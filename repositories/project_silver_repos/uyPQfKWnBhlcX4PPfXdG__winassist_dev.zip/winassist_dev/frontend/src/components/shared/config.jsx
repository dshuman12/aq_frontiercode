import React, { useState, useCallback, useEffect } from 'react'
import { useReactFlow } from '@xyflow/react'
import { Icons } from '../ui/icons'
import { Label } from '../ui/label'
import { Input } from '../ui/input'
import { Textarea } from '../ui/textarea'
import { Badge } from '../ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tab'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../ui/select'
import { UserConfig } from '../backend-node/config/userconfig'
import { ConversableAgentConfig } from '../backend-node/config/config'
import { ApiNodeConfig } from '../frontend-node/apinodeconfig'
import { ConditionNodeConfig } from '../shared/nodes/ConditionNodeConfig'
import { QuickReplyNodeConfig } from '../shared/nodes/QuickReplyNodeConfig'
import { ContainerNodeConfig } from '../shared/nodes/ContainerNodeConfig'
import { TextNodeConfig } from '../shared/nodes/TextNodeConfig'
import { ImageNodeConfig } from '../shared/nodes/ImageNodeConfig'
import { DelayNodeConfig } from '../shared/nodes/DelayNodeConfig'
import { AssistantNodeConfig } from '../shared/nodes/AssistantNodeConfig'
import { InputNodeConfig } from '../shared/nodes/InputNodeConfig'
import { BranchNodeConfig } from '../shared/nodes/BranchNodeConfig'
import { SwitchNodeConfig } from '../shared/nodes/SwitchNodeConfig'
import { MergeNodeConfig } from '../shared/nodes/MergeNodeConfig'
import { CalendarNodeConfig } from '../shared/nodes/CalendarNodeConfig'
import { FormNodeConfig } from '../shared/nodes/FormNodeConfig'
import { DocumentNodeConfig } from '../shared/nodes/DocumentNodeConfig'
import { OcrNodeConfig } from '../shared/nodes/OcrNodeConfig'
import { AnalyticsStepSection } from '../shared/nodes/AnalyticsStepSection'
import { Button } from '../ui/button'
import { toast } from '../../hooks/toast'
import { copyTextToClipboard } from '../../lib/utils'
import { DEFAULT_NODE_COLOR, resolveNodeDisplayType } from '../../lib/flow'
import { useProject } from '../../hooks/project'
import { useNavigate } from 'react-router-dom'
import { apiRequest } from '../../lib/api-client'

const NODE_COLORS = [
  { value: '#60a5fa', label: 'Light Blue' },
  { value: '#3b82f6', label: 'Blue' },
  { value: '#2dd4bf', label: 'Teal' },
  { value: '#22c55e', label: 'Green' },
  { value: '#a78bfa', label: 'Purple' },
  { value: '#f59e0b', label: 'Amber' },
  { value: '#f97316', label: 'Orange' },
  { value: '#94a3b8', label: 'Slate' },
]

// Component to display and copy API key
const ApiKeyDisplay = ({ apiKey, projectId, onRegenerate }) => {
    const [copied, setCopied] = useState(false);
    const [isRegenerating, setIsRegenerating] = useState(false);

    const handleCopy = useCallback(async () => {
        if (!apiKey) return;
        try {
            await copyTextToClipboard(apiKey);
            setCopied(true);
            toast({
                title: 'Copied!',
                description: 'API key copied to clipboard',
            });
            setTimeout(() => setCopied(false), 2000);
        } catch {
            toast({
                title: 'Copy Failed',
                description: 'Failed to copy API key',
                variant: 'destructive',
            });
        }
    }, [apiKey]);

    const handleRegenerate = useCallback(async () => {
        if (!projectId || isRegenerating) return;
        
        setIsRegenerating(true);
        try {
            const token = localStorage.getItem('token') || sessionStorage.getItem('token');
            const response = await fetch(`/api/v1/projects/${projectId}/regenerate-api-key`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json',
                },
            });

            if (response.ok) {
                const data = await response.json();
                if (onRegenerate) onRegenerate(data.api_key);
                toast({
                    title: 'API Key Regenerated',
                    description: 'New API key has been generated. Update your scripts.',
                });
            } else {
                throw new Error('Failed to regenerate API key');
            }
        } catch {
            toast({
                title: 'Regeneration Failed',
                description: 'Failed to regenerate API key. Try saving the project first.',
                variant: 'destructive',
            });
        } finally {
            setIsRegenerating(false);
        }
    }, [projectId, isRegenerating, onRegenerate]);

    if (!apiKey) {
        return (
            <div className="note-box word-wrap max-w-full rounded-lg border border-yellow-200 bg-yellow-50 dark:border-yellow-800 dark:bg-yellow-900/20">
                <div className="mb-2 flex items-start gap-2 text-yellow-700 dark:text-yellow-400">
                    <Icons.warning className="w-4 h-4" />
                    <span className="font-medium">No API Key</span>
                </div>
                <p className="mb-0 text-sm text-yellow-600 dark:text-yellow-500">
                    Click "Save" button to generate an API key for this bot.
                </p>
            </div>
        );
    }

    return (
        <div className="p-4 border rounded-lg bg-muted/50">
            <div className="flex items-center gap-2 mb-2">
                <Icons.key className="w-4 h-4 text-green-600" />
                <span className="font-medium text-sm">Bot API Key</span>
            </div>
            <div className="flex items-center gap-2 mb-3">
                <code className="flex-1 text-xs bg-background p-2 rounded border font-mono break-all">
                    {apiKey.substring(0, 20)}...{apiKey.substring(apiKey.length - 8)}
                </code>
            </div>
            <div className="flex gap-2">
                <Button
                    variant="outline"
                    size="sm"
                    onClick={handleCopy}
                    className="flex-1 gap-1"
                >
                    {copied ? (
                        <>
                            <Icons.check className="w-3 h-3" />
                            Copied
                        </>
                    ) : (
                        <>
                            <Icons.copy className="w-3 h-3" />
                            Copy Key
                        </>
                    )}
                </Button>
                <Button
                    variant="outline"
                    size="sm"
                    onClick={handleRegenerate}
                    disabled={isRegenerating}
                    className="flex-1 gap-1"
                >
                    {isRegenerating ? (
                        <>
                            <Icons.spinner className="w-3 h-3 animate-spin" />
                            Regenerating...
                        </>
                    ) : (
                        <>
                            <Icons.refresh className="w-3 h-3" />
                            Regenerate
                        </>
                    )}
                </Button>
            </div>
            <p className="text-xs text-muted-foreground mt-2">
                Use this key in your frontend widget to authenticate API calls.
            </p>
        </div>
    );
};

const DEFAULT_AI_CONFIG = {
  modelProvider: 'OpenAI',
  modelName: 'gpt-4o-mini',
  tone: 'Helpful',
  responseStyle: 'Concise',
  defaultLanguage: 'English',
  supportedLanguagesText: 'English',
  systemPrompt: '',
  enableMemory: true,
  enableRag: true,
  retrievalMode: 'hybrid',
  retrievalTopK: 3,
  chunkSize: 500,
  chunkOverlap: 50,
  knowledge_bindings: [],
  evaluationChecklist: '',
  releaseNotes: '',
  intents: [],
  entities: [],
  guardrails: {
    blockedTopicsText: '',
    escalationKeywordsText: '',
    restrictedActionsText: '',
    fallbackPolicy: 'Ask a clarification question',
    requireCitationForKnowledge: false,
    maskSensitiveData: true,
  },
  evaluationCases: [],
  evaluationRuns: [],
  improvementBacklog: [],
};

const StudioGuide = ({ title, description, example }) => (
  <div className="word-wrap rounded-lg border bg-muted/20 p-3 text-sm">
    <div className="font-medium">{title}</div>
    <p className="mt-1 text-muted-foreground">{description}</p>
    {example ? <p className="mt-2 text-xs text-muted-foreground">{example}</p> : null}
  </div>
);

const EvaluationCasesEditor = ({ value = [], onChange }) => {
  const cases = Array.isArray(value) ? value : [];

  const updateCase = (index, field, fieldValue) => {
    onChange(
      cases.map((item, itemIndex) =>
        itemIndex === index ? { ...item, [field]: fieldValue } : item
      )
    );
  };

  const removeCase = (index) => onChange(cases.filter((_, itemIndex) => itemIndex !== index));

  const addCase = () => {
    onChange([
      ...cases,
      {
        id: `eval_${Date.now()}`,
        name: '',
        query: '',
        expectedIntent: '',
        expectedRouteTarget: '',
        expectedEntitiesText: '',
      },
    ]);
  };

  return (
    <div className="space-y-3">
      {cases.map((item, index) => (
        <div key={item.id || index} className="rounded-lg border p-3 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <div className="font-medium text-sm">Evaluation Case {index + 1}</div>
            <Button variant="ghost" size="sm" onClick={() => removeCase(index)}>
              <Icons.trash className="w-4 h-4" />
            </Button>
          </div>
          <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
            <Input value={item.name || ''} onChange={(e) => updateCase(index, 'name', e.target.value)} placeholder="Case name" />
            <Input value={item.expectedIntent || ''} onChange={(e) => updateCase(index, 'expectedIntent', e.target.value)} placeholder="Expected intent" />
            <Input value={item.expectedRouteTarget || ''} onChange={(e) => updateCase(index, 'expectedRouteTarget', e.target.value)} placeholder="Expected route target" />
          </div>
          <Textarea rows={3} value={item.query || ''} onChange={(e) => updateCase(index, 'query', e.target.value)} placeholder="User message to evaluate" />
          <Textarea rows={2} value={item.expectedEntitiesText || ''} onChange={(e) => updateCase(index, 'expectedEntitiesText', e.target.value)} placeholder={'Expected entities, one per line\norder_id\nemail'} />
        </div>
      ))}
      <Button variant="outline" size="sm" onClick={addCase}>
        <Icons.add className="w-4 h-4 mr-2" />
        Add Evaluation Case
      </Button>
    </div>
  );
};

const GuardrailsEditor = ({ value = {}, onChange }) => {
  const guardrails = value || {};
  const updateGuardrails = (field, fieldValue) => {
    onChange({ ...guardrails, [field]: fieldValue });
  };

  return (
    <div className="space-y-4">
      <Textarea
        rows={3}
        value={guardrails.blockedTopicsText || ''}
        onChange={(event) => updateGuardrails('blockedTopicsText', event.target.value)}
        placeholder={'Blocked topics, one per line\nself-harm\nlegal advice'}
      />
      <Textarea
        rows={3}
        value={guardrails.escalationKeywordsText || ''}
        onChange={(event) => updateGuardrails('escalationKeywordsText', event.target.value)}
        placeholder={'Escalation keywords, one per line\nmanager\nhuman agent\ncomplaint'}
      />
      <Textarea
        rows={3}
        value={guardrails.restrictedActionsText || ''}
        onChange={(event) => updateGuardrails('restrictedActionsText', event.target.value)}
        placeholder={'Restricted actions, one per line\ndelete_user\nrefund_payment'}
      />
      <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
        <Input
          value={guardrails.fallbackPolicy || ''}
          onChange={(event) => updateGuardrails('fallbackPolicy', event.target.value)}
          placeholder="Fallback policy"
        />
        <Button
          variant={guardrails.requireCitationForKnowledge ? 'default' : 'outline'}
          onClick={() => updateGuardrails('requireCitationForKnowledge', !guardrails.requireCitationForKnowledge)}
        >
          Citation {guardrails.requireCitationForKnowledge ? 'Required' : 'Optional'}
        </Button>
        <Button
          variant={guardrails.maskSensitiveData ? 'default' : 'outline'}
          onClick={() => updateGuardrails('maskSensitiveData', !guardrails.maskSensitiveData)}
        >
          Mask Sensitive Data
        </Button>
      </div>
    </div>
  );
};

const IntentListEditor = ({ value = [], onChange }) => {
  const intents = Array.isArray(value) ? value : [];

  const updateIntent = (index, field, fieldValue) => {
    onChange(
      intents.map((item, itemIndex) =>
        itemIndex === index ? { ...item, [field]: fieldValue } : item
      )
    );
  };

  const removeIntent = (index) => {
    onChange(intents.filter((_, itemIndex) => itemIndex !== index));
  };

  const addIntent = () => {
    onChange([
      ...intents,
      {
        id: `intent_${Date.now()}`,
        name: '',
        description: '',
        utterancesText: '',
        confidenceThreshold: 0.35,
        routeTarget: '',
        language: 'English',
      },
    ]);
  };

  return (
    <div className="space-y-3">
      {intents.map((intent, index) => (
        <div key={intent.id || index} className="rounded-lg border p-3 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <div className="font-medium text-sm">Intent {index + 1}</div>
            <Button variant="ghost" size="sm" onClick={() => removeIntent(index)}>
              <Icons.trash className="w-4 h-4" />
            </Button>
          </div>
          <div className="grid grid-cols-1 gap-3 md:grid-cols-4">
            <div className="space-y-2">
              <Label>Intent key</Label>
              <Input
                value={intent.name || ''}
                onChange={(event) => updateIntent(index, 'name', event.target.value)}
                placeholder="order_status"
              />
            </div>
            <div className="space-y-2">
              <Label>Description</Label>
              <Input
                value={intent.description || ''}
                onChange={(event) => updateIntent(index, 'description', event.target.value)}
                placeholder="Customer asks about shipping or tracking"
              />
            </div>
            <div className="space-y-2">
              <Label>Confidence threshold</Label>
              <Input
                type="number"
                min="0"
                max="1"
                step="0.01"
                value={intent.confidenceThreshold ?? 0.35}
                onChange={(event) => updateIntent(index, 'confidenceThreshold', event.target.value)}
                placeholder="0.35"
              />
            </div>
            <div className="space-y-2">
              <Label>Language</Label>
              <Input
                value={intent.language || ''}
                onChange={(event) => updateIntent(index, 'language', event.target.value)}
                placeholder="English, Hindi, Spanish"
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label>Route target</Label>
            <Input
              value={intent.routeTarget || ''}
              onChange={(event) => updateIntent(index, 'routeTarget', event.target.value)}
              placeholder="support_flow or create_ticket tool"
            />
          </div>
          <div className="space-y-2">
            <Label>Training utterances</Label>
            <Textarea
              rows={5}
              value={intent.utterancesText || ''}
              onChange={(event) => updateIntent(index, 'utterancesText', event.target.value)}
              placeholder={'Where is my order?\nTrack my parcel\nHas my shipment been dispatched?'}
            />
          </div>
        </div>
      ))}
      <Button variant="outline" size="sm" onClick={addIntent}>
        <Icons.add className="w-4 h-4 mr-2" />
        Add Intent
      </Button>
    </div>
  );
};

const EntityListEditor = ({ value = [], onChange }) => {
  const entities = Array.isArray(value) ? value : [];

  const updateEntity = (index, field, fieldValue) => {
    onChange(
      entities.map((item, itemIndex) =>
        itemIndex === index ? { ...item, [field]: fieldValue } : item
      )
    );
  };

  const removeEntity = (index) => {
    onChange(entities.filter((_, itemIndex) => itemIndex !== index));
  };

  const addEntity = () => {
    onChange([
      ...entities,
      {
        id: `entity_${Date.now()}`,
        name: '',
        description: '',
        entityType: 'text',
        examplesText: '',
        pattern: '',
        normalizeMode: 'trim',
        language: 'English',
      },
    ]);
  };

  return (
    <div className="space-y-3">
      {entities.map((entity, index) => (
        <div key={entity.id || index} className="rounded-lg border p-3 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <div className="font-medium text-sm">Entity {index + 1}</div>
            <Button variant="ghost" size="sm" onClick={() => removeEntity(index)}>
              <Icons.trash className="w-4 h-4" />
            </Button>
          </div>
          <div className="grid grid-cols-1 gap-3 md:grid-cols-5">
            <div className="space-y-2">
              <Label>Entity key</Label>
              <Input
                value={entity.name || ''}
                onChange={(event) => updateEntity(index, 'name', event.target.value)}
                placeholder="order_id"
              />
            </div>
            <div className="space-y-2">
              <Label>Type</Label>
              <Select
                value={entity.entityType || 'text'}
                onValueChange={(value) => updateEntity(index, 'entityType', value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Choose entity type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="text">Text</SelectItem>
                  <SelectItem value="regex">Regex</SelectItem>
                  <SelectItem value="email">Email</SelectItem>
                  <SelectItem value="phone">Phone</SelectItem>
                  <SelectItem value="date">Date</SelectItem>
                  <SelectItem value="number">Number</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Description</Label>
              <Input
                value={entity.description || ''}
                onChange={(event) => updateEntity(index, 'description', event.target.value)}
                placeholder="Customer order reference"
              />
            </div>
            <div className="space-y-2">
              <Label>Normalization</Label>
              <Select
                value={entity.normalizeMode || 'trim'}
                onValueChange={(value) => updateEntity(index, 'normalizeMode', value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Normalization mode" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="trim">Trim only</SelectItem>
                  <SelectItem value="lowercase">Lowercase</SelectItem>
                  <SelectItem value="uppercase">Uppercase</SelectItem>
                  <SelectItem value="digits_only">Digits only</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Language</Label>
              <Input
                value={entity.language || ''}
                onChange={(event) => updateEntity(index, 'language', event.target.value)}
                placeholder="English, Hindi, Spanish"
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label>Regex pattern</Label>
            <Input
              value={entity.pattern || ''}
              onChange={(event) => updateEntity(index, 'pattern', event.target.value)}
              placeholder="Optional for regex entities, e.g. ORD-[0-9]{4}"
            />
          </div>
          <div className="space-y-2">
            <Label>Examples or synonyms</Label>
            <Textarea
              rows={4}
              value={entity.examplesText || ''}
              onChange={(event) => updateEntity(index, 'examplesText', event.target.value)}
              placeholder={'ORD-1234\ntracking number\nshipment id'}
            />
          </div>
        </div>
      ))}
      <Button variant="outline" size="sm" onClick={addEntity}>
        <Icons.add className="w-4 h-4 mr-2" />
        Add Entity
      </Button>
    </div>
  );
};

const BackendProjectConfig = ({ projectId, project }) => {
  const navigate = useNavigate();
  const { updateProject, isUpdating } = useProject(projectId);
  const [draft, setDraft] = useState(DEFAULT_AI_CONFIG);
  const [intentTestQuery, setIntentTestQuery] = useState('');
  const [intentTestResult, setIntentTestResult] = useState(null);
  const [entityTestQuery, setEntityTestQuery] = useState('');
  const [entityTestResult, setEntityTestResult] = useState(null);
  const [isTestingIntent, setIsTestingIntent] = useState(false);
  const [isTestingEntity, setIsTestingEntity] = useState(false);
  const [nluInsights, setNluInsights] = useState(null);
  const [isLoadingInsights, setIsLoadingInsights] = useState(false);
  const [intentTestHistory, setIntentTestHistory] = useState([]);
  const [entityTestHistory, setEntityTestHistory] = useState([]);
  const [evaluationResult, setEvaluationResult] = useState(null);
  const [isRunningEvaluation, setIsRunningEvaluation] = useState(false);
  const [generatedSuggestions, setGeneratedSuggestions] = useState(null);
  const [isGeneratingSuggestions, setIsGeneratingSuggestions] = useState(false);

  useEffect(() => {
    const nextConfig = {
      ...DEFAULT_AI_CONFIG,
      ...(project?.flow?.ai_config || {}),
    };
    setDraft(nextConfig);
  }, [project?.flow?.ai_config]);

  const handleSave = useCallback(async (options = {}) => {
    const { silent = false } = options;
    if (!project) return;
    try {
      await updateProject(
        {
          flow: {
            ...(project.flow || {}),
            ai_config: {
              ...draft,
              retrievalTopK: Number(draft.retrievalTopK || DEFAULT_AI_CONFIG.retrievalTopK),
              chunkSize: Number(draft.chunkSize || DEFAULT_AI_CONFIG.chunkSize),
              chunkOverlap: Number(draft.chunkOverlap || DEFAULT_AI_CONFIG.chunkOverlap),
            },
          },
        },
        { skipRevalidate: false }
      );
      if (!silent) {
        toast({
          title: 'Bot settings saved',
          description: 'Prompt, model, and retrieval defaults are now stored on this AI agent.',
        });
      }
    } catch (error) {
      if (!silent) {
        toast({
          title: 'Save failed',
          description: error instanceof Error ? error.message : 'Could not save bot settings.',
          variant: 'destructive',
        });
      }
      throw error;
    }
  }, [draft, project, updateProject]);

  const updateDraft = (key, value) => {
    setDraft((current) => ({ ...current, [key]: value }));
  };

  const knowledgeBindings = Array.isArray(draft.knowledge_bindings)
    ? draft.knowledge_bindings
    : [];

  const loadNluInsights = useCallback(async () => {
    if (!projectId) return;
    setIsLoadingInsights(true);
    try {
      await handleSave({ silent: true });
      const result = await apiRequest(`/projects/${projectId}/ai/nlu-insights`, {
        method: 'GET',
        showErrorToast: false,
      });
      setNluInsights(result);
    } catch (error) {
      toast({
        title: 'Insights load failed',
        description: error instanceof Error ? error.message : 'Could not load NLU insights.',
        variant: 'destructive',
      });
    } finally {
      setIsLoadingInsights(false);
    }
  }, [handleSave, projectId]);

  const appendUtteranceToIntent = (intentName, utterance) => {
    const trimmed = String(utterance || '').trim();
    if (!trimmed) return;
    updateDraft(
      'intents',
      (draft.intents || []).map((intent) => {
        if (intent.name !== intentName) return intent;
        const existing = String(intent.utterancesText || '').trim();
        const lines = existing ? existing.split('\n').map((line) => line.trim()) : [];
        if (lines.includes(trimmed)) return intent;
        return {
          ...intent,
          utterancesText: existing ? `${existing}\n${trimmed}` : trimmed,
        };
      })
    );
    toast({
      title: 'Training utterance added',
      description: `Added the test query to intent "${intentName}". Save to persist it.`,
    });
  };

  const appendEntityExample = (entityName, exampleValue) => {
    const trimmed = String(exampleValue || '').trim();
    if (!trimmed) return;
    updateDraft(
      'entities',
      (draft.entities || []).map((entity) => {
        if (entity.name !== entityName) return entity;
        const existing = String(entity.examplesText || '').trim();
        const lines = existing ? existing.split('\n').map((line) => line.trim()) : [];
        if (lines.includes(trimmed)) return entity;
        return {
          ...entity,
          examplesText: existing ? `${existing}\n${trimmed}` : trimmed,
        };
      })
    );
    toast({
      title: 'Entity example added',
      description: `Added "${trimmed}" to entity "${entityName}". Save to persist it.`,
    });
  };

  const pushBacklogSuggestions = useCallback((items) => {
    const existing = Array.isArray(draft.improvementBacklog) ? draft.improvementBacklog : [];
    const next = [...existing];
    (items || []).forEach((item) => {
      if (!item?.message) return;
      const key = `${item.type || 'item'}:${item.target || ''}:${item.message}`;
      if (next.some((entry) => `${entry.type || 'item'}:${entry.target || ''}:${entry.message}` === key)) {
        return;
      }
      next.unshift({ ...item, createdAt: new Date().toISOString() });
    });
    updateDraft('improvementBacklog', next.slice(0, 30));
  }, [draft.improvementBacklog]);

  const handleIntentTest = useCallback(async () => {
    if (!projectId || !intentTestQuery.trim()) return;
    setIsTestingIntent(true);
    try {
      await handleSave({ silent: true });
      const result = await apiRequest(`/projects/${projectId}/ai/intent-test`, {
        method: 'POST',
        body: { query: intentTestQuery },
        showErrorToast: false,
      });
      setIntentTestResult(result);
      setIntentTestHistory((current) => [
        { query: intentTestQuery, result, createdAt: new Date().toISOString() },
        ...current,
      ].slice(0, 8));
      if (!result?.best_intent?.name) {
        pushBacklogSuggestions([
          {
            type: 'intent_training',
            target: 'unmatched_query',
            message: `No intent matched "${intentTestQuery}". Add it to an existing intent or create a new one.`,
          },
        ]);
      }
    } catch (error) {
      toast({
        title: 'Intent test failed',
        description: error instanceof Error ? error.message : 'Could not test intent.',
        variant: 'destructive',
      });
    } finally {
      setIsTestingIntent(false);
    }
  }, [handleSave, intentTestQuery, projectId, pushBacklogSuggestions]);

  const handleEntityTest = useCallback(async () => {
    if (!projectId || !entityTestQuery.trim()) return;
    setIsTestingEntity(true);
    try {
      await handleSave({ silent: true });
      const result = await apiRequest(`/projects/${projectId}/ai/entity-test`, {
        method: 'POST',
        body: { query: entityTestQuery },
        showErrorToast: false,
      });
      setEntityTestResult(result);
      setEntityTestHistory((current) => [
        { query: entityTestQuery, result, createdAt: new Date().toISOString() },
        ...current,
      ].slice(0, 8));
      pushBacklogSuggestions(
        (result?.entities || [])
          .filter((entity) => entity.validation_passed === false)
          .map((entity) => ({
            type: 'entity_validation',
            target: entity.name,
            message: `Entity "${entity.name}" failed validation for value "${entity.value}".`,
          }))
      );
    } catch (error) {
      toast({
        title: 'Entity test failed',
        description: error instanceof Error ? error.message : 'Could not test entities.',
        variant: 'destructive',
      });
    } finally {
      setIsTestingEntity(false);
    }
  }, [entityTestQuery, handleSave, projectId, pushBacklogSuggestions]);

  const handleRunEvaluation = useCallback(async () => {
    if (!projectId) return;
    setIsRunningEvaluation(true);
    try {
      await handleSave({ silent: true });
      const payloadCases = (draft.evaluationCases || []).map((item) => ({
        name: item.name,
        query: item.query,
        expectedIntent: item.expectedIntent,
        expectedRouteTarget: item.expectedRouteTarget,
        expectedEntities: String(item.expectedEntitiesText || '')
          .split('\n')
          .map((line) => line.trim())
          .filter(Boolean),
      }));
      const result = await apiRequest(`/projects/${projectId}/ai/evaluate`, {
        method: 'POST',
        body: { cases: payloadCases },
        showErrorToast: false,
      });
      const runEntry = {
        id: `run_${Date.now()}`,
        createdAt: new Date().toISOString(),
        summary: result.summary,
        suggestions: result.suggestions || [],
      };
      setEvaluationResult(result);
      updateDraft('evaluationRuns', [runEntry, ...(draft.evaluationRuns || [])].slice(0, 15));
      pushBacklogSuggestions(result.suggestions || []);
      toast({
        title: 'Evaluation completed',
        description: `${result.summary?.passed_cases || 0}/${result.summary?.total_cases || 0} cases passed.`,
      });
    } catch (error) {
      toast({
        title: 'Evaluation failed',
        description: error instanceof Error ? error.message : 'Could not run evaluation.',
        variant: 'destructive',
      });
    } finally {
      setIsRunningEvaluation(false);
    }
  }, [draft.evaluationCases, draft.evaluationRuns, handleSave, projectId, pushBacklogSuggestions]);

  const handleGenerateSuggestions = useCallback(async () => {
    if (!projectId) return;
    setIsGeneratingSuggestions(true);
    try {
      await handleSave({ silent: true });
      const result = await apiRequest(`/projects/${projectId}/ai/improvement-suggestions`, {
        method: 'GET',
        showErrorToast: false,
      });
      setGeneratedSuggestions(result);
      pushBacklogSuggestions(result?.suggestions || []);
      toast({
        title: 'Automated suggestions generated',
        description: `${result?.summary?.suggestion_count || 0} improvement suggestion(s) were added to the backlog.`,
      });
    } catch (error) {
      toast({
        title: 'Suggestion generation failed',
        description: error instanceof Error ? error.message : 'Could not generate improvement suggestions.',
        variant: 'destructive',
      });
    } finally {
      setIsGeneratingSuggestions(false);
    }
  }, [handleSave, projectId, pushBacklogSuggestions]);

  return (
    <div className="word-wrap min-w-0 overflow-x-hidden p-4 space-y-4">
      <div className="flex items-center gap-2 border-b pb-2">
        <Icons.robot className="w-5 h-5" />
        <h3 className="font-semibold">{project?.name || 'Backend Bot'}</h3>
      </div>

      <div className="text-sm text-muted-foreground">
        {project?.description || 'Configure model, prompt, memory, and knowledge defaults for this bot.'}
      </div>

      <Tabs defaultValue="overview" className="tabs-wrapper w-full">
        <TabsList className="tabs-container h-auto rounded-lg bg-muted p-2">
          <TabsTrigger value="overview" className="tab-item max-w-none">
            Overview
          </TabsTrigger>
          <TabsTrigger value="prompt" className="tab-item max-w-none">
            Prompt
          </TabsTrigger>
          <TabsTrigger value="retrieval" className="tab-item max-w-none">
            Knowledge
          </TabsTrigger>
          <TabsTrigger value="evaluation" className="tab-item max-w-none">
            Evaluation
          </TabsTrigger>
          <TabsTrigger value="intents" className="tab-item max-w-none">
            Intents
          </TabsTrigger>
          <TabsTrigger value="entities" className="tab-item max-w-none">
            Entities
          </TabsTrigger>
          <TabsTrigger value="guardrails" className="tab-item max-w-none">
            Guardrails
          </TabsTrigger>
          <TabsTrigger value="improvement" className="tab-item max-w-none">
            Improve
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <ApiKeyDisplay apiKey={project?.api_key} projectId={projectId} />

          <div className="grid grid-cols-1 gap-3 lg:grid-cols-3">
            <StudioGuide
              title="What this bot studio controls"
              description="This page defines how the AI agent speaks, what it knows, what it detects, and what it is allowed to do."
              example="Business example: a sales bot can use a helpful tone, sales knowledge, lead-capture intents, and pricing guardrails."
            />
            <StudioGuide
              title="Who should use it"
              description="Product, operations, support, and business teams can configure AI behavior here without needing ML expertise."
              example="Use it when you want the bot to recognize new user goals, understand business fields, or follow stricter policies."
            />
            <StudioGuide
              title="How to work safely"
              description="Update one area, save, run tests, then review traces and evaluation results before using the bot in production."
              example="Recommended flow: Prompt -> Knowledge -> Intents -> Entities -> Guardrails -> Evaluation."
            />
          </div>

          <div className="rounded-lg border p-4 space-y-3">
            <div className="flex items-center gap-2">
              <Icons.sparkles className="w-4 h-4 text-primary" />
              <h4 className="font-medium">Model profile</h4>
            </div>

            <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
              <div className="space-y-2">
                <Label>Provider</Label>
                <Select value={draft.modelProvider} onValueChange={(value) => updateDraft('modelProvider', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose provider" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="OpenAI">OpenAI</SelectItem>
                    <SelectItem value="GoogleGemini">Google Gemini</SelectItem>
                    <SelectItem value="Anthropic">Anthropic</SelectItem>
                    <SelectItem value="Custom">Custom</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Model name</Label>
                <Input
                  value={draft.modelName || ''}
                  onChange={(event) => updateDraft('modelName', event.target.value)}
                  placeholder="gpt-4o-mini"
                />
              </div>

              <div className="space-y-2">
                <Label>Tone</Label>
                <Input
                  value={draft.tone || ''}
                  onChange={(event) => updateDraft('tone', event.target.value)}
                  placeholder="Helpful, sales-oriented, calm"
                />
              </div>

              <div className="space-y-2">
                <Label>Response style</Label>
                <Input
                  value={draft.responseStyle || ''}
                  onChange={(event) => updateDraft('responseStyle', event.target.value)}
                  placeholder="Concise, detailed, consultative"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Default language</Label>
              <Input
                value={draft.defaultLanguage || ''}
                onChange={(event) => updateDraft('defaultLanguage', event.target.value)}
                placeholder="English"
              />
            </div>
            <div className="space-y-2">
              <Label>Supported languages</Label>
              <Textarea
                rows={3}
                value={draft.supportedLanguagesText || ''}
                onChange={(event) => updateDraft('supportedLanguagesText', event.target.value)}
                placeholder={'English\nHindi\nSpanish'}
              />
            </div>
          </div>
        </TabsContent>

        <TabsContent value="prompt" className="space-y-4">
          <StudioGuide
            title="What is the system prompt?"
            description="The system prompt is the master instruction set for the AI agent. It defines role, business rules, escalation behavior, response style, and hard constraints."
            example='Example: "You are a B2B support assistant for Acme. Use uploaded policy documents, never invent refund approvals, and escalate billing disputes to a human agent."'
          />
          <div className="rounded-lg border p-4 space-y-3">
            <div className="flex items-center gap-2">
              <Icons.docs className="w-4 h-4 text-primary" />
              <h4 className="font-medium">System prompt</h4>
            </div>
            <Textarea
              rows={10}
              value={draft.systemPrompt || ''}
              onChange={(event) => updateDraft('systemPrompt', event.target.value)}
              placeholder="Describe business rules, persona, safety instructions, escalation policy, and answer style."
            />
            <p className="text-xs text-muted-foreground">
              This project-level prompt is stored in `flow.ai_config` so it can be versioned with the bot itself.
            </p>
          </div>
        </TabsContent>

        <TabsContent value="retrieval" className="space-y-4">
          <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
            <StudioGuide
              title="What is RAG?"
              description="RAG means Retrieval-Augmented Generation. Before answering, the platform retrieves relevant passages from your knowledge base and gives them to the model as grounded context."
              example="Use RAG for manuals, policies, pricing sheets, compliance rules, or product documentation."
            />
            <StudioGuide
              title="What do Top K, Chunk size, and Chunk overlap mean?"
              description="These are retrieval settings, not training epochs or ML batch sizes."
              example="`Top K = 3` returns the best 3 passages. `Chunk size = 500` splits documents into 500-character blocks. `Chunk overlap = 50` repeats 50 characters between blocks so context is not lost."
            />
            <StudioGuide
              title="What is retrieval mode?"
              description="Retrieval mode decides whether the bot should prioritize intent routing, grounded knowledge, freeform reasoning, or a blend of all three."
              example="Use `RAG-first` for policy bots, `Intent-first` for workflow bots, and `Hybrid` for assistants that both answer and act."
            />
          </div>
          <div className="rounded-lg border bg-muted/20 p-3 text-sm text-muted-foreground">
            This tab only defines the bot's retrieval strategy and defaults. Source uploads, URL connectors, collections, and bot-to-collection bindings are managed in `Knowledge Base`.
          </div>
          <div className="rounded-lg border p-4 space-y-3">
            <div className="flex items-center gap-2">
              <Icons.docs className="w-4 h-4 text-primary" />
              <h4 className="font-medium">Knowledge and RAG defaults</h4>
            </div>

            <div className="flex flex-wrap gap-2">
              <Badge variant={draft.enableMemory ? 'secondary' : 'outline'}>
                Memory {draft.enableMemory ? 'enabled' : 'disabled'}
              </Badge>
              <Badge variant={draft.enableRag ? 'secondary' : 'outline'}>
                RAG {draft.enableRag ? 'enabled' : 'disabled'}
              </Badge>
              <Badge variant="outline">{knowledgeBindings.length} collections bound</Badge>
            </div>

            <div className="grid grid-cols-1 gap-3 md:grid-cols-4">
              <div className="space-y-2">
                <Label>Retrieval mode</Label>
                <Select value={draft.retrievalMode || 'hybrid'} onValueChange={(value) => updateDraft('retrievalMode', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose retrieval mode" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="hybrid">Hybrid</SelectItem>
                    <SelectItem value="rag-first">RAG-first</SelectItem>
                    <SelectItem value="intent-first">Intent-first</SelectItem>
                    <SelectItem value="freeform">Freeform</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Top K</Label>
                <Input
                  type="number"
                  min="1"
                  value={draft.retrievalTopK}
                  onChange={(event) => updateDraft('retrievalTopK', event.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>Chunk size</Label>
                <Input
                  type="number"
                  min="100"
                  value={draft.chunkSize}
                  onChange={(event) => updateDraft('chunkSize', event.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>Chunk overlap</Label>
                <Input
                  type="number"
                  min="0"
                  value={draft.chunkOverlap}
                  onChange={(event) => updateDraft('chunkOverlap', event.target.value)}
                />
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              <Button
                variant={draft.enableMemory ? 'default' : 'outline'}
                size="sm"
                onClick={() => updateDraft('enableMemory', !draft.enableMemory)}
              >
                Toggle Memory
              </Button>
              <Button
                variant={draft.enableRag ? 'default' : 'outline'}
                size="sm"
                onClick={() => updateDraft('enableRag', !draft.enableRag)}
              >
                Toggle RAG
              </Button>
              <Button variant="outline" size="sm" onClick={() => navigate('/knowledge-base')}>
                Open Knowledge Base
              </Button>
            </div>

            <div className="rounded-lg bg-muted/30 p-3 text-xs text-muted-foreground">
              Bind collections from the Knowledge Base page. Their IDs are stored in this bot's `knowledge_bindings` field so the runtime can load the correct knowledge pack for this agent.
            </div>
          </div>
        </TabsContent>

        <TabsContent value="evaluation" className="space-y-4">
          <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
            <StudioGuide
              title="What is evaluation?"
              description="Evaluation checks whether the bot behaves the way your business expects across representative user questions."
              example="Example suite: pricing request, refund request, escalation request, and policy lookup."
            />
            <StudioGuide
              title="Why it matters"
              description="This helps teams catch regressions after prompt, knowledge, intent, or policy changes."
              example="If a new document causes the wrong routing or a weaker answer, evaluation should reveal it before launch."
            />
          </div>
          <div className="rounded-lg border bg-muted/20 p-3 text-sm text-muted-foreground">
            This tab is for bot quality definition and test execution. Governed releases, approval checks, rollback, and version comparison are handled in `Publish Center`.
          </div>
          <div className="rounded-lg border p-4 space-y-3">
            <div className="flex items-center gap-2">
              <Icons.circleGauge className="w-4 h-4 text-primary" />
              <h4 className="font-medium">Evaluation workspace</h4>
            </div>

            <div className="space-y-2">
              <Label>Evaluation checklist</Label>
              <Textarea
                rows={8}
                value={draft.evaluationChecklist || ''}
                onChange={(event) => updateDraft('evaluationChecklist', event.target.value)}
                placeholder={'Example:\n- ask product pricing question\n- ask refund flow question\n- ask support escalation question\n- verify grounded answer cites uploaded docs'}
              />
            </div>

            <div className="space-y-2">
              <Label>Release notes</Label>
              <Textarea
                rows={4}
                value={draft.releaseNotes || ''}
                onChange={(event) => updateDraft('releaseNotes', event.target.value)}
                placeholder="Summarize prompt, knowledge, or policy changes before publishing."
              />
            </div>

            <div className="rounded-lg bg-muted/30 p-3 text-xs text-muted-foreground">
              Store the manual test plan here so prompt changes, knowledge updates, and future publish workflows all reference the same evaluation notes.
            </div>
            <div className="border-t pt-4 space-y-3">
              <div className="font-medium text-sm">Evaluation cases</div>
              <EvaluationCasesEditor
                value={draft.evaluationCases}
                onChange={(value) => updateDraft('evaluationCases', value)}
              />
              <Button onClick={handleRunEvaluation} disabled={isRunningEvaluation}>
                {isRunningEvaluation ? 'Running...' : 'Run Evaluation Suite'}
              </Button>
              <Button
                variant="outline"
                onClick={() => navigate(`/publish-center?projectId=${projectId}`)}
              >
                Open Release Governance
              </Button>
              {evaluationResult ? (
                <div className="rounded-lg bg-muted/30 p-3 space-y-2">
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="secondary">pass rate: {evaluationResult.summary?.pass_rate}</Badge>
                    <Badge variant="outline">passed: {evaluationResult.summary?.passed_cases}</Badge>
                    <Badge variant="outline">failed: {evaluationResult.summary?.failed_cases}</Badge>
                  </div>
                  {(evaluationResult.results || []).map((item) => (
                    <div key={`${item.case_index}-${item.name}`} className="rounded border bg-background p-2 text-xs">
                      <div className="font-medium">{item.name}</div>
                      <div>{item.passed ? 'Passed' : 'Failed'}</div>
                      {!item.passed ? (
                        <div className="text-red-600">{(item.failures || []).join(' ')}</div>
                      ) : null}
                    </div>
                  ))}
                </div>
              ) : null}
              {(draft.evaluationRuns || []).length > 0 ? (
                <div className="space-y-2">
                  <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                    Evaluation history
                  </div>
                  {(draft.evaluationRuns || []).map((run) => (
                    <div key={run.id} className="rounded border bg-muted/20 p-2 text-xs">
                      <div>{run.createdAt}</div>
                      <div>
                        {run.summary?.passed_cases}/{run.summary?.total_cases} passed
                      </div>
                    </div>
                  ))}
                </div>
              ) : null}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="guardrails" className="space-y-4">
          <div className="grid grid-cols-1 gap-3 lg:grid-cols-3">
            <StudioGuide
              title="Blocked topics"
              description="Subjects the bot must avoid or refuse."
              example="Example: legal advice, medical advice, or internal-only strategy."
            />
            <StudioGuide
              title="Escalation triggers"
              description="Keywords or situations that should move the conversation toward a human handoff."
              example="Example: complaint, manager, urgent, lawsuit, cancel my contract."
            />
            <StudioGuide
              title="Restricted actions"
              description="Operations the bot must never claim to complete unless a trusted system actually performs them."
              example="Example: issue refund, delete account, approve discount, change billing plan."
            />
          </div>
          <div className="rounded-lg border p-4 space-y-3">
            <div className="flex items-center gap-2">
              <Icons.warning className="w-4 h-4 text-primary" />
              <h4 className="font-medium">Guardrails and policy</h4>
            </div>
            <p className="text-xs text-muted-foreground">
              Configure blocked topics, escalation triggers, restricted actions, and response policy for sensitive interactions.
            </p>
            <GuardrailsEditor
              value={draft.guardrails}
              onChange={(value) => updateDraft('guardrails', value)}
            />
          </div>
        </TabsContent>

        <TabsContent value="improvement" className="space-y-4">
          <StudioGuide
            title="What is the improvement backlog?"
            description="This is the team's working queue of AI issues, gaps, and retraining ideas discovered during tests and evaluations."
            example="Typical backlog items: add more utterances for a weak intent, tighten a regex, or upload a missing policy document."
          />
          <div className="rounded-lg border p-4 space-y-3">
            <div className="flex items-center gap-2">
              <Icons.inbox className="w-4 h-4 text-primary" />
              <h4 className="font-medium">Improvement backlog</h4>
            </div>
            <p className="text-xs text-muted-foreground">
              Suggestions from failed evaluations and training tests are collected here so the bot can be improved iteratively.
            </p>
            <div className="rounded-lg border bg-muted/20 p-3 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <div className="text-sm font-medium">Automated training suggestions</div>
                  <p className="text-xs text-muted-foreground">
                    P3 starter: analyze recent user traffic plus current AI settings to generate suggested intent, entity, knowledge, evaluation, and release improvements.
                  </p>
                </div>
                <Button variant="outline" onClick={handleGenerateSuggestions} disabled={isGeneratingSuggestions}>
                  {isGeneratingSuggestions ? 'Generating...' : 'Generate Suggestions'}
                </Button>
              </div>
              {generatedSuggestions?.summary ? (
                <div className="flex flex-wrap gap-2">
                  <Badge variant="outline">queries: {generatedSuggestions.summary.recent_queries_analyzed || 0}</Badge>
                  <Badge variant="outline">suggestions: {generatedSuggestions.summary.suggestion_count || 0}</Badge>
                  <Badge variant="outline">unmatched: {generatedSuggestions.summary.unmatched_query_count || 0}</Badge>
                  <Badge variant="outline">entity gaps: {generatedSuggestions.summary.entity_gap_count || 0}</Badge>
                  <Badge variant="outline">guardrail hits: {generatedSuggestions.summary.guardrail_hit_count || 0}</Badge>
                </div>
              ) : null}
            </div>
            {(draft.improvementBacklog || []).length === 0 ? (
              <div className="rounded-lg border border-dashed p-4 text-sm text-muted-foreground">
                No improvement suggestions yet. Run tests and evaluations to build the backlog.
              </div>
            ) : (
              <div className="space-y-2">
                {(draft.improvementBacklog || []).map((item, index) => (
                  <div key={`${item.createdAt || index}-${index}`} className="rounded border bg-muted/20 p-3">
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="outline">{item.type || 'suggestion'}</Badge>
                      {item.target ? <Badge variant="secondary">{item.target}</Badge> : null}
                    </div>
                    <div className="mt-2 text-sm">{item.message}</div>
                  </div>
                ))}
              </div>
            )}
            {(draft.improvementBacklog || []).length > 0 ? (
              <Button variant="outline" onClick={() => updateDraft('improvementBacklog', [])}>
                Clear Backlog
              </Button>
            ) : null}
          </div>
        </TabsContent>

        <TabsContent value="intents" className="space-y-4">
          <div className="grid grid-cols-1 gap-3 lg:grid-cols-3">
            <StudioGuide
              title="What is an intent?"
              description="An intent is the user's goal or job to be done."
              example="Examples: `track_order`, `book_demo`, `cancel_subscription`, `reset_password`."
            />
            <StudioGuide
              title="What are training utterances?"
              description="These are example sentences users might say when they have that goal."
              example='Example for `track_order`: "Where is my package?", "Track my shipment", "Has order 123 shipped?"'
            />
            <StudioGuide
              title="What is route target?"
              description="Route target is the destination workflow, flow, or tool the platform should prefer when that intent wins."
              example="Example: `support_flow`, `create_ticket`, or `lead_capture_form`."
            />
          </div>
          <div className="rounded-lg border p-4 space-y-3">
            <div className="flex items-center gap-2">
              <Icons.sparkles className="w-4 h-4 text-primary" />
              <h4 className="font-medium">Intent Studio</h4>
            </div>
            <p className="text-xs text-muted-foreground">
              Start defining trainable user goals here. These intents are stored with the bot, and each intent can be scoped to a specific business language.
            </p>
            <IntentListEditor
              value={draft.intents}
              onChange={(value) => updateDraft('intents', value)}
            />
            <div className="flex flex-wrap gap-2 border-t pt-4">
              <Button variant="outline" onClick={loadNluInsights} disabled={isLoadingInsights}>
                {isLoadingInsights ? 'Loading...' : 'Check Intent Overlap'}
              </Button>
            </div>
            {(nluInsights?.intent_insights?.warnings || []).length > 0 ? (
              <div className="space-y-2 rounded-lg bg-amber-50 p-3">
                <div className="text-xs font-semibold uppercase tracking-wide text-amber-700">
                  Intent Warnings
                </div>
                {(nluInsights.intent_insights.warnings || []).map((warning, index) => (
                  <div key={`${warning.intent || 'intent'}-${index}`} className="text-sm text-amber-800">
                    {warning.message}
                  </div>
                ))}
              </div>
            ) : null}
            <div className="rounded-lg border-t pt-4 space-y-3">
              <Label>Test intent classification</Label>
              <Textarea
                rows={3}
                value={intentTestQuery}
                onChange={(event) => setIntentTestQuery(event.target.value)}
                placeholder="Type a real customer message to test against the configured intents."
              />
              <Button onClick={handleIntentTest} disabled={isTestingIntent || !intentTestQuery.trim()}>
                {isTestingIntent ? 'Testing...' : 'Run Intent Test'}
              </Button>
              {intentTestResult ? (
                <div className="space-y-2 rounded-lg bg-muted/30 p-3">
                  <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                    Best Intent
                  </div>
                  <div className="text-sm">
                    {intentTestResult.best_intent?.name || 'No intent passed threshold'}
                  </div>
                  {intentTestResult.detected_language ? (
                    <Badge variant="outline">language: {intentTestResult.detected_language}</Badge>
                  ) : null}
                  <div className="flex flex-wrap gap-2">
                    {(intentTestResult.candidates || []).map((candidate) => (
                      <Badge key={candidate.name} variant={candidate.passed_threshold ? 'secondary' : 'outline'}>
                        {candidate.name}: {candidate.confidence}
                      </Badge>
                    ))}
                  </div>
                  {intentTestResult.best_intent?.name ? (
                    <div className="flex flex-wrap gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => appendUtteranceToIntent(intentTestResult.best_intent.name, intentTestQuery)}
                      >
                        Add query to matched intent
                      </Button>
                      {intentTestResult.best_intent?.route_target ? (
                        <Badge variant="outline">
                          route: {intentTestResult.best_intent.route_target}
                        </Badge>
                      ) : null}
                    </div>
                  ) : null}
                </div>
              ) : null}
              {intentTestHistory.length > 0 ? (
                <div className="space-y-2">
                  <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                    Recent intent tests
                  </div>
                  {intentTestHistory.map((entry, index) => (
                    <div key={`${entry.createdAt}-${index}`} className="rounded border bg-muted/20 p-2 text-xs">
                      <div className="font-medium">{entry.query}</div>
                      <div className="text-muted-foreground">
                        {entry.result?.best_intent?.name || 'No passing intent'}
                      </div>
                    </div>
                  ))}
                </div>
              ) : null}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="entities" className="space-y-4">
          <div className="grid grid-cols-1 gap-3 lg:grid-cols-3">
            <StudioGuide
              title="What is an entity?"
              description="An entity is a structured value the bot should capture from the user's message."
              example="Examples: order ID, email, phone number, city, plan type, appointment date."
            />
            <StudioGuide
              title="What is normalization?"
              description="Normalization converts extracted values into a clean format that downstream tools and prompts can reuse reliably."
              example="Example: turning ` ORD-1234 ` into `ord-1234` or keeping only digits from a phone number."
            />
            <StudioGuide
              title="When should I use regex?"
              description="Use regex when a business field follows a very specific pattern."
              example="Example: invoice code `INV-[0-9]{6}` or employee ID `EMP-[A-Z]{3}`."
            />
          </div>
          <div className="rounded-lg border p-4 space-y-3">
            <div className="flex items-center gap-2">
              <Icons.docs className="w-4 h-4 text-primary" />
              <h4 className="font-medium">Entity Studio</h4>
            </div>
            <p className="text-xs text-muted-foreground">
              Define structured values the bot should recognize and reuse in future flows, prompts, and validations, including language-specific fields.
            </p>
            <EntityListEditor
              value={draft.entities}
              onChange={(value) => updateDraft('entities', value)}
            />
            <div className="flex flex-wrap gap-2 border-t pt-4">
              <Button variant="outline" onClick={loadNluInsights} disabled={isLoadingInsights}>
                {isLoadingInsights ? 'Loading...' : 'Check Entity Warnings'}
              </Button>
            </div>
            {(nluInsights?.entity_insights?.warnings || []).length > 0 ? (
              <div className="space-y-2 rounded-lg bg-amber-50 p-3">
                <div className="text-xs font-semibold uppercase tracking-wide text-amber-700">
                  Entity Warnings
                </div>
                {(nluInsights.entity_insights.warnings || []).map((warning, index) => (
                  <div key={`${warning.entity || 'entity'}-${index}`} className="text-sm text-amber-800">
                    {warning.message}
                  </div>
                ))}
              </div>
            ) : null}
            <div className="rounded-lg border-t pt-4 space-y-3">
              <Label>Test entity extraction</Label>
              <Textarea
                rows={3}
                value={entityTestQuery}
                onChange={(event) => setEntityTestQuery(event.target.value)}
                placeholder="Try a realistic user message with names, dates, emails, order IDs, or other fields."
              />
              <Button onClick={handleEntityTest} disabled={isTestingEntity || !entityTestQuery.trim()}>
                {isTestingEntity ? 'Testing...' : 'Run Entity Test'}
              </Button>
              {entityTestResult ? (
                <div className="space-y-2 rounded-lg bg-muted/30 p-3">
                  <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                    Extracted Entities
                  </div>
                  {entityTestResult.detected_language ? (
                    <Badge variant="outline">language: {entityTestResult.detected_language}</Badge>
                  ) : null}
                  {(entityTestResult.entities || []).length === 0 ? (
                    <div className="text-sm text-muted-foreground">No entities detected.</div>
                  ) : (
                    <div className="space-y-2">
                      {(entityTestResult.entities || []).map((entity) => (
                        <div key={`${entity.name}-${entity.value}`} className="rounded border bg-background p-2">
                          <div className="flex flex-wrap gap-2">
                            <Badge variant="secondary">{entity.name}: {entity.value}</Badge>
                            <Badge variant="outline">normalized: {entity.normalized_value}</Badge>
                            <Badge variant={entity.validation_passed ? 'secondary' : 'outline'}>
                              {entity.validation_passed ? 'valid' : 'invalid'}
                            </Badge>
                          </div>
                          <div className="mt-2 flex flex-wrap gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => appendEntityExample(entity.name, entity.normalized_value || entity.value)}
                            >
                              Add as entity example
                            </Button>
                            {entity.validation_error ? (
                              <span className="text-xs text-red-600">{entity.validation_error}</span>
                            ) : null}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ) : null}
              {entityTestHistory.length > 0 ? (
                <div className="space-y-2">
                  <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                    Recent entity tests
                  </div>
                  {entityTestHistory.map((entry, index) => (
                    <div key={`${entry.createdAt}-${index}`} className="rounded border bg-muted/20 p-2 text-xs">
                      <div className="font-medium">{entry.query}</div>
                      <div className="text-muted-foreground">
                        {(entry.result?.entities || []).map((entity) => entity.name).join(', ') || 'No entities detected'}
                      </div>
                    </div>
                  ))}
                </div>
              ) : null}
            </div>
          </div>
        </TabsContent>
      </Tabs>

      <Button onClick={handleSave} disabled={isUpdating} className="w-full">
        {isUpdating ? 'Saving...' : 'Save Bot Studio Settings'}
      </Button>
    </div>
  );
};

const EDGE_COLORS = [
  { value: '#1e3a5f', label: 'Dark blue' },
  { value: '#2563eb', label: 'Blue' },
  { value: '#059669', label: 'Green' },
  { value: '#dc2626', label: 'Red' },
  { value: '#7c3aed', label: 'Purple' },
  { value: '#ea580c', label: 'Orange' },
  { value: '#0d9488', label: 'Teal' },
  { value: '#4f46e5', label: 'Indigo' },
];

const EdgeConfig = ({ edgeId }) => {
  const { getEdges, setEdges } = useReactFlow();
  const edges = getEdges();
  const edge = edges.find((e) => e.id === edgeId);

  if (!edge) {
    return (
      <div className="flex flex-col justify-center items-center h-full text-muted-foreground/50 gap-2 p-4">
        <Icons.agent className="w-6 h-6" />
        <span className="text-sm font-bold">Edge not found</span>
      </div>
    );
  }

  const edgeType = edge.type === 'step' ? 'step' : 'converse';
  const color = edge.data?.color || '#1e3a5f';
  const strokeWidth = Number(edge.data?.strokeWidth || 4);

  const setEdgeType = (type) => {
    setEdges(
      edges.map((e) =>
        e.id === edgeId ? { ...e, type: type === 'special' ? 'step' : 'converse' } : e
      )
    );
  };

  const setEdgeColor = (newColor) => {
    setEdges(
      edges.map((e) =>
        e.id === edgeId ? { ...e, data: { ...e.data, color: newColor } } : e
      )
    );
  };

  const setEdgeThickness = (newWidth) => {
    const clampedWidth = Math.min(12, Math.max(1, Number(newWidth)));
    setEdges(
      edges.map((e) =>
        e.id === edgeId
          ? { ...e, data: { ...e.data, strokeWidth: clampedWidth } }
          : e
      )
    );
  };

  return (
    <div className="p-4 space-y-4">
      <div className="flex items-center gap-2 border-b pb-2">
        <Icons.config className="w-5 h-5" />
        <h3 className="font-semibold">Connection</h3>
      </div>
      <div className="space-y-3">
        <div className="space-y-2">
          <Label>Edge type</Label>
          <Select
            value={edgeType === 'step' ? 'special' : 'normal'}
            onValueChange={(v) => setEdgeType(v)}
          >
            <SelectTrigger>
              <SelectValue placeholder="Choose type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="normal">Normal (curved)</SelectItem>
              <SelectItem value="special">Special (right-angle)</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label>Color</Label>
          <div className="flex flex-wrap gap-2">
            {EDGE_COLORS.map(({ value, label }) => (
              <button
                key={value}
                type="button"
                title={label}
                className="w-8 h-8 rounded-full border-2 transition-all hover:scale-110 focus:outline-none focus:ring-2 focus:ring-ring"
                style={{
                  backgroundColor: value,
                  borderColor: color === value ? 'var(--primary)' : 'transparent',
                  boxShadow: color === value ? '0 0 0 2px var(--primary)' : undefined,
                }}
                onClick={() => setEdgeColor(value)}
              />
            ))}
          </div>
          <p className="text-xs text-muted-foreground">Or use default dark blue</p>
        </div>
        <div className="space-y-2">
          <div className="flex items-center justify-between gap-3">
            <Label>Thickness</Label>
            <span className="text-xs font-medium text-muted-foreground">
              {strokeWidth.toFixed(1)} px
            </span>
          </div>
          <input
            type="range"
            min="1"
            max="12"
            step="0.5"
            value={strokeWidth}
            onChange={(event) => setEdgeThickness(event.target.value)}
            className="w-full accent-primary"
          />
          <div className="flex items-center gap-2">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setEdgeThickness(strokeWidth - 0.5)}
            >
              -0.5
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setEdgeThickness(strokeWidth + 0.5)}
            >
              +0.5
            </Button>
          </div>
          <p className="text-xs text-muted-foreground">
            Select a connection, then adjust its stroke width.
          </p>
        </div>
      </div>
    </div>
  );
};

const NodeAppearanceConfig = ({ nodeId }) => {
  const { getNode, setNodes } = useReactFlow();
  const node = getNode(nodeId);
  const color = node?.data?.color || DEFAULT_NODE_COLOR;

  if (!node) {
    return null;
  }

  const setNodeColor = (newColor) => {
    setNodes((nodes) =>
      nodes.map((entry) =>
        entry.id === nodeId
          ? {
              ...entry,
              data: {
                ...entry.data,
                color: newColor,
              },
            }
          : entry
      )
    );
  };

  return (
    <div className="border-t p-4 space-y-3">
      <div className="flex items-center gap-2">
        <Icons.config className="w-4 h-4" />
        <h3 className="font-semibold">Node appearance</h3>
      </div>
      <div className="space-y-2">
        <Label>Color</Label>
        <div className="flex flex-wrap gap-2">
          {NODE_COLORS.map(({ value, label }) => (
            <button
              key={value}
              type="button"
              title={label}
              className="w-8 h-8 rounded-full border-2 transition-all hover:scale-110 focus:outline-none focus:ring-2 focus:ring-ring"
              style={{
                backgroundColor: value,
                borderColor: color === value ? 'var(--primary)' : 'transparent',
                boxShadow: color === value ? '0 0 0 2px var(--primary)' : undefined,
              }}
              onClick={() => setNodeColor(value)}
            />
          ))}
        </div>
        <p className="text-xs text-muted-foreground">
          Default node color is light blue. You can override it per node here.
        </p>
      </div>
    </div>
  );
};

export const FlowConfig = ({ nodeId, edgeId, projectId, project }) => {
    const { getNode } = useReactFlow()

    if (edgeId) {
      return <EdgeConfig edgeId={edgeId} />;
    }

    if (!nodeId) {
        // Show project-level configuration (API key for backend projects)
        if (project && project.project_type === 'backend') {
            return <BackendProjectConfig projectId={projectId} project={project} />
        }
        
        return (
            <div className="flex flex-col justify-center items-center h-full text-muted-foreground/50 gap-2">
                <Icons.agent className="w-6 h-6" />
                <span className="text-sm font-bold">
                    Select a node to configure
                </span>
            </div>
        )
    }

    const node = getNode(nodeId)

    if (!node) {
        return (
            <div className="flex flex-col justify-center items-center h-full text-muted-foreground/50 gap-2">
                <Icons.agent className="w-6 h-6" />
                <span className="text-sm font-bold">Node not found</span>
            </div>
        )
    }

    const type = resolveNodeDisplayType(node.data, node.type)
    let configContent = null
    
    // Debug: log node type for troubleshooting
    if (type === 'api') {
        undefined
    }

    switch (type) {
        case 'user':
            configContent = <UserConfig nodeId={nodeId} data={node.data} />
            break

        case 'conversable':
            configContent = <ConversableAgentConfig nodeId={nodeId} data={node.data} />
            break
        case 'api':
            configContent = <ApiNodeConfig nodeId={nodeId} data={node.data} />
            break
        case 'condition':
            configContent = <ConditionNodeConfig nodeId={nodeId} data={node.data} />
            break
        case 'quickreply':
            configContent = <QuickReplyNodeConfig nodeId={nodeId} data={node.data} />
            break
        case 'container':
            configContent = <ContainerNodeConfig nodeId={nodeId} data={node.data} />
            break
        case 'text':
            configContent = <TextNodeConfig nodeId={nodeId} data={node.data} />
            break
        case 'image':
            configContent = <ImageNodeConfig nodeId={nodeId} data={node.data} />
            break
        case 'delay':
            configContent = <DelayNodeConfig nodeId={nodeId} data={node.data} />
            break
        case 'assistant':
            configContent = <AssistantNodeConfig nodeId={nodeId} data={node.data} />
            break
        case 'input':
            configContent = <InputNodeConfig nodeId={nodeId} data={node.data} />
            break
        case 'calendar':
            configContent = <CalendarNodeConfig nodeId={nodeId} data={node.data} />
            break
        case 'form':
            configContent = <FormNodeConfig nodeId={nodeId} data={node.data} />
            break
        case 'document':
            configContent = <DocumentNodeConfig nodeId={nodeId} data={node.data} />
            break
        case 'ocr':
            configContent = <OcrNodeConfig nodeId={nodeId} data={node.data} />
            break
        case 'branch':
            configContent = <BranchNodeConfig nodeId={nodeId} data={node.data} />
            break
        case 'switch':
            configContent = <SwitchNodeConfig nodeId={nodeId} data={node.data} />
            break
        case 'merge':
            configContent = <MergeNodeConfig nodeId={nodeId} data={node.data} />
            break
        default:
            return (
                <div className="flex flex-col justify-center items-center h-full text-muted-foreground gap-2">
                    <Icons.agent className="w-10 h-10" />
                    <span className="text-sm font-bold">
                        No configuration available for this node type
                    </span>
                </div>
            )
    }

    return (
        <>
            {configContent}
            <AnalyticsStepSection nodeId={nodeId} />
            <NodeAppearanceConfig nodeId={nodeId} />
        </>
    )
}
