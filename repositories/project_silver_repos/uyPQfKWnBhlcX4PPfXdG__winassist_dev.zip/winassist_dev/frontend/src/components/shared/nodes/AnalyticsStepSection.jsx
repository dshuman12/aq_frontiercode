import React, { useState, useEffect, useRef } from 'react';
import { Label } from '../../ui/label';
import { Input } from '../../ui/input';
import { Switch } from '../../ui/switch';
import { setNodeData } from '../../../lib/flow';
import { useReactFlow } from '@xyflow/react';
import { Icons } from '../../ui/icons';

const DEBOUNCE_MS = 400;

/**
 * Analytics step options for funnel/dashboard.
 * Shown for every node so you can decide: track as step (include in funnel) and set a step label.
 */
export const AnalyticsStepSection = React.memo(({ nodeId }) => {
  const instance = useReactFlow();
  const node = instance.getNode(nodeId);
  const data = node?.data || {};

  const [stepLabelLocal, setStepLabelLocal] = useState(data.analyticsStepLabel ?? '');
  const [trackAsStepLocal, setTrackAsStepLocal] = useState(data.trackAsStep !== false); // default true
  const debounceRef = useRef(null);

  // Sync from node data only when switching to a different node (keeps typing smooth)
  useEffect(() => {
    setStepLabelLocal(data?.analyticsStepLabel ?? '');
    setTrackAsStepLocal(data?.trackAsStep !== false);
    if (debounceRef.current) {
      clearTimeout(debounceRef.current);
      debounceRef.current = null;
    }
  }, [nodeId]);

  useEffect(() => {
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, []);

  const updateNode = (updates) => {
    setNodeData(instance, nodeId, updates);
  };

  const handleStepLabelChange = (e) => {
    const v = e.target.value;
    setStepLabelLocal(v);

    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      debounceRef.current = null;
      updateNode({ analyticsStepLabel: v });
    }, DEBOUNCE_MS);
  };

  const handleStepLabelBlur = () => {
    if (debounceRef.current) {
      clearTimeout(debounceRef.current);
      debounceRef.current = null;
      updateNode({ analyticsStepLabel: stepLabelLocal });
    }
  };

  return (
    <div className="border-t pt-4 mt-4 space-y-3 nodrag nowheel" onPointerDown={(e) => e.stopPropagation()}>
      <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
        <Icons.circleGauge className="w-4 h-4" />
        <span>Analytics step</span>
      </div>
      <p className="text-xs text-muted-foreground">
        Control how this node appears in the Project Dashboard funnel and step analytics.
      </p>
      <div className="flex items-center justify-between gap-4">
        <Label htmlFor={`track-step-${nodeId}`} className="text-sm font-normal cursor-pointer">
          Track as step (include in funnel)
        </Label>
        <Switch
          id={`track-step-${nodeId}`}
          checked={trackAsStepLocal}
          onCheckedChange={(checked) => {
            setTrackAsStepLocal(checked);
            updateNode({ trackAsStep: checked });
          }}
        />
      </div>
      <div className="space-y-1.5">
        <Label htmlFor={`step-label-${nodeId}`} className="text-sm">
          Step label (for analytics)
        </Label>
        <Input
          id={`step-label-${nodeId}`}
          value={stepLabelLocal}
          onChange={handleStepLabelChange}
          onBlur={handleStepLabelBlur}
          onPointerDown={(e) => e.stopPropagation()}
          placeholder="Uses node label if empty"
          className="bg-transparent nodrag nowheel text-sm"
          autoComplete="off"
        />
      </div>
    </div>
  );
});

AnalyticsStepSection.displayName = 'AnalyticsStepSection';
