import { memo } from 'react';
import { GenericNode } from '../generic-node';

const InputNode = memo(({ id, data, selected, width, height, ...props }) => {
  const variable = data.variableName || 'userInput';
  const prompt = data.prompt || 'Enter input:';
  const truncatedPrompt = prompt.length > 50 ? prompt.substring(0, 50) + '...' : prompt;

  return (
    <GenericNode
      id={id}
      data={{
        ...data,
        id: data.id || 'input',
        name: data.name || data.label || 'Input',
      }}
      selected={selected}
      width={width}
      minHeight={104}
      ports={[
        { type: 'target', name: 'input' },
        { type: 'source', name: 'output' },
      ]}
      {...props}
    >
      <div className="space-y-2">
        <div className="rounded-md border border-border/70 bg-background px-3 py-2">
          <div className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
            Variable
          </div>
          <div className="mt-1 text-xs font-medium text-foreground break-words">
            {variable}
          </div>
        </div>
        <div className="rounded-md border border-border/70 bg-background px-3 py-2">
          <div className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
            Prompt
          </div>
          <div className="mt-1 text-xs font-medium text-foreground break-words">
            {truncatedPrompt}
          </div>
        </div>
      </div>
    </GenericNode>
  );
});

InputNode.displayName = 'InputNode';

export default InputNode;

