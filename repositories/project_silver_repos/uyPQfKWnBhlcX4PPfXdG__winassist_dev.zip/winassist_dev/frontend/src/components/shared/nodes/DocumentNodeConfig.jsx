import React from 'react';
import { useReactFlow } from '@xyflow/react';
import { ScrollArea } from '../../ui/scrollarea';
import { cn } from '../../../lib/utils';
import { GenericOption } from '../option';
import { Input } from '../../ui/input';
import { Label } from '../../ui/label';
import { Textarea } from '../../ui/textarea';
import { setNodeData } from '../../../lib/flow';

export const DocumentNodeConfig = React.memo(({ nodeId, data, className }) => {
  const instance = useReactFlow();

  const updateNode = (updates) => {
    setNodeData(instance, nodeId, updates);
  };

  return (
    <ScrollArea>
      <div className={cn(className, 'flex flex-col gap-4 p-2')}>
        <GenericOption
          type="text"
          nodeId={nodeId}
          data={data}
          name="name"
          label="Name"
          placeholder="Enter node name"
        />
        <GenericOption
          type="text"
          nodeId={nodeId}
          data={data}
          name="label"
          label="Label"
          placeholder="Document Upload"
        />

        <div className="flex flex-col gap-2 text-sm">
          <Label>Store As (context key)</Label>
          <Input
            type="text"
            value={data?.variableName || 'uploadedDocument'}
            onChange={(event) => updateNode({ variableName: event.target.value.trim() || 'uploadedDocument' })}
            placeholder="uploadedDocument"
            className="bg-transparent w-full nodrag nowheel"
          />
        </div>

        <div className="flex flex-col gap-2 text-sm">
          <Label>Prompt Text</Label>
          <Textarea
            value={data?.prompt || ''}
            onChange={(event) => updateNode({ prompt: event.target.value })}
            placeholder="Please upload your document"
            rows={3}
            className="bg-transparent w-full nodrag nowheel"
          />
        </div>

        <div className="flex flex-col gap-2 text-sm">
          <Label>Accepted File Types</Label>
          <Input
            type="text"
            value={data?.accept || '*/*'}
            onChange={(event) => updateNode({ accept: event.target.value || '*/*' })}
            placeholder="*/* (all files) or image/*,video/*,.pdf"
            className="bg-transparent w-full nodrag nowheel"
          />
          <p className="text-xs text-muted-foreground">
            Use `*/*` for all files, or comma-separated extensions/MIME types.
          </p>
        </div>

        <div className="flex flex-col gap-2 text-sm">
          <Label>Max File Size (MB)</Label>
          <Input
            type="number"
            min="1"
            value={data?.maxSizeMb || 10}
            onChange={(event) => updateNode({ maxSizeMb: Number(event.target.value) || 10 })}
            placeholder="10"
            className="bg-transparent w-full nodrag nowheel"
          />
        </div>
      </div>
    </ScrollArea>
  );
});

DocumentNodeConfig.displayName = 'DocumentNodeConfig';
