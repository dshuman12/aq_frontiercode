import { memo } from 'react';
import { GenericNode } from '../generic-node';

const CalendarNode = memo(({ id, data, selected, width, height, ...props }) => {
  const variableName = data?.variableName || 'selectedDate';
  const prompt = data?.prompt || 'Select a date';
  const selectionType = data?.selectionType === 'datetime' ? 'Date & time' : 'Date';
  const dateOptions = Array.isArray(data?.calendarOptions)
    ? data.calendarOptions
        .map((option) => (typeof option === 'string' ? option : option?.value))
        .filter(Boolean)
    : [];

  return (
    <GenericNode
      id={id}
      data={{
        ...data,
        id: data?.id || 'calendar',
        name: data?.name || data?.label || 'Calendar',
      }}
      selected={selected}
      width={width}
      height={height}
      ports={[
        { type: 'target', name: 'input' },
        { type: 'source', name: 'output' },
      ]}
      {...props}
    >
      <div className="space-y-2">
        <div className="rounded-md border border-border/70 bg-background px-3 py-2">
          <div className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
            Selection
          </div>
          <div className="mt-1 text-xs font-medium text-foreground break-words">
            {selectionType}
          </div>
        </div>
        <div className="rounded-md border border-border/70 bg-background px-3 py-2">
          <div className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
            Variable
          </div>
          <div className="mt-1 text-xs font-medium text-foreground break-words">
            {variableName}
          </div>
        </div>
        <div className="rounded-md border border-border/70 bg-background px-3 py-2">
          <div className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
            Prompt
          </div>
          <div className="mt-1 text-xs font-medium text-foreground break-words">
            {prompt}
          </div>
        </div>
        {dateOptions.length > 0 && (
          <div className="rounded-md border border-border/70 bg-background px-3 py-2">
            <div className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
              Date Options
            </div>
            <div className="mt-1 space-y-1">
              {dateOptions.map((option, index) => (
                <div key={`${option}-${index}`} className="text-xs font-medium text-foreground break-words">
                  {option}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </GenericNode>
  );
});

CalendarNode.displayName = 'CalendarNode';

export default CalendarNode;
