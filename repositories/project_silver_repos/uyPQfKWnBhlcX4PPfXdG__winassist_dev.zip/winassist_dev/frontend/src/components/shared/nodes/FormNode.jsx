import { memo } from 'react';
import { GenericNode } from '../generic-node';

const FormNode = memo(({ id, data, selected, width, height, ...props }) => {
  const variableName = data?.variableName || 'formData';
  const prompt = data?.prompt || 'Please fill the form';
  const fields = Array.isArray(data?.fields) ? data.fields : [];

  return (
    <GenericNode
      id={id}
      data={{
        ...data,
        id: data?.id || 'form',
        name: data?.name || data?.label || 'Form',
      }}
      selected={selected}
      width={width}
      height={height}
      ports={[
        { type: 'target', name: 'input' },
        { type: 'source', name: 'output' },
      ]}
      {...props}
    >
      <div className="space-y-2">
        <div className="rounded-md border border-border/70 bg-background px-3 py-2">
          <div className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
            Prompt
          </div>
          <div className="mt-1 text-xs font-medium text-foreground break-words">
            {prompt}
          </div>
        </div>
        <div className="rounded-md border border-border/70 bg-background px-3 py-2">
          <div className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
            Store As
          </div>
          <div className="mt-1 text-xs font-medium text-foreground break-words">
            {variableName}
          </div>
        </div>
        <div className="rounded-md border border-border/70 bg-background px-3 py-2">
          <div className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
            Fields
          </div>
          <div className="mt-1 text-xs font-medium text-foreground break-words">
            {fields.length} configured
          </div>
        </div>
      </div>
    </GenericNode>
  );
});

FormNode.displayName = 'FormNode';

export default FormNode;
