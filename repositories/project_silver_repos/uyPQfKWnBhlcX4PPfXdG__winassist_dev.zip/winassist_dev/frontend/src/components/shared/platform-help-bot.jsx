import { useState } from 'react';
import { Button } from '../ui/button';
import { Icons } from '../ui/icons';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Textarea } from '../ui/textarea';
import { Badge } from '../ui/badge';
import { apiRequest } from '../../lib/api-client';

export function PlatformHelpBot() {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [messages, setMessages] = useState([]);
  const quickPrompts = [
    'How can I create AI agent?',
    'How to run retrieval test?',
    'My bot is giving wrong answers, how to fix?',
  ];

  const handleAsk = async () => {
    const trimmed = query.trim();
    if (!trimmed || isLoading) return;

    setIsLoading(true);
    try {
      const response = await apiRequest('/support-assistant/ask', {
        method: 'POST',
        body: { query: trimmed },
        showErrorToast: false,
      });
      setMessages((current) => [
        ...current,
        {
          query: trimmed,
          answer: response?.answer || 'No response available.',
          confidence: response?.confidence || 'unknown',
          intent: response?.intent || 'feature_overview',
          references: response?.references || [],
        },
      ]);
      setQuery('');
    } catch {
      setMessages((current) => [
        ...current,
        {
          query: trimmed,
          answer: 'I could not fetch a response right now. Please try again.',
          confidence: 'low',
          intent: 'error',
          references: [],
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-3">
      {isOpen ? (
        <Card className="w-[min(92vw,27rem)] border border-primary/20 bg-background/95 shadow-2xl backdrop-blur">
          <CardHeader className="border-b border-border/70 bg-gradient-to-r from-primary/10 via-primary/5 to-transparent px-4 pb-3 pt-4">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <div className="rounded-lg border border-primary/30 bg-primary/15 p-2 text-primary shadow-sm">
                  <Icons.robot className="h-4 w-4" />
                </div>
                <div>
                  <CardTitle className="text-sm font-semibold sm:text-base">WinAssist Support Bot</CardTitle>
                  <div className="mt-0.5 flex items-center gap-1.5 text-[11px] text-muted-foreground">
                    <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                    Platform assistant
                  </div>
                </div>
              </div>
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={() => setIsOpen(false)}
                aria-label="Close support chat"
              >
                <Icons.close className="h-4 w-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent className="flex h-[38rem] flex-col space-y-3 px-4 pb-4 pt-3">
            <div className="flex flex-wrap gap-2 pt-1">
              {quickPrompts.map((prompt) => (
                <button
                  key={prompt}
                  type="button"
                  className="rounded-full border border-primary/20 bg-primary/5 px-3 py-1 text-xs text-muted-foreground transition hover:bg-primary/10"
                  onClick={() => setQuery(prompt)}
                >
                  {prompt}
                </button>
              ))}
            </div>
            <div className="min-h-0 flex-1 space-y-3 overflow-y-auto rounded-xl border border-border/70 bg-muted/10 p-3">
              {messages.length === 0 ? (
                <div className="text-sm text-muted-foreground">
                  Ask about features, workflows, use cases, or troubleshooting.
                </div>
              ) : (
                messages.map((item, index) => (
                  <div key={`${item.query}-${index}`} className="space-y-2">
                    <div className="ml-auto max-w-[90%] rounded-xl border border-border/70 bg-background px-3 py-2">
                      <div className="text-[11px] font-semibold text-muted-foreground">You</div>
                      <div className="mt-1 text-sm">{item.query}</div>
                    </div>
                    <div className="max-w-[95%] rounded-xl border border-border/70 bg-background px-3 py-2">
                      <div className="text-[11px] font-semibold text-muted-foreground">WinAssist Bot</div>
                      <div className="mt-1 whitespace-pre-wrap text-sm leading-6">{item.answer}</div>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="outline" className="text-[10px]">
                        intent: {item.intent}
                      </Badge>
                      <Badge variant="outline" className="text-[10px]">
                        confidence: {item.confidence}
                      </Badge>
                    </div>
                    {(item.references || []).length > 0 ? (
                      <div className="rounded-md border border-border/70 bg-muted/20 p-2 text-xs text-muted-foreground">
                        {(item.references || []).slice(0, 2).map((reference, refIndex) => (
                          <div key={`${reference.path}-${refIndex}`}>
                            {reference.title} / {reference.section}
                          </div>
                        ))}
                      </div>
                    ) : null}
                  </div>
                ))
              )}
            </div>
            <div className="rounded-xl border border-border/80 bg-background p-2">
              <Textarea
                rows={2}
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Ask your WinAssist platform question..."
                className="min-h-[72px] resize-none border-0 bg-transparent px-2 py-2 shadow-none focus-visible:ring-0"
                onKeyDown={(event) => {
                  if (event.key === 'Enter' && !event.shiftKey) {
                    event.preventDefault();
                    handleAsk();
                  }
                }}
              />
              <div className="flex items-center justify-between border-t border-border/60 px-1 pt-2">
                <div className="text-[11px] text-muted-foreground">Enter to send, Shift+Enter for new line</div>
                <Button type="button" size="sm" onClick={handleAsk} disabled={isLoading || !query.trim()}>
                  {isLoading ? 'Thinking...' : 'Ask'}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : null}
      <Button
        type="button"
        onClick={() => setIsOpen((current) => !current)}
        className="group h-14 w-14 rounded-full border border-primary/30 bg-gradient-to-br from-primary to-primary/80 p-0 shadow-[0_10px_30px_-10px_rgba(236,72,153,0.75)] transition hover:scale-105 hover:from-primary/95 hover:to-primary/70"
        title="Ask WinAssist platform assistant"
        aria-label="Ask WinAssist platform assistant"
      >
        <Icons.robot className="h-6 w-6 text-primary-foreground" />
      </Button>
    </div>
  );
}
