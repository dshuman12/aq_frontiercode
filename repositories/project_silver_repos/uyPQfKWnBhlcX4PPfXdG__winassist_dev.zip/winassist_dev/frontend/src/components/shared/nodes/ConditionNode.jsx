
import { memo, useMemo } from 'react';
import { Position } from '@xyflow/react';
import { cn } from '../../../lib/utils';
import { DEFAULT_NODE_COLOR } from '../../../lib/flow';
import { GenericNode } from '../generic-node';

const ROW_HEIGHT = 28;
const ROW_GAP = 4;
const HEADER_HEIGHT = 40;
const CONTENT_PADDING_TOP = 10;
const CONTENT_PADDING_BOTTOM = 14;

const ConditionNode = memo(({ id, data, selected, width, height }) => {
  const { handles, computedHeight } = useMemo(() => {
    const elseIfConditions = (data?.elseIfConditions && Array.isArray(data.elseIfConditions)) ? data.elseIfConditions : [];
    const elseIfCount = elseIfConditions.length;
    const hasElse = data?.elseNode !== false;
    const ifCondition = (data?.ifCondition || '').trim();
    const totalOut = 1 + elseIfCount + (hasElse ? 1 : 0);
    const contentHeight = totalOut * ROW_HEIGHT + (totalOut - 1) * ROW_GAP;
    const totalHeight = HEADER_HEIGHT + CONTENT_PADDING_TOP + contentHeight + CONTENT_PADDING_BOTTOM;
    const truncate = (s, max = 28) => (s.length > max ? s.slice(0, max) + '…' : s);
    const outHandles = [];
    for (let i = 0; i < totalOut; i++) {
      const rowCenterY = HEADER_HEIGHT + CONTENT_PADDING_TOP + i * (ROW_HEIGHT + ROW_GAP) + ROW_HEIGHT / 2;
      const topPct = (rowCenterY / totalHeight) * 100;
      if (i === 0) {
        outHandles.push({
          type: 'source', id: 'if', position: Position.Right, style: { top: `${topPct}%` }, className: '!border-blue-500',
          label: ifCondition ? `If  ${truncate(ifCondition)}` : 'If',
        });
      } else if (hasElse && i === totalOut - 1) {
        outHandles.push({
          type: 'source', id: 'else', position: Position.Right, style: { top: `${topPct}%` }, className: '!border-blue-500',
          label: 'Else',
        });
      } else {
        const cond = elseIfConditions[i - 1]?.condition?.trim() || '';
        outHandles.push({
          type: 'source', id: `option-${i - 1}`, position: Position.Right, style: { top: `${topPct}%` }, className: '!border-blue-500',
          label: cond ? `Else if  ${truncate(cond)}` : `Else if ${i}`,
        });
      }
    }
    return {
      handles: [
        { type: 'target', id: 'input', position: Position.Left, style: { top: '50%' }, className: '!border-green-500' },
        ...outHandles,
      ],
      computedHeight: totalHeight,
    };
  }, [data?.elseIfConditions, data?.elseNode, data?.ifCondition]);

  const nodeColor = data.color || DEFAULT_NODE_COLOR;

  return (
    <GenericNode
      id={id}
      data={data}
      selected={selected}
      width={width}
      height={computedHeight}
      minWidth={180}
      minHeight={computedHeight}
      handles={handles}
      resizerColor={nodeColor}
      className={cn(
        'rounded-lg border-2 bg-background shadow-sm transition-all',
        selected && 'ring-2 ring-primary/30 shadow-md'
      )}
    />
  );
});

ConditionNode.displayName = 'ConditionNode';

export default ConditionNode;

