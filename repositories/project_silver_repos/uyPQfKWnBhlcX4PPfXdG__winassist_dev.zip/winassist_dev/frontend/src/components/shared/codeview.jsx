import { useState, useEffect, useRef, useImperativeHandle, forwardRef } from 'react';
import { generateJavaScriptCode, generateWidgetScript, downloadAsScript } from '../../utils/codeGenerator';
import { Button } from '../ui/button';
import { Icons } from '../ui/icons';
import { ScrollArea } from '../ui/scrollarea';
import { cn } from '../../lib/utils';
import { useNodes, useEdges } from '@xyflow/react';
import { toast } from '../../hooks/toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '../ui/dialog';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { apiRequest } from '../../lib/api-client';
import { copyTextToClipboard } from '../../lib/utils';
import useUserStore from '../../store/user';

const defaultWidgetSettings = {
  widgetWidth: 30,
  widgetHeight: 100,
  widgetPosition: 'bottom-right',
  widgetSpacing: 5,
  minWidth: '300px',
  backgroundColor: '#ffffff',
  headerBackgroundColor: '#2196F3',
  headerFontSize: 20,
  botMessageColor: '#2196F3',
  botMessageTextColor: '#ffffff',
  botIconBackgroundColor: '#f0f0f0',
  userMessageColor: '#e0e0e0',
  userMessageTextColor: '#333333',
  quickReplyBgColor: '#e0e0e0',
  quickReplyBorderColor: '#ddd',
  quickReplyPosition: 'left',
  botIcon: '💬',
  botIconImage: null,
  botIconWidth: 8,
  botIconHeight: 8,
  buttonIcon: '💬',
  buttonImage: null,
  textSize: 14,
  // Message bubbles
  botMessageMaxWidth: 85,
  userMessageMaxWidth: 85,
  botMessageAlign: 'left', // left | center
  userMessageAlign: 'right', // right | center | left
  messageBorderRadius: 12,
  messagePaddingVertical: 12,
  messagePaddingHorizontal: 16,
  messageGap: 16,
  messageShadow: 'none',
  botMessageBorderWidth: 0,
  botMessageBorderColor: '#00000000',
  userMessageBorderWidth: 0,
  userMessageBorderColor: '#00000000',
  // Quick reply buttons
  quickReplyBorderRadius: 8,
  quickReplyPaddingVertical: 8,
  quickReplyPaddingHorizontal: 16,
  quickReplyLayout: 'wrap', // wrap | stack
  quickReplyFullWidth: false,
  quickReplyTextColor: '#333333',
  quickReplyBorderWidth: 2,
  quickReplyFontSize: 14,
  quickReplyGap: 8,
  // Input & Send button
  inputBorderRadius: 8,
  inputBorderWidth: 2,
  inputBorderColor: '#ddd',
  sendButtonColor: '#2196F3',
  sendButtonTextColor: '#ffffff',
  sendButtonBorderRadius: 8,
  // Form node styles
  formContainerBgColor: '#ffffff',
  formContainerBorderColor: '#e5e7eb',
  formContainerBorderWidth: 1,
  formContainerBorderRadius: 10,
  formSectionGap: 8,
  formFieldGap: 6,
  formFieldLabelColor: '#374151',
  formFieldLabelSize: 12,
  formFieldInputBgColor: '#ffffff',
  formFieldInputTextColor: '#111827',
  formFieldInputBorderColor: '#d1d5db',
  formFieldInputBorderWidth: 1,
  formFieldInputBorderRadius: 8,
  formFieldInputPaddingVertical: 10,
  formFieldInputPaddingHorizontal: 10,
  formErrorTextColor: '#dc2626',
  formSubmitBgColor: '#111827',
  formSubmitTextColor: '#ffffff',
  formSubmitBorderColor: '#111827',
  formSubmitBorderWidth: 0,
  formSubmitBorderRadius: 8,
  formSubmitPaddingVertical: 10,
  formSubmitPaddingHorizontal: 14,
  // Image node styles
  imageMaxWidthPercent: 100,
  imageBorderRadius: 12,
  imageBorderColor: '#00000000',
  imageBorderWidth: 0,
  imageShadow: 'none',
  imageCaptionColor: '#374151',
  imageCaptionSize: 12,
  imageCaptionTopSpacing: 8,
  // Message formatting
  enableAutoFormatting: true,
  formattingMode: 'balanced', // minimal | balanced | aggressive
  autoListDetection: true,
  sectionHeadingDetection: true,
  normalizeEncodingArtifacts: true,
  maxConsecutiveBlankLines: 1,
  // Floating button & widget container
  toggleButtonBorderRadius: 50,
  toggleButtonSize: 60,
  widgetBorderRadius: 12,
  widgetBorder: 'none',
  widgetShadow: '-4px 0 20px rgba(0, 0, 0, 0.15)',
};

const CodeView = forwardRef(function CodeView({ nodes: propsNodes, edges: propsEdges, projectId, initialWidgetSettings, onWidgetSettingsSave }, ref) {
  const [code, setCode] = useState('');
  const [copied, setCopied] = useState(false);
  const [showWidgetSettings, setShowWidgetSettings] = useState(false);
  const [widgetSettings, setWidgetSettings] = useState({ ...defaultWidgetSettings });
  const lastSyncedSettingsRef = useRef(null);

  // Sync widget settings from saved project so each chat flow shows its own saved settings when (re)opening
  useEffect(() => {
    if (!initialWidgetSettings || typeof initialWidgetSettings !== 'object' || Object.keys(initialWidgetSettings).length === 0) return;
    const key = `${projectId}-${JSON.stringify(initialWidgetSettings)}`;
    if (lastSyncedSettingsRef.current === key) return;
    lastSyncedSettingsRef.current = key;
    setWidgetSettings((prev) => ({ ...defaultWidgetSettings, ...prev, ...initialWidgetSettings }));
  }, [projectId, initialWidgetSettings]);

  useImperativeHandle(ref, () => ({
    getWidgetSettings: () => widgetSettings,
  }), [widgetSettings]);

  // Use props if provided, otherwise fall back to hooks (for backward compatibility)
  const hookNodes = useNodes();
  const hookEdges = useEdges();
  const nodes = propsNodes || hookNodes;
  const edges = propsEdges || hookEdges;

  const handleGenerateCode = async () => {
    try {
      // Debug: Check raw nodes and edges
      undefined
      undefined
      undefined
      undefined
      undefined
      undefined
      undefined
      undefined
      undefined
      undefined
      
      // Convert ReactFlow nodes/edges to the format expected by codeGenerator
      // Match src copy's convertFromReactFlowNode - create completely flat structure
      const flowNodes = await Promise.all(nodes.map(async (node) => {
        // CRITICAL: Preserve the actual React Flow node ID (with suffix like "text_Ypzj5s")
        // This is the ID that connections reference, so it MUST be preserved
        const actualNodeId = node.id; // e.g., "text_Ypzj5s"
        
        // Debug: Log to verify IDs are correct
        if (actualNodeId !== node.data?.id) {
          undefined
        }
        
        // Create flat structure - NO data property, all properties at top level
        const flatNode = {
          id: actualNodeId, // MUST use the actual node.id, never node.data.id
          type: node.type,
          label: node.data?.label || node.data?.name || '',
        };
        
        // Spread all data properties to top level, excluding metadata keys
        // This creates a flat structure like src copy (no nested data property)
        Object.keys(node.data || {}).forEach(key => {
          // Exclude keys that would overwrite important properties or create nesting
          if (!['id', 'label', 'name', 'data', 'connections', 'class_type'].includes(key)) {
            flatNode[key] = node.data[key];
          }
        });
        
        // For assistant nodes with backend_bot_id, fetch the API key
        if (node.type === 'assistant' && flatNode.backend_bot_id) {
          try {
            undefined
            
            const project = await apiRequest(`/projects/${flatNode.backend_bot_id}`, {
              method: 'GET',
              showErrorToast: false,
            });
            
            flatNode.bot_api_key = project.api_key;
            
            if (project.api_key) {
              undefined
            } else {
              console.warn(`⚠️ No API key for backend bot ${flatNode.backend_bot_id}. Save the backend bot first!`);
              toast({
                title: 'API Key Missing',
                description: 'The backend bot has no API key. Please save the backend bot first.',
                variant: 'destructive',
              });
            }
          } catch (error) {
            console.error(`❌ Error fetching API key for bot ${flatNode.backend_bot_id}:`, error);
            toast({
              title: 'API Key Fetch Error',
              description: 'Failed to fetch backend bot API key. Check your network.',
              variant: 'destructive',
            });
          }
        }
        
        // Verify the ID is still correct after processing
        if (flatNode.id !== actualNodeId) {
          console.error(`ERROR: Node ID was overwritten! Expected: "${actualNodeId}", Got: "${flatNode.id}"`);
          flatNode.id = actualNodeId; // Force correct ID
        }
        
        return flatNode;
      }));
      
      const flowConnections = edges.map(edge => ({
        from: edge.source,
        to: edge.target,
        sourceHandle: edge.sourceHandle,
        branch: edge.data?.branch,
        isLoop: edge.data?.isLoop || false,
        loopIterations: edge.data?.loopIterations || 5,
      }));
      
      // Final verification
      undefined
      undefined
      undefined
      undefined
      undefined
      
      // CRITICAL: Verify each node's ID is correct
      flowNodes.forEach((node, index) => {
        undefined
        if (node.id && node.id.includes('_')) {
          undefined
        } else {
          console.error(`  ✗ Node has base ID (missing suffix): ${node.id}`);
        }
      });
      
      // Check for ID mismatches BEFORE calling generator
      const flowNodeIds = new Set(flowNodes.map(n => n.id));
      const connectionFromIds = new Set(flowConnections.map(c => c.from).filter(Boolean));
      const connectionToIds = new Set(flowConnections.map(c => c.to).filter(Boolean));
      const missingFromIds = [...connectionFromIds].filter(id => !flowNodeIds.has(id));
      const missingToIds = [...connectionToIds].filter(id => !flowNodeIds.has(id));
      
      if (missingFromIds.length > 0 || missingToIds.length > 0) {
        console.error('=== ID MISMATCH DETECTED BEFORE GENERATOR ===');
        console.error('Connections reference nodes that dont exist!');
        console.error('Missing "from" node IDs:', missingFromIds);
        console.error('Missing "to" node IDs:', missingToIds);
        console.error('Available node IDs:', [...flowNodeIds]);
        console.error('Connection "from" IDs:', [...connectionFromIds]);
        console.error('Connection "to" IDs:', [...connectionToIds]);
      }

      // Debug: Check mapped nodes and connections
      undefined
      undefined
      undefined
      undefined
      undefined
      
      // CRITICAL: Log the actual node objects right before passing them
      undefined
      flowNodes.forEach((node, i) => {
        undefined
      });

      // Generate complete widget script (includes flow logic + UI + integration)
      const generatedCode = generateWidgetScript(flowNodes, flowConnections, widgetSettings);
      
      undefined
      undefined
      undefined
      setCode(generatedCode);
      toast({
        title: 'Complete Bot Script Generated',
        description: 'Your bot is ready! The script includes flow logic, chat UI, and backend integration.',
      });
    } catch (error) {
      console.error('Error generating code:', error);
      toast({
        title: 'Generation Failed',
        description: 'Failed to generate code. Please check your flow.',
        variant: 'destructive',
      });
    }
  };

  const handleCopyCode = async () => {
    if (!code) return;
    try {
      await copyTextToClipboard(code);
      setCopied(true);
      toast({
        title: 'Copied',
        description: 'Code has been copied to clipboard.',
      });
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      console.error('Failed to copy:', error);
      toast({
        title: 'Copy Failed',
        description: 'Failed to copy code to clipboard.',
        variant: 'destructive',
      });
    }
  };

  const handleDownload = () => {
    if (!code) return;
    downloadAsScript(code, 'flow-script.js');
    toast({
      title: 'Downloaded',
      description: 'Code has been downloaded as flow-script.js',
    });
  };

  const handleDownloadWidget = async () => {
    try {
      // Get user_id from store
      const user = useUserStore.getState().user;
      const userId = user?.id || 'unknown';
      const projId = projectId || 'unknown';
      
      // CRITICAL: Preserve the actual React Flow node ID (with suffix like "text_Ypzj5s")
      // This is the ID that connections reference, so it MUST be preserved
      const flowNodes = await Promise.all(nodes.map(async (node) => {
        const actualNodeId = node.id; // e.g., "text_Ypzj5s"
        
        // Create flat structure - NO data property, all properties at top level
        const flatNode = {
          id: actualNodeId, // MUST use the actual node.id, never node.data.id
          type: node.type,
          label: node.data?.label || node.data?.name || '',
        };
        
        // Spread all data properties to top level, excluding metadata keys
        // This creates a flat structure like src copy (no nested data property)
        Object.keys(node.data || {}).forEach(key => {
          // Exclude keys that would overwrite important properties or create nesting
          if (!['id', 'label', 'name', 'data', 'connections', 'class_type'].includes(key)) {
            flatNode[key] = node.data[key];
          }
        });
        
        // For assistant nodes with backend_bot_id, fetch the API key
        if (node.type === 'assistant' && flatNode.backend_bot_id) {
          try {
            undefined
            
            const project = await apiRequest(`/projects/${flatNode.backend_bot_id}`, {
              method: 'GET',
              showErrorToast: false,
            });
            
            flatNode.bot_api_key = project.api_key;
            
            if (project.api_key) {
              undefined
            } else {
              console.warn(`⚠️ No API key for backend bot ${flatNode.backend_bot_id}. Save the backend bot first!`);
              toast({
                title: 'API Key Missing',
                description: 'The backend bot has no API key. Please save the backend bot first.',
                variant: 'destructive',
              });
            }
          } catch (error) {
            console.error(`❌ Error fetching API key for bot ${flatNode.backend_bot_id}:`, error);
            toast({
              title: 'API Key Fetch Error',
              description: 'Failed to fetch backend bot API key. Check your network.',
              variant: 'destructive',
            });
          }
        }
        
        // Verify the ID is still correct after processing
        if (flatNode.id !== actualNodeId) {
          console.error(`ERROR: Node ID was overwritten! Expected: "${actualNodeId}", Got: "${flatNode.id}"`);
          flatNode.id = actualNodeId; // Force correct ID
        }
        
        return flatNode;
      }));

      const flowConnections = edges.map(edge => ({
        from: edge.source,
        to: edge.target,
        sourceHandle: edge.sourceHandle,
        branch: edge.data?.branch,
        isLoop: edge.data?.isLoop || false,
        loopIterations: edge.data?.loopIterations || 5,
      }));

      const widgetScript = generateWidgetScript(flowNodes, flowConnections, widgetSettings);
      
      // Create filename with user_id and project_id
      const filename = `${userId}_${projId}_widget-script.js`;
      downloadAsScript(widgetScript, filename);
      toast({
        title: 'Widget Downloaded',
        description: `Widget script has been downloaded as ${filename}`,
      });
    } catch (error) {
      console.error('Error generating widget:', error);
      toast({
        title: 'Generation Failed',
        description: 'Failed to generate widget script.',
        variant: 'destructive',
      });
    }
  };

  const handleImportScript = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setCode(e.target.result);
        toast({
          title: 'Imported',
          description: 'Script has been imported.',
        });
      };
      reader.onerror = () => {
        toast({
          title: 'Import Failed',
          description: 'Failed to read the file.',
          variant: 'destructive',
        });
      };
      reader.readAsText(file);
    }
  };

  return (
    <div className="flex flex-col h-full w-full">
      {/* Toolbar */}
      <div className="flex items-center justify-between gap-2 p-4 border-b">
        <div className="flex items-center gap-2">
          <Button
            variant="default"
            size="sm"
            onClick={handleGenerateCode}
            className="gap-2"
          >
            <Icons.sparkles className="w-4 h-4" />
            Generate Code
          </Button>
          
          {code && (
            <>
              <Button
                variant="outline"
                size="sm"
                onClick={handleCopyCode}
                className="gap-2"
              >
                {copied ? (
                  <>
                    <Icons.check className="w-4 h-4" />
                    Copied!
                  </>
                ) : (
                  <>
                    <Icons.copy className="w-4 h-4" />
                    Copy
                  </>
                )}
              </Button>
              
              <Button
                variant="outline"
                size="sm"
                onClick={handleDownload}
                className="gap-2"
              >
                <Icons.download className="w-4 h-4" />
                Download JS
              </Button>
              
              <Button
                variant="outline"
                size="sm"
                onClick={handleDownloadWidget}
                className="gap-2"
              >
                <Icons.download className="w-4 h-4" />
                Download Widget
              </Button>
            </>
          )}
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowWidgetSettings(true)}
            className="gap-2"
          >
            <Icons.settings className="w-4 h-4" />
            Widget Settings
          </Button>
          
          <label className="cursor-pointer">
            <input
              type="file"
              accept=".js"
              onChange={handleImportScript}
              className="hidden"
            />
            <Button
              variant="outline"
              size="sm"
              asChild
              className="gap-2"
            >
              <span>
                <Icons.upload className="w-4 h-4" />
                Import
              </span>
            </Button>
          </label>
        </div>
        
        <div className="text-xs text-muted-foreground">
          Nodes: {nodes.length} | Connections: {edges.length}
        </div>
      </div>

      {/* Code Editor */}
      <ScrollArea className="flex-1">
        <div className="p-4">
          {code ? (
            <pre className="bg-muted p-4 rounded-lg overflow-x-auto text-sm font-mono">
              <code>{code}</code>
            </pre>
          ) : (
            <div className="flex flex-col items-center justify-center h-full text-center text-muted-foreground p-8">
              <Icons.code className="w-12 h-12 mb-4 opacity-50" />
              <p className="text-lg font-medium mb-2">No Code Generated</p>
              <p className="text-sm">
                Click "Generate Code" to convert your flow diagram to JavaScript
              </p>
            </div>
          )}
        </div>
      </ScrollArea>

      {/* Usage Instructions */}
      {code && (
        <div className="border-t p-4 bg-muted/50">
          <h3 className="text-sm font-semibold mb-2">Usage:</h3>
          <pre className="text-xs font-mono bg-background p-3 rounded overflow-x-auto">
{`// As a script tag:
<script src="flow-script.js"></script>
<script>
  FlowExecutor.executeFlow({ userInput: 'Hello' })
    .then(context => undefined);
</script>

// Or as ES module:
import { executeFlow } from './flow-script.js';
await executeFlow({ userInput: 'Hello' });`}
          </pre>
        </div>
      )}

      {/* Widget Settings Dialog */}
      <Dialog open={showWidgetSettings} onOpenChange={setShowWidgetSettings}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Widget UI Settings</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-6 py-4">
            {/* Widget Size */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold">Widget Size</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Widget Width (%)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.widgetWidth}
                    onChange={(e) => setWidgetSettings({...widgetSettings, widgetWidth: parseFloat(e.target.value) || 30})}
                    min="10"
                    max="100"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Widget Height (%)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.widgetHeight}
                    onChange={(e) => setWidgetSettings({...widgetSettings, widgetHeight: parseFloat(e.target.value) || 100})}
                    min="30"
                    max="100"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Widget Position</Label>
                <select
                  value={widgetSettings.widgetPosition}
                  onChange={(e) => setWidgetSettings({...widgetSettings, widgetPosition: e.target.value})}
                  className="w-full p-2 border rounded"
                >
                  <option value="bottom-right">Bottom Right</option>
                  <option value="top-right">Top Right</option>
                  <option value="bottom-left">Bottom Left</option>
                  <option value="top-left">Top Left</option>
                </select>
              </div>
              <div className="space-y-2">
                <Label>Widget Edge Spacing (px)</Label>
                <Input
                  type="number"
                  value={widgetSettings.widgetSpacing}
                  onChange={(e) => setWidgetSettings({...widgetSettings, widgetSpacing: parseFloat(e.target.value) || 5})}
                  min="0"
                  max="50"
                />
              </div>
            </div>

            {/* Colors */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold">Colors</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Background Color</Label>
                  <div className="flex gap-2">
                    <Input
                      type="color"
                      value={widgetSettings.backgroundColor}
                      onChange={(e) => setWidgetSettings({...widgetSettings, backgroundColor: e.target.value})}
                      className="w-16 h-10"
                    />
                    <Input
                      type="text"
                      value={widgetSettings.backgroundColor}
                      onChange={(e) => setWidgetSettings({...widgetSettings, backgroundColor: e.target.value})}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Header Background</Label>
                  <div className="flex gap-2">
                    <Input
                      type="color"
                      value={widgetSettings.headerBackgroundColor}
                      onChange={(e) => setWidgetSettings({...widgetSettings, headerBackgroundColor: e.target.value})}
                      className="w-16 h-10"
                    />
                    <Input
                      type="text"
                      value={widgetSettings.headerBackgroundColor}
                      onChange={(e) => setWidgetSettings({...widgetSettings, headerBackgroundColor: e.target.value})}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Bot icon background</Label>
                  <div className="flex gap-2">
                    <Input
                      type="color"
                      value={widgetSettings.botIconBackgroundColor ?? '#f0f0f0'}
                      onChange={(e) => setWidgetSettings({...widgetSettings, botIconBackgroundColor: e.target.value})}
                      className="w-16 h-10"
                    />
                    <Input
                      type="text"
                      value={widgetSettings.botIconBackgroundColor ?? '#f0f0f0'}
                      onChange={(e) => setWidgetSettings({...widgetSettings, botIconBackgroundColor: e.target.value})}
                    />
                  </div>
                  <p className="text-xs text-muted-foreground">Background of the circle behind the bot avatar</p>
                </div>
                <div className="space-y-2">
                  <Label>Bot message background</Label>
                  <div className="flex gap-2">
                    <Input
                      type="color"
                      value={widgetSettings.botMessageColor}
                      onChange={(e) => setWidgetSettings({...widgetSettings, botMessageColor: e.target.value})}
                      className="w-16 h-10"
                    />
                    <Input
                      type="text"
                      value={widgetSettings.botMessageColor}
                      onChange={(e) => setWidgetSettings({...widgetSettings, botMessageColor: e.target.value})}
                    />
                  </div>
                  <p className="text-xs text-muted-foreground">Background of the bot message bubble</p>
                </div>
                <div className="space-y-2">
                  <Label>Bot message text</Label>
                  <div className="flex gap-2">
                    <Input
                      type="color"
                      value={widgetSettings.botMessageTextColor}
                      onChange={(e) => setWidgetSettings({...widgetSettings, botMessageTextColor: e.target.value})}
                      className="w-16 h-10"
                    />
                    <Input
                      type="text"
                      value={widgetSettings.botMessageTextColor}
                      onChange={(e) => setWidgetSettings({...widgetSettings, botMessageTextColor: e.target.value})}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>User Message Color</Label>
                  <div className="flex gap-2">
                    <Input
                      type="color"
                      value={widgetSettings.userMessageColor}
                      onChange={(e) => setWidgetSettings({...widgetSettings, userMessageColor: e.target.value})}
                      className="w-16 h-10"
                    />
                    <Input
                      type="text"
                      value={widgetSettings.userMessageColor}
                      onChange={(e) => setWidgetSettings({...widgetSettings, userMessageColor: e.target.value})}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>User Message Text</Label>
                  <div className="flex gap-2">
                    <Input
                      type="color"
                      value={widgetSettings.userMessageTextColor}
                      onChange={(e) => setWidgetSettings({...widgetSettings, userMessageTextColor: e.target.value})}
                      className="w-16 h-10"
                    />
                    <Input
                      type="text"
                      value={widgetSettings.userMessageTextColor}
                      onChange={(e) => setWidgetSettings({...widgetSettings, userMessageTextColor: e.target.value})}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Icons */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold">Icons</h3>
              <div className="space-y-2">
                <Label>Bot Icon (emoji or image URL)</Label>
                <Input
                  type="text"
                  value={widgetSettings.botIconImage || widgetSettings.botIcon || ''}
                  onChange={(e) => {
                    const value = e.target.value;
                    // Check if it's a URL (http:// or https://)
                    const isUrl = value.startsWith('http://') || value.startsWith('https://');
                    if (isUrl) {
                      setWidgetSettings({...widgetSettings, botIconImage: value, botIcon: null});
                    } else {
                      setWidgetSettings({...widgetSettings, botIcon: value, botIconImage: null});
                    }
                  }}
                  placeholder="💬 or https://example.com/image.png"
                />
                {widgetSettings.botIconImage && (
                  <div className="mt-2">
                    <img 
                      src={widgetSettings.botIconImage} 
                      alt="Bot icon preview" 
                      className="w-12 h-12 object-contain border rounded"
                      onError={(e) => {
                        e.target.style.display = 'none';
                        toast({
                          title: 'Image Error',
                          description: 'Failed to load image. Please check the URL.',
                          variant: 'destructive',
                        });
                      }}
                    />
                  </div>
                )}
              </div>
              <div className="space-y-2">
                <Label>Button Icon (emoji or image URL)</Label>
                <Input
                  type="text"
                  value={widgetSettings.buttonImage || widgetSettings.buttonIcon || ''}
                  onChange={(e) => {
                    const value = e.target.value;
                    // Check if it's a URL (http:// or https://)
                    const isUrl = value.startsWith('http://') || value.startsWith('https://');
                    if (isUrl) {
                      setWidgetSettings({...widgetSettings, buttonImage: value, buttonIcon: null});
                    } else {
                      setWidgetSettings({...widgetSettings, buttonIcon: value, buttonImage: null});
                    }
                  }}
                  placeholder="💬 or https://example.com/image.png"
                />
                {widgetSettings.buttonImage && (
                  <div className="mt-2">
                    <img 
                      src={widgetSettings.buttonImage} 
                      alt="Button icon preview" 
                      className="w-12 h-12 object-contain border rounded"
                      onError={(e) => {
                        e.target.style.display = 'none';
                        toast({
                          title: 'Image Error',
                          description: 'Failed to load image. Please check the URL.',
                          variant: 'destructive',
                        });
                      }}
                    />
                  </div>
                )}
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Bot Icon Width (%)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.botIconWidth}
                    onChange={(e) => setWidgetSettings({...widgetSettings, botIconWidth: parseFloat(e.target.value) || 8})}
                    min="1"
                    max="20"
                    step="0.5"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Bot Icon Height (%)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.botIconHeight}
                    onChange={(e) => setWidgetSettings({...widgetSettings, botIconHeight: parseFloat(e.target.value) || 8})}
                    min="1"
                    max="20"
                    step="0.5"
                  />
                </div>
              </div>
            </div>

            {/* Text Settings */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold">Text Settings</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Message Text Size (px)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.textSize}
                    onChange={(e) => setWidgetSettings({...widgetSettings, textSize: parseInt(e.target.value) || 14})}
                    min="10"
                    max="24"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Header Font Size (px)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.headerFontSize}
                    onChange={(e) => setWidgetSettings({...widgetSettings, headerFontSize: parseInt(e.target.value) || 20})}
                    min="14"
                    max="28"
                  />
                </div>
              </div>
            </div>

            {/* Message Formatting */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold">Message Formatting</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Enable auto formatting</Label>
                  <select
                    className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                    value={widgetSettings.enableAutoFormatting ? 'yes' : 'no'}
                    onChange={(e) => setWidgetSettings({ ...widgetSettings, enableAutoFormatting: e.target.value === 'yes' })}
                  >
                    <option value="yes">Yes</option>
                    <option value="no">No</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <Label>Formatting mode</Label>
                  <select
                    className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                    value={widgetSettings.formattingMode ?? 'balanced'}
                    onChange={(e) => setWidgetSettings({ ...widgetSettings, formattingMode: e.target.value })}
                  >
                    <option value="minimal">Minimal</option>
                    <option value="balanced">Balanced</option>
                    <option value="aggressive">Aggressive</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <Label>Auto list detection</Label>
                  <select
                    className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                    value={widgetSettings.autoListDetection ? 'yes' : 'no'}
                    onChange={(e) => setWidgetSettings({ ...widgetSettings, autoListDetection: e.target.value === 'yes' })}
                  >
                    <option value="yes">Yes</option>
                    <option value="no">No</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <Label>Section heading detection</Label>
                  <select
                    className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                    value={widgetSettings.sectionHeadingDetection ? 'yes' : 'no'}
                    onChange={(e) => setWidgetSettings({ ...widgetSettings, sectionHeadingDetection: e.target.value === 'yes' })}
                  >
                    <option value="yes">Yes</option>
                    <option value="no">No</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <Label>Fix encoding artifacts (�)</Label>
                  <select
                    className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                    value={widgetSettings.normalizeEncodingArtifacts ? 'yes' : 'no'}
                    onChange={(e) => setWidgetSettings({ ...widgetSettings, normalizeEncodingArtifacts: e.target.value === 'yes' })}
                  >
                    <option value="yes">Yes</option>
                    <option value="no">No</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <Label>Max consecutive blank lines</Label>
                  <Input
                    type="number"
                    value={widgetSettings.maxConsecutiveBlankLines ?? 1}
                    onChange={(e) => setWidgetSettings({ ...widgetSettings, maxConsecutiveBlankLines: Math.max(0, Math.min(6, parseInt(e.target.value) || 0)) })}
                    min="0"
                    max="6"
                  />
                </div>
              </div>
              <p className="text-xs text-muted-foreground">
                Controls cleanup of bot markdown/text before rendering (lists, headings, spacing and broken characters).
              </p>
            </div>

            {/* Message bubbles */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold">Message Bubbles</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Bot message max width (%)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.botMessageMaxWidth}
                    onChange={(e) => setWidgetSettings({...widgetSettings, botMessageMaxWidth: parseInt(e.target.value) || 85})}
                    min="30"
                    max="100"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Bot message alignment</Label>
                  <select
                    className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                    value={widgetSettings.botMessageAlign ?? 'left'}
                    onChange={(e) => setWidgetSettings({ ...widgetSettings, botMessageAlign: e.target.value })}
                  >
                    <option value="left">Left</option>
                    <option value="center">Center</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <Label>User message max width (%)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.userMessageMaxWidth}
                    onChange={(e) => setWidgetSettings({...widgetSettings, userMessageMaxWidth: parseInt(e.target.value) || 85})}
                    min="30"
                    max="100"
                  />
                </div>
                <div className="space-y-2">
                  <Label>User message alignment</Label>
                  <select
                    className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                    value={widgetSettings.userMessageAlign ?? 'right'}
                    onChange={(e) => setWidgetSettings({ ...widgetSettings, userMessageAlign: e.target.value })}
                  >
                    <option value="right">Right</option>
                    <option value="center">Center</option>
                    <option value="left">Left</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <Label>Bubble border radius (px)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.messageBorderRadius}
                    onChange={(e) => setWidgetSettings({...widgetSettings, messageBorderRadius: parseInt(e.target.value) || 12})}
                    min="0"
                    max="32"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Gap between messages (px)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.messageGap}
                    onChange={(e) => setWidgetSettings({...widgetSettings, messageGap: parseInt(e.target.value) || 16})}
                    min="0"
                    max="32"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Bubble shadow (CSS box-shadow)</Label>
                  <Input
                    type="text"
                    value={widgetSettings.messageShadow ?? 'none'}
                    onChange={(e) => setWidgetSettings({ ...widgetSettings, messageShadow: e.target.value || 'none' })}
                    placeholder="none or 0 8px 24px rgba(0,0,0,0.12)"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Bubble padding vertical (px)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.messagePaddingVertical}
                    onChange={(e) => setWidgetSettings({...widgetSettings, messagePaddingVertical: parseInt(e.target.value) || 12})}
                    min="4"
                    max="32"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Bubble padding horizontal (px)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.messagePaddingHorizontal}
                    onChange={(e) => setWidgetSettings({...widgetSettings, messagePaddingHorizontal: parseInt(e.target.value) || 16})}
                    min="4"
                    max="32"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Bot bubble border width (px)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.botMessageBorderWidth ?? 0}
                    onChange={(e) => setWidgetSettings({ ...widgetSettings, botMessageBorderWidth: parseInt(e.target.value) || 0 })}
                    min="0"
                    max="8"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Bot bubble border color</Label>
                  <div className="flex gap-2">
                    <Input
                      type="color"
                      value={widgetSettings.botMessageBorderColor ?? '#00000000'}
                      onChange={(e) => setWidgetSettings({ ...widgetSettings, botMessageBorderColor: e.target.value })}
                      className="w-16 h-10"
                    />
                    <Input
                      type="text"
                      value={widgetSettings.botMessageBorderColor ?? '#00000000'}
                      onChange={(e) => setWidgetSettings({ ...widgetSettings, botMessageBorderColor: e.target.value })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>User bubble border width (px)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.userMessageBorderWidth ?? 0}
                    onChange={(e) => setWidgetSettings({ ...widgetSettings, userMessageBorderWidth: parseInt(e.target.value) || 0 })}
                    min="0"
                    max="8"
                  />
                </div>
                <div className="space-y-2">
                  <Label>User bubble border color</Label>
                  <div className="flex gap-2">
                    <Input
                      type="color"
                      value={widgetSettings.userMessageBorderColor ?? '#00000000'}
                      onChange={(e) => setWidgetSettings({ ...widgetSettings, userMessageBorderColor: e.target.value })}
                      className="w-16 h-10"
                    />
                    <Input
                      type="text"
                      value={widgetSettings.userMessageBorderColor ?? '#00000000'}
                      onChange={(e) => setWidgetSettings({ ...widgetSettings, userMessageBorderColor: e.target.value })}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Quick reply buttons */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold">Quick Reply Buttons</h3>
              <div className="space-y-2">
                <Label>Buttons position</Label>
                <select
                  className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                  value={widgetSettings.quickReplyPosition ?? 'left'}
                  onChange={(e) => setWidgetSettings({...widgetSettings, quickReplyPosition: e.target.value})}
                >
                  <option value="left">Left</option>
                  <option value="center">Center</option>
                  <option value="right">Right</option>
                </select>
                <p className="text-xs text-muted-foreground">Horizontal alignment of quick reply buttons</p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Border radius (px)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.quickReplyBorderRadius}
                    onChange={(e) => setWidgetSettings({...widgetSettings, quickReplyBorderRadius: parseInt(e.target.value) || 8})}
                    min="0"
                    max="24"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Padding vertical (px)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.quickReplyPaddingVertical}
                    onChange={(e) => setWidgetSettings({...widgetSettings, quickReplyPaddingVertical: parseInt(e.target.value) || 8})}
                    min="2"
                    max="24"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Padding horizontal (px)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.quickReplyPaddingHorizontal}
                    onChange={(e) => setWidgetSettings({...widgetSettings, quickReplyPaddingHorizontal: parseInt(e.target.value) || 16})}
                    min="2"
                    max="32"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Layout</Label>
                  <select
                    className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                    value={widgetSettings.quickReplyLayout ?? 'wrap'}
                    onChange={(e) => setWidgetSettings({ ...widgetSettings, quickReplyLayout: e.target.value })}
                  >
                    <option value="wrap">Wrap</option>
                    <option value="stack">Stack (vertical)</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <Label>Full width buttons</Label>
                  <select
                    className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                    value={widgetSettings.quickReplyFullWidth ? 'yes' : 'no'}
                    onChange={(e) => setWidgetSettings({ ...widgetSettings, quickReplyFullWidth: e.target.value === 'yes' })}
                  >
                    <option value="no">No</option>
                    <option value="yes">Yes</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <Label>Text color</Label>
                  <div className="flex gap-2">
                    <Input
                      type="color"
                      value={widgetSettings.quickReplyTextColor ?? '#333333'}
                      onChange={(e) => setWidgetSettings({ ...widgetSettings, quickReplyTextColor: e.target.value })}
                      className="w-16 h-10"
                    />
                    <Input
                      type="text"
                      value={widgetSettings.quickReplyTextColor ?? '#333333'}
                      onChange={(e) => setWidgetSettings({ ...widgetSettings, quickReplyTextColor: e.target.value })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Border width (px)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.quickReplyBorderWidth ?? 2}
                    onChange={(e) => setWidgetSettings({ ...widgetSettings, quickReplyBorderWidth: parseInt(e.target.value) || 2 })}
                    min="0"
                    max="8"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Font size (px)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.quickReplyFontSize ?? 14}
                    onChange={(e) => setWidgetSettings({ ...widgetSettings, quickReplyFontSize: parseInt(e.target.value) || 14 })}
                    min="10"
                    max="22"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Gap (px)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.quickReplyGap ?? 8}
                    onChange={(e) => setWidgetSettings({ ...widgetSettings, quickReplyGap: parseInt(e.target.value) || 8 })}
                    min="0"
                    max="24"
                  />
                </div>
              </div>
            </div>

            {/* Input & Send button */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold">Input & Send Button</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Input border radius (px)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.inputBorderRadius}
                    onChange={(e) => setWidgetSettings({...widgetSettings, inputBorderRadius: parseInt(e.target.value) || 8})}
                    min="0"
                    max="24"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Input border width (px)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.inputBorderWidth}
                    onChange={(e) => setWidgetSettings({...widgetSettings, inputBorderWidth: parseInt(e.target.value) || 2})}
                    min="0"
                    max="8"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Input border color</Label>
                  <div className="flex gap-2">
                    <Input
                      type="color"
                      value={widgetSettings.inputBorderColor}
                      onChange={(e) => setWidgetSettings({...widgetSettings, inputBorderColor: e.target.value})}
                      className="w-16 h-10"
                    />
                    <Input
                      type="text"
                      value={widgetSettings.inputBorderColor}
                      onChange={(e) => setWidgetSettings({...widgetSettings, inputBorderColor: e.target.value})}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Send button border radius (px)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.sendButtonBorderRadius}
                    onChange={(e) => setWidgetSettings({...widgetSettings, sendButtonBorderRadius: parseInt(e.target.value) || 8})}
                    min="0"
                    max="24"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Send button color</Label>
                  <div className="flex gap-2">
                    <Input
                      type="color"
                      value={widgetSettings.sendButtonColor}
                      onChange={(e) => setWidgetSettings({...widgetSettings, sendButtonColor: e.target.value})}
                      className="w-16 h-10"
                    />
                    <Input
                      type="text"
                      value={widgetSettings.sendButtonColor}
                      onChange={(e) => setWidgetSettings({...widgetSettings, sendButtonColor: e.target.value})}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Send button text color</Label>
                  <div className="flex gap-2">
                    <Input
                      type="color"
                      value={widgetSettings.sendButtonTextColor}
                      onChange={(e) => setWidgetSettings({...widgetSettings, sendButtonTextColor: e.target.value})}
                      className="w-16 h-10"
                    />
                    <Input
                      type="text"
                      value={widgetSettings.sendButtonTextColor}
                      onChange={(e) => setWidgetSettings({...widgetSettings, sendButtonTextColor: e.target.value})}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Form node styles */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold">Form Node Styles</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Form container background</Label>
                  <div className="flex gap-2">
                    <Input
                      type="color"
                      value={widgetSettings.formContainerBgColor}
                      onChange={(e) => setWidgetSettings({ ...widgetSettings, formContainerBgColor: e.target.value })}
                      className="w-16 h-10"
                    />
                    <Input
                      type="text"
                      value={widgetSettings.formContainerBgColor}
                      onChange={(e) => setWidgetSettings({ ...widgetSettings, formContainerBgColor: e.target.value })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Form container border color</Label>
                  <div className="flex gap-2">
                    <Input
                      type="color"
                      value={widgetSettings.formContainerBorderColor}
                      onChange={(e) => setWidgetSettings({ ...widgetSettings, formContainerBorderColor: e.target.value })}
                      className="w-16 h-10"
                    />
                    <Input
                      type="text"
                      value={widgetSettings.formContainerBorderColor}
                      onChange={(e) => setWidgetSettings({ ...widgetSettings, formContainerBorderColor: e.target.value })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Form container border width (px)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.formContainerBorderWidth}
                    onChange={(e) => setWidgetSettings({ ...widgetSettings, formContainerBorderWidth: parseInt(e.target.value) || 0 })}
                    min="0"
                    max="8"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Form container radius (px)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.formContainerBorderRadius}
                    onChange={(e) => setWidgetSettings({ ...widgetSettings, formContainerBorderRadius: parseInt(e.target.value) || 0 })}
                    min="0"
                    max="24"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Form section gap (px)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.formSectionGap}
                    onChange={(e) => setWidgetSettings({ ...widgetSettings, formSectionGap: parseInt(e.target.value) || 0 })}
                    min="0"
                    max="24"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Field gap (px)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.formFieldGap}
                    onChange={(e) => setWidgetSettings({ ...widgetSettings, formFieldGap: parseInt(e.target.value) || 0 })}
                    min="0"
                    max="16"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Label color</Label>
                  <div className="flex gap-2">
                    <Input
                      type="color"
                      value={widgetSettings.formFieldLabelColor}
                      onChange={(e) => setWidgetSettings({ ...widgetSettings, formFieldLabelColor: e.target.value })}
                      className="w-16 h-10"
                    />
                    <Input
                      type="text"
                      value={widgetSettings.formFieldLabelColor}
                      onChange={(e) => setWidgetSettings({ ...widgetSettings, formFieldLabelColor: e.target.value })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Label size (px)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.formFieldLabelSize}
                    onChange={(e) => setWidgetSettings({ ...widgetSettings, formFieldLabelSize: parseInt(e.target.value) || 12 })}
                    min="10"
                    max="20"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Input background</Label>
                  <div className="flex gap-2">
                    <Input
                      type="color"
                      value={widgetSettings.formFieldInputBgColor}
                      onChange={(e) => setWidgetSettings({ ...widgetSettings, formFieldInputBgColor: e.target.value })}
                      className="w-16 h-10"
                    />
                    <Input
                      type="text"
                      value={widgetSettings.formFieldInputBgColor}
                      onChange={(e) => setWidgetSettings({ ...widgetSettings, formFieldInputBgColor: e.target.value })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Input text color</Label>
                  <div className="flex gap-2">
                    <Input
                      type="color"
                      value={widgetSettings.formFieldInputTextColor}
                      onChange={(e) => setWidgetSettings({ ...widgetSettings, formFieldInputTextColor: e.target.value })}
                      className="w-16 h-10"
                    />
                    <Input
                      type="text"
                      value={widgetSettings.formFieldInputTextColor}
                      onChange={(e) => setWidgetSettings({ ...widgetSettings, formFieldInputTextColor: e.target.value })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Input border color</Label>
                  <div className="flex gap-2">
                    <Input
                      type="color"
                      value={widgetSettings.formFieldInputBorderColor}
                      onChange={(e) => setWidgetSettings({ ...widgetSettings, formFieldInputBorderColor: e.target.value })}
                      className="w-16 h-10"
                    />
                    <Input
                      type="text"
                      value={widgetSettings.formFieldInputBorderColor}
                      onChange={(e) => setWidgetSettings({ ...widgetSettings, formFieldInputBorderColor: e.target.value })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Input border width (px)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.formFieldInputBorderWidth}
                    onChange={(e) => setWidgetSettings({ ...widgetSettings, formFieldInputBorderWidth: parseInt(e.target.value) || 0 })}
                    min="0"
                    max="8"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Input border radius (px)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.formFieldInputBorderRadius}
                    onChange={(e) => setWidgetSettings({ ...widgetSettings, formFieldInputBorderRadius: parseInt(e.target.value) || 0 })}
                    min="0"
                    max="20"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Input padding vertical (px)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.formFieldInputPaddingVertical}
                    onChange={(e) => setWidgetSettings({ ...widgetSettings, formFieldInputPaddingVertical: parseInt(e.target.value) || 0 })}
                    min="2"
                    max="24"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Input padding horizontal (px)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.formFieldInputPaddingHorizontal}
                    onChange={(e) => setWidgetSettings({ ...widgetSettings, formFieldInputPaddingHorizontal: parseInt(e.target.value) || 0 })}
                    min="2"
                    max="24"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Error text color</Label>
                  <div className="flex gap-2">
                    <Input
                      type="color"
                      value={widgetSettings.formErrorTextColor}
                      onChange={(e) => setWidgetSettings({ ...widgetSettings, formErrorTextColor: e.target.value })}
                      className="w-16 h-10"
                    />
                    <Input
                      type="text"
                      value={widgetSettings.formErrorTextColor}
                      onChange={(e) => setWidgetSettings({ ...widgetSettings, formErrorTextColor: e.target.value })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Submit background</Label>
                  <div className="flex gap-2">
                    <Input
                      type="color"
                      value={widgetSettings.formSubmitBgColor}
                      onChange={(e) => setWidgetSettings({ ...widgetSettings, formSubmitBgColor: e.target.value })}
                      className="w-16 h-10"
                    />
                    <Input
                      type="text"
                      value={widgetSettings.formSubmitBgColor}
                      onChange={(e) => setWidgetSettings({ ...widgetSettings, formSubmitBgColor: e.target.value })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Submit text color</Label>
                  <div className="flex gap-2">
                    <Input
                      type="color"
                      value={widgetSettings.formSubmitTextColor}
                      onChange={(e) => setWidgetSettings({ ...widgetSettings, formSubmitTextColor: e.target.value })}
                      className="w-16 h-10"
                    />
                    <Input
                      type="text"
                      value={widgetSettings.formSubmitTextColor}
                      onChange={(e) => setWidgetSettings({ ...widgetSettings, formSubmitTextColor: e.target.value })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Submit border color</Label>
                  <div className="flex gap-2">
                    <Input
                      type="color"
                      value={widgetSettings.formSubmitBorderColor}
                      onChange={(e) => setWidgetSettings({ ...widgetSettings, formSubmitBorderColor: e.target.value })}
                      className="w-16 h-10"
                    />
                    <Input
                      type="text"
                      value={widgetSettings.formSubmitBorderColor}
                      onChange={(e) => setWidgetSettings({ ...widgetSettings, formSubmitBorderColor: e.target.value })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Submit border width (px)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.formSubmitBorderWidth}
                    onChange={(e) => setWidgetSettings({ ...widgetSettings, formSubmitBorderWidth: parseInt(e.target.value) || 0 })}
                    min="0"
                    max="8"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Submit border radius (px)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.formSubmitBorderRadius}
                    onChange={(e) => setWidgetSettings({ ...widgetSettings, formSubmitBorderRadius: parseInt(e.target.value) || 0 })}
                    min="0"
                    max="20"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Submit padding vertical (px)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.formSubmitPaddingVertical}
                    onChange={(e) => setWidgetSettings({ ...widgetSettings, formSubmitPaddingVertical: parseInt(e.target.value) || 0 })}
                    min="2"
                    max="24"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Submit padding horizontal (px)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.formSubmitPaddingHorizontal}
                    onChange={(e) => setWidgetSettings({ ...widgetSettings, formSubmitPaddingHorizontal: parseInt(e.target.value) || 0 })}
                    min="2"
                    max="32"
                  />
                </div>
              </div>
            </div>

            {/* Image node styles */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold">Image Node Styles</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Image max width (%)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.imageMaxWidthPercent}
                    onChange={(e) => setWidgetSettings({ ...widgetSettings, imageMaxWidthPercent: parseInt(e.target.value) || 100 })}
                    min="20"
                    max="100"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Image border radius (px)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.imageBorderRadius}
                    onChange={(e) => setWidgetSettings({ ...widgetSettings, imageBorderRadius: parseInt(e.target.value) || 0 })}
                    min="0"
                    max="32"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Image border color</Label>
                  <div className="flex gap-2">
                    <Input
                      type="color"
                      value={widgetSettings.imageBorderColor}
                      onChange={(e) => setWidgetSettings({ ...widgetSettings, imageBorderColor: e.target.value })}
                      className="w-16 h-10"
                    />
                    <Input
                      type="text"
                      value={widgetSettings.imageBorderColor}
                      onChange={(e) => setWidgetSettings({ ...widgetSettings, imageBorderColor: e.target.value })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Image border width (px)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.imageBorderWidth}
                    onChange={(e) => setWidgetSettings({ ...widgetSettings, imageBorderWidth: parseInt(e.target.value) || 0 })}
                    min="0"
                    max="8"
                  />
                </div>
                <div className="space-y-2 col-span-2">
                  <Label>Image shadow (CSS box-shadow)</Label>
                  <Input
                    type="text"
                    value={widgetSettings.imageShadow}
                    onChange={(e) => setWidgetSettings({ ...widgetSettings, imageShadow: e.target.value || 'none' })}
                    placeholder="none or 0 8px 24px rgba(0,0,0,0.15)"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Caption color</Label>
                  <div className="flex gap-2">
                    <Input
                      type="color"
                      value={widgetSettings.imageCaptionColor}
                      onChange={(e) => setWidgetSettings({ ...widgetSettings, imageCaptionColor: e.target.value })}
                      className="w-16 h-10"
                    />
                    <Input
                      type="text"
                      value={widgetSettings.imageCaptionColor}
                      onChange={(e) => setWidgetSettings({ ...widgetSettings, imageCaptionColor: e.target.value })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Caption size (px)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.imageCaptionSize}
                    onChange={(e) => setWidgetSettings({ ...widgetSettings, imageCaptionSize: parseInt(e.target.value) || 12 })}
                    min="10"
                    max="24"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Caption top spacing (px)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.imageCaptionTopSpacing}
                    onChange={(e) => setWidgetSettings({ ...widgetSettings, imageCaptionTopSpacing: parseInt(e.target.value) || 8 })}
                    min="0"
                    max="24"
                  />
                </div>
              </div>
            </div>

            {/* Floating button & widget container */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold">Floating Button & Widget Container</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Floating button size (px)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.toggleButtonSize}
                    onChange={(e) => setWidgetSettings({...widgetSettings, toggleButtonSize: parseInt(e.target.value) || 60})}
                    min="40"
                    max="100"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Floating button shape (%) — 50 = circle</Label>
                  <Input
                    type="number"
                    value={widgetSettings.toggleButtonBorderRadius}
                    onChange={(e) => setWidgetSettings({...widgetSettings, toggleButtonBorderRadius: parseInt(e.target.value) || 50})}
                    min="0"
                    max="50"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Widget container border radius (px)</Label>
                  <Input
                    type="number"
                    value={widgetSettings.widgetBorderRadius}
                    onChange={(e) => setWidgetSettings({...widgetSettings, widgetBorderRadius: parseInt(e.target.value) || 12})}
                    min="0"
                    max="32"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Widget border (e.g. 1px solid #e0e0e0)</Label>
                  <Input
                    type="text"
                    value={widgetSettings.widgetBorder}
                    onChange={(e) => setWidgetSettings({...widgetSettings, widgetBorder: e.target.value || 'none'})}
                    placeholder="none or 1px solid #e0e0e0"
                  />
                </div>
                <div className="space-y-2 col-span-2">
                  <Label>Widget shadow (CSS box-shadow)</Label>
                  <Input
                    type="text"
                    value={widgetSettings.widgetShadow}
                    onChange={(e) => setWidgetSettings({...widgetSettings, widgetShadow: e.target.value || 'none'})}
                    placeholder="-4px 0 20px rgba(0,0,0,0.15)"
                  />
                </div>
                <div className="space-y-2 col-span-2">
                  <Label>Widget min width (e.g. 300px)</Label>
                  <Input
                    type="text"
                    value={widgetSettings.minWidth}
                    onChange={(e) => setWidgetSettings({...widgetSettings, minWidth: e.target.value || '300px'})}
                    placeholder="300px"
                  />
                </div>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowWidgetSettings(false)}>
              Cancel
            </Button>
            <Button
              onClick={() => {
                if (typeof onWidgetSettingsSave === 'function') {
                  onWidgetSettingsSave(widgetSettings);
                }
                setShowWidgetSettings(false);
              }}
            >
              Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
});

export default CodeView;

