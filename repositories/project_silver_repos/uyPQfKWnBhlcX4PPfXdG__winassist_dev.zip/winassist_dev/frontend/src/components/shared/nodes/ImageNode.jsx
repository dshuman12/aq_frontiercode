import { memo } from 'react'
import { GenericNode } from '../generic-node'

const ImageNode = memo(({ id, data, selected, width, height, ...props }) => {
  const imageUrl = data?.imageUrl || data?.url || data?.image || ''
  const preview = imageUrl
    ? imageUrl.length > 40
      ? imageUrl.substring(0, 40) + '...'
      : imageUrl
    : 'No image URL'

  return (
    <GenericNode
      id={id}
      data={{
        ...data,
        id: data?.id || 'image',
        name: data?.name || data?.label || 'Image',
      }}
      selected={selected}
      width={width}
      height={height}
      ports={[
        { type: 'target', name: 'input' },
        { type: 'source', name: 'output' },
      ]}
      {...props}
    >
      <div className="rounded-md border border-border/70 bg-background px-3 py-2">
        <div className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
          Image
        </div>
        <div className="mt-1 text-xs font-medium text-foreground break-words">{preview}</div>
      </div>
    </GenericNode>
  )
})

ImageNode.displayName = 'ImageNode'

export default ImageNode

