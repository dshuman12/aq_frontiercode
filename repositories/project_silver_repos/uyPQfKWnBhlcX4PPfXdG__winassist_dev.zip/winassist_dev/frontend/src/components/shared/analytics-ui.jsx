/* eslint-disable react-refresh/only-export-components */
import { Area, AreaChart, ResponsiveContainer } from 'recharts';

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Icons } from '../ui/icons';
import { cn } from '../../lib/utils';

export const analyticsCardClass =
  'rounded-2xl border border-border/70 bg-background shadow-[0_10px_30px_-18px_rgba(15,23,42,0.28)] transition-all duration-200 hover:-translate-y-0.5 hover:border-primary/20 hover:shadow-[0_18px_40px_-24px_rgba(15,23,42,0.35)]';

const TONE_MAP = {
  blue: {
    iconWrap: 'bg-blue-500/10 text-blue-700 dark:bg-blue-500/15 dark:text-blue-300',
    iconText: 'text-blue-700 dark:text-blue-300',
    badge: 'border-blue-200 bg-blue-50 text-blue-700 dark:border-blue-900/70 dark:bg-blue-950/40 dark:text-blue-300',
    progress: 'bg-blue-500',
    subtle: 'bg-blue-500/8 dark:bg-blue-500/12',
    chart: 'hsl(var(--chart-1))',
  },
  violet: {
    iconWrap: 'bg-violet-500/10 text-violet-700 dark:bg-violet-500/15 dark:text-violet-300',
    iconText: 'text-violet-700 dark:text-violet-300',
    badge: 'border-violet-200 bg-violet-50 text-violet-700 dark:border-violet-900/70 dark:bg-violet-950/40 dark:text-violet-300',
    progress: 'bg-violet-500',
    subtle: 'bg-violet-500/8 dark:bg-violet-500/12',
    chart: 'hsl(var(--chart-4))',
  },
  emerald: {
    iconWrap: 'bg-emerald-500/10 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300',
    iconText: 'text-emerald-700 dark:text-emerald-300',
    badge: 'border-emerald-200 bg-emerald-50 text-emerald-700 dark:border-emerald-900/70 dark:bg-emerald-950/40 dark:text-emerald-300',
    progress: 'bg-emerald-500',
    subtle: 'bg-emerald-500/8 dark:bg-emerald-500/12',
    chart: 'hsl(var(--chart-2))',
  },
  amber: {
    iconWrap: 'bg-amber-500/10 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300',
    iconText: 'text-amber-700 dark:text-amber-300',
    badge: 'border-amber-200 bg-amber-50 text-amber-700 dark:border-amber-900/70 dark:bg-amber-950/40 dark:text-amber-300',
    progress: 'bg-amber-500',
    subtle: 'bg-amber-500/8 dark:bg-amber-500/12',
    chart: 'hsl(var(--chart-3))',
  },
  rose: {
    iconWrap: 'bg-rose-500/10 text-rose-700 dark:bg-rose-500/15 dark:text-rose-300',
    iconText: 'text-rose-700 dark:text-rose-300',
    badge: 'border-rose-200 bg-rose-50 text-rose-700 dark:border-rose-900/70 dark:bg-rose-950/40 dark:text-rose-300',
    progress: 'bg-rose-500',
    subtle: 'bg-rose-500/8 dark:bg-rose-500/12',
    chart: 'hsl(var(--chart-5))',
  },
  cyan: {
    iconWrap: 'bg-cyan-500/10 text-cyan-700 dark:bg-cyan-500/15 dark:text-cyan-300',
    iconText: 'text-cyan-700 dark:text-cyan-300',
    badge: 'border-cyan-200 bg-cyan-50 text-cyan-700 dark:border-cyan-900/70 dark:bg-cyan-950/40 dark:text-cyan-300',
    progress: 'bg-cyan-500',
    subtle: 'bg-cyan-500/8 dark:bg-cyan-500/12',
    chart: 'hsl(var(--chart-2))',
  },
  slate: {
    iconWrap: 'bg-slate-500/10 text-slate-700 dark:bg-slate-500/15 dark:text-slate-300',
    iconText: 'text-slate-700 dark:text-slate-300',
    badge: 'border-slate-200 bg-slate-50 text-slate-700 dark:border-slate-800 dark:bg-slate-900/60 dark:text-slate-300',
    progress: 'bg-slate-500',
    subtle: 'bg-slate-500/8 dark:bg-slate-500/12',
    chart: 'hsl(var(--muted-foreground))',
  },
};

function getTone(tone) {
  return TONE_MAP[tone] || TONE_MAP.blue;
}

export function formatCompactNumber(value) {
  const number = Number(value || 0);
  return new Intl.NumberFormat('en', {
    notation: number >= 1000 ? 'compact' : 'standard',
    maximumFractionDigits: 1,
  }).format(number);
}

export function formatPercentDelta(value) {
  const numeric = Number(value || 0);
  const prefix = numeric > 0 ? '+' : '';
  return `${prefix}${numeric}%`;
}

export function buildSimpleSparkline(...values) {
  return values
    .filter((value) => Number.isFinite(Number(value)))
    .map((value, index) => ({
      index: index + 1,
      value: Number(value),
    }));
}

export function getUsageScore(messages = 0, sessions = 0) {
  return Math.round(Number(messages || 0) + Number(sessions || 0) * 4);
}

export function compareTrailingWindows(points, getValue) {
  if (!Array.isArray(points) || points.length < 2) return null;
  const midpoint = Math.floor(points.length / 2);
  const previous = points.slice(0, midpoint);
  const current = points.slice(midpoint);
  const previousSum = previous.reduce((sum, item) => sum + Number(getValue(item) || 0), 0);
  const currentSum = current.reduce((sum, item) => sum + Number(getValue(item) || 0), 0);
  if (previousSum === 0) {
    return currentSum > 0 ? 100 : 0;
  }
  return Math.round(((currentSum - previousSum) / previousSum) * 100);
}

export function ProgressBar({ value = 0, tone = 'blue', className }) {
  const theme = getTone(tone);
  const width = Math.min(100, Math.max(0, Number(value || 0)));

  return (
    <div className={cn('h-2.5 w-full overflow-hidden rounded-full bg-muted', className)}>
      <div className={cn('h-full rounded-full transition-all', theme.progress)} style={{ width: `${width}%` }} />
    </div>
  );
}

export function MiniSparkline({ data, dataKey = 'value', color = '#2563eb', height = 56, className }) {
  if (!Array.isArray(data) || data.length === 0) {
    return <div className={cn('h-14 rounded-xl bg-muted/60', className)} />;
  }

  const gradientId = `spark-${String(color).replace(/[^a-zA-Z0-9_-]/g, '') || 'default'}`;

  return (
    <div className={cn('h-14 w-full', className)}>
      <ResponsiveContainer width="100%" height={height}>
        <AreaChart data={data} margin={{ top: 6, right: 0, left: 0, bottom: 0 }}>
          <defs>
            <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={color} stopOpacity={0.28} />
              <stop offset="100%" stopColor={color} stopOpacity={0} />
            </linearGradient>
          </defs>
          <Area
            type="monotone"
            dataKey={dataKey}
            stroke={color}
            strokeWidth={2}
            fill={`url(#${gradientId})`}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

export function AnalyticsSection({ eyebrow, title, description, action, children, className }) {
  return (
    <section className={cn('space-y-5 border-t border-border/70 pt-8 first:border-t-0 first:pt-0', className)}>
      <div className="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
        <div className="space-y-2">
          {eyebrow ? (
            <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
              {eyebrow}
            </div>
          ) : null}
          <div>
            <h2 className="text-2xl font-semibold tracking-tight text-foreground">{title}</h2>
            {description ? (
              <p className="mt-1 max-w-3xl text-sm leading-6 text-muted-foreground">{description}</p>
            ) : null}
          </div>
        </div>
        {action ? <div className="shrink-0">{action}</div> : null}
      </div>
      {children}
    </section>
  );
}

export function MetricCard({
  icon: Icon = Icons.circleGauge,
  label,
  value,
  description,
  comparison,
  trend,
  tone = 'blue',
}) {
  const theme = getTone(tone);
  const trendPositive = Number(trend || 0) >= 0;

  return (
    <Card className={analyticsCardClass}>
      <CardHeader className="space-y-4 p-5 pb-3">
        <div className="flex items-start justify-between gap-3">
          <div className="space-y-1">
            <CardDescription className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
              {label}
            </CardDescription>
            <CardTitle className="text-3xl font-semibold tracking-tight text-foreground">{value}</CardTitle>
          </div>
          <div className={cn('flex h-11 w-11 items-center justify-center rounded-xl', theme.iconWrap)}>
            <Icon className="h-5 w-5" />
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3 p-5 pt-0">
        <div className="flex flex-wrap items-center gap-2">
          {trend != null ? (
            <Badge className={cn('rounded-full border px-2.5 py-1 text-[11px] font-semibold', theme.badge)}>
              <span className="mr-1">{trendPositive ? '↑' : '↓'}</span>
              {formatPercentDelta(trend)}
            </Badge>
          ) : null}
          {comparison ? <span className="text-xs text-muted-foreground">{comparison}</span> : null}
        </div>
        {description ? <p className="text-sm leading-6 text-muted-foreground">{description}</p> : null}
      </CardContent>
    </Card>
  );
}

export function ChartPanel({ title, description, action, children, className, contentClassName }) {
  return (
    <Card className={cn(analyticsCardClass, className)}>
      <CardHeader className="space-y-2 p-5 pb-3">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
          <div className="space-y-1">
            <CardTitle className="text-lg font-semibold">{title}</CardTitle>
            {description ? <CardDescription className="leading-6">{description}</CardDescription> : null}
          </div>
          {action ? <div className="shrink-0">{action}</div> : null}
        </div>
      </CardHeader>
      <CardContent className={cn('p-5 pt-0', contentClassName)}>{children}</CardContent>
    </Card>
  );
}

export function QuickInsightCard({ title, value, caption, icon: Icon = Icons.circleGauge, tone = 'blue' }) {
  const theme = getTone(tone);

  return (
    <div className={cn('rounded-2xl border border-border/70 p-4', theme.subtle)}>
      <div className="flex items-start justify-between gap-3">
        <div className="space-y-1">
          <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">{title}</div>
          <div className="text-xl font-semibold tracking-tight text-foreground">{value}</div>
          <p className="text-sm leading-6 text-muted-foreground">{caption}</p>
        </div>
        <Icon className={cn('h-5 w-5 shrink-0', theme.iconText)} />
      </div>
    </div>
  );
}

export function TopProjectCard({
  title,
  description,
  project,
  tone = 'blue',
  onOpen,
  buttonLabel = 'Open project',
}) {
  const theme = getTone(tone);
  const messages = Number(project?.message_count || project?.total_message_count || project?.total_messages || 0);
  const sessions = Number(project?.chat_count || project?.total_chats || 0);
  const usageScore = getUsageScore(messages, sessions);
  const progressValue = usageScore > 0 ? Math.min(100, Math.max(16, usageScore / 10)) : 0;
  const sparkline = buildSimpleSparkline(
    Math.max(1, Math.round(messages * 0.35)),
    Math.max(1, Math.round(messages * 0.58)),
    Math.max(1, Math.round(messages * 0.8)),
    Math.max(1, messages),
  );

  return (
    <Card className={analyticsCardClass}>
      <CardHeader className="space-y-4 p-5 pb-3">
        <div className="flex items-start justify-between gap-3">
          <div className="space-y-1">
            <CardDescription className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
              {title}
            </CardDescription>
            <CardTitle className="text-xl font-semibold leading-7">{project?.project_name || project?.name || 'No project yet'}</CardTitle>
            {description ? <CardDescription className="leading-6">{description}</CardDescription> : null}
          </div>
          <Badge className={cn('rounded-full border px-2.5 py-1 text-[11px] font-semibold', theme.badge)}>
            Rank #1
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4 p-5 pt-0">
        <div className="grid grid-cols-3 gap-3">
          <div className="rounded-2xl bg-muted/50 p-3">
            <div className="text-xs text-muted-foreground">Usage score</div>
            <div className="mt-1 text-lg font-semibold">{formatCompactNumber(usageScore)}</div>
          </div>
          <div className="rounded-2xl bg-muted/50 p-3">
            <div className="text-xs text-muted-foreground">Sessions</div>
            <div className="mt-1 text-lg font-semibold">{formatCompactNumber(sessions)}</div>
          </div>
          <div className="rounded-2xl bg-muted/50 p-3">
            <div className="text-xs text-muted-foreground">Messages</div>
            <div className="mt-1 text-lg font-semibold">{formatCompactNumber(messages)}</div>
          </div>
        </div>
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>Usage share</span>
            <span>{progressValue}%</span>
          </div>
          <ProgressBar value={progressValue} tone={tone} />
        </div>
        <MiniSparkline
          data={sparkline}
          color={theme.chart}
        />
        {onOpen ? (
          <Button variant="outline" className="w-full justify-between rounded-xl" onClick={onOpen}>
            {buttonLabel}
            <Icons.arrowRight className="h-4 w-4" />
          </Button>
        ) : null}
      </CardContent>
    </Card>
  );
}

export function RankedProjectList({ projects = [], typeLabel, tone = 'blue', onOpen }) {
  const theme = getTone(tone);
  const ranked = [...projects]
    .map((project) => ({
      ...project,
      usage_score: getUsageScore(
        project.message_count || project.total_message_count || project.total_messages,
        project.chat_count || project.total_chats
      ),
    }))
    .sort((a, b) => b.usage_score - a.usage_score)
    .slice(0, 5);

  return (
    <div className="space-y-3">
      {ranked.map((project, index) => {
        const messages = Number(project.message_count || project.total_message_count || project.total_messages || 0);
        const sessions = Number(project.chat_count || project.total_chats || 0);
        const progressValue = ranked[0]?.usage_score
          ? Math.round((project.usage_score / ranked[0].usage_score) * 100)
          : 0;

        return (
          <button
            key={project.project_id || project.id || `${typeLabel}-${index}`}
            type="button"
            className="flex w-full items-start justify-between gap-4 rounded-2xl border border-border/70 bg-muted/20 p-4 text-left transition-all duration-200 hover:border-primary/20 hover:bg-muted/40"
            onClick={() => onOpen?.(project)}
          >
            <div className="min-w-0 flex-1 space-y-3">
              <div className="flex items-start gap-3">
                <div className={cn('flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-sm font-semibold', theme.iconWrap)}>
                  {index + 1}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="truncate text-sm font-semibold text-foreground">{project.project_name || project.name}</p>
                    <Badge className={cn('rounded-full border px-2 py-0.5 text-[10px] font-semibold', theme.badge)}>
                      {typeLabel}
                    </Badge>
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {formatCompactNumber(messages)} messages • {formatCompactNumber(sessions)} sessions
                  </p>
                </div>
              </div>
              <ProgressBar value={progressValue} tone={tone} />
            </div>
            <div className="shrink-0 text-right">
              <div className="text-sm font-semibold text-foreground">{formatCompactNumber(project.usage_score)}</div>
              <div className="text-xs text-muted-foreground">usage score</div>
            </div>
          </button>
        );
      })}
    </div>
  );
}

export function ProjectAnalyticsCard({ project, rank, onViewAnalytics, onOpenProject }) {
  const isFrontend = project?.project_type === 'frontend';
  const tone = isFrontend ? 'cyan' : 'violet';
  const theme = getTone(tone);
  const messages = Number(project?.total_messages || project?.message_count || 0);
  const sessions = Number(project?.total_chats || project?.chat_count || 0);
  const usageScore = getUsageScore(messages, sessions);
  const sparkline = buildSimpleSparkline(
    Math.max(1, Math.round(messages * 0.25)),
    Math.max(1, Math.round(messages * 0.45)),
    Math.max(1, Math.round(messages * 0.7)),
    Math.max(1, messages),
  );

  return (
    <Card className={analyticsCardClass}>
      <CardHeader className="space-y-4 p-5 pb-3">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <CardTitle className="truncate text-lg font-semibold">{project?.project_name || project?.name}</CardTitle>
              <Badge className={cn('rounded-full border px-2 py-0.5 text-[10px] font-semibold', theme.badge)}>
                {isFrontend ? 'Frontend' : 'Backend'}
              </Badge>
            </div>
            <CardDescription className="mt-1 leading-6">
              Rank #{rank} • {usageScore > 0 ? 'Active this period' : 'No recent activity'}
            </CardDescription>
          </div>
          <div className={cn('flex h-10 w-10 shrink-0 items-center justify-center rounded-xl', theme.iconWrap)}>
            {isFrontend ? <Icons.gitFork className="h-5 w-5" /> : <Icons.sparkles className="h-5 w-5" />}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4 p-5 pt-0">
        <div className="grid grid-cols-3 gap-3">
          <div>
            <div className="text-xs text-muted-foreground">Messages</div>
            <div className="mt-1 text-lg font-semibold">{formatCompactNumber(messages)}</div>
          </div>
          <div>
            <div className="text-xs text-muted-foreground">Sessions</div>
            <div className="mt-1 text-lg font-semibold">{formatCompactNumber(sessions)}</div>
          </div>
          <div>
            <div className="text-xs text-muted-foreground">Usage rank</div>
            <div className="mt-1 text-lg font-semibold">#{rank}</div>
          </div>
        </div>
        <MiniSparkline data={sparkline} color={theme.chart} />
        <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
          <Button variant="outline" className="rounded-xl" onClick={onViewAnalytics}>
            View analytics
          </Button>
          <Button className="rounded-xl" onClick={onOpenProject}>
            Open project
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

export function EmptyAnalyticsState({
  icon: Icon = Icons.project,
  title,
  description,
  actionLabel,
  onAction,
}) {
  return (
    <Card className={cn(analyticsCardClass, 'border-dashed')}>
      <CardContent className="flex flex-col items-center justify-center gap-4 p-10 text-center">
        <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-muted/60">
          <Icon className="h-7 w-7 text-muted-foreground" />
        </div>
        <div className="space-y-1">
          <h3 className="text-lg font-semibold text-foreground">{title}</h3>
          <p className="max-w-xl text-sm leading-6 text-muted-foreground">{description}</p>
        </div>
        {actionLabel ? (
          <Button variant="outline" className="rounded-xl" onClick={onAction}>
            {actionLabel}
          </Button>
        ) : null}
      </CardContent>
    </Card>
  );
}
