import { useState, useEffect, useCallback } from 'react';
import CodeMirror from '@uiw/react-codemirror';
import { python } from '@codemirror/lang-python';
import { vscodeLight, vscodeDark } from '@uiw/codemirror-theme-vscode';
import { Button } from '../ui/button';
import { Icons } from '../ui/icons';
import { ScrollArea } from '../ui/scrollarea';
import { useProject } from '../../hooks/project';
import { generateProjectCode } from '../../utils/codegen';
import { toast } from '../../hooks/toast';
import { copyTextToClipboard } from '../../lib/utils';
import { WINASSIST_LOGO_URL } from '../../lib/config';
import useThemeStore, { THEMES } from '../../store/theme';

export default function PythonCodeView({ projectId }) {
  const { project, isLoading, updateProject } = useProject(projectId);
  const [code, setCode] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState(null);
  const [copied, setCopied] = useState(false);
  const [apiKeyCopied, setApiKeyCopied] = useState(false);

  const generateCode = useCallback(async () => {
    if (!project?.flow) {
      return '';
    }
    
    setIsGenerating(true);
    setError(null);

    try {
      const generatedCode = await generateProjectCode(project);
      
      if (!generatedCode) {
        throw new Error('No code returned from server');
      }
      
      setCode(generatedCode);
      // Persist so backend chat runs the same script as the Code tab (full agent behavior).
      try {
        await updateProject(
          {
            flow: {
              ...project.flow,
              generated_python: generatedCode,
            },
          },
          { skipRevalidate: true }
        );
      } catch (persistErr) {
        console.warn('Could not save generated Python to project flow:', persistErr);
      }
      toast({
        title: 'Code Generated',
        description: 'Python saved to your project for chat and API runs.',
      });
      
      return generatedCode;
      
    } catch (e) {
      console.error('Error generating Python code:', e);
      const errorMessage = e.message || 'Unknown error occurred';
      
      setError(errorMessage);
      
      toast({
        title: 'Error generating Python code',
        description: errorMessage,
        variant: 'destructive',
      });
      
      return '';
    } finally {
      setIsGenerating(false);
    }
  }, [project, updateProject]);

  useEffect(() => {
    if (project?.flow && project?.id) {
      generateCode();
    }
  }, [project?.id, project?.updated_at, generateCode]);

  const handleCopy = async () => {
    if (!code) return;
    try {
      await copyTextToClipboard(code);
      setCopied(true);
      toast({
        title: 'Copied',
        description: 'Code has been copied to clipboard.',
      });
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      console.error('Failed to copy:', error);
      toast({
        title: 'Copy Failed',
        description: 'Failed to copy code to clipboard.',
        variant: 'destructive',
      });
    }
  };

  const handleDownload = () => {
    if (!code) return;
    
    const blob = new Blob([code], { type: 'text/python' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${project?.name || 'project'}.py`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast({
      title: 'Downloaded',
      description: 'Code has been downloaded.',
    });
  };

  const theme = useThemeStore((state) => state.theme);

  if (isLoading || !project) {
    return (
      <div className="relative flex w-full h-full items-center justify-center">
        <img src={WINASSIST_LOGO_URL} alt="WinAssist" className="w-12 h-12 object-contain animate-pulse opacity-50" />
      </div>
    );
  }

  if (isGenerating && !code) {
    return (
      <div className="relative flex flex-col w-full h-full items-center justify-center gap-4">
        <img src={WINASSIST_LOGO_URL} alt="WinAssist" className="w-12 h-12 object-contain animate-pulse opacity-50" />
        <p className="text-sm text-muted-foreground">Generating Python code...</p>
      </div>
    );
  }

  if (error && !code) {
    return (
      <div className="relative flex flex-col w-full h-full items-center justify-center gap-4 p-8">
        <div className="max-w-md p-4 border border-red-500 rounded-lg bg-red-50 dark:bg-red-900/20">
          <div className="mb-4">
            <h3 className="text-lg font-semibold mb-2 text-red-900 dark:text-red-100">Failed to Generate Code</h3>
            <p className="text-sm text-red-700 dark:text-red-300">{error}</p>
          </div>
          <Button
            onClick={() => generateCode()}
            variant="outline"
            size="sm"
          >
            Retry
          </Button>
        </div>
      </div>
    );
  }

  const handleCopyApiKey = async () => {
    if (!project?.api_key) return;
    try {
      await copyTextToClipboard(project.api_key);
      setApiKeyCopied(true);
      toast({
        title: 'API Key Copied',
        description: 'Bot API key copied to clipboard.',
      });
      setTimeout(() => setApiKeyCopied(false), 2000);
    } catch (error) {
      console.error('Failed to copy API key:', error);
      toast({
        title: 'Copy Failed',
        description: 'Failed to copy API key to clipboard.',
        variant: 'destructive',
      });
    }
  };

  return (
    <div className="flex flex-col h-full w-full">
      {/* API Key Section */}
      {project?.api_key && project?.project_type === 'backend' && (
        <div className="p-4 border-b bg-muted/30">
          <div className="flex items-center justify-between gap-4">
            <div className="flex-1 min-w-0">
              <h3 className="text-sm font-semibold mb-1 flex items-center gap-2">
                <Icons.lock className="w-4 h-4" />
                Bot API Key
              </h3>
              <p className="text-xs text-muted-foreground mb-2">
                Use this key to authenticate API requests from your frontend widget
              </p>
              <div className="flex items-center gap-2">
                <code className="flex-1 px-3 py-2 bg-background border rounded text-xs font-mono overflow-hidden text-ellipsis">
                  {project.api_key}
                </code>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleCopyApiKey}
                  className="gap-2 shrink-0"
                >
                  {apiKeyCopied ? (
                    <>
                      <Icons.check className="w-4 h-4" />
                      Copied!
                    </>
                  ) : (
                    <>
                      <Icons.copy className="w-4 h-4" />
                      Copy
                    </>
                  )}
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Toolbar */}
      <div className="flex items-center justify-between gap-2 p-4 border-b">
        <div className="flex items-center gap-2">
          <Button
            variant="default"
            size="sm"
            onClick={generateCode}
            disabled={isGenerating}
            className="gap-2"
          >
            <Icons.sparkles className="w-4 h-4" />
            {isGenerating ? 'Generating...' : 'Generate Code'}
          </Button>
          
          {code && (
            <>
              <Button
                variant="outline"
                size="sm"
                onClick={handleCopy}
                className="gap-2"
              >
                {copied ? (
                  <>
                    <Icons.check className="w-4 h-4" />
                    Copied!
                  </>
                ) : (
                  <>
                    <Icons.copy className="w-4 h-4" />
                    Copy
                  </>
                )}
              </Button>
              
              <Button
                variant="outline"
                size="sm"
                onClick={handleDownload}
                className="gap-2"
              >
                <Icons.download className="w-4 h-4" />
                Download
              </Button>
            </>
          )}
        </div>
        
        <div className="text-xs text-muted-foreground">
          {project?.name || 'Project'}
        </div>
      </div>

      {/* Code Editor */}
      <ScrollArea className="flex-1">
        <div className="relative w-full h-full">
          {code ? (
            <CodeMirror
              value={code}
              height="100%"
              theme={theme === THEMES.DARK ? vscodeDark : vscodeLight}
              extensions={[python()]}
              editable={false}
              basicSetup={{
                lineNumbers: true,
                highlightActiveLineGutter: false,
                highlightActiveLine: false,
              }}
              className="w-full text-xs"
            />
          ) : (
            <div className="flex items-center justify-center h-full">
              <div className="text-center text-muted-foreground">
                <Icons.code className="w-12 h-12 mb-4 opacity-50 mx-auto" />
                <p className="text-lg font-medium mb-2">No Code Generated</p>
                <p className="text-sm">
                  Click "Generate Code" to convert your flow to Python
                </p>
              </div>
            </div>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}

