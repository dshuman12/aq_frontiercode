import { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Icons } from '../ui/icons';
import { cn } from '../../lib/utils';
import { Button } from '../ui/button';
import { Sheet, SheetContent, SheetTitle } from '../ui/sheet';
import { WINASSIST_LOGO_URL } from '../../lib/config';
import { APP_HEADER_HEIGHT_CLASS, APP_HEADER_PADDING_X } from './layout-constants';

const MENU_ITEMS = [
  { label: 'Dashboard', path: '/dashboard', icon: Icons.home, exact: true },
  { label: 'Project Insight', path: '/project-dashboard', icon: Icons.circleGauge },
  { label: 'Chat Flow', path: '/chatflow', icon: Icons.gitFork },
  { label: 'Ai Agent', path: '/aiagent', icon: Icons.sparkles },
  { label: 'Help / Support', path: '/help-support', icon: Icons.help },
  // { label: 'Knowledge Base', path: '/knowledge-base', icon: Icons.docs },
  { label: 'Templates', path: '/templates', icon: Icons.docs },
  // { label: 'Publish Center', path: '/publish-center', icon: Icons.share },
  { label: 'Channels', path: '/channels', icon: Icons.globe },
  { label: 'MCP Tools', path: '/tools', icon: Icons.tool },
  { label: 'Marketplace', path: '/integrations', icon: Icons.package, status: 'Soon' },
  { label: 'Team', path: '/workspaces/invites', icon: Icons.group },
];

function NavLinks({ isExpanded, inDrawer, onNavigate }) {
  const location = useLocation();
  return (
    <>
      {MENU_ITEMS.map((item) => {
        const isActive = item.exact
          ? location.pathname === item.path
          : location.pathname.startsWith(item.path);
        return (
          <Button
            key={item.path}
            variant="ghost"
            className={cn(
              'relative mb-1.5 h-auto overflow-hidden rounded-xl border border-transparent transition-all duration-200',
              inDrawer ? 'w-full justify-start px-3 py-2' : isExpanded ? 'w-full justify-start px-3 py-2' : 'w-11 justify-center p-2',
              'hover:-translate-y-0.5 hover:border-sidebar-border/80 hover:bg-sidebar-accent/70',
              isActive
                ? 'border-primary/15 bg-primary text-primary-foreground shadow-[0_14px_30px_-20px_rgba(37,99,235,0.55)] hover:bg-primary/95'
                : 'bg-transparent text-sidebar-foreground'
            )}
            onClick={() => onNavigate?.(item.path)}
          >
            {isActive ? (
              <span className="absolute inset-y-0 left-0 w-1.5 rounded-r-full bg-primary-foreground/90" />
            ) : null}
            <div className={cn('flex items-center w-full', (isExpanded || inDrawer) ? 'gap-2.5' : 'justify-center')}>
              <div
                className={cn(
                  'flex h-8 w-8 shrink-0 items-center justify-center rounded-lg transition-colors',
                  isActive ? 'bg-primary-foreground/12 text-primary-foreground' : 'bg-sidebar-accent/40 text-sidebar-foreground/85'
                )}
              >
                <item.icon className="h-4 w-4 shrink-0" />
              </div>
              {(isExpanded || inDrawer) && (
                <div className="flex min-w-0 flex-1 flex-col items-start">
                  <div className="flex w-full min-w-0 items-start justify-between gap-2">
                    <span className={cn('line-clamp-1 text-left text-sm font-medium leading-snug', isActive ? 'text-primary-foreground' : 'text-sidebar-foreground')}>
                      {item.label}
                    </span>
                    {item.status ? (
                      <span
                        className={cn(
                          'shrink-0 rounded-full border px-1.5 py-0.5 text-[10px] font-medium uppercase tracking-wide',
                          isActive
                            ? 'border-primary-foreground/30 text-primary-foreground/90'
                            : 'border-sidebar-foreground/20 text-sidebar-foreground/80'
                        )}
                      >
                        {item.status}
                      </span>
                    ) : null}
                  </div>
                </div>
              )}
            </div>
          </Button>
        );
      })}
    </>
  );
}

export function Sidebar({ mobileOpen, onMobileOpenChange }) {
  const navigate = useNavigate();
  const [isExpanded, setIsExpanded] = useState(true);

  const handleNav = (path) => {
    navigate(path);
    onMobileOpenChange?.(false);
  };

  return (
    <>
      {/* Desktop sidebar - full viewport height, hidden on small screens */}
      <div
        className={cn(
          'hidden h-full min-h-0 shrink-0 flex-col border-r border-sidebar-border bg-sidebar/95 shadow-[8px_0_30px_-24px_rgba(15,23,42,0.35)] transition-all duration-300 lg:flex',
          isExpanded ? 'w-72' : 'w-16'
        )}
      >
        <div
          className={cn(
            'flex items-center border-b border-sidebar-border bg-sidebar',
            APP_HEADER_HEIGHT_CLASS,
            APP_HEADER_PADDING_X,
            isExpanded ? 'justify-between' : 'justify-center'
          )}
        >
          {isExpanded ? (
            <div className="min-w-0 flex items-center gap-3">
              <img src={WINASSIST_LOGO_URL} alt="WinAssist" className="h-11 w-11 shrink-0 rounded-xl object-contain ring-1 ring-sidebar-border/60" />
              <div className="min-w-0">
                <h2 className="truncate text-xl font-bold text-sidebar-foreground">WinAssist</h2>
                <p className="truncate text-xs text-sidebar-foreground/70">Analytics workspace</p>
              </div>
            </div>
          ) : null}
          <Button variant="ghost" size="icon" className={cn('h-9 w-9 rounded-xl bg-sidebar-accent/20 text-sidebar-foreground hover:bg-sidebar-accent/50', isExpanded && 'ml-auto shrink-0')} onClick={() => setIsExpanded(!isExpanded)}>
            {isExpanded ? <Icons.chevronLeft className="h-4 w-4" /> : <Icons.chevronRight className="h-4 w-4" />}
          </Button>
        </div>
        <div className="sidebar-nav-scroll flex-1 min-h-0 overflow-y-auto overflow-x-hidden bg-sidebar p-2">
          <NavLinks isExpanded={isExpanded} onNavigate={navigate} />
        </div>
      </div>

      {/* Mobile drawer */}
      <Sheet open={mobileOpen} onOpenChange={onMobileOpenChange}>
        <SheetContent
          side="left"
          className="flex w-[min(18rem,85vw)] max-w-[18rem] flex-col border-r border-sidebar-border bg-sidebar p-0"
        >
          <SheetTitle className="sr-only">Navigation menu</SheetTitle>
          <div className={cn('flex items-center gap-3 border-b border-sidebar-border bg-sidebar', APP_HEADER_HEIGHT_CLASS, APP_HEADER_PADDING_X)}>
            <img src={WINASSIST_LOGO_URL} alt="WinAssist" className="h-11 w-11 shrink-0 rounded-xl object-contain ring-1 ring-sidebar-border/60" />
            <div>
              <h2 className="text-xl font-bold text-sidebar-foreground">WinAssist</h2>
              <p className="text-xs text-sidebar-foreground/70">Analytics workspace</p>
            </div>
          </div>
          <div className="sidebar-nav-scroll flex-1 min-h-0 overflow-y-auto overflow-x-hidden bg-sidebar p-2">
            <NavLinks inDrawer onNavigate={handleNav} />
          </div>
        </SheetContent>
      </Sheet>
    </>
  );
}
