export const APP_HEADER_HEIGHT_CLASS = 'h-16';
export const APP_HEADER_HEIGHT_VALUE = '4rem';
export const APP_HEADER_PADDING_X = 'px-4 sm:px-6';
