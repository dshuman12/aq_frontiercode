import { AppLayout } from './app-layout';
import { PageHeader } from './page-header';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';

export function PlatformModulePage({
  icon: Icon,
  title,
  description,
  badge,
  stats = [],
  sections = [],
}) {
  return (
    <AppLayout>
      <div className="mx-auto flex max-w-7xl flex-col gap-6">
        <PageHeader title={title} description={description} icon={Icon} />
        <Card className="border-primary/20 bg-gradient-to-br from-primary/10 via-background to-accent/5">
          <CardHeader className="gap-3">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="min-w-0">
                <CardTitle className="text-lg sm:text-xl">{title}</CardTitle>
                <CardDescription className="mt-1 max-w-3xl text-sm leading-6">
                  {description}
                </CardDescription>
              </div>
              {badge ? (
                <div className="rounded-full border border-primary/20 bg-background px-3 py-1 text-xs font-medium text-primary">
                  {badge}
                </div>
              ) : null}
            </div>
          </CardHeader>
        </Card>

        {stats.length > 0 ? (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
            {stats.map((stat) => (
              <Card key={stat.label}>
                <CardHeader className="pb-2">
                  <CardDescription>{stat.label}</CardDescription>
                  <CardTitle className="text-2xl">{stat.value}</CardTitle>
                </CardHeader>
                {stat.help ? (
                  <CardContent>
                    <p className="text-sm text-muted-foreground">{stat.help}</p>
                  </CardContent>
                ) : null}
              </Card>
            ))}
          </div>
        ) : null}

        <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
          {sections.map((section) => (
            <Card key={section.title} className="h-full">
              <CardHeader>
                <CardTitle>{section.title}</CardTitle>
                {section.description ? (
                  <CardDescription>{section.description}</CardDescription>
                ) : null}
              </CardHeader>
              <CardContent className="space-y-3">
                {(section.items || []).map((item, idx) => {
                  if (item.children) {
                    return (
                      <div key={idx} className="rounded-lg bg-muted/30 p-4">
                        {item.children}
                      </div>
                    );
                  }
                  return (
                    <div
                      key={item.title}
                      className="rounded-lg border bg-muted/30 p-4"
                    >
                      <div className="text-sm font-medium text-foreground">
                        {item.title}
                      </div>
                      <p className="mt-1 text-sm leading-6 text-muted-foreground">
                        {item.description}
                      </p>
                      {item.actionLabel && item.onAction ? (
                        <div className="mt-4">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={item.onAction}
                          >
                            {item.actionLabel}
                          </Button>
                        </div>
                      ) : null}
                    </div>
                  );
                })}
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </AppLayout>
  );
}
