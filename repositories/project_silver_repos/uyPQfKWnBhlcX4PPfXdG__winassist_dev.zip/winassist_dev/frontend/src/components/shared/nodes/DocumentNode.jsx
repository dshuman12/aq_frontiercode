import { memo } from 'react';
import { GenericNode } from '../generic-node';

const formatBytes = (bytes) => {
  const numeric = Number(bytes);
  if (!Number.isFinite(numeric) || numeric <= 0) return 'No file yet';
  if (numeric < 1024) return `${numeric} B`;
  if (numeric < 1024 * 1024) return `${(numeric / 1024).toFixed(1)} KB`;
  return `${(numeric / (1024 * 1024)).toFixed(1)} MB`;
};

const DocumentNode = memo(({ id, data, selected, width, height, ...props }) => {
  const variableName = data?.variableName || 'uploadedDocument';
  const prompt = data?.prompt || 'Please upload your document';
  const acceptedTypes = data?.accept || '*/*';
  const maxSizeMb = Number(data?.maxSizeMb || 10);
  const fileName = data?.lastFileName || '';
  const fileSize = formatBytes(data?.lastFileSize);

  return (
    <GenericNode
      id={id}
      data={{
        ...data,
        id: data?.id || 'document',
        name: data?.name || data?.label || 'Document Upload',
      }}
      selected={selected}
      width={width}
      height={height}
      ports={[
        { type: 'target', name: 'input' },
        { type: 'source', name: 'output' },
      ]}
      {...props}
    >
      <div className="space-y-2">
        <div className="rounded-md border border-border/70 bg-background px-3 py-2">
          <div className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
            Prompt
          </div>
          <div className="mt-1 text-xs font-medium text-foreground break-words">
            {prompt}
          </div>
        </div>
        <div className="rounded-md border border-border/70 bg-background px-3 py-2">
          <div className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
            Variable
          </div>
          <div className="mt-1 text-xs font-medium text-foreground break-words">
            {variableName}
          </div>
        </div>
        <div className="rounded-md border border-border/70 bg-background px-3 py-2">
          <div className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
            File Rules
          </div>
          <div className="mt-1 text-xs font-medium text-foreground break-words">
            {acceptedTypes} | up to {maxSizeMb} MB
          </div>
          <div className="mt-1 text-[11px] text-muted-foreground break-words">
            {fileName ? `${fileName} (${fileSize})` : fileSize}
          </div>
        </div>
      </div>
    </GenericNode>
  );
});

DocumentNode.displayName = 'DocumentNode';

export default DocumentNode;
