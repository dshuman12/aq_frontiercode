import { memo } from 'react';
import { Position } from '@xyflow/react';
import { cn } from '../../../lib/utils';
import { DEFAULT_NODE_COLOR } from '../../../lib/flow';
import { GenericNode } from '../generic-node';

const MergeNode = memo(({ id, data, selected, width, height }) => {
  const color = data?.color || DEFAULT_NODE_COLOR;
  const handles = [
    { type: 'target', id: 'input-a', position: Position.Left, style: { top: '35%' }, className: '!border-green-500' },
    { type: 'target', id: 'input-b', position: Position.Left, style: { top: '65%' }, className: '!border-green-500' },
    { type: 'source', id: 'output', position: Position.Right, style: { top: '50%' }, className: '!border-blue-500' },
  ];

  return (
    <GenericNode
      id={id}
      data={data}
      selected={selected}
      width={width}
      height={height}
      minWidth={170}
      minHeight={100}
      handles={handles}
      resizerColor={color}
      className={cn(
        'rounded-lg border-2 bg-background shadow-sm transition-all',
        selected && 'ring-2 ring-primary/30 shadow-md'
      )}
    />
  );
});

MergeNode.displayName = 'MergeNode';

export default MergeNode;
