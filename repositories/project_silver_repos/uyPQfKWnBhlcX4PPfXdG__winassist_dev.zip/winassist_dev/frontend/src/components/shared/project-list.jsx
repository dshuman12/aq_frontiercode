import { useNavigate } from 'react-router-dom';
import { useState, useRef, useEffect } from 'react';
import { Skeleton } from '../ui/skeleton';
import { cn } from '../../lib/utils';
import { Card } from '../ui/card';
import { Icons } from '../ui/icons';
import {useProjects} from "../../hooks/project"
import { useWorkspaces } from '../../hooks/workspace';
import { Button } from '../ui/button';
import { toast } from '../../hooks/toast';
import { formatIstDateTime } from '../../lib/datetime';
export const Projectloading=()=>{
    return (
        <div className="flex w-full flex-wrap justify-center gap-4">
      {[...Array(6)].map((_, i) => (
        <Card key={i} className="w-80 h-48 flex flex-col overflow-hidden gap-2">
          <div className="p-4 flex flex-col gap-2">
            <Skeleton className="h-8 w-full" />
            <div className="flex flex-col gap-2 h-full">
              <Skeleton className="h-4 w-1/2" />
              <Skeleton className="h-3 w-full" />
              <Skeleton className="h-4 w-1/2" />
            </div>
            <div className="flex items-center justify-end gap-1">
              <Skeleton className="h-5 w-20" />
            </div>
          </div>
        </Card>
      ))}
    </div>
    )
}
export const ProjectBlock=({ project, className, index, projectType })=>{
  
  
  const navigate = useNavigate();
  const { projects: allProjects, deleteProject, isDeleting, updateProject, isUpdating } = useProjects();
  const { currentWorkspace } = useWorkspaces();
  const isViewer = currentWorkspace?.role === 'viewer';
  const [isEditingName, setIsEditingName] = useState(false);
  const [projectName, setProjectName] = useState(project.name);
  const inputRef = useRef(null);
  const [isEditingDescription, setIsEditingDescription] = useState(false);
  const [projectDescription, setProjectDescription] = useState(project.description ?? '');
  const descriptionRef = useRef(null);

  useEffect(() => {
    setProjectName(project.name);
  }, [project.name]);

  useEffect(() => {
    setProjectDescription(project.description ?? '');
  }, [project.description]);

  useEffect(() => {
    if (isEditingName && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
  }, [isEditingName]);

  useEffect(() => {
    if (isEditingDescription && descriptionRef.current) {
      descriptionRef.current.focus();
      descriptionRef.current.select?.();
    }
  }, [isEditingDescription]);
  
  const onDelete = async (e) => {
    e.stopPropagation(); // Prevent card click
    try {
      await deleteProject(project.id);
      toast({ title: `Project ${project.name} deleted` });
      
      // Check if we're currently viewing this project
      const currentPath = window.location.pathname;
      const isViewingProject = 
        currentPath === `/projects/${project.id}` ||
        currentPath === `/aiagent/${project.id}` ||
        currentPath === `/chatflow/${project.id}`;
      
      // If viewing the deleted project, redirect to projects list
      if (isViewingProject) {
        navigate('/projects');
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to delete project',
        variant: 'destructive',
      });
    }
  };

  const handleEdit = (e) => {
    e.stopPropagation();
    // Navigate based on project type or route context
    if (projectType === 'backend') {
      navigate(`/aiagent/${project.id}`);
    } else if (projectType === 'frontend') {
      navigate(`/chatflow/${project.id}`);
    } else {
      navigate(`/projects/${project.id}`);
    }
  };

  const handleNameClick = (e) => {
    e.stopPropagation();
    setIsEditingName(true);
  };

  const handleNameSave = async () => {
    if (projectName.trim() === '') {
      setProjectName(project.name);
      setIsEditingName(false);
      return;
    }

    const nextName = projectName.trim();

    if (nextName === project.name) {
      setIsEditingName(false);
      return;
    }

    const normalize = (s) => (s ?? '').trim().toLowerCase();
    const proposed = normalize(nextName);

    // Prevent duplicate project names (scoped by projectType where applicable)
    const duplicates = (allProjects || []).some((p) => {
      if (!p) return false;
      if (p.id === project.id) return false;
      if (projectType === 'backend' && p.project_type !== 'backend') return false;
      if (projectType === 'frontend' && p.project_type !== 'frontend') return false;
      return normalize(p.name) === proposed;
    });

    if (duplicates) {
      toast({
        title: 'Error',
        description: 'Project with same name exists',
        variant: 'destructive',
      });
      setProjectName(project.name);
      setIsEditingName(false);
      return;
    }

    try {
      await updateProject(project.id, { name: nextName });
      toast({ title: 'Project name updated' });
      setIsEditingName(false);
    } catch (error) {
      console.error('Failed to update project name:', error);
      setProjectName(project.name);
      toast({
        title: 'Error',
        description: 'Failed to update project name',
        variant: 'destructive',
      });
      setIsEditingName(false);
    }
  };

  const handleNameCancel = () => {
    setProjectName(project.name);
    setIsEditingName(false);
  };

  const handleNameKeyDown = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleNameSave();
    } else if (e.key === 'Escape') {
      e.preventDefault();
      handleNameCancel();
    }
  };

  const handleDescriptionClick = (e) => {
    e.stopPropagation();
    setIsEditingDescription(true);
  };

  const handleDescriptionCancel = () => {
    setProjectDescription(project.description ?? '');
    setIsEditingDescription(false);
  };

  const handleDescriptionSave = async () => {
    const nextDescription = (projectDescription ?? '').trim();
    const current = (project.description ?? '').trim();

    if (nextDescription === current) {
      setIsEditingDescription(false);
      return;
    }

    try {
      await updateProject(project.id, { description: nextDescription });
      setProjectDescription(nextDescription);
      toast({ title: 'Project description updated' });
      setIsEditingDescription(false);
    } catch (error) {
      console.error('Failed to update project description:', error);
      setProjectDescription(project.description ?? '');
      toast({
        title: 'Error',
        description: 'Failed to update project description',
        variant: 'destructive',
      });
      setIsEditingDescription(false);
    }
  };

  const handleDescriptionKeyDown = (e) => {
    if (e.key === 'Escape') {
      e.preventDefault();
      handleDescriptionCancel();
      return;
    }
    // Save on Ctrl/Cmd+Enter for textarea
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      handleDescriptionSave();
    }
  };

  return (
    <Card
      className={cn(
        'relative group w-80 hover:border-primary/40 p-4 flex flex-col gap-2 cursor-pointer',
        className
      )}
      onClick={handleEdit}
    >
      {isEditingName ? (
        <input
          ref={inputRef}
          type="text"
          value={projectName}
          onChange={(e) => setProjectName(e.target.value)}
          onBlur={handleNameSave}
          onKeyDown={handleNameKeyDown}
          onClick={(e) => e.stopPropagation()}
          className="w-full px-2 py-1 text-primary text-lg font-bold border-2 border-primary rounded bg-background focus:outline-none focus:ring-2 focus:ring-primary"
          disabled={isUpdating}
        />
      ) : (
        <h2 
          className={cn(
            "line-clamp-1 text-primary text-lg font-bold",
            !isViewer && "cursor-pointer hover:underline"
          )}
          onClick={!isViewer ? handleNameClick : undefined}
          title={!isViewer ? "Click to edit name" : undefined}
        >
          {project.name}
        </h2>
      )}
      <div className="text-xs text-muted-foreground">
        {formatIstDateTime(project.created_at || project.updated_at)}
      </div>
      {isEditingDescription ? (
        <textarea
          ref={descriptionRef}
          value={projectDescription}
          onChange={(e) => setProjectDescription(e.target.value)}
          onBlur={handleDescriptionSave}
          onKeyDown={handleDescriptionKeyDown}
          onClick={(e) => e.stopPropagation()}
          className="w-full min-h-[56px] resize-none rounded-lg border border-border/70 bg-background px-2 py-1 text-xs text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
          disabled={isUpdating}
        />
      ) : (
        <div
          className={cn(
            'text-xs text-muted-foreground',
            !isViewer && 'cursor-pointer hover:text-foreground'
          )}
          onClick={!isViewer ? handleDescriptionClick : undefined}
          title={!isViewer ? 'Click to edit description' : undefined}
        >
          {projectDescription || '—'}
        </div>
      )}
      
      <div className="relative card-actions flex items-center justify-end gap-2 pt-1 text-xs text-base-content/60">
        {!isViewer && (
          <Button
            size="sm"
            variant="ghost"
            className="h-8 rounded-lg px-2"
            onClick={(e) => {
              e.stopPropagation();
              handleEdit(e);
            }}
          >
            <span className="mr-1.5">Edit</span>
            <Icons.edit className="h-4 w-4" />
          </Button>
        )}
      </div>
      {!isViewer && (
      <div className="hidden absolute top-2 right-2 group-hover:block">
        <Button
          size="icon"
          variant="ghost"
          onClick={onDelete}
          className="text-red-600 hover:bg-red-500/10 hover:text-red-700"
          title="Delete project"
        >
          {isDeleting ? (
            <Icons.spinner className="w-4 h-4 animate-spin" />
          ) : (
            <Icons.trash className="w-4 h-4" />
          )}
        </Button>
      </div>
      )}
    </Card>
  );
}
export const ProjectList = ({ maxCount, projects: providedProjects, projectType }) => {
    const { projects: allProjects, isLoading, isError } = useProjects();
    const projects = providedProjects || allProjects;
  
    if (isError) {
      console.warn('Failed to load template');
    }
    if (!projects || projects.length === 0) return null;
  
    const displayProjects = maxCount ? projects.slice(0, maxCount) : projects;
  
    return (
      <div className="flex flex-wrap justify-center gap-4 p-2">
        {displayProjects.map((project, index) => (
          <ProjectBlock key={project.id} project={project} index={index} projectType={projectType} />
        ))}
      </div>
    );
  }