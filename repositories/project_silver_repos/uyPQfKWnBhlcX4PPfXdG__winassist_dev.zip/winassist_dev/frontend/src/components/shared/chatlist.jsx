import { useState } from 'react';
import { useChats } from '../../hooks/chat';
import { Icons } from '../ui/icons';
import { Button } from '../ui/button';
import { ScrollArea } from '../ui/scrollarea';
import { cn } from '../../lib/utils';
import { useToast } from '../../hooks/toast';
import { formatIstDate } from '../../lib/datetime';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '../ui/dialog';

export const ChatList = ({ projectId, activeChatId, onChatSelect }) => {
  const { chats, deleteChat, isDeleting, setActiveChatId } = useChats();
  const { toast } = useToast();
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [chatToDelete, setChatToDelete] = useState(null);

  // Filter chats for this project
  const projectChats = chats.filter(
    (chat) => chat.from_project === projectId
  );

  const handleDeleteClick = (e, chat) => {
    e.stopPropagation(); // Prevent chat selection when clicking delete
    setChatToDelete(chat);
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = async () => {
    if (!chatToDelete) return;

    try {
      await deleteChat(chatToDelete.id);
      
      // If deleted chat was active, reset to -1
      if (activeChatId === chatToDelete.id) {
        setActiveChatId(-1);
        if (onChatSelect) {
          onChatSelect(-1);
        }
      }
      
      toast({
        title: 'Chat Deleted',
        description: 'The chat thread has been deleted successfully.',
      });
    } catch (error) {
      toast({
        title: 'Delete Failed',
        description: error.message || 'Failed to delete chat. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setDeleteDialogOpen(false);
      setChatToDelete(null);
    }
  };

  const handleChatClick = (chatId) => {
    setActiveChatId(chatId);
    if (onChatSelect) {
      onChatSelect(chatId);
    }
  };

  if (projectChats.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center p-4 text-center text-muted-foreground">
        <Icons.chat className="w-8 h-8 mb-2 opacity-50" />
        <p className="text-sm">No chat threads yet</p>
        <p className="text-xs mt-1">Start a new chat to begin</p>
      </div>
    );
  }

  return (
    <>
      <ScrollArea className="flex-1">
        <div className="flex flex-col gap-1 p-2">
          {projectChats.map((chat) => (
            <div
              key={chat.id}
              className={cn(
                "group relative flex items-center justify-between p-2 rounded-lg cursor-pointer transition-colors",
                activeChatId === chat.id
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted/50 hover:bg-muted"
              )}
              onClick={() => handleChatClick(chat.id)}
            >
              <div className="flex-1 min-w-0">
                <p className={cn(
                  "text-sm font-medium truncate",
                  activeChatId === chat.id ? "text-primary-foreground" : "text-foreground"
                )}>
                  {chat.name || `Chat ${chat.id}`}
                </p>
                <p className={cn(
                  "text-xs truncate mt-0.5",
                  activeChatId === chat.id ? "text-primary-foreground/80" : "text-muted-foreground"
                )}>
                  {chat.status || 'ready'} • {formatIstDate(chat.created_at)}
                </p>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className={cn(
                  "h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity",
                  activeChatId === chat.id
                    ? "hover:bg-primary-foreground/20 text-primary-foreground"
                    : "hover:bg-destructive/20 text-destructive hover:text-destructive"
                )}
                onClick={(e) => handleDeleteClick(e, chat)}
                disabled={isDeleting}
                title="Delete chat"
              >
                {Icons.trash && <Icons.trash className="h-3 w-3" />}
              </Button>
            </div>
          ))}
        </div>
      </ScrollArea>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Chat Thread?</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete "{chatToDelete?.name || `Chat ${chatToDelete?.id}`}"? 
              This action cannot be undone and will delete all messages in this thread.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setDeleteDialogOpen(false);
                setChatToDelete(null);
              }}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={handleDeleteConfirm}
              disabled={isDeleting}
            >
              {isDeleting ? (
                <>
                  <Icons.spinner className="w-4 h-4 mr-2 animate-spin" />
                  Deleting...
                </>
              ) : (
                <>
                  <Icons.trash className="w-4 h-4 mr-2" />
                  Delete
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

