
import {
  Handle,
  Position,
  NodeResizer,
  NodeToolbar,
  useReactFlow,
} from '@xyflow/react';
import { cn } from '../../lib/utils';
import { Icons } from '../ui/icons';
import { Button } from '../ui/button';
import { getNodeDescription, getNodeTheme, resolveNodeDisplayType } from '../../lib/flow';
import { useState } from 'react';

export const GenericNode = ({
  id,
  data,
  selected,
  ports = [],
  handles = [],
  children,
  width,
  height,
  minWidth = 180,
  minHeight = 104,
  className,
  header,
  contentClassName,
  resizerColor,
  showIcon = true,
  showName = true,
}) => {
  const nodeType = resolveNodeDisplayType(data);
  const nodeTheme = getNodeTheme(nodeType, data?.color);
  const instance = useReactFlow();
  const [isHovered, setIsHovered] = useState(false);
  const nodeTitle = data?.name || data?.label || nodeTheme.label;
  const nodeDescription = getNodeDescription(data);

  // Use explicit dimensions if provided, otherwise use defaults
  const nodeWidth = typeof width === 'number' ? width : (width || minWidth);
  const nodeHeight = typeof height === 'number' ? height : (height || minHeight);
  // effectiveMinHeight and effectiveHeight computed after sourceHandlesWithLabels

  // Use handles if provided, otherwise fall back to ports for backward compatibility
  const handleConfigs = handles.length > 0 ? handles : ports.map(({ type, name }) => ({
    type,
    id: `${type}-${name}`,
    position: type === 'target' ? Position.Left : Position.Right,
  }));

  const sourceHandlesWithLabels = handleConfigs.filter((h) => h.type === 'source' && h.label);
  const showHandleLabels = sourceHandlesWithLabels.length > 0;
  const ROW_HEIGHT = 28;
  const ROW_GAP = 4;
  const HEADER_HEIGHT = 40;
  const CONTENT_PADDING_TOP = 10;
  const CONTENT_PADDING_BOTTOM = 14;
  const N = sourceHandlesWithLabels.length;
  const contentHeight = N > 0 ? N * ROW_HEIGHT + (N - 1) * ROW_GAP : 0;
  const bodyHeight = contentHeight + CONTENT_PADDING_TOP + CONTENT_PADDING_BOTTOM;
  const computedMinHeight = showHandleLabels ? HEADER_HEIGHT + bodyHeight : minHeight;
  const effectiveMinHeight = typeof minHeight === 'number' ? Math.max(minHeight, computedMinHeight) : computedMinHeight;
  const effectiveHeight = showHandleLabels && (height === undefined || height === null)
    ? HEADER_HEIGHT + bodyHeight
    : nodeHeight;

  const duplicateNode = () => {
    const nodes = instance.getNodes();
    const currentNode = nodes.find((node) => node.id === id);
    if (!currentNode) {
      return;
    }

    const duplicatedNode = {
      ...currentNode,
      id: `${id}-${Date.now()}`,
      position: {
        x: currentNode.position.x + 48,
        y: currentNode.position.y + 48,
      },
      selected: false,
      data: {
        ...currentNode.data,
      },
    };

    instance.setNodes(
      nodes.map((node) => ({ ...node, selected: false })).concat(duplicatedNode)
    );
  };

  const focusNode = () => {
    const currentNode = instance.getNodes().find((node) => node.id === id);
    instance.setNodes(
      instance.getNodes().map((node) => ({
        ...node,
        selected: node.id === id,
      }))
    );
    if (currentNode) {
      instance.fitView({
        nodes: [currentNode],
        duration: 250,
        maxZoom: 1.4,
      });
    }
  };

  return (
    <div
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      style={{
        width: typeof nodeWidth === 'number' ? `${nodeWidth}px` : nodeWidth,
        height: typeof effectiveHeight === 'number' ? `${effectiveHeight}px` : effectiveHeight,
        minWidth: `${minWidth}px`,
        minHeight: `${effectiveMinHeight}px`,
        '--node-accent': nodeTheme.color,
        borderColor: selected ? nodeTheme.color : nodeTheme.border,
      }}
      className={cn(
        'relative flex flex-col overflow-visible rounded-lg border-2 bg-background shadow-[0_10px_24px_-16px_rgba(15,23,42,0.55)] transition-all duration-200',
        selected && 'ring-2 ring-primary/30 shadow-md',
        className
      )}
    >
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 rounded-lg"
        style={{
          boxShadow: selected ? `0 0 0 3px ${nodeTheme.soft}` : 'none',
        }}
      />
      <NodeToolbar isVisible={selected || isHovered} position={Position.Top} align={'end'}>
        <div className="flex items-center gap-1 rounded-xl border border-border/70 bg-background/95 p-1 shadow-lg backdrop-blur">
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7"
            onClick={focusNode}
            title="Edit node"
          >
            <Icons.edit className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7"
            onClick={duplicateNode}
            title="Duplicate node"
          >
            <Icons.copy className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7 bg-red-50 text-red-600 hover:bg-red-100 hover:text-red-700"
            onClick={() => instance.deleteElements({ nodes: [{ id }] })}
            title="Delete node"
          >
            <Icons.trash className="w-4 h-4" />
          </Button>
        </div>
      </NodeToolbar>
      <NodeResizer
        color={resizerColor || nodeTheme.color}
        isVisible={selected}
        minWidth={minWidth}
        minHeight={effectiveMinHeight}
        keepAspectRatio={false}
      />
      
      <div
        className="relative z-10 grid min-h-10 flex-shrink-0 grid-cols-[12px_1fr_12px] items-center gap-1.5 rounded-t-lg px-2.5 py-1 text-[11px] font-medium leading-snug text-white"
        style={{ backgroundColor: nodeTheme.color }}
      >
        <span aria-hidden="true" />
        <div className="min-w-0 text-center">
          <div className="node-title font-medium leading-snug">
            {nodeTitle}
          </div>
        </div>
        <span aria-hidden="true" />
      </div>
      <div
        className={cn('flex flex-1 rounded-b-lg bg-muted/50 relative', contentClassName)}
        style={{
          minHeight: showHandleLabels ? `${bodyHeight}px` : '52px',
          paddingTop: showHandleLabels ? CONTENT_PADDING_TOP : 12,
          paddingBottom: showHandleLabels ? CONTENT_PADDING_BOTTOM : 12,
          paddingLeft: 10,
          paddingRight: 10,
        }}
      >
        {showHandleLabels ? (
          <div className="flex flex-col w-full flex-1" style={{ gap: ROW_GAP }}>
            {sourceHandlesWithLabels.map((h) => (
              <div
                key={h.id}
                className="flex items-center flex-shrink-0 rounded-md border border-border bg-background/80 px-2 py-1 pr-8 text-[11px] text-muted-foreground truncate shadow-sm"
                style={{ height: ROW_HEIGHT }}
              >
                {h.label}
              </div>
            ))}
          </div>
        ) : (
          <div className="node-description flex w-full items-center justify-center px-1 text-[11px] leading-5 text-muted-foreground">
            {nodeDescription}
          </div>
        )}
      </div>

      {handleConfigs.map((handle) => {
        const {
          type,
          id: handleId,
          position,
          style = {},
          className: handleClassName,
          label: _label,
          ...handleProps
        } = handle;

        return (
          <Handle
            key={handleId}
            type={type}
            position={position}
            id={handleId}
            style={style}
            className={cn(
              '!h-3.5 !w-3.5 !rounded-full !border-[3px] !bg-background shadow-sm',
              type === 'target' ? '!border-sky-500' : '!border-violet-500',
              selected && '!scale-110',
              handleClassName
            )}
            {...handleProps}
          />
        );
      })}
    </div>
  );
};
