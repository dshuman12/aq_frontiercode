import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { ScrollArea } from '../../ui/scrollarea';
import { cn } from '../../../lib/utils';
import { useTools } from '../../../hooks/tool';
import { useProjects } from '../../../hooks/project';
import { Button } from '../../ui/button';
import { Icons } from '../../ui/icons';
import { Card } from '../../ui/card';
import { GenericOption } from '../../shared/option';
import { Avatar, AvatarFallback, AvatarImage } from '../../ui/avatar';
import { Badge } from '../../ui/badge';
import useUserStore from '../../../store/user';
import { useParams } from 'react-router-dom';
import { useReactFlow } from '@xyflow/react';
import { setNodeData } from '../../../lib/flow';
import { ToolPicker } from '../../tools/picker'; 
import { ToolParameterConfig } from '../../tools/toolconfig';
import { apiRequest } from '../../../lib/api-client';
const getAuthHeaders = () => {
    const user = useUserStore.getState().user
    const token = user?.token
  
    return token
      ? {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        }
      : { 'Content-Type': 'application/json' }
  }
  

  const globalToolParameterConfigs = new Map()
  
  export const ConversableAgentConfig = React.memo(({
    nodeId,
    data,
    optionsDisabled = [],
    className,
    toolScene,
    ...props
  }) => {
    const [models, setModels] = useState([])
    const [selectedToolForParams, setSelectedToolForParams] = useState(null)
    const [toolParameterConfigs, setToolParameterConfigs] = useState({})
    const [backendBots, setBackendBots] = useState([])
    const [loadingBots, setLoadingBots] = useState(false)
  
    const { tools, getToolById } = useTools()
    const instance = useReactFlow()
    const { id: projectId } = useParams()
  
    useEffect(() => {
      setModels(['ChatGpt', 'GoogleGemini'])
    }, [])
    
    // Fetch backend bots for assistant nodes
    useEffect(() => {
      if (toolScene === 'assistant') {
        fetchBackendBots()
      }
    }, [toolScene])
    
    const fetchBackendBots = async () => {
      setLoadingBots(true)
      try {
        const response = await apiRequest('/projects?project_type=backend', {
          method: 'GET',
          showErrorToast: false,
        })
        setBackendBots(response || [])
      } catch (error) {
        console.error('Failed to fetch backend bots:', error)
        setBackendBots([])
      } finally {
        setLoadingBots(false)
      }
    }
  
    /* Restore cached configs and load from node data */
    useEffect(() => {
      const agentId = projectId
        ? parseInt(projectId)
        : data?.agent_id || 1
  
      const key = `${nodeId}-${agentId}`
      
      // First, try to load from node data (persisted in project flow)
      if (data?.toolParameterConfigs) {
        setToolParameterConfigs(data.toolParameterConfigs)
        globalToolParameterConfigs.set(key, data.toolParameterConfigs)
        return
      }
      
      // Fallback to cached configs
      const cached = globalToolParameterConfigs.get(key)
      if (cached) {
        setToolParameterConfigs(cached)
      }
    }, [nodeId, data?.agent_id, data?.toolParameterConfigs, projectId])
  
   
    // Parameters are loaded from node data (toolParameterConfigs) which is persisted in the project flow
    // No need to fetch from backend endpoint since it doesn't exist
    // The useEffect above already handles loading from node data
  
    const onAddTool = useCallback((toolId) => {
      if (data?.tools?.includes(toolId)) return
      const node = instance.getNodes().find((n) => n.id === nodeId)
      if (!node) return
      setNodeData(instance, nodeId, {
        tools: [...(node.data?.tools || []), toolId],
      })
    }, [data?.tools, instance, nodeId])
  
    const onDeleteTool = useCallback((toolId) => {
      const node = instance.getNodes().find((n) => n.id === nodeId)
      if (!node) return
      setNodeData(instance, nodeId, {
        tools: (node.data?.tools || []).filter((t) => t !== toolId),
      })
  
      setToolParameterConfigs((prev) => {
        const copy = { ...prev }
        delete copy[toolId]
        return copy
      })
    }, [instance, nodeId])
  
    const handleConfigureParameters = useCallback((tool) => {
      setSelectedToolForParams(tool)
    }, [])
  
    const handleSaveParameters = useCallback(async (parameters) => {
      if (!selectedToolForParams) return
  
      const updated = {
        ...toolParameterConfigs,
        [selectedToolForParams.id]: parameters,
      }
  
      setToolParameterConfigs(updated)
  
      const agentId = projectId
        ? parseInt(projectId)
        : data?.agent_id || 1
  
      const key = `${nodeId}-${agentId}`
      globalToolParameterConfigs.set(key, updated)
  
      setNodeData(instance, nodeId, {
        toolParameterConfigs: updated,
      })
  
      setSelectedToolForParams(null)
    }, [selectedToolForParams, toolParameterConfigs, nodeId, data?.agent_id, instance])
  
    const GENERAL_OPTIONS = useMemo(() => {
      const options = [
        {
          type: 'text',
          name: 'name',
          label: 'Name',
          placeholder: 'Enter a name',
        },
        {
          type: 'text',
          name: 'description',
          label: 'Description',
          rows: 2,
        },
        {
          type: 'text',
          name: 'system_message',
          label: 'System Message',
          rows: 2,
        },
        {
          type: 'text',
          name: 'max_consecutive_auto_reply',
          label: 'Max auto replies',
          placeholder: 'e.g. 3',
        },
        {
          type: 'select',
          name: 'human_input_mode',
          label: 'Human Input Mode',
          options: [
            { value: 'NEVER', label: 'Never' },
            { value: 'ALWAYS', label: 'Always' },
            { value: 'TERMINATE', label: 'On Termination' },
          ],
        },
      ]
      
      // Add backend bot selector for assistant nodes
      if (toolScene === 'assistant') {
        options.splice(1, 0, {
          type: 'select',
          name: 'backend_bot_id',
          label: 'Backend Bot',
          placeholder: loadingBots ? 'Loading bots...' : 'Select a backend bot',
          options: backendBots.map(bot => ({
            value: bot.id.toString(),
            label: bot.name,
          })),
        })
      }
      
      return options
    }, [toolScene, backendBots, loadingBots])
  
    return (
      <ScrollArea>
        <div className={cn(className, 'flex flex-col gap-4 p-2')}>
          {GENERAL_OPTIONS
            .filter((o) => !optionsDisabled.includes(o.name))
            .map((opt, i) => (
              <GenericOption
                key={`${nodeId}-${i}`}
                nodeId={nodeId}
                data={data}
                {...opt}
              />
            ))}
  
          {/* Tools */}
          <div className="flex flex-col gap-2">
            <div className="flex justify-between">
              <span className="text-sm font-medium">Tools</span>
              <ToolPicker
                onAddTool={onAddTool}
                button={
                  <Button size="sm" className="h-7">
                    <Icons.add className="w-4 h-4" />
                    Add Tool
                  </Button>
                }
              />
            </div>
  
            {data?.tools?.map((toolId, i) => {
              const tool = getToolById(toolId)
              if (!tool) return null
  
              return (
                <Card key={i} className="flex items-center gap-2 p-2">
                  <Avatar className="w-6 h-6">
                    <AvatarImage src={tool.logo_url} />
                    <AvatarFallback>{tool.name?.[0]}</AvatarFallback>
                  </Avatar>
  
                  <div className="flex-1">
                    <span className="text-sm font-medium">{tool.name}</span>
                  </div>
  
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => handleConfigureParameters(tool)}
                  >
                    <Icons.settings className="w-4 h-4" />
                  </Button>
  
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => onDeleteTool(toolId)}
                  >
                    <Icons.close className="w-4 h-4" />
                  </Button>
                </Card>
              )
            })}
          </div>
  
          {props.children}
        </div>
  
        <ToolParameterConfig
          tool={selectedToolForParams}
          isOpen={!!selectedToolForParams}
          onClose={() => setSelectedToolForParams(null)}
          onSave={handleSaveParameters}
          initialValues={
            selectedToolForParams
              ? toolParameterConfigs[selectedToolForParams.id]
              : {}
          }
          nodeId={nodeId}
          nodeName={data?.name || nodeId}
          agentId={projectId ? parseInt(projectId) : 0}
        />
      </ScrollArea>
    )
  })