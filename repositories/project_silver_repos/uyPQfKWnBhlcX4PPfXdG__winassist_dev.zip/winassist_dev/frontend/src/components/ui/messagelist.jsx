import { Icons } from './icons';
import { Button } from './button';
import { stripMatch } from '../../lib/match';
import { StatusMessage } from '../../lib/chat';
import { useChat } from '../../hooks/chat';
import { useUser } from '../../hooks/user';
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogTrigger,
} from './dialog';
import { Card } from './card';
import { Avatar, AvatarFallback, AvatarImage } from './avatar';
import { Markdown } from '../shared/markdown';
import { ScrollArea } from './scrollarea';
import { cn } from '../../lib/utils';
import { formatIstTime } from '../../lib/datetime';
import {
  HoverCard,
  HoverCardContent,
  HoverCardTrigger,
} from './hovercard';
import SyntaxHighlighter from 'react-syntax-highlighter';

const looksLikeRawPayload = (value) => {
  const text = String(value || '').trim();
  if (!text) return false;
  if (text.startsWith('{"kwargs"') || text.startsWith("{'query':") || text.startsWith('{"query":')) {
    return true;
  }
  return text.includes('knowledge_source') || text.includes('chunk_index') || text.includes('density_score');
};

const MessageBubble = ({ chat, message, className }) => {
  const { chatSource } = useChat(chat.id);
  const { user } = useUser();

  const userNodeName =
    chatSource?.flow?.nodes?.find(
      (node) =>
        node.data.type === 'UserProxyAgent' ||
        node.data.type === 'RetrieveUserProxyAgent' ||
        node.data.name.includes('User')
    )?.data?.name ?? '';

  let waitForHumanInput = false;

  // Status messages handling - modern centered style
  if (message.content.startsWith(StatusMessage.completed)) {
    const { found, text } = stripMatch(message.content, StatusMessage.completed);
    const success = found && text.startsWith('DONE');
    const resultClass = success
      ? 'bg-green-500/10 text-green-600 dark:text-green-400 border border-green-500/20'
      : 'bg-red-500/10 text-red-600 dark:text-red-400 border border-red-500/20';

    return (
      <div className={cn('w-full flex justify-center py-2', className)}>
        <div className={cn(
          'flex items-center gap-2 px-4 py-2 rounded-full text-xs font-medium',
          resultClass
        )}>
          {success ? (
            <Icons.checkCircle className="w-4 h-4" />
          ) : (
            <Icons.alert className="w-4 h-4" />
          )}
          <span>
            {success ? 'Completed' : 'Failed'}
          </span>
        </div>
      </div>
    );
  }

  if (message.content.startsWith(StatusMessage.running)) {
    return (
      <div className={cn('w-full flex justify-center py-2', className)}>
        <div className="flex items-center gap-2 px-4 py-2 rounded-full text-xs font-medium bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
          <Icons.group className="w-4 h-4" />
          <span>Processing...</span>
        </div>
      </div>
    );
  }

  if (message.content.startsWith(StatusMessage.receivedHumanInput)) {
    message.content = 'Human input received';
  }

  if (message.content.startsWith(StatusMessage.waitForHumanInput)) {
    const { text } = stripMatch(message.content, StatusMessage.waitForHumanInput);
    message.content = text ?? 'Waiting for human input...';
    waitForHumanInput = true;
  }

  const messageClass = waitForHumanInput
    ? 'bg-yellow-600/20 text-yellow-600'
    : message.type === 'summary'
    ? 'bg-green-500/20 border-green-500/20'
    : 'bg-background text-primary';

  let avatarIcon = <Icons.agent className="w-4 h-4" />;
  if (message.type === 'user') {
    // ✅ FIX: Handle cases where user or avatar_url might be undefined
    const avatarUrl = user?.user_metadata?.avatar_url || message.user?.avatar_url || undefined;
    
    avatarIcon = (
      <Avatar className="w-7 h-7">
        <AvatarImage src={avatarUrl} />
        <AvatarFallback>
          <Icons.user className="w-4 h-4" />
        </AvatarFallback>
      </Avatar>
    );
  } else if (message.type === 'summary') {
    avatarIcon = <Icons.info className="w-4 h-4" />;
  } else if (message.sender === userNodeName) {
    avatarIcon = <Icons.userVoiceFill className="w-5 h-5" />;
  }

  let messageHeader = null;
  if (waitForHumanInput) {
    messageHeader = (
      <div className="flex items-center gap-2 text-xs text-yellow-600">Waiting for human input...</div>
    );
  } else if (message.type === 'user') {
    // Don't show header for user messages - keep it clean
    messageHeader = null;
  } else if (message.type === 'summary') {
    // Don't show "Summary" label - just show the bot message
    messageHeader = null;
  } else if (message.sender && message.type !== 'user') {
    // Only show sender info for assistant messages (not user messages)
    messageHeader = (
      <div className="chat-header flex items-center gap-2 text-xs text-muted-foreground">
        {message.sender}
        {message.receiver && (
          <>
            <Icons.chevronRight className="w-3 h-3" />
            <span>{message.receiver}</span>
          </>
        )}
      </div>
    );
  }

  // Modern chatbot-style layout
  const isUserMessage = message.type === 'user';
  const isBotMessage = message.type === 'summary' || message.type === 'assistant';
  
  return (
    <div className={cn(
      'group flex w-full gap-3 px-4 py-2 hover:bg-muted/30 transition-colors',
      isUserMessage ? 'justify-end' : 'justify-start',
      className
    )}>
      {/* Avatar - only show for bot messages on left */}
      {!isUserMessage && (
        <div className="flex-shrink-0">
          <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary">
            {message.type === 'summary' ? <Icons.agent className="w-4 h-4" /> : avatarIcon}
          </div>
        </div>
      )}
      
      {/* Message bubble */}
      <div className={cn(
        'flex flex-col gap-1 max-w-[80%] sm:max-w-[70%]',
        isUserMessage ? 'items-end' : 'items-start'
      )}>
        {/* Header - only for bot messages if needed (hidden for cleaner UI) */}
        {messageHeader && !isUserMessage && false && (
          <div className="text-xs text-muted-foreground px-2">
            {messageHeader}
          </div>
        )}
        
        {/* Message content bubble */}
        <div className={cn(
          'rounded-2xl px-4 py-2.5 text-sm break-words',
          'shadow-sm',
          isUserMessage 
            ? 'bg-primary text-primary-foreground' 
            : isBotMessage
            ? 'bg-muted text-foreground border border-border/50'
            : messageClass
        )}>
          {message.content ? (
            <div className="prose prose-sm max-w-none dark:prose-invert [&_p]:my-1 [&_ul]:my-1 [&_ol]:my-1">
              <Markdown>{message.content}</Markdown>
            </div>
          ) : (
            <span className="text-muted-foreground italic">(no content)</span>
          )}
        </div>
        
        {/* Timestamp - subtle, below message */}
        {message.created_at && (
          <div className="text-xs text-muted-foreground px-2 opacity-70">
            {formatIstTime(message.created_at)}
          </div>
        )}
      </div>
      
      {/* Avatar - only show for user messages on right */}
      {isUserMessage && (
        <div className="flex-shrink-0">
          <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
            {avatarIcon}
          </div>
        </div>
      )}
      
      {/* Debug buttons - only show on hover for developers */}
      {false && (message.content || message.metadata) && (
        <div className="flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity flex gap-1 items-start pt-1">
          {message.content && (
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="ghost" size="icon" className="w-6 h-6 h-6">
                  <Icons.code className="w-3 h-3" />
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-4xl max-h-[calc(100vh-2rem)] overflow-hidden p-0 gap-0">
                <DialogTitle className="text-sm font-semibold px-2 py-3 border-b">
                  Raw Message Content {message.type}
                </DialogTitle>
                <ScrollArea className="max-h-[calc(100vh-var(--header-height))] text-sm bg-muted/20">
                  <pre className="whitespace-pre-wrap p-2">
                    <code>{message.content}</code>
                  </pre>
                </ScrollArea>
              </DialogContent>
            </Dialog>
          )}
          
          {message.metadata && (
            <HoverCard>
              <HoverCardTrigger asChild>
                <Button variant="ghost" size="icon" className="w-6 h-6">
                  <Icons.info className="w-3 h-3" />
                </Button>
              </HoverCardTrigger>
              <HoverCardContent
                side="left"
                align="start"
                sideOffset={10}
                className="z-50 p-2 w-[calc(100vw-4rem)] text-xs sm:w-[500px] lg:w-[600px] overflow-y-auto max-h-[calc(100vh-4rem)]"
              >
                <SyntaxHighlighter
                  language="json"
                  className="text-xs bg-muted/80 backdrop-blur-sm"
                >
                  {JSON.stringify(message.metadata, null, 2)}
                </SyntaxHighlighter>
              </HoverCardContent>
            </HoverCard>
          )}
        </div>
      )}
    </div>
  );
};

/**
 * Filter messages to show:
 * - User messages
 * - Assistant messages (conversational responses)
 * - Summary messages (final answer)
 * - Status messages (completed, failed, running, etc.)
 */
const filterMessages = (messages) => {
  return messages.filter((message) => {
    // ✅ Always keep user messages
    if (message.type === 'user') {
      return true;
    }
    
    // ✅ Always keep assistant messages (conversational responses from the agent)
    if (message.type === 'assistant' && message.content) {
      if (message.sender === 'User' || message.metadata?.tool_info || looksLikeRawPayload(message.content)) {
        return false;
      }
      // Filter out empty assistant messages and status-only messages
      const content = message.content.trim();
      if (!content || content === '__STATUS_COMPLETED__ DONE') {
        return false;
      }
      return true;
    }
    
    // ✅ Always keep summary messages (these are the final answers)
    if (message.type === 'summary') {
      return !looksLikeRawPayload(message.content);
    }
    
    // ✅ Always keep status messages (completed, failed, running, etc.)
    const content = message.content || '';
    if (
      content.startsWith('__STATUS_') ||
      content.startsWith(StatusMessage.completed) ||
      content.startsWith(StatusMessage.running) ||
      content.startsWith(StatusMessage.receivedHumanInput) ||
      content.startsWith(StatusMessage.waitForHumanInput)
    ) {
      return true;
    }
    
    // ✅ Filter out everything else
    return false;
  });
};

export const MessageList = ({ chat, messages, className }) => {
  // Filter messages before displaying
  const filteredMessages = filterMessages(messages);
  
  return (
    <>
      {filteredMessages.map((message, index) => (
        <MessageBubble
          key={message.id || index}
          chat={chat}
          message={message}
          className={className}
        />
      ))}
    </>
  );
}; 