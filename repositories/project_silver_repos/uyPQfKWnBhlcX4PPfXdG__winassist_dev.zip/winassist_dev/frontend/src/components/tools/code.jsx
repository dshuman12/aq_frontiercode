import CodeMirror from '@uiw/react-codemirror';
import { python } from '@codemirror/lang-python';
import clsx from 'clsx';
import { useEffect, useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTool } from '../../hooks/tool';
import { Icons } from '../ui/icons';
import { Button } from '../ui/button';
import { cn } from '../../lib/utils';
import { useToast } from '../../hooks/toast';

const CodeEditor = ({
  toolId,
  className,
}) => {
  const { tool, updateTool, isUpdating } = useTool(toolId);
  const navigate = useNavigate();
  const [isGenerating, setIsGenerating] = useState(false);
  const [isExtracting, setIsExtracting] = useState(false);
  const [code, setCode] = useState('');
  const hasSyncedFromToolRef = useRef(false);

  const { toast } = useToast();

  // Reset sync flag when switching tools so we load the new tool's code
  useEffect(() => {
    hasSyncedFromToolRef.current = false;
  }, [toolId]);

  // Load code from server only once when tool data is available (no auto-save on every keystroke)
  useEffect(() => {
    if (tool?.code == null || hasSyncedFromToolRef.current) return;
    hasSyncedFromToolRef.current = true;
    setCode(tool.code);
  }, [tool?.code, tool?.id]);

  const hasUnsavedChanges = (tool?.code ?? '') !== (code ?? '');

  const handleGenerateCode = async () => {
    setIsGenerating(true);
    try {
      
      const payload = {
        name: tool?.name || '',
        description: tool?.description || '', 
        variables: tool?.variables || [],
        code: tool?.code || ''
      };

      const { apiRequest } = await import('../../lib/api-client');
      const generatedFunc = await apiRequest('/codegen/tool', {
        method: 'POST',
        body: payload,
        showErrorToast: false,
      });

      if (generatedFunc) {
        

        setCode(generatedFunc.code);
        

        const savedTool = await updateTool({ 
          code: generatedFunc.code,
          description: generatedFunc.description || tool?.description
        });
        if (savedTool && String(savedTool.id) !== String(toolId) && String(savedTool.uuid || '') !== String(toolId)) {
          navigate(`/tools/${savedTool.uuid || savedTool.id}`, { replace: true });
        }
        
        

        toast({
          title: 'Code Generated Successfully',
          description: 'The generated code has been saved to your tool.',
        });
      }
    } catch (error) {
      console.error('An error occurred while generating code:', error);

      toast({
        title: 'Error Generating Code',
        description: 'An unexpected error occurred. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const extractMeta = async (code) => {
    setIsExtracting(true);
    try {
      const { apiRequest } = await import('../../lib/api-client');
      const extractedMeta = await apiRequest('/codegen/extract', {
        method: 'POST',
        body: { code },
        showErrorToast: false,
      });
      return extractedMeta;
    } catch (error) {
      console.error('An error occurred while extracting meta:', error);
    } finally {
      setIsExtracting(false);
    }
  };

  return (
    <div
      className={cn('relative flex flex-col w-full h-full gap-2', className)}
    >
      <CodeMirror
        value={code ?? ''}
        height="100%"
        minHeight="400px"
        basicSetup={{ lineNumbers: true }}
        extensions={[python()]}
        onChange={(value) => setCode(value)}
        style={{ fontSize: '0.75rem', height: '100%' }}
      />
      <div
        className={clsx('absolute flex items-center gap-1', {
          'right-2 top-2 translate-x-0 translate-y-0': code !== '',
          'left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2': code === '',
        })}
      >
        <Button
          variant={code ? 'outline' : 'default'}
          size="sm"
          className="gap-1"
          onClick={handleGenerateCode}
          disabled={isGenerating || !tool}
        >
          {isGenerating ? (
            <Icons.spinner className="w-4 h-4 animate-spin" />
          ) : (
            <Icons.sparkles className="w-4 h-4" />
          )}
          <span>Generate code</span>
        </Button>
        
        {code && (
          <Button
            variant={hasUnsavedChanges ? 'default' : 'outline'}
            size="sm"
            className={cn('gap-1', hasUnsavedChanges && 'ring-2 ring-amber-400')}
            onClick={async () => {
              try {
                const savedTool = await updateTool({ code });
                if (savedTool && String(savedTool.id) !== String(toolId) && String(savedTool.uuid || '') !== String(toolId)) {
                  navigate(`/tools/${savedTool.uuid || savedTool.id}`, { replace: true });
                }
                toast({
                  title: 'Code Saved',
                  description: 'Your changes have been saved.',
                });
              } catch (err) {
                console.error('Save failed:', err);
                toast({
                  title: 'Save Failed',
                  description: err?.message || 'Could not save code. Check your connection and try again.',
                  variant: 'destructive',
                });
              }
            }}
            disabled={isUpdating || !hasUnsavedChanges}
          >
            {isUpdating ? (
              <Icons.spinner className="w-4 h-4 animate-spin" />
            ) : (
              <Icons.check className="w-4 h-4" />
            )}
            <span>{hasUnsavedChanges ? 'Save changes' : 'Saved'}</span>
          </Button>
        )}
      </div>
    </div>
  );
};

export default CodeEditor;