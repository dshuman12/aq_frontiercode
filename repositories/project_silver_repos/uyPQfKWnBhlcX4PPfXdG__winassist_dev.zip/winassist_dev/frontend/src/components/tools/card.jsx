import { useTool } from '../../hooks/tool';
import { useUser } from '../../hooks/user';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

import { Icons } from '../ui/icons';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { cn } from '../../lib/utils';
import { Badge } from '../ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogFooter,
  DialogTitle,
  DialogDescription,
} from '../ui/dialog';

export const ToolCard = ({ tool, selected, className, ...props }) => {
  const navigate = useNavigate();
  const { userId } = useUser();
  const { deleteTool, updateTool, isDeleting, isUpdating } = useTool(tool.id);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [renameDialogOpen, setRenameDialogOpen] = useState(false);
  const [pendingName, setPendingName] = useState(tool.name || '');
  const isOwned = tool.user_id === userId;

  const handleDeleteClick = (e) => {
    e.stopPropagation();
    e.preventDefault();
    setDeleteDialogOpen(true);
  };

  const handleConfirmDelete = async (e) => {
    e?.stopPropagation();
    e?.preventDefault();
    setDeleteDialogOpen(false);
    await deleteTool();
  };

  const handleEdit = (e) => {
    e.stopPropagation();
    navigate(`/tools/${tool.uuid || tool.id}`);
  };

  const handleRenameClick = (e) => {
    e.stopPropagation();
    e.preventDefault();
    setPendingName(tool.name || '');
    setRenameDialogOpen(true);
  };

  const handleRenameSubmit = async (e) => {
    e?.stopPropagation();
    e?.preventDefault();
    const nextName = pendingName.trim();
    if (!nextName || nextName === tool.name) {
      setRenameDialogOpen(false);
      return;
    }
    await updateTool({ name: nextName });
    setRenameDialogOpen(false);
  };

  return (
    <div
      className={cn(
        'relative group flex h-full w-full min-w-0 cursor-pointer flex-col rounded-xl border border-border/70 bg-background p-4 shadow-sm transition-all duration-200',
        'hover:-translate-y-0.5 hover:border-primary/20 hover:shadow-md',
        selected
          ? 'border-primary/30 shadow-md ring-1 ring-primary/10'
          : '',
        className
      )}
      {...props}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <div className="break-words text-base font-semibold leading-6 text-foreground">
            {tool.name}
          </div>
        </div>
        <div className="flex shrink-0 items-start gap-1.5">
          {tool.is_public && (
            <Badge variant="outline" className="mt-0.5 text-xs">
              Public
            </Badge>
          )}
          {!tool.is_public && (
            <div className="hidden items-center gap-1.5 group-hover:flex">
              {isOwned && (
                <Button
                  onClick={handleRenameClick}
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 shrink-0"
                  title="Rename tool"
                >
                  <Icons.edit className="w-4 h-4" />
                </Button>
              )}
              {isOwned && (
                <Button
                  onClick={handleEdit}
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 shrink-0"
                  title="Edit tool"
                >
                  <Icons.edit className="w-4 h-4" />
                </Button>
              )}
              <Button
                variant="ghost"
                size="icon"
                onClick={handleDeleteClick}
                className="h-8 w-8 shrink-0 text-red-600 hover:bg-red-500/10 hover:text-red-700"
                title="Delete tool"
              >
                {isDeleting ? (
                  <Icons.spinner className="w-4 h-4 animate-spin" />
                ) : (
                  <Icons.trash className="w-4 h-4" />
                )}
              </Button>
            </div>
          )}
        </div>
      </div>
      <div className="min-h-0 flex-1">
        <p className="line-clamp-4 break-words text-sm leading-6 text-muted-foreground">
          {tool.description || 'No description available.'}
        </p>
      </div>

      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent
          className="bg-background border-border"
          onPointerDownOutside={(e) => e.stopPropagation()}
          onInteractOutside={(e) => e.stopPropagation()}
        >
          <DialogHeader>
            <DialogTitle>Delete tool</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete &quot;{tool.name}&quot;? This cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button
              variant="outline"
              onClick={(e) => {
                e.stopPropagation();
                setDeleteDialogOpen(false);
              }}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={handleConfirmDelete}
              disabled={isDeleting}
            >
              {isDeleting ? (
                <Icons.spinner className="w-4 h-4 animate-spin mr-2" />
              ) : null}
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={renameDialogOpen} onOpenChange={setRenameDialogOpen}>
        <DialogContent
          className="bg-background border-border"
          onPointerDownOutside={(e) => e.stopPropagation()}
          onInteractOutside={(e) => e.stopPropagation()}
        >
          <DialogHeader>
            <DialogTitle>Rename private tool</DialogTitle>
            <DialogDescription>
              Update the display name for your private tool.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <Input
              value={pendingName}
              onChange={(e) => setPendingName(e.target.value)}
              placeholder="Tool name"
              maxLength={120}
              autoFocus
            />
          </div>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button
              variant="outline"
              onClick={(e) => {
                e.stopPropagation();
                setRenameDialogOpen(false);
              }}
            >
              Cancel
            </Button>
            <Button
              onClick={handleRenameSubmit}
              disabled={isUpdating || !pendingName.trim()}
            >
              {isUpdating ? (
                <Icons.spinner className="w-4 h-4 animate-spin mr-2" />
              ) : null}
              Save name
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};