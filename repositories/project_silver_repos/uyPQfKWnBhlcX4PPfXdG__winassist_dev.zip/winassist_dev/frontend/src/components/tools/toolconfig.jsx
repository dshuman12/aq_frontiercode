import React, { useState, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Switch } from '../ui/switch';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { ScrollArea } from '../ui/scrollarea';
import { Badge } from '../ui/badge';
import { Icons } from '../ui/icons';
import { cn } from '../../lib/utils';
import { useTools } from '../../hooks/tool';
import useUserStore from '../../store/user';
import { useToast } from '../../hooks/toast';
import { apiRequest } from '../../lib/api-client';

export const ToolParameterConfig = ({
  tool,
  isOpen,
  onClose,
  onSave,
  initialValues = {},
  nodeId = 'default',
  nodeName = 'default',
  agentId,
}) => {
  const [parameterValues, setParameterValues] = useState({})
  const [errors, setErrors] = useState({})
  const [isSaving, setIsSaving] = useState(false)
  const [isLoadingFromBackend, setIsLoadingFromBackend] = useState(false)

  const { saveToolParameterConfig, getToolParameterConfigs } = useTools()
  const { toast } = useToast()

  const currentNodeIdRef = useRef(nodeId)
  const isInitializedRef = useRef(false)

  // Convert variables (backend) to parameters (frontend) format
  const getParameters = () => {
    if (tool?.variables && Array.isArray(tool.variables)) {
      return tool.variables.map(variable => {
        let description = variable.description || '';
        
        // Extract type from description marker [TYPE:xxx] if present
        let paramType = 'string'; // default
        const typeMatch = description.match(/\[TYPE:([^\]]+)\]/);
        if (typeMatch) {
          const extractedType = typeMatch[1].toLowerCase().trim();
          // Map Python types and custom types to frontend types
          if (extractedType === 'int' || extractedType === 'float' || extractedType === 'number') {
            paramType = 'number';
          } else if (extractedType === 'bool' || extractedType === 'boolean') {
            paramType = 'boolean';
          } else if (extractedType === 'str' || extractedType === 'string') {
            paramType = 'string';
          } else if (extractedType === 'file') {
            paramType = 'file';
          } else if (extractedType === 'textarea') {
            paramType = 'textarea';
          } else if (extractedType === 'select') {
            paramType = 'select';
          } else if (extractedType === 'dict' || extractedType === 'dictionary') {
            paramType = 'dict';
          } else {
            // If it's not a recognized type, default to string
            paramType = 'string';
          }
          // Remove type marker from description
          description = description.replace(/\[TYPE:[^\]]+\]\s*/g, '').trim();
        } else {
          // Fallback to inferring from value if no type marker
          paramType = typeof variable.value === 'boolean' ? 'boolean' : 
                      typeof variable.value === 'number' ? 'number' : 'string';
        }
        
        // Extract required flag from description
        const isRequired = description.includes('[REQUIRED]');
        if (isRequired) {
          description = description.replace('[REQUIRED]', '').trim();
        }
        
        return {
          name: variable.name,
          type: paramType,
          description: description,
          required: isRequired,
          default: variable.default !== undefined ? variable.default : variable.value,
          options: [],
          validation: {}
        };
      });
    }
    // Fallback to tool.parameters if it exists (for backward compatibility)
    return tool?.parameters || []
  }

  const getDefaultValues = () => {
    const defaults = {}
    const parameters = getParameters()

    if (parameters.length) {
      parameters.forEach((param) => {
        if (param.default !== undefined) {
          defaults[param.name] = param.default
        } else {
          switch (param.type) {
            case 'string':
            case 'textarea':
              defaults[param.name] = ''
              break
            case 'number':
              defaults[param.name] = 0
              break
            case 'boolean':
              defaults[param.name] = false
              break
            case 'select':
              defaults[param.name] = param.options?.[0] || ''
              break
            case 'dict':
              defaults[param.name] = {}
              break
            default:
              defaults[param.name] = ''
          }
        }
      })
    }

    return defaults
  }

  useEffect(() => {
    if (!isOpen || !tool || !agentId) return

    const hasNodeChanged = currentNodeIdRef.current !== nodeId

    if (!isInitializedRef.current || hasNodeChanged) {
      const loadParameters = async () => {
        setIsLoadingFromBackend(true)
        try {
          const defaults = getDefaultValues()
          
          // Prioritize initialValues (from node data) over backend
          let savedParams = {}
          if (Object.keys(initialValues || {}).length > 0) {
            // Use initialValues from node data (most reliable)
            savedParams = initialValues
          } else {
            // Fallback to backend if no initialValues
            try {
              savedParams = await getToolParameterConfigs(
                tool.id,
                nodeId,
                agentId
              )
            } catch (err) {
              // Backend endpoint doesn't exist (404), that's okay
              undefined
            }
          }

          const finalValues = {
            ...defaults,
            ...savedParams,
            ...initialValues, // initialValues override everything
          }

          setParameterValues(finalValues)
          setErrors({})

          currentNodeIdRef.current = nodeId
          isInitializedRef.current = true
        } catch (err) {
          const defaults = getDefaultValues()
          setParameterValues({ ...defaults, ...initialValues })
        } finally {
          setIsLoadingFromBackend(false)
        }
      }

      loadParameters()
    }
  }, [isOpen, nodeId, tool?.id, agentId, initialValues])

  useEffect(() => {
    if (!isOpen) {
      isInitializedRef.current = false
    }
  }, [isOpen])

  const validateParameter = (param, value) => {
    if (param.required && (value === undefined || value === null || value === '')) {
      return `${param.name} is required`
    }

    if (param.type === 'number' && value !== '' && isNaN(Number(value))) {
      return `${param.name} must be a valid number`
    }

    if (param.validation) {
      const { min, max, pattern } = param.validation
      if (min !== undefined && Number(value) < min) {
        return `${param.name} must be at least ${min}`
      }
      if (max !== undefined && Number(value) > max) {
        return `${param.name} must be at most ${max}`
      }
      if (pattern && !new RegExp(pattern).test(value)) {
        return `${param.name} format is invalid`
      }
    }

    return null
  }

  const handleParameterChange = (name, value) => {
    setParameterValues((prev) => ({ ...prev, [name]: value }))
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: '' }))
    }
  }

  const handleSave = async () => {
    const parameters = getParameters()
    if (!parameters || parameters.length === 0) return

    const newErrors = {}
    let hasErrors = false

    parameters.forEach((param) => {
      const err = validateParameter(param, parameterValues[param.name])
      if (err) {
        newErrors[param.name] = err
        hasErrors = true
      }
    })

    setErrors(newErrors)

    if (hasErrors) {
      toast({
        title: 'Validation Error',
        description: 'Please fix the errors before saving',
        variant: 'destructive',
      })
      return
    }

    // Note: agentId is not required since parameters are saved to node data, not backend
    // The check is removed to allow saving even when projectId is not in URL params

    setIsSaving(true)
    try {
      await saveToolParameterConfig(
        tool.id,
        nodeId,
        agentId,
        parameterValues
      )

      toast({
        title: 'Success',
        description: 'Tool parameters saved successfully',
      })

      onSave(parameterValues)
      onClose()
    } catch (err) {
      toast({
        title: 'Error',
        description: 'Failed to save tool parameters',
        variant: 'destructive',
      })
    } finally {
      setIsSaving(false)
    }
  }

  if (!tool || !isOpen) return null

  return createPortal(
    <div className="fixed inset-0 z-50 flex justify-end">
      <Card className="w-96 h-full rounded-none border-l shadow-lg">
        {/* HEADER */}
        <CardHeader className="border-b">
          <div className="flex justify-between">
            <div className="flex gap-2">
              <Icons.tool className="w-5 h-5" />
              <CardTitle>{tool.name}</CardTitle>
            </div>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <Icons.close className="w-4 h-4" />
            </Button>
          </div>
          {tool.description && (
            <CardDescription>{tool.description}</CardDescription>
          )}
        </CardHeader>

        {/* CONTENT */}
        <CardContent className="p-0">
          <ScrollArea className="h-[calc(100vh-200px)]">
            <div className="p-6 space-y-6">
              {getParameters().length === 0 ? (
                <div className="text-center text-muted-foreground py-8">
                  <p>No parameters available for this tool</p>
                </div>
              ) : (
                getParameters().map((param) => (
                  <div key={param.name} className="space-y-2">
                    <Label>
                      {param.name}
                      {param.required && (
                        <span className="text-red-500 ml-1">*</span>
                      )}
                    </Label>
                    {param.description && (
                      <p className="text-sm text-muted-foreground">{param.description}</p>
                    )}
                    <div className="space-y-2">
                      {param.type === 'string' || param.type === 'textarea' ? (
                        <Textarea
                          value={parameterValues[param.name] || param.default || ''}
                          onChange={(e) => handleParameterChange(param.name, e.target.value)}
                          placeholder={`Enter ${param.name}`}
                          className={cn(errors[param.name] && 'border-red-500')}
                        />
                      ) : param.type === 'number' ? (
                        <Input
                          type="number"
                          value={parameterValues[param.name] ?? param.default ?? ''}
                          onChange={(e) => handleParameterChange(param.name, Number(e.target.value))}
                          placeholder={`Enter ${param.name}`}
                          className={cn(errors[param.name] && 'border-red-500')}
                        />
                      ) : param.type === 'boolean' ? (
                        <Switch
                          checked={parameterValues[param.name] ?? param.default ?? false}
                          onCheckedChange={(checked) => handleParameterChange(param.name, checked)}
                        />
                      ) : param.type === 'file' ? (
                        <div className="space-y-2">
                          <Input
                            type="file"
                            disabled={isSaving}
                            onChange={async (e) => {
                              const file = e.target.files?.[0];
                              if (!file) return;
                              
                              try {
                                // Upload file to get absolute path
                                const form = new FormData();
                                form.append('file', file);
                                form.append('title', file.name);
                                
                                const json = await apiRequest('/tools/attachments', {
                                  method: 'POST',
                                  body: form,
                                  showErrorToast: false,
                                });
                                // Store absolute path as parameter value so tool can read it
                                handleParameterChange(param.name, json.path);
                                
                                toast({
                                  title: 'File uploaded',
                                  description: `${file.name} uploaded successfully`,
                                });
                              } catch (err) {
                                console.error('Attachment upload failed', err);
                                toast({
                                  title: 'Upload failed',
                                  description: err.message || 'Failed to upload file',
                                  variant: 'destructive',
                                });
                              } finally {
                                // Reset file input
                                e.target.value = '';
                              }
                            }}
                            className={cn(errors[param.name] && 'border-red-500')}
                          />
                          {parameterValues[param.name] && (
                            <p className="text-xs text-muted-foreground break-all">
                              {parameterValues[param.name]}
                            </p>
                          )}
                        </div>
                      ) : (
                        <Input
                          value={parameterValues[param.name] || param.default || ''}
                          onChange={(e) => handleParameterChange(param.name, e.target.value)}
                          placeholder={`Enter ${param.name}`}
                          className={cn(errors[param.name] && 'border-red-500')}
                        />
                      )}
                      {errors[param.name] && (
                        <p className="text-sm text-red-500">{errors[param.name]}</p>
                      )}
                    </div>
                    <Badge variant="secondary">{param.type}</Badge>
                  </div>
                ))
              )}
            </div>
          </ScrollArea>
        </CardContent>

        {/* FOOTER */}
        <div className="border-t p-4 flex gap-2">
          <Button variant="outline" onClick={onClose} className="flex-1">
            Cancel
          </Button>
          <Button onClick={handleSave} className="flex-1">
            Save Parameters
          </Button>
        </div>
      </Card>
    </div>,
    document.body
  )
}