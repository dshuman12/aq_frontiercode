import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom';
import { AuthProvider } from 'react-oidc-context';
import './index.css'
import App from './App.jsx'
import oidcConfig, { isOidcConfigured } from './common/oidc/oidc-Config'
import { ThemeProvider } from './components/shared/theme-provider';

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <ThemeProvider>
      {isOidcConfigured ? (
        <AuthProvider {...oidcConfig}>
          <BrowserRouter>
            <App />
          </BrowserRouter>
        </AuthProvider>
      ) : (
        <BrowserRouter>
          <App />
        </BrowserRouter>
      )}
    </ThemeProvider>
  </StrictMode>,
)
