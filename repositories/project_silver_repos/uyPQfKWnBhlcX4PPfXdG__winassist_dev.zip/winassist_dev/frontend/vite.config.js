


// import { defineConfig } from 'vite'
// import react from '@vitejs/plugin-react-swc'

// export default defineConfig({
//   plugins: [react()],

//   envPrefix: 'VITE_',

//   server: {
//     host: '0.0.0.0', // allow external access
//     port: 5173,
//     strictPort: true
//   }
// })





import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react-swc'

export default defineConfig({
  plugins: [react()],
  envPrefix: "VITE_",
  server: {
    host: true,
    port: 5173,
    strictPort: true
  }
})