//! Matching policy abstraction.
//!
//! The matching engine itself is a thin orchestrator: it takes orders
//! in, manages the book, and emits events. *How* an aggressor consumes
//! a price level — strict FIFO vs pro-rata vs hybrid — is delegated to
//! a `MatchingPolicy`.
//!
//! This separation matters because real venues run different policies
//! per product (e.g. equity options pro-rata, crypto BTC perp price-time)
//! and we want the engine code to read the same regardless. It also
//! makes the policies independently testable.

use std::fmt;

use meridian_common::prelude::*;
use meridian_order_book::PriceLevel;

use crate::pro_rata::ProRataPolicy;

/// One unit of allocation: "this order should be filled `qty` against
/// the aggressor at this price level".
///
/// Index into the level's queue is the position the policy thinks the
/// order is at. Position-based addressing is the only way that's robust
/// to in-flight cancels and STP cancels triggered mid-allocation.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Allocation {
    pub queue_position: usize,
    pub order_id: OrderId,
    pub fill_qty: Quantity,
}

/// What the policy is allowed to do at a price level.
///
/// We pass the level by ref + the remaining aggressor qty; the policy
/// returns a vector of allocations that the engine then applies in
/// order. The policy must not mutate the book — that's the engine's
/// job. Returning allocations is what makes the contract pure
/// (and therefore testable).
pub trait MatchingPolicy: fmt::Debug + Send + Sync + 'static {
    /// Human-readable name, used in metrics labels.
    fn name(&self) -> &'static str;

    /// Allocate up to `incoming_remaining` against the visible orders
    /// at `level`. Implementations *must* return allocations whose
    /// total qty is ≤ `incoming_remaining`, and ≤ the level's
    /// `visible_qty()`. Order ids must be unique within the result.
    fn allocate(&self, level: &PriceLevel, incoming_remaining: Quantity) -> Vec<Allocation>;

    /// Hook for the policy to react when an iceberg slice is exhausted
    /// and the hidden portion is being revealed. Pro-rata policies
    /// in particular care because it changes the weights used in the
    /// next allocation pass; price-time can ignore.
    fn on_iceberg_refresh(&self, _level: &PriceLevel, _order_id: OrderId) {}
}

/// Top-level enum dispatch — handy when callers need a single field
/// type. Production paths use the trait object for flexibility.
#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum PolicyKind {
    PriceTime,
    ProRata,
    /// Top-of-book carve-out (10% of incoming) goes to the time
    /// leader; the remainder is pro-rata-allocated. Common in agri /
    /// rates futures.
    Hybrid,
}

impl PolicyKind {
    #[must_use]
    pub fn build(self) -> Box<dyn MatchingPolicy> {
        match self {
            Self::PriceTime => Box::new(PriceTimePolicy),
            Self::ProRata => Box::new(ProRataPolicy::new()),
            Self::Hybrid => Box::new(HybridPolicy::new(10)),
        }
    }
}

/// Strict price-time priority. Fill the head of the queue until either
/// the aggressor is out of qty or the level is empty.
#[derive(Debug, Clone, Copy, Default)]
pub struct PriceTimePolicy;

impl MatchingPolicy for PriceTimePolicy {
    fn name(&self) -> &'static str {
        "price_time"
    }

    fn allocate(&self, level: &PriceLevel, incoming_remaining: Quantity) -> Vec<Allocation> {
        let mut out = Vec::new();
        let mut remaining = incoming_remaining;
        for (idx, order) in level.iter().enumerate() {
            if remaining.is_zero() {
                break;
            }
            let avail = order.visible_qty();
            if avail.is_zero() {
                // Hidden-only slots happen mid-iceberg-refresh; the
                // policy ignores them and lets the engine refresh.
                continue;
            }
            let take = avail.min(remaining);
            out.push(Allocation {
                queue_position: idx,
                order_id: order.order_id,
                fill_qty: take,
            });
            remaining -= take;
        }
        out
    }
}

/// Hybrid: a fixed percentage of the aggressor goes to the time leader
/// (the head of the queue), the remainder is pro-rata.
///
/// `top_of_book_pct` is in whole percent (0–100). 0 collapses to pure
/// pro-rata; 100 collapses to pure price-time.
#[derive(Debug, Clone)]
pub struct HybridPolicy {
    top_of_book_pct: u8,
    pro_rata: ProRataPolicy,
}

impl HybridPolicy {
    #[must_use]
    pub fn new(top_of_book_pct: u8) -> Self {
        debug_assert!(top_of_book_pct <= 100);
        Self {
            top_of_book_pct,
            pro_rata: ProRataPolicy::new(),
        }
    }
}

impl MatchingPolicy for HybridPolicy {
    fn name(&self) -> &'static str {
        "hybrid"
    }

    fn allocate(&self, level: &PriceLevel, incoming_remaining: Quantity) -> Vec<Allocation> {
        if self.top_of_book_pct == 0 || level.is_empty() {
            return self.pro_rata.allocate(level, incoming_remaining);
        }
        if self.top_of_book_pct == 100 {
            return PriceTimePolicy.allocate(level, incoming_remaining);
        }

        // Carve out top-of-book share.
        let pct = rust_decimal::Decimal::from(self.top_of_book_pct);
        let hundred = rust_decimal::Decimal::from(100);
        let carve_d = (incoming_remaining.into_decimal() * pct) / hundred;
        let carve = Quantity::from_decimal(carve_d);

        let mut out = Vec::new();
        let head = level.peek_front().expect("non-empty checked above");
        let head_take = head.visible_qty().min(carve);
        if !head_take.is_zero() {
            out.push(Allocation {
                queue_position: 0,
                order_id: head.order_id,
                fill_qty: head_take,
            });
        }

        // Pro-rata the remainder against the remaining queue.
        let remainder = incoming_remaining - head_take;
        if remainder.is_zero() {
            return out;
        }

        // For the pro-rata sub-pass we need to skip the head. We
        // re-issue against a clone of the queue tail. The
        // queue_position offsets are corrected to the original level.
        let pro_rata = self.pro_rata.allocate_skipping(level, 1, remainder);
        out.extend(pro_rata);

        out
    }
}

#[cfg(test)]
mod tests {
    use meridian_order_book::RestingOrder;
    use meridian_order_types::OrderType;
    use meridian_order_types::Side;
    use rust_decimal_macros::dec;

    use super::*;

    fn ord(id: u128, qty: i64, seq: u64) -> RestingOrder {
        RestingOrder {
            order_id: OrderId::new(id),
            account_id: AccountId::new(1),
            side: Side::Sell,
            order_type: OrderType::Limit,
            leaves_qty: Quantity::from_int(qty),
            display_qty: None,
            hidden_qty: None,
            price: Price::from_decimal(dec!(100)),
            priority_seq: SeqNo::new(seq),
            post_only: false,
        }
    }

    fn level_with(orders: &[RestingOrder]) -> PriceLevel {
        let mut l = PriceLevel::new(Price::from_decimal(dec!(100)));
        for o in orders {
            l.push_back(o.clone());
        }
        l
    }

    #[test]
    fn price_time_eats_in_order() {
        let lvl = level_with(&[ord(1, 5, 1), ord(2, 3, 2), ord(3, 7, 3)]);
        let allocs = PriceTimePolicy.allocate(&lvl, Quantity::from_int(6));
        assert_eq!(allocs.len(), 2);
        assert_eq!(allocs[0].order_id, OrderId::new(1));
        assert_eq!(allocs[0].fill_qty, Quantity::from_int(5));
        assert_eq!(allocs[1].order_id, OrderId::new(2));
        assert_eq!(allocs[1].fill_qty, Quantity::from_int(1));
    }

    #[test]
    fn price_time_caps_at_visible() {
        let lvl = level_with(&[ord(1, 2, 1)]);
        let allocs = PriceTimePolicy.allocate(&lvl, Quantity::from_int(10));
        assert_eq!(allocs.len(), 1);
        assert_eq!(allocs[0].fill_qty, Quantity::from_int(2));
    }

    #[test]
    fn hybrid_collapses_to_price_time_at_100() {
        let p = HybridPolicy::new(100);
        let lvl = level_with(&[ord(1, 5, 1), ord(2, 5, 2)]);
        let allocs = p.allocate(&lvl, Quantity::from_int(7));
        assert_eq!(allocs[0].order_id, OrderId::new(1));
        assert_eq!(allocs[0].fill_qty, Quantity::from_int(5));
        assert_eq!(allocs[1].fill_qty, Quantity::from_int(2));
    }
}
