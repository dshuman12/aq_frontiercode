//! Engine errors.

use meridian_common::Error as CommonError;
use meridian_order_types::OrderError;
use thiserror::Error;

pub type EngineResult<T> = Result<T, EngineError>;

#[derive(Debug, Error)]
pub enum EngineError {
    #[error(transparent)]
    Order(#[from] OrderError),

    #[error("symbol mismatch: engine='{expected}', command='{actual}'")]
    SymbolMismatch { expected: String, actual: String },

    #[error("order with id {0} already exists")]
    DuplicateOrderId(String),

    #[error("unknown order id: {0}")]
    UnknownOrder(String),

    #[error("order not amendable in current state")]
    NotAmendable,

    #[error("session not accepting new orders ({0:?})")]
    SessionRefuses(crate::session::SessionState),

    #[error("post-only order would cross")]
    PostOnlyCross,

    #[error("FOK order would not fully fill")]
    FokWouldNotFill,

    #[error("insufficient marketable liquidity")]
    NoMarketableLiquidity,

    #[error("kill switch engaged")]
    KillSwitched,

    #[error(transparent)]
    Common(#[from] CommonError),
}
