//! Pegged-order repricing.
//!
//! A pegged order doesn't have a fixed limit price; instead its limit
//! is computed from a *reference* (mid, primary, or market — the
//! opposite touch) plus a signed `offset_ticks`. The reference moves
//! whenever the BBO moves, so the engine has to reprice pegged orders
//! on every relevant book update.
//!
//! # Design
//!
//! - Pegged orders rest on the book at their *current* effective
//!   limit price, like any other limit order. They aren't a special
//!   queue.
//! - When the reference moves, every pegged order whose effective
//!   price would change is removed from the book, repriced, and
//!   re-inserted with a fresh `priority_seq`. Yes, this loses time
//!   priority — that's the whole point. Otherwise pegged orders would
//!   front-run vanilla limits.
//! - Repricing happens at command-edge (after the engine processes a
//!   command that moved the BBO). It does *not* happen mid-match —
//!   that would create a feedback loop.
//! - Reference values are computed against the *current* book state
//!   *after* the inducing event. The engine collects the affected
//!   orders, then applies the repricing as a batch.
//!
//! See `docs/adr/0014-peg-repricing.md`.

use meridian_common::prelude::*;
use meridian_order_book::Book;
use meridian_order_types::{OrderType, PegReference, Side};

/// What we computed for a single pegged order's repricing pass.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PegPlan {
    pub order_id: OrderId,
    pub side: Side,
    pub old_price: Price,
    pub new_price: Price,
}

/// Compute the new effective limit price for a pegged order.
///
/// Returns `None` if the reference can't be evaluated (e.g. mid-peg
/// on a one-sided book, or primary-peg with no liquidity on our side).
/// The engine treats `None` as "leave the order at its current price"
/// — it doesn't move and doesn't get cancelled.
#[must_use]
pub fn compute_effective_price(
    book: &Book,
    side: Side,
    reference: PegReference,
    offset_ticks: i32,
    tick_size: TickSize,
) -> Option<Price> {
    let reference_price = match reference {
        PegReference::Mid => book.mid_price()?,
        PegReference::Primary => match side {
            Side::Buy => book.best_bid()?,
            Side::Sell => book.best_ask()?,
        },
        PegReference::Market => match side {
            Side::Buy => book.best_ask()?,
            Side::Sell => book.best_bid()?,
        },
    };

    // Apply the signed offset. Positive `offset_ticks` always nudges
    // *away* from the touch (a buy with +1 offset peg-primary sits
    // 1 tick *below* the bid; a sell with +1 sits 1 tick *above*
    // the ask). Negative offsets are similarly symmetric.
    let dir = match side {
        Side::Buy => -1,
        Side::Sell => 1,
    };
    let total_ticks = i64::from(offset_ticks) * i64::from(dir);
    let tick_d = tick_size.0.into_decimal();
    let delta = rust_decimal::Decimal::from(total_ticks) * tick_d;
    let raw = reference_price.into_decimal() + delta;

    // Snap to a tick boundary on the safe side (rounds in the venue's
    // favour, which is "less aggressive" — buy: floor, sell: ceil).
    let snapped = if delta.is_sign_negative() || delta.is_zero() {
        // Safe direction depends only on side
        match side {
            Side::Buy => Price::from_decimal((raw / tick_d).floor() * tick_d),
            Side::Sell => Price::from_decimal((raw / tick_d).ceil() * tick_d),
        }
    } else {
        match side {
            Side::Buy => Price::from_decimal((raw / tick_d).floor() * tick_d),
            Side::Sell => Price::from_decimal((raw / tick_d).ceil() * tick_d),
        }
    };

    // Defensive: pegged limit must remain positive.
    if snapped.is_positive() {
        Some(snapped)
    } else {
        None
    }
}

/// Helper to extract the (reference, offset_ticks) from an `OrderType`
/// if it's a peg, else `None`.
#[must_use]
pub const fn peg_params(t: OrderType) -> Option<(PegReference, i32)> {
    match t {
        OrderType::Peg {
            reference,
            offset_ticks,
        } => Some((reference, offset_ticks)),
        _ => None,
    }
}

#[cfg(test)]
mod tests {
    use meridian_order_book::RestingOrder;
    use meridian_order_types::OrderType;
    use rust_decimal_macros::dec;

    use super::*;

    fn sym() -> Symbol {
        Symbol::new("BTC-USD").unwrap()
    }

    fn ord(id: u128, side: Side, price: Price, qty: i64, seq: u64) -> RestingOrder {
        RestingOrder {
            order_id: OrderId::new(id),
            account_id: AccountId::new(1),
            side,
            order_type: OrderType::Limit,
            leaves_qty: Quantity::from_int(qty),
            display_qty: None,
            hidden_qty: None,
            price,
            priority_seq: SeqNo::new(seq),
            post_only: false,
        }
    }

    fn book_with_bbo(bid: rust_decimal::Decimal, ask: rust_decimal::Decimal) -> Book {
        let mut b = Book::new(sym());
        b.insert(ord(1, Side::Buy, Price::from_decimal(bid), 1, 1));
        b.insert(ord(2, Side::Sell, Price::from_decimal(ask), 1, 2));
        b
    }

    #[test]
    fn mid_peg_centers_on_mid() {
        let b = book_with_bbo(dec!(100), dec!(102));
        let p = compute_effective_price(
            &b,
            Side::Buy,
            PegReference::Mid,
            0,
            TickSize(Price::from_decimal(dec!(0.01))),
        );
        assert_eq!(p, Some(Price::from_decimal(dec!(101))));
    }

    #[test]
    fn primary_peg_pins_to_same_side_touch() {
        let b = book_with_bbo(dec!(100), dec!(102));
        // Buy peg-primary, offset 0 → sits at the bid (100).
        let p = compute_effective_price(
            &b,
            Side::Buy,
            PegReference::Primary,
            0,
            TickSize(Price::from_decimal(dec!(0.01))),
        );
        assert_eq!(p, Some(Price::from_decimal(dec!(100))));
    }

    #[test]
    fn primary_peg_offset_pulls_away() {
        let b = book_with_bbo(dec!(100), dec!(102));
        let tick = TickSize(Price::from_decimal(dec!(0.01)));
        // Buy peg-primary, +1 tick → sits at 99.99 (1 tick *below* the bid).
        let p = compute_effective_price(&b, Side::Buy, PegReference::Primary, 1, tick);
        assert_eq!(p, Some(Price::from_decimal(dec!(99.99))));
    }

    #[test]
    fn market_peg_uses_opposite_touch() {
        let b = book_with_bbo(dec!(100), dec!(102));
        let tick = TickSize(Price::from_decimal(dec!(0.01)));
        // Buy peg-market → starts at the ask (102).
        let p = compute_effective_price(&b, Side::Buy, PegReference::Market, 0, tick);
        assert_eq!(p, Some(Price::from_decimal(dec!(102))));
    }

    #[test]
    fn one_sided_book_returns_none_for_mid() {
        let mut b = Book::new(sym());
        b.insert(ord(1, Side::Buy, Price::from_decimal(dec!(100)), 1, 1));
        let p = compute_effective_price(
            &b,
            Side::Buy,
            PegReference::Mid,
            0,
            TickSize(Price::from_decimal(dec!(0.01))),
        );
        assert!(p.is_none());
    }
}
