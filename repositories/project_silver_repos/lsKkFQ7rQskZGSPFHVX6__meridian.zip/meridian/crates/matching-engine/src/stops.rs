//! Stop / stop-limit trigger management.
//!
//! Stop orders sit *off* the book until the trigger condition fires,
//! at which point they re-enter as either a market order
//! (`Stop`) or a limit at `limit_price` (`StopLimit`).
//!
//! # Trigger conditions
//!
//! - Stop **buy** triggers when last trade price ≥ `trigger_price`.
//! - Stop **sell** triggers when last trade price ≤ `trigger_price`.
//!
//! "Last trade" is the most recent fill on this symbol. If the trade
//! doesn't reach the trigger, nothing happens. We don't peek at the
//! quote — only completed trades — to avoid being whipsawed by
//! one-tick BBO flickers without a print.
//!
//! # Storage
//!
//! Two `BTreeMap<Price, Vec<OrderId>>` — one for buy stops (ordered
//! ascending; we trigger any whose `trigger_price` is ≤ last) and one
//! for sell stops (descending; we trigger any whose `trigger_price`
//! is ≥ last). The shape is symmetric to the book itself.

use std::collections::BTreeMap;

use meridian_common::prelude::*;
use meridian_order_types::Side;

#[derive(Debug, Default)]
pub struct StopBook {
    /// Buy stops keyed by trigger price ascending. Trigger when last ≥ key.
    buys: BTreeMap<Price, Vec<OrderId>>,
    /// Sell stops keyed by trigger price ascending; we iterate from
    /// the back when last falls. Trigger when last ≤ key.
    sells: BTreeMap<Price, Vec<OrderId>>,
}

impl StopBook {
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    /// Number of pending stops.
    #[must_use]
    pub fn len(&self) -> usize {
        self.buys.values().map(Vec::len).sum::<usize>()
            + self.sells.values().map(Vec::len).sum::<usize>()
    }

    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.buys.is_empty() && self.sells.is_empty()
    }

    /// Register a stop. The engine has already validated trigger price.
    pub fn insert(&mut self, side: Side, trigger: Price, id: OrderId) {
        let target = match side {
            Side::Buy => &mut self.buys,
            Side::Sell => &mut self.sells,
        };
        target.entry(trigger).or_default().push(id);
    }

    /// Remove a stop by id at a known trigger price. Returns true if
    /// found and removed.
    pub fn remove(&mut self, side: Side, trigger: Price, id: OrderId) -> bool {
        let target = match side {
            Side::Buy => &mut self.buys,
            Side::Sell => &mut self.sells,
        };
        let Some(v) = target.get_mut(&trigger) else {
            return false;
        };
        let Some(pos) = v.iter().position(|x| *x == id) else {
            return false;
        };
        v.remove(pos);
        if v.is_empty() {
            target.remove(&trigger);
        }
        true
    }

    /// Drain every stop that `last` triggers, returning their order
    /// IDs in trigger-price order (i.e. closest-to-last first). The
    /// caller is responsible for re-injecting them into the engine
    /// matching path.
    ///
    /// We trigger:
    ///   buys whose trigger_price ≤ last;
    ///   sells whose trigger_price ≥ last.
    ///
    /// Among triggers at the same price, the order of return is the
    /// order of insertion (FIFO). Replays are deterministic because
    /// the BTreeMap iteration order is.
    pub fn fire(&mut self, last: Price) -> Vec<(Side, OrderId)> {
        let mut out = Vec::new();

        // Buys: every key ≤ last fires.
        let triggered_buy_keys: Vec<Price> = self.buys.range(..=last).map(|(k, _)| *k).collect();
        for k in triggered_buy_keys {
            if let Some(v) = self.buys.remove(&k) {
                for id in v {
                    out.push((Side::Buy, id));
                }
            }
        }

        // Sells: every key ≥ last fires.
        let triggered_sell_keys: Vec<Price> = self.sells.range(last..).map(|(k, _)| *k).collect();
        for k in triggered_sell_keys {
            if let Some(v) = self.sells.remove(&k) {
                for id in v {
                    out.push((Side::Sell, id));
                }
            }
        }

        out
    }

    /// All registered stop ids. Used by mass-cancel paths.
    pub fn iter_ids(&self) -> impl Iterator<Item = (Side, Price, OrderId)> + '_ {
        let buys = self
            .buys
            .iter()
            .flat_map(|(p, v)| v.iter().map(move |id| (Side::Buy, *p, *id)));
        let sells = self
            .sells
            .iter()
            .flat_map(|(p, v)| v.iter().map(move |id| (Side::Sell, *p, *id)));
        buys.chain(sells)
    }
}

#[cfg(test)]
mod tests {
    use rust_decimal_macros::dec;

    use super::*;

    fn p(d: rust_decimal::Decimal) -> Price {
        Price::from_decimal(d)
    }

    #[test]
    fn buy_stops_fire_at_or_above_trigger() {
        let mut s = StopBook::new();
        s.insert(Side::Buy, p(dec!(101)), OrderId::new(1));
        s.insert(Side::Buy, p(dec!(102)), OrderId::new(2));
        s.insert(Side::Buy, p(dec!(103)), OrderId::new(3));

        // Last = 101.5 → only id 1 fires.
        let fired = s.fire(p(dec!(101.5)));
        assert_eq!(fired, vec![(Side::Buy, OrderId::new(1))]);
        assert_eq!(s.len(), 2);

        // Last jumps to 103 → both remaining fire.
        let fired = s.fire(p(dec!(103)));
        assert_eq!(fired.len(), 2);
        assert!(fired.contains(&(Side::Buy, OrderId::new(2))));
        assert!(fired.contains(&(Side::Buy, OrderId::new(3))));
        assert!(s.is_empty());
    }

    #[test]
    fn sell_stops_fire_at_or_below_trigger() {
        let mut s = StopBook::new();
        s.insert(Side::Sell, p(dec!(99)), OrderId::new(1));
        s.insert(Side::Sell, p(dec!(98)), OrderId::new(2));

        let fired = s.fire(p(dec!(99)));
        assert!(fired.contains(&(Side::Sell, OrderId::new(1))));
        assert_eq!(s.len(), 1);

        let fired = s.fire(p(dec!(97.5)));
        assert!(fired.contains(&(Side::Sell, OrderId::new(2))));
        assert!(s.is_empty());
    }

    #[test]
    fn fifo_within_same_trigger_price() {
        let mut s = StopBook::new();
        s.insert(Side::Buy, p(dec!(100)), OrderId::new(1));
        s.insert(Side::Buy, p(dec!(100)), OrderId::new(2));
        s.insert(Side::Buy, p(dec!(100)), OrderId::new(3));

        let fired = s.fire(p(dec!(100)));
        assert_eq!(
            fired,
            vec![
                (Side::Buy, OrderId::new(1)),
                (Side::Buy, OrderId::new(2)),
                (Side::Buy, OrderId::new(3)),
            ]
        );
    }

    #[test]
    fn remove_works() {
        let mut s = StopBook::new();
        s.insert(Side::Buy, p(dec!(100)), OrderId::new(1));
        assert!(s.remove(Side::Buy, p(dec!(100)), OrderId::new(1)));
        assert!(s.is_empty());
        assert!(!s.remove(Side::Buy, p(dec!(100)), OrderId::new(1)));
    }
}
