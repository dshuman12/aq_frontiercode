//! Self-Trade Prevention application.
//!
//! Run *before* the fill is finalised: we look up the resting order's
//! account, compare to the aggressor's account, and short-circuit the
//! match if they're the same. The exact behaviour depends on the mode
//! the aggressor declared (or the account default if unspecified).
//!
//! Reference: <docs/adr/0011-self-trade-prevention.md>.
//!
//! # Mode semantics
//!
//! For an aggressor `T` arriving against resting `R` of the same
//! account, we have:
//!
//! | Mode               | Effect                                                                 |
//! |--------------------|------------------------------------------------------------------------|
//! | `None`             | The match proceeds (legal self-trade).                                 |
//! | `CancelNewest`     | `T` is cancelled (or its remaining qty is) — `R` stays.                |
//! | `CancelOldest`     | `R` is cancelled — `T` continues to the next resting order.            |
//! | `DecrementCancel`  | The smaller of the two is cancelled outright; the larger has its       |
//! |                    | qty decremented by the smaller's remaining qty.                        |
//! | `CancelBoth`       | Both `T` and `R` are cancelled in their entirety.                      |
//!
//! `DecrementCancel` is symmetric: it doesn't matter who's the
//! aggressor. It is the most common default because it doesn't
//! advantage one side of the pair.

use meridian_common::prelude::*;
use meridian_order_types::SelfTradePrevention;

/// What to do when STP fires for a single matchable pair.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum StpAction {
    /// No STP — proceed with the match as normal.
    Allow,
    /// Cancel the aggressor (newest); resting stays.
    CancelTaker { taker_remaining: Quantity },
    /// Cancel the resting (oldest); aggressor continues.
    CancelMaker { maker_remaining: Quantity },
    /// Cancel both in full.
    CancelBoth {
        taker_remaining: Quantity,
        maker_remaining: Quantity,
    },
    /// Cancel the smaller, decrement the larger by the smaller's qty.
    /// `decremented` is the side that survives; `cancelled_qty` is
    /// what was cancelled (the smaller's full leaves_qty).
    Decrement {
        cancelled_side: DecrementSide,
        cancelled_qty: Quantity,
    },
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum DecrementSide {
    Taker,
    Maker,
}

/// Decide what STP action to take for a (taker, maker) pair belonging
/// to the same account.
///
/// `taker_remaining` and `maker_remaining` are the *current* leaves_qty
/// at the moment we're about to match. The caller has already
/// established that the accounts match.
#[must_use]
pub fn decide(
    mode: SelfTradePrevention,
    taker_remaining: Quantity,
    maker_remaining: Quantity,
) -> StpAction {
    match mode {
        SelfTradePrevention::None => StpAction::Allow,
        SelfTradePrevention::CancelNewest => StpAction::CancelTaker { taker_remaining },
        SelfTradePrevention::CancelOldest => StpAction::CancelMaker { maker_remaining },
        SelfTradePrevention::CancelBoth => StpAction::CancelBoth {
            taker_remaining,
            maker_remaining,
        },
        SelfTradePrevention::DecrementCancel => {
            if taker_remaining <= maker_remaining {
                // Taker is the smaller side → it's the one that gets
                // cancelled; the maker keeps `maker - taker` qty.
                StpAction::Decrement {
                    cancelled_side: DecrementSide::Taker,
                    cancelled_qty: taker_remaining,
                }
            } else {
                StpAction::Decrement {
                    cancelled_side: DecrementSide::Maker,
                    cancelled_qty: maker_remaining,
                }
            }
        },
    }
}

/// Whether this STP mode would *block* a potential match, i.e. force
/// the engine to skip past this resting order rather than fill against
/// it. Useful in pre-trade checks for FOK orders that need to know
/// whether the marketable depth on the book is actually accessible.
#[must_use]
pub const fn blocks_match(mode: SelfTradePrevention) -> bool {
    !matches!(mode, SelfTradePrevention::None)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn q(n: i64) -> Quantity {
        Quantity::from_int(n)
    }

    #[test]
    fn none_allows() {
        assert_eq!(
            decide(SelfTradePrevention::None, q(1), q(1)),
            StpAction::Allow
        );
    }

    #[test]
    fn cancel_newest_kills_taker() {
        let a = decide(SelfTradePrevention::CancelNewest, q(5), q(10));
        assert_eq!(
            a,
            StpAction::CancelTaker {
                taker_remaining: q(5)
            }
        );
    }

    #[test]
    fn cancel_oldest_kills_maker() {
        let a = decide(SelfTradePrevention::CancelOldest, q(5), q(10));
        assert_eq!(
            a,
            StpAction::CancelMaker {
                maker_remaining: q(10)
            }
        );
    }

    #[test]
    fn dc_smaller_cancelled() {
        // taker is smaller → taker side cancelled
        let a = decide(SelfTradePrevention::DecrementCancel, q(3), q(7));
        assert_eq!(
            a,
            StpAction::Decrement {
                cancelled_side: DecrementSide::Taker,
                cancelled_qty: q(3),
            }
        );

        // maker is smaller → maker side cancelled
        let a = decide(SelfTradePrevention::DecrementCancel, q(10), q(2));
        assert_eq!(
            a,
            StpAction::Decrement {
                cancelled_side: DecrementSide::Maker,
                cancelled_qty: q(2),
            }
        );

        // tie → taker is the one cancelled (it's the newer order; this
        // matches CME and OKX behaviour, see ADR-0011).
        let a = decide(SelfTradePrevention::DecrementCancel, q(5), q(5));
        assert!(matches!(
            a,
            StpAction::Decrement {
                cancelled_side: DecrementSide::Taker,
                cancelled_qty,
            } if cancelled_qty == q(5)
        ));
    }

    #[test]
    fn cancel_both() {
        let a = decide(SelfTradePrevention::CancelBoth, q(3), q(7));
        assert_eq!(
            a,
            StpAction::CancelBoth {
                taker_remaining: q(3),
                maker_remaining: q(7)
            }
        );
    }

    #[test]
    fn blocks_match_predicate() {
        assert!(!blocks_match(SelfTradePrevention::None));
        assert!(blocks_match(SelfTradePrevention::CancelNewest));
        assert!(blocks_match(SelfTradePrevention::DecrementCancel));
    }
}
