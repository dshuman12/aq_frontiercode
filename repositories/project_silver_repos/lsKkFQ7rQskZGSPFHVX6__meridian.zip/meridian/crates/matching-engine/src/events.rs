//! Engine output — `EngineEvent`.
//!
//! The engine emits a stream of events for every command it processes.
//! The market-data fanout reads this stream; so does the audit log.
//! Events are append-only and globally ordered by `(seq_no, sub_seq)`,
//! where `seq_no` is the originating command's sequence and `sub_seq`
//! disambiguates multiple events from one command (e.g. a single
//! aggressor producing several fills).
//!
//! The full event log is the source of truth — any state we hold in
//! memory can be reconstructed by replaying it from the genesis
//! snapshot. Don't add fields here that can't be serialised.

use meridian_common::prelude::*;
use meridian_order_types::{Fill, Order, OrderStatus, Side};
use serde::{Deserialize, Serialize};
use smallvec::SmallVec;

use crate::session::SessionState;

/// Why an order was rejected. Surfaces in the rejection event so
/// downstream observers don't have to keep parsing free-text reasons.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum RejectReason {
    Validation,
    SymbolMismatch,
    DuplicateOrderId,
    SessionRefuses,
    PostOnlyWouldCross,
    FokWouldNotFill,
    KillSwitched,
    SelfTradeBlocked,
    UnknownOrder,
    NotAmendable,
    Internal,
}

impl RejectReason {
    /// FIX OrdRejReason (tag 103). Most of these don't have official
    /// codes; we use a fixed set our gateway translates back.
    #[must_use]
    pub const fn fix_code(self) -> u16 {
        match self {
            Self::Validation => 11,
            Self::SymbolMismatch => 1,
            Self::DuplicateOrderId => 6,
            Self::SessionRefuses => 2,
            Self::PostOnlyWouldCross => 8,
            Self::FokWouldNotFill => 9,
            Self::KillSwitched => 13,
            Self::SelfTradeBlocked => 14,
            Self::UnknownOrder => 5,
            Self::NotAmendable => 7,
            Self::Internal => 99,
        }
    }
}

/// Why an order is no longer on the book.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum CancelReason {
    UserRequested,
    SessionEnd,
    Gtd,
    Ioc,
    SelfTrade,
    KillSwitch,
    MassCancel,
    Replaced,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum EngineEvent {
    /// A new order was accepted onto the book (or as a stop / iceberg
    /// hidden order).
    OrderAccepted {
        order: Box<Order>,
        was_resting: bool,
    },

    /// An order was rejected at validation, risk, or matching time.
    OrderRejected {
        client_order_id: ClientOrderId,
        account_id: AccountId,
        reason: RejectReason,
        message: String,
    },

    /// One side of a fill. Two of these accompany every match (maker +
    /// taker). The `Fill` itself contains the trade ID linking them.
    OrderFilled {
        order_id: OrderId,
        fill: Fill,
        new_status: OrderStatus,
        leaves_qty: Quantity,
    },

    /// An order was removed without being fully filled.
    OrderCancelled {
        order_id: OrderId,
        client_order_id: ClientOrderId,
        account_id: AccountId,
        cancelled_qty: Quantity,
        reason: CancelReason,
    },

    /// An amend succeeded. Priority status is reported separately so
    /// downstream MD knows whether to redraw FIFO position.
    OrderAmended {
        order_id: OrderId,
        new_price: Option<Price>,
        new_quantity: Option<Quantity>,
        retained_priority: bool,
    },

    /// A stop / stop-limit order's trigger condition was met. The
    /// triggered order may have been then placed (resting limit) or
    /// matched (resting market) — those appear as separate events.
    StopTriggered {
        order_id: OrderId,
        trigger_price: Price,
        last_trade: Price,
    },

    /// An iceberg slice was exhausted and a new slice is being shown.
    /// `new_priority_seq` is fresh — refreshes lose priority on
    /// purpose (this is what keeps non-iceberg liquidity competitive).
    IcebergRefreshed {
        order_id: OrderId,
        revealed: Quantity,
        remaining_hidden: Quantity,
        new_priority_seq: SeqNo,
    },

    /// A pegged order has been repriced and re-queued. May fire many
    /// times if the BBO oscillates.
    PegRepriced {
        order_id: OrderId,
        old_price: Price,
        new_price: Price,
    },

    /// A book mutation that didn't fit any of the above (used by the
    /// market-data fanout when the engine reports a non-trade BBO
    /// change).
    BookUpdate {
        side: Side,
        price: Price,
        new_visible_qty: Quantity,
    },

    /// Session state machine moved.
    SessionChanged {
        from: SessionState,
        to: SessionState,
    },

    /// Snapshot worker, this is your cue.
    SnapshotMark { snapshot_id: SnapshotId },

    /// Kill switch toggled.
    KillSwitchEngaged { engaged: bool, reason: String },
}

/// One command can produce a *batch* of events. We expose the batch as
/// a unit so consumers know which events to commit / ack atomically.
///
/// Most commands produce 1–3 events. A market order sweeping deep
/// liquidity might produce dozens; we use `SmallVec` to keep the
/// common case allocation-free.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct EventBatch {
    pub originating_seq: SeqNo,
    pub at: Timestamp,
    pub events: SmallVec<[EngineEvent; 4]>,
}

impl EventBatch {
    #[must_use]
    pub fn new(originating_seq: SeqNo, at: Timestamp) -> Self {
        Self {
            originating_seq,
            at,
            events: SmallVec::new(),
        }
    }

    pub fn push(&mut self, ev: EngineEvent) {
        self.events.push(ev);
    }

    #[must_use]
    pub fn len(&self) -> usize {
        self.events.len()
    }

    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.events.is_empty()
    }

    /// Total fills represented in this batch — useful for stats.
    #[must_use]
    pub fn fill_count(&self) -> usize {
        self.events
            .iter()
            .filter(|e| matches!(e, EngineEvent::OrderFilled { .. }))
            .count()
    }

    /// Iterate just the fills in this batch.
    pub fn fills(&self) -> impl Iterator<Item = &Fill> {
        self.events.iter().filter_map(|e| match e {
            EngineEvent::OrderFilled { fill, .. } => Some(fill),
            _ => None,
        })
    }

    /// True if any rejection occurred — most callers want to know
    /// whether the originating command landed on the book at all.
    #[must_use]
    pub fn was_rejected(&self) -> bool {
        self.events
            .iter()
            .any(|e| matches!(e, EngineEvent::OrderRejected { .. }))
    }
}

#[cfg(test)]
mod tests {
    use chrono::Utc;

    use super::*;

    #[test]
    fn batch_helpers_work() {
        let mut b = EventBatch::new(SeqNo::new(1), Timestamp::from_datetime(Utc::now()));
        assert!(b.is_empty());
        b.push(EngineEvent::OrderRejected {
            client_order_id: ClientOrderId::new(1),
            account_id: AccountId::new(1),
            reason: RejectReason::Validation,
            message: "x".into(),
        });
        assert_eq!(b.len(), 1);
        assert!(b.was_rejected());
    }

    #[test]
    fn reject_codes_are_stable() {
        // These are persisted in audit logs; never renumber.
        assert_eq!(RejectReason::Validation.fix_code(), 11);
        assert_eq!(RejectReason::SymbolMismatch.fix_code(), 1);
        assert_eq!(RejectReason::DuplicateOrderId.fix_code(), 6);
        assert_eq!(RejectReason::PostOnlyWouldCross.fix_code(), 8);
    }
}
