//! The matching engine.
//!
//! One `Engine` per (shard, symbol). The engine is single-threaded
//! per symbol — no locks, no atomics in the hot path. Concurrency
//! happens *outside* the engine: the sequencer assigns SeqNos, the
//! gateway feeds commands in, the market-data fanout reads events out.
//!
//! # Hot path
//!
//! ```text
//!   Command  ──►  Engine.process_command  ──►  EventBatch
//! ```
//!
//! Each command produces *exactly one* `EventBatch`. The batch may be
//! empty (e.g. a `Tick` that fired no scheduled work), contain a
//! single rejection, or contain many fills + status updates.
//!
//! # Determinism
//!
//! The engine is referentially transparent given its starting state and
//! input sequence. There are three sources of non-determinism we
//! deliberately design *out*:
//!
//! 1. **Time.** Every timestamp comes from the inbound command, never
//!    from `Clock::now`. The clock field is only there for snapshot
//!    metadata and for tests.
//! 2. **Iteration order.** All ordering decisions tie-break by
//!    `priority_seq`. We don't iterate `HashMap`s during matching;
//!    `BTreeMap` is used wherever order matters.
//! 3. **ID generation.** The engine doesn't mint IDs from `Uuid::now_v7`
//!    because that would be wall-clock-coupled. It uses a deterministic
//!    counter seeded from the originating command's seq + a sub-index.

use meridian_common::clock::{Clock as _, SystemClock};
use meridian_common::prelude::*;
use meridian_order_book::{BookSnapshot, RestingOrder};
use meridian_order_types::{
    AmendRequest, CancelRequest, Fill, FillKind, NewOrder, Order, OrderError, OrderStatus,
    OrderType, SelfTradePrevention, Side, TimeInForce,
};

use crate::commands::{Command, CommandKind};
use crate::error::{EngineError, EngineResult};
use crate::events::{CancelReason, EngineEvent, EventBatch, RejectReason};
use crate::iceberg::{plan_refresh, RefreshOutcome};
use crate::ledger_book::LedgerBook;
use crate::peg::{compute_effective_price, peg_params};
use crate::policy::{Allocation, MatchingPolicy, PolicyKind};
use crate::session::SessionState;
use crate::stops::StopBook;
use crate::stp::{decide as decide_stp, DecrementSide, StpAction};

const PER_COMMAND_SUBSEQ_STRIDE: u64 = 1_024;

/// Tunables. Frozen at construction; the sequencer doesn't drive these.
#[derive(Debug, Clone)]
pub struct EngineConfig {
    pub symbol: Symbol,
    pub tick_size: TickSize,
    pub lot_size: LotSize,
    pub policy: PolicyKind,
    pub initial_session: SessionState,
    pub default_stp: SelfTradePrevention,
    /// Maximum events per command before we panic in debug — guards
    /// against runaway loops in pathological corner cases.
    pub max_events_per_command: usize,
}

impl EngineConfig {
    #[must_use]
    pub fn new(symbol: Symbol) -> Self {
        Self {
            symbol,
            tick_size: TickSize(Price::from_decimal(rust_decimal_macros::dec!(0.01))),
            lot_size: LotSize(Quantity::from_decimal(rust_decimal_macros::dec!(
                0.00000001
            ))),
            policy: PolicyKind::PriceTime,
            initial_session: SessionState::Continuous,
            default_stp: SelfTradePrevention::DecrementCancel,
            max_events_per_command: 4_096,
        }
    }
}

/// The engine itself.
pub struct Engine {
    cfg: EngineConfig,

    ledger: LedgerBook,
    stops: StopBook,

    /// Active matching policy. Boxed so it can be hot-swapped via an
    /// admin command without rebuilding the engine.
    policy: Box<dyn MatchingPolicy>,

    /// Last trade price. Stops trigger off this; reset to `None` on
    /// kill-switch + halt.
    last_trade_price: Option<Price>,

    /// Strict monotonic check. The sequencer is supposed to send
    /// commands in order; if we see a regression we refuse to advance.
    last_seq: SeqNo,

    session: SessionState,
    kill_switched: bool,

    /// Routing prefix for IDs minted by the engine (trade IDs, exec
    /// IDs). Order IDs are minted by the gateway.
    routing: RoutingPrefix,

    /// Per-engine counter for sub-sequence ids. Reset on every command.
    sub_seq_counter: u32,
}

impl std::fmt::Debug for Engine {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("Engine")
            .field("symbol", &self.cfg.symbol)
            .field("orders", &self.ledger.order_count())
            .field("stops_pending", &self.stops.len())
            .field("session", &self.session)
            .field("kill_switched", &self.kill_switched)
            .field("last_seq", &self.last_seq)
            .field("last_trade_price", &self.last_trade_price)
            .finish()
    }
}

impl Engine {
    #[must_use]
    pub fn new(cfg: EngineConfig) -> Self {
        let session = cfg.initial_session;
        let policy = cfg.policy.build();
        let symbol = cfg.symbol.clone();
        Self {
            cfg,
            ledger: LedgerBook::new(symbol),
            stops: StopBook::new(),
            policy,
            last_trade_price: None,
            last_seq: SeqNo::ZERO,
            session,
            kill_switched: false,
            routing: RoutingPrefix::PRIMARY,
            sub_seq_counter: 0,
        }
    }

    pub fn set_routing(&mut self, routing: RoutingPrefix) {
        self.routing = routing;
    }

    pub fn replace_policy(&mut self, kind: PolicyKind) {
        self.policy = kind.build();
    }

    #[must_use]
    pub const fn config(&self) -> &EngineConfig {
        &self.cfg
    }

    #[must_use]
    pub fn session_state(&self) -> SessionState {
        self.session
    }

    #[must_use]
    pub fn ledger(&self) -> &LedgerBook {
        &self.ledger
    }

    #[must_use]
    pub fn last_trade_price(&self) -> Option<Price> {
        self.last_trade_price
    }

    /// Capture a full snapshot — the engine state minus the indexes
    /// (which can be reconstructed from the book + the order map).
    /// The snapshot worker writes this to durable storage.
    #[must_use]
    pub fn snapshot(&self, snapshot_id: SnapshotId) -> EngineSnapshot {
        let _ = snapshot_id;
        EngineSnapshot {
            symbol: self.cfg.symbol.clone(),
            session: self.session,
            kill_switched: self.kill_switched,
            last_seq: self.last_seq,
            last_trade_price: self.last_trade_price,
            book: BookSnapshot::capture(
                &self.ledger.book,
                self.last_seq,
                Timestamp::from_datetime(SystemClock.now()),
            ),
        }
    }

    // ---------------- main entry point ----------------

    /// Process one command. Returns the produced events; the engine
    /// state is mutated in-place.
    pub fn process_command(&mut self, cmd: Command) -> EngineResult<EventBatch> {
        // Strict monotonicity.
        if cmd.seq_no.raw() <= self.last_seq.raw() {
            return Err(EngineError::Common(
                meridian_common::Error::failed_precondition(format!(
                    "non-monotonic seq: last={}, got={}",
                    self.last_seq, cmd.seq_no
                )),
            ));
        }
        self.last_seq = cmd.seq_no;
        self.sub_seq_counter = 0;

        let mut batch = EventBatch::new(cmd.seq_no, cmd.at);

        match cmd.kind {
            CommandKind::NewOrder(new) => {
                self.handle_new_order(&mut batch, new, cmd.at)?;
            },
            CommandKind::Cancel(req) => {
                self.handle_cancel(&mut batch, &req, CancelReason::UserRequested, cmd.at);
            },
            CommandKind::Amend(req) => {
                self.handle_amend(&mut batch, req, cmd.at);
            },
            CommandKind::CancelReplace { cancel, new_order } => {
                // We let cancel emit its own event, but mark the
                // reason as Replaced so observers don't treat it as a
                // user cancel.
                self.handle_cancel(&mut batch, &cancel, CancelReason::Replaced, cmd.at);
                self.handle_new_order(&mut batch, new_order, cmd.at)?;
            },
            CommandKind::MassCancelByAccount { account_id, reason } => {
                self.handle_mass_cancel(&mut batch, account_id, &reason, cmd.at);
            },
            CommandKind::SessionTransition(target) => {
                self.handle_session_transition(&mut batch, target, cmd.at);
            },
            CommandKind::SnapshotMark { snapshot_id } => {
                batch.push(EngineEvent::SnapshotMark { snapshot_id });
            },
            CommandKind::KillSwitch { engaged, reason } => {
                self.kill_switched = engaged;
                batch.push(EngineEvent::KillSwitchEngaged { engaged, reason });
            },
            CommandKind::Tick => {
                self.handle_tick(&mut batch, cmd.at);
            },
        }

        debug_assert!(
            batch.len() <= self.cfg.max_events_per_command,
            "event explosion ({} events) — likely an iceberg or peg loop",
            batch.len()
        );

        Ok(batch)
    }

    // ---------------- new order ----------------

    fn handle_new_order(
        &mut self,
        batch: &mut EventBatch,
        new: NewOrder,
        at: Timestamp,
    ) -> EngineResult<()> {
        // Pre-flight: kill switch.
        if self.kill_switched {
            push_reject(
                batch,
                &new,
                RejectReason::KillSwitched,
                "kill switch engaged",
            );
            return Ok(());
        }

        // Symbol must match.
        if new.symbol != self.cfg.symbol {
            push_reject(
                batch,
                &new,
                RejectReason::SymbolMismatch,
                &format!(
                    "engine={}, command={}",
                    self.cfg.symbol.as_str(),
                    new.symbol.as_str()
                ),
            );
            return Ok(());
        }

        // Session gate. ATO/ATC have their own dedicated path; the
        // continuous engine refuses them outside their auction window.
        if new.time_in_force.auction_only() {
            if !self.session.accepts_auction_orders() {
                push_reject(
                    batch,
                    &new,
                    RejectReason::SessionRefuses,
                    &format!("session={:?} rejects auction-only TIFs", self.session),
                );
                return Ok(());
            }
        } else if !self.session.accepts_continuous() {
            push_reject(
                batch,
                &new,
                RejectReason::SessionRefuses,
                &format!("session={:?}", self.session),
            );
            return Ok(());
        }

        // Intrinsic validation.
        let now = at.into_datetime();
        if let Err(e) = meridian_order_types::validate::validate_new_order(&new, now) {
            push_reject(batch, &new, RejectReason::Validation, &e.to_string());
            return Ok(());
        }

        // Tick / lot alignment, if applicable.
        if let Some(p) = new.limit_price {
            if !self.cfg.tick_size.is_aligned(p) {
                push_reject(
                    batch,
                    &new,
                    RejectReason::Validation,
                    "limit price not on tick",
                );
                return Ok(());
            }
        }
        if !self.cfg.lot_size.is_aligned(new.quantity) {
            push_reject(
                batch,
                &new,
                RejectReason::Validation,
                "quantity not aligned to lot size",
            );
            return Ok(());
        }

        // Allocate engine-side IDs from the inbound seq for determinism.
        let order_id = OrderId::new(self.next_id_raw());

        if self.ledger.knows_id(order_id) {
            // The sequencer should never reuse a command-derived id;
            // if it does, something is badly wrong upstream.
            push_reject(
                batch,
                &new,
                RejectReason::DuplicateOrderId,
                &order_id.to_string(),
            );
            return Ok(());
        }

        let mut order = Order::from_new(&new, order_id, self.last_seq, at, self.cfg.default_stp);

        // Stops: route to stop book, off the visible book.
        if matches!(order.order_type, OrderType::Stop | OrderType::StopLimit) {
            order.status = OrderStatus::Untriggered;
            let trigger = order
                .trigger_price
                .expect("validation ensures trigger price for stops");
            self.stops.insert(order.side, trigger, order_id);
            self.ledger.insert_full_offbook(order.clone());
            batch.push(EngineEvent::OrderAccepted {
                order: Box::new(order),
                was_resting: false,
            });
            return Ok(());
        }

        // Pegged: compute effective price from the BBO.
        if let Some((reference, offset_ticks)) = peg_params(order.order_type) {
            let effective = compute_effective_price(
                &self.ledger.book,
                order.side,
                reference,
                offset_ticks,
                self.cfg.tick_size,
            );
            let Some(eff) = effective else {
                push_reject(
                    batch,
                    &new,
                    RejectReason::Validation,
                    "peg reference unavailable on a one-sided book",
                );
                return Ok(());
            };
            order.limit_price = Some(eff);
        }

        // From here we know the order has a limit price (or is a
        // market that doesn't need one).
        self.match_and_rest(batch, order, at);
        Ok(())
    }

    /// The core matching loop.
    ///
    /// Walks the opposite side of the book from best to worst, asking
    /// the policy how to allocate at each level, applies STP per
    /// allocation, and emits fill events. Whatever doesn't match is
    /// either rested (TIF allows), cancelled (IOC), or — for FOK with
    /// insufficient depth — rejected outright.
    fn match_and_rest(&mut self, batch: &mut EventBatch, mut taker: Order, at: Timestamp) {
        let opp = taker.side.opposite();

        // FOK pre-flight: if we can't fill the entire qty against
        // currently-visible liquidity, reject without partials.
        if matches!(taker.time_in_force, TimeInForce::Fok) && !self.has_marketable_depth(&taker) {
            push_reject_for_order(
                batch,
                &taker,
                RejectReason::FokWouldNotFill,
                "FOK: insufficient depth",
            );
            return;
        }

        // Post-only pre-flight: reject if we'd cross.
        if taker.post_only && self.would_cross(&taker) {
            push_reject_for_order(
                batch,
                &taker,
                RejectReason::PostOnlyWouldCross,
                "post-only would cross",
            );
            return;
        }

        // Iterate opposite-side levels; collect deferred mutations
        // since we can't mutate the book while iterating it. Two
        // passes: (1) allocate, (2) apply.
        loop {
            if taker.leaves_qty.is_zero() {
                break;
            }
            let Some(level_price) = best_price(&self.ledger.book, opp) else {
                break;
            };
            if !self.crosses_at(level_price, &taker) {
                break;
            }

            let allocations = {
                let level = self
                    .ledger
                    .book
                    .best_level(opp)
                    .expect("we just asked for best price");
                self.policy.allocate(level, taker.leaves_qty)
            };

            if allocations.is_empty() {
                // The level had visible_qty 0 (e.g. all hidden iceberg
                // slots); we can't make further progress here without
                // refreshing. Refresh below; if no refresh fires, we
                // bail to avoid an infinite loop.
                if !self.try_refresh_at(level_price, opp, batch) {
                    break;
                }
                continue;
            }

            // Snapshot allocation IDs so we can iterate them after
            // mutating the level under the engine.
            let alloc_count = allocations.len();
            let mut applied = false;
            for alloc in allocations {
                if taker.leaves_qty.is_zero() {
                    break;
                }
                if !self.apply_allocation(batch, &mut taker, alloc, level_price, at) {
                    // Allocation skipped (STP cancel-taker); stop.
                    break;
                }
                applied = true;
            }
            if !applied && alloc_count > 0 {
                // We made no forward progress at this level (every
                // allocation skipped). Don't loop forever.
                break;
            }
        }

        // Resting decision.
        if taker.leaves_qty.is_zero() {
            taker.status = OrderStatus::Filled;
            self.ledger.insert_full_offbook(taker.clone());
            batch.push(EngineEvent::OrderAccepted {
                order: Box::new(taker),
                was_resting: false,
            });
            return;
        }

        if !taker.time_in_force.allows_resting() || matches!(taker.order_type, OrderType::Market) {
            // IOC, FOK (with partial fill — though FOK should be
            // unreachable here), or market with leftover. Cancel the
            // remainder.
            let cancelled_qty = taker.leaves_qty;
            taker.cancel(at);
            self.ledger.insert_full_offbook(taker.clone());
            batch.push(EngineEvent::OrderCancelled {
                order_id: taker.id,
                client_order_id: taker.client_order_id,
                account_id: taker.account_id,
                cancelled_qty,
                reason: CancelReason::Ioc,
            });
            return;
        }

        // Rest the remainder on the book.
        let resting = make_resting(&taker);
        self.ledger.insert_full(taker.clone(), resting);
        batch.push(EngineEvent::OrderAccepted {
            order: Box::new(taker),
            was_resting: true,
        });
    }

    /// Apply a single allocation. Returns false if STP forced us to
    /// abort the *taker* — in which case the caller stops matching.
    fn apply_allocation(
        &mut self,
        batch: &mut EventBatch,
        taker: &mut Order,
        alloc: Allocation,
        level_price: Price,
        at: Timestamp,
    ) -> bool {
        let opp = taker.side.opposite();

        // Look up the maker.
        let maker_id = alloc.order_id;
        let Some(maker) = self.ledger.get(maker_id) else {
            // Maker disappeared between policy decision and apply —
            // shouldn't happen since allocate runs synchronously, but
            // be defensive.
            return true;
        };
        let maker_qty = maker.leaves_qty;
        let maker_account = maker.account_id;
        let maker_client_id = maker.client_order_id;
        let maker_side = maker.side;
        let _ = maker_side;

        // STP if same account.
        if taker.account_id == maker_account {
            let action = decide_stp(taker.stp, taker.leaves_qty, maker_qty);
            return self.handle_stp(batch, taker, maker_id, action, level_price, at);
        }

        let fill_qty = alloc.fill_qty.min(maker_qty).min(taker.leaves_qty);
        if fill_qty.is_zero() {
            return true;
        }

        // Apply to the resting record on the book.
        let _ = self
            .ledger
            .book
            .reduce_order(opp, level_price, maker_id, fill_qty);

        // Update the maker's full record.
        let new_status_maker = {
            let m = self.ledger.get_mut(maker_id).expect("maker present");
            m.apply_fill(fill_qty, level_price, at);
            m.status
        };

        // Update the taker.
        taker.apply_fill(fill_qty, level_price, at);

        // Emit fills for both sides.
        let trade_id = self.next_trade_id();
        let fill_maker = Fill {
            trade_id,
            exec_id: self.next_exec_id(),
            symbol: self.cfg.symbol.clone(),
            kind: FillKind::Trade,
            price: level_price,
            quantity: fill_qty,
            maker_order_id: maker_id,
            taker_order_id: taker.id,
            maker_account,
            taker_account: taker.account_id,
            maker_side: opp,
            maker_fee: Fee::ZERO,
            taker_fee: Fee::ZERO,
            at,
            seq_no: MdSeqNo::new(self.last_seq.raw()),
        };
        let fill_taker = fill_maker.clone();

        batch.push(EngineEvent::OrderFilled {
            order_id: maker_id,
            fill: fill_maker,
            new_status: new_status_maker,
            leaves_qty: maker_qty - fill_qty,
        });
        batch.push(EngineEvent::OrderFilled {
            order_id: taker.id,
            fill: fill_taker,
            new_status: taker.status,
            leaves_qty: taker.leaves_qty,
        });

        // Update last trade and fire stops triggered by it.
        self.last_trade_price = Some(level_price);
        self.fire_triggered_stops(batch, level_price, at);

        // Iceberg refresh for fully-consumed maker.
        if new_status_maker == OrderStatus::Filled {
            self.maybe_refresh_iceberg(batch, maker_id, opp, level_price);
            // Drop the maker's record from the ledger if it has no
            // more residual tracking value (no hidden qty etc).
            let drop_maker = self
                .ledger
                .get(maker_id)
                .is_none_or(|m| m.leaves_qty.is_zero() && m.order_type != OrderType::Iceberg);
            if drop_maker {
                let _ = maker_client_id;
            }
        }

        true
    }

    fn handle_stp(
        &mut self,
        batch: &mut EventBatch,
        taker: &mut Order,
        maker_id: OrderId,
        action: StpAction,
        level_price: Price,
        at: Timestamp,
    ) -> bool {
        match action {
            StpAction::Allow => true,
            StpAction::CancelTaker { taker_remaining } => {
                let qty = taker_remaining;
                taker.cancel(at);
                batch.push(EngineEvent::OrderCancelled {
                    order_id: taker.id,
                    client_order_id: taker.client_order_id,
                    account_id: taker.account_id,
                    cancelled_qty: qty,
                    reason: CancelReason::SelfTrade,
                });
                false
            },
            StpAction::CancelMaker { maker_remaining } => {
                self.cancel_resting(
                    batch,
                    maker_id,
                    level_price,
                    taker.side.opposite(),
                    CancelReason::SelfTrade,
                    maker_remaining,
                    at,
                );
                true
            },
            StpAction::CancelBoth {
                taker_remaining,
                maker_remaining,
            } => {
                self.cancel_resting(
                    batch,
                    maker_id,
                    level_price,
                    taker.side.opposite(),
                    CancelReason::SelfTrade,
                    maker_remaining,
                    at,
                );
                taker.cancel(at);
                batch.push(EngineEvent::OrderCancelled {
                    order_id: taker.id,
                    client_order_id: taker.client_order_id,
                    account_id: taker.account_id,
                    cancelled_qty: taker_remaining,
                    reason: CancelReason::SelfTrade,
                });
                false
            },
            StpAction::Decrement {
                cancelled_side,
                cancelled_qty,
            } => {
                match cancelled_side {
                    DecrementSide::Taker => {
                        // Taker is the smaller — full taker cancelled,
                        // maker is decremented by `cancelled_qty`.
                        if let Some(m) = self.ledger.get_mut(maker_id) {
                            // The maker stays on the book at lower qty.
                            // Reduce its leaves but don't change its
                            // priority — STP-driven decrement is not a
                            // priority-affecting event.
                            m.leaves_qty -= cancelled_qty;
                            m.last_event_at = at;
                        }
                        // Reflect the decrement in the book itself.
                        let _ = self.ledger.book.reduce_order(
                            taker.side.opposite(),
                            level_price,
                            maker_id,
                            cancelled_qty,
                        );
                        let qty = taker.leaves_qty;
                        taker.cancel(at);
                        batch.push(EngineEvent::OrderCancelled {
                            order_id: taker.id,
                            client_order_id: taker.client_order_id,
                            account_id: taker.account_id,
                            cancelled_qty: qty,
                            reason: CancelReason::SelfTrade,
                        });
                        false
                    },
                    DecrementSide::Maker => {
                        // Maker is the smaller — full maker cancelled.
                        // Taker is decremented by `cancelled_qty`.
                        let cancelled_full = cancelled_qty;
                        self.cancel_resting(
                            batch,
                            maker_id,
                            level_price,
                            taker.side.opposite(),
                            CancelReason::SelfTrade,
                            cancelled_full,
                            at,
                        );
                        // Taker's leaves_qty was passed in via
                        // `decide_stp`; we shrink it here so the next
                        // iteration sees the right number. We don't
                        // emit a fill because no actual cross occurred.
                        taker.leaves_qty -= cancelled_full;
                        taker.last_event_at = at;
                        true
                    },
                }
            },
        }
    }

    fn cancel_resting(
        &mut self,
        batch: &mut EventBatch,
        order_id: OrderId,
        price: Price,
        side: Side,
        reason: CancelReason,
        cancelled_qty: Quantity,
        at: Timestamp,
    ) {
        let _ = self.ledger.book.remove(side, price, order_id);
        if let Some(o) = self.ledger.get_mut(order_id) {
            let cid = o.client_order_id;
            let acc = o.account_id;
            o.cancel(at);
            batch.push(EngineEvent::OrderCancelled {
                order_id,
                client_order_id: cid,
                account_id: acc,
                cancelled_qty,
                reason,
            });
        }
    }

    fn maybe_refresh_iceberg(
        &mut self,
        batch: &mut EventBatch,
        order_id: OrderId,
        _side: Side,
        _price: Price,
    ) {
        let order = match self.ledger.get(order_id) {
            Some(o) if matches!(o.order_type, OrderType::Iceberg) => o.clone(),
            _ => return,
        };
        // Reconstruct the resting view we had pre-fill so we can plan
        // the refresh from a single source. We store hidden_qty in the
        // resting record while it sits on the book; once consumed,
        // the engine's `Order` doesn't preserve it. So the source of
        // truth here is the order's `display_qty` and the original
        // `original_qty` minus `filled_qty`.
        let total_remaining = order.original_qty - order.filled_qty;
        if total_remaining.is_zero() {
            return;
        }
        let display = order.display_qty.expect("iceberg has display_qty");

        let new_visible = display.min(total_remaining);
        let new_hidden = total_remaining - new_visible;
        if new_visible.is_zero() {
            return;
        }

        // Build the resting record for the next slice.
        let sub = self.next_sub();
        assert!(
            u64::from(sub) < PER_COMMAND_SUBSEQ_STRIDE,
            "sub-sequence exceeded reserved range for command {}",
            self.last_seq
        );
        let new_seq = SeqNo::new(
            self.last_seq
                .raw()
                .saturating_mul(PER_COMMAND_SUBSEQ_STRIDE)
                .saturating_add(u64::from(sub)),
        );
        let next_slice = RestingOrder {
            order_id,
            account_id: order.account_id,
            side: order.side,
            order_type: OrderType::Iceberg,
            leaves_qty: new_visible,
            display_qty: Some(new_visible),
            hidden_qty: if new_hidden.is_zero() {
                None
            } else {
                Some(new_hidden)
            },
            price: order.limit_price.expect("iceberg has limit price"),
            priority_seq: new_seq,
            post_only: order.post_only,
        };

        // We need the underlying Order to reflect the slice's status.
        if let Some(o) = self.ledger.get_mut(order_id) {
            o.status = OrderStatus::PartiallyFilled;
            o.priority_seq = new_seq;
            o.leaves_qty = total_remaining;
        }
        self.ledger
            .relocate(order_id, next_slice.side, next_slice.price);
        self.ledger.book.insert(next_slice.clone());

        batch.push(EngineEvent::IcebergRefreshed {
            order_id,
            revealed: new_visible,
            remaining_hidden: new_hidden,
            new_priority_seq: new_seq,
        });

        // Plan-refresh based on the resting record (defensive — we
        // don't actually use the result; just verify our manual logic
        // matches the helper).
        debug_assert!(matches!(
            plan_refresh(&next_slice, new_seq),
            RefreshOutcome::Done | RefreshOutcome::Revealed { .. }
        ));
    }

    fn try_refresh_at(&mut self, _price: Price, _side: Side, _batch: &mut EventBatch) -> bool {
        // Hook for future deterministic-refresh policies. The current
        // model refreshes only on full slice consumption, not at
        // visible-zero levels (which shouldn't occur in normal flow).
        false
    }

    fn fire_triggered_stops(&mut self, batch: &mut EventBatch, last: Price, at: Timestamp) {
        let triggered = self.stops.fire(last);
        for (side, order_id) in triggered {
            let Some(order) = self.ledger.get(order_id).cloned() else {
                continue;
            };
            let trigger = order
                .trigger_price
                .expect("stops always have trigger price");
            batch.push(EngineEvent::StopTriggered {
                order_id,
                trigger_price: trigger,
                last_trade: last,
            });
            // Re-inject the order as if newly arrived. We reuse the
            // same id and account; status flips to Triggered, then
            // through normal matching.
            let mut triggered_order = order;
            triggered_order.status = OrderStatus::Triggered;
            // Stop becomes a market; stop-limit becomes a limit at
            // its limit_price.
            match triggered_order.order_type {
                OrderType::Stop => {
                    triggered_order.order_type = OrderType::Market;
                    triggered_order.limit_price = None;
                    triggered_order.time_in_force = TimeInForce::Ioc;
                },
                OrderType::StopLimit => {
                    triggered_order.order_type = OrderType::Limit;
                    // limit_price is already populated from the
                    // original order.
                },
                _ => {
                    // Should be unreachable given how we register stops,
                    // but if it happens we just drop the order.
                    debug_assert!(false, "non-stop in stop book");
                    continue;
                },
            }
            // Remove the off-book record before re-inserting through
            // the normal path so we don't trip the duplicate-id check.
            let _ = self.ledger.forget(order_id);
            let _ = side;
            self.match_and_rest(batch, triggered_order, at);
        }
    }

    fn has_marketable_depth(&self, taker: &Order) -> bool {
        let opp = taker.side.opposite();
        let mut acc = Quantity::ZERO;
        for level in self.ledger.book.iter_side(opp) {
            if !self.crosses_at(level.price, taker) {
                break;
            }
            acc += level.visible_qty();
            if acc >= taker.leaves_qty {
                return true;
            }
        }
        false
    }

    fn would_cross(&self, taker: &Order) -> bool {
        let opp = taker.side.opposite();
        let Some(top) = best_price(&self.ledger.book, opp) else {
            return false;
        };
        self.crosses_at(top, taker)
    }

    fn crosses_at(&self, level_price: Price, taker: &Order) -> bool {
        let Some(limit) = taker.limit_price else {
            // Market orders cross at any price.
            return true;
        };
        match taker.side {
            Side::Buy => level_price <= limit,
            Side::Sell => level_price >= limit,
        }
    }

    // ---------------- cancel / amend ----------------

    fn handle_cancel(
        &mut self,
        batch: &mut EventBatch,
        req: &CancelRequest,
        reason: CancelReason,
        at: Timestamp,
    ) {
        if !self.session.accepts_cancels() {
            // We don't reject — the gateway will retry in milliseconds.
            // But we do log via OrderRejected so observers see the
            // pause cleanly.
            let cid = req.client_order_id.unwrap_or(ClientOrderId::ZERO);
            batch.push(EngineEvent::OrderRejected {
                client_order_id: cid,
                account_id: req.account_id,
                reason: RejectReason::SessionRefuses,
                message: "session does not accept cancels right now".into(),
            });
            return;
        }

        let order_id = req.order_id.or_else(|| {
            req.client_order_id
                .and_then(|c| self.ledger.resolve_client_id(c))
        });
        let Some(order_id) = order_id else {
            let cid = req.client_order_id.unwrap_or(ClientOrderId::ZERO);
            batch.push(EngineEvent::OrderRejected {
                client_order_id: cid,
                account_id: req.account_id,
                reason: RejectReason::UnknownOrder,
                message: "no such order".into(),
            });
            return;
        };

        let Some(order) = self.ledger.get(order_id).cloned() else {
            let cid = req.client_order_id.unwrap_or(ClientOrderId::ZERO);
            batch.push(EngineEvent::OrderRejected {
                client_order_id: cid,
                account_id: req.account_id,
                reason: RejectReason::UnknownOrder,
                message: format!("order {} not in ledger", order_id),
            });
            return;
        };
        if order.status.is_terminal() {
            batch.push(EngineEvent::OrderRejected {
                client_order_id: order.client_order_id,
                account_id: order.account_id,
                reason: RejectReason::UnknownOrder,
                message: format!("order {} already terminal", order_id),
            });
            return;
        }

        let cancelled_qty = order.leaves_qty;

        // Untriggered stops: drop from stop book.
        if matches!(order.status, OrderStatus::Untriggered) {
            let trigger = order.trigger_price.expect("stop has trigger");
            let _ = self.stops.remove(order.side, trigger, order.id);
        } else {
            // Resting on the book — remove via locator.
            let _ = self.ledger.remove_from_book(order_id);
        }
        if let Some(o) = self.ledger.get_mut(order_id) {
            o.cancel(at);
        }
        batch.push(EngineEvent::OrderCancelled {
            order_id,
            client_order_id: order.client_order_id,
            account_id: order.account_id,
            cancelled_qty,
            reason,
        });
    }

    fn handle_amend(&mut self, batch: &mut EventBatch, req: AmendRequest, at: Timestamp) {
        let Some(order) = self.ledger.get(req.order_id).cloned() else {
            batch.push(EngineEvent::OrderRejected {
                client_order_id: ClientOrderId::ZERO,
                account_id: req.account_id,
                reason: RejectReason::UnknownOrder,
                message: format!("amend: order {} not found", req.order_id),
            });
            return;
        };
        if order.status.is_terminal() || order.account_id != req.account_id {
            batch.push(EngineEvent::OrderRejected {
                client_order_id: order.client_order_id,
                account_id: req.account_id,
                reason: RejectReason::NotAmendable,
                message: "order terminal or wrong owner".into(),
            });
            return;
        }
        let current_price = order
            .limit_price
            .ok_or(OrderError::invalid("amend on non-priced order"));
        let Ok(current_price) = current_price else {
            batch.push(EngineEvent::OrderRejected {
                client_order_id: order.client_order_id,
                account_id: req.account_id,
                reason: RejectReason::NotAmendable,
                message: "amend on non-priced order".into(),
            });
            return;
        };

        let narrowing = req.is_narrowing(current_price, order.original_qty, order.side);
        if !narrowing && req.reject_on_priority_loss {
            batch.push(EngineEvent::OrderRejected {
                client_order_id: order.client_order_id,
                account_id: req.account_id,
                reason: RejectReason::NotAmendable,
                message: "amend would lose priority".into(),
            });
            return;
        }

        // Quantity below already-filled is rejected.
        if let Some(new_qty) = req.new_quantity {
            if new_qty <= order.filled_qty {
                batch.push(EngineEvent::OrderRejected {
                    client_order_id: order.client_order_id,
                    account_id: req.account_id,
                    reason: RejectReason::Validation,
                    message: "new quantity ≤ filled qty".into(),
                });
                return;
            }
        }

        if narrowing {
            // In-place amend.
            let mut new_leaves = order.leaves_qty;
            if let Some(q) = req.new_quantity {
                new_leaves = q - order.filled_qty;
            }
            let mut new_price = current_price;
            if let Some(p) = req.new_limit_price {
                new_price = p;
            }
            // Reflect on book — narrowing keeps queue position. We do
            // this by mutating the resting record in place.
            if let Some(level) = self.ledger.book.level_mut(order.side, current_price) {
                if let Some(slot) = level.iter_mut().find(|o| o.order_id == order.id) {
                    slot.leaves_qty = new_leaves;
                    slot.price = new_price;
                }
                level.recompute_cache();
            }
            if let Some(o) = self.ledger.get_mut(order.id) {
                o.leaves_qty = new_leaves;
                o.original_qty = order.filled_qty + new_leaves;
                o.limit_price = Some(new_price);
                o.last_event_at = at;
            }
            batch.push(EngineEvent::OrderAmended {
                order_id: order.id,
                new_price: req.new_limit_price,
                new_quantity: req.new_quantity,
                retained_priority: true,
            });
            return;
        }

        // Re-queue path. Cancel + re-insert. Loses priority.
        let cancelled_qty = order.leaves_qty;
        let _ = self.ledger.remove_from_book(order.id);
        let new_price = req.new_limit_price.unwrap_or(current_price);
        let new_leaves = req
            .new_quantity
            .map_or(order.leaves_qty, |q| q - order.filled_qty);
        let new_seq = SeqNo::new(self.last_seq.raw().saturating_add(self.next_sub() as u64));
        if let Some(o) = self.ledger.get_mut(order.id) {
            o.limit_price = Some(new_price);
            o.original_qty = order.filled_qty + new_leaves;
            o.leaves_qty = new_leaves;
            o.priority_seq = new_seq;
            o.last_event_at = at;
        }
        let resting = RestingOrder {
            order_id: order.id,
            account_id: order.account_id,
            side: order.side,
            order_type: order.order_type,
            leaves_qty: new_leaves,
            display_qty: order.display_qty,
            hidden_qty: None,
            price: new_price,
            priority_seq: new_seq,
            post_only: order.post_only,
        };
        self.ledger.relocate(order.id, order.side, new_price);
        self.ledger.book.insert(resting);
        batch.push(EngineEvent::OrderAmended {
            order_id: order.id,
            new_price: req.new_limit_price,
            new_quantity: req.new_quantity,
            retained_priority: false,
        });
        let _ = cancelled_qty;
    }

    fn handle_mass_cancel(
        &mut self,
        batch: &mut EventBatch,
        account: AccountId,
        _reason: &str,
        at: Timestamp,
    ) {
        let ids = self.ledger.ids_for_account(account);
        for id in ids {
            let Some(o) = self.ledger.get(id).cloned() else {
                continue;
            };
            if o.status.is_terminal() {
                continue;
            }
            let qty = o.leaves_qty;
            if matches!(o.status, OrderStatus::Untriggered) {
                if let Some(t) = o.trigger_price {
                    let _ = self.stops.remove(o.side, t, id);
                }
            } else {
                let _ = self.ledger.remove_from_book(id);
            }
            if let Some(om) = self.ledger.get_mut(id) {
                om.cancel(at);
            }
            batch.push(EngineEvent::OrderCancelled {
                order_id: id,
                client_order_id: o.client_order_id,
                account_id: o.account_id,
                cancelled_qty: qty,
                reason: CancelReason::MassCancel,
            });
        }
    }

    fn handle_session_transition(
        &mut self,
        batch: &mut EventBatch,
        target: SessionState,
        at: Timestamp,
    ) {
        let from = self.session;
        if !from.can_transition_to(target) {
            // Refuse with a SessionRefuses rejection, attributed to no
            // particular client.
            batch.push(EngineEvent::OrderRejected {
                client_order_id: ClientOrderId::ZERO,
                account_id: AccountId::ZERO,
                reason: RejectReason::SessionRefuses,
                message: format!("illegal session transition {:?} -> {:?}", from, target),
            });
            return;
        }
        self.session = target;
        batch.push(EngineEvent::SessionChanged { from, to: target });

        // PostClose: cancel every resting Day order.
        if matches!(target, SessionState::PostClose) {
            self.cancel_day_orders(batch, at);
        }
    }

    fn cancel_day_orders(&mut self, batch: &mut EventBatch, at: Timestamp) {
        let ids: Vec<OrderId> = self
            .ledger
            .book
            .iter_side(Side::Buy)
            .chain(self.ledger.book.iter_side(Side::Sell))
            .flat_map(|lvl| lvl.iter().map(|o| o.order_id))
            .collect();
        for id in ids {
            let Some(o) = self.ledger.get(id).cloned() else {
                continue;
            };
            if !matches!(o.time_in_force, TimeInForce::Day) || o.status.is_terminal() {
                continue;
            }
            let qty = o.leaves_qty;
            let _ = self.ledger.remove_from_book(id);
            if let Some(m) = self.ledger.get_mut(id) {
                m.cancel(at);
            }
            batch.push(EngineEvent::OrderCancelled {
                order_id: id,
                client_order_id: o.client_order_id,
                account_id: o.account_id,
                cancelled_qty: qty,
                reason: CancelReason::SessionEnd,
            });
        }
    }

    fn handle_tick(&mut self, batch: &mut EventBatch, at: Timestamp) {
        // GTD expiry sweep: scan resting orders, cancel any whose
        // expiry has elapsed. Linear scan is fine; the engine
        // typically holds < 1M resting orders per symbol.
        let now = at.into_datetime();
        let candidates: Vec<OrderId> = self
            .ledger
            .book
            .iter_side(Side::Buy)
            .chain(self.ledger.book.iter_side(Side::Sell))
            .flat_map(|lvl| lvl.iter().map(|o| o.order_id))
            .collect();
        for id in candidates {
            let Some(o) = self.ledger.get(id).cloned() else {
                continue;
            };
            if o.is_expired_at(now) && !o.status.is_terminal() {
                let qty = o.leaves_qty;
                let _ = self.ledger.remove_from_book(id);
                if let Some(m) = self.ledger.get_mut(id) {
                    m.cancel(at);
                }
                batch.push(EngineEvent::OrderCancelled {
                    order_id: id,
                    client_order_id: o.client_order_id,
                    account_id: o.account_id,
                    cancelled_qty: qty,
                    reason: CancelReason::Gtd,
                });
            }
        }
    }

    // ---------------- id minting ----------------

    fn next_sub(&mut self) -> u32 {
        let v = self.sub_seq_counter;
        self.sub_seq_counter = self.sub_seq_counter.wrapping_add(1);
        v
    }

    fn next_id_raw(&mut self) -> u128 {
        let s = self.last_seq.raw();
        let sub = self.next_sub();
        // Compose: top 32 = routing, next 32 = sub_seq, low 64 = seq.
        (u128::from(self.routing.0) << 96) | (u128::from(sub) << 64) | u128::from(s)
    }

    fn next_trade_id(&mut self) -> TradeId {
        TradeId::new(self.next_id_raw())
    }

    fn next_exec_id(&mut self) -> ExecId {
        ExecId::new(self.next_id_raw())
    }
}

// ---------- helpers ----------

fn make_resting(o: &Order) -> RestingOrder {
    let display = match (o.order_type, o.display_qty) {
        (OrderType::Iceberg, Some(d)) => Some(d.min(o.leaves_qty)),
        _ => None,
    };
    let hidden = match (o.order_type, o.display_qty) {
        (OrderType::Iceberg, Some(d)) => {
            let v = d.min(o.leaves_qty);
            if o.leaves_qty > v {
                Some(o.leaves_qty - v)
            } else {
                None
            }
        },
        _ => None,
    };
    RestingOrder {
        order_id: o.id,
        account_id: o.account_id,
        side: o.side,
        order_type: o.order_type,
        leaves_qty: display.unwrap_or(o.leaves_qty),
        display_qty: display,
        hidden_qty: hidden,
        price: o.limit_price.expect("resting requires a limit price"),
        priority_seq: o.priority_seq,
        post_only: o.post_only,
    }
}

fn best_price(book: &meridian_order_book::Book, side: Side) -> Option<Price> {
    match side {
        Side::Buy => book.best_bid(),
        Side::Sell => book.best_ask(),
    }
}

fn push_reject(batch: &mut EventBatch, new: &NewOrder, reason: RejectReason, msg: &str) {
    batch.push(EngineEvent::OrderRejected {
        client_order_id: new.client_order_id,
        account_id: new.account_id,
        reason,
        message: msg.into(),
    });
}

fn push_reject_for_order(batch: &mut EventBatch, order: &Order, reason: RejectReason, msg: &str) {
    batch.push(EngineEvent::OrderRejected {
        client_order_id: order.client_order_id,
        account_id: order.account_id,
        reason,
        message: msg.into(),
    });
}

/// Snapshot of engine state as captured by the snapshot worker.
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct EngineSnapshot {
    pub symbol: Symbol,
    pub session: SessionState,
    pub kill_switched: bool,
    pub last_seq: SeqNo,
    pub last_trade_price: Option<Price>,
    pub book: BookSnapshot,
}

#[cfg(test)]
mod tests {
    use chrono::Utc;
    use meridian_order_types::Side;
    use rust_decimal_macros::dec;

    use super::*;

    fn ts() -> Timestamp {
        Timestamp::from_datetime(Utc::now())
    }

    fn sym() -> Symbol {
        Symbol::new("BTC-USD").unwrap()
    }

    fn engine() -> Engine {
        let cfg = EngineConfig::new(sym());
        Engine::new(cfg)
    }

    fn cmd(seq: u64, k: CommandKind) -> Command {
        Command::new(SeqNo::new(seq), ts(), k)
    }

    fn limit(
        account: u128,
        cid: u128,
        side: Side,
        price: rust_decimal::Decimal,
        qty: i64,
    ) -> NewOrder {
        NewOrder::limit(
            AccountId::new(account),
            ClientOrderId::new(cid),
            sym(),
            side,
            Price::from_decimal(price),
            Quantity::from_int(qty),
        )
    }

    #[test]
    fn rest_then_cross_emits_two_fills_and_clears_book() {
        let mut e = engine();
        let b1 = e
            .process_command(cmd(
                1,
                CommandKind::NewOrder(limit(1, 1, Side::Sell, dec!(100), 5)),
            ))
            .unwrap();
        assert!(!b1.was_rejected());
        let b2 = e
            .process_command(cmd(
                2,
                CommandKind::NewOrder(limit(2, 2, Side::Buy, dec!(100), 5)),
            ))
            .unwrap();
        assert_eq!(b2.fill_count(), 2);
        assert_eq!(e.ledger.book.best_ask(), None);
        assert_eq!(e.ledger.book.best_bid(), None);
    }

    #[test]
    fn post_only_that_would_cross_is_rejected() {
        let mut e = engine();
        e.process_command(cmd(
            1,
            CommandKind::NewOrder(limit(1, 1, Side::Sell, dec!(100), 5)),
        ))
        .unwrap();
        let mut po = limit(2, 2, Side::Buy, dec!(100), 5);
        po.post_only = true;
        let b = e
            .process_command(cmd(2, CommandKind::NewOrder(po)))
            .unwrap();
        assert!(b.was_rejected());
        assert_eq!(
            e.ledger.book.best_ask(),
            Some(Price::from_decimal(dec!(100)))
        );
    }

    #[test]
    fn kill_switch_rejects_new_orders() {
        let mut e = engine();
        e.process_command(cmd(
            1,
            CommandKind::KillSwitch {
                engaged: true,
                reason: "test".into(),
            },
        ))
        .unwrap();
        let b = e
            .process_command(cmd(
                2,
                CommandKind::NewOrder(limit(1, 1, Side::Sell, dec!(100), 5)),
            ))
            .unwrap();
        assert!(b.was_rejected());
    }

    #[test]
    fn pro_rata_applies_allocation_to_non_head_orders() {
        let mut cfg = EngineConfig::new(sym());
        cfg.policy = PolicyKind::ProRata;
        let mut e = Engine::new(cfg);

        e.process_command(cmd(
            1,
            CommandKind::NewOrder(limit(1, 11, Side::Sell, dec!(100), 9)),
        ))
        .unwrap();
        e.process_command(cmd(
            2,
            CommandKind::NewOrder(limit(2, 22, Side::Sell, dec!(100), 3)),
        ))
        .unwrap();

        let batch = e
            .process_command(cmd(
                3,
                CommandKind::NewOrder(limit(3, 33, Side::Buy, dec!(100), 6)),
            ))
            .unwrap();

        let mut maker_one = Quantity::ZERO;
        let mut maker_two = Quantity::ZERO;
        for event in &batch.events {
            if let EngineEvent::OrderFilled { order_id, fill, .. } = event {
                if *order_id != fill.maker_order_id {
                    continue;
                }
                if fill.maker_account == AccountId::new(1) {
                    maker_one += fill.quantity;
                } else if fill.maker_account == AccountId::new(2) {
                    maker_two += fill.quantity;
                }
            }
        }
        assert_eq!(maker_one, Quantity::from_int(5));
        assert_eq!(maker_two, Quantity::from_int(1));
    }

    #[test]
    fn fok_with_insufficient_depth_rejected() {
        let mut e = engine();
        e.process_command(cmd(
            1,
            CommandKind::NewOrder(limit(1, 1, Side::Sell, dec!(100), 1)),
        ))
        .unwrap();
        let mut fok = limit(2, 2, Side::Buy, dec!(100), 10);
        fok.time_in_force = TimeInForce::Fok;
        let b = e
            .process_command(cmd(2, CommandKind::NewOrder(fok)))
            .unwrap();
        assert!(b.was_rejected());
    }

    #[test]
    fn ioc_partial_fill_then_cancels_remainder() {
        let mut e = engine();
        e.process_command(cmd(
            1,
            CommandKind::NewOrder(limit(1, 1, Side::Sell, dec!(100), 3)),
        ))
        .unwrap();
        let mut ioc = limit(2, 2, Side::Buy, dec!(100), 10);
        ioc.time_in_force = TimeInForce::Ioc;
        let b = e
            .process_command(cmd(2, CommandKind::NewOrder(ioc)))
            .unwrap();
        assert_eq!(b.fill_count(), 2);
        // The unfilled remainder must produce a cancel event.
        assert!(b.events.iter().any(|x| matches!(
            x,
            EngineEvent::OrderCancelled {
                reason: CancelReason::Ioc,
                ..
            }
        )));
    }

    #[test]
    fn non_monotonic_seq_is_error() {
        let mut e = engine();
        e.process_command(cmd(
            5,
            CommandKind::NewOrder(limit(1, 1, Side::Sell, dec!(100), 1)),
        ))
        .unwrap();
        assert!(e
            .process_command(cmd(
                4,
                CommandKind::NewOrder(limit(2, 2, Side::Buy, dec!(100), 1)),
            ))
            .is_err());
    }

    #[test]
    fn session_halt_blocks_new_orders() {
        let mut e = engine();
        e.process_command(cmd(1, CommandKind::SessionTransition(SessionState::Halt)))
            .unwrap();
        let b = e
            .process_command(cmd(
                2,
                CommandKind::NewOrder(limit(1, 1, Side::Sell, dec!(100), 1)),
            ))
            .unwrap();
        assert!(b.was_rejected());
    }
}
