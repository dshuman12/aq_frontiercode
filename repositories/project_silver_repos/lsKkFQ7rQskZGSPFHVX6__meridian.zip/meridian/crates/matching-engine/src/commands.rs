//! Engine input — `Command`.
//!
//! A `Command` is the unit of work the engine consumes. The sequencer
//! assigns a monotonic `SeqNo` to every command before handing it off,
//! and the engine processes them strictly in `seq_no` order. This is
//! the *only* knob that determines determinism: same commands in the
//! same order → same events out, byte-for-byte.
//!
//! Commands that don't logically belong to a single book (admin, halt,
//! session transitions) still go through the same channel so we can
//! recover from snapshot + log without a separate state machine.

use meridian_common::prelude::*;
use meridian_order_types::{AmendRequest, CancelRequest, NewOrder};
use serde::{Deserialize, Serialize};

use crate::session::SessionState;

/// One unit of work for the engine.
///
/// `seq_no` is set by the sequencer; the engine asserts strict
/// monotonicity and refuses to process gaps or replays. `at` is the
/// sequencer's wall clock when the command was admitted — the engine
/// uses this for `Order.received_at` and event timestamps so that
/// downstream consumers see a single coherent timeline.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Command {
    pub seq_no: SeqNo,
    pub at: Timestamp,
    pub kind: CommandKind,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum CommandKind {
    /// Place a new order. Validation is repeated in the engine even
    /// though the gateway already validated; the engine doesn't trust
    /// upstream invariants.
    NewOrder(NewOrder),

    /// Cancel an existing order.
    Cancel(CancelRequest),

    /// Amend an existing order. May or may not retain priority — see
    /// `AmendRequest::is_narrowing`.
    Amend(AmendRequest),

    /// Cancel-replace as one atomic unit. Used by FIX cancel-replace
    /// messages where the client doesn't want a window where neither
    /// the old nor the new order is on the book.
    CancelReplace {
        cancel: CancelRequest,
        new_order: NewOrder,
    },

    /// Cancel every resting order belonging to an account on the
    /// engine's symbol. Used by `MassCancel` and admin kill paths.
    MassCancelByAccount {
        account_id: AccountId,
        reason: String,
    },

    /// Transition the session state machine. Triggered by the auctions
    /// service on schedule, or by an operator for unscheduled halts.
    SessionTransition(SessionState),

    /// Trigger a snapshot capture at the current seq_no. The snapshot
    /// itself is written by the snapshot worker; the engine just
    /// emits a marker event so the worker knows it's safe to read.
    SnapshotMark { snapshot_id: SnapshotId },

    /// Engage the kill switch. After this, every NewOrder is rejected
    /// and every resting order can still be cancelled. Recovery
    /// requires a `SessionTransition` back to `Continuous`.
    KillSwitch { engaged: bool, reason: String },

    /// Heartbeat — no-op. Used to drive scheduled tasks (GTD expiry,
    /// peg repricing) without artificially injecting fake commands.
    Tick,
}

impl Command {
    #[must_use]
    pub fn new(seq_no: SeqNo, at: Timestamp, kind: CommandKind) -> Self {
        Self { seq_no, at, kind }
    }

    /// Whether this command should be rejected when the session refuses
    /// new orders. Cancels are always allowed; amends and new orders
    /// are not.
    #[must_use]
    pub const fn is_order_entry(&self) -> bool {
        matches!(
            self.kind,
            CommandKind::NewOrder(_) | CommandKind::CancelReplace { .. } | CommandKind::Amend(_)
        )
    }

    /// True if this command is purely administrative.
    #[must_use]
    pub const fn is_admin(&self) -> bool {
        matches!(
            self.kind,
            CommandKind::SessionTransition(_)
                | CommandKind::SnapshotMark { .. }
                | CommandKind::KillSwitch { .. }
                | CommandKind::Tick
        )
    }
}

#[cfg(test)]
mod tests {
    use chrono::Utc;
    use meridian_order_types::Side;
    use rust_decimal_macros::dec;

    use super::*;

    fn ts() -> Timestamp {
        Timestamp::from_datetime(Utc::now())
    }

    fn sym() -> Symbol {
        Symbol::new("BTC-USD").unwrap()
    }

    #[test]
    fn order_entry_classification() {
        let new = NewOrder::limit(
            AccountId::new(1),
            ClientOrderId::new(1),
            sym(),
            Side::Buy,
            Price::from_decimal(dec!(100)),
            Quantity::from_int(1),
        );
        let cmd = Command::new(SeqNo::new(1), ts(), CommandKind::NewOrder(new));
        assert!(cmd.is_order_entry());
        assert!(!cmd.is_admin());
    }

    #[test]
    fn admin_classification() {
        let cmd = Command::new(SeqNo::new(1), ts(), CommandKind::Tick);
        assert!(cmd.is_admin());
        assert!(!cmd.is_order_entry());
    }
}
