//! `LedgerBook` — the engine's authoritative order index.
//!
//! The book in `order-book` is keyed by `(side, price)` because that's
//! how matching iterates. But the engine also needs to look up orders
//! by `OrderId` (for cancels, amends, fills) and by `(account, symbol)`
//! (for mass cancels), and to keep the *full* `Order` record alive so
//! it can be returned in events.
//!
//! `LedgerBook` is the side index. It owns:
//!
//! - the `Book` itself (the ladder),
//! - a `HashMap<OrderId, Order>` (the full record),
//! - a `HashMap<OrderId, (Side, Price)>` (so we can locate the level
//!   in the book),
//! - a `HashMap<AccountId, FxHashSet<OrderId>>` (mass cancel),
//! - a `HashMap<ClientOrderId, OrderId>` (gateway-side resolution; we
//!   keep it for two-way mapping in events).
//!
//! Keeping these in sync is the single biggest source of bugs in any
//! matching engine. Every mutation goes through `insert_full`,
//! `remove_full`, or `update_full` — never poke the maps directly.

use fnv::FnvHashSet;
use meridian_common::prelude::*;
use meridian_order_book::{Book, RestingOrder};
use meridian_order_types::{Order, Side};
use std::collections::HashMap;

#[derive(Debug)]
pub struct LedgerBook {
    pub book: Book,
    full: HashMap<OrderId, Order>,
    locator: HashMap<OrderId, (Side, Price)>,
    by_account: HashMap<AccountId, FnvHashSet<OrderId>>,
    by_client_order_id: HashMap<ClientOrderId, OrderId>,
}

impl LedgerBook {
    #[must_use]
    pub fn new(symbol: Symbol) -> Self {
        Self {
            book: Book::new(symbol),
            full: HashMap::default(),
            locator: HashMap::default(),
            by_account: HashMap::default(),
            by_client_order_id: HashMap::default(),
        }
    }

    #[must_use]
    pub fn symbol(&self) -> &Symbol {
        &self.book.symbol
    }

    /// Insert a freshly-accepted resting order. The caller has already
    /// decided this order rests (post-only that didn't cross, GTC,
    /// Day, etc).
    pub fn insert_full(&mut self, order: Order, resting: RestingOrder) {
        debug_assert_eq!(order.id, resting.order_id);
        debug_assert_eq!(order.side, resting.side);

        self.locator.insert(order.id, (resting.side, resting.price));
        self.by_account
            .entry(order.account_id)
            .or_default()
            .insert(order.id);
        self.by_client_order_id
            .insert(order.client_order_id, order.id);
        self.full.insert(order.id, order);
        self.book.insert(resting);
    }

    /// Insert just the full record (no book entry). Used for stops
    /// that haven't triggered yet, and for fully-filled IOCs that we
    /// keep in the index for one tick so query-by-id can still answer.
    pub fn insert_full_offbook(&mut self, order: Order) {
        self.by_account
            .entry(order.account_id)
            .or_default()
            .insert(order.id);
        self.by_client_order_id
            .insert(order.client_order_id, order.id);
        self.full.insert(order.id, order);
    }

    /// Look up an order by id.
    #[must_use]
    pub fn get(&self, id: OrderId) -> Option<&Order> {
        self.full.get(&id)
    }

    /// Mutable access to an order. Use sparingly.
    pub fn get_mut(&mut self, id: OrderId) -> Option<&mut Order> {
        self.full.get_mut(&id)
    }

    /// Resolve a `ClientOrderId` to an `OrderId`. Used by the gateway
    /// path that strips `client_order_id` from the wire and feeds the
    /// engine `order_id` directly.
    #[must_use]
    pub fn resolve_client_id(&self, cid: ClientOrderId) -> Option<OrderId> {
        self.by_client_order_id.get(&cid).copied()
    }

    /// Where on the book is this order resting? `None` if it's a
    /// stop, a fully-filled IOC, or otherwise off-book.
    #[must_use]
    pub fn locate(&self, id: OrderId) -> Option<(Side, Price)> {
        self.locator.get(&id).copied()
    }

    /// Iterate all order ids belonging to `account` (resting + off-book).
    #[must_use]
    pub fn ids_for_account(&self, account: AccountId) -> Vec<OrderId> {
        self.by_account
            .get(&account)
            .map_or_else(Vec::new, |set| set.iter().copied().collect())
    }

    /// Has this order id ever been seen by the engine? Used to detect
    /// duplicate-ID submissions.
    #[must_use]
    pub fn knows_id(&self, id: OrderId) -> bool {
        self.full.contains_key(&id)
    }

    /// Remove the on-book record for an order. Returns the resting
    /// record if found. The full record is *kept* — fills emitted
    /// after a cancel-replace need to be able to look up the
    /// pre-replace order.
    pub fn remove_from_book(&mut self, id: OrderId) -> Option<RestingOrder> {
        let (side, price) = self.locator.remove(&id)?;
        self.book.remove(side, price, id)
    }

    /// Drop all traces of an order id — both book and indexes. This is
    /// what gets called after a terminal event has been emitted.
    pub fn forget(&mut self, id: OrderId) -> Option<Order> {
        let _ = self.remove_from_book(id);
        let order = self.full.remove(&id)?;
        if let Some(set) = self.by_account.get_mut(&order.account_id) {
            set.remove(&id);
            if set.is_empty() {
                self.by_account.remove(&order.account_id);
            }
        }
        self.by_client_order_id.remove(&order.client_order_id);
        Some(order)
    }

    /// How many orders are currently tracked. Includes off-book ones
    /// (stops, just-filled IOCs awaiting drop).
    #[must_use]
    pub fn order_count(&self) -> usize {
        self.full.len()
    }

    /// Number of distinct accounts with at least one tracked order.
    #[must_use]
    pub fn account_count(&self) -> usize {
        self.by_account.len()
    }

    /// Re-issue the locator for `id` — used after an iceberg refresh
    /// or amend that moved the order to a new (price, position).
    pub fn relocate(&mut self, id: OrderId, side: Side, price: Price) {
        self.locator.insert(id, (side, price));
    }

    /// Drop the on-book pointer for `id` without removing the full
    /// record. Used between the cancel and the new-order legs of a
    /// cancel-replace, when the order will be re-inserted at a new
    /// price.
    pub fn detach_from_book(&mut self, id: OrderId) {
        self.locator.remove(&id);
    }
}

#[cfg(test)]
mod tests {
    use chrono::Utc;
    use meridian_order_types::{NewOrder, SelfTradePrevention};
    use rust_decimal_macros::dec;

    use super::*;

    fn sym() -> Symbol {
        Symbol::new("BTC-USD").unwrap()
    }

    fn make_order(id: u128, account: u128, cid: u128) -> Order {
        let new = NewOrder::limit(
            AccountId::new(account),
            ClientOrderId::new(cid),
            sym(),
            Side::Buy,
            Price::from_decimal(dec!(100)),
            Quantity::from_int(1),
        );
        Order::from_new(
            &new,
            OrderId::new(id),
            SeqNo::new(id as u64),
            Timestamp::from_datetime(Utc::now()),
            SelfTradePrevention::DecrementCancel,
        )
    }

    fn make_resting(o: &Order) -> RestingOrder {
        RestingOrder {
            order_id: o.id,
            account_id: o.account_id,
            side: o.side,
            order_type: o.order_type,
            leaves_qty: o.leaves_qty,
            display_qty: o.display_qty,
            hidden_qty: None,
            price: o.limit_price.unwrap(),
            priority_seq: o.priority_seq,
            post_only: o.post_only,
        }
    }

    #[test]
    fn insert_then_locate() {
        let mut lb = LedgerBook::new(sym());
        let o = make_order(1, 1, 1);
        let r = make_resting(&o);
        lb.insert_full(o, r);
        assert_eq!(
            lb.locate(OrderId::new(1)),
            Some((Side::Buy, Price::from_decimal(dec!(100))))
        );
        assert_eq!(lb.order_count(), 1);
    }

    #[test]
    fn forget_clears_all_indexes() {
        let mut lb = LedgerBook::new(sym());
        let o = make_order(1, 7, 99);
        let r = make_resting(&o);
        lb.insert_full(o, r);
        let removed = lb.forget(OrderId::new(1));
        assert!(removed.is_some());
        assert_eq!(lb.order_count(), 0);
        assert_eq!(lb.account_count(), 0);
        assert!(lb.resolve_client_id(ClientOrderId::new(99)).is_none());
    }

    #[test]
    fn ids_for_account_lists_all() {
        let mut lb = LedgerBook::new(sym());
        for i in 1..=3 {
            let o = make_order(i, 42, i);
            let r = make_resting(&o);
            lb.insert_full(o, r);
        }
        let mut ids = lb.ids_for_account(AccountId::new(42));
        ids.sort();
        assert_eq!(ids.len(), 3);
    }

    #[test]
    fn duplicate_id_is_detectable() {
        let mut lb = LedgerBook::new(sym());
        let o = make_order(1, 1, 1);
        lb.insert_full(o.clone(), make_resting(&o));
        assert!(lb.knows_id(OrderId::new(1)));
    }
}
