//! Pro-rata matching policy.
//!
//! Allocate the aggressor's incoming quantity *proportionally* to the
//! visible quantity of every order at the price level, with a
//! largest-remainder rounding pass to ensure the integer-allocated
//! parts sum to exactly the aggressor's qty (no leftover dust, no
//! over-allocation).
//!
//! # Algorithm
//!
//! For each resting order `i`, compute
//!
//! ```text
//!   share_i = visible_i / total_visible
//!   raw_i   = share_i * incoming
//! ```
//!
//! Floor each `raw_i` to a whole "lot" (1 base unit by default; see
//! `Allocator::with_lot`). The remaining residue is distributed by
//! largest-remainder method — the order with the biggest fractional
//! part gets the next +1 lot, ties broken by `priority_seq` (lower
//! wins, i.e. older order).
//!
//! # Why not just round-down?
//!
//! Plain floor-and-stop loses lots; the residue would silently sit
//! with the aggressor and the resting orders would each be slightly
//! short. Largest-remainder is the cheap, deterministic, fair-ish
//! resolution. Reference: <docs/adr/0008-pro-rata-allocation.md>.
//!
//! # Determinism
//!
//! All ordering decisions are tie-broken by `priority_seq`, never by
//! iterator order or hashmap iteration. This means two replays of the
//! same command stream produce byte-identical allocations.

use meridian_common::prelude::*;
use meridian_order_book::PriceLevel;
use rust_decimal::Decimal;

use crate::policy::{Allocation, MatchingPolicy};

/// Pro-rata allocator with optional minimum-lot.
#[derive(Debug, Clone)]
pub struct ProRataPolicy {
    /// Allocations are rounded to multiples of this. Default 1 base
    /// unit (i.e. `Quantity::ONE`); set higher for venues with lot
    /// minimums.
    lot: Quantity,
}

impl Default for ProRataPolicy {
    fn default() -> Self {
        Self::new()
    }
}

impl ProRataPolicy {
    #[must_use]
    pub fn new() -> Self {
        Self { lot: Quantity::ONE }
    }

    #[must_use]
    pub fn with_lot(lot: Quantity) -> Self {
        debug_assert!(lot.is_positive());
        Self { lot }
    }

    /// As `allocate`, but skipping the first `skip` queue positions.
    /// Used by hybrid policy to layer on top of a top-of-book carve.
    pub fn allocate_skipping(
        &self,
        level: &PriceLevel,
        skip: usize,
        incoming_remaining: Quantity,
    ) -> Vec<Allocation> {
        let entries: Vec<(usize, OrderId, Quantity, SeqNo)> = level
            .iter()
            .enumerate()
            .skip(skip)
            .filter_map(|(idx, o)| {
                let v = o.visible_qty();
                if v.is_zero() {
                    None
                } else {
                    Some((idx, o.order_id, v, o.priority_seq))
                }
            })
            .collect();
        self.allocate_entries(&entries, incoming_remaining)
    }

    fn allocate_entries(
        &self,
        entries: &[(usize, OrderId, Quantity, SeqNo)],
        incoming_remaining: Quantity,
    ) -> Vec<Allocation> {
        if entries.is_empty() || incoming_remaining.is_zero() {
            return Vec::new();
        }

        let total_visible: Decimal = entries.iter().map(|(_, _, q, _)| q.into_decimal()).sum();
        if total_visible.is_zero() {
            return Vec::new();
        }

        let incoming = incoming_remaining.into_decimal();
        let lot = self.lot.into_decimal();
        let cap = total_visible.min(incoming);

        // Step 1: raw share + floor.
        let mut raw: Vec<(usize, OrderId, SeqNo, Quantity, Decimal, Decimal)> = entries
            .iter()
            .map(|(pos, id, vis, seq)| {
                let share = (vis.into_decimal() / total_visible) * cap;
                let floored = (share / lot).floor() * lot;
                let remainder = share - floored;
                (*pos, *id, *seq, *vis, floored, remainder)
            })
            .collect();

        // Step 2: residue distribution by largest-remainder.
        let allocated_so_far: Decimal = raw.iter().map(|x| x.4).sum();
        let mut residue = cap - allocated_so_far;

        if residue > Decimal::ZERO {
            // Sort by (remainder desc, priority_seq asc) — older
            // orders win ties.
            raw.sort_by(|a, b| b.5.cmp(&a.5).then_with(|| a.2.cmp(&b.2)));
            let mut idx = 0;
            while residue > Decimal::ZERO && idx < raw.len() {
                // Don't allocate more than the order can take.
                let entry = &mut raw[idx];
                let max_take = entry.3.into_decimal() - entry.4;
                let bump = lot.min(max_take).min(residue);
                if bump <= Decimal::ZERO {
                    idx += 1;
                    continue;
                }
                entry.4 += bump;
                residue -= bump;
                idx += 1;
                if idx == raw.len() && residue > Decimal::ZERO {
                    // Wrap around — there may still be capacity in
                    // earlier orders. This is the path that fires when
                    // an order is fully filled but we're not done
                    // distributing residue.
                    idx = 0;
                    if !raw
                        .iter()
                        .any(|x| x.3.into_decimal() - x.4 >= lot && residue > Decimal::ZERO)
                    {
                        break;
                    }
                }
            }

            // Restore a stable ordering on the way out — by queue
            // position, ascending.
            raw.sort_by_key(|x| x.0);
        }

        raw.into_iter()
            .filter(|x| x.4 > Decimal::ZERO)
            .map(|(pos, id, _seq, _vis, alloc, _r)| Allocation {
                queue_position: pos,
                order_id: id,
                fill_qty: Quantity::from_decimal(alloc),
            })
            .collect()
    }
}

impl MatchingPolicy for ProRataPolicy {
    fn name(&self) -> &'static str {
        "pro_rata"
    }

    fn allocate(&self, level: &PriceLevel, incoming_remaining: Quantity) -> Vec<Allocation> {
        let entries: Vec<(usize, OrderId, Quantity, SeqNo)> = level
            .iter()
            .enumerate()
            .filter_map(|(idx, o)| {
                let v = o.visible_qty();
                if v.is_zero() {
                    None
                } else {
                    Some((idx, o.order_id, v, o.priority_seq))
                }
            })
            .collect();
        self.allocate_entries(&entries, incoming_remaining)
    }
}

#[cfg(test)]
mod tests {
    use meridian_order_book::RestingOrder;
    use meridian_order_types::{OrderType, Side};
    use rust_decimal_macros::dec;

    use super::*;

    fn ord(id: u128, qty: i64, seq: u64) -> RestingOrder {
        RestingOrder {
            order_id: OrderId::new(id),
            account_id: AccountId::new(1),
            side: Side::Sell,
            order_type: OrderType::Limit,
            leaves_qty: Quantity::from_int(qty),
            display_qty: None,
            hidden_qty: None,
            price: Price::from_decimal(dec!(100)),
            priority_seq: SeqNo::new(seq),
            post_only: false,
        }
    }

    fn level_with(orders: &[RestingOrder]) -> PriceLevel {
        let mut l = PriceLevel::new(Price::from_decimal(dec!(100)));
        for o in orders {
            l.push_back(o.clone());
        }
        l
    }

    #[test]
    fn fills_sum_to_aggressor() {
        let lvl = level_with(&[ord(1, 30, 1), ord(2, 20, 2), ord(3, 10, 3)]);
        let p = ProRataPolicy::new();
        let allocs = p.allocate(&lvl, Quantity::from_int(15));
        let total: Quantity = allocs.iter().fold(Quantity::ZERO, |a, x| a + x.fill_qty);
        assert_eq!(total, Quantity::from_int(15));
    }

    #[test]
    fn never_over_allocates() {
        let lvl = level_with(&[ord(1, 10, 1), ord(2, 10, 2)]);
        let p = ProRataPolicy::new();
        // Aggressor wants more than the level has.
        let allocs = p.allocate(&lvl, Quantity::from_int(100));
        let total: Quantity = allocs.iter().fold(Quantity::ZERO, |a, x| a + x.fill_qty);
        assert_eq!(total, Quantity::from_int(20));
        for a in &allocs {
            assert!(a.fill_qty <= Quantity::from_int(10));
        }
    }

    #[test]
    fn largest_remainder_to_time_leader_on_tie() {
        // Two equal-sized orders; aggressor's qty is odd → one
        // gets +1 lot. The older order (lower priority_seq) wins.
        let lvl = level_with(&[ord(1, 5, 1), ord(2, 5, 2)]);
        let p = ProRataPolicy::new();
        let allocs = p.allocate(&lvl, Quantity::from_int(3));
        let by_id: std::collections::HashMap<_, _> =
            allocs.iter().map(|a| (a.order_id, a.fill_qty)).collect();
        assert_eq!(by_id[&OrderId::new(1)], Quantity::from_int(2));
        assert_eq!(by_id[&OrderId::new(2)], Quantity::from_int(1));
    }

    #[test]
    fn empty_level_yields_nothing() {
        let lvl = PriceLevel::new(Price::from_decimal(dec!(100)));
        let p = ProRataPolicy::new();
        let allocs = p.allocate(&lvl, Quantity::from_int(10));
        assert!(allocs.is_empty());
    }

    #[test]
    fn skip_offsets_queue_positions() {
        let lvl = level_with(&[ord(1, 5, 1), ord(2, 5, 2), ord(3, 5, 3)]);
        let p = ProRataPolicy::new();
        let allocs = p.allocate_skipping(&lvl, 1, Quantity::from_int(4));
        for a in &allocs {
            assert!(a.queue_position >= 1);
        }
        let total: Quantity = allocs.iter().fold(Quantity::ZERO, |a, x| a + x.fill_qty);
        assert_eq!(total, Quantity::from_int(4));
    }
}
