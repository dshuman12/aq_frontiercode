//! Session state machine.
//!
//! ```text
//!   PreOpen ──► OpeningAuction ──► Continuous ──► ClosingAuction ──► PostClose
//!      │                              │                                  │
//!      └────────── Halt ◄─────────────┘                                  │
//!                  ▲                                                     │
//!                  └─────────────── (manual or vol-circuit) ◄────────────┘
//! ```
//!
//! - **PreOpen** — accepts ATO, rejects continuous orders.
//! - **OpeningAuction** — runs the cross; only ATO and resting day/GTC
//!   contribute. Computed by the auctions service, executed by the
//!   engine when commanded.
//! - **Continuous** — normal price-time matching.
//! - **ClosingAuction** — runs the close cross.
//! - **PostClose** — rejects new orders, cancels Day TIFs.
//! - **Halt** — refuses everything except cancels.
//!
//! The state machine is intentionally *not* clock-driven. The
//! auctions service drives transitions via `SessionTransition`
//! commands so that recovery from snapshot reproduces the same state
//! at the same `SeqNo`.

use serde::{Deserialize, Serialize};

#[derive(Debug, Default, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum SessionState {
    /// Pre-trading; ATO orders accepted, no matching.
    PreOpen,
    /// Opening auction in progress.
    OpeningAuction,
    /// Normal continuous trading.
    #[default]
    Continuous,
    /// Closing auction in progress.
    ClosingAuction,
    /// Post-trading; cancels only.
    PostClose,
    /// Halted — refuses every order-entry command.
    Halt,
}

impl SessionState {
    /// Whether continuous-flavour orders (limit, market, stop) are
    /// allowed in this state. Auction-only TIFs (ATO/ATC) have their
    /// own gate inside the engine.
    #[must_use]
    pub const fn accepts_continuous(self) -> bool {
        matches!(self, Self::Continuous)
    }

    /// Whether pre-auction orders (ATO/ATC) are allowed.
    #[must_use]
    pub const fn accepts_auction_orders(self) -> bool {
        matches!(
            self,
            Self::PreOpen | Self::Continuous | Self::ClosingAuction
        )
    }

    /// Whether cancels are allowed. Always true except (deliberately)
    /// during the actual cross — running the auction algorithm with
    /// orders disappearing under it would be a nightmare. The pause
    /// is brief; clients see "rejected, retry" for the duration.
    #[must_use]
    pub const fn accepts_cancels(self) -> bool {
        !matches!(self, Self::OpeningAuction | Self::ClosingAuction)
    }

    /// Whether the engine should attempt to match orders right now.
    #[must_use]
    pub const fn matches_continuously(self) -> bool {
        matches!(self, Self::Continuous)
    }

    /// Validate a transition. Returns `true` if the move is legal.
    ///
    /// We allow `Halt` from any state and back to `Continuous` from
    /// `Halt` (an operator-initiated resume). Everything else must
    /// follow the canonical lifecycle. Replays from snapshot bypass
    /// this validation by using `force_set` instead.
    #[must_use]
    pub const fn can_transition_to(self, target: Self) -> bool {
        if matches!(target, Self::Halt) {
            return true;
        }
        match (self, target) {
            (Self::PreOpen, Self::OpeningAuction)
            | (Self::OpeningAuction, Self::Continuous)
            | (Self::Continuous, Self::ClosingAuction)
            | (Self::ClosingAuction, Self::PostClose)
            | (Self::PostClose, Self::PreOpen)
            | (Self::Halt, Self::Continuous)
            | (Self::Halt, Self::PreOpen) => true,
            // Idempotent transitions are no-ops but legal.
            (a, b) if a as u8 == b as u8 => true,
            _ => false,
        }
    }
}

/// Session-level event, persisted alongside engine events.
///
/// Auction-cross details live in the `auctions` crate; the engine just
/// emits the entry/exit markers and re-emits the matched fills.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum SessionEvent {
    StateChanged {
        from: SessionState,
        to: SessionState,
    },
    AuctionStarted {
        auction_id: meridian_common::ids::AuctionId,
    },
    AuctionFinished {
        auction_id: meridian_common::ids::AuctionId,
        crossed_qty: meridian_common::money::Quantity,
    },
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn canonical_lifecycle_is_legal() {
        let path = [
            SessionState::PreOpen,
            SessionState::OpeningAuction,
            SessionState::Continuous,
            SessionState::ClosingAuction,
            SessionState::PostClose,
            SessionState::PreOpen,
        ];
        for w in path.windows(2) {
            assert!(w[0].can_transition_to(w[1]), "{:?} → {:?}", w[0], w[1]);
        }
    }

    #[test]
    fn halt_from_anywhere() {
        for s in [
            SessionState::PreOpen,
            SessionState::OpeningAuction,
            SessionState::Continuous,
            SessionState::ClosingAuction,
            SessionState::PostClose,
        ] {
            assert!(s.can_transition_to(SessionState::Halt));
        }
    }

    #[test]
    fn cannot_skip_states() {
        assert!(!SessionState::PreOpen.can_transition_to(SessionState::Continuous));
        assert!(!SessionState::Continuous.can_transition_to(SessionState::PreOpen));
    }

    #[test]
    fn cancels_blocked_during_cross() {
        assert!(!SessionState::OpeningAuction.accepts_cancels());
        assert!(!SessionState::ClosingAuction.accepts_cancels());
        assert!(SessionState::Continuous.accepts_cancels());
        assert!(SessionState::Halt.accepts_cancels());
    }
}
