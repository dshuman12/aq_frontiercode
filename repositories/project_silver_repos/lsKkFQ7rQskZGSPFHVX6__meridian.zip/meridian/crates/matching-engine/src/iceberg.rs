//! Iceberg slice management.
//!
//! An iceberg order has two quantities:
//!
//! - `display_qty` — what the book and L2 market data show.
//! - `hidden_qty` — what the engine knows about but doesn't broadcast.
//!
//! When the visible slice is exhausted (i.e. the head of the queue has
//! `display_qty` filled), we need to "refresh": reveal a new slice
//! from the hidden pool, give it a fresh `priority_seq`, and re-insert
//! it at the back of the queue at the same price.
//!
//! The fresh `priority_seq` is the important bit: an iceberg cannot
//! get unfair advantage by hiding qty *and* keeping its time priority.
//! It loses time priority every time a slice is exhausted. This is
//! the standard rule across CME, Eurex, Cboe, and crypto venues.

use meridian_common::prelude::*;
use meridian_order_book::RestingOrder;
use meridian_order_types::OrderType;

use crate::events::EngineEvent;

/// Outcome of refreshing an iceberg slice.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum RefreshOutcome {
    /// New slice was revealed; engine must re-queue it.
    Revealed {
        new_slice: RestingOrder,
        revealed: Quantity,
        remaining_hidden: Quantity,
    },
    /// No hidden remains; the order is fully consumed.
    Done,
    /// Caller asked to refresh a non-iceberg order. Programmer error;
    /// debug builds panic. Release builds get a no-op.
    NotIceberg,
}

/// Plan a refresh given the current resting record.
///
/// `next_priority_seq` is the seqno the engine has just allocated
/// (typically the originating command's seq); the new slice gets it
/// so determinism is preserved. The returned slice is *not* yet on
/// the book — caller inserts it.
#[must_use]
pub fn plan_refresh(current: &RestingOrder, next_priority_seq: SeqNo) -> RefreshOutcome {
    if !matches!(current.order_type, OrderType::Iceberg) {
        debug_assert!(false, "plan_refresh called on non-iceberg");
        return RefreshOutcome::NotIceberg;
    }

    let Some(hidden) = current.hidden_qty else {
        return RefreshOutcome::Done;
    };
    if hidden.is_zero() {
        return RefreshOutcome::Done;
    }

    // The display target — how big is the slice we want to expose? It's
    // the original `display_qty`. If hidden < display_qty, we expose
    // whatever's left.
    let target_display = current.display_qty.expect("iceberg always has display_qty");

    let revealed = target_display.min(hidden);
    let remaining_hidden = hidden - revealed;

    let new_slice = RestingOrder {
        order_id: current.order_id,
        account_id: current.account_id,
        side: current.side,
        order_type: OrderType::Iceberg,
        leaves_qty: revealed,
        display_qty: Some(revealed),
        hidden_qty: if remaining_hidden.is_zero() {
            None
        } else {
            Some(remaining_hidden)
        },
        price: current.price,
        priority_seq: next_priority_seq,
        post_only: current.post_only,
    };

    RefreshOutcome::Revealed {
        new_slice,
        revealed,
        remaining_hidden,
    }
}

/// Build the `IcebergRefreshed` event from a `Revealed` outcome.
///
/// The engine calls this once it has actually re-queued the slice.
/// We separate planning from event emission so the policy layer can
/// inspect the plan first if needed.
#[must_use]
pub fn refresh_event(
    order_id: OrderId,
    revealed: Quantity,
    remaining_hidden: Quantity,
    new_priority_seq: SeqNo,
) -> EngineEvent {
    EngineEvent::IcebergRefreshed {
        order_id,
        revealed,
        remaining_hidden,
        new_priority_seq,
    }
}

#[cfg(test)]
mod tests {
    use meridian_order_types::Side;
    use rust_decimal_macros::dec;

    use super::*;

    fn iceberg(visible: i64, hidden: i64, seq: u64) -> RestingOrder {
        RestingOrder {
            order_id: OrderId::new(1),
            account_id: AccountId::new(1),
            side: Side::Sell,
            order_type: OrderType::Iceberg,
            leaves_qty: Quantity::from_int(visible),
            display_qty: Some(Quantity::from_int(visible)),
            hidden_qty: Some(Quantity::from_int(hidden)),
            price: Price::from_decimal(dec!(100)),
            priority_seq: SeqNo::new(seq),
            post_only: false,
        }
    }

    #[test]
    fn refresh_reveals_full_display() {
        let r = iceberg(10, 50, 1);
        let outcome = plan_refresh(&r, SeqNo::new(2));
        match outcome {
            RefreshOutcome::Revealed {
                new_slice,
                revealed,
                remaining_hidden,
            } => {
                assert_eq!(revealed, Quantity::from_int(10));
                assert_eq!(remaining_hidden, Quantity::from_int(40));
                assert_eq!(new_slice.priority_seq, SeqNo::new(2));
                assert_eq!(new_slice.leaves_qty, Quantity::from_int(10));
                assert_eq!(new_slice.display_qty, Some(Quantity::from_int(10)));
                assert_eq!(new_slice.hidden_qty, Some(Quantity::from_int(40)));
            },
            other => panic!("expected Revealed, got {:?}", other),
        }
    }

    #[test]
    fn refresh_with_partial_hidden_reveals_what_remains() {
        let r = iceberg(10, 4, 1);
        let outcome = plan_refresh(&r, SeqNo::new(2));
        match outcome {
            RefreshOutcome::Revealed {
                new_slice,
                revealed,
                remaining_hidden,
            } => {
                assert_eq!(revealed, Quantity::from_int(4));
                assert_eq!(remaining_hidden, Quantity::ZERO);
                assert!(new_slice.hidden_qty.is_none());
            },
            other => panic!("expected Revealed, got {:?}", other),
        }
    }

    #[test]
    fn refresh_with_zero_hidden_is_done() {
        let mut r = iceberg(10, 0, 1);
        r.hidden_qty = Some(Quantity::ZERO);
        assert_eq!(plan_refresh(&r, SeqNo::new(2)), RefreshOutcome::Done);

        r.hidden_qty = None;
        assert_eq!(plan_refresh(&r, SeqNo::new(2)), RefreshOutcome::Done);
    }

    #[test]
    fn refresh_loses_priority_seq() {
        let r = iceberg(10, 50, 1);
        let outcome = plan_refresh(&r, SeqNo::new(99));
        if let RefreshOutcome::Revealed { new_slice, .. } = outcome {
            assert_eq!(new_slice.priority_seq, SeqNo::new(99));
            assert_ne!(new_slice.priority_seq, r.priority_seq);
        }
    }
}
