// Meridian matching engine.
//
// One `Engine` instance per (shard, symbol). The engine is single-threaded
// per symbol — that is the *only* concurrency story we use to keep
// matching deterministic. Everything else (gateways, market-data fanout)
// is multi-threaded behind it.
//
// The engine is pure: it consumes commands, produces events, and never
// does I/O. The event log is written by the sequencer; the snapshot
// store is written by the snapshot worker. Everything that interacts
// with the outside world is a separate process.
//
// # Design notes
//
// - We avoid `f64` everywhere; prices and quantities are `Decimal`.
// - The book is a `BTreeMap<Price, PriceLevel>`; see `order-book`.
// - Stops live in a separate trigger map, not on the visible book.
// - Iceberg orders book *only* their visible slice; the hidden portion
//   is held in `RestingOrder.hidden_qty` and refreshed when the slice
//   is exhausted (joining the back of the queue at that price).
// - STP modes are applied per-fill, before the fill is finalised.
// - Pro-rata residue follows largest-remainder; ties go to the time
//   leader.
// - Self-trade prevention runs *before* the fill is applied to either
//   order — so STP=DC actually decrements the smaller order, not the
//   incoming aggressor regardless of size.
//
// See `docs/adr/0007-matching-determinism.md` for the principles.

#![forbid(unsafe_code)]
#![deny(rust_2018_idioms)]
#![allow(clippy::pedantic, clippy::nursery, missing_debug_implementations)]
#![allow(
    clippy::module_name_repetitions,
    clippy::missing_errors_doc,
    clippy::missing_panics_doc,
    clippy::must_use_candidate,
    clippy::cast_possible_truncation,
    clippy::cast_precision_loss,
    clippy::similar_names,
    clippy::too_many_lines
)]

pub mod commands;
pub mod engine;
pub mod error;
pub mod events;
pub mod iceberg;
pub mod ledger_book;
pub mod peg;
pub mod policy;
pub mod pro_rata;
pub mod session;
pub mod stops;
pub mod stp;

pub use commands::{Command, CommandKind};
pub use engine::{Engine, EngineConfig};
pub use error::{EngineError, EngineResult};
pub use events::{EngineEvent, EventBatch};
pub use policy::{MatchingPolicy, PolicyKind, PriceTimePolicy};
pub use pro_rata::ProRataPolicy;
pub use session::{SessionEvent, SessionState};
