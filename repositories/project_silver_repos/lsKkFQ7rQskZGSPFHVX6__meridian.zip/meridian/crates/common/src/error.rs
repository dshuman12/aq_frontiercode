//! Error baseline for the platform.
//!
//! Every crate has its own `Error` enum (so callers can match precisely),
//! but they all implement `From<this::Error>`. Treat the enum here as the
//! "miscellaneous fallback" — typed errors that don't fit anywhere
//! more specific.

use std::borrow::Cow;

use thiserror::Error;

/// Result alias for crates that don't define their own.
pub type Result<T, E = Error> = std::result::Result<T, E>;

/// Common error kinds.
///
/// New variants should be added sparingly. If your case is more specific
/// than these, define an error type in your crate instead.
#[non_exhaustive]
#[derive(Debug, Error)]
pub enum Error {
    /// A value that should have been valid wasn't.
    #[error("invalid argument: {0}")]
    InvalidArgument(Cow<'static, str>),

    /// Lookup failed.
    #[error("not found: {0}")]
    NotFound(Cow<'static, str>),

    /// Caller is not allowed to do this.
    #[error("permission denied: {0}")]
    PermissionDenied(Cow<'static, str>),

    /// Some precondition wasn't satisfied (e.g. stale read, wrong state).
    #[error("failed precondition: {0}")]
    FailedPrecondition(Cow<'static, str>),

    /// Resource temporarily unavailable; safe to retry.
    #[error("unavailable: {0}")]
    Unavailable(Cow<'static, str>),

    /// Hard limit exceeded.
    #[error("resource exhausted: {0}")]
    ResourceExhausted(Cow<'static, str>),

    /// Bug. Caller should report.
    #[error("internal: {0}")]
    Internal(Cow<'static, str>),

    /// Wraps an arbitrary upstream error.
    #[error(transparent)]
    Other(#[from] Box<dyn std::error::Error + Send + Sync + 'static>),
}

impl Error {
    pub fn invalid_argument(msg: impl Into<Cow<'static, str>>) -> Self {
        Self::InvalidArgument(msg.into())
    }

    pub fn not_found(msg: impl Into<Cow<'static, str>>) -> Self {
        Self::NotFound(msg.into())
    }

    pub fn permission_denied(msg: impl Into<Cow<'static, str>>) -> Self {
        Self::PermissionDenied(msg.into())
    }

    pub fn failed_precondition(msg: impl Into<Cow<'static, str>>) -> Self {
        Self::FailedPrecondition(msg.into())
    }

    pub fn unavailable(msg: impl Into<Cow<'static, str>>) -> Self {
        Self::Unavailable(msg.into())
    }

    pub fn resource_exhausted(msg: impl Into<Cow<'static, str>>) -> Self {
        Self::ResourceExhausted(msg.into())
    }

    pub fn internal(msg: impl Into<Cow<'static, str>>) -> Self {
        Self::Internal(msg.into())
    }

    /// Coarse classification — useful for telemetry / metrics labels.
    pub const fn kind(&self) -> ErrorKind {
        match self {
            Self::InvalidArgument(_) => ErrorKind::InvalidArgument,
            Self::NotFound(_) => ErrorKind::NotFound,
            Self::PermissionDenied(_) => ErrorKind::PermissionDenied,
            Self::FailedPrecondition(_) => ErrorKind::FailedPrecondition,
            Self::Unavailable(_) => ErrorKind::Unavailable,
            Self::ResourceExhausted(_) => ErrorKind::ResourceExhausted,
            Self::Internal(_) => ErrorKind::Internal,
            Self::Other(_) => ErrorKind::Other,
        }
    }

    /// Whether the operation is safe to retry as-is.
    pub const fn is_retryable(&self) -> bool {
        matches!(self, Self::Unavailable(_))
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
#[non_exhaustive]
pub enum ErrorKind {
    InvalidArgument,
    NotFound,
    PermissionDenied,
    FailedPrecondition,
    Unavailable,
    ResourceExhausted,
    Internal,
    Other,
}

impl ErrorKind {
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::InvalidArgument => "invalid_argument",
            Self::NotFound => "not_found",
            Self::PermissionDenied => "permission_denied",
            Self::FailedPrecondition => "failed_precondition",
            Self::Unavailable => "unavailable",
            Self::ResourceExhausted => "resource_exhausted",
            Self::Internal => "internal",
            Self::Other => "other",
        }
    }
}

impl std::fmt::Display for ErrorKind {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(self.as_str())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn kind_roundtrip() {
        let cases = [
            (Error::invalid_argument("a"), ErrorKind::InvalidArgument),
            (Error::not_found("a"), ErrorKind::NotFound),
            (Error::permission_denied("a"), ErrorKind::PermissionDenied),
            (
                Error::failed_precondition("a"),
                ErrorKind::FailedPrecondition,
            ),
            (Error::unavailable("a"), ErrorKind::Unavailable),
            (Error::resource_exhausted("a"), ErrorKind::ResourceExhausted),
            (Error::internal("a"), ErrorKind::Internal),
        ];
        for (e, k) in cases {
            assert_eq!(e.kind(), k);
            assert_eq!(format!("{}", k), k.as_str());
        }
    }

    #[test]
    fn only_unavailable_is_retryable_by_default() {
        assert!(Error::unavailable("x").is_retryable());
        assert!(!Error::internal("x").is_retryable());
        assert!(!Error::not_found("x").is_retryable());
    }
}
