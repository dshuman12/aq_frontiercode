//! Thin wrapper around `tracing_subscriber` so every binary in the
//! workspace logs the same way.
//!
//! The format we use:
//!
//! - JSON in production (`MERIDIAN_LOG_FORMAT=json`),
//! - human-readable in dev (`MERIDIAN_LOG_FORMAT=text` or unset).
//!
//! Level is taken from `MERIDIAN_LOG` env var, defaulting to `info`.

use std::env;

use tracing_subscriber::layer::SubscriberExt as _;
use tracing_subscriber::util::SubscriberInitExt as _;
use tracing_subscriber::{fmt, EnvFilter, Registry};

/// Initialise the global tracing subscriber. Idempotent — subsequent
/// calls are no-ops.
pub fn init() {
    static INIT: std::sync::Once = std::sync::Once::new();
    INIT.call_once(install);
}

fn install() {
    let filter = EnvFilter::try_from_env("MERIDIAN_LOG")
        .unwrap_or_else(|_| EnvFilter::new("info,sqlx=warn,hyper=warn"));

    let format = env::var("MERIDIAN_LOG_FORMAT").unwrap_or_else(|_| "text".to_owned());

    match format.as_str() {
        "json" => {
            let layer = fmt::layer()
                .json()
                .with_current_span(true)
                .with_span_list(false)
                .with_target(true)
                .with_thread_ids(true);
            let _ = Registry::default().with(filter).with(layer).try_init();
        },
        _ => {
            let layer = fmt::layer().compact().with_target(true).with_level(true);
            let _ = Registry::default().with(filter).with(layer).try_init();
        },
    }
}

/// Convenience for binaries that need a one-line bring-up.
pub fn init_for_bin(crate_name: &'static str) {
    init();
    tracing::info!(target: "meridian.boot", crate_ = crate_name, "starting");
}
