//! Fixed-point money and quantity types.
//!
//! There is no `f64` price anywhere in this codebase. `clippy.toml`
//! actively bans `f64`/`f32` from the workspace; reach for [`Price`] and
//! [`Quantity`] instead.
//!
//! # Conventions
//!
//! - Prices are quoted in the *quote* currency per *base* unit.
//! - Quantities are in base units. Notional is `price * quantity` in the
//!   quote currency.
//! - All arithmetic returns a typed result so accidentally adding a
//!   price to a quantity is a compile error.
//! - Tick / lot enforcement is handled at the boundary, not at the
//!   `Price` / `Quantity` layer. The types here just hold values.

use std::cmp::Ordering;
use std::fmt;
use std::ops::{Add, AddAssign, Div, Mul, Neg, Sub, SubAssign};
use std::str::FromStr;

use rust_decimal::Decimal;
use rust_decimal_macros::dec;
use serde::{Deserialize, Deserializer, Serialize, Serializer};

use crate::error::{Error, Result};

/// Number of decimal places we serialise prices with on the wire.
pub const DEFAULT_PRICE_SCALE: u32 = 8;

/// Number of decimal places we serialise quantities with on the wire.
pub const DEFAULT_QTY_SCALE: u32 = 8;

/// Maximum exponent supported by the underlying `Decimal`.
pub const MAX_DECIMAL_SCALE: u32 = 28;

macro_rules! decimal_newtype {
    ($name:ident, $doc:literal $(, default_scale = $scale:expr)?) => {
        #[doc = $doc]
        #[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
        #[repr(transparent)]
        pub struct $name(Decimal);

        impl $name {
            pub const ZERO: Self = Self(Decimal::ZERO);
            pub const ONE: Self = Self(Decimal::ONE);

            #[must_use]
            pub const fn from_decimal(d: Decimal) -> Self { Self(d) }

            #[must_use]
            pub const fn into_decimal(self) -> Decimal { self.0 }

            #[must_use]
            pub fn from_int(n: i64) -> Self { Self(Decimal::from(n)) }

            pub fn from_str_strict(s: &str) -> Result<Self> {
                let d = Decimal::from_str(s).map_err(|e| {
                    Error::invalid_argument(format!("{}: {}", stringify!($name), e))
                })?;
                Ok(Self(d))
            }

            #[must_use]
            pub fn is_zero(&self) -> bool { self.0.is_zero() }

            #[must_use]
            pub fn is_positive(&self) -> bool { self.0.is_sign_positive() && !self.0.is_zero() }

            #[must_use]
            pub fn is_negative(&self) -> bool { self.0.is_sign_negative() && !self.0.is_zero() }

            #[must_use]
            pub fn abs(self) -> Self { Self(self.0.abs()) }

            #[must_use]
            pub fn min(self, other: Self) -> Self {
                if self.0 <= other.0 { self } else { other }
            }

            #[must_use]
            pub fn max(self, other: Self) -> Self {
                if self.0 >= other.0 { self } else { other }
            }

            #[must_use]
            pub fn scale(self) -> u32 { self.0.scale() }

            $(
                #[must_use]
                pub fn rescale_default(self) -> Self {
                    let mut d = self.0;
                    d.rescale($scale);
                    Self(d)
                }
            )?
        }

        impl fmt::Display for $name {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Display::fmt(&self.0, f)
            }
        }

        impl Serialize for $name {
            fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
            where
                S: Serializer,
            {
                serializer.collect_str(&self.0)
            }
        }

        impl<'de> Deserialize<'de> for $name {
            fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
            where
                D: Deserializer<'de>,
            {
                let raw = String::deserialize(deserializer)?;
                Decimal::from_str(&raw)
                    .map(Self)
                    .map_err(serde::de::Error::custom)
            }
        }

        impl PartialOrd for $name {
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> { Some(self.cmp(other)) }
        }

        impl Ord for $name {
            fn cmp(&self, other: &Self) -> Ordering { self.0.cmp(&other.0) }
        }

        impl std::hash::Hash for $name {
            fn hash<H: std::hash::Hasher>(&self, h: &mut H) { self.0.hash(h); }
        }

        impl FromStr for $name {
            type Err = Error;

            fn from_str(s: &str) -> Result<Self> {
                Self::from_str_strict(s)
            }
        }

        impl Add for $name {
            type Output = Self;
            fn add(self, rhs: Self) -> Self { Self(self.0 + rhs.0) }
        }

        impl AddAssign for $name {
            fn add_assign(&mut self, rhs: Self) { self.0 += rhs.0; }
        }

        impl Sub for $name {
            type Output = Self;
            fn sub(self, rhs: Self) -> Self { Self(self.0 - rhs.0) }
        }

        impl SubAssign for $name {
            fn sub_assign(&mut self, rhs: Self) { self.0 -= rhs.0; }
        }

        impl Neg for $name {
            type Output = Self;
            fn neg(self) -> Self { Self(-self.0) }
        }

        impl From<Decimal> for $name {
            fn from(d: Decimal) -> Self { Self(d) }
        }

        impl From<$name> for Decimal {
            fn from(v: $name) -> Self { v.0 }
        }
    };
}

decimal_newtype!(
    Price,
    "Price quoted in the quote currency, per one base unit.",
    default_scale = DEFAULT_PRICE_SCALE
);
decimal_newtype!(
    Quantity,
    "Quantity of base asset.",
    default_scale = DEFAULT_QTY_SCALE
);
decimal_newtype!(Notional, "Quote-currency value (price * quantity).");
decimal_newtype!(Fee, "Fee in the quote currency. Negative means rebate.");

// --- typed arithmetic between distinct money types ----------------------------

impl Mul<Quantity> for Price {
    type Output = Notional;
    fn mul(self, qty: Quantity) -> Notional {
        Notional(self.0 * qty.0)
    }
}

impl Mul<Price> for Quantity {
    type Output = Notional;
    fn mul(self, p: Price) -> Notional {
        Notional(self.0 * p.0)
    }
}

impl Div<Quantity> for Notional {
    type Output = Price;
    fn div(self, qty: Quantity) -> Price {
        Price(self.0 / qty.0)
    }
}

impl Div<Price> for Notional {
    type Output = Quantity;
    fn div(self, price: Price) -> Quantity {
        Quantity(self.0 / price.0)
    }
}

// --- tick / lot ---------------------------------------------------------------

/// Smallest price increment for a symbol. e.g. `0.01` for BTC-USD.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(transparent)]
pub struct TickSize(pub Price);

impl TickSize {
    /// Round `p` *down* to the nearest tick.
    #[must_use]
    pub fn floor_to(&self, p: Price) -> Price {
        if self.0.is_zero() {
            return p;
        }
        let inner = p.into_decimal();
        let tick = self.0.into_decimal();
        Price::from_decimal((inner / tick).floor() * tick)
    }

    /// Round `p` *up* to the nearest tick.
    #[must_use]
    pub fn ceil_to(&self, p: Price) -> Price {
        if self.0.is_zero() {
            return p;
        }
        let inner = p.into_decimal();
        let tick = self.0.into_decimal();
        Price::from_decimal((inner / tick).ceil() * tick)
    }

    /// True when `p` lies exactly on a tick.
    #[must_use]
    pub fn is_aligned(&self, p: Price) -> bool {
        if self.0.is_zero() {
            return true;
        }
        (p.into_decimal() % self.0.into_decimal()).is_zero()
    }
}

/// Smallest quantity increment for a symbol.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(transparent)]
pub struct LotSize(pub Quantity);

impl LotSize {
    #[must_use]
    pub fn floor_to(&self, q: Quantity) -> Quantity {
        if self.0.is_zero() {
            return q;
        }
        let inner = q.into_decimal();
        let lot = self.0.into_decimal();
        Quantity::from_decimal((inner / lot).floor() * lot)
    }

    #[must_use]
    pub fn is_aligned(&self, q: Quantity) -> bool {
        if self.0.is_zero() {
            return true;
        }
        (q.into_decimal() % self.0.into_decimal()).is_zero()
    }
}

/// Basis points — 1/100th of a percent. We store as integer for exactness.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(transparent)]
pub struct Bps(pub i32);

impl Bps {
    pub const ZERO: Self = Self(0);

    #[must_use]
    pub const fn new(b: i32) -> Self {
        Self(b)
    }

    /// Apply this rate to a notional, returning the resulting fee.
    /// Rounding is half-even, banker's style.
    #[must_use]
    pub fn apply(self, notional: Notional) -> Fee {
        let bps = Decimal::from(self.0);
        let factor = bps / dec!(10_000);
        let mut value = notional.into_decimal() * factor;
        // bankers' rounding to 8dp avoids drift on long-running fee accruals
        value.rescale(8);
        Fee::from_decimal(value)
    }
}

#[cfg(test)]
mod tests {
    use rust_decimal_macros::dec;

    use super::*;

    #[test]
    fn price_qty_yields_notional() {
        let p: Price = Price::from_decimal(dec!(101.50));
        let q: Quantity = Quantity::from_decimal(dec!(2));
        let n: Notional = p * q;
        assert_eq!(n.into_decimal(), dec!(203.00));
        let n2: Notional = q * p;
        assert_eq!(n, n2);
    }

    #[test]
    fn tick_floor_and_ceil() {
        let tick = TickSize(Price::from_decimal(dec!(0.05)));
        let p = Price::from_decimal(dec!(101.07));
        assert_eq!(tick.floor_to(p).into_decimal(), dec!(101.05));
        assert_eq!(tick.ceil_to(p).into_decimal(), dec!(101.10));
        assert!(!tick.is_aligned(p));
        assert!(tick.is_aligned(Price::from_decimal(dec!(101.05))));
    }

    #[test]
    fn lot_floor() {
        let lot = LotSize(Quantity::from_decimal(dec!(0.01)));
        let q = Quantity::from_decimal(dec!(1.234));
        assert_eq!(lot.floor_to(q).into_decimal(), dec!(1.23));
    }

    #[test]
    fn bps_apply() {
        let bps = Bps::new(25); // 25 bps = 0.25%
        let notional = Notional::from_decimal(dec!(10_000));
        let fee = bps.apply(notional).into_decimal();
        assert_eq!(fee, dec!(25.00000000));
    }

    #[test]
    fn negative_bps_yields_rebate() {
        let bps = Bps::new(-1);
        let notional = Notional::from_decimal(dec!(10_000));
        let fee = bps.apply(notional);
        assert!(fee.is_negative());
    }

    #[test]
    fn ordering_works_through_newtype() {
        let a = Price::from_decimal(dec!(1));
        let b = Price::from_decimal(dec!(2));
        assert!(a < b);
        assert_eq!(a.max(b), b);
        assert_eq!(a.min(b), a);
    }
}
