//! Extension traits and helpers around `rust_decimal::Decimal`.
//!
//! The newtypes in `money.rs` deliberately don't expose the underlying
//! `Decimal` API directly. When we *do* need that API (mostly inside
//! the matching engine for tick / pro-rata math), we route through the
//! helpers here so that the policy is centralised.

use rust_decimal::{Decimal, RoundingStrategy};

/// Half-even rounding (banker's). Default everywhere money is involved.
#[must_use]
pub fn round_half_even(d: Decimal, scale: u32) -> Decimal {
    d.round_dp_with_strategy(scale, RoundingStrategy::MidpointNearestEven)
}

/// Half-up rounding. Use sparingly — only where a regulator mandates
/// (e.g. some EU disclosure rules).
#[must_use]
pub fn round_half_up(d: Decimal, scale: u32) -> Decimal {
    d.round_dp_with_strategy(scale, RoundingStrategy::MidpointAwayFromZero)
}

/// Truncate towards zero.
#[must_use]
pub fn trunc(d: Decimal, scale: u32) -> Decimal {
    d.round_dp_with_strategy(scale, RoundingStrategy::ToZero)
}

/// Floor — rounds towards negative infinity. Used for fee accruals
/// where we always want to round in our favour for buyers.
#[must_use]
pub fn floor(d: Decimal, scale: u32) -> Decimal {
    d.round_dp_with_strategy(scale, RoundingStrategy::ToNegativeInfinity)
}

/// Ceiling — rounds towards positive infinity. Symmetric counterpart of
/// `floor`.
#[must_use]
pub fn ceil(d: Decimal, scale: u32) -> Decimal {
    d.round_dp_with_strategy(scale, RoundingStrategy::ToPositiveInfinity)
}

/// Pro-rata allocation of `total` across `weights`, returning per-bucket
/// allocations whose sum equals `total` exactly (no rounding leak).
///
/// The convention for the residue (the lot left after rounding) is
/// **largest-remainder method**: it goes to the bucket with the
/// largest fractional remainder. If multiple buckets tie on the
/// remainder, the *first* bucket wins (caller controls input order).
///
/// Returns `None` if weights are empty or sum to zero.
#[must_use]
pub fn pro_rata(total: Decimal, weights: &[Decimal], scale: u32) -> Option<Vec<Decimal>> {
    if weights.is_empty() {
        return None;
    }
    let weight_sum: Decimal = weights.iter().copied().sum();
    if weight_sum.is_zero() {
        return None;
    }

    // First pass: floor-rounded share + remainder.
    let mut allocations: Vec<Decimal> = Vec::with_capacity(weights.len());
    let mut remainders: Vec<(usize, Decimal)> = Vec::with_capacity(weights.len());
    let mut allocated_total = Decimal::ZERO;

    for (i, &w) in weights.iter().enumerate() {
        let share = total * w / weight_sum;
        let floored = floor(share, scale);
        allocations.push(floored);
        remainders.push((i, share - floored));
        allocated_total += floored;
    }

    let mut residue = total - allocated_total;
    if residue.is_zero() {
        return Some(allocations);
    }

    // Distribute residue using largest-remainder method.
    let unit = Decimal::new(1, scale);
    remainders.sort_by(|a, b| b.1.cmp(&a.1).then(a.0.cmp(&b.0)));
    for (i, _rem) in remainders {
        if residue.is_zero() {
            break;
        }
        allocations[i] += unit;
        residue -= unit;
    }

    Some(allocations)
}

#[cfg(test)]
mod tests {
    use rust_decimal_macros::dec;

    use super::*;

    #[test]
    fn round_half_even_banker() {
        assert_eq!(round_half_even(dec!(1.5), 0), dec!(2));
        assert_eq!(round_half_even(dec!(2.5), 0), dec!(2));
        assert_eq!(round_half_even(dec!(3.5), 0), dec!(4));
    }

    #[test]
    fn pro_rata_sums_exactly() {
        let weights = vec![dec!(1), dec!(2), dec!(3)];
        let alloc = pro_rata(dec!(10), &weights, 0).unwrap();
        assert_eq!(alloc.iter().copied().sum::<Decimal>(), dec!(10));
    }

    #[test]
    fn pro_rata_residue_to_largest_remainder() {
        // 10 split across [1,1,1] = 3.33 each, residue 1.
        // Each remainder is identical → goes to first bucket.
        let weights = vec![dec!(1), dec!(1), dec!(1)];
        let alloc = pro_rata(dec!(10), &weights, 0).unwrap();
        assert_eq!(alloc.iter().copied().sum::<Decimal>(), dec!(10));
        assert_eq!(alloc[0], dec!(4));
        assert_eq!(alloc[1], dec!(3));
        assert_eq!(alloc[2], dec!(3));
    }

    #[test]
    fn pro_rata_zero_weights_is_none() {
        let weights = vec![dec!(0), dec!(0)];
        assert!(pro_rata(dec!(10), &weights, 0).is_none());
    }

    #[test]
    fn floor_and_ceil_directional() {
        assert_eq!(floor(dec!(1.99), 0), dec!(1));
        assert_eq!(ceil(dec!(1.01), 0), dec!(2));
        assert_eq!(floor(dec!(-1.01), 0), dec!(-2));
        assert_eq!(ceil(dec!(-1.99), 0), dec!(-1));
    }
}
