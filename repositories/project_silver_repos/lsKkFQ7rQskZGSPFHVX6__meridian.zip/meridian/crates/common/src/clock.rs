//! Clock abstraction.
//!
//! Real time is read through one of these implementations rather than
//! `chrono::Utc::now` directly so that:
//!
//! - tests can pin time deterministically;
//! - the replay subsystem can step time forward in lock-step with the
//!   recorded event log;
//! - the matching engine and sequencer share a single source of truth.
//!
//! `clippy.toml` bans the direct calls. Use [`SystemClock`] in prod,
//! [`FixedClock`] in unit tests, [`SteppedClock`] in replay.

use std::sync::Arc;
use std::time::Duration;

use chrono::{DateTime, TimeZone, Utc};
use parking_lot::Mutex;

/// Trait for everything in the platform that needs to know "what time is it".
pub trait Clock: Send + Sync + 'static {
    /// UTC wall-clock instant.
    fn now(&self) -> DateTime<Utc>;

    /// UTC nanos since epoch — zero-allocation hot path.
    fn now_nanos(&self) -> i64 {
        self.now().timestamp_nanos_opt().unwrap_or_default()
    }

    /// Monotonic millisecond counter; not necessarily epoch-aligned.
    /// Defaults to wall-clock millis but implementations can override.
    fn monotonic_ms(&self) -> u64 {
        let nanos = self.now_nanos();
        if nanos < 0 {
            0
        } else {
            #[allow(clippy::cast_sign_loss)]
            {
                (nanos / 1_000_000) as u64
            }
        }
    }
}

/// Boxed-clock alias used when storing a Clock as a field.
pub type ClockRef = Arc<dyn Clock>;

/// Production clock — reads system time.
#[derive(Debug, Default, Clone, Copy)]
pub struct SystemClock;

impl Clock for SystemClock {
    fn now(&self) -> DateTime<Utc> {
        // Suppression: this is the *one* sanctioned use of the underlying
        // call. clippy.toml exempts this file via allow.
        #[allow(clippy::disallowed_methods)]
        Utc::now()
    }
}

/// Pinned clock — every read returns the same value. Useful in unit tests.
#[derive(Debug, Clone)]
pub struct FixedClock {
    fixed: DateTime<Utc>,
}

impl FixedClock {
    #[must_use]
    pub const fn new(t: DateTime<Utc>) -> Self {
        Self { fixed: t }
    }

    /// Convenience constructor: `FixedClock::at_unix(1_700_000_000)`.
    #[must_use]
    pub fn at_unix(secs: i64) -> Self {
        Self::new(
            Utc.timestamp_opt(secs, 0)
                .single()
                .expect("valid timestamp"),
        )
    }
}

impl Clock for FixedClock {
    fn now(&self) -> DateTime<Utc> {
        self.fixed
    }
}

/// Stepped clock — caller advances time explicitly.
///
/// Used for deterministic replay where we drive the clock from the
/// timestamps recorded in the event log.
#[derive(Debug, Clone)]
pub struct SteppedClock {
    inner: Arc<Mutex<DateTime<Utc>>>,
}

impl SteppedClock {
    #[must_use]
    pub fn new(start: DateTime<Utc>) -> Self {
        Self {
            inner: Arc::new(Mutex::new(start)),
        }
    }

    /// Move the clock forward by `delta`.
    pub fn advance(&self, delta: Duration) {
        let mut g = self.inner.lock();
        *g += chrono::Duration::from_std(delta).expect("non-overflowing");
    }

    /// Set the clock to an absolute time. Must be monotonic — going
    /// backwards is a programmer bug and panics in debug builds.
    pub fn set(&self, t: DateTime<Utc>) {
        let mut g = self.inner.lock();
        debug_assert!(t >= *g, "stepped clock must not go backwards");
        *g = t;
    }
}

impl Clock for SteppedClock {
    fn now(&self) -> DateTime<Utc> {
        *self.inner.lock()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn fixed_clock_returns_constant() {
        let c = FixedClock::at_unix(1_700_000_000);
        let a = c.now();
        std::thread::sleep(Duration::from_millis(2));
        let b = c.now();
        assert_eq!(a, b);
    }

    #[test]
    fn stepped_clock_advances() {
        let start = Utc.timestamp_opt(1_700_000_000, 0).unwrap();
        let c = SteppedClock::new(start);
        assert_eq!(c.now(), start);
        c.advance(Duration::from_secs(60));
        assert_eq!(c.now() - start, chrono::Duration::seconds(60));
    }

    #[test]
    #[should_panic]
    fn stepped_clock_rejects_backwards() {
        let start = Utc.timestamp_opt(1_700_000_000, 0).unwrap();
        let c = SteppedClock::new(start);
        c.set(start - chrono::Duration::seconds(1));
    }

    #[test]
    fn system_clock_smoketest() {
        let c = SystemClock;
        let _ = c.now_nanos();
        // Just don't panic.
    }
}
