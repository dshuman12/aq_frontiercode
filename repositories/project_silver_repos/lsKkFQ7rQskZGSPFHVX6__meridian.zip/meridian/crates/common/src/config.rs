//! Tiny config helpers.
//!
//! We don't put a full settings loader here — `gateway-rest` and friends
//! pull in `config = "0.14"` directly. What lives here is the typed
//! glue that more than one crate would otherwise duplicate.

use std::env;
use std::str::FromStr;

use crate::error::{Error, Result};

/// Read an env var and parse it; return a typed error rather than a generic one.
pub fn parse_env<T>(key: &str) -> Result<T>
where
    T: FromStr,
    T::Err: std::fmt::Display,
{
    let raw = env::var(key).map_err(|_| Error::not_found(format!("env var '{key}' not set")))?;
    raw.parse::<T>()
        .map_err(|e| Error::invalid_argument(format!("env '{key}': {e}")))
}

/// Same as [`parse_env`] but returns a default when the var is unset.
/// Re-raises the parse error if the var was set but invalid.
pub fn parse_env_or<T>(key: &str, default: T) -> Result<T>
where
    T: FromStr,
    T::Err: std::fmt::Display,
{
    match env::var(key) {
        Ok(s) => s
            .parse::<T>()
            .map_err(|e| Error::invalid_argument(format!("env '{key}': {e}"))),
        Err(_) => Ok(default),
    }
}

/// Parse a comma-separated list, trimming whitespace.
pub fn parse_csv<T>(input: &str) -> Result<Vec<T>>
where
    T: FromStr,
    T::Err: std::fmt::Display,
{
    input
        .split(',')
        .map(str::trim)
        .filter(|s| !s.is_empty())
        .map(|s| {
            s.parse::<T>()
                .map_err(|e| Error::invalid_argument(format!("'{s}': {e}")))
        })
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parse_env_or_uses_default() {
        // Use a key vanishingly unlikely to exist in the test runner env.
        let v: u32 = parse_env_or("MERIDIAN_THIS_IS_NOT_SET_ABCXYZ", 42).unwrap();
        assert_eq!(v, 42);
    }

    #[test]
    fn parse_csv_strips_whitespace() {
        let v: Vec<u32> = parse_csv(" 1 ,2,3,  4 ").unwrap();
        assert_eq!(v, vec![1, 2, 3, 4]);
    }

    #[test]
    fn parse_csv_empty_skipped() {
        let v: Vec<u32> = parse_csv(",,1,,").unwrap();
        assert_eq!(v, vec![1]);
    }

    #[test]
    fn parse_csv_propagates_error() {
        let r: Result<Vec<u32>> = parse_csv("1,xx,2");
        assert!(r.is_err());
    }
}
