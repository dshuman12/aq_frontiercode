//! Symbol — the canonical identifier for a tradable instrument.
//!
//! Format: `BASE-QUOTE`, both ASCII alphanumeric, base ≥ 1 char, quote ≥ 3 chars.
//! Examples: `BTC-USD`, `ETH-USDT`, `SOL-USDC`.
//!
//! The wire format is exactly the canonical string. No spaces, no slashes.

use std::fmt;
use std::str::FromStr;

use serde::{Deserialize, Serialize};
use smallvec::SmallVec;

use crate::error::{Error, Result};

const MAX_BASE_LEN: usize = 16;
const MAX_QUOTE_LEN: usize = 16;

/// A `BASE-QUOTE` symbol, validated and stack-allocated.
///
/// Inline storage is `SmallVec<[u8; 24]>`, which fits all real symbols
/// without heap allocating.
#[derive(Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(try_from = "String", into = "String")]
pub struct Symbol {
    bytes: SmallVec<[u8; 24]>,
    sep: u8, // index of the '-' separator
}

impl Symbol {
    /// Parse and validate a symbol.
    pub fn new(input: &str) -> Result<Self> {
        if !input.is_ascii() {
            return Err(Error::invalid_argument("symbol must be ASCII"));
        }
        let Some(sep_pos) = input.find('-') else {
            return Err(Error::invalid_argument("symbol must contain '-' separator"));
        };
        let (base, quote) = (&input[..sep_pos], &input[sep_pos + 1..]);

        if base.is_empty() || base.len() > MAX_BASE_LEN {
            return Err(Error::invalid_argument(format!(
                "base length out of range: '{base}'"
            )));
        }
        if quote.len() < 3 || quote.len() > MAX_QUOTE_LEN {
            return Err(Error::invalid_argument(format!(
                "quote length out of range: '{quote}'"
            )));
        }
        if !base.bytes().all(|b| b.is_ascii_alphanumeric()) {
            return Err(Error::invalid_argument("base must be alphanumeric ASCII"));
        }
        if !quote.bytes().all(|b| b.is_ascii_alphanumeric()) {
            return Err(Error::invalid_argument("quote must be alphanumeric ASCII"));
        }

        // Canonicalise to upper-case.
        let mut bytes: SmallVec<[u8; 24]> = SmallVec::with_capacity(input.len());
        for b in input.bytes() {
            bytes.push(b.to_ascii_uppercase());
        }
        // sep_pos is small enough to fit in u8 because MAX_BASE_LEN <= 16.
        Ok(Self {
            bytes,
            #[allow(clippy::cast_possible_truncation)]
            sep: sep_pos as u8,
        })
    }

    /// Borrowed view of the canonical string form.
    #[must_use]
    pub fn as_str(&self) -> &str {
        // Safe: bytes are validated ASCII at construction time.
        std::str::from_utf8(&self.bytes).expect("symbol bytes are valid utf-8")
    }

    /// Borrowed base part (before `-`).
    #[must_use]
    pub fn base(&self) -> &str {
        &self.as_str()[..self.sep as usize]
    }

    /// Borrowed quote part (after `-`).
    #[must_use]
    pub fn quote(&self) -> &str {
        &self.as_str()[self.sep as usize + 1..]
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "Symbol({})", self.as_str())
    }
}

impl fmt::Display for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(self.as_str())
    }
}

impl FromStr for Symbol {
    type Err = Error;
    fn from_str(s: &str) -> Result<Self> {
        Self::new(s)
    }
}

impl TryFrom<String> for Symbol {
    type Error = Error;
    fn try_from(s: String) -> Result<Self> {
        Self::new(&s)
    }
}

impl From<Symbol> for String {
    fn from(s: Symbol) -> Self {
        s.as_str().to_owned()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_canonical_symbols() {
        let s = Symbol::new("btc-usd").unwrap();
        assert_eq!(s.as_str(), "BTC-USD");
        assert_eq!(s.base(), "BTC");
        assert_eq!(s.quote(), "USD");
    }

    #[test]
    fn rejects_missing_separator() {
        assert!(Symbol::new("BTCUSD").is_err());
    }

    #[test]
    fn rejects_short_quote() {
        assert!(Symbol::new("BTC-XX").is_err());
    }

    #[test]
    fn rejects_unicode() {
        assert!(Symbol::new("BTC-U₿D").is_err());
    }

    #[test]
    fn rejects_overlong_components() {
        let too_long = "ABCDEFGHIJKLMNOPQ".to_owned() + "-USD";
        assert!(Symbol::new(&too_long).is_err());
    }

    #[test]
    fn json_roundtrip() {
        let s = Symbol::new("ETH-USDC").unwrap();
        let json = serde_json::to_string(&s).unwrap();
        assert_eq!(json, "\"ETH-USDC\"");
        let back: Symbol = serde_json::from_str(&json).unwrap();
        assert_eq!(s, back);
    }
}
