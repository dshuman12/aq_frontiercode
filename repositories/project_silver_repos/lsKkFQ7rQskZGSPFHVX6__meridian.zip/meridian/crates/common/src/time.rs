//! Timestamp utilities — typed wrappers around `chrono::DateTime<Utc>`,
//! plus a few helpers for venue-local time conversions.
//!
//! We use `chrono` here because the rest of the codebase does. The
//! `time` crate is also pulled in for FIX timestamp parsing where its
//! formatter is faster.

use std::fmt;
use std::time::Duration as StdDuration;

use chrono::{DateTime, Datelike, Duration, NaiveDate, NaiveDateTime, NaiveTime, TimeZone, Utc};
use chrono_tz::Tz;
use serde::{Deserialize, Serialize};

/// Wall-clock instant, UTC, nanosecond precision.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Serialize, Deserialize)]
#[serde(transparent)]
pub struct Timestamp(pub DateTime<Utc>);

impl Timestamp {
    pub const EPOCH: Self = Self(DateTime::from_naive_utc_and_offset(
        NaiveDateTime::new(
            NaiveDate::from_ymd_opt(1970, 1, 1).expect("1970-01-01 exists"),
            NaiveTime::from_hms_opt(0, 0, 0).expect("00:00:00 exists"),
        ),
        Utc,
    ));

    #[must_use]
    pub const fn from_datetime(dt: DateTime<Utc>) -> Self {
        Self(dt)
    }

    #[must_use]
    pub const fn into_datetime(self) -> DateTime<Utc> {
        self.0
    }

    #[must_use]
    pub fn from_unix_nanos(nanos: i64) -> Self {
        let secs = nanos.div_euclid(1_000_000_000);
        let rem = nanos.rem_euclid(1_000_000_000);
        #[allow(clippy::cast_sign_loss, clippy::cast_possible_truncation)]
        let nano_part = rem as u32;
        Self(
            Utc.timestamp_opt(secs, nano_part)
                .single()
                .unwrap_or(Self::EPOCH.0),
        )
    }

    #[must_use]
    pub fn unix_nanos(self) -> i64 {
        self.0.timestamp_nanos_opt().unwrap_or(0)
    }

    #[must_use]
    pub fn unix_millis(self) -> i64 {
        self.0.timestamp_millis()
    }

    /// Truncate to the given duration boundary (e.g. nearest second below).
    #[must_use]
    pub fn floor_to(self, period: StdDuration) -> Self {
        let nanos = self.unix_nanos();
        let p_nanos = i64::try_from(period.as_nanos()).unwrap_or(i64::MAX);
        if p_nanos <= 0 {
            return self;
        }
        let floored = nanos - nanos.rem_euclid(p_nanos);
        Self::from_unix_nanos(floored)
    }
}

impl fmt::Display for Timestamp {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // RFC 3339 / ISO-8601 with nanosecond fraction.
        write!(
            f,
            "{}",
            self.0.to_rfc3339_opts(chrono::SecondsFormat::Nanos, true)
        )
    }
}

impl From<DateTime<Utc>> for Timestamp {
    fn from(dt: DateTime<Utc>) -> Self {
        Self(dt)
    }
}

impl From<Timestamp> for DateTime<Utc> {
    fn from(t: Timestamp) -> Self {
        t.0
    }
}

/// Convert a UTC timestamp to a venue-local naive date.
#[must_use]
pub fn local_date(at: Timestamp, tz: Tz) -> NaiveDate {
    at.0.with_timezone(&tz).date_naive()
}

/// Days from the most recent prior business day for a (Mon-Fri) calendar.
///
/// `holidays_local` are dates in `tz` that should be skipped.
#[must_use]
pub fn business_days_back(from: NaiveDate, n: u32, holidays_local: &[NaiveDate]) -> NaiveDate {
    let mut cur = from;
    let mut remaining = n;
    while remaining > 0 {
        cur = cur.pred_opt().unwrap_or(cur);
        let weekend = matches!(cur.weekday(), chrono::Weekday::Sat | chrono::Weekday::Sun);
        let holiday = holidays_local.contains(&cur);
        if !weekend && !holiday {
            remaining -= 1;
        }
    }
    cur
}

/// Inclusive day-window helper used by reporting and the auctions module.
#[must_use]
pub fn within_window(now: Timestamp, start: Timestamp, end: Timestamp) -> bool {
    now >= start && now <= end
}

/// Convert a `chrono::Duration` to a positive `std::time::Duration`,
/// saturating when negative.
#[must_use]
pub fn to_std_duration(d: Duration) -> StdDuration {
    d.to_std().unwrap_or(StdDuration::ZERO)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn rfc3339_display_nanos() {
        let t = Timestamp::from_unix_nanos(1_700_000_000_123_456_789);
        let s = format!("{}", t);
        assert!(s.starts_with("2023-"));
        assert!(s.ends_with("Z"));
    }

    #[test]
    fn floor_to_second() {
        let t = Timestamp::from_unix_nanos(1_700_000_000_500_000_000);
        let floored = t.floor_to(StdDuration::from_secs(1));
        assert_eq!(floored.unix_nanos(), 1_700_000_000_000_000_000);
    }

    #[test]
    fn business_day_skips_weekend() {
        let fri = NaiveDate::from_ymd_opt(2025, 6, 13).unwrap(); // Friday
        let result = business_days_back(fri, 1, &[]);
        // one biz day back is Thursday
        assert_eq!(result, NaiveDate::from_ymd_opt(2025, 6, 12).unwrap());
    }

    #[test]
    fn business_day_skips_holiday() {
        let mon = NaiveDate::from_ymd_opt(2025, 6, 16).unwrap();
        let holidays = [NaiveDate::from_ymd_opt(2025, 6, 13).unwrap()];
        let result = business_days_back(mon, 1, &holidays);
        // Mon back skipping a Fri holiday lands on Thursday
        assert_eq!(result, NaiveDate::from_ymd_opt(2025, 6, 12).unwrap());
    }
}
