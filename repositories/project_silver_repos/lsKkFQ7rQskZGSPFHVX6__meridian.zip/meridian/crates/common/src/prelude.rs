//! `use meridian_common::prelude::*` — the everyday import set.
//!
//! Anything that 80% of files in the workspace want to use without
//! ceremony goes here. Keep the surface tight.

pub use crate::clock::{Clock, ClockRef, FixedClock, SteppedClock, SystemClock};
pub use crate::error::{Error, ErrorKind, Result};
pub use crate::ids::{
    AccountId, AuctionId, ClientOrderId, EventId, ExecId, IdGenerator, OrderId, RoutingPrefix,
    SessionId, SnapshotId, TradeId,
};
pub use crate::money::{Bps, Fee, LotSize, Notional, Price, Quantity, TickSize};
pub use crate::seq::{FixSeqNum, MdSeqNo, SeqAllocator, SeqNo};
pub use crate::symbol::Symbol;
pub use crate::time::{business_days_back, local_date, Timestamp};
