//! Sequence-number primitives.
//!
//! The platform uses three flavours of sequence number:
//!
//! - [`SeqNo`] — monotonic, assigned by the sequencer to every command
//!   before it reaches the matching engine.
//! - [`MdSeqNo`] — market-data sequence, assigned after the engine
//!   produces a fill / book-update event.
//! - [`FixSeqNum`] — per FIX session counter, two of them
//!   (incoming/outgoing) per session.
//!
//! All three are u64 newtypes; they don't share an arithmetic with each
//! other on purpose.

use std::fmt;
use std::sync::atomic::{AtomicU64, Ordering};

use serde::{Deserialize, Serialize};

macro_rules! seq_newtype {
    ($name:ident, $doc:literal) => {
        #[doc = $doc]
        #[derive(
            Debug,
            Clone,
            Copy,
            PartialEq,
            Eq,
            PartialOrd,
            Ord,
            Hash,
            Serialize,
            Deserialize,
            Default,
        )]
        #[serde(transparent)]
        #[repr(transparent)]
        pub struct $name(pub u64);

        impl $name {
            pub const ZERO: Self = Self(0);

            #[must_use]
            pub const fn new(n: u64) -> Self {
                Self(n)
            }

            /// Get the inner u64.
            #[must_use]
            pub const fn raw(self) -> u64 {
                self.0
            }

            /// Increment, returning the new value. Saturates at `u64::MAX`
            /// (which would mean we ran for thousands of years at billions/sec).
            #[must_use]
            pub const fn next(self) -> Self {
                Self(self.0.saturating_add(1))
            }
        }

        impl fmt::Display for $name {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                write!(f, "{}", self.0)
            }
        }

        impl From<u64> for $name {
            fn from(n: u64) -> Self {
                Self(n)
            }
        }
    };
}

seq_newtype!(
    SeqNo,
    "Command-stream sequence number, assigned by the sequencer."
);
seq_newtype!(
    MdSeqNo,
    "Market-data sequence number, assigned downstream of the engine."
);
seq_newtype!(FixSeqNum, "Per-session FIX sequence number.");

/// Atomic counter wrapper for issuing fresh `SeqNo`s.
#[derive(Debug)]
pub struct SeqAllocator(AtomicU64);

impl SeqAllocator {
    #[must_use]
    pub const fn new(start: u64) -> Self {
        Self(AtomicU64::new(start))
    }

    /// Return the next sequence and advance.
    pub fn next(&self) -> SeqNo {
        SeqNo::new(self.0.fetch_add(1, Ordering::SeqCst))
    }

    /// Read the current value without advancing.
    pub fn peek(&self) -> SeqNo {
        SeqNo::new(self.0.load(Ordering::SeqCst))
    }

    /// Reset to a specific value. Used for snapshot recovery only.
    pub fn reset_to(&self, value: SeqNo) {
        self.0.store(value.raw(), Ordering::SeqCst);
    }
}

impl Default for SeqAllocator {
    fn default() -> Self {
        Self::new(1)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn allocator_is_monotonic() {
        let a = SeqAllocator::new(10);
        assert_eq!(a.next(), SeqNo::new(10));
        assert_eq!(a.next(), SeqNo::new(11));
        assert_eq!(a.peek(), SeqNo::new(12));
    }

    #[test]
    fn next_saturates_at_max() {
        let s = SeqNo::new(u64::MAX);
        assert_eq!(s.next(), SeqNo::new(u64::MAX));
    }

    #[test]
    fn distinct_seq_types_dont_mix() {
        // This is a compile-time guarantee, but we exercise it:
        let a = SeqNo::new(1);
        let b = MdSeqNo::new(1);
        // a == b is a type error; this is only a runtime check that the
        // explicit conversion path works.
        assert_eq!(a.raw(), b.raw());
    }
}
