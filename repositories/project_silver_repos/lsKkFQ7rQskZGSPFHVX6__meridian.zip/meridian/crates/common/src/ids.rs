//! Strongly-typed identifiers.
//!
//! We use newtype IDs everywhere to prevent the easy class of bug where
//! "an account ID and a trade ID happen to both be u64". Each type below
//! is `#[repr(transparent)]` over its primitive so it costs nothing
//! at runtime.
//!
//! ## Format
//!
//! Most IDs are u128 so we can pack a venue / shard prefix into the high
//! bits without burning bandwidth. The packing convention is:
//!
//! ```text
//!  127 ...  96 | 95 ............. 0
//!    routing  |   monotonic value
//! ```
//!
//! The routing prefix is set by the gateway or the issuing service; the
//! monotonic part is the low-128 of a v7 UUID for IDs that need to sort
//! by time, and a counter for everything else.

use std::fmt;
use std::str::FromStr;

use serde::{Deserialize, Serialize};
use uuid::Uuid;

use crate::error::Error;

/// 32-bit routing prefix that's packed into the high bits of every ID.
///
/// We don't intend to ever run more than 2^32 venues; this is mostly for
/// future shard isolation.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(transparent)]
#[repr(transparent)]
pub struct RoutingPrefix(pub u32);

impl RoutingPrefix {
    pub const PRIMARY: Self = Self(0x0000_0001);
    pub const TEST: Self = Self(0xFFFF_FFFF);

    #[must_use]
    pub const fn new(value: u32) -> Self {
        Self(value)
    }
}

impl fmt::Display for RoutingPrefix {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{:08x}", self.0)
    }
}

macro_rules! u128_id {
    ($name:ident, $kind_str:literal $(,)?) => {
        #[doc = concat!("`", $kind_str, "` identifier — see module docs.")]
        #[derive(
            Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Serialize, Deserialize,
        )]
        #[serde(transparent)]
        #[repr(transparent)]
        pub struct $name(pub u128);

        impl $name {
            pub const ZERO: Self = Self(0);

            #[must_use]
            pub const fn new(value: u128) -> Self {
                Self(value)
            }

            #[must_use]
            pub fn from_uuid_v7(uuid: Uuid, prefix: RoutingPrefix) -> Self {
                let lo = uuid.as_u128() & ((1u128 << 96) - 1);
                let hi = u128::from(prefix.0) << 96;
                Self(hi | lo)
            }

            #[must_use]
            pub fn raw(self) -> u128 {
                self.0
            }

            #[must_use]
            pub fn routing_prefix(self) -> RoutingPrefix {
                #[allow(clippy::cast_possible_truncation)]
                RoutingPrefix((self.0 >> 96) as u32)
            }

            #[must_use]
            pub fn monotonic(self) -> u128 {
                self.0 & ((1u128 << 96) - 1)
            }

            #[must_use]
            pub fn kind() -> &'static str {
                $kind_str
            }
        }

        impl fmt::Display for $name {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                write!(f, "{}-{:032x}", $kind_str, self.0)
            }
        }

        impl FromStr for $name {
            type Err = Error;

            fn from_str(s: &str) -> Result<Self, Self::Err> {
                let prefix = concat!($kind_str, "-");
                let rest = s.strip_prefix(prefix).ok_or_else(|| {
                    Error::invalid_argument(format!("expected id prefix '{}', got '{}'", prefix, s))
                })?;
                let raw = u128::from_str_radix(rest, 16).map_err(|_| {
                    Error::invalid_argument("id body must be 32 lowercase hex chars")
                })?;
                Ok(Self(raw))
            }
        }
    };
}

u128_id!(OrderId, "ord");
u128_id!(TradeId, "trd");
u128_id!(ClientOrderId, "cli");
u128_id!(ExecId, "exe");
u128_id!(SessionId, "ses");
u128_id!(AccountId, "acc");
u128_id!(EventId, "evt");
u128_id!(SnapshotId, "snp");
u128_id!(AuctionId, "auc");

/// An ID generator for IDs that need sortability.
#[derive(Debug, Clone)]
pub struct IdGenerator {
    routing: RoutingPrefix,
}

impl IdGenerator {
    #[must_use]
    pub const fn new(routing: RoutingPrefix) -> Self {
        Self { routing }
    }

    pub fn order_id(&self) -> OrderId {
        OrderId::from_uuid_v7(Uuid::now_v7(), self.routing)
    }

    pub fn trade_id(&self) -> TradeId {
        TradeId::from_uuid_v7(Uuid::now_v7(), self.routing)
    }

    pub fn exec_id(&self) -> ExecId {
        ExecId::from_uuid_v7(Uuid::now_v7(), self.routing)
    }

    pub fn event_id(&self) -> EventId {
        EventId::from_uuid_v7(Uuid::now_v7(), self.routing)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn display_and_parse_roundtrip() {
        let id = OrderId(0x1234_5678_9abc_def0_1122_3344_5566_7788);
        let s = id.to_string();
        assert!(s.starts_with("ord-"));
        let parsed: OrderId = s.parse().unwrap();
        assert_eq!(id, parsed);
    }

    #[test]
    fn rejects_wrong_prefix() {
        let id = OrderId(1).to_string();
        let bad = id.replace("ord-", "trd-");
        assert!(bad.parse::<OrderId>().is_err());
    }

    #[test]
    fn routing_prefix_extracted() {
        let pfx = RoutingPrefix(0xC0FE_BEEF);
        let id = OrderId::from_uuid_v7(Uuid::now_v7(), pfx);
        assert_eq!(id.routing_prefix(), pfx);
    }
}
