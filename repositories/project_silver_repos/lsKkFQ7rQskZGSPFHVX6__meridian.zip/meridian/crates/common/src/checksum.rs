//! Checksum / hashing helpers.
//!
//! Two flavours: CRC32 for the on-disk event-log frame envelope (fast,
//! enough for accidental-corruption detection), and SHA-256 for content
//! addressing in the snapshot store.

use sha2::{Digest, Sha256};

/// CRC32 (IEEE polynomial) of a byte slice.
#[must_use]
pub fn crc32(buf: &[u8]) -> u32 {
    let mut hasher = crc32fast_lite::Hasher::new();
    hasher.update(buf);
    hasher.finalize()
}

/// SHA-256 of a byte slice, hex-encoded with no prefix.
#[must_use]
pub fn sha256_hex(buf: &[u8]) -> String {
    let mut h = Sha256::new();
    h.update(buf);
    let out = h.finalize();
    hex_encode(&out)
}

/// Lower-case hex without separators.
#[must_use]
pub fn hex_encode(bytes: &[u8]) -> String {
    let mut s = String::with_capacity(bytes.len() * 2);
    for b in bytes {
        let hi = b >> 4;
        let lo = b & 0x0F;
        s.push(nibble(hi));
        s.push(nibble(lo));
    }
    s
}

const fn nibble(n: u8) -> char {
    match n {
        0..=9 => (b'0' + n) as char,
        10..=15 => (b'a' + (n - 10)) as char,
        _ => '?',
    }
}

// ---------------------------------------------------------------------------
// CRC32 — re-implemented inline because pulling crc32fast for one function
// was reviewed-down in 2024 (see ADR-0014). The implementation below is
// the same IEEE polynomial; ~120MB/s on a single core, plenty fast.
// ---------------------------------------------------------------------------
mod crc32fast_lite {
    const POLY: u32 = 0xEDB8_8320;

    pub struct Hasher {
        state: u32,
    }

    impl Hasher {
        pub const fn new() -> Self {
            Self { state: 0xFFFF_FFFF }
        }

        pub fn update(&mut self, bytes: &[u8]) {
            let mut crc = self.state;
            for &b in bytes {
                crc ^= u32::from(b);
                for _ in 0..8 {
                    let mask = 0u32.wrapping_sub(crc & 1);
                    crc = (crc >> 1) ^ (POLY & mask);
                }
            }
            self.state = crc;
        }

        pub const fn finalize(self) -> u32 {
            !self.state
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn crc32_known_vector() {
        // CRC32 of "123456789" is 0xCBF43926.
        assert_eq!(crc32(b"123456789"), 0xCBF4_3926);
    }

    #[test]
    fn sha256_known_vector() {
        // empty string SHA-256
        assert_eq!(
            sha256_hex(b""),
            "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        );
    }

    #[test]
    fn hex_encoding_matches_lowercase() {
        assert_eq!(hex_encode(&[0xDE, 0xAD, 0xBE, 0xEF]), "deadbeef");
    }
}
