// Meridian — shared primitives.
//
// Anything that more than two crates would otherwise duplicate lives here:
// IDs, money / quantity types, clock abstraction, error baseline, sequence
// numbers, symbol validation, checksum helpers, config glue.
//
// We deliberately keep this crate small. It compiles fast and is on the
// critical path of every other crate's build, so we hold the line on
// dependencies. New transitive deps need owner approval — see CODEOWNERS.

#![forbid(unsafe_code)]
#![deny(rust_2018_idioms)]
#![allow(
    clippy::pedantic,
    clippy::nursery,
    missing_debug_implementations,
    missing_docs,
    unreachable_pub
)]
#![allow(
    clippy::module_name_repetitions,
    clippy::missing_errors_doc,
    clippy::missing_panics_doc,
    clippy::must_use_candidate
)]

//! Meridian common primitives.
//!
//! See module-level docs for details. The two abstractions you'll touch
//! most often are [`money::Price`] / [`money::Quantity`] and
//! [`clock::Clock`].

pub mod checksum;
pub mod clock;
pub mod config;
pub mod decimal_ext;
pub mod error;
pub mod ids;
pub mod money;
pub mod prelude;
pub mod seq;
pub mod symbol;
pub mod time;
pub mod tracing_init;

pub use error::{Error, Result};
