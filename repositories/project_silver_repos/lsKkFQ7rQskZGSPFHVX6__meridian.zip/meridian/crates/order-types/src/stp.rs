//! Self-Trade Prevention modes.
//!
//! These tell the engine what to do when an incoming order would match
//! against another order from the same account. The mode is set per
//! order; if not specified, the engine falls back to the account-level
//! default in `ref-data`.

use serde::{Deserialize, Serialize};

#[derive(Debug, Default, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum SelfTradePrevention {
    /// Do nothing — let the cross happen and book a self-trade. Off by
    /// default; some HFT use cases use it deliberately.
    None,

    /// Cancel Newest — the incoming aggressor is cancelled (or the
    /// portion that would self-trade is cancelled if some prefix is
    /// matchable against external resting orders).
    CancelNewest,

    /// Cancel Oldest — the resting order is cancelled, the aggressor
    /// continues matching against the next price level / next resting
    /// order.
    CancelOldest,

    /// Decrement and Cancel — whichever has the smaller remaining qty
    /// is cancelled completely; the other is decremented by the
    /// smaller's qty. Symmetric.
    #[default]
    DecrementCancel,

    /// Cancel Both — both orders are cancelled in their entirety.
    CancelBoth,
}

impl SelfTradePrevention {
    /// FIX tag 7928 (SelfMatchPreventionInstruction) — exchange-specific
    /// extensions; we picked sensible numbers.
    #[must_use]
    pub const fn fix_code(self) -> u8 {
        match self {
            Self::None => b'0',
            Self::CancelNewest => b'N',
            Self::CancelOldest => b'O',
            Self::DecrementCancel => b'D',
            Self::CancelBoth => b'B',
        }
    }

    /// True when this mode never produces a fill against same-account.
    #[must_use]
    pub const fn prevents_match(self) -> bool {
        !matches!(self, Self::None)
    }
}
