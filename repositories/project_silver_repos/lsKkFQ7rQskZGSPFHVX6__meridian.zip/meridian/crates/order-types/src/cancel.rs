//! Cancel — request to remove an order from the book.

use meridian_common::prelude::*;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct CancelRequest {
    pub account_id: AccountId,
    pub symbol: Symbol,

    /// One of these two must be set; if both, `order_id` wins. The
    /// gateway resolves `client_order_id` to `order_id` before reaching
    /// the engine, so by the time it gets to the matcher only `order_id`
    /// is consulted.
    pub order_id: Option<OrderId>,
    pub client_order_id: Option<ClientOrderId>,

    /// Optional reason for telemetry.
    pub reason: Option<String>,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn json_roundtrip() {
        let r = CancelRequest {
            account_id: AccountId::new(1),
            symbol: Symbol::new("BTC-USD").unwrap(),
            order_id: Some(OrderId::new(42)),
            client_order_id: None,
            reason: Some("user".into()),
        };
        let s = serde_json::to_string(&r).unwrap();
        let back: CancelRequest = serde_json::from_str(&s).unwrap();
        assert_eq!(r, back);
    }
}
