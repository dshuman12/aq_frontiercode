//! Fill — the result of a matched order.
//!
//! One match between two orders produces *two* fills (one for each
//! side). The engine emits both, the trade record links them via
//! `trade_id`. Fees are computed at fill time.

use meridian_common::prelude::*;
use serde::{Deserialize, Serialize};

use crate::side::Side;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum LiquidityRole {
    Maker,
    Taker,
}

impl LiquidityRole {
    /// FIX tag 851 (LastLiquidityInd) value.
    #[must_use]
    pub const fn fix_code(self) -> u8 {
        match self {
            Self::Maker => b'1',
            Self::Taker => b'2',
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum FillKind {
    /// Continuous trading match.
    Trade,
    /// Filled in an opening / closing / volatility auction.
    AuctionCross,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Fill {
    pub trade_id: TradeId,
    pub exec_id: ExecId,
    pub symbol: Symbol,
    pub kind: FillKind,
    pub price: Price,
    pub quantity: Quantity,
    pub maker_order_id: OrderId,
    pub taker_order_id: OrderId,
    pub maker_account: AccountId,
    pub taker_account: AccountId,
    pub maker_side: Side,
    pub maker_fee: Fee,
    pub taker_fee: Fee,
    pub at: Timestamp,
    pub seq_no: MdSeqNo,
}

impl Fill {
    #[must_use]
    pub fn notional(&self) -> Notional {
        self.price * self.quantity
    }

    /// Side of `account` from this fill's perspective. Returns `None`
    /// if the account is neither maker nor taker (e.g. a third-party
    /// view of the trade).
    #[must_use]
    pub fn side_for(&self, account: AccountId) -> Option<Side> {
        if account == self.maker_account {
            Some(self.maker_side)
        } else if account == self.taker_account {
            Some(self.maker_side.opposite())
        } else {
            None
        }
    }

    /// Opposite of [`side_for`] — gives the role.
    #[must_use]
    pub fn role_for(&self, account: AccountId) -> Option<LiquidityRole> {
        if account == self.maker_account {
            Some(LiquidityRole::Maker)
        } else if account == self.taker_account {
            Some(LiquidityRole::Taker)
        } else {
            None
        }
    }
}
