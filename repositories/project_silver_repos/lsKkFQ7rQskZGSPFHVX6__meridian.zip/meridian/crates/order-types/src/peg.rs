//! Pegged-order reference points.
//!
//! Three references match what most US/EU venues offer:
//!
//! - `Mid` — midpoint of the BBO. If the book is one-sided we don't peg
//!   and the order rests at the offset relative to the available side.
//! - `Primary` — the same-side touch (top of the book on our side).
//! - `Market` — the opposite-side touch (top of the other side, i.e.
//!   we peg to the price we would pay to cross).

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum PegReference {
    Mid,
    Primary,
    Market,
}

impl PegReference {
    /// FIX tag 1094 (PegPriceType) numeric code.
    #[must_use]
    pub const fn fix_code(self) -> u8 {
        match self {
            // 1 = Last (we don't support); we collapse Mid → 4 (mid),
            // Primary → 5, Market → 7.
            Self::Mid => b'4',
            Self::Primary => b'5',
            Self::Market => b'7',
        }
    }
}
