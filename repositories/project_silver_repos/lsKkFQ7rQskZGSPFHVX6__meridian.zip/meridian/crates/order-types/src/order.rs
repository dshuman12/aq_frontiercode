//! Order — the core order record.
//!
//! Two flavours:
//!
//! - [`NewOrder`] — what comes off the wire. Most fields are required;
//!   IDs are optional (the gateway/engine fills them in).
//! - [`Order`] — what the engine works with. Fully populated and frozen.

use chrono::{DateTime, Utc};
use meridian_common::prelude::*;
use serde::{Deserialize, Serialize};

use crate::peg::PegReference;
use crate::side::Side;
use crate::state::OrderStatus;
use crate::stp::SelfTradePrevention;
use crate::tif::TimeInForce;
use crate::types::OrderType;

/// Wire-format order for inbound order entry.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct NewOrder {
    pub account_id: AccountId,
    pub client_order_id: ClientOrderId,
    pub symbol: Symbol,
    pub side: Side,
    pub order_type: OrderType,
    pub time_in_force: TimeInForce,
    pub quantity: Quantity,

    /// Required for `Limit`, `StopLimit`, and `Iceberg`.
    pub limit_price: Option<Price>,

    /// Required for `Stop`, `StopLimit`.
    pub trigger_price: Option<Price>,

    /// Required for `Iceberg`. Must be > 0 and ≤ `quantity`.
    pub display_qty: Option<Quantity>,

    /// Optional. If unset, account-default is used.
    pub stp: Option<SelfTradePrevention>,

    /// Reject if the order would otherwise immediately cross the book.
    /// Maps to FIX ExecInst='6'.
    pub post_only: bool,

    /// Reject if the order would not reduce position. (Derivatives only;
    /// ignored on spot.)
    pub reduce_only: bool,

    /// Optional client metadata, opaque to the engine. Capped at 64 bytes.
    pub user_tag: Option<String>,
}

/// Engine-side order — fully populated, immutable except for fill /
/// cancel updates.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Order {
    pub id: OrderId,
    pub account_id: AccountId,
    pub client_order_id: ClientOrderId,
    pub symbol: Symbol,
    pub side: Side,
    pub order_type: OrderType,
    pub time_in_force: TimeInForce,
    pub status: OrderStatus,
    pub stp: SelfTradePrevention,

    pub original_qty: Quantity,
    pub filled_qty: Quantity,
    pub leaves_qty: Quantity,
    pub avg_fill_price: Price,
    pub cumulative_notional: Notional,

    pub limit_price: Option<Price>,
    pub trigger_price: Option<Price>,
    pub display_qty: Option<Quantity>,

    pub post_only: bool,
    pub reduce_only: bool,
    pub user_tag: Option<String>,

    pub received_at: Timestamp,
    pub last_event_at: Timestamp,

    /// Sequencer-assigned monotonic seqno of the original `NewOrder`
    /// command. Used for FIFO time priority — *not* `received_at`,
    /// because two orders accepted in the same nanosecond would tie.
    pub priority_seq: SeqNo,
}

impl NewOrder {
    /// Build a market buy with sensible defaults.
    #[must_use]
    pub fn market_buy(
        account_id: AccountId,
        client_order_id: ClientOrderId,
        symbol: Symbol,
        quantity: Quantity,
    ) -> Self {
        Self {
            account_id,
            client_order_id,
            symbol,
            side: Side::Buy,
            order_type: OrderType::Market,
            time_in_force: TimeInForce::Ioc,
            quantity,
            limit_price: None,
            trigger_price: None,
            display_qty: None,
            stp: None,
            post_only: false,
            reduce_only: false,
            user_tag: None,
        }
    }

    /// Build a GTC limit. Useful for tests and SDK shortcuts.
    #[must_use]
    pub fn limit(
        account_id: AccountId,
        client_order_id: ClientOrderId,
        symbol: Symbol,
        side: Side,
        price: Price,
        quantity: Quantity,
    ) -> Self {
        Self {
            account_id,
            client_order_id,
            symbol,
            side,
            order_type: OrderType::Limit,
            time_in_force: TimeInForce::Gtc,
            quantity,
            limit_price: Some(price),
            trigger_price: None,
            display_qty: None,
            stp: None,
            post_only: false,
            reduce_only: false,
            user_tag: None,
        }
    }

    /// Builder helper.
    #[must_use]
    pub fn with_post_only(mut self) -> Self {
        self.post_only = true;
        self
    }

    /// Builder helper.
    #[must_use]
    pub fn with_tif(mut self, tif: TimeInForce) -> Self {
        self.time_in_force = tif;
        self
    }

    /// Builder helper.
    #[must_use]
    pub fn with_iceberg(mut self, display: Quantity) -> Self {
        self.order_type = OrderType::Iceberg;
        self.display_qty = Some(display);
        self
    }

    /// Builder helper.
    #[must_use]
    pub fn with_stp(mut self, mode: SelfTradePrevention) -> Self {
        self.stp = Some(mode);
        self
    }

    /// Builder helper.
    #[must_use]
    pub fn with_peg(mut self, reference: PegReference, offset_ticks: i32) -> Self {
        self.order_type = OrderType::Peg {
            reference,
            offset_ticks,
        };
        self
    }
}

impl Order {
    /// Bare-minimum constructor — the engine produces these from
    /// `NewOrder` after validation and risk approval.
    #[must_use]
    pub fn from_new(
        new: &NewOrder,
        id: OrderId,
        priority_seq: SeqNo,
        received_at: Timestamp,
        default_stp: SelfTradePrevention,
    ) -> Self {
        Self {
            id,
            account_id: new.account_id,
            client_order_id: new.client_order_id,
            symbol: new.symbol.clone(),
            side: new.side,
            order_type: new.order_type,
            time_in_force: new.time_in_force,
            status: OrderStatus::New,
            stp: new.stp.unwrap_or(default_stp),
            original_qty: new.quantity,
            filled_qty: Quantity::ZERO,
            leaves_qty: new.quantity,
            avg_fill_price: Price::ZERO,
            cumulative_notional: Notional::ZERO,
            limit_price: new.limit_price,
            trigger_price: new.trigger_price,
            display_qty: new.display_qty,
            post_only: new.post_only,
            reduce_only: new.reduce_only,
            user_tag: new.user_tag.clone(),
            received_at,
            last_event_at: received_at,
            priority_seq,
        }
    }

    /// Apply a fill — internal book-keeping shared by the matcher and
    /// the auction code.
    pub fn apply_fill(&mut self, qty: Quantity, price: Price, at: Timestamp) {
        debug_assert!(qty > Quantity::ZERO);
        debug_assert!(qty <= self.leaves_qty);

        let prior_fill = self.filled_qty;
        self.filled_qty += qty;
        self.leaves_qty -= qty;
        self.cumulative_notional += price * qty;

        if !self.filled_qty.is_zero() {
            self.avg_fill_price = self.cumulative_notional / self.filled_qty;
        }

        self.last_event_at = at;
        self.status = if self.leaves_qty.is_zero() {
            OrderStatus::Filled
        } else {
            OrderStatus::PartiallyFilled
        };
        let _ = prior_fill; // silence unused when debug_assert is off
    }

    /// Mark the order as cancelled. No-op if already terminal.
    pub fn cancel(&mut self, at: Timestamp) {
        if self.status.is_terminal() {
            return;
        }
        self.status = OrderStatus::Cancelled;
        self.last_event_at = at;
        self.leaves_qty = Quantity::ZERO;
    }

    /// True if this order's GTD has elapsed by `now`.
    #[must_use]
    pub fn is_expired_at(&self, now: DateTime<Utc>) -> bool {
        match self.time_in_force {
            TimeInForce::Gtd { expires_at } => now >= expires_at,
            _ => false,
        }
    }
}
