// Order, Side, TimeInForce, OrderType, STP, Fill, validation.
//
// This crate is *only* the value types the engine consumes; no logic
// that depends on a book lives here. Keep it that way — the matching
// engine, gateways, and FIX parser all depend on this crate, and a
// dependency cycle through the engine would be a nightmare.

#![forbid(unsafe_code)]
#![deny(rust_2018_idioms)]
#![allow(
    clippy::pedantic,
    clippy::nursery,
    missing_debug_implementations,
    missing_docs
)]
#![allow(
    clippy::module_name_repetitions,
    clippy::missing_errors_doc,
    clippy::missing_panics_doc,
    clippy::must_use_candidate
)]

//! Order primitives shared by every layer that touches an order.

pub mod amend;
pub mod cancel;
pub mod error;
pub mod fill;
pub mod order;
pub mod peg;
pub mod side;
pub mod state;
pub mod stp;
pub mod tif;
pub mod types;
pub mod validate;

pub use amend::AmendRequest;
pub use cancel::CancelRequest;
pub use error::{OrderError, OrderResult};
pub use fill::{Fill, FillKind, LiquidityRole};
pub use order::{NewOrder, Order};
pub use peg::PegReference;
pub use side::Side;
pub use state::OrderStatus;
pub use stp::SelfTradePrevention;
pub use tif::TimeInForce;
pub use types::OrderType;
