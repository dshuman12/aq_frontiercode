//! Order types.

use serde::{Deserialize, Serialize};

use crate::peg::PegReference;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum OrderType {
    /// Market order — match aggressively against the book at any price.
    Market,
    /// Limit order — match against prices at or better than `limit_price`.
    Limit,
    /// Stop order — becomes a market order once `trigger_price` trades.
    Stop,
    /// Stop-limit — becomes a limit at `limit_price` once triggered.
    StopLimit,
    /// Iceberg — `display_qty` is visible at any time, the rest is hidden.
    Iceberg,
    /// Pegged — limit price is dynamically tied to a reference (mid, primary, market).
    /// Offset is signed; positive nudges away from the touch.
    Peg {
        reference: PegReference,
        offset_ticks: i32,
    },
}

impl OrderType {
    /// Whether the type is matched in continuous trading. Auction-only
    /// types still go through the engine but match in the cross.
    #[must_use]
    pub const fn matches_in_continuous(self) -> bool {
        // All current types do.
        true
    }

    /// FIX tag 40 numeric code.
    #[must_use]
    pub const fn fix_code(self) -> u8 {
        match self {
            Self::Market => b'1',
            Self::Limit => b'2',
            Self::Stop => b'3',
            Self::StopLimit => b'4',
            // Iceberg / Peg are FIX 'P' / 'P' too, but FIX has separate
            // ExecInst flags for them. We map to limit (2) and rely on
            // ExecInst to differentiate. See gateway-fix.
            Self::Iceberg => b'2',
            Self::Peg { .. } => b'P',
        }
    }

    #[must_use]
    pub const fn requires_limit_price(self) -> bool {
        matches!(self, Self::Limit | Self::StopLimit | Self::Iceberg)
    }

    #[must_use]
    pub const fn requires_trigger_price(self) -> bool {
        matches!(self, Self::Stop | Self::StopLimit)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn type_predicates() {
        assert!(OrderType::Limit.requires_limit_price());
        assert!(!OrderType::Market.requires_limit_price());
        assert!(OrderType::StopLimit.requires_trigger_price());
    }
}
