//! Time-in-force.
//!
//! Supported values:
//!
//! - `Gtc` — Good-Till-Cancel (default).
//! - `Ioc` — Immediate-or-Cancel; whatever doesn't fill at insert time
//!   is cancelled, no resting allowed.
//! - `Fok` — Fill-or-Kill; either the entire qty fills immediately or
//!   the order is rejected with no fills.
//! - `Day` — cancelled at session close in the listing tz.
//! - `Gtd { expires_at }` — Good-Till-Date; cancelled when the engine's
//!   wall clock crosses the expiry. UTC.
//! - `Atc` — At-The-Close; only matched in the closing auction.
//! - `Ato` — At-The-Open; only matched in the opening auction.

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

#[derive(Debug, Default, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum TimeInForce {
    #[default]
    Gtc,
    Ioc,
    Fok,
    Day,
    Gtd {
        expires_at: DateTime<Utc>,
    },
    Atc,
    Ato,
}

impl TimeInForce {
    /// FIX tag 59 numeric code.
    #[must_use]
    pub const fn fix_code(self) -> u8 {
        match self {
            Self::Day => b'0',
            Self::Gtc => b'1',
            // OPG (At The Opening) is FIX '2'.
            Self::Ato => b'2',
            Self::Ioc => b'3',
            Self::Fok => b'4',
            // GTX is FIX '5' but we don't support it; map to GTC.
            Self::Gtd { .. } => b'6',
            Self::Atc => b'7',
        }
    }

    /// Resting orders are allowed for these TIFs.
    #[must_use]
    pub const fn allows_resting(self) -> bool {
        matches!(
            self,
            Self::Gtc | Self::Day | Self::Gtd { .. } | Self::Ato | Self::Atc
        )
    }

    /// Auction-only TIFs.
    #[must_use]
    pub const fn auction_only(self) -> bool {
        matches!(self, Self::Atc | Self::Ato)
    }

    /// Returns the expiry instant if this TIF has one.
    #[must_use]
    pub const fn expires_at(self) -> Option<DateTime<Utc>> {
        match self {
            Self::Gtd { expires_at } => Some(expires_at),
            _ => None,
        }
    }
}

#[cfg(test)]
mod tests {
    use chrono::TimeZone;

    use super::*;

    #[test]
    fn fix_codes_match_spec() {
        assert_eq!(TimeInForce::Day.fix_code(), b'0');
        assert_eq!(TimeInForce::Gtc.fix_code(), b'1');
        assert_eq!(TimeInForce::Ato.fix_code(), b'2');
        assert_eq!(TimeInForce::Ioc.fix_code(), b'3');
        assert_eq!(TimeInForce::Fok.fix_code(), b'4');
        let gtd = TimeInForce::Gtd {
            expires_at: Utc.timestamp_opt(0, 0).unwrap(),
        };
        assert_eq!(gtd.fix_code(), b'6');
        assert_eq!(TimeInForce::Atc.fix_code(), b'7');
    }

    #[test]
    fn ioc_and_fok_disallow_resting() {
        assert!(!TimeInForce::Ioc.allows_resting());
        assert!(!TimeInForce::Fok.allows_resting());
        assert!(TimeInForce::Gtc.allows_resting());
    }

    #[test]
    fn gtd_exposes_expiry() {
        let exp = Utc.timestamp_opt(1_700_000_000, 0).unwrap();
        let tif = TimeInForce::Gtd { expires_at: exp };
        assert_eq!(tif.expires_at(), Some(exp));
        assert_eq!(TimeInForce::Gtc.expires_at(), None);
    }
}
