//! Order side.

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum Side {
    Buy,
    Sell,
}

impl Side {
    /// FIX-tag-54 single-character code (`1` = Buy, `2` = Sell).
    #[must_use]
    pub const fn fix_char(self) -> u8 {
        match self {
            Self::Buy => b'1',
            Self::Sell => b'2',
        }
    }

    #[must_use]
    pub const fn from_fix_char(c: u8) -> Option<Self> {
        match c {
            b'1' => Some(Self::Buy),
            b'2' => Some(Self::Sell),
            _ => None,
        }
    }

    #[must_use]
    pub const fn opposite(self) -> Self {
        match self {
            Self::Buy => Self::Sell,
            Self::Sell => Self::Buy,
        }
    }

    /// `+1` for buy, `-1` for sell. Used in position arithmetic.
    #[must_use]
    pub const fn sign(self) -> i32 {
        match self {
            Self::Buy => 1,
            Self::Sell => -1,
        }
    }

    /// Whether this side wants `book_price` in `our_order_price`'s book.
    /// (Buy is happy with prices ≤ its limit; Sell ≥.)
    ///
    /// Used inside `matching-engine::match_against` — keep in sync there.
    #[must_use]
    pub fn crosses(
        self,
        our_limit: rust_decimal::Decimal,
        book_price: rust_decimal::Decimal,
    ) -> bool {
        match self {
            Self::Buy => book_price <= our_limit,
            Self::Sell => book_price >= our_limit,
        }
    }
}

impl std::fmt::Display for Side {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(match self {
            Self::Buy => "buy",
            Self::Sell => "sell",
        })
    }
}

#[cfg(test)]
mod tests {
    use rust_decimal_macros::dec;

    use super::*;

    #[test]
    fn fix_chars_roundtrip() {
        for s in [Side::Buy, Side::Sell] {
            assert_eq!(Side::from_fix_char(s.fix_char()), Some(s));
        }
        assert_eq!(Side::from_fix_char(b'X'), None);
    }

    #[test]
    fn opposite_is_involutive() {
        assert_eq!(Side::Buy.opposite().opposite(), Side::Buy);
    }

    #[test]
    fn buy_crosses_at_or_below_limit() {
        assert!(Side::Buy.crosses(dec!(100), dec!(99)));
        assert!(Side::Buy.crosses(dec!(100), dec!(100)));
        assert!(!Side::Buy.crosses(dec!(100), dec!(101)));
    }

    #[test]
    fn sell_crosses_at_or_above_limit() {
        assert!(Side::Sell.crosses(dec!(100), dec!(101)));
        assert!(Side::Sell.crosses(dec!(100), dec!(100)));
        assert!(!Side::Sell.crosses(dec!(100), dec!(99)));
    }

    #[test]
    fn position_sign() {
        assert_eq!(Side::Buy.sign(), 1);
        assert_eq!(Side::Sell.sign(), -1);
    }
}
