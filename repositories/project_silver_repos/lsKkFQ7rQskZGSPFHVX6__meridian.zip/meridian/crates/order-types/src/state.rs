//! Order status — lifecycle states of an order.
//!
//! Conventional FIX-style order status, plus a `Triggered` state that's
//! specific to stop / stop-limit orders.

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum OrderStatus {
    /// Validated by the gateway, awaiting risk approval.
    PendingNew,
    /// Accepted by the engine, resting on the book.
    New,
    /// Stop / stop-limit waiting for trigger. Not visible to the book.
    Untriggered,
    /// Stop / stop-limit triggered, behaving as the post-trigger type.
    Triggered,
    /// Some quantity has matched; the rest remains on book.
    PartiallyFilled,
    /// Fully matched. Terminal.
    Filled,
    /// Cancelled before fully filling. Terminal.
    Cancelled,
    /// Rejected before reaching the engine (validation, risk, etc).
    Rejected,
    /// Cancelled because the engine couldn't make any of it match
    /// (post-only that would have crossed; FOK that wouldn't fill).
    /// Terminal.
    Expired,
    /// Modified — `client_order_id` of the new order replaces this one.
    /// Used by FIX cancel-replace.
    Replaced,
}

impl OrderStatus {
    #[must_use]
    pub const fn is_terminal(self) -> bool {
        matches!(
            self,
            Self::Filled | Self::Cancelled | Self::Rejected | Self::Expired | Self::Replaced
        )
    }

    #[must_use]
    pub const fn is_active(self) -> bool {
        matches!(
            self,
            Self::New | Self::PartiallyFilled | Self::Untriggered | Self::Triggered
        )
    }

    /// FIX tag 39 single-character code.
    #[must_use]
    pub const fn fix_code(self) -> u8 {
        match self {
            Self::PendingNew => b'A',
            Self::New => b'0',
            Self::Untriggered => b'9',
            Self::Triggered => b'L',
            Self::PartiallyFilled => b'1',
            Self::Filled => b'2',
            Self::Cancelled => b'4',
            Self::Rejected => b'8',
            Self::Expired => b'C',
            Self::Replaced => b'5',
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn terminal_classification() {
        assert!(OrderStatus::Filled.is_terminal());
        assert!(OrderStatus::Cancelled.is_terminal());
        assert!(!OrderStatus::PartiallyFilled.is_terminal());
        assert!(OrderStatus::PartiallyFilled.is_active());
        assert!(!OrderStatus::Cancelled.is_active());
    }
}
