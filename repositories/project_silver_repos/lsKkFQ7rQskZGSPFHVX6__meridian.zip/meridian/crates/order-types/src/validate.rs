//! Validation rules — applied at the gateway and again at the engine
//! boundary as a defence in depth.
//!
//! Validation here is *intrinsic* to the order — it doesn't look at
//! the book or the symbol's reference data. Tick / lot / band checks
//! belong in `ref-data` and `risk-engine`.

use chrono::{DateTime, Utc};

use crate::error::{OrderError, OrderResult};
use crate::order::NewOrder;
use crate::tif::TimeInForce;
use crate::types::OrderType;

/// Validate the *intrinsic* shape of a `NewOrder`.
///
/// Returns Ok if every required field is present and consistent with
/// the order type / TIF combination.
pub fn validate_new_order(o: &NewOrder, now: DateTime<Utc>) -> OrderResult<()> {
    // qty must be positive
    if !o.quantity.is_positive() {
        return Err(OrderError::NonPositiveQuantity(o.quantity.to_string()));
    }

    // type-specific price requirements
    if o.order_type.requires_limit_price() {
        let p = o
            .limit_price
            .ok_or(OrderError::MissingLimitPrice(o.order_type))?;
        if !p.is_positive() {
            return Err(OrderError::NonPositivePrice(p.to_string()));
        }
    }
    if o.order_type.requires_trigger_price() {
        let p = o
            .trigger_price
            .ok_or(OrderError::MissingStopTrigger(o.order_type))?;
        if !p.is_positive() {
            return Err(OrderError::NonPositivePrice(p.to_string()));
        }
    }

    // iceberg invariants
    if matches!(o.order_type, OrderType::Iceberg) {
        let display = o
            .display_qty
            .ok_or_else(|| OrderError::invalid("iceberg order requires display_qty"))?;
        if !display.is_positive() {
            return Err(OrderError::IcebergDisplayNonPositive);
        }
        if display > o.quantity {
            return Err(OrderError::IcebergDisplayExceedsTotal {
                display: display.to_string(),
                total: o.quantity.to_string(),
            });
        }
    }

    // peg sanity
    if let OrderType::Peg {
        reference: _,
        offset_ticks,
    } = o.order_type
    {
        if offset_ticks.unsigned_abs() > 1_000 {
            return Err(OrderError::invalid(
                "peg offset must be within +/- 1000 ticks",
            ));
        }
    }

    // TIF / type compatibility
    if matches!(o.order_type, OrderType::Market) && matches!(o.time_in_force, TimeInForce::Gtc) {
        return Err(OrderError::MarketCannotBeGtc);
    }

    if let TimeInForce::Gtd { expires_at } = o.time_in_force {
        if expires_at <= now {
            return Err(OrderError::ExpiryInPast);
        }
    }

    if o.post_only {
        match o.time_in_force {
            // post-only is meaningless in IOC/FOK (those don't rest
            // anyway) but we accept it as a no-op for client convenience
            TimeInForce::Ioc | TimeInForce::Fok => {},
            // Auction-only TIFs are also a no-op for post-only.
            TimeInForce::Atc | TimeInForce::Ato => {},
            _ => {},
        }
    }

    if matches!(o.order_type, OrderType::Market) && o.post_only {
        return Err(OrderError::invalid("market order cannot be post-only"));
    }

    Ok(())
}

#[cfg(test)]
mod tests {
    use chrono::TimeZone;
    use meridian_common::prelude::{AccountId, ClientOrderId, Price, Quantity, Symbol};
    use rust_decimal_macros::dec;

    use crate::peg::PegReference;

    use super::*;

    fn now() -> DateTime<Utc> {
        Utc.timestamp_opt(1_700_000_000, 0).unwrap()
    }

    fn limit() -> NewOrder {
        NewOrder::limit(
            AccountId::new(1),
            ClientOrderId::new(1),
            Symbol::new("BTC-USD").unwrap(),
            crate::Side::Buy,
            Price::from_decimal(dec!(100)),
            Quantity::from_decimal(dec!(1)),
        )
    }

    #[test]
    fn happy_path_limit() {
        validate_new_order(&limit(), now()).unwrap();
    }

    #[test]
    fn rejects_non_positive_qty() {
        let mut o = limit();
        o.quantity = Quantity::ZERO;
        assert!(validate_new_order(&o, now()).is_err());
    }

    #[test]
    fn rejects_iceberg_with_zero_display() {
        let mut o = limit();
        o.order_type = OrderType::Iceberg;
        o.display_qty = Some(Quantity::ZERO);
        match validate_new_order(&o, now()) {
            Err(OrderError::IcebergDisplayNonPositive) => {},
            other => panic!("expected IcebergDisplayNonPositive, got {:?}", other),
        }
    }

    #[test]
    fn rejects_iceberg_with_display_over_total() {
        let mut o = limit();
        o.order_type = OrderType::Iceberg;
        o.quantity = Quantity::from_decimal(dec!(1));
        o.display_qty = Some(Quantity::from_decimal(dec!(2)));
        assert!(matches!(
            validate_new_order(&o, now()),
            Err(OrderError::IcebergDisplayExceedsTotal { .. })
        ));
    }

    #[test]
    fn rejects_market_gtc() {
        let mut o = limit();
        o.order_type = OrderType::Market;
        o.limit_price = None;
        o.time_in_force = TimeInForce::Gtc;
        assert!(matches!(
            validate_new_order(&o, now()),
            Err(OrderError::MarketCannotBeGtc)
        ));
    }

    #[test]
    fn rejects_gtd_in_past() {
        let mut o = limit();
        o.time_in_force = TimeInForce::Gtd {
            expires_at: now() - chrono::Duration::seconds(1),
        };
        assert!(matches!(
            validate_new_order(&o, now()),
            Err(OrderError::ExpiryInPast)
        ));
    }

    #[test]
    fn peg_offset_bounds() {
        let mut o = limit();
        o.order_type = OrderType::Peg {
            reference: PegReference::Mid,
            offset_ticks: 5_000,
        };
        assert!(validate_new_order(&o, now()).is_err());
    }
}
