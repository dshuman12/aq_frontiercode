//! Amend — modify an existing order in place.
//!
//! We only allow narrowing changes (qty down, price worse) while
//! retaining priority. Anything that improves price or *adds* qty
//! re-queues the order, losing time priority. The semantic — "amend
//! down keeps priority, amend up loses it" — is the rule of thumb on
//! every venue we benchmarked against.

use meridian_common::prelude::*;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct AmendRequest {
    pub account_id: AccountId,
    pub symbol: Symbol,
    pub order_id: OrderId,

    /// New limit price. None means leave unchanged.
    pub new_limit_price: Option<Price>,

    /// New quantity (absolute). None means leave unchanged.
    /// May not bring quantity below already-filled (engine rejects).
    pub new_quantity: Option<Quantity>,

    /// New display qty (iceberg only).
    pub new_display_qty: Option<Quantity>,

    /// Caller hint: if this would re-queue the order (lose priority),
    /// reject instead of executing the amend. Useful for FIX clients
    /// that want to be explicit.
    pub reject_on_priority_loss: bool,
}

impl AmendRequest {
    /// True if this amend can be applied in place.
    #[must_use]
    pub fn is_narrowing(
        &self,
        current_price: Price,
        current_qty: Quantity,
        side: crate::Side,
    ) -> bool {
        let price_ok = match self.new_limit_price {
            Some(p) => match side {
                crate::Side::Buy => p <= current_price,  // worse for buyer
                crate::Side::Sell => p >= current_price, // worse for seller
            },
            None => true,
        };
        let qty_ok = self.new_quantity.is_none_or(|q| q <= current_qty);
        price_ok && qty_ok
    }
}
