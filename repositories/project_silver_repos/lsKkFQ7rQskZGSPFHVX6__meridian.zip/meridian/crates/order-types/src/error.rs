//! Errors raised by order construction / validation.

use std::borrow::Cow;

use meridian_common::Error as CommonError;
use thiserror::Error;

pub type OrderResult<T> = Result<T, OrderError>;

#[derive(Debug, Error)]
pub enum OrderError {
    #[error("price must be positive (got {0})")]
    NonPositivePrice(String),

    #[error("quantity must be positive (got {0})")]
    NonPositiveQuantity(String),

    #[error("limit price required for order type {0:?}")]
    MissingLimitPrice(crate::types::OrderType),

    #[error("stop trigger price required for order type {0:?}")]
    MissingStopTrigger(crate::types::OrderType),

    #[error("expiry required for time-in-force GTD")]
    MissingExpiry,

    #[error("expiry already in the past")]
    ExpiryInPast,

    #[error("display qty {display} exceeds total qty {total}")]
    IcebergDisplayExceedsTotal { display: String, total: String },

    #[error("display qty must be positive for iceberg")]
    IcebergDisplayNonPositive,

    #[error("post-only is incompatible with TIF {0:?}")]
    PostOnlyIncompatibleTif(crate::tif::TimeInForce),

    #[error("market orders cannot be GTC; use IOC or FOK")]
    MarketCannotBeGtc,

    #[error("invalid argument: {0}")]
    InvalidArgument(Cow<'static, str>),

    #[error(transparent)]
    Common(#[from] CommonError),
}

impl OrderError {
    pub fn invalid<S: Into<Cow<'static, str>>>(msg: S) -> Self {
        Self::InvalidArgument(msg.into())
    }
}
