//! Drop-copy fanout surface.

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct DropCopyEvent {
    pub account: String,
    pub exec_id: String,
    pub payload: serde_json::Value,
}

#[derive(Debug, Default)]
pub struct DropCopySession {
    subscribers: Vec<String>,
}

impl DropCopySession {
    pub fn subscribe(&mut self, session_id: String) {
        if !self.subscribers.contains(&session_id) {
            self.subscribers.push(session_id);
        }
    }

    #[must_use]
    pub fn subscribers(&self) -> &[String] {
        &self.subscribers
    }
}
