//! Minimal FIX dictionary used by Meridian.

pub const USED_TAGS: &[u32] = &[
    8, 9, 10, 11, 14, 17, 21, 22, 31, 32, 35, 37, 38, 39, 40, 44, 49, 52, 54, 55, 56, 58, 59, 60,
    99, 103, 110, 111, 150, 151, 167, 851, 1094, 7928,
];

#[must_use]
pub fn is_supported_tag(tag: u32) -> bool {
    USED_TAGS.binary_search(&tag).is_ok()
}
