//! Typed FIX message shapes used by the gateway.

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct Logon {
    pub sender_comp_id: String,
    pub target_comp_id: String,
    pub heartbeat_sec: u32,
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct Logout {
    pub text: Option<String>,
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct Heartbeat {
    pub test_req_id: Option<String>,
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct TestRequest {
    pub test_req_id: String,
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct ResendRequest {
    pub begin_seq_no: u64,
    pub end_seq_no: u64,
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct SequenceReset {
    pub new_seq_no: u64,
    pub gap_fill: bool,
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct NewOrderSingle {
    pub cl_ord_id: String,
    pub symbol: String,
    pub side: char,
    pub quantity: String,
    pub ord_type: char,
    pub price: Option<String>,
    pub tif: Option<char>,
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct OrderCancelRequest {
    pub cl_ord_id: String,
    pub orig_cl_ord_id: String,
    pub symbol: String,
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct OrderCancelReplaceRequest {
    pub cl_ord_id: String,
    pub orig_cl_ord_id: String,
    pub symbol: String,
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct ExecutionReport {
    pub order_id: String,
    pub exec_id: String,
    pub ord_status: char,
    pub exec_type: char,
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct OrderCancelReject {
    pub order_id: String,
    pub cl_ord_id: String,
    pub text: String,
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct Reject {
    pub ref_seq_num: u64,
    pub text: String,
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct TradeCaptureReport {
    pub trade_report_id: String,
    pub exec_id: String,
}
