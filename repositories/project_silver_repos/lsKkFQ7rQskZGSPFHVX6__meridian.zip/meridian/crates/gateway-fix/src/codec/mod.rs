//! FIX wire encoder/decoder.

use bytes::BytesMut;

use crate::error::FixGatewayError;

pub mod dict;
pub mod messages;

pub const SOH: u8 = 0x01;

#[derive(Debug, Default)]
pub struct Encoder;

#[derive(Debug, Default)]
pub struct Decoder;

impl Encoder {
    pub fn encode(msg_type: &str, fields: &[(u32, String)]) -> Result<Vec<u8>, FixGatewayError> {
        let mut body = Vec::<u8>::new();
        body.extend_from_slice(format!("35={msg_type}").as_bytes());
        body.push(SOH);
        for (tag, value) in fields {
            body.extend_from_slice(format!("{tag}={value}").as_bytes());
            body.push(SOH);
        }
        let head = format!("8=FIX.4.4{0}9={1}{0}", SOH as char, body.len());
        let mut packet = head.into_bytes();
        packet.extend_from_slice(&body);
        let cksum = checksum(&packet);
        packet.extend_from_slice(format!("10={cksum:03}{}", SOH as char).as_bytes());
        Ok(packet)
    }
}

impl Decoder {
    pub fn decode_next(buf: &mut BytesMut) -> Result<Option<Vec<(u32, String)>>, FixGatewayError> {
        let Some(start) = find_begin_string(buf) else {
            return Ok(None);
        };
        if start > 0 {
            let _ = buf.split_to(start);
        }
        let Some(end) = find_checksum_end(buf) else {
            return Ok(None);
        };
        let frame = buf.split_to(end).to_vec();
        verify_frame(&frame)?;
        Ok(Some(parse_fields(&frame)))
    }
}

fn find_begin_string(buf: &BytesMut) -> Option<usize> {
    buf.windows(10).position(|w| w == b"8=FIX.4.4\x01")
}

fn find_checksum_end(buf: &BytesMut) -> Option<usize> {
    let needle = b"\x0110=";
    let start = buf.windows(needle.len()).position(|w| w == needle)?;
    let tail_start = start + needle.len();
    if buf.len() < tail_start + 4 {
        return None;
    }
    if buf[tail_start + 3] != SOH {
        return None;
    }
    Some(tail_start + 4)
}

fn verify_frame(frame: &[u8]) -> Result<(), FixGatewayError> {
    let fields = parse_fields(frame);
    let body_len = fields
        .iter()
        .find(|(tag, _)| *tag == 9)
        .and_then(|(_, v)| v.parse::<usize>().ok())
        .ok_or_else(|| FixGatewayError::Decode("missing BodyLength(9)".into()))?;
    let checksum_field = fields
        .iter()
        .find(|(tag, _)| *tag == 10)
        .ok_or_else(|| FixGatewayError::Decode("missing CheckSum(10)".into()))?;
    let expected = checksum_field
        .1
        .parse::<u8>()
        .map_err(|_| FixGatewayError::Decode("invalid CheckSum(10)".into()))?;

    let checksum_start = frame
        .windows(4)
        .position(|w| w == b"10=")
        .ok_or_else(|| FixGatewayError::Decode("missing trailer".into()))?;
    let computed = checksum(&frame[..checksum_start]);
    if computed != expected {
        return Err(FixGatewayError::BadChecksum);
    }

    let body_start = frame
        .windows(3)
        .position(|w| w == b"9=")
        .and_then(|idx| {
            frame[idx..]
                .iter()
                .position(|b| *b == SOH)
                .map(|off| idx + off + 1)
        })
        .ok_or_else(|| FixGatewayError::Decode("invalid body".into()))?;
    let body_end = checksum_start.saturating_sub(1);
    let actual = body_end.saturating_sub(body_start).saturating_add(1);
    if actual != body_len {
        return Err(FixGatewayError::BadBodyLength);
    }
    Ok(())
}

fn checksum(bytes: &[u8]) -> u8 {
    (bytes.iter().fold(0_u32, |acc, b| acc + u32::from(*b)) % 256) as u8
}

fn parse_fields(frame: &[u8]) -> Vec<(u32, String)> {
    frame
        .split(|b| *b == SOH)
        .filter(|s| !s.is_empty())
        .filter_map(|kv| {
            let s = std::str::from_utf8(kv).ok()?;
            let (k, v) = s.split_once('=')?;
            let tag = k.parse::<u32>().ok()?;
            Some((tag, v.to_string()))
        })
        .collect()
}
