//! FIX session state machine.

use crate::error::FixGatewayError;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SessionPhase {
    AwaitLogon,
    Active,
    LoggedOut,
}

#[derive(Debug, Clone)]
pub struct FixSessionState {
    pub expected_in: u64,
    pub next_out: u64,
    pub phase: SessionPhase,
    pub sender_comp_id: String,
    pub target_comp_id: String,
}

impl FixSessionState {
    #[must_use]
    pub fn new(sender_comp_id: String, target_comp_id: String) -> Self {
        Self {
            expected_in: 1,
            next_out: 1,
            phase: SessionPhase::AwaitLogon,
            sender_comp_id,
            target_comp_id,
        }
    }

    pub fn on_logon(&mut self, sender: &str, target: &str) -> Result<(), FixGatewayError> {
        if sender != self.target_comp_id || target != self.sender_comp_id {
            return Err(FixGatewayError::Session("CompID mismatch".into()));
        }
        self.phase = SessionPhase::Active;
        Ok(())
    }

    pub fn on_incoming_seq(&mut self, seq: u64) -> Result<(), FixGatewayError> {
        if seq > self.expected_in + 100 {
            self.phase = SessionPhase::LoggedOut;
            return Err(FixGatewayError::Session(
                "MsgSeqNum > expected+100, logout required".into(),
            ));
        }
        if seq >= self.expected_in {
            self.expected_in = seq + 1;
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn large_seq_gap_requires_logout() {
        let mut s = FixSessionState::new("MERIDIAN".into(), "CLIENT1".into());
        s.phase = SessionPhase::Active;
        let err = s.on_incoming_seq(200).unwrap_err();
        assert!(err.to_string().contains("expected+100"));
        assert_eq!(s.phase, SessionPhase::LoggedOut);
    }
}
