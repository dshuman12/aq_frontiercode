//! FIX gateway errors.

use thiserror::Error;

#[derive(Debug, Error)]
pub enum FixGatewayError {
    #[error("decode error: {0}")]
    Decode(String),
    #[error("encode error: {0}")]
    Encode(String),
    #[error("bad checksum")]
    BadChecksum,
    #[error("body length mismatch")]
    BadBodyLength,
    #[error("session rejected: {0}")]
    Session(String),
}
