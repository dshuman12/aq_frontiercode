// REST entrypoint for order/account/market APIs.

#![forbid(unsafe_code)]
#![deny(rust_2018_idioms)]
#![allow(
    clippy::pedantic,
    clippy::nursery,
    missing_debug_implementations,
    missing_docs
)]
#![allow(
    clippy::module_name_repetitions,
    clippy::missing_errors_doc,
    clippy::missing_panics_doc,
    clippy::must_use_candidate
)]

//! Meridian REST gateway.

pub mod auth_middleware;
pub mod error;
pub mod routes;

use std::sync::Arc;

use axum::Router;
use tokio::sync::RwLock;

#[derive(Debug, Default)]
pub struct AppState {
    pub open_orders: Arc<RwLock<Vec<meridian_order_types::NewOrder>>>,
}

pub fn router(state: AppState) -> Router {
    routes::router().with_state(Arc::new(state))
}
