use axum::Json;

pub async fn balances() -> Json<serde_json::Value> {
    Json(serde_json::json!({"balances":[]}))
}

pub async fn fills() -> Json<serde_json::Value> {
    Json(serde_json::json!({"fills":[]}))
}

pub async fn positions() -> Json<serde_json::Value> {
    Json(serde_json::json!({"positions":[]}))
}
