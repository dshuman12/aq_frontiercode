use axum::extract::Path;
use axum::Json;

pub async fn symbols() -> Json<serde_json::Value> {
    Json(serde_json::json!({"symbols":["BTC-USD"]}))
}

pub async fn depth(Path(symbol): Path<String>) -> Json<serde_json::Value> {
    Json(serde_json::json!({"symbol":symbol,"bids":[],"asks":[]}))
}

pub async fn trades(Path(symbol): Path<String>) -> Json<serde_json::Value> {
    Json(serde_json::json!({"symbol":symbol,"trades":[]}))
}

pub async fn ticker(Path(symbol): Path<String>) -> Json<serde_json::Value> {
    Json(serde_json::json!({"symbol":symbol,"last":null}))
}

pub async fn candles(Path(symbol): Path<String>) -> Json<serde_json::Value> {
    Json(serde_json::json!({"symbol":symbol,"resolution":"1m","candles":[]}))
}
