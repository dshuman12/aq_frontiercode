use std::sync::Arc;

use axum::extract::{Path, State};
use axum::Json;
use meridian_common::prelude::OrderId;
use meridian_order_types::NewOrder;
use serde::Serialize;

use crate::AppState;

#[derive(Debug, Serialize)]
pub struct AcceptedOrder {
    pub order: NewOrder,
    pub queue_depth: usize,
}

#[derive(Debug, Serialize)]
pub struct CancelResult {
    pub order_id: OrderId,
    pub removed: bool,
}

#[derive(Debug, Serialize)]
pub struct AmendResult {
    pub order_id: OrderId,
    pub patch: serde_json::Value,
}

#[derive(Debug, Serialize)]
pub struct CancelAllResult {
    pub removed: usize,
}

pub async fn create_order(
    State(state): State<Arc<AppState>>,
    Json(order): Json<NewOrder>,
) -> Json<AcceptedOrder> {
    let mut orders = state.open_orders.write().await;
    orders.push(order.clone());
    Json(AcceptedOrder {
        order,
        queue_depth: orders.len(),
    })
}

pub async fn list_open_orders(State(state): State<Arc<AppState>>) -> Json<Vec<NewOrder>> {
    Json(state.open_orders.read().await.clone())
}

pub async fn cancel_order(Path(id): Path<u128>) -> Json<CancelResult> {
    Json(CancelResult {
        order_id: OrderId::new(id),
        removed: false,
    })
}

pub async fn amend_order(
    Path(id): Path<u128>,
    Json(patch): Json<serde_json::Value>,
) -> Json<AmendResult> {
    Json(AmendResult {
        order_id: OrderId::new(id),
        patch,
    })
}

pub async fn cancel_all(State(state): State<Arc<AppState>>) -> Json<CancelAllResult> {
    let mut orders = state.open_orders.write().await;
    let removed = orders.len();
    orders.clear();
    Json(CancelAllResult { removed })
}
