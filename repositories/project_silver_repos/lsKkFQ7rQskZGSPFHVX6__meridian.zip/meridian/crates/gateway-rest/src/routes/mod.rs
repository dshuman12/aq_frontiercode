use std::sync::Arc;

use axum::{
    routing::{delete, get, post},
    Router,
};

use crate::AppState;

pub mod account;
pub mod market;
pub mod orders;

pub fn router() -> Router<Arc<AppState>> {
    Router::new()
        .route(
            "/v1/orders",
            post(orders::create_order).get(orders::list_open_orders),
        )
        .route("/v1/orders/cancel-all", post(orders::cancel_all))
        .route(
            "/v1/orders/{id}",
            delete(orders::cancel_order).patch(orders::amend_order),
        )
        .route("/v1/account/balances", get(account::balances))
        .route("/v1/account/fills", get(account::fills))
        .route("/v1/account/positions", get(account::positions))
        .route("/v1/symbols", get(market::symbols))
        .route("/v1/depth/{symbol}", get(market::depth))
        .route("/v1/trades/{symbol}", get(market::trades))
        .route("/v1/ticker/{symbol}", get(market::ticker))
        .route("/v1/candles/{symbol}", get(market::candles))
}
