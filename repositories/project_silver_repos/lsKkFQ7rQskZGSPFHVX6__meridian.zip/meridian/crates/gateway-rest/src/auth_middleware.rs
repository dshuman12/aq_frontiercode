//! Header-based API-key signature authentication.

use std::sync::Arc;

use axum::extract::State;
use axum::http::Request;
use axum::middleware::Next;
use axum::response::Response;
use meridian_common::clock::{Clock as _, SystemClock};

use crate::error::ApiError;

pub type SecretResolver = Arc<dyn Fn(&str) -> Option<String> + Send + Sync>;

#[derive(Clone)]
pub struct AuthState {
    pub resolve_secret: SecretResolver,
}

pub async fn verify_api_signature(
    State(state): State<AuthState>,
    mut request: Request<axum::body::Body>,
    next: Next,
) -> Result<Response, ApiError> {
    let headers = request.headers();
    let key = headers
        .get("X-Meridian-Key")
        .and_then(|v| v.to_str().ok())
        .ok_or_else(|| ApiError::unauthorized("missing X-Meridian-Key"))?
        .to_owned();
    let signature = headers
        .get("X-Meridian-Signature")
        .and_then(|v| v.to_str().ok())
        .ok_or_else(|| ApiError::unauthorized("missing X-Meridian-Signature"))?
        .to_owned();
    let ts = headers
        .get("X-Meridian-Timestamp")
        .and_then(|v| v.to_str().ok())
        .ok_or_else(|| ApiError::unauthorized("missing X-Meridian-Timestamp"))?
        .to_owned();

    let ts_unix = ts
        .parse::<i64>()
        .map_err(|_| ApiError::unauthorized("invalid timestamp"))?;
    let now_unix = SystemClock.now().timestamp();
    if (now_unix - ts_unix).unsigned_abs() > 30 {
        return Err(ApiError::unauthorized("timestamp outside 30s window"));
    }

    let method = request.method().as_str().to_string();
    let path = request.uri().path().to_string();
    let secret =
        (state.resolve_secret)(&key).ok_or_else(|| ApiError::unauthorized("unknown key"))?;

    let req = meridian_auth::CanonicalRequest {
        timestamp: ts,
        method,
        path,
        body: String::new(),
    };
    meridian_auth::verify_hmac_sha256_hex(&secret, &req, &signature)
        .map_err(|_| ApiError::unauthorized("signature mismatch"))?;

    request.extensions_mut().insert(key);
    Ok(next.run(request).await)
}
