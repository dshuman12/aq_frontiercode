//! Sequencer errors.

use std::io;

use meridian_common::Error as CommonError;
use thiserror::Error;

pub type SequencerResult<T> = Result<T, SequencerError>;

#[derive(Debug, Error)]
pub enum SequencerError {
    #[error("admission denied: {0}")]
    AdmissionDenied(String),

    #[error("log io error: {0}")]
    LogIo(#[from] io::Error),

    #[error("log corrupt at offset {offset}: {msg}")]
    LogCorrupt { offset: u64, msg: String },

    #[error("log header mismatch: expected magic {expected:#x}, got {actual:#x}")]
    LogHeaderMismatch { expected: u32, actual: u32 },

    #[error("checksum mismatch in log record at offset {offset}")]
    ChecksumMismatch { offset: u64 },

    #[error("router has no engine for symbol {0}")]
    NoEngineForSymbol(String),

    #[error("seq regression: last={last}, attempted={attempted}")]
    SeqRegression { last: u64, attempted: u64 },

    #[error("snapshot recovery: {0}")]
    Recovery(String),

    #[error("encoding: {0}")]
    Encoding(String),

    #[error(transparent)]
    Common(#[from] CommonError),
}

impl SequencerError {
    pub fn admission_denied(msg: impl Into<String>) -> Self {
        Self::AdmissionDenied(msg.into())
    }

    pub fn recovery(msg: impl Into<String>) -> Self {
        Self::Recovery(msg.into())
    }

    pub fn encoding(msg: impl Into<String>) -> Self {
        Self::Encoding(msg.into())
    }
}
