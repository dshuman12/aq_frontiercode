//! Admission control.
//!
//! Decides whether a command should enter the sequencer or be
//! rejected at the door. The default policy enforces:
//!
//! - inflight cap (per-account simple counter),
//! - per-second rate cap (per-account rolling 1s window),
//! - kill-switch (every command refused except admin),
//! - shard membership (engine known for the symbol).
//!
//! Admission is *separate* from risk. Risk approval (margin, position
//! limits) lives in `risk-engine` and runs *after* the sequencer
//! assigns a SeqNo — but before the matching engine sees the order.
//! The reason for that split is that risk wants to know about other
//! orders in flight (which is post-sequencer state), while admission
//! is purely a per-account rate / cap check.

use std::collections::HashMap;
use std::time::Duration;

use meridian_common::prelude::*;
use parking_lot::Mutex;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum AdmissionDecision {
    Accept,
    RejectKillSwitched,
    RejectInflightCap,
    RejectRateLimit,
    RejectUnknownSymbol,
}

#[derive(Debug, Clone)]
pub struct AdmissionPolicy {
    pub max_inflight_per_account: u32,
    pub max_per_sec_per_account: u32,
    pub kill_switched: bool,
    pub window: Duration,
}

impl Default for AdmissionPolicy {
    fn default() -> Self {
        Self {
            max_inflight_per_account: 4_096,
            max_per_sec_per_account: 1_000,
            kill_switched: false,
            window: Duration::from_secs(1),
        }
    }
}

#[derive(Debug, Default)]
struct WindowedCounter {
    timestamps_ns: Vec<i64>,
}

impl WindowedCounter {
    fn record(&mut self, now_ns: i64, window_ns: i64) -> u32 {
        // Drop any timestamps older than the window.
        let cutoff = now_ns - window_ns;
        let drop_until = self.timestamps_ns.partition_point(|t| *t < cutoff);
        if drop_until > 0 {
            self.timestamps_ns.drain(..drop_until);
        }
        self.timestamps_ns.push(now_ns);
        u32::try_from(self.timestamps_ns.len()).unwrap_or(u32::MAX)
    }
}

/// Admission state shared across the sequencer's command channel.
#[derive(Debug)]
pub struct Admit {
    policy: AdmissionPolicy,
    inflight: Mutex<HashMap<AccountId, u32>>,
    windows: Mutex<HashMap<AccountId, WindowedCounter>>,
}

impl Admit {
    #[must_use]
    pub fn new(policy: AdmissionPolicy) -> Self {
        Self {
            policy,
            inflight: Mutex::new(HashMap::new()),
            windows: Mutex::new(HashMap::new()),
        }
    }

    pub fn set_kill(&mut self, engaged: bool) {
        self.policy.kill_switched = engaged;
    }

    /// Check the policy and bookkeep on accept. Idempotent for the
    /// rate window; the inflight count must be paired with a later
    /// `release_inflight`.
    pub fn admit(&self, account: AccountId, admin: bool, now: Timestamp) -> AdmissionDecision {
        if self.policy.kill_switched && !admin {
            return AdmissionDecision::RejectKillSwitched;
        }
        // Rate window.
        let window_ns = i64::try_from(self.policy.window.as_nanos()).unwrap_or(i64::MAX);
        let count_in_window = {
            let mut wins = self.windows.lock();
            let entry = wins.entry(account).or_default();
            entry.record(now.unix_nanos(), window_ns)
        };
        if count_in_window > self.policy.max_per_sec_per_account {
            return AdmissionDecision::RejectRateLimit;
        }

        // Inflight cap.
        {
            let mut inflight = self.inflight.lock();
            let entry = inflight.entry(account).or_insert(0);
            if *entry >= self.policy.max_inflight_per_account {
                return AdmissionDecision::RejectInflightCap;
            }
            *entry += 1;
        }
        AdmissionDecision::Accept
    }

    /// Release an inflight slot once the engine has acknowledged the
    /// command (success or rejection).
    pub fn release_inflight(&self, account: AccountId) {
        let mut inflight = self.inflight.lock();
        let entry = inflight.entry(account).or_insert(0);
        if *entry > 0 {
            *entry -= 1;
        }
    }

    #[must_use]
    pub fn inflight_for(&self, account: AccountId) -> u32 {
        self.inflight.lock().get(&account).copied().unwrap_or(0)
    }
}

#[cfg(test)]
mod tests {
    use chrono::TimeZone;

    use super::*;

    fn ts(s: i64, ns: i64) -> Timestamp {
        Timestamp::from_datetime(
            chrono::Utc
                .timestamp_opt(s, u32::try_from(ns).unwrap())
                .unwrap(),
        )
    }

    #[test]
    fn kill_switch_blocks_non_admin() {
        let mut policy = AdmissionPolicy::default();
        policy.kill_switched = true;
        let a = Admit::new(policy);
        let acc = AccountId::new(1);
        assert_eq!(
            a.admit(acc, false, ts(1, 0)),
            AdmissionDecision::RejectKillSwitched
        );
        assert_eq!(a.admit(acc, true, ts(1, 0)), AdmissionDecision::Accept);
    }

    #[test]
    fn rate_limit_kicks_in() {
        let policy = AdmissionPolicy {
            max_per_sec_per_account: 3,
            window: Duration::from_secs(1),
            ..Default::default()
        };
        let a = Admit::new(policy);
        let acc = AccountId::new(1);
        for i in 0..3 {
            assert_eq!(
                a.admit(acc, false, ts(0, i64::from(i) * 1_000)),
                AdmissionDecision::Accept
            );
            a.release_inflight(acc);
        }
        // Fourth in the same window should fail.
        assert_eq!(
            a.admit(acc, false, ts(0, 3_000)),
            AdmissionDecision::RejectRateLimit
        );
    }

    #[test]
    fn inflight_cap_blocks_concurrent_overflow() {
        let policy = AdmissionPolicy {
            max_inflight_per_account: 2,
            max_per_sec_per_account: 1_000,
            ..Default::default()
        };
        let a = Admit::new(policy);
        let acc = AccountId::new(1);
        assert_eq!(a.admit(acc, false, ts(0, 0)), AdmissionDecision::Accept);
        assert_eq!(a.admit(acc, false, ts(0, 1)), AdmissionDecision::Accept);
        assert_eq!(
            a.admit(acc, false, ts(0, 2)),
            AdmissionDecision::RejectInflightCap
        );
        a.release_inflight(acc);
        assert_eq!(a.admit(acc, false, ts(0, 3)), AdmissionDecision::Accept);
    }
}
