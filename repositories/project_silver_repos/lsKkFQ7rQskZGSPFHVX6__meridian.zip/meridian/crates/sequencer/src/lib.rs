// Sequencer — the system clock for state.
//
// The sequencer is the *only* thing in the platform that can assign a
// `SeqNo`. Gateways send raw commands here; the sequencer:
//
//   1. validates the envelope (auth handled upstream — we trust the
//      gateway, but we re-check basic invariants),
//   2. assigns a monotonic SeqNo + timestamp,
//   3. persists the command into the durable log,
//   4. forwards it to the matching engine for the relevant symbol.
//
// Persistence happens *before* forwarding so that recovery is
// possible: at any time we can replay the log from a known good
// snapshot and reproduce engine state exactly.
//
// # Sharding
//
// The sequencer is per-shard, where a shard is a disjoint set of
// symbols. We co-locate the engines for a shard with their sequencer
// to keep the network hop short. Cross-shard atomicity is *not* a
// thing — by design, an order touches exactly one symbol on one
// shard.

#![forbid(unsafe_code)]
#![deny(rust_2018_idioms)]
#![allow(
    clippy::pedantic,
    clippy::nursery,
    missing_debug_implementations,
    missing_docs
)]
#![allow(
    clippy::module_name_repetitions,
    clippy::missing_errors_doc,
    clippy::missing_panics_doc,
    clippy::must_use_candidate
)]

//! Sequencer crate — see module docs for the architectural picture.

pub mod admit;
pub mod error;
pub mod log;
pub mod recovery;
pub mod router;
pub mod sequencer;

pub use admit::{AdmissionDecision, AdmissionPolicy, Admit};
pub use error::{SequencerError, SequencerResult};
pub use log::{CommandLog, LogReader, LogWriter, RecordHeader};
pub use recovery::{recover_to, RecoveryReport};
pub use router::{RouteEntry, Router, ShardId};
pub use sequencer::{Sequencer, SequencerConfig};
