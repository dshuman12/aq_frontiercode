//! Sequencer / engine recovery.
//!
//! On startup we have:
//!
//! 1. The most recent durable snapshot — written by the snapshot
//!    worker as of some `SeqNo = N`.
//! 2. The command log up to `SeqNo = M >= N`.
//!
//! We restore the engine to its `N` state from the snapshot, then
//! replay every record from `N+1..=M` through the engine. After
//! recovery the sequencer's allocator is set to `M+1`.
//!
//! This module supplies the *replay-only* part. Snapshot loading is
//! done by the engine itself (it's the one that knows what fields to
//! restore). The sequencer only owns the log scan.

use std::path::Path;

use meridian_common::prelude::*;
use meridian_matching::{Command, CommandKind};
use serde::{Deserialize, Serialize};

use crate::error::{SequencerError, SequencerResult};
use crate::log::{CommandLog, LogReader};

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct RecoveryReport {
    pub records_scanned: u64,
    pub records_replayed: u64,
    pub last_seq_replayed: SeqNo,
    pub gap_detected_at: Option<SeqNo>,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
struct LoggedCommand {
    seq_no: u64,
    at_unix_nanos: i64,
    kind: CommandKind,
    account_id: AccountId,
}

/// Replay every record whose `seq_no > start_after` from the log into
/// `apply`. The closure is called once per command. The function does
/// not catch panics; if the engine panics on replay the caller is
/// expected to bail.
pub fn recover_to<F>(
    log_path: impl AsRef<Path>,
    start_after: SeqNo,
    mut apply: F,
) -> SequencerResult<RecoveryReport>
where
    F: FnMut(Command, AccountId) -> SequencerResult<()>,
{
    let log = CommandLog::open(log_path)?;
    let mut reader = log.reader()?;
    let mut report = RecoveryReport {
        records_scanned: 0,
        records_replayed: 0,
        last_seq_replayed: SeqNo::ZERO,
        gap_detected_at: None,
    };
    let mut prev_seq = start_after;

    while let Some((header, payload)) = reader.read_next()? {
        report.records_scanned += 1;
        let seq = SeqNo::new(header.seq_no);
        if seq.raw() <= start_after.raw() {
            continue;
        }
        // Detect gaps. The log is supposed to be dense; a gap means
        // either truncation (operational issue) or replay-on-bug.
        if prev_seq != start_after && seq.raw() != prev_seq.raw() + 1 {
            return Err(SequencerError::recovery(format!(
                "gap at seq {}; prev was {}",
                seq, prev_seq
            )));
        }
        let logged: LoggedCommand = bincode::deserialize(&payload).map_err(|e| {
            SequencerError::encoding(format!("decode at seq {}: {e}", header.seq_no))
        })?;

        let cmd = Command::new(
            seq,
            Timestamp::from_unix_nanos(logged.at_unix_nanos),
            logged.kind,
        );
        apply(cmd, logged.account_id)?;
        report.last_seq_replayed = seq;
        report.records_replayed += 1;
        prev_seq = seq;
    }

    Ok(report)
}

#[cfg(test)]
mod tests {
    use std::sync::Arc;

    use chrono::Utc;
    use meridian_order_types::{NewOrder, Side};
    use rust_decimal_macros::dec;
    use tempfile::tempdir;

    use crate::router::{RouteEntry, Router, ShardId};
    use crate::sequencer::{SequenceOutcome, Sequencer, SequencerConfig};

    use super::*;

    fn sym() -> Symbol {
        Symbol::new("BTC-USD").unwrap()
    }

    fn order(cid: u128) -> NewOrder {
        NewOrder::limit(
            AccountId::new(1),
            ClientOrderId::new(cid),
            sym(),
            Side::Buy,
            Price::from_decimal(dec!(100)),
            Quantity::from_int(1),
        )
    }

    fn router() -> Arc<Router> {
        let r = Arc::new(Router::new());
        r.upsert(
            sym(),
            RouteEntry {
                shard: ShardId::new(0),
                engine_addr: "127.0.0.1:7401".into(),
                healthy: true,
            },
        );
        r
    }

    #[test]
    fn replays_what_was_persisted() {
        let dir = tempdir().unwrap();
        let log_path = dir.path().join("seq.log");
        let cfg = SequencerConfig {
            log_path: log_path.clone(),
            ..Default::default()
        };
        let mut s = Sequencer::open(cfg, router()).unwrap();
        let now = Timestamp::from_datetime(Utc::now());
        for cid in 1..=3 {
            let r = s
                .sequence(CommandKind::NewOrder(order(cid)), AccountId::new(1), now)
                .unwrap();
            assert!(matches!(r, SequenceOutcome::Sequenced { .. }));
        }
        s.checkpoint().unwrap();
        drop(s);

        let mut replayed = 0;
        let report = recover_to(&log_path, SeqNo::ZERO, |_cmd, _acc| {
            replayed += 1;
            Ok(())
        })
        .unwrap();
        assert_eq!(report.records_replayed, 3);
        assert_eq!(replayed, 3);
        assert_eq!(report.last_seq_replayed.raw(), 3);
        assert!(report.gap_detected_at.is_none());
    }

    #[test]
    fn skips_records_at_or_below_start_after() {
        let dir = tempdir().unwrap();
        let log_path = dir.path().join("seq.log");
        let cfg = SequencerConfig {
            log_path: log_path.clone(),
            ..Default::default()
        };
        let mut s = Sequencer::open(cfg, router()).unwrap();
        let now = Timestamp::from_datetime(Utc::now());
        for cid in 1..=4 {
            s.sequence(CommandKind::NewOrder(order(cid)), AccountId::new(1), now)
                .unwrap();
        }
        s.checkpoint().unwrap();
        drop(s);

        // Skip first two; replay 3-4.
        let mut count = 0;
        let report = recover_to(&log_path, SeqNo::new(2), |_, _| {
            count += 1;
            Ok(())
        })
        .unwrap();
        assert_eq!(count, 2);
        assert_eq!(report.records_replayed, 2);
        assert_eq!(report.last_seq_replayed.raw(), 4);
    }
}
