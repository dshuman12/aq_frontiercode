//! Symbol → engine routing.
//!
//! The sequencer holds a routing table that maps each symbol to the
//! engine instance that owns its book. Engines are co-located by
//! shard, so the table is small (≤ a few hundred entries even on the
//! biggest production deployments).
//!
//! The table is rebuilt at the start of each session from `ref-data`,
//! and kept stable for the duration of the session — symbols don't
//! migrate between engines mid-day. If an engine fails, the entire
//! shard fails over via process supervisor; the sequencer doesn't
//! attempt fine-grained retry.

use std::collections::HashMap;
use std::sync::Arc;

use meridian_common::prelude::*;
use parking_lot::RwLock;

use crate::error::{SequencerError, SequencerResult};

/// Logical shard identifier — a partition of the symbol universe.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, serde::Serialize, serde::Deserialize)]
#[serde(transparent)]
#[repr(transparent)]
pub struct ShardId(pub u32);

impl ShardId {
    #[must_use]
    pub const fn new(n: u32) -> Self {
        Self(n)
    }
}

impl std::fmt::Display for ShardId {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "shard-{}", self.0)
    }
}

/// Direction of routing — symbol to (shard, engine_address).
#[derive(Debug, Clone)]
pub struct RouteEntry {
    pub shard: ShardId,
    pub engine_addr: String,
    pub healthy: bool,
}

#[derive(Debug, Default)]
pub struct Router {
    table: Arc<RwLock<HashMap<Symbol, RouteEntry>>>,
}

impl Router {
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    /// Add or replace a route for `symbol`.
    pub fn upsert(&self, symbol: Symbol, entry: RouteEntry) {
        let mut t = self.table.write();
        t.insert(symbol, entry);
    }

    /// Mark a shard's engines healthy or unhealthy in bulk.
    pub fn mark_shard(&self, shard: ShardId, healthy: bool) {
        let mut t = self.table.write();
        for entry in t.values_mut() {
            if entry.shard == shard {
                entry.healthy = healthy;
            }
        }
    }

    /// Resolve a symbol to its current route, returning an error if
    /// unknown or unhealthy.
    pub fn resolve(&self, symbol: &Symbol) -> SequencerResult<RouteEntry> {
        let t = self.table.read();
        match t.get(symbol) {
            None => Err(SequencerError::NoEngineForSymbol(symbol.to_string())),
            Some(entry) if !entry.healthy => Err(SequencerError::NoEngineForSymbol(format!(
                "{symbol} (engine unhealthy)"
            ))),
            Some(entry) => Ok(entry.clone()),
        }
    }

    /// Snapshot of the current table — for ops dashboards.
    #[must_use]
    pub fn snapshot(&self) -> Vec<(Symbol, RouteEntry)> {
        self.table
            .read()
            .iter()
            .map(|(s, r)| (s.clone(), r.clone()))
            .collect()
    }

    #[must_use]
    pub fn len(&self) -> usize {
        self.table.read().len()
    }

    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.table.read().is_empty()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn sym(s: &str) -> Symbol {
        Symbol::new(s).unwrap()
    }

    #[test]
    fn route_lookup() {
        let r = Router::new();
        r.upsert(
            sym("BTC-USD"),
            RouteEntry {
                shard: ShardId::new(0),
                engine_addr: "10.0.0.1:7401".into(),
                healthy: true,
            },
        );
        let entry = r.resolve(&sym("BTC-USD")).unwrap();
        assert_eq!(entry.shard, ShardId::new(0));
        assert!(matches!(
            r.resolve(&sym("ETH-USD")),
            Err(SequencerError::NoEngineForSymbol(_))
        ));
    }

    #[test]
    fn unhealthy_shard_blocks_routing() {
        let r = Router::new();
        r.upsert(
            sym("BTC-USD"),
            RouteEntry {
                shard: ShardId::new(0),
                engine_addr: "10.0.0.1:7401".into(),
                healthy: true,
            },
        );
        r.mark_shard(ShardId::new(0), false);
        assert!(r.resolve(&sym("BTC-USD")).is_err());
        r.mark_shard(ShardId::new(0), true);
        assert!(r.resolve(&sym("BTC-USD")).is_ok());
    }
}
