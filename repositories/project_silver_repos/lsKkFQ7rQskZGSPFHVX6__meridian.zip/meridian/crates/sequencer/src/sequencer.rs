//! `Sequencer` — assigns SeqNo, persists, dispatches.
//!
//! Single-writer. There is exactly one sequencer per shard; commands
//! arrive on a tokio mpsc channel from the gateway adapters and leave
//! on a per-engine mpsc channel.

use std::path::PathBuf;
use std::sync::Arc;

use meridian_common::prelude::*;
use meridian_matching::{Command, CommandKind};
use serde::{Deserialize, Serialize};

use crate::admit::{AdmissionDecision, AdmissionPolicy, Admit};
use crate::error::{SequencerError, SequencerResult};
use crate::log::{CommandLog, LogWriter};
use crate::router::Router;

#[derive(Debug, Clone)]
pub struct SequencerConfig {
    pub log_path: PathBuf,
    pub admission: AdmissionPolicy,
    pub batch_fsync_every: usize,
}

impl Default for SequencerConfig {
    fn default() -> Self {
        Self {
            log_path: PathBuf::from("/var/lib/meridian/sequencer.log"),
            admission: AdmissionPolicy::default(),
            batch_fsync_every: 32,
        }
    }
}

#[derive(Debug)]
pub struct Sequencer {
    cfg: SequencerConfig,
    log: CommandLog,
    seq: SeqAllocator,
    admit: Arc<Admit>,
    router: Arc<Router>,
    pending_since_fsync: usize,
}

/// Wire-format command record stored in the log. We can't serialise a
/// `Command` directly because the log also needs the submitting account.
#[derive(Debug, Clone, Serialize, Deserialize)]
struct LoggedCommand {
    seq_no: u64,
    at_unix_nanos: i64,
    kind: CommandKind,
    /// Account that submitted (for replay-time admit reconstruction).
    account_id: AccountId,
}

/// Result of a single sequence call.
#[derive(Debug, Clone, PartialEq, Eq)]
#[allow(clippy::large_enum_variant)]
pub enum SequenceOutcome {
    Sequenced { command: Command },
    Rejected { decision: AdmissionDecision },
}

impl Sequencer {
    pub fn open(cfg: SequencerConfig, router: Arc<Router>) -> SequencerResult<Self> {
        let log = CommandLog::open(&cfg.log_path)?;
        let admit = Arc::new(Admit::new(cfg.admission.clone()));
        Ok(Self {
            cfg,
            log,
            seq: SeqAllocator::new(1),
            admit,
            router,
            pending_since_fsync: 0,
        })
    }

    /// Construct a sequencer wired to an in-memory log (tests).
    pub fn open_with_log(
        cfg: SequencerConfig,
        log: CommandLog,
        router: Arc<Router>,
    ) -> SequencerResult<Self> {
        let admit = Arc::new(Admit::new(cfg.admission.clone()));
        Ok(Self {
            cfg,
            log,
            seq: SeqAllocator::new(1),
            admit,
            router,
            pending_since_fsync: 0,
        })
    }

    pub fn admit_handle(&self) -> Arc<Admit> {
        Arc::clone(&self.admit)
    }

    pub fn router(&self) -> Arc<Router> {
        Arc::clone(&self.router)
    }

    pub fn current_seq(&self) -> SeqNo {
        self.seq.peek()
    }

    /// Reset to a recovered position. Used after replaying snapshot
    /// + log into the engine on startup.
    pub fn reset_seq(&mut self, last_committed: SeqNo) {
        self.seq.reset_to(last_committed.next());
    }

    /// The hot path. Validates, allocates a seq, persists, returns the
    /// command for forwarding. The caller is responsible for handing
    /// it to the engine.
    pub fn sequence(
        &mut self,
        kind: CommandKind,
        account_id: AccountId,
        at: Timestamp,
    ) -> SequencerResult<SequenceOutcome> {
        // Admit.
        let admin = matches!(
            kind,
            CommandKind::SessionTransition(_)
                | CommandKind::SnapshotMark { .. }
                | CommandKind::KillSwitch { .. }
                | CommandKind::Tick
        );
        let decision = self.admit.admit(account_id, admin, at);
        if decision != AdmissionDecision::Accept {
            return Ok(SequenceOutcome::Rejected { decision });
        }

        // Symbol routing for order-entry commands.
        if let Some(sym) = symbol_of(&kind) {
            self.router.resolve(sym)?;
        }

        // Allocate seq.
        let seq_no = self.seq.next();

        let logged = LoggedCommand {
            seq_no: seq_no.raw(),
            at_unix_nanos: at.unix_nanos(),
            kind: kind.clone(),
            account_id,
        };
        let payload = bincode::serialize(&logged)
            .map_err(|e| SequencerError::encoding(format!("bincode: {e}")))?;
        self.log.append(seq_no, &payload)?;
        self.pending_since_fsync += 1;
        if self.pending_since_fsync >= self.cfg.batch_fsync_every {
            self.log.flush_sync()?;
            self.pending_since_fsync = 0;
        }

        Ok(SequenceOutcome::Sequenced {
            command: Command::new(seq_no, at, kind),
        })
    }

    /// Force a flush + fsync now.
    pub fn checkpoint(&mut self) -> SequencerResult<()> {
        self.log.flush_sync()?;
        self.pending_since_fsync = 0;
        Ok(())
    }

    /// Release admission inflight slot — called after the engine
    /// produces an event batch for this account's command.
    pub fn release_inflight(&self, account: AccountId) {
        self.admit.release_inflight(account);
    }

    /// On-disk position — useful for metrics.
    pub fn log_position(&self) -> u64 {
        self.log.position()
    }
}

/// Helper — extract the symbol for an order-entry command if any.
fn symbol_of(k: &CommandKind) -> Option<&Symbol> {
    match k {
        CommandKind::NewOrder(o) => Some(&o.symbol),
        CommandKind::Cancel(c) => Some(&c.symbol),
        CommandKind::Amend(a) => Some(&a.symbol),
        CommandKind::CancelReplace { new_order, .. } => Some(&new_order.symbol),
        _ => None,
    }
}

#[cfg(test)]
mod tests {
    use chrono::Utc;
    use meridian_order_types::{NewOrder, Side};
    use rust_decimal_macros::dec;
    use tempfile::tempdir;

    use crate::router::{RouteEntry, ShardId};

    use super::*;

    fn sym() -> Symbol {
        Symbol::new("BTC-USD").unwrap()
    }

    fn seq_with_router() -> (Sequencer, tempfile::TempDir) {
        let dir = tempdir().unwrap();
        let log_path = dir.path().join("seq.log");
        let cfg = SequencerConfig {
            log_path: log_path.clone(),
            admission: AdmissionPolicy::default(),
            batch_fsync_every: 1,
        };
        let router = Arc::new(Router::new());
        router.upsert(
            sym(),
            RouteEntry {
                shard: ShardId::new(0),
                engine_addr: "127.0.0.1:7401".into(),
                healthy: true,
            },
        );
        let s = Sequencer::open(cfg, router).unwrap();
        (s, dir)
    }

    #[test]
    fn sequence_assigns_monotonic() {
        let (mut s, _dir) = seq_with_router();
        let now = Timestamp::from_datetime(Utc::now());
        let new = NewOrder::limit(
            AccountId::new(1),
            ClientOrderId::new(1),
            sym(),
            Side::Buy,
            Price::from_decimal(dec!(100)),
            Quantity::from_int(1),
        );
        let r1 = s
            .sequence(CommandKind::NewOrder(new.clone()), AccountId::new(1), now)
            .unwrap();
        let r2 = s
            .sequence(CommandKind::NewOrder(new), AccountId::new(1), now)
            .unwrap();
        if let (
            SequenceOutcome::Sequenced { command: c1 },
            SequenceOutcome::Sequenced { command: c2 },
        ) = (r1, r2)
        {
            assert!(c2.seq_no > c1.seq_no);
        } else {
            panic!("expected sequenced");
        }
    }

    #[test]
    fn unknown_symbol_is_routing_error() {
        let dir = tempdir().unwrap();
        let log_path = dir.path().join("seq.log");
        let cfg = SequencerConfig {
            log_path,
            admission: AdmissionPolicy::default(),
            batch_fsync_every: 1,
        };
        let router = Arc::new(Router::new()); // empty
        let mut s = Sequencer::open(cfg, router).unwrap();
        let now = Timestamp::from_datetime(Utc::now());
        let new = NewOrder::limit(
            AccountId::new(1),
            ClientOrderId::new(1),
            Symbol::new("ETH-USD").unwrap(),
            Side::Buy,
            Price::from_decimal(dec!(100)),
            Quantity::from_int(1),
        );
        let r = s.sequence(CommandKind::NewOrder(new), AccountId::new(1), now);
        assert!(matches!(r, Err(SequencerError::NoEngineForSymbol(_))));
    }
}
