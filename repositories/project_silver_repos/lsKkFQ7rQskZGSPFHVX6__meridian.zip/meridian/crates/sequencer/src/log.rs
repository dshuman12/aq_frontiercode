//! Append-only command log.
//!
//! On-disk format is a sequence of records:
//!
//! ```text
//!   [magic:4 = 0x4D44_5251]
//!   [version:2 = 1]
//!   [reserved:2 = 0]
//!   --- file header above; record stream below ---
//!   per record:
//!     [length:4][seq_no:8][crc32c:4][payload]
//! ```
//!
//! The file header is written exactly once. The record header has the
//! seq_no inline so the recovery scanner can index quickly without
//! decoding payloads. CRC32 covers the payload only — we trust the
//! filesystem for length / seq_no integrity, and a corrupt header
//! throws off framing in a way the scanner can detect anyway.
//!
//! Records are written with `O_APPEND` and `fsync`'d at the end of
//! each batch. `fsync` per-record is too slow; per-batch hits a
//! reasonable durability/latency tradeoff (≤500µs RTT including
//! fsync on a typical NVMe).

use std::fs::{File, OpenOptions};
use std::io::{BufReader, BufWriter, Read, Seek, SeekFrom, Write};
use std::path::{Path, PathBuf};

use crc32fast::Hasher as Crc32;
use meridian_common::prelude::*;
use serde::{Deserialize, Serialize};

use crate::error::{SequencerError, SequencerResult};

/// Magic bytes for the file header — "MDRQ" in ASCII (Meridian D... ah,
/// the more important property is that it's distinct from common
/// formats so corruption is easier to spot).
pub const FILE_MAGIC: u32 = 0x4D44_5251;
pub const FILE_VERSION: u16 = 1;

const FILE_HEADER_LEN: usize = 8;
const RECORD_HEADER_LEN: usize = 16;

/// Per-record header. `length` is the size of the *payload* only.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct RecordHeader {
    pub length: u32,
    pub seq_no: u64,
    pub crc32: u32,
}

impl RecordHeader {
    fn write<W: Write>(&self, w: &mut W) -> SequencerResult<()> {
        w.write_all(&self.length.to_le_bytes())?;
        w.write_all(&self.seq_no.to_le_bytes())?;
        w.write_all(&self.crc32.to_le_bytes())?;
        Ok(())
    }

    fn read<R: Read>(r: &mut R) -> SequencerResult<Self> {
        let mut buf = [0u8; RECORD_HEADER_LEN];
        r.read_exact(&mut buf)?;
        let length = u32::from_le_bytes(buf[0..4].try_into().expect("4 bytes"));
        let seq_no = u64::from_le_bytes(buf[4..12].try_into().expect("8 bytes"));
        let crc32 = u32::from_le_bytes(buf[12..16].try_into().expect("4 bytes"));
        Ok(Self {
            length,
            seq_no,
            crc32,
        })
    }
}

/// Trait alias for the writer side. Production writes to a file; tests
/// can write to an in-memory buffer.
pub trait LogWriter: Send {
    fn append(&mut self, seq_no: SeqNo, payload: &[u8]) -> SequencerResult<()>;
    /// Force durability. Should be called once per batch.
    fn flush_sync(&mut self) -> SequencerResult<()>;
    /// Current write offset (for metrics).
    fn position(&self) -> u64;
}

/// Trait alias for the reader side. Recovery uses this to replay.
pub trait LogReader: Send {
    fn read_next(&mut self) -> SequencerResult<Option<(RecordHeader, Vec<u8>)>>;
}

/// File-backed log.
#[derive(Debug)]
pub struct CommandLog {
    path: PathBuf,
    writer: BufWriter<File>,
    write_pos: u64,
}

impl CommandLog {
    /// Open or create the log file at `path`.
    pub fn open(path: impl AsRef<Path>) -> SequencerResult<Self> {
        let path = path.as_ref().to_path_buf();
        let exists = path.exists();
        let file = OpenOptions::new()
            .create(true)
            .read(true)
            .write(true)
            .truncate(false)
            .open(&path)?;
        let mut writer = BufWriter::new(file);
        let write_pos = if !exists {
            // Write file header.
            writer.write_all(&FILE_MAGIC.to_le_bytes())?;
            writer.write_all(&FILE_VERSION.to_le_bytes())?;
            writer.write_all(&[0u8, 0u8])?;
            writer.flush()?;
            FILE_HEADER_LEN as u64
        } else {
            // Validate header + seek to end.
            let mut hdr_buf = [0u8; FILE_HEADER_LEN];
            let mut f = writer.get_mut().try_clone()?;
            f.seek(SeekFrom::Start(0))?;
            f.read_exact(&mut hdr_buf)?;
            let magic = u32::from_le_bytes(hdr_buf[0..4].try_into().expect("4"));
            if magic != FILE_MAGIC {
                return Err(SequencerError::LogHeaderMismatch {
                    expected: FILE_MAGIC,
                    actual: magic,
                });
            }
            writer.get_mut().seek(SeekFrom::End(0))?
        };
        Ok(Self {
            path,
            writer,
            write_pos,
        })
    }

    /// Open a fresh reader pointing at the start of the record stream
    /// (just after the file header). Independent of the writer's
    /// state; safe to call concurrently with appends because we only
    /// read up to whatever was flushed.
    pub fn reader(&self) -> SequencerResult<FileLogReader> {
        let mut f = File::open(&self.path)?;
        f.seek(SeekFrom::Start(FILE_HEADER_LEN as u64))?;
        Ok(FileLogReader {
            inner: BufReader::new(f),
            offset: FILE_HEADER_LEN as u64,
        })
    }
}

impl LogWriter for CommandLog {
    fn append(&mut self, seq_no: SeqNo, payload: &[u8]) -> SequencerResult<()> {
        let mut crc = Crc32::new();
        crc.update(payload);
        let header = RecordHeader {
            length: u32::try_from(payload.len())
                .map_err(|_| SequencerError::encoding("payload too large to encode in u32"))?,
            seq_no: seq_no.raw(),
            crc32: crc.finalize(),
        };
        header.write(&mut self.writer)?;
        self.writer.write_all(payload)?;
        self.write_pos += (RECORD_HEADER_LEN + payload.len()) as u64;
        Ok(())
    }

    fn flush_sync(&mut self) -> SequencerResult<()> {
        self.writer.flush()?;
        self.writer.get_mut().sync_data()?;
        Ok(())
    }

    fn position(&self) -> u64 {
        self.write_pos
    }
}

/// File-backed reader returned by `CommandLog::reader`.
#[derive(Debug)]
pub struct FileLogReader {
    inner: BufReader<File>,
    offset: u64,
}

impl LogReader for FileLogReader {
    fn read_next(&mut self) -> SequencerResult<Option<(RecordHeader, Vec<u8>)>> {
        let header = match RecordHeader::read(&mut self.inner) {
            Ok(h) => h,
            Err(SequencerError::LogIo(e)) if e.kind() == std::io::ErrorKind::UnexpectedEof => {
                return Ok(None);
            },
            Err(e) => return Err(e),
        };
        let len = header.length as usize;
        let mut payload = vec![0u8; len];
        self.inner.read_exact(&mut payload).map_err(|e| {
            if e.kind() == std::io::ErrorKind::UnexpectedEof {
                SequencerError::LogCorrupt {
                    offset: self.offset,
                    msg: "truncated payload".into(),
                }
            } else {
                SequencerError::from(e)
            }
        })?;
        let mut crc = Crc32::new();
        crc.update(&payload);
        if crc.finalize() != header.crc32 {
            return Err(SequencerError::ChecksumMismatch {
                offset: self.offset,
            });
        }
        self.offset += (RECORD_HEADER_LEN + len) as u64;
        Ok(Some((header, payload)))
    }
}

#[cfg(test)]
mod tests {
    use tempfile::tempdir;

    use super::*;

    #[test]
    fn roundtrip_three_records() {
        let dir = tempdir().unwrap();
        let path = dir.path().join("log.bin");
        let mut w = CommandLog::open(&path).unwrap();
        for i in 1..=3 {
            let payload = format!("payload-{i}");
            w.append(SeqNo::new(i), payload.as_bytes()).unwrap();
        }
        w.flush_sync().unwrap();
        drop(w);

        let log = CommandLog::open(&path).unwrap();
        let mut reader = log.reader().unwrap();
        let mut got = Vec::new();
        while let Some((hdr, data)) = reader.read_next().unwrap() {
            got.push((hdr.seq_no, String::from_utf8(data).unwrap()));
        }
        assert_eq!(
            got,
            vec![
                (1, "payload-1".to_string()),
                (2, "payload-2".to_string()),
                (3, "payload-3".to_string()),
            ]
        );
    }

    #[test]
    fn header_validated_on_reopen() {
        let dir = tempdir().unwrap();
        let path = dir.path().join("log.bin");
        // Write a garbage file with no header.
        std::fs::write(&path, b"\x00\x01\x02\x03\x04\x05\x06\x07garbage").unwrap();
        let r = CommandLog::open(&path);
        assert!(matches!(r, Err(SequencerError::LogHeaderMismatch { .. })));
    }
}
