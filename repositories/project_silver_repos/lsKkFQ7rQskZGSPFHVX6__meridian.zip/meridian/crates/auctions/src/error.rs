//! Auction errors.

use thiserror::Error;

pub type AuctionResult<T> = Result<T, AuctionError>;

#[derive(Debug, Error)]
pub enum AuctionError {
    #[error("no overlap — book has no candidate prices")]
    NoCandidatePrices,
    #[error("invariant violated: {0}")]
    Invariant(String),
}
