// Auctions — single-price-cross calculation.
//
// We run an auction at session boundaries (opening, closing) and
// after volatility halts. The algorithm is the standard "maximum
// matched volume → minimum imbalance → best reference price"
// tie-break, as used by Eurex, NYSE, and the major crypto venues.
//
// # Algorithm (per Eurex docs):
//
// 1. For each candidate price (every ask price + every bid price),
//    compute the executable volume — the lesser of cumulative
//    bid qty at-or-above the price and cumulative ask qty
//    at-or-below.
// 2. Pick the price(s) with the highest executable volume.
// 3. If multiple, pick the price(s) with the smallest residual
//    imbalance (|bid_at - ask_at|).
// 4. If still multiple, the rules differ per venue: midpoint is the
//    standard. We use midpoint of the surviving candidates.
//
// The `cross` function is pure — book in, plan out. The matching
// engine takes the plan and applies it.

#![forbid(unsafe_code)]
#![deny(rust_2018_idioms)]
#![allow(
    clippy::pedantic,
    clippy::nursery,
    missing_debug_implementations,
    missing_docs
)]
#![allow(
    clippy::module_name_repetitions,
    clippy::missing_errors_doc,
    clippy::missing_panics_doc,
    clippy::must_use_candidate
)]

//! Auction crate.

pub mod cross;
pub mod error;
pub mod plan;

pub use cross::{cross, CrossInputs};
pub use error::{AuctionError, AuctionResult};
pub use plan::{AuctionPlan, AuctionStats};
