//! `AuctionPlan` — the result of a cross calculation.

use meridian_common::prelude::*;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct AuctionPlan {
    pub auction_id: AuctionId,
    pub symbol: Symbol,
    pub cross_price: Price,
    pub crossed_qty: Quantity,
    pub stats: AuctionStats,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct AuctionStats {
    /// Total bid qty at-or-above the cross price.
    pub bid_at: Quantity,
    /// Total ask qty at-or-below the cross price.
    pub ask_at: Quantity,
    /// |bid_at - ask_at| at the cross price.
    pub imbalance: Quantity,
    /// True if the cross price was uniquely determined by max-volume
    /// alone (no tie-break needed).
    pub max_volume_unique: bool,
}
