//! Single-price cross algorithm.

use std::collections::BTreeMap;

use meridian_common::prelude::*;
use meridian_order_book::Book;
use meridian_order_types::Side;
use rust_decimal::Decimal;

use crate::error::{AuctionError, AuctionResult};
use crate::plan::{AuctionPlan, AuctionStats};

#[derive(Debug, Clone)]
pub struct CrossInputs<'a> {
    pub book: &'a Book,
    pub auction_id: AuctionId,
    pub symbol: Symbol,
}

/// Compute the auction plan for the current book.
pub fn cross(input: &CrossInputs<'_>) -> AuctionResult<AuctionPlan> {
    // Aggregate bid/ask qty per price.
    let mut bids: BTreeMap<Price, Quantity> = BTreeMap::new();
    let mut asks: BTreeMap<Price, Quantity> = BTreeMap::new();
    for lvl in input.book.iter_side(Side::Buy) {
        bids.insert(lvl.price, lvl.total_qty());
    }
    for lvl in input.book.iter_side(Side::Sell) {
        asks.insert(lvl.price, lvl.total_qty());
    }
    if bids.is_empty() || asks.is_empty() {
        return Err(AuctionError::NoCandidatePrices);
    }

    let mut candidates: Vec<Price> = bids.keys().chain(asks.keys()).copied().collect();
    candidates.sort();
    candidates.dedup();

    let mut best_volume = Quantity::ZERO;
    let mut best_set: Vec<(Price, Quantity, Quantity)> = Vec::new();

    for &p in &candidates {
        // Cumulative bid at or above p.
        let mut bid_at = Quantity::ZERO;
        for (&bp, &bq) in &bids {
            if bp >= p {
                bid_at += bq;
            }
        }
        let mut ask_at = Quantity::ZERO;
        for (&ap, &aq) in &asks {
            if ap <= p {
                ask_at += aq;
            }
        }
        let executable = bid_at.min(ask_at);
        if executable > best_volume {
            best_volume = executable;
            best_set.clear();
            best_set.push((p, bid_at, ask_at));
        } else if executable == best_volume && !best_volume.is_zero() {
            best_set.push((p, bid_at, ask_at));
        }
    }

    if best_volume.is_zero() {
        return Err(AuctionError::NoCandidatePrices);
    }

    let unique = best_set.len() == 1;

    // Tie-break 1: smallest absolute imbalance.
    let min_imbalance = best_set
        .iter()
        .map(|(_, b, a)| if b > a { *b - *a } else { *a - *b })
        .min()
        .expect("non-empty");

    let lowest: Vec<&(Price, Quantity, Quantity)> = best_set
        .iter()
        .filter(|(_, b, a)| {
            let imb = if b > a { *b - *a } else { *a - *b };
            imb == min_imbalance
        })
        .collect();

    // Tie-break 2: midpoint of surviving candidates (rounded toward
    // the bid side as a venue convention; arbitrary but deterministic).
    let cross_price = if lowest.len() == 1 {
        lowest[0].0
    } else {
        let sum: Decimal = lowest.iter().map(|(p, _, _)| p.into_decimal()).sum();
        let avg = sum / Decimal::from(lowest.len());
        Price::from_decimal(avg)
    };

    // Recompute stats at the chosen cross price.
    let mut bid_at = Quantity::ZERO;
    for (&bp, &bq) in &bids {
        if bp >= cross_price {
            bid_at += bq;
        }
    }
    let mut ask_at = Quantity::ZERO;
    for (&ap, &aq) in &asks {
        if ap <= cross_price {
            ask_at += aq;
        }
    }
    let imbalance = if bid_at > ask_at {
        bid_at - ask_at
    } else {
        ask_at - bid_at
    };
    let crossed_qty = bid_at.min(ask_at);

    Ok(AuctionPlan {
        auction_id: input.auction_id,
        symbol: input.symbol.clone(),
        cross_price,
        crossed_qty,
        stats: AuctionStats {
            bid_at,
            ask_at,
            imbalance,
            max_volume_unique: unique,
        },
    })
}

#[cfg(test)]
mod tests {
    use meridian_order_book::RestingOrder;
    use meridian_order_types::OrderType;
    use rust_decimal_macros::dec;

    use super::*;

    fn sym() -> Symbol {
        Symbol::new("BTC-USD").unwrap()
    }

    fn ord(id: u128, side: Side, price: Price, qty: i64, seq: u64) -> RestingOrder {
        RestingOrder {
            order_id: OrderId::new(id),
            account_id: AccountId::new(1),
            side,
            order_type: OrderType::Limit,
            leaves_qty: Quantity::from_int(qty),
            display_qty: None,
            hidden_qty: None,
            price,
            priority_seq: SeqNo::new(seq),
            post_only: false,
        }
    }

    #[test]
    fn classic_cross_picks_volume_max() {
        let mut b = Book::new(sym());
        b.insert(ord(1, Side::Buy, Price::from_decimal(dec!(99)), 10, 1));
        b.insert(ord(2, Side::Buy, Price::from_decimal(dec!(100)), 20, 2));
        b.insert(ord(3, Side::Sell, Price::from_decimal(dec!(100)), 15, 3));
        b.insert(ord(4, Side::Sell, Price::from_decimal(dec!(101)), 10, 4));

        let plan = cross(&CrossInputs {
            book: &b,
            auction_id: AuctionId::new(1),
            symbol: sym(),
        })
        .unwrap();
        assert_eq!(plan.cross_price, Price::from_decimal(dec!(100)));
        assert_eq!(plan.crossed_qty, Quantity::from_int(15));
    }

    #[test]
    fn no_overlap_errors() {
        let mut b = Book::new(sym());
        b.insert(ord(1, Side::Buy, Price::from_decimal(dec!(99)), 10, 1));
        b.insert(ord(2, Side::Sell, Price::from_decimal(dec!(101)), 10, 2));
        let r = cross(&CrossInputs {
            book: &b,
            auction_id: AuctionId::new(1),
            symbol: sym(),
        });
        // No overlap — best executable volume is 0 → error.
        assert!(matches!(r, Err(AuctionError::NoCandidatePrices)));
    }
}
