// Reference data — the slow-moving facts about the world.
//
// Symbols, accounts, fee schedules, holiday calendars, settlement
// periods. This crate is read-mostly: things change rarely, and when
// they do, the change goes out via a versioned snapshot that other
// services pull on a cadence (every 5s in production).
//
// We keep ref-data deliberately small. Pricing rules, margin models,
// risk limits — those are *parameters* of ref-data records, not
// separate services. The risk engine and clearing service look up
// rules here; they don't define them.

#![forbid(unsafe_code)]
#![deny(rust_2018_idioms)]
#![allow(
    clippy::pedantic,
    clippy::nursery,
    missing_debug_implementations,
    missing_docs
)]
#![allow(
    clippy::module_name_repetitions,
    clippy::missing_errors_doc,
    clippy::missing_panics_doc,
    clippy::must_use_candidate
)]

//! Reference data store.

pub mod account;
pub mod calendar;
pub mod error;
pub mod fee;
pub mod instrument;
pub mod store;

pub use account::{Account, AccountTier};
pub use calendar::{Calendar, SessionWindows};
pub use error::{RefDataError, RefDataResult};
pub use fee::{FeeSchedule, FeeTier};
pub use instrument::{Instrument, InstrumentClass, SettlementPeriod};
pub use store::RefDataStore;
