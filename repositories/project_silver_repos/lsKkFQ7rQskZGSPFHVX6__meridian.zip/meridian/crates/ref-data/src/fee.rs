//! Fee schedules.
//!
//! A schedule is a set of tiers indexed by 30-day rolling volume.
//! Each tier specifies maker / taker bps. Negative bps = rebate.

use meridian_common::prelude::*;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct FeeTier {
    /// Inclusive lower bound of the tier, in 30d notional.
    pub min_30d_notional: Notional,
    pub maker_bps: Bps,
    pub taker_bps: Bps,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FeeSchedule {
    pub id: String,
    pub display_name: String,
    /// Tiers in ascending `min_30d_notional` order. The lookup function
    /// expects this invariant.
    pub tiers: Vec<FeeTier>,
}

impl FeeSchedule {
    /// Pick the right tier for a given 30d volume.
    ///
    /// Falls back to the lowest tier (`tiers[0]`) for volume below the
    /// first cutoff. Returns `None` only if `tiers` is empty (which
    /// shouldn't happen — validate at load time).
    #[must_use]
    pub fn tier_for(&self, volume_30d: Notional) -> Option<&FeeTier> {
        let mut best: Option<&FeeTier> = self.tiers.first();
        for t in &self.tiers {
            if volume_30d >= t.min_30d_notional {
                best = Some(t);
            } else {
                break;
            }
        }
        best
    }

    /// Compute the fee for a fill.
    #[must_use]
    pub fn fee_for(&self, volume_30d: Notional, notional: Notional, is_maker: bool) -> Fee {
        let tier = self.tier_for(volume_30d).expect("non-empty schedule");
        if is_maker {
            tier.maker_bps.apply(notional)
        } else {
            tier.taker_bps.apply(notional)
        }
    }
}

#[cfg(test)]
mod tests {
    use rust_decimal_macros::dec;

    use super::*;

    fn schedule() -> FeeSchedule {
        FeeSchedule {
            id: "default".into(),
            display_name: "Default".into(),
            tiers: vec![
                FeeTier {
                    min_30d_notional: Notional::ZERO,
                    maker_bps: Bps::new(10),
                    taker_bps: Bps::new(20),
                },
                FeeTier {
                    min_30d_notional: Notional::from_decimal(dec!(1_000_000)),
                    maker_bps: Bps::new(2),
                    taker_bps: Bps::new(8),
                },
                FeeTier {
                    min_30d_notional: Notional::from_decimal(dec!(50_000_000)),
                    maker_bps: Bps::new(-1),
                    taker_bps: Bps::new(4),
                },
            ],
        }
    }

    #[test]
    fn tier_lookup_picks_highest_eligible() {
        let s = schedule();
        assert_eq!(
            s.tier_for(Notional::from_decimal(dec!(500_000)))
                .unwrap()
                .maker_bps,
            Bps::new(10)
        );
        assert_eq!(
            s.tier_for(Notional::from_decimal(dec!(2_000_000)))
                .unwrap()
                .maker_bps,
            Bps::new(2)
        );
        assert_eq!(
            s.tier_for(Notional::from_decimal(dec!(100_000_000)))
                .unwrap()
                .maker_bps,
            Bps::new(-1)
        );
    }

    #[test]
    fn fee_for_maker_can_be_rebate() {
        let s = schedule();
        let fee = s.fee_for(
            Notional::from_decimal(dec!(100_000_000)),
            Notional::from_decimal(dec!(10_000)),
            true,
        );
        assert!(fee.is_negative());
    }
}
