//! In-memory ref-data store.
//!
//! Production wires this to PostgreSQL behind a 5s refresh loop;
//! tests and small deployments load from YAML at boot.

use std::collections::HashMap;
use std::path::Path;

use meridian_common::prelude::*;
use parking_lot::RwLock;
use serde::Deserialize;

use crate::account::Account;
use crate::calendar::Calendar;
use crate::error::{RefDataError, RefDataResult};
use crate::fee::FeeSchedule;
use crate::instrument::Instrument;

#[derive(Debug, Default)]
pub struct RefDataStore {
    instruments: RwLock<HashMap<Symbol, Instrument>>,
    accounts: RwLock<HashMap<AccountId, Account>>,
    calendars: RwLock<HashMap<String, Calendar>>,
    fee_schedules: RwLock<HashMap<String, FeeSchedule>>,
    /// Monotonic version. Bumped on every write so consumers can
    /// cheaply detect a refresh.
    version: RwLock<u64>,
}

#[derive(Debug, Deserialize)]
struct YamlBundle {
    #[serde(default)]
    instruments: Vec<Instrument>,
    #[serde(default)]
    accounts: Vec<Account>,
    #[serde(default)]
    calendars: Vec<Calendar>,
    #[serde(default)]
    fee_schedules: Vec<FeeSchedule>,
}

impl RefDataStore {
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    pub fn load_yaml(&self, path: impl AsRef<Path>) -> RefDataResult<u64> {
        let raw = std::fs::read_to_string(path).map_err(|e| {
            RefDataError::Common(meridian_common::Error::invalid_argument(format!(
                "ref-data yaml: {e}"
            )))
        })?;
        let bundle: YamlBundle = serde_yaml::from_str(&raw).map_err(|e| {
            RefDataError::Common(meridian_common::Error::invalid_argument(format!(
                "yaml parse: {e}"
            )))
        })?;
        let mut version = self.version.write();
        *version += 1;
        let v = *version;

        {
            let mut m = self.instruments.write();
            m.clear();
            for i in bundle.instruments {
                m.insert(i.symbol.clone(), i);
            }
        }
        {
            let mut m = self.accounts.write();
            m.clear();
            for a in bundle.accounts {
                m.insert(a.id, a);
            }
        }
        {
            let mut m = self.calendars.write();
            m.clear();
            for c in bundle.calendars {
                m.insert(c.id.clone(), c);
            }
        }
        {
            let mut m = self.fee_schedules.write();
            m.clear();
            for f in bundle.fee_schedules {
                m.insert(f.id.clone(), f);
            }
        }
        Ok(v)
    }

    pub fn upsert_instrument(&self, i: Instrument) {
        self.instruments.write().insert(i.symbol.clone(), i);
        *self.version.write() += 1;
    }

    pub fn upsert_account(&self, a: Account) {
        self.accounts.write().insert(a.id, a);
        *self.version.write() += 1;
    }

    pub fn upsert_calendar(&self, c: Calendar) {
        self.calendars.write().insert(c.id.clone(), c);
        *self.version.write() += 1;
    }

    pub fn upsert_fee_schedule(&self, f: FeeSchedule) {
        self.fee_schedules.write().insert(f.id.clone(), f);
        *self.version.write() += 1;
    }

    pub fn instrument(&self, sym: &Symbol) -> RefDataResult<Instrument> {
        self.instruments
            .read()
            .get(sym)
            .cloned()
            .ok_or_else(|| RefDataError::UnknownInstrument(sym.to_string()))
    }

    pub fn account(&self, id: AccountId) -> RefDataResult<Account> {
        self.accounts
            .read()
            .get(&id)
            .cloned()
            .ok_or_else(|| RefDataError::UnknownAccount(id.to_string()))
    }

    pub fn calendar(&self, id: &str) -> RefDataResult<Calendar> {
        self.calendars
            .read()
            .get(id)
            .cloned()
            .ok_or_else(|| RefDataError::UnknownCalendar(id.to_string()))
    }

    pub fn fee_schedule(&self, id: &str) -> RefDataResult<FeeSchedule> {
        self.fee_schedules
            .read()
            .get(id)
            .cloned()
            .ok_or_else(|| RefDataError::UnknownFeeSchedule(id.to_string()))
    }

    /// Current version — useful for cache invalidation in clients.
    #[must_use]
    pub fn version(&self) -> u64 {
        *self.version.read()
    }
}
