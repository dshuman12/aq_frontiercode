//! Trading calendars and session windows.
//!
//! Crypto: 24/7 with brief auctions per day for opening / closing
//! marks (used by index providers and settlement). The calendar
//! captures the exact times in a tz-aware way.

use chrono::{DateTime, NaiveDate, NaiveTime, Utc};
use chrono_tz::Tz;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct SessionWindows {
    pub pre_open: NaiveTime,
    pub opening_auction: NaiveTime,
    pub continuous_open: NaiveTime,
    pub closing_auction: NaiveTime,
    pub post_close: NaiveTime,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Calendar {
    pub id: String,
    pub display_name: String,
    pub timezone: String,
    pub windows: SessionWindows,
    pub holidays: Vec<NaiveDate>,
}

impl Calendar {
    /// Resolve the timezone to a `chrono_tz::Tz`. Errors for an
    /// unknown identifier — caller should validate at load time.
    pub fn tz(&self) -> Option<Tz> {
        self.timezone.parse().ok()
    }

    /// True if `date` is a holiday in this calendar.
    #[must_use]
    pub fn is_holiday(&self, date: NaiveDate) -> bool {
        self.holidays.binary_search(&date).is_ok()
    }

    /// Compute the UTC instant of the opening auction on `date`.
    #[must_use]
    pub fn opening_auction_utc(&self, date: NaiveDate) -> Option<DateTime<Utc>> {
        let tz = self.tz()?;
        let local = date.and_time(self.windows.opening_auction);
        let res = tz.from_local_datetime(&local);
        match res {
            chrono::offset::LocalResult::Single(t) => Some(t.with_timezone(&Utc)),
            chrono::offset::LocalResult::Ambiguous(t1, _) => Some(t1.with_timezone(&Utc)),
            chrono::offset::LocalResult::None => None,
        }
    }
}

// chrono::TimeZone trait is required for from_local_datetime.
use chrono::TimeZone;

#[cfg(test)]
mod tests {
    use super::*;

    fn cal() -> Calendar {
        Calendar {
            id: "crypto-24x7".into(),
            display_name: "Crypto 24x7".into(),
            timezone: "UTC".into(),
            windows: SessionWindows {
                pre_open: NaiveTime::from_hms_opt(0, 0, 0).unwrap(),
                opening_auction: NaiveTime::from_hms_opt(0, 1, 0).unwrap(),
                continuous_open: NaiveTime::from_hms_opt(0, 2, 0).unwrap(),
                closing_auction: NaiveTime::from_hms_opt(23, 59, 0).unwrap(),
                post_close: NaiveTime::from_hms_opt(23, 59, 30).unwrap(),
            },
            holidays: vec![],
        }
    }

    #[test]
    fn opening_auction_utc_resolves() {
        let c = cal();
        let day = NaiveDate::from_ymd_opt(2025, 6, 13).unwrap();
        let t = c.opening_auction_utc(day).unwrap();
        assert_eq!(
            t.format("%Y-%m-%dT%H:%M:%SZ").to_string(),
            "2025-06-13T00:01:00Z"
        );
    }

    #[test]
    fn holiday_lookup() {
        let mut c = cal();
        c.holidays
            .push(NaiveDate::from_ymd_opt(2025, 12, 25).unwrap());
        assert!(c.is_holiday(NaiveDate::from_ymd_opt(2025, 12, 25).unwrap()));
        assert!(!c.is_holiday(NaiveDate::from_ymd_opt(2025, 6, 13).unwrap()));
    }
}
