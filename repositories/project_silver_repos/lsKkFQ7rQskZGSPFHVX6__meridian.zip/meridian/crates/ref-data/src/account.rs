//! Account profile records.

use meridian_common::prelude::*;
use meridian_order_types::SelfTradePrevention;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum AccountTier {
    /// Retail. Standard fees, conservative caps.
    Retail,
    /// Pro. Lower fees once volume threshold met.
    Pro,
    /// Institutional. Negotiated fee schedule, higher caps, FIX session.
    Institutional,
    /// Market-maker. Rebate-eligible, post-only friendly, sub-ms latency SLA.
    MarketMaker,
    /// Internal-only — used for borrowing books, liquidations, etc.
    Internal,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Account {
    pub id: AccountId,
    pub display_name: String,
    pub tier: AccountTier,
    pub fee_schedule_id: String,
    pub default_stp: SelfTradePrevention,
    pub created_at: Timestamp,
    /// Suspended accounts can still cancel; new orders are refused.
    pub suspended: bool,
    /// Reserved for hedging / clearing-only relationships.
    pub omnibus: bool,
    /// Compliance flags. Loose JSON to avoid pinning the schema in
    /// code; the compliance service validates against its own model.
    pub compliance: serde_json::Value,
}

impl Account {
    /// True if the account can submit non-cancel commands.
    #[must_use]
    pub const fn can_trade(&self) -> bool {
        !self.suspended
    }
}
