//! Ref-data errors.

use meridian_common::Error as CommonError;
use thiserror::Error;

pub type RefDataResult<T> = Result<T, RefDataError>;

#[derive(Debug, Error)]
pub enum RefDataError {
    #[error("instrument {0} not found")]
    UnknownInstrument(String),

    #[error("account {0} not found")]
    UnknownAccount(String),

    #[error("calendar {0} not found")]
    UnknownCalendar(String),

    #[error("fee schedule {0} not found")]
    UnknownFeeSchedule(String),

    #[error("inconsistent: {0}")]
    Inconsistent(String),

    #[error(transparent)]
    Common(#[from] CommonError),
}
