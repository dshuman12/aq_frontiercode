//! Instrument records.

use meridian_common::prelude::*;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum InstrumentClass {
    /// Crypto spot — settles instantly.
    SpotCrypto,
    /// Linear perpetual — funded; settles in quote.
    LinearPerp,
    /// Inverse perpetual — funded; settles in base.
    InversePerp,
    /// Dated future.
    Future,
    /// Equity (here for future expansion; not currently supported).
    Equity,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum SettlementPeriod {
    /// Trade-date settlement (T+0). Crypto spot.
    T0,
    /// T+1, e.g. US Treasuries.
    T1,
    /// T+2 — common equities outside the US.
    T2,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Instrument {
    pub symbol: Symbol,
    pub class: InstrumentClass,
    pub tick_size: TickSize,
    pub lot_size: LotSize,
    pub min_order_qty: Quantity,
    pub max_order_qty: Quantity,
    pub price_precision: u8,
    pub qty_precision: u8,
    pub fee_schedule_id: String,
    pub calendar_id: String,
    pub settlement: SettlementPeriod,
    pub active: bool,
    /// Whether the venue lists this symbol — orders may still be open
    /// during de-listing for window-down purposes.
    pub listed: bool,
    /// First listing day, in the venue's local tz. UTC midnight is
    /// used in calendars where the listing tz isn't relevant.
    pub listed_at: chrono::NaiveDate,
}

impl Instrument {
    /// Quick spot check — is the order's qty in the allowed range,
    /// and aligned to lot size?
    #[must_use]
    pub fn is_qty_valid(&self, q: Quantity) -> bool {
        q >= self.min_order_qty && q <= self.max_order_qty && self.lot_size.is_aligned(q)
    }

    /// Quick spot check for price.
    #[must_use]
    pub fn is_price_aligned(&self, p: Price) -> bool {
        self.tick_size.is_aligned(p)
    }
}
