//! Request-signature canonicalization and HMAC verification.

use hmac::Mac;
use sha2::Sha256;
use subtle::ConstantTimeEq;

use crate::error::AuthError;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CanonicalRequest {
    pub timestamp: String,
    pub method: String,
    pub path: String,
    pub body: String,
}

impl CanonicalRequest {
    #[must_use]
    pub fn to_preimage(&self) -> String {
        let body = self.body.replace('\r', "");
        format!(
            "{}{}{}{}",
            self.timestamp,
            self.method.to_ascii_uppercase(),
            self.path,
            body
        )
    }
}

#[must_use]
pub fn sign_hmac_sha256_hex(secret: &str, req: &CanonicalRequest) -> String {
    let mut mac = hmac::Hmac::<Sha256>::new_from_slice(secret.as_bytes())
        .expect("sha256 accepts any key length");
    mac.update(req.to_preimage().as_bytes());
    hex::encode(mac.finalize().into_bytes())
}

pub fn verify_hmac_sha256_hex(
    secret: &str,
    req: &CanonicalRequest,
    signature: &str,
) -> Result<(), AuthError> {
    let expected = sign_hmac_sha256_hex(secret, req);
    if expected
        .as_bytes()
        .ct_eq(signature.trim().as_bytes())
        .into()
    {
        Ok(())
    } else {
        Err(AuthError::BadSignature)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn strips_cr_before_hmac() {
        let req = CanonicalRequest {
            timestamp: "1711111111".into(),
            method: "POST".into(),
            path: "/v1/orders".into(),
            body: "{\r\n\"a\":1\r\n}".into(),
        };
        let no_cr_req = CanonicalRequest {
            body: "{\n\"a\":1\n}".into(),
            ..req.clone()
        };
        let sig1 = sign_hmac_sha256_hex("secret", &req);
        let sig2 = sign_hmac_sha256_hex("secret", &no_cr_req);
        assert_eq!(sig1, sig2);
    }
}
