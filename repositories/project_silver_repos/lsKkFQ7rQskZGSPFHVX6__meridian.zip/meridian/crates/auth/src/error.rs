//! Auth errors.

use thiserror::Error;

#[derive(Debug, Error)]
pub enum AuthError {
    #[error("unknown api key")]
    UnknownKey,
    #[error("bad signature")]
    BadSignature,
    #[error("expired")]
    Expired,
    #[error("invalid timestamp")]
    InvalidTimestamp,
    #[error("forbidden")]
    Forbidden,
    #[error("invalid token: {0}")]
    InvalidToken(String),
}

pub type AuthResult<T> = Result<T, AuthError>;
