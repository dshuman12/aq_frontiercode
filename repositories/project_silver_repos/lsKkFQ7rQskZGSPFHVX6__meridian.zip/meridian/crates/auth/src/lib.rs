// Authentication and authorization primitives.
//
// API key auth is used for REST/WS/FIX machine traffic. JWT is only for
// browser/operator sessions.

#![forbid(unsafe_code)]
#![deny(rust_2018_idioms)]
#![allow(
    clippy::pedantic,
    clippy::nursery,
    missing_debug_implementations,
    missing_docs
)]
#![allow(
    clippy::module_name_repetitions,
    clippy::missing_errors_doc,
    clippy::missing_panics_doc,
    clippy::must_use_candidate
)]

//! Meridian auth crate.

pub mod api_key;
pub mod error;
pub mod jwt;
pub mod rbac;
pub mod signature;

pub use api_key::{create_api_key, verify_secret, ApiKey, ApiKeyScope};
pub use error::{AuthError, AuthResult};
pub use jwt::{JwtClaims, JwtIssuer};
pub use rbac::{can, Action, Resource, Role};
pub use signature::{sign_hmac_sha256_hex, verify_hmac_sha256_hex, CanonicalRequest};
