//! Minimal HS256 JWT issuer/validator.

use base64::Engine;
use hmac::Mac;
use sha2::Sha256;
use subtle::ConstantTimeEq;

use crate::error::AuthError;

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct JwtClaims {
    pub sub: String,
    pub scope: String,
    pub iat: i64,
    pub exp: i64,
}

#[derive(Debug, Clone)]
pub struct JwtIssuer {
    secret: Vec<u8>,
}

impl JwtIssuer {
    #[must_use]
    pub fn new(secret: impl AsRef<[u8]>) -> Self {
        Self {
            secret: secret.as_ref().to_vec(),
        }
    }

    pub fn issue(&self, claims: &JwtClaims) -> Result<String, AuthError> {
        let header_json = serde_json::json!({"alg":"HS256","typ":"JWT"});
        let header = b64url(
            &serde_json::to_vec(&header_json)
                .map_err(|e| AuthError::InvalidToken(e.to_string()))?,
        );
        let payload = b64url(
            &serde_json::to_vec(claims).map_err(|e| AuthError::InvalidToken(e.to_string()))?,
        );
        let signing_input = format!("{header}.{payload}");
        let sig = self.sign(signing_input.as_bytes());
        Ok(format!("{signing_input}.{}", b64url(&sig)))
    }

    pub fn verify(&self, token: &str, now_unix: i64) -> Result<JwtClaims, AuthError> {
        let mut parts = token.split('.');
        let Some(header_b64) = parts.next() else {
            return Err(AuthError::InvalidToken("missing header".into()));
        };
        let Some(payload_b64) = parts.next() else {
            return Err(AuthError::InvalidToken("missing payload".into()));
        };
        let Some(sig_b64) = parts.next() else {
            return Err(AuthError::InvalidToken("missing signature".into()));
        };
        if parts.next().is_some() {
            return Err(AuthError::InvalidToken("too many segments".into()));
        }

        let signing_input = format!("{header_b64}.{payload_b64}");
        let expected_sig = self.sign(signing_input.as_bytes());
        let provided_sig = b64url_decode(sig_b64)?;
        if expected_sig
            .as_slice()
            .ct_eq(provided_sig.as_slice())
            .unwrap_u8()
            == 0
        {
            return Err(AuthError::BadSignature);
        }

        let payload_bytes = b64url_decode(payload_b64)?;
        let claims: JwtClaims = serde_json::from_slice(&payload_bytes)
            .map_err(|e| AuthError::InvalidToken(e.to_string()))?;
        if now_unix >= claims.exp {
            return Err(AuthError::Expired);
        }
        Ok(claims)
    }

    fn sign(&self, input: &[u8]) -> Vec<u8> {
        let mut mac = hmac::Hmac::<Sha256>::new_from_slice(&self.secret)
            .expect("sha256 accepts any key length");
        mac.update(input);
        mac.finalize().into_bytes().to_vec()
    }
}

fn b64url(bytes: &[u8]) -> String {
    base64::engine::general_purpose::URL_SAFE_NO_PAD.encode(bytes)
}

fn b64url_decode(s: &str) -> Result<Vec<u8>, AuthError> {
    base64::engine::general_purpose::URL_SAFE_NO_PAD
        .decode(s.as_bytes())
        .map_err(|e| AuthError::InvalidToken(e.to_string()))
}
