//! Role-based access checks.

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, serde::Serialize, serde::Deserialize)]
pub enum Role {
    Trader,
    Admin,
    MarketDataReader,
    Auditor,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum Action {
    Read,
    Write,
    Cancel,
    Configure,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum Resource {
    Orders,
    Account,
    MarketData,
    AdminPanel,
}

#[must_use]
pub const fn can(role: Role, action: Action, resource: Resource) -> bool {
    match role {
        Role::Admin => true,
        Role::Trader => matches!(
            (action, resource),
            (Action::Read, Resource::Orders)
                | (Action::Write, Resource::Orders)
                | (Action::Cancel, Resource::Orders)
                | (Action::Read, Resource::Account)
                | (Action::Read, Resource::MarketData)
        ),
        Role::MarketDataReader => {
            matches!((action, resource), (Action::Read, Resource::MarketData))
        },
        Role::Auditor => matches!(
            (action, resource),
            (Action::Read, Resource::Orders)
                | (Action::Read, Resource::Account)
                | (Action::Read, Resource::MarketData)
        ),
    }
}
