//! API keys and secret verification.

use hmac::Mac;
use meridian_common::prelude::AccountId;
use rand::RngCore;
use sha2::Sha256;
use subtle::ConstantTimeEq;

use crate::error::AuthError;

#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub enum ApiKeyScope {
    TradeRead,
    TradeWrite,
    AccountRead,
    Admin,
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct ApiKey {
    pub id: String,
    pub secret_hash: String,
    pub account: AccountId,
    pub scopes: Vec<ApiKeyScope>,
    pub expires_at: Option<chrono::DateTime<chrono::Utc>>,
}

pub fn create_api_key(
    account: AccountId,
    scopes: Vec<ApiKeyScope>,
    expires_at: Option<chrono::DateTime<chrono::Utc>>,
) -> (ApiKey, String) {
    let mut raw = [0_u8; 32];
    rand::thread_rng().fill_bytes(&mut raw);
    let secret = hex::encode(raw);

    let mut mac = hmac::Hmac::<Sha256>::new_from_slice(secret.as_bytes())
        .expect("sha256 accepts any key length");
    mac.update(account.to_string().as_bytes());
    let secret_hash = hex::encode(mac.finalize().into_bytes());

    let key = ApiKey {
        id: format!("mk_{}", &secret[..12]),
        secret_hash,
        account,
        scopes,
        expires_at,
    };
    (key, secret)
}

pub fn verify_secret(key: &ApiKey, candidate_secret: &str) -> Result<(), AuthError> {
    let mut mac = hmac::Hmac::<Sha256>::new_from_slice(candidate_secret.as_bytes())
        .expect("sha256 accepts any key length");
    mac.update(key.account.to_string().as_bytes());
    let candidate_hash = hex::encode(mac.finalize().into_bytes());
    if key
        .secret_hash
        .as_bytes()
        .ct_eq(candidate_hash.as_bytes())
        .into()
    {
        Ok(())
    } else {
        Err(AuthError::BadSignature)
    }
}
