//! Risk engine errors.

use std::borrow::Cow;

use meridian_common::Error as CommonError;
use thiserror::Error;

pub type RiskResult<T> = Result<T, RiskError>;

#[derive(Debug, Error)]
pub enum RiskError {
    #[error("account {0} unknown")]
    UnknownAccount(String),

    #[error("account {0} suspended")]
    AccountSuspended(String),

    #[error("position cap exceeded: {symbol}, cap={cap}, attempted={attempted}")]
    PositionCapExceeded {
        symbol: String,
        cap: String,
        attempted: String,
    },

    #[error("notional cap exceeded: cap={cap}, attempted={attempted}")]
    NotionalCapExceeded { cap: String, attempted: String },

    #[error("insufficient margin: required={required}, available={available}")]
    InsufficientMargin { required: String, available: String },

    #[error("price band violation: limit={limit}, last={last}, allowed_pct={allowed_pct}")]
    PriceBandViolation {
        limit: String,
        last: String,
        allowed_pct: String,
    },

    #[error("reduce-only would increase position")]
    ReduceOnlyWouldIncrease,

    #[error("risk model not configured for {0}")]
    UnknownModel(Cow<'static, str>),

    #[error(transparent)]
    Common(#[from] CommonError),
}
