//! Pre-trade risk check.
//!
//! Inputs the gateway has on hand: the order, the account, the last
//! trade price (for price-band), and the account's current wallet
//! balance. The check returns a structured outcome so callers can
//! distinguish reject reasons in metrics.

use meridian_common::prelude::*;
use meridian_order_types::{NewOrder, Side};
use rust_decimal::Decimal;
use rust_decimal_macros::dec;

use crate::error::RiskError;
use crate::limits::RiskLimits;
use crate::margin::{margin_required, MarginModel};
use crate::position::{Position, PositionBook};

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum CheckOutcome {
    Accept,
    Reject(RejectKind),
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum RejectKind {
    Suspended,
    PositionCap,
    NotionalCap,
    PriceBand,
    InsufficientMargin,
    ReduceOnlyWouldIncrease,
    UnknownAccount,
}

#[derive(Debug, Clone)]
pub struct RiskInputs<'a> {
    pub account: AccountId,
    pub order: &'a NewOrder,
    pub last_trade: Option<Price>,
    pub wallet_balance: Notional,
    pub margin_model: MarginModel,
}

#[derive(Debug)]
pub struct Check {
    limits: RiskLimits,
    positions: PositionBook,
}

impl Default for Check {
    fn default() -> Self {
        Self::new()
    }
}

impl Check {
    #[must_use]
    pub fn new() -> Self {
        Self {
            limits: RiskLimits::new(),
            positions: PositionBook::new(),
        }
    }

    pub fn limits_mut(&mut self) -> &mut RiskLimits {
        &mut self.limits
    }

    #[must_use]
    pub fn limits(&self) -> &RiskLimits {
        &self.limits
    }

    pub fn positions(&self) -> &PositionBook {
        &self.positions
    }

    /// Run the gauntlet. Order matters: cheapest, cheapest-to-reject
    /// checks first.
    pub fn check(&self, inputs: &RiskInputs<'_>) -> Result<CheckOutcome, RiskError> {
        let limits = self.limits.for_account(inputs.account);
        if limits.suspended {
            return Ok(CheckOutcome::Reject(RejectKind::Suspended));
        }

        // Price band — only if a limit price is present and a last
        // trade is known.
        if let (Some(p), Some(last)) = (inputs.order.limit_price, inputs.last_trade) {
            if let Some(pct) = limits.price_band_pct {
                if !within_pct(p, last, pct) {
                    return Ok(CheckOutcome::Reject(RejectKind::PriceBand));
                }
            }
        }

        // Position cap.
        let (current_pos, _exp) = self.positions.get(inputs.account, &inputs.order.symbol);
        let signed_delta = match inputs.order.side {
            Side::Buy => inputs.order.quantity,
            Side::Sell => -inputs.order.quantity,
        };
        let prospective_qty = current_pos.qty + signed_delta;
        if let Some(cap) = self
            .limits
            .position_cap(inputs.account, &inputs.order.symbol)
        {
            if prospective_qty.abs() > cap {
                return Ok(CheckOutcome::Reject(RejectKind::PositionCap));
            }
        }

        // Reduce-only.
        if (limits.reduce_only || inputs.order.reduce_only)
            && would_increase(current_pos, inputs.order.side)
        {
            return Ok(CheckOutcome::Reject(RejectKind::ReduceOnlyWouldIncrease));
        }

        // Notional cap (rough — uses limit if known, else last trade).
        let mark_price = inputs
            .order
            .limit_price
            .or(inputs.last_trade)
            .unwrap_or(Price::ZERO);
        let added_notional = mark_price * inputs.order.quantity;
        if let Some(cap) = limits.max_open_notional {
            if added_notional > cap {
                return Ok(CheckOutcome::Reject(RejectKind::NotionalCap));
            }
        }

        // Margin.
        let req = margin_required(inputs.margin_model, inputs.order.quantity, mark_price);
        if req > inputs.wallet_balance {
            return Ok(CheckOutcome::Reject(RejectKind::InsufficientMargin));
        }

        Ok(CheckOutcome::Accept)
    }
}

fn within_pct(p: Price, ref_price: Price, pct: Decimal) -> bool {
    if ref_price.is_zero() {
        return false;
    }
    let pct_factor = pct / dec!(100);
    let lower = ref_price.into_decimal() * (Decimal::ONE - pct_factor);
    let upper = ref_price.into_decimal() * (Decimal::ONE + pct_factor);
    p.into_decimal() >= lower && p.into_decimal() <= upper
}

fn would_increase(pos: Position, side: Side) -> bool {
    match (pos.qty.is_positive(), side) {
        (false, Side::Sell) => true,                          // increase short
        (false, Side::Buy) if !pos.qty.is_negative() => true, // open long from flat
        (true, Side::Buy) => true,                            // extend long
        _ => false,
    }
}

#[cfg(test)]
mod tests {
    use meridian_order_types::NewOrder;
    use rust_decimal_macros::dec;

    use crate::limits::AccountLimits;

    use super::*;

    fn sym() -> Symbol {
        Symbol::new("BTC-USD").unwrap()
    }

    fn limit() -> NewOrder {
        NewOrder::limit(
            AccountId::new(1),
            ClientOrderId::new(1),
            sym(),
            Side::Buy,
            Price::from_decimal(dec!(100)),
            Quantity::from_int(1),
        )
    }

    #[test]
    fn fresh_account_falls_back_to_safe_default() {
        let mut c = Check::new();
        // Set a strict fallback so an unknown account is rejected.
        let mut fallback = AccountLimits::default();
        fallback.suspended = true;
        c.limits_mut().set_fallback(fallback);
        let inputs = RiskInputs {
            account: AccountId::new(99),
            order: &limit(),
            last_trade: Some(Price::from_decimal(dec!(100))),
            wallet_balance: Notional::from_decimal(dec!(1_000_000)),
            margin_model: MarginModel::Spot,
        };
        assert_eq!(
            c.check(&inputs).unwrap(),
            CheckOutcome::Reject(RejectKind::Suspended)
        );
    }

    #[test]
    fn position_cap_blocks_oversize() {
        let c = Check::new();
        let mut limits = AccountLimits::default();
        limits.max_position_default = Some(Quantity::from_int(2));
        c.limits.upsert(AccountId::new(1), limits);
        let inputs = RiskInputs {
            account: AccountId::new(1),
            order: &NewOrder::limit(
                AccountId::new(1),
                ClientOrderId::new(1),
                sym(),
                Side::Buy,
                Price::from_decimal(dec!(100)),
                Quantity::from_int(5),
            ),
            last_trade: Some(Price::from_decimal(dec!(100))),
            wallet_balance: Notional::from_decimal(dec!(1_000_000)),
            margin_model: MarginModel::Spot,
        };
        assert_eq!(
            c.check(&inputs).unwrap(),
            CheckOutcome::Reject(RejectKind::PositionCap)
        );
    }

    #[test]
    fn price_band_blocks_far_limit() {
        let c = Check::new();
        let mut limits = AccountLimits::default();
        limits.price_band_pct = Some(dec!(2)); // ±2%
        c.limits.upsert(AccountId::new(1), limits);
        // Limit 110, last 100 → 10% off, exceeds band.
        let inputs = RiskInputs {
            account: AccountId::new(1),
            order: &NewOrder::limit(
                AccountId::new(1),
                ClientOrderId::new(1),
                sym(),
                Side::Buy,
                Price::from_decimal(dec!(110)),
                Quantity::from_int(1),
            ),
            last_trade: Some(Price::from_decimal(dec!(100))),
            wallet_balance: Notional::from_decimal(dec!(1_000_000)),
            margin_model: MarginModel::Spot,
        };
        assert_eq!(
            c.check(&inputs).unwrap(),
            CheckOutcome::Reject(RejectKind::PriceBand)
        );
    }

    #[test]
    fn insufficient_margin_blocks() {
        let c = Check::new();
        c.limits.upsert(AccountId::new(1), AccountLimits::default());
        let inputs = RiskInputs {
            account: AccountId::new(1),
            order: &limit(),
            last_trade: Some(Price::from_decimal(dec!(100))),
            wallet_balance: Notional::from_decimal(dec!(50)), // 50 < 100
            margin_model: MarginModel::Spot,
        };
        assert_eq!(
            c.check(&inputs).unwrap(),
            CheckOutcome::Reject(RejectKind::InsufficientMargin)
        );
    }
}
