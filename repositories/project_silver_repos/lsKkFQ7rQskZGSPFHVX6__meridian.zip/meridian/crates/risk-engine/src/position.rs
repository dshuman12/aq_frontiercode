//! Position and exposure tracking.
//!
//! Position is *net* (long − short) per (account, symbol). Exposure
//! is the open-order liability per side: the qty currently sitting on
//! the book that would *increase* position if it filled.
//!
//! The risk engine maintains its own copy because it can't afford to
//! query the matching engine on every check. The two copies are kept
//! in sync via the engine's event stream — risk subscribes, applies
//! fills + cancels to its own ledger, and treats a divergence > 0 as
//! a hard alarm.

use std::collections::HashMap;

use meridian_common::prelude::*;
use meridian_order_types::Side;
use parking_lot::RwLock;
use serde::{Deserialize, Serialize};

/// Signed position. `qty.is_positive()` ↔ long.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct Position {
    pub qty: Quantity,
    pub avg_entry_price: Price,
    pub realized_pnl: Notional,
}

impl Position {
    /// Apply a fill that *closes or flips* this position. Returns the
    /// realized PnL component for this fill in case the caller wants
    /// it (the running total is also updated in `self`).
    pub fn apply_fill(&mut self, side: Side, fill_qty: Quantity, price: Price) -> Notional {
        let signed_qty = match side {
            Side::Buy => fill_qty,
            Side::Sell => -fill_qty,
        };

        let prior_qty = self.qty;
        let new_qty = prior_qty + signed_qty;

        // Closing or partial close: realize PnL for the closed portion.
        let crosses_zero = (prior_qty.is_positive() && new_qty.is_negative())
            || (prior_qty.is_negative() && new_qty.is_positive());
        let same_sign = (prior_qty.is_positive() && signed_qty.is_positive())
            || (prior_qty.is_negative() && signed_qty.is_negative());

        let mut realized = Notional::ZERO;
        if !same_sign && !prior_qty.is_zero() {
            // Closed portion = min(|prior|, |signed_qty|)
            let closed = prior_qty.abs().min(fill_qty);
            // PnL on closed: (price - avg) * signed_position_direction
            let direction = if prior_qty.is_positive() { 1i64 } else { -1i64 };
            let pnl = (price - self.avg_entry_price) * closed;
            realized =
                Notional::from_decimal(pnl.into_decimal() * rust_decimal::Decimal::from(direction));
            self.realized_pnl += realized;
        }

        // Update avg entry: only when extending or flipping past zero.
        if new_qty.is_zero() {
            self.avg_entry_price = Price::ZERO;
        } else if prior_qty.is_zero() || crosses_zero {
            // Past zero: the residual takes on this fill's price as
            // the new entry.
            self.avg_entry_price = price;
        } else if same_sign {
            // Extend: weighted average.
            let prior_notional = self.avg_entry_price * prior_qty.abs();
            let added_notional = price * fill_qty;
            let total_qty = new_qty.abs();
            let new_avg = (prior_notional + added_notional) / total_qty;
            self.avg_entry_price = new_avg;
        }
        // Else: closing-only (toward zero, not past) — avg unchanged.

        self.qty = new_qty;
        realized
    }
}

/// Open exposure per side.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct Exposure {
    pub buy_qty: Quantity,
    pub sell_qty: Quantity,
}

impl Exposure {
    pub fn add(&mut self, side: Side, qty: Quantity) {
        match side {
            Side::Buy => self.buy_qty += qty,
            Side::Sell => self.sell_qty += qty,
        }
    }

    pub fn sub(&mut self, side: Side, qty: Quantity) {
        match side {
            Side::Buy => {
                self.buy_qty = (self.buy_qty - qty).max(Quantity::ZERO);
            },
            Side::Sell => {
                self.sell_qty = (self.sell_qty - qty).max(Quantity::ZERO);
            },
        }
    }

    /// Open qty on the same side as a hypothetical incoming order —
    /// what counts toward exposure caps.
    #[must_use]
    pub fn on_side(self, side: Side) -> Quantity {
        match side {
            Side::Buy => self.buy_qty,
            Side::Sell => self.sell_qty,
        }
    }
}

/// (account, symbol) → position and exposure.
#[derive(Debug, Default)]
pub struct PositionBook {
    inner: RwLock<HashMap<(AccountId, Symbol), (Position, Exposure)>>,
}

impl PositionBook {
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    /// Read snapshot. Returns defaults when missing.
    #[must_use]
    pub fn get(&self, account: AccountId, symbol: &Symbol) -> (Position, Exposure) {
        self.inner
            .read()
            .get(&(account, symbol.clone()))
            .copied()
            .unwrap_or_default()
    }

    /// Apply a fill — updates position, decreases exposure.
    pub fn apply_fill(
        &self,
        account: AccountId,
        symbol: &Symbol,
        side: Side,
        qty: Quantity,
        price: Price,
    ) -> Notional {
        let mut g = self.inner.write();
        let entry = g
            .entry((account, symbol.clone()))
            .or_insert_with(|| (Position::default(), Exposure::default()));
        entry.1.sub(side, qty);
        entry.0.apply_fill(side, qty, price)
    }

    /// Reserve exposure for a newly-accepted resting order.
    pub fn add_exposure(&self, account: AccountId, symbol: &Symbol, side: Side, qty: Quantity) {
        let mut g = self.inner.write();
        let entry = g
            .entry((account, symbol.clone()))
            .or_insert_with(|| (Position::default(), Exposure::default()));
        entry.1.add(side, qty);
    }

    /// Release exposure for a cancelled order or unfilled remainder.
    pub fn release_exposure(&self, account: AccountId, symbol: &Symbol, side: Side, qty: Quantity) {
        let mut g = self.inner.write();
        let entry = g
            .entry((account, symbol.clone()))
            .or_insert_with(|| (Position::default(), Exposure::default()));
        entry.1.sub(side, qty);
    }

    #[must_use]
    pub fn account_count(&self) -> usize {
        let g = self.inner.read();
        let mut accs = std::collections::HashSet::new();
        for (a, _) in g.keys() {
            accs.insert(*a);
        }
        accs.len()
    }
}

#[cfg(test)]
mod tests {
    use rust_decimal_macros::dec;

    use super::*;

    fn sym() -> Symbol {
        Symbol::new("BTC-USD").unwrap()
    }

    #[test]
    fn open_long_and_close() {
        let pb = PositionBook::new();
        let acc = AccountId::new(1);
        // Open long 10 @ 100.
        pb.apply_fill(
            acc,
            &sym(),
            Side::Buy,
            Quantity::from_int(10),
            Price::from_decimal(dec!(100)),
        );
        let (pos, _) = pb.get(acc, &sym());
        assert_eq!(pos.qty, Quantity::from_int(10));
        assert_eq!(pos.avg_entry_price, Price::from_decimal(dec!(100)));

        // Close 4 @ 110 → realize PnL = 4 * (110-100) = 40.
        let pnl = pb.apply_fill(
            acc,
            &sym(),
            Side::Sell,
            Quantity::from_int(4),
            Price::from_decimal(dec!(110)),
        );
        assert_eq!(pnl.into_decimal(), dec!(40));
        let (pos, _) = pb.get(acc, &sym());
        assert_eq!(pos.qty, Quantity::from_int(6));
        // avg_entry stays at 100 — closing doesn't change it.
        assert_eq!(pos.avg_entry_price, Price::from_decimal(dec!(100)));
    }

    #[test]
    fn flip_through_zero() {
        let pb = PositionBook::new();
        let acc = AccountId::new(1);
        pb.apply_fill(
            acc,
            &sym(),
            Side::Buy,
            Quantity::from_int(5),
            Price::from_decimal(dec!(100)),
        );
        // Sell 8 — close 5 longs at 110, then open 3 shorts at 110.
        pb.apply_fill(
            acc,
            &sym(),
            Side::Sell,
            Quantity::from_int(8),
            Price::from_decimal(dec!(110)),
        );
        let (pos, _) = pb.get(acc, &sym());
        assert!(pos.qty.is_negative());
        assert_eq!(pos.avg_entry_price, Price::from_decimal(dec!(110)));
    }

    #[test]
    fn exposure_tracks_open_orders() {
        let pb = PositionBook::new();
        let acc = AccountId::new(1);
        pb.add_exposure(acc, &sym(), Side::Buy, Quantity::from_int(5));
        pb.add_exposure(acc, &sym(), Side::Buy, Quantity::from_int(3));
        let (_, exp) = pb.get(acc, &sym());
        assert_eq!(exp.buy_qty, Quantity::from_int(8));
        pb.release_exposure(acc, &sym(), Side::Buy, Quantity::from_int(5));
        let (_, exp) = pb.get(acc, &sym());
        assert_eq!(exp.buy_qty, Quantity::from_int(3));
    }
}
