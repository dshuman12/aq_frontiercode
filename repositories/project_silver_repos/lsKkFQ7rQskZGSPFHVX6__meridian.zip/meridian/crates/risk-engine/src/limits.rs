//! Limits — the configurable knobs the risk engine enforces.

use std::collections::HashMap;

use meridian_common::prelude::*;
use parking_lot::RwLock;
use serde::{Deserialize, Serialize};

/// Per-account caps. Anything `None` is "no limit" (use sparingly).
#[derive(Debug, Default, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct AccountLimits {
    /// Net position cap (absolute), per symbol. Symbol "*" applies to
    /// any symbol not listed explicitly.
    pub max_position: HashMap<Symbol, Quantity>,
    pub max_position_default: Option<Quantity>,

    /// Open notional cap across all symbols.
    pub max_open_notional: Option<Notional>,

    /// Price band: order limit must be within `pct` of last trade.
    pub price_band_pct: Option<rust_decimal::Decimal>,

    /// True if every order must reduce position. Most retail accounts
    /// don't use this; pro / hedge accounts do for risk wind-down.
    pub reduce_only: bool,

    /// Account is suspended — refuse all order entry.
    pub suspended: bool,
}

/// Workspace of limits across all accounts. The risk engine refreshes
/// this from `ref-data` on a cadence.
#[derive(Debug, Default)]
pub struct RiskLimits {
    accounts: RwLock<HashMap<AccountId, AccountLimits>>,
    fallback: AccountLimits,
}

impl RiskLimits {
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    pub fn upsert(&self, account: AccountId, limits: AccountLimits) {
        self.accounts.write().insert(account, limits);
    }

    /// Returns the account's limits, falling back to the workspace
    /// default when missing. The fallback is *not* permissive — it
    /// has every cap set to a small "safe" number, so a misconfigured
    /// account fails closed.
    #[must_use]
    pub fn for_account(&self, account: AccountId) -> AccountLimits {
        self.accounts
            .read()
            .get(&account)
            .cloned()
            .unwrap_or_else(|| self.fallback.clone())
    }

    /// Set the safe-default limits for accounts not explicitly listed.
    /// Useful for tests; production loads from config.
    pub fn set_fallback(&mut self, l: AccountLimits) {
        self.fallback = l;
    }

    /// Ergonomic helper used by the check.
    #[must_use]
    pub fn position_cap(&self, account: AccountId, symbol: &Symbol) -> Option<Quantity> {
        let l = self.for_account(account);
        l.max_position
            .get(symbol)
            .copied()
            .or(l.max_position_default)
    }
}

#[cfg(test)]
mod tests {
    use rust_decimal_macros::dec;

    use super::*;

    fn sym() -> Symbol {
        Symbol::new("BTC-USD").unwrap()
    }

    #[test]
    fn position_cap_lookup() {
        let l = RiskLimits::new();
        let mut limits = AccountLimits::default();
        limits.max_position_default = Some(Quantity::from_decimal(dec!(50)));
        limits
            .max_position
            .insert(sym(), Quantity::from_decimal(dec!(100)));
        l.upsert(AccountId::new(1), limits);
        assert_eq!(
            l.position_cap(AccountId::new(1), &sym()),
            Some(Quantity::from_decimal(dec!(100)))
        );
        assert_eq!(
            l.position_cap(AccountId::new(1), &Symbol::new("ETH-USD").unwrap()),
            Some(Quantity::from_decimal(dec!(50)))
        );
    }
}
