// Risk engine — pre-trade gates.
//
// Sits between the sequencer and the matching engine. The sequencer
// has already assigned a SeqNo, so we can't change the order of
// commands; we can only accept or reject. A rejection at this layer
// produces a synthetic event in the engine's event stream so that
// downstream consumers (FIX gateway, audit log) see a coherent
// timeline regardless of where in the pipeline the reject happened.
//
// # Concepts
//
// - **Position** — net (long − short) per (account, symbol).
// - **Exposure** — open (resting) order qty per side.
// - **Initial margin** — what we lock when an order is accepted.
// - **Variation margin** — recomputed daily, held by the ledger.
// - **Limits** — per-account caps on position, exposure, notional.
//
// Limits live in `ref-data`. The risk engine re-fetches them on a
// cadence (every 5s by default) and caches the result; we don't
// hot-path-call ref-data on every order.

#![forbid(unsafe_code)]
#![deny(rust_2018_idioms)]
#![allow(
    clippy::pedantic,
    clippy::nursery,
    missing_debug_implementations,
    missing_docs
)]
#![allow(
    clippy::module_name_repetitions,
    clippy::missing_errors_doc,
    clippy::missing_panics_doc,
    clippy::must_use_candidate
)]

//! Risk engine.

pub mod check;
pub mod error;
pub mod limits;
pub mod margin;
pub mod position;

pub use check::{Check, CheckOutcome, RiskInputs};
pub use error::{RiskError, RiskResult};
pub use limits::{AccountLimits, RiskLimits};
pub use margin::{margin_required, MarginModel};
pub use position::{Exposure, Position, PositionBook};
