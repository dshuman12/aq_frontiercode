//! Margin computation.
//!
//! For now we support two simple models:
//!
//! - **Spot.** Margin = full notional. Crypto spot — no leverage.
//! - **LinearPerp.** Margin = notional / leverage, with maintenance
//!   margin held back from the wallet.
//!
//! More sophisticated models (SPAN, portfolio margining) are planned
//! and would slot in behind the same `MarginModel` trait.

use std::fmt;

use meridian_common::prelude::*;
use rust_decimal::Decimal;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum MarginModel {
    Spot,
    LinearPerp { leverage: u32, maintenance_bps: i32 },
}

impl fmt::Display for MarginModel {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Spot => f.write_str("spot"),
            Self::LinearPerp { leverage, .. } => write!(f, "linear-perp x{leverage}"),
        }
    }
}

/// Compute initial margin required for a *prospective* exposure of
/// `qty` at `price` under `model`. Always positive.
#[must_use]
pub fn margin_required(model: MarginModel, qty: Quantity, price: Price) -> Notional {
    let notional = price * qty;
    match model {
        MarginModel::Spot => notional,
        MarginModel::LinearPerp { leverage, .. } => {
            if leverage == 0 {
                return notional;
            }
            let lev = Decimal::from(leverage);
            Notional::from_decimal(notional.into_decimal() / lev)
        },
    }
}

/// Maintenance margin — the floor the wallet must remain above to
/// avoid liquidation. Spot has no maintenance.
#[must_use]
pub fn maintenance_margin(model: MarginModel, qty: Quantity, price: Price) -> Notional {
    match model {
        MarginModel::Spot => Notional::ZERO,
        MarginModel::LinearPerp {
            maintenance_bps, ..
        } => {
            let n = price * qty;
            Bps::new(maintenance_bps).apply(n).into_decimal().into()
        },
    }
}

#[cfg(test)]
mod tests {
    use rust_decimal_macros::dec;

    use super::*;

    #[test]
    fn spot_margin_is_full_notional() {
        let m = margin_required(
            MarginModel::Spot,
            Quantity::from_int(2),
            Price::from_decimal(dec!(100)),
        );
        assert_eq!(m.into_decimal(), dec!(200));
    }

    #[test]
    fn perp_margin_divides_by_leverage() {
        let m = margin_required(
            MarginModel::LinearPerp {
                leverage: 10,
                maintenance_bps: 50,
            },
            Quantity::from_int(2),
            Price::from_decimal(dec!(100)),
        );
        assert_eq!(m.into_decimal(), dec!(20));
    }

    #[test]
    fn perp_maintenance_uses_bps() {
        let mm = maintenance_margin(
            MarginModel::LinearPerp {
                leverage: 10,
                maintenance_bps: 50, // 0.50%
            },
            Quantity::from_int(10),
            Price::from_decimal(dec!(100)),
        );
        // notional = 1000; 50bps = 5
        assert_eq!(mm.into_decimal(), dec!(5.00000000));
    }
}
