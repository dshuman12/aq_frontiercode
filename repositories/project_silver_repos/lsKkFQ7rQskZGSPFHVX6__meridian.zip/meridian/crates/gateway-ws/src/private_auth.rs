//! Private-channel auth handshake.

use meridian_auth::CanonicalRequest;

use crate::error::WsGatewayError;

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct WsAuthRequest {
    pub api_key: String,
    pub signature: String,
    pub ts: String,
}

pub fn verify_opening_auth_frame(auth: &WsAuthRequest, secret: &str) -> Result<(), WsGatewayError> {
    let req = CanonicalRequest {
        timestamp: auth.ts.clone(),
        method: "AUTH".into(),
        path: "/ws/private".into(),
        body: String::new(),
    };
    meridian_auth::verify_hmac_sha256_hex(secret, &req, &auth.signature)
        .map_err(|_| WsGatewayError::AuthenticationFailed)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn auth_uses_cr_stripping_semantics() {
        let req = CanonicalRequest {
            timestamp: "1".into(),
            method: "AUTH".into(),
            path: "/ws/private".into(),
            body: "\r".into(),
        };
        let sig = meridian_auth::sign_hmac_sha256_hex("secret", &req);
        let frame = WsAuthRequest {
            api_key: "k".into(),
            signature: sig,
            ts: "1".into(),
        };
        assert!(verify_opening_auth_frame(&frame, "secret").is_ok());
    }
}
