//! WS gateway errors.

use thiserror::Error;

#[derive(Debug, Error)]
pub enum WsGatewayError {
    #[error("invalid request: {0}")]
    InvalidRequest(String),
    #[error("authentication failed")]
    AuthenticationFailed,
}
