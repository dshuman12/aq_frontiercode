//! Connection session state.

use std::collections::{HashMap, HashSet};

use crate::channels::Channel;

#[derive(Debug, Default)]
pub struct SessionState {
    pub authenticated: bool,
    subscriptions: HashSet<Channel>,
    last_seq: HashMap<String, u64>,
}

impl SessionState {
    pub fn subscribe(&mut self, ch: Channel) {
        self.subscriptions.insert(ch);
    }

    pub fn unsubscribe(&mut self, ch: Channel) {
        self.subscriptions.remove(&ch);
    }

    pub fn subscriptions(&self) -> impl Iterator<Item = Channel> + '_ {
        self.subscriptions.iter().copied()
    }

    pub fn mark_seq(&mut self, channel: &str, seq: u64) {
        self.last_seq.insert(channel.to_string(), seq);
    }
}
