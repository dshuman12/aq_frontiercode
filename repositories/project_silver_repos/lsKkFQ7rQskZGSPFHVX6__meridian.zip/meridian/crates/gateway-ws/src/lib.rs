// WebSocket gateway for public and private channels.

#![forbid(unsafe_code)]
#![deny(rust_2018_idioms)]
#![allow(
    clippy::pedantic,
    clippy::nursery,
    missing_debug_implementations,
    missing_docs
)]
#![allow(
    clippy::module_name_repetitions,
    clippy::missing_errors_doc,
    clippy::missing_panics_doc,
    clippy::must_use_candidate
)]

//! Meridian WebSocket gateway.

pub mod channels;
pub mod error;
pub mod frame;
pub mod private_auth;
pub mod session;
