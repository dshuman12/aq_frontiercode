//! Supported channel names and access policy.

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum Channel {
    BookL1,
    BookL2,
    Trades,
    Ticker,
    Candles1m,
    AccountBalances,
    AccountFills,
    AccountOrders,
}

impl Channel {
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::BookL1 => "book.l1",
            Self::BookL2 => "book.l2",
            Self::Trades => "trades",
            Self::Ticker => "ticker",
            Self::Candles1m => "candles@1m",
            Self::AccountBalances => "account.balances",
            Self::AccountFills => "account.fills",
            Self::AccountOrders => "account.orders",
        }
    }

    #[must_use]
    pub const fn requires_auth(self) -> bool {
        matches!(
            self,
            Self::AccountBalances | Self::AccountFills | Self::AccountOrders
        )
    }
}

pub fn parse(name: &str) -> Option<Channel> {
    Some(match name {
        "book.l1" => Channel::BookL1,
        "book.l2" => Channel::BookL2,
        "trades" => Channel::Trades,
        "ticker" => Channel::Ticker,
        "candles@1m" => Channel::Candles1m,
        "account.balances" => Channel::AccountBalances,
        "account.fills" => Channel::AccountFills,
        "account.orders" => Channel::AccountOrders,
        _ => return None,
    })
}
