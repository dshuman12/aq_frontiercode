//! JSON-RPC style WS request/response envelopes.

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct WsRequest {
    pub method: String,
    #[serde(default)]
    pub params: serde_json::Value,
    pub id: serde_json::Value,
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
#[serde(untagged)]
pub enum WsResponsePayload {
    Result {
        result: serde_json::Value,
        id: serde_json::Value,
    },
    Error {
        error: serde_json::Value,
        id: serde_json::Value,
    },
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct WsEvent {
    pub channel: String,
    pub data: serde_json::Value,
    pub seq: u64,
}
