//! Depth snapshots — what L2 / L3 market data publishes.

use meridian_common::prelude::*;
use meridian_order_types::Side;
use serde::{Deserialize, Serialize};

use crate::book::Book;

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct DepthLevel {
    pub price: Price,
    pub visible_qty: Quantity,
    /// Number of orders at this level (L3 detail; clients can ignore).
    pub order_count: u32,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct DepthSnapshot {
    pub symbol: Symbol,
    pub bids: Vec<DepthLevel>,
    pub asks: Vec<DepthLevel>,
    pub seq_no: MdSeqNo,
    pub at: Timestamp,
}

impl DepthSnapshot {
    /// Build a snapshot of `depth` levels per side from a book.
    #[must_use]
    pub fn from_book(book: &Book, depth: usize, seq_no: MdSeqNo, at: Timestamp) -> Self {
        let to_levels = |side: Side| -> Vec<DepthLevel> {
            book.iter_side(side)
                .take(depth)
                .map(|lvl| DepthLevel {
                    price: lvl.price,
                    visible_qty: lvl.visible_qty(),
                    order_count: u32::try_from(lvl.len()).unwrap_or(u32::MAX),
                })
                .collect()
        };
        Self {
            symbol: book.symbol.clone(),
            bids: to_levels(Side::Buy),
            asks: to_levels(Side::Sell),
            seq_no,
            at,
        }
    }

    /// Total notional resting in this snapshot, summed across both sides.
    #[must_use]
    pub fn total_notional(&self) -> Notional {
        let mut sum = Notional::ZERO;
        for lvl in self.bids.iter().chain(self.asks.iter()) {
            sum += lvl.price * lvl.visible_qty;
        }
        sum
    }
}
