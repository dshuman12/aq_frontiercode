// Order book — single-symbol, single-writer.
//
// The data structure is the classic two-sided "ladder":
//
//      bids                 asks
//      ----                 ----
//      [101.50] -> q1 q2    [101.55] -> q3
//      [101.45] -> q4       [101.60] -> q5 q6 q7
//      [101.40] -> q8       ...
//      ...                  ...
//
// Each side is a `BTreeMap<Price, PriceLevel>`. Ordering is reversed on
// the bid side so that the head of the iterator is always the best
// price (`top_of_book` is O(log n)). Within a level, orders sit in a
// `VecDeque` in time priority.
//
// The book intentionally does **not** know about matching policy,
// session state, fees, risk, or accounts. It's a value type. The
// matching engine drives it.

#![forbid(unsafe_code)]
#![deny(rust_2018_idioms)]
#![allow(
    clippy::pedantic,
    clippy::nursery,
    missing_debug_implementations,
    missing_docs
)]
#![allow(
    clippy::module_name_repetitions,
    clippy::missing_errors_doc,
    clippy::missing_panics_doc,
    clippy::must_use_candidate,
    clippy::cast_possible_truncation,
    clippy::cast_precision_loss
)]

//! Per-symbol order book primitives.

pub mod book;
pub mod depth;
pub mod imbalance;
pub mod level;
pub mod resting;
pub mod snapshot;
pub mod stats;

pub use book::{Book, BookSide};
pub use depth::{DepthLevel, DepthSnapshot};
pub use imbalance::Imbalance;
pub use level::PriceLevel;
pub use resting::RestingOrder;
pub use snapshot::BookSnapshot;
pub use stats::BookStats;
