//! Per-book counters. Engine pulls these into `metrics`.

use meridian_common::prelude::*;
use std::sync::atomic::{AtomicU64, Ordering};

#[derive(Debug, Default)]
pub struct BookStats {
    inserts: AtomicU64,
    cancels: AtomicU64,
    matches: AtomicU64,
    matched_qty_units: AtomicU64,
}

impl BookStats {
    pub fn record_insert(&self) {
        self.inserts.fetch_add(1, Ordering::Relaxed);
    }
    pub fn record_cancel(&self) {
        self.cancels.fetch_add(1, Ordering::Relaxed);
    }
    /// `delta` is the matched-quantity *units* (we round down to whole
    /// integer base units for stats; precision doesn't matter here).
    pub fn record_match(&self, delta: Quantity) {
        let units = delta.into_decimal().trunc().mantissa();
        let units = u64::try_from(units.unsigned_abs()).unwrap_or(u64::MAX);
        self.matches.fetch_add(1, Ordering::Relaxed);
        self.matched_qty_units.fetch_add(units, Ordering::Relaxed);
    }

    pub fn snapshot(&self) -> BookStatsSnapshot {
        BookStatsSnapshot {
            inserts: self.inserts.load(Ordering::Relaxed),
            cancels: self.cancels.load(Ordering::Relaxed),
            matches: self.matches.load(Ordering::Relaxed),
            matched_qty_units: self.matched_qty_units.load(Ordering::Relaxed),
        }
    }
}

impl Clone for BookStats {
    fn clone(&self) -> Self {
        Self {
            inserts: AtomicU64::new(self.inserts.load(Ordering::Relaxed)),
            cancels: AtomicU64::new(self.cancels.load(Ordering::Relaxed)),
            matches: AtomicU64::new(self.matches.load(Ordering::Relaxed)),
            matched_qty_units: AtomicU64::new(self.matched_qty_units.load(Ordering::Relaxed)),
        }
    }
}

#[derive(Debug, Clone, Copy)]
pub struct BookStatsSnapshot {
    pub inserts: u64,
    pub cancels: u64,
    pub matches: u64,
    pub matched_qty_units: u64,
}
