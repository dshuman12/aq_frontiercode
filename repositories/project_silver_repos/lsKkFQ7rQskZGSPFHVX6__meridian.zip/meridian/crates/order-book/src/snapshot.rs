//! `BookSnapshot` — full L3 dump of a book, used by recovery and tests.
//!
//! L2 / L3 wire snapshots are in `depth.rs`. The snapshot here is *the
//! whole book*, including hidden iceberg quantities — the engine writes
//! it into the snapshot store on a configurable cadence so that
//! sequencer recovery doesn't have to replay the full event log.

use meridian_common::prelude::*;
use serde::{Deserialize, Serialize};

use crate::book::Book;
use crate::resting::RestingOrder;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BookSnapshot {
    pub symbol: Symbol,
    pub seq_no: SeqNo,
    pub at: Timestamp,
    pub bids: Vec<BookSnapshotLevel>,
    pub asks: Vec<BookSnapshotLevel>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BookSnapshotLevel {
    pub price: Price,
    pub orders: Vec<RestingOrderSerde>,
}

/// Serde-friendly view of `RestingOrder`. We dance via this struct
/// rather than deriving Serialize on `RestingOrder` directly because
/// `RestingOrder` lives in this crate but is also written by the
/// matcher; making it `Serialize`-able would force matching-engine to
/// pull in serde at the trait level.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RestingOrderSerde {
    pub order_id: OrderId,
    pub account_id: AccountId,
    pub side: meridian_order_types::Side,
    pub order_type: meridian_order_types::OrderType,
    pub leaves_qty: Quantity,
    pub display_qty: Option<Quantity>,
    pub hidden_qty: Option<Quantity>,
    pub price: Price,
    pub priority_seq: SeqNo,
    pub post_only: bool,
}

impl From<&RestingOrder> for RestingOrderSerde {
    fn from(o: &RestingOrder) -> Self {
        Self {
            order_id: o.order_id,
            account_id: o.account_id,
            side: o.side,
            order_type: o.order_type,
            leaves_qty: o.leaves_qty,
            display_qty: o.display_qty,
            hidden_qty: o.hidden_qty,
            price: o.price,
            priority_seq: o.priority_seq,
            post_only: o.post_only,
        }
    }
}

impl From<RestingOrderSerde> for RestingOrder {
    fn from(o: RestingOrderSerde) -> Self {
        Self {
            order_id: o.order_id,
            account_id: o.account_id,
            side: o.side,
            order_type: o.order_type,
            leaves_qty: o.leaves_qty,
            display_qty: o.display_qty,
            hidden_qty: o.hidden_qty,
            price: o.price,
            priority_seq: o.priority_seq,
            post_only: o.post_only,
        }
    }
}

impl BookSnapshot {
    #[must_use]
    pub fn capture(book: &Book, seq_no: SeqNo, at: Timestamp) -> Self {
        let mut bids = Vec::with_capacity(book.level_count(meridian_order_types::Side::Buy));
        let mut asks = Vec::with_capacity(book.level_count(meridian_order_types::Side::Sell));
        for lvl in book.iter_side(meridian_order_types::Side::Buy) {
            bids.push(BookSnapshotLevel {
                price: lvl.price,
                orders: lvl.iter().map(RestingOrderSerde::from).collect(),
            });
        }
        for lvl in book.iter_side(meridian_order_types::Side::Sell) {
            asks.push(BookSnapshotLevel {
                price: lvl.price,
                orders: lvl.iter().map(RestingOrderSerde::from).collect(),
            });
        }
        Self {
            symbol: book.symbol.clone(),
            seq_no,
            at,
            bids,
            asks,
        }
    }

    /// Reconstruct a `Book` from the snapshot. Bids/asks are inserted
    /// in their original priority order.
    #[must_use]
    pub fn into_book(self) -> Book {
        let mut b = Book::new(self.symbol.clone());
        for lvl in &self.bids {
            for o in &lvl.orders {
                b.insert(RestingOrder::from(o.clone()));
            }
        }
        for lvl in &self.asks {
            for o in &lvl.orders {
                b.insert(RestingOrder::from(o.clone()));
            }
        }
        b
    }
}
