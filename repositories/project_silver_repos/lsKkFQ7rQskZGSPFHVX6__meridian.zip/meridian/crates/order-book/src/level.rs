//! Price level — the FIFO queue of resting orders at a single price.
//!
//! Implementation note: we use `VecDeque` rather than a linked list
//! because (a) cache locality matters and (b) matching consumes from
//! the front — exactly `pop_front`. We never insert in the middle of a
//! level; new resting orders go to the back, and amends that retain
//! priority modify-in-place.

use std::collections::VecDeque;

use meridian_common::prelude::*;

use crate::resting::RestingOrder;

/// A single price level on one side of the book.
#[derive(Debug, Clone, Default)]
pub struct PriceLevel {
    pub price: Price,
    queue: VecDeque<RestingOrder>,
    /// Cached sum of visible qty. Recomputed on every mutation.
    visible_total: Quantity,
}

impl PriceLevel {
    #[must_use]
    pub fn new(price: Price) -> Self {
        Self {
            price,
            queue: VecDeque::with_capacity(8),
            visible_total: Quantity::ZERO,
        }
    }

    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.queue.is_empty()
    }

    #[must_use]
    pub fn len(&self) -> usize {
        self.queue.len()
    }

    /// Total visible quantity. This is what L2 market data publishes.
    #[must_use]
    pub fn visible_qty(&self) -> Quantity {
        self.visible_total
    }

    /// Total quantity including hidden iceberg slices. L3 only.
    #[must_use]
    pub fn total_qty(&self) -> Quantity {
        let mut sum = Quantity::ZERO;
        for o in &self.queue {
            sum += o.leaves_qty;
        }
        sum
    }

    /// Push a new order to the *back* of the queue.
    pub fn push_back(&mut self, order: RestingOrder) {
        debug_assert_eq!(order.price, self.price);
        self.visible_total += order.visible_qty();
        self.queue.push_back(order);
    }

    /// Insert at a specific position. Used by amend-keeps-priority paths.
    pub fn insert_at(&mut self, idx: usize, order: RestingOrder) {
        debug_assert_eq!(order.price, self.price);
        self.visible_total += order.visible_qty();
        self.queue.insert(idx, order);
    }

    /// View the head of the queue without removing it.
    #[must_use]
    pub fn peek_front(&self) -> Option<&RestingOrder> {
        self.queue.front()
    }

    /// Mutable access to the head of the queue.
    #[must_use]
    pub fn peek_front_mut(&mut self) -> Option<&mut RestingOrder> {
        self.queue.front_mut()
    }

    /// Remove and return the head order.
    pub fn pop_front(&mut self) -> Option<RestingOrder> {
        let removed = self.queue.pop_front()?;
        self.visible_total -= removed.visible_qty();
        Some(removed)
    }

    /// Remove an order anywhere in the queue, by `OrderId`.
    pub fn remove_by_id(&mut self, order_id: OrderId) -> Option<RestingOrder> {
        let pos = self.queue.iter().position(|o| o.order_id == order_id)?;
        let removed = self.queue.remove(pos)?;
        self.visible_total -= removed.visible_qty();
        Some(removed)
    }

    /// Reduce the head order's `leaves_qty` by `delta` and decrement
    /// the visible total accordingly. Caller must guarantee `delta`
    /// is ≤ the head's leaves_qty.
    pub fn reduce_front(&mut self, delta: Quantity) {
        let Some(front) = self.queue.front_mut() else {
            return;
        };
        let pre_visible = front.visible_qty();
        front.leaves_qty -= delta;
        let post_visible = front.visible_qty();
        // Visible may not have moved if we ate from hidden first. The
        // caller is responsible for refreshing iceberg visible / hidden;
        // we just track what's currently in `display_qty`.
        if pre_visible >= post_visible {
            self.visible_total -= pre_visible - post_visible;
        } else {
            self.visible_total += post_visible - pre_visible;
        }
        if front.leaves_qty.is_zero() {
            let _ = self.pop_front();
        }
    }

    /// Reduce a specific order at this level by `delta`.
    ///
    /// Returns the actual reduced quantity if the order was found.
    pub fn reduce_by_id(&mut self, order_id: OrderId, delta: Quantity) -> Option<Quantity> {
        if delta.is_zero() {
            return Some(Quantity::ZERO);
        }
        let pos = self.queue.iter().position(|o| o.order_id == order_id)?;

        let (actual, remove) = {
            let order = self.queue.get_mut(pos)?;
            let actual = delta.min(order.leaves_qty);
            if actual.is_zero() {
                return Some(Quantity::ZERO);
            }
            let pre_visible = order.visible_qty();
            order.leaves_qty -= actual;
            let post_visible = order.visible_qty();
            if pre_visible >= post_visible {
                self.visible_total -= pre_visible - post_visible;
            } else {
                self.visible_total += post_visible - pre_visible;
            }
            (actual, order.leaves_qty.is_zero())
        };
        if remove {
            let _ = self.queue.remove(pos);
        }
        Some(actual)
    }

    /// Iterator over orders in priority order.
    pub fn iter(&self) -> impl Iterator<Item = &RestingOrder> {
        self.queue.iter()
    }

    /// Mutable iterator. Use sparingly — most things should go through
    /// `pop_front` / `reduce_front`.
    pub fn iter_mut(&mut self) -> impl Iterator<Item = &mut RestingOrder> {
        self.queue.iter_mut()
    }

    /// Fully refresh the cached visible total. Slow path — only used
    /// in tests and after large invariant-violating operations.
    pub fn recompute_cache(&mut self) {
        let mut sum = Quantity::ZERO;
        for o in &self.queue {
            sum += o.visible_qty();
        }
        self.visible_total = sum;
    }
}
