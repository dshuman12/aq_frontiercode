//! `Book` — the two-sided order book.
//!
//! API surface kept narrow: the matching engine is the only writer.
//! Reads (depth, BBO, imbalance) are cheap and lock-free if the engine
//! holds the book under an `arc-swap` cell.
//!
//! # Invariants
//!
//! 1. Best bid price < best ask price. The engine prevents a crossed
//!    book — see `match_against` in `matching-engine`.
//! 2. Every level is non-empty. Levels become empty only inside a
//!    method, and are pruned before return.
//! 3. Within a level, orders sit in `priority_seq` order, ascending.
//! 4. The cached `visible_total` per level equals the sum of
//!    `visible_qty()` over the level's queue.

use std::collections::BTreeMap;

use meridian_common::prelude::*;
use meridian_order_types::Side;

use crate::imbalance::Imbalance;
use crate::level::PriceLevel;
use crate::resting::RestingOrder;
use crate::stats::BookStats;

/// Which side of the book we're talking about. Re-export for callers
/// that want a more book-y synonym for `Side`.
pub type BookSide = Side;

/// Full two-sided order book for a single symbol.
#[derive(Debug, Clone)]
pub struct Book {
    pub symbol: Symbol,

    /// Bids: lookup by price, but iteration order should be high → low.
    /// We keep them in natural order and reverse-iterate; this is
    /// faster than the alternative `Reverse<Price>` because B-tree
    /// reverse-iteration is O(log n) for the first element and amortised
    /// O(1) thereafter.
    bids: BTreeMap<Price, PriceLevel>,

    /// Asks: low → high.
    asks: BTreeMap<Price, PriceLevel>,

    stats: BookStats,
}

impl Book {
    #[must_use]
    pub fn new(symbol: Symbol) -> Self {
        Self {
            symbol,
            bids: BTreeMap::new(),
            asks: BTreeMap::new(),
            stats: BookStats::default(),
        }
    }

    #[must_use]
    pub const fn stats(&self) -> &BookStats {
        &self.stats
    }

    #[must_use]
    pub fn level_count(&self, side: Side) -> usize {
        match side {
            Side::Buy => self.bids.len(),
            Side::Sell => self.asks.len(),
        }
    }

    #[must_use]
    pub fn best_bid(&self) -> Option<Price> {
        self.bids.keys().next_back().copied()
    }

    #[must_use]
    pub fn best_ask(&self) -> Option<Price> {
        self.asks.keys().next().copied()
    }

    /// `(best_bid, best_ask)` — useful single call for risk checks.
    #[must_use]
    pub fn bbo(&self) -> (Option<Price>, Option<Price>) {
        (self.best_bid(), self.best_ask())
    }

    #[must_use]
    pub fn mid_price(&self) -> Option<Price> {
        let (Some(b), Some(a)) = self.bbo() else {
            return None;
        };
        let two = rust_decimal::Decimal::from(2);
        Some(Price::from_decimal(
            (b.into_decimal() + a.into_decimal()) / two,
        ))
    }

    #[must_use]
    pub fn spread(&self) -> Option<Price> {
        match self.bbo() {
            (Some(b), Some(a)) if a >= b => Some(a - b),
            _ => None,
        }
    }

    /// Best level on a side.
    #[must_use]
    pub fn best_level(&self, side: Side) -> Option<&PriceLevel> {
        match side {
            Side::Buy => self.bids.values().next_back(),
            Side::Sell => self.asks.values().next(),
        }
    }

    /// Mutable best level on a side.
    pub fn best_level_mut(&mut self, side: Side) -> Option<&mut PriceLevel> {
        match side {
            Side::Buy => self.bids.values_mut().next_back(),
            Side::Sell => self.asks.values_mut().next(),
        }
    }

    /// Insert a resting order at its price.
    ///
    /// Caller is responsible for: validating the order is appropriate
    /// for resting (e.g. not market, TIF allows resting, post-only
    /// non-cross check has already passed), tick alignment, and
    /// duplicate-id prevention.
    pub fn insert(&mut self, order: RestingOrder) {
        let side = order.side;
        let price = order.price;
        let level = match side {
            Side::Buy => self
                .bids
                .entry(price)
                .or_insert_with(|| PriceLevel::new(price)),
            Side::Sell => self
                .asks
                .entry(price)
                .or_insert_with(|| PriceLevel::new(price)),
        };
        level.push_back(order);
        self.stats.record_insert();
    }

    /// Remove an order by id. Returns the removed `RestingOrder` if found.
    ///
    /// O(N) within a level — we don't keep a hash side-index because the
    /// engine has its own `OrderId -> (price, side)` map and only ever
    /// calls this on the level it already located.
    pub fn remove(&mut self, side: Side, price: Price, order_id: OrderId) -> Option<RestingOrder> {
        let removed = {
            let level = match side {
                Side::Buy => self.bids.get_mut(&price)?,
                Side::Sell => self.asks.get_mut(&price)?,
            };
            let removed = level.remove_by_id(order_id)?;
            if level.is_empty() {
                match side {
                    Side::Buy => {
                        self.bids.remove(&price);
                    },
                    Side::Sell => {
                        self.asks.remove(&price);
                    },
                }
            }
            removed
        };
        self.stats.record_cancel();
        Some(removed)
    }

    /// Reduce the head order's `leaves_qty` at a level by `delta`.
    /// If the head is fully consumed, it's popped and the level may be
    /// pruned if it becomes empty.
    pub fn reduce_front(&mut self, side: Side, price: Price, delta: Quantity) {
        let level = match side {
            Side::Buy => self.bids.get_mut(&price),
            Side::Sell => self.asks.get_mut(&price),
        };
        let Some(level) = level else {
            return;
        };
        level.reduce_front(delta);
        if level.is_empty() {
            match side {
                Side::Buy => {
                    self.bids.remove(&price);
                },
                Side::Sell => {
                    self.asks.remove(&price);
                },
            }
        }
        self.stats.record_match(delta);
    }

    /// Reduce a specific order's visible quantity at one level.
    ///
    /// Returns the actual reduced quantity if the order was present.
    pub fn reduce_order(
        &mut self,
        side: Side,
        price: Price,
        order_id: OrderId,
        delta: Quantity,
    ) -> Option<Quantity> {
        let level = match side {
            Side::Buy => self.bids.get_mut(&price),
            Side::Sell => self.asks.get_mut(&price),
        }?;
        let reduced = level.reduce_by_id(order_id, delta)?;
        if level.is_empty() {
            match side {
                Side::Buy => {
                    self.bids.remove(&price);
                },
                Side::Sell => {
                    self.asks.remove(&price);
                },
            }
        }
        self.stats.record_match(reduced);
        Some(reduced)
    }

    /// Iterate over the side from best to worst.
    pub fn iter_side(&self, side: Side) -> Box<dyn Iterator<Item = &PriceLevel> + '_> {
        match side {
            Side::Buy => Box::new(self.bids.values().rev()),
            Side::Sell => Box::new(self.asks.values()),
        }
    }

    /// Iterate the *first* `depth` levels of a side, best-to-worst.
    pub fn top_n_levels(&self, side: Side, depth: usize) -> Vec<&PriceLevel> {
        self.iter_side(side).take(depth).collect()
    }

    /// Compute imbalance from the top of book up to `depth` levels.
    #[must_use]
    pub fn imbalance(&self, depth: usize) -> Imbalance {
        Imbalance::compute(self, depth)
    }

    /// Returns whether the book is currently crossed. Should always be
    /// `false` outside the matcher's hot path; if it ever returns
    /// `true` in a snapshot, something is wrong — alarm.
    #[must_use]
    pub fn is_crossed(&self) -> bool {
        match self.bbo() {
            (Some(b), Some(a)) => a < b,
            _ => false,
        }
    }

    /// Total quantity resting on a side.
    #[must_use]
    pub fn total_visible_qty(&self, side: Side) -> Quantity {
        let mut sum = Quantity::ZERO;
        for lvl in self.iter_side(side) {
            sum += lvl.visible_qty();
        }
        sum
    }

    /// Mutable access to a specific level. Internal use only.
    pub fn level_mut(&mut self, side: Side, price: Price) -> Option<&mut PriceLevel> {
        match side {
            Side::Buy => self.bids.get_mut(&price),
            Side::Sell => self.asks.get_mut(&price),
        }
    }

    /// Internal: how many orders are currently resting in total. Used
    /// by stats and capacity probes.
    #[must_use]
    pub fn order_count(&self) -> usize {
        let bids: usize = self.bids.values().map(PriceLevel::len).sum();
        let asks: usize = self.asks.values().map(PriceLevel::len).sum();
        bids + asks
    }
}

#[cfg(test)]
mod tests {
    use meridian_common::prelude::*;
    use meridian_order_types::OrderType;
    use rust_decimal_macros::dec;

    use super::*;

    fn ord(id: u128, side: Side, price: Price, qty: Quantity, seq: u64) -> RestingOrder {
        RestingOrder {
            order_id: OrderId::new(id),
            account_id: AccountId::new(1),
            side,
            order_type: OrderType::Limit,
            leaves_qty: qty,
            display_qty: None,
            hidden_qty: None,
            price,
            priority_seq: SeqNo::new(seq),
            post_only: false,
        }
    }

    fn sym() -> Symbol {
        Symbol::new("BTC-USD").unwrap()
    }

    #[test]
    fn empty_book_has_no_bbo() {
        let b = Book::new(sym());
        assert_eq!(b.bbo(), (None, None));
        assert!(!b.is_crossed());
    }

    #[test]
    fn insert_orders_yield_correct_bbo() {
        let mut b = Book::new(sym());
        b.insert(ord(
            1,
            Side::Buy,
            Price::from_decimal(dec!(99.5)),
            Quantity::from_int(1),
            1,
        ));
        b.insert(ord(
            2,
            Side::Buy,
            Price::from_decimal(dec!(99.6)),
            Quantity::from_int(1),
            2,
        ));
        b.insert(ord(
            3,
            Side::Sell,
            Price::from_decimal(dec!(100.0)),
            Quantity::from_int(1),
            3,
        ));
        b.insert(ord(
            4,
            Side::Sell,
            Price::from_decimal(dec!(100.5)),
            Quantity::from_int(1),
            4,
        ));
        assert_eq!(b.best_bid(), Some(Price::from_decimal(dec!(99.6))));
        assert_eq!(b.best_ask(), Some(Price::from_decimal(dec!(100.0))));
        assert_eq!(b.spread(), Some(Price::from_decimal(dec!(0.4))));
    }

    #[test]
    fn fifo_within_level() {
        let mut b = Book::new(sym());
        b.insert(ord(
            1,
            Side::Buy,
            Price::from_decimal(dec!(100)),
            Quantity::from_int(1),
            1,
        ));
        b.insert(ord(
            2,
            Side::Buy,
            Price::from_decimal(dec!(100)),
            Quantity::from_int(1),
            2,
        ));
        let lvl = b.best_level(Side::Buy).unwrap();
        assert_eq!(lvl.peek_front().unwrap().order_id, OrderId::new(1));
    }

    #[test]
    fn remove_by_id_prunes_empty_level() {
        let mut b = Book::new(sym());
        b.insert(ord(
            1,
            Side::Buy,
            Price::from_decimal(dec!(100)),
            Quantity::from_int(1),
            1,
        ));
        let removed = b.remove(Side::Buy, Price::from_decimal(dec!(100)), OrderId::new(1));
        assert!(removed.is_some());
        assert_eq!(b.level_count(Side::Buy), 0);
    }

    #[test]
    fn reduce_front_eats_qty() {
        let mut b = Book::new(sym());
        b.insert(ord(
            1,
            Side::Buy,
            Price::from_decimal(dec!(100)),
            Quantity::from_int(5),
            1,
        ));
        b.reduce_front(
            Side::Buy,
            Price::from_decimal(dec!(100)),
            Quantity::from_int(3),
        );
        let lvl = b.best_level(Side::Buy).unwrap();
        assert_eq!(lvl.peek_front().unwrap().leaves_qty, Quantity::from_int(2));
    }

    #[test]
    fn mid_price_average() {
        let mut b = Book::new(sym());
        b.insert(ord(
            1,
            Side::Buy,
            Price::from_decimal(dec!(100)),
            Quantity::from_int(1),
            1,
        ));
        b.insert(ord(
            2,
            Side::Sell,
            Price::from_decimal(dec!(102)),
            Quantity::from_int(1),
            2,
        ));
        assert_eq!(b.mid_price(), Some(Price::from_decimal(dec!(101))));
    }

    #[test]
    fn total_visible_qty_aggregates() {
        let mut b = Book::new(sym());
        b.insert(ord(
            1,
            Side::Buy,
            Price::from_decimal(dec!(100)),
            Quantity::from_int(2),
            1,
        ));
        b.insert(ord(
            2,
            Side::Buy,
            Price::from_decimal(dec!(99)),
            Quantity::from_int(3),
            2,
        ));
        assert_eq!(b.total_visible_qty(Side::Buy), Quantity::from_int(5));
    }
}
