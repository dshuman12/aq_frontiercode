//! `RestingOrder` — the per-order record stored in a price level.
//!
//! This is intentionally narrower than `order_types::Order`: only the
//! fields the book needs to reason about. The full order lives in the
//! engine's order map; the book holds a slim handle.

use meridian_common::prelude::*;
use meridian_order_types::{OrderType, Side};

/// What the book stores at each FIFO slot.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RestingOrder {
    pub order_id: OrderId,
    pub account_id: AccountId,
    pub side: Side,
    pub order_type: OrderType,

    /// Total qty still on the book.
    pub leaves_qty: Quantity,

    /// For iceberg: total qty visible in this slice.
    /// `None` for non-iceberg orders.
    pub display_qty: Option<Quantity>,

    /// For iceberg: total hidden qty waiting for refresh.
    /// `None` for non-iceberg orders.
    pub hidden_qty: Option<Quantity>,

    /// Limit price — for the book this is the *resting price*,
    /// which equals the order's limit price for a vanilla limit and
    /// the trigger-snap price for a triggered stop-limit.
    pub price: Price,

    /// Sequencer seq at which the order was *first* assigned this
    /// price. Used as the primary key for time priority.
    pub priority_seq: SeqNo,

    /// Was the order created post-only? (post-only orders that cross
    /// at insert are rejected; the book never sees them. The flag is
    /// retained so the matcher can short-circuit without looking up
    /// the full order.)
    pub post_only: bool,
}

impl RestingOrder {
    /// Visible portion. For iceberg this is `display_qty`; otherwise
    /// `leaves_qty`.
    #[must_use]
    pub fn visible_qty(&self) -> Quantity {
        match self.display_qty {
            Some(d) => d.min(self.leaves_qty),
            None => self.leaves_qty,
        }
    }

    /// True if this is a slice from an iceberg order.
    #[must_use]
    pub const fn is_iceberg(&self) -> bool {
        matches!(self.order_type, OrderType::Iceberg)
    }
}
