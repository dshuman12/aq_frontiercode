//! Imbalance metric — buy-side vs sell-side weighted notional.
//!
//! Used by the volatility-halt detector and the auctions module's
//! indicative price calculator.

use meridian_common::prelude::*;
use meridian_order_types::Side;
use serde::{Deserialize, Serialize};

use crate::book::Book;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct Imbalance {
    pub bid_notional: Notional,
    pub ask_notional: Notional,
    /// Sign convention: positive = bid-heavy, negative = ask-heavy.
    /// Range `[-1, 1]` represented as parts-per-million ([-1_000_000, 1_000_000]).
    pub ratio_ppm: i32,
    pub depth_used: u32,
}

impl Imbalance {
    /// Compute imbalance using up to `depth` levels per side.
    #[must_use]
    pub fn compute(book: &Book, depth: usize) -> Self {
        let mut bid = Notional::ZERO;
        let mut ask = Notional::ZERO;

        for lvl in book.iter_side(Side::Buy).take(depth) {
            bid += lvl.price * lvl.visible_qty();
        }
        for lvl in book.iter_side(Side::Sell).take(depth) {
            ask += lvl.price * lvl.visible_qty();
        }

        let total = bid + ask;
        let ratio_ppm = if total.is_zero() {
            0
        } else {
            // (bid - ask) / total scaled to ppm
            let numerator = bid.into_decimal() - ask.into_decimal();
            let total_d = total.into_decimal();
            let scaled = numerator * rust_decimal::Decimal::from(1_000_000) / total_d;
            // saturating cast
            scaled.to_i32_saturating().clamp(-1_000_000, 1_000_000)
        };

        Self {
            bid_notional: bid,
            ask_notional: ask,
            ratio_ppm,
            depth_used: u32::try_from(depth).unwrap_or(u32::MAX),
        }
    }

    /// True if the imbalance is more than `threshold_ppm` bid-heavy.
    #[must_use]
    pub const fn is_bid_heavy(&self, threshold_ppm: i32) -> bool {
        self.ratio_ppm >= threshold_ppm
    }

    /// True if the imbalance is more than `threshold_ppm` ask-heavy.
    #[must_use]
    pub const fn is_ask_heavy(&self, threshold_ppm: i32) -> bool {
        self.ratio_ppm <= -threshold_ppm
    }
}

trait ToI32Saturating {
    fn to_i32_saturating(self) -> i32;
}

impl ToI32Saturating for rust_decimal::Decimal {
    fn to_i32_saturating(self) -> i32 {
        use rust_decimal::prelude::ToPrimitive;
        // We tolerate truncation here; we already clamp afterwards.
        self.to_i32().unwrap_or_else(|| {
            if self.is_sign_negative() {
                i32::MIN
            } else {
                i32::MAX
            }
        })
    }
}
