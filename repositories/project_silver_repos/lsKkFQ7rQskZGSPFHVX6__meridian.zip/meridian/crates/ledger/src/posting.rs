//! Helpers that turn a `Fill` into balanced ledger entries.

use meridian_common::prelude::*;
use meridian_order_types::{Fill, Side};
use rust_decimal::Decimal;

use crate::entry::{Direction, Entry, EntryId};
use crate::error::{LedgerError, LedgerResult};
use crate::store::Ledger;

/// One fill produces several entries — bundled into this struct so the
/// caller can persist them atomically.
#[derive(Debug, Clone)]
pub struct FillPosting {
    pub entries: Vec<Entry>,
}

impl FillPosting {
    /// Sanity check: debits == credits per currency.
    pub fn validate(&self) -> LedgerResult<()> {
        let mut by_ccy: std::collections::HashMap<&str, (Decimal, Decimal)> =
            std::collections::HashMap::new();
        for e in &self.entries {
            let entry = by_ccy
                .entry(e.currency.as_str())
                .or_insert((Decimal::ZERO, Decimal::ZERO));
            match e.direction {
                Direction::Debit => entry.0 += e.amount,
                Direction::Credit => entry.1 += e.amount,
            }
        }
        for (_, (d, c)) in by_ccy {
            if d != c {
                return Err(LedgerError::Unbalanced {
                    debits: d.to_string(),
                    credits: c.to_string(),
                });
            }
        }
        Ok(())
    }
}

/// Build the postings for a single trade.
///
/// `base_ccy` and `quote_ccy` come from the symbol's instrument record.
/// `taker_account` and `maker_account` are the customer-account ids
/// in the ledger (string-keyed, distinct from the trading-account IDs).
pub fn post_fill(
    fill: &Fill,
    base_ccy: &str,
    quote_ccy: &str,
    taker_ledger_acct: &str,
    maker_ledger_acct: &str,
    fee_revenue_acct: &str,
    at: Timestamp,
) -> FillPosting {
    let notional = fill.notional().into_decimal();
    let qty = fill.quantity.into_decimal();

    // The base-asset half. Taker receives base if taker is the buyer
    // (maker's side is opposite).
    let (base_to_taker, base_from_maker) = match fill.maker_side {
        Side::Sell => (true, true),  // taker is buyer
        Side::Buy => (false, false), // taker is seller
    };

    let _ = (base_from_maker, base_to_taker);

    let trade_ref = fill.trade_id.to_string();
    let mut entries = Vec::with_capacity(8);

    // Base leg.
    entries.push(Entry {
        id: EntryId::new((fill.trade_id.raw() << 4) | 1),
        account_id: taker_ledger_acct.to_string(),
        direction: if base_to_taker {
            Direction::Debit
        } else {
            Direction::Credit
        },
        amount: qty,
        currency: base_ccy.to_string(),
        at,
        memo: format!("trade {} base", fill.trade_id),
        reference: trade_ref.clone(),
    });
    entries.push(Entry {
        id: EntryId::new((fill.trade_id.raw() << 4) | 2),
        account_id: maker_ledger_acct.to_string(),
        direction: if base_to_taker {
            Direction::Credit
        } else {
            Direction::Debit
        },
        amount: qty,
        currency: base_ccy.to_string(),
        at,
        memo: format!("trade {} base", fill.trade_id),
        reference: trade_ref.clone(),
    });

    // Quote leg — opposite direction.
    entries.push(Entry {
        id: EntryId::new((fill.trade_id.raw() << 4) | 3),
        account_id: taker_ledger_acct.to_string(),
        direction: if base_to_taker {
            Direction::Credit
        } else {
            Direction::Debit
        },
        amount: notional,
        currency: quote_ccy.to_string(),
        at,
        memo: format!("trade {} quote", fill.trade_id),
        reference: trade_ref.clone(),
    });
    entries.push(Entry {
        id: EntryId::new((fill.trade_id.raw() << 4) | 4),
        account_id: maker_ledger_acct.to_string(),
        direction: if base_to_taker {
            Direction::Debit
        } else {
            Direction::Credit
        },
        amount: notional,
        currency: quote_ccy.to_string(),
        at,
        memo: format!("trade {} quote", fill.trade_id),
        reference: trade_ref.clone(),
    });

    // Fees. Negative fee = rebate (we pay out, account is credited
    // and revenue is debited).
    let taker_fee = fill.taker_fee.into_decimal();
    if !taker_fee.is_zero() {
        let (acct_dir, rev_dir) = if taker_fee.is_sign_positive() {
            (Direction::Credit, Direction::Debit) // we collect from taker
        } else {
            (Direction::Debit, Direction::Credit) // we pay rebate
        };
        let abs = taker_fee.abs();
        entries.push(Entry {
            id: EntryId::new((fill.trade_id.raw() << 4) | 5),
            account_id: taker_ledger_acct.to_string(),
            direction: acct_dir,
            amount: abs,
            currency: quote_ccy.to_string(),
            at,
            memo: format!("trade {} taker fee", fill.trade_id),
            reference: trade_ref.clone(),
        });
        entries.push(Entry {
            id: EntryId::new((fill.trade_id.raw() << 4) | 6),
            account_id: fee_revenue_acct.to_string(),
            direction: rev_dir,
            amount: abs,
            currency: quote_ccy.to_string(),
            at,
            memo: format!("trade {} taker fee", fill.trade_id),
            reference: trade_ref.clone(),
        });
    }
    let maker_fee = fill.maker_fee.into_decimal();
    if !maker_fee.is_zero() {
        let (acct_dir, rev_dir) = if maker_fee.is_sign_positive() {
            (Direction::Credit, Direction::Debit)
        } else {
            (Direction::Debit, Direction::Credit)
        };
        let abs = maker_fee.abs();
        entries.push(Entry {
            id: EntryId::new((fill.trade_id.raw() << 4) | 7),
            account_id: maker_ledger_acct.to_string(),
            direction: acct_dir,
            amount: abs,
            currency: quote_ccy.to_string(),
            at,
            memo: format!("trade {} maker fee", fill.trade_id),
            reference: trade_ref.clone(),
        });
        entries.push(Entry {
            id: EntryId::new((fill.trade_id.raw() << 4) | 8),
            account_id: fee_revenue_acct.to_string(),
            direction: rev_dir,
            amount: abs,
            currency: quote_ccy.to_string(),
            at,
            memo: format!("trade {} maker fee", fill.trade_id),
            reference: trade_ref,
        });
    }

    FillPosting { entries }
}

/// Move an arbitrary amount between two accounts.
pub fn post_transfer(
    from: &str,
    to: &str,
    amount: Decimal,
    currency: &str,
    memo: &str,
    reference: &str,
    at: Timestamp,
    id_seed: u128,
) -> FillPosting {
    let entries = vec![
        Entry {
            id: EntryId::new(id_seed << 1),
            account_id: from.to_string(),
            direction: Direction::Credit,
            amount,
            currency: currency.to_string(),
            at,
            memo: memo.to_string(),
            reference: reference.to_string(),
        },
        Entry {
            id: EntryId::new((id_seed << 1) | 1),
            account_id: to.to_string(),
            direction: Direction::Debit,
            amount,
            currency: currency.to_string(),
            at,
            memo: memo.to_string(),
            reference: reference.to_string(),
        },
    ];
    FillPosting { entries }
}

/// Apply an already-validated posting to a Ledger.
pub fn apply(ledger: &Ledger, posting: &FillPosting) -> LedgerResult<()> {
    posting.validate()?;
    for entry in &posting.entries {
        ledger.post(entry.clone())?;
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use chrono::Utc;
    use meridian_order_types::{FillKind, Side};
    use rust_decimal_macros::dec;

    use super::*;

    fn fill() -> Fill {
        Fill {
            trade_id: TradeId::new(0xCAFE),
            exec_id: ExecId::new(0xCAFE_0001),
            symbol: Symbol::new("BTC-USD").unwrap(),
            kind: FillKind::Trade,
            price: Price::from_decimal(dec!(100)),
            quantity: Quantity::from_int(2),
            maker_order_id: OrderId::new(1),
            taker_order_id: OrderId::new(2),
            maker_account: AccountId::new(1),
            taker_account: AccountId::new(2),
            maker_side: Side::Sell,
            maker_fee: Fee::from_decimal(dec!(0.1)),
            taker_fee: Fee::from_decimal(dec!(0.4)),
            at: Timestamp::from_datetime(Utc::now()),
            seq_no: MdSeqNo::new(1),
        }
    }

    #[test]
    fn fill_posting_balances_per_currency() {
        let f = fill();
        let p = post_fill(
            &f,
            "BTC",
            "USD",
            "cust:taker",
            "cust:maker",
            "rev:fees",
            f.at,
        );
        p.validate().unwrap();
    }
}
