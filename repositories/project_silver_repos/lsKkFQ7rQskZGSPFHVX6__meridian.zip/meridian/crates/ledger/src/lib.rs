// Ledger — the source of truth for "who owns what".
//
// Double-entry. Every fill produces:
//
//   debit  taker.base   credit maker.base   (qty in base)
//   debit  maker.quote  credit taker.quote  (qty * price in quote)
//   debit  taker.fee    credit fees         (taker fee in quote)
//   debit  maker.fee    credit fees         (maker fee, can be a rebate → reverses)
//
// All entries are signed and integer-arithmetic-clean. We never round
// inside the ledger; rounding happens at the boundary (fee bps -> Fee
// in `ref-data`). Aggregates can drift if rounding leaks; that would
// be a CRITICAL alarm.

#![forbid(unsafe_code)]
#![deny(rust_2018_idioms)]
#![allow(
    clippy::pedantic,
    clippy::nursery,
    missing_debug_implementations,
    missing_docs
)]
#![allow(
    clippy::module_name_repetitions,
    clippy::missing_errors_doc,
    clippy::missing_panics_doc,
    clippy::must_use_candidate
)]

//! Ledger crate.

pub mod entry;
pub mod error;
pub mod posting;
pub mod store;

pub use entry::{Account as LedgerAccount, AccountKind, Direction, Entry, EntryId};
pub use error::{LedgerError, LedgerResult};
pub use posting::{post_fill, post_transfer, FillPosting};
pub use store::Ledger;
