//! Ledger primitives.

use meridian_common::prelude::*;
use rust_decimal::Decimal;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum AccountKind {
    /// Owned by an external account (a customer).
    Customer,
    /// Internal — fees collected, segregation, etc.
    Internal,
    /// Liability — the venue's "we owe this back" accounts.
    Liability,
    /// Equity — the venue's own books.
    Equity,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Account {
    pub id: String,
    pub kind: AccountKind,
    pub owner: Option<AccountId>,
    pub currency: String,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Direction {
    Debit,
    Credit,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(transparent)]
pub struct EntryId(pub u128);

impl EntryId {
    #[must_use]
    pub const fn new(v: u128) -> Self {
        Self(v)
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Entry {
    pub id: EntryId,
    pub account_id: String,
    pub direction: Direction,
    pub amount: Decimal,
    pub currency: String,
    pub at: Timestamp,
    pub memo: String,
    /// Reference to the originating event — fill id, transfer id, etc.
    pub reference: String,
}

impl Entry {
    /// Signed amount: debit increases, credit decreases for asset
    /// accounts; the convention reverses for liability/equity. Each
    /// caller knows which sign convention it wants; this helper just
    /// gives debits a positive sign and credits negative.
    #[must_use]
    pub fn signed_debit(&self) -> Decimal {
        match self.direction {
            Direction::Debit => self.amount,
            Direction::Credit => -self.amount,
        }
    }
}
