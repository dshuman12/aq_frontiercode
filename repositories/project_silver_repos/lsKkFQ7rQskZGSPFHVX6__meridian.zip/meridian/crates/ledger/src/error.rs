//! Ledger errors.

use thiserror::Error;

pub type LedgerResult<T> = Result<T, LedgerError>;

#[derive(Debug, Error)]
pub enum LedgerError {
    #[error("unbalanced posting: debits {debits} != credits {credits}")]
    Unbalanced { debits: String, credits: String },

    #[error(
        "insufficient balance: account {account}, requested {requested}, available {available}"
    )]
    InsufficientBalance {
        account: String,
        requested: String,
        available: String,
    },

    #[error("unknown account: {0}")]
    UnknownAccount(String),

    #[error("currency mismatch: expected {expected}, got {actual}")]
    CurrencyMismatch { expected: String, actual: String },

    #[error("idempotent replay: entry id {0} already posted")]
    DuplicateEntry(String),

    #[error(transparent)]
    Common(#[from] meridian_common::Error),
}
