//! In-memory ledger.
//!
//! Production swaps this for the Postgres-backed implementation gated
//! behind the `postgres` feature; the trait and the in-memory impl
//! are kept for tests + small deployments + replay.

use std::collections::HashMap;

use parking_lot::RwLock;
use rust_decimal::Decimal;

use crate::entry::{Account, Direction, Entry, EntryId};
use crate::error::{LedgerError, LedgerResult};

#[derive(Debug, Default)]
pub struct Ledger {
    accounts: RwLock<HashMap<String, Account>>,
    /// Per-(account, ccy) → balance.
    balances: RwLock<HashMap<(String, String), Decimal>>,
    /// Idempotency log: every entry id seen so far.
    seen: RwLock<std::collections::HashSet<EntryId>>,
}

impl Ledger {
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    pub fn upsert_account(&self, a: Account) {
        self.accounts.write().insert(a.id.clone(), a);
    }

    pub fn account(&self, id: &str) -> Option<Account> {
        self.accounts.read().get(id).cloned()
    }

    pub fn balance(&self, account_id: &str, currency: &str) -> Decimal {
        self.balances
            .read()
            .get(&(account_id.to_string(), currency.to_string()))
            .copied()
            .unwrap_or(Decimal::ZERO)
    }

    /// Record one entry. Idempotent on `entry.id`.
    pub fn post(&self, entry: Entry) -> LedgerResult<()> {
        {
            let mut seen = self.seen.write();
            if !seen.insert(entry.id) {
                return Err(LedgerError::DuplicateEntry(format!("{:?}", entry.id)));
            }
        }
        // Validate account exists.
        if !self.accounts.read().contains_key(&entry.account_id) {
            return Err(LedgerError::UnknownAccount(entry.account_id.clone()));
        }

        let key = (entry.account_id.clone(), entry.currency.clone());
        let mut g = self.balances.write();
        let cur = g.entry(key).or_insert(Decimal::ZERO);
        match entry.direction {
            Direction::Debit => *cur += entry.amount,
            Direction::Credit => *cur -= entry.amount,
        }
        Ok(())
    }

    /// Total balances per currency across all accounts. Should sum to
    /// zero when the ledger is healthy (we count both sides of every
    /// trade).
    pub fn total_per_currency(&self) -> HashMap<String, Decimal> {
        let mut out = HashMap::new();
        for ((_, ccy), v) in self.balances.read().iter() {
            *out.entry(ccy.clone()).or_insert(Decimal::ZERO) += v;
        }
        out
    }
}

#[cfg(test)]
mod tests {
    use chrono::Utc;
    use meridian_common::prelude::*;
    use rust_decimal_macros::dec;

    use crate::entry::AccountKind;

    use super::*;

    fn ts() -> Timestamp {
        Timestamp::from_datetime(Utc::now())
    }

    fn acct(id: &str, currency: &str) -> Account {
        Account {
            id: id.to_string(),
            kind: AccountKind::Customer,
            owner: None,
            currency: currency.to_string(),
        }
    }

    #[test]
    fn debit_increases_credit_decreases() {
        let l = Ledger::new();
        l.upsert_account(acct("a", "USD"));
        l.post(Entry {
            id: EntryId::new(1),
            account_id: "a".into(),
            direction: Direction::Debit,
            amount: dec!(100),
            currency: "USD".into(),
            at: ts(),
            memo: "".into(),
            reference: "".into(),
        })
        .unwrap();
        assert_eq!(l.balance("a", "USD"), dec!(100));
        l.post(Entry {
            id: EntryId::new(2),
            account_id: "a".into(),
            direction: Direction::Credit,
            amount: dec!(30),
            currency: "USD".into(),
            at: ts(),
            memo: "".into(),
            reference: "".into(),
        })
        .unwrap();
        assert_eq!(l.balance("a", "USD"), dec!(70));
    }

    #[test]
    fn duplicate_entry_id_rejected() {
        let l = Ledger::new();
        l.upsert_account(acct("a", "USD"));
        let e = Entry {
            id: EntryId::new(1),
            account_id: "a".into(),
            direction: Direction::Debit,
            amount: dec!(1),
            currency: "USD".into(),
            at: ts(),
            memo: "".into(),
            reference: "".into(),
        };
        l.post(e.clone()).unwrap();
        assert!(matches!(l.post(e), Err(LedgerError::DuplicateEntry(_))));
    }

    #[test]
    fn unknown_account_rejected() {
        let l = Ledger::new();
        let e = Entry {
            id: EntryId::new(1),
            account_id: "ghost".into(),
            direction: Direction::Debit,
            amount: dec!(1),
            currency: "USD".into(),
            at: ts(),
            memo: "".into(),
            reference: "".into(),
        };
        assert!(matches!(l.post(e), Err(LedgerError::UnknownAccount(_))));
    }
}
