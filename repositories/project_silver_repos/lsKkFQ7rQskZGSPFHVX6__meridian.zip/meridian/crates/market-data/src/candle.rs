//! Candle aggregation.
//!
//! Open / High / Low / Close / Volume per resolution, indexed by
//! the bucket's start time. We anchor buckets to UTC midnight; for
//! venues with a session-local close, an external service rebases.

use std::collections::HashMap;
use std::time::Duration;

use meridian_common::prelude::*;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum CandleResolution {
    OneMinute,
    FiveMinute,
    FifteenMinute,
    OneHour,
    FourHour,
    OneDay,
}

impl CandleResolution {
    #[must_use]
    pub const fn duration(self) -> Duration {
        match self {
            Self::OneMinute => Duration::from_secs(60),
            Self::FiveMinute => Duration::from_secs(300),
            Self::FifteenMinute => Duration::from_secs(900),
            Self::OneHour => Duration::from_secs(3600),
            Self::FourHour => Duration::from_secs(14_400),
            Self::OneDay => Duration::from_secs(86_400),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Candle {
    pub bucket_start: Timestamp,
    pub resolution: CandleResolution,
    pub open: Price,
    pub high: Price,
    pub low: Price,
    pub close: Price,
    pub volume: Quantity,
    pub trade_count: u32,
}

impl Candle {
    #[must_use]
    pub fn new_first(
        bucket_start: Timestamp,
        resolution: CandleResolution,
        price: Price,
        qty: Quantity,
    ) -> Self {
        Self {
            bucket_start,
            resolution,
            open: price,
            high: price,
            low: price,
            close: price,
            volume: qty,
            trade_count: 1,
        }
    }

    pub fn extend(&mut self, price: Price, qty: Quantity) {
        if price > self.high {
            self.high = price;
        }
        if price < self.low {
            self.low = price;
        }
        self.close = price;
        self.volume += qty;
        self.trade_count += 1;
    }
}

/// Per-symbol candle aggregator across all resolutions.
#[derive(Debug, Default)]
pub struct CandleAggregator {
    inner: HashMap<(Symbol, CandleResolution), Candle>,
}

impl CandleAggregator {
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    /// Record a trade. Returns the *previous* candle for any
    /// resolutions that just rolled over.
    pub fn on_trade(
        &mut self,
        symbol: &Symbol,
        at: Timestamp,
        price: Price,
        qty: Quantity,
        resolutions: &[CandleResolution],
    ) -> Vec<Candle> {
        let mut closed = Vec::new();
        for &r in resolutions {
            let bucket = at.floor_to(r.duration());
            let key = (symbol.clone(), r);
            match self.inner.get_mut(&key) {
                None => {
                    self.inner
                        .insert(key, Candle::new_first(bucket, r, price, qty));
                },
                Some(existing) if existing.bucket_start == bucket => {
                    existing.extend(price, qty);
                },
                Some(existing) => {
                    closed.push(existing.clone());
                    *existing = Candle::new_first(bucket, r, price, qty);
                },
            }
        }
        closed
    }

    pub fn current(&self, symbol: &Symbol, r: CandleResolution) -> Option<&Candle> {
        self.inner.get(&(symbol.clone(), r))
    }
}

#[cfg(test)]
mod tests {
    use rust_decimal_macros::dec;

    use super::*;

    fn sym() -> Symbol {
        Symbol::new("BTC-USD").unwrap()
    }

    #[test]
    fn extends_within_bucket_and_closes_on_roll() {
        let mut a = CandleAggregator::new();
        let t0 = Timestamp::from_unix_nanos(1_700_000_040_000_000_000);
        let t1 = Timestamp::from_unix_nanos(1_700_000_099_000_000_000); // same minute
        let t2 = Timestamp::from_unix_nanos(1_700_000_100_000_000_000); // next minute

        let _ = a.on_trade(
            &sym(),
            t0,
            Price::from_decimal(dec!(100)),
            Quantity::from_int(1),
            &[CandleResolution::OneMinute],
        );
        let _ = a.on_trade(
            &sym(),
            t1,
            Price::from_decimal(dec!(105)),
            Quantity::from_int(2),
            &[CandleResolution::OneMinute],
        );
        let closed = a.on_trade(
            &sym(),
            t2,
            Price::from_decimal(dec!(102)),
            Quantity::from_int(3),
            &[CandleResolution::OneMinute],
        );
        assert_eq!(closed.len(), 1);
        assert_eq!(closed[0].open, Price::from_decimal(dec!(100)));
        assert_eq!(closed[0].high, Price::from_decimal(dec!(105)));
        assert_eq!(closed[0].close, Price::from_decimal(dec!(105)));
        assert_eq!(closed[0].volume, Quantity::from_int(3));
    }
}
