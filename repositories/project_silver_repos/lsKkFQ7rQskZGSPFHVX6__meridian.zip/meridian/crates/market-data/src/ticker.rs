//! 24h ticker — rolling stats per symbol.

use std::collections::VecDeque;
use std::time::Duration;

use meridian_common::prelude::*;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct Ticker {
    pub last_price: Price,
    pub price_24h_ago: Price,
    pub change_24h: rust_decimal::Decimal,
    pub volume_24h: Quantity,
    pub high_24h: Price,
    pub low_24h: Price,
    pub trade_count_24h: u32,
}

#[derive(Debug, Clone, Copy)]
struct Print {
    at: Timestamp,
    price: Price,
    qty: Quantity,
}

#[derive(Debug)]
pub struct TickerWindow {
    window: Duration,
    prints: VecDeque<Print>,
}

impl TickerWindow {
    #[must_use]
    pub fn new(window: Duration) -> Self {
        Self {
            window,
            prints: VecDeque::with_capacity(8 * 1024),
        }
    }

    /// Default 24h window.
    #[must_use]
    pub fn day() -> Self {
        Self::new(Duration::from_secs(86_400))
    }

    pub fn record(&mut self, at: Timestamp, price: Price, qty: Quantity) {
        // Drop expired prints from the front.
        let cutoff_ns = at.unix_nanos() - i64::try_from(self.window.as_nanos()).unwrap_or(i64::MAX);
        while let Some(front) = self.prints.front() {
            if front.at.unix_nanos() < cutoff_ns {
                self.prints.pop_front();
            } else {
                break;
            }
        }
        self.prints.push_back(Print { at, price, qty });
    }

    #[must_use]
    pub fn ticker(&self) -> Option<Ticker> {
        let last = self.prints.back()?;
        let first = self.prints.front()?;
        let mut high = first.price;
        let mut low = first.price;
        let mut volume = Quantity::ZERO;
        for p in &self.prints {
            if p.price > high {
                high = p.price;
            }
            if p.price < low {
                low = p.price;
            }
            volume += p.qty;
        }
        let change = if first.price.is_zero() {
            rust_decimal::Decimal::ZERO
        } else {
            (last.price.into_decimal() - first.price.into_decimal()) / first.price.into_decimal()
                * rust_decimal::Decimal::from(100)
        };
        Some(Ticker {
            last_price: last.price,
            price_24h_ago: first.price,
            change_24h: change,
            volume_24h: volume,
            high_24h: high,
            low_24h: low,
            trade_count_24h: u32::try_from(self.prints.len()).unwrap_or(u32::MAX),
        })
    }
}

#[cfg(test)]
mod tests {
    use rust_decimal_macros::dec;

    use super::*;

    fn ts(s: i64) -> Timestamp {
        Timestamp::from_unix_nanos(s * 1_000_000_000)
    }

    #[test]
    fn rolling_window_evicts_old() {
        let mut t = TickerWindow::new(Duration::from_secs(10));
        t.record(ts(0), Price::from_decimal(dec!(100)), Quantity::from_int(1));
        t.record(
            ts(20),
            Price::from_decimal(dec!(110)),
            Quantity::from_int(2),
        );
        let tk = t.ticker().unwrap();
        // Only the second print survives.
        assert_eq!(tk.last_price, Price::from_decimal(dec!(110)));
        assert_eq!(tk.price_24h_ago, Price::from_decimal(dec!(110)));
    }

    #[test]
    fn change_pct_computed() {
        let mut t = TickerWindow::new(Duration::from_secs(86_400));
        t.record(ts(0), Price::from_decimal(dec!(100)), Quantity::from_int(1));
        t.record(
            ts(60),
            Price::from_decimal(dec!(110)),
            Quantity::from_int(1),
        );
        let tk = t.ticker().unwrap();
        assert_eq!(tk.change_24h, dec!(10));
    }
}
