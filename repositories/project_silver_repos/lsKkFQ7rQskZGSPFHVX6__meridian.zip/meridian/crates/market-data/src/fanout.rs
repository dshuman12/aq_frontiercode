//! Subscription fanout.
//!
//! A naive `tokio::sync::broadcast` works for trade tape and ticker,
//! but not for L2 (where late subscribers need a snapshot first).
//! `Fanout` glues a snapshot path to a delta stream so consumers can
//! "subscribe" and immediately get a coherent view.

use std::collections::HashMap;
use std::sync::Arc;

use parking_lot::RwLock;
use tokio::sync::broadcast;

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct Channel {
    pub kind: ChannelKind,
    pub symbol: String,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum ChannelKind {
    Trades,
    Depth,
    Ticker,
    Candles,
}

#[derive(Debug)]
pub struct Subscription<T: Clone + Send + 'static> {
    pub initial_snapshot: Option<T>,
    pub stream: broadcast::Receiver<T>,
}

#[derive(Debug)]
struct Channelled<T: Clone + Send + 'static> {
    sender: broadcast::Sender<T>,
    snapshot: RwLock<Option<T>>,
}

#[derive(Debug)]
pub struct Fanout<T: Clone + Send + 'static> {
    channels: RwLock<HashMap<Channel, Arc<Channelled<T>>>>,
    capacity: usize,
}

impl<T: Clone + Send + 'static> Fanout<T> {
    #[must_use]
    pub fn new(capacity: usize) -> Self {
        Self {
            channels: RwLock::new(HashMap::new()),
            capacity,
        }
    }

    /// Publish to a channel. Creates the channel if it doesn't exist.
    /// `snapshot` is the new "subscribe-time" view; pass `None` to
    /// keep the previous one.
    pub fn publish(&self, ch: Channel, value: T, snapshot: Option<T>) {
        let entry = {
            let mut g = self.channels.write();
            g.entry(ch.clone())
                .or_insert_with(|| {
                    let (tx, _) = broadcast::channel(self.capacity);
                    Arc::new(Channelled {
                        sender: tx,
                        snapshot: RwLock::new(None),
                    })
                })
                .clone()
        };
        if let Some(s) = snapshot {
            *entry.snapshot.write() = Some(s);
        }
        let _ = entry.sender.send(value); // ignore lagging receivers
    }

    /// Subscribe to a channel.
    #[must_use]
    pub fn subscribe(&self, ch: &Channel) -> Subscription<T> {
        let entry = {
            let mut g = self.channels.write();
            g.entry(ch.clone())
                .or_insert_with(|| {
                    let (tx, _) = broadcast::channel(self.capacity);
                    Arc::new(Channelled {
                        sender: tx,
                        snapshot: RwLock::new(None),
                    })
                })
                .clone()
        };
        let snap = entry.snapshot.read().clone();
        let stream = entry.sender.subscribe();
        Subscription {
            initial_snapshot: snap,
            stream,
        }
    }

    pub fn channel_count(&self) -> usize {
        self.channels.read().len()
    }
}
