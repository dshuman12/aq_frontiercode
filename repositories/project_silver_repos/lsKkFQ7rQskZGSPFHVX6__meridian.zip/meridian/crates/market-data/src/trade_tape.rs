//! Public trade tape — the prints, in order.
//!
//! We expose only the fields a non-counterparty needs: trade id,
//! symbol, price, qty, taker side, timestamp. Account ids and fees
//! are stripped. Most clients consume this; only authenticated
//! account-feeds get the rest.

use meridian_common::prelude::*;
use meridian_order_types::{Fill, Side};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Trade {
    pub trade_id: TradeId,
    pub symbol: Symbol,
    pub price: Price,
    pub quantity: Quantity,
    /// Side of the *taker* — the one that crossed the spread. UI uses
    /// this to colour the print up/down.
    pub taker_side: Side,
    pub at: Timestamp,
    pub seq_no: MdSeqNo,
}

impl From<&Fill> for Trade {
    fn from(f: &Fill) -> Self {
        Self {
            trade_id: f.trade_id,
            symbol: f.symbol.clone(),
            price: f.price,
            quantity: f.quantity,
            // taker_side is the opposite of maker_side
            taker_side: f.maker_side.opposite(),
            at: f.at,
            seq_no: f.seq_no,
        }
    }
}

/// Bounded ring of recent trades. The market-data fanout keeps one
/// per symbol so late subscribers can backfill.
#[derive(Debug)]
pub struct TradeTape {
    capacity: usize,
    inner: std::collections::VecDeque<Trade>,
}

impl TradeTape {
    #[must_use]
    pub fn new(capacity: usize) -> Self {
        Self {
            capacity,
            inner: std::collections::VecDeque::with_capacity(capacity),
        }
    }

    pub fn push(&mut self, t: Trade) {
        if self.inner.len() == self.capacity {
            self.inner.pop_front();
        }
        self.inner.push_back(t);
    }

    pub fn iter(&self) -> impl Iterator<Item = &Trade> {
        self.inner.iter()
    }

    /// Take a snapshot of recent trades, newest first.
    #[must_use]
    pub fn snapshot(&self) -> Vec<Trade> {
        self.inner.iter().rev().cloned().collect()
    }

    #[must_use]
    pub fn len(&self) -> usize {
        self.inner.len()
    }

    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.inner.is_empty()
    }
}

#[cfg(test)]
mod tests {
    use chrono::Utc;
    use meridian_order_types::FillKind;
    use rust_decimal_macros::dec;

    use super::*;

    fn fill() -> Fill {
        Fill {
            trade_id: TradeId::new(1),
            exec_id: ExecId::new(1),
            symbol: Symbol::new("BTC-USD").unwrap(),
            kind: FillKind::Trade,
            price: Price::from_decimal(dec!(100)),
            quantity: Quantity::from_int(1),
            maker_order_id: OrderId::new(1),
            taker_order_id: OrderId::new(2),
            maker_account: AccountId::new(1),
            taker_account: AccountId::new(2),
            maker_side: Side::Sell,
            maker_fee: Fee::ZERO,
            taker_fee: Fee::ZERO,
            at: Timestamp::from_datetime(Utc::now()),
            seq_no: MdSeqNo::new(1),
        }
    }

    #[test]
    fn taker_side_inverts_maker_side() {
        let f = fill();
        let t = Trade::from(&f);
        assert_eq!(t.taker_side, Side::Buy);
    }

    #[test]
    fn ring_evicts_oldest() {
        let mut tape = TradeTape::new(2);
        for i in 0..3 {
            let mut f = fill();
            f.trade_id = TradeId::new(i as u128);
            tape.push(Trade::from(&f));
        }
        assert_eq!(tape.len(), 2);
        let snap = tape.snapshot();
        assert_eq!(snap[0].trade_id, TradeId::new(2));
        assert_eq!(snap[1].trade_id, TradeId::new(1));
    }
}
