// Market data fanout.
//
// Subscribes to a matching engine's event stream, derives:
//
// - L1 (BBO + last trade),
// - L2 (top-N levels, aggregated by price),
// - L3 (full book — every order, MM-only),
// - candles (1m, 5m, 15m, 1h, 1d, by close-on-time),
// - ticker (24h vol, 24h change),
//
// and republishes them on subscription channels for gateways. The
// engine doesn't care about market data; this crate exists so that
// the engine can stay narrow.

#![forbid(unsafe_code)]
#![deny(rust_2018_idioms)]
#![allow(
    clippy::pedantic,
    clippy::nursery,
    missing_debug_implementations,
    missing_docs
)]
#![allow(
    clippy::module_name_repetitions,
    clippy::missing_errors_doc,
    clippy::missing_panics_doc,
    clippy::must_use_candidate,
    clippy::cast_precision_loss,
    clippy::cast_possible_truncation
)]

//! Market data fanout.

pub mod candle;
pub mod depth;
pub mod error;
pub mod fanout;
pub mod ticker;
pub mod trade_tape;

pub use candle::{Candle, CandleAggregator, CandleResolution};
pub use depth::{DepthAggregator, DepthDelta};
pub use error::{MarketDataError, MarketDataResult};
pub use fanout::{Channel, Fanout, Subscription};
pub use ticker::{Ticker, TickerWindow};
pub use trade_tape::{Trade, TradeTape};
