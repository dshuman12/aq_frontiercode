//! L2 depth aggregation.
//!
//! Take the engine's `BookUpdate` events and produce a coalesced
//! delta that downstream subscribers can apply to a maintained book.
//!
//! We coalesce per-second by default (configurable), so a 1000-tick
//! storm at one level only emits the final state at the end of the
//! interval. UIs preferring continuous updates can subscribe to the
//! raw stream instead.

use std::collections::BTreeMap;

use meridian_common::prelude::*;
use meridian_order_types::Side;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct DepthDelta {
    pub symbol: Symbol,
    pub at: Timestamp,
    /// Bids that changed: (price, new_visible_qty). Zero qty means
    /// remove the level.
    pub bids: Vec<(Price, Quantity)>,
    pub asks: Vec<(Price, Quantity)>,
    pub seq_no: MdSeqNo,
}

#[derive(Debug)]
pub struct DepthAggregator {
    symbol: Symbol,
    pending_bids: BTreeMap<Price, Quantity>,
    pending_asks: BTreeMap<Price, Quantity>,
}

impl DepthAggregator {
    #[must_use]
    pub fn new(symbol: Symbol) -> Self {
        Self {
            symbol,
            pending_bids: BTreeMap::new(),
            pending_asks: BTreeMap::new(),
        }
    }

    /// Record a single book change. Multiple changes at the same
    /// price within an interval collapse to the latest qty.
    pub fn record(&mut self, side: Side, price: Price, new_visible_qty: Quantity) {
        let target = match side {
            Side::Buy => &mut self.pending_bids,
            Side::Sell => &mut self.pending_asks,
        };
        target.insert(price, new_visible_qty);
    }

    /// Drain whatever we have into a `DepthDelta`. The result is
    /// non-empty only if there were updates since the last drain.
    pub fn drain(&mut self, at: Timestamp, seq_no: MdSeqNo) -> Option<DepthDelta> {
        if self.pending_bids.is_empty() && self.pending_asks.is_empty() {
            return None;
        }
        let bids = std::mem::take(&mut self.pending_bids).into_iter().collect();
        let asks = std::mem::take(&mut self.pending_asks).into_iter().collect();
        Some(DepthDelta {
            symbol: self.symbol.clone(),
            at,
            bids,
            asks,
            seq_no,
        })
    }
}

#[cfg(test)]
mod tests {
    use chrono::Utc;
    use rust_decimal_macros::dec;

    use super::*;

    fn sym() -> Symbol {
        Symbol::new("BTC-USD").unwrap()
    }

    #[test]
    fn coalesces_same_price() {
        let mut agg = DepthAggregator::new(sym());
        agg.record(
            Side::Buy,
            Price::from_decimal(dec!(100)),
            Quantity::from_int(1),
        );
        agg.record(
            Side::Buy,
            Price::from_decimal(dec!(100)),
            Quantity::from_int(5),
        );
        agg.record(
            Side::Buy,
            Price::from_decimal(dec!(99)),
            Quantity::from_int(2),
        );
        let d = agg
            .drain(Timestamp::from_datetime(Utc::now()), MdSeqNo::new(1))
            .unwrap();
        assert_eq!(d.bids.len(), 2);
        assert!(d
            .bids
            .iter()
            .any(|(p, q)| *p == Price::from_decimal(dec!(100)) && *q == Quantity::from_int(5)));
    }
}
