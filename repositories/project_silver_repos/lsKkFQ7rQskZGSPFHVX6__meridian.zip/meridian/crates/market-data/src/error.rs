//! Market-data errors.

use thiserror::Error;

pub type MarketDataResult<T> = Result<T, MarketDataError>;

#[derive(Debug, Error)]
pub enum MarketDataError {
    #[error("subscription buffer overflow for channel {channel}")]
    BufferOverflow { channel: String },

    #[error("unknown channel: {0}")]
    UnknownChannel(String),

    #[error("snapshot unavailable: {0}")]
    SnapshotUnavailable(String),

    #[error(transparent)]
    Common(#[from] meridian_common::Error),
}
