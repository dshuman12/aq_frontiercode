//! Clearing errors.

use thiserror::Error;

#[derive(Debug, Error)]
pub enum ClearingError {
    #[error("allocation ratios are empty")]
    EmptyAllocation,
    #[error("allocation ratios must sum to 1.0 exactly")]
    InvalidAllocationRatios,
    #[error("missing fee schedule for account {0}")]
    MissingFeeSchedule(String),
    #[error("calendar {0} cannot resolve timezone")]
    InvalidCalendar(String),
    #[error("unknown account {0}")]
    UnknownAccount(String),
    #[error("ledger posting failed: {0}")]
    Ledger(String),
}

pub type ClearingResult<T> = Result<T, ClearingError>;
