//! End-of-day settlement posting.

use meridian_common::prelude::*;
use meridian_ledger::posting;
use meridian_ledger::{FillPosting, Ledger};
use meridian_ref_data::{Calendar, RefDataStore};
use rust_decimal::Decimal;

use crate::error::{ClearingError, ClearingResult};

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct OpenPosition {
    pub account_id: AccountId,
    pub symbol: Symbol,
    pub quantity: Quantity,
    pub mark_price: Price,
    pub avg_entry_price: Price,
}

#[derive(Debug, Clone)]
pub struct SettlementRequest {
    pub calendar_id: String,
    pub positions: Vec<OpenPosition>,
    pub settlement_account: String,
    pub venue_pnl_account: String,
    pub at: Timestamp,
}

#[derive(Debug)]
pub struct SettlementEngine<'a> {
    pub ref_data: &'a RefDataStore,
    pub ledger: &'a Ledger,
}

impl<'a> SettlementEngine<'a> {
    pub fn run(&self, req: &SettlementRequest) -> ClearingResult<Vec<FillPosting>> {
        let calendar = self
            .ref_data
            .calendar(&req.calendar_id)
            .map_err(|_| ClearingError::InvalidCalendar(req.calendar_id.clone()))?;
        ensure_calendar(&calendar)?;

        let mut postings = Vec::new();
        for position in &req.positions {
            let pnl = position_mark_to_market(position);
            if pnl.is_zero() {
                continue;
            }
            let posting = posting::post_transfer(
                &req.venue_pnl_account,
                &format!("acct:{}", position.account_id),
                pnl.abs(),
                "USD",
                &format!("daily settlement {}", position.symbol),
                &format!("settle:{}:{}", position.account_id, position.symbol),
                req.at,
                position.account_id.raw(),
            );
            posting::apply(self.ledger, &posting)
                .map_err(|e| ClearingError::Ledger(e.to_string()))?;
            postings.push(posting);
        }
        Ok(postings)
    }
}

fn ensure_calendar(calendar: &Calendar) -> ClearingResult<()> {
    if calendar.tz().is_none() {
        return Err(ClearingError::InvalidCalendar(calendar.id.clone()));
    }
    Ok(())
}

fn position_mark_to_market(position: &OpenPosition) -> Decimal {
    let mark = position.mark_price.into_decimal();
    let entry = position.avg_entry_price.into_decimal();
    let qty = position.quantity.into_decimal();
    (mark - entry) * qty
}
