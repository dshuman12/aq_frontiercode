//! Trade capture report (FIX 4.4 35=AE semantics).

use meridian_common::prelude::*;
use meridian_order_types::{Fill, FillKind, Side};

#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct TradeCaptureReport {
    pub report_id: String,
    pub trade_id: TradeId,
    pub exec_id: ExecId,
    pub symbol: Symbol,
    pub quantity: Quantity,
    pub price: Price,
    pub notional: Notional,
    pub trade_date: chrono::NaiveDate,
    pub transact_time: Timestamp,
    pub aggressor_side: Side,
    pub liquidity: meridian_order_types::LiquidityRole,
    pub kind: FillKind,
}

impl TradeCaptureReport {
    #[must_use]
    pub fn from_fill(fill: &Fill, as_account: AccountId) -> Self {
        let liquidity = fill
            .role_for(as_account)
            .unwrap_or(meridian_order_types::LiquidityRole::Taker);
        let aggressor_side = fill.maker_side.opposite();
        let dt = fill.at.into_datetime();
        Self {
            report_id: format!("tcr-{}", fill.exec_id),
            trade_id: fill.trade_id,
            exec_id: fill.exec_id,
            symbol: fill.symbol.clone(),
            quantity: fill.quantity,
            price: fill.price,
            notional: fill.notional(),
            trade_date: dt.date_naive(),
            transact_time: fill.at,
            aggressor_side,
            liquidity,
            kind: fill.kind,
        }
    }
}

#[cfg(test)]
mod tests {
    use chrono::Utc;
    use meridian_order_types::{Fill, FillKind, Side};
    use rust_decimal_macros::dec;

    use super::*;

    #[test]
    fn tcr_maps_fill_fields() {
        let fill = Fill {
            trade_id: TradeId::new(12),
            exec_id: ExecId::new(34),
            symbol: Symbol::new("BTC-USD").unwrap(),
            kind: FillKind::Trade,
            price: Price::from_decimal(dec!(100)),
            quantity: Quantity::from_int(2),
            maker_order_id: OrderId::new(1),
            taker_order_id: OrderId::new(2),
            maker_account: AccountId::new(10),
            taker_account: AccountId::new(20),
            maker_side: Side::Sell,
            maker_fee: Fee::ZERO,
            taker_fee: Fee::ZERO,
            at: Timestamp::from_datetime(Utc::now()),
            seq_no: MdSeqNo::new(1),
        };

        let report = TradeCaptureReport::from_fill(&fill, fill.maker_account);
        assert_eq!(report.trade_id, fill.trade_id);
        assert_eq!(report.quantity, fill.quantity);
        assert_eq!(report.liquidity, meridian_order_types::LiquidityRole::Maker);
    }
}
