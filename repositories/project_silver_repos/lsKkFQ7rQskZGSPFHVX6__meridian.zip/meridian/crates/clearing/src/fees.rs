//! Fee computation and posting.

use meridian_common::prelude::*;
use meridian_ledger::posting;
use meridian_ledger::{FillPosting, Ledger};
use meridian_order_types::Fill;
use meridian_ref_data::FeeSchedule;

#[derive(Debug, Clone)]
pub struct FeePostingRequest<'a> {
    pub fill: &'a Fill,
    pub schedule: &'a FeeSchedule,
    pub volume_30d: Notional,
    pub is_maker: bool,
    pub account_ledger_id: &'a str,
    pub fee_revenue_account: &'a str,
    pub at: Timestamp,
}

pub fn post_fee_entry(
    ledger: &Ledger,
    req: FeePostingRequest<'_>,
) -> Result<FillPosting, meridian_ledger::LedgerError> {
    let fee = req
        .schedule
        .fee_for(req.volume_30d, req.fill.notional(), req.is_maker)
        .into_decimal()
        .abs();
    let posting = posting::post_transfer(
        req.account_ledger_id,
        req.fee_revenue_account,
        fee,
        "USD",
        "trade fee",
        &format!("fee:{}", req.fill.exec_id),
        req.at,
        req.fill.exec_id.raw(),
    );
    posting::apply(ledger, &posting)?;
    Ok(posting)
}
