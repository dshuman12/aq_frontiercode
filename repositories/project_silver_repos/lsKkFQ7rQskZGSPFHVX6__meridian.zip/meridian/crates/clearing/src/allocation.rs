//! Block/allocation split from omnibus account to sub-accounts.

use meridian_common::prelude::*;
use meridian_order_types::Fill;
use rust_decimal::Decimal;

use crate::error::{ClearingError, ClearingResult};

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AllocationSlice {
    pub account_id: AccountId,
    pub ratio: Decimal,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AllocationSplit {
    pub account_id: AccountId,
    pub quantity: Quantity,
    pub notional: Notional,
}

pub fn split_fill(fill: &Fill, slices: &[AllocationSlice]) -> ClearingResult<Vec<AllocationSplit>> {
    if slices.is_empty() {
        return Err(ClearingError::EmptyAllocation);
    }
    let ratio_sum: Decimal = slices.iter().map(|s| s.ratio).sum();
    if ratio_sum != Decimal::ONE {
        return Err(ClearingError::InvalidAllocationRatios);
    }

    let total_qty = fill.quantity.into_decimal();
    let mut out = Vec::with_capacity(slices.len());
    let mut allocated_qty = Decimal::ZERO;

    for (idx, slice) in slices.iter().enumerate() {
        let qty = if idx + 1 == slices.len() {
            total_qty - allocated_qty
        } else {
            (total_qty * slice.ratio).floor()
        };
        allocated_qty += qty;
        let q = Quantity::from_decimal(qty);
        out.push(AllocationSplit {
            account_id: slice.account_id,
            quantity: q,
            notional: fill.price * q,
        });
    }
    Ok(out)
}

#[cfg(test)]
mod tests {
    use chrono::Utc;
    use meridian_order_types::{Fill, FillKind, Side};
    use rust_decimal_macros::dec;

    use super::*;

    fn fill() -> Fill {
        Fill {
            trade_id: TradeId::new(1),
            exec_id: ExecId::new(2),
            symbol: Symbol::new("BTC-USD").unwrap(),
            kind: FillKind::Trade,
            price: Price::from_decimal(dec!(100)),
            quantity: Quantity::from_int(10),
            maker_order_id: OrderId::new(1),
            taker_order_id: OrderId::new(2),
            maker_account: AccountId::new(3),
            taker_account: AccountId::new(4),
            maker_side: Side::Sell,
            maker_fee: Fee::ZERO,
            taker_fee: Fee::ZERO,
            at: Timestamp::from_datetime(Utc::now()),
            seq_no: MdSeqNo::new(1),
        }
    }

    #[test]
    fn split_preserves_total_quantity() {
        let splits = split_fill(
            &fill(),
            &[
                AllocationSlice {
                    account_id: AccountId::new(10),
                    ratio: dec!(0.6),
                },
                AllocationSlice {
                    account_id: AccountId::new(11),
                    ratio: dec!(0.4),
                },
            ],
        )
        .unwrap();
        let total: Quantity = splits
            .iter()
            .fold(Quantity::ZERO, |acc, s| acc + s.quantity);
        assert_eq!(total, Quantity::from_int(10));
    }
}
