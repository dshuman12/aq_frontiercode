// Clearing and settlement orchestration.
//
// The matching engine produces fills; clearing turns those into
// externally-consumable records (TCR), account-level allocations,
// settlement postings, and fee postings.

#![forbid(unsafe_code)]
#![deny(rust_2018_idioms)]
#![allow(
    clippy::pedantic,
    clippy::nursery,
    missing_debug_implementations,
    missing_docs
)]
#![allow(
    clippy::module_name_repetitions,
    clippy::missing_errors_doc,
    clippy::missing_panics_doc,
    clippy::must_use_candidate
)]

//! Meridian clearing crate.

pub mod allocation;
pub mod error;
pub mod fees;
pub mod settlement;
pub mod trade_capture;

pub use allocation::{AllocationSlice, AllocationSplit};
pub use error::{ClearingError, ClearingResult};
pub use fees::{post_fee_entry, FeePostingRequest};
pub use settlement::{OpenPosition, SettlementEngine, SettlementRequest};
pub use trade_capture::TradeCaptureReport;
