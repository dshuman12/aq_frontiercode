# Changelog

All notable changes to the Meridian platform are documented here. The
format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and the project adheres to semantic versioning of the *protocol surface*
(REST + WS + FIX). Internal crate versions track the platform tag.

## [0.18.4] - 2026-04-22

### Fixed

- **matching-engine**: pro-rata allocation now routes the lot-size residue to the
  oldest resting order (time-priority leader) rather than discarding it. Fixes
  #2823, where small fills left a sub-lot remainder that was silently dropped.
- **ledger**: prevent double-apply of maker fee rebate when a fill event is
  re-delivered after a sequencer restart. Re-keyed credit records by
  `(symbol, exec_id)` to make idempotency cheap.
- **gateway-fix**: GTD `TimeInForce` orders now expire correctly when the
  current timestamp equals `ExpireTime` (tag 126) exactly. Previously the
  `<=` boundary was off by one microsecond due to a truncation mismatch
  between the FIX timestamp and the engine's nanosecond clock. Fixes #2811.


## [0.18.3] - 2026-03-30

### Added

- **auctions**: volatility halt extension — if the indicative cross price moves
  more than `halt_extension_pct` during the final 30 seconds of an auction,
  the auction extends by `halt_extension_secs` (configurable; default 60 s).
  Prevents momentum-driven crosses from printing at extreme prices.

### Fixed

- **risk-engine**: `mid_price` fallback now uses last-trade price when the BBO
  is one-sided (no bid or no ask). Previously fell back to zero, triggering
  false margin breaches during one-sided markets.




## [0.18.2] - 2026-02-18

### Fixed

- **sequencer**: snapshot replay is now safe across log rotation boundaries.
  Previously a race between the snapshot writer and the log rotator could leave
  a partial record at the start of the new segment, causing CRC failures on
  recovery. Fixes #2754.




## [0.18.1] - 2026-01-29

### Fixed

- **gateway-ws**: `book` and `ticker` channels now return the last valid
  snapshot for symbols that are in a halt state, rather than an empty object.
  Clients were receiving `{}` during the halt window, which some interpreted as
  a symbol removal. Fixes #2602.




## [0.18.0] - 2026-01-08

### Added

- **matching-engine**: pro-rata allocation policy (`AllocationPolicy::ProRata`).
  Fills at a price level are distributed proportionally to resting quantity.
  Largest-remainder method ensures every lot is allocated; residue goes to the
  time-priority leader. See ADR-0008.
- **matching-engine**: pegged order type. Peg orders maintain a dynamic price
  offset relative to a configurable reference (best bid, best ask, or mid).
  Repriced at the command edge; lose queue priority on every reprice. See
  ADR-0014.
- **order-types**: `Peg` reference and offset types used by the engine and
  gateway layers.
- **common**: order IDs widened from `u64` to `u128` to accommodate projected
  volume over a 10-year horizon without wrapping.

### Changed

- Workspace version bumped to `0.18.0`.




## [0.17.5] - 2025-11-12

### Fixed

- **matching-engine**: iceberg slice refresh now correctly loses queue priority.
  Previously the refreshed visible slice retained the original `priority_seq`,
  allowing an iceberg to jump ahead of orders that arrived after its last
  refresh. Fixes #2641. See ADR-0012.




## [0.17.4] - 2025-10-04

### Added

- **clearing**: TradeCaptureReport (`AE`) messages are now generated per matched
  fill and routed to the drop-copy FIX session. Institutional clients can
  reconcile positions in real time without polling the REST API.

### Fixed

- **ref-data**: trading calendar DST transition was off by one hour for
  UTC+1 venues on clock-change weekends, causing false "outside trading hours"
  rejections. Fixes #2602.




## [0.17.3] - 2025-08-22

### Fixed

- **risk-engine**: kill-switch activation now cancels in-flight orders that
  arrived at the sequencer before the kill command was stamped. Previously
  those orders could match after the kill was acknowledged, surprising the
  operator.




## [0.17.2] - 2025-07-09

### Fixed

- **gateway-fix**: session now sends `Logout` when the inbound `MsgSeqNum` is
  more than 100 ahead of expected, rather than silently resetting state. This
  prevents a split-brain condition where the client thought the session was
  alive but the gateway had discarded its sequence context.




## [0.17.1] - 2025-06-15

### Fixed

- **gateway-ws**: strip trailing `\r` before computing HMAC pre-image. Some
  clients sent the subscription pre-image with Windows line endings; the
  signature check was failing because the CR was included in the signed string
  but not in the documented pre-image format.




## [0.17.0] - 2025-06-02

### Added

- **gateway-fix**: FIX 4.4 order entry and drop-copy sessions. Supports
  `NewOrderSingle` (D), `OrderCancelRequest` (F), `OrderCancelReplaceRequest`
  (G), `ExecutionReport` (8), `OrderCancelReject` (9), and
  `TradeCaptureReport` (AE). See ADR-0009 and `docs/api/fix-data-dictionary.md`.
- **gateway-fix**: self-trade prevention strategy exposed via FIX tag 7928
  (`SelfTradePreventionStrategy`) per the FIX Trading Community supplement.
- **matching-engine**: `StopBook` — stop and stop-limit orders now trigger off
  last trade price. See ADR-0013.
- **matching-engine**: self-trade prevention with five modes: `None`,
  `CancelNewest`, `CancelOldest`, `DecrementCancel`, `CancelBoth`. See
  ADR-0011.
- **matching-engine**: iceberg orders with configurable visible slice. Refresh
  loses queue priority. See ADR-0012.
- **order-types**: `SelfTradePrevention` enum consumed by engine and all three
  gateways.

### Changed

- Workspace version bumped to `0.17.0`.




## [0.16.x and earlier]
See `git log --grep '^Release v0\.16' -- CHANGELOG.md` for details, or
ask in #platform-eng. Older entries were rebuilt from commit history
during the 0.17 release branch cleanup and may be incomplete.
