# Meridian Exchange Platform

Spot crypto matching engine and the services that surround it: sequencer,
risk gate, ledger, market-data fanout, and three gateways (REST, WebSocket,
FIX 4.4). All of it is one Cargo workspace.

> Internal tooling. Not licensed for redistribution. See `LICENSE`.

## Architecture

Single-writer matching per symbol; sequencer assigns monotonic `seq_no` to
every accepted command before it reaches the engine. Risk gate is the only
thing in front of the engine. Everything downstream reads from the sequenced
event log; nothing writes back.

See `docs/adr/` for the design decisions that got us here.

## Crates

| Crate              | Responsibility                                      |
| ------------------ | --------------------------------------------------- |
| `common`           | shared primitives — IDs, fixed-point money, time    |
| `order-types`      | `Order`, `Side`, `TimeInForce`, validation          |
| `order-book`       | per-symbol price-level book, FIFO at each level     |
| `matching-engine`  | matcher, session state machine, stop triggers       |
| `auctions`         | opening / closing crosses                           |
| `sequencer`        | append-only event log, snapshots, replay            |
| `risk-engine`      | pre-trade risk, fat-finger guard, kill switch       |
| `market-data`      | L1/L2/L3 publishers, OHLCV aggregators              |
| `ledger`           | double-entry ledger, balances, holds                |
| `clearing`         | trade capture, allocation, settlement instructions  |
| `ref-data`         | symbols, calendars, tick / lot tables               |
| `auth`             | API keys, HMAC sigs, RBAC                           |
| `gateway-rest`     | HTTP API (axum)                                     |
| `gateway-ws`       | WebSocket public + private channels                 |
| `gateway-fix`      | FIX 4.4 order entry and drop-copy sessions          |

## Building

```sh
cargo build --workspace --release
```

## License

Proprietary. See [LICENSE](LICENSE).
