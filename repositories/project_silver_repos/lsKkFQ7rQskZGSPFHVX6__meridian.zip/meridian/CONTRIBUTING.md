# Contributing

Internal-only project. This document is the local convention for
people merging code into Meridian's platform repo.

## Branches

- `main` is always shippable and protected. Pushes are gated on CI.
- Feature branches: `<author>/<short-slug>` e.g. `priya/auction-vol-ext`.
- Hotfix branches: `hotfix/<incident-id>-<slug>`.

We squash-merge. Keep your branch reasonably current with `main`; if
your branch is more than 200 commits behind, rebase before review.

## Commit messages

We use a relaxed Conventional-Commits style for the *first line*:

```
<crate-or-area>: <imperative summary, lowercase, no trailing period>

<optional body — paragraphs wrapped at 72>
```

Examples:

```
matching-engine: cancel resting iceberg when STP=DC fires
gateway-fix: handle resend gap > 100 by initiating logout
risk-engine: switch fat-finger ref price to mid+fallback
```

`area` for cross-cutting changes can be `infra`, `ci`, `docs`, `release`.

## Review

Match-path changes require two approvals from `@meridian/matching-engine-owners`
and one from `@meridian/risk` if the change is observable from the
ledger or clearing path. Routine changes only need one.

ADRs are required for:

- changes to the matching algorithm or order-type semantics;
- new fields in the wire protocol (FIX, REST, WS);
- changes to ledger invariants;
- changes that alter the deterministic-replay contract.

Open the ADR as a separate PR ahead of (or alongside) the implementation.
A merged ADR with `Status: accepted` is the unblock signal.

## Testing

```
cargo test --workspace
cargo test --workspace --features property-tests
cargo bench -p matching-engine -- --save-baseline pr
```

If you regress a benchmark named in `benches/RELEASE_GATES.md`, post
the comparison output in the PR. CI will block the merge automatically.

## Releases

Release engineering owns `main`'s tag cadence. Rough schedule:

- patch releases as needed, no calendar;
- minor releases roughly every 4-6 weeks;
- major releases when wire protocol breaks (rare).

Release branch is `release/X.Y`. Backports to active release branches
are explicit cherry-picks.
