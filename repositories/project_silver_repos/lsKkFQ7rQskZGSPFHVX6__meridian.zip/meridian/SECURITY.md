# Security policy

This repository hosts the Meridian Exchange platform. It moves customer
funds and books trades. Security issues are taken seriously.

## Reporting

Send security reports to `security@meridian.markets`. Include:

- a description of the issue,
- the affected component(s) and version(s),
- a proof-of-concept or reproduction if you have one,
- whether the issue is being actively exploited.

We acknowledge within one business day. Critical issues that involve
fund loss, unauthorised order entry, or auth bypass are escalated to
the on-call security engineer immediately.

## Disclosure

We follow a 90-day coordinated disclosure window for non-critical
issues, and a 30-day window for critical issues. We will work with
reporters to publish a write-up after fixes are deployed.

## Scope

In scope:

- the matching engine and any code in this repository;
- the FIX, REST, and WebSocket gateways;
- internal services that handle authentication or fund movement.

Out of scope:

- third-party SaaS we use (report to the vendor);
- denial-of-service via volumetric traffic (we have separate process);
- self-XSS in admin UI;
- issues that depend on physical access to a Meridian datacenter.

## Hardening posture

- All build artefacts are reproduced from pinned dependencies via
  `cargo --locked`. Dependency review uses `cargo-deny`.
- The runtime image runs as UID 10001, no shell, read-only root.
- All inter-service traffic uses mTLS; certs rotate every 30 days.
- Customer secrets (API keys, withdrawal whitelists) are stored
  encrypted with KMS-managed envelope keys.
- Match-path code paths are pinned to a small allowlist of reviewers
  via `CODEOWNERS`.
