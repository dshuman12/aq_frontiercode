# FIX Session Reset Runbook

**Owner:** Yuki Tanaka (FIX gateway on-call). Escalate via `platform-eng-pri` if Yuki is unavailable.

**Slack channel:** `#platform-eng`

---

## Symptom

One or more of the following is observed:

- FIX session log for a client shows: `MsgSeqNum mismatch: expected N, got M`
- The client disconnects immediately after sending a Logon (35=A) message
- The gateway-fix log records `Logon rejected: sequence number out of range`

These symptoms indicate the client's MsgSeqNum (tag 34) has diverged from the sequence number the gateway expects for that session.

---

## Diagnose

Check the gateway-fix logs for the affected client. Substitute the client's CompID for `{CLIENT_COMP_ID}`:

```
journalctl -u meridian-gateway-fix -n 200 | grep "session_id={CLIENT_COMP_ID}"
```

Identify whether the gap is:
- **Client's outbound sequence is behind** (client thinks it's at N, gateway expects M > N): indicates the client lost state, possibly due to a restart.
- **Client's outbound sequence is ahead** (client is at M > N, gateway expected N): indicates missed messages on the gateway side. Check for any gateway restarts or network interruptions in the same window.

---

## Soft Reset (Session-Layer — Preferred)

Use a soft reset when the gap is on the client's side and the client agrees to receive a SequenceReset.

Send a SequenceReset (35=4) with GapFillFlag (tag 123) set to `Y` to advance the gateway's expected inbound sequence number to match the client. This does not require stopping the gateway process and does not affect other sessions.

Confirm with the client's technical contact that they are ready to accept the SequenceReset before sending it.

---

## Hard Reset (Session State Wipe)

Use a hard reset when the session state is irrecoverably diverged or the soft reset does not resolve the issue.

1. Notify the client's technical contact that a hard reset is about to be performed. The client will need to re-logon with MsgSeqNum=1 (or the agreed reset sequence number) after the reset completes.

2. Stop the gateway-fix process:

   ```
   systemctl stop meridian-gateway-fix
   ```

3. Delete the session state file for the affected client:

   ```
   rm /var/lib/meridian/fix-sessions/{COMP_ID}.state
   ```

4. Restart the gateway:

   ```
   systemctl start meridian-gateway-fix
   ```

5. Confirm with the client that they can now successfully logon. Watch gateway logs for `Logon accepted` for the affected `{COMP_ID}`.

**Note:** A hard reset discards the stored MsgSeqNum for that session. The client must begin a new session from sequence number 1 or a mutually agreed reset number. Always communicate the expected post-reset sequence number to the client's technical contact before executing the reset.
