# Snapshot Recovery Runbook

**Owner:** Primary on-call via `platform-eng-pri` PagerDuty service. Escalation: Henrik Bjornsson (sequencer/infra).

**Slack channel:** `#platform-eng`

---

## When This Runbook Applies

This runbook is needed when:

- The `snapshot_load_failed` alert fires for a symbol.
- The engine fails to start after three consecutive restart attempts and the logs show snapshot-related errors (`CRC mismatch`, `snapshot file not found`, `unexpected EOF in snapshot`).
- An on-call engineer is directed here from `docs/runbooks/engine-failover.md` after automatic recovery fails.

---

## Option A — Recovery from Log Only (No Snapshot)

Use this path when the snapshot file is missing entirely or when no valid backup exists.

1. Open `config/exchange.toml` for the affected shard and set:

   ```toml
   snapshot_path = ""
   ```

2. Restart the engine:

   ```
   systemctl restart meridian-engine@{symbol}
   ```

3. The engine will replay the sequencer log from sequence number 0. For large logs (production symbols with months of history), this replay may take several minutes. Monitor progress via:

   ```
   journalctl -u meridian-engine@{symbol} -f | grep "replayed seq"
   ```

4. Once replay completes, the engine will begin accepting sequence entries normally. Verify via **Post-Recovery Verification** below.

---

## Option B — Recovery from Last-Known-Good Snapshot

Use this path when the current snapshot is corrupt but backup snapshots are available.

1. List available backup snapshots for the symbol:

   ```
   ls -lt /var/backup/meridian/snapshots/{symbol}/
   ```

2. Verify the CRC of the most recent valid-looking snapshot:

   ```
   meridian-cli verify-snapshot /var/backup/meridian/snapshots/{symbol}/{snapshot_file}
   ```

   If the CRC check passes, the output will read `snapshot OK, seq={N}`. Note the sequence number.

3. Copy the verified snapshot to the live snapshot path configured in `config/exchange.toml` (field: `snapshot_path`):

   ```
   cp /var/backup/meridian/snapshots/{symbol}/{snapshot_file} {snapshot_path}
   ```

4. Restart the engine:

   ```
   systemctl restart meridian-engine@{symbol}
   ```

5. The engine will load the snapshot and replay only the log entries after the snapshot sequence number. This is much faster than a full log replay.

---

## Option C — Corrupt Log and Corrupt Snapshot (P0)

If both the snapshot and the sequencer log are corrupt or missing, this is a P0 incident.

1. Engage the kill switch immediately per `docs/runbooks/kill-switch.md`. Do not allow order entry until the state is confirmed clean.

2. Escalate to Henrik Bjornsson (sequencer/infra on-call) and the on-call SRE immediately via PagerDuty `platform-eng-pri`.

3. Data recovery proceeds from the replica node. The replica maintains a copy of the sequencer log and periodic snapshots. The SRE and Henrik will coordinate the replica promotion procedure.

---

## Post-Recovery Verification

After recovery by any path, verify event stream continuity before re-enabling order entry:

```
meridian-cli replay --from <last_snapshot_seq> --to <latest_seq>
```

Compare the output of this replay to the event archive. The event counts, order IDs, and fill amounts must match. Any discrepancy is a data integrity issue — do not bring the shard back into service. Escalate to Henrik Bjornsson.

Once continuity is confirmed, re-enable routing for the shard and monitor `engine_seq_lag` and `engine_order_count` for at least five minutes.

File an incident doc per `docs/runbooks/incident-response.md` for any snapshot recovery event.
