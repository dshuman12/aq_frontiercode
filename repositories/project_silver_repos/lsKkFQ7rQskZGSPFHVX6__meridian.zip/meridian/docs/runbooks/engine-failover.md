# Matching Engine Failover Runbook

**Owner:** Primary on-call via `platform-eng-pri` PagerDuty service.

**Slack channel:** `#platform-eng`

---

## Symptom

The alert "Engine {symbol} missed 3 heartbeats" fires in `#platform-eng`. This is generated when the `engine_heartbeat` metric for a symbol stops updating for more than three consecutive heartbeat intervals (default: 3 seconds each).

Additional indicators: order entry for the affected symbol begins returning `EngineUnavailable`, and `engine_seq_lag` for that shard starts rising.

---

## Step 1 — Determine Crash vs. Hang

Check the engine process state on the host assigned to that shard:

```
systemctl status meridian-engine@{symbol}
```

- If the status is `failed` or `inactive`, the process has crashed. Proceed to the **Crash Recovery** section.
- If the status is `active (running)` but heartbeats have stopped, the process is hung. Proceed to the **Hang Recovery** section.

---

## Crash Recovery

The shard supervisor is designed to restart the engine automatically from the most recent snapshot. In most cases, no manual intervention is required beyond confirming the recovery succeeded.

1. Check the engine logs to determine what sequence number it recovered to:

   ```
   journalctl -u meridian-engine@{symbol} -n 100 | grep "recovered to seq"
   ```

2. Confirm the recovered sequence number is within one replication period of the last known good sequence. If the numbers appear correct, the shard supervisor has handled the restart. Proceed to **Verify Recovery**.

3. If the log contains messages such as `snapshot load failed`, `log gap detected`, or `CRC mismatch`, automatic recovery has failed. Escalate to Henrik Bjornsson (sequencer/infra on-call) immediately and proceed to `docs/runbooks/snapshot-recovery.md`.

---

## Hang Recovery

A hung process will not restart on its own. Force-terminate the process and allow the supervisor to restart it:

```
kill -9 $(systemctl show -p MainPID --value meridian-engine@{symbol})
```

The supervisor will then restart the engine from the latest snapshot. Partial fills already emitted before the hang are durable — they were written to the sequencer log before acknowledgment was returned to the gateway. No fills will be duplicated or lost.

---

## Verify Recovery

Watch the following metrics after restart:

- `engine_seq_lag` for the affected symbol — should converge to 0 within 30 seconds. If it remains elevated beyond 60 seconds, the engine may be replaying a large log backlog. This is not an error, but monitor until it reaches 0.
- `engine_order_count` — compare the post-recovery value against the last value recorded in the pre-failover snapshot metadata. These should match (within the tolerance of any orders submitted during the outage window that were rejected by the gateway).

When both metrics look correct, the shard is healthy. Order entry for the symbol resumes automatically once the sequencer router detects heartbeats.

---

## Post-Failover Review

Review engine logs for the root cause of the crash or hang:

- **OOM kill** (`Out of memory: Kill process`): reduce the `max_book_depth` or `max_order_count` configuration for that symbol in `config/exchange.toml`.
- **Disk full** (`No space left on device`): expand the volume or clean old log segments. Contact Henrik Bjornsson if disk expansion requires infrastructure changes.
- **Segfault or assertion failure**: this is a code defect. File a P1 issue at `git.meridian.markets/meridian/meridian/issues` with the crash backtrace attached.

File an incident doc per `docs/runbooks/incident-response.md` for any failover that caused client-visible disruption.
