# Kill Switch — Engagement and Disengagement Runbook

**Owner:** Primary on-call via `platform-eng-pri` PagerDuty service. Secondary: trading ops on-call.

**Slack channel:** `#platform-eng`

---

## Symptom Triggers

The kill switch runbook is activated when any of the following conditions are met:

- PagerDuty alert fires with summary "Kill switch required" or "Market integrity breach"
- Risk dashboard shows a breach of the pre-set gross exposure limit for a participant or symbol group
- Trading ops team lead requests an emergency halt due to venue instability, erroneous price feed, or client-reported abnormal fills
- On-call engineer independently identifies a software fault that may produce incorrect executions

---

## Pre-Conditions

Before engaging the kill switch, confirm the action verbally or via Slack with the trading ops team lead. Document the confirmation message (user, timestamp, brief reason) in the incident doc. Do not proceed without this sign-off except in cases where trading ops is unreachable and client money is at immediate risk — in that case, engage first and notify within two minutes.

---

## Engagement Procedure

1. Send the kill switch command to the sequencer admin endpoint:

   ```
   POST /v1/admin/kill-switch
   Content-Type: application/json

   { "engaged": true, "reason": "<brief description of the trigger>" }
   ```

   Alternatively, issue the sequencer admin command directly:

   ```
   KillSwitch { engaged: true, reason: "<brief description>" }
   ```

2. Confirm rejection behavior. Submit a test order through any connected gateway. The order must be rejected with a `KillSwitchEngaged` error code. If orders continue to be accepted, the command did not apply — repeat the step and check the sequencer admin service health.

3. Verify in-flight order cancels have completed. Monitor the metric `platform/engine/{symbol}/inflight_orders` across all active symbols. Wait until all values reach 0 before declaring the halt stable. This typically completes within five seconds but may take longer during high-volume periods.

4. Post to `#platform-eng` with the incident summary: time of engagement, reason, and your name.

---

## Disengagement Procedure

Disengagement requires two explicit sign-offs: one from the risk team lead and one from the trading ops team lead. Both must be recorded in the incident doc with name and timestamp before issuing the command.

1. Once both sign-offs are recorded, send:

   ```
   KillSwitch { engaged: false }
   ```

   Or equivalently:

   ```
   POST /v1/admin/kill-switch
   { "engaged": false }
   ```

2. Monitor order flow resumes. Watch `platform/gateway/order_accept_rate` and `platform/engine/{symbol}/match_rate` for at least two minutes. Both should return to near pre-incident baselines.

3. If disengagement fails (orders continue to be rejected, or the admin endpoint returns an error), escalate immediately to Marcus Chen (matching engine on-call).

---

## Post-Incident

File an incident document using the template at `docs/runbooks/incident-response.md`. The incident doc must include the engagement and disengagement timestamps, the sign-off trail, and the root cause or suspected root cause.
