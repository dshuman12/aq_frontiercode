# Incident Response Runbook

**Owner:** Primary on-call via `platform-eng-pri` PagerDuty service.

**Slack channel:** `#platform-eng`

---

## Severity Definitions

### P0 — Trading Halted or Client Money at Risk

Any condition where trading has stopped unexpectedly, client funds are potentially at risk due to incorrect fills, or a data integrity issue exists that could affect ledger balances.

- Page `platform-eng-pri` immediately.
- Bridge trading ops and compliance into the incident call within ten minutes.
- Engage the kill switch (`docs/runbooks/kill-switch.md`) if order flow should be halted pending investigation.

### P1 — Degraded but Trading Active

Trading is continuing, but one or more components are impaired (elevated latency, partial unavailability of a symbol, gateway connectivity issues for a subset of clients).

- Page `platform-eng-pri`.
- Trading ops participation is at the Incident Commander's discretion based on client impact.
- Monitor conditions; escalate to P0 if trading halts or client money becomes at risk.

### P2 — Monitoring, No Client Impact

An anomaly has been detected but has no current client-facing impact. Examples: a metric trending in the wrong direction, a non-critical service returning errors, a capacity threshold approaching.

- File a ticket at `git.meridian.markets/meridian/meridian/issues`. No page is required.
- Assign the ticket to the responsible team. Set priority and target resolution sprint.

---

## During an Incident

**Assign roles immediately.**

- **Incident Commander (IC):** Drives the call, makes decisions, delegates investigation tasks, and tracks overall status. Only one IC at a time.
- **Scribe:** Logs all actions taken and their timestamps in the incident document in real time. The scribe does not investigate — their only job is to maintain an accurate, timestamped record.

**Communication rules:**

- All client-facing communications are issued by trading ops only. Engineering does not communicate directly with clients during an active incident, even if directly contacted.
- Internal status updates go to `#platform-eng`. Do not post speculative root causes publicly; post confirmed facts and confirmed mitigations.
- If the incident involves a client money risk, trading ops will notify compliance. Engineering does not contact compliance directly.

**Mitigation first.** Identify and apply the fastest available mitigation (kill switch, routing drain, session isolation, gateway restart) before root cause analysis. A stable-but-impaired system is preferable to an unstable one during investigation.

---

## Resolution Criteria

An incident is resolved when all three of the following are true:

1. The relevant metrics have returned to their baseline values and have been stable for at least five minutes.
2. The root cause has been identified (or a credible hypothesis exists and is documented).
3. A follow-up ticket has been filed at `git.meridian.markets/meridian/meridian/issues` to track the corrective action.

---

## Post-Incident Review

A post-incident review is required for all P0 and P1 incidents.

- The review should be scheduled within two business days of resolution.
- The IC is responsible for scheduling the review and ensuring the incident document is complete beforehand.
- The incident document template is at `docs/runbooks/_incident-template.md`.
- Attendees: IC, scribe, involved engineers, and trading ops representative (for P0s).
- Output: a root cause statement, a timeline, a list of action items with owners and due dates, and any process or configuration changes identified as corrective measures.

P2 incidents do not require a formal review, but the filed ticket must include a brief root cause statement when resolved.
