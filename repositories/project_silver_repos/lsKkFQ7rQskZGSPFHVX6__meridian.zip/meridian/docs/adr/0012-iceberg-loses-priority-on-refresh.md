# ADR-0012: Iceberg refresh loses queue priority

- Status: Accepted
- Date: 2025-02-09
- Authors: Marcus Chen, Aleksandr Voronov

## Context

An iceberg order has a `display_qty` (visible on the book and in
public market data) and a `hidden_qty` (known only to the engine).
When the visible slice is exhausted by fills, the engine must
"refresh" — reveal a new slice from the hidden pool and re-queue it.

The question is whether the refreshed slice should retain the
original order's queue priority, or be re-inserted at the back of
the queue at the same price level.

Three regimes were considered:

1. **Retain priority.** The iceberg keeps its `priority_seq` across
   refreshes; it stays at the front of the queue until the entire
   hidden pool is exhausted. This is what naive implementations do.
   It is also what gives icebergs an unfair advantage: they enjoy the
   queue priority of a small displayed order while controlling a
   large hidden volume.
2. **Lose priority on every refresh.** Every refreshed slice gets a
   fresh `priority_seq` and goes to the back of the queue at the same
   price. This is the standard rule across CME, Eurex, Cboe, and the
   major crypto venues we benchmarked (Binance, OKX, Coinbase).
3. **Lose priority only when the visible pool is exhausted *across*
   a non-zero match volume.** A hybrid that protects icebergs from
   accidental zero-fill refreshes (e.g. a peg moving the BBO past
   the slice). Rejected as too complex; the corner case it addresses
   has not been observed in production.

## Decision

Adopt regime (2): every refresh produces a `RestingOrder` with a
fresh `priority_seq`. The engine's `iceberg::plan_refresh` takes the
seq to use as a parameter — typically the originating command's
sequence shifted by `PER_COMMAND_SUBSEQ_STRIDE` — so refreshes
remain deterministic without colliding with later commands.

## Consequences

Displayed liquidity stays competitive against hidden liquidity:
participants can choose between size and queue position but not
both. This is the correct incentive structure for a continuous
double-auction venue.

The iceberg refresh path emits an `IcebergRefreshed` event so
downstream consumers (drop-copy, market-data fanout) see the new
priority. Risk and ledger ignore it because no fill occurs at
refresh time.

Bug `#2641` (fixed in v0.17.5) was a regression in this area: the
refresh code reused the parent order's `priority_seq` when the new
slice landed mid-batch, breaking the ADR-0012 contract on a narrow
race. The fix introduces `PER_COMMAND_SUBSEQ_STRIDE = 1024` so that
within-command sub-sequences cannot collide with the next command's
seq. The constant is asserted at the call site.
