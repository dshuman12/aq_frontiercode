# ADR-0009: Support FIX 4.4 only; not 4.2, not 5.0SP2, not FIXT

- Status: Accepted
- Date: 2025-04-30
- Authors: Yuki Tanaka, Marcus Chen

## Context

The first three institutional clients to ask about FIX connectivity
all wanted **4.4**, with two of them additionally requesting "and
support 4.2 if it's not too much trouble — that's what our legacy
OMS speaks." A fourth had previously deployed FIX 5.0SP2/FIXT on
another venue.

The cost of supporting multiple FIX versions is non-trivial:

- The wire format diverges at the application layer (different
  message types are valid, different tag sets per message).
- The session layer is *radically* different in 5.0SP2 — FIXT
  separates session and application versions, so two different
  application versions can run over one FIXT.1.1 session.
- Conformance tests have to run against each version; the test matrix
  multiplies.
- Reject messages have to identify version-specific failure modes.

The benefit of supporting more than one version, given that our top
clients all wanted 4.4, would have been small.

## Decision

Support **FIX 4.4 only**. Concretely:

- The codec accepts only `8=FIX.4.4` Logon messages. Any other
  `BeginString` is rejected with a session-level reject before reaching
  the application layer.
- The message dictionary covers the 4.4 message types we use:
  `D` (NewOrderSingle), `F` (OrderCancelRequest),
  `G` (OrderCancelReplaceRequest), `8` (ExecutionReport),
  `9` (OrderCancelReject), `AE` (TradeCaptureReport), and the
  session-layer messages `0` (Heartbeat), `1` (TestRequest),
  `2` (ResendRequest), `4` (SequenceReset), `5` (Logout),
  `A` (Logon).
- Client-defined custom tags are tolerated in inbound but never
  generated outbound.
- Tag 7928 `SelfTradePreventionStrategy` is supported per the FIX
  Trading Community supplement (see ADR-0011); it is not part of
  base 4.4.

Clients on FIX 4.2, 5.0SP2, or FIXT use an external adapter (their
side) or a vendor gateway. We do not maintain those.

## Consequences

Conformance scope is bounded. The drop-copy session, the order entry
session, and the session-layer state machine all share one dictionary
and one set of fixtures. New message-type support means writing one
encoder and one decoder, not three.

Negative consequences:

- A prospective client on 4.2 has to either upgrade their stack or
  run their own bridge. We have lost two prospective clients to this
  in the past 18 months, neither at sizes that would have justified
  the maintenance cost.
- We can't take advantage of 5.0SP2 features (XML data dictionaries,
  cleaner SecurityList semantics). 4.4 is "good enough" by a wide
  margin for a single-asset-class crypto venue.

Revisit this if (a) a flagship client requires 5.0SP2, (b) we add a
second asset class with materially different message semantics
(e.g., listed options), or (c) the FIX Trading Community deprecates
4.4 in a way that affects on-the-wire tags.
