# ADR-0007: Matching is fully deterministic given the command stream

- Status: Accepted
- Date: 2023-04-18
- Authors: Marcus Chen, Henrik Bjornsson

## Context

The matching engine is the system's source of truth for execution
order. Every downstream consumer — risk, ledger, market data, drop-copy
sessions, the snapshot worker — assumes that two replays of the same
command stream produce byte-identical event streams. This guarantee
is what allows the engine to be restarted from a snapshot plus the
sequencer log without operator intervention, and it is what allows
incident forensics to be reconstructed offline from the log.

Determinism does not happen by default in Rust. Hash-iteration order,
reads of the wall clock, mid-allocation `Instant::now()` calls, and
`Vec` shuffles in unstable sorts will all break it. The engine sits
on top of crates (`hashbrown`, `tokio`, `rand`) where any of these
could leak in if not actively prevented.

Alternatives considered:

1. **"Mostly deterministic, with a tolerance band on event timestamps."**
   Rejected — downstream consumers compare events for equality, not
   approximate equality, and any tolerance creeps into reconciliation.
2. **Lock the engine to a single OS thread and use a deterministic
   scheduler.** Rejected — does not address hash iteration or wall
   clock; adds operational complexity for no additional guarantee.
3. **Capture full RNG state in the snapshot.** Rejected — the engine
   does not need an RNG; banning RNG calls is simpler than capturing
   them.

## Decision

The engine commits to four invariants, enforced in code review and
clippy lints:

1. **No `HashMap` iteration in matching paths.** Resting orders, price
   levels, and per-account state are stored in `BTreeMap` or sorted
   `Vec`. Iteration order is total and stable.
2. **No wall-clock reads inside matching.** Time on events is the
   sequencer-stamped `Command.at`, not `Utc::now()`. Engine code
   that needs a clock takes `&dyn Clock`.
3. **All ordering tie-breaks use `priority_seq`** — a per-order
   monotonic value derived from the command's `SeqNo`. Pro-rata,
   STP decrement-cancel, iceberg refresh, and peg repricing all
   route through this single tie-breaker.
4. **No RNG, no `unsafe`, no FFI** in matching paths.

## Consequences

Replays produce byte-identical event streams; this is exercised by
`tests/integration/recovery_replay.rs`. Determinism foreclosed two
otherwise tempting choices: a `HashMap` order index (would have been
faster) and a thread-pooled match loop (would have parallelised
across price levels). Neither is worth losing the replay guarantee.

A future revisit is plausible if the engine ever shards by symbol
across threads — symbol shards remain individually deterministic
under this rule, but cross-symbol ordering would need a separate
total order. Out of scope today.
