# ADR-0014: Peg repricing model and queue-priority handling

- Status: Accepted
- Date: 2026-01-05
- Authors: Marcus Chen, Aleksandr Voronov

## Context

A pegged order does not carry a fixed limit price; its effective
limit is computed from a reference (mid, primary, or market — the
opposite touch) plus a signed `offset_ticks`. Because the reference
moves as the BBO moves, the engine must reprice pegged orders on
every relevant book update.

Two design questions had to be answered for v0.18.0:

1. **Where do pegs sit on the book?** Two options: (a) a separate
   pegged-orders queue iterated independently of the main book;
   (b) pegs rest on the book at their *current* effective limit
   price, alongside vanilla limit orders. Option (a) gives pegs
   their own ordering rules but doubles the matching logic. Option
   (b) reuses the main matching path but requires repricing.

2. **What happens to a peg's queue priority when its reference
   moves?** Two options: (a) preserve `priority_seq` across
   repricing — pegs always stay at the front of their level; (b)
   issue a fresh `priority_seq` on every reprice — pegs go to the
   back of the new level. Option (a) lets pegs front-run vanilla
   limits indefinitely; option (b) treats pegs identically to
   icebergs that lose priority on refresh (ADR-0012).

## Decision

- **Pegs rest on the main book** at their effective price. The
  matching path treats them like any other limit order at that
  price.
- **A reprice issues a fresh `priority_seq`.** The peg is removed
  from its current level and re-inserted at the new level (or
  re-inserted at the same level if the reference round-trips, which
  is fine — it still loses priority).
- **Repricing happens at command-edge** — after the engine finishes
  processing a command that moves the BBO. It does not happen
  mid-match; the engine collects affected orders, then applies the
  repricing as a batch. Repricing mid-match would create feedback
  loops (peg moves → BBO recomputed → peg moves again).
- **Reference unevaluable → leave the peg alone.** A mid-peg on a
  one-sided book, or a primary-peg with no liquidity on its side,
  returns `None` from `compute_effective_price`. The engine
  interprets this as "do not move and do not cancel"; the order
  rests at its last effective price until the reference becomes
  evaluable again.

## Consequences

Pegs participate in matching exactly like vanilla limits — same
allocation policy, same STP rules, same drop-copy events. Risk
checks see a normal `RestingOrder`. The only special path is the
repricing pass at command-edge.

Frequent BBO oscillation produces repricing churn. In benchmarks at
1k commands/s sustained, mid-pegs visiting both sides in alternation
produced ~3x the event volume of static limits. Drop-copy consumers
that cannot keep up should subscribe to a filtered stream rather
than the firehose; this is documented in `docs/api/websocket-channels.md`.

Tick-snapping rounds in the venue's favour: buy pegs floor, sell pegs
ceil. This means `offset_ticks=0` does not always sit *exactly* at
the reference — if the reference is mid-tick, it is rounded one tick
inside. Documented in `compute_effective_price` and surfaced in the
test `mid_peg_centers_on_mid` (which uses an even-spread BBO so the
mid is on a tick boundary).

A future revisit is plausible if the venue ever supports peg-to-NBBO
across multiple symbols (currently we only peg within a single book).
That would require a cross-book reference cache and a different
invalidation rule.
