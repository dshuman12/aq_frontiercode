# ADR-0011: Per-order Self-Trade Prevention modes

- Status: Accepted
- Date: 2025-01-22
- Authors: Marcus Chen, Priya Ramachandran

## Context

A self-trade is a fill where the aggressor and the resting order
belong to the same account. Some accounts (market makers running
multiple strategies, prop desks split across desks) want self-trades
allowed; others (regulated counterparties, accounts with internal
crossing controls) require them blocked. A single venue-wide policy
forces one or the other.

When v0.16 first shipped, the engine had a global "block all self-
trades by cancelling the aggressor" rule. Two production incidents
made the limitation visible:

- A market-maker desk with two co-located strategies kept getting
  one strategy's orders cancelled by the other, even though the
  desk wanted both filled. They worked around it by funnelling
  through a shared queue, which lost ~120ms per order.
- A prop desk crossing internally wanted *both* sides cancelled
  on a self-match (no fill, no record), not just the aggressor.

The FIX 4.4 base spec doesn't define an STP tag; the FIX Trading
Community supplement adds tag `7928 SelfTradePreventionStrategy`.
Most major venues (CME Globex, OKX, Coinbase, Binance, Kraken)
expose at minimum three modes; CME and OKX expose four or five.

## Decision

Support five modes per order, default per account configurable via
`ref-data` and overridable per order via FIX tag 7928 or REST
`stp_mode`:

| Mode               | Behaviour                                                            |
|--------------------|----------------------------------------------------------------------|
| `None`             | Self-trade allowed.                                                  |
| `CancelNewest`     | Aggressor cancelled, resting stays.                                  |
| `CancelOldest`     | Resting cancelled, aggressor continues to next resting.              |
| `DecrementCancel`  | Smaller side cancelled in full, larger has its qty decremented.      |
| `CancelBoth`       | Both cancelled in full.                                              |

`DecrementCancel` is the recommended default for accounts that don't
specify, because it is symmetric — it doesn't matter which side is
the aggressor — and it doesn't waste the larger side's queue
priority. Tie-breaking on equal sizes cancels the *taker* side; this
matches CME and OKX.

## Consequences

Per-order STP is auditable: every cancellation emits a `Cancelled`
event with `reason: SelfTradePrevention(<mode>)` so reconciliation
can attribute the cancellation correctly.

The matching path now branches on STP mode at every potential same-
account match. The cost is one branch per resting-order check —
~3% throughput overhead in benchmarks, acceptable.

Negative consequences:

- A FIX client that omits tag 7928 receives the account's default
  mode. There is no per-message "use venue default" signal; we
  treated absence as "use account default" intentionally, but a
  future revisit may change this.
- `CancelBoth` interacts awkwardly with FOK semantics: if any leg of
  a FOK aggressor is cancelled by STP, the whole FOK is rejected.
  This is correct but surprising on first read.
