# ADR-0006: Sequencer command log binary format

- Status: Accepted
- Date: 2023-05-08
- Authors: Henrik Bjornsson

## Context

The sequencer must persist every accepted command durably before it
hands the command off to the matching engine. The engine then replays
from `last_snapshot_seq + 1` on startup. Three properties are
non-negotiable:

1. **Append-only.** Records cannot be rewritten, because a replay must
   reproduce events in their exact original order.
2. **Corruption-detectable.** A torn write or bit flip must be visible
   to the recovery scanner; otherwise the engine reads garbage and
   diverges silently.
3. **Cheap to scan.** Recovery iterates from the snapshot's last seq;
   the scanner needs to skip records by seq without decoding payloads.

Three alternatives were on the table:

1. **SQLite-backed log.** Battle-tested, but adds a build dependency
   and an O(log n) per-append B-tree write that we don't need.
2. **External system (Kafka, NATS Streaming).** Solves durability
   somebody else's problem, but introduces a network hop on the hot
   path and a runtime dependency on infrastructure that, today, the
   platform doesn't otherwise need.
3. **In-house framed binary file.** Full control over format, simple
   recovery semantics, no external dependencies. Risk: we maintain
   the readers ourselves.

## Decision

Option (3). On-disk format:

```text
File header (8 bytes, written once):
  magic:    u32 LE = 0x4D44_5251  ("MDRQ")
  version:  u16 LE = 1
  reserved: u16 LE = 0

Per-record (16 bytes header + payload):
  length:   u32 LE  -- payload bytes only
  seq_no:   u64 LE  -- inline so scanners can skip without decoding
  crc32:    u32 LE  -- crc32fast over the payload only
  payload:  [u8; length] -- bincode-serialised LoggedCommand
```

Operational rules:

- Records are written through `BufWriter` with a `fsync` (`sync_data`)
  at the end of each batch. Per-record fsync is too slow (~80μs on
  NVMe); per-batch hits ≤500μs RTT including fsync at typical batch
  sizes (`batch_fsync_every` defaults to 32).
- Reopening the file validates the magic header. A magic mismatch is
  a hard error — recovery does not attempt to "fix" the file.
- A truncated payload (EOF mid-record) is a hard error.
- A CRC mismatch is a hard error — the scanner reports the offset and
  exits. Forensics tooling (`tools/meridian-cli inspect-log`) can
  walk past the bad record manually if operations decide to.
- Recovery hard-errors on a sequence-number gap (not silently skips):
  see `crates/sequencer/src/recovery.rs`.

CRC covers the payload only, not the header. The header has its own
self-validating fields (length + seq_no), and a corrupt header throws
off framing such that the next record's CRC will fail anyway —
detection still works, just one record later.

## Consequences

Recovery is simple and fast: scan from offset 8, skip records with
`seq_no <= snapshot_last`, replay the rest. Forensics can read the
log offline with no engine running.

Negative consequences:

- Format is proprietary and requires in-repo readers. We accept this
  because the readers are <100 lines and tooling is owned by the
  platform team.
- The 16-byte per-record header is overhead. At our typical command
  size (200-400 bytes after bincode) this is 4-8% file-size overhead;
  not worth optimising further.
- No per-record encryption at rest. Disk encryption is delegated to
  the host's full-disk encryption setup. If we ever need per-record
  encryption (e.g., to preserve tenant separation across a shared
  log), the format will need a `flags` byte and a v2 magic.
