# ADR-0008: Pro-rata allocation uses largest-remainder distribution

- Status: Accepted
- Date: 2024-11-04
- Authors: Marcus Chen
- Supersedes: nothing (initial decision; pro-rata was added in v0.18.0)

## Context

When a match policy distributes an aggressor's incoming quantity
across multiple resting orders at the same price level, integer-
quantity rounding produces a residue: the floored shares always sum
to less than the aggressor's total. For an incoming size of 15 split
across three orders of size 30, 20, 10 (total 60), the raw shares
are 7.5, 5.0, 2.5 — flooring gives 7, 5, 2, summing to 14. One unit
unaccounted for.

Three approaches were on the table:

1. **Floor-and-stop.** Drop the residue: aggressor receives less than
   it asked for, the unallocated lot remains with the aggressor as a
   leaves_qty. Simple, but consistently shorts the aggressor and
   complicates IOC semantics — the order is "fully filled" by quantity
   but reports leaves_qty > 0.
2. **Round-half-up per share.** Easier to implement but causes
   over-allocation in some configurations (the rounded shares can
   exceed the incoming quantity, requiring a clawback pass).
3. **Largest-remainder method.** Floor each share, then award one
   additional lot at a time to the orders with the largest fractional
   remainders, until the residue is consumed.

Largest-remainder is the standard treatment in regulated venues
(CME's pro-rata-with-LMM, Eurex's pro-rata, ICE's pro-rata). It is
also the standard apportionment method in Hamilton-style legislative
seat allocation; the algorithm is well-understood and not a venue
invention.

## Decision

Implement largest-remainder in `crates/matching-engine/src/pro_rata.rs`.
Tie-breaking on equal remainders uses `priority_seq` ascending — the
older order wins. The lot size is configurable per book
(`ProRataPolicy::with_lot`); it defaults to `Quantity::ONE`.

The residue distribution wraps around: if an order's allocation is
capped by its `visible_qty`, residue continues with the next-largest-
remainder order, repeating until either all residue is placed or no
order has remaining capacity.

## Consequences

Allocated quantities sum to exactly the executable incoming quantity
(or the level total, whichever is smaller). This is enforced by a
runtime assertion in debug builds and exercised by
`fills_sum_to_aggressor` and `never_over_allocates` unit tests.

A small downside: the residue distribution is not strictly fair when
one order is much smaller than the lot — that order can receive its
full size on a single residue pass while a larger order misses out.
This is acceptable because (a) all venues accept it, (b) the
alternative (fractional lots) violates the lot constraint upstream
relies on.

The residue-on-second-fill bug `#2811` (fixed in v0.18.4) was a
defect in this code, not in the design — the wrap-around terminator
allowed a stale `idx` to reuse a fully-allocated entry. The fix is
a re-check on the wrap.
