# ADR-0013: Stop orders trigger off last trade, not bid/ask or mark

- Status: Accepted
- Date: 2025-03-12
- Authors: Marcus Chen, Aleksandr Voronov

## Context

A stop order has a `trigger_price` and an action (market, or limit at
some `limit_price`). The engine has to decide *what reference* causes
the stop to fire. There are three plausible references:

1. **Last trade.** The stop fires when the most recent fill on this
   symbol crosses the trigger.
2. **BBO (bid for sell stops, ask for buy stops).** The stop fires
   when the relevant touch crosses the trigger, even if no trade has
   printed.
3. **Mark price** (a smoothed reference, often a TWAP of recent
   trades or an external index). Common on derivatives venues for
   liquidation triggers.

Each has tradeoffs:

- Last-trade is the most replay-stable reference: the trigger event
  is in the same event stream as the trades that produced it. Replay
  produces the same triggers in the same order.
- BBO triggers cause two operational headaches. First, a one-tick
  flicker on the bid (a quote that arrives, gets cancelled
  immediately, and was never matchable) can fire a stop with no
  actual print to back it up. Second, BBO can move during a halt
  (auctions, kill switch) without any print, which surprises clients
  who reasoned about stop semantics in terms of fills.
- Mark price requires a separate stream and complicates replay
  determinism (the mark must be replayable too).

In v0.16, the engine briefly used BBO. Two production incidents
(`#2602` precursor: stop fired during an auction crossing window with
no trade; `#2754` precursor: stop fired on a stale quote that never
became matchable) made it clear that last-trade is the correct
reference for a continuous-double-auction venue.

## Decision

Stop and stop-limit orders trigger on the **last trade price** of
the symbol:

- Stop **buy** triggers when last trade ≥ `trigger_price`.
- Stop **sell** triggers when last trade ≤ `trigger_price`.

"Last trade" is the most recent fill on this symbol, as recorded in
the engine's own event stream. The engine does not look at the BBO
for trigger purposes; it does not look at any external index.

Stops that have not yet triggered live in `StopBook` (see
`crates/matching-engine/src/stops.rs`), keyed on `trigger_price`.
After every trade, the engine asks `StopBook::fire(last)` for the
list of stops that this trade just triggered, and re-injects them
as market or limit orders in trigger-price order, FIFO within the
same trigger price.

## Consequences

Trigger semantics align with the execution stream. Replay produces
identical triggers. The `last_trade` field is the only state the
engine needs for stop logic; no separate quote feed is consulted.

Negative consequences:

- Stops do not fire during a halt (no trades). A symbol that opens
  an auction with a cross at a price that would have triggered
  pre-existing stops will fire those stops *after* the auction's
  cross trade prints, not during the auction itself. This is correct
  but worth communicating to clients used to BBO-triggered stops.
- Stops can lag indicative prices when books are thin. A wide BBO
  with no trades can sit "above" a stop trigger for an extended
  period without firing. This is the intended behaviour but has
  surprised clients before.
- Stop-loss orders cannot be used as venue-side liquidation triggers
  for derivatives, which would need a mark-price reference. This
  venue is currently spot-only; revisit if/when listed perpetuals
  are added.
