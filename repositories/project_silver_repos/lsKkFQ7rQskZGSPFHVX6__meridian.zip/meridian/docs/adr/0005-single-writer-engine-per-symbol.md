# ADR-0005: One matching engine writer per (shard, symbol)

- Status: Accepted
- Date: 2023-01-17
- Authors: Marcus Chen

## Context

The matching engine is the most contended piece of the platform. Every
order touches the book at least twice (insert, then either match or
rest), and every fill touches the resting order it consumes. Naïvely
sharing the book across threads requires either coarse locking (which
serialises everything anyway) or fine-grained per-level locking
(which introduces hidden ordering effects: thread A finishing a write
before thread B does not guarantee A's events were emitted before
B's).

The platform is built around a determinism contract (ADR-0007): two
replays of the same command stream must produce identical events.
That contract is impossible to enforce against multi-writer concurrency
without some form of global ordering layer above the writers — at
which point you're back to single-writer semantics with extra hops.

Three architectures were considered:

1. **Single global writer for the whole venue.** Simple, deterministic,
   doesn't scale past one CPU core's worth of throughput.
2. **Single writer per symbol, with a sequencer establishing global
   order before dispatch.** Symbols don't share state in the matching
   engine, so per-symbol writers don't lose any matching capability.
   Each symbol gets one core; horizontal scale is by symbol count.
3. **Multi-writer per symbol with optimistic concurrency / STM /
   per-level locks.** Highest theoretical throughput, but loses
   determinism and adds an enormous test surface for race-condition
   bugs that show up only under load.

## Decision

Adopt option (2). Concretely:

- Each shard runs N matching engine instances, one per symbol assigned
  to the shard.
- The sequencer assigns a strictly monotonic `SeqNo` to every command
  before dispatch. Commands route to the engine by symbol; the
  sequencer ordering becomes the engine's input ordering.
- Within an engine, processing is single-threaded. The engine owns its
  state outright; no locks, no `Arc`, no atomics on hot paths.
- Cross-symbol operations (mass cancel by account, kill switch, halt)
  fan out as separate commands per affected engine, sequenced through
  the same channel.

A single engine instance handles ~120k commands/s in our benchmarks
on a modern x86 core, which is well above the per-symbol command rate
even on the busiest crypto venues. If a single symbol ever exceeds
that, the answer is to split the symbol into sub-books (price-banded
or strategy-banded) rather than to multi-thread the writer.

## Consequences

Determinism is enforceable. Debugging a stuck engine means inspecting
exactly one thread's state, not reconstructing a happens-before graph.
Snapshot/replay can target a single symbol's state independently of
the rest of the venue.

Negative consequences:

- A bug that hangs one engine hangs that symbol, because there is no
  other writer to take over. Operationally this is mitigated by the
  shard supervisor, which can re-spawn the engine from snapshot + log
  in seconds.
- Per-symbol parallelism caps at the number of distinct symbols, which
  is fine for a 50-symbol crypto venue and would be a problem for a
  500-symbol equity venue. Out of scope today.
- Cross-symbol atomic operations don't exist — there's no way to
  "cancel orders on BTC-USD and ETH-USD as one atomic unit." All such
  operations are best-effort sequenced and may interleave with other
  per-symbol activity.
