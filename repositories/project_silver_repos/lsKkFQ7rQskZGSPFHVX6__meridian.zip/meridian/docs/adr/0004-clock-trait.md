# ADR-0004: All time access goes through a `Clock` trait

- Status: Accepted
- Date: 2022-11-29
- Authors: Henrik Bjornsson

## Context

A trading platform reads "now" in three very different settings:

1. **Production hot path.** The sequencer stamps a wall-clock time on
   every command at admission. The matching engine reads that stamp
   off the command, never the wall clock.
2. **Unit tests.** Test setup needs deterministic time so that GTD
   expiries, peg repricings, candle bucketing, and risk pre-trade
   checks produce reproducible outputs.
3. **Replay.** The recovery and forensics paths need time to advance
   in lock-step with the recorded log, not with `Utc::now()` running
   on the operator's laptop.

If every module calls `Utc::now()` directly, none of these settings
work cleanly. Tests get flaky, replay produces wrong event timestamps,
and the engine's determinism contract (ADR-0007) is impossible to
enforce.

Alternatives considered:

1. **Pass `DateTime<Utc>` to every function that needs time.** Works
   but pollutes signatures across crates that don't otherwise care
   about time.
2. **Global mockable clock (e.g., `mock_instant`).** Easy in tests but
   leaks test scaffolding into production builds and doesn't solve
   replay (which needs deterministic stepping, not pinning).

## Decision

Define `Clock` in `meridian_common::clock`:

```rust
pub trait Clock: Send + Sync + 'static {
    fn now(&self) -> DateTime<Utc>;
    fn now_nanos(&self) -> i64 { /* default impl */ }
    fn monotonic_ms(&self) -> u64 { /* default impl */ }
}
```

with three implementations:

- `SystemClock` — reads `Utc::now()`. Used in production by services
  that need real time (sequencer admission, snapshot worker, gateway
  rate limiters).
- `FixedClock` — returns a constant. Used in unit tests via
  `FixedClock::at_unix(1_700_000_000)`.
- `SteppedClock` — caller advances explicitly via `advance(delta)` or
  `set(t)`. Used in replay and integration tests that need to drive
  scheduled-task firing deterministically.

`clippy.toml` bans direct calls to `Utc::now`, `SystemTime::now`, and
`Instant::now` everywhere except `clock.rs` (which has a single
`#[allow(clippy::disallowed_methods)]` for the production path).

## Consequences

Replays produce identical event timestamps because they're driven by
the recorded `Command.at` field, never by `Clock::now`. Tests are
deterministic because `FixedClock` pins time. The matching engine
itself never holds a `Clock` — it doesn't need one — which is the
correct outcome of this design.

Backwards step backstop: `SteppedClock::set` panics in debug builds
on a backwards transition. Production code paths use `SystemClock`
which can never go backwards by construction (it's stateless). The
replay path uses `SteppedClock` and the recorded log is monotonic
by sequencer construction, so the backstop has not fired in
production.
