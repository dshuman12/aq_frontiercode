# Meridian WebSocket API

**Endpoint:** `wss://ws.meridian.markets/v1`

---

## Connection

Connect using any standard WebSocket client. TLS is required; plaintext `ws://` connections are rejected. The server negotiates the `json` subprotocol. All messages are UTF-8 encoded JSON.

---

## Authentication

Public channels require no authentication. Private channels (`orders.*`, `fills.*`, `balances.*`) require authentication before subscription.

Authentication is performed by sending the following message as the first message after connecting, before any subscribe actions:

```json
{
  "action": "auth",
  "key": "<api_key>",
  "timestamp": <unix_ms>,
  "signature": "<hmac_sha256_hex>"
}
```

**Signature construction:**

1. Build the pre-image string: `timestamp={ts}&channel={channel}` where `{ts}` is the same Unix millisecond timestamp in the `timestamp` field, and `{channel}` is the channel name being authenticated. Strip any carriage return characters (`\r`) before hashing.
2. Compute HMAC-SHA256 of the pre-image using your API secret as the key.
3. Encode the result as a lowercase hexadecimal string.

Authentication applies to the connection for all private channels. A single auth message covers all subsequent private channel subscriptions on that connection.

**Auth response (success):**

```json
{ "type": "auth_ok" }
```

**Auth response (failure):**

```json
{ "type": "error", "code": "auth_failed", "message": "invalid signature" }
```

---

## Heartbeat

The server sends a ping message every 15 seconds:

```json
{ "type": "ping" }
```

The client must respond with a pong within 30 seconds:

```json
{ "type": "pong" }
```

If no pong is received within 30 seconds of a ping, the server closes the connection with code 4000. Clients should reconnect and re-authenticate immediately.

---

## Subscribe and Unsubscribe

**Subscribe:**

```json
{ "action": "subscribe", "channel": "<channel_name>" }
```

**Unsubscribe:**

```json
{ "action": "unsubscribe", "channel": "<channel_name>" }
```

**Subscribe acknowledgment:**

```json
{ "type": "subscribed", "channel": "<channel_name>" }
```

**Unsubscribe acknowledgment:**

```json
{ "type": "unsubscribed", "channel": "<channel_name>" }
```

**Error response:**

```json
{ "type": "error", "channel": "<channel_name>", "code": "<error_code>", "message": "<detail>" }
```

Common error codes: `auth_required`, `unknown_channel`, `invalid_symbol`, `already_subscribed`.

---

## Public Channels

Public channels are available without authentication.

### `book.{symbol}` — Full Depth Order Book

Sends a full order book snapshot on subscribe, followed by incremental updates.

**Symbol format:** `BTC-USD`, `ETH-USD`, etc.

**Snapshot (on subscribe):**

```json
{
  "type": "snapshot",
  "channel": "book.BTC-USD",
  "seq": 1048576,
  "bids": [["43250.00", "1.500"], ["43249.50", "0.800"]],
  "asks": [["43251.00", "2.000"], ["43251.50", "1.200"]]
}
```

Each entry is `[price, quantity]`. Prices and quantities are decimal strings to preserve precision.

**Incremental update:**

```json
{
  "type": "update",
  "channel": "book.BTC-USD",
  "seq": 1048577,
  "changes": [
    ["buy", "43250.00", "0.000"],
    ["buy", "43248.00", "2.500"]
  ]
}
```

Each change is `[side, price, quantity]`. A quantity of `"0.000"` means the price level has been removed. The `seq` field increments by 1 for each update. If a gap is detected between the last received `seq` and the current update's `seq`, discard all local state, unsubscribe, and re-subscribe to receive a fresh snapshot.

### `book.depth5.{symbol}` — Top-5 Order Book

Same format as `book.{symbol}` but limited to the top five price levels on each side. Each update is a full replacement of the top-5 levels, not an incremental diff.

```json
{
  "type": "update",
  "channel": "book.depth5.BTC-USD",
  "seq": 204800,
  "bids": [["43250.00", "1.500"], ["43249.50", "0.800"], ["43249.00", "3.100"], ["43248.50", "0.500"], ["43248.00", "2.500"]],
  "asks": [["43251.00", "2.000"], ["43251.50", "1.200"], ["43252.00", "0.750"], ["43252.50", "0.300"], ["43253.00", "1.000"]]
}
```

### `trades.{symbol}` — Public Trade Feed

No snapshot on subscribe. Emits a message for each completed trade.

```json
{
  "type": "trade",
  "channel": "trades.BTC-USD",
  "seq": 87654,
  "trade_id": "t-00000000ABCD",
  "price": "43250.50",
  "quantity": "0.200",
  "side": "buy",
  "timestamp": 1746180000000
}
```

`side` reflects the aggressor side. `timestamp` is Unix milliseconds.

### `ticker.{symbol}` — Best Bid/Offer and Last Trade

No snapshot on subscribe. Emits on any change to the BBO or on each trade.

```json
{
  "type": "ticker",
  "channel": "ticker.BTC-USD",
  "seq": 33000,
  "bid": "43250.00",
  "bid_qty": "1.500",
  "ask": "43251.00",
  "ask_qty": "2.000",
  "last_price": "43250.50",
  "last_qty": "0.200",
  "timestamp": 1746180000000
}
```

### `candles.{symbol}.{interval}` — OHLCV Candles

Supported intervals: `1m`, `5m`, `15m`, `1h`, `4h`, `1d`.

On subscribe, the server sends the current in-progress candle as a snapshot, then emits updates as trades occur within the interval.

**Snapshot / update:**

```json
{
  "type": "candle",
  "channel": "candles.BTC-USD.1m",
  "seq": 5000,
  "open_time": 1746180000000,
  "open": "43240.00",
  "high": "43255.00",
  "low": "43238.50",
  "close": "43250.50",
  "volume": "12.350",
  "closed": false
}
```

`closed` is `true` only in the final update for a completed candle interval.

---

## Private Channels

Private channels require a successful `auth` message before subscription.

### `orders.{account_id}` — Order State Updates

Emits on every order state change for the specified account: new, partially filled, filled, canceled, rejected, replaced.

**Snapshot (on subscribe):** All open orders for the account.

```json
{
  "type": "snapshot",
  "channel": "orders.ACC123",
  "orders": [
    {
      "order_id": "o-0000000012AB",
      "client_order_id": "my-order-1",
      "symbol": "BTC-USD",
      "side": "buy",
      "ord_type": "limit",
      "price": "43200.00",
      "quantity": "0.500",
      "leaves_qty": "0.500",
      "cum_qty": "0.000",
      "status": "open",
      "created_at": 1746179000000
    }
  ]
}
```

**Incremental update:**

```json
{
  "type": "order",
  "channel": "orders.ACC123",
  "seq": 9001,
  "order_id": "o-0000000012AB",
  "client_order_id": "my-order-1",
  "symbol": "BTC-USD",
  "side": "buy",
  "status": "partially_filled",
  "leaves_qty": "0.300",
  "cum_qty": "0.200",
  "last_fill_price": "43200.00",
  "last_fill_qty": "0.200",
  "timestamp": 1746180000000
}
```

During a trading halt, any orders canceled by the halt are delivered as `order` messages with `status: "canceled"` and `cancel_reason: "halt"`.

### `fills.{account_id}` — Fill Events

Emits on each fill. No snapshot on subscribe (historical fills are available via REST).

```json
{
  "type": "fill",
  "channel": "fills.ACC123",
  "seq": 7002,
  "fill_id": "f-000000001ABC",
  "order_id": "o-0000000012AB",
  "client_order_id": "my-order-1",
  "symbol": "BTC-USD",
  "side": "buy",
  "price": "43200.00",
  "quantity": "0.200",
  "liquidity": "maker",
  "fee": "0.43200",
  "fee_currency": "USD",
  "timestamp": 1746180000000
}
```

`liquidity` is `"maker"` or `"taker"`.

### `balances.{account_id}` — Balance Updates

Emits on any change to the account's balances (fill, deposit, withdrawal, fee).

**Snapshot (on subscribe):** All currency balances for the account.

```json
{
  "type": "snapshot",
  "channel": "balances.ACC123",
  "balances": [
    { "currency": "USD", "available": "10500.00", "reserved": "500.00" },
    { "currency": "BTC", "available": "0.350", "reserved": "0.150" }
  ]
}
```

**Incremental update:**

```json
{
  "type": "balance",
  "channel": "balances.ACC123",
  "seq": 6100,
  "currency": "USD",
  "available": "10934.00",
  "reserved": "500.00",
  "timestamp": 1746180000000
}
```

---

## Behavior During a Trading Halt

- `book.*` and `ticker.*` channels remain active during a halt. The order book reflects the state at the time of the halt (no new updates until trading resumes).
- `trades.*` and `candles.*` channels remain connected but emit no new messages during the halt.
- `orders.*` channels emit cancel events for any orders canceled by the halt system. Each canceled order produces an `order` message with `status: "canceled"` and `cancel_reason: "halt"`.
- `fills.*` and `balances.*` channels remain active and emit any post-halt settlement or fee events.
