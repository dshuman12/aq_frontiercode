# Meridian FIX 4.4 Data Dictionary

Meridian Markets implements FIX 4.4 with a small set of FIX Trading Community supplements noted below. All sessions use the standard FIX 4.4 framing (SOH delimiters, tag=value encoding).

---

## Standard Header Tags

Every message (session and application) includes the following header tags.

| Tag | Name          | Type   | Required | Notes                                      |
|-----|---------------|--------|----------|--------------------------------------------|
| 8   | BeginString   | String | Y        | Always `FIX.4.4`                           |
| 9   | BodyLength    | Int    | Y        | Byte count of message body                 |
| 35  | MsgType       | String | Y        | See message type table                     |
| 34  | MsgSeqNum     | Int    | Y        | Per-session monotonically increasing       |
| 49  | SenderCompID  | String | Y        | Sending firm identifier                    |
| 56  | TargetCompID  | String | Y        | Receiving firm identifier                  |
| 52  | SendingTime   | UTCTimestamp | Y   | Format: `YYYYMMDD-HH:MM:SS.sss`            |
| 10  | CheckSum      | String | Y        | Three-digit modulo 256, always last        |

---

## Session Messages

### 35=A — Logon

Initiates a FIX session. Must be the first message sent by the client after TCP connect.

| Tag | Name              | Required | Notes                                               |
|-----|-------------------|----------|-----------------------------------------------------|
| 98  | EncryptMethod     | Y        | Must be `0` (None)                                  |
| 108 | HeartBtInt        | Y        | Heartbeat interval in seconds; Meridian accepts 10–60 |
| 141 | ResetOnLogon      | N        | Set `Y` to reset sequence numbers on this logon    |
| 553 | Username          | Y        | API key identifier                                  |
| 554 | Password          | Y        | HMAC-SHA256 of `timestamp={ts}` using the API secret; timestamp is Unix ms matching tag 52 |

### 35=5 — Logout

Terminates the session cleanly.

| Tag | Name    | Required | Notes                           |
|-----|---------|----------|---------------------------------|
| 58  | Text    | N        | Human-readable logout reason    |

### 35=0 — Heartbeat

Sent periodically at the interval negotiated in Logon, and in response to a TestRequest.

| Tag | Name      | Required | Notes                                         |
|-----|-----------|----------|-----------------------------------------------|
| 112 | TestReqID | C        | Present if this heartbeat responds to a TestRequest |

### 35=1 — TestRequest

Solicits a Heartbeat from the counterparty.

| Tag | Name      | Required | Notes                                    |
|-----|-----------|----------|------------------------------------------|
| 112 | TestReqID | Y        | Echoed back in the responding Heartbeat  |

### 35=2 — ResendRequest

Requests retransmission of messages in the specified range.

| Tag | Name      | Required | Notes                              |
|-----|-----------|----------|------------------------------------|
| 7   | BeginSeqNo | Y       | First sequence number to retransmit |
| 16  | EndSeqNo   | Y       | Last sequence number; `0` means all remaining |

### 35=4 — SequenceReset

Resets the expected inbound sequence number.

| Tag | Name         | Required | Notes                                       |
|-----|--------------|----------|---------------------------------------------|
| 123 | GapFillFlag  | N        | `Y` = GapFill (skipping messages); `N` or absent = hard reset |
| 36  | NewSeqNo     | Y        | New expected sequence number                |

---

## Application Messages

### 35=D — NewOrderSingle

Submits a new order.

| Tag  | Name                        | Required | Notes                                              |
|------|-----------------------------|----------|----------------------------------------------------|
| 11   | ClOrdID                     | Y        | Client-assigned order ID; must be unique per session |
| 55   | Symbol                      | Y        | Instrument symbol, e.g. `BTC-USD`                 |
| 54   | Side                        | Y        | See Side enum                                      |
| 60   | TransactTime                | Y        | Order creation time; `YYYYMMDD-HH:MM:SS.sss`       |
| 40   | OrdType                     | Y        | See OrdType enum                                   |
| 38   | OrderQty                    | Y        | Order quantity in base currency units               |
| 44   | Price                       | C        | Required when OrdType=2 (Limit), 4 (StopLimit), P (Iceberg) |
| 99   | StopPx                      | C        | Required when OrdType=3 (Stop) or 4 (StopLimit)    |
| 59   | TimeInForce                 | N        | Defaults to `0` (Day) if omitted; see TIF enum    |
| 110  | MinQty                      | N        | Minimum fill quantity; only applies to IOC orders  |
| 111  | MaxFloor                    | C        | Peak (visible) quantity for Iceberg orders; required when OrdType=P |
| 7928 | SelfTradePreventionStrategy | N        | See STP enum; defaults to `0` (None)               |
| 1094 | PegPriceType                | C        | Required for peg orders; see PegPriceType enum     |
| 432  | ExpireDate                  | C        | Required when TimeInForce=6 (GTD); format `YYYYMMDD` |

### 35=F — OrderCancelRequest

Requests cancellation of an existing order.

| Tag | Name         | Required | Notes                                              |
|-----|--------------|----------|----------------------------------------------------|
| 41  | OrigClOrdID  | Y        | ClOrdID of the order to cancel                     |
| 37  | OrderID      | N        | Exchange-assigned order ID; provide if known       |
| 11  | ClOrdID      | Y        | New unique ID for this cancel request              |
| 55  | Symbol       | Y        | Must match the original order's symbol             |
| 54  | Side         | Y        | Must match the original order's side               |
| 60  | TransactTime | Y        |                                                    |

### 35=G — OrderCancelReplaceRequest

Requests modification of an existing order. Modifying any price or quantity field causes the order to lose time priority.

| Tag  | Name         | Required | Notes                                              |
|------|--------------|----------|----------------------------------------------------|
| 41   | OrigClOrdID  | Y        | ClOrdID of the order to replace                    |
| 37   | OrderID      | N        | Exchange-assigned order ID; provide if known       |
| 11   | ClOrdID      | Y        | New unique ID for this replace request             |
| 55   | Symbol       | Y        | Cannot be changed; must match original             |
| 54   | Side         | Y        | Cannot be changed; must match original             |
| 60   | TransactTime | Y        |                                                    |
| 40   | OrdType      | Y        | Must match original OrdType                        |
| 38   | OrderQty     | Y        | New total quantity                                 |
| 44   | Price        | C        | Required for Limit, StopLimit, Iceberg orders      |
| 99   | StopPx       | C        | Required for Stop, StopLimit orders                |
| 59   | TimeInForce  | N        | Must match original if provided                    |

### 35=8 — ExecutionReport

Sent by the exchange to report order state changes, fills, and rejections.

| Tag  | Name           | Required | Notes                                                   |
|------|----------------|----------|---------------------------------------------------------|
| 37   | OrderID        | Y        | Exchange-assigned order ID                              |
| 11   | ClOrdID        | C        | Present when the report relates to a client request     |
| 41   | OrigClOrdID    | C        | Present for replace and cancel acknowledgments          |
| 17   | ExecID         | Y        | Unique execution identifier                             |
| 150  | ExecType       | Y        | See ExecType enum                                       |
| 39   | OrdStatus      | Y        | See OrdStatus enum                                      |
| 55   | Symbol         | Y        |                                                         |
| 54   | Side           | Y        |                                                         |
| 38   | OrderQty       | Y        | Original order quantity                                 |
| 14   | CumQty         | Y        | Total filled quantity to date                           |
| 151  | LeavesQty      | Y        | Remaining open quantity                                 |
| 31   | LastPx         | C        | Fill price; present when ExecType=F (Trade)             |
| 32   | LastQty        | C        | Fill quantity; present when ExecType=F (Trade)          |
| 60   | TransactTime   | Y        | Time of this execution event                            |
| 58   | Text           | C        | Human-readable reason; present on rejects               |
| 103  | OrdRejReason   | C        | Numeric reject reason; present when OrdStatus=8 (Rejected) |

### 35=9 — OrderCancelReject

Sent when a cancel or cancel-replace request cannot be processed.

| Tag | Name          | Required | Notes                                                  |
|-----|---------------|----------|--------------------------------------------------------|
| 37  | OrderID       | Y        | Exchange order ID, or `NONE` if order not found        |
| 11  | ClOrdID       | Y        | ClOrdID from the rejected cancel request               |
| 41  | OrigClOrdID   | Y        | OrigClOrdID from the rejected cancel request           |
| 39  | OrdStatus     | Y        | Current order status if known                          |
| 102 | CxlRejReason  | Y        | See CxlRejReason values below                          |
| 434 | CxlRejResponseTo | Y    | `1` = OrderCancelRequest, `2` = OrderCancelReplaceRequest |
| 58  | Text          | N        | Human-readable reason                                  |

**CxlRejReason values:** `0` = Too late to cancel, `1` = Unknown order, `3` = Order already in pending cancel.

### 35=AE — TradeCaptureReport

Sent by the exchange to confirm a completed trade. Published to both sides of a fill.

| Tag  | Name          | Required | Notes                                       |
|------|---------------|----------|---------------------------------------------|
| 571  | TradeReportID | Y        | Exchange-assigned trade identifier          |
| 487  | TradeReportTransType | Y | `0` = New                                  |
| 55   | Symbol        | Y        |                                             |
| 31   | LastPx        | Y        | Trade price                                 |
| 32   | LastQty       | Y        | Trade quantity                              |
| 60   | TransactTime  | Y        | Trade execution timestamp                   |
| 552  | NoSides       | Y        | Number of side entries; always `2`          |
| 54   | Side          | Y        | Per-side: `1`=Buy, `2`=Sell                 |
| 37   | OrderID       | Y        | Per-side: exchange order ID                 |
| 11   | ClOrdID       | N        | Per-side: client order ID if available      |

---

## Tag Value Enumerations

### Tag 40 — OrdType

| Value | Meaning    | Notes                                                         |
|-------|------------|---------------------------------------------------------------|
| 1     | Market     | Executes at best available price; no Price tag required       |
| 2     | Limit      | Executes at Price or better                                   |
| 3     | Stop       | Becomes a Market order when StopPx is touched                 |
| 4     | StopLimit  | Becomes a Limit order at Price when StopPx is touched         |
| P     | Iceberg    | Limit order with a visible peak quantity (MaxFloor)           |

### Tag 54 — Side

| Value | Meaning |
|-------|---------|
| 1     | Buy     |
| 2     | Sell    |

### Tag 59 — TimeInForce

| Value | Meaning | Notes                                            |
|-------|---------|--------------------------------------------------|
| 0     | Day     | Expires at end of regular trading session        |
| 1     | GTC     | Good Till Cancel; expires after 90 calendar days |
| 3     | IOC     | Immediate Or Cancel                              |
| 4     | FOK     | Fill Or Kill                                     |
| 6     | GTD     | Good Till Date; requires ExpireDate (tag 432)    |
| A     | ATO     | At The Open auction — Meridian extension         |
| B     | ATC     | At The Close auction — Meridian extension        |

Values `A` and `B` are Meridian Markets extensions to FIX 4.4. Orders with these TIF values are only accepted during the applicable auction phase.

### Tag 39 — OrdStatus

| Value | Meaning           |
|-------|-------------------|
| 0     | New               |
| 1     | Partially Filled  |
| 2     | Filled            |
| 4     | Canceled          |
| 5     | Replaced          |
| 6     | Pending Cancel    |
| 8     | Rejected          |
| A     | Pending New       |
| E     | Pending Replace   |

### Tag 150 — ExecType

| Value | Meaning          | Notes                                           |
|-------|------------------|-------------------------------------------------|
| 0     | New              | Order accepted                                  |
| 4     | Canceled         | Order canceled                                  |
| 5     | Replaced         | Order replaced                                  |
| 6     | Pending Cancel   |                                                 |
| 8     | Rejected         | Order rejected; see OrdRejReason and Text       |
| D     | Restated         | Order book state restated (e.g., after failover)|
| E     | Pending Replace  |                                                 |
| F     | Trade            | A fill occurred; LastPx and LastQty are populated |

### Tag 7928 — SelfTradePreventionStrategy

This tag is a FIX Trading Community supplement used in the Meridian 4.4 dialect.

| Value | Meaning          | Notes                                                        |
|-------|------------------|--------------------------------------------------------------|
| 0     | None             | No self-trade prevention applied                             |
| 1     | CancelNewest     | The incoming (resting if passive) order is canceled          |
| 2     | CancelOldest     | The resting order is canceled                                |
| 3     | DecrementCancel  | Quantities are decremented; the smaller side is canceled     |
| 4     | CancelBoth       | Both orders are canceled                                     |

### Tag 1094 — PegPriceType

This tag is a FIX Trading Community supplement used in the Meridian 4.4 dialect. Required for peg orders.

| Value | Meaning               | Notes                                         |
|-------|-----------------------|-----------------------------------------------|
| 1     | Mid                   | Pegs to the midpoint of the best bid and offer |
| 2     | Counter / Market      | Pegs to the opposite best (bid for a sell, offer for a buy) |
| 5     | Primary               | Pegs to the same-side best (bid for a buy, offer for a sell) |

---

## Meridian-Specific Extensions

The following tags are outside the FIX 4.4 base specification and are drawn from the FIX Trading Community supplement library:

- **Tag 7928 (SelfTradePreventionStrategy):** Controls how the matching engine handles orders where both sides belong to the same account. See the STP enum above.
- **Tag 1094 (PegPriceType):** Specifies the reference price for peg orders. See the PegPriceType enum above.

All other tags on inbound messages that are not listed in this dictionary are silently ignored by the gateway.
