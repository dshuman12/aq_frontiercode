---
name: Bug report
about: Something is wrong in production or staging
labels: bug
---

## Summary

<!-- one line -->

## Affected component

- [ ] matching-engine
- [ ] order-book
- [ ] auctions
- [ ] sequencer
- [ ] risk-engine
- [ ] ledger / clearing
- [ ] market-data
- [ ] gateway-rest
- [ ] gateway-ws
- [ ] gateway-fix
- [ ] ref-data / config
- [ ] tooling / CI

## Reproduction

<!--
Smallest reproduction. Include:
- platform version (`meridian-cli version` or `git describe`),
- the exact request / event (sanitised),
- expected vs actual.
-->

## Severity

- [ ] sev0 — fund movement, match correctness, market integrity
- [ ] sev1 — degraded service, user-facing
- [ ] sev2 — minor user-facing
- [ ] sev3 — internal-only, cosmetic
