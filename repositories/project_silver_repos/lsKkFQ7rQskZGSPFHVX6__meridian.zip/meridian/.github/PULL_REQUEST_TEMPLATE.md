<!-- Keep this short. The diff says what; this section says why. -->

## Why

<!--
What does this PR change, and what motivated it?
Link the ticket / incident if there is one.
-->

## Match-path / ledger impact

<!--
- [ ] No.
- [ ] Yes — ADR linked: <docs/adr/NNNN-...>
- [ ] Yes — risk-team review requested.
-->

## Tests

<!--
- [ ] Added / updated unit tests.
- [ ] Added / updated property tests.
- [ ] Added / updated conformance scenario.
- [ ] Manually verified on staging — record steps.
-->

## Rollout

<!--
- [ ] No flag, ships on next release.
- [ ] Behind feature flag: `<flag-name>`.
- [ ] Requires migration: `<migration-name>`.
-->
