#[test]
fn stp_modes_choose_expected_pair_action() {
    use meridian_common::prelude::Quantity;
    use meridian_matching::stp::{decide, DecrementSide, StpAction};
    use meridian_order_types::SelfTradePrevention as Stp;

    let taker = Quantity::from_int(4);
    let maker = Quantity::from_int(7);

    let cases = [
        (Stp::None, StpAction::Allow),
        (
            Stp::CancelNewest,
            StpAction::CancelTaker {
                taker_remaining: taker,
            },
        ),
        (
            Stp::CancelOldest,
            StpAction::CancelMaker {
                maker_remaining: maker,
            },
        ),
        (
            Stp::DecrementCancel,
            StpAction::Decrement {
                cancelled_side: DecrementSide::Taker,
                cancelled_qty: taker,
            },
        ),
        (
            Stp::CancelBoth,
            StpAction::CancelBoth {
                taker_remaining: taker,
                maker_remaining: maker,
            },
        ),
    ];

    for (mode, expected) in cases {
        assert_eq!(decide(mode, taker, maker), expected);
    }
}
