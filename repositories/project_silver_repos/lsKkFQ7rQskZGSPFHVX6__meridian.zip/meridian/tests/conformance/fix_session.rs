#[test]
fn fix_session_sequence_gap_logout_rule() {
    let mut state = meridian_gateway_fix::session::FixSessionState::new(
        "MERIDIAN".into(),
        "CLIENT1".into(),
    );
    state.phase = meridian_gateway_fix::session::SessionPhase::Active;
    assert!(state.on_incoming_seq(500).is_err());
}

#[test]
fn fix_session_accepts_expected_sequence_and_advances() {
    let mut state =
        meridian_gateway_fix::session::FixSessionState::new("MERIDIAN".into(), "CLIENT1".into());
    state.phase = meridian_gateway_fix::session::SessionPhase::Active;

    state.on_incoming_seq(1).unwrap();
    state.on_incoming_seq(2).unwrap();

    assert_eq!(state.expected_in, 3);
}

#[test]
fn fix_session_rejects_old_sequence_after_advance() {
    let mut state =
        meridian_gateway_fix::session::FixSessionState::new("MERIDIAN".into(), "CLIENT1".into());
    state.phase = meridian_gateway_fix::session::SessionPhase::Active;

    state.on_incoming_seq(1).unwrap();

    assert!(state.on_incoming_seq(1).is_err());
}
