#[test]
fn recovery_replay_skips_checkpointed_records() {
    use std::sync::Arc;

    use chrono::Utc;
    use meridian_common::prelude::*;
    use meridian_matching::CommandKind;
    use meridian_order_types::{NewOrder, Side};
    use meridian_sequencer::recovery::recover_to;
    use meridian_sequencer::router::{RouteEntry, Router, ShardId};
    use meridian_sequencer::{SequenceOutcome, Sequencer, SequencerConfig};
    use rust_decimal_macros::dec;
    use tempfile::tempdir;

    let symbol = Symbol::new("BTC-USD").unwrap();
    let router = Arc::new(Router::new());
    router.upsert(
        symbol.clone(),
        RouteEntry {
            shard: ShardId::new(0),
            engine_addr: "127.0.0.1:7401".into(),
            healthy: true,
        },
    );

    let dir = tempdir().unwrap();
    let log_path = dir.path().join("seq.log");
    let mut sequencer = Sequencer::open(
        SequencerConfig {
            log_path: log_path.clone(),
            ..Default::default()
        },
        router,
    )
    .unwrap();

    let now = Timestamp::from_datetime(Utc::now());
    for cid in 1..=5 {
        let order = NewOrder::limit(
            AccountId::new(9),
            ClientOrderId::new(cid),
            symbol.clone(),
            Side::Buy,
            Price::from_decimal(dec!(100)),
            Quantity::from_int(1),
        );
        let outcome = sequencer
            .sequence(CommandKind::NewOrder(order), AccountId::new(9), now)
            .unwrap();
        assert!(matches!(outcome, SequenceOutcome::Sequenced { .. }));
    }
    sequencer.checkpoint().unwrap();
    drop(sequencer);

    let mut replayed = Vec::new();
    let report = recover_to(&log_path, SeqNo::new(2), |cmd, account| {
        replayed.push((cmd.seq_no.raw(), account));
        Ok(())
    })
    .unwrap();

    assert_eq!(report.records_scanned, 5);
    assert_eq!(report.records_replayed, 3);
    assert_eq!(report.last_seq_replayed, SeqNo::new(5));
    assert_eq!(replayed[0], (3, AccountId::new(9)));
    assert_eq!(replayed[2], (5, AccountId::new(9)));
}
