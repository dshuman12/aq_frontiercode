use chrono::Utc;
use meridian_common::prelude::*;
use meridian_matching::{Command, CommandKind, Engine, EngineConfig};
use meridian_order_types::{NewOrder, Side};
use rust_decimal_macros::dec;

fn sym() -> Symbol {
    Symbol::new("BTC-USD").unwrap()
}

#[test]
fn submit_match_settle() {
    let mut engine = Engine::new(EngineConfig::new(sym()));
    let at = Timestamp::from_datetime(Utc::now());
    let sell = NewOrder::limit(
        AccountId::new(1),
        ClientOrderId::new(10),
        sym(),
        Side::Sell,
        Price::from_decimal(dec!(100)),
        Quantity::from_int(2),
    );
    let buy = NewOrder::limit(
        AccountId::new(2),
        ClientOrderId::new(20),
        sym(),
        Side::Buy,
        Price::from_decimal(dec!(100)),
        Quantity::from_int(2),
    );
    engine
        .process_command(Command::new(SeqNo::new(1), at, CommandKind::NewOrder(sell)))
        .unwrap();
    let batch = engine
        .process_command(Command::new(SeqNo::new(2), at, CommandKind::NewOrder(buy)))
        .unwrap();
    assert_eq!(batch.fill_count(), 2);
}

