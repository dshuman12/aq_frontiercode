#[test]
fn auction_cross_maximizes_volume_then_minimizes_imbalance() {
    use meridian_auctions::{cross, CrossInputs};
    use meridian_common::prelude::*;
    use meridian_order_book::{Book, RestingOrder};
    use meridian_order_types::{OrderType, Side};
    use rust_decimal_macros::dec;

    fn resting(id: u128, side: Side, price: Price, qty: i64, seq: u64) -> RestingOrder {
        RestingOrder {
            order_id: OrderId::new(id),
            account_id: AccountId::new(id + 10),
            side,
            order_type: OrderType::Limit,
            leaves_qty: Quantity::from_int(qty),
            display_qty: None,
            hidden_qty: None,
            price,
            priority_seq: SeqNo::new(seq),
            post_only: false,
        }
    }

    let symbol = Symbol::new("BTC-USD").unwrap();
    let mut book = Book::new(symbol.clone());
    book.insert(resting(1, Side::Buy, Price::from_decimal(dec!(101)), 8, 1));
    book.insert(resting(2, Side::Buy, Price::from_decimal(dec!(100)), 7, 2));
    book.insert(resting(3, Side::Sell, Price::from_decimal(dec!(99)), 5, 3));
    book.insert(resting(4, Side::Sell, Price::from_decimal(dec!(100)), 9, 4));
    book.insert(resting(5, Side::Sell, Price::from_decimal(dec!(102)), 20, 5));

    let plan = cross(&CrossInputs {
        book: &book,
        auction_id: AuctionId::new(42),
        symbol,
    })
    .unwrap();

    assert_eq!(plan.cross_price, Price::from_decimal(dec!(100)));
    assert_eq!(plan.crossed_qty, Quantity::from_int(14));
    assert_eq!(plan.stats.imbalance, Quantity::from_int(1));
}
