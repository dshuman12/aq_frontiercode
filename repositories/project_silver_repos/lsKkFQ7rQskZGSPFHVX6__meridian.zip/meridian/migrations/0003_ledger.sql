CREATE TABLE ledger_accounts (
    id BIGSERIAL PRIMARY KEY,
    account_code TEXT NOT NULL UNIQUE,
    currency TEXT NOT NULL
);

CREATE TABLE ledger_entries (
    id BIGSERIAL PRIMARY KEY,
    entry_uid TEXT NOT NULL UNIQUE,
    reference TEXT NOT NULL,
    account_id BIGINT NOT NULL REFERENCES ledger_accounts(id) ON DELETE RESTRICT,
    direction TEXT NOT NULL CHECK (direction IN ('debit', 'credit')),
    amount NUMERIC(38, 18) NOT NULL CHECK (amount > 0),
    currency TEXT NOT NULL,
    at TIMESTAMPTZ NOT NULL
);

CREATE TABLE ledger_balanced_refs (
    reference TEXT PRIMARY KEY,
    debit_total NUMERIC(38, 18) NOT NULL,
    credit_total NUMERIC(38, 18) NOT NULL,
    CHECK (debit_total = credit_total)
);

