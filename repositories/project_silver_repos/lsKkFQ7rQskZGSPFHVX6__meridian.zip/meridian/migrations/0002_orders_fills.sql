CREATE TABLE orders (
    id BIGSERIAL PRIMARY KEY,
    order_uid TEXT NOT NULL UNIQUE,
    account_id BIGINT NOT NULL REFERENCES accounts(id) ON DELETE RESTRICT,
    symbol TEXT NOT NULL,
    side TEXT NOT NULL,
    status TEXT NOT NULL,
    price NUMERIC(38, 18),
    quantity NUMERIC(38, 18) NOT NULL,
    leaves_quantity NUMERIC(38, 18) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE fills (
    id BIGSERIAL PRIMARY KEY,
    exec_uid TEXT NOT NULL UNIQUE,
    trade_uid TEXT NOT NULL,
    maker_order_uid TEXT NOT NULL,
    taker_order_uid TEXT NOT NULL,
    symbol TEXT NOT NULL,
    price NUMERIC(38, 18) NOT NULL,
    quantity NUMERIC(38, 18) NOT NULL,
    at TIMESTAMPTZ NOT NULL
);

CREATE TABLE trades (
    id BIGSERIAL PRIMARY KEY,
    trade_uid TEXT NOT NULL UNIQUE,
    symbol TEXT NOT NULL,
    at TIMESTAMPTZ NOT NULL
);

CREATE INDEX idx_orders__account_id_status ON orders (account_id, status);
CREATE INDEX idx_fills__symbol_at ON fills (symbol, at);
CREATE INDEX idx_trades__symbol_at ON trades (symbol, at);

