CREATE TABLE fix_sessions (
    id BIGSERIAL PRIMARY KEY,
    session_uid TEXT NOT NULL UNIQUE,
    sender_comp_id TEXT NOT NULL,
    target_comp_id TEXT NOT NULL,
    expected_in_seq BIGINT NOT NULL,
    next_out_seq BIGINT NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE dropcopy_subscriptions (
    id BIGSERIAL PRIMARY KEY,
    session_id BIGINT NOT NULL REFERENCES fix_sessions(id) ON DELETE CASCADE,
    account_uid TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

