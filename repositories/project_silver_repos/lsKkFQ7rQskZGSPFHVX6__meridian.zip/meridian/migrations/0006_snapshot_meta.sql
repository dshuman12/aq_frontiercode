CREATE TABLE snapshot_manifests (
    id BIGSERIAL PRIMARY KEY,
    snapshot_uid TEXT NOT NULL UNIQUE,
    shard_id INTEGER NOT NULL,
    seq_no BIGINT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    checksum TEXT NOT NULL
);

CREATE INDEX idx_snapshot_manifests__shard_id_seq_no ON snapshot_manifests (shard_id, seq_no);

