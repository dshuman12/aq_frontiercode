CREATE TABLE accounts (
    id BIGSERIAL PRIMARY KEY,
    account_uid TEXT NOT NULL UNIQUE,
    tier TEXT NOT NULL,
    suspended BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE instruments (
    id BIGSERIAL PRIMARY KEY,
    symbol TEXT NOT NULL UNIQUE,
    tick_size NUMERIC(38, 18) NOT NULL,
    lot_size NUMERIC(38, 18) NOT NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE fee_schedules (
    id BIGSERIAL PRIMARY KEY,
    schedule_code TEXT NOT NULL UNIQUE,
    display_name TEXT NOT NULL
);

CREATE TABLE fee_tiers (
    id BIGSERIAL PRIMARY KEY,
    fee_schedule_id BIGINT NOT NULL REFERENCES fee_schedules(id) ON DELETE CASCADE,
    min_30d_notional NUMERIC(38, 18) NOT NULL,
    maker_bps INTEGER NOT NULL,
    taker_bps INTEGER NOT NULL
);

CREATE TABLE calendars (
    id BIGSERIAL PRIMARY KEY,
    calendar_code TEXT NOT NULL UNIQUE,
    timezone TEXT NOT NULL
);

CREATE TABLE holidays (
    id BIGSERIAL PRIMARY KEY,
    calendar_id BIGINT NOT NULL REFERENCES calendars(id) ON DELETE CASCADE,
    holiday_date DATE NOT NULL
);

