/**
 * @worknest/config
 *
 * Cross-cutting configuration helpers. Mostly env-var readers with
 * defaults + validation, plus a few constants we want shared across the
 * monorepo (plan limits, page-size caps, etc.).
 */

export function envOrThrow(name: string): string {
  const value = process.env[name];
  if (!value) throw new Error(`Missing required env var: ${name}`);
  return value;
}

export function envOr(name: string, fallback: string): string {
  return process.env[name] ?? fallback;
}

export function envInt(name: string, fallback: number): number {
  const raw = process.env[name];
  if (!raw) return fallback;
  const n = Number.parseInt(raw, 10);
  if (Number.isNaN(n)) throw new Error(`Env var ${name} must be an integer (got "${raw}")`);
  return n;
}

export function envBool(name: string, fallback = false): boolean {
  const raw = process.env[name];
  if (raw === undefined) return fallback;
  return /^(1|true|yes|on)$/i.test(raw);
}

export const DEFAULT_PAGE_SIZE = 50;
export const MAX_PAGE_SIZE = 200;
export const MAX_UPLOAD_BYTES = 50 * 1024 * 1024;

export const PLAN_LIMITS = {
  free: {
    members: 5,
    projects: 5,
    storageBytes: 1 * 1024 * 1024 * 1024,
    apiRpm: 60,
    auditRetentionDays: 7,
  },
  starter: {
    members: 20,
    projects: 25,
    storageBytes: 10 * 1024 * 1024 * 1024,
    apiRpm: 300,
    auditRetentionDays: 30,
  },
  team: {
    members: 75,
    projects: 100,
    storageBytes: 100 * 1024 * 1024 * 1024,
    apiRpm: 1000,
    auditRetentionDays: 90,
  },
  business: {
    members: 300,
    projects: 500,
    storageBytes: 500 * 1024 * 1024 * 1024,
    apiRpm: 5000,
    auditRetentionDays: 365,
  },
} as const;

export type PlanKey = keyof typeof PLAN_LIMITS;

export function planLimit<K extends keyof (typeof PLAN_LIMITS)["free"]>(plan: PlanKey, key: K): (typeof PLAN_LIMITS)["free"][K] {
  return PLAN_LIMITS[plan][key];
}
