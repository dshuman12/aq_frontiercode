import { describe, expect, it } from "vitest";
import {
  buildContext,
  can,
  PermissionDenied,
  require as requirePerm,
  isOwner,
} from "../src/permission-checker";
import { permissionsByCategory } from "../src/role-presets";

describe("permission checker", () => {
  it("owner gets everything", () => {
    const ctx = buildContext({ role: "owner", organizationId: "o", userId: "u" });
    expect(can(ctx, "tasks:write")).toBe(true);
    expect(can(ctx, "org:delete")).toBe(true);
    expect(isOwner(ctx)).toBe(true);
  });

  it("viewer cannot write", () => {
    const ctx = buildContext({ role: "viewer", organizationId: "o", userId: "u" });
    expect(can(ctx, "tasks:read")).toBe(true);
    expect(can(ctx, "tasks:create")).toBe(false);
  });

  it("require throws PermissionDenied", () => {
    const ctx = buildContext({ role: "member", organizationId: "o", userId: "u" });
    expect(() => requirePerm(ctx, "billing:write")).toThrow(PermissionDenied);
  });

  it("custom grants extend the preset", () => {
    const ctx = buildContext({
      role: "viewer",
      organizationId: "o",
      userId: "u",
      customGrants: ["tasks:create"],
    });
    expect(can(ctx, "tasks:create")).toBe(true);
  });

  it("custom denies remove from the preset", () => {
    const ctx = buildContext({
      role: "manager",
      organizationId: "o",
      userId: "u",
      customDenies: ["tasks:delete"],
    });
    expect(can(ctx, "tasks:delete")).toBe(false);
  });

  it("permissionsByCategory groups every entry", () => {
    const grouped = permissionsByCategory();
    expect(Object.keys(grouped).length).toBeGreaterThan(5);
  });
});
