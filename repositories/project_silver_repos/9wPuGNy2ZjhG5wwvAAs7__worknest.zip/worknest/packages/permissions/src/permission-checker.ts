/**
 * Per-request permission resolver. Each HTTP request constructs a
 * `PermissionContext` once (via the AuthGuard's downstream interceptor)
 * and the rest of the controllers / services call `can()` or `require()`.
 *
 * Customers can override the preset with a per-org `Role` row; we merge
 * custom-on-top so a custom role can grant or deny individual entries
 * without rewriting the preset.
 */

import { Permission, isKnownPermission } from "./permission-map";
import { presetFor, RoleKey, ROLE_PRESETS } from "./role-presets";

export interface PermissionContextInput {
  userId: string;
  organizationId: string;
  /** The role key on the OrganizationMember row. */
  role: string;
  /** The preset's permission set is merged with these grants. */
  customGrants?: Permission[];
  /** These permissions are explicitly removed from the resolved set. */
  customDenies?: Permission[];
  /** Rare: raise temporary super-user mode (used by impersonation tooling). */
  superUser?: boolean;
}

export interface PermissionContext {
  userId: string;
  organizationId: string;
  role: string;
  permissions: Set<Permission>;
  isOwner: boolean;
}

export class PermissionDenied extends Error {
  constructor(public readonly permission: string, public readonly userId?: string) {
    super(`Missing permission: ${permission}`);
    this.name = "PermissionDenied";
  }
}

export function buildContext(input: PermissionContextInput): PermissionContext {
  const granted = new Set<Permission>();
  if (input.superUser) {
    for (const p of ROLE_PRESETS.owner) granted.add(p);
  } else {
    const preset = presetFor(input.role);
    if (preset) for (const p of preset) granted.add(p);
  }

  for (const grant of input.customGrants ?? []) {
    if (isKnownPermission(grant)) granted.add(grant);
  }
  for (const deny of input.customDenies ?? []) granted.delete(deny);

  return {
    userId: input.userId,
    organizationId: input.organizationId,
    role: input.role,
    permissions: granted,
    isOwner: input.role === "owner" || input.superUser === true,
  };
}

export function can(ctx: PermissionContext, permission: Permission): boolean {
  return ctx.isOwner || ctx.permissions.has(permission);
}

export function anyOf(ctx: PermissionContext, ...permissions: Permission[]): boolean {
  return permissions.some((p) => can(ctx, p));
}

export function allOf(ctx: PermissionContext, ...permissions: Permission[]): boolean {
  return permissions.every((p) => can(ctx, p));
}

export function require(ctx: PermissionContext, permission: Permission): void {
  if (!can(ctx, permission)) throw new PermissionDenied(permission, ctx.userId);
}

export function requireAnyOf(ctx: PermissionContext, ...permissions: Permission[]): void {
  if (!anyOf(ctx, ...permissions)) {
    throw new PermissionDenied(permissions.join(" OR "), ctx.userId);
  }
}

export function isOwner(ctx: PermissionContext): boolean {
  return ctx.isOwner;
}

/**
 * Returns a printable summary of a context — useful for debugging in the
 * admin tooling. Never include this in user-facing error messages.
 */
export function describeContext(ctx: PermissionContext): string {
  return `user=${ctx.userId} org=${ctx.organizationId} role=${ctx.role} grants=${ctx.permissions.size}`;
}
