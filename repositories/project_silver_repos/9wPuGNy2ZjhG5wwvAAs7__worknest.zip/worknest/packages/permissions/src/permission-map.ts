/**
 * Authoritative catalog of every permission the system understands.
 *
 * Adding a new permission means:
 *   1. Add the entry here.
 *   2. Update the relevant role preset in `role-presets.ts`.
 *   3. Decorate the controller route with @RequiresPermission(...).
 *   4. The CI script `scripts/check-permissions.ts` will fail if (3) is
 *      forgotten.
 *
 * The permissions are grouped by surface area for readability; the
 * grouping is informational only. Exported `PERMISSIONS` is a flat list.
 */

export const PERMISSION_GROUPS = {
  organization: [
    "org:read",
    "org:update",
    "org:delete",
    "org:transfer",
    "org:billing:read",
    "org:billing:write",
    "org:plan:change",
  ],
  members: [
    "members:read",
    "members:invite",
    "members:remove",
    "members:role:assign",
  ],
  roles: ["roles:read", "roles:create", "roles:update", "roles:delete"],
  teams: [
    "teams:read",
    "teams:create",
    "teams:update",
    "teams:delete",
    "teams:members:add",
    "teams:members:remove",
  ],
  projects: [
    "projects:read",
    "projects:create",
    "projects:update",
    "projects:archive",
    "projects:delete",
    "projects:members:add",
    "projects:members:remove",
  ],
  boards: ["boards:read", "boards:write", "boards:reorder"],
  tasks: [
    "tasks:read",
    "tasks:create",
    "tasks:update",
    "tasks:delete",
    "tasks:assign",
    "tasks:move",
    "tasks:comment",
    "tasks:attach",
    "tasks:depend",
    "tasks:custom-fields:write",
  ],
  tickets: [
    "tickets:read",
    "tickets:create",
    "tickets:update",
    "tickets:assign",
    "tickets:close",
    "tickets:reopen",
    "tickets:comment",
    "tickets:internal-note",
    "tickets:categories:write",
    "tickets:watchers:add",
  ],
  requests: [
    "requests:read",
    "requests:submit",
    "requests:assign",
    "requests:transition",
    "requests:comment",
    "requests:internal-note",
    "request-forms:read",
    "request-forms:write",
  ],
  approvals: [
    "approvals:read",
    "approvals:decide",
    "approvals:delegate",
    "approvals:workflows:read",
    "approvals:workflows:write",
  ],
  assets: [
    "assets:read",
    "assets:create",
    "assets:update",
    "assets:assign",
    "assets:return",
    "assets:retire",
    "assets:maintenance:write",
    "asset-categories:write",
  ],
  inventory: [
    "inventory:read",
    "inventory:create",
    "inventory:update",
    "inventory:delete",
    "inventory:transactions:write",
    "vendors:read",
    "vendors:write",
    "warehouses:read",
    "warehouses:write",
  ],
  clients: [
    "clients:read",
    "clients:create",
    "clients:update",
    "clients:delete",
    "clients:contacts:write",
    "clients:portal:invite",
    "clients:documents:write",
  ],
  notifications: [
    "notifications:read",
    "notifications:preferences:write",
  ],
  reports: [
    "reports:read",
    "reports:export",
  ],
  files: [
    "files:read",
    "files:upload",
    "files:delete",
  ],
  audit: ["audit:read"],
  apiKeys: ["api-keys:read", "api-keys:create", "api-keys:revoke"],
  webhooks: ["webhooks:read", "webhooks:write"],
  featureFlags: ["feature-flags:read", "feature-flags:write"],
  admin: ["admin:read", "admin:write"],
} as const;

export const PERMISSIONS: readonly string[] = Object.values(PERMISSION_GROUPS).flat();

export type Permission = (typeof PERMISSIONS)[number];

const PERMISSION_SET = new Set<string>(PERMISSIONS);

export function isKnownPermission(value: string): value is Permission {
  return PERMISSION_SET.has(value);
}

export function expandWildcard(prefix: string): string[] {
  return PERMISSIONS.filter((p) => p.startsWith(prefix));
}

export function describePermission(permission: Permission): string {
  return DESCRIPTIONS[permission] ?? permission;
}

const DESCRIPTIONS: Partial<Record<Permission, string>> = {
  "org:read": "View organization profile",
  "org:update": "Edit organization profile",
  "org:delete": "Delete the organization",
  "org:transfer": "Transfer ownership to another user",
  "org:billing:read": "View invoices and plan",
  "org:billing:write": "Change plan, payment method, seats",
  "members:invite": "Invite new members",
  "members:remove": "Remove members from the org",
  "members:role:assign": "Change a member's role",
  "tasks:read": "View tasks",
  "tasks:write": "Create, edit, delete tasks",
  "tasks:assign": "Reassign tasks",
  "tasks:move": "Move tasks between columns",
  "tickets:close": "Mark a ticket resolved or closed",
  "approvals:decide": "Approve or reject pending approvals",
  "audit:read": "View the audit log",
};
