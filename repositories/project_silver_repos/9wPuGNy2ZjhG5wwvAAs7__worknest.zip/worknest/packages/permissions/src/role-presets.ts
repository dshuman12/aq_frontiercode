/**
 * Built-in role presets. Each preset is a set of permission strings. The
 * `owner` preset is special — it gets every permission via wildcard, and
 * `org:delete` / `org:transfer` are owner-only by construction.
 *
 * Custom roles defined per-organization can grant any subset of the flat
 * `PERMISSIONS` list. The runtime checker merges custom + preset.
 */

import { Permission, PERMISSIONS, expandWildcard } from "./permission-map";

export type RoleKey = "owner" | "admin" | "manager" | "member" | "viewer";

const VIEWER: Permission[] = [
  "org:read",
  "members:read",
  "teams:read",
  "projects:read",
  "boards:read",
  "tasks:read",
  "tickets:read",
  "requests:read",
  "request-forms:read",
  "approvals:read",
  "approvals:workflows:read",
  "assets:read",
  "inventory:read",
  "vendors:read",
  "warehouses:read",
  "clients:read",
  "notifications:read",
  "reports:read",
  "files:read",
];

const MEMBER: Permission[] = [
  ...VIEWER,
  "tasks:create",
  "tasks:update",
  "tasks:assign",
  "tasks:move",
  "tasks:comment",
  "tasks:attach",
  "tasks:depend",
  "tickets:create",
  "tickets:update",
  "tickets:comment",
  "tickets:assign",
  "tickets:watchers:add",
  "requests:submit",
  "requests:comment",
  "approvals:decide",
  "files:upload",
  "notifications:preferences:write",
];

const MANAGER: Permission[] = [
  ...MEMBER,
  "tasks:delete",
  "tasks:custom-fields:write",
  "tickets:internal-note",
  "tickets:close",
  "tickets:reopen",
  "tickets:categories:write",
  "requests:assign",
  "requests:transition",
  "requests:internal-note",
  "request-forms:write",
  "approvals:workflows:write",
  "approvals:delegate",
  "boards:write",
  "boards:reorder",
  "projects:create",
  "projects:update",
  "projects:archive",
  "projects:members:add",
  "projects:members:remove",
  "teams:create",
  "teams:update",
  "teams:members:add",
  "teams:members:remove",
  "assets:create",
  "assets:update",
  "assets:assign",
  "assets:return",
  "assets:maintenance:write",
  "asset-categories:write",
  "inventory:create",
  "inventory:update",
  "inventory:transactions:write",
  "vendors:write",
  "warehouses:write",
  "clients:create",
  "clients:update",
  "clients:contacts:write",
  "clients:documents:write",
  "reports:export",
];

const ADMIN: Permission[] = [
  ...MANAGER,
  "org:read",
  "org:update",
  "org:billing:read",
  "members:invite",
  "members:remove",
  "members:role:assign",
  "roles:read",
  "roles:create",
  "roles:update",
  "roles:delete",
  "teams:delete",
  "projects:delete",
  "tickets:internal-note",
  "assets:retire",
  "inventory:delete",
  "clients:delete",
  "clients:portal:invite",
  "audit:read",
  "api-keys:read",
  "api-keys:create",
  "api-keys:revoke",
  "webhooks:read",
  "webhooks:write",
  "feature-flags:read",
  "feature-flags:write",
  "files:delete",
  "admin:read",
];

const OWNER: Permission[] = [...PERMISSIONS] as Permission[];

export const ROLE_PRESETS: Record<RoleKey, Set<Permission>> = {
  owner: new Set(OWNER),
  admin: new Set(ADMIN),
  manager: new Set(MANAGER),
  member: new Set(MEMBER),
  viewer: new Set(VIEWER),
};

export function presetFor(role: string): Set<Permission> | null {
  if (role in ROLE_PRESETS) return ROLE_PRESETS[role as RoleKey];
  return null;
}

export function preset(role: RoleKey): readonly Permission[] {
  return Array.from(ROLE_PRESETS[role]);
}

/**
 * Convenience for the role-builder UI: groups every permission by its
 * category prefix (`tasks:*`, `tickets:*`, etc.) so we can render
 * checkbox sections.
 */
export function permissionsByCategory(): Record<string, Permission[]> {
  const out: Record<string, Permission[]> = {};
  for (const p of PERMISSIONS) {
    const [category] = p.split(":");
    (out[category] ||= []).push(p as Permission);
  }
  return out;
}
