/**
 * @worknest/database
 *
 * Singleton wrapper around PrismaClient. Every consumer in the monorepo
 * imports `prisma` from here so we share one connection pool across the
 * API, the worker, and any scripts. Re-exports the `Prisma` namespace so
 * callers can reach into typed enums and JSON helpers without taking a
 * second dependency on `@prisma/client`.
 */

import { PrismaClient, Prisma } from "@prisma/client";

declare global {
  // eslint-disable-next-line no-var
  var __worknest_prisma: PrismaClient | undefined;
}

export const prisma: PrismaClient =
  global.__worknest_prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === "production"
      ? ["warn", "error"]
      : ["query", "info", "warn", "error"],
  });

if (process.env.NODE_ENV !== "production") {
  global.__worknest_prisma = prisma;
}

export { Prisma };
export type * from "@prisma/client";

/**
 * Helper that runs a callback inside a serializable transaction with a
 * sane default timeout. We've been bitten by long-running transactions
 * holding row locks; 5s is a reasonable upper bound for OLTP workloads.
 */
export async function tx<T>(fn: (client: PrismaClient) => Promise<T>): Promise<T> {
  return prisma.$transaction(async (client) => fn(client as PrismaClient), {
    isolationLevel: "Serializable",
    timeout: 5000,
  });
}
