import { describe, expect, it } from "vitest";
import {
  CreateAssetSchema,
  CreateInventoryItemSchema,
  CreateProjectSchema,
  CreateTaskSchema,
  CreateTicketSchema,
  EmailSchema,
  PaginationSchema,
  RegisterUserSchema,
} from "../src";

describe("validators", () => {
  it("PaginationSchema applies defaults", () => {
    const out = PaginationSchema.parse({});
    expect(out.page).toBe(1);
    expect(out.pageSize).toBe(50);
  });

  it("PaginationSchema clamps oversized pageSize", () => {
    expect(() => PaginationSchema.parse({ pageSize: 9999 })).toThrow();
  });

  it("RegisterUserSchema rejects weak passwords", () => {
    const r = RegisterUserSchema.safeParse({ email: "a@b.com", password: "abc", name: "A" });
    expect(r.success).toBe(false);
  });

  it("EmailSchema normalises", () => {
    expect(EmailSchema.parse("ALEX@Example.com")).toBe("alex@example.com");
  });

  it("CreateProjectSchema requires uppercase key", () => {
    const r = CreateProjectSchema.safeParse({ name: "P", key: "abc" });
    expect(r.success).toBe(false);
  });

  it("CreateProjectSchema accepts ENG", () => {
    const r = CreateProjectSchema.safeParse({ name: "Project", key: "ENG" });
    expect(r.success).toBe(true);
  });

  it("CreateTaskSchema defaults priority to medium", () => {
    const r = CreateTaskSchema.parse({ projectId: "p1", title: "x" });
    expect(r.priority).toBe("medium");
  });

  it("CreateTicketSchema accepts a minimum-shape ticket", () => {
    const r = CreateTicketSchema.safeParse({ title: "x" });
    expect(r.success).toBe(true);
  });

  it("CreateAssetSchema accepts minimal asset", () => {
    const r = CreateAssetSchema.safeParse({ tag: "T-1", name: "Laptop" });
    expect(r.success).toBe(true);
  });

  it("CreateInventoryItemSchema rejects negative reorder point", () => {
    const r = CreateInventoryItemSchema.safeParse({ sku: "x", name: "x", unit: "pc", reorderPoint: -1 });
    expect(r.success).toBe(false);
  });
});
