import { z } from "zod";

export const IdSchema = z.string().min(1).max(64);
export const CuidSchema = z.string().regex(/^c[a-z0-9]{24}$/i, "expected cuid");
export const SlugSchema = z
  .string()
  .min(2)
  .max(64)
  .regex(/^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i, "lowercase alphanumeric with hyphens");
export const EmailSchema = z.string().email().toLowerCase().trim();
export const NameSchema = z.string().min(1).max(160).trim();
export const ColorSchema = z.string().regex(/^#?[0-9a-f]{6}$/i, "expected hex color").optional();
export const TimezoneSchema = z.string().min(1).max(64);
export const LocaleSchema = z.enum(["en", "es", "fr", "de", "ja", "pt-BR"]);

export const PaginationSchema = z
  .object({
    page: z.coerce.number().int().positive().default(1),
    pageSize: z.coerce.number().int().positive().max(200).default(50),
  })
  .strict();

export const SortSchema = z
  .object({
    sort: z.string().optional(),
    direction: z.enum(["asc", "desc"]).default("desc"),
  })
  .strict();

export function PageEnvelope<T extends z.ZodTypeAny>(item: T) {
  return z.object({
    items: z.array(item),
    total: z.number(),
    page: z.number(),
    pageSize: z.number(),
  });
}
