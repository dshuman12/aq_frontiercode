import { z } from "zod";
import { SlugSchema } from "./common";

export const ArticleStatusSchema = z.enum(["draft", "published", "archived"]);

export const CreateKnowledgeCategorySchema = z.object({
  name: z.string().min(1).max(120),
  slug: SlugSchema,
  description: z.string().max(2000).optional(),
});

export const CreateKnowledgeArticleSchema = z.object({
  categoryId: z.string().nullable().optional(),
  slug: SlugSchema,
  title: z.string().min(1).max(200),
  body: z.string().min(1).max(200_000),
  status: ArticleStatusSchema.default("draft"),
});

export const UpdateKnowledgeArticleSchema = CreateKnowledgeArticleSchema.partial();

export const PublishKnowledgeArticleSchema = z.object({
  publish: z.boolean().default(true),
});
