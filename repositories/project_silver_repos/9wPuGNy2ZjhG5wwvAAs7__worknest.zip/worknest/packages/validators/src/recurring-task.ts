import { z } from "zod";

export const RecurrenceCadenceSchema = z.enum(["daily", "weekly", "monthly"]);

export const CreateRecurringTaskSchema = z.object({
  projectId: z.string().min(1),
  templateId: z.string().min(1).optional(),
  name: z.string().min(1).max(160),
  cadence: RecurrenceCadenceSchema,
  interval: z.number().int().positive().max(52).default(1),
  daysOfWeek: z.array(z.number().int().min(0).max(6)).max(7).default([]),
  dayOfMonth: z.number().int().min(1).max(31).optional(),
  hourOfDay: z.number().int().min(0).max(23).default(9),
  timezone: z.string().min(1).max(64).default("UTC"),
  startsOn: z.coerce.date(),
});

export const UpdateRecurringTaskSchema = CreateRecurringTaskSchema.partial();

export const PauseRecurringTaskSchema = z.object({
  active: z.boolean(),
});
