import { z } from "zod";
import { EmailSchema, NameSchema } from "./common";

export const CreateClientSchema = z.object({
  name: NameSchema,
  industry: z.string().max(80).optional(),
  website: z.string().url().optional(),
  notes: z.string().max(2000).optional(),
});

export const UpdateClientSchema = CreateClientSchema.partial().extend({
  status: z.enum(["active", "inactive"]).optional(),
});

export const CreateClientContactSchema = z.object({
  clientId: z.string().min(1),
  name: NameSchema,
  role: z.string().max(80).optional(),
  email: EmailSchema.optional(),
  phone: z.string().max(64).optional(),
});

export const InvitePortalUserSchema = z.object({
  email: EmailSchema,
  name: NameSchema,
});
