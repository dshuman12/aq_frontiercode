import { z } from "zod";
import { NameSchema } from "./common";

export const CreateApprovalWorkflowSchema = z.object({
  name: NameSchema,
  description: z.string().max(2000).optional(),
  appliesTo: z.string().min(1).max(120),
  enabled: z.boolean().default(true),
  steps: z
    .array(
      z.object({
        order: z.number().int().min(0),
        name: NameSchema,
        approverId: z.string().optional(),
        approverRole: z.string().optional(),
        condition: z.string().optional(),
        escalateAfterMinutes: z.number().int().positive().optional(),
      }),
    )
    .min(1)
    .max(20),
});

export const UpdateApprovalWorkflowSchema = CreateApprovalWorkflowSchema.partial();

export const DecideApprovalSchema = z.object({
  decision: z.enum(["approved", "rejected"]),
  reason: z.string().max(2000).optional(),
});

export const ResubmitApprovalSchema = z.object({
  reason: z.string().max(2000).optional(),
});
