import { z } from "zod";
import { EmailSchema, NameSchema } from "./common";

const PasswordSchema = z
  .string()
  .min(12, "Password must be at least 12 characters")
  .max(256)
  .refine((v) => /[a-z]/.test(v) && /[A-Z]/.test(v), "Mix upper and lower case")
  .refine((v) => /[0-9]/.test(v), "Include at least one digit")
  .refine((v) => /[^A-Za-z0-9]/.test(v), "Include at least one symbol");

export const RegisterUserSchema = z.object({
  email: EmailSchema,
  password: PasswordSchema,
  name: NameSchema,
  organizationName: NameSchema.optional(),
});

export const LoginSchema = z.object({
  email: EmailSchema,
  password: z.string().min(1).max(256),
  twoFactorCode: z.string().length(6).optional(),
});

export const RefreshSchema = z.object({
  refreshToken: z.string().min(1),
});

export const PasswordResetRequestSchema = z.object({
  email: EmailSchema,
});

export const PasswordResetCompleteSchema = z.object({
  token: z.string().min(1),
  password: PasswordSchema,
});

export const EmailVerificationSchema = z.object({
  token: z.string().min(1),
});

export const Enable2FASchema = z.object({
  code: z.string().length(6),
  secret: z.string().min(16),
});

export const Disable2FASchema = z.object({
  password: z.string().min(1),
});

export const RevokeSessionSchema = z.object({
  sessionId: z.string().min(1),
});
