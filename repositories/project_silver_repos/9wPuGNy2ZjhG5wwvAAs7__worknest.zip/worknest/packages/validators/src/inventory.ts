import { z } from "zod";
import { NameSchema } from "./common";

export const CreateInventoryItemSchema = z.object({
  sku: z.string().min(1).max(64),
  name: NameSchema,
  description: z.string().max(2000).optional(),
  unit: z.string().min(1).max(16),
  qty: z.number().min(0).default(0),
  reorderPoint: z.number().min(0).default(0),
  costCents: z.number().int().min(0).optional(),
  vendorId: z.string().optional(),
  warehouseId: z.string().optional(),
});

export const UpdateInventoryItemSchema = CreateInventoryItemSchema.partial();

export const InventoryTransactionSchema = z.object({
  itemId: z.string().min(1),
  delta: z.number().refine((v) => v !== 0, "delta must be non-zero"),
  reason: z.string().min(1).max(120),
  reference: z.string().max(120).optional(),
});

export const CreateVendorSchema = z.object({
  name: NameSchema,
  category: z.string().min(1).max(64),
  contactEmail: z.string().email().optional(),
  contactPhone: z.string().max(64).optional(),
  website: z.string().url().optional(),
  notes: z.string().max(2000).optional(),
});

export const UpdateVendorSchema = CreateVendorSchema.partial();

export const CreateWarehouseSchema = z.object({
  name: NameSchema,
  address: z.string().max(500).optional(),
});

export const UpdateWarehouseSchema = CreateWarehouseSchema.partial();
