import { z } from "zod";
import { NameSchema, SlugSchema } from "./common";

export const RequestFieldTypeSchema = z.enum([
  "text",
  "textarea",
  "number",
  "date",
  "email",
  "url",
  "select",
  "multi",
  "user",
  "file",
]);

export const RequestFieldSchema = z.object({
  label: z.string().min(1).max(120),
  key: SlugSchema,
  type: RequestFieldTypeSchema,
  required: z.boolean().default(false),
  config: z.record(z.unknown()).optional(),
  order: z.number().int().min(0).default(0),
});

export const CreateRequestFormSchema = z.object({
  name: NameSchema,
  slug: SlugSchema,
  description: z.string().max(2000).optional(),
  visibility: z.enum(["internal", "public"]).default("internal"),
  fields: z.array(RequestFieldSchema).max(60),
});

export const UpdateRequestFormSchema = CreateRequestFormSchema.partial();

export const SubmitRequestSchema = z.object({
  formId: z.string().min(1),
  title: z.string().min(1).max(280),
  priority: z.enum(["low", "medium", "high", "urgent"]).default("medium"),
  fieldValues: z.record(z.string()).default({}),
  attachmentIds: z.array(z.string()).optional(),
});

export const RequestStatusSchema = z.enum([
  "submitted",
  "in_review",
  "approved",
  "rejected",
  "closed",
]);

export const TransitionRequestSchema = z.object({
  toStatus: RequestStatusSchema,
  note: z.string().max(2000).optional(),
});

export const RequestCommentSchema = z.object({
  body: z.string().min(1).max(20_000),
  internal: z.boolean().default(false),
});
