import { z } from "zod";

export const SavedViewResourceSchema = z.enum(["tasks", "tickets", "requests"]);

export const CreateSavedViewSchema = z.object({
  resource: SavedViewResourceSchema,
  name: z.string().min(1).max(120),
  criteria: z.record(z.unknown()),
  isShared: z.boolean().default(false),
  isDefault: z.boolean().default(false),
});

export const UpdateSavedViewSchema = CreateSavedViewSchema.partial();
