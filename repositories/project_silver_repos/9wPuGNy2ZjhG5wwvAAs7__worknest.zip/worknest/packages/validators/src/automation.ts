import { z } from "zod";

export const AutomationResourceSchema = z.enum(["task", "ticket", "request"]);

export const AutomationTriggerSchema = z.enum([
  "created",
  "updated",
  "status_changed",
  "assignee_changed",
  "due_soon",
]);

export const AutomationActionSchema = z.discriminatedUnion("type", [
  z.object({ type: z.literal("set_status"), status: z.string().min(1).max(40) }),
  z.object({ type: z.literal("set_priority"), priority: z.string().min(1).max(40) }),
  z.object({ type: z.literal("assign"), userId: z.string().min(1) }),
  z.object({ type: z.literal("add_label"), labelId: z.string().min(1) }),
  z.object({ type: z.literal("comment"), body: z.string().min(1).max(2000) }),
  z.object({
    type: z.literal("notify"),
    userIds: z.array(z.string()).min(1).max(50),
    title: z.string().min(1).max(200),
    body: z.string().max(2000).optional(),
  }),
  z.object({
    type: z.literal("webhook"),
    webhookId: z.string().min(1),
    eventName: z.string().min(1).max(120),
  }),
]);

export const CreateAutomationRuleSchema = z.object({
  name: z.string().min(1).max(160),
  resource: AutomationResourceSchema,
  trigger: AutomationTriggerSchema,
  condition: z.record(z.unknown()).nullable().optional(),
  actions: z.array(AutomationActionSchema).min(1).max(20),
  active: z.boolean().default(true),
});

export const UpdateAutomationRuleSchema = CreateAutomationRuleSchema.partial();

export const TestAutomationSchema = z.object({
  resourceId: z.string().min(1),
});
