import { z } from "zod";

export const StartTimerSchema = z.object({
  taskId: z.string().min(1),
  description: z.string().max(500).optional(),
  billable: z.boolean().default(false),
});

export const StopTimerSchema = z.object({
  endedAt: z.coerce.date().default(() => new Date()),
});

export const ManualTimeEntrySchema = z
  .object({
    taskId: z.string().min(1),
    description: z.string().max(500).optional(),
    startedAt: z.coerce.date(),
    endedAt: z.coerce.date(),
    billable: z.boolean().default(false),
  })
  .refine((v) => v.endedAt > v.startedAt, {
    message: "endedAt must be after startedAt",
    path: ["endedAt"],
  });

export const UpdateTimeEntrySchema = z.object({
  description: z.string().max(500).nullable().optional(),
  startedAt: z.coerce.date().optional(),
  endedAt: z.coerce.date().optional(),
  billable: z.boolean().optional(),
});

export const TimeEntryFilterSchema = z.object({
  taskId: z.string().optional(),
  userId: z.string().optional(),
  projectId: z.string().optional(),
  fromDate: z.coerce.date().optional(),
  toDate: z.coerce.date().optional(),
  billable: z
    .union([z.literal("true"), z.literal("false")])
    .transform((v) => v === "true")
    .optional(),
  page: z.coerce.number().int().positive().default(1),
  pageSize: z.coerce.number().int().positive().max(200).default(50),
});
