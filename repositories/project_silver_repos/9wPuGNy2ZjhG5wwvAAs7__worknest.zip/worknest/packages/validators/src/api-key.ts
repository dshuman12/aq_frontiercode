import { z } from "zod";

export const CreateApiKeySchema = z.object({
  label: z.string().min(1).max(120),
  scopes: z.string().min(1).max(2000),
  expiresInDays: z.number().int().positive().max(365).optional(),
});

export const RevokeApiKeySchema = z.object({
  reason: z.string().max(500).optional(),
});
