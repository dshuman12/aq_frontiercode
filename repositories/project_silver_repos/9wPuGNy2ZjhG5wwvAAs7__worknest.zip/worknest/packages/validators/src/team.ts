import { z } from "zod";
import { NameSchema } from "./common";

export const CreateTeamSchema = z.object({
  name: NameSchema,
  description: z.string().max(500).optional(),
});

export const UpdateTeamSchema = CreateTeamSchema.partial();

export const AddTeamMemberSchema = z.object({
  userId: z.string().min(1),
  role: z.enum(["lead", "member"]).default("member"),
});

export const RemoveTeamMemberSchema = z.object({
  userId: z.string().min(1),
});

export const SetTeamRoleSchema = z.object({
  userId: z.string().min(1),
  role: z.enum(["lead", "member"]),
});
