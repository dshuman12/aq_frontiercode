import { z } from "zod";

export const SlaPrioritySchema = z.enum(["low", "medium", "high", "urgent"]);

export const CreateSlaPolicySchema = z.object({
  name: z.string().min(1).max(120),
  priority: SlaPrioritySchema,
  categoryId: z.string().nullable().optional(),
  firstResponseMinutes: z.number().int().positive().max(60 * 24 * 30),
  resolutionMinutes: z.number().int().positive().max(60 * 24 * 30),
  businessHoursOnly: z.boolean().default(false),
  active: z.boolean().default(true),
});

export const UpdateSlaPolicySchema = CreateSlaPolicySchema.partial();
