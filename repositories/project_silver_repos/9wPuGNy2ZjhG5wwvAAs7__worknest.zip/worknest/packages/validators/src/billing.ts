import { z } from "zod";

export const PlanSchema = z.enum(["free", "starter", "team", "business", "enterprise"]);

export const CheckoutSessionSchema = z.object({
  plan: z.enum(["starter", "team", "business"]),
  cadence: z.enum(["month", "year"]).default("month"),
  returnUrl: z.string().url(),
  cancelUrl: z.string().url(),
});

export const PortalSessionSchema = z.object({
  customerId: z.string().min(1),
  returnUrl: z.string().url(),
});

export const ChangeSeatsSchema = z.object({
  seats: z.number().int().positive(),
});
