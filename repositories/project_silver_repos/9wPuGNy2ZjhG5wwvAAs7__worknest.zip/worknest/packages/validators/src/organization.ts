import { z } from "zod";
import { EmailSchema, NameSchema, SlugSchema } from "./common";

export const OrganizationRoleSchema = z.enum([
  "owner",
  "admin",
  "manager",
  "member",
  "viewer",
]);

export const CreateOrganizationSchema = z.object({
  name: NameSchema,
  slug: SlugSchema,
});

export const UpdateOrganizationSchema = z.object({
  name: NameSchema.optional(),
  logoUrl: z.string().url().optional().nullable(),
});

export const InviteMemberSchema = z.object({
  email: EmailSchema,
  role: OrganizationRoleSchema.default("member"),
  customRoleId: z.string().optional(),
});

export const UpdateMemberSchema = z.object({
  role: OrganizationRoleSchema,
  customRoleId: z.string().optional().nullable(),
});

export const TransferOwnershipSchema = z.object({
  toUserId: z.string().min(1),
  password: z.string().min(1),
});

export const CreateRoleSchema = z.object({
  name: NameSchema,
  description: z.string().max(500).optional(),
  permissions: z.array(z.string()).min(1),
});

export const UpdateRoleSchema = CreateRoleSchema.partial();
