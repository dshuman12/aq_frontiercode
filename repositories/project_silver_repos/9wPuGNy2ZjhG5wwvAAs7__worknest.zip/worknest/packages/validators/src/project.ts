import { z } from "zod";
import { NameSchema } from "./common";

export const ProjectKeySchema = z
  .string()
  .regex(/^[A-Z]{2,8}$/, "2-8 uppercase letters");

export const ProjectStatusSchema = z.enum(["active", "on_hold", "archived"]);

export const CreateProjectSchema = z.object({
  name: NameSchema,
  key: ProjectKeySchema,
  description: z.string().max(2000).optional(),
  startsOn: z.coerce.date().optional(),
  endsOn: z.coerce.date().optional(),
});

export const UpdateProjectSchema = z
  .object({
    name: NameSchema.optional(),
    description: z.string().max(2000).optional().nullable(),
    status: ProjectStatusSchema.optional(),
    startsOn: z.coerce.date().optional().nullable(),
    endsOn: z.coerce.date().optional().nullable(),
    archive: z.boolean().optional(),
  })
  .strict();

export const AddProjectMemberSchema = z.object({
  userId: z.string().optional(),
  teamId: z.string().optional(),
  role: z.enum(["owner", "contributor", "viewer"]).default("contributor"),
}).refine((v) => v.userId || v.teamId, "userId or teamId required");

export const CreateMilestoneSchema = z.object({
  name: NameSchema,
  description: z.string().max(500).optional(),
  dueOn: z.coerce.date().optional(),
});

export const UpdateMilestoneSchema = CreateMilestoneSchema.partial().extend({
  completed: z.boolean().optional(),
  order: z.number().int().min(0).optional(),
});

export const CreateBoardSchema = z.object({
  name: NameSchema,
  isDefault: z.boolean().default(false),
});

export const CreateColumnSchema = z.object({
  name: NameSchema,
  order: z.number().int().min(0),
  wipLimit: z.number().int().min(1).optional(),
  color: z.string().optional(),
});

export const ReorderColumnsSchema = z.object({
  ordering: z.array(
    z.object({ id: z.string().min(1), order: z.number().int().min(0) }),
  ),
});
