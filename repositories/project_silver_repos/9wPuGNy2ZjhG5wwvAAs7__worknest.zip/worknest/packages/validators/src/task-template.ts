import { z } from "zod";

export const ChecklistItemTemplateSchema = z.object({
  text: z.string().min(1).max(280),
  done: z.boolean().default(false),
});

export const CreateTaskTemplateSchema = z.object({
  name: z.string().min(1).max(120),
  title: z.string().min(1).max(280),
  description: z.string().max(20_000).optional(),
  priority: z.enum(["low", "medium", "high", "urgent"]).default("medium"),
  estimateHours: z.number().min(0).max(10_000).optional(),
  labels: z.array(z.string().min(1).max(40)).max(50).default([]),
  checklist: z.array(ChecklistItemTemplateSchema).max(50).default([]),
});

export const UpdateTaskTemplateSchema = CreateTaskTemplateSchema.partial();

export const ApplyTaskTemplateSchema = z.object({
  projectId: z.string().min(1),
  assigneeId: z.string().nullable().optional(),
  dueAt: z.coerce.date().nullable().optional(),
});
