import { z } from "zod";
import { NameSchema, SlugSchema } from "./common";

export const TicketStatusSchema = z.enum([
  "open",
  "pending",
  "in_progress",
  "on_hold",
  "resolved",
  "closed",
]);

export const TicketPrioritySchema = z.enum(["low", "medium", "high", "urgent"]);

export const CreateTicketSchema = z.object({
  categoryId: z.string().optional(),
  title: z.string().min(1).max(280),
  description: z.string().max(20_000).optional(),
  priority: TicketPrioritySchema.default("medium"),
  assigneeId: z.string().optional(),
});

export const UpdateTicketSchema = z
  .object({
    title: z.string().min(1).max(280).optional(),
    description: z.string().max(20_000).optional().nullable(),
    status: TicketStatusSchema.optional(),
    priority: TicketPrioritySchema.optional(),
    assigneeId: z.string().optional().nullable(),
    categoryId: z.string().optional().nullable(),
  })
  .strict();

export const TicketCommentSchema = z.object({
  body: z.string().min(1).max(20_000),
  internal: z.boolean().default(false),
});

export const CreateTicketCategorySchema = z.object({
  name: NameSchema,
  slug: SlugSchema,
  description: z.string().max(500).optional(),
  defaultAssigneeId: z.string().optional(),
  defaultPriority: TicketPrioritySchema.default("medium"),
});

export const TransitionTicketSchema = z.object({
  toStatus: TicketStatusSchema,
  note: z.string().max(2000).optional(),
});

export const AddWatcherSchema = z.object({
  userId: z.string().min(1),
});
