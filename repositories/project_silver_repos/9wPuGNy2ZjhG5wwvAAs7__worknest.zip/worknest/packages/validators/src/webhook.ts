import { z } from "zod";
import { NotificationKindSchema } from "./notification";

export const CreateWebhookSchema = z.object({
  url: z.string().url(),
  kinds: z.array(NotificationKindSchema).min(1),
  secret: z.string().min(16).optional(),
});

export const UpdateWebhookSchema = z.object({
  url: z.string().url().optional(),
  kinds: z.array(NotificationKindSchema).optional(),
  enabled: z.boolean().optional(),
});

export const RotateWebhookSecretSchema = z.object({
  newSecret: z.string().min(16).optional(),
});
