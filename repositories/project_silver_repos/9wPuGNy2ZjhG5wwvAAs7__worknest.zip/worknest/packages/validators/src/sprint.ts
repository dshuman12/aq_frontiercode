import { z } from "zod";

export const SprintStatusSchema = z.enum(["planned", "active", "completed", "cancelled"]);

export const CreateSprintSchema = z
  .object({
    projectId: z.string().min(1),
    name: z.string().min(1).max(120),
    goal: z.string().max(2000).optional(),
    startsAt: z.coerce.date().optional(),
    endsAt: z.coerce.date().optional(),
  })
  .refine((v) => !v.startsAt || !v.endsAt || v.endsAt > v.startsAt, {
    message: "endsAt must be after startsAt",
    path: ["endsAt"],
  });

export const UpdateSprintSchema = z.object({
  name: z.string().min(1).max(120).optional(),
  goal: z.string().max(2000).nullable().optional(),
  startsAt: z.coerce.date().nullable().optional(),
  endsAt: z.coerce.date().nullable().optional(),
});

export const TransitionSprintSchema = z.object({
  toStatus: SprintStatusSchema,
});

export const SprintTaskMoveSchema = z.object({
  taskIds: z.array(z.string().min(1)).min(1).max(500),
});
