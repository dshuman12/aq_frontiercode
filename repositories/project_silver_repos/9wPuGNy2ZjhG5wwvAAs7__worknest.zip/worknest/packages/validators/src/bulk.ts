import { z } from "zod";

const IdsSchema = z.array(z.string().min(1)).min(1).max(500);

export const BulkTaskUpdateSchema = z.object({
  ids: IdsSchema,
  patch: z.object({
    status: z.string().min(1).max(40).optional(),
    priority: z.string().min(1).max(40).optional(),
    assigneeId: z.string().nullable().optional(),
    sprintId: z.string().nullable().optional(),
    boardColumnId: z.string().nullable().optional(),
  }),
});

export const BulkTaskDeleteSchema = z.object({
  ids: IdsSchema,
});

export const BulkTicketUpdateSchema = z.object({
  ids: IdsSchema,
  patch: z.object({
    status: z.string().min(1).max(40).optional(),
    priority: z.string().min(1).max(40).optional(),
    assigneeId: z.string().nullable().optional(),
    categoryId: z.string().nullable().optional(),
  }),
});

export const BulkLabelSchema = z.object({
  ids: IdsSchema,
  labels: z.array(z.string().min(1).max(40)).min(1).max(50),
  mode: z.enum(["add", "remove", "replace"]).default("add"),
});
