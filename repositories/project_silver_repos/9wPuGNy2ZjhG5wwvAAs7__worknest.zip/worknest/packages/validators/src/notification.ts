import { z } from "zod";

export const NotificationKindSchema = z.enum([
  "task.assigned",
  "task.commented",
  "task.due_soon",
  "task.overdue",
  "task.completed",
  "ticket.assigned",
  "ticket.commented",
  "ticket.escalated",
  "request.submitted",
  "request.approved",
  "request.rejected",
  "approval.pending",
  "approval.decided",
  "asset.warranty",
  "inventory.low_stock",
  "billing.invoice_paid",
  "billing.payment_failed",
  "digest.daily",
  "digest.weekly",
]);

export const NotificationChannelSchema = z.enum([
  "in_app",
  "email",
  "push",
  "webhook",
]);

export const MarkReadSchema = z.object({
  ids: z.array(z.string()).min(1).max(500),
});

export const SetPreferenceSchema = z.object({
  kind: NotificationKindSchema,
  channel: NotificationChannelSchema,
  enabled: z.boolean(),
});
