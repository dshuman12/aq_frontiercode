import { z } from "zod";
import { NameSchema } from "./common";

export const CreateAssetCategorySchema = z.object({
  name: NameSchema,
  description: z.string().max(500).optional(),
});

export const CreateAssetSchema = z.object({
  tag: z.string().min(1).max(64),
  name: NameSchema,
  categoryId: z.string().optional(),
  serialNumber: z.string().max(120).optional(),
  vendorId: z.string().optional(),
  warehouseId: z.string().optional(),
  purchaseDate: z.coerce.date().optional(),
  warrantyEndsAt: z.coerce.date().optional(),
  costCents: z.number().int().min(0).optional(),
  notes: z.string().max(2000).optional(),
});

export const UpdateAssetSchema = CreateAssetSchema.partial().extend({
  status: z.enum(["available", "assigned", "maintenance", "retired"]).optional(),
});

export const AssignAssetSchema = z.object({
  assigneeId: z.string().min(1),
  effectiveAt: z.coerce.date().optional(),
  note: z.string().max(2000).optional(),
});

export const ReturnAssetSchema = z.object({
  condition: z.enum(["good", "damaged", "lost"]).default("good"),
  note: z.string().max(2000).optional(),
});

export const MaintenanceRecordSchema = z.object({
  performedAt: z.coerce.date(),
  performedBy: NameSchema,
  description: z.string().min(1).max(2000),
  costCents: z.number().int().min(0).optional(),
  vendorId: z.string().optional(),
});
