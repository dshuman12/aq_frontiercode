import { z } from "zod";

export const TaskStatusSchema = z.enum([
  "todo",
  "in_progress",
  "review",
  "blocked",
  "done",
]);

export const TaskPrioritySchema = z.enum(["low", "medium", "high", "urgent"]);

export const CreateTaskSchema = z.object({
  projectId: z.string().min(1),
  boardColumnId: z.string().optional(),
  parentTaskId: z.string().optional(),
  title: z.string().min(1).max(280),
  description: z.string().max(20_000).optional(),
  priority: TaskPrioritySchema.default("medium"),
  assigneeId: z.string().optional(),
  dueAt: z.coerce.date().optional(),
  estimateHours: z.number().min(0).max(1000).optional(),
  labels: z.array(z.string().min(1).max(64)).max(20).optional(),
});

export const UpdateTaskSchema = z
  .object({
    title: z.string().min(1).max(280).optional(),
    description: z.string().max(20_000).optional().nullable(),
    status: TaskStatusSchema.optional(),
    priority: TaskPrioritySchema.optional(),
    assigneeId: z.string().optional().nullable(),
    dueAt: z.coerce.date().optional().nullable(),
    estimateHours: z.number().min(0).max(1000).optional().nullable(),
    boardColumnId: z.string().optional().nullable(),
  })
  .strict();

export const MoveTaskSchema = z.object({
  boardColumnId: z.string().min(1),
  position: z.number().optional(),
});

export const AssignTaskSchema = z.object({
  userId: z.string().nullable(),
});

export const AddCommentSchema = z.object({
  body: z.string().min(1).max(20_000),
});

export const AddDependencySchema = z.object({
  blockerId: z.string().min(1),
  type: z.enum(["blocks", "relates", "duplicates"]).default("blocks"),
});

export const CreateChecklistSchema = z.object({
  title: z.string().min(1).max(280),
});

export const AddChecklistItemSchema = z.object({
  text: z.string().min(1).max(500),
});

export const UpdateChecklistItemSchema = z.object({
  done: z.boolean().optional(),
  text: z.string().min(1).max(500).optional(),
});

export const TaskFilterSchema = z.object({
  projectId: z.string().optional(),
  assigneeId: z.string().optional(),
  status: TaskStatusSchema.optional(),
  priority: TaskPrioritySchema.optional(),
  q: z.string().optional(),
  hasParent: z.coerce.boolean().optional(),
});

export const CreateLabelSchema = z.object({
  name: z.string().min(1).max(64),
  color: z.string().optional(),
});

export const CreateCustomFieldSchema = z.object({
  name: z.string().min(1).max(64),
  type: z.enum(["text", "number", "date", "select", "multi_select", "user", "url"]),
  config: z.record(z.unknown()).optional(),
});
