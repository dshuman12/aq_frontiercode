import { useMemo, useState } from "react";
import { cn } from "./util/cn";

export interface Column<T> {
  key: string;
  header: string;
  cell: (row: T) => React.ReactNode;
  sortable?: boolean;
  sortFn?: (a: T, b: T) => number;
  className?: string;
}

export interface DataTableProps<T> {
  rows: T[];
  columns: Column<T>[];
  keyOf: (row: T) => string;
  rowClassName?: (row: T) => string;
  empty?: React.ReactNode;
  onRowClick?: (row: T) => void;
}

export function DataTable<T>({ rows, columns, keyOf, rowClassName, empty, onRowClick }: DataTableProps<T>) {
  const [sortIdx, setSortIdx] = useState<number | null>(null);
  const [sortDir, setSortDir] = useState<"asc" | "desc">("asc");

  const sortedRows = useMemo(() => {
    if (sortIdx == null) return rows;
    const col = columns[sortIdx];
    if (!col?.sortFn) return rows;
    const sorted = [...rows].sort(col.sortFn);
    return sortDir === "asc" ? sorted : sorted.reverse();
  }, [rows, columns, sortIdx, sortDir]);

  if (rows.length === 0 && empty) {
    return <>{empty}</>;
  }

  return (
    <div className="overflow-x-auto rounded-lg border border-slate-200 bg-white">
      <table className="w-full text-sm">
        <thead className="bg-slate-50 text-slate-600">
          <tr>
            {columns.map((c, i) => (
              <th
                key={c.key}
                className={cn(
                  "text-left px-4 py-2 font-medium text-xs uppercase tracking-wider whitespace-nowrap",
                  c.sortable && "cursor-pointer select-none",
                  c.className,
                )}
                onClick={() => {
                  if (!c.sortable || !c.sortFn) return;
                  if (sortIdx === i) {
                    setSortDir((d) => (d === "asc" ? "desc" : "asc"));
                  } else {
                    setSortIdx(i);
                    setSortDir("asc");
                  }
                }}
              >
                {c.header}
                {c.sortable && sortIdx === i && (
                  <span className="ml-1 text-slate-400">{sortDir === "asc" ? "↑" : "↓"}</span>
                )}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          {sortedRows.map((r) => (
            <tr
              key={keyOf(r)}
              className={cn(
                "hover:bg-slate-50",
                onRowClick && "cursor-pointer",
                rowClassName?.(r),
              )}
              onClick={() => onRowClick?.(r)}
            >
              {columns.map((c) => (
                <td key={c.key} className={cn("px-4 py-2", c.className)}>
                  {c.cell(r)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
