import { useRef, useState } from "react";
import { cn } from "./util/cn";

export interface FileUploadProps {
  accept?: string;
  multiple?: boolean;
  onFiles: (files: File[]) => void;
  helperText?: string;
}

export function FileUpload({
  accept,
  multiple = true,
  onFiles,
  helperText,
}: FileUploadProps) {
  const ref = useRef<HTMLInputElement>(null);
  const [over, setOver] = useState(false);

  const handle = (list: FileList | null) => {
    if (!list || list.length === 0) return;
    onFiles(Array.from(list));
  };

  return (
    <label
      className={cn(
        "block rounded-lg border-2 border-dashed cursor-pointer p-6 text-center text-sm transition-colors",
        over ? "border-indigo-400 bg-indigo-50" : "border-slate-300 bg-slate-50 hover:bg-slate-100",
      )}
      onDragOver={(e) => {
        e.preventDefault();
        setOver(true);
      }}
      onDragLeave={() => setOver(false)}
      onDrop={(e) => {
        e.preventDefault();
        setOver(false);
        handle(e.dataTransfer.files);
      }}
    >
      <input
        ref={ref}
        type="file"
        className="sr-only"
        accept={accept}
        multiple={multiple}
        onChange={(e) => handle(e.target.files)}
      />
      <p className="font-medium">Drop files here or click to browse</p>
      <p className="text-xs text-slate-500 mt-1">{helperText ?? "Up to 50MB per file."}</p>
    </label>
  );
}
