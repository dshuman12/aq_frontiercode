/**
 * TimerWidget — running-timer pill for the dashboard nav. Shows the
 * elapsed time of the active timer and a stop button. The host
 * supplies the current running entry; this component just animates
 * the count and emits the click.
 */
import { useEffect, useState } from "react";
import { cn } from "./util/cn";

interface TimerWidgetProps {
  startedAt?: string | Date | null;
  taskLabel?: string;
  onStop?: () => void;
  className?: string;
}

export function TimerWidget({ startedAt, taskLabel, onStop, className }: TimerWidgetProps) {
  const [tick, setTick] = useState(Date.now());
  useEffect(() => {
    if (!startedAt) return;
    const id = setInterval(() => setTick(Date.now()), 1000);
    return () => clearInterval(id);
  }, [startedAt]);

  if (!startedAt) return null;
  const ms = tick - new Date(startedAt).getTime();
  return (
    <div
      className={cn(
        "inline-flex items-center gap-2 rounded-full bg-amber-100 px-3 py-1 text-xs font-medium text-amber-900",
        className,
      )}
    >
      <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-amber-600" />
      <span className="font-mono">{formatTimer(ms)}</span>
      {taskLabel ? <span className="hidden md:inline opacity-80">· {taskLabel}</span> : null}
      {onStop ? (
        <button
          type="button"
          onClick={onStop}
          className="ml-1 rounded-full bg-amber-200 px-2 py-0.5 text-[10px] uppercase tracking-wide hover:bg-amber-300"
        >
          stop
        </button>
      ) : null}
    </div>
  );
}

function formatTimer(ms: number): string {
  const total = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(total / 3600).toString().padStart(2, "0");
  const m = Math.floor((total % 3600) / 60).toString().padStart(2, "0");
  const s = (total % 60).toString().padStart(2, "0");
  return `${h}:${m}:${s}`;
}
