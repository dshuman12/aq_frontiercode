/**
 * Tiny Markdown renderer for comment bodies and KB articles.
 * Handles a sane subset (headings, paragraphs, bold/italic/code,
 * lists, links, code fences). Sanitization is the consumer's job —
 * we never render attribute values, just escape text content.
 */
import { ReactNode } from "react";

interface Props {
  source: string;
  className?: string;
}

export function Markdown({ source, className }: Props) {
  const blocks = source.split(/\n{2,}/);
  return (
    <div className={className}>
      {blocks.map((block, i) => {
        if (block.startsWith("```")) {
          const code = block.replace(/^```\w*\n?|```$/g, "");
          return (
            <pre key={i} className="my-3 overflow-x-auto rounded-md bg-slate-100 p-3 text-xs">
              <code>{code}</code>
            </pre>
          );
        }
        if (/^#{1,3}\s/.test(block)) {
          const level = block.match(/^#+/)![0].length;
          const text = block.replace(/^#+\s+/, "");
          const sizes = ["text-xl", "text-lg", "text-base"];
          return (
            <p key={i} className={`my-2 font-semibold ${sizes[level - 1]}`}>{renderInline(text)}</p>
          );
        }
        if (/^[-*]\s/m.test(block)) {
          return (
            <ul key={i} className="my-2 list-disc pl-5">
              {block.split("\n").map((line, j) => (
                <li key={j}>{renderInline(line.replace(/^[-*]\s+/, ""))}</li>
              ))}
            </ul>
          );
        }
        return <p key={i} className="my-2 leading-relaxed">{renderInline(block)}</p>;
      })}
    </div>
  );
}

function renderInline(text: string): ReactNode {
  // bold then italic then code then link, in order
  const parts: (string | ReactNode)[] = [text];
  return parts.flatMap((part, i) =>
    typeof part === "string" ? [...renderToken(part, `t${i}`)] : [part],
  );
}

function* renderToken(text: string, prefix: string): Generator<ReactNode> {
  let buffer = text;
  let key = 0;
  const yieldText = (s: string) => s;
  const re = /(\*\*([^*]+)\*\*|\*([^*]+)\*|`([^`]+)`|\[([^\]]+)\]\((https?:\/\/[^\s)]+)\))/g;
  let last = 0;
  for (const match of buffer.matchAll(re)) {
    const idx = match.index ?? 0;
    if (idx > last) yield yieldText(buffer.slice(last, idx));
    if (match[2]) yield <strong key={`${prefix}-${key++}`}>{match[2]}</strong>;
    else if (match[3]) yield <em key={`${prefix}-${key++}`}>{match[3]}</em>;
    else if (match[4]) yield <code key={`${prefix}-${key++}`} className="rounded bg-slate-100 px-1 text-xs">{match[4]}</code>;
    else if (match[5] && match[6])
      yield (
        <a key={`${prefix}-${key++}`} href={match[6]} target="_blank" rel="noreferrer noopener" className="text-brand-700 underline">
          {match[5]}
        </a>
      );
    last = idx + match[0].length;
  }
  if (last < buffer.length) yield yieldText(buffer.slice(last));
}
