import { forwardRef } from "react";
import { cn } from "./util/cn";

export const Checkbox = forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement>>(
  function Checkbox({ className, ...rest }, ref) {
    return (
      <input
        ref={ref}
        type="checkbox"
        className={cn(
          "rounded border-slate-300 text-indigo-600 focus:ring-indigo-500",
          className,
        )}
        {...rest}
      />
    );
  },
);
