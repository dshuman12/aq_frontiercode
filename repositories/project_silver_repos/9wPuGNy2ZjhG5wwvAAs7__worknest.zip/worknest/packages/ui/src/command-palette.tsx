import { useEffect, useRef, useState } from "react";
import { cn } from "./util/cn";

export interface CommandItem {
  id: string;
  label: string;
  hint?: string;
}

export interface CommandPaletteProps {
  open: boolean;
  onClose: () => void;
  items: CommandItem[];
  onSelect: (item: CommandItem) => void;
  placeholder?: string;
}

export function CommandPalette({
  open,
  onClose,
  items,
  onSelect,
  placeholder = "Type a command…",
}: CommandPaletteProps) {
  const [query, setQuery] = useState("");
  const [active, setActive] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!open) return;
    setQuery("");
    setActive(0);
    setTimeout(() => inputRef.current?.focus(), 0);
  }, [open]);

  if (!open) return null;

  const filtered = query
    ? items.filter((i) => i.label.toLowerCase().includes(query.toLowerCase()))
    : items;

  const handleKey = (e: React.KeyboardEvent) => {
    if (e.key === "Escape") onClose();
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setActive((i) => Math.min(filtered.length - 1, i + 1));
    }
    if (e.key === "ArrowUp") {
      e.preventDefault();
      setActive((i) => Math.max(0, i - 1));
    }
    if (e.key === "Enter") {
      e.preventDefault();
      const item = filtered[active];
      if (item) {
        onSelect(item);
        onClose();
      }
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-sm flex items-start justify-center pt-[15vh]"
      onClick={onClose}
    >
      <div
        className="w-full max-w-xl rounded-lg bg-white border border-slate-200 shadow-xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <input
          ref={inputRef}
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setActive(0);
          }}
          onKeyDown={handleKey}
          placeholder={placeholder}
          className="w-full px-4 py-3 text-base outline-none border-b border-slate-200"
        />
        <ul className="max-h-[60vh] overflow-y-auto">
          {filtered.length === 0 ? (
            <li className="px-4 py-6 text-center text-sm text-slate-500">No matches</li>
          ) : (
            filtered.map((item, i) => (
              <li
                key={item.id}
                className={cn(
                  "px-4 py-2 text-sm cursor-pointer flex items-center justify-between",
                  i === active && "bg-indigo-50 text-indigo-700",
                )}
                onMouseEnter={() => setActive(i)}
                onClick={() => {
                  onSelect(item);
                  onClose();
                }}
              >
                <span>{item.label}</span>
                {item.hint && <span className="text-xs text-slate-400">{item.hint}</span>}
              </li>
            ))
          )}
        </ul>
      </div>
    </div>
  );
}
