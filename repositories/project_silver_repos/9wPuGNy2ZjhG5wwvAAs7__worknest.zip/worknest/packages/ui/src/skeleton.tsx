import { cn } from "./util/cn";

export function Skeleton({ className, ...rest }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn(
        "animate-pulse rounded bg-slate-200",
        className,
      )}
      aria-hidden
      {...rest}
    />
  );
}
