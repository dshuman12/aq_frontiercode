/**
 * Tiny keyboard-shortcut helper. Avoids pulling in `mousetrap` for
 * the four bindings we actually use. Caller provides a map of
 * "g h" / "?" / "/" style chords; we install a single keydown
 * listener on `document` and dispatch on match.
 *
 * Multi-key chords time out after 1500ms; printable single-keys
 * are ignored when an input/textarea/contenteditable has focus.
 */
import { useEffect } from "react";

type Handler = (e: KeyboardEvent) => void;

interface Bindings {
  [chord: string]: Handler;
}

const TYPING_TAGS = new Set(["INPUT", "TEXTAREA", "SELECT"]);

function isTyping(target: EventTarget | null): boolean {
  if (!(target instanceof HTMLElement)) return false;
  if (TYPING_TAGS.has(target.tagName)) return true;
  if (target.isContentEditable) return true;
  return false;
}

export function useKeyboardShortcuts(bindings: Bindings, enabled = true): void {
  useEffect(() => {
    if (!enabled) return;
    let buffer = "";
    let bufferTimer: ReturnType<typeof setTimeout> | null = null;

    function clearBuffer() {
      buffer = "";
      if (bufferTimer) clearTimeout(bufferTimer);
      bufferTimer = null;
    }

    function onKey(e: KeyboardEvent) {
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      if (isTyping(e.target)) return;
      const key = e.key.length === 1 ? e.key.toLowerCase() : e.key;

      const single = bindings[key];
      if (single) {
        single(e);
        clearBuffer();
        return;
      }

      buffer = buffer.length === 0 ? key : `${buffer} ${key}`;
      const chord = bindings[buffer];
      if (chord) {
        chord(e);
        clearBuffer();
        return;
      }
      if (bufferTimer) clearTimeout(bufferTimer);
      bufferTimer = setTimeout(clearBuffer, 1500);
    }

    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("keydown", onKey);
      clearBuffer();
    };
  }, [bindings, enabled]);
}
