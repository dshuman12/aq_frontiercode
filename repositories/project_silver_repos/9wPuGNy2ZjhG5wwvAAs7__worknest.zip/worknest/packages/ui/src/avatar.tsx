import { cn } from "./util/cn";

const COLORS = [
  "bg-rose-500",
  "bg-amber-500",
  "bg-emerald-500",
  "bg-sky-500",
  "bg-violet-500",
  "bg-fuchsia-500",
  "bg-teal-500",
  "bg-indigo-500",
];

function colorFor(name: string): string {
  let h = 0;
  for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) >>> 0;
  return COLORS[h % COLORS.length];
}

function initials(name: string): string {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? "")
    .join("");
}

export interface AvatarProps {
  name: string;
  src?: string;
  size?: "sm" | "md" | "lg";
  className?: string;
}

const SIZE = {
  sm: "h-7 w-7 text-[11px]",
  md: "h-9 w-9 text-sm",
  lg: "h-12 w-12 text-base",
};

export function Avatar({ name, src, size = "md", className }: AvatarProps) {
  if (src) {
    return (
      <img
        src={src}
        alt={name}
        className={cn(SIZE[size], "rounded-full object-cover", className)}
      />
    );
  }
  return (
    <div
      className={cn(
        SIZE[size],
        "rounded-full text-white font-medium flex items-center justify-center select-none",
        colorFor(name),
        className,
      )}
      aria-label={name}
      title={name}
    >
      {initials(name)}
    </div>
  );
}

export interface AvatarGroupProps {
  users: { name: string; src?: string }[];
  max?: number;
  size?: AvatarProps["size"];
}

export function AvatarGroup({ users, max = 5, size = "sm" }: AvatarGroupProps) {
  const visible = users.slice(0, max);
  const overflow = users.length - visible.length;
  return (
    <div className="flex -space-x-2">
      {visible.map((u, i) => (
        <Avatar
          key={u.name + i}
          name={u.name}
          src={u.src}
          size={size}
          className="border-2 border-white"
        />
      ))}
      {overflow > 0 && (
        <div
          className={cn(
            SIZE[size],
            "rounded-full bg-slate-200 text-slate-700 flex items-center justify-center border-2 border-white text-xs",
          )}
        >
          +{overflow}
        </div>
      )}
    </div>
  );
}
