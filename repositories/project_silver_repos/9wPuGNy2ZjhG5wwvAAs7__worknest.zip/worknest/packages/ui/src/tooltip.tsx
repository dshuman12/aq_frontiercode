import { useEffect, useRef, useState } from "react";
import { cn } from "./util/cn";

export interface TooltipProps {
  content: React.ReactNode;
  children: React.ReactElement;
  delayMs?: number;
}

export function Tooltip({ content, children, delayMs = 200 }: TooltipProps) {
  const [open, setOpen] = useState(false);
  const timeoutRef = useRef<number | null>(null);

  useEffect(() => () => {
    if (timeoutRef.current) window.clearTimeout(timeoutRef.current);
  }, []);

  const show = () => {
    if (timeoutRef.current) window.clearTimeout(timeoutRef.current);
    timeoutRef.current = window.setTimeout(() => setOpen(true), delayMs);
  };
  const hide = () => {
    if (timeoutRef.current) window.clearTimeout(timeoutRef.current);
    setOpen(false);
  };

  return (
    <span className="relative inline-block" onMouseEnter={show} onMouseLeave={hide} onFocus={show} onBlur={hide}>
      {children}
      {open && (
        <span
          className={cn(
            "absolute z-50 left-1/2 -translate-x-1/2 -top-2 -translate-y-full whitespace-nowrap",
            "rounded bg-slate-900 px-2 py-1 text-xs text-white shadow",
          )}
          role="tooltip"
        >
          {content}
        </span>
      )}
    </span>
  );
}
