import { cn } from "./util/cn";

export interface EmptyStateProps {
  title: string;
  description?: string;
  action?: React.ReactNode;
  className?: string;
}

export function EmptyState({ title, description, action, className }: EmptyStateProps) {
  return (
    <div
      className={cn(
        "rounded-lg border-2 border-dashed border-slate-200 bg-slate-50 p-10 text-center",
        className,
      )}
    >
      <h3 className="font-semibold text-base">{title}</h3>
      {description && <p className="text-sm text-slate-600 mt-1 max-w-md mx-auto">{description}</p>}
      {action && <div className="mt-4 flex justify-center">{action}</div>}
    </div>
  );
}
