import { Input } from "./input";

export interface DatePickerProps {
  value: Date | null;
  onChange: (next: Date | null) => void;
  placeholder?: string;
  min?: Date;
  max?: Date;
}

export function DatePicker({ value, onChange, min, max, placeholder }: DatePickerProps) {
  const formatted = value ? toIso(value) : "";
  return (
    <Input
      type="date"
      value={formatted}
      placeholder={placeholder}
      min={min ? toIso(min) : undefined}
      max={max ? toIso(max) : undefined}
      onChange={(e) => {
        const v = e.target.value;
        onChange(v ? new Date(v + "T00:00:00") : null);
      }}
    />
  );
}

export interface DateRangePickerProps {
  from: Date | null;
  to: Date | null;
  onChange: (from: Date | null, to: Date | null) => void;
}

export function DateRangePicker({ from, to, onChange }: DateRangePickerProps) {
  return (
    <div className="grid grid-cols-2 gap-2">
      <DatePicker
        value={from}
        onChange={(v) => onChange(v, to)}
        max={to ?? undefined}
        placeholder="Start date"
      />
      <DatePicker
        value={to}
        onChange={(v) => onChange(from, v)}
        min={from ?? undefined}
        placeholder="End date"
      />
    </div>
  );
}

function toIso(d: Date): string {
  return d.toISOString().slice(0, 10);
}
