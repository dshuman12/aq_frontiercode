import { useState } from "react";
import { cn } from "./util/cn";

export interface KanbanCard {
  id: string;
  title: string;
  subtitle?: string;
  badge?: { label: string; variant?: "info" | "warning" | "danger" };
}

export interface KanbanColumn {
  id: string;
  title: string;
  tasks: KanbanCard[];
  wipLimit?: number;
}

export interface KanbanBoardProps {
  columns: KanbanColumn[];
  onTaskMove: (taskId: string, columnId: string) => void;
  onTaskClick?: (taskId: string) => void;
}

export function KanbanBoard({ columns, onTaskMove, onTaskClick }: KanbanBoardProps) {
  const [draggedId, setDraggedId] = useState<string | null>(null);
  const [hoverId, setHoverId] = useState<string | null>(null);

  return (
    <div className="flex gap-4 overflow-x-auto pb-4">
      {columns.map((col) => {
        const isHover = hoverId === col.id;
        const overLimit = col.wipLimit !== undefined && col.tasks.length > col.wipLimit;
        return (
          <div
            key={col.id}
            className={cn(
              "min-w-[280px] flex-shrink-0 rounded-lg p-3 transition-colors",
              isHover ? "bg-indigo-50 border-2 border-indigo-400" : "bg-slate-50 border border-slate-200",
            )}
            onDragOver={(e) => {
              e.preventDefault();
              setHoverId(col.id);
            }}
            onDragLeave={() => setHoverId((id) => (id === col.id ? null : id))}
            onDrop={() => {
              if (draggedId) onTaskMove(draggedId, col.id);
              setDraggedId(null);
              setHoverId(null);
            }}
          >
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-medium text-sm">{col.title}</h3>
              <span
                className={cn(
                  "text-xs",
                  overLimit ? "text-red-600 font-medium" : "text-slate-500",
                )}
              >
                {col.tasks.length}
                {col.wipLimit !== undefined && ` / ${col.wipLimit}`}
              </span>
            </div>
            <div className="space-y-2">
              {col.tasks.map((task) => (
                <div
                  key={task.id}
                  draggable
                  onDragStart={() => setDraggedId(task.id)}
                  onDragEnd={() => setDraggedId(null)}
                  onClick={() => onTaskClick?.(task.id)}
                  className="bg-white rounded p-3 shadow-sm border border-slate-200 cursor-grab active:cursor-grabbing hover:shadow-md transition-shadow"
                >
                  {task.subtitle && (
                    <p className="text-xs text-slate-500 mb-1">{task.subtitle}</p>
                  )}
                  <p className="font-medium text-sm">{task.title}</p>
                  {task.badge && (
                    <span
                      className={cn(
                        "inline-block mt-2 text-xs px-1.5 py-0.5 rounded",
                        task.badge.variant === "danger" && "bg-red-100 text-red-700",
                        task.badge.variant === "warning" && "bg-amber-100 text-amber-700",
                        (!task.badge.variant || task.badge.variant === "info") &&
                          "bg-blue-100 text-blue-700",
                      )}
                    >
                      {task.badge.label}
                    </span>
                  )}
                </div>
              ))}
              {col.tasks.length === 0 && (
                <p className="text-xs text-slate-400 text-center py-4">No tasks</p>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
