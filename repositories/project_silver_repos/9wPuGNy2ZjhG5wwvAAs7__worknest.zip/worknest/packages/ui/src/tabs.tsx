import { Children, isValidElement, useState } from "react";
import { cn } from "./util/cn";

export interface TabProps {
  label: string;
  children: React.ReactNode;
}

export function Tab(_props: TabProps) {
  // Rendered by the parent <Tabs>; this is just a marker component.
  return null;
}

export interface TabsProps {
  children: React.ReactNode;
  defaultIndex?: number;
  className?: string;
}

export function Tabs({ children, defaultIndex = 0, className }: TabsProps) {
  const tabs = Children.toArray(children).filter(
    (c): c is React.ReactElement<TabProps> => isValidElement(c) && c.type === Tab,
  );
  const [active, setActive] = useState(defaultIndex);
  const activeTab = tabs[active];

  return (
    <div className={cn("space-y-4", className)}>
      <div className="border-b border-slate-200 flex gap-4">
        {tabs.map((t, i) => (
          <button
            key={i}
            role="tab"
            aria-selected={active === i}
            className={cn(
              "px-1 py-2 text-sm border-b-2 -mb-px transition-colors",
              active === i
                ? "border-indigo-600 text-indigo-700"
                : "border-transparent text-slate-600 hover:text-slate-900",
            )}
            onClick={() => setActive(i)}
          >
            {t.props.label}
          </button>
        ))}
      </div>
      <div role="tabpanel">{activeTab?.props.children}</div>
    </div>
  );
}
