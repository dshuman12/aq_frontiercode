import { createContext, useCallback, useContext, useEffect, useState } from "react";
import { cn } from "./util/cn";

export interface Toast {
  id: string;
  title: string;
  description?: string;
  variant?: "info" | "success" | "warning" | "danger";
  durationMs?: number;
}

interface ToastContextValue {
  push(toast: Omit<Toast, "id">): void;
  dismiss(id: string): void;
}

const Ctx = createContext<ToastContextValue>({ push: () => {}, dismiss: () => {} });

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const dismiss = useCallback(
    (id: string) => setToasts((cur) => cur.filter((t) => t.id !== id)),
    [],
  );

  const push = useCallback(
    (toast: Omit<Toast, "id">) => {
      const id = Math.random().toString(36).slice(2);
      const item: Toast = { id, durationMs: 4000, variant: "info", ...toast };
      setToasts((cur) => [...cur, item]);
      if (item.durationMs) {
        window.setTimeout(() => dismiss(id), item.durationMs);
      }
    },
    [dismiss],
  );

  return (
    <Ctx.Provider value={{ push, dismiss }}>
      {children}
      <div className="fixed top-4 right-4 z-[100] flex flex-col gap-2 w-80">
        {toasts.map((t) => (
          <div
            key={t.id}
            className={cn(
              "rounded-md border px-4 py-3 shadow bg-white",
              t.variant === "success" && "border-emerald-300 bg-emerald-50",
              t.variant === "warning" && "border-amber-300 bg-amber-50",
              t.variant === "danger" && "border-red-300 bg-red-50",
              t.variant === "info" && "border-slate-200",
            )}
            role="status"
          >
            <div className="font-medium text-sm">{t.title}</div>
            {t.description && (
              <div className="text-xs text-slate-600 mt-0.5">{t.description}</div>
            )}
          </div>
        ))}
      </div>
    </Ctx.Provider>
  );
}

export function useToast(): ToastContextValue {
  return useContext(Ctx);
}
