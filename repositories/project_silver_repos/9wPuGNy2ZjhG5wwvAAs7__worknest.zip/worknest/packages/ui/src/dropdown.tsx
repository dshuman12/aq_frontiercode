import { useEffect, useRef, useState } from "react";
import { cn } from "./util/cn";

export interface DropdownProps {
  trigger: React.ReactNode;
  children: React.ReactNode;
  align?: "left" | "right";
}

export function Dropdown({ trigger, children, align = "right" }: DropdownProps) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onClick = (e: MouseEvent) => {
      if (!ref.current?.contains(e.target as Node)) setOpen(false);
    };
    window.addEventListener("mousedown", onClick);
    return () => window.removeEventListener("mousedown", onClick);
  }, [open]);

  return (
    <div ref={ref} className="relative inline-block">
      <button onClick={() => setOpen((v) => !v)} type="button">
        {trigger}
      </button>
      {open && (
        <div
          className={cn(
            "absolute z-30 mt-1 min-w-[10rem] rounded-md bg-white border border-slate-200 shadow-lg py-1",
            align === "right" ? "right-0" : "left-0",
          )}
          role="menu"
          onClick={() => setOpen(false)}
        >
          {children}
        </div>
      )}
    </div>
  );
}

export interface DropdownItemProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "default" | "danger";
  onSelect?: () => void;
}

export function DropdownItem({
  className,
  variant = "default",
  onSelect,
  children,
  ...rest
}: DropdownItemProps) {
  return (
    <button
      role="menuitem"
      className={cn(
        "w-full text-left px-3 py-1.5 text-sm",
        variant === "danger"
          ? "text-red-600 hover:bg-red-50"
          : "text-slate-700 hover:bg-slate-50",
        className,
      )}
      onClick={() => onSelect?.()}
      {...rest}
    >
      {children}
    </button>
  );
}
