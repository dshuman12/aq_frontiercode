import { forwardRef } from "react";
import { cn } from "./util/cn";

export const Label = forwardRef<HTMLLabelElement, React.LabelHTMLAttributes<HTMLLabelElement>>(
  function Label({ className, ...rest }, ref) {
    return (
      <label
        ref={ref}
        className={cn("block text-sm font-medium text-slate-700 mb-1", className)}
        {...rest}
      />
    );
  },
);

export const Input = forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement>>(
  function Input({ className, ...rest }, ref) {
    return (
      <input
        ref={ref}
        className={cn(
          "block w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm placeholder:text-slate-400",
          "focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500",
          "aria-invalid:border-red-500 aria-invalid:focus:ring-red-500 aria-invalid:focus:border-red-500",
          "disabled:bg-slate-50 disabled:text-slate-500",
          className,
        )}
        {...rest}
      />
    );
  },
);

export const Textarea = forwardRef<HTMLTextAreaElement, React.TextareaHTMLAttributes<HTMLTextAreaElement>>(
  function Textarea({ className, ...rest }, ref) {
    return (
      <textarea
        ref={ref}
        className={cn(
          "block w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm placeholder:text-slate-400",
          "focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500",
          "aria-invalid:border-red-500 aria-invalid:focus:ring-red-500 aria-invalid:focus:border-red-500",
          "disabled:bg-slate-50 disabled:text-slate-500",
          className,
        )}
        {...rest}
      />
    );
  },
);
