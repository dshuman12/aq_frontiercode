/**
 * BulkActionBar — sticky bottom toolbar that appears when one or
 * more rows are selected. Receives a count, a clear handler, and
 * arbitrary action children.
 */
import { ReactNode } from "react";
import { cn } from "./util/cn";

interface BulkActionBarProps {
  count: number;
  onClear: () => void;
  children: ReactNode;
  className?: string;
}

export function BulkActionBar({ count, onClear, children, className }: BulkActionBarProps) {
  if (count === 0) return null;
  return (
    <div
      className={cn(
        "fixed inset-x-0 bottom-4 mx-auto flex w-fit items-center gap-3 rounded-full border border-slate-200",
        "bg-white px-4 py-2 shadow-lg",
        className,
      )}
    >
      <span className="text-sm font-medium text-slate-700">{count} selected</span>
      <span className="h-4 w-px bg-slate-200" />
      <div className="flex items-center gap-2">{children}</div>
      <span className="h-4 w-px bg-slate-200" />
      <button
        onClick={onClear}
        className="text-xs text-slate-500 hover:text-slate-700"
      >
        Clear
      </button>
    </div>
  );
}
