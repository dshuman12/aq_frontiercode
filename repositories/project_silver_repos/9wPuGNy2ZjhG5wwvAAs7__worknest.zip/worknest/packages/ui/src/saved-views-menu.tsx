/**
 * SavedViewsMenu — dropdown showing the current user's saved views
 * for a resource, plus shared views, plus a "Save current as..."
 * affordance. The actual persistence is the consumer's problem;
 * this is a presentational component.
 */
import { useState } from "react";
import { cn } from "./util/cn";

export interface SavedView {
  id: string;
  name: string;
  isShared: boolean;
  isDefault: boolean;
}

interface SavedViewsMenuProps {
  views: SavedView[];
  activeId?: string | null;
  onSelect: (id: string | null) => void;
  onSaveCurrent?: (name: string) => void;
  onDelete?: (id: string) => void;
  className?: string;
}

export function SavedViewsMenu({
  views,
  activeId,
  onSelect,
  onSaveCurrent,
  onDelete,
  className,
}: SavedViewsMenuProps) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const active = views.find((v) => v.id === activeId);

  return (
    <div className={cn("relative", className)}>
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="inline-flex h-9 items-center gap-2 rounded-md border border-slate-200 bg-white px-3 text-sm hover:bg-slate-50"
      >
        <span>{active?.name ?? "All items"}</span>
        <span aria-hidden>▾</span>
      </button>
      {open ? (
        <div className="absolute right-0 z-10 mt-2 w-64 rounded-md border border-slate-200 bg-white shadow-lg">
          <button
            onClick={() => {
              onSelect(null);
              setOpen(false);
            }}
            className="block w-full px-3 py-2 text-left text-sm hover:bg-slate-50"
          >
            All items
          </button>
          <div className="my-1 h-px bg-slate-100" />
          {views.length === 0 ? (
            <div className="px-3 py-2 text-xs text-slate-500">No saved views yet.</div>
          ) : null}
          {views.map((v) => (
            <div
              key={v.id}
              className="flex items-center justify-between px-2 py-1 hover:bg-slate-50"
            >
              <button
                onClick={() => {
                  onSelect(v.id);
                  setOpen(false);
                }}
                className="flex-1 px-1 py-1 text-left text-sm"
              >
                {v.name}
                {v.isDefault ? <span className="ml-1 text-xs text-slate-400">★</span> : null}
                {v.isShared ? <span className="ml-1 text-xs text-slate-400">shared</span> : null}
              </button>
              {onDelete ? (
                <button
                  onClick={() => onDelete(v.id)}
                  className="text-xs text-slate-400 hover:text-red-600"
                  aria-label="Delete view"
                >
                  ✕
                </button>
              ) : null}
            </div>
          ))}
          {onSaveCurrent ? (
            <div className="border-t border-slate-100 p-2">
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Save current view as…"
                className="block w-full rounded-md border border-slate-200 px-2 py-1 text-sm"
                onKeyDown={(e) => {
                  if (e.key === "Enter" && name.trim()) {
                    onSaveCurrent(name.trim());
                    setName("");
                    setOpen(false);
                  }
                }}
              />
            </div>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}
