import { forwardRef } from "react";
import { cn } from "./util/cn";

export const Select = forwardRef<HTMLSelectElement, React.SelectHTMLAttributes<HTMLSelectElement>>(
  function Select({ className, ...rest }, ref) {
    return (
      <select
        ref={ref}
        className={cn(
          "block w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm",
          "focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500",
          "disabled:bg-slate-50 disabled:text-slate-500",
          className,
        )}
        {...rest}
      />
    );
  },
);
