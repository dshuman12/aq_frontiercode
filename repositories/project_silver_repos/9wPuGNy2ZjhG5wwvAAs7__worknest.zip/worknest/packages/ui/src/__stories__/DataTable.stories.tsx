import type { Meta, StoryObj } from "@storybook/react";
import { Badge } from "../badge";
import { DataTable } from "../data-table";

interface Row { id: string; name: string; status: "active" | "blocked"; lastSeen: string }
const rows: Row[] = [
  { id: "u1", name: "Alex Castillo", status: "active", lastSeen: "2025-01-22" },
  { id: "u2", name: "Priya Shah", status: "active", lastSeen: "2025-01-21" },
  { id: "u3", name: "Jordan Park", status: "blocked", lastSeen: "2025-01-12" },
];

const meta: Meta = { title: "Data/DataTable", tags: ["autodocs"] };
export default meta;

export const Sortable: StoryObj = {
  render: () => (
    <DataTable<Row>
      rows={rows}
      keyOf={(r) => r.id}
      columns={[
        { key: "name", header: "Name", sortable: true, sortFn: (a, b) => a.name.localeCompare(b.name), cell: (r) => r.name },
        { key: "status", header: "Status", cell: (r) => <Badge variant={r.status === "active" ? "success" : "danger"}>{r.status}</Badge> },
        { key: "lastSeen", header: "Last seen", sortable: true, sortFn: (a, b) => a.lastSeen.localeCompare(b.lastSeen), cell: (r) => r.lastSeen },
      ]}
    />
  ),
};
