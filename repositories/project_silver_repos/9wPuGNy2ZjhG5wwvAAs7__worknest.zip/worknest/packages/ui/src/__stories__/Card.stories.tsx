import type { Meta, StoryObj } from "@storybook/react";
import { Button } from "../button";
import { Card, CardBody, CardFooter, CardHeader, CardTitle } from "../card";

const meta: Meta = { title: "Primitives/Card", tags: ["autodocs"] };
export default meta;

export const Basic: StoryObj = {
  render: () => (
    <Card className="max-w-md">
      <CardHeader><CardTitle>Project status</CardTitle></CardHeader>
      <CardBody>3 open tasks · 2 in review</CardBody>
    </Card>
  ),
};

export const WithFooter: StoryObj = {
  render: () => (
    <Card className="max-w-md">
      <CardHeader><CardTitle>Q1 launch</CardTitle></CardHeader>
      <CardBody>Track everything that needs to ship before the launch event.</CardBody>
      <CardFooter className="justify-end gap-2">
        <Button variant="outline">Open</Button>
        <Button>Promote to milestone</Button>
      </CardFooter>
    </Card>
  ),
};

export const StatGrid: StoryObj = {
  render: () => (
    <div className="grid grid-cols-2 gap-3 max-w-xl">
      {[
        { label: "Open tasks", value: 42, delta: "+3 this week" },
        { label: "Overdue", value: 7, delta: "-2 vs last week" },
        { label: "Resolved", value: 128, delta: "+18% MoM" },
        { label: "Awaiting approval", value: 5 },
      ].map((s) => (
        <Card key={s.label}>
          <CardBody>
            <p className="text-xs uppercase tracking-wide text-slate-500">{s.label}</p>
            <p className="text-3xl font-semibold mt-1">{s.value}</p>
            {s.delta && <p className="text-xs text-slate-500 mt-1">{s.delta}</p>}
          </CardBody>
        </Card>
      ))}
    </div>
  ),
};
