import type { Meta, StoryObj } from "@storybook/react";
import { Button } from "../button";
import { Card, CardBody, CardFooter, CardHeader, CardTitle } from "../card";
import { Checkbox } from "../checkbox";
import { Input, Label, Textarea } from "../input";
import { Select } from "../select";
import { Switch } from "../switch";
import { useState } from "react";

const meta: Meta = { title: "Patterns/Forms", tags: ["autodocs"] };
export default meta;

export const NewProject: StoryObj = {
  render: () => (
    <Card className="max-w-md">
      <CardHeader><CardTitle>New project</CardTitle></CardHeader>
      <CardBody className="space-y-3">
        <div><Label htmlFor="name">Name</Label><Input id="name" placeholder="Q4 marketing site refresh" /></div>
        <div><Label htmlFor="key">Key</Label><Input id="key" placeholder="MKT" /></div>
        <div>
          <Label htmlFor="desc">Description</Label>
          <Textarea id="desc" rows={3} placeholder="Optional context for the team." />
        </div>
        <div>
          <Label htmlFor="vis">Visibility</Label>
          <Select id="vis" defaultValue="org">
            <option value="org">Everyone in the organization</option>
            <option value="team">Specific team</option>
            <option value="private">Just me</option>
          </Select>
        </div>
      </CardBody>
      <CardFooter className="justify-end gap-2">
        <Button variant="outline">Cancel</Button>
        <Button>Create project</Button>
      </CardFooter>
    </Card>
  ),
};

export const Toggles: StoryObj = {
  render: () => {
    const [tfa, setTfa] = useState(true);
    const [box, setBox] = useState(false);
    return (
      <Card className="max-w-md">
        <CardBody className="space-y-3">
          <div className="flex items-center justify-between">
            <span>Two-factor authentication</span>
            <Switch checked={tfa} onCheckedChange={setTfa} />
          </div>
          <label className="flex items-center gap-2">
            <Checkbox checked={box} onChange={(e) => setBox(e.target.checked)} />
            Send me product updates
          </label>
        </CardBody>
      </Card>
    );
  },
};
