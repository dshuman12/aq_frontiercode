import type { Meta, StoryObj } from "@storybook/react";
import { useState } from "react";
import { KanbanBoard } from "../kanban-board";

const initial = [
  { id: "todo", title: "Backlog", tasks: [
    { id: "t1", title: "Audit funnel", subtitle: "LAUNCH-1" },
    { id: "t2", title: "Migrate CMS", subtitle: "LAUNCH-3" },
  ]},
  { id: "doing", title: "In progress", tasks: [
    { id: "t3", title: "Storyboard welcome screen", subtitle: "LAUNCH-2" },
  ]},
  { id: "done", title: "Done", tasks: [
    { id: "t5", title: "Ship dashboards", subtitle: "LAUNCH-6" },
  ]},
];

const meta: Meta = { title: "Data/KanbanBoard", tags: ["autodocs"] };
export default meta;

export const Default: StoryObj = {
  render: () => {
    const [cols, setCols] = useState(initial);
    return (
      <KanbanBoard
        columns={cols}
        onTaskMove={(taskId, columnId) => {
          setCols((prev) => {
            const out = prev.map((c) => ({ ...c, tasks: [...c.tasks] }));
            const moved = prev.flatMap((c) => c.tasks).find((t) => t.id === taskId);
            for (const c of out) c.tasks = c.tasks.filter((t) => t.id !== taskId);
            if (moved) out.find((c) => c.id === columnId)?.tasks.push(moved);
            return out;
          });
        }}
      />
    );
  },
};
