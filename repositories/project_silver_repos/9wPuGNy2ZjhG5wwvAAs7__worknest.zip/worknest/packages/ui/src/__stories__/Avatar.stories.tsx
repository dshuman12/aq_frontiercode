import type { Meta, StoryObj } from "@storybook/react";
import { Avatar, AvatarGroup } from "../avatar";

const meta: Meta<typeof Avatar> = {
  title: "Primitives/Avatar",
  component: Avatar,
  tags: ["autodocs"],
  args: { name: "Alex Castillo" },
};

export default meta;
type Story = StoryObj<typeof Avatar>;

export const InitialsOnly: Story = {};
export const Small: Story = { args: { size: "sm" } };
export const Large: Story = { args: { size: "lg" } };

export const Group: Story = {
  render: () => (
    <AvatarGroup
      max={4}
      users={[
        { name: "Alex Castillo" },
        { name: "Priya Shah" },
        { name: "Jordan Park" },
        { name: "Sam Chen" },
        { name: "Elena Rossi" },
        { name: "Ricky Adeyemi" },
      ]}
    />
  ),
};
