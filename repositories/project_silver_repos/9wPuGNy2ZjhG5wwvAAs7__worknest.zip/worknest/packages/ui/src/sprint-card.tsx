/**
 * SprintCard — summary tile for a sprint. Shows status, dates, task
 * counts, and an inline progress bar (done / total). Action slots on
 * the right are arbitrary children.
 */
import { ReactNode } from "react";
import { cn } from "./util/cn";

interface SprintCardProps {
  name: string;
  status: "planned" | "active" | "completed" | "cancelled";
  goal?: string | null;
  startsAt?: string | Date | null;
  endsAt?: string | Date | null;
  totalTasks: number;
  doneTasks: number;
  actions?: ReactNode;
  className?: string;
}

const STATUS: Record<string, { label: string; tone: string }> = {
  planned: { label: "Planned", tone: "bg-slate-100 text-slate-700" },
  active: { label: "Active", tone: "bg-sky-100 text-sky-800" },
  completed: { label: "Completed", tone: "bg-emerald-100 text-emerald-800" },
  cancelled: { label: "Cancelled", tone: "bg-amber-100 text-amber-800" },
};

export function SprintCard({
  name,
  status,
  goal,
  startsAt,
  endsAt,
  totalTasks,
  doneTasks,
  actions,
  className,
}: SprintCardProps) {
  const pct = totalTasks > 0 ? Math.round((doneTasks / totalTasks) * 100) : 0;
  return (
    <div className={cn("rounded-lg border border-slate-200 bg-white p-4 shadow-sm", className)}>
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-base font-semibold">{name}</h3>
            <span className={cn("rounded-full px-2 py-0.5 text-xs font-medium", STATUS[status].tone)}>
              {STATUS[status].label}
            </span>
          </div>
          {goal ? <p className="mt-1 text-sm text-slate-600">{goal}</p> : null}
          {startsAt && endsAt ? (
            <p className="mt-1 text-xs text-slate-500">
              {new Date(startsAt).toLocaleDateString()} →{" "}
              {new Date(endsAt).toLocaleDateString()}
            </p>
          ) : null}
        </div>
        {actions ? <div className="flex items-center gap-2">{actions}</div> : null}
      </div>
      <div className="mt-3">
        <div className="flex items-center justify-between text-xs text-slate-600">
          <span>
            {doneTasks} / {totalTasks} tasks done
          </span>
          <span>{pct}%</span>
        </div>
        <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-slate-100">
          <div className="h-full bg-emerald-500 transition-all" style={{ width: `${pct}%` }} />
        </div>
      </div>
    </div>
  );
}
