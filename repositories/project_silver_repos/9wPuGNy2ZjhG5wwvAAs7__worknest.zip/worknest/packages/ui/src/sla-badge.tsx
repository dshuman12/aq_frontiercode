/**
 * SLABadge — at-a-glance SLA status for a ticket. Tone is derived
 * from the timer state:
 *   - met         → green
 *   - on-track    → neutral, with remaining time label
 *   - at-risk     → amber (≤25% of window remaining)
 *   - breached    → red
 */
import { cn } from "./util/cn";

export interface SlaBadgeProps {
  dueAt: string | Date;
  metAt?: string | Date | null;
  breached?: boolean;
  label?: string;
  className?: string;
  now?: number;
}

export function SLABadge({ dueAt, metAt, breached, label, className, now }: SlaBadgeProps) {
  const due = typeof dueAt === "string" ? new Date(dueAt) : dueAt;
  const ts = now ?? Date.now();
  const remainingMs = due.getTime() - ts;
  const tone =
    metAt && new Date(metAt).getTime() <= due.getTime()
      ? "success"
      : metAt
        ? "muted"
        : breached || remainingMs < 0
          ? "danger"
          : remainingMs < 60 * 60 * 1000
            ? "warning"
            : "neutral";
  const text = metAt
    ? "met"
    : remainingMs < 0
      ? `${formatDelta(-remainingMs)} over`
      : `${formatDelta(remainingMs)} left`;

  const toneClass = {
    success: "bg-emerald-100 text-emerald-800",
    muted: "bg-slate-100 text-slate-600",
    danger: "bg-red-100 text-red-800",
    warning: "bg-amber-100 text-amber-800",
    neutral: "bg-sky-100 text-sky-800",
  }[tone];

  return (
    <span
      className={cn("inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium", toneClass, className)}
    >
      {label ? <span className="font-semibold">{label}:</span> : null}
      {text}
    </span>
  );
}

function formatDelta(ms: number): string {
  const minutes = Math.floor(ms / 60000);
  if (minutes < 60) return `${minutes}m`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ${minutes % 60}m`;
  const days = Math.floor(hours / 24);
  return `${days}d ${hours % 24}h`;
}
