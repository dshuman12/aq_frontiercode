/**
 * ActivityList — shared component for both the global activity feed
 * and per-resource sidebars. Groups by day and renders each item
 * with an actor pill, a verb, and a relative time.
 */
import { ReactNode } from "react";
import { cn } from "./util/cn";

export interface ActivityItem {
  id: string;
  resource: string;
  resourceId: string;
  verb: string;
  summary: string;
  actorId: string | null;
  createdAt: string | Date;
}

interface ActivityListProps {
  items: ActivityItem[];
  resolveActorName?: (actorId: string) => string;
  emptyState?: ReactNode;
  className?: string;
}

export function ActivityList({ items, resolveActorName, emptyState, className }: ActivityListProps) {
  if (items.length === 0) {
    return <div className={cn("py-8 text-center text-sm text-slate-500", className)}>{emptyState ?? "No activity"}</div>;
  }
  const groups = groupByDay(items);
  return (
    <div className={cn("space-y-6", className)}>
      {groups.map(([day, group]) => (
        <section key={day}>
          <h3 className="text-xs font-semibold uppercase tracking-wide text-slate-500">{day}</h3>
          <ul className="mt-2 space-y-2">
            {group.map((item) => (
              <li
                key={item.id}
                className="flex items-start justify-between rounded-md border border-slate-100 bg-white p-3 text-sm"
              >
                <div>
                  <p className="text-slate-700">
                    {item.actorId && resolveActorName ? (
                      <span className="font-medium">{resolveActorName(item.actorId)}</span>
                    ) : item.actorId ? (
                      <span className="font-medium">{item.actorId.slice(0, 6)}</span>
                    ) : (
                      <span className="font-medium text-slate-500">System</span>
                    )}{" "}
                    <span className="text-slate-500">{item.verb}</span>{" "}
                    <span>{item.summary}</span>
                  </p>
                  <p className="mt-1 text-xs text-slate-400">
                    {item.resource} · {item.resourceId.slice(0, 8)}
                  </p>
                </div>
                <span className="ml-3 shrink-0 text-xs text-slate-400">
                  {formatTime(item.createdAt)}
                </span>
              </li>
            ))}
          </ul>
        </section>
      ))}
    </div>
  );
}

function groupByDay(items: ActivityItem[]): [string, ActivityItem[]][] {
  const out = new Map<string, ActivityItem[]>();
  for (const item of items) {
    const date = new Date(item.createdAt);
    const key = date.toLocaleDateString(undefined, { dateStyle: "medium" });
    if (!out.has(key)) out.set(key, []);
    out.get(key)!.push(item);
  }
  return Array.from(out.entries());
}

function formatTime(value: string | Date): string {
  const d = typeof value === "string" ? new Date(value) : value;
  return d.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" });
}
