import { Input, Label, Textarea } from "./input";
import { Select } from "./select";
import { Switch } from "./switch";
import { cn } from "./util/cn";

export type FormFieldType =
  | "text"
  | "textarea"
  | "number"
  | "date"
  | "email"
  | "url"
  | "select"
  | "switch"
  | "user";

export interface FormField {
  key: string;
  label: string;
  type: FormFieldType;
  required?: boolean;
  placeholder?: string;
  description?: string;
  options?: { value: string; label: string }[];
}

export interface FormBuilderProps {
  fields: FormField[];
  values: Record<string, unknown>;
  onChange: (values: Record<string, unknown>) => void;
  errors?: Record<string, string>;
  className?: string;
}

export function FormBuilder({
  fields,
  values,
  onChange,
  errors,
  className,
}: FormBuilderProps) {
  const setField = (key: string, value: unknown) =>
    onChange({ ...values, [key]: value });

  return (
    <div className={cn("space-y-4", className)}>
      {fields.map((f) => {
        const id = `field-${f.key}`;
        const error = errors?.[f.key];
        const value = (values[f.key] ?? "") as string;
        return (
          <div key={f.key}>
            <Label htmlFor={id}>
              {f.label}
              {f.required && <span className="text-red-500 ml-0.5">*</span>}
            </Label>
            {f.description && (
              <p className="text-xs text-slate-500 mb-1">{f.description}</p>
            )}
            {f.type === "textarea" ? (
              <Textarea
                id={id}
                rows={4}
                value={value}
                placeholder={f.placeholder}
                aria-invalid={!!error}
                onChange={(e) => setField(f.key, e.target.value)}
              />
            ) : f.type === "select" ? (
              <Select
                id={id}
                value={value}
                aria-invalid={!!error}
                onChange={(e) => setField(f.key, e.target.value)}
              >
                <option value="">Select…</option>
                {f.options?.map((o) => (
                  <option key={o.value} value={o.value}>
                    {o.label}
                  </option>
                ))}
              </Select>
            ) : f.type === "switch" ? (
              <Switch
                checked={Boolean(values[f.key])}
                onCheckedChange={(v) => setField(f.key, v)}
              />
            ) : (
              <Input
                id={id}
                type={
                  f.type === "number"
                    ? "number"
                    : f.type === "email"
                      ? "email"
                      : f.type === "url"
                        ? "url"
                        : f.type === "date"
                          ? "date"
                          : "text"
                }
                value={value}
                placeholder={f.placeholder}
                aria-invalid={!!error}
                onChange={(e) =>
                  setField(
                    f.key,
                    f.type === "number" ? Number(e.target.value) : e.target.value,
                  )
                }
              />
            )}
            {error && <p className="text-xs text-red-600 mt-1">{error}</p>}
          </div>
        );
      })}
    </div>
  );
}
