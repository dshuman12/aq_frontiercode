import { button, definitionList, heading, layout, paragraph, plainText } from "../renderer";
import { registerTemplate } from "../registry";

export interface AssetWarrantyProps {
  recipientName: string;
  assetName: string;
  serialNumber?: string;
  warrantyEndsLabel: string;
  daysRemaining: number;
  assetUrl: string;
  vendorName?: string;
}

export const assetWarrantyTemplate = registerTemplate<AssetWarrantyProps>({
  key: "asset-warranty",
  tags: ["asset", "reminder"],
  render(props) {
    const rows: { label: string; value: string }[] = [{ label: "Asset", value: props.assetName }];
    if (props.serialNumber) rows.push({ label: "Serial #", value: props.serialNumber });
    rows.push({ label: "Warranty ends", value: props.warrantyEndsLabel });
    rows.push({ label: "Days remaining", value: String(props.daysRemaining) });
    if (props.vendorName) rows.push({ label: "Vendor", value: props.vendorName });

    const html = layout({
      previewText: `${props.assetName} warranty ends ${props.warrantyEndsLabel}.`,
      body: [
        heading(`Warranty expiring soon`),
        paragraph(`Hi ${props.recipientName},`),
        paragraph(`The warranty on ${props.assetName} expires in ${props.daysRemaining} days. Time to plan a renewal.`),
        definitionList(rows),
        button({ href: props.assetUrl, label: "Open asset" }),
      ].join("\n"),
    });
    const text = plainText({
      paragraphs: [
        `Hi ${props.recipientName},`,
        `The warranty on ${props.assetName} expires in ${props.daysRemaining} days (${props.warrantyEndsLabel}).`,
      ],
      cta: { label: "Open asset", href: props.assetUrl },
    });
    return {
      subject: `Warranty expiring in ${props.daysRemaining} days: ${props.assetName}`,
      html,
      text,
    };
  },
});
