import { button, divider, escapeHtml, heading, layout, paragraph, plainText } from "../renderer";
import { registerTemplate } from "../registry";

export interface WeeklyDigestProps {
  recipientName: string;
  organizationName: string;
  weekOfLabel: string;
  dashboardUrl: string;
  metrics: {
    completedTasks: number;
    openTasks: number;
    overdueTasks: number;
    ticketsResolved: number;
    averageResolutionHours: number;
  };
  topContributors: { name: string; completed: number }[];
}

export const weeklyDigestTemplate = registerTemplate<WeeklyDigestProps>({
  key: "weekly-digest",
  tags: ["digest"],
  render(props) {
    const metricCard = (label: string, value: string | number) =>
      `<td valign="top" align="center" style="padding:16px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;">
        <div style="font-size:13px;color:#475569;text-transform:uppercase;letter-spacing:0.04em;">${escapeHtml(label)}</div>
        <div style="font-size:26px;font-weight:700;color:#0f172a;margin-top:4px;">${value}</div>
      </td>`;

    const metricsRow = `
<table cellspacing="8" cellpadding="0" style="width:100%;margin:16px 0;">
  <tr>
    ${metricCard("Completed", props.metrics.completedTasks)}
    ${metricCard("Open", props.metrics.openTasks)}
    ${metricCard("Overdue", props.metrics.overdueTasks)}
  </tr>
  <tr>
    ${metricCard("Tickets resolved", props.metrics.ticketsResolved)}
    ${metricCard("Avg resolution", `${props.metrics.averageResolutionHours.toFixed(1)}h`)}
    <td></td>
  </tr>
</table>`;

    const contribRows = props.topContributors
      .map(
        (c, i) => `
<tr>
  <td style="padding:6px 0;color:#475569;width:32px;">${i + 1}.</td>
  <td style="padding:6px 0;color:#0f172a;">${escapeHtml(c.name)}</td>
  <td style="padding:6px 0;color:#475569;text-align:right;">${c.completed} completed</td>
</tr>`,
      )
      .join("");

    const html = layout({
      previewText: `Your ${props.organizationName} weekly summary.`,
      body: [
        heading(`Week of ${props.weekOfLabel}`),
        paragraph(`Hi ${props.recipientName}, here's how things moved at ${props.organizationName} this week.`),
        metricsRow,
        divider(),
        `<h2 style="margin:0 0 8px 0;font-size:16px;color:#0f172a;">Top contributors</h2>`,
        `<table cellspacing="0" cellpadding="0" style="width:100%;">${contribRows}</table>`,
        button({ href: props.dashboardUrl, label: "Open dashboard" }),
      ].join("\n"),
    });
    const text = plainText({
      paragraphs: [
        `Hi ${props.recipientName},`,
        `Digest for ${props.organizationName} (week of ${props.weekOfLabel}):`,
        `  - Completed tasks: ${props.metrics.completedTasks}`,
        `  - Open tasks: ${props.metrics.openTasks}`,
        `  - Overdue: ${props.metrics.overdueTasks}`,
        `  - Tickets resolved: ${props.metrics.ticketsResolved}`,
        `  - Avg resolution: ${props.metrics.averageResolutionHours.toFixed(1)}h`,
        ``,
        `Top contributors:`,
        ...props.topContributors.map((c, i) => `  ${i + 1}. ${c.name} — ${c.completed} completed`),
      ],
      cta: { label: "Open dashboard", href: props.dashboardUrl },
    });
    return {
      subject: `Your ${props.organizationName} digest, week of ${props.weekOfLabel}`,
      html,
      text,
    };
  },
});
