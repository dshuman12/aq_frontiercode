import { button, definitionList, heading, layout, paragraph, plainText } from "../renderer";
import { registerTemplate } from "../registry";

export interface TicketAssignedProps {
  assigneeName: string;
  requesterName: string;
  ticketKey: string;
  ticketTitle: string;
  ticketUrl: string;
  category?: string;
  priority: string;
}

export const ticketAssignedTemplate = registerTemplate<TicketAssignedProps>({
  key: "ticket-assigned",
  tags: ["ticket", "transactional"],
  render(props) {
    const html = layout({
      previewText: `New ticket from ${props.requesterName}.`,
      body: [
        heading(`A ticket was assigned to you`),
        paragraph(`Hi ${props.assigneeName}, ${props.requesterName} just opened a ticket and it's been routed your way.`),
        definitionList([
          { label: "Reference", value: props.ticketKey },
          { label: "Title", value: props.ticketTitle },
          { label: "Category", value: props.category ?? "—" },
          { label: "Priority", value: props.priority },
          { label: "Submitted by", value: props.requesterName },
        ]),
        button({ href: props.ticketUrl, label: "Open ticket" }),
      ].join("\n"),
    });
    const text = plainText({
      paragraphs: [
        `Hi ${props.assigneeName},`,
        `${props.requesterName} just opened ${props.ticketKey} and it's assigned to you.`,
        `Title: ${props.ticketTitle} (${props.priority})`,
      ],
      cta: { label: "Open ticket", href: props.ticketUrl },
    });
    return { subject: `Ticket assigned: ${props.ticketKey}`, html, text };
  },
});
