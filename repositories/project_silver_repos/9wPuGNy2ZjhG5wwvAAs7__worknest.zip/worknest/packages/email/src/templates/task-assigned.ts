import { button, definitionList, heading, layout, paragraph, plainText } from "../renderer";
import { registerTemplate } from "../registry";

export interface TaskAssignedProps {
  assigneeName: string;
  assignerName: string;
  projectName: string;
  taskKey: string;
  taskTitle: string;
  taskUrl: string;
  priority: string;
  dueAtLabel?: string;
}

export const taskAssignedTemplate = registerTemplate<TaskAssignedProps>({
  key: "task-assigned",
  tags: ["task", "transactional"],
  render(props) {
    const dueRow = props.dueAtLabel ? [{ label: "Due", value: props.dueAtLabel }] : [];
    const html = layout({
      previewText: `${props.assignerName} assigned you ${props.taskKey}.`,
      body: [
        heading(`You've been assigned a new task`),
        paragraph(
          `Hi ${props.assigneeName}, ${props.assignerName} assigned you a task in ${props.projectName}.`,
        ),
        definitionList([
          { label: "Project", value: props.projectName },
          { label: "Reference", value: props.taskKey },
          { label: "Title", value: props.taskTitle },
          { label: "Priority", value: props.priority },
          ...dueRow,
        ]),
        button({ href: props.taskUrl, label: "Open task" }),
      ].join("\n"),
    });
    const text = plainText({
      paragraphs: [
        `Hi ${props.assigneeName}, ${props.assignerName} assigned you ${props.taskKey} in ${props.projectName}.`,
        `Title: ${props.taskTitle} (priority ${props.priority})`,
        props.dueAtLabel ? `Due: ${props.dueAtLabel}` : "",
      ].filter(Boolean),
      cta: { label: "Open task", href: props.taskUrl },
    });
    return { subject: `[${props.taskKey}] ${props.taskTitle}`, html, text };
  },
});
