import { button, footnote, heading, layout, paragraph, plainText } from "../renderer";
import { registerTemplate } from "../registry";

export interface WelcomeProps {
  name: string;
  organizationName: string;
  ctaUrl: string;
}

export const welcomeTemplate = registerTemplate<WelcomeProps>({
  key: "welcome",
  tags: ["welcome", "transactional"],
  render(props) {
    const subject = `Welcome to WorkNest, ${props.name}!`;
    const html = layout({
      previewText: `${props.organizationName} is set up and waiting for you.`,
      body: [
        heading(`Welcome aboard, ${props.name}!`),
        paragraph(
          `${props.organizationName} is ready on WorkNest. Take a couple of minutes to invite your team and import your existing projects.`,
        ),
        button({ href: props.ctaUrl, label: "Open my workspace" }),
        paragraph(
          `From here you can spin up projects, build approval workflows, set up internal request forms, and connect Slack or your IdP.`,
        ),
        footnote(`If you didn't sign up for WorkNest, you can ignore this message.`),
      ].join("\n"),
    });
    const text = plainText({
      paragraphs: [
        `Welcome aboard, ${props.name}!`,
        `${props.organizationName} is ready on WorkNest. Open the link below to finish onboarding.`,
      ],
      cta: { label: "Open my workspace", href: props.ctaUrl },
    });
    return { subject, html, text };
  },
});
