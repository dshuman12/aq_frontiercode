import { button, definitionList, heading, layout, paragraph, plainText } from "../renderer";
import { registerTemplate } from "../registry";

export interface ApprovalPendingProps {
  approverName: string;
  workflowName: string;
  stepName: string;
  subjectTitle: string;
  initiatorName: string;
  approvalUrl: string;
  rejectUrl?: string;
  slaLabel?: string;
}

export const approvalPendingTemplate = registerTemplate<ApprovalPendingProps>({
  key: "approval-pending",
  tags: ["approval", "transactional"],
  render(props) {
    const slaRow = props.slaLabel ? [{ label: "Decide by", value: props.slaLabel }] : [];
    const html = layout({
      previewText: `${props.initiatorName} needs your approval on ${props.subjectTitle}.`,
      body: [
        heading(`Approval needed`),
        paragraph(`Hi ${props.approverName},`),
        paragraph(
          `${props.initiatorName} is waiting for your decision on ${props.subjectTitle}. This is the "${props.stepName}" step of ${props.workflowName}.`,
        ),
        definitionList([
          { label: "Workflow", value: props.workflowName },
          { label: "Step", value: props.stepName },
          { label: "Initiator", value: props.initiatorName },
          ...slaRow,
        ]),
        button({ href: props.approvalUrl, label: "Approve" }),
        props.rejectUrl
          ? `<a href="${props.rejectUrl}" style="display:inline-block;margin-left:8px;color:#dc2626;font-weight:600;">Reject instead</a>`
          : "",
      ].join("\n"),
    });
    const text = plainText({
      paragraphs: [
        `Hi ${props.approverName},`,
        `${props.initiatorName} is waiting on your decision for ${props.subjectTitle}.`,
        `Workflow: ${props.workflowName} → ${props.stepName}`,
        props.slaLabel ? `Decide by ${props.slaLabel}.` : "",
      ].filter(Boolean),
      cta: { label: "Approve or reject", href: props.approvalUrl },
    });
    return { subject: `Approval needed: ${props.subjectTitle}`, html, text };
  },
});
