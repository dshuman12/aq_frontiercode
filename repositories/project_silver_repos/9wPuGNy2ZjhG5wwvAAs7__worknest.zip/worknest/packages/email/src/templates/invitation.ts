import { button, definitionList, footnote, heading, layout, paragraph, plainText } from "../renderer";
import { registerTemplate } from "../registry";

export interface InvitationProps {
  inviterName: string;
  organizationName: string;
  role: string;
  acceptUrl: string;
  expiresOnLabel: string;
}

export const invitationTemplate = registerTemplate<InvitationProps>({
  key: "invitation",
  tags: ["invitation", "transactional"],
  render(props) {
    const html = layout({
      previewText: `${props.inviterName} added you as ${props.role}.`,
      body: [
        heading(`You've been invited!`),
        paragraph(
          `${props.inviterName} added you to ${props.organizationName} on WorkNest. Accept the invitation to start collaborating.`,
        ),
        definitionList([
          { label: "Organization", value: props.organizationName },
          { label: "Your role", value: props.role },
          { label: "Invitation expires", value: props.expiresOnLabel },
        ]),
        button({ href: props.acceptUrl, label: "Accept invitation" }),
        footnote(
          `Invitations are tied to your email address. If you accept from a different account it will be linked to this email.`,
        ),
      ].join("\n"),
    });
    const text = plainText({
      paragraphs: [
        `${props.inviterName} added you to ${props.organizationName} as ${props.role}.`,
        `Invitation expires on ${props.expiresOnLabel}.`,
      ],
      cta: { label: "Accept invitation", href: props.acceptUrl },
    });
    return {
      subject: `${props.inviterName} invited you to ${props.organizationName} on WorkNest`,
      html,
      text,
    };
  },
});
