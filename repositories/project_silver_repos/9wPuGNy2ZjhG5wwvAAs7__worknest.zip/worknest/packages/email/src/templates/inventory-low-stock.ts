import { button, escapeHtml, heading, layout, paragraph, plainText } from "../renderer";
import { registerTemplate } from "../registry";

export interface InventoryLowStockProps {
  recipientName: string;
  organizationName: string;
  inventoryUrl: string;
  items: { sku: string; name: string; onHand: number; reorderPoint: number; unit: string }[];
}

export const inventoryLowStockTemplate = registerTemplate<InventoryLowStockProps>({
  key: "inventory-low-stock",
  tags: ["inventory", "alert"],
  render(props) {
    const rows = props.items
      .map(
        (it) => `
<tr>
  <td style="padding:8px;border-bottom:1px solid #e2e8f0;font-family:ui-monospace,SFMono-Regular,monospace;">${escapeHtml(it.sku)}</td>
  <td style="padding:8px;border-bottom:1px solid #e2e8f0;">${escapeHtml(it.name)}</td>
  <td style="padding:8px;border-bottom:1px solid #e2e8f0;text-align:right;color:#dc2626;font-weight:600;">${it.onHand} ${escapeHtml(it.unit)}</td>
  <td style="padding:8px;border-bottom:1px solid #e2e8f0;text-align:right;color:#475569;">${it.reorderPoint} ${escapeHtml(it.unit)}</td>
</tr>`,
      )
      .join("");
    const table = `
<table cellspacing="0" cellpadding="0" style="width:100%;margin:16px 0;border:1px solid #e2e8f0;border-radius:8px;overflow:hidden;">
  <thead><tr style="background:#f8fafc;">
    <th style="padding:8px;text-align:left;font-size:12px;text-transform:uppercase;letter-spacing:0.04em;color:#475569;">SKU</th>
    <th style="padding:8px;text-align:left;font-size:12px;text-transform:uppercase;letter-spacing:0.04em;color:#475569;">Name</th>
    <th style="padding:8px;text-align:right;font-size:12px;text-transform:uppercase;letter-spacing:0.04em;color:#475569;">On hand</th>
    <th style="padding:8px;text-align:right;font-size:12px;text-transform:uppercase;letter-spacing:0.04em;color:#475569;">Reorder at</th>
  </tr></thead>
  <tbody>${rows}</tbody>
</table>`;

    const html = layout({
      previewText: `${props.items.length} item(s) below reorder point.`,
      body: [
        heading(`Low stock alert`),
        paragraph(`Hi ${props.recipientName},`),
        paragraph(`These items in ${props.organizationName} are at or below their reorder point.`),
        table,
        button({ href: props.inventoryUrl, label: "Open inventory" }),
      ].join("\n"),
    });
    const text = plainText({
      paragraphs: [
        `Low-stock alert for ${props.organizationName}:`,
        ...props.items.map((it) => `  - ${it.sku} ${it.name}: ${it.onHand} ${it.unit} (reorder at ${it.reorderPoint})`),
      ],
      cta: { label: "Open inventory", href: props.inventoryUrl },
    });
    return {
      subject: `${props.items.length} item${props.items.length === 1 ? "" : "s"} below reorder point`,
      html,
      text,
    };
  },
});
