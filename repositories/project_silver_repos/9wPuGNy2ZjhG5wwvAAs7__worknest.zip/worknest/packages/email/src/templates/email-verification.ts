import { button, footnote, heading, layout, paragraph, plainText } from "../renderer";
import { registerTemplate } from "../registry";

export interface EmailVerificationProps {
  name: string;
  verifyUrl: string;
  validForLabel?: string;
}

export const emailVerificationTemplate = registerTemplate<EmailVerificationProps>({
  key: "email-verification",
  tags: ["security", "transactional"],
  render(props) {
    const validFor = props.validForLabel ?? "the next 24 hours";
    const subject = `Verify your WorkNest email`;
    const html = layout({
      previewText: `Confirm your email so we can finish setting up your account.`,
      body: [
        heading(`Verify your email`),
        paragraph(
          `Hi ${props.name}, click the button below to confirm your email address. The link is valid for ${validFor}.`,
        ),
        button({ href: props.verifyUrl, label: "Verify email" }),
        footnote(`If you didn't sign up for WorkNest, ignore this email.`),
      ].join("\n"),
    });
    const text = plainText({
      paragraphs: [
        `Hi ${props.name}, please confirm your email address.`,
        `The link is valid for ${validFor}.`,
      ],
      cta: { label: "Verify email", href: props.verifyUrl },
    });
    return { subject, html, text };
  },
});
