import { button, footnote, heading, layout, paragraph, plainText } from "../renderer";
import { registerTemplate } from "../registry";

export interface PasswordResetProps {
  name: string;
  resetUrl: string;
  validForLabel?: string;
  requesterIp?: string;
}

export const passwordResetTemplate = registerTemplate<PasswordResetProps>({
  key: "password-reset",
  tags: ["security", "transactional"],
  render(props) {
    const validFor = props.validForLabel ?? "the next 30 minutes";
    const ipLine = props.requesterIp
      ? `<p style="margin:0 0 16px 0;font-size:13px;color:#475569;">Request originated from <code>${props.requesterIp}</code>.</p>`
      : "";
    const html = layout({
      previewText: `Reset link for your WorkNest account, valid for ${validFor}.`,
      body: [
        heading(`Reset your password`),
        paragraph(
          `Hi ${props.name}, someone (hopefully you) asked to reset your WorkNest password. The link below is valid for ${validFor}.`,
        ),
        button({ href: props.resetUrl, label: "Reset password", color: "#0f172a" }),
        ipLine,
        footnote(`If you didn't request a reset, ignore this email — your password won't change.`),
      ].join("\n"),
    });
    const text = plainText({
      paragraphs: [
        `Hi ${props.name},`,
        `Someone asked to reset your password. Link valid for ${validFor}.`,
        props.requesterIp ? `Request from ${props.requesterIp}.` : "",
      ].filter(Boolean),
      cta: { label: "Reset password", href: props.resetUrl },
    });
    return { subject: `Reset your WorkNest password`, html, text };
  },
});
