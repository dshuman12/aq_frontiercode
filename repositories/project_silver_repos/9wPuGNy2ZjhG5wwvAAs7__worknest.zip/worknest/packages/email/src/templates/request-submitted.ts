import { button, definitionList, heading, layout, paragraph, plainText } from "../renderer";
import { registerTemplate } from "../registry";

export interface RequestSubmittedProps {
  recipientName: string;
  requesterName: string;
  formName: string;
  requestKey: string;
  requestTitle: string;
  priority: string;
  requestUrl: string;
  summary?: string;
}

export const requestSubmittedTemplate = registerTemplate<RequestSubmittedProps>({
  key: "request-submitted",
  tags: ["request"],
  render(props) {
    const summary = props.summary ? paragraph(props.summary) : "";
    const html = layout({
      previewText: `${props.requesterName} submitted ${props.formName} ${props.requestKey}.`,
      body: [
        heading(`New ${props.formName} request`),
        paragraph(`Hi ${props.recipientName}, ${props.requesterName} just submitted a new request to triage.`),
        definitionList([
          { label: "Reference", value: props.requestKey },
          { label: "Form", value: props.formName },
          { label: "Priority", value: props.priority },
          { label: "Submitted by", value: props.requesterName },
        ]),
        summary,
        button({ href: props.requestUrl, label: "Open request" }),
      ].join("\n"),
    });
    const text = plainText({
      paragraphs: [
        `${props.requesterName} just submitted ${props.requestKey} on the ${props.formName} form.`,
        props.summary ?? "",
      ].filter(Boolean),
      cta: { label: "Open request", href: props.requestUrl },
    });
    return {
      subject: `New request: ${props.requestKey} ${props.requestTitle}`,
      html,
      text,
    };
  },
});
