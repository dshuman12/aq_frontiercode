import { button, definitionList, heading, layout, paragraph, plainText } from "../renderer";
import { registerTemplate } from "../registry";

export interface InvoicePaidProps {
  recipientName: string;
  organizationName: string;
  invoiceNumber: string;
  amountLabel: string;
  paidOnLabel: string;
  invoiceUrl: string;
  receiptUrl: string;
}

export const invoicePaidTemplate = registerTemplate<InvoicePaidProps>({
  key: "invoice-paid",
  tags: ["billing", "transactional"],
  render(props) {
    const html = layout({
      previewText: `Payment received for invoice ${props.invoiceNumber}.`,
      body: [
        heading(`Payment received`),
        paragraph(`Hi ${props.recipientName},`),
        paragraph(
          `Thanks — we just received payment of ${props.amountLabel} for invoice ${props.invoiceNumber} (${props.organizationName}).`,
        ),
        definitionList([
          { label: "Invoice", value: props.invoiceNumber },
          { label: "Amount", value: props.amountLabel },
          { label: "Paid on", value: props.paidOnLabel },
        ]),
        button({ href: props.receiptUrl, label: "View receipt" }),
        `<p style="margin:8px 0 0 0;font-size:13px;color:#475569;">Need an itemised invoice? <a href="${props.invoiceUrl}" style="color:#4f46e5;">Download the PDF</a>.</p>`,
      ].join("\n"),
    });
    const text = plainText({
      paragraphs: [
        `Hi ${props.recipientName},`,
        `Payment received for ${props.invoiceNumber}: ${props.amountLabel} on ${props.paidOnLabel}.`,
        `Receipt: ${props.receiptUrl}`,
      ],
    });
    return {
      subject: `Receipt: ${props.invoiceNumber} for ${props.amountLabel}`,
      html,
      text,
    };
  },
});
