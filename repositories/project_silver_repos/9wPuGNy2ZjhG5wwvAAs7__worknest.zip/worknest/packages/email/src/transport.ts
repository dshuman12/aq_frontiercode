import { createTransport, Transporter } from "nodemailer";
import { EmailDeliveryResult, EmailMessage, EmailTransport } from "./types";

export interface SmtpTransportConfig {
  host: string;
  port: number;
  secure?: boolean;
  user?: string;
  password?: string;
  fromEmail: string;
  fromName?: string;
}

export class SmtpTransport implements EmailTransport {
  readonly name = "smtp";
  private readonly transporter: Transporter;

  constructor(private readonly cfg: SmtpTransportConfig) {
    this.transporter = createTransport({
      host: cfg.host,
      port: cfg.port,
      secure: cfg.secure ?? cfg.port === 465,
      auth: cfg.user && cfg.password ? { user: cfg.user, pass: cfg.password } : undefined,
    });
  }

  async verify(): Promise<void> {
    await this.transporter.verify();
  }

  async send(message: EmailMessage): Promise<EmailDeliveryResult> {
    const from = message.from ?? { email: this.cfg.fromEmail, name: this.cfg.fromName };
    const headers: Record<string, string> = {};
    if (message.tags?.length) headers["X-Mailer-Tag"] = message.tags.join(",");
    const info = await this.transporter.sendMail({
      from: format(from),
      to: toArray(message.to).map(format).join(", "),
      cc: message.cc?.map(format).join(", "),
      bcc: message.bcc?.map(format).join(", "),
      replyTo: message.replyTo ? format(message.replyTo) : undefined,
      subject: message.subject,
      html: message.html,
      text: message.text,
      headers,
    });
    return { messageId: info.messageId, acceptedAt: new Date().toISOString() };
  }
}

/** No-op transport that records what was sent. Used in tests + dev. */
export class LogTransport implements EmailTransport {
  readonly name = "log";
  public sent: EmailMessage[] = [];
  private counter = 0;

  async send(message: EmailMessage): Promise<EmailDeliveryResult> {
    this.sent.push(message);
    return {
      messageId: `<log-${Date.now()}-${++this.counter}@worknest.local>`,
      acceptedAt: new Date().toISOString(),
    };
  }
}

function toArray<T>(value: T | T[]): T[] {
  return Array.isArray(value) ? value : [value];
}

function format(addr: { email: string; name?: string }): string {
  return addr.name ? `"${addr.name.replace(/"/g, "")}" <${addr.email}>` : addr.email;
}
