export interface EmailAddress {
  name?: string;
  email: string;
}

export interface RenderedEmail {
  subject: string;
  html: string;
  text: string;
}

export interface EmailMessage extends RenderedEmail {
  to: EmailAddress | EmailAddress[];
  cc?: EmailAddress[];
  bcc?: EmailAddress[];
  replyTo?: EmailAddress;
  from?: EmailAddress;
  tags?: string[];
}

export interface EmailDeliveryResult {
  messageId: string;
  acceptedAt: string;
}

export interface EmailTransport {
  name: string;
  send(message: EmailMessage): Promise<EmailDeliveryResult>;
  verify?(): Promise<void>;
}

export interface TemplateMeta<P> {
  key: string;
  from?: EmailAddress;
  tags?: string[];
  render(props: P): RenderedEmail;
}
