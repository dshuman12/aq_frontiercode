/**
 * Inline HTML helpers for the email templates. We deliberately avoid
 * MJML / React Email — the templates are short enough that owning the
 * primitives is cheaper than the dependency.
 *
 * Output is always HTML-escaped at the boundary; templates pass user
 * data through `escapeHtml` rather than templating it directly.
 */

const PRIMARY = "#4f46e5";
const TEXT = "#0f172a";
const MUTED = "#475569";
const BORDER = "#e2e8f0";
const BG = "#f8fafc";

export function escapeHtml(input: string): string {
  return input
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

export function layout(opts: { previewText?: string; body: string }): string {
  const preview = opts.previewText
    ? `<div style="display:none;max-height:0;overflow:hidden;font-size:1px;line-height:1px;color:${BG};">${escapeHtml(opts.previewText)}</div>`
    : "";
  return `<!doctype html>
<html><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/></head>
<body style="margin:0;padding:0;background:${BG};font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif;color:${TEXT};">
  ${preview}
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:${BG};padding:32px 0;">
    <tr><td align="center">
      <table role="presentation" width="560" cellpadding="0" cellspacing="0" style="background:#ffffff;border:1px solid ${BORDER};border-radius:12px;overflow:hidden;">
        <tr><td style="padding:24px 32px;border-bottom:1px solid ${BORDER};">
          <span style="font-size:18px;font-weight:600;color:${PRIMARY};">WorkNest</span>
        </td></tr>
        <tr><td style="padding:32px;font-size:15px;line-height:1.55;">${opts.body}</td></tr>
        <tr><td style="padding:20px 32px;border-top:1px solid ${BORDER};font-size:12px;color:${MUTED};">
          You're receiving this because you have an active WorkNest account. Manage your preferences under Settings &raquo; Notifications.
        </td></tr>
      </table>
    </td></tr>
  </table>
</body></html>`;
}

export function heading(text: string): string {
  return `<h1 style="margin:0 0 12px 0;font-size:22px;color:${TEXT};">${escapeHtml(text)}</h1>`;
}

export function paragraph(text: string): string {
  return `<p style="margin:0 0 16px 0;color:${TEXT};">${escapeHtml(text)}</p>`;
}

export function button(props: { href: string; label: string; color?: string }): string {
  const color = props.color ?? PRIMARY;
  return `<table role="presentation" cellspacing="0" cellpadding="0" style="margin:24px 0;"><tr><td>
    <a href="${escapeHtml(props.href)}" style="background:${color};color:#ffffff;text-decoration:none;font-weight:600;padding:12px 22px;border-radius:8px;display:inline-block;">${escapeHtml(props.label)}</a>
  </td></tr></table>`;
}

export function definitionList(rows: { label: string; value: string }[]): string {
  const items = rows
    .map(
      (r) =>
        `<tr><td style="padding:6px 0;color:${MUTED};width:140px;vertical-align:top;">${escapeHtml(r.label)}</td><td style="padding:6px 0;color:${TEXT};">${escapeHtml(r.value)}</td></tr>`,
    )
    .join("");
  return `<table cellspacing="0" cellpadding="0" style="border-top:1px solid ${BORDER};margin:16px 0;width:100%;">${items}</table>`;
}

export function divider(): string {
  return `<div style="height:1px;background:${BORDER};margin:24px 0;"></div>`;
}

export function footnote(text: string): string {
  return `<p style="margin:24px 0 0 0;font-size:13px;color:${MUTED};">${escapeHtml(text)}</p>`;
}

export function plainText(opts: {
  paragraphs: string[];
  cta?: { label: string; href: string };
  signature?: string;
}): string {
  const out: string[] = [];
  for (const p of opts.paragraphs) out.push(p, "");
  if (opts.cta) out.push(`${opts.cta.label}: ${opts.cta.href}`, "");
  out.push(opts.signature ?? "— The WorkNest team");
  return out.join("\n");
}
