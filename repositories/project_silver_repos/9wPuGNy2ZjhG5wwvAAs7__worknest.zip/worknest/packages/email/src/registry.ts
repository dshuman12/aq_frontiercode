import { RenderedEmail, TemplateMeta } from "./types";

const registry = new Map<string, TemplateMeta<unknown>>();

export function registerTemplate<P>(meta: TemplateMeta<P>): TemplateMeta<P> {
  if (registry.has(meta.key) && typeof console !== "undefined") {
    console.warn(`[worknest/email] template "${meta.key}" registered twice; later wins`);
  }
  registry.set(meta.key, meta as TemplateMeta<unknown>);
  return meta;
}

export function lookupTemplate(key: string): TemplateMeta<unknown> | undefined {
  return registry.get(key);
}

export function allTemplates(): TemplateMeta<unknown>[] {
  return Array.from(registry.values());
}

export function renderTemplate<P>(meta: TemplateMeta<P>, props: P): RenderedEmail {
  return meta.render(props);
}

export function renderByKey(key: string, props: unknown): RenderedEmail {
  const meta = registry.get(key);
  if (!meta) throw new Error(`Unknown email template: ${key}`);
  return meta.render(props);
}
