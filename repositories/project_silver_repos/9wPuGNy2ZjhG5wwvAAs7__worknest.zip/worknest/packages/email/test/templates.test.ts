import { describe, expect, it } from "vitest";
import {
  approvalPendingTemplate,
  assetWarrantyTemplate,
  emailVerificationTemplate,
  invitationTemplate,
  inventoryLowStockTemplate,
  invoicePaidTemplate,
  passwordResetTemplate,
  renderByKey,
  requestSubmittedTemplate,
  taskAssignedTemplate,
  ticketAssignedTemplate,
  weeklyDigestTemplate,
  welcomeTemplate,
} from "../src";

describe("email templates", () => {
  it("welcome contains name + cta url", () => {
    const r = welcomeTemplate.render({ name: "Alex", organizationName: "Acme", ctaUrl: "https://app/x" });
    expect(r.subject).toContain("Alex");
    expect(r.html).toContain("Acme");
    expect(r.html).toContain("https://app/x");
  });

  it("password-reset includes validity window", () => {
    const r = passwordResetTemplate.render({ name: "A", resetUrl: "https://x", validForLabel: "30 minutes" });
    expect(r.html).toContain("30 minutes");
  });

  it("invitation lists role + expiry", () => {
    const r = invitationTemplate.render({
      inviterName: "P", organizationName: "Acme", role: "admin",
      acceptUrl: "https://x", expiresOnLabel: "Mar 14",
    });
    expect(r.html).toContain("admin");
    expect(r.html).toContain("Mar 14");
  });

  it("task-assigned uses task key in subject", () => {
    const r = taskAssignedTemplate.render({
      assigneeName: "S", assignerName: "A", projectName: "P", taskKey: "P-1",
      taskTitle: "X", taskUrl: "https://x", priority: "high",
    });
    expect(r.subject).toContain("[P-1]");
  });

  it("inventory-low-stock has one row per item", () => {
    const r = inventoryLowStockTemplate.render({
      recipientName: "A", organizationName: "Acme", inventoryUrl: "https://x",
      items: [
        { sku: "A", name: "A", onHand: 1, reorderPoint: 5, unit: "pc" },
        { sku: "B", name: "B", onHand: 0, reorderPoint: 2, unit: "pc" },
      ],
    });
    expect(r.html).toContain("A");
    expect(r.html).toContain("B");
  });

  it("renderByKey throws for unknown templates", () => {
    expect(() => renderByKey("nope", {})).toThrow();
  });

  it("renderByKey resolves welcome", () => {
    const r = renderByKey("welcome", { name: "Alex", organizationName: "Acme", ctaUrl: "https://x" });
    expect(r.subject).toContain("Alex");
  });

  it("ticket-assigned mentions ticket key", () => {
    const r = ticketAssignedTemplate.render({
      assigneeName: "S", requesterName: "R", ticketKey: "TKT-1",
      ticketTitle: "X", ticketUrl: "https://x", priority: "high",
    });
    expect(r.subject).toContain("TKT-1");
  });

  it("approval-pending shows initiator + step", () => {
    const r = approvalPendingTemplate.render({
      approverName: "J", workflowName: "PO", stepName: "Manager",
      subjectTitle: "Order", initiatorName: "S", approvalUrl: "https://x",
    });
    expect(r.html).toContain("PO");
    expect(r.html).toContain("Manager");
  });

  it("asset-warranty includes days remaining", () => {
    const r = assetWarrantyTemplate.render({
      recipientName: "A", assetName: "Dell", warrantyEndsLabel: "Aug 10",
      daysRemaining: 14, assetUrl: "https://x",
    });
    expect(r.html).toContain("14");
  });

  it("invoice-paid uses receipt url", () => {
    const r = invoicePaidTemplate.render({
      recipientName: "A", organizationName: "Acme", invoiceNumber: "INV-1",
      amountLabel: "$120", paidOnLabel: "Mar 4", invoiceUrl: "https://i", receiptUrl: "https://r",
    });
    expect(r.html).toContain("https://r");
  });

  it("weekly-digest renders metrics", () => {
    const r = weeklyDigestTemplate.render({
      recipientName: "A", organizationName: "Acme", weekOfLabel: "Mar 4",
      dashboardUrl: "https://x",
      metrics: { completedTasks: 12, openTasks: 5, overdueTasks: 1, ticketsResolved: 3, averageResolutionHours: 4.7 },
      topContributors: [{ name: "P", completed: 6 }],
    });
    expect(r.html).toContain("12");
  });

  it("email-verification includes validity label", () => {
    const r = emailVerificationTemplate.render({ name: "A", verifyUrl: "https://x", validForLabel: "the next 24 hours" });
    expect(r.html).toContain("the next 24 hours");
  });

  it("request-submitted lists requester + form", () => {
    const r = requestSubmittedTemplate.render({
      recipientName: "S", requesterName: "A", formName: "Equipment",
      requestKey: "RQ-1", requestTitle: "x", priority: "medium", requestUrl: "https://x",
    });
    expect(r.html).toContain("RQ-1");
    expect(r.html).toContain("Equipment");
  });
});
