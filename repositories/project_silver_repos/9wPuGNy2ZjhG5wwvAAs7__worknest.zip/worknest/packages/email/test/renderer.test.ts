import { describe, expect, it } from "vitest";
import { button, escapeHtml, heading, layout, paragraph, plainText } from "../src/renderer";

describe("renderer", () => {
  it("escapes HTML special chars", () => {
    expect(escapeHtml("<script>")).toBe("&lt;script&gt;");
    expect(escapeHtml('"&\'')).toBe("&quot;&amp;&#39;");
  });

  it("layout includes preview text", () => {
    const html = layout({ body: "<p>hi</p>", previewText: "preview" });
    expect(html).toContain("preview");
  });

  it("button renders an anchor", () => {
    expect(button({ href: "https://x", label: "Open" })).toContain('href="https://x"');
  });

  it("plainText joins paragraphs and CTA", () => {
    const text = plainText({
      paragraphs: ["line one", "line two"],
      cta: { label: "Open", href: "https://x" },
    });
    expect(text).toContain("line one");
    expect(text).toContain("Open: https://x");
  });

  it("heading and paragraph render expected tags", () => {
    expect(heading("Hi")).toMatch(/<h1[^>]*>Hi<\/h1>/);
    expect(paragraph("Body")).toMatch(/<p[^>]*>Body<\/p>/);
  });
});
