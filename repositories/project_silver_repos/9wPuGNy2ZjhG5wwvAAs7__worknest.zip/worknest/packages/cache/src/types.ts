/**
 * Common cache contract. Every backend implements `get`, `set`,
 * and `del`. TTLs are seconds; null means "until evicted by capacity".
 */

export interface CacheStore {
  get<T>(key: string): Promise<T | null>;
  set<T>(key: string, value: T, ttlSeconds?: number | null): Promise<void>;
  del(key: string | string[]): Promise<void>;
  clear?(): Promise<void>;
}

export interface CacheEntry<T> {
  value: T;
  expiresAt: number | null;
}
