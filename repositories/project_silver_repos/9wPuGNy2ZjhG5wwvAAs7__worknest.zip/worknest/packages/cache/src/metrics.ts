/**
 * Tiny in-process counter pair for hit/miss accounting. Read via
 * `snapshot()` from a metrics endpoint or a periodic logger. We
 * deliberately don't ship a Prometheus client here — that's a
 * deployment-shaped concern.
 */

export class CacheMetrics {
  private hits = 0;
  private misses = 0;
  private writes = 0;
  private invalidations = 0;

  recordHit(): void {
    this.hits += 1;
  }
  recordMiss(): void {
    this.misses += 1;
  }
  recordWrite(): void {
    this.writes += 1;
  }
  recordInvalidation(): void {
    this.invalidations += 1;
  }

  snapshot(): {
    hits: number;
    misses: number;
    writes: number;
    invalidations: number;
    hitRatio: number;
  } {
    const total = this.hits + this.misses;
    return {
      hits: this.hits,
      misses: this.misses,
      writes: this.writes,
      invalidations: this.invalidations,
      hitRatio: total === 0 ? 0 : this.hits / total,
    };
  }

  reset(): void {
    this.hits = 0;
    this.misses = 0;
    this.writes = 0;
    this.invalidations = 0;
  }
}

export const cacheMetrics = new CacheMetrics();
