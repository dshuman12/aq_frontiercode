/**
 * LRU semantics — touching keys re-orders them so the next eviction
 * picks the genuinely-coldest entry. TTL expiry is wall-clock based,
 * so we use a tiny sleep instead of mocking time.
 */
import { describe, expect, it } from "vitest";
import { InMemoryLruCache } from "./lru";

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

describe("InMemoryLruCache", () => {
  it("returns set values until evicted", async () => {
    const c = new InMemoryLruCache({ max: 2 });
    await c.set("a", 1);
    await c.set("b", 2);
    expect(await c.get("a")).toBe(1);
    expect(await c.get("b")).toBe(2);
  });

  it("evicts the least-recently-used", async () => {
    const c = new InMemoryLruCache({ max: 2 });
    await c.set("a", 1);
    await c.set("b", 2);
    await c.get("a"); // touch a
    await c.set("c", 3); // should evict b
    expect(await c.get("b")).toBeNull();
    expect(await c.get("a")).toBe(1);
    expect(await c.get("c")).toBe(3);
  });

  it("respects ttl", async () => {
    const c = new InMemoryLruCache({ max: 4 });
    await c.set("k", "v", 0.05); // 50ms
    expect(await c.get("k")).toBe("v");
    await sleep(70);
    expect(await c.get("k")).toBeNull();
  });

  it("del removes entries", async () => {
    const c = new InMemoryLruCache({ max: 4 });
    await c.set("a", 1);
    await c.del("a");
    expect(await c.get("a")).toBeNull();
  });
});
