/**
 * Redis-backed CacheStore. We re-use the existing Redis instance
 * via a connection-string env var; values are JSON-serialized.
 */
import IORedis from "ioredis";
import type { CacheStore } from "./types";

export interface RedisCacheOptions {
  url?: string;
  prefix?: string;
}

export class RedisCacheStore implements CacheStore {
  private readonly client: IORedis;
  private readonly prefix: string;

  constructor(opts: RedisCacheOptions = {}) {
    this.client = new IORedis(opts.url ?? process.env.REDIS_URL ?? "redis://localhost:6379", {
      lazyConnect: false,
      maxRetriesPerRequest: 2,
    });
    this.prefix = opts.prefix ?? "worknest:cache:";
  }

  private k(key: string): string {
    return `${this.prefix}${key}`;
  }

  async get<T>(key: string): Promise<T | null> {
    const raw = await this.client.get(this.k(key));
    if (raw == null) return null;
    try {
      return JSON.parse(raw) as T;
    } catch {
      return null;
    }
  }

  async set<T>(key: string, value: T, ttlSeconds: number | null = null): Promise<void> {
    const raw = JSON.stringify(value);
    if (ttlSeconds != null) {
      await this.client.set(this.k(key), raw, "EX", ttlSeconds);
    } else {
      await this.client.set(this.k(key), raw);
    }
  }

  async del(key: string | string[]): Promise<void> {
    const keys = Array.isArray(key) ? key : [key];
    if (keys.length === 0) return;
    await this.client.del(...keys.map((k) => this.k(k)));
  }

  async clear(): Promise<void> {
    const stream = this.client.scanStream({ match: `${this.prefix}*`, count: 100 });
    return new Promise((resolve, reject) => {
      const keys: string[] = [];
      stream.on("data", (chunk: string[]) => keys.push(...chunk));
      stream.on("error", reject);
      stream.on("end", async () => {
        if (keys.length) await this.client.del(...keys);
        resolve();
      });
    });
  }

  async close(): Promise<void> {
    await this.client.quit();
  }
}
