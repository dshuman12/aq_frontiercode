/**
 * Stale-while-revalidate helper. Wraps a `loader` so the next caller
 * after a miss serves the previous value (if any) and refreshes in
 * the background. Designed for hot read paths where staleness is
 * cheaper than a cache miss latency cliff.
 *
 * We track in-flight refreshes per key so concurrent callers
 * coalesce to one loader invocation.
 */
import type { CacheStore } from "./types";

interface SwrOptions {
  freshSeconds: number;
  staleSeconds: number;
}

interface StoredEntry<T> {
  value: T;
  storedAt: number;
}

export class StaleWhileRevalidate {
  private readonly inflight = new Map<string, Promise<unknown>>();

  constructor(
    private readonly store: CacheStore,
    private readonly opts: SwrOptions,
  ) {}

  async get<T>(key: string, loader: () => Promise<T>): Promise<T> {
    const existing = await this.store.get<StoredEntry<T>>(key);
    const now = Date.now();
    if (existing) {
      const ageSec = (now - existing.storedAt) / 1000;
      if (ageSec < this.opts.freshSeconds) return existing.value;
      if (ageSec < this.opts.freshSeconds + this.opts.staleSeconds) {
        // serve stale, refresh in background.
        void this.refresh(key, loader);
        return existing.value;
      }
    }
    return this.refresh(key, loader);
  }

  private async refresh<T>(key: string, loader: () => Promise<T>): Promise<T> {
    const inflight = this.inflight.get(key);
    if (inflight) return inflight as Promise<T>;
    const promise = (async () => {
      const value = await loader();
      const ttl = this.opts.freshSeconds + this.opts.staleSeconds;
      await this.store.set(key, { value, storedAt: Date.now() } as StoredEntry<T>, ttl);
      this.inflight.delete(key);
      return value;
    })();
    this.inflight.set(key, promise);
    return promise;
  }

  async invalidate(key: string | string[]): Promise<void> {
    await this.store.del(key);
  }
}
