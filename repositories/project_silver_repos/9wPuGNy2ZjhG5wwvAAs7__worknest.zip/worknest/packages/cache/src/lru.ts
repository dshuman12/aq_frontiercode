/**
 * Tiny in-process LRU. Backed by Map insertion order — touching a
 * key re-inserts it to move it to the most-recent position. We keep
 * this in-package so feature code doesn't take a dependency on
 * `lru-cache` for a 40-line implementation.
 */

import type { CacheEntry, CacheStore } from "./types";

interface InMemoryOptions {
  max: number;
}

export class InMemoryLruCache implements CacheStore {
  private readonly entries = new Map<string, CacheEntry<unknown>>();

  constructor(private readonly opts: InMemoryOptions) {}

  async get<T>(key: string): Promise<T | null> {
    const entry = this.entries.get(key);
    if (!entry) return null;
    if (entry.expiresAt && entry.expiresAt < Date.now()) {
      this.entries.delete(key);
      return null;
    }
    // touch — re-insertion moves to the back of the iteration order
    this.entries.delete(key);
    this.entries.set(key, entry);
    return entry.value as T;
  }

  async set<T>(key: string, value: T, ttlSeconds: number | null = null): Promise<void> {
    if (this.entries.has(key)) this.entries.delete(key);
    if (this.entries.size >= this.opts.max) {
      // evict the oldest insertion
      const oldest = this.entries.keys().next().value;
      if (oldest !== undefined) this.entries.delete(oldest);
    }
    this.entries.set(key, {
      value,
      expiresAt: ttlSeconds ? Date.now() + ttlSeconds * 1000 : null,
    });
  }

  async del(key: string | string[]): Promise<void> {
    const keys = Array.isArray(key) ? key : [key];
    for (const k of keys) this.entries.delete(k);
  }

  async clear(): Promise<void> {
    this.entries.clear();
  }

  get size(): number {
    return this.entries.size;
  }
}
