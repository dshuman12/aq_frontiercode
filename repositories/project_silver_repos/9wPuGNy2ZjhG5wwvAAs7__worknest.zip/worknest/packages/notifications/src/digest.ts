import { NotificationEnvelope, NotificationKind } from "./types";

export interface DigestEntry<P = Record<string, unknown>> {
  envelope: NotificationEnvelope<P>;
  count: number;
  first: string;
  last: string;
}

export class DigestBuilder<P = Record<string, unknown>> {
  private readonly entries = new Map<string, DigestEntry<P>>();

  add(envelope: NotificationEnvelope<P>): void {
    const key = envelope.digestKey ?? envelope.id;
    const existing = this.entries.get(key);
    if (!existing) {
      this.entries.set(key, {
        envelope,
        count: 1,
        first: envelope.occurredAt,
        last: envelope.occurredAt,
      });
      return;
    }
    existing.count += 1;
    if (envelope.occurredAt < existing.first) existing.first = envelope.occurredAt;
    if (envelope.occurredAt > existing.last) existing.last = envelope.occurredAt;
  }

  get size(): number {
    return this.entries.size;
  }

  values(): DigestEntry<P>[] {
    return Array.from(this.entries.values());
  }

  byKind(): Record<NotificationKind, DigestEntry<P>[]> {
    const out: Partial<Record<NotificationKind, DigestEntry<P>[]>> = {};
    for (const entry of this.entries.values()) {
      const k = entry.envelope.kind;
      (out[k] ||= []).push(entry);
    }
    return out as Record<NotificationKind, DigestEntry<P>[]>;
  }

  top(n: number): DigestEntry<P>[] {
    return this.values()
      .sort((a, b) => b.count - a.count)
      .slice(0, n);
  }

  reset(): void {
    this.entries.clear();
  }
}
