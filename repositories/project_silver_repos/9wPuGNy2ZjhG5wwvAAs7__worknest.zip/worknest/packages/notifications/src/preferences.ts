import { ChannelKey, ChannelPreference, NotificationKind } from "./types";

export const DEFAULT_PREFERENCES: Record<NotificationKind, ChannelPreference> = {
  "task.assigned":         { in_app: true,  email: true,  push: true  },
  "task.commented":        { in_app: true,  email: false, push: false },
  "task.due_soon":         { in_app: true,  email: true,  push: true  },
  "task.overdue":          { in_app: true,  email: true,  push: true  },
  "task.completed":        { in_app: true,  email: false, push: false },
  "ticket.assigned":       { in_app: true,  email: true,  push: true  },
  "ticket.commented":      { in_app: true,  email: false, push: false },
  "ticket.escalated":      { in_app: true,  email: true,  push: true  },
  "request.submitted":     { in_app: true,  email: true,  push: false },
  "request.approved":      { in_app: true,  email: true,  push: false },
  "request.rejected":      { in_app: true,  email: true,  push: false },
  "approval.pending":      { in_app: true,  email: true,  push: true  },
  "approval.decided":      { in_app: true,  email: false, push: false },
  "asset.warranty":        { in_app: true,  email: true,  push: false },
  "inventory.low_stock":   { in_app: true,  email: true,  push: false },
  "billing.invoice_paid":  { in_app: true,  email: true,  push: false },
  "billing.payment_failed":{ in_app: true,  email: true,  push: true  },
  "digest.daily":          { in_app: false, email: true,  push: false },
  "digest.weekly":         { in_app: false, email: true,  push: false },
};

export interface PreferenceRow {
  userId: string;
  kind: NotificationKind;
  channel: ChannelKey;
  enabled: boolean;
}

export function rowsToMap(rows: PreferenceRow[]): Record<NotificationKind, ChannelPreference> {
  const out: Record<NotificationKind, ChannelPreference> = JSON.parse(
    JSON.stringify(DEFAULT_PREFERENCES),
  );
  for (const r of rows) {
    if (!out[r.kind]) continue;
    (out[r.kind] as Record<string, boolean>)[r.channel] = r.enabled;
  }
  return out;
}

export function isChannelEnabled(
  prefs: Record<NotificationKind, ChannelPreference>,
  kind: NotificationKind,
  channel: ChannelKey,
): boolean {
  const p = prefs[kind];
  if (!p) return false;
  return Boolean((p as Record<string, boolean | undefined>)[channel]);
}

/**
 * Per-user quiet-hours window. Notifications below `severity: "critical"`
 * are suppressed during quiet hours; critical events bypass it.
 */
export interface QuietHours {
  /** 0–23, inclusive. */
  start: number;
  /** 0–23, exclusive. */
  end: number;
  /** IANA timezone — caller is responsible for converting `now` correctly. */
  tz: string;
}

export function isQuietHour(localHour: number, hours: QuietHours): boolean {
  if (hours.start === hours.end) return false;
  if (hours.start < hours.end) return localHour >= hours.start && localHour < hours.end;
  return localHour >= hours.start || localHour < hours.end;
}
