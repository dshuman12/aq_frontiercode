/**
 * Public types for the notification dispatcher. Channels receive a fully
 * resolved envelope and never look at preferences themselves — that's
 * the dispatcher's job. This separation is what lets us unit-test
 * channels in isolation and lets us swap channels in/out at runtime
 * (e.g. disable Slack for an org but keep email).
 */

export type NotificationKind =
  | "task.assigned"
  | "task.commented"
  | "task.due_soon"
  | "task.overdue"
  | "task.completed"
  | "ticket.assigned"
  | "ticket.commented"
  | "ticket.escalated"
  | "request.submitted"
  | "request.approved"
  | "request.rejected"
  | "approval.pending"
  | "approval.decided"
  | "asset.warranty"
  | "inventory.low_stock"
  | "billing.invoice_paid"
  | "billing.payment_failed"
  | "digest.daily"
  | "digest.weekly";

export type ChannelKey = "in_app" | "email" | "webhook" | "push";

export interface ChannelPreference {
  in_app?: boolean;
  email?: boolean;
  webhook?: boolean;
  push?: boolean;
}

export interface Recipient {
  userId: string;
  organizationId: string;
  email?: string;
  name?: string;
  preferences: Record<NotificationKind, ChannelPreference>;
  pushTokens?: string[];
}

export interface NotificationEnvelope<P = Record<string, unknown>> {
  id: string;
  kind: NotificationKind;
  organizationId: string;
  recipientId: string;
  title: string;
  body?: string;
  link?: string;
  emailTemplate?: string;
  emailProps?: P;
  occurredAt: string;
  digestKey?: string;
  severity?: "info" | "warning" | "critical";
}

export interface ChannelDeliveryResult {
  envelopeId: string;
  channel: ChannelKey;
  status: "delivered" | "skipped" | "failed";
  reason?: string;
  externalId?: string;
}

export interface NotificationChannel {
  readonly key: ChannelKey;
  send(envelope: NotificationEnvelope, recipient: Recipient): Promise<ChannelDeliveryResult>;
}
