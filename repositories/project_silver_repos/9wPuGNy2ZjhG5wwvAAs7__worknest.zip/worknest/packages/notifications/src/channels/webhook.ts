/**
 * Webhook channel — POSTs a JSON envelope to a per-organization endpoint
 * with an HMAC signature. The HMAC secret rotation is handled out-of-band
 * in the /webhooks endpoints; this channel just signs with whatever
 * secret the resolver hands it.
 */

import { createHmac } from "node:crypto";
import { ChannelDeliveryResult, NotificationChannel, NotificationEnvelope, Recipient } from "../types";

export interface WebhookEndpoint {
  id: string;
  url: string;
  secret: string;
  kinds: string[];
}

export interface WebhookEndpointResolver {
  forOrganization(organizationId: string): Promise<WebhookEndpoint[]>;
}

export type WebhookFetcher = (
  url: string,
  init: { method: "POST"; body: string; headers: Record<string, string> },
) => Promise<{ status: number; ok: boolean }>;

export class WebhookChannel implements NotificationChannel {
  readonly key = "webhook" as const;

  constructor(
    private readonly resolver: WebhookEndpointResolver,
    private readonly fetcher: WebhookFetcher,
  ) {}

  async send(envelope: NotificationEnvelope, _recipient: Recipient): Promise<ChannelDeliveryResult> {
    const endpoints = await this.resolver.forOrganization(envelope.organizationId);
    const matching = endpoints.filter((e) => e.kinds.includes(envelope.kind));
    if (matching.length === 0) {
      return { envelopeId: envelope.id, channel: "webhook", status: "skipped", reason: "no-endpoints" };
    }

    const body = JSON.stringify({
      id: envelope.id,
      kind: envelope.kind,
      organizationId: envelope.organizationId,
      title: envelope.title,
      body: envelope.body,
      link: envelope.link,
      severity: envelope.severity,
      occurredAt: envelope.occurredAt,
    });

    let lastStatus = 0;
    for (const endpoint of matching) {
      const signature = createHmac("sha256", endpoint.secret).update(body).digest("hex");
      const res = await this.fetcher(endpoint.url, {
        method: "POST",
        body,
        headers: {
          "content-type": "application/json",
          "x-worknest-signature": signature,
          "x-worknest-event": envelope.kind,
          "x-worknest-id": envelope.id,
        },
      });
      lastStatus = res.status;
      if (!res.ok) {
        return {
          envelopeId: envelope.id,
          channel: "webhook",
          status: "failed",
          reason: `HTTP ${res.status}`,
          externalId: endpoint.id,
        };
      }
    }
    return {
      envelopeId: envelope.id,
      channel: "webhook",
      status: "delivered",
      externalId: `${matching.length} endpoints (${lastStatus})`,
    };
  }
}
