import { ChannelDeliveryResult, NotificationChannel, NotificationEnvelope, Recipient } from "../types";

export interface InAppPersist {
  insert(input: {
    id: string;
    organizationId: string;
    userId: string;
    kind: string;
    title: string;
    body?: string;
    link?: string;
    occurredAt: string;
    severity?: string;
  }): Promise<{ id: string }>;
}

export interface InAppRealtime {
  emit(userId: string, event: { type: "notification"; payload: unknown }): void;
}

export class InAppChannel implements NotificationChannel {
  readonly key = "in_app" as const;

  constructor(private readonly persist: InAppPersist, private readonly realtime?: InAppRealtime) {}

  async send(envelope: NotificationEnvelope, recipient: Recipient): Promise<ChannelDeliveryResult> {
    const stored = await this.persist.insert({
      id: envelope.id,
      organizationId: envelope.organizationId,
      userId: recipient.userId,
      kind: envelope.kind,
      title: envelope.title,
      body: envelope.body,
      link: envelope.link,
      occurredAt: envelope.occurredAt,
      severity: envelope.severity,
    });
    this.realtime?.emit(recipient.userId, {
      type: "notification",
      payload: {
        id: stored.id,
        kind: envelope.kind,
        title: envelope.title,
        body: envelope.body,
        link: envelope.link,
        severity: envelope.severity,
      },
    });
    return { envelopeId: envelope.id, channel: "in_app", status: "delivered", externalId: stored.id };
  }
}
