import { EmailMessage, EmailTransport, renderByKey } from "@worknest/email";
import { ChannelDeliveryResult, NotificationChannel, NotificationEnvelope, Recipient } from "../types";

export interface EmailChannelConfig {
  transport: EmailTransport;
  fromOverrides?: Partial<Record<string, EmailMessage["from"]>>;
}

export class EmailChannel implements NotificationChannel {
  readonly key = "email" as const;

  constructor(private readonly cfg: EmailChannelConfig) {}

  async send(envelope: NotificationEnvelope, recipient: Recipient): Promise<ChannelDeliveryResult> {
    if (!recipient.email) {
      return { envelopeId: envelope.id, channel: "email", status: "skipped", reason: "no-email" };
    }
    if (!envelope.emailTemplate) {
      return { envelopeId: envelope.id, channel: "email", status: "skipped", reason: "no-template" };
    }

    const rendered = renderByKey(envelope.emailTemplate, envelope.emailProps);
    const message: EmailMessage = {
      to: { email: recipient.email, name: recipient.name },
      subject: rendered.subject,
      html: rendered.html,
      text: rendered.text,
      tags: [envelope.kind],
      from: this.cfg.fromOverrides?.[envelope.kind],
    };

    const result = await this.cfg.transport.send(message);
    return {
      envelopeId: envelope.id,
      channel: "email",
      status: "delivered",
      externalId: result.messageId,
    };
  }
}
