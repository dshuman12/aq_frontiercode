import { ChannelKey, NotificationKind } from "./types";

export interface RateLimitConfig {
  capacity: number;
  windowMs: number;
}

export interface RateLimitStore {
  consume(key: string, cfg: RateLimitConfig, nowMs?: number): Promise<boolean>;
}

interface Bucket {
  tokens: number;
  lastRefill: number;
}

export class InMemoryRateLimitStore implements RateLimitStore {
  private readonly buckets = new Map<string, Bucket>();

  async consume(key: string, cfg: RateLimitConfig, nowArg?: number): Promise<boolean> {
    const now = nowArg ?? Date.now();
    const refillRate = cfg.capacity / cfg.windowMs;

    let bucket = this.buckets.get(key);
    if (!bucket) {
      bucket = { tokens: cfg.capacity, lastRefill: now };
      this.buckets.set(key, bucket);
    }
    const elapsed = Math.max(0, now - bucket.lastRefill);
    bucket.tokens = Math.min(cfg.capacity, bucket.tokens + elapsed * refillRate);
    bucket.lastRefill = now;

    if (bucket.tokens < 1) return false;
    bucket.tokens -= 1;
    return true;
  }

  reset(): void {
    this.buckets.clear();
  }
}

export function rateLimitKey(input: {
  recipientId: string;
  kind: NotificationKind;
  channel: ChannelKey;
}): string {
  return `${input.recipientId}:${input.kind}:${input.channel}`;
}

export const DEFAULT_RATE_LIMITS: Partial<Record<NotificationKind, RateLimitConfig>> = {
  "task.commented":     { capacity: 8, windowMs: 60 * 60 * 1000 },
  "task.due_soon":      { capacity: 4, windowMs: 24 * 60 * 60 * 1000 },
  "task.overdue":       { capacity: 4, windowMs: 24 * 60 * 60 * 1000 },
  "ticket.commented":   { capacity: 8, windowMs: 60 * 60 * 1000 },
  "asset.warranty":     { capacity: 1, windowMs: 7 * 24 * 60 * 60 * 1000 },
  "inventory.low_stock":{ capacity: 1, windowMs: 24 * 60 * 60 * 1000 },
  "digest.daily":       { capacity: 1, windowMs: 22 * 60 * 60 * 1000 },
  "digest.weekly":      { capacity: 1, windowMs: 6 * 24 * 60 * 60 * 1000 },
};
