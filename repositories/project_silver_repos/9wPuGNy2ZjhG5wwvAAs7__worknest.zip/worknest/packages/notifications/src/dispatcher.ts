import { logger } from "@worknest/logger";
import {
  ChannelDeliveryResult,
  ChannelKey,
  NotificationChannel,
  NotificationEnvelope,
  Recipient,
} from "./types";
import { isChannelEnabled } from "./preferences";
import {
  DEFAULT_RATE_LIMITS,
  InMemoryRateLimitStore,
  RateLimitStore,
  rateLimitKey,
} from "./rate-limit";

export interface DispatcherConfig {
  channels: NotificationChannel[];
  rateLimit?: RateLimitStore;
  /**
   * Channels in this set ignore preference toggles when severity is
   * `critical`. Default: in-app + email — we always want a critical
   * notification to land somewhere.
   */
  criticalOverrideChannels?: ChannelKey[];
}

export interface DispatchSummary {
  envelopeId: string;
  delivered: ChannelDeliveryResult[];
  skipped: { channel: ChannelKey; reason: string }[];
}

export class NotificationDispatcher {
  private readonly log = logger("notifications/dispatcher");
  private readonly channelsByKey: Map<ChannelKey, NotificationChannel>;
  private readonly rateLimit: RateLimitStore;
  private readonly criticalOverride: Set<ChannelKey>;

  constructor(cfg: DispatcherConfig) {
    this.channelsByKey = new Map(cfg.channels.map((c) => [c.key, c]));
    this.rateLimit = cfg.rateLimit ?? new InMemoryRateLimitStore();
    this.criticalOverride = new Set(cfg.criticalOverrideChannels ?? ["in_app", "email"]);
  }

  async dispatch(envelope: NotificationEnvelope, recipient: Recipient): Promise<DispatchSummary> {
    const summary: DispatchSummary = {
      envelopeId: envelope.id,
      delivered: [],
      skipped: [],
    };

    for (const [channelKey, channel] of this.channelsByKey) {
      const isCritical = envelope.severity === "critical";
      const allowedByPrefs = isChannelEnabled(recipient.preferences, envelope.kind, channelKey);
      const overridden = isCritical && this.criticalOverride.has(channelKey);

      if (!allowedByPrefs && !overridden) {
        summary.skipped.push({ channel: channelKey, reason: "disabled-by-pref" });
        continue;
      }

      const limit = DEFAULT_RATE_LIMITS[envelope.kind];
      if (limit && !overridden) {
        const ok = await this.rateLimit.consume(
          rateLimitKey({ recipientId: recipient.userId, kind: envelope.kind, channel: channelKey }),
          limit,
        );
        if (!ok) {
          summary.skipped.push({ channel: channelKey, reason: "rate-limited" });
          continue;
        }
      }

      try {
        const result = await channel.send(envelope, recipient);
        if (result.status === "delivered") summary.delivered.push(result);
        else summary.skipped.push({ channel: channelKey, reason: result.reason ?? result.status });
      } catch (err) {
        this.log.error({ err, channel: channelKey, envelopeId: envelope.id }, "channel send failed");
        summary.skipped.push({ channel: channelKey, reason: "exception" });
      }
    }

    return summary;
  }
}
