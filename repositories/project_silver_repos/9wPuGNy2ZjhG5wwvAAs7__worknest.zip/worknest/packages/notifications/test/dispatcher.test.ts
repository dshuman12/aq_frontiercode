import { describe, expect, it, vi } from "vitest";
import { NotificationDispatcher } from "../src/dispatcher";
import { DEFAULT_PREFERENCES, isQuietHour } from "../src/preferences";
import { InMemoryRateLimitStore } from "../src/rate-limit";
import { DigestBuilder } from "../src/digest";
import type { NotificationChannel, NotificationEnvelope, Recipient } from "../src/types";

function makeChannel(key: NotificationChannel["key"], status: "delivered" | "skipped" = "delivered"): NotificationChannel {
  return {
    key,
    send: vi.fn().mockResolvedValue({ envelopeId: "e", channel: key, status }),
  };
}

const RECIPIENT: Recipient = {
  userId: "u",
  organizationId: "o",
  email: "x@y.z",
  name: "Alex",
  preferences: DEFAULT_PREFERENCES,
};

const ENV: NotificationEnvelope = {
  id: "e1",
  kind: "task.assigned",
  organizationId: "o",
  recipientId: "u",
  title: "Hi",
  occurredAt: new Date().toISOString(),
};

describe("dispatcher", () => {
  it("fans out to enabled channels", async () => {
    const dispatcher = new NotificationDispatcher({
      channels: [makeChannel("in_app"), makeChannel("email")],
    });
    const summary = await dispatcher.dispatch(ENV, RECIPIENT);
    expect(summary.delivered.map((d) => d.channel).sort()).toEqual(["email", "in_app"]);
  });

  it("skips disabled channels", async () => {
    const recipient: Recipient = {
      ...RECIPIENT,
      preferences: { ...DEFAULT_PREFERENCES, "task.assigned": { in_app: true, email: false } },
    };
    const dispatcher = new NotificationDispatcher({
      channels: [makeChannel("in_app"), makeChannel("email")],
    });
    const summary = await dispatcher.dispatch(ENV, recipient);
    expect(summary.delivered.map((d) => d.channel)).toEqual(["in_app"]);
    expect(summary.skipped.map((s) => s.channel)).toContain("email");
  });

  it("critical severity overrides preferences for default channels", async () => {
    const recipient: Recipient = {
      ...RECIPIENT,
      preferences: {
        ...DEFAULT_PREFERENCES,
        "ticket.escalated": { in_app: false, email: false },
      },
    };
    const dispatcher = new NotificationDispatcher({
      channels: [makeChannel("in_app"), makeChannel("email")],
    });
    const summary = await dispatcher.dispatch(
      { ...ENV, kind: "ticket.escalated", severity: "critical" },
      recipient,
    );
    expect(summary.delivered.length).toBe(2);
  });

  it("captures channel exceptions", async () => {
    const dispatcher = new NotificationDispatcher({
      channels: [
        {
          key: "email",
          send: vi.fn().mockRejectedValue(new Error("network")),
        },
      ],
    });
    const summary = await dispatcher.dispatch(ENV, RECIPIENT);
    expect(summary.delivered.length).toBe(0);
    expect(summary.skipped[0].reason).toBe("exception");
  });
});

describe("rate-limit", () => {
  it("allows up to capacity", async () => {
    const store = new InMemoryRateLimitStore();
    const cfg = { capacity: 2, windowMs: 60_000 };
    expect(await store.consume("k", cfg, 0)).toBe(true);
    expect(await store.consume("k", cfg, 1)).toBe(true);
    expect(await store.consume("k", cfg, 2)).toBe(false);
  });
});

describe("digest", () => {
  it("collapses by digest key", () => {
    const builder = new DigestBuilder();
    builder.add({ ...ENV, id: "1", digestKey: "task-1" });
    builder.add({ ...ENV, id: "2", digestKey: "task-1" });
    builder.add({ ...ENV, id: "3", digestKey: "task-2" });
    expect(builder.size).toBe(2);
    expect(builder.top(1)[0].count).toBe(2);
  });
});

describe("quiet hours", () => {
  it("matches start<end window", () => {
    const d = new Date(); d.setHours(14);
    expect(isQuietHour(d.getHours(), { start: 13, end: 15, tz: "UTC" })).toBe(true);
    expect(isQuietHour(d.getHours(), { start: 15, end: 18, tz: "UTC" })).toBe(false);
  });

  it("handles wrap-around windows (22 -> 7)", () => {
    expect(isQuietHour(23, { start: 22, end: 7, tz: "UTC" })).toBe(true);
    expect(isQuietHour(3, { start: 22, end: 7, tz: "UTC" })).toBe(true);
    expect(isQuietHour(12, { start: 22, end: 7, tz: "UTC" })).toBe(false);
  });
});
