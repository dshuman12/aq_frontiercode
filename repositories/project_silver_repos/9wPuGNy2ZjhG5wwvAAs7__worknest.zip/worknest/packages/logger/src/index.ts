/**
 * @worknest/logger
 *
 * Wraps pino with a redaction list and a per-module child-logger helper.
 * Every consumer should call `logger("module-name")` rather than touching
 * pino directly so we have a single place to add redactions / formatters.
 */

import pino, { Logger as PinoLogger } from "pino";

const REDACT_PATHS = [
  "password",
  "passwordHash",
  "token",
  "accessToken",
  "refreshToken",
  "authorization",
  "cookie",
  "set-cookie",
  "stripeApiKey",
  "stripeWebhookSecret",
  "smtpPassword",
  "apiKey",
  "secretsManager",
  "ssn",
  "creditCard",
  "*.password",
  "*.token",
  "req.headers.authorization",
  "req.headers.cookie",
];

const baseLogger = pino({
  level: process.env.LOG_LEVEL ?? "info",
  redact: { paths: REDACT_PATHS, censor: "[REDACTED]" },
  base: {
    service: process.env.SERVICE_NAME ?? "worknest",
    env: process.env.NODE_ENV ?? "development",
  },
  timestamp: pino.stdTimeFunctions.isoTime,
  transport:
    process.env.NODE_ENV === "production"
      ? undefined
      : {
          target: "pino-pretty",
          options: { colorize: true, translateTime: "SYS:HH:MM:ss.l" },
        },
});

export type Logger = PinoLogger;

export function logger(module: string, extra: Record<string, unknown> = {}): Logger {
  return baseLogger.child({ module, ...extra });
}

/**
 * Wraps a function so its entry/exit + duration are logged at debug level.
 * Useful for profiling hot paths in dev without sprinkling timing code.
 */
export function withLogging<T extends (...args: unknown[]) => unknown>(
  module: string,
  fn: T,
): T {
  const log = logger(module);
  return ((...args: Parameters<T>) => {
    const start = Date.now();
    log.debug({ args }, "enter");
    try {
      const out = fn(...args);
      if (out instanceof Promise) {
        return out.then((value) => {
          log.debug({ ms: Date.now() - start }, "exit");
          return value;
        });
      }
      log.debug({ ms: Date.now() - start }, "exit");
      return out;
    } catch (err) {
      log.error({ err, ms: Date.now() - start }, "threw");
      throw err;
    }
  }) as T;
}
