/**
 * RFC 6238 TOTP. We avoid a third-party dep so the auth package can stay
 * minimal — totp-generator and authenticator are both fine, but we don't
 * need their feature surface and the algorithm fits in 60 lines.
 *
 * Limitations: SHA-1 only (the standard), 6-digit codes, 30-second
 * window. Window tolerance of ±1 step (so a code at the boundary still
 * verifies). No backup codes — those live in the higher-level auth flow.
 */

import { createHmac, randomBytes } from "node:crypto";

const STEP_SECONDS = 30;
const DIGITS = 6;

export function generateSecret(): string {
  // Base32 (RFC 3548) without padding. 20 bytes = 160-bit secret = 32 chars.
  return base32Encode(randomBytes(20));
}

export function totp(secret: string, atSeconds: number = Math.floor(Date.now() / 1000)): string {
  const counter = Math.floor(atSeconds / STEP_SECONDS);
  return hotp(secret, counter);
}

export function verifyTotp(
  secret: string,
  code: string,
  atSeconds: number = Math.floor(Date.now() / 1000),
  windowSteps = 1,
): boolean {
  if (code.length !== DIGITS) return false;
  const baseCounter = Math.floor(atSeconds / STEP_SECONDS);
  for (let offset = -windowSteps; offset <= windowSteps; offset++) {
    if (hotp(secret, baseCounter + offset) === code) return true;
  }
  return false;
}

export function buildOtpAuthUrl(args: {
  secret: string;
  account: string;
  issuer: string;
}): string {
  const issuer = encodeURIComponent(args.issuer);
  const account = encodeURIComponent(args.account);
  return `otpauth://totp/${issuer}:${account}?secret=${args.secret}&issuer=${issuer}&algorithm=SHA1&digits=${DIGITS}&period=${STEP_SECONDS}`;
}

function hotp(secretBase32: string, counter: number): string {
  const key = base32Decode(secretBase32);
  const buf = Buffer.alloc(8);
  let c = BigInt(counter);
  for (let i = 7; i >= 0; i--) {
    buf[i] = Number(c & 0xffn);
    c >>= 8n;
  }
  const mac = createHmac("sha1", key).update(buf).digest();
  const offset = mac[mac.length - 1] & 0x0f;
  const code =
    ((mac[offset] & 0x7f) << 24) |
    (mac[offset + 1] << 16) |
    (mac[offset + 2] << 8) |
    mac[offset + 3];
  return String(code % 10 ** DIGITS).padStart(DIGITS, "0");
}

const ALPHA = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";

function base32Encode(buf: Buffer): string {
  let out = "";
  let bits = 0;
  let value = 0;
  for (const byte of buf) {
    value = (value << 8) | byte;
    bits += 8;
    while (bits >= 5) {
      out += ALPHA[(value >>> (bits - 5)) & 0x1f];
      bits -= 5;
    }
  }
  if (bits > 0) out += ALPHA[(value << (5 - bits)) & 0x1f];
  return out;
}

function base32Decode(s: string): Buffer {
  const cleaned = s.replace(/=+$/, "").toUpperCase();
  const bytes: number[] = [];
  let bits = 0;
  let value = 0;
  for (const ch of cleaned) {
    const idx = ALPHA.indexOf(ch);
    if (idx < 0) continue;
    value = (value << 5) | idx;
    bits += 5;
    if (bits >= 8) {
      bytes.push((value >>> (bits - 8)) & 0xff);
      bits -= 8;
    }
  }
  return Buffer.from(bytes);
}
