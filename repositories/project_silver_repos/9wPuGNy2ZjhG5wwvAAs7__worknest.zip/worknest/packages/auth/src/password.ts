/**
 * Password hashing and validation. We use argon2id with parameters tuned
 * to ~250ms per verify on our API instance class. The cost is dominated
 * by memory, not CPU, so increasing the time-cost is the cheapest way
 * to harden the parameters as hardware improves.
 */

import argon2 from "argon2";

const HASH_OPTIONS: argon2.Options & { raw?: false } = {
  type: argon2.argon2id,
  memoryCost: 19_456,
  timeCost: 3,
  parallelism: 1,
};

export async function hashPassword(password: string): Promise<string> {
  return argon2.hash(password, HASH_OPTIONS);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  try {
    return await argon2.verify(hash, password, HASH_OPTIONS);
  } catch {
    return false;
  }
}

export interface PasswordValidation {
  ok: boolean;
  reason?: string;
}

export function validatePassword(password: string): PasswordValidation {
  if (password.length < 12) return { ok: false, reason: "length<12" };
  if (password.length > 256) return { ok: false, reason: "length>256" };
  if (!/[a-z]/.test(password)) return { ok: false, reason: "needs lowercase" };
  if (!/[A-Z]/.test(password)) return { ok: false, reason: "needs uppercase" };
  if (!/[0-9]/.test(password)) return { ok: false, reason: "needs digit" };
  if (!/[^A-Za-z0-9]/.test(password)) return { ok: false, reason: "needs symbol" };
  return { ok: true };
}

/**
 * Returns true if the hash uses outdated parameters and should be
 * re-hashed on the next successful login. We compare against the current
 * `HASH_OPTIONS` so changing the options here automatically rolls out.
 */
export function needsRehash(hash: string): boolean {
  return argon2.needsRehash(hash, HASH_OPTIONS);
}
