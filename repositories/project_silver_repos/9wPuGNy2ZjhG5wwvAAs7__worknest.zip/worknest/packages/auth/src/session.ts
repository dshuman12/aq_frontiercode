/**
 * Session record helpers. The DB stores the SHA-256 hash of the session
 * token; the plaintext is only ever returned to the client at creation
 * time. The application-layer auth guard hashes the incoming token and
 * looks up the row.
 */

import { generateOpaqueToken, sha256Hex } from "./tokens";

export interface SessionRow {
  userId: string;
  tokenHash: string;
  ip?: string;
  userAgent?: string;
  device?: string;
  expiresAt: Date;
}

export interface NewSession {
  row: SessionRow;
  /** Plaintext session token to hand to the client. */
  rawToken: string;
}

export function newSession(args: {
  userId: string;
  ip?: string;
  userAgent?: string;
  device?: string;
  ttlMs?: number;
}): NewSession {
  const rawToken = generateOpaqueToken();
  const tokenHash = sha256Hex(rawToken);
  const expiresAt = new Date(Date.now() + (args.ttlMs ?? 30 * 24 * 60 * 60 * 1000));
  return {
    row: { userId: args.userId, tokenHash, ip: args.ip, userAgent: args.userAgent, device: args.device, expiresAt },
    rawToken,
  };
}

export function isSessionActive(row: { expiresAt: Date; revokedAt?: Date | null }): boolean {
  if (row.revokedAt) return false;
  return row.expiresAt > new Date();
}

/**
 * Pretty-prints a user agent string for the "active sessions" list in
 * settings. Heuristic; we don't try to parse every browser variant.
 */
export function summariseUserAgent(ua: string | undefined): string {
  if (!ua) return "Unknown device";
  if (/iPhone|iPad/i.test(ua)) return "iOS";
  if (/Android/i.test(ua)) return "Android";
  if (/Macintosh/i.test(ua)) {
    if (/Chrome/i.test(ua)) return "Chrome on macOS";
    if (/Safari/i.test(ua)) return "Safari on macOS";
    if (/Firefox/i.test(ua)) return "Firefox on macOS";
    return "macOS";
  }
  if (/Windows/i.test(ua)) {
    if (/Chrome/i.test(ua)) return "Chrome on Windows";
    if (/Edg/i.test(ua)) return "Edge on Windows";
    if (/Firefox/i.test(ua)) return "Firefox on Windows";
    return "Windows";
  }
  if (/Linux/i.test(ua)) return "Linux";
  return "Unknown device";
}
