/**
 * JWT helpers + opaque-token utilities.
 *
 * Access tokens are short-lived JWTs. Refresh tokens are JWTs that carry
 * the session id (`sid`) so the API can revoke a compromised refresh
 * without invalidating the entire user.
 *
 * Opaque tokens (for password reset, email verification, API keys) are
 * unguessable random hex strings; we store the SHA-256 hash and compare
 * on use.
 */

import { createHash, randomBytes } from "node:crypto";
import jwt, { JwtPayload, SignOptions } from "jsonwebtoken";

export interface AccessClaims extends JwtPayload {
  sub: string;
  orgId: string;
  role?: string;
}

export interface RefreshClaims extends JwtPayload {
  sub: string;
  sid: string;
}

export function signAccessToken(
  claims: Pick<AccessClaims, "sub" | "orgId" | "role">,
  secret: string,
  expiresIn: SignOptions["expiresIn"] = "15m",
): string {
  return jwt.sign(claims, secret, { expiresIn, algorithm: "HS256" });
}

export function signRefreshToken(
  claims: Pick<RefreshClaims, "sub" | "sid">,
  secret: string,
  expiresIn: SignOptions["expiresIn"] = "30d",
): string {
  return jwt.sign(claims, secret, { expiresIn, algorithm: "HS256" });
}

export function verifyAccessToken(token: string, secret: string): AccessClaims {
  return jwt.verify(token, secret) as AccessClaims;
}

export function verifyRefreshToken(token: string, secret: string): RefreshClaims {
  return jwt.verify(token, secret) as RefreshClaims;
}

/**
 * Generates a 32-byte hex string (256 bits of entropy). Used for session
 * tokens, password reset tokens, email verification tokens, and API keys.
 */
export function generateOpaqueToken(): string {
  return randomBytes(32).toString("hex");
}

export function sha256Hex(input: string): string {
  return createHash("sha256").update(input).digest("hex");
}
