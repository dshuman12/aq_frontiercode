import { describe, expect, it } from "vitest";
import {
  generateOpaqueToken,
  sha256Hex,
  signAccessToken,
  signRefreshToken,
  verifyAccessToken,
  verifyRefreshToken,
} from "../src/tokens";

describe("token helpers", () => {
  it("generates unique opaque tokens", () => {
    const a = generateOpaqueToken();
    const b = generateOpaqueToken();
    expect(a).not.toBe(b);
    expect(a).toMatch(/^[a-f0-9]{40,}$/);
  });

  it("sha256 is deterministic", () => {
    expect(sha256Hex("abc")).toBe(sha256Hex("abc"));
    expect(sha256Hex("abc")).not.toBe(sha256Hex("abd"));
  });

  it("access token roundtrip", () => {
    const t = signAccessToken({ sub: "u1", orgId: "o1", role: "owner" }, "secret");
    const claims = verifyAccessToken(t, "secret");
    expect(claims.sub).toBe("u1");
    expect(claims.orgId).toBe("o1");
    expect(claims.role).toBe("owner");
  });

  it("refresh token carries session id", () => {
    const t = signRefreshToken({ sub: "u1", sid: "s1" }, "secret");
    const claims = verifyRefreshToken(t, "secret");
    expect(claims.sid).toBe("s1");
  });

  it("rejects wrong secret", () => {
    const t = signAccessToken({ sub: "u1", orgId: "o1" }, "a");
    expect(() => verifyAccessToken(t, "b")).toThrow();
  });
});
