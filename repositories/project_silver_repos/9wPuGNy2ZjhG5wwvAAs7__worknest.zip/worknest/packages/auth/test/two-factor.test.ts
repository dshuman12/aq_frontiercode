import { describe, expect, it } from "vitest";
import { generateSecret, totp, verifyTotp, buildOtpAuthUrl } from "../src/two-factor";

describe("totp", () => {
  it("generates a base32 secret", () => {
    const s = generateSecret();
    expect(s).toMatch(/^[A-Z2-7]{32}$/);
  });

  it("verifies its own code", () => {
    const s = generateSecret();
    const code = totp(s);
    expect(verifyTotp(s, code)).toBe(true);
  });

  it("rejects an incorrect code", () => {
    const s = generateSecret();
    expect(verifyTotp(s, "123456")).toBe(false);
  });

  it("buildOtpAuthUrl encodes issuer + account", () => {
    const url = buildOtpAuthUrl({ secret: "ABC", account: "alex@example.com", issuer: "WorkNest" });
    expect(url).toContain("otpauth://totp/WorkNest:alex%40example.com");
    expect(url).toContain("secret=ABC");
  });
});
