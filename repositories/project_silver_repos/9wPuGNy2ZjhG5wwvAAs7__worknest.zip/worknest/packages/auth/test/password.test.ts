import { describe, expect, it } from "vitest";
import { hashPassword, verifyPassword, validatePassword } from "../src/password";

describe("password helpers", () => {
  it("hashes and verifies", async () => {
    const hash = await hashPassword("Sup3rsecret!ABC");
    expect(await verifyPassword("Sup3rsecret!ABC", hash)).toBe(true);
    expect(await verifyPassword("nope", hash)).toBe(false);
  });

  it("rejects short passwords", () => {
    expect(validatePassword("ab1!")).toEqual({ ok: false, reason: "length<12" });
  });

  it("requires upper + lower + digit + symbol", () => {
    expect(validatePassword("alllowercase1!")).toEqual({ ok: false, reason: "needs uppercase" });
    expect(validatePassword("ALLUPPER1!aaa")).toEqual({ ok: true });
    expect(validatePassword("nodigit!Aabcdef")).toEqual({ ok: false, reason: "needs digit" });
    expect(validatePassword("nosymbol1Aabcdef")).toEqual({ ok: false, reason: "needs symbol" });
  });

  it("accepts strong password", () => {
    expect(validatePassword("Sup3r-secret-passphrase!")).toEqual({ ok: true });
  });
});
