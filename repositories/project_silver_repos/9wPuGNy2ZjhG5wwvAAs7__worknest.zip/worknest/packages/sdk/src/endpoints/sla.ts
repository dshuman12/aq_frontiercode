import { Client } from "../client";

export interface SlaPolicy {
  id: string;
  name: string;
  priority: string;
  categoryId: string | null;
  firstResponseMinutes: number;
  resolutionMinutes: number;
  businessHoursOnly: boolean;
  active: boolean;
}

export interface SlaTimer {
  id: string;
  ticketId: string;
  policyId: string;
  firstResponseDueAt: string;
  firstResponseMetAt: string | null;
  resolutionDueAt: string;
  resolutionMetAt: string | null;
  breachedFirstResponse: boolean;
  breachedResolution: boolean;
}

export const sla = {
  listPolicies: (c: Client) => c.get<SlaPolicy[]>("/sla/policies"),
  createPolicy: (c: Client, body: Omit<SlaPolicy, "id">) =>
    c.post<SlaPolicy>("/sla/policies", body),
  updatePolicy: (c: Client, id: string, body: Partial<SlaPolicy>) =>
    c.patch<SlaPolicy>(`/sla/policies/${id}`, body),
  deletePolicy: (c: Client, id: string) =>
    c.delete<{ ok: true }>(`/sla/policies/${id}`),
  startTimer: (c: Client, ticketId: string) =>
    c.post<SlaTimer | null>(`/sla/timers/${ticketId}/start`),
  markFirstResponse: (c: Client, ticketId: string) =>
    c.post<SlaTimer>(`/sla/timers/${ticketId}/first-response`),
  markResolved: (c: Client, ticketId: string) =>
    c.post<SlaTimer>(`/sla/timers/${ticketId}/resolved`),
  pause: (c: Client, ticketId: string) => c.post<SlaTimer>(`/sla/timers/${ticketId}/pause`),
  resume: (c: Client, ticketId: string) => c.post<SlaTimer>(`/sla/timers/${ticketId}/resume`),
  sweep: (c: Client) => c.post<{ scanned: number; breached: number }>("/sla/sweep"),
  dashboard: (c: Client) =>
    c.get<{ open: SlaTimer[]; breached: SlaTimer[]; breachedCount: number }>("/sla/dashboard"),
};
