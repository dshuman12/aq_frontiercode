import { Client } from "../client";
import { ApprovalDecision } from "../types";

export interface ApprovalWorkflow {
  id: string;
  name: string;
  description?: string | null;
  appliesTo: string;
  enabled: boolean;
  steps: {
    id: string;
    order: number;
    name: string;
    approverId?: string;
    approverRole?: string;
    condition?: string;
    escalateAfterMinutes?: number;
  }[];
}

export const approvals = {
  workflows: {
    list: (c: Client) => c.get<ApprovalWorkflow[]>("/approvals/workflows"),
    byId: (c: Client, id: string) => c.get<ApprovalWorkflow>(`/approvals/workflows/${id}`),
    create: (c: Client, body: Omit<ApprovalWorkflow, "id">) => c.post<ApprovalWorkflow>("/approvals/workflows", body),
    update: (c: Client, id: string, body: Partial<ApprovalWorkflow>) =>
      c.patch<ApprovalWorkflow>(`/approvals/workflows/${id}`, body),
    delete: (c: Client, id: string) => c.delete<{ ok: true }>(`/approvals/workflows/${id}`),
  },
  pending: (c: Client) => c.get<ApprovalDecision[]>("/approvals/pending"),
  decided: (c: Client) => c.get<ApprovalDecision[]>("/approvals/decided"),
  decide: (c: Client, id: string, body: { decision: "approved" | "rejected"; reason?: string }) =>
    c.post<ApprovalDecision>(`/approvals/${id}/decide`, body),
  resubmit: (c: Client, id: string, body: { reason?: string }) =>
    c.post<ApprovalDecision>(`/approvals/${id}/resubmit`, body),
};
