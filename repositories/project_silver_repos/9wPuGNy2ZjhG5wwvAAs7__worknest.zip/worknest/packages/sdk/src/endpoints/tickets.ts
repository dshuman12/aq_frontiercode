import { Client } from "../client";
import { PageOf, Ticket } from "../types";

export interface TicketListFilter {
  status?: string;
  assigneeId?: string;
  categoryId?: string;
  q?: string;
  page?: number;
  pageSize?: number;
}

function qs(filter: TicketListFilter): string {
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(filter)) {
    if (v !== undefined && v !== null && v !== "") p.set(k, String(v));
  }
  return p.toString() ? `?${p}` : "";
}

export const tickets = {
  list: (c: Client, filter: TicketListFilter = {}) => c.get<PageOf<Ticket>>(`/tickets${qs(filter)}`),
  byId: (c: Client, id: string) => c.get<Ticket>(`/tickets/${id}`),
  create: (c: Client, body: { categoryId?: string; title: string; description?: string; priority?: string; assigneeId?: string }) =>
    c.post<Ticket>("/tickets", body),
  update: (c: Client, id: string, body: Partial<Ticket>) => c.patch<Ticket>(`/tickets/${id}`, body),
  transition: (c: Client, id: string, body: { toStatus: string; note?: string }) =>
    c.post<Ticket>(`/tickets/${id}/transition`, body),
  comment: (c: Client, id: string, body: { body: string; internal: boolean }) =>
    c.post<{ id: string }>(`/tickets/${id}/comments`, body),
  history: (c: Client, id: string) =>
    c.get<{ fromStatus?: string | null; toStatus: string; at: string }[]>(`/tickets/${id}/history`),
  watchers: {
    add: (c: Client, id: string, userId: string) => c.post(`/tickets/${id}/watchers`, { userId }),
    remove: (c: Client, id: string, userId: string) => c.delete(`/tickets/${id}/watchers/${userId}`),
  },
  categories: {
    list: (c: Client) => c.get<{ id: string; name: string; slug: string }[]>("/tickets/categories"),
    create: (c: Client, body: { name: string; slug: string; description?: string }) =>
      c.post<{ id: string }>("/tickets/categories", body),
  },
};
