import { Client } from "../client";
import { Organization } from "../types";

export interface OrgMember {
  id: string;
  organizationId: string;
  userId: string;
  role: string;
  user: { id: string; name: string; email: string; avatarUrl?: string };
  joinedAt: string;
}

export const organizations = {
  create: (c: Client, body: { name: string; slug: string }) => c.post<Organization>("/organizations", body),
  current: (c: Client) => c.get<Organization>("/organizations/current"),
  stats: (c: Client) => c.get<{ members: number; projects: number; tasks: number; tickets: number }>("/organizations/current/stats"),
  update: (c: Client, body: { name?: string; logoUrl?: string | null }) =>
    c.patch<Organization>("/organizations/current", body),
  members: (c: Client) => c.get<OrgMember[]>("/organizations/current/members"),
  setRole: (c: Client, userId: string, role: string) =>
    c.patch<OrgMember>(`/organizations/current/members/${userId}`, { role }),
  removeMember: (c: Client, userId: string) =>
    c.delete<{ ok: true }>(`/organizations/current/members/${userId}`),
  transferOwnership: (c: Client, body: { toUserId: string; password: string }) =>
    c.post<{ ok: true }>("/organizations/current/transfer-ownership", body),
};

export const invitations = {
  send: (c: Client, body: { email: string; role: string }) => c.post<{ invitation: { id: string }; token: string }>("/invitations", body),
  list: (c: Client) => c.get<{ id: string; email: string; role: string; expiresAt: string; acceptedAt?: string | null }[]>("/invitations"),
  revoke: (c: Client, id: string) => c.delete<{ ok: true }>(`/invitations/${id}`),
  accept: (c: Client, token: string) => c.post<{ ok: true }>("/invitations/accept", { token }),
};

export const roles = {
  list: (c: Client) => c.get<{ id: string; name: string; kind: "preset" | "custom"; permissions: string[] }[]>("/roles"),
  permissions: (c: Client) => c.get<Record<string, string[]>>("/roles/permissions"),
  create: (c: Client, body: { name: string; description?: string; permissions: string[] }) =>
    c.post<{ id: string }>("/roles", body),
  update: (c: Client, id: string, body: Partial<{ name: string; description: string; permissions: string[] }>) =>
    c.patch<{ id: string }>(`/roles/${id}`, body),
  delete: (c: Client, id: string) => c.delete<{ ok: true }>(`/roles/${id}`),
};
