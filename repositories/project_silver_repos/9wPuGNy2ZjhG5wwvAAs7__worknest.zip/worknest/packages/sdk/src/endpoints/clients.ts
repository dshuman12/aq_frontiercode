import { Client } from "../client";

export interface ClientRecord {
  id: string;
  name: string;
  industry?: string | null;
  website?: string | null;
  status: string;
  notes?: string | null;
  _count?: { contacts: number; portalUsers: number };
}

export const clients = {
  list: (c: Client, q?: string) =>
    c.get<ClientRecord[]>(`/clients${q ? `?q=${encodeURIComponent(q)}` : ""}`),
  byId: (c: Client, id: string) => c.get<ClientRecord>(`/clients/${id}`),
  create: (c: Client, body: Partial<ClientRecord> & { name: string }) =>
    c.post<ClientRecord>("/clients", body),
  update: (c: Client, id: string, body: Partial<ClientRecord>) =>
    c.patch<ClientRecord>(`/clients/${id}`, body),
  delete: (c: Client, id: string) => c.delete<{ ok: true }>(`/clients/${id}`),
  addContact: (c: Client, body: { clientId: string; name: string; role?: string; email?: string; phone?: string }) =>
    c.post<{ id: string }>("/clients/contacts", body),
  removeContact: (c: Client, id: string) => c.delete<{ ok: true }>(`/clients/contacts/${id}`),
  invitePortalUser: (c: Client, id: string, body: { email: string; name: string }) =>
    c.post<{ id: string }>(`/clients/${id}/portal-users`, body),
};
