import { Client } from "../client";
import { AssetRecord } from "../types";

export const assets = {
  list: (c: Client, filter: { categoryId?: string; status?: string; q?: string } = {}) => {
    const p = new URLSearchParams();
    for (const [k, v] of Object.entries(filter)) if (v) p.set(k, String(v));
    return c.get<AssetRecord[]>(`/assets${p.toString() ? `?${p}` : ""}`);
  },
  byId: (c: Client, id: string) => c.get<AssetRecord>(`/assets/${id}`),
  create: (c: Client, body: Partial<AssetRecord> & { tag: string; name: string }) =>
    c.post<AssetRecord>("/assets", body),
  update: (c: Client, id: string, body: Partial<AssetRecord>) => c.patch<AssetRecord>(`/assets/${id}`, body),
  assign: (c: Client, id: string, body: { assigneeId: string; effectiveAt?: string; note?: string }) =>
    c.post<AssetRecord>(`/assets/${id}/assign`, body),
  return_: (c: Client, id: string, body: { condition: "good" | "damaged" | "lost"; note?: string }) =>
    c.post<AssetRecord>(`/assets/${id}/return`, body),
  retire: (c: Client, id: string) => c.post<AssetRecord>(`/assets/${id}/retire`),
  warrantyExpiring: (c: Client, days = 30) => c.get<AssetRecord[]>(`/assets/warranty-expiring?days=${days}`),
  assignments: (c: Client, id: string) => c.get<{ id: string; assigneeId: string; effectiveAt: string }[]>(`/assets/${id}/assignments`),
  maintenance: (c: Client, id: string) => c.get<{ id: string; description: string; performedAt: string }[]>(`/assets/${id}/maintenance`),
  recordMaintenance: (c: Client, id: string, body: { performedAt: string; performedBy: string; description: string; costCents?: number }) =>
    c.post<{ id: string }>(`/assets/${id}/maintenance`, body),
  categories: {
    list: (c: Client) => c.get<{ id: string; name: string }[]>("/assets/categories"),
    create: (c: Client, body: { name: string; description?: string }) =>
      c.post<{ id: string }>("/assets/categories", body),
  },
};
