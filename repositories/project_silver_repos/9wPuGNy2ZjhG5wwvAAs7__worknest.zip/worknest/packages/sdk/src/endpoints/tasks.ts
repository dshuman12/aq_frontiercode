import { Client } from "../client";
import { PageOf, Task } from "../types";

export interface TaskListFilter {
  projectId?: string;
  assigneeId?: string;
  status?: string;
  priority?: string;
  q?: string;
  page?: number;
  pageSize?: number;
}

function qs(filter: TaskListFilter): string {
  const params = new URLSearchParams();
  for (const [k, v] of Object.entries(filter)) {
    if (v !== undefined && v !== null && v !== "") params.set(k, String(v));
  }
  return params.toString() ? `?${params}` : "";
}

export const tasks = {
  list: (c: Client, filter: TaskListFilter = {}) => c.get<PageOf<Task>>(`/tasks${qs(filter)}`),
  byId: (c: Client, id: string) => c.get<Task>(`/tasks/${id}`),
  create: (c: Client, body: Partial<Task> & { projectId: string; title: string }) =>
    c.post<Task>("/tasks", body),
  update: (c: Client, id: string, body: Partial<Task>) => c.patch<Task>(`/tasks/${id}`, body),
  delete: (c: Client, id: string) => c.delete<{ ok: true }>(`/tasks/${id}`),
  move: (c: Client, id: string, body: { boardColumnId: string; position?: number }) =>
    c.post<Task>(`/tasks/${id}/move`, body),
  assign: (c: Client, id: string, userId: string | null) => c.post<Task>(`/tasks/${id}/assign`, { userId }),
  comment: (c: Client, id: string, body: { body: string }) =>
    c.post<{ id: string }>(`/tasks/${id}/comments`, body),
  addDependency: (c: Client, id: string, body: { blockerId: string; type?: string }) =>
    c.post<{ id: string }>(`/tasks/${id}/dependencies`, body),
  addChecklist: (c: Client, id: string, body: { title: string }) =>
    c.post<{ id: string }>(`/tasks/${id}/checklists`, body),
  addChecklistItem: (c: Client, checklistId: string, body: { text: string }) =>
    c.post<{ id: string }>(`/tasks/checklists/${checklistId}/items`, body),
  toggleChecklistItem: (c: Client, itemId: string, done: boolean) =>
    c.patch<{ id: string }>(`/tasks/checklists/items/${itemId}`, { done }),
  labels: (c: Client) => c.get<{ name: string; color?: string }[]>("/tasks/labels"),
  customFields: (c: Client) => c.get<{ id: string; name: string; type: string }[]>("/tasks/custom-fields"),
};
