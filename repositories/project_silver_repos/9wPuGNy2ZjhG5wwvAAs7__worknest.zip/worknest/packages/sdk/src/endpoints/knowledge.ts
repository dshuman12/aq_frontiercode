import { Client } from "../client";

export interface KnowledgeArticle {
  id: string;
  slug: string;
  title: string;
  body: string;
  status: "draft" | "published" | "archived";
  categoryId: string | null;
  authorId: string;
  publishedAt: string | null;
  updatedAt: string;
}

export const knowledge = {
  listCategories: (c: Client) => c.get<unknown[]>("/knowledge/categories"),
  createCategory: (c: Client, body: { name: string; slug: string; description?: string }) =>
    c.post<unknown>("/knowledge/categories", body),
  listArticles: (c: Client, query: { categoryId?: string; status?: string; q?: string } = {}) => {
    const params = new URLSearchParams();
    for (const [k, v] of Object.entries(query)) if (v) params.set(k, String(v));
    return c.get<KnowledgeArticle[]>(`/knowledge/articles${params.toString() ? `?${params}` : ""}`);
  },
  getArticle: (c: Client, idOrSlug: string) =>
    c.get<KnowledgeArticle>(`/knowledge/articles/${idOrSlug}`),
  createArticle: (c: Client, body: Omit<KnowledgeArticle, "id" | "authorId" | "publishedAt" | "updatedAt">) =>
    c.post<KnowledgeArticle>("/knowledge/articles", body),
  updateArticle: (c: Client, id: string, body: Partial<KnowledgeArticle>) =>
    c.patch<KnowledgeArticle>(`/knowledge/articles/${id}`, body),
  publishArticle: (c: Client, id: string, publish: boolean) =>
    c.post<KnowledgeArticle>(`/knowledge/articles/${id}/publish`, { publish }),
  deleteArticle: (c: Client, id: string) => c.delete<{ ok: true }>(`/knowledge/articles/${id}`),
};
