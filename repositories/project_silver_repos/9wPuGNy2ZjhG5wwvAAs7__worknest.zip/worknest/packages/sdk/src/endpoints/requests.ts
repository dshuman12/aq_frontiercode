import { Client } from "../client";
import { RequestSubmission } from "../types";

export interface RequestForm {
  id: string;
  name: string;
  slug: string;
  description?: string | null;
  visibility: string;
  fields: { id: string; key: string; label: string; type: string; required: boolean; order: number }[];
}

export const requestForms = {
  list: (c: Client) => c.get<RequestForm[]>("/requests/forms"),
  byId: (c: Client, id: string) => c.get<RequestForm>(`/requests/forms/${id}`),
  create: (c: Client, body: { name: string; slug: string; description?: string; visibility?: string; fields: unknown[] }) =>
    c.post<RequestForm>("/requests/forms", body),
  update: (c: Client, id: string, body: Partial<RequestForm>) =>
    c.patch<RequestForm>(`/requests/forms/${id}`, body),
  archive: (c: Client, id: string) => c.delete<RequestForm>(`/requests/forms/${id}`),
};

export const requests = {
  list: (c: Client, filter: { status?: string; formId?: string; assigneeId?: string } = {}) => {
    const p = new URLSearchParams();
    for (const [k, v] of Object.entries(filter)) {
      if (v) p.set(k, String(v));
    }
    return c.get<RequestSubmission[]>(`/requests${p.toString() ? `?${p}` : ""}`);
  },
  byId: (c: Client, id: string) => c.get<RequestSubmission>(`/requests/${id}`),
  submit: (c: Client, body: { formId: string; title: string; priority?: string; fieldValues: Record<string, string> }) =>
    c.post<RequestSubmission>("/requests", body),
  transition: (c: Client, id: string, body: { toStatus: string; note?: string }) =>
    c.post<RequestSubmission>(`/requests/${id}/transition`, body),
  assign: (c: Client, id: string, assigneeId: string | null) =>
    c.post<RequestSubmission>(`/requests/${id}/assign`, { assigneeId }),
  comment: (c: Client, id: string, body: { body: string; internal: boolean }) =>
    c.post<{ id: string }>(`/requests/${id}/comments`, body),
};
