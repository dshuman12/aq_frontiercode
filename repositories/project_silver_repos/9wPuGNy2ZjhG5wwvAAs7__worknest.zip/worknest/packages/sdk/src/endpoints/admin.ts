import { Client } from "../client";
import { PageOf } from "../types";

export interface ApiKeyRow {
  id: string;
  label: string;
  scopes: string;
  lastUsedAt?: string | null;
  createdAt: string;
}

export interface AuditEntry {
  id: string;
  action: string;
  resource: string;
  resourceId: string;
  actorId?: string | null;
  ip?: string | null;
  userAgent?: string | null;
  diff?: unknown;
  createdAt: string;
}

export interface WebhookRow {
  id: string;
  url: string;
  kinds: string[];
  enabled: boolean;
  failureCount: number;
  lastDeliveredAt?: string | null;
  createdAt: string;
}

export const apiKeys = {
  list: (c: Client) => c.get<ApiKeyRow[]>("/api-keys"),
  create: (c: Client, body: { label: string; scopes: string; expiresInDays?: number }) =>
    c.post<ApiKeyRow & { plaintext: string }>("/api-keys", body),
  revoke: (c: Client, id: string) => c.delete<{ ok: true }>(`/api-keys/${id}`),
};

export const auditLogs = {
  list: (c: Client, opts: { page?: number; action?: string; resource?: string; q?: string } = {}) => {
    const p = new URLSearchParams();
    for (const [k, v] of Object.entries(opts)) if (v !== undefined && v !== "") p.set(k, String(v));
    return c.get<PageOf<AuditEntry>>(`/audit-logs${p.toString() ? `?${p}` : ""}`);
  },
  forResource: (c: Client, resource: string, resourceId: string) =>
    c.get<AuditEntry[]>(`/audit-logs/${resource}/${resourceId}`),
};

export const webhooks = {
  list: (c: Client) => c.get<WebhookRow[]>("/webhooks"),
  deliveries: (c: Client) =>
    c.get<{ id: string; webhookId: string; event: string; status?: number | null; succeeded: boolean; attemptedAt: string }[]>(
      "/webhooks/deliveries",
    ),
  create: (c: Client, body: { url: string; kinds: string[] }) =>
    c.post<WebhookRow & { secret: string }>("/webhooks", body),
  update: (c: Client, id: string, body: Partial<WebhookRow>) =>
    c.patch<WebhookRow>(`/webhooks/${id}`, body),
  rotateSecret: (c: Client, id: string) => c.post<{ secret: string }>(`/webhooks/${id}/rotate-secret`),
  delete: (c: Client, id: string) => c.delete<{ ok: true }>(`/webhooks/${id}`),
};
