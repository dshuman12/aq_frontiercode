import { Client } from "../client";

export const billing = {
  checkout: (c: Client, body: { plan: "starter" | "team" | "business"; cadence: "month" | "year"; returnUrl: string; cancelUrl: string }) =>
    c.post<{ url: string; sessionId: string }>("/billing/checkout", body),
  portal: (c: Client, body: { customerId: string; returnUrl: string }) =>
    c.post<{ url: string }>("/billing/portal", body),
  changeSeats: (c: Client, body: { seats: number }) =>
    c.post<{ ok: true }>("/billing/seats", body),
  invoices: (c: Client) =>
    c.get<{ id: string; number?: string | null; status: string; amountDueCents: number; issuedAt: string; hostedInvoiceUrl?: string | null }[]>(
      "/billing/invoices",
    ),
};
