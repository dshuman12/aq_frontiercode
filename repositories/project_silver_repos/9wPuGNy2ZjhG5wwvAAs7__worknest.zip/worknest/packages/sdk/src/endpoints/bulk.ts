import { Client } from "../client";

export const bulk = {
  updateTasks: (c: Client, body: { ids: string[]; patch: Record<string, unknown> }) =>
    c.post<{ updated: number; requested: number }>("/bulk/tasks/update", body),
  deleteTasks: (c: Client, ids: string[]) =>
    c.post<{ deleted: number; requested: number }>("/bulk/tasks/delete", { ids }),
  applyTaskLabels: (
    c: Client,
    body: { ids: string[]; labels: string[]; mode: "add" | "remove" | "replace" },
  ) => c.post<{ affected: number; requested: number }>("/bulk/tasks/labels", body),
  updateTickets: (c: Client, body: { ids: string[]; patch: Record<string, unknown> }) =>
    c.post<{ updated: number; requested: number }>("/bulk/tickets/update", body),
};
