import { Client } from "../client";
import { InventoryItem, PageOf } from "../types";

export const inventory = {
  list: (c: Client, filter: { warehouseId?: string; vendorId?: string; q?: string } = {}) => {
    const p = new URLSearchParams();
    for (const [k, v] of Object.entries(filter)) if (v) p.set(k, String(v));
    return c.get<InventoryItem[]>(`/inventory${p.toString() ? `?${p}` : ""}`);
  },
  byId: (c: Client, id: string) => c.get<InventoryItem>(`/inventory/${id}`),
  create: (c: Client, body: Partial<InventoryItem> & { sku: string; name: string; unit: string }) =>
    c.post<InventoryItem>("/inventory", body),
  update: (c: Client, id: string, body: Partial<InventoryItem>) =>
    c.patch<InventoryItem>(`/inventory/${id}`, body),
  delete: (c: Client, id: string) => c.delete<{ ok: true }>(`/inventory/${id}`),
  lowStock: (c: Client) => c.get<InventoryItem[]>("/inventory/low-stock"),
  recordTransaction: (c: Client, body: { itemId: string; delta: number; reason: string; reference?: string }) =>
    c.post<{ item: InventoryItem; transaction: { id: string } }>("/inventory/transactions", body),
  transactionsFor: (c: Client, id: string, page = 1, pageSize = 50) =>
    c.get<PageOf<{ id: string; delta: number; balanceAfter: number; reason: string; createdAt: string }>>(
      `/inventory/${id}/transactions?page=${page}&pageSize=${pageSize}`,
    ),
  vendors: {
    list: (c: Client) => c.get<{ id: string; name: string; category: string }[]>("/inventory/vendors/all"),
    create: (c: Client, body: { name: string; category: string }) =>
      c.post<{ id: string }>("/inventory/vendors", body),
  },
  warehouses: {
    list: (c: Client) => c.get<{ id: string; name: string; address?: string }[]>("/inventory/warehouses/all"),
    create: (c: Client, body: { name: string; address?: string }) =>
      c.post<{ id: string }>("/inventory/warehouses", body),
  },
};
