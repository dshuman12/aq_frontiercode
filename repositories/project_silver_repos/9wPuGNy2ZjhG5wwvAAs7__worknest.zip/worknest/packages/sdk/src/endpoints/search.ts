import { Client } from "../client";

export interface SearchHit {
  resource: "project" | "task" | "ticket" | "request" | "client";
  id: string;
  title: string;
  subtitle?: string;
  url: string;
  updatedAt?: string;
}

export const search = {
  query: (c: Client, q: string, limit?: number) => {
    const params = new URLSearchParams({ q });
    if (limit) params.set("limit", String(limit));
    return c.get<{ hits: SearchHit[]; total: number }>(`/search?${params}`);
  },
};
