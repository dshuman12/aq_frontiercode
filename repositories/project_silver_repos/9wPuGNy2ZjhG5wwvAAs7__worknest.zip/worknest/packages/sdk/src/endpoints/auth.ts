import { Client } from "../client";
import { User } from "../types";

export interface LoginInput {
  email: string;
  password: string;
  twoFactorCode?: string;
}

export interface LoginResult {
  accessToken: string;
  refreshToken: string;
  sessionToken: string;
  user: User;
}

export const auth = {
  register: (c: Client, body: { email: string; password: string; name: string; organizationName?: string }) =>
    c.post<User>("/auth/register", body),
  login: (c: Client, body: LoginInput) => c.post<LoginResult>("/auth/login", body),
  refresh: (c: Client, body: { refreshToken: string }) =>
    c.post<{ accessToken: string }>("/auth/refresh", body),
  logout: (c: Client, body: { sessionToken: string }) =>
    c.post<{ ok: true }>("/auth/logout", body),
  requestPasswordReset: (c: Client, body: { email: string }) =>
    c.post<{ ok: true }>("/auth/password/reset/request", body),
  completePasswordReset: (c: Client, body: { token: string; password: string }) =>
    c.post<{ ok: true }>("/auth/password/reset/complete", body),
  verifyEmail: (c: Client, body: { token: string }) =>
    c.post<{ ok: true }>("/auth/verify-email", body),
  sessions: (c: Client) => c.get<{ id: string; ip?: string; userAgent?: string; lastSeenAt: string; createdAt: string }[]>("/auth/sessions"),
  revokeSession: (c: Client, sessionId: string) => c.post<{ ok: true }>("/auth/sessions/revoke", { sessionId }),
  begin2fa: (c: Client) => c.post<{ secret: string }>("/auth/2fa/begin"),
  enable2fa: (c: Client, body: { secret: string; code: string }) => c.post<{ ok: true }>("/auth/2fa/enable", body),
  disable2fa: (c: Client, body: { password: string }) => c.post<{ ok: true }>("/auth/2fa/disable", body),
};
