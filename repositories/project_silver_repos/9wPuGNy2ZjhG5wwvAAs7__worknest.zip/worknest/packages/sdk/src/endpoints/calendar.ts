import { Client } from "../client";

export interface CalendarEvent {
  id: string;
  title: string;
  start: string;
  end: string;
  type: "task_due" | "sprint" | "milestone";
  link: string;
}

export const calendar = {
  events: (c: Client, from: string, to: string, projectId?: string) => {
    const params = new URLSearchParams({ from, to });
    if (projectId) params.set("projectId", projectId);
    return c.get<CalendarEvent[]>(`/calendar/events?${params}`);
  },
};
