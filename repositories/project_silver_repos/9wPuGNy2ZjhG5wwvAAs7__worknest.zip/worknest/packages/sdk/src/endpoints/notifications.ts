import { Client } from "../client";
import { NotificationItem, PageOf } from "../types";

export const notifications = {
  list: (c: Client, opts: { unread?: boolean; page?: number; pageSize?: number } = {}) => {
    const p = new URLSearchParams();
    for (const [k, v] of Object.entries(opts)) {
      if (v !== undefined) p.set(k, String(v));
    }
    return c.get<PageOf<NotificationItem>>(`/notifications${p.toString() ? `?${p}` : ""}`);
  },
  unread: (c: Client) => c.get<NotificationItem[]>("/notifications/unread"),
  markRead: (c: Client, ids: string[]) => c.post<{ ok: true }>("/notifications/read", { ids }),
  markAllRead: (c: Client) => c.post<{ ok: true }>("/notifications/read-all"),
  preferences: (c: Client) => c.get<Record<string, Record<string, boolean>>>("/notifications/preferences"),
  setPreference: (c: Client, body: { kind: string; channel: string; enabled: boolean }) =>
    c.post<{ ok: true }>("/notifications/preferences", body),
  resetPreferences: (c: Client) => c.delete<Record<string, Record<string, boolean>>>("/notifications/preferences"),
};
