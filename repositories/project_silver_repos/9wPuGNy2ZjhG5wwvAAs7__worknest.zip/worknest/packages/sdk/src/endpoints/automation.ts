import { Client } from "../client";

export type AutomationResource = "task" | "ticket" | "request";
export type AutomationTrigger =
  | "created"
  | "updated"
  | "status_changed"
  | "assignee_changed"
  | "due_soon";

export interface AutomationRule {
  id: string;
  name: string;
  resource: AutomationResource;
  trigger: AutomationTrigger;
  condition: Record<string, unknown> | null;
  actions: unknown[];
  active: boolean;
}

export interface AutomationRun {
  id: string;
  ruleId: string;
  resourceId: string;
  status: "success" | "failed" | "skipped";
  outcome: unknown;
  errorMessage: string | null;
  ranAt: string;
}

export const automation = {
  listRules: (c: Client, query: { resource?: string; trigger?: string } = {}) => {
    const params = new URLSearchParams();
    for (const [k, v] of Object.entries(query)) if (v) params.set(k, String(v));
    return c.get<AutomationRule[]>(`/automation/rules${params.toString() ? `?${params}` : ""}`);
  },
  createRule: (c: Client, body: Omit<AutomationRule, "id">) =>
    c.post<AutomationRule>("/automation/rules", body),
  updateRule: (c: Client, id: string, body: Partial<AutomationRule>) =>
    c.patch<AutomationRule>(`/automation/rules/${id}`, body),
  deleteRule: (c: Client, id: string) => c.delete<{ ok: true }>(`/automation/rules/${id}`),
  runs: (c: Client, ruleId: string, limit?: number) =>
    c.get<AutomationRun[]>(`/automation/rules/${ruleId}/runs${limit ? `?limit=${limit}` : ""}`),
  test: (c: Client, ruleId: string, resourceId: string) =>
    c.post<{ matched: boolean; actionsThatWouldRun: unknown[]; payload: unknown }>(
      `/automation/rules/${ruleId}/test`,
      { resourceId },
    ),
};
