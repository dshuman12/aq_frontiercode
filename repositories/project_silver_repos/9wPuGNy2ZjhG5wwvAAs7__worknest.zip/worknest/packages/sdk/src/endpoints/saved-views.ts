import { Client } from "../client";

export interface SavedView {
  id: string;
  resource: "tasks" | "tickets" | "requests";
  name: string;
  criteria: Record<string, unknown>;
  isShared: boolean;
  isDefault: boolean;
  ownerId: string;
}

export const savedViews = {
  list: (c: Client, resource?: string) =>
    c.get<SavedView[]>(`/saved-views${resource ? `?resource=${resource}` : ""}`),
  byId: (c: Client, id: string) => c.get<SavedView>(`/saved-views/${id}`),
  create: (c: Client, body: Omit<SavedView, "id" | "ownerId">) =>
    c.post<SavedView>("/saved-views", body),
  update: (c: Client, id: string, body: Partial<SavedView>) =>
    c.patch<SavedView>(`/saved-views/${id}`, body),
  delete: (c: Client, id: string) => c.delete<{ ok: true }>(`/saved-views/${id}`),
};
