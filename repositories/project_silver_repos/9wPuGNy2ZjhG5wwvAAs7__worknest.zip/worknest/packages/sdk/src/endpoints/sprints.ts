import { Client } from "../client";

export interface Sprint {
  id: string;
  projectId: string;
  name: string;
  goal: string | null;
  status: "planned" | "active" | "completed" | "cancelled";
  startsAt: string | null;
  endsAt: string | null;
  completedAt: string | null;
}

export const sprints = {
  list: (c: Client, projectId: string, status?: string) =>
    c.get<Sprint[]>(`/sprints?projectId=${projectId}${status ? `&status=${status}` : ""}`),
  backlog: (c: Client, projectId: string) =>
    c.get<{ items: unknown[]; total: number }>(`/sprints/backlog?projectId=${projectId}`),
  byId: (c: Client, id: string) =>
    c.get<{ sprint: Sprint; stats: Array<{ status: string; _count: number }> }>(`/sprints/${id}`),
  create: (
    c: Client,
    body: { projectId: string; name: string; goal?: string; startsAt?: string; endsAt?: string },
  ) => c.post<Sprint>("/sprints", body),
  update: (c: Client, id: string, body: Partial<Sprint>) =>
    c.patch<Sprint>(`/sprints/${id}`, body),
  transition: (c: Client, id: string, toStatus: Sprint["status"]) =>
    c.post<Sprint>(`/sprints/${id}/transition`, { toStatus }),
  addTasks: (c: Client, id: string, taskIds: string[]) =>
    c.post<{ moved: number }>(`/sprints/${id}/tasks`, { taskIds }),
  removeTasks: (c: Client, id: string, taskIds: string[]) =>
    c.post<{ removed: number }>(`/sprints/${id}/tasks/remove`, { taskIds }),
};
