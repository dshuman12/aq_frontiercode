import { Client } from "../client";

export interface TimeEntry {
  id: string;
  taskId: string;
  userId: string;
  description: string | null;
  startedAt: string;
  endedAt: string | null;
  durationSeconds: number | null;
  billable: boolean;
}

interface TimeEntryListFilter {
  taskId?: string;
  userId?: string;
  projectId?: string;
  fromDate?: string;
  toDate?: string;
  billable?: boolean;
  page?: number;
  pageSize?: number;
}

function qs(filter: Record<string, unknown>): string {
  const params = new URLSearchParams();
  for (const [k, v] of Object.entries(filter)) {
    if (v !== undefined && v !== null && v !== "") params.set(k, String(v));
  }
  return params.toString() ? `?${params}` : "";
}

export const timeEntries = {
  list: (c: Client, filter: TimeEntryListFilter = {}) =>
    c.get<{ items: TimeEntry[]; total: number; totalSeconds: number }>(
      `/time-entries${qs(filter)}`,
    ),
  running: (c: Client) => c.get<TimeEntry | null>("/time-entries/running"),
  start: (c: Client, body: { taskId: string; description?: string; billable?: boolean }) =>
    c.post<TimeEntry>("/time-entries/start", body),
  stop: (c: Client, body: { endedAt?: string } = {}) =>
    c.post<TimeEntry>("/time-entries/stop", body),
  create: (
    c: Client,
    body: {
      taskId: string;
      description?: string;
      startedAt: string;
      endedAt: string;
      billable?: boolean;
    },
  ) => c.post<TimeEntry>("/time-entries", body),
  update: (c: Client, id: string, body: Partial<TimeEntry>) =>
    c.patch<TimeEntry>(`/time-entries/${id}`, body),
  delete: (c: Client, id: string) => c.delete<{ ok: true }>(`/time-entries/${id}`),
  taskRollup: (c: Client, taskId: string) =>
    c.get<{ total: number; byUser: Array<{ userId: string; _sum: { durationSeconds: number | null } }> }>(
      `/time-entries/rollup/task/${taskId}`,
    ),
  projectRollup: (c: Client, projectId: string) =>
    c.get<{ totalSeconds: number }>(`/time-entries/rollup/project/${projectId}`),
};
