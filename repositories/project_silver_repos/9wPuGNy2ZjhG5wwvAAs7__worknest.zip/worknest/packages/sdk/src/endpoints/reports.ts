import { Client } from "../client";

export interface OverviewReport {
  openTasks: number;
  overdueTasks: number;
  completedThisWeek: number;
  activeProjects: number;
  openTickets: number;
  pendingRequests: number;
  pendingApprovals: number;
}

export interface TeamWorkloadRow {
  userId: string;
  name: string;
  openTasks: number;
  overdueTasks: number;
  ticketsAssigned: number;
}

export const reports = {
  overview: (c: Client) => c.get<OverviewReport>("/reports/overview"),
  teamWorkload: (c: Client) => c.get<TeamWorkloadRow[]>("/reports/team-workload"),
  projectProgress: (c: Client, projectId: string) =>
    c.get<{ tasks: { total: number; done: number; ratio: number }; milestones: { total: number; done: number } }>(
      `/reports/project/${projectId}/progress`,
    ),
  ticketSla: (c: Client) =>
    c.get<{ priority: string; count: number; averageResolutionHours: number }[]>("/reports/ticket-sla"),
  tasksCsvUrl: (c: Client) => `${c.baseUrl}/reports/tasks.csv`,
  ticketsCsvUrl: (c: Client) => `${c.baseUrl}/reports/tickets.csv`,
};
