import { Client } from "../client";
import { Project } from "../types";

export const projects = {
  list: (c: Client) => c.get<Project[]>("/projects"),
  byId: (c: Client, id: string) => c.get<Project>(`/projects/${id}`),
  create: (c: Client, body: { name: string; key: string; description?: string }) =>
    c.post<Project>("/projects", body),
  update: (c: Client, id: string, body: Partial<Project>) => c.patch<Project>(`/projects/${id}`, body),
  archive: (c: Client, id: string) => c.patch<Project>(`/projects/${id}`, { archive: true }),
  delete: (c: Client, id: string) => c.delete<{ ok: true }>(`/projects/${id}`),
  members: (c: Client, id: string) =>
    c.get<{ id: string; userId: string | null; teamId: string | null; role: string }[]>(`/projects/${id}/members`),
  addMember: (c: Client, id: string, body: { userId?: string; teamId?: string; role?: string }) =>
    c.post<{ id: string }>(`/projects/${id}/members`, body),
  milestones: (c: Client, id: string) =>
    c.get<{ id: string; name: string; dueOn?: string; completedAt?: string | null }[]>(`/projects/${id}/milestones`),
  createMilestone: (c: Client, id: string, body: { name: string; description?: string; dueOn?: string }) =>
    c.post<{ id: string }>(`/projects/${id}/milestones`, body),
  activity: (c: Client, id: string, limit = 50) =>
    c.get<{ id: string; type: string; payload?: unknown; createdAt: string }[]>(
      `/projects/${id}/activity?limit=${limit}`,
    ),
};

export const boards = {
  forProject: (c: Client, projectId: string) =>
    c.get<{ id: string; name: string; columns: { id: string; name: string; order: number }[] }[]>(
      `/boards/by-project/${projectId}`,
    ),
  byId: (c: Client, id: string) =>
    c.get<{ id: string; name: string; columns: { id: string; name: string; order: number }[] }>(`/boards/${id}`),
  reorder: (c: Client, id: string, ordering: { id: string; order: number }[]) =>
    c.post(`/boards/${id}/reorder`, { ordering }),
  addColumn: (c: Client, id: string, body: { name: string; order: number; wipLimit?: number; color?: string }) =>
    c.post(`/boards/${id}/columns`, body),
};
