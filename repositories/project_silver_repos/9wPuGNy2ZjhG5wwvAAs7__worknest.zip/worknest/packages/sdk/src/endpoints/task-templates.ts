import { Client } from "../client";

export interface TaskTemplate {
  id: string;
  name: string;
  title: string;
  description: string | null;
  priority: string;
  estimateHours: number | null;
  labels: string[];
}

export const taskTemplates = {
  list: (c: Client) => c.get<TaskTemplate[]>("/task-templates"),
  byId: (c: Client, id: string) => c.get<TaskTemplate>(`/task-templates/${id}`),
  create: (c: Client, body: Omit<TaskTemplate, "id">) =>
    c.post<TaskTemplate>("/task-templates", body),
  update: (c: Client, id: string, body: Partial<TaskTemplate>) =>
    c.patch<TaskTemplate>(`/task-templates/${id}`, body),
  delete: (c: Client, id: string) => c.delete<{ ok: true }>(`/task-templates/${id}`),
  apply: (c: Client, id: string, body: { projectId: string; assigneeId?: string | null; dueAt?: string | null }) =>
    c.post<{ id: string }>(`/task-templates/${id}/apply`, body),
};
