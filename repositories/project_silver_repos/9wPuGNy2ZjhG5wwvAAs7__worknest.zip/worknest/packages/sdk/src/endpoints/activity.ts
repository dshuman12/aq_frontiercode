import { Client } from "../client";

export interface ActivityEvent {
  id: string;
  resource: string;
  resourceId: string;
  verb: string;
  summary: string;
  actorId: string | null;
  payload: unknown;
  createdAt: string;
}

interface ActivityListFilter {
  resource?: string;
  resourceId?: string;
  actorId?: string;
  fromDate?: string;
  toDate?: string;
  page?: number;
  pageSize?: number;
}

function qs(filter: Record<string, unknown>): string {
  const params = new URLSearchParams();
  for (const [k, v] of Object.entries(filter)) {
    if (v !== undefined && v !== null && v !== "") params.set(k, String(v));
  }
  return params.toString() ? `?${params}` : "";
}

export const activity = {
  list: (c: Client, filter: ActivityListFilter = {}) =>
    c.get<{ items: ActivityEvent[]; total: number; page: number; pageSize: number }>(
      `/activity${qs(filter)}`,
    ),
  forResource: (c: Client, resource: string, resourceId: string, limit?: number) =>
    c.get<ActivityEvent[]>(
      `/activity/for-resource?resource=${resource}&resourceId=${resourceId}${
        limit ? `&limit=${limit}` : ""
      }`,
    ),
};
