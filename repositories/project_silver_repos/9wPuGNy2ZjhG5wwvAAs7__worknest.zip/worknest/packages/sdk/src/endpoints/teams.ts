import { Client } from "../client";

export interface Team {
  id: string;
  name: string;
  description?: string | null;
  _count?: { members: number };
}

export const teams = {
  list: (c: Client) => c.get<Team[]>("/teams"),
  byId: (c: Client, id: string) => c.get<Team & { members: { userId: string; role: string }[] }>(`/teams/${id}`),
  create: (c: Client, body: { name: string; description?: string }) => c.post<Team>("/teams", body),
  update: (c: Client, id: string, body: Partial<{ name: string; description: string }>) =>
    c.patch<Team>(`/teams/${id}`, body),
  delete: (c: Client, id: string) => c.delete<{ ok: true }>(`/teams/${id}`),
  addMember: (c: Client, id: string, body: { userId: string; role?: "lead" | "member" }) =>
    c.post<{ id: string }>(`/teams/${id}/members`, body),
  removeMember: (c: Client, id: string, userId: string) =>
    c.delete<{ ok: true }>(`/teams/${id}/members/${userId}`),
  workload: (c: Client, id: string) =>
    c.get<{ userId: string; openTasks: number }[]>(`/teams/${id}/workload`),
};
