import { Client } from "../client";

export interface CsvImportResult<T> {
  imported: T[];
  errors: { line: number; reason: string }[];
}

export const csv = {
  importTasks: (c: Client, body: { csv: string }) =>
    c.post<CsvImportResult<{ id: string; key: string; title: string }>>("/csv/tasks/import", body),
  exportTasks: (c: Client, projectId?: string) =>
    c.getRaw(`/csv/tasks/export${projectId ? `?projectId=${projectId}` : ""}`),
  importTickets: (c: Client, body: { csv: string }) =>
    c.post<CsvImportResult<{ id: string; key: string; title: string }>>("/csv/tickets/import", body),
  exportTickets: (c: Client) => c.getRaw("/csv/tickets/export"),
};
