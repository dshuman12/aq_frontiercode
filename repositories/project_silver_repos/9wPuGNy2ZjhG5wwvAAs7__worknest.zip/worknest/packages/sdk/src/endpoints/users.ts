import { Client } from "../client";
import { Organization, User } from "../types";

export const users = {
  me: (c: Client) =>
    c.get<User & { organizations?: Organization[] }>(`/users/me`),
  updateProfile: (c: Client, body: Partial<{ name: string; avatarUrl: string | null; timezone: string; locale: string }>) =>
    c.patch<User>("/users/me", body),
  organizations: (c: Client) => c.get<Organization[]>("/users/me/organizations"),
  setActiveOrg: (c: Client, organizationId: string) =>
    c.post<{ organizationId: string; role: string }>("/users/me/organization/active", { organizationId }),
  byId: (c: Client, id: string) => c.get<User>(`/users/${id}`),
};
