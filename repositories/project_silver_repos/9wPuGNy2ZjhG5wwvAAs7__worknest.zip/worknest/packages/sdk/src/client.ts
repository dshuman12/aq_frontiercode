/**
 * Typed HTTP client used by the web app and any consumers writing
 * scripts against WorkNest. All endpoint helpers are layered on top of
 * this — keep network behaviour in one place.
 */

export interface ClientConfig {
  baseUrl: string;
  token?: () => string | null | Promise<string | null>;
  onUnauthorized?: () => Promise<void> | void;
}

export class ApiError extends Error {
  constructor(
    public status: number,
    public body: unknown,
    message?: string,
  ) {
    super(message ?? `HTTP ${status}`);
    this.name = "ApiError";
  }
}

export class Client {
  constructor(private readonly cfg: ClientConfig) {}

  get baseUrl(): string {
    return this.cfg.baseUrl;
  }

  private async fetchJson<T>(path: string, init: RequestInit & { method?: string } = {}): Promise<T> {
    const token = typeof this.cfg.token === "function" ? await this.cfg.token() : null;
    const headers: Record<string, string> = {
      "content-type": "application/json",
      ...(init.headers as Record<string, string> | undefined),
    };
    if (token) headers.authorization = `Bearer ${token}`;

    const res = await fetch(this.cfg.baseUrl + path, { ...init, headers });
    if (res.status === 401 && this.cfg.onUnauthorized) await this.cfg.onUnauthorized();
    if (!res.ok) {
      let body: unknown = null;
      try { body = await res.json(); } catch {}
      throw new ApiError(res.status, body, (body as { message?: string } | null)?.message);
    }
    if (res.status === 204) return undefined as unknown as T;
    return res.json();
  }

  get<T>(path: string): Promise<T> { return this.fetchJson<T>(path); }
  async getRaw(path: string): Promise<string> {
    const token = typeof this.cfg.token === "function" ? await this.cfg.token() : null;
    const headers: Record<string, string> = {};
    if (token) headers.authorization = `Bearer ${token}`;
    const res = await fetch(this.cfg.baseUrl + path, { headers });
    if (!res.ok) throw new ApiError(res.status, null);
    return res.text();
  }
  post<T>(path: string, body?: unknown): Promise<T> {
    return this.fetchJson<T>(path, { method: "POST", body: body ? JSON.stringify(body) : undefined });
  }
  put<T>(path: string, body?: unknown): Promise<T> {
    return this.fetchJson<T>(path, { method: "PUT", body: body ? JSON.stringify(body) : undefined });
  }
  patch<T>(path: string, body?: unknown): Promise<T> {
    return this.fetchJson<T>(path, { method: "PATCH", body: body ? JSON.stringify(body) : undefined });
  }
  delete<T>(path: string): Promise<T> { return this.fetchJson<T>(path, { method: "DELETE" }); }
}

export function createClient(cfg: ClientConfig): Client {
  return new Client(cfg);
}
