export interface User {
  id: string;
  email: string;
  name: string;
  avatarUrl?: string;
}

export interface Organization {
  id: string;
  name: string;
  slug: string;
  plan: string;
  logoUrl?: string;
  role?: string;
}

export interface Project {
  id: string;
  name: string;
  key: string;
  description?: string | null;
  status: string;
  archivedAt?: string | null;
  createdAt: string;
}

export interface Task {
  id: string;
  projectId: string;
  key: string;
  title: string;
  description?: string | null;
  status: string;
  priority: string;
  assigneeId?: string | null;
  dueAt?: string | null;
  createdAt: string;
  completedAt?: string | null;
}

export interface Ticket {
  id: string;
  key: string;
  title: string;
  status: string;
  priority: string;
  categoryId?: string | null;
  assigneeId?: string | null;
  createdAt: string;
}

export interface RequestSubmission {
  id: string;
  key: string;
  title: string;
  status: string;
  priority: string;
  formId: string | null;
  submitterId: string;
  assigneeId?: string | null;
  createdAt: string;
}

export interface ApprovalDecision {
  id: string;
  workflowId: string;
  stepId: string;
  status: string;
  decision?: string | null;
  reason?: string | null;
  createdAt: string;
  decidedAt?: string | null;
}

export interface AssetRecord {
  id: string;
  tag: string;
  name: string;
  status: string;
  serialNumber?: string;
  warrantyEndsAt?: string;
  assigneeId?: string | null;
}

export interface InventoryItem {
  id: string;
  sku: string;
  name: string;
  unit: string;
  qty: number;
  reorderPoint: number;
}

export interface NotificationItem {
  id: string;
  kind: string;
  title: string;
  body?: string;
  link?: string;
  severity: string;
  occurredAt: string;
  readAt?: string | null;
}

export interface PageOf<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
}
