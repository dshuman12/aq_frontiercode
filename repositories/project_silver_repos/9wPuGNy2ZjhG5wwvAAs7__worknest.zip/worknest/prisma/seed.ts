/**
 * Demo data seeder. Creates a fully populated demo organization so
 * reviewers can poke around without filling forms.
 *
 * Idempotent — re-running wipes the demo org first.
 */

import { hashPassword } from "@worknest/auth";
import { prisma } from "@worknest/database";

const SLUG = "worknest-demo";
const PASSWORD = "demo-password-change-me";

async function main() {
  console.log(`[seed] resetting "${SLUG}"`);
  await reset();

  const passwordHash = await hashPassword(PASSWORD);
  const users = await createUsers(passwordHash);

  console.log("[seed] creating organization");
  const org = await prisma.organization.create({
    data: {
      slug: SLUG,
      name: "WorkNest Demo Co.",
      plan: "team",
      members: {
        create: [
          { userId: users.owner.id, role: "owner" },
          { userId: users.admin.id, role: "admin" },
          { userId: users.manager.id, role: "manager" },
          { userId: users.engineer.id, role: "member" },
          { userId: users.designer.id, role: "member" },
          { userId: users.support.id, role: "member" },
        ],
      },
    },
  });

  console.log("[seed] teams + projects + tasks");
  const eng = await prisma.team.create({
    data: { organizationId: org.id, name: "Engineering", description: "Backend, frontend, infra" },
  });
  const ops = await prisma.team.create({
    data: { organizationId: org.id, name: "Operations", description: "Office, IT, vendors" },
  });
  await prisma.teamMember.createMany({
    data: [
      { teamId: eng.id, userId: users.manager.id, role: "lead" },
      { teamId: eng.id, userId: users.engineer.id, role: "member" },
      { teamId: ops.id, userId: users.support.id, role: "lead" },
    ],
  });

  const launch = await prisma.project.create({
    data: { organizationId: org.id, name: "Q1 Launch", key: "LAUNCH", description: "Marketing site refresh." },
  });
  const ops2 = await prisma.project.create({
    data: { organizationId: org.id, name: "Office Move", key: "MOVE", description: "Cutover from WeWork." },
  });

  for (const project of [launch, ops2]) {
    const board = await prisma.board.create({ data: { projectId: project.id, name: "Default", isDefault: true } });
    const cols = ["Backlog", "In progress", "In review", "Blocked", "Done"];
    for (let i = 0; i < cols.length; i++) {
      await prisma.boardColumn.create({ data: { boardId: board.id, name: cols[i], order: i } });
    }
  }

  const launchBoard = await prisma.board.findFirstOrThrow({
    where: { projectId: launch.id },
    include: { columns: { orderBy: { order: "asc" } } },
  });

  const TASK_FIXTURES = [
    { title: "Audit current onboarding funnel", priority: "high", col: 1, assignee: users.manager.id },
    { title: "Storyboard new welcome screen", priority: "medium", col: 1, assignee: users.designer.id },
    { title: "Migrate marketing CMS", priority: "high", col: 0, assignee: users.engineer.id },
    { title: "Run a11y audit on new landing", priority: "medium", col: 2, assignee: users.designer.id },
    { title: "Block: legal review for new copy", priority: "urgent", col: 3, assignee: users.admin.id },
    { title: "Ship analytics dashboards", priority: "low", col: 4, assignee: users.engineer.id },
    { title: "Schedule launch retrospective", priority: "low", col: 0, assignee: users.manager.id },
  ];

  for (let i = 0; i < TASK_FIXTURES.length; i++) {
    const t = TASK_FIXTURES[i];
    await prisma.task.create({
      data: {
        projectId: launch.id,
        boardColumnId: launchBoard.columns[t.col].id,
        key: `LAUNCH-${i + 1}`,
        title: t.title,
        priority: t.priority,
        assigneeId: t.assignee,
        status: ["todo", "in_progress", "review", "blocked", "done"][t.col],
        dueAt: new Date(Date.now() + (3 + i * 2) * 24 * 60 * 60 * 1000),
        createdById: users.owner.id,
      },
    });
    await prisma.project.update({ where: { id: launch.id }, data: { nextTaskNumber: { increment: 1 } } });
  }

  console.log("[seed] tickets");
  const TICKET_TITLES = [
    "Laptop replacement",
    "VPN access for new contractor",
    "Slack workspace invite",
    "Conference room booking issue",
    "Standing desk for new hire",
    "3 new monitors for design team",
    "Annual Figma renewal",
  ];
  for (let i = 0; i < TICKET_TITLES.length; i++) {
    await prisma.ticket.create({
      data: {
        organizationId: org.id,
        key: `TKT-${i + 1}`,
        title: TICKET_TITLES[i],
        description: `Demo ticket: ${TICKET_TITLES[i]}.`,
        priority: ["low", "medium", "high", "urgent"][i % 4],
        status: ["open", "in_progress", "pending", "resolved", "closed"][i % 5],
        requesterId: users.engineer.id,
        assigneeId: users.support.id,
      },
    });
  }

  console.log("[seed] request form + submissions");
  const form = await prisma.requestForm.create({
    data: {
      organizationId: org.id,
      name: "Equipment request",
      slug: "equipment",
      description: "Order hardware and accessories.",
      visibility: "internal",
      fields: {
        create: [
          { label: "Item", key: "item", type: "text", required: true, order: 0 },
          { label: "Reason", key: "reason", type: "textarea", required: true, order: 1 },
          { label: "Estimated cost (USD)", key: "cost", type: "number", required: false, order: 2 },
        ],
      },
    },
  });
  await prisma.requestSubmission.create({
    data: {
      organizationId: org.id,
      formId: form.id,
      key: "RQ-1",
      title: "Standing desk for new hire",
      submitterId: users.engineer.id,
      assigneeId: users.support.id,
      priority: "medium",
      status: "submitted",
    },
  });

  console.log("[seed] approval workflow");
  const wf = await prisma.approvalWorkflow.create({
    data: {
      organizationId: org.id,
      name: "Equipment > $500",
      appliesTo: "equipment>500",
      enabled: true,
      steps: {
        create: [
          { order: 0, name: "Manager approval", approverId: users.manager.id },
          { order: 1, name: "Finance approval", approverId: users.admin.id, escalateAfterMinutes: 1440 },
        ],
      },
    },
  });

  console.log("[seed] assets + inventory + vendors");
  const dell = await prisma.vendor.create({
    data: { organizationId: org.id, name: "Dell Technologies", category: "hardware" },
  });
  const wh = await prisma.warehouse.create({
    data: { organizationId: org.id, name: "HQ storage" },
  });

  const ASSETS = [
    { tag: "LP-01", name: "Dell XPS 15", assigneeId: users.owner.id, days: 320 },
    { tag: "LP-02", name: "Dell XPS 13", assigneeId: users.admin.id, days: 14 },
    { tag: "MN-01", name: "LG 27\" 4K monitor", assigneeId: users.designer.id, days: 200 },
  ];
  for (const a of ASSETS) {
    await prisma.asset.create({
      data: {
        organizationId: org.id,
        tag: a.tag,
        name: a.name,
        status: a.assigneeId ? "assigned" : "available",
        assigneeId: a.assigneeId,
        vendorId: dell.id,
        warehouseId: wh.id,
        warrantyEndsAt: new Date(Date.now() + a.days * 24 * 60 * 60 * 1000),
        purchaseDate: new Date(Date.now() - (730 - a.days) * 24 * 60 * 60 * 1000),
        costCents: 200_000,
      },
    });
  }

  const INVENTORY = [
    { sku: "USB-C-CABLE", name: "USB-C 1m cable", unit: "pc", qty: 12, reorderPoint: 8 },
    { sku: "DOCK-DELL", name: "Dell WD22TB4 dock", unit: "pc", qty: 2, reorderPoint: 4 },
    { sku: "KB-MX-KEYS", name: "Logitech MX Keys", unit: "pc", qty: 6, reorderPoint: 3 },
  ];
  for (const i of INVENTORY) {
    await prisma.inventoryItem.create({
      data: { organizationId: org.id, ...i, vendorId: dell.id, warehouseId: wh.id },
    });
  }

  console.log("[seed] notifications");
  for (const t of [
    { kind: "task.assigned", title: "MOVE-3 assigned to you", severity: "info" },
    { kind: "approval.pending", title: "Awaiting your approval", severity: "warning" },
    { kind: "asset.warranty", title: "LP-02 warranty ends in 14 days", severity: "warning" },
    { kind: "inventory.low_stock", title: "DOCK-DELL is below reorder point", severity: "warning" },
  ]) {
    await prisma.notification.create({
      data: {
        organizationId: org.id,
        userId: users.owner.id,
        kind: t.kind,
        title: t.title,
        severity: t.severity,
      },
    });
  }

  console.log("[seed] done");
  console.log("");
  console.log(`Sign in at http://localhost:3000`);
  console.log(`  Email:    ${users.owner.email}`);
  console.log(`  Password: ${PASSWORD}`);
}

async function reset() {
  const org = await prisma.organization.findUnique({ where: { slug: SLUG } });
  if (org) await prisma.organization.delete({ where: { id: org.id } });
  await prisma.user.deleteMany({ where: { email: { endsWith: "@worknest-demo.test" } } });
}

async function createUsers(passwordHash: string) {
  const make = (email: string, name: string) =>
    prisma.user.create({ data: { email, name, passwordHash, emailVerifiedAt: new Date() } });
  return {
    owner: await make("alex@worknest-demo.test", "Alex Castillo"),
    admin: await make("priya@worknest-demo.test", "Priya Shah"),
    manager: await make("jordan@worknest-demo.test", "Jordan Park"),
    engineer: await make("sam@worknest-demo.test", "Sam Chen"),
    designer: await make("elena@worknest-demo.test", "Elena Rossi"),
    support: await make("ricky@worknest-demo.test", "Ricky Adeyemi"),
  };
}

main()
  .catch((err) => {
    console.error(err);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
