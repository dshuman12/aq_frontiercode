ARG NODE_VERSION=20.11.0
ARG PNPM_VERSION=8.15.0

FROM node:${NODE_VERSION}-bookworm-slim AS base
RUN corepack enable && corepack prepare pnpm@${PNPM_VERSION} --activate
WORKDIR /repo

FROM base AS deps
COPY pnpm-lock.yaml pnpm-workspace.yaml package.json ./
COPY apps/worker/package.json ./apps/worker/
COPY packages/database/package.json ./packages/database/
COPY packages/email/package.json ./packages/email/
COPY packages/logger/package.json ./packages/logger/
COPY packages/notifications/package.json ./packages/notifications/
RUN pnpm install --frozen-lockfile --filter "@worknest/worker..."

FROM deps AS build
COPY tsconfig*.json ./
COPY apps/worker ./apps/worker/
COPY packages ./packages/
COPY prisma ./prisma/
RUN pnpm --filter @worknest/worker prisma generate
RUN pnpm turbo run build --filter @worknest/worker

FROM base AS prod-deps
COPY pnpm-lock.yaml pnpm-workspace.yaml package.json ./
COPY apps/worker/package.json ./apps/worker/
COPY --from=build /repo/packages/*/package.json ./packages/
RUN pnpm install --frozen-lockfile --prod --filter "@worknest/worker..."

FROM node:${NODE_VERSION}-bookworm-slim AS runtime
RUN groupadd -g 1001 worknest && useradd -u 1001 -g 1001 -m worknest
WORKDIR /app
ENV NODE_ENV=production

COPY --from=prod-deps --chown=worknest:worknest /repo/node_modules /app/node_modules
COPY --from=build --chown=worknest:worknest /repo/packages /app/packages
COPY --from=build --chown=worknest:worknest /repo/apps/worker/dist /app/dist
COPY --from=build --chown=worknest:worknest /repo/apps/worker/package.json /app/package.json
COPY --from=build --chown=worknest:worknest /repo/prisma /app/prisma

USER worknest

CMD ["node", "dist/main.js"]
