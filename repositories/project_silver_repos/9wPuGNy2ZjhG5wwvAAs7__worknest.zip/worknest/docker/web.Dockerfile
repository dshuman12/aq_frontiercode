ARG NODE_VERSION=20.11.0
ARG PNPM_VERSION=8.15.0

FROM node:${NODE_VERSION}-bookworm-slim AS base
RUN corepack enable && corepack prepare pnpm@${PNPM_VERSION} --activate
WORKDIR /repo

FROM base AS deps
COPY pnpm-lock.yaml pnpm-workspace.yaml package.json ./
COPY apps/web/package.json ./apps/web/
COPY packages/sdk/package.json ./packages/sdk/
COPY packages/ui/package.json ./packages/ui/
COPY packages/validators/package.json ./packages/validators/
RUN pnpm install --frozen-lockfile --filter "@worknest/web..."

FROM deps AS build
COPY tsconfig*.json ./
COPY apps/web ./apps/web/
COPY packages ./packages/
ENV NEXT_TELEMETRY_DISABLED=1
RUN pnpm --filter @worknest/web build

FROM node:${NODE_VERSION}-bookworm-slim AS runtime
RUN groupadd -g 1001 worknest && useradd -u 1001 -g 1001 -m worknest
WORKDIR /app
ENV NODE_ENV=production NEXT_TELEMETRY_DISABLED=1

COPY --from=build --chown=worknest:worknest /repo/apps/web/.next/standalone ./
COPY --from=build --chown=worknest:worknest /repo/apps/web/.next/static ./apps/web/.next/static
COPY --from=build --chown=worknest:worknest /repo/apps/web/public ./apps/web/public

USER worknest
EXPOSE 3000

CMD ["node", "apps/web/server.js"]
