ARG NODE_VERSION=20.11.0
ARG PNPM_VERSION=8.15.0

FROM node:${NODE_VERSION}-bookworm-slim AS base
RUN corepack enable && corepack prepare pnpm@${PNPM_VERSION} --activate
WORKDIR /repo

FROM base AS deps
COPY pnpm-lock.yaml pnpm-workspace.yaml package.json ./
COPY apps/api/package.json ./apps/api/
COPY packages/auth/package.json ./packages/auth/
COPY packages/config/package.json ./packages/config/
COPY packages/database/package.json ./packages/database/
COPY packages/email/package.json ./packages/email/
COPY packages/logger/package.json ./packages/logger/
COPY packages/notifications/package.json ./packages/notifications/
COPY packages/permissions/package.json ./packages/permissions/
COPY packages/validators/package.json ./packages/validators/
RUN pnpm install --frozen-lockfile --filter "@worknest/api..."

FROM deps AS build
COPY tsconfig*.json ./
COPY apps/api ./apps/api/
COPY packages ./packages/
COPY prisma ./prisma/
RUN pnpm --filter @worknest/api prisma generate
RUN pnpm turbo run build --filter @worknest/api

FROM base AS prod-deps
COPY pnpm-lock.yaml pnpm-workspace.yaml package.json ./
COPY apps/api/package.json ./apps/api/
COPY --from=build /repo/packages/*/package.json ./packages/
RUN pnpm install --frozen-lockfile --prod --filter "@worknest/api..."

FROM node:${NODE_VERSION}-bookworm-slim AS runtime
RUN groupadd -g 1001 worknest && useradd -u 1001 -g 1001 -m worknest
WORKDIR /app
ENV NODE_ENV=production NODE_OPTIONS="--enable-source-maps"

COPY --from=prod-deps --chown=worknest:worknest /repo/node_modules /app/node_modules
COPY --from=build --chown=worknest:worknest /repo/packages /app/packages
COPY --from=build --chown=worknest:worknest /repo/apps/api/dist /app/dist
COPY --from=build --chown=worknest:worknest /repo/apps/api/package.json /app/package.json
COPY --from=build --chown=worknest:worknest /repo/prisma /app/prisma

USER worknest
EXPOSE 4000

CMD ["node", "dist/main.js"]
