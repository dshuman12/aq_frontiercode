# Changelog

## 0.3.0 — Q2 2025

Major additions in this release:

- **Time tracking** — `TimeEntry` model + start/stop/manual entry endpoints
  + per-task and per-project rollups + web timer page.
- **SLA policies** — per-priority/category targets with first-response and
  resolution timers, pause/resume support, breach sweep worker.
- **Saved views** — persisted filter sets per user (tasks/tickets/requests)
  with shared + default flags.
- **Sprints** — project-scoped iterations with state machine + backlog
  endpoint + add/remove tasks in bulk.
- **Workflow automation** — trigger/action engine with set_status / assign /
  notify / webhook / set_priority / comment actions, condition predicates,
  dry-run test mode.
- **Bulk actions** — tenant-scoped bulk update/delete/labels for tasks
  and bulk update for tickets.
- **Full-text search** — cross-resource ILIKE search across projects, tasks,
  tickets, requests, and clients with unified hit shape.
- **CSV import/export** — RFC 4180 parser/serializer, best-effort import
  with per-line errors, downloadable exports.
- **Activity feed** — `ActivityEvent` org-wide stream with day-grouped
  list component.
- **Caching** — `@worknest/cache` package with LRU + Redis stores,
  stale-while-revalidate wrapper, hit/miss metrics.
- **Task templates + recurring tasks** — reusable shapes + cadence-based
  scheduler with worker tick.
- **Knowledge base** — categories + articles + version history.
- **Mentions + reactions** on comments.
- **Calendar + Gantt** views — synthesized event feeds and project
  timeline computation.
- **Integrations** — Slack outbound, GitHub webhook → ticket, email-to-ticket.
- **SSO + SCIM** — SAML scaffold + SCIM 2.0 user provisioning.
- **PWA + theming + i18n** — manifest, service worker, dark theme hook,
  en/es message catalogs.

## 0.2.0 — Q1 2025

(Initial release with auth, organizations, projects, tasks, tickets,
requests, approvals, assets, inventory, clients, notifications,
reports, billing, audit logs, API keys, webhooks, files, BullMQ
worker, Storybook, e2e suite.)
