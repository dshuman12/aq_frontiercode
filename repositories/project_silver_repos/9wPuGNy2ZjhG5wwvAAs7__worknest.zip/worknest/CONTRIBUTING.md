# Contributing

## Local setup

```bash
pnpm install
docker compose up -d         # Postgres + Redis + mailpit
pnpm prisma migrate deploy
pnpm db:seed
pnpm dev
```

The `dev` script boots the API on `:4000`, the web app on `:3000`,
the worker, and Storybook on `:6006`.

## Workflow

- Fork or branch off `main` (`feat/<short-name>`, `fix/<short-name>`).
- Conventional-ish commits — the changelog is hand-written, not
  parsed, so we just want them readable.
- Tests for any new behaviour. We run vitest in `pnpm test`; e2e
  is `pnpm e2e` (Playwright).
- Run `pnpm lint && pnpm prettier --check .` before opening a PR.

## Project conventions

- Every domain row carries `organizationId`. There are no shared rows
  across organizations.
- `permissions:read` is read-only; mutations always require an
  explicit write permission.
- Schema migrations are reviewed by `@worknest/api-team`; SSO/auth
  changes by `@worknest/security`.
- Worker changes ship in the same PR as their producer if they
  share a queue contract.

## Adding a feature module

1. Add the Prisma model(s) and generate.
2. Add Zod schemas to `@worknest/validators`.
3. Build the service + controller + module under
   `apps/api/src/modules/<feature>`.
4. Wire the module into `apps/api/src/app.module.ts`.
5. Add an SDK section under `packages/sdk/src/endpoints/<feature>.ts`.
6. Add a web page under `apps/web/src/app/(app)/<feature>/page.tsx`.
7. Tests + docs. PRs without tests get a comment, not a block.
