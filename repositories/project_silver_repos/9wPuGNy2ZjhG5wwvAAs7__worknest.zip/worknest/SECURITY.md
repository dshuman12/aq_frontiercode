# Security policy

## Supported versions

We patch the latest minor only. Older versions get advisories but no
fixes.

## Reporting a vulnerability

Please email **security@worknest.dev** with:

- A clear description of the issue and impact.
- Reproduction steps or a proof-of-concept.
- Whether the issue is already public.

Do **not** open a public issue. We aim to acknowledge within 2 business
days and ship a fix or mitigation within 14 days for high-severity
issues.

## Scope

In scope:

- The hosted production endpoints (api.worknest.dev, app.worknest.dev).
- Code in this repository.
- The published `@worknest/*` npm packages.

Out of scope (please don't test):

- Denial-of-service or spam.
- Social engineering against support staff.
- Issues in third-party services we depend on (Stripe, Postmark, etc).

## Hardening notes

- Passwords are argon2id with per-password salt; we never log the
  hash or the plaintext.
- API keys and webhook secrets are stored as SHA-256 hashes only.
- All session cookies are HTTPOnly + Secure + SameSite=Lax.
- The `permissions` package emits `CrossBranchAccess` rather than a
  generic 403 so the UI can produce specific guidance without
  leaking the permission catalog.
