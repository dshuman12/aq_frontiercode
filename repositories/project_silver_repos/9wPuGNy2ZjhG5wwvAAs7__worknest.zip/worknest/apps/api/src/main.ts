import "reflect-metadata";
import { NestFactory } from "@nestjs/core";
import { ValidationPipe } from "@nestjs/common";
import { logger } from "@worknest/logger";
import { AppModule } from "./app.module";

const log = logger("api/bootstrap");

async function bootstrap() {
  const app = await NestFactory.create(AppModule, { bodyParser: true });

  app.setGlobalPrefix("api", { exclude: ["health"] });
  app.useGlobalPipes(new ValidationPipe({ transform: true, whitelist: true }));
  app.enableCors({
    origin: process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000",
    credentials: true,
  });

  const port = Number.parseInt(process.env.PORT ?? "4000", 10);
  await app.listen(port);
  log.info({ port }, "WorkNest API listening");
}

bootstrap().catch((err) => {
  log.error({ err }, "bootstrap failed");
  process.exit(1);
});
