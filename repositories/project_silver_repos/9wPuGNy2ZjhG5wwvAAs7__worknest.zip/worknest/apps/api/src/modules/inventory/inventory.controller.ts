import { Body, Controller, Delete, Get, Param, Patch, Post, Query, UseGuards, UsePipes } from "@nestjs/common";
import { AuthGuard } from "../../common/auth.guard";
import { CurrentOrgId, CurrentUser } from "../../common/current-user.decorator";
import { RequiresPermission } from "../../common/permissions.guard";
import { ZodPipe } from "../../common/zod.pipe";
import {
  CreateInventoryItemSchema,
  CreateVendorSchema,
  CreateWarehouseSchema,
  InventoryTransactionSchema,
  UpdateInventoryItemSchema,
  UpdateVendorSchema,
} from "@worknest/validators";
import { InventoryService } from "./inventory.service";

@UseGuards(AuthGuard)
@Controller("inventory")
export class InventoryController {
  constructor(private readonly inventory: InventoryService) {}

  @Get()
  @RequiresPermission("inventory:read")
  list(
    @CurrentOrgId() orgId: string,
    @Query("warehouseId") warehouseId?: string,
    @Query("vendorId") vendorId?: string,
    @Query("q") q?: string,
  ) {
    return this.inventory.list(orgId, { warehouseId, vendorId, q });
  }

  @Get("low-stock")
  @RequiresPermission("inventory:read")
  lowStock(@CurrentOrgId() orgId: string) {
    return this.inventory.lowStock(orgId);
  }

  @Get(":id")
  @RequiresPermission("inventory:read")
  byId(@Param("id") id: string) {
    return this.inventory.byId(id);
  }

  @Post()
  @RequiresPermission("inventory:create")
  @UsePipes(new ZodPipe(CreateInventoryItemSchema))
  create(@CurrentOrgId() orgId: string, @Body() body: any) {
    return this.inventory.create(orgId, body);
  }

  @Patch(":id")
  @RequiresPermission("inventory:update")
  @UsePipes(new ZodPipe(UpdateInventoryItemSchema))
  update(@Param("id") id: string, @Body() body: any) {
    return this.inventory.update(id, body);
  }

  @Delete(":id")
  @RequiresPermission("inventory:delete")
  remove(@Param("id") id: string) {
    return this.inventory.delete(id);
  }

  @Post("transactions")
  @RequiresPermission("inventory:transactions:write")
  @UsePipes(new ZodPipe(InventoryTransactionSchema))
  recordTransaction(@CurrentUser() u: { sub: string }, @Body() body: any) {
    return this.inventory.applyTransaction({ ...body, actorId: u.sub });
  }

  @Get(":id/transactions")
  @RequiresPermission("inventory:read")
  transactionsFor(
    @Param("id") id: string,
    @Query("page") page?: string,
    @Query("pageSize") pageSize?: string,
  ) {
    return this.inventory.transactionsFor(
      id,
      page ? Number(page) : 1,
      pageSize ? Number(pageSize) : 50,
    );
  }

  @Get("vendors/all")
  @RequiresPermission("vendors:read")
  listVendors(@CurrentOrgId() orgId: string) {
    return this.inventory.listVendors(orgId);
  }

  @Post("vendors")
  @RequiresPermission("vendors:write")
  @UsePipes(new ZodPipe(CreateVendorSchema))
  createVendor(@CurrentOrgId() orgId: string, @Body() body: any) {
    return this.inventory.createVendor(orgId, body);
  }

  @Patch("vendors/:id")
  @RequiresPermission("vendors:write")
  @UsePipes(new ZodPipe(UpdateVendorSchema))
  updateVendor(@Param("id") id: string, @Body() body: any) {
    return this.inventory.updateVendor(id, body);
  }

  @Get("warehouses/all")
  @RequiresPermission("warehouses:read")
  listWarehouses(@CurrentOrgId() orgId: string) {
    return this.inventory.listWarehouses(orgId);
  }

  @Post("warehouses")
  @RequiresPermission("warehouses:write")
  @UsePipes(new ZodPipe(CreateWarehouseSchema))
  createWarehouse(@CurrentOrgId() orgId: string, @Body() body: any) {
    return this.inventory.createWarehouse(orgId, body);
  }
}
