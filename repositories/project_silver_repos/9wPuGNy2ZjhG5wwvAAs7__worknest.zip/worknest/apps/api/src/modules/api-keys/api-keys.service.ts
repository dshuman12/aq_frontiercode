import { Injectable } from "@nestjs/common";
import { generateOpaqueToken, sha256Hex } from "@worknest/auth";
import { prisma } from "@worknest/database";

@Injectable()
export class ApiKeysService {
  async list(organizationId: string) {
    return prisma.apiKey.findMany({
      where: { organizationId, revokedAt: null },
      select: {
        id: true,
        label: true,
        scopes: true,
        lastUsedAt: true,
        createdAt: true,
      },
      orderBy: { createdAt: "desc" },
    });
  }

  async create(input: { organizationId: string; userId: string; label: string; scopes: string; expiresInDays?: number }) {
    const plaintext = `wn_${generateOpaqueToken()}`;
    const tokenHash = sha256Hex(plaintext);
    const row = await prisma.apiKey.create({
      data: {
        organizationId: input.organizationId,
        userId: input.userId,
        label: input.label,
        tokenHash,
        scopes: input.scopes,
      },
    });
    return { row, plaintext };
  }

  async revoke(id: string) {
    await prisma.apiKey.update({
      where: { id },
      data: { revokedAt: new Date() },
    });
    return { ok: true };
  }

  async resolveByPlaintext(plaintext: string) {
    const tokenHash = sha256Hex(plaintext);
    const row = await prisma.apiKey.findUnique({ where: { tokenHash } });
    if (!row || row.revokedAt) return null;
    await prisma.apiKey.update({
      where: { id: row.id },
      data: { lastUsedAt: new Date() },
    });
    return row;
  }
}
