/**
 * The signature check is the security boundary. Test that:
 *   - matching signature → true
 *   - empty / wrong prefix → false
 *   - same length but wrong content → false
 */
import { createHmac } from "node:crypto";
import { describe, expect, it } from "vitest";
import { verifyGithubSignature } from "./github.controller";

const SECRET = "test-secret";
const sign = (body: string) =>
  "sha256=" + createHmac("sha256", SECRET).update(body).digest("hex");

describe("verifyGithubSignature", () => {
  it("accepts a matching signature", () => {
    const body = '{"hello":"world"}';
    expect(verifyGithubSignature(body, sign(body), SECRET)).toBe(true);
  });
  it("rejects when secret missing", () => {
    expect(verifyGithubSignature("x", sign("x"), "")).toBe(false);
  });
  it("rejects empty signature", () => {
    expect(verifyGithubSignature("x", "", SECRET)).toBe(false);
  });
  it("rejects when prefix is wrong", () => {
    expect(verifyGithubSignature("x", "sha1=abcd", SECRET)).toBe(false);
  });
  it("rejects same-length but wrong content", () => {
    const body = "{}";
    const real = sign(body);
    const tampered = "sha256=" + "0".repeat(real.length - "sha256=".length);
    expect(verifyGithubSignature(body, tampered, SECRET)).toBe(false);
  });
});
