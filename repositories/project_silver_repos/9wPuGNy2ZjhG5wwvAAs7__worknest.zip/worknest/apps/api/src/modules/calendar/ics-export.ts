/**
 * Minimal RFC 5545 (.ics) serializer. Subset: VCALENDAR + VEVENT
 * with summary, dtstart, dtend, uid, url. Folded line length per RFC.
 */

interface IcsEvent {
  uid: string;
  summary: string;
  start: Date;
  end: Date;
  url?: string;
}

export function buildIcs(events: IcsEvent[], calendarName = "WorkNest"): string {
  const lines: string[] = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//WorkNest//calendar 1.0//EN",
    `X-WR-CALNAME:${escapeText(calendarName)}`,
  ];
  for (const e of events) {
    lines.push("BEGIN:VEVENT");
    lines.push(`UID:${e.uid}`);
    lines.push(`DTSTAMP:${formatTime(new Date())}`);
    lines.push(`DTSTART:${formatTime(e.start)}`);
    lines.push(`DTEND:${formatTime(e.end)}`);
    lines.push(`SUMMARY:${escapeText(e.summary)}`);
    if (e.url) lines.push(`URL:${e.url}`);
    lines.push("END:VEVENT");
  }
  lines.push("END:VCALENDAR");
  return lines.map(fold).join("\r\n") + "\r\n";
}

function formatTime(d: Date): string {
  const pad = (n: number) => n.toString().padStart(2, "0");
  return (
    d.getUTCFullYear().toString() +
    pad(d.getUTCMonth() + 1) +
    pad(d.getUTCDate()) +
    "T" +
    pad(d.getUTCHours()) +
    pad(d.getUTCMinutes()) +
    pad(d.getUTCSeconds()) +
    "Z"
  );
}

function escapeText(s: string): string {
  return s.replace(/\\/g, "\\\\").replace(/;/g, "\\;").replace(/,/g, "\\,").replace(/\n/g, "\\n");
}

function fold(line: string): string {
  if (line.length <= 75) return line;
  const out: string[] = [];
  let i = 0;
  while (i < line.length) {
    const slice = line.slice(i, i + (i === 0 ? 75 : 74));
    out.push(i === 0 ? slice : " " + slice);
    i += i === 0 ? 75 : 74;
  }
  return out.join("\r\n");
}
