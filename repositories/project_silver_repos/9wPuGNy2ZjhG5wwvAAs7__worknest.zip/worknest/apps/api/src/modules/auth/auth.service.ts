import {
  BadRequestException,
  Injectable,
  UnauthorizedException,
} from "@nestjs/common";
import { prisma } from "@worknest/database";
import {
  generateOpaqueToken,
  generateSecret,
  hashPassword,
  newSession,
  needsRehash,
  sha256Hex,
  signAccessToken,
  signRefreshToken,
  validatePassword,
  verifyPassword,
  verifyRefreshToken,
  verifyTotp,
} from "@worknest/auth";
import { logger } from "@worknest/logger";

const log = logger("api/auth");

const ACCESS_SECRET = () => process.env.JWT_ACCESS_SECRET ?? "dev-only-access-secret";
const REFRESH_SECRET = () => process.env.JWT_REFRESH_SECRET ?? "dev-only-refresh-secret";

@Injectable()
export class AuthService {
  async register(input: {
    email: string;
    password: string;
    name: string;
    organizationName?: string;
  }) {
    const valid = validatePassword(input.password);
    if (!valid.ok) throw new BadRequestException(`weak_password: ${valid.reason}`);

    const existing = await prisma.user.findUnique({ where: { email: input.email } });
    if (existing) throw new BadRequestException("email_taken");

    const passwordHash = await hashPassword(input.password);
    const user = await prisma.$transaction(async (tx) => {
      const u = await tx.user.create({
        data: { email: input.email, name: input.name, passwordHash },
      });
      if (input.organizationName) {
        const slug = `${input.organizationName.toLowerCase().replace(/[^a-z0-9]+/g, "-")}-${u.id.slice(-6)}`;
        const org = await tx.organization.create({
          data: { name: input.organizationName, slug },
        });
        await tx.organizationMember.create({
          data: { organizationId: org.id, userId: u.id, role: "owner" },
        });
      }

      const verifyToken = generateOpaqueToken();
      await tx.emailVerification.create({
        data: {
          userId: u.id,
          tokenHash: sha256Hex(verifyToken),
          expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000),
        },
      });
      log.info({ userId: u.id }, "user registered");
      return u;
    });

    return { id: user.id, email: user.email, name: user.name };
  }

  async login(input: {
    email: string;
    password: string;
    twoFactorCode?: string;
    ip?: string;
    userAgent?: string;
  }) {
    const user = await prisma.user.findUnique({
      where: { email: input.email },
      include: { memberships: { take: 1, orderBy: { joinedAt: "asc" } } },
    });
    if (!user) throw new UnauthorizedException("invalid_credentials");
    const ok = await verifyPassword(input.password, user.passwordHash);
    if (!ok) throw new UnauthorizedException("invalid_credentials");

    if (user.twoFactorEnabled) {
      if (!input.twoFactorCode) throw new UnauthorizedException("totp_required");
      if (!user.twoFactorSecret || !verifyTotp(user.twoFactorSecret, input.twoFactorCode)) {
        throw new UnauthorizedException("totp_invalid");
      }
    }

    if (needsRehash(user.passwordHash)) {
      await prisma.user.update({
        where: { id: user.id },
        data: { passwordHash: await hashPassword(input.password) },
      });
    }

    const session = newSession({ userId: user.id, ip: input.ip, userAgent: input.userAgent });
    const sessionRow = await prisma.session.create({ data: session.row });
    const orgId = user.memberships[0]?.organizationId ?? "";

    return {
      accessToken: signAccessToken({ sub: user.id, orgId, role: user.memberships[0]?.role ?? "member" }, ACCESS_SECRET()),
      refreshToken: signRefreshToken({ sub: user.id, sid: sessionRow.id }, REFRESH_SECRET()),
      sessionToken: session.rawToken,
      user: { id: user.id, email: user.email, name: user.name },
    };
  }

  async refresh(refreshToken: string) {
    let claims;
    try {
      claims = verifyRefreshToken(refreshToken, REFRESH_SECRET());
    } catch {
      throw new UnauthorizedException("invalid_refresh");
    }
    const session = await prisma.session.findUnique({ where: { id: claims.sid } });
    if (!session || session.revokedAt || session.expiresAt < new Date()) {
      throw new UnauthorizedException("session_expired");
    }
    const user = await prisma.user.findUnique({
      where: { id: claims.sub },
      include: { memberships: { take: 1 } },
    });
    if (!user) throw new UnauthorizedException("user_gone");
    const orgId = user.memberships[0]?.organizationId ?? "";
    return {
      accessToken: signAccessToken(
        { sub: user.id, orgId, role: user.memberships[0]?.role ?? "member" },
        ACCESS_SECRET(),
      ),
    };
  }

  async logout(sessionToken: string) {
    const tokenHash = sha256Hex(sessionToken);
    await prisma.session.updateMany({
      where: { tokenHash, revokedAt: null },
      data: { revokedAt: new Date() },
    });
    return { ok: true };
  }

  async listSessions(userId: string) {
    return prisma.session.findMany({
      where: { userId, revokedAt: null, expiresAt: { gt: new Date() } },
      orderBy: { lastSeenAt: "desc" },
    });
  }

  async revokeSession(userId: string, sessionId: string) {
    await prisma.session.updateMany({
      where: { id: sessionId, userId },
      data: { revokedAt: new Date() },
    });
    return { ok: true };
  }

  async requestPasswordReset(email: string) {
    const user = await prisma.user.findUnique({ where: { email } });
    if (!user) return { ok: true }; // don't leak existence
    const token = generateOpaqueToken();
    await prisma.passwordReset.create({
      data: {
        userId: user.id,
        tokenHash: sha256Hex(token),
        expiresAt: new Date(Date.now() + 30 * 60 * 1000),
      },
    });
    log.info({ userId: user.id }, "password reset requested");
    return { ok: true };
  }

  async completePasswordReset(token: string, password: string) {
    const valid = validatePassword(password);
    if (!valid.ok) throw new BadRequestException(`weak_password: ${valid.reason}`);
    const row = await prisma.passwordReset.findUnique({
      where: { tokenHash: sha256Hex(token) },
    });
    if (!row || row.consumedAt || row.expiresAt < new Date()) {
      throw new BadRequestException("invalid_token");
    }
    await prisma.$transaction([
      prisma.user.update({
        where: { id: row.userId },
        data: { passwordHash: await hashPassword(password) },
      }),
      prisma.passwordReset.update({
        where: { id: row.id },
        data: { consumedAt: new Date() },
      }),
      prisma.session.updateMany({
        where: { userId: row.userId, revokedAt: null },
        data: { revokedAt: new Date() },
      }),
    ]);
    return { ok: true };
  }

  async verifyEmail(token: string) {
    const row = await prisma.emailVerification.findUnique({
      where: { tokenHash: sha256Hex(token) },
    });
    if (!row || row.consumedAt || row.expiresAt < new Date()) {
      throw new BadRequestException("invalid_token");
    }
    await prisma.$transaction([
      prisma.user.update({
        where: { id: row.userId },
        data: { emailVerifiedAt: new Date() },
      }),
      prisma.emailVerification.update({
        where: { id: row.id },
        data: { consumedAt: new Date() },
      }),
    ]);
    return { ok: true };
  }

  async beginEnable2fa(userId: string) {
    const secret = generateSecret();
    return { secret };
  }

  async confirmEnable2fa(userId: string, secret: string, code: string) {
    if (!verifyTotp(secret, code)) throw new BadRequestException("totp_invalid");
    await prisma.user.update({
      where: { id: userId },
      data: { twoFactorSecret: secret, twoFactorEnabled: true },
    });
    return { ok: true };
  }

  async disable2fa(userId: string, password: string) {
    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user) throw new UnauthorizedException();
    const ok = await verifyPassword(password, user.passwordHash);
    if (!ok) throw new UnauthorizedException("invalid_password");
    await prisma.user.update({
      where: { id: userId },
      data: { twoFactorSecret: null, twoFactorEnabled: false },
    });
    return { ok: true };
  }
}
