import { Injectable, NotFoundException } from "@nestjs/common";
import { prisma } from "@worknest/database";

@Injectable()
export class BoardsService {
  async forProject(projectId: string) {
    return prisma.board.findMany({
      where: { projectId },
      include: { columns: { orderBy: { order: "asc" } } },
    });
  }

  async byId(id: string) {
    const board = await prisma.board.findUnique({
      where: { id },
      include: { columns: { orderBy: { order: "asc" } } },
    });
    if (!board) throw new NotFoundException();
    return board;
  }

  async create(projectId: string, input: { name: string; isDefault?: boolean }) {
    return prisma.$transaction(async (tx) => {
      if (input.isDefault) {
        await tx.board.updateMany({
          where: { projectId },
          data: { isDefault: false },
        });
      }
      return tx.board.create({
        data: { projectId, name: input.name, isDefault: input.isDefault ?? false },
      });
    });
  }

  async addColumn(boardId: string, input: { name: string; order: number; wipLimit?: number; color?: string }) {
    return prisma.boardColumn.create({ data: { boardId, ...input } });
  }

  async updateColumn(columnId: string, patch: { name?: string; wipLimit?: number; color?: string }) {
    return prisma.boardColumn.update({ where: { id: columnId }, data: patch });
  }

  async removeColumn(columnId: string) {
    await prisma.boardColumn.delete({ where: { id: columnId } });
    return { ok: true };
  }

  async reorder(boardId: string, ordering: { id: string; order: number }[]) {
    await prisma.$transaction(
      ordering.map((o) =>
        prisma.boardColumn.update({
          where: { id: o.id },
          data: { order: o.order },
        }),
      ),
    );
    return this.byId(boardId);
  }
}
