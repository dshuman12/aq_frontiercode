/**
 * Cross-cutting comment behaviors: mention persistence + reactions.
 * The existing tasks/tickets/requests services handle the comment
 * row itself; this service is invoked after the row is created so
 * fan-out logic isn't duplicated three times.
 */
import { ConflictException, Injectable } from "@nestjs/common";
import { prisma } from "@worknest/database";
import { parseMentions } from "./mentions";

@Injectable()
export class CommentsService {
  async recordMentions(args: {
    resource: "task" | "ticket" | "request";
    commentId: string;
    body: string;
    mentionerId: string;
    organizationId: string;
  }): Promise<{ mentioned: number }> {
    const parsed = parseMentions(args.body);
    if (parsed.ids.length === 0 && parsed.handles.length === 0) return { mentioned: 0 };

    const idsExist = parsed.ids.length
      ? await prisma.user.findMany({
          where: { id: { in: parsed.ids } },
          select: { id: true },
        })
      : [];
    const byHandle = parsed.handles.length
      ? await prisma.user.findMany({
          where: {
            email: { in: parsed.handles.map((h) => `${h}@`) },
          },
          select: { id: true },
        })
      : [];
    const userIds = Array.from(new Set([...idsExist.map((u) => u.id), ...byHandle.map((u) => u.id)]));
    if (userIds.length === 0) return { mentioned: 0 };

    await prisma.commentMention.createMany({
      data: userIds.map((mentionedUserId) => ({
        resource: args.resource,
        commentId: args.commentId,
        mentionedUserId,
        mentionerId: args.mentionerId,
      })),
      skipDuplicates: true,
    });
    return { mentioned: userIds.length };
  }

  async react(args: {
    resource: "task" | "ticket" | "request";
    commentId: string;
    userId: string;
    emoji: string;
  }) {
    try {
      await prisma.commentReaction.create({
        data: {
          resource: args.resource,
          commentId: args.commentId,
          userId: args.userId,
          emoji: args.emoji,
        },
      });
      return { added: true };
    } catch (err) {
      // unique constraint — caller toggling on an existing reaction.
      if ((err as { code?: string })?.code === "P2002") {
        await prisma.commentReaction.deleteMany({
          where: { commentId: args.commentId, userId: args.userId, emoji: args.emoji },
        });
        return { removed: true };
      }
      throw err;
    }
  }

  async listReactions(commentId: string) {
    const rows = await prisma.commentReaction.findMany({
      where: { commentId },
    });
    const grouped = new Map<string, string[]>();
    for (const r of rows) {
      const list = grouped.get(r.emoji) ?? [];
      list.push(r.userId);
      grouped.set(r.emoji, list);
    }
    return Array.from(grouped.entries()).map(([emoji, userIds]) => ({
      emoji,
      userIds,
      count: userIds.length,
    }));
  }
}
