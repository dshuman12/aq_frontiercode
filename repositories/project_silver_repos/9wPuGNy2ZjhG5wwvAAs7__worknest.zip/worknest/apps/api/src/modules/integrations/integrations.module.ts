import { Module } from "@nestjs/common";
import { SlackService } from "./slack.service";
import { GithubWebhookController } from "./github.controller";
import { ZapierController } from "./zapier.controller";

@Module({
  controllers: [GithubWebhookController, ZapierController],
  providers: [SlackService],
  exports: [SlackService],
})
export class IntegrationsModule {}
