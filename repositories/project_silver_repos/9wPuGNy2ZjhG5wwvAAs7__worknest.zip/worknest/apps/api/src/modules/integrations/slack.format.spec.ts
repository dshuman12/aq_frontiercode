import { describe, expect, it } from "vitest";
import { digestPayload, slaBreachPayload, ticketCreatedPayload } from "./slack.format";

describe("slack format", () => {
  it("ticketCreatedPayload contains link block", () => {
    const p = ticketCreatedPayload({
      key: "T-1",
      title: "Hello",
      priority: "high",
      url: "https://example.test/tickets/T-1",
      requesterName: "Alex",
    });
    expect(p.text).toContain("T-1");
    expect(p.blocks?.some((b) => JSON.stringify(b).includes("View ticket"))).toBe(true);
  });

  it("slaBreachPayload uses rotating_light icon prefix", () => {
    const p = slaBreachPayload({
      key: "T-2",
      title: "Latency",
      reason: "resolution",
      url: "u",
    });
    expect(p.text.startsWith(":rotating_light:")).toBe(true);
  });

  it("digestPayload includes counts", () => {
    const p = digestPayload({ org: "Acme", openTickets: 3, overdueTasks: 7, url: "u" });
    expect(JSON.stringify(p)).toContain("Open tickets:* 3");
    expect(JSON.stringify(p)).toContain("Overdue tasks:* 7");
  });
});
