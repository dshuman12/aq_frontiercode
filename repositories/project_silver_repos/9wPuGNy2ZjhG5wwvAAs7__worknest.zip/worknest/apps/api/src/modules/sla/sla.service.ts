/**
 * SLA service. A `SlaPolicy` is the configured target ("urgent tickets
 * get a 15-minute first response and 4-hour resolution"); a `SlaTimer`
 * is the per-ticket clock that gets created on ticket open and frozen
 * on resolve/close. Pause + resume support is wired through `pausedAt`
 * + `pausedTotalMinutes` so business-hour breach detection can be
 * layered on later without reshaping the row.
 */
import { ConflictException, Injectable, NotFoundException } from "@nestjs/common";
import { prisma } from "@worknest/database";

@Injectable()
export class SlaService {
  // ── Policies ────────────────────────────────────────────────────────────

  async listPolicies(organizationId: string) {
    return prisma.slaPolicy.findMany({
      where: { organizationId },
      orderBy: [{ active: "desc" }, { priority: "asc" }],
    });
  }

  async createPolicy(args: {
    organizationId: string;
    name: string;
    priority: string;
    categoryId?: string | null;
    firstResponseMinutes: number;
    resolutionMinutes: number;
    businessHoursOnly?: boolean;
    active?: boolean;
  }) {
    const dup = await prisma.slaPolicy.findFirst({
      where: {
        organizationId: args.organizationId,
        priority: args.priority,
        categoryId: args.categoryId ?? null,
      },
    });
    if (dup) throw new ConflictException("policy_for_priority_exists");
    return prisma.slaPolicy.create({
      data: {
        organizationId: args.organizationId,
        name: args.name,
        priority: args.priority,
        categoryId: args.categoryId ?? null,
        firstResponseMinutes: args.firstResponseMinutes,
        resolutionMinutes: args.resolutionMinutes,
        businessHoursOnly: args.businessHoursOnly ?? false,
        active: args.active ?? true,
      },
    });
  }

  async updatePolicy(args: {
    organizationId: string;
    id: string;
    patch: Record<string, unknown>;
  }) {
    const p = await prisma.slaPolicy.findFirst({
      where: { id: args.id, organizationId: args.organizationId },
    });
    if (!p) throw new NotFoundException();
    return prisma.slaPolicy.update({ where: { id: p.id }, data: args.patch });
  }

  async deletePolicy(organizationId: string, id: string) {
    const p = await prisma.slaPolicy.findFirst({
      where: { id, organizationId },
    });
    if (!p) throw new NotFoundException();
    await prisma.slaPolicy.delete({ where: { id: p.id } });
    return { ok: true };
  }

  // ── Timers ──────────────────────────────────────────────────────────────

  async startForTicket(args: { organizationId: string; ticketId: string }) {
    const ticket = await prisma.ticket.findFirst({
      where: { id: args.ticketId, organizationId: args.organizationId },
    });
    if (!ticket) throw new NotFoundException();

    const policy = await this.matchPolicy(args.organizationId, ticket.priority, ticket.categoryId);
    if (!policy) return null;

    const existing = await prisma.slaTimer.findUnique({ where: { ticketId: ticket.id } });
    if (existing) return existing;

    const now = new Date();
    return prisma.slaTimer.create({
      data: {
        ticketId: ticket.id,
        policyId: policy.id,
        firstResponseDueAt: addMinutes(now, policy.firstResponseMinutes),
        resolutionDueAt: addMinutes(now, policy.resolutionMinutes),
      },
    });
  }

  async markFirstResponse(args: { organizationId: string; ticketId: string }) {
    const timer = await this.requireTimer(args.organizationId, args.ticketId);
    if (timer.firstResponseMetAt) return timer;
    return prisma.slaTimer.update({
      where: { id: timer.id },
      data: { firstResponseMetAt: new Date() },
    });
  }

  async markResolved(args: { organizationId: string; ticketId: string; at?: Date }) {
    const timer = await this.requireTimer(args.organizationId, args.ticketId);
    if (timer.resolutionMetAt) return timer;
    const at = args.at ?? new Date();
    return prisma.slaTimer.update({
      where: { id: timer.id },
      data: {
        resolutionMetAt: at,
        firstResponseMetAt: timer.firstResponseMetAt ?? at,
      },
    });
  }

  async pause(args: { organizationId: string; ticketId: string }) {
    const timer = await this.requireTimer(args.organizationId, args.ticketId);
    if (timer.pausedAt) return timer;
    return prisma.slaTimer.update({
      where: { id: timer.id },
      data: { pausedAt: new Date() },
    });
  }

  async resume(args: { organizationId: string; ticketId: string }) {
    const timer = await this.requireTimer(args.organizationId, args.ticketId);
    if (!timer.pausedAt) return timer;
    const minutesPaused = Math.floor(
      (Date.now() - timer.pausedAt.getTime()) / 60_000,
    );
    return prisma.slaTimer.update({
      where: { id: timer.id },
      data: {
        pausedAt: null,
        pausedTotalMinutes: timer.pausedTotalMinutes + minutesPaused,
        firstResponseDueAt: addMinutes(timer.firstResponseDueAt, minutesPaused),
        resolutionDueAt: addMinutes(timer.resolutionDueAt, minutesPaused),
      },
    });
  }

  /** Sweep: re-flag any timers that have crossed their due time without
   *  being met. Idempotent — only flips the breach booleans on, never off. */
  async sweepBreaches(organizationId?: string) {
    const where = organizationId ? { ticket: { organizationId } } : {};
    const timers = await prisma.slaTimer.findMany({
      where: {
        ...where,
        OR: [
          { breachedFirstResponse: false, firstResponseMetAt: null },
          { breachedResolution: false, resolutionMetAt: null },
        ],
      },
    });
    const now = Date.now();
    let flipped = 0;
    for (const t of timers) {
      const updates: Record<string, unknown> = {};
      if (
        !t.breachedFirstResponse &&
        !t.firstResponseMetAt &&
        now > t.firstResponseDueAt.getTime()
      ) {
        updates.breachedFirstResponse = true;
      }
      if (
        !t.breachedResolution &&
        !t.resolutionMetAt &&
        now > t.resolutionDueAt.getTime()
      ) {
        updates.breachedResolution = true;
      }
      if (Object.keys(updates).length) {
        await prisma.slaTimer.update({ where: { id: t.id }, data: updates });
        flipped += 1;
      }
    }
    return { scanned: timers.length, breached: flipped };
  }

  async dashboard(organizationId: string) {
    const open = await prisma.slaTimer.findMany({
      where: {
        ticket: { organizationId, status: { notIn: ["resolved", "closed"] } },
      },
      orderBy: { resolutionDueAt: "asc" },
      take: 100,
      include: {
        ticket: { select: { id: true, key: true, title: true, priority: true, status: true } },
      },
    });
    const breached = open.filter((t) => t.breachedFirstResponse || t.breachedResolution);
    return { open, breached, breachedCount: breached.length };
  }

  // ── Helpers ─────────────────────────────────────────────────────────────

  private async matchPolicy(organizationId: string, priority: string, categoryId: string | null) {
    const exact = await prisma.slaPolicy.findFirst({
      where: { organizationId, priority, categoryId, active: true },
    });
    if (exact) return exact;
    return prisma.slaPolicy.findFirst({
      where: { organizationId, priority, categoryId: null, active: true },
    });
  }

  private async requireTimer(organizationId: string, ticketId: string) {
    const t = await prisma.slaTimer.findUnique({
      where: { ticketId },
      include: { ticket: true },
    });
    if (!t || t.ticket.organizationId !== organizationId) throw new NotFoundException();
    return t;
  }
}

function addMinutes(d: Date, minutes: number): Date {
  return new Date(d.getTime() + minutes * 60_000);
}
