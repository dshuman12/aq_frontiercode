/**
 * Calendar feed. Synthesizes events from existing rows (task due
 * dates, sprint windows, milestone targets) without a dedicated
 * Event table — the dataset is small and rebuilding is fast.
 *
 * Returns events keyed in { id, title, start, end, type } shape so
 * the consumer (web calendar component) doesn't need to know which
 * upstream model produced it.
 */
import { Injectable } from "@nestjs/common";
import { prisma } from "@worknest/database";

export interface CalendarEvent {
  id: string;
  title: string;
  start: Date;
  end: Date;
  type: "task_due" | "sprint" | "milestone";
  link: string;
}

@Injectable()
export class CalendarService {
  async events(args: {
    organizationId: string;
    from: Date;
    to: Date;
    projectId?: string;
  }): Promise<CalendarEvent[]> {
    const projectFilter = args.projectId
      ? { id: args.projectId, organizationId: args.organizationId }
      : { organizationId: args.organizationId };

    const [tasks, sprints, milestones] = await Promise.all([
      prisma.task.findMany({
        where: {
          project: projectFilter,
          dueAt: { gte: args.from, lte: args.to },
        },
        select: { id: true, title: true, dueAt: true, key: true, projectId: true },
      }),
      prisma.sprint.findMany({
        where: {
          project: projectFilter,
          OR: [
            { startsAt: { gte: args.from, lte: args.to } },
            { endsAt: { gte: args.from, lte: args.to } },
          ],
        },
        select: { id: true, name: true, startsAt: true, endsAt: true, projectId: true },
      }),
      prisma.milestone.findMany({
        where: {
          project: projectFilter,
          dueOn: { gte: args.from, lte: args.to },
        },
        select: { id: true, name: true, dueOn: true, projectId: true },
      }),
    ]);

    const events: CalendarEvent[] = [];
    for (const t of tasks) {
      if (!t.dueAt) continue;
      events.push({
        id: `task:${t.id}`,
        title: `${t.key} — ${t.title}`,
        start: t.dueAt,
        end: t.dueAt,
        type: "task_due",
        link: `/tasks/${t.id}`,
      });
    }
    for (const s of sprints) {
      if (!s.startsAt || !s.endsAt) continue;
      events.push({
        id: `sprint:${s.id}`,
        title: `Sprint: ${s.name}`,
        start: s.startsAt,
        end: s.endsAt,
        type: "sprint",
        link: `/projects/${s.projectId}/sprints`,
      });
    }
    for (const m of milestones) {
      if (!m.dueOn) continue;
      events.push({
        id: `milestone:${m.id}`,
        title: `🏁 ${m.name}`,
        start: m.dueOn,
        end: m.dueOn,
        type: "milestone",
        link: `/projects/${m.projectId}`,
      });
    }
    events.sort((a, b) => a.start.getTime() - b.start.getTime());
    return events;
  }
}
