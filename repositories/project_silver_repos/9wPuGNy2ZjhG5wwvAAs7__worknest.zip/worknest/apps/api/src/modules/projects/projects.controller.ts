import { Body, Controller, Delete, Get, Param, Patch, Post, Query, UseGuards, UsePipes } from "@nestjs/common";
import { AuthGuard } from "../../common/auth.guard";
import { CurrentOrgId, CurrentUser } from "../../common/current-user.decorator";
import { RequiresPermission } from "../../common/permissions.guard";
import { ZodPipe } from "../../common/zod.pipe";
import {
  AddProjectMemberSchema,
  CreateMilestoneSchema,
  CreateProjectSchema,
  UpdateMilestoneSchema,
  UpdateProjectSchema,
} from "@worknest/validators";
import { ProjectsService } from "./projects.service";

@UseGuards(AuthGuard)
@Controller("projects")
export class ProjectsController {
  constructor(private readonly projects: ProjectsService) {}

  @Get()
  @RequiresPermission("projects:read")
  list(@CurrentOrgId() orgId: string) {
    return this.projects.list(orgId);
  }

  @Get(":id")
  @RequiresPermission("projects:read")
  byId(@Param("id") id: string) {
    return this.projects.byId(id);
  }

  @Post()
  @RequiresPermission("projects:create")
  @UsePipes(new ZodPipe(CreateProjectSchema))
  create(
    @CurrentOrgId() orgId: string,
    @CurrentUser() u: { sub: string },
    @Body() body: any,
  ) {
    return this.projects.create(orgId, { ...body, createdById: u.sub });
  }

  @Patch(":id")
  @RequiresPermission("projects:update")
  @UsePipes(new ZodPipe(UpdateProjectSchema))
  update(@Param("id") id: string, @Body() body: any) {
    return this.projects.update(id, body);
  }

  @Delete(":id")
  @RequiresPermission("projects:delete")
  remove(@Param("id") id: string) {
    return this.projects.delete(id);
  }

  @Get(":id/members")
  @RequiresPermission("projects:read")
  members(@Param("id") id: string) {
    return this.projects.members(id);
  }

  @Post(":id/members")
  @RequiresPermission("projects:members:add")
  @UsePipes(new ZodPipe(AddProjectMemberSchema))
  addMember(@Param("id") id: string, @Body() body: any) {
    return this.projects.addMember(id, body);
  }

  @Delete(":id/members/:memberId")
  @RequiresPermission("projects:members:remove")
  removeMember(@Param("id") _id: string, @Param("memberId") memberId: string) {
    return this.projects.removeMember(_id, memberId);
  }

  @Get(":id/milestones")
  @RequiresPermission("projects:read")
  listMilestones(@Param("id") id: string) {
    return this.projects.listMilestones(id);
  }

  @Post(":id/milestones")
  @RequiresPermission("projects:update")
  @UsePipes(new ZodPipe(CreateMilestoneSchema))
  createMilestone(@Param("id") id: string, @Body() body: any) {
    return this.projects.createMilestone(id, body);
  }

  @Patch("milestones/:milestoneId")
  @RequiresPermission("projects:update")
  @UsePipes(new ZodPipe(UpdateMilestoneSchema))
  updateMilestone(@Param("milestoneId") id: string, @Body() body: any) {
    return this.projects.updateMilestone(id, body);
  }

  @Delete("milestones/:milestoneId")
  @RequiresPermission("projects:update")
  deleteMilestone(@Param("milestoneId") id: string) {
    return this.projects.deleteMilestone(id);
  }

  @Get(":id/activity")
  @RequiresPermission("projects:read")
  activity(@Param("id") id: string, @Query("limit") limit?: string) {
    return this.projects.listActivity(id, limit ? Number(limit) : 50);
  }
}
