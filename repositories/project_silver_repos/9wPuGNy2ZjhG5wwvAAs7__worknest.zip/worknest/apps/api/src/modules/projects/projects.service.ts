import { Injectable, NotFoundException } from "@nestjs/common";
import { prisma } from "@worknest/database";

const DEFAULT_COLUMNS = [
  { name: "Backlog", order: 0 },
  { name: "In progress", order: 1 },
  { name: "In review", order: 2 },
  { name: "Blocked", order: 3 },
  { name: "Done", order: 4 },
];

@Injectable()
export class ProjectsService {
  async list(organizationId: string) {
    return prisma.project.findMany({
      where: { organizationId },
      orderBy: { createdAt: "desc" },
      include: {
        _count: { select: { tasks: true, milestones: true } },
      },
    });
  }

  async byId(id: string) {
    const project = await prisma.project.findUnique({
      where: { id },
      include: { milestones: { orderBy: { order: "asc" } } },
    });
    if (!project) throw new NotFoundException();
    return project;
  }

  async create(organizationId: string, input: {
    name: string;
    key: string;
    description?: string;
    startsOn?: Date;
    endsOn?: Date;
    createdById?: string;
  }) {
    return prisma.$transaction(async (tx) => {
      const project = await tx.project.create({
        data: {
          organizationId,
          name: input.name,
          key: input.key,
          description: input.description,
          startsOn: input.startsOn,
          endsOn: input.endsOn,
          createdById: input.createdById,
        },
      });
      const board = await tx.board.create({
        data: { projectId: project.id, name: "Default", isDefault: true },
      });
      for (const col of DEFAULT_COLUMNS) {
        await tx.boardColumn.create({
          data: { boardId: board.id, name: col.name, order: col.order },
        });
      }
      return project;
    });
  }

  async update(id: string, patch: Record<string, unknown>) {
    if (patch.archive === true) {
      patch.archivedAt = new Date();
      patch.status = "archived";
      delete patch.archive;
    } else if (patch.archive === false) {
      patch.archivedAt = null;
      patch.status = "active";
      delete patch.archive;
    }
    return prisma.project.update({ where: { id }, data: patch as never });
  }

  async delete(id: string) {
    await prisma.project.delete({ where: { id } });
    return { ok: true };
  }

  async members(projectId: string) {
    return prisma.projectMember.findMany({ where: { projectId } });
  }

  async addMember(projectId: string, input: { userId?: string; teamId?: string; role: string }) {
    return prisma.projectMember.create({
      data: { projectId, ...input },
    });
  }

  async removeMember(projectId: string, memberId: string) {
    await prisma.projectMember.delete({ where: { id: memberId } });
    return { ok: true };
  }

  async listMilestones(projectId: string) {
    return prisma.milestone.findMany({
      where: { projectId },
      orderBy: [{ order: "asc" }, { dueOn: "asc" }],
    });
  }

  async createMilestone(projectId: string, input: { name: string; description?: string; dueOn?: Date }) {
    const lastOrder = await prisma.milestone.aggregate({
      where: { projectId },
      _max: { order: true },
    });
    return prisma.milestone.create({
      data: {
        projectId,
        name: input.name,
        description: input.description,
        dueOn: input.dueOn,
        order: (lastOrder._max.order ?? -1) + 1,
      },
    });
  }

  async updateMilestone(id: string, patch: Record<string, unknown>) {
    if (patch.completed === true) {
      patch.completedAt = new Date();
      delete patch.completed;
    } else if (patch.completed === false) {
      patch.completedAt = null;
      delete patch.completed;
    }
    return prisma.milestone.update({ where: { id }, data: patch as never });
  }

  async deleteMilestone(id: string) {
    await prisma.milestone.delete({ where: { id } });
    return { ok: true };
  }

  async nextTaskNumber(projectId: string): Promise<string> {
    const project = await prisma.project.update({
      where: { id: projectId },
      data: { nextTaskNumber: { increment: 1 } },
      select: { key: true, nextTaskNumber: true },
    });
    return `${project.key}-${project.nextTaskNumber - 1}`;
  }

  async listActivity(projectId: string, limit = 50) {
    return prisma.projectActivity.findMany({
      where: { projectId },
      orderBy: { createdAt: "desc" },
      take: limit,
    });
  }

  async recordActivity(projectId: string, actorId: string | null, type: string, payload?: unknown) {
    return prisma.projectActivity.create({
      data: { projectId, actorId, type, payload: payload as never },
    });
  }
}
