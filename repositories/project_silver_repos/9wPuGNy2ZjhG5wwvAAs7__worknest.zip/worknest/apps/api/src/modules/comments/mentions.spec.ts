import { describe, expect, it } from "vitest";
import { parseMentions } from "./mentions";

describe("parseMentions", () => {
  it("extracts @<id> tokens", () => {
    const out = parseMentions("hi @<user_abc123> please review");
    expect(out.ids).toEqual(["user_abc123"]);
  });

  it("extracts plain @handles", () => {
    const out = parseMentions("@alice can you take this? cc @bob");
    expect(out.handles).toEqual(["alice", "bob"]);
  });

  it("dedupes both forms", () => {
    const out = parseMentions("@alice and @alice meeting with @<u_1> @<u_1>");
    expect(out.ids).toEqual(["u_1"]);
    expect(out.handles).toEqual(["alice"]);
  });

  it("returns empty when nothing matches", () => {
    expect(parseMentions("plain text")).toEqual({ ids: [], handles: [] });
  });
});
