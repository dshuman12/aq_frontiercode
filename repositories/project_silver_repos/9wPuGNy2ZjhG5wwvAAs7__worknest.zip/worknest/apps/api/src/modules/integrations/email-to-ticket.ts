/**
 * Email-to-ticket. Inbound MIME parsing is the responsibility of the
 * mail provider (Postmark inbound, Mailgun routes, etc); this module
 * accepts a normalized payload and maps it to a Ticket. Subject
 * becomes the title; body (text part preferred) becomes the
 * description; the From address becomes the requester (matched by
 * email, fallback to "automation" sentinel for unknowns).
 *
 * We deliberately don't try to parse threaded replies into existing
 * tickets — that lives behind a `messageId` index in a future commit.
 */
import { Injectable } from "@nestjs/common";
import { prisma } from "@worknest/database";

export interface InboundEmail {
  fromEmail: string;
  fromName?: string;
  to: string[];
  subject: string;
  textBody?: string;
  htmlBody?: string;
  messageId?: string;
}

@Injectable()
export class EmailToTicketService {
  /**
   * Map an inbound email to a Ticket. The matching org is the one
   * with an inbox alias matching one of the To addresses.
   */
  async process(email: InboundEmail): Promise<{ ticketId?: string; reason?: string }> {
    const inbox = await this.matchInbox(email.to);
    if (!inbox) return { reason: "no_matching_inbox" };

    const requester = await prisma.user.findFirst({
      where: { email: email.fromEmail.toLowerCase() },
    });

    const description = (email.textBody ?? stripHtml(email.htmlBody ?? "")).slice(0, 20_000);
    const ticket = await prisma.ticket.create({
      data: {
        organizationId: inbox.organizationId,
        key: `EM-${Date.now().toString(36).slice(-6)}`,
        title: email.subject.trim().slice(0, 200) || "(no subject)",
        description,
        priority: "medium",
        status: "open",
        requesterId: requester?.id ?? "automation",
      },
    });
    return { ticketId: ticket.id };
  }

  private async matchInbox(toAddresses: string[]): Promise<{ organizationId: string } | null> {
    // Convention: addresses look like `support+<orgSlug>@worknest.dev`.
    for (const to of toAddresses) {
      const m = /support\+([a-z0-9-]+)@/i.exec(to);
      if (!m) continue;
      const org = await prisma.organization.findUnique({ where: { slug: m[1] } });
      if (org) return { organizationId: org.id };
    }
    return null;
  }
}

export function stripHtml(html: string): string {
  return html
    .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, "")
    .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, "")
    .replace(/<[^>]+>/g, "")
    .replace(/&nbsp;/g, " ")
    .replace(/\s+\n/g, "\n")
    .trim();
}
