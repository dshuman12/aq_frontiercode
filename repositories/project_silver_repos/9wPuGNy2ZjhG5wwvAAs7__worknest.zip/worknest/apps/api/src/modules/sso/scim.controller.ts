/**
 * SCIM 2.0 user provisioning subset. Supports:
 *   - GET    /scim/v2/Users           — list (filter eq email/userName)
 *   - GET    /scim/v2/Users/:id       — get
 *   - POST   /scim/v2/Users           — create (org membership added if absent)
 *   - PATCH  /scim/v2/Users/:id       — soft enable/disable
 *   - DELETE /scim/v2/Users/:id       — soft-deactivate (suspends membership)
 *
 * Auth: a static bearer token configured per org. We extract the org
 * via the bearer's hash matched against ApiKey rows scoped to scope=`scim`.
 */
import { Body, Controller, Delete, Get, Headers, Param, Patch, Post, Query, UnauthorizedException } from "@nestjs/common";
import { createHash } from "node:crypto";
import { prisma } from "@worknest/database";
import { Public } from "../../common/permissions.guard";

@Controller("scim/v2")
export class ScimController {
  @Public()
  @Get("Users")
  async list(
    @Headers("authorization") auth: string,
    @Query("filter") filter?: string,
    @Query("startIndex") startIndex?: string,
    @Query("count") count?: string,
  ) {
    const orgId = await resolveOrg(auth);
    const start = Math.max(1, Number(startIndex ?? 1));
    const take = Math.min(200, Math.max(1, Number(count ?? 20)));
    const where = parseFilter(filter, orgId);
    const [items, total] = await Promise.all([
      prisma.organizationMember.findMany({
        where,
        skip: start - 1,
        take,
        include: { user: true },
      }),
      prisma.organizationMember.count({ where }),
    ]);
    return {
      schemas: ["urn:ietf:params:scim:api:messages:2.0:ListResponse"],
      totalResults: total,
      startIndex: start,
      itemsPerPage: items.length,
      Resources: items.map(toScimUser),
    };
  }

  @Public()
  @Post("Users")
  async create(@Headers("authorization") auth: string, @Body() body: any) {
    const orgId = await resolveOrg(auth);
    const email = (body?.emails?.[0]?.value ?? body?.userName)?.toLowerCase();
    if (!email) throw new Error("missing_email");
    const user = await prisma.user.upsert({
      where: { email },
      update: { name: body?.displayName ?? email },
      create: {
        email,
        name: body?.displayName ?? email,
        passwordHash: "",
        emailVerifiedAt: new Date(),
      },
    });
    const membership = await prisma.organizationMember.upsert({
      where: { organizationId_userId: { organizationId: orgId, userId: user.id } },
      update: { status: "active" },
      create: {
        organizationId: orgId,
        userId: user.id,
        role: "member",
        status: "active",
      },
      include: { user: true },
    });
    return toScimUser(membership);
  }

  @Public()
  @Patch("Users/:id")
  async patch(
    @Headers("authorization") auth: string,
    @Param("id") id: string,
    @Body() body: any,
  ) {
    const orgId = await resolveOrg(auth);
    const ops = (body?.Operations ?? []) as { op: string; path?: string; value?: unknown }[];
    const active = ops.find((o) => o.path === "active")?.value;
    const status = active === false ? "suspended" : "active";
    const membership = await prisma.organizationMember.update({
      where: { organizationId_userId: { organizationId: orgId, userId: id } },
      data: { status },
      include: { user: true },
    });
    return toScimUser(membership);
  }

  @Public()
  @Delete("Users/:id")
  async deactivate(@Headers("authorization") auth: string, @Param("id") id: string) {
    const orgId = await resolveOrg(auth);
    await prisma.organizationMember.update({
      where: { organizationId_userId: { organizationId: orgId, userId: id } },
      data: { status: "suspended" },
    });
    return undefined;
  }
}

async function resolveOrg(authHeader: string | undefined): Promise<string> {
  if (!authHeader?.startsWith("Bearer ")) throw new UnauthorizedException();
  const token = authHeader.slice("Bearer ".length).trim();
  const hash = createHash("sha256").update(token).digest("hex");
  const key = await prisma.apiKey.findFirst({
    where: { tokenHash: hash, scopes: { contains: "scim" } },
  });
  if (!key) throw new UnauthorizedException();
  return key.organizationId;
}

function parseFilter(filter: string | undefined, orgId: string) {
  const where: Record<string, unknown> = { organizationId: orgId };
  if (!filter) return where;
  // very small subset: userName eq "..." | emails.value eq "..."
  const m = /^(userName|emails\.value)\s+eq\s+"([^"]+)"$/i.exec(filter.trim());
  if (m) {
    return { ...where, user: { email: m[2].toLowerCase() } };
  }
  return where;
}

function toScimUser(m: { id: string; userId: string; status: string; user: { email: string; name: string } }) {
  return {
    schemas: ["urn:ietf:params:scim:schemas:core:2.0:User"],
    id: m.userId,
    userName: m.user.email,
    displayName: m.user.name,
    emails: [{ value: m.user.email, primary: true }],
    active: m.status === "active",
  };
}
