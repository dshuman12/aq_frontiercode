/**
 * Cadence math. Pure functions so the worker tick and the create
 * endpoint compute `nextRunAt` the same way. We do *not* try to
 * model timezone-aware DST quirks — `hourOfDay` is interpreted in
 * the schedule's `timezone` for display only; storage is UTC.
 */

interface CadenceInput {
  cadence: "daily" | "weekly" | "monthly";
  interval: number;
  daysOfWeek: number[];
  dayOfMonth?: number | null;
  hourOfDay: number;
}

export function nextRunAt(from: Date, cad: CadenceInput): Date {
  const base = new Date(from.getTime());
  base.setUTCMinutes(0, 0, 0);
  base.setUTCHours(cad.hourOfDay);

  if (cad.cadence === "daily") {
    base.setUTCDate(base.getUTCDate() + Math.max(1, cad.interval));
    return base;
  }
  if (cad.cadence === "weekly") {
    if (cad.daysOfWeek.length === 0) {
      base.setUTCDate(base.getUTCDate() + 7 * Math.max(1, cad.interval));
      return base;
    }
    const sorted = [...cad.daysOfWeek].sort((a, b) => a - b);
    for (let added = 1; added <= 7 * cad.interval + 7; added++) {
      const d = new Date(base.getTime());
      d.setUTCDate(d.getUTCDate() + added);
      if (sorted.includes(d.getUTCDay())) return d;
    }
    return base;
  }
  // monthly
  const day = cad.dayOfMonth ?? base.getUTCDate();
  const target = new Date(base.getTime());
  target.setUTCMonth(target.getUTCMonth() + Math.max(1, cad.interval));
  // clamp to the last day of the target month if needed.
  const lastOfMonth = new Date(
    Date.UTC(target.getUTCFullYear(), target.getUTCMonth() + 1, 0),
  ).getUTCDate();
  target.setUTCDate(Math.min(day, lastOfMonth));
  return target;
}
