import { Injectable, NotFoundException } from "@nestjs/common";
import { generateOpaqueToken } from "@worknest/auth";
import { prisma } from "@worknest/database";

@Injectable()
export class FilesService {
  /**
   * Returns a fake presigned URL. In production this would call S3's
   * SDK; for development we return a path that the local web app will
   * upload to via PUT directly.
   */
  async presign(input: { organizationId: string; uploadedById: string; filename: string; contentType: string; sizeBytes: number }) {
    const storageKey = `org/${input.organizationId}/${generateOpaqueToken().slice(0, 16)}-${input.filename}`;
    return {
      storageKey,
      uploadUrl: `${process.env.S3_PUBLIC_URL ?? "http://localhost:9000"}/${storageKey}`,
      maxBytes: 50 * 1024 * 1024,
      headers: { "content-type": input.contentType },
    };
  }

  async confirm(input: { organizationId: string; uploadedById: string; storageKey: string; filename: string; contentType: string; sizeBytes: bigint; checksumSha256?: string }) {
    return prisma.fileAsset.create({
      data: {
        organizationId: input.organizationId,
        uploadedById: input.uploadedById,
        storageKey: input.storageKey,
        filename: input.filename,
        contentType: input.contentType,
        sizeBytes: input.sizeBytes,
        checksumSha256: input.checksumSha256,
      },
    });
  }

  async byId(id: string) {
    const file = await prisma.fileAsset.findUnique({ where: { id } });
    if (!file) throw new NotFoundException();
    return file;
  }

  async delete(id: string) {
    await prisma.fileAsset.delete({ where: { id } });
    return { ok: true };
  }
}
