import { Controller, Get, Header, Param, UseGuards } from "@nestjs/common";
import { AuthGuard } from "../../common/auth.guard";
import { CurrentOrgId } from "../../common/current-user.decorator";
import { RequiresPermission } from "../../common/permissions.guard";
import { ReportsService } from "./reports.service";

@UseGuards(AuthGuard)
@Controller("reports")
export class ReportsController {
  constructor(private readonly reports: ReportsService) {}

  @Get("overview")
  @RequiresPermission("reports:read")
  overview(@CurrentOrgId() orgId: string) {
    return this.reports.overview(orgId);
  }

  @Get("team-workload")
  @RequiresPermission("reports:read")
  teamWorkload(@CurrentOrgId() orgId: string) {
    return this.reports.teamWorkload(orgId);
  }

  @Get("project/:projectId/progress")
  @RequiresPermission("reports:read")
  projectProgress(@Param("projectId") id: string) {
    return this.reports.projectProgress(id);
  }

  @Get("ticket-sla")
  @RequiresPermission("reports:read")
  ticketSla(@CurrentOrgId() orgId: string) {
    return this.reports.ticketSlaSummary(orgId);
  }

  @Get("tasks.csv")
  @RequiresPermission("reports:export")
  @Header("Content-Type", "text/csv")
  @Header("Content-Disposition", 'attachment; filename="tasks.csv"')
  tasksCsv(@CurrentOrgId() orgId: string) {
    return this.reports.exportTasksCsv(orgId);
  }

  @Get("tickets.csv")
  @RequiresPermission("reports:export")
  @Header("Content-Type", "text/csv")
  @Header("Content-Disposition", 'attachment; filename="tickets.csv"')
  ticketsCsv(@CurrentOrgId() orgId: string) {
    return this.reports.exportTicketsCsv(orgId);
  }
}
