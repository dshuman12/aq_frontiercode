import { Body, Controller, Get, Param, Patch, Post, UseGuards } from "@nestjs/common";
import { AuthGuard } from "../../common/auth.guard";
import { CurrentUser } from "../../common/current-user.decorator";
import { UsersService } from "./users.service";

@UseGuards(AuthGuard)
@Controller("users")
export class UsersController {
  constructor(private readonly users: UsersService) {}

  @Get("me")
  me(@CurrentUser() u: { sub: string }) {
    return this.users.me(u.sub);
  }

  @Patch("me")
  update(@CurrentUser() u: { sub: string }, @Body() body: any) {
    return this.users.updateProfile(u.sub, body);
  }

  @Get("me/organizations")
  organizations(@CurrentUser() u: { sub: string }) {
    return this.users.organizations(u.sub);
  }

  @Post("me/organization/active")
  setActive(@CurrentUser() u: { sub: string }, @Body() body: { organizationId: string }) {
    return this.users.setActiveOrg(u.sub, body.organizationId);
  }

  @Get(":id")
  byId(@Param("id") id: string) {
    return this.users.byId(id);
  }
}
