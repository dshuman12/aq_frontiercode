/**
 * RecurringTask service. CRUD plus a `dueNow` helper used by the
 * worker tick to find schedules that need to fire. The worker is
 * expected to call `applyOnce` for each, which materializes a
 * task and updates `lastRunAt` + `nextRunAt`.
 */
import { Injectable, NotFoundException } from "@nestjs/common";
import { prisma } from "@worknest/database";
import { TaskTemplatesService } from "../task-templates/task-templates.service";
import { nextRunAt } from "./recurrence";

@Injectable()
export class RecurringTasksService {
  constructor(private readonly templates: TaskTemplatesService) {}

  async list(args: { organizationId: string; projectId?: string }) {
    return prisma.recurringTask.findMany({
      where: {
        organizationId: args.organizationId,
        ...(args.projectId ? { projectId: args.projectId } : {}),
      },
      orderBy: { nextRunAt: "asc" },
      include: {
        template: { select: { id: true, name: true } },
        project: { select: { id: true, key: true, name: true } },
      },
    });
  }

  async create(args: {
    organizationId: string;
    input: {
      projectId: string;
      templateId?: string;
      name: string;
      cadence: "daily" | "weekly" | "monthly";
      interval: number;
      daysOfWeek: number[];
      dayOfMonth?: number;
      hourOfDay: number;
      timezone: string;
      startsOn: Date;
    };
  }) {
    return prisma.recurringTask.create({
      data: {
        organizationId: args.organizationId,
        projectId: args.input.projectId,
        templateId: args.input.templateId,
        name: args.input.name,
        cadence: args.input.cadence,
        interval: args.input.interval,
        daysOfWeek: args.input.daysOfWeek,
        dayOfMonth: args.input.dayOfMonth,
        hourOfDay: args.input.hourOfDay,
        timezone: args.input.timezone,
        nextRunAt: args.input.startsOn,
      },
    });
  }

  async update(args: { organizationId: string; id: string; patch: Record<string, unknown> }) {
    const r = await prisma.recurringTask.findFirst({
      where: { id: args.id, organizationId: args.organizationId },
    });
    if (!r) throw new NotFoundException();
    return prisma.recurringTask.update({ where: { id: r.id }, data: args.patch });
  }

  async pause(args: { organizationId: string; id: string; active: boolean }) {
    return this.update({
      organizationId: args.organizationId,
      id: args.id,
      patch: { active: args.active },
    });
  }

  async remove(organizationId: string, id: string) {
    const r = await prisma.recurringTask.findFirst({
      where: { id, organizationId },
    });
    if (!r) throw new NotFoundException();
    await prisma.recurringTask.delete({ where: { id: r.id } });
    return { ok: true };
  }

  async dueNow(now = new Date()): Promise<Array<{ id: string }>> {
    return prisma.recurringTask.findMany({
      where: { active: true, nextRunAt: { lte: now } },
      select: { id: true },
      take: 200,
    });
  }

  async applyOnce(args: { id: string; creatorId: string }): Promise<{ taskId: string }> {
    const r = await prisma.recurringTask.findUnique({ where: { id: args.id } });
    if (!r) throw new NotFoundException();

    const taskId = await prisma.$transaction(async (tx) => {
      let createdTaskId: string;
      if (r.templateId) {
        const task = await this.templates.apply({
          organizationId: r.organizationId,
          templateId: r.templateId,
          creatorId: args.creatorId,
          projectId: r.projectId,
        });
        createdTaskId = task.id;
      } else {
        const next = await tx.project.update({
          where: { id: r.projectId },
          data: { nextTaskNumber: { increment: 1 } },
          select: { key: true, nextTaskNumber: true },
        });
        const t = await tx.task.create({
          data: {
            projectId: r.projectId,
            title: r.name,
            createdById: args.creatorId,
            key: `${next.key}-${next.nextTaskNumber - 1}`,
            position: Date.now(),
          },
        });
        createdTaskId = t.id;
      }

      const newNextRunAt = nextRunAt(new Date(), {
        cadence: r.cadence as "daily" | "weekly" | "monthly",
        interval: r.interval,
        daysOfWeek: r.daysOfWeek,
        dayOfMonth: r.dayOfMonth,
        hourOfDay: r.hourOfDay,
      });
      await tx.recurringTask.update({
        where: { id: r.id },
        data: { lastRunAt: new Date(), nextRunAt: newNextRunAt },
      });
      return createdTaskId;
    });

    return { taskId };
  }
}
