/**
 * Automation rules. Each rule binds a trigger event on a resource
 * (task / ticket / request) to a sequence of actions. The actual
 * dispatch happens out of band: feature modules emit `runRules` calls
 * after writes, and we enqueue any matching rule for the worker to
 * execute. The worker is the only thing that actually mutates state
 * via these rules — the API just stores config and accepts dry-run
 * "test" requests.
 *
 * `condition` evaluation is deliberately small: equality checks on
 * top-level fields, plus `in` membership. More complex predicates
 * belong in the trigger filter (e.g. trigger=status_changed).
 */
import { Injectable, NotFoundException } from "@nestjs/common";
import { prisma } from "@worknest/database";

interface ConditionPredicate {
  field: string;
  op: "eq" | "in" | "ne" | "is_null";
  value?: unknown;
}

@Injectable()
export class AutomationService {
  async list(args: { organizationId: string; resource?: string; trigger?: string }) {
    return prisma.automationRule.findMany({
      where: {
        organizationId: args.organizationId,
        ...(args.resource ? { resource: args.resource } : {}),
        ...(args.trigger ? { trigger: args.trigger } : {}),
      },
      orderBy: [{ active: "desc" }, { createdAt: "desc" }],
      include: { _count: { select: { runs: true } } },
    });
  }

  async create(args: {
    organizationId: string;
    input: {
      name: string;
      resource: string;
      trigger: string;
      condition?: Record<string, unknown> | null;
      actions: unknown;
      active: boolean;
    };
  }) {
    return prisma.automationRule.create({
      data: {
        organizationId: args.organizationId,
        name: args.input.name,
        resource: args.input.resource,
        trigger: args.input.trigger,
        condition: (args.input.condition ?? undefined) as object | undefined,
        actions: args.input.actions as object,
        active: args.input.active,
      },
    });
  }

  async update(args: {
    organizationId: string;
    id: string;
    patch: Record<string, unknown>;
  }) {
    const r = await this.requireRule(args.organizationId, args.id);
    return prisma.automationRule.update({ where: { id: r.id }, data: args.patch });
  }

  async remove(organizationId: string, id: string) {
    const r = await this.requireRule(organizationId, id);
    await prisma.automationRule.delete({ where: { id: r.id } });
    return { ok: true };
  }

  async runs(args: { organizationId: string; ruleId: string; limit?: number }) {
    const r = await this.requireRule(args.organizationId, args.ruleId);
    return prisma.automationRun.findMany({
      where: { ruleId: r.id },
      orderBy: { ranAt: "desc" },
      take: Math.min(200, args.limit ?? 50),
    });
  }

  /**
   * Find rules that match a triggered event. Called from feature
   * modules after writes (e.g. ticket.update calls
   * `automation.matching('ticket', 'status_changed', ticket)`).
   * Honors the per-rule `condition` predicate.
   */
  async matching(args: {
    organizationId: string;
    resource: string;
    trigger: string;
    payload: Record<string, unknown>;
  }) {
    const candidates = await prisma.automationRule.findMany({
      where: {
        organizationId: args.organizationId,
        resource: args.resource,
        trigger: args.trigger,
        active: true,
      },
    });
    return candidates.filter((rule) => evaluateCondition(rule.condition as ConditionPredicate[] | null, args.payload));
  }

  /** Dry-run: evaluate a rule against a real resource without running actions. */
  async test(args: {
    organizationId: string;
    ruleId: string;
    resourceId: string;
  }) {
    const rule = await this.requireRule(args.organizationId, args.ruleId);
    const payload = await this.loadResource(args.organizationId, rule.resource, args.resourceId);
    if (!payload) throw new NotFoundException("resource_not_found");
    const matched = evaluateCondition(rule.condition as ConditionPredicate[] | null, payload);
    return {
      matched,
      actionsThatWouldRun: matched ? rule.actions : [],
      payload,
    };
  }

  private async loadResource(orgId: string, resource: string, resourceId: string): Promise<Record<string, unknown> | null> {
    if (resource === "task") {
      const t = await prisma.task.findUnique({
        where: { id: resourceId },
        include: { project: true },
      });
      if (!t || t.project.organizationId !== orgId) return null;
      return { ...t };
    }
    if (resource === "ticket") {
      return prisma.ticket.findFirst({ where: { id: resourceId, organizationId: orgId } });
    }
    if (resource === "request") {
      return prisma.requestSubmission.findFirst({ where: { id: resourceId, organizationId: orgId } });
    }
    return null;
  }

  private async requireRule(organizationId: string, id: string) {
    const r = await prisma.automationRule.findFirst({
      where: { id, organizationId },
    });
    if (!r) throw new NotFoundException();
    return r;
  }
}

export function evaluateCondition(
  condition: ConditionPredicate[] | null,
  payload: Record<string, unknown>,
): boolean {
  if (!condition || condition.length === 0) return true;
  for (const p of condition) {
    const value = payload[p.field];
    if (p.op === "is_null") {
      if (value !== null && value !== undefined) return false;
      continue;
    }
    if (p.op === "eq" && value !== p.value) return false;
    if (p.op === "ne" && value === p.value) return false;
    if (p.op === "in") {
      if (!Array.isArray(p.value) || !p.value.includes(value)) return false;
    }
  }
  return true;
}
