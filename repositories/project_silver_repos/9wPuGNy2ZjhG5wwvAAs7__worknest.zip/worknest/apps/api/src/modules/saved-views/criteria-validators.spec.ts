import { describe, expect, it } from "vitest";
import { validateCriteria } from "./criteria-validators";

describe("validateCriteria", () => {
  it("accepts known keys per resource", () => {
    expect(validateCriteria("tasks", { status: "todo", priority: "high" })).toEqual({ ok: true });
    expect(validateCriteria("tickets", { categoryId: "abc" })).toEqual({ ok: true });
  });
  it("rejects unknown keys", () => {
    expect(validateCriteria("tasks", { madeUp: 1 })).toEqual({ ok: false, reason: "unknown_key:madeUp" });
  });
  it("rejects non-primitive values", () => {
    expect(validateCriteria("tasks", { status: { eq: "todo" } as unknown as string })).toEqual({
      ok: false,
      reason: "bad_type:status",
    });
  });
  it("accepts arrays of strings", () => {
    expect(validateCriteria("tasks", { labels: ["a", "b"] })).toEqual({ ok: true });
  });
  it("rejects arrays containing objects", () => {
    expect(validateCriteria("tasks", { labels: [{ id: 1 }] as unknown as string[] })).toEqual({
      ok: false,
      reason: "bad_array:labels",
    });
  });
});
