/**
 * Sprints. Time-boxed iteration buckets at the project level.
 *
 * Status transitions (mirrors typical agile boards):
 *   planned   → active | cancelled
 *   active    → completed | cancelled
 *   completed → terminal
 *   cancelled → terminal
 *
 * Only one sprint per project may be `active`. Activating one while
 * another is active is a 409 — operators must explicitly complete
 * the prior sprint first.
 */
import { BadRequestException, ConflictException, Injectable, NotFoundException } from "@nestjs/common";
import { prisma } from "@worknest/database";

const TRANSITIONS: Record<string, string[]> = {
  planned: ["active", "cancelled"],
  active: ["completed", "cancelled"],
  completed: [],
  cancelled: [],
};

@Injectable()
export class SprintsService {
  async list(args: {
    organizationId: string;
    projectId: string;
    status?: string;
  }) {
    await this.requireProject(args.organizationId, args.projectId);
    return prisma.sprint.findMany({
      where: {
        projectId: args.projectId,
        ...(args.status ? { status: args.status } : {}),
      },
      orderBy: [{ status: "asc" }, { startsAt: "desc" }],
      include: { _count: { select: { tasks: true } } },
    });
  }

  async get(args: { organizationId: string; sprintId: string }) {
    const sprint = await this.requireSprint(args.organizationId, args.sprintId);
    const stats = await prisma.task.groupBy({
      by: ["status"],
      where: { sprintId: sprint.id },
      _count: true,
    });
    return { sprint, stats };
  }

  async create(args: {
    organizationId: string;
    input: {
      projectId: string;
      name: string;
      goal?: string;
      startsAt?: Date;
      endsAt?: Date;
    };
  }) {
    await this.requireProject(args.organizationId, args.input.projectId);
    return prisma.sprint.create({
      data: {
        projectId: args.input.projectId,
        name: args.input.name,
        goal: args.input.goal,
        startsAt: args.input.startsAt,
        endsAt: args.input.endsAt,
      },
    });
  }

  async update(args: {
    organizationId: string;
    sprintId: string;
    patch: Record<string, unknown>;
  }) {
    const sprint = await this.requireSprint(args.organizationId, args.sprintId);
    if (sprint.status === "completed" || sprint.status === "cancelled") {
      throw new BadRequestException("sprint_immutable");
    }
    return prisma.sprint.update({ where: { id: sprint.id }, data: args.patch });
  }

  async transition(args: {
    organizationId: string;
    sprintId: string;
    toStatus: string;
  }) {
    const sprint = await this.requireSprint(args.organizationId, args.sprintId);
    const allowed = TRANSITIONS[sprint.status] ?? [];
    if (!allowed.includes(args.toStatus)) {
      throw new BadRequestException({
        message: "invalid_transition",
        from: sprint.status,
        to: args.toStatus,
        allowed,
      });
    }
    if (args.toStatus === "active") {
      const otherActive = await prisma.sprint.findFirst({
        where: {
          projectId: sprint.projectId,
          status: "active",
          id: { not: sprint.id },
        },
      });
      if (otherActive) throw new ConflictException("another_sprint_active");
    }
    const data: Record<string, unknown> = { status: args.toStatus };
    if (args.toStatus === "completed") data.completedAt = new Date();
    return prisma.sprint.update({ where: { id: sprint.id }, data });
  }

  async addTasks(args: {
    organizationId: string;
    sprintId: string;
    taskIds: string[];
  }) {
    const sprint = await this.requireSprint(args.organizationId, args.sprintId);
    const result = await prisma.task.updateMany({
      where: { id: { in: args.taskIds }, projectId: sprint.projectId },
      data: { sprintId: sprint.id },
    });
    return { moved: result.count };
  }

  async removeTasks(args: {
    organizationId: string;
    sprintId: string;
    taskIds: string[];
  }) {
    const sprint = await this.requireSprint(args.organizationId, args.sprintId);
    const result = await prisma.task.updateMany({
      where: { id: { in: args.taskIds }, sprintId: sprint.id },
      data: { sprintId: null },
    });
    return { removed: result.count };
  }

  async backlog(args: {
    organizationId: string;
    projectId: string;
    page?: number;
    pageSize?: number;
  }) {
    await this.requireProject(args.organizationId, args.projectId);
    const page = args.page ?? 1;
    const pageSize = Math.min(200, args.pageSize ?? 50);
    const where = {
      projectId: args.projectId,
      sprintId: null,
      status: { notIn: ["done", "cancelled"] },
    };
    const [items, total] = await Promise.all([
      prisma.task.findMany({
        where,
        skip: (page - 1) * pageSize,
        take: pageSize,
        orderBy: [{ priority: "desc" }, { createdAt: "asc" }],
      }),
      prisma.task.count({ where }),
    ]);
    return { items, total, page, pageSize };
  }

  // ── Helpers ─────────────────────────────────────────────────────────────

  private async requireSprint(organizationId: string, sprintId: string) {
    const sprint = await prisma.sprint.findUnique({
      where: { id: sprintId },
      include: { project: true },
    });
    if (!sprint || sprint.project.organizationId !== organizationId) {
      throw new NotFoundException();
    }
    return sprint;
  }

  private async requireProject(organizationId: string, projectId: string) {
    const project = await prisma.project.findFirst({
      where: { id: projectId, organizationId },
    });
    if (!project) throw new NotFoundException("project_not_found");
    return project;
  }
}
