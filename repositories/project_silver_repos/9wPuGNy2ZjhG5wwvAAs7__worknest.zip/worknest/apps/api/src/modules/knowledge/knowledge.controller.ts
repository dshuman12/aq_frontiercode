import { Body, Controller, Delete, Get, Param, Patch, Post, Query, UseGuards, UsePipes } from "@nestjs/common";
import {
  CreateKnowledgeArticleSchema,
  CreateKnowledgeCategorySchema,
  PublishKnowledgeArticleSchema,
  UpdateKnowledgeArticleSchema,
} from "@worknest/validators";
import { AuthGuard } from "../../common/auth.guard";
import { ZodPipe } from "../../common/zod.pipe";
import { CurrentOrgId, CurrentUser } from "../../common/current-user.decorator";
import { KnowledgeService } from "./knowledge.service";

@UseGuards(AuthGuard)
@Controller("knowledge")
export class KnowledgeController {
  constructor(private readonly knowledge: KnowledgeService) {}

  @Get("categories")
  listCategories(@CurrentOrgId() orgId: string) {
    return this.knowledge.listCategories(orgId);
  }

  @Post("categories")
  @UsePipes(new ZodPipe(CreateKnowledgeCategorySchema))
  createCategory(@CurrentOrgId() orgId: string, @Body() body: any) {
    return this.knowledge.createCategory({ organizationId: orgId, input: body });
  }

  @Get("articles")
  listArticles(
    @CurrentOrgId() orgId: string,
    @Query("categoryId") categoryId?: string,
    @Query("status") status?: string,
    @Query("q") q?: string,
  ) {
    return this.knowledge.listArticles({ organizationId: orgId, categoryId, status, q });
  }

  @Get("articles/:idOrSlug")
  getArticle(@CurrentOrgId() orgId: string, @Param("idOrSlug") idOrSlug: string) {
    return this.knowledge.getArticle({ organizationId: orgId, idOrSlug });
  }

  @Post("articles")
  @UsePipes(new ZodPipe(CreateKnowledgeArticleSchema))
  createArticle(
    @CurrentOrgId() orgId: string,
    @CurrentUser() user: any,
    @Body() body: any,
  ) {
    return this.knowledge.createArticle({
      organizationId: orgId,
      authorId: user.sub,
      input: body,
    });
  }

  @Patch("articles/:id")
  @UsePipes(new ZodPipe(UpdateKnowledgeArticleSchema))
  updateArticle(
    @CurrentOrgId() orgId: string,
    @CurrentUser() user: any,
    @Param("id") id: string,
    @Body() body: any,
  ) {
    return this.knowledge.updateArticle({
      organizationId: orgId,
      authorId: user.sub,
      id,
      patch: body,
    });
  }

  @Post("articles/:id/publish")
  @UsePipes(new ZodPipe(PublishKnowledgeArticleSchema))
  publishArticle(
    @CurrentOrgId() orgId: string,
    @Param("id") id: string,
    @Body() body: { publish: boolean },
  ) {
    return this.knowledge.publishArticle({
      organizationId: orgId,
      id,
      publish: body.publish,
    });
  }

  @Delete("articles/:id")
  deleteArticle(@CurrentOrgId() orgId: string, @Param("id") id: string) {
    return this.knowledge.deleteArticle(orgId, id);
  }
}
