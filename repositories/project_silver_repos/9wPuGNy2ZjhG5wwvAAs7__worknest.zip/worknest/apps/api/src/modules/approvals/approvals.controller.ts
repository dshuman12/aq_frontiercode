import { Body, Controller, Delete, Get, Param, Patch, Post, UseGuards, UsePipes } from "@nestjs/common";
import { AuthGuard } from "../../common/auth.guard";
import { CurrentOrgId, CurrentUser } from "../../common/current-user.decorator";
import { RequiresPermission } from "../../common/permissions.guard";
import { ZodPipe } from "../../common/zod.pipe";
import {
  CreateApprovalWorkflowSchema,
  DecideApprovalSchema,
  ResubmitApprovalSchema,
  UpdateApprovalWorkflowSchema,
} from "@worknest/validators";
import { ApprovalsService } from "./approvals.service";

@UseGuards(AuthGuard)
@Controller("approvals")
export class ApprovalsController {
  constructor(private readonly approvals: ApprovalsService) {}

  @Get("workflows")
  @RequiresPermission("approvals:workflows:read")
  list(@CurrentOrgId() orgId: string) {
    return this.approvals.listWorkflows(orgId);
  }

  @Get("workflows/:id")
  @RequiresPermission("approvals:workflows:read")
  get(@Param("id") id: string) {
    return this.approvals.getWorkflow(id);
  }

  @Post("workflows")
  @RequiresPermission("approvals:workflows:write")
  @UsePipes(new ZodPipe(CreateApprovalWorkflowSchema))
  create(@CurrentOrgId() orgId: string, @Body() body: any) {
    return this.approvals.createWorkflow(orgId, body);
  }

  @Patch("workflows/:id")
  @RequiresPermission("approvals:workflows:write")
  @UsePipes(new ZodPipe(UpdateApprovalWorkflowSchema))
  update(@Param("id") id: string, @Body() body: any) {
    return this.approvals.updateWorkflow(id, body);
  }

  @Delete("workflows/:id")
  @RequiresPermission("approvals:workflows:write")
  remove(@Param("id") id: string) {
    return this.approvals.deleteWorkflow(id);
  }

  @Get("pending")
  @RequiresPermission("approvals:read")
  pending(@CurrentUser() u: { sub: string }, @CurrentOrgId() orgId: string) {
    return this.approvals.pendingFor(u.sub, orgId);
  }

  @Get("decided")
  @RequiresPermission("approvals:read")
  decided(@CurrentUser() u: { sub: string }) {
    return this.approvals.decidedFor(u.sub);
  }

  @Post(":id/decide")
  @RequiresPermission("approvals:decide")
  @UsePipes(new ZodPipe(DecideApprovalSchema))
  decide(
    @CurrentUser() u: { sub: string },
    @Param("id") id: string,
    @Body() body: { decision: "approved" | "rejected"; reason?: string },
  ) {
    return this.approvals.decide(id, u.sub, body.decision, body.reason);
  }

  @Post(":id/resubmit")
  @RequiresPermission("approvals:decide")
  @UsePipes(new ZodPipe(ResubmitApprovalSchema))
  resubmit(@Param("id") id: string, @Body() body: { reason?: string }) {
    return this.approvals.resubmit(id, body.reason);
  }
}
