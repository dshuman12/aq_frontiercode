import { Body, Controller, Get, Header, Post, Query, UseGuards } from "@nestjs/common";
import { AuthGuard } from "../../common/auth.guard";
import { CurrentOrgId, CurrentUser } from "../../common/current-user.decorator";
import { RequiresPermission } from "../../common/permissions.guard";
import { CsvService } from "./csv.service";

@UseGuards(AuthGuard)
@Controller("csv")
export class CsvController {
  constructor(private readonly csv: CsvService) {}

  @Post("tasks/import")
  @RequiresPermission("tasks:create")
  importTasks(
    @CurrentOrgId() orgId: string,
    @CurrentUser() user: any,
    @Body() body: { csv: string },
  ) {
    return this.csv.importTasks({
      organizationId: orgId,
      creatorId: user.sub,
      csv: body.csv ?? "",
    });
  }

  @Get("tasks/export")
  @RequiresPermission("tasks:read")
  @Header("content-type", "text/csv; charset=utf-8")
  @Header("content-disposition", 'attachment; filename="tasks.csv"')
  exportTasks(
    @CurrentOrgId() orgId: string,
    @Query("projectId") projectId?: string,
  ) {
    return this.csv.exportTasks({ organizationId: orgId, projectId });
  }

  @Post("tickets/import")
  @RequiresPermission("tickets:create")
  importTickets(
    @CurrentOrgId() orgId: string,
    @CurrentUser() user: any,
    @Body() body: { csv: string },
  ) {
    return this.csv.importTickets({
      organizationId: orgId,
      requesterId: user.sub,
      csv: body.csv ?? "",
    });
  }

  @Get("tickets/export")
  @RequiresPermission("tickets:read")
  @Header("content-type", "text/csv; charset=utf-8")
  @Header("content-disposition", 'attachment; filename="tickets.csv"')
  exportTickets(@CurrentOrgId() orgId: string) {
    return this.csv.exportTickets({ organizationId: orgId });
  }
}
