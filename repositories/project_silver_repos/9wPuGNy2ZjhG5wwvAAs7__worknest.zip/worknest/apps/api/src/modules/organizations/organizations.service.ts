import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from "@nestjs/common";
import { prisma } from "@worknest/database";
import { hashPassword, verifyPassword } from "@worknest/auth";

@Injectable()
export class OrganizationsService {
  async create(userId: string, input: { name: string; slug: string }) {
    const existing = await prisma.organization.findUnique({ where: { slug: input.slug } });
    if (existing) throw new BadRequestException("slug_taken");
    return prisma.$transaction(async (tx) => {
      const org = await tx.organization.create({ data: input });
      await tx.organizationMember.create({
        data: { organizationId: org.id, userId, role: "owner" },
      });
      return org;
    });
  }

  async byId(id: string) {
    const org = await prisma.organization.findUnique({ where: { id } });
    if (!org) throw new NotFoundException();
    return org;
  }

  async update(id: string, patch: { name?: string; logoUrl?: string | null }) {
    return prisma.organization.update({ where: { id }, data: patch });
  }

  async listMembers(organizationId: string) {
    return prisma.organizationMember.findMany({
      where: { organizationId },
      include: { user: { select: { id: true, name: true, email: true, avatarUrl: true } } },
      orderBy: { joinedAt: "asc" },
    });
  }

  async setRole(organizationId: string, memberUserId: string, role: string) {
    return prisma.organizationMember.update({
      where: { organizationId_userId: { organizationId, userId: memberUserId } },
      data: { role },
    });
  }

  async removeMember(organizationId: string, memberUserId: string) {
    const member = await prisma.organizationMember.findUnique({
      where: { organizationId_userId: { organizationId, userId: memberUserId } },
    });
    if (!member) throw new NotFoundException();
    if (member.role === "owner") throw new BadRequestException("cant_remove_owner");
    await prisma.organizationMember.delete({
      where: { organizationId_userId: { organizationId, userId: memberUserId } },
    });
    return { ok: true };
  }

  async transferOwnership(
    organizationId: string,
    fromUserId: string,
    input: { toUserId: string; password: string },
  ) {
    const me = await prisma.user.findUnique({ where: { id: fromUserId } });
    if (!me) throw new NotFoundException();
    const ok = await verifyPassword(input.password, me.passwordHash);
    if (!ok) throw new ForbiddenException("invalid_password");

    return prisma.$transaction([
      prisma.organizationMember.update({
        where: { organizationId_userId: { organizationId, userId: fromUserId } },
        data: { role: "admin" },
      }),
      prisma.organizationMember.update({
        where: { organizationId_userId: { organizationId, userId: input.toUserId } },
        data: { role: "owner" },
      }),
    ]);
  }

  async stats(organizationId: string) {
    const [members, projects, tasks, tickets] = await Promise.all([
      prisma.organizationMember.count({ where: { organizationId } }),
      prisma.project.count({ where: { organizationId } }),
      prisma.task.count({
        where: { project: { organizationId } },
      }),
      prisma.ticket.count({ where: { organizationId } }),
    ]);
    return { members, projects, tasks, tickets };
  }
}
