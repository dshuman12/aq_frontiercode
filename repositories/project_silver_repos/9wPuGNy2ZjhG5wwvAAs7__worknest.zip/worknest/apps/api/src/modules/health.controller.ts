import { Controller, Get } from "@nestjs/common";
import { Public } from "../common/permissions.guard";

@Controller()
export class HealthController {
  @Public()
  @Get("health")
  ok() {
    return { ok: true, ts: new Date().toISOString() };
  }
}
