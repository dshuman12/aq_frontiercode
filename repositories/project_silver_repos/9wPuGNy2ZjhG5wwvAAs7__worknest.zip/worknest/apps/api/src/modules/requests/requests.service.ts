import { BadRequestException, Injectable, NotFoundException } from "@nestjs/common";
import { prisma } from "@worknest/database";

@Injectable()
export class RequestsService {
  async listForms(organizationId: string) {
    return prisma.requestForm.findMany({
      where: { organizationId, archivedAt: null },
      include: { fields: { orderBy: { order: "asc" } } },
      orderBy: { name: "asc" },
    });
  }

  async getForm(id: string) {
    const form = await prisma.requestForm.findUnique({
      where: { id },
      include: { fields: { orderBy: { order: "asc" } } },
    });
    if (!form) throw new NotFoundException();
    return form;
  }

  async createForm(organizationId: string, input: {
    name: string;
    slug: string;
    description?: string;
    visibility?: string;
    fields: { label: string; key: string; type: string; required?: boolean; config?: unknown; order?: number }[];
  }) {
    return prisma.$transaction(async (tx) => {
      const form = await tx.requestForm.create({
        data: {
          organizationId,
          name: input.name,
          slug: input.slug,
          description: input.description,
          visibility: input.visibility ?? "internal",
        },
      });
      for (const f of input.fields) {
        await tx.requestFormField.create({
          data: {
            formId: form.id,
            label: f.label,
            key: f.key,
            type: f.type,
            required: f.required ?? false,
            config: f.config as never,
            order: f.order ?? 0,
          },
        });
      }
      return form;
    });
  }

  async updateForm(formId: string, patch: Record<string, unknown>) {
    return prisma.requestForm.update({ where: { id: formId }, data: patch as never });
  }

  async archiveForm(formId: string) {
    return prisma.requestForm.update({
      where: { id: formId },
      data: { archivedAt: new Date() },
    });
  }

  async listSubmissions(organizationId: string, filters: { status?: string; formId?: string; assigneeId?: string }) {
    const where: Record<string, unknown> = { organizationId };
    if (filters.status) where.status = filters.status;
    if (filters.formId) where.formId = filters.formId;
    if (filters.assigneeId) where.assigneeId = filters.assigneeId;
    return prisma.requestSubmission.findMany({
      where,
      orderBy: { createdAt: "desc" },
      include: { form: true },
    });
  }

  async getSubmission(id: string) {
    const submission = await prisma.requestSubmission.findUnique({
      where: { id },
      include: {
        form: { include: { fields: true } },
        fieldValues: true,
        comments: { orderBy: { createdAt: "asc" } },
        attachments: true,
        approvals: { orderBy: { createdAt: "asc" } },
      },
    });
    if (!submission) throw new NotFoundException();
    return submission;
  }

  async submit(input: {
    organizationId: string;
    formId: string;
    submitterId: string;
    title: string;
    priority: string;
    fieldValues: Record<string, string>;
    attachmentIds?: string[];
  }) {
    const form = await prisma.requestForm.findUnique({
      where: { id: input.formId },
      include: { fields: true },
    });
    if (!form || form.organizationId !== input.organizationId) {
      throw new NotFoundException("form_not_found");
    }
    const required = form.fields.filter((f) => f.required);
    for (const f of required) {
      if (!input.fieldValues[f.key]) {
        throw new BadRequestException(`missing_required: ${f.key}`);
      }
    }

    const key = await this.allocateKey(input.organizationId);
    return prisma.$transaction(async (tx) => {
      const submission = await tx.requestSubmission.create({
        data: {
          organizationId: input.organizationId,
          formId: input.formId,
          submitterId: input.submitterId,
          title: input.title,
          priority: input.priority,
          key,
        },
      });
      for (const [k, v] of Object.entries(input.fieldValues)) {
        const field = form.fields.find((f) => f.key === k);
        await tx.requestFieldValue.create({
          data: {
            submissionId: submission.id,
            fieldId: field?.id,
            key: k,
            value: v,
          },
        });
      }
      if (input.attachmentIds?.length) {
        for (const fileAssetId of input.attachmentIds) {
          await tx.requestAttachment.create({
            data: { submissionId: submission.id, fileAssetId, uploadedById: input.submitterId },
          });
        }
      }
      return submission;
    });
  }

  async transition(id: string, actorId: string, toStatus: string, note?: string) {
    const submission = await prisma.requestSubmission.findUnique({ where: { id } });
    if (!submission) throw new NotFoundException();
    return prisma.requestSubmission.update({
      where: { id },
      data: {
        status: toStatus,
        resolvedAt: ["approved", "rejected", "closed"].includes(toStatus)
          ? new Date()
          : submission.resolvedAt,
      },
    });
  }

  async assign(id: string, assigneeId: string | null) {
    return prisma.requestSubmission.update({
      where: { id },
      data: { assigneeId },
    });
  }

  async addComment(submissionId: string, authorId: string, body: string, internal: boolean) {
    return prisma.requestComment.create({
      data: { submissionId, authorId, body, internal },
    });
  }

  private async allocateKey(organizationId: string): Promise<string> {
    const count = await prisma.requestSubmission.count({ where: { organizationId } });
    return `RQ-${count + 1}`;
  }
}
