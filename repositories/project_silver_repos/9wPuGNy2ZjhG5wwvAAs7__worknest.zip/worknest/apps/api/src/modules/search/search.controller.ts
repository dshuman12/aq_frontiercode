import { Controller, Get, Query, UseGuards } from "@nestjs/common";
import { AuthGuard } from "../../common/auth.guard";
import { CurrentOrgId } from "../../common/current-user.decorator";
import { SearchService } from "./search.service";

@UseGuards(AuthGuard)
@Controller("search")
export class SearchController {
  constructor(private readonly search: SearchService) {}

  @Get()
  query(
    @CurrentOrgId() orgId: string,
    @Query("q") q: string,
    @Query("limit") limit?: string,
  ) {
    return this.search.search({
      organizationId: orgId,
      q: q ?? "",
      limit: limit ? Number(limit) : undefined,
    });
  }
}
