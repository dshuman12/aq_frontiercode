import { describe, expect, it } from "vitest";
import { buildIcs } from "./ics-export";

describe("buildIcs", () => {
  it("emits BEGIN/END VCALENDAR + VEVENT blocks", () => {
    const ics = buildIcs([
      {
        uid: "u1",
        summary: "Sprint 12",
        start: new Date("2025-07-01T09:00:00Z"),
        end: new Date("2025-07-15T17:00:00Z"),
        url: "https://app/sprints/12",
      },
    ]);
    expect(ics).toContain("BEGIN:VCALENDAR");
    expect(ics).toContain("END:VCALENDAR");
    expect(ics).toContain("BEGIN:VEVENT");
    expect(ics).toContain("END:VEVENT");
    expect(ics).toContain("UID:u1");
    expect(ics).toContain("SUMMARY:Sprint 12");
    expect(ics).toContain("DTSTART:20250701T090000Z");
    expect(ics).toContain("DTEND:20250715T170000Z");
  });
  it("escapes commas and semicolons in summary", () => {
    const ics = buildIcs([
      {
        uid: "u",
        summary: "Hello, world; goodbye",
        start: new Date(0),
        end: new Date(60_000),
      },
    ]);
    expect(ics).toContain("SUMMARY:Hello\\, world\\; goodbye");
  });
});
