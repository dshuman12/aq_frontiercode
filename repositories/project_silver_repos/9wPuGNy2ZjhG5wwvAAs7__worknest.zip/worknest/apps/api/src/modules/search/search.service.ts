/**
 * Cross-resource search. We use simple Postgres `contains` (ILIKE)
 * across the obvious text fields per resource. For a real workload
 * this gets swapped for `pg_trgm` + a GIN index or a dedicated
 * search service — the API surface stays the same so the rewrite
 * is a one-file change.
 *
 * Returns up to `limit` hits per resource type, sorted by recency.
 * Each hit is shaped uniformly so the web app can render a single
 * results list.
 */
import { Injectable } from "@nestjs/common";
import { prisma } from "@worknest/database";

export interface SearchHit {
  resource: "project" | "task" | "ticket" | "request" | "client";
  id: string;
  title: string;
  subtitle?: string;
  url: string;
  updatedAt?: Date;
}

@Injectable()
export class SearchService {
  async search(args: { organizationId: string; q: string; limit?: number }) {
    const q = args.q.trim();
    if (!q) return { hits: [], total: 0 };
    const limit = Math.min(20, args.limit ?? 10);
    const pattern = q;

    const [projects, tasks, tickets, requests, clients] = await Promise.all([
      prisma.project.findMany({
        where: {
          organizationId: args.organizationId,
          OR: [
            { name: { contains: pattern, mode: "insensitive" } },
            { key: { contains: pattern, mode: "insensitive" } },
            { description: { contains: pattern, mode: "insensitive" } },
          ],
        },
        take: limit,
        orderBy: { updatedAt: "desc" },
        select: { id: true, name: true, key: true, updatedAt: true },
      }),
      prisma.task.findMany({
        where: {
          project: { organizationId: args.organizationId },
          OR: [
            { title: { contains: pattern, mode: "insensitive" } },
            { description: { contains: pattern, mode: "insensitive" } },
            { key: { contains: pattern, mode: "insensitive" } },
          ],
        },
        take: limit,
        orderBy: { updatedAt: "desc" },
        select: {
          id: true,
          key: true,
          title: true,
          status: true,
          updatedAt: true,
          projectId: true,
        },
      }),
      prisma.ticket.findMany({
        where: {
          organizationId: args.organizationId,
          OR: [
            { title: { contains: pattern, mode: "insensitive" } },
            { description: { contains: pattern, mode: "insensitive" } },
            { key: { contains: pattern, mode: "insensitive" } },
          ],
        },
        take: limit,
        orderBy: { updatedAt: "desc" },
        select: { id: true, key: true, title: true, status: true, updatedAt: true },
      }),
      prisma.requestSubmission.findMany({
        where: {
          organizationId: args.organizationId,
          OR: [
            { title: { contains: pattern, mode: "insensitive" } },
            { key: { contains: pattern, mode: "insensitive" } },
          ],
        },
        take: limit,
        orderBy: { updatedAt: "desc" },
        select: { id: true, title: true, key: true, status: true, updatedAt: true },
      }),
      prisma.client.findMany({
        where: {
          organizationId: args.organizationId,
          OR: [
            { name: { contains: pattern, mode: "insensitive" } },
            { industry: { contains: pattern, mode: "insensitive" } },
          ],
        },
        take: limit,
        orderBy: { createdAt: "desc" },
        select: { id: true, name: true, industry: true, createdAt: true },
      }),
    ]);

    const hits: SearchHit[] = [
      ...projects.map((p) => ({
        resource: "project" as const,
        id: p.id,
        title: p.name,
        subtitle: p.key,
        url: `/projects/${p.id}`,
        updatedAt: p.updatedAt,
      })),
      ...tasks.map((t) => ({
        resource: "task" as const,
        id: t.id,
        title: `${t.key} — ${t.title}`,
        subtitle: t.status,
        url: `/tasks/${t.id}`,
        updatedAt: t.updatedAt,
      })),
      ...tickets.map((t) => ({
        resource: "ticket" as const,
        id: t.id,
        title: `${t.key} — ${t.title}`,
        subtitle: t.status,
        url: `/tickets/${t.id}`,
        updatedAt: t.updatedAt,
      })),
      ...requests.map((r) => ({
        resource: "request" as const,
        id: r.id,
        title: r.title,
        subtitle: `${r.key} · ${r.status}`,
        url: `/requests/${r.id}`,
        updatedAt: r.updatedAt,
      })),
      ...clients.map((c) => ({
        resource: "client" as const,
        id: c.id,
        title: c.name,
        subtitle: c.industry ?? undefined,
        url: `/clients/${c.id}`,
        updatedAt: c.createdAt,
      })),
    ];

    hits.sort((a, b) => (b.updatedAt?.getTime() ?? 0) - (a.updatedAt?.getTime() ?? 0));
    return { hits: hits.slice(0, limit * 3), total: hits.length };
  }
}
