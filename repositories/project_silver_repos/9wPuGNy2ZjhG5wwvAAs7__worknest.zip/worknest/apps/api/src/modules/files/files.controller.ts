import { Body, Controller, Delete, Get, Param, Post, UseGuards } from "@nestjs/common";
import { AuthGuard } from "../../common/auth.guard";
import { CurrentOrgId, CurrentUser } from "../../common/current-user.decorator";
import { RequiresPermission } from "../../common/permissions.guard";
import { FilesService } from "./files.service";

@UseGuards(AuthGuard)
@Controller("files")
export class FilesController {
  constructor(private readonly files: FilesService) {}

  @Post("presign")
  @RequiresPermission("files:upload")
  presign(
    @CurrentOrgId() orgId: string,
    @CurrentUser() u: { sub: string },
    @Body() body: { filename: string; contentType: string; sizeBytes: number },
  ) {
    return this.files.presign({ ...body, organizationId: orgId, uploadedById: u.sub });
  }

  @Post("confirm")
  @RequiresPermission("files:upload")
  confirm(
    @CurrentOrgId() orgId: string,
    @CurrentUser() u: { sub: string },
    @Body() body: { storageKey: string; filename: string; contentType: string; sizeBytes: number; checksumSha256?: string },
  ) {
    return this.files.confirm({
      ...body,
      organizationId: orgId,
      uploadedById: u.sub,
      sizeBytes: BigInt(body.sizeBytes),
    });
  }

  @Get(":id")
  @RequiresPermission("files:read")
  byId(@Param("id") id: string) {
    return this.files.byId(id);
  }

  @Delete(":id")
  @RequiresPermission("files:delete")
  remove(@Param("id") id: string) {
    return this.files.delete(id);
  }
}
