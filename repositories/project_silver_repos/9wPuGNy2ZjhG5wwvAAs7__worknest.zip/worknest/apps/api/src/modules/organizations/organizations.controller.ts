import { Body, Controller, Delete, Get, Param, Patch, Post, UseGuards, UsePipes } from "@nestjs/common";
import { AuthGuard } from "../../common/auth.guard";
import { CurrentOrgId, CurrentUser } from "../../common/current-user.decorator";
import { RequiresPermission } from "../../common/permissions.guard";
import { ZodPipe } from "../../common/zod.pipe";
import {
  CreateOrganizationSchema,
  TransferOwnershipSchema,
  UpdateMemberSchema,
  UpdateOrganizationSchema,
} from "@worknest/validators";
import { OrganizationsService } from "./organizations.service";

@UseGuards(AuthGuard)
@Controller("organizations")
export class OrganizationsController {
  constructor(private readonly orgs: OrganizationsService) {}

  @Post()
  @UsePipes(new ZodPipe(CreateOrganizationSchema))
  create(@CurrentUser() u: { sub: string }, @Body() body: any) {
    return this.orgs.create(u.sub, body);
  }

  @Get("current")
  current(@CurrentOrgId() orgId: string) {
    return this.orgs.byId(orgId);
  }

  @Get("current/stats")
  @RequiresPermission("org:read")
  stats(@CurrentOrgId() orgId: string) {
    return this.orgs.stats(orgId);
  }

  @Patch("current")
  @RequiresPermission("org:update")
  @UsePipes(new ZodPipe(UpdateOrganizationSchema))
  update(@CurrentOrgId() orgId: string, @Body() body: any) {
    return this.orgs.update(orgId, body);
  }

  @Get("current/members")
  @RequiresPermission("members:read")
  members(@CurrentOrgId() orgId: string) {
    return this.orgs.listMembers(orgId);
  }

  @Patch("current/members/:userId")
  @RequiresPermission("members:role:assign")
  @UsePipes(new ZodPipe(UpdateMemberSchema))
  setRole(@CurrentOrgId() orgId: string, @Param("userId") userId: string, @Body() body: { role: string }) {
    return this.orgs.setRole(orgId, userId, body.role);
  }

  @Delete("current/members/:userId")
  @RequiresPermission("members:remove")
  removeMember(@CurrentOrgId() orgId: string, @Param("userId") userId: string) {
    return this.orgs.removeMember(orgId, userId);
  }

  @Post("current/transfer-ownership")
  @UsePipes(new ZodPipe(TransferOwnershipSchema))
  transferOwnership(
    @CurrentOrgId() orgId: string,
    @CurrentUser() u: { sub: string },
    @Body() body: any,
  ) {
    return this.orgs.transferOwnership(orgId, u.sub, body);
  }
}
