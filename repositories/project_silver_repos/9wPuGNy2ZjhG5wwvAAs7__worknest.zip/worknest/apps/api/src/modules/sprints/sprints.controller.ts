import { Body, Controller, Get, Param, Patch, Post, Query, UseGuards, UsePipes } from "@nestjs/common";
import {
  CreateSprintSchema,
  SprintTaskMoveSchema,
  TransitionSprintSchema,
  UpdateSprintSchema,
} from "@worknest/validators";
import { AuthGuard } from "../../common/auth.guard";
import { ZodPipe } from "../../common/zod.pipe";
import { CurrentOrgId } from "../../common/current-user.decorator";
import { RequiresPermission } from "../../common/permissions.guard";
import { SprintsService } from "./sprints.service";

@UseGuards(AuthGuard)
@Controller("sprints")
export class SprintsController {
  constructor(private readonly sprints: SprintsService) {}

  @Get()
  @RequiresPermission("projects:read")
  list(
    @CurrentOrgId() orgId: string,
    @Query("projectId") projectId: string,
    @Query("status") status?: string,
  ) {
    return this.sprints.list({ organizationId: orgId, projectId, status });
  }

  @Get("backlog")
  @RequiresPermission("tasks:read")
  backlog(
    @CurrentOrgId() orgId: string,
    @Query("projectId") projectId: string,
    @Query("page") page?: string,
    @Query("pageSize") pageSize?: string,
  ) {
    return this.sprints.backlog({
      organizationId: orgId,
      projectId,
      page: page ? Number(page) : undefined,
      pageSize: pageSize ? Number(pageSize) : undefined,
    });
  }

  @Get(":id")
  @RequiresPermission("projects:read")
  get(@CurrentOrgId() orgId: string, @Param("id") id: string) {
    return this.sprints.get({ organizationId: orgId, sprintId: id });
  }

  @Post()
  @RequiresPermission("projects:update")
  @UsePipes(new ZodPipe(CreateSprintSchema))
  create(@CurrentOrgId() orgId: string, @Body() body: any) {
    return this.sprints.create({ organizationId: orgId, input: body });
  }

  @Patch(":id")
  @RequiresPermission("projects:update")
  @UsePipes(new ZodPipe(UpdateSprintSchema))
  update(
    @CurrentOrgId() orgId: string,
    @Param("id") id: string,
    @Body() body: any,
  ) {
    return this.sprints.update({
      organizationId: orgId,
      sprintId: id,
      patch: body,
    });
  }

  @Post(":id/transition")
  @RequiresPermission("projects:update")
  @UsePipes(new ZodPipe(TransitionSprintSchema))
  transition(
    @CurrentOrgId() orgId: string,
    @Param("id") id: string,
    @Body() body: { toStatus: string },
  ) {
    return this.sprints.transition({
      organizationId: orgId,
      sprintId: id,
      toStatus: body.toStatus,
    });
  }

  @Post(":id/tasks")
  @RequiresPermission("tasks:move")
  @UsePipes(new ZodPipe(SprintTaskMoveSchema))
  addTasks(
    @CurrentOrgId() orgId: string,
    @Param("id") id: string,
    @Body() body: { taskIds: string[] },
  ) {
    return this.sprints.addTasks({
      organizationId: orgId,
      sprintId: id,
      taskIds: body.taskIds,
    });
  }

  @Post(":id/tasks/remove")
  @RequiresPermission("tasks:move")
  @UsePipes(new ZodPipe(SprintTaskMoveSchema))
  removeTasks(
    @CurrentOrgId() orgId: string,
    @Param("id") id: string,
    @Body() body: { taskIds: string[] },
  ) {
    return this.sprints.removeTasks({
      organizationId: orgId,
      sprintId: id,
      taskIds: body.taskIds,
    });
  }
}
