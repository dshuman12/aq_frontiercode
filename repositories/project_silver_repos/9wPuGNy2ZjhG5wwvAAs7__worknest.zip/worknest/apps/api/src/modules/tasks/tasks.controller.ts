import { Body, Controller, Delete, Get, Param, Patch, Post, Query, UseGuards, UsePipes } from "@nestjs/common";
import { AuthGuard } from "../../common/auth.guard";
import { CurrentOrgId, CurrentUser } from "../../common/current-user.decorator";
import { RequiresPermission } from "../../common/permissions.guard";
import { ZodPipe } from "../../common/zod.pipe";
import {
  AddChecklistItemSchema,
  AddCommentSchema,
  AddDependencySchema,
  AssignTaskSchema,
  CreateChecklistSchema,
  CreateCustomFieldSchema,
  CreateTaskSchema,
  MoveTaskSchema,
  UpdateChecklistItemSchema,
  UpdateTaskSchema,
} from "@worknest/validators";
import { TasksService } from "./tasks.service";

@UseGuards(AuthGuard)
@Controller("tasks")
export class TasksController {
  constructor(private readonly tasks: TasksService) {}

  @Get()
  @RequiresPermission("tasks:read")
  list(
    @CurrentOrgId() orgId: string,
    @Query("projectId") projectId?: string,
    @Query("assigneeId") assigneeId?: string,
    @Query("status") status?: string,
    @Query("priority") priority?: string,
    @Query("q") q?: string,
    @Query("page") page?: string,
    @Query("pageSize") pageSize?: string,
  ) {
    return this.tasks.list({
      organizationId: orgId,
      projectId,
      assigneeId,
      status,
      priority,
      q,
      page: page ? Number(page) : undefined,
      pageSize: pageSize ? Number(pageSize) : undefined,
    });
  }

  @Get("labels")
  @RequiresPermission("tasks:read")
  labels(@CurrentOrgId() orgId: string) {
    return this.tasks.listLabels(orgId);
  }

  @Get("custom-fields")
  @RequiresPermission("tasks:read")
  customFields(@CurrentOrgId() orgId: string) {
    return this.tasks.listCustomFields(orgId);
  }

  @Post("custom-fields")
  @RequiresPermission("tasks:custom-fields:write")
  @UsePipes(new ZodPipe(CreateCustomFieldSchema))
  createCustomField(@CurrentOrgId() orgId: string, @Body() body: any) {
    return this.tasks.createCustomField(orgId, body);
  }

  @Get(":id")
  @RequiresPermission("tasks:read")
  byId(@Param("id") id: string) {
    return this.tasks.byId(id);
  }

  @Post()
  @RequiresPermission("tasks:create")
  @UsePipes(new ZodPipe(CreateTaskSchema))
  create(@CurrentUser() u: { sub: string }, @Body() body: any) {
    return this.tasks.create({ ...body, createdById: u.sub });
  }

  @Patch(":id")
  @RequiresPermission("tasks:update")
  @UsePipes(new ZodPipe(UpdateTaskSchema))
  update(@CurrentUser() u: { sub: string }, @Param("id") id: string, @Body() body: any) {
    return this.tasks.update(id, u.sub, body);
  }

  @Delete(":id")
  @RequiresPermission("tasks:delete")
  remove(@CurrentUser() u: { sub: string }, @Param("id") id: string) {
    return this.tasks.remove(id, u.sub);
  }

  @Post(":id/move")
  @RequiresPermission("tasks:move")
  @UsePipes(new ZodPipe(MoveTaskSchema))
  move(@CurrentUser() u: { sub: string }, @Param("id") id: string, @Body() body: any) {
    return this.tasks.move(id, u.sub, body.boardColumnId, body.position);
  }

  @Post(":id/assign")
  @RequiresPermission("tasks:assign")
  @UsePipes(new ZodPipe(AssignTaskSchema))
  assign(@CurrentUser() u: { sub: string }, @Param("id") id: string, @Body() body: { userId: string | null }) {
    return this.tasks.assign(id, u.sub, body.userId);
  }

  @Post(":id/comments")
  @RequiresPermission("tasks:comment")
  @UsePipes(new ZodPipe(AddCommentSchema))
  addComment(@CurrentUser() u: { sub: string }, @Param("id") id: string, @Body() body: { body: string }) {
    return this.tasks.addComment(id, u.sub, body.body);
  }

  @Post(":id/dependencies")
  @RequiresPermission("tasks:depend")
  @UsePipes(new ZodPipe(AddDependencySchema))
  addDep(@Param("id") id: string, @Body() body: { blockerId: string; type?: string }) {
    return this.tasks.addDependency(id, body.blockerId, body.type);
  }

  @Delete(":id/dependencies/:blockerId")
  @RequiresPermission("tasks:depend")
  removeDep(@Param("id") id: string, @Param("blockerId") blockerId: string) {
    return this.tasks.removeDependency(id, blockerId);
  }

  @Post(":id/checklists")
  @RequiresPermission("tasks:update")
  @UsePipes(new ZodPipe(CreateChecklistSchema))
  addChecklist(@Param("id") id: string, @Body() body: { title: string }) {
    return this.tasks.addChecklist(id, body.title);
  }

  @Post("checklists/:checklistId/items")
  @RequiresPermission("tasks:update")
  @UsePipes(new ZodPipe(AddChecklistItemSchema))
  addChecklistItem(@Param("checklistId") id: string, @Body() body: { text: string }) {
    return this.tasks.addChecklistItem(id, body.text);
  }

  @Patch("checklists/items/:itemId")
  @RequiresPermission("tasks:update")
  @UsePipes(new ZodPipe(UpdateChecklistItemSchema))
  updateChecklistItem(@Param("itemId") id: string, @Body() body: any) {
    return this.tasks.updateChecklistItem(id, body);
  }

  @Delete("checklists/items/:itemId")
  @RequiresPermission("tasks:update")
  deleteChecklistItem(@Param("itemId") id: string) {
    return this.tasks.deleteChecklistItem(id);
  }

  @Post(":id/custom-fields/:fieldId")
  @RequiresPermission("tasks:custom-fields:write")
  setCustomField(
    @Param("id") taskId: string,
    @Param("fieldId") fieldId: string,
    @Body() body: { value: unknown },
  ) {
    return this.tasks.setCustomFieldValue(taskId, fieldId, body.value);
  }
}
