import { Body, Controller, Delete, Get, Param, Patch, Post, UseGuards, UsePipes } from "@nestjs/common";
import { AuthGuard } from "../../common/auth.guard";
import { RequiresPermission } from "../../common/permissions.guard";
import { ZodPipe } from "../../common/zod.pipe";
import { CreateBoardSchema, CreateColumnSchema, ReorderColumnsSchema } from "@worknest/validators";
import { BoardsService } from "./boards.service";

@UseGuards(AuthGuard)
@Controller("boards")
export class BoardsController {
  constructor(private readonly boards: BoardsService) {}

  @Get("by-project/:projectId")
  @RequiresPermission("boards:read")
  forProject(@Param("projectId") id: string) {
    return this.boards.forProject(id);
  }

  @Get(":id")
  @RequiresPermission("boards:read")
  byId(@Param("id") id: string) {
    return this.boards.byId(id);
  }

  @Post("by-project/:projectId")
  @RequiresPermission("boards:write")
  @UsePipes(new ZodPipe(CreateBoardSchema))
  create(@Param("projectId") id: string, @Body() body: any) {
    return this.boards.create(id, body);
  }

  @Post(":id/columns")
  @RequiresPermission("boards:write")
  @UsePipes(new ZodPipe(CreateColumnSchema))
  addColumn(@Param("id") id: string, @Body() body: any) {
    return this.boards.addColumn(id, body);
  }

  @Patch("columns/:columnId")
  @RequiresPermission("boards:write")
  updateColumn(@Param("columnId") id: string, @Body() body: any) {
    return this.boards.updateColumn(id, body);
  }

  @Delete("columns/:columnId")
  @RequiresPermission("boards:write")
  removeColumn(@Param("columnId") id: string) {
    return this.boards.removeColumn(id);
  }

  @Post(":id/reorder")
  @RequiresPermission("boards:reorder")
  @UsePipes(new ZodPipe(ReorderColumnsSchema))
  reorder(@Param("id") id: string, @Body() body: { ordering: { id: string; order: number }[] }) {
    return this.boards.reorder(id, body.ordering);
  }
}
