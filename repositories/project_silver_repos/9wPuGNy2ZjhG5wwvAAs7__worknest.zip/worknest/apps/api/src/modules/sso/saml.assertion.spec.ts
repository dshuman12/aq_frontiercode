import { describe, expect, it } from "vitest";
import {
  AssertionAudienceMismatch,
  AssertionExpired,
  extractEmail,
  validateAssertion,
} from "./saml.assertion";

const audience = "urn:worknest";

describe("validateAssertion", () => {
  it("passes when audience + window match", () => {
    expect(() =>
      validateAssertion(
        {
          audience,
          attributes: {},
          notBefore: new Date(Date.now() - 1000),
          notOnOrAfter: new Date(Date.now() + 60_000),
        },
        audience,
      ),
    ).not.toThrow();
  });
  it("rejects on audience mismatch", () => {
    expect(() => validateAssertion({ audience: "x", attributes: {} }, audience)).toThrow(AssertionAudienceMismatch);
  });
  it("rejects when notBefore in future", () => {
    expect(() =>
      validateAssertion(
        { audience, attributes: {}, notBefore: new Date(Date.now() + 1000) },
        audience,
      ),
    ).toThrow(AssertionExpired);
  });
  it("rejects when notOnOrAfter passed", () => {
    expect(() =>
      validateAssertion(
        { audience, attributes: {}, notOnOrAfter: new Date(Date.now() - 1) },
        audience,
      ),
    ).toThrow(AssertionExpired);
  });
});

describe("extractEmail", () => {
  it("returns the lowercased trimmed value", () => {
    const parsed = {
      audience,
      attributes: { mail: "  Alice@Example.COM  " },
    };
    expect(extractEmail(parsed, "mail")).toBe("alice@example.com");
  });
  it("throws when missing", () => {
    expect(() => extractEmail({ audience, attributes: {} }, "mail")).toThrow();
  });
});
