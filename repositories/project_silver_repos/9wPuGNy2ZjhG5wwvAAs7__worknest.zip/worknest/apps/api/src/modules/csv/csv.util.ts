/**
 * Hand-rolled CSV parser/serializer. Just enough to handle the
 * subset we control (headers + scalar values, RFC 4180 quoting).
 * We don't pull in `papaparse` because the surface is small and
 * importing a parser into the API for two endpoints is overkill.
 *
 * `parseCsv` returns rows as Record<string, string> keyed by the
 * header row; missing columns are empty strings. `serializeCsv`
 * accepts a column order so output is deterministic.
 */

export function parseCsv(text: string): Record<string, string>[] {
  const lines = splitLines(text.replace(/^﻿/, "")); // strip BOM
  if (lines.length === 0) return [];
  const headers = parseRow(lines[0]);
  const rows: Record<string, string>[] = [];
  for (let i = 1; i < lines.length; i++) {
    if (lines[i].length === 0) continue;
    const cols = parseRow(lines[i]);
    const row: Record<string, string> = {};
    for (let j = 0; j < headers.length; j++) {
      row[headers[j]] = cols[j] ?? "";
    }
    rows.push(row);
  }
  return rows;
}

export function serializeCsv<T extends Record<string, unknown>>(
  rows: T[],
  columns: (keyof T & string)[],
): string {
  const header = columns.map(escapeField).join(",");
  const body = rows
    .map((r) => columns.map((c) => escapeField(stringify(r[c]))).join(","))
    .join("\n");
  return body ? `${header}\n${body}\n` : `${header}\n`;
}

function splitLines(input: string): string[] {
  const out: string[] = [];
  let current = "";
  let inQuotes = false;
  for (let i = 0; i < input.length; i++) {
    const ch = input[i];
    if (ch === '"') {
      if (inQuotes && input[i + 1] === '"') {
        current += '""';
        i += 1;
        continue;
      }
      inQuotes = !inQuotes;
      current += ch;
      continue;
    }
    if ((ch === "\n" || ch === "\r") && !inQuotes) {
      if (current.length > 0 || out.length === 0) out.push(current);
      current = "";
      if (ch === "\r" && input[i + 1] === "\n") i += 1;
      continue;
    }
    current += ch;
  }
  if (current.length > 0) out.push(current);
  return out;
}

function parseRow(line: string): string[] {
  const cols: string[] = [];
  let current = "";
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (inQuotes && line[i + 1] === '"') {
        current += '"';
        i += 1;
        continue;
      }
      inQuotes = !inQuotes;
      continue;
    }
    if (ch === "," && !inQuotes) {
      cols.push(current);
      current = "";
      continue;
    }
    current += ch;
  }
  cols.push(current);
  return cols;
}

function stringify(value: unknown): string {
  if (value == null) return "";
  if (value instanceof Date) return value.toISOString();
  if (typeof value === "object") return JSON.stringify(value);
  return String(value);
}

function escapeField(value: string): string {
  if (/[",\n\r]/.test(value)) return `"${value.replace(/"/g, '""')}"`;
  return value;
}
