/**
 * Task templates. CRUD plus an `apply` action that materializes a
 * template into a real task on a target project. The clone is a
 * one-shot — we don't track derivation, so editing the template
 * later doesn't propagate.
 */
import { ConflictException, Injectable, NotFoundException } from "@nestjs/common";
import { prisma } from "@worknest/database";

interface ChecklistItem {
  text: string;
  done?: boolean;
}

@Injectable()
export class TaskTemplatesService {
  async list(organizationId: string) {
    return prisma.taskTemplate.findMany({
      where: { organizationId },
      orderBy: { name: "asc" },
    });
  }

  async get(organizationId: string, id: string) {
    const t = await prisma.taskTemplate.findFirst({ where: { id, organizationId } });
    if (!t) throw new NotFoundException();
    return t;
  }

  async create(args: {
    organizationId: string;
    input: {
      name: string;
      title: string;
      description?: string;
      priority: string;
      estimateHours?: number;
      labels: string[];
      checklist: ChecklistItem[];
    };
  }) {
    const dup = await prisma.taskTemplate.findUnique({
      where: { organizationId_name: { organizationId: args.organizationId, name: args.input.name } },
    });
    if (dup) throw new ConflictException("template_name_in_use");
    return prisma.taskTemplate.create({
      data: {
        organizationId: args.organizationId,
        name: args.input.name,
        title: args.input.title,
        description: args.input.description,
        priority: args.input.priority,
        estimateHours: args.input.estimateHours,
        labels: args.input.labels,
        checklist: args.input.checklist as unknown as object,
      },
    });
  }

  async update(args: { organizationId: string; id: string; patch: Record<string, unknown> }) {
    const t = await this.get(args.organizationId, args.id);
    return prisma.taskTemplate.update({ where: { id: t.id }, data: args.patch });
  }

  async remove(organizationId: string, id: string) {
    const t = await this.get(organizationId, id);
    await prisma.taskTemplate.delete({ where: { id: t.id } });
    return { ok: true };
  }

  async apply(args: {
    organizationId: string;
    templateId: string;
    creatorId: string;
    projectId: string;
    assigneeId?: string | null;
    dueAt?: Date | null;
  }) {
    const tpl = await this.get(args.organizationId, args.templateId);
    const project = await prisma.project.findFirst({
      where: { id: args.projectId, organizationId: args.organizationId },
    });
    if (!project) throw new NotFoundException("project_not_found");

    return prisma.$transaction(async (tx) => {
      const next = await tx.project.update({
        where: { id: project.id },
        data: { nextTaskNumber: { increment: 1 } },
        select: { key: true, nextTaskNumber: true },
      });
      const key = `${next.key}-${next.nextTaskNumber - 1}`;
      const task = await tx.task.create({
        data: {
          projectId: project.id,
          title: tpl.title,
          description: tpl.description,
          priority: tpl.priority,
          estimateHours: tpl.estimateHours,
          assigneeId: args.assigneeId ?? null,
          dueAt: args.dueAt ?? null,
          createdById: args.creatorId,
          key,
          position: Date.now(),
        },
      });
      if (tpl.labels.length) {
        await tx.taskLabel.createMany({
          data: tpl.labels.map((name) => ({ taskId: task.id, name })),
        });
      }
      const checklist = (tpl.checklist as ChecklistItem[] | null) ?? [];
      if (checklist.length) {
        const cl = await tx.taskChecklist.create({
          data: { taskId: task.id, title: "Default" },
        });
        for (const item of checklist) {
          await tx.taskChecklistItem.create({
            data: {
              checklistId: cl.id,
              text: item.text,
              done: !!item.done,
            },
          });
        }
      }
      return task;
    });
  }
}
