import { Body, Controller, Delete, Get, Post, Query, UseGuards, UsePipes } from "@nestjs/common";
import { AuthGuard } from "../../common/auth.guard";
import { CurrentOrgId, CurrentUser } from "../../common/current-user.decorator";
import { RequiresPermission } from "../../common/permissions.guard";
import { ZodPipe } from "../../common/zod.pipe";
import { MarkReadSchema, SetPreferenceSchema } from "@worknest/validators";
import { NotificationsService } from "./notifications.service";

@UseGuards(AuthGuard)
@Controller("notifications")
export class NotificationsController {
  constructor(private readonly service: NotificationsService) {}

  @Get()
  @RequiresPermission("notifications:read")
  list(
    @CurrentUser() u: { sub: string },
    @CurrentOrgId() orgId: string,
    @Query("unread") unread?: string,
    @Query("page") page?: string,
    @Query("pageSize") pageSize?: string,
  ) {
    return this.service.list(u.sub, orgId, {
      unread: unread === "true",
      page: page ? Number(page) : undefined,
      pageSize: pageSize ? Number(pageSize) : undefined,
    });
  }

  @Get("unread")
  @RequiresPermission("notifications:read")
  unread(@CurrentUser() u: { sub: string }, @CurrentOrgId() orgId: string) {
    return this.service.unread(u.sub, orgId);
  }

  @Post("read")
  @RequiresPermission("notifications:read")
  @UsePipes(new ZodPipe(MarkReadSchema))
  markRead(@CurrentUser() u: { sub: string }, @Body() body: { ids: string[] }) {
    return this.service.markRead(u.sub, body.ids);
  }

  @Post("read-all")
  @RequiresPermission("notifications:read")
  markAllRead(@CurrentUser() u: { sub: string }, @CurrentOrgId() orgId: string) {
    return this.service.markAllRead(u.sub, orgId);
  }

  @Get("preferences")
  preferences(@CurrentUser() u: { sub: string }) {
    return this.service.preferencesFor(u.sub);
  }

  @Post("preferences")
  @RequiresPermission("notifications:preferences:write")
  @UsePipes(new ZodPipe(SetPreferenceSchema))
  setPreference(
    @CurrentUser() u: { sub: string },
    @Body() body: { kind: string; channel: string; enabled: boolean },
  ) {
    return this.service.setPreference(u.sub, body.kind, body.channel, body.enabled);
  }

  @Delete("preferences")
  @RequiresPermission("notifications:preferences:write")
  resetPreferences(@CurrentUser() u: { sub: string }) {
    return this.service.resetPreferencesToDefault(u.sub);
  }
}
