import { Injectable, NotFoundException } from "@nestjs/common";
import { generateOpaqueToken, hashPassword, sha256Hex } from "@worknest/auth";
import { prisma } from "@worknest/database";

@Injectable()
export class ClientsService {
  async list(organizationId: string, q?: string) {
    return prisma.client.findMany({
      where: q
        ? { organizationId, name: { contains: q, mode: "insensitive" } }
        : { organizationId },
      orderBy: { name: "asc" },
      include: {
        _count: { select: { contacts: true, portalUsers: true } },
      },
    });
  }

  async byId(id: string) {
    const client = await prisma.client.findUnique({
      where: { id },
      include: {
        contacts: true,
        documents: true,
        portalUsers: true,
      },
    });
    if (!client) throw new NotFoundException();
    return client;
  }

  async create(organizationId: string, input: Record<string, unknown>) {
    return prisma.client.create({
      data: { organizationId, ...(input as Record<string, never>) },
    });
  }

  async update(id: string, patch: Record<string, unknown>) {
    return prisma.client.update({ where: { id }, data: patch as never });
  }

  async delete(id: string) {
    await prisma.client.delete({ where: { id } });
    return { ok: true };
  }

  async addContact(input: { clientId: string; name: string; role?: string; email?: string; phone?: string }) {
    return prisma.clientContact.create({ data: input });
  }

  async removeContact(contactId: string) {
    await prisma.clientContact.delete({ where: { id: contactId } });
    return { ok: true };
  }

  async invitePortalUser(clientId: string, email: string, name: string) {
    const tempPassword = generateOpaqueToken().slice(0, 16);
    return prisma.clientPortalUser.create({
      data: {
        clientId,
        email,
        name,
        passwordHash: await hashPassword(tempPassword),
      },
    });
  }

  async addDocument(clientId: string, fileAssetId: string) {
    return prisma.clientDocument.create({ data: { clientId, fileAssetId } });
  }
}
