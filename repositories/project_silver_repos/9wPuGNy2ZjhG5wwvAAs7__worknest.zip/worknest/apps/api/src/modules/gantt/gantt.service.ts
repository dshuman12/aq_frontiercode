/**
 * Gantt computation. Returns a flat list of bars per project, sorted
 * by earliest scheduled date. We pull (start, end) windows from
 * milestones, sprints, and tasks-with-due-dates. Dependencies use
 * the existing TaskDependency joins so the consumer can render
 * arrow lines.
 */
import { Injectable } from "@nestjs/common";
import { prisma } from "@worknest/database";

export interface GanttBar {
  id: string;
  type: "task" | "sprint" | "milestone";
  label: string;
  start: Date;
  end: Date;
  parentId?: string;
}

export interface GanttDependency {
  fromId: string;
  toId: string;
  kind: string;
}

@Injectable()
export class GanttService {
  async forProject(args: { organizationId: string; projectId: string }) {
    const project = await prisma.project.findFirst({
      where: { id: args.projectId, organizationId: args.organizationId },
    });
    if (!project) return { bars: [], dependencies: [] as GanttDependency[] };

    const [tasks, sprints, milestones, deps] = await Promise.all([
      prisma.task.findMany({
        where: { projectId: project.id, dueAt: { not: null } },
        orderBy: { dueAt: "asc" },
        select: {
          id: true,
          key: true,
          title: true,
          createdAt: true,
          dueAt: true,
          completedAt: true,
        },
      }),
      prisma.sprint.findMany({
        where: { projectId: project.id, startsAt: { not: null }, endsAt: { not: null } },
        select: { id: true, name: true, startsAt: true, endsAt: true },
      }),
      prisma.milestone.findMany({
        where: { projectId: project.id, dueOn: { not: null } },
        select: { id: true, name: true, dueOn: true },
      }),
      prisma.taskDependency.findMany({
        where: { task: { projectId: project.id } },
        select: { taskId: true, dependsOnId: true, type: true },
      }),
    ]);

    const bars: GanttBar[] = [];
    for (const t of tasks) {
      const start = t.createdAt;
      const end = t.completedAt ?? t.dueAt!;
      bars.push({
        id: t.id,
        type: "task",
        label: `${t.key} — ${t.title}`,
        start,
        end,
      });
    }
    for (const s of sprints) {
      bars.push({
        id: s.id,
        type: "sprint",
        label: `Sprint: ${s.name}`,
        start: s.startsAt!,
        end: s.endsAt!,
      });
    }
    for (const m of milestones) {
      bars.push({
        id: m.id,
        type: "milestone",
        label: `🏁 ${m.name}`,
        start: m.dueOn!,
        end: m.dueOn!,
      });
    }

    bars.sort((a, b) => a.start.getTime() - b.start.getTime());

    const dependencies: GanttDependency[] = deps.map((d) => ({
      fromId: d.dependsOnId,
      toId: d.taskId,
      kind: d.type,
    }));

    return { bars, dependencies };
  }
}
