import { Body, Controller, Get, Headers, Ip, Post, UseGuards, UsePipes } from "@nestjs/common";
import { AuthGuard } from "../../common/auth.guard";
import { CurrentUser } from "../../common/current-user.decorator";
import { Public } from "../../common/permissions.guard";
import { ZodPipe } from "../../common/zod.pipe";
import {
  Disable2FASchema,
  Enable2FASchema,
  EmailVerificationSchema,
  LoginSchema,
  PasswordResetCompleteSchema,
  PasswordResetRequestSchema,
  RefreshSchema,
  RegisterUserSchema,
  RevokeSessionSchema,
} from "@worknest/validators";
import { AuthService } from "./auth.service";

@Controller("auth")
export class AuthController {
  constructor(private readonly auth: AuthService) {}

  @Public()
  @Post("register")
  @UsePipes(new ZodPipe(RegisterUserSchema))
  register(@Body() body: any) {
    return this.auth.register(body);
  }

  @Public()
  @Post("login")
  @UsePipes(new ZodPipe(LoginSchema))
  login(@Body() body: any, @Ip() ip: string, @Headers("user-agent") ua?: string) {
    return this.auth.login({ ...body, ip, userAgent: ua });
  }

  @Public()
  @Post("refresh")
  @UsePipes(new ZodPipe(RefreshSchema))
  refresh(@Body() body: { refreshToken: string }) {
    return this.auth.refresh(body.refreshToken);
  }

  @Post("logout")
  logout(@Body() body: { sessionToken: string }) {
    return this.auth.logout(body.sessionToken);
  }

  @Public()
  @Post("password/reset/request")
  @UsePipes(new ZodPipe(PasswordResetRequestSchema))
  requestReset(@Body() body: { email: string }) {
    return this.auth.requestPasswordReset(body.email);
  }

  @Public()
  @Post("password/reset/complete")
  @UsePipes(new ZodPipe(PasswordResetCompleteSchema))
  completeReset(@Body() body: { token: string; password: string }) {
    return this.auth.completePasswordReset(body.token, body.password);
  }

  @Public()
  @Post("verify-email")
  @UsePipes(new ZodPipe(EmailVerificationSchema))
  verifyEmail(@Body() body: { token: string }) {
    return this.auth.verifyEmail(body.token);
  }

  @UseGuards(AuthGuard)
  @Get("sessions")
  sessions(@CurrentUser() u: { sub: string }) {
    return this.auth.listSessions(u.sub);
  }

  @UseGuards(AuthGuard)
  @Post("sessions/revoke")
  @UsePipes(new ZodPipe(RevokeSessionSchema))
  revokeSession(@CurrentUser() u: { sub: string }, @Body() body: { sessionId: string }) {
    return this.auth.revokeSession(u.sub, body.sessionId);
  }

  @UseGuards(AuthGuard)
  @Post("2fa/begin")
  begin2fa(@CurrentUser() u: { sub: string }) {
    return this.auth.beginEnable2fa(u.sub);
  }

  @UseGuards(AuthGuard)
  @Post("2fa/enable")
  @UsePipes(new ZodPipe(Enable2FASchema))
  enable2fa(@CurrentUser() u: { sub: string }, @Body() body: { secret: string; code: string }) {
    return this.auth.confirmEnable2fa(u.sub, body.secret, body.code);
  }

  @UseGuards(AuthGuard)
  @Post("2fa/disable")
  @UsePipes(new ZodPipe(Disable2FASchema))
  disable2fa(@CurrentUser() u: { sub: string }, @Body() body: { password: string }) {
    return this.auth.disable2fa(u.sub, body.password);
  }
}
