import { Injectable } from "@nestjs/common";
import { generateOpaqueToken, sha256Hex } from "@worknest/auth";
import { prisma } from "@worknest/database";

@Injectable()
export class WebhooksService {
  async list(organizationId: string) {
    return prisma.webhookEndpoint.findMany({
      where: { organizationId },
      select: {
        id: true,
        url: true,
        kinds: true,
        enabled: true,
        failureCount: true,
        lastDeliveredAt: true,
        createdAt: true,
      },
      orderBy: { createdAt: "desc" },
    });
  }

  async create(input: { organizationId: string; url: string; kinds: string[]; secret?: string }) {
    const secret = input.secret ?? generateOpaqueToken();
    const row = await prisma.webhookEndpoint.create({
      data: {
        organizationId: input.organizationId,
        url: input.url,
        kinds: input.kinds,
        secretHash: sha256Hex(secret),
      },
    });
    return { row, secret };
  }

  async update(id: string, patch: { url?: string; kinds?: string[]; enabled?: boolean }) {
    return prisma.webhookEndpoint.update({ where: { id }, data: patch });
  }

  async rotateSecret(id: string, newSecret?: string) {
    const secret = newSecret ?? generateOpaqueToken();
    await prisma.webhookEndpoint.update({
      where: { id },
      data: { secretHash: sha256Hex(secret) },
    });
    return { secret };
  }

  async delete(id: string) {
    await prisma.webhookEndpoint.delete({ where: { id } });
    return { ok: true };
  }

  async listDeliveries(organizationId: string) {
    return prisma.webhookDelivery.findMany({
      where: { webhook: { organizationId } },
      orderBy: { attemptedAt: "desc" },
      take: 200,
    });
  }
}
