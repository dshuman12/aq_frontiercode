/**
 * Loose validators for saved-view criteria. Each resource accepts
 * a slightly different shape, but they share allowed top-level keys.
 * The point of this file is to reject obviously-wrong criteria
 * before they hit the database — typos, unknown filter keys, or
 * primitive type mismatches.
 *
 * We intentionally don't enforce semantic validity (e.g. that an
 * `assigneeId` references a real user) — that's the consumer's call
 * and would slow the save endpoint down for no win.
 */

const TASK_KEYS = new Set([
  "projectId",
  "assigneeId",
  "status",
  "priority",
  "labels",
  "sprintId",
  "createdById",
  "dueBefore",
  "dueAfter",
  "q",
]);
const TICKET_KEYS = new Set([
  "categoryId",
  "status",
  "priority",
  "assigneeId",
  "requesterId",
  "q",
]);
const REQUEST_KEYS = new Set([
  "formId",
  "status",
  "submitterId",
  "assigneeId",
  "q",
]);

export function validateCriteria(
  resource: "tasks" | "tickets" | "requests",
  criteria: Record<string, unknown>,
): { ok: true } | { ok: false; reason: string } {
  const allowed = resource === "tasks" ? TASK_KEYS : resource === "tickets" ? TICKET_KEYS : REQUEST_KEYS;
  for (const key of Object.keys(criteria)) {
    if (!allowed.has(key)) return { ok: false, reason: `unknown_key:${key}` };
    const value = criteria[key];
    if (value === undefined) continue;
    if (Array.isArray(value)) {
      if (!value.every((v) => typeof v === "string" || typeof v === "number")) {
        return { ok: false, reason: `bad_array:${key}` };
      }
    } else if (
      typeof value !== "string" &&
      typeof value !== "number" &&
      typeof value !== "boolean"
    ) {
      return { ok: false, reason: `bad_type:${key}` };
    }
  }
  return { ok: true };
}
