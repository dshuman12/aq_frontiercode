import { Body, Controller, Delete, Get, Param, Post, UseGuards, UsePipes } from "@nestjs/common";
import { AuthGuard } from "../../common/auth.guard";
import { CurrentOrgId, CurrentUser } from "../../common/current-user.decorator";
import { RequiresPermission } from "../../common/permissions.guard";
import { ZodPipe } from "../../common/zod.pipe";
import { CreateApiKeySchema } from "@worknest/validators";
import { ApiKeysService } from "./api-keys.service";

@UseGuards(AuthGuard)
@Controller("api-keys")
export class ApiKeysController {
  constructor(private readonly keys: ApiKeysService) {}

  @Get()
  @RequiresPermission("api-keys:read")
  list(@CurrentOrgId() orgId: string) {
    return this.keys.list(orgId);
  }

  @Post()
  @RequiresPermission("api-keys:create")
  @UsePipes(new ZodPipe(CreateApiKeySchema))
  async create(
    @CurrentOrgId() orgId: string,
    @CurrentUser() u: { sub: string },
    @Body() body: any,
  ) {
    const { row, plaintext } = await this.keys.create({
      organizationId: orgId,
      userId: u.sub,
      ...body,
    });
    return { id: row.id, label: row.label, scopes: row.scopes, plaintext };
  }

  @Delete(":id")
  @RequiresPermission("api-keys:revoke")
  revoke(@Param("id") id: string) {
    return this.keys.revoke(id);
  }
}
