/**
 * RFC 4180 corners. Quoted fields can contain commas, newlines, and
 * "" as an escaped quote. Round-trip: parse(serialize(x)) === x for
 * the value shapes we actually send.
 */
import { describe, expect, it } from "vitest";
import { parseCsv, serializeCsv } from "./csv.util";

describe("csv parse", () => {
  it("handles plain rows", () => {
    expect(parseCsv("a,b\n1,2\n3,4")).toEqual([
      { a: "1", b: "2" },
      { a: "3", b: "4" },
    ]);
  });

  it("handles commas inside quoted fields", () => {
    expect(parseCsv('a,b\n"hello, world","x"')).toEqual([
      { a: "hello, world", b: "x" },
    ]);
  });

  it("handles escaped quotes", () => {
    expect(parseCsv('a\n"she said ""hi"""')).toEqual([{ a: 'she said "hi"' }]);
  });

  it("handles newlines inside quoted fields", () => {
    expect(parseCsv('a,b\n"line\nbreak",x')).toEqual([{ a: "line\nbreak", b: "x" }]);
  });

  it("strips a UTF-8 BOM", () => {
    expect(parseCsv("﻿a\n1")).toEqual([{ a: "1" }]);
  });
});

describe("csv serialize", () => {
  it("quotes commas and newlines", () => {
    const out = serializeCsv([{ a: "x,y", b: "z\nq" }], ["a", "b"]);
    expect(out).toBe('a,b\n"x,y","z\nq"\n');
  });

  it("round-trips through parse", () => {
    const rows = [
      { title: "buy milk", priority: "high" },
      { title: 'urgent: "fix"', priority: "urgent" },
    ];
    const csv = serializeCsv(rows, ["title", "priority"]);
    expect(parseCsv(csv)).toEqual(rows);
  });
});
