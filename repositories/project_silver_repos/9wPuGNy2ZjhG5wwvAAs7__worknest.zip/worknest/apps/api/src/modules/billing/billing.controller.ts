import { Body, Controller, Get, Headers, Post, Req, UseGuards, UsePipes } from "@nestjs/common";
import { AuthGuard } from "../../common/auth.guard";
import { CurrentOrgId } from "../../common/current-user.decorator";
import { Public, RequiresPermission } from "../../common/permissions.guard";
import { ZodPipe } from "../../common/zod.pipe";
import {
  ChangeSeatsSchema,
  CheckoutSessionSchema,
  PortalSessionSchema,
} from "@worknest/validators";
import { BillingService } from "./billing.service";

@Controller("billing")
export class BillingController {
  constructor(private readonly billing: BillingService) {}

  @UseGuards(AuthGuard)
  @Post("checkout")
  @RequiresPermission("org:billing:write")
  @UsePipes(new ZodPipe(CheckoutSessionSchema))
  checkout(@CurrentOrgId() orgId: string, @Body() body: any) {
    return this.billing.createCheckoutSession({ ...body, organizationId: orgId });
  }

  @UseGuards(AuthGuard)
  @Post("portal")
  @RequiresPermission("org:billing:write")
  @UsePipes(new ZodPipe(PortalSessionSchema))
  portal(@Body() body: { customerId: string; returnUrl: string }) {
    return this.billing.createPortalSession(body);
  }

  @UseGuards(AuthGuard)
  @Post("seats")
  @RequiresPermission("org:billing:write")
  @UsePipes(new ZodPipe(ChangeSeatsSchema))
  seats(@CurrentOrgId() orgId: string, @Body() body: { seats: number }) {
    return this.billing.changeSeats(orgId, body.seats);
  }

  @UseGuards(AuthGuard)
  @Get("invoices")
  @RequiresPermission("org:billing:read")
  invoices(@CurrentOrgId() orgId: string) {
    return this.billing.listInvoices(orgId);
  }

  @Public()
  @Post("webhook")
  webhook(@Headers("stripe-signature") sig: string, @Req() req: any) {
    return this.billing.handleWebhook(req.rawBody as Buffer, sig);
  }
}
