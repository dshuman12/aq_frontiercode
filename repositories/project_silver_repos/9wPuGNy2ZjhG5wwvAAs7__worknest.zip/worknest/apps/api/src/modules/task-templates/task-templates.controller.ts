import { Body, Controller, Delete, Get, Param, Patch, Post, UseGuards, UsePipes } from "@nestjs/common";
import {
  ApplyTaskTemplateSchema,
  CreateTaskTemplateSchema,
  UpdateTaskTemplateSchema,
} from "@worknest/validators";
import { AuthGuard } from "../../common/auth.guard";
import { ZodPipe } from "../../common/zod.pipe";
import { CurrentOrgId, CurrentUser } from "../../common/current-user.decorator";
import { RequiresPermission } from "../../common/permissions.guard";
import { TaskTemplatesService } from "./task-templates.service";

@UseGuards(AuthGuard)
@Controller("task-templates")
export class TaskTemplatesController {
  constructor(private readonly templates: TaskTemplatesService) {}

  @Get()
  @RequiresPermission("tasks:read")
  list(@CurrentOrgId() orgId: string) {
    return this.templates.list(orgId);
  }

  @Get(":id")
  @RequiresPermission("tasks:read")
  get(@CurrentOrgId() orgId: string, @Param("id") id: string) {
    return this.templates.get(orgId, id);
  }

  @Post()
  @RequiresPermission("tasks:create")
  @UsePipes(new ZodPipe(CreateTaskTemplateSchema))
  create(@CurrentOrgId() orgId: string, @Body() body: any) {
    return this.templates.create({ organizationId: orgId, input: body });
  }

  @Patch(":id")
  @RequiresPermission("tasks:create")
  @UsePipes(new ZodPipe(UpdateTaskTemplateSchema))
  update(
    @CurrentOrgId() orgId: string,
    @Param("id") id: string,
    @Body() body: any,
  ) {
    return this.templates.update({ organizationId: orgId, id, patch: body });
  }

  @Delete(":id")
  @RequiresPermission("tasks:create")
  remove(@CurrentOrgId() orgId: string, @Param("id") id: string) {
    return this.templates.remove(orgId, id);
  }

  @Post(":id/apply")
  @RequiresPermission("tasks:create")
  @UsePipes(new ZodPipe(ApplyTaskTemplateSchema))
  apply(
    @CurrentOrgId() orgId: string,
    @CurrentUser() user: any,
    @Param("id") id: string,
    @Body() body: { projectId: string; assigneeId?: string | null; dueAt?: Date | null },
  ) {
    return this.templates.apply({
      organizationId: orgId,
      templateId: id,
      creatorId: user.sub,
      projectId: body.projectId,
      assigneeId: body.assigneeId ?? null,
      dueAt: body.dueAt ?? null,
    });
  }
}
