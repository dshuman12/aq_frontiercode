/**
 * Slack outbound. Posts to an Incoming Webhook URL stored on
 * org-level config (we re-use the existing FeatureFlag table for
 * runtime knobs; in production this becomes a typed Integration row).
 *
 * The body builder lives separately so we can unit-test the format
 * without poking the network.
 */
import { Injectable } from "@nestjs/common";
import { logger } from "@worknest/logger";

const log = logger("integrations/slack");

export interface SlackBlock {
  type: string;
  text?: { type: string; text: string };
  fields?: { type: string; text: string }[];
}

export interface SlackPayload {
  text: string;
  blocks?: SlackBlock[];
  username?: string;
  icon_emoji?: string;
}

@Injectable()
export class SlackService {
  async post(args: { webhookUrl: string; payload: SlackPayload }): Promise<{ ok: boolean }> {
    try {
      const res = await fetch(args.webhookUrl, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(args.payload),
        signal: AbortSignal.timeout(8000),
      });
      const text = await res.text();
      if (!res.ok) {
        log.warn({ status: res.status, body: text }, "slack_post_failed");
        return { ok: false };
      }
      return { ok: true };
    } catch (err) {
      log.warn({ err: (err as Error).message }, "slack_post_error");
      return { ok: false };
    }
  }
}
