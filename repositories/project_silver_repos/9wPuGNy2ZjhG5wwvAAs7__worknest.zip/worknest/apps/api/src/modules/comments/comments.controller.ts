import { Body, Controller, Get, Param, Post, UseGuards } from "@nestjs/common";
import { z } from "zod";
import { AuthGuard } from "../../common/auth.guard";
import { ZodPipe } from "../../common/zod.pipe";
import { CurrentOrgId, CurrentUser } from "../../common/current-user.decorator";
import { CommentsService } from "./comments.service";

const ReactSchema = z.object({
  resource: z.enum(["task", "ticket", "request"]),
  commentId: z.string().min(1),
  emoji: z.string().min(1).max(40),
});

@UseGuards(AuthGuard)
@Controller("comments")
export class CommentsController {
  constructor(private readonly comments: CommentsService) {}

  @Post("react")
  react(
    @CurrentOrgId() _orgId: string,
    @CurrentUser() user: any,
    @Body(new ZodPipe(ReactSchema))
    body: { resource: "task" | "ticket" | "request"; commentId: string; emoji: string },
  ) {
    return this.comments.react({
      resource: body.resource,
      commentId: body.commentId,
      userId: user.sub,
      emoji: body.emoji,
    });
  }

  @Get(":commentId/reactions")
  list(
    @CurrentOrgId() _orgId: string,
    @Param("commentId") commentId: string,
  ) {
    return this.comments.listReactions(commentId);
  }
}
