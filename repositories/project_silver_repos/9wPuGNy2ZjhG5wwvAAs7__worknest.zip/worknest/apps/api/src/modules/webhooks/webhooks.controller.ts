import { Body, Controller, Delete, Get, Param, Patch, Post, UseGuards, UsePipes } from "@nestjs/common";
import { AuthGuard } from "../../common/auth.guard";
import { CurrentOrgId } from "../../common/current-user.decorator";
import { RequiresPermission } from "../../common/permissions.guard";
import { ZodPipe } from "../../common/zod.pipe";
import {
  CreateWebhookSchema,
  RotateWebhookSecretSchema,
  UpdateWebhookSchema,
} from "@worknest/validators";
import { WebhooksService } from "./webhooks.service";

@UseGuards(AuthGuard)
@Controller("webhooks")
export class WebhooksController {
  constructor(private readonly webhooks: WebhooksService) {}

  @Get()
  @RequiresPermission("webhooks:read")
  list(@CurrentOrgId() orgId: string) {
    return this.webhooks.list(orgId);
  }

  @Get("deliveries")
  @RequiresPermission("webhooks:read")
  deliveries(@CurrentOrgId() orgId: string) {
    return this.webhooks.listDeliveries(orgId);
  }

  @Post()
  @RequiresPermission("webhooks:write")
  @UsePipes(new ZodPipe(CreateWebhookSchema))
  async create(@CurrentOrgId() orgId: string, @Body() body: any) {
    const { row, secret } = await this.webhooks.create({ ...body, organizationId: orgId });
    return { ...row, secret };
  }

  @Patch(":id")
  @RequiresPermission("webhooks:write")
  @UsePipes(new ZodPipe(UpdateWebhookSchema))
  update(@Param("id") id: string, @Body() body: any) {
    return this.webhooks.update(id, body);
  }

  @Post(":id/rotate-secret")
  @RequiresPermission("webhooks:write")
  @UsePipes(new ZodPipe(RotateWebhookSecretSchema))
  rotate(@Param("id") id: string, @Body() body: { newSecret?: string }) {
    return this.webhooks.rotateSecret(id, body.newSecret);
  }

  @Delete(":id")
  @RequiresPermission("webhooks:write")
  remove(@Param("id") id: string) {
    return this.webhooks.delete(id);
  }
}
