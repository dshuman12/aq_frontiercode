/**
 * CSV import/export for tasks and tickets. Imports are best-effort:
 * each row is validated independently; failed rows are returned in the
 * `errors` array with their line number rather than rolling the whole
 * batch back. Exports stream-friendly text (we keep the in-memory
 * shape because demo dataset volumes are small; production swaps to
 * a chunked stream).
 *
 * Required headers:
 *   tasks   — projectKey, title (status/priority/assigneeEmail optional)
 *   tickets — title (status/priority/categoryName optional)
 */
import { Injectable, NotFoundException } from "@nestjs/common";
import { prisma } from "@worknest/database";
import { parseCsv, serializeCsv } from "./csv.util";

interface ImportResult<T> {
  imported: T[];
  errors: { line: number; reason: string }[];
}

@Injectable()
export class CsvService {
  async importTasks(args: {
    organizationId: string;
    creatorId: string;
    csv: string;
  }): Promise<ImportResult<{ id: string; key: string; title: string }>> {
    const rows = parseCsv(args.csv);
    const imported: { id: string; key: string; title: string }[] = [];
    const errors: { line: number; reason: string }[] = [];

    const projectKeys = Array.from(new Set(rows.map((r) => r.projectKey).filter(Boolean)));
    const projects = await prisma.project.findMany({
      where: { organizationId: args.organizationId, key: { in: projectKeys } },
    });
    const projectsByKey = new Map(projects.map((p) => [p.key, p]));

    const userEmails = Array.from(new Set(rows.map((r) => r.assigneeEmail).filter(Boolean)));
    const users = userEmails.length
      ? await prisma.user.findMany({ where: { email: { in: userEmails } } })
      : [];
    const usersByEmail = new Map(users.map((u) => [u.email, u]));

    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      const lineNumber = i + 2;
      try {
        if (!row.title) {
          errors.push({ line: lineNumber, reason: "missing_title" });
          continue;
        }
        const project = projectsByKey.get(row.projectKey);
        if (!project) {
          errors.push({ line: lineNumber, reason: `unknown_project:${row.projectKey}` });
          continue;
        }
        const assignee = row.assigneeEmail ? usersByEmail.get(row.assigneeEmail) : null;
        const next = await prisma.project.update({
          where: { id: project.id },
          data: { nextTaskNumber: { increment: 1 } },
          select: { nextTaskNumber: true, key: true },
        });
        const key = `${next.key}-${next.nextTaskNumber - 1}`;
        const created = await prisma.task.create({
          data: {
            projectId: project.id,
            title: row.title,
            description: row.description || null,
            status: row.status || "todo",
            priority: row.priority || "medium",
            assigneeId: assignee?.id ?? null,
            createdById: args.creatorId,
            key,
            position: Date.now() + i,
          },
          select: { id: true, key: true, title: true },
        });
        imported.push(created);
      } catch (err) {
        errors.push({
          line: lineNumber,
          reason: err instanceof Error ? err.message : "unknown",
        });
      }
    }
    return { imported, errors };
  }

  async exportTasks(args: { organizationId: string; projectId?: string }): Promise<string> {
    const tasks = await prisma.task.findMany({
      where: {
        project: { organizationId: args.organizationId },
        ...(args.projectId ? { projectId: args.projectId } : {}),
      },
      orderBy: { createdAt: "desc" },
      include: {
        project: { select: { key: true } },
      },
    });
    return serializeCsv(
      tasks.map((t) => ({
        key: t.key,
        projectKey: t.project.key,
        title: t.title,
        description: t.description ?? "",
        status: t.status,
        priority: t.priority,
        assigneeId: t.assigneeId ?? "",
        dueAt: t.dueAt?.toISOString() ?? "",
        createdAt: t.createdAt.toISOString(),
      })),
      [
        "key",
        "projectKey",
        "title",
        "description",
        "status",
        "priority",
        "assigneeId",
        "dueAt",
        "createdAt",
      ],
    );
  }

  async importTickets(args: {
    organizationId: string;
    requesterId: string;
    csv: string;
  }): Promise<ImportResult<{ id: string; key: string; title: string }>> {
    const rows = parseCsv(args.csv);
    const imported: { id: string; key: string; title: string }[] = [];
    const errors: { line: number; reason: string }[] = [];

    const categoryNames = Array.from(new Set(rows.map((r) => r.categoryName).filter(Boolean)));
    const categories = categoryNames.length
      ? await prisma.ticketCategory.findMany({
          where: { organizationId: args.organizationId, name: { in: categoryNames } },
        })
      : [];
    const categoriesByName = new Map(categories.map((c) => [c.name, c]));

    const orgPrefix = await this.derivePrefix(args.organizationId);

    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      const lineNumber = i + 2;
      try {
        if (!row.title) {
          errors.push({ line: lineNumber, reason: "missing_title" });
          continue;
        }
        const cat = row.categoryName ? categoriesByName.get(row.categoryName) : null;
        const created = await prisma.ticket.create({
          data: {
            organizationId: args.organizationId,
            categoryId: cat?.id ?? null,
            key: `${orgPrefix}-${Date.now().toString(36).slice(-6)}-${i}`,
            title: row.title,
            description: row.description || null,
            status: row.status || "open",
            priority: row.priority || "medium",
            requesterId: args.requesterId,
          },
          select: { id: true, key: true, title: true },
        });
        imported.push(created);
      } catch (err) {
        errors.push({
          line: lineNumber,
          reason: err instanceof Error ? err.message : "unknown",
        });
      }
    }
    return { imported, errors };
  }

  async exportTickets(args: { organizationId: string }): Promise<string> {
    const tickets = await prisma.ticket.findMany({
      where: { organizationId: args.organizationId },
      orderBy: { createdAt: "desc" },
      include: { category: { select: { name: true } } },
    });
    return serializeCsv(
      tickets.map((t) => ({
        key: t.key,
        title: t.title,
        status: t.status,
        priority: t.priority,
        categoryName: t.category?.name ?? "",
        requesterId: t.requesterId,
        assigneeId: t.assigneeId ?? "",
        resolvedAt: t.resolvedAt?.toISOString() ?? "",
        createdAt: t.createdAt.toISOString(),
      })),
      [
        "key",
        "title",
        "status",
        "priority",
        "categoryName",
        "requesterId",
        "assigneeId",
        "resolvedAt",
        "createdAt",
      ],
    );
  }

  private async derivePrefix(organizationId: string): Promise<string> {
    const org = await prisma.organization.findUnique({
      where: { id: organizationId },
      select: { slug: true },
    });
    if (!org) throw new NotFoundException();
    return org.slug.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 4) || "TKT";
  }
}
