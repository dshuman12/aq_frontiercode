import { Module } from "@nestjs/common";
import { TaskTemplatesModule } from "../task-templates/task-templates.module";
import { RecurringTasksController } from "./recurring-tasks.controller";
import { RecurringTasksService } from "./recurring-tasks.service";

@Module({
  imports: [TaskTemplatesModule],
  controllers: [RecurringTasksController],
  providers: [RecurringTasksService],
  exports: [RecurringTasksService],
})
export class RecurringTasksModule {}
