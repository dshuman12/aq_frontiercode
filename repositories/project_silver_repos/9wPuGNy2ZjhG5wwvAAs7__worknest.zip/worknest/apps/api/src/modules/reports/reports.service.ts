import { Injectable } from "@nestjs/common";
import { prisma } from "@worknest/database";

@Injectable()
export class ReportsService {
  async overview(organizationId: string) {
    const weekStart = new Date();
    weekStart.setDate(weekStart.getDate() - 7);

    const [openTasks, overdueTasks, completedThisWeek, activeProjects, openTickets, pendingRequests, pendingApprovals] =
      await Promise.all([
        prisma.task.count({
          where: { project: { organizationId }, status: { not: "done" } },
        }),
        prisma.task.count({
          where: {
            project: { organizationId },
            status: { not: "done" },
            dueAt: { lt: new Date() },
          },
        }),
        prisma.task.count({
          where: {
            project: { organizationId },
            status: "done",
            completedAt: { gte: weekStart },
          },
        }),
        prisma.project.count({ where: { organizationId, archivedAt: null } }),
        prisma.ticket.count({ where: { organizationId, status: { in: ["open", "pending", "in_progress"] } } }),
        prisma.requestSubmission.count({ where: { organizationId, status: "submitted" } }),
        prisma.approvalDecision.count({
          where: { workflow: { organizationId }, status: "pending" },
        }),
      ]);

    return {
      openTasks,
      overdueTasks,
      completedThisWeek,
      activeProjects,
      openTickets,
      pendingRequests,
      pendingApprovals,
    };
  }

  async teamWorkload(organizationId: string) {
    const members = await prisma.organizationMember.findMany({
      where: { organizationId },
      include: { user: true },
    });
    return Promise.all(
      members.map(async (m) => ({
        userId: m.userId,
        name: m.user.name,
        openTasks: await prisma.task.count({
          where: {
            project: { organizationId },
            assigneeId: m.userId,
            status: { not: "done" },
          },
        }),
        overdueTasks: await prisma.task.count({
          where: {
            project: { organizationId },
            assigneeId: m.userId,
            status: { not: "done" },
            dueAt: { lt: new Date() },
          },
        }),
        ticketsAssigned: await prisma.ticket.count({
          where: { organizationId, assigneeId: m.userId, status: { not: "closed" } },
        }),
      })),
    );
  }

  async projectProgress(projectId: string) {
    const [total, done] = await Promise.all([
      prisma.task.count({ where: { projectId } }),
      prisma.task.count({ where: { projectId, status: "done" } }),
    ]);
    const milestones = await prisma.milestone.count({ where: { projectId } });
    const completedMilestones = await prisma.milestone.count({
      where: { projectId, completedAt: { not: null } },
    });
    return {
      tasks: { total, done, ratio: total === 0 ? 0 : done / total },
      milestones: { total: milestones, done: completedMilestones },
    };
  }

  async ticketSlaSummary(organizationId: string) {
    // Approximate SLA reporting from status history.
    const tickets = await prisma.ticket.findMany({
      where: { organizationId },
      select: { id: true, createdAt: true, resolvedAt: true, priority: true },
    });
    const samples = tickets
      .filter((t) => t.resolvedAt)
      .map((t) => ({
        priority: t.priority,
        hours: (t.resolvedAt!.getTime() - t.createdAt.getTime()) / 3_600_000,
      }));
    const byPriority: Record<string, { count: number; total: number }> = {};
    for (const s of samples) {
      byPriority[s.priority] ||= { count: 0, total: 0 };
      byPriority[s.priority].count += 1;
      byPriority[s.priority].total += s.hours;
    }
    return Object.entries(byPriority).map(([priority, agg]) => ({
      priority,
      count: agg.count,
      averageResolutionHours: Number.parseFloat((agg.total / agg.count).toFixed(2)),
    }));
  }

  async exportTasksCsv(organizationId: string): Promise<string> {
    const tasks = await prisma.task.findMany({
      where: { project: { organizationId } },
      include: { project: true, assignee: { select: { name: true, email: true } } },
      orderBy: { createdAt: "desc" },
    });
    const header = "key,title,project,status,priority,assignee,created_at,completed_at";
    const rows = tasks.map((t) =>
      [
        t.key,
        csv(t.title),
        csv(t.project.name),
        t.status,
        t.priority,
        csv(t.assignee?.name ?? ""),
        t.createdAt.toISOString(),
        t.completedAt?.toISOString() ?? "",
      ].join(","),
    );
    return [header, ...rows].join("\n");
  }

  async exportTicketsCsv(organizationId: string): Promise<string> {
    const tickets = await prisma.ticket.findMany({
      where: { organizationId },
      include: { category: true },
      orderBy: { createdAt: "desc" },
    });
    const header = "key,title,category,status,priority,created_at,resolved_at";
    const rows = tickets.map((t) =>
      [
        t.key,
        csv(t.title),
        csv(t.category?.name ?? ""),
        t.status,
        t.priority,
        t.createdAt.toISOString(),
        t.resolvedAt?.toISOString() ?? "",
      ].join(","),
    );
    return [header, ...rows].join("\n");
  }
}

function csv(value: string): string {
  if (/[",\n]/.test(value)) return `"${value.replace(/"/g, '""')}"`;
  return value;
}
