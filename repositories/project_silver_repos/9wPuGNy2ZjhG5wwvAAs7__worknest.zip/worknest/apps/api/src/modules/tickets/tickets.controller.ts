import { Body, Controller, Delete, Get, Param, Patch, Post, Query, UseGuards, UsePipes } from "@nestjs/common";
import { AuthGuard } from "../../common/auth.guard";
import { CurrentOrgId, CurrentUser } from "../../common/current-user.decorator";
import { RequiresPermission } from "../../common/permissions.guard";
import { ZodPipe } from "../../common/zod.pipe";
import {
  AddWatcherSchema,
  CreateTicketCategorySchema,
  CreateTicketSchema,
  TicketCommentSchema,
  TransitionTicketSchema,
  UpdateTicketSchema,
} from "@worknest/validators";
import { TicketsService } from "./tickets.service";

@UseGuards(AuthGuard)
@Controller("tickets")
export class TicketsController {
  constructor(private readonly tickets: TicketsService) {}

  @Get()
  @RequiresPermission("tickets:read")
  list(
    @CurrentOrgId() orgId: string,
    @Query("status") status?: string,
    @Query("assigneeId") assigneeId?: string,
    @Query("categoryId") categoryId?: string,
    @Query("q") q?: string,
    @Query("page") page?: string,
    @Query("pageSize") pageSize?: string,
  ) {
    return this.tickets.list(orgId, {
      status,
      assigneeId,
      categoryId,
      q,
      page: page ? Number(page) : undefined,
      pageSize: pageSize ? Number(pageSize) : undefined,
    });
  }

  @Get("categories")
  @RequiresPermission("tickets:read")
  listCategories(@CurrentOrgId() orgId: string) {
    return this.tickets.listCategories(orgId);
  }

  @Post("categories")
  @RequiresPermission("tickets:categories:write")
  @UsePipes(new ZodPipe(CreateTicketCategorySchema))
  createCategory(@CurrentOrgId() orgId: string, @Body() body: any) {
    return this.tickets.createCategory(orgId, body);
  }

  @Patch("categories/:id")
  @RequiresPermission("tickets:categories:write")
  updateCategory(@Param("id") id: string, @Body() body: any) {
    return this.tickets.updateCategory(id, body);
  }

  @Delete("categories/:id")
  @RequiresPermission("tickets:categories:write")
  deleteCategory(@Param("id") id: string) {
    return this.tickets.deleteCategory(id);
  }

  @Get(":id")
  @RequiresPermission("tickets:read")
  byId(@Param("id") id: string) {
    return this.tickets.byId(id);
  }

  @Post()
  @RequiresPermission("tickets:create")
  @UsePipes(new ZodPipe(CreateTicketSchema))
  create(
    @CurrentOrgId() orgId: string,
    @CurrentUser() u: { sub: string },
    @Body() body: any,
  ) {
    return this.tickets.create({ ...body, organizationId: orgId, requesterId: u.sub });
  }

  @Patch(":id")
  @RequiresPermission("tickets:update")
  @UsePipes(new ZodPipe(UpdateTicketSchema))
  update(@Param("id") id: string, @Body() body: any) {
    return this.tickets.update(id, body);
  }

  @Post(":id/transition")
  @RequiresPermission("tickets:update")
  @UsePipes(new ZodPipe(TransitionTicketSchema))
  transition(
    @CurrentUser() u: { sub: string },
    @Param("id") id: string,
    @Body() body: { toStatus: string; note?: string },
  ) {
    return this.tickets.transition(id, u.sub, body.toStatus, body.note);
  }

  @Post(":id/comments")
  @RequiresPermission("tickets:comment")
  @UsePipes(new ZodPipe(TicketCommentSchema))
  addComment(
    @CurrentUser() u: { sub: string },
    @Param("id") id: string,
    @Body() body: { body: string; internal: boolean },
  ) {
    return this.tickets.addComment(id, u.sub, body.body, body.internal);
  }

  @Get(":id/history")
  @RequiresPermission("tickets:read")
  history(@Param("id") id: string) {
    return this.tickets.statusHistory(id);
  }

  @Post(":id/watchers")
  @RequiresPermission("tickets:watchers:add")
  @UsePipes(new ZodPipe(AddWatcherSchema))
  addWatcher(@Param("id") id: string, @Body() body: { userId: string }) {
    return this.tickets.addWatcher(id, body.userId);
  }

  @Delete(":id/watchers/:userId")
  @RequiresPermission("tickets:watchers:add")
  removeWatcher(@Param("id") id: string, @Param("userId") userId: string) {
    return this.tickets.removeWatcher(id, userId);
  }
}
