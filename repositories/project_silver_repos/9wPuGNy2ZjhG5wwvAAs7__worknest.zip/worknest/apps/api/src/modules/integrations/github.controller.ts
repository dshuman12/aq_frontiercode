/**
 * GitHub webhook receiver. Verifies the X-Hub-Signature-256 header
 * against the configured per-org secret, then converts a small set
 * of events into WorkNest tickets.
 *
 * Events handled:
 *   - issues.opened       → ticket created (priority=medium)
 *   - issue_comment.created → ticket comment appended
 *   - workflow_run.failure → ticket created with priority=high
 *
 * Anything else is a 200 no-op so GitHub doesn't retry.
 */
import { Body, Controller, Headers, Post, RawBodyRequest, Req, UnauthorizedException } from "@nestjs/common";
import { createHmac, timingSafeEqual } from "node:crypto";
import { prisma } from "@worknest/database";
import { Public } from "../../common/permissions.guard";
import { logger } from "@worknest/logger";

const log = logger("integrations/github");

@Controller("integrations/github")
export class GithubWebhookController {
  @Public()
  @Post("webhook")
  async webhook(
    @Headers("x-hub-signature-256") signature: string,
    @Headers("x-github-event") event: string,
    @Headers("x-worknest-org") orgId: string,
    @Body() body: any,
    @Req() req: RawBodyRequest<Request>,
  ): Promise<{ ok: true }> {
    if (!orgId) throw new UnauthorizedException("missing_org_header");
    const secret = process.env.GITHUB_WEBHOOK_SECRET ?? "";
    const raw = req.rawBody?.toString("utf8") ?? JSON.stringify(body);
    if (!verifyGithubSignature(raw, signature ?? "", secret)) {
      throw new UnauthorizedException("invalid_signature");
    }

    if (event === "issues" && body?.action === "opened" && body?.issue) {
      const issue = body.issue;
      await prisma.ticket.create({
        data: {
          organizationId: orgId,
          key: `GH-${issue.number}`,
          title: issue.title.slice(0, 200),
          description: issue.body?.slice(0, 5000) ?? null,
          priority: "medium",
          status: "open",
          requesterId: "automation",
        },
      });
      return { ok: true };
    }
    if (event === "workflow_run" && body?.workflow_run?.conclusion === "failure") {
      const run = body.workflow_run;
      await prisma.ticket.create({
        data: {
          organizationId: orgId,
          key: `GH-CI-${run.id.toString().slice(-6)}`,
          title: `CI failure: ${run.name}`,
          description: `${run.head_branch} @ ${run.head_sha?.slice(0, 7)} — ${run.html_url}`,
          priority: "high",
          status: "open",
          requesterId: "automation",
        },
      });
      return { ok: true };
    }
    log.debug({ event, action: body?.action }, "github_webhook_no_op");
    return { ok: true };
  }
}

export function verifyGithubSignature(raw: string, signature: string, secret: string): boolean {
  if (!signature.startsWith("sha256=") || !secret) return false;
  const expected = "sha256=" + createHmac("sha256", secret).update(raw).digest("hex");
  if (expected.length !== signature.length) return false;
  return timingSafeEqual(Buffer.from(expected), Buffer.from(signature));
}
