import { BadRequestException, Injectable, NotFoundException } from "@nestjs/common";
import { prisma } from "@worknest/database";
import { logger } from "@worknest/logger";

const log = logger("api/approvals");

@Injectable()
export class ApprovalsService {
  async listWorkflows(organizationId: string) {
    return prisma.approvalWorkflow.findMany({
      where: { organizationId },
      include: { steps: { orderBy: { order: "asc" } } },
      orderBy: { name: "asc" },
    });
  }

  async getWorkflow(id: string) {
    const wf = await prisma.approvalWorkflow.findUnique({
      where: { id },
      include: { steps: { orderBy: { order: "asc" } } },
    });
    if (!wf) throw new NotFoundException();
    return wf;
  }

  async createWorkflow(organizationId: string, input: {
    name: string;
    description?: string;
    appliesTo: string;
    enabled?: boolean;
    steps: { order: number; name: string; approverId?: string; approverRole?: string; condition?: string; escalateAfterMinutes?: number }[];
  }) {
    return prisma.$transaction(async (tx) => {
      const wf = await tx.approvalWorkflow.create({
        data: {
          organizationId,
          name: input.name,
          description: input.description,
          appliesTo: input.appliesTo,
          enabled: input.enabled ?? true,
        },
      });
      for (const s of input.steps) {
        await tx.approvalStep.create({
          data: {
            workflowId: wf.id,
            order: s.order,
            name: s.name,
            approverId: s.approverId,
            approverRole: s.approverRole,
            condition: s.condition,
            escalateAfterMinutes: s.escalateAfterMinutes,
          },
        });
      }
      return wf;
    });
  }

  async updateWorkflow(id: string, patch: Record<string, unknown>) {
    return prisma.approvalWorkflow.update({ where: { id }, data: patch as never });
  }

  async deleteWorkflow(id: string) {
    await prisma.approvalWorkflow.delete({ where: { id } });
    return { ok: true };
  }

  async pendingFor(approverId: string, organizationId: string) {
    return prisma.approvalDecision.findMany({
      where: {
        status: "pending",
        approverId,
        workflow: { organizationId },
      },
      include: { workflow: true, step: true, submission: true },
      orderBy: { createdAt: "asc" },
    });
  }

  async decidedFor(approverId: string, limit = 50) {
    return prisma.approvalDecision.findMany({
      where: { approverId, status: { in: ["approved", "rejected"] } },
      orderBy: { decidedAt: "desc" },
      take: limit,
      include: { workflow: true, step: true, submission: true },
    });
  }

  async decide(decisionId: string, approverId: string, decision: "approved" | "rejected", reason?: string) {
    const row = await prisma.approvalDecision.findUnique({ where: { id: decisionId } });
    if (!row) throw new NotFoundException();
    if (row.approverId !== approverId) throw new BadRequestException("not_assigned");
    if (row.status !== "pending") throw new BadRequestException(`already ${row.status}`);
    const updated = await prisma.approvalDecision.update({
      where: { id: decisionId },
      data: { status: decision, decidedAt: new Date(), reason },
    });
    log.info({ decisionId, decision, approverId }, "approval decided");
    return updated;
  }

  async resubmit(decisionId: string, reason?: string) {
    const row = await prisma.approvalDecision.findUnique({ where: { id: decisionId } });
    if (!row) throw new NotFoundException();
    if (row.status !== "rejected") {
      throw new BadRequestException("only_rejected_can_resubmit");
    }
    return prisma.approvalDecision.update({
      where: { id: decisionId },
      data: { status: "pending", decidedAt: null, reason },
    });
  }

  /**
   * Walks the workflow's steps in order; finds the first step matching the
   * incoming submission. Returns the step that should be created as a
   * pending decision. Conditions are simple equality checks against
   * submission.fieldValues.
   */
  async resolveNextStep(workflowId: string, submissionId: string) {
    const wf = await this.getWorkflow(workflowId);
    const submission = await prisma.requestSubmission.findUnique({
      where: { id: submissionId },
      include: { fieldValues: true },
    });
    if (!submission) return null;
    const map: Record<string, string> = {};
    for (const v of submission.fieldValues) map[v.key] = v.value ?? "";
    for (const s of wf.steps) {
      if (!s.condition || this.matches(s.condition, map)) return s;
    }
    return null;
  }

  private matches(condition: string, fields: Record<string, string>): boolean {
    const m = condition.match(/^(\w+)\s*(==|!=|<=|>=|<|>)\s*(.*)$/);
    if (!m) return false;
    const [, key, op, raw] = m;
    const left = fields[key] ?? "";
    const right = raw.trim().replace(/^['"]|['"]$/g, "");
    if (op === "==") return left === right;
    if (op === "!=") return left !== right;
    const ln = Number(left);
    const rn = Number(right);
    if (Number.isNaN(ln) || Number.isNaN(rn)) return false;
    if (op === ">") return ln > rn;
    if (op === ">=") return ln >= rn;
    if (op === "<") return ln < rn;
    if (op === "<=") return ln <= rn;
    return false;
  }
}
