/**
 * Bulk operations for tasks and tickets. We deliberately keep a tight
 * field allow-list per resource — bulk endpoints are operator-facing
 * footguns, and limiting them to the safe-by-default mutations
 * (status/priority/assignee/sprint/labels) matches what the UI needs.
 *
 * Cross-tenant safety: every bulk write is scoped to the requesting
 * organization via a join filter, so an operator can't accidentally
 * (or deliberately) bulk-update tasks from another organization by
 * crafting a list of IDs.
 */
import { BadRequestException, Injectable } from "@nestjs/common";
import { prisma } from "@worknest/database";

@Injectable()
export class BulkService {
  async updateTasks(args: {
    organizationId: string;
    ids: string[];
    patch: Record<string, unknown>;
  }) {
    if (args.ids.length === 0) throw new BadRequestException("ids_empty");
    return prisma.$transaction(async (tx) => {
      const inOrg = await tx.task.findMany({
        where: {
          id: { in: args.ids },
          project: { organizationId: args.organizationId },
        },
        select: { id: true },
      });
      const ids = inOrg.map((t) => t.id);
      if (ids.length === 0) return { updated: 0, requested: args.ids.length };
      await tx.task.updateMany({ where: { id: { in: ids } }, data: args.patch });
      return { updated: ids.length, requested: args.ids.length };
    });
  }

  async deleteTasks(args: { organizationId: string; ids: string[] }) {
    return prisma.$transaction(async (tx) => {
      const inOrg = await tx.task.findMany({
        where: {
          id: { in: args.ids },
          project: { organizationId: args.organizationId },
        },
        select: { id: true },
      });
      const ids = inOrg.map((t) => t.id);
      const result = await tx.task.deleteMany({ where: { id: { in: ids } } });
      return { deleted: result.count, requested: args.ids.length };
    });
  }

  async updateTickets(args: {
    organizationId: string;
    ids: string[];
    patch: Record<string, unknown>;
  }) {
    if (args.ids.length === 0) throw new BadRequestException("ids_empty");
    const result = await prisma.ticket.updateMany({
      where: { id: { in: args.ids }, organizationId: args.organizationId },
      data: args.patch,
    });
    return { updated: result.count, requested: args.ids.length };
  }

  /**
   * Bulk-apply task labels by name. Labels in this schema are per-task
   * strings (no global label catalog), so we operate on (taskId, name)
   * pairs. add: union; remove: subtract; replace: clear-then-set.
   */
  async applyTaskLabels(args: {
    organizationId: string;
    ids: string[];
    labels: string[];
    mode: "add" | "remove" | "replace";
  }) {
    return prisma.$transaction(async (tx) => {
      const tasks = await tx.task.findMany({
        where: {
          id: { in: args.ids },
          project: { organizationId: args.organizationId },
        },
        select: { id: true },
      });
      const taskIds = tasks.map((t) => t.id);
      if (taskIds.length === 0) {
        return { affected: 0, requested: args.ids.length };
      }
      if (args.mode === "replace") {
        await tx.taskLabel.deleteMany({ where: { taskId: { in: taskIds } } });
      }
      if (args.mode === "remove") {
        await tx.taskLabel.deleteMany({
          where: { taskId: { in: taskIds }, name: { in: args.labels } },
        });
      }
      if (args.mode === "add" || args.mode === "replace") {
        // Avoid duplicate (taskId, name) rows when adding to tasks that
        // already have one of the labels.
        const existing = await tx.taskLabel.findMany({
          where: { taskId: { in: taskIds }, name: { in: args.labels } },
          select: { taskId: true, name: true },
        });
        const have = new Set(existing.map((e) => `${e.taskId}::${e.name}`));
        const toCreate = taskIds.flatMap((taskId) =>
          args.labels
            .filter((name) => !have.has(`${taskId}::${name}`))
            .map((name) => ({ taskId, name })),
        );
        if (toCreate.length) {
          await tx.taskLabel.createMany({ data: toCreate });
        }
      }
      return { affected: taskIds.length, requested: args.ids.length };
    });
  }
}
