/**
 * Mentions parser. Finds `@username` and `@<userId>` patterns in a
 * comment body and resolves them to user ids. Username form requires
 * a tenant-scoped lookup (we accept email prefix for the demo); the
 * `@<id>` form is what the editor produces in production.
 */

const ID_PATTERN = /@<([a-zA-Z0-9_-]{6,})>/g;
const HANDLE_PATTERN = /@([a-zA-Z][a-zA-Z0-9._-]{1,40})/g;

export interface MentionParseResult {
  ids: string[];
  handles: string[];
}

export function parseMentions(body: string): MentionParseResult {
  const ids: string[] = [];
  const handles: string[] = [];
  for (const match of body.matchAll(ID_PATTERN)) {
    ids.push(match[1]);
  }
  for (const match of body.matchAll(HANDLE_PATTERN)) {
    if (!match[1].startsWith("<")) handles.push(match[1].toLowerCase());
  }
  return {
    ids: Array.from(new Set(ids)),
    handles: Array.from(new Set(handles)),
  };
}
