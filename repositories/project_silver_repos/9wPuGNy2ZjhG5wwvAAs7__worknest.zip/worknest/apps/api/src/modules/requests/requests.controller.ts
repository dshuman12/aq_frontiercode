import { Body, Controller, Delete, Get, Param, Patch, Post, Query, UseGuards, UsePipes } from "@nestjs/common";
import { AuthGuard } from "../../common/auth.guard";
import { CurrentOrgId, CurrentUser } from "../../common/current-user.decorator";
import { RequiresPermission } from "../../common/permissions.guard";
import { ZodPipe } from "../../common/zod.pipe";
import {
  CreateRequestFormSchema,
  RequestCommentSchema,
  SubmitRequestSchema,
  TransitionRequestSchema,
  UpdateRequestFormSchema,
} from "@worknest/validators";
import { RequestsService } from "./requests.service";

@UseGuards(AuthGuard)
@Controller("requests")
export class RequestsController {
  constructor(private readonly requests: RequestsService) {}

  @Get("forms")
  @RequiresPermission("request-forms:read")
  listForms(@CurrentOrgId() orgId: string) {
    return this.requests.listForms(orgId);
  }

  @Get("forms/:id")
  @RequiresPermission("request-forms:read")
  getForm(@Param("id") id: string) {
    return this.requests.getForm(id);
  }

  @Post("forms")
  @RequiresPermission("request-forms:write")
  @UsePipes(new ZodPipe(CreateRequestFormSchema))
  createForm(@CurrentOrgId() orgId: string, @Body() body: any) {
    return this.requests.createForm(orgId, body);
  }

  @Patch("forms/:id")
  @RequiresPermission("request-forms:write")
  @UsePipes(new ZodPipe(UpdateRequestFormSchema))
  updateForm(@Param("id") id: string, @Body() body: any) {
    return this.requests.updateForm(id, body);
  }

  @Delete("forms/:id")
  @RequiresPermission("request-forms:write")
  archiveForm(@Param("id") id: string) {
    return this.requests.archiveForm(id);
  }

  @Get()
  @RequiresPermission("requests:read")
  list(
    @CurrentOrgId() orgId: string,
    @Query("status") status?: string,
    @Query("formId") formId?: string,
    @Query("assigneeId") assigneeId?: string,
  ) {
    return this.requests.listSubmissions(orgId, { status, formId, assigneeId });
  }

  @Get(":id")
  @RequiresPermission("requests:read")
  byId(@Param("id") id: string) {
    return this.requests.getSubmission(id);
  }

  @Post()
  @RequiresPermission("requests:submit")
  @UsePipes(new ZodPipe(SubmitRequestSchema))
  submit(
    @CurrentOrgId() orgId: string,
    @CurrentUser() u: { sub: string },
    @Body() body: any,
  ) {
    return this.requests.submit({ ...body, organizationId: orgId, submitterId: u.sub });
  }

  @Post(":id/transition")
  @RequiresPermission("requests:transition")
  @UsePipes(new ZodPipe(TransitionRequestSchema))
  transition(
    @CurrentUser() u: { sub: string },
    @Param("id") id: string,
    @Body() body: { toStatus: string; note?: string },
  ) {
    return this.requests.transition(id, u.sub, body.toStatus, body.note);
  }

  @Post(":id/assign")
  @RequiresPermission("requests:assign")
  assign(@Param("id") id: string, @Body() body: { assigneeId: string | null }) {
    return this.requests.assign(id, body.assigneeId);
  }

  @Post(":id/comments")
  @RequiresPermission("requests:comment")
  @UsePipes(new ZodPipe(RequestCommentSchema))
  comment(
    @CurrentUser() u: { sub: string },
    @Param("id") id: string,
    @Body() body: { body: string; internal: boolean },
  ) {
    return this.requests.addComment(id, u.sub, body.body, body.internal);
  }
}
