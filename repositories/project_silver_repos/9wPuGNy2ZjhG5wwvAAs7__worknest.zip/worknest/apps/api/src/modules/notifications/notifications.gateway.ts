import {
  ConnectedSocket,
  MessageBody,
  OnGatewayConnection,
  OnGatewayDisconnect,
  SubscribeMessage,
  WebSocketGateway,
  WebSocketServer,
} from "@nestjs/websockets";
import { Server, Socket } from "socket.io";
import { logger } from "@worknest/logger";
import { verifyAccessToken } from "@worknest/auth";

const log = logger("api/realtime");

interface SocketAuth {
  userId: string;
  orgId: string;
}

@WebSocketGateway({
  namespace: "/realtime",
  cors: { origin: process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000", credentials: true },
})
export class NotificationsGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer() io!: Server;

  private readonly auths = new WeakMap<Socket, SocketAuth>();

  handleConnection(socket: Socket) {
    const token = (socket.handshake.auth?.token ?? "") as string;
    const secret = process.env.JWT_ACCESS_SECRET;
    if (!token || !secret) {
      socket.emit("error", { code: "unauthenticated" });
      socket.disconnect(true);
      return;
    }
    try {
      const claims = verifyAccessToken(token, secret);
      const auth: SocketAuth = { userId: claims.sub, orgId: claims.orgId };
      this.auths.set(socket, auth);
      socket.join(`user:${auth.userId}`);
      socket.join(`org:${auth.orgId}`);
      log.info({ userId: auth.userId, orgId: auth.orgId }, "socket connected");
    } catch {
      socket.emit("error", { code: "invalid_token" });
      socket.disconnect(true);
    }
  }

  handleDisconnect(socket: Socket) {
    const auth = this.auths.get(socket);
    if (auth) log.info({ userId: auth.userId }, "socket disconnected");
  }

  @SubscribeMessage("subscribe")
  handleSubscribe(@ConnectedSocket() socket: Socket, @MessageBody() body: { channel: string }) {
    const auth = this.auths.get(socket);
    if (!auth) return;
    if (!body.channel || !/^(task|ticket|request|approval|presence):[a-z0-9]+$/i.test(body.channel)) return;
    socket.join(body.channel);
  }

  @SubscribeMessage("unsubscribe")
  handleUnsubscribe(@ConnectedSocket() socket: Socket, @MessageBody() body: { channel: string }) {
    socket.leave(body.channel);
  }

  emitToUser(userId: string, event: string, payload: unknown) {
    this.io.to(`user:${userId}`).emit(event, payload);
  }

  emitToOrg(orgId: string, event: string, payload: unknown) {
    this.io.to(`org:${orgId}`).emit(event, payload);
  }

  emitToChannel(channel: string, event: string, payload: unknown) {
    this.io.to(channel).emit(event, payload);
  }
}
