/**
 * Unit-level check on the breach math: a timer is breached when the
 * due-by is in the past *and* the corresponding "met" is null. The
 * sweep is idempotent — once flipped on, breach stays on even if you
 * later log the response/resolution.
 */
import { describe, expect, it } from "vitest";

interface Timer {
  firstResponseDueAt: Date;
  firstResponseMetAt: Date | null;
  resolutionDueAt: Date;
  resolutionMetAt: Date | null;
  breachedFirstResponse: boolean;
  breachedResolution: boolean;
}

function classify(t: Timer, now = Date.now()): { firstResp: boolean; resolution: boolean } {
  const firstResp =
    t.breachedFirstResponse ||
    (!t.firstResponseMetAt && now > t.firstResponseDueAt.getTime());
  const resolution =
    t.breachedResolution || (!t.resolutionMetAt && now > t.resolutionDueAt.getTime());
  return { firstResp, resolution };
}

describe("SLA breach classification", () => {
  it("not breached when due is in the future", () => {
    const future = new Date(Date.now() + 60 * 60_000);
    const t: Timer = {
      firstResponseDueAt: future,
      firstResponseMetAt: null,
      resolutionDueAt: future,
      resolutionMetAt: null,
      breachedFirstResponse: false,
      breachedResolution: false,
    };
    const c = classify(t);
    expect(c.firstResp).toBe(false);
    expect(c.resolution).toBe(false);
  });

  it("breached when due is past and not met", () => {
    const past = new Date(Date.now() - 60 * 60_000);
    const t: Timer = {
      firstResponseDueAt: past,
      firstResponseMetAt: null,
      resolutionDueAt: past,
      resolutionMetAt: null,
      breachedFirstResponse: false,
      breachedResolution: false,
    };
    const c = classify(t);
    expect(c.firstResp).toBe(true);
    expect(c.resolution).toBe(true);
  });

  it("met-after-breach still reports as breach", () => {
    const past = new Date(Date.now() - 60 * 60_000);
    const t: Timer = {
      firstResponseDueAt: past,
      firstResponseMetAt: new Date(),
      resolutionDueAt: past,
      resolutionMetAt: new Date(),
      breachedFirstResponse: true,
      breachedResolution: true,
    };
    const c = classify(t);
    expect(c.firstResp).toBe(true);
    expect(c.resolution).toBe(true);
  });
});
