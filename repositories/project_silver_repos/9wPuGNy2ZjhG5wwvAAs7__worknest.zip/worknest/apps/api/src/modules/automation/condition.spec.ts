/**
 * Condition predicates are intentionally tiny — eq/ne/in/is_null on
 * top-level fields. The test pins that "no condition" is a pass-through
 * (an empty rule fires on every trigger), and that `in` membership
 * does not silently coerce types.
 */
import { describe, expect, it } from "vitest";
import { evaluateCondition } from "./automation.service";

describe("automation condition", () => {
  it("null condition matches everything", () => {
    expect(evaluateCondition(null, { status: "open" })).toBe(true);
  });
  it("empty condition matches everything", () => {
    expect(evaluateCondition([], { status: "open" })).toBe(true);
  });
  it("eq matches", () => {
    expect(
      evaluateCondition([{ field: "status", op: "eq", value: "open" }], { status: "open" }),
    ).toBe(true);
  });
  it("eq doesn't match wrong type", () => {
    expect(
      evaluateCondition([{ field: "priority", op: "eq", value: 1 }], { priority: "1" }),
    ).toBe(false);
  });
  it("in matches when value is in array", () => {
    expect(
      evaluateCondition(
        [{ field: "priority", op: "in", value: ["high", "urgent"] }],
        { priority: "urgent" },
      ),
    ).toBe(true);
  });
  it("is_null only matches null/undefined", () => {
    expect(
      evaluateCondition([{ field: "assigneeId", op: "is_null" }], { assigneeId: null }),
    ).toBe(true);
    expect(
      evaluateCondition([{ field: "assigneeId", op: "is_null" }], { assigneeId: "u1" }),
    ).toBe(false);
  });
});
