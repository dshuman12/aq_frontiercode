import { Body, Controller, Get, Param, Patch, Post, Query, UseGuards, UsePipes } from "@nestjs/common";
import { AuthGuard } from "../../common/auth.guard";
import { CurrentOrgId, CurrentUser } from "../../common/current-user.decorator";
import { RequiresPermission } from "../../common/permissions.guard";
import { ZodPipe } from "../../common/zod.pipe";
import {
  AssignAssetSchema,
  CreateAssetCategorySchema,
  CreateAssetSchema,
  MaintenanceRecordSchema,
  ReturnAssetSchema,
  UpdateAssetSchema,
} from "@worknest/validators";
import { AssetsService } from "./assets.service";

@UseGuards(AuthGuard)
@Controller("assets")
export class AssetsController {
  constructor(private readonly assets: AssetsService) {}

  @Get()
  @RequiresPermission("assets:read")
  list(
    @CurrentOrgId() orgId: string,
    @Query("categoryId") categoryId?: string,
    @Query("status") status?: string,
    @Query("q") q?: string,
  ) {
    return this.assets.list(orgId, { categoryId, status, q });
  }

  @Get("warranty-expiring")
  @RequiresPermission("assets:read")
  warranty(@CurrentOrgId() orgId: string, @Query("days") days?: string) {
    return this.assets.warrantyExpiring(orgId, days ? Number(days) : 30);
  }

  @Get("categories")
  @RequiresPermission("assets:read")
  listCategories(@CurrentOrgId() orgId: string) {
    return this.assets.listCategories(orgId);
  }

  @Post("categories")
  @RequiresPermission("asset-categories:write")
  @UsePipes(new ZodPipe(CreateAssetCategorySchema))
  createCategory(@CurrentOrgId() orgId: string, @Body() body: any) {
    return this.assets.createCategory(orgId, body);
  }

  @Get(":id")
  @RequiresPermission("assets:read")
  byId(@Param("id") id: string) {
    return this.assets.byId(id);
  }

  @Post()
  @RequiresPermission("assets:create")
  @UsePipes(new ZodPipe(CreateAssetSchema))
  create(@CurrentOrgId() orgId: string, @Body() body: any) {
    return this.assets.create(orgId, body);
  }

  @Patch(":id")
  @RequiresPermission("assets:update")
  @UsePipes(new ZodPipe(UpdateAssetSchema))
  update(@Param("id") id: string, @Body() body: any) {
    return this.assets.update(id, body);
  }

  @Post(":id/assign")
  @RequiresPermission("assets:assign")
  @UsePipes(new ZodPipe(AssignAssetSchema))
  assign(@CurrentUser() u: { sub: string }, @Param("id") id: string, @Body() body: any) {
    return this.assets.assign(id, { ...body, actorId: u.sub });
  }

  @Post(":id/return")
  @RequiresPermission("assets:return")
  @UsePipes(new ZodPipe(ReturnAssetSchema))
  return_(@Param("id") id: string, @Body() body: { condition: "good" | "damaged" | "lost"; note?: string }) {
    return this.assets.return_(id, body.condition, body.note);
  }

  @Post(":id/retire")
  @RequiresPermission("assets:retire")
  retire(@Param("id") id: string) {
    return this.assets.retire(id);
  }

  @Get(":id/assignments")
  @RequiresPermission("assets:read")
  assignments(@Param("id") id: string) {
    return this.assets.assignments(id);
  }

  @Get(":id/maintenance")
  @RequiresPermission("assets:read")
  maintenance(@Param("id") id: string) {
    return this.assets.maintenance(id);
  }

  @Post(":id/maintenance")
  @RequiresPermission("assets:maintenance:write")
  @UsePipes(new ZodPipe(MaintenanceRecordSchema))
  recordMaintenance(@Param("id") id: string, @Body() body: any) {
    return this.assets.recordMaintenance({ assetId: id, ...body });
  }
}
