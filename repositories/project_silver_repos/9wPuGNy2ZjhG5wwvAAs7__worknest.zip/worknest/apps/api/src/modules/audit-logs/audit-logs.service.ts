import { Injectable } from "@nestjs/common";
import { prisma } from "@worknest/database";

@Injectable()
export class AuditLogsService {
  async list(organizationId: string, opts: {
    page?: number;
    pageSize?: number;
    action?: string;
    resource?: string;
    actorId?: string;
    q?: string;
  }) {
    const page = Math.max(1, opts.page ?? 1);
    const pageSize = Math.min(200, Math.max(1, opts.pageSize ?? 50));
    const where: Record<string, unknown> = { organizationId };
    if (opts.action) where.action = opts.action;
    if (opts.resource) where.resource = opts.resource;
    if (opts.actorId) where.actorId = opts.actorId;
    if (opts.q) {
      where.OR = [
        { resourceId: { contains: opts.q } },
        { ip: { contains: opts.q } },
      ];
    }
    const [items, total] = await Promise.all([
      prisma.auditLog.findMany({
        where,
        skip: (page - 1) * pageSize,
        take: pageSize,
        orderBy: { createdAt: "desc" },
      }),
      prisma.auditLog.count({ where }),
    ]);
    return { items, total, page, pageSize };
  }

  async forResource(resource: string, resourceId: string) {
    return prisma.auditLog.findMany({
      where: { resource, resourceId },
      orderBy: { createdAt: "desc" },
    });
  }

  async record(input: {
    organizationId: string;
    actorId: string | null;
    action: string;
    resource: string;
    resourceId: string;
    diff?: unknown;
    ip?: string;
    userAgent?: string;
  }) {
    return prisma.auditLog.create({
      data: {
        organizationId: input.organizationId,
        actorId: input.actorId,
        action: input.action,
        resource: input.resource,
        resourceId: input.resourceId,
        diff: input.diff as never,
        ip: input.ip,
        userAgent: input.userAgent,
      },
    });
  }
}
