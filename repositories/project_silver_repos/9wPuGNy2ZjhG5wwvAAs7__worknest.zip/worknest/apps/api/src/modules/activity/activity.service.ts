/**
 * Unified org-wide activity stream. Feature modules call `record(...)`
 * after a state change; readers query with optional filters.
 *
 * We keep this separate from the per-resource ProjectActivity /
 * TaskActivity rows because the unified stream optimizes for an
 * "everyone's recent updates" view. The two stay in sync via the
 * convention that anything worth showing on a resource page also
 * gets recorded here.
 */
import { Injectable } from "@nestjs/common";
import { prisma } from "@worknest/database";

@Injectable()
export class ActivityService {
  async record(args: {
    organizationId: string;
    actorId?: string | null;
    resource: string;
    resourceId: string;
    verb: string;
    summary: string;
    payload?: Record<string, unknown>;
  }) {
    return prisma.activityEvent.create({
      data: {
        organizationId: args.organizationId,
        actorId: args.actorId ?? null,
        resource: args.resource,
        resourceId: args.resourceId,
        verb: args.verb,
        summary: args.summary,
        payload: (args.payload ?? undefined) as object | undefined,
      },
    });
  }

  async list(args: {
    organizationId: string;
    resource?: string;
    resourceId?: string;
    actorId?: string;
    fromDate?: Date;
    toDate?: Date;
    page?: number;
    pageSize?: number;
  }) {
    const page = args.page ?? 1;
    const pageSize = Math.min(200, args.pageSize ?? 50);
    const where: Record<string, unknown> = { organizationId: args.organizationId };
    if (args.resource) where.resource = args.resource;
    if (args.resourceId) where.resourceId = args.resourceId;
    if (args.actorId) where.actorId = args.actorId;
    if (args.fromDate || args.toDate) {
      const range: Record<string, Date> = {};
      if (args.fromDate) range.gte = args.fromDate;
      if (args.toDate) range.lte = args.toDate;
      where.createdAt = range;
    }
    const [items, total] = await Promise.all([
      prisma.activityEvent.findMany({
        where,
        skip: (page - 1) * pageSize,
        take: pageSize,
        orderBy: { createdAt: "desc" },
      }),
      prisma.activityEvent.count({ where }),
    ]);
    return { items, total, page, pageSize };
  }

  async forResource(args: {
    organizationId: string;
    resource: string;
    resourceId: string;
    limit?: number;
  }) {
    return prisma.activityEvent.findMany({
      where: {
        organizationId: args.organizationId,
        resource: args.resource,
        resourceId: args.resourceId,
      },
      orderBy: { createdAt: "desc" },
      take: Math.min(200, args.limit ?? 50),
    });
  }
}
