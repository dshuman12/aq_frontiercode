import { Body, Controller, Delete, Get, Param, Patch, Post, Query, UseGuards, UsePipes } from "@nestjs/common";
import {
  ManualTimeEntrySchema,
  StartTimerSchema,
  StopTimerSchema,
  TimeEntryFilterSchema,
  UpdateTimeEntrySchema,
} from "@worknest/validators";
import { AuthGuard } from "../../common/auth.guard";
import { ZodPipe } from "../../common/zod.pipe";
import { CurrentOrgId, CurrentUser } from "../../common/current-user.decorator";
import { RequiresPermission } from "../../common/permissions.guard";
import { TimeEntriesService } from "./time-entries.service";

@UseGuards(AuthGuard)
@Controller("time-entries")
export class TimeEntriesController {
  constructor(private readonly timeEntries: TimeEntriesService) {}

  @Get()
  @RequiresPermission("tasks:read")
  list(
    @CurrentOrgId() orgId: string,
    @Query(new ZodPipe(TimeEntryFilterSchema)) filter: any,
  ) {
    return this.timeEntries.list({ organizationId: orgId, ...filter });
  }

  @Get("running")
  running(@CurrentUser() user: any) {
    return this.timeEntries.runningTimer(user.sub);
  }

  @Post("start")
  @RequiresPermission("tasks:update")
  @UsePipes(new ZodPipe(StartTimerSchema))
  start(
    @CurrentOrgId() orgId: string,
    @CurrentUser() user: any,
    @Body() body: { taskId: string; description?: string; billable: boolean },
  ) {
    return this.timeEntries.startTimer({
      organizationId: orgId,
      userId: user.sub,
      taskId: body.taskId,
      description: body.description,
      billable: body.billable,
    });
  }

  @Post("stop")
  @UsePipes(new ZodPipe(StopTimerSchema))
  stop(
    @CurrentOrgId() orgId: string,
    @CurrentUser() user: any,
    @Body() body: { endedAt: Date },
  ) {
    return this.timeEntries.stopTimer({
      organizationId: orgId,
      userId: user.sub,
      endedAt: body.endedAt,
    });
  }

  @Post()
  @RequiresPermission("tasks:update")
  @UsePipes(new ZodPipe(ManualTimeEntrySchema))
  create(
    @CurrentOrgId() orgId: string,
    @CurrentUser() user: any,
    @Body() body: any,
  ) {
    return this.timeEntries.createManual({
      organizationId: orgId,
      userId: user.sub,
      ...body,
    });
  }

  @Patch(":id")
  @UsePipes(new ZodPipe(UpdateTimeEntrySchema))
  update(
    @CurrentOrgId() orgId: string,
    @CurrentUser() user: any,
    @Param("id") id: string,
    @Body() body: any,
  ) {
    return this.timeEntries.update({
      organizationId: orgId,
      userId: user.sub,
      id,
      patch: body,
    });
  }

  @Delete(":id")
  remove(
    @CurrentOrgId() orgId: string,
    @CurrentUser() user: any,
    @Param("id") id: string,
  ) {
    return this.timeEntries.remove({
      organizationId: orgId,
      userId: user.sub,
      id,
    });
  }

  @Get("rollup/task/:taskId")
  @RequiresPermission("tasks:read")
  taskRollup(@CurrentOrgId() orgId: string, @Param("taskId") taskId: string) {
    return this.timeEntries.taskRollup({ organizationId: orgId, taskId });
  }

  @Get("rollup/project/:projectId")
  @RequiresPermission("projects:read")
  projectRollup(
    @CurrentOrgId() orgId: string,
    @Param("projectId") projectId: string,
  ) {
    return this.timeEntries.projectRollup({
      organizationId: orgId,
      projectId,
    });
  }
}
