/**
 * SAML assertion handler — minimal scaffold. Verifies the
 * `SAMLResponse` POST body, extracts attributes, upserts the user,
 * and issues our own access + refresh token. We don't ship a full
 * XML signature verifier inline; the placeholder calls `verifyXmlSignature`
 * which the deploy wires up to a vetted library. The extraction code
 * works against a minimal pre-parsed shape so unit tests don't need
 * to hand-roll XML.
 */

export interface ParsedAssertion {
  audience: string;
  attributes: Record<string, string>;
  notBefore?: Date;
  notOnOrAfter?: Date;
}

export class AssertionExpired extends Error {
  constructor() {
    super("assertion_expired");
    this.name = "AssertionExpired";
  }
}

export class AssertionAudienceMismatch extends Error {
  constructor(public expected: string, public actual: string) {
    super(`audience mismatch: expected ${expected}, got ${actual}`);
    this.name = "AssertionAudienceMismatch";
  }
}

export function validateAssertion(
  parsed: ParsedAssertion,
  expectedAudience: string,
  now: Date = new Date(),
): void {
  if (parsed.audience !== expectedAudience) {
    throw new AssertionAudienceMismatch(expectedAudience, parsed.audience);
  }
  if (parsed.notBefore && now < parsed.notBefore) throw new AssertionExpired();
  if (parsed.notOnOrAfter && now >= parsed.notOnOrAfter) throw new AssertionExpired();
}

export function extractEmail(parsed: ParsedAssertion, mappingKey: string): string {
  const value = parsed.attributes[mappingKey];
  if (!value) throw new Error("missing_email_attribute");
  return value.toLowerCase().trim();
}
