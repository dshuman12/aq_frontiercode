import { Body, Controller, Delete, Get, Param, Patch, Post, Query, UseGuards, UsePipes } from "@nestjs/common";
import {
  CreateAutomationRuleSchema,
  TestAutomationSchema,
  UpdateAutomationRuleSchema,
} from "@worknest/validators";
import { AuthGuard } from "../../common/auth.guard";
import { ZodPipe } from "../../common/zod.pipe";
import { CurrentOrgId } from "../../common/current-user.decorator";
import { RequiresPermission } from "../../common/permissions.guard";
import { AutomationService } from "./automation.service";

@UseGuards(AuthGuard)
@Controller("automation")
export class AutomationController {
  constructor(private readonly automation: AutomationService) {}

  @Get("rules")
  @RequiresPermission("org:read")
  list(
    @CurrentOrgId() orgId: string,
    @Query("resource") resource?: string,
    @Query("trigger") trigger?: string,
  ) {
    return this.automation.list({ organizationId: orgId, resource, trigger });
  }

  @Post("rules")
  @RequiresPermission("org:update")
  @UsePipes(new ZodPipe(CreateAutomationRuleSchema))
  create(@CurrentOrgId() orgId: string, @Body() body: any) {
    return this.automation.create({ organizationId: orgId, input: body });
  }

  @Patch("rules/:id")
  @RequiresPermission("org:update")
  @UsePipes(new ZodPipe(UpdateAutomationRuleSchema))
  update(
    @CurrentOrgId() orgId: string,
    @Param("id") id: string,
    @Body() body: any,
  ) {
    return this.automation.update({ organizationId: orgId, id, patch: body });
  }

  @Delete("rules/:id")
  @RequiresPermission("org:update")
  remove(@CurrentOrgId() orgId: string, @Param("id") id: string) {
    return this.automation.remove(orgId, id);
  }

  @Get("rules/:id/runs")
  @RequiresPermission("org:read")
  runs(
    @CurrentOrgId() orgId: string,
    @Param("id") id: string,
    @Query("limit") limit?: string,
  ) {
    return this.automation.runs({
      organizationId: orgId,
      ruleId: id,
      limit: limit ? Number(limit) : undefined,
    });
  }

  @Post("rules/:id/test")
  @RequiresPermission("org:update")
  @UsePipes(new ZodPipe(TestAutomationSchema))
  test(
    @CurrentOrgId() orgId: string,
    @Param("id") id: string,
    @Body() body: { resourceId: string },
  ) {
    return this.automation.test({
      organizationId: orgId,
      ruleId: id,
      resourceId: body.resourceId,
    });
  }
}
