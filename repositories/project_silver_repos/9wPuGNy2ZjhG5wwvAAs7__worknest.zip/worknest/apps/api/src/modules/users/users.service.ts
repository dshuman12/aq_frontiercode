import { Injectable, NotFoundException } from "@nestjs/common";
import { prisma } from "@worknest/database";

@Injectable()
export class UsersService {
  async me(userId: string) {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        email: true,
        name: true,
        avatarUrl: true,
        timezone: true,
        locale: true,
        twoFactorEnabled: true,
        emailVerifiedAt: true,
        memberships: {
          include: { organization: { select: { id: true, name: true, slug: true, plan: true } } },
        },
      },
    });
    if (!user) throw new NotFoundException();
    return user;
  }

  async updateProfile(
    userId: string,
    patch: Partial<{ name: string; avatarUrl: string | null; timezone: string; locale: string }>,
  ) {
    return prisma.user.update({
      where: { id: userId },
      data: patch,
      select: { id: true, name: true, avatarUrl: true, timezone: true, locale: true },
    });
  }

  async organizations(userId: string) {
    const memberships = await prisma.organizationMember.findMany({
      where: { userId },
      include: { organization: { select: { id: true, name: true, slug: true, plan: true, logoUrl: true } } },
      orderBy: { joinedAt: "asc" },
    });
    return memberships.map((m) => ({ ...m.organization, role: m.role }));
  }

  async setActiveOrg(userId: string, organizationId: string) {
    const membership = await prisma.organizationMember.findFirst({
      where: { userId, organizationId },
    });
    if (!membership) throw new NotFoundException("not_a_member");
    return { organizationId, role: membership.role };
  }

  async byId(id: string) {
    return prisma.user.findUnique({
      where: { id },
      select: { id: true, name: true, email: true, avatarUrl: true },
    });
  }
}
