import { Body, Controller, Delete, Get, Param, Patch, Post, UseGuards, UsePipes } from "@nestjs/common";
import { CreateSlaPolicySchema, UpdateSlaPolicySchema } from "@worknest/validators";
import { AuthGuard } from "../../common/auth.guard";
import { ZodPipe } from "../../common/zod.pipe";
import { CurrentOrgId } from "../../common/current-user.decorator";
import { RequiresPermission } from "../../common/permissions.guard";
import { SlaService } from "./sla.service";

@UseGuards(AuthGuard)
@Controller("sla")
export class SlaController {
  constructor(private readonly sla: SlaService) {}

  @Get("policies")
  @RequiresPermission("tickets:read")
  list(@CurrentOrgId() orgId: string) {
    return this.sla.listPolicies(orgId);
  }

  @Post("policies")
  @RequiresPermission("tickets:categories:write")
  @UsePipes(new ZodPipe(CreateSlaPolicySchema))
  create(@CurrentOrgId() orgId: string, @Body() body: any) {
    return this.sla.createPolicy({ organizationId: orgId, ...body });
  }

  @Patch("policies/:id")
  @RequiresPermission("tickets:categories:write")
  @UsePipes(new ZodPipe(UpdateSlaPolicySchema))
  update(
    @CurrentOrgId() orgId: string,
    @Param("id") id: string,
    @Body() body: any,
  ) {
    return this.sla.updatePolicy({ organizationId: orgId, id, patch: body });
  }

  @Delete("policies/:id")
  @RequiresPermission("tickets:categories:write")
  remove(@CurrentOrgId() orgId: string, @Param("id") id: string) {
    return this.sla.deletePolicy(orgId, id);
  }

  @Post("timers/:ticketId/start")
  @RequiresPermission("tickets:update")
  start(@CurrentOrgId() orgId: string, @Param("ticketId") ticketId: string) {
    return this.sla.startForTicket({ organizationId: orgId, ticketId });
  }

  @Post("timers/:ticketId/first-response")
  @RequiresPermission("tickets:comment")
  firstResponse(@CurrentOrgId() orgId: string, @Param("ticketId") ticketId: string) {
    return this.sla.markFirstResponse({ organizationId: orgId, ticketId });
  }

  @Post("timers/:ticketId/resolved")
  @RequiresPermission("tickets:close")
  resolved(@CurrentOrgId() orgId: string, @Param("ticketId") ticketId: string) {
    return this.sla.markResolved({ organizationId: orgId, ticketId });
  }

  @Post("timers/:ticketId/pause")
  @RequiresPermission("tickets:update")
  pause(@CurrentOrgId() orgId: string, @Param("ticketId") ticketId: string) {
    return this.sla.pause({ organizationId: orgId, ticketId });
  }

  @Post("timers/:ticketId/resume")
  @RequiresPermission("tickets:update")
  resume(@CurrentOrgId() orgId: string, @Param("ticketId") ticketId: string) {
    return this.sla.resume({ organizationId: orgId, ticketId });
  }

  @Post("sweep")
  @RequiresPermission("tickets:categories:write")
  sweep(@CurrentOrgId() orgId: string) {
    return this.sla.sweepBreaches(orgId);
  }

  @Get("dashboard")
  @RequiresPermission("tickets:read")
  dashboard(@CurrentOrgId() orgId: string) {
    return this.sla.dashboard(orgId);
  }
}
