import { Body, Controller, Delete, Get, Param, Patch, Post, Query, UseGuards, UsePipes } from "@nestjs/common";
import { CreateSavedViewSchema, UpdateSavedViewSchema } from "@worknest/validators";
import { AuthGuard } from "../../common/auth.guard";
import { ZodPipe } from "../../common/zod.pipe";
import { CurrentOrgId, CurrentUser } from "../../common/current-user.decorator";
import { SavedViewsService } from "./saved-views.service";

@UseGuards(AuthGuard)
@Controller("saved-views")
export class SavedViewsController {
  constructor(private readonly views: SavedViewsService) {}

  @Get()
  list(
    @CurrentOrgId() orgId: string,
    @CurrentUser() user: any,
    @Query("resource") resource?: string,
  ) {
    return this.views.list({ organizationId: orgId, userId: user.sub, resource });
  }

  @Get(":id")
  get(
    @CurrentOrgId() orgId: string,
    @CurrentUser() user: any,
    @Param("id") id: string,
  ) {
    return this.views.get({ organizationId: orgId, userId: user.sub, id });
  }

  @Post()
  @UsePipes(new ZodPipe(CreateSavedViewSchema))
  create(
    @CurrentOrgId() orgId: string,
    @CurrentUser() user: any,
    @Body() body: any,
  ) {
    return this.views.create({
      organizationId: orgId,
      userId: user.sub,
      input: body,
    });
  }

  @Patch(":id")
  @UsePipes(new ZodPipe(UpdateSavedViewSchema))
  update(
    @CurrentOrgId() orgId: string,
    @CurrentUser() user: any,
    @Param("id") id: string,
    @Body() body: any,
  ) {
    return this.views.update({
      organizationId: orgId,
      userId: user.sub,
      id,
      patch: body,
    });
  }

  @Delete(":id")
  remove(
    @CurrentOrgId() orgId: string,
    @CurrentUser() user: any,
    @Param("id") id: string,
  ) {
    return this.views.remove({ organizationId: orgId, userId: user.sub, id });
  }
}
