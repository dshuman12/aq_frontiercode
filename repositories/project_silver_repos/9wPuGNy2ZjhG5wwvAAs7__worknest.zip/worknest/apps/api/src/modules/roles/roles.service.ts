import { BadRequestException, Injectable, NotFoundException } from "@nestjs/common";
import { prisma } from "@worknest/database";
import { isKnownPermission, Permission, permissionsByCategory, ROLE_PRESETS } from "@worknest/permissions";

@Injectable()
export class RolesService {
  async list(organizationId: string) {
    const customRoles = await prisma.role.findMany({
      where: { organizationId },
      orderBy: { name: "asc" },
    });
    const presets = Object.entries(ROLE_PRESETS).map(([key, set]) => ({
      id: `preset:${key}`,
      name: key,
      kind: "preset" as const,
      permissions: Array.from(set),
    }));
    return [...presets, ...customRoles.map((r) => ({ ...r, kind: "custom" as const }))];
  }

  async catalog() {
    return permissionsByCategory();
  }

  async create(organizationId: string, input: { name: string; description?: string; permissions: string[] }) {
    const invalid = input.permissions.filter((p) => !isKnownPermission(p));
    if (invalid.length > 0) {
      throw new BadRequestException(`unknown_permissions: ${invalid.join(",")}`);
    }
    return prisma.role.create({
      data: {
        organizationId,
        name: input.name,
        description: input.description,
        permissions: input.permissions,
      },
    });
  }

  async update(roleId: string, patch: { name?: string; description?: string; permissions?: string[] }) {
    if (patch.permissions) {
      const invalid = patch.permissions.filter((p) => !isKnownPermission(p));
      if (invalid.length > 0) {
        throw new BadRequestException(`unknown_permissions: ${invalid.join(",")}`);
      }
    }
    return prisma.role.update({ where: { id: roleId }, data: patch });
  }

  async delete(organizationId: string, roleId: string) {
    const role = await prisma.role.findUnique({ where: { id: roleId } });
    if (!role || role.organizationId !== organizationId) throw new NotFoundException();
    const usage = await prisma.organizationMember.count({ where: { customRoleId: roleId } });
    if (usage > 0) throw new BadRequestException("role_in_use");
    await prisma.role.delete({ where: { id: roleId } });
    return { ok: true };
  }
}
