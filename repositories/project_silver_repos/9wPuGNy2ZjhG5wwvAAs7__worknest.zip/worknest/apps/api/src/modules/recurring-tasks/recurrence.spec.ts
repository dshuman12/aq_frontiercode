/**
 * Cadence boundaries. Daily increments cleanly; monthly clamps when
 * dayOfMonth=31 hits a 30-day month; weekly with `daysOfWeek` walks
 * forward to the next listed weekday.
 */
import { describe, expect, it } from "vitest";
import { nextRunAt } from "./recurrence";

describe("nextRunAt", () => {
  it("daily increments by interval days", () => {
    const next = nextRunAt(new Date("2025-05-22T00:00:00Z"), {
      cadence: "daily",
      interval: 1,
      daysOfWeek: [],
      hourOfDay: 9,
    });
    expect(next.toISOString()).toBe("2025-05-23T09:00:00.000Z");
  });

  it("weekly walks to next listed weekday", () => {
    // 2025-05-22 is a Thursday (UTC day 4). Schedule on Mondays (1).
    const next = nextRunAt(new Date("2025-05-22T12:00:00Z"), {
      cadence: "weekly",
      interval: 1,
      daysOfWeek: [1],
      hourOfDay: 9,
    });
    expect(next.getUTCDay()).toBe(1); // Monday
  });

  it("monthly clamps day-of-month to last day of target month", () => {
    // Jan 31 → Feb 28
    const next = nextRunAt(new Date("2025-01-15T00:00:00Z"), {
      cadence: "monthly",
      interval: 1,
      daysOfWeek: [],
      dayOfMonth: 31,
      hourOfDay: 9,
    });
    expect(next.getUTCMonth()).toBe(1); // February (zero-indexed)
    expect(next.getUTCDate()).toBe(28);
  });
});
