import { describe, expect, it } from "vitest";
import { stripHtml } from "./email-to-ticket";

describe("stripHtml", () => {
  it("drops tags but keeps text", () => {
    expect(stripHtml("<p>Hello <b>world</b></p>")).toBe("Hello world");
  });
  it("removes style + script content", () => {
    const input = "<style>.x{color:red}</style><script>alert(1)</script><p>safe</p>";
    expect(stripHtml(input)).toBe("safe");
  });
  it("converts &nbsp; to space", () => {
    expect(stripHtml("<p>a&nbsp;b</p>")).toBe("a b");
  });
});
