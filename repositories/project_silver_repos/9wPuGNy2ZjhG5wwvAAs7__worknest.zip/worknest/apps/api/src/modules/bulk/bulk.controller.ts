import { Body, Controller, Post, UseGuards, UsePipes } from "@nestjs/common";
import {
  BulkLabelSchema,
  BulkTaskDeleteSchema,
  BulkTaskUpdateSchema,
  BulkTicketUpdateSchema,
} from "@worknest/validators";
import { AuthGuard } from "../../common/auth.guard";
import { ZodPipe } from "../../common/zod.pipe";
import { CurrentOrgId } from "../../common/current-user.decorator";
import { RequiresPermission } from "../../common/permissions.guard";
import { BulkService } from "./bulk.service";

@UseGuards(AuthGuard)
@Controller("bulk")
export class BulkController {
  constructor(private readonly bulk: BulkService) {}

  @Post("tasks/update")
  @RequiresPermission("tasks:update")
  @UsePipes(new ZodPipe(BulkTaskUpdateSchema))
  updateTasks(
    @CurrentOrgId() orgId: string,
    @Body() body: { ids: string[]; patch: Record<string, unknown> },
  ) {
    return this.bulk.updateTasks({
      organizationId: orgId,
      ids: body.ids,
      patch: body.patch,
    });
  }

  @Post("tasks/delete")
  @RequiresPermission("tasks:delete")
  @UsePipes(new ZodPipe(BulkTaskDeleteSchema))
  deleteTasks(@CurrentOrgId() orgId: string, @Body() body: { ids: string[] }) {
    return this.bulk.deleteTasks({ organizationId: orgId, ids: body.ids });
  }

  @Post("tasks/labels")
  @RequiresPermission("tasks:update")
  @UsePipes(new ZodPipe(BulkLabelSchema))
  applyTaskLabels(
    @CurrentOrgId() orgId: string,
    @Body() body: { ids: string[]; labels: string[]; mode: "add" | "remove" | "replace" },
  ) {
    return this.bulk.applyTaskLabels({
      organizationId: orgId,
      ids: body.ids,
      labels: body.labels,
      mode: body.mode,
    });
  }

  @Post("tickets/update")
  @RequiresPermission("tickets:update")
  @UsePipes(new ZodPipe(BulkTicketUpdateSchema))
  updateTickets(
    @CurrentOrgId() orgId: string,
    @Body() body: { ids: string[]; patch: Record<string, unknown> },
  ) {
    return this.bulk.updateTickets({
      organizationId: orgId,
      ids: body.ids,
      patch: body.patch,
    });
  }
}
