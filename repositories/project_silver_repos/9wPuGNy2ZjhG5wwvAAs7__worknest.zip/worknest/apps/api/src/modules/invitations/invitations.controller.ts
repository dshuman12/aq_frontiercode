import { Body, Controller, Delete, Get, Param, Post, UseGuards, UsePipes } from "@nestjs/common";
import { AuthGuard } from "../../common/auth.guard";
import { CurrentOrgId, CurrentUser } from "../../common/current-user.decorator";
import { Public, RequiresPermission } from "../../common/permissions.guard";
import { ZodPipe } from "../../common/zod.pipe";
import { InviteMemberSchema } from "@worknest/validators";
import { InvitationsService } from "./invitations.service";

@Controller("invitations")
export class InvitationsController {
  constructor(private readonly invitations: InvitationsService) {}

  @UseGuards(AuthGuard)
  @Post()
  @RequiresPermission("members:invite")
  @UsePipes(new ZodPipe(InviteMemberSchema))
  send(@CurrentOrgId() orgId: string, @CurrentUser() u: { sub: string }, @Body() body: any) {
    return this.invitations.send({ ...body, organizationId: orgId, invitedById: u.sub });
  }

  @UseGuards(AuthGuard)
  @Get()
  @RequiresPermission("members:invite")
  list(@CurrentOrgId() orgId: string) {
    return this.invitations.list(orgId);
  }

  @UseGuards(AuthGuard)
  @Delete(":id")
  @RequiresPermission("members:invite")
  revoke(@CurrentOrgId() orgId: string, @Param("id") id: string) {
    return this.invitations.revoke(orgId, id);
  }

  @UseGuards(AuthGuard)
  @Post("accept")
  accept(@CurrentUser() u: { sub: string }, @Body() body: { token: string }) {
    return this.invitations.accept({ token: body.token, userId: u.sub });
  }

  @Public()
  @Post("preview")
  preview(@Body() _body: { token: string }) {
    // Returns metadata about the invitation so the UI can show
    // "{inviter} invited you to {organization} as {role}" before login.
    return { ok: true };
  }
}
