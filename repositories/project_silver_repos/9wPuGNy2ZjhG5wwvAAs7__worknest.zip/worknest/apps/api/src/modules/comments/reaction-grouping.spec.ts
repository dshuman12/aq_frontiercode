/**
 * The presentation aggregation: collapse N reaction rows into a list
 * of `{ emoji, userIds, count }`. Test it in isolation so we can
 * change rendering details without pulling in the prisma layer.
 */
import { describe, expect, it } from "vitest";

interface Row {
  emoji: string;
  userId: string;
}

function group(rows: Row[]): { emoji: string; userIds: string[]; count: number }[] {
  const grouped = new Map<string, string[]>();
  for (const r of rows) {
    const list = grouped.get(r.emoji) ?? [];
    list.push(r.userId);
    grouped.set(r.emoji, list);
  }
  return Array.from(grouped.entries()).map(([emoji, userIds]) => ({
    emoji,
    userIds,
    count: userIds.length,
  }));
}

describe("reaction grouping", () => {
  it("groups by emoji preserving user order", () => {
    const out = group([
      { emoji: "👍", userId: "u1" },
      { emoji: "🎉", userId: "u2" },
      { emoji: "👍", userId: "u3" },
    ]);
    const thumbs = out.find((g) => g.emoji === "👍");
    expect(thumbs?.userIds).toEqual(["u1", "u3"]);
    expect(thumbs?.count).toBe(2);
  });
  it("handles single reactions", () => {
    expect(group([{ emoji: "🚀", userId: "u1" }])).toEqual([
      { emoji: "🚀", userIds: ["u1"], count: 1 },
    ]);
  });
  it("returns empty on empty input", () => {
    expect(group([])).toEqual([]);
  });
});
