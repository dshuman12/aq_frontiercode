/**
 * Knowledge base. Articles + categories + per-edit version history.
 * Publishing flips status to "published" and stamps publishedAt.
 * Versions are written on every body change so we can offer a
 * basic compare-with-previous on the article page.
 */
import { ConflictException, Injectable, NotFoundException } from "@nestjs/common";
import { prisma } from "@worknest/database";

@Injectable()
export class KnowledgeService {
  // ── Categories ──────────────────────────────────────────────────────────
  async listCategories(organizationId: string) {
    return prisma.knowledgeCategory.findMany({
      where: { organizationId },
      orderBy: { name: "asc" },
      include: { _count: { select: { articles: true } } },
    });
  }

  async createCategory(args: {
    organizationId: string;
    input: { name: string; slug: string; description?: string };
  }) {
    const dup = await prisma.knowledgeCategory.findUnique({
      where: { organizationId_slug: { organizationId: args.organizationId, slug: args.input.slug } },
    });
    if (dup) throw new ConflictException("category_slug_in_use");
    return prisma.knowledgeCategory.create({
      data: { organizationId: args.organizationId, ...args.input },
    });
  }

  // ── Articles ────────────────────────────────────────────────────────────
  async listArticles(args: {
    organizationId: string;
    categoryId?: string;
    status?: string;
    q?: string;
  }) {
    return prisma.knowledgeArticle.findMany({
      where: {
        organizationId: args.organizationId,
        ...(args.categoryId ? { categoryId: args.categoryId } : {}),
        ...(args.status ? { status: args.status } : {}),
        ...(args.q
          ? {
              OR: [
                { title: { contains: args.q, mode: "insensitive" } },
                { body: { contains: args.q, mode: "insensitive" } },
              ],
            }
          : {}),
      },
      orderBy: { updatedAt: "desc" },
      include: {
        category: { select: { id: true, name: true, slug: true } },
      },
      take: 200,
    });
  }

  async getArticle(args: { organizationId: string; idOrSlug: string }) {
    const article = await prisma.knowledgeArticle.findFirst({
      where: {
        organizationId: args.organizationId,
        OR: [{ id: args.idOrSlug }, { slug: args.idOrSlug }],
      },
      include: {
        category: { select: { id: true, name: true, slug: true } },
        versions: { orderBy: { createdAt: "desc" }, take: 10 },
      },
    });
    if (!article) throw new NotFoundException();
    return article;
  }

  async createArticle(args: {
    organizationId: string;
    authorId: string;
    input: {
      slug: string;
      title: string;
      body: string;
      categoryId?: string | null;
      status: "draft" | "published" | "archived";
    };
  }) {
    const dup = await prisma.knowledgeArticle.findUnique({
      where: { organizationId_slug: { organizationId: args.organizationId, slug: args.input.slug } },
    });
    if (dup) throw new ConflictException("article_slug_in_use");
    return prisma.$transaction(async (tx) => {
      const a = await tx.knowledgeArticle.create({
        data: {
          organizationId: args.organizationId,
          authorId: args.authorId,
          slug: args.input.slug,
          title: args.input.title,
          body: args.input.body,
          categoryId: args.input.categoryId ?? null,
          status: args.input.status,
          publishedAt: args.input.status === "published" ? new Date() : null,
        },
      });
      await tx.knowledgeArticleVersion.create({
        data: { articleId: a.id, body: args.input.body, authorId: args.authorId },
      });
      return a;
    });
  }

  async updateArticle(args: {
    organizationId: string;
    authorId: string;
    id: string;
    patch: Record<string, unknown>;
  }) {
    const a = await this.getArticle({ organizationId: args.organizationId, idOrSlug: args.id });
    const bodyChanged =
      typeof args.patch.body === "string" && args.patch.body !== a.body;
    return prisma.$transaction(async (tx) => {
      const updated = await tx.knowledgeArticle.update({
        where: { id: a.id },
        data: args.patch,
      });
      if (bodyChanged) {
        await tx.knowledgeArticleVersion.create({
          data: {
            articleId: a.id,
            body: args.patch.body as string,
            authorId: args.authorId,
          },
        });
      }
      return updated;
    });
  }

  async publishArticle(args: { organizationId: string; id: string; publish: boolean }) {
    const a = await this.getArticle({ organizationId: args.organizationId, idOrSlug: args.id });
    return prisma.knowledgeArticle.update({
      where: { id: a.id },
      data: {
        status: args.publish ? "published" : "draft",
        publishedAt: args.publish ? a.publishedAt ?? new Date() : null,
      },
    });
  }

  async deleteArticle(organizationId: string, id: string) {
    const a = await this.getArticle({ organizationId, idOrSlug: id });
    await prisma.knowledgeArticle.delete({ where: { id: a.id } });
    return { ok: true };
  }
}
