import { Injectable, NotFoundException } from "@nestjs/common";
import { prisma } from "@worknest/database";

@Injectable()
export class TeamsService {
  async list(organizationId: string) {
    return prisma.team.findMany({
      where: { organizationId },
      include: { _count: { select: { members: true } } },
      orderBy: { name: "asc" },
    });
  }

  async create(organizationId: string, input: { name: string; description?: string }) {
    return prisma.team.create({
      data: { organizationId, ...input },
    });
  }

  async update(teamId: string, patch: { name?: string; description?: string }) {
    return prisma.team.update({ where: { id: teamId }, data: patch });
  }

  async delete(teamId: string) {
    await prisma.team.delete({ where: { id: teamId } });
    return { ok: true };
  }

  async members(teamId: string) {
    return prisma.teamMember.findMany({ where: { teamId } });
  }

  async addMember(teamId: string, userId: string, role: "lead" | "member" = "member") {
    return prisma.teamMember.upsert({
      where: { teamId_userId: { teamId, userId } },
      create: { teamId, userId, role },
      update: { role },
    });
  }

  async removeMember(teamId: string, userId: string) {
    await prisma.teamMember.deleteMany({ where: { teamId, userId } });
    return { ok: true };
  }

  async byId(teamId: string) {
    const team = await prisma.team.findUnique({
      where: { id: teamId },
      include: {
        members: true,
      },
    });
    if (!team) throw new NotFoundException();
    return team;
  }

  async workload(teamId: string) {
    const members = await prisma.teamMember.findMany({
      where: { teamId },
      select: { userId: true },
    });
    const userIds = members.map((m) => m.userId);
    const tasks = await prisma.task.groupBy({
      by: ["assigneeId"],
      where: { assigneeId: { in: userIds }, status: { not: "done" } },
      _count: true,
    });
    return tasks.map((t) => ({ userId: t.assigneeId, openTasks: t._count }));
  }
}
