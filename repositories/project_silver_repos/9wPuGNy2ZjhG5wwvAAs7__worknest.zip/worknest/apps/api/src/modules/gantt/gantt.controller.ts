import { Controller, Get, Query, UseGuards } from "@nestjs/common";
import { AuthGuard } from "../../common/auth.guard";
import { CurrentOrgId } from "../../common/current-user.decorator";
import { GanttService } from "./gantt.service";

@UseGuards(AuthGuard)
@Controller("gantt")
export class GanttController {
  constructor(private readonly gantt: GanttService) {}

  @Get()
  forProject(@CurrentOrgId() orgId: string, @Query("projectId") projectId: string) {
    return this.gantt.forProject({ organizationId: orgId, projectId });
  }
}
