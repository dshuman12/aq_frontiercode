/**
 * Pin the running-timer math. The service treats stop time as
 * "endedAt" and computes durationSeconds as floor((endedAt - startedAt) / 1000).
 * Edge cases: same-second start/stop is zero duration; sub-second gaps round
 * down (we don't want fractional seconds in the DB). The DST-related cases
 * are handled by the underlying Date arithmetic and aren't exercised here.
 */
import { describe, expect, it } from "vitest";

function durationSeconds(startedAt: Date, endedAt: Date): number {
  return Math.floor((endedAt.getTime() - startedAt.getTime()) / 1000);
}

describe("time-entry duration math", () => {
  it("rounds down sub-second", () => {
    const start = new Date("2025-02-17T09:00:00.000Z");
    const end = new Date("2025-02-17T09:00:01.999Z");
    expect(durationSeconds(start, end)).toBe(1);
  });

  it("computes whole minutes", () => {
    const start = new Date("2025-02-17T09:00:00.000Z");
    const end = new Date("2025-02-17T10:23:00.000Z");
    expect(durationSeconds(start, end)).toBe(83 * 60);
  });

  it("zero on identical timestamps", () => {
    const t = new Date("2025-02-17T09:00:00.000Z");
    expect(durationSeconds(t, t)).toBe(0);
  });
});
