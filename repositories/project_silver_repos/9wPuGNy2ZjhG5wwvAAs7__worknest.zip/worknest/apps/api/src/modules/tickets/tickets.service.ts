import { BadRequestException, Injectable, NotFoundException } from "@nestjs/common";
import { prisma } from "@worknest/database";

const STATUS_FLOW: Record<string, string[]> = {
  open: ["pending", "in_progress", "on_hold", "resolved", "closed"],
  pending: ["in_progress", "resolved", "closed"],
  in_progress: ["pending", "on_hold", "resolved", "closed"],
  on_hold: ["in_progress", "resolved", "closed"],
  resolved: ["closed", "in_progress"],
  closed: ["in_progress"],
};

@Injectable()
export class TicketsService {
  async list(organizationId: string, filters: { status?: string; assigneeId?: string; categoryId?: string; q?: string; page?: number; pageSize?: number }) {
    const page = Math.max(1, filters.page ?? 1);
    const pageSize = Math.min(200, Math.max(1, filters.pageSize ?? 50));
    const where: Record<string, unknown> = { organizationId };
    if (filters.status) where.status = filters.status;
    if (filters.assigneeId) where.assigneeId = filters.assigneeId;
    if (filters.categoryId) where.categoryId = filters.categoryId;
    if (filters.q) {
      where.OR = [
        { title: { contains: filters.q, mode: "insensitive" } },
        { description: { contains: filters.q, mode: "insensitive" } },
      ];
    }
    const [items, total] = await Promise.all([
      prisma.ticket.findMany({
        where,
        skip: (page - 1) * pageSize,
        take: pageSize,
        orderBy: { createdAt: "desc" },
        include: { category: true },
      }),
      prisma.ticket.count({ where }),
    ]);
    return { items, total, page, pageSize };
  }

  async byId(id: string) {
    const ticket = await prisma.ticket.findUnique({
      where: { id },
      include: {
        category: true,
        comments: { orderBy: { createdAt: "asc" } },
        attachments: true,
        history: { orderBy: { at: "desc" } },
        watchers: true,
      },
    });
    if (!ticket) throw new NotFoundException();
    return ticket;
  }

  async create(input: {
    organizationId: string;
    requesterId: string;
    title: string;
    description?: string;
    priority: string;
    categoryId?: string;
    assigneeId?: string;
  }) {
    const key = await this.allocateKey(input.organizationId);
    return prisma.$transaction(async (tx) => {
      const ticket = await tx.ticket.create({
        data: {
          organizationId: input.organizationId,
          requesterId: input.requesterId,
          title: input.title,
          description: input.description,
          priority: input.priority,
          categoryId: input.categoryId,
          assigneeId: input.assigneeId,
          key,
        },
      });
      await tx.ticketStatusHistory.create({
        data: {
          ticketId: ticket.id,
          fromStatus: null,
          toStatus: "open",
          actorId: input.requesterId,
        },
      });
      return ticket;
    });
  }

  async update(id: string, patch: Record<string, unknown>) {
    return prisma.ticket.update({ where: { id }, data: patch as never });
  }

  async transition(id: string, actorId: string, toStatus: string, note?: string) {
    const ticket = await prisma.ticket.findUnique({ where: { id } });
    if (!ticket) throw new NotFoundException();
    const allowed = STATUS_FLOW[ticket.status] ?? [];
    if (!allowed.includes(toStatus)) {
      throw new BadRequestException(`cannot move ${ticket.status} → ${toStatus}`);
    }
    return prisma.$transaction(async (tx) => {
      const updated = await tx.ticket.update({
        where: { id },
        data: {
          status: toStatus,
          resolvedAt: toStatus === "resolved" ? new Date() : ticket.resolvedAt,
          closedAt: toStatus === "closed" ? new Date() : ticket.closedAt,
        },
      });
      await tx.ticketStatusHistory.create({
        data: {
          ticketId: id,
          fromStatus: ticket.status,
          toStatus,
          actorId,
          note,
        },
      });
      return updated;
    });
  }

  async addComment(ticketId: string, authorId: string, body: string, internal: boolean) {
    return prisma.ticketComment.create({
      data: { ticketId, authorId, body, internal },
    });
  }

  async addWatcher(ticketId: string, userId: string) {
    return prisma.ticketWatcher.upsert({
      where: { ticketId_userId: { ticketId, userId } },
      create: { ticketId, userId },
      update: {},
    });
  }

  async removeWatcher(ticketId: string, userId: string) {
    await prisma.ticketWatcher.deleteMany({ where: { ticketId, userId } });
    return { ok: true };
  }

  async listCategories(organizationId: string) {
    return prisma.ticketCategory.findMany({
      where: { organizationId },
      orderBy: { name: "asc" },
    });
  }

  async createCategory(organizationId: string, input: {
    name: string;
    slug: string;
    description?: string;
    defaultAssigneeId?: string;
    defaultPriority?: string;
  }) {
    return prisma.ticketCategory.create({ data: { organizationId, ...input } });
  }

  async updateCategory(categoryId: string, patch: Record<string, unknown>) {
    return prisma.ticketCategory.update({ where: { id: categoryId }, data: patch as never });
  }

  async deleteCategory(categoryId: string) {
    await prisma.ticketCategory.delete({ where: { id: categoryId } });
    return { ok: true };
  }

  async statusHistory(ticketId: string) {
    return prisma.ticketStatusHistory.findMany({
      where: { ticketId },
      orderBy: { at: "desc" },
    });
  }

  private async allocateKey(organizationId: string): Promise<string> {
    const count = await prisma.ticket.count({ where: { organizationId } });
    return `TKT-${count + 1}`;
  }
}
