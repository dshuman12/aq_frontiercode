import { Controller, Get, Query, UseGuards } from "@nestjs/common";
import { AuthGuard } from "../../common/auth.guard";
import { CurrentOrgId } from "../../common/current-user.decorator";
import { CalendarService } from "./calendar.service";

@UseGuards(AuthGuard)
@Controller("calendar")
export class CalendarController {
  constructor(private readonly calendar: CalendarService) {}

  @Get("events")
  events(
    @CurrentOrgId() orgId: string,
    @Query("from") from: string,
    @Query("to") to: string,
    @Query("projectId") projectId?: string,
  ) {
    return this.calendar.events({
      organizationId: orgId,
      from: new Date(from),
      to: new Date(to),
      projectId,
    });
  }
}
