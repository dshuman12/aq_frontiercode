/**
 * Per-org SAML configuration. Stored on the organization (we re-use
 * FeatureFlag for runtime toggles; production version moves these to
 * an SsoConfig row with proper encryption-at-rest for the cert).
 */

export interface SamlConfig {
  organizationId: string;
  entityId: string;
  ssoUrl: string;
  certPem: string;
  attributeMapping?: {
    email?: string;
    name?: string;
    groups?: string;
  };
  enforced: boolean;
}

export function defaultAttributeMapping(): Required<NonNullable<SamlConfig["attributeMapping"]>> {
  return {
    email: "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress",
    name: "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name",
    groups: "http://schemas.xmlsoap.org/claims/Group",
  };
}
