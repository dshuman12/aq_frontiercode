import { Body, Controller, Delete, Get, Param, Patch, Post, UseGuards, UsePipes } from "@nestjs/common";
import { AuthGuard } from "../../common/auth.guard";
import { CurrentOrgId } from "../../common/current-user.decorator";
import { RequiresPermission } from "../../common/permissions.guard";
import { ZodPipe } from "../../common/zod.pipe";
import { AddTeamMemberSchema, CreateTeamSchema, UpdateTeamSchema } from "@worknest/validators";
import { TeamsService } from "./teams.service";

@UseGuards(AuthGuard)
@Controller("teams")
export class TeamsController {
  constructor(private readonly teams: TeamsService) {}

  @Get()
  @RequiresPermission("teams:read")
  list(@CurrentOrgId() orgId: string) {
    return this.teams.list(orgId);
  }

  @Get(":id")
  @RequiresPermission("teams:read")
  byId(@Param("id") id: string) {
    return this.teams.byId(id);
  }

  @Post()
  @RequiresPermission("teams:create")
  @UsePipes(new ZodPipe(CreateTeamSchema))
  create(@CurrentOrgId() orgId: string, @Body() body: any) {
    return this.teams.create(orgId, body);
  }

  @Patch(":id")
  @RequiresPermission("teams:update")
  @UsePipes(new ZodPipe(UpdateTeamSchema))
  update(@Param("id") id: string, @Body() body: any) {
    return this.teams.update(id, body);
  }

  @Delete(":id")
  @RequiresPermission("teams:delete")
  remove(@Param("id") id: string) {
    return this.teams.delete(id);
  }

  @Post(":id/members")
  @RequiresPermission("teams:members:add")
  @UsePipes(new ZodPipe(AddTeamMemberSchema))
  addMember(@Param("id") id: string, @Body() body: { userId: string; role?: "lead" | "member" }) {
    return this.teams.addMember(id, body.userId, body.role);
  }

  @Delete(":id/members/:userId")
  @RequiresPermission("teams:members:remove")
  removeMember(@Param("id") id: string, @Param("userId") userId: string) {
    return this.teams.removeMember(id, userId);
  }

  @Get(":id/workload")
  @RequiresPermission("teams:read")
  workload(@Param("id") id: string) {
    return this.teams.workload(id);
  }
}
