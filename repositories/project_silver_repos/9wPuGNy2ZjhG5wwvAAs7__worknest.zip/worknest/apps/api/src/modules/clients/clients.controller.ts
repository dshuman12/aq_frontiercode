import { Body, Controller, Delete, Get, Param, Patch, Post, Query, UseGuards, UsePipes } from "@nestjs/common";
import { AuthGuard } from "../../common/auth.guard";
import { CurrentOrgId } from "../../common/current-user.decorator";
import { RequiresPermission } from "../../common/permissions.guard";
import { ZodPipe } from "../../common/zod.pipe";
import {
  CreateClientContactSchema,
  CreateClientSchema,
  InvitePortalUserSchema,
  UpdateClientSchema,
} from "@worknest/validators";
import { ClientsService } from "./clients.service";

@UseGuards(AuthGuard)
@Controller("clients")
export class ClientsController {
  constructor(private readonly clients: ClientsService) {}

  @Get()
  @RequiresPermission("clients:read")
  list(@CurrentOrgId() orgId: string, @Query("q") q?: string) {
    return this.clients.list(orgId, q);
  }

  @Get(":id")
  @RequiresPermission("clients:read")
  byId(@Param("id") id: string) {
    return this.clients.byId(id);
  }

  @Post()
  @RequiresPermission("clients:create")
  @UsePipes(new ZodPipe(CreateClientSchema))
  create(@CurrentOrgId() orgId: string, @Body() body: any) {
    return this.clients.create(orgId, body);
  }

  @Patch(":id")
  @RequiresPermission("clients:update")
  @UsePipes(new ZodPipe(UpdateClientSchema))
  update(@Param("id") id: string, @Body() body: any) {
    return this.clients.update(id, body);
  }

  @Delete(":id")
  @RequiresPermission("clients:delete")
  remove(@Param("id") id: string) {
    return this.clients.delete(id);
  }

  @Post("contacts")
  @RequiresPermission("clients:contacts:write")
  @UsePipes(new ZodPipe(CreateClientContactSchema))
  addContact(@Body() body: any) {
    return this.clients.addContact(body);
  }

  @Delete("contacts/:id")
  @RequiresPermission("clients:contacts:write")
  removeContact(@Param("id") id: string) {
    return this.clients.removeContact(id);
  }

  @Post(":id/portal-users")
  @RequiresPermission("clients:portal:invite")
  @UsePipes(new ZodPipe(InvitePortalUserSchema))
  invitePortalUser(@Param("id") id: string, @Body() body: { email: string; name: string }) {
    return this.clients.invitePortalUser(id, body.email, body.name);
  }

  @Post(":id/documents")
  @RequiresPermission("clients:documents:write")
  addDocument(@Param("id") id: string, @Body() body: { fileAssetId: string }) {
    return this.clients.addDocument(id, body.fileAssetId);
  }
}
