import { BadRequestException, Injectable, NotFoundException } from "@nestjs/common";
import { prisma } from "@worknest/database";

@Injectable()
export class AssetsService {
  async list(organizationId: string, filters: { categoryId?: string; status?: string; q?: string }) {
    const where: Record<string, unknown> = { organizationId };
    if (filters.categoryId) where.categoryId = filters.categoryId;
    if (filters.status) where.status = filters.status;
    if (filters.q) {
      where.OR = [
        { name: { contains: filters.q, mode: "insensitive" } },
        { tag: { contains: filters.q, mode: "insensitive" } },
        { serialNumber: { contains: filters.q, mode: "insensitive" } },
      ];
    }
    return prisma.asset.findMany({
      where,
      orderBy: { createdAt: "desc" },
      include: { category: true, vendor: true, warehouse: true },
    });
  }

  async byId(id: string) {
    const asset = await prisma.asset.findUnique({
      where: { id },
      include: { category: true, vendor: true, warehouse: true },
    });
    if (!asset) throw new NotFoundException();
    return asset;
  }

  async create(organizationId: string, input: Record<string, unknown>) {
    const tag = String(input.tag);
    const existing = await prisma.asset.findFirst({ where: { organizationId, tag } });
    if (existing) throw new BadRequestException("tag_taken");
    return prisma.asset.create({
      data: { organizationId, ...(input as Record<string, never>) },
    });
  }

  async update(id: string, patch: Record<string, unknown>) {
    return prisma.asset.update({ where: { id }, data: patch as never });
  }

  async assign(id: string, input: { assigneeId: string; effectiveAt?: Date; note?: string; actorId: string }) {
    return prisma.$transaction(async (tx) => {
      await tx.assetAssignment.updateMany({
        where: { assetId: id, returnedAt: null },
        data: { returnedAt: new Date() },
      });
      await tx.assetAssignment.create({
        data: {
          assetId: id,
          assigneeId: input.assigneeId,
          actorId: input.actorId,
          effectiveAt: input.effectiveAt ?? new Date(),
          note: input.note,
        },
      });
      return tx.asset.update({
        where: { id },
        data: { status: "assigned", assigneeId: input.assigneeId },
      });
    });
  }

  async return_(id: string, condition: "good" | "damaged" | "lost", note?: string) {
    return prisma.$transaction(async (tx) => {
      await tx.assetAssignment.updateMany({
        where: { assetId: id, returnedAt: null },
        data: { returnedAt: new Date(), note },
      });
      return tx.asset.update({
        where: { id },
        data: {
          status: condition === "lost" ? "retired" : "available",
          assigneeId: null,
        },
      });
    });
  }

  async retire(id: string) {
    return prisma.asset.update({
      where: { id },
      data: { status: "retired", assigneeId: null },
    });
  }

  async assignments(id: string) {
    return prisma.assetAssignment.findMany({
      where: { assetId: id },
      orderBy: { effectiveAt: "desc" },
    });
  }

  async maintenance(id: string) {
    return prisma.assetMaintenanceRecord.findMany({
      where: { assetId: id },
      orderBy: { performedAt: "desc" },
    });
  }

  async recordMaintenance(input: {
    assetId: string;
    performedAt: Date;
    performedBy: string;
    description: string;
    costCents?: number;
    vendorId?: string;
  }) {
    return prisma.assetMaintenanceRecord.create({ data: input });
  }

  async warrantyExpiring(organizationId: string, days = 30) {
    const cutoff = new Date(Date.now() + days * 24 * 60 * 60 * 1000);
    return prisma.asset.findMany({
      where: {
        organizationId,
        warrantyEndsAt: { lte: cutoff, gte: new Date() },
        status: { not: "retired" },
      },
      orderBy: { warrantyEndsAt: "asc" },
    });
  }

  async listCategories(organizationId: string) {
    return prisma.assetCategory.findMany({ where: { organizationId }, orderBy: { name: "asc" } });
  }

  async createCategory(organizationId: string, input: { name: string; description?: string }) {
    return prisma.assetCategory.create({ data: { organizationId, ...input } });
  }
}
