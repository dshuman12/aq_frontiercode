import { Controller, Get, Query, UseGuards } from "@nestjs/common";
import { AuthGuard } from "../../common/auth.guard";
import { CurrentOrgId } from "../../common/current-user.decorator";
import { ActivityService } from "./activity.service";

@UseGuards(AuthGuard)
@Controller("activity")
export class ActivityController {
  constructor(private readonly activity: ActivityService) {}

  @Get()
  list(
    @CurrentOrgId() orgId: string,
    @Query("resource") resource?: string,
    @Query("resourceId") resourceId?: string,
    @Query("actorId") actorId?: string,
    @Query("fromDate") fromDate?: string,
    @Query("toDate") toDate?: string,
    @Query("page") page?: string,
    @Query("pageSize") pageSize?: string,
  ) {
    return this.activity.list({
      organizationId: orgId,
      resource,
      resourceId,
      actorId,
      fromDate: fromDate ? new Date(fromDate) : undefined,
      toDate: toDate ? new Date(toDate) : undefined,
      page: page ? Number(page) : undefined,
      pageSize: pageSize ? Number(pageSize) : undefined,
    });
  }

  @Get("for-resource")
  forResource(
    @CurrentOrgId() orgId: string,
    @Query("resource") resource: string,
    @Query("resourceId") resourceId: string,
    @Query("limit") limit?: string,
  ) {
    return this.activity.forResource({
      organizationId: orgId,
      resource,
      resourceId,
      limit: limit ? Number(limit) : undefined,
    });
  }
}
