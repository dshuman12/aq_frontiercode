import { BadRequestException, Injectable, NotFoundException } from "@nestjs/common";
import { prisma } from "@worknest/database";

@Injectable()
export class InventoryService {
  async list(organizationId: string, filters: { warehouseId?: string; vendorId?: string; q?: string }) {
    const where: Record<string, unknown> = { organizationId };
    if (filters.warehouseId) where.warehouseId = filters.warehouseId;
    if (filters.vendorId) where.vendorId = filters.vendorId;
    if (filters.q) {
      where.OR = [
        { sku: { contains: filters.q, mode: "insensitive" } },
        { name: { contains: filters.q, mode: "insensitive" } },
      ];
    }
    return prisma.inventoryItem.findMany({
      where,
      orderBy: { name: "asc" },
    });
  }

  async byId(id: string) {
    const item = await prisma.inventoryItem.findUnique({ where: { id } });
    if (!item) throw new NotFoundException();
    return item;
  }

  async create(organizationId: string, input: Record<string, unknown>) {
    return prisma.inventoryItem.create({
      data: { organizationId, ...(input as Record<string, never>) },
    });
  }

  async update(id: string, patch: Record<string, unknown>) {
    return prisma.inventoryItem.update({ where: { id }, data: patch as never });
  }

  async delete(id: string) {
    await prisma.inventoryItem.delete({ where: { id } });
    return { ok: true };
  }

  async lowStock(organizationId: string) {
    const all = await prisma.inventoryItem.findMany({ where: { organizationId } });
    return all.filter((i) => i.qty <= i.reorderPoint);
  }

  async applyTransaction(input: { itemId: string; delta: number; reason: string; reference?: string; actorId: string }) {
    if (input.delta === 0) throw new BadRequestException("delta_zero");
    return prisma.$transaction(async (tx) => {
      const item = await tx.inventoryItem.findUnique({ where: { id: input.itemId } });
      if (!item) throw new NotFoundException();
      const next = item.qty + input.delta;
      if (next < 0) throw new BadRequestException("negative_balance");
      const updated = await tx.inventoryItem.update({
        where: { id: input.itemId },
        data: { qty: next },
      });
      const transaction = await tx.inventoryTransaction.create({
        data: {
          itemId: input.itemId,
          delta: input.delta,
          balanceAfter: next,
          reason: input.reason,
          reference: input.reference,
          actorId: input.actorId,
        },
      });
      return { item: updated, transaction };
    });
  }

  async transactionsFor(itemId: string, page = 1, pageSize = 50) {
    const skip = (page - 1) * pageSize;
    const [items, total] = await Promise.all([
      prisma.inventoryTransaction.findMany({
        where: { itemId },
        orderBy: { createdAt: "desc" },
        skip,
        take: pageSize,
      }),
      prisma.inventoryTransaction.count({ where: { itemId } }),
    ]);
    return { items, total, page, pageSize };
  }

  async listVendors(organizationId: string) {
    return prisma.vendor.findMany({ where: { organizationId }, orderBy: { name: "asc" } });
  }

  async createVendor(organizationId: string, input: Record<string, unknown>) {
    return prisma.vendor.create({ data: { organizationId, ...(input as Record<string, never>) } });
  }

  async updateVendor(id: string, patch: Record<string, unknown>) {
    return prisma.vendor.update({ where: { id }, data: patch as never });
  }

  async listWarehouses(organizationId: string) {
    return prisma.warehouse.findMany({ where: { organizationId }, orderBy: { name: "asc" } });
  }

  async createWarehouse(organizationId: string, input: { name: string; address?: string }) {
    return prisma.warehouse.create({ data: { organizationId, ...input } });
  }
}
