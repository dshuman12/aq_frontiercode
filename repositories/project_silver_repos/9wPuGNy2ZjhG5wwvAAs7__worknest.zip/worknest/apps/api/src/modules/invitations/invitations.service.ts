import { BadRequestException, Injectable, NotFoundException } from "@nestjs/common";
import { generateOpaqueToken, sha256Hex } from "@worknest/auth";
import { prisma } from "@worknest/database";

@Injectable()
export class InvitationsService {
  async send(args: {
    organizationId: string;
    invitedById: string;
    email: string;
    role: string;
    customRoleId?: string;
  }) {
    const existing = await prisma.invitation.findUnique({
      where: { organizationId_email: { organizationId: args.organizationId, email: args.email } },
    });
    if (existing && !existing.acceptedAt) {
      throw new BadRequestException("invitation_already_pending");
    }
    const token = generateOpaqueToken();
    const inv = await prisma.invitation.create({
      data: {
        organizationId: args.organizationId,
        email: args.email,
        role: args.role,
        invitedById: args.invitedById,
        tokenHash: sha256Hex(token),
        expiresAt: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000),
      },
    });
    return { invitation: inv, token };
  }

  async list(organizationId: string) {
    return prisma.invitation.findMany({
      where: { organizationId },
      orderBy: { createdAt: "desc" },
      include: { inviter: { select: { id: true, name: true } } },
    });
  }

  async revoke(organizationId: string, invitationId: string) {
    const inv = await prisma.invitation.findUnique({ where: { id: invitationId } });
    if (!inv || inv.organizationId !== organizationId) throw new NotFoundException();
    if (inv.acceptedAt) throw new BadRequestException("already_accepted");
    await prisma.invitation.delete({ where: { id: invitationId } });
    return { ok: true };
  }

  async accept(args: { token: string; userId: string }) {
    const tokenHash = sha256Hex(args.token);
    const inv = await prisma.invitation.findUnique({ where: { tokenHash } });
    if (!inv || inv.acceptedAt || inv.expiresAt < new Date()) {
      throw new BadRequestException("invalid_or_expired");
    }
    return prisma.$transaction(async (tx) => {
      await tx.organizationMember.upsert({
        where: {
          organizationId_userId: { organizationId: inv.organizationId, userId: args.userId },
        },
        create: { organizationId: inv.organizationId, userId: args.userId, role: inv.role },
        update: { role: inv.role },
      });
      await tx.invitation.update({
        where: { id: inv.id },
        data: { acceptedAt: new Date() },
      });
      return inv;
    });
  }
}
