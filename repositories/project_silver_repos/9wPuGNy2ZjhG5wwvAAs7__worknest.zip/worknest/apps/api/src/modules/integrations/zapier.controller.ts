/**
 * Generic webhook receiver for Zapier and similar low-code tools.
 * Each org can configure a "webhook secret"; senders include it as
 * `X-WorkNest-Secret`. Payload shape:
 *
 *   { resource: "ticket"|"task"|"request",
 *     action: "create"|"comment"|"transition",
 *     ...domain fields }
 *
 * Designed to be permissive — bad payloads return 400 with a hint
 * rather than 500. We only handle the shapes we know about; anything
 * else returns `{ ok: true, ignored: true }` so partner Zaps don't
 * break when we add new resource types.
 */
import { BadRequestException, Body, Controller, Headers, Post, UnauthorizedException } from "@nestjs/common";
import { createHash, timingSafeEqual } from "node:crypto";
import { prisma } from "@worknest/database";
import { Public } from "../../common/permissions.guard";

@Controller("integrations/zapier")
export class ZapierController {
  @Public()
  @Post("webhook/:orgSlug")
  async handle(
    @Headers("x-worknest-secret") secret: string,
    @Headers("x-org-slug") explicitSlug: string,
    @Body() body: any,
  ): Promise<{ ok: boolean; ignored?: boolean; resourceId?: string }> {
    const orgSlug = explicitSlug ?? (body?.org as string);
    if (!orgSlug) throw new BadRequestException("missing_org");
    const org = await prisma.organization.findUnique({ where: { slug: orgSlug } });
    if (!org) throw new UnauthorizedException("unknown_org");

    const expected = process.env.ZAPIER_SHARED_SECRET ?? "";
    if (!secret || expected.length === 0) throw new UnauthorizedException();
    const a = Buffer.from(createHash("sha256").update(secret).digest("hex"));
    const b = Buffer.from(createHash("sha256").update(expected).digest("hex"));
    if (a.length !== b.length || !timingSafeEqual(a, b)) {
      throw new UnauthorizedException();
    }

    if (body?.resource === "ticket" && body?.action === "create") {
      const t = await prisma.ticket.create({
        data: {
          organizationId: org.id,
          key: `ZAP-${Date.now().toString(36).slice(-6)}`,
          title: String(body.title ?? "(no title)").slice(0, 200),
          description: body.description ? String(body.description).slice(0, 5000) : null,
          priority: String(body.priority ?? "medium"),
          status: "open",
          requesterId: "automation",
        },
      });
      return { ok: true, resourceId: t.id };
    }
    return { ok: true, ignored: true };
  }
}
