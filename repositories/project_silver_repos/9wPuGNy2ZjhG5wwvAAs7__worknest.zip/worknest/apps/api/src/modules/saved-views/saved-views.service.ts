/**
 * SavedView is a thin persistence layer for "remember my Tasks filter".
 * The criteria JSON is opaque to the API — interpretation is the
 * client's problem. We only enforce structural rules: a view is either
 * private (visible to its owner) or shared (visible to anyone with
 * read access on the resource).
 *
 * `isDefault` is per (user, resource) — assigning a new default
 * unsets any previous default for that pair in a single transaction.
 */
import { ConflictException, Injectable, NotFoundException } from "@nestjs/common";
import { prisma } from "@worknest/database";

@Injectable()
export class SavedViewsService {
  async list(args: { organizationId: string; userId: string; resource?: string }) {
    return prisma.savedView.findMany({
      where: {
        organizationId: args.organizationId,
        ...(args.resource ? { resource: args.resource } : {}),
        OR: [{ ownerId: args.userId }, { isShared: true }],
      },
      orderBy: [{ isDefault: "desc" }, { name: "asc" }],
    });
  }

  async get(args: { organizationId: string; userId: string; id: string }) {
    const v = await prisma.savedView.findFirst({
      where: {
        id: args.id,
        organizationId: args.organizationId,
        OR: [{ ownerId: args.userId }, { isShared: true }],
      },
    });
    if (!v) throw new NotFoundException();
    return v;
  }

  async create(args: {
    organizationId: string;
    userId: string;
    input: {
      resource: "tasks" | "tickets" | "requests";
      name: string;
      criteria: Record<string, unknown>;
      isShared: boolean;
      isDefault: boolean;
    };
  }) {
    return prisma.$transaction(async (tx) => {
      if (args.input.isDefault) {
        await tx.savedView.updateMany({
          where: {
            organizationId: args.organizationId,
            ownerId: args.userId,
            resource: args.input.resource,
            isDefault: true,
          },
          data: { isDefault: false },
        });
      }
      return tx.savedView.create({
        data: {
          organizationId: args.organizationId,
          ownerId: args.userId,
          resource: args.input.resource,
          name: args.input.name,
          criteria: args.input.criteria,
          isShared: args.input.isShared,
          isDefault: args.input.isDefault,
        },
      });
    });
  }

  async update(args: {
    organizationId: string;
    userId: string;
    id: string;
    patch: Record<string, unknown>;
  }) {
    const v = await prisma.savedView.findFirst({
      where: { id: args.id, organizationId: args.organizationId },
    });
    if (!v) throw new NotFoundException();
    if (v.ownerId !== args.userId) throw new ConflictException("not_your_view");
    return prisma.$transaction(async (tx) => {
      if (args.patch.isDefault === true) {
        await tx.savedView.updateMany({
          where: {
            organizationId: args.organizationId,
            ownerId: args.userId,
            resource: v.resource,
            isDefault: true,
            id: { not: v.id },
          },
          data: { isDefault: false },
        });
      }
      return tx.savedView.update({ where: { id: v.id }, data: args.patch });
    });
  }

  async remove(args: { organizationId: string; userId: string; id: string }) {
    const v = await prisma.savedView.findFirst({
      where: { id: args.id, organizationId: args.organizationId },
    });
    if (!v) throw new NotFoundException();
    if (v.ownerId !== args.userId) throw new ConflictException("not_your_view");
    await prisma.savedView.delete({ where: { id: v.id } });
    return { ok: true };
  }
}
