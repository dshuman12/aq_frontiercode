import { Body, Controller, Delete, Get, Param, Patch, Post, Query, UseGuards, UsePipes } from "@nestjs/common";
import {
  CreateRecurringTaskSchema,
  PauseRecurringTaskSchema,
  UpdateRecurringTaskSchema,
} from "@worknest/validators";
import { AuthGuard } from "../../common/auth.guard";
import { ZodPipe } from "../../common/zod.pipe";
import { CurrentOrgId, CurrentUser } from "../../common/current-user.decorator";
import { RequiresPermission } from "../../common/permissions.guard";
import { RecurringTasksService } from "./recurring-tasks.service";

@UseGuards(AuthGuard)
@Controller("recurring-tasks")
export class RecurringTasksController {
  constructor(private readonly recurring: RecurringTasksService) {}

  @Get()
  @RequiresPermission("tasks:read")
  list(@CurrentOrgId() orgId: string, @Query("projectId") projectId?: string) {
    return this.recurring.list({ organizationId: orgId, projectId });
  }

  @Post()
  @RequiresPermission("tasks:create")
  @UsePipes(new ZodPipe(CreateRecurringTaskSchema))
  create(@CurrentOrgId() orgId: string, @Body() body: any) {
    return this.recurring.create({ organizationId: orgId, input: body });
  }

  @Patch(":id")
  @RequiresPermission("tasks:create")
  @UsePipes(new ZodPipe(UpdateRecurringTaskSchema))
  update(
    @CurrentOrgId() orgId: string,
    @Param("id") id: string,
    @Body() body: any,
  ) {
    return this.recurring.update({ organizationId: orgId, id, patch: body });
  }

  @Post(":id/pause")
  @RequiresPermission("tasks:create")
  @UsePipes(new ZodPipe(PauseRecurringTaskSchema))
  pause(
    @CurrentOrgId() orgId: string,
    @Param("id") id: string,
    @Body() body: { active: boolean },
  ) {
    return this.recurring.pause({ organizationId: orgId, id, active: body.active });
  }

  @Post(":id/run-now")
  @RequiresPermission("tasks:create")
  runNow(
    @CurrentOrgId() _orgId: string,
    @Param("id") id: string,
    @CurrentUser() user: any,
  ) {
    return this.recurring.applyOnce({ id, creatorId: user.sub });
  }

  @Delete(":id")
  @RequiresPermission("tasks:create")
  remove(@CurrentOrgId() orgId: string, @Param("id") id: string) {
    return this.recurring.remove(orgId, id);
  }
}
