import { Body, Controller, Delete, Get, Param, Patch, Post, UseGuards, UsePipes } from "@nestjs/common";
import { AuthGuard } from "../../common/auth.guard";
import { CurrentOrgId } from "../../common/current-user.decorator";
import { RequiresPermission } from "../../common/permissions.guard";
import { ZodPipe } from "../../common/zod.pipe";
import { CreateRoleSchema, UpdateRoleSchema } from "@worknest/validators";
import { RolesService } from "./roles.service";

@UseGuards(AuthGuard)
@Controller("roles")
export class RolesController {
  constructor(private readonly roles: RolesService) {}

  @Get()
  @RequiresPermission("roles:read")
  list(@CurrentOrgId() orgId: string) {
    return this.roles.list(orgId);
  }

  @Get("permissions")
  @RequiresPermission("roles:read")
  catalog() {
    return this.roles.catalog();
  }

  @Post()
  @RequiresPermission("roles:create")
  @UsePipes(new ZodPipe(CreateRoleSchema))
  create(@CurrentOrgId() orgId: string, @Body() body: any) {
    return this.roles.create(orgId, body);
  }

  @Patch(":id")
  @RequiresPermission("roles:update")
  @UsePipes(new ZodPipe(UpdateRoleSchema))
  update(@Param("id") id: string, @Body() body: any) {
    return this.roles.update(id, body);
  }

  @Delete(":id")
  @RequiresPermission("roles:delete")
  remove(@CurrentOrgId() orgId: string, @Param("id") id: string) {
    return this.roles.delete(orgId, id);
  }
}
