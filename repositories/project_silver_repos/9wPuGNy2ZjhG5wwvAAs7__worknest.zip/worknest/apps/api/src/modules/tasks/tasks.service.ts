import { BadRequestException, Injectable, NotFoundException } from "@nestjs/common";
import { prisma } from "@worknest/database";
import { ProjectsService } from "../projects/projects.service";

interface TaskListFilters {
  organizationId: string;
  projectId?: string;
  assigneeId?: string;
  status?: string;
  priority?: string;
  q?: string;
  hasParent?: boolean;
  page?: number;
  pageSize?: number;
}

@Injectable()
export class TasksService {
  constructor(private readonly projects: ProjectsService) {}

  async list(filters: TaskListFilters) {
    const page = Math.max(1, filters.page ?? 1);
    const pageSize = Math.min(200, Math.max(1, filters.pageSize ?? 50));
    const where: Record<string, unknown> = {
      project: { organizationId: filters.organizationId },
    };
    if (filters.projectId) (where as { project: object }).project = { ...((where as { project: object }).project), ...(filters.projectId ? { id: filters.projectId } : {}) };
    if (filters.assigneeId) where.assigneeId = filters.assigneeId;
    if (filters.status) where.status = filters.status;
    if (filters.priority) where.priority = filters.priority;
    if (filters.hasParent === false) where.parentTaskId = null;
    if (filters.q) {
      where.OR = [
        { title: { contains: filters.q, mode: "insensitive" } },
        { description: { contains: filters.q, mode: "insensitive" } },
      ];
    }

    const [items, total] = await Promise.all([
      prisma.task.findMany({
        where,
        skip: (page - 1) * pageSize,
        take: pageSize,
        orderBy: [{ position: "asc" }, { createdAt: "desc" }],
      }),
      prisma.task.count({ where }),
    ]);
    return { items, total, page, pageSize };
  }

  async byId(id: string) {
    const task = await prisma.task.findUnique({
      where: { id },
      include: {
        comments: { include: { author: true }, orderBy: { createdAt: "asc" } },
        attachments: true,
        checklists: { include: { items: { orderBy: { order: "asc" } } } },
        labels: true,
        subtasks: true,
        activity: { orderBy: { createdAt: "desc" }, take: 100 },
        dependsOn: { include: { blocker: true } },
        customValues: { include: { customField: true } },
      },
    });
    if (!task) throw new NotFoundException();
    return task;
  }

  async create(input: {
    projectId: string;
    boardColumnId?: string;
    parentTaskId?: string;
    title: string;
    description?: string;
    priority?: string;
    assigneeId?: string;
    dueAt?: Date;
    estimateHours?: number;
    createdById: string;
    labels?: string[];
  }) {
    const key = await this.projects.nextTaskNumber(input.projectId);
    const task = await prisma.task.create({
      data: {
        projectId: input.projectId,
        boardColumnId: input.boardColumnId,
        parentTaskId: input.parentTaskId,
        title: input.title,
        description: input.description,
        priority: input.priority ?? "medium",
        assigneeId: input.assigneeId,
        dueAt: input.dueAt,
        estimateHours: input.estimateHours,
        createdById: input.createdById,
        key,
        position: Date.now(),
      },
    });
    if (input.labels?.length) {
      await prisma.taskLabel.createMany({
        data: input.labels.map((name) => ({ taskId: task.id, name })),
      });
    }
    await this.recordActivity(task.id, input.createdById, "created");
    return task;
  }

  async update(id: string, actorId: string, patch: Record<string, unknown>) {
    const before = await prisma.task.findUnique({ where: { id } });
    if (!before) throw new NotFoundException();

    if (patch.status && before.status !== patch.status) {
      patch.completedAt = patch.status === "done" ? new Date() : null;
    }
    const updated = await prisma.task.update({ where: { id }, data: patch as never });
    await this.recordActivity(id, actorId, "updated", patch);
    return updated;
  }

  async move(id: string, actorId: string, boardColumnId: string, position?: number) {
    const updated = await prisma.task.update({
      where: { id },
      data: { boardColumnId, position: position ?? Date.now() },
    });
    await this.recordActivity(id, actorId, "moved", { boardColumnId, position });
    return updated;
  }

  async assign(id: string, actorId: string, userId: string | null) {
    const updated = await prisma.task.update({
      where: { id },
      data: { assigneeId: userId },
    });
    await this.recordActivity(id, actorId, "assigned", { userId });
    return updated;
  }

  async addComment(taskId: string, authorId: string, body: string) {
    const comment = await prisma.taskComment.create({
      data: { taskId, authorId, body },
    });
    await this.recordActivity(taskId, authorId, "commented", { commentId: comment.id });
    return comment;
  }

  async addDependency(taskId: string, dependsOnId: string, type = "blocks") {
    if (taskId === dependsOnId) throw new BadRequestException("self_dependency");
    if (await this.wouldCreateCycle(taskId, dependsOnId)) {
      throw new BadRequestException("would_create_cycle");
    }
    return prisma.taskDependency.create({ data: { taskId, dependsOnId, type } });
  }

  async removeDependency(taskId: string, dependsOnId: string) {
    await prisma.taskDependency.deleteMany({ where: { taskId, dependsOnId } });
    return { ok: true };
  }

  async addChecklist(taskId: string, title: string) {
    return prisma.taskChecklist.create({ data: { taskId, title } });
  }

  async addChecklistItem(checklistId: string, text: string) {
    const last = await prisma.taskChecklistItem.aggregate({
      where: { checklistId },
      _max: { order: true },
    });
    return prisma.taskChecklistItem.create({
      data: { checklistId, text, order: (last._max.order ?? -1) + 1 },
    });
  }

  async updateChecklistItem(itemId: string, patch: { done?: boolean; text?: string }) {
    return prisma.taskChecklistItem.update({
      where: { id: itemId },
      data: { ...patch, doneAt: patch.done ? new Date() : null },
    });
  }

  async deleteChecklistItem(itemId: string) {
    await prisma.taskChecklistItem.delete({ where: { id: itemId } });
    return { ok: true };
  }

  async remove(id: string, actorId: string) {
    await this.recordActivity(id, actorId, "deleted");
    await prisma.task.delete({ where: { id } });
    return { ok: true };
  }

  async listLabels(organizationId: string) {
    const labels = await prisma.taskLabel.findMany({
      where: { task: { project: { organizationId } } },
      select: { name: true, color: true },
      distinct: ["name"],
    });
    return labels;
  }

  async listCustomFields(organizationId: string) {
    return prisma.taskCustomField.findMany({ where: { organizationId } });
  }

  async createCustomField(organizationId: string, input: { name: string; type: string; config?: unknown }) {
    return prisma.taskCustomField.create({
      data: { organizationId, name: input.name, type: input.type, config: input.config as never },
    });
  }

  async setCustomFieldValue(taskId: string, customFieldId: string, value: unknown) {
    return prisma.taskCustomFieldValue.upsert({
      where: { taskId_customFieldId: { taskId, customFieldId } },
      create: { taskId, customFieldId, value: value as never },
      update: { value: value as never },
    });
  }

  private async wouldCreateCycle(taskId: string, dependsOnId: string): Promise<boolean> {
    // Walk the dependency graph from `dependsOnId` and see if we hit `taskId`.
    const visited = new Set<string>();
    const stack = [dependsOnId];
    while (stack.length > 0) {
      const cursor = stack.pop()!;
      if (cursor === taskId) return true;
      if (visited.has(cursor)) continue;
      visited.add(cursor);
      const deps = await prisma.taskDependency.findMany({
        where: { taskId: cursor },
        select: { dependsOnId: true },
      });
      for (const d of deps) stack.push(d.dependsOnId);
    }
    return false;
  }

  private async recordActivity(taskId: string, actorId: string | null, type: string, payload?: unknown) {
    await prisma.taskActivity.create({
      data: { taskId, actorId, type, payload: payload as never },
    });
  }
}
