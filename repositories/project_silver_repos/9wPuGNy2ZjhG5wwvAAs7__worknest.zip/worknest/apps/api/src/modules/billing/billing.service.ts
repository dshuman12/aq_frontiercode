import { BadRequestException, Injectable } from "@nestjs/common";
import Stripe from "stripe";
import { prisma } from "@worknest/database";
import { logger } from "@worknest/logger";

const log = logger("api/billing");

const PRICE_IDS: Record<string, { month: string | undefined; year: string | undefined }> = {
  starter: {
    month: process.env.STRIPE_PRICE_STARTER_MONTHLY,
    year: process.env.STRIPE_PRICE_STARTER_ANNUAL,
  },
  team: {
    month: process.env.STRIPE_PRICE_TEAM_MONTHLY,
    year: process.env.STRIPE_PRICE_TEAM_ANNUAL,
  },
  business: {
    month: process.env.STRIPE_PRICE_BUSINESS_MONTHLY,
    year: process.env.STRIPE_PRICE_BUSINESS_ANNUAL,
  },
};

@Injectable()
export class BillingService {
  private readonly stripe = new Stripe(process.env.STRIPE_API_KEY ?? "sk_test_dummy", {
    apiVersion: "2024-04-10",
  });

  async createCheckoutSession(input: {
    organizationId: string;
    plan: "starter" | "team" | "business";
    cadence: "month" | "year";
    returnUrl: string;
    cancelUrl: string;
  }) {
    const priceId = PRICE_IDS[input.plan]?.[input.cadence];
    if (!priceId) throw new BadRequestException("price_not_configured");

    const sub = await prisma.subscription.findUnique({
      where: { organizationId: input.organizationId },
    });
    const customerId = sub?.stripeCustomerId;

    const session = await this.stripe.checkout.sessions.create({
      mode: "subscription",
      success_url: input.returnUrl,
      cancel_url: input.cancelUrl,
      customer: customerId,
      line_items: [{ price: priceId, quantity: 1 }],
      client_reference_id: input.organizationId,
    });
    return { url: session.url, sessionId: session.id };
  }

  async createPortalSession(input: { customerId: string; returnUrl: string }) {
    const portal = await this.stripe.billingPortal.sessions.create({
      customer: input.customerId,
      return_url: input.returnUrl,
    });
    return { url: portal.url };
  }

  async changeSeats(organizationId: string, seats: number) {
    const sub = await prisma.subscription.findUnique({
      where: { organizationId },
    });
    if (!sub) throw new BadRequestException("no_subscription");
    await this.stripe.subscriptions.update(sub.stripeSubscriptionId, {
      items: [{ quantity: seats }],
      proration_behavior: "create_prorations",
    });
    await prisma.subscription.update({
      where: { id: sub.id },
      data: { seats },
    });
    return { ok: true };
  }

  async listInvoices(organizationId: string) {
    return prisma.invoice.findMany({
      where: { organizationId },
      orderBy: { issuedAt: "desc" },
    });
  }

  async handleWebhook(rawBody: Buffer, signature: string) {
    const secret = process.env.STRIPE_WEBHOOK_SECRET;
    if (!secret) throw new BadRequestException("not_configured");
    let event: Stripe.Event;
    try {
      event = this.stripe.webhooks.constructEvent(rawBody, signature, secret);
    } catch (err) {
      throw new BadRequestException(`invalid_signature: ${(err as Error).message}`);
    }
    log.info({ type: event.type, id: event.id }, "stripe webhook");

    switch (event.type) {
      case "checkout.session.completed":
        await this.persistSubscription(event.data.object as Stripe.Checkout.Session);
        break;
      case "customer.subscription.updated":
        await this.upsertSubscription(event.data.object as Stripe.Subscription);
        break;
      case "customer.subscription.deleted":
        await this.cancelSubscription(event.data.object as Stripe.Subscription);
        break;
      case "invoice.paid":
      case "invoice.finalized":
        await this.recordInvoice(event.data.object as Stripe.Invoice);
        break;
    }
    return { received: true };
  }

  private async persistSubscription(session: Stripe.Checkout.Session) {
    const orgId = session.client_reference_id;
    if (!orgId) return;
    const subId = session.subscription as string;
    const customerId = session.customer as string;
    const stripeSub = await this.stripe.subscriptions.retrieve(subId);
    const plan = (session.metadata?.plan ?? this.planFromPrice(stripeSub.items.data[0]?.price.id)) as string;
    await prisma.subscription.upsert({
      where: { organizationId: orgId },
      create: {
        organizationId: orgId,
        stripeCustomerId: customerId,
        stripeSubscriptionId: subId,
        plan,
        status: stripeSub.status,
        currentPeriodStart: new Date(stripeSub.current_period_start * 1000),
        currentPeriodEnd: new Date(stripeSub.current_period_end * 1000),
        cancelAtPeriodEnd: stripeSub.cancel_at_period_end,
        seats: stripeSub.items.data[0]?.quantity ?? 1,
      },
      update: {
        stripeSubscriptionId: subId,
        plan,
        status: stripeSub.status,
        currentPeriodEnd: new Date(stripeSub.current_period_end * 1000),
        cancelAtPeriodEnd: stripeSub.cancel_at_period_end,
        seats: stripeSub.items.data[0]?.quantity ?? 1,
      },
    });
    await prisma.organization.update({
      where: { id: orgId },
      data: { plan },
    });
  }

  private async upsertSubscription(sub: Stripe.Subscription) {
    const customerId = sub.customer as string;
    const row = await prisma.subscription.findFirst({ where: { stripeCustomerId: customerId } });
    if (!row) return;
    const plan = this.planFromPrice(sub.items.data[0]?.price.id) ?? row.plan;
    await prisma.subscription.update({
      where: { id: row.id },
      data: {
        plan,
        status: sub.status,
        currentPeriodStart: new Date(sub.current_period_start * 1000),
        currentPeriodEnd: new Date(sub.current_period_end * 1000),
        cancelAtPeriodEnd: sub.cancel_at_period_end,
        seats: sub.items.data[0]?.quantity ?? 1,
      },
    });
    await prisma.organization.update({
      where: { id: row.organizationId },
      data: { plan },
    });
  }

  private async cancelSubscription(sub: Stripe.Subscription) {
    const customerId = sub.customer as string;
    const row = await prisma.subscription.findFirst({ where: { stripeCustomerId: customerId } });
    if (!row) return;
    await prisma.subscription.update({
      where: { id: row.id },
      data: { status: "canceled" },
    });
    await prisma.organization.update({
      where: { id: row.organizationId },
      data: { plan: "free" },
    });
  }

  private async recordInvoice(invoice: Stripe.Invoice) {
    const customerId = invoice.customer as string;
    const sub = await prisma.subscription.findFirst({ where: { stripeCustomerId: customerId } });
    if (!sub) return;
    await prisma.invoice.upsert({
      where: { stripeInvoiceId: invoice.id },
      create: {
        organizationId: sub.organizationId,
        stripeInvoiceId: invoice.id,
        number: invoice.number,
        status: invoice.status ?? "open",
        amountDueCents: invoice.amount_due,
        amountPaidCents: invoice.amount_paid,
        currency: invoice.currency,
        issuedAt: new Date((invoice.created ?? 0) * 1000),
        paidAt: invoice.status_transitions.paid_at ? new Date(invoice.status_transitions.paid_at * 1000) : null,
        hostedInvoiceUrl: invoice.hosted_invoice_url ?? null,
      },
      update: {
        status: invoice.status ?? "open",
        amountPaidCents: invoice.amount_paid,
        paidAt: invoice.status_transitions.paid_at ? new Date(invoice.status_transitions.paid_at * 1000) : null,
        hostedInvoiceUrl: invoice.hosted_invoice_url ?? null,
      },
    });
  }

  private planFromPrice(priceId: string | undefined): string | undefined {
    if (!priceId) return undefined;
    for (const [plan, prices] of Object.entries(PRICE_IDS)) {
      if (prices.month === priceId || prices.year === priceId) return plan;
    }
    return undefined;
  }
}
