/**
 * Pin the sprint state machine. The "active → cancelled" edge exists
 * because sometimes a sprint genuinely fails — pretending to "complete"
 * a sprint that was abandoned is worse than letting it die honestly.
 */
import { describe, expect, it } from "vitest";

const TRANSITIONS: Record<string, string[]> = {
  planned: ["active", "cancelled"],
  active: ["completed", "cancelled"],
  completed: [],
  cancelled: [],
};

describe("sprint transitions", () => {
  it("planned can be activated or cancelled", () => {
    expect(TRANSITIONS.planned).toEqual(expect.arrayContaining(["active", "cancelled"]));
  });
  it("active can complete or cancel — not return to planned", () => {
    expect(TRANSITIONS.active).not.toContain("planned");
  });
  it("completed and cancelled are terminal", () => {
    expect(TRANSITIONS.completed).toEqual([]);
    expect(TRANSITIONS.cancelled).toEqual([]);
  });
});
