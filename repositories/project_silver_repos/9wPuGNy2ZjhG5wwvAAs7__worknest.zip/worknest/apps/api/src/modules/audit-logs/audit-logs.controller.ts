import { Controller, Get, Param, Query, UseGuards } from "@nestjs/common";
import { AuthGuard } from "../../common/auth.guard";
import { CurrentOrgId } from "../../common/current-user.decorator";
import { RequiresPermission } from "../../common/permissions.guard";
import { AuditLogsService } from "./audit-logs.service";

@UseGuards(AuthGuard)
@Controller("audit-logs")
export class AuditLogsController {
  constructor(private readonly audit: AuditLogsService) {}

  @Get()
  @RequiresPermission("audit:read")
  list(
    @CurrentOrgId() orgId: string,
    @Query("page") page?: string,
    @Query("pageSize") pageSize?: string,
    @Query("action") action?: string,
    @Query("resource") resource?: string,
    @Query("actorId") actorId?: string,
    @Query("q") q?: string,
  ) {
    return this.audit.list(orgId, {
      page: page ? Number(page) : undefined,
      pageSize: pageSize ? Number(pageSize) : undefined,
      action,
      resource,
      actorId,
      q,
    });
  }

  @Get(":resource/:resourceId")
  @RequiresPermission("audit:read")
  forResource(@Param("resource") r: string, @Param("resourceId") id: string) {
    return this.audit.forResource(r, id);
  }
}
