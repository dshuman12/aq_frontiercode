/**
 * Slack message formatters. Each takes a domain object and returns
 * the {text, blocks} shape Slack's webhook expects. Keep formatting
 * separate from transport so we can render-test without network.
 */
import type { SlackPayload } from "./slack.service";

export function ticketCreatedPayload(input: {
  key: string;
  title: string;
  priority: string;
  url: string;
  requesterName: string;
}): SlackPayload {
  return {
    text: `New ticket ${input.key}: ${input.title}`,
    blocks: [
      {
        type: "section",
        text: { type: "mrkdwn", text: `*New ticket ${input.key}*\n${input.title}` },
      },
      {
        type: "section",
        fields: [
          { type: "mrkdwn", text: `*Priority:* ${input.priority}` },
          { type: "mrkdwn", text: `*Requester:* ${input.requesterName}` },
        ],
      },
      {
        type: "section",
        text: { type: "mrkdwn", text: `<${input.url}|View ticket>` },
      },
    ],
  };
}

export function slaBreachPayload(input: {
  key: string;
  title: string;
  reason: "first_response" | "resolution";
  url: string;
}): SlackPayload {
  return {
    text: `:rotating_light: SLA breached on ${input.key}`,
    blocks: [
      {
        type: "section",
        text: {
          type: "mrkdwn",
          text: `:rotating_light: *SLA breached* on ${input.key}\n${input.title}`,
        },
      },
      {
        type: "section",
        fields: [{ type: "mrkdwn", text: `*Reason:* ${input.reason.replace("_", " ")}` }],
      },
      {
        type: "section",
        text: { type: "mrkdwn", text: `<${input.url}|Open ticket>` },
      },
    ],
  };
}

export function digestPayload(input: {
  org: string;
  openTickets: number;
  overdueTasks: number;
  url: string;
}): SlackPayload {
  return {
    text: `Daily digest for ${input.org}`,
    blocks: [
      {
        type: "section",
        text: { type: "mrkdwn", text: `*Daily digest for ${input.org}*` },
      },
      {
        type: "section",
        fields: [
          { type: "mrkdwn", text: `*Open tickets:* ${input.openTickets}` },
          { type: "mrkdwn", text: `*Overdue tasks:* ${input.overdueTasks}` },
        ],
      },
      {
        type: "section",
        text: { type: "mrkdwn", text: `<${input.url}|Open WorkNest>` },
      },
    ],
  };
}
