import { Injectable } from "@nestjs/common";
import { prisma } from "@worknest/database";
import { DEFAULT_PREFERENCES, rowsToMap } from "@worknest/notifications";

@Injectable()
export class NotificationsService {
  async list(userId: string, organizationId: string, opts?: { unread?: boolean; page?: number; pageSize?: number }) {
    const page = Math.max(1, opts?.page ?? 1);
    const pageSize = Math.min(200, Math.max(1, opts?.pageSize ?? 50));
    const where: Record<string, unknown> = { userId, organizationId };
    if (opts?.unread) where.readAt = null;
    const [items, total] = await Promise.all([
      prisma.notification.findMany({
        where,
        skip: (page - 1) * pageSize,
        take: pageSize,
        orderBy: { occurredAt: "desc" },
      }),
      prisma.notification.count({ where }),
    ]);
    return { items, total, page, pageSize };
  }

  async unread(userId: string, organizationId: string) {
    return prisma.notification.findMany({
      where: { userId, organizationId, readAt: null },
      orderBy: { occurredAt: "desc" },
    });
  }

  async markRead(userId: string, ids: string[]) {
    await prisma.notification.updateMany({
      where: { id: { in: ids }, userId },
      data: { readAt: new Date() },
    });
    return { ok: true };
  }

  async markAllRead(userId: string, organizationId: string) {
    await prisma.notification.updateMany({
      where: { userId, organizationId, readAt: null },
      data: { readAt: new Date() },
    });
    return { ok: true };
  }

  async preferencesFor(userId: string) {
    const rows = await prisma.notificationPreference.findMany({
      where: { userId },
    });
    return rowsToMap(rows.map((r) => ({
      userId: r.userId,
      kind: r.kind as never,
      channel: r.channel as never,
      enabled: r.enabled,
    })));
  }

  async setPreference(userId: string, kind: string, channel: string, enabled: boolean) {
    await prisma.notificationPreference.upsert({
      where: { userId_kind_channel: { userId, kind, channel } },
      create: { userId, kind, channel, enabled },
      update: { enabled },
    });
    return { ok: true };
  }

  async resetPreferencesToDefault(userId: string) {
    await prisma.notificationPreference.deleteMany({ where: { userId } });
    return DEFAULT_PREFERENCES;
  }

  /**
   * Persist a notification row. The worker calls this; the realtime
   * gateway is responsible for pushing it to connected clients.
   */
  async persist(input: {
    organizationId: string;
    userId: string;
    kind: string;
    title: string;
    body?: string;
    link?: string;
    severity?: string;
  }) {
    return prisma.notification.create({
      data: {
        organizationId: input.organizationId,
        userId: input.userId,
        kind: input.kind,
        title: input.title,
        body: input.body,
        link: input.link,
        severity: input.severity ?? "info",
      },
    });
  }
}
