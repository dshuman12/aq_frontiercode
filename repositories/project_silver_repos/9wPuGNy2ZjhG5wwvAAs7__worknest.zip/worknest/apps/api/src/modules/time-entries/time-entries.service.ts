/**
 * Time tracking. Each entry pins a user's session of work on a task.
 * The "running timer" semantic is enforced in code: a user can only
 * have one TimeEntry with `endedAt: null` at a time. When they start
 * a new timer with one already running, we stop the prior one with
 * `endedAt = now()` to mirror what most desktop time-tracking apps
 * do — surprise data loss is worse than an audit log entry.
 */
import {
  BadRequestException,
  ConflictException,
  Injectable,
  NotFoundException,
} from "@nestjs/common";
import { prisma } from "@worknest/database";

@Injectable()
export class TimeEntriesService {
  async list(args: {
    organizationId: string;
    taskId?: string;
    userId?: string;
    projectId?: string;
    fromDate?: Date;
    toDate?: Date;
    billable?: boolean;
    page: number;
    pageSize: number;
  }) {
    const where: Record<string, unknown> = {
      task: { project: { organizationId: args.organizationId } },
    };
    if (args.taskId) where.taskId = args.taskId;
    if (args.userId) where.userId = args.userId;
    if (args.billable !== undefined) where.billable = args.billable;
    if (args.projectId) {
      where.task = {
        project: { organizationId: args.organizationId, id: args.projectId },
      };
    }
    if (args.fromDate || args.toDate) {
      const range: Record<string, Date> = {};
      if (args.fromDate) range.gte = args.fromDate;
      if (args.toDate) range.lte = args.toDate;
      where.startedAt = range;
    }
    const [items, total, agg] = await Promise.all([
      prisma.timeEntry.findMany({
        where,
        skip: (args.page - 1) * args.pageSize,
        take: args.pageSize,
        orderBy: { startedAt: "desc" },
        include: {
          task: { select: { id: true, key: true, title: true, projectId: true } },
          user: { select: { id: true, name: true, email: true } },
        },
      }),
      prisma.timeEntry.count({ where }),
      prisma.timeEntry.aggregate({
        where: { ...where, durationSeconds: { not: null } },
        _sum: { durationSeconds: true },
      }),
    ]);
    return {
      items,
      total,
      page: args.page,
      pageSize: args.pageSize,
      totalSeconds: agg._sum.durationSeconds ?? 0,
    };
  }

  async startTimer(args: {
    organizationId: string;
    userId: string;
    taskId: string;
    description?: string;
    billable: boolean;
  }) {
    await this.requireTaskInOrg(args.organizationId, args.taskId);
    const running = await prisma.timeEntry.findFirst({
      where: { userId: args.userId, endedAt: null },
    });
    if (running) {
      const now = new Date();
      const seconds = Math.max(
        0,
        Math.floor((now.getTime() - running.startedAt.getTime()) / 1000),
      );
      await prisma.timeEntry.update({
        where: { id: running.id },
        data: { endedAt: now, durationSeconds: seconds },
      });
    }
    return prisma.timeEntry.create({
      data: {
        taskId: args.taskId,
        userId: args.userId,
        description: args.description,
        billable: args.billable,
        startedAt: new Date(),
      },
    });
  }

  async stopTimer(args: { organizationId: string; userId: string; endedAt: Date }) {
    const running = await prisma.timeEntry.findFirst({
      where: { userId: args.userId, endedAt: null },
      include: { task: { include: { project: true } } },
    });
    if (!running) throw new NotFoundException("no_running_timer");
    if (running.task.project.organizationId !== args.organizationId) {
      throw new NotFoundException();
    }
    if (args.endedAt <= running.startedAt) {
      throw new BadRequestException("end_must_be_after_start");
    }
    const seconds = Math.floor(
      (args.endedAt.getTime() - running.startedAt.getTime()) / 1000,
    );
    return prisma.timeEntry.update({
      where: { id: running.id },
      data: { endedAt: args.endedAt, durationSeconds: seconds },
    });
  }

  async runningTimer(userId: string) {
    return prisma.timeEntry.findFirst({
      where: { userId, endedAt: null },
      include: {
        task: { select: { id: true, key: true, title: true, projectId: true } },
      },
    });
  }

  async createManual(args: {
    organizationId: string;
    userId: string;
    taskId: string;
    description?: string;
    startedAt: Date;
    endedAt: Date;
    billable: boolean;
  }) {
    await this.requireTaskInOrg(args.organizationId, args.taskId);
    if (args.endedAt <= args.startedAt) {
      throw new BadRequestException("end_must_be_after_start");
    }
    const seconds = Math.floor(
      (args.endedAt.getTime() - args.startedAt.getTime()) / 1000,
    );
    return prisma.timeEntry.create({
      data: {
        taskId: args.taskId,
        userId: args.userId,
        description: args.description,
        startedAt: args.startedAt,
        endedAt: args.endedAt,
        durationSeconds: seconds,
        billable: args.billable,
      },
    });
  }

  async update(args: {
    organizationId: string;
    userId: string;
    id: string;
    patch: {
      description?: string | null;
      startedAt?: Date;
      endedAt?: Date;
      billable?: boolean;
    };
  }) {
    const e = await prisma.timeEntry.findUnique({
      where: { id: args.id },
      include: { task: { include: { project: true } } },
    });
    if (!e || e.task.project.organizationId !== args.organizationId) {
      throw new NotFoundException();
    }
    if (e.userId !== args.userId) {
      throw new ConflictException("not_your_entry");
    }
    const startedAt = args.patch.startedAt ?? e.startedAt;
    const endedAt = args.patch.endedAt ?? e.endedAt;
    if (endedAt && endedAt <= startedAt) {
      throw new BadRequestException("end_must_be_after_start");
    }
    const durationSeconds =
      endedAt != null
        ? Math.floor((endedAt.getTime() - startedAt.getTime()) / 1000)
        : null;
    return prisma.timeEntry.update({
      where: { id: e.id },
      data: { ...args.patch, durationSeconds },
    });
  }

  async remove(args: { organizationId: string; userId: string; id: string }) {
    const e = await prisma.timeEntry.findUnique({
      where: { id: args.id },
      include: { task: { include: { project: true } } },
    });
    if (!e || e.task.project.organizationId !== args.organizationId) {
      throw new NotFoundException();
    }
    if (e.userId !== args.userId) throw new ConflictException("not_your_entry");
    await prisma.timeEntry.delete({ where: { id: e.id } });
    return { ok: true };
  }

  async taskRollup(args: { organizationId: string; taskId: string }) {
    await this.requireTaskInOrg(args.organizationId, args.taskId);
    const grouped = await prisma.timeEntry.groupBy({
      by: ["userId"],
      where: { taskId: args.taskId, durationSeconds: { not: null } },
      _sum: { durationSeconds: true },
    });
    const total = grouped.reduce((s, g) => s + (g._sum.durationSeconds ?? 0), 0);
    return { total, byUser: grouped };
  }

  async projectRollup(args: { organizationId: string; projectId: string }) {
    const sum = await prisma.timeEntry.aggregate({
      where: {
        durationSeconds: { not: null },
        task: { projectId: args.projectId, project: { organizationId: args.organizationId } },
      },
      _sum: { durationSeconds: true },
    });
    return { totalSeconds: sum._sum.durationSeconds ?? 0 };
  }

  private async requireTaskInOrg(organizationId: string, taskId: string) {
    const task = await prisma.task.findUnique({
      where: { id: taskId },
      include: { project: true },
    });
    if (!task || task.project.organizationId !== organizationId) {
      throw new NotFoundException("task_not_found");
    }
    return task;
  }
}
