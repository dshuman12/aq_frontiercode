import { Module } from "@nestjs/common";
import { ThrottlerModule } from "@nestjs/throttler";
import { AuthModule } from "./modules/auth/auth.module";
import { UsersModule } from "./modules/users/users.module";
import { OrganizationsModule } from "./modules/organizations/organizations.module";
import { InvitationsModule } from "./modules/invitations/invitations.module";
import { RolesModule } from "./modules/roles/roles.module";
import { TeamsModule } from "./modules/teams/teams.module";
import { ProjectsModule } from "./modules/projects/projects.module";
import { BoardsModule } from "./modules/boards/boards.module";
import { TasksModule } from "./modules/tasks/tasks.module";
import { TicketsModule } from "./modules/tickets/tickets.module";
import { RequestsModule } from "./modules/requests/requests.module";
import { ApprovalsModule } from "./modules/approvals/approvals.module";
import { AssetsModule } from "./modules/assets/assets.module";
import { InventoryModule } from "./modules/inventory/inventory.module";
import { ClientsModule } from "./modules/clients/clients.module";
import { NotificationsModule } from "./modules/notifications/notifications.module";
import { ReportsModule } from "./modules/reports/reports.module";
import { BillingModule } from "./modules/billing/billing.module";
import { AuditLogsModule } from "./modules/audit-logs/audit-logs.module";
import { ApiKeysModule } from "./modules/api-keys/api-keys.module";
import { WebhooksModule } from "./modules/webhooks/webhooks.module";
import { FilesModule } from "./modules/files/files.module";
import { TimeEntriesModule } from "./modules/time-entries/time-entries.module";
import { SlaModule } from "./modules/sla/sla.module";
import { SavedViewsModule } from "./modules/saved-views/saved-views.module";
import { SprintsModule } from "./modules/sprints/sprints.module";
import { AutomationModule } from "./modules/automation/automation.module";
import { BulkModule } from "./modules/bulk/bulk.module";
import { SearchModule } from "./modules/search/search.module";
import { CsvModule } from "./modules/csv/csv.module";
import { ActivityModule } from "./modules/activity/activity.module";
import { TaskTemplatesModule } from "./modules/task-templates/task-templates.module";
import { RecurringTasksModule } from "./modules/recurring-tasks/recurring-tasks.module";
import { KnowledgeModule } from "./modules/knowledge/knowledge.module";
import { CommentsModule } from "./modules/comments/comments.module";
import { CalendarModule } from "./modules/calendar/calendar.module";
import { GanttModule } from "./modules/gantt/gantt.module";
import { IntegrationsModule } from "./modules/integrations/integrations.module";
import { SsoModule } from "./modules/sso/sso.module";
import { HealthController } from "./modules/health.controller";

@Module({
  imports: [
    ThrottlerModule.forRoot([{ ttl: 60_000, limit: 200 }]),
    AuthModule,
    UsersModule,
    OrganizationsModule,
    InvitationsModule,
    RolesModule,
    TeamsModule,
    ProjectsModule,
    BoardsModule,
    TasksModule,
    TicketsModule,
    RequestsModule,
    ApprovalsModule,
    AssetsModule,
    InventoryModule,
    ClientsModule,
    NotificationsModule,
    ReportsModule,
    BillingModule,
    AuditLogsModule,
    ApiKeysModule,
    WebhooksModule,
    FilesModule,
    TimeEntriesModule,
    SlaModule,
    SavedViewsModule,
    SprintsModule,
    AutomationModule,
    BulkModule,
    SearchModule,
    CsvModule,
    ActivityModule,
    TaskTemplatesModule,
    RecurringTasksModule,
    KnowledgeModule,
    CommentsModule,
    CalendarModule,
    GanttModule,
    IntegrationsModule,
    SsoModule,
  ],
  controllers: [HealthController],
})
export class AppModule {}
