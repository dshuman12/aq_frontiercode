import { describe, expect, it } from "vitest";
import { sanitizeHtml } from "./sanitize-html";

describe("sanitizeHtml", () => {
  it("keeps allowed tags + attrs", () => {
    expect(sanitizeHtml('<p>hello <a href="https://x.test">link</a></p>')).toBe(
      '<p>hello <a href="https://x.test">link</a></p>',
    );
  });

  it("strips disallowed tags", () => {
    expect(sanitizeHtml("<script>bad()</script><p>good</p>")).toBe("bad()<p>good</p>");
  });

  it("strips on* attributes", () => {
    expect(sanitizeHtml('<a href="https://x.test" onclick="alert(1)">x</a>')).toBe(
      '<a href="https://x.test">x</a>',
    );
  });

  it("rejects javascript: hrefs", () => {
    expect(sanitizeHtml('<a href="javascript:alert(1)">x</a>')).toBe("<a>x</a>");
  });
});
