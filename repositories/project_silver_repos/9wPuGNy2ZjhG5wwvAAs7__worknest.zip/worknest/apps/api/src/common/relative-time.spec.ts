import { describe, expect, it } from "vitest";
import { relativeTime } from "./relative-time";

const now = new Date("2025-06-27T12:00:00Z");

describe("relativeTime", () => {
  it("seconds in past", () => {
    expect(relativeTime(new Date("2025-06-27T11:59:30Z"), now)).toBe("30 seconds ago");
  });
  it("singular minute", () => {
    expect(relativeTime(new Date("2025-06-27T11:59:00Z"), now)).toBe("1 minute ago");
  });
  it("future", () => {
    expect(relativeTime(new Date("2025-06-27T13:00:00Z"), now)).toBe("in 1 hour");
  });
  it("days", () => {
    expect(relativeTime(new Date("2025-06-25T12:00:00Z"), now)).toBe("2 days ago");
  });
  it("weeks", () => {
    expect(relativeTime(new Date("2025-06-13T12:00:00Z"), now)).toBe("2 weeks ago");
  });
});
