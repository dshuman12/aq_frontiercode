import {
  CanActivate,
  ExecutionContext,
  Injectable,
  UnauthorizedException,
} from "@nestjs/common";
import { verifyAccessToken } from "@worknest/auth";

@Injectable()
export class AuthGuard implements CanActivate {
  canActivate(context: ExecutionContext): boolean {
    const req = context.switchToHttp().getRequest();
    const auth = req.headers["authorization"] as string | undefined;
    if (!auth?.startsWith("Bearer ")) {
      throw new UnauthorizedException("missing bearer token");
    }
    const token = auth.slice("Bearer ".length).trim();
    const secret = process.env.JWT_ACCESS_SECRET;
    if (!secret) throw new Error("JWT_ACCESS_SECRET not configured");
    try {
      req.user = verifyAccessToken(token, secret);
      return true;
    } catch {
      throw new UnauthorizedException("invalid token");
    }
  }
}
