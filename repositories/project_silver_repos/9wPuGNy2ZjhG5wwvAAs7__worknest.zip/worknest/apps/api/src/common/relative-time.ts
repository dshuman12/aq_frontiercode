/**
 * Compact relative-time formatter used in notification bodies and
 * activity summaries. We don't pull `dayjs` or `date-fns` for one
 * 30-line function.
 */

export function relativeTime(when: Date | string, now: Date = new Date()): string {
  const t = typeof when === "string" ? new Date(when) : when;
  const diff = (t.getTime() - now.getTime()) / 1000;
  const abs = Math.abs(diff);

  const units: [number, string][] = [
    [60, "second"],
    [60, "minute"],
    [24, "hour"],
    [7, "day"],
    [4.345, "week"],
    [12, "month"],
    [Number.POSITIVE_INFINITY, "year"],
  ];

  let value = abs;
  let unit = "second";
  for (const [step, name] of units) {
    if (value < step) {
      unit = name;
      break;
    }
    value /= step;
    unit = name;
  }
  const rounded = Math.round(value);
  const plural = rounded === 1 ? unit : `${unit}s`;
  return diff > 0 ? `in ${rounded} ${plural}` : `${rounded} ${plural} ago`;
}
