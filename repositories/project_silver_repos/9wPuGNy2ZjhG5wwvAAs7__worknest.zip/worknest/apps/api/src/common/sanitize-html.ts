/**
 * Tiny HTML sanitizer for user-provided rich text (knowledge articles,
 * automation comment bodies). Whitelist of tags + attributes; anything
 * else is dropped. We intentionally don't ship a full DOMPurify-style
 * sanitizer because rendering happens client-side via the Markdown
 * component; this is the API-side belt-and-suspenders for legacy
 * `body` fields that historically allowed HTML.
 */

const ALLOWED_TAGS = new Set([
  "a",
  "b",
  "strong",
  "i",
  "em",
  "u",
  "p",
  "br",
  "ul",
  "ol",
  "li",
  "code",
  "pre",
  "blockquote",
  "h1",
  "h2",
  "h3",
]);

const ALLOWED_ATTRS_BY_TAG: Record<string, Set<string>> = {
  a: new Set(["href", "title", "rel"]),
};

export function sanitizeHtml(input: string): string {
  return input.replace(/<\s*(\/?)([a-z0-9]+)([^>]*)>/gi, (_full, slash, tagRaw, attrsRaw) => {
    const tag = tagRaw.toLowerCase();
    if (!ALLOWED_TAGS.has(tag)) return "";
    if (slash) return `</${tag}>`;
    const cleanedAttrs = sanitizeAttrs(tag, attrsRaw);
    return `<${tag}${cleanedAttrs ? " " + cleanedAttrs : ""}>`;
  });
}

function sanitizeAttrs(tag: string, attrsRaw: string): string {
  const allowed = ALLOWED_ATTRS_BY_TAG[tag] ?? new Set<string>();
  const out: string[] = [];
  for (const m of attrsRaw.matchAll(/([a-z][a-z0-9-]*)\s*=\s*"([^"]*)"/gi)) {
    const name = m[1].toLowerCase();
    if (!allowed.has(name)) continue;
    if (name === "href") {
      const value = m[2].trim();
      if (!/^(https?:\/\/|mailto:|\/)/i.test(value)) continue;
      out.push(`href="${value.replace(/"/g, "&quot;")}"`);
    } else {
      out.push(`${name}="${m[2].replace(/"/g, "&quot;")}"`);
    }
  }
  return out.join(" ");
}
