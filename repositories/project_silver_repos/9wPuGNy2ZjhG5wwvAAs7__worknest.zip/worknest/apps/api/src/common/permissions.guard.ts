import {
  CanActivate,
  ExecutionContext,
  ForbiddenException,
  Injectable,
  SetMetadata,
} from "@nestjs/common";
import { Reflector } from "@nestjs/core";
import {
  buildContext,
  can,
  Permission,
  PermissionContext,
} from "@worknest/permissions";

const PERMISSION_KEY = "worknest:requires-permission";

export const RequiresPermission = (permission: Permission) =>
  SetMetadata(PERMISSION_KEY, permission);

export const Public = () => SetMetadata("worknest:public", true);

@Injectable()
export class PermissionsGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const required = this.reflector.getAllAndOverride<Permission | undefined>(
      PERMISSION_KEY,
      [context.getHandler(), context.getClass()],
    );
    if (!required) return true;

    const req = context.switchToHttp().getRequest();
    const user = req.user as { sub: string; orgId: string; role: string } | undefined;
    if (!user) throw new ForbiddenException();
    const ctx: PermissionContext = buildContext({
      userId: user.sub,
      organizationId: user.orgId,
      role: user.role,
    });
    if (!can(ctx, required)) {
      throw new ForbiddenException(`Missing permission: ${required}`);
    }
    req.permissionContext = ctx;
    return true;
  }
}
