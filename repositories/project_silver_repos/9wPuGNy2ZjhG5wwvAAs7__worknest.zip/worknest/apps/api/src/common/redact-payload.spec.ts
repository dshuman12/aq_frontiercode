import { describe, expect, it } from "vitest";
import { redactPayload } from "./redact-payload";

describe("redactPayload", () => {
  it("redacts top-level sensitive keys", () => {
    expect(redactPayload({ password: "p", username: "u" })).toEqual({
      password: "[REDACTED]",
      username: "u",
    });
  });
  it("recurses into nested objects", () => {
    expect(redactPayload({ user: { email: "e", refreshToken: "rt" } })).toEqual({
      user: { email: "e", refreshToken: "[REDACTED]" },
    });
  });
  it("recurses into arrays", () => {
    expect(redactPayload([{ token: "x" }, { token: "y" }])).toEqual([
      { token: "[REDACTED]" },
      { token: "[REDACTED]" },
    ]);
  });
  it("returns scalars unchanged", () => {
    expect(redactPayload("plain")).toBe("plain");
    expect(redactPayload(42)).toBe(42);
    expect(redactPayload(null)).toBe(null);
  });
});
