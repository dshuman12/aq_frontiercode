/**
 * Redact obviously-sensitive keys from a payload before logging or
 * persisting an audit trail. We never want a password, refresh
 * token, or webhook secret in our pino streams.
 *
 * The list is intentionally short — log redaction is a defense in
 * depth, not the primary control. Real secrets must never reach the
 * server in the first place (or be in transit via TLS only).
 */

const SENSITIVE_KEYS = new Set([
  "password",
  "passwordHash",
  "currentPassword",
  "newPassword",
  "refreshToken",
  "accessToken",
  "secret",
  "token",
  "apiKey",
  "tokenHash",
  "twoFactorSecret",
]);

export function redactPayload<T>(input: T): T {
  if (input == null || typeof input !== "object") return input;
  if (Array.isArray(input)) return input.map(redactPayload) as unknown as T;
  const out: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(input as Record<string, unknown>)) {
    if (SENSITIVE_KEYS.has(key)) {
      out[key] = "[REDACTED]";
    } else {
      out[key] = redactPayload(value);
    }
  }
  return out as T;
}
