import { describe, expect, it } from "vitest";
import { decodePage, envelope } from "./cursor-pagination";

describe("decodePage", () => {
  it("defaults to page 1, size 50", () => {
    expect(decodePage()).toEqual({ page: 1, pageSize: 50, take: 50, skip: 0 });
  });
  it("clamps page size to 200", () => {
    expect(decodePage({ pageSize: 9999 }).pageSize).toBe(200);
  });
  it("clamps page to >= 1", () => {
    expect(decodePage({ page: 0 }).page).toBe(1);
    expect(decodePage({ page: -3 }).page).toBe(1);
  });
  it("computes skip from (page - 1) * pageSize", () => {
    expect(decodePage({ page: 4, pageSize: 25 }).skip).toBe(75);
  });
  it("accepts strings", () => {
    expect(decodePage({ page: "3", pageSize: "10" })).toEqual({
      page: 3,
      pageSize: 10,
      take: 10,
      skip: 20,
    });
  });
});

describe("envelope", () => {
  it("wraps items + total + page metadata", () => {
    const decoded = decodePage({ page: 2, pageSize: 5 });
    expect(envelope([{ id: "a" }], 7, decoded)).toEqual({
      items: [{ id: "a" }],
      total: 7,
      page: 2,
      pageSize: 5,
    });
  });
});
