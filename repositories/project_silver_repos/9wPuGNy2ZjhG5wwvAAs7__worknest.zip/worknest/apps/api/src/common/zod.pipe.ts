import { BadRequestException, PipeTransform } from "@nestjs/common";
import { ZodSchema } from "zod";

export class ZodPipe<T> implements PipeTransform<unknown, T> {
  constructor(private readonly schema: ZodSchema<T>) {}

  transform(value: unknown): T {
    const result = this.schema.safeParse(value);
    if (!result.success) {
      throw new BadRequestException({
        message: "validation_failed",
        errors: result.error.errors.map((e) => ({
          path: e.path,
          message: e.message,
          code: e.code,
        })),
      });
    }
    return result.data;
  }
}
