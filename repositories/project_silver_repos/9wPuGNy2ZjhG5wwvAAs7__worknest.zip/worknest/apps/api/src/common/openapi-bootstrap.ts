/**
 * Lightweight OpenAPI bootstrap. We don't run @nestjs/swagger because
 * the docs surface we ship is stable + small, and a hand-shaped spec
 * keeps the generated `LedgerFleet`-style client predictable.
 *
 * `bootstrapOpenApi` populates a base description; module authors
 * register their tags + paths via `registerOpenApiPaths`.
 */

interface OpenApiPath {
  path: string;
  method: "get" | "post" | "patch" | "put" | "delete";
  tag: string;
  summary: string;
  responseExample?: unknown;
}

const paths: OpenApiPath[] = [];

export function registerOpenApiPaths(items: OpenApiPath[]): void {
  paths.push(...items);
}

export function buildOpenApiDocument(version: string): unknown {
  const tagged = new Map<string, OpenApiPath[]>();
  for (const p of paths) {
    if (!tagged.has(p.tag)) tagged.set(p.tag, []);
    tagged.get(p.tag)!.push(p);
  }
  return {
    openapi: "3.1.0",
    info: { title: "WorkNest API", version },
    tags: Array.from(tagged.keys()).map((name) => ({ name })),
    paths: Object.fromEntries(
      paths.map((p) => [
        p.path,
        {
          [p.method]: {
            tags: [p.tag],
            summary: p.summary,
            responses: {
              "200": p.responseExample
                ? { description: "OK", content: { "application/json": { example: p.responseExample } } }
                : { description: "OK" },
            },
          },
        },
      ]),
    ),
  };
}
