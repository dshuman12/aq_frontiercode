import { BadRequestException, ConflictException, NotFoundException } from "@nestjs/common";
import { describe, expect, it } from "vitest";
import { normalize } from "./json-error-filter";

describe("normalize", () => {
  it("normalizes BadRequestException with object body", () => {
    const e = new BadRequestException({ message: "validation_failed", code: "ZOD" });
    const body = normalize(e);
    expect(body).toMatchObject({
      status: 400,
      error: "BadRequest",
      message: "validation_failed",
      code: "ZOD",
    });
  });

  it("normalizes ConflictException with string body", () => {
    const e = new ConflictException("slug_in_use");
    const body = normalize(e);
    expect(body).toMatchObject({ status: 409, message: "slug_in_use", error: "Conflict" });
  });

  it("normalizes NotFoundException", () => {
    const body = normalize(new NotFoundException());
    expect(body.status).toBe(404);
    expect(body.error).toBe("NotFound");
  });

  it("falls through to 500 on unknown errors", () => {
    expect(normalize(new Error("boom"))).toEqual({
      status: 500,
      error: "InternalServerError",
      message: "unexpected_error",
    });
  });
});
