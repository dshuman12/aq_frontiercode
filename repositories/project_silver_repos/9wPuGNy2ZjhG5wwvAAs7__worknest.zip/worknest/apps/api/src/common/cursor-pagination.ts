/**
 * Shared cursor pagination helper. Several modules grew their own
 * (page, pageSize) decoders; this consolidates the pattern so adding
 * a new resource gives you the right defaults + sane caps for free.
 *
 * Usage:
 *   const { take, skip, page, pageSize } = decodePage(query);
 *   const items = await prisma.task.findMany({ where, take, skip });
 */

const DEFAULT_PAGE_SIZE = 50;
const MAX_PAGE_SIZE = 200;

export interface PageInput {
  page?: string | number;
  pageSize?: string | number;
}

export interface PageDecoded {
  page: number;
  pageSize: number;
  take: number;
  skip: number;
}

export function decodePage(input: PageInput = {}): PageDecoded {
  const page = clampInt(coerce(input.page) ?? 1, 1, 100_000);
  const pageSize = clampInt(coerce(input.pageSize) ?? DEFAULT_PAGE_SIZE, 1, MAX_PAGE_SIZE);
  return { page, pageSize, take: pageSize, skip: (page - 1) * pageSize };
}

export function envelope<T>(items: T[], total: number, decoded: PageDecoded) {
  return { items, total, page: decoded.page, pageSize: decoded.pageSize };
}

function coerce(v: unknown): number | undefined {
  if (v == null || v === "") return undefined;
  const n = typeof v === "number" ? v : Number(v);
  return Number.isFinite(n) ? n : undefined;
}

function clampInt(n: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, Math.floor(n)));
}
