/**
 * Global exception filter that ensures every 4xx/5xx body is the
 * shape `{ error, message, status, code? }` regardless of where the
 * exception was thrown. Without this, ZodPipe's BadRequestException
 * and our own ConflictException would render slightly differently;
 * downstream callers care about the difference.
 */
import { ArgumentsHost, Catch, ExceptionFilter, HttpException } from "@nestjs/common";

interface NormalizedBody {
  error: string;
  message: string;
  status: number;
  code?: string;
  details?: unknown;
}

@Catch()
export class JsonErrorFilter implements ExceptionFilter {
  catch(exception: unknown, host: ArgumentsHost): void {
    const ctx = host.switchToHttp();
    const res = ctx.getResponse<{
      status: (n: number) => unknown;
      json: (b: unknown) => unknown;
    }>();

    const body = normalize(exception);
    res.status(body.status);
    res.json(body);
  }
}

export function normalize(exception: unknown): NormalizedBody {
  if (exception instanceof HttpException) {
    const status = exception.getStatus();
    const raw = exception.getResponse();
    if (typeof raw === "string") {
      return { error: name(status), message: raw, status };
    }
    if (raw && typeof raw === "object") {
      const obj = raw as Record<string, unknown>;
      return {
        error: typeof obj.error === "string" ? obj.error : name(status),
        message:
          typeof obj.message === "string"
            ? obj.message
            : Array.isArray(obj.message)
              ? (obj.message as string[]).join(", ")
              : JSON.stringify(obj.message ?? ""),
        status,
        code: typeof obj.code === "string" ? obj.code : undefined,
        details: obj.details,
      };
    }
  }
  return { error: "InternalServerError", message: "unexpected_error", status: 500 };
}

function name(status: number): string {
  if (status === 400) return "BadRequest";
  if (status === 401) return "Unauthorized";
  if (status === 403) return "Forbidden";
  if (status === 404) return "NotFound";
  if (status === 409) return "Conflict";
  if (status === 422) return "UnprocessableEntity";
  if (status === 429) return "TooManyRequests";
  return "Error";
}
