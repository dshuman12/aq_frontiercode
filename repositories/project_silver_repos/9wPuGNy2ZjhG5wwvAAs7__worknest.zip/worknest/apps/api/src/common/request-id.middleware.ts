/**
 * Tag every request with a stable id (CUID-ish, 16 hex chars) so log
 * lines from different layers can be joined post-hoc. Honors an
 * incoming `X-Request-Id` header when present (typical for traffic
 * coming through a load balancer that already issues one).
 */
import { Injectable, NestMiddleware } from "@nestjs/common";
import { randomBytes } from "node:crypto";
import type { NextFunction, Request, Response } from "express";

@Injectable()
export class RequestIdMiddleware implements NestMiddleware {
  use(req: Request & { requestId?: string }, res: Response, next: NextFunction): void {
    const incoming = req.header("x-request-id");
    const id = incoming && /^[a-z0-9-]{8,128}$/i.test(incoming) ? incoming : randomBytes(8).toString("hex");
    req.requestId = id;
    res.setHeader("x-request-id", id);
    next();
  }
}
