/* eslint-disable */
/**
 * Minimal service worker — cache app shell, network-first for API,
 * cache-first for static assets. Designed to not break anything if
 * disabled; the registration is opt-in from the host page.
 */

const CACHE = "worknest-shell-v1";
const APP_SHELL = ["/", "/dashboard", "/manifest.json"];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(APP_SHELL)));
  self.skipWaiting();
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))),
    ),
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);
  if (event.request.method !== "GET") return;

  if (url.pathname.startsWith("/api/")) {
    event.respondWith(
      fetch(event.request).catch(async () => {
        const cached = await caches.match(event.request);
        return cached ?? new Response(JSON.stringify({ offline: true }), {
          status: 503,
          headers: { "content-type": "application/json" },
        });
      }),
    );
    return;
  }

  event.respondWith(
    caches.match(event.request).then((cached) => {
      const network = fetch(event.request)
        .then((res) => {
          const copy = res.clone();
          caches.open(CACHE).then((c) => c.put(event.request, copy));
          return res;
        })
        .catch(() => cached);
      return cached ?? network;
    }),
  );
});
