"use client";
import { useQuery } from "@tanstack/react-query";
import { TimerWidget } from "@worknest/ui";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";

interface RunningTimer {
  id: string;
  startedAt: string;
  task: { id: string; key: string; title: string };
}

export function RunningTimerNav() {
  const qc = useQueryClient();
  const running = useQuery({
    queryKey: ["time-entries", "running"],
    queryFn: () => api<RunningTimer | null>("/time-entries/running"),
    refetchInterval: 30_000,
  });
  const stop = useMutation({
    mutationFn: () =>
      api("/time-entries/stop", { method: "POST", body: { endedAt: new Date() } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["time-entries"] }),
  });
  if (!running.data) return null;
  return (
    <TimerWidget
      startedAt={running.data.startedAt}
      taskLabel={`${running.data.task.key} ${running.data.task.title}`}
      onStop={() => stop.mutate()}
    />
  );
}
