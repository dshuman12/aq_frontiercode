"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import { useKeyboardShortcuts } from "@worknest/ui";
import { api } from "@/lib/api";

interface SearchHit {
  resource: string;
  id: string;
  title: string;
  subtitle?: string;
  url: string;
}

export function CommandPalette() {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const router = useRouter();

  useKeyboardShortcuts({
    "/": (e) => {
      e.preventDefault();
      setOpen(true);
    },
    Escape: () => setOpen(false),
  });

  const hits = useQuery({
    queryKey: ["search", query],
    queryFn: () =>
      query.length >= 2
        ? api<{ hits: SearchHit[] }>(`/search?q=${encodeURIComponent(query)}`)
        : Promise.resolve({ hits: [] }),
    enabled: open,
  });

  useEffect(() => {
    if (!open) setQuery("");
  }, [open]);

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 bg-black/30 p-4">
      <div className="mx-auto max-w-xl rounded-lg bg-white shadow-xl">
        <input
          autoFocus
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search projects, tasks, tickets…"
          className="w-full rounded-t-lg border-b border-slate-200 px-4 py-3 text-sm focus:outline-none"
        />
        <ul className="max-h-80 overflow-y-auto py-2">
          {(hits.data?.hits ?? []).map((h) => (
            <li key={`${h.resource}:${h.id}`}>
              <button
                className="block w-full px-4 py-2 text-left text-sm hover:bg-slate-50"
                onClick={() => {
                  router.push(h.url);
                  setOpen(false);
                }}
              >
                <div className="font-medium">{h.title}</div>
                {h.subtitle ? (
                  <div className="text-xs text-slate-500">
                    {h.resource} · {h.subtitle}
                  </div>
                ) : null}
              </button>
            </li>
          ))}
          {query.length >= 2 && hits.data?.hits.length === 0 ? (
            <li className="px-4 py-3 text-xs text-slate-500">No results.</li>
          ) : null}
        </ul>
      </div>
    </div>
  );
}
