"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useAuth } from "@/stores/auth";
import { Avatar } from "@worknest/ui";

const NAV = [
  { href: "/dashboard", label: "Dashboard", icon: "📊" },
  { href: "/projects", label: "Projects", icon: "📁" },
  { href: "/tasks", label: "Tasks", icon: "✅" },
  { href: "/time", label: "Time", icon: "⏱️" },
  { href: "/activity", label: "Activity", icon: "📰" },
  { href: "/knowledge", label: "Knowledge", icon: "📚" },
  { href: "/calendar", label: "Calendar", icon: "📅" },
  { href: "/tickets", label: "Tickets", icon: "🎫" },
  { href: "/requests", label: "Requests", icon: "📋" },
  { href: "/approvals", label: "Approvals", icon: "👍" },
  { href: "/teams", label: "Teams", icon: "👥" },
  { href: "/clients", label: "Clients", icon: "🏢" },
  { href: "/assets", label: "Assets", icon: "💻" },
  { href: "/inventory", label: "Inventory", icon: "📦" },
  { href: "/reports", label: "Reports", icon: "📈" },
  { href: "/notifications", label: "Notifications", icon: "🔔" },
  { href: "/billing", label: "Billing", icon: "💳" },
  { href: "/settings", label: "Settings", icon: "⚙️" },
  { href: "/admin", label: "Admin", icon: "🛡️" },
];

export function Sidebar() {
  const pathname = usePathname();
  const user = useAuth((s) => s.user);

  return (
    <aside className="hidden md:flex w-60 flex-col border-r border-slate-200 bg-white">
      <div className="px-4 py-3 border-b border-slate-200">
        <Link href="/dashboard" className="font-bold text-brand-600 text-lg">
          WorkNest
        </Link>
      </div>
      <nav className="flex-1 overflow-y-auto py-2">
        {NAV.map((n) => {
          const active = pathname === n.href || pathname?.startsWith(`${n.href}/`);
          return (
            <Link
              key={n.href}
              href={n.href}
              className={`flex items-center gap-2 px-4 py-2 text-sm ${
                active
                  ? "bg-brand-50 text-brand-700 font-medium"
                  : "text-slate-700 hover:bg-slate-50"
              }`}
            >
              <span aria-hidden>{n.icon}</span>
              {n.label}
            </Link>
          );
        })}
      </nav>
      {user && (
        <div className="border-t border-slate-200 p-3 flex items-center gap-2">
          <Avatar size="sm" name={user.name} src={user.avatarUrl} />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate">{user.name}</p>
            <p className="text-xs text-slate-500 truncate">{user.email}</p>
          </div>
        </div>
      )}
    </aside>
  );
}
