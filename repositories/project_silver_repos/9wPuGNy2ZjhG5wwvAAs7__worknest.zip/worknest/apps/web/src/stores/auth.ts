import { create } from "zustand";
import { persist } from "zustand/middleware";

export interface AuthUser {
  id: string;
  email: string;
  name: string;
  avatarUrl?: string;
}

export interface AuthState {
  accessToken: string | null;
  refreshToken: string | null;
  sessionToken: string | null;
  user: AuthUser | null;
  activeOrgId: string | null;
  setSession(input: {
    accessToken: string;
    refreshToken: string;
    sessionToken: string;
    user: AuthUser;
  }): void;
  setActiveOrg(orgId: string | null): void;
  clear(): void;
}

export const useAuth = create<AuthState>()(
  persist(
    (set) => ({
      accessToken: null,
      refreshToken: null,
      sessionToken: null,
      user: null,
      activeOrgId: null,
      setSession({ accessToken, refreshToken, sessionToken, user }) {
        set({ accessToken, refreshToken, sessionToken, user });
      },
      setActiveOrg(orgId) {
        set({ activeOrgId: orgId });
      },
      clear() {
        set({
          accessToken: null,
          refreshToken: null,
          sessionToken: null,
          user: null,
          activeOrgId: null,
        });
      },
    }),
    { name: "worknest-auth" },
  ),
);
