"use client";
import { useEffect, useState } from "react";

type Locale = "en" | "es";

let bundles: Record<Locale, Record<string, string>> = {
  en: {},
  es: {},
};

export async function loadLocale(locale: Locale): Promise<void> {
  if (Object.keys(bundles[locale]).length > 0) return;
  const mod = await import(`../../messages/${locale}.json`);
  bundles[locale] = mod.default ?? mod;
}

export function t(locale: Locale, key: string, fallback?: string): string {
  return bundles[locale]?.[key] ?? fallback ?? key;
}

export function useLocale(): { locale: Locale; setLocale: (l: Locale) => void } {
  const [locale, setLocale] = useState<Locale>(() => {
    if (typeof window === "undefined") return "en";
    return (window.localStorage.getItem("worknest:locale") as Locale) ?? "en";
  });
  useEffect(() => {
    if (typeof window === "undefined") return;
    window.localStorage.setItem("worknest:locale", locale);
    void loadLocale(locale);
  }, [locale]);
  return { locale, setLocale };
}
