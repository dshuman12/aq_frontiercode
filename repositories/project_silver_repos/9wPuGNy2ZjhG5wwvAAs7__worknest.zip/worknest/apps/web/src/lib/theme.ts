"use client";
import { useEffect } from "react";

type Theme = "light" | "dark" | "system";

const STORAGE_KEY = "worknest:theme";

export function useTheme(): { theme: Theme; setTheme: (t: Theme) => void } {
  // We persist a single Theme value; the actual <html> class is
  // computed from media query when the value is "system".
  const setTheme = (t: Theme) => {
    if (typeof window === "undefined") return;
    window.localStorage.setItem(STORAGE_KEY, t);
    applyTheme(t);
  };
  const theme = (typeof window !== "undefined" && (window.localStorage.getItem(STORAGE_KEY) as Theme)) || "system";
  useEffect(() => applyTheme(theme), [theme]);
  return { theme, setTheme };
}

function applyTheme(t: Theme): void {
  if (typeof document === "undefined") return;
  const isDark =
    t === "dark" ||
    (t === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);
  document.documentElement.classList.toggle("dark", isDark);
}

export function bootstrapTheme(): void {
  if (typeof window === "undefined") return;
  const stored = (window.localStorage.getItem(STORAGE_KEY) as Theme) ?? "system";
  applyTheme(stored);
  if (stored === "system") {
    window
      .matchMedia("(prefers-color-scheme: dark)")
      .addEventListener("change", () => applyTheme("system"));
  }
}
