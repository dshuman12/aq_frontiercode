/**
 * Tiny `fetch` wrapper used by every web-app component. Handles auth
 * token attachment, JSON parsing, and structured 4xx/5xx errors.
 */

import { useAuth } from "@/stores/auth";

export class ApiError extends Error {
  constructor(public status: number, public body: unknown, message?: string) {
    super(message ?? `HTTP ${status}`);
    this.name = "ApiError";
  }
}

export async function api<T>(
  path: string,
  opts: { method?: string; body?: unknown; headers?: Record<string, string> } = {},
): Promise<T> {
  const token = useAuth.getState().accessToken;
  const headers: Record<string, string> = {
    "content-type": "application/json",
    ...(opts.headers ?? {}),
  };
  if (token) headers.authorization = `Bearer ${token}`;

  const res = await fetch(`/api${path}`, {
    method: opts.method ?? "GET",
    headers,
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  if (!res.ok) {
    let body: unknown = null;
    try { body = await res.json(); } catch {}
    throw new ApiError(res.status, body, (body as { message?: string } | null)?.message);
  }
  if (res.status === 204) return undefined as T;
  return res.json();
}
