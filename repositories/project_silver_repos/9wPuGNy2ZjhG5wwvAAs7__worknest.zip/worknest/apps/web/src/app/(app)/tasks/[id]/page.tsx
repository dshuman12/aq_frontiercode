"use client";
import Link from "next/link";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Avatar, Badge, Button, Card, CardBody, CardHeader, CardTitle, EmptyState, Tab, Tabs, Textarea, useToast } from "@worknest/ui";
import { api } from "@/lib/api";

interface TaskDetail {
  id: string;
  key: string;
  title: string;
  description?: string | null;
  status: string;
  priority: string;
  projectId: string;
  comments: { id: string; body: string; createdAt: string; author: { name: string } }[];
  activity: { id: string; type: string; createdAt: string }[];
  checklists: {
    id: string;
    title: string;
    items: { id: string; text: string; done: boolean }[];
  }[];
  labels: { id: string; name: string; color?: string }[];
  subtasks: { id: string; key: string; title: string; status: string }[];
}

export default function TaskDetailPage({ params }: { params: { id: string } }) {
  const id = params.id;
  const qc = useQueryClient();
  const toast = useToast();
  const [comment, setComment] = useState("");

  const task = useQuery({ queryKey: ["task", id], queryFn: () => api<TaskDetail>(`/tasks/${id}`) });

  const addComment = useMutation({
    mutationFn: (body: string) => api(`/tasks/${id}/comments`, { method: "POST", body: { body } }),
    onSuccess: () => {
      setComment("");
      qc.invalidateQueries({ queryKey: ["task", id] });
    },
  });

  const toggleChecklist = useMutation({
    mutationFn: (input: { itemId: string; done: boolean }) =>
      api(`/tasks/checklists/items/${input.itemId}`, { method: "PATCH", body: { done: input.done } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["task", id] }),
  });

  if (task.isLoading) return <Card><CardBody>Loading…</CardBody></Card>;
  if (!task.data) return <EmptyState title="Task not found" />;

  const t = task.data;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
      <div className="lg:col-span-2 space-y-4">
        <div>
          <Link href="/tasks" className="text-sm text-slate-500 hover:underline">Tasks</Link>
          <div className="flex items-center gap-2 mt-1">
            <Badge variant="outline">{t.key}</Badge>
            <h1 className="text-2xl font-semibold">{t.title}</h1>
          </div>
        </div>

        {t.description && (
          <Card>
            <CardHeader><CardTitle>Description</CardTitle></CardHeader>
            <CardBody><p className="whitespace-pre-line">{t.description}</p></CardBody>
          </Card>
        )}

        {t.checklists.length > 0 && (
          <Card>
            <CardHeader><CardTitle>Checklists</CardTitle></CardHeader>
            <CardBody className="space-y-3">
              {t.checklists.map((cl) => (
                <div key={cl.id}>
                  <p className="font-medium text-sm">{cl.title}</p>
                  <ul className="mt-1 space-y-1">
                    {cl.items.map((it) => (
                      <li key={it.id} className="flex items-center gap-2 text-sm">
                        <input
                          type="checkbox"
                          checked={it.done}
                          onChange={() => toggleChecklist.mutate({ itemId: it.id, done: !it.done })}
                          className="rounded border-slate-300"
                        />
                        <span className={it.done ? "line-through text-slate-400" : ""}>{it.text}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </CardBody>
          </Card>
        )}

        <Tabs>
          <Tab label={`Comments (${t.comments.length})`}>
            <div className="space-y-3">
              {t.comments.map((c) => (
                <Card key={c.id}>
                  <CardBody className="flex gap-3">
                    <Avatar size="sm" name={c.author.name} />
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="font-medium">{c.author.name}</span>
                        <span className="text-xs text-slate-500">{new Date(c.createdAt).toLocaleString()}</span>
                      </div>
                      <p className="text-sm mt-1 whitespace-pre-line">{c.body}</p>
                    </div>
                  </CardBody>
                </Card>
              ))}
              <Card>
                <CardBody>
                  <Textarea placeholder="Add a comment" value={comment} onChange={(e) => setComment(e.target.value)} rows={3} />
                  <div className="flex justify-end mt-2">
                    <Button onClick={() => addComment.mutate(comment)} disabled={!comment.trim()}>
                      Comment
                    </Button>
                  </div>
                </CardBody>
              </Card>
            </div>
          </Tab>
          <Tab label="Activity">
            <Card>
              <CardBody>
                {t.activity.length === 0 ? (
                  <p className="text-sm text-slate-500">No activity yet.</p>
                ) : (
                  <ol className="border-l border-slate-200 ml-2">
                    {t.activity.map((a) => (
                      <li key={a.id} className="ml-4 mb-3 relative">
                        <div className="absolute -left-1.5 mt-1.5 w-3 h-3 rounded-full bg-slate-300"></div>
                        <p className="text-sm">{a.type}</p>
                        <p className="text-xs text-slate-500">{new Date(a.createdAt).toLocaleString()}</p>
                      </li>
                    ))}
                  </ol>
                )}
              </CardBody>
            </Card>
          </Tab>
        </Tabs>
      </div>

      <div className="space-y-4">
        <Card>
          <CardHeader><CardTitle>Properties</CardTitle></CardHeader>
          <CardBody>
            <dl className="space-y-2 text-sm">
              <div className="flex justify-between"><dt className="text-slate-500">Status</dt><dd><Badge>{t.status}</Badge></dd></div>
              <div className="flex justify-between"><dt className="text-slate-500">Priority</dt><dd><Badge>{t.priority}</Badge></dd></div>
            </dl>
          </CardBody>
        </Card>
        {t.labels.length > 0 && (
          <Card>
            <CardHeader><CardTitle>Labels</CardTitle></CardHeader>
            <CardBody className="flex flex-wrap gap-2">
              {t.labels.map((l) => (
                <Badge key={l.id} variant="outline">
                  {l.name}
                </Badge>
              ))}
            </CardBody>
          </Card>
        )}
        {t.subtasks.length > 0 && (
          <Card>
            <CardHeader><CardTitle>Subtasks</CardTitle></CardHeader>
            <CardBody>
              <ul className="text-sm space-y-1">
                {t.subtasks.map((s) => (
                  <li key={s.id}>
                    <Link href={`/tasks/${s.id}`} className="hover:underline">
                      <Badge variant="outline">{s.key}</Badge> {s.title}
                    </Link>
                  </li>
                ))}
              </ul>
            </CardBody>
          </Card>
        )}
      </div>
    </div>
  );
}
