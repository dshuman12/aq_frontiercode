"use client";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Badge, Card, CardBody, EmptyState } from "@worknest/ui";
import { api } from "@/lib/api";

interface ActivityEvent {
  id: string;
  resource: string;
  resourceId: string;
  verb: string;
  summary: string;
  actorId: string | null;
  createdAt: string;
}

const RESOURCE_TONE: Record<string, "info" | "success" | "neutral" | "warning"> = {
  task: "info",
  ticket: "warning",
  request: "neutral",
  approval: "success",
  client: "neutral",
};

export default function ActivityFeedPage() {
  const [resource, setResource] = useState<string>("");

  const feed = useQuery({
    queryKey: ["activity", resource],
    queryFn: () =>
      api<{ items: ActivityEvent[]; total: number }>(
        `/activity${resource ? `?resource=${resource}` : ""}`,
      ),
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Activity</h1>
          <p className="text-sm text-slate-500">Everything happening across your workspace.</p>
        </div>
        <select
          value={resource}
          onChange={(e) => setResource(e.target.value)}
          className="h-10 rounded-md border border-slate-200 bg-white px-3 text-sm"
        >
          <option value="">All resources</option>
          <option value="task">Tasks</option>
          <option value="ticket">Tickets</option>
          <option value="request">Requests</option>
          <option value="approval">Approvals</option>
          <option value="client">Clients</option>
        </select>
      </div>

      {feed.data && feed.data.items.length > 0 ? (
        <Card>
          <CardBody>
            <ul className="divide-y divide-slate-100">
              {feed.data.items.map((e) => (
                <li key={e.id} className="flex items-center justify-between py-3 text-sm">
                  <div>
                    <span className="font-medium">{e.summary}</span>
                    <span className="ml-2 text-xs text-slate-500">{e.verb}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge tone={RESOURCE_TONE[e.resource] ?? "neutral"}>{e.resource}</Badge>
                    <span className="text-xs text-slate-500">
                      {new Date(e.createdAt).toLocaleString()}
                    </span>
                  </div>
                </li>
              ))}
            </ul>
          </CardBody>
        </Card>
      ) : (
        <EmptyState title="Nothing yet" description="Activity will appear as your team works." />
      )}
    </div>
  );
}
