"use client";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Badge, Button, Card, CardBody, CardHeader, CardTitle, EmptyState, Input, Label, Modal, useToast } from "@worknest/ui";
import { api } from "@/lib/api";

interface Hook {
  id: string;
  url: string;
  kinds: string[];
  enabled: boolean;
  failureCount: number;
}

const KINDS = [
  "task.assigned",
  "task.completed",
  "ticket.assigned",
  "ticket.escalated",
  "request.submitted",
  "approval.pending",
  "approval.decided",
  "asset.warranty",
  "inventory.low_stock",
  "billing.invoice_paid",
];

export default function AdminWebhooksPage() {
  const qc = useQueryClient();
  const toast = useToast();
  const [showNew, setShowNew] = useState(false);
  const [url, setUrl] = useState("");
  const [kinds, setKinds] = useState<string[]>(["task.assigned"]);

  const list = useQuery({ queryKey: ["webhooks"], queryFn: () => api<Hook[]>("/webhooks") });

  const create = useMutation({
    mutationFn: () => api("/webhooks", { method: "POST", body: { url, kinds } }),
    onSuccess: () => {
      toast.push({ title: "Webhook created", variant: "success" });
      setShowNew(false);
      setUrl("");
      qc.invalidateQueries({ queryKey: ["webhooks"] });
    },
  });

  const toggle = useMutation({
    mutationFn: (input: { id: string; enabled: boolean }) =>
      api(`/webhooks/${input.id}`, { method: "PATCH", body: { enabled: input.enabled } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["webhooks"] }),
  });

  const remove = useMutation({
    mutationFn: (id: string) => api(`/webhooks/${id}`, { method: "DELETE" }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["webhooks"] }),
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Webhooks</h1>
        <Button onClick={() => setShowNew(true)}>New webhook</Button>
      </div>

      <Card>
        <CardHeader><CardTitle>Endpoints</CardTitle></CardHeader>
        <CardBody>
          {(list.data ?? []).length === 0 ? (
            <EmptyState title="No webhooks configured" />
          ) : (
            <ul className="divide-y">
              {list.data!.map((h) => (
                <li key={h.id} className="py-3 flex items-center justify-between">
                  <div>
                    <code className="text-sm font-mono text-slate-700">{h.url}</code>
                    <div className="flex gap-1 mt-1 flex-wrap">
                      {h.kinds.map((k) => <Badge key={k} variant="outline">{k}</Badge>)}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" onClick={() => toggle.mutate({ id: h.id, enabled: !h.enabled })}>
                      {h.enabled ? "Disable" : "Enable"}
                    </Button>
                    <Button variant="ghost" onClick={() => remove.mutate(h.id)}>Delete</Button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </CardBody>
      </Card>

      <Modal
        open={showNew}
        onClose={() => setShowNew(false)}
        title="New webhook"
        footer={
          <>
            <Button variant="outline" onClick={() => setShowNew(false)}>Cancel</Button>
            <Button onClick={() => create.mutate()} loading={create.isPending}>Create</Button>
          </>
        }
      >
        <div className="space-y-3">
          <div>
            <Label htmlFor="wh-url">URL</Label>
            <Input id="wh-url" value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://…" />
          </div>
          <div>
            <Label>Events</Label>
            <div className="grid grid-cols-2 gap-1 mt-1 max-h-48 overflow-y-auto">
              {KINDS.map((k) => (
                <label key={k} className="flex items-center gap-2 text-sm">
                  <input
                    type="checkbox"
                    className="rounded border-slate-300"
                    checked={kinds.includes(k)}
                    onChange={(e) =>
                      setKinds((prev) => (e.target.checked ? [...prev, k] : prev.filter((p) => p !== k)))
                    }
                  />
                  {k}
                </label>
              ))}
            </div>
          </div>
        </div>
      </Modal>
    </div>
  );
}
