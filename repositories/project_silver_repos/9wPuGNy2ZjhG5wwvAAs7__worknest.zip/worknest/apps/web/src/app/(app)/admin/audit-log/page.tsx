"use client";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Avatar, Badge, Card, CardBody, EmptyState, Pagination } from "@worknest/ui";
import { api } from "@/lib/api";

interface Entry {
  id: string;
  action: string;
  resource: string;
  resourceId: string;
  actorId?: string;
  ip?: string;
  createdAt: string;
}

interface PageOf<T> { items: T[]; total: number; page: number; pageSize: number }

export default function AuditLogPage() {
  const [page, setPage] = useState(1);
  const data = useQuery({
    queryKey: ["audit", page],
    queryFn: () => api<PageOf<Entry>>(`/audit-logs?page=${page}`),
  });

  if (data.isLoading) return <Card><CardBody>Loading…</CardBody></Card>;
  if (!data.data || data.data.items.length === 0) {
    return <EmptyState title="No audit entries yet" />;
  }

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Audit log</h1>
      <Card>
        <CardBody>
          <ol className="divide-y">
            {data.data.items.map((e) => (
              <li key={e.id} className="py-3 text-sm">
                <div className="flex items-center gap-2 flex-wrap">
                  <Avatar size="sm" name={e.actorId ?? "system"} />
                  <Badge variant="outline">{e.action}</Badge>
                  <span className="text-slate-600">{e.resource}</span>
                  <code className="text-xs text-slate-400">{e.resourceId.slice(0, 12)}…</code>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  {new Date(e.createdAt).toLocaleString()}
                  {e.ip && ` · from ${e.ip}`}
                </p>
              </li>
            ))}
          </ol>
        </CardBody>
      </Card>
      <Pagination page={data.data.page} pageSize={data.data.pageSize} total={data.data.total} onPageChange={setPage} />
    </div>
  );
}
