"use client";
import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Badge, Button, Card, CardBody, DataTable, EmptyState, Input } from "@worknest/ui";
import { api } from "@/lib/api";

interface RunningTimer {
  id: string;
  startedAt: string;
  description?: string | null;
  task: { id: string; key: string; title: string };
}

interface TimeEntry {
  id: string;
  startedAt: string;
  endedAt: string | null;
  durationSeconds: number | null;
  description: string | null;
  billable: boolean;
  task: { id: string; key: string; title: string };
  user: { id: string; name: string };
}

function formatSeconds(s: number | null): string {
  if (s == null) return "—";
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  return h > 0 ? `${h}h ${m}m` : `${m}m`;
}

export default function TimeTrackingPage() {
  const qc = useQueryClient();
  const [taskId, setTaskId] = useState("");
  const [description, setDescription] = useState("");
  const [tickMs, setTickMs] = useState(Date.now());

  useEffect(() => {
    const t = setInterval(() => setTickMs(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);

  const running = useQuery({
    queryKey: ["time-entries", "running"],
    queryFn: () => api<RunningTimer | null>("/time-entries/running"),
    refetchInterval: 30_000,
  });

  const recent = useQuery({
    queryKey: ["time-entries", "list"],
    queryFn: () =>
      api<{ items: TimeEntry[]; totalSeconds: number }>("/time-entries?pageSize=50"),
  });

  const start = useMutation({
    mutationFn: (input: { taskId: string; description?: string }) =>
      api("/time-entries/start", {
        method: "POST",
        body: { taskId: input.taskId, description: input.description, billable: false },
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["time-entries"] });
      setTaskId("");
      setDescription("");
    },
  });

  const stop = useMutation({
    mutationFn: () => api("/time-entries/stop", { method: "POST", body: { endedAt: new Date() } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["time-entries"] }),
  });

  const liveSeconds = running.data
    ? Math.floor((tickMs - new Date(running.data.startedAt).getTime()) / 1000)
    : null;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Time tracking</h1>
        <p className="text-sm text-slate-500">Track time against tasks. One running timer at a time.</p>
      </div>

      <Card>
        <CardBody>
          {running.data ? (
            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs uppercase tracking-wide text-slate-500">Running</div>
                <div className="mt-1 text-base font-semibold">
                  {running.data.task.key} — {running.data.task.title}
                </div>
                {running.data.description ? (
                  <div className="text-sm text-slate-600">{running.data.description}</div>
                ) : null}
                <div className="mt-2 font-mono text-2xl">{formatSeconds(liveSeconds)}</div>
              </div>
              <Button onClick={() => stop.mutate()} variant="danger">
                Stop
              </Button>
            </div>
          ) : (
            <div className="flex flex-col gap-3 md:flex-row md:items-end">
              <label className="flex-1 text-sm">
                <span className="mb-1 block text-slate-600">Task ID or key</span>
                <Input value={taskId} onChange={(e) => setTaskId(e.target.value)} />
              </label>
              <label className="flex-1 text-sm">
                <span className="mb-1 block text-slate-600">Description (optional)</span>
                <Input
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="What you're working on"
                />
              </label>
              <Button
                onClick={() => start.mutate({ taskId, description: description || undefined })}
                disabled={!taskId || start.isPending}
                variant="primary"
              >
                Start timer
              </Button>
            </div>
          )}
        </CardBody>
      </Card>

      <div>
        <div className="mb-2 flex items-center justify-between">
          <h2 className="text-base font-semibold">Recent entries</h2>
          <span className="text-sm text-slate-500">
            Total: {formatSeconds(recent.data?.totalSeconds ?? 0)}
          </span>
        </div>
        {recent.data && recent.data.items.length > 0 ? (
          <DataTable
            rows={recent.data.items}
            rowKey={(e) => e.id}
            columns={[
              { key: "task", header: "Task", cell: (e) => `${e.task.key} — ${e.task.title}` },
              { key: "who", header: "Who", cell: (e) => e.user.name },
              { key: "when", header: "Started", cell: (e) => new Date(e.startedAt).toLocaleString() },
              { key: "dur", header: "Duration", cell: (e) => formatSeconds(e.durationSeconds), align: "right" },
              {
                key: "billable",
                header: "Billable",
                cell: (e) => (e.billable ? <Badge tone="info">Billable</Badge> : null),
              },
            ]}
          />
        ) : (
          <EmptyState title="No entries yet" description="Start a timer above to log your first session." />
        )}
      </div>
    </div>
  );
}
