"use client";
import Link from "next/link";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Badge, Card, CardBody, DataTable, EmptyState, Tab, Tabs } from "@worknest/ui";
import { api } from "@/lib/api";

interface Submission {
  id: string;
  key: string;
  title: string;
  status: string;
  priority: string;
  createdAt: string;
}

const TABS = ["submitted", "in_review", "approved", "rejected", "closed"] as const;

export default function RequestsPage() {
  const [tab, setTab] = useState<typeof TABS[number]>("submitted");
  const { data = [], isLoading } = useQuery({
    queryKey: ["requests", tab],
    queryFn: () => api<Submission[]>(`/requests?status=${tab}`),
  });

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Requests</h1>

      <Tabs>
        {TABS.map((t) => (
          <Tab key={t} label={t.replace("_", " ")}>
            {isLoading && tab === t ? (
              <Card><CardBody>Loading…</CardBody></Card>
            ) : data.length === 0 ? (
              <EmptyState title="Nothing in this bucket" />
            ) : (
              <DataTable
                rows={data}
                keyOf={(r) => r.id}
                columns={[
                  { key: "key", header: "Key", cell: (r) => <Badge variant="outline">{r.key}</Badge> },
                  {
                    key: "title",
                    header: "Title",
                    cell: (r) => (
                      <Link href={`/requests/${r.id}`} className="font-medium hover:underline">
                        {r.title}
                      </Link>
                    ),
                  },
                  { key: "priority", header: "Priority", cell: (r) => <Badge>{r.priority}</Badge> },
                  { key: "created", header: "Submitted", cell: (r) => new Date(r.createdAt).toLocaleDateString() },
                ]}
              />
            )}
          </Tab>
        ))}
      </Tabs>
    </div>
  );
}
