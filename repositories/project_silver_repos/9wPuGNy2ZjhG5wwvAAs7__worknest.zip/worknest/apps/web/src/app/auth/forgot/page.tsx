"use client";
import Link from "next/link";
import { useState } from "react";
import { Button, Card, CardBody, Input, Label } from "@worknest/ui";
import { api } from "@/lib/api";

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await api("/auth/password/reset/request", { method: "POST", body: { email } });
      setSent(true);
    } finally {
      setLoading(false);
    }
  };

  if (sent) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
        <Card className="w-full max-w-md">
          <CardBody>
            <h1 className="text-2xl font-semibold text-center mb-2">Check your email</h1>
            <p className="text-slate-600 text-center text-sm">
              If that email matches an account, we've sent a reset link.
            </p>
          </CardBody>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
      <Card className="w-full max-w-md">
        <CardBody>
          <h1 className="text-2xl font-semibold text-center mb-6">Reset your password</h1>
          <form onSubmit={submit} className="space-y-3">
            <div>
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" value={email} required onChange={(e) => setEmail(e.target.value)} />
            </div>
            <Button type="submit" className="w-full" loading={loading}>
              Send reset link
            </Button>
          </form>
          <p className="text-sm text-center mt-4">
            <Link href="/auth/login" className="text-brand-600 hover:underline">
              Back to sign in
            </Link>
          </p>
        </CardBody>
      </Card>
    </div>
  );
}
