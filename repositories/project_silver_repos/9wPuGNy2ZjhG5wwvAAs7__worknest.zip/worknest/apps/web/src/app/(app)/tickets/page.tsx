"use client";
import Link from "next/link";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Badge, Card, CardBody, DataTable, EmptyState, Select } from "@worknest/ui";
import { api } from "@/lib/api";

interface Ticket {
  id: string;
  key: string;
  title: string;
  status: string;
  priority: string;
  createdAt: string;
}

export default function TicketsPage() {
  const [status, setStatus] = useState("");
  const { data, isLoading } = useQuery({
    queryKey: ["tickets", status],
    queryFn: () =>
      api<{ items: Ticket[]; total: number }>(`/tickets${status ? `?status=${status}` : ""}`),
  });

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Tickets</h1>
      <div>
        <Select value={status} onChange={(e) => setStatus(e.target.value)} className="max-w-[200px]">
          <option value="">All statuses</option>
          <option value="open">Open</option>
          <option value="pending">Pending</option>
          <option value="in_progress">In progress</option>
          <option value="on_hold">On hold</option>
          <option value="resolved">Resolved</option>
          <option value="closed">Closed</option>
        </Select>
      </div>

      {isLoading ? (
        <Card><CardBody>Loading…</CardBody></Card>
      ) : !data?.items.length ? (
        <EmptyState title="No tickets" description="Once your team starts opening tickets, they'll show up here." />
      ) : (
        <DataTable
          rows={data.items}
          keyOf={(t) => t.id}
          columns={[
            { key: "key", header: "Key", cell: (t) => <Badge variant="outline">{t.key}</Badge> },
            {
              key: "title",
              header: "Title",
              cell: (t) => (
                <Link href={`/tickets/${t.id}`} className="font-medium hover:underline">
                  {t.title}
                </Link>
              ),
            },
            { key: "priority", header: "Priority", cell: (t) => <Badge>{t.priority}</Badge> },
            { key: "status", header: "Status", cell: (t) => <Badge>{t.status}</Badge> },
            { key: "created", header: "Opened", cell: (t) => new Date(t.createdAt).toLocaleDateString() },
          ]}
        />
      )}
    </div>
  );
}
