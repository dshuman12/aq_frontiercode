"use client";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Badge, Button, Card, CardBody, DataTable, EmptyState, Input, Label, Modal, useToast } from "@worknest/ui";
import { api } from "@/lib/api";

interface Client {
  id: string;
  name: string;
  industry?: string | null;
  status: string;
  _count?: { contacts: number; portalUsers: number };
}

export default function ClientsPage() {
  const qc = useQueryClient();
  const toast = useToast();
  const [showNew, setShowNew] = useState(false);
  const [name, setName] = useState("");
  const [industry, setIndustry] = useState("");

  const { data = [], isLoading } = useQuery({ queryKey: ["clients"], queryFn: () => api<Client[]>("/clients") });

  const create = useMutation({
    mutationFn: () => api("/clients", { method: "POST", body: { name, industry: industry || undefined } }),
    onSuccess: () => {
      toast.push({ title: "Client added", variant: "success" });
      setShowNew(false);
      setName(""); setIndustry("");
      qc.invalidateQueries({ queryKey: ["clients"] });
    },
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Clients</h1>
        <Button onClick={() => setShowNew(true)}>New client</Button>
      </div>

      {isLoading ? <Card><CardBody>Loading…</CardBody></Card> : data.length === 0 ? (
        <EmptyState title="No clients yet" description="Track your customers — contacts, projects, and tickets in one place." />
      ) : (
        <DataTable
          rows={data}
          keyOf={(c) => c.id}
          columns={[
            { key: "name", header: "Name", cell: (c) => <span className="font-medium">{c.name}</span> },
            { key: "industry", header: "Industry", cell: (c) => c.industry ?? "—" },
            { key: "status", header: "Status", cell: (c) => <Badge variant={c.status === "active" ? "success" : "neutral"}>{c.status}</Badge> },
            { key: "contacts", header: "Contacts", cell: (c) => c._count?.contacts ?? 0 },
          ]}
        />
      )}

      <Modal open={showNew} onClose={() => setShowNew(false)} title="New client" footer={
        <>
          <Button variant="outline" onClick={() => setShowNew(false)}>Cancel</Button>
          <Button onClick={() => create.mutate()} loading={create.isPending}>Create</Button>
        </>
      }>
        <div className="space-y-3">
          <div><Label htmlFor="c-name">Name</Label><Input id="c-name" value={name} onChange={(e) => setName(e.target.value)} /></div>
          <div><Label htmlFor="c-ind">Industry</Label><Input id="c-ind" value={industry} onChange={(e) => setIndustry(e.target.value)} /></div>
        </div>
      </Modal>
    </div>
  );
}
