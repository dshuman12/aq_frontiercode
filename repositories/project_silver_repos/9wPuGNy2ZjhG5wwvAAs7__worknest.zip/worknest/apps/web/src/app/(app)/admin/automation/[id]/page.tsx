"use client";
import { useParams } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import { Badge, Card, CardBody, EmptyState } from "@worknest/ui";
import { api } from "@/lib/api";

interface Run {
  id: string;
  status: string;
  outcome: unknown;
  ranAt: string;
  errorMessage: string | null;
}

interface Rule {
  id: string;
  name: string;
  resource: string;
  trigger: string;
  active: boolean;
  actions: unknown[];
}

const STATUS_TONE: Record<string, "success" | "critical" | "neutral"> = {
  success: "success",
  failed: "critical",
  skipped: "neutral",
};

export default function AutomationDetailPage() {
  const params = useParams<{ id: string }>();
  const id = params.id;

  const rules = useQuery({
    queryKey: ["automation-rules"],
    queryFn: () => api<Rule[]>("/automation/rules"),
  });
  const rule = rules.data?.find((r) => r.id === id);

  const runs = useQuery({
    queryKey: ["automation-runs", id],
    queryFn: () => api<Run[]>(`/automation/rules/${id}/runs?limit=50`),
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">{rule?.name ?? "Rule"}</h1>
        <p className="text-sm text-slate-500">
          {rule ? `${rule.resource} · ${rule.trigger}` : "loading…"}
        </p>
      </div>

      <Card>
        <CardBody>
          <h2 className="mb-2 text-sm font-semibold uppercase tracking-wide text-slate-500">
            Actions
          </h2>
          <pre className="overflow-x-auto rounded-md bg-slate-50 p-3 text-xs">
            {JSON.stringify(rule?.actions ?? [], null, 2)}
          </pre>
        </CardBody>
      </Card>

      <Card>
        <CardBody>
          <h2 className="mb-2 text-sm font-semibold uppercase tracking-wide text-slate-500">
            Recent runs
          </h2>
          {runs.data && runs.data.length > 0 ? (
            <ul className="divide-y divide-slate-100">
              {runs.data.map((r) => (
                <li key={r.id} className="flex items-center justify-between py-2 text-sm">
                  <div>
                    <Badge tone={STATUS_TONE[r.status] ?? "neutral"}>{r.status}</Badge>
                    <span className="ml-2 text-xs text-slate-500">
                      {new Date(r.ranAt).toLocaleString()}
                    </span>
                  </div>
                  {r.errorMessage ? (
                    <span className="text-xs text-red-600">{r.errorMessage}</span>
                  ) : null}
                </li>
              ))}
            </ul>
          ) : (
            <EmptyState title="No runs yet" />
          )}
        </CardBody>
      </Card>
    </div>
  );
}
