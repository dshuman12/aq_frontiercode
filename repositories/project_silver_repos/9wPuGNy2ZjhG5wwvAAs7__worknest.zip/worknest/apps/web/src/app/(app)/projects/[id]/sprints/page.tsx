"use client";
import { useState } from "react";
import { useParams } from "next/navigation";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Badge, Button, Card, CardBody, EmptyState, Input } from "@worknest/ui";
import { api } from "@/lib/api";

interface Sprint {
  id: string;
  name: string;
  goal: string | null;
  status: string;
  startsAt: string | null;
  endsAt: string | null;
  _count?: { tasks: number };
}

const STATUS_TONE: Record<string, "info" | "success" | "neutral" | "warning"> = {
  planned: "neutral",
  active: "info",
  completed: "success",
  cancelled: "warning",
};

export default function SprintsPage() {
  const params = useParams<{ id: string }>();
  const projectId = params.id;
  const qc = useQueryClient();
  const [name, setName] = useState("");
  const [goal, setGoal] = useState("");

  const sprints = useQuery({
    queryKey: ["sprints", projectId],
    queryFn: () => api<Sprint[]>(`/sprints?projectId=${projectId}`),
  });

  const create = useMutation({
    mutationFn: () =>
      api("/sprints", {
        method: "POST",
        body: { projectId, name, goal: goal || undefined },
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["sprints", projectId] });
      setName("");
      setGoal("");
    },
  });

  const transition = useMutation({
    mutationFn: (input: { id: string; toStatus: string }) =>
      api(`/sprints/${input.id}/transition`, {
        method: "POST",
        body: { toStatus: input.toStatus },
      }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["sprints", projectId] }),
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Sprints</h1>
        <p className="text-sm text-slate-500">Time-boxed buckets of tasks for this project.</p>
      </div>

      <Card>
        <CardBody>
          <h2 className="mb-3 text-base font-semibold">New sprint</h2>
          <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Sprint 12" />
            <Input value={goal} onChange={(e) => setGoal(e.target.value)} placeholder="Goal (optional)" />
          </div>
          <div className="mt-3">
            <Button
              variant="primary"
              disabled={!name || create.isPending}
              onClick={() => create.mutate()}
            >
              Create sprint
            </Button>
          </div>
        </CardBody>
      </Card>

      {sprints.data && sprints.data.length > 0 ? (
        <ul className="space-y-3">
          {sprints.data.map((s) => (
            <li key={s.id}>
              <Card>
                <CardBody>
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-base font-semibold">{s.name}</h3>
                        <Badge tone={STATUS_TONE[s.status] ?? "neutral"}>{s.status}</Badge>
                      </div>
                      {s.goal ? <p className="mt-1 text-sm text-slate-600">{s.goal}</p> : null}
                      <p className="mt-1 text-xs text-slate-500">
                        {s._count?.tasks ?? 0} tasks
                        {s.startsAt && s.endsAt
                          ? ` · ${new Date(s.startsAt).toLocaleDateString()} → ${new Date(s.endsAt).toLocaleDateString()}`
                          : ""}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      {s.status === "planned" ? (
                        <Button
                          variant="primary"
                          onClick={() => transition.mutate({ id: s.id, toStatus: "active" })}
                        >
                          Start
                        </Button>
                      ) : null}
                      {s.status === "active" ? (
                        <Button
                          variant="primary"
                          onClick={() => transition.mutate({ id: s.id, toStatus: "completed" })}
                        >
                          Complete
                        </Button>
                      ) : null}
                      {(s.status === "planned" || s.status === "active") ? (
                        <Button
                          variant="ghost"
                          onClick={() => transition.mutate({ id: s.id, toStatus: "cancelled" })}
                        >
                          Cancel
                        </Button>
                      ) : null}
                    </div>
                  </div>
                </CardBody>
              </Card>
            </li>
          ))}
        </ul>
      ) : (
        <EmptyState
          title="No sprints yet"
          description="Plan your first sprint above to start grouping work into iterations."
        />
      )}
    </div>
  );
}
