"use client";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Avatar, Badge, Button, Card, CardBody, CardHeader, CardTitle, EmptyState, Tab, Tabs, Textarea, useToast } from "@worknest/ui";
import { api } from "@/lib/api";

interface Decision {
  id: string;
  status: string;
  decision?: string;
  reason?: string;
  createdAt: string;
  workflow: { id: string; name: string };
  step: { id: string; name: string; order: number };
  submission?: { id: string; key: string; title: string };
}

export default function ApprovalsPage() {
  const qc = useQueryClient();
  const toast = useToast();
  const [reasons, setReasons] = useState<Record<string, string>>({});

  const pending = useQuery({
    queryKey: ["approvals", "pending"],
    queryFn: () => api<Decision[]>("/approvals/pending"),
  });
  const decided = useQuery({
    queryKey: ["approvals", "decided"],
    queryFn: () => api<Decision[]>("/approvals/decided"),
  });

  const decide = useMutation({
    mutationFn: (input: { id: string; decision: "approved" | "rejected"; reason?: string }) =>
      api(`/approvals/${input.id}/decide`, {
        method: "POST",
        body: { decision: input.decision, reason: input.reason },
      }),
    onSuccess: (_d, vars) => {
      toast.push({ title: `Marked ${vars.decision}`, variant: "success" });
      qc.invalidateQueries({ queryKey: ["approvals"] });
    },
  });

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Approvals</h1>

      <Tabs>
        <Tab label={`Awaiting you (${pending.data?.length ?? 0})`}>
          {(pending.data ?? []).length === 0 ? (
            <EmptyState title="Inbox zero" description="Nothing is awaiting your decision." />
          ) : (
            <div className="space-y-3">
              {(pending.data ?? []).map((d) => (
                <Card key={d.id}>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span className="flex items-center gap-2">
                        <Badge variant="outline">{d.submission?.key ?? "—"}</Badge>
                        <span>{d.submission?.title ?? d.workflow.name}</span>
                      </span>
                      <span className="text-xs text-slate-500">
                        Step {d.step.order + 1}: {d.step.name}
                      </span>
                    </CardTitle>
                  </CardHeader>
                  <CardBody className="space-y-3">
                    <Textarea
                      placeholder="Optional reason"
                      rows={2}
                      value={reasons[d.id] ?? ""}
                      onChange={(e) => setReasons({ ...reasons, [d.id]: e.target.value })}
                    />
                    <div className="flex justify-end gap-2">
                      <Button
                        variant="outline"
                        onClick={() => decide.mutate({ id: d.id, decision: "rejected", reason: reasons[d.id] })}
                      >
                        Reject
                      </Button>
                      <Button
                        onClick={() => decide.mutate({ id: d.id, decision: "approved", reason: reasons[d.id] })}
                      >
                        Approve
                      </Button>
                    </div>
                  </CardBody>
                </Card>
              ))}
            </div>
          )}
        </Tab>
        <Tab label={`Recently decided (${decided.data?.length ?? 0})`}>
          {(decided.data ?? []).length === 0 ? (
            <EmptyState title="No decisions yet" description="Your decision history will show here." />
          ) : (
            <Card>
              <CardBody>
                <ul className="divide-y">
                  {(decided.data ?? []).map((d) => (
                    <li key={d.id} className="py-3 flex items-center justify-between">
                      <div>
                        <p className="font-medium">{d.submission?.title ?? d.workflow.name}</p>
                        <p className="text-xs text-slate-500">{d.workflow.name} → {d.step.name}</p>
                      </div>
                      <Badge variant={d.status === "approved" ? "success" : "danger"}>{d.status}</Badge>
                    </li>
                  ))}
                </ul>
              </CardBody>
            </Card>
          )}
        </Tab>
      </Tabs>
    </div>
  );
}
