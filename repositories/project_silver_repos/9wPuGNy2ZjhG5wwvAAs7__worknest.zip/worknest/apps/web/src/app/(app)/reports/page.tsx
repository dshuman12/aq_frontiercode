"use client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardBody, CardHeader, CardTitle, DataTable, EmptyState } from "@worknest/ui";
import { api } from "@/lib/api";

interface TeamRow {
  userId: string;
  name: string;
  openTasks: number;
  overdueTasks: number;
  ticketsAssigned: number;
}

interface SlaRow {
  priority: string;
  count: number;
  averageResolutionHours: number;
}

export default function ReportsPage() {
  const team = useQuery({ queryKey: ["reports", "team"], queryFn: () => api<TeamRow[]>("/reports/team-workload") });
  const sla = useQuery({ queryKey: ["reports", "sla"], queryFn: () => api<SlaRow[]>("/reports/ticket-sla") });

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Reports</h1>

      <Card>
        <CardHeader><CardTitle>Team workload</CardTitle></CardHeader>
        <CardBody>
          {(team.data ?? []).length === 0 ? (
            <EmptyState title="No data yet" />
          ) : (
            <DataTable
              rows={team.data!}
              keyOf={(r) => r.userId}
              columns={[
                { key: "name", header: "Name", cell: (r) => r.name },
                { key: "open", header: "Open tasks", cell: (r) => r.openTasks },
                { key: "overdue", header: "Overdue", cell: (r) => r.overdueTasks },
                { key: "tickets", header: "Tickets", cell: (r) => r.ticketsAssigned },
              ]}
            />
          )}
        </CardBody>
      </Card>

      <Card>
        <CardHeader><CardTitle>Ticket resolution time</CardTitle></CardHeader>
        <CardBody>
          {(sla.data ?? []).length === 0 ? (
            <EmptyState title="No resolved tickets yet" />
          ) : (
            <ul className="divide-y">
              {sla.data!.map((row) => (
                <li key={row.priority} className="py-2 flex items-center justify-between text-sm">
                  <span className="font-medium">{row.priority}</span>
                  <span className="text-slate-600">
                    {row.count} resolved · {row.averageResolutionHours}h average
                  </span>
                </li>
              ))}
            </ul>
          )}
        </CardBody>
      </Card>

      <Card>
        <CardHeader><CardTitle>Exports</CardTitle></CardHeader>
        <CardBody className="flex gap-3 text-sm">
          <a href="/api/reports/tasks.csv" className="text-brand-600 hover:underline">Tasks CSV</a>
          <a href="/api/reports/tickets.csv" className="text-brand-600 hover:underline">Tickets CSV</a>
        </CardBody>
      </Card>
    </div>
  );
}
