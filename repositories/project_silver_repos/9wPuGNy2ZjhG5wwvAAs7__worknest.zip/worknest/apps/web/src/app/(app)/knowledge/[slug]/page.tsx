"use client";
import { useParams } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import { Badge, Card, CardBody, Markdown } from "@worknest/ui";
import { api } from "@/lib/api";

interface Article {
  id: string;
  slug: string;
  title: string;
  body: string;
  status: "draft" | "published" | "archived";
  updatedAt: string;
  category: { name: string } | null;
  versions: { id: string; createdAt: string }[];
}

const STATUS_TONE: Record<string, "neutral" | "success" | "warning"> = {
  draft: "neutral",
  published: "success",
  archived: "warning",
};

export default function KnowledgeArticlePage() {
  const params = useParams<{ slug: string }>();
  const article = useQuery({
    queryKey: ["knowledge-article", params.slug],
    queryFn: () => api<Article>(`/knowledge/articles/${params.slug}`),
  });
  if (!article.data) return <p className="text-sm text-slate-500">Loading…</p>;
  const a = article.data;
  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">{a.title}</h1>
          <p className="text-xs text-slate-500">
            {a.category?.name ?? "Uncategorized"} · last edited {new Date(a.updatedAt).toLocaleString()}
          </p>
        </div>
        <Badge tone={STATUS_TONE[a.status]}>{a.status}</Badge>
      </div>
      <Card>
        <CardBody>
          <Markdown source={a.body} className="prose-sm" />
        </CardBody>
      </Card>
      {a.versions?.length ? (
        <Card>
          <CardBody>
            <h2 className="mb-2 text-sm font-semibold uppercase tracking-wide text-slate-500">
              Edit history
            </h2>
            <ul className="space-y-1 text-xs text-slate-500">
              {a.versions.map((v) => (
                <li key={v.id}>{new Date(v.createdAt).toLocaleString()}</li>
              ))}
            </ul>
          </CardBody>
        </Card>
      ) : null}
    </div>
  );
}
