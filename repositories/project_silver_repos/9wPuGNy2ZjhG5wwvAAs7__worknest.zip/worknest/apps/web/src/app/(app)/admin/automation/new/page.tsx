"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { useMutation } from "@tanstack/react-query";
import { Button, Card, CardBody, Input } from "@worknest/ui";
import { api } from "@/lib/api";

export default function NewAutomationRulePage() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [resource, setResource] = useState<"task" | "ticket" | "request">("ticket");
  const [trigger, setTrigger] = useState<"created" | "updated" | "status_changed" | "assignee_changed" | "due_soon">(
    "status_changed",
  );
  const [actionsJson, setActionsJson] = useState(
    JSON.stringify(
      [
        { type: "set_priority", priority: "high" },
        { type: "notify", userIds: ["<USER_ID>"], title: "Heads up" },
      ],
      null,
      2,
    ),
  );

  const create = useMutation({
    mutationFn: () =>
      api("/automation/rules", {
        method: "POST",
        body: {
          name,
          resource,
          trigger,
          actions: JSON.parse(actionsJson),
          active: true,
        },
      }),
    onSuccess: () => router.push("/admin/automation"),
  });

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <h1 className="text-2xl font-bold tracking-tight">New automation rule</h1>
      <Card>
        <CardBody className="space-y-3">
          <label className="block text-sm">
            <span className="mb-1 block text-slate-600">Name</span>
            <Input value={name} onChange={(e) => setName(e.target.value)} />
          </label>
          <div className="grid grid-cols-2 gap-3">
            <label className="block text-sm">
              <span className="mb-1 block text-slate-600">Resource</span>
              <select
                value={resource}
                onChange={(e) => setResource(e.target.value as any)}
                className="h-10 w-full rounded-md border border-slate-200 bg-white px-3 text-sm"
              >
                <option value="task">Task</option>
                <option value="ticket">Ticket</option>
                <option value="request">Request</option>
              </select>
            </label>
            <label className="block text-sm">
              <span className="mb-1 block text-slate-600">Trigger</span>
              <select
                value={trigger}
                onChange={(e) => setTrigger(e.target.value as any)}
                className="h-10 w-full rounded-md border border-slate-200 bg-white px-3 text-sm"
              >
                <option value="created">Created</option>
                <option value="updated">Updated</option>
                <option value="status_changed">Status changed</option>
                <option value="assignee_changed">Assignee changed</option>
                <option value="due_soon">Due soon</option>
              </select>
            </label>
          </div>
          <label className="block text-sm">
            <span className="mb-1 block text-slate-600">Actions (JSON)</span>
            <textarea
              value={actionsJson}
              onChange={(e) => setActionsJson(e.target.value)}
              rows={10}
              className="block w-full rounded-md border border-slate-200 bg-white p-3 font-mono text-xs"
            />
          </label>
          {create.isError ? (
            <p className="text-sm text-red-600">{(create.error as Error).message}</p>
          ) : null}
          <div className="flex justify-end gap-2">
            <Button variant="ghost" onClick={() => router.back()}>Cancel</Button>
            <Button variant="primary" disabled={!name || create.isPending} onClick={() => create.mutate()}>
              Create rule
            </Button>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
