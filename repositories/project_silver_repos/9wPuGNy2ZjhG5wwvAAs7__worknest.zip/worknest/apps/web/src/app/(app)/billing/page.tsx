"use client";
import { useQuery } from "@tanstack/react-query";
import { Badge, Button, Card, CardBody, CardHeader, CardTitle, useToast } from "@worknest/ui";
import { api } from "@/lib/api";

interface Invoice {
  id: string;
  number?: string | null;
  status: string;
  amountDueCents: number;
  issuedAt: string;
  hostedInvoiceUrl?: string | null;
}

const PLANS = [
  { key: "starter", name: "Starter", price: "$8 / seat / month", features: ["Up to 20 members", "Tickets + requests", "Email support"] },
  { key: "team", name: "Team", price: "$16 / seat / month", features: ["Up to 75 members", "Approval workflows", "Priority support"] },
  { key: "business", name: "Business", price: "$32 / seat / month", features: ["Up to 300 members", "SAML SSO + SCIM", "365-day audit log"] },
];

export default function BillingPage() {
  const toast = useToast();
  const invoices = useQuery({ queryKey: ["billing", "invoices"], queryFn: () => api<Invoice[]>("/billing/invoices") });

  const upgrade = async (plan: string) => {
    try {
      const res = await api<{ url: string }>("/billing/checkout", {
        method: "POST",
        body: {
          plan,
          cadence: "month",
          returnUrl: window.location.origin + "/billing?paid=1",
          cancelUrl: window.location.origin + "/billing",
        },
      });
      window.location.href = res.url;
    } catch (err) {
      toast.push({ title: "Checkout unavailable", description: (err as Error).message, variant: "danger" });
    }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Billing</h1>

      <div className="grid gap-3 md:grid-cols-3">
        {PLANS.map((p) => (
          <Card key={p.key}>
            <CardHeader><CardTitle>{p.name}</CardTitle></CardHeader>
            <CardBody className="space-y-3">
              <p className="text-2xl font-semibold">{p.price}</p>
              <ul className="text-sm text-slate-700 space-y-1">
                {p.features.map((f) => (
                  <li key={f}>✓ {f}</li>
                ))}
              </ul>
              <Button onClick={() => upgrade(p.key)}>Upgrade</Button>
            </CardBody>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader><CardTitle>Invoices</CardTitle></CardHeader>
        <CardBody>
          {(invoices.data ?? []).length === 0 ? (
            <p className="text-sm text-slate-500">No invoices yet.</p>
          ) : (
            <ul className="divide-y">
              {invoices.data!.map((i) => (
                <li key={i.id} className="py-3 flex items-center justify-between text-sm">
                  <span>
                    <span className="font-medium">{i.number ?? i.id.slice(0, 8)}</span>
                    <span className="ml-2 text-slate-500">{new Date(i.issuedAt).toLocaleDateString()}</span>
                  </span>
                  <span className="flex items-center gap-3">
                    <Badge variant={i.status === "paid" ? "success" : "warning"}>{i.status}</Badge>
                    <span>${(i.amountDueCents / 100).toFixed(2)}</span>
                    {i.hostedInvoiceUrl && (
                      <a href={i.hostedInvoiceUrl} target="_blank" rel="noreferrer" className="text-brand-600 hover:underline">
                        View
                      </a>
                    )}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </CardBody>
      </Card>
    </div>
  );
}
