"use client";
import { useQuery } from "@tanstack/react-query";
import { Avatar, Button, Card, CardBody, CardHeader, CardTitle, Tab, Tabs } from "@worknest/ui";
import { api } from "@/lib/api";
import { useAuth } from "@/stores/auth";

interface Me {
  id: string;
  email: string;
  name: string;
  avatarUrl?: string;
  twoFactorEnabled: boolean;
  emailVerifiedAt?: string | null;
}

export default function SettingsPage() {
  const me = useQuery({ queryKey: ["me"], queryFn: () => api<Me>("/users/me") });
  const sessions = useQuery({ queryKey: ["sessions"], queryFn: () => api<{ id: string; userAgent?: string; ip?: string; lastSeenAt: string }[]>("/auth/sessions") });
  const clear = useAuth((s) => s.clear);

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Settings</h1>

      <Tabs>
        <Tab label="Profile">
          {me.data && (
            <Card>
              <CardHeader><CardTitle>Profile</CardTitle></CardHeader>
              <CardBody className="flex items-center gap-4">
                <Avatar size="lg" name={me.data.name} src={me.data.avatarUrl} />
                <div>
                  <p className="font-medium">{me.data.name}</p>
                  <p className="text-sm text-slate-500">{me.data.email}</p>
                </div>
              </CardBody>
            </Card>
          )}
        </Tab>
        <Tab label="Security">
          <Card>
            <CardHeader><CardTitle>Two-factor authentication</CardTitle></CardHeader>
            <CardBody>
              <p className="text-sm text-slate-600">{me.data?.twoFactorEnabled ? "Enabled" : "Not enabled"}</p>
              <Button className="mt-3">{me.data?.twoFactorEnabled ? "Disable 2FA" : "Enable 2FA"}</Button>
            </CardBody>
          </Card>
          <Card className="mt-3">
            <CardHeader><CardTitle>Active sessions</CardTitle></CardHeader>
            <CardBody>
              <ul className="divide-y">
                {(sessions.data ?? []).map((s) => (
                  <li key={s.id} className="py-2 flex items-center justify-between text-sm">
                    <span>
                      <span className="font-medium">{s.userAgent ?? "Unknown device"}</span>
                      {s.ip && <span className="ml-2 text-slate-500">{s.ip}</span>}
                    </span>
                    <span className="text-xs text-slate-500">last seen {new Date(s.lastSeenAt).toLocaleString()}</span>
                  </li>
                ))}
              </ul>
            </CardBody>
          </Card>
        </Tab>
        <Tab label="Account">
          <Card>
            <CardHeader><CardTitle>Sign out</CardTitle></CardHeader>
            <CardBody>
              <Button variant="danger" onClick={() => { clear(); window.location.href = "/auth/login"; }}>
                Sign out of WorkNest
              </Button>
            </CardBody>
          </Card>
        </Tab>
      </Tabs>
    </div>
  );
}
