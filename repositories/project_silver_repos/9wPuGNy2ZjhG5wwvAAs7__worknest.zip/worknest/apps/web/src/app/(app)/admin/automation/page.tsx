"use client";
import Link from "next/link";
import { useQuery } from "@tanstack/react-query";
import { Badge, Button, Card, CardBody, DataTable, EmptyState } from "@worknest/ui";
import { api } from "@/lib/api";

interface AutomationRule {
  id: string;
  name: string;
  resource: string;
  trigger: string;
  active: boolean;
  _count?: { runs: number };
}

const RESOURCE_TONE: Record<string, "info" | "warning" | "neutral"> = {
  task: "info",
  ticket: "warning",
  request: "neutral",
};

export default function AutomationPage() {
  const rules = useQuery({
    queryKey: ["automation-rules"],
    queryFn: () => api<AutomationRule[]>("/automation/rules"),
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Automation</h1>
          <p className="text-sm text-slate-500">Rules that fire when resources change.</p>
        </div>
        <Link href="/admin/automation/new">
          <Button variant="primary">New rule</Button>
        </Link>
      </div>

      {rules.data && rules.data.length > 0 ? (
        <Card>
          <CardBody className="p-0">
            <DataTable
              rows={rules.data}
              rowKey={(r) => r.id}
              columns={[
                {
                  key: "name",
                  header: "Name",
                  cell: (r) => (
                    <Link href={`/admin/automation/${r.id}`} className="font-medium hover:underline">
                      {r.name}
                    </Link>
                  ),
                },
                {
                  key: "resource",
                  header: "Resource",
                  cell: (r) => <Badge tone={RESOURCE_TONE[r.resource] ?? "neutral"}>{r.resource}</Badge>,
                },
                { key: "trigger", header: "Trigger", cell: (r) => r.trigger },
                {
                  key: "runs",
                  header: "Runs",
                  cell: (r) => r._count?.runs ?? 0,
                  align: "right",
                },
                {
                  key: "active",
                  header: "Active",
                  cell: (r) => (r.active ? <Badge tone="success">on</Badge> : <Badge tone="neutral">off</Badge>),
                },
              ]}
            />
          </CardBody>
        </Card>
      ) : (
        <EmptyState
          title="No automation rules yet"
          description="Create your first rule to keep WorkNest moving while you sleep."
        />
      )}
    </div>
  );
}
