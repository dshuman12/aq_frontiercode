"use client";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button, Card, CardBody, CardHeader, CardTitle, EmptyState, Input, Label, Modal, useToast } from "@worknest/ui";
import { api } from "@/lib/api";

interface Team {
  id: string;
  name: string;
  description?: string | null;
  _count?: { members: number };
}

export default function TeamsPage() {
  const qc = useQueryClient();
  const toast = useToast();
  const [showNew, setShowNew] = useState(false);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");

  const { data = [], isLoading } = useQuery({ queryKey: ["teams"], queryFn: () => api<Team[]>("/teams") });

  const create = useMutation({
    mutationFn: () => api("/teams", { method: "POST", body: { name, description } }),
    onSuccess: () => {
      toast.push({ title: "Team created", variant: "success" });
      setShowNew(false);
      setName("");
      setDescription("");
      qc.invalidateQueries({ queryKey: ["teams"] });
    },
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Teams</h1>
        <Button onClick={() => setShowNew(true)}>New team</Button>
      </div>

      {isLoading ? (
        <Card><CardBody>Loading…</CardBody></Card>
      ) : data.length === 0 ? (
        <EmptyState title="No teams yet" description="Group people by function or product line." />
      ) : (
        <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
          {data.map((t) => (
            <Card key={t.id}>
              <CardHeader><CardTitle>{t.name}</CardTitle></CardHeader>
              <CardBody>
                {t.description && <p className="text-sm text-slate-600">{t.description}</p>}
                <p className="text-xs text-slate-500 mt-2">{t._count?.members ?? 0} members</p>
              </CardBody>
            </Card>
          ))}
        </div>
      )}

      <Modal
        open={showNew}
        onClose={() => setShowNew(false)}
        title="New team"
        footer={
          <>
            <Button variant="outline" onClick={() => setShowNew(false)}>Cancel</Button>
            <Button onClick={() => create.mutate()} loading={create.isPending}>Create</Button>
          </>
        }
      >
        <div className="space-y-3">
          <div><Label htmlFor="t-name">Name</Label><Input id="t-name" value={name} onChange={(e) => setName(e.target.value)} /></div>
          <div><Label htmlFor="t-desc">Description</Label><Input id="t-desc" value={description} onChange={(e) => setDescription(e.target.value)} /></div>
        </div>
      </Modal>
    </div>
  );
}
