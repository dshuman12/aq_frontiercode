"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Button, Card, CardBody, Input, Label, useToast } from "@worknest/ui";
import { api } from "@/lib/api";

export default function RegisterPage() {
  const router = useRouter();
  const toast = useToast();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [organizationName, setOrganizationName] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      await api("/auth/register", {
        method: "POST",
        body: { name, email, password, organizationName },
      });
      toast.push({ title: "Account created. Please log in.", variant: "success" });
      router.replace("/auth/login");
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
      <Card className="w-full max-w-md">
        <CardBody>
          <h1 className="text-2xl font-semibold text-center mb-6">Create your WorkNest account</h1>
          <form onSubmit={submit} className="space-y-3">
            <div>
              <Label htmlFor="name">Full name</Label>
              <Input id="name" value={name} required onChange={(e) => setName(e.target.value)} />
            </div>
            <div>
              <Label htmlFor="org">Organization name</Label>
              <Input id="org" value={organizationName} onChange={(e) => setOrganizationName(e.target.value)} />
              <p className="text-xs text-slate-500 mt-1">We'll create one for you to start.</p>
            </div>
            <div>
              <Label htmlFor="email">Work email</Label>
              <Input id="email" type="email" value={email} required onChange={(e) => setEmail(e.target.value)} />
            </div>
            <div>
              <Label htmlFor="password">Password</Label>
              <Input id="password" type="password" value={password} required onChange={(e) => setPassword(e.target.value)} />
              <p className="text-xs text-slate-500 mt-1">12+ characters with letters, numbers, and a symbol.</p>
            </div>
            {error && <p className="text-sm text-red-600">{error}</p>}
            <Button type="submit" className="w-full" loading={loading}>
              Create account
            </Button>
          </form>
          <p className="text-sm text-center mt-4">
            Already have an account?{" "}
            <Link href="/auth/login" className="text-brand-600 hover:underline">
              Sign in
            </Link>
          </p>
        </CardBody>
      </Card>
    </div>
  );
}
