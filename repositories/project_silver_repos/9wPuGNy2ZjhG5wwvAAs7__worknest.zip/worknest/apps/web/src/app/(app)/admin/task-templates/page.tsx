"use client";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Badge, Button, Card, CardBody, DataTable, EmptyState, Input } from "@worknest/ui";
import { api } from "@/lib/api";

interface Template {
  id: string;
  name: string;
  title: string;
  priority: string;
  labels: string[];
}

export default function TaskTemplatesAdmin() {
  const qc = useQueryClient();
  const list = useQuery({
    queryKey: ["task-templates"],
    queryFn: () => api<Template[]>("/task-templates"),
  });
  const [name, setName] = useState("");
  const [title, setTitle] = useState("");

  const create = useMutation({
    mutationFn: () =>
      api("/task-templates", {
        method: "POST",
        body: { name, title, priority: "medium", labels: [], checklist: [] },
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["task-templates"] });
      setName("");
      setTitle("");
    },
  });

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Task templates</h1>
        <p className="text-sm text-slate-500">Reusable shapes — clone into a project to materialize a task.</p>
      </div>
      <Card>
        <CardBody>
          <h2 className="mb-3 text-base font-semibold">New template</h2>
          <div className="grid grid-cols-2 gap-3">
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Internal name" />
            <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Default task title" />
          </div>
          <div className="mt-3">
            <Button variant="primary" disabled={!name || !title} onClick={() => create.mutate()}>
              Create
            </Button>
          </div>
        </CardBody>
      </Card>
      {list.data && list.data.length > 0 ? (
        <DataTable
          rows={list.data}
          rowKey={(t) => t.id}
          columns={[
            { key: "name", header: "Name", cell: (t) => <span className="font-medium">{t.name}</span> },
            { key: "title", header: "Default title", cell: (t) => t.title },
            { key: "priority", header: "Priority", cell: (t) => t.priority },
            {
              key: "labels",
              header: "Labels",
              cell: (t) => (t.labels.length ? t.labels.map((l) => <Badge key={l} tone="neutral">{l}</Badge>) : "—"),
            },
          ]}
        />
      ) : (
        <EmptyState title="No templates yet" />
      )}
    </div>
  );
}
