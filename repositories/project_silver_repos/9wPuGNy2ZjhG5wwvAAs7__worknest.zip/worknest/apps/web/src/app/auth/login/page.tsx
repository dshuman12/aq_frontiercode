"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Button, Card, CardBody, Input, Label, useToast } from "@worknest/ui";
import { api } from "@/lib/api";
import { useAuth } from "@/stores/auth";

export default function LoginPage() {
  const router = useRouter();
  const toast = useToast();
  const setSession = useAuth((s) => s.setSession);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [twoFactor, setTwoFactor] = useState("");
  const [needs2fa, setNeeds2fa] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const result = await api<{
        accessToken: string;
        refreshToken: string;
        sessionToken: string;
        user: { id: string; email: string; name: string };
      }>("/auth/login", {
        method: "POST",
        body: { email, password, twoFactorCode: twoFactor || undefined },
      });
      setSession(result);
      toast.push({ title: `Welcome back, ${result.user.name}!`, variant: "success" });
      router.replace("/dashboard");
    } catch (err) {
      const msg = (err as Error).message;
      if (msg === "totp_required") {
        setNeeds2fa(true);
      } else {
        setError(msg === "invalid_credentials" ? "Invalid email or password." : msg);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
      <Card className="w-full max-w-md">
        <CardBody>
          <h1 className="text-2xl font-semibold text-center mb-6">Sign in to WorkNest</h1>
          <form onSubmit={submit} className="space-y-4">
            <div>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                required
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                value={password}
                required
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
            {needs2fa && (
              <div>
                <Label htmlFor="totp">2FA code</Label>
                <Input
                  id="totp"
                  inputMode="numeric"
                  pattern="[0-9]{6}"
                  maxLength={6}
                  value={twoFactor}
                  onChange={(e) => setTwoFactor(e.target.value)}
                />
              </div>
            )}
            {error && <p className="text-sm text-red-600">{error}</p>}
            <Button type="submit" className="w-full" loading={loading}>
              Sign in
            </Button>
          </form>
          <div className="flex items-center justify-between mt-4 text-sm">
            <Link href="/auth/forgot" className="text-brand-600 hover:underline">
              Forgot password?
            </Link>
            <Link href="/auth/register" className="text-brand-600 hover:underline">
              Create an account
            </Link>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
