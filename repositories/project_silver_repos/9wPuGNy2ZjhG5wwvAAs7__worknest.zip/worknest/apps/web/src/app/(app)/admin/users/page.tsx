"use client";
import { useQuery } from "@tanstack/react-query";
import { Avatar, Badge, Card, CardBody, DataTable } from "@worknest/ui";
import { api } from "@/lib/api";

interface Member {
  id: string;
  userId: string;
  role: string;
  status: string;
  joinedAt: string;
  user: { id: string; name: string; email: string };
}

export default function AdminUsersPage() {
  const { data = [], isLoading } = useQuery({
    queryKey: ["admin", "members"],
    queryFn: () => api<Member[]>("/organizations/current/members"),
  });

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Users</h1>
      {isLoading ? (
        <Card><CardBody>Loading…</CardBody></Card>
      ) : (
        <DataTable
          rows={data}
          keyOf={(m) => m.id}
          columns={[
            {
              key: "user",
              header: "User",
              cell: (m) => (
                <span className="flex items-center gap-2">
                  <Avatar size="sm" name={m.user.name} />
                  <span>
                    <span className="font-medium block">{m.user.name}</span>
                    <span className="text-xs text-slate-500">{m.user.email}</span>
                  </span>
                </span>
              ),
            },
            { key: "role", header: "Role", cell: (m) => <Badge>{m.role}</Badge> },
            { key: "status", header: "Status", cell: (m) => <Badge variant={m.status === "active" ? "success" : "neutral"}>{m.status}</Badge> },
            { key: "joined", header: "Joined", cell: (m) => new Date(m.joinedAt).toLocaleDateString() },
          ]}
        />
      )}
    </div>
  );
}
