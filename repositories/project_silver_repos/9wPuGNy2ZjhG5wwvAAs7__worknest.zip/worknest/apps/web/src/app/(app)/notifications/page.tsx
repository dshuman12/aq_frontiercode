"use client";
import Link from "next/link";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Badge, Button, Card, CardBody, EmptyState, Tab, Tabs } from "@worknest/ui";
import { api } from "@/lib/api";

interface Notif {
  id: string;
  kind: string;
  title: string;
  body?: string;
  link?: string;
  severity: "info" | "warning" | "critical";
  occurredAt: string;
  readAt?: string | null;
}

const SEVERITY: Record<Notif["severity"], "neutral" | "warning" | "danger"> = {
  info: "neutral",
  warning: "warning",
  critical: "danger",
};

export default function NotificationsPage() {
  const qc = useQueryClient();
  const all = useQuery({ queryKey: ["notifications"], queryFn: () => api<{ items: Notif[] }>(`/notifications`) });
  const unread = useQuery({ queryKey: ["notifications", "unread"], queryFn: () => api<Notif[]>(`/notifications/unread`) });

  const markRead = useMutation({
    mutationFn: (ids: string[]) => api(`/notifications/read`, { method: "POST", body: { ids } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["notifications"] }),
  });
  const markAll = useMutation({
    mutationFn: () => api(`/notifications/read-all`, { method: "POST" }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["notifications"] }),
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Notifications</h1>
        {(unread.data ?? []).length > 0 && (
          <Button variant="outline" onClick={() => markAll.mutate()}>
            Mark all read
          </Button>
        )}
      </div>

      <Tabs>
        <Tab label={`Unread (${unread.data?.length ?? 0})`}>
          <List items={unread.data ?? []} onRead={(ids) => markRead.mutate(ids)} />
        </Tab>
        <Tab label="All">
          <List items={all.data?.items ?? []} onRead={(ids) => markRead.mutate(ids)} />
        </Tab>
      </Tabs>
    </div>
  );
}

function List({ items, onRead }: { items: Notif[]; onRead: (ids: string[]) => void }) {
  if (items.length === 0) return <EmptyState title="All caught up" description="You have no notifications matching this filter." />;
  return (
    <Card>
      <CardBody>
        <ul className="divide-y">
          {items.map((n) => (
            <li key={n.id} className="py-3 flex items-start gap-3">
              {n.severity && <Badge variant={SEVERITY[n.severity]}>{n.severity}</Badge>}
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  {n.link ? (
                    <Link href={n.link} className="font-medium hover:underline" onClick={() => !n.readAt && onRead([n.id])}>
                      {n.title}
                    </Link>
                  ) : (
                    <span className="font-medium">{n.title}</span>
                  )}
                  <span className="text-xs text-slate-500">{new Date(n.occurredAt).toLocaleString()}</span>
                </div>
                {n.body && <p className="text-sm text-slate-600 mt-1">{n.body}</p>}
              </div>
              {!n.readAt && (
                <Button variant="ghost" onClick={() => onRead([n.id])}>
                  Mark read
                </Button>
              )}
            </li>
          ))}
        </ul>
      </CardBody>
    </Card>
  );
}
