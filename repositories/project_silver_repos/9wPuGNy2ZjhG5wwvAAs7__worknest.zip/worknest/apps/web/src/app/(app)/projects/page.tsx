"use client";
import Link from "next/link";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Badge, Button, Card, CardBody, DataTable, EmptyState, Input, Label, Modal, useToast } from "@worknest/ui";
import { api } from "@/lib/api";

interface Project {
  id: string;
  name: string;
  key: string;
  status: string;
  archivedAt?: string | null;
  _count?: { tasks: number; milestones: number };
}

export default function ProjectsPage() {
  const qc = useQueryClient();
  const toast = useToast();
  const [showNew, setShowNew] = useState(false);
  const [name, setName] = useState("");
  const [key, setKey] = useState("");

  const { data = [], isLoading } = useQuery({
    queryKey: ["projects"],
    queryFn: () => api<Project[]>("/projects"),
  });

  const create = useMutation({
    mutationFn: (input: { name: string; key: string }) =>
      api<Project>("/projects", { method: "POST", body: input }),
    onSuccess: () => {
      toast.push({ title: "Project created", variant: "success" });
      setShowNew(false);
      setName("");
      setKey("");
      qc.invalidateQueries({ queryKey: ["projects"] });
    },
    onError: (err: Error) =>
      toast.push({ title: "Failed", description: err.message, variant: "danger" }),
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Projects</h1>
        <Button onClick={() => setShowNew(true)}>New project</Button>
      </div>

      {isLoading ? (
        <Card><CardBody>Loading…</CardBody></Card>
      ) : data.length === 0 ? (
        <EmptyState
          title="No projects yet"
          description="Create your first project to start tracking work."
          action={<Button onClick={() => setShowNew(true)}>Create project</Button>}
        />
      ) : (
        <DataTable
          rows={data}
          keyOf={(p) => p.id}
          columns={[
            {
              key: "key",
              header: "Key",
              cell: (p) => <Badge variant="outline">{p.key}</Badge>,
            },
            {
              key: "name",
              header: "Name",
              cell: (p) => (
                <Link href={`/projects/${p.id}`} className="font-medium hover:underline">
                  {p.name}
                </Link>
              ),
            },
            { key: "tasks", header: "Tasks", cell: (p) => p._count?.tasks ?? 0 },
            { key: "milestones", header: "Milestones", cell: (p) => p._count?.milestones ?? 0 },
            {
              key: "status",
              header: "Status",
              cell: (p) => (
                <Badge variant={p.status === "archived" ? "warning" : "success"}>{p.status}</Badge>
              ),
            },
          ]}
        />
      )}

      <Modal
        open={showNew}
        onClose={() => setShowNew(false)}
        title="New project"
        footer={
          <>
            <Button variant="outline" onClick={() => setShowNew(false)}>
              Cancel
            </Button>
            <Button onClick={() => create.mutate({ name, key })} loading={create.isPending}>
              Create
            </Button>
          </>
        }
      >
        <div className="space-y-3">
          <div>
            <Label htmlFor="np-name">Name</Label>
            <Input id="np-name" value={name} onChange={(e) => setName(e.target.value)} />
          </div>
          <div>
            <Label htmlFor="np-key">Key</Label>
            <Input
              id="np-key"
              value={key}
              onChange={(e) => setKey(e.target.value.toUpperCase())}
              placeholder="ENG"
            />
            <p className="text-xs text-slate-500 mt-1">2-8 uppercase letters.</p>
          </div>
        </div>
      </Modal>
    </div>
  );
}
