"use client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardBody, EmptyState } from "@worknest/ui";
import { api } from "@/lib/api";
import { useAuth } from "@/stores/auth";

interface Overview {
  openTasks: number;
  overdueTasks: number;
  completedThisWeek: number;
  activeProjects: number;
  openTickets: number;
  pendingRequests: number;
  pendingApprovals: number;
}

export default function DashboardPage() {
  const user = useAuth((s) => s.user);
  const overview = useQuery({
    queryKey: ["reports", "overview"],
    queryFn: () => api<Overview>("/reports/overview"),
  });

  const cards = overview.data
    ? [
        { label: "Open tasks", value: overview.data.openTasks },
        { label: "Overdue", value: overview.data.overdueTasks },
        { label: "Completed this week", value: overview.data.completedThisWeek },
        { label: "Active projects", value: overview.data.activeProjects },
        { label: "Open tickets", value: overview.data.openTickets },
        { label: "Pending requests", value: overview.data.pendingRequests },
        { label: "Awaiting your approval", value: overview.data.pendingApprovals },
      ]
    : [];

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-semibold">Dashboard</h1>
        {user && <p className="text-slate-600">Hi {user.name}, here's what's happening.</p>}
      </div>

      {overview.isLoading ? (
        <Card><CardBody>Loading…</CardBody></Card>
      ) : overview.isError ? (
        <EmptyState title="Could not load dashboard" description="Try refreshing in a moment." />
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {cards.map((c) => (
            <Card key={c.label}>
              <CardBody>
                <p className="text-xs uppercase tracking-wide text-slate-500">{c.label}</p>
                <p className="text-3xl font-semibold mt-1">{c.value}</p>
              </CardBody>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
