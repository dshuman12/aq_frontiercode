"use client";
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Badge, Card, CardBody, EmptyState } from "@worknest/ui";
import { api } from "@/lib/api";

interface Event {
  id: string;
  title: string;
  start: string;
  end: string;
  type: "task_due" | "sprint" | "milestone";
  link: string;
}

const TYPE_TONE: Record<string, "info" | "warning" | "success"> = {
  task_due: "info",
  sprint: "warning",
  milestone: "success",
};

export default function CalendarPage() {
  const today = useMemo(() => new Date(), []);
  const [cursor, setCursor] = useState(today);

  const monthStart = new Date(cursor.getFullYear(), cursor.getMonth(), 1);
  const monthEnd = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0, 23, 59, 59);

  const events = useQuery({
    queryKey: ["calendar", monthStart.toISOString(), monthEnd.toISOString()],
    queryFn: () =>
      api<Event[]>(
        `/calendar/events?from=${monthStart.toISOString()}&to=${monthEnd.toISOString()}`,
      ),
  });

  const grouped = useMemo(() => {
    const out = new Map<string, Event[]>();
    for (const e of events.data ?? []) {
      const day = new Date(e.start).toLocaleDateString();
      if (!out.has(day)) out.set(day, []);
      out.get(day)!.push(e);
    }
    return Array.from(out.entries());
  }, [events.data]);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Calendar</h1>
          <p className="text-sm text-slate-500">Tasks, sprints, and milestones in one view.</p>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <button
            onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() - 1, 1))}
            className="rounded-md border border-slate-200 px-2 py-1 hover:bg-slate-50"
          >
            ←
          </button>
          <span className="font-medium">
            {cursor.toLocaleString(undefined, { month: "long", year: "numeric" })}
          </span>
          <button
            onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1))}
            className="rounded-md border border-slate-200 px-2 py-1 hover:bg-slate-50"
          >
            →
          </button>
        </div>
      </div>

      {grouped.length > 0 ? (
        <div className="space-y-4">
          {grouped.map(([day, items]) => (
            <Card key={day}>
              <CardBody>
                <h3 className="text-sm font-semibold">{day}</h3>
                <ul className="mt-2 space-y-1 text-sm">
                  {items.map((e) => (
                    <li key={e.id} className="flex items-center justify-between">
                      <span>{e.title}</span>
                      <Badge tone={TYPE_TONE[e.type]}>{e.type.replace("_", " ")}</Badge>
                    </li>
                  ))}
                </ul>
              </CardBody>
            </Card>
          ))}
        </div>
      ) : (
        <EmptyState title="No events this month" />
      )}
    </div>
  );
}
