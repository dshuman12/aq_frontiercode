"use client";
import Link from "next/link";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Badge, Card, CardBody, DataTable, EmptyState, Input, Select } from "@worknest/ui";
import { api } from "@/lib/api";

interface Task {
  id: string;
  key: string;
  title: string;
  status: string;
  priority: string;
  assigneeId?: string | null;
  dueAt?: string | null;
  createdAt: string;
}

interface PageOf<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
}

export default function TasksPage() {
  const [filters, setFilters] = useState<Record<string, string>>({});

  const { data, isLoading } = useQuery({
    queryKey: ["tasks", filters],
    queryFn: () => {
      const p = new URLSearchParams();
      for (const [k, v] of Object.entries(filters)) if (v) p.set(k, v);
      return api<PageOf<Task>>(`/tasks${p.toString() ? `?${p}` : ""}`);
    },
  });

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Tasks</h1>

      <div className="flex gap-2">
        <Input
          placeholder="Search…"
          className="max-w-xs"
          value={filters.q ?? ""}
          onChange={(e) => setFilters({ ...filters, q: e.target.value })}
        />
        <Select
          value={filters.status ?? ""}
          onChange={(e) => setFilters({ ...filters, status: e.target.value })}
          className="max-w-[160px]"
        >
          <option value="">All statuses</option>
          <option value="todo">Todo</option>
          <option value="in_progress">In progress</option>
          <option value="review">In review</option>
          <option value="blocked">Blocked</option>
          <option value="done">Done</option>
        </Select>
        <Select
          value={filters.priority ?? ""}
          onChange={(e) => setFilters({ ...filters, priority: e.target.value })}
          className="max-w-[160px]"
        >
          <option value="">All priorities</option>
          <option value="low">Low</option>
          <option value="medium">Medium</option>
          <option value="high">High</option>
          <option value="urgent">Urgent</option>
        </Select>
      </div>

      {isLoading ? (
        <Card><CardBody>Loading…</CardBody></Card>
      ) : !data || data.items.length === 0 ? (
        <EmptyState title="No tasks match" description="Adjust your filters or create a new task from inside a project." />
      ) : (
        <DataTable
          rows={data.items}
          keyOf={(t) => t.id}
          columns={[
            { key: "key", header: "Key", cell: (t) => <Badge variant="outline">{t.key}</Badge> },
            {
              key: "title",
              header: "Title",
              cell: (t) => (
                <Link href={`/tasks/${t.id}`} className="hover:underline font-medium">
                  {t.title}
                </Link>
              ),
            },
            { key: "priority", header: "Priority", cell: (t) => <Badge>{t.priority}</Badge> },
            { key: "status", header: "Status", cell: (t) => <Badge>{t.status}</Badge> },
            { key: "due", header: "Due", cell: (t) => t.dueAt ? new Date(t.dueAt).toLocaleDateString() : <span className="text-slate-400">—</span> },
          ]}
        />
      )}
    </div>
  );
}
