"use client";
import { useParams } from "next/navigation";
import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Badge, Card, CardBody, EmptyState } from "@worknest/ui";
import { api } from "@/lib/api";

interface Bar {
  id: string;
  type: "task" | "sprint" | "milestone";
  label: string;
  start: string;
  end: string;
}

const TYPE_TONE: Record<string, "info" | "warning" | "success"> = {
  task: "info",
  sprint: "warning",
  milestone: "success",
};

export default function GanttPage() {
  const params = useParams<{ id: string }>();
  const data = useQuery({
    queryKey: ["gantt", params.id],
    queryFn: () => api<{ bars: Bar[] }>(`/gantt?projectId=${params.id}`),
  });

  const range = useMemo(() => {
    const bars = data.data?.bars ?? [];
    if (bars.length === 0) return null;
    const start = Math.min(...bars.map((b) => new Date(b.start).getTime()));
    const end = Math.max(...bars.map((b) => new Date(b.end).getTime()));
    return { start, end, span: Math.max(1, end - start) };
  }, [data.data]);

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold tracking-tight">Gantt</h1>
      {range && data.data ? (
        <Card>
          <CardBody>
            <ul className="space-y-2">
              {data.data.bars.map((b) => {
                const startMs = new Date(b.start).getTime();
                const endMs = new Date(b.end).getTime();
                const offset = ((startMs - range.start) / range.span) * 100;
                const width = Math.max(1, ((endMs - startMs) / range.span) * 100);
                return (
                  <li key={b.id} className="grid grid-cols-[180px_1fr] items-center gap-3">
                    <div className="truncate text-xs text-slate-600">{b.label}</div>
                    <div className="relative h-5 rounded bg-slate-100">
                      <div
                        className={`absolute inset-y-0 rounded ${
                          b.type === "task"
                            ? "bg-sky-500"
                            : b.type === "sprint"
                              ? "bg-amber-500"
                              : "bg-emerald-500"
                        }`}
                        style={{ left: `${offset}%`, width: `${width}%` }}
                      />
                    </div>
                  </li>
                );
              })}
            </ul>
            <div className="mt-3 flex gap-2 text-xs">
              <Badge tone={TYPE_TONE.task}>tasks</Badge>
              <Badge tone={TYPE_TONE.sprint}>sprints</Badge>
              <Badge tone={TYPE_TONE.milestone}>milestones</Badge>
            </div>
          </CardBody>
        </Card>
      ) : (
        <EmptyState title="Nothing to chart" description="Add due dates or sprint windows to your tasks." />
      )}
    </div>
  );
}
