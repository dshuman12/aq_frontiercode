"use client";
import Link from "next/link";
import { Card, CardBody, CardHeader, CardTitle } from "@worknest/ui";

const SECTIONS = [
  { href: "/admin/users", label: "Users", description: "Invite, suspend, change roles." },
  { href: "/admin/api-keys", label: "API keys", description: "Issue and revoke API tokens." },
  { href: "/admin/audit-log", label: "Audit log", description: "Browse every state change." },
  { href: "/admin/webhooks", label: "Webhooks", description: "Configure event subscriptions." },
];

export default function AdminPage() {
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Admin</h1>
      <div className="grid gap-3 md:grid-cols-2">
        {SECTIONS.map((s) => (
          <Link key={s.href} href={s.href}>
            <Card className="hover:shadow-md transition-shadow">
              <CardHeader><CardTitle>{s.label}</CardTitle></CardHeader>
              <CardBody>
                <p className="text-sm text-slate-600">{s.description}</p>
              </CardBody>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}
