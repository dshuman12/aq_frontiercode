"use client";
import Link from "next/link";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Avatar, Badge, Button, Card, CardBody, CardHeader, CardTitle, EmptyState, Tab, Tabs, Textarea, useToast } from "@worknest/ui";
import { api } from "@/lib/api";

interface TicketDetail {
  id: string;
  key: string;
  title: string;
  description?: string | null;
  status: string;
  priority: string;
  category?: { id: string; name: string } | null;
  comments: { id: string; body: string; internal: boolean; createdAt: string }[];
  history: { id: string; fromStatus?: string | null; toStatus: string; at: string }[];
  watchers: { id: string; userId: string }[];
  createdAt: string;
}

export default function TicketDetailPage({ params }: { params: { id: string } }) {
  const id = params.id;
  const qc = useQueryClient();
  const toast = useToast();
  const [body, setBody] = useState("");
  const [internal, setInternal] = useState(false);

  const ticket = useQuery({ queryKey: ["ticket", id], queryFn: () => api<TicketDetail>(`/tickets/${id}`) });

  const transition = useMutation({
    mutationFn: (toStatus: string) =>
      api(`/tickets/${id}/transition`, { method: "POST", body: { toStatus } }),
    onSuccess: () => {
      toast.push({ title: "Status updated", variant: "success" });
      qc.invalidateQueries({ queryKey: ["ticket", id] });
    },
  });

  const comment = useMutation({
    mutationFn: (input: { body: string; internal: boolean }) =>
      api(`/tickets/${id}/comments`, { method: "POST", body: input }),
    onSuccess: () => {
      setBody("");
      qc.invalidateQueries({ queryKey: ["ticket", id] });
    },
  });

  if (ticket.isLoading) return <Card><CardBody>Loading…</CardBody></Card>;
  if (!ticket.data) return <EmptyState title="Ticket not found" />;

  const t = ticket.data;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
      <div className="lg:col-span-2 space-y-4">
        <div>
          <Link href="/tickets" className="text-sm text-slate-500 hover:underline">Tickets</Link>
          <div className="flex items-center gap-2 mt-1">
            <Badge variant="outline">{t.key}</Badge>
            <h1 className="text-2xl font-semibold">{t.title}</h1>
            <Badge>{t.status}</Badge>
          </div>
        </div>

        {t.description && (
          <Card>
            <CardHeader><CardTitle>Description</CardTitle></CardHeader>
            <CardBody><p className="whitespace-pre-line">{t.description}</p></CardBody>
          </Card>
        )}

        <Tabs>
          <Tab label={`Replies (${t.comments.length})`}>
            <div className="space-y-3">
              {t.comments.map((c) => (
                <Card key={c.id} className={c.internal ? "border-amber-200 bg-amber-50" : ""}>
                  <CardBody>
                    <div className="flex items-center gap-2 mb-1">
                      {c.internal && <Badge variant="warning">internal</Badge>}
                      <span className="text-xs text-slate-500">{new Date(c.createdAt).toLocaleString()}</span>
                    </div>
                    <p className="text-sm whitespace-pre-line">{c.body}</p>
                  </CardBody>
                </Card>
              ))}
              <Card>
                <CardBody>
                  <Textarea placeholder="Reply or note" rows={3} value={body} onChange={(e) => setBody(e.target.value)} />
                  <div className="flex items-center justify-between mt-2">
                    <label className="text-sm flex items-center gap-2">
                      <input type="checkbox" checked={internal} onChange={(e) => setInternal(e.target.checked)} />
                      Internal note
                    </label>
                    <Button onClick={() => comment.mutate({ body, internal })} disabled={!body.trim()}>
                      {internal ? "Post note" : "Reply"}
                    </Button>
                  </div>
                </CardBody>
              </Card>
            </div>
          </Tab>
          <Tab label="History">
            <Card>
              <CardBody>
                <ul className="divide-y">
                  {t.history.map((h) => (
                    <li key={h.id} className="py-2 text-sm flex items-center justify-between">
                      <span>
                        {h.fromStatus ?? "—"} → <span className="font-medium">{h.toStatus}</span>
                      </span>
                      <span className="text-xs text-slate-500">{new Date(h.at).toLocaleString()}</span>
                    </li>
                  ))}
                </ul>
              </CardBody>
            </Card>
          </Tab>
        </Tabs>
      </div>

      <div className="space-y-4">
        <Card>
          <CardHeader><CardTitle>Status</CardTitle></CardHeader>
          <CardBody className="space-y-2">
            <Badge>{t.status}</Badge>
            <div className="grid grid-cols-2 gap-2 mt-3">
              {(["in_progress", "on_hold", "resolved", "closed"] as const).map((s) => (
                <Button
                  key={s}
                  variant="outline"
                  size="sm"
                  disabled={s === t.status}
                  onClick={() => transition.mutate(s)}
                >
                  {s}
                </Button>
              ))}
            </div>
          </CardBody>
        </Card>
        <Card>
          <CardHeader><CardTitle>Properties</CardTitle></CardHeader>
          <CardBody>
            <dl className="text-sm space-y-2">
              <div className="flex justify-between"><dt className="text-slate-500">Priority</dt><dd>{t.priority}</dd></div>
              <div className="flex justify-between"><dt className="text-slate-500">Category</dt><dd>{t.category?.name ?? "—"}</dd></div>
              <div className="flex justify-between"><dt className="text-slate-500">Created</dt><dd>{new Date(t.createdAt).toLocaleDateString()}</dd></div>
            </dl>
          </CardBody>
        </Card>
      </div>
    </div>
  );
}
