"use client";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Badge, Button, Card, CardBody, DataTable, EmptyState, Input } from "@worknest/ui";
import { api } from "@/lib/api";

interface SlaPolicy {
  id: string;
  name: string;
  priority: string;
  firstResponseMinutes: number;
  resolutionMinutes: number;
  active: boolean;
}

const PRIORITY_TONE: Record<string, "info" | "warning" | "critical" | "neutral"> = {
  low: "neutral",
  medium: "neutral",
  high: "warning",
  urgent: "critical",
};

export default function SlaAdminPage() {
  const qc = useQueryClient();
  const policies = useQuery({
    queryKey: ["sla-policies"],
    queryFn: () => api<SlaPolicy[]>("/sla/policies"),
  });

  const [name, setName] = useState("");
  const [priority, setPriority] = useState("medium");
  const [firstResponse, setFirstResponse] = useState("60");
  const [resolution, setResolution] = useState("480");

  const create = useMutation({
    mutationFn: () =>
      api<SlaPolicy>("/sla/policies", {
        method: "POST",
        body: {
          name,
          priority,
          firstResponseMinutes: Number(firstResponse),
          resolutionMinutes: Number(resolution),
          businessHoursOnly: false,
          active: true,
        },
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["sla-policies"] });
      setName("");
    },
  });

  const sweep = useMutation({
    mutationFn: () => api("/sla/sweep", { method: "POST" }),
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">SLA policies</h1>
          <p className="text-sm text-slate-500">First-response and resolution targets per priority.</p>
        </div>
        <Button variant="ghost" onClick={() => sweep.mutate()}>Re-sweep breaches</Button>
      </div>

      <Card>
        <CardBody>
          <h2 className="mb-3 text-base font-semibold">New policy</h2>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Name" />
            <select
              value={priority}
              onChange={(e) => setPriority(e.target.value)}
              className="h-10 rounded-md border border-slate-200 bg-white px-3 text-sm"
            >
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
              <option value="urgent">Urgent</option>
            </select>
            <Input
              type="number"
              value={firstResponse}
              onChange={(e) => setFirstResponse(e.target.value)}
              placeholder="First-response (min)"
            />
            <Input
              type="number"
              value={resolution}
              onChange={(e) => setResolution(e.target.value)}
              placeholder="Resolution (min)"
            />
          </div>
          <div className="mt-3">
            <Button variant="primary" disabled={!name} onClick={() => create.mutate()}>
              Create policy
            </Button>
          </div>
        </CardBody>
      </Card>

      {policies.data && policies.data.length > 0 ? (
        <DataTable
          rows={policies.data}
          rowKey={(p) => p.id}
          columns={[
            { key: "name", header: "Name", cell: (p) => <span className="font-medium">{p.name}</span> },
            {
              key: "priority",
              header: "Priority",
              cell: (p) => <Badge tone={PRIORITY_TONE[p.priority] ?? "neutral"}>{p.priority}</Badge>,
            },
            { key: "fr", header: "First response", cell: (p) => `${p.firstResponseMinutes} min`, align: "right" },
            { key: "res", header: "Resolution", cell: (p) => `${p.resolutionMinutes} min`, align: "right" },
            { key: "active", header: "Active", cell: (p) => (p.active ? "Yes" : "No") },
          ]}
        />
      ) : (
        <EmptyState title="No SLA policies yet" description="Add one above to start tracking targets on tickets." />
      )}
    </div>
  );
}
