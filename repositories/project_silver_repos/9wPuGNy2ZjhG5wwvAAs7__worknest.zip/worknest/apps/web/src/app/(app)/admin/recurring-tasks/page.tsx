"use client";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Badge, Button, Card, CardBody, DataTable, EmptyState } from "@worknest/ui";
import { api } from "@/lib/api";

interface Recurring {
  id: string;
  name: string;
  cadence: "daily" | "weekly" | "monthly";
  active: boolean;
  nextRunAt: string;
  lastRunAt: string | null;
  project: { id: string; key: string; name: string };
}

export default function RecurringTasksAdmin() {
  const qc = useQueryClient();
  const list = useQuery({
    queryKey: ["recurring-tasks"],
    queryFn: () => api<Recurring[]>("/recurring-tasks"),
  });
  const pause = useMutation({
    mutationFn: (input: { id: string; active: boolean }) =>
      api(`/recurring-tasks/${input.id}/pause`, {
        method: "POST",
        body: { active: input.active },
      }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["recurring-tasks"] }),
  });

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Recurring tasks</h1>
        <p className="text-sm text-slate-500">Schedules that auto-create tasks on cadence.</p>
      </div>
      {list.data && list.data.length > 0 ? (
        <Card>
          <CardBody className="p-0">
            <DataTable
              rows={list.data}
              rowKey={(r) => r.id}
              columns={[
                { key: "name", header: "Name", cell: (r) => <span className="font-medium">{r.name}</span> },
                { key: "project", header: "Project", cell: (r) => r.project.key },
                { key: "cadence", header: "Cadence", cell: (r) => r.cadence },
                {
                  key: "next",
                  header: "Next run",
                  cell: (r) => new Date(r.nextRunAt).toLocaleString(),
                },
                {
                  key: "active",
                  header: "Active",
                  cell: (r) => (r.active ? <Badge tone="success">on</Badge> : <Badge tone="neutral">paused</Badge>),
                },
                {
                  key: "actions",
                  header: "",
                  cell: (r) => (
                    <Button
                      variant="ghost"
                      onClick={() => pause.mutate({ id: r.id, active: !r.active })}
                    >
                      {r.active ? "Pause" : "Resume"}
                    </Button>
                  ),
                },
              ]}
            />
          </CardBody>
        </Card>
      ) : (
        <EmptyState title="No recurring tasks" description="Create one to auto-generate routine work." />
      )}
    </div>
  );
}
