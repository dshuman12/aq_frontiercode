"use client";
import Link from "next/link";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Badge, Button, Card, CardBody, CardHeader, CardTitle, EmptyState, KanbanBoard, Tab, Tabs, useToast } from "@worknest/ui";
import { api } from "@/lib/api";

interface Project {
  id: string;
  name: string;
  key: string;
  description?: string | null;
  status: string;
  archivedAt?: string | null;
}

interface Board {
  id: string;
  name: string;
  columns: { id: string; name: string; order: number }[];
}

interface Task {
  id: string;
  key: string;
  title: string;
  status: string;
  priority: string;
  boardColumnId?: string | null;
}

export default function ProjectDetailPage({ params }: { params: { id: string } }) {
  const id = params.id;
  const qc = useQueryClient();
  const toast = useToast();

  const project = useQuery({ queryKey: ["project", id], queryFn: () => api<Project>(`/projects/${id}`) });
  const boards = useQuery({ queryKey: ["project-boards", id], queryFn: () => api<Board[]>(`/boards/by-project/${id}`) });
  const tasks = useQuery({
    queryKey: ["project-tasks", id],
    queryFn: () => api<{ items: Task[] }>(`/tasks?projectId=${id}&pageSize=200`),
  });

  const move = useMutation({
    mutationFn: (input: { taskId: string; columnId: string }) =>
      api(`/tasks/${input.taskId}/move`, { method: "POST", body: { boardColumnId: input.columnId } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["project-tasks", id] }),
  });

  if (project.isLoading) return <Card><CardBody>Loading…</CardBody></Card>;
  if (!project.data) return <EmptyState title="Project not found" description="It may have been archived or removed." />;

  const board = boards.data?.[0];
  const cols = board?.columns ?? [];
  const items = tasks.data?.items ?? [];

  return (
    <div className="space-y-4">
      <div>
        <Link href="/projects" className="text-sm text-slate-500 hover:underline">Projects</Link>
        <div className="flex items-center gap-2 mt-1">
          <Badge variant="outline">{project.data.key}</Badge>
          <h1 className="text-2xl font-semibold">{project.data.name}</h1>
          <Badge variant={project.data.status === "archived" ? "warning" : "success"}>{project.data.status}</Badge>
        </div>
        {project.data.description && <p className="text-slate-600 mt-1">{project.data.description}</p>}
      </div>

      <Tabs>
        <Tab label="Board">
          {!board ? (
            <EmptyState title="No board" description="The default board hasn't been created yet." />
          ) : (
            <KanbanBoard
              columns={cols.map((c) => ({
                id: c.id,
                title: c.name,
                tasks: items
                  .filter((t) => t.boardColumnId === c.id)
                  .map((t) => ({ id: t.id, title: t.title, subtitle: t.key })),
              }))}
              onTaskMove={(taskId, columnId) => move.mutate({ taskId, columnId })}
            />
          )}
        </Tab>
        <Tab label="List">
          <Card>
            <CardBody className="divide-y">
              {items.map((t) => (
                <Link
                  key={t.id}
                  href={`/tasks/${t.id}`}
                  className="flex items-center justify-between py-2 hover:bg-slate-50 -mx-2 px-2 rounded"
                >
                  <span className="flex items-center gap-2">
                    <Badge variant="outline">{t.key}</Badge>
                    <span className="font-medium">{t.title}</span>
                  </span>
                  <span className="flex items-center gap-2 text-xs text-slate-500">
                    <Badge>{t.priority}</Badge>
                    <Badge>{t.status}</Badge>
                  </span>
                </Link>
              ))}
            </CardBody>
          </Card>
        </Tab>
      </Tabs>
    </div>
  );
}
