"use client";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Badge, Button, Card, CardBody, EmptyState, Input, Label, Modal, useToast } from "@worknest/ui";
import { api } from "@/lib/api";

interface ApiKeyRow {
  id: string;
  label: string;
  scopes: string;
  lastUsedAt?: string | null;
  createdAt: string;
}

export default function ApiKeysPage() {
  const qc = useQueryClient();
  const toast = useToast();
  const [showNew, setShowNew] = useState(false);
  const [label, setLabel] = useState("");
  const [scopes, setScopes] = useState("tasks:read,tasks:write,projects:read");
  const [plaintext, setPlaintext] = useState<string | null>(null);

  const list = useQuery({ queryKey: ["api-keys"], queryFn: () => api<ApiKeyRow[]>("/api-keys") });

  const create = useMutation({
    mutationFn: () => api<ApiKeyRow & { plaintext: string }>("/api-keys", { method: "POST", body: { label, scopes } }),
    onSuccess: (res) => {
      setPlaintext(res.plaintext);
      setLabel("");
      qc.invalidateQueries({ queryKey: ["api-keys"] });
    },
  });

  const revoke = useMutation({
    mutationFn: (id: string) => api(`/api-keys/${id}`, { method: "DELETE" }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["api-keys"] }),
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">API keys</h1>
        <Button onClick={() => setShowNew(true)}>Create key</Button>
      </div>

      {(list.data ?? []).length === 0 ? (
        <EmptyState title="No API keys" description="Create a key to grant programmatic access." />
      ) : (
        <Card>
          <CardBody>
            <ul className="divide-y">
              {list.data!.map((k) => (
                <li key={k.id} className="py-3 flex items-center justify-between">
                  <div>
                    <p className="font-medium">{k.label}</p>
                    <p className="text-xs text-slate-500">
                      <Badge variant="outline">{k.scopes}</Badge>
                      <span className="ml-2">created {new Date(k.createdAt).toLocaleDateString()}</span>
                    </p>
                  </div>
                  <Button variant="ghost" onClick={() => revoke.mutate(k.id)}>
                    Revoke
                  </Button>
                </li>
              ))}
            </ul>
          </CardBody>
        </Card>
      )}

      <Modal
        open={showNew}
        onClose={() => { setShowNew(false); setPlaintext(null); }}
        title={plaintext ? "Save your key" : "New API key"}
        footer={
          plaintext ? (
            <Button onClick={() => { setShowNew(false); setPlaintext(null); }}>I've saved it</Button>
          ) : (
            <>
              <Button variant="outline" onClick={() => setShowNew(false)}>Cancel</Button>
              <Button onClick={() => create.mutate()} loading={create.isPending}>Create</Button>
            </>
          )
        }
      >
        {plaintext ? (
          <div className="space-y-3">
            <p className="text-sm text-amber-700">This is the only time we'll show the key.</p>
            <code className="block bg-slate-900 text-emerald-300 p-3 rounded text-sm break-all font-mono">
              {plaintext}
            </code>
          </div>
        ) : (
          <div className="space-y-3">
            <div><Label htmlFor="lab">Label</Label><Input id="lab" value={label} onChange={(e) => setLabel(e.target.value)} /></div>
            <div>
              <Label htmlFor="sc">Scopes</Label>
              <Input id="sc" value={scopes} onChange={(e) => setScopes(e.target.value)} />
              <p className="text-xs text-slate-500 mt-1">Comma-separated permission strings, or `*`.</p>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
