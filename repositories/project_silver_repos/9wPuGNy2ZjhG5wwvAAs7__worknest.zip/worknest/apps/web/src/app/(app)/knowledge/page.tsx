"use client";
import Link from "next/link";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Badge, Card, CardBody, EmptyState, Input } from "@worknest/ui";
import { api } from "@/lib/api";

interface Article {
  id: string;
  slug: string;
  title: string;
  status: "draft" | "published" | "archived";
  updatedAt: string;
  category: { name: string } | null;
}

const STATUS_TONE: Record<string, "neutral" | "success" | "warning"> = {
  draft: "neutral",
  published: "success",
  archived: "warning",
};

export default function KnowledgePage() {
  const [q, setQ] = useState("");
  const articles = useQuery({
    queryKey: ["knowledge-articles", q],
    queryFn: () =>
      api<Article[]>(`/knowledge/articles${q ? `?q=${encodeURIComponent(q)}` : ""}`),
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Knowledge base</h1>
          <p className="text-sm text-slate-500">Internal docs, runbooks, and guides.</p>
        </div>
        <Link href="/knowledge/new" className="text-sm text-brand-700 hover:underline">
          New article →
        </Link>
      </div>

      <Input
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder="Search articles…"
        className="max-w-md"
      />

      {articles.data && articles.data.length > 0 ? (
        <ul className="space-y-3">
          {articles.data.map((a) => (
            <li key={a.id}>
              <Link href={`/knowledge/${a.slug}`}>
                <Card className="transition hover:border-slate-300">
                  <CardBody>
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-base font-semibold">{a.title}</h3>
                        <p className="mt-1 text-xs text-slate-500">
                          {a.category?.name ?? "Uncategorized"} · updated{" "}
                          {new Date(a.updatedAt).toLocaleDateString()}
                        </p>
                      </div>
                      <Badge tone={STATUS_TONE[a.status]}>{a.status}</Badge>
                    </div>
                  </CardBody>
                </Card>
              </Link>
            </li>
          ))}
        </ul>
      ) : (
        <EmptyState
          title="No articles yet"
          description="Write your first internal doc to share knowledge with the team."
        />
      )}
    </div>
  );
}
