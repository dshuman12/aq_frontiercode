"use client";
import { useQuery } from "@tanstack/react-query";
import { Badge, Card, CardBody, DataTable, EmptyState } from "@worknest/ui";
import { api } from "@/lib/api";

interface Item {
  id: string;
  sku: string;
  name: string;
  unit: string;
  qty: number;
  reorderPoint: number;
}

export default function InventoryPage() {
  const list = useQuery({ queryKey: ["inventory"], queryFn: () => api<Item[]>("/inventory") });
  const low = useQuery({ queryKey: ["inventory", "low"], queryFn: () => api<Item[]>("/inventory/low-stock") });

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Inventory</h1>

      {(low.data ?? []).length > 0 && (
        <Card className="border-amber-300 bg-amber-50">
          <CardBody>
            <p className="text-sm">⚠️ {low.data!.length} item{low.data!.length === 1 ? "" : "s"} below reorder point.</p>
          </CardBody>
        </Card>
      )}

      {list.isLoading ? <Card><CardBody>Loading…</CardBody></Card> : !list.data?.length ? (
        <EmptyState title="No inventory yet" description="Track stock levels for consumables and supplies." />
      ) : (
        <DataTable
          rows={list.data}
          keyOf={(i) => i.id}
          columns={[
            { key: "sku", header: "SKU", cell: (i) => <Badge variant="outline">{i.sku}</Badge> },
            { key: "name", header: "Name", cell: (i) => i.name },
            { key: "qty", header: "On hand", cell: (i) => `${i.qty} ${i.unit}` },
            { key: "reorder", header: "Reorder at", cell: (i) => `${i.reorderPoint} ${i.unit}` },
            {
              key: "status",
              header: "",
              cell: (i) =>
                i.qty <= i.reorderPoint ? (
                  <Badge variant="warning">low</Badge>
                ) : (
                  <Badge variant="success">ok</Badge>
                ),
            },
          ]}
        />
      )}
    </div>
  );
}
