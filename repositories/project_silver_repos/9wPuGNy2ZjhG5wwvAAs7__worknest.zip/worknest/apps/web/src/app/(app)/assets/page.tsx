"use client";
import { useQuery } from "@tanstack/react-query";
import { Badge, Card, CardBody, DataTable, EmptyState } from "@worknest/ui";
import { api } from "@/lib/api";

interface Asset {
  id: string;
  tag: string;
  name: string;
  status: string;
  serialNumber?: string;
  warrantyEndsAt?: string;
}

export default function AssetsPage() {
  const list = useQuery({ queryKey: ["assets"], queryFn: () => api<Asset[]>("/assets") });
  const expiring = useQuery({
    queryKey: ["assets", "warranty-expiring"],
    queryFn: () => api<Asset[]>("/assets/warranty-expiring?days=30"),
  });

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Assets</h1>

      {(expiring.data ?? []).length > 0 && (
        <Card className="border-amber-300 bg-amber-50">
          <CardBody>
            <p className="text-sm">
              ⚠️ {expiring.data!.length} asset{expiring.data!.length === 1 ? "" : "s"} have warranties expiring in the next 30 days.
            </p>
          </CardBody>
        </Card>
      )}

      {list.isLoading ? <Card><CardBody>Loading…</CardBody></Card> : !list.data?.length ? (
        <EmptyState title="No assets yet" description="Register your hardware to track ownership, location, and warranty." />
      ) : (
        <DataTable
          rows={list.data}
          keyOf={(a) => a.id}
          columns={[
            { key: "tag", header: "Tag", cell: (a) => <Badge variant="outline">{a.tag}</Badge> },
            { key: "name", header: "Name", cell: (a) => a.name },
            { key: "serial", header: "Serial #", cell: (a) => a.serialNumber ?? "—" },
            { key: "status", header: "Status", cell: (a) => <Badge>{a.status}</Badge> },
            {
              key: "warranty",
              header: "Warranty ends",
              cell: (a) => a.warrantyEndsAt ? new Date(a.warrantyEndsAt).toLocaleDateString() : <span className="text-slate-400">—</span>,
            },
          ]}
        />
      )}
    </div>
  );
}
