import { test, expect } from "@playwright/test";

test.describe("auth", () => {
  test("redirects unauthenticated users to login", async ({ page }) => {
    await page.goto("/dashboard");
    await expect(page).toHaveURL(/auth\/login/);
  });

  test("rejects invalid credentials", async ({ page }) => {
    await page.goto("/auth/login");
    await page.getByLabel("Email").fill("nope@nope.test");
    await page.getByLabel("Password").fill("wrongpass!ABCDEF");
    await page.getByRole("button", { name: /sign in/i }).click();
    await expect(page.getByText(/invalid|incorrect|wrong/i)).toBeVisible();
  });

  test("logs in with the demo account", async ({ page }) => {
    await page.goto("/auth/login");
    await page.getByLabel("Email").fill(process.env.E2E_DEMO_EMAIL ?? "alex@worknest-demo.test");
    await page.getByLabel("Password").fill(process.env.E2E_DEMO_PASSWORD ?? "demo-password-change-me");
    await page.getByRole("button", { name: /sign in/i }).click();
    await expect(page).toHaveURL(/dashboard/);
  });
});
