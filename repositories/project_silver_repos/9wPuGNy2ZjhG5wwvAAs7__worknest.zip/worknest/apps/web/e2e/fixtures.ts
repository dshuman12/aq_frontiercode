import { test as base } from "@playwright/test";

const DEMO_EMAIL = process.env.E2E_DEMO_EMAIL ?? "alex@worknest-demo.test";
const DEMO_PASSWORD = process.env.E2E_DEMO_PASSWORD ?? "demo-password-change-me";

export const test = base.extend<{ loggedInPage: import("@playwright/test").Page }>({
  loggedInPage: async ({ page }, use) => {
    await page.goto("/auth/login");
    await page.getByLabel("Email").fill(DEMO_EMAIL);
    await page.getByLabel("Password").fill(DEMO_PASSWORD);
    await Promise.all([
      page.waitForURL(/dashboard/),
      page.getByRole("button", { name: /sign in/i }).click(),
    ]);
    await use(page);
  },
});

export { expect } from "@playwright/test";
