import { test, expect } from "./fixtures";

test("tickets page renders the ticket queue", async ({ loggedInPage: page }) => {
  await page.goto("/tickets");
  await expect(page.getByRole("heading", { name: /tickets/i })).toBeVisible();
});

test("ticket detail allows posting a reply", async ({ loggedInPage: page }) => {
  await page.goto("/tickets");
  const firstRow = page.locator("table tbody tr").first();
  await firstRow.getByRole("link").click();
  await page.getByPlaceholder(/reply or note/i).fill("E2E reply");
  await page.getByRole("button", { name: /^reply$/i }).click();
  await expect(page.getByText("E2E reply")).toBeVisible();
});
