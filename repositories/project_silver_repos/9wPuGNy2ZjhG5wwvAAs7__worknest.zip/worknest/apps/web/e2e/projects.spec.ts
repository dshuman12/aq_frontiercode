import { test, expect } from "./fixtures";

test.describe("projects", () => {
  test("lists projects from the demo seed", async ({ loggedInPage: page }) => {
    await page.goto("/projects");
    await expect(page.getByRole("heading", { name: /projects/i })).toBeVisible();
    await expect(page.getByText("Q1 Launch")).toBeVisible();
  });

  test("creates a new project from the modal", async ({ loggedInPage: page }) => {
    await page.goto("/projects");
    await page.getByRole("button", { name: /new project/i }).click();
    const stamp = Date.now().toString().slice(-5);
    await page.getByLabel("Name").fill(`E2E Project ${stamp}`);
    await page.getByLabel("Key").fill("E2E");
    await page.getByRole("button", { name: /^create$/i }).click();
    await expect(page.getByText(/project created/i)).toBeVisible();
  });

  test("project detail shows kanban board", async ({ loggedInPage: page }) => {
    await page.goto("/projects");
    await page.locator("table tbody tr").first().getByRole("link").click();
    for (const col of ["Backlog", "In progress", "Done"]) {
      await expect(page.getByText(col)).toBeVisible();
    }
  });
});
