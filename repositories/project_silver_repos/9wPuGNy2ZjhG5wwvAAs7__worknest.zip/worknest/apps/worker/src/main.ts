import { logger } from "@worknest/logger";
import { startEmailWorker } from "./queues/email.queue";
import { startNotificationWorker } from "./queues/notification.queue";
import { startApprovalWorker } from "./queues/approval.queue";
import { startTicketWorker } from "./queues/ticket.queue";
import { startWebhookWorker } from "./queues/webhook.queue";
import { startReportWorker } from "./queues/report.queue";
import { startBillingWorker } from "./queues/billing.queue";
import { startMaintenanceWorker } from "./queues/maintenance.queue";
import { slaQueue, startSlaWorker } from "./queues/sla.queue";
import { startAutomationWorker } from "./queues/automation.queue";
import { recurringQueue, startRecurringWorker } from "./queues/recurring.queue";
import "./processors/automation.actions.set-status";
import "./processors/automation.actions.assign";
import "./processors/automation.actions.notify";
import "./processors/automation.actions.webhook";
import "./processors/automation.actions.priority";
import "./processors/automation.actions.comment";

const log = logger("worker/main");

async function main() {
  log.info("WorkNest worker booting");
  const workers = [
    startEmailWorker(),
    startNotificationWorker(),
    startApprovalWorker(),
    startTicketWorker(),
    startWebhookWorker(),
    startReportWorker(),
    startBillingWorker(),
    startMaintenanceWorker(),
    startSlaWorker(),
    startAutomationWorker(),
    startRecurringWorker(),
  ];

  // Recurring tick every 10 minutes — granularity matches "hourly is
  // good enough" cadences at minimum cost.
  await recurringQueue.add(
    "recurring-tick",
    { kind: "tick" },
    { repeat: { pattern: "*/10 * * * *" }, removeOnComplete: 50 },
  );

  // SLA sweep every 2 minutes — cheap, idempotent.
  await slaQueue.add(
    "sla-sweep",
    { kind: "sweep" },
    { repeat: { pattern: "*/2 * * * *" }, removeOnComplete: 50 },
  );

  const shutdown = async (signal: string) => {
    log.info({ signal }, "shutting down");
    for (const w of workers) {
      try {
        await w.close();
      } catch (err) {
        log.error({ err }, "worker close failed");
      }
    }
    process.exit(0);
  };

  process.on("SIGINT", () => shutdown("SIGINT"));
  process.on("SIGTERM", () => shutdown("SIGTERM"));
}

main().catch((err) => {
  log.error({ err }, "boot failed");
  process.exit(1);
});
