import { Job, Queue, Worker } from "bullmq";
import { createRedisConnection } from "../redis";
import { processReport } from "../processors/report.processor";

const QUEUE = "report";
const connection = createRedisConnection();

export const reportQueue = new Queue(QUEUE, { connection });

export interface ReportJobData {
  kind: "weekly-digest" | "asset-audit" | "ticket-sla";
  organizationId?: string;
}

export function startReportWorker(): Worker<ReportJobData> {
  return new Worker<ReportJobData>(
    QUEUE,
    async (job: Job<ReportJobData>) => processReport(job.data),
    { connection, concurrency: 2 },
  );
}
