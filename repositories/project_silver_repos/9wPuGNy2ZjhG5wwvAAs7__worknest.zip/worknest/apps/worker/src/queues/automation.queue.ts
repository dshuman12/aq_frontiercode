import { Job, Queue, Worker } from "bullmq";
import { createRedisConnection } from "../redis";
import { processAutomation } from "../processors/automation.processor";

const QUEUE = "automation";
const connection = createRedisConnection();

export const automationQueue = new Queue(QUEUE, { connection });

export interface AutomationJobData {
  ruleId: string;
  resource: string;
  resourceId: string;
  trigger: string;
  payload: Record<string, unknown>;
}

export function startAutomationWorker(): Worker<AutomationJobData> {
  return new Worker<AutomationJobData>(
    QUEUE,
    async (job: Job<AutomationJobData>) => processAutomation(job.data),
    { connection, concurrency: 4 },
  );
}
