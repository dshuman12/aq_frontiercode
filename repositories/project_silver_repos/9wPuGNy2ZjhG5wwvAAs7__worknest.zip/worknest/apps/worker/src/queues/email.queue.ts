import { Job, Queue, Worker } from "bullmq";
import { createRedisConnection } from "../redis";
import { processEmail } from "../processors/email.processor";

const QUEUE = "email";
const connection = createRedisConnection();

export const emailQueue = new Queue(QUEUE, { connection });

export interface EmailJobData {
  template: string;
  to: { email: string; name?: string };
  props: Record<string, unknown>;
  organizationId: string;
}

export function startEmailWorker(): Worker<EmailJobData> {
  return new Worker<EmailJobData>(
    QUEUE,
    async (job: Job<EmailJobData>) => processEmail(job.data),
    {
      connection,
      concurrency: Number(process.env.WORKER_CONCURRENCY_EMAIL ?? 5),
      attempts: 5,
      backoff: { type: "exponential", delay: 30_000 },
    } as never,
  );
}
