import { Job, Queue, Worker } from "bullmq";
import { createRedisConnection } from "../redis";
import { processNotification } from "../processors/notification.processor";

const QUEUE = "notification";
const connection = createRedisConnection();

export const notificationQueue = new Queue(QUEUE, { connection });

export interface NotificationJobData {
  organizationId: string;
  recipients: string[];
  kind: string;
  title: string;
  body?: string;
  link?: string;
  severity?: "info" | "warning" | "critical";
  emailTemplate?: string;
  emailProps?: Record<string, unknown>;
}

export function startNotificationWorker(): Worker<NotificationJobData> {
  return new Worker<NotificationJobData>(
    QUEUE,
    async (job: Job<NotificationJobData>) => processNotification(job.data),
    {
      connection,
      concurrency: Number(process.env.WORKER_CONCURRENCY_NOTIFICATION ?? 10),
    },
  );
}
