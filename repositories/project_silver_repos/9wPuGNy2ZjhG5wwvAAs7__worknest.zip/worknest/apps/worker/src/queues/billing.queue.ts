import { Job, Queue, Worker } from "bullmq";
import { createRedisConnection } from "../redis";
import { processBillingEvent } from "../processors/billing.processor";

const QUEUE = "billing";
const connection = createRedisConnection();

export const billingQueue = new Queue(QUEUE, { connection });

export interface BillingJobData {
  kind: "sync-usage" | "retry-failed-charge";
  organizationId: string;
}

export function startBillingWorker(): Worker<BillingJobData> {
  return new Worker<BillingJobData>(
    QUEUE,
    async (job: Job<BillingJobData>) => processBillingEvent(job.data),
    { connection, concurrency: 2 },
  );
}
