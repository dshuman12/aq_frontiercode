import { Job, Queue, Worker } from "bullmq";
import { createRedisConnection } from "../redis";
import { processMaintenance } from "../processors/maintenance.processor";

const QUEUE = "maintenance";
const connection = createRedisConnection();

export const maintenanceQueue = new Queue(QUEUE, { connection });

export interface MaintenanceJobData {
  kind: "expire-sessions" | "scan-warranties" | "scan-low-stock" | "purge-soft-deleted";
}

export function startMaintenanceWorker(): Worker<MaintenanceJobData> {
  return new Worker<MaintenanceJobData>(
    QUEUE,
    async (job: Job<MaintenanceJobData>) => processMaintenance(job.data),
    { connection, concurrency: 1 },
  );
}
