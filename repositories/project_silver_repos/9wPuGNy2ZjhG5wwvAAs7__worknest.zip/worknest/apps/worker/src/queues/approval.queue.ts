import { Job, Queue, Worker } from "bullmq";
import { createRedisConnection } from "../redis";
import { processApprovalEscalation } from "../processors/approval.processor";

const QUEUE = "approval";
const connection = createRedisConnection();

export const approvalQueue = new Queue(QUEUE, { connection });

export interface ApprovalJobData {
  decisionId: string;
  organizationId: string;
}

export function startApprovalWorker(): Worker<ApprovalJobData> {
  return new Worker<ApprovalJobData>(
    QUEUE,
    async (job: Job<ApprovalJobData>) => processApprovalEscalation(job.data),
    { connection, concurrency: 5 },
  );
}
