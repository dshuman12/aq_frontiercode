import { Job, Queue, Worker } from "bullmq";
import { createRedisConnection } from "../redis";
import { processRecurringTick } from "../processors/recurring.processor";

const QUEUE = "recurring";
const connection = createRedisConnection();

export const recurringQueue = new Queue(QUEUE, { connection });

export interface RecurringJobData {
  kind: "tick";
}

export function startRecurringWorker(): Worker<RecurringJobData> {
  return new Worker<RecurringJobData>(
    QUEUE,
    async (job: Job<RecurringJobData>) => processRecurringTick(job.data),
    { connection, concurrency: 1 },
  );
}
