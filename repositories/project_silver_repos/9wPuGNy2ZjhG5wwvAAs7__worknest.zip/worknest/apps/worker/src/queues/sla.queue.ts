import { Job, Queue, Worker } from "bullmq";
import { createRedisConnection } from "../redis";
import { processSlaSweep } from "../processors/sla.processor";

const QUEUE = "sla";
const connection = createRedisConnection();

export const slaQueue = new Queue(QUEUE, { connection });

export interface SlaJobData {
  kind: "sweep";
  organizationId?: string;
}

export function startSlaWorker(): Worker<SlaJobData> {
  return new Worker<SlaJobData>(
    QUEUE,
    async (job: Job<SlaJobData>) => processSlaSweep(job.data),
    { connection, concurrency: 1 },
  );
}
