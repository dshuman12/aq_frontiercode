import { Job, Queue, Worker } from "bullmq";
import { createRedisConnection } from "../redis";
import { processWebhookDelivery } from "../processors/webhook.processor";

const QUEUE = "webhook";
const connection = createRedisConnection();

export const webhookQueue = new Queue(QUEUE, { connection });

export interface WebhookJobData {
  webhookId: string;
  event: string;
  payload: unknown;
}

export function startWebhookWorker(): Worker<WebhookJobData> {
  return new Worker<WebhookJobData>(
    QUEUE,
    async (job: Job<WebhookJobData>) => processWebhookDelivery(job.data, job.attemptsMade),
    {
      connection,
      concurrency: Number(process.env.WORKER_CONCURRENCY_WEBHOOK ?? 20),
      // Up to 5 attempts with explicit backoff
      attempts: 5,
      backoff: { type: "exponential", delay: 30_000 },
    } as never,
  );
}
