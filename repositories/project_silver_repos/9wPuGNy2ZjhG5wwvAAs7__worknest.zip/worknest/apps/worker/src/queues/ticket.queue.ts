import { Job, Queue, Worker } from "bullmq";
import { createRedisConnection } from "../redis";
import { processTicketSla } from "../processors/ticket.processor";

const QUEUE = "ticket";
const connection = createRedisConnection();

export const ticketQueue = new Queue(QUEUE, { connection });

export interface TicketJobData {
  kind: "sla-scan" | "due-reminder";
  organizationId?: string;
}

export function startTicketWorker(): Worker<TicketJobData> {
  return new Worker<TicketJobData>(
    QUEUE,
    async (job: Job<TicketJobData>) => processTicketSla(job.data),
    { connection, concurrency: 1 },
  );
}
