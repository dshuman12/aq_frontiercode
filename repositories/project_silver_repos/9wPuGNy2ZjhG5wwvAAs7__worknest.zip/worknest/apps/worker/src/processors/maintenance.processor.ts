import { prisma } from "@worknest/database";
import { logger } from "@worknest/logger";
import { notificationQueue } from "../queues/notification.queue";
import type { MaintenanceJobData } from "../queues/maintenance.queue";

const log = logger("worker/maintenance");

export async function processMaintenance(job: MaintenanceJobData): Promise<{ ok: true }> {
  switch (job.kind) {
    case "expire-sessions":
      await expireSessions();
      break;
    case "scan-warranties":
      await scanWarranties();
      break;
    case "scan-low-stock":
      await scanLowStock();
      break;
    case "purge-soft-deleted":
      log.info("purge step is a no-op until soft-delete is wired in");
      break;
  }
  return { ok: true };
}

async function expireSessions() {
  const result = await prisma.session.updateMany({
    where: { revokedAt: null, expiresAt: { lt: new Date() } },
    data: { revokedAt: new Date() },
  });
  log.info({ count: result.count }, "expired sessions");
}

async function scanWarranties() {
  const cutoff = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
  const expiring = await prisma.asset.findMany({
    where: {
      warrantyEndsAt: { lte: cutoff, gte: new Date() },
      status: { not: "retired" },
    },
    include: { organization: true },
  });
  for (const asset of expiring) {
    const owner = await prisma.organizationMember.findFirst({
      where: { organizationId: asset.organizationId, role: "owner" },
    });
    if (!owner) continue;
    await notificationQueue.add("dispatch", {
      organizationId: asset.organizationId,
      recipients: [owner.userId],
      kind: "asset.warranty",
      title: `Warranty expiring: ${asset.name}`,
      body: `Warranty ends ${asset.warrantyEndsAt?.toDateString() ?? "soon"}.`,
      link: `/assets/${asset.id}`,
      severity: "warning",
      emailTemplate: "asset-warranty",
      emailProps: {
        recipientName: "Admin",
        assetName: asset.name,
        serialNumber: asset.serialNumber,
        warrantyEndsLabel: asset.warrantyEndsAt?.toDateString() ?? "—",
        daysRemaining: Math.ceil((asset.warrantyEndsAt!.getTime() - Date.now()) / 86_400_000),
        assetUrl: `${process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000"}/assets/${asset.id}`,
      },
    });
  }
  log.info({ count: expiring.length }, "warranty scan");
}

async function scanLowStock() {
  const items = await prisma.inventoryItem.findMany({});
  const low = items.filter((i) => i.qty <= i.reorderPoint);
  // Group by organization and notify the owner once per scan with the full list.
  const byOrg = new Map<string, typeof low>();
  for (const i of low) {
    const list = byOrg.get(i.organizationId) ?? [];
    list.push(i);
    byOrg.set(i.organizationId, list);
  }
  for (const [organizationId, list] of byOrg) {
    const owner = await prisma.organizationMember.findFirst({
      where: { organizationId, role: "owner" },
    });
    if (!owner) continue;
    await notificationQueue.add("dispatch", {
      organizationId,
      recipients: [owner.userId],
      kind: "inventory.low_stock",
      title: `${list.length} item${list.length === 1 ? "" : "s"} below reorder point`,
      severity: "warning",
      emailTemplate: "inventory-low-stock",
      emailProps: {
        recipientName: "Admin",
        organizationName: "your team",
        inventoryUrl: `${process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000"}/inventory`,
        items: list.map((i) => ({
          sku: i.sku,
          name: i.name,
          onHand: i.qty,
          reorderPoint: i.reorderPoint,
          unit: i.unit,
        })),
      },
    });
  }
  log.info({ orgCount: byOrg.size, total: low.length }, "low-stock scan");
}
