import { prisma } from "@worknest/database";
import { registerAutomationAction } from "./automation.processor";

const SYSTEM_USER_ID = "automation"; // sentinel; consumers display as "Automation"

registerAutomationAction("comment", async (action: { body: string }, ctx) => {
  if (ctx.resource === "task") {
    await prisma.taskComment.create({
      data: { taskId: ctx.resourceId, authorId: SYSTEM_USER_ID, body: action.body },
    });
    return { commented: true };
  }
  if (ctx.resource === "ticket") {
    await prisma.ticketComment.create({
      data: { ticketId: ctx.resourceId, authorId: SYSTEM_USER_ID, body: action.body, isInternal: true },
    });
    return { commented: true };
  }
  throw new Error(`comment not supported for ${ctx.resource}`);
});
