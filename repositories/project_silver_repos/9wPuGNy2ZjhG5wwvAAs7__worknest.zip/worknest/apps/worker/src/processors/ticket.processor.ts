import { prisma } from "@worknest/database";
import { logger } from "@worknest/logger";
import { notificationQueue } from "../queues/notification.queue";
import type { TicketJobData } from "../queues/ticket.queue";

const log = logger("worker/ticket");

const HIGH_PRIORITY_HOURS = 4;
const URGENT_HOURS = 1;

export async function processTicketSla(job: TicketJobData): Promise<{ alerted: number }> {
  if (job.kind !== "sla-scan") return { alerted: 0 };

  const now = new Date();
  const where: Record<string, unknown> = {
    status: { in: ["open", "pending", "in_progress"] },
  };
  if (job.organizationId) where.organizationId = job.organizationId;

  const tickets = await prisma.ticket.findMany({ where });

  let alerted = 0;
  for (const t of tickets) {
    const ageHours = (now.getTime() - t.createdAt.getTime()) / 3_600_000;
    const breach =
      (t.priority === "urgent" && ageHours > URGENT_HOURS) ||
      (t.priority === "high" && ageHours > HIGH_PRIORITY_HOURS);
    if (!breach) continue;
    await notificationQueue.add("dispatch", {
      organizationId: t.organizationId,
      recipients: t.assigneeId ? [t.assigneeId] : [],
      kind: "ticket.escalated",
      title: `${t.key} is overdue`,
      body: `Ticket has been ${t.status} for ${ageHours.toFixed(1)} hours.`,
      link: `/tickets/${t.id}`,
      severity: "critical",
    });
    alerted++;
  }
  log.info({ scanned: tickets.length, alerted }, "ticket sla scan");
  return { alerted };
}
