import { webhookQueue } from "../queues/webhook.queue";
import { registerAutomationAction } from "./automation.processor";

registerAutomationAction(
  "webhook",
  async (action: { webhookId: string; eventName: string }, ctx) => {
    await webhookQueue.add("deliver", {
      webhookId: action.webhookId,
      event: action.eventName,
      payload: {
        resource: ctx.resource,
        resourceId: ctx.resourceId,
        ...ctx.payload,
      },
    });
    return { dispatched: true };
  },
);
