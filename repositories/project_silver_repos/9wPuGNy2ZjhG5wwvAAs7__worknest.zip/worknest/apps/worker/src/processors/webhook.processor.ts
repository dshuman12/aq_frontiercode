import { createHmac } from "node:crypto";
import { prisma } from "@worknest/database";
import { logger } from "@worknest/logger";
import type { WebhookJobData } from "../queues/webhook.queue";

const log = logger("worker/webhook");

export async function processWebhookDelivery(job: WebhookJobData, attemptsMade: number): Promise<{ status: number }> {
  const hook = await prisma.webhookEndpoint.findUnique({ where: { id: job.webhookId } });
  if (!hook || !hook.enabled) {
    return { status: 0 };
  }

  const body = JSON.stringify({
    event: job.event,
    payload: job.payload,
    deliveredAt: new Date().toISOString(),
  });
  // We hash the secret but don't store the plaintext. For signing, we
  // need a stable secret — in production we'd store this in a KMS-encrypted
  // column. For now, the secretHash is used directly as the signing key.
  const signature = createHmac("sha256", hook.secretHash).update(body).digest("hex");

  let status = 0;
  let errorMessage: string | undefined;
  try {
    const res = await fetch(hook.url, {
      method: "POST",
      body,
      headers: {
        "content-type": "application/json",
        "x-worknest-signature": signature,
        "x-worknest-event": job.event,
        "x-worknest-attempt": String(attemptsMade + 1),
      },
    });
    status = res.status;
  } catch (err) {
    errorMessage = (err as Error).message;
    status = 0;
  }

  const succeeded = status >= 200 && status < 300;
  await prisma.webhookDelivery.create({
    data: {
      webhookId: hook.id,
      event: job.event,
      payload: job.payload as never,
      status: status > 0 ? status : null,
      attempts: attemptsMade + 1,
      succeeded,
      errorMessage,
    },
  });

  if (succeeded) {
    await prisma.webhookEndpoint.update({
      where: { id: hook.id },
      data: { lastDeliveredAt: new Date(), failureCount: 0 },
    });
  } else {
    await prisma.webhookEndpoint.update({
      where: { id: hook.id },
      data: { failureCount: { increment: 1 } },
    });
    if (attemptsMade >= 4) {
      // Will be the 5th and final attempt by BullMQ; auto-disable.
      await prisma.webhookEndpoint.update({
        where: { id: hook.id },
        data: { enabled: false },
      });
      log.warn({ webhookId: hook.id }, "webhook disabled after 5 consecutive failures");
    }
    throw new Error(errorMessage ?? `webhook returned ${status}`);
  }
  return { status };
}
