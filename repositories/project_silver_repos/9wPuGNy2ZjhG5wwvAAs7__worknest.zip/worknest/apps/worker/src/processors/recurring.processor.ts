/**
 * Recurring-task tick. Walks RecurringTask rows whose nextRunAt has
 * passed and materializes a task for each, advancing the schedule.
 *
 * The math is duplicated here from `apps/api/src/modules/recurring-tasks/recurrence`
 * because the worker is a separate deploy artifact and we don't pull
 * the API package at build time. Both files are short; if they
 * diverge a smoke test will catch it.
 */
import { prisma } from "@worknest/database";
import { logger } from "@worknest/logger";
import type { RecurringJobData } from "../queues/recurring.queue";

const log = logger("worker/recurring");
const SYSTEM_USER_ID = "automation";

export async function processRecurringTick(_job: RecurringJobData): Promise<{ created: number }> {
  const due = await prisma.recurringTask.findMany({
    where: { active: true, nextRunAt: { lte: new Date() } },
    take: 200,
  });
  let created = 0;
  for (const r of due) {
    const next = await prisma.project.update({
      where: { id: r.projectId },
      data: { nextTaskNumber: { increment: 1 } },
      select: { key: true, nextTaskNumber: true },
    });
    await prisma.task.create({
      data: {
        projectId: r.projectId,
        title: r.name,
        createdById: SYSTEM_USER_ID,
        key: `${next.key}-${next.nextTaskNumber - 1}`,
        position: Date.now(),
      },
    });
    const newNext = computeNext(new Date(), r);
    await prisma.recurringTask.update({
      where: { id: r.id },
      data: { lastRunAt: new Date(), nextRunAt: newNext },
    });
    created += 1;
  }
  log.info({ created, scanned: due.length }, "recurring_tick_done");
  return { created };
}

function computeNext(
  from: Date,
  cad: { cadence: string; interval: number; daysOfWeek: number[]; dayOfMonth: number | null; hourOfDay: number },
): Date {
  const base = new Date(from.getTime());
  base.setUTCMinutes(0, 0, 0);
  base.setUTCHours(cad.hourOfDay);

  if (cad.cadence === "daily") {
    base.setUTCDate(base.getUTCDate() + Math.max(1, cad.interval));
    return base;
  }
  if (cad.cadence === "weekly") {
    if (cad.daysOfWeek.length === 0) {
      base.setUTCDate(base.getUTCDate() + 7 * Math.max(1, cad.interval));
      return base;
    }
    for (let added = 1; added <= 7 * cad.interval + 7; added++) {
      const d = new Date(base.getTime());
      d.setUTCDate(d.getUTCDate() + added);
      if (cad.daysOfWeek.includes(d.getUTCDay())) return d;
    }
  }
  // monthly
  const day = cad.dayOfMonth ?? base.getUTCDate();
  const target = new Date(base.getTime());
  target.setUTCMonth(target.getUTCMonth() + Math.max(1, cad.interval));
  const lastOfMonth = new Date(
    Date.UTC(target.getUTCFullYear(), target.getUTCMonth() + 1, 0),
  ).getUTCDate();
  target.setUTCDate(Math.min(day, lastOfMonth));
  return target;
}
