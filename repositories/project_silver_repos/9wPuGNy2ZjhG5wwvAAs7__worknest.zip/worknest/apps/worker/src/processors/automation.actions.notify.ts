import { notificationQueue } from "../queues/notification.queue";
import { registerAutomationAction } from "./automation.processor";

registerAutomationAction(
  "notify",
  async (
    action: { userIds: string[]; title: string; body?: string },
    ctx,
  ) => {
    await notificationQueue.add("dispatch", {
      organizationId: ctx.organizationId,
      recipients: action.userIds,
      kind: `automation.${ctx.resource}`,
      title: action.title,
      body: action.body,
      severity: "info",
    });
    return { recipients: action.userIds.length };
  },
);
