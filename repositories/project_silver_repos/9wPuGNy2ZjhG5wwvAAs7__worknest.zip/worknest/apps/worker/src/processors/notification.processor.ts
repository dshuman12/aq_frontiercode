import { prisma } from "@worknest/database";
import { logger } from "@worknest/logger";
import { emailQueue } from "../queues/email.queue";
import { webhookQueue } from "../queues/webhook.queue";
import type { NotificationJobData } from "../queues/notification.queue";

const log = logger("worker/notification");

export async function processNotification(job: NotificationJobData): Promise<{ delivered: number }> {
  let delivered = 0;
  for (const userId of job.recipients) {
    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user) continue;
    const prefs = await prisma.notificationPreference.findMany({ where: { userId } });

    // In-app — always written.
    await prisma.notification.create({
      data: {
        organizationId: job.organizationId,
        userId,
        kind: job.kind,
        title: job.title,
        body: job.body,
        link: job.link,
        severity: job.severity ?? "info",
      },
    });
    delivered++;

    // Email
    const emailEnabled = !prefs.find((p) => p.kind === job.kind && p.channel === "email" && !p.enabled);
    if (emailEnabled && job.emailTemplate) {
      await emailQueue.add("send", {
        template: job.emailTemplate,
        to: { email: user.email, name: user.name },
        props: job.emailProps ?? {},
        organizationId: job.organizationId,
      });
    }
  }

  // Webhook fan-out.
  const hooks = await prisma.webhookEndpoint.findMany({
    where: { organizationId: job.organizationId, enabled: true },
  });
  for (const hook of hooks) {
    if (!hook.kinds.includes(job.kind)) continue;
    await webhookQueue.add("deliver", {
      webhookId: hook.id,
      event: job.kind,
      payload: { title: job.title, body: job.body, link: job.link, severity: job.severity },
    });
  }

  log.info({ kind: job.kind, recipients: job.recipients.length, delivered }, "notification fanned out");
  return { delivered };
}
