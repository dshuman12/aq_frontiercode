import { prisma } from "@worknest/database";
import { logger } from "@worknest/logger";
import { notificationQueue } from "../queues/notification.queue";
import type { ApprovalJobData } from "../queues/approval.queue";

const log = logger("worker/approval");

export async function processApprovalEscalation(job: ApprovalJobData): Promise<{ escalated: boolean }> {
  const decision = await prisma.approvalDecision.findUnique({
    where: { id: job.decisionId },
    include: { step: true, workflow: true },
  });
  if (!decision || decision.status !== "pending") return { escalated: false };

  const escalateAfter = decision.step.escalateAfterMinutes;
  if (!escalateAfter) return { escalated: false };
  const elapsedMin = (Date.now() - decision.createdAt.getTime()) / 60_000;
  if (elapsedMin < escalateAfter) return { escalated: false };

  await prisma.approvalDecision.update({
    where: { id: decision.id },
    data: { status: "escalated", reason: "auto_escalated", decidedAt: new Date() },
  });
  await notificationQueue.add("dispatch", {
    organizationId: job.organizationId,
    recipients: [decision.approverId],
    kind: "approval.pending",
    title: "Your approval was escalated",
    body: `${decision.step.name} was auto-escalated after ${escalateAfter} minutes.`,
    severity: "warning",
  });
  log.warn({ decisionId: decision.id }, "approval escalated");
  return { escalated: true };
}
