import { logger } from "@worknest/logger";
import { renderByKey, SmtpTransport, LogTransport, EmailTransport } from "@worknest/email";
import { prisma } from "@worknest/database";
import type { EmailJobData } from "../queues/email.queue";

const log = logger("worker/email");

let transport: EmailTransport | null = null;
function getTransport(): EmailTransport {
  if (transport) return transport;
  if (!process.env.SMTP_HOST || process.env.NODE_ENV === "test") {
    transport = new LogTransport();
  } else {
    transport = new SmtpTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT ?? 587),
      user: process.env.SMTP_USER,
      password: process.env.SMTP_PASSWORD,
      fromEmail: process.env.SMTP_FROM_EMAIL ?? "noreply@worknest.local",
      fromName: process.env.SMTP_FROM_NAME ?? "WorkNest",
    });
  }
  return transport;
}

export async function processEmail(job: EmailJobData): Promise<{ messageId: string }> {
  const rendered = renderByKey(job.template, job.props);
  const t = getTransport();
  const result = await t.send({
    to: job.to,
    subject: rendered.subject,
    html: rendered.html,
    text: rendered.text,
    tags: [job.template],
  });
  await prisma.emailLog.create({
    data: {
      organizationId: job.organizationId,
      template: job.template,
      to: job.to.email,
      subject: rendered.subject,
      status: "sent",
      messageId: result.messageId,
      sentAt: new Date(),
    },
  });
  log.info({ template: job.template, to: job.to.email, messageId: result.messageId }, "email sent");
  return { messageId: result.messageId };
}
