import { prisma } from "@worknest/database";
import { registerAutomationAction } from "./automation.processor";

registerAutomationAction("set_priority", async (action: { priority: string }, ctx) => {
  if (ctx.resource === "task") {
    await prisma.task.update({
      where: { id: ctx.resourceId },
      data: { priority: action.priority },
    });
    return { priority: action.priority };
  }
  if (ctx.resource === "ticket") {
    await prisma.ticket.update({
      where: { id: ctx.resourceId },
      data: { priority: action.priority },
    });
    return { priority: action.priority };
  }
  throw new Error(`set_priority not supported for ${ctx.resource}`);
});
