import { prisma } from "@worknest/database";
import { registerAutomationAction } from "./automation.processor";

registerAutomationAction("assign", async (action: { userId: string }, ctx) => {
  if (ctx.resource === "task") {
    await prisma.task.update({ where: { id: ctx.resourceId }, data: { assigneeId: action.userId } });
    return { assigned: action.userId };
  }
  if (ctx.resource === "ticket") {
    await prisma.ticket.update({
      where: { id: ctx.resourceId },
      data: { assigneeId: action.userId },
    });
    return { assigned: action.userId };
  }
  if (ctx.resource === "request") {
    await prisma.requestSubmission.update({
      where: { id: ctx.resourceId },
      data: { assigneeId: action.userId },
    });
    return { assigned: action.userId };
  }
  throw new Error(`assign not supported for ${ctx.resource}`);
});
