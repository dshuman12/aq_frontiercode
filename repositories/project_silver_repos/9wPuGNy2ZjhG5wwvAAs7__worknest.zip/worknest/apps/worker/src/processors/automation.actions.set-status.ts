import { prisma } from "@worknest/database";
import { registerAutomationAction } from "./automation.processor";

registerAutomationAction("set_status", async (action: { status: string }, ctx) => {
  if (ctx.resource === "task") {
    await prisma.task.update({ where: { id: ctx.resourceId }, data: { status: action.status } });
    return { resource: "task", status: action.status };
  }
  if (ctx.resource === "ticket") {
    await prisma.ticket.update({ where: { id: ctx.resourceId }, data: { status: action.status } });
    return { resource: "ticket", status: action.status };
  }
  if (ctx.resource === "request") {
    await prisma.requestSubmission.update({
      where: { id: ctx.resourceId },
      data: { status: action.status },
    });
    return { resource: "request", status: action.status };
  }
  throw new Error(`set_status not supported for ${ctx.resource}`);
});
