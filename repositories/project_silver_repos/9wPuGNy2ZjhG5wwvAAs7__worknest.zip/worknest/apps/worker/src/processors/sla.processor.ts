/**
 * SLA breach sweep. Walks active SlaTimer rows whose due-by has
 * passed without a corresponding "met" timestamp, flips the breach
 * boolean, and enqueues a notification job for the ticket assignee.
 *
 * The flip is idempotent (only false → true), so re-running on a
 * tighter cron just costs reads.
 */
import { prisma } from "@worknest/database";
import { logger } from "@worknest/logger";
import { notificationQueue } from "../queues/notification.queue";
import type { SlaJobData } from "../queues/sla.queue";

const log = logger("worker/sla");

export async function processSlaSweep(job: SlaJobData): Promise<{ scanned: number; breached: number }> {
  if (job.kind !== "sweep") return { scanned: 0, breached: 0 };

  const where: Record<string, unknown> = {
    OR: [
      { breachedFirstResponse: false, firstResponseMetAt: null },
      { breachedResolution: false, resolutionMetAt: null },
    ],
  };
  if (job.organizationId) {
    (where as { ticket?: object }).ticket = { organizationId: job.organizationId };
  }

  const timers = await prisma.slaTimer.findMany({
    where,
    include: {
      ticket: { select: { id: true, organizationId: true, assigneeId: true, key: true } },
    },
    take: 500,
  });

  const now = Date.now();
  let breached = 0;
  for (const t of timers) {
    const updates: Record<string, unknown> = {};
    let alertReason: "first_response" | "resolution" | null = null;
    if (
      !t.breachedFirstResponse &&
      !t.firstResponseMetAt &&
      now > t.firstResponseDueAt.getTime()
    ) {
      updates.breachedFirstResponse = true;
      alertReason = "first_response";
    }
    if (
      !t.breachedResolution &&
      !t.resolutionMetAt &&
      now > t.resolutionDueAt.getTime()
    ) {
      updates.breachedResolution = true;
      alertReason = alertReason ?? "resolution";
    }
    if (Object.keys(updates).length) {
      await prisma.slaTimer.update({ where: { id: t.id }, data: updates });
      breached += 1;
      if (t.ticket.assigneeId) {
        await notificationQueue.add("dispatch", {
          organizationId: t.ticket.organizationId,
          recipients: [t.ticket.assigneeId],
          kind: "ticket.sla_breach",
          title: `SLA breach on ${t.ticket.key}`,
          body: `Reason: ${alertReason}`,
          severity: "warning",
        });
      }
    }
  }
  log.info({ scanned: timers.length, breached }, "sla_sweep_done");
  return { scanned: timers.length, breached };
}
