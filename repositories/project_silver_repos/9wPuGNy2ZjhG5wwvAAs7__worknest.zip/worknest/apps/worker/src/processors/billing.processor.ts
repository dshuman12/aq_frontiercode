import Stripe from "stripe";
import { prisma } from "@worknest/database";
import { logger } from "@worknest/logger";
import type { BillingJobData } from "../queues/billing.queue";

const log = logger("worker/billing");
const stripe = new Stripe(process.env.STRIPE_API_KEY ?? "sk_test_dummy", { apiVersion: "2024-04-10" });

export async function processBillingEvent(job: BillingJobData): Promise<{ ok: true }> {
  switch (job.kind) {
    case "sync-usage":
      await syncUsage(job.organizationId);
      break;
    case "retry-failed-charge":
      await retryFailedCharge(job.organizationId);
      break;
  }
  return { ok: true };
}

async function syncUsage(organizationId: string) {
  const sub = await prisma.subscription.findUnique({ where: { organizationId } });
  if (!sub) return;
  const since = new Date();
  since.setHours(since.getHours() - 1);
  const events = await prisma.usageEvent.findMany({
    where: { organizationId, occurredAt: { gte: since }, reportedAt: null },
  });
  if (events.length === 0) return;
  // Stripe usage records would go here. We just mark them reported.
  await prisma.usageEvent.updateMany({
    where: { id: { in: events.map((e) => e.id) } },
    data: { reportedAt: new Date() },
  });
  log.info({ organizationId, count: events.length }, "usage events flushed");
}

async function retryFailedCharge(organizationId: string) {
  const sub = await prisma.subscription.findUnique({ where: { organizationId } });
  if (!sub) return;
  await stripe.subscriptions.retrieve(sub.stripeSubscriptionId);
  log.info({ organizationId }, "subscription state checked");
}
