import { prisma } from "@worknest/database";
import { logger } from "@worknest/logger";
import { emailQueue } from "../queues/email.queue";
import type { ReportJobData } from "../queues/report.queue";

const log = logger("worker/report");

export async function processReport(job: ReportJobData): Promise<{ ok: true }> {
  switch (job.kind) {
    case "weekly-digest":
      await runWeeklyDigest(job.organizationId);
      break;
    case "asset-audit":
      await runAssetAudit(job.organizationId);
      break;
    case "ticket-sla":
      log.info("ticket sla report deferred to ticket queue");
      break;
  }
  return { ok: true };
}

async function runWeeklyDigest(organizationId?: string) {
  const orgFilter = organizationId ? { id: organizationId } : {};
  const orgs = await prisma.organization.findMany({ where: orgFilter });
  for (const org of orgs) {
    const owner = await prisma.organizationMember.findFirst({
      where: { organizationId: org.id, role: "owner" },
      include: { user: true },
    });
    if (!owner) continue;
    const weekStart = new Date();
    weekStart.setDate(weekStart.getDate() - 7);

    const [completedTasks, openTasks, overdueTasks, ticketsResolved] = await Promise.all([
      prisma.task.count({ where: { project: { organizationId: org.id }, status: "done", completedAt: { gte: weekStart } } }),
      prisma.task.count({ where: { project: { organizationId: org.id }, status: { not: "done" } } }),
      prisma.task.count({ where: { project: { organizationId: org.id }, status: { not: "done" }, dueAt: { lt: new Date() } } }),
      prisma.ticket.count({ where: { organizationId: org.id, resolvedAt: { gte: weekStart } } }),
    ]);

    await emailQueue.add("send", {
      template: "weekly-digest",
      to: { email: owner.user.email, name: owner.user.name },
      props: {
        recipientName: owner.user.name,
        organizationName: org.name,
        weekOfLabel: weekStart.toDateString(),
        dashboardUrl: `${process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000"}/dashboard`,
        metrics: {
          completedTasks,
          openTasks,
          overdueTasks,
          ticketsResolved,
          averageResolutionHours: 0,
        },
        topContributors: [],
      },
      organizationId: org.id,
    });
  }
}

async function runAssetAudit(organizationId?: string) {
  const where: Record<string, unknown> = {
    warrantyEndsAt: { lte: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), gte: new Date() },
    status: { not: "retired" },
  };
  if (organizationId) where.organizationId = organizationId;
  const expiring = await prisma.asset.findMany({ where });
  log.info({ count: expiring.length }, "warranty audit");
}
