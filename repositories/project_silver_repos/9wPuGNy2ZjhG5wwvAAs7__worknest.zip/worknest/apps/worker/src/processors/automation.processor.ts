/**
 * Automation rule executor. Loads the rule, walks the action list,
 * and dispatches each action to a typed handler. Action handlers
 * live alongside in `automation.actions.*.ts` so adding a new
 * action type is a one-file change.
 *
 * We never re-run a rule for the same resource version implicitly;
 * the producer side (feature modules) decides when to enqueue.
 */
import { prisma } from "@worknest/database";
import { logger } from "@worknest/logger";
import type { AutomationJobData } from "../queues/automation.queue";

const log = logger("worker/automation");

interface ActionContext {
  ruleId: string;
  organizationId: string;
  resource: string;
  resourceId: string;
  payload: Record<string, unknown>;
}

const handlers: Record<string, (action: any, ctx: ActionContext) => Promise<unknown>> = {};

export function registerAutomationAction(
  type: string,
  handler: (action: any, ctx: ActionContext) => Promise<unknown>,
): void {
  handlers[type] = handler;
}

export async function processAutomation(job: AutomationJobData): Promise<{ ran: number; failed: number }> {
  const rule = await prisma.automationRule.findUnique({ where: { id: job.ruleId } });
  if (!rule || !rule.active) return { ran: 0, failed: 0 };

  const ctx: ActionContext = {
    ruleId: rule.id,
    organizationId: rule.organizationId,
    resource: job.resource,
    resourceId: job.resourceId,
    payload: job.payload,
  };

  const actions = (rule.actions as any[]) ?? [];
  let ran = 0;
  let failed = 0;
  const outcomes: unknown[] = [];

  for (const action of actions) {
    const handler = handlers[action?.type];
    if (!handler) {
      outcomes.push({ type: action?.type, status: "no_handler" });
      failed += 1;
      continue;
    }
    try {
      const result = await handler(action, ctx);
      outcomes.push({ type: action.type, status: "ok", result });
      ran += 1;
    } catch (err) {
      log.warn({ err, ruleId: rule.id, action: action?.type }, "automation_action_failed");
      outcomes.push({
        type: action?.type,
        status: "failed",
        error: err instanceof Error ? err.message : "unknown",
      });
      failed += 1;
    }
  }

  await prisma.automationRun.create({
    data: {
      ruleId: rule.id,
      resourceId: job.resourceId,
      status: failed === 0 ? "success" : ran === 0 ? "failed" : "success",
      outcome: { actions: outcomes } as object,
      errorMessage: failed > 0 ? `${failed}/${actions.length} actions failed` : null,
    },
  });

  return { ran, failed };
}
