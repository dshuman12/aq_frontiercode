# Permissions

WorkNest uses a three-layer authorization model documented in this doc.
The implementation lives in `@worknest/permissions`.

## Permission catalog

A flat list of every permission the system understands lives in
`packages/permissions/src/permission-map.ts`. Adding a new permission
means:

1. Add the entry to the catalog (grouped by category).
2. Update the relevant role preset in `role-presets.ts`.
3. Decorate the controller route with `@RequiresPermission("...")`.
4. The CI script `scripts/check-permissions.ts` fails the build if (3)
   is forgotten.

The catalog has 90+ permission strings grouped under:

```
organization, members, roles, teams, projects, boards, tasks, tickets,
requests, approvals, assets, inventory, clients, notifications,
reports, files, audit, apiKeys, webhooks, featureFlags, admin
```

Examples: `tasks:write`, `tickets:close`, `approvals:decide`,
`audit:read`, `org:billing:write`.

## Role presets

Built-in roles map to permission sets:

| Role     | Description                                                           |
|----------|-----------------------------------------------------------------------|
| owner    | Every permission. `org:delete` and `org:transfer` are owner-only.     |
| admin    | Full read/write across the org including billing + member management. |
| manager  | Project + ticket + request workflow; no billing or member changes.    |
| member   | Day-to-day collaboration (create tasks, comment, submit requests).    |
| viewer   | Read-only access to the org's data.                                   |

The presets are exported from `role-presets.ts`. Custom roles defined
per-organization override the preset's whitelist.

## PermissionContext

Each request constructs a `PermissionContext` once via the
`PermissionsGuard`. Controllers and services call:

```typescript
import { can, require } from "@worknest/permissions";

if (can(ctx, "tasks:write")) { /* ... */ }

require(ctx, "billing:write"); // throws PermissionDenied otherwise
```

The context carries `userId`, `organizationId`, `role`, the resolved
permission `Set`, and an `isOwner` flag for occasional special-case
checks.

## Custom roles

Each organization can define a `Role` row with:

- `name` + optional `description`
- `permissions: string[]`

The runtime merges a member's `role` (preset key) with the optional
`customRoleId` to compute their effective grant set:

```
preset → custom grants → custom denies → final set
```

Members can be both "manager" preset _and_ a custom role layered on
top — the union of their permissions wins.

## Auditing

Every state-changing endpoint passes through the audit log middleware
which records `(organizationId, actorId, action, resource, resourceId,
diff, ip, userAgent)`. The diff is a structured JSON object — `{ field:
[oldValue, newValue] }` — which the admin UI renders inline.

## Best practices

- Prefer `@RequiresPermission` over inline `can()` checks. Keeps the
  guard surface auditable from a single grep.
- Never trust the role string from the JWT alone — the permission check
  is the source of truth.
- When you need a permission that's specific to a single role, prefer
  introducing a permission string over special-casing the role name.
