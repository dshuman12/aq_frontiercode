# API reference

All endpoints are scoped to a single organization, identified by the
bearer token. Pagination uses `page` and `pageSize` query params.

## Authentication

| Method | Path                                | Description                              |
|--------|-------------------------------------|------------------------------------------|
| POST   | /api/auth/register                  | Create an account                        |
| POST   | /api/auth/login                     | Issue access + refresh tokens            |
| POST   | /api/auth/refresh                   | Refresh an access token                  |
| POST   | /api/auth/logout                    | Revoke a session                         |
| POST   | /api/auth/password/reset/request    | Request a password reset link            |
| POST   | /api/auth/password/reset/complete   | Complete a password reset                |
| POST   | /api/auth/verify-email              | Confirm an email address                 |
| GET    | /api/auth/sessions                  | List active sessions                     |
| POST   | /api/auth/sessions/revoke           | Revoke a specific session                |
| POST   | /api/auth/2fa/begin                 | Start 2FA enrollment, returns secret     |
| POST   | /api/auth/2fa/enable                | Confirm 2FA enrollment with code         |
| POST   | /api/auth/2fa/disable               | Disable 2FA (requires password)          |

## Users

| Method | Path                                         | Description                |
|--------|----------------------------------------------|----------------------------|
| GET    | /api/users/me                                | Current user profile       |
| PATCH  | /api/users/me                                | Update profile             |
| GET    | /api/users/me/organizations                  | List orgs you belong to    |
| POST   | /api/users/me/organization/active            | Set active org             |
| GET    | /api/users/:id                               | Public profile by id       |

## Organizations

| Method | Path                                            | Description                  |
|--------|-------------------------------------------------|------------------------------|
| POST   | /api/organizations                              | Create a new organization    |
| GET    | /api/organizations/current                      | Current org                  |
| GET    | /api/organizations/current/stats                | Headline counts              |
| PATCH  | /api/organizations/current                      | Update org                   |
| GET    | /api/organizations/current/members              | List members                 |
| PATCH  | /api/organizations/current/members/:userId      | Set role                     |
| DELETE | /api/organizations/current/members/:userId      | Remove member                |
| POST   | /api/organizations/current/transfer-ownership   | Transfer ownership           |

## Invitations + roles

| Method | Path                          | Description                    |
|--------|-------------------------------|--------------------------------|
| POST   | /api/invitations              | Send an invitation             |
| GET    | /api/invitations              | List invitations               |
| DELETE | /api/invitations/:id          | Revoke an invitation           |
| POST   | /api/invitations/accept       | Accept an invitation           |
| GET    | /api/roles                    | List roles (presets + custom)  |
| GET    | /api/roles/permissions        | Permission catalog             |
| POST   | /api/roles                    | Create a custom role           |
| PATCH  | /api/roles/:id                | Update a custom role           |
| DELETE | /api/roles/:id                | Delete a custom role           |

## Teams + projects + tasks

See the controllers under `apps/api/src/modules/{teams,projects,boards,tasks}`.
Highlights:

- Projects have nested boards with columns and milestones.
- Tasks support subtasks (`parentTaskId`), labels, custom fields,
  dependencies, checklists, comments, attachments, and an activity log.
- Tasks can be filtered by `projectId`, `assigneeId`, `status`,
  `priority`, `q`, with paginated responses.

## Tickets

| Method | Path                                | Description                |
|--------|-------------------------------------|----------------------------|
| GET    | /api/tickets                        | List tickets               |
| GET    | /api/tickets/:id                    | Ticket detail              |
| POST   | /api/tickets                        | Open a new ticket          |
| PATCH  | /api/tickets/:id                    | Update                     |
| POST   | /api/tickets/:id/transition         | Move to another status     |
| POST   | /api/tickets/:id/comments           | Add reply or internal note |
| GET    | /api/tickets/:id/history            | Status history             |
| POST   | /api/tickets/:id/watchers           | Add watcher                |
| GET    | /api/tickets/categories             | List categories            |
| POST   | /api/tickets/categories             | Create category            |

## Request forms

| Method | Path                                | Description                |
|--------|-------------------------------------|----------------------------|
| GET    | /api/requests/forms                 | List forms                 |
| GET    | /api/requests/forms/:id             | Form detail                |
| POST   | /api/requests/forms                 | Create form (with fields)  |
| PATCH  | /api/requests/forms/:id             | Update                     |
| DELETE | /api/requests/forms/:id             | Archive                    |
| GET    | /api/requests                       | List submissions           |
| POST   | /api/requests                       | Submit a request           |
| GET    | /api/requests/:id                   | Submission detail          |
| POST   | /api/requests/:id/transition        | Transition                 |
| POST   | /api/requests/:id/assign            | Assign                     |
| POST   | /api/requests/:id/comments          | Add comment                |

## Approvals

| Method | Path                                          | Description              |
|--------|-----------------------------------------------|--------------------------|
| GET    | /api/approvals/workflows                      | List workflows           |
| POST   | /api/approvals/workflows                      | Create workflow + steps  |
| PATCH  | /api/approvals/workflows/:id                  | Update                   |
| DELETE | /api/approvals/workflows/:id                  | Delete                   |
| GET    | /api/approvals/pending                        | Inbox                    |
| GET    | /api/approvals/decided                        | Recent decisions         |
| POST   | /api/approvals/:id/decide                     | Approve or reject        |
| POST   | /api/approvals/:id/resubmit                   | Resubmit a rejection     |

## Assets + inventory

See `assets/`, `inventory/` modules. Highlights:

- Asset assignment history, maintenance records, warranty alerts.
- Inventory transactions with running balance.
- Vendors + warehouses for normalising procurement data.

## Reports

| Method | Path                                | Description                 |
|--------|-------------------------------------|-----------------------------|
| GET    | /api/reports/overview               | Dashboard counts            |
| GET    | /api/reports/team-workload          | Per-user workload summary   |
| GET    | /api/reports/project/:id/progress   | Tasks + milestones progress |
| GET    | /api/reports/ticket-sla             | Avg resolution by priority  |
| GET    | /api/reports/tasks.csv              | Tasks export                |
| GET    | /api/reports/tickets.csv            | Tickets export              |

## Billing

| Method | Path                                | Description                 |
|--------|-------------------------------------|-----------------------------|
| POST   | /api/billing/checkout               | Stripe checkout session     |
| POST   | /api/billing/portal                 | Stripe customer portal      |
| POST   | /api/billing/seats                  | Change subscribed seats     |
| GET    | /api/billing/invoices               | Invoice history             |
| POST   | /api/billing/webhook                | Stripe webhook (no auth)    |

## Admin

| Method | Path                                        | Description                  |
|--------|---------------------------------------------|------------------------------|
| GET    | /api/audit-logs                             | Audit log                    |
| GET    | /api/audit-logs/:resource/:resourceId       | Per-resource history         |
| GET    | /api/api-keys                               | List API keys                |
| POST   | /api/api-keys                               | Create key (returns plaintext)|
| DELETE | /api/api-keys/:id                           | Revoke                       |
| GET    | /api/webhooks                               | List webhook endpoints       |
| GET    | /api/webhooks/deliveries                    | Recent deliveries            |
| POST   | /api/webhooks                               | Create endpoint              |
| PATCH  | /api/webhooks/:id                           | Update endpoint              |
| POST   | /api/webhooks/:id/rotate-secret             | Rotate signing secret        |
| DELETE | /api/webhooks/:id                           | Delete                       |

## Files

| Method | Path                          | Description                   |
|--------|-------------------------------|-------------------------------|
| POST   | /api/files/presign            | Get a presigned upload URL    |
| POST   | /api/files/confirm            | Persist the file metadata     |
| GET    | /api/files/:id                | File metadata by id           |
| DELETE | /api/files/:id                | Delete                        |
