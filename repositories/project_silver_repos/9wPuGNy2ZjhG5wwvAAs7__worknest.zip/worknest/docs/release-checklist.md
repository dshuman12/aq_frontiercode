# Release checklist

When cutting a new version, walk this list before tagging:

- [ ] CHANGELOG.md updated. Group changes by Major / Minor / Patch.
- [ ] `package.json` versions bumped in `apps/*` and `packages/*` (we
      ship in lockstep).
- [ ] Schema migrations have a rollback plan documented in the PR.
- [ ] `pnpm test` is green locally and in CI.
- [ ] e2e suite green against a fresh `pnpm db:seed` stack.
- [ ] Storybook builds without warnings.
- [ ] Permissions lint passes (`pnpm tsx scripts/check-permissions.ts`).
- [ ] Validators export lint passes (`pnpm tsx scripts/check-schema-exports.ts`).
- [ ] OpenAPI doc renders in Redoc preview.
- [ ] If we shipped a breaking SDK change, update the SDK README +
      add a migration note in CHANGELOG.

After tagging:

- [ ] Cut the GitHub release with the CHANGELOG section as the body.
- [ ] Drain the staging worker queue (BullMQ jobs may have schemas
      that don't match prod yet).
- [ ] Watch the SLA dashboard for the first 30 minutes — that's
      where most "the new automation broke ticketing" symptoms show up.
