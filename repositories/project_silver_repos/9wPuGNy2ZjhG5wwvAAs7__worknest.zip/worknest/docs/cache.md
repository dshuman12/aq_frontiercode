# Caching

`@worknest/cache` is a thin abstraction with two backends and a SWR
helper. Read-paths opt in by name; we deliberately don't blanket
everything because the hottest queries are well-known.

## Backends

| Backend | When |
| ------- | ---- |
| `InMemoryLruCache` | per-process; fine for stable single-instance deploys, dev. |
| `RedisCacheStore` | shared across instances; default in production. |

## SWR

`StaleWhileRevalidate` wraps a `loader` so the next caller after a
miss serves the previous value (if any) and refreshes in the
background. In-flight refreshes coalesce per key so a thundering
herd hits the loader exactly once.

```ts
const swr = new StaleWhileRevalidate(store, { freshSeconds: 30, staleSeconds: 600 });
const subs = await swr.get(`org:${id}:subscription`, () => fetchSubscription(id));
```

## Invalidation

Every cached read has a corresponding write path that should call
`store.del(key)` (or `swr.invalidate(key)`). Convention: keys are
namespaced as `<entity>:<id>:<view>`; deletions on `<entity>:<id>:*`
are rare and slow (Redis SCAN), so prefer enumerating known keys.

## Metrics

`cacheMetrics.snapshot()` returns counters; the API exposes them at
`GET /metrics/cache` for an internal observability surface (rate-limited
via Throttler). Reset between deploys is a non-goal — counters are
process-local.

## What's currently cached

- org subscription + plan limits (SWR, fresh 30s, stale 10m)
- per-user permission set (SWR, fresh 60s, stale 10m)
- search hits for high-frequency queries (LRU, 200 entries)
- `/sla/dashboard` (SWR, fresh 15s, stale 60s)
