# Database

WorkNest uses PostgreSQL 16 via Prisma. The full schema lives in
`prisma/schema.prisma`; this doc summarises the model groupings and the
non-obvious decisions.

## Multi-tenancy

Every domain row carries an `organizationId` foreign key with cascading
delete. The application layer enforces tenant isolation by:

- Pulling `orgId` from the bearer token's claims via the `CurrentOrgId`
  decorator.
- Scoping every Prisma query to `where: { organizationId, ... }`.
- A future ADR will introduce Postgres RLS as defense in depth.

## Identity

| Model               | Purpose                                          |
|---------------------|--------------------------------------------------|
| `User`              | Account profile + auth credentials                |
| `Session`           | Opaque session token (SHA-256 hashed at rest)     |
| `PasswordReset`     | Single-use token for password reset               |
| `EmailVerification` | Single-use token for email confirmation           |

## Organizations + RBAC

| Model                   | Purpose                                     |
|-------------------------|---------------------------------------------|
| `Organization`          | Tenant root                                 |
| `OrganizationMember`    | User ↔ org link with role + custom role     |
| `Invitation`            | Pending invite (token hashed)               |
| `Role`                  | Custom role (per-org permission whitelist)  |
| `Team`, `TeamMember`    | Logical grouping of members                 |

## Projects + boards + tasks

The biggest model group. Each `Project` has:

- One default `Board` with five `BoardColumn`s seeded at creation.
- `Milestone`s ordered by `order`, with `dueOn` / `completedAt` for
  progress reporting.
- `Task`s with subtasks (`parentTaskId`), dependencies
  (`TaskDependency`), labels (`TaskLabel`), comments (`TaskComment`),
  attachments (`TaskAttachment`), checklists (`TaskChecklist` ↔
  `TaskChecklistItem`), custom fields (`TaskCustomField` ↔
  `TaskCustomFieldValue`), and an activity timeline (`TaskActivity`).

`Task.position` is a fractional float for drag-reordering without
rewriting siblings. `Task.key` is denormalised
(`<project-key>-<seq>`) for fast lookup without joins.

## Tickets + requests + approvals

| Model                         | Purpose                                    |
|-------------------------------|--------------------------------------------|
| `Ticket`                      | Internal-support ticket                    |
| `TicketComment`               | Reply (with `internal` flag)               |
| `TicketStatusHistory`         | Append-only state transitions              |
| `TicketWatcher`               | Watcher subscriptions                      |
| `TicketCategory`              | Per-org categories with default assignee   |
| `RequestForm`, `RequestFormField`     | Form definitions                   |
| `RequestSubmission`, `RequestFieldValue` | Submitted requests              |
| `RequestComment`              | Comment thread (with internal flag)        |
| `ApprovalWorkflow`            | Workflow definition                        |
| `ApprovalStep`                | Ordered step with optional condition       |
| `ApprovalDecision`            | Per-step pending/decided record            |
| `ApprovalHistory`             | Append-only audit trail of decisions       |

## Assets + inventory + clients

| Model                          | Purpose                                  |
|--------------------------------|------------------------------------------|
| `Asset`, `AssetCategory`       | Hardware registry                        |
| `AssetAssignment`              | Custody history per asset                |
| `AssetMaintenanceRecord`       | Maintenance log with cost                |
| `Vendor`                       | Supplier records                         |
| `Warehouse`                    | Storage locations                        |
| `InventoryItem`                | Stock-keeping units with reorder points  |
| `InventoryTransaction`         | Append-only ledger of stock changes      |
| `Client`, `ClientContact`      | External customer records                |
| `ClientPortalUser`             | External login                           |
| `ClientDocument`               | File attachments per client              |

## Notifications + admin

| Model                          | Purpose                                  |
|--------------------------------|------------------------------------------|
| `Notification`                 | Per-user in-app inbox                    |
| `NotificationPreference`       | Per-user channel toggles                 |
| `EmailLog`                     | Sent-email trail (deliverability debug)  |
| `Subscription`                 | One-per-org Stripe subscription          |
| `UsageEvent`                   | Append-only metering events              |
| `Invoice`                      | Stripe-mirrored invoice records          |
| `AuditLog`                     | Append-only state-change log             |
| `ApiKey`                       | Hashed bearer keys                       |
| `WebhookEndpoint`              | Per-org outbound webhook targets         |
| `WebhookDelivery`              | Per-attempt delivery log                 |
| `FileAsset`                    | Object-storage metadata                  |
| `FeatureFlag`                  | Per-org rollout toggles                  |

## Indexes worth knowing

- `Task @@index([assigneeId])` and `@@index([dueAt])` for the
  "my open tasks" and "overdue" queries.
- `Notification @@index([userId, readAt])` for the inbox view.
- `AuditLog @@index([organizationId, createdAt])` and
  `@@index([resource, resourceId])` for the admin browser.
- `WebhookDelivery @@index([webhookId, attemptedAt])` for the recent
  delivery list.
