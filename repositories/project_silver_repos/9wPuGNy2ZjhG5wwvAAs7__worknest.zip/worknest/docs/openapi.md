# OpenAPI

WorkNest publishes a hand-shaped OpenAPI 3.1 document. Module
authors register tags + paths via `registerOpenApiPaths` from
`apps/api/src/common/openapi-bootstrap.ts`; the API exposes the
combined document at `GET /openapi.json`.

## Why hand-shaped?

We tried `@nestjs/swagger`'s decorator-driven generator and ended up
with a doc that drifted from the SDK's expectations whenever a
controller changed signatures. A hand-shaped doc is more work per
endpoint but stays in lockstep with the typed SDK.

## Adding a route to the doc

Inside the module file:

```ts
import { registerOpenApiPaths } from "../../common/openapi-bootstrap";

registerOpenApiPaths([
  { method: "get", path: "/sla/policies", tag: "SLA", summary: "List SLA policies" },
  { method: "post", path: "/sla/policies", tag: "SLA", summary: "Create SLA policy" },
]);
```

`responseExample` is optional — pass it when an example would help
SDK consumers. Don't bother for vanilla `{ ok: true }` responses.

## Generating types

The SDK doesn't currently generate from the OpenAPI doc — it's
hand-written. When that flips (planned for 0.4), the generator will
read `/openapi.json` and emit `packages/sdk/src/generated/`.
