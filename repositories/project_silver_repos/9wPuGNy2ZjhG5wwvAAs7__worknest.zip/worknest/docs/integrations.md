# Integrations

## Slack (outbound)

`SlackService.post({ webhookUrl, payload })` calls a Slack Incoming
Webhook. Payload shapes live in `slack.format.ts`:

- `ticketCreatedPayload` — new ticket alert
- `slaBreachPayload` — first-response or resolution breach
- `digestPayload` — daily summary

Webhook URLs are stored on the org-level config (production: a typed
Integration row). Slack outbound is best-effort; failures log a
warning and return `{ ok: false }` — the producing event is never
blocked on the network call.

## GitHub (inbound webhook)

`POST /integrations/github/webhook` accepts standard GitHub webhook
payloads. The receiver:

1. Reads `X-Hub-Signature-256` and verifies via HMAC-SHA-256 with
   `GITHUB_WEBHOOK_SECRET`.
2. Reads `X-WorkNest-Org` to scope the resulting ticket.
3. Maps known events to ticket creates:
   - `issues.opened` → priority=medium ticket
   - `workflow_run` with conclusion=failure → priority=high "CI failure" ticket

Unknown events return 200 to avoid GitHub retries.

## Email-to-ticket

`EmailToTicketService.process(email)` accepts a normalized inbound
email payload. Inbox routing follows the convention
`support+<orgSlug>@worknest.dev`. The from address is matched against
existing users; unknowns fall back to the `automation` sentinel.

Threaded replies are not yet matched into existing tickets — the
follow-up commit indexes on `messageId`.

## Zapier-style generic webhook

`POST /integrations/zapier/webhook/:orgSlug` accepts a small payload
shape (`{ resource, action, ...fields }`) authenticated by a shared
secret. Designed for low-code tools like Zapier, n8n, and Make. We
return `{ ok: true, ignored: true }` for unknown shapes so partner
flows don't break when we add new resources.
