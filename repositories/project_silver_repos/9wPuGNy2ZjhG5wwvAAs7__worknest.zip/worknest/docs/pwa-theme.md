# PWA + theming

WorkNest's web app is installable as a PWA and ships a small service
worker for offline shell caching.

## PWA

- `apps/web/public/manifest.json` declares the app name, icons,
  start URL (`/dashboard`), and theme color.
- `apps/web/public/sw.js` runs a tiny service worker. Behavior:
  - app shell: cache-first
  - `/api/*`: network-first, falling back to cache, then
    `{ offline: true }` 503
  - everything else: cache-with-revalidate

The service worker is opt-in — registration happens from `Bootstrap.tsx`.
You can disable it during local development with `?sw=off` to avoid
ghost responses while iterating.

## Themes

`useTheme()` reads/writes `worknest:theme` ("light" | "dark" | "system").
On first load, `bootstrapTheme()` reads the stored value (default
"system") and toggles `<html class="dark">`. Changing the OS preference
while in "system" mode flips the class via a `matchMedia` listener.

Tailwind utilities under `dark:` work as expected. Colors that don't
have explicit dark variants degrade gracefully because we use slate-
and brand-tone classes throughout.

## i18n

`useLocale()` reads `worknest:locale` ("en" | "es"). Catalogs are
JSON files under `apps/web/messages/`. Lookup is `t(locale, key,
fallback?)`. Untranslated keys return the key string so missing
translations are visible without crashing.

To add a locale:

1. Drop a new JSON catalog into `apps/web/messages/<code>.json`.
2. Extend the `Locale` union in `apps/web/src/lib/i18n.ts`.
3. Add a language switcher entry in `Settings → Profile`.
