# SSO + SCIM

WorkNest supports SAML 2.0 sign-in and SCIM 2.0 user provisioning per
organization. Both are configured via the Admin → Security panel.

## SAML

Each org has an entityId, an IdP-side SSO URL, and an X.509 cert. On
assertion receipt we:

1. Verify the XML signature against the configured cert.
2. Run `validateAssertion` (audience match + time window).
3. Extract the email from the configured attribute (default
   `http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress`).
4. Upsert the User and the OrganizationMember row.
5. Issue our standard access + refresh tokens.

If `enforced` is set on the org, password login is rejected for
users in the SCIM-provisioned set.

## SCIM

The `/scim/v2/Users` endpoints accept a static bearer token configured
per org. We support a small but useful subset:

- `GET    /scim/v2/Users` (filter: `userName eq` / `emails.value eq`)
- `GET    /scim/v2/Users/:id`
- `POST   /scim/v2/Users` (creates User if absent, ensures membership)
- `PATCH  /scim/v2/Users/:id` (toggle active)
- `DELETE /scim/v2/Users/:id` (soft deactivate; suspends membership)

Tokens are issued through the existing API-keys system with `scopes`
including `scim`.

## Limitations

- No SAML SLO (single logout) yet — we revoke our session but the IdP
  session lives on.
- Group sync via SCIM is not implemented; role assignment is
  organization admin's responsibility.
- Audit log entries for SCIM mutations are coarse — we record the
  action but not the calling token's label.
