# Automation rules

Rules fire when a resource changes. Each rule binds:

- a **trigger**: `created`, `updated`, `status_changed`, `assignee_changed`, `due_soon`
- a **condition** (optional): array of predicates over top-level fields
- a sequence of **actions**

## Conditions

```json
[
  { "field": "priority", "op": "eq", "value": "urgent" },
  { "field": "assigneeId", "op": "is_null" }
]
```

Supported `op` values: `eq`, `ne`, `in`, `is_null`. The empty list
matches everything.

## Actions

| Type           | Shape |
| -------------- | ----- |
| `set_status`   | `{ status: string }` |
| `set_priority` | `{ priority: string }` |
| `assign`       | `{ userId: string }` |
| `add_label`    | `{ labelId: string }` |
| `comment`      | `{ body: string }` (system-authored) |
| `notify`       | `{ userIds: string[]; title: string; body? }` |
| `webhook`      | `{ webhookId: string; eventName: string }` |

## Cookbook

### Auto-route urgent unassigned tickets

```json
{
  "name": "Page oncall on urgent",
  "resource": "ticket",
  "trigger": "created",
  "condition": [
    { "field": "priority", "op": "eq", "value": "urgent" },
    { "field": "assigneeId", "op": "is_null" }
  ],
  "actions": [
    { "type": "assign", "userId": "<oncall_user>" },
    { "type": "notify", "userIds": ["<oncall_user>"], "title": "Urgent ticket" }
  ]
}
```

### Mirror task done → outbound webhook

```json
{
  "name": "Notify integration of task completion",
  "resource": "task",
  "trigger": "status_changed",
  "condition": [{ "field": "status", "op": "eq", "value": "done" }],
  "actions": [
    { "type": "webhook", "webhookId": "<endpoint_id>", "eventName": "task.completed" }
  ]
}
```

## Dry-run

`POST /automation/rules/:id/test` with `{ resourceId }` evaluates the
condition without running actions. Use it from the rule editor to
validate a rule before turning it on.
