# SLA policies

A **policy** sets first-response and resolution targets keyed on
ticket priority (and optionally ticket category). A **timer** is the
per-ticket clock that records due-by, met-at, and breach state.

## Lifecycle

1. Ticket created → `POST /sla/timers/:ticketId/start` finds the
   matching policy and creates a SlaTimer with `firstResponseDueAt`
   and `resolutionDueAt`.
2. First reply (any non-internal comment) → mark first-response met.
3. Status flips to `resolved` → mark resolution met.
4. Worker re-sweep every 2 min flips `breachedFirstResponse`/
   `breachedResolution` when due-by passes without a met timestamp.

## Pause / resume

Status changes that move work back into a customer's court (`pending`
on customer info, "on_hold" with rationale) call
`/sla/timers/:ticketId/pause`. Resume bumps both due-by timestamps
forward by the pause duration so the same number of working
minutes remains.

## Choosing minutes

Tighter numbers mean noisier breach alerts. Common starting points:

| Priority | First response | Resolution |
| -------- | -------------- | ---------- |
| low      | 8h             | 5d         |
| medium   | 4h             | 2d         |
| high     | 1h             | 8h         |
| urgent   | 15m            | 4h         |

You can override per-category by creating a second policy with the
same priority and a `categoryId` set; matchPolicy prefers exact
matches over wildcard.
