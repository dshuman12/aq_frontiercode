# Architecture

A single-page tour of how WorkNest fits together.

## High-level layout

```
                ┌────────────────────┐
                │  Cloudflare WAF    │
                └─────────┬──────────┘
                          │
            ┌─────────────┼─────────────┐
            │             │             │
            ▼             ▼             ▼
    ┌─────────────┐ ┌─────────────┐ ┌──────────────────┐
    │ apps/web    │ │ Stripe      │ │  External clients│
    │ (Next.js 14)│ │ webhooks    │ │  (CLI, partners) │
    └──────┬──────┘ └──────┬──────┘ └─────────┬────────┘
           │               │                  │
           └────────────┬──┴──────────────────┘
                        │
                        ▼
              ┌──────────────────┐
              │   apps/api       │
              │ (NestJS, REST +  │
              │   socket.io)     │
              └────────┬─────────┘
                       │
       ┌───────────────┼───────────────┐
       │               │               │
       ▼               ▼               ▼
 ┌───────────┐ ┌──────────────┐ ┌────────────────┐
 │ Postgres  │ │    Redis     │ │  apps/worker   │
 │ (RDS)     │ │  (cluster)   │ │ (BullMQ jobs)  │
 └───────────┘ └──────────────┘ └────────────────┘
```

## Apps

### apps/web

Next.js 14 client. The post-login surface lives under `(app)` and shares a
`Sidebar` + `QueryProvider`. Auth pages live under `auth`. Talks to the
API exclusively through `/api/...` (proxied by Next).

### apps/api

NestJS service. 22 feature modules + a few cross-cutting guards in
`common/`. Stateless; multiple instances behind a load balancer with
sticky sessions for socket.io.

### apps/worker

Node process consuming BullMQ. 8 queues (`email`, `notification`,
`approval`, `ticket`, `webhook`, `report`, `billing`, `maintenance`),
each with a dedicated processor. Stateless; horizontally scalable.

## Packages

| Package                     | Purpose                                          |
|-----------------------------|--------------------------------------------------|
| `@worknest/auth`            | argon2, JWT, opaque tokens, RFC6238 TOTP         |
| `@worknest/config`          | env helpers + plan-limit constants               |
| `@worknest/database`        | singleton Prisma client + transaction helper     |
| `@worknest/email`           | SMTP transport + 11 email templates              |
| `@worknest/logger`          | pino with redaction                              |
| `@worknest/notifications`   | dispatcher + 3 channels + rate limiter + digest  |
| `@worknest/permissions`     | catalog (90+ perms) + role presets + checker     |
| `@worknest/sdk`             | typed REST client used by web + scripts          |
| `@worknest/ui`              | shadcn-style component library                   |
| `@worknest/validators`      | Zod schemas shared by web + api                  |

## Data flow

### Creating a task

1. Web: `POST /api/tasks` with the new task body.
2. API: `AuthGuard` → `PermissionsGuard(@RequiresPermission("tasks:create"))`
   → `ZodPipe(CreateTaskSchema)`.
3. `TasksService.create(...)` allocates a sequential project key,
   inserts the task, writes a `TaskActivity` row.
4. Returns the created task to the client.
5. The notification queue is enqueued separately if the task has an
   assignee.

### Submitting a request

1. Web posts to `/api/requests` with form values keyed by field key.
2. API validates the body, looks up the form, validates required fields,
   inserts the submission + `RequestFieldValue` rows.
3. The `approvals` module looks up workflows whose `appliesTo` matches
   the form's slug and creates a pending `ApprovalDecision` for each
   step's first matching approver.
4. The notification queue dispatches an in-app + email to the approver.

### Ticket SLA scan

1. Worker `ticket.queue` runs `sla-scan` every minute (cron).
2. The processor pulls open tickets, checks `(priority, ageHours)`
   against thresholds, fires a `ticket.escalated` notification.
3. Notification dispatcher fans out via in-app + email + webhook.

## Reliability principles

- **Stateless tiers.** API and worker are stateless; restart at will.
- **Idempotent jobs.** Every BullMQ job is safe to retry.
- **Ack early.** Stripe webhooks ack 200 even on transient failure.
- **Backpressure over OOM.** Per-queue concurrency tuned for memory.
