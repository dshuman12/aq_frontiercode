# Time tracking

WorkNest tracks time at the **task** level. Every running session is a
`TimeEntry` row owned by a specific user; we enforce one running timer
per user in the service layer.

## Concepts

- **Running entry** — `endedAt: null`. Starting a new timer while one
  is running stops the previous one with `endedAt = now()`.
- **Manual entry** — `startedAt` and `endedAt` provided up-front.
  Useful for "I forgot to start the timer."
- **Billable** — boolean flag that flows through reporting.

## Endpoints

| Method | Path | Notes |
| ------ | ---- | ----- |
| GET    | `/time-entries` | filter by `taskId`, `userId`, `projectId`, `fromDate`, `toDate`, `billable`. Returns paginated rows + `totalSeconds`. |
| GET    | `/time-entries/running` | the caller's currently-running entry, or `null`. |
| POST   | `/time-entries/start` | body: `{ taskId, description?, billable? }`. Stops any prior timer. |
| POST   | `/time-entries/stop` | body: `{ endedAt? }`. |
| POST   | `/time-entries` | manual entry; body has explicit `startedAt`/`endedAt`. |
| PATCH  | `/time-entries/:id` | only the entry's owner can edit. |
| DELETE | `/time-entries/:id` | only the entry's owner can delete. |
| GET    | `/time-entries/rollup/task/:taskId` | total + per-user breakdown. |
| GET    | `/time-entries/rollup/project/:projectId` | total seconds. |

## Reporting

Use the rollup endpoints for task and project totals. For organization-
wide reports, the existing `/reports/*` endpoints accept a date range
and produce summary rows.

## Permissions

Time entries piggyback on `tasks:read` and `tasks:update` — there's no
separate `time:write` permission because the current model is "if you
can update a task, you can log time on it." Owners always control
their own entries (PATCH/DELETE).
