# WorkNest documentation

Everything we've written about how WorkNest works, organized by audience.

## For operators

- [time-tracking.md](./time-tracking.md) — running timers, manual entries, rollups
- [sla.md](./sla.md) — policies, timers, breach handling
- [automation.md](./automation.md) — triggers, actions, cookbook
- [csv.md](./csv.md) — bulk import / export format

## For admins

- [sso.md](./sso.md) — SAML + SCIM
- [integrations.md](./integrations.md) — Slack / GitHub / email-to-ticket / Zapier
- [pwa-theme.md](./pwa-theme.md) — installable app, theming, i18n
- [release-checklist.md](./release-checklist.md) — what to verify before tagging

## For engineers

- [cache.md](./cache.md) — caching strategy and invalidation
- [openapi.md](./openapi.md) — how the OpenAPI doc is shaped + extended

If something's missing, that's a doc-debt issue worth filing.
