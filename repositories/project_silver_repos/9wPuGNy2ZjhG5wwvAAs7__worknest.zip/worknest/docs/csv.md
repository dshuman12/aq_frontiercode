# CSV import / export

WorkNest supports best-effort CSV bulk-load for tasks and tickets. The
parser follows RFC 4180 (quoted fields, escaped quotes, embedded
newlines) and we strip a leading UTF-8 BOM so Excel-on-Windows files
work without manual cleanup.

## Tasks

**Required headers:** `projectKey`, `title`.

**Optional headers:** `description`, `status`, `priority`, `assigneeEmail`.

```csv
projectKey,title,priority,assigneeEmail,description
WN,Set up demo data,medium,alex@example.com,
WN,"Onboard new client, ACME",high,priya@example.com,Pending paperwork
```

Each row is validated independently. Failures show up in `errors[]`
keyed by the original line number; the imported rows are returned
in `imported[]`.

## Tickets

**Required headers:** `title`. Optional: `description`, `status`,
`priority`, `categoryName`.

The bulk endpoint creates each ticket with `requesterId = caller`.
Pre-existing tickets are not deduplicated — re-running the same CSV
will create duplicates. Filter the source file before re-importing.

## Export

`GET /csv/tasks/export?projectId=...` and `GET /csv/tickets/export`
return a downloadable CSV. The web app links these from the
respective list pages.

## Sizing

The synchronous endpoint targets a few thousand rows max. For larger
loads, run the import as a background job (Postgres COPY is faster but
requires direct DB access we don't expose here).
