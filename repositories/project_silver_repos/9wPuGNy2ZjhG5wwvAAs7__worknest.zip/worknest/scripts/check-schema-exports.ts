#!/usr/bin/env tsx
/**
 * Lints `@worknest/validators`: every `export const ...Schema` from a
 * file in `packages/validators/src/` must be re-exported from
 * `packages/validators/src/index.ts`. We've shipped a few features
 * where the index forgot the new file; this catches them in CI.
 */

import { promises as fs } from "node:fs";
import { join, relative } from "node:path";

const SRC = join(process.cwd(), "packages/validators/src");
const INDEX = join(SRC, "index.ts");

async function main() {
  const indexText = await fs.readFile(INDEX, "utf8");
  const reExports = new Set<string>();
  for (const m of indexText.matchAll(/export \* from "\.\/([^"]+)"/g)) {
    reExports.add(`${m[1]}.ts`);
  }

  const entries = await fs.readdir(SRC);
  const missing: string[] = [];
  for (const file of entries) {
    if (file === "index.ts" || !file.endsWith(".ts") || file.endsWith(".spec.ts")) continue;
    if (!reExports.has(file)) missing.push(file);
  }

  if (missing.length === 0) {
    console.log("validators: every file re-exported from index");
    return;
  }
  console.error("✗ Validators not re-exported from index.ts:");
  for (const f of missing) console.error("  " + relative(process.cwd(), join(SRC, f)));
  process.exit(1);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
