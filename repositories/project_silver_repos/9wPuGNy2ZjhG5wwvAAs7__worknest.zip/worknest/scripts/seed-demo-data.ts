#!/usr/bin/env tsx
/**
 * Wrapper around `prisma/seed.ts` for the npm script. Splitting it out
 * makes the package.json command shorter and lets us add CLI arguments
 * later without touching seed logic.
 */

import "../prisma/seed";
