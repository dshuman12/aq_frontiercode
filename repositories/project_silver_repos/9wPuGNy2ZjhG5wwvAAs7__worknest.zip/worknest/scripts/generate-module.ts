#!/usr/bin/env tsx
/**
 * Scaffold a new NestJS module + controller + service trio.
 *
 * Usage:
 *   pnpm tsx scripts/generate-module.ts --name billing --route billing
 *
 * Generates:
 *   apps/api/src/modules/<name>/<name>.module.ts
 *   apps/api/src/modules/<name>/<name>.service.ts
 *   apps/api/src/modules/<name>/<name>.controller.ts
 *
 * Refuses to overwrite existing files. Reminds you to wire the new
 * module into AppModule.
 */

import { promises as fs } from "node:fs";
import { join } from "node:path";

interface Args {
  name: string;
  route?: string;
}

function parseArgs(argv: string[]): Args {
  const out: Partial<Args> = {};
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === "--name") out.name = argv[++i];
    else if (argv[i] === "--route") out.route = argv[++i];
  }
  if (!out.name) {
    console.error("Usage: generate-module.ts --name <kebab-name> [--route <prefix>]");
    process.exit(1);
  }
  return out as Args;
}

function pascal(input: string): string {
  return input
    .split(/[-_]/)
    .map((s) => s[0]?.toUpperCase() + s.slice(1))
    .join("");
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const route = args.route ?? args.name;
  const Pascal = pascal(args.name);

  const dir = join(process.cwd(), "apps/api/src/modules", args.name);
  await fs.mkdir(dir, { recursive: true });

  const files: Record<string, string> = {
    [`${args.name}.module.ts`]: `import { Module } from "@nestjs/common";
import { ${Pascal}Controller } from "./${args.name}.controller";
import { ${Pascal}Service } from "./${args.name}.service";

@Module({ controllers: [${Pascal}Controller], providers: [${Pascal}Service] })
export class ${Pascal}Module {}
`,
    [`${args.name}.service.ts`]: `import { Injectable } from "@nestjs/common";
import { prisma } from "@worknest/database";

@Injectable()
export class ${Pascal}Service {
  // TODO: implement
}
`,
    [`${args.name}.controller.ts`]: `import { Controller, Get, UseGuards } from "@nestjs/common";
import { AuthGuard } from "../../common/auth.guard";
import { CurrentOrgId } from "../../common/current-user.decorator";
import { ${Pascal}Service } from "./${args.name}.service";

@UseGuards(AuthGuard)
@Controller("${route}")
export class ${Pascal}Controller {
  constructor(private readonly service: ${Pascal}Service) {}

  @Get()
  list(@CurrentOrgId() _orgId: string) {
    return [];
  }
}
`,
  };

  for (const [fileName, contents] of Object.entries(files)) {
    const path = join(dir, fileName);
    try {
      await fs.access(path);
      console.error(`refusing to overwrite ${path}`);
      process.exit(1);
    } catch {
      await fs.writeFile(path, contents, "utf8");
      console.log(`created ${path}`);
    }
  }

  console.log(`\nDon't forget to add ${Pascal}Module to AppModule's imports.`);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
