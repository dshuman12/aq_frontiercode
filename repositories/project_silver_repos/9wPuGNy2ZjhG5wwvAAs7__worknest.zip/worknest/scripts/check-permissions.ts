#!/usr/bin/env tsx
/**
 * Lints the API for missing @RequiresPermission / @Public decorators.
 *
 * The rule: every controller method that accepts an HTTP route decorator
 * must also have either `@RequiresPermission("...")` or `@Public()`.
 * CI runs this script and fails the build if any route is undecorated.
 *
 * The check is AST-based using the TypeScript compiler API rather than
 * regex so it survives reformatting.
 */

import { promises as fs } from "node:fs";
import { join, relative } from "node:path";
import * as ts from "typescript";

const ROOT = join(process.cwd(), "apps/api/src/modules");
const HTTP_DECORATORS = new Set(["Get", "Post", "Put", "Patch", "Delete", "All"]);
const ALLOWED = new Set(["RequiresPermission", "Public"]);

interface Finding {
  file: string;
  line: number;
  method: string;
  decorators: string[];
}

async function walk(dir: string): Promise<string[]> {
  const out: string[] = [];
  const entries = await fs.readdir(dir, { withFileTypes: true });
  for (const e of entries) {
    const path = join(dir, e.name);
    if (e.isDirectory()) out.push(...(await walk(path)));
    else if (e.name.endsWith(".controller.ts")) out.push(path);
  }
  return out;
}

function decoratorName(decorator: ts.Decorator): string | null {
  const expression = decorator.expression;
  if (ts.isCallExpression(expression) && ts.isIdentifier(expression.expression)) {
    return expression.expression.text;
  }
  if (ts.isIdentifier(expression)) {
    return expression.text;
  }
  return null;
}

function findUndecorated(filePath: string, source: string): Finding[] {
  const sf = ts.createSourceFile(filePath, source, ts.ScriptTarget.Latest, true);
  const findings: Finding[] = [];

  function visit(node: ts.Node) {
    if (ts.isMethodDeclaration(node)) {
      const decorators = ts.canHaveDecorators(node) ? ts.getDecorators(node) ?? [] : [];
      const names = decorators.map(decoratorName).filter((n): n is string => n != null);
      const isHttp = names.some((n) => HTTP_DECORATORS.has(n));
      const hasGuard = names.some((n) => ALLOWED.has(n));
      if (isHttp && !hasGuard) {
        const { line } = sf.getLineAndCharacterOfPosition(node.getStart(sf));
        findings.push({
          file: relative(process.cwd(), filePath),
          line: line + 1,
          method: (node.name as ts.Identifier).text,
          decorators: names,
        });
      }
    }
    ts.forEachChild(node, visit);
  }
  visit(sf);
  return findings;
}

async function main() {
  const files = await walk(ROOT);
  const findings: Finding[] = [];
  for (const f of files) {
    const source = await fs.readFile(f, "utf8");
    findings.push(...findUndecorated(f, source));
  }

  if (findings.length === 0) {
    console.log("✓ Every HTTP route is guarded.");
    return;
  }

  console.error(`✗ ${findings.length} route(s) missing permission guards:\n`);
  for (const f of findings) {
    console.error(`  ${f.file}:${f.line}  ${f.method}()`);
  }
  process.exit(1);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
