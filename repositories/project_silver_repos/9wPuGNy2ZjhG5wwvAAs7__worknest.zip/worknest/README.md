# WorkNest

Multi-tenant business operations and project management SaaS — projects,
boards, tasks, internal tickets, request forms, approval workflows,
assets, inventory, clients, billing, and admin controls — in one Turborepo.

Feels like Jira + Monday + Freshdesk + ClickUp + an internal company
portal. No AI features.

## Stack

Turborepo, TypeScript, Next.js 14, NestJS 10, PostgreSQL, Prisma,
Redis, BullMQ, Socket.io, Tailwind, shadcn-style components, React Hook
Form, Zod, TanStack Query, Zustand, Stripe, Docker, Vitest, Playwright,
Storybook.

## Layout

```
worknest/
├── apps/
│   ├── web/        Next.js client
│   ├── api/        NestJS API
│   └── worker/     BullMQ worker
├── packages/
│   ├── ui/             shadcn-style component library
│   ├── database/       Prisma client wrapper
│   ├── validators/     Zod schemas shared by web + api
│   ├── config/         tsconfig + env helpers
│   ├── auth/           argon2 + JWT
│   ├── permissions/    RBAC catalog + checker
│   ├── email/          SMTP transport + templates
│   ├── logger/         pino + redaction
│   ├── notifications/  dispatcher + channels
│   └── sdk/            typed API client
├── prisma/
│   ├── schema.prisma
│   └── seed.ts
├── docs/
└── docker/
```

## Quick start

```sh
cp .env.example .env
docker compose up -d
pnpm install
pnpm prisma migrate deploy
pnpm db:seed
pnpm dev
```

Web: <http://localhost:3000> · API: <http://localhost:4000/api> ·
Storybook: <http://localhost:6006>

Demo account (after `pnpm db:seed`):

- Email: `alex@worknest-demo.test`
- Password: `demo-password-change-me`
