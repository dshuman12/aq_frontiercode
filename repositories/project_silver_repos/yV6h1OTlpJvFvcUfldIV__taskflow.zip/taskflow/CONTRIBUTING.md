# Contributing to TaskFlow

## Development setup

```bash
git clone <your-repo>
cd taskflow
pip install -e .[dev]
```

## Running tests

```bash
pytest tests/ -v --tb=short
```

## Code style

- Follow PEP 8
- Type-annotate all public functions
- Docstrings on all public classes and methods

## Submitting changes

1. Create a feature branch
2. Write tests for new behaviour
3. Ensure all tests pass
4. Submit a pull request with a clear description
