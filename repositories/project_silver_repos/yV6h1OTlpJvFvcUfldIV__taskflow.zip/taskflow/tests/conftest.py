"""Shared pytest fixtures for taskflow test suite."""
import pytest
from taskflow.core.registry import Registry
from taskflow.backends.memory import MemoryBackend

@pytest.fixture
def registry():
    return Registry()

@pytest.fixture
def backend():
    return MemoryBackend()

@pytest.fixture
def sample_task_kwargs():
    return {
        "name": "test_task",
        "queue_name": "default",
        "args": [],
        "kwargs": {},
    }
