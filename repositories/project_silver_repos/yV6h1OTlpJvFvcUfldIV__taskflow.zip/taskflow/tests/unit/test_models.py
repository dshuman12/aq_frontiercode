"""Tests for core models and task registry."""

import pytest
from datetime import datetime, timezone, timedelta
from taskflow.core.models import (
    Task, TaskStatus, Priority, RetryPolicy, TaskResult,
    QueueInfo, QueueStatus, TaskGroup, TaskChain
)
from taskflow.core.registry import (
    TaskRegistry, DuplicateTaskError, TaskNotFoundError,
    task, get_registry, reset_registry
)


# --- Priority ---

def test_priority_from_string():
    assert Priority.from_string("high") == Priority.HIGH
    assert Priority.from_string("CRITICAL") == Priority.CRITICAL

def test_priority_from_string_invalid():
    with pytest.raises(ValueError):
        Priority.from_string("ultrafast")

def test_priority_ordering():
    assert Priority.CRITICAL.value < Priority.HIGH.value < Priority.NORMAL.value


# --- RetryPolicy ---

def test_retry_policy_exponential_delay():
    policy = RetryPolicy(delay_seconds=1.0, backoff="exponential", backoff_factor=2.0, jitter=False)
    assert policy.delay_for_attempt(1) == 1.0
    assert policy.delay_for_attempt(2) == 2.0
    assert policy.delay_for_attempt(3) == 4.0

def test_retry_policy_linear_delay():
    policy = RetryPolicy(delay_seconds=5.0, backoff="linear", jitter=False)
    assert policy.delay_for_attempt(1) == 5.0
    assert policy.delay_for_attempt(2) == 10.0

def test_retry_policy_fixed_delay():
    policy = RetryPolicy(delay_seconds=3.0, backoff="fixed", jitter=False)
    assert policy.delay_for_attempt(1) == 3.0
    assert policy.delay_for_attempt(5) == 3.0

def test_retry_policy_max_delay():
    policy = RetryPolicy(delay_seconds=1.0, backoff="exponential", max_delay_seconds=10.0, jitter=False)
    assert policy.delay_for_attempt(100) == 10.0

def test_retry_policy_should_retry_on():
    policy = RetryPolicy(retry_on=(ValueError,))
    assert policy.should_retry_on(ValueError("oops"))
    assert not policy.should_retry_on(TypeError("nope"))

def test_retry_policy_ignore_on():
    policy = RetryPolicy(ignore_on=(KeyboardInterrupt,))
    assert not policy.should_retry_on(KeyboardInterrupt())
    assert policy.should_retry_on(RuntimeError("x"))

def test_retry_policy_no_retry():
    p = RetryPolicy.no_retry()
    assert p.max_retries == 0


# --- Task ---

def test_task_defaults():
    t = Task(task_name="myapp.add")
    assert t.status == TaskStatus.PENDING
    assert t.priority == Priority.NORMAL
    assert t.attempt == 0

def test_task_to_dict():
    t = Task(task_name="myapp.add", args=[1, 2])
    d = t.to_dict()
    assert d["task_name"] == "myapp.add"
    assert d["args"] == [1, 2]
    assert d["status"] == "pending"

def test_task_from_dict_roundtrip():
    t = Task(task_name="myapp.sub", args=[5], kwargs={"b": 3})
    d = t.to_dict()
    t2 = Task.from_dict(d)
    assert t2.task_name == t.task_name
    assert t2.args == t.args
    assert t2.kwargs == t.kwargs

def test_task_is_overdue():
    t = Task(task_name="x", expires_at=datetime.now(timezone.utc) - timedelta(seconds=1))
    assert t.is_overdue

def test_task_not_overdue():
    t = Task(task_name="x", expires_at=datetime.now(timezone.utc) + timedelta(hours=1))
    assert not t.is_overdue

def test_task_is_ready_no_eta():
    t = Task(task_name="x")
    assert t.is_ready

def test_task_is_ready_future_eta():
    t = Task(task_name="x", eta=datetime.now(timezone.utc) + timedelta(hours=1))
    assert not t.is_ready

def test_task_can_retry():
    t = Task(task_name="x", attempt=2, max_retries=3)
    t.retry_policy = RetryPolicy(max_retries=3)
    assert t.can_retry()

def test_task_cannot_retry_exhausted():
    t = Task(task_name="x", attempt=3, max_retries=3)
    t.retry_policy = RetryPolicy(max_retries=3)
    assert not t.can_retry()

def test_task_fingerprint_stable():
    t1 = Task(task_name="add", args=[1, 2], kwargs={"c": 3})
    t2 = Task(task_name="add", args=[1, 2], kwargs={"c": 3})
    assert t1.fingerprint() == t2.fingerprint()

def test_task_fingerprint_differs():
    t1 = Task(task_name="add", args=[1])
    t2 = Task(task_name="add", args=[2])
    assert t1.fingerprint() != t2.fingerprint()


# --- TaskStatus ---

def test_task_status_terminal():
    assert TaskStatus.SUCCESS.is_terminal
    assert TaskStatus.FAILURE.is_terminal
    assert not TaskStatus.RUNNING.is_terminal
    assert not TaskStatus.QUEUED.is_terminal

def test_task_status_active():
    assert TaskStatus.QUEUED.is_active
    assert TaskStatus.RUNNING.is_active
    assert not TaskStatus.SUCCESS.is_active


# --- TaskResult ---

def test_task_result_succeeded():
    r = TaskResult(task_id="abc", status=TaskStatus.SUCCESS, return_value=42)
    assert r.succeeded
    assert not r.failed

def test_task_result_failed():
    r = TaskResult(task_id="abc", status=TaskStatus.FAILURE, error="boom")
    assert r.failed
    assert not r.succeeded

def test_task_result_run_time():
    start = datetime.now(timezone.utc)
    end = start + timedelta(seconds=2)
    r = TaskResult(task_id="x", status=TaskStatus.SUCCESS, started_at=start, completed_at=end)
    assert r.run_time_seconds == pytest.approx(2.0)


# --- Registry ---

def test_registry_register_and_get():
    reg = TaskRegistry()
    def my_fn(): pass
    reg.register(my_fn, name="test.fn")
    defn = reg.get("test.fn")
    assert defn.name == "test.fn"

def test_registry_duplicate_raises():
    reg = TaskRegistry()
    def fn(): pass
    reg.register(fn, name="dup")
    with pytest.raises(DuplicateTaskError):
        reg.register(fn, name="dup")

def test_registry_overwrite():
    reg = TaskRegistry()
    def fn1(): return 1
    def fn2(): return 2
    reg.register(fn1, name="over")
    reg.register(fn2, name="over", overwrite=True)
    defn = reg.get("over")
    assert defn.func() == 2

def test_registry_not_found_raises():
    reg = TaskRegistry()
    with pytest.raises(TaskNotFoundError):
        reg.get("nonexistent")

def test_registry_contains():
    reg = TaskRegistry()
    def fn(): pass
    reg.register(fn, name="exists")
    assert "exists" in reg
    assert "nope" not in reg

def test_registry_alias():
    reg = TaskRegistry()
    def fn(): pass
    reg.register(fn, name="original")
    reg.add_alias("alias1", "original")
    assert reg.get("alias1").name == "original"

def test_registry_tasks_in_queue():
    reg = TaskRegistry()
    def a(): pass
    def b(): pass
    def c(): pass
    reg.register(a, name="a", queue_name="q1")
    reg.register(b, name="b", queue_name="q1")
    reg.register(c, name="c", queue_name="q2")
    assert len(reg.tasks_in_queue("q1")) == 2
    assert len(reg.tasks_in_queue("q2")) == 1

def test_task_decorator():
    reset_registry()
    @task(name="test.decorated", queue="myq", max_retries=5)
    def my_task(x, y):
        return x + y
    reg = get_registry()
    defn = reg.get("test.decorated")
    assert defn.queue_name == "myq"
    assert defn.retry_policy.max_retries == 5
    reset_registry()
