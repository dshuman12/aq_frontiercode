import pytest
from taskflow.core.retry_policy import RetryFilter

class TestRetryFilter:
    def test_default_retries_all(self):
        f = RetryFilter()
        assert f.should_retry(ValueError("oops"))
        assert f.should_retry(RuntimeError("x"))

    def test_retry_on_whitelist(self):
        f = RetryFilter(retry_on=[ConnectionError, TimeoutError])
        assert f.should_retry(ConnectionError())
        assert not f.should_retry(ValueError())

    def test_no_retry_on_blacklist(self):
        f = RetryFilter(no_retry_on=[TypeError])
        assert f.should_retry(ValueError())
        assert not f.should_retry(TypeError())

    def test_blacklist_beats_whitelist(self):
        f = RetryFilter(retry_on=[Exception], no_retry_on=[ValueError])
        assert not f.should_retry(ValueError())
