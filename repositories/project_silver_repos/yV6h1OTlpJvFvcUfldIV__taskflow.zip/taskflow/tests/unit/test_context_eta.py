import time
import threading
from datetime import datetime, timedelta, timezone
import pytest
from taskflow.core.context import TaskContext, set_current, get_current, clear_current
from taskflow.core.concurrency import ConcurrencyLimiter
from taskflow.core.eta import is_ready, seconds_until_ready

class TestContext:
    def test_set_and_get(self):
        ctx = TaskContext("id1", "my_task", 1, "default", {})
        set_current(ctx)
        assert get_current() is ctx
        clear_current()
        assert get_current() is None

    def test_isolated_per_thread(self):
        results = []
        def worker(val):
            ctx = TaskContext(val, "t", 1, "q", {})
            set_current(ctx)
            time.sleep(0.01)
            results.append(get_current().task_id)
        threads = [threading.Thread(target=worker, args=(str(i),)) for i in range(5)]
        [t.start() for t in threads]
        [t.join() for t in threads]
        assert sorted(results) == [str(i) for i in range(5)]

class TestConcurrencyLimiter:
    def test_unlimited_queue_always_acquires(self):
        lim = ConcurrencyLimiter({"fast": 5})
        assert lim.acquire("slow")  # no limit

    def test_limit_respected(self):
        lim = ConcurrencyLimiter({"q": 2})
        assert lim.acquire("q")
        assert lim.acquire("q")
        assert not lim.acquire("q", block=False)

class TestETA:
    def _task(self, eta=None):
        from unittest.mock import MagicMock
        t = MagicMock()
        t.eta = eta
        return t

    def test_no_eta_always_ready(self):
        assert is_ready(self._task())

    def test_future_eta_not_ready(self):
        eta = datetime.now(tz=timezone.utc) + timedelta(hours=1)
        assert not is_ready(self._task(eta))

    def test_past_eta_ready(self):
        eta = datetime.now(tz=timezone.utc) - timedelta(seconds=1)
        assert is_ready(self._task(eta))

    def test_seconds_until_ready(self):
        eta = datetime.now(tz=timezone.utc) + timedelta(seconds=30)
        s = seconds_until_ready(self._task(eta))
        assert 28 < s <= 30
