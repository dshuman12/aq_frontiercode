"""
Tests for modules added in the second half of 2023:
priority_inheritance, pagination, heartbeat, backoff,
tagging, ttl_store, event_log, quota, autoscaler.
"""

from __future__ import annotations

import threading
import time
from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

import pytest

from taskflow.core.backoff import BackoffConfig, BackoffStrategy, compute_delay, delay_sequence
from taskflow.core.priority_inheritance import effective_priority, priority_ceiling
from taskflow.core.quota import QuotaExceeded, QuotaManager, QuotaRule
from taskflow.core.tagging import TagIndex, TagOp, TagQuery
from taskflow.monitoring.event_log import EventKind, EventLog, TaskEvent
from taskflow.monitoring.heartbeat import HeartbeatMonitor, WorkerHeartbeat
from taskflow.utils.pagination import Page, PaginationOptions, paginate


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_task(task_id="t1", priority_val=2, tags=None, queue="default", status=None):
    """Build a minimal mock task for tests that only need select attributes."""
    task = MagicMock()
    task.task_id = task_id
    task.tags = set(tags or [])
    task.queue_name = queue

    from taskflow.core.models import Priority, TaskStatus
    pmap = {0: Priority.CRITICAL, 1: Priority.HIGH, 2: Priority.NORMAL, 3: Priority.LOW}
    task.priority = pmap.get(priority_val, Priority.NORMAL)
    task.status = status or TaskStatus.PENDING
    task.created_at = datetime.now(tz=timezone.utc)

    def _to_dict():
        return {"task_id": task.task_id}
    task.to_dict = _to_dict
    return task


# ---------------------------------------------------------------------------
# Priority inheritance
# ---------------------------------------------------------------------------

class TestPriorityInheritance:
    def test_higher_priority_parent_elevates_child(self):
        from taskflow.core.models import Priority
        parent = _make_task("p", priority_val=0)  # CRITICAL
        child = _make_task("c", priority_val=2)   # NORMAL
        result = effective_priority(child, parent)
        assert result == Priority.CRITICAL

    def test_lower_priority_parent_does_not_demote(self):
        from taskflow.core.models import Priority
        parent = _make_task("p", priority_val=3)  # LOW
        child = _make_task("c", priority_val=2)   # NORMAL
        result = effective_priority(child, parent)
        assert result == Priority.NORMAL

    def test_no_parent_returns_own_priority(self):
        from taskflow.core.models import Priority
        task = _make_task("t", priority_val=1)
        assert effective_priority(task) == Priority.HIGH

    def test_priority_ceiling_returns_highest(self):
        from taskflow.core.models import Priority
        tasks = [_make_task(f"t{i}", i) for i in range(4)]
        assert priority_ceiling(tasks) == Priority.CRITICAL

    def test_priority_ceiling_empty_returns_normal(self):
        from taskflow.core.models import Priority
        assert priority_ceiling([]) == Priority.NORMAL


# ---------------------------------------------------------------------------
# Pagination
# ---------------------------------------------------------------------------

class TestPagination:
    def _tasks(self, n=10):
        return [_make_task(f"t{i}") for i in range(n)]

    def test_first_page_returns_correct_slice(self):
        tasks = self._tasks(10)
        opts = PaginationOptions(page=1, page_size=3, descending=False)
        page = paginate(tasks, opts)
        assert len(page.items) == 3
        assert page.items[0].task_id == "t0"

    def test_second_page_correct(self):
        tasks = self._tasks(10)
        opts = PaginationOptions(page=2, page_size=3, descending=False)
        page = paginate(tasks, opts)
        assert page.items[0].task_id == "t3"

    def test_has_next_and_prev(self):
        tasks = self._tasks(10)
        opts = PaginationOptions(page=2, page_size=3, descending=False)
        page = paginate(tasks, opts)
        assert page.has_prev
        assert page.has_next

    def test_last_page_no_next(self):
        tasks = self._tasks(6)
        opts = PaginationOptions(page=2, page_size=3, descending=False)
        page = paginate(tasks, opts)
        assert not page.has_next

    def test_total_pages_correct(self):
        tasks = self._tasks(10)
        opts = PaginationOptions(page=1, page_size=3, descending=False)
        page = paginate(tasks, opts)
        assert page.total_pages == 4

    def test_status_filter(self):
        from taskflow.core.models import TaskStatus
        tasks = self._tasks(6)
        tasks[0].status = TaskStatus.FAILED
        opts = PaginationOptions(page=1, page_size=10, status_filter=TaskStatus.FAILED)
        page = paginate(tasks, opts)
        assert page.total == 1

    def test_empty_list_returns_empty_page(self):
        opts = PaginationOptions(page=1, page_size=5)
        page = paginate([], opts)
        assert page.total == 0
        assert page.items == []


# ---------------------------------------------------------------------------
# Heartbeat monitor
# ---------------------------------------------------------------------------

class TestHeartbeatMonitor:
    def test_fresh_worker_is_live(self):
        mon = HeartbeatMonitor(stale_threshold_seconds=60)
        hb = WorkerHeartbeat(worker_id="w1", queue_names=["default"])
        mon.register(hb)
        assert len(mon.live_workers()) == 1

    def test_beat_updates_last_seen(self):
        mon = HeartbeatMonitor(stale_threshold_seconds=60)
        hb = WorkerHeartbeat(worker_id="w1", queue_names=["default"])
        # Manually backdate last_seen using monotonic base
        hb.last_seen = time.monotonic() - 30
        mon.register(hb)
        mon.beat("w1")
        # After beat, last_seen should be recent
        assert time.monotonic() - mon._workers["w1"].last_seen < 1.0

    def test_deregister_removes_worker(self):
        mon = HeartbeatMonitor(stale_threshold_seconds=60)
        hb = WorkerHeartbeat(worker_id="w1", queue_names=["default"])
        mon.register(hb)
        mon.deregister("w1")
        assert len(mon.all_workers()) == 0

    def test_status_dict_keys(self):
        mon = HeartbeatMonitor(stale_threshold_seconds=60)
        s = mon.status()
        assert "total" in s and "live" in s and "stale" in s


# ---------------------------------------------------------------------------
# Backoff
# ---------------------------------------------------------------------------

class TestBackoff:
    def test_fixed_always_same(self):
        cfg = BackoffConfig(strategy=BackoffStrategy.FIXED, base_delay=5.0, jitter=False)
        delays = delay_sequence(5, cfg)
        assert all(d == 5.0 for d in delays)

    def test_exponential_attempt1_equals_base(self):
        cfg = BackoffConfig(
            strategy=BackoffStrategy.EXPONENTIAL,
            base_delay=1.0, multiplier=2.0, jitter=False
        )
        # attempt=1 should yield base * 2^0 = 1.0
        d = compute_delay(1, cfg)
        assert d == pytest.approx(1.0)

    def test_exponential_doubles_each_attempt(self):
        cfg = BackoffConfig(
            strategy=BackoffStrategy.EXPONENTIAL,
            base_delay=1.0, multiplier=2.0, jitter=False
        )
        delays = delay_sequence(4, cfg)
        assert delays == pytest.approx([1.0, 2.0, 4.0, 8.0])

    def test_max_delay_capped(self):
        cfg = BackoffConfig(
            strategy=BackoffStrategy.EXPONENTIAL,
            base_delay=1.0, multiplier=2.0, max_delay=10.0, jitter=False
        )
        d = compute_delay(20, cfg)
        assert d <= 10.0

    def test_linear_grows_linearly(self):
        cfg = BackoffConfig(
            strategy=BackoffStrategy.LINEAR,
            base_delay=2.0, multiplier=1.0, jitter=False
        )
        delays = delay_sequence(4, cfg)
        # base + base * multiplier * (attempt-1): 2, 4, 6, 8
        assert delays == pytest.approx([2.0, 4.0, 6.0, 8.0])


# ---------------------------------------------------------------------------
# Tagging
# ---------------------------------------------------------------------------

class TestTagging:
    def test_and_query_returns_only_tasks_with_all_tags(self):
        idx = TagIndex()
        t1 = _make_task("t1", tags=["urgent", "billing"])
        t2 = _make_task("t2", tags=["urgent"])
        t3 = _make_task("t3", tags=["billing"])
        idx.index_task(t1)
        idx.index_task(t2)
        idx.index_task(t3)
        result = idx.query(TagQuery(tags=["urgent", "billing"], op=TagOp.AND))
        assert result == {"t1"}

    def test_or_query(self):
        idx = TagIndex()
        t1 = _make_task("t1", tags=["a"])
        t2 = _make_task("t2", tags=["b"])
        t3 = _make_task("t3", tags=["c"])
        for t in [t1, t2, t3]:
            idx.index_task(t)
        result = idx.query(TagQuery(tags=["a", "b"], op=TagOp.OR))
        assert result == {"t1", "t2"}

    def test_not_query(self):
        idx = TagIndex()
        t1 = _make_task("t1", tags=["internal"])
        t2 = _make_task("t2", tags=["public"])
        idx.index_task(t1)
        idx.index_task(t2)
        result = idx.query(TagQuery(tags=["internal"], op=TagOp.NOT))
        assert result == {"t2"}

    def test_remove_task_clears_index(self):
        idx = TagIndex()
        t1 = _make_task("t1", tags=["x"])
        idx.index_task(t1)
        idx.remove_task("t1")
        result = idx.query(TagQuery(tags=["x"], op=TagOp.OR))
        assert result == set()


# ---------------------------------------------------------------------------
# EventLog
# ---------------------------------------------------------------------------

class TestEventLog:
    def test_record_and_retrieve(self):
        log = EventLog()
        log.record(TaskEvent(task_id="t1", kind=EventKind.ENQUEUED))
        log.record(TaskEvent(task_id="t1", kind=EventKind.STARTED))
        events = log.events_for("t1")
        assert len(events) == 2

    def test_rotation_keeps_newest(self):
        log = EventLog(max_events=5)
        for i in range(10):
            log.record(TaskEvent(task_id=f"t{i}", kind=EventKind.ENQUEUED))
        assert len(log) == 5

    def test_events_by_kind(self):
        log = EventLog()
        log.record(TaskEvent(task_id="t1", kind=EventKind.ENQUEUED))
        log.record(TaskEvent(task_id="t2", kind=EventKind.FAILED))
        assert len(log.events_by_kind(EventKind.FAILED)) == 1

    def test_clear_task(self):
        log = EventLog()
        log.record(TaskEvent(task_id="t1", kind=EventKind.ENQUEUED))
        log.clear_task("t1")
        assert len(log.all_events()) == 0

    def test_export_jsonl_valid(self):
        import json
        log = EventLog()
        log.record(TaskEvent(task_id="t1", kind=EventKind.SUCCEEDED))
        output = log.export_jsonl()
        parsed = json.loads(output)
        assert parsed["task_id"] == "t1"


# ---------------------------------------------------------------------------
# QuotaManager
# ---------------------------------------------------------------------------

class TestQuotaManager:
    def test_allows_under_limit(self):
        qm = QuotaManager([QuotaRule("q1", max_enqueued=3, window_seconds=60)])
        for _ in range(3):
            qm.check_and_increment("q1")  # should not raise

    def test_raises_over_limit(self):
        qm = QuotaManager([QuotaRule("q1", max_enqueued=2, window_seconds=60)])
        qm.check_and_increment("q1")
        qm.check_and_increment("q1")
        with pytest.raises(QuotaExceeded):
            qm.check_and_increment("q1")

    def test_reset_clears_count(self):
        qm = QuotaManager([QuotaRule("q1", max_enqueued=1, window_seconds=60)])
        qm.check_and_increment("q1")
        qm.reset("q1")
        qm.check_and_increment("q1")  # should not raise

    def test_burst_allowance(self):
        qm = QuotaManager([QuotaRule("q1", max_enqueued=2, window_seconds=60, burst_allowance=1)])
        for _ in range(3):  # 2 + 1 burst = 3 allowed
            qm.check_and_increment("q1")
        with pytest.raises(QuotaExceeded):
            qm.check_and_increment("q1")

    def test_unknown_scope_does_not_raise(self):
        qm = QuotaManager()
        qm.check_and_increment("unknown_queue")  # no rule = no limit
