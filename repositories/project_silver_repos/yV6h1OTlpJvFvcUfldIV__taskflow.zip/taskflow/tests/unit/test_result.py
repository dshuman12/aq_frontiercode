import pytest
from taskflow.core.result import TaskResult
from taskflow.core.models import TaskStatus
from taskflow.utils.fingerprint import fingerprint, fingerprint_matches

class TestTaskResult:
    def test_successful_get_returns_value(self):
        r = TaskResult(task_id="t1", status=TaskStatus.SUCCESS, return_value=42)
        assert r.get() == 42

    def test_failed_get_raises(self):
        r = TaskResult(task_id="t1", status=TaskStatus.FAILED,
                       exception_type="ValueError", exception_message="bad input")
        with pytest.raises(RuntimeError, match="bad input"):
            r.get()

    def test_successful_property(self):
        r = TaskResult(task_id="t1", status=TaskStatus.SUCCESS)
        assert r.successful and not r.failed

class TestFingerprint:
    def test_same_args_same_fingerprint(self):
        fp1 = fingerprint("t", [1, 2], {"k": "v"})
        fp2 = fingerprint("t", [1, 2], {"k": "v"})
        assert fp1 == fp2

    def test_different_args_different(self):
        assert fingerprint("t", [1], {}) != fingerprint("t", [2], {})

    def test_matches_helper(self):
        fp = fingerprint("send_email", ["a@b.com"], {"subject": "hi"})
        assert fingerprint_matches(fp, "send_email", ["a@b.com"], {"subject": "hi"})
