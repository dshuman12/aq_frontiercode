"""Tests for backends, middleware, scheduler, serializers, and utils."""

import pytest
import time
import threading
from datetime import datetime, timezone, timedelta
from taskflow.core.models import Task, TaskResult, TaskStatus, Priority, RetryPolicy
from taskflow.backends.memory import MemoryBackend
from taskflow.backends.sqlite import SQLiteBackend
from taskflow.middleware.base import (
    LoggingMiddleware, TimingMiddleware, RateLimitMiddleware,
    RetryTrackingMiddleware, CorrelationMiddleware
)
from taskflow.serializers.base import (
    JSONSerializer, PickleSerializer, SerializationError,
    get_serializer, serialize, deserialize
)
from taskflow.utils.helpers import (
    RateLimiter, TaskDeduplicator, CircuitBreaker, CircuitBreakerError,
    CircuitState, retry, with_timeout, chunk_list, flatten, utcnow
)
from taskflow.core.scheduler import (
    IntervalSchedule, CronSchedule, Scheduler, ScheduledTask
)


# ============================================================
# Memory backend
# ============================================================

def make_task(name="myapp.add", queue="default", **kwargs) -> Task:
    return Task(task_name=name, queue_name=queue, **kwargs)


def test_memory_enqueue_dequeue():
    b = MemoryBackend()
    t = make_task()
    b.enqueue(t)
    result = b.dequeue("default", "w1")
    assert result is not None
    assert result.task_id == t.task_id
    assert result.status == TaskStatus.RUNNING


def test_memory_priority_ordering():
    b = MemoryBackend()
    low = make_task(priority=Priority.LOW)
    high = make_task(priority=Priority.HIGH)
    critical = make_task(priority=Priority.CRITICAL)
    b.enqueue(low)
    b.enqueue(high)
    b.enqueue(critical)
    first = b.dequeue("default", "w")
    assert first.priority == Priority.CRITICAL


def test_memory_dequeue_empty():
    b = MemoryBackend()
    assert b.dequeue("default", "w") is None


def test_memory_store_and_get_result():
    b = MemoryBackend()
    t = make_task()
    b.enqueue(t)
    b.dequeue("default", "w1")
    result = TaskResult(
        task_id=t.task_id, status=TaskStatus.SUCCESS,
        return_value=42, completed_at=datetime.now(timezone.utc)
    )
    b.store_result(result)
    fetched = b.get_result(t.task_id)
    assert fetched.return_value == 42


def test_memory_revoke():
    b = MemoryBackend()
    t = make_task()
    b.enqueue(t)
    assert b.revoke(t.task_id)
    task = b.get_task(t.task_id)
    assert task.status == TaskStatus.REVOKED


def test_memory_pause_resume():
    b = MemoryBackend()
    b.declare_queue("q1")
    b.pause_queue("q1")
    assert b.is_paused("q1")
    t = make_task(queue="q1")
    b.enqueue(t)
    assert b.dequeue("q1", "w") is None
    b.resume_queue("q1")
    assert b.dequeue("q1", "w") is not None


def test_memory_purge():
    b = MemoryBackend()
    for _ in range(5):
        b.enqueue(make_task())
    count = b.purge_queue("default")
    assert count == 5
    assert b.dequeue("default", "w") is None


def test_memory_list_tasks():
    b = MemoryBackend()
    b.enqueue(make_task("a.task"))
    b.enqueue(make_task("b.task"))
    tasks = b.list_tasks()
    assert len(tasks) == 2


def test_memory_eta_skips_future():
    b = MemoryBackend()
    future_eta = datetime.now(timezone.utc) + timedelta(hours=1)
    t = make_task(eta=future_eta)
    b.enqueue(t)
    assert b.dequeue("default", "w") is None


# ============================================================
# SQLite backend
# ============================================================

def test_sqlite_enqueue_dequeue():
    b = SQLiteBackend(":memory:")
    t = make_task()
    b.enqueue(t)
    result = b.dequeue("default", "w1")
    assert result is not None
    assert result.task_id == t.task_id


def test_sqlite_store_and_get_result():
    b = SQLiteBackend(":memory:")
    t = make_task()
    b.enqueue(t)
    b.dequeue("default", "w1")
    r = TaskResult(task_id=t.task_id, status=TaskStatus.SUCCESS,
                   return_value="hello", completed_at=datetime.now(timezone.utc))
    b.store_result(r)
    fetched = b.get_result(t.task_id)
    assert fetched is not None
    assert fetched.return_value == "hello"


def test_sqlite_revoke():
    b = SQLiteBackend(":memory:")
    t = make_task()
    b.enqueue(t)
    assert b.revoke(t.task_id)
    assert b.dequeue("default", "w") is None


def test_sqlite_list_tasks():
    b = SQLiteBackend(":memory:")
    b.enqueue(make_task("task.a"))
    b.enqueue(make_task("task.b"))
    tasks = b.list_tasks()
    assert len(tasks) == 2


def test_sqlite_queue_info():
    b = SQLiteBackend(":memory:")
    b.enqueue(make_task())
    info = b.queue_info("default")
    assert info is not None
    assert info.total_enqueued == 1


def test_sqlite_purge():
    b = SQLiteBackend(":memory:")
    for _ in range(3):
        b.enqueue(make_task())
    count = b.purge_queue("default")
    assert count == 3


# ============================================================
# Serializers
# ============================================================

def test_json_serializer_roundtrip():
    s = JSONSerializer()
    data = {"key": "value", "num": 42, "list": [1, 2, 3]}
    assert s.loads(s.dumps(data)) == data


def test_json_serializer_str_roundtrip():
    s = JSONSerializer()
    data = [1, "two", None]
    assert s.loads_str(s.dumps_str(data)) == data


def test_pickle_serializer_roundtrip():
    s = PickleSerializer()
    data = {"set": {1, 2, 3}, "tuple": (4, 5)}
    result = s.loads(s.dumps(data))
    assert result["set"] == {1, 2, 3}


def test_serialize_deserialize():
    val = {"x": 1}
    encoded = serialize(val, "json")
    assert deserialize(encoded, "json") == val


def test_get_serializer_unknown():
    from taskflow.serializers.base import SerializationError
    with pytest.raises(SerializationError):
        get_serializer("nonexistent")


# ============================================================
# Rate limiter
# ============================================================

def test_rate_limiter_allows_burst():
    rl = RateLimiter(rate=10, period=1.0, burst=10)
    for _ in range(10):
        assert rl.try_acquire()


def test_rate_limiter_blocks_over_burst():
    rl = RateLimiter(rate=2, period=1.0, burst=2)
    rl.try_acquire()
    rl.try_acquire()
    assert not rl.try_acquire()


# ============================================================
# Task deduplicator
# ============================================================

def test_deduplicator_detects_duplicate():
    d = TaskDeduplicator(window_seconds=60)
    d.record("add", [1, 2], {})
    assert d.is_duplicate("add", [1, 2], {})


def test_deduplicator_different_args_not_duplicate():
    d = TaskDeduplicator(window_seconds=60)
    d.record("add", [1, 2], {})
    assert not d.is_duplicate("add", [3, 4], {})


def test_deduplicator_window_expiry():
    d = TaskDeduplicator(window_seconds=0.01)
    d.record("task", [], {})
    time.sleep(0.05)
    assert not d.is_duplicate("task", [], {})


# ============================================================
# Circuit breaker
# ============================================================

def test_circuit_breaker_closes_on_success():
    cb = CircuitBreaker(name="test", failure_threshold=3)
    assert cb.state == CircuitState.CLOSED
    cb.call(lambda: 42)
    assert cb.state == CircuitState.CLOSED


def test_circuit_breaker_opens_on_failures():
    cb = CircuitBreaker(name="test", failure_threshold=2, reset_timeout=9999)
    def fail(): raise RuntimeError("boom")
    for _ in range(2):
        try: cb.call(fail)
        except RuntimeError: pass
    assert cb.state == CircuitState.OPEN


def test_circuit_breaker_rejects_when_open():
    cb = CircuitBreaker(name="test", failure_threshold=1, reset_timeout=9999)
    try: cb.call(lambda: (_ for _ in ()).throw(RuntimeError()))
    except: pass
    with pytest.raises(CircuitBreakerError):
        cb.call(lambda: None)


def test_circuit_breaker_reset():
    cb = CircuitBreaker(name="test", failure_threshold=1)
    try: cb.call(lambda: (_ for _ in ()).throw(RuntimeError()))
    except: pass
    cb.reset()
    assert cb.state == CircuitState.CLOSED


# ============================================================
# Retry helper
# ============================================================

def test_retry_succeeds_on_third_attempt():
    calls = []
    def flaky():
        calls.append(1)
        if len(calls) < 3:
            raise ValueError("not yet")
        return "ok"
    result = retry(flaky, max_attempts=3, delay=0)
    assert result == "ok"
    assert len(calls) == 3


def test_retry_raises_after_exhaustion():
    def always_fails(): raise ValueError("always")
    with pytest.raises(ValueError):
        retry(always_fails, max_attempts=2, delay=0)


# ============================================================
# Scheduler
# ============================================================

def test_interval_schedule_due():
    s = IntervalSchedule(seconds=0.01, run_immediately=True)
    assert s.is_due()


def test_interval_schedule_not_due_after_run():
    s = IntervalSchedule(seconds=3600, run_immediately=False)
    s.mark_ran()
    assert not s.is_due()


def test_cron_schedule_parse():
    s = CronSchedule("* * * * *")
    assert s._parsed is not None
    assert len(s._parsed["minute"]) == 60


def test_cron_schedule_invalid():
    with pytest.raises(ValueError):
        CronSchedule("* * *")


def test_scheduler_add_and_list():
    b = MemoryBackend()
    sched = Scheduler(b, tick_interval=9999)
    sched.add("cleanup", "myapp.cleanup", IntervalSchedule(3600))
    entries = sched.all_entries()
    assert len(entries) == 1
    assert entries[0].name == "cleanup"


def test_chunk_list():
    assert chunk_list([1, 2, 3, 4, 5], 2) == [[1, 2], [3, 4], [5]]


def test_flatten():
    assert flatten([[1, 2], [3], 4]) == [1, 2, 3, 4]
