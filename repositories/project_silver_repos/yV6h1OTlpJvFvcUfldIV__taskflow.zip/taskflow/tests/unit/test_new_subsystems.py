"""Tests for new subsystems: cache, DLQ, throttle, pipeline, dependency graph, aggregator."""

import time
import threading
import pytest
from datetime import datetime, timezone, timedelta

from taskflow.core.models import Task, TaskResult, TaskStatus, Priority
from taskflow.backends.memory import MemoryBackend
from taskflow.backends.cache import ResultCache, CacheEntry
from taskflow.backends.dlq import DeadLetterQueue, DeadLetterEntry
from taskflow.backends.locks import DistributedLock, LockNotHeldError
from taskflow.core.hooks import HookSet, HookRegistry, get_hook_registry
from taskflow.core.throttle import RateLimit, ThrottleBucket, ThrottleRegistry
from taskflow.core.pipeline import Pipeline
from taskflow.core.dependency import DependencyGraph, DependencyError
from taskflow.batch.aggregator import ResultAggregator, AggregateResult
from taskflow.monitoring.prometheus import PrometheusExporter, TaskDurationHistogram


def make_task(name="myapp.work", queue="default", **kwargs) -> Task:
    return Task(task_name=name, queue_name=queue, **kwargs)

def make_result(task_id, status=TaskStatus.SUCCESS, value=None, error=None) -> TaskResult:
    return TaskResult(
        task_id=task_id,
        status=status,
        return_value=value,
        error=error,
        completed_at=datetime.now(timezone.utc),
    )


# ============================================================
# Result Cache
# ============================================================

class TestResultCache:
    def test_put_and_get(self):
        cache = ResultCache(ttl_seconds=60)
        t = make_task()
        r = make_result(t.task_id, value=42)
        cache.put(r)
        fetched = cache.get(t.task_id)
        assert fetched is not None
        assert fetched.return_value == 42

    def test_miss_returns_none(self):
        cache = ResultCache()
        assert cache.get("nonexistent") is None

    def test_stats_tracks_hits_misses(self):
        cache = ResultCache(ttl_seconds=60)
        t = make_task()
        r = make_result(t.task_id)
        cache.put(r)
        cache.get(t.task_id)   # hit
        cache.get("other")     # miss
        s = cache.stats()
        assert s["hits"] == 1
        assert s["misses"] == 1

    def test_invalidate(self):
        cache = ResultCache(ttl_seconds=60)
        t = make_task()
        cache.put(make_result(t.task_id))
        cache.invalidate(t.task_id)
        assert cache.get(t.task_id) is None

    def test_max_size_evicts(self):
        cache = ResultCache(ttl_seconds=60, max_size=5)
        for i in range(10):
            t = make_task()
            cache.put(make_result(t.task_id))
        assert cache.stats()["size"] <= 5

    def test_clear(self):
        cache = ResultCache(ttl_seconds=60)
        cache.put(make_result("t1"))
        cache.put(make_result("t2"))
        cache.clear()
        assert cache.stats()["size"] == 0


# ============================================================
# Dead Letter Queue
# ============================================================

class TestDeadLetterQueue:
    def test_add_and_get(self):
        b = MemoryBackend()
        dlq = DeadLetterQueue(b)
        t = make_task()
        r = make_result(t.task_id, status=TaskStatus.FAILURE, error="boom")
        dlq.add(t, r, reason="max_retries_exceeded")
        entry = dlq.get(t.task_id)
        assert entry is not None
        assert entry.reason == "max_retries_exceeded"

    def test_list_by_queue(self):
        b = MemoryBackend()
        dlq = DeadLetterQueue(b)
        t1 = make_task(queue="q1")
        t2 = make_task(queue="q2")
        dlq.add(t1, make_result(t1.task_id, status=TaskStatus.FAILURE), "err")
        dlq.add(t2, make_result(t2.task_id, status=TaskStatus.FAILURE), "err")
        assert len(dlq.list(queue_name="q1")) == 1
        assert len(dlq.list(queue_name="q2")) == 1

    def test_requeue_resets_attempts(self):
        b = MemoryBackend()
        b.declare_queue("default")
        dlq = DeadLetterQueue(b)
        t = make_task()
        t.attempt = 5
        r = make_result(t.task_id, status=TaskStatus.FAILURE)
        dlq.add(t, r, "exhausted")
        dlq.requeue(t.task_id, reset_attempts=True)
        queued = b.dequeue("default", "w")
        assert queued is not None
        assert queued.attempt == 0  # reset, then incremented by dequeue

    def test_requeue_removes_from_dlq(self):
        b = MemoryBackend()
        dlq = DeadLetterQueue(b)
        t = make_task()
        r = make_result(t.task_id, status=TaskStatus.FAILURE)
        dlq.add(t, r, "err")
        dlq.requeue(t.task_id)
        assert dlq.get(t.task_id) is None

    def test_purge(self):
        b = MemoryBackend()
        dlq = DeadLetterQueue(b)
        for _ in range(5):
            t = make_task()
            dlq.add(t, make_result(t.task_id, status=TaskStatus.FAILURE), "err")
        assert dlq.purge() == 5
        assert dlq.stats()["total"] == 0

    def test_delete(self):
        b = MemoryBackend()
        dlq = DeadLetterQueue(b)
        t = make_task()
        dlq.add(t, make_result(t.task_id, status=TaskStatus.FAILURE), "err")
        assert dlq.delete(t.task_id)
        assert dlq.get(t.task_id) is None

    def test_stats(self):
        b = MemoryBackend()
        dlq = DeadLetterQueue(b)
        t = make_task(queue="reports")
        dlq.add(t, make_result(t.task_id, status=TaskStatus.FAILURE), "err")
        s = dlq.stats()
        assert s["total"] == 1
        assert "reports" in s["by_queue"]


# ============================================================
# Throttle
# ============================================================

class TestThrottle:
    def test_rate_limit_parse(self):
        rl = RateLimit.parse("10/minute")
        assert rl.count == 10
        assert rl.period_seconds == 60.0

    def test_rate_limit_parse_invalid(self):
        with pytest.raises(Exception):
            RateLimit.parse("fast")

    def test_bucket_allows_up_to_limit(self):
        limit = RateLimit(count=5, period_seconds=60.0)
        bucket = ThrottleBucket(limit)
        for _ in range(5):
            assert bucket.try_acquire()
        assert not bucket.try_acquire()

    def test_registry_no_limit_always_passes(self):
        reg = ThrottleRegistry()
        assert reg.try_acquire("unregistered.task")

    def test_registry_enforces_limit(self):
        reg = ThrottleRegistry()
        reg.register("myapp.job", "3/minute")
        for _ in range(3):
            assert reg.try_acquire("myapp.job")
        assert not reg.try_acquire("myapp.job")

    def test_retry_after_positive_when_full(self):
        limit = RateLimit(count=1, period_seconds=60.0)
        bucket = ThrottleBucket(limit)
        bucket.try_acquire()
        assert bucket.retry_after() > 0


# ============================================================
# Pipeline builder
# ============================================================

class TestPipeline:
    def test_single_step_submit(self):
        b = MemoryBackend()
        ids = Pipeline("test").then("step.a").build().submit(b)
        assert len(ids) == 1
        task = b.dequeue("default", "w")
        assert task is not None
        assert task.task_name == "step.a"

    def test_sequential_steps_parent_chain(self):
        b = MemoryBackend()
        ids = (
            Pipeline("seq")
            .then("step.a")
            .then("step.b")
            .build()
            .submit(b)
        )
        assert len(ids) == 2
        # step-b should have step-a as parent
        task_a = b.dequeue("default", "w")
        task_b = b.dequeue("default", "w")
        assert task_b.parent_id == task_a.task_id

    def test_fan_out_submits_multiple(self):
        b = MemoryBackend()
        ids = (
            Pipeline("fan")
            .fan_out("region.load", args_list=[["us"], ["eu"], ["ap"]])
            .build()
            .submit(b)
        )
        assert len(ids) == 3

    def test_empty_pipeline_raises(self):
        with pytest.raises(ValueError):
            Pipeline("empty").build()

    def test_task_count(self):
        p = (
            Pipeline("p")
            .then("a")
            .fan_out("b", args_list=[["x"], ["y"]])
            .then("c")
            .build()
        )
        assert p.task_count() == 4


# ============================================================
# Dependency graph
# ============================================================

class TestDependencyGraph:
    def test_add_and_submit_roots(self):
        b = MemoryBackend()
        g = DependencyGraph(b, poll_interval=0.05)
        g.add_task("a", "task.a")
        g.add_task("b", "task.b", depends_on=["a"])
        g.submit_all()
        # Only "a" should be enqueued immediately
        task = b.dequeue("default", "w")
        assert task is not None
        assert task.task_name == "task.a"
        assert b.dequeue("default", "w") is None
        g.stop()

    def test_cycle_detection(self):
        b = MemoryBackend()
        g = DependencyGraph(b)
        g.add_task("a", "task.a", depends_on=["b"])
        g.add_task("b", "task.b", depends_on=["a"])
        with pytest.raises(DependencyError, match="Cycle"):
            g.submit_all()

    def test_unknown_dependency_raises(self):
        b = MemoryBackend()
        g = DependencyGraph(b)
        g.add_task("a", "task.a", depends_on=["nonexistent"])
        with pytest.raises(DependencyError, match="Unknown dependency"):
            g.submit_all()

    def test_duplicate_logical_name_raises(self):
        b = MemoryBackend()
        g = DependencyGraph(b)
        g.add_task("a", "task.a")
        with pytest.raises(DependencyError, match="Duplicate"):
            g.add_task("a", "task.b")


# ============================================================
# Result Aggregator
# ============================================================

class TestResultAggregator:
    def _make_backend_with_results(self, n, status=TaskStatus.SUCCESS):
        b = MemoryBackend()
        ids = []
        for i in range(n):
            t = make_task()
            b.enqueue(t)
            b.dequeue("default", "w")
            b.store_result(make_result(t.task_id, status=status, value=i))
            ids.append(t.task_id)
        return b, ids

    def test_wait_all_succeed(self):
        b, ids = self._make_backend_with_results(5)
        agg = ResultAggregator(b, ids)
        result = agg.wait(timeout=2.0)
        assert result.is_complete
        assert len(result.succeeded) == 5
        assert not result.timed_out

    def test_values_in_order(self):
        b, ids = self._make_backend_with_results(3)
        agg = ResultAggregator(b, ids)
        result = agg.wait(timeout=2.0)
        assert len(result.values()) == 3

    def test_reduce_sum(self):
        b, ids = self._make_backend_with_results(4)
        agg = ResultAggregator(b, ids)
        result = agg.wait(timeout=2.0)
        total = result.reduce(lambda a, b: a + b, initial=0)
        assert total == sum(range(4))

    def test_fail_fast_returns_early(self):
        b = MemoryBackend()
        t1 = make_task()
        t2 = make_task()
        b.enqueue(t1); b.dequeue("default", "w")
        b.enqueue(t2); b.dequeue("default", "w")
        b.store_result(make_result(t1.task_id, status=TaskStatus.FAILURE, error="oops"))
        b.store_result(make_result(t2.task_id, value=99))
        agg = ResultAggregator(b, [t1.task_id, t2.task_id], fail_fast=True)
        result = agg.wait(timeout=2.0)
        assert t1.task_id in result.errors

    def test_success_rate(self):
        b = MemoryBackend()
        ids = []
        for i in range(4):
            t = make_task()
            b.enqueue(t); b.dequeue("default", "w")
            status = TaskStatus.SUCCESS if i < 3 else TaskStatus.FAILURE
            b.store_result(make_result(t.task_id, status=status))
            ids.append(t.task_id)
        agg = ResultAggregator(b, ids)
        result = agg.wait(timeout=2.0)
        assert result.success_rate == pytest.approx(0.75)


# ============================================================
# Prometheus exporter
# ============================================================

class TestPrometheusExporter:
    def test_render_contains_metric_names(self):
        b = MemoryBackend()
        exp = PrometheusExporter(b)
        exp.record_task_complete("default", "myapp.job", "success", 0.5)
        output = exp.render()
        assert "taskflow_tasks_total" in output
        assert "taskflow_uptime_seconds" in output

    def test_histogram_observe(self):
        hist = TaskDurationHistogram()
        hist.observe(0.1)
        hist.observe(0.5)
        hist.observe(15.0)
        snap = hist.snapshot()
        assert snap["count"] == 3
        assert snap["sum"] == pytest.approx(15.6)

    def test_render_retry_metric(self):
        b = MemoryBackend()
        exp = PrometheusExporter(b)
        exp.record_retry("myapp.job")
        exp.record_retry("myapp.job")
        output = exp.render()
        assert "taskflow_retry_total" in output

    def test_worker_metric(self):
        b = MemoryBackend()
        exp = PrometheusExporter(b)
        exp.record_worker("worker-1", True)
        exp.record_worker("worker-2", False)
        output = exp.render()
        assert 'taskflow_worker_active{worker="worker-1"} 1' in output
        assert 'taskflow_worker_active{worker="worker-2"} 0' in output
