import pytest
from taskflow.core.topo_sort import topo_sort

class TestTopoSort:
    def test_simple_chain(self):
        graph = {"a": [], "b": ["a"], "c": ["b"]}
        order = topo_sort(graph)
        assert order.index("a") < order.index("b") < order.index("c")

    def test_no_deps(self):
        graph = {"x": [], "y": [], "z": []}
        order = topo_sort(graph)
        assert set(order) == {"x", "y", "z"}

    def test_cycle_raises(self):
        graph = {"a": ["b"], "b": ["c"], "c": ["a"]}
        with pytest.raises(ValueError, match="Cycle"):
            topo_sort(graph)

    def test_diamond(self):
        graph = {"d": ["b", "c"], "b": ["a"], "c": ["a"], "a": []}
        order = topo_sort(graph)
        assert order[0] == "a"
        assert order[-1] == "d"

    def test_single_node(self):
        assert topo_sort({"solo": []}) == ["solo"]
