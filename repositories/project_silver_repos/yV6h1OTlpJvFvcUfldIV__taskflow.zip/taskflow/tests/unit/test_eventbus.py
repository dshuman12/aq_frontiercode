import threading
import pytest
from taskflow.events.bus import EventBus

class TestEventBus:
    def test_subscribe_and_publish(self):
        bus = EventBus()
        received = []
        bus.subscribe("task.done", lambda ev, p: received.append(p))
        bus.publish("task.done", {"id": "t1"})
        assert received == [{"id": "t1"}]

    def test_unsubscribe(self):
        bus = EventBus()
        received = []
        h = lambda ev, p: received.append(p)
        bus.subscribe("x", h)
        bus.unsubscribe("x", h)
        bus.publish("x", 1)
        assert received == []

    def test_once_fires_once(self):
        bus = EventBus()
        count = [0]
        bus.once("ev", lambda e, p: count.__setitem__(0, count[0] + 1))
        bus.publish("ev", None)
        bus.publish("ev", None)
        assert count[0] == 1

    def test_handler_exception_does_not_propagate(self):
        bus = EventBus()
        bus.subscribe("bad", lambda e, p: 1/0)
        bus.publish("bad", None)  # should not raise

    def test_thread_safe_publish(self):
        bus = EventBus()
        results = []
        bus.subscribe("t", lambda e, p: results.append(p))
        threads = [threading.Thread(target=bus.publish, args=("t", i)) for i in range(20)]
        [t.start() for t in threads]
        [t.join() for t in threads]
        assert len(results) == 20
