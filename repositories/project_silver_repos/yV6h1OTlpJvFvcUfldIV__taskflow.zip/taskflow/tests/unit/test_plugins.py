import pytest
from taskflow.plugins import load_backend, register_backend
from taskflow.serializers.registry import register, dumps, loads, available

class TestPlugins:
    def test_load_memory_backend(self):
        backend = load_backend("memory")
        from taskflow.backends.memory import MemoryBackend
        assert isinstance(backend, MemoryBackend)

    def test_load_unknown_raises(self):
        with pytest.raises(ImportError):
            load_backend("nonexistent_backend")

    def test_register_and_load(self):
        register_backend("mem2", "taskflow.backends.memory:MemoryBackend")
        backend = load_backend("mem2")
        from taskflow.backends.memory import MemoryBackend
        assert isinstance(backend, MemoryBackend)

class TestSerializerRegistry:
    def setup_method(self):
        from taskflow.serializers.json_serializer import JSONSerializer
        register("application/json", JSONSerializer())

    def test_round_trip(self):
        data = {"key": "value", "num": 42}
        serialized = dumps(data)
        assert loads(serialized) == data

    def test_unknown_content_type(self):
        with pytest.raises(KeyError):
            dumps({}, content_type="application/cbor")

    def test_available_lists_registered(self):
        assert "application/json" in available()
