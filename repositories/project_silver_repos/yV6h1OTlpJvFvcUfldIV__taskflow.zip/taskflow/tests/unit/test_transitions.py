import pytest
from taskflow.core.models import TaskStatus
from taskflow.core.transitions import (
    InvalidTransition, can_transition, validate_transition
)

class TestTransitions:
    def test_pending_to_running_allowed(self):
        validate_transition(TaskStatus.PENDING, TaskStatus.RUNNING)

    def test_success_is_terminal(self):
        assert not can_transition(TaskStatus.SUCCESS, TaskStatus.PENDING)

    def test_failed_can_retry(self):
        assert can_transition(TaskStatus.FAILED, TaskStatus.PENDING)

    def test_invalid_raises(self):
        with pytest.raises(InvalidTransition):
            validate_transition(TaskStatus.SUCCESS, TaskStatus.RUNNING)

    def test_all_terminal_states_have_no_outgoing(self):
        for s in (TaskStatus.SUCCESS, TaskStatus.CANCELLED, TaskStatus.EXPIRED):
            assert not can_transition(s, TaskStatus.RUNNING)
