
## v0.6.0 — 2023-12-20

### Added
- `core/priority_inheritance.py` — propagate parent task priority to child groups
- `utils/pagination.py` — offset and cursor-based result pagination
- `monitoring/heartbeat.py` — worker liveness monitoring with stale detection
- `core/backoff.py` — pluggable retry backoff strategies (fixed, linear, exponential, jitter)
- `core/tagging.py` — inverted tag index with AND / OR / NOT query support
- `backends/ttl_store.py` — TTL key-value store with background eviction
- `monitoring/event_log.py` — append-only task audit trail with rotation
- `core/quota.py` — per-queue rolling-window quota enforcement
- `workers/autoscaler.py` — proportional auto-scaling worker pool
