"""
Serializer registry: maps content-type strings to serializer instances.
Allows tasks to negotiate serialization format at enqueue time.
"""
from __future__ import annotations
from typing import Any, Dict
from taskflow.serializers.base import BaseSerializer

_registry: Dict[str, BaseSerializer] = {}

def register(content_type: str, serializer: BaseSerializer) -> None:
    _registry[content_type] = serializer

def get(content_type: str) -> BaseSerializer:
    if content_type not in _registry:
        raise KeyError(f"No serializer registered for {content_type!r}")
    return _registry[content_type]

def dumps(data: Any, content_type: str = "application/json") -> bytes:
    return get(content_type).dumps(data)

def loads(data: bytes, content_type: str = "application/json") -> Any:
    return get(content_type).loads(data)

def available() -> list[str]:
    return list(_registry.keys())
