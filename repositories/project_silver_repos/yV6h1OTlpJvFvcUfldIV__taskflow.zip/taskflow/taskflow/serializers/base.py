"""
Serializers for taskflow task arguments and return values.

Supports JSON (default, safe) and Pickle (flexible, Python-only).
Custom serializers can be registered via the serializer registry.
"""

from __future__ import annotations

import base64
import json
import pickle
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional, Type


class SerializationError(Exception):
    """Raised when serialization or deserialization fails."""


class BaseSerializer(ABC):
    """Abstract serializer interface."""

    name: str = ""

    @abstractmethod
    def dumps(self, value: Any) -> bytes:
        """Serialize value to bytes."""

    @abstractmethod
    def loads(self, data: bytes) -> Any:
        """Deserialize bytes to value."""

    def dumps_str(self, value: Any) -> str:
        """Serialize to a base64-encoded string (safe for JSON transport)."""
        return base64.b64encode(self.dumps(value)).decode("ascii")

    def loads_str(self, data: str) -> Any:
        """Deserialize from a base64-encoded string."""
        return self.loads(base64.b64decode(data.encode("ascii")))


class JSONSerializer(BaseSerializer):
    """
    JSON serializer. Safe, human-readable, but limited to JSON-compatible types.

    Handles datetime objects by converting to ISO 8601 strings.
    Falls back gracefully for unknown types via __repr__.
    """

    name = "json"

    def __init__(self, indent: Optional[int] = None) -> None:
        self.indent = indent

    def dumps(self, value: Any) -> bytes:
        try:
            return json.dumps(value, default=self._default, indent=self.indent).encode("utf-8")
        except Exception as exc:
            raise SerializationError(f"JSON serialization failed: {exc}") from exc

    def loads(self, data: bytes) -> Any:
        try:
            return json.loads(data.decode("utf-8"))
        except Exception as exc:
            raise SerializationError(f"JSON deserialization failed: {exc}") from exc

    def _default(self, obj: Any) -> Any:
        from datetime import date, datetime
        if isinstance(obj, (datetime, date)):
            return obj.isoformat()
        if hasattr(obj, "__dict__"):
            return obj.__dict__
        return repr(obj)


class PickleSerializer(BaseSerializer):
    """
    Pickle serializer. Supports arbitrary Python objects but is Python-only
    and has security implications (never deserialize untrusted data).
    """

    name = "pickle"

    def __init__(self, protocol: int = pickle.HIGHEST_PROTOCOL) -> None:
        self.protocol = protocol

    def dumps(self, value: Any) -> bytes:
        try:
            return pickle.dumps(value, protocol=self.protocol)
        except Exception as exc:
            raise SerializationError(f"Pickle serialization failed: {exc}") from exc

    def loads(self, data: bytes) -> Any:
        try:
            return pickle.loads(data)  # noqa: S301 — intentional, caller's responsibility
        except Exception as exc:
            raise SerializationError(f"Pickle deserialization failed: {exc}") from exc


class MsgPackSerializer(BaseSerializer):
    """
    MessagePack serializer. Fast and compact, requires the msgpack package.
    Falls back to JSON if msgpack is not installed.
    """

    name = "msgpack"

    def __init__(self) -> None:
        try:
            import msgpack  # type: ignore[import]
            self._msgpack = msgpack
        except ImportError:
            self._msgpack = None

    def dumps(self, value: Any) -> bytes:
        if self._msgpack is None:
            return JSONSerializer().dumps(value)
        try:
            return self._msgpack.packb(value, use_bin_type=True)
        except Exception as exc:
            raise SerializationError(f"MsgPack serialization failed: {exc}") from exc

    def loads(self, data: bytes) -> Any:
        if self._msgpack is None:
            return JSONSerializer().loads(data)
        try:
            return self._msgpack.unpackb(data, raw=False)
        except Exception as exc:
            raise SerializationError(f"MsgPack deserialization failed: {exc}") from exc


# ---------------------------------------------------------------------------
# Serializer registry
# ---------------------------------------------------------------------------

class SerializerRegistry:
    """Registry of named serializers."""

    def __init__(self) -> None:
        self._serializers: Dict[str, BaseSerializer] = {}
        # Register defaults
        self.register(JSONSerializer())
        self.register(PickleSerializer())
        self.register(MsgPackSerializer())

    def register(self, serializer: BaseSerializer) -> None:
        self._serializers[serializer.name] = serializer

    def get(self, name: str) -> BaseSerializer:
        s = self._serializers.get(name)
        if s is None:
            raise SerializationError(
                f"Unknown serializer: {name!r}. "
                f"Available: {list(self._serializers)}"
            )
        return s

    def available(self) -> list:
        return list(self._serializers.keys())


_registry = SerializerRegistry()


def get_serializer(name: str = "json") -> BaseSerializer:
    return _registry.get(name)


def serialize(value: Any, serializer_name: str = "json") -> str:
    """Serialize a value to a base64 string using the named serializer."""
    return get_serializer(serializer_name).dumps_str(value)


def deserialize(data: str, serializer_name: str = "json") -> Any:
    """Deserialize a base64 string using the named serializer."""
    return get_serializer(serializer_name).loads_str(data)
