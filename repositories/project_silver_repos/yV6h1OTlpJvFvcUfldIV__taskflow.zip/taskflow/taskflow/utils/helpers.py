"""
Utility helpers for taskflow.

Includes: token bucket rate limiter, task deduplicator,
circuit breaker, and retry helpers.
"""

from __future__ import annotations

import hashlib
import json
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from enum import Enum
from typing import Any, Callable, Dict, Optional, Set


# ---------------------------------------------------------------------------
# Token bucket rate limiter
# ---------------------------------------------------------------------------

class RateLimiter:
    """
    Thread-safe token bucket rate limiter.

    Allows `rate` calls per `period` seconds. Extra calls block until
    a token is available, or raise RateLimitExceeded if a timeout is set.
    """

    def __init__(
        self,
        rate: float,
        period: float = 1.0,
        burst: Optional[float] = None,
    ) -> None:
        self.rate = rate          # tokens per period
        self.period = period      # seconds
        self.burst = burst or rate
        self._tokens = float(self.burst)
        self._last_refill = time.monotonic()
        self._lock = threading.Lock()

    def _refill(self) -> None:
        now = time.monotonic()
        elapsed = now - self._last_refill
        added = elapsed * (self.rate / self.period)
        self._tokens = min(self.burst, self._tokens + added)
        self._last_refill = now

    def acquire(self, count: float = 1.0, timeout: Optional[float] = None) -> bool:
        """
        Acquire `count` tokens. Blocks until available or timeout expires.

        Returns True if acquired, False if timed out.
        """
        deadline = time.monotonic() + (timeout or float("inf"))
        while True:
            with self._lock:
                self._refill()
                if self._tokens >= count:
                    self._tokens -= count
                    return True
            if time.monotonic() >= deadline:
                return False
            time.sleep(0.01)

    def try_acquire(self, count: float = 1.0) -> bool:
        """Try to acquire without blocking. Returns False immediately if unavailable."""
        with self._lock:
            self._refill()
            if self._tokens >= count:
                self._tokens -= count
                return True
        return False

    @property
    def available_tokens(self) -> float:
        with self._lock:
            self._refill()
            return self._tokens


# ---------------------------------------------------------------------------
# Task deduplicator
# ---------------------------------------------------------------------------

class TaskDeduplicator:
    """
    Prevents duplicate tasks from being enqueued within a time window.

    Two tasks are considered duplicates if they have the same name, args,
    and kwargs. The fingerprint is a hash of these three values.
    """

    def __init__(self, window_seconds: float = 300.0) -> None:
        self.window_seconds = window_seconds
        self._seen: Dict[str, float] = {}  # fingerprint -> enqueue_time
        self._lock = threading.Lock()

    def is_duplicate(self, task_name: str, args: list, kwargs: dict) -> bool:
        """Return True if an identical task was enqueued within the window."""
        fp = self._fingerprint(task_name, args, kwargs)
        now = time.monotonic()
        with self._lock:
            self._evict(now)
            return fp in self._seen

    def record(self, task_name: str, args: list, kwargs: dict) -> None:
        """Record that a task was enqueued."""
        fp = self._fingerprint(task_name, args, kwargs)
        now = time.monotonic()
        with self._lock:
            self._seen[fp] = now

    def _fingerprint(self, name: str, args: list, kwargs: dict) -> str:
        payload = json.dumps(
            {"n": name, "a": args, "k": kwargs}, sort_keys=True, default=str
        )
        return hashlib.sha256(payload.encode()).hexdigest()[:16]

    def _evict(self, now: float) -> None:
        cutoff = now - self.window_seconds
        stale = [k for k, t in self._seen.items() if t < cutoff]
        for k in stale:
            del self._seen[k]

    def clear(self) -> None:
        with self._lock:
            self._seen.clear()

    @property
    def active_count(self) -> int:
        with self._lock:
            self._evict(time.monotonic())
            return len(self._seen)


# ---------------------------------------------------------------------------
# Circuit breaker
# ---------------------------------------------------------------------------

class CircuitState(Enum):
    CLOSED = "closed"       # normal operation
    OPEN = "open"           # rejecting calls
    HALF_OPEN = "half_open" # testing recovery


class CircuitBreakerError(Exception):
    """Raised when a call is rejected because the circuit is open."""


@dataclass
class CircuitBreaker:
    """
    Circuit breaker for protecting task execution from cascading failures.

    States:
    - CLOSED: calls pass through; failures are counted
    - OPEN: calls are rejected immediately; enters HALF_OPEN after reset_timeout
    - HALF_OPEN: one call is allowed through; closes on success, reopens on failure
    """

    name: str
    failure_threshold: int = 5
    success_threshold: int = 2
    reset_timeout: float = 60.0

    _state: CircuitState = field(default=CircuitState.CLOSED, init=False)
    _failure_count: int = field(default=0, init=False)
    _success_count: int = field(default=0, init=False)
    _last_failure_time: Optional[float] = field(default=None, init=False)
    _lock: threading.Lock = field(default_factory=threading.Lock, init=False)

    @property
    def state(self) -> CircuitState:
        with self._lock:
            if self._state == CircuitState.OPEN:
                if self._last_failure_time and (
                    time.monotonic() - self._last_failure_time >= self.reset_timeout
                ):
                    self._state = CircuitState.HALF_OPEN
            return self._state

    def call(self, func: Callable, *args: Any, **kwargs: Any) -> Any:
        """
        Execute func through the circuit breaker.

        Raises CircuitBreakerError if the circuit is open.
        """
        state = self.state
        if state == CircuitState.OPEN:
            raise CircuitBreakerError(
                f"Circuit breaker '{self.name}' is OPEN. "
                f"Retry after {self.reset_timeout}s."
            )

        try:
            result = func(*args, **kwargs)
            self._on_success()
            return result
        except Exception as exc:
            self._on_failure()
            raise

    def _on_success(self) -> None:
        with self._lock:
            self._failure_count = 0
            if self._state == CircuitState.HALF_OPEN:
                self._success_count += 1
                if self._success_count >= self.success_threshold:
                    self._state = CircuitState.CLOSED
                    self._success_count = 0

    def _on_failure(self) -> None:
        with self._lock:
            self._failure_count += 1
            self._last_failure_time = time.monotonic()
            if self._state == CircuitState.HALF_OPEN:
                self._state = CircuitState.OPEN
                self._success_count = 0
            elif self._failure_count >= self.failure_threshold:
                self._state = CircuitState.OPEN

    def reset(self) -> None:
        with self._lock:
            self._state = CircuitState.CLOSED
            self._failure_count = 0
            self._success_count = 0
            self._last_failure_time = None

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "state": self.state.value,
            "failure_count": self._failure_count,
            "failure_threshold": self.failure_threshold,
            "reset_timeout": self.reset_timeout,
        }


# ---------------------------------------------------------------------------
# Retry helpers
# ---------------------------------------------------------------------------

def retry(
    func: Callable,
    max_attempts: int = 3,
    delay: float = 1.0,
    backoff: float = 2.0,
    exceptions: tuple = (Exception,),
) -> Any:
    """
    Call func with automatic retries on failure.

    Parameters
    ----------
    func:
        Callable to invoke.
    max_attempts:
        Maximum total attempts (including first).
    delay:
        Initial delay between retries in seconds.
    backoff:
        Multiplier applied to delay after each attempt.
    exceptions:
        Exception types that trigger a retry.
    """
    last_exc: Optional[Exception] = None
    current_delay = delay

    for attempt in range(1, max_attempts + 1):
        try:
            return func()
        except exceptions as exc:
            last_exc = exc
            if attempt < max_attempts:
                time.sleep(current_delay)
                current_delay *= backoff

    raise last_exc  # type: ignore[misc]


def with_timeout(func: Callable, timeout: float, *args: Any, **kwargs: Any) -> Any:
    """
    Call func with a timeout. Raises TimeoutError if it doesn't complete in time.
    """
    result_holder: list = []
    exc_holder: list = []
    done = threading.Event()

    def run() -> None:
        try:
            result_holder.append(func(*args, **kwargs))
        except Exception as e:
            exc_holder.append(e)
        finally:
            done.set()

    t = threading.Thread(target=run, daemon=True)
    t.start()
    if not done.wait(timeout=timeout):
        raise TimeoutError(f"Function timed out after {timeout}s")
    if exc_holder:
        raise exc_holder[0]
    return result_holder[0] if result_holder else None


# ---------------------------------------------------------------------------
# Misc helpers
# ---------------------------------------------------------------------------

def chunk_list(lst: list, size: int) -> list:
    """Split a list into chunks of at most `size` items."""
    return [lst[i:i + size] for i in range(0, len(lst), size)]


def flatten(nested: list) -> list:
    """Flatten one level of nesting."""
    result = []
    for item in nested:
        if isinstance(item, list):
            result.extend(item)
        else:
            result.append(item)
    return result


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def seconds_until(dt: datetime) -> float:
    """Return seconds until a future datetime (negative if in the past)."""
    return (dt - utcnow()).total_seconds()
