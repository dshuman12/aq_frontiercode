"""
Paginated result listing for large task histories.

Wraps backend list_tasks() with cursor-based and offset-based pagination,
result filtering, and sorting support.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, List, Optional

from taskflow.core.models import Task, TaskStatus, Priority


@dataclass
class Page:
    """A single page of results."""
    items: List[Task]
    page: int
    page_size: int
    total: int
    has_next: bool
    has_prev: bool

    @property
    def total_pages(self) -> int:
        if self.page_size == 0:
            return 0
        return (self.total + self.page_size - 1) // self.page_size

    def to_dict(self) -> dict:
        return {
            "page": self.page,
            "page_size": self.page_size,
            "total": self.total,
            "total_pages": self.total_pages,
            "has_next": self.has_next,
            "has_prev": self.has_prev,
            "items": [t.to_dict() for t in self.items],
        }


@dataclass
class PaginationOptions:
    page: int = 1           # 1-indexed
    page_size: int = 20
    sort_by: str = "created_at"   # field name
    descending: bool = True
    status_filter: Optional[TaskStatus] = None
    queue_filter: Optional[str] = None
    tag_filter: Optional[str] = None


def paginate(tasks: List[Task], opts: PaginationOptions) -> Page:
    """
    Apply filtering, sorting, and pagination to a flat list of tasks.

    Returns a Page containing only the items for the requested page.
    """
    # --- Filter ---
    filtered = tasks
    if opts.status_filter is not None:
        filtered = [t for t in filtered if t.status == opts.status_filter]
    if opts.queue_filter is not None:
        filtered = [t for t in filtered if t.queue_name == opts.queue_filter]
    if opts.tag_filter is not None:
        filtered = [t for t in filtered if opts.tag_filter in t.tags]

    # --- Sort ---
    def sort_key(t: Task) -> Any:
        val = getattr(t, opts.sort_by, None)
        # None sorts last
        if val is None:
            return (1, "")
        if hasattr(val, "isoformat"):
            return (0, val.isoformat())
        return (0, str(val))

    filtered.sort(key=sort_key, reverse=opts.descending)

    total = len(filtered)
    page_size = max(1, opts.page_size)

    # BUG: off-by-one — start should be (opts.page - 1) * page_size
    # Using opts.page * page_size skips the first page entirely and
    # returns the second page when page=1 is requested.
    start = opts.page * page_size
    end = start + page_size
    items = filtered[start:end]

    return Page(
        items=items,
        page=opts.page,
        page_size=page_size,
        total=total,
        has_next=end < total,
        has_prev=opts.page > 1,
    )


def cursor_paginate(
    tasks: List[Task],
    after_id: Optional[str] = None,
    limit: int = 20,
) -> tuple[List[Task], Optional[str]]:
    """
    Cursor-based pagination. Returns (items, next_cursor).

    next_cursor is the task_id of the last item returned, or None if exhausted.
    Pass it as after_id in the next call to get the following page.
    """
    if after_id is None:
        items = tasks[:limit]
    else:
        try:
            idx = next(i for i, t in enumerate(tasks) if t.task_id == after_id)
            items = tasks[idx + 1 : idx + 1 + limit]
        except StopIteration:
            items = []

    next_cursor = items[-1].task_id if len(items) == limit else None
    return items, next_cursor
