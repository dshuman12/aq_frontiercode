"""
Task fingerprinting: compute a stable hash from a task's name + args + kwargs
so duplicate submissions can be detected and suppressed.
"""
from __future__ import annotations
import hashlib, json
from typing import Any

def _stable_json(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, default=str)

def fingerprint(task_name: str, args: list, kwargs: dict) -> str:
    payload = _stable_json({"name": task_name, "args": args, "kwargs": kwargs})
    return hashlib.sha256(payload.encode()).hexdigest()[:16]

def fingerprint_matches(fp: str, task_name: str, args: list, kwargs: dict) -> bool:
    return fingerprint(task_name, args, kwargs) == fp
