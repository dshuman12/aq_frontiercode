"""
JSON structured log formatter.
Outputs each log record as a single-line JSON object compatible with
log aggregation systems (Datadog, CloudWatch, Loki, etc.).
"""
from __future__ import annotations
import json, logging, traceback
from datetime import datetime, timezone

class JSONFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        obj = {
            "ts":      datetime.fromtimestamp(record.created, tz=timezone.utc).isoformat(),
            "level":   record.levelname,
            "logger":  record.name,
            "message": record.getMessage(),
        }
        if record.exc_info:
            obj["exception"] = "".join(traceback.format_exception(*record.exc_info))
        for key, val in record.__dict__.items():
            if key.startswith("tf_"):           # taskflow-specific context fields
                obj[key[3:]] = val
        return json.dumps(obj)
