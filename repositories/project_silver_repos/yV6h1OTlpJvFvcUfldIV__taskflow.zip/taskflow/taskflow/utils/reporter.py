"""Simple text/table formatter for task status reports."""
from __future__ import annotations
from collections import Counter
from typing import List
from taskflow.core.models import Task, TaskStatus

def summary(tasks: List[Task]) -> dict:
    counts = Counter(t.status.value for t in tasks)
    return {
        "total": len(tasks),
        "by_status": dict(counts),
        "queues": list({t.queue_name for t in tasks}),
    }

def tabulate(tasks: List[Task], max_rows: int = 20) -> str:
    header = f"{'ID':<36}  {'NAME':<24}  {'STATUS':<12}  {'QUEUE':<16}"
    sep = "-" * len(header)
    rows = [header, sep]
    for t in tasks[:max_rows]:
        rows.append(
            f"{t.task_id:<36}  {t.name:<24}  {t.status.value:<12}  {t.queue_name:<16}"
        )
    if len(tasks) > max_rows:
        rows.append(f"  ... and {len(tasks) - max_rows} more")
    return "\n".join(rows)
