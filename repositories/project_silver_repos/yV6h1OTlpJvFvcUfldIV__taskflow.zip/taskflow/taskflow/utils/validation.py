"""Input validation helpers shared across subsystems."""
from __future__ import annotations
import re

_QUEUE_RE = re.compile(r'^[a-zA-Z0-9_.-]{1,128}$')
_TAG_RE   = re.compile(r'^[a-zA-Z0-9_:/-]{1,64}$')

class ValidationError(ValueError):
    pass

def validate_queue_name(name: str) -> str:
    if not _QUEUE_RE.match(name):
        raise ValidationError(
            f"Invalid queue name {name!r}. "
            "Must be 1-128 chars: letters, digits, '_', '.', '-'."
        )
    return name

def validate_tag(tag: str) -> str:
    if not _TAG_RE.match(tag):
        raise ValidationError(
            f"Invalid tag {tag!r}. "
            "Must be 1-64 chars: letters, digits, '_', ':', '/', '-'."
        )
    return tag

def validate_tags(tags: list[str]) -> list[str]:
    return [validate_tag(t) for t in tags]
