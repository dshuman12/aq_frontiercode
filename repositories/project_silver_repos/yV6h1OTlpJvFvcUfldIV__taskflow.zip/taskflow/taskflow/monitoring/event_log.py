"""
Append-only audit log for task lifecycle events.

Records every status transition, retry, enqueue, cancel, and expiry
with timestamps and metadata. Supports per-task event history retrieval,
global log rotation, and structured export for compliance or debugging.
"""

from __future__ import annotations

import json
import threading
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional


class EventKind(str, Enum):
    ENQUEUED = "enqueued"
    STARTED = "started"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    RETRIED = "retried"
    CANCELLED = "cancelled"
    EXPIRED = "expired"
    REQUEUED = "requeued"
    PRIORITY_CHANGED = "priority_changed"
    TAG_ADDED = "tag_added"
    TAG_REMOVED = "tag_removed"


@dataclass
class TaskEvent:
    task_id: str
    kind: EventKind
    timestamp: str = field(
        default_factory=lambda: datetime.now(tz=timezone.utc).isoformat()
    )
    worker_id: Optional[str] = None
    queue_name: Optional[str] = None
    attempt: int = 1
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        d = asdict(self)
        d["kind"] = self.kind.value
        return d


class EventLog:
    """
    Thread-safe in-process event log with bounded capacity.

    Events are stored globally and also indexed per task_id for fast retrieval.
    When the global log exceeds `max_events`, oldest entries are dropped.
    """

    def __init__(self, max_events: int = 10_000) -> None:
        self.max_events = max_events
        self._events: List[TaskEvent] = []
        self._by_task: Dict[str, List[TaskEvent]] = {}
        self._lock = threading.RLock()

    def record(self, event: TaskEvent) -> None:
        with self._lock:
            self._events.append(event)
            self._by_task.setdefault(event.task_id, []).append(event)
            self._rotate()

    def _rotate(self) -> None:
        """
        Drop oldest events when over capacity.

        BUG: slices self._events[-self.max_events:] which keeps the NEWEST
        events — but then reassigns to self._events, which is correct for
        the global list. However, the per-task index (_by_task) is NOT
        updated after rotation, so task-level history still references the
        evicted event objects. After rotation, for any evicted event, calling
        events_for(task_id) returns stale entries that are no longer in the
        global log — counts diverge and callers see ghost events.

        Additionally, _rotate is called after every single append, making it
        O(n) on every write once the log is full. Should only slice when
        len > max_events.
        """
        if len(self._events) > self.max_events:
            # Keeps newest — global list is correct, but _by_task not updated
            self._events = self._events[-self.max_events :]

    def events_for(self, task_id: str) -> List[TaskEvent]:
        with self._lock:
            return list(self._by_task.get(task_id, []))

    def all_events(self) -> List[TaskEvent]:
        with self._lock:
            return list(self._events)

    def events_since(self, since_iso: str) -> List[TaskEvent]:
        with self._lock:
            return [e for e in self._events if e.timestamp >= since_iso]

    def events_by_kind(self, kind: EventKind) -> List[TaskEvent]:
        with self._lock:
            return [e for e in self._events if e.kind == kind]

    def clear_task(self, task_id: str) -> int:
        """Remove all events for a specific task. Returns count removed."""
        with self._lock:
            removed = len(self._by_task.pop(task_id, []))
            self._events = [e for e in self._events if e.task_id != task_id]
            return removed

    def export_jsonl(self) -> str:
        with self._lock:
            return "\n".join(json.dumps(e.to_dict()) for e in self._events)

    def __len__(self) -> int:
        with self._lock:
            return len(self._events)

    def stats(self) -> dict:
        with self._lock:
            kind_counts: Dict[str, int] = {}
            for e in self._events:
                kind_counts[e.kind.value] = kind_counts.get(e.kind.value, 0) + 1
            return {
                "total": len(self._events),
                "capacity": self.max_events,
                "tasks_tracked": len(self._by_task),
                "by_kind": kind_counts,
            }
