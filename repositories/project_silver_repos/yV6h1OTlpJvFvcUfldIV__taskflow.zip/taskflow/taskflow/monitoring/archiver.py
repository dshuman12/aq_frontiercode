"""
Task archiver for taskflow.

Periodically snapshots completed and failed tasks from the backend
into a JSONL archive file. Useful for long-term auditing when the
backend's result store has limited retention.

Archiver runs as a background thread and drains completed results
from the backend at a configurable interval. Archived tasks are
written to a rotating JSONL file.
"""

from __future__ import annotations

import gzip
import json
import logging
import os
import threading
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from taskflow.core.models import TaskStatus

logger = logging.getLogger(__name__)


@dataclass
class ArchiveConfig:
    directory: str
    prefix: str = "taskflow-archive"
    rotate_mb: float = 100.0         # rotate file when it exceeds this size
    compress: bool = True            # gzip rotate files
    flush_interval_seconds: float = 60.0
    statuses_to_archive: tuple = (
        TaskStatus.SUCCESS,
        TaskStatus.FAILURE,
        TaskStatus.EXPIRED,
    )


class TaskArchiver:
    """
    Background archiver that writes completed task results to JSONL.

    Thread-safe write loop. File rotation happens synchronously when
    the active file exceeds rotate_mb.
    """

    def __init__(self, backend: Any, config: ArchiveConfig) -> None:
        self._backend = backend
        self._config = config
        self._lock = threading.Lock()
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        self._archived_count = 0
        self._active_file: Optional[Any] = None
        self._active_path: Optional[Path] = None
        Path(config.directory).mkdir(parents=True, exist_ok=True)
        self._open_file()

    def _open_file(self) -> None:
        ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
        name = f"{self._config.prefix}-{ts}.jsonl"
        self._active_path = Path(self._config.directory) / name
        self._active_file = open(self._active_path, "a", encoding="utf-8")

    def _rotate(self) -> None:
        if self._active_file:
            self._active_file.close()
        if self._config.compress and self._active_path:
            gz_path = self._active_path.with_suffix(".jsonl.gz")
            with open(self._active_path, "rb") as f_in:
                with gzip.open(gz_path, "wb") as f_out:
                    f_out.write(f_in.read())
            os.remove(self._active_path)
        self._open_file()

    def _should_rotate(self) -> bool:
        if self._active_path is None:
            return False
        try:
            size_mb = self._active_path.stat().st_size / (1024 * 1024)
            return size_mb >= self._config.rotate_mb
        except FileNotFoundError:
            return False

    def _archive_results(self) -> int:
        """Fetch completed results from backend and write to archive."""
        count = 0
        try:
            # Get all tasks in terminal states
            for status in self._config.statuses_to_archive:
                tasks = self._backend.list_tasks(status=status, limit=500)
                for task in tasks:
                    result = self._backend.get_result(task.task_id)
                    if result is None:
                        continue
                    record = {
                        "archived_at": datetime.now(timezone.utc).isoformat(),
                        "task": task.to_dict(),
                        "result": result.to_dict(),
                    }
                    with self._lock:
                        # BUG: _should_rotate() and _rotate() are called without
                        # the lock held, but _active_file write is inside the lock.
                        # If two threads call _archive_results() (shouldn't happen,
                        # but if _flush is called externally while the loop runs),
                        # the rotate check + write is not atomic — rotation can
                        # happen between the check and the write, leaving the
                        # new file handle written to after rotation starts.
                        if self._should_rotate():
                            self._rotate()
                        self._active_file.write(json.dumps(record) + "\n")
                    count += 1
        except Exception as exc:
            logger.error("Archiver error: %s", exc)
        return count

    def flush(self) -> int:
        """Manually trigger an archive pass. Returns count archived."""
        n = self._archive_results()
        self._archived_count += n
        with self._lock:
            if self._active_file:
                self._active_file.flush()
        return n

    def start(self) -> None:
        self._thread = threading.Thread(
            target=self._run, daemon=True, name="taskflow-archiver"
        )
        self._thread.start()
        logger.info("Archiver started (interval=%.0fs)", self._config.flush_interval_seconds)

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=self._config.flush_interval_seconds + 2)
        with self._lock:
            if self._active_file:
                self._active_file.close()
        logger.info("Archiver stopped. Total archived: %d", self._archived_count)

    def _run(self) -> None:
        while not self._stop.is_set():
            self._stop.wait(timeout=self._config.flush_interval_seconds)
            if not self._stop.is_set():
                n = self._archive_results()
                self._archived_count += n
                logger.debug("Archiver flushed %d records", n)

    def stats(self) -> dict:
        return {
            "archived_total": self._archived_count,
            "active_file": str(self._active_path),
            "directory": self._config.directory,
        }
