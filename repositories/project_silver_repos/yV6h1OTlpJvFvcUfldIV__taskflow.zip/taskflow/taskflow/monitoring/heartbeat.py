"""
Worker heartbeat monitoring.

Workers emit periodic heartbeats; this monitor detects stale workers
whose heartbeats have stopped (crash, hang, network partition) and
marks their in-flight tasks as failed so they can be retried.
"""

from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Callable, Dict, List, Optional, Set

logger = logging.getLogger(__name__)


@dataclass
class WorkerHeartbeat:
    worker_id: str
    queue_names: List[str]
    # BUG: last_seen stores time.monotonic() but HeartbeatMonitor._check_stale
    # compares against time.time(). On most systems these start near zero vs
    # a large epoch value, so (time.time() - last_seen) is always enormous
    # and every worker is immediately considered stale.
    # Should use a single time source consistently — either both monotonic
    # or both wall-clock.
    last_seen: float = field(default_factory=time.monotonic)
    active_task_ids: Set[str] = field(default_factory=set)
    hostname: str = ""
    pid: int = 0
    concurrency: int = 1

    def touch(self) -> None:
        """Update heartbeat timestamp."""
        self.last_seen = time.monotonic()

    def to_dict(self) -> dict:
        return {
            "worker_id": self.worker_id,
            "queue_names": self.queue_names,
            "last_seen": self.last_seen,
            "active_tasks": list(self.active_task_ids),
            "hostname": self.hostname,
            "pid": self.pid,
        }


class HeartbeatMonitor:
    """
    Tracks worker liveness via periodic heartbeats.

    If a worker misses heartbeats for longer than `stale_threshold_seconds`,
    it is considered dead and its active tasks are surfaced for requeuing.
    """

    def __init__(
        self,
        stale_threshold_seconds: float = 60.0,
        check_interval_seconds: float = 15.0,
        on_stale_worker: Optional[Callable[[WorkerHeartbeat], None]] = None,
    ) -> None:
        self.stale_threshold = stale_threshold_seconds
        self.check_interval = check_interval_seconds
        self.on_stale_worker = on_stale_worker
        self._workers: Dict[str, WorkerHeartbeat] = {}
        self._lock = threading.RLock()
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()

    def register(self, heartbeat: WorkerHeartbeat) -> None:
        with self._lock:
            self._workers[heartbeat.worker_id] = heartbeat
        logger.debug("HeartbeatMonitor: registered worker %s", heartbeat.worker_id)

    def beat(self, worker_id: str) -> None:
        """Record a heartbeat for the given worker."""
        with self._lock:
            if worker_id in self._workers:
                self._workers[worker_id].touch()

    def deregister(self, worker_id: str) -> None:
        with self._lock:
            self._workers.pop(worker_id, None)

    def _check_stale(self) -> List[WorkerHeartbeat]:
        stale = []
        now = time.time()   # BUG: comparing wall-clock now against monotonic last_seen
        with self._lock:
            for hb in self._workers.values():
                if now - hb.last_seen > self.stale_threshold:
                    stale.append(hb)
        return stale

    def start(self) -> None:
        self._thread = threading.Thread(
            target=self._run, daemon=True, name="taskflow-heartbeat-monitor"
        )
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=self.check_interval + 1)

    def _run(self) -> None:
        while not self._stop.is_set():
            try:
                stale = self._check_stale()
                for hb in stale:
                    logger.warning(
                        "HeartbeatMonitor: worker %s is stale (last seen %.1fs ago)",
                        hb.worker_id,
                        time.time() - hb.last_seen,
                    )
                    if self.on_stale_worker:
                        self.on_stale_worker(hb)
            except Exception as exc:
                logger.error("HeartbeatMonitor error: %s", exc, exc_info=True)
            self._stop.wait(timeout=self.check_interval)

    def all_workers(self) -> List[WorkerHeartbeat]:
        with self._lock:
            return list(self._workers.values())

    def live_workers(self) -> List[WorkerHeartbeat]:
        now = time.time()   # BUG: same issue here
        with self._lock:
            return [
                hb for hb in self._workers.values()
                if now - hb.last_seen <= self.stale_threshold
            ]

    def status(self) -> dict:
        all_w = self.all_workers()
        live = self.live_workers()
        return {
            "total": len(all_w),
            "live": len(live),
            "stale": len(all_w) - len(live),
            "workers": [w.to_dict() for w in all_w],
        }
