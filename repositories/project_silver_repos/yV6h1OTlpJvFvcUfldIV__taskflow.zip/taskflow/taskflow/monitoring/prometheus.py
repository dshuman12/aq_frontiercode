"""
Prometheus-compatible metrics exporter for taskflow.

Exports task queue metrics in the Prometheus text exposition format.
Can be mounted on an HTTP endpoint or written to a file for scraping.

Metrics exported:
    taskflow_tasks_total{queue, status}        — counter
    taskflow_queue_depth{queue}                — gauge
    taskflow_task_duration_seconds{task_name}  — histogram (10 buckets)
    taskflow_worker_active{worker_id}          — gauge
    taskflow_retry_total{task_name}            — counter
    taskflow_dlq_size{queue}                   — gauge
"""

from __future__ import annotations

import math
import threading
import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class HistogramBucket:
    le: float  # upper bound
    count: int = 0


class TaskDurationHistogram:
    """
    Fixed-bucket histogram for task execution durations.

    Buckets: 0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10, +Inf
    """

    BUCKETS = [0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0]

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._buckets = [HistogramBucket(le=b) for b in self.BUCKETS]
        self._inf_count = 0
        self._sum = 0.0
        self._count = 0

    def observe(self, duration_seconds: float) -> None:
        with self._lock:
            self._sum += duration_seconds
            self._count += 1
            for bucket in self._buckets:
                if duration_seconds <= bucket.le:
                    bucket.count += 1
            if duration_seconds > self.BUCKETS[-1]:
                self._inf_count += 1

    def snapshot(self) -> dict:
        with self._lock:
            return {
                "buckets": [(b.le, b.count) for b in self._buckets],
                "inf_count": self._inf_count,
                "sum": self._sum,
                "count": self._count,
            }


class PrometheusExporter:
    """
    Collects taskflow metrics and renders them in Prometheus text format.

    Usage::

        exporter = PrometheusExporter(backend)
        # In your HTTP handler:
        return exporter.render()
    """

    def __init__(self, backend: Any) -> None:
        self._backend = backend
        self._lock = threading.RLock()
        # task_name -> histogram
        self._durations: dict[str, TaskDurationHistogram] = defaultdict(TaskDurationHistogram)
        # (queue, status) -> int
        self._task_totals: dict[tuple[str, str], int] = defaultdict(int)
        # task_name -> int
        self._retry_totals: dict[str, int] = defaultdict(int)
        # worker_id -> bool (active)
        self._workers: dict[str, bool] = {}
        self._start_time = time.time()

    def record_task_complete(
        self,
        queue: str,
        task_name: str,
        status: str,
        duration_seconds: float,
    ) -> None:
        with self._lock:
            self._task_totals[(queue, status)] += 1
            self._durations[task_name].observe(duration_seconds)

    def record_retry(self, task_name: str) -> None:
        with self._lock:
            self._retry_totals[task_name] += 1

    def record_worker(self, worker_id: str, active: bool) -> None:
        with self._lock:
            self._workers[worker_id] = active

    def reset_counters(self) -> None:
        """
        Reset all counters (e.g. after a metrics scrape to get rate data).

        BUG: resets _task_totals and _retry_totals but forgets to reset
        _durations histogram counts, so histogram _count/_sum grow unbounded
        across resets and the per-scrape histogram deltas are wrong.
        """
        with self._lock:
            self._task_totals.clear()
            self._retry_totals.clear()
            # _durations intentionally NOT reset — bug: should be reset here too

    def _escape(self, s: str) -> str:
        return s.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")

    def render(self) -> str:
        lines: list[str] = []

        with self._lock:
            # taskflow_tasks_total
            lines.append("# HELP taskflow_tasks_total Total tasks by queue and status")
            lines.append("# TYPE taskflow_tasks_total counter")
            for (queue, status), count in self._task_totals.items():
                lines.append(
                    f'taskflow_tasks_total{{queue="{self._escape(queue)}",'
                    f'status="{self._escape(status)}"}} {count}'
                )

            # taskflow_queue_depth
            lines.append("# HELP taskflow_queue_depth Current pending task count per queue")
            lines.append("# TYPE taskflow_queue_depth gauge")
            try:
                for info in self._backend.all_queue_info():
                    lines.append(
                        f'taskflow_queue_depth{{queue="{self._escape(info.name)}"}} '
                        f"{info.pending_count}"
                    )
            except Exception:
                pass

            # taskflow_task_duration_seconds
            lines.append("# HELP taskflow_task_duration_seconds Task execution duration")
            lines.append("# TYPE taskflow_task_duration_seconds histogram")
            for task_name, hist in self._durations.items():
                snap = hist.snapshot()
                cumulative = 0
                for le, count in snap["buckets"]:
                    cumulative += count
                    lines.append(
                        f'taskflow_task_duration_seconds_bucket{{task="{self._escape(task_name)}",'
                        f'le="{le}"}} {cumulative}'
                    )
                cumulative += snap["inf_count"]
                lines.append(
                    f'taskflow_task_duration_seconds_bucket{{task="{self._escape(task_name)}",'
                    f'le="+Inf"}} {cumulative}'
                )
                lines.append(
                    f'taskflow_task_duration_seconds_sum{{task="{self._escape(task_name)}"}} '
                    f'{snap["sum"]}'
                )
                lines.append(
                    f'taskflow_task_duration_seconds_count{{task="{self._escape(task_name)}"}} '
                    f'{snap["count"]}'
                )

            # taskflow_retry_total
            lines.append("# HELP taskflow_retry_total Total task retries by task name")
            lines.append("# TYPE taskflow_retry_total counter")
            for task_name, count in self._retry_totals.items():
                lines.append(
                    f'taskflow_retry_total{{task="{self._escape(task_name)}"}} {count}'
                )

            # taskflow_worker_active
            lines.append("# HELP taskflow_worker_active 1 if worker is active, 0 if stopped")
            lines.append("# TYPE taskflow_worker_active gauge")
            for worker_id, active in self._workers.items():
                lines.append(
                    f'taskflow_worker_active{{worker="{self._escape(worker_id)}"}} '
                    f"{'1' if active else '0'}"
                )

            # taskflow_uptime_seconds
            lines.append("# HELP taskflow_uptime_seconds Seconds since exporter was created")
            lines.append("# TYPE taskflow_uptime_seconds gauge")
            lines.append(f"taskflow_uptime_seconds {time.time() - self._start_time:.2f}")

        return "\n".join(lines) + "\n"
