"""
Minimal HTTP health-check server for worker processes.
Exposes GET /health → 200 OK with JSON status.
Runs in a daemon thread alongside the main worker.
"""
from __future__ import annotations
import json, logging, threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Callable, Optional

logger = logging.getLogger(__name__)

class _Handler(BaseHTTPRequestHandler):
    status_fn: Callable[[], dict]

    def do_GET(self) -> None:
        if self.path in ("/health", "/healthz"):
            body = json.dumps(self.server.status_fn()).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        else:
            self.send_response(404)
            self.end_headers()

    def log_message(self, *args) -> None:
        pass  # silence default access log

class HealthServer:
    def __init__(self, status_fn: Callable[[], dict], port: int = 8888) -> None:
        self._status_fn = status_fn
        self._port = port
        self._server: Optional[HTTPServer] = None
        self._thread: Optional[threading.Thread] = None

    def start(self) -> None:
        class _Svr(HTTPServer):
            status_fn = self._status_fn
        _Handler.status_fn = self._status_fn
        self._server = HTTPServer(("0.0.0.0", self._port), _Handler)
        self._server.status_fn = self._status_fn
        self._thread = threading.Thread(
            target=self._server.serve_forever, daemon=True, name="taskflow-health"
        )
        self._thread.start()
        logger.info("Health server listening on :%d", self._port)

    def stop(self) -> None:
        if self._server:
            self._server.shutdown()
