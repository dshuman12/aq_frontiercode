"""
Monitoring and metrics for taskflow.

Provides a MetricsCollector that aggregates stats from workers and backends,
and a simple HTTP health endpoint for use in production deployments.
"""

from __future__ import annotations

import json
import logging
import threading
import time
from collections import defaultdict, deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Metric types
# ---------------------------------------------------------------------------

@dataclass
class Counter:
    """A monotonically increasing counter."""
    name: str
    value: float = 0.0
    labels: Dict[str, str] = field(default_factory=dict)

    def increment(self, amount: float = 1.0) -> None:
        self.value += amount

    def to_dict(self) -> dict:
        return {"name": self.name, "type": "counter", "value": self.value, "labels": self.labels}


@dataclass
class Gauge:
    """A value that can go up or down."""
    name: str
    value: float = 0.0
    labels: Dict[str, str] = field(default_factory=dict)

    def set(self, v: float) -> None:
        self.value = v

    def increment(self, amount: float = 1.0) -> None:
        self.value += amount

    def decrement(self, amount: float = 1.0) -> None:
        self.value -= amount

    def to_dict(self) -> dict:
        return {"name": self.name, "type": "gauge", "value": self.value, "labels": self.labels}


@dataclass
class Histogram:
    """Tracks the distribution of a value over a sliding window."""
    name: str
    window_size: int = 1000
    labels: Dict[str, str] = field(default_factory=dict)
    _values: deque = field(default_factory=lambda: deque(maxlen=1000), init=False, repr=False)
    _lock: threading.Lock = field(default_factory=threading.Lock, init=False, repr=False)

    def observe(self, value: float) -> None:
        with self._lock:
            self._values.append(value)

    def snapshot(self) -> dict:
        with self._lock:
            vals = sorted(self._values)
        if not vals:
            return {"name": self.name, "type": "histogram", "count": 0}
        n = len(vals)
        return {
            "name": self.name,
            "type": "histogram",
            "count": n,
            "mean": sum(vals) / n,
            "min": vals[0],
            "max": vals[-1],
            "p50": vals[n // 2],
            "p95": vals[min(int(n * 0.95), n - 1)],
            "p99": vals[min(int(n * 0.99), n - 1)],
            "labels": self.labels,
        }

    def to_dict(self) -> dict:
        return self.snapshot()


# ---------------------------------------------------------------------------
# Metrics collector
# ---------------------------------------------------------------------------

class MetricsCollector:
    """
    Central store for all taskflow metrics.

    Metrics are identified by name + label set. Supports counters, gauges,
    and histograms. Thread-safe.
    """

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._counters: Dict[str, Counter] = {}
        self._gauges: Dict[str, Gauge] = {}
        self._histograms: Dict[str, Histogram] = {}
        self._callbacks: List[Callable[[], dict]] = []

    # --- Registration ---

    def counter(self, name: str, labels: Optional[Dict[str, str]] = None) -> Counter:
        key = self._key(name, labels)
        with self._lock:
            if key not in self._counters:
                self._counters[key] = Counter(name=name, labels=labels or {})
            return self._counters[key]

    def gauge(self, name: str, labels: Optional[Dict[str, str]] = None) -> Gauge:
        key = self._key(name, labels)
        with self._lock:
            if key not in self._gauges:
                self._gauges[key] = Gauge(name=name, labels=labels or {})
            return self._gauges[key]

    def histogram(self, name: str, labels: Optional[Dict[str, str]] = None,
                  window_size: int = 1000) -> Histogram:
        key = self._key(name, labels)
        with self._lock:
            if key not in self._histograms:
                self._histograms[key] = Histogram(name=name, labels=labels or {},
                                                   window_size=window_size)
            return self._histograms[key]

    def register_callback(self, fn: Callable[[], dict]) -> None:
        """Register a function that returns extra metrics as a dict."""
        with self._lock:
            self._callbacks.append(fn)

    # --- Snapshot ---

    def snapshot(self) -> dict:
        with self._lock:
            counters = [c.to_dict() for c in self._counters.values()]
            gauges = [g.to_dict() for g in self._gauges.values()]
            histograms = [h.to_dict() for h in self._histograms.values()]
            extras = []
            for cb in self._callbacks:
                try:
                    extras.append(cb())
                except Exception:
                    pass

        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "counters": counters,
            "gauges": gauges,
            "histograms": histograms,
            "extras": extras,
        }

    def _key(self, name: str, labels: Optional[dict]) -> str:
        if not labels:
            return name
        label_str = ",".join(f"{k}={v}" for k, v in sorted(labels.items()))
        return f"{name}{{{label_str}}}"

    def reset(self) -> None:
        with self._lock:
            self._counters.clear()
            self._gauges.clear()
            self._histograms.clear()


# ---------------------------------------------------------------------------
# Built-in taskflow metrics
# ---------------------------------------------------------------------------

_global_metrics: Optional[MetricsCollector] = None
_metrics_lock = threading.Lock()


def get_metrics() -> MetricsCollector:
    global _global_metrics
    if _global_metrics is None:
        with _metrics_lock:
            if _global_metrics is None:
                _global_metrics = MetricsCollector()
    return _global_metrics


def record_task_queued(queue_name: str) -> None:
    m = get_metrics()
    m.counter("taskflow_tasks_queued_total", {"queue": queue_name}).increment()
    m.gauge("taskflow_queue_length", {"queue": queue_name}).increment()


def record_task_started(queue_name: str, task_name: str) -> None:
    m = get_metrics()
    m.counter("taskflow_tasks_started_total", {"queue": queue_name, "task": task_name}).increment()
    m.gauge("taskflow_tasks_running", {"queue": queue_name}).increment()


def record_task_success(queue_name: str, task_name: str, duration: float) -> None:
    m = get_metrics()
    m.counter("taskflow_tasks_success_total", {"queue": queue_name, "task": task_name}).increment()
    m.gauge("taskflow_tasks_running", {"queue": queue_name}).decrement()
    m.gauge("taskflow_queue_length", {"queue": queue_name}).decrement()
    m.histogram("taskflow_task_duration_seconds", {"queue": queue_name, "task": task_name}).observe(duration)


def record_task_failure(queue_name: str, task_name: str, duration: float) -> None:
    m = get_metrics()
    m.counter("taskflow_tasks_failure_total", {"queue": queue_name, "task": task_name}).increment()
    m.gauge("taskflow_tasks_running", {"queue": queue_name}).decrement()
    m.gauge("taskflow_queue_length", {"queue": queue_name}).decrement()
    m.histogram("taskflow_task_duration_seconds", {"queue": queue_name, "task": task_name}).observe(duration)


def record_task_retry(queue_name: str, task_name: str, attempt: int) -> None:
    m = get_metrics()
    m.counter("taskflow_tasks_retry_total", {"queue": queue_name, "task": task_name}).increment()


# ---------------------------------------------------------------------------
# Health / metrics HTTP server
# ---------------------------------------------------------------------------

class _HealthHandler(BaseHTTPRequestHandler):
    """Minimal HTTP handler for health and metrics endpoints."""

    collector: MetricsCollector = None  # type: ignore[assignment]
    backend: Any = None

    def do_GET(self) -> None:
        if self.path == "/health":
            self._respond(200, {"status": "ok", "timestamp": datetime.now(timezone.utc).isoformat()})
        elif self.path == "/metrics":
            data = self.collector.snapshot() if self.collector else {}
            self._respond(200, data)
        elif self.path == "/queues" and self.backend:
            queues = [q.to_dict() for q in self.backend.all_queue_info()]
            self._respond(200, {"queues": queues})
        else:
            self._respond(404, {"error": "not found"})

    def _respond(self, code: int, data: dict) -> None:
        body = json.dumps(data, indent=2).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format: str, *args: Any) -> None:
        logger.debug("HealthServer: " + format % args)


class HealthServer:
    """
    Lightweight HTTP server exposing health and metrics endpoints.

    Endpoints:
        GET /health  — liveness check
        GET /metrics — metrics snapshot
        GET /queues  — queue info
    """

    def __init__(
        self,
        host: str = "0.0.0.0",
        port: int = 8080,
        collector: Optional[MetricsCollector] = None,
        backend: Any = None,
    ) -> None:
        self.host = host
        self.port = port
        self.collector = collector or get_metrics()
        self.backend = backend
        self._server: Optional[HTTPServer] = None
        self._thread: Optional[threading.Thread] = None

    def start(self) -> None:
        handler = type(
            "_Handler",
            (_HealthHandler,),
            {"collector": self.collector, "backend": self.backend},
        )
        self._server = HTTPServer((self.host, self.port), handler)
        self._thread = threading.Thread(
            target=self._server.serve_forever, daemon=True, name="taskflow-health"
        )
        self._thread.start()
        logger.info("HealthServer listening on %s:%d", self.host, self.port)

    def stop(self) -> None:
        if self._server:
            self._server.shutdown()
        logger.info("HealthServer stopped")
