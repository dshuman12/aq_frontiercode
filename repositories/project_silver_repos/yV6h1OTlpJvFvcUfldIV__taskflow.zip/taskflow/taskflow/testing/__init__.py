"""
Testing utilities for taskflow.

This module provides fixtures, mock objects, and test helpers
for writing tests for taskflow applications.

Example usage:

    from taskflow.testing.fixtures import Fixtures, MockBackend

    # Create a mock backend with tasks
    backend = Fixtures.create_backend_with_tasks()

    # Create a mock registry with tasks
    from taskflow.testing.fixtures import MockRegistry

    @registry.register(name="my_task")
    def my_task(x, y):
        return x + y

    # Use the TaskRunner to execute tasks
    from taskflow.testing.fixtures import TaskRunner
    runner = TaskRunner(backend, registry)
    results = runner.run_until_complete(num_tasks=10)

For pytest integration, add to your conftest.py:

    import pytest
    from taskflow.testing.conftest import *

Or import specific fixtures as needed.
"""

from __future__ import annotations

from taskflow.testing.fixtures import (
    # Mock objects
    MockTask,
    MockTaskResult,
    MockExecutionContext,
    MockBackend,
    MockRegistry,
    # Fixtures
    Fixtures,
    FixtureConfig,
    # Helpers
    TestTimer,
    RateCounter,
    ConcurrencyHelper,
    TaskRunner,
    # Assertions
    TaskAssertions,
    ResultAssertions,
    BackendAssertions,
    # Benchmarking
    Benchmark,
    BenchmarkResult,
    # Integration testing
    IntegrationTestSetup,
    temp_taskflow_stack,
    # Mock services
    MockExternalService,
    MockHTTPService,
    MockDatabaseService,
    # Configuration
    TestConfig,
    # Coverage tracking
    CoverageTracker,
)

__all__ = [
    # Mock objects
    "MockTask",
    "MockTaskResult",
    "MockExecutionContext",
    "MockBackend",
    "MockRegistry",
    # Fixtures
    "Fixtures",
    "FixtureConfig",
    # Helpers
    "TestTimer",
    "RateCounter",
    "ConcurrencyHelper",
    "TaskRunner",
    # Assertions
    "TaskAssertions",
    "ResultAssertions",
    "BackendAssertions",
    # Benchmarking
    "Benchmark",
    "BenchmarkResult",
    # Integration testing
    "IntegrationTestSetup",
    "temp_taskflow_stack",
    # Mock services
    "MockExternalService",
    "MockHTTPService",
    "MockDatabaseService",
    # Configuration
    "TestConfig",
    # Coverage tracking
    "CoverageTracker",
]
