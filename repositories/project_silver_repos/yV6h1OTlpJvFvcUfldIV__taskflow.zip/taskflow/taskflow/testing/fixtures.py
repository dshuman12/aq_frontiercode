"""
Testing utilities for taskflow.

Provides fixtures, mock objects, and test helpers for writing
tests for taskflow applications.
"""

from __future__ import annotations

import copy
import logging
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional
from unittest.mock import MagicMock, Mock, patch
import uuid

# -------------------------------------------------------------------------- #
# Mock Objects
# -------------------------------------------------------------------------- #


class MockTask:
    """Mock task object for testing."""

    def __init__(
        self,
        task_name: str = "test_task",
        task_id: Optional[str] = None,
        args: tuple = (),
        kwargs: Optional[Dict[str, Any]] = None,
        queue_name: str = "default",
        priority: int = 5,
        tags: Optional[List[str]] = None,
        retry_policy: Optional[Dict[str, Any]] = None,
        correlation_id: Optional[str] = None,
        max_attempts: int = 3,
        timeout: Optional[float] = None,
    ) -> None:
        self.task_name = task_name
        self.task_id = task_id or str(uuid.uuid4())
        self.args = args
        self.kwargs = kwargs or {}
        self.queue_name = queue_name
        self.priority = priority
        self.tags = tags or []
        self.retry_policy = retry_policy or {}
        self.correlation_id = correlation_id or str(uuid.uuid4())
        self.max_attempts = max_attempts
        self.timeout = timeout
        self.attempt = 1
        self.enqueued_at = time.time()
        self.started_at = None
        self.completed_at = None
        self.result_ttl = 86400
        self.task_ttl = 604800

    def to_dict(self) -> dict:
        return {
            "task_name": self.task_name,
            "task_id": self.task_id,
            "args": self.args,
            "kwargs": self.kwargs,
            "queue_name": self.queue_name,
            "priority": self.priority,
            "tags": self.tags,
            "retry_policy": self.retry_policy,
            "correlation_id": self.correlation_id,
            "max_attempts": self.max_attempts,
            "timeout": self.timeout,
            "attempt": self.attempt,
        }


class MockTaskResult:
    """Mock task result for testing."""

    def __init__(
        self,
        status: str = "success",
        result: Any = None,
        error: Optional[str] = None,
        traceback: Optional[str] = None,
        started_at: Optional[float] = None,
        completed_at: Optional[float] = None,
    ) -> None:
        self.status = status
        self.result = result
        self.error = error
        self.traceback = traceback
        self.started_at = started_at or time.time()
        self.completed_at = completed_at or time.time()
        self.execution_time = self.completed_at - self.started_at

    def to_dict(self) -> dict:
        return {
            "status": self.status,
            "result": self.result,
            "error": self.error,
            "traceback": self.traceback,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "execution_time": self.execution_time,
        }


class MockExecutionContext:
    """Mock execution context for testing."""

    def __init__(
        self,
        task: Optional[MockTask] = None,
        worker_id: str = "test_worker",
    ) -> None:
        self.task = task or MockTask()
        self.worker_id = worker_id
        self.started_at = time.time()
        self._elapsed: Optional[float] = None

    @property
    def elapsed_seconds(self) -> float:
        if self._elapsed is not None:
            return self._elapsed
        if self.task.started_at:
            return time.time() - self.task.started_at
        return 0.0

    def set_elapsed(self, seconds: float) -> None:
        self._elapsed = seconds


class MockBackend:
    """Mock backend for testing without Redis or SQLite."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._tasks: Dict[str, MockTask] = {}
        self._results: Dict[str, MockTaskResult] = {}
        self._queues: Dict[str, List[MockTask]] = defaultdict(list)
        self._enqueued_tasks: List[str] = []
        self._stats: Dict[str, int] = defaultdict(int)

    def enqueue(self, task: MockTask) -> str:
        with self._lock:
            self._tasks[task.task_id] = task
            self._queues[task.queue_name].append(task)
            self._enqueued_tasks.append(task.task_id)
            self._stats["enqueued"] += 1
        return task.task_id

    def dequeue(
        self,
        queue_name: str,
        timeout: float = 1.0,
        worker_id: Optional[str] = None,
    ) -> Optional[MockTask]:
        deadline = time.time() + timeout
        while time.time() < deadline:
            with self._lock:
                if self._queues[queue_name]:
                    task = self._queues[queue_name].pop(0)
                    task.started_at = time.time()
                    self._stats["dequeued"] += 1
                    return task
            time.sleep(0.01)
        return None

    def requeue(self, task: MockTask) -> None:
        with self._lock:
            self._queues[task.queue_name].append(task)
            self._stats["requeued"] += 1

    def store_result(
        self,
        task_id: str,
        result: MockTaskResult,
        ttl: Optional[int] = None,
    ) -> None:
        with self._lock:
            self._results[task_id] = result
            self._stats["results_stored"] += 1

    def get_result(self, task_id: str) -> Optional[MockTaskResult]:
        with self._lock:
            return self._results.get(task_id)

    def ack(self, task_id: str) -> None:
        with self._lock:
            self._stats["acked"] += 1

    def nack(self, task_id: str, requeue: bool = True) -> None:
        with self._lock:
            self._stats["nacked"] += 1

    def get_queue_info(self, queue_name: str) -> Dict[str, Any]:
        with self._lock:
            return {
                "name": queue_name,
                "size": len(self._queues[queue_name]),
                "oldest_task": None,
            }

    def get_stats(self) -> Dict[str, int]:
        with self._lock:
            return dict(self._stats)

    def clear(self) -> None:
        with self._lock:
            self._tasks.clear()
            self._results.clear()
            for queue in self._queues.values():
                queue.clear()
            self._enqueued_tasks.clear()
            self._stats.clear()

    def set_tasks(self, tasks: List[MockTask]) -> None:
        with self._lock:
            for task in tasks:
                self._tasks[task.task_id] = task
                self._queues[task.queue_name].append(task)


class MockRegistry:
    """Mock task registry for testing."""

    def __init__(self) -> None:
        self._tasks: Dict[str, Callable] = {}
        self._middleware: List[Any] = []

    def register(
        self,
        name: Optional[str] = None,
        queue_name: str = "default",
        priority: int = 5,
        tags: Optional[List[str]] = None,
        retry_policy: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
    ) -> Callable:
        def decorator(func: Callable) -> Callable:
            task_name = name or func.__name__

            def wrapper(*args: Any, **kwargs: Any) -> Any:
                return func(*args, **kwargs)

            wrapper.task_name = task_name
            wrapper.queue_name = queue_name
            wrapper.priority = priority
            wrapper.tags = tags or []
            wrapper.retry_policy = retry_policy or {}
            wrapper.timeout = timeout
            wrapper._is_task = True

            self._tasks[task_name] = wrapper
            return wrapper

        return decorator

    def get(self, task_name: str) -> Optional[Callable]:
        return self._tasks.get(task_name)

    def list_tasks(self) -> List[str]:
        return list(self._tasks.keys())

    def clear(self) -> None:
        self._tasks.clear()


# Import defaultdict for MockBackend
from collections import defaultdict


# -------------------------------------------------------------------------- #
# Test Fixtures
# -------------------------------------------------------------------------- #


@dataclass
class FixtureConfig:
    """Configuration for test fixtures."""
    num_queues: int = 3
    tasks_per_queue: int = 10
    result_ttl: int = 3600
    task_ttl: int = 86400


class Fixtures:
    """Factory for creating test fixtures."""

    @staticmethod
    def create_task(
        task_name: str = "test_task",
        queue_name: str = "default",
        priority: int = 5,
        **kwargs: Any,
    ) -> MockTask:
        """Create a single mock task."""
        return MockTask(task_name=task_name, queue_name=queue_name, priority=priority, **kwargs)

    @staticmethod
    def create_tasks(
        count: int,
        task_name: str = "test_task",
        queue_name: str = "default",
        start_priority: int = 1,
        end_priority: int = 10,
    ) -> List[MockTask]:
        """Create multiple mock tasks with varying priorities."""
        tasks = []
        for i in range(count):
            priority = start_priority + int(
                (end_priority - start_priority) * (i / max(count - 1, 1))
            )
            task = MockTask(
                task_name=f"{task_name}_{i}",
                task_id=f"task-{uuid.uuid4().hex[:8]}-{i}",
                queue_name=queue_name,
                priority=priority,
            )
            tasks.append(task)
        return tasks

    @staticmethod
    def create_tasks_for_multiple_queues(
        num_queues: int = 3,
        tasks_per_queue: int = 10,
    ) -> Dict[str, List[MockTask]]:
        """Create tasks distributed across multiple queues."""
        queues = {}
        for i in range(num_queues):
            queue_name = f"queue_{i}"
            tasks = Fixtures.create_tasks(
                count=tasks_per_queue,
                task_name=f"task_q{i}",
                queue_name=queue_name,
            )
            queues[queue_name] = tasks
        return queues

    @staticmethod
    def create_backend_with_tasks(
        config: Optional[FixtureConfig] = None,
    ) -> MockBackend:
        """Create a mock backend pre-populated with tasks."""
        config = config or FixtureConfig()
        backend = MockBackend()

        queues = Fixtures.create_tasks_for_multiple_queues(
            num_queues=config.num_queues,
            tasks_per_queue=config.tasks_per_queue,
        )

        for queue_tasks in queues.values():
            for task in queue_tasks:
                backend.enqueue(task)

        return backend

    @staticmethod
    def create_execution_context(
        task: Optional[MockTask] = None,
        worker_id: str = "test_worker",
    ) -> MockExecutionContext:
        """Create a mock execution context."""
        return MockExecutionContext(task=task, worker_id=worker_id)

    @staticmethod
    def create_registry_with_tasks(
        task_definitions: Optional[List[Dict[str, Any]] = None,
    ) -> MockRegistry:
        """Create a mock registry with registered tasks."""
        registry = MockRegistry()
        task_definitions = task_definitions or [
            {"name": "task_1", "queue_name": "queue_1"},
            {"name": "task_2", "queue_name": "queue_2"},
            {"name": "task_3", "queue_name": "queue_1", "tags": ["urgent"]},
        ]

        for definition in task_definitions:
            registry.register(**definition)(lambda *args, **kwargs: None)

        return registry


# -------------------------------------------------------------------------- #
# Test Helpers
# -------------------------------------------------------------------------- #


class TestTimer:
    """Context manager for timing test operations."""

    def __init__(self) -> None:
        self.start_time: Optional[float] = None
        self.end_time: Optional[float] = None
        self.elapsed: float = 0.0

    def __enter__(self) -> "TestTimer":
        self.start_time = time.time()
        return self

    def __exit__(self, *args: Any) -> None:
        self.end_time = time.time()
        self.elapsed = self.end_time - self.start_time


class RateCounter:
    """Thread-safe counter for measuring rates."""

    def __init__(self) -> None:
        self._count = 0
        self._start_time = time.time()
        self._lock = threading.Lock()

    def increment(self, n: int = 1) -> None:
        with self._lock:
            self._count += n

    @property
    def rate(self) -> float:
        with self._lock:
            elapsed = time.time() - self._start_time
            return self._count / elapsed if elapsed > 0 else 0.0

    @property
    def count(self) -> int:
        with self._lock:
            return self._count

    def reset(self) -> None:
        with self._lock:
            self._count = 0
            self._start_time = time.time()


class ConcurrencyHelper:
    """Helper for testing concurrent operations."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._results: List[Any] = []
        self._errors: List[Exception] = []
        self._barrier = threading.Barrier(1)

    def run_concurrently(
        self,
        func: Callable,
        num_threads: int = 10,
        args: tuple = (),
        kwargs: Optional[Dict[str, Any]] = None,
    ) -> List[Any]:
        """Run a function concurrently in multiple threads."""
        kwargs = kwargs or {}
        self._results.clear()
        self._errors.clear()
        self._barrier = threading.Barrier(num_threads)

        def thread_func() -> None:
            try:
                result = func(*args, **kwargs)
                with self._lock:
                    self._results.append(result)
            except Exception as e:
                with self._lock:
                    self._errors.append(e)
            finally:
                self._barrier.wait()

        threads = [
            threading.Thread(target=thread_func)
            for _ in range(num_threads)
        ]

        for t in threads:
            t.start()

        for t in threads:
            t.join()

        return self._results

    @property
    def errors(self) -> List[Exception]:
        return self._errors


class TaskRunner:
    """Helper for running tasks in tests."""

    def __init__(
        self,
        backend: MockBackend,
        registry: MockRegistry,
    ) -> None:
        self.backend = backend
        self.registry = registry
        self._running = False
        self._lock = threading.Lock()

    def run_until_complete(
        self,
        num_tasks: Optional[int] = None,
        timeout: float = 5.0,
    ) -> List[MockTaskResult]:
        """Run tasks from the backend until completion or timeout."""
        results = []
        start_time = time.time()
        task_count = 0

        with self._lock:
            self._running = True

        try:
            while True:
                if num_tasks and task_count >= num_tasks:
                    break

                if time.time() - start_time > timeout:
                    break

                for queue_name in ["default", "queue_1", "queue_2"]:
                    task = self.backend.dequeue(queue_name, timeout=0.1)
                    if task:
                        func = self.registry.get(task.task_name)
                        if func:
                            try:
                                result_data = func(*task.args, **task.kwargs)
                                result = MockTaskResult(
                                    status="success",
                                    result=result_data,
                                )
                            except Exception as e:
                                result = MockTaskResult(
                                    status="failed",
                                    error=str(e),
                                )
                        else:
                            result = MockTaskResult(
                                status="failed",
                                error="Task not found",
                            )

                        self.backend.store_result(task.task_id, result)
                        results.append(result)
                        task_count += 1

                if not results and task_count == 0:
                    time.sleep(0.01)

        finally:
            with self._lock:
                self._running = False

        return results


@contextmanager
def mock_time(time_value: float = 1000.0):
    """Context manager to mock time.time() for testing."""
    with patch("time.time", return_value=time_value) as mock:
        yield mock


@contextmanager
def mock_utcnow(time_value: Optional[datetime] = None):
    """Context manager to mock datetime.now() for testing."""
    if time_value is None:
        time_value = datetime(2025, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    with patch("datetime.now", return_value=time_value) as mock:
        yield mock


# -------------------------------------------------------------------------- #
# Assertions and Matchers
# -------------------------------------------------------------------------- #


class TaskAssertions:
    """Assertion helpers for task testing."""

    @staticmethod
    def assert_task_equal(expected: MockTask, actual: MockTask) -> None:
        """Assert that two tasks are equal."""
        assert expected.task_name == actual.task_name, (
            f"Task name mismatch: {expected.task_name} != {actual.task_name}"
        )
        assert expected.task_id == actual.task_id, (
            f"Task ID mismatch: {expected.task_id} != {actual.task_id}"
        )
        assert expected.queue_name == actual.queue_name, (
            f"Queue name mismatch: {expected.queue_name} != {actual.queue_name}"
        )
        assert expected.priority == actual.priority, (
            f"Priority mismatch: {expected.priority} != {actual.priority}"
        )

    @staticmethod
    def assert_task_in_list(task: MockTask, task_list: List[MockTask]) -> None:
        """Assert that a task is in a list."""
        for t in task_list:
            if t.task_id == task.task_id:
                return
        raise AssertionError(f"Task {task.task_id} not found in list")

    @staticmethod
    def assert_tasks_ordered_by_priority(
        tasks: List[MockTask],
        ascending: bool = True,
    ) -> None:
        """Assert that tasks are ordered by priority."""
        priorities = [t.priority for t in tasks]
        sorted_priorities = sorted(priorities, reverse=not ascending)
        assert priorities == sorted_priorities, (
            f"Tasks are not ordered by priority: {priorities}"
        )


class ResultAssertions:
    """Assertion helpers for result testing."""

    @staticmethod
    def assert_success(result: MockTaskResult) -> None:
        """Assert that a result indicates success."""
        assert result.status == "success", f"Expected success, got {result.status}"

    @staticmethod
    def assert_failure(result: MockTaskResult) -> None:
        """Assert that a result indicates failure."""
        assert result.status in ("failed", "retry"), (
            f"Expected failure, got {result.status}"
        )

    @staticmethod
    def assert_result_contains(result: MockTaskResult, key: str) -> None:
        """Assert that a result contains a specific key."""
        assert hasattr(result, key), f"Result has no attribute {key}"


class BackendAssertions:
    """Assertion helpers for backend testing."""

    @staticmethod
    def assert_queue_size(backend: MockBackend, queue_name: str, expected: int) -> None:
        """Assert that a queue has the expected size."""
        info = backend.get_queue_info(queue_name)
        assert info["size"] == expected, (
            f"Queue {queue_name} size is {info['size']}, expected {expected}"
        )

    @staticmethod
    def assert_stats(backend: MockBackend, key: str, expected: int) -> None:
        """Assert that backend has expected stats value."""
        stats = backend.get_stats()
        assert stats.get(key, 0) == expected, (
            f"Backend stat {key} is {stats.get(key, 0)}, expected {expected}"
        )

    @staticmethod
    def assert_no_tasks(backend: MockBackend, queue_name: str) -> None:
        """Assert that a queue is empty."""
        BackendAssertions.assert_queue_size(backend, queue_name, 0)


# -------------------------------------------------------------------------- #
# Benchmark Helpers
# -------------------------------------------------------------------------- #


@dataclass
class BenchmarkResult:
    """Results from a benchmark run."""
    name: str
    iterations: int
    total_time: float
    avg_time: float
    min_time: float
    max_time: float
    ops_per_second: float
    metadata: Dict[str, Any] = field(default_factory=dict)


class Benchmark:
    """Benchmark helper for performance testing."""

    def __init__(
        self,
        name: str = "benchmark",
        warmup_iterations: int = 10,
        measured_iterations: int = 1000,
    ) -> None:
        self.name = name
        self.warmup_iterations = warmup_iterations
        self.measured_iterations = measured_iterations
        self._times: List[float] = []

    def run(
        self,
        func: Callable,
        *args: Any,
        **kwargs: Any,
    ) -> BenchmarkResult:
        """Run benchmark and return results."""
        # Warmup
        for _ in range(self.warmup_iterations):
            func(*args, **kwargs)

        # Measure
        self._times.clear()
        for _ in range(self.measured_iterations):
            start = time.perf_counter()
            func(*args, **kwargs)
            end = time.perf_counter()
            self._times.append(end - start)

        total_time = sum(self._times)
        avg_time = total_time / self.measured_iterations

        return BenchmarkResult(
            name=self.name,
            iterations=self.measured_iterations,
            total_time=total_time,
            avg_time=avg_time,
            min_time=min(self._times),
            max_time=max(self._times),
            ops_per_second=self.measured_iterations / total_time,
        )

    def run_with_args(
        self,
        func: Callable,
        args_list: List[tuple],
    ) -> BenchmarkResult:
        """Run benchmark with multiple argument sets."""
        total_start = time.perf_counter()

        for args in args_list:
            func(*args)

        total_time = time.time() - total_start

        return BenchmarkResult(
            name=self.name,
            iterations=len(args_list),
            total_time=total_time,
            avg_time=total_time / len(args_list),
            min_time=0,
            max_time=total_time,
            ops_per_second=len(args_list) / total_time,
        )


# -------------------------------------------------------------------------- #
# Integration Test Helpers
# -------------------------------------------------------------------------- #


class IntegrationTestSetup:
    """Setup for integration tests with full taskflow stack."""

    def __init__(self) -> None:
        self.backend: Optional[MockBackend] = None
        self.registry: Optional[MockRegistry] = None
        self.task_runner: Optional[TaskRunner] = None

    def setup(
        self,
        use_redis: bool = False,
        redis_url: Optional[str] = None,
    ) -> "IntegrationTestSetup":
        """Setup the integration test environment."""
        from taskflow.backends.memory import MemoryBackend
        from taskflow.core.registry import TaskRegistry

        if use_redis and redis_url:
            from taskflow.backends.redis_backend import RedisBackend
            self.backend = RedisBackend(url=redis_url)
        else:
            self.backend = MockBackend()

        self.registry = MockRegistry()
        self.task_runner = TaskRunner(self.backend, self.registry)
        return self

    def teardown(self) -> None:
        """Teardown the integration test environment."""
        if self.backend and hasattr(self.backend, "close"):
            self.backend.close()
        self.backend = None
        self.registry = None
        self.task_runner = None

    def __enter__(self) -> "IntegrationTestSetup":
        return self.setup()

    def __exit__(self, *args: Any) -> None:
        self.teardown()


@contextmanager
def temp_taskflow_stack(
    use_redis: bool = False,
    redis_url: Optional[str] = None,
):
    """Context manager for a temporary taskflow stack."""
    setup = IntegrationTestSetup()
    try:
        setup.setup(use_redis=use_redis, redis_url=redis_url)
        yield setup
    finally:
        setup.teardown()


# -------------------------------------------------------------------------- #
# Mock External Services
# -------------------------------------------------------------------------- #


class MockExternalService:
    """Base class for mocking external services."""

    def __init__(self) -> None:
        self._calls: List[Dict[str, Any]] = []
        self._lock = threading.Lock()
        self._failure_rate = 0.0
        self._latency_ms = 0

    def record_call(self, method: str, args: tuple, kwargs: dict) -> None:
        with self._lock:
            self._calls.append({
                "method": method,
                "args": args,
                "kwargs": kwargs,
                "timestamp": time.time(),
            })

    def set_failure_rate(self, rate: float) -> None:
        """Set the rate of failures (0.0 to 1.0)."""
        self._failure_rate = max(0.0, min(1.0, rate))

    def set_latency(self, latency_ms: int) -> None:
        """Set the simulated latency in milliseconds."""
        self._latency_ms = latency_ms

    def get_calls(self, method: Optional[str] = None) -> List[Dict[str, Any]]:
        with self._lock:
            if method:
                return [c for c in self._calls if c["method"] == method]
            return list(self._calls)

    def get_call_count(self, method: Optional[str] = None) -> int:
        return len(self.get_calls(method))

    def clear_calls(self) -> None:
        with self._lock:
            self._calls.clear()


class MockHTTPService(MockExternalService):
    """Mock HTTP service for testing."""

    def get(self, url: str, **kwargs: Any) -> Dict[str, Any]:
        self.record_call("get", (url,), kwargs)
        time.sleep(self._latency_ms / 1000.0)

        if self._failure_rate > 0 and self._should_fail():
            raise Exception("HTTP request failed")

        return {"status": 200, "data": {"result": "success"}}

    def post(self, url: str, data: Any, **kwargs: Any) -> Dict[str, Any]:
        self.record_call("post", (url, data), kwargs)
        time.sleep(self._latency_ms / 1000.0)

        if self._failure_rate > 0 and self._should_fail():
            raise Exception("HTTP request failed")

        return {"status": 201, "data": {"result": "created"}}

    def _should_fail(self) -> bool:
        import random
        return random.random() < self._failure_rate


class MockDatabaseService(MockExternalService):
    """Mock database service for testing."""

    def __init__(self) -> None:
        super().__init__()
        self._data: Dict[str, List[Dict[str, Any]]] = defaultdict(list)

    def query(self, table: str, filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        self.record_call("query", (table,), {"filters": filters})
        time.sleep(self._latency_ms / 1000.0)

        results = list(self._data.get(table, []))
        if filters:
            for key, value in filters.items():
                results = [r for r in results if r.get(key) == value]

        return results

    def insert(self, table: str, record: Dict[str, Any]) -> str:
        self.record_call("insert", (table, record), {})
        time.sleep(self._latency_ms / 1000.0)

        if self._failure_rate > 0 and self._should_fail():
            raise Exception("Database insert failed")

        record_id = str(uuid.uuid4())
        record["id"] = record_id
        self._data[table].append(record)
        return record_id

    def update(self, table: str, record_id: str, data: Dict[str, Any]) -> bool:
        self.record_call("update", (table, record_id), {"data": data})
        time.sleep(self._latency_ms / 1000.0)

        if self._failure_rate > 0 and self._should_fail():
            raise Exception("Database update failed")

        for record in self._data[table]:
            if record.get("id") == record_id:
                record.update(data)
                return True
        return False

    def delete(self, table: str, record_id: str) -> bool:
        self.record_call("delete", (table, record_id), {})
        time.sleep(self._latency_ms / 1000.0)

        original_len = len(self._data[table])
        self._data[table] = [
            r for r in self._data[table] if r.get("id") != record_id
        ]
        return len(self._data[table]) < original_len


# -------------------------------------------------------------------------- #
# Test Configuration
# -------------------------------------------------------------------------- #


class TestConfig:
    """Configuration for test runs."""

    # Timeouts
    DEFAULT_TIMEOUT = 5.0
    LONG_TIMEOUT = 30.0
    SHORT_TIMEOUT = 0.5

    # Retry settings
    DEFAULT_MAX_RETRIES = 3
    DEFAULT_RETRY_DELAY = 0.1

    # Queue settings
    DEFAULT_QUEUE_SIZE = 100
    MAX_QUEUE_SIZE = 10000

    # Worker settings
    DEFAULT_NUM_WORKERS = 4
    MAX_WORKERS = 16

    # Rate limiting
    DEFAULT_RATE_LIMIT = 100

    # Memory limits
    MAX_MEMORY_MB = 512

    @classmethod
    def reset(cls) -> None:
        """Reset configuration to defaults."""
        pass  # All values are class-level defaults


# -------------------------------------------------------------------------- #
# Coverage Helpers
# -------------------------------------------------------------------------- #


class CoverageTracker:
    """Track code coverage during tests."""

    def __init__(self) -> None:
        self._covered_lines: Set[Tuple[str, int]] = set()
        self._lock = threading.Lock()

    def record_line(self, file_path: str, line_number: int) -> None:
        with self._lock:
            self._covered_lines.add((file_path, line_number))

    def get_covered_files(self) -> List[str]:
        with self._lock:
            return list(set(f for f, _ in self._covered_lines))

    def get_coverage(self, file_path: str) -> List[int]:
        with self._lock:
            return sorted([ln for f, ln in self._covered_lines if f == file_path])


# Type alias for tuple
from typing import Tuple
from typing import Set
