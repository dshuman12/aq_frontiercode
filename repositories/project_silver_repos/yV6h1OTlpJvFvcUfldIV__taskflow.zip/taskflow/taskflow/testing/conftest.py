"""
Pytest configuration and fixtures for taskflow tests.
"""

from __future__ import annotations

import logging
import os
import sys
import threading
import time
from typing import Any, Dict, Generator, List, Optional

import pytest

# Add taskflow to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))


# ---------------------------------------------------------------------------
# Pytest Configuration
# ---------------------------------------------------------------------------

def pytest_configure(config: Any) -> None:
    """Configure pytest with custom markers and settings."""
    config.addinivalue_line(
        "markers", "slow: marks tests as slow (deselect with '-m \"not slow\"')"
    )
    config.addinivalue_line(
        "markers", "integration: marks tests as integration tests"
    )
    config.addinivalue_line(
        "markers", "redis: marks tests that require Redis"
    )
    config.addinivalue_line(
        "markers", "unit: marks tests as unit tests"
    )


def pytest_collection_modifyitems(config: Any, items: List[Any]) -> None:
    """Modify test collection to add automatic markers."""
    for item in items:
        # Add unit marker to tests in tests/unit/
        if "unit" in str(item.fspath):
            item.add_marker(pytest.mark.unit)

        # Add slow marker to tests with _slow suffix
        if "_slow" in item.name:
            item.add_marker(pytest.mark.slow)


# ---------------------------------------------------------------------------
# Session Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(scope="session")
def taskflow_version() -> str:
    """Get the taskflow version."""
    from taskflow import __version__
    return __version__


@pytest.fixture(scope="session")
def session_id() -> str:
    """Generate a unique session ID for test isolation."""
    import uuid
    return str(uuid.uuid4())[:8]


# ---------------------------------------------------------------------------
# Function Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def mock_backend():
    """Create a mock backend for testing."""
    from taskflow.testing.fixtures import MockBackend
    return MockBackend()


@pytest.fixture
def mock_registry():
    """Create a mock registry for testing."""
    from taskflow.testing.fixtures import MockRegistry
    return MockRegistry()


@pytest.fixture
def fixtures():
    """Get the Fixtures factory class."""
    from taskflow.testing.fixtures import Fixtures
    return Fixtures


@pytest.fixture
def sample_task():
    """Create a sample task for testing."""
    from taskflow.testing.fixtures import MockTask
    return MockTask(task_name="sample_task", queue_name="default")


@pytest.fixture
def sample_tasks():
    """Create multiple sample tasks for testing."""
    from taskflow.testing.fixtures import Fixtures
    return Fixtures.create_tasks(count=10, task_name="test_task")


@pytest.fixture
def sample_execution_context():
    """Create a sample execution context for testing."""
    from taskflow.testing.fixtures import MockExecutionContext, MockTask
    task = MockTask(task_name="test_task")
    return MockExecutionContext(task=task)


@pytest.fixture
def task_runner(mock_backend, mock_registry):
    """Create a task runner for testing."""
    from taskflow.testing.fixtures import TaskRunner
    return TaskRunner(mock_backend, mock_registry)


# ---------------------------------------------------------------------------
# Backend Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def memory_backend():
    """Create a real MemoryBackend for testing."""
    from taskflow.backends.memory import MemoryBackend
    backend = MemoryBackend()
    yield backend
    backend.close()


@pytest.fixture
def sqlite_backend(tmp_path):
    """Create a real SQLiteBackend for testing."""
    from taskflow.backends.sqlite import SQLiteBackend
    db_path = tmp_path / "test_taskflow.db"
    backend = SQLiteBackend(str(db_path))
    yield backend
    backend.close()


@pytest.fixture
def redis_backend():
    """Create a RedisBackend for testing (requires Redis)."""
    redis_url = os.environ.get("REDIS_URL", "redis://localhost:6379/0")

    try:
        from taskflow.backends.redis_backend import RedisBackend
        backend = RedisBackend(url=redis_url)
        yield backend
    except Exception as e:
        pytest.skip(f"Redis not available: {e}")
    finally:
        try:
            backend.close()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Registry Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def task_registry():
    """Create a real TaskRegistry for testing."""
    from taskflow.core.registry import TaskRegistry
    return TaskRegistry()


@pytest.fixture
def registered_task(task_registry):
    """Create a registered task for testing."""
    @task_registry.register(name="test_task")
    def test_task(x: int, y: int) -> int:
        return x + y

    return test_task


@pytest.fixture
def registered_tasks(task_registry):
    """Create multiple registered tasks for testing."""
    @task_registry.register(name="task_add")
    def task_add(x: int, y: int) -> int:
        return x + y

    @task_registry.register(name="task_multiply")
    def task_multiply(x: int, y: int) -> int:
        return x * y

    @task_registry.register(name="task_divide")
    def task_divide(x: float, y: float) -> float:
        return x / y

    @task_registry.register(name="task_fail")
    def task_fail() -> None:
        raise ValueError("Test failure")

    return {
        "add": task_add,
        "multiply": task_multiply,
        "divide": task_divide,
        "fail": task_fail,
    }


# ---------------------------------------------------------------------------
# Worker Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def worker(memory_backend, task_registry):
    """Create a real Worker for testing."""
    from taskflow.workers.worker import Worker
    worker = Worker(
        backend=memory_backend,
        registry=task_registry,
        num_threads=2,
    )
    yield worker
    worker.stop()


@pytest.fixture
def worker_with_tasks(worker, memory_backend, task_registry, registered_tasks):
    """Create a worker with tasks already queued."""
    # Register tasks in registry
    for name, task in registered_tasks.items():
        task_registry._tasks[name] = task

    # Queue some tasks
    for i in range(5):
        from taskflow.core.models import Task
        task = Task(
            task_name="task_add",
            args=(i, i + 1),
            queue_name="default",
        )
        memory_backend.enqueue(task)

    return worker


# ---------------------------------------------------------------------------
# Middleware Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def timing_middleware():
    """Create a TimingMiddleware for testing."""
    from taskflow.middleware.base import TimingMiddleware
    return TimingMiddleware(window_size=100)


@pytest.fixture
def logging_middleware():
    """Create a LoggingMiddleware for testing."""
    from taskflow.middleware.base import LoggingMiddleware
    return LoggingMiddleware()


@pytest.fixture
def rate_limit_middleware():
    """Create a RateLimitMiddleware for testing."""
    from taskflow.middleware.base import RateLimitMiddleware
    return RateLimitMiddleware(limits={"test_task": "10/second"})


@pytest.fixture
def concurrency_limiter():
    """Create a ConcurrencyLimiterMiddleware for testing."""
    from taskflow.middleware.advanced import ConcurrencyLimiterMiddleware
    return ConcurrencyLimiterMiddleware(
        per_task_limits={"test_task": 2},
        global_limit=10,
    )


# ---------------------------------------------------------------------------
# Configuration Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def test_config():
    """Create test configuration."""
    from taskflow.config.settings import Config, DictSource
    return Config(sources=[DictSource({"test_mode": True})])


@pytest.fixture
def yaml_config_file(tmp_path):
    """Create a temporary YAML config file."""
    import yaml
    config = {
        "taskflow": {
            "backend": "memory",
            "workers": 4,
        },
        "redis": {
            "url": "redis://localhost:6379/0",
        },
    }
    config_path = tmp_path / "config.yaml"
    with open(config_path, "w") as f:
        yaml.dump(config, f)
    return str(config_path)


# ---------------------------------------------------------------------------
# Event Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def event_emitter():
    """Create an EventEmitter for testing."""
    from taskflow.events.emitter import EventEmitter
    return EventEmitter(history_size=100)


@pytest.fixture
def captured_events():
    """Create a list to capture events."""
    events = []
    return events


# ---------------------------------------------------------------------------
# Batch Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def batch_builder():
    """Create a BatchBuilder for testing."""
    from taskflow.batch.processor import BatchBuilder
    return BatchBuilder()


# ---------------------------------------------------------------------------
# Routing Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def router():
    """Create a Router for testing."""
    from taskflow.routing.router import Router
    return Router()


# ---------------------------------------------------------------------------
# Utility Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def rate_limiter():
    """Create a RateLimiter for testing."""
    from taskflow.utils.helpers import RateLimiter
    return RateLimiter(rate=10, period=1.0)


@pytest.fixture
def task_deduplicator():
    """Create a TaskDeduplicator for testing."""
    from taskflow.utils.helpers import TaskDeduplicator
    return TaskDeduplicator(window_seconds=60.0)


@pytest.fixture
def circuit_breaker():
    """Create a CircuitBreaker for testing."""
    from taskflow.utils.helpers import CircuitBreaker
    return CircuitBreaker(
        name="test_breaker",
        failure_threshold=3,
        reset_timeout=5.0,
    )


# ---------------------------------------------------------------------------
# Async Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def event_loop():
    """Create an event loop for async tests."""
    import asyncio
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()


@pytest.fixture
async def async_backend(memory_backend):
    """Create an async-compatible backend wrapper."""
    from taskflow.backends.memory import MemoryBackend
    # MemoryBackend is sync, but can be wrapped for async tests
    return memory_backend


# ---------------------------------------------------------------------------
# Logging Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def caplog(caplog):
    """Configure caplog for taskflow logger."""
    caplog.set_level(logging.DEBUG, logger="taskflow")
    return caplog


# ---------------------------------------------------------------------------
# Cache Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def cache_middleware():
    """Create a CacheMiddleware for testing."""
    from taskflow.middleware.advanced import CacheMiddleware
    return CacheMiddleware(max_size=100, default_ttl=60.0)


# ---------------------------------------------------------------------------
# Transaction Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def transaction_middleware():
    """Create a TransactionMiddleware for testing."""
    from taskflow.middleware.advanced import TransactionMiddleware
    return TransactionMiddleware()


# ---------------------------------------------------------------------------
# SLA Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def sla_monitor():
    """Create an SLAMonitorMiddleware for testing."""
    from taskflow.middleware.advanced import SLAMonitorMiddleware, SLADefinition
    slas = [
        SLADefinition(
            name="fast_task",
            task_pattern="task_.*",
            max_duration_seconds=1.0,
            warning_threshold=0.8,
        ),
    ]
    return SLAMonitorMiddleware(slas=slas)


# ---------------------------------------------------------------------------
# Fixture Factories
# ---------------------------------------------------------------------------

class FixtureFactory:
    """Factory for creating custom fixtures."""

    @staticmethod
    def create_task(
        name: str = "test_task",
        queue: str = "default",
        priority: int = 5,
        tags: Optional[List[str]] = None,
    ):
        """Create a custom task fixture."""
        from taskflow.testing.fixtures import MockTask
        return MockTask(
            task_name=name,
            queue_name=queue,
            priority=priority,
            tags=tags,
        )

    @staticmethod
    def create_tasks_with_tags(
        tag_groups: Dict[str, List[str]],
    ) -> List[Any]:
        """Create tasks with different tag groups."""
        from taskflow.testing.fixtures import MockTask
        tasks = []
        for group_name, tags in tag_groups.items():
            for i in range(3):
                task = MockTask(
                    task_name=f"task_{group_name}_{i}",
                    tags=tags,
                )
                tasks.append(task)
        return tasks

    @staticmethod
    def create_backend_with_queue_size(
        queue_name: str,
        num_tasks: int,
    ):
        """Create a backend with a specific queue size."""
        from taskflow.testing.fixtures import MockBackend, MockTask
        backend = MockBackend()
        for i in range(num_tasks):
            task = MockTask(task_name=f"task_{i}", queue_name=queue_name)
            backend.enqueue(task)
        return backend


# ---------------------------------------------------------------------------
# Cleanup Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def cleanup_thread_locals():
    """Cleanup thread-local state after each test."""
    yield
    # Cleanup after test
    threading.current_thread().name = "MainThread"


@pytest.fixture
def reset_time():
    """Reset time-related state."""
    import time
    original_time = time.time
    yield
    # No-op, just a marker fixture


# ---------------------------------------------------------------------------
# Marker Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def requires_redis():
    """Skip test if Redis is not available."""
    redis_url = os.environ.get("REDIS_URL")
    if not redis_url:
        pytest.skip("REDIS_URL not set")

    try:
        import redis
        client = redis.from_url(redis_url)
        client.ping()
    except Exception as e:
        pytest.skip(f"Redis not available: {e}")


@pytest.fixture
def requires_sqlite():
    """Skip test if SQLite is not available."""
    try:
        import sqlite3
        conn = sqlite3.connect(":memory:")
        conn.close()
    except Exception as e:
        pytest.skip(f"SQLite not available: {e}")


# ---------------------------------------------------------------------------
# Parametrized Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(params=["memory", "sqlite"])
def any_backend(request, tmp_path):
    """Parametrized fixture for any backend type."""
    backend_type = request.param

    if backend_type == "memory":
        from taskflow.backends.memory import MemoryBackend
        return MemoryBackend()
    elif backend_type == "sqlite":
        from taskflow.backends.sqlite import SQLiteBackend
        return SQLiteBackend(str(tmp_path / "test.db"))


@pytest.fixture(params=[1, 5, 10])
def various_queue_sizes(request):
    """Parametrized fixture for various queue sizes."""
    return request.param


# ---------------------------------------------------------------------------
# Slow Test Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def slow_backend():
    """Create a backend suitable for slow tests."""
    from taskflow.backends.memory import MemoryBackend
    backend = MemoryBackend()
    yield backend
    backend.close()


@pytest.fixture
def long_running_worker(memory_backend, task_registry):
    """Create a worker suitable for long-running tests."""
    from taskflow.workers.worker import Worker
    worker = Worker(
        backend=memory_backend,
        registry=task_registry,
        num_threads=4,
        poll_interval=0.01,
    )
    yield worker
    worker.stop()
