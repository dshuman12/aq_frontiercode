"""
Batch processing for taskflow.

Provides utilities for processing multiple tasks together,
including fan-out, fan-in, chord (callback after all), and
pipeline (chained batch) operations.

Features:
- Batch enqueuing of related tasks
- Chord: execute callback after all tasks complete
- Pipeline: chain batch operations
- Chunking for large datasets
- Batch result aggregation
- Progress tracking
"""

from __future__ import annotations

import logging
import threading
import time
import uuid
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, Type

from taskflow.core.models import Priority, Task, TaskResult, TaskStatus

logger = logging.getLogger(__name__)


class BatchState(Enum):
    """State of a batch operation."""
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    PARTIAL = "partial"  # Some tasks succeeded, some failed
    FAILURE = "failure"
    CANCELLED = "cancelled"


@dataclass
class BatchTask:
    """A task within a batch."""
    task_id: str
    task_name: str
    args: List[Any] = field(default_factory=list)
    kwargs: Dict[str, Any] = field(default_factory=dict)
    priority: Priority = Priority.NORMAL
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class BatchResult:
    """Result of a batch operation."""
    batch_id: str
    state: BatchState
    total: int
    succeeded: int = 0
    failed: int = 0
    results: Dict[str, TaskResult] = field(default_factory=dict)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    error: Optional[str] = None

    @property
    def duration_seconds(self) -> Optional[float]:
        if self.started_at and self.completed_at:
            return (self.completed_at - self.started_at).total_seconds()
        return None

    @property
    def success_rate(self) -> float:
        if self.total == 0:
            return 0.0
        return self.succeeded / self.total

    def to_dict(self) -> dict:
        return {
            "batch_id": self.batch_id,
            "state": self.state.value,
            "total": self.total,
            "succeeded": self.succeeded,
            "failed": self.failed,
            "success_rate": self.success_rate,
            "duration_seconds": self.duration_seconds,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "error": self.error,
        }


@dataclass
class BatchOptions:
    """Options for batch operations."""
    chunk_size: int = 100
    max_concurrency: int = 10
    stop_on_first_failure: bool = False
    collect_results: bool = True
    timeout_seconds: Optional[float] = None
    raise_on_failure: bool = False


@dataclass
class Chord:
    """
    A chord is a callback that runs after all tasks in a group complete.

    Example:
        chord = Chord(
            tasks=[task1, task2, task3],
            callback=aggregate_results,
            args=()
        )
        chord_result = chord.execute(backend)
    """
    tasks: List[BatchTask]
    callback: Callable
    callback_args: Tuple = field(default_factory=tuple)
    callback_kwargs: Dict[str, Any] = field(default_factory=dict)
    chord_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    options: BatchOptions = field(default_factory=BatchOptions)
    task_results: Dict[str, TaskResult] = field(default_factory=dict)

    def execute(self, backend: Any, registry: Any) -> Any:
        """
        Execute the chord.

        Enqueues all tasks, waits for completion, then calls the callback.
        Returns the callback's return value.
        """
        task_ids = []
        now = datetime.now(timezone.utc)

        # Enqueue all tasks
        for batch_task in self.tasks:
            task = Task(
                task_name=batch_task.task_name,
                args=batch_task.args,
                kwargs=batch_task.kwargs,
                priority=batch_task.priority,
                metadata={"chord_id": self.chord_id, **batch_task.metadata},
            )
            backend.enqueue(task)
            task_ids.append(task.task_id)

        # Wait for all tasks to complete
        deadline = None
        if self.options.timeout_seconds:
            deadline = time.monotonic() + self.options.timeout_seconds

        while task_ids:
            # Check timeout
            if deadline and time.monotonic() >= deadline:
                raise TimeoutError(f"Chord {self.chord_id} timed out after {self.options.timeout_seconds}s")

            # Check which tasks are done
            remaining = []
            for task_id in task_ids:
                result = backend.get_result(task_id)
                if result is None:
                    remaining.append(task_id)
                else:
                    self.task_results[task_id] = result

            task_ids = remaining
            if task_ids:
                time.sleep(0.1)

        # Call the callback with results
        callback_results = {
            task_id: self.task_results[task_id].return_value
            for task_id in self.task_results
            if self.task_results[task_id].succeeded
        }

        return self.callback(callback_results, *self.callback_args, **self.callback_kwargs)


@dataclass
class Pipeline:
    """
    A pipeline is a sequence of batch operations.

    Each stage's output is fed into the next stage's input.
    """
    stages: List[BatchStage] = field(default_factory=list)
    pipeline_id: str = field(default_factory=lambda: str(uuid.uuid4()))

    def add_stage(
        self,
        stage: Callable[[List[Any]], List[BatchTask]],
        name: Optional[str] = None,
    ) -> "Pipeline":
        """Add a stage to the pipeline."""
        self.stages.append(BatchStage(
            name=name or f"stage_{len(self.stages)}",
            processor=stage,
        ))
        return self

    def execute(self, backend: Any, registry: Any) -> Any:
        """
        Execute the pipeline.

        Returns the result of the final stage.
        """
        stage_input: List[Any] = []

        for stage in self.stages:
            # Create tasks from input
            tasks = stage.processor(stage_input) if stage_input else stage.processor([])

            # Execute tasks
            batch = Batch(tasks=tasks, options=BatchOptions())
            result = batch.execute(backend, registry)

            if result.state in (BatchState.FAILURE, BatchState.CANCELLED):
                raise RuntimeError(f"Pipeline stage {stage.name} failed: {result.error}")

            # Extract return values for next stage
            stage_input = [
                result.results[task.task_id].return_value
                for task in tasks
                if task.task_id in result.results and result.results[task.task_id].succeeded
            ]

        return stage_input


@dataclass
class BatchStage:
    """A single stage in a pipeline."""
    name: str
    processor: Callable[[List[Any]], List[BatchTask]]


class Batch:
    """
    Execute multiple tasks in batch.

    Supports chunking, concurrency control, and result aggregation.
    """

    def __init__(
        self,
        tasks: Optional[List[BatchTask]] = None,
        options: Optional[BatchOptions] = None,
        batch_id: Optional[str] = None,
    ) -> None:
        self.tasks = tasks or []
        self.options = options or BatchOptions()
        self.batch_id = batch_id or str(uuid.uuid4())
        self._results: Dict[str, TaskResult] = {}
        self._lock = threading.Lock()
        self._completed = threading.Event()

    def add_task(
        self,
        task_name: str,
        args: Optional[List[Any]] = None,
        kwargs: Optional[Dict[str, Any]] = None,
        priority: Priority = Priority.NORMAL,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> str:
        """Add a task to the batch. Returns the task ID."""
        task_id = str(uuid.uuid4())
        self.tasks.append(BatchTask(
            task_id=task_id,
            task_name=task_name,
            args=args or [],
            kwargs=kwargs or {},
            priority=priority,
            metadata=metadata or {},
        ))
        return task_id

    def execute(self, backend: Any, registry: Any) -> BatchResult:
        """
        Execute all tasks in the batch.

        Returns a BatchResult with aggregated outcomes.
        """
        if not self.tasks:
            return BatchResult(
                batch_id=self.batch_id,
                state=BatchState.SUCCESS,
                total=0,
                started_at=datetime.now(timezone.utc),
                completed_at=datetime.now(timezone.utc),
            )

        started_at = datetime.now(timezone.utc)
        result = BatchResult(
            batch_id=self.batch_id,
            state=BatchState.RUNNING,
            total=len(self.tasks),
            started_at=started_at,
        )

        try:
            # Enqueue all tasks
            task_id_to_batch_id = {}
            for batch_task in self.tasks:
                task = Task(
                    task_id=batch_task.task_id,
                    task_name=batch_task.task_name,
                    args=batch_task.args,
                    kwargs=batch_task.kwargs,
                    priority=batch_task.priority,
                    metadata={
                        "batch_id": self.batch_id,
                        **batch_task.metadata,
                    },
                )
                backend.enqueue(task)
                task_id_to_batch_id[task.task_id] = batch_task.task_id

            # Wait for completion
            self._wait_for_completion(backend, task_id_to_batch_id, result)

            # Determine final state
            if result.failed == 0:
                result.state = BatchState.SUCCESS
            elif result.succeeded == 0:
                result.state = BatchState.FAILURE
            else:
                result.state = BatchState.PARTIAL

        except Exception as exc:
            result.state = BatchState.FAILURE
            result.error = str(exc)
            logger.exception("Batch %s failed: %s", self.batch_id, exc)

        result.completed_at = datetime.now(timezone.utc)
        return result

    def _wait_for_completion(
        self,
        backend: Any,
        task_id_map: Dict[str, str],
        result: BatchResult,
    ) -> None:
        """Wait for all tasks to complete."""
        pending = set(task_id_map.keys())
        deadline = None
        if self.options.timeout_seconds:
            deadline = time.monotonic() + self.options.timeout_seconds

        while pending:
            # Check timeout
            if deadline and time.monotonic() >= deadline:
                result.state = BatchState.CANCELLED
                result.error = f"Timeout after {self.options.timeout_seconds}s"
                return

            # Check which tasks are done
            newly_completed = []
            for task_id in list(pending):
                task_result = backend.get_result(task_id)
                if task_result:
                    batch_id = task_id_map[task_id]
                    result.results[batch_id] = task_result

                    if task_result.succeeded:
                        result.succeeded += 1
                    else:
                        result.failed += 1

                    newly_completed.append(task_id)

                    # Handle stop_on_first_failure
                    if self.options.stop_on_first_failure and task_result.failed:
                        pending.discard(task_id)
                        # Revoke remaining tasks
                        for remaining in pending:
                            backend.revoke(remaining)
                        pending.clear()
                        result.state = BatchState.FAILURE
                        result.error = f"Task {remaining} failed, stopping batch"
                        return

            for task_id in newly_completed:
                pending.discard(task_id)

            if pending:
                time.sleep(0.1)

    def execute_parallel(self, backend: Any, registry: Any) -> BatchResult:
        """
        Execute tasks in parallel using a thread pool.

        This is useful when you need to run task functions directly
        rather than through the queue.
        """
        started_at = datetime.now(timezone.utc)
        result = BatchResult(
            batch_id=self.batch_id,
            state=BatchState.RUNNING,
            total=len(self.tasks),
            started_at=started_at,
        )

        try:
            with ThreadPoolExecutor(max_workers=self.options.max_concurrency) as executor:
                futures = {}
                for batch_task in self.tasks:
                    # Look up task definition
                    try:
                        defn = registry.get(batch_task.task_name)
                        future = executor.submit(
                            defn.func,
                            *batch_task.args,
                            **batch_task.kwargs
                        )
                        futures[future] = batch_task
                    except Exception as exc:
                        logger.error("Failed to submit task %s: %s", batch_task.task_name, exc)
                        result.failed += 1
                        result.results[batch_task.task_id] = TaskResult(
                            task_id=batch_task.task_id,
                            status=TaskStatus.FAILURE,
                            error=str(exc),
                        )

                # Collect results
                deadline = None
                if self.options.timeout_seconds:
                    deadline = time.monotonic() + self.options.timeout_seconds

                for future in as_completed(futures, timeout=self.options.timeout_seconds):
                    batch_task = futures[future]
                    try:
                        return_value = future.result()
                        result.succeeded += 1
                        result.results[batch_task.task_id] = TaskResult(
                            task_id=batch_task.task_id,
                            status=TaskStatus.SUCCESS,
                            return_value=return_value,
                        )
                    except Exception as exc:
                        result.failed += 1
                        result.results[batch_task.task_id] = TaskResult(
                            task_id=batch_task.task_id,
                            status=TaskStatus.FAILURE,
                            error=str(exc),
                        )
                        if self.options.raise_on_failure:
                            raise

            # Determine final state
            if result.failed == 0:
                result.state = BatchState.SUCCESS
            elif result.succeeded == 0:
                result.state = BatchState.FAILURE
            else:
                result.state = BatchState.PARTIAL

        except Exception as exc:
            result.state = BatchState.FAILURE
            result.error = str(exc)
            logger.exception("Batch %s failed: %s", self.batch_id, exc)

        result.completed_at = datetime.now(timezone.utc)
        return result


class BatchBuilder:
    """
    Fluent builder for batch operations.

    Example:
        batch = (
            BatchBuilder(backend)
            .add("task1", args=[1, 2])
            .add("task2", args=[3, 4], priority=Priority.HIGH)
            .with_options(chunk_size=50, max_concurrency=20)
            .build()
        )
        result = batch.execute(backend, registry)
    """

    def __init__(
        self,
        backend: Any,
        options: Optional[BatchOptions] = None,
    ) -> None:
        self._backend = backend
        self._options = options or BatchOptions()
        self._tasks: List[BatchTask] = []

    def add(
        self,
        task_name: str,
        args: Optional[List[Any]] = None,
        kwargs: Optional[Dict[str, Any]] = None,
        priority: Priority = Priority.NORMAL,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> "BatchBuilder":
        """Add a task to the batch."""
        self._tasks.append(BatchTask(
            task_id=str(uuid.uuid4()),
            task_name=task_name,
            args=args or [],
            kwargs=kwargs or {},
            priority=priority,
            metadata=metadata or {},
        ))
        return self

    def add_many(
        self,
        task_name: str,
        items: List[Any],
        args_func: Optional[Callable[[Any], Tuple[List, Dict]]] = None,
        chunk_size: Optional[int] = None,
        priority: Priority = Priority.NORMAL,
    ) -> "BatchBuilder":
        """
        Add multiple tasks for processing a list of items.

        Args:
            task_name: Name of the task to call
            items: List of items to process
            args_func: Optional function that takes an item and returns (args, kwargs)
            chunk_size: Number of items per task (default: from options)
        """
        chunk = chunk_size or self._options.chunk_size

        for i in range(0, len(items), chunk):
            chunk_items = items[i:i + chunk]
            if args_func:
                args, kwargs = args_func(chunk_items)
                self.add(task_name, args=args, kwargs=kwargs, priority=priority)
            else:
                self.add(task_name, args=[chunk_items], kwargs={}, priority=priority)

        return self

    def with_options(
        self,
        chunk_size: Optional[int] = None,
        max_concurrency: Optional[int] = None,
        stop_on_first_failure: Optional[bool] = None,
        collect_results: Optional[bool] = None,
        timeout_seconds: Optional[float] = None,
        raise_on_failure: Optional[bool] = None,
    ) -> "BatchBuilder":
        """Update batch options."""
        if chunk_size is not None:
            self._options.chunk_size = chunk_size
        if max_concurrency is not None:
            self._options.max_concurrency = max_concurrency
        if stop_on_first_failure is not None:
            self._options.stop_on_first_failure = stop_on_first_failure
        if collect_results is not None:
            self._options.collect_results = collect_results
        if timeout_seconds is not None:
            self._options.timeout_seconds = timeout_seconds
        if raise_on_failure is not None:
            self._options.raise_on_failure = raise_on_failure
        return self

    def build(self) -> Batch:
        """Build the Batch object."""
        return Batch(tasks=self._tasks, options=self._options)

    def execute(self, backend: Any, registry: Any) -> BatchResult:
        """Execute the batch immediately."""
        return self.build().execute(backend, registry)


# ---------------------------------------------------------------------------
# Progress Tracking
# ---------------------------------------------------------------------------

class BatchProgress:
    """
    Track progress of a batch operation.

    Provides real-time progress updates via callbacks.
    """

    def __init__(
        self,
        total: int,
        on_progress: Optional[Callable[[int, int], None]] = None,
        on_complete: Optional[Callable[[BatchResult], None]] = None,
    ) -> None:
        self.total = total
        self._completed = 0
        self._failed = 0
        self._lock = threading.Lock()
        self._callbacks: List[Tuple[Callable, str]] = []
        if on_progress:
            self.on_progress(on_progress)
        if on_complete:
            self.on_complete(on_complete)

    def on_progress(self, callback: Callable[[int, int], None]) -> "BatchProgress":
        """Register a progress callback (completed, total)."""
        self._callbacks.append((callback, "progress"))
        return self

    def on_complete(self, callback: Callable[[BatchResult], None]) -> "BatchProgress":
        """Register a completion callback."""
        self._callbacks.append((callback, "complete"))
        return self

    def update(self, succeeded: int, failed: int) -> None:
        """Update progress."""
        with self._lock:
            self._completed = succeeded
            self._failed = failed
            for callback, kind in self._callbacks:
                if kind == "progress":
                    try:
                        callback(succeeded + failed, self.total)
                    except Exception:
                        pass

    def complete(self, result: BatchResult) -> None:
        """Mark as complete."""
        for callback, kind in self._callbacks:
            if kind == "complete":
                try:
                    callback(result)
                except Exception:
                    pass

    @property
    def progress_percent(self) -> float:
        if self.total == 0:
            return 100.0
        return (self._completed + self._failed) / self.total * 100

    @property
    def is_complete(self) -> bool:
        return (self._completed + self._failed) >= self.total


# ---------------------------------------------------------------------------
# Batch Helpers
# ---------------------------------------------------------------------------

def chunk_list(lst: List[Any], chunk_size: int) -> List[List[Any]]:
    """Split a list into chunks."""
    return [lst[i:i + chunk_size] for i in range(0, len(lst), chunk_size)]


def create_batch_from_map(
    backend: Any,
    task_name: str,
    items: Dict[str, Any],
    max_concurrency: int = 10,
) -> Tuple[Batch, List[str]]:
    """
    Create a batch from a dictionary.

    Each key-value pair becomes a task argument.

    Returns the batch and list of task IDs.
    """
    batch = BatchBuilder(backend, BatchOptions(max_concurrency=max_concurrency))

    task_ids = []
    for key, value in items.items():
        task_id = batch.add(task_name, args=[key, value])
        task_ids.append(task_id)

    return batch.build(), task_ids


class AsyncBatchExecutor:
    """
    Execute batches asynchronously with automatic retry.

    Useful for long-running batch operations that need to survive
    process restarts.
    """

    def __init__(
        self,
        backend: Any,
        registry: Any,
        max_retries: int = 3,
        retry_delay: float = 5.0,
    ) -> None:
        self.backend = backend
        self.registry = registry
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self._active_batches: Dict[str, Batch] = {}
        self._lock = threading.Lock()

    def submit(self, batch: Batch) -> str:
        """
        Submit a batch for async execution.

        Returns the batch ID.
        """
        with self._lock:
            self._active_batches[batch.batch_id] = batch

        # Schedule background execution
        thread = threading.Thread(
            target=self._execute_batch,
            args=(batch,),
            daemon=True,
        )
        thread.start()

        return batch.batch_id

    def _execute_batch(self, batch: Batch) -> None:
        """Execute batch with retry logic."""
        for attempt in range(self.max_retries + 1):
            try:
                result = batch.execute(self.backend, self.registry)

                if result.state == BatchState.SUCCESS:
                    logger.info("Batch %s completed successfully", batch.batch_id)
                    return

                if result.state == BatchState.PARTIAL:
                    logger.warning(
                        "Batch %s completed with partial success: %d/%d succeeded",
                        batch.batch_id, result.succeeded, result.total
                    )
                    return

                # Failure - retry
                if attempt < self.max_retries:
                    logger.warning(
                        "Batch %s failed (attempt %d/%d), retrying in %ds",
                        batch.batch_id, attempt + 1, self.max_retries + 1, self.retry_delay
                    )
                    time.sleep(self.retry_delay)
                    # Reset failed tasks for retry
                    batch = Batch(
                        tasks=batch.tasks,
                        options=batch.options,
                        batch_id=str(uuid.uuid4()),
                    )

            except Exception as exc:
                logger.exception("Batch %s execution error: %s", batch.batch_id, exc)
                if attempt < self.max_retries:
                    time.sleep(self.retry_delay)

        # All retries exhausted
        logger.error("Batch %s failed after %d attempts", batch.batch_id, self.max_retries + 1)

        with self._lock:
            self._active_batches.pop(batch.batch_id, None)

    def get_status(self, batch_id: str) -> Optional[BatchResult]:
        """Get the current status of a batch."""
        with self._lock:
            batch = self._active_batches.get(batch_id)

        if batch is None:
            return None

        # Check which tasks are complete
        result = BatchResult(
            batch_id=batch_id,
            state=BatchState.RUNNING,
            total=len(batch.tasks),
        )

        for batch_task in batch.tasks:
            task_result = self.backend.get_result(batch_task.task_id)
            if task_result:
                result.results[batch_task.task_id] = task_result
                if task_result.succeeded:
                    result.succeeded += 1
                else:
                    result.failed += 1

        if result.succeeded + result.failed == result.total:
            if result.failed == 0:
                result.state = BatchState.SUCCESS
            elif result.succeeded == 0:
                result.state = BatchState.FAILURE
            else:
                result.state = BatchState.PARTIAL

        return result
