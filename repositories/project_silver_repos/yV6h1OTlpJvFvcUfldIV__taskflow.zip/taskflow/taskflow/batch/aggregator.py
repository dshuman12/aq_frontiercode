"""
Result aggregator for fan-out task groups.

When a fan-out produces N parallel tasks, the aggregator waits for
all of them to complete and collects their results into a single
data structure for the caller.

Supports:
    - Blocking wait with timeout
    - Partial results (return what's done so far)
    - Reduce functions over results (sum, collect, first-wins)
    - Per-task error handling (fail-fast vs. best-effort)
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from taskflow.core.models import TaskResult, TaskStatus


@dataclass
class AggregateResult:
    task_ids: list[str]
    results: dict[str, TaskResult] = field(default_factory=dict)
    errors: dict[str, str] = field(default_factory=dict)
    timed_out: bool = False

    @property
    def succeeded(self) -> list[TaskResult]:
        return [r for r in self.results.values() if r.status == TaskStatus.SUCCESS]

    @property
    def failed(self) -> list[TaskResult]:
        return [r for r in self.results.values() if r.status == TaskStatus.FAILURE]

    @property
    def is_complete(self) -> bool:
        return len(self.results) + len(self.errors) == len(self.task_ids)

    @property
    def success_rate(self) -> float:
        total = len(self.task_ids)
        if total == 0:
            return 1.0
        return len(self.succeeded) / total

    def values(self) -> list[Any]:
        """Return return_values of all successful results, in task_ids order."""
        return [
            self.results[tid].return_value
            for tid in self.task_ids
            if tid in self.results and self.results[tid].status == TaskStatus.SUCCESS
        ]

    def reduce(self, fn: Callable[[Any, Any], Any], initial: Any = None) -> Any:
        vals = self.values()
        if not vals:
            return initial
        acc = vals[0] if initial is None else fn(initial, vals[0])
        for v in vals[1:]:
            acc = fn(acc, v)
        return acc


class ResultAggregator:
    """
    Collects results for a fixed set of task_ids from a backend.

    Polling-based; does not require backend pub/sub.
    """

    def __init__(
        self,
        backend: Any,
        task_ids: list[str],
        fail_fast: bool = False,
        poll_interval: float = 0.2,
    ) -> None:
        self._backend = backend
        self._task_ids = list(task_ids)
        self._fail_fast = fail_fast
        self._poll_interval = poll_interval

    def wait(
        self,
        timeout: float = 60.0,
        partial: bool = False,
    ) -> AggregateResult:
        """
        Block until all tasks complete or timeout expires.

        partial: if True, return whatever is done when timeout hits.
        fail_fast: if True, return as soon as any task fails.
        """
        agg = AggregateResult(task_ids=self._task_ids)
        deadline = time.monotonic() + timeout

        pending = set(self._task_ids)

        while pending and time.monotonic() < deadline:
            # BUG: iterates over a copy of pending but modifies via discard on the
            # original set inside the loop. This is actually safe in Python, BUT
            # the real bug is: if a result comes back with a non-terminal status
            # (e.g. RETRY), it's treated as "done" and removed from pending, so
            # the aggregator never waits for the final outcome of retrying tasks.
            for tid in list(pending):
                result = self._backend.get_result(tid)
                if result is not None:
                    # BUG: should check result.status.is_terminal before removing
                    pending.discard(tid)
                    if result.status == TaskStatus.FAILURE:
                        agg.errors[tid] = result.error or "unknown error"
                        agg.results[tid] = result
                        if self._fail_fast:
                            agg.timed_out = False
                            return agg
                    else:
                        agg.results[tid] = result

            if pending:
                time.sleep(self._poll_interval)

        if pending:
            agg.timed_out = not partial
            # Include partial results for whatever finished
        return agg

    def wait_async(
        self,
        callback: Callable[[AggregateResult], None],
        timeout: float = 60.0,
    ) -> threading.Thread:
        """Non-blocking: call callback with AggregateResult when done."""
        def _run():
            result = self.wait(timeout=timeout, partial=True)
            callback(result)
        t = threading.Thread(target=_run, daemon=True)
        t.start()
        return t
