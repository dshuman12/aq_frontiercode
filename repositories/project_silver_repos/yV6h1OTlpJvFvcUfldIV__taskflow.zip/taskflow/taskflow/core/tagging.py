"""
Task tagging system: attach arbitrary string tags to tasks and query
the registry by tag combinations (AND / OR / NOT).

Tags are stored as frozensets on each Task. This module provides
a TagIndex that maintains an inverted index for fast lookups.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, FrozenSet, List, Optional, Set

from taskflow.core.models import Task


class TagOp(str, Enum):
    AND = "and"   # task must have ALL specified tags
    OR = "or"     # task must have AT LEAST ONE of the specified tags
    NOT = "not"   # task must have NONE of the specified tags


@dataclass
class TagQuery:
    tags: List[str]
    op: TagOp = TagOp.AND


class TagIndex:
    """
    Maintains an inverted index: tag → set of task_ids.

    Allows efficient querying for tasks matching a tag expression.
    """

    def __init__(self) -> None:
        # tag -> set of task_ids that have this tag
        self._index: Dict[str, Set[str]] = defaultdict(set)
        # task_id -> set of tags
        self._task_tags: Dict[str, Set[str]] = defaultdict(set)

    def index_task(self, task: Task) -> None:
        task_id = task.task_id
        for tag in task.tags:
            self._index[tag].add(task_id)
            self._task_tags[task_id].add(tag)

    def remove_task(self, task_id: str) -> None:
        for tag in self._task_tags.pop(task_id, set()):
            self._index[tag].discard(task_id)

    def add_tag(self, task_id: str, tag: str) -> None:
        self._index[tag].add(task_id)
        self._task_tags[task_id].add(tag)

    def remove_tag(self, task_id: str, tag: str) -> None:
        self._index[tag].discard(task_id)
        self._task_tags[task_id].discard(tag)

    def tags_for(self, task_id: str) -> Set[str]:
        return set(self._task_tags.get(task_id, set()))

    def query(self, query: TagQuery) -> Set[str]:
        """
        Return task_ids matching the query.

        AND: task must possess every tag in the query.
        OR:  task must possess at least one tag.
        NOT: task must possess none of the tags.

        BUG: the AND branch uses set.union (|) instead of set.intersection (&).
        So a query for tasks tagged BOTH "urgent" AND "billing" returns tasks
        tagged EITHER "urgent" OR "billing" — the opposite of the intended
        semantics. Any task with just one of the tags is incorrectly included.
        """
        if not query.tags:
            return set()

        tag_sets = [self._index.get(t, set()) for t in query.tags]

        if query.op == TagOp.AND:
            # BUG: should be tag_sets[0].intersection(*tag_sets[1:])
            result = tag_sets[0].union(*tag_sets[1:])

        elif query.op == TagOp.OR:
            result = tag_sets[0].union(*tag_sets[1:])

        elif query.op == TagOp.NOT:
            excluded = tag_sets[0].union(*tag_sets[1:])
            all_ids = set(self._task_tags.keys())
            result = all_ids - excluded

        else:
            result = set()

        return result

    def multi_query(self, queries: List[TagQuery]) -> Set[str]:
        """
        Combine multiple TagQuery objects with AND semantics between them.
        e.g. must match query1 AND query2.
        """
        if not queries:
            return set()
        result = self.query(queries[0])
        for q in queries[1:]:
            result &= self.query(q)
        return result

    def stats(self) -> Dict[str, int]:
        """Return tag → count of indexed tasks."""
        return {tag: len(ids) for tag, ids in self._index.items()}
