"""
Typed result wrapper returned from backend.get_result().
Provides convenient accessors and re-raises stored exceptions.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Optional
from taskflow.core.models import TaskStatus

@dataclass
class TaskResult:
    task_id: str
    status: TaskStatus
    return_value: Any = None
    exception_type: Optional[str] = None
    exception_message: Optional[str] = None
    traceback: Optional[str] = None

    @property
    def successful(self) -> bool:
        return self.status == TaskStatus.SUCCESS

    @property
    def failed(self) -> bool:
        return self.status == TaskStatus.FAILED

    def get(self) -> Any:
        """Return the value or raise RuntimeError if the task failed."""
        if self.failed:
            raise RuntimeError(
                f"Task {self.task_id} failed: "
                f"{self.exception_type}: {self.exception_message}"
            )
        return self.return_value

    @classmethod
    def from_dict(cls, d: dict) -> "TaskResult":
        return cls(
            task_id=d["task_id"],
            status=TaskStatus(d["status"]),
            return_value=d.get("return_value"),
            exception_type=d.get("exception_type"),
            exception_message=d.get("exception_message"),
            traceback=d.get("traceback"),
        )
