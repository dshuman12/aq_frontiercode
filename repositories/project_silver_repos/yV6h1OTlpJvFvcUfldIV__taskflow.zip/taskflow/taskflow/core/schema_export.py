"""
Export task definitions from the Registry as a JSON schema document.
Useful for API documentation and client SDK generation.
"""
from __future__ import annotations
import json
from typing import Any

_PY_TO_JSON_TYPE = {
    str:   "string",
    int:   "integer",
    float: "number",
    bool:  "boolean",
    list:  "array",
    dict:  "object",
}

def _param_schema(annotation: Any) -> dict:
    json_type = _PY_TO_JSON_TYPE.get(annotation, "string")
    return {"type": json_type}

def registry_to_json_schema(registry) -> str:
    """Serialise all registered tasks into a JSON schema document."""
    definitions = {}
    for name, defn in registry.all().items():
        import inspect
        sig = inspect.signature(defn.func)
        properties = {}
        required = []
        for pname, param in sig.parameters.items():
            ann = param.annotation if param.annotation is not inspect.Parameter.empty else str
            schema = _param_schema(ann)
            if param.default is inspect.Parameter.empty:
                required.append(pname)
            properties[pname] = schema
        definitions[name] = {
            "type": "object",
            "properties": properties,
            "required": required,
            "description": (defn.func.__doc__ or "").strip(),
        }
    return json.dumps({"tasks": definitions}, indent=2)
