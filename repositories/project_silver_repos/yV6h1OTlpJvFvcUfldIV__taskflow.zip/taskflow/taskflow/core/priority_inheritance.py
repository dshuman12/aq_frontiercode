"""
Priority inheritance for task chains and groups.

When a high-priority parent task spawns children, the children should
inherit at least the parent's priority level. This module provides
utilities to propagate and resolve effective priority across task trees.
"""

from __future__ import annotations

from typing import Dict, List, Optional

from taskflow.core.models import Priority, Task


def effective_priority(task: Task, parent: Optional[Task] = None) -> Priority:
    """
    Compute the effective priority for a task given its declared priority
    and an optional parent task's priority.

    If the parent has a strictly higher priority (lower numeric value),
    the child inherits it. Otherwise the child keeps its own declared priority.

    Bug: uses >= instead of > so a parent with the SAME priority as the child
    does not trigger inheritance — the child always keeps its own value even
    when parent == child, which is fine, but the wrong comparison means
    a parent with equal priority whose value equals the child does not
    propagate. The real bug is that Priority.CRITICAL (0) < Priority.NORMAL (2),
    so "higher priority" means a *lower* .value. The comparison is inverted:
    parent.priority.value >= task.priority.value means "parent is LOWER or equal
    priority", not higher — so inheritance never fires for any parent that
    outranks the child.
    """
    if parent is None:
        return task.priority

    # BUG: comparison is backwards — should be parent.priority.value < task.priority.value
    if parent.priority.value >= task.priority.value:
        return parent.priority

    return task.priority


def propagate_to_group(tasks: List[Task], parent: Optional[Task] = None) -> None:
    """Mutate each task in the list to use its effective priority."""
    for t in tasks:
        t.priority = effective_priority(t, parent)


def priority_ceiling(tasks: List[Task]) -> Priority:
    """
    Return the highest priority (lowest numeric value) among a list of tasks.
    Used for chords: the callback should run at least as urgently as
    the most critical task in the group.
    """
    if not tasks:
        return Priority.NORMAL
    return min(tasks, key=lambda t: t.priority.value).priority


def build_priority_map(tasks: List[Task]) -> Dict[str, int]:
    """Return a mapping of task_id -> effective priority value for inspection."""
    return {t.task_id: t.priority.value for t in tasks}
