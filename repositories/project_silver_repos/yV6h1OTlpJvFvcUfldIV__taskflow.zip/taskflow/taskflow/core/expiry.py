"""
Task deadline enforcement.
Tasks with an expires_at in the past are transitioned to EXPIRED
by a background sweeper that runs periodically.
"""
from __future__ import annotations
import logging, threading, time
from datetime import datetime, timezone
from typing import Optional
from taskflow.backends.base import BaseBackend
from taskflow.core.models import TaskStatus

logger = logging.getLogger(__name__)

class ExpirySweeper:
    def __init__(
        self,
        backend: BaseBackend,
        interval_seconds: float = 30.0,
    ) -> None:
        self._backend = backend
        self._interval = interval_seconds
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None

    def _sweep(self) -> int:
        now = datetime.now(tz=timezone.utc)
        tasks = self._backend.list_tasks()
        expired = 0
        for task in tasks:
            if (
                task.expires_at is not None
                and task.expires_at < now
                and task.status in (TaskStatus.PENDING,)
            ):
                self._backend.update_status(task.task_id, TaskStatus.EXPIRED)
                logger.info("Expired task %s (deadline %s)", task.task_id, task.expires_at)
                expired += 1
        return expired

    def start(self) -> None:
        self._thread = threading.Thread(
            target=self._run, daemon=True, name="taskflow-expiry-sweeper"
        )
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=self._interval + 1)

    def _run(self) -> None:
        while not self._stop.is_set():
            try:
                n = self._sweep()
                if n:
                    logger.debug("Expiry sweep: %d tasks expired", n)
            except Exception as exc:
                logger.error("Expiry sweep error: %s", exc, exc_info=True)
            self._stop.wait(timeout=self._interval)
