"""
Task flow pipeline builder.

Provides a fluent API for constructing task pipelines — sequences and
parallel groups of tasks that can be submitted together and tracked
as a unit.

Example usage::

    pipeline = (
        Pipeline("data-pipeline")
        .then("etl.extract", kwargs={"source": "s3://bucket/data"})
        .then("etl.transform")
        .fan_out("etl.load_region", args_list=[["us"], ["eu"], ["ap"]])
        .build()
    )
    pipeline.submit(backend)
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional

from taskflow.core.models import Priority, Task, TaskStatus


@dataclass
class PipelineStep:
    task_name: str
    args: list = field(default_factory=list)
    kwargs: dict = field(default_factory=dict)
    queue_name: str = "default"
    priority: Priority = Priority.NORMAL
    # If True, this step is a fan-out (multiple parallel tasks)
    is_fan_out: bool = False
    fan_out_args_list: list[list] = field(default_factory=list)


@dataclass
class BuiltPipeline:
    pipeline_id: str
    steps: list[PipelineStep]
    name: str

    def submit(self, backend: Any) -> list[str]:
        """
        Submit all tasks in the pipeline to the backend.
        Returns list of task_ids in submission order.
        """
        task_ids = []
        parent_id: Optional[str] = None

        for step in self.steps:
            if step.is_fan_out:
                fan_ids = []
                for args in step.fan_out_args_list:
                    t = Task(
                        task_name=step.task_name,
                        args=args,
                        kwargs=step.kwargs,
                        queue_name=step.queue_name,
                        priority=step.priority,
                        parent_id=parent_id,
                        metadata={"pipeline_id": self.pipeline_id},
                    )
                    backend.enqueue(t)
                    fan_ids.append(t.task_id)
                task_ids.extend(fan_ids)
                # BUG: parent_id is set to the last fan-out task only,
                # so subsequent steps only chain from the last parallel branch,
                # not waiting for all of them to complete.
                parent_id = fan_ids[-1] if fan_ids else parent_id
            else:
                t = Task(
                    task_name=step.task_name,
                    args=step.args,
                    kwargs=step.kwargs,
                    queue_name=step.queue_name,
                    priority=step.priority,
                    parent_id=parent_id,
                    metadata={"pipeline_id": self.pipeline_id},
                )
                backend.enqueue(t)
                task_ids.append(t.task_id)
                parent_id = t.task_id

        return task_ids

    def task_count(self) -> int:
        count = 0
        for step in self.steps:
            if step.is_fan_out:
                count += len(step.fan_out_args_list)
            else:
                count += 1
        return count


class Pipeline:
    """Fluent pipeline builder."""

    def __init__(self, name: str = "") -> None:
        self.name = name
        self._pipeline_id = str(uuid.uuid4())
        self._steps: list[PipelineStep] = []

    def then(
        self,
        task_name: str,
        args: Optional[list] = None,
        kwargs: Optional[dict] = None,
        queue: str = "default",
        priority: Priority = Priority.NORMAL,
    ) -> "Pipeline":
        """Add a sequential step."""
        self._steps.append(PipelineStep(
            task_name=task_name,
            args=args or [],
            kwargs=kwargs or {},
            queue_name=queue,
            priority=priority,
        ))
        return self

    def fan_out(
        self,
        task_name: str,
        args_list: list[list],
        kwargs: Optional[dict] = None,
        queue: str = "default",
        priority: Priority = Priority.NORMAL,
    ) -> "Pipeline":
        """Add a parallel fan-out step."""
        self._steps.append(PipelineStep(
            task_name=task_name,
            kwargs=kwargs or {},
            queue_name=queue,
            priority=priority,
            is_fan_out=True,
            fan_out_args_list=args_list,
        ))
        return self

    def build(self) -> BuiltPipeline:
        if not self._steps:
            raise ValueError("Pipeline must have at least one step")
        return BuiltPipeline(
            pipeline_id=self._pipeline_id,
            steps=list(self._steps),
            name=self.name,
        )
