"""
Enhanced retry policy with exception filtering.
Extends the base RetryPolicy to support retry_on (whitelist)
and no_retry_on (blacklist) exception type lists.
"""
from __future__ import annotations
from typing import Optional, Sequence, Type

class RetryFilter:
    def __init__(
        self,
        retry_on: Optional[Sequence[Type[Exception]]] = None,
        no_retry_on: Optional[Sequence[Type[Exception]]] = None,
    ) -> None:
        self.retry_on = tuple(retry_on) if retry_on else ()
        self.no_retry_on = tuple(no_retry_on) if no_retry_on else ()

    def should_retry(self, exc: Exception) -> bool:
        """Return True if this exception warrants a retry attempt."""
        # no_retry_on takes precedence
        if self.no_retry_on and isinstance(exc, self.no_retry_on):
            return False
        # if retry_on specified, exc must match it
        if self.retry_on:
            return isinstance(exc, self.retry_on)
        # default: retry on everything
        return True
