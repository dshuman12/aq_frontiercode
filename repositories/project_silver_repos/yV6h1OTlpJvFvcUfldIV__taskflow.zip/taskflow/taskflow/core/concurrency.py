"""
Per-queue concurrency semaphores.
Prevents a single queue from monopolising the worker thread pool
by capping how many tasks from that queue can run simultaneously.
"""
from __future__ import annotations
import threading
from typing import Dict, Optional

class ConcurrencyLimiter:
    def __init__(self, limits: Optional[Dict[str, int]] = None) -> None:
        self._limits = limits or {}
        self._sems: Dict[str, threading.Semaphore] = {}
        self._lock = threading.Lock()

    def _sem(self, queue: str) -> Optional[threading.Semaphore]:
        if queue not in self._limits:
            return None
        with self._lock:
            if queue not in self._sems:
                self._sems[queue] = threading.Semaphore(self._limits[queue])
        return self._sems[queue]

    def acquire(self, queue: str, block: bool = True, timeout: Optional[float] = None) -> bool:
        sem = self._sem(queue)
        if sem is None:
            return True
        return sem.acquire(blocking=block, timeout=timeout or -1)

    def release(self, queue: str) -> None:
        sem = self._sem(queue)
        if sem:
            sem.release()

    def set_limit(self, queue: str, limit: int) -> None:
        with self._lock:
            self._limits[queue] = limit
            self._sems[queue] = threading.Semaphore(limit)
