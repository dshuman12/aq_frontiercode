"""
Per-task execution context, available inside task functions via
``from taskflow.core.context import current_task``.

Implemented with threading.local() so concurrent workers don't
share context across executions.
"""
from __future__ import annotations
import threading
from typing import Any, Optional

_local = threading.local()

class TaskContext:
    def __init__(
        self,
        task_id: str,
        task_name: str,
        attempt: int,
        queue_name: str,
        kwargs: dict,
    ) -> None:
        self.task_id = task_id
        self.task_name = task_name
        self.attempt = attempt
        self.queue_name = queue_name
        self.kwargs = kwargs
        self._extra: dict[str, Any] = {}

    def set(self, key: str, value: Any) -> None:
        self._extra[key] = value

    def get(self, key: str, default: Any = None) -> Any:
        return self._extra.get(key, default)

def set_current(ctx: TaskContext) -> None:
    _local.context = ctx

def get_current() -> Optional[TaskContext]:
    return getattr(_local, "context", None)

def clear_current() -> None:
    _local.context = None  # type: ignore[assignment]

# Convenience alias
current_task = get_current
