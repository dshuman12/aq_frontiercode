"""
Topological sort for task dependency graphs.
Given a dict of {task_id: [dependency_task_ids]}, returns
an execution order respecting all dependencies, or raises
if a cycle is detected.
"""
from __future__ import annotations
from collections import deque
from typing import Dict, List

def topo_sort(graph: Dict[str, List[str]]) -> List[str]:
    """
    Kahn's algorithm. Returns nodes in execution order (dependencies first).
    Raises ValueError if a cycle is detected.
    """
    in_degree: Dict[str, int] = {node: 0 for node in graph}
    for node, deps in graph.items():
        for dep in deps:
            if dep not in in_degree:
                in_degree[dep] = 0
            in_degree[node] = in_degree.get(node, 0)
    # recount
    in_degree = {n: 0 for n in graph}
    for node, deps in graph.items():
        for dep in deps:
            in_degree[node] = in_degree.get(node, 0)
    # proper count
    in_degree = {n: 0 for n in graph}
    reverse: Dict[str, List[str]] = {n: [] for n in graph}
    for node, deps in graph.items():
        for dep in deps:
            if dep not in reverse:
                reverse[dep] = []
            reverse[dep].append(node)
            in_degree[node] = in_degree.get(node, 0) + 1

    queue: deque[str] = deque(n for n, d in in_degree.items() if d == 0)
    order: List[str] = []
    while queue:
        node = queue.popleft()
        order.append(node)
        for dependent in reverse.get(node, []):
            in_degree[dependent] -= 1
            if in_degree[dependent] == 0:
                queue.append(dependent)

    if len(order) != len(graph):
        raise ValueError("Cycle detected in task dependency graph")
    return order
