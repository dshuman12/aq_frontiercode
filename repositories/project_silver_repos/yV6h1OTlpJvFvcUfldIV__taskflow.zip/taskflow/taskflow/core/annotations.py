"""
Declarative annotations for task definitions.
Attach structured metadata (SLO, owner, cost, criticality)
without polluting task kwargs.
"""
from __future__ import annotations
from dataclasses import asdict, dataclass
from typing import Any, Dict, Optional

@dataclass
class TaskAnnotation:
    owner: Optional[str] = None          # team or person responsible
    slo_seconds: Optional[float] = None  # expected max execution time
    cost_class: Optional[str] = None     # 'cheap' | 'moderate' | 'expensive'
    critical: bool = False
    tags: tuple[str, ...] = ()
    extra: Dict[str, Any] = None

    def __post_init__(self):
        if self.extra is None:
            self.extra = {}

    def to_dict(self) -> dict:
        return asdict(self)

_annotations: Dict[str, TaskAnnotation] = {}

def annotate(task_name: str, annotation: TaskAnnotation) -> None:
    _annotations[task_name] = annotation

def get_annotation(task_name: str) -> Optional[TaskAnnotation]:
    return _annotations.get(task_name)

def all_annotations() -> Dict[str, TaskAnnotation]:
    return dict(_annotations)
