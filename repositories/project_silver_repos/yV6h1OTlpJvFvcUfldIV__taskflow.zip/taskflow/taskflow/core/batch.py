"""Bulk task submission helpers for efficient batched enqueuing."""
from __future__ import annotations
from typing import Any
from taskflow.backends.base import BaseBackend
from taskflow.core.models import Task, Priority
import uuid

def enqueue_many(
    backend: BaseBackend,
    task_name: str,
    payloads: list[dict[str, Any]],
    queue_name: str = "default",
    priority: Priority = Priority.NORMAL,
) -> list[str]:
    """Enqueue a list of payloads as individual tasks. Returns list of task IDs."""
    ids = []
    for kwargs in payloads:
        task = Task(
            task_id=str(uuid.uuid4()),
            name=task_name,
            queue_name=queue_name,
            priority=priority,
            args=[],
            kwargs=kwargs,
        )
        backend.enqueue(task)
        ids.append(task.task_id)
    return ids
