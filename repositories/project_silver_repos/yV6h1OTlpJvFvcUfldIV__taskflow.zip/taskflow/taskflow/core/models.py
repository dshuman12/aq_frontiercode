"""
Core data models for taskflow.

Defines the fundamental types used throughout the system:
Task, TaskResult, TaskStatus, Priority, RetryPolicy, Schedule, and Queue.
"""

from __future__ import annotations

import hashlib
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum, auto
from typing import Any, Callable, Dict, List, Optional, Tuple, Type


# ---------------------------------------------------------------------------
# Enumerations
# ---------------------------------------------------------------------------

class TaskStatus(Enum):
    """Lifecycle states for a task."""
    PENDING = "pending"
    QUEUED = "queued"
    RUNNING = "running"
    SUCCESS = "success"
    FAILURE = "failure"
    RETRY = "retry"
    REVOKED = "revoked"
    EXPIRED = "expired"

    @property
    def is_terminal(self) -> bool:
        return self in (
            TaskStatus.SUCCESS,
            TaskStatus.FAILURE,
            TaskStatus.REVOKED,
            TaskStatus.EXPIRED,
        )

    @property
    def is_active(self) -> bool:
        return self in (TaskStatus.QUEUED, TaskStatus.RUNNING, TaskStatus.RETRY)


class Priority(Enum):
    """Task priority levels. Lower value = higher priority."""
    CRITICAL = 0
    HIGH = 1
    NORMAL = 2
    LOW = 3
    BULK = 4

    @classmethod
    def from_string(cls, s: str) -> "Priority":
        try:
            return cls[s.upper()]
        except KeyError:
            raise ValueError(f"Unknown priority: {s!r}. Choose from {[p.name for p in cls]}")

    @classmethod
    def from_int(cls, n: int) -> "Priority":
        for p in cls:
            if p.value == n:
                return p
        raise ValueError(f"No priority with value {n}")


class QueueStatus(Enum):
    ACTIVE = "active"
    PAUSED = "paused"
    DRAINING = "draining"
    CLOSED = "closed"


# ---------------------------------------------------------------------------
# Retry Policy
# ---------------------------------------------------------------------------

@dataclass
class RetryPolicy:
    """
    Defines how and when a failed task should be retried.

    Supports fixed delay, linear backoff, and exponential backoff strategies.
    """

    max_retries: int = 3
    delay_seconds: float = 5.0
    backoff: str = "exponential"   # "fixed", "linear", "exponential"
    backoff_factor: float = 2.0
    max_delay_seconds: float = 3600.0
    jitter: bool = True
    retry_on: Tuple[Type[Exception], ...] = field(default_factory=tuple)
    ignore_on: Tuple[Type[Exception], ...] = field(default_factory=tuple)

    def delay_for_attempt(self, attempt: int) -> float:
        """Calculate the delay before the nth retry attempt (1-indexed)."""
        import random
        if self.backoff == "fixed":
            delay = self.delay_seconds
        elif self.backoff == "linear":
            delay = self.delay_seconds * attempt
        elif self.backoff == "exponential":
            delay = self.delay_seconds * (self.backoff_factor ** (attempt - 1))
        else:
            delay = self.delay_seconds

        delay = min(delay, self.max_delay_seconds)

        if self.jitter:
            # Add up to 10% random jitter to avoid thundering herd
            delay += random.uniform(0, delay * 0.1)

        return delay

    def should_retry_on(self, exc: Exception) -> bool:
        """
        Return True if the given exception warrants a retry.

        If retry_on is empty, all exceptions are retried (unless in ignore_on).
        If retry_on is non-empty, only listed exception types are retried.
        """
        if self.ignore_on and isinstance(exc, self.ignore_on):
            return False
        if self.retry_on:
            return isinstance(exc, self.retry_on)
        return True

    def to_dict(self) -> dict:
        return {
            "max_retries": self.max_retries,
            "delay_seconds": self.delay_seconds,
            "backoff": self.backoff,
            "backoff_factor": self.backoff_factor,
            "max_delay_seconds": self.max_delay_seconds,
            "jitter": self.jitter,
        }

    @classmethod
    def no_retry(cls) -> "RetryPolicy":
        return cls(max_retries=0)

    @classmethod
    def aggressive(cls) -> "RetryPolicy":
        return cls(max_retries=10, delay_seconds=1.0, backoff="exponential")

    @classmethod
    def gentle(cls) -> "RetryPolicy":
        return cls(max_retries=3, delay_seconds=30.0, backoff="linear", jitter=False)


# ---------------------------------------------------------------------------
# Task Definition
# ---------------------------------------------------------------------------

@dataclass
class TaskDefinition:
    """
    Metadata describing a registered task type (not an instance).

    Created when @task is used to decorate a function.
    """

    name: str
    func: Callable
    queue_name: str = "default"
    priority: Priority = Priority.NORMAL
    retry_policy: RetryPolicy = field(default_factory=RetryPolicy)
    timeout_seconds: Optional[float] = None
    max_concurrency: Optional[int] = None
    description: str = ""
    tags: List[str] = field(default_factory=list)
    rate_limit: Optional[str] = None   # e.g. "100/minute"
    serializer: str = "json"

    def __call__(self, *args, **kwargs) -> Any:
        return self.func(*args, **kwargs)

    def __repr__(self) -> str:
        return f"TaskDefinition(name={self.name!r}, queue={self.queue_name!r})"


# ---------------------------------------------------------------------------
# Task Instance
# ---------------------------------------------------------------------------

@dataclass
class Task:
    """
    A single enqueued or executing task instance.

    Created when task.delay() or task.apply_async() is called.
    """

    task_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    task_name: str = ""
    args: List[Any] = field(default_factory=list)
    kwargs: Dict[str, Any] = field(default_factory=dict)
    queue_name: str = "default"
    priority: Priority = Priority.NORMAL
    status: TaskStatus = TaskStatus.PENDING
    retry_policy: RetryPolicy = field(default_factory=RetryPolicy)
    attempt: int = 0
    max_retries: int = 3

    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    queued_at: Optional[datetime] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    eta: Optional[datetime] = None           # Earliest time to execute
    expires_at: Optional[datetime] = None    # Deadline — discard after this

    timeout_seconds: Optional[float] = None
    worker_id: Optional[str] = None
    correlation_id: Optional[str] = None     # For tracing across tasks
    parent_id: Optional[str] = None          # For task chains/groups
    tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None
    traceback: Optional[str] = None
    serializer: str = "json"

    def __post_init__(self) -> None:
        if isinstance(self.priority, int):
            self.priority = Priority.from_int(self.priority)
        if isinstance(self.status, str):
            self.status = TaskStatus(self.status)

    @property
    def age_seconds(self) -> float:
        return (datetime.now(timezone.utc) - self.created_at).total_seconds()

    @property
    def run_time_seconds(self) -> Optional[float]:
        if self.started_at and self.completed_at:
            return (self.completed_at - self.started_at).total_seconds()
        return None

    @property
    def is_overdue(self) -> bool:
        if self.expires_at is None:
            return False
        return datetime.now(timezone.utc) > self.expires_at

    @property
    def is_ready(self) -> bool:
        """Return True if the task's ETA has passed (or it has no ETA)."""
        if self.eta is None:
            return True
        return datetime.now(timezone.utc) >= self.eta

    def can_retry(self) -> bool:
        return self.attempt < self.retry_policy.max_retries

    def next_retry_eta(self) -> datetime:
        delay = self.retry_policy.delay_for_attempt(self.attempt + 1)
        return datetime.now(timezone.utc) + timedelta(seconds=delay)

    def fingerprint(self) -> str:
        """Compute a stable hash of the task name + args for deduplication."""
        import json
        payload = json.dumps(
            {"name": self.task_name, "args": self.args, "kwargs": self.kwargs},
            sort_keys=True,
            default=str,
        )
        return hashlib.sha256(payload.encode()).hexdigest()[:16]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "task_id": self.task_id,
            "task_name": self.task_name,
            "args": self.args,
            "kwargs": self.kwargs,
            "queue_name": self.queue_name,
            "priority": self.priority.value,
            "status": self.status.value,
            "attempt": self.attempt,
            "max_retries": self.max_retries,
            "created_at": self.created_at.isoformat(),
            "queued_at": self.queued_at.isoformat() if self.queued_at else None,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "eta": self.eta.isoformat() if self.eta else None,
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
            "timeout_seconds": self.timeout_seconds,
            "worker_id": self.worker_id,
            "correlation_id": self.correlation_id,
            "parent_id": self.parent_id,
            "tags": self.tags,
            "metadata": self.metadata,
            "error": self.error,
            "traceback": self.traceback,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Task":
        task = cls(
            task_id=data["task_id"],
            task_name=data["task_name"],
            args=data.get("args", []),
            kwargs=data.get("kwargs", {}),
            queue_name=data.get("queue_name", "default"),
            priority=Priority(data.get("priority", Priority.NORMAL.value)),
            status=TaskStatus(data.get("status", TaskStatus.PENDING.value)),
            attempt=data.get("attempt", 0),
            max_retries=data.get("max_retries", 3),
            timeout_seconds=data.get("timeout_seconds"),
            worker_id=data.get("worker_id"),
            correlation_id=data.get("correlation_id"),
            parent_id=data.get("parent_id"),
            tags=data.get("tags", []),
            metadata=data.get("metadata", {}),
            error=data.get("error"),
            traceback=data.get("traceback"),
        )
        for dt_field in ("created_at", "queued_at", "started_at", "completed_at", "eta", "expires_at"):
            val = data.get(dt_field)
            if val:
                setattr(task, dt_field, datetime.fromisoformat(val))
        return task


# ---------------------------------------------------------------------------
# Task Result
# ---------------------------------------------------------------------------

@dataclass
class TaskResult:
    """Stores the outcome of a completed or failed task execution."""

    task_id: str
    status: TaskStatus
    return_value: Any = None
    error: Optional[str] = None
    traceback: Optional[str] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    worker_id: Optional[str] = None

    @property
    def succeeded(self) -> bool:
        return self.status == TaskStatus.SUCCESS

    @property
    def failed(self) -> bool:
        return self.status == TaskStatus.FAILURE

    @property
    def run_time_seconds(self) -> Optional[float]:
        if self.started_at and self.completed_at:
            return (self.completed_at - self.started_at).total_seconds()
        return None

    def to_dict(self) -> dict:
        return {
            "task_id": self.task_id,
            "status": self.status.value,
            "return_value": self.return_value,
            "error": self.error,
            "traceback": self.traceback,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "worker_id": self.worker_id,
            "run_time_seconds": self.run_time_seconds,
        }


# ---------------------------------------------------------------------------
# Queue Metadata
# ---------------------------------------------------------------------------

@dataclass
class QueueInfo:
    """Metadata about a named task queue."""

    name: str
    status: QueueStatus = QueueStatus.ACTIVE
    pending_count: int = 0
    running_count: int = 0
    completed_count: int = 0
    failed_count: int = 0
    total_enqueued: int = 0
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    last_activity: Optional[datetime] = None
    worker_count: int = 0
    max_concurrency: Optional[int] = None
    tags: List[str] = field(default_factory=list)

    @property
    def is_empty(self) -> bool:
        return self.pending_count == 0 and self.running_count == 0

    @property
    def throughput_estimate(self) -> float:
        """Very rough tasks/second estimate from completed count and age."""
        age = (datetime.now(timezone.utc) - self.created_at).total_seconds()
        if age == 0:
            return 0.0
        return self.completed_count / age

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "status": self.status.value,
            "pending": self.pending_count,
            "running": self.running_count,
            "completed": self.completed_count,
            "failed": self.failed_count,
            "total_enqueued": self.total_enqueued,
            "worker_count": self.worker_count,
        }


# ---------------------------------------------------------------------------
# Task Group / Chain primitives
# ---------------------------------------------------------------------------

@dataclass
class TaskGroup:
    """A group of tasks that run in parallel."""

    group_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    tasks: List[Task] = field(default_factory=list)
    chord_callback: Optional[Task] = None  # called when all tasks complete

    def add(self, task: Task) -> None:
        self.tasks.append(task)

    @property
    def all_done(self) -> bool:
        return all(t.status.is_terminal for t in self.tasks)

    @property
    def any_failed(self) -> bool:
        return any(t.status == TaskStatus.FAILURE for t in self.tasks)

    def to_dict(self) -> dict:
        return {
            "group_id": self.group_id,
            "tasks": [t.to_dict() for t in self.tasks],
            "all_done": self.all_done,
            "any_failed": self.any_failed,
        }


@dataclass
class TaskChain:
    """A sequence of tasks that run one after another."""

    chain_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    tasks: List[Task] = field(default_factory=list)
    current_index: int = 0
    propagate_result: bool = True  # pass output of each task as input to next

    @property
    def current_task(self) -> Optional[Task]:
        if self.current_index < len(self.tasks):
            return self.tasks[self.current_index]
        return None

    @property
    def is_complete(self) -> bool:
        return self.current_index >= len(self.tasks)

    def advance(self) -> Optional[Task]:
        self.current_index += 1
        return self.current_task

    def to_dict(self) -> dict:
        return {
            "chain_id": self.chain_id,
            "current_index": self.current_index,
            "length": len(self.tasks),
            "is_complete": self.is_complete,
            "tasks": [t.to_dict() for t in self.tasks],
        }
