"""
ETA (Earliest Time of Arrival) validation and queue delay logic.

Tasks with a future ETA are held until the scheduled time
before being made available for dequeue.
"""
from __future__ import annotations
from datetime import datetime, timezone
from typing import Optional
from taskflow.core.models import Task

def is_ready(task: Task, now: Optional[datetime] = None) -> bool:
    """Return True if the task's ETA has passed or was not set."""
    if task.eta is None:
        return True
    now = now or datetime.now(tz=timezone.utc)
    return now >= task.eta

def seconds_until_ready(task: Task, now: Optional[datetime] = None) -> float:
    """Seconds remaining until task is ready. Returns 0.0 if already ready."""
    if task.eta is None:
        return 0.0
    now = now or datetime.now(tz=timezone.utc)
    delta = (task.eta - now).total_seconds()
    return max(0.0, delta)

def validate_eta(task: Task) -> None:
    """Raise ValueError if ETA is in the past by more than 10 minutes."""
    if task.eta is None:
        return
    now = datetime.now(tz=timezone.utc)
    lag = (now - task.eta).total_seconds()
    if lag > 600:
        raise ValueError(
            f"Task ETA {task.eta.isoformat()} is {lag:.0f}s in the past. "
            "This task will execute immediately. Pass validate_eta=False to suppress."
        )
