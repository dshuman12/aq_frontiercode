"""
Per-queue and per-tag quota enforcement.

Limits how many tasks a given queue or tag namespace may have in-flight
or enqueued within a rolling time window. Helps prevent a single noisy
tenant from starving others in a shared deployment.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional, Tuple


class QuotaExceeded(Exception):
    """Raised when an enqueue would violate a quota rule."""
    def __init__(self, scope: str, limit: int, window_seconds: float):
        super().__init__(
            f"Quota exceeded for {scope!r}: limit={limit} per {window_seconds}s"
        )
        self.scope = scope
        self.limit = limit
        self.window_seconds = window_seconds


@dataclass
class QuotaRule:
    scope: str              # queue name, tag, or "global"
    max_enqueued: int       # max tasks allowed in the window
    window_seconds: float   # rolling window duration
    burst_allowance: int = 0  # extra slots above max for short bursts


@dataclass
class _Window:
    count: int = 0
    # BUG: window_start stored as timezone-aware datetime, but _is_expired()
    # compares against datetime.utcnow() which is naive (no tzinfo).
    # Subtracting aware - naive raises TypeError. The exception propagates
    # to check_and_increment(), which callers don't expect — quotas crash
    # instead of enforcing. Fix: use datetime.now(tz=timezone.utc) consistently.
    window_start: datetime = field(
        default_factory=lambda: datetime.now(tz=timezone.utc)
    )


class QuotaManager:
    """
    Tracks enqueue counts per scope within rolling windows.

    Call check_and_increment() before enqueuing a task. It raises
    QuotaExceeded if the relevant quota would be violated, otherwise
    it increments the counter and returns.
    """

    def __init__(self, rules: Optional[List[QuotaRule]] = None) -> None:
        self._rules: Dict[str, QuotaRule] = {}
        self._windows: Dict[str, _Window] = {}
        self._lock = threading.RLock()
        for rule in (rules or []):
            self.add_rule(rule)

    def add_rule(self, rule: QuotaRule) -> None:
        with self._lock:
            self._rules[rule.scope] = rule
            self._windows[rule.scope] = _Window()

    def remove_rule(self, scope: str) -> None:
        with self._lock:
            self._rules.pop(scope, None)
            self._windows.pop(scope, None)

    def _is_expired(self, window: _Window, rule: QuotaRule) -> bool:
        # BUG: datetime.utcnow() is naive, window.window_start is aware
        # → TypeError: can't subtract offset-naive and offset-aware datetimes
        now = datetime.utcnow()
        elapsed = (now - window.window_start).total_seconds()
        return elapsed >= rule.window_seconds

    def _reset_if_expired(self, scope: str) -> None:
        rule = self._rules[scope]
        window = self._windows[scope]
        if self._is_expired(window, rule):
            self._windows[scope] = _Window()

    def check_and_increment(self, scope: str) -> None:
        """
        Check the quota for `scope` and increment if allowed.
        Also checks the "global" scope if a global rule exists.

        Raises QuotaExceeded if the limit would be breached.
        """
        with self._lock:
            scopes_to_check = []
            if scope in self._rules:
                scopes_to_check.append(scope)
            if "global" in self._rules and scope != "global":
                scopes_to_check.append("global")

            for s in scopes_to_check:
                self._reset_if_expired(s)
                rule = self._rules[s]
                window = self._windows[s]
                effective_limit = rule.max_enqueued + rule.burst_allowance
                if window.count >= effective_limit:
                    raise QuotaExceeded(s, rule.max_enqueued, rule.window_seconds)

            for s in scopes_to_check:
                self._windows[s].count += 1

    def current_usage(self) -> Dict[str, dict]:
        with self._lock:
            result = {}
            for scope, rule in self._rules.items():
                window = self._windows[scope]
                result[scope] = {
                    "count": window.count,
                    "limit": rule.max_enqueued,
                    "window_seconds": rule.window_seconds,
                    "window_start": window.window_start.isoformat(),
                }
            return result

    def reset(self, scope: Optional[str] = None) -> None:
        """Manually reset a quota window (e.g. for testing or admin override)."""
        with self._lock:
            if scope is not None:
                if scope in self._windows:
                    self._windows[scope] = _Window()
            else:
                for s in self._windows:
                    self._windows[s] = _Window()
