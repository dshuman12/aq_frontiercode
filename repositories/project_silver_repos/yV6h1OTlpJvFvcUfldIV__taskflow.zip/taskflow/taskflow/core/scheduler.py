"""
Task scheduler — runs periodic and cron-scheduled tasks.

Supports fixed-interval schedules (every N seconds) and cron expressions.
The scheduler runs in a background thread and enqueues tasks via a backend.
"""

from __future__ import annotations

import logging
import re
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from typing import Any, Callable, Dict, List, Optional, Union

from taskflow.core.models import Priority, Task, TaskStatus
from taskflow.core.registry import TaskRegistry, get_registry

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Schedule types
# ---------------------------------------------------------------------------

@dataclass
class IntervalSchedule:
    """Run a task every N seconds."""
    seconds: float
    last_run: Optional[datetime] = None
    run_immediately: bool = True

    def is_due(self) -> bool:
        if self.last_run is None:
            return self.run_immediately
        elapsed = (datetime.now(timezone.utc) - self.last_run).total_seconds()
        return elapsed >= self.seconds

    def next_run(self) -> datetime:
        if self.last_run is None:
            return datetime.now(timezone.utc)
        return self.last_run + timedelta(seconds=self.seconds)

    def mark_ran(self) -> None:
        self.last_run = datetime.now(timezone.utc)

    def __repr__(self) -> str:
        return f"IntervalSchedule(every={self.seconds}s)"


@dataclass
class CronSchedule:
    """
    Run a task on a cron schedule.

    Supports standard 5-field cron syntax:
        minute hour day_of_month month day_of_week
        0-59   0-23  1-31         1-12  0-6 (0=Sunday)

    Supports '*' (any), '*/N' (every N), and comma-separated values.
    Does not support ranges (1-5) or last-day specifiers.
    """

    expression: str
    last_run: Optional[datetime] = None
    _parsed: Optional[dict] = field(default=None, repr=False, compare=False)

    def __post_init__(self) -> None:
        self._parsed = self._parse(self.expression)

    def _parse(self, expr: str) -> dict:
        fields = expr.strip().split()
        if len(fields) != 5:
            raise ValueError(
                f"Invalid cron expression {expr!r}. Expected 5 fields: "
                "minute hour day_of_month month day_of_week"
            )
        names = ["minute", "hour", "day", "month", "weekday"]
        limits = [(0, 59), (0, 23), (1, 31), (1, 12), (0, 6)]
        result = {}
        for name, field_str, (lo, hi) in zip(names, fields, limits):
            result[name] = self._expand_field(field_str, lo, hi)
        return result

    def _expand_field(self, s: str, lo: int, hi: int) -> set:
        if s == "*":
            return set(range(lo, hi + 1))
        if s.startswith("*/"):
            step = int(s[2:])
            return set(range(lo, hi + 1, step))
        values = set()
        for part in s.split(","):
            if "-" in part:
                a, b = part.split("-", 1)
                values.update(range(int(a), int(b) + 1))
            else:
                values.add(int(part))
        return values

    def is_due(self) -> bool:
        now = datetime.now(timezone.utc)
        if self.last_run and (now - self.last_run).total_seconds() < 60:
            return False
        p = self._parsed
        return (
            now.minute in p["minute"]
            and now.hour in p["hour"]
            and now.day in p["day"]
            and now.month in p["month"]
            and (now.weekday() + 1) % 7 in p["weekday"]
        )

    def mark_ran(self) -> None:
        self.last_run = datetime.now(timezone.utc)

    def __repr__(self) -> str:
        return f"CronSchedule({self.expression!r})"


Schedule = Union[IntervalSchedule, CronSchedule]


# ---------------------------------------------------------------------------
# Scheduled entry
# ---------------------------------------------------------------------------

@dataclass
class ScheduledTask:
    """A named task paired with a schedule."""
    name: str
    task_name: str
    schedule: Schedule
    args: list = field(default_factory=list)
    kwargs: dict = field(default_factory=dict)
    queue_name: str = "default"
    priority: Priority = Priority.NORMAL
    enabled: bool = True
    description: str = ""
    run_count: int = 0
    last_enqueued_id: Optional[str] = None

    def is_due(self) -> bool:
        return self.enabled and self.schedule.is_due()

    def mark_ran(self) -> None:
        self.schedule.mark_ran()
        self.run_count += 1

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "task_name": self.task_name,
            "schedule": repr(self.schedule),
            "queue_name": self.queue_name,
            "enabled": self.enabled,
            "run_count": self.run_count,
            "last_enqueued_id": self.last_enqueued_id,
        }


# ---------------------------------------------------------------------------
# Scheduler
# ---------------------------------------------------------------------------

class Scheduler:
    """
    Background thread that enqueues tasks on a schedule.

    Usage::

        scheduler = Scheduler(backend)
        scheduler.add("cleanup", "myapp.tasks.cleanup", IntervalSchedule(3600))
        scheduler.add("report", "myapp.tasks.daily_report", CronSchedule("0 8 * * *"))
        scheduler.start()
    """

    def __init__(
        self,
        backend: Any,
        tick_interval: float = 10.0,
    ) -> None:
        self.backend = backend
        self.tick_interval = tick_interval
        self._entries: Dict[str, ScheduledTask] = {}
        self._lock = threading.RLock()
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()

    def add(
        self,
        name: str,
        task_name: str,
        schedule: Schedule,
        args: Optional[list] = None,
        kwargs: Optional[dict] = None,
        queue_name: str = "default",
        priority: Priority = Priority.NORMAL,
        description: str = "",
        enabled: bool = True,
    ) -> ScheduledTask:
        """Register a scheduled task entry."""
        entry = ScheduledTask(
            name=name,
            task_name=task_name,
            schedule=schedule,
            args=args or [],
            kwargs=kwargs or {},
            queue_name=queue_name,
            priority=priority,
            description=description,
            enabled=enabled,
        )
        with self._lock:
            self._entries[name] = entry
        logger.info("Scheduler: registered '%s' (%s)", name, schedule)
        return entry

    def remove(self, name: str) -> bool:
        with self._lock:
            existed = name in self._entries
            self._entries.pop(name, None)
        return existed

    def enable(self, name: str) -> None:
        with self._lock:
            if name in self._entries:
                self._entries[name].enabled = True

    def disable(self, name: str) -> None:
        with self._lock:
            if name in self._entries:
                self._entries[name].enabled = False

    def start(self, block: bool = False) -> None:
        self._thread = threading.Thread(
            target=self._run, daemon=True, name="taskflow-scheduler"
        )
        self._thread.start()
        logger.info("Scheduler started (tick_interval=%.1fs)", self.tick_interval)
        if block:
            self._thread.join()

    def stop(self) -> None:
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=self.tick_interval + 1)
        logger.info("Scheduler stopped")

    def _run(self) -> None:
        while not self._stop_event.is_set():
            try:
                self._tick()
            except Exception as exc:
                logger.error("Scheduler tick error: %s", exc, exc_info=True)
            self._stop_event.wait(timeout=self.tick_interval)

    def _tick(self) -> None:
        with self._lock:
            entries = list(self._entries.values())

        for entry in entries:
            if entry.is_due():
                try:
                    self._enqueue(entry)
                    entry.mark_ran()
                    logger.info(
                        "Scheduler: enqueued '%s' (run #%d)", entry.name, entry.run_count
                    )
                except Exception as exc:
                    logger.error(
                        "Scheduler: failed to enqueue '%s': %s", entry.name, exc
                    )

    def _enqueue(self, entry: ScheduledTask) -> Task:
        from datetime import datetime, timezone
        task = Task(
            task_name=entry.task_name,
            args=entry.args,
            kwargs=entry.kwargs,
            queue_name=entry.queue_name,
            priority=entry.priority,
            status=TaskStatus.PENDING,
            created_at=datetime.now(timezone.utc),
            metadata={"scheduled_by": entry.name},
        )
        self.backend.enqueue(task)
        entry.last_enqueued_id = task.task_id
        return task

    def all_entries(self) -> List[ScheduledTask]:
        with self._lock:
            return list(self._entries.values())

    def status(self) -> dict:
        with self._lock:
            return {
                "entries": len(self._entries),
                "enabled": sum(1 for e in self._entries.values() if e.enabled),
                "schedules": [e.to_dict() for e in self._entries.values()],
            }

# clock-skew fix: compare with abs() delta
