"""
Task registry — central store of all registered task definitions.

Tasks are registered via the @task decorator or TaskRegistry.register().
The registry is a singleton accessible via get_registry().
"""

from __future__ import annotations

import functools
import inspect
import threading
from typing import Any, Callable, Dict, Iterator, List, Optional, Type

from taskflow.core.models import Priority, RetryPolicy, Task, TaskDefinition, TaskStatus


class RegistryError(Exception):
    """Raised for registry configuration errors."""


class DuplicateTaskError(RegistryError):
    """Raised when a task name is already registered."""


class TaskNotFoundError(RegistryError):
    """Raised when a task name cannot be found."""


class TaskRegistry:
    """
    Thread-safe registry of task definitions.

    Supports registration, lookup, introspection, and iteration.
    """

    def __init__(self) -> None:
        self._tasks: Dict[str, TaskDefinition] = {}
        self._lock = threading.RLock()
        self._aliases: Dict[str, str] = {}  # alias -> canonical name

    def register(
        self,
        func: Callable,
        name: Optional[str] = None,
        queue_name: str = "default",
        priority: Priority = Priority.NORMAL,
        retry_policy: Optional[RetryPolicy] = None,
        timeout_seconds: Optional[float] = None,
        max_concurrency: Optional[int] = None,
        description: str = "",
        tags: Optional[List[str]] = None,
        rate_limit: Optional[str] = None,
        serializer: str = "json",
        overwrite: bool = False,
    ) -> TaskDefinition:
        """Register a callable as a named task."""
        task_name = name or f"{func.__module__}.{func.__qualname__}"
        policy = retry_policy or RetryPolicy()

        definition = TaskDefinition(
            name=task_name,
            func=func,
            queue_name=queue_name,
            priority=priority,
            retry_policy=policy,
            timeout_seconds=timeout_seconds,
            max_concurrency=max_concurrency,
            description=description or (inspect.getdoc(func) or ""),
            tags=tags or [],
            rate_limit=rate_limit,
            serializer=serializer,
        )

        with self._lock:
            if task_name in self._tasks and not overwrite:
                raise DuplicateTaskError(
                    f"Task '{task_name}' is already registered. "
                    "Use overwrite=True to replace it."
                )
            self._tasks[task_name] = definition

        return definition

    def get(self, name: str) -> TaskDefinition:
        """Look up a task definition by name. Raises TaskNotFoundError if missing."""
        with self._lock:
            # Check aliases first
            canonical = self._aliases.get(name, name)
            defn = self._tasks.get(canonical)
        if defn is None:
            available = self.task_names()
            raise TaskNotFoundError(
                f"No task named {name!r}. "
                f"Registered tasks: {available}"
            )
        return defn

    def get_or_none(self, name: str) -> Optional[TaskDefinition]:
        try:
            return self.get(name)
        except TaskNotFoundError:
            return None

    def unregister(self, name: str) -> bool:
        """Remove a task from the registry. Returns True if it existed."""
        with self._lock:
            existed = name in self._tasks
            self._tasks.pop(name, None)
            # Remove any aliases pointing to this name
            stale = [k for k, v in self._aliases.items() if v == name]
            for k in stale:
                del self._aliases[k]
        return existed

    def add_alias(self, alias: str, canonical_name: str) -> None:
        """Register an alternative name for an existing task."""
        with self._lock:
            if canonical_name not in self._tasks:
                raise TaskNotFoundError(f"Cannot alias unknown task {canonical_name!r}")
            self._aliases[alias] = canonical_name

    def task_names(self) -> List[str]:
        with self._lock:
            return sorted(self._tasks.keys())

    def all_definitions(self) -> List[TaskDefinition]:
        with self._lock:
            return list(self._tasks.values())

    def __contains__(self, name: str) -> bool:
        with self._lock:
            return name in self._tasks or name in self._aliases

    def __len__(self) -> int:
        with self._lock:
            return len(self._tasks)

    def __iter__(self) -> Iterator[TaskDefinition]:
        with self._lock:
            items = list(self._tasks.values())
        yield from items

    def tasks_in_queue(self, queue_name: str) -> List[TaskDefinition]:
        """Return all task definitions targeting a given queue."""
        with self._lock:
            return [d for d in self._tasks.values() if d.queue_name == queue_name]

    def tasks_with_tag(self, tag: str) -> List[TaskDefinition]:
        with self._lock:
            return [d for d in self._tasks.values() if tag in d.tags]

    def clear(self) -> None:
        """Remove all registered tasks. Useful for testing."""
        with self._lock:
            self._tasks.clear()
            self._aliases.clear()

    def summary(self) -> dict:
        with self._lock:
            queues: Dict[str, int] = {}
            for d in self._tasks.values():
                queues[d.queue_name] = queues.get(d.queue_name, 0) + 1
            return {
                "total_tasks": len(self._tasks),
                "queues": queues,
                "aliases": len(self._aliases),
            }


# ---------------------------------------------------------------------------
# Global singleton registry
# ---------------------------------------------------------------------------

_global_registry: Optional[TaskRegistry] = None
_registry_lock = threading.Lock()


def get_registry() -> TaskRegistry:
    """Return the global task registry, creating it if necessary."""
    global _global_registry
    if _global_registry is None:
        with _registry_lock:
            if _global_registry is None:
                _global_registry = TaskRegistry()
    return _global_registry


def reset_registry() -> None:
    """Reset the global registry. Intended for tests only."""
    global _global_registry
    with _registry_lock:
        _global_registry = TaskRegistry()


# ---------------------------------------------------------------------------
# @task decorator
# ---------------------------------------------------------------------------

def task(
    func: Optional[Callable] = None,
    *,
    name: Optional[str] = None,
    queue: str = "default",
    priority: Priority = Priority.NORMAL,
    retry_policy: Optional[RetryPolicy] = None,
    max_retries: int = 3,
    retry_delay: float = 5.0,
    retry_backoff: str = "exponential",
    timeout: Optional[float] = None,
    max_concurrency: Optional[int] = None,
    tags: Optional[List[str]] = None,
    rate_limit: Optional[str] = None,
    serializer: str = "json",
    description: str = "",
    registry: Optional[TaskRegistry] = None,
) -> Any:
    """
    Decorator that registers a function as a taskflow task.

    Can be used with or without arguments::

        @task
        def send_email(to, subject, body): ...

        @task(queue="emails", priority=Priority.HIGH, max_retries=5)
        def send_email(to, subject, body): ...

    The decorated function gains `.delay()` and `.apply_async()` methods.
    """
    reg = registry or get_registry()

    def decorator(fn: Callable) -> TaskDefinition:
        policy = retry_policy or RetryPolicy(
            max_retries=max_retries,
            delay_seconds=retry_delay,
            backoff=retry_backoff,
        )
        defn = reg.register(
            fn,
            name=name,
            queue_name=queue,
            priority=priority,
            retry_policy=policy,
            timeout_seconds=timeout,
            max_concurrency=max_concurrency,
            tags=tags,
            rate_limit=rate_limit,
            serializer=serializer,
            description=description,
        )

        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            return fn(*args, **kwargs)

        wrapper.task_definition = defn  # type: ignore[attr-defined]

        def delay(*args: Any, **kwargs: Any) -> Task:
            """Enqueue this task for asynchronous execution."""
            return _make_task_instance(defn, args, kwargs)

        def apply_async(
            args: Optional[tuple] = None,
            kwargs: Optional[dict] = None,
            priority: Optional[Priority] = None,
            eta: Optional[Any] = None,
            expires: Optional[Any] = None,
            countdown: Optional[float] = None,
            correlation_id: Optional[str] = None,
        ) -> Task:
            """Enqueue with fine-grained control over execution parameters."""
            from datetime import datetime, timedelta, timezone
            t = _make_task_instance(defn, args or (), kwargs or {})
            if priority is not None:
                t.priority = priority
            if eta is not None:
                t.eta = eta
            if expires is not None:
                t.expires_at = expires
            if countdown is not None:
                t.eta = datetime.now(timezone.utc) + timedelta(seconds=countdown)
            if correlation_id is not None:
                t.correlation_id = correlation_id
            return t

        wrapper.delay = delay  # type: ignore[attr-defined]
        wrapper.apply_async = apply_async  # type: ignore[attr-defined]
        wrapper.__taskflow__ = True  # type: ignore[attr-defined]

        return wrapper  # type: ignore[return-value]

    if func is not None:
        return decorator(func)
    return decorator


def _make_task_instance(defn: TaskDefinition, args: tuple, kwargs: dict) -> Task:
    """Create a Task instance from a definition and call arguments."""
    from datetime import datetime, timezone
    return Task(
        task_name=defn.name,
        args=list(args),
        kwargs=kwargs,
        queue_name=defn.queue_name,
        priority=defn.priority,
        retry_policy=defn.retry_policy,
        max_retries=defn.retry_policy.max_retries,
        timeout_seconds=defn.timeout_seconds,
        tags=list(defn.tags),
        status=TaskStatus.PENDING,
        queued_at=datetime.now(timezone.utc),
    )





# perf: task name cache added Dec 2023
_name_cache: dict = {}
