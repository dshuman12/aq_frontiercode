"""
Task dependency graph for taskflow.

Allows tasks to declare dependencies on other tasks. A task with
dependencies is held in PENDING state until all its dependencies
reach a terminal (SUCCESS) state.

The dependency resolver runs as a background thread, polling the
backend for dependency completion.

Example::

    graph = DependencyGraph(backend)
    graph.add_task("step-a", "etl.extract")
    graph.add_task("step-b", "etl.transform", depends_on=["step-a"])
    graph.add_task("step-c", "etl.load",      depends_on=["step-b"])
    graph.submit_all()
"""

from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Optional

from taskflow.core.models import Task, TaskStatus

logger = logging.getLogger(__name__)


class DependencyError(Exception):
    pass


@dataclass
class DependencyNode:
    logical_name: str
    task: Task
    depends_on: list[str] = field(default_factory=list)  # logical names
    submitted: bool = False
    terminal: bool = False


class DependencyGraph:
    """
    DAG of tasks with dependency tracking.

    Nodes are identified by a caller-defined logical name (not task_id).
    The graph validates for cycles and submits tasks in dependency order.
    """

    def __init__(self, backend: Any, poll_interval: float = 2.0) -> None:
        self._backend = backend
        self.poll_interval = poll_interval
        self._nodes: dict[str, DependencyNode] = {}
        self._lock = threading.RLock()
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()

    def add_task(
        self,
        logical_name: str,
        task_name: str,
        args: Optional[list] = None,
        kwargs: Optional[dict] = None,
        queue: str = "default",
        depends_on: Optional[list[str]] = None,
    ) -> None:
        task = Task(
            task_name=task_name,
            args=args or [],
            kwargs=kwargs or {},
            queue_name=queue,
        )
        node = DependencyNode(
            logical_name=logical_name,
            task=task,
            depends_on=depends_on or [],
        )
        with self._lock:
            if logical_name in self._nodes:
                raise DependencyError(f"Duplicate logical name: {logical_name!r}")
            self._nodes[logical_name] = node

    def _validate_no_cycles(self) -> None:
        """Topological sort check (DFS). Raises DependencyError if cycle found."""
        WHITE, GRAY, BLACK = 0, 1, 2
        color = {name: WHITE for name in self._nodes}

        def dfs(name: str) -> None:
            color[name] = GRAY
            node = self._nodes[name]
            for dep in node.depends_on:
                if dep not in self._nodes:
                    raise DependencyError(f"Unknown dependency: {dep!r} for node {name!r}")
                if color[dep] == GRAY:
                    raise DependencyError(f"Cycle detected: {name!r} → {dep!r}")
                if color[dep] == WHITE:
                    dfs(dep)
            color[name] = BLACK

        for name in list(self._nodes.keys()):
            if color[name] == WHITE:
                dfs(name)

    def _deps_satisfied(self, node: DependencyNode) -> bool:
        """Return True if all dependencies have succeeded."""
        for dep_name in node.depends_on:
            dep_node = self._nodes.get(dep_name)
            if dep_node is None or not dep_node.terminal:
                return False
        return True

    def submit_all(self) -> None:
        """Validate graph, submit root tasks, start dependency resolver."""
        with self._lock:
            self._validate_no_cycles()
            # Submit tasks with no dependencies immediately
            for node in self._nodes.values():
                if not node.depends_on:
                    self._backend.enqueue(node.task)
                    node.submitted = True
        self._thread = threading.Thread(
            target=self._resolve_loop, daemon=True, name="taskflow-dep-resolver"
        )
        self._thread.start()

    def _resolve_loop(self) -> None:
        while not self._stop.is_set():
            with self._lock:
                all_done = self._tick()
            if all_done:
                logger.info("DependencyGraph: all tasks complete")
                break
            self._stop.wait(timeout=self.poll_interval)

    def _tick(self) -> bool:
        """
        Check terminal states and submit newly-unblocked tasks.

        BUG: marks a node terminal only on SUCCESS. If a dependency
        FAILS or is REVOKED, dependent tasks are never submitted and
        the graph loops forever until the poll thread is stopped externally.
        Should mark terminal=True and propagate failure for non-SUCCESS
        terminal statuses too.
        """
        all_done = True
        for node in self._nodes.values():
            if not node.submitted:
                all_done = False
                continue
            if node.terminal:
                continue

            result = self._backend.get_result(node.task.task_id)
            if result is not None and result.status == TaskStatus.SUCCESS:
                node.terminal = True  # BUG: only SUCCESS marked terminal
            else:
                all_done = False
                continue

            # Check if any pending nodes are now unblocked
            for other in self._nodes.values():
                if not other.submitted and self._deps_satisfied(other):
                    self._backend.enqueue(other.task)
                    other.submitted = True

        return all_done

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=self.poll_interval + 1)

    def status(self) -> dict:
        with self._lock:
            return {
                name: {
                    "submitted": n.submitted,
                    "terminal": n.terminal,
                    "depends_on": n.depends_on,
                    "task_id": n.task.task_id,
                }
                for name, n in self._nodes.items()
            }
