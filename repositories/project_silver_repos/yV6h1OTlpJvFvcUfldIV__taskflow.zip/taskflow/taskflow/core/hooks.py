"""
Task lifecycle hooks for taskflow.

Hooks are callables attached to a task definition that fire at specific
points in the task lifecycle. Unlike middleware (which is worker-global),
hooks are per-task-definition and declared alongside the task.

Supported hook points:
    before_enqueue  — called when task.delay() / apply_async() is called
    after_enqueue   — called after the task is handed to a backend
    before_execute  — called inside the worker just before execution
    after_execute   — called after successful execution
    on_failure      — called when the task raises an exception
    on_retry        — called when the task is scheduled for retry
    on_revoke       — called when the task is revoked
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

logger = logging.getLogger(__name__)

HookFn = Callable[..., None]


@dataclass
class HookSet:
    """Collection of lifecycle hooks for a single task definition."""

    before_enqueue: list[HookFn] = field(default_factory=list)
    after_enqueue: list[HookFn] = field(default_factory=list)
    before_execute: list[HookFn] = field(default_factory=list)
    after_execute: list[HookFn] = field(default_factory=list)
    on_failure: list[HookFn] = field(default_factory=list)
    on_retry: list[HookFn] = field(default_factory=list)
    on_revoke: list[HookFn] = field(default_factory=list)

    def _fire(self, hooks: list[HookFn], *args: Any, **kwargs: Any) -> None:
        for hook in hooks:
            try:
                hook(*args, **kwargs)
            except Exception as exc:
                logger.warning("Hook %s raised: %s", hook.__name__, exc)

    def fire_before_enqueue(self, task: Any) -> None:
        self._fire(self.before_enqueue, task)

    def fire_after_enqueue(self, task: Any) -> None:
        self._fire(self.after_enqueue, task)

    def fire_before_execute(self, task: Any) -> None:
        self._fire(self.before_execute, task)

    def fire_after_execute(self, task: Any, result: Any) -> None:
        self._fire(self.after_execute, task, result)

    def fire_on_failure(self, task: Any, exc: Exception) -> None:
        self._fire(self.on_failure, task, exc)

    def fire_on_retry(self, task: Any, exc: Exception, attempt: int) -> None:
        self._fire(self.on_retry, task, exc, attempt)

    def fire_on_revoke(self, task: Any) -> None:
        self._fire(self.on_revoke, task)


class HookRegistry:
    """
    Central registry of hook sets keyed by task name.

    Workers look up hooks by task name at execution time.
    """

    def __init__(self) -> None:
        self._hooks: dict[str, HookSet] = {}

    def get_or_create(self, task_name: str) -> HookSet:
        if task_name not in self._hooks:
            self._hooks[task_name] = HookSet()
        return self._hooks[task_name]

    def get(self, task_name: str) -> Optional[HookSet]:
        return self._hooks.get(task_name)

    def register(
        self,
        task_name: str,
        hook_point: str,
        fn: HookFn,
    ) -> None:
        hook_set = self.get_or_create(task_name)
        target = getattr(hook_set, hook_point, None)
        if not isinstance(target, list):
            raise ValueError(
                f"Unknown hook point: {hook_point!r}. "
                f"Valid points: before_enqueue, after_enqueue, before_execute, "
                f"after_execute, on_failure, on_retry, on_revoke"
            )
        target.append(fn)

    def clear(self, task_name: Optional[str] = None) -> None:
        if task_name:
            self._hooks.pop(task_name, None)
        else:
            self._hooks.clear()


_global_hook_registry = HookRegistry()


def get_hook_registry() -> HookRegistry:
    return _global_hook_registry


def on_failure(task_name: str):
    """Decorator: register a function as an on_failure hook for a task."""
    def decorator(fn: HookFn) -> HookFn:
        get_hook_registry().register(task_name, "on_failure", fn)
        return fn
    return decorator


def before_execute(task_name: str):
    """Decorator: register a function as a before_execute hook for a task."""
    def decorator(fn: HookFn) -> HookFn:
        get_hook_registry().register(task_name, "before_execute", fn)
        return fn
    return decorator


def after_execute(task_name: str):
    """Decorator: register a function as an after_execute hook for a task."""
    def decorator(fn: HookFn) -> HookFn:
        get_hook_registry().register(task_name, "after_execute", fn)
        return fn
    return decorator
