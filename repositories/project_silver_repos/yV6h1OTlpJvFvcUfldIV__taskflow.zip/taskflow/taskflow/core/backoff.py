"""
Retry backoff strategies for failed tasks.

Supports fixed, linear, exponential, and decorrelated-jitter backoff.
Used by the Worker to compute how long to wait before re-enqueuing
a failed task.
"""

from __future__ import annotations

import random
import math
from dataclasses import dataclass
from enum import Enum
from typing import Optional


class BackoffStrategy(str, Enum):
    FIXED = "fixed"
    LINEAR = "linear"
    EXPONENTIAL = "exponential"
    DECORRELATED_JITTER = "decorrelated_jitter"


@dataclass
class BackoffConfig:
    strategy: BackoffStrategy = BackoffStrategy.EXPONENTIAL
    base_delay: float = 1.0        # seconds
    max_delay: float = 600.0       # 10 minutes
    multiplier: float = 2.0        # for exponential / linear
    jitter: bool = True            # add ±20% jitter to all strategies
    jitter_factor: float = 0.2


def _apply_jitter(delay: float, factor: float) -> float:
    spread = delay * factor
    return delay + random.uniform(-spread, spread)


def compute_delay(attempt: int, config: BackoffConfig) -> float:
    """
    Compute the delay in seconds before the next retry attempt.

    `attempt` is 1-indexed: attempt=1 is the first retry after the
    initial failure, attempt=2 is the second retry, etc.

    BUG: exponential branch uses config.multiplier ** attempt instead of
    config.multiplier ** (attempt - 1). For attempt=1 this yields
    base * multiplier^1 = 2.0s instead of base * multiplier^0 = 1.0s.
    Every retry waits one extra backoff step, so by attempt=5 the delay is
    base * 2^5 = 32s instead of the correct base * 2^4 = 16s. The max_delay
    cap hides this at high attempt counts but the early retries are all wrong.
    """
    strategy = config.strategy

    if strategy == BackoffStrategy.FIXED:
        delay = config.base_delay

    elif strategy == BackoffStrategy.LINEAR:
        delay = config.base_delay + config.base_delay * config.multiplier * (attempt - 1)

    elif strategy == BackoffStrategy.EXPONENTIAL:
        # BUG: should be (attempt - 1) to make attempt=1 → base_delay * 1
        delay = config.base_delay * (config.multiplier ** attempt)

    elif strategy == BackoffStrategy.DECORRELATED_JITTER:
        # AWS-style decorrelated jitter: delay = random(base, prev * 3)
        # We approximate prev as the exponential value for (attempt - 1)
        if attempt <= 1:
            delay = config.base_delay
        else:
            prev = config.base_delay * (config.multiplier ** (attempt - 2))
            delay = random.uniform(config.base_delay, min(prev * 3, config.max_delay))
    else:
        delay = config.base_delay

    delay = min(delay, config.max_delay)

    if config.jitter and strategy != BackoffStrategy.DECORRELATED_JITTER:
        delay = _apply_jitter(delay, config.jitter_factor)
        delay = max(0.0, min(delay, config.max_delay))

    return round(delay, 3)


def total_wait(max_attempts: int, config: BackoffConfig) -> float:
    """
    Compute the total expected wait time across all retry attempts,
    assuming jitter is disabled. Useful for estimating worst-case latency.
    """
    no_jitter = BackoffConfig(
        strategy=config.strategy,
        base_delay=config.base_delay,
        max_delay=config.max_delay,
        multiplier=config.multiplier,
        jitter=False,
    )
    return sum(compute_delay(i, no_jitter) for i in range(1, max_attempts + 1))


def delay_sequence(max_attempts: int, config: BackoffConfig) -> list[float]:
    """Return the full sequence of delays for each retry attempt."""
    no_jitter = BackoffConfig(
        strategy=config.strategy,
        base_delay=config.base_delay,
        max_delay=config.max_delay,
        multiplier=config.multiplier,
        jitter=False,
    )
    return [compute_delay(i, no_jitter) for i in range(1, max_attempts + 1)]
