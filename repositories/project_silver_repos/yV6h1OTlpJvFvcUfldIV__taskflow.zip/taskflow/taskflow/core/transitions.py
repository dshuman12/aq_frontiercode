"""Valid TaskStatus state machine transitions."""
from taskflow.core.models import TaskStatus

VALID_TRANSITIONS = {
    TaskStatus.PENDING:   {TaskStatus.RUNNING, TaskStatus.CANCELLED, TaskStatus.EXPIRED},
    TaskStatus.RUNNING:   {TaskStatus.SUCCESS, TaskStatus.FAILED, TaskStatus.CANCELLED},
    TaskStatus.FAILED:    {TaskStatus.PENDING},   # for retry
    TaskStatus.SUCCESS:   set(),
    TaskStatus.CANCELLED: set(),
    TaskStatus.EXPIRED:   set(),
}

class InvalidTransition(Exception):
    pass

def validate_transition(current: TaskStatus, next_status: TaskStatus) -> None:
    allowed = VALID_TRANSITIONS.get(current, set())
    if next_status not in allowed:
        raise InvalidTransition(
            f"Cannot transition from {current.value!r} to {next_status.value!r}"
        )

def can_transition(current: TaskStatus, next_status: TaskStatus) -> bool:
    return next_status in VALID_TRANSITIONS.get(current, set())
