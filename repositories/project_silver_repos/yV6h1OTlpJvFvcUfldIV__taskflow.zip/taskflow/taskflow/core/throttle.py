"""
Throttle registry for taskflow.

Tracks per-task and per-queue execution rates and enforces rate limits
declared on TaskDefinition.rate_limit (e.g. "100/minute", "5/second").

The throttle is consulted by workers before executing a dequeued task.
If the rate limit is exceeded the task is requeued with a short ETA.
"""

from __future__ import annotations

import re
import threading
import time
from dataclasses import dataclass, field
from typing import Optional


class ThrottleError(Exception):
    pass


_RATE_RE = re.compile(r"^(\d+)/(second|minute|hour|day)$")

_PERIOD_SECONDS = {
    "second": 1.0,
    "minute": 60.0,
    "hour": 3600.0,
    "day": 86400.0,
}


@dataclass
class RateLimit:
    count: int
    period_seconds: float

    @classmethod
    def parse(cls, spec: str) -> "RateLimit":
        """Parse '100/minute' → RateLimit(count=100, period_seconds=60.0)."""
        m = _RATE_RE.match(spec.strip().lower())
        if not m:
            raise ThrottleError(
                f"Invalid rate limit spec: {spec!r}. "
                "Expected format: '<N>/second|minute|hour|day'"
            )
        count = int(m.group(1))
        period = _PERIOD_SECONDS[m.group(2)]
        return cls(count=count, period_seconds=period)

    @property
    def rate_per_second(self) -> float:
        return self.count / self.period_seconds


class ThrottleBucket:
    """
    Sliding-window token bucket for a single rate-limit key.

    Uses a deque of timestamps to count calls within the window.
    """

    def __init__(self, limit: RateLimit) -> None:
        self.limit = limit
        self._timestamps: list[float] = []
        self._lock = threading.Lock()

    def try_acquire(self) -> bool:
        now = time.monotonic()
        window_start = now - self.limit.period_seconds
        with self._lock:
            # Evict timestamps outside the window
            self._timestamps = [t for t in self._timestamps if t > window_start]
            if len(self._timestamps) >= self.limit.count:
                return False
            self._timestamps.append(now)
            return True

    def retry_after(self) -> float:
        """Seconds until the oldest token expires and a slot opens."""
        with self._lock:
            if not self._timestamps:
                return 0.0
            oldest = self._timestamps[0]
            return max(0.0, oldest + self.limit.period_seconds - time.monotonic())

    def current_count(self) -> int:
        now = time.monotonic()
        window_start = now - self.limit.period_seconds
        with self._lock:
            return sum(1 for t in self._timestamps if t > window_start)


class ThrottleRegistry:
    """
    Central store of per-task throttle buckets.

    Keys are task names; limits are parsed from the rate_limit field on
    TaskDefinition or set explicitly via register().
    """

    def __init__(self) -> None:
        self._buckets: dict[str, ThrottleBucket] = {}
        self._lock = threading.RLock()

    def register(self, task_name: str, rate_spec: str) -> None:
        limit = RateLimit.parse(rate_spec)
        with self._lock:
            self._buckets[task_name] = ThrottleBucket(limit)

    def try_acquire(self, task_name: str) -> bool:
        """Return True if the task may execute now, False if throttled."""
        with self._lock:
            bucket = self._buckets.get(task_name)
        if bucket is None:
            return True  # No limit registered → always allowed
        return bucket.try_acquire()

    def retry_after(self, task_name: str) -> float:
        with self._lock:
            bucket = self._buckets.get(task_name)
        if bucket is None:
            return 0.0
        return bucket.retry_after()

    def stats(self) -> dict:
        with self._lock:
            return {
                name: {
                    "limit": f"{b.limit.count}/{b.limit.period_seconds}s",
                    "current": b.current_count(),
                    "capacity": b.limit.count,
                }
                for name, b in self._buckets.items()
            }


_global_throttle_registry = ThrottleRegistry()


def get_throttle_registry() -> ThrottleRegistry:
    return _global_throttle_registry
