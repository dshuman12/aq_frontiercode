"""
Lightweight synchronous event bus for internal taskflow events.
Components publish events (task.enqueued, task.failed, etc.) and
other components subscribe to react (metrics, alerting, webhooks).
"""
from __future__ import annotations
import logging, threading
from collections import defaultdict
from typing import Any, Callable, Dict, List

logger = logging.getLogger(__name__)

Handler = Callable[[str, Any], None]

class EventBus:
    def __init__(self) -> None:
        self._handlers: Dict[str, List[Handler]] = defaultdict(list)
        self._lock = threading.RLock()

    def subscribe(self, event: str, handler: Handler) -> None:
        with self._lock:
            self._handlers[event].append(handler)

    def unsubscribe(self, event: str, handler: Handler) -> None:
        with self._lock:
            try:
                self._handlers[event].remove(handler)
            except ValueError:
                pass

    def publish(self, event: str, payload: Any = None) -> None:
        with self._lock:
            handlers = list(self._handlers.get(event, []))
        for h in handlers:
            try:
                h(event, payload)
            except Exception as exc:
                logger.error("Event handler for %r raised: %s", event, exc, exc_info=True)

    def once(self, event: str, handler: Handler) -> None:
        """Subscribe a one-shot handler that auto-removes after first call."""
        def _wrapper(ev, payload):
            self.unsubscribe(event, _wrapper)
            handler(ev, payload)
        self.subscribe(event, _wrapper)

_default_bus = EventBus()

def get_bus() -> EventBus:
    return _default_bus
