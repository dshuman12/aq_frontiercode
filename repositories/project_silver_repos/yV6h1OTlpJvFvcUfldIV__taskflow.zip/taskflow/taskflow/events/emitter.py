"""
Event system for taskflow.

Provides an event emitter for task lifecycle events,
supporting async handlers, filtering, and event history.

Features:
- Typed event classes
- Async and sync event handlers
- Event filtering by task, queue, or status
- Event history with configurable retention
- Dead letter queue events
- Worker lifecycle events
"""

from __future__ import annotations

import asyncio
import json
import logging
import threading
import time
import uuid
from abc import ABC, abstractmethod
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set, Type, Union

from taskflow.core.models import Priority, Task, TaskResult, TaskStatus

logger = logging.getLogger(__name__)


class EventType(Enum):
    """All event types in taskflow."""
    # Task lifecycle events
    TASK_ENQUEUED = "task.enqueued"
    TASK_DEQUEUED = "task.dequeued"
    TASK_STARTED = "task.started"
    TASK_SUCCEEDED = "task.succeeded"
    TASK_FAILED = "task.failed"
    TASK_RETRY = "task.retry"
    TASK_REVOKED = "task.revoked"
    TASK_EXPIRED = "task.expired"
    TASK_TIMEOUT = "task.timeout"

    # Queue events
    QUEUE_CREATED = "queue.created"
    QUEUE_PAUSED = "queue.paused"
    QUEUE_RESUMED = "queue.resumed"
    QUEUE_CLOSED = "queue.closed"
    QUEUE_DRAINED = "queue.drained"
    QUEUE_PURGED = "queue.purged"

    # Worker events
    WORKER_REGISTERED = "worker.registered"
    WORKER_UNREGISTERED = "worker.unregistered"
    WORKER_HEARTBEAT = "worker.heartbeat"
    WORKER_STARTED = "worker.started"
    WORKER_STOPPED = "worker.stopped"

    # Dead letter events
    DEAD_LETTER_CREATED = "dead_letter.created"
    DEAD_LETTER_RESTORED = "dead_letter.restored"
    DEAD_LETTER_PURGED = "dead_letter.purged"

    # Batch events
    BATCH_STARTED = "batch.started"
    BATCH_COMPLETED = "batch.completed"
    BATCH_FAILED = "batch.failed"

    # System events
    SYSTEM_ERROR = "system.error"
    SYSTEM_SHUTDOWN = "system.shutdown"


@dataclass
class Event:
    """
    Base event class.

    All events contain common metadata plus event-specific data.
    """
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    event_type: EventType = EventType.SYSTEM_ERROR
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    task_id: Optional[str] = None
    task_name: Optional[str] = None
    queue_name: Optional[str] = None
    worker_id: Optional[str] = None
    data: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def is_task_event(self) -> bool:
        return self.event_type.value.startswith("task.")

    @property
    def is_queue_event(self) -> bool:
        return self.event_type.value.startswith("queue.")

    @property
    def is_worker_event(self) -> bool:
        return self.event_type.value.startswith("worker.")

    def to_dict(self) -> dict:
        return {
            "event_id": self.event_id,
            "event_type": self.event_type.value,
            "timestamp": self.timestamp.isoformat(),
            "task_id": self.task_id,
            "task_name": self.task_name,
            "queue_name": self.queue_name,
            "worker_id": self.worker_id,
            "data": self.data,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Event":
        return cls(
            event_id=data["event_id"],
            event_type=EventType(data["event_type"]),
            timestamp=datetime.fromisoformat(data["timestamp"]),
            task_id=data.get("task_id"),
            task_name=data.get("task_name"),
            queue_name=data.get("queue_name"),
            worker_id=data.get("worker_id"),
            data=data.get("data", {}),
            metadata=data.get("metadata", {}),
        )


@dataclass
class TaskEvent(Event):
    """Event with task information."""
    task: Optional[Task] = None
    result: Optional[TaskResult] = None
    error: Optional[str] = None
    traceback: Optional[str] = None

    def to_dict(self) -> dict:
        base = super().to_dict()
        if self.task:
            base["task"] = self.task.to_dict()
        if self.result:
            base["result"] = self.result.to_dict()
        base["error"] = self.error
        base["traceback"] = self.traceback
        return base


@dataclass
class QueueEvent(Event):
    """Event with queue information."""
    queue_info: Optional[Dict[str, Any]] = None


@dataclass
class WorkerEvent(Event):
    """Event with worker information."""
    worker_info: Optional[Dict[str, Any]] = None


@dataclass
class BatchEvent(Event):
    """Event with batch information."""
    batch_id: Optional[str] = None
    batch_size: int = 0
    results: Optional[Dict[str, Any]] = None


# ---------------------------------------------------------------------------
# Event Filter
# ---------------------------------------------------------------------------

@dataclass
class EventFilter:
    """
    Filter for subscribing to specific events.

    All fields are optional. Events must match all specified fields.
    """
    event_types: Optional[Set[EventType]] = None
    task_names: Optional[Set[str]] = None
    task_ids: Optional[Set[str]] = None
    queue_names: Optional[Set[str]] = None
    worker_ids: Optional[Set[str]] = None
    status_codes: Optional[Set[str]] = None
    time_range: Optional[tuple] = None  # (start, end) datetime
    metadata_filter: Optional[Callable[[Dict], bool]] = None

    def matches(self, event: Event) -> bool:
        """Check if an event matches this filter."""
        # Event type
        if self.event_types and event.event_type not in self.event_types:
            return False

        # Task name
        if self.task_names and event.task_name not in self.task_names:
            return False

        # Task ID
        if self.task_ids and event.task_id not in self.task_ids:
            return False

        # Queue name
        if self.queue_names and event.queue_name not in self.queue_names:
            return False

        # Worker ID
        if self.worker_ids and event.worker_id not in self.worker_ids:
            return False

        # Time range
        if self.time_range:
            start, end = self.time_range
            if not (start <= event.timestamp <= end):
                return False

        # Custom metadata filter
        if self.metadata_filter and not self.metadata_filter(event.metadata):
            return False

        return True


# ---------------------------------------------------------------------------
# Event Handler
# ---------------------------------------------------------------------------

@dataclass
class EventHandler:
    """A handler that processes events."""
    callback: Callable[[Event], None]
    filter: EventFilter = field(default_factory=EventFilter)
    async_handler: bool = False
    name: Optional[str] = None
    enabled: bool = True

    def handle(self, event: Event) -> None:
        """Handle an event if it matches the filter."""
        if not self.enabled:
            return
        if not self.filter.matches(event):
            return

        try:
            if self.async_handler:
                # For async handlers, we just call directly
                # The caller should handle async properly
                result = self.callback(event)
                if asyncio.iscoroutine(result):
                    # Schedule the coroutine if we have an event loop
                    try:
                        loop = asyncio.get_event_loop()
                        loop.create_task(result)
                    except RuntimeError:
                        logger.warning(
                            "No event loop available for async event handler %s",
                            self.name
                        )
            else:
                self.callback(event)
        except Exception as exc:
            logger.exception("Event handler %s failed: %s", self.name, exc)


# ---------------------------------------------------------------------------
# Event Emitter
# ---------------------------------------------------------------------------

class EventEmitter:
    """
    Central event emitter for taskflow.

    Manages event subscriptions and dispatches events to handlers.

    Example:
        emitter = EventEmitter()

        # Subscribe to all task events
        emitter.on(EventType.TASK_SUCCEEDED, handle_success)

        # Subscribe with filter
        emitter.on(
            EventType.TASK_FAILED,
            handle_failure,
            filter=EventFilter(task_names={"my_task"})
        )

        # Emit an event
        emitter.emit(TaskEvent(
            event_type=EventType.TASK_SUCCEEDED,
            task_id="123",
            task_name="my_task",
        ))
    """

    def __init__(
        self,
        history_size: int = 1000,
        enable_logging: bool = True,
        log_level: int = logging.INFO,
    ) -> None:
        self._handlers: List[EventHandler] = []
        self._handler_lock = threading.RLock()
        self._history: deque = deque(maxlen=history_size)
        self._history_lock = threading.RLock()
        self._history_size = history_size
        self._enable_logging = enable_logging
        self._log_level = log_level
        self._subscribers: Dict[str, Any] = {}  # For pub/sub integration

    def on(
        self,
        event_type: Union[EventType, Set[EventType]],
        callback: Callable[[Event], None],
        filter: Optional[EventFilter] = None,
        name: Optional[str] = None,
        async_handler: bool = False,
    ) -> str:
        """
        Subscribe to events.

        Args:
            event_type: Event type(s) to subscribe to
            callback: Function to call when event occurs
            filter: Optional filter for more specific matching
            name: Optional handler name for debugging
            async_handler: Whether the callback is async

        Returns:
            Handler ID for later unsubscription
        """
        if isinstance(event_type, EventType):
            event_types = {event_type}
        else:
            event_types = event_type

        event_filter = filter or EventFilter()
        event_filter.event_types = event_types

        handler = EventHandler(
            callback=callback,
            filter=event_filter,
            async_handler=async_handler,
            name=name or f"handler_{len(self._handlers)}",
        )

        with self._handler_lock:
            self._handlers.append(handler)

        return handler.name

    def once(
        self,
        event_type: EventType,
        callback: Callable[[Event], None],
        filter: Optional[EventFilter] = None,
    ) -> str:
        """
        Subscribe to an event for a single execution.

        Handler is automatically removed after first matching event.
        """
        handler_id = [None]  # Use list to allow mutation in closure

        def wrapper(event: Event) -> None:
            try:
                callback(event)
            finally:
                self.off(handler_id[0])

        handler_id[0] = self.on(event_type, wrapper, filter)
        return handler_id[0]

    def off(self, handler_id: str) -> bool:
        """
        Unsubscribe a handler by ID.

        Returns True if handler was found and removed.
        """
        with self._handler_lock:
            for i, handler in enumerate(self._handlers):
                if handler.name == handler_id:
                    self._handlers.pop(i)
                    return True
        return False

    def emit(self, event: Event) -> None:
        """
        Emit an event to all matching handlers.

        This method is thread-safe.
        """
        # Log the event
        if self._enable_logging:
            self._log_event(event)

        # Store in history
        with self._history_lock:
            self._history.append(event)

        # Dispatch to handlers
        with self._handler_lock:
            handlers = list(self._handlers)

        for handler in handlers:
            try:
                handler.handle(event)
            except Exception as exc:
                logger.exception("Handler %s failed for event %s: %s",
                                 handler.name, event.event_type.value, exc)

    def _log_event(self, event: Event) -> None:
        """Log an event."""
        if event.task_id:
            logger.log(
                self._log_level,
                "Event: %s | task=%s | queue=%s | worker=%s",
                event.event_type.value,
                event.task_id[:8] if event.task_id else "-",
                event.queue_name or "-",
                event.worker_id or "-",
            )
        else:
            logger.log(
                self._log_level,
                "Event: %s | %s",
                event.event_type.value,
                event.data,
            )

    def get_history(
        self,
        event_type: Optional[EventType] = None,
        task_id: Optional[str] = None,
        limit: int = 100,
    ) -> List[Event]:
        """Get recent events from history."""
        with self._history_lock:
            events = list(self._history)

        # Apply filters
        if event_type:
            events = [e for e in events if e.event_type == event_type]
        if task_id:
            events = [e for e in events if e.task_id == task_id]

        return events[-limit:]

    def clear_history(self) -> None:
        """Clear event history."""
        with self._history_lock:
            self._history.clear()

    def get_handler_count(self) -> int:
        """Get the number of registered handlers."""
        with self._handler_lock:
            return len(self._handlers)

    def get_stats(self) -> Dict[str, Any]:
        """Get event statistics."""
        with self._history_lock:
            total = len(self._history)

        with self._handler_lock:
            handler_count = len(self._handlers)

        # Count by event type
        type_counts: Dict[str, int] = {}
        with self._history_lock:
            for event in self._history:
                type_name = event.event_type.value
                type_counts[type_name] = type_counts.get(type_name, 0) + 1

        return {
            "total_events": total,
            "handler_count": handler_count,
            "history_size": self._history_size,
            "events_by_type": type_counts,
        }


# ---------------------------------------------------------------------------
# Global Event Emitter
# ---------------------------------------------------------------------------

_global_emitter: Optional[EventEmitter] = None
_emitter_lock = threading.Lock()


def get_emitter() -> EventEmitter:
    """Get the global event emitter instance."""
    global _global_emitter
    if _global_emitter is None:
        with _emitter_lock:
            if _global_emitter is None:
                _global_emitter = EventEmitter()
    return _global_emitter


def reset_emitter() -> None:
    """Reset the global emitter. For testing."""
    global _global_emitter
    with _emitter_lock:
        _global_emitter = EventEmitter()


# ---------------------------------------------------------------------------
# Event Helper Functions
# ---------------------------------------------------------------------------

def emit_task_enqueued(task: Task) -> None:
    """Emit a task.enqueued event."""
    emitter = get_emitter()
    emitter.emit(TaskEvent(
        event_type=EventType.TASK_ENQUEUED,
        task_id=task.task_id,
        task_name=task.task_name,
        queue_name=task.queue_name,
        task=task,
        data={"priority": task.priority.value},
    ))


def emit_task_dequeued(task: Task, worker_id: str) -> None:
    """Emit a task.dequeued event."""
    emitter = get_emitter()
    emitter.emit(TaskEvent(
        event_type=EventType.TASK_DEQUEUED,
        task_id=task.task_id,
        task_name=task.task_name,
        queue_name=task.queue_name,
        worker_id=worker_id,
        task=task,
    ))


def emit_task_started(task: Task, worker_id: str) -> None:
    """Emit a task.started event."""
    emitter = get_emitter()
    emitter.emit(TaskEvent(
        event_type=EventType.TASK_STARTED,
        task_id=task.task_id,
        task_name=task.task_name,
        queue_name=task.queue_name,
        worker_id=worker_id,
        task=task,
    ))


def emit_task_succeeded(task: Task, result: TaskResult, worker_id: str) -> None:
    """Emit a task.succeeded event."""
    emitter = get_emitter()
    emitter.emit(TaskEvent(
        event_type=EventType.TASK_SUCCEEDED,
        task_id=task.task_id,
        task_name=task.task_name,
        queue_name=task.queue_name,
        worker_id=worker_id,
        task=task,
        result=result,
        data={"duration": result.run_time_seconds},
    ))


def emit_task_failed(
    task: Task,
    result: TaskResult,
    worker_id: str,
    error: str,
    traceback: Optional[str] = None,
) -> None:
    """Emit a task.failed event."""
    emitter = get_emitter()
    emitter.emit(TaskEvent(
        event_type=EventType.TASK_FAILED,
        task_id=task.task_id,
        task_name=task.task_name,
        queue_name=task.queue_name,
        worker_id=worker_id,
        task=task,
        result=result,
        error=error,
        traceback=traceback,
        data={"attempt": task.attempt},
    ))


def emit_task_retry(task: Task, delay: float) -> None:
    """Emit a task.retry event."""
    emitter = get_emitter()
    emitter.emit(TaskEvent(
        event_type=EventType.TASK_RETRY,
        task_id=task.task_id,
        task_name=task.task_name,
        queue_name=task.queue_name,
        task=task,
        data={
            "attempt": task.attempt,
            "delay_seconds": delay,
            "next_retry": task.next_retry_eta().isoformat(),
        },
    ))


def emit_queue_created(queue_name: str) -> None:
    """Emit a queue.created event."""
    emitter = get_emitter()
    emitter.emit(QueueEvent(
        event_type=EventType.QUEUE_CREATED,
        queue_name=queue_name,
    ))


def emit_worker_registered(worker_id: str, queues: List[str], concurrency: int) -> None:
    """Emit a worker.registered event."""
    emitter = get_emitter()
    emitter.emit(WorkerEvent(
        event_type=EventType.WORKER_REGISTERED,
        worker_id=worker_id,
        worker_info={
            "queues": queues,
            "concurrency": concurrency,
        },
    ))


def emit_batch_completed(batch_id: str, result: Dict[str, Any]) -> None:
    """Emit a batch.completed event."""
    emitter = get_emitter()
    emitter.emit(BatchEvent(
        event_type=EventType.BATCH_COMPLETED,
        batch_id=batch_id,
        batch_size=result.get("total", 0),
        results=result,
    ))


# ---------------------------------------------------------------------------
# Event-Driven Utilities
# ---------------------------------------------------------------------------

class EventCounter:
    """
    Count events by type.

    Useful for monitoring and analytics.
    """

    def __init__(self, emitter: Optional[EventEmitter] = None) -> None:
        self._counts: Dict[str, int] = {}
        self._lock = threading.Lock()
        self._emitter = emitter or get_emitter()
        self._handler_id = self._emitter.on(
            set(EventType),
            self._increment,
        )

    def _increment(self, event: Event) -> None:
        with self._lock:
            self._counts[event.event_type.value] = \
                self._counts.get(event.event_type.value, 0) + 1

    def get_count(self, event_type: EventType) -> int:
        with self._lock:
            return self._counts.get(event_type.value, 0)

    def get_all_counts(self) -> Dict[str, int]:
        with self._lock:
            return dict(self._counts)

    def reset(self) -> None:
        with self._lock:
            self._counts.clear()

    def stop(self) -> None:
        self._emitter.off(self._handler_id)


class EventLogger:
    """
    Log events to a file or external service.

    Useful for audit trails and debugging.
    """

    def __init__(
        self,
        filename: Optional[str] = None,
        emitter: Optional[EventEmitter] = None,
        format: str = "json",
    ) -> None:
        self._filename = filename
        self._format = format
        self._emitter = emitter or get_emitter()
        self._file = None
        self._lock = threading.Lock()
        self._handler_id = self._emitter.on(
            set(EventType),
            self._log_event,
        )

        if filename:
            self._file = open(filename, "a")

    def _log_event(self, event: Event) -> None:
        if self._format == "json":
            line = json.dumps(event.to_dict()) + "\n"
        else:
            line = f"{event.timestamp.isoformat()} {event.event_type.value} {event.task_id or '-'}\n"

        with self._lock:
            if self._file:
                self._file.write(line)
                self._file.flush()

    def close(self) -> None:
        self._emitter.off(self._handler_id)
        if self._file:
            self._file.close()
            self._file = None


# ---------------------------------------------------------------------------
# Async Event Support
# ---------------------------------------------------------------------------

class AsyncEventHandler:
    """
    Async event handler that batches events for efficient processing.

    Useful when you want to process events in batches rather than individually.
    """

    def __init__(
        self,
        emitter: EventEmitter,
        event_types: Set[EventType],
        batch_size: int = 100,
        flush_interval: float = 5.0,
        callback: Callable[[List[Event]], Any] = None,
    ) -> None:
        self._emitter = emitter
        self._event_types = event_types
        self._batch_size = batch_size
        self._flush_interval = flush_interval
        self._callback = callback
        self._buffer: List[Event] = []
        self._lock = threading.Lock()
        self._running = False
        self._flush_thread: Optional[threading.Thread] = None
        self._handler_id = self._emitter.on(event_types, self._on_event)

    def _on_event(self, event: Event) -> None:
        with self._lock:
            self._buffer.append(event)
            if len(self._buffer) >= self._batch_size:
                self._flush()

    def _flush(self) -> None:
        if not self._buffer:
            return

        events = self._buffer[:]
        self._buffer.clear()

        if self._callback:
            try:
                result = self._callback(events)
                if asyncio.iscoroutine(result):
                    try:
                        loop = asyncio.get_event_loop()
                        loop.create_task(result)
                    except RuntimeError:
                        pass
            except Exception as exc:
                logger.exception("AsyncEventHandler callback failed: %s", exc)

    def start(self) -> None:
        """Start periodic flushing."""
        self._running = True
        self._flush_thread = threading.Thread(
            target=self._flush_loop,
            daemon=True,
        )
        self._flush_thread.start()

    def stop(self) -> None:
        """Stop and flush remaining events."""
        self._running = False
        if self._flush_thread:
            self._flush_thread.join(timeout=self._flush_interval)
        with self._lock:
            self._flush()
        self._emitter.off(self._handler_id)

    def _flush_loop(self) -> None:
        while self._running:
            time.sleep(self._flush_interval)
            with self._lock:
                self._flush()
