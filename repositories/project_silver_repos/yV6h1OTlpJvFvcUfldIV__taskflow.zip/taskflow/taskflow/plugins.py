"""
Plugin discovery for custom backends, serializers, and middleware.

Third-party packages register themselves under the
'taskflow.backends' (or .serializers, .middleware) entry point group.
This loader finds and instantiates them by alias.
"""
from __future__ import annotations
import importlib, logging
from typing import Any, Dict, Optional, Type

logger = logging.getLogger(__name__)

_BUILTIN_BACKENDS = {
    "memory":  "taskflow.backends.memory:MemoryBackend",
    "sqlite":  "taskflow.backends.sqlite:SQLiteBackend",
}

def _resolve(dotted_path: str) -> type:
    module_path, cls_name = dotted_path.rsplit(":", 1)
    module = importlib.import_module(module_path)
    return getattr(module, cls_name)

def load_backend(alias: str, **kwargs: Any) -> Any:
    """Instantiate a backend by alias. Falls back to builtin registry."""
    dotted = _BUILTIN_BACKENDS.get(alias)
    if dotted is None:
        try:
            # Try direct import path e.g. "mypackage.backends:MyBackend"
            cls = _resolve(alias)
        except (ImportError, AttributeError, ValueError) as exc:
            raise ImportError(f"Cannot load backend {alias!r}: {exc}") from exc
    else:
        cls = _resolve(dotted)
    return cls(**kwargs)

def register_backend(alias: str, dotted_path: str) -> None:
    _BUILTIN_BACKENDS[alias] = dotted_path
