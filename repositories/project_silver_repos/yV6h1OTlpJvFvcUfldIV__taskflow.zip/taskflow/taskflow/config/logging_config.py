"""Default logging setup for taskflow workers and CLI."""
import logging, sys

def configure_logging(level: str = "INFO", fmt: str | None = None) -> None:
    fmt = fmt or "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format=fmt,
        stream=sys.stderr,
    )
    # Silence noisy third-party loggers
    for noisy in ("urllib3", "charset_normalizer"):
        logging.getLogger(noisy).setLevel(logging.WARNING)

def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(f"taskflow.{name}")
