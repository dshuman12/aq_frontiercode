"""
Configuration management for taskflow.

Provides flexible configuration with environment variables,
YAML/JSON files, and Python dictionaries.

Features:
- Hierarchical configuration
- Environment variable binding
- YAML/JSON config files
- Secret management
- Configuration validation
- Hot reloading
- Configuration inheritance
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field, fields, is_dataclass
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set, Type, TypeVar, Union

import yaml

logger = logging.getLogger(__name__)

T = TypeVar("T")


# ---------------------------------------------------------------------------
# Configuration Sources
# ---------------------------------------------------------------------------

class ConfigSource(ABC):
    """Abstract base class for configuration sources."""

    @abstractmethod
    def get(self, key: str, default: Any = None) -> Any:
        """Get a configuration value."""
        pass

    @abstractmethod
    def set(self, key: str, value: Any) -> None:
        """Set a configuration value."""
        pass

    @abstractmethod
    def keys(self) -> List[str]:
        """Get all configuration keys."""
        pass

    @abstractmethod
    def load(self) -> None:
        """Load configuration from source."""
        pass

    @abstractmethod
    def save(self) -> None:
        """Save configuration to source."""
        pass


class DictSource(ConfigSource):
    """Configuration from a Python dictionary."""

    def __init__(self, data: Optional[Dict[str, Any]] = None) -> None:
        self._data = data or {}
        self._lock = threading.RLock()

    def get(self, key: str, default: Any = None) -> Any:
        keys = key.split(".")
        value = self._data
        for k in keys:
            if isinstance(value, dict):
                value = value.get(k)
            else:
                return default
            if value is None:
                return default
        return value

    def set(self, key: str, value: Any) -> None:
        with self._lock:
            keys = key.split(".")
            target = self._data
            for k in keys[:-1]:
                if k not in target:
                    target[k] = {}
                target = target[k]
            target[keys[-1]] = value

    def keys(self) -> List[str]:
        return self._flatten_keys(self._data)

    def _flatten_keys(self, data: Dict, prefix: str = "") -> List[str]:
        keys = []
        for key, value in data.items():
            full_key = f"{prefix}.{key}" if prefix else key
            if isinstance(value, dict):
                keys.extend(self._flatten_keys(value, full_key))
            else:
                keys.append(full_key)
        return keys

    def load(self) -> None:
        pass  # DictSource is already loaded

    def save(self) -> None:
        pass  # DictSource is in-memory


class EnvSource(ConfigSource):
    """Configuration from environment variables."""

    def __init__(
        self,
        prefix: str = "TASKFLOW",
        separator: str = "_",
        lowercase_keys: bool = True,
    ) -> None:
        self.prefix = prefix.upper()
        self.separator = separator
        self.lowercase_keys = lowercase_keys

    def get(self, key: str, default: Any = None) -> Any:
        env_key = self._to_env_key(key)
        value = os.environ.get(env_key)
        if value is None:
            return default

        # Try to parse as JSON for complex types
        try:
            return json.loads(value)
        except (json.JSONDecodeError, TypeError):
            pass

        # Try type conversion
        if value.lower() == "true":
            return True
        elif value.lower() == "false":
            return False
        elif value.lower() == "none":
            return None

        # Try numeric conversion
        try:
            if "." in value:
                return float(value)
            return int(value)
        except ValueError:
            pass

        return value

    def set(self, key: str, value: Any) -> None:
        env_key = self._to_env_key(key)
        if value is None:
            os.environ.pop(env_key, None)
        else:
            os.environ[env_key] = str(value)

    def keys(self) -> List[str]:
        keys = []
        prefix = f"{self.prefix}{self.separator}"
        for env_key, env_value in os.environ.items():
            if env_key.startswith(prefix):
                config_key = self._from_env_key(env_key[len(prefix):])
                keys.append(config_key)
        return keys

    def _to_env_key(self, key: str) -> str:
        key = key.upper().replace(".", self.separator)
        if self.prefix:
            return f"{self.prefix}{self.separator}{key}"
        return key

    def _from_env_key(self, key: str) -> str:
        if self.lowercase_keys:
            key = key.lower()
        return key.replace(self.separator, ".")

    def load(self) -> None:
        pass  # Environment is always loaded

    def save(self) -> None:
        pass  # Can't save to environment


class YAMLSource(ConfigSource):
    """Configuration from YAML file."""

    def __init__(
        self,
        path: Union[str, Path],
        watch: bool = False,
        reload_interval: float = 5.0,
    ) -> None:
        self.path = Path(path)
        self._watch = watch
        self._reload_interval = reload_interval
        self._data: Dict[str, Any] = {}
        self._mtime: float = 0
        self._lock = threading.RLock()
        self._watcher_thread: Optional[threading.Thread] = None
        self._callbacks: List[Callable[[], None]] = []

        if self.path.exists():
            self.load()

    def get(self, key: str, default: Any = None) -> Any:
        with self._lock:
            value = self._get_nested(self._data, key)
            return value if value is not None else default

    def _get_nested(self, data: Dict, key: str) -> Any:
        keys = key.split(".")
        value = data
        for k in keys:
            if isinstance(value, dict):
                value = value.get(k)
            else:
                return None
        return value

    def set(self, key: str, value: Any) -> None:
        with self._lock:
            keys = key.split(".")
            target = self._data
            for k in keys[:-1]:
                if k not in target:
                    target[k] = {}
                target = target[k]
            target[keys[-1]] = value

    def keys(self) -> List[str]:
        with self._lock:
            return self._flatten_keys(self._data)

    def _flatten_keys(self, data: Dict, prefix: str = "") -> List[str]:
        keys = []
        for key, value in data.items():
            full_key = f"{prefix}.{key}" if prefix else key
            if isinstance(value, dict):
                keys.extend(self._flatten_keys(value, full_key))
            else:
                keys.append(full_key)
        return keys

    def load(self) -> None:
        if not self.path.exists():
            logger.warning("Config file not found: %s", self.path)
            return

        mtime = self.path.stat().st_mtime
        if mtime == self._mtime:
            return

        try:
            with open(self.path) as f:
                new_data = yaml.safe_load(f) or {}

            with self._lock:
                self._data = new_data
                self._mtime = mtime

            logger.info("Loaded configuration from %s", self.path)
        except Exception as exc:
            logger.error("Failed to load config from %s: %s", self.path, exc)

    def save(self) -> None:
        with self._lock:
            with open(self.path, "w") as f:
                yaml.safe_dump(self._data, f, default_flow_style=False)

    def watch(self, callback: Callable[[], None]) -> None:
        """Watch for file changes and call callback."""
        self._callbacks.append(callback)
        if self._watcher_thread is None:
            self._watcher_thread = threading.Thread(
                target=self._watch_loop,
                daemon=True,
            )
            self._watcher_thread.start()

    def _watch_loop(self) -> None:
        while True:
            old_mtime = self._mtime
            time.sleep(self._reload_interval)
            self.load()
            if self._mtime != old_mtime:
                for callback in self._callbacks:
                    try:
                        callback()
                    except Exception as exc:
                        logger.warning("Config reload callback failed: %s", exc)


class JSONSource(ConfigSource):
    """Configuration from JSON file."""

    def __init__(
        self,
        path: Union[str, Path],
        watch: bool = False,
        reload_interval: float = 5.0,
    ) -> None:
        self.path = Path(path)
        self._watch = watch
        self._reload_interval = reload_interval
        self._data: Dict[str, Any] = {}
        self._mtime: float = 0
        self._lock = threading.RLock()
        self._watcher_thread: Optional[threading.Thread] = None
        self._callbacks: List[Callable[[], None]] = []

        if self.path.exists():
            self.load()

    def get(self, key: str, default: Any = None) -> Any:
        with self._lock:
            value = self._get_nested(self._data, key)
            return value if value is not None else default

    def _get_nested(self, data: Dict, key: str) -> Any:
        keys = key.split(".")
        value = data
        for k in keys:
            if isinstance(value, dict):
                value = value.get(k)
            else:
                return None
        return value

    def set(self, key: str, value: Any) -> None:
        with self._lock:
            keys = key.split(".")
            target = self._data
            for k in keys[:-1]:
                if k not in target:
                    target[k] = {}
                target = target[k]
            target[keys[-1]] = value

    def keys(self) -> List[str]:
        with self._lock:
            return self._flatten_keys(self._data)

    def _flatten_keys(self, data: Dict, prefix: str = "") -> List[str]:
        keys = []
        for key, value in data.items():
            full_key = f"{prefix}.{key}" if prefix else key
            if isinstance(value, dict):
                keys.extend(self._flatten_keys(value, full_key))
            else:
                keys.append(full_key)
        return keys

    def load(self) -> None:
        if not self.path.exists():
            logger.warning("Config file not found: %s", self.path)
            return

        mtime = self.path.stat().st_mtime
        if mtime == self._mtime:
            return

        try:
            with open(self.path) as f:
                new_data = json.load(f)

            with self._lock:
                self._data = new_data
                self._mtime = mtime

            logger.info("Loaded configuration from %s", self.path)
        except Exception as exc:
            logger.error("Failed to load config from %s: %s", self.path, exc)

    def save(self) -> None:
        with self._lock:
            with open(self.path, "w") as f:
                json.dump(self._data, f, indent=2)

    def watch(self, callback: Callable[[], None]) -> None:
        """Watch for file changes and call callback."""
        self._callbacks.append(callback)
        if self._watcher_thread is None:
            self._watcher_thread = threading.Thread(
                target=self._watch_loop,
                daemon=True,
            )
            self._watcher_thread.start()

    def _watch_loop(self) -> None:
        while True:
            old_mtime = self._mtime
            time.sleep(self._reload_interval)
            self.load()
            if self._mtime != old_mtime:
                for callback in self._callbacks:
                    try:
                        callback()
                    except Exception as exc:
                        logger.warning("Config reload callback failed: %s", exc)


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

class Config:
    """
    Main configuration class.

    Combines multiple configuration sources with priority ordering.
    Configuration is hierarchical with the following precedence:
    1. Direct set() calls
    2. Environment variables
    3. YAML/JSON file
    4. Default values

    Example:
        config = Config()
        config.add_source(EnvSource("TASKFLOW"))
        config.add_source(YAMLSource("config.yaml"))

        # Get values
        debug = config.get("debug", False)
        host = config.get("server.host", "localhost")

        # Bind to dataclass
        settings = config.bind(ServerSettings)
    """

    def __init__(
        self,
        sources: Optional[List[ConfigSource]] = None,
        strict: bool = False,
    ) -> None:
        self._sources: List[ConfigSource] = sources or []
        self._overrides: Dict[str, Any] = {}
        self._lock = threading.RLock()
        self._strict = strict
        self._validators: Dict[str, Callable[[Any], bool]] = {}
        self._listeners: Dict[str, List[Callable[[Any], None]]] = {}

    def add_source(self, source: ConfigSource) -> "Config":
        """Add a configuration source. Later sources have higher priority."""
        self._sources.append(source)
        return self

    def get(self, key: str, default: Any = None, type_hint: Optional[Type] = None) -> Any:
        """
        Get a configuration value.

        Args:
            key: Configuration key (dot-separated for nested)
            default: Default value if not found
            type_hint: Optional type hint for conversion

        Returns:
            The configuration value or default
        """
        # Check overrides first
        if key in self._overrides:
            return self._validate(key, self._overrides[key], type_hint)

        # Check sources in reverse order (last added = highest priority)
        for source in reversed(self._sources):
            value = source.get(key)
            if value is not None:
                return self._validate(key, value, type_hint)

        # Check environment as fallback
        env_value = os.environ.get(f"TASKFLOW_{key.upper().replace('.', '_')}")
        if env_value is not None:
            return self._validate(key, self._convert(env_value), type_hint)

        return self._validate(key, default, type_hint)

    def set(self, key: str, value: Any) -> None:
        """Set a configuration value (highest priority)."""
        with self._lock:
            self._overrides[key] = value
            self._notify(key, value)

    def get_section(self, section: str) -> Dict[str, Any]:
        """Get all configuration values for a section."""
        result = {}
        all_keys = set()

        for source in self._sources:
            all_keys.update(source.keys())

        for key in all_keys:
            if key.startswith(f"{section}."):
                result[key[len(section) + 1:]] = self.get(key)

        return result

    def keys(self) -> List[str]:
        """Get all configuration keys."""
        all_keys = set()
        for source in self._sources:
            all_keys.update(source.keys())
        all_keys.update(self._overrides.keys())
        return sorted(all_keys)

    def to_dict(self) -> Dict[str, Any]:
        """Export all configuration as a dictionary."""
        return {key: self.get(key) for key in self.keys()}

    def _validate(self, key: str, value: Any, type_hint: Optional[Type]) -> Any:
        """Validate and convert a value."""
        if key in self._validators:
            validator = self._validators[key]
            if not validator(value):
                if self._strict:
                    raise ValueError(f"Validation failed for {key}: {value}")
                logger.warning("Validation failed for %s: %s", key, value)
        return value

    def _convert(self, value: str) -> Any:
        """Convert string value to appropriate type."""
        # Try JSON parsing
        try:
            return json.loads(value)
        except (json.JSONDecodeError, TypeError):
            pass

        # Boolean
        if value.lower() == "true":
            return True
        if value.lower() == "false":
            return False

        # None
        if value.lower() == "none":
            return None

        # Numeric
        try:
            if "." in value:
                return float(value)
            return int(value)
        except ValueError:
            pass

        return value

    def validate(self, key: str, validator: Callable[[Any], bool]) -> "Config":
        """Add a validator for a configuration key."""
        self._validators[key] = validator
        return self

    def add_listener(self, key: str, callback: Callable[[Any], None]) -> "Config":
        """Add a listener for configuration changes."""
        if key not in self._listeners:
            self._listeners[key] = []
        self._listeners[key].append(callback)
        return self

    def _notify(self, key: str, value: Any) -> None:
        """Notify listeners of configuration change."""
        if key in self._listeners:
            for callback in self._listeners[key]:
                try:
                    callback(value)
                except Exception as exc:
                    logger.warning("Config listener failed for %s: %s", key, exc)

    def bind(self, dataclass_type: Type[T]) -> T:
        """
        Bind configuration to a dataclass.

        All fields in the dataclass are populated from configuration.
        Field names match configuration keys (case-insensitive).

        Example:
            @dataclass
            class ServerConfig:
                host: str = "localhost"
                port: int = 8080
                debug: bool = False

            config = Config()
            server_config = config.bind(ServerConfig)
        """
        if not is_dataclass(dataclass_type):
            raise TypeError("bind() requires a dataclass type")

        kwargs = {}
        for field_info in fields(dataclass_type):
            key = field_info.name
            default = field_info.default
            if default is field_info.default_factory:
                default = None

            value = self.get(key, default, type_hint=field_info.type)
            kwargs[field_info.name] = value

        return dataclass_type(**kwargs)

    def __repr__(self) -> str:
        return f"Config(sources={len(self._sources)}, overrides={len(self._overrides)})"


# ---------------------------------------------------------------------------
# Predefined Configurations
# ---------------------------------------------------------------------------

def create_development_config() -> Config:
    """Create a configuration for development."""
    config = Config()
    config.add_source(YAMLSource("config.dev.yaml", watch=True))
    config.add_source(EnvSource("TASKFLOW_DEV"))
    config.set("debug", True)
    config.set("log_level", "DEBUG")
    return config


def create_production_config() -> Config:
    """Create a configuration for production."""
    config = Config(strict=True)
    config.add_source(EnvSource("TASKFLOW"))
    config.add_source(YAMLSource("config.yaml"))

    # Validate required settings
    config.validate("database.url", lambda v: v is not None)
    config.validate("redis.host", lambda v: v is not None)

    return config


def create_testing_config() -> Config:
    """Create a configuration for testing."""
    config = Config()
    config.add_source(DictSource({
        "backend": "memory",
        "log_level": "DEBUG",
        "worker_concurrency": 2,
    }))
    config.add_source(EnvSource("TASKFLOW_TEST"))
    return config


# ---------------------------------------------------------------------------
# Settings Classes
# ---------------------------------------------------------------------------

@dataclass
class BackendSettings:
    """Settings for task backend."""
    type: str = "memory"
    host: str = "localhost"
    port: int = 6379
    db: int = 0
    password: Optional[str] = None
    ssl: bool = False
    max_connections: int = 50
    result_ttl: int = 86400
    task_ttl: int = 604800


@dataclass
class WorkerSettings:
    """Settings for worker."""
    concurrency: int = 4
    prefetch: int = 1
    poll_interval: float = 0.5
    heartbeat_interval: float = 30.0
    shutdown_timeout: float = 30.0
    queues: List[str] = field(default_factory=lambda: ["default"])


@dataclass
class ServerSettings:
    """Settings for web server."""
    host: str = "0.0.0.0"
    port: int = 8000
    workers: int = 1
    ssl_cert: Optional[str] = None
    ssl_key: Optional[str] = None
    api_key: Optional[str] = None
    enable_dashboard: bool = True
    rate_limit: float = 100.0


@dataclass
class TaskSettings:
    """Settings for task execution."""
    default_timeout: float = 300.0
    max_retries: int = 3
    retry_delay: float = 5.0
    retry_backoff: str = "exponential"
    default_priority: int = 2


@dataclass
class LoggingSettings:
    """Settings for logging."""
    level: str = "INFO"
    format: str = "%(asctime)s %(name)s %(levelname)s %(message)s"
    file: Optional[str] = None
    max_bytes: int = 10485760
    backup_count: int = 5


@dataclass
class MonitoringSettings:
    """Settings for monitoring."""
    enabled: bool = True
    health_port: Optional[int] = None
    metrics_port: Optional[int] = None
    enable_events: bool = True
    event_history_size: int = 1000


@dataclass
class AppSettings:
    """All application settings."""
    backend: BackendSettings = field(default_factory=BackendSettings)
    worker: WorkerSettings = field(default_factory=WorkerSettings)
    server: ServerSettings = field(default_factory=ServerSettings)
    task: TaskSettings = field(default_factory=TaskSettings)
    logging: LoggingSettings = field(default_factory=LoggingSettings)
    monitoring: MonitoringSettings = field(default_factory=MonitoringSettings)

    @classmethod
    def from_config(cls, config: Config) -> "AppSettings":
        """Create settings from configuration."""
        return cls(
            backend=config.bind(BackendSettings),
            worker=config.bind(WorkerSettings),
            server=config.bind(ServerSettings),
            task=config.bind(TaskSettings),
            logging=config.bind(LoggingSettings),
            monitoring=config.bind(MonitoringSettings),
        )


# ---------------------------------------------------------------------------
# Configuration Management
# ---------------------------------------------------------------------------

class ConfigManager:
    """
    Manages multiple named configurations.

    Useful for multi-environment setups (dev, staging, production).
    """

    def __init__(self) -> None:
        self._configs: Dict[str, Config] = {}
        self._active: Optional[str] = None
        self._lock = threading.RLock()

    def add_config(self, name: str, config: Config) -> None:
        """Add a named configuration."""
        with self._lock:
            self._configs[name] = config

    def set_active(self, name: str) -> None:
        """Set the active configuration."""
        with self._lock:
            if name not in self._configs:
                raise KeyError(f"Configuration '{name}' not found")
            self._active = name

    def get_active(self) -> Config:
        """Get the active configuration."""
        with self._lock:
            if self._active is None:
                raise RuntimeError("No active configuration set")
            return self._configs[self._active]

    def get_config(self, name: str) -> Config:
        """Get a configuration by name."""
        with self._lock:
            return self._configs[name]

    def list_configs(self) -> List[str]:
        """List all configuration names."""
        with self._lock:
            return list(self._configs.keys())

    def load_from_file(
        self,
        name: str,
        path: Union[str, Path],
        format: str = "yaml",
    ) -> Config:
        """Load a configuration from file."""
        path = Path(path)

        if format == "yaml":
            source = YAMLSource(path, watch=True)
        elif format == "json":
            source = JSONSource(path, watch=True)
        else:
            raise ValueError(f"Unknown format: {format}")

        config = Config([source])
        self.add_config(name, config)

        if self._active is None:
            self._active = name

        return config
