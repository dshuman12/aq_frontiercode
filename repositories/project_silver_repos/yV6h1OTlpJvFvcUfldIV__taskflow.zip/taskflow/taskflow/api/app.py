"""
Web API and Dashboard for taskflow.

Provides a RESTful API and optional web dashboard for managing
tasks, queues, workers, and monitoring system health.

Features:
- RESTful API for all task operations
- WebSocket support for real-time updates
- Built-in web dashboard
- Authentication and authorization
- Rate limiting
- Request validation
- Error handling
- OpenAPI/Swagger documentation
"""

from __future__ import annotations

import json
import logging
import time
import threading
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set, Type
from urllib.parse import urlparse

try:
    from starlette.applications import Starlette
    from starlette.responses import JSONResponse, HTMLResponse, RedirectResponse
    from starlette.routing import Route, WebSocketRoute
    from starlette.middleware import Middleware
    from starlette.middleware.cors import CORSMiddleware
    from starlette.requests import Request
    from starlette.websockets import WebSocket, WebSocketDisconnect
    from starlette.staticfiles import StaticFiles
    STARLETTE_AVAILABLE = True
except ImportError:
    STARLETTE_AVAILABLE = False
    Starlette = None
    JSONResponse = None
    HTMLResponse = None
    Request = None
    WebSocket = None

from taskflow.core.models import Priority, Task, TaskResult, TaskStatus

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# API Models
# ---------------------------------------------------------------------------

class ErrorCode(Enum):
    """Standard API error codes."""
    UNKNOWN_ERROR = "UNKNOWN_ERROR"
    VALIDATION_ERROR = "VALIDATION_ERROR"
    NOT_FOUND = "NOT_FOUND"
    TASK_NOT_FOUND = "TASK_NOT_FOUND"
    QUEUE_NOT_FOUND = "QUEUE_NOT_FOUND"
    QUEUE_PAUSED = "QUEUE_PAUSED"
    QUEUE_CLOSED = "QUEUE_CLOSED"
    INVALID_STATUS = "INVALID_STATUS"
    TASK_EXPIRED = "TASK_EXPIRED"
    RATE_LIMITED = "RATE_LIMITED"
    UNAUTHORIZED = "UNAUTHORIZED"
    FORBIDDEN = "FORBIDDEN"


@dataclass
class APIResponse:
    """Standard API response wrapper."""
    success: bool
    data: Any = None
    error: Optional[Dict[str, Any]] = None
    meta: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        result = {"success": self.success}
        if self.data is not None:
            result["data"] = self.data
        if self.error:
            result["error"] = self.error
        if self.meta:
            result["meta"] = self.meta
        return result


@dataclass
class PaginatedResponse(APIResponse):
    """Paginated API response."""
    items: List[Any] = field(default_factory=list)
    total: int = 0
    page: int = 1
    per_page: int = 20
    total_pages: int = 0

    def to_dict(self) -> dict:
        return {
            **super().to_dict(),
            "items": self.items,
            "pagination": {
                "total": self.total,
                "page": self.page,
                "per_page": self.per_page,
                "total_pages": self.total_pages,
            },
        }


@dataclass
class TaskCreateRequest:
    """Request to create a new task."""
    task_name: str
    args: List[Any] = field(default_factory=list)
    kwargs: Dict[str, Any] = field(default_factory=dict)
    queue_name: str = "default"
    priority: int = 2
    eta: Optional[str] = None  # ISO format
    expires_at: Optional[str] = None  # ISO format
    timeout_seconds: Optional[float] = None
    correlation_id: Optional[str] = None
    parent_id: Optional[str] = None
    tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class QueueCreateRequest:
    """Request to create a new queue."""
    name: str
    max_concurrency: Optional[int] = None
    tags: List[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Authentication
# ---------------------------------------------------------------------------

class AuthProvider(ABC):
    """Abstract authentication provider."""

    @abstractmethod
    def authenticate(self, request: Any) -> Optional[Dict[str, Any]]:
        """Authenticate a request and return user info or None."""
        pass

    @abstractmethod
    def get_user_permissions(self, user: Dict[str, Any]) -> Set[str]:
        """Get permissions for a user."""
        pass


class APIKeyAuth(AuthProvider):
    """API key based authentication."""

    def __init__(self, valid_keys: Dict[str, Dict[str, Any]]) -> None:
        """
        Initialize with valid API keys.

        Args:
            valid_keys: Dict mapping API keys to user info.
                       Format: {"key": {"user_id": "...", "permissions": [...]}}
        """
        self.valid_keys = valid_keys

    def authenticate(self, request: Any) -> Optional[Dict[str, Any]]:
        # Get API key from header
        auth_header = request.headers.get("Authorization", "")
        if not auth_header.startswith("Bearer "):
            return None

        api_key = auth_header[7:]
        return self.valid_keys.get(api_key)

    def get_user_permissions(self, user: Dict[str, Any]) -> Set[str]:
        return set(user.get("permissions", []))


class NoAuth(AuthProvider):
    """No authentication - for development only."""

    def authenticate(self, request: Any) -> Optional[Dict[str, Any]]:
        return {"user_id": "anonymous", "permissions": {"*"}}

    def get_user_permissions(self, user: Dict[str, Any]) -> Set[str]:
        return {"*"}


# ---------------------------------------------------------------------------
# Rate Limiting
# ---------------------------------------------------------------------------

class RateLimiter:
    """Simple token bucket rate limiter for API endpoints."""

    def __init__(
        self,
        requests_per_second: float = 100,
        burst_size: Optional[float] = None,
    ) -> None:
        self.rate = requests_per_second
        self.burst = burst_size or requests_per_second
        self._buckets: Dict[str, Dict[str, Any]] = {}
        self._lock = threading.Lock()

    def is_allowed(self, key: str) -> bool:
        now = time.monotonic()
        with self._lock:
            bucket = self._buckets.get(key, {
                "tokens": self.burst,
                "last_update": now,
            })

            # Refill tokens
            elapsed = now - bucket["last_update"]
            bucket["tokens"] = min(
                self.burst,
                bucket["tokens"] + elapsed * self.rate
            )
            bucket["last_update"] = now

            if bucket["tokens"] >= 1:
                bucket["tokens"] -= 1
                self._buckets[key] = bucket
                return True

            self._buckets[key] = bucket
            return False


# ---------------------------------------------------------------------------
# Request Validation
# ---------------------------------------------------------------------------

class Validator:
    """Request validation utilities."""

    @staticmethod
    def validate_task_create(data: Dict[str, Any]) -> Tuple[Optional[TaskCreateRequest], Optional[str]]:
        """Validate task creation request."""
        if not data.get("task_name"):
            return None, "task_name is required"

        try:
            priority = int(data.get("priority", 2))
            if priority < 0 or priority > 10:
                return None, "priority must be between 0 and 10"
        except (ValueError, TypeError):
            return None, "priority must be an integer"

        eta = None
        if data.get("eta"):
            try:
                eta = datetime.fromisoformat(data["eta"].replace("Z", "+00:00"))
            except (ValueError, AttributeError):
                return None, "eta must be a valid ISO 8601 datetime"

        expires_at = None
        if data.get("expires_at"):
            try:
                expires_at = datetime.fromisoformat(data["expires_at"].replace("Z", "+00:00"))
            except (ValueError, AttributeError):
                return None, "expires_at must be a valid ISO 8601 datetime"

        return TaskCreateRequest(
            task_name=data["task_name"],
            args=data.get("args", []),
            kwargs=data.get("kwargs", {}),
            queue_name=data.get("queue_name", "default"),
            priority=priority,
            eta=eta.isoformat() if eta else None,
            expires_at=expires_at.isoformat() if expires_at else None,
            timeout_seconds=data.get("timeout_seconds"),
            correlation_id=data.get("correlation_id"),
            parent_id=data.get("parent_id"),
            tags=data.get("tags", []),
            metadata=data.get("metadata", {}),
        ), None

    @staticmethod
    def validate_queue_create(data: Dict[str, Any]) -> Tuple[Optional[QueueCreateRequest], Optional[str]]:
        """Validate queue creation request."""
        if not data.get("name"):
            return None, "name is required"

        name = data["name"]
        if not name.replace("_", "").replace("-", "").isalnum():
            return None, "name must be alphanumeric with optional hyphens/underscores"

        if len(name) > 64:
            return None, "name must be 64 characters or less"

        return QueueCreateRequest(
            name=name,
            max_concurrency=data.get("max_concurrency"),
            tags=data.get("tags", []),
        ), None


def validate_priority(priority: Any) -> Priority:
    """Convert priority value to Priority enum."""
    if isinstance(priority, str):
        return Priority.from_string(priority)
    return Priority.from_int(int(priority))


# ---------------------------------------------------------------------------
# API Handler
# ---------------------------------------------------------------------------

class APIHandler:
    """
    Main API request handler.

    Routes requests to appropriate methods and handles errors.
    """

    def __init__(
        self,
        backend: Any,
        registry: Any,
        auth: Optional[AuthProvider] = None,
        rate_limiter: Optional[RateLimiter] = None,
    ) -> None:
        self.backend = backend
        self.registry = registry
        self.auth = auth or NoAuth()
        self.rate_limiter = rate_limiter or RateLimiter()

    async def handle_request(self, request: Request) -> JSONResponse:
        """Route and handle the request."""
        # Rate limiting
        if not self.rate_limiter.is_allowed(request.client.host if request.client else "unknown"):
            return self._error_response(
                ErrorCode.RATE_LIMITED,
                "Rate limit exceeded",
                status_code=429
            )

        # Authentication
        user = self.auth.authenticate(request)
        if user is None:
            return self._error_response(
                ErrorCode.UNAUTHORIZED,
                "Authentication required",
                status_code=401
            )

        # Route request
        path = request.url.path
        method = request.method

        try:
            if path == "/api/v1/tasks" and method == "POST":
                return await self._create_task(request, user)
            elif path.startswith("/api/v1/tasks/") and method == "GET":
                task_id = path.split("/")[-1]
                return await self._get_task(task_id, user)
            elif path.startswith("/api/v1/tasks/") and method == "DELETE":
                task_id = path.split("/")[-1]
                return await self._revoke_task(task_id, user)
            elif path == "/api/v1/tasks" and method == "GET":
                return await self._list_tasks(request, user)
            elif path == "/api/v1/tasks/wait" and method == "POST":
                return await self._wait_for_task(request, user)

            elif path == "/api/v1/queues" and method == "POST":
                return await self._create_queue(request, user)
            elif path == "/api/v1/queues" and method == "GET":
                return await self._list_queues(request, user)
            elif path.startswith("/api/v1/queues/") and method == "GET":
                queue_name = path.split("/")[-1]
                return await self._get_queue(queue_name, user)
            elif path.startswith("/api/v1/queues/") and method == "DELETE":
                queue_name = path.split("/")[-1]
                return await self._purge_queue(queue_name, request, user)
            elif path.startswith("/api/v1/queues/") and method == "PATCH":
                queue_name = path.split("/")[-1]
                return await self._update_queue(queue_name, request, user)

            elif path == "/api/v1/workers" and method == "GET":
                return await self._list_workers(request, user)
            elif path.startswith("/api/v1/workers/") and method == "DELETE":
                worker_id = path.split("/")[-1]
                return await self._unregister_worker(worker_id, user)

            elif path == "/api/v1/stats" and method == "GET":
                return await self._get_stats(request, user)
            elif path.startswith("/api/v1/queues/") and path.endswith("/stats"):
                queue_name = path.split("/")[-2]
                return await self._get_queue_stats(queue_name, user)

            elif path == "/api/v1/health" and method == "GET":
                return await self._health_check(request)
            elif path == "/api/v1/ready" and method == "GET":
                return await self._readiness_check(request)

            elif path == "/api/v1/dead-letter" and method == "GET":
                return await self._list_dead_letter(request, user)
            elif path.startswith("/api/v1/dead-letter/") and method == "POST":
                task_id = path.split("/")[-1]
                return await self._restore_dead_letter(task_id, user)

            elif path == "/api/v1" and method == "GET":
                return self._success_response({
                    "name": "taskflow",
                    "version": "1.0.0",
                    "endpoints": self._get_endpoints(),
                })

            else:
                return self._error_response(
                    ErrorCode.NOT_FOUND,
                    f"Endpoint not found: {method} {path}",
                    status_code=404
                )

        except Exception as exc:
            logger.exception("API request failed: %s", exc)
            return self._error_response(
                ErrorCode.UNKNOWN_ERROR,
                str(exc),
                status_code=500
            )

    def _get_endpoints(self) -> List[Dict[str, str]]:
        """Get list of available API endpoints."""
        return [
            {"method": "POST", "path": "/api/v1/tasks", "description": "Create a new task"},
            {"method": "GET", "path": "/api/v1/tasks", "description": "List tasks"},
            {"method": "GET", "path": "/api/v1/tasks/{id}", "description": "Get task details"},
            {"method": "DELETE", "path": "/api/v1/tasks/{id}", "description": "Revoke a task"},
            {"method": "POST", "path": "/api/v1/tasks/wait", "description": "Wait for task result"},
            {"method": "POST", "path": "/api/v1/queues", "description": "Create a queue"},
            {"method": "GET", "path": "/api/v1/queues", "description": "List queues"},
            {"method": "GET", "path": "/api/v1/queues/{name}", "description": "Get queue details"},
            {"method": "PATCH", "path": "/api/v1/queues/{name}", "description": "Update queue"},
            {"method": "DELETE", "path": "/api/v1/queues/{name}", "description": "Purge queue"},
            {"method": "GET", "path": "/api/v1/workers", "description": "List workers"},
            {"method": "GET", "path": "/api/v1/stats", "description": "Get global stats"},
            {"method": "GET", "path": "/api/v1/health", "description": "Health check"},
            {"method": "GET", "path": "/api/v1/ready", "description": "Readiness check"},
        ]

    def _success_response(
        self,
        data: Any,
        meta: Optional[Dict[str, Any]] = None,
        status_code: int = 200,
    ) -> JSONResponse:
        """Create a successful API response."""
        response = APIResponse(success=True, data=data, meta=meta or {})
        return JSONResponse(response.to_dict(), status_code=status_code)

    def _error_response(
        self,
        code: ErrorCode,
        message: str,
        details: Optional[Dict[str, Any]] = None,
        status_code: int = 400,
    ) -> JSONResponse:
        """Create an error API response."""
        error = {
            "code": code.value,
            "message": message,
        }
        if details:
            error["details"] = details

        response = APIResponse(success=False, error=error)
        return JSONResponse(response.to_dict(), status_code=status_code)

    # ---------------------------------------------------------------------------
    # Task Endpoints
    # ---------------------------------------------------------------------------

    async def _create_task(self, request: Request, user: Dict[str, Any]) -> JSONResponse:
        """Create a new task."""
        body = await request.json()
        task_request, error = Validator.validate_task_create(body)
        if error:
            return self._error_response(ErrorCode.VALIDATION_ERROR, error)

        # Check if task exists in registry
        try:
            self.registry.get(task_request.task_name)
        except Exception:
            return self._error_response(
                ErrorCode.NOT_FOUND,
                f"Task '{task_request.task_name}' not found in registry"
            )

        # Create task
        task = Task(
            task_name=task_request.task_name,
            args=task_request.args,
            kwargs=task_request.kwargs,
            queue_name=task_request.queue_name,
            priority=Priority.from_int(task_request.priority),
            eta=datetime.fromisoformat(task_request.eta) if task_request.eta else None,
            expires_at=datetime.fromisoformat(task_request.expires_at) if task_request.expires_at else None,
            timeout_seconds=task_request.timeout_seconds,
            correlation_id=task_request.correlation_id,
            parent_id=task_request.parent_id,
            tags=task_request.tags,
            metadata=task_request.metadata,
        )

        self.backend.enqueue(task)

        return self._success_response(task.to_dict(), status_code=201)

    async def _get_task(self, task_id: str, user: Dict[str, Any]) -> JSONResponse:
        """Get task details."""
        task = self.backend.get_task(task_id)
        if not task:
            result = self.backend.get_result(task_id)
            if result:
                return self._success_response(result.to_dict())
            return self._error_response(
                ErrorCode.TASK_NOT_FOUND,
                f"Task '{task_id}' not found",
                status_code=404
            )

        return self._success_response(task.to_dict())

    async def _list_tasks(self, request: Request, user: Dict[str, Any]) -> JSONResponse:
        """List tasks with pagination and filtering."""
        queue_name = request.query_params.get("queue")
        status_str = request.query_params.get("status")
        status = None
        if status_str:
            try:
                status = TaskStatus(status_str)
            except ValueError:
                return self._error_response(
                    ErrorCode.VALIDATION_ERROR,
                    f"Invalid status: {status_str}"
                )

        limit = min(int(request.query_params.get("limit", 20)), 100)
        offset = int(request.query_params.get("offset", 0))

        tasks = self.backend.list_tasks(
            queue_name=queue_name,
            status=status,
            limit=limit,
            offset=offset,
        )

        return self._success_response({
            "tasks": [t.to_dict() for t in tasks],
            "limit": limit,
            "offset": offset,
        })

    async def _revoke_task(self, task_id: str, user: Dict[str, Any]) -> JSONResponse:
        """Revoke a task."""
        ok = self.backend.revoke(task_id)
        if not ok:
            return self._error_response(
                ErrorCode.TASK_NOT_FOUND,
                f"Task '{task_id}' not found or already terminal",
                status_code=404
            )

        return self._success_response({"revoked": True, "task_id": task_id})

    async def _wait_for_task(self, request: Request, user: Dict[str, Any]) -> JSONResponse:
        """Wait for a task result."""
        body = await request.json()
        task_id = body.get("task_id")
        if not task_id:
            return self._error_response(ErrorCode.VALIDATION_ERROR, "task_id is required")

        timeout = float(body.get("timeout", 30.0))
        result = self.backend.wait_for_result(task_id, timeout=timeout)

        if result is None:
            return self._error_response(
                ErrorCode.TASK_NOT_FOUND,
                f"No result found for task '{task_id}' within {timeout}s",
                status_code=404
            )

        return self._success_response(result.to_dict())

    # ---------------------------------------------------------------------------
    # Queue Endpoints
    # ---------------------------------------------------------------------------

    async def _create_queue(self, request: Request, user: Dict[str, Any]) -> JSONResponse:
        """Create a new queue."""
        body = await request.json()
        queue_request, error = Validator.validate_queue_create(body)
        if error:
            return self._error_response(ErrorCode.VALIDATION_ERROR, error)

        info = self.backend.declare_queue(
            name=queue_request.name,
            max_concurrency=queue_request.max_concurrency,
            tags=queue_request.tags,
        )

        return self._success_response(info.to_dict(), status_code=201)

    async def _list_queues(self, request: Request, user: Dict[str, Any]) -> JSONResponse:
        """List all queues."""
        queues = self.backend.all_queue_info()
        return self._success_response({
            "queues": [q.to_dict() for q in queues],
        })

    async def _get_queue(self, name: str, user: Dict[str, Any]) -> JSONResponse:
        """Get queue details."""
        info = self.backend.queue_info(name)
        if not info:
            return self._error_response(
                ErrorCode.QUEUE_NOT_FOUND,
                f"Queue '{name}' not found",
                status_code=404
            )

        return self._success_response(info.to_dict())

    async def _purge_queue(self, name: str, request: Request, user: Dict[str, Any]) -> JSONResponse:
        """Purge a queue."""
        count = self.backend.purge_queue(name)
        return self._success_response({
            "purged": count,
            "queue": name,
        })

    async def _update_queue(self, name: str, request: Request, user: Dict[str, Any]) -> JSONResponse:
        """Update queue status."""
        body = await request.json()
        action = body.get("action")

        if action == "pause":
            self.backend.pause_queue(name)
        elif action == "resume":
            self.backend.resume_queue(name)
        elif action == "close":
            self.backend.close_queue(name)
        elif action == "drain":
            count = self.backend.drain_queue(name)
            return self._success_response({
                "drained": count,
                "queue": name,
            })
        else:
            return self._error_response(
                ErrorCode.VALIDATION_ERROR,
                f"Unknown action: {action}"
            )

        return self._success_response({"updated": True, "queue": name, "action": action})

    # ---------------------------------------------------------------------------
    # Worker Endpoints
    # ---------------------------------------------------------------------------

    async def _list_workers(self, request: Request, user: Dict[str, Any]) -> JSONResponse:
        """List active workers."""
        workers = self.backend.get_active_workers()
        return self._success_response({"workers": workers})

    async def _unregister_worker(self, worker_id: str, user: Dict[str, Any]) -> JSONResponse:
        """Unregister a worker."""
        self.backend.unregister_worker(worker_id)
        return self._success_response({"unregistered": True, "worker_id": worker_id})

    # ---------------------------------------------------------------------------
    # Stats Endpoints
    # ---------------------------------------------------------------------------

    async def _get_stats(self, request: Request, user: Dict[str, Any]) -> JSONResponse:
        """Get global statistics."""
        stats = self.backend.get_global_stats()
        return self._success_response(stats)

    async def _get_queue_stats(self, queue_name: str, user: Dict[str, Any]) -> JSONResponse:
        """Get queue statistics."""
        stats = self.backend.get_queue_stats(queue_name)
        return self._success_response(stats)

    # ---------------------------------------------------------------------------
    # Health Endpoints
    # ---------------------------------------------------------------------------

    async def _health_check(self, request: Request) -> JSONResponse:
        """Basic health check."""
        return self._success_response({
            "status": "healthy",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })

    async def _readiness_check(self, request: Request) -> JSONResponse:
        """Readiness check including backend connectivity."""
        try:
            # Check if backend is available
            if hasattr(self.backend, "ping"):
                is_ready = self.backend.ping()
            else:
                is_ready = True

            return self._success_response({
                "ready": is_ready,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            })
        except Exception as exc:
            return self._error_response(
                ErrorCode.UNKNOWN_ERROR,
                f"Backend not ready: {exc}",
                status_code=503
            )

    # ---------------------------------------------------------------------------
    # Dead Letter Endpoints
    # ---------------------------------------------------------------------------

    async def _list_dead_letter(self, request: Request, user: Dict[str, Any]) -> JSONResponse:
        """List dead letter tasks."""
        queue_name = request.query_params.get("queue")
        limit = min(int(request.query_params.get("limit", 20)), 100)
        offset = int(request.query_params.get("offset", 0))

        tasks = self.backend.get_dead_letter_tasks(
            queue_name=queue_name,
            limit=limit,
            offset=offset,
        )

        return self._success_response({
            "tasks": tasks,
            "limit": limit,
            "offset": offset,
        })

    async def _restore_dead_letter(self, task_id: str, user: Dict[str, Any]) -> JSONResponse:
        """Restore a task from dead letter queue."""
        task = self.backend.restore_from_dead_letter(task_id)
        if not task:
            return self._error_response(
                ErrorCode.TASK_NOT_FOUND,
                f"Task '{task_id}' not found in dead letter queue",
                status_code=404
            )

        return self._success_response({
            "restored": True,
            "task": task.to_dict(),
        })


# ---------------------------------------------------------------------------
# WebSocket Handler
# ---------------------------------------------------------------------------

class WebSocketHandler:
    """WebSocket handler for real-time updates."""

    def __init__(self, backend: Any) -> None:
        self.backend = backend
        self.connections: Dict[str, Set[WebSocket]] = {}
        self._lock = threading.Lock()

    async def connect(self, websocket: WebSocket, queue_name: Optional[str] = None) -> None:
        """Accept a WebSocket connection."""
        await websocket.accept()

        queue_key = queue_name or "*"
        with self._lock:
            if queue_key not in self.connections:
                self.connections[queue_key] = set()
            self.connections[queue_key].add(websocket)

    def disconnect(self, websocket: WebSocket, queue_name: Optional[str] = None) -> None:
        """Remove a WebSocket connection."""
        queue_key = queue_name or "*"
        with self._lock:
            if queue_key in self.connections:
                self.connections[queue_key].discard(websocket)
                if not self.connections[queue_key]:
                    del self.connections[queue_key]

    async def broadcast(self, queue_name: str, event_type: str, data: Dict[str, Any]) -> None:
        """Broadcast an event to subscribed connections."""
        message = json.dumps({
            "type": event_type,
            "queue": queue_name,
            "data": data,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })

        with self._lock:
            # Send to specific queue subscribers
            if queue_name in self.connections:
                for ws in list(self.connections[queue_name]):
                    try:
                        await ws.send_text(message)
                    except Exception:
                        self.connections[queue_name].discard(ws)

            # Send to wildcard subscribers
            if "*" in self.connections:
                for ws in list(self.connections["*"]):
                    try:
                        await ws.send_text(message)
                    except Exception:
                        self.connections["*"].discard(ws)


# ---------------------------------------------------------------------------
# Dashboard HTML
# ---------------------------------------------------------------------------

DASHBOARD_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TaskFlow Dashboard</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f5f5f5; }
        .header { background: #2c3e50; color: white; padding: 1rem 2rem; display: flex; justify-content: space-between; align-items: center; }
        .header h1 { font-size: 1.5rem; }
        .container { max-width: 1400px; margin: 0 auto; padding: 2rem; }
        .card { background: white; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); padding: 1.5rem; margin-bottom: 1.5rem; }
        .card h2 { margin-bottom: 1rem; color: #2c3e50; }
        .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; }
        .stat { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 1.5rem; border-radius: 8px; }
        .stat h3 { font-size: 0.875rem; opacity: 0.9; }
        .stat .value { font-size: 2rem; font-weight: bold; }
        .table { width: 100%; border-collapse: collapse; }
        .table th, .table td { padding: 0.75rem; text-align: left; border-bottom: 1px solid #eee; }
        .table th { background: #f8f9fa; font-weight: 600; }
        .status { padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.75rem; font-weight: 500; }
        .status.pending { background: #fff3cd; color: #856404; }
        .status.running { background: #cce5ff; color: #004085; }
        .status.success { background: #d4edda; color: #155724; }
        .status.failure { background: #f8d7da; color: #721c24; }
        .tabs { display: flex; gap: 0.5rem; margin-bottom: 1rem; }
        .tab { padding: 0.5rem 1rem; border: none; background: #e9ecef; cursor: pointer; border-radius: 4px; }
        .tab.active { background: #2c3e50; color: white; }
        .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 1rem; }
        .queue-card { background: #f8f9fa; padding: 1rem; border-radius: 8px; }
        .queue-card h4 { margin-bottom: 0.5rem; }
        .queue-stats { display: flex; gap: 1rem; font-size: 0.875rem; color: #666; }
        .btn { padding: 0.5rem 1rem; border: none; border-radius: 4px; cursor: pointer; }
        .btn-primary { background: #3498db; color: white; }
        .btn-danger { background: #e74c3c; color: white; }
        .refresh { position: fixed; bottom: 2rem; right: 2rem; }
    </style>
</head>
<body>
    <div class="header">
        <h1>TaskFlow Dashboard</h1>
        <span id="timestamp"></span>
    </div>
    <div class="container">
        <div class="stats" id="stats">
            <div class="stat"><h3>Total Enqueued</h3><div class="value" id="total-enqueued">-</div></div>
            <div class="stat"><h3>Completed</h3><div class="value" id="total-completed">-</div></div>
            <div class="stat"><h3>Failed</h3><div class="value" id="total-failed">-</div></div>
            <div class="stat"><h3>Active Workers</h3><div class="value" id="active-workers">-</div></div>
        </div>

        <div class="card">
            <h2>Queues</h2>
            <div class="tabs">
                <button class="tab active" data-tab="queues">All Queues</button>
                <button class="tab" data-tab="tasks">Recent Tasks</button>
                <button class="tab" data-tab="workers">Workers</button>
            </div>
            <div id="tab-content"></div>
        </div>
    </div>

    <script>
        const API_BASE = '/api/v1';

        async function fetchJSON(url, options = {}) {
            const response = await fetch(url, options);
            const data = await response.json();
            if (!data.success) throw new Error(data.error?.message || 'Request failed');
            return data;
        }

        async function loadStats() {
            try {
                const stats = await fetchJSON(API_BASE + '/stats');
                document.getElementById('total-enqueued').textContent = stats.data.total_enqueued || 0;
                document.getElementById('total-completed').textContent = stats.data.total_completed || 0;
                document.getElementById('total-failed').textContent = stats.data.total_failed || 0;
                document.getElementById('active-workers').textContent = (await fetchJSON(API_BASE + '/workers')).data.workers?.length || 0;
            } catch (e) {
                console.error('Failed to load stats:', e);
            }
        }

        async function loadQueues() {
            const data = await fetchJSON(API_BASE + '/queues');
            const queues = data.data.queues || [];

            let html = '<div class="grid">';
            for (const q of queues) {
                html += `
                    <div class="queue-card">
                        <h4>${q.name}</h4>
                        <span class="status ${q.status}">${q.status}</span>
                        <div class="queue-stats">
                            <span>Pending: ${q.pending_count}</span>
                            <span>Completed: ${q.completed_count}</span>
                        </div>
                    </div>
                `;
            }
            html += '</div>';
            document.getElementById('tab-content').innerHTML = html || '<p>No queues found</p>';
        }

        async function loadTasks() {
            const data = await fetchJSON(API_BASE + '/tasks?limit=50');
            const tasks = data.data.tasks || [];

            let html = '<table class="table"><thead><tr><th>ID</th><th>Name</th><th>Status</th><th>Queue</th><th>Created</th></tr></thead><tbody>';
            for (const t of tasks) {
                html += `
                    <tr>
                        <td>${t.task_id.substring(0, 8)}...</td>
                        <td>${t.task_name}</td>
                        <td><span class="status ${t.status}">${t.status}</span></td>
                        <td>${t.queue_name}</td>
                        <td>${new Date(t.created_at).toLocaleString()}</td>
                    </tr>
                `;
            }
            html += '</tbody></table>';
            document.getElementById('tab-content').innerHTML = html || '<p>No tasks found</p>';
        }

        async function loadWorkers() {
            const data = await fetchJSON(API_BASE + '/workers');
            const workers = data.data.workers || [];

            let html = '<table class="table"><thead><tr><th>Worker ID</th><th>Queues</th><th>Concurrency</th><th>Last Heartbeat</th></tr></thead><tbody>';
            for (const w of workers) {
                html += `
                    <tr>
                        <td>${w.worker_id}</td>
                        <td>${JSON.parse(w.queues || '[]').join(', ')}</td>
                        <td>${w.concurrency}</td>
                        <td>${w.last_heartbeat ? new Date(w.last_heartbeat).toLocaleString() : '-'}</td>
                    </tr>
                `;
            }
            html += '</tbody></table>';
            document.getElementById('tab-content').innerHTML = html || '<p>No active workers</p>';
        }

        document.querySelectorAll('.tab').forEach(tab => {
            tab.addEventListener('click', () => {
                document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
                tab.classList.add('active');
                const tabName = tab.dataset.tab;
                if (tabName === 'queues') loadQueues();
                else if (tabName === 'tasks') loadTasks();
                else if (tabName === 'workers') loadWorkers();
            });
        });

        function updateTimestamp() {
            document.getElementById('timestamp').textContent = new Date().toLocaleString();
        }

        async function refresh() {
            updateTimestamp();
            await loadStats();
            await loadQueues();
        }

        refresh();
        setInterval(refresh, 10000);
    </script>
</body>
</html>
"""


# ---------------------------------------------------------------------------
# Application Builder
# ---------------------------------------------------------------------------

class TaskFlowApp:
    """
    TaskFlow web application builder.

    Combines API, WebSocket, and dashboard into a Starlette application.
    """

    def __init__(
        self,
        backend: Any,
        registry: Any,
        auth: Optional[AuthProvider] = None,
        api_key: Optional[str] = None,
        enable_dashboard: bool = True,
        rate_limit: float = 100,
    ) -> None:
        if not STARLETTE_AVAILABLE:
            raise ImportError(
                "Starlette is required for the web API. "
                "Install with: pip install starlette uvicorn"
            )

        self.backend = backend
        self.registry = registry
        self.api_key = api_key
        self.enable_dashboard = enable_dashboard

        # Create API key auth if key provided
        if api_key:
            self.auth = APIKeyAuth({
                api_key: {"user_id": "admin", "permissions": {"*"}}
            })
        else:
            self.auth = auth or NoAuth()

        self.rate_limiter = RateLimiter(requests_per_second=rate_limit)
        self.api_handler = APIHandler(
            backend=backend,
            registry=registry,
            auth=self.auth,
            rate_limiter=self.rate_limiter,
        )
        self.ws_handler = WebSocketHandler(backend=backend)

        self.app = self._build_app()

    def _build_app(self) -> Any:
        """Build the Starlette application."""
        routes = [
            Route("/api/v1/{path:path}", self._handle_api, methods=["GET", "POST", "PUT", "PATCH", "DELETE"]),
            Route("/api/v1", self._handle_api_root, methods=["GET"]),
            WebSocketRoute("/ws", self._handle_websocket),
        ]

        if self.enable_dashboard:
            routes.extend([
                Route("/", self._dashboard),
                Route("/dashboard", self._dashboard),
            ])

        middleware = [
            Middleware(
                CORSMiddleware,
                allow_origins=["*"],
                allow_methods=["*"],
                allow_headers=["*"],
            ),
        ]

        return Starlette(
            debug=True,
            routes=routes,
            middleware=middleware,
        )

    async def _handle_api(self, request: Request) -> JSONResponse:
        """Handle API requests."""
        # Handle root path specially
        if request.url.path == "/api/v1":
            return await self.api_handler.handle_request(request)

        return await self.api_handler.handle_request(request)

    async def _handle_api_root(self, request: Request) -> JSONResponse:
        """Handle root API requests."""
        return await self.api_handler.handle_request(request)

    async def _handle_websocket(self, websocket: WebSocket) -> None:
        """Handle WebSocket connections."""
        queue_name = websocket.query_params.get("queue")
        await self.ws_handler.connect(websocket, queue_name)
        try:
            while True:
                # Keep connection alive and handle incoming messages
                data = await websocket.receive_text()
                message = json.loads(data)
                if message.get("type") == "ping":
                    await websocket.send_text(json.dumps({"type": "pong"}))
        except WebSocketDisconnect:
            self.ws_handler.disconnect(websocket, queue_name)

    async def _dashboard(self, request: Request) -> HTMLResponse:
        """Serve the dashboard HTML."""
        return HTMLResponse(DASHBOARD_HTML)

    def run(
        self,
        host: str = "0.0.0.0",
        port: int = 8000,
        workers: int = 1,
        log_level: str = "info",
    ) -> None:
        """
        Run the application with uvicorn.

        Requires uvicorn to be installed.
        """
        try:
            import uvicorn
            uvicorn.run(
                self.app,
                host=host,
                port=port,
                workers=workers,
                log_level=log_level,
            )
        except ImportError:
            raise ImportError(
                "uvicorn is required to run the web server. "
                "Install with: pip install uvicorn"
            )


# ---------------------------------------------------------------------------
# Standalone Server
# ---------------------------------------------------------------------------

def run_server(
    backend: Any,
    registry: Any,
    host: str = "0.0.0.0",
    port: int = 8000,
    api_key: Optional[str] = None,
    enable_dashboard: bool = True,
) -> None:
    """
    Run the TaskFlow web server.

    Args:
        backend: Task backend instance.
        registry: Task registry instance.
        host: Host to bind to.
        port: Port to bind to.
        api_key: Optional API key for authentication.
        enable_dashboard: Whether to enable the web dashboard.
    """
    app = TaskFlowApp(
        backend=backend,
        registry=registry,
        api_key=api_key,
        enable_dashboard=enable_dashboard,
    )
    app.run(host=host, port=port)


# ---------------------------------------------------------------------------
# WSGI/ASGI Export
# ---------------------------------------------------------------------------

def create_app(
    backend: Any,
    registry: Any,
    api_key: Optional[str] = None,
    enable_dashboard: bool = True,
) -> Any:
    """
    Create an ASGI application for deployment.

    Returns a Starlette application that can be mounted or run with uvicorn.
    """
    app = TaskFlowApp(
        backend=backend,
        registry=registry,
        api_key=api_key,
        enable_dashboard=enable_dashboard,
    )
    return app.app
