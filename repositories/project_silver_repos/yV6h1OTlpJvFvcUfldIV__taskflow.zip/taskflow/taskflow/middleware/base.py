"""
Middleware for taskflow workers.

Middleware runs before and after each task execution, allowing cross-cutting
concerns like logging, metrics, rate limiting, and tracing to be implemented
cleanly without modifying task code.
"""

from __future__ import annotations

import logging
import time
import threading
from abc import ABC, abstractmethod
from collections import defaultdict, deque
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


class BaseMiddleware(ABC):
    """Abstract base class for taskflow middleware."""

    def before_task(self, ctx: Any) -> None:
        """Called before a task is executed. ctx is a TaskExecutionContext."""

    def after_task(self, ctx: Any, result: Any) -> None:
        """Called after a task completes (success or failure)."""

    def on_error(self, ctx: Any, exc: Exception) -> None:
        """Called when a task raises an unhandled exception."""


class LoggingMiddleware(BaseMiddleware):
    """
    Logs task start, completion, and failure events.

    Configurable log levels for each event type.
    """

    def __init__(
        self,
        logger_name: str = "taskflow.tasks",
        start_level: int = logging.DEBUG,
        success_level: int = logging.INFO,
        failure_level: int = logging.WARNING,
    ) -> None:
        self._logger = logging.getLogger(logger_name)
        self.start_level = start_level
        self.success_level = success_level
        self.failure_level = failure_level

    def before_task(self, ctx: Any) -> None:
        self._logger.log(
            self.start_level,
            "Starting task %s (id=%s attempt=%d queue=%s)",
            ctx.task.task_name,
            ctx.task.task_id,
            ctx.task.attempt,
            ctx.task.queue_name,
        )

    def after_task(self, ctx: Any, result: Any) -> None:
        from taskflow.core.models import TaskStatus
        level = self.success_level if result.status == TaskStatus.SUCCESS else self.failure_level
        self._logger.log(
            level,
            "Task %s %s in %.3fs (id=%s)",
            ctx.task.task_name,
            result.status.value,
            ctx.elapsed_seconds,
            ctx.task.task_id,
        )


class TimingMiddleware(BaseMiddleware):
    """
    Records task execution times and maintains a rolling statistics window.

    Statistics are accessible via .stats(task_name).
    """

    def __init__(self, window_size: int = 1000) -> None:
        self._lock = threading.Lock()
        self._times: Dict[str, deque] = defaultdict(lambda: deque(maxlen=window_size))

    def after_task(self, ctx: Any, result: Any) -> None:
        elapsed = ctx.elapsed_seconds
        with self._lock:
            self._times[ctx.task.task_name].append(elapsed)

    def stats(self, task_name: Optional[str] = None) -> dict:
        with self._lock:
            if task_name:
                times = list(self._times.get(task_name, []))
                return self._compute_stats(task_name, times)
            return {
                name: self._compute_stats(name, list(times))
                for name, times in self._times.items()
            }

    def _compute_stats(self, name: str, times: list) -> dict:
        if not times:
            return {"task": name, "count": 0}
        sorted_times = sorted(times)
        n = len(sorted_times)
        return {
            "task": name,
            "count": n,
            "mean": sum(times) / n,
            "min": sorted_times[0],
            "max": sorted_times[-1],
            "p50": sorted_times[n // 2],
            "p95": sorted_times[int(n * 0.95)],
            "p99": sorted_times[int(n * 0.99)],
        }


class RateLimitMiddleware(BaseMiddleware):
    """
    Token-bucket rate limiter per task name.

    Blocks execution (with a short sleep loop) if the rate limit is exceeded.
    Rate spec format: "N/period" where period is second, minute, or hour.
    Example: "100/minute", "10/second", "1000/hour"
    """

    def __init__(self, limits: Dict[str, str]) -> None:
        self._lock = threading.Lock()
        self._buckets: Dict[str, dict] = {}
        for task_name, spec in limits.items():
            rate, period = self._parse_spec(spec)
            self._buckets[task_name] = {
                "rate": rate,
                "period_seconds": period,
                "tokens": float(rate),
                "last_refill": time.monotonic(),
            }

    def _parse_spec(self, spec: str) -> tuple[float, float]:
        parts = spec.strip().split("/")
        if len(parts) != 2:
            raise ValueError(f"Invalid rate limit spec: {spec!r}. Expected 'N/period'")
        count = float(parts[0])
        period_str = parts[1].lower()
        if period_str in ("s", "sec", "second"):
            period = 1.0
        elif period_str in ("m", "min", "minute"):
            period = 60.0
        elif period_str in ("h", "hr", "hour"):
            period = 3600.0
        else:
            raise ValueError(f"Unknown period: {period_str!r}")
        return count, period

    def _refill(self, bucket: dict) -> None:
        now = time.monotonic()
        elapsed = now - bucket["last_refill"]
        new_tokens = elapsed * (bucket["rate"] / bucket["period_seconds"])
        bucket["tokens"] = min(bucket["rate"], bucket["tokens"] + new_tokens)
        bucket["last_refill"] = now

    def before_task(self, ctx: Any) -> None:
        name = ctx.task.task_name
        with self._lock:
            bucket = self._buckets.get(name)
            if bucket is None:
                return
            self._refill(bucket)
            if bucket["tokens"] >= 1:
                bucket["tokens"] -= 1
                return

        # Wait for a token
        while True:
            time.sleep(0.05)
            with self._lock:
                bucket = self._buckets.get(name)
                if bucket is None:
                    return
                self._refill(bucket)
                if bucket["tokens"] >= 1:
                    bucket["tokens"] -= 1
                    return


class RetryTrackingMiddleware(BaseMiddleware):
    """Tracks retry counts per task name for monitoring."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._retries: Dict[str, int] = defaultdict(int)

    def after_task(self, ctx: Any, result: Any) -> None:
        from taskflow.core.models import TaskStatus
        if result.status == TaskStatus.RETRY or ctx.task.attempt > 1:
            with self._lock:
                self._retries[ctx.task.task_name] += 1

    def retry_counts(self) -> dict:
        with self._lock:
            return dict(self._retries)


class CorrelationMiddleware(BaseMiddleware):
    """
    Propagates correlation IDs through task execution.

    Stores the correlation ID in a thread-local so it can be accessed
    by logging formatters or other code running within the task.
    """

    _local = threading.local()

    @classmethod
    def current_correlation_id(cls) -> Optional[str]:
        return getattr(cls._local, "correlation_id", None)

    def before_task(self, ctx: Any) -> None:
        self._local.correlation_id = ctx.task.correlation_id

    def after_task(self, ctx: Any, result: Any) -> None:
        self._local.correlation_id = None


class TagFilterMiddleware(BaseMiddleware):
    """
    Skips tasks that don't match a required tag.

    Useful when multiple worker processes share a queue but should only
    execute tasks relevant to their role.
    """

    def __init__(self, required_tags: List[str], mode: str = "any") -> None:
        self.required_tags = set(required_tags)
        self.mode = mode  # "any" or "all"

    def before_task(self, ctx: Any) -> None:
        task_tags = set(ctx.task.tags or [])
        if self.mode == "all":
            if not self.required_tags.issubset(task_tags):
                raise SkipTask(
                    f"Task {ctx.task.task_name} missing required tags: "
                    f"{self.required_tags - task_tags}"
                )
        else:  # any
            if not self.required_tags & task_tags:
                raise SkipTask(
                    f"Task {ctx.task.task_name} has no matching tags from {self.required_tags}"
                )


class SkipTask(Exception):
    """Raised by middleware to skip a task without marking it as failed."""
