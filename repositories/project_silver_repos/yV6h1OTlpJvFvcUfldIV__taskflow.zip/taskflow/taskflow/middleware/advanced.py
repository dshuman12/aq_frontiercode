"""
Advanced middleware for taskflow workers.

Advanced middleware includes resource quotas, concurrency limiting,
alerting, caching, transaction support, and more.
"""

from __future__ import annotations

import copy
import hashlib
import json
import logging
import threading
import time
from abc import abstractmethod
from collections import defaultdict, deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set, Tuple
from contextlib import contextmanager

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Concurrency Limiter Middleware
# ---------------------------------------------------------------------------

class ConcurrencyLimiterMiddleware:
    """
    Limits concurrent executions of tasks by name or globally.

    Uses semaphores to prevent resource exhaustion when many tasks
    of the same type are queued.
    """

    def __init__(
        self,
        per_task_limits: Optional[Dict[str, int]] = None,
        global_limit: Optional[int] = None,
        block_on_limit: bool = True,
        timeout: Optional[float] = None,
    ) -> None:
        self._per_task_limits = per_task_limits or {}
        self._global_limit = global_limit
        self._block_on_limit = block_on_limit
        self._timeout = timeout
        self._lock = threading.Lock()
        self._task_semaphores: Dict[str, threading.Semaphore] = {}
        self._global_semaphore: Optional[threading.Semaphore] = None
        self._active_counts: Dict[str, int] = defaultdict(int)
        self._total_active: int = 0

        # Initialize semaphores
        for task_name, limit in self._per_task_limits.items():
            self._task_semaphores[task_name] = threading.Semaphore(limit)

        if self._global_limit:
            self._global_semaphore = threading.Semaphore(self._global_limit)

    def before_task(self, ctx: Any) -> None:
        task_name = ctx.task.task_name
        acquired = False
        wait_start = time.monotonic()

        try:
            # Acquire task-specific semaphore
            task_sem = self._get_task_semaphore(task_name)
            if task_sem:
                if self._block_on_limit:
                    if self._timeout:
                        remaining = self._timeout - (time.monotonic() - wait_start)
                        if remaining <= 0:
                            raise ConcurrencyLimitExceeded(
                                f"Timeout waiting for concurrency slot: {task_name}"
                            )
                        acquired = task_sem.acquire(timeout=remaining)
                    else:
                        task_sem.acquire()
                    acquired = True
                else:
                    acquired = task_sem.acquire(blocking=False)
                    if not acquired:
                        raise ConcurrencyLimitExceeded(
                            f"No concurrency slot available for {task_name}"
                        )

            # Acquire global semaphore if configured
            if self._global_semaphore:
                if self._block_on_limit:
                    if self._timeout:
                        remaining = self._timeout - (time.monotonic() - wait_start)
                        if remaining <= 0:
                            raise ConcurrencyLimitExceeded(
                                f"Timeout waiting for global concurrency slot"
                            )
                        self._global_semaphore.acquire(timeout=remaining)
                    else:
                        self._global_semaphore.acquire()
                else:
                    if not self._global_semaphore.acquire(blocking=False):
                        raise ConcurrencyLimitExceeded(
                            "No global concurrency slot available"
                        )

            with self._lock:
                self._active_counts[task_name] += 1
                self._total_active += 1

        except Exception:
            # Release task semaphore if global was not acquired
            if acquired and task_sem:
                task_sem.release()
            raise

    def after_task(self, ctx: Any, result: Any) -> None:
        task_name = ctx.task.task_name

        with self._lock:
            self._active_counts[task_name] = max(0, self._active_counts[task_name] - 1)
            self._total_active = max(0, self._total_active - 1)

        # Release semaphores
        task_sem = self._get_task_semaphore(task_name)
        if task_sem:
            task_sem.release()

        if self._global_semaphore:
            self._global_semaphore.release()

    def _get_task_semaphore(self, task_name: str) -> Optional[threading.Semaphore]:
        with self._lock:
            return self._task_semaphores.get(task_name)

    def get_active_count(self, task_name: Optional[str] = None) -> int:
        with self._lock:
            if task_name:
                return self._active_counts.get(task_name, 0)
            return self._total_active

    def get_stats(self) -> dict:
        with self._lock:
            return {
                "global_active": self._total_active,
                "global_limit": self._global_limit,
                "per_task": {
                    name: {
                        "active": self._active_counts.get(name, 0),
                        "limit": limit,
                    }
                    for name, limit in self._per_task_limits.items()
                },
            }


class ConcurrencyLimitExceeded(Exception):
    """Raised when a task cannot acquire a concurrency slot."""


# ---------------------------------------------------------------------------
# Resource Quota Middleware
# ---------------------------------------------------------------------------

class ResourceType(Enum):
    MEMORY = "memory"
    CPU = "cpu"
    DISK = "disk"
    NETWORK = "network"
    CUSTOM = "custom"


@dataclass
class ResourceQuota:
    """Defines a quota for a resource type."""
    quota: float
    unit: str = ""
    reset_window: Optional[float] = None  # seconds
    block_on_exhausted: bool = True
    timeout: Optional[float] = None


class ResourceQuotaMiddleware:
    """
    Enforces resource quotas for task execution.

    Tracks resource usage per task and can block or reject tasks
    that would exceed their allocated quota.
    """

    def __init__(
        self,
        quotas: Dict[str, ResourceQuota],
        resource_estimator: Optional[Callable[[str, Any], Dict[str, float]]] = None,
    ) -> None:
        self._quotas = quotas
        self._estimator = resource_estimator or self._default_estimator
        self._lock = threading.Lock()
        self._usage: Dict[str, Dict[str, Tuple[float, float]]] = defaultdict(
            lambda: defaultdict(lambda: (0.0, 0.0))  # (current, peak)
        )
        self._windows: Dict[str, Dict[str, float]] = defaultdict(
            lambda: defaultdict(float)  # window start times
        )

    def _default_estimator(self, task_name: str, ctx: Any) -> Dict[str, float]:
        """Estimate resource usage based on task metadata."""
        return {
            "memory": 100 * 1024 * 1024,  # 100 MB default
            "cpu": 1.0,
        }

    def before_task(self, ctx: Any) -> None:
        task_name = ctx.task.task_name
        estimated = self._estimator(task_name, ctx)
        current_time = time.monotonic()

        with self._lock:
            for resource, amount in estimated.items():
                if resource not in self._quotas:
                    continue

                quota = self._quotas[resource]
                usage_key = f"{task_name}:{resource}"

                # Check window reset
                window_start = self._windows[usage_key]
                if quota.reset_window:
                    elapsed = current_time - window_start
                    if elapsed >= quota.reset_window:
                        self._usage[usage_key][resource] = (0.0, 0.0)
                        window_start = current_time

                current, peak = self._usage[usage_key][resource]

                if current + amount > quota.quota:
                    if quota.block_on_exhausted:
                        raise ResourceQuotaExceeded(
                            f"Quota exceeded for {resource} in {task_name}. "
                            f"Used {current}, requested {amount}, quota {quota.quota}"
                        )
                    else:
                        logger.warning(
                            f"Resource {resource} quota exceeded for {task_name}, "
                            f"but allowing execution"
                        )

    def after_task(self, ctx: Any, result: Any) -> None:
        task_name = ctx.task.task_name
        actual = self._estimator(task_name, ctx)

        with self._lock:
            for resource, amount in actual.items():
                if resource not in self._quotas:
                    continue

                usage_key = f"{task_name}:{resource}"
                current, peak = self._usage[usage_key][resource]
                new_current = current + amount
                new_peak = max(peak, new_current)
                self._usage[usage_key][resource] = (new_current, new_peak)

    def get_usage(self, task_name: str, resource: str) -> Tuple[float, float]:
        with self._lock:
            usage_key = f"{task_name}:{resource}"
            return self._usage[usage_key].get(resource, (0.0, 0.0))

    def reset_usage(self, task_name: Optional[str] = None) -> None:
        with self._lock:
            if task_name:
                self._usage[task_name].clear()
            else:
                self._usage.clear()


class ResourceQuotaExceeded(Exception):
    """Raised when a task exceeds its resource quota."""


# ---------------------------------------------------------------------------
# Alert Middleware
# ---------------------------------------------------------------------------

class AlertLevel(Enum):
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


@dataclass
class AlertRule:
    """Defines a rule for triggering alerts."""
    name: str
    condition: Callable[[Any, Any, Optional[Exception]], bool]
    level: AlertLevel
    message_template: str
    cooldown_seconds: float = 0.0
    max_per_window: Optional[int] = None
    window_seconds: float = 60.0


@dataclass
class Alert:
    """Represents an alert notification."""
    rule_name: str
    level: AlertLevel
    message: str
    task_name: str
    task_id: str
    timestamp: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)


AlertCallback = Callable[[Alert], None]


class AlertMiddleware:
    """
    Monitors task execution and triggers alerts based on rules.

    Supports multiple alert channels via callbacks and implements
    cooldown/windowing to prevent alert storms.
    """

    def __init__(
        self,
        rules: Optional[List[AlertRule]] = None,
        default_cooldown: float = 60.0,
    ) -> None:
        self._rules = rules or []
        self._default_cooldown = default_cooldown
        self._lock = threading.Lock()
        self._callbacks: List[AlertCallback] = []
        self._last_alerts: Dict[str, float] = defaultdict(float)
        self._alert_counts: Dict[str, int] = defaultdict(int)
        self._alert_history: deque = deque(maxlen=1000)

    def add_rule(self, rule: AlertRule) -> None:
        self._rules.append(rule)

    def remove_rule(self, name: str) -> None:
        self._rules = [r for r in self._rules if r.name != name]

    def on_alert(self, callback: AlertCallback) -> None:
        self._callbacks.append(callback)

    def before_task(self, ctx: Any) -> None:
        pass  # Alerts are triggered after task completion

    def after_task(self, ctx: Any, result: Any) -> None:
        self._check_rules(ctx, result, None)

    def on_error(self, ctx: Any, exc: Exception) -> None:
        self._check_rules(ctx, None, exc)

    def _check_rules(
        self,
        ctx: Any,
        result: Any,
        error: Optional[Exception],
    ) -> None:
        for rule in self._rules:
            try:
                if not rule.condition(ctx, result, error):
                    continue

                if not self._should_fire(rule):
                    continue

                alert = Alert(
                    rule_name=rule.name,
                    level=rule.level,
                    message=rule.message_template.format(
                        task_name=ctx.task.task_name,
                        task_id=ctx.task.task_id,
                        elapsed=ctx.elapsed_seconds,
                        attempt=ctx.task.attempt,
                        error=str(error) if error else None,
                        status=result.status.value if result else None,
                    ),
                    task_name=ctx.task.task_name,
                    task_id=ctx.task.task_id,
                    metadata={
                        "elapsed_seconds": ctx.elapsed_seconds,
                        "attempt": ctx.task.attempt,
                    },
                )

                self._fire_alert(alert)

            except Exception as e:
                logger.exception(f"Error checking alert rule {rule.name}: {e}")

    def _should_fire(self, rule: AlertRule) -> bool:
        current_time = time.time()
        key = rule.name

        # Check cooldown
        time_since_last = current_time - self._last_alerts[key]
        if time_since_last < rule.cooldown_seconds:
            return False

        # Check max per window
        if rule.max_per_window:
            count_key = f"{key}:{int(current_time / rule.window_seconds)}"
            if self._alert_counts[count_key] >= rule.max_per_window:
                return False

        return True

    def _fire_alert(self, alert: Alert) -> None:
        with self._lock:
            self._last_alerts[alert.rule_name] = alert.timestamp
            count_key = f"{alert.rule_name}:{int(alert.timestamp / alert.algorithm_seconds)}"
            self._alert_counts[count_key] += 1
            self._alert_history.append(alert)

        # Call callbacks
        for callback in self._callbacks:
            try:
                callback(alert)
            except Exception as e:
                logger.exception(f"Error in alert callback: {e}")

    def get_alert_history(self, limit: int = 100) -> List[Alert]:
        with self._lock:
            return list(self._alert_history)[-limit:]

    def get_alert_stats(self) -> dict:
        with self._lock:
            return {
                "total_alerts": len(self._alert_history),
                "by_level": {
                    level.value: sum(
                        1 for a in self._alert_history if a.level == level
                    )
                    for level in AlertLevel
                },
                "by_rule": {
                    name: sum(1 for a in self._alert_history if a.rule_name == name)
                    for name in set(a.rule_name for a in self._alert_history)
                },
            }


# Add missing attribute to Alert dataclass
Alert.algorithm_seconds = 60.0  # Default, will be overridden in usage


# ---------------------------------------------------------------------------
# Cache Middleware
# ---------------------------------------------------------------------------

@dataclass
class CacheEntry:
    """Represents a cached task result."""
    key: str
    value: Any
    created_at: float = field(default_factory=time.time)
    expires_at: Optional[float] = None
    hit_count: int = 0


class CacheMiddleware:
    """
    Caches task results based on task name and arguments.

    Supports TTL-based expiration, LRU eviction, and cache invalidation.
    """

    def __init__(
        self,
        max_size: int = 1000,
        default_ttl: float = 300.0,
        key_prefix: str = "taskflow:cache",
        enable_hits: bool = True,
    ) -> None:
        self._max_size = max_size
        self._default_ttl = default_ttl
        self._key_prefix = key_prefix
        self._enable_hits = enable_hits
        self._lock = threading.Lock()
        self._cache: Dict[str, CacheEntry] = {}
        self._access_order: deque = deque()
        self._hits: int = 0
        self._misses: int = 0

    def _make_key(self, task_name: str, args: tuple, kwargs: dict) -> str:
        """Generate a cache key from task name and arguments."""
        payload = json.dumps(
            {"n": task_name, "a": args, "k": kwargs},
            sort_keys=True,
            default=str,
        )
        hash_val = hashlib.sha256(payload.encode()).hexdigest()
        return f"{self._key_prefix}:{task_name}:{hash_val}"

    def _evict_if_needed(self) -> None:
        """Evict least recently used entries if cache is full."""
        while len(self._cache) >= self._max_size:
            if not self._access_order:
                break
            oldest_key = self._access_order.popleft()
            self._cache.pop(oldest_key, None)

    def get(self, task_name: str, args: tuple, kwargs: dict) -> Optional[Any]:
        """Get a cached result if available and not expired."""
        key = self._make_key(task_name, args, kwargs)
        current_time = time.time()

        with self._lock:
            entry = self._cache.get(key)
            if entry is None:
                self._misses += 1
                return None

            # Check expiration
            if entry.expires_at and current_time > entry.expires_at:
                del self._cache[key]
                self._misses += 1
                return None

            # Update access order and hit count
            entry.hit_count += 1
            self._hits += 1
            self._access_order.append(key)
            return copy.deepcopy(entry.value)

    def set(
        self,
        task_name: str,
        args: tuple,
        kwargs: dict,
        value: Any,
        ttl: Optional[float] = None,
    ) -> None:
        """Cache a task result."""
        key = self._make_key(task_name, args, kwargs)
        expires_at = time.time() + (ttl or self._default_ttl)

        with self._lock:
            self._evict_if_needed()
            self._cache[key] = CacheEntry(
                key=key,
                value=value,
                expires_at=expires_at,
            )
            self._access_order.append(key)

    def invalidate(self, task_name: Optional[str] = None) -> int:
        """Invalidate cache entries. If task_name is None, clear all."""
        count = 0
        with self._lock:
            if task_name:
                keys_to_remove = [
                    k for k in self._cache if k.startswith(f"{self._key_prefix}:{task_name}:")
                ]
                for key in keys_to_remove:
                    self._cache.pop(key, None)
                    count += 1
            else:
                count = len(self._cache)
                self._cache.clear()
                self._access_order.clear()
        return count

    def get_stats(self) -> dict:
        with self._lock:
            total = self._hits + self._misses
            hit_rate = self._hits / total if total > 0 else 0.0
            return {
                "size": len(self._cache),
                "max_size": self._max_size,
                "hits": self._hits,
                "misses": self._misses,
                "hit_rate": hit_rate,
                "total_requests": total,
            }


# ---------------------------------------------------------------------------
# Transaction Middleware
# ---------------------------------------------------------------------------

class TransactionMode(Enum):
    """Transaction isolation modes."""
    AUTO = "auto"  # Auto-commit when no error
    MANUAL = "manual"  # Require explicit commit/rollback
    COMPENSATING = "compensating"  # Execute compensating actions on failure


@dataclass
class CompensatingAction:
    """Defines a compensating action for rollback."""
    name: str
    func: Callable[[], Any]
    order: int = 0


class TaskTransaction:
    """Represents an active task transaction."""

    def __init__(self, task_id: str, mode: TransactionMode = TransactionMode.AUTO) -> None:
        self.task_id = task_id
        self.mode = mode
        self._started_at: Optional[float] = None
        self._committed: bool = False
        self._rolled_back: bool = False
        self._actions: List[CompensatingAction] = []
        self._results: Dict[str, Any] = {}
        self._lock = threading.Lock()

    def start(self) -> None:
        self._started_at = time.time()

    def add_result(self, key: str, value: Any) -> None:
        with self._lock:
            self._results[key] = value

    def get_result(self, key: str, default: Any = None) -> Any:
        with self._lock:
            return self._results.get(key, default)

    def add_compensating_action(self, action: CompensatingAction) -> None:
        self._actions.append(action)
        self._actions.sort(key=lambda a: a.order)

    def commit(self) -> None:
        with self._lock:
            self._committed = True

    def rollback(self) -> List[Exception]:
        """Execute compensating actions in reverse order."""
        errors = []
        with self._lock:
            if self._rolled_back:
                return errors
            self._rolled_back = True

        for action in reversed(self._actions):
            try:
                action.func()
            except Exception as e:
                errors.append(e)
                logger.error(f"Compensating action '{action.name}' failed: {e}")

        return errors

    @property
    def is_active(self) -> bool:
        return self._started_at is not None and not self._committed and not self._rolled_back

    @property
    def elapsed_seconds(self) -> float:
        if not self._started_at:
            return 0.0
        return time.time() - self._started_at


class TransactionContext:
    """Thread-local transaction context."""

    _local = threading.local()

    @classmethod
    def get_current(cls) -> Optional[TaskTransaction]:
        return getattr(cls._local, "transaction", None)

    @classmethod
    def set_current(cls, transaction: Optional[TaskTransaction]) -> None:
        cls._local.transaction = transaction


class TransactionMiddleware:
    """
    Provides transaction support for task execution.

    Supports automatic rollback via compensating actions and
    transaction context propagation.
    """

    def __init__(
        self,
        default_mode: TransactionMode = TransactionMode.AUTO,
        enable_nesting: bool = False,
    ) -> None:
        self._default_mode = default_mode
        self._enable_nesting = enable_nesting
        self._lock = threading.Lock()
        self._transaction_stats: Dict[str, int] = defaultdict(int)

    def before_task(self, ctx: Any) -> None:
        mode = getattr(ctx.task, "transaction_mode", None) or self._default_mode
        transaction = TaskTransaction(ctx.task.task_id, TransactionMode(mode))
        transaction.start()
        TransactionContext.set_current(transaction)

    def after_task(self, ctx: Any, result: Any) -> None:
        transaction = TransactionContext.get_current()
        if not transaction:
            return

        try:
            with self._lock:
                self._transaction_stats["total"] += 1

            if transaction.is_active:
                from taskflow.core.models import TaskStatus
                if result and result.status == TaskStatus.SUCCESS:
                    if transaction.mode == TransactionMode.AUTO:
                        transaction.commit()
                        with self._lock:
                            self._transaction_stats["committed"] += 1
                else:
                    if transaction.mode != TransactionMode.MANUAL:
                        errors = transaction.rollback()
                        with self._lock:
                            self._transaction_stats["rolled_back"] += 1
                        if errors:
                            logger.warning(
                                f"Transaction rollback had {len(errors)} errors for {transaction.task_id}"
                            )

        finally:
            TransactionContext.set_current(None)

    def on_error(self, ctx: Any, exc: Exception) -> None:
        transaction = TransactionContext.get_current()
        if transaction and transaction.mode != TransactionMode.MANUAL:
            errors = transaction.rollback()
            with self._lock:
                self._transaction_stats["rolled_back"] += 1
            if errors:
                logger.warning(f"Transaction rollback had {len(errors)} errors")

    def get_stats(self) -> dict:
        with self._lock:
            total = self._transaction_stats.get("total", 0)
            committed = self._transaction_stats.get("committed", 0)
            rolled_back = self._transaction_stats.get("rolled_back", 0)
            return {
                "total": total,
                "committed": committed,
                "rolled_back": rolled_back,
                "commit_rate": committed / total if total > 0 else 0.0,
            }


# ---------------------------------------------------------------------------
# Priority Boost Middleware
# ---------------------------------------------------------------------------

class PriorityBoostMiddleware:
    """
    Dynamically boosts task priority based on waiting time.

    Prevents starvation of low-priority tasks that have been waiting
    in the queue for too long.
    """

    def __init__(
        self,
        max_boost_factor: float = 4.0,
        boost_threshold_seconds: float = 300.0,
        boost_interval_seconds: float = 60.0,
    ) -> None:
        self._max_boost_factor = max_boost_factor
        self._boost_threshold = boost_threshold_seconds
        self._boost_interval = boost_interval_seconds
        self._lock = threading.Lock()
        self._boost_history: Dict[str, float] = {}

    def before_task(self, ctx: Any) -> None:
        """Apply priority boost based on waiting time."""
        from taskflow.core.models import Priority

        if ctx.task.enqueued_at is None:
            return

        waiting_time = time.time() - ctx.task.enqueued_at
        if waiting_time < self._boost_threshold:
            return

        # Calculate boost factor
        boost_periods = (waiting_time - self._boost_threshold) / self._boost_interval
        boost_factor = min(1.0 + boost_periods, self._max_boost_factor)

        if boost_factor > 1.0:
            task_id = ctx.task.task_id
            original_priority = ctx.task.priority

            # Boost priority
            if ctx.task.priority < Priority.HIGH:
                new_priority_value = int(
                    original_priority.value * boost_factor
                )
                new_priority_value = min(new_priority_value, Priority.CRITICAL.value)
                ctx.task.priority = Priority(new_priority_value)

            with self._lock:
                self._boost_history[task_id] = boost_factor

            logger.info(
                f"Priority boost applied to {ctx.task.task_name}: "
                f"waiting={waiting_time:.1f}s, factor={boost_factor:.1f}"
            )

    def get_boost_stats(self) -> dict:
        with self._lock:
            return {
                "boosted_tasks": len(self._boost_history),
                "avg_boost_factor": sum(self._boost_history.values())
                / len(self._boost_history)
                if self._boost_history
                else 0.0,
            }


# ---------------------------------------------------------------------------
# SLA Monitor Middleware
# ---------------------------------------------------------------------------

@dataclass
class SLADefinition:
    """Defines an SLA requirement for a task or group."""
    name: str
    task_pattern: str  # regex pattern to match task names
    max_duration_seconds: float
    warning_threshold: float = 0.8  # trigger warning at 80% of SLA
    action: Callable[[str, float, float], None] = None  # callback on breach


class SLAMonitorMiddleware:
    """
    Monitors task execution against SLA definitions.

    Tracks SLA compliance and can trigger callbacks or alerts
    when SLA thresholds are at risk or breached.
    """

    def __init__(
        self,
        slas: Optional[List[SLADefinition]] = None,
        on_warning: Optional[Callable[[Alert], None]] = None,
        on_breach: Optional[Callable[[Alert], None]] = None,
    ) -> None:
        self._slas = {sla.name: sla for sla in (slas or [])}
        self._on_warning = on_warning
        self._on_breach = on_breach
        self._lock = threading.Lock()
        self._violations: Dict[str, int] = defaultdict(int)
        self._warnings: Dict[str, int] = defaultdict(int)

    def add_sla(self, sla: SLADefinition) -> None:
        self._slas[sla.name] = sla

    def remove_sla(self, name: str) -> None:
        self._slas.pop(name, None)

    def before_task(self, ctx: Any) -> None:
        pass

    def after_task(self, ctx: Any, result: Any) -> None:
        self._check_sla(ctx, result, None)

    def on_error(self, ctx: Any, exc: Exception) -> None:
        self._check_sla(ctx, None, exc)

    def _check_sla(
        self,
        ctx: Any,
        result: Any,
        error: Optional[Exception],
    ) -> None:
        import re

        for sla in self._slas.values():
            if not re.match(sla.task_pattern, ctx.task.task_name):
                continue

            elapsed = ctx.elapsed_seconds
            max_duration = sla.max_duration_seconds
            warning_threshold = sla.warning_threshold

            # Check warning threshold
            if elapsed >= max_duration * warning_threshold and elapsed < max_duration:
                with self._lock:
                    self._warnings[sla.name] += 1

                alert = Alert(
                    rule_name=f"{sla.name}_warning",
                    level=AlertLevel.WARNING,
                    message=f"SLA warning for {ctx.task.task_name}: "
                    f"{elapsed:.1f}s / {max_duration}s ({elapsed/max_duration*100:.0f}%)",
                    task_name=ctx.task.task_name,
                    task_id=ctx.task.task_id,
                    metadata={"sla": sla.name, "elapsed": elapsed},
                )

                if self._on_warning:
                    self._on_warning(alert)

            # Check breach
            elif elapsed >= max_duration:
                with self._lock:
                    self._violations[sla.name] += 1

                alert = Alert(
                    rule_name=f"{sla.name}_breach",
                    level=AlertLevel.ERROR,
                    message=f"SLA breach for {ctx.task.task_name}: "
                    f"{elapsed:.1f}s > {max_duration}s",
                    task_name=ctx.task.task_name,
                    task_id=ctx.task.task_id,
                    metadata={"sla": sla.name, "elapsed": elapsed},
                )

                if self._on_breach:
                    self._on_breach(alert)

                if sla.action:
                    sla.action(ctx.task.task_name, elapsed, max_duration)

    def get_sla_stats(self) -> dict:
        with self._lock:
            return {
                "violations": dict(self._violations),
                "warnings": dict(self._warnings),
            }


# ---------------------------------------------------------------------------
# Metrics Middleware
# ---------------------------------------------------------------------------

class MetricsMiddleware(BaseMiddleware):
    """
    Collects detailed metrics for task execution.

    Tracks success/failure rates, execution times, queue times,
    and resource usage for each task type.
    """

    def __init__(
        self,
        window_size: int = 10000,
        quantiles: List[float] = None,
    ) -> None:
        from taskflow.middleware.base import BaseMiddleware

        class _BaseMiddleware(BaseMiddleware):
            pass

        self._base = _BaseMiddleware()
        self._window_size = window_size
        self._quantiles = quantiles or [0.5, 0.9, 0.95, 0.99]
        self._lock = threading.Lock()

        # Metrics storage
        self._durations: Dict[str, deque] = defaultdict(
            lambda: deque(maxlen=window_size)
        )
        self._queue_times: Dict[str, deque] = defaultdict(
            lambda: deque(maxlen=window_size)
        )
        self._success_counts: Dict[str, int] = defaultdict(int)
        self._failure_counts: Dict[str, int] = defaultdict(int)
        self._error_types: Dict[str, Dict[str, int]] = defaultdict(
            lambda: defaultdict(int)
        )

    def before_task(self, ctx: Any) -> None:
        pass

    def after_task(self, ctx: Any, result: Any) -> None:
        from taskflow.core.models import TaskStatus

        task_name = ctx.task.task_name
        duration = ctx.elapsed_seconds

        with self._lock:
            self._durations[task_name].append(duration)

            # Track queue time if available
            if ctx.task.enqueued_at:
                queue_time = ctx.started_at - ctx.task.enqueued_at
                self._queue_times[task_name].append(queue_time)

            # Track success/failure
            if result.status == TaskStatus.SUCCESS:
                self._success_counts[task_name] += 1
            else:
                self._failure_counts[task_name] += 1

    def on_error(self, ctx: Any, exc: Exception) -> None:
        task_name = ctx.task.task_name
        error_type = type(exc).__name__

        with self._lock:
            self._failure_counts[task_name] += 1
            self._error_types[task_name][error_type] += 1

    def _compute_percentiles(self, values: List[float]) -> Dict[str, float]:
        if not values:
            return {}

        sorted_values = sorted(values)
        n = len(sorted_values)
        return {
            f"p{int(q * 100)}": sorted_values[min(int(n * q), n - 1)]
            for q in self._quantiles
        }

    def get_metrics(self, task_name: Optional[str] = None) -> dict:
        with self._lock:
            if task_name:
                return self._compute_task_metrics(task_name)

            return {
                name: self._compute_task_metrics(name)
                for name in self._durations.keys()
            }

    def _compute_task_metrics(self, task_name: str) -> dict:
        durations = list(self._durations.get(task_name, []))
        queue_times = list(self._queue_times.get(task_name, []))
        successes = self._success_counts.get(task_name, 0)
        failures = self._failure_counts.get(task_name, 0)
        total = successes + failures
        error_types = dict(self._error_types.get(task_name, {}))

        if not total:
            return {"task": task_name, "count": 0}

        return {
            "task": task_name,
            "count": total,
            "successes": successes,
            "failures": failures,
            "success_rate": successes / total,
            "error_types": error_types,
            "duration": self._compute_percentiles(durations),
            "queue_time": self._compute_percentiles(queue_times),
        }


# Import BaseMiddleware for inheritance
from taskflow.middleware.base import BaseMiddleware
