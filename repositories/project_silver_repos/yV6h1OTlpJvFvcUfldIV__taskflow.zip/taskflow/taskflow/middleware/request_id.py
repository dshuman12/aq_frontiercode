"""
Middleware that generates or propagates a request-id header
through task execution for distributed tracing.
"""
from __future__ import annotations
import uuid, logging
from taskflow.core.context import get_current

logger = logging.getLogger(__name__)

class RequestIdMiddleware:
    """Assigns a unique request_id to each task execution."""

    def __init__(self, header: str = "x-request-id") -> None:
        self.header = header

    def before_task(self, task, **kwargs) -> None:
        ctx = get_current()
        if ctx is not None:
            existing = task.kwargs.get(self.header)
            request_id = existing or str(uuid.uuid4())
            ctx.set("request_id", request_id)
            logger.debug("Task %s request_id=%s", task.task_id, request_id)

    def after_task(self, task, result, **kwargs) -> None:
        pass

    def on_failure(self, task, exc, **kwargs) -> None:
        ctx = get_current()
        rid = ctx.get("request_id") if ctx else "unknown"
        logger.error("Task %s (request_id=%s) failed: %s", task.task_id, rid, exc)
