"""
Advanced CLI commands for taskflow.

Extends the basic CLI with additional commands for monitoring,
debugging, and administrative tasks.
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

import questionary

from taskflow.core.models import Priority, TaskStatus


def setup_logging(verbose: bool = False, quiet: bool = False) -> None:
    """Configure logging for CLI."""
    if quiet:
        level = logging.ERROR
    elif verbose:
        level = logging.DEBUG
    else:
        level = logging.INFO

    logging.basicConfig(
        level=level,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )


def create_parser() -> argparse.ArgumentParser:
    """Create the main argument parser."""
    parser = argparse.ArgumentParser(
        prog="taskflow",
        description="TaskFlow - Distributed Task Queue CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    parser.add_argument("-v", "--verbose", action="store_true", help="Enable verbose output")
    parser.add_argument("-q", "--quiet", action="store_true", help="Suppress output")
    parser.add_argument("--config", type=Path, help="Path to configuration file")

    sub = parser.add_subparsers(dest="command", help="Command to execute")

    # Worker command
    _add_worker_command(sub)

    # Inspect command
    _add_inspect_command(sub)

    # List command
    _add_list_command(sub)

    # Queue commands
    _add_queue_commands(sub)

    # Task commands
    _add_task_commands(sub)

    # Stats command
    _add_stats_command(sub)

    # Monitor command
    _add_monitor_command(sub)

    # Config command
    _add_config_command(sub)

    # Server command
    _add_server_command(sub)

    # Shell command
    _add_shell_command(sub)

    # Worker pool command
    _add_pool_command(sub)

    return parser


def _add_worker_command(sub: argparse._SubParsersAction) -> None:
    """Add worker command."""
    worker = sub.add_parser("worker", help="Start a task worker")
    worker.add_argument("--queues", "-q", nargs="+", default=["default"], help="Queues to consume")
    worker.add_argument("-c", "--concurrency", type=int, default=4, help="Concurrency level")
    worker.add_argument("--backend", default="memory", choices=["memory", "sqlite", "redis"], help="Backend type")
    worker.add_argument("--host", default="localhost", help="Redis host")
    worker.add_argument("--port", type=int, default=6379, help="Redis port")
    worker.add_argument("--db", type=int, default=0, help="Redis database")
    worker.add_argument("--db-path", default="taskflow.db", help="SQLite database path")
    worker.add_argument("--poll-interval", type=float, default=0.5, help="Poll interval")
    worker.add_argument("--health-port", type=int, help="Health server port")
    worker.add_argument("--log-level", default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    worker.add_argument("--daemon", action="store_true", help="Run as daemon")
    worker.add_argument("--pid-file", type=Path, help="PID file path")


def _add_inspect_command(sub: argparse._SubParsersAction) -> None:
    """Add inspect command."""
    inspect = sub.add_parser("inspect", help="Inspect tasks and queues")
    inspect.add_argument("--task-id", help="Specific task ID")
    inspect.add_argument("--queue", help="Filter by queue")
    inspect.add_argument("--status", help="Filter by status")
    inspect.add_argument("--limit", type=int, default=20, help="Result limit")
    inspect.add_argument("--format", choices=["table", "json", "csv"], default="table")
    inspect.add_argument("--watch", action="store_true", help="Watch mode")
    inspect.add_argument("--interval", type=float, default=2.0, help="Watch interval")


def _add_list_command(sub: argparse._SubParsersAction) -> None:
    """Add list command."""
    list_cmd = sub.add_parser("list", help="List tasks, queues, or workers")
    list_cmd.add_argument("what", choices=["tasks", "queues", "workers", "tasks-by-status"], help="What to list")
    list_cmd.add_argument("--queue", help="Filter tasks by queue")
    list_cmd.add_argument("--status", help="Filter by status")
    list_cmd.add_argument("--limit", type=int, default=50)
    list_cmd.add_argument("--format", choices=["table", "json"], default="table")
    list_cmd.add_argument("--sort", choices=["created", "status", "priority", "name"], default="created")
    list_cmd.add_argument("--reverse", action="store_true", help="Reverse sort order")


def _add_queue_commands(sub: argparse._SubParsersAction) -> None:
    """Add queue management commands."""
    queue = sub.add_parser("queue", help="Manage queues")
    queue_sub = queue.add_subparsers(dest="queue_action", help="Queue action")

    # Queue create
    q_create = queue_sub.add_parser("create", help="Create a queue")
    q_create.add_argument("name", help="Queue name")
    q_create.add_argument("--max-concurrency", type=int, help="Max concurrent tasks")
    q_create.add_argument("--tags", nargs="+", help="Queue tags")

    # Queue pause/resume
    q_pause = queue_sub.add_parser("pause", help="Pause a queue")
    q_pause.add_argument("name", help="Queue name")

    q_resume = queue_sub.add_parser("resume", help="Resume a queue")
    q_resume.add_argument("name", help="Queue name")

    # Queue purge
    q_purge = queue_sub.add_parser("purge", help="Purge a queue")
    q_purge.add_argument("name", help="Queue name")
    q_purge.add_argument("--force", "-f", action="store_true", help="Skip confirmation")

    # Queue stats
    q_stats = queue_sub.add_parser("stats", help="Show queue statistics")
    q_stats.add_argument("name", nargs="?", help="Queue name (omit for all)")
    q_stats.add_argument("--history", action="store_true", help="Include historical stats")

    # Queue drain
    q_drain = queue_sub.add_parser("drain", help="Drain a queue (close but process remaining)")
    q_drain.add_argument("name", help="Queue name")


def _add_task_commands(sub: argparse._SubParsersAction) -> None:
    """Add task management commands."""
    task = sub.add_parser("task", help="Manage tasks")
    task_sub = task.add_subparsers(dest="task_action", help="Task action")

    # Task submit
    t_submit = task_sub.add_parser("submit", help="Submit a new task")
    t_submit.add_argument("task_name", help="Task function name")
    t_submit.add_argument("--args", nargs="*", help="Positional arguments")
    t_submit.add_argument("--kwargs", help="Keyword arguments as JSON")
    t_submit.add_argument("--queue", default="default", help="Target queue")
    t_submit.add_argument("--priority", type=int, default=2, help="Priority (0-4)")
    t_submit.add_argument("--delay", type=float, help="Delay execution by seconds")
    t_submit.add_argument("--timeout", type=float, help="Task timeout in seconds")
    t_submit.add_argument("--expires", type=float, help="Task expires in seconds")

    # Task revoke
    t_revoke = task_sub.add_parser("revoke", help="Revoke a task")
    t_revoke.add_argument("task_id", help="Task ID")
    t_revoke.add_argument("--terminate", action="store_true", help="Terminate if running")

    # Task result
    t_result = task_sub.add_parser("result", help="Get task result")
    t_result.add_argument("task_id", help="Task ID")
    t_result.add_argument("--wait", type=float, help="Wait for result")
    t_result.add_argument("--timeout", type=float, default=60.0, help="Max wait time")

    # Task cancel
    t_cancel = task_sub.add_parser("cancel", help="Cancel pending task")
    t_cancel.add_argument("task_id", help="Task ID")

    # Task retry
    t_retry = task_sub.add_parser("retry", help="Retry a failed task")
    t_retry.add_argument("task_id", help="Task ID")

    # Task info
    t_info = task_sub.add_parser("info", help="Get task information")
    t_info.add_argument("task_id", help="Task ID")


def _add_stats_command(sub: argparse._SubParsersAction) -> None:
    """Add statistics command."""
    stats = sub.add_parser("stats", help="Show statistics")
    stats.add_argument("--type", choices=["global", "queue", "worker", "task"], default="global")
    stats.add_argument("--name", help="Specific queue/worker name")
    stats.add_argument("--period", type=int, default=3600, help="Time period in seconds")
    stats.add_argument("--format", choices=["table", "json"], default="table")
    stats.add_argument("--since", help="Start time (ISO format)")


def _add_monitor_command(sub: argparse._SubParsersAction) -> None:
    """Add monitor command."""
    monitor = sub.add_parser("monitor", help="Monitor taskflow in real-time")
    monitor.add_argument("--queue", help="Monitor specific queue")
    monitor.add_argument("--interval", type=float, default=1.0, help="Update interval")
    monitor.add_argument("--events", nargs="+", choices=["enqueued", "dequeued", "started", "completed", "failed"], help="Event types to monitor")


def _add_config_command(sub: argparse._SubParsersAction) -> None:
    """Add config command."""
    config = sub.add_parser("config", help="Manage configuration")
    config_sub = config.add_subparsers(dest="config_action")

    # Config show
    c_show = config_sub.add_parser("show", help="Show current configuration")
    c_show.add_argument("--key", help="Specific key")
    c_show.add_argument("--format", choices=["table", "json", "env"], default="table")

    # Config set
    c_set = config_sub.add_parser("set", help="Set a configuration value")
    c_set.add_argument("key", help="Configuration key")
    c_set.add_argument("value", help="Configuration value")

    # Config get
    c_get = config_sub.add_parser("get", help="Get a configuration value")
    c_get.add_argument("key", help="Configuration key")

    # Config validate
    c_validate = config_sub.add_parser("validate", help="Validate configuration")
    c_validate.add_argument("--file", type=Path, help="Config file to validate")


def _add_server_command(sub: argparse._SubParsersAction) -> None:
    """Add server command."""
    server = sub.add_parser("server", help="Start web server")
    server.add_argument("--host", default="0.0.0.0", help="Host to bind")
    server.add_argument("--port", type=int, default=8000, help="Port to bind")
    server.add_argument("--workers", type=int, default=1, help="Number of workers")
    server.add_argument("--api-key", help="API authentication key")
    server.add_argument("--no-dashboard", action="store_true", help="Disable dashboard")
    server.add_argument("--log-level", default="info")


def _add_shell_command(sub: argparse._SubParsersAction) -> None:
    """Add interactive shell command."""
    shell = sub.add_parser("shell", help="Interactive taskflow shell")
    shell.add_argument("--backend", default="memory")
    shell.add_argument("--exec", help="Execute command and exit")


def _add_pool_command(sub: argparse._SubParsersAction) -> None:
    """Add worker pool command."""
    pool = sub.add_parser("pool", help="Manage worker pools")
    pool_sub = pool.add_subparsers(dest="pool_action")

    # Pool status
    p_status = pool_sub.add_parser("status", help="Show pool status")
    p_status.add_argument("--name", help="Pool name")

    # Pool scale
    p_scale = pool_sub.add_parser("scale", help="Scale a pool")
    p_scale.add_argument("name", help="Pool name")
    p_scale.add_argument("workers", type=int, help="Number of workers")


def execute_command(args: argparse.Namespace) -> int:
    """Execute the specified command."""
    setup_logging(args.verbose, args.quiet)

    if args.command == "worker":
        return cmd_worker(args)
    elif args.command == "inspect":
        return cmd_inspect(args)
    elif args.command == "list":
        return cmd_list(args)
    elif args.command == "queue":
        return cmd_queue(args)
    elif args.command == "task":
        return cmd_task(args)
    elif args.command == "stats":
        return cmd_stats(args)
    elif args.command == "monitor":
        return cmd_monitor(args)
    elif args.command == "config":
        return cmd_config(args)
    elif args.command == "server":
        return cmd_server(args)
    elif args.command == "shell":
        return cmd_shell(args)
    elif args.command == "pool":
        return cmd_pool(args)
    else:
        print("Unknown command. Use --help for usage.")
        return 1


def _get_backend(args: argparse.Namespace) -> Any:
    """Create backend instance based on args."""
    if args.backend == "redis":
        from taskflow.backends.redis_backend import RedisBackend, RedisConnectionConfig
        config = RedisConnectionConfig(
            host=getattr(args, "host", "localhost"),
            port=getattr(args, "port", 6379),
            db=getattr(args, "db", 0),
        )
        return RedisBackend(config=config)
    elif args.backend == "sqlite":
        from taskflow.backends.sqlite import SQLiteBackend
        db_path = getattr(args, "db_path", "taskflow.db")
        return SQLiteBackend(db_path=db_path)
    else:
        from taskflow.backends.memory import MemoryBackend
        return MemoryBackend()


def cmd_worker(args: argparse.Namespace) -> int:
    """Execute worker command."""
    from taskflow.workers.worker import Worker

    backend = _get_backend(args)

    if args.daemon:
        import daemon
        with daemon.DaemonContext():
            _run_worker(backend, args)
    else:
        _run_worker(backend, args)

    return 0


def _run_worker(backend: Any, args: argparse.Namespace) -> None:
    """Internal worker runner."""
    from taskflow.workers.worker import Worker

    if args.pid_file:
        args.pid_file.write_text(str(os.getpid()))

    worker = Worker(
        backend=backend,
        queues=args.queues,
        concurrency=args.concurrency,
        poll_interval=args.poll_interval,
    )

    try:
        worker.start(block=True)
    except KeyboardInterrupt:
        worker.stop()


def cmd_inspect(args: argparse.Namespace) -> int:
    """Execute inspect command."""
    backend = _get_backend(args)

    if args.task_id:
        task = backend.get_task(args.task_id)
        if task:
            print(json.dumps(task.to_dict(), indent=2, default=str))
        else:
            result = backend.get_result(args.task_id)
            if result:
                print(json.dumps(result.to_dict(), indent=2, default=str))
            else:
                print(f"Task '{args.task_id}' not found", file=sys.stderr)
                return 1
    else:
        status = TaskStatus(args.status) if args.status else None
        tasks = backend.list_tasks(
            queue_name=args.queue,
            status=status,
            limit=args.limit,
        )

        if args.format == "json":
            print(json.dumps([t.to_dict() for t in tasks], indent=2, default=str))
        else:
            print(f"{'ID':<36}  {'NAME':<30}  {'STATUS':<12}  {'QUEUE':<15}  {'ATTEMPTS':<8}")
            print("-" * 110)
            for t in tasks:
                print(f"{t.task_id:<36}  {t.task_name:<30}  {t.status.value:<12}  {t.queue_name:<15}  {t.attempt:<8}")

    return 0


def cmd_list(args: argparse.Namespace) -> int:
    """Execute list command."""
    backend = _get_backend(args)

    if args.what == "queues":
        queues = backend.all_queue_info()
        if args.format == "json":
            print(json.dumps([q.to_dict() for q in queues], indent=2))
        else:
            print(f"{'NAME':<20}  {'STATUS':<10}  {'PENDING':<10}  {'RUNNING':<10}  {'COMPLETED':<12}  {'FAILED':<10}")
            print("-" * 85)
            for q in queues:
                print(f"{q.name:<20}  {q.status.value:<10}  {q.pending_count:<10}  {q.running_count:<10}  {q.completed_count:<12}  {q.failed_count:<10}")

    elif args.what == "workers":
        if hasattr(backend, "get_active_workers"):
            workers = backend.get_active_workers()
            if args.format == "json":
                print(json.dumps(workers, indent=2))
            else:
                for w in workers:
                    print(f"Worker: {w.get('worker_id', 'unknown')}")
                    print(f"  Queues: {w.get('queues', [])}")
                    print(f"  Concurrency: {w.get('concurrency', 0)}")
                    print(f"  Last heartbeat: {w.get('last_heartbeat', 'never')}")
                    print()
        else:
            print("Workers not supported for this backend")
            return 1

    else:
        tasks = backend.list_tasks(
            queue_name=args.queue,
            limit=args.limit,
        )
        if args.status:
            status = TaskStatus(args.status)
            tasks = [t for t in tasks if t.status == status]

        if args.format == "json":
            print(json.dumps([t.to_dict() for t in tasks], indent=2, default=str))
        else:
            print(f"{'ID':<36}  {'NAME':<30}  {'STATUS':<12}  {'QUEUE':<15}")
            print("-" * 100)
            for t in tasks:
                print(f"{t.task_id:<36}  {t.task_name:<30}  {t.status.value:<12}  {t.queue_name:<15}")

    return 0


def cmd_queue(args: argparse.Namespace) -> int:
    """Execute queue command."""
    backend = _get_backend(args)

    action = args.queue_action

    if action == "create":
        backend.declare_queue(args.name, args.max_concurrency, args.tags)
        print(f"Queue '{args.name}' created")

    elif action == "pause":
        backend.pause_queue(args.name)
        print(f"Queue '{args.name}' paused")

    elif action == "resume":
        backend.resume_queue(args.name)
        print(f"Queue '{args.name}' resumed")

    elif action == "purge":
        if args.force or questionary.confirm(f"Purge all tasks from '{args.name}'?").ask():
            count = backend.purge_queue(args.name)
            print(f"Purged {count} tasks from '{args.name}'")

    elif action == "stats":
        if args.name:
            stats = backend.get_queue_stats(args.name)
            print(json.dumps(stats, indent=2, default=str))
        else:
            queues = backend.all_queue_info()
            for q in queues:
                print(f"Queue: {q.name}")
                print(f"  Status: {q.status.value}")
                print(f"  Pending: {q.pending_count}")
                print(f"  Completed: {q.completed_count}")
                print(f"  Failed: {q.failed_count}")
                print()

    elif action == "drain":
        backend.drain_queue(args.name)
        print(f"Queue '{args.name}' drained")

    return 0


def cmd_task(args: argparse.Namespace) -> int:
    """Execute task command."""
    backend = _get_backend(args)
    from taskflow.core.registry import get_registry

    action = args.task_action

    if action == "submit":
        from taskflow.core.models import Task

        registry = get_registry()
        try:
            registry.get(args.task_name)
        except Exception:
            print(f"Task '{args.task_name}' not found in registry", file=sys.stderr)
            return 1

        task = Task(
            task_name=args.task_name,
            args=list(args.args) if args.args else [],
            kwargs=json.loads(args.kwargs) if args.kwargs else {},
            queue_name=args.queue,
            priority=Priority.from_int(args.priority),
        )

        if args.delay:
            task.eta = datetime.now(timezone.utc) + timedelta(seconds=args.delay)
        if args.timeout:
            task.timeout_seconds = args.timeout
        if args.expires:
            task.expires_at = datetime.now(timezone.utc) + timedelta(seconds=args.expires)

        backend.enqueue(task)
        print(f"Task submitted: {task.task_id}")
        print(f"  Queue: {task.queue_name}")
        print(f"  Priority: {task.priority.name}")

    elif action == "revoke":
        ok = backend.revoke(args.task_id)
        if ok:
            print(f"Task '{args.task_id}' revoked")
        else:
            print(f"Task '{args.task_id}' not found or already terminal", file=sys.stderr)
            return 1

    elif action == "result":
        if args.wait:
            result = backend.wait_for_result(args.task_id, timeout=args.wait)
        else:
            result = backend.get_result(args.task_id)

        if result:
            print(json.dumps(result.to_dict(), indent=2, default=str))
        else:
            print(f"No result found for task '{args.task_id}'", file=sys.stderr)
            return 1

    elif action == "info":
        task = backend.get_task(args.task_id)
        if task:
            print(json.dumps(task.to_dict(), indent=2, default=str))
        else:
            print(f"Task '{args.task_id}' not found", file=sys.stderr)
            return 1

    return 0


def cmd_stats(args: argparse.Namespace) -> int:
    """Execute stats command."""
    backend = _get_backend(args)

    if args.type == "global":
        if hasattr(backend, "get_global_stats"):
            stats = backend.get_global_stats()
        else:
            queues = backend.all_queue_info()
            stats = {
                "queue_count": len(queues),
                "total_pending": sum(q.pending_count for q in queues),
                "total_completed": sum(q.completed_count for q in queues),
                "total_failed": sum(q.failed_count for q in queues),
            }
    elif args.type == "queue":
        if hasattr(backend, "get_queue_stats"):
            stats = backend.get_queue_stats(args.name)
        else:
            info = backend.queue_info(args.name)
            stats = info.to_dict() if info else {}
    else:
        stats = {}

    if args.format == "json":
        print(json.dumps(stats, indent=2, default=str))
    else:
        for key, value in stats.items():
            print(f"{key}: {value}")

    return 0


def cmd_monitor(args: argparse.Namespace) -> int:
    """Execute monitor command."""
    from taskflow.events.emitter import get_emitter, EventType

    emitter = get_emitter()

    print(f"Monitoring taskflow events (interval: {args.interval}s)")
    print("Press Ctrl+C to stop")
    print()

    def handler(event):
        print(f"[{event.timestamp.strftime('%H:%M:%S')}] {event.event_type.value}")
        if event.task_id:
            print(f"  Task: {event.task_id}")
        if event.queue_name:
            print(f"  Queue: {event.queue_name}")
        if event.worker_id:
            print(f"  Worker: {event.worker_id}")
        print()

    # Subscribe to events
    emitter.on(set(EventType), handler)

    try:
        while True:
            time.sleep(args.interval)
    except KeyboardInterrupt:
        pass

    return 0


def cmd_config(args: argparse.Namespace) -> int:
    """Execute config command."""
    from taskflow.config.settings import Config

    config = Config()
    if args.config:
        from taskflow.config.settings import YAMLSource
        config.add_source(YAMLSource(args.config))

    action = args.config_action

    if action == "show":
        if args.key:
            value = config.get(args.key)
            print(value)
        else:
            data = config.to_dict()
            if args.format == "json":
                print(json.dumps(data, indent=2))
            elif args.format == "env":
                for key, value in data.items():
                    print(f"TASKFLOW_{key.upper().replace('.', '_')}={value}")
            else:
                for key, value in data.items():
                    print(f"{key}: {value}")

    elif action == "get":
        value = config.get(args.key)
        print(value)

    elif action == "set":
        config.set(args.key, args.value)
        print(f"Set {args.key} = {args.value}")

    return 0


def cmd_server(args: argparse.Namespace) -> int:
    """Execute server command."""
    try:
        from taskflow.api.app import run_server
        from taskflow.core.registry import get_registry
    except ImportError as exc:
        print(f"Web server requires additional dependencies: {exc}", file=sys.stderr)
        return 1

    backend = _get_backend(args)
    registry = get_registry()

    run_server(
        backend=backend,
        registry=registry,
        host=args.host,
        port=args.port,
        api_key=args.api_key,
        enable_dashboard=not args.no_dashboard,
    )

    return 0


def cmd_shell(args: argparse.Namespace) -> int:
    """Execute shell command."""
    import code

    backend = _get_backend(args)

    banner = f"""TaskFlow Interactive Shell
Backend: {args.backend}
Type 'exit' to quit
"""
    local_vars = {
        "backend": backend,
    }

    if args.exec:
        exec(args.exec, local_vars)
    else:
        code.interact(banner=banner, local=local_vars)

    return 0


def cmd_pool(args: argparse.Namespace) -> int:
    """Execute pool command."""
    print("Worker pool management not yet implemented")
    return 1


def main(argv: Optional[List[str]] = None) -> int:
    """Main entry point."""
    parser = create_parser()
    args = parser.parse_args(argv)

    if not args.command:
        parser.print_help()
        return 1

    try:
        return execute_command(args)
    except KeyboardInterrupt:
        print("\nInterrupted")
        return 130
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        if args.verbose if 'args' in locals() else False:
            import traceback
            traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
