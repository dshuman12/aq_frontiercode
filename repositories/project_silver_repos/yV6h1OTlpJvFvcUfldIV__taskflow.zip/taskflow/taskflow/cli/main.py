"""
Command-line interface for taskflow.

Provides commands to inspect queues, list tasks, purge queues,
show worker stats, and run a development worker.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Any, Optional


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="taskflow",
        description="taskflow — distributed task queue CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="Run 'taskflow COMMAND --help' for help on a specific command.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # worker
    worker_p = sub.add_parser("worker", help="Start a task worker process.")
    worker_p.add_argument("--queues", "-q", nargs="+", default=["default"],
                          help="Queue names to consume from.")
    worker_p.add_argument("--concurrency", "-c", type=int, default=4,
                          help="Number of concurrent task threads.")
    worker_p.add_argument("--backend", default="memory",
                          choices=["memory", "sqlite"],
                          help="Backend to use.")
    worker_p.add_argument("--db", default="taskflow.db",
                          help="SQLite database path (--backend=sqlite only).")
    worker_p.add_argument("--poll-interval", type=float, default=0.5,
                          help="Seconds between queue polls.")
    worker_p.add_argument("--health-port", type=int, default=None,
                          help="Start health server on this port.")
    worker_p.add_argument("--log-level", default="INFO",
                          choices=["DEBUG", "INFO", "WARNING", "ERROR"])

    # inspect
    inspect_p = sub.add_parser("inspect", help="Inspect queue and task state.")
    inspect_p.add_argument("--backend", default="memory", choices=["memory", "sqlite"])
    inspect_p.add_argument("--db", default="taskflow.db")
    inspect_p.add_argument("--queue", help="Filter by queue name.")
    inspect_p.add_argument("--status", help="Filter by task status.")
    inspect_p.add_argument("--limit", type=int, default=20)
    inspect_p.add_argument("--format", choices=["table", "json"], default="table")

    # purge
    purge_p = sub.add_parser("purge", help="Purge all pending tasks from a queue.")
    purge_p.add_argument("queue", help="Queue name to purge.")
    purge_p.add_argument("--backend", default="sqlite", choices=["memory", "sqlite"])
    purge_p.add_argument("--db", default="taskflow.db")
    purge_p.add_argument("--yes", "-y", action="store_true", help="Skip confirmation.")

    # revoke
    revoke_p = sub.add_parser("revoke", help="Revoke a specific task by ID.")
    revoke_p.add_argument("task_id", help="Task ID to revoke.")
    revoke_p.add_argument("--backend", default="sqlite", choices=["memory", "sqlite"])
    revoke_p.add_argument("--db", default="taskflow.db")

    # queues
    queues_p = sub.add_parser("queues", help="List all known queues and their stats.")
    queues_p.add_argument("--backend", default="sqlite", choices=["memory", "sqlite"])
    queues_p.add_argument("--db", default="taskflow.db")
    queues_p.add_argument("--format", choices=["table", "json"], default="table")

    # result
    result_p = sub.add_parser("result", help="Fetch the result of a task by ID.")
    result_p.add_argument("task_id")
    result_p.add_argument("--backend", default="sqlite", choices=["memory", "sqlite"])
    result_p.add_argument("--db", default="taskflow.db")
    result_p.add_argument("--wait", type=float, default=0.0,
                          help="Wait up to N seconds for the result.")

    return parser


def _make_backend(args: argparse.Namespace) -> Any:
    if args.backend == "sqlite":
        from taskflow.backends.sqlite import SQLiteBackend
        return SQLiteBackend(db_path=args.db)
    from taskflow.backends.memory import MemoryBackend
    return MemoryBackend()


def cmd_worker(args: argparse.Namespace) -> int:
    import logging
    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s %(name)s %(levelname)s %(message)s",
    )

    backend = _make_backend(args)

    if args.health_port:
        from taskflow.monitoring.metrics import HealthServer, get_metrics
        hs = HealthServer(port=args.health_port, backend=backend, collector=get_metrics())
        hs.start()

    from taskflow.workers.worker import Worker
    worker = Worker(
        backend=backend,
        queues=args.queues,
        concurrency=args.concurrency,
        poll_interval=args.poll_interval,
    )
    try:
        worker.start(block=True)
    except KeyboardInterrupt:
        worker.stop()
    return 0


def cmd_inspect(args: argparse.Namespace) -> int:
    from taskflow.core.models import TaskStatus
    backend = _make_backend(args)
    status = TaskStatus(args.status) if args.status else None
    tasks = backend.list_tasks(queue_name=args.queue, status=status, limit=args.limit)

    if args.format == "json":
        print(json.dumps([t.to_dict() for t in tasks], indent=2))
        return 0

    if not tasks:
        print("No tasks found.")
        return 0

    print(f"{'ID':36}  {'NAME':30}  {'STATUS':10}  {'QUEUE':12}  {'ATTEMPT':7}")
    print("-" * 100)
    for t in tasks:
        print(
            f"{t.task_id:36}  {t.task_name:30}  {t.status.value:10}  "
            f"{t.queue_name:12}  {t.attempt:7}"
        )
    return 0


def cmd_purge(args: argparse.Namespace) -> int:
    if not args.yes:
        confirm = input(f"Purge all pending tasks from '{args.queue}'? [y/N] ")
        if confirm.lower() != "y":
            print("Aborted.")
            return 0

    backend = _make_backend(args)
    count = backend.purge_queue(args.queue)
    print(f"Purged {count} tasks from '{args.queue}'.")
    return 0


def cmd_revoke(args: argparse.Namespace) -> int:
    backend = _make_backend(args)
    ok = backend.revoke(args.task_id)
    if ok:
        print(f"Task {args.task_id} revoked.")
        return 0
    print(f"Task {args.task_id} not found or already terminal.", file=sys.stderr)
    return 1


def cmd_queues(args: argparse.Namespace) -> int:
    backend = _make_backend(args)
    queues = backend.all_queue_info()

    if args.format == "json":
        print(json.dumps([q.to_dict() for q in queues], indent=2))
        return 0

    if not queues:
        print("No queues found.")
        return 0

    print(f"{'NAME':20}  {'STATUS':10}  {'PENDING':8}  {'RUNNING':8}  {'DONE':8}  {'FAILED':8}")
    print("-" * 75)
    for q in queues:
        print(
            f"{q.name:20}  {q.status.value:10}  {q.pending_count:8}  "
            f"{q.running_count:8}  {q.completed_count:8}  {q.failed_count:8}"
        )
    return 0


def cmd_result(args: argparse.Namespace) -> int:
    backend = _make_backend(args)

    if args.wait > 0:
        result = backend.wait_for_result(args.task_id, timeout=args.wait)
    else:
        result = backend.get_result(args.task_id)

    if result is None:
        print(f"No result found for task {args.task_id}.")
        return 1

    print(json.dumps(result.to_dict(), indent=2))
    return 0 if result.succeeded else 1


def main(argv: Optional[list] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    try:
        if args.command == "worker":
            return cmd_worker(args)
        if args.command == "inspect":
            return cmd_inspect(args)
        if args.command == "purge":
            return cmd_purge(args)
        if args.command == "revoke":
            return cmd_revoke(args)
        if args.command == "queues":
            return cmd_queues(args)
        if args.command == "result":
            return cmd_result(args)
    except FileNotFoundError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        return 0

    return 0


if __name__ == "__main__":
    sys.exit(main())
