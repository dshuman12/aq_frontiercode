"""
SQLite backend for taskflow.

Persists tasks and results to a SQLite database file.
Suitable for single-host deployments that need durability across restarts.
"""

from __future__ import annotations

import json
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Iterator, List, Optional

from taskflow.core.models import (
    Priority, QueueInfo, QueueStatus, Task, TaskResult, TaskStatus
)

SCHEMA_VERSION = 1

CREATE_TASKS_TABLE = """
CREATE TABLE IF NOT EXISTS tasks (
    task_id       TEXT PRIMARY KEY,
    task_name     TEXT NOT NULL,
    queue_name    TEXT NOT NULL DEFAULT 'default',
    priority      INTEGER NOT NULL DEFAULT 2,
    status        TEXT NOT NULL DEFAULT 'pending',
    args          TEXT NOT NULL DEFAULT '[]',
    kwargs        TEXT NOT NULL DEFAULT '{}',
    attempt       INTEGER NOT NULL DEFAULT 0,
    max_retries   INTEGER NOT NULL DEFAULT 3,
    created_at    TEXT NOT NULL,
    queued_at     TEXT,
    started_at    TEXT,
    completed_at  TEXT,
    eta           TEXT,
    expires_at    TEXT,
    timeout_secs  REAL,
    worker_id     TEXT,
    correlation_id TEXT,
    parent_id     TEXT,
    tags          TEXT NOT NULL DEFAULT '[]',
    metadata      TEXT NOT NULL DEFAULT '{}',
    error         TEXT,
    traceback     TEXT,
    retry_policy  TEXT NOT NULL DEFAULT '{}'
);
"""

CREATE_RESULTS_TABLE = """
CREATE TABLE IF NOT EXISTS results (
    task_id       TEXT PRIMARY KEY,
    status        TEXT NOT NULL,
    return_value  TEXT,
    error         TEXT,
    traceback     TEXT,
    started_at    TEXT,
    completed_at  TEXT,
    worker_id     TEXT
);
"""

CREATE_QUEUES_TABLE = """
CREATE TABLE IF NOT EXISTS queues (
    name            TEXT PRIMARY KEY,
    status          TEXT NOT NULL DEFAULT 'active',
    total_enqueued  INTEGER NOT NULL DEFAULT 0,
    completed_count INTEGER NOT NULL DEFAULT 0,
    failed_count    INTEGER NOT NULL DEFAULT 0,
    created_at      TEXT NOT NULL,
    last_activity   TEXT,
    max_concurrency INTEGER,
    tags            TEXT NOT NULL DEFAULT '[]'
);
"""

CREATE_INDEXES = [
    "CREATE INDEX IF NOT EXISTS idx_tasks_queue_status ON tasks(queue_name, status);",
    "CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);",
    "CREATE INDEX IF NOT EXISTS idx_tasks_eta ON tasks(eta);",
    "CREATE INDEX IF NOT EXISTS idx_tasks_priority ON tasks(priority);",
]


class SQLiteBackend:
    """
    SQLite-backed task store.

    All operations are synchronous and thread-safe via a single connection
    with WAL mode enabled.
    """

    def __init__(self, db_path: str | Path = ":memory:") -> None:
        self.db_path = str(db_path)
        self._lock = threading.RLock()
        self._local = threading.local()
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        if not hasattr(self._local, "conn") or self._local.conn is None:
            conn = sqlite3.connect(self.db_path, check_same_thread=False)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA foreign_keys=ON")
            self._local.conn = conn
        return self._local.conn

    @contextmanager
    def _cursor(self) -> Iterator[sqlite3.Cursor]:
        conn = self._connect()
        with self._lock:
            cursor = conn.cursor()
            try:
                yield cursor
                conn.commit()
            except Exception:
                conn.rollback()
                raise
            finally:
                cursor.close()

    def _init_db(self) -> None:
        with self._cursor() as cur:
            cur.execute(CREATE_TASKS_TABLE)
            cur.execute(CREATE_RESULTS_TABLE)
            cur.execute(CREATE_QUEUES_TABLE)
            for idx in CREATE_INDEXES:
                cur.execute(idx)

    # -----------------------------------------------------------------------
    # Queue management
    # -----------------------------------------------------------------------

    def declare_queue(self, name: str, max_concurrency: Optional[int] = None,
                      tags: Optional[List[str]] = None) -> QueueInfo:
        now = datetime.now(timezone.utc).isoformat()
        with self._cursor() as cur:
            cur.execute(
                """
                INSERT INTO queues (name, created_at, max_concurrency, tags)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(name) DO NOTHING
                """,
                (name, now, max_concurrency, json.dumps(tags or [])),
            )
        return self.queue_info(name) or QueueInfo(name=name)

    def pause_queue(self, name: str) -> None:
        with self._cursor() as cur:
            cur.execute("UPDATE queues SET status=? WHERE name=?", ("paused", name))

    def resume_queue(self, name: str) -> None:
        with self._cursor() as cur:
            cur.execute("UPDATE queues SET status=? WHERE name=?", ("active", name))

    def is_paused(self, name: str) -> bool:
        with self._cursor() as cur:
            row = cur.execute(
                "SELECT status FROM queues WHERE name=?", (name,)
            ).fetchone()
        return row is not None and row["status"] == "paused"

    # -----------------------------------------------------------------------
    # Enqueue / Dequeue
    # -----------------------------------------------------------------------

    def enqueue(self, task: Task) -> None:
        task.status = TaskStatus.QUEUED
        task.queued_at = datetime.now(timezone.utc)
        with self._cursor() as cur:
            cur.execute(
                """
                INSERT OR REPLACE INTO tasks
                (task_id, task_name, queue_name, priority, status, args, kwargs,
                 attempt, max_retries, created_at, queued_at, eta, expires_at,
                 timeout_secs, correlation_id, parent_id, tags, metadata, retry_policy)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    task.task_id, task.task_name, task.queue_name,
                    task.priority.value, task.status.value,
                    json.dumps(task.args), json.dumps(task.kwargs),
                    task.attempt, task.max_retries,
                    task.created_at.isoformat(),
                    task.queued_at.isoformat() if task.queued_at else None,
                    task.eta.isoformat() if task.eta else None,
                    task.expires_at.isoformat() if task.expires_at else None,
                    task.timeout_seconds, task.correlation_id, task.parent_id,
                    json.dumps(task.tags), json.dumps(task.metadata),
                    json.dumps(task.retry_policy.to_dict()),
                ),
            )
            cur.execute(
                """
                INSERT INTO queues (name, created_at, total_enqueued, last_activity)
                VALUES (?, ?, 1, ?)
                ON CONFLICT(name) DO UPDATE SET
                    total_enqueued = total_enqueued + 1,
                    last_activity = excluded.last_activity
                """,
                (task.queue_name, task.created_at.isoformat(),
                 task.queued_at.isoformat() if task.queued_at else None),
            )

    def dequeue(self, queue_name: str, worker_id: str) -> Optional[Task]:
        now_iso = datetime.now(timezone.utc).isoformat()
        with self._cursor() as cur:
            row = cur.execute(
                """
                SELECT * FROM tasks
                WHERE queue_name = ?
                  AND status = 'queued'
                  AND (eta IS NULL OR eta <= ?)
                  AND (expires_at IS NULL OR expires_at > ?)
                ORDER BY priority ASC, queued_at ASC
                LIMIT 1
                """,
                (queue_name, now_iso, now_iso),
            ).fetchone()

            if row is None:
                return None

            cur.execute(
                """
                UPDATE tasks SET status='running', started_at=?, worker_id=?, attempt=attempt+1
                WHERE task_id=?
                """,
                (now_iso, worker_id, row["task_id"]),
            )

        return self._row_to_task(dict(row))

    def requeue(self, task: Task) -> None:
        task.status = TaskStatus.QUEUED
        task.started_at = None
        task.worker_id = None
        with self._cursor() as cur:
            cur.execute(
                "UPDATE tasks SET status='queued', started_at=NULL, worker_id=NULL, eta=? WHERE task_id=?",
                (task.eta.isoformat() if task.eta else None, task.task_id),
            )

    # -----------------------------------------------------------------------
    # Results
    # -----------------------------------------------------------------------

    def store_result(self, result: TaskResult) -> None:
        with self._cursor() as cur:
            cur.execute(
                """
                INSERT OR REPLACE INTO results
                (task_id, status, return_value, error, traceback, started_at, completed_at, worker_id)
                VALUES (?,?,?,?,?,?,?,?)
                """,
                (
                    result.task_id, result.status.value,
                    json.dumps(result.return_value) if result.return_value is not None else None,
                    result.error, result.traceback,
                    result.started_at.isoformat() if result.started_at else None,
                    result.completed_at.isoformat() if result.completed_at else None,
                    result.worker_id,
                ),
            )
            cur.execute(
                "UPDATE tasks SET status=?, completed_at=?, error=? WHERE task_id=?",
                (result.status.value,
                 result.completed_at.isoformat() if result.completed_at else None,
                 result.error, result.task_id),
            )
            if result.status == TaskStatus.SUCCESS:
                cur.execute(
                    "UPDATE queues SET completed_count=completed_count+1 WHERE name=(SELECT queue_name FROM tasks WHERE task_id=?)",
                    (result.task_id,),
                )
            elif result.status == TaskStatus.FAILURE:
                cur.execute(
                    "UPDATE queues SET failed_count=failed_count+1 WHERE name=(SELECT queue_name FROM tasks WHERE task_id=?)",
                    (result.task_id,),
                )

    def get_result(self, task_id: str) -> Optional[TaskResult]:
        with self._cursor() as cur:
            row = cur.execute(
                "SELECT * FROM results WHERE task_id=?", (task_id,)
            ).fetchone()
        if row is None:
            return None
        return self._row_to_result(dict(row))

    def get_task(self, task_id: str) -> Optional[Task]:
        with self._cursor() as cur:
            row = cur.execute(
                "SELECT * FROM tasks WHERE task_id=?", (task_id,)
            ).fetchone()
        return self._row_to_task(dict(row)) if row else None

    def list_tasks(self, queue_name: Optional[str] = None,
                   status: Optional[TaskStatus] = None, limit: int = 100) -> List[Task]:
        query = "SELECT * FROM tasks WHERE 1=1"
        params: list = []
        if queue_name:
            query += " AND queue_name=?"
            params.append(queue_name)
        if status:
            query += " AND status=?"
            params.append(status.value)
        query += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)
        with self._cursor() as cur:
            rows = cur.execute(query, params).fetchall()
        return [self._row_to_task(dict(r)) for r in rows]

    def revoke(self, task_id: str) -> bool:
        with self._cursor() as cur:
            cur.execute(
                "UPDATE tasks SET status='revoked' WHERE task_id=? AND status IN ('pending','queued')",
                (task_id,),
            )
            return cur.rowcount > 0

    def queue_info(self, name: str) -> Optional[QueueInfo]:
        with self._cursor() as cur:
            row = cur.execute("SELECT * FROM queues WHERE name=?", (name,)).fetchone()
            pending = cur.execute(
                "SELECT COUNT(*) FROM tasks WHERE queue_name=? AND status='queued'", (name,)
            ).fetchone()[0]
            running = cur.execute(
                "SELECT COUNT(*) FROM tasks WHERE queue_name=? AND status='running'", (name,)
            ).fetchone()[0]
        if row is None:
            return None
        info = QueueInfo(
            name=row["name"],
            status=QueueStatus(row["status"]),
            total_enqueued=row["total_enqueued"],
            completed_count=row["completed_count"],
            failed_count=row["failed_count"],
            pending_count=pending,
            running_count=running,
        )
        return info

    def all_queue_info(self) -> List[QueueInfo]:
        with self._cursor() as cur:
            rows = cur.execute("SELECT name FROM queues").fetchall()
        return [self.queue_info(r["name"]) for r in rows if self.queue_info(r["name"])]

    def purge_queue(self, name: str) -> int:
        with self._cursor() as cur:
            count = cur.execute(
                "SELECT COUNT(*) FROM tasks WHERE queue_name=? AND status='queued'", (name,)
            ).fetchone()[0]
            cur.execute(
                "DELETE FROM tasks WHERE queue_name=? AND status='queued'", (name,)
            )
        return count

    # -----------------------------------------------------------------------
    # Helpers
    # -----------------------------------------------------------------------

    def _row_to_task(self, row: dict) -> Task:
        task = Task(
            task_id=row["task_id"],
            task_name=row["task_name"],
            queue_name=row["queue_name"],
            priority=Priority(row["priority"]),
            status=TaskStatus(row["status"]),
            args=json.loads(row["args"]),
            kwargs=json.loads(row["kwargs"]),
            attempt=row["attempt"],
            max_retries=row["max_retries"],
            timeout_seconds=row.get("timeout_secs"),
            worker_id=row.get("worker_id"),
            correlation_id=row.get("correlation_id"),
            parent_id=row.get("parent_id"),
            tags=json.loads(row.get("tags") or "[]"),
            metadata=json.loads(row.get("metadata") or "{}"),
            error=row.get("error"),
            traceback=row.get("traceback"),
        )
        for field, attr in [
            ("created_at", "created_at"), ("queued_at", "queued_at"),
            ("started_at", "started_at"), ("completed_at", "completed_at"),
            ("eta", "eta"), ("expires_at", "expires_at"),
        ]:
            val = row.get(field)
            if val:
                setattr(task, attr, datetime.fromisoformat(val))
        return task

    def _row_to_result(self, row: dict) -> TaskResult:
        rv_raw = row.get("return_value")
        return_value = json.loads(rv_raw) if rv_raw else None
        result = TaskResult(
            task_id=row["task_id"],
            status=TaskStatus(row["status"]),
            return_value=return_value,
            error=row.get("error"),
            traceback=row.get("traceback"),
            worker_id=row.get("worker_id"),
        )
        for field, attr in [("started_at", "started_at"), ("completed_at", "completed_at")]:
            val = row.get(field)
            if val:
                setattr(result, attr, datetime.fromisoformat(val))
        return result

    def close(self) -> None:
        if hasattr(self._local, "conn") and self._local.conn:
            self._local.conn.close()
            self._local.conn = None
