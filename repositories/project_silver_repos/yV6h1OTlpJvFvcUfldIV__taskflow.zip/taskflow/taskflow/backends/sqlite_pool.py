"""
Connection pool wrapper around SQLite that enables WAL journal mode
and manages a pool of connections for concurrent reader threads.
Writers still serialise via a single write connection + RLock.
"""
from __future__ import annotations
import logging, queue, sqlite3, threading
from typing import Optional

logger = logging.getLogger(__name__)

class SQLitePool:
    def __init__(
        self,
        db_path: str,
        pool_size: int = 4,
        timeout: float = 5.0,
    ) -> None:
        self._db_path = db_path
        self._timeout = timeout
        self._pool: queue.Queue[sqlite3.Connection] = queue.Queue(maxsize=pool_size)
        self._write_lock = threading.RLock()
        for _ in range(pool_size):
            conn = self._make_connection()
            self._pool.put(conn)

    def _make_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(
            self._db_path, check_same_thread=False, timeout=self._timeout
        )
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA foreign_keys=ON")
        conn.commit()
        return conn

    def acquire(self) -> sqlite3.Connection:
        try:
            return self._pool.get(timeout=self._timeout)
        except queue.Empty:
            raise TimeoutError("SQLitePool: timed out waiting for a connection")

    def release(self, conn: sqlite3.Connection) -> None:
        try:
            self._pool.put_nowait(conn)
        except queue.Full:
            conn.close()

    def write_lock(self) -> threading.RLock:
        return self._write_lock

    def close_all(self) -> None:
        while not self._pool.empty():
            try:
                conn = self._pool.get_nowait()
                conn.close()
            except queue.Empty:
                break
