"""
Redis backend for taskflow.

Provides a production-grade backend using Redis for task queuing,
result storage, and distributed locking. Supports Redis Cluster
for high availability and horizontal scaling.

Features:
- Priority queues using Redis sorted sets
- Result storage with TTL
- Distributed locking for task reservation
- Pub/Sub for real-time task distribution
- Lua scripts for atomic operations
- Connection pooling
- Retry with exponential backoff
"""

from __future__ import annotations

import json
import logging
import random
import threading
import time
import uuid
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from typing import Any, Callable, Dict, Iterator, List, Optional, Set, Tuple

try:
    import redis
    from redis import Redis
    from redis.exceptions import ConnectionError, TimeoutError, RedisError
    REDIS_AVAILABLE = True
except ImportError:
    REDIS_AVAILABLE = False
    Redis = None
    ConnectionError = Exception
    TimeoutError = Exception
    RedisError = Exception

from taskflow.core.models import (
    Priority, QueueInfo, QueueStatus, Task, TaskResult, TaskStatus
)

logger = logging.getLogger(__name__)

# Redis key prefixes
PREFIX_TASKS = "taskflow:tasks:"
PREFIX_QUEUE = "taskflow:queue:"
PREFIX_RESULTS = "taskflow:results:"
PREFIX_LOCKS = "taskflow:locks:"
PREFIX_SCHEDULED = "taskflow:scheduled:"
PREFIX_DEAD = "taskflow:dead:"
PREFIX_CHANNELS = "taskflow:channels:"
PREFIX_WORKERS = "taskflow:workers:"
PREFIX_STATS = "taskflow:stats:"
PREFIX_EVENTS = "taskflow:events:"


# Lua scripts for atomic operations
DEQUEUE_SCRIPT = """
local queue_key = KEYS[1]
local scheduled_key = KEYS[2]
local worker_id = ARGV[1]
local now = tonumber(ARGV[2])
local lease_ms = tonumber(ARGV[3])

-- Check scheduled tasks first
local scheduled = redis.call('ZRANGEBYSCORE', scheduled_key, '-inf', now, 'LIMIT', 0, 1)
if #scheduled > 0 then
    local task_id = scheduled[1]
    redis.call('ZREM', scheduled_key, task_id)
    local task_data = redis.call('GET', KEYS[3] .. task_id)
    if task_data then
        local task = cjson.decode(task_data)
        task.status = 'running'
        task.worker_id = worker_id
        task.started_at = now
        task.attempt = (task.attempt or 0) + 1
        redis.call('SET', KEYS[3] .. task_id, cjson.encode(task), 'PX', lease_ms)
        redis.call('HSET', KEYS[4] .. task_id, 'worker_id', worker_id, 'started_at', now, 'lease_until', now + lease_ms)
        return {task_id, task_data}
    end
end

-- Get from regular queue
local items = redis.call('ZRANGE', queue_key, 0, 0)
if #items > 0 then
    local task_id = items[1]
    local task_data = redis.call('GET', KEYS[3] .. task_id)
    if task_data then
        redis.call('ZREM', queue_key, task_id)
        local task = cjson.decode(task_data)
        task.status = 'running'
        task.worker_id = worker_id
        task.started_at = now
        task.attempt = (task.attempt or 0) + 1
        redis.call('SET', KEYS[3] .. task_id, cjson.encode(task), 'PX', lease_ms)
        redis.call('HSET', KEYS[4] .. task_id, 'worker_id', worker_id, 'started_at', now, 'lease_until', now + lease_ms)
        return {task_id, task_data}
    end
end

return nil
"""

RENEW_LEASE_SCRIPT = """
local lock_key = KEYS[1]
local lease_key = KEYS[2]
local task_key = KEYS[3]
local task_id = ARGV[1]
local worker_id = ARGV[2]
local lease_ms = tonumber(ARGV[3])
local now = tonumber(ARGV[4])

local current_worker = redis.call('HGET', lock_key, task_id)
if current_worker ~= worker_id then
    return 0
end

redis.call('EXPIRE', lock_key, math.ceil(lease_ms / 1000))
redis.call('HSET', lock_key, task_id, worker_id)
redis.call('EXPIRE', lock_key, math.ceil(lease_ms / 1000))
redis.call('HSET', lease_key, task_id, tostring(now + lease_ms))
redis.call('EXPIRE', lease_key, math.ceil(lease_ms / 1000))

local task_data = redis.call('GET', task_key)
if task_data then
    local task = cjson.decode(task_data)
    redis.call('SET', task_key, cjson.encode(task), 'PX', lease_ms)
    return 1
end
return 0
"""

COMPLETE_TASK_SCRIPT = """
local queue_key = KEYS[1]
local lock_key = KEYS[2]
local result_key = KEYS[3]
local task_key = KEYS[4]
local stats_key = KEYS[5]
local task_id = ARGV[1]
local worker_id = ARGV[2]
local status = ARGV[3]
local now = tonumber(ARGV[4])

-- Verify worker owns the task
local current_worker = redis.call('HGET', lock_key, task_id)
if current_worker ~= worker_id then
    return {0, 'not_owner'}
end

-- Remove from locks
redis.call('HDEL', lock_key, task_id)
redis.call('HDEL', KEYS[6], task_id)

-- Store result
redis.call('SET', result_key, ARGV[4], 'EX', 86400)

-- Update task status
if status == 'success' then
    redis.call('HINCRBY', stats_key .. 'completed', ARGV[5], 1)
elseif status == 'failure' then
    redis.call('HINCRBY', stats_key .. 'failed', ARGV[5], 1)
end

-- Delete task data
redis.call('DEL', task_key)

return {1, 'ok'}
"""

REQUEUE_TASK_SCRIPT = """
local queue_key = KEYS[1]
local scheduled_key = KEYS[2]
local lock_key = KEYS[3]
local task_key = KEYS[4]
local task_id = ARGV[1]
local worker_id = ARGV[2]
local eta = tonumber(ARGV[3])
local priority = tonumber(ARGV[4])
local now = tonumber(ARGV[5])

-- Verify worker owns the task
local current_worker = redis.call('HGET', lock_key, task_id)
if current_worker ~= worker_id then
    return 0
end

-- Get task data
local task_data = redis.call('GET', task_key)
if not task_data then
    return 0
end

-- Update task status
local task = cjson.decode(task_data)
task.status = 'queued'
task.worker_id = nil
task.started_at = nil

-- Remove from locks
redis.call('HDEL', lock_key, task_id)
redis.call('HDEL', KEYS[5], task_id)

-- Re-add to queue or schedule
redis.call('SET', task_key, cjson.encode(task))
if eta > now then
    redis.call('ZADD', scheduled_key, eta, task_id)
else
    redis.call('ZADD', queue_key, priority, task_id)
end

return 1
"""


class RedisBackendError(Exception):
    """Raised for Redis backend errors."""
    pass


class ConnectionFailedError(RedisBackendError):
    """Raised when Redis connection fails."""
    pass


class TaskLeaseExpiredError(RedisBackendError):
    """Raised when a task lease has expired."""
    pass


@dataclass
class RedisConnectionConfig:
    """
    Configuration for Redis connection.

    Supports single Redis, Sentinel, and Cluster configurations.
    """

    host: str = "localhost"
    port: int = 6379
    db: int = 0
    password: Optional[str] = None
    ssl: bool = False
    ssl_certfile: Optional[str] = None
    ssl_keyfile: Optional[str] = None
    ssl_ca_certs: Optional[str] = None

    # Connection pool settings
    max_connections: int = 50
    socket_timeout: float = 5.0
    socket_connect_timeout: float = 5.0
    socket_keepalive: bool = True
    socket_keepalive_options: Optional[Dict] = None
    retry_on_timeout: bool = True
    health_check_interval: int = 30

    # Sentinel settings
    sentinel_enabled: bool = False
    sentinel_service_name: Optional[str] = None
    sentinel_master_name: Optional[str] = None
    sentinel_nodes: Optional[List[Tuple[str, int]]] = None

    # Cluster settings
    cluster_enabled: bool = False
    cluster_startup_nodes: Optional[List[Tuple[str, int]]] = None
    cluster_max_redirects: int = 3

    # Replication settings
    master_name: Optional[str] = None
    read_from_replicas: bool = False

    # Retry settings
    max_retries: int = 3
    retry_delay: float = 0.5
    retry_backoff_factor: float = 2.0

    def to_redis_params(self) -> Dict[str, Any]:
        """Convert config to redis-py parameters."""
        params: Dict[str, Any] = {
            "host": self.host,
            "port": self.port,
            "db": self.db,
            "password": self.password,
            "ssl": self.ssl,
            "socket_timeout": self.socket_timeout,
            "socket_connect_timeout": self.socket_connect_timeout,
            "socket_keepalive": self.socket_keepalive,
            "retry_on_timeout": self.retry_on_timeout,
            "health_check_interval": self.health_check_interval,
            "decode_responses": False,
        }
        if self.ssl_certfile:
            params["ssl_certfile"] = self.ssl_certfile
        if self.ssl_keyfile:
            params["ssl_keyfile"] = self.ssl_keyfile
        if self.ssl_ca_certs:
            params["ssl_ca_certs"] = self.ssl_ca_certs
        return params


class RedisConnectionPool:
    """
    Manages Redis connections with pooling and automatic reconnection.

    Supports single Redis, Sentinel, and Cluster modes.
    """

    def __init__(self, config: RedisConnectionConfig) -> None:
        self.config = config
        self._pool: Optional[Any] = None
        self._client: Optional[Redis] = None
        self._lock = threading.Lock()
        self._init_pool()

    def _init_pool(self) -> None:
        """Initialize the connection pool based on configuration."""
        if not REDIS_AVAILABLE:
            raise RedisBackendError(
                "redis-py is not installed. Install it with: pip install redis"
            )

        params = self.config.to_redis_params()

        if self.config.cluster_enabled:
            from redis.cluster import RedisCluster
            startup_nodes = [
                {"host": n[0], "port": n[1]}
                for n in (self.config.cluster_startup_nodes or [])
            ]
            self._pool = RedisCluster(
                startup_nodes=startup_nodes,
                max_redirects=self.config.cluster_max_redirects,
                **params
            )
            self._client = self._pool
        elif self.config.sentinel_enabled:
            from redis.sentinel import Sentinel
            sentinels = self.config.sentinel_nodes or []
            sentinel = Sentinel(
                [(s[0], s[1]) for s in sentinels],
                sentinel_kwargs={"socket_timeout": self.config.socket_timeout}
            )
            if self.config.read_from_replicas:
                self._client = sentinel.slave_for(
                    self.config.sentinel_master_name or "mymaster",
                    **params
                )
            else:
                self._client = sentinel.master_for(
                    self.config.sentinel_master_name or "mymaster",
                    **params
                )
        else:
            self._pool = redis.ConnectionPool(
                max_connections=self.config.max_connections,
                **params
            )
            self._client = redis.Redis(connection_pool=self._pool)

    def get_client(self) -> Redis:
        """Get the Redis client, reconnecting if necessary."""
        if self._client is None:
            with self._lock:
                if self._client is None:
                    self._init_pool()
        return self._client

    def close(self) -> None:
        """Close all connections in the pool."""
        if self._pool:
            self._pool.disconnect()
        if self._client:
            self._client.close()

    def execute_with_retry(
        self,
        func: Callable,
        *args: Any,
        **kwargs: Any
    ) -> Any:
        """
        Execute a Redis command with automatic retry on transient failures.

        Uses exponential backoff for retries.
        """
        last_error: Optional[Exception] = None
        delay = self.config.retry_delay

        for attempt in range(self.config.max_retries + 1):
            try:
                client = self.get_client()
                return func(client, *args, **kwargs)
            except (ConnectionError, TimeoutError) as exc:
                last_error = exc
                if attempt < self.config.max_retries:
                    logger.warning(
                        "Redis operation failed (attempt %d/%d): %s",
                        attempt + 1, self.config.max_retries, exc
                    )
                    time.sleep(delay)
                    delay *= self.config.retry_backoff_factor
                    # Force reconnection on next attempt
                    with self._lock:
                        self._client = None
                else:
                    raise ConnectionFailedError(
                        f"Redis operation failed after {self.config.max_retries + 1} attempts: {exc}"
                    ) from exc

        raise ConnectionFailedError(f"Redis operation failed: {last_error}")


class RedisBackend:
    """
    Redis-backed task store for production deployments.

    Features:
    - Priority queues using sorted sets
    - Atomic task operations via Lua scripts
    - Distributed task leasing
    - Result storage with TTL
    - Pub/Sub for real-time task distribution
    - Dead letter queue for failed tasks
    - Task scheduling with ETA
    - Worker heartbeat tracking
    - Comprehensive statistics

    Thread-safe and suitable for distributed deployments.
    """

    def __init__(
        self,
        config: Optional[RedisConnectionConfig] = None,
        result_ttl: int = 86400,
        task_ttl: int = 604800,
        default_lease_ms: int = 300000,
        dead_letter_threshold: int = 5,
        enable_pubsub: bool = True,
    ) -> None:
        """
        Initialize Redis backend.

        Args:
            config: Redis connection configuration. Uses defaults if not provided.
            result_ttl: TTL for result storage in seconds (default: 24 hours).
            task_ttl: TTL for task data in seconds (default: 7 days).
            default_lease_ms: Default task lease duration in milliseconds.
            dead_letter_threshold: Max retries before moving to dead letter queue.
            enable_pubsub: Enable Pub/Sub for real-time task notifications.
        """
        if not REDIS_AVAILABLE:
            raise RedisBackendError(
                "redis-py is not installed. Install with: pip install redis"
            )

        self.config = config or RedisConnectionConfig()
        self.result_ttl = result_ttl
        self.task_ttl = task_ttl
        self.default_lease_ms = default_lease_ms
        self.dead_letter_threshold = dead_letter_threshold
        self.enable_pubsub = enable_pubsub

        self._pool = RedisConnectionPool(self.config)
        self._lua_scripts: Dict[str, Any] = {}
        self._pubsub: Optional[Any] = None
        self._pubsub_thread: Optional[threading.Thread] = None
        self._subscriber_callbacks: List[Callable[[str, Dict], None]] = []
        self._lock = threading.RLock()

        # Register Lua scripts
        self._register_scripts()

    def _register_scripts(self) -> None:
        """Register Lua scripts with Redis."""
        client = self._pool.get_client()
        self._lua_scripts["dequeue"] = client.register_script(DEQUEUE_SCRIPT)
        self._lua_scripts["renew_lease"] = client.register_script(RENEW_LEASE_SCRIPT)
        self._lua_scripts["complete_task"] = client.register_script(COMPLETE_TASK_SCRIPT)
        self._lua_scripts["requeue_task"] = client.register_script(REQUEUE_TASK_SCRIPT)

    @contextmanager
    def _pipeline(self) -> Iterator[Any]:
        """Context manager for Redis pipeline transactions."""
        client = self._pool.get_client()
        pipe = client.pipeline()
        try:
            yield pipe
            pipe.execute()
        except Exception:
            pipe.reset()
            raise

    # ---------------------------------------------------------------------------
    # Queue Management
    # ---------------------------------------------------------------------------

    def declare_queue(
        self,
        name: str,
        max_concurrency: Optional[int] = None,
        tags: Optional[List[str]] = None,
    ) -> QueueInfo:
        """
        Declare a queue and return its info.

        Creates queue metadata in Redis if it doesn't exist.
        """
        client = self._pool.get_client()
        now = datetime.now(timezone.utc).isoformat()
        queue_key = f"{PREFIX_QUEUE}{name}"
        stats_key = f"{PREFIX_STATS}{name}"

        def _do_declare(c: Redis) -> QueueInfo:
            pipe = c.pipeline()
            # Create queue metadata
            pipe.hset(queue_key, mapping={
                "name": name,
                "status": "active",
                "max_concurrency": str(max_concurrency or ""),
                "tags": json.dumps(tags or []),
                "created_at": now,
                "last_activity": now,
            })
            # Initialize stats
            pipe.hset(stats_key, mapping={
                "enqueued": 0,
                "completed": 0,
                "failed": 0,
                "retried": 0,
            })
            pipe.execute()
            return self.queue_info(name) or QueueInfo(name=name)

        return self._pool.execute_with_retry(_do_declare)

    def pause_queue(self, name: str) -> None:
        """Pause a queue, preventing new tasks from being dequeued."""
        def _do_pause(c: Redis) -> None:
            c.hset(f"{PREFIX_QUEUE}{name}", "status", "paused")

        self._pool.execute_with_retry(_do_pause)

    def resume_queue(self, name: str) -> None:
        """Resume a paused queue."""
        def _do_resume(c: Redis) -> None:
            c.hset(f"{PREFIX_QUEUE}{name}", "status", "active")

        self._pool.execute_with_retry(_do_resume)

    def is_paused(self, name: str) -> bool:
        """Check if a queue is paused."""
        def _do_check(c: Redis) -> bool:
            status = c.hget(f"{PREFIX_QUEUE}{name}", "status")
            return status == b"paused"

        return self._pool.execute_with_retry(_do_check)

    def close_queue(self, name: str) -> None:
        """Close a queue permanently."""
        def _do_close(c: Redis) -> None:
            c.hset(f"{PREFIX_QUEUE}{name}", "status", "closed")

        self._pool.execute_with_retry(_do_close)

    def drain_queue(self, name: str) -> int:
        """
        Drain a queue by removing all pending tasks.

        Returns the number of tasks removed.
        """
        def _do_drain(c: Redis) -> int:
            queue_key = f"{PREFIX_QUEUE}{name}"
            scheduled_key = f"{PREFIX_SCHEDULED}{name}"
            tasks_key = PREFIX_TASKS

            # Get all task IDs from queue
            task_ids = c.zrange(queue_key, 0, -1)
            count = len(task_ids)

            # Delete from queues and task storage
            if task_ids:
                c.zrem(queue_key, *task_ids)
                c.zrem(scheduled_key, *task_ids)
                for task_id in task_ids:
                    c.delete(f"{tasks_key}{task_id.decode() if isinstance(task_id, bytes) else task_id}")

            return count

        return self._pool.execute_with_retry(_do_drain)

    # ---------------------------------------------------------------------------
    # Enqueue / Dequeue
    # ---------------------------------------------------------------------------

    def enqueue(self, task: Task) -> None:
        """
        Add a task to its queue.

        Tasks are stored in Redis and added to a priority sorted set.
        If the task has an ETA, it's added to the scheduled set instead.
        """
        def _do_enqueue(c: Redis) -> None:
            now = datetime.now(timezone.utc)
            task_id = task.task_id

            # Serialize task
            task.status = TaskStatus.QUEUED
            task.queued_at = now
            task_dict = task.to_dict()

            # Keys
            task_key = f"{PREFIX_TASKS}{task_id}"
            queue_key = f"{PREFIX_QUEUE}{task.queue_name}"
            scheduled_key = f"{PREFIX_SCHEDULED}{task.queue_name}"
            stats_key = f"{PREFIX_STATS}{task.queue_name}"

            # Use pipeline for atomic operations
            pipe = c.pipeline()

            # Store task data
            pipe.set(task_key, json.dumps(task_dict, default=str), ex=self.task_ttl)

            # Add to appropriate queue
            if task.eta:
                # Convert ETA to Unix timestamp
                eta_ts = task.eta.timestamp() * 1000
                pipe.zadd(scheduled_key, {task_id: eta_ts})
            else:
                pipe.zadd(queue_key, {task_id: task.priority.value})

            # Update stats
            pipe.hincrby(stats_key, "enqueued", 1)
            pipe.hset(queue_key, "last_activity", now.isoformat())

            # Ensure queue exists
            pipe.hsetnx(queue_key, "name", task.queue_name)
            pipe.hsetnx(queue_key, "status", "active")

            pipe.execute()

            # Publish notification if enabled
            if self.enable_pubsub:
                try:
                    c.publish(
                        f"{PREFIX_CHANNELS}{task.queue_name}",
                        json.dumps({"type": "enqueued", "task_id": task_id})
                    )
                except RedisError:
                    pass  # Non-critical if pubsub fails

        self._pool.execute_with_retry(_do_enqueue)

    def dequeue(
        self,
        queue_name: str,
        worker_id: str,
        lease_ms: Optional[int] = None,
    ) -> Optional[Task]:
        """
        Dequeue a task for processing.

        Uses Lua script for atomic dequeue and lease acquisition.
        Returns None if no tasks are available or queue is paused.

        Args:
            queue_name: Name of the queue to dequeue from.
            worker_id: ID of the worker claiming the task.
            lease_ms: Lease duration in milliseconds.

        Returns:
            Task if one was available, None otherwise.
        """
        if self.is_paused(queue_name):
            return None

        lease_ms = lease_ms or self.default_lease_ms
        now_ms = int(datetime.now(timezone.utc).timestamp() * 1000)

        keys = [
            f"{PREFIX_QUEUE}{queue_name}",
            f"{PREFIX_SCHEDULED}{queue_name}",
            PREFIX_TASKS,
            PREFIX_LOCKS,
        ]

        try:
            result = self._lua_scripts["dequeue"](
                keys=list(keys),
                args=[
                    worker_id,
                    now_ms,
                    lease_ms,
                ]
            )

            if not result:
                return None

            task_id, task_data = result
            task_id = task_id.decode() if isinstance(task_id, bytes) else task_id
            task_data_str = task_data.decode() if isinstance(task_data, bytes) else task_data
            task_dict = json.loads(task_data_str)

            task = Task.from_dict(task_dict)

            # Publish notification
            if self.enable_pubsub:
                client = self._pool.get_client()
                try:
                    client.publish(
                        f"{PREFIX_CHANNELS}{queue_name}",
                        json.dumps({"type": "dequeued", "task_id": task_id})
                    )
                except RedisError:
                    pass

            return task

        except (ConnectionError, TimeoutError, RedisError) as exc:
            logger.error("Dequeue failed: %s", exc)
            raise ConnectionFailedError(f"Dequeue operation failed: {exc}") from exc

    def requeue(self, task: Task) -> None:
        """
        Re-enqueue a task for retry.

        Removes the task lease and re-adds it to the queue with updated ETA.
        """
        def _do_requeue(c: Redis) -> None:
            task_id = task.task_id
            now_ms = int(datetime.now(timezone.utc).timestamp() * 1000)
            queue_key = f"{PREFIX_QUEUE}{task.queue_name}"
            scheduled_key = f"{PREFIX_SCHEDULED}{task.queue_name}"
            lock_key = f"{PREFIX_LOCKS}{task_id}"
            task_key = f"{PREFIX_TASKS}{task_id}"

            # Update task status
            task.status = TaskStatus.QUEUED
            task.worker_id = None
            task.started_at = None

            pipe = c.pipeline()
            pipe.delete(lock_key)
            pipe.set(task_key, json.dumps(task.to_dict(), default=str), ex=self.task_ttl)

            # Add to appropriate queue based on ETA
            if task.eta:
                eta_ts = task.eta.timestamp() * 1000
                pipe.zadd(scheduled_key, {task_id: eta_ts})
            else:
                pipe.zadd(queue_key, {task_id: task.priority.value})

            pipe.execute()

        self._pool.execute_with_retry(_do_requeue)

    def renew_lease(
        self,
        task_id: str,
        worker_id: str,
        lease_ms: Optional[int] = None,
    ) -> bool:
        """
        Renew the lease on a task.

        Returns True if lease was renewed, False if the task is no longer owned.
        """
        lease_ms = lease_ms or self.default_lease_ms
        now_ms = int(datetime.now(timezone.utc).timestamp() * 1000)

        keys = [
            f"{PREFIX_LOCKS}",
            f"{PREFIX_LOCKS}",
            f"{PREFIX_TASKS}{task_id}",
        ]

        result = self._lua_scripts["renew_lease"](
            keys=list(keys),
            args=[
                task_id,
                worker_id,
                lease_ms,
                now_ms,
            ]
        )

        return bool(result)

    # ---------------------------------------------------------------------------
    # Results
    # ---------------------------------------------------------------------------

    def store_result(self, result: TaskResult) -> None:
        """
        Store the result of a completed task.

        Results are stored with TTL and trigger Pub/Sub notification.
        """
        def _do_store(c: Redis) -> None:
            result_key = f"{PREFIX_RESULTS}{result.task_id}"
            stats_key = f"{PREFIX_STATS}"

            # Get task to find queue name
            task = self.get_task(result.task_id)
            queue_name = task.queue_name if task else "unknown"

            pipe = c.pipeline()

            # Store result with TTL
            result_dict = result.to_dict()
            pipe.set(
                result_key,
                json.dumps(result_dict, default=str),
                ex=self.result_ttl
            )

            # Update stats
            if result.status == TaskStatus.SUCCESS:
                pipe.hincrby(f"{stats_key}{queue_name}", "completed", 1)
            elif result.status == TaskStatus.FAILURE:
                pipe.hincrby(f"{stats_key}{queue_name}", "failed", 1)

            # Clean up task data
            pipe.delete(f"{PREFIX_TASKS}{result.task_id}")
            pipe.delete(f"{PREFIX_LOCKS}{result.task_id}")

            pipe.execute()

            # Publish notification
            if self.enable_pubsub:
                try:
                    c.publish(
                        f"{PREFIX_CHANNELS}{queue_name}",
                        json.dumps({
                            "type": "completed",
                            "task_id": result.task_id,
                            "status": result.status.value,
                        })
                    )
                except RedisError:
                    pass

        self._pool.execute_with_retry(_do_store)

    def get_result(self, task_id: str) -> Optional[TaskResult]:
        """Retrieve the result of a task."""
        def _do_get(c: Redis) -> Optional[TaskResult]:
            result_key = f"{PREFIX_RESULTS}{task_id}"
            data = c.get(result_key)
            if not data:
                return None
            data_str = data.decode() if isinstance(data, bytes) else data
            result_dict = json.loads(data_str)
            result_dict["status"] = TaskStatus(result_dict["status"])
            return TaskResult(**result_dict)

        return self._pool.execute_with_retry(_do_get)

    def wait_for_result(
        self,
        task_id: str,
        timeout: float = 30.0,
        poll_interval: float = 0.1,
    ) -> Optional[TaskResult]:
        """
        Wait for a task result with polling.

        Uses Redis Pub/Sub for efficient waiting when possible.
        Falls back to polling if Pub/Sub is not available.
        """
        deadline = time.monotonic() + timeout

        # Try Pub/Sub first for efficiency
        if self.enable_pubsub:
            try:
                result = self._wait_with_pubsub(task_id, timeout)
                if result:
                    return result
            except Exception as exc:
                logger.warning("Pub/Sub wait failed, falling back to polling: %s", exc)

        # Fall back to polling
        while time.monotonic() < deadline:
            result = self.get_result(task_id)
            if result:
                return result
            time.sleep(min(poll_interval, deadline - time.monotonic()))

        return None

    def _wait_with_pubsub(self, task_id: str, timeout: float) -> Optional[TaskResult]:
        """Wait for result using Pub/Sub."""
        client = self._pool.get_client()
        pubsub = client.pubsub()

        try:
            # Get task to find queue
            task = self.get_task(task_id)
            if not task:
                return None

            channel = f"{PREFIX_CHANNELS}{task.queue_name}"
            pubsub.subscribe(channel)

            deadline = time.monotonic() + timeout
            while time.monotonic() < deadline:
                # Check if result is ready
                result = self.get_result(task_id)
                if result:
                    return result

                # Wait for pubsub message
                remaining = deadline - time.monotonic()
                if remaining > 0:
                    msg = pubsub.get_message(timeout=remaining)
                    if msg and msg["type"] == "message":
                        data = json.loads(msg["data"])
                        if data.get("task_id") == task_id:
                            return self.get_result(task_id)

            return None
        finally:
            pubsub.unsubscribe()
            pubsub.close()

    # ---------------------------------------------------------------------------
    # Task Management
    # ---------------------------------------------------------------------------

    def get_task(self, task_id: str) -> Optional[Task]:
        """Retrieve task metadata."""
        def _do_get(c: Redis) -> Optional[Task]:
            task_key = f"{PREFIX_TASKS}{task_id}"
            data = c.get(task_key)
            if not data:
                return None
            data_str = data.decode() if isinstance(data, bytes) else data
            task_dict = json.loads(data_str)
            return Task.from_dict(task_dict)

        return self._pool.execute_with_retry(_do_get)

    def list_tasks(
        self,
        queue_name: Optional[str] = None,
        status: Optional[TaskStatus] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Task]:
        """
        List tasks with optional filtering.

        Args:
            queue_name: Filter by queue name.
            status: Filter by task status.
            limit: Maximum number of tasks to return.
            offset: Number of tasks to skip.

        Returns:
            List of tasks matching the criteria.
        """
        def _do_list(c: Redis) -> List[Task]:
            tasks = []

            # Scan for task keys
            cursor = 0
            pattern = f"{PREFIX_TASKS}*"

            while len(tasks) < limit:
                cursor, keys = c.scan(cursor, match=pattern, count=100)
                if keys:
                    pipe = c.pipeline()
                    for key in keys:
                        pipe.get(key)
                    results = pipe.execute()

                    for data in results:
                        if data:
                            data_str = data.decode() if isinstance(data, bytes) else data
                            task_dict = json.loads(data_str)
                            task = Task.from_dict(task_dict)

                            # Apply filters
                            if queue_name and task.queue_name != queue_name:
                                continue
                            if status and task.status != status:
                                continue

                            tasks.append(task)

                            if len(tasks) >= limit + offset:
                                break

                if cursor == 0:
                    break

            return tasks[offset:offset + limit]

        return self._pool.execute_with_retry(_do_list)

    def revoke(self, task_id: str) -> bool:
        """
        Revoke a task.

        Marks the task as revoked so workers will skip it.
        """
        def _do_revoke(c: Redis) -> bool:
            task_key = f"{PREFIX_TASKS}{task_id}"
            queue_key = f"{PREFIX_QUEUE}"
            lock_key = f"{PREFIX_LOCKS}{task_id}"

            # Get task
            data = c.get(task_key)
            if not data:
                return False

            data_str = data.decode() if isinstance(data, bytes) else data
            task_dict = json.loads(data_str)
            task = Task.from_dict(task_dict)

            # Check if task can be revoked
            if task.status.is_terminal:
                return False

            # Update task status
            task.status = TaskStatus.REVOKED
            c.set(task_key, json.dumps(task.to_dict(), default=str), ex=self.task_ttl)

            # Remove from queues
            c.zrem(f"{PREFIX_QUEUE}{task.queue_name}", task_id)
            c.zrem(f"{PREFIX_SCHEDULED}{task.queue_name}", task_id)

            # Release any lock
            c.delete(lock_key)

            return True

        return self._pool.execute_with_retry(_do_revoke)

    def get_task_position(self, task_id: str, queue_name: str) -> Optional[int]:
        """
        Get the position of a task in its queue.

        Returns None if the task is not in the queue.
        Position is 0-indexed (position 0 is next to be dequeued).
        """
        def _do_get_pos(c: Redis) -> Optional[int]:
            queue_key = f"{PREFIX_QUEUE}{queue_name}"

            # Get all tasks in priority order
            tasks = c.zrange(queue_key, 0, -1, withscores=True)

            for i, (task, score) in enumerate(tasks):
                tid = task.decode() if isinstance(task, bytes) else task
                if tid == task_id:
                    return i

            return None

        return self._pool.execute_with_retry(_do_get_pos)

    # ---------------------------------------------------------------------------
    # Queue Info
    # ---------------------------------------------------------------------------

    def queue_info(self, name: str) -> Optional[QueueInfo]:
        """Get information about a queue."""
        def _do_info(c: Redis) -> Optional[QueueInfo]:
            queue_key = f"{PREFIX_QUEUE}{name}"
            stats_key = f"{PREFIX_STATS}{name}"

            queue_data = c.hgetall(queue_key)
            stats_data = c.hgetall(stats_key)

            if not queue_data:
                return None

            # Get pending and running counts
            pending = c.zcard(f"{PREFIX_QUEUE}{name}")
            scheduled = c.zcard(f"{PREFIX_SCHEDULED}{name}")

            def decode(v: Any) -> Any:
                return v.decode() if isinstance(v, bytes) else v

            queue_data = {decode(k): decode(v) for k, v in queue_data.items()}
            stats_data = {decode(k): decode(v) for k, v in stats_data.items()}

            info = QueueInfo(
                name=name,
                status=QueueStatus(queue_data.get("status", "active")),
                pending_count=pending + scheduled,
                total_enqueued=int(stats_data.get("enqueued", 0)),
                completed_count=int(stats_data.get("completed", 0)),
                failed_count=int(stats_data.get("failed", 0)),
                created_at=datetime.fromisoformat(
                    queue_data.get("created_at", datetime.now(timezone.utc).isoformat())
                ),
            )

            if queue_data.get("last_activity"):
                info.last_activity = datetime.fromisoformat(queue_data["last_activity"])

            return info

        return self._pool.execute_with_retry(_do_info)

    def all_queue_info(self) -> List[QueueInfo]:
        """Get information about all queues."""
        def _do_all(c: Redis) -> List[QueueInfo]:
            queues = []
            cursor = 0
            pattern = f"{PREFIX_QUEUE}*"

            while True:
                cursor, keys = c.scan(cursor, match=pattern, count=100)
                for key in keys:
                    key_str = key.decode() if isinstance(key, bytes) else key
                    name = key_str.replace(f"{PREFIX_QUEUE}", "")
                    if name and ":" not in name:  # Skip sub-keys
                        info = self.queue_info(name)
                        if info:
                            queues.append(info)

                if cursor == 0:
                    break

            return queues

        return self._pool.execute_with_retry(_do_all)

    def queue_length(self, name: str) -> int:
        """Get the number of pending tasks in a queue."""
        def _do_length(c: Redis) -> int:
            queue_key = f"{PREFIX_QUEUE}{name}"
            scheduled_key = f"{PREFIX_SCHEDULED}{name}"
            return c.zcard(queue_key) + c.zcard(scheduled_key)

        return self._pool.execute_with_retry(_do_length)

    def purge_queue(self, name: str) -> int:
        """Remove all pending tasks from a queue."""
        def _do_purge(c: Redis) -> int:
            queue_key = f"{PREFIX_QUEUE}{name}"
            scheduled_key = f"{PREFIX_SCHEDULED}{name}"

            # Get all task IDs
            task_ids = c.zrange(queue_key, 0, -1)
            scheduled_ids = c.zrange(scheduled_key, 0, -1)

            count = len(task_ids) + len(scheduled_ids)

            if task_ids:
                c.zrem(queue_key, *task_ids)
            if scheduled_ids:
                c.zrem(scheduled_key, *scheduled_ids)

            # Update queue info
            c.hset(f"{PREFIX_QUEUE}{name}", "last_activity", datetime.now(timezone.utc).isoformat())

            return count

        return self._pool.execute_with_retry(_do_purge)

    # ---------------------------------------------------------------------------
    # Dead Letter Queue
    # ---------------------------------------------------------------------------

    def move_to_dead_letter(self, task: Task, reason: str) -> None:
        """
        Move a task to the dead letter queue.

        Dead letter queue stores permanently failed tasks for later analysis.
        """
        def _do_move(c: Redis) -> None:
            dead_key = f"{PREFIX_DEAD}{task.queue_name}"

            # Create dead task record
            dead_record = {
                **task.to_dict(),
                "dead_reason": reason,
                "dead_at": datetime.now(timezone.utc).isoformat(),
                "total_attempts": task.attempt,
            }

            c.zadd(dead_key, {task.task_id: datetime.now(timezone.utc).timestamp()})
            c.hset(f"{PREFIX_DEAD}meta:{task.task_id}", mapping={
                "task_id": task.task_id,
                "queue_name": task.queue_name,
                "task_name": task.task_name,
                "reason": reason,
                "dead_at": dead_record["dead_at"],
                "total_attempts": str(task.attempt),
                "data": json.dumps(task.to_dict(), default=str),
            })

            # Clean up original task
            c.delete(f"{PREFIX_TASKS}{task.task_id}")
            c.delete(f"{PREFIX_LOCKS}{task.task_id}")

        self._pool.execute_with_retry(_do_move)

    def get_dead_letter_tasks(
        self,
        queue_name: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Dict[str, Any]]:
        """Get tasks from the dead letter queue."""
        def _do_get(c: Redis) -> List[Dict[str, Any]]:
            if queue_name:
                keys = [f"{PREFIX_DEAD}{queue_name}"]
            else:
                keys = []
                cursor = 0
                pattern = f"{PREFIX_DEAD}*"
                while True:
                    cursor, k = c.scan(cursor, match=pattern, count=100)
                    for key in k:
                        key_str = key.decode() if isinstance(key, bytes) else key
                        if not key_str.startswith(f"{PREFIX_DEAD}meta:"):
                            keys.append(key_str)
                    if cursor == 0:
                        break

            tasks = []
            for key in keys:
                task_ids = c.zrange(key, offset, offset + limit - 1)
                for task_id in task_ids:
                    tid = task_id.decode() if isinstance(task_id, bytes) else task_id
                    meta = c.hgetall(f"{PREFIX_DEAD}meta:{tid}")
                    if meta:
                        meta_decoded = {
                            k.decode() if isinstance(k, bytes) else k:
                            v.decode() if isinstance(v, bytes) else v
                            for k, v in meta.items()
                        }
                        tasks.append(meta_decoded)

            return tasks[offset:offset + limit]

        return self._pool.execute_with_retry(_do_get)

    def purge_dead_letter(self, queue_name: Optional[str] = None, before: Optional[datetime] = None) -> int:
        """Purge tasks from dead letter queue."""
        def _do_purge(c: Redis) -> int:
            count = 0
            if queue_name:
                keys = [f"{PREFIX_DEAD}{queue_name}"]
            else:
                keys = []
                cursor = 0
                pattern = f"{PREFIX_DEAD}*"
                while True:
                    cursor, k = c.scan(cursor, match=pattern, count=100)
                    for key in k:
                        key_str = key.decode() if isinstance(key, bytes) else key
                        if not key_str.startswith(f"{PREFIX_DEAD}meta:"):
                            keys.append(key_str)
                    if cursor == 0:
                        break

            for key in keys:
                task_ids = c.zrange(key, 0, -1)
                for task_id in task_ids:
                    tid = task_id.decode() if isinstance(task_id, bytes) else task_id
                    c.delete(f"{PREFIX_DEAD}meta:{tid}")
                    c.zrem(key, tid)
                    count += 1

            return count

        return self._pool.execute_with_retry(_do_purge)

    def restore_from_dead_letter(self, task_id: str) -> Optional[Task]:
        """
        Restore a task from the dead letter queue.

        Returns the restored task or None if not found.
        """
        def _do_restore(c: Redis) -> Optional[Task]:
            # Get metadata
            meta = c.hgetall(f"{PREFIX_DEAD}meta:{task_id}")
            if not meta:
                return None

            meta_decoded = {
                k.decode() if isinstance(k, bytes) else k:
                v.decode() if isinstance(v, bytes) else v
                for k, v in meta.items()
            }

            task_data = json.loads(meta_decoded["data"])
            task = Task.from_dict(task_data)

            # Remove from dead letter queue
            c.delete(f"{PREFIX_DEAD}meta:{task_id}")
            c.zrem(f"{PREFIX_DEAD}{task.queue_name}", task_id)

            # Re-enqueue
            task.status = TaskStatus.PENDING
            task.attempt = 0
            task.error = None
            task.traceback = None

            self.enqueue(task)

            return task

        return self._pool.execute_with_retry(_do_restore)

    # ---------------------------------------------------------------------------
    # Worker Management
    # ---------------------------------------------------------------------------

    def register_worker(
        self,
        worker_id: str,
        queues: List[str],
        concurrency: int = 4,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Register a worker with the backend."""
        def _do_register(c: Redis) -> None:
            worker_key = f"{PREFIX_WORKERS}{worker_id}"
            now = datetime.now(timezone.utc).isoformat()

            pipe = c.pipeline()
            pipe.hset(worker_key, mapping={
                "queues": json.dumps(queues),
                "concurrency": str(concurrency),
                "metadata": json.dumps(metadata or {}),
                "registered_at": now,
                "last_heartbeat": now,
                "status": "active",
            })
            pipe.expire(worker_key, 300)  # 5 minute TTL
            pipe.execute()

        self._pool.execute_with_retry(_do_register)

    def unregister_worker(self, worker_id: str) -> None:
        """Unregister a worker."""
        def _do_unregister(c: Redis) -> None:
            worker_key = f"{PREFIX_WORKERS}{worker_id}"
            c.delete(worker_key)

        self._pool.execute_with_retry(_do_unregister)

    def worker_heartbeat(
        self,
        worker_id: str,
        stats: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Update worker heartbeat."""
        def _do_heartbeat(c: Redis) -> None:
            worker_key = f"{PREFIX_WORKERS}{worker_id}"
            now = datetime.now(timezone.utc).isoformat()

            pipe = c.pipeline()
            pipe.hset(worker_key, "last_heartbeat", now)
            if stats:
                pipe.hset(worker_key, "stats", json.dumps(stats))
            pipe.expire(worker_key, 300)
            pipe.execute()

        self._pool.execute_with_retry(_do_heartbeat)

    def get_active_workers(self) -> List[Dict[str, Any]]:
        """Get all active workers."""
        def _do_get(c: Redis) -> List[Dict[str, Any]]:
            workers = []
            cursor = 0
            pattern = f"{PREFIX_WORKERS}*"

            while True:
                cursor, keys = c.scan(cursor, match=pattern, count=100)
                for key in keys:
                    key_str = key.decode() if isinstance(key, bytes) else key
                    data = c.hgetall(key_str)
                    if data:
                        decoded = {
                            k.decode() if isinstance(k, bytes) else k:
                            v.decode() if isinstance(v, bytes) else v
                            for k, v in data.items()
                        }
                        decoded["worker_id"] = key_str.replace(f"{PREFIX_WORKERS}", "")
                        workers.append(decoded)

                if cursor == 0:
                    break

            return workers

        return self._pool.execute_with_retry(_do_get)

    # ---------------------------------------------------------------------------
    # Statistics
    # ---------------------------------------------------------------------------

    def get_queue_stats(self, queue_name: str) -> Dict[str, Any]:
        """Get detailed statistics for a queue."""
        def _do_stats(c: Redis) -> Dict[str, Any]:
            stats_key = f"{PREFIX_STATS}{queue_name}"
            queue_key = f"{PREFIX_QUEUE}{queue_name}"

            stats = c.hgetall(stats_key)
            decoded = {
                k.decode() if isinstance(k, bytes) else k:
                v.decode() if isinstance(v, bytes) else v
                for k, v in stats.items()
            }

            pending = c.zcard(f"{PREFIX_QUEUE}{queue_name}")
            scheduled = c.zcard(f"{PREFIX_SCHEDULED}{queue_name}")

            return {
                "queue_name": queue_name,
                "pending": pending,
                "scheduled": scheduled,
                "total": pending + scheduled,
                "enqueued": int(decoded.get("enqueued", 0)),
                "completed": int(decoded.get("completed", 0)),
                "failed": int(decoded.get("failed", 0)),
                "retried": int(decoded.get("retried", 0)),
            }

        return self._pool.execute_with_retry(_do_stats)

    def get_global_stats(self) -> Dict[str, Any]:
        """Get global statistics across all queues."""
        def _do_stats(c: Redis) -> Dict[str, Any]:
            stats = {
                "total_enqueued": 0,
                "total_completed": 0,
                "total_failed": 0,
                "total_retried": 0,
                "queue_count": 0,
            }

            cursor = 0
            pattern = f"{PREFIX_STATS}*"

            while True:
                cursor, keys = c.scan(cursor, match=pattern, count=100)
                for key in keys:
                    key_str = key.decode() if isinstance(key, bytes) else key
                    name = key_str.replace(f"{PREFIX_STATS}", "")
                    if name and ":" not in name:
                        data = c.hgetall(key_str)
                        decoded = {
                            k.decode() if isinstance(k, bytes) else k:
                            v.decode() if isinstance(v, bytes) else v
                            for k, v in data.items()
                        }
                        stats["total_enqueued"] += int(decoded.get("enqueued", 0))
                        stats["total_completed"] += int(decoded.get("completed", 0))
                        stats["total_failed"] += int(decoded.get("failed", 0))
                        stats["total_retried"] += int(decoded.get("retried", 0))
                        stats["queue_count"] += 1

                if cursor == 0:
                    break

            return stats

        return self._pool.execute_with_retry(_do_stats)

    # ---------------------------------------------------------------------------
    # Pub/Sub Subscription
    # ---------------------------------------------------------------------------

    def subscribe_to_queue(
        self,
        queue_name: str,
        callback: Callable[[str, Dict[str, Any]], None],
    ) -> None:
        """
        Subscribe to queue events.

        Callback receives (event_type, event_data).
        """
        with self._lock:
            self._subscriber_callbacks.append(callback)

        if self._pubsub is None:
            self._start_pubsub()

    def _start_pubsub(self) -> None:
        """Start the Pub/Sub listener thread."""
        client = self._pool.get_client()
        self._pubsub = client.pubsub()

        def listener() -> None:
            while self._pubsub:
                try:
                    message = self._pubsub.get_message(timeout=1.0)
                    if message and message["type"] == "message":
                        data = json.loads(message["data"])
                        channel = message["channel"]
                        channel_name = channel.decode() if isinstance(channel, bytes) else channel
                        event_type = data.get("type", "unknown")

                        for callback in self._subscriber_callbacks:
                            try:
                                callback(event_type, data)
                            except Exception as exc:
                                logger.warning("Subscriber callback error: %s", exc)
                except Exception as exc:
                    logger.error("Pub/Sub listener error: %s", exc)
                    time.sleep(1)

        self._pubsub_thread = threading.Thread(target=listener, daemon=True)
        self._pubsub_thread.start()

    def unsubscribe_from_queue(self, queue_name: str) -> None:
        """Unsubscribe from queue events."""
        # In a full implementation, would track subscriptions per queue
        pass

    # ---------------------------------------------------------------------------
    # Cleanup and Maintenance
    # ---------------------------------------------------------------------------

    def clear_results(self, older_than_seconds: Optional[float] = None) -> int:
        """
        Clear old results to free memory.

        Args:
            older_than_seconds: Only clear results older than this many seconds.
                                If None, clears all results.

        Returns:
            Number of results cleared.
        """
        def _do_clear(c: Redis) -> int:
            count = 0
            cursor = 0
            pattern = f"{PREFIX_RESULTS}*"

            while True:
                cursor, keys = c.scan(cursor, match=pattern, count=100)
                for key in keys:
                    if older_than_seconds:
                        ttl = c.ttl(key)
                        if ttl > 0 and ttl <= older_than_seconds:
                            c.delete(key)
                            count += 1
                    else:
                        c.delete(key)
                        count += 1

                if cursor == 0:
                    break

            return count

        return self._pool.execute_with_retry(_do_clear)

    def cleanup_expired_leases(self) -> int:
        """
        Clean up expired task leases.

        Returns the number of leases cleaned up.
        """
        def _do_cleanup(c: Redis) -> int:
            count = 0
            now = int(datetime.now(timezone.utc).timestamp() * 1000)

            # Scan for expired locks
            cursor = 0
            pattern = f"{PREFIX_LOCKS}*"

            while True:
                cursor, keys = c.scan(cursor, match=pattern, count=100)
                for key in keys:
                    key_str = key.decode() if isinstance(key, bytes) else key
                    if key_str.startswith(f"{PREFIX_LOCKS}"):
                        task_id = key_str.replace(f"{PREFIX_LOCKS}", "")
                        lease_until = c.hget(f"{PREFIX_LOCKS}", task_id)
                        if lease_until:
                            lease_ts = int(lease_until.decode() if isinstance(lease_until, bytes) else lease_until)
                            if lease_ts < now:
                                c.hdel(f"{PREFIX_LOCKS}", task_id)
                                c.delete(f"{PREFIX_TASKS}{task_id}")
                                count += 1

                if cursor == 0:
                    break

            return count

        return self._pool.execute_with_retry(_do_cleanup)

    def ping(self) -> bool:
        """Check if Redis is reachable."""
        try:
            client = self._pool.get_client()
            return client.ping()
        except Exception:
            return False

    def close(self) -> None:
        """Close all connections and cleanup resources."""
        if self._pubsub:
            self._pubsub.close()
            self._pubsub = None
        self._pool.close()

    def __enter__(self) -> "RedisBackend":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


class RedisBackendFactory:
    """Factory for creating RedisBackend instances with common configurations."""

    @staticmethod
    def local(
        host: str = "localhost",
        port: int = 6379,
        db: int = 0,
    ) -> RedisBackend:
        """Create a backend for local development."""
        config = RedisConnectionConfig(
            host=host,
            port=port,
            db=db,
            max_connections=10,
        )
        return RedisBackend(config=config)

    @staticmethod
    def production(
        host: str = "localhost",
        port: int = 6379,
        password: Optional[str] = None,
        ssl: bool = True,
    ) -> RedisBackend:
        """Create a backend for production use."""
        config = RedisConnectionConfig(
            host=host,
            port=port,
            password=password,
            ssl=ssl,
            max_connections=50,
            socket_timeout=10.0,
            socket_connect_timeout=10.0,
            retry_on_timeout=True,
            max_retries=5,
            retry_delay=1.0,
            retry_backoff_factor=2.0,
        )
        return RedisBackend(
            config=config,
            result_ttl=86400,
            task_ttl=604800,
            dead_letter_threshold=5,
            enable_pubsub=True,
        )

    @staticmethod
    def sentinel(
        sentinel_nodes: List[Tuple[str, int]],
        master_name: str = "mymaster",
        **kwargs: Any,
    ) -> RedisBackend:
        """Create a backend using Redis Sentinel for high availability."""
        config = RedisConnectionConfig(
            sentinel_enabled=True,
            sentinel_master_name=master_name,
            sentinel_nodes=sentinel_nodes,
            max_connections=50,
            **kwargs,
        )
        return RedisBackend(
            config=config,
            enable_pubsub=True,
        )

    @staticmethod
    def cluster(
        startup_nodes: List[Tuple[str, int]],
        **kwargs: Any,
    ) -> RedisBackend:
        """Create a backend using Redis Cluster for horizontal scaling."""
        config = RedisConnectionConfig(
            cluster_enabled=True,
            cluster_startup_nodes=startup_nodes,
            max_connections=50,
            **kwargs,
        )
        return RedisBackend(
            config=config,
            enable_pubsub=True,
        )
