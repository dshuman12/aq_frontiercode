"""
In-memory backend for taskflow.

Suitable for development, testing, and single-process deployments.
Uses a priority queue internally; does not persist across restarts.
"""

from __future__ import annotations

import heapq
import threading
import time
from collections import defaultdict
from datetime import datetime, timezone
from typing import Dict, Iterator, List, Optional, Tuple

from taskflow.core.models import (
    Priority, QueueInfo, QueueStatus, Task, TaskResult, TaskStatus
)


class MemoryBackend:
    """
    Thread-safe in-memory task backend.

    Internally maintains:
    - A priority heap per queue for pending tasks
    - A dict of running tasks keyed by task_id
    - A result store keyed by task_id
    - Queue metadata
    """

    def __init__(self) -> None:
        self._lock = threading.RLock()
        # (priority_int, enqueue_time, task) heap per queue name
        self._queues: Dict[str, List[Tuple[int, float, Task]]] = defaultdict(list)
        self._running: Dict[str, Task] = {}
        self._results: Dict[str, TaskResult] = {}
        self._queue_info: Dict[str, QueueInfo] = {}
        self._all_tasks: Dict[str, Task] = {}
        self._paused_queues: set = set()

    # -----------------------------------------------------------------------
    # Queue management
    # -----------------------------------------------------------------------

    def declare_queue(
        self,
        name: str,
        max_concurrency: Optional[int] = None,
        tags: Optional[List[str]] = None,
    ) -> QueueInfo:
        """Create queue metadata if it doesn't exist."""
        with self._lock:
            if name not in self._queue_info:
                self._queue_info[name] = QueueInfo(
                    name=name,
                    max_concurrency=max_concurrency,
                    tags=tags or [],
                )
            return self._queue_info[name]

    def pause_queue(self, name: str) -> None:
        with self._lock:
            self._paused_queues.add(name)
            if name in self._queue_info:
                self._queue_info[name].status = QueueStatus.PAUSED

    def resume_queue(self, name: str) -> None:
        with self._lock:
            self._paused_queues.discard(name)
            if name in self._queue_info:
                self._queue_info[name].status = QueueStatus.ACTIVE

    def is_paused(self, name: str) -> bool:
        with self._lock:
            return name in self._paused_queues

    # -----------------------------------------------------------------------
    # Enqueue / Dequeue
    # -----------------------------------------------------------------------

    def enqueue(self, task: Task) -> None:
        """Add a task to its queue's priority heap."""
        with self._lock:
            task.status = TaskStatus.QUEUED
            task.queued_at = datetime.now(timezone.utc)
            q = self._queues[task.queue_name]
            heapq.heappush(q, (task.priority.value, time.monotonic(), task))
            self._all_tasks[task.task_id] = task
            info = self._queue_info.setdefault(
                task.queue_name, QueueInfo(name=task.queue_name)
            )
            info.pending_count += 1
            info.total_enqueued += 1
            info.last_activity = datetime.now(timezone.utc)

    def dequeue(self, queue_name: str, worker_id: str) -> Optional[Task]:
        """
        Pop the highest-priority ready task from the queue.

        Returns None if the queue is empty, paused, or all tasks have future ETAs.
        """
        with self._lock:
            if self.is_paused(queue_name):
                return None

            q = self._queues.get(queue_name, [])
            now = datetime.now(timezone.utc)

            # Find the first task that is ready (ETA passed)
            ready_tasks = []
            not_ready = []

            while q:
                entry = heapq.heappop(q)
                _, _, task = entry
                if task.eta and task.eta > now:
                    not_ready.append(entry)
                elif task.is_overdue:
                    task.status = TaskStatus.EXPIRED
                    self._finalize_task(task, worker_id)
                else:
                    ready_tasks.append(entry)
                    break

            # Put not-ready and unused ready tasks back
            for entry in not_ready:
                heapq.heappush(q, entry)
            for entry in ready_tasks[1:]:
                heapq.heappush(q, entry)

            if not ready_tasks:
                return None

            _, _, task = ready_tasks[0]
            task.status = TaskStatus.RUNNING
            task.started_at = datetime.now(timezone.utc)
            task.worker_id = worker_id
            task.attempt += 1
            self._running[task.task_id] = task

            info = self._queue_info.get(queue_name)
            if info:
                info.pending_count = max(0, info.pending_count - 1)
                info.running_count += 1

            return task

    def requeue(self, task: Task) -> None:
        """Re-enqueue a task (e.g. for retry)."""
        with self._lock:
            self._running.pop(task.task_id, None)
            info = self._queue_info.get(task.queue_name)
            if info:
                info.running_count = max(0, info.running_count - 1)
        self.enqueue(task)

    # -----------------------------------------------------------------------
    # Results
    # -----------------------------------------------------------------------

    def store_result(self, result: TaskResult) -> None:
        with self._lock:
            self._results[result.task_id] = result
            task = self._all_tasks.get(result.task_id)
            if task:
                task.status = result.status
                task.completed_at = result.completed_at
                task.error = result.error
                task.traceback = result.traceback
            self._running.pop(result.task_id, None)
            info = self._queue_info.get(task.queue_name if task else "")
            if info:
                info.running_count = max(0, info.running_count - 1)
                if result.status == TaskStatus.SUCCESS:
                    info.completed_count += 1
                elif result.status == TaskStatus.FAILURE:
                    info.failed_count += 1

    def get_result(self, task_id: str) -> Optional[TaskResult]:
        with self._lock:
            return self._results.get(task_id)

    def wait_for_result(
        self, task_id: str, timeout: float = 30.0, poll_interval: float = 0.1
    ) -> Optional[TaskResult]:
        """Block until a result is available or timeout expires."""
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            result = self.get_result(task_id)
            if result is not None:
                return result
            time.sleep(poll_interval)
        return None

    # -----------------------------------------------------------------------
    # Task lookup
    # -----------------------------------------------------------------------

    def get_task(self, task_id: str) -> Optional[Task]:
        with self._lock:
            return self._all_tasks.get(task_id)

    def list_tasks(
        self,
        queue_name: Optional[str] = None,
        status: Optional[TaskStatus] = None,
        limit: int = 100,
    ) -> List[Task]:
        with self._lock:
            tasks = list(self._all_tasks.values())
        if queue_name:
            tasks = [t for t in tasks if t.queue_name == queue_name]
        if status:
            tasks = [t for t in tasks if t.status == status]
        tasks.sort(key=lambda t: t.created_at, reverse=True)
        return tasks[:limit]

    def revoke(self, task_id: str) -> bool:
        """Mark a task as revoked so workers skip it."""
        with self._lock:
            task = self._all_tasks.get(task_id)
            if task is None:
                return False
            task.status = TaskStatus.REVOKED
            return True

    # -----------------------------------------------------------------------
    # Queue info
    # -----------------------------------------------------------------------

    def queue_info(self, name: str) -> Optional[QueueInfo]:
        with self._lock:
            return self._queue_info.get(name)

    def all_queue_info(self) -> List[QueueInfo]:
        with self._lock:
            return list(self._queue_info.values())

    def queue_length(self, name: str) -> int:
        with self._lock:
            return len(self._queues.get(name, []))

    def purge_queue(self, name: str) -> int:
        """Remove all pending tasks from a queue. Returns count removed."""
        with self._lock:
            q = self._queues.get(name, [])
            count = len(q)
            self._queues[name] = []
            info = self._queue_info.get(name)
            if info:
                info.pending_count = 0
            return count

    def clear_results(self, older_than_seconds: Optional[float] = None) -> int:
        """Remove stored results. Returns count cleared."""
        with self._lock:
            if older_than_seconds is None:
                count = len(self._results)
                self._results.clear()
                return count
            now = datetime.now(timezone.utc)
            stale = []
            for tid, result in self._results.items():
                if result.completed_at:
                    age = (now - result.completed_at).total_seconds()
                    if age > older_than_seconds:
                        stale.append(tid)
            for tid in stale:
                del self._results[tid]
            return len(stale)

    def _finalize_task(self, task: Task, worker_id: str) -> None:
        """Internal: move expired task to results store."""
        result = TaskResult(
            task_id=task.task_id,
            status=task.status,
            completed_at=datetime.now(timezone.utc),
            worker_id=worker_id,
        )
        self._results[task.task_id] = result

    def stats(self) -> dict:
        with self._lock:
            return {
                "total_tasks": len(self._all_tasks),
                "running": len(self._running),
                "stored_results": len(self._results),
                "queues": {
                    name: {
                        "pending": len(q),
                        "info": self._queue_info.get(name, QueueInfo(name=name)).to_dict(),
                    }
                    for name, q in self._queues.items()
                },
            }
