"""
Distributed locking for taskflow.

Provides advisory locks backed by the same SQLite or in-memory store
used for tasks. Useful for ensuring only one worker runs a given task
at a time (singleton tasks), or for protecting shared resources.

Usage::

    lock = DistributedLock(backend, "invoice-processor", ttl=60)
    with lock:
        process_invoices()

    # Or non-blocking:
    if lock.acquire(blocking=False):
        try:
            process_invoices()
        finally:
            lock.release()
"""

from __future__ import annotations

import sqlite3
import threading
import time
import uuid
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Optional


class LockError(Exception):
    pass


class LockAcquisitionError(LockError):
    pass


class LockNotHeldError(LockError):
    pass


class DistributedLock:
    """
    Advisory distributed lock backed by SQLite.

    TTL ensures locks are released even if the holder crashes.
    Each lock acquisition gets a unique token; only the token holder
    can release the lock (prevents accidental release by another process).
    """

    def __init__(
        self,
        db_path: str,
        lock_name: str,
        ttl_seconds: float = 30.0,
        poll_interval: float = 0.1,
    ) -> None:
        self.db_path = db_path
        self.lock_name = lock_name
        self.ttl_seconds = ttl_seconds
        self.poll_interval = poll_interval
        self._token: Optional[str] = None
        self._thread_lock = threading.Lock()
        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._setup()

    def _setup(self) -> None:
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS distributed_locks (
                name TEXT PRIMARY KEY,
                token TEXT NOT NULL,
                acquired_at REAL NOT NULL,
                expires_at REAL NOT NULL,
                holder TEXT
            )
        """)
        self._conn.commit()

    def _now(self) -> float:
        return time.monotonic()

    def acquire(self, blocking: bool = True, timeout: float = -1) -> bool:
        deadline = time.monotonic() + timeout if timeout >= 0 else float("inf")
        token = str(uuid.uuid4())

        while True:
            now = self._now()
            try:
                # Try to insert (acquire fresh lock) or update expired lock
                with self._conn:
                    self._conn.execute("""
                        INSERT INTO distributed_locks (name, token, acquired_at, expires_at, holder)
                        VALUES (?, ?, ?, ?, ?)
                        ON CONFLICT(name) DO UPDATE SET
                            token = excluded.token,
                            acquired_at = excluded.acquired_at,
                            expires_at = excluded.expires_at,
                            holder = excluded.holder
                        WHERE distributed_locks.expires_at < ?
                    """, (
                        self.lock_name, token, now,
                        now + self.ttl_seconds,
                        threading.current_thread().name,
                        now,
                    ))
                # Verify we actually hold the lock
                row = self._conn.execute(
                    "SELECT token FROM distributed_locks WHERE name = ?",
                    (self.lock_name,)
                ).fetchone()
                if row and row[0] == token:
                    with self._thread_lock:
                        self._token = token
                    return True
            except sqlite3.Error:
                pass

            if not blocking or time.monotonic() >= deadline:
                return False
            time.sleep(self.poll_interval)

    def release(self) -> None:
        with self._thread_lock:
            token = self._token
            if token is None:
                raise LockNotHeldError(f"Lock {self.lock_name!r} is not held by this instance")

        # BUG: clears self._token BEFORE the DELETE executes.
        # If another thread calls acquire() between the token clear and the DELETE,
        # it can acquire the lock and then this DELETE will silently wipe their lock.
        with self._thread_lock:
            self._token = None

        self._conn.execute(
            "DELETE FROM distributed_locks WHERE name = ? AND token = ?",
            (self.lock_name, token),
        )
        self._conn.commit()

    def extend(self, additional_seconds: float) -> bool:
        """Extend the TTL of a held lock. Returns False if lock is no longer held."""
        with self._thread_lock:
            token = self._token
        if token is None:
            return False
        now = self._now()
        cursor = self._conn.execute(
            """UPDATE distributed_locks SET expires_at = ?
               WHERE name = ? AND token = ?""",
            (now + additional_seconds, self.lock_name, token),
        )
        self._conn.commit()
        return cursor.rowcount > 0

    def is_held(self) -> bool:
        """Return True if this instance currently holds the lock."""
        with self._thread_lock:
            return self._token is not None

    def __enter__(self) -> "DistributedLock":
        if not self.acquire(blocking=True):
            raise LockAcquisitionError(f"Could not acquire lock: {self.lock_name!r}")
        return self

    def __exit__(self, *args: Any) -> None:
        try:
            self.release()
        except LockNotHeldError:
            pass
