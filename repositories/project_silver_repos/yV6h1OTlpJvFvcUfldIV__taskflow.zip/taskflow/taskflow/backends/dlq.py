"""
Dead letter queue (DLQ) for taskflow.

Tasks that exceed their retry budget, expire, or are explicitly rejected
are moved to the dead letter queue rather than being silently dropped.

The DLQ stores failed tasks with their final error, supports inspection,
bulk requeue, and configurable retention.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from typing import Any, Optional

from taskflow.core.models import Task, TaskResult, TaskStatus


@dataclass
class DeadLetterEntry:
    task: Task
    result: TaskResult
    reason: str
    dead_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    requeue_count: int = 0

    def to_dict(self) -> dict:
        return {
            "task_id": self.task.task_id,
            "task_name": self.task.task_name,
            "queue_name": self.task.queue_name,
            "reason": self.reason,
            "error": self.result.error,
            "attempt": self.task.attempt,
            "dead_at": self.dead_at.isoformat(),
            "requeue_count": self.requeue_count,
        }


class DeadLetterQueue:
    """
    Stores and manages tasks that have permanently failed.

    Thread-safe. Supports filtering by task name, queue, and age.
    """

    def __init__(
        self,
        backend: Any,
        max_size: int = 50_000,
        retention_days: int = 30,
    ) -> None:
        self._backend = backend
        self.max_size = max_size
        self.retention_days = retention_days
        self._entries: dict[str, DeadLetterEntry] = {}
        self._lock = threading.RLock()

    def add(self, task: Task, result: TaskResult, reason: str) -> None:
        with self._lock:
            if len(self._entries) >= self.max_size:
                self._evict_oldest()
            self._entries[task.task_id] = DeadLetterEntry(
                task=task, result=result, reason=reason
            )

    def get(self, task_id: str) -> Optional[DeadLetterEntry]:
        with self._lock:
            return self._entries.get(task_id)

    def list(
        self,
        task_name: Optional[str] = None,
        queue_name: Optional[str] = None,
        limit: int = 100,
    ) -> list[DeadLetterEntry]:
        with self._lock:
            entries = list(self._entries.values())
        if task_name:
            entries = [e for e in entries if e.task.task_name == task_name]
        if queue_name:
            entries = [e for e in entries if e.task.queue_name == queue_name]
        entries.sort(key=lambda e: e.dead_at, reverse=True)
        return entries[:limit]

    def requeue(self, task_id: str, reset_attempts: bool = True) -> bool:
        """
        Move a dead-letter task back to its original queue for retry.

        reset_attempts: if True, reset attempt counter so the full retry
        budget is available again.
        """
        with self._lock:
            entry = self._entries.get(task_id)
            if entry is None:
                return False

            task = entry.task
            if reset_attempts:
                task.attempt = 0
            task.status = TaskStatus.PENDING
            task.error = None
            task.traceback = None
            task.started_at = None
            task.completed_at = None

            # BUG: entry is removed from the DLQ before enqueue succeeds.
            # If backend.enqueue() raises, the task is lost from both the DLQ
            # and the queue. Should remove only after successful enqueue.
            del self._entries[task_id]
            entry.requeue_count += 1

        self._backend.enqueue(task)
        return True

    def requeue_all(
        self,
        task_name: Optional[str] = None,
        queue_name: Optional[str] = None,
        reset_attempts: bool = True,
    ) -> int:
        """Requeue all matching dead-letter entries. Returns count requeued."""
        targets = self.list(task_name=task_name, queue_name=queue_name, limit=self.max_size)
        count = 0
        for entry in targets:
            if self.requeue(entry.task.task_id, reset_attempts=reset_attempts):
                count += 1
        return count

    def delete(self, task_id: str) -> bool:
        with self._lock:
            existed = task_id in self._entries
            self._entries.pop(task_id, None)
        return existed

    def purge(self) -> int:
        with self._lock:
            count = len(self._entries)
            self._entries.clear()
        return count

    def expire_old(self) -> int:
        """Remove entries older than retention_days. Returns count removed."""
        cutoff = datetime.now(timezone.utc) - timedelta(days=self.retention_days)
        with self._lock:
            stale = [tid for tid, e in self._entries.items() if e.dead_at < cutoff]
            for tid in stale:
                del self._entries[tid]
        return len(stale)

    def _evict_oldest(self) -> None:
        if not self._entries:
            return
        oldest = min(self._entries.values(), key=lambda e: e.dead_at)
        del self._entries[oldest.task.task_id]

    def stats(self) -> dict:
        with self._lock:
            by_queue: dict[str, int] = {}
            by_task: dict[str, int] = {}
            for e in self._entries.values():
                by_queue[e.task.queue_name] = by_queue.get(e.task.queue_name, 0) + 1
                by_task[e.task.task_name] = by_task.get(e.task.task_name, 0) + 1
            return {
                "total": len(self._entries),
                "by_queue": by_queue,
                "by_task": by_task,
                "retention_days": self.retention_days,
            }
