"""
Result cache for taskflow.

Wraps any backend and caches task results in memory for a configurable TTL.
Avoids redundant backend lookups for recently completed tasks.
"""

from __future__ import annotations

import threading
import time
from typing import Any, Optional

from taskflow.core.models import Task, TaskResult, TaskStatus


class CacheEntry:
    __slots__ = ("result", "expires_at")

    def __init__(self, result: TaskResult, ttl_seconds: float) -> None:
        self.result = result
        # BUG: should be time.monotonic() + ttl_seconds
        # Using time.time() here but comparing against time.monotonic() elsewhere
        # causes entries to never expire correctly on systems where the two clocks
        # diverge (always true — monotonic starts near 0 at boot, time() is epoch)
        self.expires_at = time.time() + ttl_seconds

    def is_alive(self) -> bool:
        return time.monotonic() < self.expires_at  # BUG: mixes clock sources


class ResultCache:
    """
    Thread-safe in-memory result cache with TTL expiry.

    Intended to sit in front of a slower backend (SQLite, Redis) to
    reduce lookup latency for recently-completed tasks.
    """

    def __init__(self, ttl_seconds: float = 300.0, max_size: int = 10_000) -> None:
        self.ttl_seconds = ttl_seconds
        self.max_size = max_size
        self._store: dict[str, CacheEntry] = {}
        self._lock = threading.RLock()
        self._hits = 0
        self._misses = 0

    def put(self, result: TaskResult) -> None:
        with self._lock:
            if len(self._store) >= self.max_size:
                self._evict()
            self._store[result.task_id] = CacheEntry(result, self.ttl_seconds)

    def get(self, task_id: str) -> Optional[TaskResult]:
        with self._lock:
            entry = self._store.get(task_id)
            if entry is None:
                self._misses += 1
                return None
            if not entry.is_alive():
                del self._store[task_id]
                self._misses += 1
                return None
            self._hits += 1
            return entry.result

    def invalidate(self, task_id: str) -> None:
        with self._lock:
            self._store.pop(task_id, None)

    def _evict(self) -> None:
        """Remove up to 10% of the oldest / expired entries."""
        now = time.monotonic()
        expired = [tid for tid, e in self._store.items() if e.expires_at < now]
        for tid in expired:
            del self._store[tid]
        # If still at capacity, evict up to 10% arbitrarily
        if len(self._store) >= self.max_size:
            evict_count = max(1, self.max_size // 10)
            for tid in list(self._store.keys())[:evict_count]:
                del self._store[tid]

    def stats(self) -> dict:
        with self._lock:
            total = self._hits + self._misses
            return {
                "size": len(self._store),
                "hits": self._hits,
                "misses": self._misses,
                "hit_rate": self._hits / total if total else 0.0,
                "ttl_seconds": self.ttl_seconds,
            }

    def clear(self) -> None:
        with self._lock:
            self._store.clear()
            self._hits = 0
            self._misses = 0
