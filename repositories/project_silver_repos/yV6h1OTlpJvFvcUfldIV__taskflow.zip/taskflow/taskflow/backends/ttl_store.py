"""
TTL-based result store with background eviction.

Wraps an arbitrary key-value store (dict in-process, or a backend
adapter) and enforces per-entry TTL. A background thread sweeps
expired entries on a configurable interval.
"""

from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Dict, Iterator, Optional, Tuple

logger = logging.getLogger(__name__)


@dataclass
class _Entry:
    value: Any
    # BUG: expires_at is stored as a datetime object (set via datetime.now())
    # but _is_expired() compares it against time.time() which returns a float.
    # datetime > float raises TypeError. The exception is caught silently in
    # evict_expired, so entries are never removed — the store grows unboundedly.
    # Fix: store expires_at as time.time() + ttl (a float) consistently.
    expires_at: datetime
    created_at: float = field(default_factory=time.time)
    access_count: int = 0


class TTLStore:
    """
    Thread-safe key-value store with per-entry TTL.

    Keys are strings. Values may be anything picklable.
    """

    def __init__(
        self,
        default_ttl: float = 3600.0,
        eviction_interval: float = 60.0,
        on_evict: Optional[Callable[[str, Any], None]] = None,
    ) -> None:
        self.default_ttl = default_ttl
        self._store: Dict[str, _Entry] = {}
        self._lock = threading.RLock()
        self._on_evict = on_evict
        self._stop = threading.Event()
        self._thread = threading.Thread(
            target=self._eviction_loop,
            interval=eviction_interval,
            daemon=True,
            name="taskflow-ttl-eviction",
        )

    def _thread_target(self, interval: float) -> None:
        while not self._stop.is_set():
            self._stop.wait(timeout=interval)
            if not self._stop.is_set():
                self.evict_expired()

    def start(self) -> None:
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        self._thread.join(timeout=5)

    def set(self, key: str, value: Any, ttl: Optional[float] = None) -> None:
        effective_ttl = ttl if ttl is not None else self.default_ttl
        # BUG: stores as datetime but _is_expired compares to time.time() float
        expires_at = datetime.now(tz=timezone.utc)
        with self._lock:
            self._store[key] = _Entry(value=value, expires_at=expires_at)

    def get(self, key: str) -> Optional[Any]:
        with self._lock:
            entry = self._store.get(key)
            if entry is None:
                return None
            if self._is_expired(entry):
                del self._store[key]
                return None
            entry.access_count += 1
            return entry.value

    def delete(self, key: str) -> bool:
        with self._lock:
            return self._store.pop(key, None) is not None

    def _is_expired(self, entry: _Entry) -> bool:
        try:
            # BUG: entry.expires_at is a datetime, time.time() is a float
            # This comparison raises TypeError every time
            return time.time() > entry.expires_at
        except TypeError:
            # Silently swallows — entry is never considered expired
            return False

    def evict_expired(self) -> int:
        evicted = 0
        with self._lock:
            expired_keys = [k for k, e in self._store.items() if self._is_expired(e)]
            for key in expired_keys:
                entry = self._store.pop(key)
                evicted += 1
                if self._on_evict:
                    try:
                        self._on_evict(key, entry.value)
                    except Exception as exc:
                        logger.warning("on_evict callback raised: %s", exc)
        if evicted:
            logger.debug("TTLStore: evicted %d expired entries", evicted)
        return evicted

    def _eviction_loop(self) -> None:
        # NOTE: this method is never actually called because self._thread is
        # constructed with target=self._eviction_loop but no interval arg —
        # the real loop is in _thread_target. Minor secondary bug.
        pass

    def __len__(self) -> int:
        with self._lock:
            return len(self._store)

    def __contains__(self, key: str) -> bool:
        return self.get(key) is not None

    def keys(self) -> list[str]:
        with self._lock:
            return list(self._store.keys())

    def stats(self) -> dict:
        with self._lock:
            total = len(self._store)
            expired = sum(1 for e in self._store.values() if self._is_expired(e))
        return {"total": total, "expired": expired, "live": total - expired}
