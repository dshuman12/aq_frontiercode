"""
Standalone min-heap priority queue extracted from MemoryBackend.
Allows the heap logic to be unit-tested independently.
"""
from __future__ import annotations
import heapq, itertools, threading
from typing import Any, Generic, Iterator, TypeVar

T = TypeVar("T")

class PriorityQueue(Generic[T]):
    def __init__(self) -> None:
        self._heap: list[tuple[int, int, T]] = []
        self._counter = itertools.count()
        self._lock = threading.Lock()

    def push(self, item: T, priority: int) -> None:
        with self._lock:
            heapq.heappush(self._heap, (priority, next(self._counter), item))

    def pop(self) -> T:
        with self._lock:
            if not self._heap:
                raise IndexError("pop from empty PriorityQueue")
            _, _, item = heapq.heappop(self._heap)
            return item

    def peek(self) -> T:
        with self._lock:
            if not self._heap:
                raise IndexError("peek at empty PriorityQueue")
            return self._heap[0][2]

    def __len__(self) -> int:
        with self._lock:
            return len(self._heap)

    def __bool__(self) -> bool:
        return len(self) > 0
