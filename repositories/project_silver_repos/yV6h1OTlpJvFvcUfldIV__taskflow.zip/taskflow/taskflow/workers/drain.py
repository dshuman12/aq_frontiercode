"""
Worker drain mode: on shutdown signal, stop accepting new tasks
but allow all in-flight tasks to complete before exiting.
"""
from __future__ import annotations
import logging, threading, time
from typing import Callable, Optional

logger = logging.getLogger(__name__)

class DrainController:
    def __init__(self, max_drain_seconds: float = 120.0) -> None:
        self.max_drain = max_drain_seconds
        self._draining = threading.Event()
        self._idle_fn: Optional[Callable[[], bool]] = None

    def register_idle_fn(self, fn: Callable[[], bool]) -> None:
        """Register a function that returns True when all workers are idle."""
        self._idle_fn = fn

    def initiate(self) -> None:
        logger.info("DrainController: entering drain mode (max %.0fs)", self.max_drain)
        self._draining.set()

    def is_draining(self) -> bool:
        return self._draining.is_set()

    def wait_until_idle(self) -> bool:
        """Block until idle or max_drain exceeded. Returns True if cleanly drained."""
        deadline = time.monotonic() + self.max_drain
        while time.monotonic() < deadline:
            if self._idle_fn and self._idle_fn():
                logger.info("DrainController: all workers idle — clean drain complete")
                return True
            time.sleep(0.5)
        logger.warning("DrainController: drain timed out after %.0fs", self.max_drain)
        return False
