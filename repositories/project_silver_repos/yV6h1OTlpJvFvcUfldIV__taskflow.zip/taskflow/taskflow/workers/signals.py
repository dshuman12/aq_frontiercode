"""
POSIX signal handling for graceful worker shutdown.
Intercepts SIGTERM and SIGINT and sets a threading.Event
that workers poll to drain their in-flight tasks cleanly.
"""
from __future__ import annotations
import logging, signal, threading
from typing import Optional

logger = logging.getLogger(__name__)

_shutdown_event: Optional[threading.Event] = None

def get_shutdown_event() -> threading.Event:
    global _shutdown_event
    if _shutdown_event is None:
        _shutdown_event = threading.Event()
    return _shutdown_event

def _handler(signum, frame):
    name = signal.Signals(signum).name
    logger.info("Received %s — initiating graceful shutdown", name)
    get_shutdown_event().set()

def install_signal_handlers() -> threading.Event:
    """Install handlers and return the shared shutdown event."""
    ev = get_shutdown_event()
    signal.signal(signal.SIGTERM, _handler)
    signal.signal(signal.SIGINT,  _handler)
    return ev
