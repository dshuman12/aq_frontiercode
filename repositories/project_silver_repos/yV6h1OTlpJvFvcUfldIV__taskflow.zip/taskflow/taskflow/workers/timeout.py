"""
Per-task timeout enforcement using a background watchdog thread.
If a task function runs longer than its configured timeout_seconds,
the watchdog raises TimeoutError in the calling thread.
"""
from __future__ import annotations
import ctypes, threading
from typing import Optional

class TaskTimeout(Exception):
    pass

def _raise_in_thread(tid: int, exc_type: type) -> None:
    res = ctypes.pythonapi.PyThreadState_SetAsyncExc(
        ctypes.c_ulong(tid), ctypes.py_object(exc_type)
    )
    if res == 0:
        raise ValueError(f"Invalid thread id: {tid}")

class WatchdogTimer:
    def __init__(self, seconds: float, thread_id: int) -> None:
        self.seconds = seconds
        self.thread_id = thread_id
        self._timer: Optional[threading.Timer] = None

    def start(self) -> None:
        self._timer = threading.Timer(
            self.seconds,
            _raise_in_thread,
            args=(self.thread_id, TaskTimeout),
        )
        self._timer.daemon = True
        self._timer.start()

    def cancel(self) -> None:
        if self._timer:
            self._timer.cancel()
