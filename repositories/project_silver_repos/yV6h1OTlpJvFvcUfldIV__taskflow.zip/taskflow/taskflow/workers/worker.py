"""
Worker — executes tasks dequeued from a backend.

Supports thread-pool and single-threaded execution modes,
graceful shutdown, signal handling, middleware chains, and heartbeating.
"""

from __future__ import annotations

import logging
import os
import signal
import threading
import time
import traceback
import uuid
from concurrent.futures import Future, ThreadPoolExecutor
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional, Set

from taskflow.core.models import Priority, Task, TaskResult, TaskStatus
from taskflow.core.registry import TaskRegistry, TaskNotFoundError, get_registry

logger = logging.getLogger(__name__)


class WorkerError(Exception):
    """Raised for worker configuration or runtime errors."""


class ShutdownSignal(Exception):
    """Internal signal to initiate graceful shutdown."""


class WorkerStats:
    """Tracks worker performance counters."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self.tasks_executed: int = 0
        self.tasks_succeeded: int = 0
        self.tasks_failed: int = 0
        self.tasks_retried: int = 0
        self.tasks_expired: int = 0
        self.total_run_time: float = 0.0
        self.started_at: datetime = datetime.now(timezone.utc)

    def record_success(self, run_time: float) -> None:
        with self._lock:
            self.tasks_executed += 1
            self.tasks_succeeded += 1
            self.total_run_time += run_time

    def record_failure(self, run_time: float) -> None:
        with self._lock:
            self.tasks_executed += 1
            self.tasks_failed += 1
            self.total_run_time += run_time

    def record_retry(self) -> None:
        with self._lock:
            self.tasks_retried += 1

    @property
    def average_run_time(self) -> float:
        with self._lock:
            if self.tasks_executed == 0:
                return 0.0
            return self.total_run_time / self.tasks_executed

    @property
    def uptime_seconds(self) -> float:
        return (datetime.now(timezone.utc) - self.started_at).total_seconds()

    def to_dict(self) -> dict:
        with self._lock:
            return {
                "tasks_executed": self.tasks_executed,
                "tasks_succeeded": self.tasks_succeeded,
                "tasks_failed": self.tasks_failed,
                "tasks_retried": self.tasks_retried,
                "average_run_time_seconds": round(self.average_run_time, 3),
                "uptime_seconds": round(self.uptime_seconds, 1),
                "started_at": self.started_at.isoformat(),
            }


class TaskExecutionContext:
    """
    Context object passed to middleware and available during task execution.

    Provides access to the task, worker, and mutable state that middleware
    can read and modify.
    """

    def __init__(self, task: Task, worker_id: str) -> None:
        self.task = task
        self.worker_id = worker_id
        self.start_time: float = time.monotonic()
        self.extra: Dict[str, Any] = {}

    @property
    def elapsed_seconds(self) -> float:
        return time.monotonic() - self.start_time


class Worker:
    """
    Pulls tasks from one or more queues and executes them.

    Execution model:
    - A main loop thread polls queues in round-robin order
    - Each task is submitted to a ThreadPoolExecutor
    - Results are stored back via the backend
    - Retries are re-enqueued with updated ETA
    """

    def __init__(
        self,
        backend: Any,
        queues: Optional[List[str]] = None,
        concurrency: int = 4,
        poll_interval: float = 0.5,
        worker_id: Optional[str] = None,
        registry: Optional[TaskRegistry] = None,
        middleware: Optional[List[Callable]] = None,
        prefetch_limit: int = 1,
        heartbeat_interval: float = 30.0,
    ) -> None:
        self.backend = backend
        self.queues = queues or ["default"]
        self.concurrency = concurrency
        self.poll_interval = poll_interval
        self.worker_id = worker_id or f"worker-{uuid.uuid4().hex[:8]}"
        self.registry = registry or get_registry()
        self.middleware = middleware or []
        self.prefetch_limit = prefetch_limit
        self.heartbeat_interval = heartbeat_interval

        self._executor: Optional[ThreadPoolExecutor] = None
        self._shutdown_event = threading.Event()
        self._active_futures: Set[Future] = set()
        self._futures_lock = threading.Lock()
        self.stats = WorkerStats()
        self._queue_index = 0

        logger.info(
            "Worker %s initialised | queues=%s concurrency=%d",
            self.worker_id, self.queues, self.concurrency,
        )

    # -----------------------------------------------------------------------
    # Lifecycle
    # -----------------------------------------------------------------------

    def start(self, block: bool = True) -> None:
        """Start the worker. If block=True, runs until shutdown."""
        self._executor = ThreadPoolExecutor(
            max_workers=self.concurrency,
            thread_name_prefix=f"taskflow-{self.worker_id}",
        )
        self._install_signal_handlers()

        logger.info("Worker %s started", self.worker_id)

        if block:
            self._run_loop()
        else:
            t = threading.Thread(target=self._run_loop, daemon=True, name=f"{self.worker_id}-loop")
            t.start()

    def stop(self, timeout: float = 30.0) -> None:
        """Signal graceful shutdown and wait for in-flight tasks."""
        logger.info("Worker %s shutting down...", self.worker_id)
        self._shutdown_event.set()
        if self._executor:
            self._executor.shutdown(wait=True, cancel_futures=False)
        logger.info("Worker %s stopped. Stats: %s", self.worker_id, self.stats.to_dict())

    def _install_signal_handlers(self) -> None:
        try:
            signal.signal(signal.SIGTERM, self._handle_signal)
            signal.signal(signal.SIGINT, self._handle_signal)
        except (OSError, ValueError):
            pass  # Not in main thread or unsupported platform

    def _handle_signal(self, signum: int, frame: Any) -> None:
        logger.info("Worker %s received signal %d, shutting down", self.worker_id, signum)
        self._shutdown_event.set()

    # -----------------------------------------------------------------------
    # Main loop
    # -----------------------------------------------------------------------

    def _run_loop(self) -> None:
        heartbeat_thread = threading.Thread(
            target=self._heartbeat_loop, daemon=True, name=f"{self.worker_id}-heartbeat"
        )
        heartbeat_thread.start()

        while not self._shutdown_event.is_set():
            try:
                self._poll_once()
            except Exception as exc:
                logger.error("Worker %s poll error: %s", self.worker_id, exc, exc_info=True)
            self._shutdown_event.wait(timeout=self.poll_interval)

    def _poll_once(self) -> None:
        """Check one queue for a task and submit it for execution."""
        if not self.queues:
            return

        # Round-robin through queues
        queue_name = self.queues[self._queue_index % len(self.queues)]
        self._queue_index += 1

        # Check concurrency cap
        with self._futures_lock:
            active = sum(1 for f in self._active_futures if not f.done())
        if active >= self.concurrency:
            return

        task = self.backend.dequeue(queue_name, self.worker_id)
        if task is None:
            return

        logger.debug("Worker %s dequeued task %s (%s)", self.worker_id, task.task_id, task.task_name)

        future = self._executor.submit(self._execute_task, task)
        with self._futures_lock:
            self._active_futures.add(future)
            def _remove_future(f):
                with self._futures_lock:
                    self._active_futures.discard(f)
            future.add_done_callback(_remove_future)

    def _heartbeat_loop(self) -> None:
        while not self._shutdown_event.is_set():
            logger.debug("Worker %s heartbeat | stats=%s", self.worker_id, self.stats.to_dict())
            self._shutdown_event.wait(timeout=self.heartbeat_interval)

    # -----------------------------------------------------------------------
    # Task execution
    # -----------------------------------------------------------------------

    def _execute_task(self, task: Task) -> None:
        ctx = TaskExecutionContext(task, self.worker_id)
        start = time.monotonic()

        try:
            self._run_before_middleware(ctx)
            return_value = self._call_task(task)
            elapsed = time.monotonic() - start

            result = TaskResult(
                task_id=task.task_id,
                status=TaskStatus.SUCCESS,
                return_value=return_value,
                started_at=task.started_at,
                completed_at=datetime.now(timezone.utc),
                worker_id=self.worker_id,
            )
            self.backend.store_result(result)
            self.stats.record_success(elapsed)
            self._run_after_middleware(ctx, result)
            logger.info(
                "Task %s succeeded in %.3fs (attempt %d)",
                task.task_id, elapsed, task.attempt,
            )

        except Exception as exc:
            elapsed = time.monotonic() - start
            tb = traceback.format_exc()
            logger.warning(
                "Task %s failed (attempt %d/%d): %s",
                task.task_id, task.attempt, task.max_retries, exc,
            )

            should_retry = (
                task.can_retry()
                and task.retry_policy.should_retry_on(exc)
            )

            if should_retry:
                task.status = TaskStatus.RETRY
                task.error = str(exc)
                task.eta = task.next_retry_eta()
                self.backend.requeue(task)
                self.stats.record_retry()
                logger.info(
                    "Task %s scheduled for retry %d/%d at %s",
                    task.task_id, task.attempt, task.max_retries, task.eta,
                )
            else:
                result = TaskResult(
                    task_id=task.task_id,
                    status=TaskStatus.FAILURE,
                    error=str(exc),
                    traceback=tb,
                    started_at=task.started_at,
                    completed_at=datetime.now(timezone.utc),
                    worker_id=self.worker_id,
                )
                self.backend.store_result(result)
                self.stats.record_failure(elapsed)
                self._run_after_middleware(ctx, result)

    def _call_task(self, task: Task) -> Any:
        """Look up the task definition and call it with args/kwargs."""
        if task.is_overdue:
            raise WorkerError(f"Task {task.task_id} expired before execution")

        defn = self.registry.get(task.task_name)

        if task.timeout_seconds:
            result_holder: list = []
            error_holder: list = []
            done_event = threading.Event()

            def run() -> None:
                try:
                    result_holder.append(defn.func(*task.args, **task.kwargs))
                except Exception as e:
                    error_holder.append(e)
                finally:
                    done_event.set()

            t = threading.Thread(target=run, daemon=True)
            t.start()
            finished = done_event.wait(timeout=task.timeout_seconds)
            if not finished:
                raise TimeoutError(
                    f"Task {task.task_name} timed out after {task.timeout_seconds}s"
                )
            if error_holder:
                raise error_holder[0]
            return result_holder[0] if result_holder else None
        else:
            return defn.func(*task.args, **task.kwargs)

    # -----------------------------------------------------------------------
    # Middleware hooks
    # -----------------------------------------------------------------------

    def _run_before_middleware(self, ctx: TaskExecutionContext) -> None:
        for mw in self.middleware:
            if hasattr(mw, "before_task"):
                try:
                    mw.before_task(ctx)
                except Exception as e:
                    logger.warning("Middleware before_task error: %s", e)

    def _run_after_middleware(self, ctx: TaskExecutionContext, result: TaskResult) -> None:
        for mw in reversed(self.middleware):
            if hasattr(mw, "after_task"):
                try:
                    mw.after_task(ctx, result)
                except Exception as e:
                    logger.warning("Middleware after_task error: %s", e)
