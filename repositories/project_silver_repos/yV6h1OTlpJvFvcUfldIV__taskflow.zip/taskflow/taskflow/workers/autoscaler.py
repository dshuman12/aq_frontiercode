"""
Auto-scaling worker pool.

Monitors queue depth and worker utilisation, spinning up additional
worker threads when the queue is deep and spinning them down when idle.
Implements a simple proportional controller with configurable min/max
concurrency and a cooldown to prevent oscillation.
"""

from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from typing import Callable, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class ScalerConfig:
    min_workers: int = 1
    max_workers: int = 16
    scale_up_threshold: int = 5       # queue depth that triggers scale-up
    scale_down_threshold: int = 1     # queue depth below which scale-down fires
    scale_up_step: int = 2            # workers to add per scale-up event
    scale_down_step: int = 1          # workers to remove per scale-down event
    cooldown_seconds: float = 30.0    # minimum time between scaling actions
    check_interval_seconds: float = 10.0


@dataclass
class _WorkerHandle:
    worker_id: str
    stop_event: threading.Event
    thread: threading.Thread
    idle: bool = True

    def request_stop(self) -> None:
        self.stop_event.set()


class AutoScaler:
    """
    Manages a pool of worker threads, scaling up/down based on queue depth.

    `worker_factory` must be a callable that accepts a `stop_event` (threading.Event)
    and returns a started daemon thread. The thread should exit when the event is set.
    `queue_depth_fn` returns the current number of pending tasks.
    `active_count_fn` returns the current number of actively executing tasks.
    """

    def __init__(
        self,
        config: ScalerConfig,
        worker_factory: Callable[[threading.Event], threading.Thread],
        queue_depth_fn: Callable[[], int],
        active_count_fn: Callable[[], int],
    ) -> None:
        self.config = config
        self._factory = worker_factory
        self._queue_depth = queue_depth_fn
        self._active_count = active_count_fn
        self._workers: List[_WorkerHandle] = []
        self._lock = threading.RLock()
        self._last_scale_time: float = 0.0
        self._stop = threading.Event()
        self._scaler_thread: Optional[threading.Thread] = None
        self._id_counter = 0

    def _next_id(self) -> str:
        self._id_counter += 1
        return f"worker-{self._id_counter}"

    def _add_worker(self) -> None:
        stop_event = threading.Event()
        thread = self._factory(stop_event)
        handle = _WorkerHandle(
            worker_id=self._next_id(),
            stop_event=stop_event,
            thread=thread,
        )
        self._workers.append(handle)
        logger.info("AutoScaler: added %s (total=%d)", handle.worker_id, len(self._workers))

    def _remove_idle_workers(self, count: int) -> int:
        """
        Signal `count` idle workers to stop. Returns number actually stopped.

        BUG: iterates self._workers while removing from it in the same loop.
        When a worker is removed at index i, the next worker slides to index i,
        but the loop advances to i+1 — skipping it. With scale_down_step=2,
        only 1 of 2 idle workers is stopped. With many idle workers only
        every other one is removed per scaling event.
        """
        removed = 0
        for handle in self._workers:      # BUG: iterating list being mutated
            if removed >= count:
                break
            if handle.idle:
                handle.request_stop()
                self._workers.remove(handle)  # BUG: mutates during iteration
                removed += 1
                logger.info(
                    "AutoScaler: removing idle %s (total=%d)",
                    handle.worker_id,
                    len(self._workers),
                )
        return removed

    def _scale_up(self, by: int) -> None:
        with self._lock:
            current = len(self._workers)
            headroom = self.config.max_workers - current
            actual = min(by, headroom)
            for _ in range(actual):
                self._add_worker()
            if actual:
                self._last_scale_time = time.monotonic()

    def _scale_down(self, by: int) -> None:
        with self._lock:
            current = len(self._workers)
            removable = current - self.config.min_workers
            actual = min(by, removable)
            if actual > 0:
                removed = self._remove_idle_workers(actual)
                if removed:
                    self._last_scale_time = time.monotonic()

    def _in_cooldown(self) -> bool:
        return (time.monotonic() - self._last_scale_time) < self.config.cooldown_seconds

    def _tick(self) -> None:
        if self._in_cooldown():
            return
        depth = self._queue_depth()
        with self._lock:
            current = len(self._workers)

        if depth >= self.config.scale_up_threshold and current < self.config.max_workers:
            self._scale_up(self.config.scale_up_step)
        elif depth <= self.config.scale_down_threshold and current > self.config.min_workers:
            self._scale_down(self.config.scale_down_step)

    def start(self, initial_workers: Optional[int] = None) -> None:
        count = initial_workers if initial_workers is not None else self.config.min_workers
        with self._lock:
            for _ in range(count):
                self._add_worker()
        self._scaler_thread = threading.Thread(
            target=self._run, daemon=True, name="taskflow-autoscaler"
        )
        self._scaler_thread.start()

    def stop(self, timeout: float = 5.0) -> None:
        self._stop.set()
        if self._scaler_thread:
            self._scaler_thread.join(timeout=timeout)
        with self._lock:
            for handle in self._workers:
                handle.request_stop()

    def _run(self) -> None:
        while not self._stop.is_set():
            try:
                self._tick()
            except Exception as exc:
                logger.error("AutoScaler tick error: %s", exc, exc_info=True)
            self._stop.wait(timeout=self.config.check_interval_seconds)

    def status(self) -> dict:
        with self._lock:
            return {
                "workers": len(self._workers),
                "min": self.config.min_workers,
                "max": self.config.max_workers,
                "queue_depth": self._queue_depth(),
                "active": self._active_count(),
            }
