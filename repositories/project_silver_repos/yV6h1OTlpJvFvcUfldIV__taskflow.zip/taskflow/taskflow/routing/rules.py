"""
Routing rules engine: determines which queue a task should be sent to.
Rules are evaluated in order; the first match wins.
"""
from __future__ import annotations
import re
from dataclasses import dataclass, field
from typing import Callable, List, Optional
from taskflow.core.models import Task

@dataclass
class RoutingRule:
    queue: str
    name_pattern: Optional[str] = None       # regex matched against task.name
    tags: Optional[List[str]] = None          # task must have ALL of these tags
    predicate: Optional[Callable[[Task], bool]] = None  # arbitrary callable
    _compiled: Optional[re.Pattern] = field(default=None, init=False, repr=False)

    def __post_init__(self):
        if self.name_pattern:
            self._compiled = re.compile(self.name_pattern)

    def matches(self, task: Task) -> bool:
        if self._compiled and not self._compiled.search(task.name):
            return False
        if self.tags and not all(t in task.tags for t in self.tags):
            return False
        if self.predicate and not self.predicate(task):
            return False
        return True

class RuleRouter:
    def __init__(self, rules: List[RoutingRule], default_queue: str = "default") -> None:
        self._rules = rules
        self._default = default_queue

    def route(self, task: Task) -> str:
        for rule in self._rules:
            if rule.matches(task):
                return rule.queue
        return self._default

    def add_rule(self, rule: RoutingRule, position: int = -1) -> None:
        if position < 0:
            self._rules.append(rule)
        else:
            self._rules.insert(position, rule)
