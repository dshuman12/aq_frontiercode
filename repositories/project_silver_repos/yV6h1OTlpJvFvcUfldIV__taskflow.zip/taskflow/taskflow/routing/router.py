"""
Task routing for taskflow.

Provides dynamic task routing based on task attributes,
content-based routing, weighted routing, and fan-out patterns.

Features:
- Route tasks to different queues based on rules
- Content-based routing with predicates
- Weighted routing for load balancing
- Fan-out: broadcast task to multiple queues
- Route merging and composition
- Dynamic queue discovery
"""

from __future__ import annotations

import fnmatch
import hashlib
import json
import logging
import re
import threading
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, Union

from taskflow.core.models import Priority, Task

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Route Result
# ---------------------------------------------------------------------------

@dataclass
class RouteResult:
    """Result of a routing decision."""
    queue_name: str
    priority: Priority = Priority.NORMAL
    metadata: Dict[str, Any] = field(default_factory=dict)
    routing_reason: Optional[str] = None
    matched_rules: List[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Routing Predicates
# ---------------------------------------------------------------------------

class Predicate(ABC):
    """Abstract base class for routing predicates."""

    @abstractmethod
    def matches(self, task: Task) -> bool:
        """Check if a task matches this predicate."""
        pass

    @abstractmethod
    def to_dict(self) -> dict:
        """Serialize to dictionary."""
        pass

    @classmethod
    def from_dict(cls, data: dict) -> "Predicate":
        """Deserialize from dictionary."""
        pred_type = data.get("type")
        if pred_type == "task_name":
            return TaskNamePredicate.from_dict(data)
        elif pred_type == "tag":
            return TagPredicate.from_dict(data)
        elif pred_type == "argument":
            return ArgumentPredicate.from_dict(data)
        elif pred_type == "priority":
            return PriorityPredicate.from_dict(data)
        elif pred_type == "regex":
            return RegexPredicate.from_dict(data)
        elif pred_type == "and":
            return AndPredicate.from_dict(data)
        elif pred_type == "or":
            return OrPredicate.from_dict(data)
        elif pred_type == "not":
            return NotPredicate.from_dict(data)
        else:
            raise ValueError(f"Unknown predicate type: {pred_type}")


@dataclass
class TaskNamePredicate(Predicate):
    """Match tasks by name pattern."""
    pattern: str
    use_glob: bool = True

    def matches(self, task: Task) -> bool:
        if self.use_glob:
            return fnmatch.fnmatch(task.task_name, self.pattern)
        else:
            return task.task_name == self.pattern

    def to_dict(self) -> dict:
        return {
            "type": "task_name",
            "pattern": self.pattern,
            "use_glob": self.use_glob,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "TaskNamePredicate":
        return cls(
            pattern=data["pattern"],
            use_glob=data.get("use_glob", True),
        )


@dataclass
class TagPredicate(Predicate):
    """Match tasks that have specific tags."""
    tags: Set[str]
    match_all: bool = False

    def matches(self, task: Task) -> bool:
        task_tags = set(task.tags)
        if self.match_all:
            return self.tags.issubset(task_tags)
        else:
            return bool(self.tags & task_tags)

    def to_dict(self) -> dict:
        return {
            "type": "tag",
            "tags": list(self.tags),
            "match_all": self.match_all,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "TagPredicate":
        return cls(
            tags=set(data["tags"]),
            match_all=data.get("match_all", False),
        )


@dataclass
class ArgumentPredicate(Predicate):
    """Match tasks based on argument values."""
    argument_path: str  # e.g., "args[0]" or "kwargs.user_id"
    operator: str = "eq"  # eq, ne, gt, lt, gte, lte, contains, in
    value: Any = None
    regex: Optional[str] = None

    def matches(self, task: Task) -> bool:
        arg_value = self._get_argument(task)
        if arg_value is None:
            return False

        if self.operator == "eq":
            return arg_value == self.value
        elif self.operator == "ne":
            return arg_value != self.value
        elif self.operator == "gt":
            return arg_value > self.value
        elif self.operator == "lt":
            return arg_value < self.value
        elif self.operator == "gte":
            return arg_value >= self.value
        elif self.operator == "lte":
            return arg_value <= self.value
        elif self.operator == "contains":
            return self.value in arg_value
        elif self.operator == "in":
            return arg_value in self.value
        elif self.operator == "regex" and self.regex:
            return bool(re.match(self.regex, str(arg_value)))
        elif self.operator == "exists":
            return arg_value is not None
        elif self.operator == "truthy":
            return bool(arg_value)

        return False

    def _get_argument(self, task: Task) -> Any:
        if self.argument_path.startswith("args["):
            match = re.match(r"args\[(\d+)\]", self.argument_path)
            if match:
                idx = int(match.group(1))
                return task.args[idx] if idx < len(task.args) else None
        elif self.argument_path.startswith("kwargs."):
            key = self.argument_path[7:]
            return task.kwargs.get(key)
        elif self.argument_path.startswith("metadata."):
            key = self.argument_path[9:]
            return task.metadata.get(key)
        return None

    def to_dict(self) -> dict:
        return {
            "type": "argument",
            "argument_path": self.argument_path,
            "operator": self.operator,
            "value": self.value,
            "regex": self.regex,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "ArgumentPredicate":
        return cls(
            argument_path=data["argument_path"],
            operator=data.get("operator", "eq"),
            value=data.get("value"),
            regex=data.get("regex"),
        )


@dataclass
class PriorityPredicate(Predicate):
    """Match tasks based on priority."""
    priorities: Set[int]

    def matches(self, task: Task) -> bool:
        return task.priority.value in self.priorities

    def to_dict(self) -> dict:
        return {
            "type": "priority",
            "priorities": list(self.priorities),
        }

    @classmethod
    def from_dict(cls, data: dict) -> "PriorityPredicate":
        return cls(priorities=set(data["priorities"]))


@dataclass
class RegexPredicate(Predicate):
    """Match tasks using regex on task name."""
    pattern: str
    flags: int = 0
    _compiled: Optional[re.Pattern] = field(default=None, repr=False)

    def __post_init__(self) -> None:
        self._compiled = re.compile(self.pattern, self.flags)

    def matches(self, task: Task) -> bool:
        return bool(self._compiled.search(task.task_name))

    def to_dict(self) -> dict:
        return {
            "type": "regex",
            "pattern": self.pattern,
            "flags": self.flags,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "RegexPredicate":
        return cls(
            pattern=data["pattern"],
            flags=data.get("flags", 0),
        )


@dataclass
class AndPredicate(Predicate):
    """Match if all predicates match."""
    predicates: List[Predicate]

    def matches(self, task: Task) -> bool:
        return all(p.matches(task) for p in self.predicates)

    def to_dict(self) -> dict:
        return {
            "type": "and",
            "predicates": [p.to_dict() for p in self.predicates],
        }

    @classmethod
    def from_dict(cls, data: dict) -> "AndPredicate":
        return cls(
            predicates=[Predicate.from_dict(p) for p in data["predicates"]],
        )


@dataclass
class OrPredicate(Predicate):
    """Match if any predicate matches."""
    predicates: List[Predicate]

    def matches(self, task: Task) -> bool:
        return any(p.matches(task) for p in self.predicates)

    def to_dict(self) -> dict:
        return {
            "type": "or",
            "predicates": [p.to_dict() for p in self.predicates],
        }

    @classmethod
    def from_dict(cls, data: dict) -> "OrPredicate":
        return cls(
            predicates=[Predicate.from_dict(p) for p in data["predicates"]],
        )


@dataclass
class NotPredicate(Predicate):
    """Invert a predicate."""
    predicate: Predicate

    def matches(self, task: Task) -> bool:
        return not self.predicate.matches(task)

    def to_dict(self) -> dict:
        return {
            "type": "not",
            "predicate": self.predicate.to_dict(),
        }

    @classmethod
    def from_dict(cls, data: dict) -> "NotPredicate":
        return cls(predicate=Predicate.from_dict(data["predicate"]))


# ---------------------------------------------------------------------------
# Routing Rules
# ---------------------------------------------------------------------------

@dataclass
class RoutingRule:
    """
    A single routing rule.

    Maps a predicate to a destination queue and optional modifications.
    """
    rule_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: Optional[str] = None
    predicate: Optional[Predicate] = None
    queue_name: str = "default"
    priority: Priority = Priority.NORMAL
    priority_override: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)
    weight: float = 1.0  # For weighted routing
    enabled: bool = True
    description: Optional[str] = None

    def matches(self, task: Task) -> bool:
        if not self.enabled:
            return False
        if self.predicate is None:
            return True  # No predicate = always match
        return self.predicate.matches(task)

    def apply(self, task: Task) -> RouteResult:
        """Apply this rule to a task."""
        return RouteResult(
            queue_name=self.queue_name,
            priority=self.priority if self.priority_override else task.priority,
            metadata={**task.metadata, **self.metadata},
            routing_reason=self.name or self.rule_id,
            matched_rules=[self.rule_id],
        )

    def to_dict(self) -> dict:
        return {
            "rule_id": self.rule_id,
            "name": self.name,
            "predicate": self.predicate.to_dict() if self.predicate else None,
            "queue_name": self.queue_name,
            "priority": self.priority.value,
            "priority_override": self.priority_override,
            "metadata": self.metadata,
            "weight": self.weight,
            "enabled": self.enabled,
            "description": self.description,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "RoutingRule":
        predicate = None
        if data.get("predicate"):
            predicate = Predicate.from_dict(data["predicate"])

        return cls(
            rule_id=data.get("rule_id", str(uuid.uuid4())),
            name=data.get("name"),
            predicate=predicate,
            queue_name=data["queue_name"],
            priority=Priority(data.get("priority", 2)),
            priority_override=data.get("priority_override", False),
            metadata=data.get("metadata", {}),
            weight=data.get("weight", 1.0),
            enabled=data.get("enabled", True),
            description=data.get("description"),
        )


# ---------------------------------------------------------------------------
# Router
# ---------------------------------------------------------------------------

class RoutingStrategy(Enum):
    """Strategy for selecting a route when multiple rules match."""
    FIRST = "first"  # Use first matching rule
    WEIGHTED = "weighted"  # Random selection weighted by rule weight
    PRIORITY = "priority"  # Use highest priority rule
    MERGE = "merge"  # Merge metadata from all matching rules


class Router:
    """
    Task router for directing tasks to appropriate queues.

    Supports multiple routing strategies and rule composition.

    Example:
        router = Router()

        # Add rules
        router.add_rule(RoutingRule(
            name="high_priority",
            predicate=ArgumentPredicate(
                argument_path="kwargs.priority",
                operator="eq",
                value="high"
            ),
            queue_name="high-priority",
            priority=Priority.CRITICAL,
            priority_override=True,
        ))

        # Route a task
        result = router.route(task)
        if result:
            backend.enqueue_to(result.queue_name, task)
    """

    def __init__(
        self,
        strategy: RoutingStrategy = RoutingStrategy.FIRST,
        default_queue: str = "default",
        default_priority: Priority = Priority.NORMAL,
    ) -> None:
        self.strategy = strategy
        self.default_queue = default_queue
        self.default_priority = default_priority
        self._rules: List[RoutingRule] = []
        self._lock = threading.RLock()

    def add_rule(self, rule: RoutingRule) -> str:
        """Add a routing rule. Returns the rule ID."""
        with self._lock:
            self._rules.append(rule)
        return rule.rule_id

    def remove_rule(self, rule_id: str) -> bool:
        """Remove a routing rule by ID."""
        with self._lock:
            for i, rule in enumerate(self._rules):
                if rule.rule_id == rule_id:
                    self._rules.pop(i)
                    return True
        return False

    def enable_rule(self, rule_id: str, enabled: bool = True) -> None:
        """Enable or disable a routing rule."""
        with self._lock:
            for rule in self._rules:
                if rule.rule_id == rule_id:
                    rule.enabled = enabled
                    break

    def route(self, task: Task) -> RouteResult:
        """
        Route a task to its destination.

        Returns a RouteResult with the queue and any modifications.
        """
        with self._lock:
            matching_rules = [r for r in self._rules if r.matches(task)]

        if not matching_rules:
            return RouteResult(
                queue_name=self.default_queue,
                priority=self.default_priority,
            )

        if self.strategy == RoutingStrategy.FIRST:
            return matching_rules[0].apply(task)

        elif self.strategy == RoutingStrategy.WEIGHTED:
            return self._weighted_route(task, matching_rules)

        elif self.strategy == RoutingStrategy.PRIORITY:
            # Sort by priority value (lower = higher priority)
            sorted_rules = sorted(matching_rules, key=lambda r: r.priority.value)
            return sorted_rules[0].apply(task)

        elif self.strategy == RoutingStrategy.MERGE:
            return self._merge_route(task, matching_rules)

        return matching_rules[0].apply(task)

    def _weighted_route(self, task: Task, rules: List[RoutingRule]) -> RouteResult:
        """Select a rule based on weights."""
        total_weight = sum(r.weight for r in rules)
        if total_weight == 0:
            return rules[0].apply(task)

        rand = hashlib.md5(
            f"{task.task_id}{time.time()}".encode()
        ).hexdigest()
        threshold = int(rand, 16) / (2**128) * total_weight

        cumulative = 0.0
        for rule in rules:
            cumulative += rule.weight
            if cumulative >= threshold:
                return rule.apply(task)

        return rules[-1].apply(task)

    def _merge_route(self, task: Task, rules: List[RoutingRule]) -> RouteResult:
        """Merge metadata from all matching rules."""
        merged_metadata = dict(task.metadata)
        matched_rules = []
        highest_priority = task.priority
        queue_name = self.default_queue

        for rule in rules:
            matched_rules.append(rule.rule_id)
            merged_metadata.update(rule.metadata)
            if rule.priority_override and rule.priority.value < highest_priority.value:
                highest_priority = rule.priority
                queue_name = rule.queue_name

        return RouteResult(
            queue_name=queue_name,
            priority=highest_priority,
            metadata=merged_metadata,
            matched_rules=matched_rules,
        )

    def get_rules(self) -> List[RoutingRule]:
        """Get all routing rules."""
        with self._lock:
            return list(self._rules)

    def clear_rules(self) -> None:
        """Remove all routing rules."""
        with self._lock:
            self._rules.clear()

    def to_dict(self) -> dict:
        """Serialize router configuration."""
        return {
            "strategy": self.strategy.value,
            "default_queue": self.default_queue,
            "default_priority": self.default_priority.value,
            "rules": [r.to_dict() for r in self._rules],
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Router":
        """Deserialize router configuration."""
        router = cls(
            strategy=RoutingStrategy(data.get("strategy", "first")),
            default_queue=data.get("default_queue", "default"),
            default_priority=Priority(data.get("default_priority", 2)),
        )
        for rule_data in data.get("rules", []):
            router.add_rule(RoutingRule.from_dict(rule_data))
        return router


# ---------------------------------------------------------------------------
# Fan-out Routing
# ---------------------------------------------------------------------------

@dataclass
class FanOutRouter:
    """
    Router that sends tasks to multiple queues simultaneously.

    Useful for broadcasting or replicating work.
    """

    def __init__(self, base_router: Optional[Router] = None) -> None:
        self.base_router = base_router or Router()
        self._fan_out_rules: Dict[str, List[str]] = {}  # task_name -> [queues]

    def register_fan_out(
        self,
        task_name: str,
        queues: List[str],
        predicate: Optional[Predicate] = None,
    ) -> None:
        """
        Register a fan-out pattern for a task.

        When this task is routed, it will be sent to all specified queues.
        """
        self._fan_out_rules[task_name] = queues

    def unregister_fan_out(self, task_name: str) -> bool:
        """Remove a fan-out registration."""
        if task_name in self._fan_out_rules:
            del self._fan_out_rules[task_name]
            return True
        return False

    def get_destinations(self, task: Task) -> List[RouteResult]:
        """
        Get all destination queues for a task.

        Returns one RouteResult per destination queue.
        """
        destinations = []

        # Check if task has fan-out pattern
        fan_out_queues = self._fan_out_rules.get(task.task_name)
        if fan_out_queues:
            for queue_name in fan_out_queues:
                destinations.append(RouteResult(
                    queue_name=queue_name,
                    priority=task.priority,
                    routing_reason=f"fan_out:{task.task_name}",
                ))
        else:
            # Use base router
            result = self.base_router.route(task)
            destinations.append(result)

        return destinations


# ---------------------------------------------------------------------------
# Queue-based Load Balancer
# ---------------------------------------------------------------------------

class LoadBalancer:
    """
    Load balancer for distributing tasks across multiple queues.

    Supports various load balancing strategies.
    """

    class Strategy(Enum):
        ROUND_ROBIN = "round_robin"
        LEAST_LOADED = "least_loaded"
        HASH_BASED = "hash_based"
        RANDOM = "random"

    def __init__(
        self,
        queues: List[str],
        strategy: Strategy = Strategy.ROUND_ROBIN,
    ) -> None:
        self.queues = queues
        self.strategy = strategy
        self._current_index = 0
        self._lock = threading.Lock()
        self._queue_loads: Dict[str, int] = {q: 0 for q in queues}
        self._total_routed = 0

    def select_queue(self, task: Optional[Task] = None) -> str:
        """Select a queue for routing based on strategy."""
        with self._lock:
            self._total_routed += 1

            if self.strategy == self.Strategy.ROUND_ROBIN:
                queue = self.queues[self._current_index]
                self._current_index = (self._current_index + 1) % len(self.queues)
                self._queue_loads[queue] += 1
                return queue

            elif self.strategy == self.Strategy.LEAST_LOADED:
                min_load = min(self._queue_loads.values())
                candidates = [q for q, load in self._queue_loads.items() if load == min_load]
                queue = candidates[self._total_routed % len(candidates)]
                self._queue_loads[queue] += 1
                return queue

            elif self.strategy == self.Strategy.HASH_BASED:
                if task:
                    hash_val = int(hashlib.md5(task.task_id.encode()).hexdigest(), 16)
                    queue = self.queues[hash_val % len(self.queues)]
                else:
                    queue = self.queues[self._total_routed % len(self.queues)]
                self._queue_loads[queue] += 1
                return queue

            else:  # RANDOM
                queue = self.queues[self._total_routed % len(self.queues)]
                self._queue_loads[queue] += 1
                return queue

    def add_queue(self, queue: str) -> None:
        """Add a new queue."""
        with self._lock:
            if queue not in self.queues:
                self.queues.append(queue)
                self._queue_loads[queue] = 0

    def remove_queue(self, queue: str) -> bool:
        """Remove a queue."""
        with self._lock:
            if queue in self.queues:
                self.queues.remove(queue)
                del self._queue_loads[queue]
                if self._current_index >= len(self.queues):
                    self._current_index = 0
                return True
        return False

    def get_loads(self) -> Dict[str, int]:
        """Get current load for all queues."""
        with self._lock:
            return dict(self._queue_loads)

    def rebalance(self) -> None:
        """Reset load tracking for rebalancing."""
        with self._lock:
            for queue in self._queue_loads:
                self._queue_loads[queue] = 0
            self._current_index = 0


# ---------------------------------------------------------------------------
# Dynamic Routing with Discovery
# ---------------------------------------------------------------------------

class QueueDiscovery:
    """
    Dynamic queue discovery based on task attributes.

    Queues are created on-demand and can be discovered via patterns.
    """

    def __init__(
        self,
        pattern: str = "{task_name}",
        separator: str = "_",
        cache_ttl: float = 300.0,
    ) -> None:
        self.pattern = pattern
        self.separator = separator
        self.cache_ttl = cache_ttl
        self._cache: Dict[str, Tuple[str, float]] = {}  # task_name -> (queue_name, expires_at)
        self._lock = threading.Lock()
        self._discovered_queues: Set[str] = set()
        self._on_discovery: Optional[Callable[[str], None]] = None

    def set_discovery_callback(self, callback: Callable[[str], None]) -> None:
        """Set callback for when new queues are discovered."""
        self._on_discovery = callback

    def discover_queue(self, task: Task) -> str:
        """Discover or create queue name for a task."""
        # Check cache
        with self._lock:
            if task.task_name in self._cache:
                queue_name, expires_at = self._cache[task.task_name]
                if time.time() < expires_at:
                    return queue_name

        # Generate queue name from pattern
        queue_name = self._generate_queue_name(task)

        # Cache it
        with self._lock:
            self._cache[task.task_name] = (queue_name, time.time() + self.cache_ttl)

            # Notify if new
            if queue_name not in self._discovered_queues:
                self._discovered_queues.add(queue_name)
                if self._on_discovery:
                    try:
                        self._on_discovery(queue_name)
                    except Exception as exc:
                        logger.warning("Discovery callback failed: %s", exc)

        return queue_name

    def _generate_queue_name(self, task: Task) -> str:
        """Generate queue name from pattern."""
        queue_name = self.pattern

        # Replace placeholders
        queue_name = queue_name.replace("{task_name}", task.task_name)
        queue_name = queue_name.replace("{module}", task.task_name.rsplit(".", 1)[0] if "." in task.task_name else "default")
        queue_name = queue_name.replace("{priority}", task.priority.name.lower())

        # Replace tag placeholders
        for i, tag in enumerate(task.tags):
            queue_name = queue_name.replace(f"{{tag{i}}}", tag)

        # Add metadata placeholders
        for key, value in task.metadata.items():
            placeholder = f"{{metadata.{key}}}"
            if placeholder in queue_name:
                queue_name = queue_name.replace(placeholder, str(value))

        # Clean up remaining placeholders
        queue_name = re.sub(r"\{[^}]+\}", "", queue_name)

        # Replace separators
        queue_name = queue_name.replace("/", self.separator)
        queue_name = queue_name.replace(".", self.separator)

        return queue_name or "default"

    def clear_cache(self) -> None:
        """Clear the queue name cache."""
        with self._lock:
            self._cache.clear()

    def get_discovered_queues(self) -> Set[str]:
        """Get all discovered queue names."""
        with self._lock:
            return set(self._discovered_queues)
