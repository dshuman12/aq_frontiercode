# TaskFlow

A lightweight distributed task queue for Python with support for
multiple backends, middleware, scheduling, and observability.

## Features
- In-memory and SQLite backends
- Priority queues
- Retry with configurable backoff
- Cron and interval scheduling
- Middleware pipeline
- CLI worker management

## Installation
```
pip install taskflow
```

## Quick Start
```python
from taskflow.core.registry import task

@task
def send_email(to, subject, body):
    ...

send_email.delay(to="alice@example.com", subject="Hi", body="Hello")
```
