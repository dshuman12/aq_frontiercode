"""Authentication and authorization subsystem."""
