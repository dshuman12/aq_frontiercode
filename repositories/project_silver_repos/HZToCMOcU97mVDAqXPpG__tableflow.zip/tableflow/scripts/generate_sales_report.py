#!/usr/bin/env python
"""Generate a quick CSV sales report for the last N days."""
from __future__ import annotations

import csv
import os
import sys
from datetime import date, timedelta

import django

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings.dev")
django.setup()

from apps.payments.models import Payment  # noqa: E402
from apps.reports.aggregations import revenue_by_day  # noqa: E402


def run(restaurant_slug: str, days: int = 30, out_path: str = "sales.csv") -> None:
    from apps.restaurants.models import Restaurant
    r = Restaurant.objects.get(slug=restaurant_slug)
    start = date.today() - timedelta(days=days)
    payments = list(
        Payment.objects.filter(
            restaurant_id=r.id, status="captured", captured_at__date__gte=start,
        ).values("captured_at", "amount_cents")
    )
    by_day = revenue_by_day(payments)
    with open(out_path, "w", newline="", encoding="utf-8") as fp:
        w = csv.writer(fp)
        w.writerow(["date", "revenue_cents"])
        for d, cents in sorted(by_day.items()):
            w.writerow([d, cents])
    print(f"Wrote {out_path} with {len(by_day)} rows")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("usage: generate_sales_report.py <restaurant_slug> [days] [out_path]")
        sys.exit(2)
    args = sys.argv[1:]
    run(args[0], int(args[1]) if len(args) > 1 else 30, args[2] if len(args) > 2 else "sales.csv")
