#!/usr/bin/env python
"""Quick liveness probe — exits 0 if /health/ returns 200."""
from __future__ import annotations

import sys
import urllib.request


def run(url: str = "http://localhost:8000/health/") -> int:
    try:
        with urllib.request.urlopen(url, timeout=5) as resp:
            ok = resp.status == 200
            body = resp.read().decode()
        if ok:
            print(f"[ok] {url} → 200")
            print(body)
            return 0
        print(f"[fail] {url} → {resp.status}")
        return 1
    except Exception as exc:
        print(f"[fail] {url} unreachable: {exc}")
        return 1


if __name__ == "__main__":
    sys.exit(run(sys.argv[1] if len(sys.argv) > 1 else "http://localhost:8000/health/"))
