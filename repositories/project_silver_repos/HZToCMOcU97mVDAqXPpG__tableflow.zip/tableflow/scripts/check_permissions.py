#!/usr/bin/env python
"""Lints that every requirePermission(...) string in route files exists in the catalog."""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "backend"))

from apps.permissions.catalog import CATALOG  # noqa: E402

PATTERN = re.compile(r"perm\(['\"]([^'\"]+)['\"]\)")


def run() -> int:
    used: set[str] = set()
    for f in (ROOT / "backend" / "apps").rglob("*.py"):
        text = f.read_text()
        for match in PATTERN.findall(text):
            used.add(match)
    missing = sorted(p for p in used if p not in CATALOG)
    unused = sorted(p for p in CATALOG if p not in used and not p.endswith(":admin"))
    if missing:
        print("MISSING from catalog:")
        for p in missing:
            print(f"  - {p}")
    if unused:
        print("Defined but unused:")
        for p in unused:
            print(f"  - {p}")
    return 2 if missing else 0


if __name__ == "__main__":
    sys.exit(run())
