#!/usr/bin/env python
"""Anonymize a JSON export for sharing with vendors / support."""
from __future__ import annotations

import hashlib
import json
import os
import re
import sys

SALT = os.environ.get("ANON_SALT", "tableflow-anon").encode()


def _short(value: object) -> str:
    return hashlib.sha256(SALT + str(value).encode()).hexdigest()[:8]


def _fake_name(seed: object) -> str:
    return f"Customer-{_short(seed).upper()}"


def _fake_email(seed: object) -> str:
    return f"c{_short(seed)}@example.invalid"


def _fake_phone(seed: object) -> str:
    digits = re.sub(r"[^0-9]", "", _short(seed)) or "0000000"
    digits = (digits + "000")[:7]
    return f"555-{digits[:3]}-{digits[3:7]}"


def anonymize(value):
    if isinstance(value, list):
        return [anonymize(x) for x in value]
    if not isinstance(value, dict):
        return value
    out = {}
    for k, v in value.items():
        if k in {"first_name", "last_name", "name", "customer_name"}:
            out[k] = _fake_name(v)
        elif k in {"email", "customer_email"}:
            out[k] = _fake_email(v)
        elif k in {"phone", "customer_phone"}:
            out[k] = _fake_phone(v)
        elif k in {"ssn", "card_last4", "stripe_payment_intent_id"}:
            out[k] = "***"
        else:
            out[k] = anonymize(v)
    return out


def main():
    if len(sys.argv) < 3:
        print("usage: anonymize_export.py <in.json> <out.json>")
        sys.exit(2)
    with open(sys.argv[1]) as f:
        data = json.load(f)
    with open(sys.argv[2], "w") as f:
        json.dump(anonymize(data), f, indent=2)
    print(f"Anonymized {sys.argv[1]} → {sys.argv[2]}")


if __name__ == "__main__":
    main()
