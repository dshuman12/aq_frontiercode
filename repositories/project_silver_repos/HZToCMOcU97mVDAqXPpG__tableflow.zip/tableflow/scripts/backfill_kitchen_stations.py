#!/usr/bin/env python
"""Backfill the default 8 kitchen stations into a restaurant's main branch."""
from __future__ import annotations

import os
import sys

import django

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings.dev")
django.setup()

from apps.branches.models import Branch  # noqa: E402
from apps.kitchen.models import KitchenStation  # noqa: E402
from apps.restaurants.models import Restaurant  # noqa: E402

DEFAULTS = [
    ("Grill", "grill"), ("Fryer", "fryer"), ("Pizza", "pizza"), ("Salad", "salad"),
    ("Dessert", "dessert"), ("Drinks", "drinks"), ("Bar", "bar"), ("Packaging", "packaging"),
]


def run(slug: str, branch_name: str = "Main") -> None:
    r = Restaurant.objects.get(slug=slug)
    branch = Branch.objects.get(restaurant=r, name=branch_name)
    created = 0
    for name, kind in DEFAULTS:
        _, was_new = KitchenStation.objects.get_or_create(
            restaurant_id=r.id, branch=branch, name=name, defaults={"kind": kind},
        )
        created += int(was_new)
    print(f"[done] {r.slug}/{branch.name}: {created} stations created")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("usage: backfill_kitchen_stations.py <restaurant_slug> [branch]")
        sys.exit(2)
    run(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else "Main")
