#!/usr/bin/env python
"""Seed a fully populated demo restaurant for local dev."""
from __future__ import annotations

import os
import random
from decimal import Decimal

import django

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings.dev")
django.setup()

from django.contrib.auth import get_user_model  # noqa: E402
from apps.branches.models import Branch  # noqa: E402
from apps.coupons.models import Coupon  # noqa: E402
from apps.customers.models import Customer  # noqa: E402
from apps.inventory.models import Ingredient, IngredientCategory  # noqa: E402
from apps.kitchen.models import KitchenStation  # noqa: E402
from apps.menus.models import Menu, MenuCategory, MenuItem  # noqa: E402
from apps.modifiers.models import ModifierGroup, ModifierOption  # noqa: E402
from apps.permissions.presets import PRESETS  # noqa: E402
from apps.restaurants.models import Restaurant, RestaurantMember  # noqa: E402
from apps.restaurants.services import create_restaurant  # noqa: E402
from apps.roles.models import Role  # noqa: E402
from apps.suppliers.models import Supplier  # noqa: E402
from apps.tables.models import DiningArea, RestaurantTable, TableQRCode  # noqa: E402

User = get_user_model()
random.seed(42)

OWNER_EMAIL = "owner@demo.test"
OWNER_PASSWORD = "demo-password-12"


def run() -> None:
    print("[seed] cleaning existing demo data...")
    Restaurant.objects.filter(slug__startswith="demo-bistro").delete()
    User.objects.filter(email__endswith="@demo.test").delete()

    print("[seed] owner user")
    owner, _ = User.objects.get_or_create(email=OWNER_EMAIL, defaults={"name": "Demo Owner"})
    owner.set_password(OWNER_PASSWORD)
    owner.save()

    print("[seed] restaurant")
    restaurant = create_restaurant(owner=owner, name="Demo Bistro")

    main = Branch.objects.get(restaurant=restaurant, name="Main")
    east = Branch.objects.create(restaurant=restaurant, name="East side", code="EAST", phone="512-555-0102")

    print("[seed] kitchen stations")
    for kind in ["grill", "fryer", "pizza", "salad", "drinks", "packaging"]:
        KitchenStation.objects.get_or_create(restaurant_id=restaurant.id, branch=main, name=kind.title(), kind=kind)

    print("[seed] menu")
    menu = Menu.objects.create(restaurant_id=restaurant.id, name="Dinner", slug="dinner", is_default=True)
    cats = {
        "starters": MenuCategory.objects.create(menu=menu, name="Starters", sort_order=1),
        "mains": MenuCategory.objects.create(menu=menu, name="Mains", sort_order=2),
        "sides": MenuCategory.objects.create(menu=menu, name="Sides", sort_order=3),
        "drinks": MenuCategory.objects.create(menu=menu, name="Drinks", sort_order=4),
    }
    items = [
        ("Bruschetta", "starters", 800, ["gluten"], ["vegetarian"]),
        ("Caesar salad", "starters", 1100, ["dairy", "fish"], ["vegetarian"]),
        ("Margherita pizza", "mains", 1600, ["gluten", "dairy"], ["vegetarian"]),
        ("Carbonara", "mains", 1700, ["gluten", "dairy", "egg"], []),
        ("Steak frites", "mains", 2800, [], ["gluten-free"]),
        ("Truffle fries", "sides", 800, [], ["vegan"]),
        ("Lemonade", "drinks", 500, [], ["vegan"]),
        ("House wine", "drinks", 900, [], []),
    ]
    item_objs = []
    for name, cat, price, allergens, dietary in items:
        item_objs.append(MenuItem.objects.create(
            restaurant_id=restaurant.id,
            category=cats[cat], name=name, base_price_cents=price,
            allergens=allergens, dietary_tags=dietary, prep_time_minutes=random.randint(5, 18),
        ))

    print("[seed] modifiers")
    sizes = ModifierGroup.objects.create(restaurant_id=restaurant.id, name="Size", min_select=1, max_select=1, is_required=True)
    for n, d in [("Small", -200), ("Medium", 0), ("Large", 300)]:
        ModifierOption.objects.create(group=sizes, name=n, price_delta_cents=d, is_default=n == "Medium")
    addons = ModifierGroup.objects.create(restaurant_id=restaurant.id, name="Add-ons", max_select=4)
    for n, d in [("Extra cheese", 150), ("Mushrooms", 100), ("Pepperoni", 250)]:
        ModifierOption.objects.create(group=addons, name=n, price_delta_cents=d)

    print("[seed] dining areas + tables")
    inside = DiningArea.objects.create(restaurant_id=restaurant.id, branch=main, name="Inside", kind="dining")
    patio = DiningArea.objects.create(restaurant_id=restaurant.id, branch=main, name="Patio", kind="patio")
    for i in range(1, 11):
        t = RestaurantTable.objects.create(
            restaurant_id=restaurant.id, area=inside if i <= 7 else patio,
            number=f"T-{i:02d}", capacity=random.choice([2, 2, 4, 4, 6]),
        )
        TableQRCode.objects.create(table=t)

    print("[seed] customers")
    NAMES = ["Ada", "Alan", "Grace", "Linus", "Margaret", "Edsger", "Donald", "Barbara", "Rosa", "Hedy"]
    for i, n in enumerate(NAMES):
        Customer.objects.create(
            restaurant_id=restaurant.id, first_name=n, last_name="Doe",
            email=f"{n.lower()}@example.test", phone=f"512-555-{1000 + i:04d}",
        )

    print("[seed] inventory")
    veg = IngredientCategory.objects.create(restaurant_id=restaurant.id, name="Vegetables")
    for n in ["Tomato", "Lettuce", "Onion", "Garlic", "Basil"]:
        Ingredient.objects.create(
            restaurant_id=restaurant.id, branch=main, category=veg, name=n, unit="kg",
            on_hand_qty=Decimal(random.randint(2, 30)), par_qty=Decimal("5"),
            cost_per_unit_cents=random.randint(150, 800),
        )
    Ingredient.objects.create(restaurant_id=restaurant.id, branch=main, name="Flour", unit="kg",
                              on_hand_qty=Decimal("2"), par_qty=Decimal("10"), cost_per_unit_cents=120)

    print("[seed] suppliers")
    Supplier.objects.create(restaurant_id=restaurant.id, name="Riverbend Produce", code="RB", phone="512-555-9001")

    print("[seed] coupons")
    Coupon.objects.create(restaurant_id=restaurant.id, code="WELCOME10", name="Welcome 10%", kind="percent", percent_off=10)
    Coupon.objects.create(restaurant_id=restaurant.id, code="FREESHIP", name="Free delivery", kind="free_delivery")

    print("[seed] done")
    print(f"  Login: {OWNER_EMAIL} / {OWNER_PASSWORD}")
    print(f"  Restaurant: {restaurant.name} ({restaurant.slug})")


if __name__ == "__main__":
    run()
