#!/usr/bin/env python
"""Import a CSV of menu items into a restaurant."""
from __future__ import annotations

import csv
import os
import sys
from decimal import Decimal

import django

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings.dev")
django.setup()

from apps.menus.models import Menu, MenuCategory, MenuItem  # noqa: E402
from apps.restaurants.models import Restaurant  # noqa: E402


def run(restaurant_slug: str, file_path: str, menu_slug: str = "main") -> None:
    restaurant = Restaurant.objects.get(slug=restaurant_slug)
    menu, _ = Menu.objects.get_or_create(
        restaurant_id=restaurant.id, slug=menu_slug,
        defaults={"name": menu_slug.title()},
    )
    with open(file_path, newline="", encoding="utf-8") as fp:
        reader = csv.DictReader(fp)
        for row in reader:
            cat, _ = MenuCategory.objects.get_or_create(menu=menu, name=row["category"])
            item, created = MenuItem.objects.update_or_create(
                restaurant_id=restaurant.id, category=cat, name=row["name"],
                defaults={
                    "description": row.get("description", ""),
                    "base_price_cents": int(Decimal(row.get("price", "0")) * 100),
                    "allergens": [a.strip() for a in row.get("allergens", "").split("|") if a.strip()],
                    "prep_time_minutes": int(row.get("prep_min", "0")),
                },
            )
            print(("created" if created else "updated"), item.name)


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("usage: import_menu.py <restaurant_slug> <file.csv> [menu_slug]")
        sys.exit(2)
    run(sys.argv[1], sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else "main")
