import { describe, expect, it } from 'vitest';
import { elapsedMinutes, isDelayed } from './elapsed';

const now = new Date('2024-08-15T12:30:00Z').getTime();

describe('elapsedMinutes', () => {
  it('handles null', () => {
    expect(elapsedMinutes(null, now)).toBe(0);
  });
  it('returns minutes since iso', () => {
    expect(elapsedMinutes('2024-08-15T12:18:00Z', now)).toBe(12);
  });
  it('floors at 0 for future timestamps', () => {
    expect(elapsedMinutes('2024-08-15T13:00:00Z', now)).toBe(0);
  });
});

describe('isDelayed', () => {
  it('only when status is queued or in_progress', () => {
    expect(isDelayed('ready', '2024-08-15T12:00:00Z', 5, 5, now)).toBe(false);
    expect(isDelayed('in_progress', '2024-08-15T12:00:00Z', 5, 5, now)).toBe(true);
  });
  it('respects slack window', () => {
    // 12 min elapsed, expected 10, slack 5 → not delayed
    expect(isDelayed('in_progress', '2024-08-15T12:18:00Z', 10, 5, now)).toBe(false);
    // 30 min elapsed, expected 10, slack 5 → delayed
    expect(isDelayed('in_progress', '2024-08-15T12:00:00Z', 10, 5, now)).toBe(true);
  });
  it('not delayed without started_at', () => {
    expect(isDelayed('in_progress', null, 10, 5, now)).toBe(false);
  });
});
