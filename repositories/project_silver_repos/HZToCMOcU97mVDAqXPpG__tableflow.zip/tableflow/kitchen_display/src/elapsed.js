export function elapsedMinutes(iso, now = Date.now()) {
  if (!iso) return 0;
  return Math.max(0, Math.floor((now - new Date(iso).getTime()) / 60_000));
}

export function isDelayed(status, startedAt, expectedMinutes, slackMinutes = 5, now = Date.now()) {
  if (status !== 'queued' && status !== 'in_progress') return false;
  if (!startedAt) return false;
  return elapsedMinutes(startedAt, now) > expectedMinutes + slackMinutes;
}
