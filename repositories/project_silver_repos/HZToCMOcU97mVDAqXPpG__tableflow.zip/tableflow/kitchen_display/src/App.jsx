import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import axios from 'axios';
import clsx from 'clsx';

const api = axios.create({ baseURL: '' });
const STATIONS = ['all', 'grill', 'fryer', 'pizza', 'salad', 'bar', 'packaging'];

function elapsedMinutes(iso) {
  if (!iso) return 0;
  return Math.max(0, Math.floor((Date.now() - new Date(iso).getTime()) / 60_000));
}

function Ticket({ ticket, onTransition, onItemDone }) {
  const elapsed = elapsedMinutes(ticket.started_at || ticket.created_at);
  const tone =
    ticket.status === 'ready' ? 'bg-green-700' :
    ticket.status === 'in_progress' ? 'bg-amber-600' :
    elapsed > 15 ? 'bg-red-700' : 'bg-slate-700';
  return (
    <div className={clsx('rounded-2xl p-4 shadow-lg', tone)}>
      <div className="flex items-center justify-between mb-2">
        <h3 className="text-lg font-bold">{ticket.order_number || 'Order'}</h3>
        <span className="text-2xl font-mono">{elapsed}m</span>
      </div>
      <div className="text-sm opacity-90 mb-2">
        Station: <span className="font-semibold">{ticket.station}</span>
      </div>
      <ul className="text-sm space-y-1 mb-3">
        {(ticket.items || []).map((it) => (
          <li key={it.id} className="flex justify-between bg-black/20 rounded-md px-2 py-1">
            <span>{it.quantity}× {it.note || 'item'}</span>
            <button
              onClick={() => !it.is_done && onItemDone(ticket.id, it.id)}
              disabled={it.is_done}
              className="text-xs bg-white/20 px-2 py-0.5 rounded disabled:opacity-50"
            >
              {it.is_done ? '✓ done' : 'mark done'}
            </button>
          </li>
        ))}
      </ul>
      <div className="flex gap-2">
        {ticket.status === 'queued' && (
          <button onClick={() => onTransition(ticket.id, 'in_progress')} className="flex-1 bg-amber-500 rounded-lg py-2 font-semibold">Start</button>
        )}
        {ticket.status === 'in_progress' && (
          <button onClick={() => onTransition(ticket.id, 'ready')} className="flex-1 bg-green-600 rounded-lg py-2 font-semibold">Ready</button>
        )}
        {ticket.status === 'ready' && (
          <button onClick={() => onTransition(ticket.id, 'served')} className="flex-1 bg-slate-600 rounded-lg py-2 font-semibold">Served</button>
        )}
      </div>
    </div>
  );
}

export function App() {
  const [station, setStation] = useState('all');
  const { data, refetch } = useQuery({
    queryKey: ['kds-tickets', station],
    queryFn: () => api.get('/api/kitchen/tickets', {
      params: { active: 1, ...(station !== 'all' ? { station } : {}) },
    }).then((r) => r.data),
  });
  const tickets = data?.rows || data || [];

  const onTransition = (id, to) =>
    api.post(`/api/kitchen/tickets/${id}/transition`, { to_status: to }).then(() => refetch());
  const onItemDone = (id, itemId) =>
    api.post(`/api/kitchen/tickets/${id}/items/${itemId}/done`).then(() => refetch());

  return (
    <div className="h-full flex flex-col">
      <header className="px-4 py-3 border-b border-slate-700 flex items-center gap-3">
        <h1 className="text-xl font-bold">Kitchen Display</h1>
        <div className="ml-auto flex gap-2">
          {STATIONS.map((s) => (
            <button
              key={s}
              onClick={() => setStation(s)}
              className={'px-3 py-1.5 rounded-full text-sm ' + (station === s ? 'bg-white text-slate-900' : 'bg-slate-700 text-white')}
            >
              {s}
            </button>
          ))}
        </div>
        <div className="text-sm opacity-70 ml-3">{tickets.length} active</div>
      </header>
      <main className="flex-1 overflow-y-auto p-4">
        {tickets.length === 0 ? (
          <p className="text-center opacity-70 py-20">All caught up.</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {tickets.map((t) => (
              <Ticket key={t.id} ticket={t} onTransition={onTransition} onItemDone={onItemDone} />
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
