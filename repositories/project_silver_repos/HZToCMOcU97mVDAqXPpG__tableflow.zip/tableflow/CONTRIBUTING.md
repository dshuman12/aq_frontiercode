# Contributing to TableFlow

Thanks for chipping in. TableFlow is a Django + React monorepo and we keep the
bar high without slowing anyone down.

## Workflow

1. Branch off `main` with `feat/<scope>` or `fix/<scope>`.
2. Each commit should pass tests on its own.
3. `make lint && make test` before opening a PR.
4. Fill in the PR template; CI must be green.
5. A reviewer from the matching CODEOWNERS group merges with squash.

## Conventions

- Python 3.11+, formatted with **black** (line length 100), linted with **ruff**.
- JavaScript with **eslint** + **prettier**; tab/space and quotes follow the existing files.
- Mongoose-style HMR is not used — Django models live in `apps/<app>/models.py` and run migrations explicitly.
- Validators for request bodies live in DRF serializers, not view handlers.
- Routes call `perm("<resource>:<action>")`. New permissions must be added to `apps/permissions/catalog.py` AND at least one preset.
- `restaurant_id` is the first argument of every domain service method; views derive it from the JWT, never the request body.

## Tests

- Pure-function tests live next to the file as `test_*.py`.
- Don't add fragile tests that hit live Stripe or live SMTP. Use the simulated wrappers in `apps/payments/stripe_client.py` and the console email backend.
- New domain logic without a unit test is grounds for changes-requested.

## Commit messages

```
<area>: <short imperative summary>

Optional body explaining the why.
```

Examples:

- `orders: enforce half-open intervals for overlapping reservations`
- `frontend: Tooltip — close on focus loss`
- `docs(security): expand TOTP enrolment flow`

## Reporting bugs

Open an issue with:

1. What you expected
2. What actually happened
3. The smallest reproduction you can manage
4. The version of TableFlow you're running (`git rev-parse HEAD` is fine)
