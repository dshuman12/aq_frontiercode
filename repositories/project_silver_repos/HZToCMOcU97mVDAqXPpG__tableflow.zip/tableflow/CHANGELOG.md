# Changelog

All notable changes to TableFlow are recorded here.

## [Unreleased]

### Added
- Customer portal (Vite + React) with menu browsing, cart, checkout, and reservation flow
- Kitchen display app with station-filtered ticket grid + 5s polling
- Outbound webhooks with HMAC-SHA256 signing and exponential backoff
- Operator dashboard pages: Floor, POS, Kitchen, Calendar, Menu, Modifiers, Customers, Loyalty, Coupons, Staff, Inventory, Suppliers, Purchasing, Delivery, Payments, Closeouts, Reports, Branches, Roles, Audit, ApiKeys, Webhooks, Profile

### Changed
- The reception/floor view derives "needs cleaning" without writing a flag column
- Audit log filters resource and actor without server-side joins

### Security
- JsonFormatter redacts password, secret, token, ssn, card_number, cvv, totp_secret, and email addresses before serializing log records
- Login throttle locks an account after 5 consecutive failures within 15 minutes
- Webhook signatures include a unix timestamp + HMAC; receivers verify within a 5-minute tolerance window

## [0.1.0] — Foundation

Initial scaffolding of the multi-tenant restaurant platform:

- Django 5 + DRF backend with 26 apps
- Postgres + Redis + Channels (websockets)
- 60+ database tables, all `restaurant_id`-scoped
- 10 role presets with ~95 permission strings
- Stripe integration with simulated mode
- Celery worker with 8 queues
- Three React SPAs (operator, customer, kitchen)
