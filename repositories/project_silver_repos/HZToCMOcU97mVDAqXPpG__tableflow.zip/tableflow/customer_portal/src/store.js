import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { setToken } from './api';

export const useStore = create(
  persist(
    (set, get) => ({
      accessToken: null,
      user: null,
      cart: [], // [{menu_item, name, price_cents, quantity, modifier_options:[ids]}]

      setAuth: ({ access_token, user }) => {
        setToken(access_token || null);
        set({ accessToken: access_token, user });
      },
      logout: () => { setToken(null); set({ accessToken: null, user: null }); },

      addToCart: (item) => set({ cart: [...get().cart, item] }),
      updateQty: (idx, delta) => set({
        cart: get().cart
          .map((c, i) => (i === idx ? { ...c, quantity: c.quantity + delta } : c))
          .filter((c) => c.quantity > 0),
      }),
      clearCart: () => set({ cart: [] }),

      cartSubtotal: () => get().cart.reduce((sum, c) => sum + c.price_cents * c.quantity, 0),
    }),
    {
      name: 'tableflow.customer',
      onRehydrateStorage: () => (state) => {
        if (state?.accessToken) setToken(state.accessToken);
      },
    },
  ),
);
