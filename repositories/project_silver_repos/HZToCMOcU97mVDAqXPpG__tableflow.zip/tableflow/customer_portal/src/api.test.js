import { describe, expect, it, beforeEach, afterEach } from 'vitest';
import { portalApi } from './api';

describe('cart persistence', () => {
  beforeEach(() => localStorage.clear());
  afterEach(() => localStorage.clear());

  it('save then load round-trips', () => {
    const items = [{ menu_item: 'a', name: 'X', price_cents: 500, quantity: 2 }];
    portalApi.saveCart(items);
    expect(portalApi.loadCart()).toEqual(items);
  });

  it('load with no key returns []', () => {
    expect(portalApi.loadCart()).toEqual([]);
  });

  it('save overwrites previous content', () => {
    portalApi.saveCart([{ menu_item: 'a' }]);
    portalApi.saveCart([{ menu_item: 'b' }]);
    expect(portalApi.loadCart()).toEqual([{ menu_item: 'b' }]);
  });
});
