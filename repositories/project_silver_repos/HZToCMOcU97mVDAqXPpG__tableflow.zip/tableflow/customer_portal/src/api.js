import axios from 'axios';

let token = null;
export const setToken = (t) => { token = t; };

const api = axios.create({ baseURL: import.meta.env.VITE_API_URL || '' });
api.interceptors.request.use((c) => {
  if (token) c.headers.Authorization = `Bearer ${token}`;
  return c;
});
api.interceptors.response.use((r) => r, (err) => {
  const msg = err.response?.data?.detail || err.message;
  throw new Error(typeof msg === 'string' ? msg : 'request-failed');
});

export const portalApi = {
  // Public
  menu: (slug) => api.get(`/api/portal/menu/${slug}`).then((r) => r.data),
  branches: (slug) => api.get(`/api/portal/branches/${slug}`).then((r) => r.data),

  // Customer auth
  register: (body) => api.post('/api/auth/register', body).then((r) => r.data),
  login: (body) => api.post('/api/auth/login', body).then((r) => r.data),
  me: () => api.get('/api/auth/me').then((r) => r.data),

  // Browse
  loadCart: () => JSON.parse(localStorage.getItem('cart') || '[]'),
  saveCart: (items) => localStorage.setItem('cart', JSON.stringify(items)),

  // Place order
  placeOrder: (body) => api.post('/api/orders/', body).then((r) => r.data),
  myOrders: () => api.get('/api/orders/').then((r) => r.data),
  orderDetail: (id) => api.get(`/api/orders/${id}`).then((r) => r.data),

  // Reservations
  bookReservation: (body) => api.post('/api/reservations/', body).then((r) => r.data),
};

export default api;
