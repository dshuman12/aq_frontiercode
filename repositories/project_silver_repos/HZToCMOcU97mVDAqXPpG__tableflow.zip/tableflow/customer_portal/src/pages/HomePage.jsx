import { Link } from 'react-router-dom';

export function HomePage() {
  return (
    <>
      <section className="rounded-3xl bg-gradient-to-br from-brand-100 via-white to-orange-50 p-8 md:p-12 mb-6">
        <h1 className="text-3xl md:text-4xl font-bold mb-2">Order online, dine in, or reserve a table</h1>
        <p className="text-slate-700 mb-6">Skip the line — your food, your way, faster.</p>
        <div className="flex flex-wrap gap-3">
          <Link to="/menu" className="btn-primary">Order online</Link>
          <Link to="/reserve" className="btn-secondary">Reserve a table</Link>
        </div>
      </section>
      <section className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="card p-5"><h3 className="font-semibold mb-2">Pickup</h3><p className="text-sm text-slate-600">Place an order ahead, grab it when it's ready.</p></div>
        <div className="card p-5"><h3 className="font-semibold mb-2">Delivery</h3><p className="text-sm text-slate-600">Hot meals brought to your door in our zone.</p></div>
        <div className="card p-5"><h3 className="font-semibold mb-2">Loyalty</h3><p className="text-sm text-slate-600">Earn 1 point per dollar spent. Redeem for rewards.</p></div>
      </section>
    </>
  );
}
