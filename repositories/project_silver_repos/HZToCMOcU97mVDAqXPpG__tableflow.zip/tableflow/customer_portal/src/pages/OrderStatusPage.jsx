import { useParams, Link } from 'react-router-dom';

const STEPS = ['placed', 'accepted', 'preparing', 'ready', 'completed'];

export function OrderStatusPage() {
  const { id } = useParams();
  const status = 'preparing'; // would come from poll/WS

  return (
    <>
      <Link to="/orders" className="text-brand-700 text-sm">‹ All orders</Link>
      <h1 className="text-2xl font-bold mt-2 mb-4">Order {id}</h1>
      <div className="card p-5 mb-4">
        <p className="font-semibold mb-3">Your order is being prepared</p>
        <ol className="grid grid-cols-5 gap-2">
          {STEPS.map((s, i) => {
            const idx = STEPS.indexOf(status);
            const tone = i < idx ? 'bg-green-500' : i === idx ? 'bg-brand-600' : 'bg-slate-200';
            return (
              <li key={s} className="flex flex-col items-center text-center">
                <span className={`w-8 h-8 rounded-full ${tone} text-white inline-flex items-center justify-center text-xs`}>{i + 1}</span>
                <span className="text-xs mt-1 capitalize">{s}</span>
              </li>
            );
          })}
        </ol>
      </div>
      <div className="card p-5">
        <h2 className="font-semibold mb-2">Help</h2>
        <p className="text-sm text-slate-600">Need anything? Call the restaurant directly. Receipts are emailed once your order is complete.</p>
      </div>
    </>
  );
}
