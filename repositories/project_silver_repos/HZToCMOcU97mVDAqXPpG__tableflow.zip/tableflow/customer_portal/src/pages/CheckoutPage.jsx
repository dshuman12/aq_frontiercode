import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { useStore } from '../store';

export function CheckoutPage() {
  const navigate = useNavigate();
  const cart = useStore((s) => s.cart);
  const subtotal = useStore((s) => s.cartSubtotal());
  const clearCart = useStore((s) => s.clearCart);
  const [busy, setBusy] = useState(false);
  const [kind, setKind] = useState('takeout');
  const { register, handleSubmit } = useForm();

  const tax = Math.round(subtotal * 0.0825);
  const total = subtotal + tax;

  const placeOrder = async (data) => {
    setBusy(true);
    // Simulated — backend wiring would call portalApi.placeOrder({...})
    await new Promise((r) => setTimeout(r, 600));
    clearCart();
    navigate('/orders/sim_' + Math.random().toString(36).slice(2, 8));
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[1fr_22rem] gap-6">
      <div>
        <h1 className="text-2xl font-bold mb-4">Checkout</h1>
        <div className="card p-4 mb-3">
          <p className="font-semibold mb-2">How would you like your order?</p>
          <div className="flex gap-2">
            {['takeout', 'delivery'].map((k) => (
              <button
                key={k}
                onClick={() => setKind(k)}
                className={'flex-1 py-2 rounded-lg ' + (kind === k ? 'bg-brand-600 text-white' : 'bg-white border border-slate-200')}
              >
                {k === 'takeout' ? 'Pickup' : 'Delivery'}
              </button>
            ))}
          </div>
        </div>
        <form onSubmit={handleSubmit(placeOrder)} className="space-y-3">
          <input className="input" placeholder="Name" {...register('name', { required: true })} />
          <input className="input" placeholder="Phone" {...register('phone', { required: true })} />
          <input className="input" type="email" placeholder="Email" {...register('email')} />
          {kind === 'delivery' && <input className="input" placeholder="Delivery address" {...register('address', { required: true })} />}
          <textarea className="input min-h-[6rem]" placeholder="Special instructions (optional)" {...register('notes')} />
          <button type="submit" disabled={busy} className="btn-primary w-full">
            {busy ? 'Placing order…' : `Place order — $${(total / 100).toFixed(2)}`}
          </button>
        </form>
      </div>
      <aside className="card p-4 h-fit">
        <h2 className="font-semibold mb-3">Order summary</h2>
        <ul className="text-sm divide-y divide-slate-100 mb-3">
          {cart.map((c, i) => (
            <li key={i} className="py-1.5 flex justify-between">
              <span>{c.quantity}× {c.name}</span>
              <span>${((c.price_cents * c.quantity) / 100).toFixed(2)}</span>
            </li>
          ))}
        </ul>
        <div className="text-sm space-y-1 border-t border-slate-100 pt-3">
          <div className="flex justify-between"><span>Subtotal</span><span>${(subtotal / 100).toFixed(2)}</span></div>
          <div className="flex justify-between"><span>Tax</span><span>${(tax / 100).toFixed(2)}</span></div>
          <div className="flex justify-between font-bold border-t border-slate-100 pt-1 mt-1">
            <span>Total</span><span>${(total / 100).toFixed(2)}</span>
          </div>
        </div>
      </aside>
    </div>
  );
}
