import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { portalApi } from '../api';

export function OrdersPage() {
  const { data } = useQuery({ queryKey: ['my-orders'], queryFn: () => portalApi.myOrders() });
  const rows = data?.rows || data || [];
  return (
    <>
      <h1 className="text-2xl font-bold mb-4">My orders</h1>
      {rows.length === 0 ? (
        <p className="text-slate-500">No orders yet — <Link to="/menu" className="text-brand-700">browse the menu</Link>.</p>
      ) : (
        <ul className="space-y-2">
          {rows.map((o) => (
            <li key={o.id} className="card p-4 flex justify-between items-center">
              <div>
                <p className="font-medium">{o.number}</p>
                <p className="text-xs text-slate-500">{new Date(o.created_at).toLocaleString()} · {o.kind}</p>
              </div>
              <Link to={`/orders/${o.id}`} className="text-brand-700 text-sm">View →</Link>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
