import { Link, useNavigate } from 'react-router-dom';
import { useStore } from '../store';

export function CartPage() {
  const navigate = useNavigate();
  const cart = useStore((s) => s.cart);
  const updateQty = useStore((s) => s.updateQty);
  const subtotal = useStore((s) => s.cartSubtotal());

  if (cart.length === 0) {
    return (
      <div className="text-center py-16">
        <p className="text-slate-500 mb-4">Your cart is empty.</p>
        <Link to="/menu" className="btn-primary">Browse menu</Link>
      </div>
    );
  }

  return (
    <>
      <h1 className="text-2xl font-bold mb-3">Your cart</h1>
      <div className="card divide-y divide-slate-100">
        {cart.map((c, i) => (
          <div key={i} className="p-4 flex items-center gap-3">
            <div className="flex-1">
              <p className="font-medium">{c.name}</p>
              <p className="text-sm text-slate-500">${(c.price_cents / 100).toFixed(2)} each</p>
            </div>
            <div className="flex items-center gap-1 border border-slate-200 rounded-full">
              <button onClick={() => updateQty(i, -1)} className="w-8 h-8">−</button>
              <span className="w-6 text-center">{c.quantity}</span>
              <button onClick={() => updateQty(i, +1)} className="w-8 h-8">+</button>
            </div>
            <div className="font-semibold w-20 text-right">${((c.price_cents * c.quantity) / 100).toFixed(2)}</div>
          </div>
        ))}
      </div>
      <div className="card p-4 mt-3">
        <div className="flex justify-between font-semibold">
          <span>Subtotal</span>
          <span>${(subtotal / 100).toFixed(2)}</span>
        </div>
        <p className="text-xs text-slate-500 mt-1">Tax and tip calculated at checkout.</p>
      </div>
      <button onClick={() => navigate('/checkout')} className="btn-primary mt-3 w-full">
        Continue to checkout
      </button>
    </>
  );
}
