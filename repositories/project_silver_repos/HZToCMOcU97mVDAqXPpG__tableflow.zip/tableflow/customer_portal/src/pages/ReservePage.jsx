import { useState } from 'react';
import { useForm } from 'react-hook-form';

export function ReservePage() {
  const [done, setDone] = useState(null);
  const { register, handleSubmit } = useForm({
    defaultValues: { party_size: 2, duration_minutes: 90 },
  });

  const submit = async (data) => {
    await new Promise((r) => setTimeout(r, 400));
    setDone(data);
  };

  if (done) {
    return (
      <div className="card p-8 max-w-md mx-auto text-center">
        <h2 className="text-xl font-bold mb-2">Reservation requested</h2>
        <p className="text-sm text-slate-600 mb-3">We've received your request for {done.party_size} on {done.starts_at}. Check your email for confirmation.</p>
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto">
      <h1 className="text-2xl font-bold mb-4">Reserve a table</h1>
      <form onSubmit={handleSubmit(submit)} className="card p-5 space-y-3">
        <input className="input" placeholder="Name" {...register('customer_name', { required: true })} />
        <input className="input" type="tel" placeholder="Phone" {...register('customer_phone', { required: true })} />
        <input className="input" type="email" placeholder="Email" {...register('customer_email')} />
        <div className="grid grid-cols-2 gap-3">
          <input className="input" type="number" min="1" placeholder="Party size" {...register('party_size', { valueAsNumber: true, required: true })} />
          <input className="input" type="datetime-local" {...register('starts_at', { required: true })} />
        </div>
        <textarea className="input min-h-[5rem]" placeholder="Notes (e.g. window seat)" {...register('notes')} />
        <button type="submit" className="btn-primary w-full">Request reservation</button>
      </form>
    </div>
  );
}
