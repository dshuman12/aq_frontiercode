import { useState } from 'react';
import { useStore } from '../store';
import { Link } from 'react-router-dom';

const SAMPLE = {
  categories: [
    { id: 'apps', name: 'Starters' },
    { id: 'mains', name: 'Mains' },
    { id: 'sides', name: 'Sides' },
    { id: 'drinks', name: 'Drinks' },
  ],
  items: [
    { id: 'i1', category: 'apps', name: 'Bruschetta', description: 'Tomato, basil, garlic', base_price_cents: 800 },
    { id: 'i2', category: 'apps', name: 'Soup of the day', description: 'Chef\'s choice', base_price_cents: 700 },
    { id: 'i3', category: 'mains', name: 'Margherita pizza', description: 'San Marzano, mozzarella di bufala', base_price_cents: 1600 },
    { id: 'i4', category: 'mains', name: 'Pasta carbonara', description: 'Guanciale, pecorino, egg yolk', base_price_cents: 1700 },
    { id: 'i5', category: 'sides', name: 'Truffle fries', description: 'House cut, parmesan', base_price_cents: 800 },
    { id: 'i6', category: 'drinks', name: 'House lemonade', description: 'Honey-sweetened', base_price_cents: 500 },
  ],
};

export function MenuPage() {
  const [activeCat, setActiveCat] = useState('apps');
  const addToCart = useStore((s) => s.addToCart);

  return (
    <>
      <h1 className="text-2xl font-bold mb-3">Menu</h1>
      <div className="flex gap-2 mb-4 overflow-x-auto pb-2">
        {SAMPLE.categories.map((c) => (
          <button
            key={c.id}
            onClick={() => setActiveCat(c.id)}
            className={'px-4 py-2 rounded-full text-sm font-medium ' + (activeCat === c.id ? 'bg-brand-600 text-white' : 'bg-white border border-slate-200')}
          >
            {c.name}
          </button>
        ))}
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {SAMPLE.items.filter((i) => i.category === activeCat).map((item) => (
          <div key={item.id} className="card p-4 flex flex-col">
            <h3 className="font-semibold">{item.name}</h3>
            <p className="text-sm text-slate-600 flex-1">{item.description}</p>
            <div className="mt-3 flex items-center justify-between">
              <span className="font-bold">${(item.base_price_cents / 100).toFixed(2)}</span>
              <button
                className="btn-primary h-9 px-4 text-sm"
                onClick={() => addToCart({ menu_item: item.id, name: item.name, price_cents: item.base_price_cents, quantity: 1, modifier_options: [] })}
              >
                Add
              </button>
            </div>
          </div>
        ))}
      </div>
      <div className="mt-6">
        <Link to="/cart" className="btn-primary">Go to cart →</Link>
      </div>
    </>
  );
}
