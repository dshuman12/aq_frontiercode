import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { useStore } from '../store';
import { portalApi } from '../api';

export function LoginPage() {
  const setAuth = useStore((s) => s.setAuth);
  const navigate = useNavigate();
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);
  const [mode, setMode] = useState('login');
  const { register, handleSubmit } = useForm();

  const submit = async (data) => {
    setBusy(true);
    setError(null);
    try {
      const r = mode === 'login' ? await portalApi.login(data) : await portalApi.register(data);
      setAuth({ access_token: r.access_token, user: r.user });
      navigate('/orders');
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="max-w-md mx-auto">
      <h1 className="text-2xl font-bold mb-4">{mode === 'login' ? 'Sign in' : 'Create account'}</h1>
      {error && <div className="rounded-lg bg-red-50 border border-red-200 text-red-800 px-3 py-2 text-sm mb-3">{error}</div>}
      <form onSubmit={handleSubmit(submit)} className="card p-5 space-y-3">
        {mode === 'register' && <input className="input" placeholder="Full name" {...register('name', { required: true })} />}
        <input className="input" type="email" placeholder="Email" {...register('email', { required: true })} />
        <input className="input" type="password" placeholder="Password" {...register('password', { required: true })} />
        <button type="submit" disabled={busy} className="btn-primary w-full">
          {busy ? 'Working…' : mode === 'login' ? 'Sign in' : 'Create account'}
        </button>
      </form>
      <p className="text-sm text-center mt-3">
        {mode === 'login' ? (
          <>New here? <button onClick={() => setMode('register')} className="text-brand-700">Create account</button></>
        ) : (
          <>Already have an account? <button onClick={() => setMode('login')} className="text-brand-700">Sign in</button></>
        )}
      </p>
    </div>
  );
}
