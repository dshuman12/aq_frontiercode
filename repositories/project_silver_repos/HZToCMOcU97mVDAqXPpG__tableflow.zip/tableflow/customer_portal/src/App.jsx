import { Routes, Route, Link, NavLink } from 'react-router-dom';
import { HomePage } from './pages/HomePage';
import { MenuPage } from './pages/MenuPage';
import { CartPage } from './pages/CartPage';
import { CheckoutPage } from './pages/CheckoutPage';
import { OrderStatusPage } from './pages/OrderStatusPage';
import { ReservePage } from './pages/ReservePage';
import { LoginPage } from './pages/LoginPage';
import { OrdersPage } from './pages/OrdersPage';
import { useStore } from './store';

export function App() {
  const cart = useStore((s) => s.cart);
  const user = useStore((s) => s.user);

  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-white border-b border-slate-100 sticky top-0 z-30">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center gap-3">
          <Link to="/" className="font-bold text-lg text-brand-700">TableFlow</Link>
          <nav className="ml-3 text-sm flex items-center gap-3">
            <NavLink to="/menu" className={({ isActive }) => isActive ? 'text-brand-700 font-medium' : 'text-slate-700'}>Menu</NavLink>
            <NavLink to="/reserve" className={({ isActive }) => isActive ? 'text-brand-700 font-medium' : 'text-slate-700'}>Reserve</NavLink>
            {user && <NavLink to="/orders" className={({ isActive }) => isActive ? 'text-brand-700 font-medium' : 'text-slate-700'}>My orders</NavLink>}
          </nav>
          <div className="ml-auto flex items-center gap-2">
            <Link to="/cart" className="relative">
              🛒
              {cart.length > 0 && (
                <span className="absolute -top-2 -right-2 bg-brand-600 text-white text-[10px] rounded-full px-1.5 py-0.5">{cart.reduce((s, c) => s + c.quantity, 0)}</span>
              )}
            </Link>
            {user ? (
              <span className="text-sm text-slate-600">Hi, {user.name?.split(' ')[0]}</span>
            ) : (
              <Link to="/login" className="text-sm text-brand-700 font-medium">Sign in</Link>
            )}
          </div>
        </div>
      </header>
      <main className="flex-1 max-w-5xl mx-auto px-4 py-6 w-full">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/menu" element={<MenuPage />} />
          <Route path="/cart" element={<CartPage />} />
          <Route path="/checkout" element={<CheckoutPage />} />
          <Route path="/orders" element={<OrdersPage />} />
          <Route path="/orders/:id" element={<OrderStatusPage />} />
          <Route path="/reserve" element={<ReservePage />} />
          <Route path="/login" element={<LoginPage />} />
        </Routes>
      </main>
      <footer className="border-t border-slate-100 py-4 text-center text-xs text-slate-500">
        Powered by TableFlow
      </footer>
    </div>
  );
}
