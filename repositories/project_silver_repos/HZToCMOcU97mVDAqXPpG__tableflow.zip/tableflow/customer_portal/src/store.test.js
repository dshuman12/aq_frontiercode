import { beforeEach, describe, expect, it } from 'vitest';
import { useStore } from './store';

describe('customer portal store', () => {
  beforeEach(() => {
    useStore.setState({ accessToken: null, user: null, cart: [] });
  });

  it('addToCart appends', () => {
    useStore.getState().addToCart({ menu_item: 'a', name: 'X', price_cents: 500, quantity: 1 });
    expect(useStore.getState().cart).toHaveLength(1);
  });

  it('updateQty increments and decrements', () => {
    useStore.getState().addToCart({ menu_item: 'a', name: 'X', price_cents: 500, quantity: 1 });
    useStore.getState().updateQty(0, 2);
    expect(useStore.getState().cart[0].quantity).toBe(3);
    useStore.getState().updateQty(0, -3);
    expect(useStore.getState().cart).toHaveLength(0);
  });

  it('cartSubtotal sums price × quantity across lines', () => {
    useStore.getState().addToCart({ menu_item: 'a', name: 'X', price_cents: 500, quantity: 2 });
    useStore.getState().addToCart({ menu_item: 'b', name: 'Y', price_cents: 1000, quantity: 1 });
    expect(useStore.getState().cartSubtotal()).toBe(2000);
  });

  it('clearCart empties everything', () => {
    useStore.getState().addToCart({ menu_item: 'a', name: 'X', price_cents: 100, quantity: 1 });
    useStore.getState().clearCart();
    expect(useStore.getState().cart).toEqual([]);
  });

  it('logout clears token and user', () => {
    useStore.setState({ accessToken: 'tok', user: { id: '1' } });
    useStore.getState().logout();
    expect(useStore.getState().accessToken).toBeNull();
    expect(useStore.getState().user).toBeNull();
  });
});
