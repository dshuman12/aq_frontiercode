"""Authentication services — registration, login, refresh, password reset."""
from __future__ import annotations

import secrets
from dataclasses import dataclass
from datetime import datetime, timezone

from django.conf import settings
from django.contrib.auth.hashers import check_password
from django.utils import timezone as djtz
from rest_framework.exceptions import AuthenticationFailed, NotFound, ValidationError

from . import jwt
from .hashing import hash_token, verify_token
from .models import EmailVerification, PasswordReset, Session, User


@dataclass(frozen=True)
class TokenPair:
    access: str
    refresh: str
    refresh_session_id: str


def issue_token_pair(
    user: User,
    *,
    restaurant_id: str | None = None,
    branch_id: str | None = None,
    role: str | None = None,
    permissions: list[str] | None = None,
    user_agent: str = "",
    ip: str | None = None,
) -> TokenPair:
    now = djtz.now()
    access_payload = {
        "sub": str(user.id),
        "email": user.email,
        "rid": restaurant_id,
        "bid": branch_id,
        "role": role,
        "perms": permissions or [],
        "kind": "access",
        "iat": int(now.timestamp()),
        "exp": int((now + settings.JWT_ACCESS_TTL).timestamp()),
        "jti": jwt.random_jti(),
    }
    access = jwt.encode(access_payload)

    refresh_token = secrets.token_urlsafe(48)
    session = Session.objects.create(
        user=user,
        refresh_token_hash=hash_token(refresh_token),
        user_agent=user_agent[:255],
        ip=ip,
        expires_at=now + settings.JWT_REFRESH_TTL,
    )
    return TokenPair(access=access, refresh=refresh_token, refresh_session_id=str(session.id))


def login(email: str, password: str, *, ua: str = "", ip: str | None = None, totp_code: str | None = None) -> tuple[User, TokenPair]:
    try:
        user = User.objects.get(email__iexact=email, is_active=True)
    except User.DoesNotExist as exc:
        raise AuthenticationFailed("invalid-credentials") from exc
    if not check_password(password, user.password):
        raise AuthenticationFailed("invalid-credentials")
    if user.totp_secret:
        from .totp import verify as verify_totp

        if not totp_code:
            raise AuthenticationFailed("totp-required")
        if not verify_totp(user.totp_secret, totp_code):
            raise AuthenticationFailed("invalid-totp")
    user.last_login_at = djtz.now()
    user.last_login_ip = ip
    user.save(update_fields=["last_login_at", "last_login_ip"])
    pair = issue_token_pair(user, user_agent=ua, ip=ip)
    return user, pair


def refresh(refresh_token: str) -> TokenPair:
    h = hash_token(refresh_token)
    try:
        session = Session.objects.select_related("user").get(refresh_token_hash=h, revoked_at__isnull=True)
    except Session.DoesNotExist as exc:
        raise AuthenticationFailed("invalid-refresh") from exc
    if not session.is_valid():
        raise AuthenticationFailed("expired-refresh")
    # Rotate
    session.revoked_at = djtz.now()
    session.save(update_fields=["revoked_at"])
    return issue_token_pair(session.user, user_agent=session.user_agent, ip=session.ip)


def logout_session(refresh_token: str) -> None:
    h = hash_token(refresh_token)
    Session.objects.filter(refresh_token_hash=h, revoked_at__isnull=True).update(revoked_at=djtz.now())


def request_password_reset(email: str) -> None:
    try:
        user = User.objects.get(email__iexact=email, is_active=True)
    except User.DoesNotExist:
        return  # do not leak account existence
    _, token = PasswordReset.issue(user)
    from apps.notifications.tasks import send_password_reset_email

    send_password_reset_email.delay(str(user.id), token)


def consume_password_reset(token: str, new_password: str) -> User:
    h = hash_token(token)
    try:
        pr = PasswordReset.objects.select_related("user").get(token_hash=h, used_at__isnull=True)
    except PasswordReset.DoesNotExist as exc:
        raise NotFound("reset-token-not-found") from exc
    if pr.expires_at < djtz.now():
        raise ValidationError({"token": "expired"})
    user = pr.user
    user.set_password(new_password)
    user.save(update_fields=["password"])
    pr.used_at = djtz.now()
    pr.save(update_fields=["used_at"])
    Session.objects.filter(user=user, revoked_at__isnull=True).update(revoked_at=djtz.now())
    return user
