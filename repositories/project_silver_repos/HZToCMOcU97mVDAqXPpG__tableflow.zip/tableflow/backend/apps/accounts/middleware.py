"""Middleware that resolves the active restaurant + branch from the JWT.

Every authenticated request needs a `restaurant_id` for tenant scoping. We
read it from the access-token claims so the request body can never spoof it.
"""
from __future__ import annotations

from collections.abc import Callable

from django.http import HttpRequest, HttpResponse


class RestaurantContextMiddleware:
    def __init__(self, get_response: Callable[[HttpRequest], HttpResponse]):
        self.get_response = get_response

    def __call__(self, request: HttpRequest) -> HttpResponse:
        request.restaurant_id = None  # type: ignore[attr-defined]
        request.branch_id = None  # type: ignore[attr-defined]
        request.role = None  # type: ignore[attr-defined]
        request.permissions = []  # type: ignore[attr-defined]
        claims = getattr(request, "auth_claims", None)
        if claims:
            request.restaurant_id = claims.get("rid")  # type: ignore[attr-defined]
            request.branch_id = claims.get("bid")  # type: ignore[attr-defined]
            request.role = claims.get("role")  # type: ignore[attr-defined]
            request.permissions = claims.get("perms", [])  # type: ignore[attr-defined]
        return self.get_response(request)
