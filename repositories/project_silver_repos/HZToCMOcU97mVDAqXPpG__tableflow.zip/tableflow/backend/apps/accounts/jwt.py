"""Lightweight HS256 JWT helpers — keeps deps small (no PyJWT)."""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import secrets
from datetime import datetime, timezone
from typing import Any

from django.conf import settings


def _b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()


def _b64url_decode(data: str) -> bytes:
    pad = "=" * (-len(data) % 4)
    return base64.urlsafe_b64decode(data + pad)


def encode(payload: dict[str, Any], *, secret: str | None = None) -> str:
    secret = secret or settings.SECRET_KEY
    header = {"alg": "HS256", "typ": "JWT"}
    h = _b64url_encode(json.dumps(header, separators=(",", ":")).encode())
    p = _b64url_encode(json.dumps(payload, separators=(",", ":")).encode())
    signing_input = f"{h}.{p}".encode()
    sig = hmac.new(secret.encode(), signing_input, hashlib.sha256).digest()
    s = _b64url_encode(sig)
    return f"{h}.{p}.{s}"


def decode(token: str, *, secret: str | None = None) -> dict[str, Any]:
    secret = secret or settings.SECRET_KEY
    try:
        h, p, s = token.split(".")
    except ValueError as exc:
        raise InvalidToken("Malformed token") from exc
    signing_input = f"{h}.{p}".encode()
    expected = hmac.new(secret.encode(), signing_input, hashlib.sha256).digest()
    if not hmac.compare_digest(_b64url_decode(s), expected):
        raise InvalidToken("Bad signature")
    payload = json.loads(_b64url_decode(p))
    exp = payload.get("exp")
    if exp and datetime.fromtimestamp(exp, tz=timezone.utc) < datetime.now(tz=timezone.utc):
        raise InvalidToken("Expired")
    return payload


def random_jti() -> str:
    return secrets.token_urlsafe(12)


class InvalidToken(Exception):
    pass
