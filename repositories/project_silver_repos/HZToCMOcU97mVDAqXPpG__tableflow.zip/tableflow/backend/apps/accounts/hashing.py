"""Token hashing helpers — refresh tokens, password resets, API keys."""
from __future__ import annotations

import hashlib
import hmac

from django.conf import settings


def hash_token(token: str) -> str:
    """HMAC-SHA256 hex digest using DJANGO_SECRET_KEY as the key.

    The secret key is rotated separately from the database, so a database
    leak alone does not expose useful refresh tokens.
    """
    return hmac.new(
        settings.SECRET_KEY.encode(),
        msg=token.encode(),
        digestmod=hashlib.sha256,
    ).hexdigest()


def verify_token(token: str, expected_hash: str) -> bool:
    return hmac.compare_digest(hash_token(token), expected_hash)
