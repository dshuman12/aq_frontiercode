"""Celery tasks for the accounts app."""
from __future__ import annotations

from celery import shared_task
from django.utils import timezone

from .models import EmailVerification, PasswordReset, Session


@shared_task
def cleanup_expired_sessions() -> dict:
    now = timezone.now()
    sessions = Session.objects.filter(expires_at__lt=now).delete()[0]
    resets = PasswordReset.objects.filter(expires_at__lt=now).delete()[0]
    verifs = EmailVerification.objects.filter(expires_at__lt=now).delete()[0]
    return {"sessions": sessions, "resets": resets, "verifications": verifs}
