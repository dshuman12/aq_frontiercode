"""RFC 7807 problem-details exception handler for DRF."""
from __future__ import annotations

from rest_framework import exceptions
from rest_framework.response import Response
from rest_framework.views import exception_handler


def problem_details_handler(exc, context):
    response = exception_handler(exc, context)
    if response is None:
        return None
    detail = getattr(exc, "detail", str(exc))
    title = getattr(exc, "default_code", "error").replace("_", " ").title()
    body = {
        "type": "about:blank",
        "title": title,
        "status": response.status_code,
        "detail": detail if isinstance(detail, str) else None,
        "errors": detail if not isinstance(detail, str) else None,
    }
    if isinstance(exc, exceptions.ValidationError):
        body["title"] = "Validation Error"
    return Response(body, status=response.status_code, headers=response.headers)
