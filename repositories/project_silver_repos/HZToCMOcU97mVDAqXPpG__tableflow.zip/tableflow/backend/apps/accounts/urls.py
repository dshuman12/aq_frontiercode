from django.urls import path

from . import views

urlpatterns = [
    path("register", views.RegisterView.as_view()),
    path("login", views.LoginView.as_view()),
    path("refresh", views.RefreshView.as_view()),
    path("logout", views.LogoutView.as_view()),
    path("me", views.MeView.as_view()),
    path("change-password", views.ChangePasswordView.as_view()),
    path("password-reset/request", views.PasswordResetRequestView.as_view()),
    path("password-reset/confirm", views.PasswordResetConfirmView.as_view()),
    path("totp/enroll", views.TotpEnrollView.as_view()),
    path("totp/disable", views.TotpDisableView.as_view()),
    path("sessions", views.SessionsView.as_view()),
]
