"""factory_boy factories for accounts."""
from __future__ import annotations

import factory
from django.contrib.auth import get_user_model

User = get_user_model()


class UserFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = User

    email = factory.Sequence(lambda n: f"user{n}@tableflow.test")
    name = factory.Faker("name")
    password = factory.PostGenerationMethodCall("set_password", "longenough123")
