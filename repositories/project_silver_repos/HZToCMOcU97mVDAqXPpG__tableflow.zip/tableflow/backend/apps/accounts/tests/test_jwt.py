from datetime import datetime, timedelta, timezone

import pytest

from apps.accounts import jwt


def test_encode_decode_roundtrip(settings):
    payload = {"sub": "abc", "kind": "access"}
    token = jwt.encode(payload)
    out = jwt.decode(token)
    assert out["sub"] == "abc"
    assert out["kind"] == "access"


def test_decode_rejects_tampered_signature():
    token = jwt.encode({"sub": "x"})
    bad = token[:-2] + ("AA" if token[-2:] != "AA" else "BB")
    with pytest.raises(jwt.InvalidToken):
        jwt.decode(bad)


def test_decode_rejects_expired_token():
    exp = int((datetime.now(tz=timezone.utc) - timedelta(minutes=1)).timestamp())
    token = jwt.encode({"sub": "x", "exp": exp})
    with pytest.raises(jwt.InvalidToken):
        jwt.decode(token)


def test_decode_malformed_token():
    with pytest.raises(jwt.InvalidToken):
        jwt.decode("not-a-jwt")
