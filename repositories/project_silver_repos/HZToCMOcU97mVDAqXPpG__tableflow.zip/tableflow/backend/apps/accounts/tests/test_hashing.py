from apps.accounts.hashing import hash_token, verify_token


def test_round_trip_verifies():
    token = "abc-token-123"
    h = hash_token(token)
    assert verify_token(token, h)


def test_different_tokens_produce_different_hashes():
    assert hash_token("a") != hash_token("b")


def test_verify_rejects_wrong_token():
    h = hash_token("right")
    assert not verify_token("wrong", h)


def test_hash_is_deterministic():
    assert hash_token("x") == hash_token("x")
