from apps.accounts import totp


def test_new_secret_is_base32():
    s = totp.new_secret()
    assert len(s) >= 16
    assert all(c in "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567" for c in s)


def test_current_code_verifies():
    s = totp.new_secret()
    code = totp.code_for(s)
    assert totp.verify(s, code)


def test_wrong_code_rejected():
    s = totp.new_secret()
    assert not totp.verify(s, "000000")
