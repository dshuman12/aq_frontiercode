"""Authentication views."""
from __future__ import annotations

from django.contrib.auth.password_validation import validate_password
from django.utils import timezone as djtz
from rest_framework import status
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from . import services, totp
from .models import User
from .serializers import (
    ChangePasswordSerializer,
    LoginSerializer,
    PasswordResetConfirmSerializer,
    PasswordResetRequestSerializer,
    ProfileSerializer,
    RefreshSerializer,
    RegisterSerializer,
    TotpEnrollSerializer,
)


def _client_meta(request):
    ua = request.META.get("HTTP_USER_AGENT", "")
    ip = request.META.get("HTTP_X_FORWARDED_FOR", "").split(",")[0].strip() or request.META.get("REMOTE_ADDR")
    return ua, ip


class RegisterView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = RegisterSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = User.objects.create_user(**serializer.validated_data)
        ua, ip = _client_meta(request)
        pair = services.issue_token_pair(user, user_agent=ua, ip=ip)
        return Response(
            {
                "user": ProfileSerializer(user).data,
                "access_token": pair.access,
                "refresh_token": pair.refresh,
            },
            status=status.HTTP_201_CREATED,
        )


class LoginView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        ua, ip = _client_meta(request)
        user, pair = services.login(
            email=serializer.validated_data["email"],
            password=serializer.validated_data["password"],
            ua=ua,
            ip=ip,
            totp_code=serializer.validated_data.get("totp_code") or None,
        )
        return Response(
            {
                "user": ProfileSerializer(user).data,
                "access_token": pair.access,
                "refresh_token": pair.refresh,
            }
        )


class RefreshView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = RefreshSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        pair = services.refresh(serializer.validated_data["refresh_token"])
        return Response({"access_token": pair.access, "refresh_token": pair.refresh})


class LogoutView(APIView):
    def post(self, request):
        rt = request.data.get("refresh_token")
        if rt:
            services.logout_session(rt)
        return Response(status=status.HTTP_204_NO_CONTENT)


class MeView(APIView):
    def get(self, request):
        return Response(ProfileSerializer(request.user).data)

    def patch(self, request):
        serializer = ProfileSerializer(request.user, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)


class ChangePasswordView(APIView):
    def post(self, request):
        serializer = ChangePasswordSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        from django.contrib.auth.hashers import check_password

        if not check_password(serializer.validated_data["current_password"], request.user.password):
            return Response({"detail": "wrong-password"}, status=status.HTTP_400_BAD_REQUEST)
        request.user.set_password(serializer.validated_data["new_password"])
        request.user.save(update_fields=["password"])
        return Response(status=status.HTTP_204_NO_CONTENT)


class PasswordResetRequestView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = PasswordResetRequestSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        services.request_password_reset(serializer.validated_data["email"])
        return Response(status=status.HTTP_202_ACCEPTED)


class PasswordResetConfirmView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = PasswordResetConfirmSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        validate_password(serializer.validated_data["password"])
        services.consume_password_reset(
            serializer.validated_data["token"], serializer.validated_data["password"]
        )
        return Response(status=status.HTTP_204_NO_CONTENT)


class TotpEnrollView(APIView):
    def get(self, request):
        secret = totp.new_secret()
        request.session["pending_totp_secret"] = secret
        uri = totp.provisioning_uri(secret, request.user.email)
        qr = totp.provisioning_qr_data_url(secret, request.user.email)
        return Response({"secret": secret, "otpauth_url": uri, "qr_data_url": qr})

    def post(self, request):
        serializer = TotpEnrollSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        secret = request.session.get("pending_totp_secret")
        if not secret or not totp.verify(secret, serializer.validated_data["code"]):
            return Response({"detail": "invalid-code"}, status=status.HTTP_400_BAD_REQUEST)
        request.user.totp_secret = secret
        request.user.totp_enrolled_at = djtz.now()
        request.user.save(update_fields=["totp_secret", "totp_enrolled_at"])
        request.session.pop("pending_totp_secret", None)
        return Response(status=status.HTTP_204_NO_CONTENT)


class TotpDisableView(APIView):
    def post(self, request):
        serializer = TotpEnrollSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        if not request.user.totp_secret or not totp.verify(request.user.totp_secret, serializer.validated_data["code"]):
            return Response({"detail": "invalid-code"}, status=status.HTTP_400_BAD_REQUEST)
        request.user.totp_secret = ""
        request.user.totp_enrolled_at = None
        request.user.save(update_fields=["totp_secret", "totp_enrolled_at"])
        return Response(status=status.HTTP_204_NO_CONTENT)


class SessionsView(APIView):
    def get(self, request):
        rows = [
            {
                "id": str(s.id),
                "ip": s.ip,
                "user_agent": s.user_agent,
                "created_at": s.created_at,
                "expires_at": s.expires_at,
                "revoked_at": s.revoked_at,
            }
            for s in request.user.sessions.order_by("-created_at")[:50]
        ]
        return Response(rows)


class HealthView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        return Response({"status": "ok"})
