"""DRF authentication backend that validates HS256 access tokens."""
from __future__ import annotations

from rest_framework import authentication, exceptions

from .jwt import InvalidToken, decode
from .models import User


class JWTAuthentication(authentication.BaseAuthentication):
    keyword = "Bearer"

    def authenticate(self, request):  # type: ignore[override]
        header = request.META.get("HTTP_AUTHORIZATION", "")
        if not header.startswith(f"{self.keyword} "):
            return None
        token = header.removeprefix(f"{self.keyword} ").strip()
        try:
            claims = decode(token)
        except InvalidToken as exc:
            raise exceptions.AuthenticationFailed(str(exc)) from exc
        if claims.get("kind") not in (None, "access"):
            raise exceptions.AuthenticationFailed("wrong-token-kind")
        try:
            user = User.objects.get(pk=claims["sub"], is_active=True)
        except User.DoesNotExist as exc:
            raise exceptions.AuthenticationFailed("user-not-found") from exc
        request.auth_claims = claims
        return (user, claims)

    def authenticate_header(self, request):  # type: ignore[override]
        return self.keyword
