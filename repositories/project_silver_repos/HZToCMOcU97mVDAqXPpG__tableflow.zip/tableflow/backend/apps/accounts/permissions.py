"""Permission-string helpers shared across DRF views."""
from __future__ import annotations

from rest_framework import permissions
from rest_framework.exceptions import PermissionDenied


def has_perm(request, code: str) -> bool:
    perms = getattr(request, "permissions", []) or []
    return code in perms or "*" in perms


def require_perm(request, code: str) -> None:
    if not has_perm(request, code):
        raise PermissionDenied(detail=f"missing-permission:{code}")


class HasPermission(permissions.BasePermission):
    """View permission. Subclass with `code` set, or set `required_perm` on the view."""

    code: str | None = None

    def has_permission(self, request, view):  # type: ignore[override]
        if not request.user or not request.user.is_authenticated:
            return False
        code = self.code or getattr(view, "required_perm", None)
        if code is None:
            return True
        return has_perm(request, code)


def perm(code: str) -> type[HasPermission]:
    return type(f"Has_{code.replace(':','_')}", (HasPermission,), {"code": code})


class IsRestaurantMember(permissions.BasePermission):
    def has_permission(self, request, view):  # type: ignore[override]
        return bool(request.user and request.user.is_authenticated and getattr(request, "restaurant_id", None))
