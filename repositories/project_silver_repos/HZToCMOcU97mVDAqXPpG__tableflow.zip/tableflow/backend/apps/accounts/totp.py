"""RFC 6238 TOTP wrapper around pyotp with QR provisioning helper."""
from __future__ import annotations

import io
from base64 import b64encode

import pyotp
import qrcode
from django.conf import settings


def new_secret() -> str:
    return pyotp.random_base32()


def code_for(secret: str, when: int | None = None) -> str:
    return pyotp.TOTP(secret).at(when) if when else pyotp.TOTP(secret).now()


def verify(secret: str, code: str, *, valid_window: int = 1) -> bool:
    return pyotp.TOTP(secret).verify(code, valid_window=valid_window)


def provisioning_uri(secret: str, label: str, issuer: str | None = None) -> str:
    issuer = issuer or "TableFlow"
    return pyotp.TOTP(secret).provisioning_uri(name=label, issuer_name=issuer)


def provisioning_qr_data_url(secret: str, label: str, issuer: str | None = None) -> str:
    uri = provisioning_uri(secret, label, issuer)
    img = qrcode.make(uri)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return f"data:image/png;base64,{b64encode(buf.getvalue()).decode()}"
