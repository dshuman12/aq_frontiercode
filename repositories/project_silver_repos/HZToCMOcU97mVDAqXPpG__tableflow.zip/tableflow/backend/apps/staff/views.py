from django.utils import timezone
from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.accounts.permissions import perm

from .models import StaffProfile, StaffShift, TimeClockEntry
from .serializers import StaffProfileSerializer, StaffShiftSerializer, TimeClockEntrySerializer


class StaffProfileList(generics.ListCreateAPIView):
    serializer_class = StaffProfileSerializer
    permission_classes = [perm("staff:read")]
    search_fields = ["title", "employee_code"]

    def get_queryset(self):  # type: ignore[override]
        return StaffProfile.objects.filter(restaurant_id=self.request.restaurant_id).select_related("user")

    def perform_create(self, serializer):  # type: ignore[override]
        serializer.save(restaurant_id=self.request.restaurant_id)


class StaffProfileDetail(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = StaffProfileSerializer
    permission_classes = [perm("staff:read")]

    def get_queryset(self):  # type: ignore[override]
        return StaffProfile.objects.filter(restaurant_id=self.request.restaurant_id)


class ShiftList(generics.ListCreateAPIView):
    serializer_class = StaffShiftSerializer
    permission_classes = [perm("shifts:read")]
    filterset_fields = ["branch", "user"]

    def get_queryset(self):  # type: ignore[override]
        qs = StaffShift.objects.filter(restaurant_id=self.request.restaurant_id, cancelled_at__isnull=True)
        date_from = self.request.query_params.get("from")
        date_to = self.request.query_params.get("to")
        if date_from:
            qs = qs.filter(starts_at__gte=date_from)
        if date_to:
            qs = qs.filter(starts_at__lte=date_to)
        return qs

    def perform_create(self, serializer):  # type: ignore[override]
        serializer.save(restaurant_id=self.request.restaurant_id)


class ShiftDetail(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = StaffShiftSerializer
    permission_classes = [perm("shifts:read")]

    def get_queryset(self):  # type: ignore[override]
        return StaffShift.objects.filter(restaurant_id=self.request.restaurant_id)


class ClockInView(APIView):
    permission_classes = [perm("time-clock:write")]

    def post(self, request):
        branch_id = request.data.get("branch") or request.branch_id
        TimeClockEntry.objects.filter(
            restaurant_id=request.restaurant_id,
            user=request.user,
            clock_out_at__isnull=True,
        ).update(clock_out_at=timezone.now())
        entry = TimeClockEntry.objects.create(
            restaurant_id=request.restaurant_id,
            user=request.user,
            branch_id=branch_id,
            clock_in_at=timezone.now(),
        )
        return Response(TimeClockEntrySerializer(entry).data, status=status.HTTP_201_CREATED)


class ClockOutView(APIView):
    permission_classes = [perm("time-clock:write")]

    def post(self, request):
        try:
            entry = TimeClockEntry.objects.get(
                restaurant_id=request.restaurant_id,
                user=request.user,
                clock_out_at__isnull=True,
            )
        except TimeClockEntry.DoesNotExist:
            return Response({"detail": "no-active-clock-in"}, status=status.HTTP_400_BAD_REQUEST)
        entry.clock_out_at = timezone.now()
        entry.break_minutes = int(request.data.get("break_minutes", 0))
        entry.save(update_fields=["clock_out_at", "break_minutes"])
        return Response(TimeClockEntrySerializer(entry).data)


class TimeClockList(generics.ListAPIView):
    serializer_class = TimeClockEntrySerializer
    permission_classes = [perm("staff:read")]
    filterset_fields = ["user", "branch"]
    ordering = ["-clock_in_at"]

    def get_queryset(self):  # type: ignore[override]
        return TimeClockEntry.objects.filter(restaurant_id=self.request.restaurant_id)
