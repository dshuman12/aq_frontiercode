from django.contrib import admin

from .models import StaffProfile, StaffShift, TimeClockEntry


@admin.register(StaffShift)
class StaffShiftAdmin(admin.ModelAdmin):
    list_display = ("user", "branch", "starts_at", "ends_at", "role_label", "published_at")
    list_filter = ("branch", "role_label")
    date_hierarchy = "starts_at"


admin.site.register([StaffProfile, TimeClockEntry])
