"""Staff profile, shift schedule, and time-clock entries."""
from __future__ import annotations

import uuid

from django.conf import settings
from django.db import models


class StaffProfile(models.Model):
    PAY_TYPE_CHOICES = [("hourly", "Hourly"), ("salary", "Salary"), ("contract", "Contract")]
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(db_index=True)
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="staff_profile")
    employee_code = models.CharField(max_length=24, blank=True)
    title = models.CharField(max_length=80, blank=True)
    pay_type = models.CharField(max_length=10, choices=PAY_TYPE_CHOICES, default="hourly")
    hourly_rate_cents = models.PositiveIntegerField(default=0)
    salary_cents = models.PositiveIntegerField(default=0)
    hired_on = models.DateField(null=True, blank=True)
    terminated_on = models.DateField(null=True, blank=True)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "staff_profile"
        unique_together = ("restaurant_id", "user")


class StaffShift(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(db_index=True)
    branch = models.ForeignKey("branches.Branch", on_delete=models.CASCADE, related_name="shifts")
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="shifts")
    starts_at = models.DateTimeField(db_index=True)
    ends_at = models.DateTimeField()
    role_label = models.CharField(max_length=80, blank=True)
    notes = models.CharField(max_length=200, blank=True)
    published_at = models.DateTimeField(null=True, blank=True)
    cancelled_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "staff_shift"
        indexes = [models.Index(fields=["restaurant_id", "branch", "starts_at"])]


class TimeClockEntry(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(db_index=True)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="time_entries")
    branch = models.ForeignKey("branches.Branch", on_delete=models.CASCADE, related_name="time_entries")
    clock_in_at = models.DateTimeField()
    clock_out_at = models.DateTimeField(null=True, blank=True)
    break_minutes = models.PositiveIntegerField(default=0)
    notes = models.CharField(max_length=200, blank=True)

    class Meta:
        db_table = "staff_time_clock"
        indexes = [models.Index(fields=["restaurant_id", "user", "clock_in_at"])]

    @property
    def duration_minutes(self) -> int | None:
        if not self.clock_out_at:
            return None
        delta = self.clock_out_at - self.clock_in_at
        return max(0, int(delta.total_seconds() // 60) - self.break_minutes)
