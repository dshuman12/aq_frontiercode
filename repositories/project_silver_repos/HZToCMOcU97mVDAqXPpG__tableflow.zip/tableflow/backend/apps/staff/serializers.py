from rest_framework import serializers

from .models import StaffProfile, StaffShift, TimeClockEntry


class StaffProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = StaffProfile
        fields = "__all__"
        read_only_fields = ["id", "restaurant_id", "created_at", "updated_at"]


class StaffShiftSerializer(serializers.ModelSerializer):
    class Meta:
        model = StaffShift
        fields = "__all__"
        read_only_fields = ["id", "restaurant_id", "created_at"]

    def validate(self, attrs):
        if attrs.get("ends_at") and attrs.get("starts_at") and attrs["ends_at"] <= attrs["starts_at"]:
            raise serializers.ValidationError({"ends_at": "must be after starts_at"})
        return attrs


class TimeClockEntrySerializer(serializers.ModelSerializer):
    duration_minutes = serializers.IntegerField(read_only=True)

    class Meta:
        model = TimeClockEntry
        fields = "__all__"
        read_only_fields = ["id", "restaurant_id", "duration_minutes"]
