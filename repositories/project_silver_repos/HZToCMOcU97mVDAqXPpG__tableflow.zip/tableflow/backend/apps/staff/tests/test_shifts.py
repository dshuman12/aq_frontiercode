"""Shift overlap detection — pure logic."""
from datetime import datetime, timedelta


def shifts_conflict(a_start, a_end, b_start, b_end):
    return a_start < b_end and b_start < a_end


def total_minutes(starts_at, ends_at):
    return int((ends_at - starts_at).total_seconds() // 60)


def test_back_to_back_does_not_conflict():
    a = (datetime(2024, 8, 15, 9, 0), datetime(2024, 8, 15, 14, 0))
    b = (datetime(2024, 8, 15, 14, 0), datetime(2024, 8, 15, 19, 0))
    assert not shifts_conflict(*a, *b)


def test_overlap_blocks_assignment():
    a = (datetime(2024, 8, 15, 9, 0), datetime(2024, 8, 15, 14, 0))
    b = (datetime(2024, 8, 15, 13, 0), datetime(2024, 8, 15, 18, 0))
    assert shifts_conflict(*a, *b)


def test_total_minutes_handles_long_shift():
    out = total_minutes(datetime(2024, 8, 15, 9, 0), datetime(2024, 8, 15, 21, 30))
    assert out == 750
