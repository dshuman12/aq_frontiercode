from datetime import datetime, timedelta


def test_duration_subtracts_break_minutes():
    start = datetime(2024, 8, 15, 9, 0)
    end = datetime(2024, 8, 15, 17, 30)
    break_min = 30
    minutes = int((end - start).total_seconds() // 60) - break_min
    assert minutes == 480


def test_clocking_in_again_closes_open_punch():
    """The clock-in handler closes any active punch first, then opens a new one."""
    open_punches = [{"clock_out_at": None}]
    closed = sum(1 for p in open_punches if p["clock_out_at"] is None)
    assert closed == 1


def test_duration_for_unfinished_returns_none():
    start = datetime(2024, 8, 15, 9, 0)
    end = None
    if end is None:
        duration = None
    else:
        duration = int((end - start).total_seconds() // 60)
    assert duration is None
