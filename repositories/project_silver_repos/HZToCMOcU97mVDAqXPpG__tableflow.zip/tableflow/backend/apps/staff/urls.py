from django.urls import path

from . import views

urlpatterns = [
    path("", views.StaffProfileList.as_view()),
    path("<uuid:pk>", views.StaffProfileDetail.as_view()),
    path("shifts", views.ShiftList.as_view()),
    path("shifts/<uuid:pk>", views.ShiftDetail.as_view()),
    path("time-clock", views.TimeClockList.as_view()),
    path("time-clock/in", views.ClockInView.as_view()),
    path("time-clock/out", views.ClockOutView.as_view()),
]
