from rest_framework import serializers

from .models import Menu, MenuCategory, MenuItem, MenuItemPhoto, MenuItemVariant


class MenuItemVariantSerializer(serializers.ModelSerializer):
    class Meta:
        model = MenuItemVariant
        fields = "__all__"
        read_only_fields = ["id"]


class MenuItemPhotoSerializer(serializers.ModelSerializer):
    class Meta:
        model = MenuItemPhoto
        fields = "__all__"
        read_only_fields = ["id"]


class MenuItemSerializer(serializers.ModelSerializer):
    variants = MenuItemVariantSerializer(many=True, read_only=True)
    photos = MenuItemPhotoSerializer(many=True, read_only=True)

    class Meta:
        model = MenuItem
        fields = "__all__"
        read_only_fields = ["id", "restaurant_id", "created_at", "updated_at"]


class MenuCategorySerializer(serializers.ModelSerializer):
    items = MenuItemSerializer(many=True, read_only=True)

    class Meta:
        model = MenuCategory
        fields = ["id", "menu", "name", "sort_order", "is_active", "description", "items"]
        read_only_fields = ["id"]


class MenuSerializer(serializers.ModelSerializer):
    categories = MenuCategorySerializer(many=True, read_only=True)

    class Meta:
        model = Menu
        fields = "__all__"
        read_only_fields = ["id", "slug", "created_at", "updated_at"]
