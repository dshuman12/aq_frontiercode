"""More edge-case pricing math tests."""
from __future__ import annotations

import pytest

from apps.menus.pricing import (
    LineItemSpec,
    apply_tax_cents,
    discounted_total_cents,
    line_item_total_cents,
)


def test_zero_modifier_options_tuple_is_handled():
    spec = LineItemSpec(base_price_cents=1000, modifier_options=(), quantity=1)
    assert line_item_total_cents(spec) == 1000


def test_negative_quantity_raises():
    with pytest.raises(ValueError):
        line_item_total_cents(LineItemSpec(base_price_cents=100, quantity=-1))


def test_discount_percent_then_zero_fixed():
    # 25% off $40 = $30
    assert discounted_total_cents(4000, percent_off=25) == 3000


def test_discount_percent_out_of_range_raises():
    with pytest.raises(ValueError):
        discounted_total_cents(1000, percent_off=150)
    with pytest.raises(ValueError):
        discounted_total_cents(1000, percent_off=-1)


def test_apply_tax_zero_rate_returns_zero():
    assert apply_tax_cents(50000, tax_rate=0) == 0


def test_apply_tax_negative_rate_raises():
    with pytest.raises(ValueError):
        apply_tax_cents(100, tax_rate=-0.01)


def test_modifiers_can_subtract_below_base():
    """A 'no cheese' option might give -50 cents off."""
    spec = LineItemSpec(base_price_cents=1000, modifier_options=(-50,), quantity=2)
    assert line_item_total_cents(spec) == 1900
