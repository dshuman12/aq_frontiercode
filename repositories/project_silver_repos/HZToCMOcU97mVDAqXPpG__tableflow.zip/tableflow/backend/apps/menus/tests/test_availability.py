from datetime import datetime, time

from apps.menus.availability import item_is_orderable, menu_is_available


def at(d: str, t: str) -> datetime:
    return datetime.fromisoformat(f"{d}T{t}")


def test_no_schedule_means_always_available():
    assert menu_is_available(starts_at=None, ends_at=None, weekdays=[], now=at("2024-08-15", "12:00"))


def test_within_window_returns_true():
    assert menu_is_available(starts_at=time(11, 0), ends_at=time(15, 0), weekdays=[], now=at("2024-08-15", "12:30"))


def test_outside_window_returns_false():
    assert not menu_is_available(starts_at=time(11, 0), ends_at=time(15, 0), weekdays=[], now=at("2024-08-15", "16:30"))


def test_overnight_window():
    # 22:00 -> 02:00 next day
    assert menu_is_available(starts_at=time(22, 0), ends_at=time(2, 0), weekdays=[], now=at("2024-08-15", "23:30"))
    assert menu_is_available(starts_at=time(22, 0), ends_at=time(2, 0), weekdays=[], now=at("2024-08-16", "01:00"))
    assert not menu_is_available(starts_at=time(22, 0), ends_at=time(2, 0), weekdays=[], now=at("2024-08-15", "12:00"))


def test_weekday_restriction():
    # 2024-08-15 is Thursday (weekday=3); allow only weekends
    assert not menu_is_available(starts_at=None, ends_at=None, weekdays=[5, 6], now=at("2024-08-15", "12:00"))
    # Saturday
    assert menu_is_available(starts_at=None, ends_at=None, weekdays=[5, 6], now=at("2024-08-17", "12:00"))


def test_item_orderable_requires_all_signals():
    assert item_is_orderable(item_available=True, menu_available=True, sold_out=False)
    assert not item_is_orderable(item_available=False, menu_available=True)
    assert not item_is_orderable(item_available=True, menu_available=False)
    assert not item_is_orderable(item_available=True, menu_available=True, sold_out=True)
