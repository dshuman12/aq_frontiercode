"""More menu-availability scenarios."""
from datetime import datetime, time

from apps.menus.availability import menu_is_available


def test_only_starts_at_acts_as_floor():
    assert menu_is_available(starts_at=time(11, 0), ends_at=None, weekdays=[], now=datetime(2024, 8, 15, 12, 0))
    assert not menu_is_available(starts_at=time(11, 0), ends_at=None, weekdays=[], now=datetime(2024, 8, 15, 10, 0))


def test_only_ends_at_acts_as_ceiling():
    assert menu_is_available(starts_at=None, ends_at=time(15, 0), weekdays=[], now=datetime(2024, 8, 15, 14, 30))
    assert not menu_is_available(starts_at=None, ends_at=time(15, 0), weekdays=[], now=datetime(2024, 8, 15, 16, 0))


def test_weekday_zero_is_monday_in_python():
    # 2024-08-12 is a Monday → weekday=0
    assert menu_is_available(starts_at=None, ends_at=None, weekdays=[0], now=datetime(2024, 8, 12, 12, 0))
    assert not menu_is_available(starts_at=None, ends_at=None, weekdays=[0], now=datetime(2024, 8, 13, 12, 0))


def test_overnight_at_midnight():
    assert menu_is_available(starts_at=time(22, 0), ends_at=time(2, 0), weekdays=[], now=datetime(2024, 8, 16, 0, 0))
