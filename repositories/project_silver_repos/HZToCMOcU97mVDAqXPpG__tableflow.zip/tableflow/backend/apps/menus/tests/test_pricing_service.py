"""Round-trip tests combining variant + multi-modifier + tax + discount."""
from apps.menus.pricing import (
    LineItemSpec,
    apply_tax_cents,
    discounted_total_cents,
    line_item_total_cents,
)


def test_full_pizza_order():
    # Margherita base $16, large +$3, two toppings $1.50 + $2.50, qty 2
    spec = LineItemSpec(
        base_price_cents=1600,
        variant_delta_cents=300,
        modifier_options=(150, 250),
        quantity=2,
    )
    line_total = line_item_total_cents(spec)
    # (1600 + 300 + 150 + 250) * 2 = 4600
    assert line_total == 4600


def test_apply_15_percent_discount_then_8_25_tax():
    subtotal = 4600
    after_discount = discounted_total_cents(subtotal, percent_off=15)
    tax = apply_tax_cents(after_discount, tax_rate=0.0825)
    total = after_discount + tax
    # 4600 - 15% = 3910 ; tax = 323 ; total = 4233
    assert after_discount == 3910
    assert tax == 323
    assert total == 4233
