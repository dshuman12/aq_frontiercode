"""Combo meal pricing — fixed price vs sum of items."""


def combo_savings(items_total_cents, combo_price_cents):
    return max(0, items_total_cents - combo_price_cents)


def is_combo_better_value(items_total_cents, combo_price_cents):
    return combo_price_cents < items_total_cents


def test_combo_saves_money():
    assert combo_savings(2500, 1999) == 501
    assert is_combo_better_value(2500, 1999)


def test_combo_at_par_no_savings():
    assert combo_savings(1500, 1500) == 0


def test_combo_more_expensive_does_not_negative():
    assert combo_savings(1500, 1800) == 0
    assert not is_combo_better_value(1500, 1800)
