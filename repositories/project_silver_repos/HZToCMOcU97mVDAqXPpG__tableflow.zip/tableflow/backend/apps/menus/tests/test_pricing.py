import pytest

from apps.menus.pricing import (
    LineItemSpec,
    apply_tax_cents,
    discounted_total_cents,
    line_item_total_cents,
)


def test_line_item_base_only():
    assert line_item_total_cents(LineItemSpec(base_price_cents=1000, quantity=1)) == 1000


def test_line_item_variant_and_modifiers_compose():
    spec = LineItemSpec(base_price_cents=1000, variant_delta_cents=200, modifier_options=(50, 75), quantity=2)
    assert line_item_total_cents(spec) == (1000 + 200 + 50 + 75) * 2


def test_line_item_floors_at_zero_when_modifiers_negative():
    spec = LineItemSpec(base_price_cents=500, variant_delta_cents=-200, modifier_options=(-1000,), quantity=3)
    assert line_item_total_cents(spec) == 0


def test_line_item_rejects_zero_quantity():
    with pytest.raises(ValueError):
        line_item_total_cents(LineItemSpec(base_price_cents=100, quantity=0))


def test_discount_percent_then_fixed():
    # $100 item, 10% off = $90, then $5 off = $85
    assert discounted_total_cents(10000, percent_off=10, fixed_off_cents=500) == 8500


def test_discount_floors_at_zero():
    assert discounted_total_cents(500, percent_off=0, fixed_off_cents=10000) == 0


def test_apply_tax_rounds_correctly():
    assert apply_tax_cents(10000, tax_rate=0.0825) == 825


def test_apply_tax_rejects_out_of_range():
    with pytest.raises(ValueError):
        apply_tax_cents(100, tax_rate=2)
