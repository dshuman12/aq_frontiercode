"""Menu, MenuCategory, MenuItem, MenuItemVariant, MenuItemPhoto."""
from __future__ import annotations

import uuid

from django.db import models


class Menu(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(db_index=True)
    name = models.CharField(max_length=120)
    slug = models.SlugField(max_length=120)
    is_default = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    starts_at = models.TimeField(null=True, blank=True)
    ends_at = models.TimeField(null=True, blank=True)
    weekdays = models.JSONField(default=list)  # e.g. [0,1,2,3,4]
    branches = models.ManyToManyField("branches.Branch", blank=True, related_name="menus")
    description = models.CharField(max_length=200, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "menus"
        unique_together = ("restaurant_id", "slug")

    def __str__(self) -> str:
        return self.name


class MenuCategory(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    menu = models.ForeignKey(Menu, on_delete=models.CASCADE, related_name="categories")
    name = models.CharField(max_length=120)
    sort_order = models.PositiveIntegerField(default=0)
    is_active = models.BooleanField(default=True)
    description = models.CharField(max_length=200, blank=True)

    class Meta:
        db_table = "menu_category"
        ordering = ["sort_order", "name"]


class MenuItem(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(db_index=True)
    category = models.ForeignKey(MenuCategory, on_delete=models.PROTECT, related_name="items")
    name = models.CharField(max_length=160)
    short_name = models.CharField(max_length=60, blank=True)
    description = models.TextField(blank=True)
    base_price_cents = models.PositiveIntegerField(default=0)
    cost_cents = models.PositiveIntegerField(default=0)
    sku = models.CharField(max_length=40, blank=True)
    is_available = models.BooleanField(default=True)
    is_archived = models.BooleanField(default=False)
    prep_time_minutes = models.PositiveIntegerField(default=0)
    calories = models.PositiveIntegerField(null=True, blank=True)
    spicy_level = models.PositiveSmallIntegerField(default=0)  # 0..5
    allergens = models.JSONField(default=list)  # ["gluten","dairy",...]
    dietary_tags = models.JSONField(default=list)  # ["vegan","keto",...]
    sort_order = models.PositiveIntegerField(default=0)
    kitchen_station = models.ForeignKey("kitchen.KitchenStation", on_delete=models.SET_NULL, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "menu_item"
        ordering = ["sort_order", "name"]
        indexes = [models.Index(fields=["restaurant_id", "is_available"])]

    def __str__(self) -> str:
        return self.name


class MenuItemPhoto(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    item = models.ForeignKey(MenuItem, on_delete=models.CASCADE, related_name="photos")
    file = models.ForeignKey("files.FileAsset", on_delete=models.CASCADE)
    is_primary = models.BooleanField(default=False)
    sort_order = models.PositiveIntegerField(default=0)
    alt_text = models.CharField(max_length=160, blank=True)

    class Meta:
        db_table = "menu_item_photo"
        ordering = ["-is_primary", "sort_order"]


class MenuItemVariant(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    item = models.ForeignKey(MenuItem, on_delete=models.CASCADE, related_name="variants")
    name = models.CharField(max_length=80)  # e.g. "Small", "Medium", "Large"
    sku = models.CharField(max_length=40, blank=True)
    price_delta_cents = models.IntegerField(default=0)  # added to base price
    is_default = models.BooleanField(default=False)
    sort_order = models.PositiveIntegerField(default=0)

    class Meta:
        db_table = "menu_item_variant"
        ordering = ["sort_order"]
