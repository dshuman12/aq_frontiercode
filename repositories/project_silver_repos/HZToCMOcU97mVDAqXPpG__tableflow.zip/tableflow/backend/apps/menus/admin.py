from django.contrib import admin

from .models import Menu, MenuCategory, MenuItem, MenuItemPhoto, MenuItemVariant


class CategoryInline(admin.TabularInline):
    model = MenuCategory
    extra = 1


@admin.register(Menu)
class MenuAdmin(admin.ModelAdmin):
    list_display = ("name", "slug", "is_default", "is_active")
    inlines = [CategoryInline]


@admin.register(MenuItem)
class MenuItemAdmin(admin.ModelAdmin):
    list_display = ("name", "category", "base_price_cents", "is_available", "is_archived")
    list_filter = ("is_available", "is_archived", "category")
    search_fields = ("name", "sku")


admin.site.register([MenuItemPhoto, MenuItemVariant, MenuCategory])
