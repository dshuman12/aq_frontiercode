"""Menu lifecycle signals — slug auto-generation."""
from __future__ import annotations

from django.db.models.signals import pre_save
from django.dispatch import receiver
from django.utils.text import slugify

from .models import Menu


@receiver(pre_save, sender=Menu)
def ensure_menu_slug(sender, instance: Menu, **kwargs):
    if instance.slug:
        return
    base = slugify(instance.name) or "menu"
    slug = base
    n = 1
    while Menu.objects.filter(restaurant_id=instance.restaurant_id, slug=slug).exclude(pk=instance.pk).exists():
        n += 1
        slug = f"{base}-{n}"
    instance.slug = slug
