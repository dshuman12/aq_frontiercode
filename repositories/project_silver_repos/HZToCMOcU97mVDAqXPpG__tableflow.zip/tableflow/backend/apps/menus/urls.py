from django.urls import path

from . import views

urlpatterns = [
    path("", views.MenuList.as_view()),
    path("<uuid:pk>", views.MenuDetail.as_view()),
    path("categories", views.CategoryList.as_view()),
    path("categories/<uuid:pk>", views.CategoryDetail.as_view()),
    path("items", views.ItemList.as_view()),
    path("items/<uuid:pk>", views.ItemDetail.as_view()),
    path("variants", views.VariantList.as_view()),
    path("variants/<uuid:pk>", views.VariantDetail.as_view()),
    path("photos", views.PhotoList.as_view()),
]
