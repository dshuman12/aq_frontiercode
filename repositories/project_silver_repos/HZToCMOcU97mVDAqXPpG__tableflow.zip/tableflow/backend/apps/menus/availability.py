"""Decide whether a menu is currently available based on schedule + day."""
from __future__ import annotations

from datetime import datetime, time


def menu_is_available(
    *,
    starts_at: time | None,
    ends_at: time | None,
    weekdays: list[int],
    now: datetime,
) -> bool:
    if weekdays and now.weekday() not in weekdays:
        return False
    if starts_at is None and ends_at is None:
        return True
    cur = now.time()
    if starts_at and ends_at:
        if starts_at <= ends_at:
            return starts_at <= cur <= ends_at
        # overnight (e.g. 22:00 -> 02:00)
        return cur >= starts_at or cur <= ends_at
    if starts_at and not ends_at:
        return cur >= starts_at
    if ends_at and not starts_at:
        return cur <= ends_at
    return True


def item_is_orderable(*, item_available: bool, menu_available: bool, sold_out: bool = False) -> bool:
    return item_available and menu_available and not sold_out
