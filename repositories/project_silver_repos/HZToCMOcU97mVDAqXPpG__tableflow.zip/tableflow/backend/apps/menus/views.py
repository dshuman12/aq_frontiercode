from django.utils.text import slugify
from rest_framework import generics

from apps.accounts.permissions import perm

from .models import Menu, MenuCategory, MenuItem, MenuItemPhoto, MenuItemVariant
from .serializers import (
    MenuCategorySerializer,
    MenuItemPhotoSerializer,
    MenuItemSerializer,
    MenuItemVariantSerializer,
    MenuSerializer,
)


class MenuList(generics.ListCreateAPIView):
    serializer_class = MenuSerializer
    permission_classes = [perm("menu:read")]
    filterset_fields = ["is_active", "is_default"]

    def get_queryset(self):  # type: ignore[override]
        return Menu.objects.filter(restaurant_id=self.request.restaurant_id).prefetch_related(
            "categories__items__variants"
        )

    def perform_create(self, serializer):  # type: ignore[override]
        name = serializer.validated_data["name"]
        slug = slugify(name) or "menu"
        n = 1
        while Menu.objects.filter(restaurant_id=self.request.restaurant_id, slug=slug).exists():
            n += 1
            slug = f"{slugify(name)}-{n}"
        serializer.save(restaurant_id=self.request.restaurant_id, slug=slug)


class MenuDetail(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = MenuSerializer
    permission_classes = [perm("menu:read")]

    def get_queryset(self):  # type: ignore[override]
        return Menu.objects.filter(restaurant_id=self.request.restaurant_id)


class CategoryList(generics.ListCreateAPIView):
    serializer_class = MenuCategorySerializer
    permission_classes = [perm("menu:read")]
    filterset_fields = ["menu", "is_active"]

    def get_queryset(self):  # type: ignore[override]
        return MenuCategory.objects.filter(menu__restaurant_id=self.request.restaurant_id)


class CategoryDetail(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = MenuCategorySerializer
    permission_classes = [perm("menu:update")]

    def get_queryset(self):  # type: ignore[override]
        return MenuCategory.objects.filter(menu__restaurant_id=self.request.restaurant_id)


class ItemList(generics.ListCreateAPIView):
    serializer_class = MenuItemSerializer
    permission_classes = [perm("menu:read")]
    filterset_fields = ["category", "is_available", "is_archived"]
    search_fields = ["name", "short_name", "description", "sku"]

    def get_queryset(self):  # type: ignore[override]
        return (
            MenuItem.objects.filter(restaurant_id=self.request.restaurant_id)
            .select_related("category", "kitchen_station")
            .prefetch_related("variants", "photos")
        )

    def perform_create(self, serializer):  # type: ignore[override]
        serializer.save(restaurant_id=self.request.restaurant_id)


class ItemDetail(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = MenuItemSerializer
    permission_classes = [perm("menu:read")]

    def get_queryset(self):  # type: ignore[override]
        return MenuItem.objects.filter(restaurant_id=self.request.restaurant_id)


class VariantList(generics.ListCreateAPIView):
    serializer_class = MenuItemVariantSerializer
    permission_classes = [perm("menu:update")]
    filterset_fields = ["item"]

    def get_queryset(self):  # type: ignore[override]
        return MenuItemVariant.objects.filter(item__restaurant_id=self.request.restaurant_id)


class VariantDetail(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = MenuItemVariantSerializer
    permission_classes = [perm("menu:update")]

    def get_queryset(self):  # type: ignore[override]
        return MenuItemVariant.objects.filter(item__restaurant_id=self.request.restaurant_id)


class PhotoList(generics.ListCreateAPIView):
    serializer_class = MenuItemPhotoSerializer
    permission_classes = [perm("menu:update")]
    filterset_fields = ["item"]

    def get_queryset(self):  # type: ignore[override]
        return MenuItemPhoto.objects.filter(item__restaurant_id=self.request.restaurant_id)
