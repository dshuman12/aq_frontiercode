"""Pure pricing math for menu items + variants + modifiers."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class LineItemSpec:
    base_price_cents: int
    variant_delta_cents: int = 0
    modifier_options: tuple[int, ...] = ()  # tuple of price_delta_cents
    quantity: int = 1


def line_item_total_cents(spec: LineItemSpec) -> int:
    if spec.quantity <= 0:
        raise ValueError("quantity must be positive")
    unit = spec.base_price_cents + spec.variant_delta_cents + sum(spec.modifier_options)
    return max(0, unit) * spec.quantity


def discounted_total_cents(subtotal_cents: int, *, percent_off: float = 0, fixed_off_cents: int = 0) -> int:
    if percent_off < 0 or percent_off > 100:
        raise ValueError("percent_off must be 0..100")
    after_pct = subtotal_cents - int(round(subtotal_cents * percent_off / 100))
    after_fixed = after_pct - fixed_off_cents
    return max(0, after_fixed)


def apply_tax_cents(amount_cents: int, *, tax_rate: float) -> int:
    if tax_rate < 0 or tax_rate > 1:
        raise ValueError("tax_rate must be 0..1 (decimal)")
    return int(round(amount_cents * tax_rate))
