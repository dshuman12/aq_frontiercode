"""Restaurant + onboarding settings."""
from __future__ import annotations

import uuid

from django.conf import settings
from django.db import models


class Restaurant(models.Model):
    PLAN_CHOICES = [
        ("starter", "Starter"),
        ("growth", "Growth"),
        ("pro", "Pro"),
    ]
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=120)
    slug = models.SlugField(unique=True)
    plan = models.CharField(max_length=20, choices=PLAN_CHOICES, default="starter")
    cuisine = models.CharField(max_length=80, blank=True)
    timezone = models.CharField(max_length=64, default="America/Chicago")
    currency = models.CharField(max_length=8, default="USD")

    phone = models.CharField(max_length=32, blank=True)
    address = models.TextField(blank=True)
    website = models.URLField(blank=True)
    logo_url = models.URLField(blank=True)
    brand_color = models.CharField(max_length=16, blank=True)

    # Order / payment policy
    accepts_dine_in = models.BooleanField(default=True)
    accepts_takeout = models.BooleanField(default=True)
    accepts_delivery = models.BooleanField(default=False)
    accepts_reservations = models.BooleanField(default=True)
    auto_accept_online_orders = models.BooleanField(default=False)

    tax_rate = models.DecimalField(max_digits=6, decimal_places=4, default=0)
    service_charge_rate = models.DecimalField(max_digits=6, decimal_places=4, default=0)
    default_tip_options = models.JSONField(default=list)  # e.g. [10, 15, 20]

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "restaurants"

    def __str__(self) -> str:
        return self.name


class BusinessHours(models.Model):
    DAY_CHOICES = [(i, name) for i, name in enumerate(
        ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    )]
    restaurant = models.ForeignKey(Restaurant, on_delete=models.CASCADE, related_name="business_hours")
    branch = models.ForeignKey("branches.Branch", on_delete=models.CASCADE, null=True, blank=True, related_name="business_hours")
    weekday = models.IntegerField(choices=DAY_CHOICES)
    opens_at = models.TimeField()
    closes_at = models.TimeField()
    closed = models.BooleanField(default=False)

    class Meta:
        db_table = "restaurant_business_hours"
        unique_together = ("restaurant", "branch", "weekday")
        ordering = ["weekday"]


class Holiday(models.Model):
    restaurant = models.ForeignKey(Restaurant, on_delete=models.CASCADE, related_name="holidays")
    branch = models.ForeignKey("branches.Branch", on_delete=models.CASCADE, null=True, blank=True, related_name="holidays")
    date = models.DateField()
    closed = models.BooleanField(default=True)
    opens_at = models.TimeField(null=True, blank=True)
    closes_at = models.TimeField(null=True, blank=True)
    note = models.CharField(max_length=120, blank=True)

    class Meta:
        db_table = "restaurant_holiday"
        unique_together = ("restaurant", "branch", "date")


class RestaurantMember(models.Model):
    """Join row between a User and a Restaurant — also stores role + branch scope."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant = models.ForeignKey(Restaurant, on_delete=models.CASCADE, related_name="members")
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="memberships")
    role = models.ForeignKey("roles.Role", on_delete=models.PROTECT, related_name="members")
    branches = models.ManyToManyField("branches.Branch", blank=True, related_name="members")
    is_owner = models.BooleanField(default=False)
    invited_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="+")
    joined_at = models.DateTimeField(auto_now_add=True)
    archived_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "restaurant_member"
        unique_together = ("restaurant", "user")
        indexes = [models.Index(fields=["restaurant", "archived_at"])]


class Invitation(models.Model):
    STATUS_CHOICES = [
        ("pending", "Pending"),
        ("accepted", "Accepted"),
        ("revoked", "Revoked"),
        ("expired", "Expired"),
    ]
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant = models.ForeignKey(Restaurant, on_delete=models.CASCADE, related_name="invitations")
    email = models.EmailField()
    role = models.ForeignKey("roles.Role", on_delete=models.PROTECT)
    token_hash = models.CharField(max_length=128, db_index=True)
    invited_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name="+")
    expires_at = models.DateTimeField()
    status = models.CharField(max_length=16, choices=STATUS_CHOICES, default="pending")
    accepted_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "restaurant_invitation"
        unique_together = ("restaurant", "email")
