from datetime import timedelta

from django.utils import timezone as djtz
from rest_framework import generics, status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.accounts.hashing import hash_token
from apps.accounts.permissions import perm

from . import services
from .models import BusinessHours, Holiday, Invitation, Restaurant
from .serializers import (
    BusinessHoursSerializer,
    CreateInvitationSerializer,
    CreateRestaurantSerializer,
    HolidaySerializer,
    InvitationSerializer,
    RestaurantSerializer,
)


class RestaurantsView(APIView):
    """List my restaurants and create a new one."""

    permission_classes = [IsAuthenticated]

    def get(self, request):
        memberships = request.user.memberships.select_related("restaurant", "role").filter(archived_at__isnull=True)
        return Response([
            {
                "membership_id": str(m.id),
                "restaurant": RestaurantSerializer(m.restaurant).data,
                "role": m.role.slug,
                "is_owner": m.is_owner,
            }
            for m in memberships
        ])

    def post(self, request):
        serializer = CreateRestaurantSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        r = services.create_restaurant(
            owner=request.user,
            name=serializer.validated_data["name"],
            cuisine=serializer.validated_data.get("cuisine") or "",
            timezone_=serializer.validated_data.get("timezone") or "America/Chicago",
        )
        return Response(RestaurantSerializer(r).data, status=status.HTTP_201_CREATED)


class CurrentRestaurantView(APIView):
    permission_classes = [perm("restaurant:read")]

    def get(self, request):
        r = Restaurant.objects.get(pk=request.restaurant_id)
        return Response(RestaurantSerializer(r).data)

    def patch(self, request):
        r = Restaurant.objects.get(pk=request.restaurant_id)
        serializer = RestaurantSerializer(r, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)


class BusinessHoursList(generics.ListCreateAPIView):
    serializer_class = BusinessHoursSerializer
    permission_classes = [perm("restaurant:read")]

    def get_queryset(self):  # type: ignore[override]
        return BusinessHours.objects.filter(restaurant_id=self.request.restaurant_id)

    def perform_create(self, serializer):  # type: ignore[override]
        serializer.save(restaurant_id=self.request.restaurant_id)


class BusinessHoursDetail(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = BusinessHoursSerializer
    permission_classes = [perm("restaurant:update")]

    def get_queryset(self):  # type: ignore[override]
        return BusinessHours.objects.filter(restaurant_id=self.request.restaurant_id)


class HolidayList(generics.ListCreateAPIView):
    serializer_class = HolidaySerializer
    permission_classes = [perm("restaurant:read")]

    def get_queryset(self):  # type: ignore[override]
        return Holiday.objects.filter(restaurant_id=self.request.restaurant_id)

    def perform_create(self, serializer):  # type: ignore[override]
        serializer.save(restaurant_id=self.request.restaurant_id)


class InvitationList(generics.ListCreateAPIView):
    permission_classes = [perm("members:invite")]

    def get_queryset(self):  # type: ignore[override]
        return Invitation.objects.filter(restaurant_id=self.request.restaurant_id)

    def get_serializer_class(self):  # type: ignore[override]
        return CreateInvitationSerializer if self.request.method == "POST" else InvitationSerializer

    def create(self, request, *args, **kwargs):  # type: ignore[override]
        serializer = CreateInvitationSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        import secrets

        token = secrets.token_urlsafe(32)
        inv = Invitation.objects.create(
            restaurant_id=request.restaurant_id,
            email=serializer.validated_data["email"],
            role_id=serializer.validated_data["role"],
            token_hash=hash_token(token),
            invited_by=request.user,
            expires_at=djtz.now() + timedelta(days=14),
        )
        return Response(
            {**InvitationSerializer(inv).data, "token": token},
            status=status.HTTP_201_CREATED,
        )
