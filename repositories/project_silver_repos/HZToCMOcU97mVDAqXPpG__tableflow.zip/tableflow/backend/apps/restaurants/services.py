"""Restaurant onboarding."""
from __future__ import annotations

from datetime import time

from django.db import transaction
from django.utils.text import slugify

from apps.branches.models import Branch
from apps.roles.services import provision_preset_roles

from .models import BusinessHours, Restaurant, RestaurantMember


@transaction.atomic
def create_restaurant(*, owner, name: str, cuisine: str = "", timezone_: str = "America/Chicago") -> Restaurant:
    base_slug = slugify(name) or "restaurant"
    slug = base_slug
    n = 1
    while Restaurant.objects.filter(slug=slug).exists():
        n += 1
        slug = f"{base_slug}-{n}"
    r = Restaurant.objects.create(name=name, slug=slug, cuisine=cuisine, timezone=timezone_)
    roles = provision_preset_roles(r)
    owner_role = next(role for role in roles if role.slug == "owner")
    branch = Branch.objects.create(restaurant=r, name="Main", code="MAIN", timezone=timezone_)
    RestaurantMember.objects.create(restaurant=r, user=owner, role=owner_role, is_owner=True)
    member = RestaurantMember.objects.get(restaurant=r, user=owner)
    member.branches.add(branch)
    for wd in range(7):
        BusinessHours.objects.create(
            restaurant=r,
            weekday=wd,
            opens_at=time(9, 0),
            closes_at=time(22, 0),
            closed=wd == 6,  # closed Sundays by default
        )
    return r


@transaction.atomic
def update_restaurant(restaurant: Restaurant, **fields) -> Restaurant:
    for k, v in fields.items():
        setattr(restaurant, k, v)
    restaurant.save()
    return restaurant
