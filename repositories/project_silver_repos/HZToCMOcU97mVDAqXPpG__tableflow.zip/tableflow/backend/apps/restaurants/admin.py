from django.contrib import admin

from .models import BusinessHours, Holiday, Invitation, Restaurant, RestaurantMember


@admin.register(Restaurant)
class RestaurantAdmin(admin.ModelAdmin):
    list_display = ("name", "slug", "plan", "currency", "created_at")
    search_fields = ("name", "slug")
    list_filter = ("plan",)


@admin.register(RestaurantMember)
class RestaurantMemberAdmin(admin.ModelAdmin):
    list_display = ("restaurant", "user", "role", "is_owner", "joined_at")
    list_filter = ("is_owner", "role")
    search_fields = ("user__email",)


admin.site.register([BusinessHours, Holiday, Invitation])
