from django.urls import path

from . import views

urlpatterns = [
    path("", views.RestaurantsView.as_view()),
    path("current", views.CurrentRestaurantView.as_view()),
    path("business-hours", views.BusinessHoursList.as_view()),
    path("business-hours/<int:pk>", views.BusinessHoursDetail.as_view()),
    path("holidays", views.HolidayList.as_view()),
    path("invitations", views.InvitationList.as_view()),
]
