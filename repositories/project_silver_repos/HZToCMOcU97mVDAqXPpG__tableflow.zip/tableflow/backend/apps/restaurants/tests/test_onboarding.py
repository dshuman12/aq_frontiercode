import pytest

from apps.accounts.tests.factories import UserFactory
from apps.branches.models import Branch
from apps.permissions.presets import PRESETS
from apps.restaurants.models import BusinessHours, Restaurant, RestaurantMember
from apps.restaurants.services import create_restaurant
from apps.roles.models import Role


@pytest.mark.django_db
def test_create_restaurant_provisions_roles_branch_and_owner_membership():
    owner = UserFactory()
    r = create_restaurant(owner=owner, name="Tortilla Co.")
    assert isinstance(r, Restaurant)
    # all preset roles created
    role_slugs = set(Role.objects.filter(restaurant=r).values_list("slug", flat=True))
    assert role_slugs == set(PRESETS.keys())
    # main branch
    assert Branch.objects.filter(restaurant=r, name="Main").exists()
    # owner membership
    m = RestaurantMember.objects.get(restaurant=r, user=owner)
    assert m.is_owner
    assert m.role.slug == "owner"
    # business hours seeded
    assert BusinessHours.objects.filter(restaurant=r).count() == 7


@pytest.mark.django_db
def test_create_restaurant_disambiguates_slug():
    owner1 = UserFactory()
    owner2 = UserFactory()
    a = create_restaurant(owner=owner1, name="The Spot")
    b = create_restaurant(owner=owner2, name="The Spot")
    assert a.slug != b.slug
