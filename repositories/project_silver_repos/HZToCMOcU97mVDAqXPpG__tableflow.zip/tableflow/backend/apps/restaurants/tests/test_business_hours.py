import pytest

from apps.accounts.tests.factories import UserFactory
from apps.restaurants.models import BusinessHours
from apps.restaurants.services import create_restaurant


@pytest.mark.django_db
def test_seven_business_hours_rows_per_restaurant():
    owner = UserFactory()
    r = create_restaurant(owner=owner, name="Hours Test")
    rows = BusinessHours.objects.filter(restaurant=r)
    assert rows.count() == 7
    assert sorted(rows.values_list("weekday", flat=True)) == [0, 1, 2, 3, 4, 5, 6]


@pytest.mark.django_db
def test_default_sunday_is_closed():
    owner = UserFactory()
    r = create_restaurant(owner=owner, name="Closed Sundays")
    sun = BusinessHours.objects.get(restaurant=r, weekday=6)
    assert sun.closed is True
