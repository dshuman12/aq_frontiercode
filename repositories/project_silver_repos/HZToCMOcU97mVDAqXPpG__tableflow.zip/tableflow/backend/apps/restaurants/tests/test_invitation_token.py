from datetime import timedelta

import pytest
from django.utils import timezone

from apps.accounts.hashing import hash_token
from apps.accounts.tests.factories import UserFactory
from apps.restaurants.models import Invitation, RestaurantMember
from apps.restaurants.services import create_restaurant


@pytest.mark.django_db
def test_invitation_token_is_hashed():
    owner = UserFactory()
    r = create_restaurant(owner=owner, name="Inv Test")
    role = RestaurantMember.objects.get(restaurant=r, user=owner).role
    inv = Invitation.objects.create(
        restaurant=r, email="x@y.test", role=role,
        token_hash=hash_token("plaintext"), invited_by=owner,
        expires_at=timezone.now() + timedelta(days=7),
    )
    assert inv.token_hash != "plaintext"
    assert hash_token("plaintext") == inv.token_hash


@pytest.mark.django_db
def test_invitation_unique_per_email_per_restaurant():
    owner = UserFactory()
    r = create_restaurant(owner=owner, name="Dup Test")
    role = RestaurantMember.objects.get(restaurant=r, user=owner).role
    Invitation.objects.create(
        restaurant=r, email="z@y.test", role=role,
        token_hash="h", invited_by=owner,
        expires_at=timezone.now() + timedelta(days=7),
    )
    from django.db import IntegrityError
    with pytest.raises(IntegrityError):
        Invitation.objects.create(
            restaurant=r, email="z@y.test", role=role,
            token_hash="h2", invited_by=owner,
            expires_at=timezone.now() + timedelta(days=7),
        )
