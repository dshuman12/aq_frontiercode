from rest_framework import serializers

from .models import BusinessHours, Holiday, Invitation, Restaurant


class RestaurantSerializer(serializers.ModelSerializer):
    class Meta:
        model = Restaurant
        fields = "__all__"
        read_only_fields = ["id", "slug", "created_at", "updated_at"]


class CreateRestaurantSerializer(serializers.Serializer):
    name = serializers.CharField(max_length=120)
    cuisine = serializers.CharField(max_length=80, required=False, allow_blank=True)
    timezone = serializers.CharField(max_length=64, required=False, allow_blank=True)


class BusinessHoursSerializer(serializers.ModelSerializer):
    class Meta:
        model = BusinessHours
        fields = "__all__"


class HolidaySerializer(serializers.ModelSerializer):
    class Meta:
        model = Holiday
        fields = "__all__"


class InvitationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Invitation
        fields = ["id", "email", "role", "status", "expires_at", "created_at", "accepted_at"]
        read_only_fields = ["id", "status", "created_at", "accepted_at"]


class CreateInvitationSerializer(serializers.Serializer):
    email = serializers.EmailField()
    role = serializers.UUIDField()
