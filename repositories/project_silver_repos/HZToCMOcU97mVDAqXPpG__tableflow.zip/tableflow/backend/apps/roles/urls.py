from django.urls import path

from . import views

urlpatterns = [
    path("", views.RoleList.as_view()),
    path("catalog", views.CatalogView.as_view()),
    path("<uuid:pk>", views.RoleDetail.as_view()),
]
