"""Role — bundle of permission strings assigned to RestaurantMember rows."""
from __future__ import annotations

import uuid

from django.db import models


class Role(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant = models.ForeignKey("restaurants.Restaurant", on_delete=models.CASCADE, related_name="roles")
    name = models.CharField(max_length=80)
    slug = models.SlugField(max_length=80)
    permissions = models.JSONField(default=list)
    is_preset = models.BooleanField(default=False)
    description = models.CharField(max_length=200, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "roles"
        unique_together = ("restaurant", "slug")
        ordering = ["name"]

    def __str__(self) -> str:
        return f"{self.name} ({self.restaurant_id})"

    @property
    def is_owner_role(self) -> bool:
        return self.slug == "owner" or "*" in (self.permissions or [])
