"""Provision preset roles for a freshly created restaurant."""
from __future__ import annotations

from django.db import transaction

from apps.permissions.presets import PRESETS

from .models import Role


@transaction.atomic
def provision_preset_roles(restaurant) -> list[Role]:
    out = []
    for slug, perms in PRESETS.items():
        role, _ = Role.objects.update_or_create(
            restaurant=restaurant,
            slug=slug,
            defaults={
                "name": slug.replace("_", " ").title(),
                "permissions": perms,
                "is_preset": True,
            },
        )
        out.append(role)
    return out
