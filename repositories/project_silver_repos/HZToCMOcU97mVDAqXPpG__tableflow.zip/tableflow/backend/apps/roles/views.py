from rest_framework import generics
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.accounts.permissions import perm
from apps.permissions.catalog import CATALOG

from .models import Role
from .serializers import RoleSerializer


class RoleList(generics.ListCreateAPIView):
    serializer_class = RoleSerializer
    permission_classes = [perm("roles:read")]

    def get_queryset(self):  # type: ignore[override]
        return Role.objects.filter(restaurant_id=self.request.restaurant_id)

    def perform_create(self, serializer):  # type: ignore[override]
        serializer.save(restaurant_id=self.request.restaurant_id, is_preset=False)


class RoleDetail(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = RoleSerializer
    permission_classes = [perm("roles:read")]

    def get_queryset(self):  # type: ignore[override]
        return Role.objects.filter(restaurant_id=self.request.restaurant_id)


class CatalogView(APIView):
    permission_classes = [perm("roles:read")]

    def get(self, request):
        return Response({"permissions": CATALOG})
