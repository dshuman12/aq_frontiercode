from rest_framework import serializers

from apps.permissions.catalog import is_known

from .models import Role


class RoleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Role
        fields = ["id", "name", "slug", "permissions", "is_preset", "description", "created_at"]
        read_only_fields = ["id", "is_preset", "created_at"]

    def validate_permissions(self, value):
        for p in value:
            if p == "*":
                continue
            if not is_known(p):
                raise serializers.ValidationError(f"unknown-permission:{p}")
        return value
