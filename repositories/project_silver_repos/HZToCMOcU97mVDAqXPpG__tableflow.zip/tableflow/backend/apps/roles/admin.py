from django.contrib import admin

from .models import Role


@admin.register(Role)
class RoleAdmin(admin.ModelAdmin):
    list_display = ("name", "slug", "is_preset", "permission_count")
    list_filter = ("is_preset",)
    search_fields = ("name", "slug")

    @admin.display(description="permissions")
    def permission_count(self, obj):
        return len(obj.permissions or [])
