"""Sketch test that the fan-out groups order items by their menu_item.kitchen_station."""
from collections import defaultdict


def test_grouping_by_station_groups_correctly():
    items = [
        {"id": "a", "station": "grill"},
        {"id": "b", "station": "grill"},
        {"id": "c", "station": "fryer"},
        {"id": "d", "station": None},
    ]
    grouped: dict = defaultdict(list)
    for it in items:
        grouped[it["station"]].append(it["id"])
    assert sorted(grouped["grill"]) == ["a", "b"]
    assert grouped["fryer"] == ["c"]
    assert grouped[None] == ["d"]
