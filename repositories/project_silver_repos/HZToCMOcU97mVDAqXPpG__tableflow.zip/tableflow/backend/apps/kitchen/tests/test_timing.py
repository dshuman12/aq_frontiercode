from datetime import datetime, timedelta

from apps.kitchen.timing import elapsed_minutes, expected_minutes_for_items, is_delayed


def test_elapsed_minutes_handles_none():
    assert elapsed_minutes(None, now=datetime(2024, 1, 1, 12, 0)) == 0


def test_elapsed_minutes_basic():
    started = datetime(2024, 1, 1, 12, 0)
    assert elapsed_minutes(started, now=datetime(2024, 1, 1, 12, 12)) == 12


def test_is_delayed_only_when_in_progress():
    started = datetime(2024, 1, 1, 12, 0)
    now = datetime(2024, 1, 1, 12, 25)
    assert is_delayed(ticket_status="in_progress", started_at=started, expected_minutes=10, now=now)
    assert not is_delayed(ticket_status="ready", started_at=started, expected_minutes=10, now=now)
    assert not is_delayed(ticket_status="in_progress", started_at=None, expected_minutes=10, now=now)


def test_is_delayed_within_slack_returns_false():
    started = datetime(2024, 1, 1, 12, 0)
    now = datetime(2024, 1, 1, 12, 12)
    assert not is_delayed(ticket_status="in_progress", started_at=started, expected_minutes=10, now=now, slack=5)


def test_expected_minutes_uses_longest_line():
    items = [{"prep_time_minutes": 5, "quantity": 1}, {"prep_time_minutes": 12, "quantity": 1}]
    assert expected_minutes_for_items(items) == 12
    assert expected_minutes_for_items([]) == 0
