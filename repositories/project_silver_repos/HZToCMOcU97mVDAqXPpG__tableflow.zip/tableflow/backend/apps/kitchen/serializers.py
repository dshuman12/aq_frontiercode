from rest_framework import serializers

from .models import KitchenStation, KitchenTicket, KitchenTicketItem


class KitchenStationSerializer(serializers.ModelSerializer):
    class Meta:
        model = KitchenStation
        fields = "__all__"
        read_only_fields = ["id", "restaurant_id"]


class KitchenTicketItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = KitchenTicketItem
        fields = "__all__"


class KitchenTicketSerializer(serializers.ModelSerializer):
    items = KitchenTicketItemSerializer(many=True, read_only=True)
    order_number = serializers.CharField(source="order.number", read_only=True)
    table_number = serializers.CharField(source="order.table.number", read_only=True, default=None)

    class Meta:
        model = KitchenTicket
        fields = "__all__"
        read_only_fields = ["id", "restaurant_id", "created_at", "started_at", "ready_at", "served_at"]
