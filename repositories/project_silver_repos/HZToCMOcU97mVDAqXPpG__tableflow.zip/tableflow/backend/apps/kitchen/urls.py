from django.urls import path

from . import views

urlpatterns = [
    path("stations", views.StationList.as_view()),
    path("stations/<uuid:pk>", views.StationDetail.as_view()),
    path("tickets", views.TicketList.as_view()),
    path("tickets/<uuid:pk>/transition", views.TransitionTicketView.as_view()),
    path("tickets/<uuid:pk>/items/<uuid:item_id>/done", views.TicketItemDoneView.as_view()),
]
