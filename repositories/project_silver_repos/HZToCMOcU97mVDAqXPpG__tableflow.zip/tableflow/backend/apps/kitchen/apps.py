from django.apps import AppConfig


class KitchenConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.kitchen"

    def ready(self) -> None:
        from . import signals  # noqa: F401
