from django.contrib import admin

from .models import KitchenStation, KitchenTicket, KitchenTicketItem


@admin.register(KitchenTicket)
class KitchenTicketAdmin(admin.ModelAdmin):
    list_display = ("order", "station", "status", "started_at", "ready_at")
    list_filter = ("status", "station")
    readonly_fields = ("started_at", "ready_at", "served_at", "created_at")


admin.site.register([KitchenStation, KitchenTicketItem])
