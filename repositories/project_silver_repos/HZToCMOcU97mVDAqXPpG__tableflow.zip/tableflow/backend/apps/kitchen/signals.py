"""Push kitchen ticket events to the websocket group."""
from __future__ import annotations

from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer
from django.db.models.signals import post_save
from django.dispatch import receiver

from apps.branches.models import Branch

from .models import KitchenTicket


@receiver(post_save, sender=KitchenTicket)
def broadcast_ticket(sender, instance: KitchenTicket, created: bool, **kwargs):
    layer = get_channel_layer()
    if layer is None:
        return
    branch_id = instance.station.branch_id
    payload = {
        "kind": "created" if created else "updated",
        "ticket_id": str(instance.id),
        "order_id": str(instance.order_id),
        "station_id": str(instance.station_id),
        "status": instance.status,
    }
    async_to_sync(layer.group_send)(f"kitchen.{branch_id}", {"type": "kitchen.event", "payload": payload})
