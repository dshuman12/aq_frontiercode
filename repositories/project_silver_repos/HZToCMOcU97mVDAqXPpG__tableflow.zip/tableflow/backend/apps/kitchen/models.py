"""KitchenStation, KitchenTicket, KitchenTicketItem."""
from __future__ import annotations

import uuid

from django.conf import settings
from django.db import models


class KitchenStation(models.Model):
    KIND_CHOICES = [
        ("grill", "Grill"),
        ("fryer", "Fryer"),
        ("pizza", "Pizza"),
        ("salad", "Salad"),
        ("dessert", "Dessert"),
        ("drinks", "Drinks"),
        ("bar", "Bar"),
        ("packaging", "Packaging"),
        ("other", "Other"),
    ]
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(db_index=True)
    branch = models.ForeignKey("branches.Branch", on_delete=models.CASCADE, related_name="kitchen_stations")
    name = models.CharField(max_length=80)
    kind = models.CharField(max_length=10, choices=KIND_CHOICES, default="other")
    sort_order = models.PositiveIntegerField(default=0)
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = "kitchen_station"
        unique_together = ("restaurant_id", "branch", "name")
        ordering = ["sort_order"]


class KitchenTicket(models.Model):
    STATUS_CHOICES = [
        ("queued", "Queued"),
        ("in_progress", "In progress"),
        ("ready", "Ready"),
        ("served", "Served"),
        ("cancelled", "Cancelled"),
    ]
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(db_index=True)
    order = models.ForeignKey("orders.Order", on_delete=models.CASCADE, related_name="kitchen_tickets")
    station = models.ForeignKey(KitchenStation, on_delete=models.CASCADE, related_name="tickets")
    status = models.CharField(max_length=12, choices=STATUS_CHOICES, default="queued", db_index=True)
    priority = models.PositiveSmallIntegerField(default=0)  # 0=normal, 1=rush
    notes = models.CharField(max_length=300, blank=True)
    started_at = models.DateTimeField(null=True, blank=True)
    ready_at = models.DateTimeField(null=True, blank=True)
    served_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "kitchen_ticket"
        indexes = [
            models.Index(fields=["restaurant_id", "station", "status", "created_at"]),
        ]


class KitchenTicketItem(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    ticket = models.ForeignKey(KitchenTicket, on_delete=models.CASCADE, related_name="items")
    order_item = models.ForeignKey("orders.OrderItem", on_delete=models.CASCADE, related_name="kitchen_lines")
    quantity = models.PositiveSmallIntegerField(default=1)
    note = models.CharField(max_length=300, blank=True)
    is_done = models.BooleanField(default=False)
    done_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL)
    done_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "kitchen_ticket_item"
