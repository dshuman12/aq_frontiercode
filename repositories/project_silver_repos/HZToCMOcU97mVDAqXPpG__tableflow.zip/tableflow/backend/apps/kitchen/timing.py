"""Kitchen ticket timing — prep time + delayed flag."""
from __future__ import annotations

from datetime import datetime, timedelta


def elapsed_minutes(started_at: datetime | None, *, now: datetime) -> int:
    if not started_at:
        return 0
    return max(0, int((now - started_at).total_seconds() // 60))


def is_delayed(*, ticket_status: str, started_at: datetime | None, expected_minutes: int, now: datetime, slack: int = 5) -> bool:
    if ticket_status not in ("queued", "in_progress"):
        return False
    if not started_at:
        return False
    return elapsed_minutes(started_at, now=now) > expected_minutes + slack


def expected_minutes_for_items(items: list[dict]) -> int:
    """Items: list of {prep_time_minutes, quantity}. Use the longest single line."""
    if not items:
        return 0
    return max(int(it.get("prep_time_minutes", 0)) for it in items)
