from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.accounts.permissions import perm

from . import services
from .models import KitchenStation, KitchenTicket, KitchenTicketItem
from .serializers import (
    KitchenStationSerializer,
    KitchenTicketItemSerializer,
    KitchenTicketSerializer,
)


class StationList(generics.ListCreateAPIView):
    serializer_class = KitchenStationSerializer
    permission_classes = [perm("kitchen:read")]
    filterset_fields = ["branch", "is_active"]

    def get_queryset(self):  # type: ignore[override]
        return KitchenStation.objects.filter(restaurant_id=self.request.restaurant_id)

    def perform_create(self, serializer):  # type: ignore[override]
        serializer.save(restaurant_id=self.request.restaurant_id)


class StationDetail(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = KitchenStationSerializer
    permission_classes = [perm("kitchen:read")]

    def get_queryset(self):  # type: ignore[override]
        return KitchenStation.objects.filter(restaurant_id=self.request.restaurant_id)


class TicketList(generics.ListAPIView):
    serializer_class = KitchenTicketSerializer
    permission_classes = [perm("kitchen:read")]
    filterset_fields = ["station", "status"]
    ordering = ["created_at"]

    def get_queryset(self):  # type: ignore[override]
        qs = KitchenTicket.objects.filter(restaurant_id=self.request.restaurant_id).select_related("order").prefetch_related("items")
        active = self.request.query_params.get("active")
        if active in ("1", "true"):
            qs = qs.filter(status__in=["queued", "in_progress"])
        return qs


class TransitionTicketView(APIView):
    permission_classes = [perm("kitchen:transition")]

    def post(self, request, pk):
        ticket = KitchenTicket.objects.get(pk=pk, restaurant_id=request.restaurant_id)
        services.transition_ticket(ticket, to_status=request.data.get("to_status"), by=request.user)
        return Response(KitchenTicketSerializer(ticket).data)


class TicketItemDoneView(APIView):
    permission_classes = [perm("kitchen:transition")]

    def post(self, request, pk, item_id):
        ticket = KitchenTicket.objects.get(pk=pk, restaurant_id=request.restaurant_id)
        item = KitchenTicketItem.objects.get(pk=item_id, ticket=ticket)
        services.mark_item_done(item, by=request.user)
        return Response(KitchenTicketItemSerializer(item).data)
