"""Kitchen ticket dispatch + state."""
from __future__ import annotations

from collections import defaultdict

from django.db import transaction
from django.utils import timezone
from rest_framework.exceptions import ValidationError

from apps.orders.models import Order

from .models import KitchenStation, KitchenTicket, KitchenTicketItem


@transaction.atomic
def build_tickets_for_order(order_id: str) -> dict:
    order = Order.objects.select_related("branch").prefetch_related("items").get(pk=order_id)
    by_station: dict[str | None, list] = defaultdict(list)
    for item in order.items.filter(is_voided=False).select_related("menu_item__kitchen_station"):
        st = item.menu_item.kitchen_station_id
        by_station[st].append(item)

    fallback = (
        KitchenStation.objects.filter(restaurant_id=order.restaurant_id, branch=order.branch).first()
    )
    created = 0
    for station_id, items in by_station.items():
        st = (
            KitchenStation.objects.get(pk=station_id)
            if station_id
            else fallback
        )
        if st is None:
            continue
        ticket = KitchenTicket.objects.create(
            restaurant_id=order.restaurant_id,
            order=order,
            station=st,
            priority=0,
        )
        for item in items:
            KitchenTicketItem.objects.create(
                ticket=ticket,
                order_item=item,
                quantity=item.quantity,
                note=item.note,
            )
        created += 1
    return {"order_id": str(order.id), "tickets": created}


@transaction.atomic
def transition_ticket(ticket: KitchenTicket, *, to_status: str, by) -> KitchenTicket:
    legal = {
        "queued": ["in_progress", "cancelled"],
        "in_progress": ["ready", "cancelled"],
        "ready": ["served"],
        "served": [],
        "cancelled": [],
    }
    if to_status not in legal.get(ticket.status, []):
        raise ValidationError({"status": f"illegal:{ticket.status}->{to_status}"})
    ticket.status = to_status
    now = timezone.now()
    if to_status == "in_progress" and not ticket.started_at:
        ticket.started_at = now
    if to_status == "ready":
        ticket.ready_at = now
    if to_status == "served":
        ticket.served_at = now
    ticket.save()
    return ticket


@transaction.atomic
def mark_item_done(item: KitchenTicketItem, *, by) -> KitchenTicketItem:
    item.is_done = True
    item.done_by = by if getattr(by, "is_authenticated", False) else None
    item.done_at = timezone.now()
    item.save(update_fields=["is_done", "done_by", "done_at"])
    if not item.ticket.items.filter(is_done=False).exists() and item.ticket.status != "ready":
        transition_ticket(item.ticket, to_status="ready", by=by)
    return item
