from django.urls import path

from .consumers import KitchenStreamConsumer

websocket_urlpatterns = [
    path("ws/kitchen/<uuid:branch_id>", KitchenStreamConsumer.as_asgi()),
]
