from rest_framework import serializers

from .models import FileAsset


class SignUploadSerializer(serializers.Serializer):
    filename = serializers.CharField(max_length=255)
    content_type = serializers.CharField(max_length=120)
    kind = serializers.ChoiceField(choices=[c[0] for c in FileAsset.KIND_CHOICES], default="other")


class FileAssetSerializer(serializers.ModelSerializer):
    class Meta:
        model = FileAsset
        fields = "__all__"
        read_only_fields = ["id", "created_at", "uploaded_by", "restaurant_id"]
