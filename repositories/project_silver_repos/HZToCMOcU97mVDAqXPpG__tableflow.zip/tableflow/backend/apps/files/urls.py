from django.urls import path

from . import views

urlpatterns = [
    path("", views.FileAssetListView.as_view()),
    path("sign-upload", views.SignUploadView.as_view()),
    path("finish-upload", views.FinishUploadView.as_view()),
    path("<uuid:pk>/sign-download", views.SignDownloadView.as_view()),
]
