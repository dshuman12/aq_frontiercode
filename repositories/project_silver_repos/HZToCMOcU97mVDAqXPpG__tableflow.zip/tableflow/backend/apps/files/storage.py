"""S3-compatible storage helpers (presigned URLs)."""
from __future__ import annotations

import re
from datetime import datetime
from typing import Any

import boto3
from botocore.client import Config
from django.conf import settings


def _client():
    return boto3.client(
        "s3",
        aws_access_key_id=settings.AWS_ACCESS_KEY_ID if hasattr(settings, "AWS_ACCESS_KEY_ID") else None,
        aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY if hasattr(settings, "AWS_SECRET_ACCESS_KEY") else None,
        endpoint_url=getattr(settings, "AWS_S3_ENDPOINT_URL", None) or None,
        region_name=getattr(settings, "AWS_S3_REGION_NAME", "us-east-1"),
        config=Config(signature_version="s3v4"),
    )


_FILENAME_RE = re.compile(r"[^A-Za-z0-9._-]+")


def sanitize_filename(name: str) -> str:
    name = name.replace("..", "")
    name = name.lstrip("/")
    return _FILENAME_RE.sub("-", name).strip("-")[:120] or "file"


def build_upload_key(restaurant_id: str, filename: str, kind: str = "other") -> str:
    today = datetime.utcnow()
    return f"{restaurant_id}/{kind}/{today:%Y/%m}/{today:%d-%H%M%S}-{sanitize_filename(filename)}"


def presign_upload(*, bucket: str, key: str, content_type: str, expires: int = 600) -> dict[str, Any]:
    return _client().generate_presigned_post(
        Bucket=bucket,
        Key=key,
        Fields={"Content-Type": content_type},
        Conditions=[
            ["content-length-range", 0, 25 * 1024 * 1024],
            {"Content-Type": content_type},
        ],
        ExpiresIn=expires,
    )


def presign_download(*, bucket: str, key: str, expires: int = 600) -> str:
    return _client().generate_presigned_url(
        "get_object",
        Params={"Bucket": bucket, "Key": key},
        ExpiresIn=expires,
    )
