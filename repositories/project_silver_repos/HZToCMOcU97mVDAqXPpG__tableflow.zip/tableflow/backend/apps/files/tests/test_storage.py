from apps.files.storage import build_upload_key, sanitize_filename


def test_sanitize_strips_path_traversal():
    assert sanitize_filename("../../etc/passwd") == "etc-passwd"
    assert sanitize_filename("/abs/path/file.png").endswith("file.png")


def test_sanitize_replaces_unsafe_chars():
    assert sanitize_filename("hello world.png") == "hello-world.png"
    assert sanitize_filename("café.txt") != ""


def test_build_upload_key_prefixes_restaurant_kind_and_date():
    key = build_upload_key("rid-123", "menu-photo.png", kind="menu_item")
    assert key.startswith("rid-123/menu_item/")
    assert key.endswith("menu-photo.png")
