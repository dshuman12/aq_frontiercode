from django.contrib import admin

from .models import FileAsset


@admin.register(FileAsset)
class FileAssetAdmin(admin.ModelAdmin):
    list_display = ("kind", "key", "content_type", "size_bytes", "created_at")
    list_filter = ("kind",)
    search_fields = ("key", "checksum_sha256")
    readonly_fields = ("created_at",)
