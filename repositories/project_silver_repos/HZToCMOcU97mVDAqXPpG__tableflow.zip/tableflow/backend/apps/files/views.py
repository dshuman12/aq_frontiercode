from django.conf import settings
from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.accounts.permissions import perm

from . import storage
from .models import FileAsset
from .serializers import FileAssetSerializer, SignUploadSerializer


class SignUploadView(APIView):
    permission_classes = [perm("files:create")]

    def post(self, request):
        serializer = SignUploadSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data
        bucket = settings.AWS_STORAGE_BUCKET_NAME
        key = storage.build_upload_key(str(request.restaurant_id), data["filename"], data["kind"])
        signed = storage.presign_upload(bucket=bucket, key=key, content_type=data["content_type"])
        return Response({"bucket": bucket, "key": key, **signed})


class FinishUploadView(APIView):
    permission_classes = [perm("files:create")]

    def post(self, request):
        serializer = FileAssetSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        asset = serializer.save(restaurant_id=request.restaurant_id, uploaded_by=request.user)
        return Response(FileAssetSerializer(asset).data, status=status.HTTP_201_CREATED)


class FileAssetListView(generics.ListAPIView):
    serializer_class = FileAssetSerializer
    permission_classes = [perm("files:read")]
    filterset_fields = ["kind"]
    ordering = ["-created_at"]

    def get_queryset(self):  # type: ignore[override]
        return FileAsset.objects.filter(restaurant_id=self.request.restaurant_id)


class SignDownloadView(APIView):
    permission_classes = [perm("files:read")]

    def get(self, request, pk):
        try:
            asset = FileAsset.objects.get(pk=pk, restaurant_id=request.restaurant_id)
        except FileAsset.DoesNotExist:
            return Response({"detail": "not-found"}, status=status.HTTP_404_NOT_FOUND)
        url = storage.presign_download(bucket=asset.bucket, key=asset.key)
        return Response({"url": url, "content_type": asset.content_type})
