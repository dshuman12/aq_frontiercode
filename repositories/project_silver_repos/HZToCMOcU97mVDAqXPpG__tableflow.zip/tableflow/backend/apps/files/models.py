"""FileAsset — metadata for objects stored in the S3-compatible bucket."""
from __future__ import annotations

import uuid

from django.conf import settings
from django.db import models


class FileAsset(models.Model):
    KIND_CHOICES = [
        ("menu_item", "Menu item photo"),
        ("receipt", "Receipt PDF"),
        ("report", "Report"),
        ("supplier_invoice", "Supplier invoice"),
        ("avatar", "Avatar"),
        ("delivery_proof", "Delivery proof"),
        ("other", "Other"),
    ]
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(db_index=True)
    uploaded_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True)
    kind = models.CharField(max_length=32, choices=KIND_CHOICES, default="other")
    bucket = models.CharField(max_length=120)
    key = models.CharField(max_length=500, db_index=True)
    content_type = models.CharField(max_length=120, blank=True)
    size_bytes = models.PositiveBigIntegerField(default=0)
    checksum_sha256 = models.CharField(max_length=64, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "files_asset"
        indexes = [models.Index(fields=["restaurant_id", "kind", "created_at"])]
