"""Role presets — the named role bundles that ship out of the box."""
from __future__ import annotations

from .catalog import CATALOG

PRESETS: dict[str, list[str]] = {
    "owner": ["*"],  # all-permissions sentinel
    "manager": [
        "restaurant:read", "restaurant:update", "branches:read", "branches:update",
        "members:read", "members:invite", "members:update", "members:remove",
        "roles:read",
        "staff:read", "staff:create", "staff:update", "staff:remove",
        "shifts:read", "shifts:create", "shifts:update", "shifts:delete",
        "time-clock:write",
        "menu:read", "menu:create", "menu:update", "menu:delete",
        "modifiers:read", "modifiers:create", "modifiers:update", "modifiers:delete",
        "tables:read", "tables:create", "tables:update", "tables:delete",
        "reservations:read", "reservations:create", "reservations:update", "reservations:cancel",
        "orders:read", "orders:create", "orders:update", "orders:transition", "orders:cancel", "orders:refund",
        "kitchen:read",
        "payments:read", "payments:refund", "closeout:read", "closeout:create",
        "customers:read", "customers:update",
        "loyalty:read", "loyalty:adjust",
        "coupons:read", "coupons:create", "coupons:update", "coupons:delete",
        "inventory:read", "inventory:adjust", "inventory:count", "waste:write",
        "suppliers:read", "suppliers:create", "suppliers:update",
        "purchasing:read", "purchasing:create", "purchasing:receive",
        "delivery:read", "delivery:assign", "delivery:transition",
        "notifications:read", "reports:read", "audit:read",
    ],
    "cashier": [
        "menu:read", "tables:read", "reservations:read",
        "orders:read", "orders:create", "orders:update", "orders:transition",
        "payments:read", "payments:create",
        "customers:read", "customers:create",
        "loyalty:read", "coupons:read",
    ],
    "server": [
        "menu:read", "tables:read", "tables:update", "reservations:read",
        "orders:read", "orders:create", "orders:update", "orders:transition",
        "kitchen:read",
        "customers:read", "customers:create",
    ],
    "chef": [
        "menu:read", "kitchen:read", "kitchen:transition", "orders:read",
        "inventory:read", "waste:write",
    ],
    "kitchen_staff": ["menu:read", "kitchen:read", "kitchen:transition", "orders:read"],
    "delivery_staff": ["orders:read", "delivery:read", "delivery:transition"],
    "inventory_manager": [
        "inventory:read", "inventory:adjust", "inventory:count", "waste:write",
        "suppliers:read", "suppliers:create", "suppliers:update",
        "purchasing:read", "purchasing:create", "purchasing:receive",
    ],
    "accountant": [
        "payments:read", "closeout:read", "reports:read",
        "purchasing:read", "suppliers:read",
    ],
    "viewer": [p for p in CATALOG if p.endswith(":read")],
}
