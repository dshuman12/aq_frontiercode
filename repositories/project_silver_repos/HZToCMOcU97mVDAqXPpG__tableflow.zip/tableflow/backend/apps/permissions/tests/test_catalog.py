from apps.permissions.catalog import CATALOG, is_known
from apps.permissions.presets import PRESETS


def test_no_duplicate_permissions():
    assert len(CATALOG) == len(set(CATALOG))


def test_owner_uses_wildcard():
    assert PRESETS["owner"] == ["*"]


def test_every_preset_perm_is_known_or_wildcard():
    for slug, perms in PRESETS.items():
        for p in perms:
            if p == "*":
                continue
            assert is_known(p), f"{slug} references unknown permission {p}"


def test_viewer_is_read_only():
    for p in PRESETS["viewer"]:
        assert p.endswith(":read")


def test_cashier_can_create_orders_and_payments():
    assert "orders:create" in PRESETS["cashier"]
    assert "payments:create" in PRESETS["cashier"]
    assert "payments:refund" not in PRESETS["cashier"]
