from apps.permissions.presets import PRESETS


def test_owner_is_only_wildcard():
    assert PRESETS["owner"] == ["*"]
    for slug, perms in PRESETS.items():
        if slug != "owner":
            assert "*" not in perms, f"{slug} should not have wildcard"


def test_chef_can_transition_kitchen_but_not_orders():
    perms = PRESETS["chef"]
    assert "kitchen:transition" in perms
    assert "orders:transition" not in perms


def test_delivery_staff_no_kitchen_access():
    perms = PRESETS["delivery_staff"]
    assert "kitchen:transition" not in perms
    assert "delivery:transition" in perms


def test_accountant_can_close_day_and_read_reports():
    perms = PRESETS["accountant"]
    assert "closeout:read" in perms
    assert "reports:read" in perms


def test_inventory_manager_no_orders_access():
    perms = PRESETS["inventory_manager"]
    assert "orders:read" not in perms
    assert "inventory:adjust" in perms
