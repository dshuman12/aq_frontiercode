"""Flat permission catalog. Every protected route uses one of these strings."""
from __future__ import annotations

CATALOG: list[str] = [
    # restaurant + admin
    "restaurant:read",
    "restaurant:update",
    "restaurant:admin",
    "branches:read",
    "branches:create",
    "branches:update",
    "branches:delete",
    "members:read",
    "members:invite",
    "members:update",
    "members:remove",
    "roles:read",
    "roles:create",
    "roles:update",
    "roles:delete",

    # staff
    "staff:read",
    "staff:create",
    "staff:update",
    "staff:remove",
    "shifts:read",
    "shifts:create",
    "shifts:update",
    "shifts:delete",
    "time-clock:write",

    # menu
    "menu:read",
    "menu:create",
    "menu:update",
    "menu:delete",
    "modifiers:read",
    "modifiers:create",
    "modifiers:update",
    "modifiers:delete",

    # tables / reservations
    "tables:read",
    "tables:create",
    "tables:update",
    "tables:delete",
    "reservations:read",
    "reservations:create",
    "reservations:update",
    "reservations:cancel",

    # orders
    "orders:read",
    "orders:create",
    "orders:update",
    "orders:transition",
    "orders:cancel",
    "orders:refund",
    "kitchen:read",
    "kitchen:transition",

    # payments
    "payments:read",
    "payments:create",
    "payments:refund",
    "closeout:read",
    "closeout:create",

    # customers / loyalty / coupons
    "customers:read",
    "customers:create",
    "customers:update",
    "customers:delete",
    "loyalty:read",
    "loyalty:adjust",
    "coupons:read",
    "coupons:create",
    "coupons:update",
    "coupons:delete",

    # inventory / suppliers
    "inventory:read",
    "inventory:adjust",
    "inventory:count",
    "waste:write",
    "suppliers:read",
    "suppliers:create",
    "suppliers:update",
    "suppliers:delete",
    "purchasing:read",
    "purchasing:create",
    "purchasing:receive",

    # delivery
    "delivery:read",
    "delivery:assign",
    "delivery:transition",

    # ops
    "notifications:read",
    "notifications:dispatch",
    "reports:read",
    "audit:read",
    "api-keys:read",
    "api-keys:create",
    "api-keys:revoke",
    "webhooks:read",
    "webhooks:create",
    "webhooks:revoke",
    "files:read",
    "files:create",
    "files:delete",
]


def is_known(perm: str) -> bool:
    return perm in CATALOG
