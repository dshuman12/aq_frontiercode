"""Render a payment receipt PDF using reportlab."""
from __future__ import annotations

import io
from decimal import Decimal

from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch
from reportlab.pdfgen import canvas


def cents_to_money(cents: int, currency: str = "USD") -> str:
    return f"${Decimal(cents) / 100:.2f}"


def render_receipt_pdf(*, restaurant_name: str, order_number: str, line_items: list[dict], totals: dict, currency: str = "USD") -> bytes:
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=letter)
    width, height = letter
    y = height - 1 * inch

    c.setFont("Helvetica-Bold", 16)
    c.drawString(1 * inch, y, restaurant_name)
    y -= 0.3 * inch
    c.setFont("Helvetica", 10)
    c.drawString(1 * inch, y, f"Receipt for {order_number}")
    y -= 0.4 * inch

    c.setFont("Helvetica-Bold", 10)
    c.drawString(1 * inch, y, "Item")
    c.drawRightString(7.5 * inch, y, "Total")
    y -= 0.18 * inch
    c.line(1 * inch, y, 7.5 * inch, y)
    y -= 0.18 * inch
    c.setFont("Helvetica", 10)
    for li in line_items:
        c.drawString(1 * inch, y, f"{li['quantity']}x {li['name']}")
        c.drawRightString(7.5 * inch, y, cents_to_money(li["total_cents"], currency))
        y -= 0.16 * inch

    y -= 0.18 * inch
    c.line(1 * inch, y, 7.5 * inch, y)
    y -= 0.18 * inch
    for label, key in [
        ("Subtotal", "subtotal_cents"),
        ("Discount", "discount_cents"),
        ("Tax", "tax_cents"),
        ("Service charge", "service_charge_cents"),
        ("Tip", "tip_cents"),
    ]:
        if totals.get(key, 0) == 0 and label != "Subtotal":
            continue
        c.drawString(5 * inch, y, label)
        c.drawRightString(7.5 * inch, y, cents_to_money(totals.get(key, 0), currency))
        y -= 0.16 * inch
    c.setFont("Helvetica-Bold", 11)
    c.drawString(5 * inch, y, "Total")
    c.drawRightString(7.5 * inch, y, cents_to_money(totals.get("total_cents", 0), currency))

    c.showPage()
    c.save()
    return buf.getvalue()
