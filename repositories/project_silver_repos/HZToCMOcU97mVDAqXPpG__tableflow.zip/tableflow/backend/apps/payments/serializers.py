from rest_framework import serializers

from .models import DailyCloseout, Payment, PaymentMethod, Receipt, Refund


class PaymentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Payment
        fields = "__all__"
        read_only_fields = [
            "id", "restaurant_id", "branch", "status", "stripe_payment_intent_id",
            "stripe_charge_id", "captured_at", "voided_at", "error_code", "error_message",
            "created_at", "updated_at",
        ]


class CapturePaymentSerializer(serializers.Serializer):
    order = serializers.UUIDField()
    amount_cents = serializers.IntegerField(min_value=1)
    tip_cents = serializers.IntegerField(min_value=0, default=0)
    method = serializers.ChoiceField(choices=[c[0] for c in Payment.METHOD_CHOICES], default="card")
    notes = serializers.CharField(required=False, allow_blank=True, max_length=300)


class RefundSerializer(serializers.ModelSerializer):
    class Meta:
        model = Refund
        fields = "__all__"
        read_only_fields = ["id", "status", "stripe_refund_id", "created_at", "succeeded_at"]


class CreateRefundSerializer(serializers.Serializer):
    payment = serializers.UUIDField()
    amount_cents = serializers.IntegerField(min_value=1)
    reason = serializers.CharField(required=False, allow_blank=True, max_length=200)


class ReceiptSerializer(serializers.ModelSerializer):
    class Meta:
        model = Receipt
        fields = "__all__"


class PaymentMethodSerializer(serializers.ModelSerializer):
    class Meta:
        model = PaymentMethod
        fields = "__all__"
        read_only_fields = ["id", "created_at"]


class CloseoutSerializer(serializers.ModelSerializer):
    class Meta:
        model = DailyCloseout
        fields = "__all__"
        read_only_fields = ["id", "restaurant_id", "expected_cents", "diff_cents", "closed_at"]


class CreateCloseoutSerializer(serializers.Serializer):
    branch = serializers.UUIDField()
    date = serializers.DateField()
    counted_cents = serializers.IntegerField(min_value=0)
    notes = serializers.CharField(required=False, allow_blank=True, max_length=300)
