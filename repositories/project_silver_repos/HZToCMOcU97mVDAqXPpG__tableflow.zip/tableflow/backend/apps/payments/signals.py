"""Audit logging for payment captures and refunds."""
from __future__ import annotations

from django.db.models.signals import post_save
from django.dispatch import receiver

from .models import Payment, Refund


@receiver(post_save, sender=Payment)
def emit_payment_audit(sender, instance: Payment, created: bool, **kwargs):
    from apps.audit_logs.models import AuditLog

    if not (created or instance.status == "captured"):
        return
    if not (created and instance.status == "captured") and instance.status not in ("captured", "refunded", "voided"):
        return
    AuditLog.objects.create(
        restaurant_id=instance.restaurant_id,
        action=f"payment.{instance.status}",
        resource="payment",
        resource_id=str(instance.id),
        diff={"amount_cents": instance.amount_cents, "method": instance.method},
    )


@receiver(post_save, sender=Refund)
def emit_refund_audit(sender, instance: Refund, created: bool, **kwargs):
    if not created or instance.status != "succeeded":
        return
    from apps.audit_logs.models import AuditLog
    AuditLog.objects.create(
        restaurant_id=instance.payment.restaurant_id,
        action="payment.refund.succeeded",
        resource="refund",
        resource_id=str(instance.id),
        diff={"amount_cents": instance.amount_cents, "reason": instance.reason},
    )
