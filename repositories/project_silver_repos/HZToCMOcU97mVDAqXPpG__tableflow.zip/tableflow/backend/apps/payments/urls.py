from django.urls import path

from . import views

urlpatterns = [
    path("", views.PaymentList.as_view()),
    path("capture", views.CapturePaymentView.as_view()),
    path("refunds", views.CreateRefundView.as_view()),
    path("closeouts", views.CloseoutList.as_view()),
    path("closeouts/create", views.CreateCloseoutView.as_view()),
    path("webhooks/stripe", views.StripeWebhookView.as_view()),
]
