from django.contrib import admin

from .models import DailyCloseout, Payment, PaymentMethod, Receipt, Refund


@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ("order", "amount_cents", "method", "status", "captured_at")
    list_filter = ("status", "method")
    search_fields = ("stripe_payment_intent_id", "stripe_charge_id")
    readonly_fields = ("captured_at", "voided_at", "created_at", "updated_at")


@admin.register(DailyCloseout)
class DailyCloseoutAdmin(admin.ModelAdmin):
    list_display = ("date", "branch", "expected_cents", "counted_cents", "diff_cents")
    list_filter = ("branch",)


admin.site.register([Refund, Receipt, PaymentMethod])
