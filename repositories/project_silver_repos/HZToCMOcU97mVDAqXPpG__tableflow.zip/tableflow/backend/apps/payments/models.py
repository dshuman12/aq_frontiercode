"""Payment, PaymentMethod, Refund, Receipt, DailyCloseout."""
from __future__ import annotations

import uuid

from django.conf import settings
from django.db import models


class PaymentMethod(models.Model):
    """Saved payment method for a customer (Stripe payment_method id)."""

    KIND_CHOICES = [("card", "Card"), ("apple_pay", "Apple Pay"), ("google_pay", "Google Pay")]
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    customer = models.ForeignKey("customers.Customer", on_delete=models.CASCADE, related_name="payment_methods")
    kind = models.CharField(max_length=12, choices=KIND_CHOICES, default="card")
    stripe_payment_method_id = models.CharField(max_length=120)
    brand = models.CharField(max_length=24, blank=True)  # visa/mc/...
    last4 = models.CharField(max_length=4, blank=True)
    exp_month = models.PositiveSmallIntegerField(default=0)
    exp_year = models.PositiveSmallIntegerField(default=0)
    is_default = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "payment_method"


class Payment(models.Model):
    METHOD_CHOICES = [
        ("card", "Card"),
        ("cash", "Cash"),
        ("manual", "Manual"),
        ("gift_card", "Gift card"),
        ("loyalty", "Loyalty redemption"),
        ("split", "Split"),
    ]
    STATUS_CHOICES = [
        ("pending", "Pending"),
        ("captured", "Captured"),
        ("failed", "Failed"),
        ("voided", "Voided"),
        ("refunded", "Refunded"),
    ]
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(db_index=True)
    branch = models.ForeignKey("branches.Branch", on_delete=models.PROTECT, related_name="payments")
    order = models.ForeignKey("orders.Order", on_delete=models.PROTECT, related_name="payments")
    amount_cents = models.PositiveIntegerField()
    tip_cents = models.PositiveIntegerField(default=0)
    method = models.CharField(max_length=12, choices=METHOD_CHOICES, default="card")
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default="pending", db_index=True)
    stripe_payment_intent_id = models.CharField(max_length=120, blank=True, db_index=True)
    stripe_charge_id = models.CharField(max_length=120, blank=True)
    cashier = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="captured_payments")
    error_code = models.CharField(max_length=80, blank=True)
    error_message = models.CharField(max_length=300, blank=True)
    captured_at = models.DateTimeField(null=True, blank=True)
    voided_at = models.DateTimeField(null=True, blank=True)
    notes = models.CharField(max_length=300, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "payment"
        indexes = [
            models.Index(fields=["restaurant_id", "branch", "created_at"]),
            models.Index(fields=["restaurant_id", "status"]),
        ]


class Refund(models.Model):
    STATUS_CHOICES = [("pending", "Pending"), ("succeeded", "Succeeded"), ("failed", "Failed")]
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    payment = models.ForeignKey(Payment, on_delete=models.CASCADE, related_name="refunds")
    amount_cents = models.PositiveIntegerField()
    reason = models.CharField(max_length=200, blank=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default="pending")
    stripe_refund_id = models.CharField(max_length=120, blank=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL)
    created_at = models.DateTimeField(auto_now_add=True)
    succeeded_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "refund"


class Receipt(models.Model):
    KIND_CHOICES = [("html", "HTML"), ("pdf", "PDF"), ("email", "Email")]
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    order = models.ForeignKey("orders.Order", on_delete=models.CASCADE, related_name="receipts")
    payment = models.ForeignKey(Payment, on_delete=models.CASCADE, related_name="receipts", null=True, blank=True)
    kind = models.CharField(max_length=8, choices=KIND_CHOICES, default="email")
    file = models.ForeignKey("files.FileAsset", null=True, blank=True, on_delete=models.SET_NULL)
    sent_to = models.EmailField(blank=True)
    sent_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "receipt"


class DailyCloseout(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(db_index=True)
    branch = models.ForeignKey("branches.Branch", on_delete=models.PROTECT, related_name="closeouts")
    date = models.DateField()
    cashier = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL, related_name="closeouts")
    expected_cents = models.PositiveIntegerField(default=0)
    counted_cents = models.PositiveIntegerField(default=0)
    diff_cents = models.IntegerField(default=0)
    notes = models.CharField(max_length=300, blank=True)
    closed_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "daily_closeout"
        unique_together = ("restaurant_id", "branch", "date")
