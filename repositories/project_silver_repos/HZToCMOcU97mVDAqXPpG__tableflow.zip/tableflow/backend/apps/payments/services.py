"""Payment services — capture/void/refund + closeout."""
from __future__ import annotations

from datetime import date

from django.db import transaction
from django.db.models import Sum
from django.utils import timezone
from rest_framework.exceptions import ValidationError

from apps.orders.models import Order

from .models import DailyCloseout, Payment, Refund
from .stripe_client import get_client


@transaction.atomic
def capture_payment(*, order: Order, amount_cents: int, method: str = "card", tip_cents: int = 0, cashier=None, notes: str = "") -> Payment:
    if amount_cents <= 0:
        raise ValidationError({"amount_cents": "must be positive"})
    if amount_cents > order.balance_cents:
        raise ValidationError({"amount_cents": f"exceeds-balance:{order.balance_cents}"})

    payment = Payment.objects.create(
        restaurant_id=order.restaurant_id,
        branch=order.branch,
        order=order,
        amount_cents=amount_cents,
        tip_cents=tip_cents,
        method=method,
        status="pending",
        cashier=cashier if getattr(cashier, "is_authenticated", False) else None,
        notes=notes,
    )
    if method == "card":
        client = get_client()
        intent = client.create_payment_intent(
            amount_cents=amount_cents + tip_cents,
            metadata={"order_id": str(order.id), "payment_id": str(payment.id)},
        )
        confirmed = client.confirm_payment_intent(intent["id"])
        payment.stripe_payment_intent_id = intent["id"]
        ok = confirmed.get("status") == "succeeded"
        payment.status = "captured" if ok else "failed"
        if not ok:
            payment.error_message = "stripe-not-succeeded"
    else:
        payment.status = "captured"

    if payment.status == "captured":
        payment.captured_at = timezone.now()
        order.paid_cents = order.paid_cents + amount_cents
        order.tip_cents = order.tip_cents + tip_cents
        order.save(update_fields=["paid_cents", "tip_cents", "updated_at"])
    payment.save()
    return payment


@transaction.atomic
def refund_payment(*, payment: Payment, amount_cents: int, reason: str = "", by=None) -> Refund:
    if payment.status != "captured":
        raise ValidationError({"status": "cannot-refund-non-captured"})
    refundable = payment.amount_cents - sum(
        r.amount_cents for r in payment.refunds.filter(status="succeeded")
    )
    if amount_cents <= 0 or amount_cents > refundable:
        raise ValidationError({"amount_cents": f"max-refundable:{refundable}"})

    refund = Refund.objects.create(
        payment=payment, amount_cents=amount_cents, reason=reason,
        created_by=by if getattr(by, "is_authenticated", False) else None,
    )
    if payment.method == "card" and payment.stripe_payment_intent_id:
        client = get_client()
        result = client.refund(
            payment_intent_id=payment.stripe_payment_intent_id, amount_cents=amount_cents,
        )
        refund.stripe_refund_id = result.get("id", "")
        refund.status = "succeeded" if result.get("status") == "succeeded" else "failed"
    else:
        refund.status = "succeeded"
    if refund.status == "succeeded":
        refund.succeeded_at = timezone.now()
        order = payment.order
        order.refund_cents = order.refund_cents + amount_cents
        order.paid_cents = max(0, order.paid_cents - amount_cents)
        order.save(update_fields=["refund_cents", "paid_cents", "updated_at"])
    refund.save()
    return refund


def daily_expected(*, restaurant_id, branch, day: date) -> int:
    qs = Payment.objects.filter(
        restaurant_id=restaurant_id,
        branch=branch,
        status="captured",
        captured_at__date=day,
    )
    return qs.aggregate(total=Sum("amount_cents"))["total"] or 0


@transaction.atomic
def close_day(*, restaurant_id, branch, day: date, counted_cents: int, cashier=None, notes: str = "") -> DailyCloseout:
    expected = daily_expected(restaurant_id=restaurant_id, branch=branch, day=day)
    obj, _ = DailyCloseout.objects.update_or_create(
        restaurant_id=restaurant_id, branch=branch, date=day,
        defaults={
            "expected_cents": expected,
            "counted_cents": counted_cents,
            "diff_cents": counted_cents - expected,
            "cashier": cashier if getattr(cashier, "is_authenticated", False) else None,
            "notes": notes,
        },
    )
    return obj
