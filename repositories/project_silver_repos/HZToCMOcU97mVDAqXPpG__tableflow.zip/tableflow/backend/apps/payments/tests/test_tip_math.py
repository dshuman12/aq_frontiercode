import pytest

from apps.payments.tip_math import even_split_tip, shares_by_hours, tip_for_percent


def test_tip_for_percent_basic():
    assert tip_for_percent(10000, 18) == 1800
    assert tip_for_percent(2599, 20) == 520


def test_tip_for_percent_zero_returns_zero():
    assert tip_for_percent(10000, 0) == 0


def test_tip_for_percent_negative_raises():
    with pytest.raises(ValueError):
        tip_for_percent(1000, -5)


def test_even_split_tip_sums_exactly():
    assert sum(even_split_tip(1001, 3)) == 1001


def test_shares_by_hours_proportional():
    out = shares_by_hours(10000, {"a": 2, "b": 8})
    assert out["a"] + out["b"] == 10000
    assert out["a"] == 2000
    assert out["b"] == 8000


def test_shares_by_hours_remainder_to_top_worker():
    out = shares_by_hours(1001, {"a": 1, "b": 1, "c": 2})
    assert sum(out.values()) == 1001
    assert max(out, key=out.get) == "c"


def test_shares_by_hours_zero_total():
    out = shares_by_hours(0, {"a": 1, "b": 2})
    assert out == {"a": 0, "b": 0}


def test_shares_by_hours_no_hours_returns_zeros():
    out = shares_by_hours(1000, {"a": 0, "b": 0})
    assert out == {"a": 0, "b": 0}
