"""Daily method breakdown derived purely from payments."""


def aggregate(payments):
    out = {}
    for p in payments:
        if p.get("status") != "captured":
            continue
        m = p.get("method", "other")
        out[m] = out.get(m, 0) + int(p.get("amount_cents", 0))
    return out


def test_groups_by_method():
    rows = [
        {"status": "captured", "method": "card", "amount_cents": 1000},
        {"status": "captured", "method": "cash", "amount_cents": 200},
        {"status": "failed", "method": "card", "amount_cents": 500},
    ]
    assert aggregate(rows) == {"card": 1000, "cash": 200}


def test_drops_failed_payments():
    rows = [{"status": "failed", "method": "card", "amount_cents": 1}]
    assert aggregate(rows) == {}


def test_unknown_method_falls_through():
    rows = [{"status": "captured", "amount_cents": 100}]
    assert aggregate(rows) == {"other": 100}
