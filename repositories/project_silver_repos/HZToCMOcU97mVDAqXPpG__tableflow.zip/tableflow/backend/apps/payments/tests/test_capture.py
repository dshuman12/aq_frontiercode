from datetime import date

import pytest

from apps.payments.services import close_day, daily_expected
from apps.payments.stripe_client import StripeClient


@pytest.fixture
def sim_client():
    return StripeClient(secret="")


def test_simulated_client_returns_pseudo_intent(sim_client):
    pi = sim_client.create_payment_intent(amount_cents=12345)
    assert pi["simulated"] is True
    assert pi["amount"] == 12345
    assert pi["id"].startswith("sim_pi_")


def test_simulated_client_refund_succeeds(sim_client):
    out = sim_client.refund(payment_intent_id="sim_pi_abc", amount_cents=500)
    assert out["status"] == "succeeded"


def test_simulated_construct_event_returns_payload(sim_client):
    raw = b'{"type":"payment_intent.succeeded","data":{"object":{"id":"pi_x"}}}'
    evt = sim_client.construct_event(raw, "ignored")
    assert evt["type"] == "payment_intent.succeeded"
