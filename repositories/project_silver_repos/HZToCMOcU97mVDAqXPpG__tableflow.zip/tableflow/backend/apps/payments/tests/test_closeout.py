"""Pure-math closeout tests — diff between expected and counted."""


def diff(expected, counted):
    return counted - expected


def test_zero_diff_when_matched():
    assert diff(123_456, 123_456) == 0


def test_negative_diff_when_short():
    assert diff(50_000, 49_500) == -500


def test_positive_diff_when_over():
    assert diff(50_000, 50_300) == 300


def test_summary_categorizes_diff():
    cases = [(0, "ok"), (-100, "short"), (200, "over")]
    for d, label in cases:
        if d == 0:
            actual = "ok"
        elif d > 0:
            actual = "over"
        else:
            actual = "short"
        assert actual == label
