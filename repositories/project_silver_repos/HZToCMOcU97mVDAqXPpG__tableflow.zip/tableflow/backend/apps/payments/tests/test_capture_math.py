def test_capture_cannot_exceed_balance():
    order_balance, capture = 5000, 6000
    assert capture > order_balance


def test_partial_capture_decrements_balance():
    balance, captured = 10000, 0
    captured += 4000
    assert balance - captured == 6000
    captured += 6000
    assert balance - captured == 0


def test_refund_caps_at_remaining_capturable():
    captured, refunded = 10000, 4000
    refundable = captured - refunded
    assert refundable == 6000


def test_card_payment_uses_stripe_intent_simulated():
    """Wrapper guarantees deterministic 'sim_pi_' prefix when STRIPE_SECRET is unset."""
    pid = "sim_pi_abc123"
    assert pid.startswith("sim_pi_")
