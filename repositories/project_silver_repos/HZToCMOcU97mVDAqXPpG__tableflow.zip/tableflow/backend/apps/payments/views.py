from rest_framework import generics, status
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.accounts.permissions import perm
from apps.audit_logs.services import record as audit
from apps.branches.models import Branch
from apps.orders.models import Order

from . import services
from .models import DailyCloseout, Payment, Refund
from .serializers import (
    CapturePaymentSerializer,
    CloseoutSerializer,
    CreateCloseoutSerializer,
    CreateRefundSerializer,
    PaymentSerializer,
    RefundSerializer,
)
from .stripe_client import get_client


class PaymentList(generics.ListAPIView):
    serializer_class = PaymentSerializer
    permission_classes = [perm("payments:read")]
    filterset_fields = ["branch", "status", "method", "order"]
    ordering = ["-created_at"]

    def get_queryset(self):  # type: ignore[override]
        return Payment.objects.filter(restaurant_id=self.request.restaurant_id)


class CapturePaymentView(APIView):
    permission_classes = [perm("payments:create")]

    def post(self, request):
        serializer = CapturePaymentSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        d = serializer.validated_data
        order = Order.objects.get(pk=d["order"], restaurant_id=request.restaurant_id)
        payment = services.capture_payment(
            order=order,
            amount_cents=d["amount_cents"],
            tip_cents=d.get("tip_cents", 0),
            method=d.get("method", "card"),
            cashier=request.user,
            notes=d.get("notes", ""),
        )
        audit(request=request, action="payment.capture", resource="payment", resource_id=str(payment.id),
              diff={"order_id": str(order.id), "amount_cents": payment.amount_cents, "method": payment.method, "status": payment.status})
        return Response(PaymentSerializer(payment).data, status=status.HTTP_201_CREATED)


class CreateRefundView(APIView):
    permission_classes = [perm("payments:refund")]

    def post(self, request):
        serializer = CreateRefundSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        d = serializer.validated_data
        payment = Payment.objects.get(pk=d["payment"], restaurant_id=request.restaurant_id)
        refund = services.refund_payment(payment=payment, amount_cents=d["amount_cents"], reason=d.get("reason", ""), by=request.user)
        audit(request=request, action="payment.refund", resource="refund", resource_id=str(refund.id),
              diff={"payment_id": str(payment.id), "amount_cents": refund.amount_cents})
        return Response(RefundSerializer(refund).data, status=status.HTTP_201_CREATED)


class CloseoutList(generics.ListAPIView):
    serializer_class = CloseoutSerializer
    permission_classes = [perm("closeout:read")]
    filterset_fields = ["branch", "date"]

    def get_queryset(self):  # type: ignore[override]
        return DailyCloseout.objects.filter(restaurant_id=self.request.restaurant_id).order_by("-date")


class CreateCloseoutView(APIView):
    permission_classes = [perm("closeout:create")]

    def post(self, request):
        serializer = CreateCloseoutSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        d = serializer.validated_data
        branch = Branch.objects.get(pk=d["branch"], restaurant_id=request.restaurant_id)
        obj = services.close_day(
            restaurant_id=request.restaurant_id,
            branch=branch,
            day=d["date"],
            counted_cents=d["counted_cents"],
            cashier=request.user,
            notes=d.get("notes", ""),
        )
        audit(request=request, action="closeout.create", resource="closeout", resource_id=str(obj.id),
              diff={"date": str(obj.date), "diff_cents": obj.diff_cents})
        return Response(CloseoutSerializer(obj).data, status=status.HTTP_201_CREATED)


class StripeWebhookView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        payload = request.body
        sig = request.META.get("HTTP_STRIPE_SIGNATURE", "")
        try:
            event = get_client().construct_event(payload, sig)
        except Exception as exc:  # pragma: no cover
            return Response({"detail": f"bad-signature:{exc}"}, status=status.HTTP_400_BAD_REQUEST)

        from .tasks import handle_stripe_event
        handle_stripe_event.delay(event.get("type"), event.get("data", {}).get("object", {}))
        return Response({"received": True})
