"""Stripe wrapper with simulated mode (no STRIPE_SECRET → log-only)."""
from __future__ import annotations

import logging
import secrets
from typing import Any

from django.conf import settings

log = logging.getLogger(__name__)

try:
    import stripe as stripe_lib
except ImportError:  # pragma: no cover
    stripe_lib = None


class StripeClient:
    def __init__(self, *, secret: str | None = None) -> None:
        self.secret = secret if secret is not None else settings.STRIPE_SECRET
        self.simulated = not bool(self.secret)
        if not self.simulated and stripe_lib is not None:
            stripe_lib.api_key = self.secret

    def create_payment_intent(self, *, amount_cents: int, currency: str = "usd", metadata: dict | None = None) -> dict[str, Any]:
        if self.simulated:
            pid = "sim_pi_" + secrets.token_hex(8)
            log.info("stripe.sim.create_payment_intent", extra={"pid": pid, "amount_cents": amount_cents, "metadata": metadata})
            return {
                "id": pid,
                "client_secret": pid + "_secret",
                "amount": amount_cents,
                "currency": currency,
                "status": "requires_payment_method",
                "simulated": True,
            }
        return stripe_lib.PaymentIntent.create(amount=amount_cents, currency=currency, metadata=metadata or {})  # type: ignore[union-attr]

    def confirm_payment_intent(self, intent_id: str) -> dict[str, Any]:
        if self.simulated:
            return {"id": intent_id, "status": "succeeded", "simulated": True}
        return stripe_lib.PaymentIntent.confirm(intent_id)  # type: ignore[union-attr]

    def refund(self, *, payment_intent_id: str, amount_cents: int) -> dict[str, Any]:
        if self.simulated:
            rid = "sim_re_" + secrets.token_hex(8)
            log.info("stripe.sim.refund", extra={"rid": rid, "pid": payment_intent_id, "amount_cents": amount_cents})
            return {"id": rid, "status": "succeeded", "amount": amount_cents, "simulated": True}
        return stripe_lib.Refund.create(payment_intent=payment_intent_id, amount=amount_cents)  # type: ignore[union-attr]

    def construct_event(self, payload: bytes, sig_header: str) -> dict[str, Any]:
        if self.simulated or not stripe_lib:
            import json
            return json.loads(payload)
        return stripe_lib.Webhook.construct_event(payload, sig_header, settings.STRIPE_WEBHOOK_SECRET)  # type: ignore[union-attr]


def get_client() -> StripeClient:
    return StripeClient()
