"""Celery tasks for payments — webhook handling + receipt emails."""
from __future__ import annotations

import logging

from celery import shared_task
from django.utils import timezone

from .models import Payment

log = logging.getLogger(__name__)


@shared_task
def handle_stripe_event(event_type: str, obj: dict) -> dict:
    if event_type == "payment_intent.succeeded":
        pid = obj.get("id")
        if not pid:
            return {"skipped": "no-id"}
        try:
            p = Payment.objects.get(stripe_payment_intent_id=pid, status__in=["pending", "captured"])
        except Payment.DoesNotExist:
            return {"skipped": "payment-not-found"}
        if p.status != "captured":
            p.status = "captured"
            p.captured_at = timezone.now()
            p.save(update_fields=["status", "captured_at", "updated_at"])
        return {"ok": True, "payment": str(p.id)}
    if event_type == "payment_intent.payment_failed":
        pid = obj.get("id")
        if pid:
            Payment.objects.filter(stripe_payment_intent_id=pid).update(
                status="failed",
                error_code=(obj.get("last_payment_error") or {}).get("code", ""),
                error_message=(obj.get("last_payment_error") or {}).get("message", ""),
            )
        return {"ok": True}
    return {"ignored": event_type}


@shared_task
def send_payment_receipt_email(payment_id: str, to_email: str) -> dict:
    log.info("payments.receipt.email", extra={"payment_id": payment_id, "to": to_email})
    return {"queued": True}
