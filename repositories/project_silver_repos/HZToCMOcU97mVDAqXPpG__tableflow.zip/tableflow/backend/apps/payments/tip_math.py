"""Pure helpers for tip computation."""
from __future__ import annotations


def tip_for_percent(subtotal_cents: int, percent: float) -> int:
    if percent < 0:
        raise ValueError("percent must be non-negative")
    return int(round(subtotal_cents * (percent / 100)))


def even_split_tip(total_tip_cents: int, n_servers: int) -> list[int]:
    if n_servers <= 0:
        raise ValueError("n_servers must be positive")
    base, extra = divmod(total_tip_cents, n_servers)
    return [base + (1 if i < extra else 0) for i in range(n_servers)]


def shares_by_hours(total_tip_cents: int, hours_by_server: dict[str, float]) -> dict[str, int]:
    """Allocate tip pool by hours-worked weight; remainder goes to the highest hours."""
    if not hours_by_server:
        return {}
    if total_tip_cents == 0:
        return {k: 0 for k in hours_by_server}
    total_hours = sum(hours_by_server.values())
    if total_hours <= 0:
        return {k: 0 for k in hours_by_server}
    out: dict[str, int] = {}
    running = 0
    for k, h in hours_by_server.items():
        share = int(total_tip_cents * (h / total_hours))
        out[k] = share
        running += share
    leftover = total_tip_cents - running
    if leftover:
        top = max(hours_by_server.items(), key=lambda kv: kv[1])[0]
        out[top] += leftover
    return out
