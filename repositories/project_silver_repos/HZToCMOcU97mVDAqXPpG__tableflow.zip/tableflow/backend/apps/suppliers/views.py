from rest_framework import generics

from apps.accounts.permissions import perm

from .models import Supplier, SupplierContact, SupplierInvoice
from .serializers import (
    SupplierContactSerializer,
    SupplierInvoiceSerializer,
    SupplierSerializer,
)


class SupplierList(generics.ListCreateAPIView):
    serializer_class = SupplierSerializer
    permission_classes = [perm("suppliers:read")]
    search_fields = ["name", "code"]
    filterset_fields = ["is_archived"]

    def get_queryset(self):  # type: ignore[override]
        return Supplier.objects.filter(restaurant_id=self.request.restaurant_id).prefetch_related("contacts")

    def perform_create(self, serializer):  # type: ignore[override]
        serializer.save(restaurant_id=self.request.restaurant_id)


class SupplierDetail(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = SupplierSerializer
    permission_classes = [perm("suppliers:read")]

    def get_queryset(self):  # type: ignore[override]
        return Supplier.objects.filter(restaurant_id=self.request.restaurant_id)

    def perform_destroy(self, instance):  # type: ignore[override]
        instance.is_archived = True
        instance.save(update_fields=["is_archived"])


class SupplierContactList(generics.ListCreateAPIView):
    serializer_class = SupplierContactSerializer
    permission_classes = [perm("suppliers:read")]
    filterset_fields = ["supplier"]

    def get_queryset(self):  # type: ignore[override]
        return SupplierContact.objects.filter(supplier__restaurant_id=self.request.restaurant_id)


class SupplierInvoiceList(generics.ListCreateAPIView):
    serializer_class = SupplierInvoiceSerializer
    permission_classes = [perm("suppliers:read")]
    filterset_fields = ["supplier", "status"]

    def get_queryset(self):  # type: ignore[override]
        return SupplierInvoice.objects.filter(supplier__restaurant_id=self.request.restaurant_id)
