from rest_framework import serializers

from .models import Supplier, SupplierContact, SupplierInvoice


class SupplierContactSerializer(serializers.ModelSerializer):
    class Meta:
        model = SupplierContact
        fields = "__all__"
        read_only_fields = ["id"]


class SupplierSerializer(serializers.ModelSerializer):
    contacts = SupplierContactSerializer(many=True, read_only=True)

    class Meta:
        model = Supplier
        fields = "__all__"
        read_only_fields = ["id", "restaurant_id", "created_at", "updated_at"]


class SupplierInvoiceSerializer(serializers.ModelSerializer):
    class Meta:
        model = SupplierInvoice
        fields = "__all__"
        read_only_fields = ["id"]
