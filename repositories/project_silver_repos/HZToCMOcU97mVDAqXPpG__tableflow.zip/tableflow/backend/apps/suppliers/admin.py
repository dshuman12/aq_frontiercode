from django.contrib import admin

from .models import Supplier, SupplierContact, SupplierInvoice


@admin.register(Supplier)
class SupplierAdmin(admin.ModelAdmin):
    list_display = ("name", "code", "phone", "email", "is_archived")
    search_fields = ("name", "code", "email")


admin.site.register([SupplierContact, SupplierInvoice])
