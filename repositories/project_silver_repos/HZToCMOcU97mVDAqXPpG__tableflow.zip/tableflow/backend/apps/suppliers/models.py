"""Supplier + SupplierContact + SupplierInvoice."""
from __future__ import annotations

import uuid

from django.db import models


class Supplier(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(db_index=True)
    name = models.CharField(max_length=160)
    code = models.CharField(max_length=24, blank=True)
    phone = models.CharField(max_length=32, blank=True)
    email = models.EmailField(blank=True)
    address = models.TextField(blank=True)
    payment_terms = models.CharField(max_length=80, blank=True)  # e.g. "NET-30"
    notes = models.TextField(blank=True)
    is_archived = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "supplier"
        unique_together = ("restaurant_id", "code")
        indexes = [models.Index(fields=["restaurant_id", "is_archived"])]


class SupplierContact(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    supplier = models.ForeignKey(Supplier, on_delete=models.CASCADE, related_name="contacts")
    name = models.CharField(max_length=120)
    phone = models.CharField(max_length=32, blank=True)
    email = models.EmailField(blank=True)
    role = models.CharField(max_length=80, blank=True)
    is_primary = models.BooleanField(default=False)

    class Meta:
        db_table = "supplier_contact"


class SupplierInvoice(models.Model):
    STATUS_CHOICES = [("open", "Open"), ("paid", "Paid"), ("void", "Void")]
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    supplier = models.ForeignKey(Supplier, on_delete=models.PROTECT, related_name="invoices")
    purchase_order = models.ForeignKey("purchasing.PurchaseOrder", null=True, blank=True, on_delete=models.SET_NULL, related_name="invoices")
    number = models.CharField(max_length=80)
    issued_on = models.DateField()
    due_on = models.DateField(null=True, blank=True)
    paid_on = models.DateField(null=True, blank=True)
    amount_cents = models.PositiveIntegerField()
    paid_cents = models.PositiveIntegerField(default=0)
    status = models.CharField(max_length=8, choices=STATUS_CHOICES, default="open")
    file = models.ForeignKey("files.FileAsset", null=True, blank=True, on_delete=models.SET_NULL)

    class Meta:
        db_table = "supplier_invoice"
        unique_together = ("supplier", "number")
