from django.urls import path

from . import views

urlpatterns = [
    path("", views.SupplierList.as_view()),
    path("<uuid:pk>", views.SupplierDetail.as_view()),
    path("contacts", views.SupplierContactList.as_view()),
    path("invoices", views.SupplierInvoiceList.as_view()),
]
