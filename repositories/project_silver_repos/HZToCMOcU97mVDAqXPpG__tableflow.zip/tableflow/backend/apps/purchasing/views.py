import secrets

from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.accounts.permissions import perm

from . import services
from .models import PurchaseOrder
from .serializers import PurchaseOrderSerializer, ReceiveSerializer


class PurchaseOrderList(generics.ListCreateAPIView):
    serializer_class = PurchaseOrderSerializer
    permission_classes = [perm("purchasing:read")]
    filterset_fields = ["supplier", "branch", "status"]
    ordering = ["-created_at"]

    def get_queryset(self):  # type: ignore[override]
        return PurchaseOrder.objects.filter(restaurant_id=self.request.restaurant_id).prefetch_related("items")

    def perform_create(self, serializer):  # type: ignore[override]
        number = "PO-" + secrets.token_hex(3).upper()
        serializer.save(
            restaurant_id=self.request.restaurant_id,
            number=number,
            created_by=self.request.user,
        )


class PurchaseOrderDetail(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = PurchaseOrderSerializer
    permission_classes = [perm("purchasing:read")]

    def get_queryset(self):  # type: ignore[override]
        return PurchaseOrder.objects.filter(restaurant_id=self.request.restaurant_id)


class SubmitPOView(APIView):
    permission_classes = [perm("purchasing:create")]

    def post(self, request, pk):
        po = PurchaseOrder.objects.get(pk=pk, restaurant_id=request.restaurant_id)
        services.submit(po)
        return Response(PurchaseOrderSerializer(po).data)


class ReceivePOView(APIView):
    permission_classes = [perm("purchasing:receive")]

    def post(self, request, pk):
        po = PurchaseOrder.objects.get(pk=pk, restaurant_id=request.restaurant_id)
        serializer = ReceiveSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        services.receive(po, lines=serializer.validated_data["lines"], by=request.user)
        return Response(PurchaseOrderSerializer(po).data)


class CancelPOView(APIView):
    permission_classes = [perm("purchasing:create")]

    def post(self, request, pk):
        po = PurchaseOrder.objects.get(pk=pk, restaurant_id=request.restaurant_id)
        services.cancel(po)
        return Response(PurchaseOrderSerializer(po).data)
