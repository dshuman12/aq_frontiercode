from decimal import Decimal


def test_receive_partial_marks_partial_when_short():
    """If any line has quantity_received < quantity_ordered, status stays 'partial'."""
    lines = [
        {"id": "a", "ordered": Decimal("10"), "received": Decimal("10")},
        {"id": "b", "ordered": Decimal("5"), "received": Decimal("3")},
    ]
    fully = all(line["received"] >= line["ordered"] for line in lines)
    assert not fully


def test_receive_full_marks_received():
    lines = [
        {"id": "a", "ordered": Decimal("10"), "received": Decimal("10")},
        {"id": "b", "ordered": Decimal("5"), "received": Decimal("5")},
    ]
    assert all(line["received"] >= line["ordered"] for line in lines)


def test_subtotal_math():
    lines = [(Decimal("10"), 250), (Decimal("4"), 1500)]
    subtotal = sum(int(qty * cost) for qty, cost in lines)
    assert subtotal == 2500 + 6000
