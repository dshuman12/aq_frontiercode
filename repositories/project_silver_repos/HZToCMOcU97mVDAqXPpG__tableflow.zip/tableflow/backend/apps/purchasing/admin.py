from django.contrib import admin

from .models import PurchaseOrder, PurchaseOrderItem


class PurchaseOrderItemInline(admin.TabularInline):
    model = PurchaseOrderItem
    extra = 0
    readonly_fields = ("line_total_cents",)


@admin.register(PurchaseOrder)
class PurchaseOrderAdmin(admin.ModelAdmin):
    list_display = ("number", "supplier", "branch", "status", "expected_on", "total_cents")
    list_filter = ("status", "supplier")
    search_fields = ("number",)
    inlines = [PurchaseOrderItemInline]
    readonly_fields = ("subtotal_cents", "tax_cents", "total_cents", "created_at", "updated_at")
