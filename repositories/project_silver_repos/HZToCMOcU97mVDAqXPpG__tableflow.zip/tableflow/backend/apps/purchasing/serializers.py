from rest_framework import serializers

from .models import PurchaseOrder, PurchaseOrderItem


class PurchaseOrderItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = PurchaseOrderItem
        fields = "__all__"
        read_only_fields = ["id", "quantity_received", "line_total_cents"]


class PurchaseOrderSerializer(serializers.ModelSerializer):
    items = PurchaseOrderItemSerializer(many=True, read_only=True)

    class Meta:
        model = PurchaseOrder
        fields = "__all__"
        read_only_fields = [
            "id", "restaurant_id", "number", "status", "submitted_at", "received_on",
            "subtotal_cents", "tax_cents", "total_cents", "created_at", "updated_at",
        ]


class ReceiveSerializer(serializers.Serializer):
    lines = serializers.DictField(child=serializers.DecimalField(max_digits=12, decimal_places=3))
