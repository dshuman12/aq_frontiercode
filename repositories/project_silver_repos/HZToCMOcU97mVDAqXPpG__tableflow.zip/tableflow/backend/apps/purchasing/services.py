"""Purchasing services — submit, receive (full or partial), cancel."""
from __future__ import annotations

from decimal import Decimal

from django.db import transaction
from django.utils import timezone
from rest_framework.exceptions import ValidationError

from apps.inventory.services import post_transaction

from .models import PurchaseOrder, PurchaseOrderItem


def _recalc(po: PurchaseOrder) -> None:
    subtotal = sum(int(i.quantity_ordered * i.unit_cost_cents) for i in po.items.all())
    po.subtotal_cents = subtotal
    po.total_cents = subtotal + po.tax_cents
    po.save(update_fields=["subtotal_cents", "total_cents", "updated_at"])


@transaction.atomic
def submit(po: PurchaseOrder) -> PurchaseOrder:
    if po.status != "draft":
        raise ValidationError({"status": "only-draft-can-submit"})
    _recalc(po)
    po.status = "submitted"
    po.submitted_at = timezone.now()
    po.save(update_fields=["status", "submitted_at", "updated_at"])
    return po


@transaction.atomic
def receive(po: PurchaseOrder, *, lines: dict[str, Decimal], by=None) -> PurchaseOrder:
    """`lines`: {item_id: quantity_received_now}."""
    if po.status not in ("submitted", "partial"):
        raise ValidationError({"status": "not-receivable"})
    fully = True
    for item in po.items.select_related("ingredient"):
        delta = lines.get(str(item.id), Decimal("0"))
        if delta > 0:
            item.quantity_received = item.quantity_received + delta
            item.save(update_fields=["quantity_received"])
            post_transaction(
                ingredient=item.ingredient,
                kind="purchase",
                quantity_change=delta,
                unit_cost_cents=item.unit_cost_cents,
                purchase_order=po,
                by=by,
            )
        if item.quantity_received < item.quantity_ordered:
            fully = False
    po.status = "received" if fully else "partial"
    if fully:
        po.received_on = timezone.now().date()
    po.save(update_fields=["status", "received_on", "updated_at"])
    return po


@transaction.atomic
def cancel(po: PurchaseOrder) -> PurchaseOrder:
    if po.status in ("received", "cancelled"):
        raise ValidationError({"status": "cannot-cancel-now"})
    po.status = "cancelled"
    po.save(update_fields=["status", "updated_at"])
    return po
