from django.urls import path

from . import views

urlpatterns = [
    path("", views.PurchaseOrderList.as_view()),
    path("<uuid:pk>", views.PurchaseOrderDetail.as_view()),
    path("<uuid:pk>/submit", views.SubmitPOView.as_view()),
    path("<uuid:pk>/receive", views.ReceivePOView.as_view()),
    path("<uuid:pk>/cancel", views.CancelPOView.as_view()),
]
