import time

from apps.webhooks.sign import sign_payload, verify_signature


def test_round_trip_verifies():
    body = '{"event":"order.placed","data":{"id":"x"}}'
    sig = sign_payload(body, "whsec_test")
    assert verify_signature(body, sig, "whsec_test")


def test_tampered_payload_fails():
    sig = sign_payload('{"a":1}', "whsec_test")
    assert not verify_signature('{"a":2}', sig, "whsec_test")


def test_wrong_secret_fails():
    body = '{"a":1}'
    sig = sign_payload(body, "whsec_a")
    assert not verify_signature(body, sig, "whsec_b")


def test_stale_signature_outside_tolerance():
    body = "x"
    sig = sign_payload(body, "whsec_x", when=int(time.time()) - 600)
    assert not verify_signature(body, sig, "whsec_x", tolerance=300)
