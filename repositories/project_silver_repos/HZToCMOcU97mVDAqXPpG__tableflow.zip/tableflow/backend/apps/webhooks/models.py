"""Webhook subscriptions and delivery audit."""
from __future__ import annotations

import secrets
import uuid

from django.db import models


class WebhookEndpoint(models.Model):
    EVENT_CHOICES = [
        ("order.placed", "Order placed"),
        ("order.completed", "Order completed"),
        ("order.cancelled", "Order cancelled"),
        ("payment.captured", "Payment captured"),
        ("reservation.created", "Reservation created"),
        ("inventory.low", "Inventory low"),
    ]
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(db_index=True)
    url = models.URLField()
    events = models.JSONField(default=list)
    secret = models.CharField(max_length=64, default=secrets.token_urlsafe)
    paused_at = models.DateTimeField(null=True, blank=True)
    failure_count = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "webhook_endpoint"


class WebhookDelivery(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    endpoint = models.ForeignKey(WebhookEndpoint, on_delete=models.CASCADE, related_name="deliveries")
    event = models.CharField(max_length=64, db_index=True)
    payload = models.JSONField(default=dict)
    response_status = models.IntegerField(null=True, blank=True)
    response_body = models.TextField(blank=True)
    attempt = models.PositiveIntegerField(default=1)
    next_attempt_at = models.DateTimeField(null=True, blank=True)
    delivered_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "webhook_delivery"
        indexes = [models.Index(fields=["endpoint", "created_at"])]
