from django.urls import path

from . import views

urlpatterns = [
    path("", views.WebhookEndpointList.as_view()),
    path("<uuid:pk>", views.WebhookEndpointDetail.as_view()),
    path("deliveries", views.WebhookDeliveriesList.as_view()),
]
