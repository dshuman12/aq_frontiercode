from django.contrib import admin

from .models import WebhookDelivery, WebhookEndpoint


@admin.register(WebhookEndpoint)
class WebhookEndpointAdmin(admin.ModelAdmin):
    list_display = ("url", "events", "failure_count", "paused_at", "created_at")
    list_filter = ("paused_at",)
    search_fields = ("url",)


@admin.register(WebhookDelivery)
class WebhookDeliveryAdmin(admin.ModelAdmin):
    list_display = ("endpoint", "event", "response_status", "attempt", "delivered_at")
    list_filter = ("event", "response_status")
    readonly_fields = ("created_at", "next_attempt_at", "delivered_at")
