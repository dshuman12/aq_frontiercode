"""Outbound webhook delivery with HMAC signing + exponential backoff."""
from __future__ import annotations

import json
from datetime import timedelta

import requests
from celery import shared_task
from django.utils import timezone

from .models import WebhookDelivery, WebhookEndpoint
from .sign import sign_payload

MAX_ATTEMPTS = 8


@shared_task(bind=True, max_retries=MAX_ATTEMPTS)
def deliver_event(self, endpoint_id: str, event: str, payload: dict) -> dict:
    try:
        endpoint = WebhookEndpoint.objects.get(pk=endpoint_id)
    except WebhookEndpoint.DoesNotExist:
        return {"skipped": "endpoint-missing"}
    if endpoint.paused_at or event not in endpoint.events:
        return {"skipped": "not-subscribed"}

    body = json.dumps({"event": event, "data": payload}, separators=(",", ":"))
    sig = sign_payload(body, endpoint.secret)
    delivery = WebhookDelivery.objects.create(
        endpoint=endpoint, event=event, payload=payload, attempt=self.request.retries + 1,
    )
    try:
        resp = requests.post(
            endpoint.url,
            data=body,
            headers={
                "Content-Type": "application/json",
                "X-TableFlow-Signature": sig,
                "X-TableFlow-Event": event,
            },
            timeout=10,
        )
        delivery.response_status = resp.status_code
        delivery.response_body = resp.text[:1000]
        delivery.delivered_at = timezone.now()
        delivery.save()
        if 200 <= resp.status_code < 300:
            endpoint.failure_count = 0
            endpoint.save(update_fields=["failure_count"])
            return {"ok": True, "status": resp.status_code}
        raise RuntimeError(f"non-2xx: {resp.status_code}")
    except Exception as exc:
        endpoint.failure_count += 1
        if endpoint.failure_count >= MAX_ATTEMPTS:
            endpoint.paused_at = timezone.now()
        endpoint.save(update_fields=["failure_count", "paused_at"])
        delivery.next_attempt_at = timezone.now() + timedelta(seconds=2 ** (self.request.retries + 1))
        delivery.save()
        raise self.retry(exc=exc, countdown=2 ** (self.request.retries + 1))
