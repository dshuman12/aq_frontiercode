from rest_framework import generics, status
from rest_framework.response import Response

from apps.accounts.permissions import perm

from .models import WebhookDelivery, WebhookEndpoint
from .serializers import WebhookDeliverySerializer, WebhookEndpointSerializer


class WebhookEndpointList(generics.ListCreateAPIView):
    serializer_class = WebhookEndpointSerializer
    permission_classes = [perm("webhooks:read")]

    def get_queryset(self):  # type: ignore[override]
        return WebhookEndpoint.objects.filter(restaurant_id=self.request.restaurant_id)

    def perform_create(self, serializer):  # type: ignore[override]
        serializer.save(restaurant_id=self.request.restaurant_id)


class WebhookEndpointDetail(generics.RetrieveDestroyAPIView):
    serializer_class = WebhookEndpointSerializer
    permission_classes = [perm("webhooks:read")]

    def get_queryset(self):  # type: ignore[override]
        return WebhookEndpoint.objects.filter(restaurant_id=self.request.restaurant_id)


class WebhookDeliveriesList(generics.ListAPIView):
    serializer_class = WebhookDeliverySerializer
    permission_classes = [perm("webhooks:read")]
    ordering = ["-created_at"]

    def get_queryset(self):  # type: ignore[override]
        return WebhookDelivery.objects.filter(endpoint__restaurant_id=self.request.restaurant_id)
