"""HMAC-SHA256 signing for outbound webhook deliveries."""
from __future__ import annotations

import hashlib
import hmac
import time


def sign_payload(payload: bytes | str, secret: str, *, when: int | None = None) -> str:
    if isinstance(payload, str):
        payload = payload.encode()
    ts = when or int(time.time())
    body = f"{ts}.".encode() + payload
    sig = hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
    return f"t={ts},v1={sig}"


def verify_signature(payload: bytes | str, header: str, secret: str, *, tolerance: int = 300) -> bool:
    if isinstance(payload, str):
        payload = payload.encode()
    parts = dict(p.split("=", 1) for p in header.split(","))
    try:
        ts = int(parts["t"])
        v1 = parts["v1"]
    except (KeyError, ValueError):
        return False
    if abs(int(time.time()) - ts) > tolerance:
        return False
    body = f"{ts}.".encode() + payload
    expected = hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, v1)
