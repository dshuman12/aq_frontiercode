"""Edge cases for the PHI redactor."""
from apps.audit_logs.log_format import _redact


def test_redact_handles_none():
    assert _redact(None) is None


def test_redact_passes_numbers_through():
    assert _redact(123) == 123
    assert _redact(1.5) == 1.5


def test_redact_uppercase_credentials_keys():
    out = _redact({"Password": "x", "TOKEN": "y", "X": "ok"})
    # The redactor lowers keys before checking
    assert out["Password"] == "[redacted]"
    assert out["TOKEN"] == "[redacted]"
    assert out["X"] == "ok"


def test_redact_deeply_nested():
    out = _redact({"a": {"b": {"c": {"password": "hunter2", "ok": True}}}})
    assert out["a"]["b"]["c"]["password"] == "[redacted]"
    assert out["a"]["b"]["c"]["ok"] is True
