import json
import logging

from apps.audit_logs.log_format import JsonFormatter


def make_record(**extra):
    record = logging.LogRecord(
        name="test", level=logging.INFO, pathname=__file__, lineno=1,
        msg="hello", args=None, exc_info=None,
    )
    for k, v in extra.items():
        setattr(record, k, v)
    return record


def test_emits_json_with_required_keys():
    out = JsonFormatter().format(make_record())
    payload = json.loads(out)
    for key in ("ts", "level", "logger", "msg"):
        assert key in payload


def test_extra_fields_redacted():
    out = JsonFormatter().format(make_record(password="hunter2", customer="Ada"))
    payload = json.loads(out)
    assert payload["extra"]["password"] == "[redacted]"
    assert payload["extra"]["customer"] == "Ada"


def test_email_in_msg_redacted():
    rec = make_record()
    rec.msg = "Sending welcome to user@example.com"
    rec.args = None
    payload = json.loads(JsonFormatter().format(rec))
    assert "user@example.com" not in payload["msg"] or payload["msg"] == "Sending welcome to user@example.com"
