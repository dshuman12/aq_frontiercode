from rest_framework import generics

from apps.accounts.permissions import HasPermission, perm

from .models import AuditLog
from .serializers import AuditLogSerializer


class AuditLogListView(generics.ListAPIView):
    serializer_class = AuditLogSerializer
    permission_classes = [perm("audit:read")]
    filterset_fields = ["resource", "action", "actor"]
    search_fields = ["resource_id", "actor_email"]
    ordering = ["-created_at"]

    def get_queryset(self):  # type: ignore[override]
        return AuditLog.objects.filter(restaurant_id=self.request.restaurant_id)
