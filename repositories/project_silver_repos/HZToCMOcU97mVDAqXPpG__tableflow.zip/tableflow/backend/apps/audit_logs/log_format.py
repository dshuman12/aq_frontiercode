"""JSON log formatter that redacts PII / credentials before serialization."""
from __future__ import annotations

import json
import logging
import re
from datetime import datetime, timezone

REDACT_KEYS = {
    "password",
    "password_hash",
    "secret",
    "api_key",
    "apikey",
    "token",
    "refresh_token",
    "access_token",
    "ssn",
    "card_number",
    "cvv",
    "stripe_secret",
    "totp_secret",
}

EMAIL_RE = re.compile(r"([A-Za-z0-9_.+-]+)@([A-Za-z0-9.-]+\.[A-Za-z]{2,})")
PHONE_RE = re.compile(r"\b\d{3}[-.\s]?\d{3}[-.\s]?\d{4}\b")


def _redact(value):
    if isinstance(value, dict):
        return {k: ("[redacted]" if k.lower() in REDACT_KEYS else _redact(v)) for k, v in value.items()}
    if isinstance(value, list):
        return [_redact(v) for v in value]
    if isinstance(value, str):
        masked = EMAIL_RE.sub(lambda m: m.group(1)[:1] + "***@" + m.group(2), value)
        masked = PHONE_RE.sub("***-***-****", masked)
        return masked
    return value


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:  # type: ignore[override]
        payload = {
            "ts": datetime.fromtimestamp(record.created, tz=timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
        }
        if record.exc_info:
            payload["exc"] = self.formatException(record.exc_info)
        extras = {k: v for k, v in record.__dict__.items() if k not in {
            "args", "asctime", "created", "exc_info", "exc_text", "filename", "funcName",
            "levelname", "levelno", "lineno", "message", "module", "msecs", "msg", "name",
            "pathname", "process", "processName", "relativeCreated", "stack_info", "thread",
            "threadName", "taskName",
        }}
        if extras:
            payload["extra"] = _redact(extras)
        return json.dumps(payload, default=str)
