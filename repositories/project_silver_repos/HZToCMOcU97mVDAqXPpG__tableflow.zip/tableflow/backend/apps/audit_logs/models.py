"""AuditLog — append-only record of every privileged action."""
from __future__ import annotations

import uuid

from django.conf import settings
from django.db import models


class AuditLog(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(db_index=True)
    actor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name="audit_events")
    actor_email = models.CharField(max_length=255, blank=True)
    action = models.CharField(max_length=120, db_index=True)
    resource = models.CharField(max_length=64, db_index=True)
    resource_id = models.CharField(max_length=64, blank=True)
    ip = models.GenericIPAddressField(null=True, blank=True)
    user_agent = models.CharField(max_length=255, blank=True)
    request_id = models.CharField(max_length=64, blank=True)
    diff = models.JSONField(default=dict, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        db_table = "audit_logs"
        indexes = [
            models.Index(fields=["restaurant_id", "created_at"]),
            models.Index(fields=["restaurant_id", "resource", "resource_id"]),
        ]

    def __str__(self) -> str:
        return f"{self.action} {self.resource}/{self.resource_id}"
