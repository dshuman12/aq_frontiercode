"""Helper for emitting audit log entries."""
from __future__ import annotations

from typing import Any

from .models import AuditLog


def record(
    *,
    request,
    action: str,
    resource: str,
    resource_id: str = "",
    diff: dict[str, Any] | None = None,
) -> AuditLog:
    return AuditLog.objects.create(
        restaurant_id=getattr(request, "restaurant_id", None) or "00000000-0000-0000-0000-000000000000",
        actor=request.user if request.user.is_authenticated else None,
        actor_email=getattr(request.user, "email", "") or "",
        action=action,
        resource=resource,
        resource_id=str(resource_id),
        ip=getattr(request, "client_ip", None),
        user_agent=request.META.get("HTTP_USER_AGENT", "")[:255],
        request_id=getattr(request, "request_id", ""),
        diff=diff or {},
    )
