"""Attaches a per-request id and resolves the client IP."""
from __future__ import annotations

import secrets
from collections.abc import Callable

from django.http import HttpRequest, HttpResponse


class AuditContextMiddleware:
    def __init__(self, get_response: Callable[[HttpRequest], HttpResponse]):
        self.get_response = get_response

    def __call__(self, request: HttpRequest) -> HttpResponse:
        request.request_id = request.META.get("HTTP_X_REQUEST_ID") or secrets.token_hex(8)  # type: ignore[attr-defined]
        request.client_ip = (  # type: ignore[attr-defined]
            request.META.get("HTTP_X_FORWARDED_FOR", "").split(",")[0].strip()
            or request.META.get("REMOTE_ADDR")
        )
        response = self.get_response(request)
        response.headers["X-Request-Id"] = request.request_id  # type: ignore[attr-defined]
        return response
