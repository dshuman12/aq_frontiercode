from django.urls import path

from .consumers import DeliveryStreamConsumer

websocket_urlpatterns = [
    path("ws/delivery/<uuid:branch_id>", DeliveryStreamConsumer.as_asgi()),
]
