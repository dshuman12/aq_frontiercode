from django.contrib.auth import get_user_model
from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.accounts.permissions import perm

from . import services
from .models import DeliveryOrder, DeliveryZone
from .serializers import (
    AssignDriverSerializer,
    DeliveryOrderSerializer,
    DeliveryZoneSerializer,
    TransitionSerializer,
)

User = get_user_model()


class ZoneList(generics.ListCreateAPIView):
    serializer_class = DeliveryZoneSerializer
    permission_classes = [perm("delivery:read")]
    filterset_fields = ["branch", "is_active"]

    def get_queryset(self):  # type: ignore[override]
        return DeliveryZone.objects.filter(restaurant_id=self.request.restaurant_id)

    def perform_create(self, serializer):  # type: ignore[override]
        serializer.save(restaurant_id=self.request.restaurant_id)


class ZoneDetail(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = DeliveryZoneSerializer
    permission_classes = [perm("delivery:read")]

    def get_queryset(self):  # type: ignore[override]
        return DeliveryZone.objects.filter(restaurant_id=self.request.restaurant_id)


class DeliveryList(generics.ListAPIView):
    serializer_class = DeliveryOrderSerializer
    permission_classes = [perm("delivery:read")]
    filterset_fields = ["status"]
    ordering = ["-id"]

    def get_queryset(self):  # type: ignore[override]
        return DeliveryOrder.objects.filter(restaurant_id=self.request.restaurant_id).select_related("order", "zone")


class AssignView(APIView):
    permission_classes = [perm("delivery:assign")]

    def post(self, request, pk):
        delivery = DeliveryOrder.objects.get(pk=pk, restaurant_id=request.restaurant_id)
        serializer = AssignDriverSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        driver = User.objects.get(pk=serializer.validated_data["driver"])
        services.assign_driver(delivery=delivery, driver=driver, by=request.user)
        return Response(DeliveryOrderSerializer(delivery).data)


class TransitionView(APIView):
    permission_classes = [perm("delivery:transition")]

    def post(self, request, pk):
        delivery = DeliveryOrder.objects.get(pk=pk, restaurant_id=request.restaurant_id)
        serializer = TransitionSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        services.transition(
            delivery,
            to=serializer.validated_data["to"],
            by=request.user,
            note=serializer.validated_data.get("note", ""),
            lat=serializer.validated_data.get("latitude"),
            lng=serializer.validated_data.get("longitude"),
        )
        return Response(DeliveryOrderSerializer(delivery).data)


class ZoneLookupView(APIView):
    permission_classes = [perm("delivery:read")]

    def get(self, request):
        try:
            lat = float(request.query_params["lat"])
            lng = float(request.query_params["lng"])
            branch_id = request.query_params["branch"]
        except (KeyError, ValueError):
            return Response({"detail": "missing-params"}, status=status.HTTP_400_BAD_REQUEST)
        zone = services.find_zone_for_point(
            restaurant_id=request.restaurant_id, branch=branch_id, lat=lat, lng=lng
        )
        return Response({"zone": DeliveryZoneSerializer(zone).data if zone else None})
