"""Celery tasks for delivery."""
from __future__ import annotations

from celery import shared_task

from .models import DeliveryOrder


@shared_task
def push_delivery_eta(delivery_id: str) -> dict:
    try:
        d = DeliveryOrder.objects.get(pk=delivery_id)
    except DeliveryOrder.DoesNotExist:
        return {"skipped": "missing"}
    from apps.notifications.tasks import send_delivery_eta_update

    send_delivery_eta_update.delay(str(d.id))
    return {"queued": True}
