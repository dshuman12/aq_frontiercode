from apps.delivery.services import point_in_polygon


def test_concave_polygon_recognized():
    """A C-shape; point inside the notch should not register as inside."""
    poly = [
        [0, 0], [0, 10], [10, 10], [10, 6], [4, 6], [4, 4], [10, 4], [10, 0],
    ]
    assert not point_in_polygon((6, 5), poly)
    assert point_in_polygon((1, 5), poly)


def test_point_on_boundary_is_implementation_defined():
    """Ray-cast can flicker on boundary; just assert deterministic behavior."""
    poly = [[0, 0], [0, 10], [10, 10], [10, 0]]
    a = point_in_polygon((0, 0), poly)
    b = point_in_polygon((0, 0), poly)
    assert a == b


def test_polygon_with_only_two_points_returns_false():
    assert not point_in_polygon((1, 1), [[0, 0], [1, 1]])
