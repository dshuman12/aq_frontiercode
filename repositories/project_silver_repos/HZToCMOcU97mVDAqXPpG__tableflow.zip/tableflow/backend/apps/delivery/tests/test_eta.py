"""ETA windowing for delivery."""
from datetime import datetime, timedelta


def projected_arrival(picked_up_at, eta_minutes):
    return picked_up_at + timedelta(minutes=eta_minutes)


def is_overdue(now, picked_up_at, eta_minutes, slack=5):
    if not picked_up_at:
        return False
    return now > projected_arrival(picked_up_at, eta_minutes + slack)


def test_arrival_within_window_not_overdue():
    pickup = datetime(2024, 8, 15, 18, 0)
    now = datetime(2024, 8, 15, 18, 25)
    assert not is_overdue(now, pickup, eta_minutes=30)


def test_arrival_past_eta_plus_slack_is_overdue():
    pickup = datetime(2024, 8, 15, 18, 0)
    now = datetime(2024, 8, 15, 18, 40)
    assert is_overdue(now, pickup, eta_minutes=30)


def test_no_pickup_means_not_overdue():
    now = datetime(2024, 8, 15, 18, 0)
    assert not is_overdue(now, None, eta_minutes=30)


def test_projected_arrival_basic():
    out = projected_arrival(datetime(2024, 8, 15, 18, 0), 25)
    assert out == datetime(2024, 8, 15, 18, 25)
