from apps.delivery.services import can_transition, point_in_polygon


def test_point_inside_square():
    poly = [[0, 0], [0, 10], [10, 10], [10, 0]]
    assert point_in_polygon((5, 5), poly)


def test_point_outside_square():
    poly = [[0, 0], [0, 10], [10, 10], [10, 0]]
    assert not point_in_polygon((20, 20), poly)


def test_empty_polygon_returns_false():
    assert not point_in_polygon((1, 1), [])
    assert not point_in_polygon((1, 1), [[0, 0], [1, 0]])


def test_transition_paths():
    assert can_transition("pending", "assigned")
    assert can_transition("assigned", "picked_up")
    assert can_transition("picked_up", "delivering")
    assert can_transition("delivering", "delivered")
    assert not can_transition("delivered", "delivering")
    assert not can_transition("pending", "delivered")
