from django.urls import path

from . import views

urlpatterns = [
    path("", views.DeliveryList.as_view()),
    path("<uuid:pk>/assign", views.AssignView.as_view()),
    path("<uuid:pk>/transition", views.TransitionView.as_view()),
    path("zones", views.ZoneList.as_view()),
    path("zones/<uuid:pk>", views.ZoneDetail.as_view()),
    path("zone-lookup", views.ZoneLookupView.as_view()),
]
