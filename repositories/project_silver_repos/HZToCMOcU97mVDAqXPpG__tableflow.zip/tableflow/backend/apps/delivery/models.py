"""DeliveryZone, DeliveryOrder, DeliveryDriverAssignment, DeliveryStatusHistory."""
from __future__ import annotations

import uuid

from django.conf import settings
from django.db import models


class DeliveryZone(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(db_index=True)
    branch = models.ForeignKey("branches.Branch", on_delete=models.CASCADE, related_name="delivery_zones")
    name = models.CharField(max_length=80)
    fee_cents = models.PositiveIntegerField(default=0)
    minimum_order_cents = models.PositiveIntegerField(default=0)
    eta_minutes = models.PositiveSmallIntegerField(default=30)
    polygon = models.JSONField(default=list)  # list of [lat, lng] pairs
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = "delivery_zone"


class DeliveryOrder(models.Model):
    STATUS_CHOICES = [
        ("pending", "Pending"),
        ("assigned", "Assigned"),
        ("picked_up", "Picked up"),
        ("delivering", "Delivering"),
        ("delivered", "Delivered"),
        ("failed", "Failed"),
        ("cancelled", "Cancelled"),
    ]
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(db_index=True)
    order = models.OneToOneField("orders.Order", on_delete=models.CASCADE, related_name="delivery")
    zone = models.ForeignKey(DeliveryZone, null=True, blank=True, on_delete=models.SET_NULL, related_name="deliveries")
    address = models.ForeignKey("customers.CustomerAddress", null=True, blank=True, on_delete=models.SET_NULL)
    address_text = models.CharField(max_length=300, blank=True)
    instructions = models.CharField(max_length=300, blank=True)
    contactless = models.BooleanField(default=False)
    status = models.CharField(max_length=12, choices=STATUS_CHOICES, default="pending", db_index=True)
    eta_minutes = models.PositiveSmallIntegerField(default=30)
    fee_cents = models.PositiveIntegerField(default=0)
    pickup_at = models.DateTimeField(null=True, blank=True)
    delivered_at = models.DateTimeField(null=True, blank=True)
    failed_reason = models.CharField(max_length=300, blank=True)
    proof_file = models.ForeignKey("files.FileAsset", null=True, blank=True, on_delete=models.SET_NULL)
    customer_phone = models.CharField(max_length=32, blank=True)
    customer_name = models.CharField(max_length=120, blank=True)

    class Meta:
        db_table = "delivery_order"
        indexes = [models.Index(fields=["restaurant_id", "status", "pickup_at"])]


class DeliveryDriverAssignment(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    delivery = models.ForeignKey(DeliveryOrder, on_delete=models.CASCADE, related_name="driver_assignments")
    driver = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="delivery_jobs")
    assigned_at = models.DateTimeField(auto_now_add=True)
    accepted_at = models.DateTimeField(null=True, blank=True)
    released_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "delivery_driver_assignment"


class DeliveryStatusHistory(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    delivery = models.ForeignKey(DeliveryOrder, on_delete=models.CASCADE, related_name="status_history")
    previous_status = models.CharField(max_length=12, blank=True)
    new_status = models.CharField(max_length=12)
    changed_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL)
    changed_at = models.DateTimeField(auto_now_add=True)
    note = models.CharField(max_length=200, blank=True)
    latitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    longitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)

    class Meta:
        db_table = "delivery_status_history"
        ordering = ["-changed_at"]
