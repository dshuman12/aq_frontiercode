from django.apps import AppConfig


class DeliveryConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.delivery"

    def ready(self) -> None:
        from . import signals  # noqa: F401
