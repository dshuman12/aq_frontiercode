"""Push delivery status changes to the realtime group."""
from __future__ import annotations

from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer
from django.db.models.signals import post_save
from django.dispatch import receiver

from .models import DeliveryStatusHistory


@receiver(post_save, sender=DeliveryStatusHistory)
def broadcast_delivery(sender, instance: DeliveryStatusHistory, created: bool, **kwargs):
    if not created:
        return
    layer = get_channel_layer()
    if layer is None:
        return
    branch_id = instance.delivery.order.branch_id
    payload = {
        "kind": "transition",
        "delivery_id": str(instance.delivery_id),
        "from": instance.previous_status,
        "to": instance.new_status,
        "lat": str(instance.latitude) if instance.latitude is not None else None,
        "lng": str(instance.longitude) if instance.longitude is not None else None,
    }
    async_to_sync(layer.group_send)(f"delivery.{branch_id}", {"type": "delivery.event", "payload": payload})
