from django.contrib import admin

from .models import DeliveryDriverAssignment, DeliveryOrder, DeliveryStatusHistory, DeliveryZone


@admin.register(DeliveryOrder)
class DeliveryOrderAdmin(admin.ModelAdmin):
    list_display = ("order", "status", "eta_minutes", "fee_cents", "delivered_at")
    list_filter = ("status",)


@admin.register(DeliveryZone)
class DeliveryZoneAdmin(admin.ModelAdmin):
    list_display = ("name", "branch", "fee_cents", "minimum_order_cents", "is_active")
    list_filter = ("is_active", "branch")


admin.site.register([DeliveryDriverAssignment, DeliveryStatusHistory])
