from channels.generic.websocket import AsyncJsonWebsocketConsumer


class DeliveryStreamConsumer(AsyncJsonWebsocketConsumer):
    async def connect(self):
        self.branch_id = self.scope["url_route"]["kwargs"]["branch_id"]
        self.group_name = f"delivery.{self.branch_id}"
        if self.scope.get("user") and self.scope["user"].is_authenticated:
            await self.channel_layer.group_add(self.group_name, self.channel_name)
            await self.accept()
        else:
            await self.close()

    async def disconnect(self, code):
        await self.channel_layer.group_discard(self.group_name, self.channel_name)

    async def delivery_event(self, event):
        await self.send_json(event["payload"])
