from rest_framework import serializers

from .models import (
    DeliveryDriverAssignment,
    DeliveryOrder,
    DeliveryStatusHistory,
    DeliveryZone,
)


class DeliveryZoneSerializer(serializers.ModelSerializer):
    class Meta:
        model = DeliveryZone
        fields = "__all__"
        read_only_fields = ["id", "restaurant_id"]


class DeliveryOrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = DeliveryOrder
        fields = "__all__"
        read_only_fields = ["id", "restaurant_id", "status", "pickup_at", "delivered_at"]


class DeliveryStatusHistorySerializer(serializers.ModelSerializer):
    class Meta:
        model = DeliveryStatusHistory
        fields = "__all__"


class AssignDriverSerializer(serializers.Serializer):
    driver = serializers.UUIDField()


class TransitionSerializer(serializers.Serializer):
    to = serializers.ChoiceField(choices=[c[0] for c in DeliveryOrder.STATUS_CHOICES])
    note = serializers.CharField(required=False, allow_blank=True, max_length=200)
    latitude = serializers.DecimalField(max_digits=9, decimal_places=6, required=False, allow_null=True)
    longitude = serializers.DecimalField(max_digits=9, decimal_places=6, required=False, allow_null=True)
