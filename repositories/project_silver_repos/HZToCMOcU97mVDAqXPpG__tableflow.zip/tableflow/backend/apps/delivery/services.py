"""Delivery state machine + driver assignment."""
from __future__ import annotations

from django.db import transaction
from django.utils import timezone
from rest_framework.exceptions import ValidationError

from .models import DeliveryDriverAssignment, DeliveryOrder, DeliveryStatusHistory

TRANSITIONS = {
    "pending": ["assigned", "cancelled"],
    "assigned": ["picked_up", "cancelled"],
    "picked_up": ["delivering", "failed", "cancelled"],
    "delivering": ["delivered", "failed"],
    "delivered": [],
    "failed": [],
    "cancelled": [],
}


def can_transition(a: str, b: str) -> bool:
    return b in TRANSITIONS.get(a, [])


@transaction.atomic
def transition(delivery: DeliveryOrder, *, to: str, by, note: str = "", lat=None, lng=None) -> DeliveryOrder:
    if not can_transition(delivery.status, to):
        raise ValidationError({"status": f"illegal:{delivery.status}->{to}"})
    DeliveryStatusHistory.objects.create(
        delivery=delivery,
        previous_status=delivery.status,
        new_status=to,
        changed_by=by if getattr(by, "is_authenticated", False) else None,
        note=note,
        latitude=lat,
        longitude=lng,
    )
    delivery.status = to
    now = timezone.now()
    if to == "picked_up":
        delivery.pickup_at = now
    elif to == "delivered":
        delivery.delivered_at = now
    delivery.save()
    return delivery


@transaction.atomic
def assign_driver(*, delivery: DeliveryOrder, driver, by=None) -> DeliveryDriverAssignment:
    DeliveryDriverAssignment.objects.filter(delivery=delivery, released_at__isnull=True).update(released_at=timezone.now())
    assignment = DeliveryDriverAssignment.objects.create(delivery=delivery, driver=driver)
    if delivery.status == "pending":
        transition(delivery, to="assigned", by=by, note=f"Assigned to {driver.email}")
    return assignment


def point_in_polygon(point: tuple[float, float], polygon: list[list[float]]) -> bool:
    """Ray-cast algorithm for [lat,lng] polygon."""
    if not polygon or len(polygon) < 3:
        return False
    x, y = point
    inside = False
    j = len(polygon) - 1
    for i in range(len(polygon)):
        xi, yi = polygon[i][0], polygon[i][1]
        xj, yj = polygon[j][0], polygon[j][1]
        if ((yi > y) != (yj > y)) and (x < (xj - xi) * (y - yi) / ((yj - yi) or 1e-12) + xi):
            inside = not inside
        j = i
    return inside


def find_zone_for_point(*, restaurant_id, branch, lat: float, lng: float) -> "DeliveryZone | None":
    from .models import DeliveryZone
    for zone in DeliveryZone.objects.filter(restaurant_id=restaurant_id, branch=branch, is_active=True):
        if point_in_polygon((lat, lng), zone.polygon):
            return zone
    return None
