"""Modifier groups, modifier options, combo meals."""
from __future__ import annotations

import uuid

from django.db import models


class ModifierGroup(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(db_index=True)
    name = models.CharField(max_length=120)
    is_required = models.BooleanField(default=False)
    min_select = models.PositiveSmallIntegerField(default=0)
    max_select = models.PositiveSmallIntegerField(default=1)
    is_archived = models.BooleanField(default=False)
    items = models.ManyToManyField("menus.MenuItem", related_name="modifier_groups", blank=True)

    class Meta:
        db_table = "modifier_group"
        ordering = ["name"]


class ModifierOption(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    group = models.ForeignKey(ModifierGroup, on_delete=models.CASCADE, related_name="options")
    name = models.CharField(max_length=120)
    price_delta_cents = models.IntegerField(default=0)
    is_default = models.BooleanField(default=False)
    is_available = models.BooleanField(default=True)
    sort_order = models.PositiveIntegerField(default=0)

    class Meta:
        db_table = "modifier_option"
        ordering = ["sort_order"]


class ComboMeal(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(db_index=True)
    name = models.CharField(max_length=120)
    base_price_cents = models.PositiveIntegerField(default=0)
    is_active = models.BooleanField(default=True)
    description = models.CharField(max_length=200, blank=True)
    items = models.ManyToManyField("menus.MenuItem", through="ComboMealItem", related_name="combos")

    class Meta:
        db_table = "combo_meal"


class ComboMealItem(models.Model):
    combo = models.ForeignKey(ComboMeal, on_delete=models.CASCADE)
    item = models.ForeignKey("menus.MenuItem", on_delete=models.PROTECT)
    quantity = models.PositiveSmallIntegerField(default=1)
    is_required = models.BooleanField(default=True)

    class Meta:
        db_table = "combo_meal_item"
        unique_together = ("combo", "item")
