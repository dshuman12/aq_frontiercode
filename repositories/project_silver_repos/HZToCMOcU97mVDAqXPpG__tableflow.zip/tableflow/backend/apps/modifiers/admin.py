from django.contrib import admin

from .models import ComboMeal, ComboMealItem, ModifierGroup, ModifierOption


class ModifierOptionInline(admin.TabularInline):
    model = ModifierOption
    extra = 1


@admin.register(ModifierGroup)
class ModifierGroupAdmin(admin.ModelAdmin):
    list_display = ("name", "is_required", "min_select", "max_select", "is_archived")
    list_filter = ("is_required", "is_archived")
    inlines = [ModifierOptionInline]


admin.site.register([ComboMeal, ComboMealItem])
