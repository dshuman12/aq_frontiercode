from rest_framework import serializers

from .models import ComboMeal, ComboMealItem, ModifierGroup, ModifierOption


class ModifierOptionSerializer(serializers.ModelSerializer):
    class Meta:
        model = ModifierOption
        fields = "__all__"
        read_only_fields = ["id"]


class ModifierGroupSerializer(serializers.ModelSerializer):
    options = ModifierOptionSerializer(many=True, read_only=True)

    class Meta:
        model = ModifierGroup
        fields = "__all__"
        read_only_fields = ["id", "restaurant_id"]


class ComboMealItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = ComboMealItem
        fields = "__all__"


class ComboMealSerializer(serializers.ModelSerializer):
    items_through = ComboMealItemSerializer(source="combomealitem_set", many=True, read_only=True)

    class Meta:
        model = ComboMeal
        fields = "__all__"
        read_only_fields = ["id", "restaurant_id"]
