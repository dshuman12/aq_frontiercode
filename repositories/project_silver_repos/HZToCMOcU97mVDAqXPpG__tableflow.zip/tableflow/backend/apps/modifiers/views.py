from rest_framework import generics
from rest_framework.exceptions import ValidationError

from apps.accounts.permissions import perm

from .models import ComboMeal, ModifierGroup, ModifierOption
from .serializers import ComboMealSerializer, ModifierGroupSerializer, ModifierOptionSerializer


def _validate_group_select_bounds(group: ModifierGroup) -> None:
    if group.min_select > group.max_select:
        raise ValidationError({"min_select": "must be <= max_select"})


class GroupList(generics.ListCreateAPIView):
    serializer_class = ModifierGroupSerializer
    permission_classes = [perm("modifiers:read")]

    def get_queryset(self):  # type: ignore[override]
        return ModifierGroup.objects.filter(restaurant_id=self.request.restaurant_id, is_archived=False).prefetch_related("options")

    def perform_create(self, serializer):  # type: ignore[override]
        instance: ModifierGroup = serializer.save(restaurant_id=self.request.restaurant_id)
        _validate_group_select_bounds(instance)


class GroupDetail(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = ModifierGroupSerializer
    permission_classes = [perm("modifiers:read")]

    def get_queryset(self):  # type: ignore[override]
        return ModifierGroup.objects.filter(restaurant_id=self.request.restaurant_id)

    def perform_destroy(self, instance):  # type: ignore[override]
        instance.is_archived = True
        instance.save(update_fields=["is_archived"])


class OptionList(generics.ListCreateAPIView):
    serializer_class = ModifierOptionSerializer
    permission_classes = [perm("modifiers:read")]
    filterset_fields = ["group", "is_available"]

    def get_queryset(self):  # type: ignore[override]
        return ModifierOption.objects.filter(group__restaurant_id=self.request.restaurant_id)


class OptionDetail(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = ModifierOptionSerializer
    permission_classes = [perm("modifiers:update")]

    def get_queryset(self):  # type: ignore[override]
        return ModifierOption.objects.filter(group__restaurant_id=self.request.restaurant_id)


class ComboList(generics.ListCreateAPIView):
    serializer_class = ComboMealSerializer
    permission_classes = [perm("menu:read")]

    def get_queryset(self):  # type: ignore[override]
        return ComboMeal.objects.filter(restaurant_id=self.request.restaurant_id)

    def perform_create(self, serializer):  # type: ignore[override]
        serializer.save(restaurant_id=self.request.restaurant_id)


class ComboDetail(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = ComboMealSerializer
    permission_classes = [perm("menu:read")]

    def get_queryset(self):  # type: ignore[override]
        return ComboMeal.objects.filter(restaurant_id=self.request.restaurant_id)
