from django.urls import path

from . import views

urlpatterns = [
    path("groups", views.GroupList.as_view()),
    path("groups/<uuid:pk>", views.GroupDetail.as_view()),
    path("options", views.OptionList.as_view()),
    path("options/<uuid:pk>", views.OptionDetail.as_view()),
    path("combos", views.ComboList.as_view()),
    path("combos/<uuid:pk>", views.ComboDetail.as_view()),
]
