"""Even-split helper for splitting an order into N parts of equal value."""
from __future__ import annotations


def even_split_cents(total_cents: int, n: int) -> list[int]:
    """Split N ways. Returns N integers that sum to total_cents.

    The first `total % n` parts each get +1 cent so the sum is exact.
    """
    if n <= 0:
        raise ValueError("n must be positive")
    base, extra = divmod(total_cents, n)
    return [base + (1 if i < extra else 0) for i in range(n)]


def by_seat_split(line_totals: list[int], assignments: list[int]) -> dict[int, int]:
    """Sum line totals by seat assignment. `assignments[i]` is the seat for line i."""
    if len(line_totals) != len(assignments):
        raise ValueError("length-mismatch")
    out: dict[int, int] = {}
    for amount, seat in zip(line_totals, assignments, strict=True):
        out[seat] = out.get(seat, 0) + amount
    return out
