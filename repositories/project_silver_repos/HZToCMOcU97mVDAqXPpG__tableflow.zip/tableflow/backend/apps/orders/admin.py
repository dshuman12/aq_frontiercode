from django.contrib import admin

from .models import Order, OrderItem, OrderItemModifier, OrderStatusHistory


class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 0
    readonly_fields = ("name_snapshot", "line_total_cents", "created_at")


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ("number", "kind", "status", "branch", "total_cents", "created_at")
    list_filter = ("status", "kind", "branch")
    search_fields = ("number",)
    inlines = [OrderItemInline]
    readonly_fields = ("subtotal_cents", "tax_cents", "service_charge_cents", "total_cents")


admin.site.register([OrderItem, OrderItemModifier, OrderStatusHistory])
