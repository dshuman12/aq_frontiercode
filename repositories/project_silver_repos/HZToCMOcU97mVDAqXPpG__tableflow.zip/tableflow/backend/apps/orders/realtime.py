"""Helpers to publish order events into the Channels group."""
from __future__ import annotations

from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer


def publish_order_event(order, kind: str, **extra) -> None:
    layer = get_channel_layer()
    if layer is None:
        return
    async_to_sync(layer.group_send)(
        f"orders.{order.branch_id}",
        {
            "type": "order.event",
            "payload": {
                "kind": kind,
                "order_id": str(order.id),
                "number": order.number,
                "status": order.status,
                **extra,
            },
        },
    )
