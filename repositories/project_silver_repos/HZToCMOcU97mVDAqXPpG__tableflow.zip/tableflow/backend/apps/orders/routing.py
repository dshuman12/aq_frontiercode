from django.urls import path

from .consumers import OrderStreamConsumer

websocket_urlpatterns = [
    path("ws/orders/<uuid:branch_id>", OrderStreamConsumer.as_asgi()),
]
