"""Order, OrderItem, OrderItemModifier, OrderStatusHistory."""
from __future__ import annotations

import uuid

from django.conf import settings
from django.db import models


class Order(models.Model):
    KIND_CHOICES = [
        ("dine_in", "Dine-in"),
        ("takeout", "Takeout"),
        ("delivery", "Delivery"),
        ("online", "Online"),
        ("qr", "QR table"),
    ]
    STATUS_CHOICES = [
        ("draft", "Draft"),
        ("placed", "Placed"),
        ("accepted", "Accepted"),
        ("preparing", "Preparing"),
        ("ready", "Ready"),
        ("served", "Served"),
        ("out_for_delivery", "Out for delivery"),
        ("completed", "Completed"),
        ("cancelled", "Cancelled"),
        ("refunded", "Refunded"),
    ]
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(db_index=True)
    branch = models.ForeignKey("branches.Branch", on_delete=models.PROTECT, related_name="orders")
    number = models.CharField(max_length=24, db_index=True)  # e.g. "ORD-A1B2"
    kind = models.CharField(max_length=12, choices=KIND_CHOICES, default="dine_in")
    table = models.ForeignKey("tables.RestaurantTable", null=True, blank=True, on_delete=models.SET_NULL, related_name="orders")
    customer = models.ForeignKey("customers.Customer", null=True, blank=True, on_delete=models.SET_NULL, related_name="orders")
    server = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="served_orders")
    cashier = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="cashed_orders")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="draft", db_index=True)
    notes = models.CharField(max_length=500, blank=True)
    party_size = models.PositiveSmallIntegerField(default=1)
    coupon = models.ForeignKey("coupons.Coupon", null=True, blank=True, on_delete=models.SET_NULL, related_name="orders")

    # Money rollups (cents)
    subtotal_cents = models.PositiveIntegerField(default=0)
    discount_cents = models.PositiveIntegerField(default=0)
    tax_cents = models.PositiveIntegerField(default=0)
    service_charge_cents = models.PositiveIntegerField(default=0)
    delivery_fee_cents = models.PositiveIntegerField(default=0)
    tip_cents = models.PositiveIntegerField(default=0)
    total_cents = models.PositiveIntegerField(default=0)
    paid_cents = models.PositiveIntegerField(default=0)
    refund_cents = models.PositiveIntegerField(default=0)

    placed_at = models.DateTimeField(null=True, blank=True)
    accepted_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    cancelled_at = models.DateTimeField(null=True, blank=True)
    cancelled_reason = models.CharField(max_length=200, blank=True)
    parent_order = models.ForeignKey("self", null=True, blank=True, on_delete=models.SET_NULL, related_name="split_children")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "orders_order"
        unique_together = ("restaurant_id", "number")
        indexes = [
            models.Index(fields=["restaurant_id", "branch", "status", "created_at"]),
            models.Index(fields=["restaurant_id", "kind", "created_at"]),
        ]

    def __str__(self) -> str:
        return self.number

    @property
    def balance_cents(self) -> int:
        return max(0, self.total_cents - self.paid_cents)


class OrderItem(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="items")
    menu_item = models.ForeignKey("menus.MenuItem", on_delete=models.PROTECT, related_name="ordered_as")
    variant = models.ForeignKey("menus.MenuItemVariant", null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    name_snapshot = models.CharField(max_length=200)
    base_price_cents = models.PositiveIntegerField(default=0)
    variant_delta_cents = models.IntegerField(default=0)
    quantity = models.PositiveSmallIntegerField(default=1)
    line_total_cents = models.PositiveIntegerField(default=0)
    note = models.CharField(max_length=300, blank=True)
    is_voided = models.BooleanField(default=False)
    voided_reason = models.CharField(max_length=200, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "orders_order_item"
        ordering = ["created_at"]


class OrderItemModifier(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    item = models.ForeignKey(OrderItem, on_delete=models.CASCADE, related_name="modifiers")
    option = models.ForeignKey("modifiers.ModifierOption", on_delete=models.PROTECT, related_name="+")
    name_snapshot = models.CharField(max_length=200)
    price_delta_cents = models.IntegerField(default=0)

    class Meta:
        db_table = "orders_order_item_modifier"


class OrderStatusHistory(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="status_history")
    previous_status = models.CharField(max_length=20, blank=True)
    new_status = models.CharField(max_length=20)
    changed_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL)
    changed_at = models.DateTimeField(auto_now_add=True)
    note = models.CharField(max_length=200, blank=True)

    class Meta:
        db_table = "orders_status_history"
        ordering = ["-changed_at"]
