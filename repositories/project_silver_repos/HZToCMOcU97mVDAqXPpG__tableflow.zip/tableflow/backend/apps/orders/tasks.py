"""Order-related Celery tasks."""
from __future__ import annotations

from celery import shared_task

from .models import Order


@shared_task
def send_order_confirmation(order_id: str) -> dict:
    try:
        order = Order.objects.get(pk=order_id)
    except Order.DoesNotExist:
        return {"skipped": "missing"}
    from apps.notifications.tasks import send_order_confirmation_email

    send_order_confirmation_email.delay(order_id)
    return {"queued": True, "number": order.number}


@shared_task
def fanout_kitchen_tickets(order_id: str) -> dict:
    """When an order is accepted, fan out its items to kitchen stations."""
    from apps.kitchen.services import build_tickets_for_order

    return build_tickets_for_order(order_id)
