"""Order services — create/add/transition/split."""
from __future__ import annotations

from typing import Any

from django.db import transaction
from django.utils import timezone
from rest_framework.exceptions import ValidationError

from apps.menus.pricing import LineItemSpec, line_item_total_cents

from .models import Order, OrderItem, OrderItemModifier, OrderStatusHistory
from .numbering import generate_number
from .transitions import can_transition


@transaction.atomic
def create_order(*, restaurant_id, branch, kind: str = "dine_in", table=None, customer=None, server=None, party_size: int = 1) -> Order:
    number = generate_number()
    while Order.objects.filter(restaurant_id=restaurant_id, number=number).exists():
        number = generate_number()
    return Order.objects.create(
        restaurant_id=restaurant_id,
        branch=branch,
        kind=kind,
        number=number,
        table=table,
        customer=customer,
        server=server,
        party_size=party_size,
    )


@transaction.atomic
def add_item(*, order: Order, menu_item, variant=None, quantity: int = 1, modifier_options=(), note: str = "") -> OrderItem:
    if order.status not in ("draft", "placed", "accepted", "preparing"):
        raise ValidationError({"order": "cannot-add-after-ready"})
    base = menu_item.base_price_cents
    variant_delta = variant.price_delta_cents if variant else 0
    spec = LineItemSpec(
        base_price_cents=base,
        variant_delta_cents=variant_delta,
        modifier_options=tuple(o.price_delta_cents for o in modifier_options),
        quantity=quantity,
    )
    line_total = line_item_total_cents(spec)
    item = OrderItem.objects.create(
        order=order,
        menu_item=menu_item,
        variant=variant,
        name_snapshot=menu_item.name + (f" — {variant.name}" if variant else ""),
        base_price_cents=base,
        variant_delta_cents=variant_delta,
        quantity=quantity,
        line_total_cents=line_total,
        note=note,
    )
    for opt in modifier_options:
        OrderItemModifier.objects.create(
            item=item,
            option=opt,
            name_snapshot=opt.name,
            price_delta_cents=opt.price_delta_cents,
        )
    recalculate_totals(order)
    return item


@transaction.atomic
def void_item(*, item: OrderItem, reason: str = "") -> OrderItem:
    item.is_voided = True
    item.voided_reason = reason
    item.line_total_cents = 0
    item.save(update_fields=["is_voided", "voided_reason", "line_total_cents"])
    recalculate_totals(item.order)
    return item


def recalculate_totals(order: Order) -> Order:
    """Roll up subtotal + tax + service charge + discount + delivery fee + tip."""
    items = order.items.filter(is_voided=False)
    subtotal = sum((i.line_total_cents for i in items), 0)
    discount = order.discount_cents
    after_discount = max(0, subtotal - discount)
    # tax/service charge from the restaurant settings — caller may also override
    from apps.restaurants.models import Restaurant

    r = Restaurant.objects.only("tax_rate", "service_charge_rate").get(pk=order.restaurant_id)
    tax = int(round(after_discount * float(r.tax_rate)))
    service = int(round(after_discount * float(r.service_charge_rate)))
    total = after_discount + tax + service + order.delivery_fee_cents + order.tip_cents
    order.subtotal_cents = subtotal
    order.tax_cents = tax
    order.service_charge_cents = service
    order.total_cents = total
    order.save(update_fields=["subtotal_cents", "tax_cents", "service_charge_cents", "total_cents", "updated_at"])
    return order


@transaction.atomic
def transition(order: Order, *, to_status: str, by, note: str = "") -> Order:
    if not can_transition(order.status, to_status):
        raise ValidationError({"status": f"illegal-transition:{order.status}->{to_status}"})
    OrderStatusHistory.objects.create(
        order=order,
        previous_status=order.status,
        new_status=to_status,
        changed_by=by if getattr(by, "is_authenticated", False) else None,
        note=note,
    )
    order.status = to_status
    now = timezone.now()
    if to_status == "placed":
        order.placed_at = now
    elif to_status == "accepted":
        order.accepted_at = now
    elif to_status == "completed":
        order.completed_at = now
    elif to_status == "cancelled":
        order.cancelled_at = now
    order.save()
    return order


@transaction.atomic
def split_order(*, order: Order, item_ids: list[str]) -> Order:
    """Move a subset of items into a new child order."""
    items = list(order.items.filter(pk__in=item_ids, is_voided=False))
    if not items:
        raise ValidationError({"items": "no-items-selected"})
    child = create_order(
        restaurant_id=order.restaurant_id,
        branch=order.branch,
        kind=order.kind,
        table=order.table,
        customer=order.customer,
        server=order.server,
        party_size=order.party_size,
    )
    child.parent_order = order
    child.save(update_fields=["parent_order"])
    for it in items:
        it.order = child
        it.save(update_fields=["order"])
    recalculate_totals(order)
    recalculate_totals(child)
    return child
