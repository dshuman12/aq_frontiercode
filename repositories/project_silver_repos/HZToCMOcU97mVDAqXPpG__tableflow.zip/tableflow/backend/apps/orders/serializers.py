from rest_framework import serializers

from .models import Order, OrderItem, OrderItemModifier, OrderStatusHistory


class OrderItemModifierSerializer(serializers.ModelSerializer):
    class Meta:
        model = OrderItemModifier
        fields = "__all__"


class OrderItemSerializer(serializers.ModelSerializer):
    modifiers = OrderItemModifierSerializer(many=True, read_only=True)

    class Meta:
        model = OrderItem
        fields = "__all__"
        read_only_fields = ["id", "order", "name_snapshot", "line_total_cents", "created_at"]


class OrderStatusHistorySerializer(serializers.ModelSerializer):
    class Meta:
        model = OrderStatusHistory
        fields = "__all__"


class OrderSerializer(serializers.ModelSerializer):
    items = OrderItemSerializer(many=True, read_only=True)
    balance_cents = serializers.IntegerField(read_only=True)

    class Meta:
        model = Order
        fields = "__all__"
        read_only_fields = [
            "id", "restaurant_id", "number", "status", "subtotal_cents", "tax_cents",
            "service_charge_cents", "total_cents", "paid_cents", "refund_cents",
            "balance_cents", "placed_at", "accepted_at", "completed_at", "cancelled_at",
            "created_at", "updated_at",
        ]


class CreateOrderSerializer(serializers.Serializer):
    branch = serializers.UUIDField()
    kind = serializers.ChoiceField(choices=[c[0] for c in Order.KIND_CHOICES], default="dine_in")
    table = serializers.UUIDField(required=False, allow_null=True)
    customer = serializers.UUIDField(required=False, allow_null=True)
    party_size = serializers.IntegerField(min_value=1, max_value=80, default=1)


class AddItemSerializer(serializers.Serializer):
    menu_item = serializers.UUIDField()
    variant = serializers.UUIDField(required=False, allow_null=True)
    modifier_options = serializers.ListField(child=serializers.UUIDField(), default=list)
    quantity = serializers.IntegerField(min_value=1, max_value=99, default=1)
    note = serializers.CharField(required=False, allow_blank=True, max_length=300)


class TransitionSerializer(serializers.Serializer):
    to_status = serializers.ChoiceField(choices=[c[0] for c in Order.STATUS_CHOICES])
    note = serializers.CharField(required=False, allow_blank=True, max_length=200)
