"""Order lifecycle signals — fan out to kitchen, inventory, notifications, webhooks."""
from __future__ import annotations

from django.db.models.signals import post_save
from django.dispatch import receiver

from .models import Order, OrderStatusHistory


@receiver(post_save, sender=OrderStatusHistory)
def on_order_status_changed(sender, instance: OrderStatusHistory, created: bool, **kwargs):
    if not created:
        return
    order = instance.order
    new = instance.new_status
    if new == "accepted":
        from apps.orders.tasks import fanout_kitchen_tickets
        fanout_kitchen_tickets.delay(str(order.id))
    if new == "ready" and order.kind in ("takeout", "online", "qr"):
        from apps.notifications.tasks import send_pickup_ready
        send_pickup_ready.delay(str(order.id))
    if new == "completed":
        from apps.inventory.tasks import deduct_for_order
        deduct_for_order.delay(str(order.id))
        from apps.webhooks.tasks import deliver_event
        from apps.webhooks.models import WebhookEndpoint
        for endpoint in WebhookEndpoint.objects.filter(restaurant_id=order.restaurant_id, paused_at__isnull=True):
            deliver_event.delay(str(endpoint.id), "order.completed", {"order_id": str(order.id), "number": order.number})
    if new == "placed":
        from apps.orders.tasks import send_order_confirmation
        send_order_confirmation.delay(str(order.id))


@receiver(post_save, sender=Order)
def on_order_created(sender, instance: Order, created: bool, **kwargs):
    if created:
        OrderStatusHistory.objects.create(
            order=instance, previous_status="", new_status=instance.status, note="initial",
        )
