from django.urls import path

from . import views

urlpatterns = [
    path("", views.OrderList.as_view()),
    path("<uuid:pk>", views.OrderDetail.as_view()),
    path("<uuid:pk>/items", views.AddItemView.as_view()),
    path("<uuid:pk>/items/<uuid:item_id>/void", views.VoidItemView.as_view()),
    path("<uuid:pk>/transition", views.TransitionOrderView.as_view()),
    path("<uuid:pk>/split", views.SplitOrderView.as_view()),
]
