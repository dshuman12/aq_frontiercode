import re

from apps.orders.numbering import generate_number


def test_default_prefix_and_length():
    n = generate_number()
    assert re.match(r"^ORD-[ABCDEFGHJKMNPQRSTUVWXYZ23456789]{4}$", n)


def test_custom_prefix_and_length():
    n = generate_number(prefix="X-", length=6)
    assert n.startswith("X-")
    assert len(n) == 8


def test_excludes_confusing_chars():
    samples = {generate_number() for _ in range(200)}
    text = "".join(samples)
    for ch in "01IO":
        assert ch not in text
