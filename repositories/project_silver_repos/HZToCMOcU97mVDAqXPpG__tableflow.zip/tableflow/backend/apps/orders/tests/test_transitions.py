import pytest

from apps.orders.transitions import can_transition, is_terminal


def test_full_dine_in_path():
    seq = ["draft", "placed", "accepted", "preparing", "ready", "served", "completed"]
    for a, b in zip(seq, seq[1:]):
        assert can_transition(a, b), f"{a}->{b}"


def test_delivery_path():
    seq = ["draft", "placed", "accepted", "preparing", "ready", "out_for_delivery", "completed"]
    for a, b in zip(seq, seq[1:]):
        assert can_transition(a, b)


def test_terminal_states():
    assert is_terminal("cancelled")
    assert is_terminal("refunded")
    assert not is_terminal("placed")


def test_cannot_skip_to_completed():
    assert not can_transition("placed", "completed")


def test_completed_can_be_refunded_only():
    assert can_transition("completed", "refunded")
    assert not can_transition("completed", "served")
