"""Order-kind specific transition rules."""
from apps.orders.transitions import can_transition


def test_takeout_skips_served():
    """Takeout/online/qr go ready → completed (no 'served' step)."""
    assert can_transition("ready", "served")  # legal in general
    # but for takeout, the UI / service should bypass straight to completed
    assert can_transition("served", "completed")


def test_delivery_uses_out_for_delivery():
    assert can_transition("ready", "out_for_delivery")
    assert can_transition("out_for_delivery", "completed")


def test_terminals_cannot_branch():
    for terminal in ("cancelled", "refunded"):
        for s in ("draft", "placed", "preparing", "completed"):
            assert not can_transition(terminal, s), f"{terminal}->{s}"
