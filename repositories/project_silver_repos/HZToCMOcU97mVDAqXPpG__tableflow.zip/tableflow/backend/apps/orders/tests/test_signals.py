"""Smoke check that the order signals module imports cleanly."""
from __future__ import annotations


def test_signals_module_importable():
    from apps.orders import signals
    assert hasattr(signals, "on_order_status_changed")
    assert hasattr(signals, "on_order_created")
