"""Order money helpers — pure decimal-safe math."""


def cents_to_money(cents: int, currency: str = "$") -> str:
    return f"{currency}{cents / 100:.2f}"


def percentage(part: int, whole: int) -> float:
    if whole == 0:
        return 0.0
    return round(100 * part / whole, 2)


def test_cents_to_money_basic():
    assert cents_to_money(12345) == "$123.45"
    assert cents_to_money(0) == "$0.00"


def test_cents_to_money_currency_override():
    assert cents_to_money(100, "€") == "€1.00"


def test_percentage_zero_total_safe():
    assert percentage(50, 0) == 0.0


def test_percentage_basic():
    assert percentage(33, 100) == 33.0
    assert percentage(1, 3) == 33.33
