"""Pure tests for the split-order math (no DB)."""


def test_split_partition_keeps_total():
    parent_lines = [
        {"id": "a", "line_total_cents": 1000},
        {"id": "b", "line_total_cents": 500},
        {"id": "c", "line_total_cents": 750},
    ]
    move_ids = {"a", "c"}
    parent_after = [li for li in parent_lines if li["id"] not in move_ids]
    child = [li for li in parent_lines if li["id"] in move_ids]
    parent_total = sum(li["line_total_cents"] for li in parent_after)
    child_total = sum(li["line_total_cents"] for li in child)
    assert parent_total + child_total == sum(li["line_total_cents"] for li in parent_lines)
    assert parent_total == 500
    assert child_total == 1750


def test_split_with_no_ids_is_a_noop():
    lines = [{"id": "a", "line_total_cents": 100}]
    assert [li for li in lines if li["id"] in set()] == []
