from decimal import Decimal


def test_recalculate_subtotal_sums_active_lines_only():
    items = [{"line_total_cents": 1000, "is_voided": False},
             {"line_total_cents": 500,  "is_voided": True},
             {"line_total_cents": 700,  "is_voided": False}]
    subtotal = sum(i["line_total_cents"] for i in items if not i["is_voided"])
    assert subtotal == 1700


def test_total_combines_subtotal_tax_service_delivery_tip_minus_discount():
    subtotal, discount, tax_rate, service_rate = 10000, 1000, 0.0825, 0.05
    delivery, tip = 500, 1500
    after_discount = max(0, subtotal - discount)
    tax = round(after_discount * tax_rate)
    service = round(after_discount * service_rate)
    total = after_discount + tax + service + delivery + tip
    assert tax == 743
    assert service == 450
    assert total == 9000 + 743 + 450 + 500 + 1500


def test_balance_floors_at_zero_for_overpaid_order():
    paid, total = 12000, 10000
    assert max(0, total - paid) == 0
