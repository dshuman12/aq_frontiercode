"""Verify the shape we expect to send to the audit log on transitions."""


def transition_diff(prev, new, note=""):
    return {"from": prev, "to": new, "note": note}


def test_diff_basic():
    assert transition_diff("placed", "accepted") == {"from": "placed", "to": "accepted", "note": ""}


def test_diff_includes_note():
    assert transition_diff("ready", "served", note="walked past 20s")["note"] == "walked past 20s"
