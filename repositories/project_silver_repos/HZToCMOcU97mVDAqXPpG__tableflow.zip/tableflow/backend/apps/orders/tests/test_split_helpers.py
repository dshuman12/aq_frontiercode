import pytest

from apps.orders.services_split import by_seat_split, even_split_cents


def test_even_split_sums_exactly():
    assert sum(even_split_cents(1000, 3)) == 1000
    assert sum(even_split_cents(1234, 7)) == 1234


def test_even_split_first_parts_get_extra():
    parts = even_split_cents(1001, 4)
    assert parts == [251, 250, 250, 250]


def test_even_split_zero_total():
    assert even_split_cents(0, 4) == [0, 0, 0, 0]


def test_even_split_invalid_n():
    with pytest.raises(ValueError):
        even_split_cents(100, 0)


def test_by_seat_groups_correctly():
    out = by_seat_split([500, 200, 300, 1000], [1, 2, 1, 3])
    assert out == {1: 800, 2: 200, 3: 1000}


def test_by_seat_length_mismatch():
    with pytest.raises(ValueError):
        by_seat_split([100], [1, 2])
