from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.accounts.permissions import perm
from apps.branches.models import Branch
from apps.menus.models import MenuItem, MenuItemVariant
from apps.modifiers.models import ModifierOption
from apps.tables.models import RestaurantTable

from . import services
from .models import Order, OrderItem
from .serializers import (
    AddItemSerializer,
    CreateOrderSerializer,
    OrderItemSerializer,
    OrderSerializer,
    TransitionSerializer,
)


class OrderList(generics.ListCreateAPIView):
    serializer_class = OrderSerializer
    permission_classes = [perm("orders:read")]
    filterset_fields = ["branch", "kind", "status", "table", "customer"]
    search_fields = ["number"]
    ordering = ["-created_at"]

    def get_queryset(self):  # type: ignore[override]
        return (
            Order.objects.filter(restaurant_id=self.request.restaurant_id)
            .select_related("branch", "table", "customer", "server", "cashier")
            .prefetch_related("items__modifiers")
        )

    def create(self, request, *args, **kwargs):  # type: ignore[override]
        serializer = CreateOrderSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        d = serializer.validated_data
        branch = Branch.objects.get(pk=d["branch"], restaurant_id=request.restaurant_id)
        table = RestaurantTable.objects.get(pk=d["table"], restaurant_id=request.restaurant_id) if d.get("table") else None
        order = services.create_order(
            restaurant_id=request.restaurant_id,
            branch=branch,
            kind=d.get("kind", "dine_in"),
            table=table,
            party_size=d.get("party_size", 1),
            server=request.user if request.user.is_authenticated else None,
        )
        return Response(OrderSerializer(order).data, status=status.HTTP_201_CREATED)


class OrderDetail(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = OrderSerializer
    permission_classes = [perm("orders:read")]

    def get_queryset(self):  # type: ignore[override]
        return Order.objects.filter(restaurant_id=self.request.restaurant_id).prefetch_related("items__modifiers")


class AddItemView(APIView):
    permission_classes = [perm("orders:update")]

    def post(self, request, pk):
        order = Order.objects.get(pk=pk, restaurant_id=request.restaurant_id)
        serializer = AddItemSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        d = serializer.validated_data
        menu_item = MenuItem.objects.get(pk=d["menu_item"], restaurant_id=request.restaurant_id)
        variant = MenuItemVariant.objects.get(pk=d["variant"]) if d.get("variant") else None
        options = list(ModifierOption.objects.filter(pk__in=d["modifier_options"]))
        item = services.add_item(
            order=order,
            menu_item=menu_item,
            variant=variant,
            modifier_options=options,
            quantity=d.get("quantity", 1),
            note=d.get("note", ""),
        )
        return Response(OrderItemSerializer(item).data, status=status.HTTP_201_CREATED)


class VoidItemView(APIView):
    permission_classes = [perm("orders:update")]

    def post(self, request, pk, item_id):
        order = Order.objects.get(pk=pk, restaurant_id=request.restaurant_id)
        item = OrderItem.objects.get(pk=item_id, order=order)
        services.void_item(item=item, reason=request.data.get("reason", ""))
        return Response(OrderItemSerializer(item).data)


class TransitionOrderView(APIView):
    permission_classes = [perm("orders:transition")]

    def post(self, request, pk):
        order = Order.objects.get(pk=pk, restaurant_id=request.restaurant_id)
        serializer = TransitionSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        services.transition(
            order,
            to_status=serializer.validated_data["to_status"],
            by=request.user,
            note=serializer.validated_data.get("note", ""),
        )
        return Response(OrderSerializer(order).data)


class SplitOrderView(APIView):
    permission_classes = [perm("orders:update")]

    def post(self, request, pk):
        order = Order.objects.get(pk=pk, restaurant_id=request.restaurant_id)
        item_ids = request.data.get("items", [])
        child = services.split_order(order=order, item_ids=item_ids)
        return Response({"parent": OrderSerializer(order).data, "child": OrderSerializer(child).data})
