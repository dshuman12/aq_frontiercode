"""Order status transitions."""
from __future__ import annotations

TRANSITIONS: dict[str, list[str]] = {
    "draft": ["placed", "cancelled"],
    "placed": ["accepted", "cancelled"],
    "accepted": ["preparing", "cancelled"],
    "preparing": ["ready", "cancelled"],
    "ready": ["served", "out_for_delivery", "cancelled"],
    "served": ["completed"],
    "out_for_delivery": ["completed", "cancelled"],
    "completed": ["refunded"],
    "cancelled": [],
    "refunded": [],
}


def can_transition(from_status: str, to_status: str) -> bool:
    return to_status in TRANSITIONS.get(from_status, [])


def is_terminal(status: str) -> bool:
    return TRANSITIONS.get(status, []) == []


def assert_transition(from_status: str, to_status: str) -> None:
    if not can_transition(from_status, to_status):
        raise ValueError(f"illegal-transition:{from_status}->{to_status}")
