"""Generate human-readable order numbers like 'ORD-A1B2'."""
from __future__ import annotations

import secrets
import string

ALPHABET = string.ascii_uppercase + string.digits  # I/O/0/1 not excluded — staff can read both
SAFE_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"  # excludes confusing chars


def generate_number(prefix: str = "ORD-", length: int = 4) -> str:
    return prefix + "".join(secrets.choice(SAFE_ALPHABET) for _ in range(length))
