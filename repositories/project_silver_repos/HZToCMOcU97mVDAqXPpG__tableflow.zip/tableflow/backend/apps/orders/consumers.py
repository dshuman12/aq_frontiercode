"""WS consumer that streams order/state changes to operators on the floor."""
from __future__ import annotations

from channels.generic.websocket import AsyncJsonWebsocketConsumer


class OrderStreamConsumer(AsyncJsonWebsocketConsumer):
    async def connect(self):
        self.branch_id = self.scope["url_route"]["kwargs"]["branch_id"]
        self.group_name = f"orders.{self.branch_id}"
        if self.scope.get("user") and self.scope["user"].is_authenticated:
            await self.channel_layer.group_add(self.group_name, self.channel_name)
            await self.accept()
        else:
            await self.close()

    async def disconnect(self, code):
        await self.channel_layer.group_discard(self.group_name, self.channel_name)

    async def order_event(self, event):
        await self.send_json(event["payload"])
