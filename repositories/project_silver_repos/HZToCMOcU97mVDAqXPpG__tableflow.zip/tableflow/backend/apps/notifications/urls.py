from django.urls import path

from . import views

urlpatterns = [
    path("", views.NotificationList.as_view()),
    path("read", views.MarkReadView.as_view()),
    path("preferences", views.PreferenceView.as_view()),
]
