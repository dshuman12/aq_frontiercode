"""Notification, NotificationPreference, EmailLog."""
from __future__ import annotations

import uuid

from django.conf import settings
from django.db import models


class Notification(models.Model):
    KIND_CHOICES = [
        ("order_confirmation", "Order confirmation"),
        ("order_status", "Order status update"),
        ("kitchen_alert", "Kitchen alert"),
        ("reservation_reminder", "Reservation reminder"),
        ("pickup_ready", "Pickup ready"),
        ("delivery_update", "Delivery update"),
        ("low_stock", "Low stock"),
        ("payment_receipt", "Payment receipt"),
        ("daily_digest", "Daily digest"),
        ("password_reset", "Password reset"),
        ("invitation", "Invitation"),
    ]
    CHANNEL_CHOICES = [("email", "Email"), ("sms", "SMS"), ("push", "Push"), ("inapp", "In-app")]
    STATUS_CHOICES = [("queued", "Queued"), ("sent", "Sent"), ("failed", "Failed"), ("read", "Read")]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(db_index=True)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="notifications")
    customer = models.ForeignKey("customers.Customer", null=True, blank=True, on_delete=models.SET_NULL, related_name="notifications")
    kind = models.CharField(max_length=24, choices=KIND_CHOICES, db_index=True)
    channel = models.CharField(max_length=8, choices=CHANNEL_CHOICES)
    status = models.CharField(max_length=8, choices=STATUS_CHOICES, default="queued", db_index=True)
    title = models.CharField(max_length=160)
    body = models.TextField(blank=True)
    payload = models.JSONField(default=dict, blank=True)
    sent_at = models.DateTimeField(null=True, blank=True)
    read_at = models.DateTimeField(null=True, blank=True)
    error_message = models.CharField(max_length=300, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "notification"
        indexes = [
            models.Index(fields=["restaurant_id", "user", "read_at"]),
            models.Index(fields=["restaurant_id", "status", "created_at"]),
        ]


class NotificationPreference(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="notification_prefs")
    email_orders = models.BooleanField(default=True)
    email_reservations = models.BooleanField(default=True)
    email_marketing = models.BooleanField(default=False)
    sms_orders = models.BooleanField(default=False)
    sms_reservations = models.BooleanField(default=False)
    push_kitchen = models.BooleanField(default=True)
    push_floor = models.BooleanField(default=True)

    class Meta:
        db_table = "notification_preference"


class EmailLog(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(null=True, blank=True, db_index=True)
    to_email = models.EmailField()
    subject = models.CharField(max_length=300)
    template = models.CharField(max_length=80)
    payload = models.JSONField(default=dict)
    sent_at = models.DateTimeField(auto_now_add=True)
    error = models.CharField(max_length=300, blank=True)

    class Meta:
        db_table = "email_log"
        indexes = [models.Index(fields=["restaurant_id", "sent_at"])]
