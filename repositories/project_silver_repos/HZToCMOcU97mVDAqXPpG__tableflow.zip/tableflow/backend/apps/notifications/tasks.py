"""Notification Celery tasks (one per kind)."""
from __future__ import annotations

import logging

from celery import shared_task
from django.conf import settings
from django.core.mail import send_mail

from .models import EmailLog, Notification
from .templates_registry import REGISTRY, render

log = logging.getLogger(__name__)


def _send_email(*, restaurant_id, to_email: str, template_key: str, ctx: dict) -> None:
    template = REGISTRY[template_key]
    body = render(template, ctx)
    try:
        send_mail(
            subject=body["subject"],
            message=body["html"],
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=[to_email],
            html_message=body["html"],
        )
        EmailLog.objects.create(
            restaurant_id=restaurant_id, to_email=to_email, subject=body["subject"],
            template=template_key, payload=ctx,
        )
    except Exception as exc:  # pragma: no cover
        log.error("notifications.email.error", extra={"to": to_email, "tpl": template_key, "exc": str(exc)})
        EmailLog.objects.create(
            restaurant_id=restaurant_id, to_email=to_email, subject=body["subject"],
            template=template_key, payload=ctx, error=str(exc)[:300],
        )


@shared_task
def send_password_reset_email(user_id: str, token: str) -> dict:
    from apps.accounts.models import User
    user = User.objects.get(pk=user_id)
    reset_url = f"{settings.APP_URL}/reset-password?token={token}"
    _send_email(restaurant_id=None, to_email=user.email, template_key="password_reset",
                ctx={"reset_url": reset_url})
    return {"queued": True}


@shared_task
def send_order_confirmation_email(order_id: str) -> dict:
    from apps.orders.models import Order
    o = Order.objects.select_related("customer").get(pk=order_id)
    if not o.customer or not o.customer.email:
        return {"skipped": "no-email"}
    _send_email(
        restaurant_id=o.restaurant_id, to_email=o.customer.email,
        template_key="order_confirmation",
        ctx={
            "order": {"number": o.number, "total": f"${o.total_cents/100:.2f}"},
            "customer": {"name": o.customer.display_name},
            "restaurant": {"name": "Restaurant"},
        },
    )
    return {"sent": True}


@shared_task
def send_reservation_reminder(reservation_id: str) -> dict:
    from apps.reservations.models import Reservation
    r = Reservation.objects.get(pk=reservation_id)
    if not r.customer_email:
        return {"skipped": "no-email"}
    _send_email(
        restaurant_id=r.restaurant_id, to_email=r.customer_email,
        template_key="reservation_reminder",
        ctx={
            "customer_name": r.customer_name,
            "starts_at": r.starts_at.isoformat(),
            "party_size": str(r.party_size),
        },
    )
    return {"sent": True}


@shared_task
def send_low_stock_alert(ingredient_id: str) -> dict:
    log.info("notifications.low_stock", extra={"ingredient_id": ingredient_id})
    Notification.objects.create(
        restaurant_id="00000000-0000-0000-0000-000000000000",
        kind="low_stock", channel="inapp", title=f"Ingredient {ingredient_id} low",
    )
    return {"queued": True}


@shared_task
def send_pickup_ready(order_id: str) -> dict:
    log.info("notifications.pickup_ready", extra={"order_id": order_id})
    return {"queued": True}


@shared_task
def send_delivery_eta_update(delivery_id: str) -> dict:
    log.info("notifications.delivery_eta", extra={"delivery_id": delivery_id})
    return {"queued": True}
