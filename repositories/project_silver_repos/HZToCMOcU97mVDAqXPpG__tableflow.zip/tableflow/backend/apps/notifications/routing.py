from django.urls import path

from .consumers import NotificationStreamConsumer

websocket_urlpatterns = [
    path("ws/notifications/<uuid:user_id>", NotificationStreamConsumer.as_asgi()),
]
