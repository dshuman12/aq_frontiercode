from django.utils import timezone
from rest_framework import generics
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.accounts.permissions import perm

from .models import Notification, NotificationPreference
from .serializers import NotificationPreferenceSerializer, NotificationSerializer


class NotificationList(generics.ListAPIView):
    serializer_class = NotificationSerializer
    permission_classes = [perm("notifications:read")]
    filterset_fields = ["kind", "channel", "status"]
    ordering = ["-created_at"]

    def get_queryset(self):  # type: ignore[override]
        qs = Notification.objects.filter(restaurant_id=self.request.restaurant_id)
        if self.request.query_params.get("mine") in ("1", "true"):
            qs = qs.filter(user=self.request.user)
        return qs


class MarkReadView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        ids = request.data.get("ids") or []
        Notification.objects.filter(
            restaurant_id=request.restaurant_id, user=request.user, id__in=ids
        ).update(status="read", read_at=timezone.now())
        return Response({"ok": True})


class PreferenceView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        pref, _ = NotificationPreference.objects.get_or_create(user=request.user)
        return Response(NotificationPreferenceSerializer(pref).data)

    def patch(self, request):
        pref, _ = NotificationPreference.objects.get_or_create(user=request.user)
        serializer = NotificationPreferenceSerializer(pref, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)
