from django.contrib import admin

from .models import EmailLog, Notification, NotificationPreference


@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ("kind", "channel", "title", "status", "created_at")
    list_filter = ("kind", "channel", "status")
    search_fields = ("title", "body")


@admin.register(EmailLog)
class EmailLogAdmin(admin.ModelAdmin):
    list_display = ("to_email", "template", "subject", "sent_at")
    list_filter = ("template",)
    search_fields = ("to_email", "subject")
    readonly_fields = ("sent_at",)


admin.site.register([NotificationPreference])
