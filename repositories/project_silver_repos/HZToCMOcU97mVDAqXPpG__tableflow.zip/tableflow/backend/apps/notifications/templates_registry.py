"""Email template registry — light Mustache-style replacer."""
from __future__ import annotations

import re
from dataclasses import dataclass

_TAG = re.compile(r"\{\{\s*([a-zA-Z0-9_.]+)\s*\}\}")


@dataclass(frozen=True)
class Template:
    key: str
    subject: str
    html: str


def _resolve(path: str, ctx: dict) -> str:
    cur = ctx
    for part in path.split("."):
        if isinstance(cur, dict) and part in cur:
            cur = cur[part]
        else:
            return ""
    return str(cur)


def render(t: Template, ctx: dict) -> dict:
    return {
        "subject": _TAG.sub(lambda m: _resolve(m.group(1), ctx), t.subject),
        "html": _TAG.sub(lambda m: _resolve(m.group(1), ctx), t.html),
    }


REGISTRY: dict[str, Template] = {
    "order_confirmation": Template(
        key="order_confirmation",
        subject="Order {{order.number}} confirmed — {{restaurant.name}}",
        html="<h1>Thanks {{customer.name}}!</h1><p>Your order #{{order.number}} totals {{order.total}}.</p>",
    ),
    "reservation_reminder": Template(
        key="reservation_reminder",
        subject="See you at {{starts_at}}",
        html="<p>Hi {{customer_name}}, your table for {{party_size}} is reserved at {{starts_at}}.</p>",
    ),
    "pickup_ready": Template(
        key="pickup_ready",
        subject="Order {{order.number}} is ready for pickup",
        html="<p>Hi {{customer.name}}, your order #{{order.number}} is ready.</p>",
    ),
    "delivery_update": Template(
        key="delivery_update",
        subject="Delivery update for {{order.number}}",
        html="<p>Status: {{status}}. ETA: {{eta_minutes}} min.</p>",
    ),
    "low_stock": Template(
        key="low_stock",
        subject="Low stock alert: {{ingredient.name}}",
        html="<p>{{ingredient.name}} is below par ({{ingredient.on_hand}} / {{ingredient.par}}).</p>",
    ),
    "payment_receipt": Template(
        key="payment_receipt",
        subject="Receipt for order {{order.number}}",
        html="<p>Thank you. {{amount_formatted}} captured.</p>",
    ),
    "password_reset": Template(
        key="password_reset",
        subject="Reset your TableFlow password",
        html='<p>Click <a href="{{reset_url}}">here</a> to reset your password.</p>',
    ),
    "invitation": Template(
        key="invitation",
        subject="You're invited to {{restaurant.name}} on TableFlow",
        html='<p>Click <a href="{{accept_url}}">accept</a> to join.</p>',
    ),
    "daily_digest": Template(
        key="daily_digest",
        subject="Daily sales digest — {{date}}",
        html="<p>Revenue: {{revenue}}. Orders: {{orders}}. Top item: {{top_item}}.</p>",
    ),
}
