"""Multi-channel dispatcher with token bucket throttling per (restaurant, channel)."""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Callable


@dataclass
class TokenBucket:
    capacity: int = 60
    refill_per_sec: float = 1.0
    tokens: float = field(init=False)
    last_refill: float = field(init=False)

    def __post_init__(self):
        self.tokens = self.capacity
        self.last_refill = time.monotonic()

    def take(self, n: int = 1) -> bool:
        now = time.monotonic()
        elapsed = now - self.last_refill
        self.tokens = min(self.capacity, self.tokens + elapsed * self.refill_per_sec)
        self.last_refill = now
        if self.tokens >= n:
            self.tokens -= n
            return True
        return False


class Dispatcher:
    """Routes a notification through enabled channels via send callables."""

    def __init__(self, channels: dict[str, Callable[[dict], dict]]):
        self.channels = channels

    def dispatch(self, *, kind: str, body: dict, prefs: dict[str, bool]) -> dict:
        results: dict[str, dict] = {}
        active = {name: fn for name, fn in self.channels.items() if prefs.get(name)}
        if not active:
            raise ValueError("no-channels-enabled")
        for name, fn in active.items():
            try:
                results[name] = {"delivered": True, **(fn({"kind": kind, **body}) or {})}
            except Exception as exc:  # pragma: no cover
                results[name] = {"delivered": False, "error": str(exc)}
        return results
