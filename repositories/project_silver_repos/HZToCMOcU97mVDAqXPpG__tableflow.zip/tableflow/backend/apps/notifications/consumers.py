from channels.generic.websocket import AsyncJsonWebsocketConsumer


class NotificationStreamConsumer(AsyncJsonWebsocketConsumer):
    async def connect(self):
        user_id = self.scope["url_route"]["kwargs"]["user_id"]
        self.group_name = f"notifications.{user_id}"
        if self.scope.get("user") and self.scope["user"].is_authenticated and str(self.scope["user"].id) == str(user_id):
            await self.channel_layer.group_add(self.group_name, self.channel_name)
            await self.accept()
        else:
            await self.close()

    async def disconnect(self, code):
        await self.channel_layer.group_discard(self.group_name, self.channel_name)

    async def notification_event(self, event):
        await self.send_json(event["payload"])
