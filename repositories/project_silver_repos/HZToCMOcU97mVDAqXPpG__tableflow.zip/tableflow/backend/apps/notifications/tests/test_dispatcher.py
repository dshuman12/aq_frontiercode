import time

import pytest

from apps.notifications.dispatcher import Dispatcher, TokenBucket
from apps.notifications.templates_registry import REGISTRY, render


def test_token_bucket_starts_full_and_drains():
    b = TokenBucket(capacity=3, refill_per_sec=0.0001)
    assert b.take() and b.take() and b.take()
    assert not b.take()


def test_token_bucket_refills():
    b = TokenBucket(capacity=2, refill_per_sec=100)
    b.take(); b.take()
    time.sleep(0.05)
    assert b.take()


def test_dispatcher_routes_only_enabled_channels():
    sent_email = []
    sent_sms = []
    d = Dispatcher({
        "email": lambda payload: sent_email.append(payload) or {"id": "e1"},
        "sms": lambda payload: sent_sms.append(payload) or {"id": "s1"},
    })
    out = d.dispatch(kind="x", body={"msg": "hi"}, prefs={"email": True, "sms": False})
    assert out["email"]["delivered"]
    assert "sms" not in out
    assert sent_email and not sent_sms


def test_dispatcher_raises_with_no_channels_enabled():
    d = Dispatcher({"email": lambda p: {}})
    with pytest.raises(ValueError):
        d.dispatch(kind="x", body={}, prefs={"sms": False})


def test_template_rendering_substitutes():
    out = render(REGISTRY["password_reset"], {"reset_url": "https://x/y"})
    assert "https://x/y" in out["html"]
