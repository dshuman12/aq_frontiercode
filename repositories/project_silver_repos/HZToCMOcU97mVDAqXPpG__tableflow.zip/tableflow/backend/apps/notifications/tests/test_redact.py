from apps.audit_logs.log_format import _redact


def test_redacts_credentials():
    out = _redact({"password": "hunter2", "api_key": "abc", "user": "ada"})
    assert out["password"] == "[redacted]"
    assert out["api_key"] == "[redacted]"
    assert out["user"] == "ada"


def test_redacts_email_in_strings():
    out = _redact({"msg": "Hi from user@example.com — please verify"})
    assert "user@example.com" not in out["msg"]
    assert "@example.com" in out["msg"]


def test_redacts_phone_in_strings():
    out = _redact({"msg": "Call 512-555-9999 to confirm"})
    assert "512-555-9999" not in out["msg"]


def test_recurses_into_lists_and_dicts():
    out = _redact({"items": [{"password": "x"}, {"ok": True}]})
    assert out["items"][0]["password"] == "[redacted]"
    assert out["items"][1] == {"ok": True}
