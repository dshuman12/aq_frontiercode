from apps.notifications.templates_registry import REGISTRY, render


def test_every_template_has_subject_and_html():
    for key, t in REGISTRY.items():
        assert t.subject, f"{key} missing subject"
        assert t.html, f"{key} missing html"


def test_unresolved_tags_become_empty_string():
    out = render(REGISTRY["password_reset"], {})  # no reset_url provided
    assert "{{" not in out["html"]
    # The literal text remains, but the tag is resolved away to ""
    assert 'href=""' in out["html"]


def test_nested_dot_path_resolves():
    out = render(REGISTRY["order_confirmation"], {
        "order": {"number": "ORD-AB12", "total": "$25.00"},
        "customer": {"name": "Ada"},
        "restaurant": {"name": "Demo"},
    })
    assert "ORD-AB12" in out["subject"]
    assert "Ada" in out["html"]
    assert "$25.00" in out["html"]
