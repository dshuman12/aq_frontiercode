"""More dispatcher edge cases."""
import pytest

from apps.notifications.dispatcher import Dispatcher, TokenBucket


def test_bucket_take_n_at_once():
    b = TokenBucket(capacity=10, refill_per_sec=0.0001)
    assert b.take(5) is True
    assert b.take(5) is True
    assert b.take(1) is False


def test_bucket_partial_take_when_insufficient():
    b = TokenBucket(capacity=2, refill_per_sec=0.0001)
    assert b.take(2) is True
    assert b.take(1) is False


def test_dispatcher_per_channel_failure_doesnt_break_others():
    log = []
    def ok(payload): log.append(("ok", payload)); return {"id": "1"}
    def boom(_payload): raise RuntimeError("simulated")

    d = Dispatcher({"email": ok, "sms": boom})
    out = d.dispatch(kind="x", body={"msg": "hi"}, prefs={"email": True, "sms": True})
    assert out["email"]["delivered"]
    assert out["sms"]["delivered"] is False
    assert "simulated" in out["sms"]["error"]
    assert log == [("ok", {"kind": "x", "msg": "hi"})]


def test_dispatcher_skips_disabled_channels():
    sent = []
    d = Dispatcher({"email": lambda p: sent.append(p) or {"id": "1"}})
    out = d.dispatch(kind="x", body={}, prefs={"email": True, "push": True})
    # push isn't in registered channels, so it's silently ignored
    assert "email" in out
    assert "push" not in out
