"""Notification preference defaults — pure dict-based logic."""


DEFAULTS = {
    "email_orders": True,
    "email_reservations": True,
    "email_marketing": False,
    "sms_orders": False,
    "sms_reservations": False,
    "push_kitchen": True,
    "push_floor": True,
}


def merge_with_defaults(prefs):
    out = dict(DEFAULTS)
    out.update(prefs or {})
    return out


def channels_for(kind, prefs):
    p = merge_with_defaults(prefs)
    out = []
    if kind == "order_confirmation":
        if p["email_orders"]:
            out.append("email")
        if p["sms_orders"]:
            out.append("sms")
    elif kind == "reservation_reminder":
        if p["email_reservations"]:
            out.append("email")
        if p["sms_reservations"]:
            out.append("sms")
    elif kind == "kitchen_alert":
        if p["push_kitchen"]:
            out.append("push")
    return out


def test_defaults_email_orders_on_sms_off():
    out = channels_for("order_confirmation", None)
    assert "email" in out
    assert "sms" not in out


def test_user_can_opt_in_to_sms():
    out = channels_for("order_confirmation", {"sms_orders": True})
    assert "email" in out and "sms" in out


def test_user_can_disable_email():
    out = channels_for("order_confirmation", {"email_orders": False})
    assert "email" not in out


def test_kitchen_uses_push_only():
    assert channels_for("kitchen_alert", None) == ["push"]
