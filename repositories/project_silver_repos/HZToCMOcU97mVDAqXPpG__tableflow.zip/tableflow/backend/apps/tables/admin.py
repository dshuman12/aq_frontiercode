from django.contrib import admin

from .models import DiningArea, RestaurantTable, TableQRCode, TableStatusHistory


@admin.register(RestaurantTable)
class RestaurantTableAdmin(admin.ModelAdmin):
    list_display = ("number", "area", "capacity", "status", "is_active")
    list_filter = ("status", "is_active", "area")
    search_fields = ("number", "label")


admin.site.register([DiningArea, TableQRCode, TableStatusHistory])
