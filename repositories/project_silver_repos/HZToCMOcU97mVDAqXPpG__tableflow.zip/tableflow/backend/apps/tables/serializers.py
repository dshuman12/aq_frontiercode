from rest_framework import serializers

from .models import DiningArea, RestaurantTable, TableQRCode, TableStatusHistory


class DiningAreaSerializer(serializers.ModelSerializer):
    class Meta:
        model = DiningArea
        fields = "__all__"
        read_only_fields = ["id", "restaurant_id"]


class TableQRCodeSerializer(serializers.ModelSerializer):
    class Meta:
        model = TableQRCode
        fields = "__all__"
        read_only_fields = ["id", "code", "issued_at"]


class RestaurantTableSerializer(serializers.ModelSerializer):
    qr_code = serializers.CharField(source="qr.code", read_only=True)

    class Meta:
        model = RestaurantTable
        fields = "__all__"
        read_only_fields = ["id", "restaurant_id", "qr_code", "created_at", "updated_at"]


class TableStatusHistorySerializer(serializers.ModelSerializer):
    class Meta:
        model = TableStatusHistory
        fields = "__all__"


class TransitionSerializer(serializers.Serializer):
    to_status = serializers.ChoiceField(choices=[c[0] for c in RestaurantTable.STATUS_CHOICES])
    note = serializers.CharField(required=False, allow_blank=True, max_length=200)
