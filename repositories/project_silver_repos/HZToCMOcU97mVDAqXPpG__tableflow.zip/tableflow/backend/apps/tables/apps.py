from django.apps import AppConfig


class TablesConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.tables"

    def ready(self) -> None:
        from . import signals  # noqa: F401
