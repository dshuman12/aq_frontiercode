"""Table status transitions — explicit guards prevent illegal jumps."""
from __future__ import annotations

TRANSITIONS: dict[str, list[str]] = {
    "available": ["reserved", "seated", "closed"],
    "reserved": ["seated", "available", "closed"],
    "seated": ["ordering", "available", "needs_cleaning"],
    "ordering": ["preparing", "available"],
    "preparing": ["served"],
    "served": ["needs_cleaning", "available"],
    "needs_cleaning": ["available"],
    "closed": ["available"],
}


def can_transition(from_status: str, to_status: str) -> bool:
    return to_status in TRANSITIONS.get(from_status, [])


def assert_transition(from_status: str, to_status: str) -> None:
    if not can_transition(from_status, to_status):
        raise ValueError(f"illegal-transition:{from_status}->{to_status}")
