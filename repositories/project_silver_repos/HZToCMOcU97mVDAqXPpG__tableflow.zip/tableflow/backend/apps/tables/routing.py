from django.urls import path

from .consumers import TableStatusConsumer

websocket_urlpatterns = [
    path("ws/tables/<uuid:branch_id>", TableStatusConsumer.as_asgi()),
]
