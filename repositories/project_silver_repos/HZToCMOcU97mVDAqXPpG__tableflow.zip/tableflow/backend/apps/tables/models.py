"""DiningArea, RestaurantTable, TableQRCode, TableStatusHistory."""
from __future__ import annotations

import secrets
import uuid

from django.conf import settings
from django.db import models


class DiningArea(models.Model):
    SHAPE_CHOICES = [("dining", "Dining room"), ("bar", "Bar"), ("patio", "Patio"), ("private", "Private")]
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(db_index=True)
    branch = models.ForeignKey("branches.Branch", on_delete=models.CASCADE, related_name="dining_areas")
    name = models.CharField(max_length=80)
    kind = models.CharField(max_length=12, choices=SHAPE_CHOICES, default="dining")
    sort_order = models.PositiveIntegerField(default=0)

    class Meta:
        db_table = "dining_area"
        ordering = ["sort_order"]


class RestaurantTable(models.Model):
    STATUS_CHOICES = [
        ("available", "Available"),
        ("reserved", "Reserved"),
        ("seated", "Seated"),
        ("ordering", "Ordering"),
        ("preparing", "Food preparing"),
        ("served", "Served"),
        ("needs_cleaning", "Needs cleaning"),
        ("closed", "Closed"),
    ]
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(db_index=True)
    area = models.ForeignKey(DiningArea, on_delete=models.CASCADE, related_name="tables")
    number = models.CharField(max_length=12)  # "T-12", "B-3"
    label = models.CharField(max_length=80, blank=True)
    capacity = models.PositiveSmallIntegerField(default=2)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="available", db_index=True)
    server = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="served_tables")
    pos_x = models.IntegerField(default=0)
    pos_y = models.IntegerField(default=0)
    width = models.PositiveSmallIntegerField(default=2)
    height = models.PositiveSmallIntegerField(default=2)
    merged_into = models.ForeignKey("self", null=True, blank=True, on_delete=models.SET_NULL, related_name="merged_from")
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "restaurant_table"
        unique_together = ("restaurant_id", "area", "number")
        ordering = ["area", "number"]

    def __str__(self) -> str:
        return f"{self.number} ({self.capacity}p)"


class TableQRCode(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    table = models.OneToOneField(RestaurantTable, on_delete=models.CASCADE, related_name="qr")
    code = models.CharField(max_length=48, unique=True, default=lambda: secrets.token_urlsafe(16))
    issued_at = models.DateTimeField(auto_now_add=True)
    revoked_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "table_qr_code"


class TableStatusHistory(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    table = models.ForeignKey(RestaurantTable, on_delete=models.CASCADE, related_name="status_history")
    previous_status = models.CharField(max_length=20, blank=True)
    new_status = models.CharField(max_length=20)
    changed_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL)
    changed_at = models.DateTimeField(auto_now_add=True)
    note = models.CharField(max_length=200, blank=True)

    class Meta:
        db_table = "table_status_history"
        ordering = ["-changed_at"]
