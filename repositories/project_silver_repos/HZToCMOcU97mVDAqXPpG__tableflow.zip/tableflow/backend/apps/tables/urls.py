from django.urls import path

from . import views

urlpatterns = [
    path("areas", views.AreaList.as_view()),
    path("areas/<uuid:pk>", views.AreaDetail.as_view()),
    path("", views.TableList.as_view()),
    path("<uuid:pk>", views.TableDetail.as_view()),
    path("<uuid:pk>/transition", views.TransitionTableView.as_view()),
    path("<uuid:pk>/qr/rotate", views.QRRotateView.as_view()),
    path("<uuid:pk>/split", views.SplitTablesView.as_view()),
    path("merge", views.MergeTablesView.as_view()),
]
