"""Issue a fresh QR code when a table is created without one."""
from __future__ import annotations

from django.db.models.signals import post_save
from django.dispatch import receiver

from .models import RestaurantTable, TableQRCode


@receiver(post_save, sender=RestaurantTable)
def ensure_qr_code(sender, instance: RestaurantTable, created: bool, **kwargs):
    if not created:
        return
    TableQRCode.objects.get_or_create(table=instance)
