from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.accounts.permissions import perm

from . import services
from .models import DiningArea, RestaurantTable, TableQRCode
from .serializers import (
    DiningAreaSerializer,
    RestaurantTableSerializer,
    TableQRCodeSerializer,
    TransitionSerializer,
)


class AreaList(generics.ListCreateAPIView):
    serializer_class = DiningAreaSerializer
    permission_classes = [perm("tables:read")]
    filterset_fields = ["branch"]

    def get_queryset(self):  # type: ignore[override]
        return DiningArea.objects.filter(restaurant_id=self.request.restaurant_id)

    def perform_create(self, serializer):  # type: ignore[override]
        serializer.save(restaurant_id=self.request.restaurant_id)


class AreaDetail(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = DiningAreaSerializer
    permission_classes = [perm("tables:read")]

    def get_queryset(self):  # type: ignore[override]
        return DiningArea.objects.filter(restaurant_id=self.request.restaurant_id)


class TableList(generics.ListCreateAPIView):
    serializer_class = RestaurantTableSerializer
    permission_classes = [perm("tables:read")]
    filterset_fields = ["area", "status", "is_active"]

    def get_queryset(self):  # type: ignore[override]
        return RestaurantTable.objects.filter(restaurant_id=self.request.restaurant_id).select_related("area", "qr")

    def perform_create(self, serializer):  # type: ignore[override]
        table = serializer.save(restaurant_id=self.request.restaurant_id)
        TableQRCode.objects.create(table=table)


class TableDetail(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = RestaurantTableSerializer
    permission_classes = [perm("tables:read")]

    def get_queryset(self):  # type: ignore[override]
        return RestaurantTable.objects.filter(restaurant_id=self.request.restaurant_id)


class TransitionTableView(APIView):
    permission_classes = [perm("tables:update")]

    def post(self, request, pk):
        try:
            table = RestaurantTable.objects.get(pk=pk, restaurant_id=request.restaurant_id)
        except RestaurantTable.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)
        serializer = TransitionSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        services.transition_table(
            table,
            to_status=serializer.validated_data["to_status"],
            by=request.user,
            note=serializer.validated_data.get("note", ""),
        )
        return Response(RestaurantTableSerializer(table).data)


class MergeTablesView(APIView):
    permission_classes = [perm("tables:update")]

    def post(self, request):
        primary_id = request.data.get("primary")
        others_ids = request.data.get("others", [])
        primary = RestaurantTable.objects.get(pk=primary_id, restaurant_id=request.restaurant_id)
        others = list(RestaurantTable.objects.filter(pk__in=others_ids, restaurant_id=request.restaurant_id))
        services.merge_tables(primary=primary, others=others)
        return Response(RestaurantTableSerializer(primary).data)


class SplitTablesView(APIView):
    permission_classes = [perm("tables:update")]

    def post(self, request, pk):
        primary = RestaurantTable.objects.get(pk=pk, restaurant_id=request.restaurant_id)
        n = services.split_tables(primary=primary)
        return Response({"split": n})


class QRRotateView(APIView):
    permission_classes = [perm("tables:update")]

    def post(self, request, pk):
        table = RestaurantTable.objects.get(pk=pk, restaurant_id=request.restaurant_id)
        try:
            old = table.qr
            old.revoked_at = None
            old.delete()
        except TableQRCode.DoesNotExist:
            pass
        qr = TableQRCode.objects.create(table=table)
        return Response(TableQRCodeSerializer(qr).data)
