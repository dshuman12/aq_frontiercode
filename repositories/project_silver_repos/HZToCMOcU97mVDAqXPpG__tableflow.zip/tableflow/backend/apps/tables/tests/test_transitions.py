import pytest

from apps.tables.transitions import assert_transition, can_transition


def test_happy_path_seated_to_served():
    seq = ["available", "seated", "ordering", "preparing", "served", "needs_cleaning", "available"]
    for a, b in zip(seq, seq[1:]):
        assert can_transition(a, b)


def test_cannot_skip_to_served_from_available():
    assert not can_transition("available", "served")


def test_cannot_jump_back_from_served():
    assert not can_transition("served", "ordering")


def test_assert_raises_on_illegal():
    with pytest.raises(ValueError):
        assert_transition("served", "ordering")


def test_closed_can_be_reopened():
    assert can_transition("closed", "available")
