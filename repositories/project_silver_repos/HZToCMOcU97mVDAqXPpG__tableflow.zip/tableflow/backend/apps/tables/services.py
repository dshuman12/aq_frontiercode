"""Table services — transition + merge."""
from __future__ import annotations

from django.db import transaction
from rest_framework.exceptions import ValidationError

from .models import RestaurantTable, TableStatusHistory
from .transitions import can_transition


@transaction.atomic
def transition_table(table: RestaurantTable, *, to_status: str, by, note: str = "") -> RestaurantTable:
    if not can_transition(table.status, to_status):
        raise ValidationError({"status": f"illegal-transition:{table.status}->{to_status}"})
    TableStatusHistory.objects.create(
        table=table,
        previous_status=table.status,
        new_status=to_status,
        changed_by=by if getattr(by, "is_authenticated", False) else None,
        note=note,
    )
    table.status = to_status
    table.save(update_fields=["status", "updated_at"])
    return table


@transaction.atomic
def merge_tables(*, primary: RestaurantTable, others: list[RestaurantTable]) -> RestaurantTable:
    for t in others:
        if t.id == primary.id:
            continue
        t.merged_into = primary
        t.is_active = False
        t.save(update_fields=["merged_into", "is_active"])
    return primary


@transaction.atomic
def split_tables(*, primary: RestaurantTable) -> int:
    qs = RestaurantTable.objects.filter(merged_into=primary)
    n = qs.count()
    qs.update(merged_into=None, is_active=True)
    return n
