"""Coupon, Promotion, CouponRedemption."""
from __future__ import annotations

import uuid

from django.db import models


class Coupon(models.Model):
    KIND_CHOICES = [
        ("percent", "Percent off"),
        ("amount", "Amount off"),
        ("bogo", "Buy-one-get-one"),
        ("free_delivery", "Free delivery"),
    ]
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(db_index=True)
    code = models.CharField(max_length=40, db_index=True)
    name = models.CharField(max_length=120)
    kind = models.CharField(max_length=14, choices=KIND_CHOICES)
    percent_off = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    amount_off_cents = models.PositiveIntegerField(default=0)
    min_order_cents = models.PositiveIntegerField(default=0)
    max_uses = models.PositiveIntegerField(default=0)  # 0 = unlimited
    times_used = models.PositiveIntegerField(default=0)
    branches = models.ManyToManyField("branches.Branch", blank=True, related_name="coupons")
    starts_at = models.DateTimeField(null=True, blank=True)
    ends_at = models.DateTimeField(null=True, blank=True)
    is_active = models.BooleanField(default=True)
    description = models.CharField(max_length=200, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "coupon"
        unique_together = ("restaurant_id", "code")
        indexes = [models.Index(fields=["restaurant_id", "is_active", "ends_at"])]


class Promotion(models.Model):
    KIND_CHOICES = [
        ("happy_hour", "Happy hour"),
        ("daily_special", "Daily special"),
        ("seasonal", "Seasonal"),
    ]
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(db_index=True)
    name = models.CharField(max_length=120)
    kind = models.CharField(max_length=16, choices=KIND_CHOICES, default="seasonal")
    weekdays = models.JSONField(default=list)
    starts_time = models.TimeField(null=True, blank=True)
    ends_time = models.TimeField(null=True, blank=True)
    starts_on = models.DateField(null=True, blank=True)
    ends_on = models.DateField(null=True, blank=True)
    percent_off = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    items = models.ManyToManyField("menus.MenuItem", blank=True, related_name="promotions")
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = "promotion"


class CouponRedemption(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    coupon = models.ForeignKey(Coupon, on_delete=models.CASCADE, related_name="redemptions")
    order = models.ForeignKey("orders.Order", on_delete=models.CASCADE, related_name="coupon_redemptions")
    discount_cents = models.PositiveIntegerField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "coupon_redemption"
        unique_together = ("coupon", "order")
