from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.accounts.permissions import perm
from apps.orders.models import Order

from . import services
from .models import Coupon, Promotion
from .serializers import (
    ApplyCouponSerializer,
    CouponRedemptionSerializer,
    CouponSerializer,
    PromotionSerializer,
)


class CouponList(generics.ListCreateAPIView):
    serializer_class = CouponSerializer
    permission_classes = [perm("coupons:read")]
    search_fields = ["code", "name"]
    filterset_fields = ["is_active", "kind"]

    def get_queryset(self):  # type: ignore[override]
        return Coupon.objects.filter(restaurant_id=self.request.restaurant_id)

    def perform_create(self, serializer):  # type: ignore[override]
        serializer.save(restaurant_id=self.request.restaurant_id)


class CouponDetail(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = CouponSerializer
    permission_classes = [perm("coupons:read")]

    def get_queryset(self):  # type: ignore[override]
        return Coupon.objects.filter(restaurant_id=self.request.restaurant_id)


class PromotionList(generics.ListCreateAPIView):
    serializer_class = PromotionSerializer
    permission_classes = [perm("coupons:read")]

    def get_queryset(self):  # type: ignore[override]
        return Promotion.objects.filter(restaurant_id=self.request.restaurant_id)

    def perform_create(self, serializer):  # type: ignore[override]
        serializer.save(restaurant_id=self.request.restaurant_id)


class ApplyCouponView(APIView):
    permission_classes = [perm("orders:update")]

    def post(self, request):
        serializer = ApplyCouponSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        coupon = Coupon.objects.get(restaurant_id=request.restaurant_id, code__iexact=serializer.validated_data["code"])
        order = Order.objects.get(pk=serializer.validated_data["order"], restaurant_id=request.restaurant_id)
        red = services.apply(coupon=coupon, order=order)
        return Response(CouponRedemptionSerializer(red).data, status=status.HTTP_201_CREATED)
