"""Promotion windowing — pure logic tests."""
from datetime import date, time


def in_window(now_dt, *, weekdays, starts_time=None, ends_time=None, starts_on=None, ends_on=None):
    if weekdays and now_dt.weekday() not in weekdays:
        return False
    if starts_on and now_dt.date() < starts_on:
        return False
    if ends_on and now_dt.date() > ends_on:
        return False
    if starts_time and now_dt.time() < starts_time:
        return False
    if ends_time and now_dt.time() > ends_time:
        return False
    return True


def test_inside_window():
    from datetime import datetime
    assert in_window(
        datetime(2024, 8, 15, 16, 0),
        weekdays=[0, 1, 2, 3, 4], starts_time=time(15, 0), ends_time=time(18, 0),
    )


def test_outside_weekday():
    from datetime import datetime
    assert not in_window(datetime(2024, 8, 17, 16, 0), weekdays=[0, 1, 2, 3, 4])  # Saturday


def test_outside_time_window():
    from datetime import datetime
    assert not in_window(datetime(2024, 8, 15, 19, 0), weekdays=[3], starts_time=time(15, 0), ends_time=time(18, 0))


def test_after_ends_on():
    from datetime import datetime
    assert not in_window(datetime(2024, 9, 15, 12, 0), weekdays=[], ends_on=date(2024, 9, 1))
