"""Promotion + coupon stacking rules."""


def can_stack(coupon_kind, promotion_kind):
    """One coupon + one promotion are stackable unless both are percent-off."""
    if coupon_kind == "percent" and promotion_kind == "happy_hour":
        return False
    return True


def test_amount_off_stacks_with_happy_hour():
    assert can_stack("amount", "happy_hour")


def test_percent_off_does_not_stack_with_happy_hour():
    assert not can_stack("percent", "happy_hour")


def test_bogo_stacks_with_seasonal():
    assert can_stack("bogo", "seasonal")
