from datetime import datetime, timedelta, timezone

import pytest

from apps.coupons.models import Coupon
from apps.coupons.services import discount_for, is_redeemable


def make_coupon(**kwargs):
    base = dict(
        restaurant_id="00000000-0000-0000-0000-000000000001",
        code="SAVE10",
        name="Save 10",
        kind="percent",
        percent_off=10,
        is_active=True,
    )
    base.update(kwargs)
    c = Coupon(**base)
    return c


def test_inactive_coupon_not_redeemable():
    assert not is_redeemable(make_coupon(is_active=False), subtotal_cents=10000)


def test_min_order_enforced():
    c = make_coupon(min_order_cents=2000)
    assert not is_redeemable(c, subtotal_cents=1500)
    assert is_redeemable(c, subtotal_cents=2000)


def test_uses_capped():
    c = make_coupon(max_uses=5, times_used=5)
    assert not is_redeemable(c, subtotal_cents=10000)


def test_percent_discount_math():
    assert discount_for(make_coupon(kind="percent", percent_off=10), subtotal_cents=10000) == 1000
    assert discount_for(make_coupon(kind="percent", percent_off=15), subtotal_cents=2333) == 350


def test_amount_off_caps_at_subtotal():
    c = make_coupon(kind="amount", amount_off_cents=2000)
    assert discount_for(c, subtotal_cents=1000) == 1000
    assert discount_for(c, subtotal_cents=5000) == 2000


def test_bogo_is_half_off():
    assert discount_for(make_coupon(kind="bogo"), subtotal_cents=2000) == 1000


def test_starts_at_in_future_blocks():
    future = datetime.now(tz=timezone.utc) + timedelta(days=1)
    c = make_coupon(starts_at=future)
    assert not is_redeemable(c, subtotal_cents=10000)
