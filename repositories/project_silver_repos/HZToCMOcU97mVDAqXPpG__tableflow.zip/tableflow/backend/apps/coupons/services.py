"""Coupon application logic."""
from __future__ import annotations

from datetime import datetime

from django.db import transaction
from django.utils import timezone
from rest_framework.exceptions import ValidationError

from .models import Coupon, CouponRedemption


def is_redeemable(coupon: Coupon, *, subtotal_cents: int, branch=None, now: datetime | None = None) -> bool:
    now = now or timezone.now()
    if not coupon.is_active:
        return False
    if coupon.starts_at and now < coupon.starts_at:
        return False
    if coupon.ends_at and now > coupon.ends_at:
        return False
    if coupon.max_uses and coupon.times_used >= coupon.max_uses:
        return False
    if subtotal_cents < coupon.min_order_cents:
        return False
    if branch and coupon.branches.exists() and not coupon.branches.filter(pk=branch.pk).exists():
        return False
    return True


def discount_for(coupon: Coupon, *, subtotal_cents: int) -> int:
    if coupon.kind == "percent":
        return int(round(subtotal_cents * float(coupon.percent_off) / 100))
    if coupon.kind == "amount":
        return min(subtotal_cents, coupon.amount_off_cents)
    if coupon.kind == "bogo":
        return subtotal_cents // 2  # naive 50% off
    return 0


@transaction.atomic
def apply(*, coupon: Coupon, order) -> CouponRedemption:
    if order.coupon_id and order.coupon_id != coupon.id:
        raise ValidationError({"coupon": "another-applied"})
    if not is_redeemable(coupon, subtotal_cents=order.subtotal_cents, branch=order.branch):
        raise ValidationError({"coupon": "not-redeemable"})
    discount = discount_for(coupon, subtotal_cents=order.subtotal_cents)
    if discount <= 0:
        raise ValidationError({"coupon": "no-discount"})
    redemption, _ = CouponRedemption.objects.get_or_create(
        coupon=coupon, order=order, defaults={"discount_cents": discount}
    )
    order.coupon = coupon
    order.discount_cents = discount
    order.save(update_fields=["coupon", "discount_cents", "updated_at"])
    coupon.times_used += 1
    coupon.save(update_fields=["times_used"])

    from apps.orders.services import recalculate_totals

    recalculate_totals(order)
    return redemption
