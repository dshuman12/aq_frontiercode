from rest_framework import serializers

from .models import Coupon, CouponRedemption, Promotion


class CouponSerializer(serializers.ModelSerializer):
    class Meta:
        model = Coupon
        fields = "__all__"
        read_only_fields = ["id", "restaurant_id", "times_used", "created_at"]


class PromotionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Promotion
        fields = "__all__"
        read_only_fields = ["id", "restaurant_id"]


class CouponRedemptionSerializer(serializers.ModelSerializer):
    class Meta:
        model = CouponRedemption
        fields = "__all__"
        read_only_fields = ["id", "discount_cents", "created_at"]


class ApplyCouponSerializer(serializers.Serializer):
    code = serializers.CharField(max_length=40)
    order = serializers.UUIDField()
