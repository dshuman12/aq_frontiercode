"""Coupon Celery tasks."""
from __future__ import annotations

from celery import shared_task
from django.utils import timezone

from .models import Coupon


@shared_task
def expire_old_coupons() -> int:
    now = timezone.now()
    return Coupon.objects.filter(is_active=True, ends_at__lt=now).update(is_active=False)
