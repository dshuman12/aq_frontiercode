from django.contrib import admin

from .models import Coupon, CouponRedemption, Promotion


@admin.register(Coupon)
class CouponAdmin(admin.ModelAdmin):
    list_display = ("code", "name", "kind", "is_active", "times_used", "max_uses", "ends_at")
    list_filter = ("is_active", "kind")
    search_fields = ("code", "name")


admin.site.register([Promotion, CouponRedemption])
