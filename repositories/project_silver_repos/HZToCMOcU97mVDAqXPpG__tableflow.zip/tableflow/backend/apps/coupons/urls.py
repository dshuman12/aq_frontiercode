from django.urls import path

from . import views

urlpatterns = [
    path("", views.CouponList.as_view()),
    path("<uuid:pk>", views.CouponDetail.as_view()),
    path("apply", views.ApplyCouponView.as_view()),
    path("promotions", views.PromotionList.as_view()),
]
