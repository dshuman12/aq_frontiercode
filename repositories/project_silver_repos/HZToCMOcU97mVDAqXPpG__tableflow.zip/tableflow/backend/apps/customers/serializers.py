from rest_framework import serializers

from .models import Customer, CustomerAddress, CustomerPreference, CustomerTag


class CustomerTagSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomerTag
        fields = "__all__"
        read_only_fields = ["id", "restaurant_id"]


class CustomerAddressSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomerAddress
        fields = "__all__"
        read_only_fields = ["id"]


class CustomerPreferenceSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomerPreference
        fields = "__all__"
        read_only_fields = ["id"]


class CustomerSerializer(serializers.ModelSerializer):
    addresses = CustomerAddressSerializer(many=True, read_only=True)
    preferences = CustomerPreferenceSerializer(read_only=True)
    display_name = serializers.CharField(read_only=True)

    class Meta:
        model = Customer
        fields = "__all__"
        read_only_fields = ["id", "restaurant_id", "last_seen_at", "created_at", "updated_at"]
