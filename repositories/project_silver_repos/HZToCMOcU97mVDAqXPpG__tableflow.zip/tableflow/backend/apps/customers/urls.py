from django.urls import path

from . import views

urlpatterns = [
    path("", views.CustomerList.as_view()),
    path("<uuid:pk>", views.CustomerDetail.as_view()),
    path("addresses", views.CustomerAddressList.as_view()),
    path("tags", views.CustomerTagList.as_view()),
]
