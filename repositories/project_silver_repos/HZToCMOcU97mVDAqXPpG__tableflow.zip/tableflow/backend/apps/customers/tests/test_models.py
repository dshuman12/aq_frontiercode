import pytest

from apps.customers.models import Customer


@pytest.mark.django_db
def test_display_name_uses_first_and_last():
    c = Customer.objects.create(restaurant_id="00000000-0000-0000-0000-000000000001", first_name="Ada", last_name="Lovelace")
    assert c.display_name == "Ada Lovelace"


@pytest.mark.django_db
def test_display_name_strips_when_no_last_name():
    c = Customer.objects.create(restaurant_id="00000000-0000-0000-0000-000000000001", first_name="Plato")
    assert c.display_name == "Plato"
