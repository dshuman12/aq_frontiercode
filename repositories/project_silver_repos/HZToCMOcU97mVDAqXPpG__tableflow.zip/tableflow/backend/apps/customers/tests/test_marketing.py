"""Marketing-list filter — pure logic."""


def list_for_blast(customers):
    """Customers who opted into email marketing AND have an email."""
    return [c for c in customers if c.get("marketing_opt_in_email") and c.get("email")]


def test_only_opted_in_with_email():
    rows = [
        {"email": "a@x.com", "marketing_opt_in_email": True},
        {"email": "b@x.com", "marketing_opt_in_email": False},
        {"email": "", "marketing_opt_in_email": True},
        {"marketing_opt_in_email": True},
    ]
    out = list_for_blast(rows)
    assert len(out) == 1
    assert out[0]["email"] == "a@x.com"


def test_empty_list_returns_empty():
    assert list_for_blast([]) == []
