"""Customer + Address + preferences + tags."""
from __future__ import annotations

import uuid

from django.conf import settings
from django.db import models


class CustomerTag(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(db_index=True)
    name = models.CharField(max_length=40)
    color = models.CharField(max_length=16, blank=True)

    class Meta:
        db_table = "customer_tag"
        unique_together = ("restaurant_id", "name")


class Customer(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(db_index=True)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="customer_records")
    first_name = models.CharField(max_length=80)
    last_name = models.CharField(max_length=80, blank=True)
    email = models.EmailField(blank=True)
    phone = models.CharField(max_length=32, blank=True)
    birthday = models.DateField(null=True, blank=True)
    notes = models.TextField(blank=True)
    tags = models.ManyToManyField(CustomerTag, blank=True, related_name="customers")
    marketing_opt_in_email = models.BooleanField(default=False)
    marketing_opt_in_sms = models.BooleanField(default=False)
    is_archived = models.BooleanField(default=False)
    last_seen_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "customer"
        indexes = [
            models.Index(fields=["restaurant_id", "phone"]),
            models.Index(fields=["restaurant_id", "email"]),
            models.Index(fields=["restaurant_id", "last_name", "first_name"]),
        ]

    @property
    def display_name(self) -> str:
        return f"{self.first_name} {self.last_name}".strip()


class CustomerAddress(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name="addresses")
    label = models.CharField(max_length=40, blank=True)
    line1 = models.CharField(max_length=200)
    line2 = models.CharField(max_length=120, blank=True)
    city = models.CharField(max_length=80)
    region = models.CharField(max_length=80, blank=True)
    country = models.CharField(max_length=40)
    postal_code = models.CharField(max_length=20)
    latitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    longitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    is_default = models.BooleanField(default=False)
    instructions = models.CharField(max_length=200, blank=True)

    class Meta:
        db_table = "customer_address"


class CustomerPreference(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    customer = models.OneToOneField(Customer, on_delete=models.CASCADE, related_name="preferences")
    favorite_items = models.JSONField(default=list)
    dietary_tags = models.JSONField(default=list)
    seating_preference = models.CharField(max_length=80, blank=True)
    notes = models.TextField(blank=True)
