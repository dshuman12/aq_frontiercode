"""Track last-seen on customers when an order is placed."""
from __future__ import annotations

from django.db.models.signals import post_save
from django.dispatch import receiver
from django.utils import timezone

from apps.orders.models import Order


@receiver(post_save, sender=Order)
def update_customer_last_seen(sender, instance: Order, created: bool, **kwargs):
    if not created or not instance.customer_id:
        return
    instance.customer.last_seen_at = timezone.now()
    instance.customer.save(update_fields=["last_seen_at"])
