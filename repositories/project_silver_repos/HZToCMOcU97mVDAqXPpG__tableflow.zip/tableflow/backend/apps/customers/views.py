from rest_framework import generics

from apps.accounts.permissions import perm

from .models import Customer, CustomerAddress, CustomerTag
from .serializers import (
    CustomerAddressSerializer,
    CustomerSerializer,
    CustomerTagSerializer,
)


class CustomerList(generics.ListCreateAPIView):
    serializer_class = CustomerSerializer
    permission_classes = [perm("customers:read")]
    search_fields = ["first_name", "last_name", "email", "phone"]
    filterset_fields = ["is_archived", "marketing_opt_in_email"]
    ordering = ["-created_at"]

    def get_queryset(self):  # type: ignore[override]
        return Customer.objects.filter(restaurant_id=self.request.restaurant_id).prefetch_related("addresses", "tags")

    def perform_create(self, serializer):  # type: ignore[override]
        serializer.save(restaurant_id=self.request.restaurant_id)


class CustomerDetail(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = CustomerSerializer
    permission_classes = [perm("customers:read")]

    def get_queryset(self):  # type: ignore[override]
        return Customer.objects.filter(restaurant_id=self.request.restaurant_id)

    def perform_destroy(self, instance):  # type: ignore[override]
        instance.is_archived = True
        instance.save(update_fields=["is_archived"])


class CustomerAddressList(generics.ListCreateAPIView):
    serializer_class = CustomerAddressSerializer
    permission_classes = [perm("customers:update")]
    filterset_fields = ["customer"]

    def get_queryset(self):  # type: ignore[override]
        return CustomerAddress.objects.filter(customer__restaurant_id=self.request.restaurant_id)


class CustomerTagList(generics.ListCreateAPIView):
    serializer_class = CustomerTagSerializer
    permission_classes = [perm("customers:read")]

    def get_queryset(self):  # type: ignore[override]
        return CustomerTag.objects.filter(restaurant_id=self.request.restaurant_id)

    def perform_create(self, serializer):  # type: ignore[override]
        serializer.save(restaurant_id=self.request.restaurant_id)
