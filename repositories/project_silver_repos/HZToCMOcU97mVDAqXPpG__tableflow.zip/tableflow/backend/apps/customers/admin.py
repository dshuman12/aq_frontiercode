from django.contrib import admin

from .models import Customer, CustomerAddress, CustomerPreference, CustomerTag


@admin.register(Customer)
class CustomerAdmin(admin.ModelAdmin):
    list_display = ("first_name", "last_name", "email", "phone", "marketing_opt_in_email", "is_archived")
    search_fields = ("first_name", "last_name", "email", "phone")
    list_filter = ("is_archived", "marketing_opt_in_email", "marketing_opt_in_sms")


admin.site.register([CustomerAddress, CustomerPreference, CustomerTag])
