from rest_framework import generics

from apps.accounts.permissions import perm

from .models import Branch
from .serializers import BranchSerializer


class BranchList(generics.ListCreateAPIView):
    serializer_class = BranchSerializer
    permission_classes = [perm("branches:read")]
    filterset_fields = ["is_active"]
    search_fields = ["name", "code", "city"]

    def get_queryset(self):  # type: ignore[override]
        return Branch.objects.filter(restaurant_id=self.request.restaurant_id)

    def perform_create(self, serializer):  # type: ignore[override]
        serializer.save(restaurant_id=self.request.restaurant_id)


class BranchDetail(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = BranchSerializer
    permission_classes = [perm("branches:read")]

    def get_queryset(self):  # type: ignore[override]
        return Branch.objects.filter(restaurant_id=self.request.restaurant_id)

    def perform_destroy(self, instance):  # type: ignore[override]
        from django.utils import timezone

        instance.archived_at = timezone.now()
        instance.is_active = False
        instance.save(update_fields=["archived_at", "is_active"])
