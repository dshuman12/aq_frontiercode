from django.urls import path

from . import views

urlpatterns = [
    path("", views.BranchList.as_view()),
    path("<uuid:pk>", views.BranchDetail.as_view()),
]
