from django.contrib import admin

from .models import Branch


@admin.register(Branch)
class BranchAdmin(admin.ModelAdmin):
    list_display = ("name", "code", "city", "phone", "pickup_enabled", "delivery_enabled", "is_active")
    list_filter = ("is_active", "pickup_enabled", "delivery_enabled")
    search_fields = ("name", "code", "city")
