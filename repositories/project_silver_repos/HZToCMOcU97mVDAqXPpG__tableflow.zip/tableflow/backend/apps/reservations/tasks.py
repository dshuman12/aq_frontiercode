"""Celery tasks: release unpaid reservations, send reminders."""
from __future__ import annotations

from datetime import timedelta

from celery import shared_task
from django.db import transaction
from django.utils import timezone

from .models import Reservation


@shared_task
def release_unpaid_reservations() -> int:
    """Cancel any 'requested' reservation older than 30 minutes whose deposit is unpaid."""
    cutoff = timezone.now() - timedelta(minutes=30)
    released = 0
    with transaction.atomic():
        qs = Reservation.objects.select_for_update().filter(
            status="requested",
            created_at__lt=cutoff,
            deposit_required_cents__gt=0,
        )
        for r in qs:
            if r.deposit_paid_cents < r.deposit_required_cents:
                r.status = "cancelled"
                r.cancelled_at = timezone.now()
                r.cancelled_reason = "unpaid-deposit"
                r.save(update_fields=["status", "cancelled_at", "cancelled_reason"])
                released += 1
    return released


@shared_task
def send_pending_reminders() -> int:
    """Send a reminder for confirmed reservations starting in the next 60 minutes."""
    now = timezone.now()
    upcoming = Reservation.objects.filter(
        status="confirmed",
        starts_at__lte=now + timedelta(minutes=60),
        starts_at__gte=now,
        reminder_sent_at__isnull=True,
    )
    count = 0
    for r in upcoming:
        from apps.notifications.tasks import send_reservation_reminder

        send_reservation_reminder.delay(str(r.id))
        r.reminder_sent_at = now
        r.save(update_fields=["reminder_sent_at"])
        count += 1
    return count
