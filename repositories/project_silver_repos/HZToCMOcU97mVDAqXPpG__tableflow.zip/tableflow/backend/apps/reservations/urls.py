from django.urls import path

from . import views

urlpatterns = [
    path("", views.ReservationList.as_view()),
    path("<uuid:pk>", views.ReservationDetail.as_view()),
    path("<uuid:pk>/transition", views.TransitionReservationView.as_view()),
    path("waitlist", views.WaitlistList.as_view()),
    path("waitlist/<uuid:pk>", views.WaitlistDetail.as_view()),
]
