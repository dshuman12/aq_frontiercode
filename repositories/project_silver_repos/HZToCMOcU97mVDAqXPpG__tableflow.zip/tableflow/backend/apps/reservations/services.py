"""Reservation services — booking, transitioning, conflict check."""
from __future__ import annotations

from datetime import timedelta

from django.db import transaction
from django.utils import timezone
from rest_framework.exceptions import ValidationError

from .models import Reservation, ReservationStatusHistory
from .transitions import can_transition


def overlaps(a_start, a_end, b_start, b_end) -> bool:
    """Half-open overlap test: [a_start, a_end) and [b_start, b_end)."""
    return a_start < b_end and b_start < a_end


@transaction.atomic
def book(*, restaurant_id, branch, customer_name, customer_phone, customer_email, party_size, starts_at, duration_minutes=90, table=None, source="online", created_by=None) -> Reservation:
    if party_size < 1:
        raise ValidationError({"party_size": "must be >= 1"})
    if starts_at < timezone.now():
        raise ValidationError({"starts_at": "must be in the future"})
    ends_at = starts_at + timedelta(minutes=duration_minutes)

    if table:
        if table.capacity < party_size:
            raise ValidationError({"table": "capacity-too-small"})
        clashes = Reservation.objects.filter(
            restaurant_id=restaurant_id,
            table=table,
            status__in=["requested", "confirmed", "seated"],
        )
        for r in clashes:
            r_end = r.starts_at + timedelta(minutes=r.duration_minutes)
            if overlaps(starts_at, ends_at, r.starts_at, r_end):
                raise ValidationError({"table": f"conflict-with:{r.id}"})

    return Reservation.objects.create(
        restaurant_id=restaurant_id,
        branch=branch,
        table=table,
        customer_name=customer_name,
        customer_phone=customer_phone,
        customer_email=customer_email,
        party_size=party_size,
        starts_at=starts_at,
        duration_minutes=duration_minutes,
        source=source,
        created_by=created_by,
    )


@transaction.atomic
def transition(reservation: Reservation, *, to_status: str, by, note: str = "") -> Reservation:
    if not can_transition(reservation.status, to_status):
        raise ValidationError({"status": f"illegal-transition:{reservation.status}->{to_status}"})
    ReservationStatusHistory.objects.create(
        reservation=reservation,
        previous_status=reservation.status,
        new_status=to_status,
        changed_by=by if getattr(by, "is_authenticated", False) else None,
        note=note,
    )
    reservation.status = to_status
    now = timezone.now()
    if to_status == "confirmed":
        reservation.confirmed_at = now
    elif to_status == "seated":
        reservation.seated_at = now
    elif to_status == "completed":
        reservation.completed_at = now
    elif to_status == "cancelled":
        reservation.cancelled_at = now
    reservation.save()
    return reservation
