from datetime import datetime, timedelta, timezone

import pytest


def overlap(a_start, a_end, b_start, b_end):
    return a_start < b_end and b_start < a_end


def test_back_to_back_does_not_conflict():
    a = (datetime(2024, 8, 15, 18, 0), datetime(2024, 8, 15, 19, 30))
    b = (datetime(2024, 8, 15, 19, 30), datetime(2024, 8, 15, 21, 0))
    assert not overlap(*a, *b)


def test_partial_overlap_blocks_booking():
    a = (datetime(2024, 8, 15, 18, 0), datetime(2024, 8, 15, 19, 30))
    b = (datetime(2024, 8, 15, 19, 0), datetime(2024, 8, 15, 20, 30))
    assert overlap(*a, *b)


def test_party_too_large_for_table_is_rejected():
    capacity, party = 4, 6
    assert party > capacity


def test_reservation_in_past_is_rejected():
    starts = datetime.now(tz=timezone.utc) - timedelta(hours=1)
    assert starts < datetime.now(tz=timezone.utc)
