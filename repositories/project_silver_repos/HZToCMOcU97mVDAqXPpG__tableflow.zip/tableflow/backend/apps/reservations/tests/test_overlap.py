from datetime import datetime, timedelta

from apps.reservations.services import overlaps


def at(s: str) -> datetime:
    return datetime.fromisoformat(s)


def test_back_to_back_does_not_overlap():
    # half-open: 10:00–11:00 and 11:00–12:00 are NOT overlapping
    assert not overlaps(at("2024-08-15T10:00"), at("2024-08-15T11:00"), at("2024-08-15T11:00"), at("2024-08-15T12:00"))


def test_partial_overlap_detected():
    assert overlaps(at("2024-08-15T10:00"), at("2024-08-15T11:30"), at("2024-08-15T11:00"), at("2024-08-15T12:00"))


def test_one_inside_the_other():
    assert overlaps(at("2024-08-15T10:00"), at("2024-08-15T13:00"), at("2024-08-15T11:00"), at("2024-08-15T12:00"))


def test_disjoint_returns_false():
    assert not overlaps(at("2024-08-15T10:00"), at("2024-08-15T11:00"), at("2024-08-15T13:00"), at("2024-08-15T14:00"))
