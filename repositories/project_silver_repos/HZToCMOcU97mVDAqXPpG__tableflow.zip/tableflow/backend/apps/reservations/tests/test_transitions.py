import pytest

from apps.reservations.transitions import can_transition


def test_happy_path():
    seq = ["requested", "confirmed", "seated", "completed"]
    for a, b in zip(seq, seq[1:]):
        assert can_transition(a, b)


def test_can_no_show_from_confirmed():
    assert can_transition("confirmed", "no_show")


def test_cannot_transition_from_terminal():
    for terminal in ("completed", "cancelled", "no_show"):
        assert not can_transition(terminal, "confirmed")


def test_cannot_skip_confirmation():
    assert not can_transition("requested", "seated")
