"""No-show flagging is a derivation, not a stored field — verify the logic here."""
from datetime import datetime, timedelta


def is_late(now, starts_at, late_minutes=10):
    return now > starts_at + timedelta(minutes=late_minutes)


def is_no_show_candidate(now, starts_at, status, no_show_minutes=20):
    if status not in ("requested", "confirmed"):
        return False
    return now > starts_at + timedelta(minutes=no_show_minutes)


def test_late_after_grace_period():
    starts = datetime(2024, 8, 15, 18, 0)
    assert not is_late(starts + timedelta(minutes=9), starts)
    assert is_late(starts + timedelta(minutes=11), starts)


def test_no_show_only_for_pending_states():
    starts = datetime(2024, 8, 15, 18, 0)
    now = starts + timedelta(minutes=25)
    assert is_no_show_candidate(now, starts, "confirmed")
    assert is_no_show_candidate(now, starts, "requested")
    assert not is_no_show_candidate(now, starts, "seated")
    assert not is_no_show_candidate(now, starts, "completed")


def test_inside_window_not_no_show():
    starts = datetime(2024, 8, 15, 18, 0)
    now = starts + timedelta(minutes=15)
    assert not is_no_show_candidate(now, starts, "confirmed", no_show_minutes=20)
