"""Reservation lifecycle signals."""
from __future__ import annotations

from django.db.models.signals import post_save
from django.dispatch import receiver

from .models import Reservation, ReservationStatusHistory


@receiver(post_save, sender=Reservation)
def emit_initial_history(sender, instance: Reservation, created: bool, **kwargs):
    if not created:
        return
    ReservationStatusHistory.objects.create(
        reservation=instance, previous_status="", new_status=instance.status, note="initial",
    )


@receiver(post_save, sender=ReservationStatusHistory)
def emit_audit_on_transition(sender, instance: ReservationStatusHistory, created: bool, **kwargs):
    if not created:
        return
    from apps.audit_logs.models import AuditLog
    AuditLog.objects.create(
        restaurant_id=instance.reservation.restaurant_id,
        action=f"reservation.{instance.new_status}",
        resource="reservation",
        resource_id=str(instance.reservation_id),
        diff={"from": instance.previous_status, "to": instance.new_status, "note": instance.note},
    )
