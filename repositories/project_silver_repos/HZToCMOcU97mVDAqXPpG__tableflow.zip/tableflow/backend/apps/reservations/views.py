from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.accounts.permissions import perm
from apps.branches.models import Branch
from apps.tables.models import RestaurantTable

from . import services
from .models import Reservation, WaitlistEntry
from .serializers import (
    CreateReservationSerializer,
    ReservationSerializer,
    TransitionSerializer,
    WaitlistEntrySerializer,
)


class ReservationList(generics.ListCreateAPIView):
    permission_classes = [perm("reservations:read")]
    serializer_class = ReservationSerializer
    filterset_fields = ["branch", "status", "table", "source"]
    search_fields = ["customer_name", "customer_phone", "customer_email"]
    ordering = ["starts_at"]

    def get_queryset(self):  # type: ignore[override]
        qs = Reservation.objects.filter(restaurant_id=self.request.restaurant_id)
        date_from = self.request.query_params.get("from")
        date_to = self.request.query_params.get("to")
        if date_from:
            qs = qs.filter(starts_at__gte=date_from)
        if date_to:
            qs = qs.filter(starts_at__lte=date_to)
        return qs

    def create(self, request, *args, **kwargs):  # type: ignore[override]
        serializer = CreateReservationSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data
        branch = Branch.objects.get(pk=data["branch"], restaurant_id=request.restaurant_id)
        table = None
        if data.get("table"):
            table = RestaurantTable.objects.get(pk=data["table"], restaurant_id=request.restaurant_id)
        r = services.book(
            restaurant_id=request.restaurant_id,
            branch=branch,
            table=table,
            customer_name=data["customer_name"],
            customer_phone=data.get("customer_phone", ""),
            customer_email=data.get("customer_email", ""),
            party_size=data["party_size"],
            starts_at=data["starts_at"],
            duration_minutes=data.get("duration_minutes", 90),
            source=data.get("source", "online"),
            created_by=request.user if request.user.is_authenticated else None,
        )
        return Response(ReservationSerializer(r).data, status=status.HTTP_201_CREATED)


class ReservationDetail(generics.RetrieveUpdateDestroyAPIView):
    permission_classes = [perm("reservations:read")]
    serializer_class = ReservationSerializer

    def get_queryset(self):  # type: ignore[override]
        return Reservation.objects.filter(restaurant_id=self.request.restaurant_id)


class TransitionReservationView(APIView):
    permission_classes = [perm("reservations:update")]

    def post(self, request, pk):
        try:
            r = Reservation.objects.get(pk=pk, restaurant_id=request.restaurant_id)
        except Reservation.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)
        serializer = TransitionSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        services.transition(r, to_status=serializer.validated_data["to_status"], by=request.user, note=serializer.validated_data.get("note", ""))
        return Response(ReservationSerializer(r).data)


class WaitlistList(generics.ListCreateAPIView):
    permission_classes = [perm("reservations:read")]
    serializer_class = WaitlistEntrySerializer
    filterset_fields = ["branch", "status"]

    def get_queryset(self):  # type: ignore[override]
        return WaitlistEntry.objects.filter(restaurant_id=self.request.restaurant_id)

    def perform_create(self, serializer):  # type: ignore[override]
        serializer.save(restaurant_id=self.request.restaurant_id)


class WaitlistDetail(generics.RetrieveUpdateDestroyAPIView):
    permission_classes = [perm("reservations:read")]
    serializer_class = WaitlistEntrySerializer

    def get_queryset(self):  # type: ignore[override]
        return WaitlistEntry.objects.filter(restaurant_id=self.request.restaurant_id)
