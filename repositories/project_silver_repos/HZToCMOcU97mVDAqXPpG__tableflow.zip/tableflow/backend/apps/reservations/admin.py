from django.contrib import admin

from .models import Reservation, ReservationDeposit, ReservationStatusHistory, WaitlistEntry


@admin.register(Reservation)
class ReservationAdmin(admin.ModelAdmin):
    list_display = ("customer_name", "starts_at", "party_size", "branch", "status")
    list_filter = ("status", "branch", "source")
    search_fields = ("customer_name", "customer_phone", "customer_email")
    date_hierarchy = "starts_at"


admin.site.register([ReservationStatusHistory, WaitlistEntry, ReservationDeposit])
