"""Reservation state machine."""
from __future__ import annotations

TRANSITIONS: dict[str, list[str]] = {
    "requested": ["confirmed", "cancelled"],
    "confirmed": ["seated", "cancelled", "no_show"],
    "seated": ["completed", "cancelled"],
    "completed": [],
    "cancelled": [],
    "no_show": [],
}


def can_transition(from_status: str, to_status: str) -> bool:
    return to_status in TRANSITIONS.get(from_status, [])
