"""Reservation, ReservationStatusHistory, WaitlistEntry, ReservationDeposit."""
from __future__ import annotations

import uuid

from django.conf import settings
from django.db import models


class Reservation(models.Model):
    STATUS_CHOICES = [
        ("requested", "Requested"),
        ("confirmed", "Confirmed"),
        ("seated", "Seated"),
        ("completed", "Completed"),
        ("cancelled", "Cancelled"),
        ("no_show", "No-show"),
    ]
    SOURCE_CHOICES = [
        ("phone", "Phone"),
        ("walk_in", "Walk-in"),
        ("online", "Online"),
        ("staff", "Staff"),
    ]
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(db_index=True)
    branch = models.ForeignKey("branches.Branch", on_delete=models.CASCADE, related_name="reservations")
    table = models.ForeignKey("tables.RestaurantTable", null=True, blank=True, on_delete=models.SET_NULL, related_name="reservations")
    customer = models.ForeignKey("customers.Customer", null=True, blank=True, on_delete=models.SET_NULL, related_name="reservations")
    customer_name = models.CharField(max_length=120)
    customer_phone = models.CharField(max_length=32, blank=True)
    customer_email = models.EmailField(blank=True)
    party_size = models.PositiveSmallIntegerField()
    starts_at = models.DateTimeField(db_index=True)
    duration_minutes = models.PositiveSmallIntegerField(default=90)
    source = models.CharField(max_length=12, choices=SOURCE_CHOICES, default="online")
    status = models.CharField(max_length=12, choices=STATUS_CHOICES, default="requested", db_index=True)
    notes = models.TextField(blank=True)
    deposit_required_cents = models.PositiveIntegerField(default=0)
    deposit_paid_cents = models.PositiveIntegerField(default=0)
    confirmed_at = models.DateTimeField(null=True, blank=True)
    seated_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    cancelled_at = models.DateTimeField(null=True, blank=True)
    cancelled_reason = models.CharField(max_length=200, blank=True)
    reminder_sent_at = models.DateTimeField(null=True, blank=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "reservation"
        indexes = [
            models.Index(fields=["restaurant_id", "branch", "starts_at"]),
            models.Index(fields=["restaurant_id", "status"]),
        ]

    @property
    def deposit_complete(self) -> bool:
        return self.deposit_required_cents == 0 or self.deposit_paid_cents >= self.deposit_required_cents


class ReservationStatusHistory(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    reservation = models.ForeignKey(Reservation, on_delete=models.CASCADE, related_name="status_history")
    previous_status = models.CharField(max_length=12, blank=True)
    new_status = models.CharField(max_length=12)
    changed_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL)
    changed_at = models.DateTimeField(auto_now_add=True)
    note = models.CharField(max_length=200, blank=True)


class WaitlistEntry(models.Model):
    STATUS_CHOICES = [
        ("waiting", "Waiting"),
        ("notified", "Notified"),
        ("seated", "Seated"),
        ("left", "Left"),
        ("expired", "Expired"),
    ]
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(db_index=True)
    branch = models.ForeignKey("branches.Branch", on_delete=models.CASCADE, related_name="waitlist")
    customer_name = models.CharField(max_length=120)
    customer_phone = models.CharField(max_length=32, blank=True)
    party_size = models.PositiveSmallIntegerField()
    quoted_minutes = models.PositiveSmallIntegerField(default=15)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default="waiting", db_index=True)
    created_at = models.DateTimeField(auto_now_add=True)
    notified_at = models.DateTimeField(null=True, blank=True)
    seated_at = models.DateTimeField(null=True, blank=True)
    notes = models.CharField(max_length=200, blank=True)


class ReservationDeposit(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    reservation = models.ForeignKey(Reservation, on_delete=models.CASCADE, related_name="deposits")
    amount_cents = models.PositiveIntegerField()
    method = models.CharField(max_length=20, default="card")
    stripe_payment_intent_id = models.CharField(max_length=120, blank=True)
    captured_at = models.DateTimeField(null=True, blank=True)
    refunded_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
