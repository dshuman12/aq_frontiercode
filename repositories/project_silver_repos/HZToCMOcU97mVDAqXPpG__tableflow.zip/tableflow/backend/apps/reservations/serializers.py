from rest_framework import serializers

from .models import Reservation, ReservationDeposit, ReservationStatusHistory, WaitlistEntry


class ReservationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Reservation
        fields = "__all__"
        read_only_fields = [
            "id", "restaurant_id", "status", "confirmed_at", "seated_at", "completed_at",
            "cancelled_at", "deposit_paid_cents", "reminder_sent_at", "created_at", "updated_at",
        ]


class CreateReservationSerializer(serializers.Serializer):
    branch = serializers.UUIDField()
    table = serializers.UUIDField(required=False, allow_null=True)
    customer_name = serializers.CharField(max_length=120)
    customer_phone = serializers.CharField(max_length=32, required=False, allow_blank=True)
    customer_email = serializers.EmailField(required=False, allow_blank=True)
    party_size = serializers.IntegerField(min_value=1, max_value=40)
    starts_at = serializers.DateTimeField()
    duration_minutes = serializers.IntegerField(min_value=15, max_value=480, default=90)
    source = serializers.ChoiceField(choices=[c[0] for c in Reservation.SOURCE_CHOICES], default="online")
    notes = serializers.CharField(required=False, allow_blank=True, max_length=1000)


class TransitionSerializer(serializers.Serializer):
    to_status = serializers.ChoiceField(choices=[c[0] for c in Reservation.STATUS_CHOICES])
    note = serializers.CharField(required=False, allow_blank=True, max_length=200)


class WaitlistEntrySerializer(serializers.ModelSerializer):
    class Meta:
        model = WaitlistEntry
        fields = "__all__"
        read_only_fields = ["id", "restaurant_id", "created_at", "notified_at", "seated_at"]


class ReservationDepositSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReservationDeposit
        fields = "__all__"
