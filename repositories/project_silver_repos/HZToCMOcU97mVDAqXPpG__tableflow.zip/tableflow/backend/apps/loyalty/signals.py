"""Auto-create a loyalty account when a customer is created."""
from __future__ import annotations

from django.db.models.signals import post_save
from django.dispatch import receiver

from apps.customers.models import Customer

from .models import LoyaltyAccount


@receiver(post_save, sender=Customer)
def create_loyalty_account(sender, instance: Customer, created: bool, **kwargs):
    if not created:
        return
    LoyaltyAccount.objects.get_or_create(
        restaurant_id=instance.restaurant_id, customer=instance,
    )
