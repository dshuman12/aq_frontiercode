from django.urls import path

from . import views

urlpatterns = [
    path("accounts", views.AccountList.as_view()),
    path("accounts/<uuid:pk>", views.AccountDetail.as_view()),
    path("transactions", views.TransactionList.as_view()),
    path("rewards", views.RewardList.as_view()),
    path("rewards/<uuid:pk>", views.RewardDetail.as_view()),
    path("adjust", views.AdjustView.as_view()),
    path("redeem", views.RedeemView.as_view()),
]
