from django.contrib import admin

from .models import LoyaltyAccount, LoyaltyTransaction, Reward, RewardRedemption


@admin.register(LoyaltyAccount)
class LoyaltyAccountAdmin(admin.ModelAdmin):
    list_display = ("customer", "tier", "points_balance", "lifetime_points", "visits")
    list_filter = ("tier",)


@admin.register(Reward)
class RewardAdmin(admin.ModelAdmin):
    list_display = ("name", "kind", "cost_points", "is_active")
    list_filter = ("kind", "is_active")


admin.site.register([LoyaltyTransaction, RewardRedemption])
