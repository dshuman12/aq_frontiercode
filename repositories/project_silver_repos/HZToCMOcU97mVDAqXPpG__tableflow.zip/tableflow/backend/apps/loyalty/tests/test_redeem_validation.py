"""Validate the redemption preconditions."""


def can_redeem(*, points_balance, reward_cost, reward_active):
    if not reward_active:
        return False
    if reward_cost <= 0:
        return False
    return points_balance >= reward_cost


def test_happy_path():
    assert can_redeem(points_balance=100, reward_cost=50, reward_active=True)


def test_insufficient_points():
    assert not can_redeem(points_balance=10, reward_cost=50, reward_active=True)


def test_inactive_reward_blocked():
    assert not can_redeem(points_balance=1000, reward_cost=50, reward_active=False)


def test_zero_cost_reward_blocked():
    assert not can_redeem(points_balance=1000, reward_cost=0, reward_active=True)


def test_exact_balance_allowed():
    assert can_redeem(points_balance=50, reward_cost=50, reward_active=True)
