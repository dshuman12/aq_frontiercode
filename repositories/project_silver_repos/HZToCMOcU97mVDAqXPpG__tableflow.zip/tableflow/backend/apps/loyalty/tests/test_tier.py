from apps.loyalty.services import TIER_THRESHOLDS, points_for_order, tier_for_lifetime


def test_thresholds_are_in_order():
    last = -1
    for _, threshold in TIER_THRESHOLDS:
        assert threshold > last
        last = threshold


def test_no_points_for_sub_dollar_orders():
    for cents in (0, 1, 50, 99):
        assert points_for_order(cents) == 0


def test_promotion_at_each_tier():
    for tier, threshold in TIER_THRESHOLDS:
        assert tier_for_lifetime(threshold) == tier


def test_huge_balance_promotes_to_top():
    assert tier_for_lifetime(10**9) == TIER_THRESHOLDS[-1][0]
