from decimal import Decimal

from apps.loyalty.services import points_for_order


def test_earn_simple():
    assert points_for_order(2500) == 25  # $25.00 → 25 points


def test_earn_truncates_partial_dollars():
    assert points_for_order(2599) == 25
    assert points_for_order(2500) == 25
    assert points_for_order(2400) == 24


def test_earn_negative_returns_zero():
    # The function uses max(0, ...) so negatives are zero
    assert points_for_order(-100) == 0
