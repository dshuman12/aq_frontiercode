from apps.loyalty.services import points_for_order, tier_for_lifetime


def test_points_for_order_one_per_dollar():
    assert points_for_order(1000) == 10
    assert points_for_order(99) == 0
    assert points_for_order(150) == 1


def test_tier_thresholds():
    assert tier_for_lifetime(0) == "bronze"
    assert tier_for_lifetime(499) == "bronze"
    assert tier_for_lifetime(500) == "silver"
    assert tier_for_lifetime(2000) == "gold"
    assert tier_for_lifetime(50_000) == "platinum"
