from datetime import date

from apps.loyalty.birthday import already_redeemed_this_year, is_birthday_window


def test_inside_default_window():
    assert is_birthday_window(date(2024, 8, 17), date(1990, 8, 15))


def test_outside_window():
    assert not is_birthday_window(date(2024, 9, 30), date(1990, 8, 15))


def test_no_birthday_returns_false():
    assert not is_birthday_window(date(2024, 8, 15), None)


def test_redeemed_lookup():
    txs = [{"kind": "earn", "note": "birthday-2024", "year": 2024}]
    assert already_redeemed_this_year(txs, 2024)
    assert not already_redeemed_this_year(txs, 2025)
