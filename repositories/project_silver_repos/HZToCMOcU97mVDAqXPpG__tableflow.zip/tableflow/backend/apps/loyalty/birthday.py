"""Birthday reward eligibility — pure logic."""
from __future__ import annotations

from datetime import date


def is_birthday_window(today: date, birthday: date | None, *, days_before: int = 0, days_after: int = 7) -> bool:
    """True when `today` falls within [birthday - days_before, birthday + days_after] for the year."""
    if not birthday:
        return False
    this_year_birthday = birthday.replace(year=today.year)
    delta = (today - this_year_birthday).days
    return -days_before <= delta <= days_after


def already_redeemed_this_year(transactions: list[dict], year: int) -> bool:
    return any(
        t.get("kind") == "earn" and t.get("note", "").startswith("birthday") and t.get("year") == year
        for t in transactions
    )
