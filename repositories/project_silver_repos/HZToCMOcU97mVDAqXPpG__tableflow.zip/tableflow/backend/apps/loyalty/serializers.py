from rest_framework import serializers

from .models import LoyaltyAccount, LoyaltyTransaction, Reward, RewardRedemption


class LoyaltyAccountSerializer(serializers.ModelSerializer):
    class Meta:
        model = LoyaltyAccount
        fields = "__all__"
        read_only_fields = ["id", "restaurant_id", "tier", "lifetime_points", "visits", "last_activity_at", "created_at"]


class LoyaltyTransactionSerializer(serializers.ModelSerializer):
    class Meta:
        model = LoyaltyTransaction
        fields = "__all__"
        read_only_fields = ["id", "created_at"]


class RewardSerializer(serializers.ModelSerializer):
    class Meta:
        model = Reward
        fields = "__all__"
        read_only_fields = ["id", "restaurant_id"]


class RewardRedemptionSerializer(serializers.ModelSerializer):
    class Meta:
        model = RewardRedemption
        fields = "__all__"
        read_only_fields = ["id", "redeemed_at"]


class AdjustPointsSerializer(serializers.Serializer):
    customer = serializers.UUIDField()
    points = serializers.IntegerField()
    note = serializers.CharField(required=False, allow_blank=True, max_length=200)


class RedeemRewardSerializer(serializers.Serializer):
    customer = serializers.UUIDField()
    reward = serializers.UUIDField()
    order = serializers.UUIDField(required=False, allow_null=True)
