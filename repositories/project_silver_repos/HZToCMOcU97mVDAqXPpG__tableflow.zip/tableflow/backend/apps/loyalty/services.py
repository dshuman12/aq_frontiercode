"""Loyalty: earning rules, redemption, tier promotion."""
from __future__ import annotations

from django.db import transaction
from django.utils import timezone
from rest_framework.exceptions import ValidationError

from .models import LoyaltyAccount, LoyaltyTransaction, Reward, RewardRedemption

POINTS_PER_DOLLAR = 1
TIER_THRESHOLDS = [("bronze", 0), ("silver", 500), ("gold", 2000), ("platinum", 10000)]


def points_for_order(amount_cents: int) -> int:
    return max(0, (amount_cents // 100) * POINTS_PER_DOLLAR)


def tier_for_lifetime(points: int) -> str:
    cur = "bronze"
    for tier, threshold in TIER_THRESHOLDS:
        if points >= threshold:
            cur = tier
    return cur


@transaction.atomic
def earn(*, account: LoyaltyAccount, order, amount_cents: int, by=None) -> LoyaltyTransaction:
    pts = points_for_order(amount_cents)
    tx = LoyaltyTransaction.objects.create(
        account=account, kind="earn", points=pts, order=order, created_by=by if getattr(by, "is_authenticated", False) else None
    )
    account.points_balance += pts
    account.lifetime_points += pts
    account.visits += 1
    account.tier = tier_for_lifetime(account.lifetime_points)
    account.last_activity_at = timezone.now()
    account.save(update_fields=["points_balance", "lifetime_points", "visits", "tier", "last_activity_at"])
    return tx


@transaction.atomic
def redeem(*, account: LoyaltyAccount, reward: Reward, order=None, by=None) -> RewardRedemption:
    if reward.cost_points <= 0:
        raise ValidationError({"reward": "invalid-cost"})
    if account.points_balance < reward.cost_points:
        raise ValidationError({"points": "insufficient"})
    if not reward.is_active:
        raise ValidationError({"reward": "inactive"})
    LoyaltyTransaction.objects.create(
        account=account, kind="redeem", points=-reward.cost_points, order=order, reward=reward,
        created_by=by if getattr(by, "is_authenticated", False) else None,
    )
    account.points_balance -= reward.cost_points
    account.last_activity_at = timezone.now()
    account.save(update_fields=["points_balance", "last_activity_at"])
    return RewardRedemption.objects.create(
        account=account, reward=reward, order=order, points_spent=reward.cost_points,
    )


@transaction.atomic
def adjust(*, account: LoyaltyAccount, points: int, note: str = "", by=None) -> LoyaltyTransaction:
    tx = LoyaltyTransaction.objects.create(
        account=account, kind="adjust", points=points, note=note,
        created_by=by if getattr(by, "is_authenticated", False) else None,
    )
    account.points_balance += points
    if points > 0:
        account.lifetime_points += points
    account.tier = tier_for_lifetime(account.lifetime_points)
    account.last_activity_at = timezone.now()
    account.save()
    return tx
