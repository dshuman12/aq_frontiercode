"""LoyaltyAccount, LoyaltyTransaction, Reward, RewardRedemption."""
from __future__ import annotations

import uuid

from django.conf import settings
from django.db import models


class LoyaltyAccount(models.Model):
    TIER_CHOICES = [
        ("bronze", "Bronze"),
        ("silver", "Silver"),
        ("gold", "Gold"),
        ("platinum", "Platinum"),
    ]
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(db_index=True)
    customer = models.OneToOneField("customers.Customer", on_delete=models.CASCADE, related_name="loyalty")
    tier = models.CharField(max_length=10, choices=TIER_CHOICES, default="bronze")
    points_balance = models.IntegerField(default=0)
    lifetime_points = models.PositiveIntegerField(default=0)
    visits = models.PositiveIntegerField(default=0)
    last_activity_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "loyalty_account"
        indexes = [models.Index(fields=["restaurant_id", "tier"])]


class LoyaltyTransaction(models.Model):
    KIND_CHOICES = [
        ("earn", "Earn"),
        ("redeem", "Redeem"),
        ("adjust", "Adjust"),
        ("expire", "Expire"),
    ]
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    account = models.ForeignKey(LoyaltyAccount, on_delete=models.CASCADE, related_name="transactions")
    kind = models.CharField(max_length=8, choices=KIND_CHOICES)
    points = models.IntegerField()  # positive earn, negative redeem
    order = models.ForeignKey("orders.Order", null=True, blank=True, on_delete=models.SET_NULL)
    reward = models.ForeignKey("loyalty.Reward", null=True, blank=True, on_delete=models.SET_NULL)
    note = models.CharField(max_length=200, blank=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "loyalty_transaction"
        ordering = ["-created_at"]


class Reward(models.Model):
    KIND_CHOICES = [
        ("free_item", "Free item"),
        ("percent_off", "Percent off"),
        ("amount_off", "Amount off"),
        ("free_delivery", "Free delivery"),
    ]
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(db_index=True)
    name = models.CharField(max_length=120)
    kind = models.CharField(max_length=14, choices=KIND_CHOICES)
    cost_points = models.PositiveIntegerField()
    value_cents = models.PositiveIntegerField(default=0)
    percent_off = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    menu_item = models.ForeignKey("menus.MenuItem", null=True, blank=True, on_delete=models.SET_NULL)
    is_active = models.BooleanField(default=True)
    description = models.CharField(max_length=200, blank=True)

    class Meta:
        db_table = "loyalty_reward"


class RewardRedemption(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    account = models.ForeignKey(LoyaltyAccount, on_delete=models.CASCADE, related_name="redemptions")
    reward = models.ForeignKey(Reward, on_delete=models.PROTECT)
    order = models.ForeignKey("orders.Order", null=True, blank=True, on_delete=models.SET_NULL, related_name="reward_redemptions")
    points_spent = models.PositiveIntegerField()
    redeemed_at = models.DateTimeField(auto_now_add=True)
    voided_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "loyalty_redemption"
