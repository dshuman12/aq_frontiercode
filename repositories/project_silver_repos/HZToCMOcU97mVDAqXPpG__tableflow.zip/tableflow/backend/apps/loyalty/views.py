from rest_framework import generics
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.accounts.permissions import perm
from apps.customers.models import Customer
from apps.orders.models import Order

from . import services
from .models import LoyaltyAccount, LoyaltyTransaction, Reward, RewardRedemption
from .serializers import (
    AdjustPointsSerializer,
    LoyaltyAccountSerializer,
    LoyaltyTransactionSerializer,
    RedeemRewardSerializer,
    RewardRedemptionSerializer,
    RewardSerializer,
)


class AccountList(generics.ListAPIView):
    serializer_class = LoyaltyAccountSerializer
    permission_classes = [perm("loyalty:read")]
    filterset_fields = ["tier"]
    ordering = ["-points_balance"]

    def get_queryset(self):  # type: ignore[override]
        return LoyaltyAccount.objects.filter(restaurant_id=self.request.restaurant_id).select_related("customer")


class AccountDetail(generics.RetrieveAPIView):
    serializer_class = LoyaltyAccountSerializer
    permission_classes = [perm("loyalty:read")]

    def get_queryset(self):  # type: ignore[override]
        return LoyaltyAccount.objects.filter(restaurant_id=self.request.restaurant_id)


class TransactionList(generics.ListAPIView):
    serializer_class = LoyaltyTransactionSerializer
    permission_classes = [perm("loyalty:read")]
    filterset_fields = ["account", "kind"]
    ordering = ["-created_at"]

    def get_queryset(self):  # type: ignore[override]
        return LoyaltyTransaction.objects.filter(account__restaurant_id=self.request.restaurant_id)


class RewardList(generics.ListCreateAPIView):
    serializer_class = RewardSerializer
    permission_classes = [perm("loyalty:read")]

    def get_queryset(self):  # type: ignore[override]
        return Reward.objects.filter(restaurant_id=self.request.restaurant_id)

    def perform_create(self, serializer):  # type: ignore[override]
        serializer.save(restaurant_id=self.request.restaurant_id)


class RewardDetail(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = RewardSerializer
    permission_classes = [perm("loyalty:read")]

    def get_queryset(self):  # type: ignore[override]
        return Reward.objects.filter(restaurant_id=self.request.restaurant_id)


class AdjustView(APIView):
    permission_classes = [perm("loyalty:adjust")]

    def post(self, request):
        serializer = AdjustPointsSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        d = serializer.validated_data
        customer = Customer.objects.get(pk=d["customer"], restaurant_id=request.restaurant_id)
        account, _ = LoyaltyAccount.objects.get_or_create(
            restaurant_id=request.restaurant_id, customer=customer
        )
        services.adjust(account=account, points=d["points"], note=d.get("note", ""), by=request.user)
        return Response(LoyaltyAccountSerializer(account).data)


class RedeemView(APIView):
    permission_classes = [perm("loyalty:adjust")]

    def post(self, request):
        serializer = RedeemRewardSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        d = serializer.validated_data
        customer = Customer.objects.get(pk=d["customer"], restaurant_id=request.restaurant_id)
        reward = Reward.objects.get(pk=d["reward"], restaurant_id=request.restaurant_id)
        account = LoyaltyAccount.objects.get(restaurant_id=request.restaurant_id, customer=customer)
        order = Order.objects.get(pk=d["order"], restaurant_id=request.restaurant_id) if d.get("order") else None
        red = services.redeem(account=account, reward=reward, order=order, by=request.user)
        return Response(RewardRedemptionSerializer(red).data)
