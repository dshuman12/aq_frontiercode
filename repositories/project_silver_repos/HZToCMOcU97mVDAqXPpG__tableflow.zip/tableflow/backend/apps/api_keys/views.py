from django.utils import timezone
from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.accounts.permissions import perm
from apps.audit_logs.services import record as audit

from .models import ApiKey
from .serializers import ApiKeySerializer, CreateApiKeySerializer


class ApiKeyListView(generics.ListAPIView):
    serializer_class = ApiKeySerializer
    permission_classes = [perm("api-keys:read")]
    ordering = ["-created_at"]

    def get_queryset(self):  # type: ignore[override]
        return ApiKey.objects.filter(restaurant_id=self.request.restaurant_id)


class ApiKeyCreateView(APIView):
    permission_classes = [perm("api-keys:create")]

    def post(self, request):
        serializer = CreateApiKeySerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        key, token = ApiKey.issue(
            restaurant_id=request.restaurant_id,
            label=serializer.validated_data["label"],
            scopes=serializer.validated_data["scopes"],
            created_by=request.user,
        )
        audit(request=request, action="api_key.create", resource="api_key", resource_id=str(key.id))
        # token is returned only once
        return Response(
            {"id": str(key.id), "label": key.label, "prefix": key.prefix, "token": token, "scopes": key.scopes},
            status=status.HTTP_201_CREATED,
        )


class ApiKeyRevokeView(APIView):
    permission_classes = [perm("api-keys:revoke")]

    def post(self, request, pk):
        try:
            key = ApiKey.objects.get(pk=pk, restaurant_id=request.restaurant_id, revoked_at__isnull=True)
        except ApiKey.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)
        key.revoked_at = timezone.now()
        key.save(update_fields=["revoked_at"])
        audit(request=request, action="api_key.revoke", resource="api_key", resource_id=str(key.id))
        return Response(status=status.HTTP_204_NO_CONTENT)
