from django.contrib import admin

from .models import ApiKey


@admin.register(ApiKey)
class ApiKeyAdmin(admin.ModelAdmin):
    list_display = ("label", "prefix", "created_at", "last_used_at", "revoked_at")
    search_fields = ("label", "prefix")
    readonly_fields = ("token_hash", "prefix", "created_at", "last_used_at")
