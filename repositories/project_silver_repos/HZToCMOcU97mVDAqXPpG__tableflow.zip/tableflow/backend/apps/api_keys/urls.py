from django.urls import path

from . import views

urlpatterns = [
    path("", views.ApiKeyListView.as_view()),
    path("issue", views.ApiKeyCreateView.as_view()),
    path("<uuid:pk>/revoke", views.ApiKeyRevokeView.as_view()),
]
