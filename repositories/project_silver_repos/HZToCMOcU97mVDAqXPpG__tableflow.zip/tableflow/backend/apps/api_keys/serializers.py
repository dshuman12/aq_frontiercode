from rest_framework import serializers

from .models import ApiKey


class ApiKeySerializer(serializers.ModelSerializer):
    class Meta:
        model = ApiKey
        fields = ["id", "label", "prefix", "scopes", "created_at", "last_used_at", "revoked_at"]
        read_only_fields = ["id", "prefix", "created_at", "last_used_at", "revoked_at"]


class CreateApiKeySerializer(serializers.Serializer):
    label = serializers.CharField(max_length=120)
    scopes = serializers.ListField(child=serializers.CharField(max_length=120), default=list)
