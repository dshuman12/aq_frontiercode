"""API keys — hashed bearer tokens with scopes."""
from __future__ import annotations

import secrets
import uuid

from django.conf import settings
from django.db import models

PREFIX = "tflw_"


class ApiKey(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(db_index=True)
    label = models.CharField(max_length=120)
    prefix = models.CharField(max_length=12, db_index=True)
    token_hash = models.CharField(max_length=128, db_index=True)
    scopes = models.JSONField(default=list)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    last_used_at = models.DateTimeField(null=True, blank=True)
    revoked_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "api_keys"
        indexes = [models.Index(fields=["restaurant_id", "revoked_at"])]

    @classmethod
    def issue(cls, *, restaurant_id, label: str, scopes: list[str], created_by) -> tuple["ApiKey", str]:
        from apps.accounts.hashing import hash_token

        token = PREFIX + secrets.token_urlsafe(32)
        instance = cls.objects.create(
            restaurant_id=restaurant_id,
            label=label,
            prefix=token[: len(PREFIX) + 6],
            token_hash=hash_token(token),
            scopes=scopes,
            created_by=created_by,
        )
        return instance, token
