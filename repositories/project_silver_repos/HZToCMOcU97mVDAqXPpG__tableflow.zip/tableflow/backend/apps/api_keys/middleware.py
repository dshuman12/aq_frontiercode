"""API key authentication backend that complements the JWT path."""
from __future__ import annotations

from collections.abc import Callable

from django.http import HttpRequest, HttpResponse
from django.utils import timezone

from apps.accounts.hashing import hash_token

from .models import ApiKey, PREFIX


class ApiKeyAuthMiddleware:
    """If an `Authorization: Token tflw_...` header is present, attach a virtual user context."""

    def __init__(self, get_response: Callable[[HttpRequest], HttpResponse]):
        self.get_response = get_response

    def __call__(self, request: HttpRequest) -> HttpResponse:
        header = request.META.get("HTTP_AUTHORIZATION", "")
        if header.startswith("Token "):
            token = header.removeprefix("Token ").strip()
            if token.startswith(PREFIX):
                key = ApiKey.objects.filter(token_hash=hash_token(token), revoked_at__isnull=True).first()
                if key:
                    key.last_used_at = timezone.now()
                    key.save(update_fields=["last_used_at"])
                    request.api_key = key  # type: ignore[attr-defined]
                    request.restaurant_id = key.restaurant_id  # type: ignore[attr-defined]
                    request.permissions = key.scopes  # type: ignore[attr-defined]
        return self.get_response(request)
