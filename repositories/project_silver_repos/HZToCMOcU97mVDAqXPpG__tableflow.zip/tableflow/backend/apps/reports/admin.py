from django.contrib import admin

from .models import ReportExport


@admin.register(ReportExport)
class ReportExportAdmin(admin.ModelAdmin):
    list_display = ("kind", "format", "status", "range_from", "range_to", "created_at")
    list_filter = ("kind", "format", "status")
    readonly_fields = ("created_at", "finished_at")
