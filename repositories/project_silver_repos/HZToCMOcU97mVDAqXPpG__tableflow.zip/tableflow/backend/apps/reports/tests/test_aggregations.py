from datetime import date, datetime

from apps.reports.aggregations import (
    no_show_rate,
    payment_method_breakdown,
    revenue_by_day,
    tip_summary,
    top_items,
)


def test_revenue_by_day_groups_by_iso_date():
    payments = [
        {"captured_at": datetime(2024, 8, 15, 10, 0), "amount_cents": 1000},
        {"captured_at": datetime(2024, 8, 15, 22, 0), "amount_cents": 500},
        {"captured_at": datetime(2024, 8, 16, 8, 0), "amount_cents": 200},
    ]
    out = revenue_by_day(payments)
    assert out["2024-08-15"] == 1500
    assert out["2024-08-16"] == 200


def test_top_items_sorted_by_revenue():
    items = [
        {"name": "Burger", "line_total_cents": 1000},
        {"name": "Fries", "line_total_cents": 200},
        {"name": "Burger", "line_total_cents": 500},
    ]
    out = top_items(items, limit=2)
    assert out[0] == ("Burger", 1500)
    assert out[1] == ("Fries", 200)


def test_tip_summary_handles_empty():
    assert tip_summary([]) == {"total_tips_cents": 0, "captured_count": 0, "avg_tip_cents": 0}


def test_tip_summary_basic():
    payments = [
        {"status": "captured", "tip_cents": 200},
        {"status": "captured", "tip_cents": 400},
        {"status": "failed", "tip_cents": 1000},
    ]
    out = tip_summary(payments)
    assert out["captured_count"] == 2
    assert out["total_tips_cents"] == 600
    assert out["avg_tip_cents"] == 300


def test_payment_method_breakdown_excludes_non_captured():
    payments = [
        {"status": "captured", "method": "card", "amount_cents": 1000},
        {"status": "failed", "method": "card", "amount_cents": 500},
        {"status": "captured", "method": "cash", "amount_cents": 300},
    ]
    out = payment_method_breakdown(payments)
    assert out["card"] == 1000
    assert out["cash"] == 300


def test_no_show_rate():
    rs = [{"status": "completed"}, {"status": "no_show"}, {"status": "completed"}, {"status": "no_show"}]
    assert no_show_rate(rs) == 50.0
    assert no_show_rate([]) == 0.0
