from apps.reports.csv_export import write_csv


def test_basic_csv_round_trip():
    out = write_csv(["a", "b"], [[1, 2], [3, 4]])
    text = out.decode("utf-8")
    assert text.splitlines()[0] == "a,b"
    assert "1,2" in text
    assert "3,4" in text


def test_handles_strings_with_commas_via_quoting():
    out = write_csv(["x"], [["a, b, c"]])
    text = out.decode("utf-8")
    assert '"a, b, c"' in text


def test_empty_rows_writes_header_only():
    out = write_csv(["a"], [])
    assert out.decode("utf-8").strip() == "a"
