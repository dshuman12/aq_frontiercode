from apps.reports.aggregations import (
    no_show_rate,
    payment_method_breakdown,
    revenue_by_day,
    tip_summary,
    top_items,
)


def test_revenue_skipping_string_dates():
    payments = [
        {"captured_at": "2024-08-15T12:00:00", "amount_cents": 500},
        {"captured_at": "2024-08-15T18:00:00", "amount_cents": 1500},
    ]
    out = revenue_by_day(payments)
    assert out == {"2024-08-15": 2000}


def test_top_items_limit_capped():
    items = [{"name": f"item-{i}", "line_total_cents": i * 100} for i in range(20)]
    out = top_items(items, limit=5)
    assert len(out) == 5
    assert out[0][0] == "item-19"


def test_payment_method_handles_no_method_key():
    payments = [{"status": "captured", "amount_cents": 1000}]
    out = payment_method_breakdown(payments)
    assert out["other"] == 1000


def test_tip_summary_excludes_failed_payments():
    payments = [{"status": "failed", "tip_cents": 9999}]
    assert tip_summary(payments)["total_tips_cents"] == 0


def test_no_show_rounding():
    assert no_show_rate([{"status": "no_show"}, {"status": "completed"}, {"status": "completed"}]) == 33.33
