"""Pure aggregation helpers — easy to unit test."""
from __future__ import annotations

from collections import Counter, defaultdict
from datetime import date


def revenue_by_day(payments: list[dict]) -> dict[str, int]:
    """payments: [{captured_at: date|datetime, amount_cents: int}]"""
    out: dict[str, int] = defaultdict(int)
    for p in payments:
        d = p["captured_at"]
        key = d.isoformat()[:10] if hasattr(d, "isoformat") else str(d)[:10]
        out[key] += int(p.get("amount_cents", 0))
    return dict(out)


def top_items(items: list[dict], *, limit: int = 10) -> list[tuple[str, int]]:
    """items: [{name: str, line_total_cents: int}]"""
    c: Counter[str] = Counter()
    for it in items:
        c[it["name"]] += int(it.get("line_total_cents", 0))
    return c.most_common(limit)


def tip_summary(payments: list[dict]) -> dict[str, int]:
    out = {"total_tips_cents": 0, "captured_count": 0, "avg_tip_cents": 0}
    captured = [p for p in payments if p.get("status") == "captured"]
    out["captured_count"] = len(captured)
    out["total_tips_cents"] = sum(int(p.get("tip_cents", 0)) for p in captured)
    if out["captured_count"]:
        out["avg_tip_cents"] = out["total_tips_cents"] // out["captured_count"]
    return out


def payment_method_breakdown(payments: list[dict]) -> dict[str, int]:
    out: dict[str, int] = defaultdict(int)
    for p in payments:
        if p.get("status") == "captured":
            out[p.get("method", "other")] += int(p.get("amount_cents", 0))
    return dict(out)


def no_show_rate(reservations: list[dict]) -> float:
    if not reservations:
        return 0.0
    no_show = sum(1 for r in reservations if r.get("status") == "no_show")
    return round(100 * no_show / len(reservations), 2)
