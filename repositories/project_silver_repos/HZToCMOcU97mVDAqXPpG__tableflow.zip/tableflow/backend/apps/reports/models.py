"""ReportExport — generated CSV/PDF artifacts."""
from __future__ import annotations

import uuid

from django.conf import settings
from django.db import models


class ReportExport(models.Model):
    KIND_CHOICES = [
        ("daily_sales", "Daily sales"),
        ("menu_items", "Menu item sales"),
        ("revenue", "Revenue"),
        ("payment_method", "Payment method"),
        ("tips", "Tips"),
        ("tax", "Tax"),
        ("inventory_usage", "Inventory usage"),
        ("waste", "Waste"),
        ("reservations", "Reservations"),
        ("loyalty", "Loyalty"),
        ("staff", "Staff performance"),
    ]
    FORMAT_CHOICES = [("csv", "CSV"), ("pdf", "PDF"), ("xlsx", "Excel")]
    STATUS_CHOICES = [("queued", "Queued"), ("ready", "Ready"), ("failed", "Failed")]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(db_index=True)
    branch = models.ForeignKey("branches.Branch", null=True, blank=True, on_delete=models.SET_NULL, related_name="report_exports")
    kind = models.CharField(max_length=20, choices=KIND_CHOICES)
    format = models.CharField(max_length=8, choices=FORMAT_CHOICES, default="csv")
    status = models.CharField(max_length=8, choices=STATUS_CHOICES, default="queued")
    range_from = models.DateField()
    range_to = models.DateField()
    requested_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL)
    file = models.ForeignKey("files.FileAsset", null=True, blank=True, on_delete=models.SET_NULL)
    error_message = models.CharField(max_length=300, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    finished_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "report_export"
        indexes = [models.Index(fields=["restaurant_id", "kind", "created_at"])]
