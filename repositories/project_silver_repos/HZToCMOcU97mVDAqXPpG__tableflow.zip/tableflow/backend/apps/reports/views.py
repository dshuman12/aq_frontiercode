from datetime import date, datetime, timedelta

from django.db.models import Count, Sum
from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.accounts.permissions import perm
from apps.orders.models import Order
from apps.payments.models import Payment

from .models import ReportExport
from .serializers import CreateReportSerializer, ReportExportSerializer


class DashboardView(APIView):
    permission_classes = [perm("reports:read")]

    def get(self, request):
        today = date.today()
        start = today - timedelta(days=29)
        orders_today = Order.objects.filter(restaurant_id=request.restaurant_id, created_at__date=today).count()
        revenue_30 = Payment.objects.filter(
            restaurant_id=request.restaurant_id, status="captured", captured_at__date__gte=start,
        ).aggregate(total=Sum("amount_cents"))["total"] or 0
        return Response({
            "orders_today": orders_today,
            "revenue_30d_cents": revenue_30,
            "range_from": start.isoformat(),
            "range_to": today.isoformat(),
        })


class ExportList(generics.ListAPIView):
    serializer_class = ReportExportSerializer
    permission_classes = [perm("reports:read")]
    filterset_fields = ["kind", "format", "status"]
    ordering = ["-created_at"]

    def get_queryset(self):  # type: ignore[override]
        return ReportExport.objects.filter(restaurant_id=self.request.restaurant_id)


class CreateExportView(APIView):
    permission_classes = [perm("reports:read")]

    def post(self, request):
        serializer = CreateReportSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        d = serializer.validated_data
        rep = ReportExport.objects.create(
            restaurant_id=request.restaurant_id,
            branch_id=d.get("branch"),
            kind=d["kind"],
            format=d["format"],
            range_from=d["range_from"],
            range_to=d["range_to"],
            requested_by=request.user,
        )
        from .tasks import build_report
        build_report.delay(str(rep.id))
        return Response(ReportExportSerializer(rep).data, status=status.HTTP_201_CREATED)
