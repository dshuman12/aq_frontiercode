from rest_framework import serializers

from .models import ReportExport


class ReportExportSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReportExport
        fields = "__all__"
        read_only_fields = ["id", "restaurant_id", "status", "file", "error_message", "created_at", "finished_at"]


class CreateReportSerializer(serializers.Serializer):
    kind = serializers.ChoiceField(choices=[c[0] for c in ReportExport.KIND_CHOICES])
    format = serializers.ChoiceField(choices=[c[0] for c in ReportExport.FORMAT_CHOICES], default="csv")
    range_from = serializers.DateField()
    range_to = serializers.DateField()
    branch = serializers.UUIDField(required=False, allow_null=True)
