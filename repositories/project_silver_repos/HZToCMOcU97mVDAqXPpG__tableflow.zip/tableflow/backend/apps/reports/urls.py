from django.urls import path

from . import views

urlpatterns = [
    path("dashboard", views.DashboardView.as_view()),
    path("exports", views.ExportList.as_view()),
    path("exports/create", views.CreateExportView.as_view()),
]
