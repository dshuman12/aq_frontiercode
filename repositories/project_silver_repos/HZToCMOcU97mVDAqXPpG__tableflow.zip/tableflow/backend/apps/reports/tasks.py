"""Celery tasks: generate report files; daily sales digest."""
from __future__ import annotations

import logging
from datetime import datetime, time, timedelta

from celery import shared_task
from django.utils import timezone

from .csv_export import write_csv
from .models import ReportExport

log = logging.getLogger(__name__)


@shared_task
def build_report(report_id: str) -> dict:
    try:
        rep = ReportExport.objects.get(pk=report_id)
    except ReportExport.DoesNotExist:
        return {"skipped": "missing"}
    try:
        # Stub: a real impl would query and write to S3 via files.storage
        if rep.format == "csv":
            _ = write_csv(["date", "amount"], [[str(rep.range_from), 0]])
        rep.status = "ready"
        rep.finished_at = timezone.now()
        rep.save(update_fields=["status", "finished_at"])
        return {"ok": True, "id": str(rep.id)}
    except Exception as exc:  # pragma: no cover
        rep.status = "failed"
        rep.error_message = str(exc)[:300]
        rep.save(update_fields=["status", "error_message"])
        return {"failed": True}


@shared_task
def send_daily_sales_digest() -> int:
    log.info("reports.digest.daily")
    return 0
