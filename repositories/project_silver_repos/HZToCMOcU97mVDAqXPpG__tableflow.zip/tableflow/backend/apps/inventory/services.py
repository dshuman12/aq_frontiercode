"""Inventory services — adjust stock, deduct from completed orders, log waste."""
from __future__ import annotations

from decimal import Decimal

from django.db import transaction
from django.utils import timezone
from rest_framework.exceptions import ValidationError

from .models import (
    Ingredient,
    InventoryCount,
    InventoryCountLine,
    InventoryTransaction,
    Recipe,
    WasteLog,
)


@transaction.atomic
def post_transaction(*, ingredient: Ingredient, kind: str, quantity_change: Decimal, unit_cost_cents: int = 0, note: str = "", order=None, purchase_order=None, by=None) -> InventoryTransaction:
    tx = InventoryTransaction.objects.create(
        restaurant_id=ingredient.restaurant_id,
        ingredient=ingredient,
        kind=kind,
        quantity_change=quantity_change,
        unit_cost_cents=unit_cost_cents,
        note=note,
        order=order,
        purchase_order=purchase_order,
        created_by=by if getattr(by, "is_authenticated", False) else None,
    )
    ingredient.on_hand_qty = ingredient.on_hand_qty + quantity_change
    ingredient.save(update_fields=["on_hand_qty", "updated_at"])
    return tx


@transaction.atomic
def deduct_for_order(order) -> dict:
    """When an order is completed, deduct its recipe-mapped ingredients."""
    deducted = 0
    for item in order.items.filter(is_voided=False).select_related("menu_item"):
        try:
            recipe = item.menu_item.recipe
        except Recipe.DoesNotExist:
            continue
        for line in recipe.lines.select_related("ingredient"):
            qty = -(line.quantity * item.quantity)
            post_transaction(ingredient=line.ingredient, kind="sale", quantity_change=qty, order=order)
            deducted += 1
    return {"order_id": str(order.id), "lines": deducted}


@transaction.atomic
def adjust(*, ingredient: Ingredient, new_on_hand: Decimal, note: str = "", by=None) -> InventoryTransaction:
    diff = new_on_hand - ingredient.on_hand_qty
    return post_transaction(ingredient=ingredient, kind="adjust", quantity_change=diff, note=note, by=by)


@transaction.atomic
def log_waste(*, ingredient: Ingredient, quantity: Decimal, reason: str, note: str = "", by=None) -> WasteLog:
    if quantity <= 0:
        raise ValidationError({"quantity": "must be positive"})
    waste = WasteLog.objects.create(
        restaurant_id=ingredient.restaurant_id,
        ingredient=ingredient,
        quantity=quantity,
        reason=reason,
        note=note,
        logged_by=by if getattr(by, "is_authenticated", False) else None,
    )
    post_transaction(ingredient=ingredient, kind="waste", quantity_change=-quantity, note=f"waste:{reason}")
    return waste


@transaction.atomic
def finalize_count(count: InventoryCount) -> InventoryCount:
    if count.finalized_at:
        raise ValidationError({"count": "already-finalized"})
    for line in count.lines.select_related("ingredient"):
        line.diff = line.counted - line.expected
        line.save(update_fields=["diff"])
        if line.diff != 0:
            post_transaction(
                ingredient=line.ingredient, kind="count", quantity_change=line.diff,
                note=f"count adjustment from {line.ingredient.on_hand_qty} to {line.counted}",
            )
        line.ingredient.last_counted_at = timezone.now()
        line.ingredient.save(update_fields=["last_counted_at", "updated_at"])
    count.finalized_at = timezone.now()
    count.save(update_fields=["finalized_at"])
    return count
