from django.contrib import admin

from .models import (
    Ingredient,
    IngredientCategory,
    InventoryCount,
    InventoryCountLine,
    InventoryTransaction,
    Recipe,
    RecipeIngredient,
    WasteLog,
)


@admin.register(Ingredient)
class IngredientAdmin(admin.ModelAdmin):
    list_display = ("name", "unit", "on_hand_qty", "par_qty", "is_archived")
    search_fields = ("name", "sku")
    list_filter = ("is_archived", "unit", "category")


@admin.register(InventoryTransaction)
class InventoryTransactionAdmin(admin.ModelAdmin):
    list_display = ("ingredient", "kind", "quantity_change", "unit_cost_cents", "created_at")
    list_filter = ("kind",)
    readonly_fields = ("created_at",)


admin.site.register([IngredientCategory, Recipe, RecipeIngredient, InventoryCount, InventoryCountLine, WasteLog])
