from decimal import Decimal


def test_low_stock_threshold():
    """Pure: ingredient is low when on_hand < par and par > 0."""
    class Stub:
        def __init__(self, on, par):
            self.on_hand_qty, self.par_qty = on, par

        @property
        def is_low_stock(self):
            return self.par_qty > 0 and self.on_hand_qty < self.par_qty

    assert Stub(Decimal("4"), Decimal("5")).is_low_stock
    assert not Stub(Decimal("5"), Decimal("5")).is_low_stock
    assert not Stub(Decimal("0"), Decimal("0")).is_low_stock  # par 0 disables


def test_recipe_deduction_quantity_math():
    # 3 burgers using 0.250 kg patty each → -0.750 kg
    qty_per = Decimal("0.250")
    burgers = 3
    assert -(qty_per * burgers) == Decimal("-0.750")
