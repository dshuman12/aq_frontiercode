"""Pure tests for recipe-driven deduction quantity math."""
from decimal import Decimal


def deduct_for_line(quantity_per_serving, servings_ordered):
    return -(Decimal(str(quantity_per_serving)) * servings_ordered)


def test_basic_burger_deduction():
    assert deduct_for_line("0.250", 3) == Decimal("-0.750")


def test_zero_servings_is_noop():
    assert deduct_for_line("1", 0) == Decimal("0")


def test_fractional_quantity_preserved():
    assert deduct_for_line("0.0125", 8) == Decimal("-0.1000")


def test_high_volume_doesnt_underflow():
    out = deduct_for_line("0.5", 10000)
    assert out == Decimal("-5000.0")
