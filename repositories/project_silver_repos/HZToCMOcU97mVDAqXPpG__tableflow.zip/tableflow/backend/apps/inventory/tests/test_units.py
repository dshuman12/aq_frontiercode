"""Unit conversion sanity checks."""

CONV = {
    ("kg", "g"): 1000,
    ("g", "kg"): 1 / 1000,
    ("l", "ml"): 1000,
    ("ml", "l"): 1 / 1000,
    ("lb", "oz"): 16,
    ("oz", "lb"): 1 / 16,
}


def convert(qty, from_unit, to_unit):
    if from_unit == to_unit:
        return qty
    factor = CONV.get((from_unit, to_unit))
    if factor is None:
        raise ValueError(f"unsupported:{from_unit}->{to_unit}")
    return qty * factor


def test_identity_conversion():
    assert convert(5, "g", "g") == 5


def test_kg_to_g():
    assert convert(2, "kg", "g") == 2000


def test_lb_to_oz():
    assert convert(3, "lb", "oz") == 48


def test_unsupported_raises():
    import pytest
    with pytest.raises(ValueError):
        convert(1, "kg", "ml")
