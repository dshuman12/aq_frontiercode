"""Pure low-stock decision tests (no DB)."""
from decimal import Decimal


def is_low(on_hand, par):
    return par > 0 and on_hand < par


def test_zero_par_disables_low_stock():
    assert not is_low(Decimal("0"), Decimal("0"))
    assert not is_low(Decimal("100"), Decimal("0"))


def test_at_par_is_not_low():
    assert not is_low(Decimal("5"), Decimal("5"))


def test_below_par_is_low():
    assert is_low(Decimal("4.99"), Decimal("5"))
    assert is_low(Decimal("0"), Decimal("0.01"))
