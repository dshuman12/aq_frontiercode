"""Inventory count diff math."""
from decimal import Decimal


def diff(expected, counted):
    return Decimal(str(counted)) - Decimal(str(expected))


def test_perfect_count_diff_zero():
    assert diff("10.000", "10.000") == Decimal("0")


def test_short_count_negative_diff():
    assert diff("10.000", "9.250") == Decimal("-0.750")


def test_over_count_positive_diff():
    assert diff("5.000", "5.500") == Decimal("0.500")


def test_diff_summary():
    rows = [
        {"expected": "10", "counted": "9.5"},
        {"expected": "5", "counted": "5"},
        {"expected": "8", "counted": "9"},
    ]
    diffs = [diff(r["expected"], r["counted"]) for r in rows]
    short = sum(1 for d in diffs if d < 0)
    over = sum(1 for d in diffs if d > 0)
    matched = sum(1 for d in diffs if d == 0)
    assert short == 1 and over == 1 and matched == 1
