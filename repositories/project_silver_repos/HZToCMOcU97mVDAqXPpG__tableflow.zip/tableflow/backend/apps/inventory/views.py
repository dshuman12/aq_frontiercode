from decimal import Decimal

from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.accounts.permissions import perm

from . import services
from .models import (
    Ingredient,
    IngredientCategory,
    InventoryCount,
    InventoryTransaction,
    Recipe,
    WasteLog,
)
from .serializers import (
    IngredientCategorySerializer,
    IngredientSerializer,
    InventoryCountSerializer,
    InventoryTransactionSerializer,
    RecipeSerializer,
    WasteLogSerializer,
)


class IngredientList(generics.ListCreateAPIView):
    serializer_class = IngredientSerializer
    permission_classes = [perm("inventory:read")]
    filterset_fields = ["branch", "category", "is_archived"]
    search_fields = ["name", "sku"]

    def get_queryset(self):  # type: ignore[override]
        return Ingredient.objects.filter(restaurant_id=self.request.restaurant_id)

    def perform_create(self, serializer):  # type: ignore[override]
        serializer.save(restaurant_id=self.request.restaurant_id)


class IngredientDetail(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = IngredientSerializer
    permission_classes = [perm("inventory:read")]

    def get_queryset(self):  # type: ignore[override]
        return Ingredient.objects.filter(restaurant_id=self.request.restaurant_id)


class CategoryList(generics.ListCreateAPIView):
    serializer_class = IngredientCategorySerializer
    permission_classes = [perm("inventory:read")]

    def get_queryset(self):  # type: ignore[override]
        return IngredientCategory.objects.filter(restaurant_id=self.request.restaurant_id)

    def perform_create(self, serializer):  # type: ignore[override]
        serializer.save(restaurant_id=self.request.restaurant_id)


class RecipeList(generics.ListCreateAPIView):
    serializer_class = RecipeSerializer
    permission_classes = [perm("inventory:read")]
    filterset_fields = ["menu_item"]

    def get_queryset(self):  # type: ignore[override]
        return Recipe.objects.filter(restaurant_id=self.request.restaurant_id)

    def perform_create(self, serializer):  # type: ignore[override]
        serializer.save(restaurant_id=self.request.restaurant_id)


class TransactionList(generics.ListAPIView):
    serializer_class = InventoryTransactionSerializer
    permission_classes = [perm("inventory:read")]
    filterset_fields = ["ingredient", "kind"]
    ordering = ["-created_at"]

    def get_queryset(self):  # type: ignore[override]
        return InventoryTransaction.objects.filter(restaurant_id=self.request.restaurant_id)


class AdjustView(APIView):
    permission_classes = [perm("inventory:adjust")]

    def post(self, request, pk):
        ing = Ingredient.objects.get(pk=pk, restaurant_id=request.restaurant_id)
        new_on_hand = Decimal(str(request.data.get("new_on_hand", "0")))
        services.adjust(ingredient=ing, new_on_hand=new_on_hand, note=request.data.get("note", ""), by=request.user)
        return Response(IngredientSerializer(ing).data)


class WasteList(generics.ListCreateAPIView):
    serializer_class = WasteLogSerializer
    permission_classes = [perm("inventory:read")]
    filterset_fields = ["ingredient"]
    ordering = ["-created_at"]

    def get_queryset(self):  # type: ignore[override]
        return WasteLog.objects.filter(restaurant_id=self.request.restaurant_id)

    def create(self, request, *args, **kwargs):  # type: ignore[override]
        ing = Ingredient.objects.get(pk=request.data.get("ingredient"), restaurant_id=request.restaurant_id)
        waste = services.log_waste(
            ingredient=ing,
            quantity=Decimal(str(request.data.get("quantity", "0"))),
            reason=request.data.get("reason", ""),
            note=request.data.get("note", ""),
            by=request.user,
        )
        return Response(WasteLogSerializer(waste).data, status=status.HTTP_201_CREATED)


class CountList(generics.ListCreateAPIView):
    serializer_class = InventoryCountSerializer
    permission_classes = [perm("inventory:count")]

    def get_queryset(self):  # type: ignore[override]
        return InventoryCount.objects.filter(restaurant_id=self.request.restaurant_id)

    def perform_create(self, serializer):  # type: ignore[override]
        serializer.save(restaurant_id=self.request.restaurant_id, counted_by=self.request.user)


class FinalizeCountView(APIView):
    permission_classes = [perm("inventory:count")]

    def post(self, request, pk):
        count = InventoryCount.objects.get(pk=pk, restaurant_id=request.restaurant_id)
        services.finalize_count(count)
        return Response(InventoryCountSerializer(count).data)


class LowStockView(APIView):
    permission_classes = [perm("inventory:read")]

    def get(self, request):
        rows = [
            i for i in Ingredient.objects.filter(restaurant_id=request.restaurant_id, is_archived=False)
            if i.is_low_stock
        ]
        return Response(IngredientSerializer(rows, many=True).data)
