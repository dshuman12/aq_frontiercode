"""Inventory threshold alerts — fire low-stock notification on transactions."""
from __future__ import annotations

from django.db.models.signals import post_save
from django.dispatch import receiver

from .models import InventoryTransaction


@receiver(post_save, sender=InventoryTransaction)
def maybe_emit_low_stock(sender, instance: InventoryTransaction, created: bool, **kwargs):
    if not created:
        return
    ing = instance.ingredient
    # Only sale/waste/transfer_out can drop us below par
    if instance.kind not in ("sale", "waste", "transfer_out", "adjust"):
        return
    if ing.par_qty > 0 and ing.on_hand_qty < ing.par_qty:
        from apps.notifications.tasks import send_low_stock_alert
        send_low_stock_alert.delay(str(ing.id))
