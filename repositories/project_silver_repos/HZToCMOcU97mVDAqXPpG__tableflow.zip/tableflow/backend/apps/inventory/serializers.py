from rest_framework import serializers

from .models import (
    Ingredient,
    IngredientCategory,
    InventoryCount,
    InventoryCountLine,
    InventoryTransaction,
    Recipe,
    RecipeIngredient,
    WasteLog,
)


class IngredientCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = IngredientCategory
        fields = "__all__"
        read_only_fields = ["id", "restaurant_id"]


class IngredientSerializer(serializers.ModelSerializer):
    is_low_stock = serializers.BooleanField(read_only=True)

    class Meta:
        model = Ingredient
        fields = "__all__"
        read_only_fields = ["id", "restaurant_id", "last_counted_at", "is_low_stock", "created_at", "updated_at"]


class RecipeIngredientSerializer(serializers.ModelSerializer):
    class Meta:
        model = RecipeIngredient
        fields = "__all__"
        read_only_fields = ["id"]


class RecipeSerializer(serializers.ModelSerializer):
    lines = RecipeIngredientSerializer(many=True, read_only=True)

    class Meta:
        model = Recipe
        fields = "__all__"
        read_only_fields = ["id", "restaurant_id"]


class InventoryTransactionSerializer(serializers.ModelSerializer):
    class Meta:
        model = InventoryTransaction
        fields = "__all__"
        read_only_fields = ["id", "restaurant_id", "created_at"]


class WasteLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = WasteLog
        fields = "__all__"
        read_only_fields = ["id", "restaurant_id", "created_at"]


class InventoryCountLineSerializer(serializers.ModelSerializer):
    class Meta:
        model = InventoryCountLine
        fields = "__all__"
        read_only_fields = ["id", "diff"]


class InventoryCountSerializer(serializers.ModelSerializer):
    lines = InventoryCountLineSerializer(many=True, read_only=True)

    class Meta:
        model = InventoryCount
        fields = "__all__"
        read_only_fields = ["id", "restaurant_id", "started_at", "finalized_at"]
