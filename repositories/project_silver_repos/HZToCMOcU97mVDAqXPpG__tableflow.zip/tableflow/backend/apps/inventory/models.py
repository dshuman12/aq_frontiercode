"""Ingredient/Recipe/Stock models."""
from __future__ import annotations

import uuid

from django.conf import settings
from django.db import models


class IngredientCategory(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(db_index=True)
    name = models.CharField(max_length=80)
    sort_order = models.PositiveIntegerField(default=0)

    class Meta:
        db_table = "ingredient_category"
        unique_together = ("restaurant_id", "name")


class Ingredient(models.Model):
    UNIT_CHOICES = [
        ("g", "Gram"), ("kg", "Kilogram"), ("ml", "Milliliter"), ("l", "Liter"),
        ("ea", "Each"), ("oz", "Ounce"), ("lb", "Pound"),
    ]
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(db_index=True)
    branch = models.ForeignKey("branches.Branch", null=True, blank=True, on_delete=models.SET_NULL, related_name="ingredients")
    category = models.ForeignKey(IngredientCategory, null=True, blank=True, on_delete=models.SET_NULL, related_name="ingredients")
    name = models.CharField(max_length=120)
    sku = models.CharField(max_length=40, blank=True)
    unit = models.CharField(max_length=4, choices=UNIT_CHOICES, default="g")
    on_hand_qty = models.DecimalField(max_digits=12, decimal_places=3, default=0)
    par_qty = models.DecimalField(max_digits=12, decimal_places=3, default=0)
    reorder_qty = models.DecimalField(max_digits=12, decimal_places=3, default=0)
    cost_per_unit_cents = models.PositiveIntegerField(default=0)
    is_archived = models.BooleanField(default=False)
    last_counted_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "ingredient"
        unique_together = ("restaurant_id", "branch", "name")
        indexes = [models.Index(fields=["restaurant_id", "branch", "is_archived"])]

    @property
    def is_low_stock(self) -> bool:
        return self.par_qty > 0 and self.on_hand_qty < self.par_qty


class Recipe(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(db_index=True)
    menu_item = models.OneToOneField("menus.MenuItem", on_delete=models.CASCADE, related_name="recipe")
    yield_qty = models.PositiveSmallIntegerField(default=1)
    notes = models.TextField(blank=True)

    class Meta:
        db_table = "recipe"


class RecipeIngredient(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    recipe = models.ForeignKey(Recipe, on_delete=models.CASCADE, related_name="lines")
    ingredient = models.ForeignKey(Ingredient, on_delete=models.PROTECT, related_name="recipe_lines")
    quantity = models.DecimalField(max_digits=12, decimal_places=3)
    unit = models.CharField(max_length=4, choices=Ingredient.UNIT_CHOICES)

    class Meta:
        db_table = "recipe_ingredient"


class InventoryTransaction(models.Model):
    KIND_CHOICES = [
        ("purchase", "Purchase"),
        ("sale", "Sale (deduct)"),
        ("waste", "Waste"),
        ("adjust", "Adjust"),
        ("count", "Count"),
        ("transfer_in", "Transfer in"),
        ("transfer_out", "Transfer out"),
    ]
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(db_index=True)
    ingredient = models.ForeignKey(Ingredient, on_delete=models.CASCADE, related_name="transactions")
    kind = models.CharField(max_length=14, choices=KIND_CHOICES, db_index=True)
    quantity_change = models.DecimalField(max_digits=12, decimal_places=3)  # positive in, negative out
    unit_cost_cents = models.PositiveIntegerField(default=0)
    note = models.CharField(max_length=300, blank=True)
    order = models.ForeignKey("orders.Order", null=True, blank=True, on_delete=models.SET_NULL)
    purchase_order = models.ForeignKey("purchasing.PurchaseOrder", null=True, blank=True, on_delete=models.SET_NULL)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "inventory_transaction"
        indexes = [models.Index(fields=["restaurant_id", "ingredient", "created_at"])]
        ordering = ["-created_at"]


class InventoryCount(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(db_index=True)
    branch = models.ForeignKey("branches.Branch", on_delete=models.CASCADE, related_name="inventory_counts")
    counted_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL)
    started_at = models.DateTimeField(auto_now_add=True)
    finalized_at = models.DateTimeField(null=True, blank=True)
    notes = models.TextField(blank=True)

    class Meta:
        db_table = "inventory_count"


class InventoryCountLine(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    count = models.ForeignKey(InventoryCount, on_delete=models.CASCADE, related_name="lines")
    ingredient = models.ForeignKey(Ingredient, on_delete=models.CASCADE)
    expected = models.DecimalField(max_digits=12, decimal_places=3)
    counted = models.DecimalField(max_digits=12, decimal_places=3)
    diff = models.DecimalField(max_digits=12, decimal_places=3)

    class Meta:
        db_table = "inventory_count_line"
        unique_together = ("count", "ingredient")


class WasteLog(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant_id = models.UUIDField(db_index=True)
    ingredient = models.ForeignKey(Ingredient, on_delete=models.CASCADE, related_name="waste_logs")
    quantity = models.DecimalField(max_digits=12, decimal_places=3)
    reason = models.CharField(max_length=120)
    note = models.CharField(max_length=300, blank=True)
    logged_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "waste_log"
