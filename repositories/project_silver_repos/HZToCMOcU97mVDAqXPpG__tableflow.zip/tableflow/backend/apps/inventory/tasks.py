"""Celery tasks for inventory: low-stock scan + post-completion deduction."""
from __future__ import annotations

from celery import shared_task

from apps.orders.models import Order

from .models import Ingredient


@shared_task
def scan_low_stock() -> int:
    rows = Ingredient.objects.filter(is_archived=False, par_qty__gt=0)
    notified = 0
    for ing in rows:
        if ing.on_hand_qty < ing.par_qty:
            from apps.notifications.tasks import send_low_stock_alert
            send_low_stock_alert.delay(str(ing.id))
            notified += 1
    return notified


@shared_task
def deduct_for_order(order_id: str) -> dict:
    from .services import deduct_for_order as _deduct
    try:
        order = Order.objects.get(pk=order_id)
    except Order.DoesNotExist:
        return {"skipped": "missing"}
    return _deduct(order)
