from django.urls import path

from . import views

urlpatterns = [
    path("", views.IngredientList.as_view()),
    path("<uuid:pk>", views.IngredientDetail.as_view()),
    path("<uuid:pk>/adjust", views.AdjustView.as_view()),
    path("categories", views.CategoryList.as_view()),
    path("recipes", views.RecipeList.as_view()),
    path("transactions", views.TransactionList.as_view()),
    path("waste", views.WasteList.as_view()),
    path("counts", views.CountList.as_view()),
    path("counts/<uuid:pk>/finalize", views.FinalizeCountView.as_view()),
    path("low-stock", views.LowStockView.as_view()),
]
