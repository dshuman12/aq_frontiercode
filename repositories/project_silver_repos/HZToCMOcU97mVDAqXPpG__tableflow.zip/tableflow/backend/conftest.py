"""Pytest fixtures shared across the suite."""
from __future__ import annotations

import pytest
from rest_framework.test import APIClient


@pytest.fixture
def api_client():
    return APIClient()


@pytest.fixture
def authed_client(db, api_client):
    from apps.accounts.services import issue_token_pair
    from apps.accounts.tests.factories import UserFactory

    user = UserFactory()
    pair = issue_token_pair(user)
    api_client.credentials(HTTP_AUTHORIZATION=f"Bearer {pair.access}")
    return api_client, user
