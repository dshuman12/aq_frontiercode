"""Celery application setup."""
from __future__ import annotations

import os

from celery import Celery
from celery.schedules import crontab

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings.dev")

app = Celery("tableflow")
app.config_from_object("django.conf:settings", namespace="CELERY")
app.autodiscover_tasks()

app.conf.beat_schedule = {
    "release-unpaid-reservations": {
        "task": "apps.reservations.tasks.release_unpaid_reservations",
        "schedule": crontab(minute="*/5"),
    },
    "expire-old-coupons": {
        "task": "apps.coupons.tasks.expire_old_coupons",
        "schedule": crontab(minute=0, hour="*/6"),
    },
    "send-reservation-reminders": {
        "task": "apps.reservations.tasks.send_pending_reminders",
        "schedule": crontab(minute="*/15"),
    },
    "low-stock-alerts": {
        "task": "apps.inventory.tasks.scan_low_stock",
        "schedule": crontab(minute=0, hour=8),
    },
    "daily-sales-digest": {
        "task": "apps.reports.tasks.send_daily_sales_digest",
        "schedule": crontab(minute=0, hour=23),
    },
    "cleanup-expired-sessions": {
        "task": "apps.accounts.tasks.cleanup_expired_sessions",
        "schedule": crontab(minute=0, hour=3),
    },
}


@app.task(bind=True)
def debug_task(self) -> None:  # pragma: no cover
    print(f"Request: {self.request!r}")
