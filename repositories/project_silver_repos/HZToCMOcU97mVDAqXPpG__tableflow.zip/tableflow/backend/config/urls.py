"""TableFlow URL configuration."""
from django.contrib import admin
from django.urls import include, path
from drf_spectacular.views import (
    SpectacularAPIView,
    SpectacularRedocView,
    SpectacularSwaggerView,
)

api_urls = [
    path("auth/", include("apps.accounts.urls")),
    path("restaurants/", include("apps.restaurants.urls")),
    path("branches/", include("apps.branches.urls")),
    path("staff/", include("apps.staff.urls")),
    path("roles/", include("apps.roles.urls")),
    path("menus/", include("apps.menus.urls")),
    path("modifiers/", include("apps.modifiers.urls")),
    path("tables/", include("apps.tables.urls")),
    path("reservations/", include("apps.reservations.urls")),
    path("orders/", include("apps.orders.urls")),
    path("kitchen/", include("apps.kitchen.urls")),
    path("payments/", include("apps.payments.urls")),
    path("customers/", include("apps.customers.urls")),
    path("loyalty/", include("apps.loyalty.urls")),
    path("coupons/", include("apps.coupons.urls")),
    path("inventory/", include("apps.inventory.urls")),
    path("suppliers/", include("apps.suppliers.urls")),
    path("purchasing/", include("apps.purchasing.urls")),
    path("delivery/", include("apps.delivery.urls")),
    path("notifications/", include("apps.notifications.urls")),
    path("reports/", include("apps.reports.urls")),
    path("audit-logs/", include("apps.audit_logs.urls")),
    path("api-keys/", include("apps.api_keys.urls")),
    path("webhooks/", include("apps.webhooks.urls")),
    path("files/", include("apps.files.urls")),
]

urlpatterns = [
    path("admin/", admin.site.urls),
    path("api/", include(api_urls)),
    path("api/schema/", SpectacularAPIView.as_view(), name="schema"),
    path("api/docs/", SpectacularSwaggerView.as_view(url_name="schema"), name="swagger"),
    path("api/redoc/", SpectacularRedocView.as_view(url_name="schema"), name="redoc"),
    path("health/", include("apps.accounts.health_urls")),
]
