"""ASGI config — wires Channels websocket routing alongside HTTP."""
import os

import django
from channels.auth import AuthMiddlewareStack
from channels.routing import ProtocolTypeRouter, URLRouter
from channels.security.websocket import AllowedHostsOriginValidator
from django.core.asgi import get_asgi_application

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings.prod")
django.setup()

http_application = get_asgi_application()

from apps.kitchen.routing import websocket_urlpatterns as kitchen_ws  # noqa: E402
from apps.orders.routing import websocket_urlpatterns as orders_ws  # noqa: E402
from apps.tables.routing import websocket_urlpatterns as tables_ws  # noqa: E402
from apps.delivery.routing import websocket_urlpatterns as delivery_ws  # noqa: E402
from apps.notifications.routing import websocket_urlpatterns as notif_ws  # noqa: E402

application = ProtocolTypeRouter(
    {
        "http": http_application,
        "websocket": AllowedHostsOriginValidator(
            AuthMiddlewareStack(
                URLRouter(kitchen_ws + orders_ws + tables_ws + delivery_ws + notif_ws),
            ),
        ),
    }
)
