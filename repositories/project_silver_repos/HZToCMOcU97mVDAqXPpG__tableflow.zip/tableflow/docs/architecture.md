# TableFlow — Architecture

## Overview

TableFlow is a **Django + DRF** monorepo with three React frontends. The
backend is multi-tenant (`restaurant_id` on every domain row), and the
realtime layer uses **Django Channels** over Redis.

```
backend/                     Django project + 26 apps
frontend/                    Operator dashboard (Vite + React)
customer_portal/             Customer ordering app (Vite + React)
kitchen_display/             Kitchen Display Screen (Vite + React)
docker/, scripts/, docs/
```

## Apps

| App                | Purpose                                         |
|--------------------|-------------------------------------------------|
| accounts           | User, JWT, TOTP, sessions, password reset       |
| restaurants        | Restaurant, BusinessHours, Holiday, Member, Inv |
| branches           | Per-location data                               |
| staff              | StaffProfile, StaffShift, TimeClockEntry        |
| roles              | Role bundles, preset provisioning               |
| permissions        | Catalog + 10 role presets                       |
| menus              | Menu, MenuCategory, MenuItem, Variant, Photo    |
| modifiers          | ModifierGroup, Option, ComboMeal                |
| tables             | DiningArea, Table, QR codes, status history     |
| reservations       | Reservation, Waitlist, Deposit, transitions     |
| orders             | Order, OrderItem, Modifier, status, signals     |
| kitchen            | KitchenStation, Ticket, TicketItem, timing      |
| payments           | Payment, Refund, Receipt, DailyCloseout, Stripe |
| customers          | Customer, Address, Preference, Tag              |
| loyalty            | Account, Transaction, Reward, Redemption        |
| coupons            | Coupon, Promotion, Redemption                   |
| inventory          | Ingredient, Recipe, Transaction, Count, Waste   |
| suppliers          | Supplier, Contact, Invoice                      |
| purchasing         | PurchaseOrder, items, receive flow              |
| delivery           | Zone (polygon), DeliveryOrder, driver assign   |
| notifications      | Notification, Preference, EmailLog, dispatcher  |
| reports            | Aggregations, ReportExport, daily digest        |
| audit_logs         | Append-only audit, JSON formatter               |
| api_keys           | Hashed bearer tokens with scopes                |
| webhooks           | Endpoints, deliveries, HMAC signing             |
| files              | FileAsset, S3 presigned uploads                 |

## Request lifecycle

1. Browser → Django (`/api/...`)
2. CORS / CSRF / session middleware → JWTAuthentication
3. RestaurantContextMiddleware attaches `request.restaurant_id` from JWT
4. AuditContextMiddleware adds a per-request id
5. View calls `requirePermission('...')` then delegates to a service
6. Services interact with Postgres, write audit rows, dispatch tasks
7. Errors flow through the RFC 7807 problem-details handler

## Async work

Celery workers run eight queues:

```
orders       — confirmations, fan-out tickets
reservations — release unpaid, reminders
payments     — Stripe webhooks
notifications— email/sms/push dispatch
inventory    — low-stock scan, deduct on completion
delivery     — ETA pushes
reports      — CSV/PDF builds, daily digest
webhooks     — outbound HMAC-signed deliveries with retry
```

## Realtime

Channels groups:

- `tables.<branch_id>` — floor staff
- `orders.<branch_id>` — POS + reception
- `kitchen.<branch_id>` — KDS
- `delivery.<branch_id>` — delivery board
- `notifications.<user_id>` — direct in-app notifications

## See also

- [docs/api.md](api.md) — HTTP endpoints
- [docs/database.md](database.md) — schema
- [docs/permissions.md](permissions.md) — RBAC
- [docs/restaurant-workflow.md](restaurant-workflow.md) — order lifecycle
