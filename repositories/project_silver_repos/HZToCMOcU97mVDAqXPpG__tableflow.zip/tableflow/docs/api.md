# TableFlow — HTTP API

All authenticated requests need a `Bearer` access token from `/api/auth/login`.
Errors follow [RFC 7807 problem details](https://datatracker.ietf.org/doc/html/rfc7807).

## Auth

```
POST   /api/auth/register           {email, name, password}
POST   /api/auth/login              {email, password, totp_code?}
POST   /api/auth/refresh            {refresh_token}
POST   /api/auth/logout             {refresh_token}
GET    /api/auth/me
PATCH  /api/auth/me
POST   /api/auth/change-password
POST   /api/auth/password-reset/request
POST   /api/auth/password-reset/confirm
GET    /api/auth/totp/enroll        → {secret, otpauth_url, qr_data_url}
POST   /api/auth/totp/enroll        {code}
POST   /api/auth/totp/disable       {code}
GET    /api/auth/sessions
```

## Restaurant + branches + staff + roles

```
GET    /api/restaurants/                  list my restaurants
POST   /api/restaurants/                  create one (provisions roles + main branch)
GET    /api/restaurants/current
PATCH  /api/restaurants/current
GET    /api/restaurants/business-hours
POST   /api/restaurants/business-hours
GET    /api/restaurants/holidays
POST   /api/restaurants/invitations       {email, role}

GET    /api/branches/
POST   /api/branches/
PATCH  /api/branches/:id
DELETE /api/branches/:id

GET    /api/staff/
POST   /api/staff/
GET    /api/staff/shifts
POST   /api/staff/shifts
POST   /api/staff/time-clock/in
POST   /api/staff/time-clock/out

GET    /api/roles/
POST   /api/roles/
GET    /api/roles/catalog                  → all permission strings
```

## Menu

```
GET    /api/menus/
POST   /api/menus/
GET    /api/menus/categories
POST   /api/menus/categories
GET    /api/menus/items
POST   /api/menus/items
PATCH  /api/menus/items/:id
GET    /api/modifiers/groups
POST   /api/modifiers/groups
GET    /api/modifiers/options
POST   /api/modifiers/options
```

## Tables + reservations

```
GET    /api/tables/
POST   /api/tables/
POST   /api/tables/:id/transition          {to_status, note?}
POST   /api/tables/:id/qr/rotate
GET    /api/tables/areas

GET    /api/reservations/?from=&to=
POST   /api/reservations/
POST   /api/reservations/:id/transition    {to_status, note?}
GET    /api/reservations/waitlist
```

## Orders + kitchen + payments

```
GET    /api/orders/?branch=&status=
POST   /api/orders/
GET    /api/orders/:id
POST   /api/orders/:id/items               {menu_item, variant?, modifier_options[], quantity, note?}
POST   /api/orders/:id/items/:item_id/void
POST   /api/orders/:id/transition          {to_status}
POST   /api/orders/:id/split               {items[]}

GET    /api/kitchen/tickets?active=1
POST   /api/kitchen/tickets/:id/transition {to_status}
POST   /api/kitchen/tickets/:id/items/:item_id/done
GET    /api/kitchen/stations

GET    /api/payments/
POST   /api/payments/capture               {order, amount_cents, tip_cents?, method, notes?}
POST   /api/payments/refunds               {payment, amount_cents, reason?}
POST   /api/payments/closeouts/create      {branch, date, counted_cents, notes?}
POST   /api/payments/webhooks/stripe       (Stripe-signed)
```

## Customers, loyalty, coupons

```
GET    /api/customers/
POST   /api/customers/
GET    /api/customers/:id
PATCH  /api/customers/:id

GET    /api/loyalty/accounts
GET    /api/loyalty/rewards
POST   /api/loyalty/rewards
POST   /api/loyalty/adjust                  {customer, points, note?}
POST   /api/loyalty/redeem                  {customer, reward, order?}

GET    /api/coupons/
POST   /api/coupons/
POST   /api/coupons/apply                   {code, order}
GET    /api/coupons/promotions
```

## Inventory + suppliers + purchasing

```
GET    /api/inventory/
POST   /api/inventory/
POST   /api/inventory/:id/adjust            {new_on_hand, note?}
POST   /api/inventory/waste                  {ingredient, quantity, reason}
GET    /api/inventory/low-stock
GET    /api/inventory/counts
POST   /api/inventory/counts
POST   /api/inventory/counts/:id/finalize

GET    /api/suppliers/
POST   /api/suppliers/

GET    /api/purchasing/
POST   /api/purchasing/
POST   /api/purchasing/:id/submit
POST   /api/purchasing/:id/receive          {lines: {item_id: qty}}
POST   /api/purchasing/:id/cancel
```

## Delivery, notifications, reports

```
GET    /api/delivery/
POST   /api/delivery/:id/assign             {driver}
POST   /api/delivery/:id/transition         {to, note?, latitude?, longitude?}
GET    /api/delivery/zones
GET    /api/delivery/zone-lookup?lat=&lng=&branch=

GET    /api/notifications/?mine=1
POST   /api/notifications/read              {ids[]}
GET    /api/notifications/preferences
PATCH  /api/notifications/preferences

GET    /api/reports/dashboard
GET    /api/reports/exports
POST   /api/reports/exports/create          {kind, format, range_from, range_to, branch?}
```

## Audit, API keys, webhooks, files

```
GET    /api/audit-logs/?resource=&action=&actor=

GET    /api/api-keys/
POST   /api/api-keys/issue                  → {token} (returned once)
POST   /api/api-keys/:id/revoke

GET    /api/webhooks/
POST   /api/webhooks/                       {url, events[]}
DELETE /api/webhooks/:id
GET    /api/webhooks/deliveries

GET    /api/files/
POST   /api/files/sign-upload               → {bucket, key, fields, url}
POST   /api/files/finish-upload
GET    /api/files/:id/sign-download
```

## Pagination

List endpoints return:

```json
{
  "rows": [...],
  "page": 1,
  "page_size": 25,
  "total": 134,
  "pages": 6
}
```

Pass `?page=N&page_size=50` to paginate.
