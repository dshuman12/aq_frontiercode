# TableFlow — Customer portal

The customer portal (`customer_portal/`) is a public-facing app that
lets diners browse the menu, build a cart, place orders, and book
reservations.

## Routes

```
/                  Home with order CTAs
/menu              Categorized menu, add-to-cart
/cart              Edit quantities, see subtotal
/checkout          Pickup/delivery toggle + customer details
/orders            Past orders (auth required)
/orders/:id        Live status of a specific order
/reserve           Reservation request form
/login             Sign-in / register
```

## Cart persistence

The cart lives in `localStorage` under `tableflow.customer`. The
`useStore` hook wraps zustand with a persist middleware so cart state
survives reloads.

## Auth

Customers register or sign in through the same `/api/auth/login`
endpoint as staff. The portal stores the access token in `localStorage`
and sets it on every axios request via `setToken`.

## Order status updates

After checkout, the portal polls `/api/orders/:id` every few seconds for
the latest status. A future iteration will use the websocket
(`/ws/orders/<branch_id>`) for push updates.

## Theming

The portal uses a warm orange palette (`brand-50` through `brand-900`).
Restaurants can override via the future `branding` settings on
`Restaurant`.

## Embedding

Restaurants can embed the portal under their own domain by reverse-
proxying `/portal/*` to the portal's static build and routing API calls
back to the central TableFlow API.
