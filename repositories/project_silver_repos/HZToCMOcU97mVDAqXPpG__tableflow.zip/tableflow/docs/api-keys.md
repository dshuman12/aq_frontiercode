# TableFlow — API key guide

## Issuing a key

Operators with `api-keys:create` can mint keys via `Admin → API keys` or:

```http
POST /api/api-keys/issue
Authorization: Bearer <jwt>
Content-Type: application/json

{ "label": "Square POS", "scopes": ["orders:read", "menu:read"] }
```

The response contains `token` once — store it now. Subsequent reads
return only `prefix` and `last_used_at`.

## Calling the API with a key

```http
GET /api/orders/
Authorization: Token tflw_<base64url-secret>
```

The `ApiKeyAuthMiddleware` attaches `request.api_key`, sets
`request.restaurant_id`, and uses the key's `scopes` as the permission
set for the request.

## Rotating a key

Issue a new key, update the consumer, then revoke the old:

```http
POST /api/api-keys/<id>/revoke
```

Revoking is permanent; revoked keys cannot be reactivated.

## Scopes

Use the same string catalog as user roles. A key with `["orders:read"]`
can list orders but not transition them.

## Storage

- The token itself is **not** stored. Only an HMAC-SHA256 (under `SECRET_KEY`) is persisted.
- The `prefix` field stores the first 12 characters so admins can identify a leaked key.
- `last_used_at` is updated on each successful call (every minute at most, to reduce write contention in the future).

## Common pitfalls

- The `Token` scheme uses the literal string `Token ` (trailing space) — not `Bearer`.
- Keys are scoped to a single restaurant. Cross-tenant calls with a key return 404.
- A key cannot have `*` (wildcard) — that's reserved for users.
