# TableFlow — Security

## Authentication

- Passwords hashed with **Argon2id** by default (PBKDF2 fallback in tests).
- HS256 JWT with `JWT_ACCESS_TTL_MINUTES` (default 15). Refresh tokens are 30-day opaque hex strings stored hashed (HMAC-SHA256 of the token under `SECRET_KEY`) in `accounts_session`.
- Optional **TOTP** (RFC 6238) per user via pyotp. Enrolment hands back a QR data URL.
- Account-level lockout after 5 consecutive failed logins (configurable in settings).

## Authorization

- Every authenticated route declares `perm("<code>")`.
- Permissions live in `apps/permissions/catalog.py` and `apps/permissions/presets.py`.
- The wildcard `*` is reserved for `owner` only.
- API keys carry their own scope list; the `ApiKeyAuthMiddleware` attaches them to the request.

## Multi-tenancy

- Every domain row carries `restaurant_id`.
- `RestaurantContextMiddleware` reads the restaurant id off the JWT, never the request body.
- Cross-tenant reads return 404 (not 403) to avoid leaking existence.

## PHI / PII handling

- `JsonFormatter` redacts password, secret, token, refresh_token, ssn, card_number, cvv, totp_secret, and email addresses before serializing log records.
- Audit log captures every privileged action with actor, resource, IP, request_id, and a JSON `diff`.
- Soft delete is preferred over hard delete; the `audit_logs` table is append-only.

## Transport

- TLS 1.2+ in production. The `prod.py` settings enable HSTS (1 year, preload), HTTPS redirect, secure cookies, and `X-Frame-Options: DENY`.
- CORS is locked to the configured `APP_URL`, `CUSTOMER_PORTAL_URL`, and `KITCHEN_URL`.

## Webhooks

Outbound webhooks are signed `t=<unix-ts>,v1=<hmac-sha256-hex>`. Recipients
verify with the construction described in `apps/webhooks/sign.py`. Failed
deliveries retry with exponential backoff (8 attempts) before pausing the
subscription.

## Rate limiting

- Login endpoint: 10 attempts / 15 minutes per IP via `django-ratelimit` (when installed).
- Notification dispatcher uses a per-restaurant token bucket to prevent runaway sends.

## Right to erasure

`DELETE /api/customers/:id` archives a customer (soft delete). A separate
admin-only `apps/customers/erasure.py` flow runs the full cascade: orders
become `customer=NULL`, `customer_address` and `customer_preference` rows
are removed, and an audit log row records the snapshot.

## Stripe

- Webhook signature is verified via `Webhook.construct_event` using `STRIPE_WEBHOOK_SECRET`.
- Simulated mode (no `STRIPE_SECRET`) returns deterministic pseudo-IDs so dev work doesn't require live keys.
