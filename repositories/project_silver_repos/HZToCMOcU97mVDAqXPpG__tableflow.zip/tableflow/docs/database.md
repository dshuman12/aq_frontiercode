# TableFlow — Database

PostgreSQL via Django ORM. Every domain table carries a `restaurant_id` UUID
that participates in the leading index for tenant-scoped queries.

## Tenant + identity

- `accounts_user` — UUID PK, email unique, optional `totp_secret`
- `accounts_session` — refresh-token hash + UA + IP + expiry
- `accounts_password_reset` — hashed token + expiry
- `restaurants` — name, slug, plan, timezone, brand
- `restaurants_business_hours` — weekday × (open, close, closed?)
- `restaurants_holiday` — date-specific override
- `restaurant_member` — user×restaurant×role (with branches m2m)
- `restaurant_invitation` — pending team invites
- `branches` — locations
- `roles` — preset + custom permission bundles

## Menu

- `menus` — slug, weekdays, time window, branches m2m
- `menu_category` — sort order, item rollup
- `menu_item` — base price, allergens, dietary, prep time, kitchen station
- `menu_item_photo` — link to FileAsset
- `menu_item_variant` — name + price delta
- `modifier_group` — required, min/max select, items m2m
- `modifier_option` — price delta, default, available
- `combo_meal` + `combo_meal_item` — meal bundles

## Tables + reservations

- `dining_area` — by branch, kind = dining/bar/patio/private
- `restaurant_table` — number, capacity, status, server, x/y coords, merged_into
- `table_qr_code` — opaque token rotated per request
- `table_status_history` — append-only state log
- `reservation` — branch, table, party_size, starts_at, duration, status, deposit
- `reservation_status_history`
- `waitlist_entry`
- `reservation_deposit` — Stripe-backed

## Orders + kitchen

- `orders_order` — number, kind, table, server, money rollups, status
- `orders_order_item` — name snapshot, base/variant/quantity, line_total
- `orders_order_item_modifier`
- `orders_status_history`
- `kitchen_station`
- `kitchen_ticket` — order × station + status
- `kitchen_ticket_item`

## Finance

- `payment` — Stripe intent, method, status, captured_at, tip_cents
- `refund` — partial-refund tracker, status
- `receipt`
- `daily_closeout` — expected vs counted, diff
- `payment_method` — saved customer cards

## Customers + loyalty + coupons

- `customer` + `customer_address` + `customer_preference` + `customer_tag`
- `loyalty_account` — points balance, tier
- `loyalty_transaction` — earn/redeem/adjust/expire
- `loyalty_reward` + `loyalty_redemption`
- `coupon` + `coupon_redemption` + `promotion`

## Inventory + suppliers + purchasing

- `ingredient_category` + `ingredient`
- `recipe` (per menu_item) + `recipe_ingredient`
- `inventory_transaction` — purchase/sale/waste/adjust/count/transfer
- `inventory_count` + `inventory_count_line`
- `waste_log`
- `supplier` + `supplier_contact` + `supplier_invoice`
- `purchase_order` + `purchase_order_item`

## Delivery + notifications + ops

- `delivery_zone` (polygon JSON)
- `delivery_order` + `delivery_driver_assignment` + `delivery_status_history`
- `notification` + `notification_preference` + `email_log`
- `report_export`
- `audit_logs` — append-only, indexed `(restaurant_id, created_at)` and `(restaurant_id, resource, resource_id)`
- `api_keys` — hashed token, prefix, scopes
- `webhook_endpoint` + `webhook_delivery`
- `files_asset` — S3 bucket+key + checksum

## Indexing strategy

- Every domain table: leading `(restaurant_id, ...)` index
- `orders_order`: also `(restaurant_id, branch, status, created_at)` and `(restaurant_id, kind, created_at)`
- `kitchen_ticket`: `(restaurant_id, station, status, created_at)`
- `payment`: `(restaurant_id, branch, created_at)`
- `audit_logs`: append-only, never UPDATE'd

## Soft delete

- `is_archived` is preferred over hard delete on user-facing entities (Menu items, Suppliers, Customers).
- Hard delete is reserved for ephemeral data (sessions, password resets, expired notifications).
