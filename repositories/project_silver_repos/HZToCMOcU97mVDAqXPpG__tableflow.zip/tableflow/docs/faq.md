# TableFlow — FAQ

### Why Django and not FastAPI?

Onboarding speed and the size of the operational surface area. The Django
admin alone covers a lot of "manager wants to fix one row" workflows
without us building an admin UI. Django Channels + DRF are mature.

### Can I run multiple restaurants in one deployment?

Yes — that's the default. Every domain row carries `restaurant_id` and
every service method takes it as the first argument. The
`RestaurantContextMiddleware` derives it from the JWT, never the body.

### How is the customer portal isolated from staff?

The customer portal uses the same JWT issuance but with a customer-bound
`Customer` row. Routes guard tenant access via `request.restaurant_id`.
Future work: a separate JWT `kind` claim to fully isolate them.

### Where does PHI / PII go in the logs?

Nowhere readable. The `JsonFormatter` redacts password, secret, token,
ssn, card_number, cvv, totp_secret, and any matching email/phone in
strings before serializing. See `apps.audit_logs.log_format`.

### Can clinics customize roles?

Yes — `Admin → Roles` builds arbitrary subsets of the permission catalog.
The 10 built-in presets are tagged `is_preset: true` and read-only.

### Does TableFlow support multiple branches?

Yes. Each restaurant has any number of `Branch` rows; tables, kitchen
stations, staff shifts, purchase orders, deliveries, and reports can be
branch-scoped. Owners and managers see all branches; everyone else is
restricted to their membership's `branches` set.

### How do reminders work?

A Celery beat task runs every 15 minutes and sends a reminder for
confirmed reservations within the next hour, but only once per
reservation (`reminder_sent_at` is set on send).

### Why MongoDB? Wait, you're not using MongoDB.

Right. TableFlow uses **Postgres**. We picked relational because order →
items → modifiers maps naturally to JOINs and we want strong constraints
on money columns.

### How do I add a new feature with its own routes?

```bash
python manage.py startapp my_feature backend/apps/my_feature
```

Then add it to `INSTALLED_APPS` in `config/settings/base.py`, register
its URL include in `config/urls.py`, and add the relevant permission
strings to `apps/permissions/catalog.py`.

### How do I export data?

`Admin → Reports` queues a CSV/PDF build. The job builds in the worker
and ships the result to the bucket; the row in `report_export` flips to
`ready` with a `file` reference.
