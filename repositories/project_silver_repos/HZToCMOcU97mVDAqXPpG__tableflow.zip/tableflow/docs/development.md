# TableFlow — Local development

## Prerequisites

- Python 3.11+
- Node 20+
- Docker (for Postgres, Redis, MinIO, Mailpit)

## First-time setup

```bash
cp .env.example .env
docker compose up -d
python -m venv .venv && source .venv/bin/activate
pip install -e backend[dev]
cd backend && python manage.py migrate
python ../scripts/seed_demo_data.py

# In separate terminals:
python manage.py runserver 0.0.0.0:8000
celery -A config worker -B -l info
cd ../frontend && pnpm install && pnpm dev
cd ../customer_portal && pnpm install && pnpm dev
cd ../kitchen_display && pnpm install && pnpm dev
```

## Demo credentials

```
Email:    owner@demo.test
Password: demo-password-12
```

## Tests

```bash
cd backend
pytest                                # whole backend
pytest apps/orders -k transitions     # one app
pytest --cov=apps --cov-report=term-missing
```

```bash
cd frontend && pnpm test               # vitest unit tests
pnpm e2e                                # playwright (api + web must be running)
```

## Useful commands

```bash
python scripts/check_permissions.py    # lint route ↔ catalog
python scripts/import_menu.py demo-bistro fixtures/menu.csv
python scripts/generate_sales_report.py demo-bistro 30 sales.csv
```

## Environment variables

| Var                    | Used by      | Notes                                  |
|------------------------|--------------|----------------------------------------|
| `DATABASE_URL`         | Django       | postgres URL                           |
| `REDIS_URL`            | api, worker  | base redis                             |
| `CELERY_BROKER_URL`    | worker       | typically redis db 1                   |
| `CHANNELS_REDIS_URL`   | api          | redis db 3 for websocket fan-out       |
| `STRIPE_SECRET`        | api          | optional — sim mode if blank           |
| `STRIPE_WEBHOOK_SECRET`| api          | required for live Stripe webhooks      |
| `JWT_ACCESS_TTL_MINUTES` | api        | default 15                             |
| `JWT_REFRESH_TTL_DAYS`  | api         | default 30                             |
| `EMAIL_BACKEND`        | api          | console in dev, SMTP in prod           |
| `AWS_S3_*`             | api          | MinIO in dev                           |

See [.env.example](../.env.example) for the full list.

## Branch model

- `main` is always deployable
- short-lived `feat/<scope>` and `fix/<scope>` branches
- migrations live in `backend/apps/<app>/migrations/`
