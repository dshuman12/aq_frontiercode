# TableFlow — Deployment

## Topology

```
    ┌─────────────┐  ┌──────────────────┐  ┌────────────────┐
    │ frontend    │  │ customer_portal  │  │ kitchen_display│
    │ (static)    │  │ (static)         │  │ (static)       │
    └──────┬──────┘  └─────────┬────────┘  └────────┬───────┘
           └────────────────────┴────────────────────┘
                                │ HTTPS / WSS
                       ┌────────▼─────────┐
                       │  Daphne (ASGI)   │
                       │  Django + DRF    │
                       │  Channels        │
                       └────────┬─────────┘
                                │
        ┌──────────────┬────────┼────────┬─────────────┐
        ▼              ▼        ▼        ▼             ▼
   ┌────────┐    ┌────────┐ ┌──────┐ ┌──────┐    ┌──────────┐
   │ Postgres│    │ Redis  │ │ S3   │ │Mailpit│   │ Celery   │
   └────────┘    └────────┘ └──────┘ │/SMTP │    │ workers  │
                                     └──────┘    └──────────┘
```

## Build

```bash
# Backend: no build step — runs directly via Daphne
pip install -e backend
cd frontend && pnpm install --frozen-lockfile && pnpm build
cd customer_portal && pnpm install --frozen-lockfile && pnpm build
cd kitchen_display && pnpm install --frozen-lockfile && pnpm build
```

## Run

```bash
DJANGO_SETTINGS_MODULE=config.settings.prod \
  daphne -b 0.0.0.0 -p 8000 config.asgi:application

celery -A config worker -l info -Q orders,reservations,payments,notifications,inventory,delivery,reports,webhooks
celery -A config beat -l info
```

Static frontends ship to a CDN or serve them via nginx.

## Health probes

- `GET /health/` — process up
- `GET /api/schema/` — DRF spectacular OpenAPI

## Scaling

- Daphne is stateless except for the Channels Redis adapter; scale horizontally.
- Celery: separate worker per queue if a single concern saturates.
- Postgres: index `(restaurant_id, ...)` on every domain table; consider Citus or per-tenant schemas at very large scale.
- Redis: BullMQ-equivalent. Keep memory-bound; persist with `--appendonly yes`.

## Observability

- Logs: `apps.audit_logs.log_format.JsonFormatter` redacts PHI before stdout.
- Audit log: `audit_logs` table is append-only; back it up but never DELETE.
- Webhooks: failed deliveries pause the endpoint after 8 attempts and surface in admin.
