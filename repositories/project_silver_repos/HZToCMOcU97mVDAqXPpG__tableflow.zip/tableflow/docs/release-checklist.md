# TableFlow — Release checklist

A concise pre-flight before cutting a tag.

## Code is green

- [ ] `ruff check apps config` clean
- [ ] `black --check apps config` clean
- [ ] `pytest --cov` passing; coverage hasn't regressed >2%
- [ ] `pnpm test` passing (frontend, customer_portal, kitchen_display)
- [ ] `python scripts/check_permissions.py` clean
- [ ] `pnpm e2e` passes against a freshly seeded environment

## Migrations

- [ ] Migration files committed alongside the model changes
- [ ] If a column gained `NOT NULL`, the rollout is staged: deploy code that writes both → backfill → flip the constraint
- [ ] New filter/sort columns have indexes

## Permissions

- [ ] New permissions added to `apps/permissions/catalog.py` AND at least one preset
- [ ] `scripts/check_permissions.py` reports zero missing entries

## UI / UX

- [ ] All three SPAs build (`pnpm build`)
- [ ] Loading and empty states present everywhere a network call is made
- [ ] New pages have at least one Playwright spec

## Observability

- [ ] New audit-worthy actions emit an `audit_logs` row
- [ ] New background jobs use structured logging
- [ ] PHI redaction in `apps.audit_logs.log_format` covers any newly persisted PHI shapes

## Docs

- [ ] `docs/api.md` lists new endpoints
- [ ] `docs/permissions.md` lists new permissions / preset grants
- [ ] `CHANGELOG.md` Unreleased section reflects the actual change

## Cut the release

- [ ] Move `Unreleased` → `[X.Y.Z]` in `CHANGELOG.md` with the date
- [ ] Tag `vX.Y.Z` and push
- [ ] Run the deploy pipeline; verify `/health/` is 200
- [ ] Smoke-test `/login`, `/`, `/orders`, `/kitchen`, `/admin/audit` against the live env
