# TableFlow — Permission model

TableFlow uses a flat string catalog of `<resource>:<action>` permissions.
Every protected route declares the one it needs:

```python
@permission_classes([perm("orders:create")])
```

A user's permission set is encoded into the JWT and read from
`request.permissions`. The wildcard `*` matches everything (owner only).

## Catalog (~95 strings)

See [`backend/apps/permissions/catalog.py`](../backend/apps/permissions/catalog.py)
for the full list. Categories:

```
restaurant:* / branches:* / members:* / roles:*
staff:* / shifts:* / time-clock:write
menu:* / modifiers:*
tables:* / reservations:*
orders:* / kitchen:*
payments:* / closeout:*
customers:* / loyalty:* / coupons:*
inventory:* / waste:write / suppliers:* / purchasing:*
delivery:*
notifications:* / reports:read / audit:read
api-keys:* / webhooks:* / files:*
```

## Role presets

There are 10 presets defined in [`presets.py`](../backend/apps/permissions/presets.py):

| Role               | Scope                                               |
|--------------------|-----------------------------------------------------|
| `owner`            | `["*"]` — everything                                |
| `manager`          | full operations + reads on audit                    |
| `cashier`          | menu read, orders, payments capture, customers      |
| `server`           | menu read, tables update, orders, kitchen read      |
| `chef`             | kitchen read+transition, inventory read, waste      |
| `kitchen_staff`    | kitchen read+transition only                        |
| `delivery_staff`   | orders read + delivery transitions                  |
| `inventory_manager`| inventory + suppliers + purchasing                  |
| `accountant`       | payments, closeouts, reports, suppliers read        |
| `viewer`           | read-only across the catalog                        |

## Adding a new permission

1. Add the string to `catalog.py`.
2. Decide which preset(s) should inherit it; update `presets.py`.
3. Use `perm("<new>")` on the route.
4. Run `python scripts/check_permissions.py` to validate the catalog
   matches the routes.

## Branch scoping

Most resources also carry a `branch_id`. The `RestaurantContextMiddleware`
attaches `request.branch_id` from the JWT. Service methods that read by
branch take it as the first argument; views derive it from the request.

Owners and managers see all branches; everyone else is restricted to their
membership's `branches` set. The wildcard `*` permission **does not**
bypass branch scoping — that's an explicit `cross-branch:read` style perm.
