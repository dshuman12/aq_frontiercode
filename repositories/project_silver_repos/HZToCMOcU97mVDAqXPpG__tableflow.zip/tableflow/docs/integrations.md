# TableFlow — Integrations

## Stripe (payments)

The Stripe wrapper at `apps/payments/stripe_client.py` enters **simulated
mode** when `STRIPE_SECRET` is unset (the dev default). Invoices and
captures still succeed, but no API calls leave the box.

Set live secrets to enable real charges:

```env
STRIPE_SECRET=sk_live_...
STRIPE_WEBHOOK_SECRET=whsec_...
STRIPE_PUBLISHABLE_KEY=pk_live_...
```

Webhook endpoint: `POST /api/payments/webhooks/stripe`. Configure Stripe
to send `payment_intent.succeeded`, `payment_intent.payment_failed`, and
`charge.refunded` to that path.

## Email

Two transports are wired:

- **SMTP** when `SMTP_HOST` is set (`apps.notifications.tasks._send_email` uses Django's mail).
- **Console** transport otherwise — emails go to stdout in dev so SMTP isn't needed.

Templates live in `apps/notifications/templates_registry.py` with a tiny
Mustache-style replacer. Add a template by appending to the `REGISTRY`
dict.

## File uploads (S3 / MinIO)

`POST /api/files/sign-upload` returns a signed POST policy. The browser
uploads directly to the bucket; the API persists the metadata only after
`POST /api/files/finish-upload`. In dev, MinIO at
`http://localhost:9000` is wired by `docker-compose.yml`.

## Channels (realtime)

WebSocket routes:

- `/ws/orders/<branch_id>` — POS + reception
- `/ws/kitchen/<branch_id>` — KDS
- `/ws/tables/<branch_id>` — floor staff
- `/ws/delivery/<branch_id>` — delivery board
- `/ws/notifications/<user_id>` — direct notifications

JWT is validated through `AuthMiddlewareStack` over Channels.

## Outbound webhooks

Restaurants can subscribe via `Admin → Webhooks`. Supported events:

```
order.placed     order.completed   order.cancelled
payment.captured reservation.created
inventory.low
```

Deliveries are signed `t=<unix>,v1=<hmac-sha256>` and retried up to 8 times
with exponential backoff. Failures past 8 attempts pause the subscription
and surface in the admin.

## SMS / push

Both default to a log-only transport in dev. Plug in Twilio or APNs by
adding a callable that takes `{kind, body}` and returns a result dict to
`apps/notifications/dispatcher.py`.

## API keys

Bearer tokens with the `tflw_` prefix. Issuance returns the secret
**once**; subsequent reads only show the prefix and `last_used_at`.
