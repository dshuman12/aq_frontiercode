# TableFlow — Webhooks

TableFlow ships HMAC-SHA256-signed webhook deliveries with exponential
backoff and automatic pause after 8 failures.

## Subscribing

```http
POST /api/webhooks/
{
  "url": "https://your.app/hooks/tableflow",
  "events": ["order.placed", "payment.captured"]
}
```

Response includes a `secret` — store it; you'll need it to verify signatures.

## Signature format

Each delivery includes:

```
X-TableFlow-Signature: t=1715797123,v1=ab3f...
X-TableFlow-Event: order.placed
Content-Type: application/json
```

`v1` is `HMAC-SHA256("<unix-timestamp>." + body, secret)`.

## Verification (Python)

```python
import hashlib, hmac, time

def verify(payload: bytes, header: str, secret: str, tolerance: int = 300) -> bool:
    parts = dict(p.split("=", 1) for p in header.split(","))
    ts = int(parts["t"])
    if abs(int(time.time()) - ts) > tolerance:
        return False
    body = f"{ts}.".encode() + payload
    expected = hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, parts["v1"])
```

## Verification (Node)

```js
const crypto = require('crypto');

function verify(payload, header, secret, tolerance = 300) {
  const parts = Object.fromEntries(header.split(',').map((p) => p.split('=')));
  const ts = parseInt(parts.t, 10);
  if (Math.abs(Math.floor(Date.now() / 1000) - ts) > tolerance) return false;
  const expected = crypto.createHmac('sha256', secret).update(`${ts}.${payload}`).digest('hex');
  return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(parts.v1));
}
```

## Retries

- Up to 8 attempts with exponential backoff (`2^n` seconds).
- Each attempt creates a `webhook_delivery` row with the response status and body.
- After 8 failures the endpoint is `paused_at`-stamped and stops receiving until manually resumed.

## Available events

```
order.placed     order.completed   order.cancelled
payment.captured reservation.created
inventory.low
```

## Idempotency

Receivers should be idempotent — TableFlow may retry a delivery with the
same body. Use the `id` field in the `data` payload as the dedupe key.
