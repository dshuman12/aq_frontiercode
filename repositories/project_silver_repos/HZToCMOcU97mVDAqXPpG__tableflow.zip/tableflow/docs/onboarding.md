# TableFlow — Onboarding new restaurants

## Step 1 — Create the restaurant

The owner signs up at `/login → register` (or accepts an invitation).
Then visits `/onboarding`, which posts:

```
POST /api/restaurants/
{
  "name": "Demo Bistro",
  "cuisine": "Italian",
  "timezone": "America/Chicago"
}
```

The service:

1. Creates a slugified `Restaurant` (collision-safe — appends `-2`, `-3`).
2. Provisions all 10 preset roles via `apps.roles.services.provision_preset_roles`.
3. Creates a `Main` branch with the same timezone.
4. Adds the owner as `is_owner=True` member with the `owner` role.
5. Seeds 7 weekday `BusinessHours` rows (closed Sundays by default).

## Step 2 — Build the menu

`Admin → Menu builder` lets you import a CSV via:

```
python scripts/import_menu.py demo-bistro fixtures/menu.csv
```

Or click-through:
1. Create a `Menu` (e.g. "Dinner")
2. Add `MenuCategory` rows (Starters, Mains, ...)
3. Add `MenuItem` rows under each category, with allergens + prep time

## Step 3 — Map kitchen stations

Each item points to a `KitchenStation` so tickets fan out correctly.
Run `scripts/backfill_kitchen_stations.py demo-bistro Main` to seed the
default 8 stations (grill, fryer, pizza, salad, dessert, drinks, bar,
packaging), then assign items in the menu builder.

## Step 4 — Layout the floor

`Admin → Floor`:
1. Create one or more `DiningArea` rows (Inside, Patio).
2. Add tables under each area, each with capacity and a number.
3. QR codes auto-issue on creation; rotate from the table detail.

## Step 5 — Invite staff

`Admin → Staff → Invite member` accepts an email + role and sends a
signed link. The recipient lands on `/onboarding/accept?token=...`,
chooses a password, and joins.

## Step 6 — Wire integrations

- **Stripe**: set `STRIPE_SECRET` + webhook secret; no app changes.
- **Email**: SMTP if you want email; console transport otherwise.
- **Webhooks**: `Admin → Webhooks` to add outbound endpoints.

## Step 7 — Open for business

Reservations and online orders flow into `Reception` and `Kitchen`. The
floor view colors tables by status; click to advance.
