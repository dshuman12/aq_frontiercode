# TableFlow — Kitchen Display Screen (KDS)

A dark-themed, high-contrast app meant for the wall-mounted screen in
each kitchen station.

## Routes

The KDS is a single page. Station selection is a top-bar control:

```
all  grill  fryer  pizza  salad  bar  packaging
```

## Tile colors

| Status        | Background | Note                               |
|---------------|------------|------------------------------------|
| `queued`      | slate-700  | Just landed; not started           |
| `in_progress` | amber-600  | Cook is working on it              |
| `ready`       | green-700  | Done; waiting on a server          |
| `delayed`     | red-700    | Elapsed > expected + 5min slack    |

## Timer

Each tile shows the elapsed minutes since `started_at` (or `created_at`
if not yet started). The pure logic lives in `src/elapsed.js` and is
unit-tested.

## Per-item done

Each line on a ticket can be marked done individually:

```
1× Margherita pizza         [mark done]
2× Truffle fries            [✓ done]
```

When the last unfinished item flips, the ticket auto-promotes to
`ready` (handled by the API in `apps/kitchen/services.mark_item_done`).

## Polling

The KDS polls `/api/kitchen/tickets?active=1` every 5 seconds. Channels
push (`/ws/kitchen/<branch_id>`) is available too — wire it up by
calling `useWebSocket` and merging events into the cache.

## Hardware

We test the KDS on a 24" wall-mounted Android tablet running Chrome in
kiosk mode. The layout is responsive down to 800×600.
