# TableFlow — Troubleshooting

## "django.db.utils.OperationalError: connection refused"

Postgres isn't up. Run `docker compose up -d postgres` and check `docker compose ps`.

## "channels.exceptions.InvalidChannelLayerError"

Redis isn't reachable, or `CHANNELS_REDIS_URL` is wrong. Verify
`docker compose ps redis` and the value of `CHANNELS_REDIS_URL` in `.env`.

## Stripe webhook signature mismatch

In dev with `stripe listen`, copy the printed `whsec_…` value into
`STRIPE_WEBHOOK_SECRET`. Without it, the API rejects the webhook (this
is intentional).

## Frontend says "Network Error" on every call

The Vite dev server proxies `/api` and `/ws` to `localhost:8000`. If the
backend isn't running first, the proxy config doesn't matter — start
Daphne / runserver, then reload Vite.

## Permission denied on every request

Two likely causes:

1. The role assigned to your user is missing the required permission. Visit `Admin → Roles` and verify the assignment.
2. A new permission was added to a route but not the catalog. Run `python scripts/check_permissions.py` to catch this.

## "AppRegistryNotReady" when running scripts

Scripts must call `django.setup()` before importing apps. The bundled
scripts already do this — copy from `scripts/seed_demo_data.py` if
writing your own.

## Pytest "no settings module" error

Set `DJANGO_SETTINGS_MODULE=config.settings.test` (the bundled `pytest.ini` already does this).

## Celery tasks never run

`worker` isn't running. Start `celery -A config worker -B -l info`. The
`-B` flag also runs the beat scheduler that triggers reservation
reminders, low-stock scans, etc.

## Floor / Kitchen pages don't update in real time

The Channels websocket fallback to long-polling means a single failure
will not be obvious. Check that your reverse proxy passes
`Upgrade: websocket` headers (Nginx: `proxy_set_header Connection "upgrade";`).

## Migrations conflict

If two branches each generated a migration with the same number, run:

```bash
python manage.py makemigrations --merge
```

then commit the merge migration.

## Stale Customer Portal cart

The cart is stored in `localStorage` under `tableflow.customer`. Clear
that key in DevTools to reset.
