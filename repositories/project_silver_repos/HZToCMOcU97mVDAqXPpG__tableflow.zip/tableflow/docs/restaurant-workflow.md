# TableFlow — Restaurant workflow

## Order lifecycle

```
   draft ── place ──▶ placed ── accept ──▶ accepted ── start ──▶ preparing
                                                                       │
                                                                       ▼
                                                                     ready
                                                                       │
                          ┌────────────────────────────────────────────┤
                          │ dine_in                                    │ delivery / takeout
                          ▼                                            ▼
                       served ── complete ──▶ completed       out_for_delivery ── deliver ──▶ completed
                                                                       │
                                                                       └─▶ cancelled / refunded
```

The full transition table lives in [`apps/orders/transitions.py`](../backend/apps/orders/transitions.py).

## Side effects on transitions

The signal handler in [`apps/orders/signals.py`](../backend/apps/orders/signals.py) reacts to status changes:

| New status        | Side effects                                                  |
|-------------------|---------------------------------------------------------------|
| `placed`          | Send confirmation email to customer                           |
| `accepted`        | Fan out kitchen tickets per station                           |
| `ready` (takeout) | Send pickup-ready notification                                |
| `completed`       | Deduct ingredients per recipe; emit `order.completed` webhook |

## Kitchen pipeline

When an order is `accepted`, the `fanout_kitchen_tickets` task creates one
`KitchenTicket` per affected station. Each ticket has its own state machine:

```
queued → in_progress → ready → served
   ↘            ↘
  cancelled  cancelled
```

Items can be marked done individually; when the last one flips, the ticket
is auto-promoted to `ready`.

## Reservation lifecycle

```
requested → confirmed → seated → completed
     ↘          ↘             ↘
    cancelled  cancelled    cancelled
                  ↘
                no_show
```

Unpaid reservations (deposit required but not paid) are auto-cancelled by
the `release_unpaid_reservations` Celery task every 5 minutes.

## Table transitions

```
available → reserved → seated → ordering → preparing → served → needs_cleaning → available
                                                                  ↘
                                                                 closed → available
```

Each transition appends a `TableStatusHistory` row. Floor staff drive
this from the operator dashboard's Floor page.

## Inventory deduction

When an order is `completed`, `inventory.tasks.deduct_for_order` runs
through every order item, looks up its `Recipe.lines`, and posts a
negative `InventoryTransaction` for each. The transaction has
`kind='sale'` and references the order so usage reports can attribute
consumption back to specific items.

## Closeout

End-of-day, a manager calls `POST /api/payments/closeouts/create` with
the counted cash. The service:

1. Computes `expected_cents` from captured payments by branch+date
2. Stores `(expected, counted, diff)` in `daily_closeout`
3. Emits an audit log entry

The dashboard surfaces non-zero diffs in red so accounting can investigate.
