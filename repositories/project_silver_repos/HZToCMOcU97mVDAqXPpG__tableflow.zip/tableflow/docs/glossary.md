# TableFlow — Glossary

| Term            | Meaning                                                                      |
|-----------------|------------------------------------------------------------------------------|
| Restaurant      | The top-level tenant. Every domain row carries its UUID.                     |
| Branch          | A physical location of a restaurant. Tables, staff, deliveries, etc.         |
| Member          | A user × restaurant join row, with a Role and an optional set of Branches.   |
| Role            | A bundle of permission strings (built-in or custom).                         |
| Permission      | A `<resource>:<action>` string, e.g. `orders:create`.                        |
| Menu            | A named, scheduled, branch-scoped collection of categories and items.        |
| Category        | An ordering inside a menu (Starters, Mains, Drinks).                         |
| Item            | A single sellable thing with base price, allergens, and a kitchen station.   |
| Variant         | A sub-version of an item (Small, Medium, Large) with a price delta.          |
| Modifier group  | A set of options attached to one or more items, with min/max select.         |
| Modifier option | A choice inside a group with a price delta.                                  |
| Combo meal      | A bundle of items at a special price.                                        |
| Dining area     | A physical zone (Inside, Patio, Bar). Tables belong to an area.              |
| Table           | A seatable spot with capacity, status, server, and an optional QR code.      |
| Reservation     | A scheduled visit. May require a deposit; reminders auto-send.               |
| Order           | A single sale. Has lines (items), modifiers, and a status state machine.    |
| Kitchen ticket  | A station-scoped subset of an order's items; cooks fulfill these.            |
| Closeout        | End-of-day cash count vs expected for a branch.                              |
| Ingredient      | A stockable raw material with par level, on-hand qty, unit cost.             |
| Recipe          | Ingredient mapping for a menu item; drives auto-deduction.                  |
| Coupon          | A marketing discount with redemption rules and expiry.                       |
| Reward          | Loyalty redemption — points cost + value/percent off.                        |
| Webhook         | An HMAC-signed POST to a customer URL on selected events.                    |
| API key         | A scoped bearer token used by integrations (alternative to JWT).             |
| Audit log       | An append-only record of every privileged action with actor, IP, and diff.   |
