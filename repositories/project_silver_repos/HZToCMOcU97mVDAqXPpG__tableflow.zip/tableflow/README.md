# TableFlow

A restaurant management and ordering platform for independent restaurants,
cafes, food trucks, cloud kitchens, and small restaurant groups.

Reservations, table management, POS ordering, kitchen display, payments,
inventory, loyalty, suppliers, delivery, reports — all in one Django
backend with three React frontends (admin, customer portal, kitchen
display). No AI features.

## Stack

Python, Django, Django REST Framework, PostgreSQL, Celery, Redis, Django
Channels, Stripe, Boto3, Docker, Pytest, Playwright, drf-spectacular.
React + Vite + Tailwind + TanStack Query + Zustand + React Hook Form +
Yup on the frontend.

## Layout

```
tableflow/
├── backend/
│   ├── config/                Django project (settings, urls, asgi, celery)
│   └── apps/                  26 Django apps (accounts, menus, orders, ...)
├── frontend/                  Operator dashboard (React + Vite)
├── customer_portal/           Customer-facing ordering app
├── kitchen_display/           Kitchen display screen (KDS)
├── docs/
├── docker/
└── scripts/
```

## Quick start

```sh
cp .env.example .env
docker compose up -d
make setup
make seed
make dev
```

| Surface         | URL                      |
| --------------- | ------------------------ |
| Operator web    | http://localhost:5173    |
| Customer portal | http://localhost:5174    |
| Kitchen display | http://localhost:5175    |
| API             | http://localhost:8000    |
| Admin           | http://localhost:8000/admin |
| API docs        | http://localhost:8000/api/docs/ |
| Mailpit         | http://localhost:8025    |
| MinIO console   | http://localhost:9001    |

## Documentation

| Topic                  | File                                              |
| ---------------------- | ------------------------------------------------- |
| Architecture overview  | [docs/architecture.md](docs/architecture.md)      |
| HTTP API reference     | [docs/api.md](docs/api.md)                        |
| Database schema        | [docs/database.md](docs/database.md)              |
| Permissions / RBAC     | [docs/permissions.md](docs/permissions.md)        |
| Restaurant workflow    | [docs/restaurant-workflow.md](docs/restaurant-workflow.md) |
| Security model         | [docs/security.md](docs/security.md)              |
| Integrations           | [docs/integrations.md](docs/integrations.md)      |
| Local development      | [docs/development.md](docs/development.md)        |
| Deployment             | [docs/deployment.md](docs/deployment.md)          |
| Release checklist      | [docs/release-checklist.md](docs/release-checklist.md) |
| Troubleshooting        | [docs/troubleshooting.md](docs/troubleshooting.md) |
| FAQ                    | [docs/faq.md](docs/faq.md)                        |
| Contributing           | [CONTRIBUTING.md](CONTRIBUTING.md)                |
| Changelog              | [CHANGELOG.md](CHANGELOG.md)                      |

## Demo credentials (after `python scripts/seed_demo_data.py`)

```
owner@demo.test / demo-password-12
```
