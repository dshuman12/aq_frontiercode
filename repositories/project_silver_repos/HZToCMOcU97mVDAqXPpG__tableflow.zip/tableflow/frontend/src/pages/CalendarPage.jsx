import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { Card, CardBody, CardHeader } from '../components/Card';
import { Button } from '../components/Button';
import { Drawer } from '../components/Drawer';
import { Field } from '../components/Field';
import { Input } from '../components/Input';
import { StatusPill } from '../components/StatusPill';
import { useToast } from '../components/Toast';
import { endpoints } from '../api/endpoints';

function startOfDay(d) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}

export function CalendarPage() {
  const qc = useQueryClient();
  const toast = useToast();
  const [date, setDate] = useState(() => startOfDay(new Date()));
  const [open, setOpen] = useState(false);
  const from = startOfDay(date).toISOString();
  const to = new Date(startOfDay(date).getTime() + 86400000 - 1).toISOString();

  const { data } = useQuery({
    queryKey: ['reservations', from],
    queryFn: () => endpoints.reservations.list({ from, to }),
  });
  const reservations = data?.rows || data || [];

  const create = useMutation({
    mutationFn: (body) => endpoints.reservations.create(body),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['reservations'] });
      toast.success('Reservation booked');
      setOpen(false);
    },
    onError: (e) => toast.error(e.message),
  });
  const transition = useMutation({
    mutationFn: ({ id, to_status }) => endpoints.reservations.transition(id, { to_status }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['reservations'] }),
  });

  const { register, handleSubmit, reset } = useForm({ defaultValues: { duration_minutes: 90, party_size: 2, source: 'phone' } });

  return (
    <>
      <div className="flex items-end justify-between mb-4">
        <h1 className="text-2xl font-semibold">Reservations</h1>
        <Button onClick={() => { reset(); setOpen(true); }}>New reservation</Button>
      </div>

      <div className="flex items-center gap-2 mb-3">
        <Button variant="secondary" onClick={() => setDate((d) => new Date(d.getTime() - 86400000))}>‹</Button>
        <input type="date" value={date.toISOString().slice(0, 10)} onChange={(e) => setDate(startOfDay(new Date(e.target.value)))} className="input w-auto" />
        <Button variant="secondary" onClick={() => setDate((d) => new Date(d.getTime() + 86400000))}>›</Button>
        <Button variant="secondary" onClick={() => setDate(startOfDay(new Date()))}>Today</Button>
      </div>

      <Card>
        <CardHeader title={`${reservations.length} reservations`} />
        <CardBody>
          <ul className="divide-y divide-slate-100">
            {reservations.map((r) => (
              <li key={r.id} className="py-3 flex items-center justify-between gap-3">
                <div>
                  <p className="font-medium">{new Date(r.starts_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} · {r.customer_name}</p>
                  <p className="text-xs text-slate-500">Party of {r.party_size} · {r.source}</p>
                </div>
                <div className="flex items-center gap-2">
                  <StatusPill kind="reservation" value={r.status} />
                  {r.status === 'requested' && (
                    <Button variant="secondary" onClick={() => transition.mutate({ id: r.id, to_status: 'confirmed' })}>Confirm</Button>
                  )}
                  {(r.status === 'confirmed' || r.status === 'requested') && (
                    <Button variant="secondary" onClick={() => transition.mutate({ id: r.id, to_status: 'seated' })}>Seat</Button>
                  )}
                </div>
              </li>
            ))}
          </ul>
        </CardBody>
      </Card>

      <Drawer open={open} onClose={() => setOpen(false)} title="New reservation">
        <form onSubmit={handleSubmit((d) => create.mutate(d))} className="space-y-3">
          <Field label="Branch ID" required><Input {...register('branch', { required: true })} /></Field>
          <Field label="Customer name" required><Input {...register('customer_name', { required: true })} /></Field>
          <Field label="Phone"><Input {...register('customer_phone')} /></Field>
          <Field label="Email"><Input type="email" {...register('customer_email')} /></Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Party size" required><Input type="number" min={1} {...register('party_size', { required: true, valueAsNumber: true })} /></Field>
            <Field label="Duration (min)"><Input type="number" {...register('duration_minutes', { valueAsNumber: true })} /></Field>
          </div>
          <Field label="Starts at" required><Input type="datetime-local" {...register('starts_at', { required: true })} /></Field>
          <div className="flex justify-end"><Button type="submit" loading={create.isPending}>Book</Button></div>
        </form>
      </Drawer>
    </>
  );
}
