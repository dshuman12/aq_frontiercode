import { useQuery } from '@tanstack/react-query';
import { Card, CardBody } from '../components/Card';
import { DataTable } from '../components/DataTable';
import { Button } from '../components/Button';
import { endpoints } from '../api/endpoints';

export function SuppliersPage() {
  const { data, isLoading } = useQuery({ queryKey: ['suppliers'], queryFn: () => endpoints.suppliers.list() });
  return (
    <>
      <div className="flex items-end justify-between mb-4">
        <h1 className="text-2xl font-semibold">Suppliers</h1>
        <Button>Add supplier</Button>
      </div>
      <Card>
        <CardBody className="!p-0">
          <DataTable
            loading={isLoading}
            rows={data?.rows || data || []}
            columns={[
              { key: 'name', header: 'Name' },
              { key: 'code', header: 'Code' },
              { key: 'phone', header: 'Phone' },
              { key: 'email', header: 'Email' },
              { key: 'terms', header: 'Terms', render: (s) => s.payment_terms || '—' },
            ]}
          />
        </CardBody>
      </Card>
    </>
  );
}
