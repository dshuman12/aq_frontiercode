import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardBody, CardHeader } from '../components/Card';
import { DataTable } from '../components/DataTable';
import { Button } from '../components/Button';
import { Field } from '../components/Field';
import { Input } from '../components/Input';
import { useToast } from '../components/Toast';
import { endpoints } from '../api/endpoints';

const KINDS = [
  'daily_sales', 'menu_items', 'revenue', 'payment_method', 'tips', 'tax', 'inventory_usage', 'waste', 'reservations', 'loyalty', 'staff',
];

export function ReportsPage() {
  const qc = useQueryClient();
  const toast = useToast();
  const [kind, setKind] = useState('daily_sales');
  const [from, setFrom] = useState(() => new Date(Date.now() - 30 * 86400000).toISOString().slice(0, 10));
  const [to, setTo] = useState(() => new Date().toISOString().slice(0, 10));

  const { data: dash } = useQuery({ queryKey: ['report-dash'], queryFn: () => endpoints.reports.dashboard() });
  const { data: exports, isLoading } = useQuery({ queryKey: ['exports'], queryFn: () => endpoints.reports.exports() });

  const create = useMutation({
    mutationFn: () => endpoints.reports.createExport({ kind, format: 'csv', range_from: from, range_to: to }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['exports'] }); toast.success('Queued'); },
  });

  return (
    <>
      <h1 className="text-2xl font-semibold mb-4">Reports</h1>
      <Card className="mb-4">
        <CardHeader title="Last 30 days" />
        <CardBody>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div><div className="text-sm text-slate-500">Orders today</div><div className="text-2xl font-semibold">{dash?.orders_today ?? 0}</div></div>
            <div><div className="text-sm text-slate-500">Revenue 30d</div><div className="text-2xl font-semibold">${((dash?.revenue_30d_cents ?? 0) / 100).toFixed(0)}</div></div>
            <div><div className="text-sm text-slate-500">Range</div><div className="text-sm">{dash?.range_from} → {dash?.range_to}</div></div>
          </div>
        </CardBody>
      </Card>
      <Card className="mb-4">
        <CardHeader title="Generate export" />
        <CardBody>
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <Field label="Kind">
              <select className="input" value={kind} onChange={(e) => setKind(e.target.value)}>
                {KINDS.map((k) => <option key={k}>{k}</option>)}
              </select>
            </Field>
            <Field label="From"><Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} /></Field>
            <Field label="To"><Input type="date" value={to} onChange={(e) => setTo(e.target.value)} /></Field>
            <div className="flex items-end"><Button onClick={() => create.mutate()} loading={create.isPending}>Queue export</Button></div>
          </div>
        </CardBody>
      </Card>
      <Card>
        <CardBody className="!p-0">
          <DataTable
            loading={isLoading}
            rows={exports?.rows || exports || []}
            columns={[
              { key: 'kind', header: 'Kind' },
              { key: 'format', header: 'Format' },
              { key: 'range', header: 'Range', render: (r) => `${r.range_from} → ${r.range_to}` },
              { key: 'status', header: 'Status' },
              { key: 'created_at', header: 'Created', render: (r) => new Date(r.created_at).toLocaleString() },
            ]}
          />
        </CardBody>
      </Card>
    </>
  );
}
