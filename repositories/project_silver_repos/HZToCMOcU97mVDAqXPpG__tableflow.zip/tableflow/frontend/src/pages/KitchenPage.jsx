import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardBody } from '../components/Card';
import { Button } from '../components/Button';
import { Badge } from '../components/Badge';
import { useToast } from '../components/Toast';
import { endpoints } from '../api/endpoints';

export function KitchenPage() {
  const qc = useQueryClient();
  const toast = useToast();
  const { data, isLoading } = useQuery({
    queryKey: ['kitchen-tickets'],
    queryFn: () => endpoints.kitchen.tickets({ active: 1 }),
    refetchInterval: 5_000,
  });

  const transition = useMutation({
    mutationFn: ({ id, to }) => endpoints.kitchen.transitionTicket(id, { to_status: to }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['kitchen-tickets'] }),
    onError: (e) => toast.error(e.message),
  });

  const tickets = data?.rows || data || [];
  if (isLoading) return <p className="text-slate-500">Loading…</p>;

  return (
    <>
      <h1 className="text-2xl font-semibold mb-4">Kitchen display</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
        {tickets.map((t) => (
          <Card key={t.id} className={t.status === 'in_progress' ? 'border-amber-300' : ''}>
            <CardHeader
              title={t.order_number || 'Order'}
              subtitle={`Station ${t.station} · ${new Date(t.created_at).toLocaleTimeString()}`}
              actions={<Badge tone={t.status === 'ready' ? 'success' : 'warn'}>{t.status}</Badge>}
            />
            <CardBody>
              <ul className="text-sm space-y-1 mb-3">
                {(t.items || []).map((it) => (
                  <li key={it.id} className="flex justify-between">
                    <span>{it.quantity}× line</span>
                    <button
                      type="button"
                      disabled={it.is_done}
                      onClick={() => endpoints.kitchen.markItemDone(t.id, it.id).then(() => qc.invalidateQueries({ queryKey: ['kitchen-tickets'] }))}
                      className="text-amber-700 disabled:text-slate-400 disabled:line-through"
                    >
                      {it.is_done ? 'done' : 'mark done'}
                    </button>
                  </li>
                ))}
              </ul>
              <div className="flex gap-2">
                {t.status === 'queued' && <Button onClick={() => transition.mutate({ id: t.id, to: 'in_progress' })}>Start</Button>}
                {t.status === 'in_progress' && <Button onClick={() => transition.mutate({ id: t.id, to: 'ready' })}>Ready</Button>}
                {t.status === 'ready' && <Button onClick={() => transition.mutate({ id: t.id, to: 'served' })}>Served</Button>}
              </div>
            </CardBody>
          </Card>
        ))}
      </div>
    </>
  );
}
