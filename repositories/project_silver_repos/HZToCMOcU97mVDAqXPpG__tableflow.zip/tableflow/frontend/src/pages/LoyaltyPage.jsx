import { useQuery } from '@tanstack/react-query';
import { Card, CardBody, CardHeader } from '../components/Card';
import { DataTable } from '../components/DataTable';
import { Badge } from '../components/Badge';
import { endpoints } from '../api/endpoints';

const TIER_TONE = { bronze: 'neutral', silver: 'info', gold: 'warn', platinum: 'brand' };

export function LoyaltyPage() {
  const { data: accounts } = useQuery({ queryKey: ['loyalty'], queryFn: () => endpoints.loyalty.accounts() });
  const { data: rewards } = useQuery({ queryKey: ['rewards'], queryFn: () => endpoints.loyalty.rewards() });

  return (
    <>
      <h1 className="text-2xl font-semibold mb-4">Loyalty</h1>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2">
          <CardHeader title="Top members" />
          <CardBody className="!p-0">
            <DataTable
              rows={(accounts?.rows || accounts || []).slice(0, 25)}
              columns={[
                { key: 'tier', header: 'Tier', render: (a) => <Badge tone={TIER_TONE[a.tier]}>{a.tier}</Badge> },
                { key: 'points', header: 'Points', render: (a) => a.points_balance },
                { key: 'lifetime', header: 'Lifetime', render: (a) => a.lifetime_points },
                { key: 'visits', header: 'Visits', render: (a) => a.visits },
              ]}
            />
          </CardBody>
        </Card>
        <Card>
          <CardHeader title="Rewards" />
          <CardBody>
            <ul className="text-sm divide-y divide-slate-100">
              {(rewards?.rows || rewards || []).map((r) => (
                <li key={r.id} className="py-2 flex justify-between">
                  <div>
                    <p className="font-medium">{r.name}</p>
                    <p className="text-xs text-slate-500">{r.kind}</p>
                  </div>
                  <div className="text-amber-700 font-semibold">{r.cost_points} pts</div>
                </li>
              ))}
            </ul>
          </CardBody>
        </Card>
      </div>
    </>
  );
}
