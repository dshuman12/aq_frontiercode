import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import clsx from 'clsx';
import { useState } from 'react';
import { Card, CardBody, CardHeader } from '../components/Card';
import { StatusPill } from '../components/StatusPill';
import { Button } from '../components/Button';
import { Modal } from '../components/Modal';
import { useToast } from '../components/Toast';
import { endpoints } from '../api/endpoints';

const STATUS_COLOR = {
  available: 'bg-green-50 border-green-300 text-green-900',
  reserved: 'bg-sky-50 border-sky-300 text-sky-900',
  seated: 'bg-amber-50 border-amber-300 text-amber-900',
  ordering: 'bg-amber-50 border-amber-300 text-amber-900',
  preparing: 'bg-orange-50 border-orange-300 text-orange-900',
  served: 'bg-green-50 border-green-300 text-green-900',
  needs_cleaning: 'bg-yellow-50 border-yellow-300 text-yellow-900',
  closed: 'bg-slate-100 border-slate-300 text-slate-600',
};

export function FloorPage() {
  const qc = useQueryClient();
  const toast = useToast();
  const [active, setActive] = useState(null);
  const { data, isLoading } = useQuery({ queryKey: ['tables'], queryFn: () => endpoints.tables.list({ is_active: true }) });
  const transition = useMutation({
    mutationFn: ({ id, to }) => endpoints.tables.transition(id, { to_status: to }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['tables'] });
      toast.success('Table updated');
      setActive(null);
    },
    onError: (e) => toast.error(e.message),
  });

  const tables = data?.rows || data || [];

  return (
    <>
      <h1 className="text-2xl font-semibold mb-4">Floor</h1>
      {isLoading ? (
        <div className="text-slate-500">Loading…</div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3">
          {tables.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setActive(t)}
              className={clsx('rounded-xl border-2 p-3 text-left hover:shadow', STATUS_COLOR[t.status] || STATUS_COLOR.available)}
            >
              <div className="font-bold">{t.number}</div>
              <div className="text-xs opacity-80">{t.capacity} seats</div>
              <div className="mt-2"><StatusPill kind="table" value={t.status} /></div>
            </button>
          ))}
        </div>
      )}

      <Modal
        open={!!active}
        onClose={() => setActive(null)}
        title={active ? `Table ${active.number}` : 'Table'}
        footer={
          active && (
            <div className="flex gap-2">
              {['seated', 'ordering', 'served', 'needs_cleaning', 'available'].map((s) => (
                <Button key={s} variant="secondary" onClick={() => transition.mutate({ id: active.id, to: s })}>
                  {s.replace('_', ' ')}
                </Button>
              ))}
            </div>
          )
        }
      >
        {active && (
          <div className="space-y-2 text-sm">
            <div>Status: <StatusPill kind="table" value={active.status} /></div>
            <div>Capacity: {active.capacity}</div>
            {active.qr_code && <div>QR: <code>{active.qr_code}</code></div>}
          </div>
        )}
      </Modal>
    </>
  );
}
