import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { Card, CardBody } from '../../components/Card';
import { Button } from '../../components/Button';
import { DataTable } from '../../components/DataTable';
import { Drawer } from '../../components/Drawer';
import { Field } from '../../components/Field';
import { Input } from '../../components/Input';
import { Badge } from '../../components/Badge';
import { useToast } from '../../components/Toast';
import { endpoints } from '../../api/endpoints';

export function RolesPage() {
  const qc = useQueryClient();
  const toast = useToast();
  const [drawer, setDrawer] = useState(null);
  const { data: roles, isLoading } = useQuery({ queryKey: ['roles'], queryFn: () => endpoints.roles.list() });
  const { data: catalog } = useQuery({ queryKey: ['perm-catalog'], queryFn: () => endpoints.roles.catalog() });

  const create = useMutation({
    mutationFn: (body) => endpoints.roles.create(body),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['roles'] }); setDrawer(null); toast.success('Saved'); },
    onError: (e) => toast.error(e.message),
  });

  const { register, handleSubmit, watch, setValue, reset } = useForm({ defaultValues: { permissions: [] } });
  const allPerms = catalog?.permissions || [];
  const togglePerm = (p) => {
    const cur = watch('permissions') || [];
    setValue('permissions', cur.includes(p) ? cur.filter((x) => x !== p) : [...cur, p]);
  };

  return (
    <>
      <div className="flex items-end justify-between mb-4">
        <h1 className="text-2xl font-semibold">Roles</h1>
        <Button onClick={() => { reset({ permissions: [] }); setDrawer(true); }}>New role</Button>
      </div>
      <Card>
        <CardBody className="!p-0">
          <DataTable
            loading={isLoading}
            rows={roles?.rows || roles || []}
            columns={[
              { key: 'name', header: 'Name' },
              { key: 'slug', header: 'Slug', render: (r) => <code className="font-mono text-xs">{r.slug}</code> },
              { key: 'count', header: 'Permissions', render: (r) => <Badge tone="brand">{(r.permissions || []).length}</Badge> },
              { key: 'preset', header: 'Preset', render: (r) => r.is_preset ? <Badge tone="info">preset</Badge> : null },
            ]}
          />
        </CardBody>
      </Card>

      <Drawer open={!!drawer} onClose={() => setDrawer(null)} title="New role">
        <form onSubmit={handleSubmit((d) => create.mutate(d))} className="space-y-3">
          <Field label="Name" required><Input {...register('name', { required: true })} /></Field>
          <Field label="Slug" required><Input {...register('slug', { required: true })} placeholder="custom_role" /></Field>
          <Field label="Permissions">
            <div className="grid grid-cols-2 gap-1 max-h-96 overflow-y-auto bg-slate-50 rounded-lg p-2">
              {allPerms.map((p) => (
                <label key={p} className="text-xs flex items-center gap-1.5">
                  <input type="checkbox" checked={(watch('permissions') || []).includes(p)} onChange={() => togglePerm(p)} />
                  <code className="font-mono">{p}</code>
                </label>
              ))}
            </div>
          </Field>
          <div className="flex justify-end"><Button type="submit" loading={create.isPending}>Create</Button></div>
        </form>
      </Drawer>
    </>
  );
}
