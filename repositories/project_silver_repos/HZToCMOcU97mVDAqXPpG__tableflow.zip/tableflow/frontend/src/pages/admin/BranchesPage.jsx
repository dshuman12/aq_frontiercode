import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { Card, CardBody } from '../../components/Card';
import { Button } from '../../components/Button';
import { DataTable } from '../../components/DataTable';
import { Modal } from '../../components/Modal';
import { Field } from '../../components/Field';
import { Input } from '../../components/Input';
import { useToast } from '../../components/Toast';
import { endpoints } from '../../api/endpoints';

export function BranchesPage() {
  const qc = useQueryClient();
  const toast = useToast();
  const [editing, setEditing] = useState(null);
  const { data, isLoading } = useQuery({ queryKey: ['branches'], queryFn: () => endpoints.branches.list() });

  const save = useMutation({
    mutationFn: (body) => editing?.id ? endpoints.branches.update(editing.id, body) : endpoints.branches.create(body),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['branches'] }); toast.success('Saved'); setEditing(null); },
    onError: (e) => toast.error(e.message),
  });

  const { register, handleSubmit, reset } = useForm();

  return (
    <>
      <div className="flex items-end justify-between mb-4">
        <h1 className="text-2xl font-semibold">Branches</h1>
        <Button onClick={() => { reset({ is_active: true }); setEditing({}); }}>Add branch</Button>
      </div>
      <Card>
        <CardBody className="!p-0">
          <DataTable
            loading={isLoading}
            rows={data?.rows || data || []}
            onRowClick={(b) => { reset(b); setEditing(b); }}
            columns={[
              { key: 'name', header: 'Name' },
              { key: 'code', header: 'Code' },
              { key: 'city', header: 'City' },
              { key: 'phone', header: 'Phone' },
              { key: 'pickup', header: 'Pickup', render: (b) => b.pickup_enabled ? '✓' : '—' },
              { key: 'delivery', header: 'Delivery', render: (b) => b.delivery_enabled ? '✓' : '—' },
            ]}
          />
        </CardBody>
      </Card>

      <Modal open={!!editing} onClose={() => setEditing(null)} title={editing?.id ? 'Edit branch' : 'New branch'}
        footer={<><Button variant="secondary" onClick={() => setEditing(null)}>Cancel</Button><Button onClick={handleSubmit((d) => save.mutate(d))} loading={save.isPending}>Save</Button></>}>
        <form className="space-y-3">
          <Field label="Name" required><Input {...register('name', { required: true })} /></Field>
          <Field label="Code"><Input {...register('code')} /></Field>
          <Field label="Address"><Input {...register('address')} /></Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="City"><Input {...register('city')} /></Field>
            <Field label="Postal code"><Input {...register('postal_code')} /></Field>
          </div>
          <Field label="Phone"><Input {...register('phone')} /></Field>
          <div className="flex gap-4">
            <label className="text-sm flex items-center gap-2"><input type="checkbox" {...register('pickup_enabled')} />Pickup</label>
            <label className="text-sm flex items-center gap-2"><input type="checkbox" {...register('delivery_enabled')} />Delivery</label>
          </div>
        </form>
      </Modal>
    </>
  );
}
