import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardBody } from '../../components/Card';
import { Field } from '../../components/Field';
import { Input } from '../../components/Input';
import { DataTable } from '../../components/DataTable';
import { endpoints } from '../../api/endpoints';

export function AuditPage() {
  const [resource, setResource] = useState('');
  const [action, setAction] = useState('');
  const { data, isLoading } = useQuery({
    queryKey: ['audit', resource, action],
    queryFn: () => endpoints.audit.list({ resource: resource || undefined, action: action || undefined }),
    keepPreviousData: true,
  });

  return (
    <>
      <h1 className="text-2xl font-semibold mb-4">Audit log</h1>
      <Card className="mb-3">
        <CardBody>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <Field label="Resource"><Input value={resource} onChange={(e) => setResource(e.target.value)} placeholder="order, payment, ..." /></Field>
            <Field label="Action"><Input value={action} onChange={(e) => setAction(e.target.value)} placeholder="payment.capture, ..." /></Field>
          </div>
        </CardBody>
      </Card>
      <Card>
        <CardBody className="!p-0">
          <DataTable
            loading={isLoading}
            rows={data?.rows || data || []}
            columns={[
              { key: 'when', header: 'When', render: (r) => new Date(r.created_at).toLocaleString() },
              { key: 'actor', header: 'Actor', render: (r) => r.actor_email || '—' },
              { key: 'action', header: 'Action' },
              { key: 'resource', header: 'Resource', render: (r) => `${r.resource}/${r.resource_id?.slice(0, 8)}` },
              { key: 'ip', header: 'IP' },
            ]}
          />
        </CardBody>
      </Card>
    </>
  );
}
