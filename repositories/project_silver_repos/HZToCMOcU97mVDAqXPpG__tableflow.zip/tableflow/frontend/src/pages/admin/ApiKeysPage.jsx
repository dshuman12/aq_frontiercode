import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { Card, CardBody } from '../../components/Card';
import { DataTable } from '../../components/DataTable';
import { Button } from '../../components/Button';
import { Modal } from '../../components/Modal';
import { Field } from '../../components/Field';
import { Input } from '../../components/Input';
import { useToast } from '../../components/Toast';
import { endpoints } from '../../api/endpoints';

export function ApiKeysPage() {
  const qc = useQueryClient();
  const toast = useToast();
  const [open, setOpen] = useState(false);
  const [revealed, setRevealed] = useState(null);
  const { data, isLoading } = useQuery({ queryKey: ['api-keys'], queryFn: () => endpoints.apiKeys.list() });
  const issue = useMutation({
    mutationFn: (body) => endpoints.apiKeys.issue(body),
    onSuccess: (k) => { setRevealed(k.token); qc.invalidateQueries({ queryKey: ['api-keys'] }); setOpen(false); },
  });
  const revoke = useMutation({
    mutationFn: (id) => endpoints.apiKeys.revoke(id),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['api-keys'] }); toast.success('Revoked'); },
  });
  const { register, handleSubmit, reset } = useForm();

  return (
    <>
      <div className="flex items-end justify-between mb-4">
        <h1 className="text-2xl font-semibold">API keys</h1>
        <Button onClick={() => { reset(); setOpen(true); }}>Create key</Button>
      </div>
      {revealed && (
        <Card className="mb-3 border-amber-300">
          <CardBody>
            <p className="text-sm font-semibold mb-2">Save this token — it won't be shown again:</p>
            <code className="font-mono text-xs break-all">{revealed}</code>
            <button className="ml-2 text-xs text-brand-700" onClick={() => setRevealed(null)}>×</button>
          </CardBody>
        </Card>
      )}
      <Card>
        <CardBody className="!p-0">
          <DataTable
            loading={isLoading}
            rows={data?.rows || data || []}
            columns={[
              { key: 'label', header: 'Label' },
              { key: 'prefix', header: 'Prefix', render: (k) => <code className="font-mono text-xs">{k.prefix}…</code> },
              { key: 'scopes', header: 'Scopes', render: (k) => (k.scopes || []).join(', ') || '—' },
              { key: 'last', header: 'Last used', render: (k) => k.last_used_at ? new Date(k.last_used_at).toLocaleString() : '—' },
              {
                key: 'actions',
                header: '',
                render: (k) => k.revoked_at ? <span className="text-slate-400">revoked</span> : (
                  <Button variant="danger" onClick={(e) => { e.stopPropagation(); revoke.mutate(k.id); }}>Revoke</Button>
                ),
              },
            ]}
          />
        </CardBody>
      </Card>

      <Modal open={open} onClose={() => setOpen(false)} title="Create API key"
        footer={<><Button variant="secondary" onClick={() => setOpen(false)}>Cancel</Button><Button onClick={handleSubmit((d) => issue.mutate({ ...d, scopes: (d.scopes || '').split(',').map((s) => s.trim()).filter(Boolean) }))} loading={issue.isPending}>Create</Button></>}>
        <form className="space-y-3">
          <Field label="Label" required><Input {...register('label', { required: true })} /></Field>
          <Field label="Scopes (comma-separated)" hint="Permission strings the key may use"><Input {...register('scopes')} placeholder="orders:read, payments:read" /></Field>
        </form>
      </Modal>
    </>
  );
}
