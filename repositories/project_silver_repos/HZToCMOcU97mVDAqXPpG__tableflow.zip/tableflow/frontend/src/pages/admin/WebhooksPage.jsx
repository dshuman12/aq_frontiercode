import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { Card, CardBody } from '../../components/Card';
import { Button } from '../../components/Button';
import { Drawer } from '../../components/Drawer';
import { DataTable } from '../../components/DataTable';
import { Field } from '../../components/Field';
import { Input } from '../../components/Input';
import { useToast } from '../../components/Toast';
import { endpoints } from '../../api/endpoints';

const EVENTS = [
  'order.placed', 'order.completed', 'order.cancelled',
  'payment.captured', 'reservation.created', 'inventory.low',
];

export function WebhooksPage() {
  const qc = useQueryClient();
  const toast = useToast();
  const [open, setOpen] = useState(false);
  const { data, isLoading } = useQuery({ queryKey: ['webhooks'], queryFn: () => endpoints.webhooks.list() });
  const create = useMutation({
    mutationFn: (body) => endpoints.webhooks.create(body),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['webhooks'] }); setOpen(false); toast.success('Created'); },
    onError: (e) => toast.error(e.message),
  });
  const { register, handleSubmit, watch, setValue } = useForm({ defaultValues: { events: [] } });
  const subscribed = watch('events') || [];
  const toggle = (ev) => setValue('events', subscribed.includes(ev) ? subscribed.filter((e) => e !== ev) : [...subscribed, ev]);

  return (
    <>
      <div className="flex items-end justify-between mb-4">
        <h1 className="text-2xl font-semibold">Webhooks</h1>
        <Button onClick={() => setOpen(true)}>New endpoint</Button>
      </div>
      <Card>
        <CardBody className="!p-0">
          <DataTable
            loading={isLoading}
            rows={data?.rows || data || []}
            columns={[
              { key: 'url', header: 'URL' },
              { key: 'events', header: 'Events', render: (w) => (w.events || []).join(', ') },
              { key: 'failures', header: 'Failures', render: (w) => w.failure_count || 0 },
              { key: 'paused', header: 'Paused', render: (w) => w.paused_at ? '⏸' : '✓' },
            ]}
          />
        </CardBody>
      </Card>

      <Drawer open={open} onClose={() => setOpen(false)} title="New webhook">
        <form onSubmit={handleSubmit((d) => create.mutate(d))} className="space-y-3">
          <Field label="Endpoint URL" required><Input {...register('url', { required: true })} placeholder="https://example.com/hooks" /></Field>
          <Field label="Events">
            <div className="flex flex-wrap gap-2">
              {EVENTS.map((e) => (
                <label key={e} className={'px-2 py-1 rounded-md border cursor-pointer ' + (subscribed.includes(e) ? 'bg-amber-100 border-amber-300' : 'border-slate-200')}>
                  <input type="checkbox" className="hidden" checked={subscribed.includes(e)} onChange={() => toggle(e)} />
                  <code className="text-xs">{e}</code>
                </label>
              ))}
            </div>
          </Field>
          <div className="flex justify-end"><Button type="submit" loading={create.isPending}>Create</Button></div>
        </form>
      </Drawer>
    </>
  );
}
