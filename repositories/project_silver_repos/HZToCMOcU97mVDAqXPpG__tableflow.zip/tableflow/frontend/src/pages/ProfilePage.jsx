import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { Card, CardBody, CardHeader } from '../components/Card';
import { Button } from '../components/Button';
import { Field } from '../components/Field';
import { Input } from '../components/Input';
import { useToast } from '../components/Toast';
import { endpoints } from '../api/endpoints';

export function ProfilePage() {
  const qc = useQueryClient();
  const toast = useToast();
  const [tab, setTab] = useState('profile');
  const { data: me } = useQuery({ queryKey: ['me'], queryFn: () => endpoints.auth.me() });
  const { data: sessions } = useQuery({ queryKey: ['sessions'], queryFn: () => endpoints.auth.sessions(), enabled: tab === 'security' });

  const update = useMutation({
    mutationFn: (body) => endpoints.auth.updateProfile(body),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['me'] }); toast.success('Saved'); },
  });
  const changePw = useMutation({
    mutationFn: (body) => endpoints.auth.changePassword(body),
    onSuccess: () => toast.success('Password updated'),
    onError: (e) => toast.error(e.message),
  });

  const profile = useForm({ defaultValues: me });
  const pw = useForm();

  return (
    <>
      <h1 className="text-2xl font-semibold mb-4">My profile</h1>
      <div className="bg-white border border-slate-200 rounded-lg p-1 inline-flex mb-4">
        {['profile', 'security'].map((t) => (
          <button key={t} onClick={() => setTab(t)} className={'px-3 py-1.5 text-sm rounded ' + (tab === t ? 'bg-amber-100 text-amber-900' : 'text-slate-600')}>
            {t}
          </button>
        ))}
      </div>

      {tab === 'profile' && (
        <Card><CardHeader title="Personal" actions={<Button onClick={profile.handleSubmit((d) => update.mutate(d))} loading={update.isPending}>Save</Button>} />
          <CardBody>
            <form className="space-y-3 max-w-md">
              <Field label="Name"><Input defaultValue={me?.name} {...profile.register('name')} /></Field>
              <Field label="Phone"><Input defaultValue={me?.phone} {...profile.register('phone')} /></Field>
            </form>
          </CardBody>
        </Card>
      )}

      {tab === 'security' && (
        <>
          <Card className="mb-3">
            <CardHeader title="Change password" />
            <CardBody>
              <form className="space-y-3 max-w-md" onSubmit={pw.handleSubmit((d) => changePw.mutate(d))}>
                <Field label="Current"><Input type="password" {...pw.register('current_password', { required: true })} /></Field>
                <Field label="New"><Input type="password" {...pw.register('new_password', { required: true, minLength: 10 })} /></Field>
                <Button type="submit" loading={changePw.isPending}>Update</Button>
              </form>
            </CardBody>
          </Card>
          <Card>
            <CardHeader title="Active sessions" />
            <CardBody>
              <ul className="text-sm divide-y divide-slate-100">
                {(sessions || []).map((s) => (
                  <li key={s.id} className="py-2 flex justify-between">
                    <span>{s.user_agent || 'unknown'} · {s.ip || '—'}</span>
                    <span className="text-slate-500">{new Date(s.created_at).toLocaleDateString()}</span>
                  </li>
                ))}
              </ul>
            </CardBody>
          </Card>
        </>
      )}
    </>
  );
}
