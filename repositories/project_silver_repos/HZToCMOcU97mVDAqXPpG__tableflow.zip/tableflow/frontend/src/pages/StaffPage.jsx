import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { Card, CardBody, CardHeader } from '../components/Card';
import { Button } from '../components/Button';
import { DataTable } from '../components/DataTable';
import { Modal } from '../components/Modal';
import { Field } from '../components/Field';
import { Input } from '../components/Input';
import { useToast } from '../components/Toast';
import { endpoints } from '../api/endpoints';

export function StaffPage() {
  const toast = useToast();
  const [invite, setInvite] = useState(false);
  const { data, isLoading } = useQuery({ queryKey: ['staff'], queryFn: () => endpoints.staff.list() });
  const inviteMut = useMutation({
    mutationFn: (body) => endpoints.restaurants.invitations(body),
    onSuccess: () => { setInvite(false); toast.success('Invitation sent'); },
    onError: (e) => toast.error(e.message),
  });
  const { register, handleSubmit, reset } = useForm();

  return (
    <>
      <div className="flex items-end justify-between mb-4">
        <h1 className="text-2xl font-semibold">Staff</h1>
        <Button onClick={() => { reset(); setInvite(true); }}>Invite member</Button>
      </div>
      <Card>
        <CardBody className="!p-0">
          <DataTable
            loading={isLoading}
            rows={data?.rows || data || []}
            columns={[
              { key: 'employee_code', header: 'Code' },
              { key: 'title', header: 'Title' },
              { key: 'pay_type', header: 'Pay' },
              { key: 'rate', header: 'Rate', render: (s) => s.pay_type === 'hourly' ? `$${(s.hourly_rate_cents/100).toFixed(2)}/hr` : `$${(s.salary_cents/100).toFixed(0)}` },
              { key: 'hired', header: 'Hired', render: (s) => s.hired_on || '—' },
            ]}
          />
        </CardBody>
      </Card>

      <Modal open={invite} onClose={() => setInvite(false)} title="Invite team member"
        footer={<><Button variant="secondary" onClick={() => setInvite(false)}>Cancel</Button><Button onClick={handleSubmit((d) => inviteMut.mutate(d))} loading={inviteMut.isPending}>Send</Button></>}>
        <form className="space-y-3">
          <Field label="Email" required><Input type="email" {...register('email', { required: true })} /></Field>
          <Field label="Role ID" required><Input {...register('role', { required: true })} /></Field>
        </form>
      </Modal>
    </>
  );
}
