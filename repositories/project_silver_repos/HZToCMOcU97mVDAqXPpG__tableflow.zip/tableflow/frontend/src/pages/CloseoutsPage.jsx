import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { Card, CardBody } from '../components/Card';
import { DataTable } from '../components/DataTable';
import { Button } from '../components/Button';
import { Modal } from '../components/Modal';
import { Field } from '../components/Field';
import { Input } from '../components/Input';
import { useToast } from '../components/Toast';
import { endpoints } from '../api/endpoints';

export function CloseoutsPage() {
  const qc = useQueryClient();
  const toast = useToast();
  const [open, setOpen] = useState(false);
  const { data, isLoading } = useQuery({ queryKey: ['closeouts'], queryFn: () => endpoints.payments.closeouts() });
  const create = useMutation({
    mutationFn: (body) => endpoints.payments.createCloseout(body),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['closeouts'] }); toast.success('Closed'); setOpen(false); },
    onError: (e) => toast.error(e.message),
  });
  const { register, handleSubmit, reset } = useForm();

  return (
    <>
      <div className="flex items-end justify-between mb-4">
        <h1 className="text-2xl font-semibold">Daily closeouts</h1>
        <Button onClick={() => { reset({ date: new Date().toISOString().slice(0, 10) }); setOpen(true); }}>Close today</Button>
      </div>
      <Card>
        <CardBody className="!p-0">
          <DataTable
            loading={isLoading}
            rows={data?.rows || data || []}
            columns={[
              { key: 'date', header: 'Date' },
              { key: 'expected', header: 'Expected', render: (c) => `$${(c.expected_cents / 100).toFixed(2)}` },
              { key: 'counted', header: 'Counted', render: (c) => `$${(c.counted_cents / 100).toFixed(2)}` },
              { key: 'diff', header: 'Diff', render: (c) => <span className={c.diff_cents === 0 ? '' : c.diff_cents > 0 ? 'text-green-700' : 'text-red-700'}>${(c.diff_cents / 100).toFixed(2)}</span> },
            ]}
          />
        </CardBody>
      </Card>

      <Modal open={open} onClose={() => setOpen(false)} title="Close day"
        footer={<><Button variant="secondary" onClick={() => setOpen(false)}>Cancel</Button><Button onClick={handleSubmit((d) => create.mutate(d))} loading={create.isPending}>Save</Button></>}>
        <form className="space-y-3">
          <Field label="Branch ID" required><Input {...register('branch', { required: true })} /></Field>
          <Field label="Date" required><Input type="date" {...register('date', { required: true })} /></Field>
          <Field label="Counted (cents)" required><Input type="number" min={0} {...register('counted_cents', { required: true, valueAsNumber: true })} /></Field>
          <Field label="Notes"><Input {...register('notes')} /></Field>
        </form>
      </Modal>
    </>
  );
}
