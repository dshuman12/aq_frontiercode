import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardBody } from '../components/Card';
import { DataTable } from '../components/DataTable';
import { Button } from '../components/Button';
import { StatusPill } from '../components/StatusPill';
import { useToast } from '../components/Toast';
import { endpoints } from '../api/endpoints';

const NEXT = {
  pending: 'assigned',
  assigned: 'picked_up',
  picked_up: 'delivering',
  delivering: 'delivered',
};

export function DeliveryPage() {
  const qc = useQueryClient();
  const toast = useToast();
  const { data, isLoading } = useQuery({ queryKey: ['delivery'], queryFn: () => endpoints.delivery.list() });
  const transition = useMutation({
    mutationFn: ({ id, to }) => endpoints.delivery.transition(id, { to }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['delivery'] }); toast.success('Updated'); },
    onError: (e) => toast.error(e.message),
  });

  return (
    <>
      <h1 className="text-2xl font-semibold mb-4">Delivery</h1>
      <Card>
        <CardBody className="!p-0">
          <DataTable
            loading={isLoading}
            rows={data?.rows || data || []}
            columns={[
              { key: 'address', header: 'Address', render: (d) => d.address_text || '—' },
              { key: 'customer', header: 'Customer', render: (d) => d.customer_name || '—' },
              { key: 'eta', header: 'ETA', render: (d) => `${d.eta_minutes} min` },
              { key: 'fee', header: 'Fee', render: (d) => `$${(d.fee_cents / 100).toFixed(2)}` },
              { key: 'status', header: 'Status', render: (d) => <StatusPill kind="delivery" value={d.status} /> },
              {
                key: 'next',
                header: '',
                render: (d) => NEXT[d.status] ? (
                  <Button variant="secondary" onClick={(e) => { e.stopPropagation(); transition.mutate({ id: d.id, to: NEXT[d.status] }); }}>
                    → {NEXT[d.status].replace('_', ' ')}
                  </Button>
                ) : null,
              },
            ]}
          />
        </CardBody>
      </Card>
    </>
  );
}
