import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { Card, CardBody, CardHeader } from '../components/Card';
import { Button } from '../components/Button';
import { Drawer } from '../components/Drawer';
import { Field } from '../components/Field';
import { Input } from '../components/Input';
import { Badge } from '../components/Badge';
import { useToast } from '../components/Toast';
import { endpoints } from '../api/endpoints';

export function ModifiersPage() {
  const qc = useQueryClient();
  const toast = useToast();
  const [drawer, setDrawer] = useState(null);
  const { data: groups } = useQuery({ queryKey: ['mod-groups'], queryFn: () => endpoints.modifiers.groups() });

  const create = useMutation({
    mutationFn: (body) => endpoints.modifiers.createGroup(body),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['mod-groups'] });
      toast.success('Created');
      setDrawer(null);
    },
  });
  const { register, handleSubmit, reset } = useForm({ defaultValues: { min_select: 0, max_select: 1 } });

  return (
    <>
      <div className="flex items-end justify-between mb-4">
        <h1 className="text-2xl font-semibold">Modifiers</h1>
        <Button onClick={() => { reset(); setDrawer({ kind: 'group' }); }}>New group</Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
        {(groups?.rows || groups || []).map((g) => (
          <Card key={g.id}>
            <CardHeader title={g.name} actions={
              <div className="flex gap-2">
                {g.is_required && <Badge tone="brand">required</Badge>}
                <Badge>{g.min_select}–{g.max_select}</Badge>
              </div>
            } />
            <CardBody>
              <ul className="text-sm divide-y divide-slate-100">
                {(g.options || []).map((o) => (
                  <li key={o.id} className="py-1.5 flex justify-between">
                    <span>{o.name}</span>
                    <span className="text-slate-500">+${(o.price_delta_cents / 100).toFixed(2)}</span>
                  </li>
                ))}
              </ul>
            </CardBody>
          </Card>
        ))}
      </div>

      <Drawer open={!!drawer} onClose={() => setDrawer(null)} title="New modifier group">
        <form onSubmit={handleSubmit((d) => create.mutate(d))} className="space-y-3">
          <Field label="Name" required><Input {...register('name', { required: true })} /></Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Min select"><Input type="number" min={0} {...register('min_select', { valueAsNumber: true })} /></Field>
            <Field label="Max select"><Input type="number" min={1} {...register('max_select', { valueAsNumber: true })} /></Field>
          </div>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" {...register('is_required')} /> Required
          </label>
          <div className="flex justify-end"><Button type="submit" loading={create.isPending}>Create</Button></div>
        </form>
      </Drawer>
    </>
  );
}
