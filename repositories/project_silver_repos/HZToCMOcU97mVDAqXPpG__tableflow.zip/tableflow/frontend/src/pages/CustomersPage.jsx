import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardBody } from '../components/Card';
import { DataTable } from '../components/DataTable';
import { Button } from '../components/Button';
import { Input } from '../components/Input';
import { useDebounced } from '../hooks/useDebounced';
import { endpoints } from '../api/endpoints';

export function CustomersPage() {
  const [q, setQ] = useState('');
  const dq = useDebounced(q);
  const { data, isLoading } = useQuery({
    queryKey: ['customers', dq],
    queryFn: () => endpoints.customers.list({ search: dq || undefined }),
    keepPreviousData: true,
  });
  const rows = data?.rows || [];

  return (
    <>
      <div className="flex items-end justify-between mb-4">
        <h1 className="text-2xl font-semibold">Customers</h1>
        <Button>Add customer</Button>
      </div>
      <Input placeholder="Search by name, email, phone" value={q} onChange={(e) => setQ(e.target.value)} className="w-80 mb-3" />
      <Card>
        <CardBody className="!p-0">
          <DataTable
            loading={isLoading}
            rows={rows}
            columns={[
              { key: 'name', header: 'Name', render: (c) => `${c.first_name} ${c.last_name || ''}` },
              { key: 'email', header: 'Email' },
              { key: 'phone', header: 'Phone' },
              { key: 'last_seen_at', header: 'Last seen', render: (c) => (c.last_seen_at ? new Date(c.last_seen_at).toLocaleDateString() : '—') },
              { key: 'tags', header: 'Tags', render: (c) => (c.tags || []).map((t) => t.name || t).join(', ') || '—' },
            ]}
          />
        </CardBody>
      </Card>
    </>
  );
}
