import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Card, CardBody } from '../components/Card';
import { Button } from '../components/Button';
import { DataTable } from '../components/DataTable';
import { StatusPill } from '../components/StatusPill';
import { Input } from '../components/Input';
import { useDebounced } from '../hooks/useDebounced';
import { endpoints } from '../api/endpoints';

const TABS = [
  { value: 'all', label: 'All' },
  { value: 'open', label: 'Open' },
  { value: 'today', label: 'Today' },
];

export function OrdersPage() {
  const navigate = useNavigate();
  const [tab, setTab] = useState('all');
  const [q, setQ] = useState('');
  const dq = useDebounced(q);

  const { data, isLoading } = useQuery({
    queryKey: ['orders', tab, dq],
    queryFn: () => endpoints.orders.list({ search: dq || undefined }),
    keepPreviousData: true,
  });

  const rows = data?.rows || [];
  const filtered = tab === 'all'
    ? rows
    : tab === 'open'
      ? rows.filter((o) => !['completed', 'cancelled', 'refunded'].includes(o.status))
      : rows.filter((o) => new Date(o.created_at).toDateString() === new Date().toDateString());

  return (
    <>
      <div className="flex items-end justify-between mb-4">
        <h1 className="text-2xl font-semibold">Orders</h1>
        <Button onClick={() => navigate('/orders/new')}>New order</Button>
      </div>

      <div className="flex items-center gap-2 mb-3">
        <div className="bg-white border border-slate-200 rounded-lg p-1 inline-flex">
          {TABS.map((t) => (
            <button
              key={t.value}
              onClick={() => setTab(t.value)}
              className={'px-3 py-1.5 text-sm rounded ' + (tab === t.value ? 'bg-amber-100 text-amber-900' : 'text-slate-600')}
            >
              {t.label}
            </button>
          ))}
        </div>
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search order #" className="w-64 ml-auto" />
      </div>

      <Card>
        <CardBody className="!p-0">
          <DataTable
            loading={isLoading}
            rows={filtered}
            onRowClick={(o) => navigate(`/orders/${o.id}`)}
            columns={[
              { key: 'number', header: '#', render: (o) => <span className="font-mono">{o.number}</span> },
              { key: 'kind', header: 'Type' },
              { key: 'when', header: 'When', render: (o) => new Date(o.created_at).toLocaleString() },
              { key: 'total', header: 'Total', render: (o) => `$${(o.total_cents / 100).toFixed(2)}` },
              { key: 'paid', header: 'Paid', render: (o) => `$${(o.paid_cents / 100).toFixed(2)}` },
              { key: 'status', header: 'Status', render: (o) => <StatusPill value={o.status} /> },
            ]}
          />
        </CardBody>
      </Card>
    </>
  );
}
