import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardBody, CardHeader } from '../components/Card';
import { Button } from '../components/Button';
import { StatusPill } from '../components/StatusPill';
import { useToast } from '../components/Toast';
import { endpoints } from '../api/endpoints';

export function POSPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const toast = useToast();
  const [activeCat, setActiveCat] = useState(null);

  const { data: order } = useQuery({
    queryKey: ['order', id],
    queryFn: () => endpoints.orders.detail(id),
    enabled: !!id,
  });
  const { data: items } = useQuery({ queryKey: ['menu-items'], queryFn: () => endpoints.menus.items({ is_available: true }) });
  const { data: cats } = useQuery({ queryKey: ['menu-cats'], queryFn: () => endpoints.menus.categories() });

  const create = useMutation({
    mutationFn: (body) => endpoints.orders.create(body),
    onSuccess: (o) => navigate(`/orders/${o.id}`),
  });
  const addItem = useMutation({
    mutationFn: ({ orderId, body }) => endpoints.orders.addItem(orderId, body),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['order', id] }),
  });
  const transition = useMutation({
    mutationFn: ({ orderId, to }) => endpoints.orders.transition(orderId, { to_status: to }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['order', id] });
      toast.success('Status updated');
    },
  });

  if (!id) {
    return (
      <div className="p-8 text-center">
        <h1 className="text-xl font-semibold mb-2">Start a new order</h1>
        <Button onClick={() => create.mutate({ kind: 'dine_in', branch: '' })}>Create draft</Button>
      </div>
    );
  }
  if (!order) return <div className="text-slate-500">Loading order…</div>;

  const itemRows = (items?.rows || items || []).filter((mi) => !activeCat || mi.category === activeCat);
  const categories = cats?.rows || cats || [];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[1fr_24rem] gap-4">
      <div>
        <h1 className="text-xl font-semibold mb-2">Order {order.number}</h1>
        <div className="flex flex-wrap gap-2 mb-3">
          {categories.map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => setActiveCat(activeCat === c.id ? null : c.id)}
              className={'px-3 py-1.5 rounded-lg border ' + (activeCat === c.id ? 'bg-amber-100 border-amber-300' : 'border-slate-200 bg-white')}
            >
              {c.name}
            </button>
          ))}
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
          {itemRows.slice(0, 60).map((mi) => (
            <button
              key={mi.id}
              type="button"
              onClick={() => addItem.mutate({ orderId: id, body: { menu_item: mi.id, quantity: 1 } })}
              className="card p-3 text-left hover:shadow"
            >
              <div className="font-semibold text-sm">{mi.name}</div>
              <div className="text-xs text-slate-500 mt-1">${(mi.base_price_cents / 100).toFixed(2)}</div>
            </button>
          ))}
        </div>
      </div>

      <Card>
        <CardHeader title="Cart" actions={<StatusPill value={order.status} />} />
        <CardBody>
          {order.items.length === 0 ? (
            <p className="text-sm text-slate-500">Pick items from the menu.</p>
          ) : (
            <ul className="divide-y divide-slate-100 text-sm">
              {order.items.map((it) => (
                <li key={it.id} className="py-2 flex justify-between">
                  <span>{it.quantity}× {it.name_snapshot}</span>
                  <span>${(it.line_total_cents / 100).toFixed(2)}</span>
                </li>
              ))}
            </ul>
          )}
          <div className="mt-3 pt-3 border-t border-slate-100 space-y-1 text-sm">
            <div className="flex justify-between"><span>Subtotal</span><span>${(order.subtotal_cents / 100).toFixed(2)}</span></div>
            <div className="flex justify-between"><span>Tax</span><span>${(order.tax_cents / 100).toFixed(2)}</span></div>
            <div className="flex justify-between font-semibold"><span>Total</span><span>${(order.total_cents / 100).toFixed(2)}</span></div>
            <div className="flex justify-between text-green-700"><span>Paid</span><span>${(order.paid_cents / 100).toFixed(2)}</span></div>
          </div>
          <div className="mt-3 flex flex-wrap gap-2">
            {order.status === 'draft' && <Button onClick={() => transition.mutate({ orderId: id, to: 'placed' })}>Place</Button>}
            {order.status === 'placed' && <Button onClick={() => transition.mutate({ orderId: id, to: 'accepted' })}>Accept</Button>}
            {order.status === 'accepted' && <Button onClick={() => transition.mutate({ orderId: id, to: 'preparing' })}>Start prep</Button>}
            {order.status === 'preparing' && <Button onClick={() => transition.mutate({ orderId: id, to: 'ready' })}>Mark ready</Button>}
            {order.status === 'ready' && order.kind === 'dine_in' && <Button onClick={() => transition.mutate({ orderId: id, to: 'served' })}>Served</Button>}
            {order.status === 'served' && <Button onClick={() => transition.mutate({ orderId: id, to: 'completed' })}>Complete</Button>}
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
