import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { Card, CardBody, CardHeader } from '../components/Card';
import { Button } from '../components/Button';
import { Drawer } from '../components/Drawer';
import { Field } from '../components/Field';
import { Input } from '../components/Input';
import { DataTable } from '../components/DataTable';
import { Badge } from '../components/Badge';
import { useToast } from '../components/Toast';
import { endpoints } from '../api/endpoints';

export function MenuPage() {
  const qc = useQueryClient();
  const toast = useToast();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);

  const { data: items, isLoading } = useQuery({ queryKey: ['menu-items'], queryFn: () => endpoints.menus.items() });
  const { data: cats } = useQuery({ queryKey: ['menu-cats'], queryFn: () => endpoints.menus.categories() });

  const save = useMutation({
    mutationFn: (body) => (editing ? endpoints.menus.updateItem(editing.id, body) : endpoints.menus.createItem(body)),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['menu-items'] });
      toast.success(editing ? 'Updated' : 'Created');
      setOpen(false);
    },
    onError: (e) => toast.error(e.message),
  });

  const { register, handleSubmit, reset } = useForm();
  const beginEdit = (it) => {
    setEditing(it);
    reset(it || {});
    setOpen(true);
  };

  const rows = items?.rows || items || [];
  const cs = cats?.rows || cats || [];

  return (
    <>
      <div className="flex items-end justify-between mb-4">
        <h1 className="text-2xl font-semibold">Menu</h1>
        <Button onClick={() => beginEdit(null)}>New item</Button>
      </div>
      <Card>
        <CardBody className="!p-0">
          <DataTable
            loading={isLoading}
            rows={rows}
            onRowClick={beginEdit}
            columns={[
              { key: 'name', header: 'Name' },
              { key: 'category', header: 'Category', render: (i) => cs.find((c) => c.id === i.category)?.name || '—' },
              { key: 'price', header: 'Price', render: (i) => `$${(i.base_price_cents / 100).toFixed(2)}` },
              { key: 'avail', header: 'Available', render: (i) => <Badge tone={i.is_available ? 'success' : 'neutral'}>{i.is_available ? 'yes' : 'no'}</Badge> },
              { key: 'allergens', header: 'Allergens', render: (i) => (i.allergens || []).join(', ') || '—' },
            ]}
          />
        </CardBody>
      </Card>

      <Drawer open={open} onClose={() => setOpen(false)} title={editing ? 'Edit item' : 'New item'}>
        <form onSubmit={handleSubmit((d) => save.mutate(d))} className="space-y-3">
          <Field label="Name" required><Input {...register('name', { required: true })} /></Field>
          <Field label="Description"><Input {...register('description')} /></Field>
          <Field label="Category ID" required><Input {...register('category', { required: true })} /></Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Base price (cents)"><Input type="number" {...register('base_price_cents', { valueAsNumber: true })} /></Field>
            <Field label="Cost (cents)"><Input type="number" {...register('cost_cents', { valueAsNumber: true })} /></Field>
          </div>
          <Field label="Prep time (minutes)"><Input type="number" {...register('prep_time_minutes', { valueAsNumber: true })} /></Field>
          <div className="flex justify-end"><Button type="submit" loading={save.isPending}>Save</Button></div>
        </form>
      </Drawer>
    </>
  );
}
