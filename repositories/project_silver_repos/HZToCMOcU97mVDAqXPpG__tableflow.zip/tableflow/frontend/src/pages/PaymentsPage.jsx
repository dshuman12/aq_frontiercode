import { useQuery } from '@tanstack/react-query';
import { Card, CardBody } from '../components/Card';
import { DataTable } from '../components/DataTable';
import { StatusPill } from '../components/StatusPill';
import { endpoints } from '../api/endpoints';

export function PaymentsPage() {
  const { data, isLoading } = useQuery({ queryKey: ['payments'], queryFn: () => endpoints.payments.list() });
  return (
    <>
      <h1 className="text-2xl font-semibold mb-4">Payments</h1>
      <Card>
        <CardBody className="!p-0">
          <DataTable
            loading={isLoading}
            rows={data?.rows || data || []}
            columns={[
              { key: 'when', header: 'When', render: (p) => new Date(p.created_at).toLocaleString() },
              { key: 'order', header: 'Order', render: (p) => p.order },
              { key: 'amount', header: 'Amount', render: (p) => `$${(p.amount_cents / 100).toFixed(2)}` },
              { key: 'tip', header: 'Tip', render: (p) => `$${(p.tip_cents / 100).toFixed(2)}` },
              { key: 'method', header: 'Method' },
              { key: 'status', header: 'Status', render: (p) => <StatusPill kind="payment" value={p.status} /> },
            ]}
          />
        </CardBody>
      </Card>
    </>
  );
}
