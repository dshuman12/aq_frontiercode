import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardBody } from '../components/Card';
import { DataTable } from '../components/DataTable';
import { Button } from '../components/Button';
import { Badge } from '../components/Badge';
import { Modal } from '../components/Modal';
import { Field } from '../components/Field';
import { Input } from '../components/Input';
import { useToast } from '../components/Toast';
import { endpoints } from '../api/endpoints';

export function InventoryPage() {
  const qc = useQueryClient();
  const toast = useToast();
  const [adjustFor, setAdjustFor] = useState(null);
  const [newOnHand, setNewOnHand] = useState('');
  const { data, isLoading } = useQuery({ queryKey: ['inventory'], queryFn: () => endpoints.inventory.list() });

  const adjust = useMutation({
    mutationFn: ({ id, body }) => endpoints.inventory.adjust(id, body),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['inventory'] }); toast.success('Adjusted'); setAdjustFor(null); },
    onError: (e) => toast.error(e.message),
  });

  const rows = data?.rows || data || [];

  return (
    <>
      <div className="flex items-end justify-between mb-4">
        <h1 className="text-2xl font-semibold">Inventory</h1>
        <Button>New ingredient</Button>
      </div>
      <Card>
        <CardBody className="!p-0">
          <DataTable
            loading={isLoading}
            rows={rows}
            onRowClick={(i) => { setAdjustFor(i); setNewOnHand(String(i.on_hand_qty)); }}
            columns={[
              { key: 'name', header: 'Name' },
              { key: 'unit', header: 'Unit' },
              { key: 'on_hand', header: 'On hand', render: (i) => `${i.on_hand_qty} ${i.unit}` },
              { key: 'par', header: 'Par', render: (i) => `${i.par_qty} ${i.unit}` },
              { key: 'low', header: '', render: (i) => i.is_low_stock ? <Badge tone="danger">low</Badge> : null },
              { key: 'cost', header: 'Unit cost', render: (i) => `$${(i.cost_per_unit_cents / 100).toFixed(2)}` },
            ]}
          />
        </CardBody>
      </Card>

      <Modal open={!!adjustFor} onClose={() => setAdjustFor(null)} title="Adjust on-hand"
        footer={
          <>
            <Button variant="secondary" onClick={() => setAdjustFor(null)}>Cancel</Button>
            <Button onClick={() => adjust.mutate({ id: adjustFor.id, body: { new_on_hand: newOnHand } })} loading={adjust.isPending}>Save</Button>
          </>
        }>
        {adjustFor && (
          <Field label={`${adjustFor.name} (${adjustFor.unit})`}>
            <Input value={newOnHand} onChange={(e) => setNewOnHand(e.target.value)} />
          </Field>
        )}
      </Modal>
    </>
  );
}
