import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardBody } from '../components/Card';
import { DataTable } from '../components/DataTable';
import { Button } from '../components/Button';
import { StatusPill } from '../components/StatusPill';
import { Badge } from '../components/Badge';
import { useToast } from '../components/Toast';
import { endpoints } from '../api/endpoints';

const TONES = {
  draft: 'neutral', submitted: 'info', partial: 'warn', received: 'success', cancelled: 'danger',
};

export function PurchasingPage() {
  const qc = useQueryClient();
  const toast = useToast();
  const { data, isLoading } = useQuery({ queryKey: ['purchasing'], queryFn: () => endpoints.purchasing.list() });
  const submit = useMutation({
    mutationFn: (id) => endpoints.purchasing.submit(id),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['purchasing'] }); toast.success('Submitted'); },
    onError: (e) => toast.error(e.message),
  });

  return (
    <>
      <div className="flex items-end justify-between mb-4">
        <h1 className="text-2xl font-semibold">Purchasing</h1>
        <Button>New purchase order</Button>
      </div>
      <Card>
        <CardBody className="!p-0">
          <DataTable
            loading={isLoading}
            rows={data?.rows || data || []}
            columns={[
              { key: 'number', header: '#', render: (p) => <code className="font-mono">{p.number}</code> },
              { key: 'supplier', header: 'Supplier' },
              { key: 'expected', header: 'Expected', render: (p) => p.expected_on || '—' },
              { key: 'total', header: 'Total', render: (p) => `$${(p.total_cents / 100).toFixed(2)}` },
              { key: 'status', header: 'Status', render: (p) => <Badge tone={TONES[p.status] || 'neutral'}>{p.status}</Badge> },
              {
                key: 'actions',
                header: '',
                render: (p) => p.status === 'draft' ? (
                  <Button variant="secondary" onClick={(e) => { e.stopPropagation(); submit.mutate(p.id); }}>Submit</Button>
                ) : null,
              },
            ]}
          />
        </CardBody>
      </Card>
    </>
  );
}
