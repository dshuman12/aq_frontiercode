import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { Card, CardBody } from '../components/Card';
import { Button } from '../components/Button';
import { Drawer } from '../components/Drawer';
import { Field } from '../components/Field';
import { Input } from '../components/Input';
import { DataTable } from '../components/DataTable';
import { Badge } from '../components/Badge';
import { useToast } from '../components/Toast';
import { endpoints } from '../api/endpoints';

export function CouponsPage() {
  const qc = useQueryClient();
  const toast = useToast();
  const [open, setOpen] = useState(false);
  const { data, isLoading } = useQuery({ queryKey: ['coupons'], queryFn: () => endpoints.coupons.list() });
  const create = useMutation({
    mutationFn: (body) => endpoints.coupons.create(body),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['coupons'] }); setOpen(false); toast.success('Created'); },
    onError: (e) => toast.error(e.message),
  });
  const { register, handleSubmit, reset } = useForm({ defaultValues: { kind: 'percent' } });

  return (
    <>
      <div className="flex items-end justify-between mb-4">
        <h1 className="text-2xl font-semibold">Coupons</h1>
        <Button onClick={() => { reset({ kind: 'percent' }); setOpen(true); }}>New coupon</Button>
      </div>
      <Card>
        <CardBody className="!p-0">
          <DataTable
            loading={isLoading}
            rows={data?.rows || data || []}
            columns={[
              { key: 'code', header: 'Code', render: (c) => <code className="font-mono">{c.code}</code> },
              { key: 'name', header: 'Name' },
              { key: 'kind', header: 'Type' },
              { key: 'discount', header: 'Discount', render: (c) => c.kind === 'percent' ? `${c.percent_off}%` : c.kind === 'amount' ? `$${(c.amount_off_cents/100).toFixed(2)}` : '—' },
              { key: 'used', header: 'Used', render: (c) => `${c.times_used}/${c.max_uses || '∞'}` },
              { key: 'active', header: 'Active', render: (c) => <Badge tone={c.is_active ? 'success' : 'neutral'}>{c.is_active ? 'yes' : 'no'}</Badge> },
            ]}
          />
        </CardBody>
      </Card>
      <Drawer open={open} onClose={() => setOpen(false)} title="New coupon">
        <form onSubmit={handleSubmit((d) => create.mutate(d))} className="space-y-3">
          <Field label="Code" required><Input {...register('code', { required: true })} /></Field>
          <Field label="Name" required><Input {...register('name', { required: true })} /></Field>
          <Field label="Type">
            <select className="input" {...register('kind')}>
              <option value="percent">Percent off</option>
              <option value="amount">Amount off</option>
              <option value="bogo">Buy-one-get-one</option>
              <option value="free_delivery">Free delivery</option>
            </select>
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Percent off"><Input type="number" step="0.01" {...register('percent_off', { valueAsNumber: true })} /></Field>
            <Field label="Amount off (cents)"><Input type="number" {...register('amount_off_cents', { valueAsNumber: true })} /></Field>
          </div>
          <Field label="Min order (cents)"><Input type="number" {...register('min_order_cents', { valueAsNumber: true })} /></Field>
          <Field label="Max uses (0 = ∞)"><Input type="number" {...register('max_uses', { valueAsNumber: true })} /></Field>
          <div className="flex justify-end"><Button type="submit" loading={create.isPending}>Create</Button></div>
        </form>
      </Drawer>
    </>
  );
}
