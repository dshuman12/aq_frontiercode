import { useQuery } from '@tanstack/react-query';
import { Card, CardBody, CardHeader } from '../components/Card';
import { Badge } from '../components/Badge';
import { endpoints } from '../api/endpoints';

function StatTile({ label, value, hint, tone = 'brand' }) {
  return (
    <div className="card p-4">
      <div className="text-sm text-slate-500">{label}</div>
      <div className="mt-2 text-2xl font-semibold">{value}</div>
      {hint && <div className="text-xs text-slate-500 mt-1">{hint}</div>}
    </div>
  );
}

export function DashboardPage() {
  const { data: dash } = useQuery({ queryKey: ['report-dashboard'], queryFn: () => endpoints.reports.dashboard() });
  const { data: kitchen } = useQuery({ queryKey: ['kitchen-active'], queryFn: () => endpoints.kitchen.tickets({ active: 1 }) });
  const { data: lowStock } = useQuery({ queryKey: ['inv-low'], queryFn: () => endpoints.inventory.lowStock() });

  const ordersToday = dash?.orders_today ?? 0;
  const revenue = ((dash?.revenue_30d_cents ?? 0) / 100).toFixed(2);
  const ticketCount = (kitchen?.rows ?? kitchen ?? []).length || 0;
  const lowCount = (lowStock || []).length;

  return (
    <>
      <div className="flex items-end justify-between mb-6">
        <div>
          <h1 className="text-2xl font-semibold">Today at a glance</h1>
          <p className="text-slate-500 text-sm">{new Date().toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })}</p>
        </div>
        <Badge tone="brand">Live</Badge>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
        <StatTile label="Orders today" value={ordersToday} />
        <StatTile label="Revenue (30d)" value={`$${revenue}`} />
        <StatTile label="Active kitchen tickets" value={ticketCount} hint="queued + in progress" />
        <StatTile label="Low-stock ingredients" value={lowCount} hint="below par" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2">
          <CardHeader title="Active kitchen tickets" />
          <CardBody>
            {ticketCount === 0 ? (
              <p className="text-sm text-slate-500">No active tickets right now.</p>
            ) : (
              <ul className="divide-y divide-slate-100">
                {(kitchen?.rows || kitchen || []).slice(0, 8).map((t) => (
                  <li key={t.id} className="py-2 flex items-center justify-between">
                    <div>
                      <span className="font-medium">{t.order_number}</span>
                      <span className="text-slate-500 text-sm ml-2">→ {t.station}</span>
                    </div>
                    <Badge tone={t.status === 'ready' ? 'success' : 'warn'}>{t.status}</Badge>
                  </li>
                ))}
              </ul>
            )}
          </CardBody>
        </Card>
        <Card>
          <CardHeader title="Low stock" />
          <CardBody>
            {lowCount === 0 ? (
              <p className="text-sm text-slate-500">All ingredients above par.</p>
            ) : (
              <ul className="divide-y divide-slate-100">
                {(lowStock || []).slice(0, 8).map((i) => (
                  <li key={i.id} className="py-2 flex justify-between text-sm">
                    <span>{i.name}</span>
                    <span className="text-slate-500">{i.on_hand_qty} / {i.par_qty}</span>
                  </li>
                ))}
              </ul>
            )}
          </CardBody>
        </Card>
      </div>
    </>
  );
}
