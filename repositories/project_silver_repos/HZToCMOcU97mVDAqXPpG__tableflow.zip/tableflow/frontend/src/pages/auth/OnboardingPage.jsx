import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { Card, CardBody, CardHeader } from '../../components/Card';
import { Field } from '../../components/Field';
import { Input } from '../../components/Input';
import { Button } from '../../components/Button';
import { endpoints } from '../../api/endpoints';
import { useToast } from '../../components/Toast';

const STEPS = ['Restaurant', 'Branch & hours', 'Tax & payments', 'Review'];

export function OnboardingPage() {
  const navigate = useNavigate();
  const toast = useToast();
  const [step, setStep] = useState(0);
  const { register, handleSubmit, getValues } = useForm({
    defaultValues: { tax_rate: '0.0825', service_charge_rate: '0' },
  });

  const finish = async () => {
    const data = getValues();
    try {
      await endpoints.restaurants.create({ name: data.name, cuisine: data.cuisine, timezone: data.timezone || 'America/Chicago' });
      toast.success('Restaurant created');
      navigate('/');
    } catch (e) {
      toast.error(e.message || 'Setup failed');
    }
  };

  return (
    <div className="min-h-screen p-6 max-w-3xl mx-auto">
      <div className="flex items-center gap-2 mb-6">
        {STEPS.map((s, i) => (
          <div key={s} className="flex items-center gap-2">
            <span className={'w-7 h-7 rounded-full inline-flex items-center justify-center text-xs font-semibold ' + (i <= step ? 'bg-brand-600 text-white' : 'bg-slate-200 text-slate-500')}>
              {i + 1}
            </span>
            <span className="text-sm">{s}</span>
            {i < STEPS.length - 1 && <span className="w-6 border-t border-slate-300 mx-1" />}
          </div>
        ))}
      </div>
      <Card>
        <CardHeader title={STEPS[step]} subtitle="Set up your restaurant" />
        <CardBody>
          {step === 0 && (
            <form onSubmit={handleSubmit(() => setStep(1))} className="space-y-3">
              <Field label="Restaurant name" required>
                <Input {...register('name', { required: true })} />
              </Field>
              <Field label="Cuisine">
                <Input {...register('cuisine')} placeholder="Italian, Mexican, etc." />
              </Field>
              <Field label="Timezone">
                <Input {...register('timezone')} placeholder="America/Chicago" />
              </Field>
            </form>
          )}
          {step === 1 && (
            <form onSubmit={handleSubmit(() => setStep(2))} className="space-y-3">
              <Field label="Main branch address"><Input {...register('address')} /></Field>
              <Field label="Phone"><Input {...register('phone')} /></Field>
              <div className="grid grid-cols-2 gap-3">
                <Field label="Open"><Input type="time" {...register('open')} defaultValue="09:00" /></Field>
                <Field label="Close"><Input type="time" {...register('close')} defaultValue="22:00" /></Field>
              </div>
            </form>
          )}
          {step === 2 && (
            <form onSubmit={handleSubmit(() => setStep(3))} className="space-y-3">
              <Field label="Tax rate (decimal, e.g. 0.0825)"><Input {...register('tax_rate')} /></Field>
              <Field label="Service charge rate"><Input {...register('service_charge_rate')} /></Field>
              <Field label="Default tip options (CSV)"><Input {...register('tips')} placeholder="10,15,20" /></Field>
            </form>
          )}
          {step === 3 && <pre className="text-xs bg-slate-50 rounded-lg p-3 overflow-auto">{JSON.stringify(getValues(), null, 2)}</pre>}

          <div className="flex justify-between mt-6">
            <Button variant="secondary" onClick={() => setStep((s) => Math.max(0, s - 1))} disabled={step === 0}>
              Back
            </Button>
            {step < 3 ? (
              <Button onClick={() => setStep((s) => Math.min(3, s + 1))}>Next</Button>
            ) : (
              <Button onClick={finish}>Finish</Button>
            )}
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
