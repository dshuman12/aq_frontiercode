import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { Card, CardBody, CardHeader } from '../../components/Card';
import { Field } from '../../components/Field';
import { Input } from '../../components/Input';
import { Button } from '../../components/Button';
import { useToast } from '../../components/Toast';
import { useAuth } from '../../stores/auth';
import { endpoints } from '../../api/endpoints';

export function LoginPage() {
  const auth = useAuth();
  const navigate = useNavigate();
  const loc = useLocation();
  const toast = useToast();
  const { register, handleSubmit, formState: { errors } } = useForm();
  const [error, setError] = useState(null);
  const [needsTotp, setNeedsTotp] = useState(false);
  const [busy, setBusy] = useState(false);

  const onSubmit = async (data) => {
    setBusy(true);
    setError(null);
    try {
      const r = await endpoints.auth.login(data);
      auth.setAuth({ ...r, restaurant_id: null });
      toast.success(`Welcome, ${r.user?.name || r.user?.email}`);
      navigate(loc.state?.from || '/', { replace: true });
    } catch (e) {
      if (String(e.message).includes('totp-required')) {
        setNeedsTotp(true);
        return;
      }
      setError(e.message || 'Sign-in failed');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-slate-100">
      <div className="w-full max-w-md">
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-brand-600 text-white text-xl font-bold mb-2">T</div>
          <h1 className="text-2xl font-semibold">Sign in to TableFlow</h1>
          <p className="text-sm text-slate-500 mt-1">Operator console</p>
        </div>
        <Card>
          <CardHeader title="Email + password" />
          <CardBody>
            {error && <div className="rounded-lg bg-red-50 border border-red-200 text-red-800 px-3 py-2 text-sm mb-3">{error}</div>}
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-3">
              <Field label="Email" required error={errors.email?.message}>
                <Input type="email" {...register('email', { required: 'Required' })} />
              </Field>
              <Field label="Password" required error={errors.password?.message}>
                <Input type="password" {...register('password', { required: 'Required' })} />
              </Field>
              {needsTotp && (
                <Field label="2FA code" hint="Enter the 6-digit code from your authenticator">
                  <Input inputMode="numeric" maxLength={6} {...register('totp_code')} />
                </Field>
              )}
              <Button type="submit" loading={busy} className="w-full">Sign in</Button>
              <div className="text-sm flex justify-between">
                <Link to="/reset-password" className="text-brand-700 hover:underline">Forgot password?</Link>
                <a href="/customer" className="text-brand-700 hover:underline">Customer portal</a>
              </div>
            </form>
          </CardBody>
        </Card>
      </div>
    </div>
  );
}
