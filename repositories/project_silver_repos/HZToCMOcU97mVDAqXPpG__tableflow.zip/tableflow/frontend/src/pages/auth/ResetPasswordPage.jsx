import { useState } from 'react';
import { Link, useSearchParams, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { Card, CardBody, CardHeader } from '../../components/Card';
import { Field } from '../../components/Field';
import { Input } from '../../components/Input';
import { Button } from '../../components/Button';
import { useToast } from '../../components/Toast';
import { endpoints } from '../../api/endpoints';

export function ResetPasswordPage() {
  const [params] = useSearchParams();
  const token = params.get('token');
  const navigate = useNavigate();
  const toast = useToast();
  const { register, handleSubmit, watch } = useForm();
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(false);

  const onRequest = async ({ email }) => {
    setBusy(true);
    try {
      await endpoints.auth.requestReset({ email });
      setSent(true);
    } finally {
      setBusy(false);
    }
  };

  const onConfirm = async ({ password }) => {
    setBusy(true);
    try {
      await endpoints.auth.confirmReset({ token, password });
      toast.success('Password updated. Please sign in.');
      navigate('/login');
    } catch (e) {
      toast.error(e.message || 'Reset failed');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-slate-100">
      <div className="w-full max-w-md">
        <Card>
          <CardHeader title={token ? 'Choose a new password' : 'Forgot password'} />
          <CardBody>
            {token ? (
              <form onSubmit={handleSubmit(onConfirm)} className="space-y-3">
                <Field label="New password" required><Input type="password" {...register('password', { required: true, minLength: 10 })} /></Field>
                <Field label="Confirm password" required>
                  <Input type="password" {...register('confirm', { validate: (v) => v === watch('password') || 'Mismatch' })} />
                </Field>
                <Button type="submit" loading={busy} className="w-full">Set password</Button>
              </form>
            ) : sent ? (
              <p className="text-sm text-slate-600">If that address is on file, you'll receive a reset link shortly.</p>
            ) : (
              <form onSubmit={handleSubmit(onRequest)} className="space-y-3">
                <Field label="Email" required><Input type="email" {...register('email', { required: true })} /></Field>
                <Button type="submit" loading={busy} className="w-full">Send reset link</Button>
              </form>
            )}
            <div className="mt-3 text-sm"><Link to="/login" className="text-brand-700 hover:underline">Back to sign in</Link></div>
          </CardBody>
        </Card>
      </div>
    </div>
  );
}
