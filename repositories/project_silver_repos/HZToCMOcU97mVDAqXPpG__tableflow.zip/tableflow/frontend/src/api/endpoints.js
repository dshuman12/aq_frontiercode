import { api } from './client';

export const endpoints = {
  auth: {
    login: (body) => api.post('/api/auth/login', body).then((r) => r.data),
    register: (body) => api.post('/api/auth/register', body).then((r) => r.data),
    refresh: (body) => api.post('/api/auth/refresh', body).then((r) => r.data),
    logout: (body) => api.post('/api/auth/logout', body).then((r) => r.data),
    me: () => api.get('/api/auth/me').then((r) => r.data),
    updateProfile: (body) => api.patch('/api/auth/me', body).then((r) => r.data),
    changePassword: (body) => api.post('/api/auth/change-password', body).then((r) => r.data),
    requestReset: (body) => api.post('/api/auth/password-reset/request', body).then((r) => r.data),
    confirmReset: (body) => api.post('/api/auth/password-reset/confirm', body).then((r) => r.data),
    enrollTotp: () => api.get('/api/auth/totp/enroll').then((r) => r.data),
    confirmTotp: (body) => api.post('/api/auth/totp/enroll', body).then((r) => r.data),
    disableTotp: (body) => api.post('/api/auth/totp/disable', body).then((r) => r.data),
    sessions: () => api.get('/api/auth/sessions').then((r) => r.data),
  },

  restaurants: {
    list: () => api.get('/api/restaurants/').then((r) => r.data),
    create: (body) => api.post('/api/restaurants/', body).then((r) => r.data),
    current: () => api.get('/api/restaurants/current').then((r) => r.data),
    update: (body) => api.patch('/api/restaurants/current', body).then((r) => r.data),
    invitations: (body) => api.post('/api/restaurants/invitations', body).then((r) => r.data),
  },

  branches: {
    list: (params) => api.get('/api/branches/', { params }).then((r) => r.data),
    create: (body) => api.post('/api/branches/', body).then((r) => r.data),
    update: (id, body) => api.patch(`/api/branches/${id}`, body).then((r) => r.data),
    delete: (id) => api.delete(`/api/branches/${id}`).then((r) => r.data),
  },

  staff: {
    list: (params) => api.get('/api/staff/', { params }).then((r) => r.data),
    detail: (id) => api.get(`/api/staff/${id}`).then((r) => r.data),
    shifts: (params) => api.get('/api/staff/shifts', { params }).then((r) => r.data),
    createShift: (body) => api.post('/api/staff/shifts', body).then((r) => r.data),
    clockIn: (body) => api.post('/api/staff/time-clock/in', body).then((r) => r.data),
    clockOut: (body) => api.post('/api/staff/time-clock/out', body).then((r) => r.data),
  },

  roles: {
    list: () => api.get('/api/roles/').then((r) => r.data),
    catalog: () => api.get('/api/roles/catalog').then((r) => r.data),
    create: (body) => api.post('/api/roles/', body).then((r) => r.data),
    update: (id, body) => api.patch(`/api/roles/${id}`, body).then((r) => r.data),
  },

  menus: {
    list: () => api.get('/api/menus/').then((r) => r.data),
    create: (body) => api.post('/api/menus/', body).then((r) => r.data),
    items: (params) => api.get('/api/menus/items', { params }).then((r) => r.data),
    createItem: (body) => api.post('/api/menus/items', body).then((r) => r.data),
    updateItem: (id, body) => api.patch(`/api/menus/items/${id}`, body).then((r) => r.data),
    categories: (params) => api.get('/api/menus/categories', { params }).then((r) => r.data),
    createCategory: (body) => api.post('/api/menus/categories', body).then((r) => r.data),
  },

  modifiers: {
    groups: () => api.get('/api/modifiers/groups').then((r) => r.data),
    options: (params) => api.get('/api/modifiers/options', { params }).then((r) => r.data),
    createGroup: (body) => api.post('/api/modifiers/groups', body).then((r) => r.data),
    createOption: (body) => api.post('/api/modifiers/options', body).then((r) => r.data),
  },

  tables: {
    list: (params) => api.get('/api/tables/', { params }).then((r) => r.data),
    create: (body) => api.post('/api/tables/', body).then((r) => r.data),
    transition: (id, body) => api.post(`/api/tables/${id}/transition`, body).then((r) => r.data),
    rotateQr: (id) => api.post(`/api/tables/${id}/qr/rotate`).then((r) => r.data),
    areas: () => api.get('/api/tables/areas').then((r) => r.data),
    createArea: (body) => api.post('/api/tables/areas', body).then((r) => r.data),
  },

  reservations: {
    list: (params) => api.get('/api/reservations/', { params }).then((r) => r.data),
    create: (body) => api.post('/api/reservations/', body).then((r) => r.data),
    update: (id, body) => api.patch(`/api/reservations/${id}`, body).then((r) => r.data),
    transition: (id, body) => api.post(`/api/reservations/${id}/transition`, body).then((r) => r.data),
    waitlist: () => api.get('/api/reservations/waitlist').then((r) => r.data),
  },

  orders: {
    list: (params) => api.get('/api/orders/', { params }).then((r) => r.data),
    detail: (id) => api.get(`/api/orders/${id}`).then((r) => r.data),
    create: (body) => api.post('/api/orders/', body).then((r) => r.data),
    addItem: (id, body) => api.post(`/api/orders/${id}/items`, body).then((r) => r.data),
    voidItem: (id, itemId, body) => api.post(`/api/orders/${id}/items/${itemId}/void`, body).then((r) => r.data),
    transition: (id, body) => api.post(`/api/orders/${id}/transition`, body).then((r) => r.data),
    split: (id, body) => api.post(`/api/orders/${id}/split`, body).then((r) => r.data),
  },

  kitchen: {
    tickets: (params) => api.get('/api/kitchen/tickets', { params }).then((r) => r.data),
    transitionTicket: (id, body) => api.post(`/api/kitchen/tickets/${id}/transition`, body).then((r) => r.data),
    markItemDone: (id, itemId) => api.post(`/api/kitchen/tickets/${id}/items/${itemId}/done`).then((r) => r.data),
    stations: () => api.get('/api/kitchen/stations').then((r) => r.data),
  },

  payments: {
    list: (params) => api.get('/api/payments/', { params }).then((r) => r.data),
    capture: (body) => api.post('/api/payments/capture', body).then((r) => r.data),
    refund: (body) => api.post('/api/payments/refunds', body).then((r) => r.data),
    closeouts: () => api.get('/api/payments/closeouts').then((r) => r.data),
    createCloseout: (body) => api.post('/api/payments/closeouts/create', body).then((r) => r.data),
  },

  customers: {
    list: (params) => api.get('/api/customers/', { params }).then((r) => r.data),
    detail: (id) => api.get(`/api/customers/${id}`).then((r) => r.data),
    create: (body) => api.post('/api/customers/', body).then((r) => r.data),
    update: (id, body) => api.patch(`/api/customers/${id}`, body).then((r) => r.data),
  },

  loyalty: {
    accounts: () => api.get('/api/loyalty/accounts').then((r) => r.data),
    rewards: () => api.get('/api/loyalty/rewards').then((r) => r.data),
    createReward: (body) => api.post('/api/loyalty/rewards', body).then((r) => r.data),
    adjust: (body) => api.post('/api/loyalty/adjust', body).then((r) => r.data),
    redeem: (body) => api.post('/api/loyalty/redeem', body).then((r) => r.data),
  },

  coupons: {
    list: () => api.get('/api/coupons/').then((r) => r.data),
    create: (body) => api.post('/api/coupons/', body).then((r) => r.data),
    apply: (body) => api.post('/api/coupons/apply', body).then((r) => r.data),
  },

  inventory: {
    list: (params) => api.get('/api/inventory/', { params }).then((r) => r.data),
    create: (body) => api.post('/api/inventory/', body).then((r) => r.data),
    update: (id, body) => api.patch(`/api/inventory/${id}`, body).then((r) => r.data),
    adjust: (id, body) => api.post(`/api/inventory/${id}/adjust`, body).then((r) => r.data),
    waste: (body) => api.post('/api/inventory/waste', body).then((r) => r.data),
    counts: () => api.get('/api/inventory/counts').then((r) => r.data),
    finalizeCount: (id) => api.post(`/api/inventory/counts/${id}/finalize`).then((r) => r.data),
    lowStock: () => api.get('/api/inventory/low-stock').then((r) => r.data),
  },

  suppliers: {
    list: () => api.get('/api/suppliers/').then((r) => r.data),
    create: (body) => api.post('/api/suppliers/', body).then((r) => r.data),
  },

  purchasing: {
    list: () => api.get('/api/purchasing/').then((r) => r.data),
    create: (body) => api.post('/api/purchasing/', body).then((r) => r.data),
    submit: (id) => api.post(`/api/purchasing/${id}/submit`).then((r) => r.data),
    receive: (id, body) => api.post(`/api/purchasing/${id}/receive`, body).then((r) => r.data),
  },

  delivery: {
    list: (params) => api.get('/api/delivery/', { params }).then((r) => r.data),
    transition: (id, body) => api.post(`/api/delivery/${id}/transition`, body).then((r) => r.data),
    assign: (id, body) => api.post(`/api/delivery/${id}/assign`, body).then((r) => r.data),
    zones: (params) => api.get('/api/delivery/zones', { params }).then((r) => r.data),
  },

  notifications: {
    list: (params) => api.get('/api/notifications/', { params }).then((r) => r.data),
    markRead: (body) => api.post('/api/notifications/read', body).then((r) => r.data),
    preferences: () => api.get('/api/notifications/preferences').then((r) => r.data),
    updatePreferences: (body) => api.patch('/api/notifications/preferences', body).then((r) => r.data),
  },

  reports: {
    dashboard: () => api.get('/api/reports/dashboard').then((r) => r.data),
    exports: () => api.get('/api/reports/exports').then((r) => r.data),
    createExport: (body) => api.post('/api/reports/exports/create', body).then((r) => r.data),
  },

  audit: {
    list: (params) => api.get('/api/audit-logs/', { params }).then((r) => r.data),
  },

  apiKeys: {
    list: () => api.get('/api/api-keys/').then((r) => r.data),
    issue: (body) => api.post('/api/api-keys/issue', body).then((r) => r.data),
    revoke: (id) => api.post(`/api/api-keys/${id}/revoke`).then((r) => r.data),
  },

  webhooks: {
    list: () => api.get('/api/webhooks/').then((r) => r.data),
    create: (body) => api.post('/api/webhooks/', body).then((r) => r.data),
    deliveries: () => api.get('/api/webhooks/deliveries').then((r) => r.data),
  },
};
