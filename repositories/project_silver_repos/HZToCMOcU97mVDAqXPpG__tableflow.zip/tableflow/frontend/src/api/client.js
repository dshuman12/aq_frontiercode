import axios from 'axios';

let access = null;
let onUnauthorized = null;

export function setAccessToken(token) {
  access = token;
}

export function setUnauthorizedHandler(handler) {
  onUnauthorized = handler;
}

export const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || '',
  headers: { 'Content-Type': 'application/json' },
});

api.interceptors.request.use((config) => {
  if (access) {
    config.headers.Authorization = `Bearer ${access}`;
  }
  return config;
});

api.interceptors.response.use(
  (r) => r,
  (err) => {
    if (err.response?.status === 401 && onUnauthorized) {
      onUnauthorized();
    }
    const detail = err.response?.data?.detail || err.response?.data?.errors || err.message;
    const e = new Error(typeof detail === 'string' ? detail : 'request-failed');
    e.status = err.response?.status;
    e.detail = err.response?.data;
    throw e;
  },
);
