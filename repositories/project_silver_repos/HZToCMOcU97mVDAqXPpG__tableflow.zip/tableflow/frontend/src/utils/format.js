export function formatMoney(cents, currency = 'USD', locale = 'en-US') {
  const value = (Number(cents) || 0) / 100;
  try {
    return new Intl.NumberFormat(locale, { style: 'currency', currency }).format(value);
  } catch {
    return `$${value.toFixed(2)}`;
  }
}

export function formatNumber(n, locale = 'en-US') {
  try {
    return new Intl.NumberFormat(locale).format(Number(n) || 0);
  } catch {
    return String(n);
  }
}

export function formatPhone(p) {
  const digits = String(p || '').replace(/\D/g, '');
  if (digits.length === 10) return `(${digits.slice(0, 3)}) ${digits.slice(3, 6)}-${digits.slice(6)}`;
  if (digits.length === 11 && digits[0] === '1') return `+1 (${digits.slice(1, 4)}) ${digits.slice(4, 7)}-${digits.slice(7)}`;
  return p;
}

export function relativeTime(d, now = new Date()) {
  const ms = new Date(d).getTime() - now.getTime();
  const abs = Math.abs(ms);
  const min = 60_000;
  const hr = 60 * min;
  const day = 24 * hr;
  if (abs < min) return 'just now';
  if (abs < hr) return `${Math.round(abs / min)}m ${ms < 0 ? 'ago' : ''}`.trim();
  if (abs < day) return `${Math.round(abs / hr)}h ${ms < 0 ? 'ago' : ''}`.trim();
  return `${Math.round(abs / day)}d ${ms < 0 ? 'ago' : ''}`.trim();
}

export function truncate(s, max = 80) {
  const x = String(s || '');
  return x.length <= max ? x : x.slice(0, max - 1) + '…';
}
