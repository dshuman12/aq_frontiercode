import { describe, expect, it } from 'vitest';
import { formatMoney, formatNumber, formatPhone, relativeTime, truncate } from './format';

describe('format', () => {
  it('formatMoney converts cents to USD string', () => {
    expect(formatMoney(12345)).toMatch(/\$123\.45/);
    expect(formatMoney(0)).toMatch(/\$0\.00/);
  });

  it('formatNumber adds thousands separators', () => {
    expect(formatNumber(1234567)).toMatch(/1,234,567/);
  });

  it('formatPhone formats US 10-digit numbers', () => {
    expect(formatPhone('5125551234')).toBe('(512) 555-1234');
  });

  it('formatPhone formats US 11-digit (with country code) numbers', () => {
    expect(formatPhone('15125551234')).toBe('+1 (512) 555-1234');
  });

  it('truncate keeps short strings intact', () => {
    expect(truncate('hi', 80)).toBe('hi');
  });

  it('truncate adds ellipsis past max', () => {
    const out = truncate('a'.repeat(100), 10);
    expect(out.length).toBe(10);
    expect(out.endsWith('…')).toBe(true);
  });

  it('relativeTime returns "just now" within a minute', () => {
    const now = new Date('2024-08-15T12:00:00Z');
    expect(relativeTime(now, now)).toBe('just now');
  });

  it('relativeTime returns minutes ago', () => {
    const now = new Date('2024-08-15T12:30:00Z');
    const past = new Date('2024-08-15T12:20:00Z');
    expect(relativeTime(past, now)).toBe('10m ago');
  });
});
