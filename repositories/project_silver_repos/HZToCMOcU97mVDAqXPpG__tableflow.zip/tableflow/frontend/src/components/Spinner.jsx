import clsx from 'clsx';

const SIZES = {
  xs: 'w-3 h-3',
  sm: 'w-4 h-4',
  md: 'w-6 h-6',
  lg: 'w-8 h-8',
};

export function Spinner({ size = 'md', className, label }) {
  return (
    <span role="status" aria-label={label || 'Loading'} className="inline-flex items-center gap-2">
      <span
        className={clsx(
          'inline-block border-2 border-current border-t-transparent rounded-full animate-spin text-brand-600',
          SIZES[size] || SIZES.md,
          className,
        )}
      />
      {label && <span className="text-sm text-slate-500">{label}</span>}
    </span>
  );
}
