import { useState } from 'react';
import clsx from 'clsx';

export function Tooltip({ label, side = 'top', className, children }) {
  const [open, setOpen] = useState(false);
  const sideCls = {
    top: 'bottom-full left-1/2 -translate-x-1/2 mb-1',
    bottom: 'top-full left-1/2 -translate-x-1/2 mt-1',
    left: 'right-full top-1/2 -translate-y-1/2 mr-1',
    right: 'left-full top-1/2 -translate-y-1/2 ml-1',
  }[side];
  return (
    <span
      className={clsx('relative inline-block', className)}
      onMouseEnter={() => setOpen(true)}
      onMouseLeave={() => setOpen(false)}
      onFocus={() => setOpen(true)}
      onBlur={() => setOpen(false)}
    >
      {children}
      {open && (
        <span
          role="tooltip"
          className={clsx(
            'absolute z-30 px-2 py-1 rounded-md bg-slate-900 text-white text-xs whitespace-nowrap shadow-lg',
            sideCls,
          )}
        >
          {label}
        </span>
      )}
    </span>
  );
}
