import clsx from 'clsx';

const VARIANTS = {
  primary: 'btn-primary',
  secondary: 'btn-secondary',
  danger: 'btn-danger',
};

export function Button({ variant = 'primary', loading = false, disabled = false, className, children, ...rest }) {
  return (
    <button
      className={clsx(VARIANTS[variant] || VARIANTS.primary, className)}
      disabled={disabled || loading}
      {...rest}
    >
      {loading && <span className="inline-block w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />}
      {children}
    </button>
  );
}
