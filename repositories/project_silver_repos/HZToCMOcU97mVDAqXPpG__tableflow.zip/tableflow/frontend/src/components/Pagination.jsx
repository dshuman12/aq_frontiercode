import clsx from 'clsx';

export function pageWindow(current, total, span = 2) {
  const out = [];
  const start = Math.max(1, current - span);
  const end = Math.min(total, current + span);
  if (start > 1) {
    out.push(1);
    if (start > 2) out.push('…');
  }
  for (let i = start; i <= end; i++) out.push(i);
  if (end < total) {
    if (end < total - 1) out.push('…');
    out.push(total);
  }
  return out;
}

export function Pagination({ page, total, pageSize, onChange, className }) {
  const pages = Math.max(1, Math.ceil(total / pageSize));
  const window = pageWindow(page, pages);
  const btn = 'h-8 min-w-[2rem] px-2 text-sm rounded-md border border-slate-200 bg-white hover:bg-slate-50 disabled:opacity-50';
  return (
    <div className={clsx('flex items-center gap-1', className)}>
      <button type="button" className={btn} disabled={page <= 1} onClick={() => onChange(page - 1)}>Prev</button>
      {window.map((p, i) =>
        p === '…' ? (
          <span key={`e-${i}`} className="px-2 text-slate-400">…</span>
        ) : (
          <button
            key={p}
            type="button"
            onClick={() => onChange(p)}
            className={clsx(btn, p === page && 'bg-brand-600 text-white border-brand-600 hover:bg-brand-700')}
          >
            {p}
          </button>
        ),
      )}
      <button type="button" className={btn} disabled={page >= pages} onClick={() => onChange(page + 1)}>Next</button>
    </div>
  );
}
