import clsx from 'clsx';

const TONES = {
  neutral: 'bg-slate-100 text-slate-700',
  brand: 'bg-amber-100 text-amber-800',
  success: 'bg-green-100 text-green-800',
  warn: 'bg-amber-100 text-amber-900',
  danger: 'bg-red-100 text-red-800',
  info: 'bg-sky-100 text-sky-800',
};

export function Badge({ tone = 'neutral', dot = false, className, children }) {
  return (
    <span className={clsx('badge', TONES[tone] || TONES.neutral, className)}>
      {dot && <span className="w-1.5 h-1.5 rounded-full bg-current opacity-80" />}
      {children}
    </span>
  );
}
