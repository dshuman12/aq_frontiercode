import clsx from 'clsx';

export function Tabs({ value, onChange, items, variant = 'underline', className }) {
  return (
    <div className={clsx('flex items-center gap-1', variant === 'underline' && 'border-b border-slate-100', className)}>
      {items.map((it) => {
        const active = it.value === value;
        const baseCls = 'px-3 py-2 text-sm font-medium transition-colors focus:outline-none';
        const variantCls =
          variant === 'pill'
            ? clsx('rounded-lg', active ? 'bg-brand-600 text-white' : 'text-slate-700 hover:bg-slate-100')
            : clsx(
                '-mb-px border-b-2',
                active ? 'border-brand-600 text-brand-700' : 'border-transparent text-slate-700 hover:text-slate-900',
              );
        return (
          <button key={it.value} type="button" onClick={() => onChange(it.value)} className={clsx(baseCls, variantCls)}>
            {it.label}
            {it.badge != null && (
              <span className="ml-1.5 inline-flex items-center justify-center h-4 min-w-[1rem] px-1 rounded-full bg-slate-100 text-slate-700 text-[10px]">
                {it.badge}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
}
