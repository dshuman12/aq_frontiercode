import { forwardRef } from 'react';
import clsx from 'clsx';

export const Input = forwardRef(function Input({ className, invalid, ...rest }, ref) {
  return (
    <input
      ref={ref}
      className={clsx('input', invalid && 'border-red-400 focus:ring-red-200', className)}
      {...rest}
    />
  );
});
