export function Field({ label, hint, error, required, htmlFor, children }) {
  return (
    <div className="mb-4">
      {label && (
        <label htmlFor={htmlFor} className="label">
          {label}
          {required && <span className="text-red-500 ml-0.5">*</span>}
        </label>
      )}
      {children}
      {error ? (
        <p className="text-xs text-red-600 mt-1">{error}</p>
      ) : hint ? (
        <p className="text-xs text-slate-500 mt-1">{hint}</p>
      ) : null}
    </div>
  );
}
