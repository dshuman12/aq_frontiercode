import { Badge } from './Badge';

const ORDER_TONE = {
  draft: 'neutral',
  placed: 'info',
  accepted: 'info',
  preparing: 'warn',
  ready: 'success',
  served: 'success',
  out_for_delivery: 'brand',
  completed: 'success',
  cancelled: 'danger',
  refunded: 'danger',
};

const TABLE_TONE = {
  available: 'success',
  reserved: 'info',
  seated: 'brand',
  ordering: 'brand',
  preparing: 'warn',
  served: 'success',
  needs_cleaning: 'warn',
  closed: 'neutral',
};

const RESERVATION_TONE = {
  requested: 'neutral',
  confirmed: 'info',
  seated: 'brand',
  completed: 'success',
  cancelled: 'danger',
  no_show: 'warn',
};

const KITCHEN_TONE = {
  queued: 'neutral',
  in_progress: 'warn',
  ready: 'success',
  served: 'success',
  cancelled: 'danger',
};

const PAYMENT_TONE = {
  pending: 'warn',
  captured: 'success',
  failed: 'danger',
  voided: 'neutral',
  refunded: 'danger',
};

const DELIVERY_TONE = {
  pending: 'neutral',
  assigned: 'info',
  picked_up: 'brand',
  delivering: 'brand',
  delivered: 'success',
  failed: 'danger',
  cancelled: 'danger',
};

const MAPS = {
  order: ORDER_TONE,
  table: TABLE_TONE,
  reservation: RESERVATION_TONE,
  kitchen: KITCHEN_TONE,
  payment: PAYMENT_TONE,
  delivery: DELIVERY_TONE,
};

export function StatusPill({ kind = 'order', value, ...rest }) {
  const map = MAPS[kind] || ORDER_TONE;
  const tone = map[value] || 'neutral';
  return (
    <Badge tone={tone} dot {...rest}>
      {String(value || '').replace(/_/g, ' ')}
    </Badge>
  );
}
