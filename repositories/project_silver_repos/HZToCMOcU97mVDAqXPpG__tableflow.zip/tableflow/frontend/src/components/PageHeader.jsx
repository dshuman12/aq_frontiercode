import clsx from 'clsx';

export function PageHeader({ title, description, actions, className }) {
  return (
    <div className={clsx('flex items-end justify-between gap-4 mb-6', className)}>
      <div className="min-w-0">
        <h1 className="text-2xl font-semibold truncate">{title}</h1>
        {description && <p className="text-sm text-slate-500 mt-1">{description}</p>}
      </div>
      {actions && <div className="flex items-center gap-2 shrink-0">{actions}</div>}
    </div>
  );
}
