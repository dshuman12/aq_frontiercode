import clsx from 'clsx';

export function Skeleton({ className, w, h, rounded = 'md' }) {
  const r = { sm: 'rounded', md: 'rounded-md', lg: 'rounded-lg', xl: 'rounded-xl', full: 'rounded-full' }[rounded] || 'rounded-md';
  return (
    <div className={clsx('animate-pulse bg-slate-200/70', r, className)} style={{ width: w, height: h }} />
  );
}

export function SkeletonText({ lines = 3, className }) {
  return (
    <div className={clsx('space-y-2', className)}>
      {Array.from({ length: lines }).map((_, i) => (
        <Skeleton key={i} h={12} className={i === lines - 1 ? 'w-2/3' : 'w-full'} />
      ))}
    </div>
  );
}
