import { render, fireEvent } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import { Button } from './Button';

describe('Button', () => {
  it('renders children', () => {
    const { getByText } = render(<Button>Click me</Button>);
    expect(getByText('Click me')).toBeInTheDocument();
  });

  it('disables on loading and shows spinner', () => {
    const { container } = render(<Button loading>Save</Button>);
    expect(container.querySelector('button')).toBeDisabled();
    expect(container.querySelector('.animate-spin')).toBeInTheDocument();
  });

  it('applies the variant class', () => {
    const { container } = render(<Button variant="danger">Delete</Button>);
    expect(container.firstChild.className).toContain('btn-danger');
  });

  it('handles clicks', () => {
    const onClick = vi.fn();
    const { getByText } = render(<Button onClick={onClick}>Tap</Button>);
    fireEvent.click(getByText('Tap'));
    expect(onClick).toHaveBeenCalledTimes(1);
  });
});
