import clsx from 'clsx';

export function Card({ className, children, ...rest }) {
  return (
    <div className={clsx('card p-4', className)} {...rest}>
      {children}
    </div>
  );
}

export function CardHeader({ title, subtitle, actions, className }) {
  return (
    <div className={clsx('flex items-start justify-between gap-3 pb-3 border-b border-slate-100', className)}>
      <div>
        <h3 className="text-base font-semibold">{title}</h3>
        {subtitle && <p className="text-sm text-slate-500 mt-0.5">{subtitle}</p>}
      </div>
      {actions && <div className="flex items-center gap-2">{actions}</div>}
    </div>
  );
}

export function CardBody({ className, children }) {
  return <div className={clsx('pt-3', className)}>{children}</div>;
}
