import { render, fireEvent } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import { DataTable } from './DataTable';

const COLUMNS = [
  { key: 'name', header: 'Name' },
  { key: 'price', header: 'Price', render: (r) => `$${(r.price / 100).toFixed(2)}` },
];

describe('DataTable', () => {
  it('renders rows with rendered cells', () => {
    const rows = [{ id: 'a', name: 'Burger', price: 1099 }];
    const { getByText } = render(<DataTable columns={COLUMNS} rows={rows} />);
    expect(getByText('Burger')).toBeInTheDocument();
    expect(getByText('$10.99')).toBeInTheDocument();
  });

  it('shows skeleton on loading', () => {
    const { container } = render(<DataTable columns={COLUMNS} loading />);
    expect(container.querySelectorAll('.animate-pulse').length).toBeGreaterThan(0);
  });

  it('shows empty state with no rows', () => {
    const { getByText } = render(<DataTable columns={COLUMNS} rows={[]} emptyTitle="None yet" />);
    expect(getByText('None yet')).toBeInTheDocument();
  });

  it('calls onRowClick on tr click', () => {
    const onRowClick = vi.fn();
    const rows = [{ id: 'a', name: 'A' }];
    const { getByText } = render(<DataTable columns={[{ key: 'name', header: 'Name' }]} rows={rows} onRowClick={onRowClick} />);
    fireEvent.click(getByText('A'));
    expect(onRowClick).toHaveBeenCalledWith(rows[0]);
  });
});
