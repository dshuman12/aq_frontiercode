import { render } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import { StatusPill } from './StatusPill';

describe('StatusPill', () => {
  it('renders the value with underscores spaced', () => {
    const { getByText } = render(<StatusPill kind="order" value="out_for_delivery" />);
    expect(getByText('out for delivery')).toBeInTheDocument();
  });

  it('falls back to neutral for unknown values', () => {
    const { container } = render(<StatusPill kind="order" value="bogus" />);
    expect(container.firstChild.className).toContain('bg-slate-100');
  });

  it('uses the kitchen palette when kind=kitchen', () => {
    const { container } = render(<StatusPill kind="kitchen" value="ready" />);
    expect(container.firstChild.className).toContain('bg-green-100');
  });

  it('table seated shows brand tone', () => {
    const { container } = render(<StatusPill kind="table" value="seated" />);
    expect(container.firstChild.className).toContain('bg-amber-100');
  });
});
