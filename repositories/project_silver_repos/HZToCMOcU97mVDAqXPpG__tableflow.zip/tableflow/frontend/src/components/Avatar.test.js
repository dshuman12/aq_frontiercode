import { describe, expect, it } from 'vitest';
import { initials } from './Avatar';

describe('Avatar.initials', () => {
  it('uses first and last initial', () => {
    expect(initials('Ada Lovelace')).toBe('AL');
  });
  it('handles single names', () => {
    expect(initials('Plato')).toBe('PL');
  });
  it('returns ? for empty', () => {
    expect(initials('')).toBe('?');
    expect(initials()).toBe('?');
  });
  it('first + last on multi-word', () => {
    expect(initials('Mary Wollstonecraft Shelley')).toBe('MS');
  });
});
