import { useEffect, useState } from 'react';
import clsx from 'clsx';
import { useDebounced } from '../hooks/useDebounced';

export function SearchBar({ value, onChange, placeholder = 'Search…', delay = 300, className }) {
  const [local, setLocal] = useState(value || '');
  const debounced = useDebounced(local, delay);

  useEffect(() => {
    if (debounced !== value) onChange?.(debounced);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debounced]);

  return (
    <div className={clsx('flex items-center gap-2 h-10 px-3 rounded-lg border border-slate-200 bg-white focus-within:ring-2 focus-within:ring-brand-500/40', className)}>
      <span className="text-slate-400">🔎</span>
      <input
        type="search"
        value={local}
        onChange={(e) => setLocal(e.target.value)}
        placeholder={placeholder}
        className="flex-1 bg-transparent outline-none text-sm placeholder:text-slate-400"
      />
      {local && (
        <button type="button" onClick={() => setLocal('')} className="text-slate-400 hover:text-slate-700">×</button>
      )}
    </div>
  );
}
