import { useEffect } from 'react';
import clsx from 'clsx';

const SIZES = { sm: 'max-w-sm', md: 'max-w-md', lg: 'max-w-lg', xl: 'max-w-2xl' };

export function Modal({ open, onClose, title, size = 'md', footer, children }) {
  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e) => e.key === 'Escape' && onClose && onClose();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" role="dialog" aria-modal="true">
      <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm" onClick={onClose} />
      <div className={clsx('relative w-full bg-white rounded-2xl shadow-xl overflow-hidden', SIZES[size])}>
        {title && (
          <div className="flex items-center justify-between px-5 py-3 border-b border-slate-100">
            <h3 className="text-base font-semibold">{title}</h3>
            <button type="button" onClick={onClose} className="text-slate-500 hover:text-slate-900 w-8 h-8 inline-flex items-center justify-center rounded-md hover:bg-slate-100">×</button>
          </div>
        )}
        <div className="p-5">{children}</div>
        {footer && <div className="px-5 py-3 border-t border-slate-100 bg-slate-50/50 flex items-center justify-end gap-2">{footer}</div>}
      </div>
    </div>
  );
}
