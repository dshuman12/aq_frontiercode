import { useEffect } from 'react';
import clsx from 'clsx';

export function Drawer({ open, onClose, side = 'right', title, footer, children }) {
  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e) => e.key === 'Escape' && onClose && onClose();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);
  if (!open) return null;
  const sideCls = side === 'right' ? 'right-0' : 'left-0';
  return (
    <div className="fixed inset-0 z-50">
      <div className="absolute inset-0 bg-slate-900/30" onClick={onClose} />
      <div className={clsx('absolute top-0 bottom-0 w-[28rem] bg-white shadow-xl flex flex-col', sideCls)}>
        {title && (
          <div className="flex items-center justify-between px-5 py-3 border-b border-slate-100">
            <h3 className="font-semibold">{title}</h3>
            <button type="button" onClick={onClose} className="text-slate-500 hover:text-slate-900">×</button>
          </div>
        )}
        <div className="p-5 overflow-y-auto flex-1">{children}</div>
        {footer && <div className="px-5 py-3 border-t border-slate-100 flex items-center justify-end gap-2">{footer}</div>}
      </div>
    </div>
  );
}
