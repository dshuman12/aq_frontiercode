import { describe, expect, it } from 'vitest';
import { pageWindow } from './Pagination';

describe('pageWindow', () => {
  it('returns the visible window when total fits', () => {
    expect(pageWindow(3, 5)).toEqual([1, 2, 3, 4, 5]);
  });
  it('inserts an ellipsis on the right', () => {
    const w = pageWindow(2, 50);
    expect(w[0]).toBe(1);
    expect(w).toContain('…');
    expect(w[w.length - 1]).toBe(50);
  });
  it('inserts an ellipsis on the left', () => {
    const w = pageWindow(48, 50);
    expect(w[0]).toBe(1);
    expect(w).toContain('…');
    expect(w[w.length - 1]).toBe(50);
  });
  it('two ellipses for far-from-edges', () => {
    const w = pageWindow(25, 50);
    expect(w.filter((x) => x === '…').length).toBe(2);
    expect(w).toContain(25);
  });
});
