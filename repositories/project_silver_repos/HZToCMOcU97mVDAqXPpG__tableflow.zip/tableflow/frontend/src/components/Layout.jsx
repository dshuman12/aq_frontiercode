import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import clsx from 'clsx';
import { useAuth } from '../stores/auth';
import { useBranchStore } from '../stores/branch';

const NAV = [
  { section: 'Workspace' },
  { to: '/', label: 'Dashboard', icon: '🏠' },
  { to: '/floor', label: 'Floor', icon: '🪑' },
  { to: '/calendar', label: 'Reservations', icon: '📅' },
  { to: '/orders', label: 'Orders', icon: '📋' },
  { to: '/kitchen', label: 'Kitchen', icon: '🍳' },

  { section: 'Menu' },
  { to: '/menu', label: 'Menu builder', icon: '📖' },
  { to: '/modifiers', label: 'Modifiers', icon: '➕' },

  { section: 'People' },
  { to: '/customers', label: 'Customers', icon: '👥' },
  { to: '/loyalty', label: 'Loyalty', icon: '⭐' },
  { to: '/coupons', label: 'Coupons', icon: '🏷' },
  { to: '/staff', label: 'Staff', icon: '👨‍🍳' },

  { section: 'Operations' },
  { to: '/inventory', label: 'Inventory', icon: '📦' },
  { to: '/suppliers', label: 'Suppliers', icon: '🚚' },
  { to: '/purchasing', label: 'Purchasing', icon: '🧾' },
  { to: '/delivery', label: 'Delivery', icon: '🛵' },

  { section: 'Finance' },
  { to: '/payments', label: 'Payments', icon: '💳' },
  { to: '/closeouts', label: 'Closeouts', icon: '🗓' },
  { to: '/reports', label: 'Reports', icon: '📊' },

  { section: 'Admin' },
  { to: '/admin/branches', label: 'Branches', icon: '🏢' },
  { to: '/admin/roles', label: 'Roles', icon: '🔐' },
  { to: '/admin/audit', label: 'Audit log', icon: '🕵' },
  { to: '/admin/api-keys', label: 'API keys', icon: '🔑' },
  { to: '/admin/webhooks', label: 'Webhooks', icon: '🪝' },
];

export function Layout() {
  const auth = useAuth();
  const branches = useBranchStore((s) => s.branches);
  const activeBranchId = useBranchStore((s) => s.activeBranchId);
  const setActiveBranch = useBranchStore((s) => s.setActiveBranch);
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex bg-slate-50">
      <aside className="w-60 shrink-0 bg-white border-r border-slate-200 flex flex-col">
        <div className="px-4 py-4 border-b border-slate-100 flex items-center gap-2 font-semibold">
          <span className="w-8 h-8 rounded-lg bg-brand-600 text-white inline-flex items-center justify-center">T</span>
          TableFlow
        </div>
        <nav className="flex-1 overflow-y-auto py-2">
          {NAV.map((it, i) =>
            it.section ? (
              <div key={i} className="px-4 pt-3 pb-1 text-[11px] font-semibold uppercase tracking-wide text-slate-400">
                {it.section}
              </div>
            ) : (
              <NavLink
                key={it.to}
                to={it.to}
                end={it.to === '/'}
                className={({ isActive }) =>
                  clsx(
                    'mx-2 my-0.5 rounded-md px-3 py-2 text-sm flex items-center gap-2',
                    isActive ? 'bg-amber-50 text-amber-900 font-medium' : 'text-slate-700 hover:bg-slate-100',
                  )
                }
              >
                <span className="w-5 text-center">{it.icon}</span>
                <span className="truncate">{it.label}</span>
              </NavLink>
            ),
          )}
        </nav>
        <div className="px-4 py-3 border-t border-slate-100 text-xs text-slate-500">
          {auth.user?.email} · {auth.role}
        </div>
      </aside>

      <div className="flex-1 min-w-0 flex flex-col">
        <header className="h-14 bg-white border-b border-slate-200 flex items-center px-4 gap-3 sticky top-0 z-30">
          <select
            value={activeBranchId || ''}
            onChange={(e) => setActiveBranch(e.target.value)}
            className="input h-9 w-56"
          >
            <option value="">All branches</option>
            {branches.map((b) => (
              <option key={b.id} value={b.id}>
                {b.name}
              </option>
            ))}
          </select>
          <div className="flex-1" />
          <button
            type="button"
            className="btn-secondary h-9"
            onClick={() => {
              auth.logout();
              navigate('/login');
            }}
          >
            Sign out
          </button>
        </header>
        <main className="flex-1 px-6 py-6 overflow-x-hidden">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
