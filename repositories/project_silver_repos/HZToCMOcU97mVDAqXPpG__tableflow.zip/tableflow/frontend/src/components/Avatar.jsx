import clsx from 'clsx';

const SIZES = {
  xs: 'w-6 h-6 text-[10px]',
  sm: 'w-8 h-8 text-xs',
  md: 'w-10 h-10 text-sm',
  lg: 'w-12 h-12 text-base',
};

export function initials(name = '') {
  const parts = String(name).trim().split(/\s+/);
  if (parts.length === 0) return '?';
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

export function Avatar({ name = '', src = null, size = 'md', className }) {
  const sizeCls = SIZES[size] || SIZES.md;
  if (src) {
    return <img src={src} alt={name} className={clsx('inline-block rounded-full object-cover bg-slate-100', sizeCls, className)} />;
  }
  return (
    <span
      className={clsx(
        'inline-flex items-center justify-center rounded-full bg-amber-100 text-amber-800 font-semibold',
        sizeCls,
        className,
      )}
    >
      {initials(name)}
    </span>
  );
}
