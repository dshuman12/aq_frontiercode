export function EmptyState({ title, description, action }) {
  return (
    <div className="text-center py-10 px-6 rounded-xl border border-dashed border-slate-200 bg-white">
      <div className="text-3xl mb-2">∅</div>
      <p className="font-semibold">{title}</p>
      {description && <p className="text-sm text-slate-500 mt-1">{description}</p>}
      {action && <div className="mt-3">{action}</div>}
    </div>
  );
}
