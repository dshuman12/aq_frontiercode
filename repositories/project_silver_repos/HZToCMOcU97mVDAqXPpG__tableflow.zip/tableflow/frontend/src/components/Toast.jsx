import { createContext, useCallback, useContext, useMemo, useState } from 'react';
import clsx from 'clsx';

const ToastCtx = createContext(null);

const TONES = {
  success: 'border-l-green-600',
  error: 'border-l-red-600',
  info: 'border-l-sky-600',
  warn: 'border-l-amber-600',
};

export function ToastProvider({ children }) {
  const [items, setItems] = useState([]);
  const dismiss = useCallback((id) => setItems((s) => s.filter((t) => t.id !== id)), []);
  const push = useCallback((toast) => {
    const id = Math.random().toString(36).slice(2, 10);
    const t = { id, tone: 'info', duration: 4000, ...toast };
    setItems((s) => [...s, t]);
    if (t.duration > 0) setTimeout(() => dismiss(id), t.duration);
  }, [dismiss]);
  const api = useMemo(() => ({
    push,
    success: (msg, opts) => push({ tone: 'success', message: msg, ...opts }),
    error: (msg, opts) => push({ tone: 'error', message: msg, ...opts }),
    info: (msg, opts) => push({ tone: 'info', message: msg, ...opts }),
    warn: (msg, opts) => push({ tone: 'warn', message: msg, ...opts }),
  }), [push]);

  return (
    <ToastCtx.Provider value={api}>
      {children}
      <div className="fixed bottom-4 right-4 z-[60] space-y-2 max-w-sm">
        {items.map((t) => (
          <div key={t.id} className={clsx('rounded-xl shadow bg-white border-l-4 pl-4 pr-3 py-3 flex items-start gap-3', TONES[t.tone])}>
            <div className="flex-1">
              {t.title && <p className="text-sm font-semibold">{t.title}</p>}
              <p className="text-sm text-slate-700">{t.message}</p>
            </div>
            <button type="button" onClick={() => dismiss(t.id)} className="text-slate-400 hover:text-slate-700">×</button>
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastCtx);
  if (!ctx) throw new Error('useToast must be used inside ToastProvider');
  return ctx;
}
