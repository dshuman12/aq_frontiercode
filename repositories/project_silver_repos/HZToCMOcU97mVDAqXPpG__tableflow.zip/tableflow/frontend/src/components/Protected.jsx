import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../stores/auth';

export function Protected({ children }) {
  const accessToken = useAuth((s) => s.accessToken);
  const loc = useLocation();
  if (!accessToken) {
    return <Navigate to="/login" state={{ from: loc.pathname }} replace />;
  }
  return children;
}

export function PermissionGate({ code, fallback = null, children }) {
  const hasPerm = useAuth((s) => s.hasPerm);
  return hasPerm(code) ? children : fallback;
}
