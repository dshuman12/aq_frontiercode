import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { setAccessToken, setUnauthorizedHandler } from '../api/client';

export const useAuth = create(
  persist(
    (set, get) => ({
      accessToken: null,
      refreshToken: null,
      user: null,
      restaurantId: null,
      branchId: null,
      role: null,
      permissions: [],

      setAuth: ({ access_token, refresh_token, user, restaurant_id, branch_id, role, permissions }) => {
        setAccessToken(access_token || null);
        set({
          accessToken: access_token,
          refreshToken: refresh_token,
          user,
          restaurantId: restaurant_id ?? get().restaurantId,
          branchId: branch_id ?? get().branchId,
          role: role ?? get().role,
          permissions: permissions ?? get().permissions,
        });
      },

      logout: () => {
        setAccessToken(null);
        set({ accessToken: null, refreshToken: null, user: null });
      },

      hasPerm: (code) => {
        const perms = get().permissions || [];
        return perms.includes('*') || perms.includes(code);
      },
    }),
    {
      name: 'tableflow.auth',
      onRehydrateStorage: () => (state) => {
        if (state?.accessToken) setAccessToken(state.accessToken);
      },
    },
  ),
);

setUnauthorizedHandler(() => useAuth.getState().logout());
