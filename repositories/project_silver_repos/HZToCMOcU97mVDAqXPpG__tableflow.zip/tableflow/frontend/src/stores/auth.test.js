import { beforeEach, describe, expect, it } from 'vitest';
import { useAuth } from './auth';

describe('useAuth', () => {
  beforeEach(() => {
    useAuth.setState({ accessToken: null, refreshToken: null, user: null, permissions: [] });
  });

  it('hasPerm returns false without permissions', () => {
    expect(useAuth.getState().hasPerm('orders:read')).toBe(false);
  });

  it('hasPerm matches the wildcard', () => {
    useAuth.setState({ permissions: ['*'] });
    expect(useAuth.getState().hasPerm('orders:write')).toBe(true);
  });

  it('hasPerm matches an exact code', () => {
    useAuth.setState({ permissions: ['orders:read', 'menu:read'] });
    expect(useAuth.getState().hasPerm('orders:read')).toBe(true);
    expect(useAuth.getState().hasPerm('orders:write')).toBe(false);
  });

  it('logout clears tokens and user', () => {
    useAuth.setState({ accessToken: 'tok', user: { id: '1' } });
    useAuth.getState().logout();
    expect(useAuth.getState().accessToken).toBeNull();
    expect(useAuth.getState().user).toBeNull();
  });
});
