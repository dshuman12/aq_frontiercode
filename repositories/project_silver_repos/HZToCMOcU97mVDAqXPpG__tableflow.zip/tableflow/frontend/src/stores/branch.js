import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export const useBranchStore = create(
  persist(
    (set) => ({
      branches: [],
      activeBranchId: null,
      setBranches: (branches) => set({ branches }),
      setActiveBranch: (id) => set({ activeBranchId: id }),
    }),
    { name: 'tableflow.branch' },
  ),
);
