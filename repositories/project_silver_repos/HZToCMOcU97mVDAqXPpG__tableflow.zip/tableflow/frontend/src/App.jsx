import { Routes, Route, Navigate } from 'react-router-dom';
import { Layout } from './components/Layout';
import { Protected } from './components/Protected';

import { LoginPage } from './pages/auth/LoginPage';
import { OnboardingPage } from './pages/auth/OnboardingPage';
import { ResetPasswordPage } from './pages/auth/ResetPasswordPage';

import { DashboardPage } from './pages/DashboardPage';
import { FloorPage } from './pages/FloorPage';
import { CalendarPage } from './pages/CalendarPage';
import { OrdersPage } from './pages/OrdersPage';
import { POSPage } from './pages/POSPage';
import { KitchenPage } from './pages/KitchenPage';
import { MenuPage } from './pages/MenuPage';
import { ModifiersPage } from './pages/ModifiersPage';
import { CustomersPage } from './pages/CustomersPage';
import { LoyaltyPage } from './pages/LoyaltyPage';
import { CouponsPage } from './pages/CouponsPage';
import { StaffPage } from './pages/StaffPage';
import { InventoryPage } from './pages/InventoryPage';
import { SuppliersPage } from './pages/SuppliersPage';
import { PurchasingPage } from './pages/PurchasingPage';
import { DeliveryPage } from './pages/DeliveryPage';
import { PaymentsPage } from './pages/PaymentsPage';
import { CloseoutsPage } from './pages/CloseoutsPage';
import { ReportsPage } from './pages/ReportsPage';
import { BranchesPage } from './pages/admin/BranchesPage';
import { RolesPage } from './pages/admin/RolesPage';
import { AuditPage } from './pages/admin/AuditPage';
import { ApiKeysPage } from './pages/admin/ApiKeysPage';
import { WebhooksPage } from './pages/admin/WebhooksPage';
import { ProfilePage } from './pages/ProfilePage';

export function App() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/onboarding" element={<OnboardingPage />} />
      <Route path="/reset-password" element={<ResetPasswordPage />} />
      <Route element={<Protected><Layout /></Protected>}>
        <Route index element={<DashboardPage />} />
        <Route path="floor" element={<FloorPage />} />
        <Route path="calendar" element={<CalendarPage />} />
        <Route path="orders" element={<OrdersPage />} />
        <Route path="orders/new" element={<POSPage />} />
        <Route path="orders/:id" element={<POSPage />} />
        <Route path="kitchen" element={<KitchenPage />} />
        <Route path="menu" element={<MenuPage />} />
        <Route path="modifiers" element={<ModifiersPage />} />
        <Route path="customers" element={<CustomersPage />} />
        <Route path="loyalty" element={<LoyaltyPage />} />
        <Route path="coupons" element={<CouponsPage />} />
        <Route path="staff" element={<StaffPage />} />
        <Route path="inventory" element={<InventoryPage />} />
        <Route path="suppliers" element={<SuppliersPage />} />
        <Route path="purchasing" element={<PurchasingPage />} />
        <Route path="delivery" element={<DeliveryPage />} />
        <Route path="payments" element={<PaymentsPage />} />
        <Route path="closeouts" element={<CloseoutsPage />} />
        <Route path="reports" element={<ReportsPage />} />
        <Route path="admin/branches" element={<BranchesPage />} />
        <Route path="admin/roles" element={<RolesPage />} />
        <Route path="admin/audit" element={<AuditPage />} />
        <Route path="admin/api-keys" element={<ApiKeysPage />} />
        <Route path="admin/webhooks" element={<WebhooksPage />} />
        <Route path="profile" element={<ProfilePage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  );
}
