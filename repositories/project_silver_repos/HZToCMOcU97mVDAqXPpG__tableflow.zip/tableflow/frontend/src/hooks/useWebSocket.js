import { useEffect, useRef } from 'react';

export function useWebSocket(url, onMessage, deps = []) {
  const wsRef = useRef(null);

  useEffect(() => {
    if (!url) return undefined;
    const ws = new WebSocket(url);
    wsRef.current = ws;
    ws.onmessage = (e) => {
      try {
        onMessage(JSON.parse(e.data));
      } catch {
        onMessage(e.data);
      }
    };
    return () => ws.close();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [url, ...deps]);

  return wsRef;
}
