import { expect, test } from '@playwright/test';

const PORTAL = 'http://localhost:5174';

test.describe('Customer portal', () => {
  test('home page hero shows order CTAs', async ({ page }) => {
    await page.goto(PORTAL + '/');
    await expect(page.getByText(/Order online, dine in/)).toBeVisible();
    await expect(page.getByRole('link', { name: 'Order online' })).toBeVisible();
    await expect(page.getByRole('link', { name: 'Reserve a table' })).toBeVisible();
  });

  test('menu page lets you add items to cart', async ({ page }) => {
    await page.goto(PORTAL + '/menu');
    await page.getByRole('button', { name: 'Add' }).first().click();
    await expect(page.locator('text=1')).toBeVisible();
  });

  test('cart page shows the running subtotal', async ({ page }) => {
    await page.goto(PORTAL + '/menu');
    await page.getByRole('button', { name: 'Add' }).first().click();
    await page.getByRole('link', { name: /Go to cart/ }).click();
    await expect(page.getByText('Subtotal')).toBeVisible();
  });

  test('reserve page accepts party size + datetime', async ({ page }) => {
    await page.goto(PORTAL + '/reserve');
    await expect(page.getByRole('heading', { name: 'Reserve a table' })).toBeVisible();
    await expect(page.locator('input[type=datetime-local]')).toBeVisible();
  });
});
