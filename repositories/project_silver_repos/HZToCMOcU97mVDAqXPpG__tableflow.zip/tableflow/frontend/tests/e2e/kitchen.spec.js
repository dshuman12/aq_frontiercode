import { expect, test } from '@playwright/test';
import { signIn } from './helpers';

test.beforeEach(async ({ page }) => signIn(page));

test('kitchen page renders', async ({ page }) => {
  await page.goto('/kitchen');
  await expect(page.getByRole('heading', { name: /Kitchen/ })).toBeVisible();
});

test('reservations calendar paginates dates', async ({ page }) => {
  await page.goto('/calendar');
  await expect(page.getByRole('heading', { name: 'Reservations' })).toBeVisible();
  await page.getByRole('button', { name: 'Today' }).click();
  await expect(page).toHaveURL(/\/calendar/);
});

test('reports dashboard shows last 30 days', async ({ page }) => {
  await page.goto('/reports');
  await expect(page.getByText('Last 30 days')).toBeVisible();
});
