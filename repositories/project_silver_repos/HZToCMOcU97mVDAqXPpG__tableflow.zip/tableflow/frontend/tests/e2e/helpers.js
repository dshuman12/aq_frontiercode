/**
 * Sign in via the API and persist the resulting auth state to localStorage so
 * the SPA boots authenticated. Falls back to clicking through the form if the
 * API isn't reachable.
 */
export async function signIn(page, { email = 'owner@demo.test', password = 'demo-password-12' } = {}) {
  const ctx = page.context();
  const res = await ctx.request.post('http://localhost:8000/api/auth/login', {
    data: { email, password },
    failOnStatusCode: false,
  });
  if (!res.ok()) {
    await page.goto('/login');
    await page.fill('input[type=email]', email);
    await page.fill('input[type=password]', password);
    await page.getByRole('button', { name: 'Sign in' }).click();
    return;
  }
  const body = await res.json();
  await page.addInitScript((auth) => {
    localStorage.setItem('tableflow.auth', JSON.stringify({
      state: {
        accessToken: auth.access_token,
        refreshToken: auth.refresh_token,
        user: auth.user,
        permissions: auth.permissions || [],
      },
      version: 0,
    }));
  }, body);
  await page.goto('/');
}
