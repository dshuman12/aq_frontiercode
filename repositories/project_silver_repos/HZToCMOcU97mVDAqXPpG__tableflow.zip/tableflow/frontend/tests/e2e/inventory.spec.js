import { expect, test } from '@playwright/test';
import { signIn } from './helpers';

test.beforeEach(async ({ page }) => signIn(page));

test('inventory page lists ingredients', async ({ page }) => {
  await page.goto('/inventory');
  await expect(page.getByRole('heading', { name: 'Inventory' })).toBeVisible();
  await expect(page.getByRole('button', { name: 'New ingredient' })).toBeVisible();
});

test('clicking a row opens the adjust modal', async ({ page }) => {
  await page.goto('/inventory');
  const firstRow = page.locator('table tbody tr').first();
  if (await firstRow.count()) {
    await firstRow.click();
    await expect(page.getByText('Adjust on-hand')).toBeVisible();
  }
});

test('suppliers page is reachable', async ({ page }) => {
  await page.goto('/suppliers');
  await expect(page.getByRole('heading', { name: 'Suppliers' })).toBeVisible();
});

test('purchasing page is reachable', async ({ page }) => {
  await page.goto('/purchasing');
  await expect(page.getByRole('heading', { name: 'Purchasing' })).toBeVisible();
});
