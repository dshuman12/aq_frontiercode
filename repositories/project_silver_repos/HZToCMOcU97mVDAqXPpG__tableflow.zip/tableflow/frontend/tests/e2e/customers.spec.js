import { expect, test } from '@playwright/test';
import { signIn } from './helpers';

test.beforeEach(async ({ page }) => signIn(page));

test('customers page renders the search box', async ({ page }) => {
  await page.goto('/customers');
  await expect(page.getByRole('heading', { name: 'Customers' })).toBeVisible();
  await expect(page.getByPlaceholder(/Search by/)).toBeVisible();
});

test('loyalty page lists members', async ({ page }) => {
  await page.goto('/loyalty');
  await expect(page.getByRole('heading', { name: 'Loyalty' })).toBeVisible();
  await expect(page.getByText('Top members')).toBeVisible();
});

test('coupons page opens new-coupon drawer', async ({ page }) => {
  await page.goto('/coupons');
  await page.getByRole('button', { name: 'New coupon' }).click();
  await expect(page.getByLabel('Code')).toBeVisible();
});
