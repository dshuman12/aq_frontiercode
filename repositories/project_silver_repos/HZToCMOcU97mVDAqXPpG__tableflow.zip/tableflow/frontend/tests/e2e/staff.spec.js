import { expect, test } from '@playwright/test';
import { signIn } from './helpers';

test.beforeEach(async ({ page }) => signIn(page));

test('staff page lists team members', async ({ page }) => {
  await page.goto('/staff');
  await expect(page.getByRole('heading', { name: 'Staff' })).toBeVisible();
  await expect(page.getByRole('button', { name: 'Invite member' })).toBeVisible();
});

test('invite member opens with role picker', async ({ page }) => {
  await page.goto('/staff');
  await page.getByRole('button', { name: 'Invite member' }).click();
  await expect(page.getByLabel('Email')).toBeVisible();
  await expect(page.getByLabel('Role ID')).toBeVisible();
});

test('profile page has the security tab', async ({ page }) => {
  await page.goto('/profile');
  await page.getByRole('button', { name: 'security' }).click();
  await expect(page.getByText('Change password')).toBeVisible();
});
