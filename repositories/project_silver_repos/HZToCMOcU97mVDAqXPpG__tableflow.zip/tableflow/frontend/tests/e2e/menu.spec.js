import { expect, test } from '@playwright/test';
import { signIn } from './helpers';

test.beforeEach(async ({ page }) => signIn(page));

test('menu page lists items', async ({ page }) => {
  await page.goto('/menu');
  await expect(page.getByRole('heading', { name: 'Menu' })).toBeVisible();
  await expect(page.getByRole('button', { name: 'New item' })).toBeVisible();
});

test('opens the new-item drawer', async ({ page }) => {
  await page.goto('/menu');
  await page.getByRole('button', { name: 'New item' }).click();
  await expect(page.getByLabel('Name')).toBeVisible();
  await expect(page.getByLabel('Category ID')).toBeVisible();
});

test('modifiers page is reachable', async ({ page }) => {
  await page.goto('/modifiers');
  await expect(page.getByRole('heading', { name: 'Modifiers' })).toBeVisible();
});
