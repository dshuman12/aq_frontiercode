import { expect, test } from '@playwright/test';
import { signIn } from './helpers';

test.beforeEach(async ({ page }) => signIn(page));

test('orders list page renders', async ({ page }) => {
  await page.goto('/orders');
  await expect(page.getByRole('heading', { name: 'Orders' })).toBeVisible();
  await expect(page.getByText('All')).toBeVisible();
  await expect(page.getByText('Open')).toBeVisible();
});

test('switching tabs filters the table', async ({ page }) => {
  await page.goto('/orders');
  await page.getByText('Open').click();
  await page.getByText('Today').click();
  await expect(page.getByRole('heading', { name: 'Orders' })).toBeVisible();
});

test('search input is debounced', async ({ page }) => {
  await page.goto('/orders');
  await page.locator('input[placeholder*="Search"]').fill('ORD-AB');
  await page.waitForTimeout(400);
  await expect(page).toHaveURL(/\/orders/);
});
