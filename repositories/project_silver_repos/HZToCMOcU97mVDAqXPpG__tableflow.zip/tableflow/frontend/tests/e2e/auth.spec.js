import { expect, test } from '@playwright/test';

test('redirects unauthenticated visits to /login', async ({ page }) => {
  await page.goto('/');
  await expect(page).toHaveURL(/\/login/);
  await expect(page.getByText('Sign in to TableFlow')).toBeVisible();
});

test('shows the email + password form', async ({ page }) => {
  await page.goto('/login');
  await expect(page.locator('input[type=email]')).toBeVisible();
  await expect(page.locator('input[type=password]')).toBeVisible();
  await expect(page.getByRole('button', { name: 'Sign in' })).toBeVisible();
});

test('forgot password link is reachable', async ({ page }) => {
  await page.goto('/login');
  await page.getByText('Forgot password?').click();
  await expect(page).toHaveURL(/reset-password/);
});
