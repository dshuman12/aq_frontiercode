import { expect, test } from '@playwright/test';
import { signIn } from './helpers';

test.beforeEach(async ({ page }) => signIn(page));

test('payments page shows the transactions table', async ({ page }) => {
  await page.goto('/payments');
  await expect(page.getByRole('heading', { name: 'Payments' })).toBeVisible();
});

test('closeouts page lets you close today', async ({ page }) => {
  await page.goto('/closeouts');
  await page.getByRole('button', { name: 'Close today' }).click();
  await expect(page.getByLabel('Branch ID')).toBeVisible();
});

test('delivery page lists active deliveries', async ({ page }) => {
  await page.goto('/delivery');
  await expect(page.getByRole('heading', { name: 'Delivery' })).toBeVisible();
});
