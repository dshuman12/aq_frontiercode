import { expect, test } from '@playwright/test';
import { signIn } from './helpers';

test.beforeEach(async ({ page }) => {
  await signIn(page);
});

test('floor page renders the table grid', async ({ page }) => {
  await page.goto('/floor');
  await expect(page.getByText(/Floor/)).toBeVisible();
});

test('clicking a table opens the transition modal', async ({ page }) => {
  await page.goto('/floor');
  const firstTable = page.locator('button[class*=rounded-xl]').first();
  if (await firstTable.count()) {
    await firstTable.click();
    await expect(page.getByText('Status:')).toBeVisible();
  }
});
