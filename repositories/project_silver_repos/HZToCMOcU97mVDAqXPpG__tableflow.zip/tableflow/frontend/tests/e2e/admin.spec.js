import { expect, test } from '@playwright/test';
import { signIn } from './helpers';

test.beforeEach(async ({ page }) => signIn(page));

test('audit log filters by resource', async ({ page }) => {
  await page.goto('/admin/audit');
  await expect(page.getByRole('heading', { name: 'Audit log' })).toBeVisible();
  await page.getByPlaceholder(/order, payment/).fill('order');
  await page.waitForTimeout(300);
});

test('api keys page lists keys', async ({ page }) => {
  await page.goto('/admin/api-keys');
  await expect(page.getByRole('heading', { name: 'API keys' })).toBeVisible();
  await expect(page.getByRole('button', { name: 'Create key' })).toBeVisible();
});

test('webhooks page is reachable', async ({ page }) => {
  await page.goto('/admin/webhooks');
  await expect(page.getByRole('heading', { name: 'Webhooks' })).toBeVisible();
});

test('roles page shows the catalog drawer', async ({ page }) => {
  await page.goto('/admin/roles');
  await page.getByRole('button', { name: 'New role' }).click();
  await expect(page.getByLabel('Name')).toBeVisible();
});
