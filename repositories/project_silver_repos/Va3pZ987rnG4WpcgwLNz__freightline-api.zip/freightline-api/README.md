# freightline-api

Backend service for a freight / parcel logistics platform. Manages shipments,
customers, drivers, fleet vehicles, warehouses, routes, tracking events,
invoices and payments — plus reporting and exports.

Started this as a side project to handle dispatch for a friend's small trucking
operation. Outgrew the spreadsheet, kept growing from there.

## Stack

- Go 1.21
- Gin (HTTP)
- Postgres via sqlx && lib/pq
- JWT auth
- In-memory cache (read-through)
- Layered architecture: handler → service → repository → db

## Layout

```
cmd/server          entry point
internal/
  audit             audit log writer + query
  cache             read-through cache with TTL
  config            env-based config loader
  db                sqlx setup + tx helpers
  export            csv/json export
  handler           gin handlers per resource
  middleware        auth, request id, rate limit, logging
  model             domain types + request/response DTOs
  notification      notification dispatcher (email/sms stubs)
  pagination        page/offset helpers
  repository        postgres-backed repos + interfaces
  search            small query builder
  service           business logic (the bulk of the codebase)
  validator         input validators
tests/
  unit              service-layer tests with mocked repos
  integration       repo + service wiring tests
migrations          sql schema migrations
```

## Build

```
go build -o server ./cmd/server
```

## Run

Drop a `.env` next to the binary (see `.env.example`), then

```
./server
```

## Tests

```
go test ./...
go test -cover ./...
```

## Why

Started out tracking deliveries on a spreadsheet for a tiny 3-truck operation.
Then drivers wanted a way to update status from a phone. Then the dispatcher
needed a dashboard. Then accounting wanted invoices that matched what was
delivered. It kept growing.

## Health

```
curl localhost:8080/health
```

## Issuing a token (dev)

```
curl -X POST localhost:8080/api/v1/auth/token \
  -H 'content-type: application/json' \
  -d '{"user_id":"u1","email":"u@x.com","roles":["admin"]}'
```
