-- shipments, tracking events, routes, invoices, payments
-- this is the second batch. ran 2022-08-15

CREATE TABLE IF NOT EXISTS shipments (
    id                     UUID PRIMARY KEY,
    tracking_number        TEXT NOT NULL UNIQUE,
    customer_id            UUID NOT NULL REFERENCES customers(id) ON DELETE RESTRICT,
    origin_warehouse_id    UUID REFERENCES warehouses(id) ON DELETE SET NULL,
    dest_warehouse_id      UUID REFERENCES warehouses(id) ON DELETE SET NULL,
    assigned_driver_id     UUID REFERENCES drivers(id) ON DELETE SET NULL,
    assigned_vehicle_id    UUID REFERENCES vehicles(id) ON DELETE SET NULL,
    route_id               UUID,
    carrier_id             UUID REFERENCES carriers(id) ON DELETE SET NULL,
    invoice_id             UUID,
    pickup_name            TEXT NOT NULL,
    pickup_phone           TEXT,
    pickup_address         TEXT NOT NULL,
    pickup_city            TEXT NOT NULL,
    pickup_state           TEXT,
    pickup_zip             TEXT,
    pickup_country         TEXT,
    delivery_name          TEXT NOT NULL,
    delivery_phone         TEXT,
    delivery_address       TEXT NOT NULL,
    delivery_city          TEXT NOT NULL,
    delivery_state         TEXT,
    delivery_zip           TEXT,
    delivery_country       TEXT,
    status                 TEXT NOT NULL DEFAULT 'booked',
    service_level          TEXT NOT NULL DEFAULT 'standard',
    weight_kg              NUMERIC(12,3) NOT NULL,
    volume_m3              NUMERIC(10,3) NOT NULL DEFAULT 0,
    pieces                 INT NOT NULL DEFAULT 1,
    declared_value         NUMERIC(14,2) NOT NULL DEFAULT 0,
    base_rate              NUMERIC(12,2) NOT NULL DEFAULT 0,
    fuel_surcharge         NUMERIC(12,2) NOT NULL DEFAULT 0,
    insurance_fee          NUMERIC(12,2) NOT NULL DEFAULT 0,
    handling_fee           NUMERIC(12,2) NOT NULL DEFAULT 0,
    total_charge           NUMERIC(14,2) NOT NULL DEFAULT 0,
    is_fragile             BOOLEAN NOT NULL DEFAULT FALSE,
    is_hazmat              BOOLEAN NOT NULL DEFAULT FALSE,
    requires_refrigeration BOOLEAN NOT NULL DEFAULT FALSE,
    requires_signature     BOOLEAN NOT NULL DEFAULT FALSE,
    special_instructions   TEXT,
    scheduled_pickup       TIMESTAMPTZ,
    actual_pickup          TIMESTAMPTZ,
    scheduled_delivery     TIMESTAMPTZ,
    actual_delivery        TIMESTAMPTZ,
    created_at             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at             TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_shipments_status        ON shipments (status);
CREATE INDEX IF NOT EXISTS idx_shipments_customer      ON shipments (customer_id);
CREATE INDEX IF NOT EXISTS idx_shipments_driver        ON shipments (assigned_driver_id);
CREATE INDEX IF NOT EXISTS idx_shipments_vehicle       ON shipments (assigned_vehicle_id);
CREATE INDEX IF NOT EXISTS idx_shipments_tracking      ON shipments (tracking_number);
CREATE INDEX IF NOT EXISTS idx_shipments_scheduled_dlv ON shipments (scheduled_delivery);

CREATE TABLE IF NOT EXISTS tracking_events (
    id           UUID PRIMARY KEY,
    shipment_id  UUID NOT NULL REFERENCES shipments(id) ON DELETE CASCADE,
    event_type   TEXT NOT NULL,
    status       TEXT,
    description  TEXT,
    location     TEXT,
    city         TEXT,
    state        TEXT,
    country      TEXT,
    latitude     DOUBLE PRECISION DEFAULT 0,
    longitude    DOUBLE PRECISION DEFAULT 0,
    actor_id     TEXT,
    driver_id    UUID REFERENCES drivers(id) ON DELETE SET NULL,
    vehicle_id   UUID REFERENCES vehicles(id) ON DELETE SET NULL,
    warehouse_id UUID REFERENCES warehouses(id) ON DELETE SET NULL,
    occurred_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_tracking_shipment    ON tracking_events (shipment_id, occurred_at);
CREATE INDEX IF NOT EXISTS idx_tracking_event_type  ON tracking_events (event_type);

CREATE TABLE IF NOT EXISTS routes (
    id                     UUID PRIMARY KEY,
    code                   TEXT NOT NULL UNIQUE,
    name                   TEXT NOT NULL,
    driver_id              UUID REFERENCES drivers(id) ON DELETE SET NULL,
    vehicle_id             UUID REFERENCES vehicles(id) ON DELETE SET NULL,
    origin_warehouse_id    UUID REFERENCES warehouses(id) ON DELETE SET NULL,
    status                 TEXT NOT NULL DEFAULT 'planned',
    planned_distance_km    NUMERIC(12,2) NOT NULL DEFAULT 0,
    actual_distance_km     NUMERIC(12,2) NOT NULL DEFAULT 0,
    planned_duration_hours NUMERIC(8,2) NOT NULL DEFAULT 0,
    actual_duration_hours  NUMERIC(8,2) NOT NULL DEFAULT 0,
    stop_count             INT NOT NULL DEFAULT 0,
    completed_stops        INT NOT NULL DEFAULT 0,
    scheduled_start        TIMESTAMPTZ NOT NULL,
    scheduled_end          TIMESTAMPTZ,
    actual_start           TIMESTAMPTZ,
    actual_end             TIMESTAMPTZ,
    fuel_cost              NUMERIC(12,2) NOT NULL DEFAULT 0,
    toll_cost              NUMERIC(12,2) NOT NULL DEFAULT 0,
    notes                  TEXT,
    created_at             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at             TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS route_stops (
    id          UUID PRIMARY KEY,
    route_id    UUID NOT NULL REFERENCES routes(id) ON DELETE CASCADE,
    shipment_id UUID NOT NULL REFERENCES shipments(id) ON DELETE CASCADE,
    stop_order  INT NOT NULL,
    stop_type   TEXT NOT NULL DEFAULT 'delivery',
    address     TEXT,
    city        TEXT,
    state       TEXT,
    latitude    DOUBLE PRECISION DEFAULT 0,
    longitude   DOUBLE PRECISION DEFAULT 0,
    planned_eta TIMESTAMPTZ,
    actual_eta  TIMESTAMPTZ,
    completed   BOOLEAN NOT NULL DEFAULT FALSE,
    notes       TEXT
);

CREATE INDEX IF NOT EXISTS idx_route_stops_route ON route_stops (route_id, stop_order);

CREATE TABLE IF NOT EXISTS invoices (
    id              UUID PRIMARY KEY,
    invoice_number  TEXT NOT NULL UNIQUE,
    customer_id     UUID NOT NULL REFERENCES customers(id) ON DELETE RESTRICT,
    status          TEXT NOT NULL DEFAULT 'issued',
    issued_date     TIMESTAMPTZ NOT NULL,
    due_date        TIMESTAMPTZ NOT NULL,
    subtotal        NUMERIC(14,2) NOT NULL DEFAULT 0,
    tax_amount      NUMERIC(14,2) NOT NULL DEFAULT 0,
    discount_amount NUMERIC(14,2) NOT NULL DEFAULT 0,
    total           NUMERIC(14,2) NOT NULL DEFAULT 0,
    amount_paid     NUMERIC(14,2) NOT NULL DEFAULT 0,
    balance_due     NUMERIC(14,2) NOT NULL DEFAULT 0,
    currency        TEXT NOT NULL DEFAULT 'USD',
    payment_terms   INT NOT NULL DEFAULT 30,
    notes           TEXT,
    billing_address TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_invoices_customer ON invoices (customer_id);
CREATE INDEX IF NOT EXISTS idx_invoices_status   ON invoices (status);
CREATE INDEX IF NOT EXISTS idx_invoices_due_date ON invoices (due_date);

CREATE TABLE IF NOT EXISTS invoice_line_items (
    id          UUID PRIMARY KEY,
    invoice_id  UUID NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
    shipment_id UUID REFERENCES shipments(id) ON DELETE SET NULL,
    description TEXT NOT NULL,
    quantity    NUMERIC(12,3) NOT NULL,
    unit_price  NUMERIC(14,4) NOT NULL,
    discount    NUMERIC(6,3) NOT NULL DEFAULT 0,
    tax_rate    NUMERIC(6,3) NOT NULL DEFAULT 0,
    line_total  NUMERIC(14,2) NOT NULL DEFAULT 0,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_inv_lines_invoice ON invoice_line_items (invoice_id);

CREATE TABLE IF NOT EXISTS payments (
    id             UUID PRIMARY KEY,
    reference_no   TEXT NOT NULL UNIQUE,
    invoice_id     UUID NOT NULL REFERENCES invoices(id) ON DELETE RESTRICT,
    customer_id    UUID NOT NULL REFERENCES customers(id) ON DELETE RESTRICT,
    method         TEXT NOT NULL,
    status         TEXT NOT NULL DEFAULT 'pending',
    amount         NUMERIC(14,2) NOT NULL,
    currency       TEXT NOT NULL DEFAULT 'USD',
    payment_date   TIMESTAMPTZ NOT NULL,
    cleared_date   TIMESTAMPTZ,
    processor_ref  TEXT,
    bank_reference TEXT,
    notes          TEXT,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_payments_invoice  ON payments (invoice_id);
CREATE INDEX IF NOT EXISTS idx_payments_customer ON payments (customer_id);
CREATE INDEX IF NOT EXISTS idx_payments_status   ON payments (status);
