-- initial schema for freightline-api
-- ran this by hand against the dev db on 2022-06-01

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE IF NOT EXISTS customers (
    id              UUID PRIMARY KEY,
    company_name    TEXT NOT NULL,
    contact_name    TEXT NOT NULL,
    email           TEXT NOT NULL UNIQUE,
    phone           TEXT,
    type            TEXT NOT NULL,
    tax_id          TEXT,
    billing_address TEXT,
    billing_city    TEXT,
    billing_state   TEXT,
    billing_zip     TEXT,
    billing_country TEXT,
    credit_limit    NUMERIC(14,2) NOT NULL DEFAULT 0,
    outstanding_bal NUMERIC(14,2) NOT NULL DEFAULT 0,
    payment_terms   INT NOT NULL DEFAULT 30,
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    notes           TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_customers_email   ON customers (LOWER(email));
CREATE INDEX IF NOT EXISTS idx_customers_active  ON customers (is_active);
CREATE INDEX IF NOT EXISTS idx_customers_city    ON customers (billing_city);
CREATE INDEX IF NOT EXISTS idx_customers_type    ON customers (type);

CREATE TABLE IF NOT EXISTS drivers (
    id                 UUID PRIMARY KEY,
    employee_code      TEXT NOT NULL UNIQUE,
    first_name         TEXT NOT NULL,
    last_name          TEXT NOT NULL,
    email              TEXT NOT NULL UNIQUE,
    phone              TEXT,
    license_number     TEXT NOT NULL,
    license_class      TEXT NOT NULL,
    license_expiry     TIMESTAMPTZ,
    hire_date          TIMESTAMPTZ,
    date_of_birth      TIMESTAMPTZ,
    status             TEXT NOT NULL DEFAULT 'active',
    hourly_rate        NUMERIC(10,2) NOT NULL DEFAULT 0,
    per_mile_rate      NUMERIC(10,4) NOT NULL DEFAULT 0,
    home_address       TEXT,
    home_city          TEXT,
    home_state         TEXT,
    emergency_contact  TEXT,
    emergency_phone    TEXT,
    total_miles_driven NUMERIC(14,2) NOT NULL DEFAULT 0,
    total_deliveries   INT NOT NULL DEFAULT 0,
    incident_count     INT NOT NULL DEFAULT 0,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at         TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_drivers_status        ON drivers (status);
CREATE INDEX IF NOT EXISTS idx_drivers_license_class ON drivers (license_class);
CREATE INDEX IF NOT EXISTS idx_drivers_license_exp   ON drivers (license_expiry);

CREATE TABLE IF NOT EXISTS warehouses (
    id                 UUID PRIMARY KEY,
    code               TEXT NOT NULL UNIQUE,
    name               TEXT NOT NULL,
    type               TEXT NOT NULL,
    address            TEXT NOT NULL,
    city               TEXT NOT NULL,
    state              TEXT,
    zip_code           TEXT,
    country            TEXT,
    latitude           DOUBLE PRECISION DEFAULT 0,
    longitude          DOUBLE PRECISION DEFAULT 0,
    phone              TEXT,
    manager_name       TEXT,
    manager_email      TEXT,
    capacity_m3        NUMERIC(14,2) NOT NULL DEFAULT 0,
    used_capacity_m3   NUMERIC(14,2) NOT NULL DEFAULT 0,
    docks_count        INT NOT NULL DEFAULT 0,
    operating_hours    TEXT,
    has_cold_storage   BOOLEAN NOT NULL DEFAULT FALSE,
    has_hazmat_license BOOLEAN NOT NULL DEFAULT FALSE,
    is_active          BOOLEAN NOT NULL DEFAULT TRUE,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at         TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_warehouses_city   ON warehouses (city);
CREATE INDEX IF NOT EXISTS idx_warehouses_type   ON warehouses (type);
CREATE INDEX IF NOT EXISTS idx_warehouses_active ON warehouses (is_active);

CREATE TABLE IF NOT EXISTS vehicles (
    id                   UUID PRIMARY KEY,
    plate_number         TEXT NOT NULL UNIQUE,
    vin                  TEXT NOT NULL UNIQUE,
    make                 TEXT NOT NULL,
    model                TEXT NOT NULL,
    year                 INT NOT NULL,
    type                 TEXT NOT NULL,
    fuel_type            TEXT,
    capacity_kg          NUMERIC(12,2) NOT NULL DEFAULT 0,
    capacity_m3          NUMERIC(12,2) NOT NULL DEFAULT 0,
    odometer_km          NUMERIC(14,2) NOT NULL DEFAULT 0,
    fuel_efficiency      NUMERIC(8,3) NOT NULL DEFAULT 0,
    status               TEXT NOT NULL DEFAULT 'available',
    insurance_provider   TEXT,
    insurance_policy     TEXT,
    insurance_expiry     TIMESTAMPTZ,
    registration_expiry  TIMESTAMPTZ,
    last_service_date    TIMESTAMPTZ,
    next_service_date    TIMESTAMPTZ,
    next_service_km      NUMERIC(14,2) NOT NULL DEFAULT 0,
    home_warehouse_id    UUID REFERENCES warehouses(id) ON DELETE SET NULL,
    purchase_date        TIMESTAMPTZ,
    purchase_price       NUMERIC(14,2) NOT NULL DEFAULT 0,
    current_value        NUMERIC(14,2) NOT NULL DEFAULT 0,
    is_refrigerated      BOOLEAN NOT NULL DEFAULT FALSE,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at           TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_vehicles_status ON vehicles (status);
CREATE INDEX IF NOT EXISTS idx_vehicles_type   ON vehicles (type);

CREATE TABLE IF NOT EXISTS carriers (
    id                  UUID PRIMARY KEY,
    name                TEXT NOT NULL,
    code                TEXT NOT NULL UNIQUE,
    contact_name        TEXT,
    email               TEXT NOT NULL,
    phone               TEXT,
    address             TEXT,
    city                TEXT,
    state               TEXT,
    country             TEXT,
    service_area        TEXT,
    base_rate           NUMERIC(12,2) NOT NULL DEFAULT 0,
    per_kg_rate         NUMERIC(10,4) NOT NULL DEFAULT 0,
    per_km_rate         NUMERIC(10,4) NOT NULL DEFAULT 0,
    fuel_surcharge_rate NUMERIC(6,3) NOT NULL DEFAULT 0,
    insurance_policy    TEXT,
    insurance_coverage  NUMERIC(14,2) NOT NULL DEFAULT 0,
    tax_id              TEXT,
    on_time_rate        NUMERIC(6,3) NOT NULL DEFAULT 0,
    damage_rate         NUMERIC(6,3) NOT NULL DEFAULT 0,
    total_shipments     INT NOT NULL DEFAULT 0,
    rating              NUMERIC(3,2) NOT NULL DEFAULT 3.0,
    is_active           BOOLEAN NOT NULL DEFAULT TRUE,
    is_hazmat_certified BOOLEAN NOT NULL DEFAULT FALSE,
    notes               TEXT,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_carriers_active ON carriers (is_active);
CREATE INDEX IF NOT EXISTS idx_carriers_rating ON carriers (rating);
