package integration_test

import (
	"context"
	"testing"
	"time"

	"freightline.dev/api/internal/audit"
	"freightline.dev/api/internal/cache"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/service"
	"github.com/google/uuid"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

type fakeCustomerRepo struct{ mock.Mock }

func (m *fakeCustomerRepo) Create(ctx context.Context, c *model.Customer) (uuid.UUID, error) {
	args := m.Called(ctx, c)
	return args.Get(0).(uuid.UUID), args.Error(1)
}
func (m *fakeCustomerRepo) GetByID(ctx context.Context, id uuid.UUID) (*model.Customer, error) {
	args := m.Called(ctx, id)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*model.Customer), args.Error(1)
}
func (m *fakeCustomerRepo) GetByEmail(ctx context.Context, email string) (*model.Customer, error) {
	args := m.Called(ctx, email)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*model.Customer), args.Error(1)
}
func (m *fakeCustomerRepo) Update(ctx context.Context, id uuid.UUID, c *model.Customer) error {
	return m.Called(ctx, id, c).Error(0)
}
func (m *fakeCustomerRepo) Delete(ctx context.Context, id uuid.UUID) error {
	return m.Called(ctx, id).Error(0)
}
func (m *fakeCustomerRepo) List(ctx context.Context, f *model.CustomerFilter) ([]*model.Customer, int, error) {
	args := m.Called(ctx, f)
	return args.Get(0).([]*model.Customer), args.Int(1), args.Error(2)
}
func (m *fakeCustomerRepo) UpdateOutstandingBalance(ctx context.Context, id uuid.UUID, delta float64) error {
	return m.Called(ctx, id, delta).Error(0)
}
func (m *fakeCustomerRepo) SetActive(ctx context.Context, id uuid.UUID, active bool) error {
	return m.Called(ctx, id, active).Error(0)
}

func TestIntegration_CustomerCreateAndCharge(t *testing.T) {
	repo := new(fakeCustomerRepo)
	svc := service.NewCustomerService(repo, audit.NewMemoryLogger(100), cache.New(time.Minute, 100))

	repo.On("GetByEmail", mock.Anything, "j@x.com").Return(nil, model.ErrNotFound)
	createdID := uuid.New()
	repo.On("Create", mock.Anything, mock.AnythingOfType("*model.Customer")).Return(createdID, nil)

	id, err := svc.Create(context.Background(), model.CreateCustomerRequest{
		CompanyName: "Acme", ContactName: "Joe", Email: "j@x.com",
		Type: model.CustomerTypeBusiness, CreditLimit: 5000,
	}, "actor-1")
	assert.NoError(t, err)
	assert.Equal(t, createdID, id)

	repo.On("GetByID", mock.Anything, id).Return(&model.Customer{
		ID: id, IsActive: true, CreditLimit: 5000, OutstandingBal: 0,
	}, nil)
	repo.On("UpdateOutstandingBalance", mock.Anything, id, 1000.0).Return(nil)

	err = svc.ChargeBalance(context.Background(), id, 1000, "actor-1")
	assert.NoError(t, err)
}
