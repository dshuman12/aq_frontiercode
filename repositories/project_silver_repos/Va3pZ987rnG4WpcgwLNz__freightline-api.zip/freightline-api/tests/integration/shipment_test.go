package integration_test

import (
	"context"
	"testing"
	"time"

	"freightline.dev/api/internal/audit"
	"freightline.dev/api/internal/cache"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/service"
	"github.com/google/uuid"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)


type fakeShipmentRepo struct{ mock.Mock }

func (m *fakeShipmentRepo) Create(ctx context.Context, s *model.Shipment) (uuid.UUID, error) {
	a := m.Called(ctx, s)
	return a.Get(0).(uuid.UUID), a.Error(1)
}
func (m *fakeShipmentRepo) GetByID(ctx context.Context, id uuid.UUID) (*model.Shipment, error) {
	a := m.Called(ctx, id)
	if a.Get(0) == nil {
		return nil, a.Error(1)
	}
	return a.Get(0).(*model.Shipment), a.Error(1)
}
func (m *fakeShipmentRepo) GetByTrackingNumber(ctx context.Context, n string) (*model.Shipment, error) {
	a := m.Called(ctx, n)
	if a.Get(0) == nil {
		return nil, a.Error(1)
	}
	return a.Get(0).(*model.Shipment), a.Error(1)
}
func (m *fakeShipmentRepo) Update(ctx context.Context, id uuid.UUID, s *model.Shipment) error {
	return m.Called(ctx, id, s).Error(0)
}
func (m *fakeShipmentRepo) Delete(ctx context.Context, id uuid.UUID) error {
	return m.Called(ctx, id).Error(0)
}
func (m *fakeShipmentRepo) List(ctx context.Context, f *model.ShipmentFilter) ([]*model.Shipment, int, error) {
	a := m.Called(ctx, f)
	return a.Get(0).([]*model.Shipment), a.Int(1), a.Error(2)
}
func (m *fakeShipmentRepo) UpdateStatus(ctx context.Context, id uuid.UUID, s model.ShipmentStatus) error {
	return m.Called(ctx, id, s).Error(0)
}
func (m *fakeShipmentRepo) AssignDriver(ctx context.Context, id, drv uuid.UUID) error {
	return m.Called(ctx, id, drv).Error(0)
}
func (m *fakeShipmentRepo) AssignVehicle(ctx context.Context, id, veh uuid.UUID) error {
	return m.Called(ctx, id, veh).Error(0)
}
func (m *fakeShipmentRepo) AssignCarrier(ctx context.Context, id, c uuid.UUID) error {
	return m.Called(ctx, id, c).Error(0)
}
func (m *fakeShipmentRepo) AttachInvoice(ctx context.Context, id, inv uuid.UUID) error {
	return m.Called(ctx, id, inv).Error(0)
}
func (m *fakeShipmentRepo) ListByCustomer(ctx context.Context, c uuid.UUID, limit int) ([]*model.Shipment, error) {
	a := m.Called(ctx, c, limit)
	return a.Get(0).([]*model.Shipment), a.Error(1)
}
func (m *fakeShipmentRepo) ListByDriver(ctx context.Context, d uuid.UUID, limit int) ([]*model.Shipment, error) {
	a := m.Called(ctx, d, limit)
	return a.Get(0).([]*model.Shipment), a.Error(1)
}
func (m *fakeShipmentRepo) ListByVehicle(ctx context.Context, v uuid.UUID, limit int) ([]*model.Shipment, error) {
	a := m.Called(ctx, v, limit)
	return a.Get(0).([]*model.Shipment), a.Error(1)
}
func (m *fakeShipmentRepo) ListOverdue(ctx context.Context) ([]*model.Shipment, error) {
	a := m.Called(ctx)
	return a.Get(0).([]*model.Shipment), a.Error(1)
}
func (m *fakeShipmentRepo) CountByStatus(ctx context.Context) (map[model.ShipmentStatus]int, error) {
	a := m.Called(ctx)
	return a.Get(0).(map[model.ShipmentStatus]int), a.Error(1)
}

type fakeTrackingRepo struct{ mock.Mock }

func (m *fakeTrackingRepo) Create(ctx context.Context, e *model.TrackingEvent) (uuid.UUID, error) {
	a := m.Called(ctx, e)
	return a.Get(0).(uuid.UUID), a.Error(1)
}
func (m *fakeTrackingRepo) GetByID(ctx context.Context, id uuid.UUID) (*model.TrackingEvent, error) {
	return nil, model.ErrNotFound
}
func (m *fakeTrackingRepo) ListByShipment(ctx context.Context, id uuid.UUID) ([]*model.TrackingEvent, error) {
	a := m.Called(ctx, id)
	return a.Get(0).([]*model.TrackingEvent), a.Error(1)
}
func (m *fakeTrackingRepo) List(ctx context.Context, f *model.TrackingEventFilter) ([]*model.TrackingEvent, int, error) {
	return nil, 0, nil
}
func (m *fakeTrackingRepo) GetLatestForShipment(ctx context.Context, id uuid.UUID) (*model.TrackingEvent, error) {
	return nil, model.ErrNotFound
}

func TestIntegration_ShipmentCreateAndTrack(t *testing.T) {
	sr := new(fakeShipmentRepo)
	tr := new(fakeTrackingRepo)
	custID := uuid.New()
	custRepo := new(fakeCustomerRepo)
	custRepo.On("GetByID", mock.Anything, custID).Return(&model.Customer{
		ID: custID, IsActive: true,
	}, nil)

	svc := service.NewShipmentService(sr, tr, custRepo, nil, nil,
		audit.NewMemoryLogger(100), cache.New(time.Minute, 100))

	createdID := uuid.New()
	sr.On("Create", mock.Anything, mock.AnythingOfType("*model.Shipment")).Return(createdID, nil)
	tr.On("Create", mock.Anything, mock.AnythingOfType("*model.TrackingEvent")).Return(uuid.New(), nil)

	id, err := svc.Create(context.Background(), model.CreateShipmentRequest{
		CustomerID:      custID.String(),
		PickupName:      "Sender",
		PickupAddress:   "1 Pine",
		PickupCity:      "Reno",
		DeliveryName:    "Receiver",
		DeliveryAddress: "5 Oak",
		DeliveryCity:    "Phoenix",
		ServiceLevel:    model.ServiceLevelStandard,
		WeightKg:        25,
	}, "actor")
	assert.NoError(t, err)
	assert.Equal(t, createdID, id)

	sr.On("GetByID", mock.Anything, id).Return(&model.Shipment{
		ID: id, Status: model.ShipmentStatusBooked,
	}, nil)
	sr.On("UpdateStatus", mock.Anything, id, model.ShipmentStatusPickedUp).Return(nil)
	sr.On("Update", mock.Anything, id, mock.AnythingOfType("*model.Shipment")).Return(nil)

	err = svc.TransitionStatus(context.Background(), id, model.ShipmentStatusPickedUp, "Reno", "actor")
	assert.NoError(t, err)
}
