package integration_test

import (
	"context"
	"testing"
	"time"

	"freightline.dev/api/internal/audit"
	"freightline.dev/api/internal/cache"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/service"
	"github.com/google/uuid"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

type fakeVehicleRepo struct{ mock.Mock }

func (m *fakeVehicleRepo) Create(ctx context.Context, v *model.Vehicle) (uuid.UUID, error) {
	a := m.Called(ctx, v)
	return a.Get(0).(uuid.UUID), a.Error(1)
}
func (m *fakeVehicleRepo) GetByID(ctx context.Context, id uuid.UUID) (*model.Vehicle, error) {
	a := m.Called(ctx, id)
	if a.Get(0) == nil {
		return nil, a.Error(1)
	}
	return a.Get(0).(*model.Vehicle), a.Error(1)
}
func (m *fakeVehicleRepo) GetByPlate(ctx context.Context, p string) (*model.Vehicle, error) {
	a := m.Called(ctx, p)
	if a.Get(0) == nil {
		return nil, a.Error(1)
	}
	return a.Get(0).(*model.Vehicle), a.Error(1)
}
func (m *fakeVehicleRepo) GetByVIN(ctx context.Context, v string) (*model.Vehicle, error) {
	a := m.Called(ctx, v)
	if a.Get(0) == nil {
		return nil, a.Error(1)
	}
	return a.Get(0).(*model.Vehicle), a.Error(1)
}
func (m *fakeVehicleRepo) Update(ctx context.Context, id uuid.UUID, v *model.Vehicle) error {
	return m.Called(ctx, id, v).Error(0)
}
func (m *fakeVehicleRepo) Delete(ctx context.Context, id uuid.UUID) error {
	return m.Called(ctx, id).Error(0)
}
func (m *fakeVehicleRepo) List(ctx context.Context, f *model.VehicleFilter) ([]*model.Vehicle, int, error) {
	return nil, 0, nil
}
func (m *fakeVehicleRepo) UpdateStatus(ctx context.Context, id uuid.UUID, s model.VehicleStatus) error {
	return m.Called(ctx, id, s).Error(0)
}
func (m *fakeVehicleRepo) UpdateOdometer(ctx context.Context, id uuid.UUID, km float64) error {
	return m.Called(ctx, id, km).Error(0)
}
func (m *fakeVehicleRepo) ListAvailable(ctx context.Context) ([]*model.Vehicle, error) {
	a := m.Called(ctx)
	return a.Get(0).([]*model.Vehicle), a.Error(1)
}
func (m *fakeVehicleRepo) ListNeedingService(ctx context.Context) ([]*model.Vehicle, error) {
	return nil, nil
}

func TestIntegration_VehicleCreateAndTrip(t *testing.T) {
	repo := new(fakeVehicleRepo)
	svc := service.NewVehicleService(repo, audit.NewMemoryLogger(100), cache.New(time.Minute, 100))

	repo.On("GetByPlate", mock.Anything, "ABC-1234").Return(nil, model.ErrNotFound)
	repo.On("GetByVIN", mock.Anything, "1HGCM82633A123456").Return(nil, model.ErrNotFound)
	created := uuid.New()
	repo.On("Create", mock.Anything, mock.AnythingOfType("*model.Vehicle")).Return(created, nil)

	id, err := svc.Create(context.Background(), model.CreateVehicleRequest{
		PlateNumber: "ABC-1234", VIN: "1HGCM82633A123456",
		Make: "Volvo", Model: "FH16", Year: 2020,
		Type: model.VehicleTypeSemi, CapacityKg: 20000,
	}, "actor")
	assert.NoError(t, err)
	assert.Equal(t, created, id)

	repo.On("GetByID", mock.Anything, id).Return(&model.Vehicle{
		ID: id, OdometerKm: 1000, Status: model.VehicleStatusAvailable,
	}, nil)
	repo.On("UpdateOdometer", mock.Anything, id, 1300.0).Return(nil)
	err = svc.RecordTrip(context.Background(), id, 300, "actor")
	assert.NoError(t, err)
}
