package integration_test

import (
	"context"
	"testing"
	"time"

	"freightline.dev/api/internal/audit"
	"freightline.dev/api/internal/cache"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/service"
	"github.com/google/uuid"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

type fakeInvoiceRepo struct{ mock.Mock }

func (m *fakeInvoiceRepo) Create(ctx context.Context, inv *model.Invoice, lines []*model.InvoiceLineItem) (uuid.UUID, error) {
	a := m.Called(ctx, inv, lines)
	return a.Get(0).(uuid.UUID), a.Error(1)
}
func (m *fakeInvoiceRepo) GetByID(ctx context.Context, id uuid.UUID) (*model.Invoice, error) {
	a := m.Called(ctx, id)
	if a.Get(0) == nil {
		return nil, a.Error(1)
	}
	return a.Get(0).(*model.Invoice), a.Error(1)
}
func (m *fakeInvoiceRepo) GetWithLines(ctx context.Context, id uuid.UUID) (*model.InvoiceWithLines, error) {
	a := m.Called(ctx, id)
	if a.Get(0) == nil {
		return nil, a.Error(1)
	}
	return a.Get(0).(*model.InvoiceWithLines), a.Error(1)
}
func (m *fakeInvoiceRepo) GetByNumber(ctx context.Context, n string) (*model.Invoice, error) {
	return nil, model.ErrNotFound
}
func (m *fakeInvoiceRepo) Update(ctx context.Context, id uuid.UUID, inv *model.Invoice) error {
	return m.Called(ctx, id, inv).Error(0)
}
func (m *fakeInvoiceRepo) Delete(ctx context.Context, id uuid.UUID) error {
	return m.Called(ctx, id).Error(0)
}
func (m *fakeInvoiceRepo) List(ctx context.Context, f *model.InvoiceFilter) ([]*model.Invoice, int, error) {
	a := m.Called(ctx, f)
	return a.Get(0).([]*model.Invoice), a.Int(1), a.Error(2)
}
func (m *fakeInvoiceRepo) UpdateStatus(ctx context.Context, id uuid.UUID, s model.InvoiceStatus) error {
	return m.Called(ctx, id, s).Error(0)
}
func (m *fakeInvoiceRepo) ApplyPayment(ctx context.Context, id uuid.UUID, amt float64) error {
	return m.Called(ctx, id, amt).Error(0)
}
func (m *fakeInvoiceRepo) ListByCustomer(ctx context.Context, c uuid.UUID, l int) ([]*model.Invoice, error) {
	a := m.Called(ctx, c, l)
	return a.Get(0).([]*model.Invoice), a.Error(1)
}
func (m *fakeInvoiceRepo) ListOverdue(ctx context.Context) ([]*model.Invoice, error) {
	a := m.Called(ctx)
	return a.Get(0).([]*model.Invoice), a.Error(1)
}
func (m *fakeInvoiceRepo) SumOutstanding(ctx context.Context) (float64, error) {
	a := m.Called(ctx)
	return a.Get(0).(float64), a.Error(1)
}

func TestIntegration_InvoiceCreateAndVoid(t *testing.T) {
	ir := new(fakeInvoiceRepo)
	cr := new(fakeCustomerRepo)
	custID := uuid.New()
	cr.On("GetByID", mock.Anything, custID).Return(&model.Customer{
		ID: custID, CompanyName: "Acme", PaymentTerms: 30,
	}, nil)
	cr.On("UpdateOutstandingBalance", mock.Anything, custID, mock.Anything).Return(nil)
	ir.On("Create", mock.Anything, mock.AnythingOfType("*model.Invoice"), mock.AnythingOfType("[]*model.InvoiceLineItem")).Return(uuid.New(), nil)

	svc := service.NewInvoiceService(ir, nil, cr,
		audit.NewMemoryLogger(100), cache.New(time.Minute, 100))

	id, err := svc.Create(context.Background(), model.CreateInvoiceRequest{
		CustomerID: custID.String(),
		LineItems: []model.CreateInvoiceLineItemRequest{
			{Description: "Freight", Quantity: 1, UnitPrice: 200, TaxRate: 10},
		},
	}, "actor")
	assert.NoError(t, err)
	assert.NotEqual(t, uuid.Nil, id)

	ir.On("GetByID", mock.Anything, id).Return(&model.Invoice{
		ID: id, CustomerID: custID, Status: model.InvoiceStatusIssued, Total: 220,
	}, nil)
	ir.On("UpdateStatus", mock.Anything, id, model.InvoiceStatusVoided).Return(nil)
	err = svc.Void(context.Background(), id, "duplicate", "actor")
	assert.NoError(t, err)
}
