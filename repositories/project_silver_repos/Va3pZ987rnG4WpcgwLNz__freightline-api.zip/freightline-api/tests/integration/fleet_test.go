package integration_test

import (
	"context"
	"testing"
	"time"

	"freightline.dev/api/internal/audit"
	"freightline.dev/api/internal/cache"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/service"
	"github.com/google/uuid"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

type fakeDriverRepo struct{ mock.Mock }

func (m *fakeDriverRepo) Create(ctx context.Context, d *model.Driver) (uuid.UUID, error) {
	a := m.Called(ctx, d)
	return a.Get(0).(uuid.UUID), a.Error(1)
}
func (m *fakeDriverRepo) GetByID(ctx context.Context, id uuid.UUID) (*model.Driver, error) {
	a := m.Called(ctx, id)
	if a.Get(0) == nil {
		return nil, a.Error(1)
	}
	return a.Get(0).(*model.Driver), a.Error(1)
}
func (m *fakeDriverRepo) GetByEmployeeCode(ctx context.Context, code string) (*model.Driver, error) {
	a := m.Called(ctx, code)
	if a.Get(0) == nil {
		return nil, a.Error(1)
	}
	return a.Get(0).(*model.Driver), a.Error(1)
}
func (m *fakeDriverRepo) GetByEmail(ctx context.Context, e string) (*model.Driver, error) {
	a := m.Called(ctx, e)
	if a.Get(0) == nil {
		return nil, a.Error(1)
	}
	return a.Get(0).(*model.Driver), a.Error(1)
}
func (m *fakeDriverRepo) Update(ctx context.Context, id uuid.UUID, d *model.Driver) error {
	return m.Called(ctx, id, d).Error(0)
}
func (m *fakeDriverRepo) Delete(ctx context.Context, id uuid.UUID) error {
	return m.Called(ctx, id).Error(0)
}
func (m *fakeDriverRepo) List(ctx context.Context, f *model.DriverFilter) ([]*model.Driver, int, error) {
	a := m.Called(ctx, f)
	return a.Get(0).([]*model.Driver), a.Int(1), a.Error(2)
}
func (m *fakeDriverRepo) UpdateStatus(ctx context.Context, id uuid.UUID, s model.DriverStatus) error {
	return m.Called(ctx, id, s).Error(0)
}
func (m *fakeDriverRepo) IncrementDeliveries(ctx context.Context, id uuid.UUID, miles float64) error {
	return m.Called(ctx, id, miles).Error(0)
}
func (m *fakeDriverRepo) ListAvailable(ctx context.Context) ([]*model.Driver, error) {
	a := m.Called(ctx)
	return a.Get(0).([]*model.Driver), a.Error(1)
}
func (m *fakeDriverRepo) ListExpiringLicenses(ctx context.Context, days int) ([]*model.Driver, error) {
	a := m.Called(ctx, days)
	return a.Get(0).([]*model.Driver), a.Error(1)
}

func TestIntegration_DriverCreateAndAssign(t *testing.T) {
	repo := new(fakeDriverRepo)
	svc := service.NewDriverService(repo, audit.NewMemoryLogger(100), cache.New(time.Minute, 100))

	repo.On("GetByEmployeeCode", mock.Anything, "EMP100").Return(nil, model.ErrNotFound)
	repo.On("GetByEmail", mock.Anything, "jane@example.com").Return(nil, model.ErrNotFound)
	createdID := uuid.New()
	repo.On("Create", mock.Anything, mock.AnythingOfType("*model.Driver")).Return(createdID, nil)

	id, err := svc.Create(context.Background(), model.CreateDriverRequest{
		EmployeeCode: "EMP100", FirstName: "Jane", LastName: "Driver",
		Email: "jane@example.com", Phone: "5551234567",
		LicenseNumber: "DL1", LicenseClass: model.LicenseClassB,
		LicenseExpiry: "2030-01-01",
	}, "actor")
	assert.NoError(t, err)
	assert.Equal(t, createdID, id)

	repo.On("GetByID", mock.Anything, id).Return(&model.Driver{
		ID: id, Status: model.DriverStatusInactive,
		LicenseExpiry: time.Now().AddDate(1, 0, 0),
	}, nil)
	repo.On("UpdateStatus", mock.Anything, id, model.DriverStatusActive).Return(nil)
	err = svc.ChangeStatus(context.Background(), id, model.DriverStatusActive, "actor")
	assert.NoError(t, err)
}
