package integration_test

import (
	"context"
	"testing"
	"time"

	"freightline.dev/api/internal/audit"
	"freightline.dev/api/internal/cache"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/service"
	"github.com/google/uuid"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

type fakeRouteRepo struct{ mock.Mock }

func (m *fakeRouteRepo) Create(ctx context.Context, r *model.Route, stops []*model.RouteStop) (uuid.UUID, error) {
	a := m.Called(ctx, r, stops)
	return a.Get(0).(uuid.UUID), a.Error(1)
}
func (m *fakeRouteRepo) GetByID(ctx context.Context, id uuid.UUID) (*model.Route, error) {
	a := m.Called(ctx, id)
	if a.Get(0) == nil {
		return nil, a.Error(1)
	}
	return a.Get(0).(*model.Route), a.Error(1)
}
func (m *fakeRouteRepo) GetWithStops(ctx context.Context, id uuid.UUID) (*model.RouteWithStops, error) {
	return nil, model.ErrNotFound
}
func (m *fakeRouteRepo) Update(ctx context.Context, id uuid.UUID, r *model.Route) error {
	return m.Called(ctx, id, r).Error(0)
}
func (m *fakeRouteRepo) Delete(ctx context.Context, id uuid.UUID) error {
	return m.Called(ctx, id).Error(0)
}
func (m *fakeRouteRepo) List(ctx context.Context, f *model.RouteFilter) ([]*model.Route, int, error) {
	return nil, 0, nil
}
func (m *fakeRouteRepo) UpdateStatus(ctx context.Context, id uuid.UUID, s model.RouteStatus) error {
	return m.Called(ctx, id, s).Error(0)
}
func (m *fakeRouteRepo) CompleteStop(ctx context.Context, id uuid.UUID) error {
	return m.Called(ctx, id).Error(0)
}
func (m *fakeRouteRepo) ListByDriver(ctx context.Context, drv uuid.UUID, l int) ([]*model.Route, error) {
	return nil, nil
}

func TestIntegration_RouteLifecycle(t *testing.T) {
	rr := new(fakeRouteRepo)
	sr := new(fakeShipmentRepo)
	shipID := uuid.New()
	sr.On("GetByID", mock.Anything, shipID).Return(&model.Shipment{
		ID: shipID, DeliveryAddress: "1 Pine", DeliveryCity: "Reno",
	}, nil)

	svc := service.NewRouteService(rr, sr, nil, nil, audit.NewMemoryLogger(100), cache.New(time.Minute, 50))

	created := uuid.New()
	rr.On("Create", mock.Anything, mock.AnythingOfType("*model.Route"), mock.AnythingOfType("[]*model.RouteStop")).Return(created, nil)

	id, err := svc.Create(context.Background(), model.CreateRouteRequest{
		Name:           "Morning",
		ScheduledStart: time.Now().Format(time.RFC3339),
		ShipmentIDs:    []string{shipID.String()},
	}, "actor")
	assert.NoError(t, err)
	assert.Equal(t, created, id)

	rr.On("GetByID", mock.Anything, id).Return(&model.Route{ID: id, Status: model.RouteStatusPlanned}, nil)
	rr.On("UpdateStatus", mock.Anything, id, model.RouteStatusActive).Return(nil)
	err = svc.Start(context.Background(), id, "actor")
	assert.NoError(t, err)
}
