package unit_test

import (
	"context"
	"errors"
	"testing"
	"time"

	"freightline.dev/api/internal/audit"
	"freightline.dev/api/internal/cache"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/service"
	"github.com/google/uuid"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

func newCustomerSvc() (*service.CustomerService, *MockCustomerRepo) {
	repo := new(MockCustomerRepo)
	svc := service.NewCustomerService(repo, audit.NewMemoryLogger(100), cache.New(5*time.Minute, 100))
	return svc, repo
}

func TestCustomerService_Create_Success(t *testing.T) {
	svc, repo := newCustomerSvc()
	req := model.CreateCustomerRequest{
		CompanyName: "Acme", ContactName: "Joe",
		Email: "joe@acme.com", Phone: "+15551234567",
		Type: model.CustomerTypeBusiness, CreditLimit: 5000, PaymentTerms: 30,
	}
	repo.On("GetByEmail", mock.Anything, "joe@acme.com").Return(nil, model.ErrNotFound)
	repo.On("Create", mock.Anything, mock.AnythingOfType("*model.Customer")).Return(uuid.New(), nil)

	id, err := svc.Create(context.Background(), req, "actor")
	assert.NoError(t, err)
	assert.NotEqual(t, uuid.Nil, id)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestCustomerService_Create_DuplicateEmail(t *testing.T) {
	svc, repo := newCustomerSvc()
	req := model.CreateCustomerRequest{
		CompanyName: "Acme", ContactName: "J", Email: "j@x.com",
		Type: model.CustomerTypeBusiness,
	}
	repo.On("GetByEmail", mock.Anything, "j@x.com").Return(&model.Customer{ID: uuid.New()}, nil)
	_, err := svc.Create(context.Background(), req, "actor")
	assert.Error(t, err)
	assert.True(t, errors.Is(err, model.ErrDuplicate))
	repo.AssertExpectations(t)
}

func TestCustomerService_Create_EmptyCompany(t *testing.T) {
	svc, _ := newCustomerSvc()
	req := model.CreateCustomerRequest{
		ContactName: "Joe", Email: "j@x.com", Type: model.CustomerTypeBusiness,
	}
	_, err := svc.Create(context.Background(), req, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestCustomerService_Create_BadEmail(t *testing.T) {
	svc, _ := newCustomerSvc()
	req := model.CreateCustomerRequest{
		CompanyName: "A", ContactName: "J", Email: "bad", Type: model.CustomerTypeBusiness,
	}
	_, err := svc.Create(context.Background(), req, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestCustomerService_Create_BadType(t *testing.T) {
	svc, _ := newCustomerSvc()
	req := model.CreateCustomerRequest{
		CompanyName: "A", ContactName: "J", Email: "a@b.com",
		Type: model.CustomerType("wat"),
	}
	_, err := svc.Create(context.Background(), req, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestCustomerService_Create_NegativeCredit(t *testing.T) {
	svc, _ := newCustomerSvc()
	req := model.CreateCustomerRequest{
		CompanyName: "A", ContactName: "J", Email: "a@b.com",
		Type: model.CustomerTypeBusiness, CreditLimit: -100,
	}
	_, err := svc.Create(context.Background(), req, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestCustomerService_GetByID_Success(t *testing.T) {
	svc, repo := newCustomerSvc()
	id := uuid.New()
	c := &model.Customer{ID: id, CompanyName: "Acme", IsActive: true}
	repo.On("GetByID", mock.Anything, id).Return(c, nil)
	got, err := svc.GetByID(context.Background(), id)
	assert.NoError(t, err)
	assert.Equal(t, "Acme", got.CompanyName)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestCustomerService_GetByID_NilUUID(t *testing.T) {
	svc, _ := newCustomerSvc()
	_, err := svc.GetByID(context.Background(), uuid.Nil)
	assert.Error(t, err)
	assert.True(t, errors.Is(err, model.ErrInvalidInput))
	assert.NotNil(t, svc)
}

func TestCustomerService_GetByID_NotFound(t *testing.T) {
	svc, repo := newCustomerSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(nil, model.ErrNotFound)
	_, err := svc.GetByID(context.Background(), id)
	assert.Error(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestCustomerService_GetByID_Cached(t *testing.T) {
	svc, repo := newCustomerSvc()
	id := uuid.New()
	c := &model.Customer{ID: id, CompanyName: "Acme"}
	repo.On("GetByID", mock.Anything, id).Return(c, nil).Once()
	_, _ = svc.GetByID(context.Background(), id)
	got, err := svc.GetByID(context.Background(), id)
	assert.NoError(t, err)
	assert.Equal(t, "Acme", got.CompanyName)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestCustomerService_GetByEmail_Success(t *testing.T) {
	svc, repo := newCustomerSvc()
	c := &model.Customer{Email: "x@y.com"}
	repo.On("GetByEmail", mock.Anything, "x@y.com").Return(c, nil)
	got, err := svc.GetByEmail(context.Background(), "x@y.com")
	assert.NoError(t, err)
	assert.NotNil(t, got)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestCustomerService_GetByEmail_BadFormat(t *testing.T) {
	svc, _ := newCustomerSvc()
	_, err := svc.GetByEmail(context.Background(), "garbage")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestCustomerService_Update_Success(t *testing.T) {
	svc, repo := newCustomerSvc()
	id := uuid.New()
	existing := &model.Customer{ID: id, CompanyName: "Old"}
	repo.On("GetByID", mock.Anything, id).Return(existing, nil)
	repo.On("Update", mock.Anything, id, mock.AnythingOfType("*model.Customer")).Return(nil)
	err := svc.Update(context.Background(), id, model.UpdateCustomerRequest{CompanyName: "New"}, "actor")
	assert.NoError(t, err)
	assert.Equal(t, "New", existing.CompanyName)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestCustomerService_Update_NotFound(t *testing.T) {
	svc, repo := newCustomerSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(nil, model.ErrNotFound)
	err := svc.Update(context.Background(), id, model.UpdateCustomerRequest{}, "actor")
	assert.Error(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestCustomerService_Update_BadPhone(t *testing.T) {
	svc, repo := newCustomerSvc()
	id := uuid.New()
	existing := &model.Customer{ID: id, IsActive: true}
	repo.On("GetByID", mock.Anything, id).Return(existing, nil)
	err := svc.Update(context.Background(), id, model.UpdateCustomerRequest{Phone: "garbage"}, "actor")
	assert.Error(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestCustomerService_Delete_Success(t *testing.T) {
	svc, repo := newCustomerSvc()
	id := uuid.New()
	existing := &model.Customer{ID: id, OutstandingBal: 0}
	repo.On("GetByID", mock.Anything, id).Return(existing, nil)
	repo.On("Delete", mock.Anything, id).Return(nil)
	err := svc.Delete(context.Background(), id, "actor")
	assert.NoError(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestCustomerService_Delete_NotFound(t *testing.T) {
	svc, repo := newCustomerSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(nil, model.ErrNotFound)
	err := svc.Delete(context.Background(), id, "actor")
	assert.Error(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestCustomerService_Delete_HasBalance(t *testing.T) {
	svc, repo := newCustomerSvc()
	id := uuid.New()
	existing := &model.Customer{ID: id, OutstandingBal: 500}
	repo.On("GetByID", mock.Anything, id).Return(existing, nil)
	err := svc.Delete(context.Background(), id, "actor")
	assert.Error(t, err)
	assert.True(t, errors.Is(err, model.ErrConflict))
	repo.AssertExpectations(t)
}

func TestCustomerService_List(t *testing.T) {
	svc, repo := newCustomerSvc()
	custs := []*model.Customer{{ID: uuid.New(), CompanyName: "A"}, {ID: uuid.New(), CompanyName: "B"}}
	repo.On("List", mock.Anything, mock.AnythingOfType("*model.CustomerFilter")).Return(custs, 2, nil)
	got, total, err := svc.List(context.Background(), &model.CustomerFilter{})
	assert.NoError(t, err)
	assert.Len(t, got, 2)
	assert.Equal(t, 2, total)
}

func TestCustomerService_List_NilFilter(t *testing.T) {
	svc, repo := newCustomerSvc()
	repo.On("List", mock.Anything, mock.AnythingOfType("*model.CustomerFilter")).Return([]*model.Customer{}, 0, nil)
	got, total, err := svc.List(context.Background(), nil)
	assert.NoError(t, err)
	assert.Empty(t, got)
	assert.Equal(t, 0, total)
}

func TestCustomerService_Activate_Success(t *testing.T) {
	svc, repo := newCustomerSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(&model.Customer{ID: id, IsActive: false}, nil)
	repo.On("SetActive", mock.Anything, id, true).Return(nil)
	err := svc.Activate(context.Background(), id, "actor")
	assert.NoError(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestCustomerService_Activate_AlreadyActive(t *testing.T) {
	svc, repo := newCustomerSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(&model.Customer{ID: id, IsActive: true}, nil)
	err := svc.Activate(context.Background(), id, "actor")
	assert.NoError(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestCustomerService_Deactivate_Success(t *testing.T) {
	svc, repo := newCustomerSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(&model.Customer{ID: id, IsActive: true}, nil)
	repo.On("SetActive", mock.Anything, id, false).Return(nil)
	err := svc.Deactivate(context.Background(), id, "actor")
	assert.NoError(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestCustomerService_ChargeBalance_Success(t *testing.T) {
	svc, repo := newCustomerSvc()
	id := uuid.New()
	c := &model.Customer{ID: id, IsActive: true, CreditLimit: 1000, OutstandingBal: 100}
	repo.On("GetByID", mock.Anything, id).Return(c, nil)
	repo.On("UpdateOutstandingBalance", mock.Anything, id, 200.0).Return(nil)
	err := svc.ChargeBalance(context.Background(), id, 200, "actor")
	assert.NoError(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestCustomerService_ChargeBalance_Insufficient(t *testing.T) {
	svc, repo := newCustomerSvc()
	id := uuid.New()
	c := &model.Customer{ID: id, IsActive: true, CreditLimit: 100, OutstandingBal: 90}
	repo.On("GetByID", mock.Anything, id).Return(c, nil)
	err := svc.ChargeBalance(context.Background(), id, 50, "actor")
	assert.Error(t, err)
	assert.True(t, errors.Is(err, model.ErrInsufficient))
	repo.AssertExpectations(t)
}

func TestCustomerService_ChargeBalance_ZeroAmount(t *testing.T) {
	svc, _ := newCustomerSvc()
	err := svc.ChargeBalance(context.Background(), uuid.New(), 0, "actor")
	assert.NoError(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestCustomerService_CreditBalance_Success(t *testing.T) {
	svc, repo := newCustomerSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(&model.Customer{ID: id, OutstandingBal: 500}, nil)
	repo.On("UpdateOutstandingBalance", mock.Anything, id, -200.0).Return(nil)
	err := svc.CreditBalance(context.Background(), id, 200, "actor")
	assert.NoError(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestCustomerService_CreditBalance_NegativeAmount(t *testing.T) {
	svc, _ := newCustomerSvc()
	err := svc.CreditBalance(context.Background(), uuid.New(), -10, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestCustomerService_AvailableCredit(t *testing.T) {
	svc, repo := newCustomerSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(&model.Customer{
		ID: id, CreditLimit: 1000, OutstandingBal: 300,
	}, nil)
	got, err := svc.AvailableCredit(context.Background(), id)
	assert.NoError(t, err)
	assert.Equal(t, 700.0, got)
	repo.AssertExpectations(t)
}
