package unit_test

import (
	"context"
	"testing"
	"time"

	"freightline.dev/api/internal/audit"
	"freightline.dev/api/internal/cache"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/service"
	"github.com/google/uuid"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

func newCarrierSvc() (*service.CarrierService, *MockCarrierRepo) {
	repo := new(MockCarrierRepo)
	svc := service.NewCarrierService(repo, audit.NewMemoryLogger(100), cache.New(5*time.Minute, 100))
	return svc, repo
}

func validCarrierReq() model.CreateCarrierRequest {
	return model.CreateCarrierRequest{
		Name: "Speedy Freight", Code: "SPEED",
		Email: "ops@speedy.com", Phone: "5551234567",
		BaseRate: 100, PerKgRate: 2, PerKmRate: 0.5, FuelSurchargeRate: 10,
	}
}

func TestCarrierService_Create_Success(t *testing.T) {
	svc, repo := newCarrierSvc()
	repo.On("GetByCode", mock.Anything, "SPEED").Return(nil, model.ErrNotFound)
	repo.On("Create", mock.Anything, mock.AnythingOfType("*model.Carrier")).Return(uuid.New(), nil)
	id, err := svc.Create(context.Background(), validCarrierReq(), "actor")
	assert.NoError(t, err)
	assert.NotEqual(t, uuid.Nil, id)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
	assert.NotEmpty(t, t.Name())
}

func TestCarrierService_Create_Duplicate(t *testing.T) {
	svc, repo := newCarrierSvc()
	repo.On("GetByCode", mock.Anything, "SPEED").Return(&model.Carrier{ID: uuid.New()}, nil)
	_, err := svc.Create(context.Background(), validCarrierReq(), "actor")
	assert.Error(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestCarrierService_Create_BadEmail(t *testing.T) {
	svc, _ := newCarrierSvc()
	req := validCarrierReq()
	req.Email = "broken"
	_, err := svc.Create(context.Background(), req, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotEmpty(t, t.Name())
}

func TestCarrierService_Create_NegativeRate(t *testing.T) {
	svc, _ := newCarrierSvc()
	req := validCarrierReq()
	req.BaseRate = -1
	_, err := svc.Create(context.Background(), req, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotEmpty(t, t.Name())
}

func TestCarrierService_Create_BadFuelRate(t *testing.T) {
	svc, _ := newCarrierSvc()
	req := validCarrierReq()
	req.FuelSurchargeRate = 200
	_, err := svc.Create(context.Background(), req, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotEmpty(t, t.Name())
}

func TestCarrierService_GetByID(t *testing.T) {
	svc, repo := newCarrierSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(&model.Carrier{ID: id, Name: "X"}, nil)
	got, err := svc.GetByID(context.Background(), id)
	assert.NoError(t, err)
	assert.Equal(t, "X", got.Name)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
	assert.NotEmpty(t, t.Name())
}

func TestCarrierService_GetByID_NilUUID(t *testing.T) {
	svc, _ := newCarrierSvc()
	_, err := svc.GetByID(context.Background(), uuid.Nil)
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotEmpty(t, t.Name())
}

func TestCarrierService_GetByCode(t *testing.T) {
	svc, repo := newCarrierSvc()
	repo.On("GetByCode", mock.Anything, "X").Return(&model.Carrier{Code: "X"}, nil)
	got, err := svc.GetByCode(context.Background(), "X")
	assert.NoError(t, err)
	assert.NotNil(t, got)
	repo.AssertExpectations(t)
}

func TestCarrierService_GetByCode_Empty(t *testing.T) {
	svc, _ := newCarrierSvc()
	_, err := svc.GetByCode(context.Background(), "")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotEmpty(t, t.Name())
}

func TestCarrierService_Update_Success(t *testing.T) {
	svc, repo := newCarrierSvc()
	id := uuid.New()
	c := &model.Carrier{ID: id, Name: "Old", BaseRate: 100}
	repo.On("GetByID", mock.Anything, id).Return(c, nil)
	repo.On("Update", mock.Anything, id, mock.AnythingOfType("*model.Carrier")).Return(nil)
	err := svc.Update(context.Background(), id, model.UpdateCarrierRequest{Name: "New", BaseRate: 150}, "actor")
	assert.NoError(t, err)
	assert.Equal(t, "New", c.Name)
	assert.Equal(t, 150.0, c.BaseRate)
	repo.AssertExpectations(t)
}

func TestCarrierService_Update_BadPhone(t *testing.T) {
	svc, repo := newCarrierSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(&model.Carrier{ID: id}, nil)
	err := svc.Update(context.Background(), id, model.UpdateCarrierRequest{Phone: "garbage"}, "actor")
	assert.Error(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestCarrierService_Update_NotFound(t *testing.T) {
	svc, repo := newCarrierSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(nil, model.ErrNotFound)
	err := svc.Update(context.Background(), id, model.UpdateCarrierRequest{}, "actor")
	assert.Error(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestCarrierService_Delete(t *testing.T) {
	svc, repo := newCarrierSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(&model.Carrier{ID: id}, nil)
	repo.On("Delete", mock.Anything, id).Return(nil)
	err := svc.Delete(context.Background(), id, "actor")
	assert.NoError(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestCarrierService_Delete_NotFound(t *testing.T) {
	svc, repo := newCarrierSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(nil, model.ErrNotFound)
	err := svc.Delete(context.Background(), id, "actor")
	assert.Error(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestCarrierService_List(t *testing.T) {
	svc, repo := newCarrierSvc()
	repo.On("List", mock.Anything, mock.AnythingOfType("*model.CarrierFilter")).Return(
		[]*model.Carrier{{ID: uuid.New()}}, 1, nil)
	got, total, err := svc.List(context.Background(), &model.CarrierFilter{})
	assert.NoError(t, err)
	assert.Len(t, got, 1)
	assert.Equal(t, 1, total)
}

func TestCarrierService_Quote(t *testing.T) {
	svc, repo := newCarrierSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(&model.Carrier{
		ID: id, BaseRate: 50, PerKgRate: 1, PerKmRate: 0.3, FuelSurchargeRate: 10,
	}, nil)
	got, err := svc.Quote(context.Background(), id, 10, 100)
	assert.NoError(t, err)
	assert.Greater(t, got, 0.0)
	repo.AssertExpectations(t)
}

func TestCarrierService_Quote_BadWeight(t *testing.T) {
	svc, repo := newCarrierSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(&model.Carrier{ID: id, BaseRate: 50}, nil)
	_, err := svc.Quote(context.Background(), id, -1, 100)
	assert.Error(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestCarrierService_RecordPerformance(t *testing.T) {
	svc, repo := newCarrierSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(&model.Carrier{ID: id}, nil)
	repo.On("UpdateStats", mock.Anything, id, 95.0, 2.0, 100).Return(nil)
	err := svc.RecordPerformance(context.Background(), id, 95.0, 2.0, 100, "actor")
	assert.NoError(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestCarrierService_RecordPerformance_NegativeTotal(t *testing.T) {
	svc, _ := newCarrierSvc()
	err := svc.RecordPerformance(context.Background(), uuid.New(), 90, 1, -5, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestCarrierService_Activate(t *testing.T) {
	svc, repo := newCarrierSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(&model.Carrier{ID: id, IsActive: false}, nil)
	repo.On("SetActive", mock.Anything, id, true).Return(nil)
	err := svc.Activate(context.Background(), id, "actor")
	assert.NoError(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestCarrierService_Activate_AlreadyActive(t *testing.T) {
	svc, repo := newCarrierSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(&model.Carrier{ID: id, IsActive: true}, nil)
	err := svc.Activate(context.Background(), id, "actor")
	assert.NoError(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestCarrierService_Deactivate(t *testing.T) {
	svc, repo := newCarrierSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(&model.Carrier{ID: id, IsActive: true}, nil)
	repo.On("SetActive", mock.Anything, id, false).Return(nil)
	err := svc.Deactivate(context.Background(), id, "actor")
	assert.NoError(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}
