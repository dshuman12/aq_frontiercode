package unit_test

import (
	"context"
	"testing"
	"time"

	"freightline.dev/api/internal/audit"
	"freightline.dev/api/internal/cache"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/service"
	"github.com/google/uuid"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

func newPaymentSvc() (*service.PaymentService, *MockPaymentRepo, *MockInvoiceRepo, *MockCustomerRepo) {
	pr := new(MockPaymentRepo)
	ir := new(MockInvoiceRepo)
	cr := new(MockCustomerRepo)
	svc := service.NewPaymentService(pr, ir, cr, audit.NewMemoryLogger(100), cache.New(5*time.Minute, 100))
	return svc, pr, ir, cr
}

func validPaymentReq(invID uuid.UUID) model.CreatePaymentRequest {
	return model.CreatePaymentRequest{
		InvoiceID: invID.String(),
		Method:    model.PaymentMethodACH,
		Amount:    250,
		Currency:  "USD",
	}
}

func TestPaymentService_Create_Success(t *testing.T) {
	svc, pr, ir, _ := newPaymentSvc()
	invID, custID := uuid.New(), uuid.New()
	ir.On("GetByID", mock.Anything, invID).Return(&model.Invoice{
		ID: invID, CustomerID: custID, Status: model.InvoiceStatusIssued,
		Total: 1000, BalanceDue: 1000,
	}, nil)
	pr.On("Create", mock.Anything, mock.AnythingOfType("*model.Payment")).Return(uuid.New(), nil)
	id, err := svc.Create(context.Background(), validPaymentReq(invID), "actor")
	assert.NoError(t, err)
	assert.NotEqual(t, uuid.Nil, id)
	pr.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestPaymentService_Create_VoidedInvoice(t *testing.T) {
	svc, _, ir, _ := newPaymentSvc()
	invID := uuid.New()
	ir.On("GetByID", mock.Anything, invID).Return(&model.Invoice{
		ID: invID, Status: model.InvoiceStatusVoided,
	}, nil)
	_, err := svc.Create(context.Background(), validPaymentReq(invID), "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestPaymentService_Create_OverBalance(t *testing.T) {
	svc, _, ir, _ := newPaymentSvc()
	invID := uuid.New()
	ir.On("GetByID", mock.Anything, invID).Return(&model.Invoice{
		ID: invID, Status: model.InvoiceStatusIssued, BalanceDue: 50,
	}, nil)
	req := validPaymentReq(invID)
	req.Amount = 200
	_, err := svc.Create(context.Background(), req, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestPaymentService_Create_BadMethod(t *testing.T) {
	svc, _, _, _ := newPaymentSvc()
	req := validPaymentReq(uuid.New())
	req.Method = "bitcoin"
	_, err := svc.Create(context.Background(), req, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestPaymentService_Create_NegativeAmount(t *testing.T) {
	svc, _, _, _ := newPaymentSvc()
	req := validPaymentReq(uuid.New())
	req.Amount = -50
	_, err := svc.Create(context.Background(), req, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestPaymentService_GetByID(t *testing.T) {
	svc, pr, _, _ := newPaymentSvc()
	id := uuid.New()
	pr.On("GetByID", mock.Anything, id).Return(&model.Payment{ID: id, Amount: 100}, nil)
	got, err := svc.GetByID(context.Background(), id)
	assert.NoError(t, err)
	assert.Equal(t, 100.0, got.Amount)
	assert.NotNil(t, svc)
}

func TestPaymentService_GetByID_NilUUID(t *testing.T) {
	svc, _, _, _ := newPaymentSvc()
	_, err := svc.GetByID(context.Background(), uuid.Nil)
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestPaymentService_Clear_Success(t *testing.T) {
	svc, pr, ir, cr := newPaymentSvc()
	id, invID, custID := uuid.New(), uuid.New(), uuid.New()
	pr.On("GetByID", mock.Anything, id).Return(&model.Payment{
		ID: id, InvoiceID: invID, CustomerID: custID,
		Status: model.PaymentStatusPending, Amount: 100,
	}, nil)
	pr.On("UpdateStatus", mock.Anything, id, model.PaymentStatusCleared).Return(nil)
	ir.On("ApplyPayment", mock.Anything, invID, 100.0).Return(nil)
	ir.On("GetByID", mock.Anything, invID).Return(&model.Invoice{
		ID: invID, BalanceDue: 0, AmountPaid: 100,
	}, nil)
	ir.On("UpdateStatus", mock.Anything, invID, model.InvoiceStatusPaid).Return(nil)
	cr.On("UpdateOutstandingBalance", mock.Anything, custID, -100.0).Return(nil)
	err := svc.Clear(context.Background(), id, "actor")
	assert.NoError(t, err)
	pr.AssertExpectations(t)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestPaymentService_Clear_AlreadyCleared(t *testing.T) {
	svc, pr, _, _ := newPaymentSvc()
	id := uuid.New()
	pr.On("GetByID", mock.Anything, id).Return(&model.Payment{
		ID: id, Status: model.PaymentStatusCleared,
	}, nil)
	err := svc.Clear(context.Background(), id, "actor")
	assert.NoError(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestPaymentService_Clear_Reversed(t *testing.T) {
	svc, pr, _, _ := newPaymentSvc()
	id := uuid.New()
	pr.On("GetByID", mock.Anything, id).Return(&model.Payment{
		ID: id, Status: model.PaymentStatusReversed,
	}, nil)
	err := svc.Clear(context.Background(), id, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestPaymentService_Reverse_Success(t *testing.T) {
	svc, pr, ir, cr := newPaymentSvc()
	id, invID, custID := uuid.New(), uuid.New(), uuid.New()
	pr.On("GetByID", mock.Anything, id).Return(&model.Payment{
		ID: id, InvoiceID: invID, CustomerID: custID,
		Status: model.PaymentStatusCleared, Amount: 100,
	}, nil)
	pr.On("UpdateStatus", mock.Anything, id, model.PaymentStatusReversed).Return(nil)
	ir.On("ApplyPayment", mock.Anything, invID, -100.0).Return(nil)
	cr.On("UpdateOutstandingBalance", mock.Anything, custID, 100.0).Return(nil)
	err := svc.Reverse(context.Background(), id, "fraud", "actor")
	assert.NoError(t, err)
	pr.AssertExpectations(t)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestPaymentService_Reverse_AlreadyReversed(t *testing.T) {
	svc, pr, _, _ := newPaymentSvc()
	id := uuid.New()
	pr.On("GetByID", mock.Anything, id).Return(&model.Payment{
		ID: id, Status: model.PaymentStatusReversed,
	}, nil)
	err := svc.Reverse(context.Background(), id, "x", "actor")
	assert.NoError(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestPaymentService_Refund_Success(t *testing.T) {
	svc, pr, ir, cr := newPaymentSvc()
	id, invID, custID := uuid.New(), uuid.New(), uuid.New()
	pr.On("GetByID", mock.Anything, id).Return(&model.Payment{
		ID: id, InvoiceID: invID, CustomerID: custID,
		Status: model.PaymentStatusCleared, Amount: 200,
	}, nil)
	pr.On("UpdateStatus", mock.Anything, id, model.PaymentStatusRefunded).Return(nil)
	ir.On("ApplyPayment", mock.Anything, invID, -50.0).Return(nil)
	cr.On("UpdateOutstandingBalance", mock.Anything, custID, 50.0).Return(nil)
	err := svc.Refund(context.Background(), id, model.RefundPaymentRequest{Amount: 50}, "actor")
	assert.NoError(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestPaymentService_Refund_NotCleared(t *testing.T) {
	svc, pr, _, _ := newPaymentSvc()
	id := uuid.New()
	pr.On("GetByID", mock.Anything, id).Return(&model.Payment{
		ID: id, Status: model.PaymentStatusPending, Amount: 100,
	}, nil)
	err := svc.Refund(context.Background(), id, model.RefundPaymentRequest{Amount: 50}, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestPaymentService_Refund_OverPayment(t *testing.T) {
	svc, pr, _, _ := newPaymentSvc()
	id := uuid.New()
	pr.On("GetByID", mock.Anything, id).Return(&model.Payment{
		ID: id, Status: model.PaymentStatusCleared, Amount: 100,
	}, nil)
	err := svc.Refund(context.Background(), id, model.RefundPaymentRequest{Amount: 200}, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestPaymentService_Refund_NegativeAmount(t *testing.T) {
	svc, _, _, _ := newPaymentSvc()
	err := svc.Refund(context.Background(), uuid.New(), model.RefundPaymentRequest{Amount: -10}, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestPaymentService_List(t *testing.T) {
	svc, pr, _, _ := newPaymentSvc()
	pr.On("List", mock.Anything, mock.AnythingOfType("*model.PaymentFilter")).Return(
		[]*model.Payment{{ID: uuid.New()}}, 1, nil)
	got, total, err := svc.List(context.Background(), nil)
	assert.NoError(t, err)
	assert.Len(t, got, 1)
	assert.Equal(t, 1, total)
}

func TestPaymentService_ListByInvoice(t *testing.T) {
	svc, pr, _, _ := newPaymentSvc()
	invID := uuid.New()
	pr.On("ListByInvoice", mock.Anything, invID).Return([]*model.Payment{}, nil)
	got, err := svc.ListByInvoice(context.Background(), invID)
	assert.NoError(t, err)
	assert.NotNil(t, got)
	assert.NotNil(t, svc)
}

func TestPaymentService_ListByInvoice_NilUUID(t *testing.T) {
	svc, _, _, _ := newPaymentSvc()
	_, err := svc.ListByInvoice(context.Background(), uuid.Nil)
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestPaymentService_SumForInvoice(t *testing.T) {
	svc, pr, _, _ := newPaymentSvc()
	invID := uuid.New()
	pr.On("SumForInvoice", mock.Anything, invID).Return(500.0, nil)
	got, err := svc.SumForInvoice(context.Background(), invID)
	assert.NoError(t, err)
	assert.Equal(t, 500.0, got)
	assert.NotNil(t, svc)
}
