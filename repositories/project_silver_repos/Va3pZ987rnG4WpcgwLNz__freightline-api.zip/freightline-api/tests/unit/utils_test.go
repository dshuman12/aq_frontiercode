package unit_test

import (
	"context"
	"errors"
	"testing"
	"time"

	"freightline.dev/api/internal/config"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/search"
	"github.com/stretchr/testify/assert"
)

func TestConfig_Load_Defaults(t *testing.T) {
	cfg, err := config.Load()
	assert.NoError(t, err)
	assert.Equal(t, "8080", cfg.Server.Port)
	assert.NotEmpty(t, cfg.JWT.Secret)
}

func TestConfig_DSN(t *testing.T) {
	c := config.DatabaseConfig{
		Host: "localhost", Port: "5432", User: "u", Password: "p",
		Name: "db", SSLMode: "disable",
	}
	dsn := c.DSN()
	assert.Contains(t, dsn, "host=localhost")
	assert.Contains(t, dsn, "port=5432")
	assert.Contains(t, dsn, "dbname=db")
}

func TestServiceError_Combined(t *testing.T) {
	err := model.NewServiceError("CODE", "msg", errors.New("inner"))
	assert.Error(t, err)
	assert.Contains(t, err.Error(), "CODE")
	assert.Contains(t, err.Error(), "msg")
	assert.Contains(t, err.Error(), "inner")
	assert.NotNil(t, err.Unwrap())
}

func TestSearch_Direction(t *testing.T) {
	assert.Equal(t, search.Direction("ASC"), search.Asc)
	assert.Equal(t, search.Direction("DESC"), search.Desc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestContext_Cancel(t *testing.T) {
	ctx, cancel := context.WithTimeout(context.Background(), time.Millisecond)
	defer cancel()
	<-ctx.Done()
	assert.Error(t, ctx.Err())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestModelErrors_Distinct(t *testing.T) {
	all := []error{
		model.ErrNotFound, model.ErrDuplicate, model.ErrInvalidInput,
		model.ErrForbidden, model.ErrUnauthorized, model.ErrConflict,
		model.ErrUnavailable, model.ErrInvalidStatus, model.ErrInsufficient,
		model.ErrExpired, model.ErrRateLimit, model.ErrInternal,
		model.ErrAlreadyClosed, model.ErrTooEarly, model.ErrTooLate,
	}
	for _, e := range all {
		assert.Error(t, e)
	}
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}
