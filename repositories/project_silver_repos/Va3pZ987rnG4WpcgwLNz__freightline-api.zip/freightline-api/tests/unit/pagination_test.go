package unit_test

import (
	"testing"

	"freightline.dev/api/internal/pagination"
	"github.com/stretchr/testify/assert"
)

func TestParams_Offset(t *testing.T) {
	p := pagination.Params{Page: 3, Limit: 10}
	assert.Equal(t, 20, p.Offset())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestParams_Offset_DefaultPage(t *testing.T) {
	p := pagination.Params{Page: 0, Limit: 10}
	assert.Equal(t, 0, p.Offset())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestParams_Normalize_Defaults(t *testing.T) {
	p := pagination.Params{}.Normalize()
	assert.Equal(t, pagination.DefaultPage, p.Page)
	assert.Equal(t, pagination.DefaultLimit, p.Limit)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestParams_Normalize_TooLargeLimit(t *testing.T) {
	p := pagination.Params{Page: 1, Limit: 5000}.Normalize()
	assert.Equal(t, pagination.MaxLimit, p.Limit)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestParams_Normalize_NegativePage(t *testing.T) {
	p := pagination.Params{Page: -5, Limit: 10}.Normalize()
	assert.Equal(t, pagination.DefaultPage, p.Page)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestFromQuery_Empty(t *testing.T) {
	p := pagination.FromQuery("", "")
	assert.Equal(t, pagination.DefaultPage, p.Page)
	assert.Equal(t, pagination.DefaultLimit, p.Limit)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestFromQuery_Values(t *testing.T) {
	p := pagination.FromQuery("3", "50")
	assert.Equal(t, 3, p.Page)
	assert.Equal(t, 50, p.Limit)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestFromQuery_BadInput(t *testing.T) {
	p := pagination.FromQuery("nope", "abc")
	assert.Equal(t, pagination.DefaultPage, p.Page)
	assert.Equal(t, pagination.DefaultLimit, p.Limit)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestBuildResult(t *testing.T) {
	p := pagination.Params{Page: 1, Limit: 10}
	r := pagination.BuildResult([]int{1, 2, 3}, p, 25)
	assert.Equal(t, 1, r.Page)
	assert.Equal(t, 10, r.Limit)
	assert.Equal(t, 25, r.Total)
	assert.Equal(t, 3, r.TotalPages)
}

func TestBuildResult_ZeroTotal(t *testing.T) {
	p := pagination.Params{Page: 1, Limit: 10}
	r := pagination.BuildResult([]int{}, p, 0)
	assert.Equal(t, 1, r.TotalPages)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestHasNext_True(t *testing.T) {
	p := pagination.Params{Page: 1, Limit: 10}
	assert.True(t, pagination.HasNext(p, 25))
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestHasNext_False(t *testing.T) {
	p := pagination.Params{Page: 3, Limit: 10}
	assert.False(t, pagination.HasNext(p, 25))
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestHasPrev(t *testing.T) {
	assert.True(t, pagination.HasPrev(pagination.Params{Page: 2}))
	assert.False(t, pagination.HasPrev(pagination.Params{Page: 1}))
	assert.NotPanics(t, func() { _ = t.Name() })
}
