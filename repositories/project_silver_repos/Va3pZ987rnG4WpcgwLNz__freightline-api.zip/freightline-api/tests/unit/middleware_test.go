package unit_test

import (
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"freightline.dev/api/internal/middleware"
	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
)

func init() {
	gin.SetMode(gin.TestMode)
}

func TestJWT_SignAndParse(t *testing.T) {
	j := middleware.NewJWT("test-secret", 5*time.Minute)
	tok, err := j.Sign("user-1", "u@x.com", []string{"admin"})
	assert.NoError(t, err)
	assert.NotEmpty(t, tok)
	claims, err := j.Parse(tok)
	assert.NoError(t, err)
	assert.Equal(t, "user-1", claims.UserID)
}

func TestJWT_ParseBadToken(t *testing.T) {
	j := middleware.NewJWT("s", 5*time.Minute)
	_, err := j.Parse("garbage")
	assert.Error(t, err)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestRequireAuth_NoHeader(t *testing.T) {
	j := middleware.NewJWT("test-secret", 5*time.Minute)
	r := gin.New()
	r.Use(middleware.RequireAuth(j))
	r.GET("/x", func(c *gin.Context) { c.Status(200) })
	w := httptest.NewRecorder()
	r.ServeHTTP(w, httptest.NewRequest("GET", "/x", nil))
	assert.Equal(t, http.StatusUnauthorized, w.Code)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestRequireAuth_BadScheme(t *testing.T) {
	j := middleware.NewJWT("s", 5*time.Minute)
	r := gin.New()
	r.Use(middleware.RequireAuth(j))
	r.GET("/x", func(c *gin.Context) { c.Status(200) })
	req := httptest.NewRequest("GET", "/x", nil)
	req.Header.Set("Authorization", "Basic xyz")
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)
	assert.Equal(t, http.StatusUnauthorized, w.Code)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestRequireAuth_Valid(t *testing.T) {
	j := middleware.NewJWT("s", 5*time.Minute)
	tok, _ := j.Sign("u", "u@x.com", []string{"user"})
	r := gin.New()
	r.Use(middleware.RequireAuth(j))
	r.GET("/x", func(c *gin.Context) {
		assert.Equal(t, "u", middleware.CurrentUserID(c))
		c.Status(200)
	})
	req := httptest.NewRequest("GET", "/x", nil)
	req.Header.Set("Authorization", "Bearer "+tok)
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)
	assert.Equal(t, http.StatusOK, w.Code)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestRequireRole_AllowedRole(t *testing.T) {
	j := middleware.NewJWT("s", 5*time.Minute)
	tok, _ := j.Sign("u", "u@x.com", []string{"admin"})
	r := gin.New()
	r.Use(middleware.RequireAuth(j))
	r.Use(middleware.RequireRole("admin"))
	r.GET("/x", func(c *gin.Context) { c.Status(200) })
	req := httptest.NewRequest("GET", "/x", nil)
	req.Header.Set("Authorization", "Bearer "+tok)
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)
	assert.Equal(t, http.StatusOK, w.Code)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestRequireRole_Denied(t *testing.T) {
	j := middleware.NewJWT("s", 5*time.Minute)
	tok, _ := j.Sign("u", "u@x.com", []string{"user"})
	r := gin.New()
	r.Use(middleware.RequireAuth(j))
	r.Use(middleware.RequireRole("admin"))
	r.GET("/x", func(c *gin.Context) { c.Status(200) })
	req := httptest.NewRequest("GET", "/x", nil)
	req.Header.Set("Authorization", "Bearer "+tok)
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)
	assert.Equal(t, http.StatusForbidden, w.Code)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestRequestID_GeneratesID(t *testing.T) {
	r := gin.New()
	r.Use(middleware.RequestID())
	r.GET("/x", func(c *gin.Context) {
		v, _ := c.Get("request_id")
		assert.NotEmpty(t, v)
		c.Status(200)
	})
	w := httptest.NewRecorder()
	r.ServeHTTP(w, httptest.NewRequest("GET", "/x", nil))
	assert.NotEmpty(t, w.Header().Get("X-Request-ID"))
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestRequestID_UsesProvided(t *testing.T) {
	r := gin.New()
	r.Use(middleware.RequestID())
	r.GET("/x", func(c *gin.Context) { c.Status(200) })
	req := httptest.NewRequest("GET", "/x", nil)
	req.Header.Set("X-Request-ID", "abc-123")
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)
	assert.Equal(t, "abc-123", w.Header().Get("X-Request-ID"))
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestSecurityHeaders(t *testing.T) {
	r := gin.New()
	r.Use(middleware.SecurityHeaders())
	r.GET("/x", func(c *gin.Context) { c.Status(200) })
	w := httptest.NewRecorder()
	r.ServeHTTP(w, httptest.NewRequest("GET", "/x", nil))
	assert.Equal(t, "nosniff", w.Header().Get("X-Content-Type-Options"))
	assert.Equal(t, "DENY", w.Header().Get("X-Frame-Options"))
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestCORS_Preflight(t *testing.T) {
	r := gin.New()
	r.Use(middleware.CORS("*"))
	r.OPTIONS("/x", func(c *gin.Context) { c.Status(200) })
	r.GET("/x", func(c *gin.Context) { c.Status(200) })
	w := httptest.NewRecorder()
	r.ServeHTTP(w, httptest.NewRequest("OPTIONS", "/x", nil))
	assert.Equal(t, http.StatusNoContent, w.Code)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestRateLimiter_AllowsBurst(t *testing.T) {
	rl := middleware.NewRateLimiter(10, 5)
	r := gin.New()
	r.Use(rl.Limit())
	r.GET("/x", func(c *gin.Context) { c.Status(200) })
	for i := 0; i < 3; i++ {
		w := httptest.NewRecorder()
		r.ServeHTTP(w, httptest.NewRequest("GET", "/x", nil))
		assert.Equal(t, http.StatusOK, w.Code)
	}
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}
