package unit_test

import (
	"context"
	"testing"
	"time"

	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/service"
	"github.com/google/uuid"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

func newReportSvc() (*service.ReportService, *MockShipmentRepo, *MockDriverRepo, *MockVehicleRepo, *MockWarehouseRepo, *MockCustomerRepo, *MockInvoiceRepo, *MockPaymentRepo, *MockCarrierRepo) {
	sr := new(MockShipmentRepo)
	dr := new(MockDriverRepo)
	vr := new(MockVehicleRepo)
	wr := new(MockWarehouseRepo)
	cr := new(MockCustomerRepo)
	ir := new(MockInvoiceRepo)
	pr := new(MockPaymentRepo)
	ar := new(MockCarrierRepo)
	svc := service.NewReportService(sr, dr, vr, wr, cr, ir, pr, ar)
	return svc, sr, dr, vr, wr, cr, ir, pr, ar
}

func TestReportService_Dashboard(t *testing.T) {
	svc, sr, dr, vr, _, _, ir, pr, _ := newReportSvc()
	sr.On("CountByStatus", mock.Anything).Return(map[model.ShipmentStatus]int{
		model.ShipmentStatusBooked:    3,
		model.ShipmentStatusInTransit: 5,
		model.ShipmentStatusDelivered: 8,
	}, nil)
	dr.On("ListAvailable", mock.Anything).Return([]*model.Driver{{ID: uuid.New()}, {ID: uuid.New()}}, nil)
	vr.On("ListAvailable", mock.Anything).Return([]*model.Vehicle{{ID: uuid.New()}}, nil)
	sr.On("ListOverdue", mock.Anything).Return([]*model.Shipment{}, nil)
	ir.On("SumOutstanding", mock.Anything).Return(2500.0, nil)
	pr.On("List", mock.Anything, mock.AnythingOfType("*model.PaymentFilter")).Return([]*model.Payment{
		{ID: uuid.New(), Amount: 500},
	}, 1, nil)

	r, err := svc.Dashboard(context.Background())
	assert.NoError(t, err)
	assert.NotNil(t, r)
	assert.Equal(t, 8, r.ActiveShipments)
	assert.Equal(t, 2500.0, r.OutstandingRevenue)
}

func TestReportService_FleetUtilization(t *testing.T) {
	svc, _, _, vr, _, _, _, _, _ := newReportSvc()
	vr.On("List", mock.Anything, mock.AnythingOfType("*model.VehicleFilter")).Return([]*model.Vehicle{
		{ID: uuid.New(), Status: model.VehicleStatusAvailable, CapacityKg: 5000, OdometerKm: 10000},
		{ID: uuid.New(), Status: model.VehicleStatusInTransit, CapacityKg: 8000, OdometerKm: 50000},
		{ID: uuid.New(), Status: model.VehicleStatusMaintenance, CapacityKg: 5000, OdometerKm: 100000},
	}, 3, nil)

	r, err := svc.FleetUtilization(context.Background(), time.Now().AddDate(0, -1, 0), time.Now())
	assert.NoError(t, err)
	assert.Equal(t, 3, r.TotalVehicles)
	assert.Equal(t, 1, r.AvailableVehicles)
	assert.Equal(t, 1, r.InTransit)
	assert.Equal(t, 1, r.InMaintenance)
}

func TestReportService_DriverPerformance(t *testing.T) {
	svc, sr, dr, _, _, _, _, _, _ := newReportSvc()
	drvID := uuid.New()
	dr.On("GetByID", mock.Anything, drvID).Return(&model.Driver{
		ID: drvID, FirstName: "Sam", LastName: "Driver", TotalMilesDriven: 5000,
	}, nil)

	deliv1 := time.Now()
	sched := time.Now().AddDate(0, 0, 1)
	pickup := time.Now().AddDate(0, 0, -1)
	sr.On("ListByDriver", mock.Anything, drvID, 1000).Return([]*model.Shipment{
		{
			ID: uuid.New(), Status: model.ShipmentStatusDelivered,
			ActualDelivery: &deliv1, ScheduledDelivery: sched, ActualPickup: &pickup,
		},
		{ID: uuid.New(), Status: model.ShipmentStatusFailed},
	}, nil)

	r, err := svc.DriverPerformance(context.Background(), drvID, time.Time{}, time.Time{})
	assert.NoError(t, err)
	assert.Equal(t, 1, r.DeliveriesCompleted)
	assert.Equal(t, 1, r.FailedDeliveries)
	assert.InDelta(t, 100.0, r.OnTimeRate, 0.01)
}

func TestReportService_DriverPerformance_NilUUID(t *testing.T) {
	svc, _, _, _, _, _, _, _, _ := newReportSvc()
	_, err := svc.DriverPerformance(context.Background(), uuid.Nil, time.Time{}, time.Time{})
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestReportService_DriverPerformance_NotFound(t *testing.T) {
	svc, _, dr, _, _, _, _, _, _ := newReportSvc()
	drvID := uuid.New()
	dr.On("GetByID", mock.Anything, drvID).Return(nil, model.ErrNotFound)
	_, err := svc.DriverPerformance(context.Background(), drvID, time.Time{}, time.Time{})
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestReportService_Revenue(t *testing.T) {
	svc, _, _, _, _, cr, ir, pr, _ := newReportSvc()
	custID := uuid.New()
	ir.On("List", mock.Anything, mock.AnythingOfType("*model.InvoiceFilter")).Return([]*model.Invoice{
		{ID: uuid.New(), CustomerID: custID, Total: 1000, AmountPaid: 500, BalanceDue: 500, Status: model.InvoiceStatusPartiallyPaid},
	}, 1, nil)
	pr.On("List", mock.Anything, mock.AnythingOfType("*model.PaymentFilter")).Return([]*model.Payment{
		{ID: uuid.New(), Amount: 500},
	}, 1, nil)
	cr.On("GetByID", mock.Anything, custID).Return(&model.Customer{ID: custID, CompanyName: "Acme"}, nil)

	r, err := svc.Revenue(context.Background(), time.Now().AddDate(0, -1, 0), time.Now())
	assert.NoError(t, err)
	assert.Equal(t, 1, r.InvoiceCount)
	assert.Equal(t, 1000.0, r.InvoicedAmount)
	assert.Equal(t, 500.0, r.CollectedAmount)
	assert.Equal(t, 500.0, r.Outstanding)
}

func TestReportService_ShipmentVolume(t *testing.T) {
	svc, sr, _, _, _, _, _, _, _ := newReportSvc()
	pickup := time.Now().AddDate(0, 0, -2)
	deliv := time.Now()
	sr.On("List", mock.Anything, mock.AnythingOfType("*model.ShipmentFilter")).Return([]*model.Shipment{
		{
			ID: uuid.New(), Status: model.ShipmentStatusDelivered, WeightKg: 50, VolumeM3: 2,
			ServiceLevel: model.ServiceLevelStandard,
			ActualPickup: &pickup, ActualDelivery: &deliv, ScheduledDelivery: deliv.AddDate(0, 0, 1),
		},
		{ID: uuid.New(), Status: model.ShipmentStatusFailed, WeightKg: 30},
	}, 2, nil)

	r, err := svc.ShipmentVolume(context.Background(), time.Now().AddDate(0, -1, 0), time.Now())
	assert.NoError(t, err)
	assert.Equal(t, 2, r.TotalShipments)
	assert.Equal(t, 80.0, r.TotalWeightKg)
	assert.Equal(t, 1, r.ByStatus[model.ShipmentStatusDelivered])
}

func TestReportService_WarehouseUtilization(t *testing.T) {
	svc, _, _, _, wr, _, _, _, _ := newReportSvc()
	whID := uuid.New()
	wr.On("GetByID", mock.Anything, whID).Return(&model.Warehouse{
		ID: whID, Name: "Main", Capacity: 1000, UsedCapacity: 300,
	}, nil)

	r, err := svc.WarehouseUtilization(context.Background(), whID)
	assert.NoError(t, err)
	assert.Equal(t, 1000.0, r.Capacity)
	assert.Equal(t, 300.0, r.Used)
	assert.InDelta(t, 30.0, r.UtilizationPercent, 0.01)
}

func TestReportService_WarehouseUtilization_NilUUID(t *testing.T) {
	svc, _, _, _, _, _, _, _, _ := newReportSvc()
	_, err := svc.WarehouseUtilization(context.Background(), uuid.Nil)
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestReportService_CarrierPerformance(t *testing.T) {
	svc, sr, _, _, _, _, _, _, ar := newReportSvc()
	carrID := uuid.New()
	ar.On("GetByID", mock.Anything, carrID).Return(&model.Carrier{
		ID: carrID, Name: "Speedy", OnTimeRate: 90, DamageRate: 2, Rating: 4.5,
	}, nil)
	sr.On("List", mock.Anything, mock.AnythingOfType("*model.ShipmentFilter")).Return([]*model.Shipment{
		{ID: uuid.New(), TotalCharge: 100},
		{ID: uuid.New(), TotalCharge: 200},
	}, 2, nil)

	r, err := svc.CarrierPerformance(context.Background(), carrID, time.Time{}, time.Time{})
	assert.NoError(t, err)
	assert.Equal(t, 2, r.ShipmentCount)
	assert.Equal(t, 300.0, r.TotalSpend)
	assert.Equal(t, 150.0, r.AvgCost)
}

func TestReportService_CarrierPerformance_NotFound(t *testing.T) {
	svc, _, _, _, _, _, _, _, ar := newReportSvc()
	carrID := uuid.New()
	ar.On("GetByID", mock.Anything, carrID).Return(nil, model.ErrNotFound)
	_, err := svc.CarrierPerformance(context.Background(), carrID, time.Time{}, time.Time{})
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}
