package unit_test

import (
	"strings"
	"testing"

	"freightline.dev/api/internal/search"
	"github.com/stretchr/testify/assert"
)

func TestBuilder_SimpleSelect(t *testing.T) {
	q, args := search.NewBuilder("customers").Build()
	assert.Equal(t, "SELECT * FROM customers", q)
	assert.Empty(t, args)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestBuilder_Columns(t *testing.T) {
	q, _ := search.NewBuilder("customers").Select("id", "name").Build()
	assert.Equal(t, "SELECT id, name FROM customers", q)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestBuilder_WhereEq(t *testing.T) {
	q, args := search.NewBuilder("customers").WhereEq("city", "Houston").Build()
	assert.Contains(t, q, "WHERE city = $1")
	assert.Equal(t, []interface{}{"Houston"}, args)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestBuilder_WhereLike_Empty(t *testing.T) {
	q, args := search.NewBuilder("customers").WhereLike("name", "").Build()
	assert.NotContains(t, q, "WHERE")
	assert.Empty(t, args)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestBuilder_WhereLike(t *testing.T) {
	q, args := search.NewBuilder("customers").WhereLike("name", "acme").Build()
	assert.Contains(t, q, "ILIKE")
	assert.Equal(t, []interface{}{"%acme%"}, args)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestBuilder_WhereIn(t *testing.T) {
	q, args := search.NewBuilder("customers").WhereIn("state", []interface{}{"TX", "FL"}).Build()
	assert.Contains(t, q, "IN ($1,$2)")
	assert.Equal(t, []interface{}{"TX", "FL"}, args)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestBuilder_WhereIn_Empty(t *testing.T) {
	q, _ := search.NewBuilder("customers").WhereIn("state", []interface{}{}).Build()
	assert.NotContains(t, q, "WHERE")
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestBuilder_WhereNullish(t *testing.T) {
	q, _ := search.NewBuilder("customers").WhereNullish("deleted_at", true).Build()
	assert.Contains(t, q, "IS NULL")
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestBuilder_OrderByLimitOffset(t *testing.T) {
	q, _ := search.NewBuilder("c").
		OrderBy("created_at", search.Desc).
		Limit(10).
		Offset(20).
		Build()
	assert.Contains(t, q, "ORDER BY created_at DESC")
	assert.Contains(t, q, "LIMIT 10")
	assert.Contains(t, q, "OFFSET 20")
}

func TestBuilder_MultipleConditions(t *testing.T) {
	q, args := search.NewBuilder("c").
		WhereEq("city", "Reno").
		Where("age", search.OpGte, 18).
		Build()
	assert.Contains(t, q, "WHERE")
	assert.True(t, strings.Contains(q, "AND"))
	assert.Equal(t, []interface{}{"Reno", 18}, args)
}

func TestBuilder_CountQuery(t *testing.T) {
	b := search.NewBuilder("c").WhereEq("active", true).Limit(50).Offset(10).OrderBy("name", search.Asc)
	q, args := b.CountQuery()
	assert.Contains(t, q, "COUNT(*)")
	assert.NotContains(t, q, "LIMIT")
	assert.NotContains(t, q, "OFFSET")
	assert.NotContains(t, q, "ORDER")
	assert.Equal(t, []interface{}{true}, args)
}
