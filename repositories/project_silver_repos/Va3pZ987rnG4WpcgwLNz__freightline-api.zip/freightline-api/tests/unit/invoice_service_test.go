package unit_test

import (
	"context"
	"testing"
	"time"

	"freightline.dev/api/internal/audit"
	"freightline.dev/api/internal/cache"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/service"
	"github.com/google/uuid"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

func newInvoiceSvc() (*service.InvoiceService, *MockInvoiceRepo, *MockPaymentRepo, *MockCustomerRepo) {
	ir := new(MockInvoiceRepo)
	pr := new(MockPaymentRepo)
	cr := new(MockCustomerRepo)
	svc := service.NewInvoiceService(ir, pr, cr, audit.NewMemoryLogger(100), cache.New(5*time.Minute, 100))
	return svc, ir, pr, cr
}

func validInvoiceReq(custID uuid.UUID) model.CreateInvoiceRequest {
	return model.CreateInvoiceRequest{
		CustomerID:   custID.String(),
		IssuedDate:   "2024-01-15",
		DueDate:      "2024-02-15",
		PaymentTerms: 30,
		Currency:     "USD",
		LineItems: []model.CreateInvoiceLineItemRequest{
			{Description: "Freight charges", Quantity: 1, UnitPrice: 500, TaxRate: 7},
		},
	}
}

func TestInvoiceService_Create_Success(t *testing.T) {
	svc, ir, _, cr := newInvoiceSvc()
	custID := uuid.New()
	cr.On("GetByID", mock.Anything, custID).Return(&model.Customer{
		ID: custID, CompanyName: "Acme", PaymentTerms: 30,
	}, nil)
	ir.On("Create", mock.Anything, mock.AnythingOfType("*model.Invoice"), mock.AnythingOfType("[]*model.InvoiceLineItem")).Return(uuid.New(), nil)
	cr.On("UpdateOutstandingBalance", mock.Anything, custID, mock.Anything).Return(nil)
	id, err := svc.Create(context.Background(), validInvoiceReq(custID), "actor")
	assert.NoError(t, err)
	assert.NotEqual(t, uuid.Nil, id)
	ir.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestInvoiceService_Create_BadCustomerID(t *testing.T) {
	svc, _, _, _ := newInvoiceSvc()
	req := validInvoiceReq(uuid.New())
	req.CustomerID = "broken"
	_, err := svc.Create(context.Background(), req, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestInvoiceService_Create_NoLineItems(t *testing.T) {
	svc, _, _, _ := newInvoiceSvc()
	req := validInvoiceReq(uuid.New())
	req.LineItems = nil
	_, err := svc.Create(context.Background(), req, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestInvoiceService_Create_BadLineItem(t *testing.T) {
	svc, _, _, _ := newInvoiceSvc()
	req := validInvoiceReq(uuid.New())
	req.LineItems[0].Quantity = 0
	_, err := svc.Create(context.Background(), req, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestInvoiceService_Create_BadDiscount(t *testing.T) {
	svc, _, _, _ := newInvoiceSvc()
	req := validInvoiceReq(uuid.New())
	req.LineItems[0].Discount = 200
	_, err := svc.Create(context.Background(), req, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestInvoiceService_GetByID(t *testing.T) {
	svc, ir, _, _ := newInvoiceSvc()
	id := uuid.New()
	ir.On("GetByID", mock.Anything, id).Return(&model.Invoice{ID: id, InvoiceNumber: "INV1"}, nil)
	got, err := svc.GetByID(context.Background(), id)
	assert.NoError(t, err)
	assert.Equal(t, "INV1", got.InvoiceNumber)
	assert.NotNil(t, svc)
}

func TestInvoiceService_GetByID_NilUUID(t *testing.T) {
	svc, _, _, _ := newInvoiceSvc()
	_, err := svc.GetByID(context.Background(), uuid.Nil)
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestInvoiceService_GetWithLines(t *testing.T) {
	svc, ir, _, _ := newInvoiceSvc()
	id := uuid.New()
	ir.On("GetWithLines", mock.Anything, id).Return(&model.InvoiceWithLines{
		Invoice: &model.Invoice{ID: id}, LineItems: []*model.InvoiceLineItem{{}},
	}, nil)
	got, err := svc.GetWithLines(context.Background(), id)
	assert.NoError(t, err)
	assert.Len(t, got.LineItems, 1)
	assert.NotNil(t, svc)
}

func TestInvoiceService_GetWithLines_NilUUID(t *testing.T) {
	svc, _, _, _ := newInvoiceSvc()
	_, err := svc.GetWithLines(context.Background(), uuid.Nil)
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestInvoiceService_Update_Success(t *testing.T) {
	svc, ir, _, _ := newInvoiceSvc()
	id := uuid.New()
	inv := &model.Invoice{ID: id, Status: model.InvoiceStatusIssued}
	ir.On("GetByID", mock.Anything, id).Return(inv, nil)
	ir.On("Update", mock.Anything, id, mock.AnythingOfType("*model.Invoice")).Return(nil)
	err := svc.Update(context.Background(), id, model.UpdateInvoiceRequest{Notes: "ping"}, "actor")
	assert.NoError(t, err)
	assert.Equal(t, "ping", inv.Notes)
	ir.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestInvoiceService_Update_VoidedFails(t *testing.T) {
	svc, ir, _, _ := newInvoiceSvc()
	id := uuid.New()
	ir.On("GetByID", mock.Anything, id).Return(&model.Invoice{ID: id, Status: model.InvoiceStatusVoided}, nil)
	err := svc.Update(context.Background(), id, model.UpdateInvoiceRequest{Notes: "x"}, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestInvoiceService_Void_Success(t *testing.T) {
	svc, ir, _, cr := newInvoiceSvc()
	id, custID := uuid.New(), uuid.New()
	ir.On("GetByID", mock.Anything, id).Return(&model.Invoice{
		ID: id, CustomerID: custID, Status: model.InvoiceStatusIssued, Total: 100,
	}, nil)
	ir.On("UpdateStatus", mock.Anything, id, model.InvoiceStatusVoided).Return(nil)
	cr.On("UpdateOutstandingBalance", mock.Anything, custID, -100.0).Return(nil)
	err := svc.Void(context.Background(), id, "duplicate", "actor")
	assert.NoError(t, err)
	ir.AssertExpectations(t)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestInvoiceService_Void_WithPayments(t *testing.T) {
	svc, ir, _, _ := newInvoiceSvc()
	id := uuid.New()
	ir.On("GetByID", mock.Anything, id).Return(&model.Invoice{
		ID: id, Status: model.InvoiceStatusIssued, AmountPaid: 50,
	}, nil)
	err := svc.Void(context.Background(), id, "reason", "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestInvoiceService_Void_AlreadyVoided(t *testing.T) {
	svc, ir, _, _ := newInvoiceSvc()
	id := uuid.New()
	ir.On("GetByID", mock.Anything, id).Return(&model.Invoice{ID: id, Status: model.InvoiceStatusVoided}, nil)
	err := svc.Void(context.Background(), id, "x", "actor")
	assert.NoError(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestInvoiceService_Delete_Success(t *testing.T) {
	svc, ir, _, _ := newInvoiceSvc()
	id := uuid.New()
	ir.On("GetByID", mock.Anything, id).Return(&model.Invoice{ID: id, AmountPaid: 0}, nil)
	ir.On("Delete", mock.Anything, id).Return(nil)
	err := svc.Delete(context.Background(), id, "actor")
	assert.NoError(t, err)
	ir.AssertExpectations(t)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestInvoiceService_Delete_WithPayments(t *testing.T) {
	svc, ir, _, _ := newInvoiceSvc()
	id := uuid.New()
	ir.On("GetByID", mock.Anything, id).Return(&model.Invoice{ID: id, AmountPaid: 50}, nil)
	err := svc.Delete(context.Background(), id, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestInvoiceService_List(t *testing.T) {
	svc, ir, _, _ := newInvoiceSvc()
	ir.On("List", mock.Anything, mock.AnythingOfType("*model.InvoiceFilter")).Return(
		[]*model.Invoice{{ID: uuid.New()}}, 1, nil)
	got, total, err := svc.List(context.Background(), nil)
	assert.NoError(t, err)
	assert.Len(t, got, 1)
	assert.Equal(t, 1, total)
}

func TestInvoiceService_ListByCustomer(t *testing.T) {
	svc, ir, _, _ := newInvoiceSvc()
	custID := uuid.New()
	ir.On("ListByCustomer", mock.Anything, custID, 50).Return([]*model.Invoice{}, nil)
	got, err := svc.ListByCustomer(context.Background(), custID, 0)
	assert.NoError(t, err)
	assert.NotNil(t, got)
	assert.NotNil(t, svc)
}

func TestInvoiceService_ListByCustomer_NilUUID(t *testing.T) {
	svc, _, _, _ := newInvoiceSvc()
	_, err := svc.ListByCustomer(context.Background(), uuid.Nil, 10)
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestInvoiceService_ListOverdue(t *testing.T) {
	svc, ir, _, _ := newInvoiceSvc()
	ir.On("ListOverdue", mock.Anything).Return([]*model.Invoice{}, nil)
	got, err := svc.ListOverdue(context.Background())
	assert.NoError(t, err)
	assert.NotNil(t, got)
	assert.NotNil(t, svc)
}

func TestInvoiceService_MarkOverdue(t *testing.T) {
	svc, ir, _, _ := newInvoiceSvc()
	overdue := []*model.Invoice{
		{ID: uuid.New(), Status: model.InvoiceStatusIssued},
		{ID: uuid.New(), Status: model.InvoiceStatusOverdue},
	}
	ir.On("ListOverdue", mock.Anything).Return(overdue, nil)
	ir.On("UpdateStatus", mock.Anything, overdue[0].ID, model.InvoiceStatusOverdue).Return(nil)
	n, err := svc.MarkOverdue(context.Background(), "actor")
	assert.NoError(t, err)
	assert.Equal(t, 1, n)
	assert.NotNil(t, svc)
}

func TestInvoiceService_TotalOutstanding(t *testing.T) {
	svc, ir, _, _ := newInvoiceSvc()
	ir.On("SumOutstanding", mock.Anything).Return(1234.5, nil)
	got, err := svc.TotalOutstanding(context.Background())
	assert.NoError(t, err)
	assert.InDelta(t, 1234.5, got, 0.01)
	assert.NotNil(t, svc)
}
