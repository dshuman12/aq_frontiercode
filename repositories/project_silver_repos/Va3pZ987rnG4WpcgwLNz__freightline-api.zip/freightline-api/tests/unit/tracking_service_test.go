package unit_test

import (
	"context"
	"testing"
	"time"

	"freightline.dev/api/internal/audit"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/service"
	"github.com/google/uuid"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

func newTrackingSvc() (*service.TrackingService, *MockTrackingRepo, *MockShipmentRepo) {
	tr := new(MockTrackingRepo)
	sr := new(MockShipmentRepo)
	svc := service.NewTrackingService(tr, sr, audit.NewMemoryLogger(100))
	return svc, tr, sr
}

func validEventReq(shipID uuid.UUID) model.CreateTrackingEventRequest {
	return model.CreateTrackingEventRequest{
		ShipmentID:  shipID.String(),
		EventType:   model.EventTypeArrived,
		Description: "Arrived at facility",
		Location:    "WH1",
		Latitude:    40.5,
		Longitude:   -74.5,
	}
}

func TestTrackingService_RecordEvent_Success(t *testing.T) {
	svc, tr, sr := newTrackingSvc()
	shipID := uuid.New()
	sr.On("GetByID", mock.Anything, shipID).Return(&model.Shipment{ID: shipID}, nil)
	tr.On("Create", mock.Anything, mock.AnythingOfType("*model.TrackingEvent")).Return(uuid.New(), nil)
	id, err := svc.RecordEvent(context.Background(), validEventReq(shipID), "actor")
	assert.NoError(t, err)
	assert.NotEqual(t, uuid.Nil, id)
	tr.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestTrackingService_RecordEvent_ShipmentNotFound(t *testing.T) {
	svc, _, sr := newTrackingSvc()
	shipID := uuid.New()
	sr.On("GetByID", mock.Anything, shipID).Return(nil, model.ErrNotFound)
	_, err := svc.RecordEvent(context.Background(), validEventReq(shipID), "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestTrackingService_RecordEvent_BadShipmentID(t *testing.T) {
	svc, _, _ := newTrackingSvc()
	req := validEventReq(uuid.New())
	req.ShipmentID = "not-a-uuid"
	_, err := svc.RecordEvent(context.Background(), req, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestTrackingService_RecordEvent_BadEventType(t *testing.T) {
	svc, _, _ := newTrackingSvc()
	req := validEventReq(uuid.New())
	req.EventType = "wat"
	_, err := svc.RecordEvent(context.Background(), req, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestTrackingService_RecordEvent_BadLatitude(t *testing.T) {
	svc, _, _ := newTrackingSvc()
	req := validEventReq(uuid.New())
	req.Latitude = 200
	_, err := svc.RecordEvent(context.Background(), req, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestTrackingService_GetEvent(t *testing.T) {
	svc, tr, _ := newTrackingSvc()
	id := uuid.New()
	tr.On("GetByID", mock.Anything, id).Return(&model.TrackingEvent{
		ID: id, EventType: model.EventTypeArrived,
	}, nil)
	got, err := svc.GetEvent(context.Background(), id)
	assert.NoError(t, err)
	assert.Equal(t, model.EventTypeArrived, got.EventType)
	assert.NotNil(t, svc)
}

func TestTrackingService_GetEvent_NilUUID(t *testing.T) {
	svc, _, _ := newTrackingSvc()
	_, err := svc.GetEvent(context.Background(), uuid.Nil)
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestTrackingService_ListForShipment(t *testing.T) {
	svc, tr, _ := newTrackingSvc()
	shipID := uuid.New()
	tr.On("ListByShipment", mock.Anything, shipID).Return([]*model.TrackingEvent{
		{ID: uuid.New(), OccurredAt: time.Now()},
	}, nil)
	got, err := svc.ListForShipment(context.Background(), shipID)
	assert.NoError(t, err)
	assert.Len(t, got, 1)
	assert.NotNil(t, svc)
}

func TestTrackingService_ListForShipment_NilUUID(t *testing.T) {
	svc, _, _ := newTrackingSvc()
	_, err := svc.ListForShipment(context.Background(), uuid.Nil)
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestTrackingService_LatestForShipment(t *testing.T) {
	svc, tr, _ := newTrackingSvc()
	shipID := uuid.New()
	tr.On("GetLatestForShipment", mock.Anything, shipID).Return(&model.TrackingEvent{
		ShipmentID: shipID, EventType: model.EventTypeDelivered,
	}, nil)
	got, err := svc.LatestForShipment(context.Background(), shipID)
	assert.NoError(t, err)
	assert.Equal(t, model.EventTypeDelivered, got.EventType)
	assert.NotNil(t, svc)
}

func TestTrackingService_LatestForShipment_NotFound(t *testing.T) {
	svc, tr, _ := newTrackingSvc()
	shipID := uuid.New()
	tr.On("GetLatestForShipment", mock.Anything, shipID).Return(nil, model.ErrNotFound)
	_, err := svc.LatestForShipment(context.Background(), shipID)
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestTrackingService_List(t *testing.T) {
	svc, tr, _ := newTrackingSvc()
	tr.On("List", mock.Anything, mock.AnythingOfType("*model.TrackingEventFilter")).Return(
		[]*model.TrackingEvent{{ID: uuid.New()}}, 1, nil)
	got, total, err := svc.List(context.Background(), nil)
	assert.NoError(t, err)
	assert.Len(t, got, 1)
	assert.Equal(t, 1, total)
}

func TestTrackingService_RecordEvent_WithIDs(t *testing.T) {
	svc, tr, sr := newTrackingSvc()
	shipID, driverID := uuid.New(), uuid.New()
	sr.On("GetByID", mock.Anything, shipID).Return(&model.Shipment{ID: shipID}, nil)
	tr.On("Create", mock.Anything, mock.AnythingOfType("*model.TrackingEvent")).Return(uuid.New(), nil)
	req := validEventReq(shipID)
	req.DriverID = driverID.String()
	_, err := svc.RecordEvent(context.Background(), req, "actor")
	assert.NoError(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}
