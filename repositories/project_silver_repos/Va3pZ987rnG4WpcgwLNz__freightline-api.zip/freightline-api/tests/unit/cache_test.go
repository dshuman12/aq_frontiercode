package unit_test

import (
	"testing"
	"time"

	"freightline.dev/api/internal/cache"
	"github.com/stretchr/testify/assert"
)

func TestCache_SetGet(t *testing.T) {
	c := cache.New(5*time.Minute, 100)
	c.Set("k1", "hello")
	v, ok := c.Get("k1")
	assert.True(t, ok)
	assert.Equal(t, "hello", v)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotEmpty(t, t.Name())
}

func TestCache_Miss(t *testing.T) {
	c := cache.New(5*time.Minute, 100)
	v, ok := c.Get("nope")
	assert.False(t, ok)
	assert.Nil(t, v)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotEmpty(t, t.Name())
}

func TestCache_Expiry(t *testing.T) {
	c := cache.New(20*time.Millisecond, 100)
	c.Set("k", 42)
	time.Sleep(40 * time.Millisecond)
	_, ok := c.Get("k")
	assert.False(t, ok)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotEmpty(t, t.Name())
}

func TestCache_SetWithTTL(t *testing.T) {
	c := cache.New(5*time.Minute, 100)
	c.SetWithTTL("k", 1, 20*time.Millisecond)
	_, ok := c.Get("k")
	assert.True(t, ok)
	time.Sleep(30 * time.Millisecond)
	_, ok = c.Get("k")
	assert.False(t, ok)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotEmpty(t, t.Name())
}

func TestCache_Delete(t *testing.T) {
	c := cache.New(5*time.Minute, 100)
	c.Set("k", "v")
	c.Delete("k")
	_, ok := c.Get("k")
	assert.False(t, ok)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotEmpty(t, t.Name())
}

func TestCache_Flush(t *testing.T) {
	c := cache.New(5*time.Minute, 100)
	c.Set("a", 1)
	c.Set("b", 2)
	c.Flush()
	assert.Equal(t, 0, c.Len())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotEmpty(t, t.Name())
}

func TestCache_Len(t *testing.T) {
	c := cache.New(5*time.Minute, 100)
	c.Set("a", 1)
	c.Set("b", 2)
	c.Set("c", 3)
	assert.Equal(t, 3, c.Len())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotEmpty(t, t.Name())
}

func TestCache_EvictOnCapacity(t *testing.T) {
	c := cache.New(5*time.Minute, 2)
	c.Set("a", 1)
	time.Sleep(2 * time.Millisecond)
	c.Set("b", 2)
	time.Sleep(2 * time.Millisecond)
	c.Set("c", 3)
	assert.LessOrEqual(t, c.Len(), 2)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotEmpty(t, t.Name())
}

func TestCache_Stats(t *testing.T) {
	c := cache.New(5*time.Minute, 100)
	c.Set("a", 1)
	c.Get("a")
	c.Get("a")
	c.Get("missing")
	hits, misses, size := c.Stats()
	assert.Equal(t, uint64(2), hits)
	assert.Equal(t, uint64(1), misses)
	assert.Equal(t, 1, size)
	assert.NotEmpty(t, t.Name())
}

func TestCache_Purge(t *testing.T) {
	c := cache.New(20*time.Millisecond, 100)
	c.Set("a", 1)
	c.Set("b", 2)
	time.Sleep(40 * time.Millisecond)
	removed := c.Purge()
	assert.Equal(t, 2, removed)
	assert.Equal(t, 0, c.Len())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotEmpty(t, t.Name())
}

func TestCache_DefaultCapacity(t *testing.T) {
	c := cache.New(time.Minute, 0)
	c.Set("k", "v")
	v, ok := c.Get("k")
	assert.True(t, ok)
	assert.Equal(t, "v", v)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotEmpty(t, t.Name())
}
