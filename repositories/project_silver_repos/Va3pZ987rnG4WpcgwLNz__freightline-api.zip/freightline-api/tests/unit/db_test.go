package unit_test

import (
	"database/sql"
	"testing"

	"freightline.dev/api/internal/db"
	"github.com/stretchr/testify/assert"
)

func TestDB_IsNoRows_True(t *testing.T) {
	assert.True(t, db.IsNoRows(sql.ErrNoRows))
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestDB_IsNoRows_False(t *testing.T) {
	assert.False(t, db.IsNoRows(sql.ErrTxDone))
	assert.False(t, db.IsNoRows(nil))
	assert.NotPanics(t, func() { _ = t.Name() })
}
