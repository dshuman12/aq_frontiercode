package unit_test

import (
	"context"
	"testing"
	"time"

	"freightline.dev/api/internal/audit"
	"freightline.dev/api/internal/cache"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/service"
	"github.com/google/uuid"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

func newRouteSvc() (*service.RouteService, *MockRouteRepo, *MockShipmentRepo, *MockDriverRepo, *MockVehicleRepo) {
	rr := new(MockRouteRepo)
	sr := new(MockShipmentRepo)
	dr := new(MockDriverRepo)
	vr := new(MockVehicleRepo)
	svc := service.NewRouteService(rr, sr, dr, vr, audit.NewMemoryLogger(100), cache.New(time.Minute, 50))
	return svc, rr, sr, dr, vr
}

func validRouteReq(shipID uuid.UUID) model.CreateRouteRequest {
	return model.CreateRouteRequest{
		Name:           "Morning Run",
		ScheduledStart: time.Now().Format(time.RFC3339),
		ShipmentIDs:    []string{shipID.String()},
	}
}

func TestRouteService_Create_Success(t *testing.T) {
	svc, rr, sr, _, _ := newRouteSvc()
	shipID := uuid.New()
	sr.On("GetByID", mock.Anything, shipID).Return(&model.Shipment{
		ID: shipID, DeliveryAddress: "1 Pine", DeliveryCity: "Reno",
	}, nil)
	rr.On("Create", mock.Anything, mock.AnythingOfType("*model.Route"), mock.AnythingOfType("[]*model.RouteStop")).Return(uuid.New(), nil)
	id, err := svc.Create(context.Background(), validRouteReq(shipID), "actor")
	assert.NoError(t, err)
	assert.NotEqual(t, uuid.Nil, id)
	rr.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestRouteService_Create_NoShipments(t *testing.T) {
	svc, _, _, _, _ := newRouteSvc()
	req := validRouteReq(uuid.New())
	req.ShipmentIDs = nil
	_, err := svc.Create(context.Background(), req, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestRouteService_Create_BadShipmentID(t *testing.T) {
	svc, _, _, _, _ := newRouteSvc()
	req := validRouteReq(uuid.New())
	req.ShipmentIDs = []string{"not-a-uuid"}
	_, err := svc.Create(context.Background(), req, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestRouteService_Create_BadStartTime(t *testing.T) {
	svc, _, _, _, _ := newRouteSvc()
	req := validRouteReq(uuid.New())
	req.ScheduledStart = "not-a-time"
	_, err := svc.Create(context.Background(), req, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestRouteService_Create_MissingName(t *testing.T) {
	svc, _, _, _, _ := newRouteSvc()
	req := validRouteReq(uuid.New())
	req.Name = ""
	_, err := svc.Create(context.Background(), req, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestRouteService_GetByID(t *testing.T) {
	svc, rr, _, _, _ := newRouteSvc()
	id := uuid.New()
	rr.On("GetByID", mock.Anything, id).Return(&model.Route{ID: id, Name: "R1"}, nil)
	got, err := svc.GetByID(context.Background(), id)
	assert.NoError(t, err)
	assert.Equal(t, "R1", got.Name)
	assert.NotNil(t, svc)
}

func TestRouteService_GetByID_NilUUID(t *testing.T) {
	svc, _, _, _, _ := newRouteSvc()
	_, err := svc.GetByID(context.Background(), uuid.Nil)
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestRouteService_GetWithStops(t *testing.T) {
	svc, rr, _, _, _ := newRouteSvc()
	id := uuid.New()
	rr.On("GetWithStops", mock.Anything, id).Return(&model.RouteWithStops{
		Route: &model.Route{ID: id}, Stops: []*model.RouteStop{{}},
	}, nil)
	got, err := svc.GetWithStops(context.Background(), id)
	assert.NoError(t, err)
	assert.Len(t, got.Stops, 1)
	assert.NotNil(t, svc)
}

func TestRouteService_Update_Success(t *testing.T) {
	svc, rr, _, _, _ := newRouteSvc()
	id := uuid.New()
	r := &model.Route{ID: id, Name: "Old", Status: model.RouteStatusPlanned}
	rr.On("GetByID", mock.Anything, id).Return(r, nil)
	rr.On("Update", mock.Anything, id, mock.AnythingOfType("*model.Route")).Return(nil)
	err := svc.Update(context.Background(), id, model.UpdateRouteRequest{Name: "New"}, "actor")
	assert.NoError(t, err)
	assert.Equal(t, "New", r.Name)
	assert.NotNil(t, svc)
}

func TestRouteService_Update_Terminal(t *testing.T) {
	svc, rr, _, _, _ := newRouteSvc()
	id := uuid.New()
	rr.On("GetByID", mock.Anything, id).Return(&model.Route{ID: id, Status: model.RouteStatusCompleted}, nil)
	err := svc.Update(context.Background(), id, model.UpdateRouteRequest{Name: "X"}, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestRouteService_Delete_Success(t *testing.T) {
	svc, rr, _, _, _ := newRouteSvc()
	id := uuid.New()
	rr.On("GetByID", mock.Anything, id).Return(&model.Route{ID: id, Status: model.RouteStatusPlanned}, nil)
	rr.On("Delete", mock.Anything, id).Return(nil)
	err := svc.Delete(context.Background(), id, "actor")
	assert.NoError(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestRouteService_Delete_Active(t *testing.T) {
	svc, rr, _, _, _ := newRouteSvc()
	id := uuid.New()
	rr.On("GetByID", mock.Anything, id).Return(&model.Route{ID: id, Status: model.RouteStatusActive}, nil)
	err := svc.Delete(context.Background(), id, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestRouteService_Start_Success(t *testing.T) {
	svc, rr, _, _, _ := newRouteSvc()
	id := uuid.New()
	rr.On("GetByID", mock.Anything, id).Return(&model.Route{ID: id, Status: model.RouteStatusPlanned}, nil)
	rr.On("UpdateStatus", mock.Anything, id, model.RouteStatusActive).Return(nil)
	err := svc.Start(context.Background(), id, "actor")
	assert.NoError(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestRouteService_Start_AlreadyCompleted(t *testing.T) {
	svc, rr, _, _, _ := newRouteSvc()
	id := uuid.New()
	rr.On("GetByID", mock.Anything, id).Return(&model.Route{ID: id, Status: model.RouteStatusCompleted}, nil)
	err := svc.Start(context.Background(), id, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestRouteService_Complete_Success(t *testing.T) {
	svc, rr, _, _, _ := newRouteSvc()
	id := uuid.New()
	rr.On("GetByID", mock.Anything, id).Return(&model.Route{ID: id, Status: model.RouteStatusActive}, nil)
	rr.On("UpdateStatus", mock.Anything, id, model.RouteStatusCompleted).Return(nil)
	err := svc.Complete(context.Background(), id, "actor")
	assert.NoError(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestRouteService_Complete_NotActive(t *testing.T) {
	svc, rr, _, _, _ := newRouteSvc()
	id := uuid.New()
	rr.On("GetByID", mock.Anything, id).Return(&model.Route{ID: id, Status: model.RouteStatusPlanned}, nil)
	err := svc.Complete(context.Background(), id, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestRouteService_Cancel_Success(t *testing.T) {
	svc, rr, _, _, _ := newRouteSvc()
	id := uuid.New()
	rr.On("GetByID", mock.Anything, id).Return(&model.Route{ID: id, Status: model.RouteStatusPlanned}, nil)
	rr.On("UpdateStatus", mock.Anything, id, model.RouteStatusCancelled).Return(nil)
	err := svc.Cancel(context.Background(), id, "reason", "actor")
	assert.NoError(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestRouteService_Cancel_Completed(t *testing.T) {
	svc, rr, _, _, _ := newRouteSvc()
	id := uuid.New()
	rr.On("GetByID", mock.Anything, id).Return(&model.Route{ID: id, Status: model.RouteStatusCompleted}, nil)
	err := svc.Cancel(context.Background(), id, "x", "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestRouteService_CompleteStop(t *testing.T) {
	svc, rr, _, _, _ := newRouteSvc()
	stopID := uuid.New()
	rr.On("CompleteStop", mock.Anything, stopID).Return(nil)
	err := svc.CompleteStop(context.Background(), stopID, "actor")
	assert.NoError(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestRouteService_List(t *testing.T) {
	svc, rr, _, _, _ := newRouteSvc()
	rr.On("List", mock.Anything, mock.AnythingOfType("*model.RouteFilter")).Return(
		[]*model.Route{{ID: uuid.New()}}, 1, nil)
	got, total, err := svc.List(context.Background(), nil)
	assert.NoError(t, err)
	assert.Len(t, got, 1)
	assert.Equal(t, 1, total)
}

func TestRouteService_ListByDriver(t *testing.T) {
	svc, rr, _, _, _ := newRouteSvc()
	drvID := uuid.New()
	rr.On("ListByDriver", mock.Anything, drvID, 50).Return([]*model.Route{}, nil)
	got, err := svc.ListByDriver(context.Background(), drvID, 0)
	assert.NoError(t, err)
	assert.NotNil(t, got)
	assert.NotNil(t, svc)
}

func TestRouteService_ListByDriver_NilUUID(t *testing.T) {
	svc, _, _, _, _ := newRouteSvc()
	_, err := svc.ListByDriver(context.Background(), uuid.Nil, 10)
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}
