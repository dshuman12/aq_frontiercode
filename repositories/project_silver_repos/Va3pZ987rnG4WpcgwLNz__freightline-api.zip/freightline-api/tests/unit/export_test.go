package unit_test

import (
	"bytes"
	"encoding/json"
	"strings"
	"testing"
	"time"

	"freightline.dev/api/internal/export"
	"github.com/stretchr/testify/assert"
)

func TestExport_ToCSV(t *testing.T) {
	e := export.New()
	out, err := e.ToCSV(
		[]string{"name", "age"},
		[][]string{{"Sam", "30"}, {"Joe", "25"}},
	)
	assert.NoError(t, err)
	assert.Contains(t, string(out), "name,age")
	assert.Contains(t, string(out), "Sam,30")
	assert.Contains(t, string(out), "Joe,25")
}

func TestExport_ToJSON(t *testing.T) {
	e := export.New()
	out, err := e.ToJSON(
		[]string{"a", "b"},
		[][]string{{"1", "2"}, {"3", "4"}},
	)
	assert.NoError(t, err)
	var got []map[string]string
	assert.NoError(t, json.Unmarshal(out, &got))
	assert.Len(t, got, 2)
	assert.Equal(t, "1", got[0]["a"])
}

func TestExport_Unsupported(t *testing.T) {
	e := export.New()
	_, err := e.Export(export.Format("xml"), nil, nil)
	assert.Error(t, err)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestExport_CSV_FromExporter(t *testing.T) {
	e := export.New()
	out, err := e.Export(export.FormatCSV, []string{"a"}, [][]string{{"1"}})
	assert.NoError(t, err)
	assert.Contains(t, string(out), "1")
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestExport_StructsToCSV(t *testing.T) {
	type row struct {
		Name string  `export:"Name"`
		Age  int     `export:"Age"`
		At   time.Time `export:"At"`
	}
	now := time.Now()
	rows := []row{{Name: "Sam", Age: 30, At: now}, {Name: "Joe", Age: 40, At: now}}
	e := export.New()
	out, err := e.StructsToCSV(rows)
	assert.NoError(t, err)
	assert.Contains(t, string(out), "Name,Age,At")
	assert.Contains(t, string(out), "Sam,30")
}

func TestExport_StructsToCSV_NotSlice(t *testing.T) {
	e := export.New()
	_, err := e.StructsToCSV(42)
	assert.Error(t, err)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestExport_StructsToCSV_Empty(t *testing.T) {
	e := export.New()
	out, err := e.StructsToCSV([]struct{ Name string }{})
	assert.NoError(t, err)
	assert.Empty(t, out)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestExport_Stream(t *testing.T) {
	e := export.New()
	var buf bytes.Buffer
	err := e.Stream(export.FormatCSV, []string{"a"}, [][]string{{"1"}}, &buf)
	assert.NoError(t, err)
	assert.Contains(t, buf.String(), "1")
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestExport_WithDateLayout(t *testing.T) {
	e := export.New().WithDateLayout("2006-01-02")
	type row struct {
		At time.Time `export:"at"`
	}
	out, err := e.StructsToCSV([]row{{At: time.Date(2024, 1, 5, 12, 0, 0, 0, time.UTC)}})
	assert.NoError(t, err)
	assert.True(t, strings.Contains(string(out), "2024-01-05"))
	assert.NotPanics(t, func() { _ = t.Name() })
}
