package unit_test

import (
	"context"
	"testing"
	"time"

	"freightline.dev/api/internal/audit"
	"github.com/google/uuid"
	"github.com/stretchr/testify/assert"
)

func TestAuditLogger_Log(t *testing.T) {
	l := audit.NewMemoryLogger(100)
	l.Log(context.Background(), &audit.Entry{
		ActorID:    "user-1",
		EntityType: "customer",
		Action:     audit.ActionCreate,
	})
	assert.Equal(t, 1, l.Count())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotEmpty(t, t.Name())
}

func TestAuditLogger_Nil(t *testing.T) {
	l := audit.NewMemoryLogger(100)
	l.Log(context.Background(), nil)
	assert.Equal(t, 0, l.Count())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotEmpty(t, t.Name())
}

func TestAuditLogger_AutoFillsIDAndTime(t *testing.T) {
	l := audit.NewMemoryLogger(100)
	e := &audit.Entry{ActorID: "u", EntityType: "x", Action: audit.ActionUpdate}
	l.Log(context.Background(), e)
	assert.NotEqual(t, uuid.Nil, e.ID)
	assert.False(t, e.Timestamp.IsZero())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotEmpty(t, t.Name())
}

func TestAuditLogger_Recent(t *testing.T) {
	l := audit.NewMemoryLogger(100)
	for i := 0; i < 5; i++ {
		l.Log(context.Background(), &audit.Entry{ActorID: "u", EntityType: "x"})
	}
	got := l.Recent(3)
	assert.Len(t, got, 3)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotEmpty(t, t.Name())
}

func TestAuditLogger_Recent_AllZero(t *testing.T) {
	l := audit.NewMemoryLogger(100)
	got := l.Recent(0)
	assert.Empty(t, got)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotEmpty(t, t.Name())
}

func TestAuditLogger_Query_ByActor(t *testing.T) {
	l := audit.NewMemoryLogger(100)
	l.Log(context.Background(), &audit.Entry{ActorID: "alice", EntityType: "x"})
	l.Log(context.Background(), &audit.Entry{ActorID: "bob", EntityType: "x"})
	l.Log(context.Background(), &audit.Entry{ActorID: "alice", EntityType: "x"})
	got := l.Query(audit.EntryFilter{ActorID: "alice"})
	assert.Len(t, got, 2)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotEmpty(t, t.Name())
}

func TestAuditLogger_Query_ByEntityType(t *testing.T) {
	l := audit.NewMemoryLogger(100)
	l.Log(context.Background(), &audit.Entry{EntityType: "customer"})
	l.Log(context.Background(), &audit.Entry{EntityType: "shipment"})
	got := l.Query(audit.EntryFilter{EntityType: "shipment"})
	assert.Len(t, got, 1)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotEmpty(t, t.Name())
}

func TestAuditLogger_Query_ByAction(t *testing.T) {
	l := audit.NewMemoryLogger(100)
	l.Log(context.Background(), &audit.Entry{Action: audit.ActionCreate})
	l.Log(context.Background(), &audit.Entry{Action: audit.ActionDelete})
	got := l.Query(audit.EntryFilter{Action: audit.ActionDelete})
	assert.Len(t, got, 1)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotEmpty(t, t.Name())
}

func TestAuditLogger_Query_TimeRange(t *testing.T) {
	l := audit.NewMemoryLogger(100)
	now := time.Now()
	old := &audit.Entry{ActorID: "u"}
	old.Timestamp = now.Add(-time.Hour)
	l.Log(context.Background(), old)
	fresh := &audit.Entry{ActorID: "u"}
	l.Log(context.Background(), fresh)
	got := l.Query(audit.EntryFilter{From: now.Add(-30 * time.Minute)})
	assert.GreaterOrEqual(t, len(got), 1)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotEmpty(t, t.Name())
}

func TestAuditLogger_MaxRotation(t *testing.T) {
	l := audit.NewMemoryLogger(3)
	for i := 0; i < 5; i++ {
		l.Log(context.Background(), &audit.Entry{ActorID: "u"})
	}
	assert.Equal(t, 3, l.Count())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotEmpty(t, t.Name())
}

func TestAuditLogger_Flush(t *testing.T) {
	l := audit.NewMemoryLogger(100)
	l.Log(context.Background(), &audit.Entry{ActorID: "u"})
	l.Flush()
	assert.Equal(t, 0, l.Count())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotEmpty(t, t.Name())
}

func TestAuditEntry_ToJSON(t *testing.T) {
	e := &audit.Entry{
		ID: uuid.New(), ActorID: "u", EntityType: "x", Action: audit.ActionCreate,
		Timestamp: time.Now(),
	}
	j, err := e.ToJSON()
	assert.NoError(t, err)
	assert.Contains(t, string(j), "actor_id")
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotEmpty(t, t.Name())
}
