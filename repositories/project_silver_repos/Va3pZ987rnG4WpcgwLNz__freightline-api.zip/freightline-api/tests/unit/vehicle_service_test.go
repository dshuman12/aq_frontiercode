package unit_test

import (
	"context"
	"errors"
	"testing"
	"time"

	"freightline.dev/api/internal/audit"
	"freightline.dev/api/internal/cache"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/service"
	"github.com/google/uuid"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

func newVehicleSvc() (*service.VehicleService, *MockVehicleRepo) {
	repo := new(MockVehicleRepo)
	svc := service.NewVehicleService(repo, audit.NewMemoryLogger(100), cache.New(5*time.Minute, 100))
	return svc, repo
}

func validVehicleReq() model.CreateVehicleRequest {
	return model.CreateVehicleRequest{
		PlateNumber: "ABC-1234",
		VIN:         "1HGCM82633A123456",
		Make:        "Volvo",
		Model:       "FH16",
		Year:        2020,
		Type:        model.VehicleTypeSemi,
		CapacityKg:  20000,
	}
}

func TestVehicleService_Create_Success(t *testing.T) {
	svc, repo := newVehicleSvc()
	repo.On("GetByPlate", mock.Anything, "ABC-1234").Return(nil, model.ErrNotFound)
	repo.On("GetByVIN", mock.Anything, "1HGCM82633A123456").Return(nil, model.ErrNotFound)
	repo.On("Create", mock.Anything, mock.AnythingOfType("*model.Vehicle")).Return(uuid.New(), nil)
	id, err := svc.Create(context.Background(), validVehicleReq(), "actor")
	assert.NoError(t, err)
	assert.NotEqual(t, uuid.Nil, id)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestVehicleService_Create_DuplicatePlate(t *testing.T) {
	svc, repo := newVehicleSvc()
	repo.On("GetByPlate", mock.Anything, "ABC-1234").Return(&model.Vehicle{ID: uuid.New()}, nil)
	_, err := svc.Create(context.Background(), validVehicleReq(), "actor")
	assert.Error(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestVehicleService_Create_DuplicateVIN(t *testing.T) {
	svc, repo := newVehicleSvc()
	repo.On("GetByPlate", mock.Anything, "ABC-1234").Return(nil, model.ErrNotFound)
	repo.On("GetByVIN", mock.Anything, "1HGCM82633A123456").Return(&model.Vehicle{ID: uuid.New()}, nil)
	_, err := svc.Create(context.Background(), validVehicleReq(), "actor")
	assert.Error(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestVehicleService_Create_BadVIN(t *testing.T) {
	svc, _ := newVehicleSvc()
	req := validVehicleReq()
	req.VIN = "SHORT"
	_, err := svc.Create(context.Background(), req, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestVehicleService_Create_BadType(t *testing.T) {
	svc, _ := newVehicleSvc()
	req := validVehicleReq()
	req.Type = "spaceship"
	_, err := svc.Create(context.Background(), req, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestVehicleService_Create_BadYear(t *testing.T) {
	svc, _ := newVehicleSvc()
	req := validVehicleReq()
	req.Year = 1700
	_, err := svc.Create(context.Background(), req, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestVehicleService_GetByID(t *testing.T) {
	svc, repo := newVehicleSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(&model.Vehicle{ID: id, PlateNumber: "X"}, nil)
	got, err := svc.GetByID(context.Background(), id)
	assert.NoError(t, err)
	assert.Equal(t, "X", got.PlateNumber)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestVehicleService_GetByID_NilUUID(t *testing.T) {
	svc, _ := newVehicleSvc()
	_, err := svc.GetByID(context.Background(), uuid.Nil)
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestVehicleService_GetByPlate(t *testing.T) {
	svc, repo := newVehicleSvc()
	repo.On("GetByPlate", mock.Anything, "X").Return(&model.Vehicle{PlateNumber: "X"}, nil)
	got, err := svc.GetByPlate(context.Background(), "X")
	assert.NoError(t, err)
	assert.NotNil(t, got)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestVehicleService_GetByPlate_Empty(t *testing.T) {
	svc, _ := newVehicleSvc()
	_, err := svc.GetByPlate(context.Background(), "")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestVehicleService_Update_Success(t *testing.T) {
	svc, repo := newVehicleSvc()
	id := uuid.New()
	v := &model.Vehicle{ID: id, OdometerKm: 100}
	repo.On("GetByID", mock.Anything, id).Return(v, nil)
	repo.On("Update", mock.Anything, id, mock.AnythingOfType("*model.Vehicle")).Return(nil)
	err := svc.Update(context.Background(), id, model.UpdateVehicleRequest{OdometerKm: 200}, "actor")
	assert.NoError(t, err)
	assert.Equal(t, 200.0, v.OdometerKm)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestVehicleService_Update_OdometerCantDecrease(t *testing.T) {
	svc, repo := newVehicleSvc()
	id := uuid.New()
	v := &model.Vehicle{ID: id, OdometerKm: 500}
	repo.On("GetByID", mock.Anything, id).Return(v, nil)
	err := svc.Update(context.Background(), id, model.UpdateVehicleRequest{OdometerKm: 100}, "actor")
	assert.Error(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestVehicleService_Update_NotFound(t *testing.T) {
	svc, repo := newVehicleSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(nil, model.ErrNotFound)
	err := svc.Update(context.Background(), id, model.UpdateVehicleRequest{}, "actor")
	assert.Error(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestVehicleService_Delete_Success(t *testing.T) {
	svc, repo := newVehicleSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(&model.Vehicle{ID: id, Status: model.VehicleStatusAvailable}, nil)
	repo.On("Delete", mock.Anything, id).Return(nil)
	err := svc.Delete(context.Background(), id, "actor")
	assert.NoError(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestVehicleService_Delete_InTransit(t *testing.T) {
	svc, repo := newVehicleSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(&model.Vehicle{ID: id, Status: model.VehicleStatusInTransit}, nil)
	err := svc.Delete(context.Background(), id, "actor")
	assert.Error(t, err)
	assert.True(t, errors.Is(err, model.ErrConflict))
	repo.AssertExpectations(t)
}

func TestVehicleService_List(t *testing.T) {
	svc, repo := newVehicleSvc()
	repo.On("List", mock.Anything, mock.AnythingOfType("*model.VehicleFilter")).Return(
		[]*model.Vehicle{{ID: uuid.New()}}, 1, nil)
	got, total, err := svc.List(context.Background(), nil)
	assert.NoError(t, err)
	assert.Len(t, got, 1)
	assert.Equal(t, 1, total)
}

func TestVehicleService_ChangeStatus(t *testing.T) {
	svc, repo := newVehicleSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(&model.Vehicle{ID: id, Status: model.VehicleStatusAvailable}, nil)
	repo.On("UpdateStatus", mock.Anything, id, model.VehicleStatusMaintenance).Return(nil)
	err := svc.ChangeStatus(context.Background(), id, model.VehicleStatusMaintenance, "actor")
	assert.NoError(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestVehicleService_ChangeStatus_Same(t *testing.T) {
	svc, repo := newVehicleSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(&model.Vehicle{ID: id, Status: model.VehicleStatusAvailable}, nil)
	err := svc.ChangeStatus(context.Background(), id, model.VehicleStatusAvailable, "actor")
	assert.NoError(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestVehicleService_RecordTrip_Success(t *testing.T) {
	svc, repo := newVehicleSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(&model.Vehicle{ID: id, OdometerKm: 1000}, nil)
	repo.On("UpdateOdometer", mock.Anything, id, 1500.0).Return(nil)
	err := svc.RecordTrip(context.Background(), id, 500, "actor")
	assert.NoError(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestVehicleService_RecordTrip_ZeroKm(t *testing.T) {
	svc, _ := newVehicleSvc()
	err := svc.RecordTrip(context.Background(), uuid.New(), 0, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestVehicleService_ListAvailable(t *testing.T) {
	svc, repo := newVehicleSvc()
	repo.On("ListAvailable", mock.Anything).Return([]*model.Vehicle{{ID: uuid.New()}}, nil)
	got, err := svc.ListAvailable(context.Background())
	assert.NoError(t, err)
	assert.Len(t, got, 1)
	repo.AssertExpectations(t)
}

func TestVehicleService_ListNeedingService(t *testing.T) {
	svc, repo := newVehicleSvc()
	repo.On("ListNeedingService", mock.Anything).Return([]*model.Vehicle{}, nil)
	got, err := svc.ListNeedingService(context.Background())
	assert.NoError(t, err)
	assert.NotNil(t, got)
	repo.AssertExpectations(t)
}

func TestVehicleService_FindSuitable(t *testing.T) {
	svc, repo := newVehicleSvc()
	repo.On("ListAvailable", mock.Anything).Return([]*model.Vehicle{
		{ID: uuid.New(), Status: model.VehicleStatusAvailable, CapacityKg: 5000, IsRefrigerated: false},
		{ID: uuid.New(), Status: model.VehicleStatusAvailable, CapacityKg: 10000, IsRefrigerated: true},
	}, nil)
	got, err := svc.FindSuitable(context.Background(), 8000, 0, true)
	assert.NoError(t, err)
	assert.Len(t, got, 1)
	repo.AssertExpectations(t)
}

func TestVehicleService_FindSuitable_NoneAvailable(t *testing.T) {
	svc, repo := newVehicleSvc()
	repo.On("ListAvailable", mock.Anything).Return([]*model.Vehicle{}, nil)
	got, err := svc.FindSuitable(context.Background(), 1000, 0, false)
	assert.NoError(t, err)
	assert.Empty(t, got)
	repo.AssertExpectations(t)
}
