package unit_test

import (
	"context"
	"errors"
	"testing"
	"time"

	"freightline.dev/api/internal/audit"
	"freightline.dev/api/internal/cache"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/service"
	"github.com/google/uuid"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

func newDriverSvc() (*service.DriverService, *MockDriverRepo) {
	repo := new(MockDriverRepo)
	svc := service.NewDriverService(repo, audit.NewMemoryLogger(100), cache.New(5*time.Minute, 100))
	return svc, repo
}

func validDriverReq() model.CreateDriverRequest {
	return model.CreateDriverRequest{
		EmployeeCode: "EMP100",
		FirstName:    "Jane",
		LastName:     "Driver",
		Email:        "jane@example.com",
		Phone:        "5551234567",
		LicenseNumber: "DL12345",
		LicenseClass:  model.LicenseClassA,
		HireDate:      "2020-01-15",
		LicenseExpiry: "2030-01-15",
		HourlyRate:    25,
		PerMileRate:   0.45,
	}
}

func TestDriverService_Create_Success(t *testing.T) {
	svc, repo := newDriverSvc()
	repo.On("GetByEmployeeCode", mock.Anything, "EMP100").Return(nil, model.ErrNotFound)
	repo.On("GetByEmail", mock.Anything, "jane@example.com").Return(nil, model.ErrNotFound)
	repo.On("Create", mock.Anything, mock.AnythingOfType("*model.Driver")).Return(uuid.New(), nil)
	id, err := svc.Create(context.Background(), validDriverReq(), "actor")
	assert.NoError(t, err)
	assert.NotEqual(t, uuid.Nil, id)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestDriverService_Create_DuplicateCode(t *testing.T) {
	svc, repo := newDriverSvc()
	repo.On("GetByEmployeeCode", mock.Anything, "EMP100").Return(&model.Driver{ID: uuid.New()}, nil)
	_, err := svc.Create(context.Background(), validDriverReq(), "actor")
	assert.Error(t, err)
	assert.True(t, errors.Is(err, model.ErrDuplicate))
	repo.AssertExpectations(t)
}

func TestDriverService_Create_DuplicateEmail(t *testing.T) {
	svc, repo := newDriverSvc()
	repo.On("GetByEmployeeCode", mock.Anything, "EMP100").Return(nil, model.ErrNotFound)
	repo.On("GetByEmail", mock.Anything, "jane@example.com").Return(&model.Driver{ID: uuid.New()}, nil)
	_, err := svc.Create(context.Background(), validDriverReq(), "actor")
	assert.Error(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestDriverService_Create_MissingFields(t *testing.T) {
	svc, _ := newDriverSvc()
	req := model.CreateDriverRequest{}
	_, err := svc.Create(context.Background(), req, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestDriverService_Create_BadEmail(t *testing.T) {
	svc, _ := newDriverSvc()
	req := validDriverReq()
	req.Email = "garbage"
	_, err := svc.Create(context.Background(), req, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestDriverService_Create_BadLicenseClass(t *testing.T) {
	svc, _ := newDriverSvc()
	req := validDriverReq()
	req.LicenseClass = "Z"
	_, err := svc.Create(context.Background(), req, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestDriverService_GetByID_Success(t *testing.T) {
	svc, repo := newDriverSvc()
	id := uuid.New()
	d := &model.Driver{ID: id, FirstName: "Jane", LastName: "Doe"}
	repo.On("GetByID", mock.Anything, id).Return(d, nil)
	got, err := svc.GetByID(context.Background(), id)
	assert.NoError(t, err)
	assert.Equal(t, "Jane Doe", got.FullName())
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestDriverService_GetByID_NilUUID(t *testing.T) {
	svc, _ := newDriverSvc()
	_, err := svc.GetByID(context.Background(), uuid.Nil)
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestDriverService_GetByID_NotFound(t *testing.T) {
	svc, repo := newDriverSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(nil, model.ErrNotFound)
	_, err := svc.GetByID(context.Background(), id)
	assert.Error(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestDriverService_GetByEmployeeCode(t *testing.T) {
	svc, repo := newDriverSvc()
	d := &model.Driver{EmployeeCode: "E1"}
	repo.On("GetByEmployeeCode", mock.Anything, "E1").Return(d, nil)
	got, err := svc.GetByEmployeeCode(context.Background(), "E1")
	assert.NoError(t, err)
	assert.NotNil(t, got)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestDriverService_GetByEmployeeCode_Empty(t *testing.T) {
	svc, _ := newDriverSvc()
	_, err := svc.GetByEmployeeCode(context.Background(), "")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestDriverService_Update_Success(t *testing.T) {
	svc, repo := newDriverSvc()
	id := uuid.New()
	d := &model.Driver{ID: id, FirstName: "Old"}
	repo.On("GetByID", mock.Anything, id).Return(d, nil)
	repo.On("Update", mock.Anything, id, mock.AnythingOfType("*model.Driver")).Return(nil)
	err := svc.Update(context.Background(), id, model.UpdateDriverRequest{FirstName: "New"}, "actor")
	assert.NoError(t, err)
	assert.Equal(t, "New", d.FirstName)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestDriverService_Update_NotFound(t *testing.T) {
	svc, repo := newDriverSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(nil, model.ErrNotFound)
	err := svc.Update(context.Background(), id, model.UpdateDriverRequest{}, "actor")
	assert.Error(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestDriverService_Update_BadLicenseClass(t *testing.T) {
	svc, repo := newDriverSvc()
	id := uuid.New()
	d := &model.Driver{ID: id}
	repo.On("GetByID", mock.Anything, id).Return(d, nil)
	err := svc.Update(context.Background(), id, model.UpdateDriverRequest{LicenseClass: "Z"}, "actor")
	assert.Error(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestDriverService_Delete_Success(t *testing.T) {
	svc, repo := newDriverSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(&model.Driver{ID: id, Status: model.DriverStatusInactive}, nil)
	repo.On("Delete", mock.Anything, id).Return(nil)
	err := svc.Delete(context.Background(), id, "actor")
	assert.NoError(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestDriverService_Delete_Active(t *testing.T) {
	svc, repo := newDriverSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(&model.Driver{ID: id, Status: model.DriverStatusActive}, nil)
	err := svc.Delete(context.Background(), id, "actor")
	assert.Error(t, err)
	assert.True(t, errors.Is(err, model.ErrConflict))
	repo.AssertExpectations(t)
}

func TestDriverService_List(t *testing.T) {
	svc, repo := newDriverSvc()
	repo.On("List", mock.Anything, mock.AnythingOfType("*model.DriverFilter")).Return(
		[]*model.Driver{{ID: uuid.New()}}, 1, nil)
	got, total, err := svc.List(context.Background(), &model.DriverFilter{})
	assert.NoError(t, err)
	assert.Len(t, got, 1)
	assert.Equal(t, 1, total)
}

func TestDriverService_ChangeStatus_Success(t *testing.T) {
	svc, repo := newDriverSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(&model.Driver{
		ID: id, Status: model.DriverStatusInactive,
		LicenseExpiry: time.Now().AddDate(1, 0, 0),
	}, nil)
	repo.On("UpdateStatus", mock.Anything, id, model.DriverStatusActive).Return(nil)
	err := svc.ChangeStatus(context.Background(), id, model.DriverStatusActive, "actor")
	assert.NoError(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestDriverService_ChangeStatus_ExpiredLicense(t *testing.T) {
	svc, repo := newDriverSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(&model.Driver{
		ID: id, Status: model.DriverStatusInactive,
		LicenseExpiry: time.Now().AddDate(0, 0, -1),
	}, nil)
	err := svc.ChangeStatus(context.Background(), id, model.DriverStatusActive, "actor")
	assert.Error(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestDriverService_ChangeStatus_SameStatus(t *testing.T) {
	svc, repo := newDriverSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(&model.Driver{ID: id, Status: model.DriverStatusActive}, nil)
	err := svc.ChangeStatus(context.Background(), id, model.DriverStatusActive, "actor")
	assert.NoError(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestDriverService_RecordDelivery_Success(t *testing.T) {
	svc, repo := newDriverSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(&model.Driver{ID: id}, nil)
	repo.On("IncrementDeliveries", mock.Anything, id, 120.0).Return(nil)
	err := svc.RecordDelivery(context.Background(), id, 120, "actor")
	assert.NoError(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestDriverService_RecordDelivery_NegativeMiles(t *testing.T) {
	svc, _ := newDriverSvc()
	err := svc.RecordDelivery(context.Background(), uuid.New(), -5, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestDriverService_ListAvailable(t *testing.T) {
	svc, repo := newDriverSvc()
	repo.On("ListAvailable", mock.Anything).Return([]*model.Driver{{ID: uuid.New()}}, nil)
	got, err := svc.ListAvailable(context.Background())
	assert.NoError(t, err)
	assert.Len(t, got, 1)
	repo.AssertExpectations(t)
}

func TestDriverService_ListExpiringLicenses(t *testing.T) {
	svc, repo := newDriverSvc()
	repo.On("ListExpiringLicenses", mock.Anything, 30).Return([]*model.Driver{}, nil)
	got, err := svc.ListExpiringLicenses(context.Background(), 30)
	assert.NoError(t, err)
	assert.NotNil(t, got)
	repo.AssertExpectations(t)
}

func TestDriverService_ListExpiringLicenses_DefaultDays(t *testing.T) {
	svc, repo := newDriverSvc()
	repo.On("ListExpiringLicenses", mock.Anything, 30).Return([]*model.Driver{}, nil)
	_, err := svc.ListExpiringLicenses(context.Background(), 0)
	assert.NoError(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestDriverService_ComputeCommission(t *testing.T) {
	svc, repo := newDriverSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(&model.Driver{
		ID: id, HourlyRate: 20, PerMileRate: 0.5,
	}, nil)
	got, err := svc.ComputeCommission(context.Background(), id, 100, 8)
	assert.NoError(t, err)
	assert.InDelta(t, 210.0, got, 0.01)
	repo.AssertExpectations(t)
}

func TestDriverService_ComputeCommission_NegativeInput(t *testing.T) {
	svc, _ := newDriverSvc()
	_, err := svc.ComputeCommission(context.Background(), uuid.New(), -1, 0)
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}
