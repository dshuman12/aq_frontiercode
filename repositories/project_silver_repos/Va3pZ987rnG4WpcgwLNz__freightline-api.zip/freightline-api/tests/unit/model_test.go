package unit_test

import (
	"testing"
	"time"

	"freightline.dev/api/internal/model"
	"github.com/google/uuid"
	"github.com/stretchr/testify/assert"
)


func TestCustomer_AvailableCredit(t *testing.T) {
	c := &model.Customer{CreditLimit: 1000, OutstandingBal: 400}
	assert.Equal(t, 600.0, c.AvailableCredit())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestCustomer_AvailableCredit_OverLimit(t *testing.T) {
	c := &model.Customer{CreditLimit: 1000, OutstandingBal: 1500}
	assert.Equal(t, 0.0, c.AvailableCredit())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestCustomer_IsOverLimit_True(t *testing.T) {
	c := &model.Customer{CreditLimit: 500, OutstandingBal: 700}
	assert.True(t, c.IsOverLimit())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestCustomer_IsOverLimit_False(t *testing.T) {
	c := &model.Customer{CreditLimit: 500, OutstandingBal: 200}
	assert.False(t, c.IsOverLimit())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestCustomer_CanCharge_Active(t *testing.T) {
	c := &model.Customer{IsActive: true, CreditLimit: 500, OutstandingBal: 100}
	assert.True(t, c.CanCharge(200))
	assert.False(t, c.CanCharge(500))
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestCustomer_CanCharge_Inactive(t *testing.T) {
	c := &model.Customer{IsActive: false, CreditLimit: 1000}
	assert.False(t, c.CanCharge(100))
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestCustomer_CanCharge_NoLimit(t *testing.T) {
	c := &model.Customer{IsActive: true, CreditLimit: 0}
	assert.True(t, c.CanCharge(99999))
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestCustomer_BillingFullAddress(t *testing.T) {
	c := &model.Customer{
		BillingAddress: "123 Main",
		BillingCity:    "Houston",
		BillingState:   "TX",
		BillingZip:     "77001",
		BillingCountry: "USA",
	}
	got := c.BillingFullAddress()
	assert.Contains(t, got, "123 Main")
	assert.Contains(t, got, "Houston")
	assert.Contains(t, got, "TX")
	assert.Contains(t, got, "77001")
	assert.Contains(t, got, "USA")
}

func TestCustomer_ToResponse(t *testing.T) {
	id := uuid.New()
	c := &model.Customer{
		ID: id, CompanyName: "Acme", ContactName: "Joe",
		Email: "j@x.com", IsActive: true, CreatedAt: time.Now(),
	}
	r := c.ToResponse()
	assert.Equal(t, id, r.ID)
	assert.Equal(t, "Acme", r.CompanyName)
	assert.True(t, r.IsActive)
}


func TestDriver_FullName(t *testing.T) {
	d := &model.Driver{FirstName: "Jane", LastName: "Doe"}
	assert.Equal(t, "Jane Doe", d.FullName())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestDriver_IsLicenseExpired_True(t *testing.T) {
	d := &model.Driver{LicenseExpiry: time.Now().AddDate(0, 0, -10)}
	assert.True(t, d.IsLicenseExpired())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestDriver_IsLicenseExpired_False(t *testing.T) {
	d := &model.Driver{LicenseExpiry: time.Now().AddDate(1, 0, 0)}
	assert.False(t, d.IsLicenseExpired())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestDriver_IsLicenseExpired_Zero(t *testing.T) {
	d := &model.Driver{}
	assert.False(t, d.IsLicenseExpired())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestDriver_IsAvailable_True(t *testing.T) {
	d := &model.Driver{
		Status:        model.DriverStatusActive,
		LicenseExpiry: time.Now().AddDate(1, 0, 0),
	}
	assert.True(t, d.IsAvailable())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestDriver_IsAvailable_NotActive(t *testing.T) {
	d := &model.Driver{Status: model.DriverStatusOnLeave}
	assert.False(t, d.IsAvailable())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestDriver_IsAvailable_ExpiredLicense(t *testing.T) {
	d := &model.Driver{
		Status:        model.DriverStatusActive,
		LicenseExpiry: time.Now().AddDate(0, 0, -1),
	}
	assert.False(t, d.IsAvailable())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestDriver_LicenseExpiresInDays(t *testing.T) {
	d := &model.Driver{LicenseExpiry: time.Now().AddDate(0, 0, 30)}
	days := d.LicenseExpiresInDays()
	assert.GreaterOrEqual(t, days, 28)
	assert.LessOrEqual(t, days, 30)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestDriver_AverageMilesPerDelivery(t *testing.T) {
	d := &model.Driver{TotalMilesDriven: 1000, TotalDeliveries: 10}
	assert.InDelta(t, 100.0, d.AverageMilesPerDelivery(), 0.01)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestDriver_AverageMilesPerDelivery_Zero(t *testing.T) {
	d := &model.Driver{}
	assert.Equal(t, 0.0, d.AverageMilesPerDelivery())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestDriver_YearsOfService(t *testing.T) {
	d := &model.Driver{HireDate: time.Now().AddDate(-2, 0, 0)}
	yrs := d.YearsOfService()
	assert.Greater(t, yrs, 1.9)
	assert.Less(t, yrs, 2.1)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestDriver_ToResponse(t *testing.T) {
	d := &model.Driver{
		ID: uuid.New(), FirstName: "Sam", LastName: "Lee",
		EmployeeCode: "EMP1", Status: model.DriverStatusActive,
	}
	r := d.ToResponse()
	assert.Equal(t, "Sam Lee", r.FullName)
	assert.Equal(t, model.DriverStatusActive, r.Status)
	assert.NotPanics(t, func() { _ = t.Name() })
}


func TestVehicle_IsAvailable(t *testing.T) {
	v := &model.Vehicle{Status: model.VehicleStatusAvailable}
	assert.True(t, v.IsAvailable())
	v.Status = model.VehicleStatusInTransit
	assert.False(t, v.IsAvailable())
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestVehicle_IsInsuranceExpired(t *testing.T) {
	v := &model.Vehicle{InsuranceExpiry: time.Now().AddDate(0, 0, -1)}
	assert.True(t, v.IsInsuranceExpired())
	v.InsuranceExpiry = time.Now().AddDate(1, 0, 0)
	assert.False(t, v.IsInsuranceExpired())
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestVehicle_NeedsService_Date(t *testing.T) {
	v := &model.Vehicle{NextServiceDate: time.Now().AddDate(0, 0, -1)}
	assert.True(t, v.NeedsService())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestVehicle_NeedsService_Mileage(t *testing.T) {
	v := &model.Vehicle{OdometerKm: 50001, NextServiceKm: 50000}
	assert.True(t, v.NeedsService())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestVehicle_NeedsService_False(t *testing.T) {
	v := &model.Vehicle{OdometerKm: 1000, NextServiceKm: 50000}
	assert.False(t, v.NeedsService())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestVehicle_AgeInYears(t *testing.T) {
	v := &model.Vehicle{Year: time.Now().Year() - 5}
	assert.Equal(t, 5, v.AgeInYears())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestVehicle_DepreciationPercent(t *testing.T) {
	v := &model.Vehicle{PurchasePrice: 100000, CurrentValue: 60000}
	assert.InDelta(t, 40.0, v.DepreciationPercent(), 0.01)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestVehicle_DepreciationPercent_Zero(t *testing.T) {
	v := &model.Vehicle{}
	assert.Equal(t, 0.0, v.DepreciationPercent())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestVehicle_CanCarry_OK(t *testing.T) {
	v := &model.Vehicle{
		Status: model.VehicleStatusAvailable, CapacityKg: 1000, CapacityM3: 20,
	}
	assert.True(t, v.CanCarry(500, 10))
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestVehicle_CanCarry_OverWeight(t *testing.T) {
	v := &model.Vehicle{
		Status: model.VehicleStatusAvailable, CapacityKg: 1000,
	}
	assert.False(t, v.CanCarry(1500, 0))
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestVehicle_CanCarry_NotAvailable(t *testing.T) {
	v := &model.Vehicle{Status: model.VehicleStatusMaintenance, CapacityKg: 5000}
	assert.False(t, v.CanCarry(100, 0))
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestVehicle_ToResponse(t *testing.T) {
	v := &model.Vehicle{
		ID: uuid.New(), PlateNumber: "ABC123", Make: "Volvo", Year: 2020,
		Status: model.VehicleStatusAvailable, CapacityKg: 5000,
	}
	r := v.ToResponse()
	assert.Equal(t, "ABC123", r.PlateNumber)
	assert.Equal(t, 5000.0, r.CapacityKg)
	assert.NotPanics(t, func() { _ = t.Name() })
}


func TestWarehouse_AvailableCapacity(t *testing.T) {
	w := &model.Warehouse{Capacity: 1000, UsedCapacity: 300}
	assert.Equal(t, 700.0, w.AvailableCapacity())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestWarehouse_AvailableCapacity_NegativeClamp(t *testing.T) {
	w := &model.Warehouse{Capacity: 500, UsedCapacity: 800}
	assert.Equal(t, 0.0, w.AvailableCapacity())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestWarehouse_UtilizationPercent(t *testing.T) {
	w := &model.Warehouse{Capacity: 1000, UsedCapacity: 250}
	assert.InDelta(t, 25.0, w.UtilizationPercent(), 0.01)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestWarehouse_UtilizationPercent_Zero(t *testing.T) {
	w := &model.Warehouse{}
	assert.Equal(t, 0.0, w.UtilizationPercent())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestWarehouse_IsFull(t *testing.T) {
	w := &model.Warehouse{Capacity: 100, UsedCapacity: 100}
	assert.True(t, w.IsFull())
	w.UsedCapacity = 99
	assert.False(t, w.IsFull())
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestWarehouse_CanAccept(t *testing.T) {
	w := &model.Warehouse{IsActive: true, Capacity: 100, UsedCapacity: 50}
	assert.True(t, w.CanAccept(40))
	assert.False(t, w.CanAccept(60))
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestWarehouse_CanAccept_Inactive(t *testing.T) {
	w := &model.Warehouse{IsActive: false, Capacity: 1000}
	assert.False(t, w.CanAccept(10))
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestWarehouse_FullAddress(t *testing.T) {
	w := &model.Warehouse{
		Address: "1 Industrial", City: "Reno", State: "NV", ZipCode: "89501", Country: "USA",
	}
	got := w.FullAddress()
	assert.Contains(t, got, "Reno")
	assert.Contains(t, got, "NV")
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestWarehouse_HasCoordinates(t *testing.T) {
	w := &model.Warehouse{Latitude: 39.5, Longitude: -119.8}
	assert.True(t, w.HasCoordinates())
	w2 := &model.Warehouse{}
	assert.False(t, w2.HasCoordinates())
	assert.NotPanics(t, func() { _ = t.Name() })
}


func TestShipment_IsAvailable(t *testing.T) {
	s := &model.Shipment{Status: model.ShipmentStatusBooked}
	assert.True(t, s.IsAvailable())
	s.Status = model.ShipmentStatusDelivered
	assert.False(t, s.IsAvailable())
	s.Status = model.ShipmentStatusCancelled
	assert.False(t, s.IsAvailable())
}

func TestShipment_IsTerminal(t *testing.T) {
	terminal := []model.ShipmentStatus{model.ShipmentStatusDelivered, model.ShipmentStatusCancelled, model.ShipmentStatusReturned}
	for _, st := range terminal {
		s := &model.Shipment{Status: st}
		assert.True(t, s.IsTerminal(), "expected terminal for %s", st)
	}
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestShipment_RequiresSpecialVehicle(t *testing.T) {
	s := &model.Shipment{RequiresRefrigeration: true}
	assert.True(t, s.RequiresSpecialVehicle())
	s2 := &model.Shipment{IsHazmat: true}
	assert.True(t, s2.RequiresSpecialVehicle())
	s3 := &model.Shipment{}
	assert.False(t, s3.RequiresSpecialVehicle())
}

func TestShipment_IsDeliveryOverdue(t *testing.T) {
	s := &model.Shipment{
		Status: model.ShipmentStatusInTransit, ScheduledDelivery: time.Now().AddDate(0, 0, -1),
	}
	assert.True(t, s.IsDeliveryOverdue())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestShipment_IsDeliveryOverdue_Delivered(t *testing.T) {
	s := &model.Shipment{
		Status: model.ShipmentStatusDelivered, ScheduledDelivery: time.Now().AddDate(0, 0, -1),
	}
	assert.False(t, s.IsDeliveryOverdue())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestShipment_CalculateTotal(t *testing.T) {
	s := &model.Shipment{BaseRate: 100, FuelSurcharge: 12, InsuranceFee: 5, HandlingFee: 8}
	assert.InDelta(t, 125.0, s.CalculateTotal(), 0.01)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestShipment_CanTransitionTo_Allowed(t *testing.T) {
	s := &model.Shipment{Status: model.ShipmentStatusBooked}
	assert.True(t, s.CanTransitionTo(model.ShipmentStatusPickedUp))
	assert.True(t, s.CanTransitionTo(model.ShipmentStatusCancelled))
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestShipment_CanTransitionTo_Disallowed(t *testing.T) {
	s := &model.Shipment{Status: model.ShipmentStatusDelivered}
	assert.False(t, s.CanTransitionTo(model.ShipmentStatusBooked))
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestShipment_DeliveryDurationDays(t *testing.T) {
	pickup := time.Now().AddDate(0, 0, -2)
	delivery := time.Now()
	s := &model.Shipment{ActualPickup: &pickup, ActualDelivery: &delivery}
	assert.InDelta(t, 2.0, s.DeliveryDurationDays(), 0.1)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestShipment_DeliveryDurationDays_NilPickup(t *testing.T) {
	s := &model.Shipment{}
	assert.Equal(t, 0.0, s.DeliveryDurationDays())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestShipment_ToResponse(t *testing.T) {
	s := &model.Shipment{
		ID: uuid.New(), TrackingNumber: "FL123", Status: model.ShipmentStatusBooked,
		WeightKg: 50, TotalCharge: 200,
	}
	r := s.ToResponse()
	assert.Equal(t, "FL123", r.TrackingNumber)
	assert.Equal(t, 50.0, r.WeightKg)
	assert.Equal(t, 200.0, r.TotalCharge)
}


func TestRoute_ProgressPercent(t *testing.T) {
	r := &model.Route{StopCount: 10, CompletedStops: 5}
	assert.InDelta(t, 50.0, r.ProgressPercent(), 0.01)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestRoute_ProgressPercent_Zero(t *testing.T) {
	r := &model.Route{}
	assert.Equal(t, 0.0, r.ProgressPercent())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestRoute_TotalCost(t *testing.T) {
	r := &model.Route{FuelCost: 100, TollCost: 25}
	assert.Equal(t, 125.0, r.TotalCost())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestRoute_IsOverdue(t *testing.T) {
	r := &model.Route{Status: model.RouteStatusActive, ScheduledEnd: time.Now().AddDate(0, 0, -1)}
	assert.True(t, r.IsOverdue())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestRoute_IsOverdue_Completed(t *testing.T) {
	r := &model.Route{Status: model.RouteStatusCompleted, ScheduledEnd: time.Now().AddDate(0, 0, -1)}
	assert.False(t, r.IsOverdue())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestRoute_CanTransitionTo(t *testing.T) {
	r := &model.Route{Status: model.RouteStatusPlanned}
	assert.True(t, r.CanTransitionTo(model.RouteStatusActive))
	r.Status = model.RouteStatusCompleted
	assert.False(t, r.CanTransitionTo(model.RouteStatusActive))
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestRoute_DistanceVariance(t *testing.T) {
	r := &model.Route{PlannedDistance: 100, ActualDistance: 110}
	assert.Equal(t, 10.0, r.DistanceVariance())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}


func TestCarrier_QuoteShipment(t *testing.T) {
	c := &model.Carrier{BaseRate: 50, PerKgRate: 2, PerKmRate: 0.5, FuelSurchargeRate: 10}
	got := c.QuoteShipment(10, 100)
	assert.InDelta(t, 132.0, got, 0.01)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestCarrier_IsPreferred(t *testing.T) {
	c := &model.Carrier{Rating: 4.5, OnTimeRate: 95}
	assert.True(t, c.IsPreferred())
	c.Rating = 3.0
	assert.False(t, c.IsPreferred())
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestCarrier_PerformanceScore(t *testing.T) {
	c := &model.Carrier{OnTimeRate: 90, DamageRate: 5, Rating: 4.5}
	score := c.PerformanceScore()
	assert.Greater(t, score, 80.0)
	assert.Less(t, score, 100.0)
	assert.NotPanics(t, func() { _ = t.Name() })
}


func TestInvoice_IsOverdue_True(t *testing.T) {
	i := &model.Invoice{Status: model.InvoiceStatusIssued, DueDate: time.Now().AddDate(0, 0, -5)}
	assert.True(t, i.IsOverdue())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestInvoice_IsOverdue_Paid(t *testing.T) {
	i := &model.Invoice{Status: model.InvoiceStatusPaid, DueDate: time.Now().AddDate(0, 0, -5)}
	assert.False(t, i.IsOverdue())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestInvoice_DaysOverdue(t *testing.T) {
	i := &model.Invoice{Status: model.InvoiceStatusIssued, DueDate: time.Now().AddDate(0, 0, -10)}
	days := i.DaysOverdue()
	assert.GreaterOrEqual(t, days, 9)
	assert.LessOrEqual(t, days, 11)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestInvoice_IsPaidInFull(t *testing.T) {
	i := &model.Invoice{BalanceDue: 0}
	assert.True(t, i.IsPaidInFull())
	i.BalanceDue = 50
	assert.False(t, i.IsPaidInFull())
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestInvoiceLineItem_Compute(t *testing.T) {
	li := &model.InvoiceLineItem{Quantity: 2, UnitPrice: 100, Discount: 10, TaxRate: 5}
	assert.InDelta(t, 189.0, li.Compute(), 0.01)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestInvoice_RecomputeTotals(t *testing.T) {
	i := &model.Invoice{}
	lines := []*model.InvoiceLineItem{
		{Quantity: 2, UnitPrice: 100, Discount: 0, TaxRate: 10},
		{Quantity: 1, UnitPrice: 50, Discount: 0, TaxRate: 10},
	}
	i.RecomputeTotals(lines)
	assert.InDelta(t, 250.0, i.Subtotal, 0.01)
	assert.InDelta(t, 25.0, i.TaxAmount, 0.01)
	assert.InDelta(t, 275.0, i.Total, 0.01)
}


func TestPayment_IsCleared(t *testing.T) {
	p := &model.Payment{Status: model.PaymentStatusCleared}
	assert.True(t, p.IsCleared())
	p.Status = model.PaymentStatusPending
	assert.False(t, p.IsCleared())
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestPayment_CanRefund(t *testing.T) {
	p := &model.Payment{Status: model.PaymentStatusCleared}
	assert.True(t, p.CanRefund())
	p.Status = model.PaymentStatusPending
	assert.False(t, p.CanRefund())
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestPayment_DaysToClear(t *testing.T) {
	pd := time.Now().AddDate(0, 0, -5)
	cd := time.Now()
	p := &model.Payment{PaymentDate: pd, ClearedDate: &cd}
	assert.GreaterOrEqual(t, p.DaysToClear(), 4)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}


func TestTrackingEvent_HasCoordinates(t *testing.T) {
	e := &model.TrackingEvent{Latitude: 40.0, Longitude: -74.0}
	assert.True(t, e.HasCoordinates())
	e2 := &model.TrackingEvent{}
	assert.False(t, e2.HasCoordinates())
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestTrackingEvent_Summary_WithDescription(t *testing.T) {
	e := &model.TrackingEvent{Description: "Custom note"}
	assert.Equal(t, "Custom note", e.Summary())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestTrackingEvent_Summary_Delivered(t *testing.T) {
	e := &model.TrackingEvent{EventType: model.EventTypeDelivered}
	assert.Equal(t, "Delivered", e.Summary())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestTrackingEvent_IsTerminal(t *testing.T) {
	e := &model.TrackingEvent{EventType: model.EventTypeDelivered}
	assert.True(t, e.IsTerminal())
	e2 := &model.TrackingEvent{EventType: model.EventTypePickup}
	assert.False(t, e2.IsTerminal())
	assert.NotPanics(t, func() { _ = t.Name() })
}


func TestServiceError_Error(t *testing.T) {
	e := model.NewServiceError("E1", "something", nil)
	assert.Contains(t, e.Error(), "E1")
	assert.Contains(t, e.Error(), "something")
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestServiceError_Unwrap(t *testing.T) {
	inner := model.ErrNotFound
	e := model.NewServiceError("E2", "wrap", inner)
	assert.Equal(t, inner, e.Unwrap())
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}
