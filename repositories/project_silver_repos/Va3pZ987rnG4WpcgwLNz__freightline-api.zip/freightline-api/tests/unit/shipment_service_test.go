package unit_test

import (
	"context"
	"errors"
	"testing"
	"time"

	"freightline.dev/api/internal/audit"
	"freightline.dev/api/internal/cache"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/service"
	"github.com/google/uuid"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

func newShipmentSvc() (*service.ShipmentService, *MockShipmentRepo, *MockTrackingRepo, *MockCustomerRepo, *MockDriverRepo, *MockVehicleRepo) {
	sr := new(MockShipmentRepo)
	tr := new(MockTrackingRepo)
	cr := new(MockCustomerRepo)
	dr := new(MockDriverRepo)
	vr := new(MockVehicleRepo)
	svc := service.NewShipmentService(sr, tr, cr, dr, vr,
		audit.NewMemoryLogger(100), cache.New(5*time.Minute, 100))
	return svc, sr, tr, cr, dr, vr
}

func validShipReq(custID uuid.UUID) model.CreateShipmentRequest {
	return model.CreateShipmentRequest{
		CustomerID:      custID.String(),
		PickupName:      "Sender Inc",
		PickupAddress:   "1 First Ave",
		PickupCity:      "Reno",
		DeliveryName:    "Receiver LLC",
		DeliveryAddress: "5 Second Ave",
		DeliveryCity:    "Phoenix",
		ServiceLevel:    model.ServiceLevelStandard,
		WeightKg:        25,
	}
}

func TestShipmentService_Create_Success(t *testing.T) {
	svc, sr, tr, cr, _, _ := newShipmentSvc()
	custID := uuid.New()
	cr.On("GetByID", mock.Anything, custID).Return(&model.Customer{ID: custID, IsActive: true}, nil)
	sr.On("Create", mock.Anything, mock.AnythingOfType("*model.Shipment")).Return(uuid.New(), nil)
	tr.On("Create", mock.Anything, mock.AnythingOfType("*model.TrackingEvent")).Return(uuid.New(), nil)
	id, err := svc.Create(context.Background(), validShipReq(custID), "actor")
	assert.NoError(t, err)
	assert.NotEqual(t, uuid.Nil, id)
	sr.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestShipmentService_Create_CustomerInactive(t *testing.T) {
	svc, _, _, cr, _, _ := newShipmentSvc()
	custID := uuid.New()
	cr.On("GetByID", mock.Anything, custID).Return(&model.Customer{ID: custID, IsActive: false}, nil)
	_, err := svc.Create(context.Background(), validShipReq(custID), "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestShipmentService_Create_BadCustomerID(t *testing.T) {
	svc, _, _, _, _, _ := newShipmentSvc()
	req := validShipReq(uuid.New())
	req.CustomerID = "not-a-uuid"
	_, err := svc.Create(context.Background(), req, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestShipmentService_Create_MissingWeight(t *testing.T) {
	svc, _, _, _, _, _ := newShipmentSvc()
	req := validShipReq(uuid.New())
	req.WeightKg = 0
	_, err := svc.Create(context.Background(), req, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestShipmentService_Create_BadServiceLevel(t *testing.T) {
	svc, _, _, _, _, _ := newShipmentSvc()
	req := validShipReq(uuid.New())
	req.ServiceLevel = "bogus"
	_, err := svc.Create(context.Background(), req, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestShipmentService_GetByID_Success(t *testing.T) {
	svc, sr, _, _, _, _ := newShipmentSvc()
	id := uuid.New()
	sr.On("GetByID", mock.Anything, id).Return(&model.Shipment{ID: id, TrackingNumber: "FL1"}, nil)
	got, err := svc.GetByID(context.Background(), id)
	assert.NoError(t, err)
	assert.Equal(t, "FL1", got.TrackingNumber)
	sr.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestShipmentService_GetByID_NilUUID(t *testing.T) {
	svc, _, _, _, _, _ := newShipmentSvc()
	_, err := svc.GetByID(context.Background(), uuid.Nil)
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestShipmentService_GetByTrackingNumber(t *testing.T) {
	svc, sr, _, _, _, _ := newShipmentSvc()
	sr.On("GetByTrackingNumber", mock.Anything, "FL123").Return(&model.Shipment{TrackingNumber: "FL123"}, nil)
	got, err := svc.GetByTrackingNumber(context.Background(), "FL123")
	assert.NoError(t, err)
	assert.NotNil(t, got)
	assert.NotNil(t, svc)
}

func TestShipmentService_GetByTrackingNumber_Empty(t *testing.T) {
	svc, _, _, _, _, _ := newShipmentSvc()
	_, err := svc.GetByTrackingNumber(context.Background(), "")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestShipmentService_Update_Success(t *testing.T) {
	svc, sr, _, _, _, _ := newShipmentSvc()
	id := uuid.New()
	s := &model.Shipment{ID: id, Status: model.ShipmentStatusBooked}
	sr.On("GetByID", mock.Anything, id).Return(s, nil)
	sr.On("Update", mock.Anything, id, mock.AnythingOfType("*model.Shipment")).Return(nil)
	err := svc.Update(context.Background(), id, model.UpdateShipmentRequest{DeliveryName: "New"}, "actor")
	assert.NoError(t, err)
	assert.Equal(t, "New", s.DeliveryName)
	sr.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestShipmentService_Update_Terminal(t *testing.T) {
	svc, sr, _, _, _, _ := newShipmentSvc()
	id := uuid.New()
	sr.On("GetByID", mock.Anything, id).Return(&model.Shipment{ID: id, Status: model.ShipmentStatusDelivered}, nil)
	err := svc.Update(context.Background(), id, model.UpdateShipmentRequest{}, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestShipmentService_Cancel_Success(t *testing.T) {
	svc, sr, tr, _, _, _ := newShipmentSvc()
	id := uuid.New()
	sr.On("GetByID", mock.Anything, id).Return(&model.Shipment{ID: id, Status: model.ShipmentStatusBooked}, nil)
	sr.On("UpdateStatus", mock.Anything, id, model.ShipmentStatusCancelled).Return(nil)
	tr.On("Create", mock.Anything, mock.AnythingOfType("*model.TrackingEvent")).Return(uuid.New(), nil)
	err := svc.Cancel(context.Background(), id, "customer request", "actor")
	assert.NoError(t, err)
	sr.AssertExpectations(t)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestShipmentService_Cancel_Delivered(t *testing.T) {
	svc, sr, _, _, _, _ := newShipmentSvc()
	id := uuid.New()
	sr.On("GetByID", mock.Anything, id).Return(&model.Shipment{ID: id, Status: model.ShipmentStatusDelivered}, nil)
	err := svc.Cancel(context.Background(), id, "reason", "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestShipmentService_Cancel_AlreadyCancelled(t *testing.T) {
	svc, sr, _, _, _, _ := newShipmentSvc()
	id := uuid.New()
	sr.On("GetByID", mock.Anything, id).Return(&model.Shipment{ID: id, Status: model.ShipmentStatusCancelled}, nil)
	err := svc.Cancel(context.Background(), id, "reason", "actor")
	assert.NoError(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestShipmentService_AssignDriver_Success(t *testing.T) {
	svc, sr, _, _, dr, _ := newShipmentSvc()
	id, drvID := uuid.New(), uuid.New()
	sr.On("GetByID", mock.Anything, id).Return(&model.Shipment{ID: id, Status: model.ShipmentStatusBooked}, nil)
	dr.On("GetByID", mock.Anything, drvID).Return(&model.Driver{
		ID: drvID, Status: model.DriverStatusActive, LicenseExpiry: time.Now().AddDate(1, 0, 0),
	}, nil)
	sr.On("AssignDriver", mock.Anything, id, drvID).Return(nil)
	err := svc.AssignDriver(context.Background(), id, drvID, "actor")
	assert.NoError(t, err)
	sr.AssertExpectations(t)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestShipmentService_AssignDriver_Unavailable(t *testing.T) {
	svc, sr, _, _, dr, _ := newShipmentSvc()
	id, drvID := uuid.New(), uuid.New()
	sr.On("GetByID", mock.Anything, id).Return(&model.Shipment{ID: id, Status: model.ShipmentStatusBooked}, nil)
	dr.On("GetByID", mock.Anything, drvID).Return(&model.Driver{
		ID: drvID, Status: model.DriverStatusInactive,
	}, nil)
	err := svc.AssignDriver(context.Background(), id, drvID, "actor")
	assert.Error(t, err)
	assert.True(t, errors.Is(err, model.ErrUnavailable))
	assert.NotNil(t, svc)
}

func TestShipmentService_AssignVehicle_Success(t *testing.T) {
	svc, sr, _, _, _, vr := newShipmentSvc()
	id, vID := uuid.New(), uuid.New()
	sr.On("GetByID", mock.Anything, id).Return(&model.Shipment{
		ID: id, Status: model.ShipmentStatusBooked, WeightKg: 500, VolumeM3: 5,
	}, nil)
	vr.On("GetByID", mock.Anything, vID).Return(&model.Vehicle{
		ID: vID, Status: model.VehicleStatusAvailable, CapacityKg: 5000, CapacityM3: 50,
	}, nil)
	sr.On("AssignVehicle", mock.Anything, id, vID).Return(nil)
	err := svc.AssignVehicle(context.Background(), id, vID, "actor")
	assert.NoError(t, err)
	sr.AssertExpectations(t)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestShipmentService_AssignVehicle_NotEnoughCapacity(t *testing.T) {
	svc, sr, _, _, _, vr := newShipmentSvc()
	id, vID := uuid.New(), uuid.New()
	sr.On("GetByID", mock.Anything, id).Return(&model.Shipment{
		ID: id, Status: model.ShipmentStatusBooked, WeightKg: 5000,
	}, nil)
	vr.On("GetByID", mock.Anything, vID).Return(&model.Vehicle{
		ID: vID, Status: model.VehicleStatusAvailable, CapacityKg: 100,
	}, nil)
	err := svc.AssignVehicle(context.Background(), id, vID, "actor")
	assert.Error(t, err)
	assert.True(t, errors.Is(err, model.ErrInsufficient))
	assert.NotNil(t, svc)
}

func TestShipmentService_AssignVehicle_NeedsRefrigeration(t *testing.T) {
	svc, sr, _, _, _, vr := newShipmentSvc()
	id, vID := uuid.New(), uuid.New()
	sr.On("GetByID", mock.Anything, id).Return(&model.Shipment{
		ID: id, Status: model.ShipmentStatusBooked, WeightKg: 100,
		RequiresRefrigeration: true,
	}, nil)
	vr.On("GetByID", mock.Anything, vID).Return(&model.Vehicle{
		ID: vID, Status: model.VehicleStatusAvailable, CapacityKg: 5000, IsRefrigerated: false,
	}, nil)
	err := svc.AssignVehicle(context.Background(), id, vID, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestShipmentService_TransitionStatus_Success(t *testing.T) {
	svc, sr, tr, _, _, _ := newShipmentSvc()
	id := uuid.New()
	sr.On("GetByID", mock.Anything, id).Return(&model.Shipment{ID: id, Status: model.ShipmentStatusBooked}, nil)
	sr.On("UpdateStatus", mock.Anything, id, model.ShipmentStatusPickedUp).Return(nil)
	sr.On("Update", mock.Anything, id, mock.AnythingOfType("*model.Shipment")).Return(nil)
	tr.On("Create", mock.Anything, mock.AnythingOfType("*model.TrackingEvent")).Return(uuid.New(), nil)
	err := svc.TransitionStatus(context.Background(), id, model.ShipmentStatusPickedUp, "WH1", "actor")
	assert.NoError(t, err)
	sr.AssertExpectations(t)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestShipmentService_TransitionStatus_Invalid(t *testing.T) {
	svc, sr, _, _, _, _ := newShipmentSvc()
	id := uuid.New()
	sr.On("GetByID", mock.Anything, id).Return(&model.Shipment{ID: id, Status: model.ShipmentStatusDelivered}, nil)
	err := svc.TransitionStatus(context.Background(), id, model.ShipmentStatusBooked, "", "actor")
	assert.Error(t, err)
	assert.True(t, errors.Is(err, model.ErrInvalidStatus))
	assert.NotNil(t, svc)
}

func TestShipmentService_Delete_Success(t *testing.T) {
	svc, sr, _, _, _, _ := newShipmentSvc()
	id := uuid.New()
	sr.On("GetByID", mock.Anything, id).Return(&model.Shipment{ID: id, Status: model.ShipmentStatusDraft}, nil)
	sr.On("Delete", mock.Anything, id).Return(nil)
	err := svc.Delete(context.Background(), id, "actor")
	assert.NoError(t, err)
	sr.AssertExpectations(t)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestShipmentService_Delete_BookedFails(t *testing.T) {
	svc, sr, _, _, _, _ := newShipmentSvc()
	id := uuid.New()
	sr.On("GetByID", mock.Anything, id).Return(&model.Shipment{ID: id, Status: model.ShipmentStatusBooked}, nil)
	err := svc.Delete(context.Background(), id, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestShipmentService_List(t *testing.T) {
	svc, sr, _, _, _, _ := newShipmentSvc()
	sr.On("List", mock.Anything, mock.AnythingOfType("*model.ShipmentFilter")).Return(
		[]*model.Shipment{{ID: uuid.New()}}, 1, nil)
	got, total, err := svc.List(context.Background(), nil)
	assert.NoError(t, err)
	assert.Len(t, got, 1)
	assert.Equal(t, 1, total)
}

func TestShipmentService_ListByCustomer(t *testing.T) {
	svc, sr, _, _, _, _ := newShipmentSvc()
	custID := uuid.New()
	sr.On("ListByCustomer", mock.Anything, custID, 50).Return([]*model.Shipment{}, nil)
	got, err := svc.ListByCustomer(context.Background(), custID, 0)
	assert.NoError(t, err)
	assert.NotNil(t, got)
	assert.NotNil(t, svc)
}

func TestShipmentService_ListByCustomer_NilUUID(t *testing.T) {
	svc, _, _, _, _, _ := newShipmentSvc()
	_, err := svc.ListByCustomer(context.Background(), uuid.Nil, 10)
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestShipmentService_ListOverdue(t *testing.T) {
	svc, sr, _, _, _, _ := newShipmentSvc()
	sr.On("ListOverdue", mock.Anything).Return([]*model.Shipment{}, nil)
	got, err := svc.ListOverdue(context.Background())
	assert.NoError(t, err)
	assert.NotNil(t, got)
	assert.NotNil(t, svc)
}

func TestShipmentService_StatusCounts(t *testing.T) {
	svc, sr, _, _, _, _ := newShipmentSvc()
	sr.On("CountByStatus", mock.Anything).Return(map[model.ShipmentStatus]int{
		model.ShipmentStatusDelivered: 5,
	}, nil)
	got, err := svc.StatusCounts(context.Background())
	assert.NoError(t, err)
	assert.Equal(t, 5, got[model.ShipmentStatusDelivered])
	assert.NotNil(t, svc)
}

func TestShipmentService_Quote(t *testing.T) {
	svc, _, _, _, _, _ := newShipmentSvc()
	q, err := svc.Quote(context.Background(), 10, model.ServiceLevelStandard, 100)
	assert.NoError(t, err)
	assert.Greater(t, q, 0.0)
	assert.NotNil(t, svc)
}

func TestShipmentService_Quote_BadWeight(t *testing.T) {
	svc, _, _, _, _, _ := newShipmentSvc()
	_, err := svc.Quote(context.Background(), 0, model.ServiceLevelStandard, 0)
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}
