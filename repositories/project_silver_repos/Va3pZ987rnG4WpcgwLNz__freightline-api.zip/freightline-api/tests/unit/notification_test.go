package unit_test

import (
	"context"
	"testing"

	"freightline.dev/api/internal/notification"
	"github.com/stretchr/testify/assert"
)

func TestDispatcher_Email(t *testing.T) {
	d := notification.NewDispatcher(3)
	d.Register(notification.NewLoggingEmailSender("noreply@x.com"))
	err := d.Dispatch(context.Background(), &notification.Notification{
		Channel: notification.ChannelEmail, Recipient: "user@x.com",
		Subject: "Hi", Body: "World",
	})
	assert.NoError(t, err)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestDispatcher_NoSender(t *testing.T) {
	d := notification.NewDispatcher(3)
	err := d.Dispatch(context.Background(), &notification.Notification{
		Channel: notification.ChannelEmail, Recipient: "u@x.com",
	})
	assert.Error(t, err)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestDispatcher_NilNotification(t *testing.T) {
	d := notification.NewDispatcher(3)
	err := d.Dispatch(context.Background(), nil)
	assert.Error(t, err)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestDispatcher_FailedSender(t *testing.T) {
	d := notification.NewDispatcher(2)
	d.Register(notification.NewLoggingEmailSender("noreply@x.com"))
	err := d.Dispatch(context.Background(), &notification.Notification{
		Channel:   notification.ChannelEmail,
		Recipient: "", // triggers failure
	})
	assert.Error(t, err)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestDispatcher_SMS(t *testing.T) {
	d := notification.NewDispatcher(2)
	d.Register(notification.NewLoggingSMSSender("gw"))
	err := d.Dispatch(context.Background(), &notification.Notification{
		Channel: notification.ChannelSMS, Recipient: "+15551234",
	})
	assert.NoError(t, err)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestDispatcher_History(t *testing.T) {
	d := notification.NewDispatcher(2)
	d.Register(notification.NewLoggingEmailSender("noreply@x.com"))
	_ = d.Dispatch(context.Background(), &notification.Notification{
		Channel: notification.ChannelEmail, Recipient: "a@x.com",
	})
	hist := d.History(10)
	assert.GreaterOrEqual(t, len(hist), 1)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestDispatcher_DefaultMaxRetry(t *testing.T) {
	d := notification.NewDispatcher(0)
	d.Register(notification.NewLoggingEmailSender("noreply@x.com"))
	err := d.Dispatch(context.Background(), &notification.Notification{
		Channel: notification.ChannelEmail, Recipient: "a@x.com",
	})
	assert.NoError(t, err)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}
