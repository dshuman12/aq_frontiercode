package unit_test

import (
	"context"
	"errors"
	"testing"
	"time"

	"freightline.dev/api/internal/audit"
	"freightline.dev/api/internal/cache"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/service"
	"github.com/google/uuid"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

func newWarehouseSvc() (*service.WarehouseService, *MockWarehouseRepo) {
	repo := new(MockWarehouseRepo)
	svc := service.NewWarehouseService(repo, audit.NewMemoryLogger(100), cache.New(5*time.Minute, 100))
	return svc, repo
}

func validWarehouseReq() model.CreateWarehouseRequest {
	return model.CreateWarehouseRequest{
		Code: "WH01", Name: "Main Houston",
		Type: model.WarehouseTypeMain,
		Address: "123 Industry Dr", City: "Houston",
		Capacity: 50000, DocksCount: 12,
	}
}

func TestWarehouseService_Create_Success(t *testing.T) {
	svc, repo := newWarehouseSvc()
	repo.On("GetByCode", mock.Anything, "WH01").Return(nil, model.ErrNotFound)
	repo.On("Create", mock.Anything, mock.AnythingOfType("*model.Warehouse")).Return(uuid.New(), nil)
	id, err := svc.Create(context.Background(), validWarehouseReq(), "actor")
	assert.NoError(t, err)
	assert.NotEqual(t, uuid.Nil, id)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestWarehouseService_Create_DuplicateCode(t *testing.T) {
	svc, repo := newWarehouseSvc()
	repo.On("GetByCode", mock.Anything, "WH01").Return(&model.Warehouse{ID: uuid.New()}, nil)
	_, err := svc.Create(context.Background(), validWarehouseReq(), "actor")
	assert.Error(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestWarehouseService_Create_BadType(t *testing.T) {
	svc, _ := newWarehouseSvc()
	req := validWarehouseReq()
	req.Type = "bogus"
	_, err := svc.Create(context.Background(), req, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestWarehouseService_Create_MissingAddress(t *testing.T) {
	svc, _ := newWarehouseSvc()
	req := validWarehouseReq()
	req.Address = ""
	_, err := svc.Create(context.Background(), req, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestWarehouseService_Create_BadLat(t *testing.T) {
	svc, _ := newWarehouseSvc()
	req := validWarehouseReq()
	req.Latitude = 200
	_, err := svc.Create(context.Background(), req, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestWarehouseService_GetByID(t *testing.T) {
	svc, repo := newWarehouseSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(&model.Warehouse{ID: id, Name: "X"}, nil)
	got, err := svc.GetByID(context.Background(), id)
	assert.NoError(t, err)
	assert.Equal(t, "X", got.Name)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestWarehouseService_GetByID_NilUUID(t *testing.T) {
	svc, _ := newWarehouseSvc()
	_, err := svc.GetByID(context.Background(), uuid.Nil)
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestWarehouseService_GetByCode(t *testing.T) {
	svc, repo := newWarehouseSvc()
	repo.On("GetByCode", mock.Anything, "X").Return(&model.Warehouse{Code: "X"}, nil)
	got, err := svc.GetByCode(context.Background(), "X")
	assert.NoError(t, err)
	assert.NotNil(t, got)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestWarehouseService_GetByCode_Empty(t *testing.T) {
	svc, _ := newWarehouseSvc()
	_, err := svc.GetByCode(context.Background(), "")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestWarehouseService_Update_Success(t *testing.T) {
	svc, repo := newWarehouseSvc()
	id := uuid.New()
	w := &model.Warehouse{ID: id, Name: "Old"}
	repo.On("GetByID", mock.Anything, id).Return(w, nil)
	repo.On("Update", mock.Anything, id, mock.AnythingOfType("*model.Warehouse")).Return(nil)
	err := svc.Update(context.Background(), id, model.UpdateWarehouseRequest{Name: "New"}, "actor")
	assert.NoError(t, err)
	assert.Equal(t, "New", w.Name)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestWarehouseService_Update_BadEmail(t *testing.T) {
	svc, repo := newWarehouseSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(&model.Warehouse{ID: id}, nil)
	err := svc.Update(context.Background(), id, model.UpdateWarehouseRequest{ManagerEmail: "garbage"}, "actor")
	assert.Error(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestWarehouseService_Delete_Success(t *testing.T) {
	svc, repo := newWarehouseSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(&model.Warehouse{ID: id, UsedCapacity: 0}, nil)
	repo.On("Delete", mock.Anything, id).Return(nil)
	err := svc.Delete(context.Background(), id, "actor")
	assert.NoError(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestWarehouseService_Delete_NotEmpty(t *testing.T) {
	svc, repo := newWarehouseSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(&model.Warehouse{ID: id, UsedCapacity: 500}, nil)
	err := svc.Delete(context.Background(), id, "actor")
	assert.Error(t, err)
	assert.True(t, errors.Is(err, model.ErrConflict))
	repo.AssertExpectations(t)
}

func TestWarehouseService_List(t *testing.T) {
	svc, repo := newWarehouseSvc()
	repo.On("List", mock.Anything, mock.AnythingOfType("*model.WarehouseFilter")).Return(
		[]*model.Warehouse{{ID: uuid.New()}}, 1, nil)
	got, total, err := svc.List(context.Background(), &model.WarehouseFilter{})
	assert.NoError(t, err)
	assert.Len(t, got, 1)
	assert.Equal(t, 1, total)
}

func TestWarehouseService_Activate_Success(t *testing.T) {
	svc, repo := newWarehouseSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(&model.Warehouse{ID: id, IsActive: false}, nil)
	repo.On("SetActive", mock.Anything, id, true).Return(nil)
	err := svc.Activate(context.Background(), id, "actor")
	assert.NoError(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestWarehouseService_Activate_AlreadyActive(t *testing.T) {
	svc, repo := newWarehouseSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(&model.Warehouse{ID: id, IsActive: true}, nil)
	err := svc.Activate(context.Background(), id, "actor")
	assert.NoError(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
}

func TestWarehouseService_Deactivate_Success(t *testing.T) {
	svc, repo := newWarehouseSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(&model.Warehouse{ID: id, IsActive: true}, nil)
	repo.On("SetActive", mock.Anything, id, false).Return(nil)
	err := svc.Deactivate(context.Background(), id, "actor")
	assert.NoError(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestWarehouseService_ReserveCapacity_Success(t *testing.T) {
	svc, repo := newWarehouseSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(&model.Warehouse{
		ID: id, IsActive: true, Capacity: 1000, UsedCapacity: 200,
	}, nil)
	repo.On("UpdateUsedCapacity", mock.Anything, id, 300.0).Return(nil)
	err := svc.ReserveCapacity(context.Background(), id, 300, "actor")
	assert.NoError(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestWarehouseService_ReserveCapacity_Full(t *testing.T) {
	svc, repo := newWarehouseSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(&model.Warehouse{
		ID: id, IsActive: true, Capacity: 100, UsedCapacity: 90,
	}, nil)
	err := svc.ReserveCapacity(context.Background(), id, 50, "actor")
	assert.Error(t, err)
	assert.True(t, errors.Is(err, model.ErrInsufficient))
	repo.AssertExpectations(t)
}

func TestWarehouseService_ReserveCapacity_NegativeVolume(t *testing.T) {
	svc, _ := newWarehouseSvc()
	err := svc.ReserveCapacity(context.Background(), uuid.New(), -10, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestWarehouseService_ReleaseCapacity_Success(t *testing.T) {
	svc, repo := newWarehouseSvc()
	id := uuid.New()
	repo.On("GetByID", mock.Anything, id).Return(&model.Warehouse{ID: id, UsedCapacity: 500}, nil)
	repo.On("UpdateUsedCapacity", mock.Anything, id, -200.0).Return(nil)
	err := svc.ReleaseCapacity(context.Background(), id, 200, "actor")
	assert.NoError(t, err)
	repo.AssertExpectations(t)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestWarehouseService_ReleaseCapacity_NegativeVolume(t *testing.T) {
	svc, _ := newWarehouseSvc()
	err := svc.ReleaseCapacity(context.Background(), uuid.New(), -1, "actor")
	assert.Error(t, err)
	assert.NotNil(t, svc)
	assert.NotPanics(t, func() { _ = t.Name() })
}
