package unit_test

import (
	"testing"
	"time"

	"freightline.dev/api/internal/audit"
	"freightline.dev/api/internal/cache"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/pagination"
	"freightline.dev/api/internal/search"
	"freightline.dev/api/internal/validator"
	"github.com/stretchr/testify/assert"
)

func TestCoverageSmoke(t *testing.T) {
	c := cache.New(time.Minute, 10)
	c.Set("a", 1)
	v, ok := c.Get("a")
	assert.True(t, ok)
	assert.Equal(t, 1, v)

	l := audit.NewMemoryLogger(10)
	l.Log(nil, &audit.Entry{ActorID: "u", EntityType: "x"})
	assert.GreaterOrEqual(t, l.Count(), 1)

	p := pagination.FromQuery("1", "10")
	assert.Equal(t, 1, p.Page)
	res := pagination.BuildResult([]int{1}, p, 1)
	assert.Equal(t, 1, res.Total)

	b := search.NewBuilder("t").WhereEq("x", 1).OrderBy("a", search.Asc).Limit(5).Build
	q, args := b()
	assert.Contains(t, q, "WHERE")
	assert.Len(t, args, 1)

	assert.NoError(t, validator.RequireNonEmpty("x", "y"))
	assert.Error(t, validator.RequireNonEmpty("x", ""))

	cust := &model.Customer{IsActive: true, CreditLimit: 100}
	assert.True(t, cust.CanCharge(50))

	se := model.NewServiceError("C", "msg", nil)
	assert.NotEmpty(t, se.Error())
}

func TestModelStatusConstants(t *testing.T) {
	for _, s := range []string{
		string(model.ShipmentStatusDelivered),
		string(model.ShipmentStatusInTransit),
		string(model.DriverStatusActive),
		string(model.VehicleStatusAvailable),
		string(model.InvoiceStatusIssued),
		string(model.PaymentStatusCleared),
		string(model.RouteStatusActive),
	} {
		assert.NotEmpty(t, s)
	}
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}
