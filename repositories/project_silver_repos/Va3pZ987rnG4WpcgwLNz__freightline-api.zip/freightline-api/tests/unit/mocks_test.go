package unit_test

import (
	"context"

	"freightline.dev/api/internal/model"
	"github.com/google/uuid"
	"github.com/stretchr/testify/mock"
)

type MockCustomerRepo struct{ mock.Mock }

func (m *MockCustomerRepo) Create(ctx context.Context, c *model.Customer) (uuid.UUID, error) {
	args := m.Called(ctx, c)
	return args.Get(0).(uuid.UUID), args.Error(1)
}
func (m *MockCustomerRepo) GetByID(ctx context.Context, id uuid.UUID) (*model.Customer, error) {
	args := m.Called(ctx, id)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*model.Customer), args.Error(1)
}
func (m *MockCustomerRepo) GetByEmail(ctx context.Context, email string) (*model.Customer, error) {
	args := m.Called(ctx, email)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*model.Customer), args.Error(1)
}
func (m *MockCustomerRepo) Update(ctx context.Context, id uuid.UUID, c *model.Customer) error {
	return m.Called(ctx, id, c).Error(0)
}
func (m *MockCustomerRepo) Delete(ctx context.Context, id uuid.UUID) error {
	return m.Called(ctx, id).Error(0)
}
func (m *MockCustomerRepo) List(ctx context.Context, f *model.CustomerFilter) ([]*model.Customer, int, error) {
	args := m.Called(ctx, f)
	return args.Get(0).([]*model.Customer), args.Int(1), args.Error(2)
}
func (m *MockCustomerRepo) UpdateOutstandingBalance(ctx context.Context, id uuid.UUID, delta float64) error {
	return m.Called(ctx, id, delta).Error(0)
}
func (m *MockCustomerRepo) SetActive(ctx context.Context, id uuid.UUID, active bool) error {
	return m.Called(ctx, id, active).Error(0)
}

type MockDriverRepo struct{ mock.Mock }

func (m *MockDriverRepo) Create(ctx context.Context, d *model.Driver) (uuid.UUID, error) {
	args := m.Called(ctx, d)
	return args.Get(0).(uuid.UUID), args.Error(1)
}
func (m *MockDriverRepo) GetByID(ctx context.Context, id uuid.UUID) (*model.Driver, error) {
	args := m.Called(ctx, id)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*model.Driver), args.Error(1)
}
func (m *MockDriverRepo) GetByEmployeeCode(ctx context.Context, code string) (*model.Driver, error) {
	args := m.Called(ctx, code)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*model.Driver), args.Error(1)
}
func (m *MockDriverRepo) GetByEmail(ctx context.Context, email string) (*model.Driver, error) {
	args := m.Called(ctx, email)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*model.Driver), args.Error(1)
}
func (m *MockDriverRepo) Update(ctx context.Context, id uuid.UUID, d *model.Driver) error {
	return m.Called(ctx, id, d).Error(0)
}
func (m *MockDriverRepo) Delete(ctx context.Context, id uuid.UUID) error {
	return m.Called(ctx, id).Error(0)
}
func (m *MockDriverRepo) List(ctx context.Context, f *model.DriverFilter) ([]*model.Driver, int, error) {
	args := m.Called(ctx, f)
	return args.Get(0).([]*model.Driver), args.Int(1), args.Error(2)
}
func (m *MockDriverRepo) UpdateStatus(ctx context.Context, id uuid.UUID, st model.DriverStatus) error {
	return m.Called(ctx, id, st).Error(0)
}
func (m *MockDriverRepo) IncrementDeliveries(ctx context.Context, id uuid.UUID, miles float64) error {
	return m.Called(ctx, id, miles).Error(0)
}
func (m *MockDriverRepo) ListAvailable(ctx context.Context) ([]*model.Driver, error) {
	args := m.Called(ctx)
	return args.Get(0).([]*model.Driver), args.Error(1)
}
func (m *MockDriverRepo) ListExpiringLicenses(ctx context.Context, days int) ([]*model.Driver, error) {
	args := m.Called(ctx, days)
	return args.Get(0).([]*model.Driver), args.Error(1)
}

type MockVehicleRepo struct{ mock.Mock }

func (m *MockVehicleRepo) Create(ctx context.Context, v *model.Vehicle) (uuid.UUID, error) {
	args := m.Called(ctx, v)
	return args.Get(0).(uuid.UUID), args.Error(1)
}
func (m *MockVehicleRepo) GetByID(ctx context.Context, id uuid.UUID) (*model.Vehicle, error) {
	args := m.Called(ctx, id)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*model.Vehicle), args.Error(1)
}
func (m *MockVehicleRepo) GetByPlate(ctx context.Context, plate string) (*model.Vehicle, error) {
	args := m.Called(ctx, plate)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*model.Vehicle), args.Error(1)
}
func (m *MockVehicleRepo) GetByVIN(ctx context.Context, vin string) (*model.Vehicle, error) {
	args := m.Called(ctx, vin)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*model.Vehicle), args.Error(1)
}
func (m *MockVehicleRepo) Update(ctx context.Context, id uuid.UUID, v *model.Vehicle) error {
	return m.Called(ctx, id, v).Error(0)
}
func (m *MockVehicleRepo) Delete(ctx context.Context, id uuid.UUID) error {
	return m.Called(ctx, id).Error(0)
}
func (m *MockVehicleRepo) List(ctx context.Context, f *model.VehicleFilter) ([]*model.Vehicle, int, error) {
	args := m.Called(ctx, f)
	return args.Get(0).([]*model.Vehicle), args.Int(1), args.Error(2)
}
func (m *MockVehicleRepo) UpdateStatus(ctx context.Context, id uuid.UUID, st model.VehicleStatus) error {
	return m.Called(ctx, id, st).Error(0)
}
func (m *MockVehicleRepo) UpdateOdometer(ctx context.Context, id uuid.UUID, km float64) error {
	return m.Called(ctx, id, km).Error(0)
}
func (m *MockVehicleRepo) ListAvailable(ctx context.Context) ([]*model.Vehicle, error) {
	args := m.Called(ctx)
	return args.Get(0).([]*model.Vehicle), args.Error(1)
}
func (m *MockVehicleRepo) ListNeedingService(ctx context.Context) ([]*model.Vehicle, error) {
	args := m.Called(ctx)
	return args.Get(0).([]*model.Vehicle), args.Error(1)
}

type MockWarehouseRepo struct{ mock.Mock }

func (m *MockWarehouseRepo) Create(ctx context.Context, w *model.Warehouse) (uuid.UUID, error) {
	args := m.Called(ctx, w)
	return args.Get(0).(uuid.UUID), args.Error(1)
}
func (m *MockWarehouseRepo) GetByID(ctx context.Context, id uuid.UUID) (*model.Warehouse, error) {
	args := m.Called(ctx, id)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*model.Warehouse), args.Error(1)
}
func (m *MockWarehouseRepo) GetByCode(ctx context.Context, code string) (*model.Warehouse, error) {
	args := m.Called(ctx, code)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*model.Warehouse), args.Error(1)
}
func (m *MockWarehouseRepo) Update(ctx context.Context, id uuid.UUID, w *model.Warehouse) error {
	return m.Called(ctx, id, w).Error(0)
}
func (m *MockWarehouseRepo) Delete(ctx context.Context, id uuid.UUID) error {
	return m.Called(ctx, id).Error(0)
}
func (m *MockWarehouseRepo) List(ctx context.Context, f *model.WarehouseFilter) ([]*model.Warehouse, int, error) {
	args := m.Called(ctx, f)
	return args.Get(0).([]*model.Warehouse), args.Int(1), args.Error(2)
}
func (m *MockWarehouseRepo) UpdateUsedCapacity(ctx context.Context, id uuid.UUID, delta float64) error {
	return m.Called(ctx, id, delta).Error(0)
}
func (m *MockWarehouseRepo) SetActive(ctx context.Context, id uuid.UUID, active bool) error {
	return m.Called(ctx, id, active).Error(0)
}

type MockShipmentRepo struct{ mock.Mock }

func (m *MockShipmentRepo) Create(ctx context.Context, s *model.Shipment) (uuid.UUID, error) {
	args := m.Called(ctx, s)
	return args.Get(0).(uuid.UUID), args.Error(1)
}
func (m *MockShipmentRepo) GetByID(ctx context.Context, id uuid.UUID) (*model.Shipment, error) {
	args := m.Called(ctx, id)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*model.Shipment), args.Error(1)
}
func (m *MockShipmentRepo) GetByTrackingNumber(ctx context.Context, num string) (*model.Shipment, error) {
	args := m.Called(ctx, num)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*model.Shipment), args.Error(1)
}
func (m *MockShipmentRepo) Update(ctx context.Context, id uuid.UUID, s *model.Shipment) error {
	return m.Called(ctx, id, s).Error(0)
}
func (m *MockShipmentRepo) Delete(ctx context.Context, id uuid.UUID) error {
	return m.Called(ctx, id).Error(0)
}
func (m *MockShipmentRepo) List(ctx context.Context, f *model.ShipmentFilter) ([]*model.Shipment, int, error) {
	args := m.Called(ctx, f)
	return args.Get(0).([]*model.Shipment), args.Int(1), args.Error(2)
}
func (m *MockShipmentRepo) UpdateStatus(ctx context.Context, id uuid.UUID, st model.ShipmentStatus) error {
	return m.Called(ctx, id, st).Error(0)
}
func (m *MockShipmentRepo) AssignDriver(ctx context.Context, id, driverID uuid.UUID) error {
	return m.Called(ctx, id, driverID).Error(0)
}
func (m *MockShipmentRepo) AssignVehicle(ctx context.Context, id, vehicleID uuid.UUID) error {
	return m.Called(ctx, id, vehicleID).Error(0)
}
func (m *MockShipmentRepo) AssignCarrier(ctx context.Context, id, carrierID uuid.UUID) error {
	return m.Called(ctx, id, carrierID).Error(0)
}
func (m *MockShipmentRepo) AttachInvoice(ctx context.Context, id, invoiceID uuid.UUID) error {
	return m.Called(ctx, id, invoiceID).Error(0)
}
func (m *MockShipmentRepo) ListByCustomer(ctx context.Context, custID uuid.UUID, limit int) ([]*model.Shipment, error) {
	args := m.Called(ctx, custID, limit)
	return args.Get(0).([]*model.Shipment), args.Error(1)
}
func (m *MockShipmentRepo) ListByDriver(ctx context.Context, driverID uuid.UUID, limit int) ([]*model.Shipment, error) {
	args := m.Called(ctx, driverID, limit)
	return args.Get(0).([]*model.Shipment), args.Error(1)
}
func (m *MockShipmentRepo) ListByVehicle(ctx context.Context, vehicleID uuid.UUID, limit int) ([]*model.Shipment, error) {
	args := m.Called(ctx, vehicleID, limit)
	return args.Get(0).([]*model.Shipment), args.Error(1)
}
func (m *MockShipmentRepo) ListOverdue(ctx context.Context) ([]*model.Shipment, error) {
	args := m.Called(ctx)
	return args.Get(0).([]*model.Shipment), args.Error(1)
}
func (m *MockShipmentRepo) CountByStatus(ctx context.Context) (map[model.ShipmentStatus]int, error) {
	args := m.Called(ctx)
	return args.Get(0).(map[model.ShipmentStatus]int), args.Error(1)
}

type MockTrackingRepo struct{ mock.Mock }

func (m *MockTrackingRepo) Create(ctx context.Context, e *model.TrackingEvent) (uuid.UUID, error) {
	args := m.Called(ctx, e)
	return args.Get(0).(uuid.UUID), args.Error(1)
}
func (m *MockTrackingRepo) GetByID(ctx context.Context, id uuid.UUID) (*model.TrackingEvent, error) {
	args := m.Called(ctx, id)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*model.TrackingEvent), args.Error(1)
}
func (m *MockTrackingRepo) ListByShipment(ctx context.Context, shipmentID uuid.UUID) ([]*model.TrackingEvent, error) {
	args := m.Called(ctx, shipmentID)
	return args.Get(0).([]*model.TrackingEvent), args.Error(1)
}
func (m *MockTrackingRepo) List(ctx context.Context, f *model.TrackingEventFilter) ([]*model.TrackingEvent, int, error) {
	args := m.Called(ctx, f)
	return args.Get(0).([]*model.TrackingEvent), args.Int(1), args.Error(2)
}
func (m *MockTrackingRepo) GetLatestForShipment(ctx context.Context, shipmentID uuid.UUID) (*model.TrackingEvent, error) {
	args := m.Called(ctx, shipmentID)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*model.TrackingEvent), args.Error(1)
}

type MockCarrierRepo struct{ mock.Mock }

func (m *MockCarrierRepo) Create(ctx context.Context, c *model.Carrier) (uuid.UUID, error) {
	args := m.Called(ctx, c)
	return args.Get(0).(uuid.UUID), args.Error(1)
}
func (m *MockCarrierRepo) GetByID(ctx context.Context, id uuid.UUID) (*model.Carrier, error) {
	args := m.Called(ctx, id)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*model.Carrier), args.Error(1)
}
func (m *MockCarrierRepo) GetByCode(ctx context.Context, code string) (*model.Carrier, error) {
	args := m.Called(ctx, code)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*model.Carrier), args.Error(1)
}
func (m *MockCarrierRepo) Update(ctx context.Context, id uuid.UUID, c *model.Carrier) error {
	return m.Called(ctx, id, c).Error(0)
}
func (m *MockCarrierRepo) Delete(ctx context.Context, id uuid.UUID) error {
	return m.Called(ctx, id).Error(0)
}
func (m *MockCarrierRepo) List(ctx context.Context, f *model.CarrierFilter) ([]*model.Carrier, int, error) {
	args := m.Called(ctx, f)
	return args.Get(0).([]*model.Carrier), args.Int(1), args.Error(2)
}
func (m *MockCarrierRepo) UpdateStats(ctx context.Context, id uuid.UUID, ot, dmg float64, total int) error {
	return m.Called(ctx, id, ot, dmg, total).Error(0)
}
func (m *MockCarrierRepo) SetActive(ctx context.Context, id uuid.UUID, active bool) error {
	return m.Called(ctx, id, active).Error(0)
}

type MockInvoiceRepo struct{ mock.Mock }

func (m *MockInvoiceRepo) Create(ctx context.Context, inv *model.Invoice, lines []*model.InvoiceLineItem) (uuid.UUID, error) {
	args := m.Called(ctx, inv, lines)
	return args.Get(0).(uuid.UUID), args.Error(1)
}
func (m *MockInvoiceRepo) GetByID(ctx context.Context, id uuid.UUID) (*model.Invoice, error) {
	args := m.Called(ctx, id)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*model.Invoice), args.Error(1)
}
func (m *MockInvoiceRepo) GetWithLines(ctx context.Context, id uuid.UUID) (*model.InvoiceWithLines, error) {
	args := m.Called(ctx, id)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*model.InvoiceWithLines), args.Error(1)
}
func (m *MockInvoiceRepo) GetByNumber(ctx context.Context, num string) (*model.Invoice, error) {
	args := m.Called(ctx, num)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*model.Invoice), args.Error(1)
}
func (m *MockInvoiceRepo) Update(ctx context.Context, id uuid.UUID, inv *model.Invoice) error {
	return m.Called(ctx, id, inv).Error(0)
}
func (m *MockInvoiceRepo) Delete(ctx context.Context, id uuid.UUID) error {
	return m.Called(ctx, id).Error(0)
}
func (m *MockInvoiceRepo) List(ctx context.Context, f *model.InvoiceFilter) ([]*model.Invoice, int, error) {
	args := m.Called(ctx, f)
	return args.Get(0).([]*model.Invoice), args.Int(1), args.Error(2)
}
func (m *MockInvoiceRepo) UpdateStatus(ctx context.Context, id uuid.UUID, st model.InvoiceStatus) error {
	return m.Called(ctx, id, st).Error(0)
}
func (m *MockInvoiceRepo) ApplyPayment(ctx context.Context, id uuid.UUID, amount float64) error {
	return m.Called(ctx, id, amount).Error(0)
}
func (m *MockInvoiceRepo) ListByCustomer(ctx context.Context, custID uuid.UUID, limit int) ([]*model.Invoice, error) {
	args := m.Called(ctx, custID, limit)
	return args.Get(0).([]*model.Invoice), args.Error(1)
}
func (m *MockInvoiceRepo) ListOverdue(ctx context.Context) ([]*model.Invoice, error) {
	args := m.Called(ctx)
	return args.Get(0).([]*model.Invoice), args.Error(1)
}
func (m *MockInvoiceRepo) SumOutstanding(ctx context.Context) (float64, error) {
	args := m.Called(ctx)
	return args.Get(0).(float64), args.Error(1)
}

type MockPaymentRepo struct{ mock.Mock }

func (m *MockPaymentRepo) Create(ctx context.Context, p *model.Payment) (uuid.UUID, error) {
	args := m.Called(ctx, p)
	return args.Get(0).(uuid.UUID), args.Error(1)
}
func (m *MockPaymentRepo) GetByID(ctx context.Context, id uuid.UUID) (*model.Payment, error) {
	args := m.Called(ctx, id)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*model.Payment), args.Error(1)
}
func (m *MockPaymentRepo) GetByReference(ctx context.Context, ref string) (*model.Payment, error) {
	args := m.Called(ctx, ref)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*model.Payment), args.Error(1)
}
func (m *MockPaymentRepo) Update(ctx context.Context, id uuid.UUID, p *model.Payment) error {
	return m.Called(ctx, id, p).Error(0)
}
func (m *MockPaymentRepo) UpdateStatus(ctx context.Context, id uuid.UUID, st model.PaymentStatus) error {
	return m.Called(ctx, id, st).Error(0)
}
func (m *MockPaymentRepo) List(ctx context.Context, f *model.PaymentFilter) ([]*model.Payment, int, error) {
	args := m.Called(ctx, f)
	return args.Get(0).([]*model.Payment), args.Int(1), args.Error(2)
}
func (m *MockPaymentRepo) ListByInvoice(ctx context.Context, invoiceID uuid.UUID) ([]*model.Payment, error) {
	args := m.Called(ctx, invoiceID)
	return args.Get(0).([]*model.Payment), args.Error(1)
}
func (m *MockPaymentRepo) SumForInvoice(ctx context.Context, invoiceID uuid.UUID) (float64, error) {
	args := m.Called(ctx, invoiceID)
	return args.Get(0).(float64), args.Error(1)
}

type MockRouteRepo struct{ mock.Mock }

func (m *MockRouteRepo) Create(ctx context.Context, r *model.Route, stops []*model.RouteStop) (uuid.UUID, error) {
	args := m.Called(ctx, r, stops)
	return args.Get(0).(uuid.UUID), args.Error(1)
}
func (m *MockRouteRepo) GetByID(ctx context.Context, id uuid.UUID) (*model.Route, error) {
	args := m.Called(ctx, id)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*model.Route), args.Error(1)
}
func (m *MockRouteRepo) GetWithStops(ctx context.Context, id uuid.UUID) (*model.RouteWithStops, error) {
	args := m.Called(ctx, id)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*model.RouteWithStops), args.Error(1)
}
func (m *MockRouteRepo) Update(ctx context.Context, id uuid.UUID, r *model.Route) error {
	return m.Called(ctx, id, r).Error(0)
}
func (m *MockRouteRepo) Delete(ctx context.Context, id uuid.UUID) error {
	return m.Called(ctx, id).Error(0)
}
func (m *MockRouteRepo) List(ctx context.Context, f *model.RouteFilter) ([]*model.Route, int, error) {
	args := m.Called(ctx, f)
	return args.Get(0).([]*model.Route), args.Int(1), args.Error(2)
}
func (m *MockRouteRepo) UpdateStatus(ctx context.Context, id uuid.UUID, st model.RouteStatus) error {
	return m.Called(ctx, id, st).Error(0)
}
func (m *MockRouteRepo) CompleteStop(ctx context.Context, stopID uuid.UUID) error {
	return m.Called(ctx, stopID).Error(0)
}
func (m *MockRouteRepo) ListByDriver(ctx context.Context, driverID uuid.UUID, limit int) ([]*model.Route, error) {
	args := m.Called(ctx, driverID, limit)
	return args.Get(0).([]*model.Route), args.Error(1)
}
