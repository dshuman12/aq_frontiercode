package unit_test

import (
	"errors"
	"strings"
	"testing"
	"time"

	"freightline.dev/api/internal/validator"
	"github.com/stretchr/testify/assert"
)

func TestRequireNonEmpty_Ok(t *testing.T) {
	err := validator.RequireNonEmpty("name", "Sahil")
	assert.NoError(t, err)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestRequireNonEmpty_Empty(t *testing.T) {
	err := validator.RequireNonEmpty("name", "")
	assert.Error(t, err)
	assert.True(t, errors.Is(err, validator.ErrEmptyField))
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestRequireNonEmpty_Spaces(t *testing.T) {
	err := validator.RequireNonEmpty("name", "    ")
	assert.Error(t, err)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestValidateEmail_Ok(t *testing.T) {
	assert.NoError(t, validator.ValidateEmail("a@b.com"))
	assert.NoError(t, validator.ValidateEmail("john.smith+1@sub.example.co"))
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestValidateEmail_Bad(t *testing.T) {
	assert.Error(t, validator.ValidateEmail("not-an-email"))
	assert.Error(t, validator.ValidateEmail("missing@"))
	assert.Error(t, validator.ValidateEmail("@nope.com"))
}

func TestValidateEmail_Empty(t *testing.T) {
	err := validator.ValidateEmail("")
	assert.Error(t, err)
	assert.True(t, errors.Is(err, validator.ErrEmptyField))
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestValidatePhone_Ok(t *testing.T) {
	assert.NoError(t, validator.ValidatePhone("+1 555 123 4567"))
	assert.NoError(t, validator.ValidatePhone("5551234567"))
	assert.NoError(t, validator.ValidatePhone("(555) 123-4567"))
}

func TestValidatePhone_Bad(t *testing.T) {
	assert.Error(t, validator.ValidatePhone("abc123"))
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestValidatePhone_Empty(t *testing.T) {
	assert.NoError(t, validator.ValidatePhone(""))
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestValidateUUID_Ok(t *testing.T) {
	u, err := validator.ValidateUUID("id", "550e8400-e29b-41d4-a716-446655440000")
	assert.NoError(t, err)
	assert.NotEmpty(t, u.String())
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestValidateUUID_Bad(t *testing.T) {
	_, err := validator.ValidateUUID("id", "garbage")
	assert.Error(t, err)
	assert.True(t, errors.Is(err, validator.ErrBadID))
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestValidatePositive(t *testing.T) {
	assert.NoError(t, validator.ValidatePositive("x", 1.5))
	assert.Error(t, validator.ValidatePositive("x", 0))
	assert.Error(t, validator.ValidatePositive("x", -1))
}

func TestValidateNonNegative(t *testing.T) {
	assert.NoError(t, validator.ValidateNonNegative("x", 0))
	assert.NoError(t, validator.ValidateNonNegative("x", 5))
	assert.Error(t, validator.ValidateNonNegative("x", -1))
}

func TestValidateRange(t *testing.T) {
	assert.NoError(t, validator.ValidateRange("x", 5, 0, 10))
	assert.Error(t, validator.ValidateRange("x", -1, 0, 10))
	assert.Error(t, validator.ValidateRange("x", 11, 0, 10))
}

func TestValidatePlateNumber_Ok(t *testing.T) {
	assert.NoError(t, validator.ValidatePlateNumber("ABC-1234"))
	assert.NoError(t, validator.ValidatePlateNumber("XYZ999"))
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestValidatePlateNumber_Bad(t *testing.T) {
	assert.Error(t, validator.ValidatePlateNumber(""))
	assert.Error(t, validator.ValidatePlateNumber("ABCDEFGHIJKLMNOP1234"))
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestValidateZip_Ok(t *testing.T) {
	assert.NoError(t, validator.ValidateZip(""))
	assert.NoError(t, validator.ValidateZip("12345"))
	assert.NoError(t, validator.ValidateZip("M4B 1B3"))
}

func TestValidateZip_Bad(t *testing.T) {
	assert.Error(t, validator.ValidateZip("ABCDEFGHIJKLMNOP"))
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestValidateDateInPast_Ok(t *testing.T) {
	assert.NoError(t, validator.ValidateDateInPast("date", time.Now().AddDate(0, 0, -1)))
	assert.NoError(t, validator.ValidateDateInPast("date", time.Time{}))
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestValidateDateInPast_Future(t *testing.T) {
	err := validator.ValidateDateInPast("date", time.Now().AddDate(0, 0, 1))
	assert.Error(t, err)
	assert.True(t, errors.Is(err, validator.ErrFutureDate))
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestValidateDateInFuture_Past(t *testing.T) {
	err := validator.ValidateDateInFuture("date", time.Now().AddDate(0, 0, -1))
	assert.Error(t, err)
	assert.True(t, errors.Is(err, validator.ErrPastDate))
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestValidateStringLength(t *testing.T) {
	assert.NoError(t, validator.ValidateStringLength("name", "Sahil", 2, 10))
	assert.Error(t, validator.ValidateStringLength("name", "S", 2, 10))
	assert.Error(t, validator.ValidateStringLength("name", strings.Repeat("x", 50), 2, 10))
}

func TestValidateOneOf(t *testing.T) {
	assert.NoError(t, validator.ValidateOneOf("color", "red", []string{"red", "blue"}))
	assert.Error(t, validator.ValidateOneOf("color", "green", []string{"red", "blue"}))
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestValidateAlphaNumeric(t *testing.T) {
	assert.NoError(t, validator.ValidateAlphaNumeric("code", "ABC123"))
	assert.Error(t, validator.ValidateAlphaNumeric("code", "ABC-123"))
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestValidatePassword_Ok(t *testing.T) {
	assert.NoError(t, validator.ValidatePassword("Secret123"))
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestValidatePassword_TooShort(t *testing.T) {
	assert.Error(t, validator.ValidatePassword("Ab1"))
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestValidatePassword_NoUpper(t *testing.T) {
	assert.Error(t, validator.ValidatePassword("secret123"))
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestValidatePassword_NoDigit(t *testing.T) {
	assert.Error(t, validator.ValidatePassword("SecretPass"))
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestSanitize(t *testing.T) {
	got := validator.Sanitize("  hello\x00world  ")
	assert.Equal(t, "helloworld", got)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestCollectErrors_None(t *testing.T) {
	assert.NoError(t, validator.CollectErrors(nil, nil))
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestCollectErrors_Some(t *testing.T) {
	err := validator.CollectErrors(nil, errors.New("a"), errors.New("b"))
	assert.Error(t, err)
	assert.Contains(t, err.Error(), "a")
	assert.Contains(t, err.Error(), "b")
}
