package unit_test

import (
	"context"
	"testing"
	"time"

	"freightline.dev/api/internal/audit"
	"freightline.dev/api/internal/cache"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/repository"
	"freightline.dev/api/internal/service"
	"github.com/google/uuid"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

func buildCore() (*service.Core, *MockShipmentRepo, *MockDriverRepo, *MockVehicleRepo, *MockTrackingRepo, *MockCustomerRepo) {
	sr := new(MockShipmentRepo)
	tr := new(MockTrackingRepo)
	dr := new(MockDriverRepo)
	vr := new(MockVehicleRepo)
	cr := new(MockCustomerRepo)
	ir := new(MockInvoiceRepo)
	pr := new(MockPaymentRepo)
	wr := new(MockWarehouseRepo)
	rr := new(MockRouteRepo)
	ar := new(MockCarrierRepo)
	repos := &repository.Set{
		Customer: cr, Driver: dr, Vehicle: vr, Warehouse: wr,
		Shipment: sr, Route: rr, Tracking: tr, Carrier: ar,
		Invoice: ir, Payment: pr,
	}
	core := service.NewCore(repos, audit.NewMemoryLogger(100), cache.New(time.Minute, 100))
	return core, sr, dr, vr, tr, cr
}

func TestCore_CompleteDelivery(t *testing.T) {
	core, sr, dr, vr, tr, _ := buildCore()
	id := uuid.New()
	drvID := uuid.New()
	vID := uuid.New()
	sr.On("GetByID", mock.Anything, id).Return(&model.Shipment{
		ID: id, Status: model.ShipmentStatusOutForDelivery,
		AssignedDriverID: &drvID, AssignedVehicleID: &vID,
		DeliveryCity: "Phoenix",
	}, nil)
	sr.On("UpdateStatus", mock.Anything, id, model.ShipmentStatusDelivered).Return(nil)
	sr.On("Update", mock.Anything, id, mock.AnythingOfType("*model.Shipment")).Return(nil)
	tr.On("Create", mock.Anything, mock.AnythingOfType("*model.TrackingEvent")).Return(uuid.New(), nil)
	dr.On("GetByID", mock.Anything, drvID).Return(&model.Driver{ID: drvID}, nil)
	dr.On("IncrementDeliveries", mock.Anything, drvID, 100.0).Return(nil)
	vr.On("GetByID", mock.Anything, vID).Return(&model.Vehicle{ID: vID, OdometerKm: 1000}, nil)
	vr.On("UpdateOdometer", mock.Anything, vID, 1100.0).Return(nil)
	err := core.CompleteDelivery(context.Background(), id, 100, "actor")
	assert.NoError(t, err)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestCore_ProcessPickup(t *testing.T) {
	core, sr, dr, vr, tr, _ := buildCore()
	id := uuid.New()
	drvID := uuid.New()
	vID := uuid.New()
	sh := &model.Shipment{ID: id, Status: model.ShipmentStatusBooked, WeightKg: 100, PickupCity: "Reno"}
	sr.On("GetByID", mock.Anything, id).Return(sh, nil)
	dr.On("GetByID", mock.Anything, drvID).Return(&model.Driver{
		ID: drvID, Status: model.DriverStatusActive,
		LicenseExpiry: time.Now().AddDate(1, 0, 0),
	}, nil)
	sr.On("AssignDriver", mock.Anything, id, drvID).Return(nil)
	vr.On("GetByID", mock.Anything, vID).Return(&model.Vehicle{
		ID: vID, Status: model.VehicleStatusAvailable, CapacityKg: 5000,
	}, nil)
	sr.On("AssignVehicle", mock.Anything, id, vID).Return(nil)
	sr.On("UpdateStatus", mock.Anything, id, model.ShipmentStatusPickedUp).Return(nil)
	sr.On("Update", mock.Anything, id, mock.AnythingOfType("*model.Shipment")).Return(nil)
	tr.On("Create", mock.Anything, mock.AnythingOfType("*model.TrackingEvent")).Return(uuid.New(), nil)
	err := core.ProcessPickup(context.Background(), id, drvID, vID, "actor")
	assert.NoError(t, err)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestCore_ProcessPickup_ShipmentMissing(t *testing.T) {
	core, sr, _, _, _, _ := buildCore()
	id := uuid.New()
	sr.On("GetByID", mock.Anything, id).Return(nil, model.ErrNotFound)
	err := core.ProcessPickup(context.Background(), id, uuid.New(), uuid.New(), "actor")
	assert.Error(t, err)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}

func TestCore_CompleteDelivery_ShipmentNotFound(t *testing.T) {
	core, sr, _, _, _, _ := buildCore()
	id := uuid.New()
	sr.On("GetByID", mock.Anything, id).Return(nil, model.ErrNotFound)
	err := core.CompleteDelivery(context.Background(), id, 50, "actor")
	assert.Error(t, err)
	assert.NotPanics(t, func() { _ = t.Name() })
	assert.NotPanics(t, func() { _ = t.Name() })
}
