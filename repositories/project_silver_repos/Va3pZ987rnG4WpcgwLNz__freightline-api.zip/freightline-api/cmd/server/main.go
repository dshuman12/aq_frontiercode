package main

import (
	"context"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"freightline.dev/api/internal/audit"
	"freightline.dev/api/internal/cache"
	"freightline.dev/api/internal/config"
	"freightline.dev/api/internal/db"
	"freightline.dev/api/internal/handler"
	"freightline.dev/api/internal/middleware"
	"freightline.dev/api/internal/notification"
	"freightline.dev/api/internal/repository"
	"freightline.dev/api/internal/service"
	"github.com/gin-gonic/gin"
)

func main() {
	cfg, err := config.Load()
	if err != nil {
		log.Fatalf("config: %v", err)
	}

	if cfg.Server.Mode == "release" {
		gin.SetMode(gin.ReleaseMode)
	}

	var database *db.DB
	if cfg.Database.Host != "" {
		database, err = db.Connect(cfg.Database)
		if err != nil {
			log.Printf("warning: db connect failed: %v (continuing without db)", err)
		}
	}

	c := cache.New(cfg.Cache.TTL, cfg.Cache.Capacity)
	auditLog := audit.NewMemoryLogger(10000)

	dispatcher := notification.NewDispatcher(3)
	dispatcher.Register(notification.NewLoggingEmailSender(cfg.Notify.FromEmail))
	if cfg.Notify.SMSGateway != "" {
		dispatcher.Register(notification.NewLoggingSMSSender(cfg.Notify.SMSGateway))
	}

	repos := buildRepoSet(database)
	core := service.NewCore(repos, auditLog, c)

	jwt := middleware.NewJWT(cfg.JWT.Secret, cfg.JWT.TTL)

	router := setupRouter(cfg, jwt, core, auditLog)

	srv := &http.Server{
		Addr:              ":" + cfg.Server.Port,
		Handler:           router,
		ReadHeaderTimeout: 5 * time.Second,
		ReadTimeout:       30 * time.Second,
		WriteTimeout:      30 * time.Second,
		IdleTimeout:       2 * time.Minute,
	}

	go func() {
		log.Printf("freightline-api listening on :%s mode=%s", cfg.Server.Port, cfg.Server.Mode)
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("listen: %v", err)
		}
	}()

	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit
	log.Println("shutting down...")

	shutdownCtx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	if err := srv.Shutdown(shutdownCtx); err != nil {
		log.Printf("shutdown: %v", err)
	}
	if database != nil {
		_ = database.Close()
	}
}

func buildRepoSet(d *db.DB) *repository.Set {
	if d == nil {
		return &repository.Set{}
	}
	return &repository.Set{
		Customer:  repository.NewPgCustomerRepo(d),
		Driver:    repository.NewPgDriverRepo(d),
		Vehicle:   repository.NewPgVehicleRepo(d),
		Warehouse: repository.NewPgWarehouseRepo(d),
		Shipment:  repository.NewPgShipmentRepo(d),
		Route:     repository.NewPgRouteRepo(d),
		Tracking:  repository.NewPgTrackingRepo(d),
		Carrier:   repository.NewPgCarrierRepo(d),
		Invoice:   repository.NewPgInvoiceRepo(d),
		Payment:   repository.NewPgPaymentRepo(d),
	}
}

func setupRouter(
	cfg *config.Config,
	jwt *middleware.JWT,
	core *service.Core,
	auditLog audit.Logger,
) *gin.Engine {
	r := gin.New()
	r.Use(middleware.Recovery())
	r.Use(middleware.RequestID())
	r.Use(middleware.Logger())
	r.Use(middleware.SecurityHeaders())
	r.Use(middleware.CORS("*"))

	r.GET("/health", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{"status": "ok", "service": "freightline-api"})
	})
	r.GET("/ready", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{"ready": true})
	})

	auth := handler.NewAuthHandler(jwt)
	auth.Register(r.Group("/api/v1"))

	rate := middleware.NewRateLimiter(cfg.Rate.PerSec, cfg.Rate.Burst)

	api := r.Group("/api/v1")
	api.Use(middleware.RequireAuth(jwt))
	api.Use(rate.Limit())
	{
		handler.NewCustomerHandler(core.Customer).Register(api)
		handler.NewDriverHandler(core.Driver).Register(api)
		handler.NewVehicleHandler(core.Vehicle).Register(api)
		handler.NewWarehouseHandler(core.Warehouse).Register(api)
		handler.NewShipmentHandler(core.Shipment, core.Tracking).Register(api)
		handler.NewCarrierHandler(core.Carrier).Register(api)
		handler.NewInvoiceHandler(core.Invoice).Register(api)
		handler.NewPaymentHandler(core.Payment).Register(api)
		handler.NewRouteHandler(core.Route).Register(api)
		handler.NewTrackingHandler(core.Tracking).Register(api)
		handler.NewReportHandler(core.Report).Register(api)
	}

	return r
}
