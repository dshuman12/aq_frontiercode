package export

import (
	"bytes"
	"encoding/csv"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"reflect"
	"strconv"
	"strings"
	"time"
)

type Format string

const (
	FormatCSV  Format = "csv"
	FormatJSON Format = "json"
)

var ErrUnsupportedFormat = errors.New("unsupported export format")

type Exporter struct {
	dateLayout string
}

func New() *Exporter {
	return &Exporter{dateLayout: time.RFC3339}
}

func (e *Exporter) WithDateLayout(layout string) *Exporter {
	e.dateLayout = layout
	return e
}

func (e *Exporter) Export(format Format, headers []string, rows [][]string) ([]byte, error) {
	switch format {
	case FormatCSV:
		return e.ToCSV(headers, rows)
	case FormatJSON:
		return e.ToJSON(headers, rows)
	default:
		return nil, ErrUnsupportedFormat
	}
}

func (e *Exporter) ToCSV(headers []string, rows [][]string) ([]byte, error) {
	var buf bytes.Buffer
	w := csv.NewWriter(&buf)

	if len(headers) > 0 {
		if err := w.Write(headers); err != nil {
			return nil, fmt.Errorf("write headers: %w", err)
		}
	}

	for i, row := range rows {
		if err := w.Write(row); err != nil {
			return nil, fmt.Errorf("write row %d: %w", i, err)
		}
	}

	w.Flush()
	if err := w.Error(); err != nil {
		return nil, err
	}

	return buf.Bytes(), nil
}

func (e *Exporter) ToJSON(headers []string, rows [][]string) ([]byte, error) {
	out := make([]map[string]string, 0, len(rows))
	for _, row := range rows {
		m := make(map[string]string, len(headers))
		for i, h := range headers {
			if i < len(row) {
				m[h] = row[i]
			} else {
				m[h] = ""
			}
		}
		out = append(out, m)
	}
	return json.MarshalIndent(out, "", "  ")
}

func (e *Exporter) StructsToCSV(records interface{}) ([]byte, error) {
	v := reflect.ValueOf(records)
	if v.Kind() != reflect.Slice {
		return nil, errors.New("records must be a slice")
	}

	if v.Len() == 0 {
		return []byte{}, nil
	}

	elem := v.Index(0)
	if elem.Kind() == reflect.Ptr {
		elem = elem.Elem()
	}
	if elem.Kind() != reflect.Struct {
		return nil, errors.New("slice element must be a struct")
	}

	headers := []string{}
	for i := 0; i < elem.Type().NumField(); i++ {
		f := elem.Type().Field(i)
		name := f.Tag.Get("export")
		if name == "" {
			name = f.Tag.Get("json")
			if name != "" {
				name = strings.Split(name, ",")[0]
			}
		}
		if name == "" {
			name = f.Name
		}
		if name == "-" {
			continue
		}
		headers = append(headers, name)
	}

	rows := make([][]string, 0, v.Len())
	for i := 0; i < v.Len(); i++ {
		elem := v.Index(i)
		if elem.Kind() == reflect.Ptr {
			elem = elem.Elem()
		}
		row := []string{}
		for j := 0; j < elem.Type().NumField(); j++ {
			f := elem.Type().Field(j)
			name := f.Tag.Get("export")
			if name == "" {
				name = f.Tag.Get("json")
				if name != "" {
					name = strings.Split(name, ",")[0]
				}
			}
			if name == "-" {
				continue
			}
			row = append(row, formatValue(elem.Field(j), e.dateLayout))
		}
		rows = append(rows, row)
	}

	return e.ToCSV(headers, rows)
}

func formatValue(v reflect.Value, dateLayout string) string {
	if !v.IsValid() {
		return ""
	}
	switch v.Kind() {
	case reflect.String:
		return v.String()
	case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
		return strconv.FormatInt(v.Int(), 10)
	case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64:
		return strconv.FormatUint(v.Uint(), 10)
	case reflect.Float32, reflect.Float64:
		return strconv.FormatFloat(v.Float(), 'f', 2, 64)
	case reflect.Bool:
		return strconv.FormatBool(v.Bool())
	case reflect.Struct:
		if t, ok := v.Interface().(time.Time); ok {
			if t.IsZero() {
				return ""
			}
			return t.Format(dateLayout)
		}
		return fmt.Sprintf("%v", v.Interface())
	default:
		return fmt.Sprintf("%v", v.Interface())
	}
}

func (e *Exporter) Stream(format Format, headers []string, rows [][]string, w io.Writer) error {
	data, err := e.Export(format, headers, rows)
	if err != nil {
		return err
	}
	_, err = w.Write(data)
	return err
}
