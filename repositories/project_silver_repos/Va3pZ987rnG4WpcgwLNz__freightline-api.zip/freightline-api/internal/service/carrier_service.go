package service

import (
	"context"
	"fmt"
	"strings"
	"time"

	"freightline.dev/api/internal/audit"
	"freightline.dev/api/internal/cache"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/repository"
	"freightline.dev/api/internal/validator"
	"github.com/google/uuid"
)

type CarrierService struct {
	repo  repository.CarrierRepository
	audit audit.Logger
	cache *cache.Cache
}

func NewCarrierService(repo repository.CarrierRepository, log audit.Logger, c *cache.Cache) *CarrierService {
	return &CarrierService{repo: repo, audit: log, cache: c}
}

func (s *CarrierService) Create(ctx context.Context, req model.CreateCarrierRequest, actorID string) (uuid.UUID, error) {
	if err := validateCreateCarrier(req); err != nil {
		return uuid.Nil, err
	}
	if existing, _ := s.repo.GetByCode(ctx, req.Code); existing != nil {
		return uuid.Nil, fmt.Errorf("carrier code in use: %w", model.ErrDuplicate)
	}

	c := &model.Carrier{
		ID:                uuid.New(),
		Name:              req.Name,
		Code:              strings.ToUpper(strings.TrimSpace(req.Code)),
		ContactName:       req.ContactName,
		Email:             strings.ToLower(strings.TrimSpace(req.Email)),
		Phone:             req.Phone,
		Address:           req.Address,
		City:              req.City,
		State:             req.State,
		Country:           req.Country,
		ServiceArea:       req.ServiceArea,
		BaseRate:          req.BaseRate,
		PerKgRate:         req.PerKgRate,
		PerKmRate:         req.PerKmRate,
		FuelSurchargeRate: req.FuelSurchargeRate,
		InsurancePolicy:   req.InsurancePolicy,
		InsuranceCoverage: req.InsuranceCoverage,
		TaxID:             req.TaxID,
		IsHazmatCertified: req.IsHazmatCertified,
		IsActive:          true,
		Rating:            3.0,
		OnTimeRate:        100,
		Notes:             req.Notes,
		CreatedAt:         time.Now(),
		UpdatedAt:         time.Now(),
	}

	id, err := s.repo.Create(ctx, c)
	if err != nil {
		return uuid.Nil, fmt.Errorf("create carrier: %w", err)
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "carrier", EntityID: id, Action: audit.ActionCreate,
			NewValues: map[string]interface{}{"name": c.Name, "code": c.Code},
		})
	}
	return id, nil
}

func validateCreateCarrier(req model.CreateCarrierRequest) error {
	if err := validator.RequireNonEmpty("name", req.Name); err != nil {
		return err
	}
	if err := validator.RequireNonEmpty("code", req.Code); err != nil {
		return err
	}
	if err := validator.ValidateEmail(req.Email); err != nil {
		return err
	}
	if err := validator.ValidatePhone(req.Phone); err != nil {
		return err
	}
	if err := validator.ValidateNonNegative("base_rate", req.BaseRate); err != nil {
		return err
	}
	if err := validator.ValidateNonNegative("per_kg_rate", req.PerKgRate); err != nil {
		return err
	}
	if err := validator.ValidateNonNegative("per_km_rate", req.PerKmRate); err != nil {
		return err
	}
	if req.FuelSurchargeRate < 0 || req.FuelSurchargeRate > 100 {
		return fmt.Errorf("fuel_surcharge_rate: %w", validator.ErrOutOfRange)
	}
	return nil
}

func (s *CarrierService) GetByID(ctx context.Context, id uuid.UUID) (*model.Carrier, error) {
	if id == uuid.Nil {
		return nil, model.ErrInvalidInput
	}
	key := "carrier:" + id.String()
	if s.cache != nil {
		if v, ok := s.cache.Get(key); ok {
			if c, ok := v.(*model.Carrier); ok {
				return c, nil
			}
		}
	}
	c, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return nil, err
	}
	if c == nil {
		return nil, model.ErrNotFound
	}
	if s.cache != nil {
		s.cache.Set(key, c)
	}
	return c, nil
}

func (s *CarrierService) GetByCode(ctx context.Context, code string) (*model.Carrier, error) {
	if code == "" {
		return nil, model.ErrInvalidInput
	}
	c, err := s.repo.GetByCode(ctx, code)
	if err != nil {
		return nil, err
	}
	if c == nil {
		return nil, model.ErrNotFound
	}
	return c, nil
}

func (s *CarrierService) Update(ctx context.Context, id uuid.UUID, req model.UpdateCarrierRequest, actorID string) error {
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}
	if req.Name != "" {
		existing.Name = req.Name
	}
	if req.ContactName != "" {
		existing.ContactName = req.ContactName
	}
	if req.Phone != "" {
		if err := validator.ValidatePhone(req.Phone); err != nil {
			return err
		}
		existing.Phone = req.Phone
	}
	if req.Address != "" {
		existing.Address = req.Address
	}
	if req.City != "" {
		existing.City = req.City
	}
	if req.State != "" {
		existing.State = req.State
	}
	if req.BaseRate >= 0 {
		existing.BaseRate = req.BaseRate
	}
	if req.PerKgRate >= 0 {
		existing.PerKgRate = req.PerKgRate
	}
	if req.PerKmRate >= 0 {
		existing.PerKmRate = req.PerKmRate
	}
	if req.FuelSurchargeRate >= 0 && req.FuelSurchargeRate <= 100 {
		existing.FuelSurchargeRate = req.FuelSurchargeRate
	}
	if req.InsuranceCoverage >= 0 {
		existing.InsuranceCoverage = req.InsuranceCoverage
	}
	existing.IsHazmatCertified = req.IsHazmatCertified
	if req.Notes != "" {
		existing.Notes = req.Notes
	}

	if err := s.repo.Update(ctx, id, existing); err != nil {
		return fmt.Errorf("update carrier: %w", err)
	}
	if s.cache != nil {
		s.cache.Delete("carrier:" + id.String())
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "carrier", EntityID: id, Action: audit.ActionUpdate,
		})
	}
	return nil
}

func (s *CarrierService) Delete(ctx context.Context, id uuid.UUID, actorID string) error {
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}
	if err := s.repo.Delete(ctx, id); err != nil {
		return fmt.Errorf("delete carrier: %w", err)
	}
	if s.cache != nil {
		s.cache.Delete("carrier:" + id.String())
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "carrier", EntityID: id, Action: audit.ActionDelete,
		})
	}
	return nil
}

func (s *CarrierService) List(ctx context.Context, f *model.CarrierFilter) ([]*model.Carrier, int, error) {
	if f == nil {
		f = &model.CarrierFilter{}
	}
	if f.Limit <= 0 {
		f.Limit = 25
	}
	if f.Limit > 200 {
		f.Limit = 200
	}
	if f.Offset < 0 {
		f.Offset = 0
	}
	return s.repo.List(ctx, f)
}

func (s *CarrierService) Quote(ctx context.Context, id uuid.UUID, weightKg, distanceKm float64) (float64, error) {
	c, err := s.GetByID(ctx, id)
	if err != nil {
		return 0, err
	}
	if weightKg <= 0 || distanceKm <= 0 {
		return 0, fmt.Errorf("weight/distance: %w", validator.ErrOutOfRange)
	}
	return c.QuoteShipment(weightKg, distanceKm), nil
}

func (s *CarrierService) RecordPerformance(ctx context.Context, id uuid.UUID, onTime, damage float64, total int, actorID string) error {
	if total < 0 {
		return fmt.Errorf("total: %w", validator.ErrOutOfRange)
	}
	if _, err := s.repo.GetByID(ctx, id); err != nil {
		return err
	}
	if err := s.repo.UpdateStats(ctx, id, onTime, damage, total); err != nil {
		return fmt.Errorf("update stats: %w", err)
	}
	if s.cache != nil {
		s.cache.Delete("carrier:" + id.String())
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "carrier", EntityID: id, Action: audit.ActionUpdate,
			Notes: fmt.Sprintf("perf: ot=%.1f damage=%.1f total=%d", onTime, damage, total),
		})
	}
	return nil
}

func (s *CarrierService) Activate(ctx context.Context, id uuid.UUID, actorID string) error {
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}
	if existing.IsActive {
		return nil
	}
	if err := s.repo.SetActive(ctx, id, true); err != nil {
		return err
	}
	if s.cache != nil {
		s.cache.Delete("carrier:" + id.String())
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "carrier", EntityID: id, Action: audit.ActionStatusSet,
		})
	}
	return nil
}

func (s *CarrierService) Deactivate(ctx context.Context, id uuid.UUID, actorID string) error {
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}
	if !existing.IsActive {
		return nil
	}
	if err := s.repo.SetActive(ctx, id, false); err != nil {
		return err
	}
	if s.cache != nil {
		s.cache.Delete("carrier:" + id.String())
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "carrier", EntityID: id, Action: audit.ActionStatusSet,
		})
	}
	return nil
}
