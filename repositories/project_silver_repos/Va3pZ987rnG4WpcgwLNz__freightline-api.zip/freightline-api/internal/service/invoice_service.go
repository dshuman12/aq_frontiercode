package service

import (
	"context"
	"fmt"
	"strings"
	"time"

	"freightline.dev/api/internal/audit"
	"freightline.dev/api/internal/cache"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/repository"
	"freightline.dev/api/internal/validator"
	"github.com/google/uuid"
)

type InvoiceService struct {
	repo     repository.InvoiceRepository
	payments repository.PaymentRepository
	customer repository.CustomerRepository
	audit    audit.Logger
	cache    *cache.Cache
}

func NewInvoiceService(
	repo repository.InvoiceRepository,
	pay repository.PaymentRepository,
	cust repository.CustomerRepository,
	log audit.Logger,
	c *cache.Cache,
) *InvoiceService {
	return &InvoiceService{repo: repo, payments: pay, customer: cust, audit: log, cache: c}
}

func generateInvoiceNumber() string {
	return "INV-" + time.Now().Format("20060102") + "-" + strings.ToUpper(strings.ReplaceAll(uuid.New().String()[:6], "-", ""))
}

func (s *InvoiceService) Create(ctx context.Context, req model.CreateInvoiceRequest, actorID string) (uuid.UUID, error) {
	if err := validateCreateInvoice(req); err != nil {
		return uuid.Nil, err
	}

	custID, err := uuid.Parse(req.CustomerID)
	if err != nil {
		return uuid.Nil, fmt.Errorf("customer_id: %w", validator.ErrBadID)
	}

	var customer *model.Customer
	if s.customer != nil {
		c, err := s.customer.GetByID(ctx, custID)
		if err != nil {
			return uuid.Nil, fmt.Errorf("customer lookup: %w", err)
		}
		customer = c
	}

	inv := &model.Invoice{
		ID:            uuid.New(),
		InvoiceNumber: generateInvoiceNumber(),
		CustomerID:    custID,
		Status:        model.InvoiceStatusIssued,
		IssuedDate:    time.Now(),
		Currency:      "USD",
		PaymentTerms:  30,
		Notes:         req.Notes,
		CreatedAt:     time.Now(),
		UpdatedAt:     time.Now(),
	}

	if req.Currency != "" {
		inv.Currency = strings.ToUpper(req.Currency)
	}
	if req.PaymentTerms > 0 {
		inv.PaymentTerms = req.PaymentTerms
	} else if customer != nil && customer.PaymentTerms > 0 {
		inv.PaymentTerms = customer.PaymentTerms
	}

	if req.IssuedDate != "" {
		if t, err := time.Parse("2006-01-02", req.IssuedDate); err == nil {
			inv.IssuedDate = t
		}
	}
	if req.DueDate != "" {
		if t, err := time.Parse("2006-01-02", req.DueDate); err == nil {
			inv.DueDate = t
		}
	} else {
		inv.DueDate = inv.IssuedDate.AddDate(0, 0, inv.PaymentTerms)
	}

	if customer != nil {
		inv.BillingAddress = customer.BillingFullAddress()
	}

	lines := make([]*model.InvoiceLineItem, 0, len(req.LineItems))
	for _, li := range req.LineItems {
		line := &model.InvoiceLineItem{
			ID:          uuid.New(),
			Description: li.Description,
			Quantity:    li.Quantity,
			UnitPrice:   li.UnitPrice,
			Discount:    li.Discount,
			TaxRate:     li.TaxRate,
		}
		if li.ShipmentID != "" {
			if sid, err := uuid.Parse(li.ShipmentID); err == nil {
				line.ShipmentID = &sid
			}
		}
		lines = append(lines, line)
	}
	inv.RecomputeTotals(lines)

	id, err := s.repo.Create(ctx, inv, lines)
	if err != nil {
		return uuid.Nil, fmt.Errorf("create invoice: %w", err)
	}

	if s.customer != nil {
		_ = s.customer.UpdateOutstandingBalance(ctx, custID, inv.Total)
	}

	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "invoice", EntityID: id, Action: audit.ActionCreate,
			NewValues: map[string]interface{}{"invoice_number": inv.InvoiceNumber, "total": inv.Total},
		})
	}
	return id, nil
}

func validateCreateInvoice(req model.CreateInvoiceRequest) error {
	if _, err := uuid.Parse(req.CustomerID); err != nil {
		return fmt.Errorf("customer_id: %w", validator.ErrBadID)
	}
	if len(req.LineItems) == 0 {
		return fmt.Errorf("at least one line item required: %w", validator.ErrEmptyField)
	}
	for i, li := range req.LineItems {
		if li.Description == "" {
			return fmt.Errorf("line_item[%d] description: %w", i, validator.ErrEmptyField)
		}
		if li.Quantity <= 0 {
			return fmt.Errorf("line_item[%d] quantity: %w", i, validator.ErrOutOfRange)
		}
		if li.UnitPrice < 0 {
			return fmt.Errorf("line_item[%d] unit_price: %w", i, validator.ErrOutOfRange)
		}
		if li.Discount < 0 || li.Discount > 100 {
			return fmt.Errorf("line_item[%d] discount: %w", i, validator.ErrOutOfRange)
		}
		if li.TaxRate < 0 || li.TaxRate > 100 {
			return fmt.Errorf("line_item[%d] tax_rate: %w", i, validator.ErrOutOfRange)
		}
	}
	return nil
}

func (s *InvoiceService) GetByID(ctx context.Context, id uuid.UUID) (*model.Invoice, error) {
	if id == uuid.Nil {
		return nil, model.ErrInvalidInput
	}
	key := "invoice:" + id.String()
	if s.cache != nil {
		if v, ok := s.cache.Get(key); ok {
			if inv, ok := v.(*model.Invoice); ok {
				return inv, nil
			}
		}
	}
	inv, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return nil, err
	}
	if inv == nil {
		return nil, model.ErrNotFound
	}
	if s.cache != nil {
		s.cache.Set(key, inv)
	}
	return inv, nil
}

func (s *InvoiceService) GetWithLines(ctx context.Context, id uuid.UUID) (*model.InvoiceWithLines, error) {
	if id == uuid.Nil {
		return nil, model.ErrInvalidInput
	}
	out, err := s.repo.GetWithLines(ctx, id)
	if err != nil {
		return nil, err
	}
	if out == nil {
		return nil, model.ErrNotFound
	}
	return out, nil
}

func (s *InvoiceService) Update(ctx context.Context, id uuid.UUID, req model.UpdateInvoiceRequest, actorID string) error {
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}
	if existing.Status == model.InvoiceStatusVoided || existing.Status == model.InvoiceStatusPaid {
		return fmt.Errorf("invoice cannot be modified in status %q: %w", existing.Status, model.ErrConflict)
	}
	if req.DueDate != "" {
		if t, err := time.Parse("2006-01-02", req.DueDate); err == nil {
			existing.DueDate = t
		}
	}
	if req.Notes != "" {
		existing.Notes = req.Notes
	}
	if err := s.repo.Update(ctx, id, existing); err != nil {
		return fmt.Errorf("update invoice: %w", err)
	}
	if s.cache != nil {
		s.cache.Delete("invoice:" + id.String())
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "invoice", EntityID: id, Action: audit.ActionUpdate,
		})
	}
	return nil
}

func (s *InvoiceService) Void(ctx context.Context, id uuid.UUID, reason, actorID string) error {
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}
	if existing.Status == model.InvoiceStatusVoided {
		return nil
	}
	if existing.AmountPaid > 0 {
		return fmt.Errorf("cannot void invoice with payments: %w", model.ErrConflict)
	}
	if err := s.repo.UpdateStatus(ctx, id, model.InvoiceStatusVoided); err != nil {
		return fmt.Errorf("void: %w", err)
	}
	if s.customer != nil {
		_ = s.customer.UpdateOutstandingBalance(ctx, existing.CustomerID, -existing.Total)
	}
	if s.cache != nil {
		s.cache.Delete("invoice:" + id.String())
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "invoice", EntityID: id, Action: audit.ActionCancel,
			Notes: reason,
		})
	}
	return nil
}

func (s *InvoiceService) Delete(ctx context.Context, id uuid.UUID, actorID string) error {
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}
	if existing.AmountPaid > 0 {
		return fmt.Errorf("cannot delete invoice with payments: %w", model.ErrConflict)
	}
	if err := s.repo.Delete(ctx, id); err != nil {
		return err
	}
	if s.cache != nil {
		s.cache.Delete("invoice:" + id.String())
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "invoice", EntityID: id, Action: audit.ActionDelete,
		})
	}
	return nil
}

func (s *InvoiceService) List(ctx context.Context, f *model.InvoiceFilter) ([]*model.Invoice, int, error) {
	if f == nil {
		f = &model.InvoiceFilter{}
	}
	if f.Limit <= 0 {
		f.Limit = 25
	}
	if f.Limit > 200 {
		f.Limit = 200
	}
	if f.Offset < 0 {
		f.Offset = 0
	}
	return s.repo.List(ctx, f)
}

func (s *InvoiceService) ListByCustomer(ctx context.Context, customerID uuid.UUID, limit int) ([]*model.Invoice, error) {
	if customerID == uuid.Nil {
		return nil, model.ErrInvalidInput
	}
	if limit <= 0 {
		limit = 50
	}
	return s.repo.ListByCustomer(ctx, customerID, limit)
}

func (s *InvoiceService) ListOverdue(ctx context.Context) ([]*model.Invoice, error) {
	return s.repo.ListOverdue(ctx)
}

func (s *InvoiceService) MarkOverdue(ctx context.Context, actorID string) (int, error) {
	overdue, err := s.repo.ListOverdue(ctx)
	if err != nil {
		return 0, err
	}
	updated := 0
	for _, inv := range overdue {
		if inv.Status == model.InvoiceStatusOverdue {
			continue
		}
		if err := s.repo.UpdateStatus(ctx, inv.ID, model.InvoiceStatusOverdue); err == nil {
			updated++
		}
	}
	if s.audit != nil && updated > 0 {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "invoice", Action: audit.ActionStatusSet,
			Notes: fmt.Sprintf("marked %d invoices overdue", updated),
		})
	}
	return updated, nil
}

func (s *InvoiceService) TotalOutstanding(ctx context.Context) (float64, error) {
	return s.repo.SumOutstanding(ctx)
}
