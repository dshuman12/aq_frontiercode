package service

import (
	"context"
	"errors"
	"fmt"
	"strings"
	"time"

	"freightline.dev/api/internal/audit"
	"freightline.dev/api/internal/cache"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/repository"
	"freightline.dev/api/internal/validator"
	"github.com/google/uuid"
)

type DriverService struct {
	repo  repository.DriverRepository
	audit audit.Logger
	cache *cache.Cache
}

func NewDriverService(repo repository.DriverRepository, log audit.Logger, c *cache.Cache) *DriverService {
	return &DriverService{repo: repo, audit: log, cache: c}
}

func (s *DriverService) Create(ctx context.Context, req model.CreateDriverRequest, actorID string) (uuid.UUID, error) {
	if err := validateCreateDriver(req); err != nil {
		return uuid.Nil, err
	}

	if existing, _ := s.repo.GetByEmployeeCode(ctx, req.EmployeeCode); existing != nil {
		return uuid.Nil, fmt.Errorf("employee code in use: %w", model.ErrDuplicate)
	}
	if existing, _ := s.repo.GetByEmail(ctx, req.Email); existing != nil {
		return uuid.Nil, fmt.Errorf("email in use: %w", model.ErrDuplicate)
	}

	d := &model.Driver{
		ID:              uuid.New(),
		EmployeeCode:    strings.ToUpper(strings.TrimSpace(req.EmployeeCode)),
		FirstName:       validator.Sanitize(req.FirstName),
		LastName:        validator.Sanitize(req.LastName),
		Email:           strings.ToLower(strings.TrimSpace(req.Email)),
		Phone:           req.Phone,
		LicenseNumber:   strings.ToUpper(req.LicenseNumber),
		LicenseClass:    req.LicenseClass,
		HourlyRate:      req.HourlyRate,
		PerMileRate:     req.PerMileRate,
		HomeAddress:     req.HomeAddress,
		HomeCity:        req.HomeCity,
		HomeState:       req.HomeState,
		EmergencyContact: req.EmergencyContact,
		EmergencyPhone:   req.EmergencyPhone,
		Status:          model.DriverStatusActive,
		CreatedAt:       time.Now(),
		UpdatedAt:       time.Now(),
	}

	if req.LicenseExpiry != "" {
		if t, err := time.Parse("2006-01-02", req.LicenseExpiry); err == nil {
			d.LicenseExpiry = t
		}
	}
	if req.HireDate != "" {
		if t, err := time.Parse("2006-01-02", req.HireDate); err == nil {
			d.HireDate = t
		}
	}
	if req.DateOfBirth != "" {
		if t, err := time.Parse("2006-01-02", req.DateOfBirth); err == nil {
			d.DateOfBirth = t
		}
	}

	id, err := s.repo.Create(ctx, d)
	if err != nil {
		return uuid.Nil, fmt.Errorf("create driver: %w", err)
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "driver", EntityID: id,
			Action: audit.ActionCreate,
			NewValues: map[string]interface{}{"employee_code": d.EmployeeCode, "email": d.Email},
		})
	}
	return id, nil
}

func validateCreateDriver(req model.CreateDriverRequest) error {
	if err := validator.RequireNonEmpty("employee_code", req.EmployeeCode); err != nil {
		return err
	}
	if err := validator.RequireNonEmpty("first_name", req.FirstName); err != nil {
		return err
	}
	if err := validator.RequireNonEmpty("last_name", req.LastName); err != nil {
		return err
	}
	if err := validator.ValidateEmail(req.Email); err != nil {
		return err
	}
	if err := validator.RequireNonEmpty("phone", req.Phone); err != nil {
		return err
	}
	if err := validator.ValidatePhone(req.Phone); err != nil {
		return err
	}
	if err := validator.RequireNonEmpty("license_number", req.LicenseNumber); err != nil {
		return err
	}
	switch req.LicenseClass {
	case model.LicenseClassA, model.LicenseClassB, model.LicenseClassC:
	default:
		return fmt.Errorf("license_class: invalid: %w", validator.ErrBadFormat)
	}
	if err := validator.ValidateNonNegative("hourly_rate", req.HourlyRate); err != nil {
		return err
	}
	if err := validator.ValidateNonNegative("per_mile_rate", req.PerMileRate); err != nil {
		return err
	}
	return nil
}

func (s *DriverService) GetByID(ctx context.Context, id uuid.UUID) (*model.Driver, error) {
	if id == uuid.Nil {
		return nil, model.ErrInvalidInput
	}
	key := "driver:" + id.String()
	if s.cache != nil {
		if v, ok := s.cache.Get(key); ok {
			if d, ok := v.(*model.Driver); ok {
				return d, nil
			}
		}
	}
	d, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return nil, err
	}
	if d == nil {
		return nil, model.ErrNotFound
	}
	if s.cache != nil {
		s.cache.Set(key, d)
	}
	return d, nil
}

func (s *DriverService) GetByEmployeeCode(ctx context.Context, code string) (*model.Driver, error) {
	if code == "" {
		return nil, model.ErrInvalidInput
	}
	d, err := s.repo.GetByEmployeeCode(ctx, code)
	if err != nil {
		return nil, err
	}
	if d == nil {
		return nil, model.ErrNotFound
	}
	return d, nil
}

func (s *DriverService) Update(ctx context.Context, id uuid.UUID, req model.UpdateDriverRequest, actorID string) error {
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}

	if req.FirstName != "" {
		existing.FirstName = validator.Sanitize(req.FirstName)
	}
	if req.LastName != "" {
		existing.LastName = validator.Sanitize(req.LastName)
	}
	if req.Phone != "" {
		if err := validator.ValidatePhone(req.Phone); err != nil {
			return err
		}
		existing.Phone = req.Phone
	}
	if req.LicenseClass != "" {
		switch req.LicenseClass {
		case model.LicenseClassA, model.LicenseClassB, model.LicenseClassC:
			existing.LicenseClass = req.LicenseClass
		default:
			return fmt.Errorf("license_class: invalid: %w", validator.ErrBadFormat)
		}
	}
	if req.LicenseExpiry != "" {
		if t, err := time.Parse("2006-01-02", req.LicenseExpiry); err == nil {
			existing.LicenseExpiry = t
		}
	}
	if req.HourlyRate > 0 {
		existing.HourlyRate = req.HourlyRate
	}
	if req.PerMileRate > 0 {
		existing.PerMileRate = req.PerMileRate
	}
	if req.HomeAddress != "" {
		existing.HomeAddress = req.HomeAddress
	}
	if req.HomeCity != "" {
		existing.HomeCity = req.HomeCity
	}
	if req.HomeState != "" {
		existing.HomeState = req.HomeState
	}
	if req.EmergencyContact != "" {
		existing.EmergencyContact = req.EmergencyContact
	}
	if req.EmergencyPhone != "" {
		existing.EmergencyPhone = req.EmergencyPhone
	}

	if err := s.repo.Update(ctx, id, existing); err != nil {
		return fmt.Errorf("update driver: %w", err)
	}
	if s.cache != nil {
		s.cache.Delete("driver:" + id.String())
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "driver", EntityID: id, Action: audit.ActionUpdate,
		})
	}
	return nil
}

func (s *DriverService) Delete(ctx context.Context, id uuid.UUID, actorID string) error {
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}
	if existing.Status == model.DriverStatusActive {
		return fmt.Errorf("driver still active: %w", model.ErrConflict)
	}
	if err := s.repo.Delete(ctx, id); err != nil {
		return fmt.Errorf("delete driver: %w", err)
	}
	if s.cache != nil {
		s.cache.Delete("driver:" + id.String())
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "driver", EntityID: id, Action: audit.ActionDelete,
		})
	}
	return nil
}

func (s *DriverService) List(ctx context.Context, f *model.DriverFilter) ([]*model.Driver, int, error) {
	if f == nil {
		f = &model.DriverFilter{}
	}
	if f.Limit <= 0 {
		f.Limit = 25
	}
	if f.Limit > 200 {
		f.Limit = 200
	}
	if f.Offset < 0 {
		f.Offset = 0
	}
	return s.repo.List(ctx, f)
}

func (s *DriverService) ChangeStatus(ctx context.Context, id uuid.UUID, status model.DriverStatus, actorID string) error {
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}
	if existing.Status == status {
		return nil
	}

	if status == model.DriverStatusActive && existing.IsLicenseExpired() {
		return fmt.Errorf("cannot activate driver with expired license: %w", model.ErrConflict)
	}

	if err := s.repo.UpdateStatus(ctx, id, status); err != nil {
		return fmt.Errorf("update status: %w", err)
	}
	if s.cache != nil {
		s.cache.Delete("driver:" + id.String())
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "driver", EntityID: id, Action: audit.ActionStatusSet,
			OldValues: map[string]interface{}{"status": existing.Status},
			NewValues: map[string]interface{}{"status": status},
		})
	}
	return nil
}

func (s *DriverService) RecordDelivery(ctx context.Context, id uuid.UUID, miles float64, actorID string) error {
	if miles < 0 {
		return fmt.Errorf("miles must be non-negative: %w", validator.ErrOutOfRange)
	}
	if _, err := s.repo.GetByID(ctx, id); err != nil {
		return err
	}
	if err := s.repo.IncrementDeliveries(ctx, id, miles); err != nil {
		return fmt.Errorf("inc deliveries: %w", err)
	}
	if s.cache != nil {
		s.cache.Delete("driver:" + id.String())
	}
	return nil
}

func (s *DriverService) ListAvailable(ctx context.Context) ([]*model.Driver, error) {
	out, err := s.repo.ListAvailable(ctx)
	if err != nil {
		return nil, fmt.Errorf("list available: %w", err)
	}
	return out, nil
}

func (s *DriverService) ListExpiringLicenses(ctx context.Context, days int) ([]*model.Driver, error) {
	if days <= 0 {
		days = 30
	}
	if days > 365 {
		days = 365
	}
	return s.repo.ListExpiringLicenses(ctx, days)
}

func (s *DriverService) ComputeCommission(ctx context.Context, id uuid.UUID, miles, hours float64) (float64, error) {
	if miles < 0 || hours < 0 {
		return 0, validator.ErrOutOfRange
	}
	d, err := s.GetByID(ctx, id)
	if err != nil {
		return 0, err
	}
	if !errors.Is(err, nil) && d == nil {
		return 0, model.ErrNotFound
	}
	return d.HourlyRate*hours + d.PerMileRate*miles, nil
}
