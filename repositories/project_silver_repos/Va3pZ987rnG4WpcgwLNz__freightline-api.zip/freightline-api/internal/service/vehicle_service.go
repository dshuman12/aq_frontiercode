package service

import (
	"context"
	"fmt"
	"strings"
	"time"

	"freightline.dev/api/internal/audit"
	"freightline.dev/api/internal/cache"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/repository"
	"freightline.dev/api/internal/validator"
	"github.com/google/uuid"
)

type VehicleService struct {
	repo  repository.VehicleRepository
	audit audit.Logger
	cache *cache.Cache
}

func NewVehicleService(repo repository.VehicleRepository, log audit.Logger, c *cache.Cache) *VehicleService {
	return &VehicleService{repo: repo, audit: log, cache: c}
}

func (s *VehicleService) Create(ctx context.Context, req model.CreateVehicleRequest, actorID string) (uuid.UUID, error) {
	if err := validateCreateVehicle(req); err != nil {
		return uuid.Nil, err
	}

	if existing, _ := s.repo.GetByPlate(ctx, req.PlateNumber); existing != nil {
		return uuid.Nil, fmt.Errorf("plate %q already exists: %w", req.PlateNumber, model.ErrDuplicate)
	}
	if existing, _ := s.repo.GetByVIN(ctx, req.VIN); existing != nil {
		return uuid.Nil, fmt.Errorf("vin %q already exists: %w", req.VIN, model.ErrDuplicate)
	}

	v := &model.Vehicle{
		ID:             uuid.New(),
		PlateNumber:    strings.ToUpper(strings.TrimSpace(req.PlateNumber)),
		VIN:            strings.ToUpper(strings.TrimSpace(req.VIN)),
		Make:           req.Make,
		Model:          req.Model,
		Year:           req.Year,
		Type:           req.Type,
		FuelType:       req.FuelType,
		CapacityKg:     req.CapacityKg,
		CapacityM3:     req.CapacityM3,
		FuelEfficiency: req.FuelEfficiency,
		Status:         model.VehicleStatusAvailable,
		InsuranceProvider: req.InsuranceProvider,
		InsurancePolicy:   req.InsurancePolicy,
		PurchasePrice:  req.PurchasePrice,
		CurrentValue:   req.PurchasePrice,
		IsRefrigerated: req.IsRefrigerated,
		CreatedAt:      time.Now(),
		UpdatedAt:      time.Now(),
	}

	if req.InsuranceExpiry != "" {
		if t, err := time.Parse("2006-01-02", req.InsuranceExpiry); err == nil {
			v.InsuranceExpiry = t
		}
	}
	if req.RegistrationExpiry != "" {
		if t, err := time.Parse("2006-01-02", req.RegistrationExpiry); err == nil {
			v.RegistrationExpiry = t
		}
	}
	if req.PurchaseDate != "" {
		if t, err := time.Parse("2006-01-02", req.PurchaseDate); err == nil {
			v.PurchaseDate = t
		}
	}
	if req.HomeWarehouseID != "" {
		if hwid, err := uuid.Parse(req.HomeWarehouseID); err == nil {
			v.HomeWarehouseID = &hwid
		}
	}

	id, err := s.repo.Create(ctx, v)
	if err != nil {
		return uuid.Nil, fmt.Errorf("create vehicle: %w", err)
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "vehicle", EntityID: id,
			Action: audit.ActionCreate,
			NewValues: map[string]interface{}{"plate": v.PlateNumber, "vin": v.VIN},
		})
	}
	return id, nil
}

func validateCreateVehicle(req model.CreateVehicleRequest) error {
	if err := validator.ValidatePlateNumber(req.PlateNumber); err != nil {
		return err
	}
	if err := validator.RequireNonEmpty("vin", req.VIN); err != nil {
		return err
	}
	if len(req.VIN) != 17 {
		return fmt.Errorf("vin: must be 17 characters: %w", validator.ErrBadFormat)
	}
	if err := validator.RequireNonEmpty("make", req.Make); err != nil {
		return err
	}
	if err := validator.RequireNonEmpty("model", req.Model); err != nil {
		return err
	}
	currentYear := time.Now().Year()
	if req.Year < 1900 || req.Year > currentYear+1 {
		return fmt.Errorf("year: %w", validator.ErrOutOfRange)
	}
	switch req.Type {
	case model.VehicleTypeBox, model.VehicleTypeSemi, model.VehicleTypeVan, model.VehicleTypePickup,
		model.VehicleTypeReefer, model.VehicleTypeFlatbed, model.VehicleTypeTanker, model.VehicleTypeContainer:
	default:
		return fmt.Errorf("type: %q invalid: %w", req.Type, validator.ErrBadFormat)
	}
	if err := validator.ValidateNonNegative("capacity_kg", req.CapacityKg); err != nil {
		return err
	}
	if err := validator.ValidateNonNegative("purchase_price", req.PurchasePrice); err != nil {
		return err
	}
	return nil
}

func (s *VehicleService) GetByID(ctx context.Context, id uuid.UUID) (*model.Vehicle, error) {
	if id == uuid.Nil {
		return nil, model.ErrInvalidInput
	}
	key := "vehicle:" + id.String()
	if s.cache != nil {
		if v, ok := s.cache.Get(key); ok {
			if vv, ok := v.(*model.Vehicle); ok {
				return vv, nil
			}
		}
	}
	v, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return nil, err
	}
	if v == nil {
		return nil, model.ErrNotFound
	}
	if s.cache != nil {
		s.cache.Set(key, v)
	}
	return v, nil
}

func (s *VehicleService) GetByPlate(ctx context.Context, plate string) (*model.Vehicle, error) {
	if plate == "" {
		return nil, model.ErrInvalidInput
	}
	v, err := s.repo.GetByPlate(ctx, plate)
	if err != nil {
		return nil, err
	}
	if v == nil {
		return nil, model.ErrNotFound
	}
	return v, nil
}

func (s *VehicleService) Update(ctx context.Context, id uuid.UUID, req model.UpdateVehicleRequest, actorID string) error {
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}

	if req.OdometerKm > 0 {
		if req.OdometerKm < existing.OdometerKm {
			return fmt.Errorf("odometer cannot decrease: %w", validator.ErrOutOfRange)
		}
		existing.OdometerKm = req.OdometerKm
	}
	if req.FuelEfficiency > 0 {
		existing.FuelEfficiency = req.FuelEfficiency
	}
	if req.InsuranceProvider != "" {
		existing.InsuranceProvider = req.InsuranceProvider
	}
	if req.InsurancePolicy != "" {
		existing.InsurancePolicy = req.InsurancePolicy
	}
	if req.InsuranceExpiry != "" {
		if t, err := time.Parse("2006-01-02", req.InsuranceExpiry); err == nil {
			existing.InsuranceExpiry = t
		}
	}
	if req.RegistrationExpiry != "" {
		if t, err := time.Parse("2006-01-02", req.RegistrationExpiry); err == nil {
			existing.RegistrationExpiry = t
		}
	}
	if req.LastServiceDate != "" {
		if t, err := time.Parse("2006-01-02", req.LastServiceDate); err == nil {
			existing.LastServiceDate = t
		}
	}
	if req.NextServiceDate != "" {
		if t, err := time.Parse("2006-01-02", req.NextServiceDate); err == nil {
			existing.NextServiceDate = t
		}
	}
	if req.NextServiceKm > 0 {
		existing.NextServiceKm = req.NextServiceKm
	}
	if req.CurrentValue > 0 {
		existing.CurrentValue = req.CurrentValue
	}
	if req.HomeWarehouseID != "" {
		if hwid, err := uuid.Parse(req.HomeWarehouseID); err == nil {
			existing.HomeWarehouseID = &hwid
		}
	}

	if err := s.repo.Update(ctx, id, existing); err != nil {
		return fmt.Errorf("update vehicle: %w", err)
	}
	if s.cache != nil {
		s.cache.Delete("vehicle:" + id.String())
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "vehicle", EntityID: id, Action: audit.ActionUpdate,
		})
	}
	return nil
}

func (s *VehicleService) Delete(ctx context.Context, id uuid.UUID, actorID string) error {
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}
	if existing.Status == model.VehicleStatusInTransit {
		return fmt.Errorf("cannot delete vehicle in transit: %w", model.ErrConflict)
	}
	if err := s.repo.Delete(ctx, id); err != nil {
		return fmt.Errorf("delete vehicle: %w", err)
	}
	if s.cache != nil {
		s.cache.Delete("vehicle:" + id.String())
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "vehicle", EntityID: id, Action: audit.ActionDelete,
		})
	}
	return nil
}

func (s *VehicleService) List(ctx context.Context, f *model.VehicleFilter) ([]*model.Vehicle, int, error) {
	if f == nil {
		f = &model.VehicleFilter{}
	}
	if f.Limit <= 0 {
		f.Limit = 25
	}
	if f.Limit > 200 {
		f.Limit = 200
	}
	if f.Offset < 0 {
		f.Offset = 0
	}
	return s.repo.List(ctx, f)
}

func (s *VehicleService) ChangeStatus(ctx context.Context, id uuid.UUID, status model.VehicleStatus, actorID string) error {
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}
	if existing.Status == status {
		return nil
	}
	if err := s.repo.UpdateStatus(ctx, id, status); err != nil {
		return fmt.Errorf("update status: %w", err)
	}
	if s.cache != nil {
		s.cache.Delete("vehicle:" + id.String())
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "vehicle", EntityID: id, Action: audit.ActionStatusSet,
			OldValues: map[string]interface{}{"status": existing.Status},
			NewValues: map[string]interface{}{"status": status},
		})
	}
	return nil
}

func (s *VehicleService) RecordTrip(ctx context.Context, id uuid.UUID, km float64, actorID string) error {
	if km <= 0 {
		return fmt.Errorf("km must be positive: %w", validator.ErrOutOfRange)
	}
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}
	newOdo := existing.OdometerKm + km
	if err := s.repo.UpdateOdometer(ctx, id, newOdo); err != nil {
		return fmt.Errorf("update odometer: %w", err)
	}
	if s.cache != nil {
		s.cache.Delete("vehicle:" + id.String())
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "vehicle", EntityID: id, Action: audit.ActionUpdate,
			Notes: fmt.Sprintf("recorded %.2f km trip", km),
		})
	}
	return nil
}

func (s *VehicleService) ListAvailable(ctx context.Context) ([]*model.Vehicle, error) {
	return s.repo.ListAvailable(ctx)
}

func (s *VehicleService) ListNeedingService(ctx context.Context) ([]*model.Vehicle, error) {
	return s.repo.ListNeedingService(ctx)
}

func (s *VehicleService) FindSuitable(ctx context.Context, weightKg, volumeM3 float64, refrigeration bool) ([]*model.Vehicle, error) {
	all, err := s.repo.ListAvailable(ctx)
	if err != nil {
		return nil, err
	}
	out := []*model.Vehicle{}
	for _, v := range all {
		if refrigeration && !v.IsRefrigerated {
			continue
		}
		if !v.CanCarry(weightKg, volumeM3) {
			continue
		}
		out = append(out, v)
	}
	return out, nil
}
