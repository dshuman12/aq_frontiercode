package service

import (
	"context"
	"fmt"
	"time"

	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/repository"
	"github.com/google/uuid"
)

type ReportService struct {
	shipment  repository.ShipmentRepository
	driver    repository.DriverRepository
	vehicle   repository.VehicleRepository
	warehouse repository.WarehouseRepository
	customer  repository.CustomerRepository
	invoice   repository.InvoiceRepository
	payment   repository.PaymentRepository
	carrier   repository.CarrierRepository
}

func NewReportService(
	sh repository.ShipmentRepository,
	dr repository.DriverRepository,
	veh repository.VehicleRepository,
	wh repository.WarehouseRepository,
	cu repository.CustomerRepository,
	inv repository.InvoiceRepository,
	pay repository.PaymentRepository,
	ca repository.CarrierRepository,
) *ReportService {
	return &ReportService{
		shipment: sh, driver: dr, vehicle: veh, warehouse: wh,
		customer: cu, invoice: inv, payment: pay, carrier: ca,
	}
}

func (s *ReportService) Dashboard(ctx context.Context) (*model.DashboardSummary, error) {
	counts, err := s.shipment.CountByStatus(ctx)
	if err != nil {
		return nil, fmt.Errorf("count shipments: %w", err)
	}

	active := 0
	for st, n := range counts {
		switch st {
		case model.ShipmentStatusBooked, model.ShipmentStatusPickedUp,
			model.ShipmentStatusAtWarehouse, model.ShipmentStatusInTransit,
			model.ShipmentStatusOutForDelivery, model.ShipmentStatusHeld:
			active += n
		}
	}

	availableDrivers, err := s.driver.ListAvailable(ctx)
	if err != nil {
		return nil, fmt.Errorf("available drivers: %w", err)
	}
	availableVehicles, err := s.vehicle.ListAvailable(ctx)
	if err != nil {
		return nil, fmt.Errorf("available vehicles: %w", err)
	}
	overdue, err := s.shipment.ListOverdue(ctx)
	if err != nil {
		return nil, fmt.Errorf("overdue: %w", err)
	}

	outstanding, _ := s.invoice.SumOutstanding(ctx)

	monthStart := time.Date(time.Now().Year(), time.Now().Month(), 1, 0, 0, 0, 0, time.UTC)
	pf := &model.PaymentFilter{
		FromDate: monthStart,
		Status:   model.PaymentStatusCleared,
		Limit:    1000,
	}
	payments, _, _ := s.payment.List(ctx, pf)
	monthlyRevenue := 0.0
	for _, p := range payments {
		monthlyRevenue += p.Amount
	}

	return &model.DashboardSummary{
		ActiveShipments:    active,
		DeliveredToday:     counts[model.ShipmentStatusDelivered],
		PendingPickups:     counts[model.ShipmentStatusBooked],
		OverdueShipments:   len(overdue),
		AvailableDrivers:   len(availableDrivers),
		AvailableVehicles:  len(availableVehicles),
		OutstandingRevenue: outstanding,
		RevenueThisMonth:   monthlyRevenue,
		GeneratedAt:        time.Now(),
	}, nil
}

func (s *ReportService) FleetUtilization(ctx context.Context, from, to time.Time) (*model.FleetUtilizationReport, error) {
	vehicles, _, err := s.vehicle.List(ctx, &model.VehicleFilter{Limit: 1000})
	if err != nil {
		return nil, fmt.Errorf("list vehicles: %w", err)
	}
	r := &model.FleetUtilizationReport{
		Period:      model.ReportPeriod{From: from, To: to},
		GeneratedAt: time.Now(),
	}
	r.TotalVehicles = len(vehicles)
	totalOdo := 0.0
	for _, v := range vehicles {
		switch v.Status {
		case model.VehicleStatusAvailable:
			r.AvailableVehicles++
		case model.VehicleStatusInTransit:
			r.InTransit++
		case model.VehicleStatusMaintenance:
			r.InMaintenance++
		}
		r.TotalCapacityKg += v.CapacityKg
		totalOdo += v.OdometerKm
	}
	if r.TotalVehicles > 0 {
		r.AvgOdometerKm = totalOdo / float64(r.TotalVehicles)
		usable := r.TotalVehicles - r.InMaintenance
		if usable > 0 {
			r.UtilizationRate = (float64(r.InTransit) / float64(usable)) * 100
		}
	}
	return r, nil
}

func (s *ReportService) DriverPerformance(ctx context.Context, driverID uuid.UUID, from, to time.Time) (*model.DriverPerformanceReport, error) {
	if driverID == uuid.Nil {
		return nil, model.ErrInvalidInput
	}
	d, err := s.driver.GetByID(ctx, driverID)
	if err != nil {
		return nil, err
	}
	if d == nil {
		return nil, model.ErrNotFound
	}

	shipments, err := s.shipment.ListByDriver(ctx, driverID, 1000)
	if err != nil {
		return nil, fmt.Errorf("list by driver: %w", err)
	}

	r := &model.DriverPerformanceReport{
		DriverID:    driverID,
		DriverName:  d.FullName(),
		Period:      model.ReportPeriod{From: from, To: to},
		IncidentCount: d.IncidentCount,
		TotalMilesDriven: d.TotalMilesDriven,
		GeneratedAt: time.Now(),
	}

	totalDelivHours := 0.0
	delivered := 0
	for _, sh := range shipments {
		if !from.IsZero() && sh.CreatedAt.Before(from) {
			continue
		}
		if !to.IsZero() && sh.CreatedAt.After(to) {
			continue
		}
		switch sh.Status {
		case model.ShipmentStatusDelivered:
			r.DeliveriesCompleted++
			if sh.ActualDelivery != nil && !sh.ScheduledDelivery.IsZero() {
				if !sh.ActualDelivery.After(sh.ScheduledDelivery) {
					r.OnTimeDeliveries++
				} else {
					r.LateDeliveries++
				}
			}
			if sh.ActualPickup != nil && sh.ActualDelivery != nil {
				totalDelivHours += sh.ActualDelivery.Sub(*sh.ActualPickup).Hours()
				delivered++
			}
		case model.ShipmentStatusFailed, model.ShipmentStatusReturned:
			r.FailedDeliveries++
		}
	}

	if r.DeliveriesCompleted > 0 {
		r.OnTimeRate = (float64(r.OnTimeDeliveries) / float64(r.DeliveriesCompleted)) * 100
	}
	if delivered > 0 {
		r.AvgDeliveryHours = totalDelivHours / float64(delivered)
	}
	return r, nil
}

func (s *ReportService) Revenue(ctx context.Context, from, to time.Time) (*model.RevenueReport, error) {
	r := &model.RevenueReport{
		Period:      model.ReportPeriod{From: from, To: to},
		GeneratedAt: time.Now(),
	}

	invs, _, err := s.invoice.List(ctx, &model.InvoiceFilter{
		FromDate: from, ToDate: to, Limit: 5000,
	})
	if err != nil {
		return nil, fmt.Errorf("list invoices: %w", err)
	}

	customerMap := map[uuid.UUID]*model.CustomerRevenue{}
	for _, inv := range invs {
		r.InvoiceCount++
		r.InvoicedAmount += inv.Total
		r.CollectedAmount += inv.AmountPaid
		r.Outstanding += inv.BalanceDue
		if inv.IsOverdue() {
			r.OverdueAmount += inv.BalanceDue
		}
		cust, ok := customerMap[inv.CustomerID]
		if !ok {
			cust = &model.CustomerRevenue{CustomerID: inv.CustomerID}
			customerMap[inv.CustomerID] = cust
		}
		cust.Revenue += inv.Total
	}

	r.TotalRevenue = r.CollectedAmount

	if s.customer != nil {
		for id, cv := range customerMap {
			c, err := s.customer.GetByID(ctx, id)
			if err == nil && c != nil {
				cv.CustomerName = c.CompanyName
			}
		}
	}

	for _, cv := range customerMap {
		r.ByCustomer = append(r.ByCustomer, cv)
	}

	pf := &model.PaymentFilter{FromDate: from, ToDate: to, Limit: 5000}
	pays, _, err := s.payment.List(ctx, pf)
	if err != nil {
		return nil, fmt.Errorf("list payments: %w", err)
	}
	r.PaymentCount = len(pays)
	return r, nil
}

func (s *ReportService) ShipmentVolume(ctx context.Context, from, to time.Time) (*model.ShipmentVolumeReport, error) {
	shipments, _, err := s.shipment.List(ctx, &model.ShipmentFilter{
		FromDate: from, ToDate: to, Limit: 10000,
	})
	if err != nil {
		return nil, fmt.Errorf("list shipments: %w", err)
	}

	r := &model.ShipmentVolumeReport{
		Period:         model.ReportPeriod{From: from, To: to},
		ByStatus:       map[model.ShipmentStatus]int{},
		ByServiceLevel: map[model.ServiceLevel]int{},
		GeneratedAt:    time.Now(),
	}
	r.TotalShipments = len(shipments)
	totalDelivDays := 0.0
	deliveredCount := 0
	onTime := 0
	damaged := 0
	for _, sh := range shipments {
		r.TotalWeightKg += sh.WeightKg
		r.TotalVolumeM3 += sh.VolumeM3
		r.ByStatus[sh.Status]++
		r.ByServiceLevel[sh.ServiceLevel]++
		if sh.Status == model.ShipmentStatusDelivered {
			deliveredCount++
			if sh.ActualDelivery != nil && sh.ActualPickup != nil {
				totalDelivDays += sh.DeliveryDurationDays()
			}
			if sh.ActualDelivery != nil && !sh.ScheduledDelivery.IsZero() && !sh.ActualDelivery.After(sh.ScheduledDelivery) {
				onTime++
			}
		}
		if sh.Status == model.ShipmentStatusFailed || sh.Status == model.ShipmentStatusReturned {
			damaged++
		}
	}
	if deliveredCount > 0 {
		r.AvgDeliveryDays = totalDelivDays / float64(deliveredCount)
		r.OnTimeRate = (float64(onTime) / float64(deliveredCount)) * 100
	}
	if r.TotalShipments > 0 {
		r.DamageRate = (float64(damaged) / float64(r.TotalShipments)) * 100
	}
	return r, nil
}

func (s *ReportService) WarehouseUtilization(ctx context.Context, warehouseID uuid.UUID) (*model.WarehouseUtilizationReport, error) {
	if warehouseID == uuid.Nil {
		return nil, model.ErrInvalidInput
	}
	w, err := s.warehouse.GetByID(ctx, warehouseID)
	if err != nil {
		return nil, err
	}
	if w == nil {
		return nil, model.ErrNotFound
	}
	return &model.WarehouseUtilizationReport{
		WarehouseID:       w.ID,
		WarehouseName:     w.Name,
		Capacity:          w.Capacity,
		Used:              w.UsedCapacity,
		UtilizationPercent: w.UtilizationPercent(),
		GeneratedAt:       time.Now(),
	}, nil
}

func (s *ReportService) CarrierPerformance(ctx context.Context, carrierID uuid.UUID, from, to time.Time) (*model.CarrierPerformanceReport, error) {
	if carrierID == uuid.Nil {
		return nil, model.ErrInvalidInput
	}
	c, err := s.carrier.GetByID(ctx, carrierID)
	if err != nil {
		return nil, err
	}
	if c == nil {
		return nil, model.ErrNotFound
	}

	shipments, _, err := s.shipment.List(ctx, &model.ShipmentFilter{
		CarrierID: &carrierID,
		FromDate:  from,
		ToDate:    to,
		Limit:     5000,
	})
	if err != nil {
		return nil, fmt.Errorf("list carrier shipments: %w", err)
	}

	r := &model.CarrierPerformanceReport{
		CarrierID:   c.ID,
		CarrierName: c.Name,
		Period:      model.ReportPeriod{From: from, To: to},
		ShipmentCount: len(shipments),
		OnTimeRate:  c.OnTimeRate,
		DamageRate:  c.DamageRate,
		Score:       c.PerformanceScore(),
		GeneratedAt: time.Now(),
	}
	totalSpend := 0.0
	for _, sh := range shipments {
		totalSpend += sh.TotalCharge
	}
	r.TotalSpend = totalSpend
	if r.ShipmentCount > 0 {
		r.AvgCost = totalSpend / float64(r.ShipmentCount)
	}
	return r, nil
}
