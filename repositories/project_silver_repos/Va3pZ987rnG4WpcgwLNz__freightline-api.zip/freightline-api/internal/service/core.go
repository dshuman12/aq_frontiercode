package service

import (
	"context"
	"fmt"

	"freightline.dev/api/internal/audit"
	"freightline.dev/api/internal/cache"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/repository"
	"github.com/google/uuid"
)

type Core struct {
	Customer  *CustomerService
	Driver    *DriverService
	Vehicle   *VehicleService
	Warehouse *WarehouseService
	Shipment  *ShipmentService
	Carrier   *CarrierService
	Invoice   *InvoiceService
	Payment   *PaymentService
	Route     *RouteService
	Tracking  *TrackingService
	Report    *ReportService
}

func NewCore(
	repos *repository.Set,
	auditLog audit.Logger,
	c *cache.Cache,
) *Core {
	return &Core{
		Customer:  NewCustomerService(repos.Customer, auditLog, c),
		Driver:    NewDriverService(repos.Driver, auditLog, c),
		Vehicle:   NewVehicleService(repos.Vehicle, auditLog, c),
		Warehouse: NewWarehouseService(repos.Warehouse, auditLog, c),
		Shipment:  NewShipmentService(repos.Shipment, repos.Tracking, repos.Customer, repos.Driver, repos.Vehicle, auditLog, c),
		Carrier:   NewCarrierService(repos.Carrier, auditLog, c),
		Invoice:   NewInvoiceService(repos.Invoice, repos.Payment, repos.Customer, auditLog, c),
		Payment:   NewPaymentService(repos.Payment, repos.Invoice, repos.Customer, auditLog, c),
		Route:     NewRouteService(repos.Route, repos.Shipment, repos.Driver, repos.Vehicle, auditLog, c),
		Tracking:  NewTrackingService(repos.Tracking, repos.Shipment, auditLog),
		Report: NewReportService(
			repos.Shipment, repos.Driver, repos.Vehicle, repos.Warehouse,
			repos.Customer, repos.Invoice, repos.Payment, repos.Carrier,
		),
	}
}

func (c *Core) CompleteDelivery(ctx context.Context, shipmentID uuid.UUID, miles float64, actorID string) error {
	ship, err := c.Shipment.GetByID(ctx, shipmentID)
	if err != nil {
		return err
	}
	if ship == nil {
		return model.ErrNotFound
	}

	if err := c.Shipment.TransitionStatus(ctx, shipmentID, model.ShipmentStatusDelivered, ship.DeliveryCity, actorID); err != nil {
		return fmt.Errorf("transition: %w", err)
	}

	if ship.AssignedDriverID != nil {
		_ = c.Driver.RecordDelivery(ctx, *ship.AssignedDriverID, miles, actorID)
	}
	if ship.AssignedVehicleID != nil {
		_ = c.Vehicle.RecordTrip(ctx, *ship.AssignedVehicleID, miles, actorID)
	}
	return nil
}

func (c *Core) ProcessPickup(ctx context.Context, shipmentID, driverID, vehicleID uuid.UUID, actorID string) error {
	ship, err := c.Shipment.GetByID(ctx, shipmentID)
	if err != nil {
		return err
	}
	if ship == nil {
		return model.ErrNotFound
	}
	if err := c.Shipment.AssignDriver(ctx, shipmentID, driverID, actorID); err != nil {
		return fmt.Errorf("assign driver: %w", err)
	}
	if err := c.Shipment.AssignVehicle(ctx, shipmentID, vehicleID, actorID); err != nil {
		return fmt.Errorf("assign vehicle: %w", err)
	}
	return c.Shipment.TransitionStatus(ctx, shipmentID, model.ShipmentStatusPickedUp, ship.PickupCity, actorID)
}
