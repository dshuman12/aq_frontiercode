package service

import (
	"context"
	"fmt"
	"time"

	"freightline.dev/api/internal/audit"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/repository"
	"freightline.dev/api/internal/validator"
	"github.com/google/uuid"
)

type TrackingService struct {
	repo     repository.TrackingEventRepository
	shipment repository.ShipmentRepository
	audit    audit.Logger
}

func NewTrackingService(repo repository.TrackingEventRepository, sh repository.ShipmentRepository, log audit.Logger) *TrackingService {
	return &TrackingService{repo: repo, shipment: sh, audit: log}
}

func (s *TrackingService) RecordEvent(ctx context.Context, req model.CreateTrackingEventRequest, actorID string) (uuid.UUID, error) {
	if err := validateEvent(req); err != nil {
		return uuid.Nil, err
	}

	shipID, err := uuid.Parse(req.ShipmentID)
	if err != nil {
		return uuid.Nil, fmt.Errorf("shipment_id: %w", validator.ErrBadID)
	}

	if s.shipment != nil {
		ship, err := s.shipment.GetByID(ctx, shipID)
		if err != nil {
			return uuid.Nil, fmt.Errorf("shipment: %w", err)
		}
		if ship == nil {
			return uuid.Nil, fmt.Errorf("shipment not found: %w", model.ErrNotFound)
		}
	}

	e := &model.TrackingEvent{
		ID:          uuid.New(),
		ShipmentID:  shipID,
		EventType:   req.EventType,
		Description: req.Description,
		Location:    req.Location,
		City:        req.City,
		State:       req.State,
		Country:     req.Country,
		Latitude:    req.Latitude,
		Longitude:   req.Longitude,
		ActorID:     actorID,
		CreatedAt:   time.Now(),
	}

	if req.OccurredAt != "" {
		if t, err := time.Parse(time.RFC3339, req.OccurredAt); err == nil {
			e.OccurredAt = t
		} else {
			e.OccurredAt = time.Now()
		}
	} else {
		e.OccurredAt = time.Now()
	}

	if req.DriverID != "" {
		if u, err := uuid.Parse(req.DriverID); err == nil {
			e.DriverID = &u
		}
	}
	if req.VehicleID != "" {
		if u, err := uuid.Parse(req.VehicleID); err == nil {
			e.VehicleID = &u
		}
	}
	if req.WarehouseID != "" {
		if u, err := uuid.Parse(req.WarehouseID); err == nil {
			e.WarehouseID = &u
		}
	}

	id, err := s.repo.Create(ctx, e)
	if err != nil {
		return uuid.Nil, fmt.Errorf("create event: %w", err)
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "tracking_event", EntityID: id, Action: audit.ActionCreate,
			NewValues: map[string]interface{}{"shipment_id": e.ShipmentID, "event_type": e.EventType},
		})
	}
	return id, nil
}

func validateEvent(req model.CreateTrackingEventRequest) error {
	if _, err := uuid.Parse(req.ShipmentID); err != nil {
		return fmt.Errorf("shipment_id: %w", validator.ErrBadID)
	}
	switch req.EventType {
	case model.EventTypeCreated, model.EventTypeBooked, model.EventTypePickup, model.EventTypeArrived,
		model.EventTypeDeparted, model.EventTypeOutForDelivery, model.EventTypeDelivered, model.EventTypeFailedAttempt,
		model.EventTypeReturned, model.EventTypeHeld, model.EventTypeCancelled, model.EventTypeInspection,
		model.EventTypeException, model.EventTypeAddressUpdated:
	default:
		return fmt.Errorf("event_type %q invalid: %w", req.EventType, validator.ErrBadFormat)
	}
	if req.Latitude < -90 || req.Latitude > 90 {
		return fmt.Errorf("latitude: %w", validator.ErrOutOfRange)
	}
	if req.Longitude < -180 || req.Longitude > 180 {
		return fmt.Errorf("longitude: %w", validator.ErrOutOfRange)
	}
	return nil
}

func (s *TrackingService) GetEvent(ctx context.Context, id uuid.UUID) (*model.TrackingEvent, error) {
	if id == uuid.Nil {
		return nil, model.ErrInvalidInput
	}
	e, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return nil, err
	}
	if e == nil {
		return nil, model.ErrNotFound
	}
	return e, nil
}

func (s *TrackingService) ListForShipment(ctx context.Context, shipmentID uuid.UUID) ([]*model.TrackingEvent, error) {
	if shipmentID == uuid.Nil {
		return nil, model.ErrInvalidInput
	}
	return s.repo.ListByShipment(ctx, shipmentID)
}

func (s *TrackingService) LatestForShipment(ctx context.Context, shipmentID uuid.UUID) (*model.TrackingEvent, error) {
	if shipmentID == uuid.Nil {
		return nil, model.ErrInvalidInput
	}
	e, err := s.repo.GetLatestForShipment(ctx, shipmentID)
	if err != nil {
		return nil, err
	}
	if e == nil {
		return nil, model.ErrNotFound
	}
	return e, nil
}

func (s *TrackingService) List(ctx context.Context, f *model.TrackingEventFilter) ([]*model.TrackingEvent, int, error) {
	if f == nil {
		f = &model.TrackingEventFilter{}
	}
	if f.Limit <= 0 {
		f.Limit = 50
	}
	if f.Limit > 500 {
		f.Limit = 500
	}
	if f.Offset < 0 {
		f.Offset = 0
	}
	return s.repo.List(ctx, f)
}
