package service

import (
	"context"
	"fmt"
	"strings"
	"time"

	"freightline.dev/api/internal/audit"
	"freightline.dev/api/internal/cache"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/repository"
	"freightline.dev/api/internal/validator"
	"github.com/google/uuid"
)

type RouteService struct {
	repo     repository.RouteRepository
	shipment repository.ShipmentRepository
	driver   repository.DriverRepository
	vehicle  repository.VehicleRepository
	audit    audit.Logger
	cache    *cache.Cache
}

func NewRouteService(
	repo repository.RouteRepository,
	sh repository.ShipmentRepository,
	dr repository.DriverRepository,
	veh repository.VehicleRepository,
	log audit.Logger,
	c *cache.Cache,
) *RouteService {
	return &RouteService{repo: repo, shipment: sh, driver: dr, vehicle: veh, audit: log, cache: c}
}

func (s *RouteService) Create(ctx context.Context, req model.CreateRouteRequest, actorID string) (uuid.UUID, error) {
	if err := validateCreateRoute(req); err != nil {
		return uuid.Nil, err
	}

	startTime, err := time.Parse(time.RFC3339, req.ScheduledStart)
	if err != nil {
		return uuid.Nil, fmt.Errorf("scheduled_start: %w", validator.ErrBadFormat)
	}

	r := &model.Route{
		ID:             uuid.New(),
		Code:           req.Code,
		Name:           req.Name,
		Status:         model.RouteStatusPlanned,
		ScheduledStart: startTime,
		Notes:          req.Notes,
		CreatedAt:      time.Now(),
		UpdatedAt:      time.Now(),
	}
	if r.Code == "" {
		r.Code = "RT-" + strings.ToUpper(strings.ReplaceAll(uuid.New().String()[:8], "-", ""))
	}

	if req.ScheduledEnd != "" {
		if t, err := time.Parse(time.RFC3339, req.ScheduledEnd); err == nil {
			r.ScheduledEnd = t
		}
	}
	if req.DriverID != "" {
		if d, err := uuid.Parse(req.DriverID); err == nil {
			r.DriverID = &d
		}
	}
	if req.VehicleID != "" {
		if v, err := uuid.Parse(req.VehicleID); err == nil {
			r.VehicleID = &v
		}
	}
	if req.OriginWarehouseID != "" {
		if w, err := uuid.Parse(req.OriginWarehouseID); err == nil {
			r.OriginWarehouseID = &w
		}
	}

	stops := make([]*model.RouteStop, 0, len(req.ShipmentIDs))
	for i, sid := range req.ShipmentIDs {
		shipID, err := uuid.Parse(sid)
		if err != nil {
			return uuid.Nil, fmt.Errorf("shipment_ids[%d]: %w", i, validator.ErrBadID)
		}
		stop := &model.RouteStop{
			ID:         uuid.New(),
			ShipmentID: shipID,
			StopOrder:  i + 1,
			StopType:   "delivery",
			PlannedETA: startTime.Add(time.Duration(30*(i+1)) * time.Minute),
		}
		if s.shipment != nil {
			ship, err := s.shipment.GetByID(ctx, shipID)
			if err == nil && ship != nil {
				stop.Address = ship.DeliveryAddress
				stop.City = ship.DeliveryCity
				stop.State = ship.DeliveryState
			}
		}
		stops = append(stops, stop)
	}

	id, err := s.repo.Create(ctx, r, stops)
	if err != nil {
		return uuid.Nil, fmt.Errorf("create route: %w", err)
	}

	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "route", EntityID: id, Action: audit.ActionCreate,
			NewValues: map[string]interface{}{"code": r.Code, "stops": len(stops)},
		})
	}
	return id, nil
}

func validateCreateRoute(req model.CreateRouteRequest) error {
	if err := validator.RequireNonEmpty("name", req.Name); err != nil {
		return err
	}
	if req.ScheduledStart == "" {
		return fmt.Errorf("scheduled_start: %w", validator.ErrEmptyField)
	}
	if len(req.ShipmentIDs) == 0 {
		return fmt.Errorf("shipment_ids: %w", validator.ErrEmptyField)
	}
	return nil
}

func (s *RouteService) GetByID(ctx context.Context, id uuid.UUID) (*model.Route, error) {
	if id == uuid.Nil {
		return nil, model.ErrInvalidInput
	}
	r, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return nil, err
	}
	if r == nil {
		return nil, model.ErrNotFound
	}
	return r, nil
}

func (s *RouteService) GetWithStops(ctx context.Context, id uuid.UUID) (*model.RouteWithStops, error) {
	if id == uuid.Nil {
		return nil, model.ErrInvalidInput
	}
	out, err := s.repo.GetWithStops(ctx, id)
	if err != nil {
		return nil, err
	}
	if out == nil {
		return nil, model.ErrNotFound
	}
	return out, nil
}

func (s *RouteService) Update(ctx context.Context, id uuid.UUID, req model.UpdateRouteRequest, actorID string) error {
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}
	if existing.IsTerminal() {
		return fmt.Errorf("route terminal: %w", model.ErrConflict)
	}
	if req.Name != "" {
		existing.Name = req.Name
	}
	if req.DriverID != "" {
		if d, err := uuid.Parse(req.DriverID); err == nil {
			existing.DriverID = &d
		}
	}
	if req.VehicleID != "" {
		if v, err := uuid.Parse(req.VehicleID); err == nil {
			existing.VehicleID = &v
		}
	}
	if req.ScheduledStart != "" {
		if t, err := time.Parse(time.RFC3339, req.ScheduledStart); err == nil {
			existing.ScheduledStart = t
		}
	}
	if req.ScheduledEnd != "" {
		if t, err := time.Parse(time.RFC3339, req.ScheduledEnd); err == nil {
			existing.ScheduledEnd = t
		}
	}
	if req.PlannedDistance > 0 {
		existing.PlannedDistance = req.PlannedDistance
	}
	if req.PlannedDuration > 0 {
		existing.PlannedDuration = req.PlannedDuration
	}
	if req.Notes != "" {
		existing.Notes = req.Notes
	}
	if err := s.repo.Update(ctx, id, existing); err != nil {
		return fmt.Errorf("update route: %w", err)
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "route", EntityID: id, Action: audit.ActionUpdate,
		})
	}
	return nil
}

func (s *RouteService) Delete(ctx context.Context, id uuid.UUID, actorID string) error {
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}
	if existing.Status == model.RouteStatusActive {
		return fmt.Errorf("route active: %w", model.ErrConflict)
	}
	if err := s.repo.Delete(ctx, id); err != nil {
		return err
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "route", EntityID: id, Action: audit.ActionDelete,
		})
	}
	return nil
}

func (s *RouteService) Start(ctx context.Context, id uuid.UUID, actorID string) error {
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}
	if !existing.CanTransitionTo(model.RouteStatusActive) {
		return fmt.Errorf("cannot start in status %q: %w", existing.Status, model.ErrInvalidStatus)
	}
	if err := s.repo.UpdateStatus(ctx, id, model.RouteStatusActive); err != nil {
		return fmt.Errorf("start route: %w", err)
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "route", EntityID: id, Action: audit.ActionDispatch,
		})
	}
	return nil
}

func (s *RouteService) Complete(ctx context.Context, id uuid.UUID, actorID string) error {
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}
	if !existing.CanTransitionTo(model.RouteStatusCompleted) {
		return fmt.Errorf("cannot complete in status %q: %w", existing.Status, model.ErrInvalidStatus)
	}
	if err := s.repo.UpdateStatus(ctx, id, model.RouteStatusCompleted); err != nil {
		return fmt.Errorf("complete: %w", err)
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "route", EntityID: id, Action: audit.ActionStatusSet,
		})
	}
	return nil
}

func (s *RouteService) Cancel(ctx context.Context, id uuid.UUID, reason, actorID string) error {
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}
	if !existing.CanTransitionTo(model.RouteStatusCancelled) {
		return fmt.Errorf("cannot cancel in status %q: %w", existing.Status, model.ErrInvalidStatus)
	}
	if err := s.repo.UpdateStatus(ctx, id, model.RouteStatusCancelled); err != nil {
		return fmt.Errorf("cancel: %w", err)
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "route", EntityID: id, Action: audit.ActionCancel,
			Notes: reason,
		})
	}
	return nil
}

func (s *RouteService) CompleteStop(ctx context.Context, stopID uuid.UUID, actorID string) error {
	if err := s.repo.CompleteStop(ctx, stopID); err != nil {
		return fmt.Errorf("complete stop: %w", err)
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "route_stop", EntityID: stopID, Action: audit.ActionStatusSet,
		})
	}
	return nil
}

func (s *RouteService) List(ctx context.Context, f *model.RouteFilter) ([]*model.Route, int, error) {
	if f == nil {
		f = &model.RouteFilter{}
	}
	if f.Limit <= 0 {
		f.Limit = 25
	}
	if f.Limit > 200 {
		f.Limit = 200
	}
	if f.Offset < 0 {
		f.Offset = 0
	}
	return s.repo.List(ctx, f)
}

func (s *RouteService) ListByDriver(ctx context.Context, driverID uuid.UUID, limit int) ([]*model.Route, error) {
	if driverID == uuid.Nil {
		return nil, model.ErrInvalidInput
	}
	if limit <= 0 {
		limit = 50
	}
	return s.repo.ListByDriver(ctx, driverID, limit)
}
