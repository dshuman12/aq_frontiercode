package service

import (
	"context"
	"fmt"
	"strings"
	"time"

	"freightline.dev/api/internal/audit"
	"freightline.dev/api/internal/cache"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/repository"
	"freightline.dev/api/internal/validator"
	"github.com/google/uuid"
)

type PaymentService struct {
	repo     repository.PaymentRepository
	invoice  repository.InvoiceRepository
	customer repository.CustomerRepository
	audit    audit.Logger
	cache    *cache.Cache
}

func NewPaymentService(
	repo repository.PaymentRepository,
	inv repository.InvoiceRepository,
	cust repository.CustomerRepository,
	log audit.Logger,
	c *cache.Cache,
) *PaymentService {
	return &PaymentService{repo: repo, invoice: inv, customer: cust, audit: log, cache: c}
}

func generatePaymentReference() string {
	return "PAY-" + time.Now().Format("20060102") + "-" + strings.ToUpper(strings.ReplaceAll(uuid.New().String()[:6], "-", ""))
}

func (s *PaymentService) Create(ctx context.Context, req model.CreatePaymentRequest, actorID string) (uuid.UUID, error) {
	if err := validateCreatePayment(req); err != nil {
		return uuid.Nil, err
	}

	invID, err := uuid.Parse(req.InvoiceID)
	if err != nil {
		return uuid.Nil, fmt.Errorf("invoice_id: %w", validator.ErrBadID)
	}

	var inv *model.Invoice
	if s.invoice != nil {
		inv, err = s.invoice.GetByID(ctx, invID)
		if err != nil {
			return uuid.Nil, fmt.Errorf("invoice lookup: %w", err)
		}
		if inv == nil {
			return uuid.Nil, model.ErrNotFound
		}
		if inv.Status == model.InvoiceStatusVoided {
			return uuid.Nil, fmt.Errorf("cannot pay voided invoice: %w", model.ErrConflict)
		}
		if req.Amount > inv.BalanceDue {
			return uuid.Nil, fmt.Errorf("amount %.2f exceeds balance %.2f: %w", req.Amount, inv.BalanceDue, validator.ErrOutOfRange)
		}
	}

	p := &model.Payment{
		ID:            uuid.New(),
		ReferenceNo:   generatePaymentReference(),
		InvoiceID:     invID,
		Method:        req.Method,
		Status:        model.PaymentStatusPending,
		Amount:        req.Amount,
		Currency:      strings.ToUpper(req.Currency),
		ProcessorRef:  req.ProcessorRef,
		BankReference: req.BankReference,
		Notes:         req.Notes,
		CreatedAt:     time.Now(),
		UpdatedAt:     time.Now(),
	}

	if inv != nil {
		p.CustomerID = inv.CustomerID
	}

	if p.Currency == "" {
		p.Currency = "USD"
	}
	if req.PaymentDate != "" {
		if t, err := time.Parse("2006-01-02", req.PaymentDate); err == nil {
			p.PaymentDate = t
		}
	} else {
		p.PaymentDate = time.Now()
	}

	id, err := s.repo.Create(ctx, p)
	if err != nil {
		return uuid.Nil, fmt.Errorf("create payment: %w", err)
	}

	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "payment", EntityID: id, Action: audit.ActionCreate,
			NewValues: map[string]interface{}{"ref": p.ReferenceNo, "amount": p.Amount, "method": p.Method},
		})
	}
	return id, nil
}

func validateCreatePayment(req model.CreatePaymentRequest) error {
	if _, err := uuid.Parse(req.InvoiceID); err != nil {
		return fmt.Errorf("invoice_id: %w", validator.ErrBadID)
	}
	switch req.Method {
	case model.PaymentMethodCash, model.PaymentMethodCheck, model.PaymentMethodWire,
		model.PaymentMethodACH, model.PaymentMethodCard, model.PaymentMethodCreditNote, model.PaymentMethodOther:
	default:
		return fmt.Errorf("method %q invalid: %w", req.Method, validator.ErrBadFormat)
	}
	if req.Amount <= 0 {
		return fmt.Errorf("amount: %w", validator.ErrOutOfRange)
	}
	return nil
}

func (s *PaymentService) GetByID(ctx context.Context, id uuid.UUID) (*model.Payment, error) {
	if id == uuid.Nil {
		return nil, model.ErrInvalidInput
	}
	p, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return nil, err
	}
	if p == nil {
		return nil, model.ErrNotFound
	}
	return p, nil
}

func (s *PaymentService) Update(ctx context.Context, id uuid.UUID, notes, procRef, bankRef, actorID string) error {
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}
	if notes != "" {
		existing.Notes = notes
	}
	if procRef != "" {
		existing.ProcessorRef = procRef
	}
	if bankRef != "" {
		existing.BankReference = bankRef
	}
	if err := s.repo.Update(ctx, id, existing); err != nil {
		return fmt.Errorf("update payment: %w", err)
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "payment", EntityID: id, Action: audit.ActionUpdate,
		})
	}
	return nil
}

func (s *PaymentService) Clear(ctx context.Context, id uuid.UUID, actorID string) error {
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}
	if existing.Status == model.PaymentStatusCleared {
		return nil
	}
	if existing.Status == model.PaymentStatusReversed || existing.Status == model.PaymentStatusFailed {
		return fmt.Errorf("payment in non-clearable state %q: %w", existing.Status, model.ErrConflict)
	}

	if err := s.repo.UpdateStatus(ctx, id, model.PaymentStatusCleared); err != nil {
		return fmt.Errorf("clear payment: %w", err)
	}

	if s.invoice != nil {
		if err := s.invoice.ApplyPayment(ctx, existing.InvoiceID, existing.Amount); err == nil {
			inv, _ := s.invoice.GetByID(ctx, existing.InvoiceID)
			if inv != nil {
				if inv.BalanceDue <= 0 {
					_ = s.invoice.UpdateStatus(ctx, inv.ID, model.InvoiceStatusPaid)
				} else if inv.AmountPaid > 0 {
					_ = s.invoice.UpdateStatus(ctx, inv.ID, model.InvoiceStatusPartiallyPaid)
				}
			}
		}
	}

	if s.customer != nil && existing.CustomerID != uuid.Nil {
		_ = s.customer.UpdateOutstandingBalance(ctx, existing.CustomerID, -existing.Amount)
	}

	if s.cache != nil {
		s.cache.Delete("invoice:" + existing.InvoiceID.String())
	}

	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "payment", EntityID: id, Action: audit.ActionPay,
			Notes: fmt.Sprintf("cleared %.2f", existing.Amount),
		})
	}
	return nil
}

func (s *PaymentService) Reverse(ctx context.Context, id uuid.UUID, reason, actorID string) error {
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}
	if existing.Status == model.PaymentStatusReversed {
		return nil
	}
	wasCleared := existing.Status == model.PaymentStatusCleared

	if err := s.repo.UpdateStatus(ctx, id, model.PaymentStatusReversed); err != nil {
		return fmt.Errorf("reverse: %w", err)
	}

	if wasCleared && s.invoice != nil {
		_ = s.invoice.ApplyPayment(ctx, existing.InvoiceID, -existing.Amount)
	}
	if wasCleared && s.customer != nil && existing.CustomerID != uuid.Nil {
		_ = s.customer.UpdateOutstandingBalance(ctx, existing.CustomerID, existing.Amount)
	}

	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "payment", EntityID: id, Action: audit.ActionRefund,
			Notes: reason,
		})
	}
	return nil
}

func (s *PaymentService) Refund(ctx context.Context, id uuid.UUID, req model.RefundPaymentRequest, actorID string) error {
	if req.Amount <= 0 {
		return fmt.Errorf("amount: %w", validator.ErrOutOfRange)
	}
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}
	if !existing.CanRefund() {
		return fmt.Errorf("payment cannot be refunded: %w", model.ErrConflict)
	}
	if req.Amount > existing.Amount {
		return fmt.Errorf("refund exceeds payment: %w", validator.ErrOutOfRange)
	}

	if err := s.repo.UpdateStatus(ctx, id, model.PaymentStatusRefunded); err != nil {
		return fmt.Errorf("refund: %w", err)
	}

	if s.invoice != nil {
		_ = s.invoice.ApplyPayment(ctx, existing.InvoiceID, -req.Amount)
	}
	if s.customer != nil && existing.CustomerID != uuid.Nil {
		_ = s.customer.UpdateOutstandingBalance(ctx, existing.CustomerID, req.Amount)
	}

	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "payment", EntityID: id, Action: audit.ActionRefund,
			Notes: fmt.Sprintf("refund %.2f: %s", req.Amount, req.Reason),
		})
	}
	return nil
}

func (s *PaymentService) List(ctx context.Context, f *model.PaymentFilter) ([]*model.Payment, int, error) {
	if f == nil {
		f = &model.PaymentFilter{}
	}
	if f.Limit <= 0 {
		f.Limit = 25
	}
	if f.Limit > 200 {
		f.Limit = 200
	}
	if f.Offset < 0 {
		f.Offset = 0
	}
	return s.repo.List(ctx, f)
}

func (s *PaymentService) ListByInvoice(ctx context.Context, invoiceID uuid.UUID) ([]*model.Payment, error) {
	if invoiceID == uuid.Nil {
		return nil, model.ErrInvalidInput
	}
	return s.repo.ListByInvoice(ctx, invoiceID)
}

func (s *PaymentService) SumForInvoice(ctx context.Context, invoiceID uuid.UUID) (float64, error) {
	if invoiceID == uuid.Nil {
		return 0, model.ErrInvalidInput
	}
	return s.repo.SumForInvoice(ctx, invoiceID)
}
