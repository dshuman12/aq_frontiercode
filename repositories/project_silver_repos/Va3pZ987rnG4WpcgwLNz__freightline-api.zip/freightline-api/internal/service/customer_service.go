package service

import (
	"context"
	"errors"
	"fmt"
	"strings"
	"time"

	"freightline.dev/api/internal/audit"
	"freightline.dev/api/internal/cache"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/repository"
	"freightline.dev/api/internal/validator"
	"github.com/google/uuid"
)

type CustomerService struct {
	repo  repository.CustomerRepository
	audit audit.Logger
	cache *cache.Cache
}

func NewCustomerService(repo repository.CustomerRepository, log audit.Logger, c *cache.Cache) *CustomerService {
	return &CustomerService{repo: repo, audit: log, cache: c}
}

func (s *CustomerService) Create(ctx context.Context, req model.CreateCustomerRequest, actorID string) (uuid.UUID, error) {
	if err := validateCreateCustomer(req); err != nil {
		return uuid.Nil, err
	}

	existing, err := s.repo.GetByEmail(ctx, req.Email)
	if err != nil && !errors.Is(err, model.ErrNotFound) {
		return uuid.Nil, fmt.Errorf("check email: %w", err)
	}
	if existing != nil {
		return uuid.Nil, model.ErrDuplicate
	}

	c := &model.Customer{
		ID:             uuid.New(),
		CompanyName:    validator.Sanitize(req.CompanyName),
		ContactName:    validator.Sanitize(req.ContactName),
		Email:          strings.ToLower(strings.TrimSpace(req.Email)),
		Phone:          validator.Sanitize(req.Phone),
		Type:           req.Type,
		TaxID:          req.TaxID,
		BillingAddress: req.BillingAddress,
		BillingCity:    req.BillingCity,
		BillingState:   req.BillingState,
		BillingZip:     req.BillingZip,
		BillingCountry: req.BillingCountry,
		CreditLimit:    req.CreditLimit,
		PaymentTerms:   req.PaymentTerms,
		IsActive:       true,
		Notes:          req.Notes,
		CreatedAt:      time.Now(),
		UpdatedAt:      time.Now(),
	}

	id, err := s.repo.Create(ctx, c)
	if err != nil {
		return uuid.Nil, fmt.Errorf("create customer: %w", err)
	}

	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID:    actorID,
			EntityType: "customer",
			EntityID:   id,
			Action:     audit.ActionCreate,
			NewValues:  map[string]interface{}{"email": c.Email, "company_name": c.CompanyName},
		})
	}

	return id, nil
}

func validateCreateCustomer(req model.CreateCustomerRequest) error {
	if err := validator.RequireNonEmpty("company_name", req.CompanyName); err != nil {
		return err
	}
	if err := validator.RequireNonEmpty("contact_name", req.ContactName); err != nil {
		return err
	}
	if err := validator.ValidateEmail(req.Email); err != nil {
		return err
	}
	if err := validator.ValidatePhone(req.Phone); err != nil {
		return err
	}
	if req.Type == "" {
		return fmt.Errorf("type: %w", validator.ErrEmptyField)
	}
	switch req.Type {
	case model.CustomerTypeIndividual, model.CustomerTypeBusiness, model.CustomerTypeGov:
	default:
		return fmt.Errorf("type: invalid value %q: %w", req.Type, validator.ErrBadFormat)
	}
	if err := validator.ValidateNonNegative("credit_limit", req.CreditLimit); err != nil {
		return err
	}
	if req.PaymentTerms < 0 || req.PaymentTerms > 365 {
		return fmt.Errorf("payment_terms: %w", validator.ErrOutOfRange)
	}
	return nil
}

func (s *CustomerService) GetByID(ctx context.Context, id uuid.UUID) (*model.Customer, error) {
	if id == uuid.Nil {
		return nil, model.ErrInvalidInput
	}
	cacheKey := fmt.Sprintf("customer:%s", id.String())
	if s.cache != nil {
		if v, ok := s.cache.Get(cacheKey); ok {
			if c, ok := v.(*model.Customer); ok {
				return c, nil
			}
		}
	}

	c, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return nil, err
	}
	if c == nil {
		return nil, model.ErrNotFound
	}
	if s.cache != nil {
		s.cache.Set(cacheKey, c)
	}
	return c, nil
}

func (s *CustomerService) GetByEmail(ctx context.Context, email string) (*model.Customer, error) {
	if err := validator.ValidateEmail(email); err != nil {
		return nil, err
	}
	c, err := s.repo.GetByEmail(ctx, email)
	if err != nil {
		return nil, err
	}
	if c == nil {
		return nil, model.ErrNotFound
	}
	return c, nil
}

func (s *CustomerService) Update(ctx context.Context, id uuid.UUID, req model.UpdateCustomerRequest, actorID string) error {
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return fmt.Errorf("customer not found: %w", model.ErrNotFound)
	}

	old := *existing

	if req.CompanyName != "" {
		existing.CompanyName = validator.Sanitize(req.CompanyName)
	}
	if req.ContactName != "" {
		existing.ContactName = validator.Sanitize(req.ContactName)
	}
	if req.Phone != "" {
		if err := validator.ValidatePhone(req.Phone); err != nil {
			return err
		}
		existing.Phone = req.Phone
	}
	if req.TaxID != "" {
		existing.TaxID = req.TaxID
	}
	if req.BillingAddress != "" {
		existing.BillingAddress = req.BillingAddress
	}
	if req.BillingCity != "" {
		existing.BillingCity = req.BillingCity
	}
	if req.BillingState != "" {
		existing.BillingState = req.BillingState
	}
	if req.BillingZip != "" {
		existing.BillingZip = req.BillingZip
	}
	if req.BillingCountry != "" {
		existing.BillingCountry = req.BillingCountry
	}
	if req.CreditLimit > 0 {
		existing.CreditLimit = req.CreditLimit
	}
	if req.PaymentTerms > 0 {
		existing.PaymentTerms = req.PaymentTerms
	}
	if req.Notes != "" {
		existing.Notes = req.Notes
	}

	if err := s.repo.Update(ctx, id, existing); err != nil {
		return fmt.Errorf("update: %w", err)
	}

	if s.cache != nil {
		s.cache.Delete(fmt.Sprintf("customer:%s", id.String()))
	}

	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID:    actorID,
			EntityType: "customer",
			EntityID:   id,
			Action:     audit.ActionUpdate,
			OldValues:  map[string]interface{}{"company_name": old.CompanyName, "credit_limit": old.CreditLimit},
			NewValues:  map[string]interface{}{"company_name": existing.CompanyName, "credit_limit": existing.CreditLimit},
		})
	}
	return nil
}

func (s *CustomerService) Delete(ctx context.Context, id uuid.UUID, actorID string) error {
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}
	if existing.OutstandingBal > 0 {
		return fmt.Errorf("customer has outstanding balance: %w", model.ErrConflict)
	}
	if err := s.repo.Delete(ctx, id); err != nil {
		return fmt.Errorf("delete: %w", err)
	}
	if s.cache != nil {
		s.cache.Delete(fmt.Sprintf("customer:%s", id.String()))
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID:    actorID,
			EntityType: "customer",
			EntityID:   id,
			Action:     audit.ActionDelete,
		})
	}
	return nil
}

func (s *CustomerService) List(ctx context.Context, f *model.CustomerFilter) ([]*model.Customer, int, error) {
	if f == nil {
		f = &model.CustomerFilter{}
	}
	if f.Limit <= 0 {
		f.Limit = 25
	}
	if f.Limit > 200 {
		f.Limit = 200
	}
	if f.Offset < 0 {
		f.Offset = 0
	}
	return s.repo.List(ctx, f)
}

func (s *CustomerService) Activate(ctx context.Context, id uuid.UUID, actorID string) error {
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}
	if existing.IsActive {
		return nil
	}
	if err := s.repo.SetActive(ctx, id, true); err != nil {
		return fmt.Errorf("activate: %w", err)
	}
	if s.cache != nil {
		s.cache.Delete(fmt.Sprintf("customer:%s", id.String()))
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID:    actorID,
			EntityType: "customer",
			EntityID:   id,
			Action:     audit.ActionStatusSet,
			NewValues:  map[string]interface{}{"is_active": true},
		})
	}
	return nil
}

func (s *CustomerService) Deactivate(ctx context.Context, id uuid.UUID, actorID string) error {
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}
	if !existing.IsActive {
		return nil
	}
	if err := s.repo.SetActive(ctx, id, false); err != nil {
		return fmt.Errorf("deactivate: %w", err)
	}
	if s.cache != nil {
		s.cache.Delete(fmt.Sprintf("customer:%s", id.String()))
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID:    actorID,
			EntityType: "customer",
			EntityID:   id,
			Action:     audit.ActionStatusSet,
			NewValues:  map[string]interface{}{"is_active": false},
		})
	}
	return nil
}

func (s *CustomerService) ChargeBalance(ctx context.Context, id uuid.UUID, amount float64, actorID string) error {
	if amount == 0 {
		return nil
	}
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}
	if !existing.CanCharge(amount) {
		return fmt.Errorf("customer cannot accept charge: %w", model.ErrInsufficient)
	}
	if err := s.repo.UpdateOutstandingBalance(ctx, id, amount); err != nil {
		return fmt.Errorf("charge balance: %w", err)
	}
	if s.cache != nil {
		s.cache.Delete(fmt.Sprintf("customer:%s", id.String()))
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID:    actorID,
			EntityType: "customer",
			EntityID:   id,
			Action:     audit.ActionUpdate,
			Notes:      fmt.Sprintf("charge %.2f", amount),
		})
	}
	return nil
}

func (s *CustomerService) CreditBalance(ctx context.Context, id uuid.UUID, amount float64, actorID string) error {
	if amount <= 0 {
		return fmt.Errorf("amount must be positive: %w", validator.ErrOutOfRange)
	}
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}
	if err := s.repo.UpdateOutstandingBalance(ctx, id, -amount); err != nil {
		return fmt.Errorf("credit balance: %w", err)
	}
	if s.cache != nil {
		s.cache.Delete(fmt.Sprintf("customer:%s", id.String()))
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID:    actorID,
			EntityType: "customer",
			EntityID:   id,
			Action:     audit.ActionPay,
			Notes:      fmt.Sprintf("credit %.2f", amount),
		})
	}
	return nil
}

func (s *CustomerService) AvailableCredit(ctx context.Context, id uuid.UUID) (float64, error) {
	c, err := s.GetByID(ctx, id)
	if err != nil {
		return 0, err
	}
	return c.AvailableCredit(), nil
}
