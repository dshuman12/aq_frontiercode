package service

import (
	"context"
	"fmt"
	"strings"
	"time"

	"freightline.dev/api/internal/audit"
	"freightline.dev/api/internal/cache"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/repository"
	"freightline.dev/api/internal/validator"
	"github.com/google/uuid"
)

type ShipmentService struct {
	repo      repository.ShipmentRepository
	tracking  repository.TrackingEventRepository
	customer  repository.CustomerRepository
	driver    repository.DriverRepository
	vehicle   repository.VehicleRepository
	audit     audit.Logger
	cache     *cache.Cache
}

func NewShipmentService(
	repo repository.ShipmentRepository,
	track repository.TrackingEventRepository,
	cust repository.CustomerRepository,
	drv repository.DriverRepository,
	veh repository.VehicleRepository,
	log audit.Logger,
	c *cache.Cache,
) *ShipmentService {
	return &ShipmentService{
		repo: repo, tracking: track, customer: cust, driver: drv, vehicle: veh,
		audit: log, cache: c,
	}
}

func generateTrackingNumber() string {
	now := time.Now().UTC()
	return fmt.Sprintf("FL%s%s",
		now.Format("060102"),
		strings.ReplaceAll(uuid.New().String()[:8], "-", ""))
}

func (s *ShipmentService) Create(ctx context.Context, req model.CreateShipmentRequest, actorID string) (uuid.UUID, error) {
	if err := validateCreateShipment(req); err != nil {
		return uuid.Nil, err
	}

	custID, err := uuid.Parse(req.CustomerID)
	if err != nil {
		return uuid.Nil, fmt.Errorf("customer_id: %w", validator.ErrBadID)
	}

	if s.customer != nil {
		cust, err := s.customer.GetByID(ctx, custID)
		if err != nil {
			return uuid.Nil, fmt.Errorf("customer not found: %w", err)
		}
		if cust != nil && !cust.IsActive {
			return uuid.Nil, fmt.Errorf("customer is inactive: %w", model.ErrConflict)
		}
	}

	sh := &model.Shipment{
		ID:                    uuid.New(),
		TrackingNumber:        generateTrackingNumber(),
		CustomerID:            custID,
		PickupName:            req.PickupName,
		PickupPhone:           req.PickupPhone,
		PickupAddress:         req.PickupAddress,
		PickupCity:            req.PickupCity,
		PickupState:           req.PickupState,
		PickupZip:             req.PickupZip,
		PickupCountry:         req.PickupCountry,
		DeliveryName:          req.DeliveryName,
		DeliveryPhone:         req.DeliveryPhone,
		DeliveryAddress:       req.DeliveryAddress,
		DeliveryCity:          req.DeliveryCity,
		DeliveryState:         req.DeliveryState,
		DeliveryZip:           req.DeliveryZip,
		DeliveryCountry:       req.DeliveryCountry,
		Status:                model.ShipmentStatusBooked,
		ServiceLevel:          req.ServiceLevel,
		WeightKg:              req.WeightKg,
		VolumeM3:              req.VolumeM3,
		Pieces:                req.Pieces,
		DeclaredValue:         req.DeclaredValue,
		IsFragile:             req.IsFragile,
		IsHazmat:              req.IsHazmat,
		RequiresRefrigeration: req.RequiresRefrigeration,
		RequiresSignature:     req.RequiresSignature,
		SpecialInstructions:   req.SpecialInstructions,
		CreatedAt:             time.Now(),
		UpdatedAt:             time.Now(),
	}

	if req.OriginWarehouseID != "" {
		if u, err := uuid.Parse(req.OriginWarehouseID); err == nil {
			sh.OriginWarehouseID = &u
		}
	}
	if req.DestWarehouseID != "" {
		if u, err := uuid.Parse(req.DestWarehouseID); err == nil {
			sh.DestWarehouseID = &u
		}
	}
	if req.ScheduledPickup != "" {
		if t, err := time.Parse(time.RFC3339, req.ScheduledPickup); err == nil {
			sh.ScheduledPickup = t
		}
	}
	if req.ScheduledDelivery != "" {
		if t, err := time.Parse(time.RFC3339, req.ScheduledDelivery); err == nil {
			sh.ScheduledDelivery = t
		}
	}

	sh.BaseRate = computeBaseRate(req.ServiceLevel, req.WeightKg)
	sh.FuelSurcharge = sh.BaseRate * 0.12
	if req.DeclaredValue > 0 {
		sh.InsuranceFee = req.DeclaredValue * 0.005
	}
	if req.IsHazmat {
		sh.HandlingFee += 75
	}
	if req.RequiresRefrigeration {
		sh.HandlingFee += 35
	}
	if req.IsFragile {
		sh.HandlingFee += 15
	}
	sh.TotalCharge = sh.CalculateTotal()

	id, err := s.repo.Create(ctx, sh)
	if err != nil {
		return uuid.Nil, fmt.Errorf("create shipment: %w", err)
	}

	if s.tracking != nil {
		_, _ = s.tracking.Create(ctx, &model.TrackingEvent{
			ShipmentID:  id,
			EventType:   model.EventTypeCreated,
			Status:      sh.Status,
			Description: "Shipment booked",
			ActorID:     actorID,
			OccurredAt:  time.Now(),
		})
	}

	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "shipment", EntityID: id, Action: audit.ActionCreate,
			NewValues: map[string]interface{}{"tracking": sh.TrackingNumber, "customer_id": sh.CustomerID},
		})
	}

	return id, nil
}

func validateCreateShipment(req model.CreateShipmentRequest) error {
	if _, err := uuid.Parse(req.CustomerID); err != nil {
		return fmt.Errorf("customer_id: %w", validator.ErrBadID)
	}
	if err := validator.RequireNonEmpty("pickup_name", req.PickupName); err != nil {
		return err
	}
	if err := validator.RequireNonEmpty("pickup_address", req.PickupAddress); err != nil {
		return err
	}
	if err := validator.RequireNonEmpty("pickup_city", req.PickupCity); err != nil {
		return err
	}
	if err := validator.RequireNonEmpty("delivery_name", req.DeliveryName); err != nil {
		return err
	}
	if err := validator.RequireNonEmpty("delivery_address", req.DeliveryAddress); err != nil {
		return err
	}
	if err := validator.RequireNonEmpty("delivery_city", req.DeliveryCity); err != nil {
		return err
	}
	if err := validator.ValidatePositive("weight_kg", req.WeightKg); err != nil {
		return err
	}
	switch req.ServiceLevel {
	case model.ServiceLevelStandard, model.ServiceLevelExpress, model.ServiceLevelOvernight,
		model.ServiceLevelEconomy, model.ServiceLevelSameDay:
	default:
		return fmt.Errorf("service_level %q invalid: %w", req.ServiceLevel, validator.ErrBadFormat)
	}
	if req.DeclaredValue < 0 {
		return fmt.Errorf("declared_value: %w", validator.ErrOutOfRange)
	}
	return nil
}

func computeBaseRate(level model.ServiceLevel, weightKg float64) float64 {
	base := 25.0
	switch level {
	case model.ServiceLevelEconomy:
		base = 18.0
	case model.ServiceLevelExpress:
		base = 45.0
	case model.ServiceLevelOvernight:
		base = 95.0
	case model.ServiceLevelSameDay:
		base = 140.0
	}
	return base + (weightKg * 0.65)
}

func (s *ShipmentService) GetByID(ctx context.Context, id uuid.UUID) (*model.Shipment, error) {
	if id == uuid.Nil {
		return nil, model.ErrInvalidInput
	}
	key := "shipment:" + id.String()
	if s.cache != nil {
		if v, ok := s.cache.Get(key); ok {
			if sh, ok := v.(*model.Shipment); ok {
				return sh, nil
			}
		}
	}
	sh, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return nil, err
	}
	if sh == nil {
		return nil, model.ErrNotFound
	}
	if s.cache != nil {
		s.cache.Set(key, sh)
	}
	return sh, nil
}

func (s *ShipmentService) GetByTrackingNumber(ctx context.Context, num string) (*model.Shipment, error) {
	if num == "" {
		return nil, model.ErrInvalidInput
	}
	sh, err := s.repo.GetByTrackingNumber(ctx, num)
	if err != nil {
		return nil, err
	}
	if sh == nil {
		return nil, model.ErrNotFound
	}
	return sh, nil
}

func (s *ShipmentService) Update(ctx context.Context, id uuid.UUID, req model.UpdateShipmentRequest, actorID string) error {
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}
	if existing.IsTerminal() {
		return fmt.Errorf("shipment is in terminal status: %w", model.ErrConflict)
	}
	if req.DeliveryName != "" {
		existing.DeliveryName = req.DeliveryName
	}
	if req.DeliveryPhone != "" {
		existing.DeliveryPhone = req.DeliveryPhone
	}
	if req.DeliveryAddress != "" {
		existing.DeliveryAddress = req.DeliveryAddress
	}
	if req.SpecialInstructions != "" {
		existing.SpecialInstructions = req.SpecialInstructions
	}
	if req.ScheduledPickup != "" {
		if t, err := time.Parse(time.RFC3339, req.ScheduledPickup); err == nil {
			existing.ScheduledPickup = t
		}
	}
	if req.ScheduledDelivery != "" {
		if t, err := time.Parse(time.RFC3339, req.ScheduledDelivery); err == nil {
			existing.ScheduledDelivery = t
		}
	}
	if req.DeclaredValue >= 0 {
		existing.DeclaredValue = req.DeclaredValue
		existing.InsuranceFee = req.DeclaredValue * 0.005
		existing.TotalCharge = existing.CalculateTotal()
	}

	if err := s.repo.Update(ctx, id, existing); err != nil {
		return fmt.Errorf("update shipment: %w", err)
	}
	if s.cache != nil {
		s.cache.Delete("shipment:" + id.String())
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "shipment", EntityID: id, Action: audit.ActionUpdate,
		})
	}
	return nil
}

func (s *ShipmentService) Cancel(ctx context.Context, id uuid.UUID, reason, actorID string) error {
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}
	if existing.IsDelivered() {
		return fmt.Errorf("delivered shipment cannot be cancelled: %w", model.ErrConflict)
	}
	if existing.IsCancelled() {
		return nil
	}
	if err := s.repo.UpdateStatus(ctx, id, model.ShipmentStatusCancelled); err != nil {
		return fmt.Errorf("cancel: %w", err)
	}
	if s.tracking != nil {
		_, _ = s.tracking.Create(ctx, &model.TrackingEvent{
			ShipmentID: id, EventType: model.EventTypeCancelled,
			Status: model.ShipmentStatusCancelled,
			Description: "Cancelled: " + reason,
			ActorID: actorID, OccurredAt: time.Now(),
		})
	}
	if s.cache != nil {
		s.cache.Delete("shipment:" + id.String())
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "shipment", EntityID: id, Action: audit.ActionCancel,
			Notes: reason,
		})
	}
	return nil
}

func (s *ShipmentService) AssignDriver(ctx context.Context, id, driverID uuid.UUID, actorID string) error {
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}
	if existing.IsTerminal() {
		return fmt.Errorf("shipment terminal: %w", model.ErrConflict)
	}
	if s.driver != nil {
		d, err := s.driver.GetByID(ctx, driverID)
		if err != nil {
			return fmt.Errorf("driver not found: %w", err)
		}
		if d == nil || !d.IsAvailable() {
			return fmt.Errorf("driver not available: %w", model.ErrUnavailable)
		}
	}
	if err := s.repo.AssignDriver(ctx, id, driverID); err != nil {
		return fmt.Errorf("assign driver: %w", err)
	}
	if s.cache != nil {
		s.cache.Delete("shipment:" + id.String())
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "shipment", EntityID: id, Action: audit.ActionAssign,
			NewValues: map[string]interface{}{"driver_id": driverID},
		})
	}
	return nil
}

func (s *ShipmentService) AssignVehicle(ctx context.Context, id, vehicleID uuid.UUID, actorID string) error {
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}
	if s.vehicle != nil {
		v, err := s.vehicle.GetByID(ctx, vehicleID)
		if err != nil {
			return fmt.Errorf("vehicle not found: %w", err)
		}
		if v == nil {
			return model.ErrNotFound
		}
		if !v.CanCarry(existing.WeightKg, existing.VolumeM3) {
			return fmt.Errorf("vehicle insufficient for shipment: %w", model.ErrInsufficient)
		}
		if existing.RequiresRefrigeration && !v.IsRefrigerated {
			return fmt.Errorf("shipment needs refrigeration but vehicle isn't refrigerated: %w", model.ErrConflict)
		}
	}
	if err := s.repo.AssignVehicle(ctx, id, vehicleID); err != nil {
		return fmt.Errorf("assign vehicle: %w", err)
	}
	if s.cache != nil {
		s.cache.Delete("shipment:" + id.String())
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "shipment", EntityID: id, Action: audit.ActionAssign,
			NewValues: map[string]interface{}{"vehicle_id": vehicleID},
		})
	}
	return nil
}

func (s *ShipmentService) TransitionStatus(ctx context.Context, id uuid.UUID, next model.ShipmentStatus, location, actorID string) error {
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}
	if !existing.CanTransitionTo(next) {
		return fmt.Errorf("cannot transition %s -> %s: %w", existing.Status, next, model.ErrInvalidStatus)
	}

	if err := s.repo.UpdateStatus(ctx, id, next); err != nil {
		return fmt.Errorf("update status: %w", err)
	}

	switch next {
	case model.ShipmentStatusPickedUp:
		now := time.Now()
		existing.ActualPickup = &now
		_ = s.repo.Update(ctx, id, existing)
	case model.ShipmentStatusDelivered:
		now := time.Now()
		existing.ActualDelivery = &now
		_ = s.repo.Update(ctx, id, existing)
	}

	if s.tracking != nil {
		eventType := model.EventTypeArrived
		switch next {
		case model.ShipmentStatusPickedUp:
			eventType = model.EventTypePickup
		case model.ShipmentStatusOutForDelivery:
			eventType = model.EventTypeOutForDelivery
		case model.ShipmentStatusDelivered:
			eventType = model.EventTypeDelivered
		case model.ShipmentStatusFailed:
			eventType = model.EventTypeFailedAttempt
		case model.ShipmentStatusHeld:
			eventType = model.EventTypeHeld
		case model.ShipmentStatusReturned:
			eventType = model.EventTypeReturned
		}
		_, _ = s.tracking.Create(ctx, &model.TrackingEvent{
			ShipmentID: id, EventType: eventType, Status: next,
			Description: fmt.Sprintf("Status: %s", next),
			Location: location, ActorID: actorID, OccurredAt: time.Now(),
		})
	}

	if s.cache != nil {
		s.cache.Delete("shipment:" + id.String())
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "shipment", EntityID: id, Action: audit.ActionStatusSet,
			OldValues: map[string]interface{}{"status": existing.Status},
			NewValues: map[string]interface{}{"status": next},
		})
	}
	return nil
}

func (s *ShipmentService) Delete(ctx context.Context, id uuid.UUID, actorID string) error {
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}
	if existing.Status != model.ShipmentStatusDraft && existing.Status != model.ShipmentStatusCancelled {
		return fmt.Errorf("only draft/cancelled shipments can be deleted: %w", model.ErrConflict)
	}
	if err := s.repo.Delete(ctx, id); err != nil {
		return fmt.Errorf("delete shipment: %w", err)
	}
	if s.cache != nil {
		s.cache.Delete("shipment:" + id.String())
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "shipment", EntityID: id, Action: audit.ActionDelete,
		})
	}
	return nil
}

func (s *ShipmentService) List(ctx context.Context, f *model.ShipmentFilter) ([]*model.Shipment, int, error) {
	if f == nil {
		f = &model.ShipmentFilter{}
	}
	if f.Limit <= 0 {
		f.Limit = 25
	}
	if f.Limit > 200 {
		f.Limit = 200
	}
	if f.Offset < 0 {
		f.Offset = 0
	}
	return s.repo.List(ctx, f)
}

func (s *ShipmentService) ListByCustomer(ctx context.Context, customerID uuid.UUID, limit int) ([]*model.Shipment, error) {
	if customerID == uuid.Nil {
		return nil, model.ErrInvalidInput
	}
	if limit <= 0 {
		limit = 50
	}
	return s.repo.ListByCustomer(ctx, customerID, limit)
}

func (s *ShipmentService) ListOverdue(ctx context.Context) ([]*model.Shipment, error) {
	return s.repo.ListOverdue(ctx)
}

func (s *ShipmentService) StatusCounts(ctx context.Context) (map[model.ShipmentStatus]int, error) {
	return s.repo.CountByStatus(ctx)
}

func (s *ShipmentService) Quote(ctx context.Context, weightKg float64, level model.ServiceLevel, declaredValue float64) (float64, error) {
	if weightKg <= 0 {
		return 0, fmt.Errorf("weight: %w", validator.ErrOutOfRange)
	}
	base := computeBaseRate(level, weightKg)
	fuel := base * 0.12
	ins := declaredValue * 0.005
	return base + fuel + ins, nil
}
