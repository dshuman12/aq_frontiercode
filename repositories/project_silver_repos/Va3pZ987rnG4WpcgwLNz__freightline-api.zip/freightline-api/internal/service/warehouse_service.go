package service

import (
	"context"
	"fmt"
	"strings"
	"time"

	"freightline.dev/api/internal/audit"
	"freightline.dev/api/internal/cache"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/repository"
	"freightline.dev/api/internal/validator"
	"github.com/google/uuid"
)

type WarehouseService struct {
	repo  repository.WarehouseRepository
	audit audit.Logger
	cache *cache.Cache
}

func NewWarehouseService(repo repository.WarehouseRepository, log audit.Logger, c *cache.Cache) *WarehouseService {
	return &WarehouseService{repo: repo, audit: log, cache: c}
}

func (s *WarehouseService) Create(ctx context.Context, req model.CreateWarehouseRequest, actorID string) (uuid.UUID, error) {
	if err := validateCreateWarehouse(req); err != nil {
		return uuid.Nil, err
	}

	if existing, _ := s.repo.GetByCode(ctx, req.Code); existing != nil {
		return uuid.Nil, fmt.Errorf("warehouse code in use: %w", model.ErrDuplicate)
	}

	w := &model.Warehouse{
		ID:               uuid.New(),
		Code:             strings.ToUpper(strings.TrimSpace(req.Code)),
		Name:             req.Name,
		Type:             req.Type,
		Address:          req.Address,
		City:             req.City,
		State:            req.State,
		ZipCode:          req.ZipCode,
		Country:          req.Country,
		Latitude:         req.Latitude,
		Longitude:        req.Longitude,
		Phone:            req.Phone,
		ManagerName:      req.ManagerName,
		ManagerEmail:     req.ManagerEmail,
		Capacity:         req.Capacity,
		DocksCount:       req.DocksCount,
		OperatingHours:   req.OperatingHours,
		HasColdStorage:   req.HasColdStorage,
		HasHazmatLicense: req.HasHazmatLicense,
		IsActive:         true,
		CreatedAt:        time.Now(),
		UpdatedAt:        time.Now(),
	}

	id, err := s.repo.Create(ctx, w)
	if err != nil {
		return uuid.Nil, fmt.Errorf("create warehouse: %w", err)
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "warehouse", EntityID: id, Action: audit.ActionCreate,
			NewValues: map[string]interface{}{"code": w.Code, "name": w.Name},
		})
	}
	return id, nil
}

func validateCreateWarehouse(req model.CreateWarehouseRequest) error {
	if err := validator.RequireNonEmpty("code", req.Code); err != nil {
		return err
	}
	if err := validator.RequireNonEmpty("name", req.Name); err != nil {
		return err
	}
	if err := validator.RequireNonEmpty("address", req.Address); err != nil {
		return err
	}
	if err := validator.RequireNonEmpty("city", req.City); err != nil {
		return err
	}
	switch req.Type {
	case model.WarehouseTypeMain, model.WarehouseTypeRegional, model.WarehouseTypeDistribution,
		model.WarehouseTypeColdStorage, model.WarehouseTypeBondedDuty, model.WarehouseTypeCrossDock:
	default:
		return fmt.Errorf("type %q invalid: %w", req.Type, validator.ErrBadFormat)
	}
	if err := validator.ValidateNonNegative("capacity_m3", req.Capacity); err != nil {
		return err
	}
	if req.DocksCount < 0 {
		return fmt.Errorf("docks_count: %w", validator.ErrOutOfRange)
	}
	if req.Latitude != 0 || req.Longitude != 0 {
		if req.Latitude < -90 || req.Latitude > 90 {
			return fmt.Errorf("latitude: %w", validator.ErrOutOfRange)
		}
		if req.Longitude < -180 || req.Longitude > 180 {
			return fmt.Errorf("longitude: %w", validator.ErrOutOfRange)
		}
	}
	return nil
}

func (s *WarehouseService) GetByID(ctx context.Context, id uuid.UUID) (*model.Warehouse, error) {
	if id == uuid.Nil {
		return nil, model.ErrInvalidInput
	}
	key := "warehouse:" + id.String()
	if s.cache != nil {
		if v, ok := s.cache.Get(key); ok {
			if w, ok := v.(*model.Warehouse); ok {
				return w, nil
			}
		}
	}
	w, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return nil, err
	}
	if w == nil {
		return nil, model.ErrNotFound
	}
	if s.cache != nil {
		s.cache.Set(key, w)
	}
	return w, nil
}

func (s *WarehouseService) GetByCode(ctx context.Context, code string) (*model.Warehouse, error) {
	if code == "" {
		return nil, model.ErrInvalidInput
	}
	w, err := s.repo.GetByCode(ctx, code)
	if err != nil {
		return nil, err
	}
	if w == nil {
		return nil, model.ErrNotFound
	}
	return w, nil
}

func (s *WarehouseService) Update(ctx context.Context, id uuid.UUID, req model.UpdateWarehouseRequest, actorID string) error {
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}
	if req.Name != "" {
		existing.Name = req.Name
	}
	if req.Phone != "" {
		existing.Phone = req.Phone
	}
	if req.ManagerName != "" {
		existing.ManagerName = req.ManagerName
	}
	if req.ManagerEmail != "" {
		if err := validator.ValidateEmail(req.ManagerEmail); err != nil {
			return err
		}
		existing.ManagerEmail = req.ManagerEmail
	}
	if req.Capacity > 0 {
		existing.Capacity = req.Capacity
	}
	if req.DocksCount > 0 {
		existing.DocksCount = req.DocksCount
	}
	if req.OperatingHours != "" {
		existing.OperatingHours = req.OperatingHours
	}
	existing.HasColdStorage = req.HasColdStorage
	existing.HasHazmatLicense = req.HasHazmatLicense

	if err := s.repo.Update(ctx, id, existing); err != nil {
		return fmt.Errorf("update warehouse: %w", err)
	}
	if s.cache != nil {
		s.cache.Delete("warehouse:" + id.String())
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "warehouse", EntityID: id, Action: audit.ActionUpdate,
		})
	}
	return nil
}

func (s *WarehouseService) Delete(ctx context.Context, id uuid.UUID, actorID string) error {
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}
	if existing.UsedCapacity > 0 {
		return fmt.Errorf("warehouse not empty: %w", model.ErrConflict)
	}
	if err := s.repo.Delete(ctx, id); err != nil {
		return fmt.Errorf("delete warehouse: %w", err)
	}
	if s.cache != nil {
		s.cache.Delete("warehouse:" + id.String())
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "warehouse", EntityID: id, Action: audit.ActionDelete,
		})
	}
	return nil
}

func (s *WarehouseService) List(ctx context.Context, f *model.WarehouseFilter) ([]*model.Warehouse, int, error) {
	if f == nil {
		f = &model.WarehouseFilter{}
	}
	if f.Limit <= 0 {
		f.Limit = 25
	}
	if f.Limit > 200 {
		f.Limit = 200
	}
	if f.Offset < 0 {
		f.Offset = 0
	}
	return s.repo.List(ctx, f)
}

func (s *WarehouseService) Activate(ctx context.Context, id uuid.UUID, actorID string) error {
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}
	if existing.IsActive {
		return nil
	}
	if err := s.repo.SetActive(ctx, id, true); err != nil {
		return fmt.Errorf("activate: %w", err)
	}
	if s.cache != nil {
		s.cache.Delete("warehouse:" + id.String())
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "warehouse", EntityID: id, Action: audit.ActionStatusSet,
		})
	}
	return nil
}

func (s *WarehouseService) Deactivate(ctx context.Context, id uuid.UUID, actorID string) error {
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}
	if !existing.IsActive {
		return nil
	}
	if err := s.repo.SetActive(ctx, id, false); err != nil {
		return fmt.Errorf("deactivate: %w", err)
	}
	if s.cache != nil {
		s.cache.Delete("warehouse:" + id.String())
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "warehouse", EntityID: id, Action: audit.ActionStatusSet,
		})
	}
	return nil
}

func (s *WarehouseService) ReserveCapacity(ctx context.Context, id uuid.UUID, volumeM3 float64, actorID string) error {
	if volumeM3 <= 0 {
		return fmt.Errorf("volume must be positive: %w", validator.ErrOutOfRange)
	}
	existing, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return err
	}
	if existing == nil {
		return model.ErrNotFound
	}
	if !existing.CanAccept(volumeM3) {
		return fmt.Errorf("warehouse full: %w", model.ErrInsufficient)
	}
	if err := s.repo.UpdateUsedCapacity(ctx, id, volumeM3); err != nil {
		return fmt.Errorf("reserve: %w", err)
	}
	if s.cache != nil {
		s.cache.Delete("warehouse:" + id.String())
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "warehouse", EntityID: id, Action: audit.ActionUpdate,
			Notes: fmt.Sprintf("reserved %.2f m3", volumeM3),
		})
	}
	return nil
}

func (s *WarehouseService) ReleaseCapacity(ctx context.Context, id uuid.UUID, volumeM3 float64, actorID string) error {
	if volumeM3 <= 0 {
		return fmt.Errorf("volume must be positive: %w", validator.ErrOutOfRange)
	}
	if _, err := s.repo.GetByID(ctx, id); err != nil {
		return err
	}
	if err := s.repo.UpdateUsedCapacity(ctx, id, -volumeM3); err != nil {
		return fmt.Errorf("release: %w", err)
	}
	if s.cache != nil {
		s.cache.Delete("warehouse:" + id.String())
	}
	if s.audit != nil {
		s.audit.Log(ctx, &audit.Entry{
			ActorID: actorID, EntityType: "warehouse", EntityID: id, Action: audit.ActionUpdate,
			Notes: fmt.Sprintf("released %.2f m3", volumeM3),
		})
	}
	return nil
}
