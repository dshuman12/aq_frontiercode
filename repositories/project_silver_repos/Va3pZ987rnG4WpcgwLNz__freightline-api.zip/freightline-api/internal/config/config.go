package config

import (
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/joho/godotenv"
)

type Config struct {
	Server   ServerConfig
	Database DatabaseConfig
	JWT      JWTConfig
	Cache    CacheConfig
	Rate     RateLimitConfig
	Export   ExportConfig
	Notify   NotifyConfig
}

type ServerConfig struct {
	Port string
	Mode string
}

type DatabaseConfig struct {
	Host            string
	Port            string
	User            string
	Password        string
	Name            string
	SSLMode         string
	MaxOpenConns    int
	MaxIdleConns    int
	ConnMaxLifetime time.Duration
}

type JWTConfig struct {
	Secret string
	TTL    time.Duration
}

type CacheConfig struct {
	TTL      time.Duration
	Capacity int
}

type RateLimitConfig struct {
	PerSec int
	Burst  int
}

type ExportConfig struct {
	Dir string
}

type NotifyConfig struct {
	FromEmail  string
	SMSGateway string
}

func Load() (*Config, error) {
	_ = godotenv.Load()

	maxOpen, err := atoi(getEnv("DB_MAX_OPEN_CONNS", "25"))
	if err != nil {
		return nil, fmt.Errorf("DB_MAX_OPEN_CONNS: %w", err)
	}
	maxIdle, err := atoi(getEnv("DB_MAX_IDLE_CONNS", "5"))
	if err != nil {
		return nil, fmt.Errorf("DB_MAX_IDLE_CONNS: %w", err)
	}
	connMaxLife, err := time.ParseDuration(getEnv("DB_CONN_MAX_LIFETIME", "30m"))
	if err != nil {
		return nil, fmt.Errorf("DB_CONN_MAX_LIFETIME: %w", err)
	}
	jwtTTL, err := time.ParseDuration(getEnv("JWT_TTL", "24h"))
	if err != nil {
		return nil, fmt.Errorf("JWT_TTL: %w", err)
	}
	cacheTTL, err := time.ParseDuration(getEnv("CACHE_TTL", "5m"))
	if err != nil {
		return nil, fmt.Errorf("CACHE_TTL: %w", err)
	}
	cacheCap, err := atoi(getEnv("CACHE_CAPACITY", "10000"))
	if err != nil {
		return nil, fmt.Errorf("CACHE_CAPACITY: %w", err)
	}
	rps, err := atoi(getEnv("RATE_LIMIT_PER_SEC", "50"))
	if err != nil {
		return nil, fmt.Errorf("RATE_LIMIT_PER_SEC: %w", err)
	}
	burst, err := atoi(getEnv("RATE_LIMIT_BURST", "100"))
	if err != nil {
		return nil, fmt.Errorf("RATE_LIMIT_BURST: %w", err)
	}

	return &Config{
		Server: ServerConfig{
			Port: getEnv("SERVER_PORT", "8080"),
			Mode: getEnv("SERVER_MODE", "debug"),
		},
		Database: DatabaseConfig{
			Host:            getEnv("DB_HOST", "localhost"),
			Port:            getEnv("DB_PORT", "5432"),
			User:            getEnv("DB_USER", "freightline"),
			Password:        getEnv("DB_PASS", "freightline"),
			Name:            getEnv("DB_NAME", "freightline"),
			SSLMode:         getEnv("DB_SSLMODE", "disable"),
			MaxOpenConns:    maxOpen,
			MaxIdleConns:    maxIdle,
			ConnMaxLifetime: connMaxLife,
		},
		JWT: JWTConfig{
			Secret: getEnv("JWT_SECRET", "dev-secret-not-for-prod"),
			TTL:    jwtTTL,
		},
		Cache: CacheConfig{
			TTL:      cacheTTL,
			Capacity: cacheCap,
		},
		Rate: RateLimitConfig{
			PerSec: rps,
			Burst:  burst,
		},
		Export: ExportConfig{
			Dir: getEnv("EXPORT_DIR", "/tmp/freightline-exports"),
		},
		Notify: NotifyConfig{
			FromEmail:  getEnv("NOTIFY_FROM_EMAIL", "no-reply@freightline.dev"),
			SMSGateway: getEnv("NOTIFY_SMS_GATEWAY", ""),
		},
	}, nil
}

func (c *DatabaseConfig) DSN() string {
	return fmt.Sprintf(
		"host=%s port=%s user=%s password=%s dbname=%s sslmode=%s",
		c.Host, c.Port, c.User, c.Password, c.Name, c.SSLMode,
	)
}

func getEnv(key, fallback string) string {
	if v, ok := os.LookupEnv(key); ok && strings.TrimSpace(v) != "" {
		return v
	}
	return fallback
}

func atoi(s string) (int, error) {
	return strconv.Atoi(strings.TrimSpace(s))
}
