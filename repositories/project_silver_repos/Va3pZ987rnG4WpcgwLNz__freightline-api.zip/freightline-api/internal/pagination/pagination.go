package pagination

import (
	"strconv"
)

const (
	DefaultPage  = 1
	DefaultLimit = 25
	MaxLimit     = 200
)

type Params struct {
	Page  int
	Limit int
}

func (p Params) Offset() int {
	if p.Page <= 0 {
		p.Page = DefaultPage
	}
	return (p.Page - 1) * p.Limit
}

func (p Params) Normalize() Params {
	if p.Page <= 0 {
		p.Page = DefaultPage
	}
	if p.Limit <= 0 {
		p.Limit = DefaultLimit
	}
	if p.Limit > MaxLimit {
		p.Limit = MaxLimit
	}
	return p
}

func FromQuery(pageStr, limitStr string) Params {
	page, _ := strconv.Atoi(pageStr)
	limit, _ := strconv.Atoi(limitStr)
	return Params{Page: page, Limit: limit}.Normalize()
}

type Result struct {
	Data       interface{} `json:"data"`
	Page       int         `json:"page"`
	Limit      int         `json:"limit"`
	Total      int         `json:"total"`
	TotalPages int         `json:"total_pages"`
}

func BuildResult(data interface{}, p Params, total int) Result {
	totalPages := total / p.Limit
	if total%p.Limit != 0 {
		totalPages++
	}
	if totalPages == 0 {
		totalPages = 1
	}
	return Result{
		Data:       data,
		Page:       p.Page,
		Limit:      p.Limit,
		Total:      total,
		TotalPages: totalPages,
	}
}

func HasNext(p Params, total int) bool {
	return p.Page*p.Limit < total
}

func HasPrev(p Params) bool {
	return p.Page > 1
}
