package model

import (
	"time"

	"github.com/google/uuid"
)

type Carrier struct {
	ID              uuid.UUID `db:"id" json:"id"`
	Name            string    `db:"name" json:"name"`
	Code            string    `db:"code" json:"code"`
	ContactName     string    `db:"contact_name" json:"contact_name"`
	Email           string    `db:"email" json:"email"`
	Phone           string    `db:"phone" json:"phone"`
	Address         string    `db:"address" json:"address"`
	City            string    `db:"city" json:"city"`
	State           string    `db:"state" json:"state"`
	Country         string    `db:"country" json:"country"`
	ServiceArea     string    `db:"service_area" json:"service_area"`
	BaseRate        float64   `db:"base_rate" json:"base_rate"`
	PerKgRate       float64   `db:"per_kg_rate" json:"per_kg_rate"`
	PerKmRate       float64   `db:"per_km_rate" json:"per_km_rate"`
	FuelSurchargeRate float64 `db:"fuel_surcharge_rate" json:"fuel_surcharge_rate"`
	InsurancePolicy string    `db:"insurance_policy" json:"insurance_policy"`
	InsuranceCoverage float64 `db:"insurance_coverage" json:"insurance_coverage"`
	TaxID           string    `db:"tax_id" json:"tax_id"`
	OnTimeRate      float64   `db:"on_time_rate" json:"on_time_rate"`
	DamageRate      float64   `db:"damage_rate" json:"damage_rate"`
	TotalShipments  int       `db:"total_shipments" json:"total_shipments"`
	Rating          float64   `db:"rating" json:"rating"`
	IsActive        bool      `db:"is_active" json:"is_active"`
	IsHazmatCertified bool    `db:"is_hazmat_certified" json:"is_hazmat_certified"`
	Notes           string    `db:"notes" json:"notes"`
	CreatedAt       time.Time `db:"created_at" json:"created_at"`
	UpdatedAt       time.Time `db:"updated_at" json:"updated_at"`
}

type CreateCarrierRequest struct {
	Name              string  `json:"name" binding:"required"`
	Code              string  `json:"code" binding:"required"`
	ContactName       string  `json:"contact_name"`
	Email             string  `json:"email" binding:"required,email"`
	Phone             string  `json:"phone"`
	Address           string  `json:"address"`
	City              string  `json:"city"`
	State             string  `json:"state"`
	Country           string  `json:"country"`
	ServiceArea       string  `json:"service_area"`
	BaseRate          float64 `json:"base_rate"`
	PerKgRate         float64 `json:"per_kg_rate"`
	PerKmRate         float64 `json:"per_km_rate"`
	FuelSurchargeRate float64 `json:"fuel_surcharge_rate"`
	InsurancePolicy   string  `json:"insurance_policy"`
	InsuranceCoverage float64 `json:"insurance_coverage"`
	TaxID             string  `json:"tax_id"`
	IsHazmatCertified bool    `json:"is_hazmat_certified"`
	Notes             string  `json:"notes"`
}

type UpdateCarrierRequest struct {
	Name              string  `json:"name"`
	ContactName       string  `json:"contact_name"`
	Phone             string  `json:"phone"`
	Address           string  `json:"address"`
	City              string  `json:"city"`
	State             string  `json:"state"`
	BaseRate          float64 `json:"base_rate"`
	PerKgRate         float64 `json:"per_kg_rate"`
	PerKmRate         float64 `json:"per_km_rate"`
	FuelSurchargeRate float64 `json:"fuel_surcharge_rate"`
	InsuranceCoverage float64 `json:"insurance_coverage"`
	IsHazmatCertified bool    `json:"is_hazmat_certified"`
	Notes             string  `json:"notes"`
}

type CarrierFilter struct {
	SearchTerm     string
	City           string
	State          string
	Country        string
	IsActive       *bool
	IsHazmatCertified *bool
	MinRating      float64
	MinOnTime      float64
	FromDate       time.Time
	ToDate         time.Time
	Limit          int
	Offset         int
}

func (c *Carrier) QuoteShipment(weightKg, distanceKm float64) float64 {
	cost := c.BaseRate + (weightKg * c.PerKgRate) + (distanceKm * c.PerKmRate)
	if c.FuelSurchargeRate > 0 {
		cost += cost * (c.FuelSurchargeRate / 100)
	}
	return cost
}

func (c *Carrier) IsPreferred() bool {
	return c.Rating >= 4.0 && c.OnTimeRate >= 90
}

func (c *Carrier) PerformanceScore() float64 {
	onTime := c.OnTimeRate
	if onTime > 100 {
		onTime = 100
	}
	dmg := 100 - c.DamageRate
	if dmg < 0 {
		dmg = 0
	}
	ratingScore := (c.Rating / 5.0) * 100
	return (onTime*0.4 + dmg*0.3 + ratingScore*0.3)
}
