package model

import (
	"time"

	"github.com/google/uuid"
)

type EventType string

const (
	EventTypeCreated         EventType = "created"
	EventTypeBooked          EventType = "booked"
	EventTypePickup          EventType = "pickup"
	EventTypeArrived         EventType = "arrived_at_facility"
	EventTypeDeparted        EventType = "departed_facility"
	EventTypeOutForDelivery  EventType = "out_for_delivery"
	EventTypeDelivered       EventType = "delivered"
	EventTypeFailedAttempt   EventType = "failed_attempt"
	EventTypeReturned        EventType = "returned"
	EventTypeHeld            EventType = "held"
	EventTypeCancelled       EventType = "cancelled"
	EventTypeInspection      EventType = "customs_inspection"
	EventTypeException       EventType = "exception"
	EventTypeAddressUpdated  EventType = "address_updated"
)

type TrackingEvent struct {
	ID          uuid.UUID  `db:"id" json:"id"`
	ShipmentID  uuid.UUID  `db:"shipment_id" json:"shipment_id"`
	EventType   EventType  `db:"event_type" json:"event_type"`
	Status      ShipmentStatus `db:"status" json:"status"`
	Description string     `db:"description" json:"description"`
	Location    string     `db:"location" json:"location"`
	City        string     `db:"city" json:"city"`
	State       string     `db:"state" json:"state"`
	Country     string     `db:"country" json:"country"`
	Latitude    float64    `db:"latitude" json:"latitude"`
	Longitude   float64    `db:"longitude" json:"longitude"`
	ActorID     string     `db:"actor_id" json:"actor_id"`
	DriverID    *uuid.UUID `db:"driver_id" json:"driver_id"`
	VehicleID   *uuid.UUID `db:"vehicle_id" json:"vehicle_id"`
	WarehouseID *uuid.UUID `db:"warehouse_id" json:"warehouse_id"`
	OccurredAt  time.Time  `db:"occurred_at" json:"occurred_at"`
	CreatedAt   time.Time  `db:"created_at" json:"created_at"`
}

type CreateTrackingEventRequest struct {
	ShipmentID  string    `json:"shipment_id" binding:"required"`
	EventType   EventType `json:"event_type" binding:"required"`
	Description string    `json:"description"`
	Location    string    `json:"location"`
	City        string    `json:"city"`
	State       string    `json:"state"`
	Country     string    `json:"country"`
	Latitude    float64   `json:"latitude"`
	Longitude   float64   `json:"longitude"`
	DriverID    string    `json:"driver_id"`
	VehicleID   string    `json:"vehicle_id"`
	WarehouseID string    `json:"warehouse_id"`
	OccurredAt  string    `json:"occurred_at"`
}

type TrackingEventFilter struct {
	ShipmentID  *uuid.UUID
	EventType   EventType
	DriverID    *uuid.UUID
	VehicleID   *uuid.UUID
	WarehouseID *uuid.UUID
	FromDate    time.Time
	ToDate      time.Time
	Limit       int
	Offset      int
}

func (e *TrackingEvent) HasCoordinates() bool {
	return e.Latitude != 0 || e.Longitude != 0
}

func (e *TrackingEvent) IsTerminal() bool {
	switch e.EventType {
	case EventTypeDelivered, EventTypeCancelled, EventTypeReturned:
		return true
	}
	return false
}

func (e *TrackingEvent) Summary() string {
	if e.Description != "" {
		return e.Description
	}
	switch e.EventType {
	case EventTypeCreated:
		return "Shipment created"
	case EventTypeBooked:
		return "Shipment booked"
	case EventTypePickup:
		return "Picked up by carrier"
	case EventTypeArrived:
		return "Arrived at " + e.Location
	case EventTypeDeparted:
		return "Departed from " + e.Location
	case EventTypeOutForDelivery:
		return "Out for delivery"
	case EventTypeDelivered:
		return "Delivered"
	case EventTypeFailedAttempt:
		return "Failed delivery attempt"
	case EventTypeReturned:
		return "Returned to sender"
	case EventTypeHeld:
		return "Held at facility"
	case EventTypeCancelled:
		return "Cancelled"
	}
	return string(e.EventType)
}
