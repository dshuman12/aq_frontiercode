package model

import (
	"time"

	"github.com/google/uuid"
)

type RouteStatus string

const (
	RouteStatusPlanned   RouteStatus = "planned"
	RouteStatusActive    RouteStatus = "active"
	RouteStatusCompleted RouteStatus = "completed"
	RouteStatusCancelled RouteStatus = "cancelled"
)

type RouteStop struct {
	ID          uuid.UUID `db:"id" json:"id"`
	RouteID     uuid.UUID `db:"route_id" json:"route_id"`
	ShipmentID  uuid.UUID `db:"shipment_id" json:"shipment_id"`
	StopOrder   int       `db:"stop_order" json:"stop_order"`
	StopType    string    `db:"stop_type" json:"stop_type"`
	Address     string    `db:"address" json:"address"`
	City        string    `db:"city" json:"city"`
	State       string    `db:"state" json:"state"`
	Latitude    float64   `db:"latitude" json:"latitude"`
	Longitude   float64   `db:"longitude" json:"longitude"`
	PlannedETA  time.Time `db:"planned_eta" json:"planned_eta"`
	ActualETA   *time.Time `db:"actual_eta" json:"actual_eta"`
	Completed   bool      `db:"completed" json:"completed"`
	Notes       string    `db:"notes" json:"notes"`
}

type Route struct {
	ID              uuid.UUID   `db:"id" json:"id"`
	Code            string      `db:"code" json:"code"`
	Name            string      `db:"name" json:"name"`
	DriverID        *uuid.UUID  `db:"driver_id" json:"driver_id"`
	VehicleID       *uuid.UUID  `db:"vehicle_id" json:"vehicle_id"`
	OriginWarehouseID *uuid.UUID `db:"origin_warehouse_id" json:"origin_warehouse_id"`
	Status          RouteStatus `db:"status" json:"status"`
	PlannedDistance float64     `db:"planned_distance_km" json:"planned_distance_km"`
	ActualDistance  float64     `db:"actual_distance_km" json:"actual_distance_km"`
	PlannedDuration float64     `db:"planned_duration_hours" json:"planned_duration_hours"`
	ActualDuration  float64     `db:"actual_duration_hours" json:"actual_duration_hours"`
	StopCount       int         `db:"stop_count" json:"stop_count"`
	CompletedStops  int         `db:"completed_stops" json:"completed_stops"`
	ScheduledStart  time.Time   `db:"scheduled_start" json:"scheduled_start"`
	ScheduledEnd    time.Time   `db:"scheduled_end" json:"scheduled_end"`
	ActualStart     *time.Time  `db:"actual_start" json:"actual_start"`
	ActualEnd       *time.Time  `db:"actual_end" json:"actual_end"`
	FuelCost        float64     `db:"fuel_cost" json:"fuel_cost"`
	TollCost        float64     `db:"toll_cost" json:"toll_cost"`
	Notes           string      `db:"notes" json:"notes"`
	CreatedAt       time.Time   `db:"created_at" json:"created_at"`
	UpdatedAt       time.Time   `db:"updated_at" json:"updated_at"`
}

type CreateRouteRequest struct {
	Code              string   `json:"code"`
	Name              string   `json:"name" binding:"required"`
	DriverID          string   `json:"driver_id"`
	VehicleID         string   `json:"vehicle_id"`
	OriginWarehouseID string   `json:"origin_warehouse_id"`
	ScheduledStart    string   `json:"scheduled_start" binding:"required"`
	ScheduledEnd      string   `json:"scheduled_end"`
	ShipmentIDs       []string `json:"shipment_ids" binding:"required"`
	Notes             string   `json:"notes"`
}

type UpdateRouteRequest struct {
	Name            string    `json:"name"`
	DriverID        string    `json:"driver_id"`
	VehicleID       string    `json:"vehicle_id"`
	ScheduledStart  string    `json:"scheduled_start"`
	ScheduledEnd    string    `json:"scheduled_end"`
	PlannedDistance float64   `json:"planned_distance_km"`
	PlannedDuration float64   `json:"planned_duration_hours"`
	Notes           string    `json:"notes"`
}

type RouteFilter struct {
	SearchTerm        string
	Status            RouteStatus
	DriverID          *uuid.UUID
	VehicleID         *uuid.UUID
	OriginWarehouseID *uuid.UUID
	FromDate          time.Time
	ToDate            time.Time
	Limit             int
	Offset            int
}

type RouteWithStops struct {
	*Route
	Stops []*RouteStop `json:"stops"`
}

func (r *Route) IsActive() bool {
	return r.Status == RouteStatusActive
}

func (r *Route) IsCompleted() bool {
	return r.Status == RouteStatusCompleted
}

func (r *Route) IsTerminal() bool {
	return r.Status == RouteStatusCompleted || r.Status == RouteStatusCancelled
}

func (r *Route) ProgressPercent() float64 {
	if r.StopCount <= 0 {
		return 0
	}
	return (float64(r.CompletedStops) / float64(r.StopCount)) * 100
}

func (r *Route) TotalCost() float64 {
	return r.FuelCost + r.TollCost
}

func (r *Route) IsOverdue() bool {
	if r.IsTerminal() {
		return false
	}
	if r.ScheduledEnd.IsZero() {
		return false
	}
	return time.Now().After(r.ScheduledEnd)
}

func (r *Route) DistanceVariance() float64 {
	return r.ActualDistance - r.PlannedDistance
}

func (r *Route) DurationVariance() float64 {
	return r.ActualDuration - r.PlannedDuration
}

func (r *Route) CanTransitionTo(next RouteStatus) bool {
	allowed := map[RouteStatus][]RouteStatus{
		RouteStatusPlanned:   {RouteStatusActive, RouteStatusCancelled},
		RouteStatusActive:    {RouteStatusCompleted, RouteStatusCancelled},
	}
	candidates, ok := allowed[r.Status]
	if !ok {
		return false
	}
	for _, c := range candidates {
		if c == next {
			return true
		}
	}
	return false
}
