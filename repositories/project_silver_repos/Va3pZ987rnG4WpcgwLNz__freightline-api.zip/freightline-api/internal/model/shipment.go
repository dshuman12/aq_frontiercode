package model

import (
	"time"

	"github.com/google/uuid"
)

type ShipmentStatus string

const (
	ShipmentStatusDraft       ShipmentStatus = "draft"
	ShipmentStatusBooked      ShipmentStatus = "booked"
	ShipmentStatusPickedUp    ShipmentStatus = "picked_up"
	ShipmentStatusAtWarehouse ShipmentStatus = "at_warehouse"
	ShipmentStatusInTransit   ShipmentStatus = "in_transit"
	ShipmentStatusOutForDelivery ShipmentStatus = "out_for_delivery"
	ShipmentStatusDelivered   ShipmentStatus = "delivered"
	ShipmentStatusFailed      ShipmentStatus = "failed_delivery"
	ShipmentStatusReturned    ShipmentStatus = "returned"
	ShipmentStatusCancelled   ShipmentStatus = "cancelled"
	ShipmentStatusHeld        ShipmentStatus = "held"
)

type ServiceLevel string

const (
	ServiceLevelStandard ServiceLevel = "standard"
	ServiceLevelExpress  ServiceLevel = "express"
	ServiceLevelOvernight ServiceLevel = "overnight"
	ServiceLevelEconomy  ServiceLevel = "economy"
	ServiceLevelSameDay  ServiceLevel = "same_day"
)

type Shipment struct {
	ID                uuid.UUID      `db:"id" json:"id"`
	TrackingNumber    string         `db:"tracking_number" json:"tracking_number"`
	CustomerID        uuid.UUID      `db:"customer_id" json:"customer_id"`
	OriginWarehouseID *uuid.UUID     `db:"origin_warehouse_id" json:"origin_warehouse_id"`
	DestWarehouseID   *uuid.UUID     `db:"dest_warehouse_id" json:"dest_warehouse_id"`
	AssignedDriverID  *uuid.UUID     `db:"assigned_driver_id" json:"assigned_driver_id"`
	AssignedVehicleID *uuid.UUID     `db:"assigned_vehicle_id" json:"assigned_vehicle_id"`
	RouteID           *uuid.UUID     `db:"route_id" json:"route_id"`
	CarrierID         *uuid.UUID     `db:"carrier_id" json:"carrier_id"`
	InvoiceID         *uuid.UUID     `db:"invoice_id" json:"invoice_id"`
	PickupName        string         `db:"pickup_name" json:"pickup_name"`
	PickupPhone       string         `db:"pickup_phone" json:"pickup_phone"`
	PickupAddress     string         `db:"pickup_address" json:"pickup_address"`
	PickupCity        string         `db:"pickup_city" json:"pickup_city"`
	PickupState       string         `db:"pickup_state" json:"pickup_state"`
	PickupZip         string         `db:"pickup_zip" json:"pickup_zip"`
	PickupCountry     string         `db:"pickup_country" json:"pickup_country"`
	DeliveryName      string         `db:"delivery_name" json:"delivery_name"`
	DeliveryPhone     string         `db:"delivery_phone" json:"delivery_phone"`
	DeliveryAddress   string         `db:"delivery_address" json:"delivery_address"`
	DeliveryCity      string         `db:"delivery_city" json:"delivery_city"`
	DeliveryState     string         `db:"delivery_state" json:"delivery_state"`
	DeliveryZip       string         `db:"delivery_zip" json:"delivery_zip"`
	DeliveryCountry   string         `db:"delivery_country" json:"delivery_country"`
	Status            ShipmentStatus `db:"status" json:"status"`
	ServiceLevel      ServiceLevel   `db:"service_level" json:"service_level"`
	WeightKg          float64        `db:"weight_kg" json:"weight_kg"`
	VolumeM3          float64        `db:"volume_m3" json:"volume_m3"`
	Pieces            int            `db:"pieces" json:"pieces"`
	DeclaredValue     float64        `db:"declared_value" json:"declared_value"`
	BaseRate          float64        `db:"base_rate" json:"base_rate"`
	FuelSurcharge     float64        `db:"fuel_surcharge" json:"fuel_surcharge"`
	InsuranceFee      float64        `db:"insurance_fee" json:"insurance_fee"`
	HandlingFee       float64        `db:"handling_fee" json:"handling_fee"`
	TotalCharge       float64        `db:"total_charge" json:"total_charge"`
	IsFragile         bool           `db:"is_fragile" json:"is_fragile"`
	IsHazmat          bool           `db:"is_hazmat" json:"is_hazmat"`
	RequiresRefrigeration bool       `db:"requires_refrigeration" json:"requires_refrigeration"`
	RequiresSignature  bool          `db:"requires_signature" json:"requires_signature"`
	SpecialInstructions string       `db:"special_instructions" json:"special_instructions"`
	ScheduledPickup   time.Time      `db:"scheduled_pickup" json:"scheduled_pickup"`
	ActualPickup      *time.Time     `db:"actual_pickup" json:"actual_pickup"`
	ScheduledDelivery time.Time      `db:"scheduled_delivery" json:"scheduled_delivery"`
	ActualDelivery    *time.Time     `db:"actual_delivery" json:"actual_delivery"`
	CreatedAt         time.Time      `db:"created_at" json:"created_at"`
	UpdatedAt         time.Time      `db:"updated_at" json:"updated_at"`
}

type CreateShipmentRequest struct {
	CustomerID            string       `json:"customer_id" binding:"required"`
	OriginWarehouseID     string       `json:"origin_warehouse_id"`
	DestWarehouseID       string       `json:"dest_warehouse_id"`
	PickupName            string       `json:"pickup_name" binding:"required"`
	PickupPhone           string       `json:"pickup_phone"`
	PickupAddress         string       `json:"pickup_address" binding:"required"`
	PickupCity            string       `json:"pickup_city" binding:"required"`
	PickupState           string       `json:"pickup_state"`
	PickupZip             string       `json:"pickup_zip"`
	PickupCountry         string       `json:"pickup_country"`
	DeliveryName          string       `json:"delivery_name" binding:"required"`
	DeliveryPhone         string       `json:"delivery_phone"`
	DeliveryAddress       string       `json:"delivery_address" binding:"required"`
	DeliveryCity          string       `json:"delivery_city" binding:"required"`
	DeliveryState         string       `json:"delivery_state"`
	DeliveryZip           string       `json:"delivery_zip"`
	DeliveryCountry       string       `json:"delivery_country"`
	ServiceLevel          ServiceLevel `json:"service_level" binding:"required"`
	WeightKg              float64      `json:"weight_kg" binding:"required"`
	VolumeM3              float64      `json:"volume_m3"`
	Pieces                int          `json:"pieces"`
	DeclaredValue         float64      `json:"declared_value"`
	IsFragile             bool         `json:"is_fragile"`
	IsHazmat              bool         `json:"is_hazmat"`
	RequiresRefrigeration bool         `json:"requires_refrigeration"`
	RequiresSignature     bool         `json:"requires_signature"`
	SpecialInstructions   string       `json:"special_instructions"`
	ScheduledPickup       string       `json:"scheduled_pickup"`
	ScheduledDelivery     string       `json:"scheduled_delivery"`
}

type UpdateShipmentRequest struct {
	DeliveryName        string  `json:"delivery_name"`
	DeliveryPhone       string  `json:"delivery_phone"`
	DeliveryAddress     string  `json:"delivery_address"`
	SpecialInstructions string  `json:"special_instructions"`
	ScheduledPickup     string  `json:"scheduled_pickup"`
	ScheduledDelivery   string  `json:"scheduled_delivery"`
	DeclaredValue       float64 `json:"declared_value"`
}

type ShipmentFilter struct {
	SearchTerm        string
	Status            ShipmentStatus
	ServiceLevel      ServiceLevel
	CustomerID        *uuid.UUID
	DriverID          *uuid.UUID
	VehicleID         *uuid.UUID
	CarrierID         *uuid.UUID
	OriginWarehouseID *uuid.UUID
	DestWarehouseID   *uuid.UUID
	OriginCity        string
	DeliveryCity      string
	IsHazmat          *bool
	IsFragile         *bool
	MinWeight         float64
	MaxWeight         float64
	FromDate          time.Time
	ToDate            time.Time
	Limit             int
	Offset            int
}

type ShipmentResponse struct {
	ID                uuid.UUID      `json:"id"`
	TrackingNumber    string         `json:"tracking_number"`
	CustomerID        uuid.UUID      `json:"customer_id"`
	PickupCity        string         `json:"pickup_city"`
	DeliveryCity      string         `json:"delivery_city"`
	Status            ShipmentStatus `json:"status"`
	ServiceLevel      ServiceLevel   `json:"service_level"`
	WeightKg          float64        `json:"weight_kg"`
	TotalCharge       float64        `json:"total_charge"`
	ScheduledDelivery time.Time      `json:"scheduled_delivery"`
	ActualDelivery    *time.Time     `json:"actual_delivery"`
	CreatedAt         time.Time      `json:"created_at"`
}

type ShipmentWithEvents struct {
	*Shipment
	Events []*TrackingEvent `json:"events"`
}

func (s *Shipment) IsAvailable() bool {
	return s.Status != ShipmentStatusCancelled &&
		s.Status != ShipmentStatusDelivered &&
		s.Status != ShipmentStatusReturned
}

func (s *Shipment) IsDelivered() bool {
	return s.Status == ShipmentStatusDelivered
}

func (s *Shipment) IsCancelled() bool {
	return s.Status == ShipmentStatusCancelled
}

func (s *Shipment) IsTerminal() bool {
	switch s.Status {
	case ShipmentStatusDelivered, ShipmentStatusCancelled, ShipmentStatusReturned:
		return true
	}
	return false
}

func (s *Shipment) RequiresSpecialVehicle() bool {
	return s.RequiresRefrigeration || s.IsHazmat
}

func (s *Shipment) IsDeliveryOverdue() bool {
	if s.IsDelivered() || s.IsCancelled() {
		return false
	}
	if s.ScheduledDelivery.IsZero() {
		return false
	}
	return time.Now().After(s.ScheduledDelivery)
}

func (s *Shipment) DeliveryDurationDays() float64 {
	if s.ActualDelivery == nil || s.ActualPickup == nil {
		return 0
	}
	return s.ActualDelivery.Sub(*s.ActualPickup).Hours() / 24
}

func (s *Shipment) CalculateTotal() float64 {
	return s.BaseRate + s.FuelSurcharge + s.InsuranceFee + s.HandlingFee
}

func (s *Shipment) CanTransitionTo(next ShipmentStatus) bool {
	allowed := map[ShipmentStatus][]ShipmentStatus{
		ShipmentStatusDraft:       {ShipmentStatusBooked, ShipmentStatusCancelled},
		ShipmentStatusBooked:      {ShipmentStatusPickedUp, ShipmentStatusCancelled, ShipmentStatusHeld},
		ShipmentStatusHeld:        {ShipmentStatusBooked, ShipmentStatusCancelled},
		ShipmentStatusPickedUp:    {ShipmentStatusAtWarehouse, ShipmentStatusInTransit},
		ShipmentStatusAtWarehouse: {ShipmentStatusInTransit, ShipmentStatusOutForDelivery},
		ShipmentStatusInTransit:   {ShipmentStatusAtWarehouse, ShipmentStatusOutForDelivery, ShipmentStatusFailed},
		ShipmentStatusOutForDelivery: {ShipmentStatusDelivered, ShipmentStatusFailed},
		ShipmentStatusFailed:      {ShipmentStatusOutForDelivery, ShipmentStatusReturned},
	}
	candidates, ok := allowed[s.Status]
	if !ok {
		return false
	}
	for _, c := range candidates {
		if c == next {
			return true
		}
	}
	return false
}

func (s *Shipment) ToResponse() *ShipmentResponse {
	return &ShipmentResponse{
		ID:                s.ID,
		TrackingNumber:    s.TrackingNumber,
		CustomerID:        s.CustomerID,
		PickupCity:        s.PickupCity,
		DeliveryCity:      s.DeliveryCity,
		Status:            s.Status,
		ServiceLevel:      s.ServiceLevel,
		WeightKg:          s.WeightKg,
		TotalCharge:       s.TotalCharge,
		ScheduledDelivery: s.ScheduledDelivery,
		ActualDelivery:    s.ActualDelivery,
		CreatedAt:         s.CreatedAt,
	}
}
