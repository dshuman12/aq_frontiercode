package model

import (
	"time"

	"github.com/google/uuid"
)

type VehicleType string

const (
	VehicleTypeBox       VehicleType = "box_truck"
	VehicleTypeSemi      VehicleType = "semi"
	VehicleTypeVan       VehicleType = "van"
	VehicleTypePickup    VehicleType = "pickup"
	VehicleTypeReefer    VehicleType = "reefer"
	VehicleTypeFlatbed   VehicleType = "flatbed"
	VehicleTypeTanker    VehicleType = "tanker"
	VehicleTypeContainer VehicleType = "container"
)

type VehicleStatus string

const (
	VehicleStatusAvailable    VehicleStatus = "available"
	VehicleStatusInTransit    VehicleStatus = "in_transit"
	VehicleStatusMaintenance  VehicleStatus = "maintenance"
	VehicleStatusOutOfService VehicleStatus = "out_of_service"
	VehicleStatusRetired      VehicleStatus = "retired"
)

type FuelType string

const (
	FuelDiesel   FuelType = "diesel"
	FuelGasoline FuelType = "gasoline"
	FuelElectric FuelType = "electric"
	FuelHybrid   FuelType = "hybrid"
	FuelCNG      FuelType = "cng"
	FuelLNG      FuelType = "lng"
)

type Vehicle struct {
	ID                uuid.UUID     `db:"id" json:"id"`
	PlateNumber       string        `db:"plate_number" json:"plate_number"`
	VIN               string        `db:"vin" json:"vin"`
	Make              string        `db:"make" json:"make"`
	Model             string        `db:"model" json:"model"`
	Year              int           `db:"year" json:"year"`
	Type              VehicleType   `db:"type" json:"type"`
	FuelType          FuelType      `db:"fuel_type" json:"fuel_type"`
	CapacityKg        float64       `db:"capacity_kg" json:"capacity_kg"`
	CapacityM3        float64       `db:"capacity_m3" json:"capacity_m3"`
	OdometerKm        float64       `db:"odometer_km" json:"odometer_km"`
	FuelEfficiency    float64       `db:"fuel_efficiency" json:"fuel_efficiency"`
	Status            VehicleStatus `db:"status" json:"status"`
	InsuranceProvider string        `db:"insurance_provider" json:"insurance_provider"`
	InsurancePolicy   string        `db:"insurance_policy" json:"insurance_policy"`
	InsuranceExpiry   time.Time     `db:"insurance_expiry" json:"insurance_expiry"`
	RegistrationExpiry time.Time    `db:"registration_expiry" json:"registration_expiry"`
	LastServiceDate   time.Time     `db:"last_service_date" json:"last_service_date"`
	NextServiceDate   time.Time     `db:"next_service_date" json:"next_service_date"`
	NextServiceKm     float64       `db:"next_service_km" json:"next_service_km"`
	HomeWarehouseID   *uuid.UUID    `db:"home_warehouse_id" json:"home_warehouse_id"`
	PurchaseDate      time.Time     `db:"purchase_date" json:"purchase_date"`
	PurchasePrice     float64       `db:"purchase_price" json:"purchase_price"`
	CurrentValue      float64       `db:"current_value" json:"current_value"`
	IsRefrigerated    bool          `db:"is_refrigerated" json:"is_refrigerated"`
	CreatedAt         time.Time     `db:"created_at" json:"created_at"`
	UpdatedAt         time.Time     `db:"updated_at" json:"updated_at"`
}

type CreateVehicleRequest struct {
	PlateNumber       string      `json:"plate_number" binding:"required"`
	VIN               string      `json:"vin" binding:"required"`
	Make              string      `json:"make" binding:"required"`
	Model             string      `json:"model" binding:"required"`
	Year              int         `json:"year" binding:"required"`
	Type              VehicleType `json:"type" binding:"required"`
	FuelType          FuelType    `json:"fuel_type"`
	CapacityKg        float64     `json:"capacity_kg"`
	CapacityM3        float64     `json:"capacity_m3"`
	FuelEfficiency    float64     `json:"fuel_efficiency"`
	InsuranceProvider string      `json:"insurance_provider"`
	InsurancePolicy   string      `json:"insurance_policy"`
	InsuranceExpiry   string      `json:"insurance_expiry"`
	RegistrationExpiry string     `json:"registration_expiry"`
	HomeWarehouseID   string      `json:"home_warehouse_id"`
	PurchaseDate      string      `json:"purchase_date"`
	PurchasePrice     float64     `json:"purchase_price"`
	IsRefrigerated    bool        `json:"is_refrigerated"`
}

type UpdateVehicleRequest struct {
	OdometerKm        float64   `json:"odometer_km"`
	FuelEfficiency    float64   `json:"fuel_efficiency"`
	InsuranceProvider string    `json:"insurance_provider"`
	InsurancePolicy   string    `json:"insurance_policy"`
	InsuranceExpiry   string    `json:"insurance_expiry"`
	RegistrationExpiry string   `json:"registration_expiry"`
	LastServiceDate   string    `json:"last_service_date"`
	NextServiceDate   string    `json:"next_service_date"`
	NextServiceKm     float64   `json:"next_service_km"`
	HomeWarehouseID   string    `json:"home_warehouse_id"`
	CurrentValue      float64   `json:"current_value"`
}

type VehicleFilter struct {
	SearchTerm      string
	Type            VehicleType
	Status          VehicleStatus
	FuelType        FuelType
	HomeWarehouseID *uuid.UUID
	MinCapacityKg   float64
	MaxCapacityKg   float64
	IsRefrigerated  *bool
	NeedsService    *bool
	InsuranceExpiringIn int
	FromDate        time.Time
	ToDate          time.Time
	Limit           int
	Offset          int
}

type VehicleResponse struct {
	ID            uuid.UUID     `json:"id"`
	PlateNumber   string        `json:"plate_number"`
	Make          string        `json:"make"`
	Model         string        `json:"model"`
	Year          int           `json:"year"`
	Type          VehicleType   `json:"type"`
	Status        VehicleStatus `json:"status"`
	CapacityKg    float64       `json:"capacity_kg"`
	OdometerKm    float64       `json:"odometer_km"`
	IsRefrigerated bool         `json:"is_refrigerated"`
}

func (v *Vehicle) IsAvailable() bool {
	return v.Status == VehicleStatusAvailable
}

func (v *Vehicle) IsInsuranceExpired() bool {
	if v.InsuranceExpiry.IsZero() {
		return false
	}
	return time.Now().After(v.InsuranceExpiry)
}

func (v *Vehicle) IsRegistrationExpired() bool {
	if v.RegistrationExpiry.IsZero() {
		return false
	}
	return time.Now().After(v.RegistrationExpiry)
}

func (v *Vehicle) NeedsService() bool {
	if !v.NextServiceDate.IsZero() && time.Now().After(v.NextServiceDate) {
		return true
	}
	if v.NextServiceKm > 0 && v.OdometerKm >= v.NextServiceKm {
		return true
	}
	return false
}

func (v *Vehicle) AgeInYears() int {
	if v.Year == 0 {
		return 0
	}
	return time.Now().Year() - v.Year
}

func (v *Vehicle) DepreciationPercent() float64 {
	if v.PurchasePrice <= 0 {
		return 0
	}
	loss := v.PurchasePrice - v.CurrentValue
	return (loss / v.PurchasePrice) * 100
}

func (v *Vehicle) CanCarry(weightKg, volumeM3 float64) bool {
	if !v.IsAvailable() {
		return false
	}
	if v.CapacityKg > 0 && weightKg > v.CapacityKg {
		return false
	}
	if v.CapacityM3 > 0 && volumeM3 > v.CapacityM3 {
		return false
	}
	return true
}

func (v *Vehicle) ToResponse() *VehicleResponse {
	return &VehicleResponse{
		ID:             v.ID,
		PlateNumber:    v.PlateNumber,
		Make:           v.Make,
		Model:          v.Model,
		Year:           v.Year,
		Type:           v.Type,
		Status:         v.Status,
		CapacityKg:     v.CapacityKg,
		OdometerKm:     v.OdometerKm,
		IsRefrigerated: v.IsRefrigerated,
	}
}
