package model

import (
	"time"

	"github.com/google/uuid"
)

type InvoiceStatus string

const (
	InvoiceStatusDraft       InvoiceStatus = "draft"
	InvoiceStatusIssued      InvoiceStatus = "issued"
	InvoiceStatusPartiallyPaid InvoiceStatus = "partially_paid"
	InvoiceStatusPaid        InvoiceStatus = "paid"
	InvoiceStatusOverdue     InvoiceStatus = "overdue"
	InvoiceStatusVoided      InvoiceStatus = "voided"
	InvoiceStatusDisputed    InvoiceStatus = "disputed"
)

type InvoiceLineItem struct {
	ID          uuid.UUID `db:"id" json:"id"`
	InvoiceID   uuid.UUID `db:"invoice_id" json:"invoice_id"`
	ShipmentID  *uuid.UUID `db:"shipment_id" json:"shipment_id"`
	Description string    `db:"description" json:"description"`
	Quantity    float64   `db:"quantity" json:"quantity"`
	UnitPrice   float64   `db:"unit_price" json:"unit_price"`
	Discount    float64   `db:"discount" json:"discount"`
	TaxRate     float64   `db:"tax_rate" json:"tax_rate"`
	LineTotal   float64   `db:"line_total" json:"line_total"`
	CreatedAt   time.Time `db:"created_at" json:"created_at"`
}

type Invoice struct {
	ID            uuid.UUID     `db:"id" json:"id"`
	InvoiceNumber string        `db:"invoice_number" json:"invoice_number"`
	CustomerID    uuid.UUID     `db:"customer_id" json:"customer_id"`
	Status        InvoiceStatus `db:"status" json:"status"`
	IssuedDate    time.Time     `db:"issued_date" json:"issued_date"`
	DueDate       time.Time     `db:"due_date" json:"due_date"`
	Subtotal      float64       `db:"subtotal" json:"subtotal"`
	TaxAmount     float64       `db:"tax_amount" json:"tax_amount"`
	DiscountAmount float64      `db:"discount_amount" json:"discount_amount"`
	Total         float64       `db:"total" json:"total"`
	AmountPaid    float64       `db:"amount_paid" json:"amount_paid"`
	BalanceDue    float64       `db:"balance_due" json:"balance_due"`
	Currency      string        `db:"currency" json:"currency"`
	PaymentTerms  int           `db:"payment_terms" json:"payment_terms"`
	Notes         string        `db:"notes" json:"notes"`
	BillingAddress string       `db:"billing_address" json:"billing_address"`
	CreatedAt     time.Time     `db:"created_at" json:"created_at"`
	UpdatedAt     time.Time     `db:"updated_at" json:"updated_at"`
}

type CreateInvoiceRequest struct {
	CustomerID   string                       `json:"customer_id" binding:"required"`
	IssuedDate   string                       `json:"issued_date"`
	DueDate      string                       `json:"due_date"`
	PaymentTerms int                          `json:"payment_terms"`
	Currency     string                       `json:"currency"`
	Notes        string                       `json:"notes"`
	LineItems    []CreateInvoiceLineItemRequest `json:"line_items" binding:"required"`
}

type CreateInvoiceLineItemRequest struct {
	ShipmentID  string  `json:"shipment_id"`
	Description string  `json:"description" binding:"required"`
	Quantity    float64 `json:"quantity" binding:"required"`
	UnitPrice   float64 `json:"unit_price" binding:"required"`
	Discount    float64 `json:"discount"`
	TaxRate     float64 `json:"tax_rate"`
}

type UpdateInvoiceRequest struct {
	DueDate string `json:"due_date"`
	Notes   string `json:"notes"`
}

type InvoiceFilter struct {
	SearchTerm string
	CustomerID *uuid.UUID
	Status     InvoiceStatus
	IsOverdue  *bool
	FromDate   time.Time
	ToDate     time.Time
	MinTotal   float64
	MaxTotal   float64
	Limit      int
	Offset     int
}

type InvoiceWithLines struct {
	*Invoice
	LineItems []*InvoiceLineItem `json:"line_items"`
}

func (i *Invoice) IsOverdue() bool {
	if i.Status == InvoiceStatusPaid || i.Status == InvoiceStatusVoided {
		return false
	}
	if i.DueDate.IsZero() {
		return false
	}
	return time.Now().After(i.DueDate)
}

func (i *Invoice) DaysOverdue() int {
	if !i.IsOverdue() {
		return 0
	}
	return int(time.Since(i.DueDate).Hours() / 24)
}

func (i *Invoice) IsPaidInFull() bool {
	return i.BalanceDue <= 0
}

func (i *Invoice) IsAvailable() bool {
	return i.Status != InvoiceStatusVoided
}

func (li *InvoiceLineItem) Compute() float64 {
	gross := li.Quantity * li.UnitPrice
	disc := gross * (li.Discount / 100)
	net := gross - disc
	tax := net * (li.TaxRate / 100)
	return net + tax
}

func (i *Invoice) RecomputeTotals(lines []*InvoiceLineItem) {
	subtotal := 0.0
	taxAmount := 0.0
	discountAmount := 0.0

	for _, li := range lines {
		gross := li.Quantity * li.UnitPrice
		disc := gross * (li.Discount / 100)
		net := gross - disc
		tax := net * (li.TaxRate / 100)
		li.LineTotal = net + tax

		subtotal += gross
		discountAmount += disc
		taxAmount += tax
	}

	i.Subtotal = subtotal
	i.TaxAmount = taxAmount
	i.DiscountAmount = discountAmount
	i.Total = subtotal - discountAmount + taxAmount
	i.BalanceDue = i.Total - i.AmountPaid
}
