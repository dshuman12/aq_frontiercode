package model

import (
	"time"

	"github.com/google/uuid"
)

type LicenseClass string

const (
	LicenseClassA LicenseClass = "A"
	LicenseClassB LicenseClass = "B"
	LicenseClassC LicenseClass = "C"
)

type DriverStatus string

const (
	DriverStatusActive    DriverStatus = "active"
	DriverStatusOnLeave   DriverStatus = "on_leave"
	DriverStatusInactive  DriverStatus = "inactive"
	DriverStatusTerminated DriverStatus = "terminated"
	DriverStatusSuspended DriverStatus = "suspended"
)

type Driver struct {
	ID              uuid.UUID    `db:"id" json:"id"`
	EmployeeCode    string       `db:"employee_code" json:"employee_code"`
	FirstName       string       `db:"first_name" json:"first_name"`
	LastName        string       `db:"last_name" json:"last_name"`
	Email           string       `db:"email" json:"email"`
	Phone           string       `db:"phone" json:"phone"`
	LicenseNumber   string       `db:"license_number" json:"license_number"`
	LicenseClass    LicenseClass `db:"license_class" json:"license_class"`
	LicenseExpiry   time.Time    `db:"license_expiry" json:"license_expiry"`
	HireDate        time.Time    `db:"hire_date" json:"hire_date"`
	DateOfBirth     time.Time    `db:"date_of_birth" json:"date_of_birth"`
	Status          DriverStatus `db:"status" json:"status"`
	HourlyRate      float64      `db:"hourly_rate" json:"hourly_rate"`
	PerMileRate     float64      `db:"per_mile_rate" json:"per_mile_rate"`
	HomeAddress     string       `db:"home_address" json:"home_address"`
	HomeCity        string       `db:"home_city" json:"home_city"`
	HomeState       string       `db:"home_state" json:"home_state"`
	EmergencyContact string      `db:"emergency_contact" json:"emergency_contact"`
	EmergencyPhone   string      `db:"emergency_phone" json:"emergency_phone"`
	TotalMilesDriven float64     `db:"total_miles_driven" json:"total_miles_driven"`
	TotalDeliveries  int         `db:"total_deliveries" json:"total_deliveries"`
	IncidentCount    int         `db:"incident_count" json:"incident_count"`
	CreatedAt        time.Time   `db:"created_at" json:"created_at"`
	UpdatedAt        time.Time   `db:"updated_at" json:"updated_at"`
}

type CreateDriverRequest struct {
	EmployeeCode    string       `json:"employee_code" binding:"required"`
	FirstName       string       `json:"first_name" binding:"required"`
	LastName        string       `json:"last_name" binding:"required"`
	Email           string       `json:"email" binding:"required,email"`
	Phone           string       `json:"phone" binding:"required"`
	LicenseNumber   string       `json:"license_number" binding:"required"`
	LicenseClass    LicenseClass `json:"license_class" binding:"required"`
	LicenseExpiry   string       `json:"license_expiry"`
	HireDate        string       `json:"hire_date"`
	DateOfBirth     string       `json:"date_of_birth"`
	HourlyRate      float64      `json:"hourly_rate"`
	PerMileRate     float64      `json:"per_mile_rate"`
	HomeAddress     string       `json:"home_address"`
	HomeCity        string       `json:"home_city"`
	HomeState       string       `json:"home_state"`
	EmergencyContact string      `json:"emergency_contact"`
	EmergencyPhone   string      `json:"emergency_phone"`
}

type UpdateDriverRequest struct {
	FirstName       string       `json:"first_name"`
	LastName        string       `json:"last_name"`
	Phone           string       `json:"phone"`
	LicenseExpiry   string       `json:"license_expiry"`
	LicenseClass    LicenseClass `json:"license_class"`
	HourlyRate      float64      `json:"hourly_rate"`
	PerMileRate     float64      `json:"per_mile_rate"`
	HomeAddress     string       `json:"home_address"`
	HomeCity        string       `json:"home_city"`
	HomeState       string       `json:"home_state"`
	EmergencyContact string      `json:"emergency_contact"`
	EmergencyPhone   string      `json:"emergency_phone"`
}

type DriverFilter struct {
	SearchTerm   string
	LicenseClass LicenseClass
	Status       DriverStatus
	HomeState    string
	FromDate     time.Time
	ToDate       time.Time
	Limit        int
	Offset       int
}

type DriverResponse struct {
	ID             uuid.UUID    `json:"id"`
	EmployeeCode   string       `json:"employee_code"`
	FullName       string       `json:"full_name"`
	Email          string       `json:"email"`
	Phone          string       `json:"phone"`
	LicenseClass   LicenseClass `json:"license_class"`
	LicenseExpiry  time.Time    `json:"license_expiry"`
	Status         DriverStatus `json:"status"`
	TotalMilesDriven float64    `json:"total_miles_driven"`
	TotalDeliveries  int        `json:"total_deliveries"`
	CreatedAt      time.Time    `json:"created_at"`
}

func (d *Driver) FullName() string {
	return d.FirstName + " " + d.LastName
}

func (d *Driver) IsAvailable() bool {
	return d.Status == DriverStatusActive && !d.IsLicenseExpired()
}

func (d *Driver) IsLicenseExpired() bool {
	if d.LicenseExpiry.IsZero() {
		return false
	}
	return time.Now().After(d.LicenseExpiry)
}

func (d *Driver) LicenseExpiresInDays() int {
	if d.LicenseExpiry.IsZero() {
		return 0
	}
	return int(time.Until(d.LicenseExpiry).Hours() / 24)
}

func (d *Driver) YearsOfService() float64 {
	if d.HireDate.IsZero() {
		return 0
	}
	return time.Since(d.HireDate).Hours() / (24 * 365.25)
}

func (d *Driver) AverageMilesPerDelivery() float64 {
	if d.TotalDeliveries == 0 {
		return 0
	}
	return d.TotalMilesDriven / float64(d.TotalDeliveries)
}

func (d *Driver) ToResponse() *DriverResponse {
	return &DriverResponse{
		ID:               d.ID,
		EmployeeCode:     d.EmployeeCode,
		FullName:         d.FullName(),
		Email:            d.Email,
		Phone:            d.Phone,
		LicenseClass:     d.LicenseClass,
		LicenseExpiry:    d.LicenseExpiry,
		Status:           d.Status,
		TotalMilesDriven: d.TotalMilesDriven,
		TotalDeliveries:  d.TotalDeliveries,
		CreatedAt:        d.CreatedAt,
	}
}
