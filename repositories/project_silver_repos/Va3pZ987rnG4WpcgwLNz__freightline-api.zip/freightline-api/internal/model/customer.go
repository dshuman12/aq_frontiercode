package model

import (
	"time"

	"github.com/google/uuid"
)

type CustomerType string

const (
	CustomerTypeIndividual CustomerType = "individual"
	CustomerTypeBusiness   CustomerType = "business"
	CustomerTypeGov        CustomerType = "government"
)

type Customer struct {
	ID            uuid.UUID    `db:"id" json:"id"`
	CompanyName   string       `db:"company_name" json:"company_name"`
	ContactName   string       `db:"contact_name" json:"contact_name"`
	Email         string       `db:"email" json:"email"`
	Phone         string       `db:"phone" json:"phone"`
	Type          CustomerType `db:"type" json:"type"`
	TaxID         string       `db:"tax_id" json:"tax_id"`
	BillingAddress string      `db:"billing_address" json:"billing_address"`
	BillingCity   string       `db:"billing_city" json:"billing_city"`
	BillingState  string       `db:"billing_state" json:"billing_state"`
	BillingZip    string       `db:"billing_zip" json:"billing_zip"`
	BillingCountry string      `db:"billing_country" json:"billing_country"`
	CreditLimit   float64      `db:"credit_limit" json:"credit_limit"`
	OutstandingBal float64     `db:"outstanding_bal" json:"outstanding_bal"`
	PaymentTerms   int         `db:"payment_terms" json:"payment_terms"`
	IsActive       bool        `db:"is_active" json:"is_active"`
	Notes          string      `db:"notes" json:"notes"`
	CreatedAt      time.Time   `db:"created_at" json:"created_at"`
	UpdatedAt      time.Time   `db:"updated_at" json:"updated_at"`
}

type CreateCustomerRequest struct {
	CompanyName    string       `json:"company_name" binding:"required"`
	ContactName    string       `json:"contact_name" binding:"required"`
	Email          string       `json:"email" binding:"required,email"`
	Phone          string       `json:"phone"`
	Type           CustomerType `json:"type" binding:"required"`
	TaxID          string       `json:"tax_id"`
	BillingAddress string       `json:"billing_address"`
	BillingCity    string       `json:"billing_city"`
	BillingState   string       `json:"billing_state"`
	BillingZip     string       `json:"billing_zip"`
	BillingCountry string       `json:"billing_country"`
	CreditLimit    float64      `json:"credit_limit"`
	PaymentTerms   int          `json:"payment_terms"`
	Notes          string       `json:"notes"`
}

type UpdateCustomerRequest struct {
	CompanyName    string  `json:"company_name"`
	ContactName    string  `json:"contact_name"`
	Phone          string  `json:"phone"`
	TaxID          string  `json:"tax_id"`
	BillingAddress string  `json:"billing_address"`
	BillingCity    string  `json:"billing_city"`
	BillingState   string  `json:"billing_state"`
	BillingZip     string  `json:"billing_zip"`
	BillingCountry string  `json:"billing_country"`
	CreditLimit    float64 `json:"credit_limit"`
	PaymentTerms   int     `json:"payment_terms"`
	Notes          string  `json:"notes"`
}

type CustomerFilter struct {
	SearchTerm string
	Type       CustomerType
	City       string
	State      string
	Country    string
	IsActive   *bool
	HasBalance *bool
	FromDate   time.Time
	ToDate     time.Time
	Limit      int
	Offset     int
}

type CustomerResponse struct {
	ID             uuid.UUID    `json:"id"`
	CompanyName    string       `json:"company_name"`
	ContactName    string       `json:"contact_name"`
	Email          string       `json:"email"`
	Phone          string       `json:"phone"`
	Type           CustomerType `json:"type"`
	BillingCity    string       `json:"billing_city"`
	BillingState   string       `json:"billing_state"`
	CreditLimit    float64      `json:"credit_limit"`
	OutstandingBal float64      `json:"outstanding_bal"`
	IsActive       bool         `json:"is_active"`
	CreatedAt      time.Time    `json:"created_at"`
}

func (c *Customer) AvailableCredit() float64 {
	available := c.CreditLimit - c.OutstandingBal
	if available < 0 {
		return 0
	}
	return available
}

func (c *Customer) IsOverLimit() bool {
	return c.OutstandingBal > c.CreditLimit && c.CreditLimit > 0
}

func (c *Customer) CanCharge(amount float64) bool {
	if !c.IsActive {
		return false
	}
	if c.CreditLimit <= 0 {
		return true
	}
	return c.OutstandingBal+amount <= c.CreditLimit
}

func (c *Customer) BillingFullAddress() string {
	out := c.BillingAddress
	if c.BillingCity != "" {
		out += ", " + c.BillingCity
	}
	if c.BillingState != "" {
		out += ", " + c.BillingState
	}
	if c.BillingZip != "" {
		out += " " + c.BillingZip
	}
	if c.BillingCountry != "" {
		out += ", " + c.BillingCountry
	}
	return out
}

func (c *Customer) ToResponse() *CustomerResponse {
	return &CustomerResponse{
		ID:             c.ID,
		CompanyName:    c.CompanyName,
		ContactName:    c.ContactName,
		Email:          c.Email,
		Phone:          c.Phone,
		Type:           c.Type,
		BillingCity:    c.BillingCity,
		BillingState:   c.BillingState,
		CreditLimit:    c.CreditLimit,
		OutstandingBal: c.OutstandingBal,
		IsActive:       c.IsActive,
		CreatedAt:      c.CreatedAt,
	}
}

func (t CustomerType) IsBusiness() bool {
	return t == CustomerTypeBusiness || t == CustomerTypeGov
}
