package model

import (
	"time"

	"github.com/google/uuid"
)

type WarehouseType string

const (
	WarehouseTypeMain         WarehouseType = "main"
	WarehouseTypeRegional     WarehouseType = "regional"
	WarehouseTypeDistribution WarehouseType = "distribution"
	WarehouseTypeColdStorage  WarehouseType = "cold_storage"
	WarehouseTypeBondedDuty   WarehouseType = "bonded"
	WarehouseTypeCrossDock    WarehouseType = "cross_dock"
)

type Warehouse struct {
	ID               uuid.UUID     `db:"id" json:"id"`
	Code             string        `db:"code" json:"code"`
	Name             string        `db:"name" json:"name"`
	Type             WarehouseType `db:"type" json:"type"`
	Address          string        `db:"address" json:"address"`
	City             string        `db:"city" json:"city"`
	State            string        `db:"state" json:"state"`
	ZipCode          string        `db:"zip_code" json:"zip_code"`
	Country          string        `db:"country" json:"country"`
	Latitude         float64       `db:"latitude" json:"latitude"`
	Longitude        float64       `db:"longitude" json:"longitude"`
	Phone            string        `db:"phone" json:"phone"`
	ManagerName      string        `db:"manager_name" json:"manager_name"`
	ManagerEmail     string        `db:"manager_email" json:"manager_email"`
	Capacity         float64       `db:"capacity_m3" json:"capacity_m3"`
	UsedCapacity     float64       `db:"used_capacity_m3" json:"used_capacity_m3"`
	DocksCount       int           `db:"docks_count" json:"docks_count"`
	OperatingHours   string        `db:"operating_hours" json:"operating_hours"`
	HasColdStorage   bool          `db:"has_cold_storage" json:"has_cold_storage"`
	HasHazmatLicense bool          `db:"has_hazmat_license" json:"has_hazmat_license"`
	IsActive         bool          `db:"is_active" json:"is_active"`
	CreatedAt        time.Time     `db:"created_at" json:"created_at"`
	UpdatedAt        time.Time     `db:"updated_at" json:"updated_at"`
}

type CreateWarehouseRequest struct {
	Code             string        `json:"code" binding:"required"`
	Name             string        `json:"name" binding:"required"`
	Type             WarehouseType `json:"type" binding:"required"`
	Address          string        `json:"address" binding:"required"`
	City             string        `json:"city" binding:"required"`
	State            string        `json:"state"`
	ZipCode          string        `json:"zip_code"`
	Country          string        `json:"country"`
	Latitude         float64       `json:"latitude"`
	Longitude        float64       `json:"longitude"`
	Phone            string        `json:"phone"`
	ManagerName      string        `json:"manager_name"`
	ManagerEmail     string        `json:"manager_email"`
	Capacity         float64       `json:"capacity_m3"`
	DocksCount       int           `json:"docks_count"`
	OperatingHours   string        `json:"operating_hours"`
	HasColdStorage   bool          `json:"has_cold_storage"`
	HasHazmatLicense bool          `json:"has_hazmat_license"`
}

type UpdateWarehouseRequest struct {
	Name             string  `json:"name"`
	Phone            string  `json:"phone"`
	ManagerName      string  `json:"manager_name"`
	ManagerEmail     string  `json:"manager_email"`
	Capacity         float64 `json:"capacity_m3"`
	DocksCount       int     `json:"docks_count"`
	OperatingHours   string  `json:"operating_hours"`
	HasColdStorage   bool    `json:"has_cold_storage"`
	HasHazmatLicense bool    `json:"has_hazmat_license"`
}

type WarehouseFilter struct {
	SearchTerm     string
	Type           WarehouseType
	City           string
	State          string
	Country        string
	HasColdStorage *bool
	HasHazmat      *bool
	IsActive       *bool
	MinCapacity    float64
	Limit          int
	Offset         int
}

func (w *Warehouse) AvailableCapacity() float64 {
	avail := w.Capacity - w.UsedCapacity
	if avail < 0 {
		return 0
	}
	return avail
}

func (w *Warehouse) UtilizationPercent() float64 {
	if w.Capacity <= 0 {
		return 0
	}
	return (w.UsedCapacity / w.Capacity) * 100
}

func (w *Warehouse) IsFull() bool {
	if w.Capacity <= 0 {
		return false
	}
	return w.UsedCapacity >= w.Capacity
}

func (w *Warehouse) CanAccept(volumeM3 float64) bool {
	if !w.IsActive {
		return false
	}
	if w.Capacity <= 0 {
		return true
	}
	return w.UsedCapacity+volumeM3 <= w.Capacity
}

func (w *Warehouse) FullAddress() string {
	out := w.Address
	if w.City != "" {
		out += ", " + w.City
	}
	if w.State != "" {
		out += ", " + w.State
	}
	if w.ZipCode != "" {
		out += " " + w.ZipCode
	}
	if w.Country != "" {
		out += ", " + w.Country
	}
	return out
}

func (w *Warehouse) HasCoordinates() bool {
	return w.Latitude != 0 || w.Longitude != 0
}
