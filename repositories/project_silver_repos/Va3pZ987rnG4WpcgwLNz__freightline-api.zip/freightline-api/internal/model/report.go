package model

import (
	"time"

	"github.com/google/uuid"
)

type ReportPeriod struct {
	From time.Time
	To   time.Time
}

type FleetUtilizationReport struct {
	Period            ReportPeriod `json:"period"`
	TotalVehicles     int          `json:"total_vehicles"`
	AvailableVehicles int          `json:"available_vehicles"`
	InTransit         int          `json:"in_transit"`
	InMaintenance     int          `json:"in_maintenance"`
	UtilizationRate   float64      `json:"utilization_rate"`
	AvgOdometerKm     float64      `json:"avg_odometer_km"`
	TotalCapacityKg   float64      `json:"total_capacity_kg"`
	GeneratedAt       time.Time    `json:"generated_at"`
}

type DriverPerformanceReport struct {
	DriverID         uuid.UUID `json:"driver_id"`
	DriverName       string    `json:"driver_name"`
	Period           ReportPeriod `json:"period"`
	DeliveriesCompleted int    `json:"deliveries_completed"`
	OnTimeDeliveries int       `json:"on_time_deliveries"`
	LateDeliveries   int       `json:"late_deliveries"`
	FailedDeliveries int       `json:"failed_deliveries"`
	TotalMilesDriven float64   `json:"total_miles_driven"`
	OnTimeRate       float64   `json:"on_time_rate"`
	IncidentCount    int       `json:"incident_count"`
	AvgDeliveryHours float64   `json:"avg_delivery_hours"`
	GeneratedAt      time.Time `json:"generated_at"`
}

type RevenueReport struct {
	Period          ReportPeriod        `json:"period"`
	TotalRevenue    float64             `json:"total_revenue"`
	InvoicedAmount  float64             `json:"invoiced_amount"`
	CollectedAmount float64             `json:"collected_amount"`
	Outstanding     float64             `json:"outstanding"`
	OverdueAmount   float64             `json:"overdue_amount"`
	InvoiceCount    int                 `json:"invoice_count"`
	PaymentCount    int                 `json:"payment_count"`
	ByCustomer      []*CustomerRevenue  `json:"by_customer"`
	ByServiceLevel  []*ServiceLevelRevenue `json:"by_service_level"`
	GeneratedAt     time.Time           `json:"generated_at"`
}

type CustomerRevenue struct {
	CustomerID  uuid.UUID `json:"customer_id"`
	CustomerName string   `json:"customer_name"`
	Revenue     float64   `json:"revenue"`
	ShipmentCount int     `json:"shipment_count"`
}

type ServiceLevelRevenue struct {
	ServiceLevel ServiceLevel `json:"service_level"`
	Revenue      float64      `json:"revenue"`
	ShipmentCount int         `json:"shipment_count"`
}

type ShipmentVolumeReport struct {
	Period         ReportPeriod    `json:"period"`
	TotalShipments int             `json:"total_shipments"`
	TotalWeightKg  float64         `json:"total_weight_kg"`
	TotalVolumeM3  float64         `json:"total_volume_m3"`
	ByStatus       map[ShipmentStatus]int `json:"by_status"`
	ByServiceLevel map[ServiceLevel]int   `json:"by_service_level"`
	AvgDeliveryDays float64        `json:"avg_delivery_days"`
	OnTimeRate     float64         `json:"on_time_rate"`
	DamageRate     float64         `json:"damage_rate"`
	GeneratedAt    time.Time       `json:"generated_at"`
}

type WarehouseUtilizationReport struct {
	WarehouseID       uuid.UUID `json:"warehouse_id"`
	WarehouseName     string    `json:"warehouse_name"`
	Capacity          float64   `json:"capacity_m3"`
	Used              float64   `json:"used_m3"`
	UtilizationPercent float64  `json:"utilization_percent"`
	ShipmentsHandled  int       `json:"shipments_handled"`
	GeneratedAt       time.Time `json:"generated_at"`
}

type CarrierPerformanceReport struct {
	CarrierID       uuid.UUID `json:"carrier_id"`
	CarrierName     string    `json:"carrier_name"`
	Period          ReportPeriod `json:"period"`
	ShipmentCount   int       `json:"shipment_count"`
	OnTimeRate      float64   `json:"on_time_rate"`
	DamageRate      float64   `json:"damage_rate"`
	AvgCost         float64   `json:"avg_cost"`
	TotalSpend      float64   `json:"total_spend"`
	Score           float64   `json:"score"`
	GeneratedAt     time.Time `json:"generated_at"`
}

type DashboardSummary struct {
	ActiveShipments   int     `json:"active_shipments"`
	DeliveredToday    int     `json:"delivered_today"`
	PendingPickups    int     `json:"pending_pickups"`
	OverdueShipments  int     `json:"overdue_shipments"`
	AvailableDrivers  int     `json:"available_drivers"`
	AvailableVehicles int     `json:"available_vehicles"`
	OutstandingRevenue float64 `json:"outstanding_revenue"`
	RevenueThisMonth  float64 `json:"revenue_this_month"`
	GeneratedAt       time.Time `json:"generated_at"`
}


