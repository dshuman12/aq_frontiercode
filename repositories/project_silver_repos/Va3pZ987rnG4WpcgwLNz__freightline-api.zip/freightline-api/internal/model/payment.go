package model

import (
	"time"

	"github.com/google/uuid"
)

type PaymentMethod string

const (
	PaymentMethodCash       PaymentMethod = "cash"
	PaymentMethodCheck      PaymentMethod = "check"
	PaymentMethodWire       PaymentMethod = "wire"
	PaymentMethodACH        PaymentMethod = "ach"
	PaymentMethodCard       PaymentMethod = "card"
	PaymentMethodCreditNote PaymentMethod = "credit_note"
	PaymentMethodOther      PaymentMethod = "other"
)

type PaymentStatus string

const (
	PaymentStatusPending   PaymentStatus = "pending"
	PaymentStatusCleared   PaymentStatus = "cleared"
	PaymentStatusReversed  PaymentStatus = "reversed"
	PaymentStatusFailed    PaymentStatus = "failed"
	PaymentStatusRefunded  PaymentStatus = "refunded"
)

type Payment struct {
	ID            uuid.UUID     `db:"id" json:"id"`
	ReferenceNo   string        `db:"reference_no" json:"reference_no"`
	InvoiceID     uuid.UUID     `db:"invoice_id" json:"invoice_id"`
	CustomerID    uuid.UUID     `db:"customer_id" json:"customer_id"`
	Method        PaymentMethod `db:"method" json:"method"`
	Status        PaymentStatus `db:"status" json:"status"`
	Amount        float64       `db:"amount" json:"amount"`
	Currency      string        `db:"currency" json:"currency"`
	PaymentDate   time.Time     `db:"payment_date" json:"payment_date"`
	ClearedDate   *time.Time    `db:"cleared_date" json:"cleared_date"`
	ProcessorRef  string        `db:"processor_ref" json:"processor_ref"`
	BankReference string        `db:"bank_reference" json:"bank_reference"`
	Notes         string        `db:"notes" json:"notes"`
	CreatedAt     time.Time     `db:"created_at" json:"created_at"`
	UpdatedAt     time.Time     `db:"updated_at" json:"updated_at"`
}

type CreatePaymentRequest struct {
	InvoiceID     string        `json:"invoice_id" binding:"required"`
	Method        PaymentMethod `json:"method" binding:"required"`
	Amount        float64       `json:"amount" binding:"required"`
	Currency      string        `json:"currency"`
	PaymentDate   string        `json:"payment_date"`
	ProcessorRef  string        `json:"processor_ref"`
	BankReference string        `json:"bank_reference"`
	Notes         string        `json:"notes"`
}

type RefundPaymentRequest struct {
	Amount float64 `json:"amount" binding:"required"`
	Reason string  `json:"reason"`
}

type PaymentFilter struct {
	CustomerID *uuid.UUID
	InvoiceID  *uuid.UUID
	Method     PaymentMethod
	Status     PaymentStatus
	FromDate   time.Time
	ToDate     time.Time
	MinAmount  float64
	MaxAmount  float64
	Limit      int
	Offset     int
}

func (p *Payment) IsCleared() bool {
	return p.Status == PaymentStatusCleared
}

func (p *Payment) IsAvailable() bool {
	return p.Status != PaymentStatusReversed && p.Status != PaymentStatusFailed
}

func (p *Payment) DaysToClear() int {
	if p.ClearedDate == nil || p.PaymentDate.IsZero() {
		return 0
	}
	return int(p.ClearedDate.Sub(p.PaymentDate).Hours() / 24)
}

func (p *Payment) CanRefund() bool {
	return p.Status == PaymentStatusCleared
}
