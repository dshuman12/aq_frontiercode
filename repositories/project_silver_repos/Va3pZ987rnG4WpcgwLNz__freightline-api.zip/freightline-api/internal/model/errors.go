package model

import "errors"

var (
	ErrNotFound       = errors.New("not found")
	ErrDuplicate      = errors.New("duplicate record")
	ErrInvalidInput   = errors.New("invalid input")
	ErrForbidden      = errors.New("forbidden")
	ErrUnauthorized   = errors.New("unauthorized")
	ErrConflict       = errors.New("conflict")
	ErrUnavailable    = errors.New("unavailable")
	ErrAlreadyClosed  = errors.New("already closed")
	ErrInvalidStatus  = errors.New("invalid status transition")
	ErrInsufficient   = errors.New("insufficient capacity")
	ErrExpired        = errors.New("expired")
	ErrRateLimit      = errors.New("rate limit exceeded")
	ErrInternal       = errors.New("internal error")
	ErrMissingDep     = errors.New("dependency missing")
	ErrBadAssignment  = errors.New("bad assignment")
	ErrTooEarly       = errors.New("too early")
	ErrTooLate        = errors.New("too late")
)

type ServiceError struct {
	Code    string
	Message string
	Err     error
}

func (e *ServiceError) Error() string {
	if e.Err != nil {
		return e.Code + ": " + e.Message + ": " + e.Err.Error()
	}
	return e.Code + ": " + e.Message
}

func (e *ServiceError) Unwrap() error {
	return e.Err
}

func NewServiceError(code, message string, err error) *ServiceError {
	return &ServiceError{Code: code, Message: message, Err: err}
}
