package validator

import (
	"errors"
	"fmt"
	"regexp"
	"strings"
	"time"
	"unicode"

	"github.com/google/uuid"
)

var (
	emailRegex = regexp.MustCompile(`^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$`)
	phoneRegex = regexp.MustCompile(`^\+?[0-9\-\s()]{7,20}$`)
	plateRegex = regexp.MustCompile(`^[A-Z0-9\-]{2,12}$`)
	zipRegex   = regexp.MustCompile(`^[A-Za-z0-9\s\-]{3,12}$`)

	ErrEmptyField  = errors.New("field is required")
	ErrBadFormat   = errors.New("invalid format")
	ErrOutOfRange  = errors.New("value out of range")
	ErrBadID       = errors.New("invalid id")
	ErrFutureDate  = errors.New("date cannot be in the future")
	ErrPastDate    = errors.New("date cannot be in the past")
)

func RequireNonEmpty(field, value string) error {
	if strings.TrimSpace(value) == "" {
		return fmt.Errorf("%s: %w", field, ErrEmptyField)
	}
	return nil
}

func ValidateEmail(email string) error {
	email = strings.TrimSpace(email)
	if email == "" {
		return fmt.Errorf("email: %w", ErrEmptyField)
	}
	if !emailRegex.MatchString(email) {
		return fmt.Errorf("email: %w", ErrBadFormat)
	}
	return nil
}

func ValidatePhone(phone string) error {
	phone = strings.TrimSpace(phone)
	if phone == "" {
		return nil
	}
	if !phoneRegex.MatchString(phone) {
		return fmt.Errorf("phone: %w", ErrBadFormat)
	}
	return nil
}

func ValidateUUID(field, id string) (uuid.UUID, error) {
	u, err := uuid.Parse(id)
	if err != nil {
		return uuid.Nil, fmt.Errorf("%s: %w", field, ErrBadID)
	}
	return u, nil
}

func ValidatePositive(field string, n float64) error {
	if n <= 0 {
		return fmt.Errorf("%s: %w", field, ErrOutOfRange)
	}
	return nil
}

func ValidateNonNegative(field string, n float64) error {
	if n < 0 {
		return fmt.Errorf("%s: %w", field, ErrOutOfRange)
	}
	return nil
}

func ValidateRange(field string, n, min, max float64) error {
	if n < min || n > max {
		return fmt.Errorf("%s (%v): must be between %v and %v: %w", field, n, min, max, ErrOutOfRange)
	}
	return nil
}

func ValidatePlateNumber(plate string) error {
	plate = strings.ToUpper(strings.TrimSpace(plate))
	if plate == "" {
		return fmt.Errorf("plate_number: %w", ErrEmptyField)
	}
	if !plateRegex.MatchString(plate) {
		return fmt.Errorf("plate_number: %w", ErrBadFormat)
	}
	return nil
}

func ValidateZip(zip string) error {
	zip = strings.TrimSpace(zip)
	if zip == "" {
		return nil
	}
	if !zipRegex.MatchString(zip) {
		return fmt.Errorf("zip_code: %w", ErrBadFormat)
	}
	return nil
}

func ValidateDateInPast(field string, t time.Time) error {
	if t.IsZero() {
		return nil
	}
	if t.After(time.Now()) {
		return fmt.Errorf("%s: %w", field, ErrFutureDate)
	}
	return nil
}

func ValidateDateInFuture(field string, t time.Time) error {
	if t.IsZero() {
		return nil
	}
	if t.Before(time.Now()) {
		return fmt.Errorf("%s: %w", field, ErrPastDate)
	}
	return nil
}

func ValidateStringLength(field, value string, min, max int) error {
	l := len(strings.TrimSpace(value))
	if l < min || l > max {
		return fmt.Errorf("%s: length must be between %d and %d: %w", field, min, max, ErrOutOfRange)
	}
	return nil
}

func ValidateOneOf(field, value string, allowed []string) error {
	for _, a := range allowed {
		if a == value {
			return nil
		}
	}
	return fmt.Errorf("%s (%q): must be one of %v: %w", field, value, allowed, ErrBadFormat)
}

func ValidateAlphaNumeric(field, value string) error {
	for _, r := range value {
		if !unicode.IsLetter(r) && !unicode.IsDigit(r) {
			return fmt.Errorf("%s: %w", field, ErrBadFormat)
		}
	}
	return nil
}

func ValidatePassword(p string) error {
	if len(p) < 8 {
		return fmt.Errorf("password too short: %w", ErrOutOfRange)
	}
	var hasUpper, hasLower, hasDigit bool
	for _, r := range p {
		switch {
		case unicode.IsUpper(r):
			hasUpper = true
		case unicode.IsLower(r):
			hasLower = true
		case unicode.IsDigit(r):
			hasDigit = true
		}
	}
	if !hasUpper || !hasLower || !hasDigit {
		return fmt.Errorf("password must include upper, lower and digit: %w", ErrBadFormat)
	}
	return nil
}

func Sanitize(input string) string {
	s := strings.TrimSpace(input)
	s = strings.ReplaceAll(s, "\x00", "")
	return s
}

func CollectErrors(errs ...error) error {
	var nonNil []string
	for _, e := range errs {
		if e != nil {
			nonNil = append(nonNil, e.Error())
		}
	}
	if len(nonNil) == 0 {
		return nil
	}
	return errors.New(strings.Join(nonNil, "; "))
}

func ValidateRangeInt(field string, n, min, max int) error {
	if n < min || n > max {
		return fmt.Errorf("%s (%d): must be between %d and %d: %w", field, n, min, max, ErrOutOfRange)
	}
	return nil
}
