package audit

import (
	"context"
	"encoding/json"
	"sync"
	"time"

	"github.com/google/uuid"
)

type Action string

const (
	ActionCreate     Action = "create"
	ActionUpdate     Action = "update"
	ActionDelete     Action = "delete"
	ActionStatusSet  Action = "status_set"
	ActionAssign     Action = "assign"
	ActionUnassign   Action = "unassign"
	ActionDispatch   Action = "dispatch"
	ActionDeliver    Action = "deliver"
	ActionCancel     Action = "cancel"
	ActionPay        Action = "pay"
	ActionRefund     Action = "refund"
	ActionViewExport Action = "export"
	ActionLogin      Action = "login"
)

type Entry struct {
	ID         uuid.UUID
	ActorID    string
	EntityType string
	EntityID   interface{}
	Action     Action
	OldValues  map[string]interface{}
	NewValues  map[string]interface{}
	Notes      string
	IP         string
	UserAgent  string
	Timestamp  time.Time
}

type Logger interface {
	Log(ctx context.Context, entry *Entry)
	Recent(n int) []*Entry
	Query(filter EntryFilter) []*Entry
	Count() int
}

type EntryFilter struct {
	ActorID    string
	EntityType string
	Action     Action
	From       time.Time
	To         time.Time
}

type MemoryLogger struct {
	mu      sync.RWMutex
	entries []*Entry
	max     int
}

func NewMemoryLogger(max int) *MemoryLogger {
	if max <= 0 {
		max = 10000
	}
	return &MemoryLogger{
		entries: make([]*Entry, 0, max),
		max:     max,
	}
}

func (l *MemoryLogger) Log(ctx context.Context, entry *Entry) {
	if entry == nil {
		return
	}
	if entry.ID == uuid.Nil {
		entry.ID = uuid.New()
	}
	if entry.Timestamp.IsZero() {
		entry.Timestamp = time.Now()
	}

	l.mu.Lock()
	defer l.mu.Unlock()

	if len(l.entries) >= l.max {
		l.entries = l.entries[1:]
	}
	l.entries = append(l.entries, entry)
}

func (l *MemoryLogger) Recent(n int) []*Entry {
	l.mu.RLock()
	defer l.mu.RUnlock()

	if n <= 0 || n > len(l.entries) {
		n = len(l.entries)
	}
	out := make([]*Entry, n)
	start := len(l.entries) - n
	for i := 0; i < n; i++ {
		out[i] = l.entries[start+i]
	}
	return out
}

func (l *MemoryLogger) Count() int {
	l.mu.RLock()
	defer l.mu.RUnlock()
	return len(l.entries)
}

func (l *MemoryLogger) Query(filter EntryFilter) []*Entry {
	l.mu.RLock()
	defer l.mu.RUnlock()

	out := make([]*Entry, 0)
	for _, e := range l.entries {
		if filter.ActorID != "" && e.ActorID != filter.ActorID {
			continue
		}
		if filter.EntityType != "" && e.EntityType != filter.EntityType {
			continue
		}
		if filter.Action != "" && e.Action != filter.Action {
			continue
		}
		if !filter.From.IsZero() && e.Timestamp.Before(filter.From) {
			continue
		}
		if !filter.To.IsZero() && e.Timestamp.After(filter.To) {
			continue
		}
		out = append(out, e)
	}
	return out
}

func (l *MemoryLogger) Flush() {
	l.mu.Lock()
	defer l.mu.Unlock()
	l.entries = l.entries[:0]
}

func (e *Entry) ToJSON() ([]byte, error) {
	return json.Marshal(map[string]interface{}{
		"id":          e.ID,
		"actor_id":    e.ActorID,
		"entity_type": e.EntityType,
		"entity_id":   e.EntityID,
		"action":      e.Action,
		"old_values":  e.OldValues,
		"new_values":  e.NewValues,
		"notes":       e.Notes,
		"ip":          e.IP,
		"user_agent":  e.UserAgent,
		"timestamp":   e.Timestamp,
	})
}

func (l *MemoryLogger) Last() *Entry {
	l.mu.RLock()
	defer l.mu.RUnlock()
	if len(l.entries) == 0 {
		return nil
	}
	return l.entries[len(l.entries)-1]
}
