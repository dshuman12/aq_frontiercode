package repository

import (
	"context"

	"freightline.dev/api/internal/model"
	"github.com/google/uuid"
)

type CustomerRepository interface {
	Create(ctx context.Context, c *model.Customer) (uuid.UUID, error)
	GetByID(ctx context.Context, id uuid.UUID) (*model.Customer, error)
	GetByEmail(ctx context.Context, email string) (*model.Customer, error)
	Update(ctx context.Context, id uuid.UUID, c *model.Customer) error
	Delete(ctx context.Context, id uuid.UUID) error
	List(ctx context.Context, f *model.CustomerFilter) ([]*model.Customer, int, error)
	UpdateOutstandingBalance(ctx context.Context, id uuid.UUID, delta float64) error
	SetActive(ctx context.Context, id uuid.UUID, active bool) error
}

type DriverRepository interface {
	Create(ctx context.Context, d *model.Driver) (uuid.UUID, error)
	GetByID(ctx context.Context, id uuid.UUID) (*model.Driver, error)
	GetByEmployeeCode(ctx context.Context, code string) (*model.Driver, error)
	GetByEmail(ctx context.Context, email string) (*model.Driver, error)
	Update(ctx context.Context, id uuid.UUID, d *model.Driver) error
	Delete(ctx context.Context, id uuid.UUID) error
	List(ctx context.Context, f *model.DriverFilter) ([]*model.Driver, int, error)
	UpdateStatus(ctx context.Context, id uuid.UUID, status model.DriverStatus) error
	IncrementDeliveries(ctx context.Context, id uuid.UUID, miles float64) error
	ListAvailable(ctx context.Context) ([]*model.Driver, error)
	ListExpiringLicenses(ctx context.Context, days int) ([]*model.Driver, error)
}

type VehicleRepository interface {
	Create(ctx context.Context, v *model.Vehicle) (uuid.UUID, error)
	GetByID(ctx context.Context, id uuid.UUID) (*model.Vehicle, error)
	GetByPlate(ctx context.Context, plate string) (*model.Vehicle, error)
	GetByVIN(ctx context.Context, vin string) (*model.Vehicle, error)
	Update(ctx context.Context, id uuid.UUID, v *model.Vehicle) error
	Delete(ctx context.Context, id uuid.UUID) error
	List(ctx context.Context, f *model.VehicleFilter) ([]*model.Vehicle, int, error)
	UpdateStatus(ctx context.Context, id uuid.UUID, status model.VehicleStatus) error
	UpdateOdometer(ctx context.Context, id uuid.UUID, km float64) error
	ListAvailable(ctx context.Context) ([]*model.Vehicle, error)
	ListNeedingService(ctx context.Context) ([]*model.Vehicle, error)
}

type WarehouseRepository interface {
	Create(ctx context.Context, w *model.Warehouse) (uuid.UUID, error)
	GetByID(ctx context.Context, id uuid.UUID) (*model.Warehouse, error)
	GetByCode(ctx context.Context, code string) (*model.Warehouse, error)
	Update(ctx context.Context, id uuid.UUID, w *model.Warehouse) error
	Delete(ctx context.Context, id uuid.UUID) error
	List(ctx context.Context, f *model.WarehouseFilter) ([]*model.Warehouse, int, error)
	UpdateUsedCapacity(ctx context.Context, id uuid.UUID, delta float64) error
	SetActive(ctx context.Context, id uuid.UUID, active bool) error
}

type ShipmentRepository interface {
	Create(ctx context.Context, s *model.Shipment) (uuid.UUID, error)
	GetByID(ctx context.Context, id uuid.UUID) (*model.Shipment, error)
	GetByTrackingNumber(ctx context.Context, num string) (*model.Shipment, error)
	Update(ctx context.Context, id uuid.UUID, s *model.Shipment) error
	Delete(ctx context.Context, id uuid.UUID) error
	List(ctx context.Context, f *model.ShipmentFilter) ([]*model.Shipment, int, error)
	UpdateStatus(ctx context.Context, id uuid.UUID, status model.ShipmentStatus) error
	AssignDriver(ctx context.Context, id, driverID uuid.UUID) error
	AssignVehicle(ctx context.Context, id, vehicleID uuid.UUID) error
	AssignCarrier(ctx context.Context, id, carrierID uuid.UUID) error
	AttachInvoice(ctx context.Context, id, invoiceID uuid.UUID) error
	ListByCustomer(ctx context.Context, customerID uuid.UUID, limit int) ([]*model.Shipment, error)
	ListByDriver(ctx context.Context, driverID uuid.UUID, limit int) ([]*model.Shipment, error)
	ListByVehicle(ctx context.Context, vehicleID uuid.UUID, limit int) ([]*model.Shipment, error)
	ListOverdue(ctx context.Context) ([]*model.Shipment, error)
	CountByStatus(ctx context.Context) (map[model.ShipmentStatus]int, error)
}

type RouteRepository interface {
	Create(ctx context.Context, r *model.Route, stops []*model.RouteStop) (uuid.UUID, error)
	GetByID(ctx context.Context, id uuid.UUID) (*model.Route, error)
	GetWithStops(ctx context.Context, id uuid.UUID) (*model.RouteWithStops, error)
	Update(ctx context.Context, id uuid.UUID, r *model.Route) error
	Delete(ctx context.Context, id uuid.UUID) error
	List(ctx context.Context, f *model.RouteFilter) ([]*model.Route, int, error)
	UpdateStatus(ctx context.Context, id uuid.UUID, status model.RouteStatus) error
	CompleteStop(ctx context.Context, stopID uuid.UUID) error
	ListByDriver(ctx context.Context, driverID uuid.UUID, limit int) ([]*model.Route, error)
}

type TrackingEventRepository interface {
	Create(ctx context.Context, e *model.TrackingEvent) (uuid.UUID, error)
	GetByID(ctx context.Context, id uuid.UUID) (*model.TrackingEvent, error)
	ListByShipment(ctx context.Context, shipmentID uuid.UUID) ([]*model.TrackingEvent, error)
	List(ctx context.Context, f *model.TrackingEventFilter) ([]*model.TrackingEvent, int, error)
	GetLatestForShipment(ctx context.Context, shipmentID uuid.UUID) (*model.TrackingEvent, error)
}

type CarrierRepository interface {
	Create(ctx context.Context, c *model.Carrier) (uuid.UUID, error)
	GetByID(ctx context.Context, id uuid.UUID) (*model.Carrier, error)
	GetByCode(ctx context.Context, code string) (*model.Carrier, error)
	Update(ctx context.Context, id uuid.UUID, c *model.Carrier) error
	Delete(ctx context.Context, id uuid.UUID) error
	List(ctx context.Context, f *model.CarrierFilter) ([]*model.Carrier, int, error)
	UpdateStats(ctx context.Context, id uuid.UUID, onTime, damage float64, total int) error
	SetActive(ctx context.Context, id uuid.UUID, active bool) error
}

type InvoiceRepository interface {
	Create(ctx context.Context, inv *model.Invoice, lines []*model.InvoiceLineItem) (uuid.UUID, error)
	GetByID(ctx context.Context, id uuid.UUID) (*model.Invoice, error)
	GetWithLines(ctx context.Context, id uuid.UUID) (*model.InvoiceWithLines, error)
	GetByNumber(ctx context.Context, num string) (*model.Invoice, error)
	Update(ctx context.Context, id uuid.UUID, inv *model.Invoice) error
	Delete(ctx context.Context, id uuid.UUID) error
	List(ctx context.Context, f *model.InvoiceFilter) ([]*model.Invoice, int, error)
	UpdateStatus(ctx context.Context, id uuid.UUID, status model.InvoiceStatus) error
	ApplyPayment(ctx context.Context, id uuid.UUID, amount float64) error
	ListByCustomer(ctx context.Context, customerID uuid.UUID, limit int) ([]*model.Invoice, error)
	ListOverdue(ctx context.Context) ([]*model.Invoice, error)
	SumOutstanding(ctx context.Context) (float64, error)
}

type Set struct {
	Customer  CustomerRepository
	Driver    DriverRepository
	Vehicle   VehicleRepository
	Warehouse WarehouseRepository
	Shipment  ShipmentRepository
	Route     RouteRepository
	Tracking  TrackingEventRepository
	Carrier   CarrierRepository
	Invoice   InvoiceRepository
	Payment   PaymentRepository
}

type PaymentRepository interface {
	Create(ctx context.Context, p *model.Payment) (uuid.UUID, error)
	GetByID(ctx context.Context, id uuid.UUID) (*model.Payment, error)
	GetByReference(ctx context.Context, ref string) (*model.Payment, error)
	Update(ctx context.Context, id uuid.UUID, p *model.Payment) error
	UpdateStatus(ctx context.Context, id uuid.UUID, status model.PaymentStatus) error
	List(ctx context.Context, f *model.PaymentFilter) ([]*model.Payment, int, error)
	ListByInvoice(ctx context.Context, invoiceID uuid.UUID) ([]*model.Payment, error)
	SumForInvoice(ctx context.Context, invoiceID uuid.UUID) (float64, error)
}
