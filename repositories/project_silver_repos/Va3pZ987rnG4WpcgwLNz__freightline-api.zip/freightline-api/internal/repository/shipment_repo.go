package repository

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strings"
	"time"

	"freightline.dev/api/internal/db"
	"freightline.dev/api/internal/model"
	"github.com/google/uuid"
)

type PgShipmentRepo struct {
	db *db.DB
}

func NewPgShipmentRepo(d *db.DB) *PgShipmentRepo {
	return &PgShipmentRepo{db: d}
}

const shipmentColumns = `id, tracking_number, customer_id, origin_warehouse_id, dest_warehouse_id,
		assigned_driver_id, assigned_vehicle_id, route_id, carrier_id, invoice_id,
		pickup_name, pickup_phone, pickup_address, pickup_city, pickup_state, pickup_zip, pickup_country,
		delivery_name, delivery_phone, delivery_address, delivery_city, delivery_state, delivery_zip, delivery_country,
		status, service_level, weight_kg, volume_m3, pieces, declared_value,
		base_rate, fuel_surcharge, insurance_fee, handling_fee, total_charge,
		is_fragile, is_hazmat, requires_refrigeration, requires_signature, special_instructions,
		scheduled_pickup, actual_pickup, scheduled_delivery, actual_delivery,
		created_at, updated_at`

func (r *PgShipmentRepo) Create(ctx context.Context, s *model.Shipment) (uuid.UUID, error) {
	if s.ID == uuid.Nil {
		s.ID = uuid.New()
	}
	if s.CreatedAt.IsZero() {
		s.CreatedAt = time.Now()
	}
	s.UpdatedAt = time.Now()

	q := `INSERT INTO shipments (` + shipmentColumns + `) VALUES (
		:id, :tracking_number, :customer_id, :origin_warehouse_id, :dest_warehouse_id,
		:assigned_driver_id, :assigned_vehicle_id, :route_id, :carrier_id, :invoice_id,
		:pickup_name, :pickup_phone, :pickup_address, :pickup_city, :pickup_state, :pickup_zip, :pickup_country,
		:delivery_name, :delivery_phone, :delivery_address, :delivery_city, :delivery_state, :delivery_zip, :delivery_country,
		:status, :service_level, :weight_kg, :volume_m3, :pieces, :declared_value,
		:base_rate, :fuel_surcharge, :insurance_fee, :handling_fee, :total_charge,
		:is_fragile, :is_hazmat, :requires_refrigeration, :requires_signature, :special_instructions,
		:scheduled_pickup, :actual_pickup, :scheduled_delivery, :actual_delivery,
		:created_at, :updated_at)`
	_, err := r.db.NamedExecContext(ctx, q, s)
	if err != nil {
		return uuid.Nil, fmt.Errorf("insert shipment: %w", err)
	}
	return s.ID, nil
}

func (r *PgShipmentRepo) GetByID(ctx context.Context, id uuid.UUID) (*model.Shipment, error) {
	var s model.Shipment
	q := `SELECT ` + shipmentColumns + ` FROM shipments WHERE id = $1`
	if err := r.db.GetContext(ctx, &s, q, id); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, model.ErrNotFound
		}
		return nil, fmt.Errorf("get shipment: %w", err)
	}
	return &s, nil
}

func (r *PgShipmentRepo) GetByTrackingNumber(ctx context.Context, num string) (*model.Shipment, error) {
	var s model.Shipment
	q := `SELECT ` + shipmentColumns + ` FROM shipments WHERE tracking_number = $1`
	if err := r.db.GetContext(ctx, &s, q, num); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, model.ErrNotFound
		}
		return nil, fmt.Errorf("get shipment by tracking: %w", err)
	}
	return &s, nil
}

func (r *PgShipmentRepo) Update(ctx context.Context, id uuid.UUID, s *model.Shipment) error {
	s.UpdatedAt = time.Now()
	s.ID = id
	q := `UPDATE shipments SET
		delivery_name = :delivery_name, delivery_phone = :delivery_phone,
		delivery_address = :delivery_address, special_instructions = :special_instructions,
		scheduled_pickup = :scheduled_pickup, scheduled_delivery = :scheduled_delivery,
		declared_value = :declared_value, updated_at = :updated_at WHERE id = :id`
	res, err := r.db.NamedExecContext(ctx, q, s)
	if err != nil {
		return fmt.Errorf("update shipment: %w", err)
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return model.ErrNotFound
	}
	return nil
}

func (r *PgShipmentRepo) Delete(ctx context.Context, id uuid.UUID) error {
	q := `DELETE FROM shipments WHERE id = $1`
	res, err := r.db.ExecContext(ctx, q, id)
	if err != nil {
		return fmt.Errorf("delete shipment: %w", err)
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return model.ErrNotFound
	}
	return nil
}

func (r *PgShipmentRepo) buildFilter(f *model.ShipmentFilter) (string, []interface{}) {
	if f == nil {
		return "", nil
	}
	parts := []string{}
	args := []interface{}{}
	idx := 1
	if f.SearchTerm != "" {
		parts = append(parts, fmt.Sprintf("(tracking_number ILIKE $%d OR pickup_name ILIKE $%d OR delivery_name ILIKE $%d)", idx, idx, idx))
		args = append(args, "%"+f.SearchTerm+"%")
		idx++
	}
	if f.Status != "" {
		parts = append(parts, fmt.Sprintf("status = $%d", idx))
		args = append(args, f.Status)
		idx++
	}
	if f.ServiceLevel != "" {
		parts = append(parts, fmt.Sprintf("service_level = $%d", idx))
		args = append(args, f.ServiceLevel)
		idx++
	}
	if f.CustomerID != nil {
		parts = append(parts, fmt.Sprintf("customer_id = $%d", idx))
		args = append(args, *f.CustomerID)
		idx++
	}
	if f.DriverID != nil {
		parts = append(parts, fmt.Sprintf("assigned_driver_id = $%d", idx))
		args = append(args, *f.DriverID)
		idx++
	}
	if f.VehicleID != nil {
		parts = append(parts, fmt.Sprintf("assigned_vehicle_id = $%d", idx))
		args = append(args, *f.VehicleID)
		idx++
	}
	if f.CarrierID != nil {
		parts = append(parts, fmt.Sprintf("carrier_id = $%d", idx))
		args = append(args, *f.CarrierID)
		idx++
	}
	if f.IsHazmat != nil {
		parts = append(parts, fmt.Sprintf("is_hazmat = $%d", idx))
		args = append(args, *f.IsHazmat)
		idx++
	}
	if f.IsFragile != nil {
		parts = append(parts, fmt.Sprintf("is_fragile = $%d", idx))
		args = append(args, *f.IsFragile)
		idx++
	}
	if f.MinWeight > 0 {
		parts = append(parts, fmt.Sprintf("weight_kg >= $%d", idx))
		args = append(args, f.MinWeight)
		idx++
	}
	if f.MaxWeight > 0 {
		parts = append(parts, fmt.Sprintf("weight_kg <= $%d", idx))
		args = append(args, f.MaxWeight)
		idx++
	}
	if !f.FromDate.IsZero() {
		parts = append(parts, fmt.Sprintf("created_at >= $%d", idx))
		args = append(args, f.FromDate)
		idx++
	}
	if !f.ToDate.IsZero() {
		parts = append(parts, fmt.Sprintf("created_at <= $%d", idx))
		args = append(args, f.ToDate)
		idx++
	}
	if len(parts) == 0 {
		return "", args
	}
	return "WHERE " + strings.Join(parts, " AND "), args
}

func (r *PgShipmentRepo) List(ctx context.Context, f *model.ShipmentFilter) ([]*model.Shipment, int, error) {
	where, args := r.buildFilter(f)
	var total int
	if err := r.db.GetContext(ctx, &total, `SELECT COUNT(*) FROM shipments `+where, args...); err != nil {
		return nil, 0, fmt.Errorf("count shipments: %w", err)
	}
	q := `SELECT ` + shipmentColumns + ` FROM shipments ` + where +
		` ORDER BY created_at DESC LIMIT $` + fmt.Sprint(len(args)+1) + ` OFFSET $` + fmt.Sprint(len(args)+2)
	args = append(args, f.Limit, f.Offset)
	rows := []*model.Shipment{}
	if err := r.db.SelectContext(ctx, &rows, q, args...); err != nil {
		return nil, 0, fmt.Errorf("select shipments: %w", err)
	}
	return rows, total, nil
}

func (r *PgShipmentRepo) UpdateStatus(ctx context.Context, id uuid.UUID, status model.ShipmentStatus) error {
	q := `UPDATE shipments SET status = $1, updated_at = $2 WHERE id = $3`
	res, err := r.db.ExecContext(ctx, q, status, time.Now(), id)
	if err != nil {
		return fmt.Errorf("update status: %w", err)
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return model.ErrNotFound
	}
	return nil
}

func (r *PgShipmentRepo) AssignDriver(ctx context.Context, id, driverID uuid.UUID) error {
	q := `UPDATE shipments SET assigned_driver_id = $1, updated_at = $2 WHERE id = $3`
	res, err := r.db.ExecContext(ctx, q, driverID, time.Now(), id)
	if err != nil {
		return fmt.Errorf("assign driver: %w", err)
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return model.ErrNotFound
	}
	return nil
}

func (r *PgShipmentRepo) AssignVehicle(ctx context.Context, id, vehicleID uuid.UUID) error {
	q := `UPDATE shipments SET assigned_vehicle_id = $1, updated_at = $2 WHERE id = $3`
	res, err := r.db.ExecContext(ctx, q, vehicleID, time.Now(), id)
	if err != nil {
		return fmt.Errorf("assign vehicle: %w", err)
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return model.ErrNotFound
	}
	return nil
}

func (r *PgShipmentRepo) AssignCarrier(ctx context.Context, id, carrierID uuid.UUID) error {
	q := `UPDATE shipments SET carrier_id = $1, updated_at = $2 WHERE id = $3`
	res, err := r.db.ExecContext(ctx, q, carrierID, time.Now(), id)
	if err != nil {
		return fmt.Errorf("assign carrier: %w", err)
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return model.ErrNotFound
	}
	return nil
}

func (r *PgShipmentRepo) AttachInvoice(ctx context.Context, id, invoiceID uuid.UUID) error {
	q := `UPDATE shipments SET invoice_id = $1, updated_at = $2 WHERE id = $3`
	res, err := r.db.ExecContext(ctx, q, invoiceID, time.Now(), id)
	if err != nil {
		return fmt.Errorf("attach invoice: %w", err)
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return model.ErrNotFound
	}
	return nil
}

func (r *PgShipmentRepo) ListByCustomer(ctx context.Context, customerID uuid.UUID, limit int) ([]*model.Shipment, error) {
	if limit <= 0 {
		limit = 50
	}
	q := `SELECT ` + shipmentColumns + ` FROM shipments WHERE customer_id = $1 ORDER BY created_at DESC LIMIT $2`
	rows := []*model.Shipment{}
	if err := r.db.SelectContext(ctx, &rows, q, customerID, limit); err != nil {
		return nil, fmt.Errorf("list by customer: %w", err)
	}
	return rows, nil
}

func (r *PgShipmentRepo) ListByDriver(ctx context.Context, driverID uuid.UUID, limit int) ([]*model.Shipment, error) {
	if limit <= 0 {
		limit = 50
	}
	q := `SELECT ` + shipmentColumns + ` FROM shipments WHERE assigned_driver_id = $1 ORDER BY created_at DESC LIMIT $2`
	rows := []*model.Shipment{}
	if err := r.db.SelectContext(ctx, &rows, q, driverID, limit); err != nil {
		return nil, fmt.Errorf("list by driver: %w", err)
	}
	return rows, nil
}

func (r *PgShipmentRepo) ListByVehicle(ctx context.Context, vehicleID uuid.UUID, limit int) ([]*model.Shipment, error) {
	if limit <= 0 {
		limit = 50
	}
	q := `SELECT ` + shipmentColumns + ` FROM shipments WHERE assigned_vehicle_id = $1 ORDER BY created_at DESC LIMIT $2`
	rows := []*model.Shipment{}
	if err := r.db.SelectContext(ctx, &rows, q, vehicleID, limit); err != nil {
		return nil, fmt.Errorf("list by vehicle: %w", err)
	}
	return rows, nil
}

func (r *PgShipmentRepo) ListOverdue(ctx context.Context) ([]*model.Shipment, error) {
	q := `SELECT ` + shipmentColumns + ` FROM shipments
		WHERE status NOT IN ('delivered','cancelled','returned')
		AND scheduled_delivery < $1 ORDER BY scheduled_delivery ASC LIMIT 200`
	rows := []*model.Shipment{}
	if err := r.db.SelectContext(ctx, &rows, q, time.Now()); err != nil {
		return nil, fmt.Errorf("list overdue: %w", err)
	}
	return rows, nil
}

func (r *PgShipmentRepo) CountByStatus(ctx context.Context) (map[model.ShipmentStatus]int, error) {
	type row struct {
		Status model.ShipmentStatus `db:"status"`
		N      int                  `db:"n"`
	}
	q := `SELECT status, COUNT(*) AS n FROM shipments GROUP BY status`
	out := []row{}
	if err := r.db.SelectContext(ctx, &out, q); err != nil {
		return nil, fmt.Errorf("count by status: %w", err)
	}
	m := make(map[model.ShipmentStatus]int, len(out))
	for _, r := range out {
		m[r.Status] = r.N
	}
	return m, nil
}
