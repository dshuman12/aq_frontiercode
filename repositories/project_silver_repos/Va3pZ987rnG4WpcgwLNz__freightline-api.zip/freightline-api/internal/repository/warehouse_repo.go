package repository

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strings"
	"time"

	"freightline.dev/api/internal/db"
	"freightline.dev/api/internal/model"
	"github.com/google/uuid"
)

type PgWarehouseRepo struct {
	db *db.DB
}

func NewPgWarehouseRepo(d *db.DB) *PgWarehouseRepo {
	return &PgWarehouseRepo{db: d}
}

const warehouseColumns = `id, code, name, type, address, city, state, zip_code, country,
		latitude, longitude, phone, manager_name, manager_email,
		capacity_m3, used_capacity_m3, docks_count, operating_hours,
		has_cold_storage, has_hazmat_license, is_active, created_at, updated_at`

func (r *PgWarehouseRepo) Create(ctx context.Context, w *model.Warehouse) (uuid.UUID, error) {
	if w.ID == uuid.Nil {
		w.ID = uuid.New()
	}
	if w.CreatedAt.IsZero() {
		w.CreatedAt = time.Now()
	}
	w.UpdatedAt = time.Now()
	q := `INSERT INTO warehouses (` + warehouseColumns + `) VALUES (
		:id, :code, :name, :type, :address, :city, :state, :zip_code, :country,
		:latitude, :longitude, :phone, :manager_name, :manager_email,
		:capacity_m3, :used_capacity_m3, :docks_count, :operating_hours,
		:has_cold_storage, :has_hazmat_license, :is_active, :created_at, :updated_at)`
	_, err := r.db.NamedExecContext(ctx, q, w)
	if err != nil {
		return uuid.Nil, fmt.Errorf("insert warehouse: %w", err)
	}
	return w.ID, nil
}

func (r *PgWarehouseRepo) GetByID(ctx context.Context, id uuid.UUID) (*model.Warehouse, error) {
	var w model.Warehouse
	q := `SELECT ` + warehouseColumns + ` FROM warehouses WHERE id = $1`
	if err := r.db.GetContext(ctx, &w, q, id); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, model.ErrNotFound
		}
		return nil, fmt.Errorf("get warehouse: %w", err)
	}
	return &w, nil
}

func (r *PgWarehouseRepo) GetByCode(ctx context.Context, code string) (*model.Warehouse, error) {
	var w model.Warehouse
	q := `SELECT ` + warehouseColumns + ` FROM warehouses WHERE UPPER(code) = UPPER($1)`
	if err := r.db.GetContext(ctx, &w, q, code); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, model.ErrNotFound
		}
		return nil, fmt.Errorf("get warehouse by code: %w", err)
	}
	return &w, nil
}

func (r *PgWarehouseRepo) Update(ctx context.Context, id uuid.UUID, w *model.Warehouse) error {
	w.UpdatedAt = time.Now()
	w.ID = id
	q := `UPDATE warehouses SET name = :name, phone = :phone,
		manager_name = :manager_name, manager_email = :manager_email,
		capacity_m3 = :capacity_m3, docks_count = :docks_count,
		operating_hours = :operating_hours, has_cold_storage = :has_cold_storage,
		has_hazmat_license = :has_hazmat_license, updated_at = :updated_at
		WHERE id = :id`
	res, err := r.db.NamedExecContext(ctx, q, w)
	if err != nil {
		return fmt.Errorf("update warehouse: %w", err)
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return model.ErrNotFound
	}
	return nil
}

func (r *PgWarehouseRepo) Delete(ctx context.Context, id uuid.UUID) error {
	q := `DELETE FROM warehouses WHERE id = $1`
	res, err := r.db.ExecContext(ctx, q, id)
	if err != nil {
		return fmt.Errorf("delete warehouse: %w", err)
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return model.ErrNotFound
	}
	return nil
}

func (r *PgWarehouseRepo) List(ctx context.Context, f *model.WarehouseFilter) ([]*model.Warehouse, int, error) {
	parts := []string{}
	args := []interface{}{}
	idx := 1
	if f != nil {
		if f.SearchTerm != "" {
			parts = append(parts, fmt.Sprintf("(name ILIKE $%d OR code ILIKE $%d OR city ILIKE $%d)", idx, idx, idx))
			args = append(args, "%"+f.SearchTerm+"%")
			idx++
		}
		if f.Type != "" {
			parts = append(parts, fmt.Sprintf("type = $%d", idx))
			args = append(args, f.Type)
			idx++
		}
		if f.City != "" {
			parts = append(parts, fmt.Sprintf("city = $%d", idx))
			args = append(args, f.City)
			idx++
		}
		if f.State != "" {
			parts = append(parts, fmt.Sprintf("state = $%d", idx))
			args = append(args, f.State)
			idx++
		}
		if f.Country != "" {
			parts = append(parts, fmt.Sprintf("country = $%d", idx))
			args = append(args, f.Country)
			idx++
		}
		if f.HasColdStorage != nil {
			parts = append(parts, fmt.Sprintf("has_cold_storage = $%d", idx))
			args = append(args, *f.HasColdStorage)
			idx++
		}
		if f.IsActive != nil {
			parts = append(parts, fmt.Sprintf("is_active = $%d", idx))
			args = append(args, *f.IsActive)
			idx++
		}
		if f.MinCapacity > 0 {
			parts = append(parts, fmt.Sprintf("capacity_m3 >= $%d", idx))
			args = append(args, f.MinCapacity)
			idx++
		}
	}
	where := ""
	if len(parts) > 0 {
		where = "WHERE " + strings.Join(parts, " AND ")
	}

	var total int
	if err := r.db.GetContext(ctx, &total, `SELECT COUNT(*) FROM warehouses `+where, args...); err != nil {
		return nil, 0, fmt.Errorf("count warehouses: %w", err)
	}
	limit := 25
	offset := 0
	if f != nil {
		limit = f.Limit
		offset = f.Offset
	}
	q := `SELECT ` + warehouseColumns + ` FROM warehouses ` + where +
		` ORDER BY name LIMIT $` + fmt.Sprint(len(args)+1) + ` OFFSET $` + fmt.Sprint(len(args)+2)
	args = append(args, limit, offset)
	rows := []*model.Warehouse{}
	if err := r.db.SelectContext(ctx, &rows, q, args...); err != nil {
		return nil, 0, fmt.Errorf("select warehouses: %w", err)
	}
	return rows, total, nil
}

func (r *PgWarehouseRepo) UpdateUsedCapacity(ctx context.Context, id uuid.UUID, delta float64) error {
	q := `UPDATE warehouses SET used_capacity_m3 = GREATEST(used_capacity_m3 + $1, 0),
			updated_at = $2 WHERE id = $3`
	res, err := r.db.ExecContext(ctx, q, delta, time.Now(), id)
	if err != nil {
		return fmt.Errorf("update used capacity: %w", err)
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return model.ErrNotFound
	}
	return nil
}

func (r *PgWarehouseRepo) SetActive(ctx context.Context, id uuid.UUID, active bool) error {
	q := `UPDATE warehouses SET is_active = $1, updated_at = $2 WHERE id = $3`
	res, err := r.db.ExecContext(ctx, q, active, time.Now(), id)
	if err != nil {
		return fmt.Errorf("set active: %w", err)
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return model.ErrNotFound
	}
	return nil
}
