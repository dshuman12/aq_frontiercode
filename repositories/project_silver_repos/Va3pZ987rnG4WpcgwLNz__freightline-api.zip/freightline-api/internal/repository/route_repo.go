package repository

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strings"
	"time"

	"freightline.dev/api/internal/db"
	"freightline.dev/api/internal/model"
	"github.com/google/uuid"
	"github.com/jmoiron/sqlx"
)

type PgRouteRepo struct {
	db *db.DB
}

func NewPgRouteRepo(d *db.DB) *PgRouteRepo {
	return &PgRouteRepo{db: d}
}

const routeColumns = `id, code, name, driver_id, vehicle_id, origin_warehouse_id, status,
		planned_distance_km, actual_distance_km, planned_duration_hours, actual_duration_hours,
		stop_count, completed_stops, scheduled_start, scheduled_end, actual_start, actual_end,
		fuel_cost, toll_cost, notes, created_at, updated_at`

func (r *PgRouteRepo) Create(ctx context.Context, route *model.Route, stops []*model.RouteStop) (uuid.UUID, error) {
	if route.ID == uuid.Nil {
		route.ID = uuid.New()
	}
	if route.CreatedAt.IsZero() {
		route.CreatedAt = time.Now()
	}
	route.UpdatedAt = time.Now()
	route.StopCount = len(stops)

	err := r.db.WithTx(ctx, func(tx *sqlx.Tx) error {
		q := `INSERT INTO routes (` + routeColumns + `) VALUES (
			:id, :code, :name, :driver_id, :vehicle_id, :origin_warehouse_id, :status,
			:planned_distance_km, :actual_distance_km, :planned_duration_hours, :actual_duration_hours,
			:stop_count, :completed_stops, :scheduled_start, :scheduled_end, :actual_start, :actual_end,
			:fuel_cost, :toll_cost, :notes, :created_at, :updated_at)`
		if _, err := tx.NamedExecContext(ctx, q, route); err != nil {
			return fmt.Errorf("insert route: %w", err)
		}
		for _, s := range stops {
			if s.ID == uuid.Nil {
				s.ID = uuid.New()
			}
			s.RouteID = route.ID
			sq := `INSERT INTO route_stops (id, route_id, shipment_id, stop_order, stop_type,
				address, city, state, latitude, longitude, planned_eta, actual_eta, completed, notes)
				VALUES (:id, :route_id, :shipment_id, :stop_order, :stop_type,
				:address, :city, :state, :latitude, :longitude, :planned_eta, :actual_eta, :completed, :notes)`
			if _, err := tx.NamedExecContext(ctx, sq, s); err != nil {
				return fmt.Errorf("insert route stop: %w", err)
			}
		}
		return nil
	})
	if err != nil {
		return uuid.Nil, err
	}
	return route.ID, nil
}

func (r *PgRouteRepo) GetByID(ctx context.Context, id uuid.UUID) (*model.Route, error) {
	var rt model.Route
	q := `SELECT ` + routeColumns + ` FROM routes WHERE id = $1`
	if err := r.db.GetContext(ctx, &rt, q, id); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, model.ErrNotFound
		}
		return nil, fmt.Errorf("get route: %w", err)
	}
	return &rt, nil
}

func (r *PgRouteRepo) GetWithStops(ctx context.Context, id uuid.UUID) (*model.RouteWithStops, error) {
	route, err := r.GetByID(ctx, id)
	if err != nil {
		return nil, err
	}
	stops := []*model.RouteStop{}
	if err := r.db.SelectContext(ctx, &stops,
		`SELECT id, route_id, shipment_id, stop_order, stop_type, address, city, state,
		latitude, longitude, planned_eta, actual_eta, completed, notes
		FROM route_stops WHERE route_id = $1 ORDER BY stop_order ASC`, id); err != nil {
		return nil, fmt.Errorf("get stops: %w", err)
	}
	return &model.RouteWithStops{Route: route, Stops: stops}, nil
}

func (r *PgRouteRepo) Update(ctx context.Context, id uuid.UUID, route *model.Route) error {
	route.UpdatedAt = time.Now()
	route.ID = id
	q := `UPDATE routes SET name = :name, driver_id = :driver_id, vehicle_id = :vehicle_id,
		scheduled_start = :scheduled_start, scheduled_end = :scheduled_end,
		planned_distance_km = :planned_distance_km, planned_duration_hours = :planned_duration_hours,
		notes = :notes, updated_at = :updated_at WHERE id = :id`
	res, err := r.db.NamedExecContext(ctx, q, route)
	if err != nil {
		return fmt.Errorf("update route: %w", err)
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return model.ErrNotFound
	}
	return nil
}

func (r *PgRouteRepo) Delete(ctx context.Context, id uuid.UUID) error {
	return r.db.WithTx(ctx, func(tx *sqlx.Tx) error {
		if _, err := tx.ExecContext(ctx, `DELETE FROM route_stops WHERE route_id = $1`, id); err != nil {
			return fmt.Errorf("delete stops: %w", err)
		}
		res, err := tx.ExecContext(ctx, `DELETE FROM routes WHERE id = $1`, id)
		if err != nil {
			return fmt.Errorf("delete route: %w", err)
		}
		n, _ := res.RowsAffected()
		if n == 0 {
			return model.ErrNotFound
		}
		return nil
	})
}

func (r *PgRouteRepo) List(ctx context.Context, f *model.RouteFilter) ([]*model.Route, int, error) {
	parts := []string{}
	args := []interface{}{}
	idx := 1
	if f != nil {
		if f.SearchTerm != "" {
			parts = append(parts, fmt.Sprintf("(name ILIKE $%d OR code ILIKE $%d)", idx, idx))
			args = append(args, "%"+f.SearchTerm+"%")
			idx++
		}
		if f.Status != "" {
			parts = append(parts, fmt.Sprintf("status = $%d", idx))
			args = append(args, f.Status)
			idx++
		}
		if f.DriverID != nil {
			parts = append(parts, fmt.Sprintf("driver_id = $%d", idx))
			args = append(args, *f.DriverID)
			idx++
		}
		if f.VehicleID != nil {
			parts = append(parts, fmt.Sprintf("vehicle_id = $%d", idx))
			args = append(args, *f.VehicleID)
			idx++
		}
		if f.OriginWarehouseID != nil {
			parts = append(parts, fmt.Sprintf("origin_warehouse_id = $%d", idx))
			args = append(args, *f.OriginWarehouseID)
			idx++
		}
		if !f.FromDate.IsZero() {
			parts = append(parts, fmt.Sprintf("scheduled_start >= $%d", idx))
			args = append(args, f.FromDate)
			idx++
		}
		if !f.ToDate.IsZero() {
			parts = append(parts, fmt.Sprintf("scheduled_start <= $%d", idx))
			args = append(args, f.ToDate)
			idx++
		}
	}
	where := ""
	if len(parts) > 0 {
		where = "WHERE " + strings.Join(parts, " AND ")
	}
	var total int
	if err := r.db.GetContext(ctx, &total, `SELECT COUNT(*) FROM routes `+where, args...); err != nil {
		return nil, 0, fmt.Errorf("count routes: %w", err)
	}
	limit := 25
	offset := 0
	if f != nil {
		limit = f.Limit
		offset = f.Offset
	}
	q := `SELECT ` + routeColumns + ` FROM routes ` + where +
		` ORDER BY scheduled_start DESC LIMIT $` + fmt.Sprint(len(args)+1) + ` OFFSET $` + fmt.Sprint(len(args)+2)
	args = append(args, limit, offset)
	rows := []*model.Route{}
	if err := r.db.SelectContext(ctx, &rows, q, args...); err != nil {
		return nil, 0, fmt.Errorf("select routes: %w", err)
	}
	return rows, total, nil
}

func (r *PgRouteRepo) UpdateStatus(ctx context.Context, id uuid.UUID, status model.RouteStatus) error {
	q := `UPDATE routes SET status = $1, updated_at = $2 WHERE id = $3`
	res, err := r.db.ExecContext(ctx, q, status, time.Now(), id)
	if err != nil {
		return fmt.Errorf("update route status: %w", err)
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return model.ErrNotFound
	}
	return nil
}

func (r *PgRouteRepo) CompleteStop(ctx context.Context, stopID uuid.UUID) error {
	return r.db.WithTx(ctx, func(tx *sqlx.Tx) error {
		var routeID uuid.UUID
		if err := tx.GetContext(ctx, &routeID,
			`SELECT route_id FROM route_stops WHERE id = $1`, stopID); err != nil {
			if errors.Is(err, sql.ErrNoRows) {
				return model.ErrNotFound
			}
			return fmt.Errorf("lookup stop: %w", err)
		}
		if _, err := tx.ExecContext(ctx,
			`UPDATE route_stops SET completed = true, actual_eta = $1 WHERE id = $2 AND completed = false`,
			time.Now(), stopID); err != nil {
			return fmt.Errorf("complete stop: %w", err)
		}
		if _, err := tx.ExecContext(ctx,
			`UPDATE routes SET completed_stops = completed_stops + 1, updated_at = $1 WHERE id = $2`,
			time.Now(), routeID); err != nil {
			return fmt.Errorf("inc completed: %w", err)
		}
		return nil
	})
}

func (r *PgRouteRepo) ListByDriver(ctx context.Context, driverID uuid.UUID, limit int) ([]*model.Route, error) {
	if limit <= 0 {
		limit = 50
	}
	q := `SELECT ` + routeColumns + ` FROM routes WHERE driver_id = $1 ORDER BY scheduled_start DESC LIMIT $2`
	rows := []*model.Route{}
	if err := r.db.SelectContext(ctx, &rows, q, driverID, limit); err != nil {
		return nil, fmt.Errorf("list by driver: %w", err)
	}
	return rows, nil
}
