package repository

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strings"
	"time"

	"freightline.dev/api/internal/db"
	"freightline.dev/api/internal/model"
	"github.com/google/uuid"
)

type PgCarrierRepo struct {
	db *db.DB
}

func NewPgCarrierRepo(d *db.DB) *PgCarrierRepo {
	return &PgCarrierRepo{db: d}
}

const carrierColumns = `id, name, code, contact_name, email, phone, address, city, state, country,
		service_area, base_rate, per_kg_rate, per_km_rate, fuel_surcharge_rate,
		insurance_policy, insurance_coverage, tax_id, on_time_rate, damage_rate,
		total_shipments, rating, is_active, is_hazmat_certified, notes, created_at, updated_at`

func (r *PgCarrierRepo) Create(ctx context.Context, c *model.Carrier) (uuid.UUID, error) {
	if c.ID == uuid.Nil {
		c.ID = uuid.New()
	}
	if c.CreatedAt.IsZero() {
		c.CreatedAt = time.Now()
	}
	c.UpdatedAt = time.Now()
	q := `INSERT INTO carriers (` + carrierColumns + `) VALUES (
		:id, :name, :code, :contact_name, :email, :phone, :address, :city, :state, :country,
		:service_area, :base_rate, :per_kg_rate, :per_km_rate, :fuel_surcharge_rate,
		:insurance_policy, :insurance_coverage, :tax_id, :on_time_rate, :damage_rate,
		:total_shipments, :rating, :is_active, :is_hazmat_certified, :notes, :created_at, :updated_at)`
	if _, err := r.db.NamedExecContext(ctx, q, c); err != nil {
		return uuid.Nil, fmt.Errorf("insert carrier: %w", err)
	}
	return c.ID, nil
}

func (r *PgCarrierRepo) GetByID(ctx context.Context, id uuid.UUID) (*model.Carrier, error) {
	var c model.Carrier
	q := `SELECT ` + carrierColumns + ` FROM carriers WHERE id = $1`
	if err := r.db.GetContext(ctx, &c, q, id); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, model.ErrNotFound
		}
		return nil, fmt.Errorf("get carrier: %w", err)
	}
	return &c, nil
}

func (r *PgCarrierRepo) GetByCode(ctx context.Context, code string) (*model.Carrier, error) {
	var c model.Carrier
	q := `SELECT ` + carrierColumns + ` FROM carriers WHERE UPPER(code) = UPPER($1)`
	if err := r.db.GetContext(ctx, &c, q, code); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, model.ErrNotFound
		}
		return nil, fmt.Errorf("get carrier by code: %w", err)
	}
	return &c, nil
}

func (r *PgCarrierRepo) Update(ctx context.Context, id uuid.UUID, c *model.Carrier) error {
	c.UpdatedAt = time.Now()
	c.ID = id
	q := `UPDATE carriers SET name = :name, contact_name = :contact_name, phone = :phone,
		address = :address, city = :city, state = :state,
		base_rate = :base_rate, per_kg_rate = :per_kg_rate, per_km_rate = :per_km_rate,
		fuel_surcharge_rate = :fuel_surcharge_rate, insurance_coverage = :insurance_coverage,
		is_hazmat_certified = :is_hazmat_certified, notes = :notes, updated_at = :updated_at
		WHERE id = :id`
	res, err := r.db.NamedExecContext(ctx, q, c)
	if err != nil {
		return fmt.Errorf("update carrier: %w", err)
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return model.ErrNotFound
	}
	return nil
}

func (r *PgCarrierRepo) Delete(ctx context.Context, id uuid.UUID) error {
	q := `DELETE FROM carriers WHERE id = $1`
	res, err := r.db.ExecContext(ctx, q, id)
	if err != nil {
		return fmt.Errorf("delete carrier: %w", err)
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return model.ErrNotFound
	}
	return nil
}

func (r *PgCarrierRepo) List(ctx context.Context, f *model.CarrierFilter) ([]*model.Carrier, int, error) {
	parts := []string{}
	args := []interface{}{}
	idx := 1
	if f != nil {
		if f.SearchTerm != "" {
			parts = append(parts, fmt.Sprintf("(name ILIKE $%d OR code ILIKE $%d)", idx, idx))
			args = append(args, "%"+f.SearchTerm+"%")
			idx++
		}
		if f.City != "" {
			parts = append(parts, fmt.Sprintf("city = $%d", idx))
			args = append(args, f.City)
			idx++
		}
		if f.State != "" {
			parts = append(parts, fmt.Sprintf("state = $%d", idx))
			args = append(args, f.State)
			idx++
		}
		if f.IsActive != nil {
			parts = append(parts, fmt.Sprintf("is_active = $%d", idx))
			args = append(args, *f.IsActive)
			idx++
		}
		if f.IsHazmatCertified != nil {
			parts = append(parts, fmt.Sprintf("is_hazmat_certified = $%d", idx))
			args = append(args, *f.IsHazmatCertified)
			idx++
		}
		if f.MinRating > 0 {
			parts = append(parts, fmt.Sprintf("rating >= $%d", idx))
			args = append(args, f.MinRating)
			idx++
		}
		if f.MinOnTime > 0 {
			parts = append(parts, fmt.Sprintf("on_time_rate >= $%d", idx))
			args = append(args, f.MinOnTime)
			idx++
		}
	}
	where := ""
	if len(parts) > 0 {
		where = "WHERE " + strings.Join(parts, " AND ")
	}
	var total int
	if err := r.db.GetContext(ctx, &total, `SELECT COUNT(*) FROM carriers `+where, args...); err != nil {
		return nil, 0, fmt.Errorf("count carriers: %w", err)
	}
	limit := 25
	offset := 0
	if f != nil {
		limit = f.Limit
		offset = f.Offset
	}
	q := `SELECT ` + carrierColumns + ` FROM carriers ` + where +
		` ORDER BY rating DESC, name ASC LIMIT $` + fmt.Sprint(len(args)+1) + ` OFFSET $` + fmt.Sprint(len(args)+2)
	args = append(args, limit, offset)
	rows := []*model.Carrier{}
	if err := r.db.SelectContext(ctx, &rows, q, args...); err != nil {
		return nil, 0, fmt.Errorf("select carriers: %w", err)
	}
	return rows, total, nil
}

func (r *PgCarrierRepo) UpdateStats(ctx context.Context, id uuid.UUID, onTime, damage float64, total int) error {
	q := `UPDATE carriers SET on_time_rate = $1, damage_rate = $2, total_shipments = $3, updated_at = $4 WHERE id = $5`
	res, err := r.db.ExecContext(ctx, q, onTime, damage, total, time.Now(), id)
	if err != nil {
		return fmt.Errorf("update carrier stats: %w", err)
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return model.ErrNotFound
	}
	return nil
}

func (r *PgCarrierRepo) SetActive(ctx context.Context, id uuid.UUID, active bool) error {
	q := `UPDATE carriers SET is_active = $1, updated_at = $2 WHERE id = $3`
	res, err := r.db.ExecContext(ctx, q, active, time.Now(), id)
	if err != nil {
		return fmt.Errorf("set active: %w", err)
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return model.ErrNotFound
	}
	return nil
}
