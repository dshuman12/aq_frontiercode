package repository

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strings"
	"time"

	"freightline.dev/api/internal/db"
	"freightline.dev/api/internal/model"
	"github.com/google/uuid"
	"github.com/jmoiron/sqlx"
)

type PgInvoiceRepo struct {
	db *db.DB
}

func NewPgInvoiceRepo(d *db.DB) *PgInvoiceRepo {
	return &PgInvoiceRepo{db: d}
}

const invoiceColumns = `id, invoice_number, customer_id, status, issued_date, due_date,
		subtotal, tax_amount, discount_amount, total, amount_paid, balance_due,
		currency, payment_terms, notes, billing_address, created_at, updated_at`

const lineItemColumns = `id, invoice_id, shipment_id, description, quantity, unit_price,
		discount, tax_rate, line_total, created_at`

func (r *PgInvoiceRepo) Create(ctx context.Context, inv *model.Invoice, lines []*model.InvoiceLineItem) (uuid.UUID, error) {
	if inv.ID == uuid.Nil {
		inv.ID = uuid.New()
	}
	if inv.CreatedAt.IsZero() {
		inv.CreatedAt = time.Now()
	}
	inv.UpdatedAt = time.Now()

	err := r.db.WithTx(ctx, func(tx *sqlx.Tx) error {
		q := `INSERT INTO invoices (` + invoiceColumns + `) VALUES (
			:id, :invoice_number, :customer_id, :status, :issued_date, :due_date,
			:subtotal, :tax_amount, :discount_amount, :total, :amount_paid, :balance_due,
			:currency, :payment_terms, :notes, :billing_address, :created_at, :updated_at)`
		if _, err := tx.NamedExecContext(ctx, q, inv); err != nil {
			return fmt.Errorf("insert invoice: %w", err)
		}
		for _, li := range lines {
			if li.ID == uuid.Nil {
				li.ID = uuid.New()
			}
			li.InvoiceID = inv.ID
			if li.CreatedAt.IsZero() {
				li.CreatedAt = time.Now()
			}
			lq := `INSERT INTO invoice_line_items (` + lineItemColumns + `) VALUES (
				:id, :invoice_id, :shipment_id, :description, :quantity, :unit_price,
				:discount, :tax_rate, :line_total, :created_at)`
			if _, err := tx.NamedExecContext(ctx, lq, li); err != nil {
				return fmt.Errorf("insert line: %w", err)
			}
		}
		return nil
	})
	if err != nil {
		return uuid.Nil, err
	}
	return inv.ID, nil
}

func (r *PgInvoiceRepo) GetByID(ctx context.Context, id uuid.UUID) (*model.Invoice, error) {
	var inv model.Invoice
	q := `SELECT ` + invoiceColumns + ` FROM invoices WHERE id = $1`
	if err := r.db.GetContext(ctx, &inv, q, id); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, model.ErrNotFound
		}
		return nil, fmt.Errorf("get invoice: %w", err)
	}
	return &inv, nil
}

func (r *PgInvoiceRepo) GetWithLines(ctx context.Context, id uuid.UUID) (*model.InvoiceWithLines, error) {
	inv, err := r.GetByID(ctx, id)
	if err != nil {
		return nil, err
	}
	lines := []*model.InvoiceLineItem{}
	q := `SELECT ` + lineItemColumns + ` FROM invoice_line_items WHERE invoice_id = $1 ORDER BY created_at ASC`
	if err := r.db.SelectContext(ctx, &lines, q, id); err != nil {
		return nil, fmt.Errorf("select lines: %w", err)
	}
	return &model.InvoiceWithLines{Invoice: inv, LineItems: lines}, nil
}

func (r *PgInvoiceRepo) GetByNumber(ctx context.Context, num string) (*model.Invoice, error) {
	var inv model.Invoice
	q := `SELECT ` + invoiceColumns + ` FROM invoices WHERE invoice_number = $1`
	if err := r.db.GetContext(ctx, &inv, q, num); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, model.ErrNotFound
		}
		return nil, fmt.Errorf("get invoice by num: %w", err)
	}
	return &inv, nil
}

func (r *PgInvoiceRepo) Update(ctx context.Context, id uuid.UUID, inv *model.Invoice) error {
	inv.UpdatedAt = time.Now()
	inv.ID = id
	q := `UPDATE invoices SET due_date = :due_date, notes = :notes, updated_at = :updated_at WHERE id = :id`
	res, err := r.db.NamedExecContext(ctx, q, inv)
	if err != nil {
		return fmt.Errorf("update invoice: %w", err)
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return model.ErrNotFound
	}
	return nil
}

func (r *PgInvoiceRepo) Delete(ctx context.Context, id uuid.UUID) error {
	return r.db.WithTx(ctx, func(tx *sqlx.Tx) error {
		if _, err := tx.ExecContext(ctx, `DELETE FROM invoice_line_items WHERE invoice_id = $1`, id); err != nil {
			return fmt.Errorf("del lines: %w", err)
		}
		res, err := tx.ExecContext(ctx, `DELETE FROM invoices WHERE id = $1`, id)
		if err != nil {
			return fmt.Errorf("del invoice: %w", err)
		}
		n, _ := res.RowsAffected()
		if n == 0 {
			return model.ErrNotFound
		}
		return nil
	})
}

func (r *PgInvoiceRepo) List(ctx context.Context, f *model.InvoiceFilter) ([]*model.Invoice, int, error) {
	parts := []string{}
	args := []interface{}{}
	idx := 1
	if f != nil {
		if f.SearchTerm != "" {
			parts = append(parts, fmt.Sprintf("invoice_number ILIKE $%d", idx))
			args = append(args, "%"+f.SearchTerm+"%")
			idx++
		}
		if f.CustomerID != nil {
			parts = append(parts, fmt.Sprintf("customer_id = $%d", idx))
			args = append(args, *f.CustomerID)
			idx++
		}
		if f.Status != "" {
			parts = append(parts, fmt.Sprintf("status = $%d", idx))
			args = append(args, f.Status)
			idx++
		}
		if f.IsOverdue != nil && *f.IsOverdue {
			parts = append(parts, fmt.Sprintf("due_date < $%d AND status NOT IN ('paid','voided')", idx))
			args = append(args, time.Now())
			idx++
		}
		if !f.FromDate.IsZero() {
			parts = append(parts, fmt.Sprintf("issued_date >= $%d", idx))
			args = append(args, f.FromDate)
			idx++
		}
		if !f.ToDate.IsZero() {
			parts = append(parts, fmt.Sprintf("issued_date <= $%d", idx))
			args = append(args, f.ToDate)
			idx++
		}
		if f.MinTotal > 0 {
			parts = append(parts, fmt.Sprintf("total >= $%d", idx))
			args = append(args, f.MinTotal)
			idx++
		}
		if f.MaxTotal > 0 {
			parts = append(parts, fmt.Sprintf("total <= $%d", idx))
			args = append(args, f.MaxTotal)
			idx++
		}
	}
	where := ""
	if len(parts) > 0 {
		where = "WHERE " + strings.Join(parts, " AND ")
	}
	var total int
	if err := r.db.GetContext(ctx, &total, `SELECT COUNT(*) FROM invoices `+where, args...); err != nil {
		return nil, 0, fmt.Errorf("count invoices: %w", err)
	}
	limit := 25
	offset := 0
	if f != nil {
		limit = f.Limit
		offset = f.Offset
	}
	q := `SELECT ` + invoiceColumns + ` FROM invoices ` + where +
		` ORDER BY issued_date DESC LIMIT $` + fmt.Sprint(len(args)+1) + ` OFFSET $` + fmt.Sprint(len(args)+2)
	args = append(args, limit, offset)
	rows := []*model.Invoice{}
	if err := r.db.SelectContext(ctx, &rows, q, args...); err != nil {
		return nil, 0, fmt.Errorf("select invoices: %w", err)
	}
	return rows, total, nil
}

func (r *PgInvoiceRepo) UpdateStatus(ctx context.Context, id uuid.UUID, status model.InvoiceStatus) error {
	q := `UPDATE invoices SET status = $1, updated_at = $2 WHERE id = $3`
	res, err := r.db.ExecContext(ctx, q, status, time.Now(), id)
	if err != nil {
		return fmt.Errorf("update invoice status: %w", err)
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return model.ErrNotFound
	}
	return nil
}

func (r *PgInvoiceRepo) ApplyPayment(ctx context.Context, id uuid.UUID, amount float64) error {
	q := `UPDATE invoices SET amount_paid = amount_paid + $1,
			balance_due = GREATEST(total - (amount_paid + $1), 0),
			updated_at = $2 WHERE id = $3`
	res, err := r.db.ExecContext(ctx, q, amount, time.Now(), id)
	if err != nil {
		return fmt.Errorf("apply payment: %w", err)
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return model.ErrNotFound
	}
	return nil
}

func (r *PgInvoiceRepo) ListByCustomer(ctx context.Context, customerID uuid.UUID, limit int) ([]*model.Invoice, error) {
	if limit <= 0 {
		limit = 50
	}
	q := `SELECT ` + invoiceColumns + ` FROM invoices WHERE customer_id = $1 ORDER BY issued_date DESC LIMIT $2`
	rows := []*model.Invoice{}
	if err := r.db.SelectContext(ctx, &rows, q, customerID, limit); err != nil {
		return nil, fmt.Errorf("list by customer: %w", err)
	}
	return rows, nil
}

func (r *PgInvoiceRepo) ListOverdue(ctx context.Context) ([]*model.Invoice, error) {
	q := `SELECT ` + invoiceColumns + ` FROM invoices
		WHERE due_date < $1 AND status NOT IN ('paid','voided')
		ORDER BY due_date ASC LIMIT 500`
	rows := []*model.Invoice{}
	if err := r.db.SelectContext(ctx, &rows, q, time.Now()); err != nil {
		return nil, fmt.Errorf("list overdue: %w", err)
	}
	return rows, nil
}

func (r *PgInvoiceRepo) SumOutstanding(ctx context.Context) (float64, error) {
	var sum sql.NullFloat64
	if err := r.db.GetContext(ctx, &sum,
		`SELECT SUM(balance_due) FROM invoices WHERE status NOT IN ('paid','voided')`); err != nil {
		return 0, fmt.Errorf("sum outstanding: %w", err)
	}
	if !sum.Valid {
		return 0, nil
	}
	return sum.Float64, nil
}
