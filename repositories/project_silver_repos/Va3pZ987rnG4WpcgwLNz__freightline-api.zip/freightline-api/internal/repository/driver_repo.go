package repository

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strings"
	"time"

	"freightline.dev/api/internal/db"
	"freightline.dev/api/internal/model"
	"github.com/google/uuid"
)

type PgDriverRepo struct {
	db *db.DB
}

func NewPgDriverRepo(d *db.DB) *PgDriverRepo {
	return &PgDriverRepo{db: d}
}

const driverColumns = `id, employee_code, first_name, last_name, email, phone,
		license_number, license_class, license_expiry, hire_date, date_of_birth,
		status, hourly_rate, per_mile_rate, home_address, home_city, home_state,
		emergency_contact, emergency_phone, total_miles_driven, total_deliveries,
		incident_count, created_at, updated_at`

func (r *PgDriverRepo) Create(ctx context.Context, d *model.Driver) (uuid.UUID, error) {
	if d.ID == uuid.Nil {
		d.ID = uuid.New()
	}
	if d.CreatedAt.IsZero() {
		d.CreatedAt = time.Now()
	}
	d.UpdatedAt = time.Now()

	q := `INSERT INTO drivers (` + driverColumns + `) VALUES (
		:id, :employee_code, :first_name, :last_name, :email, :phone,
		:license_number, :license_class, :license_expiry, :hire_date, :date_of_birth,
		:status, :hourly_rate, :per_mile_rate, :home_address, :home_city, :home_state,
		:emergency_contact, :emergency_phone, :total_miles_driven, :total_deliveries,
		:incident_count, :created_at, :updated_at)`

	_, err := r.db.NamedExecContext(ctx, q, d)
	if err != nil {
		return uuid.Nil, fmt.Errorf("insert driver: %w", err)
	}
	return d.ID, nil
}

func (r *PgDriverRepo) GetByID(ctx context.Context, id uuid.UUID) (*model.Driver, error) {
	var d model.Driver
	q := `SELECT ` + driverColumns + ` FROM drivers WHERE id = $1`
	if err := r.db.GetContext(ctx, &d, q, id); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, model.ErrNotFound
		}
		return nil, fmt.Errorf("get driver: %w", err)
	}
	return &d, nil
}

func (r *PgDriverRepo) GetByEmployeeCode(ctx context.Context, code string) (*model.Driver, error) {
	var d model.Driver
	q := `SELECT ` + driverColumns + ` FROM drivers WHERE employee_code = $1`
	if err := r.db.GetContext(ctx, &d, q, code); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, model.ErrNotFound
		}
		return nil, fmt.Errorf("get driver by code: %w", err)
	}
	return &d, nil
}

func (r *PgDriverRepo) GetByEmail(ctx context.Context, email string) (*model.Driver, error) {
	var d model.Driver
	q := `SELECT ` + driverColumns + ` FROM drivers WHERE LOWER(email) = LOWER($1)`
	if err := r.db.GetContext(ctx, &d, q, email); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, model.ErrNotFound
		}
		return nil, fmt.Errorf("get driver by email: %w", err)
	}
	return &d, nil
}

func (r *PgDriverRepo) Update(ctx context.Context, id uuid.UUID, d *model.Driver) error {
	d.UpdatedAt = time.Now()
	d.ID = id
	q := `UPDATE drivers SET
		first_name = :first_name, last_name = :last_name, phone = :phone,
		license_expiry = :license_expiry, license_class = :license_class,
		hourly_rate = :hourly_rate, per_mile_rate = :per_mile_rate,
		home_address = :home_address, home_city = :home_city, home_state = :home_state,
		emergency_contact = :emergency_contact, emergency_phone = :emergency_phone,
		updated_at = :updated_at WHERE id = :id`
	res, err := r.db.NamedExecContext(ctx, q, d)
	if err != nil {
		return fmt.Errorf("update driver: %w", err)
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return model.ErrNotFound
	}
	return nil
}

func (r *PgDriverRepo) Delete(ctx context.Context, id uuid.UUID) error {
	q := `DELETE FROM drivers WHERE id = $1`
	res, err := r.db.ExecContext(ctx, q, id)
	if err != nil {
		return fmt.Errorf("delete driver: %w", err)
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return model.ErrNotFound
	}
	return nil
}

func (r *PgDriverRepo) List(ctx context.Context, f *model.DriverFilter) ([]*model.Driver, int, error) {
	where, args := r.buildFilter(f)
	var total int
	if err := r.db.GetContext(ctx, &total, `SELECT COUNT(*) FROM drivers `+where, args...); err != nil {
		return nil, 0, fmt.Errorf("count drivers: %w", err)
	}
	q := `SELECT ` + driverColumns + ` FROM drivers ` + where +
		` ORDER BY created_at DESC LIMIT $` + fmt.Sprint(len(args)+1) + ` OFFSET $` + fmt.Sprint(len(args)+2)
	args = append(args, f.Limit, f.Offset)
	rows := []*model.Driver{}
	if err := r.db.SelectContext(ctx, &rows, q, args...); err != nil {
		return nil, 0, fmt.Errorf("select drivers: %w", err)
	}
	return rows, total, nil
}

func (r *PgDriverRepo) buildFilter(f *model.DriverFilter) (string, []interface{}) {
	if f == nil {
		return "", nil
	}
	parts := []string{}
	args := []interface{}{}
	idx := 1
	if f.SearchTerm != "" {
		parts = append(parts, fmt.Sprintf("(first_name ILIKE $%d OR last_name ILIKE $%d OR employee_code ILIKE $%d)", idx, idx, idx))
		args = append(args, "%"+f.SearchTerm+"%")
		idx++
	}
	if f.LicenseClass != "" {
		parts = append(parts, fmt.Sprintf("license_class = $%d", idx))
		args = append(args, f.LicenseClass)
		idx++
	}
	if f.Status != "" {
		parts = append(parts, fmt.Sprintf("status = $%d", idx))
		args = append(args, f.Status)
		idx++
	}
	if f.HomeState != "" {
		parts = append(parts, fmt.Sprintf("home_state = $%d", idx))
		args = append(args, f.HomeState)
		idx++
	}
	if !f.FromDate.IsZero() {
		parts = append(parts, fmt.Sprintf("hire_date >= $%d", idx))
		args = append(args, f.FromDate)
		idx++
	}
	if !f.ToDate.IsZero() {
		parts = append(parts, fmt.Sprintf("hire_date <= $%d", idx))
		args = append(args, f.ToDate)
		idx++
	}
	if len(parts) == 0 {
		return "", args
	}
	return "WHERE " + strings.Join(parts, " AND "), args
}

func (r *PgDriverRepo) UpdateStatus(ctx context.Context, id uuid.UUID, status model.DriverStatus) error {
	q := `UPDATE drivers SET status = $1, updated_at = $2 WHERE id = $3`
	res, err := r.db.ExecContext(ctx, q, status, time.Now(), id)
	if err != nil {
		return fmt.Errorf("update driver status: %w", err)
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return model.ErrNotFound
	}
	return nil
}

func (r *PgDriverRepo) IncrementDeliveries(ctx context.Context, id uuid.UUID, miles float64) error {
	q := `UPDATE drivers SET
			total_deliveries = total_deliveries + 1,
			total_miles_driven = total_miles_driven + $1,
			updated_at = $2 WHERE id = $3`
	res, err := r.db.ExecContext(ctx, q, miles, time.Now(), id)
	if err != nil {
		return fmt.Errorf("inc deliveries: %w", err)
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return model.ErrNotFound
	}
	return nil
}

func (r *PgDriverRepo) ListAvailable(ctx context.Context) ([]*model.Driver, error) {
	q := `SELECT ` + driverColumns + ` FROM drivers WHERE status = $1 AND license_expiry > $2 ORDER BY total_deliveries ASC LIMIT 200`
	rows := []*model.Driver{}
	if err := r.db.SelectContext(ctx, &rows, q, model.DriverStatusActive, time.Now()); err != nil {
		return nil, fmt.Errorf("list available drivers: %w", err)
	}
	return rows, nil
}

func (r *PgDriverRepo) ListExpiringLicenses(ctx context.Context, days int) ([]*model.Driver, error) {
	cutoff := time.Now().AddDate(0, 0, days)
	q := `SELECT ` + driverColumns + ` FROM drivers WHERE license_expiry <= $1 ORDER BY license_expiry ASC`
	rows := []*model.Driver{}
	if err := r.db.SelectContext(ctx, &rows, q, cutoff); err != nil {
		return nil, fmt.Errorf("list expiring: %w", err)
	}
	return rows, nil
}
