package repository

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strings"
	"time"

	"freightline.dev/api/internal/db"
	"freightline.dev/api/internal/model"
	"github.com/google/uuid"
)

type PgTrackingRepo struct {
	db *db.DB
}

func NewPgTrackingRepo(d *db.DB) *PgTrackingRepo {
	return &PgTrackingRepo{db: d}
}

const trackingColumns = `id, shipment_id, event_type, status, description, location,
		city, state, country, latitude, longitude, actor_id, driver_id, vehicle_id,
		warehouse_id, occurred_at, created_at`

func (r *PgTrackingRepo) Create(ctx context.Context, e *model.TrackingEvent) (uuid.UUID, error) {
	if e.ID == uuid.Nil {
		e.ID = uuid.New()
	}
	if e.CreatedAt.IsZero() {
		e.CreatedAt = time.Now()
	}
	if e.OccurredAt.IsZero() {
		e.OccurredAt = time.Now()
	}
	q := `INSERT INTO tracking_events (` + trackingColumns + `) VALUES (
		:id, :shipment_id, :event_type, :status, :description, :location,
		:city, :state, :country, :latitude, :longitude, :actor_id, :driver_id, :vehicle_id,
		:warehouse_id, :occurred_at, :created_at)`
	_, err := r.db.NamedExecContext(ctx, q, e)
	if err != nil {
		return uuid.Nil, fmt.Errorf("insert event: %w", err)
	}
	return e.ID, nil
}

func (r *PgTrackingRepo) GetByID(ctx context.Context, id uuid.UUID) (*model.TrackingEvent, error) {
	var e model.TrackingEvent
	q := `SELECT ` + trackingColumns + ` FROM tracking_events WHERE id = $1`
	if err := r.db.GetContext(ctx, &e, q, id); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, model.ErrNotFound
		}
		return nil, fmt.Errorf("get event: %w", err)
	}
	return &e, nil
}

func (r *PgTrackingRepo) ListByShipment(ctx context.Context, shipmentID uuid.UUID) ([]*model.TrackingEvent, error) {
	q := `SELECT ` + trackingColumns + ` FROM tracking_events WHERE shipment_id = $1 ORDER BY occurred_at ASC`
	rows := []*model.TrackingEvent{}
	if err := r.db.SelectContext(ctx, &rows, q, shipmentID); err != nil {
		return nil, fmt.Errorf("list events: %w", err)
	}
	return rows, nil
}

func (r *PgTrackingRepo) List(ctx context.Context, f *model.TrackingEventFilter) ([]*model.TrackingEvent, int, error) {
	parts := []string{}
	args := []interface{}{}
	idx := 1
	if f != nil {
		if f.ShipmentID != nil {
			parts = append(parts, fmt.Sprintf("shipment_id = $%d", idx))
			args = append(args, *f.ShipmentID)
			idx++
		}
		if f.EventType != "" {
			parts = append(parts, fmt.Sprintf("event_type = $%d", idx))
			args = append(args, f.EventType)
			idx++
		}
		if f.DriverID != nil {
			parts = append(parts, fmt.Sprintf("driver_id = $%d", idx))
			args = append(args, *f.DriverID)
			idx++
		}
		if f.VehicleID != nil {
			parts = append(parts, fmt.Sprintf("vehicle_id = $%d", idx))
			args = append(args, *f.VehicleID)
			idx++
		}
		if !f.FromDate.IsZero() {
			parts = append(parts, fmt.Sprintf("occurred_at >= $%d", idx))
			args = append(args, f.FromDate)
			idx++
		}
		if !f.ToDate.IsZero() {
			parts = append(parts, fmt.Sprintf("occurred_at <= $%d", idx))
			args = append(args, f.ToDate)
			idx++
		}
	}
	where := ""
	if len(parts) > 0 {
		where = "WHERE " + strings.Join(parts, " AND ")
	}
	var total int
	if err := r.db.GetContext(ctx, &total, `SELECT COUNT(*) FROM tracking_events `+where, args...); err != nil {
		return nil, 0, fmt.Errorf("count events: %w", err)
	}
	limit := 50
	offset := 0
	if f != nil {
		limit = f.Limit
		offset = f.Offset
	}
	q := `SELECT ` + trackingColumns + ` FROM tracking_events ` + where +
		` ORDER BY occurred_at DESC LIMIT $` + fmt.Sprint(len(args)+1) + ` OFFSET $` + fmt.Sprint(len(args)+2)
	args = append(args, limit, offset)
	rows := []*model.TrackingEvent{}
	if err := r.db.SelectContext(ctx, &rows, q, args...); err != nil {
		return nil, 0, fmt.Errorf("select events: %w", err)
	}
	return rows, total, nil
}

func (r *PgTrackingRepo) GetLatestForShipment(ctx context.Context, shipmentID uuid.UUID) (*model.TrackingEvent, error) {
	var e model.TrackingEvent
	q := `SELECT ` + trackingColumns + ` FROM tracking_events WHERE shipment_id = $1 ORDER BY occurred_at DESC LIMIT 1`
	if err := r.db.GetContext(ctx, &e, q, shipmentID); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, model.ErrNotFound
		}
		return nil, fmt.Errorf("get latest event: %w", err)
	}
	return &e, nil
}
