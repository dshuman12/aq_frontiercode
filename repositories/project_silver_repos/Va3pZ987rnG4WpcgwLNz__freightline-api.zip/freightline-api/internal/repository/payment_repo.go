package repository

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strings"
	"time"

	"freightline.dev/api/internal/db"
	"freightline.dev/api/internal/model"
	"github.com/google/uuid"
)

type PgPaymentRepo struct {
	db *db.DB
}

func NewPgPaymentRepo(d *db.DB) *PgPaymentRepo {
	return &PgPaymentRepo{db: d}
}

const paymentColumns = `id, reference_no, invoice_id, customer_id, method, status,
		amount, currency, payment_date, cleared_date, processor_ref, bank_reference,
		notes, created_at, updated_at`

func (r *PgPaymentRepo) Create(ctx context.Context, p *model.Payment) (uuid.UUID, error) {
	if p.ID == uuid.Nil {
		p.ID = uuid.New()
	}
	if p.CreatedAt.IsZero() {
		p.CreatedAt = time.Now()
	}
	p.UpdatedAt = time.Now()
	q := `INSERT INTO payments (` + paymentColumns + `) VALUES (
		:id, :reference_no, :invoice_id, :customer_id, :method, :status,
		:amount, :currency, :payment_date, :cleared_date, :processor_ref, :bank_reference,
		:notes, :created_at, :updated_at)`
	if _, err := r.db.NamedExecContext(ctx, q, p); err != nil {
		return uuid.Nil, fmt.Errorf("insert payment: %w", err)
	}
	return p.ID, nil
}

func (r *PgPaymentRepo) GetByID(ctx context.Context, id uuid.UUID) (*model.Payment, error) {
	var p model.Payment
	q := `SELECT ` + paymentColumns + ` FROM payments WHERE id = $1`
	if err := r.db.GetContext(ctx, &p, q, id); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, model.ErrNotFound
		}
		return nil, fmt.Errorf("get payment: %w", err)
	}
	return &p, nil
}

func (r *PgPaymentRepo) GetByReference(ctx context.Context, ref string) (*model.Payment, error) {
	var p model.Payment
	q := `SELECT ` + paymentColumns + ` FROM payments WHERE reference_no = $1`
	if err := r.db.GetContext(ctx, &p, q, ref); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, model.ErrNotFound
		}
		return nil, fmt.Errorf("get payment by ref: %w", err)
	}
	return &p, nil
}

func (r *PgPaymentRepo) Update(ctx context.Context, id uuid.UUID, p *model.Payment) error {
	p.UpdatedAt = time.Now()
	p.ID = id
	q := `UPDATE payments SET notes = :notes, processor_ref = :processor_ref,
		bank_reference = :bank_reference, updated_at = :updated_at WHERE id = :id`
	res, err := r.db.NamedExecContext(ctx, q, p)
	if err != nil {
		return fmt.Errorf("update payment: %w", err)
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return model.ErrNotFound
	}
	return nil
}

func (r *PgPaymentRepo) UpdateStatus(ctx context.Context, id uuid.UUID, status model.PaymentStatus) error {
	var clearedDate interface{}
	if status == model.PaymentStatusCleared {
		clearedDate = time.Now()
	}
	q := `UPDATE payments SET status = $1, cleared_date = $2, updated_at = $3 WHERE id = $4`
	res, err := r.db.ExecContext(ctx, q, status, clearedDate, time.Now(), id)
	if err != nil {
		return fmt.Errorf("update payment status: %w", err)
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return model.ErrNotFound
	}
	return nil
}

func (r *PgPaymentRepo) List(ctx context.Context, f *model.PaymentFilter) ([]*model.Payment, int, error) {
	parts := []string{}
	args := []interface{}{}
	idx := 1
	if f != nil {
		if f.CustomerID != nil {
			parts = append(parts, fmt.Sprintf("customer_id = $%d", idx))
			args = append(args, *f.CustomerID)
			idx++
		}
		if f.InvoiceID != nil {
			parts = append(parts, fmt.Sprintf("invoice_id = $%d", idx))
			args = append(args, *f.InvoiceID)
			idx++
		}
		if f.Method != "" {
			parts = append(parts, fmt.Sprintf("method = $%d", idx))
			args = append(args, f.Method)
			idx++
		}
		if f.Status != "" {
			parts = append(parts, fmt.Sprintf("status = $%d", idx))
			args = append(args, f.Status)
			idx++
		}
		if !f.FromDate.IsZero() {
			parts = append(parts, fmt.Sprintf("payment_date >= $%d", idx))
			args = append(args, f.FromDate)
			idx++
		}
		if !f.ToDate.IsZero() {
			parts = append(parts, fmt.Sprintf("payment_date <= $%d", idx))
			args = append(args, f.ToDate)
			idx++
		}
		if f.MinAmount > 0 {
			parts = append(parts, fmt.Sprintf("amount >= $%d", idx))
			args = append(args, f.MinAmount)
			idx++
		}
		if f.MaxAmount > 0 {
			parts = append(parts, fmt.Sprintf("amount <= $%d", idx))
			args = append(args, f.MaxAmount)
			idx++
		}
	}
	where := ""
	if len(parts) > 0 {
		where = "WHERE " + strings.Join(parts, " AND ")
	}
	var total int
	if err := r.db.GetContext(ctx, &total, `SELECT COUNT(*) FROM payments `+where, args...); err != nil {
		return nil, 0, fmt.Errorf("count payments: %w", err)
	}
	limit := 25
	offset := 0
	if f != nil {
		limit = f.Limit
		offset = f.Offset
	}
	q := `SELECT ` + paymentColumns + ` FROM payments ` + where +
		` ORDER BY payment_date DESC LIMIT $` + fmt.Sprint(len(args)+1) + ` OFFSET $` + fmt.Sprint(len(args)+2)
	args = append(args, limit, offset)
	rows := []*model.Payment{}
	if err := r.db.SelectContext(ctx, &rows, q, args...); err != nil {
		return nil, 0, fmt.Errorf("select payments: %w", err)
	}
	return rows, total, nil
}

func (r *PgPaymentRepo) ListByInvoice(ctx context.Context, invoiceID uuid.UUID) ([]*model.Payment, error) {
	q := `SELECT ` + paymentColumns + ` FROM payments WHERE invoice_id = $1 ORDER BY payment_date DESC`
	rows := []*model.Payment{}
	if err := r.db.SelectContext(ctx, &rows, q, invoiceID); err != nil {
		return nil, fmt.Errorf("list by invoice: %w", err)
	}
	return rows, nil
}

func (r *PgPaymentRepo) SumForInvoice(ctx context.Context, invoiceID uuid.UUID) (float64, error) {
	var sum sql.NullFloat64
	if err := r.db.GetContext(ctx, &sum,
		`SELECT SUM(amount) FROM payments WHERE invoice_id = $1 AND status = 'cleared'`, invoiceID); err != nil {
		return 0, fmt.Errorf("sum payments: %w", err)
	}
	if !sum.Valid {
		return 0, nil
	}
	return sum.Float64, nil
}
