package repository

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strings"
	"time"

	"freightline.dev/api/internal/db"
	"freightline.dev/api/internal/model"
	"github.com/google/uuid"
)

type PgVehicleRepo struct {
	db *db.DB
}

func NewPgVehicleRepo(d *db.DB) *PgVehicleRepo {
	return &PgVehicleRepo{db: d}
}

const vehicleColumns = `id, plate_number, vin, make, model, year, type, fuel_type,
		capacity_kg, capacity_m3, odometer_km, fuel_efficiency, status,
		insurance_provider, insurance_policy, insurance_expiry, registration_expiry,
		last_service_date, next_service_date, next_service_km, home_warehouse_id,
		purchase_date, purchase_price, current_value, is_refrigerated,
		created_at, updated_at`

func (r *PgVehicleRepo) Create(ctx context.Context, v *model.Vehicle) (uuid.UUID, error) {
	if v.ID == uuid.Nil {
		v.ID = uuid.New()
	}
	if v.CreatedAt.IsZero() {
		v.CreatedAt = time.Now()
	}
	v.UpdatedAt = time.Now()

	q := `INSERT INTO vehicles (` + vehicleColumns + `) VALUES (
		:id, :plate_number, :vin, :make, :model, :year, :type, :fuel_type,
		:capacity_kg, :capacity_m3, :odometer_km, :fuel_efficiency, :status,
		:insurance_provider, :insurance_policy, :insurance_expiry, :registration_expiry,
		:last_service_date, :next_service_date, :next_service_km, :home_warehouse_id,
		:purchase_date, :purchase_price, :current_value, :is_refrigerated,
		:created_at, :updated_at)`
	_, err := r.db.NamedExecContext(ctx, q, v)
	if err != nil {
		return uuid.Nil, fmt.Errorf("insert vehicle: %w", err)
	}
	return v.ID, nil
}

func (r *PgVehicleRepo) GetByID(ctx context.Context, id uuid.UUID) (*model.Vehicle, error) {
	var v model.Vehicle
	q := `SELECT ` + vehicleColumns + ` FROM vehicles WHERE id = $1`
	if err := r.db.GetContext(ctx, &v, q, id); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, model.ErrNotFound
		}
		return nil, fmt.Errorf("get vehicle: %w", err)
	}
	return &v, nil
}

func (r *PgVehicleRepo) GetByPlate(ctx context.Context, plate string) (*model.Vehicle, error) {
	var v model.Vehicle
	q := `SELECT ` + vehicleColumns + ` FROM vehicles WHERE UPPER(plate_number) = UPPER($1)`
	if err := r.db.GetContext(ctx, &v, q, plate); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, model.ErrNotFound
		}
		return nil, fmt.Errorf("get vehicle by plate: %w", err)
	}
	return &v, nil
}

func (r *PgVehicleRepo) GetByVIN(ctx context.Context, vin string) (*model.Vehicle, error) {
	var v model.Vehicle
	q := `SELECT ` + vehicleColumns + ` FROM vehicles WHERE UPPER(vin) = UPPER($1)`
	if err := r.db.GetContext(ctx, &v, q, vin); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, model.ErrNotFound
		}
		return nil, fmt.Errorf("get vehicle by vin: %w", err)
	}
	return &v, nil
}

func (r *PgVehicleRepo) Update(ctx context.Context, id uuid.UUID, v *model.Vehicle) error {
	v.UpdatedAt = time.Now()
	v.ID = id
	q := `UPDATE vehicles SET
		odometer_km = :odometer_km, fuel_efficiency = :fuel_efficiency,
		insurance_provider = :insurance_provider, insurance_policy = :insurance_policy,
		insurance_expiry = :insurance_expiry, registration_expiry = :registration_expiry,
		last_service_date = :last_service_date, next_service_date = :next_service_date,
		next_service_km = :next_service_km, home_warehouse_id = :home_warehouse_id,
		current_value = :current_value, updated_at = :updated_at
		WHERE id = :id`
	res, err := r.db.NamedExecContext(ctx, q, v)
	if err != nil {
		return fmt.Errorf("update vehicle: %w", err)
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return model.ErrNotFound
	}
	return nil
}

func (r *PgVehicleRepo) Delete(ctx context.Context, id uuid.UUID) error {
	q := `DELETE FROM vehicles WHERE id = $1`
	res, err := r.db.ExecContext(ctx, q, id)
	if err != nil {
		return fmt.Errorf("delete vehicle: %w", err)
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return model.ErrNotFound
	}
	return nil
}

func (r *PgVehicleRepo) List(ctx context.Context, f *model.VehicleFilter) ([]*model.Vehicle, int, error) {
	where, args := r.buildFilter(f)
	var total int
	if err := r.db.GetContext(ctx, &total, `SELECT COUNT(*) FROM vehicles `+where, args...); err != nil {
		return nil, 0, fmt.Errorf("count vehicles: %w", err)
	}
	q := `SELECT ` + vehicleColumns + ` FROM vehicles ` + where +
		` ORDER BY created_at DESC LIMIT $` + fmt.Sprint(len(args)+1) + ` OFFSET $` + fmt.Sprint(len(args)+2)
	args = append(args, f.Limit, f.Offset)
	rows := []*model.Vehicle{}
	if err := r.db.SelectContext(ctx, &rows, q, args...); err != nil {
		return nil, 0, fmt.Errorf("select vehicles: %w", err)
	}
	return rows, total, nil
}

func (r *PgVehicleRepo) buildFilter(f *model.VehicleFilter) (string, []interface{}) {
	if f == nil {
		return "", nil
	}
	parts := []string{}
	args := []interface{}{}
	idx := 1
	if f.SearchTerm != "" {
		parts = append(parts, fmt.Sprintf("(plate_number ILIKE $%d OR vin ILIKE $%d OR make ILIKE $%d OR model ILIKE $%d)", idx, idx, idx, idx))
		args = append(args, "%"+f.SearchTerm+"%")
		idx++
	}
	if f.Type != "" {
		parts = append(parts, fmt.Sprintf("type = $%d", idx))
		args = append(args, f.Type)
		idx++
	}
	if f.Status != "" {
		parts = append(parts, fmt.Sprintf("status = $%d", idx))
		args = append(args, f.Status)
		idx++
	}
	if f.FuelType != "" {
		parts = append(parts, fmt.Sprintf("fuel_type = $%d", idx))
		args = append(args, f.FuelType)
		idx++
	}
	if f.HomeWarehouseID != nil {
		parts = append(parts, fmt.Sprintf("home_warehouse_id = $%d", idx))
		args = append(args, *f.HomeWarehouseID)
		idx++
	}
	if f.MinCapacityKg > 0 {
		parts = append(parts, fmt.Sprintf("capacity_kg >= $%d", idx))
		args = append(args, f.MinCapacityKg)
		idx++
	}
	if f.MaxCapacityKg > 0 {
		parts = append(parts, fmt.Sprintf("capacity_kg <= $%d", idx))
		args = append(args, f.MaxCapacityKg)
		idx++
	}
	if f.IsRefrigerated != nil {
		parts = append(parts, fmt.Sprintf("is_refrigerated = $%d", idx))
		args = append(args, *f.IsRefrigerated)
		idx++
	}
	if len(parts) == 0 {
		return "", args
	}
	return "WHERE " + strings.Join(parts, " AND "), args
}

func (r *PgVehicleRepo) UpdateStatus(ctx context.Context, id uuid.UUID, status model.VehicleStatus) error {
	q := `UPDATE vehicles SET status = $1, updated_at = $2 WHERE id = $3`
	res, err := r.db.ExecContext(ctx, q, status, time.Now(), id)
	if err != nil {
		return fmt.Errorf("update vehicle status: %w", err)
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return model.ErrNotFound
	}
	return nil
}

func (r *PgVehicleRepo) UpdateOdometer(ctx context.Context, id uuid.UUID, km float64) error {
	q := `UPDATE vehicles SET odometer_km = $1, updated_at = $2 WHERE id = $3`
	res, err := r.db.ExecContext(ctx, q, km, time.Now(), id)
	if err != nil {
		return fmt.Errorf("update odometer: %w", err)
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return model.ErrNotFound
	}
	return nil
}

func (r *PgVehicleRepo) ListAvailable(ctx context.Context) ([]*model.Vehicle, error) {
	q := `SELECT ` + vehicleColumns + ` FROM vehicles WHERE status = $1 ORDER BY odometer_km ASC LIMIT 200`
	rows := []*model.Vehicle{}
	if err := r.db.SelectContext(ctx, &rows, q, model.VehicleStatusAvailable); err != nil {
		return nil, fmt.Errorf("list available vehicles: %w", err)
	}
	return rows, nil
}

func (r *PgVehicleRepo) ListNeedingService(ctx context.Context) ([]*model.Vehicle, error) {
	q := `SELECT ` + vehicleColumns + ` FROM vehicles WHERE
		(next_service_date IS NOT NULL AND next_service_date <= $1)
		OR (next_service_km > 0 AND odometer_km >= next_service_km)
		ORDER BY next_service_date ASC`
	rows := []*model.Vehicle{}
	if err := r.db.SelectContext(ctx, &rows, q, time.Now()); err != nil {
		return nil, fmt.Errorf("list needing service: %w", err)
	}
	return rows, nil
}
