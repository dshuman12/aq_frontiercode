package repository

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strings"
	"time"

	"freightline.dev/api/internal/db"
	"freightline.dev/api/internal/model"
	"github.com/google/uuid"
	"github.com/jmoiron/sqlx"
)

type PgCustomerRepo struct {
	db *db.DB
}

func NewPgCustomerRepo(d *db.DB) *PgCustomerRepo {
	return &PgCustomerRepo{db: d}
}

const customerColumns = `id, company_name, contact_name, email, phone, type, tax_id,
		billing_address, billing_city, billing_state, billing_zip, billing_country,
		credit_limit, outstanding_bal, payment_terms, is_active, notes,
		created_at, updated_at`

func (r *PgCustomerRepo) Create(ctx context.Context, c *model.Customer) (uuid.UUID, error) {
	if c.ID == uuid.Nil {
		c.ID = uuid.New()
	}
	if c.CreatedAt.IsZero() {
		c.CreatedAt = time.Now()
	}
	c.UpdatedAt = time.Now()

	q := `INSERT INTO customers (` + customerColumns + `)
		VALUES (:id, :company_name, :contact_name, :email, :phone, :type, :tax_id,
		:billing_address, :billing_city, :billing_state, :billing_zip, :billing_country,
		:credit_limit, :outstanding_bal, :payment_terms, :is_active, :notes,
		:created_at, :updated_at)`

	_, err := r.db.NamedExecContext(ctx, q, c)
	if err != nil {
		return uuid.Nil, fmt.Errorf("insert customer: %w", err)
	}
	return c.ID, nil
}

func (r *PgCustomerRepo) GetByID(ctx context.Context, id uuid.UUID) (*model.Customer, error) {
	var c model.Customer
	q := `SELECT ` + customerColumns + ` FROM customers WHERE id = $1`
	if err := r.db.GetContext(ctx, &c, q, id); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, model.ErrNotFound
		}
		return nil, fmt.Errorf("get customer: %w", err)
	}
	return &c, nil
}

func (r *PgCustomerRepo) GetByEmail(ctx context.Context, email string) (*model.Customer, error) {
	var c model.Customer
	q := `SELECT ` + customerColumns + ` FROM customers WHERE LOWER(email) = LOWER($1)`
	if err := r.db.GetContext(ctx, &c, q, email); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, model.ErrNotFound
		}
		return nil, fmt.Errorf("get customer by email: %w", err)
	}
	return &c, nil
}

func (r *PgCustomerRepo) Update(ctx context.Context, id uuid.UUID, c *model.Customer) error {
	c.UpdatedAt = time.Now()
	c.ID = id

	q := `UPDATE customers SET
		company_name = :company_name,
		contact_name = :contact_name,
		phone = :phone,
		tax_id = :tax_id,
		billing_address = :billing_address,
		billing_city = :billing_city,
		billing_state = :billing_state,
		billing_zip = :billing_zip,
		billing_country = :billing_country,
		credit_limit = :credit_limit,
		payment_terms = :payment_terms,
		notes = :notes,
		updated_at = :updated_at
		WHERE id = :id`

	res, err := r.db.NamedExecContext(ctx, q, c)
	if err != nil {
		return fmt.Errorf("update customer: %w", err)
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return model.ErrNotFound
	}
	return nil
}

func (r *PgCustomerRepo) Delete(ctx context.Context, id uuid.UUID) error {
	q := `DELETE FROM customers WHERE id = $1`
	res, err := r.db.ExecContext(ctx, q, id)
	if err != nil {
		return fmt.Errorf("delete customer: %w", err)
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return model.ErrNotFound
	}
	return nil
}

func (r *PgCustomerRepo) List(ctx context.Context, f *model.CustomerFilter) ([]*model.Customer, int, error) {
	where, args := r.buildFilter(f)
	countQ := `SELECT COUNT(*) FROM customers ` + where
	var total int
	if err := r.db.GetContext(ctx, &total, countQ, args...); err != nil {
		return nil, 0, fmt.Errorf("count customers: %w", err)
	}

	listQ := `SELECT ` + customerColumns + ` FROM customers ` + where +
		` ORDER BY created_at DESC LIMIT $` + fmt.Sprint(len(args)+1) + ` OFFSET $` + fmt.Sprint(len(args)+2)
	args = append(args, f.Limit, f.Offset)

	rows := []*model.Customer{}
	if err := r.db.SelectContext(ctx, &rows, listQ, args...); err != nil {
		return nil, 0, fmt.Errorf("select customers: %w", err)
	}
	return rows, total, nil
}

func (r *PgCustomerRepo) buildFilter(f *model.CustomerFilter) (string, []interface{}) {
	if f == nil {
		return "", nil
	}
	parts := []string{}
	args := []interface{}{}
	idx := 1

	if f.SearchTerm != "" {
		parts = append(parts, fmt.Sprintf("(company_name ILIKE $%d OR contact_name ILIKE $%d OR email ILIKE $%d)", idx, idx, idx))
		args = append(args, "%"+f.SearchTerm+"%")
		idx++
	}
	if f.Type != "" {
		parts = append(parts, fmt.Sprintf("type = $%d", idx))
		args = append(args, f.Type)
		idx++
	}
	if f.City != "" {
		parts = append(parts, fmt.Sprintf("billing_city = $%d", idx))
		args = append(args, f.City)
		idx++
	}
	if f.State != "" {
		parts = append(parts, fmt.Sprintf("billing_state = $%d", idx))
		args = append(args, f.State)
		idx++
	}
	if f.Country != "" {
		parts = append(parts, fmt.Sprintf("billing_country = $%d", idx))
		args = append(args, f.Country)
		idx++
	}
	if f.IsActive != nil {
		parts = append(parts, fmt.Sprintf("is_active = $%d", idx))
		args = append(args, *f.IsActive)
		idx++
	}
	if f.HasBalance != nil {
		if *f.HasBalance {
			parts = append(parts, "outstanding_bal > 0")
		} else {
			parts = append(parts, "outstanding_bal <= 0")
		}
	}
	if !f.FromDate.IsZero() {
		parts = append(parts, fmt.Sprintf("created_at >= $%d", idx))
		args = append(args, f.FromDate)
		idx++
	}
	if !f.ToDate.IsZero() {
		parts = append(parts, fmt.Sprintf("created_at <= $%d", idx))
		args = append(args, f.ToDate)
		idx++
	}

	if len(parts) == 0 {
		return "", args
	}
	return "WHERE " + strings.Join(parts, " AND "), args
}

func (r *PgCustomerRepo) UpdateOutstandingBalance(ctx context.Context, id uuid.UUID, delta float64) error {
	q := `UPDATE customers SET outstanding_bal = outstanding_bal + $1, updated_at = $2 WHERE id = $3`
	res, err := r.db.ExecContext(ctx, q, delta, time.Now(), id)
	if err != nil {
		return fmt.Errorf("update outstanding: %w", err)
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return model.ErrNotFound
	}
	return nil
}

func (r *PgCustomerRepo) SetActive(ctx context.Context, id uuid.UUID, active bool) error {
	q := `UPDATE customers SET is_active = $1, updated_at = $2 WHERE id = $3`
	res, err := r.db.ExecContext(ctx, q, active, time.Now(), id)
	if err != nil {
		return fmt.Errorf("set active: %w", err)
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return model.ErrNotFound
	}
	return nil
}

func (r *PgCustomerRepo) WithTx(ctx context.Context, tx *sqlx.Tx, fn func(tx *sqlx.Tx) error) error {
	return fn(tx)
}
