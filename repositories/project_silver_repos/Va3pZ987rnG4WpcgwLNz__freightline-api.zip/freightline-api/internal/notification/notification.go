package notification

import (
	"context"
	"fmt"
	"sync"
	"time"

	"github.com/google/uuid"
)

type Channel string

const (
	ChannelEmail Channel = "email"
	ChannelSMS   Channel = "sms"
	ChannelPush  Channel = "push"
	ChannelWebhook Channel = "webhook"
)

type Priority string

const (
	PriorityLow      Priority = "low"
	PriorityNormal   Priority = "normal"
	PriorityHigh     Priority = "high"
	PriorityCritical Priority = "critical"
)

type Status string

const (
	StatusPending   Status = "pending"
	StatusSent      Status = "sent"
	StatusFailed    Status = "failed"
	StatusDelivered Status = "delivered"
)

type Notification struct {
	ID        uuid.UUID
	Channel   Channel
	Recipient string
	Subject   string
	Body      string
	Priority  Priority
	Status    Status
	Attempts  int
	CreatedAt time.Time
	SentAt    time.Time
	Error     string
	Metadata  map[string]string
}

type Sender interface {
	Send(ctx context.Context, n *Notification) error
	Channel() Channel
}

type Dispatcher struct {
	mu       sync.RWMutex
	senders  map[Channel]Sender
	history  []*Notification
	maxRetry int
}

func NewDispatcher(maxRetry int) *Dispatcher {
	if maxRetry <= 0 {
		maxRetry = 3
	}
	return &Dispatcher{
		senders:  make(map[Channel]Sender),
		history:  make([]*Notification, 0, 256),
		maxRetry: maxRetry,
	}
}

func (d *Dispatcher) Register(s Sender) {
	d.mu.Lock()
	defer d.mu.Unlock()
	d.senders[s.Channel()] = s
}

func (d *Dispatcher) Dispatch(ctx context.Context, n *Notification) error {
	if n == nil {
		return fmt.Errorf("nil notification")
	}
	if n.ID == uuid.Nil {
		n.ID = uuid.New()
	}
	if n.CreatedAt.IsZero() {
		n.CreatedAt = time.Now()
	}
	if n.Status == "" {
		n.Status = StatusPending
	}

	d.mu.RLock()
	sender, ok := d.senders[n.Channel]
	d.mu.RUnlock()

	if !ok {
		n.Status = StatusFailed
		n.Error = fmt.Sprintf("no sender for channel %q", n.Channel)
		d.record(n)
		return fmt.Errorf("%s", n.Error)
	}

	var err error
	for attempt := 1; attempt <= d.maxRetry; attempt++ {
		n.Attempts = attempt
		if err = sender.Send(ctx, n); err == nil {
			n.Status = StatusSent
			n.SentAt = time.Now()
			d.record(n)
			return nil
		}
	}

	n.Status = StatusFailed
	n.Error = err.Error()
	d.record(n)
	return err
}

func (d *Dispatcher) record(n *Notification) {
	d.mu.Lock()
	defer d.mu.Unlock()
	d.history = append(d.history, n)
	if len(d.history) > 3000 {
		d.history = d.history[len(d.history)-3000:]
	}
}

func (d *Dispatcher) History(limit int) []*Notification {
	d.mu.RLock()
	defer d.mu.RUnlock()
	if limit <= 0 || limit > len(d.history) {
		limit = len(d.history)
	}
	out := make([]*Notification, limit)
	start := len(d.history) - limit
	for i := 0; i < limit; i++ {
		out[i] = d.history[start+i]
	}
	return out
}

type loggingEmailSender struct {
	from string
	sent []*Notification
	mu   sync.Mutex
}

func NewLoggingEmailSender(from string) Sender {
	return &loggingEmailSender{from: from}
}

func (s *loggingEmailSender) Channel() Channel { return ChannelEmail }

func (s *loggingEmailSender) Send(ctx context.Context, n *Notification) error {
	if n.Recipient == "" {
		return fmt.Errorf("empty recipient")
	}
	s.mu.Lock()
	s.sent = append(s.sent, n)
	s.mu.Unlock()
	return nil
}

func (s *loggingEmailSender) Sent() []*Notification {
	s.mu.Lock()
	defer s.mu.Unlock()
	cp := make([]*Notification, len(s.sent))
	copy(cp, s.sent)
	return cp
}

type loggingSMSSender struct {
	gateway string
	sent    []*Notification
	mu      sync.Mutex
}

func NewLoggingSMSSender(gateway string) Sender {
	return &loggingSMSSender{gateway: gateway}
}

func (s *loggingSMSSender) Channel() Channel { return ChannelSMS }

func (s *loggingSMSSender) Send(ctx context.Context, n *Notification) error {
	if n.Recipient == "" {
		return fmt.Errorf("empty recipient")
	}
	s.mu.Lock()
	s.sent = append(s.sent, n)
	s.mu.Unlock()
	return nil
}

func (s *loggingSMSSender) Sent() []*Notification {
	s.mu.Lock()
	defer s.mu.Unlock()
	cp := make([]*Notification, len(s.sent))
	copy(cp, s.sent)
	return cp
}
