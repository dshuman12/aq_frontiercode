package handler

import (
	"errors"
	"net/http"
	"strconv"

	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/validator"
	"github.com/gin-gonic/gin"
)

type ErrorResponse struct {
	Error   string `json:"error"`
	Code    string `json:"code,omitempty"`
	Details string `json:"details,omitempty"`
}

func respondError(c *gin.Context, err error) {
	if err == nil {
		c.JSON(http.StatusInternalServerError, ErrorResponse{Error: "unknown error"})
		return
	}
	status, code := classifyError(err)
	c.JSON(status, ErrorResponse{
		Error:   err.Error(),
		Code:    code,
		Details: err.Error(),
	})
}

func classifyError(err error) (int, string) {
	switch {
	case errors.Is(err, model.ErrNotFound):
		return http.StatusNotFound, "not_found"
	case errors.Is(err, model.ErrDuplicate):
		return http.StatusConflict, "duplicate"
	case errors.Is(err, model.ErrConflict):
		return http.StatusConflict, "conflict"
	case errors.Is(err, model.ErrInvalidInput),
		errors.Is(err, validator.ErrEmptyField),
		errors.Is(err, validator.ErrBadFormat),
		errors.Is(err, validator.ErrOutOfRange),
		errors.Is(err, validator.ErrBadID),
		errors.Is(err, validator.ErrFutureDate),
		errors.Is(err, validator.ErrPastDate):
		return http.StatusBadRequest, "bad_request"
	case errors.Is(err, model.ErrUnauthorized):
		return http.StatusUnauthorized, "unauthorized"
	case errors.Is(err, model.ErrForbidden):
		return http.StatusForbidden, "forbidden"
	case errors.Is(err, model.ErrInsufficient),
		errors.Is(err, model.ErrInvalidStatus),
		errors.Is(err, model.ErrUnavailable):
		return http.StatusUnprocessableEntity, "unprocessable"
	case errors.Is(err, model.ErrRateLimit):
		return http.StatusTooManyRequests, "rate_limit"
	}
	return http.StatusInternalServerError, "internal"
}

func respondOK(c *gin.Context, payload interface{}) {
	c.JSON(http.StatusOK, payload)
}

func respondCreated(c *gin.Context, payload interface{}) {
	c.JSON(http.StatusCreated, payload)
}

func respondNoContent(c *gin.Context) {
	c.Status(http.StatusNoContent)
}

func parseFloat(s string) float64 {
	if s == "" {
		return 0
	}
	v, err := strconv.ParseFloat(s, 64)
	if err != nil {
		return 0
	}
	return v
}

func parseInt(s string, fallback int) int {
	if s == "" {
		return fallback
	}
	v, err := strconv.Atoi(s)
	if err != nil {
		return fallback
	}
	return v
}

func parseBool(s string) *bool {
	if s == "" {
		return nil
	}
	b, err := strconv.ParseBool(s)
	if err != nil {
		return nil
	}
	return &b
}

func respondAccepted(c *gin.Context, payload interface{}) {
	c.JSON(http.StatusAccepted, payload)
}
