package handler

import (
	"time"

	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/service"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

type ReportHandler struct {
	svc *service.ReportService
}

func NewReportHandler(svc *service.ReportService) *ReportHandler {
	return &ReportHandler{svc: svc}
}

func (h *ReportHandler) Register(rg *gin.RouterGroup) {
	rg.GET("/reports/dashboard", h.Dashboard)
	rg.GET("/reports/fleet-utilization", h.FleetUtilization)
	rg.GET("/reports/driver/:id", h.DriverPerformance)
	rg.GET("/reports/revenue", h.Revenue)
	rg.GET("/reports/shipment-volume", h.ShipmentVolume)
	rg.GET("/reports/warehouse/:id/utilization", h.WarehouseUtilization)
	rg.GET("/reports/carrier/:id/performance", h.CarrierPerformance)
}

func parseDateRange(c *gin.Context) (time.Time, time.Time) {
	var from, to time.Time
	if v := c.Query("from"); v != "" {
		if t, err := time.Parse("2006-01-02", v); err == nil {
			from = t
		}
	}
	if v := c.Query("to"); v != "" {
		if t, err := time.Parse("2006-01-02", v); err == nil {
			to = t
		}
	}
	if from.IsZero() {
		from = time.Now().AddDate(0, -1, 0)
	}
	if to.IsZero() {
		to = time.Now()
	}
	return from, to
}

func (h *ReportHandler) Dashboard(c *gin.Context) {
	r, err := h.svc.Dashboard(c.Request.Context())
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, r)
}

func (h *ReportHandler) FleetUtilization(c *gin.Context) {
	from, to := parseDateRange(c)
	r, err := h.svc.FleetUtilization(c.Request.Context(), from, to)
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, r)
}

func (h *ReportHandler) DriverPerformance(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	from, to := parseDateRange(c)
	r, err := h.svc.DriverPerformance(c.Request.Context(), id, from, to)
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, r)
}

func (h *ReportHandler) Revenue(c *gin.Context) {
	from, to := parseDateRange(c)
	r, err := h.svc.Revenue(c.Request.Context(), from, to)
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, r)
}

func (h *ReportHandler) ShipmentVolume(c *gin.Context) {
	from, to := parseDateRange(c)
	r, err := h.svc.ShipmentVolume(c.Request.Context(), from, to)
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, r)
}

func (h *ReportHandler) WarehouseUtilization(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	r, err := h.svc.WarehouseUtilization(c.Request.Context(), id)
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, r)
}

func (h *ReportHandler) CarrierPerformance(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	from, to := parseDateRange(c)
	r, err := h.svc.CarrierPerformance(c.Request.Context(), id, from, to)
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, r)
}
