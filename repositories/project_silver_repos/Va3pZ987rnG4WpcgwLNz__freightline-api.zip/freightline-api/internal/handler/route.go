package handler

import (
	"freightline.dev/api/internal/middleware"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/pagination"
	"freightline.dev/api/internal/service"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

type RouteHandler struct {
	svc *service.RouteService
}

func NewRouteHandler(svc *service.RouteService) *RouteHandler {
	return &RouteHandler{svc: svc}
}

func (h *RouteHandler) Register(rg *gin.RouterGroup) {
	rg.POST("/routes", h.Create)
	rg.GET("/routes", h.List)
	rg.GET("/routes/:id", h.Get)
	rg.GET("/routes/:id/stops", h.GetWithStops)
	rg.PUT("/routes/:id", h.Update)
	rg.DELETE("/routes/:id", h.Delete)
	rg.POST("/routes/:id/start", h.Start)
	rg.POST("/routes/:id/complete", h.Complete)
	rg.POST("/routes/:id/cancel", h.Cancel)
	rg.POST("/routes/stops/:stop_id/complete", h.CompleteStop)
}

func (h *RouteHandler) Create(c *gin.Context) {
	var req model.CreateRouteRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		respondError(c, err)
		return
	}
	id, err := h.svc.Create(c.Request.Context(), req, middleware.CurrentUserID(c))
	if err != nil {
		respondError(c, err)
		return
	}
	respondCreated(c, gin.H{"id": id})
}

func (h *RouteHandler) Get(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	r, err := h.svc.GetByID(c.Request.Context(), id)
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, r)
}

func (h *RouteHandler) GetWithStops(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	r, err := h.svc.GetWithStops(c.Request.Context(), id)
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, r)
}

func (h *RouteHandler) Update(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	var req model.UpdateRouteRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		respondError(c, err)
		return
	}
	if err := h.svc.Update(c.Request.Context(), id, req, middleware.CurrentUserID(c)); err != nil {
		respondError(c, err)
		return
	}
	respondNoContent(c)
}

func (h *RouteHandler) Delete(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	if err := h.svc.Delete(c.Request.Context(), id, middleware.CurrentUserID(c)); err != nil {
		respondError(c, err)
		return
	}
	respondNoContent(c)
}

func (h *RouteHandler) Start(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	if err := h.svc.Start(c.Request.Context(), id, middleware.CurrentUserID(c)); err != nil {
		respondError(c, err)
		return
	}
	respondNoContent(c)
}

func (h *RouteHandler) Complete(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	if err := h.svc.Complete(c.Request.Context(), id, middleware.CurrentUserID(c)); err != nil {
		respondError(c, err)
		return
	}
	respondNoContent(c)
}

func (h *RouteHandler) Cancel(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	var body struct {
		Reason string `json:"reason"`
	}
	_ = c.ShouldBindJSON(&body)
	if err := h.svc.Cancel(c.Request.Context(), id, body.Reason, middleware.CurrentUserID(c)); err != nil {
		respondError(c, err)
		return
	}
	respondNoContent(c)
}

func (h *RouteHandler) CompleteStop(c *gin.Context) {
	stopID, err := uuid.Parse(c.Param("stop_id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	if err := h.svc.CompleteStop(c.Request.Context(), stopID, middleware.CurrentUserID(c)); err != nil {
		respondError(c, err)
		return
	}
	respondNoContent(c)
}

func (h *RouteHandler) List(c *gin.Context) {
	p := pagination.FromQuery(c.Query("page"), c.Query("limit"))
	f := &model.RouteFilter{
		SearchTerm: c.Query("q"),
		Limit:      p.Limit,
		Offset:     p.Offset(),
	}
	if v := c.Query("status"); v != "" {
		f.Status = model.RouteStatus(v)
	}
	if v := c.Query("driver_id"); v != "" {
		if u, err := uuid.Parse(v); err == nil {
			f.DriverID = &u
		}
	}
	results, total, err := h.svc.List(c.Request.Context(), f)
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, pagination.BuildResult(results, p, total))
}
