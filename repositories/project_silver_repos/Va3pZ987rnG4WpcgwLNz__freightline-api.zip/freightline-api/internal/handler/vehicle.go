package handler

import (
	"freightline.dev/api/internal/middleware"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/pagination"
	"freightline.dev/api/internal/service"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

type VehicleHandler struct {
	svc *service.VehicleService
}

func NewVehicleHandler(svc *service.VehicleService) *VehicleHandler {
	return &VehicleHandler{svc: svc}
}

func (h *VehicleHandler) Register(rg *gin.RouterGroup) {
	rg.POST("/vehicles", h.Create)
	rg.GET("/vehicles", h.List)
	rg.GET("/vehicles/:id", h.Get)
	rg.PUT("/vehicles/:id", h.Update)
	rg.DELETE("/vehicles/:id", h.Delete)
	rg.POST("/vehicles/:id/status", h.ChangeStatus)
	rg.POST("/vehicles/:id/trip", h.RecordTrip)
	rg.GET("/vehicles/available", h.ListAvailable)
	rg.GET("/vehicles/needs-service", h.ListNeedingService)
	rg.GET("/vehicles/find-suitable", h.FindSuitable)
}

func (h *VehicleHandler) Create(c *gin.Context) {
	var req model.CreateVehicleRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		respondError(c, err)
		return
	}
	id, err := h.svc.Create(c.Request.Context(), req, middleware.CurrentUserID(c))
	if err != nil {
		respondError(c, err)
		return
	}
	respondCreated(c, gin.H{"id": id})
}

func (h *VehicleHandler) Get(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	v, err := h.svc.GetByID(c.Request.Context(), id)
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, v)
}

func (h *VehicleHandler) Update(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	var req model.UpdateVehicleRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		respondError(c, err)
		return
	}
	if err := h.svc.Update(c.Request.Context(), id, req, middleware.CurrentUserID(c)); err != nil {
		respondError(c, err)
		return
	}
	respondNoContent(c)
}

func (h *VehicleHandler) Delete(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	if err := h.svc.Delete(c.Request.Context(), id, middleware.CurrentUserID(c)); err != nil {
		respondError(c, err)
		return
	}
	respondNoContent(c)
}

func (h *VehicleHandler) List(c *gin.Context) {
	p := pagination.FromQuery(c.Query("page"), c.Query("limit"))
	f := &model.VehicleFilter{
		SearchTerm: c.Query("q"),
		Limit:      p.Limit,
		Offset:     p.Offset(),
	}
	if v := c.Query("status"); v != "" {
		f.Status = model.VehicleStatus(v)
	}
	if v := c.Query("type"); v != "" {
		f.Type = model.VehicleType(v)
	}
	if v := c.Query("fuel_type"); v != "" {
		f.FuelType = model.FuelType(v)
	}
	f.IsRefrigerated = parseBool(c.Query("is_refrigerated"))
	results, total, err := h.svc.List(c.Request.Context(), f)
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, pagination.BuildResult(results, p, total))
}

func (h *VehicleHandler) ChangeStatus(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	var body struct {
		Status string `json:"status" binding:"required"`
	}
	if err := c.ShouldBindJSON(&body); err != nil {
		respondError(c, err)
		return
	}
	if err := h.svc.ChangeStatus(c.Request.Context(), id, model.VehicleStatus(body.Status), middleware.CurrentUserID(c)); err != nil {
		respondError(c, err)
		return
	}
	respondNoContent(c)
}

func (h *VehicleHandler) RecordTrip(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	var body struct {
		Km float64 `json:"km" binding:"required"`
	}
	if err := c.ShouldBindJSON(&body); err != nil {
		respondError(c, err)
		return
	}
	if err := h.svc.RecordTrip(c.Request.Context(), id, body.Km, middleware.CurrentUserID(c)); err != nil {
		respondError(c, err)
		return
	}
	respondNoContent(c)
}

func (h *VehicleHandler) ListAvailable(c *gin.Context) {
	out, err := h.svc.ListAvailable(c.Request.Context())
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, out)
}

func (h *VehicleHandler) ListNeedingService(c *gin.Context) {
	out, err := h.svc.ListNeedingService(c.Request.Context())
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, out)
}

func (h *VehicleHandler) FindSuitable(c *gin.Context) {
	weight := parseFloat(c.Query("weight_kg"))
	vol := parseFloat(c.Query("volume_m3"))
	refrigerated := parseBool(c.Query("refrigerated"))
	needRefrigeration := refrigerated != nil && *refrigerated
	out, err := h.svc.FindSuitable(c.Request.Context(), weight, vol, needRefrigeration)
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, out)
}
