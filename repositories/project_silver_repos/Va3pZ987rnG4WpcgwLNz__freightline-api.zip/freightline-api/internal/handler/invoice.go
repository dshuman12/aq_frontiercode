package handler

import (
	"freightline.dev/api/internal/middleware"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/pagination"
	"freightline.dev/api/internal/service"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

type InvoiceHandler struct {
	svc *service.InvoiceService
}

func NewInvoiceHandler(svc *service.InvoiceService) *InvoiceHandler {
	return &InvoiceHandler{svc: svc}
}

func (h *InvoiceHandler) Register(rg *gin.RouterGroup) {
	rg.POST("/invoices", h.Create)
	rg.GET("/invoices", h.List)
	rg.GET("/invoices/:id", h.Get)
	rg.GET("/invoices/:id/with-lines", h.GetWithLines)
	rg.PUT("/invoices/:id", h.Update)
	rg.DELETE("/invoices/:id", h.Delete)
	rg.POST("/invoices/:id/void", h.Void)
	rg.GET("/invoices/overdue", h.ListOverdue)
	rg.POST("/invoices/mark-overdue", h.MarkOverdue)
	rg.GET("/invoices/outstanding", h.TotalOutstanding)
}

func (h *InvoiceHandler) Create(c *gin.Context) {
	var req model.CreateInvoiceRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		respondError(c, err)
		return
	}
	id, err := h.svc.Create(c.Request.Context(), req, middleware.CurrentUserID(c))
	if err != nil {
		respondError(c, err)
		return
	}
	respondCreated(c, gin.H{"id": id})
}

func (h *InvoiceHandler) Get(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	inv, err := h.svc.GetByID(c.Request.Context(), id)
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, inv)
}

func (h *InvoiceHandler) GetWithLines(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	inv, err := h.svc.GetWithLines(c.Request.Context(), id)
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, inv)
}

func (h *InvoiceHandler) Update(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	var req model.UpdateInvoiceRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		respondError(c, err)
		return
	}
	if err := h.svc.Update(c.Request.Context(), id, req, middleware.CurrentUserID(c)); err != nil {
		respondError(c, err)
		return
	}
	respondNoContent(c)
}

func (h *InvoiceHandler) Delete(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	if err := h.svc.Delete(c.Request.Context(), id, middleware.CurrentUserID(c)); err != nil {
		respondError(c, err)
		return
	}
	respondNoContent(c)
}

func (h *InvoiceHandler) Void(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	var body struct {
		Reason string `json:"reason"`
	}
	_ = c.ShouldBindJSON(&body)
	if err := h.svc.Void(c.Request.Context(), id, body.Reason, middleware.CurrentUserID(c)); err != nil {
		respondError(c, err)
		return
	}
	respondNoContent(c)
}

func (h *InvoiceHandler) List(c *gin.Context) {
	p := pagination.FromQuery(c.Query("page"), c.Query("limit"))
	f := &model.InvoiceFilter{
		SearchTerm: c.Query("q"),
		Limit:      p.Limit,
		Offset:     p.Offset(),
	}
	if v := c.Query("status"); v != "" {
		f.Status = model.InvoiceStatus(v)
	}
	if v := c.Query("customer_id"); v != "" {
		if u, err := uuid.Parse(v); err == nil {
			f.CustomerID = &u
		}
	}
	f.IsOverdue = parseBool(c.Query("is_overdue"))
	results, total, err := h.svc.List(c.Request.Context(), f)
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, pagination.BuildResult(results, p, total))
}

func (h *InvoiceHandler) ListOverdue(c *gin.Context) {
	out, err := h.svc.ListOverdue(c.Request.Context())
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, out)
}

func (h *InvoiceHandler) MarkOverdue(c *gin.Context) {
	n, err := h.svc.MarkOverdue(c.Request.Context(), middleware.CurrentUserID(c))
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, gin.H{"updated": n})
}

func (h *InvoiceHandler) TotalOutstanding(c *gin.Context) {
	total, err := h.svc.TotalOutstanding(c.Request.Context())
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, gin.H{"total": total})
}
