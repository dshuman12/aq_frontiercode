package handler

import (
	"freightline.dev/api/internal/middleware"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/pagination"
	"freightline.dev/api/internal/service"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

type DriverHandler struct {
	svc *service.DriverService
}

func NewDriverHandler(svc *service.DriverService) *DriverHandler {
	return &DriverHandler{svc: svc}
}

func (h *DriverHandler) Register(rg *gin.RouterGroup) {
	rg.POST("/drivers", h.Create)
	rg.GET("/drivers", h.List)
	rg.GET("/drivers/:id", h.Get)
	rg.PUT("/drivers/:id", h.Update)
	rg.DELETE("/drivers/:id", h.Delete)
	rg.POST("/drivers/:id/status", h.ChangeStatus)
	rg.GET("/drivers/available", h.ListAvailable)
	rg.GET("/drivers/expiring-licenses", h.ListExpiringLicenses)
}

func (h *DriverHandler) Create(c *gin.Context) {
	var req model.CreateDriverRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		respondError(c, err)
		return
	}
	id, err := h.svc.Create(c.Request.Context(), req, middleware.CurrentUserID(c))
	if err != nil {
		respondError(c, err)
		return
	}
	respondCreated(c, gin.H{"id": id})
}

func (h *DriverHandler) Get(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	d, err := h.svc.GetByID(c.Request.Context(), id)
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, d)
}

func (h *DriverHandler) Update(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	var req model.UpdateDriverRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		respondError(c, err)
		return
	}
	if err := h.svc.Update(c.Request.Context(), id, req, middleware.CurrentUserID(c)); err != nil {
		respondError(c, err)
		return
	}
	respondNoContent(c)
}

func (h *DriverHandler) Delete(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	if err := h.svc.Delete(c.Request.Context(), id, middleware.CurrentUserID(c)); err != nil {
		respondError(c, err)
		return
	}
	respondNoContent(c)
}

func (h *DriverHandler) List(c *gin.Context) {
	p := pagination.FromQuery(c.Query("page"), c.Query("limit"))
	f := &model.DriverFilter{
		SearchTerm: c.Query("q"),
		HomeState:  c.Query("home_state"),
		Limit:      p.Limit,
		Offset:     p.Offset(),
	}
	if v := c.Query("status"); v != "" {
		f.Status = model.DriverStatus(v)
	}
	if v := c.Query("license_class"); v != "" {
		f.LicenseClass = model.LicenseClass(v)
	}
	results, total, err := h.svc.List(c.Request.Context(), f)
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, pagination.BuildResult(results, p, total))
}

func (h *DriverHandler) ChangeStatus(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	var body struct {
		Status string `json:"status" binding:"required"`
	}
	if err := c.ShouldBindJSON(&body); err != nil {
		respondError(c, err)
		return
	}
	if err := h.svc.ChangeStatus(c.Request.Context(), id, model.DriverStatus(body.Status), middleware.CurrentUserID(c)); err != nil {
		respondError(c, err)
		return
	}
	respondNoContent(c)
}

func (h *DriverHandler) ListAvailable(c *gin.Context) {
	out, err := h.svc.ListAvailable(c.Request.Context())
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, out)
}

func (h *DriverHandler) ListExpiringLicenses(c *gin.Context) {
	days := parseInt(c.Query("days"), 30)
	out, err := h.svc.ListExpiringLicenses(c.Request.Context(), days)
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, out)
}
