package handler

import (
	"strconv"

	"freightline.dev/api/internal/middleware"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/pagination"
	"freightline.dev/api/internal/service"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

type CustomerHandler struct {
	svc *service.CustomerService
}

func NewCustomerHandler(svc *service.CustomerService) *CustomerHandler {
	return &CustomerHandler{svc: svc}
}

func (h *CustomerHandler) Register(rg *gin.RouterGroup) {
	rg.POST("/customers", h.Create)
	rg.GET("/customers", h.List)
	rg.GET("/customers/:id", h.Get)
	rg.PUT("/customers/:id", h.Update)
	rg.DELETE("/customers/:id", h.Delete)
	rg.POST("/customers/:id/activate", h.Activate)
	rg.POST("/customers/:id/deactivate", h.Deactivate)
	rg.GET("/customers/:id/credit", h.AvailableCredit)
}

func (h *CustomerHandler) Create(c *gin.Context) {
	var req model.CreateCustomerRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		respondError(c, err)
		return
	}
	id, err := h.svc.Create(c.Request.Context(), req, middleware.CurrentUserID(c))
	if err != nil {
		respondError(c, err)
		return
	}
	respondCreated(c, gin.H{"id": id})
}

func (h *CustomerHandler) Get(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	cust, err := h.svc.GetByID(c.Request.Context(), id)
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, cust)
}

func (h *CustomerHandler) Update(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	var req model.UpdateCustomerRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		respondError(c, err)
		return
	}
	if err := h.svc.Update(c.Request.Context(), id, req, middleware.CurrentUserID(c)); err != nil {
		respondError(c, err)
		return
	}
	respondNoContent(c)
}

func (h *CustomerHandler) Delete(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	if err := h.svc.Delete(c.Request.Context(), id, middleware.CurrentUserID(c)); err != nil {
		respondError(c, err)
		return
	}
	respondNoContent(c)
}

func (h *CustomerHandler) List(c *gin.Context) {
	p := pagination.FromQuery(c.Query("page"), c.Query("limit"))
	f := &model.CustomerFilter{
		SearchTerm: c.Query("q"),
		City:       c.Query("city"),
		State:      c.Query("state"),
		Country:    c.Query("country"),
		Limit:      p.Limit,
		Offset:     p.Offset(),
	}
	if v := c.Query("type"); v != "" {
		f.Type = model.CustomerType(v)
	}
	if v := c.Query("is_active"); v != "" {
		b, _ := strconv.ParseBool(v)
		f.IsActive = &b
	}
	results, total, err := h.svc.List(c.Request.Context(), f)
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, pagination.BuildResult(results, p, total))
}

func (h *CustomerHandler) Activate(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	if err := h.svc.Activate(c.Request.Context(), id, middleware.CurrentUserID(c)); err != nil {
		respondError(c, err)
		return
	}
	respondNoContent(c)
}

func (h *CustomerHandler) Deactivate(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	if err := h.svc.Deactivate(c.Request.Context(), id, middleware.CurrentUserID(c)); err != nil {
		respondError(c, err)
		return
	}
	respondNoContent(c)
}

func (h *CustomerHandler) AvailableCredit(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	credit, err := h.svc.AvailableCredit(c.Request.Context(), id)
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, gin.H{"available_credit": credit})
}
