package handler

import (
	"freightline.dev/api/internal/middleware"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/pagination"
	"freightline.dev/api/internal/service"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

type ShipmentHandler struct {
	svc      *service.ShipmentService
	tracking *service.TrackingService
}

func NewShipmentHandler(svc *service.ShipmentService, track *service.TrackingService) *ShipmentHandler {
	return &ShipmentHandler{svc: svc, tracking: track}
}

func (h *ShipmentHandler) Register(rg *gin.RouterGroup) {
	rg.POST("/shipments", h.Create)
	rg.GET("/shipments", h.List)
	rg.GET("/shipments/:id", h.Get)
	rg.PUT("/shipments/:id", h.Update)
	rg.DELETE("/shipments/:id", h.Delete)
	rg.POST("/shipments/:id/cancel", h.Cancel)
	rg.POST("/shipments/:id/assign-driver", h.AssignDriver)
	rg.POST("/shipments/:id/assign-vehicle", h.AssignVehicle)
	rg.POST("/shipments/:id/transition", h.Transition)
	rg.GET("/shipments/:id/events", h.Events)
	rg.GET("/shipments/track/:number", h.GetByTracking)
	rg.GET("/shipments/quote", h.Quote)
	rg.GET("/shipments/overdue", h.ListOverdue)
}

func (h *ShipmentHandler) Create(c *gin.Context) {
	var req model.CreateShipmentRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		respondError(c, err)
		return
	}
	id, err := h.svc.Create(c.Request.Context(), req, middleware.CurrentUserID(c))
	if err != nil {
		respondError(c, err)
		return
	}
	respondCreated(c, gin.H{"id": id})
}

func (h *ShipmentHandler) Get(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	sh, err := h.svc.GetByID(c.Request.Context(), id)
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, sh)
}

func (h *ShipmentHandler) GetByTracking(c *gin.Context) {
	num := c.Param("number")
	sh, err := h.svc.GetByTrackingNumber(c.Request.Context(), num)
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, sh)
}

func (h *ShipmentHandler) Update(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	var req model.UpdateShipmentRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		respondError(c, err)
		return
	}
	if err := h.svc.Update(c.Request.Context(), id, req, middleware.CurrentUserID(c)); err != nil {
		respondError(c, err)
		return
	}
	respondNoContent(c)
}

func (h *ShipmentHandler) Delete(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	if err := h.svc.Delete(c.Request.Context(), id, middleware.CurrentUserID(c)); err != nil {
		respondError(c, err)
		return
	}
	respondNoContent(c)
}

func (h *ShipmentHandler) Cancel(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	var body struct {
		Reason string `json:"reason"`
	}
	_ = c.ShouldBindJSON(&body)
	if err := h.svc.Cancel(c.Request.Context(), id, body.Reason, middleware.CurrentUserID(c)); err != nil {
		respondError(c, err)
		return
	}
	respondNoContent(c)
}

func (h *ShipmentHandler) AssignDriver(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	var body struct {
		DriverID string `json:"driver_id" binding:"required"`
	}
	if err := c.ShouldBindJSON(&body); err != nil {
		respondError(c, err)
		return
	}
	driverID, err := uuid.Parse(body.DriverID)
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	if err := h.svc.AssignDriver(c.Request.Context(), id, driverID, middleware.CurrentUserID(c)); err != nil {
		respondError(c, err)
		return
	}
	respondNoContent(c)
}

func (h *ShipmentHandler) AssignVehicle(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	var body struct {
		VehicleID string `json:"vehicle_id" binding:"required"`
	}
	if err := c.ShouldBindJSON(&body); err != nil {
		respondError(c, err)
		return
	}
	vehicleID, err := uuid.Parse(body.VehicleID)
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	if err := h.svc.AssignVehicle(c.Request.Context(), id, vehicleID, middleware.CurrentUserID(c)); err != nil {
		respondError(c, err)
		return
	}
	respondNoContent(c)
}

func (h *ShipmentHandler) Transition(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	var body struct {
		Status   string `json:"status" binding:"required"`
		Location string `json:"location"`
	}
	if err := c.ShouldBindJSON(&body); err != nil {
		respondError(c, err)
		return
	}
	if err := h.svc.TransitionStatus(c.Request.Context(), id, model.ShipmentStatus(body.Status), body.Location, middleware.CurrentUserID(c)); err != nil {
		respondError(c, err)
		return
	}
	respondNoContent(c)
}

func (h *ShipmentHandler) Events(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	events, err := h.tracking.ListForShipment(c.Request.Context(), id)
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, events)
}

func (h *ShipmentHandler) List(c *gin.Context) {
	p := pagination.FromQuery(c.Query("page"), c.Query("limit"))
	f := &model.ShipmentFilter{
		SearchTerm:   c.Query("q"),
		OriginCity:   c.Query("origin_city"),
		DeliveryCity: c.Query("delivery_city"),
		Limit:        p.Limit,
		Offset:       p.Offset(),
	}
	if v := c.Query("status"); v != "" {
		f.Status = model.ShipmentStatus(v)
	}
	if v := c.Query("service_level"); v != "" {
		f.ServiceLevel = model.ServiceLevel(v)
	}
	if v := c.Query("customer_id"); v != "" {
		if u, err := uuid.Parse(v); err == nil {
			f.CustomerID = &u
		}
	}
	results, total, err := h.svc.List(c.Request.Context(), f)
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, pagination.BuildResult(results, p, total))
}

func (h *ShipmentHandler) ListOverdue(c *gin.Context) {
	results, err := h.svc.ListOverdue(c.Request.Context())
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, results)
}

func (h *ShipmentHandler) Quote(c *gin.Context) {
	weight := parseFloat(c.Query("weight_kg"))
	declared := parseFloat(c.Query("declared_value"))
	level := model.ServiceLevel(c.DefaultQuery("service_level", string(model.ServiceLevelStandard)))
	q, err := h.svc.Quote(c.Request.Context(), weight, level, declared)
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, gin.H{"total": q})
}


