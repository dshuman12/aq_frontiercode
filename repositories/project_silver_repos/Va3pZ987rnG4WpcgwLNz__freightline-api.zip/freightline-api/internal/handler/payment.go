package handler

import (
	"freightline.dev/api/internal/middleware"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/pagination"
	"freightline.dev/api/internal/service"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

type PaymentHandler struct {
	svc *service.PaymentService
}

func NewPaymentHandler(svc *service.PaymentService) *PaymentHandler {
	return &PaymentHandler{svc: svc}
}

func (h *PaymentHandler) Register(rg *gin.RouterGroup) {
	rg.POST("/payments", h.Create)
	rg.GET("/payments", h.List)
	rg.GET("/payments/:id", h.Get)
	rg.POST("/payments/:id/clear", h.Clear)
	rg.POST("/payments/:id/reverse", h.Reverse)
	rg.POST("/payments/:id/refund", h.Refund)
}

func (h *PaymentHandler) Create(c *gin.Context) {
	var req model.CreatePaymentRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		respondError(c, err)
		return
	}
	id, err := h.svc.Create(c.Request.Context(), req, middleware.CurrentUserID(c))
	if err != nil {
		respondError(c, err)
		return
	}
	respondCreated(c, gin.H{"id": id})
}

func (h *PaymentHandler) Get(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	p, err := h.svc.GetByID(c.Request.Context(), id)
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, p)
}

func (h *PaymentHandler) Clear(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	if err := h.svc.Clear(c.Request.Context(), id, middleware.CurrentUserID(c)); err != nil {
		respondError(c, err)
		return
	}
	respondNoContent(c)
}

func (h *PaymentHandler) Reverse(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	var body struct {
		Reason string `json:"reason"`
	}
	_ = c.ShouldBindJSON(&body)
	if err := h.svc.Reverse(c.Request.Context(), id, body.Reason, middleware.CurrentUserID(c)); err != nil {
		respondError(c, err)
		return
	}
	respondNoContent(c)
}

func (h *PaymentHandler) Refund(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	var req model.RefundPaymentRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		respondError(c, err)
		return
	}
	if err := h.svc.Refund(c.Request.Context(), id, req, middleware.CurrentUserID(c)); err != nil {
		respondError(c, err)
		return
	}
	respondNoContent(c)
}

func (h *PaymentHandler) List(c *gin.Context) {
	p := pagination.FromQuery(c.Query("page"), c.Query("limit"))
	f := &model.PaymentFilter{
		Limit:  p.Limit,
		Offset: p.Offset(),
	}
	if v := c.Query("customer_id"); v != "" {
		if u, err := uuid.Parse(v); err == nil {
			f.CustomerID = &u
		}
	}
	if v := c.Query("invoice_id"); v != "" {
		if u, err := uuid.Parse(v); err == nil {
			f.InvoiceID = &u
		}
	}
	if v := c.Query("method"); v != "" {
		f.Method = model.PaymentMethod(v)
	}
	if v := c.Query("status"); v != "" {
		f.Status = model.PaymentStatus(v)
	}
	f.MinAmount = parseFloat(c.Query("min_amount"))
	f.MaxAmount = parseFloat(c.Query("max_amount"))
	results, total, err := h.svc.List(c.Request.Context(), f)
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, pagination.BuildResult(results, p, total))
}
