package handler

import (
	"freightline.dev/api/internal/middleware"
	"github.com/gin-gonic/gin"
)

type AuthHandler struct {
	jwt *middleware.JWT
}

func NewAuthHandler(j *middleware.JWT) *AuthHandler {
	return &AuthHandler{jwt: j}
}

func (h *AuthHandler) Register(rg *gin.RouterGroup) {
	rg.POST("/auth/token", h.IssueToken)
}

type IssueTokenRequest struct {
	UserID string   `json:"user_id" binding:"required"`
	Email  string   `json:"email" binding:"required,email"`
	Roles  []string `json:"roles"`
}

func (h *AuthHandler) IssueToken(c *gin.Context) {
	var req IssueTokenRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		respondError(c, err)
		return
	}
	tok, err := h.jwt.Sign(req.UserID, req.Email, req.Roles)
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, gin.H{"token": tok})
}
