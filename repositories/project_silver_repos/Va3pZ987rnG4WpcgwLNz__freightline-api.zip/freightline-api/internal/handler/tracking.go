package handler

import (
	"freightline.dev/api/internal/middleware"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/service"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

type TrackingHandler struct {
	svc *service.TrackingService
}

func NewTrackingHandler(svc *service.TrackingService) *TrackingHandler {
	return &TrackingHandler{svc: svc}
}

func (h *TrackingHandler) Register(rg *gin.RouterGroup) {
	rg.POST("/tracking/events", h.Record)
	rg.GET("/tracking/events/:id", h.Get)
	rg.GET("/tracking/shipments/:shipment_id/events", h.ListForShipment)
	rg.GET("/tracking/shipments/:shipment_id/latest", h.Latest)
}

func (h *TrackingHandler) Record(c *gin.Context) {
	var req model.CreateTrackingEventRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		respondError(c, err)
		return
	}
	id, err := h.svc.RecordEvent(c.Request.Context(), req, middleware.CurrentUserID(c))
	if err != nil {
		respondError(c, err)
		return
	}
	respondCreated(c, gin.H{"id": id})
}

func (h *TrackingHandler) Get(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	e, err := h.svc.GetEvent(c.Request.Context(), id)
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, e)
}

func (h *TrackingHandler) ListForShipment(c *gin.Context) {
	id, err := uuid.Parse(c.Param("shipment_id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	events, err := h.svc.ListForShipment(c.Request.Context(), id)
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, events)
}

func (h *TrackingHandler) Latest(c *gin.Context) {
	id, err := uuid.Parse(c.Param("shipment_id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	e, err := h.svc.LatestForShipment(c.Request.Context(), id)
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, e)
}
