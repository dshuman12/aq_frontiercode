package handler

import (
	"freightline.dev/api/internal/middleware"
	"freightline.dev/api/internal/model"
	"freightline.dev/api/internal/pagination"
	"freightline.dev/api/internal/service"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

type CarrierHandler struct {
	svc *service.CarrierService
}

func NewCarrierHandler(svc *service.CarrierService) *CarrierHandler {
	return &CarrierHandler{svc: svc}
}

func (h *CarrierHandler) Register(rg *gin.RouterGroup) {
	rg.POST("/carriers", h.Create)
	rg.GET("/carriers", h.List)
	rg.GET("/carriers/:id", h.Get)
	rg.PUT("/carriers/:id", h.Update)
	rg.DELETE("/carriers/:id", h.Delete)
	rg.POST("/carriers/:id/activate", h.Activate)
	rg.POST("/carriers/:id/deactivate", h.Deactivate)
	rg.GET("/carriers/:id/quote", h.Quote)
	rg.POST("/carriers/:id/performance", h.RecordPerformance)
}

func (h *CarrierHandler) Create(c *gin.Context) {
	var req model.CreateCarrierRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		respondError(c, err)
		return
	}
	id, err := h.svc.Create(c.Request.Context(), req, middleware.CurrentUserID(c))
	if err != nil {
		respondError(c, err)
		return
	}
	respondCreated(c, gin.H{"id": id})
}

func (h *CarrierHandler) Get(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	ca, err := h.svc.GetByID(c.Request.Context(), id)
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, ca)
}

func (h *CarrierHandler) Update(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	var req model.UpdateCarrierRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		respondError(c, err)
		return
	}
	if err := h.svc.Update(c.Request.Context(), id, req, middleware.CurrentUserID(c)); err != nil {
		respondError(c, err)
		return
	}
	respondNoContent(c)
}

func (h *CarrierHandler) Delete(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	if err := h.svc.Delete(c.Request.Context(), id, middleware.CurrentUserID(c)); err != nil {
		respondError(c, err)
		return
	}
	respondNoContent(c)
}

func (h *CarrierHandler) List(c *gin.Context) {
	p := pagination.FromQuery(c.Query("page"), c.Query("limit"))
	f := &model.CarrierFilter{
		SearchTerm: c.Query("q"),
		City:       c.Query("city"),
		State:      c.Query("state"),
		Country:    c.Query("country"),
		MinRating:  parseFloat(c.Query("min_rating")),
		MinOnTime:  parseFloat(c.Query("min_on_time")),
		Limit:      p.Limit,
		Offset:     p.Offset(),
	}
	f.IsActive = parseBool(c.Query("is_active"))
	f.IsHazmatCertified = parseBool(c.Query("is_hazmat_certified"))
	results, total, err := h.svc.List(c.Request.Context(), f)
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, pagination.BuildResult(results, p, total))
}

func (h *CarrierHandler) Activate(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	if err := h.svc.Activate(c.Request.Context(), id, middleware.CurrentUserID(c)); err != nil {
		respondError(c, err)
		return
	}
	respondNoContent(c)
}

func (h *CarrierHandler) Deactivate(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	if err := h.svc.Deactivate(c.Request.Context(), id, middleware.CurrentUserID(c)); err != nil {
		respondError(c, err)
		return
	}
	respondNoContent(c)
}

func (h *CarrierHandler) Quote(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	weight := parseFloat(c.Query("weight_kg"))
	distance := parseFloat(c.Query("distance_km"))
	q, err := h.svc.Quote(c.Request.Context(), id, weight, distance)
	if err != nil {
		respondError(c, err)
		return
	}
	respondOK(c, gin.H{"total": q})
}

func (h *CarrierHandler) RecordPerformance(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, model.ErrInvalidInput)
		return
	}
	var body struct {
		OnTime float64 `json:"on_time_rate"`
		Damage float64 `json:"damage_rate"`
		Total  int     `json:"total"`
	}
	if err := c.ShouldBindJSON(&body); err != nil {
		respondError(c, err)
		return
	}
	if err := h.svc.RecordPerformance(c.Request.Context(), id, body.OnTime, body.Damage, body.Total, middleware.CurrentUserID(c)); err != nil {
		respondError(c, err)
		return
	}
	respondNoContent(c)
}
