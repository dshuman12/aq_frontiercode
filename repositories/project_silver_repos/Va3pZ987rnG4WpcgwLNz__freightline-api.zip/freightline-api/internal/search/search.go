package search

import (
	"fmt"
	"strings"
)

type Operator string

const (
	OpEq    Operator = "="
	OpNeq   Operator = "!="
	OpGt    Operator = ">"
	OpGte   Operator = ">="
	OpLt    Operator = "<"
	OpLte   Operator = "<="
	OpLike  Operator = "ILIKE"
	OpIn    Operator = "IN"
	OpIsNil Operator = "IS NULL"
	OpNotNil Operator = "IS NOT NULL"
)

type Direction string

const (
	Asc  Direction = "ASC"
	Desc Direction = "DESC"
)

type Condition struct {
	Field    string
	Operator Operator
	Value    interface{}
}

type Order struct {
	Field     string
	Direction Direction
}

type Builder struct {
	table      string
	columns    []string
	conditions []Condition
	orders     []Order
	limit      int
	offset     int
	args       []interface{}
}

func NewBuilder(table string) *Builder {
	return &Builder{
		table:   table,
		columns: []string{"*"},
	}
}

func (b *Builder) Select(cols ...string) *Builder {
	if len(cols) > 0 {
		b.columns = cols
	}
	return b
}

func (b *Builder) Where(field string, op Operator, value interface{}) *Builder {
	b.conditions = append(b.conditions, Condition{Field: field, Operator: op, Value: value})
	return b
}

func (b *Builder) WhereEq(field string, value interface{}) *Builder {
	return b.Where(field, OpEq, value)
}

func (b *Builder) WhereLike(field, value string) *Builder {
	if value == "" {
		return b
	}
	return b.Where(field, OpLike, "%"+value+"%")
}

func (b *Builder) WhereNullish(field string, nullish bool) *Builder {
	if nullish {
		return b.Where(field, OpIsNil, nil)
	}
	return b.Where(field, OpNotNil, nil)
}

func (b *Builder) WhereIn(field string, values []interface{}) *Builder {
	if len(values) == 0 {
		return b
	}
	return b.Where(field, OpIn, values)
}

func (b *Builder) OrderBy(field string, dir Direction) *Builder {
	b.orders = append(b.orders, Order{Field: field, Direction: dir})
	return b
}

func (b *Builder) Limit(n int) *Builder {
	if n > 0 {
		b.limit = n
	}
	return b
}

func (b *Builder) Offset(n int) *Builder {
	if n > 0 {
		b.offset = n
	}
	return b
}

func (b *Builder) Build() (string, []interface{}) {
	var sb strings.Builder
	b.args = nil

	sb.WriteString("SELECT ")
	sb.WriteString(strings.Join(b.columns, ", "))
	sb.WriteString(" FROM ")
	sb.WriteString(b.table)

	if len(b.conditions) > 0 {
		sb.WriteString(" WHERE ")
		var parts []string
		argPos := 1
		for _, c := range b.conditions {
			switch c.Operator {
			case OpIsNil, OpNotNil:
				parts = append(parts, fmt.Sprintf("%s %s", c.Field, c.Operator))
			case OpIn:
				vals, ok := c.Value.([]interface{})
				if !ok || len(vals) == 0 {
					continue
				}
				placeholders := make([]string, 0, len(vals))
				for _, v := range vals {
					placeholders = append(placeholders, fmt.Sprintf("$%d", argPos))
					b.args = append(b.args, v)
					argPos++
				}
				parts = append(parts, fmt.Sprintf("%s IN (%s)", c.Field, strings.Join(placeholders, ",")))
			default:
				parts = append(parts, fmt.Sprintf("%s %s $%d", c.Field, c.Operator, argPos))
				b.args = append(b.args, c.Value)
				argPos++
			}
		}
		sb.WriteString(strings.Join(parts, " AND "))
	}

	if len(b.orders) > 0 {
		sb.WriteString(" ORDER BY ")
		var os []string
		for _, o := range b.orders {
			os = append(os, fmt.Sprintf("%s %s", o.Field, o.Direction))
		}
		sb.WriteString(strings.Join(os, ", "))
	}

	if b.limit > 0 {
		sb.WriteString(fmt.Sprintf(" LIMIT %d", b.limit))
	}
	if b.offset > 0 {
		sb.WriteString(fmt.Sprintf(" OFFSET %d", b.offset))
	}

	return sb.String(), b.args
}

func (b *Builder) CountQuery() (string, []interface{}) {
	cur := b.columns
	b.columns = []string{"COUNT(*)"}
	cl := b.limit
	co := b.offset
	cord := b.orders
	b.limit = 0
	b.offset = 0
	b.orders = nil

	q, args := b.Build()

	b.columns = cur
	b.limit = cl
	b.offset = co
	b.orders = cord
	return q, args
}
