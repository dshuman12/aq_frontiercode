# Authoring adversarial tasks for `converge`

This guide covers the mechanics of building a SWE-Bench-Pro / Silver task
against this repo. For the acceptance bar, see Silver's 11 criteria.

## 1. Scaffold

From the repo root:

```bash
python3 scripts/scaffold_task.py <task-name>
```

`<task-name>` is lowercase, 3-40 chars, `[a-z0-9_-]` only. The script
copies `tasks/_template/` into `tasks/<task-name>/` and nudges the
prose files so `TASK TITLE` / `TASK NAME` placeholders are replaced
with your task name.

## 2. What each file does

Inside `tasks/<task-name>/`:

| File | Role |
| --- | --- |
| `task.toml` | Author metadata + declared difficulty / category. |
| `instruction.md` | Prose handed to the agent. Public-API only, no hints about the fix. 150-350 words. |
| `reference_plan.md` | Reviewer-facing notes: root cause, fix in words, what each test covers. |
| `solution/solve.sh` | A `bash` heredoc holding a unified diff. Must apply cleanly at `base_commit` with `git apply`. |
| `environment/Dockerfile` | `FROM __APPROVED_REPO_IMAGE_HERE__` plus `WORKDIR /app/converge`. The verify script rewrites the FROM to a local image tag. |
| `tests/config.json` | `repo`, `base_commit`, `test_patch`, `fail_to_pass`, `pass_to_pass`, `selected_test_files_to_run`. |
| `tests/run_script.sh` | One-line `pytest -vs` on the selected test file(s). |
| `tests/test.sh` | Self-contained harness. Inlines the test file via heredoc, inlines FAIL/PASS arrays, writes reward to `/logs/verifier/reward.txt`. Must work with AND without `TEST_PATCH`. |
| `tests/parser.py` | Generic pytest-result parser; leave as-is. |

## 3. Quality bar

- `fail_to_pass` >= 4 distinct tests covering distinct facets of the bug.
- `pass_to_pass` >= 6 tests confirming adjacent / invariant behavior
  (commutativity, idempotence, other CRDTs, etc.) does not regress.
- `solution/solve.sh` must apply at `base_commit` with `git apply` and
  produce a passing test run.
- `tests/test.sh` must be fully self-contained: running it with
  `TEST_PATCH` unset should still execute pytest and emit a reward.
- Instruction uses only public API names. No mentions of private
  helpers or fix locations.

## 4. Verify locally

```bash
export ANTHROPIC_API_KEY=sk-ant-...
bash scripts/verify_task_with_sonnet46.sh <task-name>
```

Reward `0` means sonnet-4.6 failed (good for an adversarial task);
reward `1` means the task is too easy and should be dropped or
hardened. For the batch run use `scripts/probe_all_tasks.sh`.

## 5. Submit

Zip the task directory and upload per Silver's intake flow. Ensure the
task satisfies Silver's 11 criteria before submission.
