# TASK TITLE — one concise sentence describing the symptom

<!--
  Write to the AGENT. This is what they'll read cold.
  Avoid: pseudocode, function names from the fix, implementation hints.
  Target: 150-350 words. Short paragraphs. Optional small code block(s).
-->

Opening paragraph: which CRDT / subsystem this involves (counter, register,
set, sequence, causality clock, ...) and at a high level what currently
misbehaves under concurrent or replayed operations. One or two sentences.

## Current behavior

A short runnable snippet that reproduces the bug using ONLY the public API
exported from `converge`. Show the current output and call out what's
wrong. Prefer scenarios that stress the convergence property — two
replicas, concurrent mutations, merge, observe divergence.

```python
from converge import SomeCRDT

a = SomeCRDT(replica_id="a")
b = SomeCRDT(replica_id="b")

# ... concurrent mutations on a and b ...

a.merge(b)
b.merge(a)
print(a.value(), b.value())   # -> diverges          (this is the bug)
```

Optionally a second example covering a different facet of the same bug
(e.g. a commutativity or idempotence violation). Keep each snippet small.

## Expected behavior

Describe what SHOULD be true after the fix in terms of observable
behavior. Be concrete: include specific inputs and the outputs the
agent's code has to produce. Reference the public API, never internal
names.

State any properties the fix must preserve — "existing CRDTs must remain
commutative / associative / idempotent", "no other operators change
their semantics", "existing tests must still pass". This frames the
scope so the agent doesn't over-rewrite.
