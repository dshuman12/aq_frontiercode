# Task template

Copy this directory via `scripts/scaffold_task.py`, don't edit it in place.

After copying, the files you need to fill in are marked with `__PLACEHOLDER__`
or `TASK TITLE` / `TASK NAME`:

- `instruction.md` — prose for the agent
- `reference_plan.md` — internal notes for the reviewer
- `task.toml` — author metadata + difficulty
- `environment/Dockerfile` — `FROM __APPROVED_REPO_IMAGE_HERE__`
- `solution/solve.sh` — the fix as a `git apply` patch
- `tests/run_script.sh` — the test file path to invoke
- `tests/config.json` — `base_commit`, `test_patch`, and test-name lists
- `tests/test.sh` — inlined test body + FAIL_TO_PASS / PASS_TO_PASS arrays

`tests/parser.py` is generic — you almost never modify it.

See `../../docs/TASK_AUTHORING.md` for the full walkthrough.
