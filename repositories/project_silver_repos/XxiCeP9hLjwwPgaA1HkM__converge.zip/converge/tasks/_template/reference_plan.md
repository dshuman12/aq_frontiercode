# Reference plan — TASK TITLE

<!--
  Internal-facing. The reviewer reads this when the rubric LLM is uncertain.
  Explain the bug honestly, the fix concisely, and why the tests pin down
  the right surface.
-->

## Root cause

Which file (e.g. `converge/counters/pncounter.py`), which function, which
line(s). What's wrong about it. Why it's non-obvious — "the symptom
appears during merge but the cause is in the apply path, and these two
places are L lines / S subsystems apart". The "why hard" paragraph
justifies the difficulty claim.

Include a short code excerpt of the buggy region if it helps the
reviewer orient.

## Fix

What the correct change is, in words (not diff). Keep under 100 words.
Mention any "wrong-but-plausible" fix an agent might try that would NOT
make the tests pass — this is useful context for why the fail_to_pass
set is the shape it is. For CRDT tasks, be explicit about which algebraic
law (commutativity, associativity, idempotence, monotonicity) the bug
violates and which the fix restores.

## What the tests cover

- **fail_to_pass** (N tests): a sentence per test explaining which facet
  of the bug it exercises. The set should feel comprehensive — not
  redundant, not gap-ridden. For CRDTs, include at least one property-
  style test (e.g. merge is commutative across a permuted op stream).
- **pass_to_pass** (M tests): a sentence on what adjacent behavior must
  NOT regress.

Close with a one-sentence rubric defense: why this task satisfies
criteria 5 (behavioral tests), 6 (outcome-verified instruction), and 10
(anti-cheat — the tests can't be gamed).
