#!/bin/bash
# Self-contained test harness. Works in both Silver's server runtime AND
# Harbor's ad-hoc runner.
#
# Behavior:
#   - If TEST_PATCH is set (Silver), apply it via `git apply --allow-empty`.
#   - Otherwise (Harbor), inline the test file via heredoc below so pytest
#     has something to run.
#   - Run pytest, parse -vs output, compare against inlined
#     FAIL_TO_PASS / PASS_TO_PASS arrays, and write 1/0 reward to
#     /logs/verifier/reward.txt.
#
# Copy this per-task; fill in:
#   (1) TEST_FILE path
#   (2) the heredoc body (the full source of tests/<TEST_FILE>.py)
#   (3) FAIL_TO_PASS / PASS_TO_PASS arrays — keep in sync with config.json
set -euo pipefail

cd /app/converge

if [ -n "${TEST_PATCH:-}" ]; then
    echo "$TEST_PATCH" | git apply --allow-empty || true
fi

# TODO: replace with the path of the test file added by test_patch.
TEST_FILE="tests/PATH_TO_NEW_TEST.py"
mkdir -p "$(dirname "$TEST_FILE")"

# TODO: paste the full body of the test file between the TEST_CONTENT_EOF
# markers. This is what Harbor will run when TEST_PATCH isn't provided.
cat > "$TEST_FILE" <<'TEST_CONTENT_EOF'
"""Placeholder test file. Replace with your task's real test source."""
from __future__ import annotations

# import converge
# from converge import ...


def test_fail_name_1():
    assert False, "replace me"


def test_fail_name_2():
    assert False, "replace me"


def test_pass_name_1():
    pass


def test_pass_name_2():
    pass
TEST_CONTENT_EOF

OUTPUT=$(python -m pytest "$TEST_FILE" -vs 2>&1) || true
echo "$OUTPUT"

mkdir -p /logs/verifier

RESULT=$(echo "$OUTPUT" | python3 -c "
import sys, re

output = sys.stdin.read()
results = {}
for line in output.splitlines():
    m = re.match(r'^(tests/\S+::\S+)\s+(PASSED|FAILED|ERROR)', line)
    if m:
        results[m.group(1)] = m.group(2)

# TODO: replace with your own test names. Keep in sync with
# tests/config.json's fail_to_pass and pass_to_pass arrays.
FAIL_TO_PASS = [
    'tests/PATH_TO_NEW_TEST.py::test_fail_name_1',
    'tests/PATH_TO_NEW_TEST.py::test_fail_name_2',
]
PASS_TO_PASS = [
    'tests/PATH_TO_NEW_TEST.py::test_pass_name_1',
    'tests/PATH_TO_NEW_TEST.py::test_pass_name_2',
]

all_pass = True
for t in FAIL_TO_PASS + PASS_TO_PASS:
    status = results.get(t)
    if status != 'PASSED':
        all_pass = False
        print(f'FAIL: {t} -> {status}', file=sys.stderr)

print('1' if all_pass else '0')
")

echo "$RESULT" > /logs/verifier/reward.txt
echo "Reward: $RESULT"
