#!/bin/bash
set -e

cd /app/converge

# Replace tests/PATH_TO_NEW_TEST.py with the actual path of the test file
# added by test_patch in config.json. Multiple files space-separated.
python -m pytest tests/PATH_TO_NEW_TEST.py -vs 2>&1
