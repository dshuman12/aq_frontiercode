"""Parse pytest -vs output into {name, status} records."""
import json
import re
import sys


def parse_pytest_output(output: str) -> list[dict[str, str]]:
    results = []
    for line in output.splitlines():
        match = re.match(r'^(tests/\S+::\S+)\s+(PASSED|FAILED|ERROR)', line)
        if match:
            results.append({'name': match.group(1), 'status': match.group(2)})
    return results


if __name__ == '__main__':
    print(json.dumps(parse_pytest_output(sys.stdin.read()), indent=2))
