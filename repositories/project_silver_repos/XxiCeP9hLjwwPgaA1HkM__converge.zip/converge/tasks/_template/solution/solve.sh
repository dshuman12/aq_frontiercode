#!/bin/bash
set -euo pipefail

cd /app/converge

# Paste the unified diff produced by `git diff` between the __SOLUTION__
# markers. The patch must apply cleanly at the base_commit declared in
# tests/config.json.
cat > /tmp/solution.patch <<'__SOLUTION__'
diff --git a/path/to/file.py b/path/to/file.py
--- a/path/to/file.py
+++ b/path/to/file.py
@@ -LINENO,N +LINENO,N @@
 unchanged context
-   buggy line
+   fixed line
 unchanged context
__SOLUTION__

git apply --verbose /tmp/solution.patch
