#!/bin/bash
# Run a converge task through Harbor locally using mini-swe-agent +
# claude-sonnet-4.6, the same combo the Silver server uses for the
# easiness probe. Confirms whether the task is still solvable, and if
# it is, whether sonnet-4.6 produces the expected fix.
#
# Usage:
#   scripts/verify_task_with_sonnet46.sh <TASK_NAME>
#
# Runs one trial (same as Silver's easiness probe). For the difficulty
# probe you'd run 10 (set TRIALS=10).
#
# Requires:
#   - Docker Desktop running
#   - uv installed (https://docs.astral.sh/uv/)
#   - ANTHROPIC_API_KEY exported (real API key, not Claude Code's
#     ANTHROPIC_AUTH_TOKEN)
#
# The script:
#   1. Installs harbor if missing (uv tool).
#   2. Builds a local converge image (the approved Silver image isn't
#      accessible outside the server).
#   3. Creates a temp task dir with the Dockerfile's FROM line swapped
#      to the local image.
#   4. Runs `harbor run -p <tmp-task> -a mini-swe-agent` with
#      claude-sonnet-4.6.
#   5. Reports reward + diffs.
#
# KNOWN ISSUE (corp network): apt-based Dockerfile steps can fail on
# Visa corp network because package mirrors are blocked. If the image
# build at step 2 fails with apt/DNS errors, retry off-corp (personal
# hotspot) or prebuild on a clean network and docker load here.

set -euo pipefail

if [ $# -lt 1 ]; then
    echo "usage: $0 <task-name>" >&2
    exit 2
fi

TASK="$1"

# Resolve repo root as the parent of scripts/. This way the script works
# regardless of the absolute path the user checked converge out at.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(dirname "$SCRIPT_DIR")"
TASK_DIR="$REPO_DIR/tasks/$TASK"

if [ ! -d "$TASK_DIR" ]; then
    echo "no such task: $TASK_DIR" >&2
    exit 1
fi

if ! docker info >/dev/null 2>&1; then
    echo "error: docker daemon not running. Start Docker Desktop first." >&2
    exit 1
fi

if [ -z "${ANTHROPIC_API_KEY:-}" ]; then
    echo "error: ANTHROPIC_API_KEY not set." >&2
    echo "Use a real API key (Console -> API Keys)." >&2
    echo "Note: Claude Code's ANTHROPIC_AUTH_TOKEN is different -- not usable here." >&2
    exit 1
fi

# Step 1: harbor
if ! command -v harbor >/dev/null 2>&1; then
    echo "installing harbor via uv..."
    uv tool install harbor
fi

# Step 2: build the converge image locally
LOCAL_IMAGE="converge-repo:verify"
if ! docker image inspect "$LOCAL_IMAGE" >/dev/null 2>&1; then
    echo "building local converge image..."
    (cd "$REPO_DIR" && docker build -t "$LOCAL_IMAGE" .)
fi

# Step 3: temp task dir with swapped FROM
STAGING="$(mktemp -d)"
trap 'rm -rf "$STAGING"' EXIT
cp -a "$TASK_DIR/." "$STAGING/"
sed -i '' "s|__APPROVED_REPO_IMAGE_HERE__|$LOCAL_IMAGE|" "$STAGING/environment/Dockerfile"
echo "task staged at $STAGING"
echo "Dockerfile FROM: $(grep ^FROM "$STAGING/environment/Dockerfile")"

# Step 4: run harbor with mini-swe-agent + sonnet-4.6
echo
echo "=== Running easiness probe (1 trial) ==="
echo "If you want the difficulty probe, set TRIALS=10."
TRIALS="${TRIALS:-1}"

harbor run \
    -p "$STAGING" \
    -a mini-swe-agent \
    --agent-arg "model_name=anthropic/claude-sonnet-4-5-20250929" \
    --n-trials "$TRIALS" \
    2>&1 | tee "$STAGING/harbor.log"

# Step 5: reward + summary
echo
echo "=== Results ==="
JOBS_DIR="$(ls -dt jobs/*/ 2>/dev/null | head -1)"
if [ -n "$JOBS_DIR" ]; then
    REWARD_FILE=$(find "$JOBS_DIR" -name reward.txt | head -1)
    [ -n "$REWARD_FILE" ] && echo "reward: $(cat $REWARD_FILE)"
    TEST_OUT=$(find "$JOBS_DIR" -name test-stdout.txt | head -1)
    if [ -n "$TEST_OUT" ]; then
        echo
        echo "--- final test stdout (tail) ---"
        tail -40 "$TEST_OUT"
    fi
    # Find the agent's diff if the trajectory logged it
    TRAJ=$(find "$JOBS_DIR" -name "*.jsonl" -o -name "trajectory*" | head -1)
    [ -n "$TRAJ" ] && echo && echo "trajectory: $TRAJ"
fi

echo
echo "To re-run: bash $0 $TASK"
echo "For difficulty probe (10 trials): TRIALS=10 bash $0 $TASK"
