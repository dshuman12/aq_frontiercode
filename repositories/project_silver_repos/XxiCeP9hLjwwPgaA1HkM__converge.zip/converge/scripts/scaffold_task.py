#!/usr/bin/env python3
"""Copy tasks/_template/ into a new task directory.

Usage: python3 scripts/scaffold_task.py <task-name>

Rules for <task-name>:
- lowercase
- words separated by dashes or underscores
- 3-40 chars
- no path separators
"""
from __future__ import annotations

import re
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TEMPLATE = ROOT / "tasks" / "_template"

NAME_RE = re.compile(r"^[a-z][a-z0-9_-]{2,39}$")


def main() -> int:
    if len(sys.argv) != 2:
        print(__doc__, file=sys.stderr)
        return 2

    name = sys.argv[1]
    if not NAME_RE.match(name):
        print(
            f"bad task name {name!r}: must be lowercase, 3-40 chars, "
            f"[a-z0-9_-] only",
            file=sys.stderr,
        )
        return 2

    dst = ROOT / "tasks" / name
    if dst.exists():
        print(f"task already exists: {dst}", file=sys.stderr)
        return 1

    if not TEMPLATE.is_dir():
        print(f"template missing at {TEMPLATE}", file=sys.stderr)
        return 1

    shutil.copytree(TEMPLATE, dst)

    # Substitute the placeholder "TASK NAME" / "TASK TITLE" tokens in the
    # two prose files so the authored task dir starts with its own name
    # in obvious places. Authors still rewrite the prose entirely — this
    # is just a nudge that the dir is no longer the template.
    for rel in ("instruction.md", "reference_plan.md"):
        p = dst / rel
        if p.exists():
            text = p.read_text()
            text = text.replace("TASK TITLE", name).replace("TASK NAME", name)
            p.write_text(text)

    # Strip the template's README so the new task dir is clean.
    readme = dst / "README.md"
    if readme.exists():
        readme.unlink()

    print(f"created {dst.relative_to(ROOT)}")
    print()
    print("next steps:")
    print(f"  1. write the failing test in tests/... (inside the converge repo)")
    print(f"  2. fill in {dst.relative_to(ROOT)}/instruction.md")
    print(f"  3. fill in {dst.relative_to(ROOT)}/reference_plan.md")
    print(f"  4. generate the patch and paste into solution/solve.sh")
    print(f"  5. update tests/config.json (base_commit + test_patch + test names)")
    print(f"  6. inline the test body + FAIL_TO_PASS/PASS_TO_PASS in tests/test.sh")
    print(f"  7. verify locally: bash scripts/verify_task_with_sonnet46.sh {name}")
    print(f"  8. zip and upload")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
