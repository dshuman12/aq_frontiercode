#!/bin/bash
# Probe every non-template task in tasks/ against sonnet-4.6, one trial
# each, in parallel. Writes per-task logs to probe_logs/<task>.log and a
# summary to probe_logs/summary.txt.
#
# Usage:
#   export ANTHROPIC_API_KEY=...    # real API key from Console
#   bash scripts/probe_all_tasks.sh
#
# Runs harbor jobs concurrently -- each is a docker container + API calls.
# Wall time scales with task count and Anthropic tier; expect a few
# minutes per batch of ~6 tasks.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(dirname "$SCRIPT_DIR")"
cd "$ROOT"

# Enumerate tasks dynamically, skipping the template.
TASKS=()
for d in tasks/*/; do
    name="$(basename "$d")"
    [ "$name" = "_template" ] && continue
    TASKS+=("$name")
done

if [ ${#TASKS[@]} -eq 0 ]; then
    echo "no tasks found under tasks/ (only _template present?)" >&2
    exit 0
fi

if [ -z "${ANTHROPIC_API_KEY:-}" ]; then
    echo "error: ANTHROPIC_API_KEY not set" >&2
    exit 1
fi
if ! command -v harbor >/dev/null 2>&1; then
    echo "error: harbor not on PATH. Install: uv tool install harbor" >&2
    exit 1
fi
if ! docker info >/dev/null 2>&1; then
    echo "error: docker not running" >&2
    exit 1
fi

# Pre-build the image once so parallel runs don't race to build it.
LOCAL_IMAGE="converge-repo:verify"
if ! docker image inspect "$LOCAL_IMAGE" >/dev/null 2>&1; then
    echo "building local converge image..."
    docker build -t "$LOCAL_IMAGE" .
fi

mkdir -p probe_logs
: > probe_logs/summary.txt

run_one() {
    local task="$1"
    local task_dir="tasks/$task"
    local staging; staging="$(mktemp -d)"
    trap 'rm -rf "$staging"' RETURN

    cp -a "$task_dir/." "$staging/"
    sed -i '' "s|__APPROVED_REPO_IMAGE_HERE__|$LOCAL_IMAGE|" "$staging/environment/Dockerfile"

    local log="probe_logs/$task.log"
    echo "[$task] starting at $(date +%H:%M:%S)" | tee -a probe_logs/summary.txt
    harbor run \
        -p "$staging" \
        -a mini-swe-agent \
        --agent-arg "model_name=anthropic/claude-sonnet-4-5-20250929" \
        --n-trials 1 \
        >"$log" 2>&1 || true

    # Parse reward from harbor output.
    local reward="unknown"
    if grep -q "reward = 1.0" "$log"; then
        reward=1
    elif grep -q "reward = 0.0" "$log"; then
        reward=0
    fi
    echo "[$task] done at $(date +%H:%M:%S) -- reward=$reward" | tee -a probe_logs/summary.txt
}

echo "dispatching ${#TASKS[@]} parallel probes..."
for task in "${TASKS[@]}"; do
    run_one "$task" &
done
wait

echo
echo "=== SUMMARY ==="
cat probe_logs/summary.txt
echo
echo "Keep tasks where reward=0 (sonnet failed). Drop tasks where reward=1."
