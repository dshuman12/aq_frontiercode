# converge — design spec

A Python CRDT library implementing state-based conflict-free replicated data types. Build target: approx. 2.5–3 k source LOC + 1.5 k test LOC, Python 3.11, stdlib only (no third-party runtime deps).

## Module layout

```
converge/
  __init__.py           # public API re-exports
  errors.py             # ConvergeError (base), CausalError, ReplicaError
  causality/
    __init__.py
    vector_clock.py     # VectorClock
    dotted_version_vector.py  # DottedVersionVector (DVV)
  counters/
    __init__.py
    gcounter.py         # GCounter (grow-only)
    pncounter.py        # PNCounter (positive + negative)
  sets/
    __init__.py
    twopset.py          # 2P-Set (monotone add/remove with tombstones)
    orset.py            # OR-Set (observed-remove with dots)
    lwwset.py           # LWW-Set
  registers/
    __init__.py
    lwwregister.py      # LWW-Register
    mvregister.py       # Multi-Value Register (uses DVV)
  sequence/
    __init__.py
    rga.py              # RGA (Replicated Growable Array)
tests/
  __init__.py
  test_*.py (per type)
  test_invariants.py    # cross-type property tests
```

## Universal contract

Every CRDT class exposes at minimum:

- a constructor `__init__(self, replica_id: str, ...)` — replica_id is an opaque string identifier
- one or more mutation methods, each of which is **local** (affects only `self`) and does **not** take a `replica_id` argument (the CRDT's own `replica_id` is used)
- `value(self) -> <observed-value-type>` — the user-facing observed state
- `merge(self, other: SameType) -> None` — **in-place**, idempotent, commutative, associative merge of `other`'s state into `self`
- `to_dict(self) -> dict` / classmethod `from_dict(cls, d: dict) -> Self` — JSON-safe serialization roundtrip (all values nested inside are JSON-safe or trivially serializable)
- `__eq__` and `__repr__`

**Every merge must satisfy:**
1. **Idempotence** — `a.merge(deepcopy(a))` leaves `a.value()` unchanged
2. **Commutativity** — after `a.merge(b)` vs `b.merge(a)` (with deep copies), the resulting `.value()` is equal
3. **Associativity** — `(a ∪ b) ∪ c == a ∪ (b ∪ c)` on values

**Every merge must reject type mismatches**: `a.merge(b)` where `type(a) != type(b)` raises `TypeError`.

Replica-id argument in constructor is non-empty string. Empty string or non-str → `ReplicaError` from `converge.errors`.

## Types — API details

### `VectorClock` (causality/vector_clock.py)

Map from `replica_id: str` to `count: int`.

```python
VectorClock()                                  # empty
VectorClock({"a": 1, "b": 3})                 # initial counts
vc.get(replica_id) -> int                     # 0 if missing
vc.increment(replica_id) -> None              # self[replica_id] += 1
vc.merge(other: VectorClock) -> None          # in-place componentwise max
vc.descends(other: VectorClock) -> bool       # self[r] >= other[r] for every r
vc.dominates(other: VectorClock) -> bool      # descends and not equal
vc.is_concurrent_with(other) -> bool          # neither dominates the other, and unequal
vc == other                                    # equal counts (missing keys default 0)
vc.to_dict() / VectorClock.from_dict()
```

Note: empty VectorClock is identity for merge and descends every other empty clock.

### `DottedVersionVector` (causality/dotted_version_vector.py)

A vector clock plus a set of "dots" (replica_id, counter) that are NOT contiguous with the contiguous base.

```python
dvv = DottedVersionVector()
dvv.observe(replica_id, counter) -> None    # add a dot; if contiguous with base, compact into base
dvv.next_dot(replica_id) -> tuple[str, int] # return a fresh (replica, counter) that extends base
dvv.contains_dot(replica_id, counter) -> bool
dvv.merge(other: DottedVersionVector) -> None  # merge bases and dots, recompact
dvv.to_dict() / from_dict()
```

Internally: `base: dict[str, int]` (contiguous prefix per replica), `dots: set[tuple[str, int]]` (holes).

### `GCounter` (counters/gcounter.py)

```python
GCounter(replica_id: str)
g.increment(n: int = 1) -> None               # ValueError if n < 0
g.value() -> int                               # sum over all replicas' counts
g.merge(other: GCounter) -> None               # per-replica max
g.to_dict() / from_dict()
```

### `PNCounter` (counters/pncounter.py)

Two GCounters internally: `pos`, `neg`. `value() == pos.value() - neg.value()`.

```python
PNCounter(replica_id: str)
p.increment(n: int = 1) -> None                # ValueError if n < 0
p.decrement(n: int = 1) -> None                # ValueError if n < 0
p.value() -> int
p.merge(other: PNCounter) -> None
```

### `TwoPSet` (sets/twopset.py)

Two sets internally: `added`, `removed`. `contains(x) == (x in added) and (x not in removed)`.

```python
TwoPSet(replica_id: str)
s.add(element) -> None
s.remove(element) -> None                      # ConvergeError if element was never added
s.contains(element) -> bool
s.value() -> frozenset
s.merge(other: TwoPSet) -> None                # union of added, union of removed
```

Once removed, an element cannot be re-added. That's the 2P-Set semantic.

### `ORSet` (sets/orset.py)

Observed-Remove set: each add produces a unique dot `(replica_id, local_counter)`. Remove removes all dots currently associated with the element. On merge, adds survive if their dots weren't removed on the other side.

```python
ORSet(replica_id: str)
s.add(element) -> None                         # assigns a fresh dot for this replica
s.remove(element) -> None                      # removes all currently observed dots for element
s.contains(element) -> bool
s.value() -> frozenset
s.merge(other: ORSet) -> None
```

Internal state: `elements: dict[hashable, set[tuple[str, int]]]` (element → set of dots), `tombstones: set[tuple[str, int]]` (removed dots).

Merge rule: for each element, the alive dot set = union of both sides' dots MINUS union of both sides' tombstones. An element is present iff its alive dot set is non-empty.

### `LWWSet` (sets/lwwset.py)

Each element tracks `add_ts` and `remove_ts` (logical timestamps with replica-id tiebreak). Element present iff `add_ts > remove_ts` (with tiebreak: on equal ts, max replica_id string wins — configurable, but default is max replica_id).

```python
LWWSet(replica_id: str, clock: Callable[[], int] | None = None)
s.add(element, ts: int | None = None) -> None
s.remove(element, ts: int | None = None) -> None
s.contains(element) -> bool
s.value() -> frozenset
s.merge(other) -> None
```

If `ts` is None, use `clock()` (default: monotonic counter per instance).

### `LWWRegister` (registers/lwwregister.py)

Single value with `(timestamp, replica_id)`.

```python
LWWRegister(replica_id: str, initial: Any = None, ts: int = 0)
r.set(value, ts: int | None = None) -> None    # clock() if ts is None
r.value() -> Any
r.merge(other) -> None                         # pick higher (ts, replica_id)
```

### `MVRegister` (registers/mvregister.py)

Multi-value register: keeps all concurrent values. Set operation happens within a DottedVersionVector; merge drops values whose dots are dominated by the other side's DVV.

```python
MVRegister(replica_id: str)
r.set(value) -> None                            # assigns fresh dot, drops values dominated by self DVV
r.values() -> list                              # current concurrent values
r.merge(other) -> None
```

Internal: `entries: list[tuple[tuple[str, int], Any]]` of `((replica, counter), value)`, plus a `DottedVersionVector` tracking observed dots.

### `RGA` (sequence/rga.py)

Replicated Growable Array. Each node has a unique id (replica_id, counter) and an optional tombstone flag.

```python
RGA(replica_id: str)
r.insert_at(pos: int, element) -> None         # pos is in visible (non-tombstoned) positions
r.delete_at(pos: int) -> None                  # marks visible position as tombstoned
r.to_list() -> list
r.merge(other) -> None
r.__len__() -> int                             # visible (non-tombstoned) length
```

Ordering:
- Internal representation: ordered list of nodes `(id, parent_id, element, tombstoned)`
- Insertion uses `parent_id` to anchor between existing nodes
- Tiebreak rule when multiple concurrent inserts share the same parent: sort by `id` (lexicographic on replica_id, then counter) in **descending** order (standard RGA convention — the "youngest" sibling, by id, comes first among equal-parent siblings)
- Tombstoned nodes remain in the internal structure to preserve positioning of concurrent inserts that anchor on them.

## Errors (errors.py)

```python
class ConvergeError(Exception): pass
class CausalError(ConvergeError): pass       # e.g. referencing an unknown dot
class ReplicaError(ConvergeError): pass      # e.g. empty replica_id
```

## Quality bar for implementations

- Every class has a top-of-module docstring explaining the CRDT semantics in 3–6 lines (not a research paper; enough for a reviewer).
- Every public method has a one-line docstring minimum, and explains any non-obvious invariant in 2–4 lines.
- No `assert` for argument validation — raise `ConvergeError`/`TypeError`/`ValueError` explicitly.
- No I/O, no time-based non-determinism (except `LWWRegister`/`LWWSet` which accept an explicit `clock` callable; default is a monotonic counter per instance).
- Deterministic behavior under repeated merges.
- Hashable restriction: `ORSet`, `TwoPSet`, `LWWSet` element must be hashable (clearly document this).
- `RGA` and `MVRegister` can hold any element (hashable or not).

## pyproject.toml

- name = "converge"
- version = "0.1.0"
- Python >= 3.11
- no runtime deps
- dev deps: pytest == 8.3.3, pytest-cov == 5.0.0

## Dockerfile

Mirror rivulet's style:
- FROM python:3.11.9-slim-bookworm
- Install git + ca-certificates (for per-task git reset)
- Pin pip==24.2, setuptools==75.1.0, wheel==0.44.0
- Pin pytest==8.3.3, pytest-cov==5.0.0
- PYTHONPATH=/app/converge
- WORKDIR /app/converge
- COPY . /app/converge
- git init + safe.directory + user.email + user.name (global config)
- CMD ["pytest", "-q"]

## README.md

Short: what converge is, install, quickstart example per CRDT type, build/test instructions, license line.

## LICENSE

MIT.

## .gitignore

Standard Python: __pycache__, *.egg-info, .pytest_cache, .coverage, dist, build, .venv, env/

## Tests

- `tests/test_invariants.py`: property-based (use stdlib `random` with fixed seed) idempotence / commutativity / associativity tests over all CRDT types
- `tests/test_<type>.py`: specific semantic tests (e.g., OR-Set "concurrent add and remove → add wins", RGA "two concurrent inserts at same position resolve deterministically")
- Total: roughly 1.5 k test LOC
- All tests must pass deterministically
- Use `pytest.parametrize` liberally

## Invariants to pin in tests

For EVERY CRDT:
- Idempotence of merge
- Commutativity of merge
- Associativity of merge  
- Round-trip via `to_dict` / `from_dict`
- Merging an empty instance is a no-op
- Type mismatch raises TypeError

Per-CRDT specific invariants called out in test files.

## Non-goals

- Op-based CRDTs (delta-CRDTs are a later addition)
- Network transport
- Byzantine fault tolerance
- Garbage collection of tombstones (out of scope for v0.1)
