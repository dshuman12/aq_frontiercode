"""Tests for :class:`converge.AntiEntropyRound`."""
from __future__ import annotations

import pytest

from converge import AntiEntropyRound, GCounter
from converge.errors import ReplicaError


def _build_group(n: int = 3) -> dict[str, GCounter]:
    """Return n GCounters with distinct replica ids."""
    return {chr(ord("A") + i): GCounter(chr(ord("A") + i)) for i in range(n)}


def test_anti_entropy_pairwise_init():
    group = _build_group(3)
    coord = AntiEntropyRound(group, mode="pairwise", seed=0)
    assert coord.mode == "pairwise"
    assert coord.seed == 0
    assert coord.round_index == 0
    assert len(coord) == 3


def test_anti_entropy_invalid_mode_raises():
    group = _build_group(2)
    with pytest.raises(ValueError):
        AntiEntropyRound(group, mode="bogus")


def test_anti_entropy_round_robin_converges_in_one_tick():
    group = _build_group(3)
    group["A"].increment(1)
    group["B"].increment(2)
    group["C"].increment(3)

    coord = AntiEntropyRound(group, mode="round_robin", seed=0)
    coord.tick()
    assert coord.converged()
    expected = 1 + 2 + 3
    for g in group.values():
        assert g.value() == expected


def test_anti_entropy_pairwise_converges_after_rounds():
    group = _build_group(3)
    group["A"].increment(1)
    group["B"].increment(2)
    group["C"].increment(3)

    coord = AntiEntropyRound(group, mode="pairwise", seed=42)
    # Run many rounds with a deterministic seed
    coord.run(rounds=50)
    assert coord.converged()


def test_anti_entropy_pairwise_is_deterministic_with_seed():
    group1 = _build_group(3)
    group2 = _build_group(3)
    group1["A"].increment(10)
    group2["A"].increment(10)

    c1 = AntiEntropyRound(group1, mode="pairwise", seed=123)
    c2 = AntiEntropyRound(group2, mode="pairwise", seed=123)

    pairs1 = []
    pairs2 = []
    for _ in range(5):
        pairs1.extend(c1.tick())
        pairs2.extend(c2.tick())
    assert pairs1 == pairs2


def test_anti_entropy_converged_returns_true_on_empty_and_single():
    coord = AntiEntropyRound({}, mode="pairwise", seed=0)
    assert coord.converged()
    single = {"A": GCounter("A")}
    coord = AntiEntropyRound(single, mode="pairwise", seed=0)
    assert coord.converged()


def test_anti_entropy_converged_false_before_tick():
    group = _build_group(2)
    group["A"].increment(1)
    group["B"].increment(2)
    coord = AntiEntropyRound(group, mode="pairwise", seed=0)
    assert not coord.converged()


def test_anti_entropy_add_replica():
    group = _build_group(2)
    coord = AntiEntropyRound(group, mode="pairwise", seed=0)
    coord.add_replica("C", GCounter("C"))
    assert "C" in coord
    assert len(coord) == 3


def test_anti_entropy_add_duplicate_replica_raises():
    group = _build_group(2)
    coord = AntiEntropyRound(group, mode="pairwise", seed=0)
    with pytest.raises(ReplicaError):
        coord.add_replica("A", GCounter("A"))


def test_anti_entropy_drop_replica():
    group = _build_group(3)
    coord = AntiEntropyRound(group, mode="pairwise", seed=0)
    coord.drop_replica("C")
    assert "C" not in coord
    assert len(coord) == 2


def test_anti_entropy_drop_unknown_replica_raises():
    group = _build_group(2)
    coord = AntiEntropyRound(group, mode="pairwise", seed=0)
    with pytest.raises(ReplicaError):
        coord.drop_replica("Z")


def test_anti_entropy_tick_returns_pair_list():
    group = _build_group(3)
    coord = AntiEntropyRound(group, mode="round_robin", seed=0)
    pairs = coord.tick()
    # round_robin: 3 replicas => 3 ordered pairs (AB, AC, BC)
    assert len(pairs) == 3


def test_anti_entropy_tick_single_replica_noop():
    group = {"A": GCounter("A")}
    coord = AntiEntropyRound(group, mode="pairwise", seed=0)
    pairs = coord.tick()
    assert pairs == []


def test_anti_entropy_run_increments_round_counter():
    group = _build_group(3)
    coord = AntiEntropyRound(group, mode="pairwise", seed=0)
    coord.run(rounds=5)
    assert coord.round_index == 5


def test_anti_entropy_crdt_missing_merge_raises():
    class Bad:
        def value(self): return 0

    with pytest.raises(TypeError):
        AntiEntropyRound({"A": Bad()}, mode="pairwise", seed=0)


def test_anti_entropy_pairwise_multi_replica_converges():
    group = _build_group(5)
    for i, rid in enumerate(group):
        group[rid].increment(i + 1)
    coord = AntiEntropyRound(group, mode="pairwise", seed=7)
    coord.run(rounds=100)
    assert coord.converged()
