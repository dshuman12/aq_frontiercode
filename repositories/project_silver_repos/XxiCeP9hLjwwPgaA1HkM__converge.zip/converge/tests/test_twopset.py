"""Tests for :class:`converge.TwoPSet`."""
from __future__ import annotations

from copy import deepcopy

import pytest

from converge import TwoPSet
from converge.errors import ConvergeError, ReplicaError


def test_twop_empty_value():
    s = TwoPSet("r1")
    assert s.value() == frozenset()


def test_twop_add_then_contains():
    s = TwoPSet("r1")
    s.add("apple")
    assert s.contains("apple")
    assert s.value() == frozenset({"apple"})


def test_twop_remove_of_added_element_hides_it():
    s = TwoPSet("r1")
    s.add("apple")
    s.remove("apple")
    assert not s.contains("apple")
    assert s.value() == frozenset()


def test_twop_remove_of_unseen_element_raises_converge_error():
    s = TwoPSet("r1")
    with pytest.raises(ConvergeError):
        s.remove("never-added")


def test_twop_cannot_readd_after_remove():
    s = TwoPSet("r1")
    s.add("apple")
    s.remove("apple")
    s.add("apple")  # this is permitted -- adds are union -- but element stays removed
    assert not s.contains("apple")


def test_twop_remove_is_permanent_across_merges():
    a = TwoPSet("a")
    b = TwoPSet("b")
    a.add("x")
    b.merge(a)         # b observes x
    b.remove("x")      # b tombstones x
    # Concurrently, a re-adds x.
    a.add("x")
    a.merge(b)
    assert "x" not in a.value()


def test_twop_merge_unions_both_added_and_removed():
    a = TwoPSet("a")
    b = TwoPSet("b")
    a.add("x")
    a.add("y")
    b.add("y")
    b.add("z")
    b.remove("y")
    a.merge(b)
    assert a.value() == frozenset({"x", "z"})


def test_twop_merge_type_mismatch_raises():
    s = TwoPSet("r1")
    with pytest.raises(TypeError):
        s.merge("not a set")  # type: ignore[arg-type]


def test_twop_merge_idempotent():
    s = TwoPSet("r1")
    s.add(1)
    s.add(2)
    s.remove(1)
    s.merge(deepcopy(s))
    assert s.value() == frozenset({2})


def test_twop_merge_empty_is_noop():
    s = TwoPSet("r1")
    s.add("x")
    s.merge(TwoPSet("r1"))
    assert s.value() == frozenset({"x"})


def test_twop_merge_commutative_values():
    a = TwoPSet("a")
    b = TwoPSet("b")
    a.add("x")
    b.add("y")
    left = deepcopy(a)
    left.merge(deepcopy(b))
    right = deepcopy(b)
    right.merge(deepcopy(a))
    assert left.value() == right.value()


def test_twop_to_from_dict_roundtrip():
    s = TwoPSet("r1")
    s.add("x")
    s.add("y")
    s.remove("x")
    dup = TwoPSet.from_dict(s.to_dict())
    assert dup.value() == s.value()
    assert dup == s


def test_twop_empty_replica_id_raises():
    with pytest.raises(ReplicaError):
        TwoPSet("")


def test_twop_is_not_hashable():
    with pytest.raises(TypeError):
        hash(TwoPSet("r1"))


def test_twop_unhashable_element_raises():
    s = TwoPSet("r1")
    with pytest.raises(TypeError):
        s.add([1, 2, 3])
