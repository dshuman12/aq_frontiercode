"""Tests for :class:`converge.BCounter` (bounded counter)."""
from __future__ import annotations

from copy import deepcopy

import pytest

from converge import BCounter, BoundedCounter
from converge.errors import ConvergeError, ReplicaError


def test_bcounter_alias_matches_bounded_counter():
    assert BCounter is BoundedCounter


def test_bcounter_empty_value_is_zero():
    bc = BCounter("A")
    assert bc.value() == 0


def test_bcounter_empty_quota_is_zero():
    bc = BCounter("A")
    assert bc.local_quota() == 0


def test_bcounter_increment_grows_value_and_quota():
    bc = BCounter("A")
    bc.increment(5)
    assert bc.value() == 5
    assert bc.local_quota() == 5


def test_bcounter_decrement_within_quota_succeeds():
    bc = BCounter("A")
    bc.increment(5)
    bc.decrement(3)
    assert bc.value() == 2
    assert bc.local_quota() == 2


def test_bcounter_decrement_below_zero_raises():
    # Critical: 5 - 10 must raise, not yield -5.
    bc = BCounter("A")
    bc.increment(5)
    with pytest.raises(ConvergeError):
        bc.decrement(10)
    # State unchanged by the failed operation.
    assert bc.value() == 5


def test_bcounter_decrement_with_no_quota_raises():
    bc = BCounter("A")
    with pytest.raises(ConvergeError):
        bc.decrement(1)


def test_bcounter_transfer_reduces_local_quota():
    bc = BCounter("A")
    bc.increment(5)
    bc.transfer("B", 3)
    # Local quota after transfer = 5 - 3 = 2
    assert bc.local_quota() == 2


def test_bcounter_transfer_preserves_value():
    bc = BCounter("A")
    bc.increment(5)
    bc.transfer("B", 3)
    # Transfers don't change the total value
    assert bc.value() == 5


def test_bcounter_transfer_more_than_quota_raises():
    bc = BCounter("A")
    bc.increment(5)
    with pytest.raises(ConvergeError):
        bc.transfer("B", 10)


def test_bcounter_transfer_to_self_raises():
    bc = BCounter("A")
    bc.increment(5)
    with pytest.raises(ReplicaError):
        bc.transfer("A", 3)


def test_bcounter_transfer_then_merge_gives_remote_quota():
    a = BCounter("A")
    a.increment(5)
    a.transfer("B", 3)

    b = BCounter("B")
    b.merge(a)
    # B should now have quota 3 because A transferred 3 units to it.
    assert b.local_quota("B") == 3
    # A has quota 2 (5 incremented - 3 transferred out)
    assert b.local_quota("A") == 2


def test_bcounter_transfer_merge_then_remote_decrement():
    a = BCounter("A")
    a.increment(5)
    a.transfer("B", 3)

    b = BCounter("B")
    b.merge(a)
    b.decrement(2)
    # Value should be 5 - 2 = 3
    assert b.value() == 3
    # B's remaining quota is 3 - 2 = 1
    assert b.local_quota("B") == 1


def test_bcounter_remote_decrement_limited_by_transferred_quota():
    a = BCounter("A")
    a.increment(5)
    a.transfer("B", 3)

    b = BCounter("B")
    b.merge(a)
    # B has quota 3; decrement by 5 should fail
    with pytest.raises(ConvergeError):
        b.decrement(5)


def test_bcounter_merge_is_idempotent():
    a = BCounter("A")
    a.increment(5)
    a.transfer("B", 2)
    before = deepcopy(a)
    a.merge(deepcopy(a))
    assert a == before


def test_bcounter_merge_is_commutative_on_state():
    a = BCounter("A")
    a.increment(3)
    b = BCounter("B")
    b.increment(4)

    left = deepcopy(a)
    left.merge(deepcopy(b))
    right = deepcopy(b)
    right.merge(deepcopy(a))
    assert left.value() == right.value()
    assert left.contrib == right.contrib
    assert left.decrements == right.decrements


def test_bcounter_merge_is_associative():
    a = BCounter("A")
    a.increment(2)
    b = BCounter("B")
    b.increment(3)
    c = BCounter("C")
    c.increment(4)

    left = deepcopy(a)
    left.merge(deepcopy(b))
    left.merge(deepcopy(c))

    right = deepcopy(a)
    bc = deepcopy(b)
    bc.merge(deepcopy(c))
    right.merge(bc)

    assert left.value() == right.value()


def test_bcounter_merge_type_mismatch_raises():
    bc = BCounter("A")
    with pytest.raises(TypeError):
        bc.merge("nope")  # type: ignore[arg-type]


def test_bcounter_merge_empty_is_noop():
    bc = BCounter("A")
    bc.increment(5)
    before_value = bc.value()
    bc.merge(BCounter("A"))
    assert bc.value() == before_value


def test_bcounter_to_from_dict_roundtrip():
    bc = BCounter("A")
    bc.increment(5)
    bc.transfer("B", 2)
    dup = BCounter.from_dict(bc.to_dict())
    assert dup == bc
    assert dup.value() == bc.value()


def test_bcounter_negative_increment_raises():
    bc = BCounter("A")
    with pytest.raises(ValueError):
        bc.increment(-1)


def test_bcounter_zero_increment_is_noop():
    bc = BCounter("A")
    bc.increment(0)
    assert bc.value() == 0
    assert bc.local_quota() == 0


def test_bcounter_zero_transfer_is_noop():
    bc = BCounter("A")
    bc.increment(5)
    bc.transfer("B", 0)
    assert bc.local_quota() == 5


def test_bcounter_zero_decrement_is_noop():
    bc = BCounter("A")
    bc.increment(5)
    bc.decrement(0)
    assert bc.value() == 5


def test_bcounter_empty_replica_id_raises():
    with pytest.raises(ReplicaError):
        BCounter("")


def test_bcounter_is_not_hashable():
    with pytest.raises(TypeError):
        hash(BCounter("A"))
