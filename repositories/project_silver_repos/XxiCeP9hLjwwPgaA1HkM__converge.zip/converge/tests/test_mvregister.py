"""Tests for :class:`converge.MVRegister`."""
from __future__ import annotations

from copy import deepcopy

import pytest

from converge import MVRegister
from converge.errors import ReplicaError


def test_mv_empty_values_list():
    r = MVRegister("r1")
    assert r.values() == []


def test_mv_single_set_produces_single_value():
    r = MVRegister("r1")
    r.set("hello")
    assert r.values() == ["hello"]


def test_mv_second_set_supersedes_first_on_same_replica():
    r = MVRegister("r1")
    r.set("a")
    r.set("b")
    assert r.values() == ["b"]


def test_mv_concurrent_sets_produce_two_values():
    a = MVRegister("a")
    b = MVRegister("b")
    a.set("from-a")
    b.set("from-b")
    a.merge(deepcopy(b))
    vals = set(a.values())
    assert vals == {"from-a", "from-b"}


def test_mv_observed_sibling_dropped_after_later_set():
    a = MVRegister("a")
    b = MVRegister("b")
    a.set("from-a")
    b.set("from-b")
    a.merge(deepcopy(b))
    # a now observes both dots via the merged DVV.
    a.set("newer")
    # Later set on a has observed both dots and replaces everything.
    assert a.values() == ["newer"]


def test_mv_merge_commutative_on_values():
    a = MVRegister("a")
    b = MVRegister("b")
    a.set("x")
    b.set("y")
    left = deepcopy(a)
    left.merge(deepcopy(b))
    right = deepcopy(b)
    right.merge(deepcopy(a))
    assert set(left.values()) == set(right.values())


def test_mv_merge_associative_on_values():
    a = MVRegister("a")
    b = MVRegister("b")
    c = MVRegister("c")
    a.set(1)
    b.set(2)
    c.set(3)
    left = deepcopy(a)
    left.merge(deepcopy(b))
    left.merge(deepcopy(c))
    right = deepcopy(a)
    bc = deepcopy(b)
    bc.merge(deepcopy(c))
    right.merge(bc)
    assert set(left.values()) == set(right.values())


def test_mv_merge_idempotent_on_values():
    r = MVRegister("r1")
    r.set("x")
    before = set(r.values())
    r.merge(deepcopy(r))
    assert set(r.values()) == before


def test_mv_merge_type_mismatch_raises():
    with pytest.raises(TypeError):
        MVRegister("r1").merge("nope")  # type: ignore[arg-type]


def test_mv_merge_empty_is_noop():
    r = MVRegister("r1")
    r.set("x")
    r.merge(MVRegister("r1"))
    assert r.values() == ["x"]


def test_mv_empty_replica_id_raises():
    with pytest.raises(ReplicaError):
        MVRegister("")


def test_mv_is_not_hashable():
    with pytest.raises(TypeError):
        hash(MVRegister("r1"))


def test_mv_to_from_dict_roundtrip():
    a = MVRegister("a")
    b = MVRegister("b")
    a.set(1)
    b.set(2)
    a.merge(deepcopy(b))
    dup = MVRegister.from_dict(a.to_dict())
    assert dup == a
    assert set(dup.values()) == set(a.values())


def test_mv_value_alias_for_values():
    r = MVRegister("r1")
    r.set("x")
    assert r.value() == r.values()


def test_mv_three_way_concurrent_set_all_survive():
    a = MVRegister("a")
    b = MVRegister("b")
    c = MVRegister("c")
    a.set("A")
    b.set("B")
    c.set("C")
    a.merge(deepcopy(b))
    a.merge(deepcopy(c))
    assert set(a.values()) == {"A", "B", "C"}


def test_mv_sequential_overwrites_on_one_replica_without_merges():
    r = MVRegister("r1")
    for v in range(5):
        r.set(v)
    assert r.values() == [4]
