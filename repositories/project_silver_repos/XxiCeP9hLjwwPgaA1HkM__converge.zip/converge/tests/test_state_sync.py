"""Tests for :class:`converge.StateSync`."""
from __future__ import annotations

import pytest

from converge import GCounter, ORSet, StateSync


def test_state_sync_pair_converges_gcounters():
    a = GCounter("A")
    a.increment(3)
    b = GCounter("B")
    b.increment(5)

    s = StateSync()
    s.sync_pair(a, b)
    assert a.value() == b.value() == 8
    assert s.syncs_performed == 1


def test_state_sync_pair_converges_orsets():
    a = ORSet("A")
    a.add("x")
    b = ORSet("B")
    b.add("y")

    s = StateSync()
    s.sync_pair(a, b)
    assert a.value() == b.value()
    assert a.value() == frozenset({"x", "y"})


def test_state_sync_different_types_raises():
    a = GCounter("A")
    b = ORSet("B")
    s = StateSync()
    with pytest.raises(TypeError):
        s.sync_pair(a, b)


def test_state_sync_converged_true_after_sync():
    a = GCounter("A")
    a.increment(1)
    b = GCounter("B")
    b.increment(2)
    c = GCounter("C")
    c.increment(3)

    s = StateSync()
    s.sync_pair(a, b)
    s.sync_pair(b, c)
    s.sync_pair(a, c)
    assert s.converged([a, b, c])


def test_state_sync_converged_false_for_divergent():
    a = GCounter("A")
    a.increment(1)
    b = GCounter("B")
    b.increment(99)
    s = StateSync()
    assert not s.converged([a, b])


def test_state_sync_converged_single_trivial():
    a = GCounter("A")
    s = StateSync()
    assert s.converged([a])
    assert s.converged([])


def test_state_sync_size_estimate_is_positive_int():
    a = GCounter("A")
    a.increment(5)
    s = StateSync()
    size = s.size_estimate(a)
    assert isinstance(size, int)
    assert size > 0


def test_state_sync_send_full_state_advances_bytes():
    a = GCounter("A")
    a.increment(5)
    s = StateSync()
    assert s.bytes_sent == 0
    s.send_full_state(a)
    assert s.bytes_sent > 0


def test_state_sync_multi_replica_chain_converges():
    replicas = [GCounter(chr(ord("A") + i)) for i in range(4)]
    for i, g in enumerate(replicas):
        g.increment(i + 1)

    s = StateSync()
    # Chain sync: 0<->1, 1<->2, 2<->3, then back
    for _ in range(3):
        for i in range(len(replicas) - 1):
            s.sync_pair(replicas[i], replicas[i + 1])
    assert s.converged(replicas)
    expected = sum(range(1, 5))
    for g in replicas:
        assert g.value() == expected


def test_state_sync_apply_state_merges():
    a = GCounter("A")
    a.increment(5)
    b = GCounter("B")
    b.increment(3)

    s = StateSync()
    snap = s.send_full_state(a)
    s.apply_state(b, snap)
    # b now has both its own 3 and a's 5 merged
    assert b.value() == 8


def test_state_sync_reset_stats():
    a = GCounter("A")
    s = StateSync()
    s.send_full_state(a)
    assert s.bytes_sent > 0
    s.reset_stats()
    assert s.bytes_sent == 0
    assert s.syncs_performed == 0


def test_state_sync_to_from_dict_roundtrip():
    a = GCounter("A")
    a.increment(2)
    b = GCounter("B")
    s = StateSync()
    s.sync_pair(a, b)
    dup = StateSync.from_dict(s.to_dict())
    assert dup == s


def test_state_sync_is_not_hashable():
    with pytest.raises(TypeError):
        hash(StateSync())
