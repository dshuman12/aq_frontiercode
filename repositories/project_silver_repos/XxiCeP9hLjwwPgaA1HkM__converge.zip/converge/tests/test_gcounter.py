"""Tests for :class:`converge.GCounter`."""
from __future__ import annotations

from copy import deepcopy

import pytest

from converge import GCounter
from converge.errors import ReplicaError


def test_gcounter_empty_value_is_zero():
    g = GCounter("r1")
    assert g.value() == 0


def test_gcounter_increment_default_is_one():
    g = GCounter("r1")
    g.increment()
    assert g.value() == 1


def test_gcounter_increment_accumulates():
    g = GCounter("r1")
    g.increment(3)
    g.increment(4)
    assert g.value() == 7


def test_gcounter_increment_by_zero_is_noop():
    g = GCounter("r1")
    g.increment(0)
    assert g.value() == 0


def test_gcounter_negative_increment_raises():
    g = GCounter("r1")
    with pytest.raises(ValueError):
        g.increment(-1)


def test_gcounter_only_owner_slot_grows_locally():
    g = GCounter("r1")
    g.increment(5)
    # Owner slot is the only populated one.
    assert g.to_dict()["counts"] == {"r1": 5}


def test_gcounter_merge_sums_concurrent_increments_from_different_replicas():
    a = GCounter("a")
    a.increment(3)
    b = GCounter("b")
    b.increment(4)
    a.merge(b)
    assert a.value() == 7


def test_gcounter_merge_takes_per_replica_max():
    a = GCounter("a", counts={"a": 2, "b": 1})
    b = GCounter("b", counts={"a": 1, "b": 5})
    a.merge(b)
    assert a.value() == 2 + 5


def test_gcounter_merge_is_idempotent():
    g = GCounter("r1")
    g.increment(4)
    g.merge(deepcopy(g))
    assert g.value() == 4


def test_gcounter_merge_empty_is_noop():
    g = GCounter("r1")
    g.increment(4)
    g.merge(GCounter("r1"))
    assert g.value() == 4


def test_gcounter_merge_type_mismatch_raises():
    g = GCounter("r1")
    with pytest.raises(TypeError):
        g.merge("nope")  # type: ignore[arg-type]


def test_gcounter_to_from_dict_roundtrip():
    g = GCounter("r1")
    g.increment(10)
    dup = GCounter.from_dict(g.to_dict())
    assert dup == g
    assert dup.value() == 10


def test_gcounter_empty_replica_id_raises():
    with pytest.raises(ReplicaError):
        GCounter("")


def test_gcounter_is_not_hashable():
    with pytest.raises(TypeError):
        hash(GCounter("r1"))


def test_gcounter_commutative_merge_on_values():
    a = GCounter("a")
    a.increment(2)
    b = GCounter("b")
    b.increment(3)
    left = deepcopy(a)
    left.merge(deepcopy(b))
    right = deepcopy(b)
    right.merge(deepcopy(a))
    assert left.value() == right.value()
