"""Tests for :class:`converge.PNCounter`."""
from __future__ import annotations

from copy import deepcopy

import pytest

from converge import PNCounter
from converge.errors import ReplicaError


def test_pn_empty_value_is_zero():
    p = PNCounter("r1")
    assert p.value() == 0


def test_pn_increment_matches_gcounter_semantics():
    p = PNCounter("r1")
    p.increment(5)
    assert p.value() == 5


def test_pn_decrement_reduces_value():
    p = PNCounter("r1")
    p.increment(10)
    p.decrement(3)
    assert p.value() == 7


def test_pn_value_can_go_negative():
    p = PNCounter("r1")
    p.decrement(4)
    assert p.value() == -4


def test_pn_increment_then_decrement_net_zero():
    p = PNCounter("r1")
    p.increment(3)
    p.decrement(3)
    assert p.value() == 0


def test_pn_decrement_stores_in_negative_side():
    p = PNCounter("r1")
    p.decrement(2)
    assert p.pos.value() == 0
    assert p.neg.value() == 2


def test_pn_negative_increment_raises():
    p = PNCounter("r1")
    with pytest.raises(ValueError):
        p.increment(-1)
    with pytest.raises(ValueError):
        p.decrement(-1)


def test_pn_merge_sums_concurrent_decrements_from_different_replicas():
    a = PNCounter("a")
    b = PNCounter("b")
    a.decrement(1)
    b.decrement(2)
    a.merge(b)
    assert a.value() == -3


def test_pn_merge_combines_inc_and_dec_across_replicas():
    a = PNCounter("a")
    b = PNCounter("b")
    a.increment(5)
    b.decrement(2)
    a.merge(b)
    assert a.value() == 3


def test_pn_merge_idempotent():
    p = PNCounter("r1")
    p.increment(2)
    p.decrement(1)
    p.merge(deepcopy(p))
    assert p.value() == 1


def test_pn_merge_empty_is_noop():
    p = PNCounter("r1")
    p.increment(3)
    p.merge(PNCounter("r1"))
    assert p.value() == 3


def test_pn_merge_type_mismatch_raises():
    p = PNCounter("r1")
    with pytest.raises(TypeError):
        p.merge("nope")  # type: ignore[arg-type]


def test_pn_to_from_dict_roundtrip():
    p = PNCounter("r1")
    p.increment(7)
    p.decrement(2)
    dup = PNCounter.from_dict(p.to_dict())
    assert dup == p
    assert dup.value() == 5


def test_pn_empty_replica_id_raises():
    with pytest.raises(ReplicaError):
        PNCounter("")


def test_pn_is_not_hashable():
    with pytest.raises(TypeError):
        hash(PNCounter("r1"))


def test_pn_commutative_merge_on_values():
    a = PNCounter("a")
    a.increment(4)
    a.decrement(1)
    b = PNCounter("b")
    b.increment(2)
    b.decrement(5)

    left = deepcopy(a)
    left.merge(deepcopy(b))
    right = deepcopy(b)
    right.merge(deepcopy(a))
    assert left.value() == right.value()
