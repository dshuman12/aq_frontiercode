"""Tests for :class:`converge.IntervalTreeClock`."""
from __future__ import annotations

from copy import deepcopy

import pytest

from converge import IntervalTreeClock
from converge.errors import ConvergeError


def test_itc_seed_has_full_interval_and_no_events():
    c = IntervalTreeClock.seed()
    assert c.id_tree == 1
    assert c.event_tree == 0


def test_itc_fork_splits_ids_disjointly():
    c = IntervalTreeClock.seed()
    a, b = c.fork()
    # Disjoint: (1,0) and (0,1)
    assert a.id_tree != b.id_tree
    # Neither side should be zero (both should own some region)
    assert a.id_tree != 0
    assert b.id_tree != 0


def test_itc_fork_preserves_event_tree():
    c = IntervalTreeClock.seed()
    c.event()
    a, b = c.fork()
    # Both sides inherit the current event tree
    assert a.event_tree == c.event_tree
    assert b.event_tree == c.event_tree


def test_itc_event_advances_max():
    c = IntervalTreeClock.seed()
    before = c.event_tree
    c.event()
    # event tree should now represent more events
    assert c.event_tree != before


def test_itc_event_on_anonymous_raises():
    c = IntervalTreeClock(0, 0)
    with pytest.raises(ConvergeError):
        c.event()


def test_itc_seed_peek_is_anonymous():
    c = IntervalTreeClock.seed()
    peek = c.peek()
    assert peek.id_tree == 0
    # peek cannot record events
    with pytest.raises(ConvergeError):
        peek.event()


def test_itc_event_then_fork_then_event_yields_concurrent():
    a = IntervalTreeClock.seed()
    a.event()
    a, b = a.fork()
    a.event()
    b.event()
    assert a.is_concurrent_with(b)
    assert not a.leq(b)
    assert not b.leq(a)


def test_itc_join_reunites_id_intervals():
    c = IntervalTreeClock.seed()
    a, b = c.fork()
    a.join(b)
    # After join, a owns the whole interval again
    assert a.id_tree == 1


def test_itc_join_event_trees_point_wise_max():
    a = IntervalTreeClock.seed()
    a, b = a.fork()
    a.event()
    a.event()
    b.event()
    # Join b into a: events should include everything from both
    a_events_before = a.event_tree
    a.join(b)
    assert a.leq(a)  # trivially
    # After joining, a should be >= b (since it absorbed b)
    assert b.leq(a)


def test_itc_leq_after_self_event_is_reflexive():
    c = IntervalTreeClock.seed()
    c.event()
    c2 = c.clone()
    assert c.leq(c2)
    assert c2.leq(c)


def test_itc_leq_on_chained_events():
    c = IntervalTreeClock.seed()
    c1 = c.clone()
    c.event()
    # c1 is older; c1 <= c should hold
    assert c1.leq(c)
    # c is strictly after c1
    assert c1.happens_before(c)


def test_itc_happens_before_strict():
    c = IntervalTreeClock.seed()
    earlier = c.clone()
    c.event()
    assert earlier.happens_before(c)
    assert not c.happens_before(earlier)


def test_itc_is_concurrent_with_self_is_false():
    c = IntervalTreeClock.seed()
    c2 = c.clone()
    # Same state: each is <= the other, so not concurrent
    assert not c.is_concurrent_with(c2)


def test_itc_normalize_collapses_zero_zero_to_zero():
    # (0, 0) should normalize to 0
    c = IntervalTreeClock((0, 0), 0)
    assert c.id_tree == 0


def test_itc_normalize_collapses_one_one_to_one():
    c = IntervalTreeClock((1, 1), 0)
    assert c.id_tree == 1


def test_itc_to_from_dict_roundtrip_seed():
    c = IntervalTreeClock.seed()
    dup = IntervalTreeClock.from_dict(c.to_dict())
    assert dup == c


def test_itc_to_from_dict_roundtrip_after_fork_and_event():
    c = IntervalTreeClock.seed()
    a, _b = c.fork()
    a.event()
    a.event()
    dup = IntervalTreeClock.from_dict(a.to_dict())
    assert dup == a


def test_itc_clone_independence():
    a = IntervalTreeClock.seed()
    b = a.clone()
    a.event()
    # b should still be at its pre-event state
    assert b.event_tree == 0


def test_itc_join_type_mismatch_raises():
    c = IntervalTreeClock.seed()
    with pytest.raises(TypeError):
        c.join("not-a-clock")  # type: ignore[arg-type]


def test_itc_leq_type_mismatch_raises():
    c = IntervalTreeClock.seed()
    with pytest.raises(TypeError):
        c.leq("not-a-clock")  # type: ignore[arg-type]


def test_itc_is_not_hashable():
    c = IntervalTreeClock.seed()
    with pytest.raises(TypeError):
        hash(c)


def test_itc_multiple_events_are_monotonic():
    c = IntervalTreeClock.seed()
    snapshots = []
    for _ in range(3):
        snapshots.append(c.clone())
        c.event()
    # Each earlier snapshot should be <= the next
    for i in range(len(snapshots) - 1):
        assert snapshots[i].leq(snapshots[i + 1])


def test_itc_peek_has_id_zero_after_events():
    c = IntervalTreeClock.seed()
    c.event()
    p = c.peek()
    assert p.id_tree == 0
    # But peek still carries the event tree
    assert p.event_tree == c.event_tree
