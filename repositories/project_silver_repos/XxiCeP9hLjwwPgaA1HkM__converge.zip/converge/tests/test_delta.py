"""Tests for delta-CRDT primitives: :class:`DeltaCRDT`, :class:`DeltaGCounter`,
:class:`DeltaORSet`, and :class:`DeltaBuffer`.
"""
from __future__ import annotations

from copy import deepcopy

import pytest

from converge import DeltaBuffer, DeltaCRDT, DeltaGCounter, DeltaORSet
from converge.errors import ConvergeError


# ---------------------------------------------------------------------------
# Protocol
# ---------------------------------------------------------------------------

def test_deltacrdt_is_abstract_cannot_instantiate():
    with pytest.raises(TypeError):
        DeltaCRDT()  # type: ignore[abstract]


def test_delta_gcounter_is_deltacrdt():
    assert issubclass(DeltaGCounter, DeltaCRDT)


def test_delta_orset_is_deltacrdt():
    assert issubclass(DeltaORSet, DeltaCRDT)


# ---------------------------------------------------------------------------
# DeltaGCounter
# ---------------------------------------------------------------------------

def test_delta_gcounter_snapshot_is_dict():
    g = DeltaGCounter("A")
    g.increment(5)
    snap = g.snapshot()
    assert isinstance(snap, dict)
    assert snap == {"A": 5}


def test_delta_gcounter_delta_since_empty_snapshot():
    g = DeltaGCounter("A")
    g.increment(3)
    delta = g.delta_since({})
    assert delta == {"A": 3}


def test_delta_gcounter_delta_since_caught_up():
    g = DeltaGCounter("A")
    g.increment(3)
    # Peer already has the same state
    delta = g.delta_since({"A": 3})
    assert delta == {}


def test_delta_gcounter_apply_delta_converges():
    a = DeltaGCounter("A")
    a.increment(3)
    b = DeltaGCounter("B")
    b.increment(4)

    # Compute a's delta relative to b
    delta = a.delta_since(b.snapshot())
    # Apply to b
    b.apply_delta(delta)
    # Now a should be <= b (b absorbed a's deltas)
    assert b.value() >= a.value()


def test_delta_gcounter_apply_delta_to_third_replica_converges():
    a = DeltaGCounter("A")
    a.increment(5)
    b = DeltaGCounter("B")
    b.increment(7)
    c = DeltaGCounter("C")

    # Apply both deltas to c
    c.apply_delta(a.delta_since(c.snapshot()))
    c.apply_delta(b.delta_since(c.snapshot()))
    # c should now have the sum
    assert c.value() == 5 + 7


def test_delta_gcounter_apply_delta_is_idempotent():
    a = DeltaGCounter("A")
    a.increment(5)
    b = DeltaGCounter("B")

    delta = a.delta_since(b.snapshot())
    b.apply_delta(delta)
    value1 = b.value()
    # Applying again should not change anything (idempotent)
    b.apply_delta(delta)
    assert b.value() == value1


def test_delta_gcounter_apply_delta_rejects_non_dict():
    g = DeltaGCounter("A")
    with pytest.raises(TypeError):
        g.apply_delta("not a dict")  # type: ignore[arg-type]


def test_delta_gcounter_apply_delta_rejects_negative_amount():
    g = DeltaGCounter("A")
    with pytest.raises(ValueError):
        g.apply_delta({"B": -3})


# ---------------------------------------------------------------------------
# DeltaORSet
# ---------------------------------------------------------------------------

def test_delta_orset_snapshot_shape():
    s = DeltaORSet("A")
    s.add("x")
    snap = s.snapshot()
    assert "dots" in snap
    assert "tombstones" in snap
    assert "x" in snap["dots"]


def test_delta_orset_delta_captures_adds():
    a = DeltaORSet("A")
    a.add("x")
    b = DeltaORSet("B")
    delta = a.delta_since(b.snapshot())
    assert "x" in delta["added"]


def test_delta_orset_delta_captures_tombstones():
    a = DeltaORSet("A")
    a.add("x")
    a.remove("x")
    b = DeltaORSet("B")
    delta = a.delta_since(b.snapshot())
    # The tombstone for "x" should be in the delta
    assert len(delta["tombstones"]) > 0


def test_delta_orset_apply_delta_converges_to_full_merge():
    # Build two sets with some activity
    a = DeltaORSet("A")
    a.add("x")
    a.add("y")

    b = DeltaORSet("B")
    b.add("z")

    # Full-state merge reference
    full_a = deepcopy(a)
    full_a.merge(deepcopy(b))

    # Delta-based: apply a's delta to b, b's delta to a
    delta_a_to_b = a.delta_since(b.snapshot())
    delta_b_to_a = b.delta_since(a.snapshot())
    a.apply_delta(delta_b_to_a)
    b.apply_delta(delta_a_to_b)

    # Both should match the full-state merge
    assert a.value() == full_a.value()
    assert b.value() == full_a.value()


def test_delta_orset_apply_delta_is_idempotent():
    a = DeltaORSet("A")
    a.add("x")
    b = DeltaORSet("B")
    delta = a.delta_since(b.snapshot())
    b.apply_delta(delta)
    value1 = b.value()
    b.apply_delta(delta)
    assert b.value() == value1


def test_delta_orset_delta_propagates_remove():
    a = DeltaORSet("A")
    a.add("x")
    b = DeltaORSet("B")
    # First sync them so they both see x
    delta = a.delta_since(b.snapshot())
    b.apply_delta(delta)
    assert "x" in b.value()

    # Now remove on A and propagate
    a.remove("x")
    delta = a.delta_since(b.snapshot())
    b.apply_delta(delta)
    assert "x" not in b.value()


def test_delta_orset_apply_delta_rejects_non_dict():
    s = DeltaORSet("A")
    with pytest.raises(TypeError):
        s.apply_delta("nope")  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# DeltaBuffer
# ---------------------------------------------------------------------------

def test_delta_buffer_empty():
    buf = DeltaBuffer()
    assert len(buf) == 0
    assert buf.next_seq == 1
    assert buf.peek_latest() is None


def test_delta_buffer_push_assigns_monotonic_seqs():
    buf = DeltaBuffer()
    s1 = buf.push({"op": "add", "x": 1})
    s2 = buf.push({"op": "add", "x": 2})
    s3 = buf.push({"op": "add", "x": 3})
    assert s1 < s2 < s3
    assert s1 == 1
    assert s2 == 2
    assert s3 == 3


def test_delta_buffer_deltas_since_returns_newer():
    buf = DeltaBuffer()
    buf.push("d1")
    buf.push("d2")
    buf.push("d3")
    # Since seq=1, should return entries with seq > 1
    out = buf.deltas_since(1)
    assert [seq for seq, _d in out] == [2, 3]


def test_delta_buffer_deltas_since_zero_returns_all():
    buf = DeltaBuffer()
    buf.push("d1")
    buf.push("d2")
    out = buf.deltas_since(0)
    assert len(out) == 2


def test_delta_buffer_compact_drops_older():
    buf = DeltaBuffer()
    buf.push("d1")
    buf.push("d2")
    buf.push("d3")
    dropped = buf.compact(before_seq=3)
    assert dropped == 2
    # Only seq 3 survives
    assert len(buf) == 1
    assert buf.peek_latest() == (3, "d3")


def test_delta_buffer_compact_ahead_of_next_seq_raises():
    buf = DeltaBuffer()
    buf.push("d1")
    with pytest.raises(ConvergeError):
        buf.compact(before_seq=999)


def test_delta_buffer_seq_numbers_never_reused_after_compact():
    buf = DeltaBuffer()
    buf.push("d1")
    buf.push("d2")
    buf.compact(before_seq=3)
    # Next push should have seq 3, not 1
    s = buf.push("d3")
    assert s == 3


def test_delta_buffer_to_from_dict_roundtrip():
    buf = DeltaBuffer()
    buf.push({"op": "x"})
    buf.push({"op": "y"})
    dup = DeltaBuffer.from_dict(buf.to_dict())
    assert dup == buf
    assert len(dup) == 2


def test_delta_buffer_peek_latest():
    buf = DeltaBuffer()
    buf.push("d1")
    buf.push("d2")
    assert buf.peek_latest() == (2, "d2")


def test_delta_buffer_is_not_hashable():
    with pytest.raises(TypeError):
        hash(DeltaBuffer())
