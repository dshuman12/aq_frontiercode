"""Tests for :class:`converge.NetworkSim`."""
from __future__ import annotations

import pytest

from converge import NetworkSim
from converge.errors import ReplicaError


def test_network_sim_send_tick_delivers():
    sim = NetworkSim(seed=0, drop_prob=0.0, max_delay=0)
    sim.send("A", "B", {"op": "inc"})
    sim.tick()
    msgs = sim.inbox("B")
    assert len(msgs) == 1
    assert msgs[0] == ("A", {"op": "inc"})


def test_network_sim_drop_prob_one_delivers_nothing():
    sim = NetworkSim(seed=0, drop_prob=1.0, max_delay=0)
    for _ in range(10):
        sim.send("A", "B", "msg")
    sim.tick()
    assert sim.inbox("B") == []
    assert sim.stats()["dropped"] == 10


def test_network_sim_drop_prob_zero_delivers_everything():
    sim = NetworkSim(seed=0, drop_prob=0.0, max_delay=0)
    for i in range(5):
        sim.send("A", "B", i)
    sim.tick()
    msgs = sim.inbox("B")
    assert len(msgs) == 5


def test_network_sim_max_delay_requires_multiple_ticks():
    sim = NetworkSim(seed=0, drop_prob=0.0, max_delay=3)
    sim.send("A", "B", "hi")
    # With delay, the message might not arrive immediately.
    # After enough ticks, it should arrive.
    delivered = False
    for _ in range(5):
        sim.tick()
        if sim.peek_inbox("B"):
            delivered = True
            break
    assert delivered


def test_network_sim_partition_blocks_messages():
    sim = NetworkSim(seed=0, drop_prob=0.0, max_delay=0)
    sim.partition("A", "B", for_ticks=3)
    sim.send("A", "B", "blocked")
    sim.tick()
    assert sim.inbox("B") == []
    # Counted as dropped
    assert sim.stats()["dropped"] >= 1


def test_network_sim_heal_unblocks():
    sim = NetworkSim(seed=0, drop_prob=0.0, max_delay=0)
    sim.partition("A", "B", for_ticks=10)
    sim.heal("A", "B")
    sim.send("A", "B", "ok")
    sim.tick()
    assert len(sim.inbox("B")) == 1


def test_network_sim_partition_expires_after_ticks():
    sim = NetworkSim(seed=0, drop_prob=0.0, max_delay=0)
    sim.partition("A", "B", for_ticks=2)
    # Tick twice to exhaust the partition
    sim.tick()
    sim.tick()
    # Now partition should be expired
    assert not sim.is_partitioned("A", "B")
    sim.send("A", "B", "ok")
    sim.tick()
    assert len(sim.inbox("B")) == 1


def test_network_sim_is_partitioned():
    sim = NetworkSim(seed=0)
    assert not sim.is_partitioned("A", "B")
    sim.partition("A", "B", for_ticks=5)
    assert sim.is_partitioned("A", "B")
    # Order-independent
    assert sim.is_partitioned("B", "A")


def test_network_sim_stats_counts_sane():
    sim = NetworkSim(seed=0, drop_prob=0.0, max_delay=0)
    for _ in range(3):
        sim.send("A", "B", "m")
    sim.tick()
    stats = sim.stats()
    assert stats["sent"] == 3
    assert stats["delivered"] == 3
    assert stats["dropped"] == 0


def test_network_sim_send_to_self_raises():
    sim = NetworkSim(seed=0)
    with pytest.raises(ValueError):
        sim.send("A", "A", "msg")


def test_network_sim_send_bad_replica_id_raises():
    sim = NetworkSim(seed=0)
    with pytest.raises(ReplicaError):
        sim.send("", "B", "msg")


def test_network_sim_invalid_drop_prob_raises():
    with pytest.raises(ValueError):
        NetworkSim(seed=0, drop_prob=1.5)


def test_network_sim_negative_max_delay_raises():
    with pytest.raises(ValueError):
        NetworkSim(seed=0, max_delay=-1)


def test_network_sim_partition_for_zero_ticks_raises():
    sim = NetworkSim(seed=0)
    with pytest.raises(ValueError):
        sim.partition("A", "B", for_ticks=0)


def test_network_sim_current_tick_advances():
    sim = NetworkSim(seed=0)
    assert sim.current_tick == 0
    sim.tick()
    sim.tick()
    assert sim.current_tick == 2


def test_network_sim_pending_count():
    sim = NetworkSim(seed=0, drop_prob=0.0, max_delay=5)
    sim.send("A", "B", "m")
    # max_delay=5 means the message may still be in the queue
    assert sim.pending() >= 0  # conservative


def test_network_sim_inbox_drains():
    sim = NetworkSim(seed=0, drop_prob=0.0, max_delay=0)
    sim.send("A", "B", "m")
    sim.tick()
    assert len(sim.inbox("B")) == 1
    # After drain, inbox is empty
    assert sim.inbox("B") == []


def test_network_sim_peek_does_not_drain():
    sim = NetworkSim(seed=0, drop_prob=0.0, max_delay=0)
    sim.send("A", "B", "m")
    sim.tick()
    assert len(sim.peek_inbox("B")) == 1
    # Peek again: still there
    assert len(sim.peek_inbox("B")) == 1


def test_network_sim_to_from_dict_roundtrip():
    sim = NetworkSim(seed=7, drop_prob=0.1, reorder_prob=0.2, max_delay=2)
    sim.send("A", "B", {"k": 1})
    sim.tick()
    dup = NetworkSim.from_dict(sim.to_dict())
    assert dup.seed == sim.seed
    assert dup.drop_prob == sim.drop_prob
    assert dup.reorder_prob == sim.reorder_prob
    assert dup.max_delay == sim.max_delay
    assert dup.current_tick == sim.current_tick


def test_network_sim_resume_after_roundtrip():
    sim = NetworkSim(seed=0, drop_prob=0.0, max_delay=0)
    sim.send("A", "B", "msg1")
    # Roundtrip before tick
    dup = NetworkSim.from_dict(sim.to_dict())
    dup.tick()
    assert len(dup.inbox("B")) == 1
