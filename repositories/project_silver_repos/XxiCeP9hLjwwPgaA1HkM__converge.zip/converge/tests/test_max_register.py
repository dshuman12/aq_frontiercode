"""Tests for :class:`converge.MaxRegister`."""
from __future__ import annotations

from copy import deepcopy

import pytest

from converge import MaxRegister
from converge.errors import ReplicaError


def test_max_empty_value_is_none():
    r = MaxRegister("r1")
    assert r.value() is None


def test_max_first_update_lands():
    r = MaxRegister("r1")
    r.update(5)
    assert r.value() == 5


def test_max_update_monotonic_increase():
    r = MaxRegister("r1")
    r.update(1)
    r.update(5)
    r.update(3)
    assert r.value() == 5


def test_max_update_none_is_rejected():
    r = MaxRegister("r1")
    with pytest.raises(TypeError):
        r.update(None)


def test_max_merge_none_is_identity():
    a = MaxRegister("a")
    a.update(10)
    b = MaxRegister("b")  # never updated
    a.merge(b)
    assert a.value() == 10


def test_max_merge_into_empty_takes_other():
    a = MaxRegister("a")
    b = MaxRegister("b")
    b.update(7)
    a.merge(b)
    assert a.value() == 7


def test_max_merge_takes_larger():
    a = MaxRegister("a")
    a.update(3)
    b = MaxRegister("b")
    b.update(10)
    a.merge(b)
    assert a.value() == 10


def test_max_merge_keeps_larger_when_self_wins():
    a = MaxRegister("a")
    a.update(99)
    b = MaxRegister("b")
    b.update(1)
    a.merge(b)
    assert a.value() == 99


def test_max_equal_value_tiebreak_larger_replica_wins_on_merge():
    a = MaxRegister("A")
    a.update(5)
    b = MaxRegister("B")
    b.update(5)
    # Merging b into a: b has larger replica id "B" > "A" (since B > A lexicographically)
    a.merge(b)
    assert a.value() == 5
    # Writer should be "B" (the larger writer)
    assert a.writer == "B"


def test_max_equal_value_tiebreak_smaller_replica_loses():
    a = MaxRegister("B")
    a.update(5)
    b = MaxRegister("A")
    b.update(5)
    a.merge(b)
    # "B" > "A", so writer remains "B"
    assert a.writer == "B"


def test_max_merge_is_idempotent():
    r = MaxRegister("r1")
    r.update(42)
    before = r.value()
    r.merge(deepcopy(r))
    assert r.value() == before


def test_max_merge_is_commutative_on_values():
    a = MaxRegister("A")
    a.update(3)
    b = MaxRegister("B")
    b.update(7)
    left = deepcopy(a)
    left.merge(deepcopy(b))
    right = deepcopy(b)
    right.merge(deepcopy(a))
    assert left.value() == right.value()


def test_max_merge_is_associative():
    a = MaxRegister("A")
    a.update(1)
    b = MaxRegister("B")
    b.update(5)
    c = MaxRegister("C")
    c.update(3)

    left = deepcopy(a)
    left.merge(deepcopy(b))
    left.merge(deepcopy(c))

    right = deepcopy(a)
    bc = deepcopy(b)
    bc.merge(deepcopy(c))
    right.merge(bc)

    assert left.value() == right.value()


def test_max_merge_type_mismatch_raises():
    r = MaxRegister("r1")
    with pytest.raises(TypeError):
        r.merge("not-a-register")  # type: ignore[arg-type]


def test_max_incomparable_update_raises_type_error():
    r = MaxRegister("r1")
    r.update(5)
    with pytest.raises(TypeError):
        r.update("a-string")


def test_max_to_from_dict_roundtrip():
    r = MaxRegister("r1")
    r.update(42)
    dup = MaxRegister.from_dict(r.to_dict())
    assert dup.value() == r.value()
    assert dup.writer == r.writer


def test_max_empty_replica_id_raises():
    with pytest.raises(ReplicaError):
        MaxRegister("")


def test_max_initial_value_in_constructor():
    r = MaxRegister("r1", initial=10)
    assert r.value() == 10


def test_max_is_not_hashable():
    r = MaxRegister("r1")
    with pytest.raises(TypeError):
        hash(r)
