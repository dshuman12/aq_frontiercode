"""Shared pytest fixtures and helpers for the converge test suite."""
from __future__ import annotations

import random
from copy import deepcopy
from typing import Any, Callable

import pytest


RANDOM_SEED = 0x5115


@pytest.fixture
def seeded_random() -> random.Random:
    """Return a deterministic ``random.Random`` keyed off :data:`RANDOM_SEED`."""
    return random.Random(RANDOM_SEED)


@pytest.fixture
def replica_ids() -> list[str]:
    """A small stable pool of replica ids used by many tests."""
    return ["alice", "bob", "carol", "dave"]


@pytest.fixture
def make_replica_id() -> Callable[[int], str]:
    """Factory for synthetic replica ids, useful when tests need many replicas."""
    def _make(i: int) -> str:
        return f"r{i:03d}"
    return _make


def clone(x: Any) -> Any:
    """Deep-copy helper -- exists so tests read closer to the invariant formulas."""
    return deepcopy(x)


def assert_idempotent_merge(instance: Any) -> None:
    """Assert ``instance.merge(deepcopy(instance))`` leaves ``instance.value()`` fixed."""
    before = instance.value()
    instance.merge(deepcopy(instance))
    after = instance.value()
    assert after == before, f"idempotence violated: before={before!r} after={after!r}"


def assert_commutative(a: Any, b: Any) -> None:
    """Assert ``a.merge(b)`` and ``b.merge(a)`` end with equal ``.value()``."""
    left = deepcopy(a)
    right_a = deepcopy(a)
    right_b = deepcopy(b)
    left.merge(deepcopy(b))
    right_b.merge(right_a)
    assert left.value() == right_b.value(), (
        f"commutativity violated: a⊔b={left.value()!r} b⊔a={right_b.value()!r}"
    )


def assert_associative(a: Any, b: Any, c: Any) -> None:
    """Assert ``(a⊔b)⊔c`` and ``a⊔(b⊔c)`` yield the same ``.value()``."""
    left = deepcopy(a)
    left.merge(deepcopy(b))
    left.merge(deepcopy(c))

    right = deepcopy(a)
    bc = deepcopy(b)
    bc.merge(deepcopy(c))
    right.merge(bc)

    assert left.value() == right.value(), (
        f"associativity violated: (a⊔b)⊔c={left.value()!r} a⊔(b⊔c)={right.value()!r}"
    )
