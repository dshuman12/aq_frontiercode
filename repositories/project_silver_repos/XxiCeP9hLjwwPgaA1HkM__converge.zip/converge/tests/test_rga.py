"""Tests for :class:`converge.RGA`."""
from __future__ import annotations

import random
from copy import deepcopy

import pytest

from converge import RGA
from converge.errors import ReplicaError


def test_rga_empty_value():
    r = RGA("r1")
    assert r.to_list() == []
    assert len(r) == 0


def test_rga_insert_at_zero_into_empty():
    r = RGA("r1")
    r.insert_at(0, "a")
    assert r.to_list() == ["a"]
    assert len(r) == 1


def test_rga_sequential_inserts_append_preserve_order():
    r = RGA("r1")
    for i, ch in enumerate(["a", "b", "c", "d"]):
        r.insert_at(i, ch)
    assert r.to_list() == ["a", "b", "c", "d"]


def test_rga_insert_at_len_appends():
    r = RGA("r1")
    r.insert_at(0, "x")
    r.insert_at(len(r), "y")
    assert r.to_list() == ["x", "y"]


def test_rga_insert_at_middle_shifts_tail():
    r = RGA("r1")
    r.insert_at(0, "a")
    r.insert_at(1, "c")
    r.insert_at(1, "b")
    assert r.to_list() == ["a", "b", "c"]


def test_rga_insert_out_of_range_raises():
    r = RGA("r1")
    with pytest.raises(IndexError):
        r.insert_at(1, "x")
    r.insert_at(0, "a")
    with pytest.raises(IndexError):
        r.insert_at(5, "y")
    with pytest.raises(IndexError):
        r.insert_at(-1, "z")


def test_rga_delete_at_removes_visible_element():
    r = RGA("r1")
    for i, ch in enumerate(["a", "b", "c"]):
        r.insert_at(i, ch)
    r.delete_at(1)
    assert r.to_list() == ["a", "c"]
    assert len(r) == 2


def test_rga_delete_out_of_range_raises():
    r = RGA("r1")
    with pytest.raises(IndexError):
        r.delete_at(0)
    r.insert_at(0, "a")
    with pytest.raises(IndexError):
        r.delete_at(5)
    with pytest.raises(IndexError):
        r.delete_at(-1)


def test_rga_insert_delete_insert_on_same_replica():
    r = RGA("r1")
    r.insert_at(0, "a")
    r.insert_at(1, "b")
    r.delete_at(0)            # 'a' is tombstoned
    r.insert_at(0, "x")       # new element at head
    assert r.to_list() == ["x", "b"]


def test_rga_len_matches_to_list_length():
    r = RGA("r1")
    for i in range(10):
        r.insert_at(i, i)
    for _ in range(3):
        r.delete_at(0)
    assert len(r) == len(r.to_list())


def test_rga_concurrent_inserts_at_head_use_descending_replica_tiebreak():
    # Two replicas each insert at position 0 into empty RGA.
    # Sibling rule: descending id order. Both nodes share parent=None,
    # so the one with the lex-larger (replica_id, counter) appears first.
    a = RGA("alpha")
    b = RGA("beta")
    a.insert_at(0, "A")
    b.insert_at(0, "B")
    a.merge(deepcopy(b))
    # ("beta", 1) > ("alpha", 1) lex; descending means "beta" first.
    assert a.to_list() == ["B", "A"]


def test_rga_concurrent_inserts_at_shared_parent_use_descending_replica_tiebreak():
    # Both start from a common ancestor x, insert right after it
    # concurrently; larger replica_id wins the nearer-to-parent slot.
    seed = RGA("a")
    seed.insert_at(0, "x")
    left = deepcopy(seed)
    right = RGA("b")
    right.merge(deepcopy(seed))

    # left inserts "L" after "x"; right inserts "R" after "x".
    left.insert_at(1, "L")
    right.insert_at(1, "R")

    left.merge(deepcopy(right))
    # Both new nodes share the same parent ("a", 1) = x.
    # ("b", ...) > ("a", ...) lex, so R comes before L in descending order.
    assert left.to_list() == ["x", "R", "L"]


def test_rga_tombstone_anchors_concurrent_inserts():
    a = RGA("a")
    a.insert_at(0, "x")
    a.insert_at(1, "y")
    a.insert_at(2, "z")

    b = deepcopy(a)
    # a deletes "y", b inserts "Y2" right after "y".
    a.delete_at(1)
    b.insert_at(2, "Y2")        # after "y" in b's view (pos 2 = after y)
    a.merge(deepcopy(b))
    # "y" is tombstoned but still anchors Y2 between its old slot and "z".
    result = a.to_list()
    assert result == ["x", "Y2", "z"]


def test_rga_merge_type_mismatch_raises():
    with pytest.raises(TypeError):
        RGA("r1").merge("no")  # type: ignore[arg-type]


def test_rga_merge_idempotent():
    r = RGA("r1")
    for i, ch in enumerate(["a", "b", "c"]):
        r.insert_at(i, ch)
    r.delete_at(0)
    r.merge(deepcopy(r))
    assert r.to_list() == ["b", "c"]


def test_rga_merge_empty_is_noop():
    r = RGA("r1")
    r.insert_at(0, "x")
    r.merge(RGA("r1"))
    assert r.to_list() == ["x"]


def test_rga_merge_overlapping_identical_inserts_converges():
    # Both replicas see the same base doc, a merges and inserts X; b
    # also inserts different element Y concurrently. Merge converges.
    base = RGA("a")
    base.insert_at(0, "hi")
    a = deepcopy(base)
    b = RGA("b")
    b.merge(deepcopy(base))

    a.insert_at(1, "X")
    b.insert_at(1, "Y")

    # a merges b; b merges a; they should converge to same list.
    a2 = deepcopy(a)
    b2 = deepcopy(b)
    a2.merge(deepcopy(b))
    b2.merge(deepcopy(a))
    assert a2.to_list() == b2.to_list()


def test_rga_to_from_dict_roundtrip():
    r = RGA("r1")
    for i, ch in enumerate(["a", "b", "c"]):
        r.insert_at(i, ch)
    r.delete_at(1)
    dup = RGA.from_dict(r.to_dict())
    assert dup == r
    assert dup.to_list() == r.to_list()


def test_rga_empty_replica_id_raises():
    with pytest.raises(ReplicaError):
        RGA("")


def test_rga_is_not_hashable():
    with pytest.raises(TypeError):
        hash(RGA("r1"))


def test_rga_value_alias_for_to_list():
    r = RGA("r1")
    r.insert_at(0, "a")
    assert r.value() == r.to_list()


def test_rga_large_sequence_with_deletes_and_merges_converges():
    rng = random.Random(0xC0FFEE)
    a = RGA("a")
    b = RGA("b")
    for _ in range(100):
        target = rng.choice([a, b])
        pos = rng.randint(0, len(target))
        target.insert_at(pos, rng.randint(0, 10**6))

    # Merge both ways so they are causally up-to-date.
    a.merge(deepcopy(b))
    b.merge(deepcopy(a))
    assert a.to_list() == b.to_list()

    # Now delete on one, merge.
    for _ in range(30):
        if len(a) == 0:
            break
        pos = rng.randint(0, len(a) - 1)
        a.delete_at(pos)
    b.merge(deepcopy(a))
    assert a.to_list() == b.to_list()


def test_rga_three_way_merge_converges():
    a = RGA("a")
    b = RGA("b")
    c = RGA("c")
    a.insert_at(0, "a0")
    b.insert_at(0, "b0")
    c.insert_at(0, "c0")

    a2 = deepcopy(a)
    a2.merge(deepcopy(b))
    a2.merge(deepcopy(c))

    c2 = deepcopy(c)
    c2.merge(deepcopy(b))
    c2.merge(deepcopy(a))

    assert a2.to_list() == c2.to_list()


def test_rga_counter_advances_past_observed_ids_after_merge():
    a = RGA("a")
    b = RGA("b")
    for i in range(3):
        b.insert_at(i, i)
    a.merge(deepcopy(b))
    # Insert on a; new ids should not collide with any b-minted id, but
    # more importantly a's own counter should start from its own history.
    a.insert_at(len(a), "end")
    # The insert must have succeeded and the list must contain the new tail.
    assert a.to_list()[-1] == "end"
