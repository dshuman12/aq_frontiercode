"""Tests for :class:`converge.ORMap`."""
from __future__ import annotations

from copy import deepcopy

import pytest

from converge import ORMap
from converge.errors import ConvergeError, ReplicaError


def test_ormap_empty_value():
    m = ORMap("r1")
    assert m.value() == {}
    assert m.keys() == frozenset()


def test_ormap_set_then_get():
    m = ORMap("r1")
    m.set("k", "v")
    assert m.get("k") == ["v"]
    assert m.contains("k")


def test_ormap_get_unknown_key_returns_empty_list():
    m = ORMap("r1")
    assert m.get("ghost") == []


def test_ormap_sequential_set_replaces_own_write():
    m = ORMap("r1")
    m.set("k", "v1")
    m.set("k", "v2")
    assert m.get("k") == ["v2"]


def test_ormap_remove_unknown_key_raises():
    m = ORMap("r1")
    with pytest.raises(ConvergeError):
        m.remove("ghost")


def test_ormap_remove_makes_key_absent():
    m = ORMap("r1")
    m.set("k", "v")
    m.remove("k")
    assert not m.contains("k")
    assert m.get("k") == []


def test_ormap_remove_then_reset_preserves_new_value():
    m = ORMap("r1")
    m.set("k", "v1")
    m.remove("k")
    m.set("k", "v2")
    assert m.get("k") == ["v2"]


def test_ormap_concurrent_sets_preserve_both_values():
    a = ORMap("A")
    a.set("k", "va")
    b = ORMap("B")
    b.set("k", "vb")
    a.merge(b)
    got = a.value()["k"]
    assert len(got) == 2
    assert set(got) == {"va", "vb"}


def test_ormap_merge_with_overlapping_keys():
    a = ORMap("A")
    a.set("x", 1)
    a.set("y", 2)
    b = ORMap("B")
    b.set("y", 20)
    b.set("z", 30)
    a.merge(b)
    assert a.get("x") == [1]
    # y has concurrent writes
    assert set(a.get("y")) == {2, 20}
    assert a.get("z") == [30]


def test_ormap_merge_is_idempotent():
    m = ORMap("r1")
    m.set("k", "v")
    before = m.value()
    m.merge(deepcopy(m))
    assert m.value() == before


def test_ormap_merge_is_commutative_on_values():
    a = ORMap("A")
    a.set("k", "va")
    b = ORMap("B")
    b.set("k", "vb")
    left = deepcopy(a)
    left.merge(deepcopy(b))
    right = deepcopy(b)
    right.merge(deepcopy(a))
    assert set(left.value()["k"]) == set(right.value()["k"])


def test_ormap_merge_is_associative():
    a = ORMap("A")
    a.set("k", "va")
    b = ORMap("B")
    b.set("k", "vb")
    c = ORMap("C")
    c.set("k", "vc")

    left = deepcopy(a)
    left.merge(deepcopy(b))
    left.merge(deepcopy(c))

    right = deepcopy(a)
    bc = deepcopy(b)
    bc.merge(deepcopy(c))
    right.merge(bc)

    assert set(left.value()["k"]) == set(right.value()["k"])


def test_ormap_merge_type_mismatch_raises():
    m = ORMap("r1")
    with pytest.raises(TypeError):
        m.merge("nope")  # type: ignore[arg-type]


def test_ormap_merge_empty_is_noop():
    m = ORMap("r1")
    m.set("k", "v")
    before = m.value()
    m.merge(ORMap("r1"))
    assert m.value() == before


def test_ormap_add_wins_over_concurrent_remove():
    # A sets "k", B sees it and removes, A concurrently re-sets
    a = ORMap("A")
    a.set("k", "v1")
    b = deepcopy(a)
    b.replica_id = "B"
    b.remove("k")
    # A concurrently sets k again
    a.set("k", "v2")
    a.merge(b)
    # v2 should still be alive (added after B's observed-remove)
    assert "v2" in a.get("k")


def test_ormap_to_from_dict_roundtrip():
    m = ORMap("r1")
    m.set("a", 1)
    m.set("b", "two")
    dup = ORMap.from_dict(m.to_dict())
    assert dup.value() == m.value()


def test_ormap_empty_replica_id_raises():
    with pytest.raises(ReplicaError):
        ORMap("")


def test_ormap_is_not_hashable():
    with pytest.raises(TypeError):
        hash(ORMap("r1"))


def test_ormap_unhashable_key_raises():
    m = ORMap("r1")
    with pytest.raises(TypeError):
        m.set([1, 2], "v")


def test_ormap_keys_returns_live_only():
    m = ORMap("r1")
    m.set("a", 1)
    m.set("b", 2)
    m.remove("a")
    assert m.keys() == frozenset({"b"})
