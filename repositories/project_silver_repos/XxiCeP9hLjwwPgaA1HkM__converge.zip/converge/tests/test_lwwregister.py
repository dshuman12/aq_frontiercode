"""Tests for :class:`converge.LWWRegister`."""
from __future__ import annotations

from copy import deepcopy

import pytest

from converge import LWWRegister
from converge.errors import ReplicaError


def test_lww_reg_initial_value_and_ts():
    r = LWWRegister("r1", initial="hello", ts=0)
    assert r.value() == "hello"


def test_lww_reg_set_overrides_when_ts_greater():
    r = LWWRegister("r1", initial="a", ts=0)
    r.set("b", ts=5)
    assert r.value() == "b"
    assert r.ts == 5


def test_lww_reg_set_stale_ts_ignored():
    r = LWWRegister("r1", initial="a", ts=5)
    r.set("b", ts=1)
    assert r.value() == "a"


def test_lww_reg_default_clock_is_monotonic():
    r = LWWRegister("r1", initial=None, ts=0)
    r.set("a")
    r.set("b")
    assert r.value() == "b"


def test_lww_reg_merge_picks_higher_ts():
    a = LWWRegister("a", initial="x", ts=1)
    b = LWWRegister("b", initial="y", ts=3)
    a.merge(b)
    assert a.value() == "y"


def test_lww_reg_merge_tiebreak_by_writer_lex():
    # same ts, different writers: lex-greater writer wins.
    a = LWWRegister("alpha")
    b = LWWRegister("beta")
    a.set("from-a", ts=5)
    b.set("from-b", ts=5)
    a.merge(deepcopy(b))
    # ("5", "beta") > ("5", "alpha") lexicographically on replica_id.
    assert a.value() == "from-b"


def test_lww_reg_merge_type_mismatch_raises():
    r = LWWRegister("r1")
    with pytest.raises(TypeError):
        r.merge("nope")  # type: ignore[arg-type]


def test_lww_reg_merge_empty_is_noop():
    r = LWWRegister("r1", initial="x", ts=1)
    r.merge(LWWRegister("r1", initial=None, ts=0))
    # (1, "r1") > (0, "r1") so value stays "x".
    assert r.value() == "x"


def test_lww_reg_merge_idempotent():
    r = LWWRegister("r1", initial="x", ts=5)
    before = r.value()
    r.merge(deepcopy(r))
    assert r.value() == before


def test_lww_reg_commutative_merge_on_values():
    a = LWWRegister("a")
    b = LWWRegister("b")
    a.set("from-a", ts=2)
    b.set("from-b", ts=3)
    left = deepcopy(a)
    left.merge(deepcopy(b))
    right = deepcopy(b)
    right.merge(deepcopy(a))
    assert left.value() == right.value()


def test_lww_reg_to_from_dict_roundtrip():
    r = LWWRegister("r1", initial="x", ts=2)
    r.set("y", ts=3)
    dup = LWWRegister.from_dict(r.to_dict())
    assert dup == r
    assert dup.value() == "y"


def test_lww_reg_empty_replica_id_raises():
    with pytest.raises(ReplicaError):
        LWWRegister("")


def test_lww_reg_is_not_hashable():
    with pytest.raises(TypeError):
        hash(LWWRegister("r1"))
