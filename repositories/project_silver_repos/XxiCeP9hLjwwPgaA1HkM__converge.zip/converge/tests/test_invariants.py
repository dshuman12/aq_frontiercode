"""Cross-type invariant tests: idempotence, commutativity, associativity.

Every state-based CRDT in converge must satisfy:

* ``a.merge(deepcopy(a))`` leaves ``a.value()`` unchanged.
* ``a.merge(b)`` and ``b.merge(a)`` yield the same ``.value()``.
* ``(a⊔b)⊔c == a⊔(b⊔c)`` on values.
* Type mismatch on merge raises ``TypeError``.
* Merging an empty instance of the same type is a no-op.
* ``to_dict`` / ``from_dict`` round-trip is equal.
* ``__hash__`` is ``None``.

These invariants are exercised here across every CRDT type using a single
parametrized matrix so that any regression is caught in one file.
"""
from __future__ import annotations

import random
from copy import deepcopy
from typing import Any, Callable

import pytest

from converge import (
    GCounter,
    LWWRegister,
    LWWSet,
    MVRegister,
    ORSet,
    PNCounter,
    RGA,
    TwoPSet,
)


SEED = 0xCAFEBABE


# ---------------------------------------------------------------------------
# Per-type builder functions
# ---------------------------------------------------------------------------
def build_gcounter(replica: str, rng: random.Random) -> GCounter:
    g = GCounter(replica)
    for _ in range(rng.randint(0, 5)):
        g.increment(rng.randint(1, 7))
    return g


def build_pncounter(replica: str, rng: random.Random) -> PNCounter:
    p = PNCounter(replica)
    for _ in range(rng.randint(0, 5)):
        if rng.random() < 0.5:
            p.increment(rng.randint(1, 5))
        else:
            p.decrement(rng.randint(1, 5))
    return p


def build_twopset(replica: str, rng: random.Random) -> TwoPSet:
    s = TwoPSet(replica)
    for _ in range(rng.randint(0, 5)):
        s.add(rng.randint(0, 4))
    if s.value() and rng.random() < 0.4:
        victim = next(iter(s.value()))
        s.remove(victim)
    return s


def build_orset(replica: str, rng: random.Random) -> ORSet:
    s = ORSet(replica)
    for _ in range(rng.randint(0, 5)):
        s.add(rng.randint(0, 4))
    if s.value() and rng.random() < 0.4:
        victim = next(iter(s.value()))
        s.remove(victim)
    return s


def build_lwwset(replica: str, rng: random.Random) -> LWWSet:
    s = LWWSet(replica)
    for _ in range(rng.randint(0, 5)):
        s.add(rng.randint(0, 4), ts=rng.randint(1, 100))
    return s


def build_lwwregister(replica: str, rng: random.Random) -> LWWRegister:
    r = LWWRegister(replica, initial=None, ts=0)
    for _ in range(rng.randint(0, 3)):
        r.set(rng.randint(0, 1000), ts=rng.randint(1, 100))
    return r


def build_mvregister(replica: str, rng: random.Random) -> MVRegister:
    r = MVRegister(replica)
    for _ in range(rng.randint(0, 3)):
        r.set(rng.randint(0, 1000))
    return r


def build_rga(replica: str, rng: random.Random) -> RGA:
    r = RGA(replica)
    for _ in range(rng.randint(0, 4)):
        pos = rng.randint(0, len(r))
        r.insert_at(pos, rng.randint(0, 100))
    if len(r) > 0 and rng.random() < 0.3:
        r.delete_at(rng.randint(0, len(r) - 1))
    return r


# ---------------------------------------------------------------------------
# Empty-same-type factories
# ---------------------------------------------------------------------------
def empty_gcounter(replica: str) -> GCounter: return GCounter(replica)
def empty_pncounter(replica: str) -> PNCounter: return PNCounter(replica)
def empty_twopset(replica: str) -> TwoPSet: return TwoPSet(replica)
def empty_orset(replica: str) -> ORSet: return ORSet(replica)
def empty_lwwset(replica: str) -> LWWSet: return LWWSet(replica)
def empty_lwwregister(replica: str) -> LWWRegister:
    return LWWRegister(replica, initial=None, ts=0)
def empty_mvregister(replica: str) -> MVRegister: return MVRegister(replica)
def empty_rga(replica: str) -> RGA: return RGA(replica)


Builder = Callable[[str, random.Random], Any]
Empty = Callable[[str], Any]


CRDT_MATRIX: list[tuple[str, Builder, Empty]] = [
    ("GCounter", build_gcounter, empty_gcounter),
    ("PNCounter", build_pncounter, empty_pncounter),
    ("TwoPSet", build_twopset, empty_twopset),
    ("ORSet", build_orset, empty_orset),
    ("LWWSet", build_lwwset, empty_lwwset),
    ("LWWRegister", build_lwwregister, empty_lwwregister),
    ("MVRegister", build_mvregister, empty_mvregister),
    ("RGA", build_rga, empty_rga),
]


def _value_equal(name: str, u: Any, v: Any) -> bool:
    """Return True if two observed values should be considered equal."""
    # MVRegister.values() is a list of concurrent values whose order is
    # deterministic but not semantically meaningful -- compare as sets.
    if name == "MVRegister":
        return set(u) == set(v)
    return u == v


# ---------------------------------------------------------------------------
# Parametrized cross-type tests
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("name,build,empty", CRDT_MATRIX, ids=[m[0] for m in CRDT_MATRIX])
def test_idempotence_of_merge(name, build, empty):
    rng = random.Random(SEED)
    inst = build("r1", rng)
    before = inst.value()
    inst.merge(deepcopy(inst))
    after = inst.value()
    assert _value_equal(name, before, after)


@pytest.mark.parametrize("name,build,empty", CRDT_MATRIX, ids=[m[0] for m in CRDT_MATRIX])
def test_commutativity_of_merge(name, build, empty):
    rng = random.Random(SEED + 1)
    a = build("a", rng)
    b = build("b", rng)
    left = deepcopy(a)
    left.merge(deepcopy(b))
    right = deepcopy(b)
    right.merge(deepcopy(a))
    assert _value_equal(name, left.value(), right.value())


@pytest.mark.parametrize("name,build,empty", CRDT_MATRIX, ids=[m[0] for m in CRDT_MATRIX])
def test_associativity_of_merge(name, build, empty):
    rng = random.Random(SEED + 2)
    a = build("a", rng)
    b = build("b", rng)
    c = build("c", rng)

    left = deepcopy(a)
    left.merge(deepcopy(b))
    left.merge(deepcopy(c))

    right = deepcopy(a)
    bc = deepcopy(b)
    bc.merge(deepcopy(c))
    right.merge(bc)

    assert _value_equal(name, left.value(), right.value())


@pytest.mark.parametrize("name,build,empty", CRDT_MATRIX, ids=[m[0] for m in CRDT_MATRIX])
def test_merge_empty_is_noop(name, build, empty):
    rng = random.Random(SEED + 3)
    inst = build("r1", rng)
    before = inst.value()
    inst.merge(empty("r1"))
    assert _value_equal(name, before, inst.value())


@pytest.mark.parametrize("name,build,empty", CRDT_MATRIX, ids=[m[0] for m in CRDT_MATRIX])
def test_merge_type_mismatch_raises(name, build, empty):
    rng = random.Random(SEED + 4)
    inst = build("r1", rng)
    with pytest.raises(TypeError):
        inst.merge("not-the-right-type")


@pytest.mark.parametrize("name,build,empty", CRDT_MATRIX, ids=[m[0] for m in CRDT_MATRIX])
def test_to_from_dict_roundtrip(name, build, empty):
    rng = random.Random(SEED + 5)
    inst = build("r1", rng)
    cls = type(inst)
    dup = cls.from_dict(inst.to_dict())
    assert _value_equal(name, dup.value(), inst.value())


@pytest.mark.parametrize("name,build,empty", CRDT_MATRIX, ids=[m[0] for m in CRDT_MATRIX])
def test_eq_is_value_based_for_same_replica(name, build, empty):
    rng = random.Random(SEED + 6)
    a = build("r1", rng)
    b = deepcopy(a)
    assert a == b


@pytest.mark.parametrize("name,build,empty", CRDT_MATRIX, ids=[m[0] for m in CRDT_MATRIX])
def test_instances_are_not_hashable(name, build, empty):
    inst = empty("r1")
    with pytest.raises(TypeError):
        hash(inst)


# ---------------------------------------------------------------------------
# Merged convergence tests: two sides converge when they see the same history
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("name,build,empty", CRDT_MATRIX, ids=[m[0] for m in CRDT_MATRIX])
def test_two_replica_convergence(name, build, empty):
    rng = random.Random(SEED + 7)
    a = build("a", rng)
    b = build("b", rng)

    a_copy = deepcopy(a)
    b_copy = deepcopy(b)

    # Both sides see the same merged state, just in opposite orders.
    a.merge(deepcopy(b_copy))
    b.merge(deepcopy(a_copy))
    assert _value_equal(name, a.value(), b.value())


# ---------------------------------------------------------------------------
# Merge does not mutate the "other" argument.
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("name,build,empty", CRDT_MATRIX, ids=[m[0] for m in CRDT_MATRIX])
def test_merge_does_not_mutate_other(name, build, empty):
    rng = random.Random(SEED + 8)
    a = build("a", rng)
    b = build("b", rng)
    before = deepcopy(b.value())
    a.merge(b)
    assert _value_equal(name, b.value(), before)


# ---------------------------------------------------------------------------
# Per-replica empty constructor raises on empty replica id.
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("name,build,empty", CRDT_MATRIX, ids=[m[0] for m in CRDT_MATRIX])
def test_empty_replica_id_raises(name, build, empty):
    from converge.errors import ReplicaError

    with pytest.raises(ReplicaError):
        empty("")
