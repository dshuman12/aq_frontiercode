"""Cross-type invariants for the expansion CRDTs.

Verifies idempotence, commutativity, associativity, empty-merge-noop,
type-mismatch-TypeError, and to/from_dict round-trips for the new state-based
CRDTs added in the expansion modules.

Delta-CRDTs (DeltaGCounter, DeltaORSet) and sync primitives are not included
here because the invariants apply differently (deltas have an apply_delta path)
and they are covered in their own test modules.
"""
from __future__ import annotations

import random
from copy import deepcopy
from typing import Any, Callable

import pytest

from converge import (
    BCounter,
    GSet,
    LWWMap,
    MaxRegister,
    MinRegister,
    ORMap,
)


SEED = 0xFEEDFACE


# ---------------------------------------------------------------------------
# Builder / empty factories
# ---------------------------------------------------------------------------

def build_gset(replica: str, rng: random.Random) -> GSet:
    s = GSet(replica)
    for _ in range(rng.randint(0, 4)):
        s.add(rng.randint(0, 10))
    return s


def empty_gset(replica: str) -> GSet:
    return GSet(replica)


def build_maxreg(replica: str, rng: random.Random) -> MaxRegister:
    r = MaxRegister(replica)
    for _ in range(rng.randint(1, 3)):
        r.update(rng.randint(1, 100))
    return r


def empty_maxreg(replica: str) -> MaxRegister:
    return MaxRegister(replica)


def build_minreg(replica: str, rng: random.Random) -> MinRegister:
    r = MinRegister(replica)
    for _ in range(rng.randint(1, 3)):
        r.update(rng.randint(1, 100))
    return r


def empty_minreg(replica: str) -> MinRegister:
    return MinRegister(replica)


def build_bcounter(replica: str, rng: random.Random) -> BCounter:
    bc = BCounter(replica)
    bc.increment(rng.randint(1, 10))
    if rng.random() < 0.5:
        # Maybe do a small decrement within quota
        q = bc.local_quota()
        if q > 0:
            bc.decrement(rng.randint(1, q))
    return bc


def empty_bcounter(replica: str) -> BCounter:
    return BCounter(replica)


def build_ormap(replica: str, rng: random.Random) -> ORMap:
    m = ORMap(replica)
    for _ in range(rng.randint(1, 3)):
        m.set(f"k{rng.randint(0, 3)}", rng.randint(0, 100))
    return m


def empty_ormap(replica: str) -> ORMap:
    return ORMap(replica)


def build_lwwmap(replica: str, rng: random.Random) -> LWWMap:
    m = LWWMap(replica)
    for _ in range(rng.randint(1, 3)):
        m.set(f"k{rng.randint(0, 3)}", rng.randint(0, 100), ts=rng.randint(1, 100))
    return m


def empty_lwwmap(replica: str) -> LWWMap:
    return LWWMap(replica)


Builder = Callable[[str, random.Random], Any]
Empty = Callable[[str], Any]


CRDT_MATRIX: list[tuple[str, Builder, Empty]] = [
    ("GSet", build_gset, empty_gset),
    ("MaxRegister", build_maxreg, empty_maxreg),
    ("MinRegister", build_minreg, empty_minreg),
    ("BCounter", build_bcounter, empty_bcounter),
    ("ORMap", build_ormap, empty_ormap),
    ("LWWMap", build_lwwmap, empty_lwwmap),
]


def _value_equal(name: str, u: Any, v: Any) -> bool:
    """Return True if two observed values are equal given the CRDT's shape.

    ORMap.value() returns {k: [v1, v2, ...]} where the order of concurrent
    values is insertion-order but semantically unordered; compare as sets.
    """
    if name == "ORMap":
        if set(u.keys()) != set(v.keys()):
            return False
        for k in u:
            if set(u[k]) != set(v[k]):
                return False
        return True
    return u == v


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("name,build,empty", CRDT_MATRIX, ids=[m[0] for m in CRDT_MATRIX])
def test_idempotence_of_merge(name, build, empty):
    rng = random.Random(SEED)
    inst = build("r1", rng)
    before = deepcopy(inst.value())
    inst.merge(deepcopy(inst))
    assert _value_equal(name, before, inst.value())


@pytest.mark.parametrize("name,build,empty", CRDT_MATRIX, ids=[m[0] for m in CRDT_MATRIX])
def test_commutativity_of_merge(name, build, empty):
    rng = random.Random(SEED + 1)
    a = build("A", rng)
    b = build("B", rng)
    left = deepcopy(a)
    left.merge(deepcopy(b))
    right = deepcopy(b)
    right.merge(deepcopy(a))
    assert _value_equal(name, left.value(), right.value())


@pytest.mark.parametrize("name,build,empty", CRDT_MATRIX, ids=[m[0] for m in CRDT_MATRIX])
def test_associativity_of_merge(name, build, empty):
    rng = random.Random(SEED + 2)
    a = build("A", rng)
    b = build("B", rng)
    c = build("C", rng)

    left = deepcopy(a)
    left.merge(deepcopy(b))
    left.merge(deepcopy(c))

    right = deepcopy(a)
    bc = deepcopy(b)
    bc.merge(deepcopy(c))
    right.merge(bc)

    assert _value_equal(name, left.value(), right.value())


@pytest.mark.parametrize("name,build,empty", CRDT_MATRIX, ids=[m[0] for m in CRDT_MATRIX])
def test_merge_empty_is_noop(name, build, empty):
    rng = random.Random(SEED + 3)
    inst = build("r1", rng)
    before = deepcopy(inst.value())
    inst.merge(empty("r1"))
    assert _value_equal(name, before, inst.value())


@pytest.mark.parametrize("name,build,empty", CRDT_MATRIX, ids=[m[0] for m in CRDT_MATRIX])
def test_merge_type_mismatch_raises(name, build, empty):
    rng = random.Random(SEED + 4)
    inst = build("r1", rng)
    with pytest.raises(TypeError):
        inst.merge("not-the-right-type")


@pytest.mark.parametrize("name,build,empty", CRDT_MATRIX, ids=[m[0] for m in CRDT_MATRIX])
def test_to_from_dict_roundtrip(name, build, empty):
    rng = random.Random(SEED + 5)
    inst = build("r1", rng)
    cls = type(inst)
    dup = cls.from_dict(inst.to_dict())
    assert _value_equal(name, dup.value(), inst.value())


@pytest.mark.parametrize("name,build,empty", CRDT_MATRIX, ids=[m[0] for m in CRDT_MATRIX])
def test_two_replica_convergence(name, build, empty):
    rng = random.Random(SEED + 6)
    a = build("A", rng)
    b = build("B", rng)
    a_copy = deepcopy(a)
    b_copy = deepcopy(b)
    a.merge(deepcopy(b_copy))
    b.merge(deepcopy(a_copy))
    assert _value_equal(name, a.value(), b.value())


@pytest.mark.parametrize("name,build,empty", CRDT_MATRIX, ids=[m[0] for m in CRDT_MATRIX])
def test_merge_does_not_mutate_other(name, build, empty):
    rng = random.Random(SEED + 7)
    a = build("A", rng)
    b = build("B", rng)
    before = deepcopy(b.value())
    a.merge(b)
    assert _value_equal(name, b.value(), before)


@pytest.mark.parametrize("name,build,empty", CRDT_MATRIX, ids=[m[0] for m in CRDT_MATRIX])
def test_empty_instance_is_not_hashable(name, build, empty):
    inst = empty("r1")
    with pytest.raises(TypeError):
        hash(inst)


@pytest.mark.parametrize("name,build,empty", CRDT_MATRIX, ids=[m[0] for m in CRDT_MATRIX])
def test_empty_replica_id_raises(name, build, empty):
    from converge.errors import ReplicaError
    with pytest.raises(ReplicaError):
        empty("")
