"""Tests for :class:`converge.ORSet`."""
from __future__ import annotations

from copy import deepcopy

import pytest

from converge import ORSet
from converge.errors import ConvergeError, ReplicaError


def test_or_empty_value():
    s = ORSet("r1")
    assert s.value() == frozenset()


def test_or_add_then_contains():
    s = ORSet("r1")
    s.add("apple")
    assert s.contains("apple")
    assert s.value() == frozenset({"apple"})


def test_or_remove_of_added_element_hides_it():
    s = ORSet("r1")
    s.add("apple")
    s.remove("apple")
    assert not s.contains("apple")


def test_or_remove_of_unseen_element_raises():
    s = ORSet("r1")
    with pytest.raises(ConvergeError):
        s.remove("ghost")


def test_or_multiple_adds_produce_multiple_dots():
    s = ORSet("r1")
    s.add("x")
    s.add("x")
    dots = s.to_dict()["elements"]
    [entry] = [e for e in dots if e["element"] == "x"]
    assert len(entry["dots"]) == 2


def test_or_sequential_add_remove_add_stays_present():
    s = ORSet("r1")
    s.add("x")
    s.remove("x")
    s.add("x")
    assert s.contains("x")


def test_or_concurrent_add_and_remove_add_wins():
    # a.remove(x) based on dot_a only; b.add(x) produces a fresh dot_b.
    a = ORSet("a")
    a.add("x")
    b = deepcopy(a)      # b has observed dot_a
    a.remove("x")        # a tombstones dot_a
    b.add("x")           # b mints a fresh dot_b for x (concurrent add)

    merged = deepcopy(a)
    merged.merge(deepcopy(b))
    assert merged.contains("x"), "add-wins: concurrent add survives remove"


def test_or_concurrent_removes_converge():
    a = ORSet("a")
    a.add("x")
    b = deepcopy(a)
    a.remove("x")
    b.remove("x")
    a.merge(deepcopy(b))
    assert not a.contains("x")


def test_or_tombstones_preserved_across_merges():
    a = ORSet("a")
    a.add("x")
    a.remove("x")
    b = ORSet("b")
    b.merge(a)
    # b should now know the tombstone.
    assert not b.contains("x")
    c = ORSet("c")
    c.add("x")           # fresh add with a new replica_id / counter
    b.merge(c)
    # the newly-added dot from c is alive because the tombstones from a don't cover it.
    assert b.contains("x")


def test_or_merge_is_commutative_on_values():
    a = ORSet("a")
    b = ORSet("b")
    a.add("x")
    b.add("y")
    left = deepcopy(a)
    left.merge(deepcopy(b))
    right = deepcopy(b)
    right.merge(deepcopy(a))
    assert left.value() == right.value()


def test_or_merge_is_associative_on_values():
    a = ORSet("a")
    b = ORSet("b")
    c = ORSet("c")
    a.add("x")
    b.add("y")
    c.add("z")
    c.remove("z")
    left = deepcopy(a)
    left.merge(deepcopy(b))
    left.merge(deepcopy(c))
    right = deepcopy(a)
    bc = deepcopy(b)
    bc.merge(deepcopy(c))
    right.merge(bc)
    assert left.value() == right.value()


def test_or_merge_is_idempotent():
    s = ORSet("r1")
    s.add("x")
    s.add("y")
    s.remove("x")
    s.merge(deepcopy(s))
    assert s.value() == frozenset({"y"})


def test_or_merge_empty_is_noop():
    s = ORSet("r1")
    s.add("x")
    s.merge(ORSet("r1"))
    assert s.value() == frozenset({"x"})


def test_or_merge_type_mismatch_raises():
    with pytest.raises(TypeError):
        ORSet("r1").merge("no")  # type: ignore[arg-type]


def test_or_to_from_dict_roundtrip_preserves_state():
    s = ORSet("r1")
    s.add("x")
    s.add("y")
    s.remove("x")
    dup = ORSet.from_dict(s.to_dict())
    assert dup == s
    assert dup.value() == s.value()


def test_or_empty_replica_id_raises():
    with pytest.raises(ReplicaError):
        ORSet("")


def test_or_is_not_hashable():
    with pytest.raises(TypeError):
        hash(ORSet("r1"))


def test_or_dot_counts_remain_bounded_after_many_ops():
    s = ORSet("r1")
    for i in range(50):
        s.add(i)
        s.remove(i)
    # 50 adds + 50 removes -> 50 tombstones, 0 live dots.
    serialized = s.to_dict()
    live_dots = sum(len(e["dots"]) for e in serialized["elements"])
    assert live_dots == 0
    assert len(serialized["tombstones"]) == 50


def test_or_unhashable_element_raises():
    s = ORSet("r1")
    with pytest.raises(TypeError):
        s.add({"not": "hashable"})


def test_or_three_way_concurrent_add_converges():
    a = ORSet("a")
    b = ORSet("b")
    c = ORSet("c")
    a.add("x")
    b.add("x")
    c.add("x")
    a.merge(deepcopy(b))
    a.merge(deepcopy(c))
    assert a.contains("x")


def test_or_remove_then_concurrent_add_merges_both_sides():
    a = ORSet("a")
    a.add("x")
    b = deepcopy(a)
    a.remove("x")           # a tombstones its dot
    # b remains with dot_a alive; now b adds another dot for x.
    b.add("x")
    a.merge(deepcopy(b))
    # x should be present since at least one of b's two dots survives.
    assert a.contains("x")
