"""Tests for :class:`converge.LWWSet`."""
from __future__ import annotations

from copy import deepcopy

import pytest

from converge import LWWSet
from converge.errors import ReplicaError


def test_lww_set_empty_value():
    s = LWWSet("r1")
    assert s.value() == frozenset()


def test_lww_set_add_then_contains():
    s = LWWSet("r1")
    s.add("x", ts=1)
    assert s.contains("x")


def test_lww_set_later_add_beats_earlier_remove():
    s = LWWSet("r1")
    s.remove("x", ts=1)
    s.add("x", ts=2)
    assert s.contains("x")


def test_lww_set_later_remove_beats_earlier_add():
    s = LWWSet("r1")
    s.add("x", ts=1)
    s.remove("x", ts=2)
    assert not s.contains("x")


def test_lww_set_explicit_ts_respected():
    s = LWWSet("r1")
    s.add("x", ts=10)
    s.add("x", ts=5)   # stale, no-op
    assert s.to_dict()["adds"][0]["ts"] == 10


def test_lww_set_tie_breaks_on_replica_id_lex():
    # Both sides add 'x' at same ts; writer with greater replica_id wins,
    # which then controls remove/add resolution.
    a = LWWSet("alpha")
    b = LWWSet("beta")
    a.add("x", ts=1)
    b.remove("x", ts=1)
    # (1, "alpha") vs (1, "beta"): beta > alpha lex, so remove wins.
    a.merge(deepcopy(b))
    assert not a.contains("x")


def test_lww_set_same_writer_same_ts_remove_wins():
    s = LWWSet("r1")
    s.add("x", ts=5)
    s.remove("x", ts=5)
    # Stamps (5, "r1") tie; contains requires strict '>' so remove wins.
    assert not s.contains("x")


def test_lww_set_merge_type_mismatch_raises():
    with pytest.raises(TypeError):
        LWWSet("r").merge("nope")  # type: ignore[arg-type]


def test_lww_set_merge_empty_is_noop():
    s = LWWSet("r1")
    s.add("x", ts=1)
    s.merge(LWWSet("r1"))
    assert s.contains("x")


def test_lww_set_merge_idempotent():
    s = LWWSet("r1")
    s.add("x", ts=3)
    s.remove("y", ts=1)
    s.merge(deepcopy(s))
    assert s.contains("x")
    assert not s.contains("y")


def test_lww_set_merge_commutative_on_values():
    a = LWWSet("a")
    b = LWWSet("b")
    a.add("x", ts=2)
    b.remove("x", ts=1)
    left = deepcopy(a)
    left.merge(deepcopy(b))
    right = deepcopy(b)
    right.merge(deepcopy(a))
    assert left.value() == right.value()


def test_lww_set_to_from_dict_roundtrip():
    s = LWWSet("r1")
    s.add("x", ts=5)
    s.remove("y", ts=3)
    dup = LWWSet.from_dict(s.to_dict())
    assert dup == s
    assert dup.value() == s.value()


def test_lww_set_empty_replica_id_raises():
    with pytest.raises(ReplicaError):
        LWWSet("")


def test_lww_set_is_not_hashable():
    with pytest.raises(TypeError):
        hash(LWWSet("r"))


def test_lww_set_default_clock_monotonic_without_explicit_ts():
    s = LWWSet("r1")
    s.add("x")
    s.remove("x")
    assert not s.contains("x")
