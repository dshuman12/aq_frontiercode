"""Tests for :class:`converge.GSet`."""
from __future__ import annotations

from copy import deepcopy

import pytest

from converge import GSet
from converge.errors import ConvergeError, ReplicaError


def test_gset_empty_value():
    s = GSet("r1")
    assert s.value() == frozenset()
    assert len(s) == 0


def test_gset_add_then_contains():
    s = GSet("r1")
    s.add("a")
    assert s.contains("a")
    assert "a" in s
    assert s.value() == frozenset({"a"})


def test_gset_add_is_idempotent_locally():
    s = GSet("r1")
    s.add("x")
    s.add("x")
    assert s.value() == frozenset({"x"})
    assert len(s) == 1


def test_gset_has_no_remove_method():
    s = GSet("r1")
    assert not hasattr(s, "remove")


def test_gset_merge_union_semantics():
    a = GSet("a")
    a.add(1)
    a.add(2)
    b = GSet("b")
    b.add(2)
    b.add(3)
    a.merge(b)
    assert a.value() == frozenset({1, 2, 3})


def test_gset_merge_is_idempotent():
    s = GSet("r1")
    s.add("a")
    s.add("b")
    before = s.value()
    s.merge(deepcopy(s))
    assert s.value() == before


def test_gset_merge_is_commutative_on_values():
    a = GSet("a")
    a.add(1)
    a.add(2)
    b = GSet("b")
    b.add(3)
    left = deepcopy(a)
    left.merge(deepcopy(b))
    right = deepcopy(b)
    right.merge(deepcopy(a))
    assert left.value() == right.value()


def test_gset_merge_is_associative():
    a = GSet("a")
    a.add(1)
    b = GSet("b")
    b.add(2)
    c = GSet("c")
    c.add(3)

    left = deepcopy(a)
    left.merge(deepcopy(b))
    left.merge(deepcopy(c))

    right = deepcopy(a)
    bc = deepcopy(b)
    bc.merge(deepcopy(c))
    right.merge(bc)
    assert left.value() == right.value()


def test_gset_merge_empty_is_noop():
    s = GSet("r1")
    s.add("a")
    before = s.value()
    s.merge(GSet("r1"))
    assert s.value() == before


def test_gset_merge_type_mismatch_raises():
    s = GSet("r1")
    with pytest.raises(TypeError):
        s.merge("not-a-gset")  # type: ignore[arg-type]


def test_gset_to_from_dict_roundtrip():
    s = GSet("r1")
    s.add(1)
    s.add("two")
    dup = GSet.from_dict(s.to_dict())
    assert dup.value() == s.value()


def test_gset_empty_replica_id_raises():
    with pytest.raises(ReplicaError):
        GSet("")


def test_gset_is_not_hashable():
    s = GSet("r1")
    with pytest.raises(TypeError):
        hash(s)


def test_gset_unhashable_add_raises():
    s = GSet("r1")
    with pytest.raises(TypeError):
        s.add([1, 2, 3])  # lists aren't hashable


def test_gset_update_multi_elements():
    s = GSet("r1")
    s.update([1, 2, 3])
    assert s.value() == frozenset({1, 2, 3})


def test_gset_is_subset_monotonic_after_merge():
    a = GSet("a")
    a.add(1)
    a_before = deepcopy(a)
    b = GSet("b")
    b.add(2)
    a.merge(b)
    assert a_before.is_subset(a)


def test_gset_from_dict_bad_type_raises():
    with pytest.raises(ConvergeError):
        GSet.from_dict({"type": "NotGSet", "replica_id": "r1", "elements": []})
