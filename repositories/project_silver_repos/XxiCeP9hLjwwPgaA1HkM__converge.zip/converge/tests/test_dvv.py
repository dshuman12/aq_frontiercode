"""Tests for :class:`converge.DottedVersionVector`."""
from __future__ import annotations

from copy import deepcopy

import pytest

from converge import DottedVersionVector
from converge.errors import ReplicaError


def test_dvv_empty_constructor():
    dvv = DottedVersionVector()
    assert dvv.base == {}
    assert dvv.dots == set()


def test_dvv_observe_contiguous_compacts_into_base():
    dvv = DottedVersionVector()
    dvv.observe("a", 1)
    assert dvv.base == {"a": 1}
    assert dvv.dots == set()


def test_dvv_observe_non_contiguous_stays_in_dots():
    dvv = DottedVersionVector()
    dvv.observe("a", 3)
    assert dvv.base.get("a", 0) == 0
    assert ("a", 3) in dvv.dots


def test_dvv_observe_already_in_base_is_idempotent():
    dvv = DottedVersionVector(base={"a": 5})
    before_base = dict(dvv.base)
    before_dots = set(dvv.dots)
    dvv.observe("a", 3)  # already covered
    dvv.observe("a", 5)  # equal to base
    assert dvv.base == before_base
    assert dvv.dots == before_dots


def test_dvv_observe_cascade_compaction():
    dvv = DottedVersionVector()
    # Observe 2 and 3 out of order -- both should stay as dots.
    dvv.observe("a", 2)
    dvv.observe("a", 3)
    assert dvv.base.get("a", 0) == 0
    assert {("a", 2), ("a", 3)} <= dvv.dots

    # Observing 1 closes the gap: everything chains into the base.
    dvv.observe("a", 1)
    assert dvv.base == {"a": 3}
    assert dvv.dots == set()


def test_dvv_next_dot_extends_base_not_dots():
    dvv = DottedVersionVector()
    replica, counter = dvv.next_dot("r1")
    assert (replica, counter) == ("r1", 1)
    assert dvv.base == {"r1": 1}
    assert dvv.dots == set()

    replica, counter = dvv.next_dot("r1")
    assert (replica, counter) == ("r1", 2)
    assert dvv.base == {"r1": 2}


def test_dvv_next_dot_after_gap_fills_then_cascades():
    dvv = DottedVersionVector()
    dvv.observe("r1", 2)  # hole at 1
    assert dvv.dots == {("r1", 2)}
    # next_dot mints counter 1, which cascades to absorb the dot at 2.
    dvv.next_dot("r1")
    assert dvv.base == {"r1": 2}
    assert dvv.dots == set()


def test_dvv_contains_dot_checks_base_and_dots():
    dvv = DottedVersionVector(base={"r": 3}, dots={("r", 5)})
    assert dvv.contains_dot("r", 1)
    assert dvv.contains_dot("r", 3)
    assert not dvv.contains_dot("r", 4)
    assert dvv.contains_dot("r", 5)
    assert not dvv.contains_dot("r", 6)


def test_dvv_merge_unions_bases_and_dots_and_compacts():
    a = DottedVersionVector(base={"r": 2}, dots={("r", 5)})
    b = DottedVersionVector(base={}, dots={("r", 3), ("r", 4)})
    a.merge(b)
    # After merge: 1,2 base; 3,4 dots chain in; 5 chains in too.
    assert a.base == {"r": 5}
    assert a.dots == set()


def test_dvv_merge_type_mismatch_raises():
    with pytest.raises(TypeError):
        DottedVersionVector().merge("not a dvv")  # type: ignore[arg-type]


def test_dvv_merge_empty_is_noop():
    a = DottedVersionVector(base={"r": 2}, dots={("r", 4)})
    before = a.to_dict()
    a.merge(DottedVersionVector())
    assert a.to_dict() == before


def test_dvv_merge_idempotence():
    a = DottedVersionVector(base={"x": 3}, dots={("x", 7), ("y", 2)})
    before_dict = a.to_dict()
    a.merge(deepcopy(a))
    assert a.to_dict() == before_dict


def test_dvv_to_from_dict_roundtrip():
    original = DottedVersionVector(
        base={"a": 2, "b": 1}, dots={("a", 5), ("c", 7)}
    )
    dup = DottedVersionVector.from_dict(original.to_dict())
    assert dup == original


def test_dvv_empty_replica_id_raises_replica_error():
    with pytest.raises(ReplicaError):
        DottedVersionVector(base={"": 1})
    with pytest.raises(ReplicaError):
        DottedVersionVector().observe("", 1)


def test_dvv_counter_must_be_positive():
    dvv = DottedVersionVector()
    with pytest.raises(ValueError):
        dvv.observe("a", 0)


def test_dvv_is_not_hashable():
    with pytest.raises(TypeError):
        hash(DottedVersionVector())


def test_dvv_equality_is_value_based():
    a = DottedVersionVector(base={"a": 1}, dots={("a", 3)})
    b = DottedVersionVector(base={"a": 1}, dots={("a", 3)})
    assert a == b
    assert a is not b
