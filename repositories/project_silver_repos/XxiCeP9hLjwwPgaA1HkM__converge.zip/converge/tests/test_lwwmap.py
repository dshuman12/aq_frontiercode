"""Tests for :class:`converge.LWWMap`."""
from __future__ import annotations

from copy import deepcopy

import pytest

from converge import LWWMap
from converge.errors import ReplicaError


def test_lwwmap_empty_value():
    m = LWWMap("r1")
    assert m.value() == {}


def test_lwwmap_set_then_get():
    m = LWWMap("r1")
    m.set("k", "v")
    assert m.get("k") == "v"
    assert m.contains("k")


def test_lwwmap_get_unknown_returns_default():
    m = LWWMap("r1")
    assert m.get("ghost") is None
    assert m.get("ghost", "default") == "default"


def test_lwwmap_later_ts_wins():
    m = LWWMap("r1")
    m.set("k", "v1", ts=1)
    m.set("k", "v2", ts=5)
    assert m.get("k") == "v2"


def test_lwwmap_earlier_ts_is_ignored():
    m = LWWMap("r1")
    m.set("k", "v1", ts=5)
    m.set("k", "v2", ts=3)
    assert m.get("k") == "v1"


def test_lwwmap_remove_makes_absent():
    m = LWWMap("r1")
    m.set("k", "v", ts=1)
    m.remove("k", ts=2)
    assert not m.contains("k")


def test_lwwmap_remove_then_readd_with_higher_ts():
    m = LWWMap("r1")
    m.set("k", "v1", ts=1)
    m.remove("k", ts=2)
    m.set("k", "v2", ts=3)
    assert m.get("k") == "v2"
    assert m.contains("k")


def test_lwwmap_remove_with_lower_ts_is_ignored():
    m = LWWMap("r1")
    m.set("k", "v", ts=5)
    m.remove("k", ts=1)
    # The newer set still wins.
    assert m.get("k") == "v"


def test_lwwmap_merge_larger_ts_wins():
    a = LWWMap("A")
    a.set("k", "va", ts=1)
    b = LWWMap("B")
    b.set("k", "vb", ts=5)
    a.merge(b)
    assert a.get("k") == "vb"


def test_lwwmap_merge_is_idempotent():
    m = LWWMap("r1")
    m.set("k", "v", ts=1)
    before = m.value()
    m.merge(deepcopy(m))
    assert m.value() == before


def test_lwwmap_merge_is_commutative_on_values():
    a = LWWMap("A")
    a.set("k", "va", ts=1)
    b = LWWMap("B")
    b.set("k", "vb", ts=5)
    left = deepcopy(a)
    left.merge(deepcopy(b))
    right = deepcopy(b)
    right.merge(deepcopy(a))
    assert left.value() == right.value()


def test_lwwmap_merge_is_associative():
    a = LWWMap("A")
    a.set("k", "va", ts=1)
    b = LWWMap("B")
    b.set("k", "vb", ts=2)
    c = LWWMap("C")
    c.set("k", "vc", ts=3)

    left = deepcopy(a)
    left.merge(deepcopy(b))
    left.merge(deepcopy(c))

    right = deepcopy(a)
    bc = deepcopy(b)
    bc.merge(deepcopy(c))
    right.merge(bc)
    assert left.value() == right.value()


def test_lwwmap_merge_type_mismatch_raises():
    m = LWWMap("r1")
    with pytest.raises(TypeError):
        m.merge("nope")  # type: ignore[arg-type]


def test_lwwmap_merge_empty_is_noop():
    m = LWWMap("r1")
    m.set("k", "v", ts=1)
    before = m.value()
    m.merge(LWWMap("r1"))
    assert m.value() == before


def test_lwwmap_tie_ts_writer_breaks():
    a = LWWMap("A")
    a.set("k", "va", ts=5)
    b = LWWMap("B")
    b.set("k", "vb", ts=5)
    a.merge(b)
    # Larger writer "B" wins the tiebreak
    assert a.get("k") == "vb"


def test_lwwmap_to_from_dict_roundtrip():
    m = LWWMap("r1")
    m.set("a", 1, ts=1)
    m.set("b", "two", ts=2)
    dup = LWWMap.from_dict(m.to_dict())
    assert dup.value() == m.value()


def test_lwwmap_empty_replica_id_raises():
    with pytest.raises(ReplicaError):
        LWWMap("")


def test_lwwmap_is_not_hashable():
    with pytest.raises(TypeError):
        hash(LWWMap("r1"))


def test_lwwmap_keys_returns_live_only():
    m = LWWMap("r1")
    m.set("a", 1, ts=1)
    m.set("b", 2, ts=2)
    m.remove("a", ts=3)
    assert m.keys() == frozenset({"b"})
