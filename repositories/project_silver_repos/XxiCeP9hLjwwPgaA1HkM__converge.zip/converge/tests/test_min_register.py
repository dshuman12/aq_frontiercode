"""Tests for :class:`converge.MinRegister`."""
from __future__ import annotations

from copy import deepcopy

import pytest

from converge import MinRegister
from converge.errors import ReplicaError


def test_min_empty_value_is_none():
    r = MinRegister("r1")
    assert r.value() is None


def test_min_first_update_lands():
    r = MinRegister("r1")
    r.update(5)
    assert r.value() == 5


def test_min_update_monotonic_decrease():
    r = MinRegister("r1")
    r.update(10)
    r.update(3)
    r.update(7)
    assert r.value() == 3


def test_min_update_none_is_rejected():
    r = MinRegister("r1")
    with pytest.raises(TypeError):
        r.update(None)


def test_min_merge_none_is_identity():
    a = MinRegister("a")
    a.update(10)
    b = MinRegister("b")
    a.merge(b)
    assert a.value() == 10


def test_min_merge_takes_smaller():
    a = MinRegister("a")
    a.update(10)
    b = MinRegister("b")
    b.update(3)
    a.merge(b)
    assert a.value() == 3


def test_min_equal_value_tiebreak_smaller_replica_wins():
    a = MinRegister("B")
    a.update(5)
    b = MinRegister("A")
    b.update(5)
    a.merge(b)
    assert a.value() == 5
    # Smaller writer "A" should win the tiebreak
    assert a.writer == "A"


def test_min_merge_is_idempotent():
    r = MinRegister("r1")
    r.update(42)
    before = r.value()
    r.merge(deepcopy(r))
    assert r.value() == before


def test_min_merge_is_commutative_on_values():
    a = MinRegister("A")
    a.update(3)
    b = MinRegister("B")
    b.update(7)
    left = deepcopy(a)
    left.merge(deepcopy(b))
    right = deepcopy(b)
    right.merge(deepcopy(a))
    assert left.value() == right.value()


def test_min_merge_is_associative():
    a = MinRegister("A")
    a.update(10)
    b = MinRegister("B")
    b.update(5)
    c = MinRegister("C")
    c.update(3)

    left = deepcopy(a)
    left.merge(deepcopy(b))
    left.merge(deepcopy(c))

    right = deepcopy(a)
    bc = deepcopy(b)
    bc.merge(deepcopy(c))
    right.merge(bc)
    assert left.value() == right.value()


def test_min_merge_type_mismatch_raises():
    r = MinRegister("r1")
    with pytest.raises(TypeError):
        r.merge("not-a-register")  # type: ignore[arg-type]


def test_min_incomparable_update_raises_type_error():
    r = MinRegister("r1")
    r.update(5)
    with pytest.raises(TypeError):
        r.update("string")


def test_min_to_from_dict_roundtrip():
    r = MinRegister("r1")
    r.update(42)
    dup = MinRegister.from_dict(r.to_dict())
    assert dup.value() == r.value()
    assert dup.writer == r.writer


def test_min_empty_replica_id_raises():
    with pytest.raises(ReplicaError):
        MinRegister("")


def test_min_initial_value_in_constructor():
    r = MinRegister("r1", initial=10)
    assert r.value() == 10


def test_min_is_not_hashable():
    r = MinRegister("r1")
    with pytest.raises(TypeError):
        hash(r)
