"""Tests for :class:`converge.VectorClock`."""
from __future__ import annotations

from copy import deepcopy

import pytest

from converge import VectorClock
from converge.errors import ReplicaError


def test_vc_empty_constructor_has_no_replicas():
    vc = VectorClock()
    assert vc.replicas() == frozenset()
    assert vc.to_dict() == {"counts": {}}


def test_vc_seeded_constructor_drops_zero_counts():
    vc = VectorClock({"a": 1, "b": 0, "c": 3})
    assert vc.get("a") == 1
    assert vc.get("b") == 0
    assert vc.get("c") == 3
    # Zero-valued replicas should not appear as tracked replicas.
    assert "b" not in vc.replicas()


def test_vc_missing_key_defaults_to_zero():
    vc = VectorClock({"a": 4})
    assert vc.get("never-seen") == 0


def test_vc_increment_creates_and_grows():
    vc = VectorClock()
    vc.increment("a")
    vc.increment("a")
    vc.increment("b")
    assert vc.get("a") == 2
    assert vc.get("b") == 1


def test_vc_merge_is_componentwise_max_in_place():
    left = VectorClock({"a": 1, "b": 5})
    right = VectorClock({"a": 3, "c": 2})
    left.merge(right)
    assert left.get("a") == 3
    assert left.get("b") == 5
    assert left.get("c") == 2
    # right is unchanged by an in-place merge into left.
    assert right.get("a") == 3
    assert right.get("b") == 0


def test_vc_descends_equal_and_subset_and_superset():
    a = VectorClock({"x": 2, "y": 1})
    b = VectorClock({"x": 2, "y": 1})
    assert a.descends(b)
    assert b.descends(a)

    super_ = VectorClock({"x": 3, "y": 1})
    sub = VectorClock({"x": 1})
    assert super_.descends(sub)
    assert not sub.descends(super_)


def test_vc_dominates_requires_strict_dominance():
    equal_a = VectorClock({"x": 1})
    equal_b = VectorClock({"x": 1})
    assert not equal_a.dominates(equal_b)
    bigger = VectorClock({"x": 2})
    assert bigger.dominates(equal_a)
    assert not equal_a.dominates(bigger)


def test_vc_concurrent_when_neither_dominates():
    a = VectorClock({"x": 1, "y": 0})
    b = VectorClock({"x": 0, "y": 1})
    assert a.is_concurrent_with(b)
    assert b.is_concurrent_with(a)


def test_vc_not_concurrent_when_ordered_or_equal():
    a = VectorClock({"x": 1})
    b = VectorClock({"x": 2})
    assert not a.is_concurrent_with(b)
    c = VectorClock({"x": 1})
    # equal clocks are considered NOT concurrent in DESIGN (neither dominates)
    # but descends is mutual -> not concurrent per "neither dominates" phrasing.
    # Implementation uses: not descends AND not descends_reversed => False when equal.
    assert not a.is_concurrent_with(c)


def test_vc_merge_empty_is_noop():
    vc = VectorClock({"a": 2})
    before = dict(vc.to_dict()["counts"])
    vc.merge(VectorClock())
    assert vc.to_dict()["counts"] == before


def test_vc_merge_type_mismatch_raises():
    vc = VectorClock()
    with pytest.raises(TypeError):
        vc.merge("not a clock")  # type: ignore[arg-type]


def test_vc_to_from_dict_roundtrip():
    vc = VectorClock({"a": 10, "b": 3})
    dup = VectorClock.from_dict(vc.to_dict())
    assert dup == vc


def test_vc_equality_is_value_based():
    a = VectorClock({"x": 2})
    b = VectorClock({"x": 2})
    assert a == b
    assert a is not b


def test_vc_empty_replica_id_raises_replica_error():
    with pytest.raises(ReplicaError):
        VectorClock({"": 1})
    vc = VectorClock()
    with pytest.raises(ReplicaError):
        vc.increment("")


def test_vc_non_string_replica_id_raises_replica_error():
    with pytest.raises(ReplicaError):
        VectorClock({1: 1})  # type: ignore[dict-item]


def test_vc_is_not_hashable():
    with pytest.raises(TypeError):
        hash(VectorClock())


def test_vc_negative_count_rejected():
    with pytest.raises(ValueError):
        VectorClock({"a": -1})


def test_vc_idempotence_of_merge():
    vc = VectorClock({"a": 2, "b": 1})
    vc.merge(deepcopy(vc))
    assert vc == VectorClock({"a": 2, "b": 1})


def test_vc_commutative_merge_values():
    a = VectorClock({"a": 1, "b": 3})
    b = VectorClock({"a": 5})
    left = deepcopy(a)
    left.merge(deepcopy(b))
    right = deepcopy(b)
    right.merge(deepcopy(a))
    assert left == right


def test_vc_associative_merge_values():
    a = VectorClock({"a": 1})
    b = VectorClock({"b": 2})
    c = VectorClock({"a": 3, "c": 1})
    left = deepcopy(a)
    left.merge(deepcopy(b))
    left.merge(deepcopy(c))
    right = deepcopy(a)
    bc = deepcopy(b)
    bc.merge(deepcopy(c))
    right.merge(bc)
    assert left == right


@pytest.mark.parametrize(
    "left, right, expected",
    [
        ({"a": 1}, {"a": 1}, True),
        ({"a": 2}, {"a": 1}, True),
        ({"a": 1}, {"a": 2}, False),
        ({"a": 1, "b": 1}, {"a": 1}, True),
        ({"a": 1}, {"a": 1, "b": 1}, False),
    ],
)
def test_vc_descends_parametrized(left, right, expected):
    assert VectorClock(left).descends(VectorClock(right)) is expected
