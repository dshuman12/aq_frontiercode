# converge

State-based Conflict-free Replicated Data Types (CRDTs) in pure Python — stdlib only, no runtime dependencies.

`converge` provides counters, sets, registers, and a sequence type that each satisfy idempotent, commutative, and associative `merge` semantics, so replicas can exchange state in any order (and with duplicates) and still arrive at the same observed value.

## Install / quickstart

`converge` targets **Python 3.11+** and has **no runtime dependencies**. There is no `pip install` step — drop the repo on your `PYTHONPATH` and import:

```bash
git clone https://github.com/parapath/converge.git
cd converge
export PYTHONPATH=.
python -c "from converge import GCounter; print(GCounter('a'))"
```

## Examples

### `GCounter` — grow-only counter

```python
from converge import GCounter

a = GCounter("replica-a")
b = GCounter("replica-b")
a.increment(3)
b.increment(5)
a.merge(b)           # in-place
assert a.value() == 8
```

### `ORSet` — observed-remove set (add-wins)

```python
from converge import ORSet

a = ORSet("a")
b = ORSet("b")
a.add("apple")
b.add("apple")       # concurrent add of same element
b.remove("apple")    # removes only the dot b observed
a.merge(b)           # a's dot for "apple" is still alive → add wins
assert "apple" in a.value()
```

### `LWWRegister` — last-writer-wins register

```python
from converge import LWWRegister

a = LWWRegister("a", initial="draft", ts=0)
b = LWWRegister("b", initial="draft", ts=0)
a.set("v1", ts=1)
b.set("v2", ts=2)    # later timestamp
a.merge(b)
assert a.value() == "v2"
```

### `RGA` — replicated growable array

```python
from converge import RGA

a = RGA("a")
b = RGA("b")
a.insert_at(0, "H")
a.insert_at(1, "i")
b.merge(a)
b.insert_at(2, "!")  # concurrent with a deleting 'i'
a.delete_at(1)
a.merge(b)
b.merge(a)
assert a.to_list() == b.to_list()   # deterministic convergence
```

## Public API

Top-level imports re-exported from `converge`:

- Causality: `VectorClock`, `DottedVersionVector`
- Counters: `GCounter`, `PNCounter`
- Sets: `TwoPSet`, `ORSet`, `LWWSet`
- Registers: `LWWRegister`, `MVRegister`
- Sequence: `RGA`
- Errors: `ConvergeError`, `CausalError`, `ReplicaError`

Every CRDT exposes the same minimal contract: a `replica_id`-keyed constructor, local mutation methods, `value()` (or `values()` for `MVRegister`), an in-place `merge(other)`, and JSON-safe `to_dict` / `from_dict` round-trip. See `DESIGN.md` for the full specification.

## Running tests

```bash
PYTHONPATH=. pytest tests/ -v
```

Dev dependencies (test-only): `pytest==8.3.3`, `pytest-cov==5.0.0`.

A reproducible test environment is also available via Docker:

```bash
docker build -t converge .
docker run --rm converge
```

## License

MIT — see [`LICENSE`](./LICENSE).
