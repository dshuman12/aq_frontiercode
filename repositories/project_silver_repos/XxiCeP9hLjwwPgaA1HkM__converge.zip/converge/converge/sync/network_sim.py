"""In-memory network simulator for CRDT sync messages.

:class:`NetworkSim` models a faulty transport between named replicas. It
supports probabilistic message drops, probabilistic reorders, per-message
random delay (``0..max_delay`` ticks), and bidirectional partitions that
auto-heal after a configurable number of ticks. The simulator is purely
in-memory, uses a seeded :class:`random.Random` instance for
reproducibility, and never touches real sockets or threads.
"""

from __future__ import annotations

import random
from typing import Any

from ..errors import ReplicaError


def _validate_replica_id(replica_id: Any, label: str = "replica_id") -> None:
    """Raise :class:`ReplicaError` if ``replica_id`` is not a non-empty string."""
    if not isinstance(replica_id, str):
        raise ReplicaError(
            f"{label} must be a str, got {type(replica_id).__name__}"
        )
    if replica_id == "":
        raise ReplicaError(f"{label} must be a non-empty string")


def _validate_prob(value: Any, label: str) -> float:
    """Validate a probability in the closed interval [0.0, 1.0]."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{label} must be a float in [0, 1]")
    f = float(value)
    if f < 0.0 or f > 1.0:
        raise ValueError(f"{label} must be in [0.0, 1.0], got {f}")
    return f


class NetworkSim:
    """Simulate a faulty network carrying CRDT sync messages.

    Messages submitted via :meth:`send` are queued with a per-message
    random delay in ``[0, max_delay]``; on each :meth:`tick`, matured
    messages are moved into destination inboxes unless they have been
    dropped (``drop_prob``) or blocked by an active partition. Inboxes
    are drained by :meth:`inbox`.
    """

    __slots__ = (
        "_seed",
        "_drop_prob",
        "_reorder_prob",
        "_max_delay",
        "_rng",
        "_tick_index",
        "_queue",
        "_inboxes",
        "_partitions",
        "_seq",
        "_sent",
        "_dropped",
        "_delivered",
        "_reordered",
    )

    def __init__(
        self,
        *,
        seed: int = 0,
        drop_prob: float = 0.0,
        reorder_prob: float = 0.0,
        max_delay: int = 0,
    ) -> None:
        """Configure the simulator with the given reliability parameters."""
        if not isinstance(seed, int) or isinstance(seed, bool):
            raise TypeError("seed must be int")
        self._drop_prob: float = _validate_prob(drop_prob, "drop_prob")
        self._reorder_prob: float = _validate_prob(
            reorder_prob, "reorder_prob"
        )
        if not isinstance(max_delay, int) or isinstance(max_delay, bool):
            raise TypeError("max_delay must be int")
        if max_delay < 0:
            raise ValueError("max_delay must be non-negative")

        self._seed: int = seed
        self._max_delay: int = max_delay
        self._rng: random.Random = random.Random(seed)
        self._tick_index: int = 0

        # Each entry: (deliver_at, enqueue_seq, src, dst, payload)
        self._queue: list[tuple[int, int, str, str, Any]] = []
        self._inboxes: dict[str, list[tuple[str, Any]]] = {}
        # frozenset({a, b}) -> expiry tick index (exclusive upper bound)
        self._partitions: dict[frozenset[str], int] = {}
        self._seq: int = 0

        self._sent: int = 0
        self._dropped: int = 0
        self._delivered: int = 0
        self._reordered: int = 0

    # ------------------------------------------------------------------ #
    # Accessors
    # ------------------------------------------------------------------ #
    @property
    def seed(self) -> int:
        """Return the RNG seed."""
        return self._seed

    @property
    def drop_prob(self) -> float:
        """Return the drop probability (inclusive 0..1)."""
        return self._drop_prob

    @property
    def reorder_prob(self) -> float:
        """Return the reorder probability (inclusive 0..1)."""
        return self._reorder_prob

    @property
    def max_delay(self) -> int:
        """Return the maximum message delay in ticks."""
        return self._max_delay

    @property
    def current_tick(self) -> int:
        """Return the number of ticks that have been advanced so far."""
        return self._tick_index

    # ------------------------------------------------------------------ #
    # Message injection
    # ------------------------------------------------------------------ #
    def send(self, src: str, dst: str, payload: Any) -> None:
        """Enqueue a message from ``src`` to ``dst`` with ``payload``.

        The message is dropped at enqueue time with probability
        ``drop_prob``; otherwise a random delay in ``[0, max_delay]`` is
        sampled and the message is stored until its maturity tick.
        """
        _validate_replica_id(src, "src")
        _validate_replica_id(dst, "dst")
        if src == dst:
            raise ValueError("src and dst must differ")

        self._sent += 1

        if self._drop_prob > 0.0 and self._rng.random() < self._drop_prob:
            self._dropped += 1
            return

        delay = (
            self._rng.randint(0, self._max_delay)
            if self._max_delay > 0
            else 0
        )
        self._seq += 1
        entry = (
            self._tick_index + delay,
            self._seq,
            src,
            dst,
            payload,
        )
        self._queue.append(entry)

    # ------------------------------------------------------------------ #
    # Partitioning
    # ------------------------------------------------------------------ #
    def partition(self, a: str, b: str, for_ticks: int) -> None:
        """Block traffic between ``a`` and ``b`` for ``for_ticks`` ticks.

        A message blocked by a partition is counted as dropped, not
        delayed; this matches the behavior of a real network partition
        which loses packets rather than buffering them.
        """
        _validate_replica_id(a, "a")
        _validate_replica_id(b, "b")
        if a == b:
            raise ValueError("a and b must differ")
        if not isinstance(for_ticks, int) or isinstance(for_ticks, bool):
            raise TypeError("for_ticks must be int")
        if for_ticks <= 0:
            raise ValueError("for_ticks must be positive")
        key = frozenset({a, b})
        expiry = self._tick_index + for_ticks
        # If there is already a partition in effect, extend to the later expiry.
        prev = self._partitions.get(key, 0)
        if expiry > prev:
            self._partitions[key] = expiry

    def heal(self, a: str, b: str) -> None:
        """Remove any active partition between ``a`` and ``b``."""
        _validate_replica_id(a, "a")
        _validate_replica_id(b, "b")
        if a == b:
            raise ValueError("a and b must differ")
        self._partitions.pop(frozenset({a, b}), None)

    def is_partitioned(self, a: str, b: str) -> bool:
        """Return True if ``a`` and ``b`` are currently partitioned."""
        _validate_replica_id(a, "a")
        _validate_replica_id(b, "b")
        if a == b:
            return False
        expiry = self._partitions.get(frozenset({a, b}))
        if expiry is None:
            return False
        return self._tick_index < expiry

    # ------------------------------------------------------------------ #
    # Simulation loop
    # ------------------------------------------------------------------ #
    def tick(self) -> None:
        """Advance the simulated clock by one tick.

        All messages whose maturity tick equals the new ``current_tick``
        either enter their destination inbox or are dropped because of
        an active partition. Within a single tick, delivered messages
        may be reordered pairwise (probability ``reorder_prob``).
        """
        self._tick_index += 1
        self._expire_partitions()

        matured: list[tuple[int, str, str, Any]] = []
        remaining: list[tuple[int, int, str, str, Any]] = []
        for deliver_at, seq, src, dst, payload in self._queue:
            if deliver_at <= self._tick_index:
                matured.append((seq, src, dst, payload))
            else:
                remaining.append((deliver_at, seq, src, dst, payload))
        self._queue = remaining

        # Group by destination; preserve per-destination enqueue order
        # (by seq). Apply reorder swaps within each destination group.
        matured.sort(key=lambda entry: entry[0])
        per_dst: dict[str, list[tuple[str, Any]]] = {}
        for _seq, src, dst, payload in matured:
            if self.is_partitioned(src, dst):
                self._dropped += 1
                continue
            per_dst.setdefault(dst, []).append((src, payload))

        for dst, messages in per_dst.items():
            if self._reorder_prob > 0.0 and len(messages) >= 2:
                self._apply_reorders(messages)
            inbox = self._inboxes.setdefault(dst, [])
            inbox.extend(messages)
            self._delivered += len(messages)

    def inbox(self, dst: str) -> list[tuple[str, Any]]:
        """Drain and return all pending ``(src, payload)`` messages for ``dst``."""
        _validate_replica_id(dst, "dst")
        bucket = self._inboxes.pop(dst, [])
        return bucket

    def peek_inbox(self, dst: str) -> list[tuple[str, Any]]:
        """Return a copy of ``dst``'s inbox without draining it."""
        _validate_replica_id(dst, "dst")
        return list(self._inboxes.get(dst, []))

    def pending(self) -> int:
        """Return the number of messages still in flight (undelivered)."""
        return len(self._queue)

    def stats(self) -> dict[str, int]:
        """Return running counters.

        Keys: ``sent`` (every :meth:`send` call), ``dropped`` (both
        probabilistic drops and partition drops), ``delivered`` (messages
        actually placed in an inbox), and ``reordered`` (number of
        in-tick swap operations applied by the reorder logic).
        """
        return {
            "sent": self._sent,
            "dropped": self._dropped,
            "delivered": self._delivered,
            "reordered": self._reordered,
        }

    # ------------------------------------------------------------------ #
    # Serialization
    # ------------------------------------------------------------------ #
    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-safe snapshot of the simulator.

        The pending message queue and inboxes are included so the whole
        simulation can be resumed after a round-trip through
        :meth:`from_dict`. Payloads are stored verbatim; if they are not
        JSON-serializable, callers must serialize them separately.
        """
        return {
            "type": "NetworkSim",
            "seed": self._seed,
            "drop_prob": self._drop_prob,
            "reorder_prob": self._reorder_prob,
            "max_delay": self._max_delay,
            "tick": self._tick_index,
            "seq": self._seq,
            "queue": [
                {
                    "deliver_at": d,
                    "seq": s,
                    "src": src,
                    "dst": dst,
                    "payload": payload,
                }
                for d, s, src, dst, payload in self._queue
            ],
            "inboxes": {
                dst: [[src, payload] for src, payload in msgs]
                for dst, msgs in self._inboxes.items()
            },
            "partitions": [
                {"peers": sorted(pair), "expiry": expiry}
                for pair, expiry in self._partitions.items()
            ],
            "stats": self.stats(),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> NetworkSim:
        """Rebuild a :class:`NetworkSim` from :meth:`to_dict` output."""
        if not isinstance(data, dict):
            raise TypeError("from_dict expects a dict")
        if data.get("type") != "NetworkSim":
            raise ValueError(
                f"from_dict: expected type 'NetworkSim', got {data.get('type')!r}"
            )
        sim = cls(
            seed=int(data.get("seed", 0)),
            drop_prob=float(data.get("drop_prob", 0.0)),
            reorder_prob=float(data.get("reorder_prob", 0.0)),
            max_delay=int(data.get("max_delay", 0)),
        )
        sim._tick_index = int(data.get("tick", 0))
        sim._seq = int(data.get("seq", 0))

        queue: list[tuple[int, int, str, str, Any]] = []
        for entry in data.get("queue", []):
            queue.append(
                (
                    int(entry["deliver_at"]),
                    int(entry["seq"]),
                    str(entry["src"]),
                    str(entry["dst"]),
                    entry.get("payload"),
                )
            )
        sim._queue = queue

        inboxes: dict[str, list[tuple[str, Any]]] = {}
        for dst, msgs in data.get("inboxes", {}).items():
            inboxes[str(dst)] = [
                (str(pair[0]), pair[1]) for pair in msgs
            ]
        sim._inboxes = inboxes

        partitions: dict[frozenset[str], int] = {}
        for entry in data.get("partitions", []):
            peers = entry.get("peers", [])
            if len(peers) != 2:
                raise ValueError("partition entry must have exactly 2 peers")
            partitions[frozenset({str(peers[0]), str(peers[1])})] = int(
                entry["expiry"]
            )
        sim._partitions = partitions

        stats = data.get("stats", {})
        sim._sent = int(stats.get("sent", 0))
        sim._dropped = int(stats.get("dropped", 0))
        sim._delivered = int(stats.get("delivered", 0))
        sim._reordered = int(stats.get("reordered", 0))
        return sim

    # ------------------------------------------------------------------ #
    # Dunder
    # ------------------------------------------------------------------ #
    def __eq__(self, other: object) -> bool:
        if not isinstance(other, NetworkSim):
            return NotImplemented
        return (
            self._seed == other._seed
            and self._drop_prob == other._drop_prob
            and self._reorder_prob == other._reorder_prob
            and self._max_delay == other._max_delay
            and self._tick_index == other._tick_index
            and self._queue == other._queue
            and self._inboxes == other._inboxes
            and self._partitions == other._partitions
            and self.stats() == other.stats()
        )

    def __repr__(self) -> str:
        return (
            f"NetworkSim(seed={self._seed}, drop_prob={self._drop_prob}, "
            f"reorder_prob={self._reorder_prob}, "
            f"max_delay={self._max_delay}, tick={self._tick_index}, "
            f"pending={len(self._queue)})"
        )

    __hash__ = None  # type: ignore[assignment]

    # ------------------------------------------------------------------ #
    # Internal helpers
    # ------------------------------------------------------------------ #
    def _expire_partitions(self) -> None:
        """Drop any partition whose expiry tick has been reached."""
        to_remove = [
            pair
            for pair, expiry in self._partitions.items()
            if expiry <= self._tick_index
        ]
        for pair in to_remove:
            del self._partitions[pair]

    def _apply_reorders(self, messages: list[tuple[str, Any]]) -> None:
        """Potentially swap adjacent pairs in ``messages``.

        The reorder loop makes a single left-to-right pass and, for each
        adjacent pair, swaps it with probability ``reorder_prob``. This
        lets ``reorder_prob`` behave as "per-adjacent-pair swap chance"
        which is easy to reason about in tests.
        """
        for i in range(len(messages) - 1):
            if self._rng.random() < self._reorder_prob:
                messages[i], messages[i + 1] = messages[i + 1], messages[i]
                self._reordered += 1
