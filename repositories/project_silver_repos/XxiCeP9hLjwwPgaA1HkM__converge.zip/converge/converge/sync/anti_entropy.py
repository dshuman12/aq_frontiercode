"""Anti-entropy round coordinator for CRDT replicas.

Provides :class:`AntiEntropyRound`, an in-memory gossip-style coordinator
that pairs up replicas and triggers bidirectional state merges. Two modes
are supported: ``pairwise`` (one random pair per tick) and
``round_robin`` (every ``a < b`` pair merges per tick). This is a
simulation primitive; a real deployment plugs its own transport in and
calls ``merge`` directly. Determinism is provided by a seeded
:class:`random.Random` so test runs are reproducible.
"""

from __future__ import annotations

import copy
import random
from typing import Any

from ..errors import ReplicaError


_VALID_MODES = ("pairwise", "round_robin")


def _validate_replica_id(replica_id: Any) -> None:
    """Raise :class:`ReplicaError` if ``replica_id`` is not a non-empty string."""
    if not isinstance(replica_id, str):
        raise ReplicaError(
            f"replica_id must be a str, got {type(replica_id).__name__}"
        )
    if replica_id == "":
        raise ReplicaError("replica_id must be a non-empty string")


def _check_crdt(crdt: Any) -> None:
    """Best-effort check that ``crdt`` supports the minimum CRDT contract."""
    if not hasattr(crdt, "merge") or not callable(getattr(crdt, "merge")):
        raise TypeError("crdt must expose a callable .merge(other) method")
    if not hasattr(crdt, "value") or not callable(getattr(crdt, "value")):
        raise TypeError("crdt must expose a callable .value() method")


class AntiEntropyRound:
    """Coordinate pairwise state merges across a set of replicas.

    Each ``tick`` advances one round: in ``pairwise`` mode a single random
    ordered pair performs a bidirectional state merge; in ``round_robin``
    mode every lexicographic ``(a, b)`` pair where ``a < b`` is merged.
    """

    __slots__ = ("_replicas", "_mode", "_seed", "_rng", "_round")

    def __init__(
        self,
        replicas: dict[str, Any],
        mode: str = "pairwise",
        seed: int = 0,
    ) -> None:
        """Create a coordinator over ``replicas`` keyed by replica id."""
        if not isinstance(replicas, dict):
            raise TypeError("replicas must be a dict of {replica_id: crdt}")
        if not isinstance(mode, str):
            raise TypeError("mode must be a str")
        if mode not in _VALID_MODES:
            raise ValueError(
                f"mode must be one of {_VALID_MODES!r}, got {mode!r}"
            )
        if not isinstance(seed, int) or isinstance(seed, bool):
            raise TypeError("seed must be int")

        self._replicas: dict[str, Any] = {}
        for rid, crdt in replicas.items():
            _validate_replica_id(rid)
            _check_crdt(crdt)
            self._replicas[rid] = crdt

        self._mode: str = mode
        self._seed: int = seed
        self._rng: random.Random = random.Random(seed)
        self._round: int = 0

    # ------------------------------------------------------------------ #
    # Membership
    # ------------------------------------------------------------------ #
    def add_replica(self, replica_id: str, crdt: Any) -> None:
        """Register a new replica under ``replica_id``."""
        _validate_replica_id(replica_id)
        _check_crdt(crdt)
        if replica_id in self._replicas:
            raise ReplicaError(f"replica_id already registered: {replica_id!r}")
        self._replicas[replica_id] = crdt

    def drop_replica(self, replica_id: str) -> None:
        """Remove ``replica_id`` from the coordinator."""
        _validate_replica_id(replica_id)
        if replica_id not in self._replicas:
            raise ReplicaError(f"unknown replica_id: {replica_id!r}")
        del self._replicas[replica_id]

    def replica_ids(self) -> list[str]:
        """Return a sorted list of registered replica ids."""
        return sorted(self._replicas.keys())

    def get_replica(self, replica_id: str) -> Any:
        """Return the CRDT registered under ``replica_id``."""
        _validate_replica_id(replica_id)
        if replica_id not in self._replicas:
            raise ReplicaError(f"unknown replica_id: {replica_id!r}")
        return self._replicas[replica_id]

    # ------------------------------------------------------------------ #
    # Accessors
    # ------------------------------------------------------------------ #
    @property
    def mode(self) -> str:
        """Return the coordinator mode (``pairwise`` or ``round_robin``)."""
        return self._mode

    @property
    def seed(self) -> int:
        """Return the RNG seed that was used to initialize this coordinator."""
        return self._seed

    @property
    def round_index(self) -> int:
        """Return how many ticks have been performed so far."""
        return self._round

    def __len__(self) -> int:
        return len(self._replicas)

    def __contains__(self, replica_id: object) -> bool:
        return isinstance(replica_id, str) and replica_id in self._replicas

    # ------------------------------------------------------------------ #
    # Core simulation
    # ------------------------------------------------------------------ #
    def tick(self) -> list[tuple[str, str]]:
        """Advance the coordinator by one round.

        Returns the list of ``(src, dst)`` pairs that were merged. Each
        pair represents a bidirectional merge: the destination first
        absorbs a deep-copied snapshot of the source, then the source
        absorbs a deep-copied snapshot of the destination.
        """
        self._round += 1
        pairs: list[tuple[str, str]] = []
        ids = sorted(self._replicas.keys())

        if len(ids) < 2:
            return pairs

        if self._mode == "pairwise":
            a, b = self._pick_random_pair(ids)
            self._bidirectional_merge(a, b)
            pairs.append((a, b))
            return pairs

        # round_robin: every (a, b) with a < b merges
        for i in range(len(ids)):
            for j in range(i + 1, len(ids)):
                a, b = ids[i], ids[j]
                self._bidirectional_merge(a, b)
                pairs.append((a, b))
        return pairs

    def run(self, rounds: int) -> None:
        """Run ``rounds`` consecutive :meth:`tick` invocations."""
        if not isinstance(rounds, int) or isinstance(rounds, bool):
            raise TypeError("rounds must be int")
        if rounds < 0:
            raise ValueError("rounds must be non-negative")
        for _ in range(rounds):
            self.tick()

    def converged(self) -> bool:
        """Return True iff every replica reports the same ``.value()``."""
        if len(self._replicas) < 2:
            return True
        iterator = iter(self._replicas.values())
        reference = next(iterator).value()
        for crdt in iterator:
            if crdt.value() != reference:
                return False
        return True

    # ------------------------------------------------------------------ #
    # Serialization
    # ------------------------------------------------------------------ #
    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-safe snapshot of the coordinator's metadata.

        The CRDT instances themselves are not serialized — only their
        replica ids, the mode/seed/round counter. Restoring requires the
        caller to provide the CRDT instances again to :meth:`from_dict`.
        """
        return {
            "type": "AntiEntropyRound",
            "mode": self._mode,
            "seed": self._seed,
            "round": self._round,
            "replica_ids": sorted(self._replicas.keys()),
        }

    @classmethod
    def from_dict(
        cls,
        data: dict[str, Any],
        replicas: dict[str, Any],
    ) -> AntiEntropyRound:
        """Rebuild a coordinator from :meth:`to_dict` output plus live replicas."""
        if not isinstance(data, dict):
            raise TypeError("from_dict expects a dict")
        if data.get("type") != "AntiEntropyRound":
            raise ValueError(
                f"from_dict: expected type 'AntiEntropyRound', got {data.get('type')!r}"
            )
        if not isinstance(replicas, dict):
            raise TypeError("replicas must be a dict of {replica_id: crdt}")
        expected_ids = set(data.get("replica_ids", []))
        if set(replicas.keys()) != expected_ids:
            raise ValueError(
                "replicas dict does not match the serialized replica ids"
            )
        instance = cls(
            replicas=replicas,
            mode=str(data.get("mode", "pairwise")),
            seed=int(data.get("seed", 0)),
        )
        # Advance the internal RNG to replay ``round`` ticks worth of
        # random selections so future ticks stay deterministic.
        round_count = int(data.get("round", 0))
        if round_count < 0:
            raise ValueError("round must be non-negative")
        ids = sorted(replicas.keys())
        if instance._mode == "pairwise" and len(ids) >= 2:
            for _ in range(round_count):
                instance._pick_random_pair(ids)
        instance._round = round_count
        return instance

    # ------------------------------------------------------------------ #
    # Dunder methods
    # ------------------------------------------------------------------ #
    def __eq__(self, other: object) -> bool:
        if not isinstance(other, AntiEntropyRound):
            return NotImplemented
        return (
            self._mode == other._mode
            and self._seed == other._seed
            and self._round == other._round
            and sorted(self._replicas.keys())
            == sorted(other._replicas.keys())
        )

    def __repr__(self) -> str:
        ids = ",".join(sorted(self._replicas.keys()))
        return (
            f"AntiEntropyRound(mode={self._mode!r}, seed={self._seed}, "
            f"round={self._round}, replicas=[{ids}])"
        )

    __hash__ = None  # type: ignore[assignment]

    # ------------------------------------------------------------------ #
    # Internal helpers
    # ------------------------------------------------------------------ #
    def _pick_random_pair(self, ids: list[str]) -> tuple[str, str]:
        """Pick two distinct ids deterministically from the internal RNG."""
        if len(ids) < 2:
            raise ReplicaError("need at least two replicas to pick a pair")
        i = self._rng.randrange(len(ids))
        j = self._rng.randrange(len(ids) - 1)
        if j >= i:
            j += 1
        return ids[i], ids[j]

    def _bidirectional_merge(self, a_id: str, b_id: str) -> None:
        """Merge replicas ``a_id`` and ``b_id`` in both directions.

        Deep-copy snapshots before cross-merging so that mutating ``a``
        halfway through the round does not then leak partial state back
        into ``b``. CRDT merge is idempotent and commutative, so the
        order of the two calls is immaterial for correctness, but using
        snapshots makes the behavior independent of insertion order.
        """
        a = self._replicas[a_id]
        b = self._replicas[b_id]
        snap_a = copy.deepcopy(a)
        snap_b = copy.deepcopy(b)
        a.merge(snap_b)
        b.merge(snap_a)
