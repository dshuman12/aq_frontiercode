"""State-based sync helper for CRDT replicas.

:class:`StateSync` wraps the simplest correct sync strategy for any
state-based CRDT: send the full serialized state and let the receiver
merge it. It exposes ``send_full_state`` to snapshot a replica,
``apply_state`` to merge a received snapshot, ``sync_pair`` to push both
directions between two replicas, ``converged`` to check equality of a
whole group, and ``size_estimate`` to approximate the on-the-wire cost.
"""

from __future__ import annotations

import copy
import json
from typing import Any, Sequence

from ..errors import ConvergeError


def _check_crdt(crdt: Any, label: str = "crdt") -> None:
    """Best-effort check that ``crdt`` satisfies the state-based contract."""
    if not hasattr(crdt, "merge") or not callable(getattr(crdt, "merge")):
        raise TypeError(f"{label} must expose a callable .merge(other) method")
    if not hasattr(crdt, "value") or not callable(getattr(crdt, "value")):
        raise TypeError(f"{label} must expose a callable .value() method")
    if not hasattr(crdt, "to_dict") or not callable(getattr(crdt, "to_dict")):
        raise TypeError(f"{label} must expose a callable .to_dict() method")
    if not hasattr(crdt, "from_dict") or not callable(
        getattr(type(crdt), "from_dict", None)
    ):
        raise TypeError(
            f"{label} must expose a callable classmethod .from_dict(d)"
        )


class StateSync:
    """State-based sync helper.

    All methods are effectively stateless except for a running byte-count
    meter used by :meth:`size_estimate`. Callers normally keep one
    instance around for bookkeeping, but multiple instances are cheap
    and independent.
    """

    __slots__ = ("_bytes_sent", "_syncs_performed")

    def __init__(self) -> None:
        """Construct a new helper with zeroed counters."""
        self._bytes_sent: int = 0
        self._syncs_performed: int = 0

    # ------------------------------------------------------------------ #
    # Accessors
    # ------------------------------------------------------------------ #
    @property
    def bytes_sent(self) -> int:
        """Return total bytes of state pushed by :meth:`send_full_state`."""
        return self._bytes_sent

    @property
    def syncs_performed(self) -> int:
        """Return the number of :meth:`sync_pair` invocations so far."""
        return self._syncs_performed

    def reset_stats(self) -> None:
        """Zero out the internal bookkeeping counters."""
        self._bytes_sent = 0
        self._syncs_performed = 0

    # ------------------------------------------------------------------ #
    # Core operations
    # ------------------------------------------------------------------ #
    def send_full_state(self, from_crdt: Any) -> dict[str, Any]:
        """Return a deep-copied, JSON-safe snapshot of ``from_crdt``'s state.

        The snapshot is a plain ``dict`` suitable for sending across any
        transport. The internal counter :attr:`bytes_sent` is advanced
        by the approximate serialized byte count.
        """
        _check_crdt(from_crdt, "from_crdt")
        raw = from_crdt.to_dict()
        snapshot = copy.deepcopy(raw)
        self._bytes_sent += _estimate_bytes(snapshot)
        return snapshot

    def apply_state(
        self,
        to_crdt: Any,
        incoming_state_dict: dict[str, Any],
    ) -> None:
        """Merge ``incoming_state_dict`` into ``to_crdt`` in place.

        The incoming dict is first rehydrated through the target's own
        ``from_dict`` classmethod so that the merge operates on a proper
        CRDT instance; this also surfaces any type mismatch as a
        ``ConvergeError`` before we touch the live replica.
        """
        _check_crdt(to_crdt, "to_crdt")
        if not isinstance(incoming_state_dict, dict):
            raise TypeError("incoming_state_dict must be a dict")
        cls = type(to_crdt)
        try:
            other = cls.from_dict(copy.deepcopy(incoming_state_dict))
        except (KeyError, TypeError, ValueError) as exc:
            raise ConvergeError(
                f"apply_state: cannot rebuild {cls.__name__} from payload: {exc}"
            ) from exc
        to_crdt.merge(other)

    def sync_pair(self, a: Any, b: Any) -> None:
        """Bidirectionally sync two replicas ``a`` and ``b``.

        Both sides are snapshotted first (deep copy), then each side
        merges the other's snapshot. This mirrors what
        :class:`AntiEntropyRound` does internally and ensures the result
        is independent of which side mutates first.
        """
        _check_crdt(a, "a")
        _check_crdt(b, "b")
        if type(a) is not type(b):
            raise TypeError(
                f"sync_pair requires matching CRDT types; got "
                f"{type(a).__name__} and {type(b).__name__}"
            )
        snap_a = self.send_full_state(a)
        snap_b = self.send_full_state(b)
        self.apply_state(a, snap_b)
        self.apply_state(b, snap_a)
        self._syncs_performed += 1

    def converged(self, crdts: Sequence[Any]) -> bool:
        """Return True iff every CRDT in ``crdts`` reports the same ``.value()``."""
        if not isinstance(crdts, Sequence) or isinstance(crdts, (str, bytes)):
            raise TypeError("crdts must be a non-string Sequence")
        if len(crdts) < 2:
            return True
        first = crdts[0]
        _check_crdt(first, "crdts[0]")
        reference = first.value()
        for index, crdt in enumerate(crdts[1:], start=1):
            _check_crdt(crdt, f"crdts[{index}]")
            if crdt.value() != reference:
                return False
        return True

    def size_estimate(self, crdt: Any) -> int:
        """Return an approximate serialized byte count for ``crdt``'s state."""
        _check_crdt(crdt, "crdt")
        return _estimate_bytes(crdt.to_dict())

    # ------------------------------------------------------------------ #
    # Serialization
    # ------------------------------------------------------------------ #
    def to_dict(self) -> dict[str, Any]:
        """Return a snapshot of the helper's bookkeeping counters."""
        return {
            "type": "StateSync",
            "bytes_sent": self._bytes_sent,
            "syncs_performed": self._syncs_performed,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> StateSync:
        """Rebuild a :class:`StateSync` from :meth:`to_dict` output."""
        if not isinstance(data, dict):
            raise TypeError("from_dict expects a dict")
        if data.get("type") != "StateSync":
            raise ValueError(
                f"from_dict: expected type 'StateSync', got {data.get('type')!r}"
            )
        instance = cls()
        bytes_sent = int(data.get("bytes_sent", 0))
        syncs = int(data.get("syncs_performed", 0))
        if bytes_sent < 0 or syncs < 0:
            raise ValueError("counters must be non-negative")
        instance._bytes_sent = bytes_sent
        instance._syncs_performed = syncs
        return instance

    # ------------------------------------------------------------------ #
    # Dunder
    # ------------------------------------------------------------------ #
    def __eq__(self, other: object) -> bool:
        if not isinstance(other, StateSync):
            return NotImplemented
        return (
            self._bytes_sent == other._bytes_sent
            and self._syncs_performed == other._syncs_performed
        )

    def __repr__(self) -> str:
        return (
            f"StateSync(bytes_sent={self._bytes_sent}, "
            f"syncs_performed={self._syncs_performed})"
        )

    __hash__ = None  # type: ignore[assignment]


def _estimate_bytes(payload: Any) -> int:
    """Best-effort byte-count of ``payload`` via a JSON serialization.

    Falls back to ``len(repr(payload))`` if the payload contains
    non-JSON-serializable values (e.g. an element inside an OR-Set that
    is not itself JSON-friendly). This keeps ``size_estimate`` usable
    even for exotic element types, at the price of a looser bound.
    """
    try:
        return len(json.dumps(payload, default=str, sort_keys=True))
    except (TypeError, ValueError):
        return len(repr(payload))
