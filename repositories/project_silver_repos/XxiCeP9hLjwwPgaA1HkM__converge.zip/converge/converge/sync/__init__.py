"""Sync-layer primitives for the converge library.

This subpackage exposes three simulation-friendly building blocks:
:class:`AntiEntropyRound` for pairwise gossip-style merges,
:class:`NetworkSim` for modeling a faulty in-memory transport, and
:class:`StateSync` for naive full-state synchronization between any two
replicas of the same CRDT type. None of these helpers perform real I/O.
"""

from __future__ import annotations

from .anti_entropy import AntiEntropyRound
from .network_sim import NetworkSim
from .state_sync import StateSync

__all__ = ["AntiEntropyRound", "NetworkSim", "StateSync"]
