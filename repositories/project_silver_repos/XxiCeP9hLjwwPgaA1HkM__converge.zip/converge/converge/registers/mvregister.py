"""Multi-Value register (MV-Register) built on a dotted version vector.

An :class:`MVRegister` preserves every concurrent write it has seen
instead of silently dropping losers as an LWW-Register does. Each
``set`` mints a fresh dot from a :class:`DottedVersionVector`; entries
whose dots are already dominated by the observing DVV are replaced,
while concurrent entries from other replicas survive side-by-side
until a later write observes them. Merging two registers unions their
entries and then drops any entry whose dot is contained in the *other*
side's DVV prior to the merge.
"""

from __future__ import annotations

from copy import deepcopy
from typing import Any

from ..causality import DottedVersionVector
from ..errors import ReplicaError


def _validate_replica_id(replica_id: Any) -> None:
    """Raise :class:`ReplicaError` if ``replica_id`` is not a non-empty string."""
    if not isinstance(replica_id, str) or replica_id == "":
        raise ReplicaError("replica_id must be a non-empty string")


class MVRegister:
    """Concurrent-value register tracking every unseen sibling write.

    Internal state consists of

    * ``_entries``: list of ``((replica_id, counter), value)`` pairs, one
      per live write, kept sorted by dot for deterministic serialization.
    * ``_dvv``: a :class:`DottedVersionVector` over every dot this
      replica has either minted or absorbed via merge.
    """

    __slots__ = ("_replica_id", "_entries", "_dvv")

    def __init__(self, replica_id: str) -> None:
        """Initialise an empty MV-Register owned by ``replica_id``."""
        _validate_replica_id(replica_id)
        self._replica_id: str = replica_id
        self._entries: list[tuple[tuple[str, int], Any]] = []
        self._dvv: DottedVersionVector = DottedVersionVector()

    # ------------------------------------------------------------------
    # Mutation
    # ------------------------------------------------------------------
    def set(self, value: Any) -> None:
        """Replace every write this replica has observed with ``value``.

        Any entry whose dot is already contained in ``self._dvv`` has
        been observed by this replica and is therefore superseded. A
        fresh dot is then allocated for the new write and appended.
        Entries whose dots are NOT in ``self._dvv`` (which can only
        happen transiently during merges that mutate the DVV before the
        entry list) are preserved as concurrent siblings.
        """
        # Partition first so the DVV membership test reflects the state
        # BEFORE we mint the new dot.
        surviving: list[tuple[tuple[str, int], Any]] = []
        for dot, val in self._entries:
            replica, counter = dot
            if not self._dvv.contains_dot(replica, counter):
                surviving.append((dot, val))
        new_dot = self._dvv.next_dot(self._replica_id)
        surviving.append((new_dot, value))
        self._entries = _sort_entries(surviving)

    # ------------------------------------------------------------------
    # Observation
    # ------------------------------------------------------------------
    def values(self) -> list[Any]:
        """Return the current list of concurrent values (order matches internal dot ordering)."""
        return [value for (_dot, value) in self._entries]

    def value(self) -> list[Any]:
        """Alias for :meth:`values` so the universal contract is satisfied."""
        return self.values()

    @property
    def replica_id(self) -> str:
        """Identifier of the replica owning this register instance."""
        return self._replica_id

    @property
    def dvv(self) -> DottedVersionVector:
        """Read-only view of the register's dotted version vector."""
        return self._dvv

    # ------------------------------------------------------------------
    # Merge
    # ------------------------------------------------------------------
    def merge(self, other: MVRegister) -> None:
        """Union entries, drop those dominated by the other side's DVV, then merge DVVs."""
        if not isinstance(other, MVRegister):
            raise TypeError("can only merge MVRegister with MVRegister")
        # Snapshot DVVs before they are mutated so the dominance tests
        # reflect the two replicas' pre-merge observation states.
        self_dvv_pre = deepcopy(self._dvv)
        other_dvv_pre = other._dvv

        kept: dict[tuple[str, int], Any] = {}
        # Own entries: survive unless the other side has observed them
        # (in which case the other side may have already replaced them).
        for dot, val in self._entries:
            if not other_dvv_pre.contains_dot(dot[0], dot[1]):
                kept[dot] = val
            elif dot in {d for (d, _v) in other._entries}:
                # Still live on the other side -- both sides agree.
                kept[dot] = val
        # Other entries: survive unless self has observed them (in which
        # case self may have already replaced them).
        for dot, val in other._entries:
            if not self_dvv_pre.contains_dot(dot[0], dot[1]):
                kept[dot] = val
            elif dot in {d for (d, _v) in self._entries}:
                kept[dot] = val

        self._dvv.merge(other._dvv)
        self._entries = _sort_entries(list(kept.items()))

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------
    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-safe dict representation."""
        return {
            "replica_id": self._replica_id,
            "entries": [
                [[dot[0], dot[1]], value] for (dot, value) in self._entries
            ],
            "dvv": self._dvv.to_dict(),
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> MVRegister:
        """Rebuild an :class:`MVRegister` from the output of :meth:`to_dict`."""
        if not isinstance(d, dict):
            raise TypeError("from_dict expects a dict")
        for key in ("replica_id", "entries", "dvv"):
            if key not in d:
                raise ValueError(f"missing key {key!r} in MVRegister dict")
        reg = cls(d["replica_id"])
        raw_entries = d["entries"]
        if not isinstance(raw_entries, (list, tuple)):
            raise TypeError("entries must be a list")
        entries: list[tuple[tuple[str, int], Any]] = []
        for item in raw_entries:
            if not (isinstance(item, (list, tuple)) and len(item) == 2):
                raise TypeError("each entry must be a [dot, value] pair")
            dot_raw, value = item
            if not (isinstance(dot_raw, (list, tuple)) and len(dot_raw) == 2):
                raise TypeError("dot must be a 2-element [replica, counter]")
            replica, counter = dot_raw
            if not isinstance(replica, str) or replica == "":
                raise ReplicaError("entry replica must be non-empty str")
            if not isinstance(counter, int) or isinstance(counter, bool):
                raise TypeError("entry counter must be int")
            entries.append(((replica, counter), value))
        reg._entries = _sort_entries(entries)
        reg._dvv = DottedVersionVector.from_dict(d["dvv"])
        return reg

    # ------------------------------------------------------------------
    # Dunder methods
    # ------------------------------------------------------------------
    def __eq__(self, other: object) -> bool:
        if not isinstance(other, MVRegister):
            return NotImplemented
        return (
            self._replica_id == other._replica_id
            and self._entries == other._entries
            and self._dvv == other._dvv
        )

    def __repr__(self) -> str:
        entries_repr = ", ".join(
            f"({r!r},{c})={v!r}" for ((r, c), v) in self._entries
        )
        return (
            f"MVRegister(replica_id={self._replica_id!r}, "
            f"entries=[{entries_repr}])"
        )

    __hash__ = None  # type: ignore[assignment]


# ----------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------
def _sort_entries(
    entries: list[tuple[tuple[str, int], Any]],
) -> list[tuple[tuple[str, int], Any]]:
    """Return ``entries`` sorted by dot ``(replica_id, counter)`` ascending."""
    return sorted(entries, key=lambda item: item[0])
