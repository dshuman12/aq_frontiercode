"""Monotonic-maximum register (Max-Register).

A :class:`MaxRegister` stores a single comparable value and only ever
moves "upwards" under the natural ordering of its element type. Writes
that do not strictly increase the value are discarded; ties are broken
by ``(value, writer_replica_id)`` so that concurrent equal writes
resolve deterministically across replicas.

The identity element is ``None``: an uninitialised register compares
less than any non-``None`` value so the first real write always wins.
Because both ``max`` and the lexicographic tiebreak are commutative
and associative, merge is a pure state-based join and is trivially
idempotent.
"""

from __future__ import annotations

from typing import Any

from converge.errors import ConvergeError, ReplicaError


def _validate_replica_id(replica_id: Any) -> str:
    """Validate that ``replica_id`` is a non-empty string.

    Raises :class:`ReplicaError` with a descriptive message when the
    argument has the wrong type or is empty. The helper is duplicated
    deliberately across modules so each CRDT remains readable in
    isolation.
    """
    if not isinstance(replica_id, str):
        raise ReplicaError(
            f"replica_id must be a str, got {type(replica_id).__name__}"
        )
    if replica_id == "":
        raise ReplicaError("replica_id must be a non-empty string")
    return replica_id


def _compare_strictly_greater(candidate: Any, current: Any) -> bool:
    """Return ``True`` iff ``candidate`` is strictly greater than ``current``.

    ``None`` acts as the identity element for the max register and is
    considered less than every real value. A :class:`TypeError` raised
    by ``<`` on incompatible types (for example comparing an ``int`` to
    a ``str``) is propagated so callers see the underlying problem
    instead of a cryptic "False".
    """
    if current is None and candidate is None:
        return False
    if current is None:
        return True
    if candidate is None:
        return False
    # Will raise TypeError if the operands are not mutually comparable.
    return candidate > current


class MaxRegister:
    """Register that monotonically advances to the maximum observed value.

    The register records the largest ``(value, writer)`` pair it has
    ever seen. The writer tag is used only for breaking ties on equal
    values so the resolution is deterministic even when two replicas
    submit the same value concurrently.
    """

    __hash__ = None  # type: ignore[assignment]

    def __init__(self, replica_id: str, initial: Any = None) -> None:
        """Create a max register owned by ``replica_id``.

        ``initial`` may be ``None`` (the identity) or any value that is
        comparable to itself. When a real initial value is supplied it
        is stamped as if this replica had just written it, so any
        later write must strictly exceed it to take effect.
        """
        self.replica_id = _validate_replica_id(replica_id)
        self.value_: Any = None
        self.ts: int | None = None
        self.writer: str | None = None
        if initial is not None:
            # Round-trip through ``update`` so we inherit all validation.
            self.update(initial)

    # ------------------------------------------------------------------ #
    # Mutation
    # ------------------------------------------------------------------ #
    def update(self, value: Any) -> None:
        """Advance the register to ``max(current, value)``.

        The write takes effect when ``(value, self.replica_id)`` is
        strictly greater, under the natural lexicographic order, than
        the currently stored ``(value_, writer)``. Otherwise it is a
        no-op, preserving monotonicity. Raises :class:`TypeError` if
        ``value`` cannot be compared with the currently stored value.
        """
        if value is None:
            raise TypeError(
                "MaxRegister.update value must not be None; "
                "None is reserved as the identity element"
            )
        if self.value_ is None:
            # First real write always lands.
            self.value_ = value
            self.ts = 0
            self.writer = self.replica_id
            return
        if _compare_strictly_greater(value, self.value_):
            self.value_ = value
            self.ts = (self.ts or 0) + 1
            self.writer = self.replica_id
            return
        if value == self.value_:
            # Tiebreak: prefer the lexicographically larger replica id.
            if self.replica_id > (self.writer or ""):
                self.writer = self.replica_id
                self.ts = (self.ts or 0) + 1

    # ------------------------------------------------------------------ #
    # Observation
    # ------------------------------------------------------------------ #
    def value(self) -> Any:
        """Return the current observed value (``None`` if uninitialised)."""
        return self.value_

    # ------------------------------------------------------------------ #
    # Merge
    # ------------------------------------------------------------------ #
    def merge(self, other: MaxRegister) -> None:
        """Elementwise-max merge with replica-id tiebreak.

        The join uses ``(value_, writer)`` as the partial order,
        mirroring :meth:`update`. Because the join is a set-theoretic
        max on a totally ordered domain, merge is idempotent,
        commutative and associative.
        """
        if not isinstance(other, MaxRegister):
            raise TypeError(
                f"cannot merge MaxRegister with {type(other).__name__}"
            )
        if other.value_ is None:
            return
        if self.value_ is None:
            self.value_ = other.value_
            self.writer = other.writer
            self.ts = other.ts
            return
        if _compare_strictly_greater(other.value_, self.value_):
            self.value_ = other.value_
            self.writer = other.writer
            self.ts = other.ts
            return
        if other.value_ == self.value_:
            # Tiebreak on writer: the larger replica id wins.
            if (other.writer or "") > (self.writer or ""):
                self.writer = other.writer
                if other.ts is not None:
                    self.ts = max(self.ts or 0, other.ts)

    # ------------------------------------------------------------------ #
    # Serialization
    # ------------------------------------------------------------------ #
    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-safe dict representation."""
        return {
            "type": "MaxRegister",
            "replica_id": self.replica_id,
            "value": self.value_,
            "ts": self.ts,
            "writer": self.writer,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> MaxRegister:
        """Rebuild a :class:`MaxRegister` from the output of :meth:`to_dict`."""
        if not isinstance(d, dict):
            raise TypeError("from_dict expects a dict")
        if d.get("type") not in (None, "MaxRegister"):
            raise ConvergeError(
                f"from_dict: expected type 'MaxRegister', got {d.get('type')!r}"
            )
        replica_id = d.get("replica_id")
        inst = cls(replica_id)  # type: ignore[arg-type]
        inst.value_ = d.get("value")
        inst.ts = d.get("ts")
        writer = d.get("writer")
        if writer is not None and (not isinstance(writer, str) or writer == ""):
            raise ReplicaError("writer must be a non-empty string or None")
        inst.writer = writer
        return inst

    # ------------------------------------------------------------------ #
    # Dunder
    # ------------------------------------------------------------------ #
    def __eq__(self, other: object) -> bool:
        if not isinstance(other, MaxRegister):
            return NotImplemented
        # Value-equality ignores ``replica_id`` (implementation detail)
        # but keeps ``writer`` since tiebreak history is observable.
        return (
            self.value_ == other.value_
            and self.writer == other.writer
        )

    def __repr__(self) -> str:
        return (
            f"MaxRegister(replica_id={self.replica_id!r}, "
            f"value={self.value_!r}, ts={self.ts}, writer={self.writer!r})"
        )
