"""Last-Writer-Wins register (LWW-Register).

An :class:`LWWRegister` holds a single value annotated with a logical
timestamp and the writer's replica id. Writes compare
``(timestamp, replica_id)`` lexicographically and the greater tuple
wins, giving a total order over concurrent writes. Merge is therefore
simply "pick the side whose tuple is larger"; this makes merge
idempotent, commutative and associative by construction.
"""

from __future__ import annotations

from typing import Any

from ..errors import ReplicaError


def _validate_replica_id(replica_id: Any) -> None:
    """Raise :class:`ReplicaError` if ``replica_id`` is not a non-empty string."""
    if not isinstance(replica_id, str) or replica_id == "":
        raise ReplicaError("replica_id must be a non-empty string")


def _validate_ts(ts: Any) -> None:
    """Raise ``TypeError``/``ValueError`` unless ``ts`` is a non-negative int."""
    if not isinstance(ts, int) or isinstance(ts, bool):
        raise TypeError("ts must be int")
    if ts < 0:
        raise ValueError("ts must be non-negative")


class LWWRegister:
    """Last-Writer-Wins register parameterised by ``(ts, replica_id)``.

    The "value" of the register is whatever was written by the largest
    ``(ts, writer)`` tuple observed so far. ``writer`` is the replica id
    of whichever replica produced that write, not necessarily this
    replica.
    """

    __slots__ = ("_replica_id", "_value", "_ts", "_writer", "_clock")

    def __init__(
        self,
        replica_id: str,
        initial: Any = None,
        ts: int = 0,
    ) -> None:
        """Initialise the register with ``initial`` stamped at ``ts``.

        The initial write is attributed to this replica so that merges
        between fresh registers with different initial values resolve
        deterministically via the ``(ts, writer)`` tiebreak.
        """
        _validate_replica_id(replica_id)
        _validate_ts(ts)
        self._replica_id: str = replica_id
        self._value: Any = initial
        self._ts: int = ts
        self._writer: str = replica_id
        # Monotonic counter used when ``set`` is called without an explicit ts.
        self._clock: int = ts

    # ------------------------------------------------------------------
    # Mutation
    # ------------------------------------------------------------------
    def set(self, value: Any, ts: int | None = None) -> None:
        """Write ``value`` at ``ts`` (auto-allocated if ``None``).

        The write takes effect only when ``(ts, self.replica_id)`` is
        strictly greater, lexicographically, than the currently stored
        ``(ts, writer)``. Otherwise it is ignored so that stale writes
        never clobber fresher ones.
        """
        if ts is None:
            # Always move strictly forward, even across stale explicit ts values.
            self._clock = max(self._clock, self._ts) + 1
            new_ts = self._clock
        else:
            _validate_ts(ts)
            new_ts = ts
            if new_ts > self._clock:
                self._clock = new_ts

        if (new_ts, self._replica_id) > (self._ts, self._writer):
            self._value = value
            self._ts = new_ts
            self._writer = self._replica_id

    # ------------------------------------------------------------------
    # Observation
    # ------------------------------------------------------------------
    def value(self) -> Any:
        """Return the value of the register as last written."""
        return self._value

    @property
    def replica_id(self) -> str:
        """Identifier of the replica that owns this register instance."""
        return self._replica_id

    @property
    def ts(self) -> int:
        """Timestamp of the currently winning write."""
        return self._ts

    @property
    def writer(self) -> str:
        """Replica id of the writer of the currently winning write."""
        return self._writer

    # ------------------------------------------------------------------
    # Merge
    # ------------------------------------------------------------------
    def merge(self, other: LWWRegister) -> None:
        """Merge ``other`` into ``self`` by picking the larger ``(ts, writer)``."""
        if not isinstance(other, LWWRegister):
            raise TypeError("can only merge LWWRegister with LWWRegister")
        # Keep the local monotonic counter ahead of both observed timestamps
        # so that future unsolicited writes strictly supersede everything seen.
        self._clock = max(self._clock, other._clock, other._ts)
        if (other._ts, other._writer) > (self._ts, self._writer):
            self._value = other._value
            self._ts = other._ts
            self._writer = other._writer

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------
    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-safe dict representation."""
        return {
            "value": self._value,
            "ts": self._ts,
            "writer": self._writer,
            "replica_id": self._replica_id,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> LWWRegister:
        """Rebuild an :class:`LWWRegister` from the output of :meth:`to_dict`."""
        if not isinstance(d, dict):
            raise TypeError("from_dict expects a dict")
        required = ("value", "ts", "writer", "replica_id")
        for key in required:
            if key not in d:
                raise ValueError(f"missing key {key!r} in LWWRegister dict")
        replica_id = d["replica_id"]
        writer = d["writer"]
        ts = d["ts"]
        _validate_replica_id(replica_id)
        if not isinstance(writer, str) or writer == "":
            raise ReplicaError("writer must be a non-empty string")
        _validate_ts(ts)
        reg = cls(replica_id, initial=None, ts=0)
        reg._value = d["value"]
        reg._ts = ts
        reg._writer = writer
        reg._clock = ts
        return reg

    # ------------------------------------------------------------------
    # Dunder methods
    # ------------------------------------------------------------------
    def __eq__(self, other: object) -> bool:
        if not isinstance(other, LWWRegister):
            return NotImplemented
        return (
            self._value == other._value
            and self._ts == other._ts
            and self._writer == other._writer
            and self._replica_id == other._replica_id
        )

    def __repr__(self) -> str:
        return (
            f"LWWRegister(replica_id={self._replica_id!r}, "
            f"value={self._value!r}, ts={self._ts}, writer={self._writer!r})"
        )

    __hash__ = None  # type: ignore[assignment]
