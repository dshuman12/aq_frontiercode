"""Register CRDTs exposed by converge.

This subpackage re-exports :class:`LWWRegister` (last-writer-wins),
:class:`MVRegister` (multi-value), :class:`MaxRegister` (monotonic
max) and :class:`MinRegister` (monotonic min) -- the register
flavours supported by converge.
"""

from __future__ import annotations

from .lwwregister import LWWRegister
from .maxregister import MaxRegister
from .minregister import MinRegister
from .mvregister import MVRegister

__all__ = ["LWWRegister", "MVRegister", "MaxRegister", "MinRegister"]
