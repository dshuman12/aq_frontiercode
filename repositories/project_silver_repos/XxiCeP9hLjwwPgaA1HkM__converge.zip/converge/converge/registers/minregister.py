"""Monotonic-minimum register (Min-Register).

A :class:`MinRegister` is the order-dual of
:class:`converge.registers.maxregister.MaxRegister`: it stores a
single comparable value and only ever moves downwards under the
natural ordering of its element type. Writes that do not strictly
decrease the value are discarded; ties on equal values break toward
the *lower* replica id, which is the opposite of the max register
convention but equally deterministic.

Like the max register, ``None`` is used as the identity element: it
represents "no real value yet" and therefore loses every comparison
with a real value, so the first real write always lands.
"""

from __future__ import annotations

from typing import Any

from converge.errors import ConvergeError, ReplicaError


def _validate_replica_id(replica_id: Any) -> str:
    """Validate that ``replica_id`` is a non-empty string.

    See :mod:`converge.registers.maxregister` for the rationale behind
    duplicating this helper in each module -- it keeps each CRDT file
    self-contained and avoids a shared-helper import web.
    """
    if not isinstance(replica_id, str):
        raise ReplicaError(
            f"replica_id must be a str, got {type(replica_id).__name__}"
        )
    if replica_id == "":
        raise ReplicaError("replica_id must be a non-empty string")
    return replica_id


def _compare_strictly_less(candidate: Any, current: Any) -> bool:
    """Return ``True`` iff ``candidate`` is strictly less than ``current``.

    ``None`` is the identity element for the min register; it is
    considered greater than every real value. Any :class:`TypeError`
    raised by ``<`` on mutually-incompatible types is propagated so
    users see the real comparability problem, not a silent skip.
    """
    if current is None and candidate is None:
        return False
    if current is None:
        return True  # Any real value is "less" than the identity.
    if candidate is None:
        return False
    return candidate < current


class MinRegister:
    """Register that monotonically advances to the minimum observed value.

    The register records the smallest ``(value, writer)`` pair it has
    ever seen, with ``writer`` used only to break ties on equal
    values. On ties we intentionally prefer the *lower* replica id so
    the register's resolution is the order-dual of the max register
    and joins remain associative and commutative.
    """

    __hash__ = None  # type: ignore[assignment]

    def __init__(self, replica_id: str, initial: Any = None) -> None:
        """Create a min register owned by ``replica_id``.

        ``initial`` follows the same rules as the max register: it may
        be ``None`` (identity) or a value comparable to itself. When a
        real initial value is supplied it is stamped as if this
        replica had just written it.
        """
        self.replica_id = _validate_replica_id(replica_id)
        self.value_: Any = None
        self.ts: int | None = None
        self.writer: str | None = None
        if initial is not None:
            self.update(initial)

    # ------------------------------------------------------------------ #
    # Mutation
    # ------------------------------------------------------------------ #
    def update(self, value: Any) -> None:
        """Advance the register to ``min(current, value)``.

        Writes only take effect when strictly smaller than the
        currently stored value, so duplicate writes are idempotent.
        Raises :class:`TypeError` if ``value`` is not comparable with
        the current state or is ``None``.
        """
        if value is None:
            raise TypeError(
                "MinRegister.update value must not be None; "
                "None is reserved as the identity element"
            )
        if self.value_ is None:
            self.value_ = value
            self.ts = 0
            self.writer = self.replica_id
            return
        if _compare_strictly_less(value, self.value_):
            self.value_ = value
            self.ts = (self.ts or 0) + 1
            self.writer = self.replica_id
            return
        if value == self.value_:
            # Tiebreak: prefer the lexicographically smaller replica id.
            if self.writer is None or self.replica_id < self.writer:
                self.writer = self.replica_id
                self.ts = (self.ts or 0) + 1

    # ------------------------------------------------------------------ #
    # Observation
    # ------------------------------------------------------------------ #
    def value(self) -> Any:
        """Return the current observed value (``None`` if uninitialised)."""
        return self.value_

    # ------------------------------------------------------------------ #
    # Merge
    # ------------------------------------------------------------------ #
    def merge(self, other: MinRegister) -> None:
        """Elementwise-min merge with replica-id tiebreak.

        The join takes the smaller of the two ``value_`` fields and
        uses the smaller ``writer`` to resolve ties on equal values.
        This is the order-dual of the max register's merge and shares
        all of its CRDT properties.
        """
        if not isinstance(other, MinRegister):
            raise TypeError(
                f"cannot merge MinRegister with {type(other).__name__}"
            )
        if other.value_ is None:
            return
        if self.value_ is None:
            self.value_ = other.value_
            self.writer = other.writer
            self.ts = other.ts
            return
        if _compare_strictly_less(other.value_, self.value_):
            self.value_ = other.value_
            self.writer = other.writer
            self.ts = other.ts
            return
        if other.value_ == self.value_:
            # Tiebreak: smaller writer wins.
            if other.writer is not None and (
                self.writer is None or other.writer < self.writer
            ):
                self.writer = other.writer
                if other.ts is not None:
                    self.ts = max(self.ts or 0, other.ts)

    # ------------------------------------------------------------------ #
    # Serialization
    # ------------------------------------------------------------------ #
    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-safe dict representation."""
        return {
            "type": "MinRegister",
            "replica_id": self.replica_id,
            "value": self.value_,
            "ts": self.ts,
            "writer": self.writer,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> MinRegister:
        """Rebuild a :class:`MinRegister` from the output of :meth:`to_dict`."""
        if not isinstance(d, dict):
            raise TypeError("from_dict expects a dict")
        if d.get("type") not in (None, "MinRegister"):
            raise ConvergeError(
                f"from_dict: expected type 'MinRegister', got {d.get('type')!r}"
            )
        replica_id = d.get("replica_id")
        inst = cls(replica_id)  # type: ignore[arg-type]
        inst.value_ = d.get("value")
        inst.ts = d.get("ts")
        writer = d.get("writer")
        if writer is not None and (not isinstance(writer, str) or writer == ""):
            raise ReplicaError("writer must be a non-empty string or None")
        inst.writer = writer
        return inst

    # ------------------------------------------------------------------ #
    # Dunder
    # ------------------------------------------------------------------ #
    def __eq__(self, other: object) -> bool:
        if not isinstance(other, MinRegister):
            return NotImplemented
        # Value-equality ignores ``replica_id`` but retains ``writer``
        # because it reflects the tiebreak result, which is observable.
        return (
            self.value_ == other.value_
            and self.writer == other.writer
        )

    def __repr__(self) -> str:
        return (
            f"MinRegister(replica_id={self.replica_id!r}, "
            f"value={self.value_!r}, ts={self.ts}, writer={self.writer!r})"
        )
