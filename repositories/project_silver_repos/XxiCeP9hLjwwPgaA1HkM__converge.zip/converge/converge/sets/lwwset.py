"""Last-Writer-Wins Set (LWW-Set) CRDT.

Every element carries at most one add-timestamp and at most one
remove-timestamp, each tagged with the ``replica_id`` that wrote it.
Membership is decided by comparing those timestamps lexicographically as
``(ts, replica_id)``: the element is present iff the add-stamp is
strictly greater than the remove-stamp. On ties (same ``ts``), the
``replica_id`` string comparison breaks the tie — a deterministic rule
that keeps merges commutative.

Timestamps are logical integers produced by a caller-supplied ``clock``
callable, or — by default — a monotonic per-instance counter. No wall
clock is ever read, which keeps the CRDT deterministic under replay.
Elements must be hashable.
"""

from __future__ import annotations

from typing import Any, Callable, Hashable, Optional

from converge.errors import ConvergeError, ReplicaError


Stamp = tuple[int, str]


def _validate_replica_id(replica_id: Any) -> str:
    """Validate that ``replica_id`` is a non-empty string."""
    if not isinstance(replica_id, str):
        raise ReplicaError(
            f"replica_id must be a str, got {type(replica_id).__name__}"
        )
    if replica_id == "":
        raise ReplicaError("replica_id must be a non-empty string")
    return replica_id


class _MonotonicCounter:
    """Default logical clock: a monotonic per-instance integer counter.

    We use a small callable class rather than a closure so that ``repr``
    and debugger introspection show something meaningful, and so we can
    serialize the current counter value via :meth:`LWWSet.to_dict`.
    """

    def __init__(self, start: int = 0) -> None:
        self.value = int(start)

    def __call__(self) -> int:
        self.value += 1
        return self.value


class LWWSet:
    """Last-Writer-Wins Set with ``(ts, replica_id)`` tiebreak.

    Internally we keep two dicts, ``adds`` and ``removes``, each mapping
    an element to the best ``(ts, replica_id)`` stamp seen so far. This
    representation is equivalent to the "one stamp with an add/remove
    flag" layout but makes the merge rule trivially symmetrical: keep
    the lexicographically-greater stamp on each side.
    """

    __hash__ = None  # mutable; opt out of default hashing

    def __init__(
        self,
        replica_id: str,
        clock: Optional[Callable[[], int]] = None,
    ) -> None:
        """Create an empty LWW-Set owned by ``replica_id``.

        If ``clock`` is ``None`` a default monotonic counter per
        instance is installed. The caller may supply any zero-argument
        callable that returns an ``int``; this is the hook used by the
        test harness to inject deterministic timestamps.
        """
        self.replica_id = _validate_replica_id(replica_id)
        if clock is None:
            clock = _MonotonicCounter()
        if not callable(clock):
            raise TypeError(
                f"clock must be callable, got {type(clock).__name__}"
            )
        self._clock: Callable[[], int] = clock
        self.adds: dict[Hashable, Stamp] = {}
        self.removes: dict[Hashable, Stamp] = {}

    # ------------------------------------------------------------------ #
    # Mutations
    # ------------------------------------------------------------------ #
    def add(self, element: Hashable, ts: Optional[int] = None) -> None:
        """Record an add of ``element`` at timestamp ``ts``.

        If ``ts`` is ``None`` the instance clock is consulted. The stamp
        written is ``(ts, self.replica_id)``; it replaces the existing
        add stamp only if it is strictly greater in lex order. Passing
        an older ``ts`` than the current add stamp is therefore a no-op,
        which is what keeps merges idempotent.
        """
        self._check_hashable(element)
        stamp = self._make_stamp(ts)
        self._upsert(self.adds, element, stamp)

    def remove(self, element: Hashable, ts: Optional[int] = None) -> None:
        """Record a remove of ``element`` at timestamp ``ts``.

        Unlike 2P-Set / OR-Set, an LWW-Set accepts a ``remove`` for an
        element that has never been seen locally — the remove stamp just
        sits in ``removes`` and wins if no future add out-stamps it.
        This is the standard LWW-Set semantic; merges must not diverge
        based on local observation history.
        """
        self._check_hashable(element)
        stamp = self._make_stamp(ts)
        self._upsert(self.removes, element, stamp)

    # ------------------------------------------------------------------ #
    # Observations
    # ------------------------------------------------------------------ #
    def contains(self, element: Hashable) -> bool:
        """Return ``True`` iff the add stamp beats the remove stamp.

        Ties on the integer ``ts`` are resolved by comparing
        ``replica_id`` lexicographically; ties on the full stamp (same
        ``ts`` and same ``replica_id``) resolve in favor of *remove*,
        because membership requires ``adds[e] > removes[e]`` strictly.
        """
        if element not in self.adds:
            return False
        if element not in self.removes:
            return True
        return self.adds[element] > self.removes[element]

    def value(self) -> frozenset:
        """Return the observed set as an immutable ``frozenset``."""
        return frozenset(e for e in self.adds if self.contains(e))

    # ------------------------------------------------------------------ #
    # Merge
    # ------------------------------------------------------------------ #
    def merge(self, other: LWWSet) -> None:
        """Merge ``other`` into ``self`` in place.

        For every element seen on either side we keep the lex-maximum
        add stamp and the lex-maximum remove stamp. Because "pick the
        larger stamp" is idempotent, commutative, and associative, so is
        this merge. The remote ``clock`` callable is never invoked —
        only its already-materialized stamps are consumed.
        """
        if not isinstance(other, LWWSet):
            raise TypeError(f"cannot merge LWWSet with {type(other).__name__}")
        for element, stamp in other.adds.items():
            self._upsert(self.adds, element, stamp)
        for element, stamp in other.removes.items():
            self._upsert(self.removes, element, stamp)

    # ------------------------------------------------------------------ #
    # Serialization
    # ------------------------------------------------------------------ #
    def to_dict(self) -> dict:
        """Return a JSON-safe dict representation of this LWW-Set.

        The default monotonic counter's current value is serialized so
        that a round-tripped instance keeps issuing increasing stamps;
        a caller-supplied clock is not serialized (the caller must
        re-install it on :meth:`from_dict`).
        """
        clock_value: Optional[int]
        if isinstance(self._clock, _MonotonicCounter):
            clock_value = self._clock.value
        else:
            clock_value = None

        return {
            "type": "LWWSet",
            "replica_id": self.replica_id,
            "clock_value": clock_value,
            "adds": [
                {"element": e, "ts": ts, "writer": w}
                for e, (ts, w) in self.adds.items()
            ],
            "removes": [
                {"element": e, "ts": ts, "writer": w}
                for e, (ts, w) in self.removes.items()
            ],
        }

    @classmethod
    def from_dict(
        cls,
        data: dict,
        clock: Optional[Callable[[], int]] = None,
    ) -> LWWSet:
        """Rehydrate an :class:`LWWSet` previously produced by ``to_dict``.

        If ``clock`` is not supplied and the serialized state was using
        the default monotonic counter, we rebuild a fresh counter seeded
        with the persisted value so that subsequent adds/removes keep
        producing strictly increasing stamps.
        """
        if not isinstance(data, dict):
            raise TypeError(f"from_dict expects dict, got {type(data).__name__}")
        if data.get("type") != "LWWSet":
            raise ConvergeError(
                f"from_dict: expected type 'LWWSet', got {data.get('type')!r}"
            )

        if clock is None:
            clock = _MonotonicCounter(start=int(data.get("clock_value") or 0))

        instance = cls(data["replica_id"], clock=clock)
        instance.adds = {
            entry["element"]: (int(entry["ts"]), str(entry["writer"]))
            for entry in data.get("adds", [])
        }
        instance.removes = {
            entry["element"]: (int(entry["ts"]), str(entry["writer"]))
            for entry in data.get("removes", [])
        }
        return instance

    # ------------------------------------------------------------------ #
    # Dunder
    # ------------------------------------------------------------------ #
    def __eq__(self, other: object) -> bool:
        if not isinstance(other, LWWSet):
            return NotImplemented
        # Equality is on add/remove stamp state; replica_id and the live
        # clock callable are instance-local identity, not CRDT state.
        return self.adds == other.adds and self.removes == other.removes

    def __repr__(self) -> str:
        return (
            f"LWWSet(replica_id={self.replica_id!r}, "
            f"value={sorted(self.value(), key=repr)!r})"
        )

    # ------------------------------------------------------------------ #
    # Internal helpers
    # ------------------------------------------------------------------ #
    def _make_stamp(self, ts: Optional[int]) -> Stamp:
        """Build a ``(ts, replica_id)`` stamp, pulling from the clock if needed."""
        if ts is None:
            ts = self._clock()
        if not isinstance(ts, int) or isinstance(ts, bool):
            raise TypeError(f"ts must be int, got {type(ts).__name__}")
        return (ts, self.replica_id)

    @staticmethod
    def _upsert(
        table: dict[Hashable, Stamp],
        element: Hashable,
        stamp: Stamp,
    ) -> None:
        """Keep the lex-greater of the existing and the new stamp for ``element``."""
        current = table.get(element)
        if current is None or stamp > current:
            table[element] = stamp

    @staticmethod
    def _check_hashable(element: Any) -> None:
        """Ensure ``element`` is hashable; raise ``TypeError`` otherwise."""
        try:
            hash(element)
        except TypeError as exc:
            raise TypeError(
                f"LWWSet elements must be hashable: {element!r}"
            ) from exc
