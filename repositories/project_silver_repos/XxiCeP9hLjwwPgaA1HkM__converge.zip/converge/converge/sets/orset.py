"""Observed-Remove Set (OR-Set) CRDT.

The OR-Set solves the fundamental 2P-Set limitation — "once removed,
forever gone" — by tagging every ``add`` with a fresh unique *dot*
``(replica_id, counter)``. ``remove`` only kills the dots that this
replica has already observed, which means an ``add`` made concurrently on
another replica survives the merge ("add wins" on concurrent add/remove).

Internal state: ``elements`` maps each element to its set of live dots,
``tombstones`` collects all dots that have been observed and then removed,
and ``_counter`` is the local monotonic counter that feeds ``next_dot``.
Elements must be hashable.
"""

from __future__ import annotations

from typing import Any, Hashable

from converge.errors import ConvergeError, ReplicaError


Dot = tuple[str, int]


def _validate_replica_id(replica_id: Any) -> str:
    """Validate that ``replica_id`` is a non-empty string."""
    if not isinstance(replica_id, str):
        raise ReplicaError(
            f"replica_id must be a str, got {type(replica_id).__name__}"
        )
    if replica_id == "":
        raise ReplicaError("replica_id must be a non-empty string")
    return replica_id


class ORSet:
    """Observed-Remove Set keyed by per-replica dots.

    The invariant that makes OR-Set converge is: a ``remove`` can only
    tombstone the dots that are locally visible at the moment of removal.
    Any dot that was produced concurrently on another replica — and so
    was not yet observed here — is not tombstoned, and will therefore
    keep its element alive after the eventual merge.
    """

    __hash__ = None  # mutable; opt out of default hashing

    def __init__(self, replica_id: str) -> None:
        """Create an empty OR-Set owned by ``replica_id``."""
        self.replica_id = _validate_replica_id(replica_id)
        self.elements: dict[Hashable, set[Dot]] = {}
        self.tombstones: set[Dot] = set()
        self._counter: int = 0

    # ------------------------------------------------------------------ #
    # Mutations
    # ------------------------------------------------------------------ #
    def add(self, element: Hashable) -> None:
        """Add ``element`` with a fresh unique dot for this replica.

        The new dot ``(self.replica_id, next_counter)`` is unique across
        all replicas because counters are per-replica and monotonically
        increasing; this uniqueness is what allows a remote ``remove`` to
        leave our add alone if it happened concurrently.
        """
        self._check_hashable(element)
        self._counter += 1
        new_dot: Dot = (self.replica_id, self._counter)
        self.elements.setdefault(element, set()).add(new_dot)

    def remove(self, element: Hashable) -> None:
        """Remove ``element`` by tombstoning every currently live dot.

        Raises :class:`ConvergeError` if ``element`` has no live dots on
        this replica. This matches the "observed-remove" contract: you
        can only remove what you have already observed.
        """
        self._check_hashable(element)
        live_dots = self.elements.get(element)
        if not live_dots:
            raise ConvergeError(f"cannot remove unknown element: {element!r}")
        self.tombstones.update(live_dots)
        self.elements[element] = set()

    # ------------------------------------------------------------------ #
    # Observations
    # ------------------------------------------------------------------ #
    def contains(self, element: Hashable) -> bool:
        """Return ``True`` iff ``element`` has at least one live dot."""
        dots = self.elements.get(element)
        return bool(dots)

    def value(self) -> frozenset:
        """Return the observed set as an immutable ``frozenset``."""
        return frozenset(e for e, dots in self.elements.items() if dots)

    # ------------------------------------------------------------------ #
    # Merge
    # ------------------------------------------------------------------ #
    def merge(self, other: ORSet) -> None:
        """Merge ``other`` into ``self`` in place.

        The rule is: alive dots of an element = (union of dots from both
        sides) minus (union of tombstones from both sides). This keeps
        any add whose dot has not been tombstoned on either replica,
        which is exactly the add-wins semantic described above.
        """
        if not isinstance(other, ORSet):
            raise TypeError(f"cannot merge ORSet with {type(other).__name__}")

        all_tombstones: set[Dot] = self.tombstones | other.tombstones

        all_keys = set(self.elements.keys()) | set(other.elements.keys())
        merged_elements: dict[Hashable, set[Dot]] = {}
        for element in all_keys:
            union_dots = self.elements.get(element, set()) | other.elements.get(
                element, set()
            )
            alive = union_dots - all_tombstones
            merged_elements[element] = alive

        self.elements = merged_elements
        self.tombstones = all_tombstones
        self._counter = self._recompute_local_counter()

    # ------------------------------------------------------------------ #
    # Serialization
    # ------------------------------------------------------------------ #
    def to_dict(self) -> dict:
        """Return a JSON-safe dict representation of this OR-Set.

        Dots become two-element lists because JSON has no tuple type; the
        inverse conversion is handled in :meth:`from_dict`.
        """
        return {
            "type": "ORSet",
            "replica_id": self.replica_id,
            "counter": self._counter,
            "elements": [
                {"element": element, "dots": [list(d) for d in sorted(dots)]}
                for element, dots in self.elements.items()
            ],
            "tombstones": [list(d) for d in sorted(self.tombstones)],
        }

    @classmethod
    def from_dict(cls, data: dict) -> ORSet:
        """Rehydrate an :class:`ORSet` previously produced by ``to_dict``."""
        if not isinstance(data, dict):
            raise TypeError(f"from_dict expects dict, got {type(data).__name__}")
        if data.get("type") != "ORSet":
            raise ConvergeError(
                f"from_dict: expected type 'ORSet', got {data.get('type')!r}"
            )
        instance = cls(data["replica_id"])
        instance._counter = int(data.get("counter", 0))

        elements: dict[Hashable, set[Dot]] = {}
        for entry in data.get("elements", []):
            element = entry["element"]
            dots = {_dot_from_list(d) for d in entry.get("dots", [])}
            elements[element] = dots
        instance.elements = elements
        instance.tombstones = {
            _dot_from_list(d) for d in data.get("tombstones", [])
        }
        return instance

    # ------------------------------------------------------------------ #
    # Dunder
    # ------------------------------------------------------------------ #
    def __eq__(self, other: object) -> bool:
        if not isinstance(other, ORSet):
            return NotImplemented
        # Equality compares *state* (dot assignments and tombstones), not
        # replica identity or local counter. Two replicas that have merged
        # the same history should be equal even if they have different
        # replica_ids.
        if self.tombstones != other.tombstones:
            return False
        keys_a = {k for k, v in self.elements.items() if v}
        keys_b = {k for k, v in other.elements.items() if v}
        if keys_a != keys_b:
            return False
        for key in keys_a:
            if self.elements[key] != other.elements[key]:
                return False
        return True

    def __repr__(self) -> str:
        return (
            f"ORSet(replica_id={self.replica_id!r}, "
            f"value={sorted(self.value(), key=repr)!r}, "
            f"tombstones={len(self.tombstones)})"
        )

    # ------------------------------------------------------------------ #
    # Internal helpers
    # ------------------------------------------------------------------ #
    def _recompute_local_counter(self) -> int:
        """Recompute ``_counter`` post-merge.

        After a merge we must make sure our next dot does not collide
        with any dot we have ever observed for our own ``replica_id``.
        We therefore take the maximum counter seen in either live dots
        or tombstones whose replica matches ours, and use that as the
        floor for the next allocation.
        """
        best = self._counter
        for dots in self.elements.values():
            for replica, counter in dots:
                if replica == self.replica_id and counter > best:
                    best = counter
        for replica, counter in self.tombstones:
            if replica == self.replica_id and counter > best:
                best = counter
        return best

    @staticmethod
    def _check_hashable(element: Any) -> None:
        """Ensure ``element`` is hashable; raise ``TypeError`` otherwise."""
        try:
            hash(element)
        except TypeError as exc:
            raise TypeError(
                f"ORSet elements must be hashable: {element!r}"
            ) from exc


def _dot_from_list(obj: Any) -> Dot:
    """Convert a 2-element list ``[replica, counter]`` into a tuple dot."""
    if not isinstance(obj, (list, tuple)) or len(obj) != 2:
        raise TypeError(f"expected 2-element list for a dot, got {obj!r}")
    replica, counter = obj
    if not isinstance(replica, str):
        raise TypeError(f"dot replica must be str, got {type(replica).__name__}")
    if not isinstance(counter, int) or isinstance(counter, bool):
        raise TypeError(
            f"dot counter must be int, got {type(counter).__name__}"
        )
    return (replica, counter)
