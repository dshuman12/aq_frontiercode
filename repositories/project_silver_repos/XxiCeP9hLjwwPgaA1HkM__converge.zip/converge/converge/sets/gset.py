"""Grow-only set (G-Set) CRDT.

A :class:`GSet` stores a monotonically growing collection of hashable
elements. Only ``add`` is supported -- there is deliberately no remove
-- which makes the merge operation the ordinary set union and therefore
trivially idempotent, commutative and associative.

This is the simplest convergent CRDT and is frequently used as a
building block for more interesting structures (the add-set half of a
2P-Set, the sequence-of-unique-ids behind an OR-Set, etc.). Elements
must be hashable; otherwise they would not fit in an underlying
``set``.
"""

from __future__ import annotations

from typing import Any, Hashable, Iterable, Iterator

from converge.errors import ConvergeError, ReplicaError


def _validate_replica_id(replica_id: Any) -> str:
    """Validate that ``replica_id`` is a non-empty string.

    Returns ``replica_id`` unchanged on success; raises
    :class:`ReplicaError` with a descriptive message otherwise. The
    function exists so that every CRDT in this package validates its
    replica id in exactly the same way.
    """
    if not isinstance(replica_id, str):
        raise ReplicaError(
            f"replica_id must be a str, got {type(replica_id).__name__}"
        )
    if replica_id == "":
        raise ReplicaError("replica_id must be a non-empty string")
    return replica_id


def _check_hashable(element: Any) -> None:
    """Ensure ``element`` is hashable; raise ``TypeError`` otherwise.

    G-Set elements must be hashable because the underlying container is
    a :class:`set`. We attempt ``hash`` eagerly so that unhashable
    inputs fail fast at ``add`` time instead of surfacing mysterious
    errors later during merge or serialization.
    """
    try:
        hash(element)
    except TypeError as exc:
        raise TypeError(
            f"GSet elements must be hashable: {element!r}"
        ) from exc


class GSet:
    """Grow-only set of hashable elements.

    The CRDT invariant is simple: once an element has been observed it
    is observed forever. ``value`` returns a :class:`frozenset` so
    callers cannot mutate the observed state by accident. The set is
    intentionally unordered; for an ordered variant see the sequence
    CRDTs in :mod:`converge.sequence`.
    """

    __hash__ = None  # mutable; opt out of default hashing

    def __init__(self, replica_id: str) -> None:
        """Create an empty G-Set owned by ``replica_id``.

        ``replica_id`` is stored on the instance so this object can be
        distinguished from peers during debugging and so that future
        extensions (for example a dotted variant) can attribute local
        operations to it. Validation mirrors every other CRDT in the
        package.
        """
        self.replica_id = _validate_replica_id(replica_id)
        self.elements: set[Hashable] = set()

    # ------------------------------------------------------------------ #
    # Mutations
    # ------------------------------------------------------------------ #
    def add(self, element: Hashable) -> None:
        """Add ``element`` to the set.

        Because the G-Set is grow-only this operation is idempotent:
        adding an already-present element is a no-op that is still
        safe to apply on every replica. ``element`` must be hashable.
        """
        _check_hashable(element)
        self.elements.add(element)

    # ------------------------------------------------------------------ #
    # Observations
    # ------------------------------------------------------------------ #
    def contains(self, element: Hashable) -> bool:
        """Return ``True`` iff ``element`` has been added on any replica."""
        return element in self.elements

    def value(self) -> frozenset:
        """Return the observed set as an immutable :class:`frozenset`.

        The frozenset is a fresh copy; callers may keep it as long as
        they like without worrying that subsequent :meth:`add` calls
        will mutate the snapshot underneath them.
        """
        return frozenset(self.elements)

    # ------------------------------------------------------------------ #
    # Merge
    # ------------------------------------------------------------------ #
    def merge(self, other: GSet) -> None:
        """Merge ``other`` into ``self`` in place.

        The merge is the set union of the two element collections.
        Union is idempotent, commutative and associative, so the
        merged state depends only on the combined set of elements --
        not on the order in which merges were applied.
        """
        if not isinstance(other, GSet):
            raise TypeError(
                f"cannot merge GSet with {type(other).__name__}"
            )
        self.elements |= other.elements

    # ------------------------------------------------------------------ #
    # Serialization
    # ------------------------------------------------------------------ #
    def to_dict(self) -> dict:
        """Return a JSON-safe dict representation of this G-Set.

        Element order inside the emitted list is sorted by ``repr`` so
        that identical sets serialize to identical JSON regardless of
        the underlying ``set`` iteration order. This keeps snapshots
        byte-comparable across replicas.
        """
        try:
            ordered = sorted(self.elements, key=lambda e: (type(e).__name__, repr(e)))
        except TypeError:
            ordered = list(self.elements)
        return {
            "type": "GSet",
            "replica_id": self.replica_id,
            "elements": ordered,
        }

    @classmethod
    def from_dict(cls, data: dict) -> GSet:
        """Rehydrate a :class:`GSet` previously produced by :meth:`to_dict`."""
        if not isinstance(data, dict):
            raise TypeError(
                f"from_dict expects dict, got {type(data).__name__}"
            )
        if data.get("type") != "GSet":
            raise ConvergeError(
                f"from_dict: expected type 'GSet', got {data.get('type')!r}"
            )
        replica_id = data.get("replica_id")
        elements = data.get("elements", [])
        if not isinstance(elements, list):
            raise TypeError("from_dict expects 'elements' to be a list")
        instance = cls(replica_id)  # type: ignore[arg-type]
        for element in elements:
            _check_hashable(element)
            instance.elements.add(element)
        return instance

    # ------------------------------------------------------------------ #
    # Convenience dunder methods
    # ------------------------------------------------------------------ #
    def __iter__(self) -> Iterator[Hashable]:
        """Iterate over the observed elements (order unspecified)."""
        return iter(self.elements)

    def __len__(self) -> int:
        """Return the cardinality of the observed set."""
        return len(self.elements)

    def __contains__(self, element: object) -> bool:
        """Return ``element in self``; equivalent to :meth:`contains`."""
        return element in self.elements

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, GSet):
            return NotImplemented
        # Equality is value-based: we ignore ``replica_id`` because two
        # replicas with identical observed elements represent the same
        # abstract set even if they were created by different nodes.
        return self.elements == other.elements

    def __repr__(self) -> str:
        try:
            shown = sorted(self.elements, key=lambda e: (type(e).__name__, repr(e)))
        except TypeError:
            shown = list(self.elements)
        return (
            f"GSet(replica_id={self.replica_id!r}, elements={shown!r})"
        )

    # ------------------------------------------------------------------ #
    # Extra helpers
    # ------------------------------------------------------------------ #
    def update(self, elements: Iterable[Hashable]) -> None:
        """Add every element from ``elements`` to the set.

        This is a thin wrapper around :meth:`add` that mirrors
        :meth:`set.update`. Each element is validated independently so
        that a single unhashable item aborts the entire batch before
        any partial state lands.
        """
        collected: list[Hashable] = []
        for element in elements:
            _check_hashable(element)
            collected.append(element)
        for element in collected:
            self.elements.add(element)

    def is_subset(self, other: GSet) -> bool:
        """Return ``True`` iff every element in ``self`` is also in ``other``.

        Useful when writing invariants about monotonic progress: the
        pre-merge state must always be a subset of the post-merge
        state for a grow-only CRDT.
        """
        if not isinstance(other, GSet):
            raise TypeError(
                f"cannot compare GSet with {type(other).__name__}"
            )
        return self.elements <= other.elements
