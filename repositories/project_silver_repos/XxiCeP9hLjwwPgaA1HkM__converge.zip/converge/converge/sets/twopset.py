"""Two-Phase Set (2P-Set) CRDT.

A 2P-Set tracks two monotonically growing collections: ``added`` and
``removed``. An element is considered a member iff it has been added and
has not yet been removed. Once an element is removed it can never be
re-added; that is the defining (and limiting) semantic of the 2P-Set.

Both underlying collections grow only by union on merge, which makes the
merge operation trivially idempotent, commutative, and associative.
Elements must be hashable.
"""

from __future__ import annotations

from typing import Any, Hashable, Iterable

from converge.errors import ConvergeError, ReplicaError


def _validate_replica_id(replica_id: Any) -> str:
    """Validate that ``replica_id`` is a non-empty string."""
    if not isinstance(replica_id, str):
        raise ReplicaError(
            f"replica_id must be a str, got {type(replica_id).__name__}"
        )
    if replica_id == "":
        raise ReplicaError("replica_id must be a non-empty string")
    return replica_id


class TwoPSet:
    """Two-Phase Set: monotone add/remove with permanent tombstones.

    Internally we store ``added`` and ``removed`` as ``dict[element, True]``
    rather than ``set[element]`` so that iteration order is deterministic
    (insertion order), which makes ``repr`` and ``to_dict`` reproducible.
    """

    __hash__ = None  # mutable; opt out of default hashing

    def __init__(self, replica_id: str) -> None:
        """Create an empty 2P-Set owned by ``replica_id``."""
        self.replica_id = _validate_replica_id(replica_id)
        self.added: dict[Hashable, bool] = {}
        self.removed: dict[Hashable, bool] = {}

    # ------------------------------------------------------------------ #
    # Mutations
    # ------------------------------------------------------------------ #
    def add(self, element: Hashable) -> None:
        """Record that ``element`` was added.

        If ``element`` has already been removed the set keeps the tombstone
        and ``contains`` continues to return ``False`` — once removed an
        element cannot come back, which is the 2P-Set invariant.
        """
        self._check_hashable(element)
        self.added[element] = True

    def remove(self, element: Hashable) -> None:
        """Record that ``element`` was removed.

        Raises :class:`ConvergeError` if ``element`` was never added on
        this replica. The 2P-Set requires observation before removal.
        """
        self._check_hashable(element)
        if element not in self.added:
            raise ConvergeError(f"cannot remove unknown element: {element!r}")
        self.removed[element] = True

    # ------------------------------------------------------------------ #
    # Observations
    # ------------------------------------------------------------------ #
    def contains(self, element: Hashable) -> bool:
        """Return ``True`` iff ``element`` is added and not yet removed."""
        return element in self.added and element not in self.removed

    def value(self) -> frozenset:
        """Return the observed set as an immutable ``frozenset``."""
        return frozenset(e for e in self.added if e not in self.removed)

    # ------------------------------------------------------------------ #
    # Merge
    # ------------------------------------------------------------------ #
    def merge(self, other: TwoPSet) -> None:
        """Merge ``other`` into ``self`` in place.

        The merge is the componentwise union of the two ``added`` sets and
        the two ``removed`` sets. Because union is idempotent, commutative
        and associative, so is this merge. ``other``'s ``replica_id`` is
        not copied; only its tombstones and added-records are absorbed.
        """
        if not isinstance(other, TwoPSet):
            raise TypeError(
                f"cannot merge TwoPSet with {type(other).__name__}"
            )
        for element in other.added:
            self.added.setdefault(element, True)
        for element in other.removed:
            self.removed.setdefault(element, True)

    # ------------------------------------------------------------------ #
    # Serialization
    # ------------------------------------------------------------------ #
    def to_dict(self) -> dict:
        """Return a JSON-safe dict representation of this 2P-Set."""
        return {
            "type": "TwoPSet",
            "replica_id": self.replica_id,
            "added": list(self.added.keys()),
            "removed": list(self.removed.keys()),
        }

    @classmethod
    def from_dict(cls, data: dict) -> TwoPSet:
        """Rehydrate a :class:`TwoPSet` previously produced by ``to_dict``."""
        if not isinstance(data, dict):
            raise TypeError(f"from_dict expects dict, got {type(data).__name__}")
        if data.get("type") != "TwoPSet":
            raise ConvergeError(
                f"from_dict: expected type 'TwoPSet', got {data.get('type')!r}"
            )
        instance = cls(data["replica_id"])
        instance.added = {e: True for e in _iter_list(data.get("added", []))}
        instance.removed = {e: True for e in _iter_list(data.get("removed", []))}
        return instance

    # ------------------------------------------------------------------ #
    # Dunder
    # ------------------------------------------------------------------ #
    def __eq__(self, other: object) -> bool:
        if not isinstance(other, TwoPSet):
            return NotImplemented
        # Two TwoPSets are equal if they have the same added/removed
        # membership. We intentionally ignore replica_id and dict insertion
        # order here — those are implementation detail, not state.
        return (
            set(self.added.keys()) == set(other.added.keys())
            and set(self.removed.keys()) == set(other.removed.keys())
        )

    def __repr__(self) -> str:
        return (
            f"TwoPSet(replica_id={self.replica_id!r}, "
            f"added={list(self.added.keys())!r}, "
            f"removed={list(self.removed.keys())!r})"
        )

    # ------------------------------------------------------------------ #
    # Internal helpers
    # ------------------------------------------------------------------ #
    @staticmethod
    def _check_hashable(element: Any) -> None:
        """Ensure ``element`` is hashable; raise ``TypeError`` otherwise."""
        try:
            hash(element)
        except TypeError as exc:
            raise TypeError(
                f"TwoPSet elements must be hashable: {element!r}"
            ) from exc


def _iter_list(obj: Any) -> Iterable:
    """Return ``obj`` if it is a list, else raise ``TypeError``."""
    if not isinstance(obj, list):
        raise TypeError(f"expected list, got {type(obj).__name__}")
    return obj
