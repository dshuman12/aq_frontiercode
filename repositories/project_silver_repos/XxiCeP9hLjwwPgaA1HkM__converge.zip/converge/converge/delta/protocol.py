"""Protocol and abstract base class for delta-CRDTs.

State-based CRDTs converge by gossiping their entire state every round;
that is simple but wastes bandwidth once the state gets large. A
*delta-CRDT* instead produces a small, self-contained delta mutator on
each local operation and only ships those deltas. Peers apply received
deltas with the usual CRDT merge rule, so the convergence properties
(idempotence, commutativity, associativity) are preserved while the
wire-traffic grows with activity rather than with total state size.

This module defines the three-method interface every delta-CRDT in the
library follows: :meth:`snapshot`, :meth:`delta_since`, and
:meth:`apply_delta`.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class DeltaCRDT(ABC):
    """Abstract base class implemented by every delta-CRDT in converge.

    Concrete subclasses (for example :class:`DeltaGCounter` and
    :class:`DeltaORSet`) extend an existing state-based CRDT with these
    three methods while preserving the parent's merge semantics. A
    typical anti-entropy round looks like::

        my_snap = peer.snapshot()           # peer tells us what it has
        delta = self.delta_since(my_snap)   # we compute the difference
        peer.apply_delta(delta)             # peer applies the diff

    The ``snapshot`` / ``delta`` payloads are deliberately plain data
    (dicts, sets, tuples) so that they survive a JSON round-trip and
    can be sent over the wire unchanged.
    """

    @abstractmethod
    def snapshot(self) -> Any:
        """Return an opaque summary of the local state.

        The returned value is handed to a peer's :meth:`delta_since`
        call so the peer can compute exactly what has changed on us
        since the last round. Implementations should keep snapshots
        small (a dict of per-replica versions is typical) and MUST
        return JSON-safe data.
        """
        raise NotImplementedError

    @abstractmethod
    def delta_since(self, other_state: Any) -> Any:
        """Return the delta that, when applied to ``other_state``, matches ``self``.

        ``other_state`` is the output of a remote :meth:`snapshot`. The
        returned delta MUST be idempotent and commutative with respect
        to other deltas -- applying it twice, or in a different order
        relative to other deltas, must not change the final state.
        """
        raise NotImplementedError

    @abstractmethod
    def apply_delta(self, delta: Any) -> None:
        """Apply a delta produced by a peer's :meth:`delta_since` in place.

        Because deltas are idempotent, receiving the same delta twice
        is harmless. Implementations SHOULD validate the delta's shape
        and raise :class:`TypeError` / :class:`ValueError` on malformed
        input rather than silently corrupting state.
        """
        raise NotImplementedError


__all__ = ["DeltaCRDT"]
