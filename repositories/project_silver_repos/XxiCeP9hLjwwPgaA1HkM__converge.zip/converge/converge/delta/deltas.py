"""Delta-CRDT wrappers for the core state-based CRDTs.

Each class in this module subclasses a state-based CRDT from the
library and extends it with the :class:`DeltaCRDT` three-method
interface (:meth:`snapshot`, :meth:`delta_since`, :meth:`apply_delta`)
without touching the parent's state layout. That way a delta-CRDT can
still be merged with a plain state-based peer via ``merge`` while also
participating in efficient delta-based gossip.
"""

from __future__ import annotations

from typing import Any, Hashable

from ..counters.gcounter import GCounter
from ..sets.orset import ORSet
from .protocol import DeltaCRDT


# ---------------------------------------------------------------------------
# DeltaGCounter
# ---------------------------------------------------------------------------

class DeltaGCounter(GCounter, DeltaCRDT):
    """G-Counter that can emit and apply per-replica increment deltas.

    The snapshot is a ``{replica_id: count}`` dict -- the same shape as
    the counter's internal ``counts`` view. A delta is also a
    ``{replica_id: amount}`` dict where each value is the positive
    increment the remote peer needs in order to catch up; zero-valued
    entries are omitted. Applying a delta is a max-merge on each
    replica's slot, which is exactly the G-Counter merge rule.
    """

    def snapshot(self) -> dict[str, int]:
        """Return a copy of the per-replica counts (a JSON-safe dict)."""
        return dict(self._counts)

    @property
    def counts(self) -> dict[str, int]:
        """Alias for :meth:`snapshot`; reads nicer at call sites."""
        return dict(self._counts)

    def delta_since(self, other_state: dict[str, int]) -> dict[str, int]:
        """Return the per-replica absolute counts where ``self`` is ahead.

        For each replica the emitted value is ``self._counts[replica]``
        (the absolute count, not a diff), omitted when the peer is
        already at or ahead of our count. Sending absolute counts keeps
        :meth:`apply_delta` as a plain max-merge, which is what makes
        repeated application idempotent.
        """
        if not isinstance(other_state, dict):
            raise TypeError("other_state must be a dict[str, int]")
        delta: dict[str, int] = {}
        for replica, count in self._counts.items():
            other_count = other_state.get(replica, 0)
            if not isinstance(other_count, int) or isinstance(other_count, bool):
                raise TypeError(
                    f"other_state values must be int, got "
                    f"{type(other_count).__name__}"
                )
            if other_count < 0:
                raise ValueError("other_state values must be non-negative")
            if count > other_count:
                delta[replica] = count
        return delta

    def apply_delta(self, delta: dict[str, int]) -> None:
        """Apply a per-replica absolute-count delta using max-merge semantics.

        Each ``delta[replica]`` is the sender's current count for that
        replica. Apply is ``self[replica] = max(self[replica], delta[replica])``.
        Because the operation is a pure max-merge of absolute values,
        applying the same delta any number of times is idempotent.
        """
        if not isinstance(delta, dict):
            raise TypeError("delta must be a dict[str, int]")
        for replica, amount in delta.items():
            if not isinstance(replica, str) or replica == "":
                raise TypeError("delta keys must be non-empty str")
            if not isinstance(amount, int) or isinstance(amount, bool):
                raise TypeError(f"delta values must be int, got {amount!r}")
            if amount < 0:
                raise ValueError("delta values must be non-negative")
            current = self._counts.get(replica, 0)
            if amount > current:
                self._counts[replica] = amount


# ---------------------------------------------------------------------------
# DeltaORSet
# ---------------------------------------------------------------------------

class DeltaORSet(ORSet, DeltaCRDT):
    """OR-Set that emits dot-based deltas for add/remove gossip.

    Snapshot shape: a dict ``{"dots": {element: [[replica, counter], ...]},
    "tombstones": [[replica, counter], ...]}``.  A delta reports exactly
    which dots have been added (per element) and which tombstones are
    new, so the peer can perform a standard OR-Set merge using only
    those deltas -- no need to ship the entire element table.
    """

    def snapshot(self) -> dict[str, Any]:
        """Return a JSON-safe summary of all alive dots and tombstones."""
        return {
            "dots": {
                element: sorted([list(d) for d in dots])
                for element, dots in self.elements.items()
                if dots
            },
            "tombstones": sorted([list(d) for d in self.tombstones]),
        }

    def delta_since(self, other_state: dict[str, Any]) -> dict[str, Any]:
        """Return the new alive-dots and new tombstones relative to ``other_state``."""
        if not isinstance(other_state, dict):
            raise TypeError("other_state must be a dict")
        peer_dots_raw = other_state.get("dots", {})
        peer_tombstones_raw = other_state.get("tombstones", [])
        if not isinstance(peer_dots_raw, dict):
            raise TypeError("other_state['dots'] must be a dict")
        if not isinstance(peer_tombstones_raw, (list, tuple, set, frozenset)):
            raise TypeError("other_state['tombstones'] must be list-like")

        peer_dots: dict[Hashable, set[tuple[str, int]]] = {}
        for element, dots in peer_dots_raw.items():
            peer_dots[element] = {_dot_tuple(d) for d in dots}
        peer_tombstones: set[tuple[str, int]] = {
            _dot_tuple(d) for d in peer_tombstones_raw
        }

        added: dict[Hashable, list[list[Any]]] = {}
        for element, dots in self.elements.items():
            if not dots:
                continue
            new_dots = dots - peer_dots.get(element, set())
            if new_dots:
                added[element] = sorted([list(d) for d in new_dots])

        new_tombstones = sorted(
            [list(d) for d in (self.tombstones - peer_tombstones)]
        )
        return {"added": added, "tombstones": new_tombstones}

    def apply_delta(self, delta: dict[str, Any]) -> None:
        """Apply a delta produced by :meth:`delta_since`.

        Added dots are unioned into each element's dot set; then the
        freshly-received tombstones are unioned into the tombstone set
        and applied to every element. We also refresh the local
        counter with :func:`_recompute_local_counter` so future
        :meth:`add` calls do not reuse a dot we've just learned about.
        """
        if not isinstance(delta, dict):
            raise TypeError("delta must be a dict")
        added_raw = delta.get("added", {})
        tombstones_raw = delta.get("tombstones", [])
        if not isinstance(added_raw, dict):
            raise TypeError("delta['added'] must be a dict")
        if not isinstance(tombstones_raw, (list, tuple, set, frozenset)):
            raise TypeError("delta['tombstones'] must be list-like")

        new_tombstones: set[tuple[str, int]] = {
            _dot_tuple(d) for d in tombstones_raw
        }
        all_tombstones = self.tombstones | new_tombstones

        for element, dots in added_raw.items():
            if not isinstance(dots, (list, tuple, set, frozenset)):
                raise TypeError("delta['added'] values must be list-like")
            incoming = {_dot_tuple(d) for d in dots}
            current = self.elements.get(element, set())
            self.elements[element] = (current | incoming) - all_tombstones

        # Tombstones may have killed dots in elements we did not receive
        # any additions for; scrub those as well.
        for element, dots in list(self.elements.items()):
            self.elements[element] = dots - all_tombstones

        self.tombstones = all_tombstones
        self._counter = self._recompute_local_counter()


def _dot_tuple(obj: Any) -> tuple[str, int]:
    """Coerce a 2-element list/tuple into a ``(replica, counter)`` dot tuple."""
    if not isinstance(obj, (list, tuple)) or len(obj) != 2:
        raise TypeError(f"expected 2-element list/tuple for a dot, got {obj!r}")
    replica, counter = obj
    if not isinstance(replica, str) or replica == "":
        raise TypeError("dot replica must be a non-empty str")
    if not isinstance(counter, int) or isinstance(counter, bool):
        raise TypeError("dot counter must be int")
    if counter < 1:
        raise ValueError("dot counter must be >= 1")
    return (replica, counter)


__all__ = ["DeltaGCounter", "DeltaORSet"]
