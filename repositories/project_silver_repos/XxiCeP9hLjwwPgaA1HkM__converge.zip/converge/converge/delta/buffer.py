"""Sequence-numbered buffer for outbound delta gossip.

A delta-CRDT emits a small mutator on every local operation. In an
anti-entropy protocol each peer needs to replay exactly the deltas it
has not yet seen, so we tag every buffered delta with a strictly
increasing sequence number and let peers ask for "everything after ``n``".
Once every peer has acknowledged sequence ``m`` the caller can
:meth:`compact` the buffer to reclaim memory.
"""

from __future__ import annotations

from typing import Any

from ..errors import ConvergeError


class DeltaBuffer:
    """Append-only, sequence-numbered buffer of outbound delta mutators.

    Sequence numbers are monotonically increasing 1-based integers that
    are never reused, even after :meth:`compact` drops older entries.
    This makes per-peer bookmarking trivial: a peer remembers the last
    seq it applied and asks for :meth:`deltas_since` next round.
    """

    __slots__ = ("_entries", "_next_seq")

    def __init__(self) -> None:
        """Create an empty delta buffer with the next sequence number set to ``1``."""
        # ``_entries`` is kept sorted by seq; we only append, so insertion
        # order already equals seq order.
        self._entries: list[tuple[int, Any]] = []
        self._next_seq: int = 1

    # ------------------------------------------------------------------
    # Mutation
    # ------------------------------------------------------------------
    def push(self, delta: Any) -> int:
        """Append ``delta`` to the buffer and return its assigned sequence number.

        Sequence numbers never decrease and never repeat, even after
        :meth:`compact`. The returned value is the seq the caller must
        use later with :meth:`deltas_since` to exclude this entry.
        """
        seq = self._next_seq
        self._entries.append((seq, delta))
        self._next_seq += 1
        return seq

    def compact(self, before_seq: int) -> int:
        """Drop every entry whose seq is ``< before_seq``; return the drop count.

        This is garbage collection: the caller is responsible for
        ensuring no peer still needs the dropped deltas. Raises
        :class:`ConvergeError` if ``before_seq`` is ahead of the next
        seq we would ever assign, since that would silently strand a
        future push.
        """
        if not isinstance(before_seq, int) or isinstance(before_seq, bool):
            raise TypeError("before_seq must be int")
        if before_seq < 0:
            raise ValueError("before_seq must be non-negative")
        if before_seq > self._next_seq:
            raise ConvergeError(
                f"before_seq ({before_seq}) is ahead of next_seq "
                f"({self._next_seq})"
            )
        # Linear scan is fine: entries are always in seq order.
        keep_from = 0
        for idx, (seq, _delta) in enumerate(self._entries):
            if seq >= before_seq:
                keep_from = idx
                break
        else:
            # Every entry is strictly below ``before_seq``; drop them all.
            dropped = len(self._entries)
            self._entries = []
            return dropped
        dropped = keep_from
        if dropped:
            self._entries = self._entries[keep_from:]
        return dropped

    # ------------------------------------------------------------------
    # Accessors
    # ------------------------------------------------------------------
    def deltas_since(self, seq: int) -> list[tuple[int, Any]]:
        """Return every ``(seq, delta)`` pair with seq strictly greater than ``seq``.

        The returned list is ordered by seq ascending so that the
        caller can apply them in the original order they were pushed.
        """
        if not isinstance(seq, int) or isinstance(seq, bool):
            raise TypeError("seq must be int")
        if seq < 0:
            raise ValueError("seq must be non-negative")
        return [(s, d) for (s, d) in self._entries if s > seq]

    def peek_latest(self) -> tuple[int, Any] | None:
        """Return the most recent ``(seq, delta)`` pair, or ``None`` if empty."""
        if not self._entries:
            return None
        return self._entries[-1]

    @property
    def next_seq(self) -> int:
        """Return the sequence number that the next :meth:`push` will assign."""
        return self._next_seq

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------
    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-safe dict representation of the buffer.

        The deltas themselves must already be JSON-safe (which is what
        the delta-CRDT classes in this package produce); anything else
        is the caller's responsibility.
        """
        return {
            "next_seq": self._next_seq,
            "entries": [[seq, delta] for (seq, delta) in self._entries],
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> DeltaBuffer:
        """Rebuild a :class:`DeltaBuffer` from :meth:`to_dict` output."""
        if not isinstance(d, dict):
            raise TypeError("from_dict expects a dict")
        next_seq = d.get("next_seq", 1)
        entries_raw = d.get("entries", [])
        if not isinstance(next_seq, int) or isinstance(next_seq, bool):
            raise TypeError("next_seq must be int")
        if next_seq < 1:
            raise ValueError("next_seq must be >= 1")
        if not isinstance(entries_raw, (list, tuple)):
            raise TypeError("entries must be a list")
        buf = cls()
        buf._next_seq = next_seq
        parsed: list[tuple[int, Any]] = []
        prev_seq = 0
        for item in entries_raw:
            if not isinstance(item, (list, tuple)) or len(item) != 2:
                raise TypeError(
                    "each entry must be a [seq, delta] pair"
                )
            seq, delta = item
            if not isinstance(seq, int) or isinstance(seq, bool):
                raise TypeError("seq must be int")
            if seq < 1:
                raise ValueError("seq must be >= 1")
            if seq <= prev_seq:
                raise ValueError("entries must be in strictly increasing seq order")
            if seq >= next_seq:
                raise ValueError(
                    f"entry seq {seq} must be < next_seq {next_seq}"
                )
            parsed.append((seq, delta))
            prev_seq = seq
        buf._entries = parsed
        return buf

    # ------------------------------------------------------------------
    # Dunder methods
    # ------------------------------------------------------------------
    def __len__(self) -> int:
        return len(self._entries)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, DeltaBuffer):
            return NotImplemented
        return (
            self._next_seq == other._next_seq
            and self._entries == other._entries
        )

    def __repr__(self) -> str:
        return (
            f"DeltaBuffer(size={len(self._entries)}, "
            f"next_seq={self._next_seq})"
        )

    __hash__ = None  # type: ignore[assignment]


__all__ = ["DeltaBuffer"]
