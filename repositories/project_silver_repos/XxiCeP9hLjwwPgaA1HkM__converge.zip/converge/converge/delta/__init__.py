"""Delta-CRDT layer: efficient anti-entropy gossip on top of state-based CRDTs.

This subpackage turns the state-based CRDTs in :mod:`converge` into
delta-CRDTs. Every local operation produces a small mutator that can be
gossiped to peers instead of re-shipping the whole state each round.
See :class:`DeltaCRDT` for the three-method interface every wrapper
implements, :class:`DeltaGCounter` / :class:`DeltaORSet` for concrete
examples, and :class:`DeltaBuffer` for the sequence-numbered buffer
that peers use to catch up.
"""

from __future__ import annotations

from .buffer import DeltaBuffer
from .deltas import DeltaGCounter, DeltaORSet
from .protocol import DeltaCRDT

__all__ = ["DeltaCRDT", "DeltaGCounter", "DeltaORSet", "DeltaBuffer"]
