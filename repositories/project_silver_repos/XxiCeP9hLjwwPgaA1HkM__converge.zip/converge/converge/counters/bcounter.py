"""Bounded counter (BCounter) CRDT.

A :class:`BoundedCounter` (BCounter) is a counter whose observed value
is guaranteed never to fall below zero. Unlike a PN-Counter -- where
any replica may decrement at will and local negative views are
possible while gossip is in flight -- the BCounter represents each
replica's decrement budget explicitly as a *reservation*.

Replicas have local decrement quota equal to their own increments
plus any transfers received from peers minus any transfers they have
made to peers minus their own decrements. A replica must transfer
quota before another replica can decrement; attempting to decrement
or transfer more than the local quota is rejected locally. Merge is
componentwise max on each of the three internal tables, which keeps
the join idempotent, commutative and associative.
"""

from __future__ import annotations

from typing import Any

from converge.errors import ConvergeError, ReplicaError


def _validate_replica_id(replica_id: Any) -> str:
    """Validate that ``replica_id`` is a non-empty string.

    Raises :class:`ReplicaError` with a descriptive message otherwise.
    This helper is intentionally duplicated across modules to keep
    each CRDT file independently readable.
    """
    if not isinstance(replica_id, str):
        raise ReplicaError(
            f"replica_id must be a str, got {type(replica_id).__name__}"
        )
    if replica_id == "":
        raise ReplicaError("replica_id must be a non-empty string")
    return replica_id


def _validate_non_negative_int(n: Any, name: str) -> int:
    """Ensure ``n`` is a non-negative plain ``int`` and return it.

    ``bool`` is excluded explicitly because Python treats ``True``/
    ``False`` as ints; allowing them would let ``increment(True)``
    silently succeed, which is confusing.
    """
    if not isinstance(n, int) or isinstance(n, bool):
        raise TypeError(f"{name} must be int")
    if n < 0:
        raise ValueError(f"{name} must be non-negative")
    return n


class BoundedCounter:
    """A counter that cannot go below zero.

    Replicas have local decrement quota from their own increments plus
    any transfers received. A replica must transfer quota before
    another replica can decrement. The observed total is always
    ``sum(contrib) - sum(decrements) >= 0`` by construction.
    """

    __hash__ = None  # type: ignore[assignment]

    def __init__(self, replica_id: str) -> None:
        """Create an empty bounded counter owned by ``replica_id``.

        All three internal tables start empty, meaning the initial
        value is zero and the local quota is also zero -- no
        decrements are permitted until at least one increment or
        transfer has arrived.
        """
        self.replica_id = _validate_replica_id(replica_id)
        # Per-replica positive contributions (increments only).
        self.contrib: dict[str, int] = {}
        # (from_replica, to_replica) -> cumulative amount transferred.
        self.transfers: dict[tuple[str, str], int] = {}
        # Per-replica cumulative decrements.
        self.decrements: dict[str, int] = {}

    # ------------------------------------------------------------------ #
    # Local quota arithmetic
    # ------------------------------------------------------------------ #
    def _received(self, replica: str) -> int:
        """Sum of transfers into ``replica`` from every other replica."""
        return sum(
            amount
            for (src, dst), amount in self.transfers.items()
            if dst == replica and src != replica
        )

    def _sent(self, replica: str) -> int:
        """Sum of transfers out of ``replica`` to every other replica."""
        return sum(
            amount
            for (src, dst), amount in self.transfers.items()
            if src == replica and dst != replica
        )

    def local_quota(self, replica: str | None = None) -> int:
        """Return how much decrement quota ``replica`` has remaining.

        Defaults to this replica. Quota equals the replica's own
        increments plus any transfers received minus any transfers
        sent minus its own decrements. It is always non-negative --
        each operation is rejected locally before it could drive the
        number negative.
        """
        if replica is None:
            replica = self.replica_id
        _validate_replica_id(replica)
        own = self.contrib.get(replica, 0)
        return (
            own
            + self._received(replica)
            - self._sent(replica)
            - self.decrements.get(replica, 0)
        )

    # ------------------------------------------------------------------ #
    # Mutations
    # ------------------------------------------------------------------ #
    def increment(self, n: int = 1) -> None:
        """Increment the counter by ``n`` under this replica's slot.

        Only the owning replica may increment its own slot. ``n`` must
        be a non-negative ``int``; ``n == 0`` is a no-op. Incrementing
        automatically grows the owner's local quota by ``n``.
        """
        value = _validate_non_negative_int(n, "n")
        if value == 0:
            return
        self.contrib[self.replica_id] = self.contrib.get(self.replica_id, 0) + value

    def transfer(self, to_replica: str, n: int) -> None:
        """Transfer ``n`` units of decrement quota from self to ``to_replica``.

        The transfer is local-only until a merge propagates it; the
        receiving replica only observes the new quota after it sees
        the updated ``transfers`` entry through :meth:`merge`. Raises
        :class:`ConvergeError` if the local quota is insufficient and
        :class:`ReplicaError` if ``to_replica`` is ``self.replica_id``
        or otherwise invalid.
        """
        _validate_replica_id(to_replica)
        if to_replica == self.replica_id:
            raise ReplicaError("cannot transfer quota to self")
        value = _validate_non_negative_int(n, "n")
        if value == 0:
            return
        if self.local_quota() < value:
            raise ConvergeError(
                f"insufficient quota on {self.replica_id!r}: "
                f"have {self.local_quota()}, need {value}"
            )
        key = (self.replica_id, to_replica)
        self.transfers[key] = self.transfers.get(key, 0) + value

    def decrement(self, n: int = 1) -> None:
        """Decrement the counter by ``n`` under this replica's slot.

        Fails with :class:`ConvergeError` if doing so would drive the
        local quota below zero. Because each replica only ever
        decrements against its own quota this check preserves the
        global "value >= 0" invariant across any concurrent schedule.
        """
        value = _validate_non_negative_int(n, "n")
        if value == 0:
            return
        if self.local_quota() < value:
            raise ConvergeError(
                f"insufficient quota on {self.replica_id!r} to decrement by {value}: "
                f"have {self.local_quota()}"
            )
        self.decrements[self.replica_id] = (
            self.decrements.get(self.replica_id, 0) + value
        )

    # ------------------------------------------------------------------ #
    # Observation
    # ------------------------------------------------------------------ #
    def value(self) -> int:
        """Return the observed counter value.

        The total is the sum of every replica's increments minus the
        sum of every replica's decrements. Transfers do not appear in
        this formula because they are conservative moves of quota
        between replicas; they reshuffle the right to decrement
        without changing the total.
        """
        return sum(self.contrib.values()) - sum(self.decrements.values())

    # ------------------------------------------------------------------ #
    # Merge
    # ------------------------------------------------------------------ #
    def merge(self, other: BoundedCounter) -> None:
        """Merge ``other`` into ``self`` componentwise by max.

        ``contrib``, ``transfers`` and ``decrements`` are all merged by
        taking the per-key maximum. Because each of those tables is
        itself a grow-only counter-like CRDT, this merge is
        idempotent, commutative and associative. The merged state is
        guaranteed to keep ``value() >= 0`` provided both inputs did.
        """
        if not isinstance(other, BoundedCounter):
            raise TypeError(
                f"cannot merge BoundedCounter with {type(other).__name__}"
            )
        for replica, amount in other.contrib.items():
            if amount > self.contrib.get(replica, 0):
                self.contrib[replica] = amount
        for key, amount in other.transfers.items():
            if amount > self.transfers.get(key, 0):
                self.transfers[key] = amount
        for replica, amount in other.decrements.items():
            if amount > self.decrements.get(replica, 0):
                self.decrements[replica] = amount

    # ------------------------------------------------------------------ #
    # Serialization
    # ------------------------------------------------------------------ #
    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-safe dict representation.

        ``transfers`` is emitted as a list of ``[from, to, amount]``
        triples because JSON object keys must be strings; reassembling
        the tuple keys happens in :meth:`from_dict`.
        """
        return {
            "type": "BoundedCounter",
            "replica_id": self.replica_id,
            "contrib": dict(self.contrib),
            "transfers": [
                [src, dst, amount]
                for (src, dst), amount in sorted(self.transfers.items())
            ],
            "decrements": dict(self.decrements),
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> BoundedCounter:
        """Rebuild a :class:`BoundedCounter` from the output of :meth:`to_dict`."""
        if not isinstance(d, dict):
            raise TypeError("from_dict expects a dict")
        if d.get("type") not in (None, "BoundedCounter"):
            raise ConvergeError(
                f"from_dict: expected type 'BoundedCounter', got {d.get('type')!r}"
            )
        replica_id = d.get("replica_id")
        inst = cls(replica_id)  # type: ignore[arg-type]

        contrib = d.get("contrib", {})
        if not isinstance(contrib, dict):
            raise TypeError("from_dict expects 'contrib' to be a dict")
        for replica, amount in contrib.items():
            _validate_replica_id(replica)
            _validate_non_negative_int(amount, "contrib amount")
            inst.contrib[replica] = amount

        transfers = d.get("transfers", [])
        if not isinstance(transfers, list):
            raise TypeError("from_dict expects 'transfers' to be a list")
        for entry in transfers:
            if not isinstance(entry, (list, tuple)) or len(entry) != 3:
                raise TypeError(
                    "each transfer entry must be [from, to, amount]"
                )
            src, dst, amount = entry
            _validate_replica_id(src)
            _validate_replica_id(dst)
            _validate_non_negative_int(amount, "transfer amount")
            inst.transfers[(src, dst)] = amount

        decrements = d.get("decrements", {})
        if not isinstance(decrements, dict):
            raise TypeError("from_dict expects 'decrements' to be a dict")
        for replica, amount in decrements.items():
            _validate_replica_id(replica)
            _validate_non_negative_int(amount, "decrement amount")
            inst.decrements[replica] = amount

        return inst

    # ------------------------------------------------------------------ #
    # Dunder
    # ------------------------------------------------------------------ #
    def __eq__(self, other: object) -> bool:
        if not isinstance(other, BoundedCounter):
            return NotImplemented
        # Value-equality compares the three state tables and ignores
        # the local ``replica_id`` tag, which is an instance label
        # rather than part of the CRDT state.
        return (
            self.contrib == other.contrib
            and self.transfers == other.transfers
            and self.decrements == other.decrements
        )

    def __repr__(self) -> str:
        contrib = ", ".join(
            f"{r!r}: {v}" for r, v in sorted(self.contrib.items())
        )
        transfers = ", ".join(
            f"({s!r}->{d!r}): {v}"
            for (s, d), v in sorted(self.transfers.items())
        )
        decrements = ", ".join(
            f"{r!r}: {v}" for r, v in sorted(self.decrements.items())
        )
        return (
            f"BoundedCounter(replica_id={self.replica_id!r}, "
            f"contrib={{{contrib}}}, transfers={{{transfers}}}, "
            f"decrements={{{decrements}}})"
        )


# Historical alias. Tests and external code may refer to the CRDT by
# the shorthand ``BCounter`` used in the literature.
BCounter = BoundedCounter
