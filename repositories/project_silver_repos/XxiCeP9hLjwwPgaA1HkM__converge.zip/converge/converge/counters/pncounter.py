"""Positive-negative counter (PN-Counter) CRDT.

A :class:`PNCounter` supports both increment and decrement by composing
two :class:`GCounter` instances -- one for positive contributions
(``pos``) and one for negative contributions (``neg``). The observed
value is ``pos.value() - neg.value()``. Because each inner counter is
itself a CRDT, merge simply delegates to the inner counters and inherits
idempotence, commutativity, and associativity.
"""

from __future__ import annotations

from typing import Any

from ..errors import ReplicaError
from .gcounter import GCounter


def _validate_replica_id(replica_id: Any) -> None:
    """Raise :class:`ReplicaError` if ``replica_id`` is not a non-empty string."""
    if not isinstance(replica_id, str) or replica_id == "":
        raise ReplicaError("replica_id must be a non-empty string")


class PNCounter:
    """Counter supporting increment and decrement via two internal G-Counters.

    Both inner counters are parameterised with the same ``replica_id``;
    incrementing the PN-Counter modifies the positive G-Counter and
    decrementing modifies the negative G-Counter.
    """

    __slots__ = ("_replica_id", "_pos", "_neg")

    def __init__(
        self,
        replica_id: str,
        pos: GCounter | None = None,
        neg: GCounter | None = None,
    ) -> None:
        """Create a PN-Counter owned by ``replica_id``; inner counters may be supplied."""
        _validate_replica_id(replica_id)
        self._replica_id: str = replica_id
        self._pos: GCounter = pos if pos is not None else GCounter(replica_id)
        self._neg: GCounter = neg if neg is not None else GCounter(replica_id)

        if not isinstance(self._pos, GCounter) or not isinstance(self._neg, GCounter):
            raise TypeError("pos and neg must be GCounter instances")
        if self._pos.replica_id != replica_id or self._neg.replica_id != replica_id:
            raise ReplicaError(
                "inner GCounter replica_id must match PNCounter replica_id"
            )

    # ------------------------------------------------------------------
    # Accessors
    # ------------------------------------------------------------------
    @property
    def replica_id(self) -> str:
        """Return the replica id that owns this counter."""
        return self._replica_id

    @property
    def pos(self) -> GCounter:
        """Return the inner positive G-Counter."""
        return self._pos

    @property
    def neg(self) -> GCounter:
        """Return the inner negative G-Counter."""
        return self._neg

    def value(self) -> int:
        """Return the observed value, ``pos.value() - neg.value()``."""
        return self._pos.value() - self._neg.value()

    # ------------------------------------------------------------------
    # Mutation
    # ------------------------------------------------------------------
    def increment(self, n: int = 1) -> None:
        """Add ``n`` (non-negative) to the positive component."""
        # Delegate validation to GCounter.increment to keep rules in one place.
        self._pos.increment(n)

    def decrement(self, n: int = 1) -> None:
        """Add ``n`` (non-negative) to the negative component."""
        self._neg.increment(n)

    def merge(self, other: PNCounter) -> None:
        """Merge ``other`` into ``self`` by merging each inner G-Counter."""
        if not isinstance(other, PNCounter):
            raise TypeError("can only merge PNCounter with PNCounter")
        self._pos.merge(other._pos)
        self._neg.merge(other._neg)

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------
    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-safe dict representation, embedding both inner counters."""
        return {
            "replica_id": self._replica_id,
            "pos": self._pos.to_dict(),
            "neg": self._neg.to_dict(),
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> PNCounter:
        """Rebuild a :class:`PNCounter` from the output of :meth:`to_dict`."""
        if not isinstance(d, dict):
            raise TypeError("from_dict expects a dict")
        replica_id = d.get("replica_id")
        pos_raw = d.get("pos")
        neg_raw = d.get("neg")
        if not isinstance(pos_raw, dict) or not isinstance(neg_raw, dict):
            raise TypeError("from_dict expects 'pos' and 'neg' to be dicts")
        pos = GCounter.from_dict(pos_raw)
        neg = GCounter.from_dict(neg_raw)
        return cls(replica_id, pos=pos, neg=neg)  # type: ignore[arg-type]

    # ------------------------------------------------------------------
    # Dunder methods
    # ------------------------------------------------------------------
    def __eq__(self, other: object) -> bool:
        if not isinstance(other, PNCounter):
            return NotImplemented
        return (
            self._replica_id == other._replica_id
            and self._pos == other._pos
            and self._neg == other._neg
        )

    def __repr__(self) -> str:
        return (
            f"PNCounter(replica_id={self._replica_id!r}, "
            f"pos={self._pos!r}, neg={self._neg!r})"
        )

    __hash__ = None  # type: ignore[assignment]
