"""Grow-only counter (G-Counter) CRDT.

A :class:`GCounter` tracks a per-replica, monotonically non-decreasing
count. Each replica may only increment its own slot; the observed value
is the sum of every replica's slot. Merge takes the per-replica maximum,
which is idempotent, commutative, and associative and therefore yields
strong eventual consistency without any coordination.
"""

from __future__ import annotations

from typing import Any

from ..errors import ReplicaError


def _validate_replica_id(replica_id: Any) -> None:
    """Raise :class:`ReplicaError` if ``replica_id`` is not a non-empty string."""
    if not isinstance(replica_id, str) or replica_id == "":
        raise ReplicaError("replica_id must be a non-empty string")


class GCounter:
    """Grow-only counter keyed by replica id.

    Only the replica identified by ``self.replica_id`` is allowed to
    increment its own entry; other replicas' entries are updated solely
    through :meth:`merge`. The observed value is the sum of all entries.
    """

    __slots__ = ("_replica_id", "_counts")

    def __init__(
        self,
        replica_id: str,
        counts: dict[str, int] | None = None,
    ) -> None:
        """Create a G-Counter owned by ``replica_id``, optionally seeded with ``counts``."""
        _validate_replica_id(replica_id)
        self._replica_id: str = replica_id
        self._counts: dict[str, int] = {}

        if counts is not None:
            if not isinstance(counts, dict):
                raise TypeError("counts must be a dict[str, int] or None")
            for replica, value in counts.items():
                _validate_replica_id(replica)
                if not isinstance(value, int) or isinstance(value, bool):
                    raise TypeError("GCounter counts must be int")
                if value < 0:
                    raise ValueError("GCounter counts must be non-negative")
                if value > 0:
                    self._counts[replica] = value

    # ------------------------------------------------------------------
    # Accessors
    # ------------------------------------------------------------------
    @property
    def replica_id(self) -> str:
        """Return the replica id that owns this counter."""
        return self._replica_id

    def value(self) -> int:
        """Return the observed value: the sum of every replica's count."""
        return sum(self._counts.values())

    # ------------------------------------------------------------------
    # Mutation
    # ------------------------------------------------------------------
    def increment(self, n: int = 1) -> None:
        """Increment this replica's slot by ``n`` (must be a non-negative int)."""
        if not isinstance(n, int) or isinstance(n, bool):
            raise TypeError("n must be int")
        if n < 0:
            raise ValueError("n must be non-negative")
        if n == 0:
            return
        self._counts[self._replica_id] = self._counts.get(self._replica_id, 0) + n

    def merge(self, other: GCounter) -> None:
        """Merge ``other`` into ``self`` by taking per-replica maximum (in place)."""
        if not isinstance(other, GCounter):
            raise TypeError("can only merge GCounter with GCounter")
        for replica, value in other._counts.items():
            if value > self._counts.get(replica, 0):
                self._counts[replica] = value

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------
    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-safe dict representation of this counter."""
        return {
            "replica_id": self._replica_id,
            "counts": dict(self._counts),
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> GCounter:
        """Rebuild a :class:`GCounter` from the output of :meth:`to_dict`."""
        if not isinstance(d, dict):
            raise TypeError("from_dict expects a dict")
        replica_id = d.get("replica_id")
        counts = d.get("counts", {})
        if not isinstance(counts, dict):
            raise TypeError("from_dict expects 'counts' to be a dict")
        return cls(replica_id, counts)  # type: ignore[arg-type]

    # ------------------------------------------------------------------
    # Dunder methods
    # ------------------------------------------------------------------
    def __eq__(self, other: object) -> bool:
        if not isinstance(other, GCounter):
            return NotImplemented
        return (
            self._replica_id == other._replica_id
            and self._counts == other._counts
        )

    def __repr__(self) -> str:
        items = ", ".join(f"{r!r}: {c}" for r, c in sorted(self._counts.items()))
        return f"GCounter(replica_id={self._replica_id!r}, counts={{{items}}})"

    __hash__ = None  # type: ignore[assignment]
