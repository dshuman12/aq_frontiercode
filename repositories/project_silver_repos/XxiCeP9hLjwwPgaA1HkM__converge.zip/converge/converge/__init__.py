"""converge — state-based CRDTs in pure Python."""
from __future__ import annotations

from converge.errors import ConvergeError, CausalError, ReplicaError
from converge.causality import VectorClock, DottedVersionVector, IntervalTreeClock
from converge.counters import GCounter, PNCounter, BCounter, BoundedCounter
from converge.sets import GSet, TwoPSet, ORSet, LWWSet
from converge.registers import LWWRegister, MVRegister, MaxRegister, MinRegister
from converge.sequence import RGA
from converge.maps import ORMap, LWWMap
from converge.delta import DeltaCRDT, DeltaGCounter, DeltaORSet, DeltaBuffer
from converge.sync import AntiEntropyRound, NetworkSim, StateSync

__all__ = [
    "ConvergeError", "CausalError", "ReplicaError",
    "VectorClock", "DottedVersionVector", "IntervalTreeClock",
    "GCounter", "PNCounter", "BCounter", "BoundedCounter",
    "GSet", "TwoPSet", "ORSet", "LWWSet",
    "LWWRegister", "MVRegister", "MaxRegister", "MinRegister",
    "RGA",
    "ORMap", "LWWMap",
    "DeltaCRDT", "DeltaGCounter", "DeltaORSet", "DeltaBuffer",
    "AntiEntropyRound", "NetworkSim", "StateSync",
]

__version__ = "0.2.0"
