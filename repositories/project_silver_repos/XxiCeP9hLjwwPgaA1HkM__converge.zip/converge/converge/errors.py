"""Exception hierarchy for the converge library.

All converge-specific errors inherit from :class:`ConvergeError` so that
callers can catch the whole family with a single ``except`` clause. More
specific subclasses distinguish between causal-history violations
(:class:`CausalError`) and replica-identity problems
(:class:`ReplicaError`).
"""

from __future__ import annotations


class ConvergeError(Exception):
    """Base class for all converge-specific errors."""


class CausalError(ConvergeError):
    """Raised when a causal-history invariant is violated.

    Examples include referencing a dot that has not been observed or
    attempting an operation that would break the happens-before order
    tracked by a vector clock or dotted version vector.
    """


class ReplicaError(ConvergeError):
    """Raised for problems related to a replica identifier.

    The most common case is an empty or non-string ``replica_id`` passed
    to a CRDT constructor.
    """
