"""Sequence CRDTs exposed by converge.

This subpackage currently re-exports :class:`RGA`, converge's
Replicated Growable Array implementation.
"""

from __future__ import annotations

from .rga import RGA

__all__ = ["RGA"]
