"""Replicated Growable Array (RGA).

An :class:`RGA` is a sequence CRDT where every element is stored as a
node with a unique ``(replica_id, counter)`` id and a parent pointer
identifying the node it was inserted immediately after. The visible
order is produced by a pre-order traversal of the parent tree rooted
at the virtual head (``parent_id == None``). Siblings of the same
parent are ordered by id **descending** lexicographically so that a
replica's freshest writes appear nearest their anchor. Deletions are
tombstones -- the node stays in the tree so concurrent inserts that
anchored on it keep their relative position.

Note: ``insert_at(n, ...)`` where ``n == len(self)`` anchors on the
last *visible* node, which may be a tombstone if the tail has been
deleted. This is intentional: it keeps the anchor stable under
concurrent trailing deletes, at the cost of exposing a tombstone as an
anchor in the internal tree.
"""

from __future__ import annotations

from typing import Any

from ..errors import ReplicaError


NodeId = tuple[str, int]


def _validate_replica_id(replica_id: Any) -> None:
    """Raise :class:`ReplicaError` if ``replica_id`` is not a non-empty string."""
    if not isinstance(replica_id, str) or replica_id == "":
        raise ReplicaError("replica_id must be a non-empty string")


class _Node:
    """Internal tree node used by :class:`RGA`.

    Each node carries its own id, the id of the node it was inserted
    after (``None`` for top-level inserts), the user element it stores
    and a tombstone flag flipped on by :meth:`RGA.delete_at`.
    """

    __slots__ = ("id", "parent", "element", "tombstoned")

    def __init__(
        self,
        id: NodeId,
        parent: NodeId | None,
        element: Any,
        tombstoned: bool = False,
    ) -> None:
        self.id: NodeId = id
        self.parent: NodeId | None = parent
        self.element: Any = element
        self.tombstoned: bool = tombstoned

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, _Node):
            return NotImplemented
        return (
            self.id == other.id
            and self.parent == other.parent
            and self.element == other.element
            and self.tombstoned == other.tombstoned
        )

    def __repr__(self) -> str:
        return (
            f"_Node(id={self.id!r}, parent={self.parent!r}, "
            f"element={self.element!r}, tombstoned={self.tombstoned})"
        )


class RGA:
    """Replicated Growable Array -- a convergent sequence CRDT."""

    __slots__ = ("_replica_id", "_nodes", "_order", "_counter", "_counters")

    def __init__(self, replica_id: str) -> None:
        """Initialise an empty RGA owned by ``replica_id``."""
        _validate_replica_id(replica_id)
        self._replica_id: str = replica_id
        # All nodes ever seen, keyed by id. Tombstoned nodes are kept so
        # that concurrent inserts anchored on them still find their parent.
        self._nodes: dict[NodeId, _Node] = {}
        # Canonical pre-order traversal of the parent tree, including
        # tombstoned nodes.
        self._order: list[NodeId] = []
        # Local counter used to mint fresh ids (``self._replica_id`` suffix).
        self._counter: int = 0
        # Per-replica maximum counter we've observed. Used to drive
        # ``next id`` post-merge and to help reason about unseen nodes.
        self._counters: dict[str, int] = {}

    # ------------------------------------------------------------------
    # Mutation
    # ------------------------------------------------------------------
    def insert_at(self, pos: int, element: Any) -> None:
        """Insert ``element`` so that it appears at visible position ``pos``.

        ``pos`` ranges over the visible (non-tombstoned) elements: ``0``
        means "before every existing visible element", ``len(self)``
        means "after the last visible element". Bounds outside that
        range raise :class:`IndexError`.
        """
        if not isinstance(pos, int) or isinstance(pos, bool):
            raise TypeError("pos must be int")
        visible = self._visible_ids()
        if pos < 0 or pos > len(visible):
            raise IndexError("RGA insert_at index out of range")
        parent_id: NodeId | None
        if pos == 0:
            parent_id = None
        else:
            parent_id = visible[pos - 1]

        self._counter += 1
        new_id: NodeId = (self._replica_id, self._counter)
        # Keep per-replica counter tracking consistent.
        self._counters[self._replica_id] = max(
            self._counters.get(self._replica_id, 0), self._counter
        )
        node = _Node(id=new_id, parent=parent_id, element=element)
        self._nodes[new_id] = node
        self._rebuild_order()

    def delete_at(self, pos: int) -> None:
        """Tombstone the visible element at position ``pos``.

        The node remains in the tree so that concurrent inserts
        anchored on it retain their relative positions after a merge.
        """
        if not isinstance(pos, int) or isinstance(pos, bool):
            raise TypeError("pos must be int")
        visible = self._visible_ids()
        if pos < 0 or pos >= len(visible):
            raise IndexError("RGA delete_at index out of range")
        target = visible[pos]
        self._nodes[target].tombstoned = True

    # ------------------------------------------------------------------
    # Observation
    # ------------------------------------------------------------------
    def to_list(self) -> list[Any]:
        """Return the list of visible (non-tombstoned) elements in order."""
        return [
            self._nodes[nid].element
            for nid in self._order
            if not self._nodes[nid].tombstoned
        ]

    def value(self) -> list[Any]:
        """Alias for :meth:`to_list` so the universal contract is satisfied."""
        return self.to_list()

    @property
    def replica_id(self) -> str:
        """Identifier of the replica owning this RGA instance."""
        return self._replica_id

    def __len__(self) -> int:
        """Return the number of visible (non-tombstoned) elements."""
        return sum(
            1 for nid in self._order if not self._nodes[nid].tombstoned
        )

    # ------------------------------------------------------------------
    # Merge
    # ------------------------------------------------------------------
    def merge(self, other: RGA) -> None:
        """Merge ``other`` into ``self`` by unioning nodes and tombstones.

        * A node id present on both sides must have the same parent and
          element (otherwise the ids collide, which is a causal
          violation).
        * Tombstones union -- a node is tombstoned if either side has
          it so.
        * The per-replica counter map is per-replica max.
        * The visible order is recomputed via pre-order DFS.
        """
        if not isinstance(other, RGA):
            raise TypeError("can only merge RGA with RGA")

        for nid, node in other._nodes.items():
            if nid in self._nodes:
                existing = self._nodes[nid]
                if existing.parent != node.parent or existing.element != node.element:
                    raise ValueError(
                        "RGA merge conflict: node id reused with different parent/element: "
                        f"{nid!r}"
                    )
                if node.tombstoned:
                    existing.tombstoned = True
            else:
                self._nodes[nid] = _Node(
                    id=node.id,
                    parent=node.parent,
                    element=node.element,
                    tombstoned=node.tombstoned,
                )

        # Per-replica counter max.
        for replica, counter in other._counters.items():
            if counter > self._counters.get(replica, 0):
                self._counters[replica] = counter
        # Ensure our own fresh-id counter keeps marching forward so we
        # never reissue an id after merging.
        self._counter = max(
            self._counter, self._counters.get(self._replica_id, 0)
        )

        self._rebuild_order()

    # ------------------------------------------------------------------
    # Internal ordering
    # ------------------------------------------------------------------
    def _visible_ids(self) -> list[NodeId]:
        """Return the ordered list of node ids whose elements are visible."""
        return [nid for nid in self._order if not self._nodes[nid].tombstoned]

    def _rebuild_order(self) -> None:
        """Recompute ``self._order`` from the parent tree via pre-order DFS.

        Children of the same parent are traversed in descending id order
        (lexicographic on ``(replica_id, counter)``) so that newer
        writes appear closer to the parent's position in the final
        sequence. This is the standard RGA sibling-ordering rule and is
        crucial for deterministic convergence of concurrent inserts.
        """
        children: dict[NodeId | None, list[NodeId]] = {}
        for nid, node in self._nodes.items():
            children.setdefault(node.parent, []).append(nid)

        order: list[NodeId] = []
        # Iterative pre-order DFS (recursion tripped the default
        # recursion limit on long documents during stress tests). We
        # want children emitted in descending id order, so we push each
        # sibling list in ascending order -- ``stack.pop()`` then yields
        # the largest id first.
        stack: list[NodeId] = sorted(children.get(None, []))
        while stack:
            nid = stack.pop()
            order.append(nid)
            kids = children.get(nid, [])
            if kids:
                for child in sorted(kids):
                    stack.append(child)

        self._order = order

        # Validate every non-root parent is known -- defensive check that
        # catches malformed inputs from ``from_dict``. Nodes whose parent
        # is missing from ``self._nodes`` are left out of ``order``, so
        # we detect the omission by size.
        if len(order) != len(self._nodes):
            missing = [
                nid
                for nid in self._nodes
                if nid not in set(order)
            ]
            raise ValueError(
                "RGA has nodes with unknown parents: " f"{missing!r}"
            )

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------
    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-safe dict representation.

        Nodes are serialized in canonical order so the output is stable
        across runs with the same state.
        """
        nodes_serialized: list[dict[str, Any]] = []
        for nid in sorted(self._nodes.keys()):
            node = self._nodes[nid]
            nodes_serialized.append(
                {
                    "id": [node.id[0], node.id[1]],
                    "parent": (
                        None
                        if node.parent is None
                        else [node.parent[0], node.parent[1]]
                    ),
                    "element": node.element,
                    "tombstoned": node.tombstoned,
                }
            )
        return {
            "replica_id": self._replica_id,
            "counter": self._counter,
            "counters": dict(self._counters),
            "order": [[nid[0], nid[1]] for nid in self._order],
            "nodes": nodes_serialized,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> RGA:
        """Rebuild an :class:`RGA` from the output of :meth:`to_dict`."""
        if not isinstance(d, dict):
            raise TypeError("from_dict expects a dict")
        for key in ("replica_id", "counter", "nodes"):
            if key not in d:
                raise ValueError(f"missing key {key!r} in RGA dict")
        replica_id = d["replica_id"]
        _validate_replica_id(replica_id)
        rga = cls(replica_id)

        counter = d["counter"]
        if not isinstance(counter, int) or isinstance(counter, bool) or counter < 0:
            raise ValueError("counter must be a non-negative int")
        rga._counter = counter

        counters_raw = d.get("counters", {})
        if not isinstance(counters_raw, dict):
            raise TypeError("counters must be a dict")
        counters: dict[str, int] = {}
        for replica, value in counters_raw.items():
            if not isinstance(replica, str) or replica == "":
                raise ReplicaError("counter replica id must be non-empty str")
            if not isinstance(value, int) or isinstance(value, bool) or value < 0:
                raise ValueError("counter values must be non-negative int")
            counters[replica] = value
        rga._counters = counters
        # Keep the local counter ahead of the observed per-replica max so
        # we never mint a duplicate id.
        rga._counter = max(
            rga._counter, rga._counters.get(rga._replica_id, 0)
        )

        raw_nodes = d["nodes"]
        if not isinstance(raw_nodes, (list, tuple)):
            raise TypeError("nodes must be a list")
        for item in raw_nodes:
            if not isinstance(item, dict):
                raise TypeError("each node must be a dict")
            for key in ("id", "parent", "element", "tombstoned"):
                if key not in item:
                    raise ValueError(f"node missing key {key!r}")
            id_raw = item["id"]
            if not (isinstance(id_raw, (list, tuple)) and len(id_raw) == 2):
                raise TypeError("node id must be a 2-element list")
            node_id: NodeId = (id_raw[0], id_raw[1])
            if not isinstance(node_id[0], str) or node_id[0] == "":
                raise ReplicaError("node id replica must be non-empty str")
            if not isinstance(node_id[1], int) or isinstance(node_id[1], bool):
                raise TypeError("node id counter must be int")
            parent_raw = item["parent"]
            parent_id: NodeId | None
            if parent_raw is None:
                parent_id = None
            else:
                if not (
                    isinstance(parent_raw, (list, tuple)) and len(parent_raw) == 2
                ):
                    raise TypeError("node parent must be null or 2-element list")
                parent_id = (parent_raw[0], parent_raw[1])
            tombstoned = item["tombstoned"]
            if not isinstance(tombstoned, bool):
                raise TypeError("tombstoned must be bool")
            rga._nodes[node_id] = _Node(
                id=node_id,
                parent=parent_id,
                element=item["element"],
                tombstoned=tombstoned,
            )

        rga._rebuild_order()
        return rga

    # ------------------------------------------------------------------
    # Dunder methods
    # ------------------------------------------------------------------
    def __eq__(self, other: object) -> bool:
        if not isinstance(other, RGA):
            return NotImplemented
        return (
            self._replica_id == other._replica_id
            and self._nodes == other._nodes
            and self._order == other._order
            and self._counter == other._counter
            and self._counters == other._counters
        )

    def __repr__(self) -> str:
        return (
            f"RGA(replica_id={self._replica_id!r}, "
            f"len={len(self)}, order={self._order!r})"
        )

    __hash__ = None  # type: ignore[assignment]
