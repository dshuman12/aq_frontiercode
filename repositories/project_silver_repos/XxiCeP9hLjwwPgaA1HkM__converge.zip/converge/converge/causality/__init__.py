"""Causality-tracking primitives used throughout converge.

This subpackage exposes :class:`VectorClock`,
:class:`DottedVersionVector`, and :class:`IntervalTreeClock`, which are
the building blocks for any CRDT that needs to reason about the
happens-before relation between events originating on different
replicas. Pick a vector clock for fixed replica sets, a DVV when the
CRDT needs dot-level precision (MV-Register, OR-Set), or an ITC when
the replica set grows and shrinks at runtime.
"""

from __future__ import annotations

from .dotted_version_vector import DottedVersionVector
from .itc import IntervalTreeClock
from .vector_clock import VectorClock

__all__ = ["VectorClock", "DottedVersionVector", "IntervalTreeClock"]
