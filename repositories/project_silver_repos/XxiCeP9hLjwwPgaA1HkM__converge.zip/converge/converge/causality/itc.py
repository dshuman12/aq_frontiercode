"""Interval Tree Clock (ITC) causality primitive.

ITCs are the Almeida/Baquero/Fonte compact alternative to vector clocks:
a stamp carries an ``id`` (a subset of the interval ``[0, 1]`` encoded as
a binary tree) that identifies the owning replica and an ``event`` tree
that records observed events. Unlike vector clocks, ids are dynamic --
a stamp may be :meth:`fork`-ed to spawn a new replica or re-absorbed via
:meth:`join`, which makes ITCs well suited to systems whose replica set
grows and shrinks over time. Event trees grow lazily and collapse in
regions that are already covered by the id, giving sub-linear size in
practice compared to an ever-growing vector of replica counters.
"""

from __future__ import annotations

from typing import Any

from ..errors import ConvergeError


# ---------------------------------------------------------------------------
# Tree representation
# ---------------------------------------------------------------------------
#
# ``id`` trees are either:
#   * a leaf ``0`` or ``1`` (a bit), or
#   * a 2-tuple ``(left, right)`` where ``left`` and ``right`` are id trees.
#
# ``event`` trees are either:
#   * a leaf ``n`` (non-negative int) representing a flat count, or
#   * a 3-tuple ``(n, left, right)`` where ``n`` is a base height and
#     ``left``/``right`` are event trees carrying additional height
#     beyond ``n``.
#
# Both kinds of trees have canonical forms; the ``_normalize_*`` helpers
# below collapse equivalent trees down to their canonical representation
# so that ``==`` on raw trees is meaningful.


# ---------------------------------------------------------------------------
# Id-tree helpers
# ---------------------------------------------------------------------------

def _is_id_leaf(node: Any) -> bool:
    """Return ``True`` iff ``node`` is a leaf id (``0`` or ``1``)."""
    return node == 0 or node == 1


def _validate_id(node: Any) -> None:
    """Recursively validate that ``node`` is a well-formed id tree."""
    if _is_id_leaf(node):
        return
    if not (isinstance(node, tuple) and len(node) == 2):
        raise ValueError(f"invalid id subtree: {node!r}")
    _validate_id(node[0])
    _validate_id(node[1])


def _normalize_id(node: Any) -> Any:
    """Collapse an id tree to its canonical form.

    ``(0, 0) -> 0`` and ``(1, 1) -> 1``. Internal subtrees are
    normalized bottom-up so that structurally equal ids compare equal
    regardless of the order in which they were built.
    """
    if _is_id_leaf(node):
        return node
    left = _normalize_id(node[0])
    right = _normalize_id(node[1])
    if left == 0 and right == 0:
        return 0
    if left == 1 and right == 1:
        return 1
    return (left, right)


def _sum_id(a: Any, b: Any) -> Any:
    """Merge two disjoint id trees into a single id tree.

    Summing is commutative and associative. The stamps being summed are
    expected to have disjoint id regions (which is the invariant
    maintained by :meth:`fork` / :meth:`join`); overlap is treated as
    already-owned territory and produces a ``1`` leaf at that position.
    """
    if a == 0:
        return b
    if b == 0:
        return a
    # Overlap -- degenerate but preserve union semantics.
    if a == 1 or b == 1:
        return 1
    # Both are 2-tuples at this point.
    left = _sum_id(a[0], b[0])
    right = _sum_id(a[1], b[1])
    return _normalize_id((left, right))


def _split_id(node: Any) -> tuple[Any, Any]:
    """Split an id tree into two non-overlapping halves.

    This is the core of :meth:`fork`. The algorithm follows the
    Almeida/Baquero/Fonte recursive definition:

    * ``split(0) -> (0, 0)`` (nothing to split).
    * ``split(1) -> ((1, 0), (0, 1))`` (split the whole interval).
    * ``split((0, r)) -> ((0, sl), (0, sr))`` where ``(sl, sr) = split(r)``.
    * ``split((l, 0)) -> ((sl, 0), (sr, 0))`` where ``(sl, sr) = split(l)``.
    * ``split((l, r)) -> ((l, 0), (0, r))``.
    """
    if node == 0:
        return (0, 0)
    if node == 1:
        return ((1, 0), (0, 1))
    left, right = node
    if left == 0:
        sl, sr = _split_id(right)
        return (_normalize_id((0, sl)), _normalize_id((0, sr)))
    if right == 0:
        sl, sr = _split_id(left)
        return (_normalize_id((sl, 0)), _normalize_id((sr, 0)))
    return (_normalize_id((left, 0)), _normalize_id((0, right)))


def _id_has_one(node: Any) -> bool:
    """Return ``True`` iff the id tree owns any region of ``[0, 1]``."""
    if node == 0:
        return False
    if node == 1:
        return True
    return _id_has_one(node[0]) or _id_has_one(node[1])


# ---------------------------------------------------------------------------
# Event-tree helpers
# ---------------------------------------------------------------------------

def _is_event_leaf(node: Any) -> bool:
    """Return ``True`` iff ``node`` is a flat event leaf (a non-negative int)."""
    return isinstance(node, int) and not isinstance(node, bool) and node >= 0


def _validate_event(node: Any) -> None:
    """Recursively validate that ``node`` is a well-formed event tree."""
    if _is_event_leaf(node):
        return
    if not (isinstance(node, tuple) and len(node) == 3):
        raise ValueError(f"invalid event subtree: {node!r}")
    base, left, right = node
    if not isinstance(base, int) or isinstance(base, bool) or base < 0:
        raise ValueError(f"event base must be non-negative int, got {base!r}")
    _validate_event(left)
    _validate_event(right)


def _event_min(node: Any) -> int:
    """Return the smallest number of events observed at any point in the tree."""
    if _is_event_leaf(node):
        return node
    base, left, right = node
    return base + min(_event_min(left), _event_min(right))


def _event_max(node: Any) -> int:
    """Return the largest number of events observed at any point in the tree."""
    if _is_event_leaf(node):
        return node
    base, left, right = node
    return base + max(_event_max(left), _event_max(right))


def _event_lift(node: Any, m: int) -> Any:
    """Add ``m`` to the base of an event tree (shift every count upward by ``m``)."""
    if m == 0:
        return node
    if _is_event_leaf(node):
        return node + m
    base, left, right = node
    return (base + m, left, right)


def _event_sink(node: Any, m: int) -> Any:
    """Subtract ``m`` from the base of an event tree (inverse of :func:`_event_lift`)."""
    if m == 0:
        return node
    if _is_event_leaf(node):
        return node - m
    base, left, right = node
    return (base - m, left, right)


def _normalize_event(node: Any) -> Any:
    """Collapse an event tree to its canonical form.

    ``(n, m, m) -> n + m`` when both sides are equal leaves. Otherwise
    the base is raised by ``min(left, right)`` so that at least one
    subtree touches zero; this keeps serialized trees compact.
    """
    if _is_event_leaf(node):
        return node
    base, left, right = node
    left = _normalize_event(left)
    right = _normalize_event(right)
    if _is_event_leaf(left) and _is_event_leaf(right) and left == right:
        return base + left
    m = min(_event_min(left), _event_min(right))
    if m > 0:
        left = _event_sink(left, m)
        right = _event_sink(right, m)
        base += m
    return (base, left, right)


def _event_join(a: Any, b: Any) -> Any:
    """Point-wise maximum of two event trees; commutative and associative."""
    if _is_event_leaf(a) and _is_event_leaf(b):
        return max(a, b)
    if _is_event_leaf(a):
        # Promote ``a`` into a pseudo-internal node at the same shape as ``b``.
        return _event_join((a, 0, 0), b)
    if _is_event_leaf(b):
        return _event_join(a, (b, 0, 0))
    a_base, a_left, a_right = a
    b_base, b_left, b_right = b
    if a_base > b_base:
        diff = a_base - b_base
        return _normalize_event(
            (
                b_base,
                _event_join(_event_lift(a_left, diff), b_left),
                _event_join(_event_lift(a_right, diff), b_right),
            )
        )
    diff = b_base - a_base
    return _normalize_event(
        (
            a_base,
            _event_join(a_left, _event_lift(b_left, diff)),
            _event_join(a_right, _event_lift(b_right, diff)),
        )
    )


def _event_leq(a: Any, b: Any) -> bool:
    """Return ``True`` iff event tree ``a`` is point-wise ``<=`` event tree ``b``."""
    if _is_event_leaf(a) and _is_event_leaf(b):
        return a <= b
    if _is_event_leaf(a):
        a_base, a_left, a_right = a, 0, 0
    else:
        a_base, a_left, a_right = a
    if _is_event_leaf(b):
        b_base, b_left, b_right = b, 0, 0
    else:
        b_base, b_left, b_right = b
    if a_base > b_base:
        return False
    # If ``a_base < b_base`` we need every point in ``a`` to stay below
    # ``b``; compensate by lifting the ``b`` subtrees less than we lifted
    # ``a``. We reduce to the tree-with-equal-base case first.
    if a_base < b_base:
        diff = b_base - a_base
        b_left = _event_lift(b_left, diff)
        b_right = _event_lift(b_right, diff)
    return _event_leq(a_left, b_left) and _event_leq(a_right, b_right)


def _event_fill(id_node: Any, ev: Any) -> Any:
    """Collapse event-tree regions fully covered by the id into a flat max.

    The idea: wherever the id has a ``1`` leaf, every future event must
    happen in that region, so the event tree's detail there can be
    flattened to ``event_max`` of that subtree without losing any
    information for causal comparison. This keeps event trees small.
    """
    if id_node == 0:
        return ev
    if id_node == 1:
        if _is_event_leaf(ev):
            return ev
        return _event_max(ev)
    if _is_event_leaf(ev):
        return ev
    base, left, right = ev
    id_left, id_right = id_node
    # When one side is fully owned, flatten that side.
    new_left = _event_fill(id_left, left)
    new_right = _event_fill(id_right, right)
    # If one side is a whole-owned leaf we can try to pull it into the base.
    if id_left == 1 and _is_event_leaf(new_left):
        new_right = _event_join(new_right, new_left)
    if id_right == 1 and _is_event_leaf(new_right):
        new_left = _event_join(new_left, new_right)
    return _normalize_event((base, new_left, new_right))


def _event_grow(id_node: Any, ev: Any) -> tuple[Any, int]:
    """Grow the event tree in a region covered by the id tree.

    Returns ``(new_event, cost)`` where ``cost`` is a rough measure of
    how much tree-depth the growth added; the caller picks the lowest
    cost option at each level. This mirrors the grow function from the
    ITC paper but simplified -- we do not attempt to pick between
    competing candidate growths beyond the obvious "prefer a shallower
    tree" heuristic because correctness does not depend on it.
    """
    if _is_event_leaf(ev):
        if id_node == 1:
            # Just bump the leaf.
            return ev + 1, 0
        # Turn the leaf into an internal node, then recurse.
        grown, cost = _event_grow(id_node, (ev, 0, 0))
        return grown, cost + 1000  # heavy penalty for deepening
    base, left, right = ev
    if id_node == 0:
        # Nothing of ours to grow here -- should not happen for a
        # non-anonymous stamp, but be safe.
        raise ConvergeError("event_grow called with id == 0")
    id_left, id_right = id_node
    if id_left == 0:
        new_right, cost = _event_grow(id_right, right)
        return _normalize_event((base, left, new_right)), cost + 1
    if id_right == 0:
        new_left, cost = _event_grow(id_left, left)
        return _normalize_event((base, new_left, right)), cost + 1
    # Both sides are non-zero: try both and pick the cheaper.
    left_grown, cost_l = _event_grow(id_left, left)
    right_grown, cost_r = _event_grow(id_right, right)
    if cost_l <= cost_r:
        return _normalize_event((base, left_grown, right)), cost_l + 1
    return _normalize_event((base, left, right_grown)), cost_r + 1


# ---------------------------------------------------------------------------
# Serialization helpers
# ---------------------------------------------------------------------------

def _id_to_json(node: Any) -> Any:
    """Serialize an id tree to a JSON-safe structure (``int`` or ``list``)."""
    if _is_id_leaf(node):
        return node
    return [_id_to_json(node[0]), _id_to_json(node[1])]


def _id_from_json(obj: Any) -> Any:
    """Rehydrate an id tree from :func:`_id_to_json` output."""
    if obj == 0 or obj == 1:
        return obj
    if isinstance(obj, list) and len(obj) == 2:
        return _normalize_id((_id_from_json(obj[0]), _id_from_json(obj[1])))
    raise ValueError(f"invalid serialized id: {obj!r}")


def _event_to_json(node: Any) -> Any:
    """Serialize an event tree to a JSON-safe structure."""
    if _is_event_leaf(node):
        return node
    base, left, right = node
    return [base, _event_to_json(left), _event_to_json(right)]


def _event_from_json(obj: Any) -> Any:
    """Rehydrate an event tree from :func:`_event_to_json` output."""
    if _is_event_leaf(obj):
        return obj
    if isinstance(obj, list) and len(obj) == 3:
        base = obj[0]
        if not isinstance(base, int) or isinstance(base, bool) or base < 0:
            raise ValueError(f"invalid event base: {base!r}")
        return _normalize_event(
            (base, _event_from_json(obj[1]), _event_from_json(obj[2]))
        )
    raise ValueError(f"invalid serialized event: {obj!r}")


# ---------------------------------------------------------------------------
# Public ITC class
# ---------------------------------------------------------------------------

class IntervalTreeClock:
    """Compact ITC stamp carrying an id interval and an event history.

    An ITC is mutated in place by :meth:`event` and :meth:`join`; it is
    split by :meth:`fork`. Equality compares the canonical (id, event)
    pair. The class intentionally offers no ``__hash__`` because it is
    mutable, mirroring the other CRDT types in the library.

    The classic operation sequence looks like::

        a = IntervalTreeClock.seed()
        a, b = a.fork()      # spawn a second replica
        a.event()             # record an event on ``a``
        b.event()             # record a concurrent event on ``b``
        assert a.is_concurrent_with(b)
        a.join(b)             # absorb ``b`` back into ``a``
    """

    __slots__ = ("_id", "_event")

    def __init__(self, id_tree: Any = 1, event_tree: Any = 0) -> None:
        """Build a stamp from raw id and event trees (advanced -- prefer :meth:`seed`)."""
        _validate_id(id_tree)
        _validate_event(event_tree)
        self._id = _normalize_id(id_tree)
        self._event = _normalize_event(event_tree)

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------
    @classmethod
    def seed(cls) -> IntervalTreeClock:
        """Return the seed stamp ``(id=1, event=0)`` that owns the whole interval."""
        return cls(1, 0)

    def clone(self) -> IntervalTreeClock:
        """Return a deep (structural) copy of this stamp."""
        return IntervalTreeClock(self._id, self._event)

    # ------------------------------------------------------------------
    # Accessors
    # ------------------------------------------------------------------
    @property
    def id_tree(self) -> Any:
        """Return the canonical id tree (read-only view of the underlying structure)."""
        return self._id

    @property
    def event_tree(self) -> Any:
        """Return the canonical event tree (read-only view)."""
        return self._event

    # ------------------------------------------------------------------
    # ITC operations
    # ------------------------------------------------------------------
    def fork(self) -> tuple[IntervalTreeClock, IntervalTreeClock]:
        """Split this stamp into two independent stamps.

        The event history is copied to both sides; the id is split into
        two disjoint sub-intervals using the recursive Almeida/Baquero
        algorithm. Neither returned stamp is the same object as
        ``self``; the caller is expected to discard ``self`` after fork.
        """
        id_left, id_right = _split_id(self._id)
        return (
            IntervalTreeClock(id_left, self._event),
            IntervalTreeClock(id_right, self._event),
        )

    def peek(self) -> IntervalTreeClock:
        """Return a read-only observer stamp (``id=0``) with the same event tree."""
        return IntervalTreeClock(0, self._event)

    def event(self) -> None:
        """Record a new event in the region owned by this stamp.

        We first try :func:`_event_fill` -- which can extend the event
        tree for free by collapsing regions already fully owned -- and
        fall back to :func:`_event_grow` only if fill did not change
        the observable maximum. Raises :class:`ConvergeError` if the
        stamp is anonymous (``id == 0``) and therefore owns no region
        in which an event could be recorded.
        """
        if not _id_has_one(self._id):
            raise ConvergeError("cannot record an event on a stamp with id=0")
        filled = _event_fill(self._id, self._event)
        if _event_max(filled) > _event_max(self._event):
            self._event = filled
            return
        grown, _cost = _event_grow(self._id, self._event)
        self._event = grown

    def join(self, other: IntervalTreeClock) -> None:
        """Merge ``other`` into ``self`` in place.

        The id is summed (disjoint union of owned intervals) and the
        event trees are point-wise maximized. Typically used on
        decommission: when a replica leaves, its stamp is joined back
        into a surviving peer so the interval it owned is not lost.
        """
        if not isinstance(other, IntervalTreeClock):
            raise TypeError(
                "can only join IntervalTreeClock with IntervalTreeClock"
            )
        self._id = _sum_id(self._id, other._id)
        self._event = _event_join(self._event, other._event)
        self._event = _normalize_event(self._event)

    # ------------------------------------------------------------------
    # Causal comparisons
    # ------------------------------------------------------------------
    def leq(self, other: IntervalTreeClock) -> bool:
        """Return ``True`` iff every event in ``self`` is covered by ``other``."""
        if not isinstance(other, IntervalTreeClock):
            raise TypeError(
                "can only compare IntervalTreeClock with IntervalTreeClock"
            )
        return _event_leq(self._event, other._event)

    def is_concurrent_with(self, other: IntervalTreeClock) -> bool:
        """Return ``True`` iff neither stamp's events are ordered before the other."""
        if not isinstance(other, IntervalTreeClock):
            raise TypeError(
                "can only compare IntervalTreeClock with IntervalTreeClock"
            )
        return not self.leq(other) and not other.leq(self)

    def happens_before(self, other: IntervalTreeClock) -> bool:
        """Return ``True`` iff ``self`` strictly happens-before ``other``."""
        if not isinstance(other, IntervalTreeClock):
            raise TypeError(
                "can only compare IntervalTreeClock with IntervalTreeClock"
            )
        return self.leq(other) and not other.leq(self)

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------
    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-safe ``{id, event}`` dict for this stamp."""
        return {
            "id": _id_to_json(self._id),
            "event": _event_to_json(self._event),
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> IntervalTreeClock:
        """Rebuild an :class:`IntervalTreeClock` from :meth:`to_dict` output."""
        if not isinstance(d, dict):
            raise TypeError("from_dict expects a dict")
        if "id" not in d or "event" not in d:
            raise ValueError("from_dict expects keys 'id' and 'event'")
        return cls(_id_from_json(d["id"]), _event_from_json(d["event"]))

    # ------------------------------------------------------------------
    # Dunder methods
    # ------------------------------------------------------------------
    def __eq__(self, other: object) -> bool:
        if not isinstance(other, IntervalTreeClock):
            return NotImplemented
        return self._id == other._id and self._event == other._event

    def __repr__(self) -> str:
        return (
            f"IntervalTreeClock(id={self._id!r}, event={self._event!r})"
        )

    __hash__ = None  # type: ignore[assignment]
