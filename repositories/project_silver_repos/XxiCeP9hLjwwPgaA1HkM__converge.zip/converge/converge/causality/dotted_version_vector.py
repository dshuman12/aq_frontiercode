"""Dotted version vector (DVV) for tracking observed causal events.

A :class:`DottedVersionVector` is a vector clock augmented with a set of
"dots" -- ``(replica_id, counter)`` pairs that have been observed but are
not yet contiguous with the per-replica base prefix. When a dot fills the
next expected slot for a replica the dot is *compacted* into the base,
which may cascade to higher-numbered dots. This structure lets CRDTs
such as :class:`MVRegister` and :class:`ORSet` precisely track which
individual writes are still live.
"""

from __future__ import annotations

from typing import Any

from ..errors import ReplicaError


def _validate_replica_id(replica_id: Any) -> None:
    """Raise :class:`ReplicaError` if ``replica_id`` is not a non-empty string."""
    if not isinstance(replica_id, str) or replica_id == "":
        raise ReplicaError("replica_id must be a non-empty string")


def _validate_counter(counter: Any) -> None:
    """Raise ``ValueError``/``TypeError`` unless ``counter`` is a positive int."""
    if not isinstance(counter, int) or isinstance(counter, bool):
        raise TypeError("counter must be int")
    if counter < 1:
        raise ValueError("counter must be >= 1")


class DottedVersionVector:
    """Dotted version vector combining a contiguous base with out-of-order dots.

    The invariant maintained at all times is:

    * ``base[r]`` is the largest ``n`` such that every counter in
      ``1..n`` for replica ``r`` has been observed.
    * ``dots`` contains only pairs ``(r, c)`` with ``c > base.get(r, 0)``.

    Therefore no counter is represented in both ``base`` and ``dots``.
    """

    __slots__ = ("_base", "_dots")

    def __init__(
        self,
        base: dict[str, int] | None = None,
        dots: set[tuple[str, int]] | None = None,
    ) -> None:
        """Create a DVV, optionally seeded with a base dict and a set of dots."""
        self._base: dict[str, int] = {}
        self._dots: set[tuple[str, int]] = set()

        if base is not None:
            if not isinstance(base, dict):
                raise TypeError("base must be a dict[str, int] or None")
            for replica, value in base.items():
                _validate_replica_id(replica)
                if not isinstance(value, int) or isinstance(value, bool):
                    raise TypeError("base values must be int")
                if value < 0:
                    raise ValueError("base values must be non-negative")
                if value > 0:
                    self._base[replica] = value

        if dots is not None:
            if not isinstance(dots, (set, frozenset, list, tuple)):
                raise TypeError("dots must be a set/list/tuple of (replica, counter)")
            for dot in dots:
                if not (isinstance(dot, tuple) and len(dot) == 2):
                    raise TypeError("each dot must be a (replica_id, counter) tuple")
                replica, counter = dot
                _validate_replica_id(replica)
                _validate_counter(counter)
                self._dots.add((replica, counter))

        # Normalize so the invariant holds even if the caller passed dots
        # that are already covered by or contiguous with the base.
        self._compact_all()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------
    def _compact_replica(self, replica: str) -> None:
        """Absorb any dots that are contiguous with ``base[replica]`` into the base.

        Compaction cascades: once ``base`` advances by one, the next
        counter may already be present in the dot set, so we loop until
        no further chaining is possible.
        """
        current = self._base.get(replica, 0)
        # Repeatedly pull the next expected counter out of the dot set.
        while (replica, current + 1) in self._dots:
            current += 1
            self._dots.remove((replica, current))
        if current > 0:
            self._base[replica] = current

    def _compact_all(self) -> None:
        """Compact every replica that currently has at least one dot or base entry."""
        # Drop any dots already covered by the base (defensive normalization).
        self._dots = {
            (r, c) for (r, c) in self._dots if c > self._base.get(r, 0)
        }
        # Compact per replica; only replicas that could possibly change matter.
        replicas = {r for (r, _c) in self._dots} | set(self._base.keys())
        for replica in replicas:
            self._compact_replica(replica)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def observe(self, replica_id: str, counter: int) -> None:
        """Record that event ``(replica_id, counter)`` has been observed.

        If ``counter`` extends the contiguous base for ``replica_id`` the
        base is advanced and any previously-held dots that now chain onto
        the new base are cascaded in as well.
        """
        _validate_replica_id(replica_id)
        _validate_counter(counter)

        base = self._base.get(replica_id, 0)
        if counter <= base:
            # Already covered by the base; nothing to do.
            return

        # Always stage the dot, then let compaction decide its fate.
        self._dots.add((replica_id, counter))
        self._compact_replica(replica_id)

    def next_dot(self, replica_id: str) -> tuple[str, int]:
        """Extend the base for ``replica_id`` and return the fresh ``(replica_id, counter)``.

        This is the local operation used by a replica to mint a new event
        id; because the new counter is by construction contiguous with the
        existing base we advance the base directly rather than staging a
        dot.
        """
        _validate_replica_id(replica_id)
        new_counter = self._base.get(replica_id, 0) + 1
        self._base[replica_id] = new_counter
        # A dot could have been observed out of order earlier; the fresh
        # counter may now chain further compaction.
        self._compact_replica(replica_id)
        return (replica_id, new_counter)

    def contains_dot(self, replica_id: str, counter: int) -> bool:
        """Return ``True`` iff ``(replica_id, counter)`` has been observed."""
        _validate_replica_id(replica_id)
        _validate_counter(counter)
        if counter <= self._base.get(replica_id, 0):
            return True
        return (replica_id, counter) in self._dots

    def merge(self, other: DottedVersionVector) -> None:
        """Merge ``other`` into ``self`` by taking per-replica max of bases and unioning dots."""
        if not isinstance(other, DottedVersionVector):
            raise TypeError(
                "can only merge DottedVersionVector with DottedVersionVector"
            )
        for replica, value in other._base.items():
            if value > self._base.get(replica, 0):
                self._base[replica] = value
        self._dots.update(other._dots)
        self._compact_all()

    # ------------------------------------------------------------------
    # Accessors (read-only views for CRDTs built on top of DVV)
    # ------------------------------------------------------------------
    @property
    def base(self) -> dict[str, int]:
        """Return a copy of the contiguous base mapping."""
        return dict(self._base)

    @property
    def dots(self) -> set[tuple[str, int]]:
        """Return a copy of the non-contiguous dot set."""
        return set(self._dots)

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------
    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-safe dict representation (dots become ``[replica, counter]`` lists)."""
        return {
            "base": dict(self._base),
            "dots": sorted([[r, c] for (r, c) in self._dots]),
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> DottedVersionVector:
        """Rebuild a DVV from the output of :meth:`to_dict`."""
        if not isinstance(d, dict):
            raise TypeError("from_dict expects a dict")
        base = d.get("base", {})
        raw_dots = d.get("dots", [])
        if not isinstance(raw_dots, (list, tuple, set, frozenset)):
            raise TypeError("from_dict expects 'dots' to be a list/tuple/set")
        dots: set[tuple[str, int]] = set()
        for item in raw_dots:
            if isinstance(item, (list, tuple)) and len(item) == 2:
                dots.add((item[0], item[1]))
            else:
                raise TypeError("each dot entry must be a 2-element list/tuple")
        return cls(base=base, dots=dots)

    # ------------------------------------------------------------------
    # Dunder methods
    # ------------------------------------------------------------------
    def __eq__(self, other: object) -> bool:
        if not isinstance(other, DottedVersionVector):
            return NotImplemented
        return self._base == other._base and self._dots == other._dots

    def __repr__(self) -> str:
        base_items = ", ".join(
            f"{r!r}: {c}" for r, c in sorted(self._base.items())
        )
        dot_items = ", ".join(
            f"({r!r}, {c})" for (r, c) in sorted(self._dots)
        )
        return f"DottedVersionVector(base={{{base_items}}}, dots={{{dot_items}}})"

    __hash__ = None  # type: ignore[assignment]
