"""Vector clock for tracking causal history across replicas.

A :class:`VectorClock` maps ``replica_id -> non-negative int``. It captures
the happens-before partial order between events: event A happens-before
event B iff A's clock is component-wise less-than-or-equal to B's clock
and strictly less on at least one component. Two clocks that are neither
equal nor ordered are *concurrent*. Merge is component-wise maximum,
which is idempotent, commutative, and associative.
"""

from __future__ import annotations

from typing import Any

from ..errors import ReplicaError


def _validate_replica_id(replica_id: Any) -> None:
    """Raise :class:`ReplicaError` if ``replica_id`` is not a non-empty string."""
    if not isinstance(replica_id, str) or replica_id == "":
        raise ReplicaError("replica_id must be a non-empty string")


class VectorClock:
    """Component-wise vector clock keyed by replica id.

    Missing replicas are treated as having count ``0``. Two clocks compare
    equal when every replica that appears in either side has the same
    count on both sides.
    """

    __slots__ = ("_counts",)

    def __init__(self, counts: dict[str, int] | None = None) -> None:
        """Create a vector clock, optionally seeded from a ``{replica_id: count}`` dict."""
        self._counts: dict[str, int] = {}
        if counts is None:
            return
        if not isinstance(counts, dict):
            raise TypeError("counts must be a dict[str, int] or None")
        for replica, count in counts.items():
            _validate_replica_id(replica)
            if not isinstance(count, int) or isinstance(count, bool):
                raise TypeError("vector clock counts must be int")
            if count < 0:
                raise ValueError("vector clock counts must be non-negative")
            if count > 0:
                # Drop zero-valued keys so equal clocks have identical dicts.
                self._counts[replica] = count

    # ------------------------------------------------------------------
    # Accessors
    # ------------------------------------------------------------------
    def get(self, replica_id: str) -> int:
        """Return the count for ``replica_id`` (``0`` if the replica is unknown)."""
        _validate_replica_id(replica_id)
        return self._counts.get(replica_id, 0)

    def replicas(self) -> frozenset[str]:
        """Return the set of replica ids currently tracked with a non-zero count."""
        return frozenset(self._counts.keys())

    # ------------------------------------------------------------------
    # Mutation
    # ------------------------------------------------------------------
    def increment(self, replica_id: str) -> None:
        """Increment the counter for ``replica_id`` by one (creating it if needed)."""
        _validate_replica_id(replica_id)
        self._counts[replica_id] = self._counts.get(replica_id, 0) + 1

    def merge(self, other: VectorClock) -> None:
        """Merge ``other`` into ``self`` via component-wise maximum (in place)."""
        if not isinstance(other, VectorClock):
            raise TypeError("can only merge VectorClock with VectorClock")
        for replica, count in other._counts.items():
            if count > self._counts.get(replica, 0):
                self._counts[replica] = count

    # ------------------------------------------------------------------
    # Causal comparisons
    # ------------------------------------------------------------------
    def descends(self, other: VectorClock) -> bool:
        """Return ``True`` iff ``self[r] >= other[r]`` for every replica ``r``.

        Missing replicas default to ``0``. By this definition every clock
        descends the empty clock, and a clock descends itself.
        """
        if not isinstance(other, VectorClock):
            raise TypeError("can only compare VectorClock with VectorClock")
        for replica, other_count in other._counts.items():
            if self._counts.get(replica, 0) < other_count:
                return False
        return True

    def dominates(self, other: VectorClock) -> bool:
        """Return ``True`` iff ``self`` descends ``other`` and they are not equal."""
        return self.descends(other) and self != other

    def is_concurrent_with(self, other: VectorClock) -> bool:
        """Return ``True`` iff ``self`` and ``other`` are causally incomparable."""
        if not isinstance(other, VectorClock):
            raise TypeError("can only compare VectorClock with VectorClock")
        return not self.descends(other) and not other.descends(self)

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------
    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-safe dict representation of this vector clock."""
        return {"counts": dict(self._counts)}

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> VectorClock:
        """Rebuild a :class:`VectorClock` from the output of :meth:`to_dict`."""
        if not isinstance(d, dict):
            raise TypeError("from_dict expects a dict")
        counts = d.get("counts", {})
        if not isinstance(counts, dict):
            raise TypeError("from_dict expects 'counts' to be a dict")
        return cls(counts)

    # ------------------------------------------------------------------
    # Dunder methods
    # ------------------------------------------------------------------
    def __eq__(self, other: object) -> bool:
        if not isinstance(other, VectorClock):
            return NotImplemented
        return self._counts == other._counts

    def __repr__(self) -> str:
        items = ", ".join(f"{r!r}: {c}" for r, c in sorted(self._counts.items()))
        return f"VectorClock({{{items}}})"

    # Mutable containers should not be hashable.
    __hash__ = None  # type: ignore[assignment]
