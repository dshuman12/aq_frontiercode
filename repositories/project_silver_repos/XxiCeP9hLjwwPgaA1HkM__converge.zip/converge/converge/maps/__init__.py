"""Map CRDTs: observed-remove and last-writer-wins dictionaries.

This subpackage exposes two key/value CRDTs that mirror the semantics
of the element-oriented CRDTs found elsewhere in ``converge``:
:class:`ORMap` generalises :class:`~converge.sets.ORSet` to carry
arbitrary values per key, while :class:`LWWMap` applies the
``(ts, writer)`` resolution rule from
:class:`~converge.registers.LWWRegister` to a whole dictionary.
"""

from __future__ import annotations

from .lwwmap import LWWMap
from .ormap import ORMap

__all__ = ["ORMap", "LWWMap"]
