"""Last-Writer-Wins Map (LWW-Map) CRDT.

An :class:`LWWMap` is a dictionary whose per-key conflicts are resolved
by the same ``(ts, writer)`` lexicographic order used by
:class:`~converge.registers.LWWRegister`. Every ``set`` and ``remove``
stamps the affected key with a timestamp and the local replica id; the
entry with the strictly greater ``(ts, writer)`` wins, and tombstones
are stored in-band as ``is_alive=False`` so that deletions themselves
converge under the same rule. Merges are idempotent, commutative and
associative because the operation per key is simply ``max``.
"""

from __future__ import annotations

from typing import Any, Callable, Hashable

from ..errors import ConvergeError, ReplicaError


def _validate_replica_id(replica_id: Any) -> str:
    """Validate that ``replica_id`` is a non-empty string."""
    if not isinstance(replica_id, str):
        raise ReplicaError(
            f"replica_id must be a str, got {type(replica_id).__name__}"
        )
    if replica_id == "":
        raise ReplicaError("replica_id must be a non-empty string")
    return replica_id


def _validate_ts(ts: Any) -> None:
    """Raise ``TypeError``/``ValueError`` unless ``ts`` is a non-negative int."""
    if not isinstance(ts, int) or isinstance(ts, bool):
        raise TypeError("ts must be int")
    if ts < 0:
        raise ValueError("ts must be non-negative")


class LWWMap:
    """Last-Writer-Wins map keyed by ``(ts, writer)`` order.

    Entries take the form ``(ts, writer, value, is_alive)``. ``set``
    installs a live entry; ``remove`` installs a tombstone entry with
    ``is_alive=False``. Either operation is ignored if its
    ``(ts, writer)`` does not strictly exceed the currently stored
    tuple. Because the comparison is a total order, two replicas that
    have seen the same set of writes always produce equal state.
    """

    __hash__ = None  # mutable; opt out of default hashing

    def __init__(
        self,
        replica_id: str,
        clock: Callable[[], int] | None = None,
    ) -> None:
        """Create an empty LWW-Map owned by ``replica_id``.

        ``clock`` is an optional zero-arg callable returning the next
        timestamp to use when ``set``/``remove`` is invoked without an
        explicit ``ts``. The default is an internal monotonic counter
        bumped on every auto-allocation, kept above every ``ts`` the
        replica has observed so that fresh writes dominate history.
        """
        self.replica_id = _validate_replica_id(replica_id)
        if clock is not None and not callable(clock):
            raise TypeError("clock must be callable returning int")
        self._clock_fn: Callable[[], int] | None = clock
        self._clock: int = 0
        # entries[key] = (ts, writer, value, is_alive)
        self.entries: dict[Hashable, tuple[int, str, Any, bool]] = {}

    # ------------------------------------------------------------------ #
    # Mutations
    # ------------------------------------------------------------------ #
    def set(self, key: Hashable, value: Any, ts: int | None = None) -> None:
        """Write ``value`` at ``(ts, self.replica_id)``.

        When ``ts`` is ``None`` it is drawn from the injected clock (or
        the internal monotonic counter, which is always advanced past
        any timestamp the replica has seen). The write is committed
        only when ``(new_ts, self.replica_id)`` exceeds the currently
        stored tuple for the key.
        """
        self._check_hashable(key)
        new_ts = self._allocate_ts(ts)
        self._install(key, new_ts, self.replica_id, value, True)

    def remove(self, key: Hashable, ts: int | None = None) -> None:
        """Tombstone ``key`` at ``(ts, self.replica_id)``.

        Unlike observed-remove CRDTs, ``remove`` does not require the
        key to currently be live: a later ``set`` with a larger
        ``(ts, writer)`` will still win, and a concurrent ``set`` with
        a smaller tuple will be shadowed by this tombstone.
        """
        self._check_hashable(key)
        new_ts = self._allocate_ts(ts)
        self._install(key, new_ts, self.replica_id, None, False)

    # ------------------------------------------------------------------ #
    # Observations
    # ------------------------------------------------------------------ #
    def get(self, key: Hashable, default: Any = None) -> Any:
        """Return the live value for ``key`` or ``default`` when absent/tombstoned."""
        self._check_hashable(key)
        entry = self.entries.get(key)
        if entry is None:
            return default
        _ts, _writer, value, is_alive = entry
        return value if is_alive else default

    def contains(self, key: Hashable) -> bool:
        """Return ``True`` iff ``key`` currently has a live entry."""
        self._check_hashable(key)
        entry = self.entries.get(key)
        return bool(entry and entry[3])

    def keys(self) -> frozenset:
        """Return the frozenset of keys with a live entry."""
        return frozenset(
            k for k, (_ts, _w, _v, alive) in self.entries.items() if alive
        )

    def value(self) -> dict[Hashable, Any]:
        """Return the live state as a plain ``{key: value}`` dict."""
        return {
            k: v
            for k, (_ts, _w, v, alive) in self.entries.items()
            if alive
        }

    # ------------------------------------------------------------------ #
    # Merge
    # ------------------------------------------------------------------ #
    def merge(self, other: LWWMap) -> None:
        """Merge ``other`` into ``self`` by taking per-key max ``(ts, writer)``."""
        if not isinstance(other, LWWMap):
            raise TypeError(f"cannot merge LWWMap with {type(other).__name__}")

        # Keep the local clock strictly ahead of everything we have ever seen
        # so that a subsequent auto-timestamped write dominates the union.
        highest = self._clock
        for ts, _w, _v, _alive in other.entries.values():
            if ts > highest:
                highest = ts
        highest = max(highest, other._clock)
        self._clock = highest

        for key, entry in other.entries.items():
            ts, writer, value, is_alive = entry
            self._install(key, ts, writer, value, is_alive)

    # ------------------------------------------------------------------ #
    # Serialization
    # ------------------------------------------------------------------ #
    def to_dict(self) -> dict:
        """Return a JSON-safe dict representation of this LWW-Map."""
        return {
            "type": "LWWMap",
            "replica_id": self.replica_id,
            "clock": self._clock,
            "entries": [
                {
                    "key": key,
                    "ts": ts,
                    "writer": writer,
                    "value": value,
                    "is_alive": bool(is_alive),
                }
                for key, (ts, writer, value, is_alive) in self.entries.items()
            ],
        }

    @classmethod
    def from_dict(cls, data: dict) -> LWWMap:
        """Rehydrate an :class:`LWWMap` previously produced by :meth:`to_dict`."""
        if not isinstance(data, dict):
            raise TypeError(f"from_dict expects dict, got {type(data).__name__}")
        if data.get("type") != "LWWMap":
            raise ConvergeError(
                f"from_dict: expected type 'LWWMap', got {data.get('type')!r}"
            )
        instance = cls(data["replica_id"])
        clock = data.get("clock", 0)
        if not isinstance(clock, int) or isinstance(clock, bool):
            raise TypeError("clock must be int")
        if clock < 0:
            raise ValueError("clock must be non-negative")
        instance._clock = clock

        entries: dict[Hashable, tuple[int, str, Any, bool]] = {}
        for item in data.get("entries", []):
            key = item["key"]
            ts = item["ts"]
            writer = item["writer"]
            value = item.get("value")
            is_alive = bool(item.get("is_alive", True))
            _validate_ts(ts)
            if not isinstance(writer, str) or writer == "":
                raise ReplicaError("writer must be a non-empty string")
            entries[key] = (ts, writer, value, is_alive)
        instance.entries = entries
        return instance

    # ------------------------------------------------------------------ #
    # Dunder methods
    # ------------------------------------------------------------------ #
    def __eq__(self, other: object) -> bool:
        if not isinstance(other, LWWMap):
            return NotImplemented
        return self.entries == other.entries

    def __repr__(self) -> str:
        alive_keys = sorted(self.keys(), key=repr)
        tomb_count = sum(
            1 for (_ts, _w, _v, alive) in self.entries.values() if not alive
        )
        return (
            f"LWWMap(replica_id={self.replica_id!r}, "
            f"keys={alive_keys!r}, tombstones={tomb_count})"
        )

    # ------------------------------------------------------------------ #
    # Internal helpers
    # ------------------------------------------------------------------ #
    def _allocate_ts(self, ts: int | None) -> int:
        """Choose the timestamp for a new local write.

        Explicit ``ts`` values advance the internal clock if larger so
        that future auto-allocations dominate; an unspecified ``ts``
        bumps the clock (or defers to the injected callable) and
        returns the resulting value.
        """
        if ts is None:
            if self._clock_fn is not None:
                candidate = self._clock_fn()
                _validate_ts(candidate)
                if candidate > self._clock:
                    self._clock = candidate
                else:
                    self._clock += 1
                return self._clock
            self._clock += 1
            return self._clock
        _validate_ts(ts)
        if ts > self._clock:
            self._clock = ts
        return ts

    def _install(
        self,
        key: Hashable,
        ts: int,
        writer: str,
        value: Any,
        is_alive: bool,
    ) -> None:
        """Install ``(ts, writer, value, is_alive)`` iff it beats the stored tuple."""
        existing = self.entries.get(key)
        if existing is None or (ts, writer) > (existing[0], existing[1]):
            self.entries[key] = (ts, writer, value, is_alive)

    @staticmethod
    def _check_hashable(key: Any) -> None:
        """Ensure ``key`` is hashable; raise ``TypeError`` otherwise."""
        try:
            hash(key)
        except TypeError as exc:
            raise TypeError(
                f"LWWMap keys must be hashable: {key!r}"
            ) from exc
