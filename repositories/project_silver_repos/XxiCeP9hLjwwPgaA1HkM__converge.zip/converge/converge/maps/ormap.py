"""Observed-Remove Map (OR-Map) CRDT.

An :class:`ORMap` generalises :class:`~converge.sets.ORSet` from elements
to key/value pairs: each mutation of a key is tagged with a fresh dot
``(replica_id, counter)`` drawn from a local
:class:`~converge.causality.DottedVersionVector`, and a ``remove`` only
tombstones the dots that this replica has already observed. Concurrent
writes to the same key therefore survive as a multi-valued set until
they are reconciled by a merge, matching the "add-wins" semantic of
OR-Set. Values may be any JSON-serialisable primitive, or a nested CRDT
exposing ``to_dict`` (rehydrated from a ``_crdt_type`` marker).
"""

from __future__ import annotations

from typing import Any, Hashable

from ..causality.dotted_version_vector import DottedVersionVector
from ..errors import ConvergeError, ReplicaError


Dot = tuple[str, int]


def _validate_replica_id(replica_id: Any) -> str:
    """Validate that ``replica_id`` is a non-empty string."""
    if not isinstance(replica_id, str):
        raise ReplicaError(
            f"replica_id must be a str, got {type(replica_id).__name__}"
        )
    if replica_id == "":
        raise ReplicaError("replica_id must be a non-empty string")
    return replica_id


def _dot_from_list(obj: Any) -> Dot:
    """Convert a 2-element list ``[replica, counter]`` into a tuple dot."""
    if not isinstance(obj, (list, tuple)) or len(obj) != 2:
        raise TypeError(f"expected 2-element list for a dot, got {obj!r}")
    replica, counter = obj
    if not isinstance(replica, str):
        raise TypeError(f"dot replica must be str, got {type(replica).__name__}")
    if not isinstance(counter, int) or isinstance(counter, bool):
        raise TypeError(
            f"dot counter must be int, got {type(counter).__name__}"
        )
    return (replica, counter)


def _encode_value(value: Any) -> Any:
    """Serialise a value for :meth:`ORMap.to_dict`.

    Primitive JSON-friendly values are returned as-is. A value that
    exposes ``to_dict`` (i.e. a nested CRDT) is wrapped with a
    ``_crdt_type`` marker so that a registry-aware ``from_dict`` can
    rehydrate it later; the default ``from_dict`` simply round-trips
    the marker back out unchanged.
    """
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    if isinstance(value, list):
        return [_encode_value(v) for v in value]
    if isinstance(value, dict):
        return {str(k): _encode_value(v) for k, v in value.items()}
    to_dict = getattr(value, "to_dict", None)
    if callable(to_dict):
        return {
            "_crdt_type": type(value).__name__,
            "_crdt_data": to_dict(),
        }
    raise TypeError(
        f"ORMap values must be JSON-serialisable or expose to_dict; "
        f"got {type(value).__name__}"
    )


def _decode_value(value: Any) -> Any:
    """Inverse of :func:`_encode_value` for the primitive portion of the tree.

    Wrapped CRDT values are returned as ``{_crdt_type, _crdt_data}``
    dicts: without a CRDT-type registry the map layer cannot know which
    class to instantiate, so the caller is expected to rehydrate these
    markers if they used nested CRDTs.
    """
    if isinstance(value, list):
        return [_decode_value(v) for v in value]
    if isinstance(value, dict):
        if "_crdt_type" in value and "_crdt_data" in value:
            # Preserve the marker for later registry-aware rehydration.
            return {
                "_crdt_type": value["_crdt_type"],
                "_crdt_data": value["_crdt_data"],
            }
        return {k: _decode_value(v) for k, v in value.items()}
    return value


class ORMap:
    """Observed-Remove Map from hashable keys to arbitrary CRDT/primitive values.

    Each key's live state is the list of ``(dot, value)`` pairs that
    have not yet been tombstoned. A local ``set`` supersedes any entry
    whose dot is already contained in this replica's observed context
    (tracked via a :class:`DottedVersionVector`), so sequential writes
    on one replica behave like a normal dictionary; concurrent writes
    on different replicas accumulate as alternatives until merged.
    """

    __hash__ = None  # mutable; opt out of default hashing

    def __init__(self, replica_id: str) -> None:
        """Create an empty OR-Map owned by ``replica_id``."""
        self.replica_id = _validate_replica_id(replica_id)
        self.entries: dict[Hashable, list[tuple[Dot, Any]]] = {}
        self.tombstones: set[Dot] = set()
        self._context: DottedVersionVector = DottedVersionVector()

    # ------------------------------------------------------------------ #
    # Mutations
    # ------------------------------------------------------------------ #
    def set(self, key: Hashable, value: Any) -> None:
        """Associate ``value`` with ``key`` under a fresh local dot.

        Any existing entry for ``key`` whose dot has already been
        observed in this replica's causal context is dropped — this
        replaces our own previous write without disturbing concurrent
        writes from other replicas that are still unobserved here.
        """
        self._check_hashable(key)
        existing = self.entries.get(key, [])
        survivors = [
            (dot, val)
            for (dot, val) in existing
            if not self._context.contains_dot(dot[0], dot[1])
        ]
        new_dot = self._context.next_dot(self.replica_id)
        survivors.append((new_dot, value))
        self.entries[key] = survivors

    def remove(self, key: Hashable) -> None:
        """Tombstone every live dot for ``key``.

        Raises :class:`ConvergeError` when the key has no live entries
        on this replica — the observed-remove contract forbids removing
        what was never observed.
        """
        self._check_hashable(key)
        live = self.entries.get(key)
        if not live:
            raise ConvergeError(f"cannot remove unknown key: {key!r}")
        for dot, _value in live:
            self.tombstones.add(dot)
        self.entries[key] = []

    # ------------------------------------------------------------------ #
    # Observations
    # ------------------------------------------------------------------ #
    def get(self, key: Hashable) -> list[Any]:
        """Return the list of concurrent live values for ``key``.

        The list is empty when the key is absent or fully tombstoned.
        A length > 1 means the key currently has unresolved concurrent
        writes from different replicas; callers are responsible for
        picking a resolution strategy.
        """
        self._check_hashable(key)
        live = self.entries.get(key, [])
        return [value for (_dot, value) in live]

    def contains(self, key: Hashable) -> bool:
        """Return ``True`` iff ``key`` has at least one live entry."""
        self._check_hashable(key)
        return bool(self.entries.get(key))

    def keys(self) -> frozenset:
        """Return the frozenset of keys with at least one live entry."""
        return frozenset(k for k, live in self.entries.items() if live)

    def value(self) -> dict[Hashable, list[Any]]:
        """Return the observed state as ``{key: [value, ...]}``.

        Only keys with live entries appear; each key maps to the list
        of its concurrent live values (usually length 1).
        """
        return {
            k: [v for (_d, v) in live]
            for k, live in self.entries.items()
            if live
        }

    # ------------------------------------------------------------------ #
    # Merge
    # ------------------------------------------------------------------ #
    def merge(self, other: ORMap) -> None:
        """Merge ``other`` into ``self`` in place.

        Tombstones are unioned; for each key we combine both sides'
        entries, drop any whose dot is tombstoned anywhere, then dedup
        by dot so the same dot observed twice contributes once. The
        causal context is merged so future local ``set`` calls supersede
        everything either side had observed.
        """
        if not isinstance(other, ORMap):
            raise TypeError(f"cannot merge ORMap with {type(other).__name__}")

        all_tombstones: set[Dot] = self.tombstones | other.tombstones
        all_keys = set(self.entries.keys()) | set(other.entries.keys())

        merged: dict[Hashable, list[tuple[Dot, Any]]] = {}
        for key in all_keys:
            combined = list(self.entries.get(key, [])) + list(
                other.entries.get(key, [])
            )
            seen_dots: set[Dot] = set()
            kept: list[tuple[Dot, Any]] = []
            for dot, value in combined:
                if dot in all_tombstones:
                    continue
                if dot in seen_dots:
                    continue
                seen_dots.add(dot)
                kept.append((dot, value))
            if kept:
                merged[key] = kept
            # else: drop the key entirely; empty list would lie about liveness

        self.entries = merged
        self.tombstones = all_tombstones
        self._context.merge(other._context)

    # ------------------------------------------------------------------ #
    # Serialization
    # ------------------------------------------------------------------ #
    def to_dict(self) -> dict:
        """Return a JSON-safe dict representation of this OR-Map.

        Dots become 2-element lists; CRDT-valued entries are wrapped in
        a ``{"_crdt_type", "_crdt_data"}`` envelope to preserve their
        identity for registry-aware rehydration.
        """
        entries_out = []
        for key, live in self.entries.items():
            entries_out.append(
                {
                    "key": key,
                    "values": [
                        {"dot": [d[0], d[1]], "value": _encode_value(v)}
                        for (d, v) in live
                    ],
                }
            )
        return {
            "type": "ORMap",
            "replica_id": self.replica_id,
            "entries": entries_out,
            "tombstones": sorted([list(d) for d in self.tombstones]),
            "context": self._context.to_dict(),
        }

    @classmethod
    def from_dict(cls, data: dict) -> ORMap:
        """Rehydrate an :class:`ORMap` previously produced by :meth:`to_dict`."""
        if not isinstance(data, dict):
            raise TypeError(f"from_dict expects dict, got {type(data).__name__}")
        if data.get("type") != "ORMap":
            raise ConvergeError(
                f"from_dict: expected type 'ORMap', got {data.get('type')!r}"
            )
        instance = cls(data["replica_id"])

        entries: dict[Hashable, list[tuple[Dot, Any]]] = {}
        for entry in data.get("entries", []):
            key = entry["key"]
            bucket: list[tuple[Dot, Any]] = []
            for item in entry.get("values", []):
                dot = _dot_from_list(item["dot"])
                value = _decode_value(item["value"])
                bucket.append((dot, value))
            if bucket:
                entries[key] = bucket
        instance.entries = entries
        instance.tombstones = {
            _dot_from_list(d) for d in data.get("tombstones", [])
        }
        ctx = data.get("context")
        if ctx is not None:
            instance._context = DottedVersionVector.from_dict(ctx)
        return instance

    # ------------------------------------------------------------------ #
    # Dunder methods
    # ------------------------------------------------------------------ #
    def __eq__(self, other: object) -> bool:
        if not isinstance(other, ORMap):
            return NotImplemented
        # State equality: tombstones plus live dot->value mappings.
        if self.tombstones != other.tombstones:
            return False
        live_a = {k: v for k, v in self.entries.items() if v}
        live_b = {k: v for k, v in other.entries.items() if v}
        if set(live_a.keys()) != set(live_b.keys()):
            return False
        for key in live_a:
            if sorted(live_a[key], key=lambda p: p[0]) != sorted(
                live_b[key], key=lambda p: p[0]
            ):
                return False
        return True

    def __repr__(self) -> str:
        return (
            f"ORMap(replica_id={self.replica_id!r}, "
            f"keys={sorted(self.keys(), key=repr)!r}, "
            f"tombstones={len(self.tombstones)})"
        )

    # ------------------------------------------------------------------ #
    # Internal helpers
    # ------------------------------------------------------------------ #
    @staticmethod
    def _check_hashable(key: Any) -> None:
        """Ensure ``key`` is hashable; raise ``TypeError`` otherwise."""
        try:
            hash(key)
        except TypeError as exc:
            raise TypeError(
                f"ORMap keys must be hashable: {key!r}"
            ) from exc
