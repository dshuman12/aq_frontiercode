# Pulselog

TypeScript library for parsing, analyzing, and reporting on structured workout logs (strength training, running logs via shared types, CSV/JSON imports).

## Install

Requires Node.js 20+.

```bash
npm install
npm test
```

## Docker

```bash
docker build -t pulselog:dev .
```

## License

MIT — see [LICENSE](./LICENSE).
