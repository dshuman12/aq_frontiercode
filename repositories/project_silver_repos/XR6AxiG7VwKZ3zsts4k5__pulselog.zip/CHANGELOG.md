# Changelog

## 1.0.0 — 2026-05-12

- Initial release: parsers, volume/intensity/progression, recovery, splits, analytics, formatters, validators, comparison, streaks, feature helpers, expanded catalog, statistical utilities.
