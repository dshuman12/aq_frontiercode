import { describe, it, expect } from 'vitest';
import { importSessionFromJson, importSessionsFromJsonArray } from './jsonImport.js';
describe('json', () => {
  it('sess', () => {
    const s = importSessionFromJson({ startedAt:'2026-01-01T00:00:00.000Z', endedAt:'2026-01-01T01:00:00.000Z',
      blocks:[{ exerciseName:'x', sets:[{reps:1,weightKg:1}]}]});
    expect(s.blocks[0]?.sets[0]?.weightKg).toBe(1);
  });
  it('arr', () => expect(importSessionsFromJsonArray('[{"startedAt":"2026-01-01T00:00:00.000Z","endedAt":"2026-01-02T00:00:00.000Z","blocks":[]}]').length).toBe(1));
  for (let i = 0; i < 8; i++) it(`j${i}`, () => expect(importSessionFromJson({startedAt:1,endedAt:2,blocks:[]}).id.length).toBeGreaterThan(0));
});
