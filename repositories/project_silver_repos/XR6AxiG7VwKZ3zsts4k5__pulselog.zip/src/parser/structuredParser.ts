import type { ExerciseBlock, WorkoutSession, WorkoutSet } from '../types/core.js';
import { tokenizeStructuredLog } from './tokenizer.js';

export interface StructuredParseOptions {
  readonly defaultBodyweightKg?: number;
}

function parseSetTokenGroup(tokens: string[]): WorkoutSet[] {
  const sets: WorkoutSet[] = [];
  for (const t of tokens) {
    const m = /^(\d+)x([0-9.]+)(@([0-9.]+))?$/.exec(t);
    if (m) {
      const reps = Number(m[1]);
      const weight = Number(m[2]);
      const rpe = m[4] !== undefined ? Number(m[4]) : undefined;
      sets.push({ reps, weightKg: weight, rpe });
    }
  }
  return sets;
}

export function parseStructuredWorkoutLog(
  text: string,
  options: StructuredParseOptions = {},
): WorkoutSession {
  const lines = tokenizeStructuredLog(text);
  let startedAt = new Date();
  let endedAt = new Date();
  const blocks: ExerciseBlock[] = [];
  const sessionId = 'parsed-session';
  for (const row of lines) {
    const tks = row.tokens.map((t) => (t.kind === 'number' ? String(t.value) : t.kind === 'label' ? t.value : '')).join(' ');
    if (/session|start|end/i.test(tks)) {
      const low = tks.toLowerCase();
      const iso = /(\d{4}-\d{2}-\d{2}T\d{2}:\d{2})/.exec(low)?.[1];
      if (iso) {
        if (low.includes('start')) startedAt = new Date(iso);
        if (low.includes('end')) endedAt = new Date(iso);
      }
      continue;
    }
    const sepIdx = row.tokens.findIndex((t) => t.kind === 'separator' && t.value === ':');
    if (sepIdx <= 0) continue;
    const nameParts = row.tokens.slice(0, sepIdx).filter((t) => t.kind === 'label');
    const exerciseName = nameParts.map((t) => t.value).join(' ');
    const frag: string[] = [];
    for (const t of row.tokens.slice(sepIdx + 1)) {
      if (t.kind === 'number') frag.push(String(t.value));
      else if (t.kind === 'separator' && (t.value === 'x' || t.value === '@')) frag.push(t.value);
    }
    const compact = frag.join('');
    const groups = compact.split(/\s+/).flatMap((piece) =>
      piece
        .split(/(?<=\d)x(?=\d)/)
        .join('x')
        .split(' ')
        .filter(Boolean),
    );
    const parsedSets = parseSetTokenGroup(groups.length ? groups : [compact]);
    const isBw = /\bw\b|bw|bodyweight|pull-up|pullup|dip/i.test(exerciseName);
    const sets: WorkoutSet[] = parsedSets.map((s) => ({
      ...s,
      weightKg: isBw ? (options.defaultBodyweightKg ?? 0) + s.weightKg : s.weightKg,
    }));
    blocks.push({
      exerciseId: exerciseName.toLowerCase().replace(/\s+/g, '-'),
      exerciseName,
      sets,
    });
  }
  return {
    id: sessionId,
    startedAt,
    endedAt,
    blocks,
    bodyweightKg: options.defaultBodyweightKg,
  };
}
