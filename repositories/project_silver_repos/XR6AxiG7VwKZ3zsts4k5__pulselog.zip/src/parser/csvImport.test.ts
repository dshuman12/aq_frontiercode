import { describe, it, expect } from 'vitest';
import { parseWorkoutCsv } from './csvImport.js';
const csv = 'exercise,reps,weightKg\npull-up,5,90\ndeadlift,1,180';
describe('csv', () => {
  it('last line no newline', () => expect(parseWorkoutCsv(csv)[0]?.blocks.some(b=>b.exerciseName==='deadlift')).toBe(true));
  it('sets2', () => expect(parseWorkoutCsv(csv)[0]?.blocks.flatMap(b=>b.sets).length).toBe(2));
  it('semi', () => expect(parseWorkoutCsv('e;r;w\ns;3;100',{delimiter:';'} )[0]?.blocks[0]?.exerciseName).toBe('s'));
  for (let i = 0; i < 8; i++) it(`c${i}`, () => expect(parseWorkoutCsv(csv).length).toBeGreaterThan(0));
});
