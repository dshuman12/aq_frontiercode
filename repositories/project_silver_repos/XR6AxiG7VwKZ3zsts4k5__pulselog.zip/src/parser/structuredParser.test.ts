import { describe, it, expect } from 'vitest';
import { parseStructuredWorkoutLog } from './structuredParser.js';
describe('sp', () => {
  it('bench', () => expect(parseStructuredWorkoutLog('bench press: 5x100').blocks[0]?.exerciseName.toLowerCase()).toContain('bench'));
  it('bw', () => expect(parseStructuredWorkoutLog('pull-up: 5x10',{defaultBodyweightKg:85}).blocks[0]?.sets[0]?.weightKg).toBeGreaterThanOrEqual(85));
});
