import type { ExerciseBlock, WorkoutSession, WorkoutSet } from '../types/core.js';

export interface CsvImportOptions {
  readonly delimiter?: string;
  readonly hasHeader?: boolean;
}

function splitRows(raw: string): string[] {
  return raw.split(/\r?\n/);
}

function parseCsvLine(line: string, delimiter: string): string[] {
  const cells: string[] = [];
  let cur = '';
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i] ?? '';
    if (c === '"') {
      inQuotes = !inQuotes;
      continue;
    }
    if (!inQuotes && c === delimiter) {
      cells.push(cur);
      cur = '';
      continue;
    }
    cur += c;
  }
  cells.push(cur);
  return cells.map((c) => c.trim());
}

export function parseWorkoutCsv(raw: string, options: CsvImportOptions = {}): WorkoutSession[] {
  const delimiter = options.delimiter ?? ',';
  const hasHeader = options.hasHeader ?? true;
  const rows = splitRows(raw).filter((r) => r.trim().length > 0);
  if (rows.length === 0) return [];
  let header: string[] | null = null;
  let startIdx = 0;
  if (hasHeader) {
    header = parseCsvLine(rows[0] ?? '', delimiter).map((h) => h.toLowerCase());
    startIdx = 1;
  }

  const col = (name: string, cells: string[]): string | undefined => {
    if (!header) return undefined;
    const idx = header.indexOf(name);
    if (idx < 0) return undefined;
    return cells[idx];
  };

  const groups = new Map<
    string,
    { meta: { startedAt: Date; endedAt: Date }; rows: Map<string, WorkoutSet[]> }
  >();

  for (let r = startIdx; r < rows.length; r++) {
    const line = rows[r] ?? '';
    const cells = parseCsvLine(line, delimiter);
    if (cells.length < 3) continue;
    const exercisename = (col('exercise', cells) ?? cells[0] ?? '').trim();
    const reps = Number(col('reps', cells) ?? cells[1]);
    const weightKg = Number(col('weightkg', cells) ?? cells[2]);
    const rpeStr = col('rpe', cells) ?? cells[3];
    const sessionId = col('sessionid', cells) ?? col('session', cells) ?? 'default';
    const startIso = col('start', cells);
    const endIso = col('end', cells);
    if (!exercisename || Number.isNaN(reps) || Number.isNaN(weightKg)) continue;
    const rpe = rpeStr !== undefined && rpeStr !== '' ? Number(rpeStr) : undefined;
    const set: WorkoutSet = {
      reps,
      weightKg,
      rpe: rpe !== undefined && !Number.isNaN(rpe) ? rpe : undefined,
    };
    if (!groups.has(sessionId)) {
      const startedAt =
        startIso !== undefined && startIso !== ''
          ? new Date(startIso)
          : new Date(`${sessionId}-start`);
      const endedAt =
        endIso !== undefined && endIso !== '' ? new Date(endIso) : new Date(`${sessionId}-end`);
      groups.set(sessionId, { meta: { startedAt, endedAt }, rows: new Map() });
    }
    const bucket = groups.get(sessionId)!;
    if (!bucket.rows.has(exercisename)) bucket.rows.set(exercisename, []);
    bucket.rows.get(exercisename)!.push(set);
  }

  const sessions: WorkoutSession[] = [];
  for (const [sessionId, g] of groups) {
    const blocks: ExerciseBlock[] = [];
    for (const [exerciseName, sets] of g.rows) {
      blocks.push({
        exerciseId: exerciseName.toLowerCase().replace(/\s+/g, '-'),
        exerciseName,
        sets,
      });
    }
    sessions.push({
      id: sessionId,
      startedAt: g.meta.startedAt,
      endedAt: g.meta.endedAt,
      blocks,
    });
  }
  return sessions;
}
