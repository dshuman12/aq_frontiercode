import { describe, it, expect } from 'vitest';
import { tokenizeWorkoutLine, tokenizeStructuredLog } from './tokenizer.js';
describe('tokenizer', () => {
  it('nums', () => expect(tokenizeWorkoutLine('a:5x100').some(t=>t.kind==='number')).toBe(true));
  it('struct skip #', () => expect(tokenizeStructuredLog('#x\na:1x1').length).toBe(1));
  for (let k = 0; k < 10; k++) {
    it(`tok ${k}`, () => expect(tokenizeWorkoutLine('1x2').length).toBeGreaterThan(0));
  }
});
