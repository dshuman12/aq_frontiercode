import { describe, it, expect } from 'vitest';
import { detectLogFormat } from './formatDetect.js';
describe('fmt', () => {
  const cases: [string, string][] = [
    ['[]','json'], ['{"a":1}','json'], ['a,b\nc,d\ne,f','csv'], ['x:1x1','structured_text'],
    ['','unknown'], ['@@@','unknown'], ['a\tb\nc\td','csv'], ['  []  ','json'],
  ];
  it('matrix', () => { for (const [raw, exp] of cases) expect(detectLogFormat(raw)).toBe(exp); });
  for (let i = 0; i < 10; i++) it(`d${i}`, () => expect(['structured_text','unknown','csv','json']).toContain(detectLogFormat('a:1x1')));
});
