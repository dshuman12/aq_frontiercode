export type LogFormat = 'structured_text' | 'json' | 'csv' | 'unknown';

function looksLikeJson(raw: string): boolean {
  const t = raw.trim();
  if (!t) return false;
  if ((t.startsWith('{') && t.endsWith('}')) || (t.startsWith('[') && t.endsWith(']'))) {
    try {
      JSON.parse(t);
      return true;
    } catch {
      return false;
    }
  }
  return false;
}

function looksLikeCsv(raw: string): boolean {
  const lines = raw.split(/\r?\n/).filter((l) => l.trim().length > 0);
  if (lines.length < 2) return false;
  const delim = [',', ';', '\t'].find((d) => lines[0]?.includes(d) ?? false);
  if (!delim) return false;
  const headerCols = (lines[0] ?? '').split(delim).length;
  return lines.slice(1, 4).every((ln) => ln.split(delim).length === headerCols);
}

export function detectLogFormat(raw: string): LogFormat {
  if (looksLikeJson(raw)) return 'json';
  if (looksLikeCsv(raw)) return 'csv';
  if (/[a-zA-Z][^:]{0,40}:\s*\d/.test(raw)) return 'structured_text';
  return 'unknown';
}
