export type WorkoutToken =
  | { kind: 'label'; value: string }
  | { kind: 'number'; value: number }
  | { kind: 'unit'; value: string }
  | { kind: 'separator'; value: string }
  | { kind: 'meta'; value: string };

const SEP = new Set([':', ',', 'x', '@', '|', ';']);

export function tokenizeWorkoutLine(line: string): WorkoutToken[] {
  const tokens: WorkoutToken[] = [];
  let i = 0;
  const n = line.length;
  const pushWord = (): void => {
    const start = i;
    while (i < n && !/\s/.test(line[i] ?? '') && !SEP.has(line[i] ?? '')) {
      i++;
    }
    const raw = line.slice(start, i);
    if (raw.length > 0) {
      const num = Number(raw.replace(',', '.'));
      if (!Number.isNaN(num) && /^[0-9]+([.,][0-9]+)?$/.test(raw)) {
        tokens.push({ kind: 'number', value: num });
      } else {
        tokens.push({ kind: 'label', value: raw });
      }
    }
  };
  while (i < n) {
    const ch = line[i] ?? '';
    if (/\s/.test(ch)) {
      i++;
      continue;
    }
    if (SEP.has(ch)) {
      tokens.push({ kind: 'separator', value: ch });
      i++;
      continue;
    }
    if (ch === '(') {
      let j = i + 1;
      while (j < n && line[j] !== ')') j++;
      const inner = line.slice(i + 1, j);
      tokens.push({ kind: 'meta', value: inner.trim() });
      i = j < n ? j + 1 : n;
      continue;
    }
    pushWord();
  }
  return tokens;
}

export function tokenizeStructuredLog(text: string): { line: number; tokens: WorkoutToken[] }[] {
  const lines = text.split(/\r?\n/);
  const out: { line: number; tokens: WorkoutToken[] }[] = [];
  for (let idx = 0; idx < lines.length; idx++) {
    const line = (lines[idx] ?? '').trim();
    if (!line || line.startsWith('#')) continue;
    out.push({ line: idx + 1, tokens: tokenizeWorkoutLine(line) });
  }
  return out;
}
