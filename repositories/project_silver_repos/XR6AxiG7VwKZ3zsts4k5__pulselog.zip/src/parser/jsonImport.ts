import type { ExerciseBlock, WorkoutSession, WorkoutSet } from '../types/core.js';

export interface JsonSessionInput {
  id?: string;
  startedAt: string | number;
  endedAt: string | number;
  blocks: JsonBlockInput[];
  bodyweightKg?: number;
  notes?: string;
  tags?: string[];
}

export interface JsonBlockInput {
  exerciseId?: string;
  exerciseName: string;
  sets: JsonSetInput[];
  restSecAvg?: number;
}

export interface JsonSetInput {
  reps: number;
  weightKg: number;
  rpe?: number;
  rir?: number;
  distanceM?: number;
  durationSec?: number;
  notes?: string;
  isWarmup?: boolean;
}

function toDate(v: string | number): Date {
  if (typeof v === 'number') return new Date(v);
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) throw new Error(`Invalid date: ${v}`);
  return d;
}

function normalizeSet(s: JsonSetInput, idx: number): WorkoutSet {
  if (s.reps < 0 || s.weightKg < 0) throw new Error(`Invalid set at index ${idx}`);
  return {
    reps: s.reps,
    weightKg: s.weightKg,
    rpe: s.rpe,
    rir: s.rir,
    distanceM: s.distanceM,
    durationSec: s.durationSec,
    notes: s.notes,
    isWarmup: s.isWarmup,
  };
}

export function importSessionFromJson(input: JsonSessionInput): WorkoutSession {
  const id = input.id ?? `session-${toDate(input.startedAt).toISOString()}`;
  const blocks: ExerciseBlock[] = input.blocks.map((b, bi) => {
    const exerciseId = b.exerciseId ?? b.exerciseName.toLowerCase().replace(/\s+/g, '-');
    const sets = b.sets.map((s, si) => normalizeSet(s, bi * 100 + si));
    return { exerciseId, exerciseName: b.exerciseName, sets, restSecAvg: b.restSecAvg };
  });
  return {
    id,
    startedAt: toDate(input.startedAt),
    endedAt: toDate(input.endedAt),
    blocks,
    bodyweightKg: input.bodyweightKg,
    notes: input.notes,
    tags: input.tags,
  };
}

export function importSessionsFromJsonArray(raw: string): WorkoutSession[] {
  const data = JSON.parse(raw) as unknown;
  if (!Array.isArray(data)) throw new Error('Expected JSON array of sessions');
  return data.map((x) => importSessionFromJson(x as JsonSessionInput));
}
