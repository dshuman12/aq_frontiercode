export function lombardiOneRm(weightKg: number, reps: number): number {
  if (reps <= 0) return weightKg;
  return weightKg * Math.pow(reps, 0.1);
}
