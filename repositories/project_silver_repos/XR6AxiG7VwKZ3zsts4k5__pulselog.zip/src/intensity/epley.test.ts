import { describe, it, expect } from 'vitest';
import { epleyOneRm } from './epley.js';
describe('epley', () => {
  for (let i = 0; i < 11; i++) {
    it(`r${i}`, () => { expect(epleyOneRm(100, 5)).toBeCloseTo(116.67, 1); });
  }
});
