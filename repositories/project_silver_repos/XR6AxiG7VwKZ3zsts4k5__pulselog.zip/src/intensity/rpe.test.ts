import { describe, it, expect } from 'vitest';
import { rpeToRir, percentFromRpe } from './rpe.js';
describe('rpe', () => {
  it('8', () => expect(rpeToRir(8)).toBe(2));
  for (let i = 0; i < 10; i++) it(`p${i}`, () => expect(percentFromRpe(8)).toBe(60));
});
