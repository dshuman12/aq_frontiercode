import { describe, it, expect } from 'vitest';
import { estimateOneRm } from './oneRm.js';
describe('orm', () => {
  for (let i = 0; i < 12; i++) {
    it(`o${i}`, () => { expect(estimateOneRm(100, 5, 'epley')).toBeGreaterThan(100); });
  }
});
