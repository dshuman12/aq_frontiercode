export type IntensityZone = 'skill' | 'strength' | 'hypertrophy' | 'endurance';
export function zoneFromPercent1Rm(pct: number): IntensityZone {
  if (pct >= 90) return 'strength';
  if (pct >= 75) return 'hypertrophy';
  if (pct >= 55) return 'endurance';
  return 'skill';
}
