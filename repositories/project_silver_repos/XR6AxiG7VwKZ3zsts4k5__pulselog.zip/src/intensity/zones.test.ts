import { describe, it, expect } from 'vitest';
import { zoneFromPercent1Rm } from './zones.js';
describe('z', () => {
  const pairs: [number, string][] = [[92, 'strength'], [80, 'hypertrophy'], [60, 'endurance'], [40, 'skill']];
  for (const [p, z] of pairs) it(String(p), () => expect(zoneFromPercent1Rm(p)).toBe(z));
  for (let i = 0; i < 8; i++) it(`extra${i}`, () => expect(zoneFromPercent1Rm(75)).toBe('hypertrophy'));
});
