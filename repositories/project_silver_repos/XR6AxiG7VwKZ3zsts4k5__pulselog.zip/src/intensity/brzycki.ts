export function brzyckiOneRm(weightKg: number, reps: number): number {
  if (reps <= 0) return weightKg;
  return weightKg * (36 / (37 - reps));
}
