export function rpeToRir(rpe: number): number { return Math.max(0, 10 - rpe); }
export function rirToRpe(rir: number): number { return Math.min(10, Math.max(1, 10 - rir)); }
export function percentFromRpe(rpe: number): number {
  const x = Math.min(10, Math.max(6, rpe));
  return 40 + (x - 6) * 10;
}
