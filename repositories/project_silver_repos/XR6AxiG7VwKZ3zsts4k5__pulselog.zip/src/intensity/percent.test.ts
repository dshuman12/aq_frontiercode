import { describe, it, expect } from 'vitest';
import { weightFromPercent1Rm, percentLoadFromWeight } from './percent.js';
describe('pct', () => {
  for (let i = 0; i < 10; i++) it(`i${i}`, () => {
    expect(weightFromPercent1Rm(200, 80)).toBe(160);
    expect(percentLoadFromWeight(200, 160)).toBe(80);
  });
});
