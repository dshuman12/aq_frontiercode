import { describe, it, expect } from 'vitest';
import { brzyckiOneRm } from './brzycki.js';
describe('brz', () => {
  for (let i = 0; i < 12; i++) {
    it(`b${i}`, () => expect(brzyckiOneRm(100, 5)).toBeCloseTo(112.5, 1));
  }
});
