import { brzyckiOneRm } from './brzycki.js';
import { epleyOneRm } from './epley.js';
import { lombardiOneRm } from './lombardi.js';

export type OneRmFormula = 'epley' | 'brzycki' | 'lombardi';

export function estimateOneRm(weightKg: number, reps: number, formula: OneRmFormula = 'epley'): number {
  switch (formula) {
    case 'epley': return epleyOneRm(weightKg, reps);
    case 'brzycki': return brzyckiOneRm(weightKg, reps);
    case 'lombardi': return lombardiOneRm(weightKg, reps);
    default: return epleyOneRm(weightKg, reps);
  }
}
