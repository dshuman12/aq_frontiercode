export function weightFromPercent1Rm(oneRm: number, pct: number): number { return (oneRm * pct) / 100; }
export function percentLoadFromWeight(oneRm: number, load: number): number {
  if (oneRm <= 0) return 0;
  return (load / oneRm) * 100;
}
