import { describe, it, expect } from 'vitest';
import { findExerciseById, getDefaultCatalog, searchExercises } from './catalog.js';
describe('cat', () => {
  for (let i = 0; i < 11; i++) it(`c${i}`, () => {
    expect(getDefaultCatalog().length).toBeGreaterThan(5);
    expect(findExerciseById('squat')).toBeDefined();
    expect(searchExercises('bench').length).toBeGreaterThan(0);
  });
});
