import type { Exercise } from '../types/core.js';

export function isIsolationExercise(ex: Exercise): boolean { return !ex.isCompound; }

export function partitionCompound(exercises: readonly Exercise[]): {
  compound: Exercise[]; isolation: Exercise[];
} {
  const compound: Exercise[] = [];
  const isolation: Exercise[] = [];
  for (const e of exercises) (e.isCompound ? compound : isolation).push(e);
  return { compound, isolation };
}
