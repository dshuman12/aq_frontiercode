import { describe, it, expect } from 'vitest';
import { expandMuscleActivation, mergeActivationMaps } from './muscleMap.js';
import { findExerciseById } from './catalog.js';
import { MuscleGroup } from '../types/core.js';
describe('mm', () => {
  it('ex', () => expect(expandMuscleActivation(findExerciseById('bench-press')!).get(MuscleGroup.Chest)).toBe(1));
  it('mg', () =>
    expect(mergeActivationMaps([expandMuscleActivation(findExerciseById('bench-press')!)]).size).toBeGreaterThan(0));
});
