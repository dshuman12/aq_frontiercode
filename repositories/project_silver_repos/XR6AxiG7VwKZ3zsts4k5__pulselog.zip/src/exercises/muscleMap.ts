import { MuscleGroup } from '../types/core.js';
import type { Exercise } from '../types/core.js';

export function expandMuscleActivation(ex: Exercise): Map<MuscleGroup, number> {
  const m = new Map<MuscleGroup, number>();
  for (const g of ex.primaryMuscles) m.set(g, (m.get(g) ?? 0) + 1);
  for (const g of ex.secondaryMuscles) m.set(g, (m.get(g) ?? 0) + 0.5);
  return m;
}

export function mergeActivationMaps(
  maps: ReadonlyArray<ReadonlyMap<MuscleGroup, number>>,
): Map<MuscleGroup, number> {
  const out = new Map<MuscleGroup, number>();
  for (const mp of maps) {
    for (const [k, v] of mp) out.set(k, (out.get(k) ?? 0) + v);
  }
  return out;
}
