import { getDefaultCatalog } from './catalog.js';

export function resolveAlias(token: string): string | null {
  const q = token.trim().toLowerCase();
  for (const ex of getDefaultCatalog()) {
    if (ex.name.toLowerCase() === q || ex.id === q) return ex.id;
    if (ex.aliases.some((a) => a.toLowerCase() === q)) return ex.id;
  }
  return null;
}

export function tokenizeAliasesCsv(csv: string): string[] {
  return csv.split(',').map((s) => s.trim()).filter(Boolean);
}
