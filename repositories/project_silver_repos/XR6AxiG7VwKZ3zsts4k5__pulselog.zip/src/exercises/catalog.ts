import type { Exercise } from '../types/core.js';
import { ExerciseCategory, MovementPattern, MuscleGroup } from '../types/core.js';

const raw: Exercise[] = [
  { id: 'bench-press', name: 'Barbell Bench Press', aliases: ['bench', 'bb bench'],
    primaryMuscles: [MuscleGroup.Chest], secondaryMuscles: [MuscleGroup.Triceps, MuscleGroup.Shoulders],
    pattern: MovementPattern.HorizontalPush, category: ExerciseCategory.Strength, equipment: 'barbell', isCompound: true },
  { id: 'overhead-press', name: 'Overhead Press', aliases: ['ohp', 'military press'],
    primaryMuscles: [MuscleGroup.Shoulders], secondaryMuscles: [MuscleGroup.Triceps, MuscleGroup.Abs],
    pattern: MovementPattern.VerticalPush, category: ExerciseCategory.Strength, equipment: 'barbell', isCompound: true },
  { id: 'squat', name: 'High-Bar Squat', aliases: ['squats'],
    primaryMuscles: [MuscleGroup.Quads, MuscleGroup.Glutes], secondaryMuscles: [MuscleGroup.Hamstrings, MuscleGroup.Abs],
    pattern: MovementPattern.Squat, category: ExerciseCategory.Strength, equipment: 'barbell', isCompound: true },
  { id: 'deadlift', name: 'Conventional Deadlift', aliases: ['dl', 'deads'],
    primaryMuscles: [MuscleGroup.Hamstrings, MuscleGroup.Glutes, MuscleGroup.Back],
    secondaryMuscles: [MuscleGroup.Forearms, MuscleGroup.Back],
    pattern: MovementPattern.Hinge, category: ExerciseCategory.Strength, equipment: 'barbell', isCompound: true },
  { id: 'pull-up', name: 'Pull-up', aliases: ['pullup', 'pullups'],
    primaryMuscles: [MuscleGroup.Back, MuscleGroup.Biceps], secondaryMuscles: [MuscleGroup.Forearms],
    pattern: MovementPattern.VerticalPull, category: ExerciseCategory.Strength, equipment: 'bodyweight', isCompound: true },
  { id: 'dip', name: 'Parallel Bar Dip', aliases: ['dips'],
    primaryMuscles: [MuscleGroup.Chest, MuscleGroup.Triceps], secondaryMuscles: [MuscleGroup.Shoulders],
    pattern: MovementPattern.VerticalPush, category: ExerciseCategory.Hypertrophy, equipment: 'bodyweight', isCompound: true },
  { id: 'leg-press', name: 'Leg Press', aliases: ['legpress'],
    primaryMuscles: [MuscleGroup.Quads], secondaryMuscles: [MuscleGroup.Glutes],
    pattern: MovementPattern.Squat, category: ExerciseCategory.Hypertrophy, equipment: 'machine', isCompound: true },
  { id: 'barbell-row', name: 'Pendlay Row', aliases: ['bb row'],
    primaryMuscles: [MuscleGroup.Back], secondaryMuscles: [MuscleGroup.Biceps, MuscleGroup.Forearms],
    pattern: MovementPattern.HorizontalPull, category: ExerciseCategory.Strength, equipment: 'barbell', isCompound: true },
];

export function getDefaultCatalog(): readonly Exercise[] { return raw; }
export function findExerciseById(id: string): Exercise | undefined { return raw.find((e) => e.id === id); }
export function searchExercises(query: string): Exercise[] {
  const q = query.trim().toLowerCase();
  if (!q) return [...raw];
  return raw.filter((e) => e.name.toLowerCase().includes(q) || e.aliases.some((a) => a.toLowerCase().includes(q)) || e.id.includes(q));
}
