import { MovementPattern } from '../types/core.js';
import type { Exercise } from '../types/core.js';

export function classifyPatternKeyword(name: string): MovementPattern | null {
  const n = name.toLowerCase();
  if (/squat|leg press|hack squat/.test(n)) return MovementPattern.Squat;
  if (/deadlift|rdl|romanian|good morning/.test(n)) return MovementPattern.Hinge;
  if (/bench|push[- ]?up|dip/.test(n)) return MovementPattern.HorizontalPush;
  if (/ohp|shoulder press|arnold|military/.test(n)) return MovementPattern.VerticalPush;
  if (/row|lat pulldown|pulldown/.test(n)) return MovementPattern.HorizontalPull;
  if (/pull[- ]?up|chin[- ]?up|lat/.test(n)) return MovementPattern.VerticalPull;
  return null;
}

export function exerciseMatchesPattern(ex: Exercise, pattern: MovementPattern): boolean {
  return ex.pattern === pattern;
}
