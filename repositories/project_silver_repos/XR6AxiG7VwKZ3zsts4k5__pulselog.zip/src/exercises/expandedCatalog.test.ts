import { describe, it, expect } from 'vitest';
import { getExpandedCatalog, findInExpanded, searchExpanded } from './expandedCatalog.js';
describe('ex', () => {
  for (let i = 0; i < 12; i++)
    it(`e${i}`, () => {
      expect(getExpandedCatalog().length).toBeGreaterThan(200);
      expect(findInExpanded('gen-exercise-0')?.id).toBe('gen-exercise-0');
      expect(searchExpanded('').length).toBe(getExpandedCatalog().length);
    });
});
