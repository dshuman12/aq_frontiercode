import { describe, it, expect } from 'vitest';
import { wavePatternVolumes } from './waves.js';
import { isLikelyDeloadWeek } from './deloads.js';
import type { WorkoutSession } from '../types/core.js';
describe('wav', () => {
  it('one', () => expect(wavePatternVolumes(60, 1)).toEqual([60]));
  for (let i = 0; i < 10; i++) it(`v${i}`, () => expect(wavePatternVolumes(80, 5)[0]).toBeGreaterThan(0));
  it('del', () =>
    expect(isLikelyDeloadWeek([{ id: 'd', startedAt: new Date(), endedAt: new Date(), blocks: [
      { exerciseId: 'bench-press', exerciseName: 'b', sets: [{ reps: 1, weightKg: 1, rpe: 8 }] },
    ] }], 20)).toBe(true));
});
