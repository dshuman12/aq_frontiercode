import type { TrainingBlock } from '../types/core.js';

export function sessionsInBlock(block: TrainingBlock): number { return block.sessions.length; }

export function blockDurationDays(block: TrainingBlock): number {
  return Math.max(0, Math.round((block.end.getTime() - block.start.getTime()) / 86400000));
}
