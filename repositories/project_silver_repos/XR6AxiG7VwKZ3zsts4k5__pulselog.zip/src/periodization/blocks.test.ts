import { describe, it, expect } from 'vitest';
import { blockDurationDays, sessionsInBlock } from './blocks.js';
import type { TrainingBlock } from '../types/core.js';
describe('bl', () => {
  for (let i = 0; i < 8; i++)
    it(`b${i}`, () => {
      const B: TrainingBlock = { id: 'b', name: 'x', start: new Date('2026-01-01'), end: new Date('2026-01-08'), sessions: [] };
      expect(blockDurationDays(B)).toBe(7);
      expect(sessionsInBlock(B)).toBe(0);
    });
});
