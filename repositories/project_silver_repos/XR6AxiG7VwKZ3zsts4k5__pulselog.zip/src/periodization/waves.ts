export function wavePatternVolumes(base: number, weeks: number): number[] {
  if (weeks <= 0) return [];
  if (weeks === 1) return [Math.round(base)];
  const arr: number[] = [];
  for (let i = 0; i < weeks; i++) {
    const t = Math.sin((i / (weeks - 1)) * Math.PI);
    arr.push(Math.round(base * (0.85 + 0.15 * t)));
  }
  return arr;
}
