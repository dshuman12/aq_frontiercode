import type { WorkoutSession } from '../types/core.js';

export function bucketSessionsByWeek(sessions: readonly WorkoutSession[]): Map<string, WorkoutSession[]> {
  const m = new Map<string, WorkoutSession[]>();
  for (const s of sessions) {
    const d = s.startedAt;
    const key = `${d.getUTCFullYear()}-W${weekNumber(d)}`;
    const arr = m.get(key) ?? [];
    arr.push(s);
    m.set(key, arr);
  }
  return m;
}

function weekNumber(d: Date): number {
  const t = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
  const day = t.getUTCDay() || 7;
  t.setUTCDate(t.getUTCDate() + 4 - day);
  const yearStart = new Date(Date.UTC(t.getUTCFullYear(), 0, 1));
  return Math.ceil(((t.getTime() - yearStart.getTime()) / 86400000 + 1) / 7);
}
