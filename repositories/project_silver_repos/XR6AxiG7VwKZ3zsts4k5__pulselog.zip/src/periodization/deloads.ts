import type { WorkoutSession } from '../types/core.js';
import { totalSets } from '../volume/totals.js';

export function isLikelyDeloadWeek(sessions: readonly WorkoutSession[], baselineSets: number): boolean {
  const sets = totalSets(sessions, 'working');
  return sets < baselineSets * 0.65;
}
