import { describe, it, expect } from 'vitest';
import { isPlausibleBenchKg, isPlausibleSquatKg } from './physiological.js';
describe('phy', () => {
  for (let i = 0; i < 10; i++) it(`p${i}`, () => {
    expect(isPlausibleSquatKg(100, 180)).toBe(true);
    expect(isPlausibleBenchKg(100, 150)).toBe(true);
  });
});
