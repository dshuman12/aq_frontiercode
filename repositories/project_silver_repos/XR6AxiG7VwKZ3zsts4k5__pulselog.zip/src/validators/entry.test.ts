import { describe, it, expect } from 'vitest';
import { validateSet } from './entry.js';
describe('ent', () => { for (let i = 0; i < 10; i++) it(`e${i}`, () => expect(validateSet({ reps: 5, weightKg: 100, rpe: 8 })).toEqual([])); });
