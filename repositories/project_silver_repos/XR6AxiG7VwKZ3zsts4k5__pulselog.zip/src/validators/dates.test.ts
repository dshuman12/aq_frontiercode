import { describe, it, expect } from 'vitest';
import { sessionsChronological } from './dates.js';
describe('dt', () => {
  for (let i = 0; i < 10; i++)
    it(`d${i}`, () =>
      expect(
        sessionsChronological([
          { id: '1', startedAt: new Date(1), endedAt: new Date(2), blocks: [] },
          { id: '2', startedAt: new Date(3), endedAt: new Date(4), blocks: [] },
        ]),
      ).toBe(true));
});
