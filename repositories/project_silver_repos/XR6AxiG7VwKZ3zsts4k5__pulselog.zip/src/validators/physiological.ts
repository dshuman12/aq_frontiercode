export function isPlausibleSquatKg(bodyweightKg: number, squatKg: number): boolean {
  return squatKg < bodyweightKg * 6;
}
export function isPlausibleBenchKg(bodyweightKg: number, benchKg: number): boolean {
  return benchKg < bodyweightKg * 4;
}
