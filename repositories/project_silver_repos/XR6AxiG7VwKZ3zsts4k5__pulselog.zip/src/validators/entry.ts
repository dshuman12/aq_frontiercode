import type { WorkoutSet } from '../types/core.js';

export function validateSet(set: WorkoutSet): string[] {
  const errs: string[] = [];
  if (set.reps <= 0) errs.push('reps must be positive');
  if (set.weightKg < 0) errs.push('weight must be non-negative');
  if (set.rpe !== undefined && (set.rpe < 1 || set.rpe > 10)) errs.push('rpe out of range');
  return errs;
}
