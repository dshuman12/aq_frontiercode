import type { WorkoutSession } from '../types/core.js';

export function sessionsChronological(sessions: readonly WorkoutSession[]): boolean {
  for (let i = 1; i < sessions.length; i++) {
    const a = sessions[i - 1]?.endedAt.getTime() ?? 0;
    const b = sessions[i]?.startedAt.getTime() ?? 0;
    if (b < a) return false;
  }
  return true;
}
