export function balanceScore(pushVol: number, pullVol: number): number {
  const t = pushVol + pullVol;
  if (t === 0) return 100;
  const ideal = 0.5;
  const actual = pushVol / t;
  return 100 - Math.abs(actual - ideal) * 200;
}
