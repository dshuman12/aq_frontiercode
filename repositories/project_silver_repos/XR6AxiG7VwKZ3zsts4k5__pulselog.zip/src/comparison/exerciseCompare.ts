import type { WorkoutSet } from '../types/core.js';

export function betterSet(a: WorkoutSet, b: WorkoutSet): WorkoutSet {
  if (a.reps === b.reps) return a.weightKg >= b.weightKg ? a : b;
  return a.weightKg / (1 + a.reps / 30) >= b.weightKg / (1 + b.reps / 30) ? a : b;
}
