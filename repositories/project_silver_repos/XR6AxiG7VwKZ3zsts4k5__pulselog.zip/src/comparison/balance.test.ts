import { describe, it, expect } from 'vitest';
import { balanceScore } from './balance.js';
import { comparePeriodVolume } from './period.js';
import type { WorkoutSession } from '../types/core.js';
const blk = (n: number): WorkoutSession => ({
  id: String(n),
  startedAt: new Date(),
  endedAt: new Date(),
  blocks: [{ exerciseId: 'bench-press', exerciseName: 'b', sets: Array.from({ length: n }, () => ({ reps: 5, weightKg: 60, rpe: 8 })) }],
});
describe('cmp', () => {
  for (let i = 0; i < 8; i++)
    it(`b${i}`, () => {
      expect(balanceScore(50, 50)).toBe(100);
      expect(comparePeriodVolume([blk(2)], [blk(5)])).toBe(3);
    });
});
