import type { WorkoutSession } from '../types/core.js';
import { totalSets } from '../volume/totals.js';

export function comparePeriodVolume(a: readonly WorkoutSession[], b: readonly WorkoutSession[]): number {
  return totalSets(b, 'working') - totalSets(a, 'working');
}
