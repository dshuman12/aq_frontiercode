import { describe, it, expect } from 'vitest';
import { wf_mean_0, wf_sum_0, wf_var_0 } from './workoutMath.js';
describe('math', () => {
  for (let i = 0; i < 12; i++)
    it(`m${i}`, () => {
      expect(wf_sum_0([1, 2, 3])).toBe(6);
      expect(wf_mean_0([2, 4, 6])).toBe(4);
      expect(wf_var_0([1, 3])).toBeGreaterThan(0);
    });
});
