/** Statistical helpers */
export function wf_sum_0(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_0(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_0(xs) / xs.length;
}
export function wf_var_0(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_0(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_1(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_1(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_1(xs) / xs.length;
}
export function wf_var_1(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_1(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_2(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_2(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_2(xs) / xs.length;
}
export function wf_var_2(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_2(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_3(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_3(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_3(xs) / xs.length;
}
export function wf_var_3(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_3(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_4(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_4(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_4(xs) / xs.length;
}
export function wf_var_4(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_4(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_5(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_5(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_5(xs) / xs.length;
}
export function wf_var_5(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_5(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_6(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_6(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_6(xs) / xs.length;
}
export function wf_var_6(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_6(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_7(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_7(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_7(xs) / xs.length;
}
export function wf_var_7(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_7(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_8(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_8(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_8(xs) / xs.length;
}
export function wf_var_8(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_8(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_9(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_9(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_9(xs) / xs.length;
}
export function wf_var_9(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_9(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_10(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_10(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_10(xs) / xs.length;
}
export function wf_var_10(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_10(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_11(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_11(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_11(xs) / xs.length;
}
export function wf_var_11(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_11(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_12(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_12(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_12(xs) / xs.length;
}
export function wf_var_12(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_12(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_13(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_13(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_13(xs) / xs.length;
}
export function wf_var_13(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_13(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_14(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_14(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_14(xs) / xs.length;
}
export function wf_var_14(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_14(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_15(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_15(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_15(xs) / xs.length;
}
export function wf_var_15(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_15(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_16(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_16(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_16(xs) / xs.length;
}
export function wf_var_16(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_16(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_17(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_17(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_17(xs) / xs.length;
}
export function wf_var_17(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_17(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_18(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_18(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_18(xs) / xs.length;
}
export function wf_var_18(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_18(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_19(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_19(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_19(xs) / xs.length;
}
export function wf_var_19(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_19(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_20(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_20(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_20(xs) / xs.length;
}
export function wf_var_20(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_20(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_21(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_21(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_21(xs) / xs.length;
}
export function wf_var_21(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_21(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_22(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_22(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_22(xs) / xs.length;
}
export function wf_var_22(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_22(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_23(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_23(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_23(xs) / xs.length;
}
export function wf_var_23(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_23(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_24(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_24(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_24(xs) / xs.length;
}
export function wf_var_24(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_24(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_25(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_25(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_25(xs) / xs.length;
}
export function wf_var_25(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_25(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_26(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_26(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_26(xs) / xs.length;
}
export function wf_var_26(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_26(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_27(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_27(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_27(xs) / xs.length;
}
export function wf_var_27(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_27(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_28(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_28(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_28(xs) / xs.length;
}
export function wf_var_28(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_28(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_29(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_29(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_29(xs) / xs.length;
}
export function wf_var_29(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_29(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_30(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_30(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_30(xs) / xs.length;
}
export function wf_var_30(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_30(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_31(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_31(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_31(xs) / xs.length;
}
export function wf_var_31(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_31(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_32(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_32(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_32(xs) / xs.length;
}
export function wf_var_32(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_32(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_33(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_33(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_33(xs) / xs.length;
}
export function wf_var_33(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_33(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_34(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_34(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_34(xs) / xs.length;
}
export function wf_var_34(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_34(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_35(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_35(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_35(xs) / xs.length;
}
export function wf_var_35(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_35(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_36(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_36(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_36(xs) / xs.length;
}
export function wf_var_36(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_36(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_37(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_37(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_37(xs) / xs.length;
}
export function wf_var_37(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_37(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_38(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_38(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_38(xs) / xs.length;
}
export function wf_var_38(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_38(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_39(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_39(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_39(xs) / xs.length;
}
export function wf_var_39(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_39(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_40(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_40(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_40(xs) / xs.length;
}
export function wf_var_40(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_40(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_41(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_41(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_41(xs) / xs.length;
}
export function wf_var_41(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_41(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_42(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_42(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_42(xs) / xs.length;
}
export function wf_var_42(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_42(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_43(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_43(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_43(xs) / xs.length;
}
export function wf_var_43(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_43(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_44(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_44(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_44(xs) / xs.length;
}
export function wf_var_44(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_44(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_45(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_45(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_45(xs) / xs.length;
}
export function wf_var_45(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_45(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_46(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_46(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_46(xs) / xs.length;
}
export function wf_var_46(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_46(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_47(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_47(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_47(xs) / xs.length;
}
export function wf_var_47(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_47(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_48(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_48(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_48(xs) / xs.length;
}
export function wf_var_48(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_48(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_49(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_49(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_49(xs) / xs.length;
}
export function wf_var_49(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_49(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_50(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_50(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_50(xs) / xs.length;
}
export function wf_var_50(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_50(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_51(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_51(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_51(xs) / xs.length;
}
export function wf_var_51(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_51(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_52(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_52(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_52(xs) / xs.length;
}
export function wf_var_52(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_52(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_53(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_53(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_53(xs) / xs.length;
}
export function wf_var_53(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_53(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_54(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_54(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_54(xs) / xs.length;
}
export function wf_var_54(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_54(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_55(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_55(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_55(xs) / xs.length;
}
export function wf_var_55(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_55(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_56(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_56(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_56(xs) / xs.length;
}
export function wf_var_56(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_56(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_57(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_57(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_57(xs) / xs.length;
}
export function wf_var_57(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_57(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_58(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_58(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_58(xs) / xs.length;
}
export function wf_var_58(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_58(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_59(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_59(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_59(xs) / xs.length;
}
export function wf_var_59(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_59(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_60(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_60(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_60(xs) / xs.length;
}
export function wf_var_60(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_60(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_61(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_61(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_61(xs) / xs.length;
}
export function wf_var_61(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_61(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_62(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_62(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_62(xs) / xs.length;
}
export function wf_var_62(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_62(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_63(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_63(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_63(xs) / xs.length;
}
export function wf_var_63(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_63(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_64(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_64(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_64(xs) / xs.length;
}
export function wf_var_64(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_64(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_65(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_65(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_65(xs) / xs.length;
}
export function wf_var_65(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_65(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_66(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_66(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_66(xs) / xs.length;
}
export function wf_var_66(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_66(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_67(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_67(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_67(xs) / xs.length;
}
export function wf_var_67(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_67(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_68(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_68(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_68(xs) / xs.length;
}
export function wf_var_68(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_68(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_69(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_69(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_69(xs) / xs.length;
}
export function wf_var_69(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_69(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_70(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_70(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_70(xs) / xs.length;
}
export function wf_var_70(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_70(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_71(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_71(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_71(xs) / xs.length;
}
export function wf_var_71(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_71(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_72(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_72(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_72(xs) / xs.length;
}
export function wf_var_72(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_72(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_73(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_73(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_73(xs) / xs.length;
}
export function wf_var_73(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_73(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_74(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_74(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_74(xs) / xs.length;
}
export function wf_var_74(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_74(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_75(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_75(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_75(xs) / xs.length;
}
export function wf_var_75(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_75(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_76(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_76(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_76(xs) / xs.length;
}
export function wf_var_76(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_76(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_77(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_77(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_77(xs) / xs.length;
}
export function wf_var_77(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_77(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_78(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_78(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_78(xs) / xs.length;
}
export function wf_var_78(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_78(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_79(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_79(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_79(xs) / xs.length;
}
export function wf_var_79(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_79(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_80(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_80(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_80(xs) / xs.length;
}
export function wf_var_80(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_80(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_81(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_81(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_81(xs) / xs.length;
}
export function wf_var_81(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_81(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_82(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_82(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_82(xs) / xs.length;
}
export function wf_var_82(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_82(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_83(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_83(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_83(xs) / xs.length;
}
export function wf_var_83(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_83(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_84(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_84(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_84(xs) / xs.length;
}
export function wf_var_84(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_84(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_85(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_85(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_85(xs) / xs.length;
}
export function wf_var_85(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_85(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_86(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_86(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_86(xs) / xs.length;
}
export function wf_var_86(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_86(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_87(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_87(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_87(xs) / xs.length;
}
export function wf_var_87(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_87(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_88(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_88(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_88(xs) / xs.length;
}
export function wf_var_88(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_88(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_89(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_89(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_89(xs) / xs.length;
}
export function wf_var_89(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_89(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_90(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_90(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_90(xs) / xs.length;
}
export function wf_var_90(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_90(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_91(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_91(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_91(xs) / xs.length;
}
export function wf_var_91(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_91(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_92(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_92(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_92(xs) / xs.length;
}
export function wf_var_92(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_92(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_93(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_93(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_93(xs) / xs.length;
}
export function wf_var_93(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_93(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_94(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_94(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_94(xs) / xs.length;
}
export function wf_var_94(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_94(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_95(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_95(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_95(xs) / xs.length;
}
export function wf_var_95(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_95(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_96(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_96(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_96(xs) / xs.length;
}
export function wf_var_96(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_96(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_97(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_97(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_97(xs) / xs.length;
}
export function wf_var_97(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_97(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_98(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_98(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_98(xs) / xs.length;
}
export function wf_var_98(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_98(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_99(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_99(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_99(xs) / xs.length;
}
export function wf_var_99(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_99(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_100(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_100(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_100(xs) / xs.length;
}
export function wf_var_100(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_100(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_101(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_101(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_101(xs) / xs.length;
}
export function wf_var_101(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_101(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_102(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_102(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_102(xs) / xs.length;
}
export function wf_var_102(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_102(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_103(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_103(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_103(xs) / xs.length;
}
export function wf_var_103(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_103(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_104(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_104(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_104(xs) / xs.length;
}
export function wf_var_104(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_104(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_105(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_105(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_105(xs) / xs.length;
}
export function wf_var_105(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_105(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_106(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_106(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_106(xs) / xs.length;
}
export function wf_var_106(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_106(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_107(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_107(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_107(xs) / xs.length;
}
export function wf_var_107(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_107(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_108(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_108(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_108(xs) / xs.length;
}
export function wf_var_108(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_108(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_109(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_109(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_109(xs) / xs.length;
}
export function wf_var_109(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_109(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_110(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_110(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_110(xs) / xs.length;
}
export function wf_var_110(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_110(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_111(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_111(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_111(xs) / xs.length;
}
export function wf_var_111(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_111(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_112(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_112(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_112(xs) / xs.length;
}
export function wf_var_112(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_112(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_113(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_113(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_113(xs) / xs.length;
}
export function wf_var_113(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_113(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_114(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_114(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_114(xs) / xs.length;
}
export function wf_var_114(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_114(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_115(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_115(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_115(xs) / xs.length;
}
export function wf_var_115(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_115(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_116(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_116(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_116(xs) / xs.length;
}
export function wf_var_116(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_116(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_117(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_117(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_117(xs) / xs.length;
}
export function wf_var_117(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_117(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_118(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_118(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_118(xs) / xs.length;
}
export function wf_var_118(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_118(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_119(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_119(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_119(xs) / xs.length;
}
export function wf_var_119(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_119(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_120(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_120(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_120(xs) / xs.length;
}
export function wf_var_120(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_120(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_121(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_121(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_121(xs) / xs.length;
}
export function wf_var_121(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_121(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_122(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_122(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_122(xs) / xs.length;
}
export function wf_var_122(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_122(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_123(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_123(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_123(xs) / xs.length;
}
export function wf_var_123(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_123(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_124(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_124(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_124(xs) / xs.length;
}
export function wf_var_124(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_124(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_125(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_125(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_125(xs) / xs.length;
}
export function wf_var_125(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_125(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_126(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_126(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_126(xs) / xs.length;
}
export function wf_var_126(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_126(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_127(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_127(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_127(xs) / xs.length;
}
export function wf_var_127(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_127(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_128(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_128(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_128(xs) / xs.length;
}
export function wf_var_128(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_128(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_129(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_129(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_129(xs) / xs.length;
}
export function wf_var_129(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_129(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_130(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_130(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_130(xs) / xs.length;
}
export function wf_var_130(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_130(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_131(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_131(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_131(xs) / xs.length;
}
export function wf_var_131(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_131(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_132(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_132(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_132(xs) / xs.length;
}
export function wf_var_132(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_132(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_133(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_133(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_133(xs) / xs.length;
}
export function wf_var_133(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_133(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_134(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_134(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_134(xs) / xs.length;
}
export function wf_var_134(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_134(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_135(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_135(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_135(xs) / xs.length;
}
export function wf_var_135(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_135(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_136(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_136(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_136(xs) / xs.length;
}
export function wf_var_136(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_136(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_137(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_137(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_137(xs) / xs.length;
}
export function wf_var_137(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_137(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_138(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_138(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_138(xs) / xs.length;
}
export function wf_var_138(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_138(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_139(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_139(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_139(xs) / xs.length;
}
export function wf_var_139(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_139(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_140(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_140(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_140(xs) / xs.length;
}
export function wf_var_140(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_140(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_141(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_141(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_141(xs) / xs.length;
}
export function wf_var_141(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_141(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_142(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_142(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_142(xs) / xs.length;
}
export function wf_var_142(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_142(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_143(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_143(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_143(xs) / xs.length;
}
export function wf_var_143(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_143(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_144(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_144(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_144(xs) / xs.length;
}
export function wf_var_144(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_144(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_145(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_145(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_145(xs) / xs.length;
}
export function wf_var_145(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_145(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_146(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_146(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_146(xs) / xs.length;
}
export function wf_var_146(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_146(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_147(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_147(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_147(xs) / xs.length;
}
export function wf_var_147(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_147(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_148(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_148(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_148(xs) / xs.length;
}
export function wf_var_148(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_148(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_149(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_149(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_149(xs) / xs.length;
}
export function wf_var_149(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_149(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_150(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_150(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_150(xs) / xs.length;
}
export function wf_var_150(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_150(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_151(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_151(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_151(xs) / xs.length;
}
export function wf_var_151(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_151(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_152(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_152(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_152(xs) / xs.length;
}
export function wf_var_152(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_152(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_153(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_153(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_153(xs) / xs.length;
}
export function wf_var_153(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_153(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_154(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_154(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_154(xs) / xs.length;
}
export function wf_var_154(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_154(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_155(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_155(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_155(xs) / xs.length;
}
export function wf_var_155(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_155(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_156(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_156(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_156(xs) / xs.length;
}
export function wf_var_156(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_156(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_157(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_157(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_157(xs) / xs.length;
}
export function wf_var_157(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_157(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_158(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_158(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_158(xs) / xs.length;
}
export function wf_var_158(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_158(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_159(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_159(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_159(xs) / xs.length;
}
export function wf_var_159(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_159(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_160(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_160(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_160(xs) / xs.length;
}
export function wf_var_160(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_160(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_161(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_161(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_161(xs) / xs.length;
}
export function wf_var_161(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_161(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_162(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_162(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_162(xs) / xs.length;
}
export function wf_var_162(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_162(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_163(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_163(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_163(xs) / xs.length;
}
export function wf_var_163(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_163(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_164(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_164(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_164(xs) / xs.length;
}
export function wf_var_164(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_164(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_165(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_165(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_165(xs) / xs.length;
}
export function wf_var_165(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_165(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_166(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_166(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_166(xs) / xs.length;
}
export function wf_var_166(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_166(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_167(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_167(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_167(xs) / xs.length;
}
export function wf_var_167(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_167(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_168(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_168(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_168(xs) / xs.length;
}
export function wf_var_168(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_168(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_169(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_169(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_169(xs) / xs.length;
}
export function wf_var_169(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_169(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_170(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_170(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_170(xs) / xs.length;
}
export function wf_var_170(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_170(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_171(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_171(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_171(xs) / xs.length;
}
export function wf_var_171(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_171(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_172(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_172(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_172(xs) / xs.length;
}
export function wf_var_172(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_172(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_173(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_173(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_173(xs) / xs.length;
}
export function wf_var_173(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_173(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_174(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_174(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_174(xs) / xs.length;
}
export function wf_var_174(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_174(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_175(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_175(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_175(xs) / xs.length;
}
export function wf_var_175(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_175(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_176(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_176(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_176(xs) / xs.length;
}
export function wf_var_176(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_176(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_177(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_177(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_177(xs) / xs.length;
}
export function wf_var_177(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_177(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_178(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_178(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_178(xs) / xs.length;
}
export function wf_var_178(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_178(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_179(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_179(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_179(xs) / xs.length;
}
export function wf_var_179(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_179(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_180(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_180(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_180(xs) / xs.length;
}
export function wf_var_180(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_180(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_181(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_181(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_181(xs) / xs.length;
}
export function wf_var_181(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_181(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_182(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_182(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_182(xs) / xs.length;
}
export function wf_var_182(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_182(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_183(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_183(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_183(xs) / xs.length;
}
export function wf_var_183(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_183(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_184(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_184(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_184(xs) / xs.length;
}
export function wf_var_184(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_184(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_185(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_185(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_185(xs) / xs.length;
}
export function wf_var_185(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_185(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_186(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_186(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_186(xs) / xs.length;
}
export function wf_var_186(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_186(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_187(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_187(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_187(xs) / xs.length;
}
export function wf_var_187(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_187(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_188(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_188(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_188(xs) / xs.length;
}
export function wf_var_188(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_188(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_189(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_189(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_189(xs) / xs.length;
}
export function wf_var_189(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_189(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_190(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_190(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_190(xs) / xs.length;
}
export function wf_var_190(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_190(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_191(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_191(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_191(xs) / xs.length;
}
export function wf_var_191(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_191(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_192(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_192(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_192(xs) / xs.length;
}
export function wf_var_192(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_192(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_193(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_193(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_193(xs) / xs.length;
}
export function wf_var_193(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_193(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_194(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_194(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_194(xs) / xs.length;
}
export function wf_var_194(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_194(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_195(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_195(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_195(xs) / xs.length;
}
export function wf_var_195(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_195(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_196(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_196(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_196(xs) / xs.length;
}
export function wf_var_196(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_196(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_197(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_197(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_197(xs) / xs.length;
}
export function wf_var_197(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_197(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_198(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_198(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_198(xs) / xs.length;
}
export function wf_var_198(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_198(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_199(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_199(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_199(xs) / xs.length;
}
export function wf_var_199(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_199(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_200(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_200(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_200(xs) / xs.length;
}
export function wf_var_200(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_200(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_201(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_201(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_201(xs) / xs.length;
}
export function wf_var_201(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_201(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_202(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_202(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_202(xs) / xs.length;
}
export function wf_var_202(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_202(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_203(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_203(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_203(xs) / xs.length;
}
export function wf_var_203(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_203(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_204(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_204(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_204(xs) / xs.length;
}
export function wf_var_204(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_204(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_205(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_205(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_205(xs) / xs.length;
}
export function wf_var_205(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_205(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_206(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_206(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_206(xs) / xs.length;
}
export function wf_var_206(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_206(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_207(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_207(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_207(xs) / xs.length;
}
export function wf_var_207(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_207(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_208(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_208(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_208(xs) / xs.length;
}
export function wf_var_208(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_208(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_209(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_209(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_209(xs) / xs.length;
}
export function wf_var_209(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_209(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_210(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_210(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_210(xs) / xs.length;
}
export function wf_var_210(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_210(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_211(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_211(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_211(xs) / xs.length;
}
export function wf_var_211(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_211(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_212(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_212(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_212(xs) / xs.length;
}
export function wf_var_212(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_212(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_213(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_213(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_213(xs) / xs.length;
}
export function wf_var_213(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_213(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_214(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_214(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_214(xs) / xs.length;
}
export function wf_var_214(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_214(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_215(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_215(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_215(xs) / xs.length;
}
export function wf_var_215(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_215(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_216(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_216(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_216(xs) / xs.length;
}
export function wf_var_216(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_216(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_217(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_217(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_217(xs) / xs.length;
}
export function wf_var_217(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_217(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_218(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_218(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_218(xs) / xs.length;
}
export function wf_var_218(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_218(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_219(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_219(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_219(xs) / xs.length;
}
export function wf_var_219(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_219(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_220(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_220(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_220(xs) / xs.length;
}
export function wf_var_220(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_220(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_221(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_221(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_221(xs) / xs.length;
}
export function wf_var_221(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_221(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_222(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_222(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_222(xs) / xs.length;
}
export function wf_var_222(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_222(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_223(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_223(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_223(xs) / xs.length;
}
export function wf_var_223(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_223(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_224(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_224(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_224(xs) / xs.length;
}
export function wf_var_224(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_224(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_225(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_225(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_225(xs) / xs.length;
}
export function wf_var_225(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_225(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_226(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_226(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_226(xs) / xs.length;
}
export function wf_var_226(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_226(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_227(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_227(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_227(xs) / xs.length;
}
export function wf_var_227(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_227(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_228(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_228(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_228(xs) / xs.length;
}
export function wf_var_228(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_228(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_229(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_229(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_229(xs) / xs.length;
}
export function wf_var_229(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_229(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_230(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_230(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_230(xs) / xs.length;
}
export function wf_var_230(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_230(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_231(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_231(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_231(xs) / xs.length;
}
export function wf_var_231(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_231(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_232(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_232(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_232(xs) / xs.length;
}
export function wf_var_232(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_232(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_233(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_233(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_233(xs) / xs.length;
}
export function wf_var_233(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_233(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_234(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_234(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_234(xs) / xs.length;
}
export function wf_var_234(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_234(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_235(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_235(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_235(xs) / xs.length;
}
export function wf_var_235(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_235(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_236(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_236(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_236(xs) / xs.length;
}
export function wf_var_236(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_236(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_237(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_237(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_237(xs) / xs.length;
}
export function wf_var_237(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_237(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_238(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_238(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_238(xs) / xs.length;
}
export function wf_var_238(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_238(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_239(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_239(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_239(xs) / xs.length;
}
export function wf_var_239(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_239(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_240(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_240(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_240(xs) / xs.length;
}
export function wf_var_240(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_240(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_241(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_241(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_241(xs) / xs.length;
}
export function wf_var_241(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_241(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_242(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_242(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_242(xs) / xs.length;
}
export function wf_var_242(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_242(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_243(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_243(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_243(xs) / xs.length;
}
export function wf_var_243(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_243(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_244(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_244(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_244(xs) / xs.length;
}
export function wf_var_244(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_244(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_245(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_245(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_245(xs) / xs.length;
}
export function wf_var_245(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_245(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_246(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_246(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_246(xs) / xs.length;
}
export function wf_var_246(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_246(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_247(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_247(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_247(xs) / xs.length;
}
export function wf_var_247(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_247(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_248(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_248(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_248(xs) / xs.length;
}
export function wf_var_248(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_248(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_249(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_249(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_249(xs) / xs.length;
}
export function wf_var_249(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_249(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_250(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_250(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_250(xs) / xs.length;
}
export function wf_var_250(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_250(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_251(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_251(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_251(xs) / xs.length;
}
export function wf_var_251(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_251(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_252(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_252(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_252(xs) / xs.length;
}
export function wf_var_252(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_252(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_253(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_253(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_253(xs) / xs.length;
}
export function wf_var_253(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_253(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_254(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_254(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_254(xs) / xs.length;
}
export function wf_var_254(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_254(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_255(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_255(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_255(xs) / xs.length;
}
export function wf_var_255(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_255(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_256(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_256(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_256(xs) / xs.length;
}
export function wf_var_256(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_256(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_257(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_257(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_257(xs) / xs.length;
}
export function wf_var_257(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_257(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_258(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_258(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_258(xs) / xs.length;
}
export function wf_var_258(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_258(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_259(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_259(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_259(xs) / xs.length;
}
export function wf_var_259(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_259(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_260(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_260(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_260(xs) / xs.length;
}
export function wf_var_260(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_260(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_261(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_261(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_261(xs) / xs.length;
}
export function wf_var_261(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_261(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_262(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_262(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_262(xs) / xs.length;
}
export function wf_var_262(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_262(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_263(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_263(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_263(xs) / xs.length;
}
export function wf_var_263(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_263(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_264(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_264(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_264(xs) / xs.length;
}
export function wf_var_264(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_264(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_265(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_265(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_265(xs) / xs.length;
}
export function wf_var_265(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_265(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_266(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_266(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_266(xs) / xs.length;
}
export function wf_var_266(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_266(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_267(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_267(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_267(xs) / xs.length;
}
export function wf_var_267(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_267(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_268(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_268(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_268(xs) / xs.length;
}
export function wf_var_268(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_268(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_269(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_269(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_269(xs) / xs.length;
}
export function wf_var_269(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_269(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_270(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_270(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_270(xs) / xs.length;
}
export function wf_var_270(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_270(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_271(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_271(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_271(xs) / xs.length;
}
export function wf_var_271(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_271(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_272(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_272(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_272(xs) / xs.length;
}
export function wf_var_272(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_272(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_273(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_273(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_273(xs) / xs.length;
}
export function wf_var_273(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_273(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_274(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_274(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_274(xs) / xs.length;
}
export function wf_var_274(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_274(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_275(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_275(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_275(xs) / xs.length;
}
export function wf_var_275(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_275(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_276(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_276(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_276(xs) / xs.length;
}
export function wf_var_276(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_276(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_277(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_277(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_277(xs) / xs.length;
}
export function wf_var_277(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_277(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_278(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_278(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_278(xs) / xs.length;
}
export function wf_var_278(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_278(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_279(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_279(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_279(xs) / xs.length;
}
export function wf_var_279(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_279(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_280(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_280(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_280(xs) / xs.length;
}
export function wf_var_280(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_280(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_281(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_281(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_281(xs) / xs.length;
}
export function wf_var_281(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_281(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_282(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_282(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_282(xs) / xs.length;
}
export function wf_var_282(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_282(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_283(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_283(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_283(xs) / xs.length;
}
export function wf_var_283(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_283(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_284(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_284(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_284(xs) / xs.length;
}
export function wf_var_284(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_284(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_285(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_285(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_285(xs) / xs.length;
}
export function wf_var_285(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_285(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_286(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_286(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_286(xs) / xs.length;
}
export function wf_var_286(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_286(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_287(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_287(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_287(xs) / xs.length;
}
export function wf_var_287(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_287(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_288(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_288(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_288(xs) / xs.length;
}
export function wf_var_288(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_288(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_289(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_289(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_289(xs) / xs.length;
}
export function wf_var_289(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_289(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_290(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_290(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_290(xs) / xs.length;
}
export function wf_var_290(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_290(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_291(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_291(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_291(xs) / xs.length;
}
export function wf_var_291(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_291(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_292(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_292(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_292(xs) / xs.length;
}
export function wf_var_292(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_292(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_293(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_293(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_293(xs) / xs.length;
}
export function wf_var_293(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_293(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_294(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_294(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_294(xs) / xs.length;
}
export function wf_var_294(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_294(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_295(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_295(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_295(xs) / xs.length;
}
export function wf_var_295(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_295(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_296(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_296(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_296(xs) / xs.length;
}
export function wf_var_296(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_296(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_297(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_297(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_297(xs) / xs.length;
}
export function wf_var_297(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_297(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_298(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_298(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_298(xs) / xs.length;
}
export function wf_var_298(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_298(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_299(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_299(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_299(xs) / xs.length;
}
export function wf_var_299(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_299(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_300(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_300(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_300(xs) / xs.length;
}
export function wf_var_300(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_300(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_301(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_301(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_301(xs) / xs.length;
}
export function wf_var_301(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_301(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_302(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_302(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_302(xs) / xs.length;
}
export function wf_var_302(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_302(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_303(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_303(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_303(xs) / xs.length;
}
export function wf_var_303(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_303(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_304(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_304(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_304(xs) / xs.length;
}
export function wf_var_304(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_304(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_305(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_305(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_305(xs) / xs.length;
}
export function wf_var_305(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_305(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_306(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_306(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_306(xs) / xs.length;
}
export function wf_var_306(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_306(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_307(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_307(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_307(xs) / xs.length;
}
export function wf_var_307(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_307(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_308(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_308(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_308(xs) / xs.length;
}
export function wf_var_308(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_308(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_309(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_309(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_309(xs) / xs.length;
}
export function wf_var_309(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_309(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_310(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_310(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_310(xs) / xs.length;
}
export function wf_var_310(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_310(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_311(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_311(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_311(xs) / xs.length;
}
export function wf_var_311(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_311(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_312(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_312(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_312(xs) / xs.length;
}
export function wf_var_312(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_312(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_313(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_313(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_313(xs) / xs.length;
}
export function wf_var_313(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_313(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_314(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_314(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_314(xs) / xs.length;
}
export function wf_var_314(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_314(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_315(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_315(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_315(xs) / xs.length;
}
export function wf_var_315(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_315(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_316(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_316(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_316(xs) / xs.length;
}
export function wf_var_316(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_316(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_317(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_317(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_317(xs) / xs.length;
}
export function wf_var_317(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_317(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_318(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_318(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_318(xs) / xs.length;
}
export function wf_var_318(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_318(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_319(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_319(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_319(xs) / xs.length;
}
export function wf_var_319(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_319(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_320(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_320(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_320(xs) / xs.length;
}
export function wf_var_320(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_320(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_321(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_321(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_321(xs) / xs.length;
}
export function wf_var_321(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_321(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_322(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_322(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_322(xs) / xs.length;
}
export function wf_var_322(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_322(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_323(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_323(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_323(xs) / xs.length;
}
export function wf_var_323(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_323(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_324(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_324(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_324(xs) / xs.length;
}
export function wf_var_324(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_324(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_325(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_325(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_325(xs) / xs.length;
}
export function wf_var_325(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_325(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_326(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_326(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_326(xs) / xs.length;
}
export function wf_var_326(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_326(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_327(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_327(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_327(xs) / xs.length;
}
export function wf_var_327(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_327(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_328(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_328(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_328(xs) / xs.length;
}
export function wf_var_328(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_328(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_329(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_329(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_329(xs) / xs.length;
}
export function wf_var_329(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_329(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_330(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_330(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_330(xs) / xs.length;
}
export function wf_var_330(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_330(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_331(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_331(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_331(xs) / xs.length;
}
export function wf_var_331(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_331(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_332(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_332(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_332(xs) / xs.length;
}
export function wf_var_332(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_332(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_333(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_333(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_333(xs) / xs.length;
}
export function wf_var_333(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_333(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_334(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_334(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_334(xs) / xs.length;
}
export function wf_var_334(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_334(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_335(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_335(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_335(xs) / xs.length;
}
export function wf_var_335(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_335(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_336(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_336(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_336(xs) / xs.length;
}
export function wf_var_336(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_336(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_337(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_337(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_337(xs) / xs.length;
}
export function wf_var_337(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_337(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_338(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_338(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_338(xs) / xs.length;
}
export function wf_var_338(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_338(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_339(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_339(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_339(xs) / xs.length;
}
export function wf_var_339(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_339(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_340(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_340(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_340(xs) / xs.length;
}
export function wf_var_340(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_340(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_341(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_341(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_341(xs) / xs.length;
}
export function wf_var_341(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_341(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_342(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_342(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_342(xs) / xs.length;
}
export function wf_var_342(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_342(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_343(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_343(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_343(xs) / xs.length;
}
export function wf_var_343(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_343(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_344(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_344(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_344(xs) / xs.length;
}
export function wf_var_344(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_344(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_345(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_345(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_345(xs) / xs.length;
}
export function wf_var_345(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_345(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_346(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_346(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_346(xs) / xs.length;
}
export function wf_var_346(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_346(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_347(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_347(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_347(xs) / xs.length;
}
export function wf_var_347(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_347(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_348(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_348(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_348(xs) / xs.length;
}
export function wf_var_348(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_348(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_349(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_349(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_349(xs) / xs.length;
}
export function wf_var_349(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_349(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_350(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_350(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_350(xs) / xs.length;
}
export function wf_var_350(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_350(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_351(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_351(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_351(xs) / xs.length;
}
export function wf_var_351(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_351(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_352(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_352(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_352(xs) / xs.length;
}
export function wf_var_352(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_352(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_353(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_353(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_353(xs) / xs.length;
}
export function wf_var_353(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_353(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_354(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_354(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_354(xs) / xs.length;
}
export function wf_var_354(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_354(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_355(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_355(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_355(xs) / xs.length;
}
export function wf_var_355(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_355(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_356(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_356(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_356(xs) / xs.length;
}
export function wf_var_356(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_356(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_357(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_357(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_357(xs) / xs.length;
}
export function wf_var_357(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_357(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_358(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_358(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_358(xs) / xs.length;
}
export function wf_var_358(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_358(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_359(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_359(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_359(xs) / xs.length;
}
export function wf_var_359(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_359(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_360(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_360(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_360(xs) / xs.length;
}
export function wf_var_360(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_360(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_361(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_361(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_361(xs) / xs.length;
}
export function wf_var_361(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_361(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_362(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_362(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_362(xs) / xs.length;
}
export function wf_var_362(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_362(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_363(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_363(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_363(xs) / xs.length;
}
export function wf_var_363(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_363(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_364(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_364(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_364(xs) / xs.length;
}
export function wf_var_364(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_364(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_365(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_365(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_365(xs) / xs.length;
}
export function wf_var_365(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_365(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_366(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_366(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_366(xs) / xs.length;
}
export function wf_var_366(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_366(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_367(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_367(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_367(xs) / xs.length;
}
export function wf_var_367(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_367(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_368(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_368(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_368(xs) / xs.length;
}
export function wf_var_368(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_368(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_369(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_369(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_369(xs) / xs.length;
}
export function wf_var_369(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_369(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_370(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_370(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_370(xs) / xs.length;
}
export function wf_var_370(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_370(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_371(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_371(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_371(xs) / xs.length;
}
export function wf_var_371(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_371(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_372(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_372(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_372(xs) / xs.length;
}
export function wf_var_372(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_372(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_373(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_373(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_373(xs) / xs.length;
}
export function wf_var_373(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_373(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_374(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_374(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_374(xs) / xs.length;
}
export function wf_var_374(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_374(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_375(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_375(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_375(xs) / xs.length;
}
export function wf_var_375(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_375(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_376(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_376(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_376(xs) / xs.length;
}
export function wf_var_376(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_376(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_377(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_377(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_377(xs) / xs.length;
}
export function wf_var_377(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_377(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_378(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_378(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_378(xs) / xs.length;
}
export function wf_var_378(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_378(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_379(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_379(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_379(xs) / xs.length;
}
export function wf_var_379(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_379(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_380(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_380(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_380(xs) / xs.length;
}
export function wf_var_380(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_380(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_381(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_381(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_381(xs) / xs.length;
}
export function wf_var_381(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_381(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_382(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_382(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_382(xs) / xs.length;
}
export function wf_var_382(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_382(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_383(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_383(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_383(xs) / xs.length;
}
export function wf_var_383(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_383(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_384(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_384(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_384(xs) / xs.length;
}
export function wf_var_384(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_384(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_385(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_385(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_385(xs) / xs.length;
}
export function wf_var_385(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_385(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_386(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_386(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_386(xs) / xs.length;
}
export function wf_var_386(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_386(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_387(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_387(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_387(xs) / xs.length;
}
export function wf_var_387(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_387(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_388(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_388(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_388(xs) / xs.length;
}
export function wf_var_388(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_388(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_389(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_389(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_389(xs) / xs.length;
}
export function wf_var_389(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_389(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_390(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_390(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_390(xs) / xs.length;
}
export function wf_var_390(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_390(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_391(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_391(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_391(xs) / xs.length;
}
export function wf_var_391(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_391(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_392(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_392(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_392(xs) / xs.length;
}
export function wf_var_392(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_392(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_393(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_393(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_393(xs) / xs.length;
}
export function wf_var_393(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_393(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_394(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_394(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_394(xs) / xs.length;
}
export function wf_var_394(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_394(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_395(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_395(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_395(xs) / xs.length;
}
export function wf_var_395(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_395(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_396(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_396(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_396(xs) / xs.length;
}
export function wf_var_396(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_396(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_397(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_397(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_397(xs) / xs.length;
}
export function wf_var_397(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_397(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_398(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_398(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_398(xs) / xs.length;
}
export function wf_var_398(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_398(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

export function wf_sum_399(xs: readonly number[]): number {
  let s = 0; for (const x of xs) s += x; return s;
}
export function wf_mean_399(xs: readonly number[]): number {
  if (xs.length === 0) return 0; return wf_sum_399(xs) / xs.length;
}
export function wf_var_399(xs: readonly number[]): number {
  if (xs.length < 2) return 0; const m = wf_mean_399(xs);
  let v = 0; for (const x of xs) v += (x - m) ** 2; return v / (xs.length - 1);
}

