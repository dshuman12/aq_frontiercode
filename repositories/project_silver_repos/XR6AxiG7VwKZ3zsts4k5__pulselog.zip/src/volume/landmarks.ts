import { MuscleGroup } from '../types/core.js';
import type { VolumeLandmarkSet } from '../types/core.js';

export const DEFAULT_LANDMARKS: readonly VolumeLandmarkSet[] = [
  { muscle: MuscleGroup.Chest, MV: 6, MEV: 8, MAV: 16, MRV: 22 },
  { muscle: MuscleGroup.Back, MV: 8, MEV: 10, MAV: 18, MRV: 25 },
  { muscle: MuscleGroup.Quads, MV: 8, MEV: 10, MAV: 18, MRV: 24 },
  { muscle: MuscleGroup.Hamstrings, MV: 4, MEV: 6, MAV: 12, MRV: 18 },
];

export function landmarkForMuscle(m: MuscleGroup): VolumeLandmarkSet | undefined {
  return DEFAULT_LANDMARKS.find((x) => x.muscle === m);
}
