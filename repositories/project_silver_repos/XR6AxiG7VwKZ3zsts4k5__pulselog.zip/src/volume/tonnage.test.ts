import { describe, it, expect } from 'vitest';
import { blockTonnageKg } from './tonnage.js';
describe('ton', () => {
  it('bw0', () =>
    expect(blockTonnageKg({ exerciseId: 'pull-up', exerciseName: 'p', sets: [{ reps: 8, weightKg: 90 }] }, 90)).toBe(0));
  it('dip', () =>
    expect(blockTonnageKg({ exerciseId: 'dip', exerciseName: 'd', sets: [{ reps: 5, weightKg: 105 }] }, 100)).toBe(25));
  for (let i = 0; i < 8; i++)
    it(`x${i}`, () =>
      expect(
        blockTonnageKg({ exerciseId: 'bench-press', exerciseName: 'b', sets: [{ reps: 5, weightKg: 100 }] }),
      ).toBe(500));
});
