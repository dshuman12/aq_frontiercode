import { describe, it, expect } from 'vitest';
import { estimateEffectiveReps } from './effectiveReps.js';
describe('eff', () => {
  it('r', () => expect(estimateEffectiveReps({ reps: 10, weightKg: 1, rir: 0 })).toBeGreaterThanOrEqual(5));
  for (let i = 0; i < 10; i++) it(`e${i}`, () => expect(estimateEffectiveReps({ reps: 5, weightKg: 1 })).toBeGreaterThan(0));
});
