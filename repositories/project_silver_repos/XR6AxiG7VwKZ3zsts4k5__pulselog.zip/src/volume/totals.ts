import type { WorkoutSession, WorkoutSet } from '../types/core.js';
export type VolumeMode = 'all' | 'working';

function isWorkingSet(set: WorkoutSet): boolean {
  if (set.isWarmup) return false;
  if (set.rpe !== undefined && set.rpe < 6) return false;
  return true;
}

export function totalReps(sessions: readonly WorkoutSession[], mode: VolumeMode = 'working'): number {
  let n = 0;
  for (const s of sessions) {
    for (const b of s.blocks) {
      for (const st of b.sets) {
        if (mode === 'working' && !isWorkingSet(st)) continue;
        n += st.reps;
      }
    }
  }
  return n;
}

export function totalSets(sessions: readonly WorkoutSession[], mode: VolumeMode = 'working'): number {
  let n = 0;
  for (const s of sessions) {
    for (const b of s.blocks) {
      for (const st of b.sets) {
        if (mode === 'working' && !isWorkingSet(st)) continue;
        n++;
      }
    }
  }
  return n;
}
