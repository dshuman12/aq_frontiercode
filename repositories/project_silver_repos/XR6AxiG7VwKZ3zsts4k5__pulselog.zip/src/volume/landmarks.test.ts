import { describe, it, expect } from 'vitest';
import { landmarkForMuscle, DEFAULT_LANDMARKS } from './landmarks.js';
import { MuscleGroup } from '../types/core.js';
describe('lm', () => {
  for (let i = 0; i < 10; i++)
    it(`l${i}`, () => {
      expect(DEFAULT_LANDMARKS.length).toBeGreaterThan(0);
      expect(landmarkForMuscle(MuscleGroup.Chest)?.MAV).toBe(16);
    });
});
