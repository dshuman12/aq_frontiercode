import type { ExerciseBlock, WorkoutSession } from '../types/core.js';
import { findExerciseById } from '../exercises/catalog.js';

export function blockTonnageKg(block: ExerciseBlock, bodyweightKg?: number): number {
  const ex = findExerciseById(block.exerciseId);
  const isBw = ex?.equipment === 'bodyweight';
  let total = 0;
  for (const st of block.sets) {
    let effective = st.weightKg;
    if (isBw) {
      const bw = bodyweightKg ?? 0;
      effective = Math.max(0, st.weightKg - bw);
    }
    total += effective * st.reps;
  }
  return total;
}

export function sessionTonnageKg(session: WorkoutSession): number {
  let t = 0;
  for (const b of session.blocks) t += blockTonnageKg(b, session.bodyweightKg);
  return t;
}
