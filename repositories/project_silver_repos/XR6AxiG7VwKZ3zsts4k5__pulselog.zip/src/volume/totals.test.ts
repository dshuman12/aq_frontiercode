import { describe, it, expect } from 'vitest';
import { totalReps, totalSets } from './totals.js';
import type { WorkoutSession } from '../types/core.js';
const S = (sets: { reps: number; weight: number; rpe?: number; w?: boolean }[]): WorkoutSession => ({
  id: 's',
  startedAt: new Date(),
  endedAt: new Date(),
  blocks: [
    {
      exerciseId: 'bench-press',
      exerciseName: 'b',
      sets: sets.map((s) => ({ reps: s.reps, weightKg: s.weight, rpe: s.rpe, isWarmup: s.w })),
    },
  ],
});
describe('tot', () => {
  it('w', () => expect(totalReps([S([{ reps: 5, weight: 20, w: true }, { reps: 5, weight: 100 }])], 'working')).toBe(5));
  it('rpe', () =>
    expect(totalReps([S([{ reps: 5, weight: 40, rpe: 5 }, { reps: 5, weight: 100, rpe: 8 }])], 'working')).toBe(5));
  for (let i = 0; i < 10; i++)
    it(`t${i}`, () => expect(totalReps([S([{ reps: 1, weight: 1, rpe: 8 }])], 'working')).toBe(1));
});
