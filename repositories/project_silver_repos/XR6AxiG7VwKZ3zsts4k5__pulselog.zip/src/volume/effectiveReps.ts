import type { WorkoutSet } from '../types/core.js';

export function estimateEffectiveReps(set: WorkoutSet): number {
  const rir = set.rir ?? (set.rpe !== undefined ? 10 - set.rpe : 2);
  const cutoff = Math.max(0, 5 - rir);
  return Math.max(0, set.reps - cutoff);
}
