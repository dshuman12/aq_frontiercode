import type { WorkoutSession } from '../types/core.js';

export function sessionToCsvRows(session: WorkoutSession): string {
  const header = 'exercise,reps,weightKg,rpe\n';
  const rows: string[] = [header];
  for (const b of session.blocks) {
    for (const st of b.sets) {
      rows.push(`${b.exerciseName},${st.reps},${st.weightKg},${st.rpe ?? ''}\n`);
    }
  }
  return rows.join('');
}
