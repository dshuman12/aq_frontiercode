import type { WorkoutSession } from '../types/core.js';

export function prettyPrintSession(session: WorkoutSession): string {
  return JSON.stringify(session, null, 2);
}
