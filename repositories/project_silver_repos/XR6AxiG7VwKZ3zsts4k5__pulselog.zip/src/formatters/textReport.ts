import type { WorkoutSession } from '../types/core.js';
import { summarizeSession } from '../analytics/sessionStats.js';

export function formatSessionText(session: WorkoutSession): string {
  const st = summarizeSession(session);
  const lines: string[] = [];
  lines.push(`Session ${session.id}`);
  lines.push(`Duration: ${st.durationMin.toFixed(1)} min`);
  lines.push(`Tonnage: ${st.tonnageKg.toFixed(1)} kg·reps`);
  lines.push(`Working sets: ${st.workingSets}`);
  return lines.join('\n');
}
