import { describe, it, expect } from 'vitest';
import { formatSessionText } from './textReport.js';
import { sessionToCsvRows } from './csvExport.js';
import { sessionToMarkdown } from './markdown.js';
import type { WorkoutSession } from '../types/core.js';
const S: WorkoutSession = { id: 'demo', startedAt: new Date(0), endedAt: new Date(3600000), blocks: [
  { exerciseId: 'squat', exerciseName: 'Squat', sets: [{ reps: 5, weightKg: 100, rpe: 8 }] },
]};
describe('fmt', () => {
  for (let i = 0; i < 9; i++)
    it(`f${i}`, () => {
      expect(formatSessionText(S)).toContain('demo');
      expect(sessionToCsvRows(S)).toContain('100');
      expect(sessionToMarkdown(S).split('\n').length).toBeGreaterThanOrEqual(3);
    });
});
