import type { WorkoutSession } from '../types/core.js';

export function sessionToJson(session: WorkoutSession): string {
  return JSON.stringify(session, (_k, v) => (v instanceof Date ? v.toISOString() : v), 2);
}
