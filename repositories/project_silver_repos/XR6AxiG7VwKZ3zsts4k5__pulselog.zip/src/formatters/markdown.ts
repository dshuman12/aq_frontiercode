import type { WorkoutSession } from '../types/core.js';

export function sessionToMarkdown(session: WorkoutSession): string {
  const lines: string[] = [];
  lines.push(`## ${session.id}`);
  for (const b of session.blocks) {
    lines.push(`- **${b.exerciseName}**`);
    for (const st of b.sets) lines.push(`  - ${st.reps}×${st.weightKg}kg`);
  }
  return lines.join('\n');
}
