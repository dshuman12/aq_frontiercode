import { MuscleGroup } from '../types/core.js';

export function muscleRecoveryEtaHours(m: MuscleGroup, hardSets: number): number {
  const base = m === MuscleGroup.Quads || m === MuscleGroup.Hamstrings ? 48 : 36;
  return base + hardSets * 4;
}
