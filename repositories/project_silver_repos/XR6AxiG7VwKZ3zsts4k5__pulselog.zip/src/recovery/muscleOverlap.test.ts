import { describe, it, expect } from 'vitest';
import { allMusclesForExercise, getIndirectFatigueMuscles } from './muscleOverlap.js';
import { findExerciseById } from '../exercises/catalog.js';
import { MuscleGroup } from '../types/core.js';
describe('ov', () => {
  it('bench', () => expect(allMusclesForExercise(findExerciseById('bench-press')!).includes(MuscleGroup.Triceps)).toBe(true));
  for (let i = 0; i < 10; i++) it(`o${i}`, () => expect(getIndirectFatigueMuscles(MuscleGroup.Chest).includes(MuscleGroup.Triceps)).toBe(true));
});
