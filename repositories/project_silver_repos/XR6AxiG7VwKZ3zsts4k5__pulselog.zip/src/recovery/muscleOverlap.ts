import { MuscleGroup } from '../types/core.js';
import type { Exercise } from '../types/core.js';

const OVERLAP: ReadonlyArray<readonly [MuscleGroup, MuscleGroup]> = [
  [MuscleGroup.Chest, MuscleGroup.Triceps],
  [MuscleGroup.Back, MuscleGroup.Biceps],
  [MuscleGroup.Shoulders, MuscleGroup.Triceps],
];

export function getIndirectFatigueMuscles(primary: MuscleGroup): MuscleGroup[] {
  const extra = new Set<MuscleGroup>();
  for (const [a, b] of OVERLAP) {
    if (a === primary) extra.add(b);
    if (b === primary) extra.add(a);
  }
  return [...extra];
}

export function allMusclesForExercise(ex: Exercise): MuscleGroup[] {
  const s = new Set<MuscleGroup>([...ex.primaryMuscles, ...ex.secondaryMuscles]);
  for (const p of ex.primaryMuscles) {
    for (const x of getIndirectFatigueMuscles(p)) s.add(x);
  }
  return [...s];
}
