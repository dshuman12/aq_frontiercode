import type { WorkoutSession } from '../types/core.js';
import { sessionTonnageKg } from '../volume/tonnage.js';

export function recoveryScoreFromLastSession(session: WorkoutSession | undefined): number {
  if (!session) return 100;
  const load = sessionTonnageKg(session);
  const hours = Math.max(1, (Date.now() - session.endedAt.getTime()) / 3600000);
  const fatigue = load / (10 + hours);
  return Math.max(0, Math.min(100, 100 - fatigue));
}
