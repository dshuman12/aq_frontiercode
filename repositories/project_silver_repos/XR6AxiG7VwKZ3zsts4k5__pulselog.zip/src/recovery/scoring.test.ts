import { describe, it, expect } from 'vitest';
import { recoveryScoreFromLastSession } from './scoring.js';
import type { WorkoutSession } from '../types/core.js';
describe('sc', () => {
  it('undef', () => expect(recoveryScoreFromLastSession(undefined)).toBe(100));
  it('sess', () => {
    const s: WorkoutSession = {
      id: 'x',
      startedAt: new Date(Date.now() - 86400000),
      endedAt: new Date(Date.now() - 86400000),
      blocks: [{ exerciseId: 'bench-press', exerciseName: 'b', sets: [{ reps: 10, weightKg: 100, rpe: 10 }] }],
    };
    expect(recoveryScoreFromLastSession(s)).toBeLessThan(100);
  });
  for (let i = 0; i < 8; i++) it(`b${i}`, () => expect(recoveryScoreFromLastSession({ id: 'y', startedAt: new Date(), endedAt: new Date(), blocks: [] })).toBeGreaterThanOrEqual(0));
});
