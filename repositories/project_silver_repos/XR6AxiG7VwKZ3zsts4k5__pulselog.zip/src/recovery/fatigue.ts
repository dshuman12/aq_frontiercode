export function fitnessFatigueResponse(daysSince: number, impulseFitness: number, impulseFatigue: number): number {
  const tauF = 42;
  const tauC = 7;
  const fitness = impulseFitness * (1 - Math.exp(-daysSince / tauF));
  const fatigue = impulseFatigue * (1 - Math.exp(-daysSince / tauC));
  return fitness - fatigue;
}
