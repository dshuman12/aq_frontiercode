export function readinessFromSleepQualityHours(sleepHours: number, quality01: number): number {
  const h = Math.min(10, Math.max(4, sleepHours));
  const base = (h - 4) * 12.5;
  return Math.max(0, Math.min(100, base * quality01));
}
