/** Muscle groups tracked for volume, recovery, and split analysis */
export enum MuscleGroup {
  Chest = 'chest',
  Back = 'back',
  Shoulders = 'shoulders',
  Biceps = 'biceps',
  Triceps = 'triceps',
  Forearms = 'forearms',
  Quads = 'quads',
  Hamstrings = 'hamstrings',
  Glutes = 'glutes',
  Calves = 'calves',
  Abs = 'abs',
  Neck = 'neck',
  Other = 'other',
}

/** High-level movement pattern for exercise taxonomy */
export enum MovementPattern {
  Squat = 'squat',
  Hinge = 'hinge',
  HorizontalPush = 'horizontal_push',
  VerticalPush = 'vertical_push',
  HorizontalPull = 'horizontal_pull',
  VerticalPull = 'vertical_pull',
  Lunge = 'lunge',
  Carry = 'carry',
  CoreFlexion = 'core_flexion',
  CoreExtension = 'core_extension',
  Accessory = 'accessory',
  Isolation = 'isolation',
}

/** Broad exercise category for analytics filters */
export enum ExerciseCategory {
  Strength = 'strength',
  Hypertrophy = 'hypertrophy',
  Conditioning = 'conditioning',
  Mobility = 'mobility',
  Skill = 'skill',
  Rehab = 'rehab',
}

export type Equipment =
  | 'barbell'
  | 'dumbbell'
  | 'cable'
  | 'machine'
  | 'kettlebell'
  | 'bodyweight'
  | 'band'
  | 'other';

export interface Exercise {
  readonly id: string;
  readonly name: string;
  readonly aliases: readonly string[];
  readonly primaryMuscles: readonly MuscleGroup[];
  readonly secondaryMuscles: readonly MuscleGroup[];
  readonly pattern: MovementPattern;
  readonly category: ExerciseCategory;
  readonly equipment: Equipment;
  readonly isCompound: boolean;
}

export interface WorkoutSet {
  readonly reps: number;
  readonly weightKg: number;
  readonly rpe?: number;
  readonly rir?: number;
  readonly distanceM?: number;
  readonly durationSec?: number;
  readonly notes?: string;
  readonly isWarmup?: boolean;
}

export interface ExerciseBlock {
  readonly exerciseId: string;
  readonly exerciseName: string;
  readonly sets: readonly WorkoutSet[];
  readonly restSecAvg?: number;
}

export interface WorkoutSession {
  readonly id: string;
  readonly startedAt: Date;
  readonly endedAt: Date;
  readonly blocks: readonly ExerciseBlock[];
  readonly bodyweightKg?: number;
  readonly notes?: string;
  readonly tags?: readonly string[];
}

export interface TrainingBlock {
  readonly id: string;
  readonly name: string;
  readonly start: Date;
  readonly end: Date;
  readonly sessions: readonly WorkoutSession[];
  readonly focus?: ExerciseCategory;
}

export interface VolumeLandmarkSet {
  readonly muscle: MuscleGroup;
  readonly MV: number;
  readonly MEV: number;
  readonly MAV: number;
  readonly MRV: number;
}
