import { describe, it, expect } from 'vitest';
import { MuscleGroup, MovementPattern } from './core.js';
describe('core types', () => {
  for (let i = 0; i < 12; i++) {
    it(`enum sanity ${i}`, () => {
      expect(MuscleGroup.Chest).toBe('chest');
      expect(MovementPattern.Squat).toBe('squat');
    });
  }
});
