import { describe, it, expect } from 'vitest';
import { suggestSubstitutions } from './substitution.js';
import { MuscleGroup } from '../types/core.js';
describe('sub', () => {
  for (let i = 0; i < 8; i++) it(`s${i}`, () => expect(suggestSubstitutions(MuscleGroup.Chest, 'bench-press').length).toBeGreaterThan(0));
});
