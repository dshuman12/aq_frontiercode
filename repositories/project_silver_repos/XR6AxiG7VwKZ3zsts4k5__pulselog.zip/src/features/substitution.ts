import { MuscleGroup } from '../types/core.js';
import { getDefaultCatalog } from '../exercises/catalog.js';

export function suggestSubstitutions(muscle: MuscleGroup, excludeId: string): string[] {
  const out: string[] = [];
  for (const ex of getDefaultCatalog()) {
    if (ex.id === excludeId) continue;
    if (ex.primaryMuscles.includes(muscle)) out.push(ex.id);
  }
  return out.slice(0, 5);
}
