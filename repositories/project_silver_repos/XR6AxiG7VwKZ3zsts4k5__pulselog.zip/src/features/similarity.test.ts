import { describe, it, expect } from 'vitest';
import { sessionExerciseSimilarity } from './similarity.js';
import type { WorkoutSession } from '../types/core.js';
const mk = (ids: string[]): WorkoutSession => ({
  id: 'x',
  startedAt: new Date(),
  endedAt: new Date(),
  blocks: ids.map((i) => ({ exerciseId: i, exerciseName: i, sets: [{ reps: 1, weightKg: 1, rpe: 8 }] })),
});
describe('sim', () => {
  it('id', () => expect(sessionExerciseSimilarity(mk(['a', 'b']), mk(['a', 'b']))).toBe(1));
  for (let i = 0; i < 10; i++) it(`s${i}`, () => expect(sessionExerciseSimilarity(mk(['a']), mk(['b']))).toBe(0));
});
