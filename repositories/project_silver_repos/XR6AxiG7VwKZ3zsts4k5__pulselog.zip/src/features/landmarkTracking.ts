import { MuscleGroup } from '../types/core.js';
import type { VolumeLandmarkSet } from '../types/core.js';
import { DEFAULT_LANDMARKS } from '../volume/landmarks.js';

export type LandmarkBand = 'below_MV' | 'MEV_to_MAV' | 'MAV_to_MRV' | 'above_MRV';

export function bandForWeeklySets(
  muscle: MuscleGroup,
  weeklySets: number,
  table: readonly VolumeLandmarkSet[] = DEFAULT_LANDMARKS,
): LandmarkBand {
  const L = table.find((x) => x.muscle === muscle);
  if (!L) return 'MEV_to_MAV';
  if (weeklySets < L.MEV) return 'below_MV';
  if (weeklySets < L.MAV) return 'MEV_to_MAV';
  if (weeklySets <= L.MRV) return 'MAV_to_MRV';
  return 'above_MRV';
}
