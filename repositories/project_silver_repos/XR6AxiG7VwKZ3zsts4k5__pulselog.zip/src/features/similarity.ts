import type { WorkoutSession } from '../types/core.js';

function jaccard(a: Set<string>, b: Set<string>): number {
  let inter = 0;
  for (const x of a) if (b.has(x)) inter++;
  const union = a.size + b.size - inter;
  return union === 0 ? 1 : inter / union;
}

export function sessionExerciseSimilarity(a: WorkoutSession, b: WorkoutSession): number {
  const sa = new Set(a.blocks.map((x) => x.exerciseId));
  const sb = new Set(b.blocks.map((x) => x.exerciseId));
  return jaccard(sa, sb);
}
