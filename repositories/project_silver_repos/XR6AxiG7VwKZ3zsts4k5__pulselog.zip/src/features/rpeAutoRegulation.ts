import type { WorkoutSet } from '../types/core.js';

export interface AutoRegOptions { readonly targetRpe: number; readonly stepKg: number; }

export function suggestNextWeightFromRpe(previous: WorkoutSet, options: AutoRegOptions): number {
  const delta = (options.targetRpe - (previous.rpe ?? options.targetRpe)) * options.stepKg;
  return Math.max(0, previous.weightKg + delta);
}
