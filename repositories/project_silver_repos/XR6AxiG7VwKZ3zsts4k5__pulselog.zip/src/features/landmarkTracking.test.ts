import { describe, it, expect } from 'vitest';
import { bandForWeeklySets } from './landmarkTracking.js';
import { MuscleGroup } from '../types/core.js';
describe('lm', () => {
  for (let i = 0; i < 10; i++) it(`b${i}`, () => expect(bandForWeeklySets(MuscleGroup.Chest, 4)).toBe('below_MV'));
});
