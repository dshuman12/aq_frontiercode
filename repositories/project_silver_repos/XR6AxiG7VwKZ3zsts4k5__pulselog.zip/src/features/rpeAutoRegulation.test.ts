import { describe, it, expect } from 'vitest';
import { suggestNextWeightFromRpe } from './rpeAutoRegulation.js';
describe('ar', () => {
  for (let i = 0; i < 10; i++)
    it(`a${i}`, () =>
      expect(suggestNextWeightFromRpe({ reps: 5, weightKg: 100, rpe: 7 }, { targetRpe: 8, stepKg: 2.5 })).toBe(102.5));
});
