import { describe, it, expect } from 'vitest';
import { isNewPr } from './pr.js';
describe('pr', () => {
  const h = [{ reps: 5, weightKg: 100 }];
  it('trg', () => expect(isNewPr(h, { reps: 5, weightKg: 110 }, { targetReps: 5 })).toBe(true));
  for (let i = 0; i < 9; i++) it(`p${i}`, () => expect(isNewPr([], { reps: 5, weightKg: 50 }, { targetReps: 5 })).toBe(true));
});
