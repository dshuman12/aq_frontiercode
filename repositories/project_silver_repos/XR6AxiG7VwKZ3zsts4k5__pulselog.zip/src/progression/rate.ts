export function weeklyChangeKgPerWeek(points: readonly number[]): number {
  if (points.length < 2) return 0;
  const first = points[0] ?? 0;
  const last = points[points.length - 1] ?? 0;
  return (last - first) / (points.length - 1);
}
