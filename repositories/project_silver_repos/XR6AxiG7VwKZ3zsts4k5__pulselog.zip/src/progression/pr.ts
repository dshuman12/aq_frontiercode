import type { WorkoutSet } from '../types/core.js';

export interface PrCheckOptions { readonly targetReps?: number; }

export function isNewPr(
  historyBest: { reps: number; weightKg: number }[],
  candidate: WorkoutSet,
  options: PrCheckOptions = {},
): boolean {
  const tgt = options.targetReps;
  if (tgt !== undefined) {
    const same = historyBest.filter((h) => h.reps === tgt);
    const bestW = same.length ? Math.max(...same.map((s) => s.weightKg)) : 0;
    return candidate.reps === tgt && candidate.weightKg > bestW + 1e-6;
  }
  const bestOverall = historyBest.length ? Math.max(...historyBest.map((h) => h.weightKg)) : 0;
  return candidate.weightKg > bestOverall + 1e-6;
}
