export function detectPlateau(est1RmSeries: readonly number[], windowSize: number, epsilonKg: number): boolean {
  if (est1RmSeries.length < windowSize || windowSize < 2) return false;
  const startIdx = est1RmSeries.length - windowSize;
  const first = est1RmSeries[startIdx] ?? 0;
  const last = est1RmSeries[est1RmSeries.length - 1] ?? 0;
  return last - first < epsilonKg;
}

export function windowMean(values: readonly number[]): number {
  if (values.length === 0) return 0;
  return values.reduce((a, b) => a + b, 0) / values.length;
}
