import { describe, it, expect } from 'vitest';
import { bestEstimated1RmKgPerSession, isLinearImprovement } from './linear.js';
import type { WorkoutSession } from '../types/core.js';
describe('lin', () => {
  it('series', () => {
    const a: WorkoutSession = { id:'1', startedAt:new Date(), endedAt:new Date(),
      blocks:[{ exerciseId:'squat', exerciseName:'s', sets:[{ reps:5, weightKg:100 }]}]};
    const b: WorkoutSession = { ...a, id:'2', blocks:[{ exerciseId:'squat', exerciseName:'s', sets:[{ reps:5, weightKg:105 }]}]};
    expect(bestEstimated1RmKgPerSession([a, b], 'squat')[1]).toBeGreaterThan(bestEstimated1RmKgPerSession([a, b], 'squat')[0]!);
  });
  for (let i = 0; i < 8; i++) it(`l${i}`, () => expect(isLinearImprovement([100,102,104],1.5)).toBe(true));
});
