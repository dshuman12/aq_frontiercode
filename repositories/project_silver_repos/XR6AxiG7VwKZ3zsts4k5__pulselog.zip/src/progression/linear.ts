import type { WorkoutSession } from '../types/core.js';
import { estimateOneRm } from '../intensity/oneRm.js';

export function bestEstimated1RmKgPerSession(sessions: readonly WorkoutSession[], exerciseId: string): number[] {
  const out: number[] = [];
  for (const s of sessions) {
    let best = 0;
    const block = s.blocks.find((b) => b.exerciseId === exerciseId);
    if (!block) { out.push(0); continue; }
    for (const st of block.sets) {
      const e = estimateOneRm(st.weightKg, st.reps);
      if (e > best) best = e;
    }
    out.push(best);
  }
  return out;
}

export function isLinearImprovement(series: readonly number[], minDelta: number): boolean {
  if (series.length < 2) return true;
  for (let i = 1; i < series.length; i++) {
    const prev = series[i - 1] ?? 0;
    const cur = series[i] ?? 0;
    if (cur + 1e-6 < prev + minDelta) return false;
  }
  return true;
}
