import { describe, it, expect } from 'vitest';
import { standardFromSquatRatio, totalBarLoadKg } from './standards.js';
describe('std', () => {
  it('bar', () => expect(totalBarLoadKg(20, 100)).toBe(120));
  it('sq', () => expect(standardFromSquatRatio(100, 70)).toBe('novice'));
  for (let i = 0; i < 10; i++) it(`s${i}`, () => expect(totalBarLoadKg(0, 140)).toBe(140));
});
