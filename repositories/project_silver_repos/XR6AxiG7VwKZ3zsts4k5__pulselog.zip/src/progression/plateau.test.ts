import { describe, it, expect } from 'vitest';
import { detectPlateau, windowMean } from './plateau.js';
describe('pl', () => {
  it('flat', () => expect(detectPlateau([100,100,100,100],4,1)).toBe(true));
  it('up', () => expect(detectPlateau([100,105,110,120],4,15)).toBe(false));
  for (let i = 0; i < 10; i++) it(`m${i}`, () => expect(windowMean([2,4,6])).toBe(4));
});
