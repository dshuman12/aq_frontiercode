export type StrengthStandard = 'novice' | 'intermediate' | 'advanced' | 'elite';
const SQ = [0.75, 1.25, 1.75, 2.25];

export function standardFromSquatRatio(bodyweightKg: number, squatKg: number): StrengthStandard {
  const r = squatKg / bodyweightKg;
  if (r < SQ[0]) return 'novice';
  if (r < SQ[1]) return 'intermediate';
  if (r < SQ[2]) return 'advanced';
  return 'elite';
}

export function totalBarLoadKg(barWeightKg: number, platesKg: number): number {
  return barWeightKg + platesKg;
}
