import { describe, it, expect } from 'vitest';
import { classifySessionSplit } from './detect.js';
import type { WorkoutSession } from '../types/core.js';
const S = (ids: string[]): WorkoutSession => ({
  id: 't',
  startedAt: new Date(),
  endedAt: new Date(),
  blocks: ids.map((id) => ({ exerciseId: id, exerciseName: id, sets: [{ reps: 5, weightKg: 40, rpe: 8 }] })),
});
describe('spl', () => {
  it('ppl', () => expect(classifySessionSplit(S(['pull-up', 'squat']))).toBe('ppl'));
  it('fb', () => expect(classifySessionSplit(S(['bench-press', 'barbell-row', 'squat']))).toBe('full_body'));
  for (let i = 0; i < 9; i++) it(`d${i}`, () => expect(typeof classifySessionSplit(S(['squat']))).toBe('string'));
});
