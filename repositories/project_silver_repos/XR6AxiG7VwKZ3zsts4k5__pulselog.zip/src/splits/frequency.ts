import type { WorkoutSession } from '../types/core.js';
import { MuscleGroup } from '../types/core.js';
import { findExerciseById } from '../exercises/catalog.js';
import { allMusclesForExercise } from '../recovery/muscleOverlap.js';

export function sessionsPerMusclePerWeek(sessions: readonly WorkoutSession[]): Map<MuscleGroup, number> {
  const weeks = new Map<string, Set<MuscleGroup>>();
  for (const s of sessions) {
    const key = `${s.startedAt.getUTCFullYear()}-W${Math.ceil(s.startedAt.getUTCDate() / 7)}`;
    const bag = weeks.get(key) ?? new Set<MuscleGroup>();
    for (const b of s.blocks) {
      const ex = findExerciseById(b.exerciseId);
      if (!ex) continue;
      for (const m of allMusclesForExercise(ex)) bag.add(m);
    }
    weeks.set(key, bag);
  }
  const counts = new Map<MuscleGroup, number>();
  for (const bag of weeks.values()) {
    for (const m of bag) counts.set(m, (counts.get(m) ?? 0) + 1);
  }
  return counts;
}
