import type { WorkoutSession } from '../types/core.js';
import { totalSets } from '../volume/totals.js';

export function volumeShare(sessionsByTag: Map<string, WorkoutSession[]>): Map<string, number> {
  const totals = new Map<string, number>();
  let sum = 0;
  for (const [tag, ses] of sessionsByTag) {
    const v = totalSets(ses, 'working');
    totals.set(tag, v);
    sum += v;
  }
  const share = new Map<string, number>();
  for (const [tag, v] of totals) share.set(tag, sum ? v / sum : 0);
  return share;
}
