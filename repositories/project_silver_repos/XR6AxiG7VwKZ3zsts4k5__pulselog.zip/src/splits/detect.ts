import type { WorkoutSession } from '../types/core.js';
import { MuscleGroup } from '../types/core.js';
import { findExerciseById } from '../exercises/catalog.js';
import { allMusclesForExercise } from '../recovery/muscleOverlap.js';

export type SplitLabel = 'ppl' | 'upper_lower' | 'full_body' | 'bro_split' | 'mixed';

function dominantMuscles(session: WorkoutSession): Set<MuscleGroup> {
  const s = new Set<MuscleGroup>();
  for (const b of session.blocks) {
    const ex = findExerciseById(b.exerciseId);
    if (!ex) continue;
    for (const m of allMusclesForExercise(ex)) s.add(m);
  }
  return s;
}

function isPushLike(m: Set<MuscleGroup>): boolean {
  return m.has(MuscleGroup.Chest) || m.has(MuscleGroup.Shoulders) || m.has(MuscleGroup.Triceps);
}
function isPullLike(m: Set<MuscleGroup>): boolean { return m.has(MuscleGroup.Back) || m.has(MuscleGroup.Biceps); }
function isLegLike(m: Set<MuscleGroup>): boolean {
  return m.has(MuscleGroup.Quads) || m.has(MuscleGroup.Hamstrings) || m.has(MuscleGroup.Glutes);
}

export function classifySessionSplit(session: WorkoutSession): SplitLabel {
  const m = dominantMuscles(session);
  const push = isPushLike(m);
  const pull = isPullLike(m);
  const leg = isLegLike(m);
  const total = [push, pull, leg].filter(Boolean).length;
  if (total >= 3) return 'full_body';
  if (push && leg && !pull) return 'ppl';
  if (pull && leg && !push) return 'ppl';
  if (push && pull && leg) return 'mixed';
  if (push && pull && !leg) return 'upper_lower';
  if (pull && leg && !push) return 'ppl';
  if ((push || pull) && leg) return 'ppl';
  if (push && !pull && !leg) return 'bro_split';
  return 'mixed';
}
