import type { WorkoutSet } from '../types/core.js';

export function timeUnderTensionSec(set: WorkoutSet, tempoSecPerRep = 3): number {
  return set.reps * tempoSecPerRep;
}
