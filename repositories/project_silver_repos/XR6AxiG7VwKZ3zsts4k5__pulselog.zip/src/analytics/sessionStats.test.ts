import { describe, it, expect } from 'vitest';
import { summarizeSession } from './sessionStats.js';
import type { WorkoutSession } from '../types/core.js';
describe('ss', () => {
  for (let i = 0; i < 8; i++)
    it(`s${i}`, () => {
      const s: WorkoutSession = { id: 'a', startedAt: new Date(0), endedAt: new Date(600000), blocks: [] };
      expect(summarizeSession(s).durationMin).toBe(10);
    });
});
