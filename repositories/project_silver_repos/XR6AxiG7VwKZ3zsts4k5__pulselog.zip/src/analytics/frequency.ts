import type { WorkoutSession } from '../types/core.js';

export function exerciseAppearanceCount(sessions: readonly WorkoutSession[], exerciseId: string): number {
  let n = 0;
  for (const s of sessions) {
    if (s.blocks.some((b) => b.exerciseId === exerciseId)) n++;
  }
  return n;
}
