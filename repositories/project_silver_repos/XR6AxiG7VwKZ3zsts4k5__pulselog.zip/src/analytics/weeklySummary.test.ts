import { describe, it, expect } from 'vitest';
import { sessionsByStartDay, weeklyWorkingSetTotals } from './weeklySummary.js';
import type { WorkoutSession } from '../types/core.js';
describe('wk', () => {
  it('mid', () => {
    const s: WorkoutSession = {
      id: 'x',
      startedAt: new Date('2026-02-10T23:00:00.000Z'),
      endedAt: new Date('2026-02-11T01:00:00.000Z'),
      blocks: [{ exerciseId: 'squat', exerciseName: 's', sets: [{ reps: 3, weightKg: 100, rpe: 8 }] }],
    };
    expect(sessionsByStartDay([s]).size).toBe(1);
  });
  for (let i = 0; i < 9; i++)
    it(`w${i}`, () => {
      const s: WorkoutSession = { id: 'y', startedAt: new Date(), endedAt: new Date(), blocks: [] };
      expect(weeklyWorkingSetTotals([s])).toBe(0);
    });
});
