export function linearRegressionSlope(xs: readonly number[], ys: readonly number[]): number {
  const n = Math.min(xs.length, ys.length);
  if (n < 2) return 0;
  let sumX = 0, sumY = 0;
  for (let i = 0; i < n; i++) { sumX += xs[i] ?? 0; sumY += ys[i] ?? 0; }
  const meanX = sumX / n, meanY = sumY / n;
  let num = 0, den = 0;
  for (let i = 0; i < n; i++) {
    const x = (xs[i] ?? 0) - meanX;
    const y = (ys[i] ?? 0) - meanY;
    num += x * y;
    den += x * x;
  }
  return den === 0 ? 0 : num / den;
}
