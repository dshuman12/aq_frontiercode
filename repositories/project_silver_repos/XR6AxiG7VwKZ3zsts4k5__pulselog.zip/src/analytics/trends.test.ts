import { describe, it, expect } from 'vitest';
import { linearRegressionSlope } from './trends.js';
describe('tr', () => {
  for (let i = 0; i < 10; i++) it(`t${i}`, () => expect(linearRegressionSlope([0, 1], [0, 2])).toBe(2));
});
