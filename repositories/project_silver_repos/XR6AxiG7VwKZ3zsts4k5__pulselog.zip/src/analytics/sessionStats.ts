import type { WorkoutSession } from '../types/core.js';
import { sessionTonnageKg } from '../volume/tonnage.js';
import { totalReps, totalSets } from '../volume/totals.js';

export interface SessionStatSummary {
  durationMin: number;
  tonnageKg: number;
  workingSets: number;
  reps: number;
}

export function summarizeSession(session: WorkoutSession): SessionStatSummary {
  const ms = session.endedAt.getTime() - session.startedAt.getTime();
  return {
    durationMin: Math.max(0, ms / 60000),
    tonnageKg: sessionTonnageKg(session),
    workingSets: totalSets([session], 'working'),
    reps: totalReps([session], 'working'),
  };
}
