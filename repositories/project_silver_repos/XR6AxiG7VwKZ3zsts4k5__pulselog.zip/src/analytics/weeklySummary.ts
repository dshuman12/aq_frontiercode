import type { WorkoutSession } from '../types/core.js';
import { totalSets } from '../volume/totals.js';

function dayKeyUTC(d: Date): string { return d.toISOString().slice(0, 10); }

export function sessionsByStartDay(sessions: readonly WorkoutSession[]): Map<string, WorkoutSession[]> {
  const m = new Map<string, WorkoutSession[]>();
  for (const s of sessions) {
    const k = dayKeyUTC(s.startedAt);
    const arr = m.get(k) ?? [];
    arr.push(s);
    m.set(k, arr);
  }
  return m;
}

export function weeklyWorkingSetTotals(sessions: readonly WorkoutSession[]): number {
  return totalSets(sessions, 'working');
}
