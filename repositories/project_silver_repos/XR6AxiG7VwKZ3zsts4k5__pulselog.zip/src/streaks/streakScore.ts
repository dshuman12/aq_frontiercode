import type { WorkoutSession } from '../types/core.js';
import { trainingDaysInRange } from './consistency.js';

export function longestStreakDays(sessions: readonly WorkoutSession[]): number {
  const days = [...trainingDaysInRange(sessions)].sort((a, b) => a - b);
  if (days.length === 0) return 0;
  let best = 1;
  let cur = 1;
  for (let i = 1; i < days.length; i++) {
    const prev = days[i - 1] ?? 0;
    const d = days[i] ?? 0;
    if (d - prev === 86400000) {
      cur++;
      best = Math.max(best, cur);
    } else {
      cur = 1;
    }
  }
  return best;
}
