import type { WorkoutSession } from '../types/core.js';

export function averageRestDaysBetween(sessions: readonly WorkoutSession[]): number {
  if (sessions.length < 2) return 0;
  const sorted = [...sessions].sort((a, b) => a.startedAt.getTime() - b.startedAt.getTime());
  let sum = 0;
  for (let i = 1; i < sorted.length; i++) {
    const a = sorted[i - 1]?.startedAt.getTime() ?? 0;
    const b = sorted[i]?.startedAt.getTime() ?? 0;
    sum += (b - a) / 86400000;
  }
  return sum / (sorted.length - 1);
}
