import { describe, it, expect } from 'vitest';
import { longestStreakDays } from './streakScore.js';
import type { WorkoutSession } from '../types/core.js';
const d = (y: number, m: number, day: number) => new Date(Date.UTC(y, m - 1, day));
describe('st', () => {
  it('2', () => {
    const xs: WorkoutSession[] = [
      { id: '1', startedAt: d(2026, 2, 1), endedAt: d(2026, 2, 1), blocks: [] },
      { id: '2', startedAt: d(2026, 2, 2), endedAt: d(2026, 2, 2), blocks: [] },
    ];
    expect(longestStreakDays(xs)).toBe(2);
  });
  for (let i = 0; i < 8; i++) it(`k${i}`, () => expect(longestStreakDays([])).toBe(0));
});
