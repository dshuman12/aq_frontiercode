import type { WorkoutSession } from '../types/core.js';

function dayStampUTC(d: Date): number {
  return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate());
}

export function trainingDaysInRange(sessions: readonly WorkoutSession[]): Set<number> {
  const s = new Set<number>();
  for (const x of sessions) s.add(dayStampUTC(x.startedAt));
  return s;
}
