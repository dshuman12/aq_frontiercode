"""Tests for app.utils.validators."""

import pytest
from app.utils.validators import (
    validate_task_name,
    validate_queue_name,
    validate_priority,
    validate_tags,
    validate_metadata,
    validate_cron_expression,
    validate_webhook_url,
    validate_timeout,
    validate_retry_config,
    validate_concurrency_limit,
    validate_batch_size,
)


class TestValidateTaskName:
    def test_valid(self):
        assert validate_task_name("send-email") == "send-email"

    def test_strips_whitespace(self):
        assert validate_task_name("  hello  ") == "hello"

    def test_empty(self):
        with pytest.raises(ValueError, match="not be empty"):
            validate_task_name("")

    def test_too_long(self):
        with pytest.raises(ValueError, match="exceeds"):
            validate_task_name("x" * 300)


class TestValidateQueueName:
    def test_valid(self):
        assert validate_queue_name("my.queue-1") == "my.queue-1"

    def test_empty(self):
        with pytest.raises(ValueError, match="not be empty"):
            validate_queue_name("")

    def test_invalid_chars(self):
        with pytest.raises(ValueError, match="must start"):
            validate_queue_name("123queue")

    def test_too_long(self):
        with pytest.raises(ValueError, match="exceeds"):
            validate_queue_name("q" * 200)


class TestValidatePriority:
    def test_valid(self):
        assert validate_priority(5) == 5

    def test_too_low(self):
        with pytest.raises(ValueError):
            validate_priority(0)

    def test_too_high(self):
        with pytest.raises(ValueError):
            validate_priority(100)


class TestValidateTags:
    def test_valid(self):
        result = validate_tags(["tag1", "tag2"])
        assert result == ["tag1", "tag2"]

    def test_dedup(self):
        result = validate_tags(["tag1", "TAG1", "tag2"])
        assert result == ["tag1", "tag2"]

    def test_too_many(self):
        with pytest.raises(ValueError, match="Maximum"):
            validate_tags([f"tag{i}" for i in range(20)])

    def test_invalid_chars(self):
        with pytest.raises(ValueError, match="must start"):
            validate_tags(["!invalid"])

    def test_empty_ignored(self):
        result = validate_tags(["tag1", "", "tag2"])
        assert result == ["tag1", "tag2"]


class TestValidateMetadata:
    def test_none(self):
        assert validate_metadata(None) is None

    def test_valid_dict(self):
        assert validate_metadata({"key": "value"}) == {"key": "value"}

    def test_not_dict(self):
        with pytest.raises(ValueError, match="JSON object"):
            validate_metadata("string")

    def test_too_large(self):
        with pytest.raises(ValueError, match="exceeds"):
            validate_metadata({"big": "x" * 100000})


class TestValidateCronExpression:
    def test_valid(self):
        assert validate_cron_expression("0 * * * *") == "0 * * * *"

    def test_empty(self):
        with pytest.raises(ValueError, match="not be empty"):
            validate_cron_expression("")

    def test_wrong_fields(self):
        with pytest.raises(ValueError, match="5 fields"):
            validate_cron_expression("0 * *")

    def test_invalid_chars(self):
        with pytest.raises(ValueError, match="Invalid character"):
            validate_cron_expression("0 * * * abc")


class TestValidateWebhookUrl:
    def test_https(self):
        assert validate_webhook_url("https://example.com/hook") == "https://example.com/hook"

    def test_localhost(self):
        assert validate_webhook_url("http://localhost:8080/hook") == "http://localhost:8080/hook"

    def test_no_https(self):
        with pytest.raises(ValueError, match="HTTPS"):
            validate_webhook_url("http://example.com/hook")

    def test_empty(self):
        with pytest.raises(ValueError, match="not be empty"):
            validate_webhook_url("")


class TestValidateTimeout:
    def test_valid(self):
        assert validate_timeout(60) == 60

    def test_zero(self):
        with pytest.raises(ValueError, match="positive"):
            validate_timeout(0)

    def test_too_large(self):
        with pytest.raises(ValueError, match="exceed"):
            validate_timeout(100000)


class TestValidateRetryConfig:
    def test_valid(self):
        assert validate_retry_config(3, 60) == (3, 60)

    def test_negative_retries(self):
        with pytest.raises(ValueError, match="non-negative"):
            validate_retry_config(-1, 60)

    def test_too_many_retries(self):
        with pytest.raises(ValueError, match="exceed 10"):
            validate_retry_config(11, 60)


class TestValidateConcurrencyLimit:
    def test_valid(self):
        assert validate_concurrency_limit(10) == 10

    def test_unlimited(self):
        assert validate_concurrency_limit(0) == 0

    def test_negative(self):
        with pytest.raises(ValueError, match="non-negative"):
            validate_concurrency_limit(-1)


class TestValidateBatchSize:
    def test_valid(self):
        assert validate_batch_size(50) == 50

    def test_zero(self):
        with pytest.raises(ValueError, match="positive"):
            validate_batch_size(0)

    def test_too_large(self):
        with pytest.raises(ValueError, match="exceed"):
            validate_batch_size(2000)
