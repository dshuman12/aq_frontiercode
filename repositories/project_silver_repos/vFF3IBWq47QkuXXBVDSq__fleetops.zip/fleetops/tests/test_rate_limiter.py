from app.utils.rate_limiter import RateLimiter

class TestRateLimiter:
    def test_allow(self):
        rl = RateLimiter(default_limit=5)
        ok, _ = rl.is_allowed("k1")
        assert ok is True
    def test_block(self):
        rl = RateLimiter(default_limit=2)
        rl.is_allowed("k1"); rl.is_allowed("k1")
        ok, info = rl.is_allowed("k1")
        assert ok is False and info["remaining"] == 0
    def test_different_keys(self):
        rl = RateLimiter(default_limit=1)
        ok1, _ = rl.is_allowed("a")
        ok2, _ = rl.is_allowed("b")
        assert ok1 and ok2
    def test_reset(self):
        rl = RateLimiter(default_limit=1)
        rl.is_allowed("k"); rl.is_allowed("k")
        rl.reset("k")
        ok, _ = rl.is_allowed("k")
        assert ok
    def test_stats(self):
        rl = RateLimiter()
        rl.is_allowed("a"); rl.is_allowed("b")
        s = rl.get_stats()
        assert s["total_keys"] == 2
