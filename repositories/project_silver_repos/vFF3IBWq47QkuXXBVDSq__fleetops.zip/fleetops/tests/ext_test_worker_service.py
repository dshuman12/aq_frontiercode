"""Tests for WorkerService."""

import pytest
from app.services.worker_service import WorkerService
from app.exceptions import NotFoundError, ValidationError


@pytest.fixture
def worker_data():
    return {
        "worker_id": "worker_abc123",
        "hostname": "worker-host-1",
        "pid": 12345,
        "concurrency": 4,
        "queue_names": ["default", "email"],
        "capabilities": ["email.send", "report.generate"],
        "version": "1.0.0",
    }


class TestWorkerRegister:
    def test_register_new(self, db, worker_data):
        svc = WorkerService(db)
        worker = svc.register(worker_data)
        assert worker.worker_id == "worker_abc123"
        assert worker.status == "idle"
        assert worker.concurrency == 4
        assert len(worker.capabilities) == 2

    def test_re_register(self, db, worker_data):
        svc = WorkerService(db)
        w1 = svc.register(worker_data)
        worker_data["hostname"] = "new-host"
        w2 = svc.register(worker_data)
        assert w1.id == w2.id
        assert w2.hostname == "new-host"


class TestWorkerHeartbeat:
    def test_heartbeat(self, db, worker_data):
        svc = WorkerService(db)
        svc.register(worker_data)
        updated = svc.heartbeat("worker_abc123", {"current_tasks": 2, "cpu_usage": 45.5})
        assert updated.current_tasks == 2
        assert updated.status == "busy"

    def test_heartbeat_idle(self, db, worker_data):
        svc = WorkerService(db)
        svc.register(worker_data)
        svc.heartbeat("worker_abc123", {"current_tasks": 2})
        updated = svc.heartbeat("worker_abc123", {"current_tasks": 0})
        assert updated.status == "idle"


class TestWorkerDeregister:
    def test_deregister(self, db, worker_data):
        svc = WorkerService(db)
        svc.register(worker_data)
        worker = svc.deregister("worker_abc123")
        assert worker.status == "offline"
        assert worker.stopped_at is not None


class TestWorkerList:
    def test_list_all(self, db, worker_data):
        svc = WorkerService(db)
        svc.register(worker_data)
        workers, total = svc.list_workers()
        assert total == 1

    def test_filter_by_status(self, db, worker_data):
        svc = WorkerService(db)
        svc.register(worker_data)
        workers, total = svc.list_workers(status="idle")
        assert total == 1
        workers, total = svc.list_workers(status="busy")
        assert total == 0


class TestWorkerStats:
    def test_stats(self, db, worker_data):
        svc = WorkerService(db)
        svc.register(worker_data)
        stats = svc.get_stats()
        assert stats["total_workers"] == 1
        assert stats["active_workers"] == 1


class TestWorkerDelete:
    def test_delete_offline(self, db, worker_data):
        svc = WorkerService(db)
        svc.register(worker_data)
        svc.deregister("worker_abc123")
        worker = svc.get_by_worker_id("worker_abc123")
        svc.delete(worker.id)
        with pytest.raises(NotFoundError):
            svc.get(worker.id)

    def test_delete_active_fails(self, db, worker_data):
        svc = WorkerService(db)
        worker = svc.register(worker_data)
        with pytest.raises(ValidationError):
            svc.delete(worker.id)
