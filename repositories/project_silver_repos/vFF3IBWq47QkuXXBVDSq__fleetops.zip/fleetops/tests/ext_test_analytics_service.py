"""Tests for AnalyticsService."""

from app.services.analytics_service import AnalyticsService
from app.services.queue_service import QueueService
from app.services.task_service import TaskService


class TestDashboardSummary:
    def test_empty(self, db):
        svc = AnalyticsService(db)
        summary = svc.get_dashboard_summary()
        assert summary["total_queues"] == 0
        assert summary["total_tasks"] == 0
        assert summary["active_workers"] == 0

    def test_with_data(self, db, sample_queue_data, sample_task_data):
        qsvc = QueueService(db)
        qsvc.create(sample_queue_data)
        tsvc = TaskService(db)
        tsvc.create(sample_task_data)
        svc = AnalyticsService(db)
        summary = svc.get_dashboard_summary()
        assert summary["total_queues"] == 1
        assert summary["total_tasks"] == 1


class TestTaskBreakdown:
    def test_empty(self, db):
        svc = AnalyticsService(db)
        breakdown = svc.get_task_status_breakdown()
        assert breakdown == []

    def test_with_tasks(self, db, sample_queue_data, sample_task_data):
        qsvc = QueueService(db)
        qsvc.create(sample_queue_data)
        tsvc = TaskService(db)
        tsvc.create(sample_task_data)
        svc = AnalyticsService(db)
        breakdown = svc.get_task_status_breakdown()
        assert len(breakdown) == 1
        assert breakdown[0]["status"] == "pending"


class TestTaskTrends:
    def test_empty(self, db):
        svc = AnalyticsService(db)
        trends = svc.get_task_trends(days=7)
        assert len(trends) == 7

    def test_all_zeros_empty_db(self, db):
        svc = AnalyticsService(db)
        trends = svc.get_task_trends(days=3)
        for t in trends:
            assert t["created"] == 0


class TestErrorBreakdown:
    def test_empty(self, db):
        svc = AnalyticsService(db)
        errors = svc.get_error_breakdown()
        assert errors == []
