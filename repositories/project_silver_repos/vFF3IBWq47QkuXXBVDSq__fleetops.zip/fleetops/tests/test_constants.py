from app.utils.constants import (WorkflowStatus, RunStatus, StepStatus, StepType, EventStatus,
    RetryStrategy, ChannelType, FilterOperator, VALID_WORKFLOW_TRANSITIONS,
    VALID_RUN_TRANSITIONS, VALID_STEP_TRANSITIONS, TERMINAL_RUN_STATES, ACTIVE_RUN_STATES)

class TestWorkflowTransitions:
    def test_draft_to_active(self):
        assert WorkflowStatus.ACTIVE in VALID_WORKFLOW_TRANSITIONS[WorkflowStatus.DRAFT]
    def test_archived_terminal(self):
        assert VALID_WORKFLOW_TRANSITIONS[WorkflowStatus.ARCHIVED] == []
    def test_all_have_transitions(self):
        for s in WorkflowStatus: assert s in VALID_WORKFLOW_TRANSITIONS
class TestRunTransitions:
    def test_pending_to_running(self):
        assert RunStatus.RUNNING in VALID_RUN_TRANSITIONS[RunStatus.PENDING]
    def test_completed_terminal(self):
        assert VALID_RUN_TRANSITIONS[RunStatus.COMPLETED] == []
    def test_failed_retryable(self):
        assert RunStatus.PENDING in VALID_RUN_TRANSITIONS[RunStatus.FAILED]
class TestStepTransitions:
    def test_pending_to_running(self):
        assert StepStatus.RUNNING in VALID_STEP_TRANSITIONS[StepStatus.PENDING]
    def test_completed_terminal(self):
        assert VALID_STEP_TRANSITIONS[StepStatus.COMPLETED] == []
class TestTerminal:
    def test_completed(self): assert RunStatus.COMPLETED in TERMINAL_RUN_STATES
    def test_failed(self): assert RunStatus.FAILED in TERMINAL_RUN_STATES
class TestActive:
    def test_running(self): assert RunStatus.RUNNING in ACTIVE_RUN_STATES
class TestEnums:
    def test_step_types(self): assert StepType.ACTION.value == "action"
    def test_event_status(self): assert EventStatus.RECEIVED.value == "received"
    def test_retry(self): assert RetryStrategy.EXPONENTIAL.value == "exponential"
    def test_channel(self): assert ChannelType.QUEUE.value == "queue"
    def test_filter(self): assert FilterOperator.EQUALS.value == "eq"
