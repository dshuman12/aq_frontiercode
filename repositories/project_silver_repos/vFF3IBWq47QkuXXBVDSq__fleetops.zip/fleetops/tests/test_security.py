from app.utils.security import (hash_password, verify_password, generate_api_key,
    hash_api_key, sign_payload, verify_signature, generate_webhook_secret, constant_time_compare)

class TestPassword:
    def test_hash_verify(self):
        h = hash_password("secret"); assert verify_password("secret", h)
    def test_wrong(self):
        h = hash_password("secret"); assert not verify_password("wrong", h)
class TestApiKey:
    def test_gen(self): assert generate_api_key().startswith("nx_")
    def test_hash(self): assert len(hash_api_key(generate_api_key())) == 64
class TestSignature:
    def test_ok(self):
        sig = sign_payload(b"data", "secret"); assert verify_signature(b"data", "secret", sig)
    def test_bad(self):
        sig = sign_payload(b"data", "s1"); assert not verify_signature(b"data", "s2", sig)
class TestWebhookSecret:
    def test_len(self): assert len(generate_webhook_secret()) == 64
class TestCompare:
    def test_eq(self): assert constant_time_compare("abc", "abc")
    def test_neq(self): assert not constant_time_compare("abc", "def")
