"""Tests for SearchService."""

from app.services.search_service import SearchService
from app.services.queue_service import QueueService
from app.services.task_service import TaskService


class TestSearchTasks:
    def test_search_by_name(self, db, sample_queue_data, sample_task_data):
        qsvc = QueueService(db)
        qsvc.create(sample_queue_data)
        tsvc = TaskService(db)
        tsvc.create(sample_task_data)
        svc = SearchService(db)
        tasks, total = svc.search_tasks("test")
        assert total == 1

    def test_search_no_match(self, db, sample_queue_data, sample_task_data):
        qsvc = QueueService(db)
        qsvc.create(sample_queue_data)
        tsvc = TaskService(db)
        tsvc.create(sample_task_data)
        svc = SearchService(db)
        tasks, total = svc.search_tasks("nonexistent")
        assert total == 0


class TestSearchQueues:
    def test_search_by_name(self, db, sample_queue_data):
        qsvc = QueueService(db)
        qsvc.create(sample_queue_data)
        svc = SearchService(db)
        queues, total = svc.search_queues("test")
        assert total == 1


class TestGlobalSearch:
    def test_global(self, db, sample_queue_data, sample_task_data):
        qsvc = QueueService(db)
        qsvc.create(sample_queue_data)
        tsvc = TaskService(db)
        tsvc.create(sample_task_data)
        svc = SearchService(db)
        results = svc.global_search("test")
        assert "tasks" in results
        assert "queues" in results
