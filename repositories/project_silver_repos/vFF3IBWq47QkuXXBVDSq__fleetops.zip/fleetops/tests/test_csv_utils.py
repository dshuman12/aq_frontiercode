from app.utils.csv_utils import workflows_to_csv, events_to_csv, runs_to_csv, parse_csv_header

class TestWorkflowsCsv:
    def test_basic(self):
        csv = workflows_to_csv([{"id": 1, "name": "test", "status": "active"}])
        assert "test" in csv
    def test_empty(self): assert workflows_to_csv([]) == ""
class TestEventsCsv:
    def test_basic(self):
        csv = events_to_csv([{"event_id": "e1", "event_type": "order.created"}])
        assert "order.created" in csv
class TestRunsCsv:
    def test_basic(self):
        csv = runs_to_csv([{"run_id": "r1", "status": "completed"}])
        assert "completed" in csv
class TestHeader:
    def test_basic(self): assert parse_csv_header("a,b,c\n1,2,3") == ["a", "b", "c"]
    def test_empty(self): assert parse_csv_header("") == []
