"""Tests for app.utils.formatters."""

from app.utils.formatters import (
    format_task_summary,
    format_queue_summary,
    format_worker_summary,
    format_duration_human,
    format_timestamp,
    format_count,
    format_percentage,
    format_bytes,
    format_rate,
    format_json_compact,
    format_progress_bar,
    mask_sensitive_fields,
)
from datetime import datetime, timezone


class TestFormatTaskSummary:
    def test_basic(self):
        result = format_task_summary({"id": 1, "name": "test", "status": "running", "queue_name": "q1"})
        assert "RUNNING" in result
        assert "test" in result


class TestFormatQueueSummary:
    def test_basic(self):
        result = format_queue_summary({"name": "q1", "status": "active", "pending_count": 5, "running_count": 2})
        assert "q1" in result
        assert "pending=5" in result


class TestFormatWorkerSummary:
    def test_basic(self):
        result = format_worker_summary({"id": 1, "hostname": "host1", "status": "idle", "current_tasks": 0})
        assert "host1" in result


class TestFormatDurationHuman:
    def test_none(self):
        assert format_duration_human(None) == "-"

    def test_milliseconds(self):
        assert format_duration_human(0.5) == "500ms"

    def test_seconds(self):
        assert format_duration_human(45.2) == "45.2s"

    def test_minutes(self):
        assert format_duration_human(125) == "2m 5s"

    def test_hours(self):
        assert format_duration_human(7200) == "2h 0m"

    def test_days(self):
        assert format_duration_human(90000) == "1d 1h"


class TestFormatTimestamp:
    def test_none(self):
        assert format_timestamp(None) == "-"

    def test_utc(self):
        dt = datetime(2024, 6, 15, 14, 30, 0, tzinfo=timezone.utc)
        result = format_timestamp(dt)
        assert "2024-06-15" in result


class TestFormatCount:
    def test_thousands(self):
        assert format_count(1234567) == "1,234,567"

    def test_small(self):
        assert format_count(42) == "42"


class TestFormatPercentage:
    def test_normal(self):
        assert format_percentage(3, 10) == "30.0%"

    def test_zero_total(self):
        assert format_percentage(5, 0) == "0.0%"


class TestFormatBytes:
    def test_bytes(self):
        assert format_bytes(100) == "100 B"

    def test_kb(self):
        assert format_bytes(1536) == "1.5 KB"

    def test_mb(self):
        result = format_bytes(1048576)
        assert "MB" in result


class TestFormatRate:
    def test_normal(self):
        result = format_rate(100, 10)
        assert "10.0 ops/s" == result

    def test_zero_time(self):
        assert format_rate(100, 0) == "∞ ops/s"


class TestFormatProgressBar:
    def test_zero(self):
        result = format_progress_bar(0, 10, 10)
        assert "0%" in result

    def test_half(self):
        result = format_progress_bar(5, 10, 10)
        assert "50%" in result

    def test_full(self):
        result = format_progress_bar(10, 10, 10)
        assert "100%" in result


class TestMaskSensitiveFields:
    def test_masks_password(self):
        result = mask_sensitive_fields({"username": "admin", "password": "secret"})
        assert result["username"] == "admin"
        assert result["password"] == "***"

    def test_nested(self):
        result = mask_sensitive_fields({"config": {"api_key": "xyz"}})
        assert result["config"]["api_key"] == "***"
