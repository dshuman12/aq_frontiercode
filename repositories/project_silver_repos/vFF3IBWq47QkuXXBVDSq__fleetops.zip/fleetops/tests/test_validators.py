import pytest
from app.utils.validators import (validate_workflow_name, validate_step_name, validate_event_type,
    validate_channel_name, validate_tenant_name, validate_webhook_url, validate_condition,
    validate_step_type, validate_retry_strategy, validate_channel_type, validate_filter_operator,
    validate_metadata, validate_payload_size, validate_cron_expression)

class TestWorkflowName:
    def test_valid(self): assert validate_workflow_name("My Workflow") == "My Workflow"
    def test_empty(self):
        with pytest.raises(ValueError): validate_workflow_name("")
    def test_too_long(self):
        with pytest.raises(ValueError): validate_workflow_name("x" * 300)
class TestStepName:
    def test_valid(self): assert validate_step_name("validate-input") == "validate-input"
    def test_empty(self):
        with pytest.raises(ValueError): validate_step_name("")
class TestEventType:
    def test_valid(self): assert validate_event_type("order.created") == "order.created"
    def test_empty(self):
        with pytest.raises(ValueError): validate_event_type("")
    def test_invalid(self):
        with pytest.raises(ValueError): validate_event_type("@invalid!")
class TestChannelName:
    def test_valid(self): assert validate_channel_name("orders") == "orders"
class TestWebhookUrl:
    def test_valid(self): assert validate_webhook_url("https://example.com/hook") == "https://example.com/hook"
    def test_invalid(self):
        with pytest.raises(ValueError): validate_webhook_url("not-a-url")
class TestCondition:
    def test_valid(self): assert validate_condition("prev.success == true") == "prev.success == true"
    def test_empty(self):
        with pytest.raises(ValueError): validate_condition("")
class TestStepType:
    def test_valid(self): assert validate_step_type("action") == "action"
    def test_invalid(self):
        with pytest.raises(ValueError): validate_step_type("magic")
class TestRetryStrategy:
    def test_valid(self): assert validate_retry_strategy("exponential") == "exponential"
    def test_invalid(self):
        with pytest.raises(ValueError): validate_retry_strategy("random")
class TestChannelType:
    def test_valid(self): assert validate_channel_type("queue") == "queue"
class TestFilterOp:
    def test_valid(self): assert validate_filter_operator("eq") == "eq"
class TestMetadata:
    def test_none(self): assert validate_metadata(None) is None
    def test_valid(self): assert validate_metadata({"k": "v"}) == {"k": "v"}
    def test_not_dict(self):
        with pytest.raises(ValueError): validate_metadata("str")
class TestPayloadSize:
    def test_ok(self): validate_payload_size({"small": True})
    def test_too_big(self):
        with pytest.raises(ValueError): validate_payload_size("x" * 2000000, max_bytes=1000)
class TestCron:
    def test_valid(self): assert validate_cron_expression("*/5 * * * *") == "*/5 * * * *"
    def test_invalid(self):
        with pytest.raises(ValueError): validate_cron_expression("bad")
