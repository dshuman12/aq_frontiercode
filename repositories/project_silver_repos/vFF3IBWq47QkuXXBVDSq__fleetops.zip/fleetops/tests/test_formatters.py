from app.utils.formatters import (format_workflow_summary, format_count, format_percentage,
    format_duration_human, mask_pii, format_bytes)

class TestWorkflowSummary:
    def test_basic(self):
        r = format_workflow_summary({"status": "active", "name": "test", "step_count": 3})
        assert "ACTIVE" in r and "test" in r
class TestCount:
    def test_thousands(self): assert format_count(1234567) == "1,234,567"
class TestPercentage:
    def test_basic(self): assert format_percentage(3, 10) == "30.0%"
    def test_zero(self): assert format_percentage(0, 0) == "0.0%"
class TestDuration:
    def test_none(self): assert format_duration_human(None) == "-"
    def test_secs(self): assert format_duration_human(30) == "30s"
    def test_hours(self): assert "h" in format_duration_human(7200)
class TestMask:
    def test_basic(self): assert mask_pii("John Doe", 3) == "*****Doe"
class TestBytes:
    def test_bytes(self): assert format_bytes(500) == "500B"
    def test_kb(self): assert "KB" in format_bytes(5000)
    def test_mb(self): assert "MB" in format_bytes(5000000)
