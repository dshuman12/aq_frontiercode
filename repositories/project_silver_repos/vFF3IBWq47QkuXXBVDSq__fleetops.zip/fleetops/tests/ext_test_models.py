"""Tests for ORM model properties and repr."""

from app.models.queue import Queue, QueueTag
from app.models.task import Task, TaskTag, TaskDependency
from app.models.worker import Worker, WorkerCapability
from app.models.schedule import Schedule
from app.models.webhook import Webhook
from app.models.pipeline import Pipeline, PipelineStep
from app.models.audit import AuditLog
from app.models.api_key import ApiKey
from app.models.dead_letter import DeadLetterEntry, MetricSnapshot
from app.utils.date_utils import utc_now
from datetime import timedelta


class TestQueueModel:
    def test_repr(self, db):
        q = Queue(name="test", status="active")
        db.add(q)
        db.commit()
        assert "test" in repr(q)

    def test_create_with_tag(self, db):
        q = Queue(name="tagged", status="active")
        db.add(q)
        db.flush()
        tag = QueueTag(queue_id=q.id, tag="important")
        db.add(tag)
        db.commit()
        assert len(q.tags) == 1


class TestTaskModel:
    def test_repr(self, db):
        q = Queue(name="q", status="active")
        db.add(q)
        db.flush()
        t = Task(name="t", task_type="test", queue_id=q.id, status="pending", priority=5)
        db.add(t)
        db.commit()
        assert "PENDING" in repr(t).upper()

    def test_is_terminal(self, db):
        q = Queue(name="q", status="active")
        db.add(q)
        db.flush()
        t = Task(name="t", task_type="test", queue_id=q.id, status="success", priority=5)
        db.add(t)
        db.commit()
        assert t.is_terminal is True

    def test_is_active(self, db):
        q = Queue(name="q", status="active")
        db.add(q)
        db.flush()
        t = Task(name="t", task_type="test", queue_id=q.id, status="running", priority=5)
        db.add(t)
        db.commit()
        assert t.is_active is True

    def test_dependency(self, db):
        q = Queue(name="q", status="active")
        db.add(q)
        db.flush()
        t1 = Task(name="t1", task_type="test", queue_id=q.id, status="pending", priority=5)
        t2 = Task(name="t2", task_type="test", queue_id=q.id, status="pending", priority=5)
        db.add_all([t1, t2])
        db.flush()
        dep = TaskDependency(task_id=t2.id, depends_on_id=t1.id)
        db.add(dep)
        db.commit()
        assert len(t2.dependencies) == 1


class TestWorkerModel:
    def test_repr(self, db):
        w = Worker(worker_id="w1", hostname="h1", status="idle")
        db.add(w)
        db.commit()
        assert "w1" in repr(w)


class TestScheduleModel:
    def test_repr(self, db):
        s = Schedule(
            name="daily", cron_expression="0 * * * *",
            task_name="t", task_type="test", queue_name="q",
            status="active",
        )
        db.add(s)
        db.commit()
        assert "daily" in repr(s)


class TestApiKeyModel:
    def test_is_active(self, db):
        key = ApiKey(
            name="test", key_hash="abc", key_prefix="tq_",
            owner="admin", enabled=True,
        )
        db.add(key)
        db.commit()
        assert key.is_active is True

    def test_is_inactive_when_revoked(self, db):
        key = ApiKey(
            name="test", key_hash="abc", key_prefix="tq_",
            owner="admin", enabled=True, revoked_at=utc_now(),
        )
        db.add(key)
        db.commit()
        assert key.is_active is False

    def test_is_inactive_when_expired(self, db):
        key = ApiKey(
            name="test", key_hash="abc", key_prefix="tq_",
            owner="admin", enabled=True,
            expires_at=utc_now() - timedelta(hours=1),
        )
        db.add(key)
        db.commit()
        assert key.is_active is False

    def test_repr(self, db):
        key = ApiKey(
            name="mykey", key_hash="abc", key_prefix="tq_abc",
            owner="admin",
        )
        db.add(key)
        db.commit()
        assert "mykey" in repr(key)


class TestDeadLetterModel:
    def test_repr(self, db):
        entry = DeadLetterEntry(
            original_task_id=1, queue_name="q", task_name="t", task_type="test",
            first_failed_at=utc_now(), last_failed_at=utc_now(),
        )
        db.add(entry)
        db.commit()
        assert "DeadLetterEntry" in repr(entry)


class TestMetricSnapshot:
    def test_repr(self, db):
        snap = MetricSnapshot(metric_name="cpu", metric_value=42.0)
        db.add(snap)
        db.commit()
        assert "cpu" in repr(snap)
