"""Tests for app.utils.csv_utils."""

from datetime import datetime, timezone
from app.utils.csv_utils import (
    tasks_to_csv,
    csv_to_task_dicts,
    queues_to_csv,
    workers_to_csv,
    pipeline_runs_to_csv,
    parse_csv_header,
)


class TestTasksCsv:
    def test_roundtrip(self):
        tasks = [
            {"id": 1, "name": "task1", "status": "success", "priority": 5,
             "queue_name": "q1", "created_at": datetime(2024, 1, 1, tzinfo=timezone.utc)},
        ]
        csv = tasks_to_csv(tasks)
        parsed = csv_to_task_dicts(csv)
        assert len(parsed) == 1
        assert parsed[0]["name"] == "task1"
        assert parsed[0]["id"] == 1

    def test_empty(self):
        assert tasks_to_csv([]) == ""


class TestQueuesCsv:
    def test_basic(self):
        queues = [{"id": 1, "name": "q1", "status": "active"}]
        csv = queues_to_csv(queues)
        assert "q1" in csv

    def test_empty(self):
        assert queues_to_csv([]) == ""


class TestWorkersCsv:
    def test_basic(self):
        workers = [{"id": 1, "hostname": "host1", "status": "idle"}]
        csv = workers_to_csv(workers)
        assert "host1" in csv


class TestPipelineRunsCsv:
    def test_basic(self):
        runs = [{"id": 1, "pipeline_id": 1, "status": "completed"}]
        csv = pipeline_runs_to_csv(runs)
        assert "completed" in csv


class TestParseHeader:
    def test_basic(self):
        csv = "id,name,status\n1,test,ok\n"
        headers = parse_csv_header(csv)
        assert headers == ["id", "name", "status"]

    def test_empty(self):
        assert parse_csv_header("") == []
