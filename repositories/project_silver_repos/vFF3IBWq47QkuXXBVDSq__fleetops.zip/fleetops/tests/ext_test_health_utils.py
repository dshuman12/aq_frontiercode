"""Tests for health check utilities."""

from app.utils.health import HealthCheck, check_disk_space


class TestHealthCheck:
    def test_empty(self):
        hc = HealthCheck()
        result = hc.run_all()
        assert result["status"] == "healthy"
        assert result["checks"] == {}

    def test_healthy_check(self):
        hc = HealthCheck()
        hc.register_check("db", lambda: {"status": "healthy"})
        result = hc.run_all()
        assert result["status"] == "healthy"
        assert result["checks"]["db"]["status"] == "healthy"

    def test_unhealthy_check(self):
        hc = HealthCheck()
        hc.register_check("db", lambda: {"status": "unhealthy"})
        result = hc.run_all()
        assert result["status"] == "degraded"

    def test_exception_in_check(self):
        def bad_check():
            raise RuntimeError("boom")
        hc = HealthCheck()
        hc.register_check("bad", bad_check)
        result = hc.run_all()
        assert result["status"] == "degraded"
        assert "error" in result["checks"]["bad"]

    def test_run_single(self):
        hc = HealthCheck()
        hc.register_check("test", lambda: {"status": "healthy"})
        result = hc.run_check("test")
        assert result["status"] == "healthy"

    def test_run_missing(self):
        hc = HealthCheck()
        result = hc.run_check("nope")
        assert result["status"] == "unknown"


class TestDiskSpaceCheck:
    def test_returns_status(self):
        result = check_disk_space(min_free_gb=0.001)
        assert result["status"] in ("healthy", "warning")
        assert "free_gb" in result
