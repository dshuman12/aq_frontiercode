"""Tests for TaskScheduler."""

from datetime import timedelta
from app.services.task_scheduler import TaskScheduler
from app.services.queue_service import QueueService
from app.services.task_service import TaskService
from app.utils.date_utils import utc_now


class TestPromoteScheduled:
    def test_promote(self, db, sample_queue_data, sample_task_data):
        qsvc = QueueService(db)
        qsvc.create(sample_queue_data)
        tsvc = TaskService(db)
        sample_task_data["scheduled_at"] = utc_now() - timedelta(minutes=5)
        tsvc.create(sample_task_data)
        scheduler = TaskScheduler(db)
        promoted = scheduler.promote_scheduled_tasks()
        assert promoted == 1

    def test_not_yet_due(self, db, sample_queue_data, sample_task_data):
        qsvc = QueueService(db)
        qsvc.create(sample_queue_data)
        tsvc = TaskService(db)
        sample_task_data["scheduled_at"] = utc_now() + timedelta(hours=1)
        tsvc.create(sample_task_data)
        scheduler = TaskScheduler(db)
        promoted = scheduler.promote_scheduled_tasks()
        assert promoted == 0


class TestCheckTimeouts:
    def test_timeout(self, db, sample_queue_data, sample_task_data):
        qsvc = QueueService(db)
        qsvc.create(sample_queue_data)
        tsvc = TaskService(db)
        sample_task_data["timeout"] = 1
        task = tsvc.create(sample_task_data)
        tsvc.transition_status(task.id, "queued")
        tsvc.transition_status(task.id, "running")
        # Backdate started_at
        task.started_at = utc_now() - timedelta(hours=1)
        db.commit()
        scheduler = TaskScheduler(db)
        timed_out = scheduler.check_timeouts()
        assert timed_out == 1


class TestCheckDeadlines:
    def test_deadline_passed(self, db, sample_queue_data, sample_task_data):
        qsvc = QueueService(db)
        qsvc.create(sample_queue_data)
        tsvc = TaskService(db)
        sample_task_data["deadline"] = utc_now() - timedelta(hours=1)
        tsvc.create(sample_task_data)
        scheduler = TaskScheduler(db)
        cancelled = scheduler.check_deadlines()
        assert cancelled == 1


class TestMaintenanceCycle:
    def test_run_cycle(self, db):
        scheduler = TaskScheduler(db)
        results = scheduler.run_maintenance_cycle()
        assert "promoted_scheduled" in results
        assert "timeouts_detected" in results
        assert "retries_processed" in results
