"""Tests for retry utilities."""

from app.utils.retry import (
    ConstantBackoff,
    LinearBackoff,
    ExponentialBackoff,
    FibonacciBackoff,
    RetryContext,
)


class TestConstantBackoff:
    def test_constant(self):
        b = ConstantBackoff(delay=5.0)
        assert b.get_delay(0) == 5.0
        assert b.get_delay(5) == 5.0


class TestLinearBackoff:
    def test_linear(self):
        b = LinearBackoff(base_delay=1.0, increment=2.0)
        assert b.get_delay(0) == 1.0
        assert b.get_delay(1) == 3.0
        assert b.get_delay(2) == 5.0

    def test_max_delay(self):
        b = LinearBackoff(base_delay=1.0, increment=100.0, max_delay=50.0)
        assert b.get_delay(1) == 50.0


class TestExponentialBackoff:
    def test_exponential(self):
        b = ExponentialBackoff(base_delay=1.0, factor=2.0, jitter=False)
        assert b.get_delay(0) == 1.0
        assert b.get_delay(1) == 2.0
        assert b.get_delay(2) == 4.0

    def test_max_delay(self):
        b = ExponentialBackoff(base_delay=1.0, factor=2.0, max_delay=10.0, jitter=False)
        assert b.get_delay(10) == 10.0

    def test_jitter(self):
        b = ExponentialBackoff(base_delay=10.0, jitter=True)
        delays = [b.get_delay(0) for _ in range(10)]
        assert len(set(delays)) > 1


class TestFibonacciBackoff:
    def test_fibonacci(self):
        b = FibonacciBackoff(base_delay=1.0)
        assert b.get_delay(0) == 1.0
        assert b.get_delay(1) == 1.0
        assert b.get_delay(2) == 2.0
        assert b.get_delay(3) == 3.0
        assert b.get_delay(4) == 5.0


class TestRetryContext:
    def test_should_retry(self):
        ctx = RetryContext(max_retries=3)
        assert ctx.should_retry is True
        ctx.record_attempt(ValueError("err"))
        ctx.record_attempt(ValueError("err"))
        ctx.record_attempt(ValueError("err"))
        ctx.record_attempt(ValueError("err"))
        assert ctx.should_retry is False

    def test_summary(self):
        ctx = RetryContext(max_retries=2)
        ctx.record_attempt(ValueError("a"))
        ctx.record_attempt(ValueError("b"))
        summary = ctx.get_summary()
        assert summary["attempts"] == 2
        assert len(summary["errors"]) == 2
