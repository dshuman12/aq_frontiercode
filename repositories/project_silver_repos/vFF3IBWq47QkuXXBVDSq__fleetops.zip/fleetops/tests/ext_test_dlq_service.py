"""Tests for DeadLetterService."""

from app.services.dlq_service import DeadLetterService


class TestDLQAdd:
    def test_add_entry(self, db):
        svc = DeadLetterService(db)
        entry = svc.add_entry(
            task_id=1,
            queue_name="test.queue",
            task_name="failing-task",
            task_type="email.send",
            error_message="Connection refused",
        )
        assert entry.original_task_id == 1
        assert entry.error_count == 1

    def test_increment_on_duplicate(self, db):
        svc = DeadLetterService(db)
        svc.add_entry(1, "q", "t", "type", error_message="err1")
        entry = svc.add_entry(1, "q", "t", "type", error_message="err2")
        assert entry.error_count == 2
        assert entry.error_message == "err2"


class TestDLQList:
    def test_list_empty(self, db):
        svc = DeadLetterService(db)
        entries, total = svc.list_entries()
        assert total == 0

    def test_list_with_filter(self, db):
        svc = DeadLetterService(db)
        svc.add_entry(1, "q1", "t1", "type1")
        svc.add_entry(2, "q2", "t2", "type2")
        entries, total = svc.list_entries(queue_name="q1")
        assert total == 1


class TestDLQResolve:
    def test_resolve(self, db):
        svc = DeadLetterService(db)
        entry = svc.add_entry(1, "q", "t", "type")
        resolved = svc.resolve(entry.id, "fixed", resolved_by="admin")
        assert resolved.resolution == "fixed"
        assert resolved.resolved_at is not None

    def test_resolve_nonexistent(self, db):
        svc = DeadLetterService(db)
        assert svc.resolve(999, "fixed") is None


class TestDLQRequeue:
    def test_mark_requeued(self, db):
        svc = DeadLetterService(db)
        entry = svc.add_entry(1, "q", "t", "type")
        requeued = svc.mark_requeued(entry.id)
        assert requeued.requeued == 1


class TestDLQStats:
    def test_stats_empty(self, db):
        svc = DeadLetterService(db)
        stats = svc.get_stats()
        assert stats["total"] == 0

    def test_stats_with_data(self, db):
        svc = DeadLetterService(db)
        svc.add_entry(1, "q1", "t1", "type1", error_message="err")
        svc.add_entry(2, "q1", "t2", "type2", error_message="err")
        stats = svc.get_stats()
        assert stats["total"] == 2
        assert stats["unresolved"] == 2
