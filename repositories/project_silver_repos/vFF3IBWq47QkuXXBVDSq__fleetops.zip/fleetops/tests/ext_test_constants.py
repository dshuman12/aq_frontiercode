"""Tests for constants and state machine definitions."""

from app.utils.constants import (
    TaskStatus,
    TaskPriority,
    QueueStatus,
    WorkerStatus,
    ScheduleStatus,
    WebhookEvent,
    PipelineStatus,
    PipelineStepStatus,
    TagColor,
    VALID_TASK_TRANSITIONS,
    VALID_QUEUE_TRANSITIONS,
    VALID_PIPELINE_TRANSITIONS,
    TERMINAL_TASK_STATES,
    ACTIVE_TASK_STATES,
    DEFAULT_QUEUE_SETTINGS,
    MAX_TASK_NAME_LENGTH,
    MAX_PIPELINE_STEPS,
)


class TestTaskStatus:
    def test_values(self):
        assert TaskStatus.PENDING.value == "pending"
        assert TaskStatus.SUCCESS.value == "success"
        assert TaskStatus.DEAD_LETTER.value == "dead_letter"

    def test_all_statuses_have_transitions(self):
        for status in TaskStatus:
            assert status in VALID_TASK_TRANSITIONS


class TestTaskPriority:
    def test_ordering(self):
        assert TaskPriority.CRITICAL < TaskPriority.HIGH
        assert TaskPriority.HIGH < TaskPriority.NORMAL
        assert TaskPriority.NORMAL < TaskPriority.LOW
        assert TaskPriority.LOW < TaskPriority.BACKGROUND


class TestQueueStatus:
    def test_transitions(self):
        assert QueueStatus.PAUSED in VALID_QUEUE_TRANSITIONS[QueueStatus.ACTIVE]
        assert QueueStatus.ACTIVE in VALID_QUEUE_TRANSITIONS[QueueStatus.PAUSED]

    def test_disabled_can_reactivate(self):
        assert QueueStatus.ACTIVE in VALID_QUEUE_TRANSITIONS[QueueStatus.DISABLED]


class TestTerminalStates:
    def test_terminal(self):
        assert TaskStatus.SUCCESS in TERMINAL_TASK_STATES
        assert TaskStatus.CANCELLED in TERMINAL_TASK_STATES
        assert TaskStatus.DEAD_LETTER in TERMINAL_TASK_STATES

    def test_not_terminal(self):
        assert TaskStatus.RUNNING not in TERMINAL_TASK_STATES
        assert TaskStatus.PENDING not in TERMINAL_TASK_STATES


class TestActiveStates:
    def test_active(self):
        assert TaskStatus.RUNNING in ACTIVE_TASK_STATES
        assert TaskStatus.QUEUED in ACTIVE_TASK_STATES

    def test_not_active(self):
        assert TaskStatus.SUCCESS not in ACTIVE_TASK_STATES


class TestPipelineTransitions:
    def test_pending_can_run(self):
        assert PipelineStatus.RUNNING in VALID_PIPELINE_TRANSITIONS[PipelineStatus.PENDING]

    def test_completed_is_terminal(self):
        assert VALID_PIPELINE_TRANSITIONS[PipelineStatus.COMPLETED] == []


class TestDefaults:
    def test_queue_settings(self):
        assert DEFAULT_QUEUE_SETTINGS["max_size"] == 10000
        assert DEFAULT_QUEUE_SETTINGS["max_retries"] == 3

    def test_limits(self):
        assert MAX_TASK_NAME_LENGTH == 255
        assert MAX_PIPELINE_STEPS == 50


class TestWebhookEvents:
    def test_task_events(self):
        assert WebhookEvent.TASK_CREATED.value == "task.created"
        assert WebhookEvent.TASK_FAILED.value == "task.failed"

    def test_queue_events(self):
        assert WebhookEvent.QUEUE_PAUSED.value == "queue.paused"


class TestTagColor:
    def test_values(self):
        assert TagColor.RED.value == "red"
        assert TagColor.BLUE.value == "blue"
