"""Tests for WebhookService."""

import pytest
from app.services.webhook_service import WebhookService
from app.exceptions import NotFoundError


@pytest.fixture
def webhook_data():
    return {
        "name": "task-notifications",
        "url": "https://example.com/webhook",
        "events": ["task.completed", "task.failed"],
    }


class TestWebhookCreate:
    def test_basic(self, db, webhook_data):
        svc = WebhookService(db)
        webhook = svc.create(webhook_data)
        assert webhook.name == "task-notifications"
        assert webhook.enabled is True
        assert webhook.secret is not None

    def test_with_filter(self, db, webhook_data):
        webhook_data["queue_filter"] = "email"
        svc = WebhookService(db)
        webhook = svc.create(webhook_data)
        assert webhook.queue_filter == "email"


class TestWebhookUpdate:
    def test_update_url(self, db, webhook_data):
        svc = WebhookService(db)
        webhook = svc.create(webhook_data)
        updated = svc.update(webhook.id, {"url": "https://new.example.com/hook"})
        assert updated.url == "https://new.example.com/hook"

    def test_disable(self, db, webhook_data):
        svc = WebhookService(db)
        webhook = svc.create(webhook_data)
        disabled = svc.disable(webhook.id)
        assert disabled.enabled is False
        enabled = svc.enable(webhook.id)
        assert enabled.enabled is True


class TestWebhookDelivery:
    def test_record_success(self, db, webhook_data):
        svc = WebhookService(db)
        webhook = svc.create(webhook_data)
        delivery = svc.record_delivery(
            webhook.id, "task.completed",
            response_status=200, success=True, duration_ms=15.0,
        )
        assert delivery.success is True
        assert delivery.response_status == 200

    def test_record_failure(self, db, webhook_data):
        svc = WebhookService(db)
        webhook = svc.create(webhook_data)
        svc.record_delivery(
            webhook.id, "task.completed",
            response_status=500, success=False, error_message="Server Error",
        )
        webhook = svc.get(webhook.id)
        assert webhook.consecutive_failures == 1

    def test_get_deliveries(self, db, webhook_data):
        svc = WebhookService(db)
        webhook = svc.create(webhook_data)
        svc.record_delivery(webhook.id, "task.completed", success=True)
        svc.record_delivery(webhook.id, "task.failed", success=True)
        deliveries, total = svc.get_deliveries(webhook.id)
        assert total == 2


class TestWebhookMatching:
    def test_match_event(self, db, webhook_data):
        svc = WebhookService(db)
        svc.create(webhook_data)
        matching = svc.get_matching_webhooks("task.completed")
        assert len(matching) == 1

    def test_no_match(self, db, webhook_data):
        svc = WebhookService(db)
        svc.create(webhook_data)
        matching = svc.get_matching_webhooks("queue.paused")
        assert len(matching) == 0


class TestWebhookRotateSecret:
    def test_rotate(self, db, webhook_data):
        svc = WebhookService(db)
        webhook = svc.create(webhook_data)
        old_secret = webhook.secret
        rotated = svc.rotate_secret(webhook.id)
        assert rotated.secret != old_secret


class TestWebhookDelete:
    def test_delete(self, db, webhook_data):
        svc = WebhookService(db)
        webhook = svc.create(webhook_data)
        svc.delete(webhook.id)
        with pytest.raises(NotFoundError):
            svc.get(webhook.id)
