"""Tests for app.utils.helpers."""

from app.utils.helpers import (
    slugify,
    truncate,
    compute_payload_hash,
    mask_string,
    parse_cron_fields,
    format_duration,
    safe_json_loads,
    deep_merge,
    chunk_list,
    generate_task_id,
    generate_worker_id,
    generate_api_key,
    generate_nonce,
    sanitize_metadata,
)
import pytest


class TestSlugify:
    def test_basic(self):
        assert slugify("My Queue Name!") == "my-queue-name"

    def test_special_chars(self):
        assert slugify("Hello, World!!!") == "hello-world"

    def test_spaces(self):
        assert slugify("  multiple   spaces  ") == "multiple-spaces"

    def test_empty(self):
        assert slugify("") == ""

    def test_already_slug(self):
        assert slugify("my-slug") == "my-slug"


class TestTruncate:
    def test_short_string(self):
        assert truncate("hello", 10) == "hello"

    def test_exact_length(self):
        assert truncate("hello", 5) == "hello"

    def test_truncated(self):
        assert truncate("hello world", 8) == "hello..."

    def test_custom_suffix(self):
        assert truncate("hello world", 8, "~") == "hello w~"


class TestComputePayloadHash:
    def test_dict(self):
        h1 = compute_payload_hash({"a": 1, "b": 2})
        h2 = compute_payload_hash({"b": 2, "a": 1})
        assert h1 == h2

    def test_string(self):
        h = compute_payload_hash("test")
        assert len(h) == 64

    def test_different_payloads(self):
        h1 = compute_payload_hash({"x": 1})
        h2 = compute_payload_hash({"x": 2})
        assert h1 != h2


class TestMaskString:
    def test_long_string(self):
        assert mask_string("secret_api_key_1234") == "***************1234"

    def test_short_string(self):
        assert mask_string("ab", 4) == "ab"

    def test_exact_length(self):
        assert mask_string("abcd", 4) == "abcd"


class TestParseCronFields:
    def test_valid(self):
        result = parse_cron_fields("0 */2 * * 1-5")
        assert result["minute"] == "0"
        assert result["hour"] == "*/2"
        assert result["day_of_week"] == "1-5"

    def test_invalid_fields(self):
        with pytest.raises(ValueError, match="5 fields"):
            parse_cron_fields("0 * *")


class TestFormatDuration:
    def test_seconds(self):
        assert format_duration(45.0) == "45s"

    def test_minutes(self):
        assert format_duration(125.0) == "2m 5s"

    def test_hours(self):
        assert format_duration(3661.5) == "1h 1m 1s"

    def test_negative(self):
        assert format_duration(-1) == "0s"


class TestSafeJsonLoads:
    def test_valid_json(self):
        assert safe_json_loads('{"a": 1}') == {"a": 1}

    def test_invalid_json(self):
        assert safe_json_loads("not json") is None

    def test_none(self):
        assert safe_json_loads(None) is None


class TestDeepMerge:
    def test_simple(self):
        result = deep_merge({"a": 1}, {"b": 2})
        assert result == {"a": 1, "b": 2}

    def test_nested(self):
        result = deep_merge({"a": {"x": 1}}, {"a": {"y": 2}})
        assert result == {"a": {"x": 1, "y": 2}}

    def test_override(self):
        result = deep_merge({"a": 1}, {"a": 2})
        assert result == {"a": 2}


class TestChunkList:
    def test_even(self):
        assert chunk_list([1, 2, 3, 4], 2) == [[1, 2], [3, 4]]

    def test_remainder(self):
        assert chunk_list([1, 2, 3, 4, 5], 2) == [[1, 2], [3, 4], [5]]

    def test_empty(self):
        assert chunk_list([], 5) == []

    def test_invalid_size(self):
        with pytest.raises(ValueError):
            chunk_list([1], 0)


class TestGenerators:
    def test_task_id(self):
        tid = generate_task_id()
        assert tid.startswith("task_")
        assert len(tid) > 10

    def test_worker_id(self):
        wid = generate_worker_id()
        assert wid.startswith("worker_")

    def test_api_key(self):
        key = generate_api_key()
        assert key.startswith("tq_")

    def test_nonce(self):
        n = generate_nonce(32)
        assert len(n) == 32


class TestSanitizeMetadata:
    def test_shallow(self):
        result = sanitize_metadata({"a": 1})
        assert result == {"a": 1}

    def test_deep_truncation(self):
        data = {"a": {"b": {"c": {"d": {"e": {"f": "deep"}}}}}}
        result = sanitize_metadata(data, max_depth=3)
        assert result["a"]["b"]["c"] == "<truncated>"
