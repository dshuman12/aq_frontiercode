"""Tests for ConcurrencyService."""

from app.services.concurrency_service import ConcurrencyService
from app.services.queue_service import QueueService
from app.services.worker_service import WorkerService


class TestConcurrencyQueue:
    def test_no_limit(self, db, sample_queue_data):
        qsvc = QueueService(db)
        queue = qsvc.create(sample_queue_data)
        svc = ConcurrencyService(db)
        result = svc.check_queue_limit(queue.id)
        assert result["allowed"] is True

    def test_with_limit(self, db, sample_queue_data):
        sample_queue_data["concurrency_limit"] = 5
        qsvc = QueueService(db)
        queue = qsvc.create(sample_queue_data)
        svc = ConcurrencyService(db)
        result = svc.check_queue_limit(queue.id)
        assert result["allowed"] is True
        assert result["remaining"] == 5

    def test_queue_not_found(self, db):
        svc = ConcurrencyService(db)
        result = svc.check_queue_limit(999)
        assert result["allowed"] is False


class TestConcurrencyWorker:
    def test_worker_capacity(self, db):
        wsvc = WorkerService(db)
        worker = wsvc.register({
            "worker_id": "w1", "hostname": "h1", "concurrency": 4
        })
        svc = ConcurrencyService(db)
        result = svc.check_worker_limit(worker.id)
        assert result["allowed"] is True
        assert result["remaining"] == 4

    def test_worker_not_found(self, db):
        svc = ConcurrencyService(db)
        result = svc.check_worker_limit(999)
        assert result["allowed"] is False


class TestConcurrencyGlobal:
    def test_no_global_limit(self, db):
        svc = ConcurrencyService(db)
        result = svc.check_global_limit()
        assert result["allowed"] is True

    def test_set_global_limit(self, db):
        svc = ConcurrencyService(db)
        svc.set_global_limit(100)
        assert svc.get_global_limit() == 100
        result = svc.check_global_limit()
        assert result["allowed"] is True


class TestAcquireSlot:
    def test_acquire(self, db, sample_queue_data):
        qsvc = QueueService(db)
        queue = qsvc.create(sample_queue_data)
        wsvc = WorkerService(db)
        worker = wsvc.register({"worker_id": "w1", "hostname": "h1"})
        svc = ConcurrencyService(db)
        result = svc.acquire_slot(queue.id, worker.id)
        assert result["acquired"] is True


class TestUtilization:
    def test_empty(self, db):
        svc = ConcurrencyService(db)
        result = svc.get_utilization()
        assert result["total_running"] == 0
        assert result["total_capacity"] == 0
