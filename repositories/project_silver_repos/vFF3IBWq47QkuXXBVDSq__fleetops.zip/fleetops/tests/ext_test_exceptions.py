"""Tests for the exception hierarchy."""

from app.exceptions import (
    TaskQueueError,
    NotFoundError,
    DuplicateError,
    InvalidStateTransitionError,
    QueueFullError,
    TaskTimeoutError,
    RetryExhaustedError,
    WorkerUnavailableError,
    ConcurrencyLimitError,
    WebhookDeliveryError,
    ScheduleConflictError,
    ValidationError,
    RateLimitExceededError,
    PipelineError,
    DependencyError,
)


class TestExceptions:
    def test_base(self):
        e = TaskQueueError("test error", "TEST")
        assert str(e) == "test error"
        assert e.code == "TEST"

    def test_not_found(self):
        e = NotFoundError("Task", 42)
        assert "42" in e.message
        assert e.resource == "Task"

    def test_duplicate(self):
        e = DuplicateError("Queue", "name", "q1")
        assert "q1" in e.message

    def test_invalid_transition(self):
        e = InvalidStateTransitionError("Task", "pending", "success")
        assert "pending" in e.message
        assert "success" in e.message

    def test_queue_full(self):
        e = QueueFullError("my-queue", 1000)
        assert "my-queue" in e.message
        assert e.max_size == 1000

    def test_task_timeout(self):
        e = TaskTimeoutError(1, 3600)
        assert e.task_id == 1

    def test_retry_exhausted(self):
        e = RetryExhaustedError(1, 3)
        assert e.max_retries == 3

    def test_worker_unavailable(self):
        e = WorkerUnavailableError("email")
        assert "email" in e.message

    def test_worker_unavailable_no_queue(self):
        e = WorkerUnavailableError()
        assert "No workers" in e.message

    def test_concurrency_limit(self):
        e = ConcurrencyLimitError("queue:default", 5, 5)
        assert e.current == 5

    def test_webhook_delivery(self):
        e = WebhookDeliveryError(1, "https://example.com", 500)
        assert e.status_code == 500

    def test_schedule_conflict(self):
        e = ScheduleConflictError("a", "b")
        assert "a" in e.message

    def test_validation(self):
        e = ValidationError("bad input", field="name")
        assert e.field == "name"

    def test_rate_limit(self):
        e = RateLimitExceededError(100, 60, 30)
        assert e.retry_after == 30

    def test_pipeline(self):
        e = PipelineError(1, 2, "step failed")
        assert e.step_index == 2

    def test_dependency(self):
        e = DependencyError(1, [2, 3])
        assert "2" in e.message
