"""Shared test fixtures."""
import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.database import Base

@pytest.fixture(scope="function")
def db():
    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    Base.metadata.create_all(bind=engine)
    Session = sessionmaker(bind=engine)
    session = Session()
    try: yield session
    finally: session.close(); Base.metadata.drop_all(bind=engine)

@pytest.fixture
def vehicle_data():
    return {"plate": "AB-1234", "vin": "1HGBH41JXMN109186", "vehicle_type": "truck",
        "make": "Ford", "model": "F-150", "year": 2023, "fuel_capacity_liters": 80.0}

@pytest.fixture
def driver_data():
    return {"employee_id": "EMP-001", "name": "John Doe",
        "license_number": "DL12345678", "license_class": "C", "email": "john@fleet.com"}
