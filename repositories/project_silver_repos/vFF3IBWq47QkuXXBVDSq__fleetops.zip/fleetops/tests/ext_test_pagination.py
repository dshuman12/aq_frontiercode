"""Tests for pagination utilities."""

from app.utils.pagination import (
    build_pagination_meta,
    validate_page_params,
)


class TestBuildPaginationMeta:
    def test_basic(self):
        meta = build_pagination_meta(total=100, page=1, page_size=20)
        assert meta["total"] == 100
        assert meta["pages"] == 5
        assert meta["has_next"] is True
        assert meta["has_prev"] is False

    def test_last_page(self):
        meta = build_pagination_meta(total=100, page=5, page_size=20)
        assert meta["has_next"] is False
        assert meta["has_prev"] is True

    def test_single_page(self):
        meta = build_pagination_meta(total=5, page=1, page_size=20)
        assert meta["pages"] == 1
        assert meta["has_next"] is False

    def test_empty(self):
        meta = build_pagination_meta(total=0, page=1, page_size=20)
        assert meta["pages"] == 0


class TestValidatePageParams:
    def test_valid(self):
        page, size = validate_page_params(2, 50)
        assert page == 2
        assert size == 50

    def test_clamp_negative(self):
        page, size = validate_page_params(-1, -5)
        assert page == 1
        assert size == 1

    def test_clamp_max(self):
        page, size = validate_page_params(1, 500, max_page_size=100)
        assert size == 100
