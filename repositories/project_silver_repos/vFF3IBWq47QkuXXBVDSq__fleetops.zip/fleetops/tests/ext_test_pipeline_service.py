"""Tests for PipelineService."""

import pytest
from app.services.pipeline_service import PipelineService
from app.exceptions import DuplicateError, NotFoundError, ValidationError, InvalidStateTransitionError


@pytest.fixture
def pipeline_data():
    return {
        "name": "data-processing",
        "queue_name": "default",
        "steps": [
            {"name": "extract", "task_type": "etl.extract"},
            {"name": "transform", "task_type": "etl.transform"},
            {"name": "load", "task_type": "etl.load"},
        ],
    }


class TestPipelineCreate:
    def test_basic(self, db, pipeline_data):
        svc = PipelineService(db)
        pipeline = svc.create(pipeline_data)
        assert pipeline.name == "data-processing"
        assert len(pipeline.steps) == 3
        assert pipeline.steps[0].name == "extract"
        assert pipeline.steps[0].step_index == 0

    def test_duplicate(self, db, pipeline_data):
        svc = PipelineService(db)
        svc.create(pipeline_data)
        with pytest.raises(DuplicateError):
            svc.create(pipeline_data)

    def test_no_steps(self, db, pipeline_data):
        pipeline_data["steps"] = []
        svc = PipelineService(db)
        with pytest.raises(ValidationError):
            svc.create(pipeline_data)


class TestPipelineRun:
    def test_start_run(self, db, pipeline_data):
        svc = PipelineService(db)
        pipeline = svc.create(pipeline_data)
        run = svc.start_run(pipeline.id)
        assert run.status == "pending"
        assert len(run.step_runs) == 3

    def test_advance_run(self, db, pipeline_data):
        svc = PipelineService(db)
        pipeline = svc.create(pipeline_data)
        run = svc.start_run(pipeline.id)
        advanced = svc.advance_run(run.id)
        assert advanced.status == "running"

    def test_complete_step(self, db, pipeline_data):
        svc = PipelineService(db)
        pipeline = svc.create(pipeline_data)
        run = svc.start_run(pipeline.id)
        svc.advance_run(run.id)
        run = svc.complete_step(run.id, 0, success=True)
        completed_step = [sr for sr in run.step_runs if sr.step_index == 0][0]
        assert completed_step.status == "completed"

    def test_failed_step_stops_pipeline(self, db, pipeline_data):
        svc = PipelineService(db)
        pipeline = svc.create(pipeline_data)
        run = svc.start_run(pipeline.id)
        svc.advance_run(run.id)
        run = svc.complete_step(run.id, 0, success=False, error_message="extract failed")
        assert run.status == "failed"

    def test_cancel_run(self, db, pipeline_data):
        svc = PipelineService(db)
        pipeline = svc.create(pipeline_data)
        run = svc.start_run(pipeline.id)
        svc.advance_run(run.id)
        cancelled = svc.cancel_run(run.id)
        assert cancelled.status == "cancelled"

    def test_concurrent_run_limit(self, db, pipeline_data):
        pipeline_data["max_concurrent_runs"] = 1
        svc = PipelineService(db)
        pipeline = svc.create(pipeline_data)
        svc.start_run(pipeline.id)
        with pytest.raises(ValidationError, match="active runs"):
            svc.start_run(pipeline.id)


class TestPipelineUpdate:
    def test_update_description(self, db, pipeline_data):
        svc = PipelineService(db)
        pipeline = svc.create(pipeline_data)
        updated = svc.update(pipeline.id, {"description": "ETL pipeline"})
        assert updated.description == "ETL pipeline"

    def test_update_steps_bumps_version(self, db, pipeline_data):
        svc = PipelineService(db)
        pipeline = svc.create(pipeline_data)
        updated = svc.update(pipeline.id, {
            "steps": [{"name": "single-step", "task_type": "simple.task"}],
        })
        assert updated.version == 2
        assert len(updated.steps) == 1


class TestPipelineDelete:
    def test_delete(self, db, pipeline_data):
        svc = PipelineService(db)
        pipeline = svc.create(pipeline_data)
        svc.delete(pipeline.id)
        with pytest.raises(NotFoundError):
            svc.get(pipeline.id)

    def test_delete_with_active_runs(self, db, pipeline_data):
        svc = PipelineService(db)
        pipeline = svc.create(pipeline_data)
        svc.start_run(pipeline.id)
        with pytest.raises(ValidationError):
            svc.delete(pipeline.id)
