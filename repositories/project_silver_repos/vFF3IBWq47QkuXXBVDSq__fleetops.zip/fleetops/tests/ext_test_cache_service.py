"""Tests for CacheService."""

import time
from app.services.cache_service import CacheService


class TestCacheBasic:
    def test_set_get(self):
        cache = CacheService(default_ttl=300)
        cache.set("key1", "value1")
        assert cache.get("key1") == "value1"

    def test_miss(self):
        cache = CacheService()
        assert cache.get("nonexistent") is None

    def test_delete(self):
        cache = CacheService()
        cache.set("k", "v")
        assert cache.delete("k") is True
        assert cache.get("k") is None

    def test_delete_nonexistent(self):
        cache = CacheService()
        assert cache.delete("nope") is False

    def test_exists(self):
        cache = CacheService()
        cache.set("k", "v")
        assert cache.exists("k") is True
        assert cache.exists("nope") is False

    def test_clear(self):
        cache = CacheService()
        cache.set("a", 1)
        cache.set("b", 2)
        count = cache.clear()
        assert count == 2
        assert cache.get("a") is None


class TestCacheTTL:
    def test_expired(self):
        cache = CacheService(default_ttl=300)
        # Set with a very short TTL and wait
        cache._store["k"] = __import__("app.services.cache_service", fromlist=["CacheEntry"]).CacheEntry("v", 0)
        cache._store["k"].expires_at = 0  # force expired
        assert cache.get("k") is None

    def test_not_expired(self):
        cache = CacheService()
        cache.set("k", "v", ttl=3600)
        assert cache.get("k") == "v"


class TestCacheStats:
    def test_stats(self):
        cache = CacheService()
        cache.set("k", "v")
        cache.get("k")
        cache.get("miss")
        stats = cache.get_stats()
        assert stats["hits"] == 1
        assert stats["misses"] == 1
        assert stats["size"] == 1


class TestCacheEviction:
    def test_max_size(self):
        cache = CacheService(max_size=2)
        cache.set("a", 1)
        cache.set("b", 2)
        cache.set("c", 3)
        assert cache.get("c") == 3
        assert cache.get_stats()["size"] == 2


class TestCacheGetOrSet:
    def test_miss_then_set(self):
        cache = CacheService()
        result = cache.get_or_set("new_key", lambda: "computed_value")
        assert result == "computed_value"
        assert cache.get("new_key") == "computed_value"

    def test_hit(self):
        cache = CacheService()
        cache.set("existing", "old_value")
        result = cache.get_or_set("existing", lambda: "new_value")
        assert result == "old_value"


class TestCacheKeys:
    def test_get_keys(self):
        cache = CacheService()
        cache.set("user:1", "a")
        cache.set("user:2", "b")
        cache.set("task:1", "c")
        user_keys = cache.get_keys(prefix="user:")
        assert len(user_keys) == 2
