"""Edge case tests for various services."""

import pytest
from app.services.queue_service import QueueService
from app.services.task_service import TaskService
from app.services.schedule_service import ScheduleService
from app.exceptions import ValidationError, NotFoundError


class TestQueueEdgeCases:
    def test_queue_name_validation(self, db):
        svc = QueueService(db)
        with pytest.raises(ValueError):
            svc.create({"name": ""})

    def test_queue_max_size_used(self, db, sample_queue_data):
        sample_queue_data["max_size"] = 2
        svc = QueueService(db)
        q = svc.create(sample_queue_data)
        stats = svc.get_stats(q.id)
        assert stats["total_tasks"] == 0

    def test_purge_empty_queue(self, db, sample_queue_data):
        svc = QueueService(db)
        q = svc.create(sample_queue_data)
        count = svc.purge(q.id)
        assert count == 0

    def test_purge_dry_run(self, db, sample_queue_data):
        svc = QueueService(db)
        q = svc.create(sample_queue_data)
        count = svc.purge(q.id, dry_run=True)
        assert count == 0


class TestTaskEdgeCases:
    def test_task_with_metadata(self, db, sample_queue_data, sample_task_data):
        qsvc = QueueService(db)
        qsvc.create(sample_queue_data)
        tsvc = TaskService(db)
        sample_task_data["metadata"] = {"env": "production", "version": "1.2.3"}
        task = tsvc.create(sample_task_data)
        assert task.metadata_json is not None

    def test_task_with_correlation_id(self, db, sample_queue_data, sample_task_data):
        qsvc = QueueService(db)
        qsvc.create(sample_queue_data)
        tsvc = TaskService(db)
        sample_task_data["correlation_id"] = "corr-abc-123"
        task = tsvc.create(sample_task_data)
        tasks = tsvc.get_by_correlation_id("corr-abc-123")
        assert len(tasks) == 1

    def test_update_non_pending(self, db, sample_queue_data, sample_task_data):
        qsvc = QueueService(db)
        qsvc.create(sample_queue_data)
        tsvc = TaskService(db)
        task = tsvc.create(sample_task_data)
        tsvc.transition_status(task.id, "queued")
        tsvc.transition_status(task.id, "running")
        with pytest.raises(ValidationError):
            tsvc.update(task.id, {"name": "new-name"})

    def test_list_dead_letter_empty(self, db, sample_queue_data):
        qsvc = QueueService(db)
        qsvc.create(sample_queue_data)
        tsvc = TaskService(db)
        tasks, total = tsvc.get_dead_letter_tasks(queue_name="test.queue")
        assert total == 0

    def test_check_dependencies_no_deps(self, db, sample_queue_data, sample_task_data):
        qsvc = QueueService(db)
        qsvc.create(sample_queue_data)
        tsvc = TaskService(db)
        task = tsvc.create(sample_task_data)
        assert tsvc.check_dependencies_met(task.id) is True

    def test_list_with_search(self, db, sample_queue_data, sample_task_data):
        qsvc = QueueService(db)
        qsvc.create(sample_queue_data)
        tsvc = TaskService(db)
        tsvc.create(sample_task_data)
        tasks, total = tsvc.list_tasks(filters={"search": "test"})
        assert total == 1
        tasks, total = tsvc.list_tasks(filters={"search": "nonexistent"})
        assert total == 0


class TestScheduleEdgeCases:
    def test_schedule_with_all_fields(self, db):
        svc = ScheduleService(db)
        schedule = svc.create({
            "name": "full-schedule",
            "cron_expression": "*/5 * * * *",
            "task_name": "check-status",
            "task_type": "monitoring.check",
            "queue_name": "monitoring",
            "task_payload": {"check": "cpu"},
            "task_priority": 3,
            "task_timeout": 120,
            "task_max_retries": 1,
            "max_instances": 2,
            "coalesce": False,
            "jitter_seconds": 10,
            "metadata": {"team": "ops"},
        })
        assert schedule.task_priority == 3
        assert schedule.jitter_seconds == 10
        assert schedule.max_instances == 2

    def test_failure_count_increments(self, db):
        svc = ScheduleService(db)
        schedule = svc.create({
            "name": "failing",
            "cron_expression": "0 * * * *",
            "task_name": "fail",
            "task_type": "test",
            "queue_name": "test",
        })
        from app.utils.date_utils import utc_now
        svc.record_run(schedule.id, scheduled_for=utc_now(), status="failed", error_message="err")
        schedule = svc.get(schedule.id)
        assert schedule.failure_count == 1
