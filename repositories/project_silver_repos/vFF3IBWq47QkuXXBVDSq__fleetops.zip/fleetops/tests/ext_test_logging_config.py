"""Tests for logging configuration."""

import json
import logging
from app.utils.logging_config import JSONFormatter, TaskContextFilter, get_logger


class TestJSONFormatter:
    def test_format(self):
        fmt = JSONFormatter()
        record = logging.LogRecord("test", logging.INFO, "file.py", 1, "Hello %s", ("world",), None)
        output = fmt.format(record)
        data = json.loads(output)
        assert data["message"] == "Hello world"
        assert data["level"] == "INFO"

    def test_extras(self):
        fmt = JSONFormatter(include_extras=True)
        record = logging.LogRecord("test", logging.INFO, "file.py", 1, "msg", (), None)
        record.task_id = 42
        output = fmt.format(record)
        data = json.loads(output)
        assert data.get("task_id") == 42


class TestTaskContextFilter:
    def test_adds_context(self):
        f = TaskContextFilter()
        f.set_context(queue_name="test")
        record = logging.LogRecord("test", logging.INFO, "f", 1, "msg", (), None)
        f.filter(record)
        assert getattr(record, "queue_name") == "test"

    def test_clear_context(self):
        f = TaskContextFilter()
        f.set_context(key="val")
        f.clear_context()
        record = logging.LogRecord("test", logging.INFO, "f", 1, "msg", (), None)
        f.filter(record)
        assert not hasattr(record, "key")


class TestGetLogger:
    def test_prefix(self):
        log = get_logger("queues")
        assert log.name == "fleetops.queues"
