"""Tests for app.utils.date_utils."""

from datetime import datetime, timedelta, timezone
import pytest

from app.utils.date_utils import (
    utc_now,
    to_utc,
    start_of_day,
    end_of_day,
    start_of_week,
    start_of_month,
    days_ago,
    hours_ago,
    is_expired,
    seconds_until,
    format_iso,
    parse_iso,
    time_bucket,
    duration_between,
    next_retry_at,
    split_date_range,
)


class TestUtcNow:
    def test_returns_datetime(self):
        now = utc_now()
        assert isinstance(now, datetime)

    def test_recent(self):
        now = utc_now()
        from datetime import timedelta
        assert abs((datetime.utcnow() - now).total_seconds()) < 1


class TestToUtc:
    def test_naive_stays_naive(self):
        dt = datetime(2024, 1, 1, 12, 0)
        result = to_utc(dt)
        assert result.tzinfo is None

    def test_aware_becomes_naive(self):
        dt = datetime(2024, 1, 1, 12, 0, tzinfo=timezone.utc)
        result = to_utc(dt)
        assert result.tzinfo is None
        assert result.hour == 12


class TestStartOfDay:
    def test_clears_time(self):
        dt = datetime(2024, 6, 15, 14, 30, 45, tzinfo=timezone.utc)
        result = start_of_day(dt)
        assert result.hour == 0
        assert result.minute == 0
        assert result.second == 0

    def test_default_today(self):
        result = start_of_day()
        assert result.hour == 0


class TestEndOfDay:
    def test_end_of_day(self):
        dt = datetime(2024, 6, 15, 14, 30, tzinfo=timezone.utc)
        result = end_of_day(dt)
        assert result.hour == 23
        assert result.minute == 59


class TestStartOfWeek:
    def test_monday(self):
        dt = datetime(2024, 6, 12, 14, 0, tzinfo=timezone.utc)  # Wednesday
        result = start_of_week(dt)
        assert result.weekday() == 0  # Monday


class TestStartOfMonth:
    def test_first_day(self):
        dt = datetime(2024, 6, 15, 14, 0, tzinfo=timezone.utc)
        result = start_of_month(dt)
        assert result.day == 1


class TestDaysAgo:
    def test_positive(self):
        result = days_ago(7)
        expected = utc_now() - timedelta(days=7)
        assert abs((result - expected).total_seconds()) < 1


class TestHoursAgo:
    def test_positive(self):
        result = hours_ago(2)
        expected = utc_now() - timedelta(hours=2)
        assert abs((result - expected).total_seconds()) < 1


class TestIsExpired:
    def test_not_expired(self):
        dt = utc_now()
        assert not is_expired(dt, 3600)

    def test_expired(self):
        dt = utc_now() - timedelta(hours=2)
        assert is_expired(dt, 3600)


class TestSecondsUntil:
    def test_future(self):
        dt = utc_now() + timedelta(hours=1)
        s = seconds_until(dt)
        assert 3500 < s < 3700

    def test_past(self):
        dt = utc_now() - timedelta(hours=1)
        s = seconds_until(dt)
        assert s < 0


class TestFormatIso:
    def test_none(self):
        assert format_iso(None) is None

    def test_datetime(self):
        dt = datetime(2024, 1, 1, 12, 0, tzinfo=timezone.utc)
        result = format_iso(dt)
        assert "2024-01-01" in result


class TestTimeBucket:
    def test_15min(self):
        dt = datetime(2024, 1, 1, 13, 47, tzinfo=timezone.utc)
        result = time_bucket(dt, 15)
        assert result.minute == 45

    def test_60min(self):
        dt = datetime(2024, 1, 1, 13, 47, tzinfo=timezone.utc)
        result = time_bucket(dt, 60)
        assert result.minute == 0


class TestDurationBetween:
    def test_positive(self):
        a = datetime(2024, 1, 1, 12, 0, tzinfo=timezone.utc)
        b = datetime(2024, 1, 1, 14, 0, tzinfo=timezone.utc)
        assert duration_between(a, b) == timedelta(hours=2)


class TestNextRetryAt:
    def test_first_retry(self):
        result = next_retry_at(0, base_delay=60)
        assert result > utc_now()

    def test_exponential_backoff(self):
        r1 = next_retry_at(0, base_delay=10)
        r2 = next_retry_at(2, base_delay=10)
        assert r2 > r1


class TestSplitDateRange:
    def test_split(self):
        start = datetime(2024, 1, 1)
        end = datetime(2024, 1, 10)
        ranges = split_date_range(start, end, timedelta(days=3))
        assert len(ranges) == 3
        assert ranges[0][0] == start
