"""Tests for TaskService."""

import pytest
from app.services.queue_service import QueueService
from app.services.task_service import TaskService
from app.exceptions import (
    NotFoundError, InvalidStateTransitionError,
    QueueFullError, ValidationError,
)


@pytest.fixture
def queue(db, sample_queue_data):
    svc = QueueService(db)
    return svc.create(sample_queue_data)


class TestTaskCreate:
    def test_basic(self, db, queue, sample_task_data):
        svc = TaskService(db)
        task = svc.create(sample_task_data)
        assert task.name == "test-task"
        assert task.status == "pending"
        assert task.queue_id == queue.id

    def test_with_tags(self, db, queue, sample_task_data):
        sample_task_data["tags"] = ["urgent", "email"]
        svc = TaskService(db)
        task = svc.create(sample_task_data)
        assert len(task.tags) == 2

    def test_queue_not_found(self, db, sample_task_data):
        sample_task_data["queue_name"] = "nonexistent"
        svc = TaskService(db)
        with pytest.raises(NotFoundError):
            svc.create(sample_task_data)

    def test_idempotency(self, db, queue, sample_task_data):
        sample_task_data["idempotency_key"] = "unique-key-1"
        svc = TaskService(db)
        t1 = svc.create(sample_task_data)
        t2 = svc.create(sample_task_data)
        assert t1.id == t2.id

    def test_queue_full(self, db, sample_queue_data, sample_task_data):
        sample_queue_data["max_size"] = 1
        qsvc = QueueService(db)
        qsvc.create(sample_queue_data)
        svc = TaskService(db)
        svc.create(sample_task_data)
        with pytest.raises(QueueFullError):
            svc.create({**sample_task_data, "name": "second-task"})


class TestTaskGet:
    def test_get(self, db, queue, sample_task_data):
        svc = TaskService(db)
        created = svc.create(sample_task_data)
        fetched = svc.get(created.id)
        assert fetched.name == created.name

    def test_not_found(self, db):
        svc = TaskService(db)
        with pytest.raises(NotFoundError):
            svc.get(999)


class TestTaskList:
    def test_list_all(self, db, queue, sample_task_data):
        svc = TaskService(db)
        svc.create(sample_task_data)
        tasks, total = svc.list_tasks()
        assert total == 1

    def test_filter_by_status(self, db, queue, sample_task_data):
        svc = TaskService(db)
        svc.create(sample_task_data)
        tasks, total = svc.list_tasks(filters={"status": "pending"})
        assert total == 1
        tasks, total = svc.list_tasks(filters={"status": "running"})
        assert total == 0


class TestTaskTransition:
    def test_pending_to_queued(self, db, queue, sample_task_data):
        svc = TaskService(db)
        task = svc.create(sample_task_data)
        updated = svc.transition_status(task.id, "queued")
        assert updated.status == "queued"

    def test_queued_to_running(self, db, queue, sample_task_data):
        svc = TaskService(db)
        task = svc.create(sample_task_data)
        svc.transition_status(task.id, "queued")
        updated = svc.transition_status(task.id, "running")
        assert updated.status == "running"
        assert updated.started_at is not None

    def test_running_to_success(self, db, queue, sample_task_data):
        svc = TaskService(db)
        task = svc.create(sample_task_data)
        svc.transition_status(task.id, "queued")
        svc.transition_status(task.id, "running")
        updated = svc.transition_status(task.id, "success", result={"ok": True})
        assert updated.status == "success"
        assert updated.completed_at is not None
        assert updated.duration_seconds is not None

    def test_running_to_failed(self, db, queue, sample_task_data):
        svc = TaskService(db)
        task = svc.create(sample_task_data)
        svc.transition_status(task.id, "queued")
        svc.transition_status(task.id, "running")
        updated = svc.transition_status(task.id, "failed", error_message="boom")
        assert updated.status == "failed"
        assert updated.error_message == "boom"

    def test_invalid_transition(self, db, queue, sample_task_data):
        svc = TaskService(db)
        task = svc.create(sample_task_data)
        with pytest.raises(InvalidStateTransitionError):
            svc.transition_status(task.id, "success")

    def test_retry_increments_count(self, db, queue, sample_task_data):
        svc = TaskService(db)
        task = svc.create(sample_task_data)
        svc.transition_status(task.id, "queued")
        svc.transition_status(task.id, "running")
        svc.transition_status(task.id, "failed")
        updated = svc.transition_status(task.id, "retrying")
        assert updated.retry_count == 1


class TestTaskCancel:
    def test_cancel_pending(self, db, queue, sample_task_data):
        svc = TaskService(db)
        task = svc.create(sample_task_data)
        cancelled = svc.cancel(task.id)
        assert cancelled.status == "cancelled"

    def test_cancel_terminal_fails(self, db, queue, sample_task_data):
        svc = TaskService(db)
        task = svc.create(sample_task_data)
        svc.transition_status(task.id, "queued")
        svc.transition_status(task.id, "running")
        svc.transition_status(task.id, "success")
        with pytest.raises(InvalidStateTransitionError):
            svc.cancel(task.id)


class TestTaskRetry:
    def test_retry_failed(self, db, queue, sample_task_data):
        svc = TaskService(db)
        task = svc.create(sample_task_data)
        svc.transition_status(task.id, "queued")
        svc.transition_status(task.id, "running")
        svc.transition_status(task.id, "failed")
        retried = svc.retry(task.id)
        assert retried.status == "retrying"

    def test_retry_dead_letter(self, db, queue, sample_task_data):
        sample_task_data["max_retries"] = 0
        svc = TaskService(db)
        task = svc.create(sample_task_data)
        svc.transition_status(task.id, "queued")
        svc.transition_status(task.id, "running")
        svc.transition_status(task.id, "failed")
        svc.transition_status(task.id, "dead_letter")
        retried = svc.retry(task.id)
        assert retried.status == "queued"
        assert retried.retry_count == 0


class TestTaskProgress:
    def test_update_progress(self, db, queue, sample_task_data):
        svc = TaskService(db)
        task = svc.create(sample_task_data)
        svc.transition_status(task.id, "queued")
        svc.transition_status(task.id, "running")
        updated = svc.update_progress(task.id, 50)
        assert updated.progress == 50

    def test_progress_clamp(self, db, queue, sample_task_data):
        svc = TaskService(db)
        task = svc.create(sample_task_data)
        svc.transition_status(task.id, "queued")
        svc.transition_status(task.id, "running")
        updated = svc.update_progress(task.id, 150)
        assert updated.progress == 100

    def test_progress_wrong_state(self, db, queue, sample_task_data):
        svc = TaskService(db)
        task = svc.create(sample_task_data)
        with pytest.raises(ValidationError):
            svc.update_progress(task.id, 50)


class TestBulkOperations:
    def test_bulk_create(self, db, queue, sample_task_data):
        svc = TaskService(db)
        tasks_data = [
            {**sample_task_data, "name": f"task-{i}"}
            for i in range(5)
        ]
        tasks = svc.bulk_create(tasks_data, batch_id="batch-1")
        assert len(tasks) == 5

    def test_bulk_cancel(self, db, queue, sample_task_data):
        svc = TaskService(db)
        t1 = svc.create({**sample_task_data, "name": "t1"})
        t2 = svc.create({**sample_task_data, "name": "t2"})
        result = svc.bulk_cancel([t1.id, t2.id])
        assert result["succeeded"] == 2
