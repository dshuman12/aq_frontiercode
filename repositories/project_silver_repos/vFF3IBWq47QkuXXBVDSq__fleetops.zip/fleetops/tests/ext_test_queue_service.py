"""Tests for QueueService."""

import pytest
from app.services.queue_service import QueueService
from app.exceptions import DuplicateError, NotFoundError, InvalidStateTransitionError, ValidationError


class TestQueueCreate:
    def test_create_basic(self, db, sample_queue_data):
        svc = QueueService(db)
        queue = svc.create(sample_queue_data)
        assert queue.name == "test.queue"
        assert queue.status == "active"
        assert queue.max_size == 1000

    def test_create_with_tags(self, db, sample_queue_data):
        sample_queue_data["tags"] = ["important", "email"]
        svc = QueueService(db)
        queue = svc.create(sample_queue_data)
        assert len(queue.tags) == 2

    def test_duplicate_name(self, db, sample_queue_data):
        svc = QueueService(db)
        svc.create(sample_queue_data)
        with pytest.raises(DuplicateError):
            svc.create(sample_queue_data)


class TestQueueGet:
    def test_get_by_id(self, db, sample_queue_data):
        svc = QueueService(db)
        created = svc.create(sample_queue_data)
        fetched = svc.get(created.id)
        assert fetched.name == created.name

    def test_not_found(self, db):
        svc = QueueService(db)
        with pytest.raises(NotFoundError):
            svc.get(999)

    def test_get_by_name(self, db, sample_queue_data):
        svc = QueueService(db)
        svc.create(sample_queue_data)
        fetched = svc.get_by_name("test.queue")
        assert fetched.name == "test.queue"


class TestQueueList:
    def test_list_all(self, db, sample_queue_data):
        svc = QueueService(db)
        svc.create(sample_queue_data)
        queues, total = svc.list_queues()
        assert total == 1
        assert len(queues) == 1

    def test_list_with_status(self, db, sample_queue_data):
        svc = QueueService(db)
        svc.create(sample_queue_data)
        queues, total = svc.list_queues(status="active")
        assert total == 1

    def test_pagination(self, db):
        svc = QueueService(db)
        for i in range(5):
            svc.create({"name": f"queue{i}", "max_size": 100})
        queues, total = svc.list_queues(offset=2, limit=2)
        assert total == 5
        assert len(queues) == 2


class TestQueueUpdate:
    def test_update_fields(self, db, sample_queue_data):
        svc = QueueService(db)
        queue = svc.create(sample_queue_data)
        updated = svc.update(queue.id, {"display_name": "Updated Name", "max_size": 5000})
        assert updated.display_name == "Updated Name"
        assert updated.max_size == 5000

    def test_update_tags(self, db, sample_queue_data):
        svc = QueueService(db)
        queue = svc.create(sample_queue_data)
        updated = svc.update(queue.id, {"tags": ["new-tag"]})
        assert len(updated.tags) == 1
        assert updated.tags[0].tag == "new-tag"


class TestQueueDelete:
    def test_delete_empty(self, db, sample_queue_data):
        svc = QueueService(db)
        queue = svc.create(sample_queue_data)
        svc.delete(queue.id)
        with pytest.raises(NotFoundError):
            svc.get(queue.id)


class TestQueueTransition:
    def test_pause(self, db, sample_queue_data):
        svc = QueueService(db)
        queue = svc.create(sample_queue_data)
        paused = svc.transition_status(queue.id, "paused")
        assert paused.status == "paused"
        assert paused.paused_at is not None

    def test_resume(self, db, sample_queue_data):
        svc = QueueService(db)
        queue = svc.create(sample_queue_data)
        svc.transition_status(queue.id, "paused")
        resumed = svc.transition_status(queue.id, "active")
        assert resumed.status == "active"

    def test_invalid_transition(self, db, sample_queue_data):
        svc = QueueService(db)
        queue = svc.create(sample_queue_data)
        svc.transition_status(queue.id, "disabled")
        with pytest.raises(InvalidStateTransitionError):
            svc.transition_status(queue.id, "paused")


class TestQueueStats:
    def test_empty_queue(self, db, sample_queue_data):
        svc = QueueService(db)
        queue = svc.create(sample_queue_data)
        stats = svc.get_stats(queue.id)
        assert stats["total_tasks"] == 0
        assert stats["queue_name"] == "test.queue"
