from app.utils.retry import (ConstantBackoff, LinearBackoff, ExponentialBackoff,
    FibonacciBackoff, get_backoff_strategy, RetryContext)
import pytest

class TestConstant:
    def test_constant(self):
        b = ConstantBackoff(delay=5.0)
        assert b.get_delay(0) == 5.0
        assert b.get_delay(99) == 5.0
class TestLinear:
    def test_linear(self):
        b = LinearBackoff(base_delay=1.0, increment=2.0)
        assert b.get_delay(0) == 1.0
        assert b.get_delay(1) == 3.0
    def test_max(self):
        b = LinearBackoff(base_delay=1.0, increment=100.0, max_delay=50.0)
        assert b.get_delay(1) == 50.0
class TestExponential:
    def test_basic(self):
        b = ExponentialBackoff(base_delay=1.0, factor=2.0, jitter=False)
        assert b.get_delay(0) == 1.0
        assert b.get_delay(1) == 2.0
        assert b.get_delay(2) == 4.0
    def test_max(self):
        b = ExponentialBackoff(base_delay=1.0, max_delay=10.0, jitter=False)
        assert b.get_delay(100) == 10.0
class TestFibonacci:
    def test_fib(self):
        b = FibonacciBackoff(base_delay=1.0)
        assert b.get_delay(0) == 1.0
        assert b.get_delay(1) == 1.0
        assert b.get_delay(2) == 2.0
        assert b.get_delay(3) == 3.0
        assert b.get_delay(4) == 5.0
class TestFactory:
    def test_constant(self): assert isinstance(get_backoff_strategy("constant"), ConstantBackoff)
    def test_exponential(self): assert isinstance(get_backoff_strategy("exponential"), ExponentialBackoff)
    def test_invalid(self):
        with pytest.raises(ValueError): get_backoff_strategy("random")
class TestRetryContext:
    def test_should_retry(self):
        ctx = RetryContext(max_retries=2)
        assert ctx.should_retry is True
        ctx.record_attempt(ValueError("e1")); ctx.record_attempt(ValueError("e2")); ctx.record_attempt(ValueError("e3"))
        assert ctx.should_retry is False
    def test_summary(self):
        ctx = RetryContext(max_retries=1)
        ctx.record_attempt(ValueError("x"))
        s = ctx.get_summary()
        assert s["attempts"] == 1 and len(s["errors"]) == 1
