from datetime import datetime, timedelta
from app.utils.date_utils import (utc_now, start_of_day, end_of_day, days_ago, days_from_now,
    hours_between, is_expired, format_date, format_datetime, add_seconds, time_bucket)

class TestUtcNow:
    def test_type(self): assert isinstance(utc_now(), datetime)
class TestStartOfDay:
    def test_clear(self): assert start_of_day(datetime(2024,6,15,14,30)).hour == 0
class TestEndOfDay:
    def test_end(self): assert end_of_day(datetime(2024,6,15)).hour == 23
class TestDaysAgo:
    def test_basic(self): assert (utc_now() - days_ago(7)).days >= 6
class TestIsExpired:
    def test_not(self): assert not is_expired(utc_now(), 365)
    def test_yes(self): assert is_expired(utc_now() - timedelta(days=400), 365)
class TestHoursBetween:
    def test_basic(self): assert abs(hours_between(datetime(2024,1,1,0,0), datetime(2024,1,1,3,0)) - 3.0) < 0.01
class TestFormatDate:
    def test_none(self): assert format_date(None) == "-"
    def test_date(self): assert format_date(datetime(2024,6,15)) == "2024-06-15"
class TestAddSeconds:
    def test_basic(self): assert add_seconds(datetime(2024,1,1,0,0,0), 60).minute == 1
class TestTimeBucket:
    def test_basic(self):
        dt = datetime(2024,1,1,14,37)
        bucketed = time_bucket(dt, 60)
        assert bucketed.minute == 0
