"""Tests for ScheduleService."""

import pytest
from app.services.schedule_service import ScheduleService
from app.exceptions import DuplicateError, NotFoundError
from app.utils.date_utils import utc_now


@pytest.fixture
def schedule_data():
    return {
        "name": "daily-cleanup",
        "cron_expression": "0 2 * * *",
        "task_name": "cleanup-old-tasks",
        "task_type": "maintenance.cleanup",
        "queue_name": "maintenance",
    }


class TestScheduleCreate:
    def test_basic(self, db, schedule_data):
        svc = ScheduleService(db)
        schedule = svc.create(schedule_data)
        assert schedule.name == "daily-cleanup"
        assert schedule.cron_expression == "0 2 * * *"
        assert schedule.status == "active"

    def test_duplicate(self, db, schedule_data):
        svc = ScheduleService(db)
        svc.create(schedule_data)
        with pytest.raises(DuplicateError):
            svc.create(schedule_data)

    def test_with_payload(self, db, schedule_data):
        schedule_data["task_payload"] = {"retention_days": 30}
        svc = ScheduleService(db)
        schedule = svc.create(schedule_data)
        assert schedule.task_payload is not None


class TestScheduleUpdate:
    def test_update_cron(self, db, schedule_data):
        svc = ScheduleService(db)
        schedule = svc.create(schedule_data)
        updated = svc.update(schedule.id, {"cron_expression": "0 3 * * *"})
        assert updated.cron_expression == "0 3 * * *"


class TestScheduleEnable:
    def test_disable_enable(self, db, schedule_data):
        svc = ScheduleService(db)
        schedule = svc.create(schedule_data)
        disabled = svc.disable(schedule.id)
        assert disabled.enabled is False
        assert disabled.status == "disabled"
        enabled = svc.enable(schedule.id)
        assert enabled.enabled is True
        assert enabled.status == "active"


class TestSchedulePause:
    def test_pause(self, db, schedule_data):
        svc = ScheduleService(db)
        schedule = svc.create(schedule_data)
        paused = svc.pause(schedule.id)
        assert paused.status == "paused"


class TestScheduleRun:
    def test_record_run(self, db, schedule_data):
        svc = ScheduleService(db)
        schedule = svc.create(schedule_data)
        run = svc.record_run(schedule.id, scheduled_for=utc_now(), task_id=1)
        assert run.status == "triggered"

    def test_run_count(self, db, schedule_data):
        svc = ScheduleService(db)
        schedule = svc.create(schedule_data)
        svc.record_run(schedule.id, scheduled_for=utc_now())
        svc.record_run(schedule.id, scheduled_for=utc_now())
        schedule = svc.get(schedule.id)
        assert schedule.run_count == 2

    def test_get_runs(self, db, schedule_data):
        svc = ScheduleService(db)
        schedule = svc.create(schedule_data)
        svc.record_run(schedule.id, scheduled_for=utc_now())
        runs, total = svc.get_runs(schedule.id)
        assert total == 1


class TestScheduleDelete:
    def test_delete(self, db, schedule_data):
        svc = ScheduleService(db)
        schedule = svc.create(schedule_data)
        svc.delete(schedule.id)
        with pytest.raises(NotFoundError):
            svc.get(schedule.id)
