"""Tests for pipeline step output chaining, conditional execution, and failure continuation."""

import json
import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.database import Base
from app.services.pipeline_service import PipelineService
from app.utils.constants import PipelineStatus, PipelineStepStatus


@pytest.fixture
def db():
    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    Base.metadata.create_all(bind=engine)
    Session = sessionmaker(bind=engine)
    session = Session()
    yield session
    session.close()
    Base.metadata.drop_all(bind=engine)


@pytest.fixture
def svc(db):
    return PipelineService(db)


@pytest.fixture
def three_step_pipeline(svc):
    return svc.create({
        "name": "etl-chain",
        "queue_name": "default",
        "on_failure": "stop",
        "steps": [
            {"name": "extract", "task_type": "etl.extract"},
            {"name": "transform", "task_type": "etl.transform"},
            {"name": "load", "task_type": "etl.load"},
        ],
    })


# ── output chaining ──────────────────────────────────────────────────


def test_completed_step_output_flows_into_next_step_input(svc, three_step_pipeline):
    run = svc.start_run(three_step_pipeline.id)
    run = svc.advance_run(run.id)  # starts extract (step 0)

    svc.complete_step(run.id, 0, success=True,
                      output_data={"rows": 42, "source": "s3"})

    run = svc.advance_run(run.id)  # should start transform (step 1)

    step1 = [sr for sr in run.step_runs if sr.step_index == 1][0]
    assert step1.status == PipelineStepStatus.RUNNING
    received = json.loads(step1.input_data) if step1.input_data else None
    assert received is not None, "transform step must receive extract's output as input"
    assert received["rows"] == 42
    assert received["source"] == "s3"


def test_first_step_receives_run_level_input(svc, three_step_pipeline):
    run = svc.start_run(three_step_pipeline.id,
                        {"input_data": {"bucket": "raw"}})
    run = svc.advance_run(run.id)

    step0 = [sr for sr in run.step_runs if sr.step_index == 0][0]
    received = json.loads(step0.input_data) if step0.input_data else None
    assert received is not None, "first step must receive run-level input"
    assert received["bucket"] == "raw"


def test_output_chain_accumulates_across_all_steps(svc, three_step_pipeline):
    run = svc.start_run(three_step_pipeline.id,
                        {"input_data": {"origin": "api"}})
    run = svc.advance_run(run.id)
    svc.complete_step(run.id, 0, success=True, output_data={"extracted": 100})
    run = svc.advance_run(run.id)
    svc.complete_step(run.id, 1, success=True, output_data={"transformed": 95})
    run = svc.advance_run(run.id)

    step2 = [sr for sr in run.step_runs if sr.step_index == 2][0]
    received = json.loads(step2.input_data) if step2.input_data else None
    assert received is not None
    assert received["transformed"] == 95


# ── failure continuation ─────────────────────────────────────────────


def test_continue_on_failure_runs_remaining_steps(svc):
    pipeline = svc.create({
        "name": "resilient-pipe",
        "queue_name": "default",
        "on_failure": "continue",
        "steps": [
            {"name": "step-a", "task_type": "a"},
            {"name": "step-b", "task_type": "b", "continue_on_failure": True},
            {"name": "step-c", "task_type": "c"},
        ],
    })
    run = svc.start_run(pipeline.id)
    run = svc.advance_run(run.id)  # starts step-a
    svc.complete_step(run.id, 0, success=True)

    run = svc.advance_run(run.id)  # starts step-b
    svc.complete_step(run.id, 1, success=False, error_message="non-critical error")

    run = svc.advance_run(run.id)  # must start step-c, NOT deadlock
    step_c = [sr for sr in run.step_runs if sr.step_index == 2][0]
    assert step_c.status == PipelineStepStatus.RUNNING, \
        "step-c must start even though step-b failed (continue_on_failure)"


def test_continue_mode_completes_pipeline_when_all_done(svc):
    pipeline = svc.create({
        "name": "continue-complete",
        "queue_name": "default",
        "on_failure": "continue",
        "steps": [
            {"name": "s1", "task_type": "t1", "continue_on_failure": True},
            {"name": "s2", "task_type": "t2"},
        ],
    })
    run = svc.start_run(pipeline.id)
    svc.advance_run(run.id)
    svc.complete_step(run.id, 0, success=False, error_message="oops")
    svc.advance_run(run.id)
    svc.complete_step(run.id, 1, success=True)
    run = svc.advance_run(run.id)

    assert run.status == PipelineStatus.COMPLETED


def test_stop_mode_still_halts_on_failure(svc, three_step_pipeline):
    run = svc.start_run(three_step_pipeline.id)
    svc.advance_run(run.id)
    run = svc.complete_step(run.id, 0, success=False, error_message="bad data")

    assert run.status == PipelineStatus.FAILED
    remaining = [sr for sr in run.step_runs if sr.step_index > 0]
    assert all(sr.status == PipelineStepStatus.SKIPPED for sr in remaining)


# ── conditional execution ────────────────────────────────────────────


def test_condition_false_skips_step(svc):
    pipeline = svc.create({
        "name": "conditional-pipe",
        "queue_name": "default",
        "steps": [
            {"name": "check", "task_type": "check"},
            {"name": "expensive", "task_type": "compute",
             "condition": "prev.output.should_run == true"},
            {"name": "report", "task_type": "report"},
        ],
    })
    run = svc.start_run(pipeline.id)
    svc.advance_run(run.id)
    svc.complete_step(run.id, 0, success=True,
                      output_data={"should_run": False})

    run = svc.advance_run(run.id)
    expensive = [sr for sr in run.step_runs if sr.step_index == 1][0]
    assert expensive.status == PipelineStepStatus.SKIPPED, \
        "step with false condition must be skipped"

    report = [sr for sr in run.step_runs if sr.step_index == 2][0]
    assert report.status == PipelineStepStatus.RUNNING, \
        "step after skipped step must run"


def test_condition_true_runs_step(svc):
    pipeline = svc.create({
        "name": "cond-true",
        "queue_name": "default",
        "steps": [
            {"name": "gate", "task_type": "gate"},
            {"name": "action", "task_type": "action",
             "condition": "prev.output.enabled == true"},
        ],
    })
    run = svc.start_run(pipeline.id)
    svc.advance_run(run.id)
    svc.complete_step(run.id, 0, success=True, output_data={"enabled": True})

    run = svc.advance_run(run.id)
    action = [sr for sr in run.step_runs if sr.step_index == 1][0]
    assert action.status == PipelineStepStatus.RUNNING


def test_condition_on_first_step_with_no_prev_is_always_run(svc):
    pipeline = svc.create({
        "name": "cond-first",
        "queue_name": "default",
        "steps": [
            {"name": "first", "task_type": "start",
             "condition": "prev.output.x == 1"},
        ],
    })
    run = svc.start_run(pipeline.id)
    run = svc.advance_run(run.id)
    step = [sr for sr in run.step_runs if sr.step_index == 0][0]
    assert step.status == PipelineStepStatus.RUNNING, \
        "first step condition should be ignored (no prev context)"


def test_condition_after_failed_prev_step_skips(svc):
    pipeline = svc.create({
        "name": "cond-after-fail",
        "queue_name": "default",
        "on_failure": "continue",
        "steps": [
            {"name": "risky", "task_type": "risky", "continue_on_failure": True},
            {"name": "depends-on-success", "task_type": "dep",
             "condition": "prev.success == true"},
            {"name": "always", "task_type": "cleanup"},
        ],
    })
    run = svc.start_run(pipeline.id)
    svc.advance_run(run.id)
    svc.complete_step(run.id, 0, success=False, error_message="boom")

    run = svc.advance_run(run.id)
    dep_step = [sr for sr in run.step_runs if sr.step_index == 1][0]
    assert dep_step.status == PipelineStepStatus.SKIPPED, \
        "condition 'prev.success == true' must skip when prev failed"

    cleanup = [sr for sr in run.step_runs if sr.step_index == 2][0]
    assert cleanup.status == PipelineStepStatus.RUNNING


# ── existing behaviour preserved ─────────────────────────────────────


def test_basic_linear_execution_still_works(svc, three_step_pipeline):
    run = svc.start_run(three_step_pipeline.id)

    for i in range(3):
        run = svc.advance_run(run.id)
        step = [sr for sr in run.step_runs if sr.step_index == i][0]
        assert step.status == PipelineStepStatus.RUNNING
        svc.complete_step(run.id, i, success=True)

    run = svc.advance_run(run.id)
    assert run.status == PipelineStatus.COMPLETED


def test_cancel_run_still_works(svc, three_step_pipeline):
    run = svc.start_run(three_step_pipeline.id)
    svc.advance_run(run.id)
    cancelled = svc.cancel_run(run.id)
    assert cancelled.status == PipelineStatus.CANCELLED
