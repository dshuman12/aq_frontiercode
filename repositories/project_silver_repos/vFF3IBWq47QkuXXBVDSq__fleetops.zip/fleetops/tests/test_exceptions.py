from app.exceptions import (FleetOpsError, NotFoundError, DuplicateError, InvalidStateError,
    ValidationError, WorkflowError, ConditionError, RetryExhaustedError, CircuitOpenError,
    RateLimitError, WebhookDeliveryError, TenantError, EventPayloadError, DeadLetterError)

class TestExceptions:
    def test_base(self): e = FleetOpsError("err", "CODE"); assert str(e) == "err" and e.code == "CODE"
    def test_not_found(self): e = NotFoundError("Workflow", 1); assert "1" in e.message
    def test_duplicate(self): e = DuplicateError("Workflow", "name", "test"); assert "test" in e.message
    def test_invalid_state(self):
        e = InvalidStateError("Workflow", "draft", "active"); assert "draft" in e.message
    def test_validation(self): e = ValidationError("bad", field="x"); assert e.field == "x"
    def test_workflow(self): e = WorkflowError("not active"); assert e.code == "WORKFLOW_ERROR"
    def test_condition(self): e = ConditionError("bad expr", "a==b"); assert e.expression == "a==b"
    def test_retry_exhausted(self): e = RetryExhaustedError("e1", 3); assert "3" in e.message
    def test_circuit_open(self): e = CircuitOpenError("payments"); assert e.target == "payments"
    def test_rate_limit(self): e = RateLimitError("tenant1", 100); assert "100" in e.message
    def test_webhook(self):
        e = WebhookDeliveryError("https://x.com", 500); assert "500" in e.message
    def test_tenant(self): e = TenantError("suspended"); assert e.code == "TENANT_ERROR"
    def test_payload(self): e = EventPayloadError("too big"); assert e.code == "PAYLOAD_ERROR"
    def test_dlq(self): e = DeadLetterError("full"); assert e.code == "DLQ_ERROR"
