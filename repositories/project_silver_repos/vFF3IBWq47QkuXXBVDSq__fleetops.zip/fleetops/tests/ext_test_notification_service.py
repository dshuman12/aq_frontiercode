"""Tests for NotificationService."""

from app.services.notification_service import NotificationService, EmailChannel, SlackChannel


class TestEmailChannel:
    def test_send(self):
        ch = EmailChannel()
        assert ch.send("user@test.com", "Subject", "Body") is True
        assert len(ch.sent) == 1


class TestSlackChannel:
    def test_send(self):
        ch = SlackChannel()
        assert ch.send("#general", "Alert", "Something happened") is True
        assert len(ch.sent) == 1


class TestNotificationService:
    def test_send_email(self, db):
        svc = NotificationService(db)
        result = svc.send("email", "admin@test.com", "Test", "Body")
        assert result is True

    def test_send_unknown_channel(self, db):
        svc = NotificationService(db)
        result = svc.send("sms", "+1234", "Test", "Body")
        assert result is False

    def test_notify_task_failure(self, db):
        svc = NotificationService(db)
        sent = svc.notify_task_failure(1, "test-task", "Connection error")
        assert sent == 1

    def test_notify_pipeline_completion(self, db):
        svc = NotificationService(db)
        sent = svc.notify_pipeline_completion("etl", 1, "completed")
        assert sent == 1

    def test_sent_log(self, db):
        svc = NotificationService(db)
        svc.send("email", "a@b.com", "S", "B")
        log = svc.get_sent_log()
        assert len(log) == 1

    def test_custom_channel(self, db):
        svc = NotificationService(db)
        svc.register_channel("custom", EmailChannel())
        result = svc.send("custom", "user@test.com", "Hi", "Hello")
        assert result is True
