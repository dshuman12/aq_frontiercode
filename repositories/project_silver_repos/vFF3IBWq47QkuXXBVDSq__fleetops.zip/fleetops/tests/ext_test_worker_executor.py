"""Tests for TaskExecutor, RetryPolicy, and WorkerPool."""

import pytest
from app.worker import (
    TaskExecutor,
    LoggingMiddleware,
    MetricsMiddleware,
    RetryPolicy,
    WorkerPool,
)


class TestTaskExecutor:
    def test_register_and_execute(self):
        executor = TaskExecutor()
        executor.register_handler("echo", lambda p: p)
        result = executor.execute(1, "echo", {"msg": "hello"})
        assert result["status"] == "success"
        assert result["result"] == {"msg": "hello"}

    def test_execute_no_handler(self):
        executor = TaskExecutor()
        with pytest.raises(ValueError, match="No handler"):
            executor.execute(1, "unknown")

    def test_handler_error(self):
        executor = TaskExecutor()
        executor.register_handler("fail", lambda p: 1 / 0)
        result = executor.execute(1, "fail")
        assert result["status"] == "failed"
        assert "division" in result["error"]

    def test_has_handler(self):
        executor = TaskExecutor()
        executor.register_handler("test", lambda p: None)
        assert executor.has_handler("test") is True
        assert executor.has_handler("other") is False

    def test_list_handlers(self):
        executor = TaskExecutor()
        executor.register_handler("a", lambda p: None)
        executor.register_handler("b", lambda p: None)
        assert sorted(executor.list_handlers()) == ["a", "b"]

    def test_unregister(self):
        executor = TaskExecutor()
        executor.register_handler("test", lambda p: None)
        executor.unregister_handler("test")
        assert executor.has_handler("test") is False

    def test_middleware(self):
        executor = TaskExecutor()
        metrics = MetricsMiddleware()
        executor.add_middleware(metrics)
        executor.register_handler("test", lambda p: "ok")
        executor.execute(1, "test")
        assert metrics.execution_count == 1
        assert metrics.success_count == 1

    def test_running_tasks(self):
        executor = TaskExecutor()
        # No tasks running initially
        assert executor.get_running_tasks() == {}

    def test_cancel_nonexistent(self):
        executor = TaskExecutor()
        assert executor.cancel_task(999) is False

    def test_duration_tracked(self):
        executor = TaskExecutor()
        executor.register_handler("slow", lambda p: "done")
        result = executor.execute(1, "slow")
        assert result["duration_seconds"] >= 0


class TestRetryPolicy:
    def test_should_retry(self):
        policy = RetryPolicy(max_retries=3)
        assert policy.should_retry(0, Exception("test")) is True
        assert policy.should_retry(3, Exception("test")) is False

    def test_get_delay(self):
        policy = RetryPolicy(base_delay=1.0, backoff_factor=2.0)
        assert policy.get_delay(0) == 1.0
        assert policy.get_delay(1) == 2.0
        assert policy.get_delay(2) == 4.0

    def test_max_delay(self):
        policy = RetryPolicy(base_delay=100, max_delay=200)
        assert policy.get_delay(5) == 200

    def test_execute_with_retry_success(self):
        policy = RetryPolicy(max_retries=3, base_delay=0.001)
        call_count = 0
        def flaky(x):
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise ValueError("not yet")
            return x
        result = policy.execute_with_retry(flaky, 42)
        assert result == 42
        assert call_count == 3

    def test_execute_with_retry_exhausted(self):
        policy = RetryPolicy(max_retries=1, base_delay=0.001)
        with pytest.raises(ZeroDivisionError):
            policy.execute_with_retry(lambda: 1 / 0)


class TestMetricsMiddleware:
    def test_metrics(self):
        m = MetricsMiddleware()
        m.before_execute(1, "test", None)
        m.after_execute(1, "test", "ok")
        metrics = m.get_metrics()
        assert metrics["executions"] == 1
        assert metrics["successes"] == 1

    def test_avg_duration_zero(self):
        m = MetricsMiddleware()
        assert m.get_metrics()["avg_duration"] == 0


class TestWorkerPool:
    def test_initialize(self):
        pool = WorkerPool(pool_size=2)
        pool.initialize()
        status = pool.get_pool_status()
        assert status["pool_size"] == 2
        assert status["active"] == 0

    def test_get_release(self):
        pool = WorkerPool(pool_size=2)
        pool.initialize()
        e1 = pool.get_executor()
        assert e1 is not None
        assert pool.get_pool_status()["active"] == 1
        pool.release_executor()
        assert pool.get_pool_status()["active"] == 0

    def test_pool_exhausted(self):
        pool = WorkerPool(pool_size=1)
        pool.initialize()
        pool.get_executor()
        assert pool.get_executor() is None

    def test_shutdown(self):
        pool = WorkerPool(pool_size=2)
        pool.initialize()
        pool.shutdown()
        assert pool.get_pool_status()["active"] == 0
