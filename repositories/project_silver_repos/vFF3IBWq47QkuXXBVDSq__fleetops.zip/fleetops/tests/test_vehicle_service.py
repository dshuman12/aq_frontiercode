"""Tests for VehicleService."""
import pytest
from app.services.vehicle_service import VehicleService
from app.exceptions import NotFoundError, DuplicateError, InvalidStateError, VehicleGroundedError, ValidationError

class TestVehicleCreate:
    def test_basic(self, db, vehicle_data):
        svc = VehicleService(db); v = svc.create(vehicle_data)
        assert v.plate == "AB-1234" and v.status == "available"
    def test_duplicate_plate(self, db, vehicle_data):
        svc = VehicleService(db); svc.create(vehicle_data)
        with pytest.raises(DuplicateError): svc.create(vehicle_data)
    def test_duplicate_vin(self, db, vehicle_data):
        svc = VehicleService(db); svc.create(vehicle_data)
        vehicle_data["plate"] = "CD-5678"
        with pytest.raises(DuplicateError): svc.create(vehicle_data)

class TestVehicleGet:
    def test_get(self, db, vehicle_data):
        svc = VehicleService(db); v = svc.create(vehicle_data)
        assert svc.get(v.id).plate == "AB-1234"
    def test_not_found(self, db):
        with pytest.raises(NotFoundError): VehicleService(db).get(999)
    def test_by_plate(self, db, vehicle_data):
        svc = VehicleService(db); svc.create(vehicle_data)
        assert svc.get_by_plate("AB-1234").vin == "1HGBH41JXMN109186"

class TestVehicleTransition:
    def test_to_en_route(self, db, vehicle_data):
        svc = VehicleService(db); v = svc.create(vehicle_data)
        updated = svc.transition_status(v.id, "en_route"); assert updated.status == "en_route"
    def test_ground(self, db, vehicle_data):
        svc = VehicleService(db); v = svc.create(vehicle_data)
        grounded = svc.transition_status(v.id, "grounded", "accident")
        assert grounded.status == "grounded" and grounded.grounded_reason == "accident"
    def test_invalid(self, db, vehicle_data):
        svc = VehicleService(db); v = svc.create(vehicle_data)
        svc.transition_status(v.id, "decommissioned")
        with pytest.raises(InvalidStateError): svc.transition_status(v.id, "available")

class TestVehicleLocation:
    def test_update(self, db, vehicle_data):
        svc = VehicleService(db); v = svc.create(vehicle_data)
        loc = svc.update_location(v.id, 9.05, 7.49, 60.0)
        assert loc.latitude == 9.05
    def test_history(self, db, vehicle_data):
        svc = VehicleService(db); v = svc.create(vehicle_data)
        svc.update_location(v.id, 9.05, 7.49); svc.update_location(v.id, 9.06, 7.50)
        assert len(svc.get_location_history(v.id)) == 2

class TestVehicleFuel:
    def test_update(self, db, vehicle_data):
        svc = VehicleService(db); v = svc.create(vehicle_data)
        svc.update_fuel(v.id, 75.0); assert svc.get(v.id).fuel_level_pct == 75.0
    def test_clamp(self, db, vehicle_data):
        svc = VehicleService(db); v = svc.create(vehicle_data)
        svc.update_fuel(v.id, 150.0); assert svc.get(v.id).fuel_level_pct == 100.0

class TestVehicleOdometer:
    def test_update(self, db, vehicle_data):
        svc = VehicleService(db); v = svc.create(vehicle_data)
        svc.update_odometer(v.id, 50000); assert svc.get(v.id).odometer_km == 50000
    def test_decrease_fails(self, db, vehicle_data):
        svc = VehicleService(db); v = svc.create(vehicle_data)
        svc.update_odometer(v.id, 50000)
        with pytest.raises(ValidationError): svc.update_odometer(v.id, 40000)

class TestVehicleDriver:
    def test_assign(self, db, vehicle_data, driver_data):
        from app.services.driver_service import DriverService
        svc = VehicleService(db); v = svc.create(vehicle_data)
        driver = DriverService(db).create(driver_data)
        v = svc.assign_driver(v.id, driver.id); assert v.assigned_driver_id == driver.id
    def test_assign_grounded(self, db, vehicle_data, driver_data):
        from app.services.driver_service import DriverService
        svc = VehicleService(db); v = svc.create(vehicle_data)
        svc.transition_status(v.id, "grounded", "broken")
        driver = DriverService(db).create(driver_data)
        with pytest.raises(VehicleGroundedError): svc.assign_driver(v.id, driver.id)

class TestVehicleDelete:
    def test_delete(self, db, vehicle_data):
        svc = VehicleService(db); v = svc.create(vehicle_data)
        svc.delete(v.id)
        with pytest.raises(NotFoundError): svc.get(v.id)
    def test_delete_en_route(self, db, vehicle_data):
        svc = VehicleService(db); v = svc.create(vehicle_data)
        svc.transition_status(v.id, "en_route")
        with pytest.raises(ValidationError): svc.delete(v.id)

class TestFleetStats:
    def test_empty(self, db): assert VehicleService(db).get_fleet_stats()["total"] == 0
    def test_with_data(self, db, vehicle_data):
        VehicleService(db).create(vehicle_data)
        assert VehicleService(db).get_fleet_stats()["total"] == 1
