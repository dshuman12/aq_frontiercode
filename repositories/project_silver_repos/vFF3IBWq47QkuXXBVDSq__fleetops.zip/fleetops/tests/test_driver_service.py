"""Tests for DriverService."""
import pytest
from app.services.driver_service import DriverService
from app.exceptions import NotFoundError, DuplicateError, InvalidStateError, DriverHoursExceededError

class TestDriverCreate:
    def test_basic(self, db, driver_data):
        svc = DriverService(db); d = svc.create(driver_data)
        assert d.name == "John Doe" and d.status == "available"
    def test_duplicate(self, db, driver_data):
        svc = DriverService(db); svc.create(driver_data)
        with pytest.raises(DuplicateError): svc.create(driver_data)

class TestDriverTransition:
    def test_to_on_duty(self, db, driver_data):
        svc = DriverService(db); d = svc.create(driver_data)
        d = svc.transition_status(d.id, "on_duty"); assert d.status == "on_duty"
    def test_to_driving(self, db, driver_data):
        svc = DriverService(db); d = svc.create(driver_data)
        svc.transition_status(d.id, "on_duty")
        d = svc.transition_status(d.id, "driving"); assert d.status == "driving"
    def test_invalid(self, db, driver_data):
        svc = DriverService(db); d = svc.create(driver_data)
        with pytest.raises(InvalidStateError): svc.transition_status(d.id, "driving")
    def test_hours_exceeded(self, db, driver_data):
        svc = DriverService(db); d = svc.create(driver_data)
        d.total_hours_today = 12.0; db.commit()
        svc.transition_status(d.id, "on_duty")
        with pytest.raises(DriverHoursExceededError): svc.transition_status(d.id, "driving")

class TestDriverShift:
    def test_start_end(self, db, driver_data):
        svc = DriverService(db); d = svc.create(driver_data)
        shift = svc.start_shift(d.id); assert shift.status == "active"
        ended = svc.end_shift(shift.id, hours_driven=4.0, distance_km=200)
        assert ended.status == "completed"
        d = svc.get(d.id); assert d.total_hours_today == 4.0
