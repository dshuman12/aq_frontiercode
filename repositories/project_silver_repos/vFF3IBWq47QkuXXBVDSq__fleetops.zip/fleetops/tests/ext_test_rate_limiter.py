"""Tests for RateLimiter."""

from app.services.rate_limiter import RateLimiter


class TestRateLimiter:
    def test_allow_under_limit(self):
        rl = RateLimiter(default_limit=5, default_window=60)
        allowed, info = rl.is_allowed("user1")
        assert allowed is True

    def test_block_over_limit(self):
        rl = RateLimiter(default_limit=2, default_window=60)
        rl.is_allowed("user1")
        rl.is_allowed("user1")
        allowed, info = rl.is_allowed("user1")
        assert allowed is False
        assert info["remaining"] == 0

    def test_different_keys(self):
        rl = RateLimiter(default_limit=1, default_window=60)
        a1, _ = rl.is_allowed("user1")
        a2, _ = rl.is_allowed("user2")
        assert a1 is True
        assert a2 is True

    def test_custom_limits(self):
        rl = RateLimiter()
        allowed, info = rl.is_allowed("key", limit=1, window=60)
        assert allowed is True
        allowed, info = rl.is_allowed("key", limit=1, window=60)
        assert allowed is False

    def test_reset(self):
        rl = RateLimiter(default_limit=1, default_window=60)
        rl.is_allowed("user1")
        rl.is_allowed("user1")
        rl.reset("user1")
        allowed, _ = rl.is_allowed("user1")
        assert allowed is True

    def test_reset_all(self):
        rl = RateLimiter(default_limit=1, default_window=60)
        rl.is_allowed("a")
        rl.is_allowed("b")
        rl.reset_all()
        assert rl.get_all_keys() == []

    def test_get_usage(self):
        rl = RateLimiter(default_limit=10, default_window=60)
        rl.is_allowed("k1")
        rl.is_allowed("k1")
        usage = rl.get_usage("k1")
        assert usage["count"] == 2
