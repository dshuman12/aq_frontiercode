"""Tests for AuditService."""

from app.services.audit_service import AuditService


class TestAuditLog:
    def test_create_log(self, db):
        svc = AuditService(db)
        entry = svc.log("Queue", 1, "create", actor="admin")
        assert entry.entity_type == "Queue"
        assert entry.action == "create"
        assert entry.actor == "admin"

    def test_list_logs(self, db):
        svc = AuditService(db)
        svc.log("Queue", 1, "create")
        svc.log("Task", 1, "cancel")
        logs, total = svc.list_logs()
        assert total == 2

    def test_filter_by_entity(self, db):
        svc = AuditService(db)
        svc.log("Queue", 1, "create")
        svc.log("Task", 1, "cancel")
        logs, total = svc.list_logs(entity_type="Queue")
        assert total == 1

    def test_count_by_action(self, db):
        svc = AuditService(db)
        svc.log("Queue", 1, "create")
        svc.log("Queue", 2, "create")
        svc.log("Task", 1, "cancel")
        counts = svc.count_by_action()
        assert counts["create"] == 2
        assert counts["cancel"] == 1

    def test_purge(self, db):
        svc = AuditService(db)
        svc.log("Queue", 1, "create")
        deleted = svc.purge_old_logs(days=0)
        assert deleted >= 0
