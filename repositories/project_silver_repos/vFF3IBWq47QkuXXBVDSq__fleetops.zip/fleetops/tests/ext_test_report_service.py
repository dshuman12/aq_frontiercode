"""Tests for ReportService."""

from app.services.report_service import ReportService
from app.services.queue_service import QueueService
from app.services.task_service import TaskService


class TestDailySummary:
    def test_empty(self, db):
        svc = ReportService(db)
        report = svc.daily_summary()
        assert report["tasks_created"] == 0
        assert report["tasks_completed"] == 0


class TestQueueReport:
    def test_report(self, db, sample_queue_data):
        qsvc = QueueService(db)
        qsvc.create(sample_queue_data)
        svc = ReportService(db)
        report = svc.queue_report()
        assert len(report) == 1
        assert report[0]["name"] == "test.queue"


class TestExportCsv:
    def test_export_tasks(self, db, sample_queue_data, sample_task_data):
        qsvc = QueueService(db)
        qsvc.create(sample_queue_data)
        tsvc = TaskService(db)
        tsvc.create(sample_task_data)
        svc = ReportService(db)
        csv = svc.export_tasks_csv()
        assert "test-task" in csv

    def test_export_queues(self, db, sample_queue_data):
        qsvc = QueueService(db)
        qsvc.create(sample_queue_data)
        svc = ReportService(db)
        csv = svc.export_queues_csv()
        assert "test.queue" in csv
