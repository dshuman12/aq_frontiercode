import pytest
from app.utils.helpers import (slugify, truncate, compute_hash, mask_string, format_duration,
    safe_json_loads, safe_json_dumps, deep_merge, chunk_list, sanitize_metadata,
    generate_workflow_id, generate_run_id, generate_event_id, generate_api_key,
    validate_json_path, resolve_json_path, match_event_pattern)

class TestSlugify:
    def test_basic(self): assert slugify("My Workflow!") == "my-workflow"
    def test_empty(self): assert slugify("") == ""
class TestTruncate:
    def test_short(self): assert truncate("hi", 10) == "hi"
    def test_long(self): assert truncate("hello world", 8) == "hello..."
class TestComputeHash:
    def test_deterministic(self): assert compute_hash({"a": 1, "b": 2}) == compute_hash({"b": 2, "a": 1})
    def test_different(self): assert compute_hash("a") != compute_hash("b")
class TestMask:
    def test_basic(self): assert mask_string("secret1234") == "******1234"
    def test_short(self): assert mask_string("ab", 4) == "ab"
class TestDuration:
    def test_seconds(self): assert format_duration(45) == "45s"
    def test_hours(self): assert format_duration(3661) == "1h 1m 1s"
    def test_negative(self): assert format_duration(-1) == "0s"
class TestJson:
    def test_loads_valid(self): assert safe_json_loads('{"a":1}') == {"a": 1}
    def test_loads_invalid(self): assert safe_json_loads("bad") is None
    def test_loads_none(self): assert safe_json_loads(None) is None
    def test_dumps(self): assert safe_json_dumps({"a": 1}) is not None
    def test_dumps_none(self): assert safe_json_dumps(None) is None
class TestDeepMerge:
    def test_nested(self): assert deep_merge({"a": {"x": 1}}, {"a": {"y": 2}}) == {"a": {"x": 1, "y": 2}}
    def test_override(self): assert deep_merge({"a": 1}, {"a": 2}) == {"a": 2}
class TestChunk:
    def test_even(self): assert chunk_list([1,2,3,4], 2) == [[1,2],[3,4]]
    def test_remainder(self): assert chunk_list([1,2,3], 2) == [[1,2],[3]]
    def test_invalid(self):
        with pytest.raises(ValueError): chunk_list([1], 0)
class TestSanitize:
    def test_deep(self): assert sanitize_metadata({"a":{"b":{"c":"d"}}}, 2)["a"]["b"] == "<truncated>"
class TestGenerators:
    def test_workflow_id(self): assert generate_workflow_id().startswith("wf-")
    def test_run_id(self): assert generate_run_id().startswith("run-")
    def test_event_id(self): assert generate_event_id().startswith("evt-")
    def test_api_key(self): assert generate_api_key().startswith("nx_")
class TestJsonPath:
    def test_valid(self): assert validate_json_path("data.user.name") == ["data", "user", "name"]
    def test_empty(self):
        with pytest.raises(ValueError): validate_json_path("")
    def test_resolve(self): assert resolve_json_path({"data": {"x": 1}}, "data.x") == 1
    def test_resolve_missing(self): assert resolve_json_path({"a": 1}, "b.c") is None
class TestEventPattern:
    def test_exact(self): assert match_event_pattern("order.created", "order.created") is True
    def test_wildcard(self): assert match_event_pattern("order.*", "order.created") is True
    def test_no_match(self): assert match_event_pattern("order.created", "user.signup") is False
    def test_star_all(self): assert match_event_pattern("*", "anything.here") is True
    def test_double_star(self): assert match_event_pattern("order.**.shipped", "order.us.shipped") is True
    def test_double_star_deep(self): assert match_event_pattern("order.**", "order.a.b.c") is True
