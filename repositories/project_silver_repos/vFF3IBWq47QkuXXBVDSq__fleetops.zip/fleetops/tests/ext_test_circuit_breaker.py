"""Tests for circuit breaker."""

import pytest
from app.utils.circuit_breaker import (
    CircuitBreaker,
    CircuitBreakerRegistry,
    CircuitOpenError,
    CircuitState,
)


class TestCircuitBreaker:
    def test_initial_closed(self):
        cb = CircuitBreaker("test")
        assert cb.state == CircuitState.CLOSED

    def test_call_passes_through(self):
        cb = CircuitBreaker("test")
        result = cb.call(lambda: 42)
        assert result == 42

    def test_trip_on_failures(self):
        cb = CircuitBreaker("test", failure_threshold=3)
        for _ in range(3):
            try:
                cb.call(lambda: 1 / 0)
            except ZeroDivisionError:
                pass
        assert cb.state == CircuitState.OPEN

    def test_open_rejects_calls(self):
        cb = CircuitBreaker("test", failure_threshold=1)
        try:
            cb.call(lambda: 1 / 0)
        except ZeroDivisionError:
            pass
        with pytest.raises(CircuitOpenError):
            cb.call(lambda: 42)

    def test_reset(self):
        cb = CircuitBreaker("test", failure_threshold=1)
        try:
            cb.call(lambda: 1 / 0)
        except ZeroDivisionError:
            pass
        assert cb.is_open
        cb.reset()
        assert cb.state == CircuitState.CLOSED

    def test_stats(self):
        cb = CircuitBreaker("test")
        cb.call(lambda: 1)
        stats = cb.get_stats()
        assert stats["name"] == "test"
        assert stats["total_calls"] == 1
        assert stats["state"] == "closed"


class TestCircuitBreakerRegistry:
    def test_get_or_create(self):
        reg = CircuitBreakerRegistry()
        cb1 = reg.get_or_create("test")
        cb2 = reg.get_or_create("test")
        assert cb1 is cb2

    def test_list_all(self):
        reg = CircuitBreakerRegistry()
        reg.get_or_create("a")
        reg.get_or_create("b")
        all_stats = reg.list_all()
        assert len(all_stats) == 2

    def test_reset_all(self):
        reg = CircuitBreakerRegistry()
        cb = reg.get_or_create("test", failure_threshold=1)
        try:
            cb.call(lambda: 1 / 0)
        except ZeroDivisionError:
            pass
        reg.reset_all()
        assert cb.state == CircuitState.CLOSED

    def test_get_nonexistent(self):
        reg = CircuitBreakerRegistry()
        assert reg.get("nope") is None
