"""Tests for MetricsService."""

from app.services.metrics_service import MetricsService


class TestMetricsRecord:
    def test_record(self, db):
        svc = MetricsService(db)
        snapshot = svc.record("cpu.usage", 45.5, labels={"host": "w1"})
        assert snapshot.metric_name == "cpu.usage"
        assert snapshot.metric_value == 45.5

    def test_record_batch(self, db):
        svc = MetricsService(db)
        count = svc.record_batch([
            {"name": "cpu.usage", "value": 40.0},
            {"name": "mem.usage", "value": 60.0},
        ])
        assert count == 2


class TestMetricsQuery:
    def test_query_avg(self, db):
        svc = MetricsService(db)
        svc.record("cpu", 40.0)
        svc.record("cpu", 60.0)
        result = svc.query("cpu", aggregation="avg")
        assert result["value"] == 50.0

    def test_query_sum(self, db):
        svc = MetricsService(db)
        svc.record("tasks", 10.0)
        svc.record("tasks", 20.0)
        result = svc.query("tasks", aggregation="sum")
        assert result["value"] == 30.0

    def test_query_min_max(self, db):
        svc = MetricsService(db)
        svc.record("temp", 10.0)
        svc.record("temp", 50.0)
        result = svc.query("temp")
        assert result["min"] == 10.0
        assert result["max"] == 50.0

    def test_query_empty(self, db):
        svc = MetricsService(db)
        result = svc.query("nonexistent")
        assert result["count"] == 0


class TestMetricsLatest:
    def test_get_latest(self, db):
        svc = MetricsService(db)
        svc.record("cpu", 40.0)
        svc.record("cpu", 60.0)
        assert svc.get_latest("cpu") == 60.0

    def test_get_latest_none(self, db):
        svc = MetricsService(db)
        assert svc.get_latest("missing") is None


class TestMetricsList:
    def test_list_metrics(self, db):
        svc = MetricsService(db)
        svc.record("cpu", 40.0)
        svc.record("mem", 60.0)
        names = svc.list_metrics()
        assert sorted(names) == ["cpu", "mem"]


class TestMetricsTimeSeries:
    def test_time_series(self, db):
        svc = MetricsService(db)
        svc.record("cpu", 40.0)
        svc.record("cpu", 60.0)
        series = svc.get_time_series("cpu")
        assert len(series) >= 1
