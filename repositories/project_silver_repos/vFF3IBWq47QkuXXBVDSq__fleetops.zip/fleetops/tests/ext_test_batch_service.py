"""Tests for BatchService."""

from app.services.batch_service import BatchService
from app.services.queue_service import QueueService


class TestBatchCreate:
    def test_create_batch(self, db, sample_queue_data, sample_task_data):
        qsvc = QueueService(db)
        qsvc.create(sample_queue_data)
        svc = BatchService(db)
        tasks_data = [
            {**sample_task_data, "name": f"batch-task-{i}"}
            for i in range(3)
        ]
        result = svc.create_batch(tasks_data, batch_id="batch-123")
        assert result["batch_id"] == "batch-123"
        assert result["created"] == 3


class TestBatchStatus:
    def test_status(self, db, sample_queue_data, sample_task_data):
        qsvc = QueueService(db)
        qsvc.create(sample_queue_data)
        svc = BatchService(db)
        tasks_data = [{**sample_task_data, "name": f"t{i}"} for i in range(3)]
        svc.create_batch(tasks_data, batch_id="batch-456")
        status = svc.get_batch_status("batch-456")
        assert status["total"] == 3
        assert status["completed"] is False

    def test_empty_batch(self, db):
        svc = BatchService(db)
        status = svc.get_batch_status("nonexistent")
        assert status["total"] == 0


class TestBatchCancel:
    def test_cancel(self, db, sample_queue_data, sample_task_data):
        qsvc = QueueService(db)
        qsvc.create(sample_queue_data)
        svc = BatchService(db)
        tasks_data = [{**sample_task_data, "name": f"t{i}"} for i in range(3)]
        svc.create_batch(tasks_data, batch_id="batch-789")
        result = svc.cancel_batch("batch-789")
        assert result["cancelled"] == 3
