"""Tests for app.utils.security."""

from app.utils.security import (
    hash_password,
    verify_password,
    generate_api_key,
    hash_api_key,
    sign_webhook_payload,
    verify_webhook_signature,
    generate_nonce,
    generate_idempotency_key,
    constant_time_compare,
    obfuscate_key,
)


class TestPasswordHashing:
    def test_hash_and_verify(self):
        hashed = hash_password("secret123")
        assert verify_password("secret123", hashed)

    def test_wrong_password(self):
        hashed = hash_password("secret123")
        assert not verify_password("wrong", hashed)

    def test_different_hashes(self):
        h1 = hash_password("same")
        h2 = hash_password("same")
        assert h1 != h2


class TestApiKey:
    def test_generate(self):
        key = generate_api_key()
        assert key.startswith("tq_")
        assert len(key) > 20

    def test_hash(self):
        key = generate_api_key()
        hashed = hash_api_key(key)
        assert len(hashed) == 64
        assert hashed != key


class TestWebhookSignature:
    def test_sign_and_verify(self):
        payload = b'{"event": "task.completed"}'
        secret = "my-secret"
        sig = sign_webhook_payload(payload, secret)
        assert verify_webhook_signature(payload, secret, sig)

    def test_wrong_secret(self):
        payload = b"test"
        sig = sign_webhook_payload(payload, "secret1")
        assert not verify_webhook_signature(payload, "secret2", sig)

    def test_tampered_payload(self):
        payload = b"original"
        sig = sign_webhook_payload(payload, "secret")
        assert not verify_webhook_signature(b"tampered", "secret", sig)


class TestNonce:
    def test_length(self):
        n = generate_nonce(16)
        assert len(n) == 16

    def test_uniqueness(self):
        n1 = generate_nonce(32)
        n2 = generate_nonce(32)
        assert n1 != n2


class TestIdempotencyKey:
    def test_format(self):
        key = generate_idempotency_key()
        assert key.startswith("idem_")


class TestConstantTimeCompare:
    def test_equal(self):
        assert constant_time_compare("abc", "abc")

    def test_not_equal(self):
        assert not constant_time_compare("abc", "def")


class TestObfuscateKey:
    def test_long(self):
        result = obfuscate_key("tq_abcdef123456", 8)
        assert result.startswith("tq_abcde")
        assert "..." in result

    def test_short(self):
        result = obfuscate_key("ab", 8)
        assert result == "ab"
