# FleetOps

Logistics fleet management platform for vehicle tracking, route planning,
maintenance scheduling, driver compliance, fuel monitoring, and dispatch.

## Features
- Vehicle fleet management with status state machines
- Route planning with stop optimization (nearest-neighbor)
- Driver compliance tracking (hours-of-service, license expiry)
- Maintenance scheduling with overdue detection
- Fuel monitoring with consumption analytics
- Geofencing with circle-intersection detection
- Incident reporting with auto-grounding
- Dispatch assignment with resource allocation
- Multi-fleet isolation
- Real-time location tracking

## Quick Start
```bash
pip install -r requirements.txt
make dev
```
