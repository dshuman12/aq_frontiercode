# Changelog
## [0.9.0] - 2025-07-01
- Workflow engine with DAG execution
- Event routing and filtering
- Retry policies and DLQ
- Webhook delivery system
- Multi-tenant support

### Fixed
- Condition evaluation edge cases
