"""Service layer for dead letter queue management."""

from __future__ import annotations

from datetime import timedelta
from typing import Any

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.models.dead_letter import DeadLetterEntry
from app.utils.date_utils import utc_now


class DeadLetterService:
    """Manages dead letter entries — review, requeue, and resolution."""

    def __init__(self, db: Session):
        self.db = db

    def add_entry(
        self,
        task_id: int,
        queue_name: str,
        task_name: str,
        task_type: str,
        payload: str | None = None,
        error_message: str | None = None,
        error_traceback: str | None = None,
    ) -> DeadLetterEntry:
        """Add a failed task to the dead letter queue."""
        now = utc_now()
        existing = (
            self.db.query(DeadLetterEntry)
            .filter(DeadLetterEntry.original_task_id == task_id)
            .first()
        )
        if existing:
            existing.error_count += 1
            existing.last_failed_at = now
            existing.error_message = error_message
            existing.error_traceback = error_traceback
            self.db.commit()
            self.db.refresh(existing)
            return existing

        entry = DeadLetterEntry(
            original_task_id=task_id,
            queue_name=queue_name,
            task_name=task_name,
            task_type=task_type,
            payload=payload,
            error_message=error_message,
            error_traceback=error_traceback,
            first_failed_at=now,
            last_failed_at=now,
        )
        self.db.add(entry)
        self.db.commit()
        self.db.refresh(entry)
        return entry

    def get(self, entry_id: int) -> DeadLetterEntry | None:
        """Get a DLQ entry by ID."""
        return self.db.query(DeadLetterEntry).filter(DeadLetterEntry.id == entry_id).first()

    def list_entries(
        self,
        queue_name: str | None = None,
        task_type: str | None = None,
        resolved: bool | None = None,
        offset: int = 0,
        limit: int = 20,
    ) -> tuple[list[DeadLetterEntry], int]:
        """List DLQ entries with optional filters."""
        query = self.db.query(DeadLetterEntry)
        if queue_name:
            query = query.filter(DeadLetterEntry.queue_name == queue_name)
        if task_type:
            query = query.filter(DeadLetterEntry.task_type == task_type)
        if resolved is not None:
            if resolved:
                query = query.filter(DeadLetterEntry.resolved_at.isnot(None))
            else:
                query = query.filter(DeadLetterEntry.resolved_at.is_(None))
        total = query.count()
        entries = query.order_by(DeadLetterEntry.last_failed_at.desc()).offset(offset).limit(limit).all()
        return entries, total

    def resolve(
        self,
        entry_id: int,
        resolution: str,
        resolved_by: str | None = None,
        notes: str | None = None,
    ) -> DeadLetterEntry | None:
        """Mark a DLQ entry as resolved."""
        entry = self.get(entry_id)
        if not entry:
            return None
        entry.resolution = resolution
        entry.resolved_at = utc_now()
        entry.resolved_by = resolved_by
        entry.notes = notes
        self.db.commit()
        self.db.refresh(entry)
        return entry

    def mark_requeued(self, entry_id: int) -> DeadLetterEntry | None:
        """Mark a DLQ entry as requeued."""
        entry = self.get(entry_id)
        if not entry:
            return None
        entry.requeued += 1
        entry.requeued_at = utc_now()
        self.db.commit()
        self.db.refresh(entry)
        return entry

    def get_stats(self) -> dict[str, Any]:
        """Get DLQ statistics."""
        total = self.db.query(func.count(DeadLetterEntry.id)).scalar() or 0
        unresolved = (
            self.db.query(func.count(DeadLetterEntry.id))
            .filter(DeadLetterEntry.resolved_at.is_(None))
            .scalar() or 0
        )
        by_queue = (
            self.db.query(DeadLetterEntry.queue_name, func.count(DeadLetterEntry.id))
            .filter(DeadLetterEntry.resolved_at.is_(None))
            .group_by(DeadLetterEntry.queue_name)
            .all()
        )
        by_error = (
            self.db.query(DeadLetterEntry.error_message, func.count(DeadLetterEntry.id))
            .filter(DeadLetterEntry.resolved_at.is_(None))
            .group_by(DeadLetterEntry.error_message)
            .order_by(func.count(DeadLetterEntry.id).desc())
            .limit(10)
            .all()
        )
        return {
            "total": total,
            "unresolved": unresolved,
            "resolved": total - unresolved,
            "by_queue": {q: c for q, c in by_queue},
            "top_errors": [{"error": e[:100] if e else "unknown", "count": c} for e, c in by_error],
        }

    def purge_resolved(self, older_than_days: int = 30) -> int:
        """Delete resolved entries older than N days."""
        cutoff = utc_now() - timedelta(days=older_than_days)
        count = (
            self.db.query(DeadLetterEntry)
            .filter(
                DeadLetterEntry.resolved_at.isnot(None),
                DeadLetterEntry.resolved_at < cutoff,
            )
            .delete()
        )
        self.db.commit()
        return count
