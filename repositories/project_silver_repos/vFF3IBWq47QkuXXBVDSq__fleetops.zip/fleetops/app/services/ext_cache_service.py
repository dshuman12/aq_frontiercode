"""In-memory cache with TTL support."""

from __future__ import annotations

import time
from threading import Lock
from typing import Any


class CacheEntry:
    """A single cached value with expiration."""

    __slots__ = ("value", "expires_at", "created_at")

    def __init__(self, value: Any, ttl: int):
        self.value = value
        self.created_at = time.monotonic()
        self.expires_at = self.created_at + ttl if ttl > 0 else float("inf")

    @property
    def is_expired(self) -> bool:
        return time.monotonic() > self.expires_at


class CacheService:
    """Simple in-memory cache with TTL, eviction, and stats."""

    def __init__(self, default_ttl: int = 300, max_size: int = 10000):
        self.default_ttl = default_ttl
        self.max_size = max_size
        self._store: dict[str, CacheEntry] = {}
        self._lock = Lock()
        self._hits = 0
        self._misses = 0

    def get(self, key: str) -> Any | None:
        """Get a value from cache. Returns None on miss or expiry."""
        with self._lock:
            entry = self._store.get(key)
            if entry is None:
                self._misses += 1
                return None
            if entry.is_expired:
                del self._store[key]
                self._misses += 1
                return None
            self._hits += 1
            return entry.value

    def set(self, key: str, value: Any, ttl: int | None = None) -> None:
        """Set a value in cache with optional TTL."""
        ttl = ttl if ttl is not None else self.default_ttl
        with self._lock:
            if len(self._store) >= self.max_size and key not in self._store:
                self._evict_expired()
                if len(self._store) >= self.max_size:
                    oldest_key = min(self._store, key=lambda k: self._store[k].created_at)
                    del self._store[oldest_key]
            self._store[key] = CacheEntry(value, ttl)

    def delete(self, key: str) -> bool:
        """Remove a key from cache. Returns True if it existed."""
        with self._lock:
            return self._store.pop(key, None) is not None

    def exists(self, key: str) -> bool:
        """Check if a non-expired key exists."""
        with self._lock:
            entry = self._store.get(key)
            if entry is None or entry.is_expired:
                return False
            return True

    def clear(self) -> int:
        """Clear all cached entries. Returns the count cleared."""
        with self._lock:
            count = len(self._store)
            self._store.clear()
            self._hits = 0
            self._misses = 0
            return count

    def get_stats(self) -> dict[str, Any]:
        """Cache hit/miss statistics."""
        with self._lock:
            total = self._hits + self._misses
            return {
                "size": len(self._store),
                "max_size": self.max_size,
                "hits": self._hits,
                "misses": self._misses,
                "hit_rate": (self._hits / total * 100) if total > 0 else 0,
                "default_ttl": self.default_ttl,
            }

    def get_keys(self, prefix: str | None = None) -> list[str]:
        """List cache keys, optionally filtered by prefix."""
        with self._lock:
            if prefix:
                return [k for k in self._store if k.startswith(prefix)]
            return list(self._store.keys())

    def _evict_expired(self) -> int:
        """Remove all expired entries. Caller must hold the lock."""
        expired = [k for k, v in self._store.items() if v.is_expired]
        for k in expired:
            del self._store[k]
        return len(expired)

    def get_or_set(self, key: str, factory: Any, ttl: int | None = None) -> Any:
        """Get from cache or compute and cache the value."""
        value = self.get(key)
        if value is not None:
            return value
        if callable(factory):
            value = factory()
        else:
            value = factory
        self.set(key, value, ttl)
        return value
