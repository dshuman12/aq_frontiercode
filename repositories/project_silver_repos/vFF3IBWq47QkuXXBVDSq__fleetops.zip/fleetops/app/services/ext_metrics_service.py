"""Service layer for recording and querying system metrics."""

from __future__ import annotations

import json
from datetime import timedelta
from typing import Any

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.models.dead_letter import MetricSnapshot
from app.utils.date_utils import utc_now


class MetricsService:
    """Records and queries time-series metric data."""

    def __init__(self, db: Session):
        self.db = db

    def record(
        self,
        metric_name: str,
        value: float,
        labels: dict[str, str] | None = None,
    ) -> MetricSnapshot:
        """Record a metric data point."""
        snapshot = MetricSnapshot(
            metric_name=metric_name,
            metric_value=value,
            labels=json.dumps(labels) if labels else None,
        )
        self.db.add(snapshot)
        self.db.commit()
        self.db.refresh(snapshot)
        return snapshot

    def record_batch(self, metrics: list[dict[str, Any]]) -> int:
        """Record multiple metrics at once."""
        count = 0
        for m in metrics:
            snapshot = MetricSnapshot(
                metric_name=m["name"],
                metric_value=m["value"],
                labels=json.dumps(m.get("labels")) if m.get("labels") else None,
            )
            self.db.add(snapshot)
            count += 1
        self.db.commit()
        return count

    def query(
        self,
        metric_name: str,
        hours: int = 24,
        aggregation: str = "avg",
    ) -> dict[str, Any]:
        """Query metric values over a time window."""
        cutoff = utc_now() - timedelta(hours=hours)
        query = self.db.query(MetricSnapshot).filter(
            MetricSnapshot.metric_name == metric_name,
            MetricSnapshot.recorded_at >= cutoff,
        )

        values = [s.metric_value for s in query.all()]
        if not values:
            return {"metric": metric_name, "count": 0, "value": None}

        if aggregation == "avg":
            result = sum(values) / len(values)
        elif aggregation == "sum":
            result = sum(values)
        elif aggregation == "min":
            result = min(values)
        elif aggregation == "max":
            result = max(values)
        elif aggregation == "count":
            result = len(values)
        else:
            result = sum(values) / len(values)

        return {
            "metric": metric_name,
            "aggregation": aggregation,
            "count": len(values),
            "value": result,
            "min": min(values),
            "max": max(values),
        }

    def get_latest(self, metric_name: str) -> float | None:
        """Get the latest value for a metric."""
        snapshot = (
            self.db.query(MetricSnapshot)
            .filter(MetricSnapshot.metric_name == metric_name)
            .order_by(MetricSnapshot.recorded_at.desc())
            .first()
        )
        return snapshot.metric_value if snapshot else None

    def list_metrics(self) -> list[str]:
        """List all distinct metric names."""
        rows = self.db.query(MetricSnapshot.metric_name).distinct().all()
        return [r[0] for r in rows]

    def get_time_series(
        self,
        metric_name: str,
        hours: int = 24,
        bucket_minutes: int = 60,
    ) -> list[dict[str, Any]]:
        """Get time-series data points grouped by time bucket."""
        cutoff = utc_now() - timedelta(hours=hours)
        snapshots = (
            self.db.query(MetricSnapshot)
            .filter(
                MetricSnapshot.metric_name == metric_name,
                MetricSnapshot.recorded_at >= cutoff,
            )
            .order_by(MetricSnapshot.recorded_at.asc())
            .all()
        )

        if not snapshots:
            return []

        from app.utils.date_utils import time_bucket
        buckets: dict[str, list[float]] = {}
        for s in snapshots:
            bucket = time_bucket(s.recorded_at, bucket_minutes)
            key = bucket.isoformat()
            if key not in buckets:
                buckets[key] = []
            buckets[key].append(s.metric_value)

        return [
            {
                "timestamp": ts,
                "avg": sum(vals) / len(vals),
                "min": min(vals),
                "max": max(vals),
                "count": len(vals),
            }
            for ts, vals in sorted(buckets.items())
        ]

    def purge_old(self, days: int = 30) -> int:
        """Delete metric snapshots older than N days."""
        cutoff = utc_now() - timedelta(days=days)
        count = (
            self.db.query(MetricSnapshot)
            .filter(MetricSnapshot.recorded_at < cutoff)
            .delete()
        )
        self.db.commit()
        return count
