"""Service layer for Task CRUD, state transitions, and dependency management."""

from __future__ import annotations

import json
from datetime import timedelta
from typing import Any

from sqlalchemy import func, and_, or_
from sqlalchemy.orm import Session

from app.exceptions import (
    DependencyError,
    DuplicateError,
    InvalidStateTransitionError,
    NotFoundError,
    QueueFullError,
    RetryExhaustedError,
    ValidationError,
)
from app.models.queue import Queue
from app.models.task import Task, TaskDependency, TaskTag
from app.utils.constants import (
    ACTIVE_TASK_STATES,
    TERMINAL_TASK_STATES,
    TaskPriority,
    TaskStatus,
    VALID_TASK_TRANSITIONS,
)
from app.utils.date_utils import next_retry_at, utc_now
from app.utils.helpers import compute_payload_hash
from app.utils.validators import (
    validate_metadata,
    validate_priority,
    validate_tags,
    validate_task_name,
)


class TaskService:
    """Manages task lifecycle including creation, transitions, retries, and dependencies."""

    def __init__(self, db: Session):
        self.db = db

    def create(self, data: dict[str, Any]) -> Task:
        """Create a new task and enqueue it."""
        name = validate_task_name(data["name"])

        queue = (
            self.db.query(Queue)
            .filter(Queue.name == data["queue_name"])
            .first()
        )
        if not queue:
            raise NotFoundError("Queue", data["queue_name"])

        pending_count = (
            self.db.query(func.count(Task.id))
            .filter(Task.queue_id == queue.id)
            .filter(Task.status.in_([TaskStatus.PENDING, TaskStatus.QUEUED]))
            .scalar()
        )
        if pending_count >= queue.max_size:
            raise QueueFullError(queue.name, queue.max_size)

        if data.get("idempotency_key"):
            existing = (
                self.db.query(Task)
                .filter(Task.idempotency_key == data["idempotency_key"])
                .first()
            )
            if existing:
                return existing

        payload_str = None
        payload_hash = None
        if data.get("payload"):
            payload_str = json.dumps(data["payload"], default=str)
            payload_hash = compute_payload_hash(payload_str)

        priority = data.get("priority", TaskPriority.NORMAL)
        if isinstance(priority, int):
            validate_priority(priority)

        metadata = validate_metadata(data.get("metadata"))
        metadata_json = json.dumps(metadata, default=str) if metadata else None

        task = Task(
            name=name,
            task_type=data["task_type"],
            queue_id=queue.id,
            priority=priority,
            payload=payload_str,
            payload_hash=payload_hash,
            timeout=data.get("timeout", queue.timeout),
            max_retries=data.get("max_retries", queue.max_retries),
            retry_delay=data.get("retry_delay", queue.retry_delay),
            scheduled_at=data.get("scheduled_at"),
            deadline=data.get("deadline"),
            idempotency_key=data.get("idempotency_key"),
            correlation_id=data.get("correlation_id"),
            metadata_json=metadata_json,
        )
        self.db.add(task)
        self.db.flush()

        if data.get("tags"):
            tags = validate_tags(data["tags"])
            for tag_name in tags:
                self.db.add(TaskTag(task_id=task.id, tag=tag_name))

        if data.get("depends_on"):
            self._add_dependencies(task, data["depends_on"])

        self.db.commit()
        self.db.refresh(task)
        return task

    def get(self, task_id: int) -> Task:
        """Get a task by ID or raise NotFoundError."""
        task = self.db.query(Task).filter(Task.id == task_id).first()
        if not task:
            raise NotFoundError("Task", task_id)
        return task

    def list_tasks(
        self,
        filters: dict[str, Any] | None = None,
        offset: int = 0,
        limit: int = 20,
    ) -> tuple[list[Task], int]:
        """List tasks with optional filters and pagination."""
        query = self.db.query(Task)
        filters = filters or {}

        if filters.get("status"):
            query = query.filter(Task.status == filters["status"])
        if filters.get("statuses"):
            query = query.filter(Task.status.in_(filters["statuses"]))
        if filters.get("queue_name"):
            queue = self.db.query(Queue).filter(
                Queue.name == filters["queue_name"]
            ).first()
            if queue:
                query = query.filter(Task.queue_id == queue.id)
        if filters.get("task_type"):
            query = query.filter(Task.task_type == filters["task_type"])
        if filters.get("priority_min"):
            query = query.filter(Task.priority >= filters["priority_min"])
        if filters.get("priority_max"):
            query = query.filter(Task.priority <= filters["priority_max"])
        if filters.get("created_after"):
            query = query.filter(Task.created_at >= filters["created_after"])
        if filters.get("created_before"):
            query = query.filter(Task.created_at <= filters["created_before"])
        if filters.get("correlation_id"):
            query = query.filter(Task.correlation_id == filters["correlation_id"])
        if filters.get("batch_id"):
            query = query.filter(Task.batch_id == filters["batch_id"])
        if filters.get("search"):
            search_term = f"%{filters['search']}%"
            query = query.filter(Task.name.ilike(search_term))

        total = query.count()
        tasks = (
            query
            .order_by(Task.priority.asc(), Task.created_at.asc())
            .offset(offset)
            .limit(limit)
            .all()
        )
        return tasks, total

    def update(self, task_id: int, data: dict[str, Any]) -> Task:
        """Update mutable task fields (only allowed before execution)."""
        task = self.get(task_id)
        if task.status not in (TaskStatus.PENDING, TaskStatus.QUEUED):
            raise ValidationError(
                f"Cannot update task in '{task.status}' state"
            )

        if data.get("name"):
            task.name = validate_task_name(data["name"])
        if data.get("priority") is not None:
            task.priority = validate_priority(data["priority"])
        if data.get("timeout") is not None:
            task.timeout = data["timeout"]
        if data.get("max_retries") is not None:
            task.max_retries = data["max_retries"]
        if data.get("scheduled_at") is not None:
            task.scheduled_at = data["scheduled_at"]
        if data.get("deadline") is not None:
            task.deadline = data["deadline"]

        if "tags" in data and data["tags"] is not None:
            tags = validate_tags(data["tags"])
            self.db.query(TaskTag).filter(TaskTag.task_id == task.id).delete()
            for tag_name in tags:
                self.db.add(TaskTag(task_id=task.id, tag=tag_name))

        if data.get("metadata") is not None:
            md = validate_metadata(data["metadata"])
            task.metadata_json = json.dumps(md, default=str) if md else None

        self.db.commit()
        self.db.refresh(task)
        return task

    def transition_status(
        self,
        task_id: int,
        new_status: str,
        error_message: str | None = None,
        result: dict[str, Any] | None = None,
    ) -> Task:
        """Transition a task to a new state, enforcing the state machine."""
        task = self.get(task_id)
        current = TaskStatus(task.status)
        target = TaskStatus(new_status)

        allowed = VALID_TASK_TRANSITIONS.get(current, [])
        if target not in allowed:
            raise InvalidStateTransitionError("Task", current.value, target.value)

        task.status = target

        if target == TaskStatus.RUNNING:
            task.started_at = utc_now()
        elif target == TaskStatus.SUCCESS:
            task.completed_at = utc_now()
            if task.started_at:
                task.duration_seconds = (
                    task.completed_at - task.started_at
                ).total_seconds()
            if result:
                task.result = json.dumps(result, default=str)
        elif target == TaskStatus.FAILED:
            task.completed_at = utc_now()
            task.error_message = error_message
            if task.started_at:
                task.duration_seconds = (
                    task.completed_at - task.started_at
                ).total_seconds()
        elif target == TaskStatus.RETRYING:
            task.retry_count += 1
            if task.retry_count > task.max_retries:
                task.status = TaskStatus.DEAD_LETTER
            else:
                task.next_retry_at = next_retry_at(
                    task.retry_count - 1,
                    base_delay=task.retry_delay,
                )
        elif target == TaskStatus.CANCELLED:
            task.completed_at = utc_now()

        self.db.commit()
        self.db.refresh(task)
        return task

    def cancel(self, task_id: int) -> Task:
        """Cancel a task if it's in a cancellable state."""
        task = self.get(task_id)
        current = TaskStatus(task.status)
        if current in TERMINAL_TASK_STATES:
            raise InvalidStateTransitionError("Task", current.value, "cancelled")
        return self.transition_status(task_id, TaskStatus.CANCELLED)

    def retry(self, task_id: int) -> Task:
        """Manually retry a failed or dead-lettered task."""
        task = self.get(task_id)
        current = TaskStatus(task.status)
        if current == TaskStatus.FAILED:
            return self.transition_status(task_id, TaskStatus.RETRYING)
        elif current == TaskStatus.DEAD_LETTER:
            task.retry_count = 0
            task.status = TaskStatus.QUEUED
            task.error_message = None
            task.completed_at = None
            task.started_at = None
            task.duration_seconds = None
            self.db.commit()
            self.db.refresh(task)
            return task
        else:
            raise InvalidStateTransitionError("Task", current.value, "retrying")

    def claim_next(self, queue_name: str, worker_id: int) -> Task | None:
        """Claim the next available task for a worker. Returns None if queue is empty."""
        queue = self.db.query(Queue).filter(Queue.name == queue_name).first()
        if not queue:
            return None

        if queue.status != "active":
            return None

        now = utc_now()
        query = (
            self.db.query(Task)
            .filter(
                Task.queue_id == queue.id,
                Task.status == TaskStatus.QUEUED,
                or_(Task.scheduled_at.is_(None), Task.scheduled_at <= now),
            )
        )

        if queue.priority_enabled:
            query = query.order_by(Task.priority.asc(), Task.created_at.asc())
        else:
            query = query.order_by(Task.created_at.asc())

        task = query.first()
        if not task:
            return None

        task.status = TaskStatus.RUNNING
        task.worker_id = worker_id
        task.started_at = now
        self.db.commit()
        self.db.refresh(task)
        return task

    def update_progress(self, task_id: int, progress: int) -> Task:
        """Update task progress (0-100)."""
        task = self.get(task_id)
        if task.status != TaskStatus.RUNNING:
            raise ValidationError(f"Cannot update progress for task in '{task.status}' state")
        task.progress = max(0, min(100, progress))
        self.db.commit()
        self.db.refresh(task)
        return task

    def bulk_create(self, tasks_data: list[dict[str, Any]], batch_id: str | None = None) -> list[Task]:
        """Create multiple tasks at once."""
        created: list[Task] = []
        for task_data in tasks_data:
            if batch_id:
                task_data["is_batch"] = True
            task = self.create(task_data)
            if batch_id:
                task.batch_id = batch_id
                task.is_batch = True
            created.append(task)
        self.db.commit()
        return created

    def bulk_cancel(self, task_ids: list[int]) -> dict[str, Any]:
        """Cancel multiple tasks."""
        succeeded = 0
        errors: list[dict[str, Any]] = []
        for tid in task_ids:
            try:
                self.cancel(tid)
                succeeded += 1
            except Exception as e:
                errors.append({"task_id": tid, "error": str(e)})
        return {"total": len(task_ids), "succeeded": succeeded, "failed": len(errors), "errors": errors}

    def get_by_correlation_id(self, correlation_id: str) -> list[Task]:
        """Find all tasks with a specific correlation ID."""
        return (
            self.db.query(Task)
            .filter(Task.correlation_id == correlation_id)
            .order_by(Task.created_at.asc())
            .all()
        )

    def check_dependencies_met(self, task_id: int) -> bool:
        """Check if all dependencies of a task have completed successfully."""
        deps = (
            self.db.query(TaskDependency)
            .filter(TaskDependency.task_id == task_id)
            .all()
        )
        if not deps:
            return True
        dep_ids = [d.depends_on_id for d in deps]
        completed = (
            self.db.query(func.count(Task.id))
            .filter(Task.id.in_(dep_ids), Task.status == TaskStatus.SUCCESS)
            .scalar()
        )
        return completed == len(dep_ids)

    def _add_dependencies(self, task: Task, dependency_ids: list[int]) -> None:
        """Add task dependencies, validating they exist and won't create cycles."""
        for dep_id in dependency_ids:
            dep_task = self.db.query(Task).filter(Task.id == dep_id).first()
            if not dep_task:
                raise NotFoundError("Task", dep_id)
            if dep_id == task.id:
                raise ValidationError("A task cannot depend on itself")
            self.db.add(TaskDependency(task_id=task.id, depends_on_id=dep_id))

    def get_dead_letter_tasks(
        self,
        queue_name: str | None = None,
        offset: int = 0,
        limit: int = 20,
    ) -> tuple[list[Task], int]:
        """List dead-lettered tasks."""
        query = self.db.query(Task).filter(Task.status == TaskStatus.DEAD_LETTER)
        if queue_name:
            queue = self.db.query(Queue).filter(Queue.name == queue_name).first()
            if queue:
                query = query.filter(Task.queue_id == queue.id)
        total = query.count()
        tasks = query.order_by(Task.created_at.desc()).offset(offset).limit(limit).all()
        return tasks, total

# End of task service
