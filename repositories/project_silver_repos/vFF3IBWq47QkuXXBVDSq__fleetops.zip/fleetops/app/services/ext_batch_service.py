"""Service layer for batch task operations."""

from __future__ import annotations

from typing import Any
from uuid import uuid4

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.models.task import Task
from app.models.queue import Queue
from app.utils.constants import TaskStatus, TERMINAL_TASK_STATES
from app.utils.date_utils import utc_now


class BatchService:
    """Manages batch task creation, monitoring, and lifecycle."""

    def __init__(self, db: Session):
        self.db = db

    def create_batch(
        self,
        tasks_data: list[dict[str, Any]],
        batch_id: str | None = None,
    ) -> dict[str, Any]:
        """Create a batch of tasks and return a summary."""
        if not batch_id:
            batch_id = f"batch_{uuid4().hex[:12]}"

        from app.services.task_service import TaskService
        task_svc = TaskService(self.db)

        created: list[int] = []
        errors: list[dict[str, Any]] = []

        for idx, td in enumerate(tasks_data):
            try:
                task = task_svc.create(td)
                task.batch_id = batch_id
                task.is_batch = True
                created.append(task.id)
            except Exception as e:
                errors.append({"index": idx, "error": str(e)})

        self.db.commit()

        return {
            "batch_id": batch_id,
            "total": len(tasks_data),
            "created": len(created),
            "failed": len(errors),
            "task_ids": created,
            "errors": errors,
        }

    def get_batch_status(self, batch_id: str) -> dict[str, Any]:
        """Get the aggregate status of a batch."""
        tasks = self.db.query(Task).filter(Task.batch_id == batch_id).all()
        if not tasks:
            return {"batch_id": batch_id, "total": 0}

        status_counts: dict[str, int] = {}
        for task in tasks:
            status_counts[task.status] = status_counts.get(task.status, 0) + 1

        total = len(tasks)
        terminal = sum(
            status_counts.get(s.value, 0) for s in TERMINAL_TASK_STATES
        )
        all_done = terminal == total

        return {
            "batch_id": batch_id,
            "total": total,
            "status_counts": status_counts,
            "completed": all_done,
            "progress_pct": (terminal / total * 100) if total > 0 else 0,
        }

    def cancel_batch(self, batch_id: str) -> dict[str, Any]:
        """Cancel all non-terminal tasks in a batch."""
        tasks = (
            self.db.query(Task)
            .filter(
                Task.batch_id == batch_id,
                Task.status.notin_([s.value for s in TERMINAL_TASK_STATES]),
            )
            .all()
        )
        cancelled = 0
        for task in tasks:
            task.status = TaskStatus.CANCELLED
            task.completed_at = utc_now()
            cancelled += 1
        self.db.commit()
        return {"batch_id": batch_id, "cancelled": cancelled}

    def retry_failed_in_batch(self, batch_id: str) -> dict[str, Any]:
        """Retry all failed tasks in a batch."""
        tasks = (
            self.db.query(Task)
            .filter(
                Task.batch_id == batch_id,
                Task.status.in_([TaskStatus.FAILED, TaskStatus.DEAD_LETTER]),
            )
            .all()
        )
        retried = 0
        for task in tasks:
            task.status = TaskStatus.QUEUED
            task.retry_count = 0
            task.error_message = None
            task.completed_at = None
            task.started_at = None
            task.duration_seconds = None
            retried += 1
        self.db.commit()
        return {"batch_id": batch_id, "retried": retried}

    def list_batches(
        self, offset: int = 0, limit: int = 20
    ) -> tuple[list[dict[str, Any]], int]:
        """List all batches with summary stats."""
        subq = (
            self.db.query(
                Task.batch_id,
                func.count(Task.id).label("total"),
                func.min(Task.created_at).label("created_at"),
            )
            .filter(Task.batch_id.isnot(None))
            .group_by(Task.batch_id)
            .subquery()
        )
        total = self.db.query(func.count()).select_from(subq).scalar() or 0

        rows = (
            self.db.query(subq)
            .order_by(subq.c.created_at.desc())
            .offset(offset)
            .limit(limit)
            .all()
        )

        batches = []
        for row in rows:
            batches.append({
                "batch_id": row.batch_id,
                "total": row.total,
                "created_at": row.created_at.isoformat() if row.created_at else None,
            })
        return batches, total
