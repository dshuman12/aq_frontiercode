"""Service layer for Pipeline definitions and execution."""

from __future__ import annotations

import json
from typing import Any

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.exceptions import (
    DuplicateError,
    InvalidStateTransitionError,
    NotFoundError,
    PipelineError,
    ValidationError,
)
from app.models.pipeline import Pipeline, PipelineStep, PipelineRun, PipelineStepRun
from app.utils.constants import PipelineStatus, PipelineStepStatus, VALID_PIPELINE_TRANSITIONS
from app.utils.date_utils import utc_now


class PipelineService:
    """Manages pipeline definitions, executions, and step tracking."""

    def __init__(self, db: Session):
        self.db = db

    def create(self, data: dict[str, Any]) -> Pipeline:
        """Create a new pipeline with its steps."""
        existing = self.db.query(Pipeline).filter(Pipeline.name == data["name"]).first()
        if existing:
            raise DuplicateError("Pipeline", "name", data["name"])

        if not data.get("steps"):
            raise ValidationError("Pipeline must have at least one step")

        metadata_json = None
        if data.get("metadata"):
            metadata_json = json.dumps(data["metadata"], default=str)

        pipeline = Pipeline(
            name=data["name"],
            description=data.get("description"),
            queue_name=data["queue_name"],
            on_failure=data.get("on_failure", "stop"),
            max_concurrent_runs=data.get("max_concurrent_runs", 1),
            timeout=data.get("timeout", 7200),
            metadata_json=metadata_json,
        )
        self.db.add(pipeline)
        self.db.flush()

        for idx, step_data in enumerate(data["steps"]):
            payload_template = None
            if step_data.get("task_payload_template"):
                payload_template = json.dumps(step_data["task_payload_template"], default=str)

            step = PipelineStep(
                pipeline_id=pipeline.id,
                step_index=idx,
                name=step_data["name"],
                task_type=step_data["task_type"],
                task_payload_template=payload_template,
                timeout=step_data.get("timeout", 3600),
                max_retries=step_data.get("max_retries", 0),
                continue_on_failure=step_data.get("continue_on_failure", False),
                condition=step_data.get("condition"),
            )
            self.db.add(step)

        self.db.commit()
        self.db.refresh(pipeline)
        return pipeline

    def get(self, pipeline_id: int) -> Pipeline:
        """Get a pipeline by ID."""
        pipeline = self.db.query(Pipeline).filter(Pipeline.id == pipeline_id).first()
        if not pipeline:
            raise NotFoundError("Pipeline", pipeline_id)
        return pipeline

    def get_by_name(self, name: str) -> Pipeline:
        """Get a pipeline by name."""
        pipeline = self.db.query(Pipeline).filter(Pipeline.name == name).first()
        if not pipeline:
            raise NotFoundError("Pipeline", name)
        return pipeline

    def list_pipelines(
        self, offset: int = 0, limit: int = 20
    ) -> tuple[list[Pipeline], int]:
        """List all pipelines."""
        query = self.db.query(Pipeline)
        total = query.count()
        pipelines = query.order_by(Pipeline.name).offset(offset).limit(limit).all()
        return pipelines, total

    def update(self, pipeline_id: int, data: dict[str, Any]) -> Pipeline:
        """Update a pipeline definition."""
        pipeline = self.get(pipeline_id)

        updatable = {
            "description", "queue_name", "on_failure",
            "max_concurrent_runs", "timeout", "enabled",
        }
        for key, value in data.items():
            if key in updatable and value is not None:
                setattr(pipeline, key, value)

        if "steps" in data and data["steps"] is not None:
            self.db.query(PipelineStep).filter(
                PipelineStep.pipeline_id == pipeline.id
            ).delete()
            for idx, step_data in enumerate(data["steps"]):
                payload_template = None
                if step_data.get("task_payload_template"):
                    payload_template = json.dumps(step_data["task_payload_template"], default=str)
                step = PipelineStep(
                    pipeline_id=pipeline.id,
                    step_index=idx,
                    name=step_data["name"],
                    task_type=step_data["task_type"],
                    task_payload_template=payload_template,
                    timeout=step_data.get("timeout", 3600),
                    max_retries=step_data.get("max_retries", 0),
                    continue_on_failure=step_data.get("continue_on_failure", False),
                    condition=step_data.get("condition"),
                )
                self.db.add(step)
            pipeline.version += 1

        if "metadata" in data:
            pipeline.metadata_json = (
                json.dumps(data["metadata"], default=str)
                if data["metadata"] else None
            )

        self.db.commit()
        self.db.refresh(pipeline)
        return pipeline

    def delete(self, pipeline_id: int) -> None:
        """Delete a pipeline and all its runs."""
        pipeline = self.get(pipeline_id)
        active_runs = (
            self.db.query(func.count(PipelineRun.id))
            .filter(
                PipelineRun.pipeline_id == pipeline.id,
                PipelineRun.status.in_([PipelineStatus.RUNNING, PipelineStatus.PENDING]),
            )
            .scalar()
        )
        if active_runs > 0:
            raise ValidationError(
                f"Cannot delete pipeline with {active_runs} active runs"
            )
        self.db.delete(pipeline)
        self.db.commit()

    def start_run(self, pipeline_id: int, data: dict[str, Any] | None = None) -> PipelineRun:
        """Start a new pipeline run."""
        data = data or {}
        pipeline = self.get(pipeline_id)
        if not pipeline.enabled:
            raise ValidationError(f"Pipeline '{pipeline.name}' is disabled")

        active_runs = (
            self.db.query(func.count(PipelineRun.id))
            .filter(
                PipelineRun.pipeline_id == pipeline.id,
                PipelineRun.status.in_([PipelineStatus.RUNNING, PipelineStatus.PENDING]),
            )
            .scalar()
        )
        if active_runs >= pipeline.max_concurrent_runs:
            raise ValidationError(
                f"Pipeline '{pipeline.name}' already has {active_runs} active runs "
                f"(max {pipeline.max_concurrent_runs})"
            )

        input_data = None
        if data.get("input_data"):
            input_data = json.dumps(data["input_data"], default=str)

        run = PipelineRun(
            pipeline_id=pipeline.id,
            status=PipelineStatus.PENDING,
            trigger="manual",
            correlation_id=data.get("correlation_id"),
            input_data=input_data,
        )
        self.db.add(run)
        self.db.flush()

        for step in pipeline.steps:
            step_run = PipelineStepRun(
                pipeline_run_id=run.id,
                step_index=step.step_index,
                step_name=step.name,
                status=PipelineStepStatus.PENDING,
            )
            self.db.add(step_run)

        self.db.commit()
        self.db.refresh(run)
        return run

    def get_run(self, run_id: int) -> PipelineRun:
        """Get a pipeline run by ID."""
        run = self.db.query(PipelineRun).filter(PipelineRun.id == run_id).first()
        if not run:
            raise NotFoundError("PipelineRun", run_id)
        return run

    def list_runs(
        self,
        pipeline_id: int | None = None,
        status: str | None = None,
        offset: int = 0,
        limit: int = 20,
    ) -> tuple[list[PipelineRun], int]:
        """List pipeline runs."""
        query = self.db.query(PipelineRun)
        if pipeline_id:
            query = query.filter(PipelineRun.pipeline_id == pipeline_id)
        if status:
            query = query.filter(PipelineRun.status == status)
        total = query.count()
        runs = query.order_by(PipelineRun.created_at.desc()).offset(offset).limit(limit).all()
        return runs, total

    def advance_run(self, run_id: int) -> PipelineRun:
        """Advance a pipeline run to the next step."""
        run = self.get_run(run_id)
        if run.status == PipelineStatus.PENDING:
            run.status = PipelineStatus.RUNNING
            run.started_at = utc_now()

        step_runs = sorted(run.step_runs, key=lambda sr: sr.step_index)
        current = None
        for sr in step_runs:
            if sr.status == PipelineStepStatus.PENDING:
                current = sr
                break

        if current is None:
            run.status = PipelineStatus.COMPLETED
            run.completed_at = utc_now()
            if run.started_at:
                run.duration_seconds = (run.completed_at - run.started_at).total_seconds()
        else:
            current.status = PipelineStepStatus.RUNNING
            current.started_at = utc_now()
            run.current_step = current.step_index

        self.db.commit()
        self.db.refresh(run)
        return run

    def complete_step(
        self,
        run_id: int,
        step_index: int,
        success: bool = True,
        output_data: dict | None = None,
        error_message: str | None = None,
    ) -> PipelineRun:
        """Mark a pipeline step as completed."""
        run = self.get_run(run_id)
        step_run = None
        for sr in run.step_runs:
            if sr.step_index == step_index:
                step_run = sr
                break

        if not step_run:
            raise NotFoundError("PipelineStepRun", f"run={run_id} step={step_index}")

        step_run.status = PipelineStepStatus.COMPLETED if success else PipelineStepStatus.FAILED
        step_run.completed_at = utc_now()
        if step_run.started_at:
            step_run.duration_seconds = (step_run.completed_at - step_run.started_at).total_seconds()
        step_run.error_message = error_message
        if output_data:
            step_run.output_data = json.dumps(output_data, default=str)

        if not success:
            pipeline = self.get(run.pipeline_id)
            step_def = None
            for s in pipeline.steps:
                if s.step_index == step_index:
                    step_def = s
                    break

            if step_def and not step_def.continue_on_failure and pipeline.on_failure == "stop":
                run.status = PipelineStatus.FAILED
                run.completed_at = utc_now()
                run.error_message = f"Step '{step_run.step_name}' failed: {error_message}"
                if run.started_at:
                    run.duration_seconds = (run.completed_at - run.started_at).total_seconds()
                for sr in run.step_runs:
                    if sr.status == PipelineStepStatus.PENDING:
                        sr.status = PipelineStepStatus.SKIPPED

        self.db.commit()
        self.db.refresh(run)
        return run

    def cancel_run(self, run_id: int) -> PipelineRun:
        """Cancel a pipeline run."""
        run = self.get_run(run_id)
        current = PipelineStatus(run.status)
        allowed = VALID_PIPELINE_TRANSITIONS.get(current, [])
        if PipelineStatus.CANCELLED not in allowed:
            raise InvalidStateTransitionError("PipelineRun", current.value, "cancelled")

        run.status = PipelineStatus.CANCELLED
        run.completed_at = utc_now()
        if run.started_at:
            run.duration_seconds = (run.completed_at - run.started_at).total_seconds()

        for sr in run.step_runs:
            if sr.status in (PipelineStepStatus.PENDING, PipelineStepStatus.RUNNING):
                sr.status = PipelineStepStatus.SKIPPED

        self.db.commit()
        self.db.refresh(run)
        return run

# End of pipeline service
