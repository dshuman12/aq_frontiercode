"""Service layer for analytics, reporting, and metrics."""

from __future__ import annotations

from datetime import timedelta
from typing import Any

from sqlalchemy import func, case
from sqlalchemy.orm import Session

from app.models.pipeline import Pipeline, PipelineRun
from app.models.queue import Queue
from app.models.schedule import Schedule
from app.models.task import Task
from app.models.worker import Worker
from app.utils.constants import (
    PipelineStatus,
    QueueStatus,
    ScheduleStatus,
    TaskStatus,
    WorkerStatus,
)
from app.utils.date_utils import utc_now, start_of_day


class AnalyticsService:
    """Computes dashboard metrics, trends, and breakdowns."""

    def __init__(self, db: Session):
        self.db = db

    def get_dashboard_summary(self) -> dict[str, Any]:
        """High-level dashboard metrics."""
        total_queues = self.db.query(func.count(Queue.id)).scalar() or 0
        active_queues = (
            self.db.query(func.count(Queue.id))
            .filter(Queue.status == QueueStatus.ACTIVE)
            .scalar() or 0
        )

        total_tasks = self.db.query(func.count(Task.id)).scalar() or 0
        pending_tasks = (
            self.db.query(func.count(Task.id))
            .filter(Task.status.in_([TaskStatus.PENDING, TaskStatus.QUEUED]))
            .scalar() or 0
        )
        running_tasks = (
            self.db.query(func.count(Task.id))
            .filter(Task.status == TaskStatus.RUNNING)
            .scalar() or 0
        )

        today_start = start_of_day()
        completed_today = (
            self.db.query(func.count(Task.id))
            .filter(Task.status == TaskStatus.SUCCESS, Task.completed_at >= today_start)
            .scalar() or 0
        )
        failed_today = (
            self.db.query(func.count(Task.id))
            .filter(Task.status == TaskStatus.FAILED, Task.completed_at >= today_start)
            .scalar() or 0
        )

        active_workers = (
            self.db.query(func.count(Worker.id))
            .filter(Worker.status.in_([WorkerStatus.IDLE, WorkerStatus.BUSY]))
            .scalar() or 0
        )
        total_workers = self.db.query(func.count(Worker.id)).scalar() or 0

        active_pipelines = (
            self.db.query(func.count(Pipeline.id))
            .filter(Pipeline.enabled == True)
            .scalar() or 0
        )
        active_schedules = (
            self.db.query(func.count(Schedule.id))
            .filter(Schedule.status == ScheduleStatus.ACTIVE)
            .scalar() or 0
        )

        avg_duration = (
            self.db.query(func.avg(Task.duration_seconds))
            .filter(Task.status == TaskStatus.SUCCESS)
            .scalar()
        )

        total_completed = (
            self.db.query(func.count(Task.id))
            .filter(Task.status == TaskStatus.SUCCESS)
            .scalar() or 0
        )
        total_failed = (
            self.db.query(func.count(Task.id))
            .filter(Task.status == TaskStatus.FAILED)
            .scalar() or 0
        )
        total_finished = total_completed + total_failed
        success_rate = (total_completed / total_finished * 100) if total_finished > 0 else None

        return {
            "total_queues": total_queues,
            "active_queues": active_queues,
            "total_tasks": total_tasks,
            "pending_tasks": pending_tasks,
            "running_tasks": running_tasks,
            "completed_tasks_today": completed_today,
            "failed_tasks_today": failed_today,
            "active_workers": active_workers,
            "total_workers": total_workers,
            "active_pipelines": active_pipelines,
            "active_schedules": active_schedules,
            "avg_task_duration": float(avg_duration) if avg_duration else None,
            "task_success_rate": success_rate,
        }

    def get_task_status_breakdown(self) -> list[dict[str, Any]]:
        """Count tasks grouped by status."""
        rows = (
            self.db.query(Task.status, func.count(Task.id))
            .group_by(Task.status)
            .all()
        )
        total = sum(c for _, c in rows)
        return [
            {
                "status": status,
                "count": count,
                "percentage": (count / total * 100) if total > 0 else 0,
            }
            for status, count in rows
        ]

    def get_task_trends(self, days: int = 7) -> list[dict[str, Any]]:
        """Task creation/completion trends over the last N days."""
        trends: list[dict[str, Any]] = []
        now = utc_now()
        for i in range(days - 1, -1, -1):
            day_start = start_of_day(now - timedelta(days=i))
            day_end = day_start + timedelta(days=1)

            created = (
                self.db.query(func.count(Task.id))
                .filter(Task.created_at >= day_start, Task.created_at < day_end)
                .scalar() or 0
            )
            completed = (
                self.db.query(func.count(Task.id))
                .filter(
                    Task.status == TaskStatus.SUCCESS,
                    Task.completed_at >= day_start,
                    Task.completed_at < day_end,
                )
                .scalar() or 0
            )
            failed = (
                self.db.query(func.count(Task.id))
                .filter(
                    Task.status == TaskStatus.FAILED,
                    Task.completed_at >= day_start,
                    Task.completed_at < day_end,
                )
                .scalar() or 0
            )

            trends.append({
                "period": day_start.strftime("%Y-%m-%d"),
                "period_start": day_start.isoformat(),
                "created": created,
                "completed": completed,
                "failed": failed,
            })
        return trends

    def get_error_breakdown(self, limit: int = 10) -> list[dict[str, Any]]:
        """Top error messages from failed tasks."""
        rows = (
            self.db.query(Task.error_message, func.count(Task.id))
            .filter(Task.status == TaskStatus.FAILED, Task.error_message.isnot(None))
            .group_by(Task.error_message)
            .order_by(func.count(Task.id).desc())
            .limit(limit)
            .all()
        )
        total = sum(c for _, c in rows)
        return [
            {
                "error_type": msg[:100] if msg else "unknown",
                "count": count,
                "percentage": (count / total * 100) if total > 0 else 0,
            }
            for msg, count in rows
        ]

    def get_queue_throughput(self, queue_name: str, hours: int = 24) -> dict[str, Any]:
        """Throughput metrics for a specific queue."""
        queue = self.db.query(Queue).filter(Queue.name == queue_name).first()
        if not queue:
            return {}

        cutoff = utc_now() - timedelta(hours=hours)
        completed = (
            self.db.query(func.count(Task.id))
            .filter(
                Task.queue_id == queue.id,
                Task.status == TaskStatus.SUCCESS,
                Task.completed_at >= cutoff,
            )
            .scalar() or 0
        )
        failed = (
            self.db.query(func.count(Task.id))
            .filter(
                Task.queue_id == queue.id,
                Task.status == TaskStatus.FAILED,
                Task.completed_at >= cutoff,
            )
            .scalar() or 0
        )
        avg_dur = (
            self.db.query(func.avg(Task.duration_seconds))
            .filter(
                Task.queue_id == queue.id,
                Task.status == TaskStatus.SUCCESS,
                Task.completed_at >= cutoff,
            )
            .scalar()
        )

        return {
            "queue_name": queue_name,
            "window_hours": hours,
            "tasks_completed": completed,
            "tasks_failed": failed,
            "avg_duration_seconds": float(avg_dur) if avg_dur else None,
        }

    def get_pipeline_analytics(self) -> list[dict[str, Any]]:
        """Analytics for all pipelines."""
        pipelines = self.db.query(Pipeline).all()
        results: list[dict[str, Any]] = []
        for p in pipelines:
            total_runs = (
                self.db.query(func.count(PipelineRun.id))
                .filter(PipelineRun.pipeline_id == p.id)
                .scalar() or 0
            )
            successful = (
                self.db.query(func.count(PipelineRun.id))
                .filter(PipelineRun.pipeline_id == p.id, PipelineRun.status == PipelineStatus.COMPLETED)
                .scalar() or 0
            )
            failed = (
                self.db.query(func.count(PipelineRun.id))
                .filter(PipelineRun.pipeline_id == p.id, PipelineRun.status == PipelineStatus.FAILED)
                .scalar() or 0
            )
            avg_dur = (
                self.db.query(func.avg(PipelineRun.duration_seconds))
                .filter(PipelineRun.pipeline_id == p.id, PipelineRun.status == PipelineStatus.COMPLETED)
                .scalar()
            )
            results.append({
                "pipeline_id": p.id,
                "pipeline_name": p.name,
                "total_runs": total_runs,
                "successful_runs": successful,
                "failed_runs": failed,
                "avg_duration_seconds": float(avg_dur) if avg_dur else None,
            })
        return results
