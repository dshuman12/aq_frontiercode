"""Service layer for Queue CRUD and state management."""

from __future__ import annotations

import json
from typing import Any

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.exceptions import (
    DuplicateError,
    InvalidStateTransitionError,
    NotFoundError,
    ValidationError,
)
from app.models.queue import Queue, QueueTag
from app.models.task import Task
from app.utils.constants import (
    QueueStatus,
    TaskStatus,
    VALID_QUEUE_TRANSITIONS,
)
from app.utils.date_utils import utc_now
from app.utils.validators import validate_queue_name, validate_tags


class QueueService:
    """Manages queue lifecycle, configuration, and status transitions."""

    def __init__(self, db: Session):
        self.db = db

    def create(self, data: dict[str, Any]) -> Queue:
        """Create a new queue with the given configuration."""
        name = validate_queue_name(data["name"])

        existing = self.db.query(Queue).filter(Queue.name == name).first()
        if existing:
            raise DuplicateError("Queue", "name", name)

        if data.get("dead_letter_queue_id"):
            dl = self.db.query(Queue).filter(
                Queue.id == data["dead_letter_queue_id"]
            ).first()
            if not dl:
                raise NotFoundError("Queue", data["dead_letter_queue_id"])

        queue = Queue(
            name=name,
            display_name=data.get("display_name"),
            description=data.get("description"),
            max_size=data.get("max_size", 10000),
            max_retries=data.get("max_retries", 3),
            retry_delay=data.get("retry_delay", 60),
            timeout=data.get("timeout", 3600),
            concurrency_limit=data.get("concurrency_limit", 0),
            rate_limit=data.get("rate_limit", 0),
            rate_window=data.get("rate_window", 60),
            enable_dead_letter=data.get("enable_dead_letter", True),
            dead_letter_queue_id=data.get("dead_letter_queue_id"),
            priority_enabled=data.get("priority_enabled", True),
            fifo=data.get("fifo", False),
        )
        self.db.add(queue)
        self.db.flush()

        if data.get("tags"):
            tags = validate_tags(data["tags"])
            for tag_name in tags:
                self.db.add(QueueTag(queue_id=queue.id, tag=tag_name))

        self.db.commit()
        self.db.refresh(queue)
        return queue

    def get(self, queue_id: int) -> Queue:
        """Get a queue by ID or raise NotFoundError."""
        queue = self.db.query(Queue).filter(Queue.id == queue_id).first()
        if not queue:
            raise NotFoundError("Queue", queue_id)
        return queue

    def get_by_name(self, name: str) -> Queue:
        """Get a queue by name or raise NotFoundError."""
        queue = self.db.query(Queue).filter(Queue.name == name).first()
        if not queue:
            raise NotFoundError("Queue", name)
        return queue

    def list_queues(
        self,
        status: str | None = None,
        offset: int = 0,
        limit: int = 20,
    ) -> tuple[list[Queue], int]:
        """List queues with optional status filter and pagination."""
        query = self.db.query(Queue)
        if status:
            query = query.filter(Queue.status == status)
        total = query.count()
        queues = query.order_by(Queue.name).offset(offset).limit(limit).all()
        return queues, total

    def update(self, queue_id: int, data: dict[str, Any]) -> Queue:
        """Update queue configuration."""
        queue = self.get(queue_id)

        updatable = {
            "display_name", "description", "max_size", "max_retries",
            "retry_delay", "timeout", "concurrency_limit", "rate_limit",
            "rate_window", "enable_dead_letter", "dead_letter_queue_id",
            "priority_enabled",
        }
        for key, value in data.items():
            if key in updatable and value is not None:
                setattr(queue, key, value)

        if "tags" in data and data["tags"] is not None:
            tags = validate_tags(data["tags"])
            self.db.query(QueueTag).filter(QueueTag.queue_id == queue.id).delete()
            for tag_name in tags:
                self.db.add(QueueTag(queue_id=queue.id, tag=tag_name))

        self.db.commit()
        self.db.refresh(queue)
        return queue

    def delete(self, queue_id: int) -> None:
        """Delete a queue. Fails if tasks still reference it."""
        queue = self.get(queue_id)
        active_count = (
            self.db.query(func.count(Task.id))
            .filter(Task.queue_id == queue.id)
            .filter(Task.status.in_(["pending", "queued", "running", "retrying"]))
            .scalar()
        )
        if active_count > 0:
            raise ValidationError(
                f"Cannot delete queue '{queue.name}': {active_count} active tasks remain"
            )
        self.db.delete(queue)
        self.db.commit()

    def transition_status(self, queue_id: int, new_status: str) -> Queue:
        """Transition a queue to a new status, validating the transition."""
        queue = self.get(queue_id)
        current = QueueStatus(queue.status)
        target = QueueStatus(new_status)

        allowed = VALID_QUEUE_TRANSITIONS.get(current, [])
        if target not in allowed:
            raise InvalidStateTransitionError("Queue", current.value, target.value)

        queue.status = target
        if target == QueueStatus.PAUSED:
            queue.paused_at = utc_now()
        elif target == QueueStatus.ACTIVE and queue.paused_at:
            queue.paused_at = None

        self.db.commit()
        self.db.refresh(queue)
        return queue

    def get_stats(self, queue_id: int) -> dict[str, Any]:
        """Get aggregate statistics for a queue."""
        queue = self.get(queue_id)
        status_counts = (
            self.db.query(Task.status, func.count(Task.id))
            .filter(Task.queue_id == queue.id)
            .group_by(Task.status)
            .all()
        )
        counts = {status: count for status, count in status_counts}

        avg_duration = (
            self.db.query(func.avg(Task.duration_seconds))
            .filter(Task.queue_id == queue.id, Task.status == TaskStatus.SUCCESS)
            .scalar()
        )

        return {
            "queue_id": queue.id,
            "queue_name": queue.name,
            "total_tasks": sum(counts.values()),
            "pending": counts.get(TaskStatus.PENDING, 0),
            "queued": counts.get(TaskStatus.QUEUED, 0),
            "running": counts.get(TaskStatus.RUNNING, 0),
            "completed": counts.get(TaskStatus.SUCCESS, 0),
            "failed": counts.get(TaskStatus.FAILED, 0),
            "dead_letter": counts.get(TaskStatus.DEAD_LETTER, 0),
            "avg_duration_seconds": float(avg_duration) if avg_duration else None,
        }

    def purge(
        self,
        queue_id: int,
        statuses: list[str] | None = None,
        older_than_hours: int | None = None,
        dry_run: bool = False,
    ) -> int:
        """Purge tasks from a queue matching the given criteria."""
        queue = self.get(queue_id)
        query = self.db.query(Task).filter(Task.queue_id == queue.id)

        if statuses:
            query = query.filter(Task.status.in_(statuses))
        else:
            query = query.filter(
                Task.status.in_([TaskStatus.CANCELLED, TaskStatus.DEAD_LETTER])
            )

        if older_than_hours:
            from datetime import timedelta
            cutoff = utc_now() - timedelta(hours=older_than_hours)
            query = query.filter(Task.created_at < cutoff)

        count = query.count()
        if not dry_run:
            query.delete(synchronize_session=False)
            self.db.commit()
        return count

    def get_pending_count(self, queue_id: int) -> int:
        """Count pending tasks in a queue."""
        return (
            self.db.query(func.count(Task.id))
            .filter(Task.queue_id == queue_id, Task.status == TaskStatus.PENDING)
            .scalar() or 0
        )

    def get_running_count(self, queue_id: int) -> int:
        """Count running tasks in a queue."""
        return (
            self.db.query(func.count(Task.id))
            .filter(Task.queue_id == queue_id, Task.status == TaskStatus.RUNNING)
            .scalar() or 0
        )
