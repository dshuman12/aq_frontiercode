"""Service layer for Worker registration, heartbeats, and management."""

from __future__ import annotations

import json
from typing import Any

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.exceptions import DuplicateError, NotFoundError, ValidationError
from app.models.worker import Worker, WorkerCapability
from app.utils.constants import WorkerStatus
from app.utils.date_utils import utc_now, hours_ago


class WorkerService:
    """Manages worker lifecycle — registration, heartbeats, and decommissioning."""

    def __init__(self, db: Session):
        self.db = db

    def register(self, data: dict[str, Any]) -> Worker:
        """Register a new worker or re-register an existing one."""
        existing = (
            self.db.query(Worker)
            .filter(Worker.worker_id == data["worker_id"])
            .first()
        )
        if existing:
            existing.status = WorkerStatus.IDLE
            existing.hostname = data["hostname"]
            existing.pid = data.get("pid")
            existing.concurrency = data.get("concurrency", 4)
            existing.version = data.get("version")
            existing.last_heartbeat = utc_now()
            existing.started_at = utc_now()
            existing.stopped_at = None
            existing.current_tasks = 0

            if data.get("queue_names"):
                existing.queue_names = json.dumps(data["queue_names"])

            self.db.query(WorkerCapability).filter(
                WorkerCapability.worker_id == existing.id
            ).delete()
            for cap in data.get("capabilities", []):
                self.db.add(WorkerCapability(worker_id=existing.id, capability=cap))

            self.db.commit()
            self.db.refresh(existing)
            return existing

        worker = Worker(
            worker_id=data["worker_id"],
            hostname=data["hostname"],
            pid=data.get("pid"),
            concurrency=data.get("concurrency", 4),
            version=data.get("version"),
            queue_names=json.dumps(data.get("queue_names", [])),
            metadata_json=json.dumps(data.get("metadata", {})) if data.get("metadata") else None,
        )
        self.db.add(worker)
        self.db.flush()

        for cap in data.get("capabilities", []):
            self.db.add(WorkerCapability(worker_id=worker.id, capability=cap))

        self.db.commit()
        self.db.refresh(worker)
        return worker

    def get(self, worker_id: int) -> Worker:
        """Get a worker by DB ID."""
        worker = self.db.query(Worker).filter(Worker.id == worker_id).first()
        if not worker:
            raise NotFoundError("Worker", worker_id)
        return worker

    def get_by_worker_id(self, worker_id: str) -> Worker:
        """Get a worker by its unique worker_id string."""
        worker = self.db.query(Worker).filter(Worker.worker_id == worker_id).first()
        if not worker:
            raise NotFoundError("Worker", worker_id)
        return worker

    def list_workers(
        self,
        status: str | None = None,
        offset: int = 0,
        limit: int = 20,
    ) -> tuple[list[Worker], int]:
        """List workers with optional status filter."""
        query = self.db.query(Worker)
        if status:
            query = query.filter(Worker.status == status)
        total = query.count()
        workers = query.order_by(Worker.started_at.desc()).offset(offset).limit(limit).all()
        return workers, total

    def heartbeat(self, worker_id_str: str, data: dict[str, Any]) -> Worker:
        """Process a worker heartbeat."""
        worker = self.get_by_worker_id(worker_id_str)
        worker.last_heartbeat = utc_now()
        worker.current_tasks = data.get("current_tasks", worker.current_tasks)
        worker.tasks_completed = data.get("tasks_completed", worker.tasks_completed)
        worker.tasks_failed = data.get("tasks_failed", worker.tasks_failed)

        if data.get("cpu_usage") is not None:
            worker.cpu_usage = data["cpu_usage"]
        if data.get("memory_usage") is not None:
            worker.memory_usage = data["memory_usage"]
        if data.get("disk_usage") is not None:
            worker.disk_usage = data["disk_usage"]

        if worker.current_tasks > 0:
            worker.status = WorkerStatus.BUSY
        elif worker.status == WorkerStatus.BUSY:
            worker.status = WorkerStatus.IDLE

        self.db.commit()
        self.db.refresh(worker)
        return worker

    def deregister(self, worker_id_str: str) -> Worker:
        """Mark a worker as offline."""
        worker = self.get_by_worker_id(worker_id_str)
        worker.status = WorkerStatus.OFFLINE
        worker.stopped_at = utc_now()
        worker.current_tasks = 0
        self.db.commit()
        self.db.refresh(worker)
        return worker

    def mark_stale_workers(self, stale_threshold_minutes: int = 5) -> int:
        """Mark workers as unhealthy if they haven't sent a heartbeat recently."""
        cutoff = utc_now() - __import__("datetime").timedelta(minutes=stale_threshold_minutes)
        stale = (
            self.db.query(Worker)
            .filter(
                Worker.status.in_([WorkerStatus.IDLE, WorkerStatus.BUSY]),
                Worker.last_heartbeat < cutoff,
            )
            .all()
        )
        for worker in stale:
            worker.status = WorkerStatus.UNHEALTHY
        self.db.commit()
        return len(stale)

    def get_stats(self) -> dict[str, Any]:
        """Aggregate worker statistics."""
        statuses = (
            self.db.query(Worker.status, func.count(Worker.id))
            .group_by(Worker.status)
            .all()
        )
        status_map = {s: c for s, c in statuses}

        total_concurrency = (
            self.db.query(func.sum(Worker.concurrency))
            .filter(Worker.status.in_([WorkerStatus.IDLE, WorkerStatus.BUSY]))
            .scalar() or 0
        )
        total_current = (
            self.db.query(func.sum(Worker.current_tasks))
            .filter(Worker.status == WorkerStatus.BUSY)
            .scalar() or 0
        )
        avg_cpu = (
            self.db.query(func.avg(Worker.cpu_usage))
            .filter(Worker.status.in_([WorkerStatus.IDLE, WorkerStatus.BUSY]))
            .scalar()
        )
        avg_memory = (
            self.db.query(func.avg(Worker.memory_usage))
            .filter(Worker.status.in_([WorkerStatus.IDLE, WorkerStatus.BUSY]))
            .scalar()
        )

        return {
            "total_workers": sum(status_map.values()),
            "active_workers": status_map.get(WorkerStatus.IDLE, 0) + status_map.get(WorkerStatus.BUSY, 0),
            "idle_workers": status_map.get(WorkerStatus.IDLE, 0),
            "offline_workers": status_map.get(WorkerStatus.OFFLINE, 0),
            "total_concurrency": total_concurrency,
            "total_current_tasks": total_current,
            "avg_cpu_usage": float(avg_cpu) if avg_cpu else None,
            "avg_memory_usage": float(avg_memory) if avg_memory else None,
        }

    def delete(self, worker_id: int) -> None:
        """Remove a worker record. Only allowed for offline workers."""
        worker = self.get(worker_id)
        if worker.status not in (WorkerStatus.OFFLINE, WorkerStatus.UNHEALTHY):
            raise ValidationError(
                f"Cannot delete worker in '{worker.status}' state. Deregister first."
            )
        self.db.delete(worker)
        self.db.commit()
