"""Service layer for full-text search across tasks and queues."""

from __future__ import annotations

from typing import Any

from sqlalchemy import func, or_
from sqlalchemy.orm import Session

from app.models.task import Task, TaskTag
from app.models.queue import Queue, QueueTag
from app.models.worker import Worker
from app.models.pipeline import Pipeline
from app.models.schedule import Schedule


class SearchService:
    """Provides search functionality across TaskQueue entities."""

    def __init__(self, db: Session):
        self.db = db

    def search_tasks(
        self,
        query: str,
        status: str | None = None,
        queue_name: str | None = None,
        offset: int = 0,
        limit: int = 20,
    ) -> tuple[list[Task], int]:
        """Search tasks by name, type, or correlation ID."""
        search = f"%{query}%"
        q = self.db.query(Task).filter(
            or_(
                Task.name.ilike(search),
                Task.task_type.ilike(search),
                Task.correlation_id.ilike(search),
                Task.batch_id.ilike(search),
            )
        )
        if status:
            q = q.filter(Task.status == status)
        if queue_name:
            queue = self.db.query(Queue).filter(Queue.name == queue_name).first()
            if queue:
                q = q.filter(Task.queue_id == queue.id)
        total = q.count()
        tasks = q.order_by(Task.created_at.desc()).offset(offset).limit(limit).all()
        return tasks, total

    def search_queues(self, query: str, offset: int = 0, limit: int = 20) -> tuple[list[Queue], int]:
        """Search queues by name or description."""
        search = f"%{query}%"
        q = self.db.query(Queue).filter(
            or_(
                Queue.name.ilike(search),
                Queue.display_name.ilike(search),
                Queue.description.ilike(search),
            )
        )
        total = q.count()
        queues = q.order_by(Queue.name).offset(offset).limit(limit).all()
        return queues, total

    def search_by_tag(
        self,
        tag: str,
        entity_type: str = "task",
        offset: int = 0,
        limit: int = 20,
    ) -> tuple[list[Any], int]:
        """Search for entities by tag."""
        tag = tag.lower().strip()
        if entity_type == "task":
            q = (
                self.db.query(Task)
                .join(TaskTag, TaskTag.task_id == Task.id)
                .filter(TaskTag.tag == tag)
            )
        elif entity_type == "queue":
            q = (
                self.db.query(Queue)
                .join(QueueTag, QueueTag.queue_id == Queue.id)
                .filter(QueueTag.tag == tag)
            )
        else:
            return [], 0
        total = q.count()
        items = q.offset(offset).limit(limit).all()
        return items, total

    def global_search(
        self,
        query: str,
        offset: int = 0,
        limit: int = 10,
    ) -> dict[str, Any]:
        """Search across all entity types."""
        results: dict[str, Any] = {}
        search = f"%{query}%"

        tasks = (
            self.db.query(Task)
            .filter(or_(Task.name.ilike(search), Task.task_type.ilike(search)))
            .order_by(Task.created_at.desc())
            .limit(limit)
            .all()
        )
        results["tasks"] = [{"id": t.id, "name": t.name, "status": t.status} for t in tasks]

        queues = (
            self.db.query(Queue)
            .filter(or_(Queue.name.ilike(search), Queue.display_name.ilike(search)))
            .limit(limit)
            .all()
        )
        results["queues"] = [{"id": q.id, "name": q.name, "status": q.status} for q in queues]

        workers = (
            self.db.query(Worker)
            .filter(or_(Worker.worker_id.ilike(search), Worker.hostname.ilike(search)))
            .limit(limit)
            .all()
        )
        results["workers"] = [{"id": w.id, "worker_id": w.worker_id, "status": w.status} for w in workers]

        pipelines = (
            self.db.query(Pipeline)
            .filter(Pipeline.name.ilike(search))
            .limit(limit)
            .all()
        )
        results["pipelines"] = [{"id": p.id, "name": p.name} for p in pipelines]

        schedules = (
            self.db.query(Schedule)
            .filter(Schedule.name.ilike(search))
            .limit(limit)
            .all()
        )
        results["schedules"] = [{"id": s.id, "name": s.name, "status": s.status} for s in schedules]

        return results
