"""Service layer for Schedule CRUD and execution."""

from __future__ import annotations

import json
from typing import Any

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.exceptions import DuplicateError, NotFoundError, ValidationError
from app.models.schedule import Schedule, ScheduleRun
from app.utils.constants import ScheduleStatus
from app.utils.date_utils import utc_now
from app.utils.validators import validate_cron_expression


class ScheduleService:
    """Manages cron-based recurring task schedules."""

    def __init__(self, db: Session):
        self.db = db

    def create(self, data: dict[str, Any]) -> Schedule:
        """Create a new schedule."""
        existing = self.db.query(Schedule).filter(Schedule.name == data["name"]).first()
        if existing:
            raise DuplicateError("Schedule", "name", data["name"])

        cron_expr = validate_cron_expression(data["cron_expression"])

        metadata_json = None
        if data.get("metadata"):
            metadata_json = json.dumps(data["metadata"], default=str)

        task_payload = None
        if data.get("task_payload"):
            task_payload = json.dumps(data["task_payload"], default=str)

        schedule = Schedule(
            name=data["name"],
            description=data.get("description"),
            cron_expression=cron_expr,
            timezone=data.get("timezone", "UTC"),
            task_name=data["task_name"],
            task_type=data["task_type"],
            queue_name=data["queue_name"],
            task_payload=task_payload,
            task_priority=data.get("task_priority", 5),
            task_timeout=data.get("task_timeout", 3600),
            task_max_retries=data.get("task_max_retries", 3),
            max_instances=data.get("max_instances", 1),
            coalesce=data.get("coalesce", True),
            jitter_seconds=data.get("jitter_seconds", 0),
            starts_at=data.get("starts_at"),
            expires_at=data.get("expires_at"),
            metadata_json=metadata_json,
        )
        self.db.add(schedule)
        self.db.commit()
        self.db.refresh(schedule)
        return schedule

    def get(self, schedule_id: int) -> Schedule:
        """Get a schedule by ID."""
        schedule = self.db.query(Schedule).filter(Schedule.id == schedule_id).first()
        if not schedule:
            raise NotFoundError("Schedule", schedule_id)
        return schedule

    def get_by_name(self, name: str) -> Schedule:
        """Get a schedule by name."""
        schedule = self.db.query(Schedule).filter(Schedule.name == name).first()
        if not schedule:
            raise NotFoundError("Schedule", name)
        return schedule

    def list_schedules(
        self,
        status: str | None = None,
        offset: int = 0,
        limit: int = 20,
    ) -> tuple[list[Schedule], int]:
        """List schedules with optional filtering."""
        query = self.db.query(Schedule)
        if status:
            query = query.filter(Schedule.status == status)
        total = query.count()
        schedules = query.order_by(Schedule.name).offset(offset).limit(limit).all()
        return schedules, total

    def update(self, schedule_id: int, data: dict[str, Any]) -> Schedule:
        """Update a schedule."""
        schedule = self.get(schedule_id)

        if data.get("cron_expression"):
            data["cron_expression"] = validate_cron_expression(data["cron_expression"])

        updatable = {
            "description", "cron_expression", "timezone", "task_name",
            "task_type", "queue_name", "task_priority", "task_timeout",
            "task_max_retries", "max_instances", "coalesce", "jitter_seconds",
            "starts_at", "expires_at",
        }
        for key, value in data.items():
            if key in updatable and value is not None:
                setattr(schedule, key, value)

        if "task_payload" in data:
            if data["task_payload"] is not None:
                schedule.task_payload = json.dumps(data["task_payload"], default=str)
            else:
                schedule.task_payload = None

        if "metadata" in data:
            if data["metadata"] is not None:
                schedule.metadata_json = json.dumps(data["metadata"], default=str)
            else:
                schedule.metadata_json = None

        self.db.commit()
        self.db.refresh(schedule)
        return schedule

    def delete(self, schedule_id: int) -> None:
        """Delete a schedule."""
        schedule = self.get(schedule_id)
        self.db.delete(schedule)
        self.db.commit()

    def enable(self, schedule_id: int) -> Schedule:
        """Enable a schedule."""
        schedule = self.get(schedule_id)
        schedule.enabled = True
        schedule.status = ScheduleStatus.ACTIVE
        self.db.commit()
        self.db.refresh(schedule)
        return schedule

    def disable(self, schedule_id: int) -> Schedule:
        """Disable a schedule."""
        schedule = self.get(schedule_id)
        schedule.enabled = False
        schedule.status = ScheduleStatus.DISABLED
        self.db.commit()
        self.db.refresh(schedule)
        return schedule

    def pause(self, schedule_id: int) -> Schedule:
        """Pause a schedule."""
        schedule = self.get(schedule_id)
        schedule.status = ScheduleStatus.PAUSED
        self.db.commit()
        self.db.refresh(schedule)
        return schedule

    def record_run(
        self,
        schedule_id: int,
        scheduled_for: Any,
        task_id: int | None = None,
        status: str = "triggered",
        error_message: str | None = None,
    ) -> ScheduleRun:
        """Record a schedule trigger event."""
        schedule = self.get(schedule_id)
        schedule.last_run_at = utc_now()
        schedule.run_count += 1
        if status == "failed":
            schedule.failure_count += 1

        run = ScheduleRun(
            schedule_id=schedule_id,
            task_id=task_id,
            scheduled_for=scheduled_for,
            status=status,
            error_message=error_message,
        )
        self.db.add(run)
        self.db.commit()
        self.db.refresh(run)
        return run

    def get_runs(
        self,
        schedule_id: int,
        offset: int = 0,
        limit: int = 20,
    ) -> tuple[list[ScheduleRun], int]:
        """Get run history for a schedule."""
        self.get(schedule_id)
        query = self.db.query(ScheduleRun).filter(ScheduleRun.schedule_id == schedule_id)
        total = query.count()
        runs = query.order_by(ScheduleRun.triggered_at.desc()).offset(offset).limit(limit).all()
        return runs, total

    def get_due_schedules(self) -> list[Schedule]:
        """Find schedules that are due to trigger."""
        now = utc_now()
        return (
            self.db.query(Schedule)
            .filter(
                Schedule.enabled == True,
                Schedule.status == ScheduleStatus.ACTIVE,
                Schedule.next_run_at <= now,
            )
            .all()
        )
