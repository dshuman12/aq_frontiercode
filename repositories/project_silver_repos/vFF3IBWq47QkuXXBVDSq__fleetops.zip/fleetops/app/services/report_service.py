"""Report generation."""
from __future__ import annotations
from typing import Any
from sqlalchemy import func
from sqlalchemy.orm import Session
from app.models.vehicle import Vehicle

class ReportService:
    def __init__(self, db: Session):
        self.db = db
    def fleet_summary(self) -> dict[str, Any]:
        total = self.db.query(func.count(Vehicle.id)).scalar() or 0
        by_type = {t: c for t, c in self.db.query(Vehicle.vehicle_type, func.count(Vehicle.id)).group_by(Vehicle.vehicle_type).all()}
        return {"total_vehicles": total, "by_type": by_type}
