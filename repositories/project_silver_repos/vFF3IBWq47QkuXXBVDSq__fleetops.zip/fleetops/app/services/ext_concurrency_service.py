"""Service for managing task concurrency limits and slot allocation."""

from __future__ import annotations

from typing import Any

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.exceptions import ConcurrencyLimitError
from app.models.queue import Queue
from app.models.task import Task
from app.models.worker import Worker
from app.utils.constants import TaskStatus, WorkerStatus


class ConcurrencyService:
    """Manages concurrency limits for queues and workers.

    Ensures that the number of concurrently running tasks does not exceed
    configured limits at the queue, worker, or global level.
    """

    def __init__(self, db: Session):
        self.db = db
        self._global_limit: int = 0  # 0 = unlimited

    def set_global_limit(self, limit: int) -> None:
        """Set a global concurrency limit across all queues."""
        self._global_limit = max(0, limit)

    def get_global_limit(self) -> int:
        """Get the current global concurrency limit."""
        return self._global_limit

    def check_queue_limit(self, queue_id: int) -> dict[str, Any]:
        """Check if a queue has room for another concurrent task."""
        queue = self.db.query(Queue).filter(Queue.id == queue_id).first()
        if not queue:
            return {"allowed": False, "reason": "Queue not found"}

        if queue.concurrency_limit == 0:
            return {"allowed": True, "current": 0, "limit": 0, "reason": "No limit set"}

        running = (
            self.db.query(func.count(Task.id))
            .filter(Task.queue_id == queue_id, Task.status == TaskStatus.RUNNING)
            .scalar() or 0
        )

        allowed = running < queue.concurrency_limit
        return {
            "allowed": allowed,
            "current": running,
            "limit": queue.concurrency_limit,
            "remaining": max(0, queue.concurrency_limit - running),
            "reason": None if allowed else "Concurrency limit reached",
        }

    def check_worker_limit(self, worker_id: int) -> dict[str, Any]:
        """Check if a worker has capacity for another task."""
        worker = self.db.query(Worker).filter(Worker.id == worker_id).first()
        if not worker:
            return {"allowed": False, "reason": "Worker not found"}

        allowed = worker.current_tasks < worker.concurrency
        return {
            "allowed": allowed,
            "current": worker.current_tasks,
            "limit": worker.concurrency,
            "remaining": max(0, worker.concurrency - worker.current_tasks),
            "reason": None if allowed else "Worker at capacity",
        }

    def check_global_limit(self) -> dict[str, Any]:
        """Check the global concurrency limit."""
        if self._global_limit == 0:
            return {"allowed": True, "current": 0, "limit": 0, "reason": "No global limit"}

        running = (
            self.db.query(func.count(Task.id))
            .filter(Task.status == TaskStatus.RUNNING)
            .scalar() or 0
        )

        allowed = running < self._global_limit
        return {
            "allowed": allowed,
            "current": running,
            "limit": self._global_limit,
            "remaining": max(0, self._global_limit - running),
            "reason": None if allowed else "Global concurrency limit reached",
        }

    def acquire_slot(self, queue_id: int, worker_id: int) -> dict[str, Any]:
        """Attempt to acquire a concurrency slot for task execution.

        Checks queue, worker, and global limits in sequence.
        Returns a dict with 'acquired' bool and details.
        """
        checks: list[dict[str, Any]] = []

        queue_check = self.check_queue_limit(queue_id)
        checks.append({"level": "queue", **queue_check})
        if not queue_check["allowed"]:
            return {"acquired": False, "checks": checks}

        worker_check = self.check_worker_limit(worker_id)
        checks.append({"level": "worker", **worker_check})
        if not worker_check["allowed"]:
            return {"acquired": False, "checks": checks}

        global_check = self.check_global_limit()
        checks.append({"level": "global", **global_check})
        if not global_check["allowed"]:
            return {"acquired": False, "checks": checks}

        return {"acquired": True, "checks": checks}

    def get_utilization(self) -> dict[str, Any]:
        """Get overall system utilization metrics."""
        total_running = (
            self.db.query(func.count(Task.id))
            .filter(Task.status == TaskStatus.RUNNING)
            .scalar() or 0
        )
        total_capacity = (
            self.db.query(func.sum(Worker.concurrency))
            .filter(Worker.status.in_([WorkerStatus.IDLE, WorkerStatus.BUSY]))
            .scalar() or 0
        )

        queues = self.db.query(Queue).filter(Queue.concurrency_limit > 0).all()
        queue_utilization: list[dict[str, Any]] = []
        for q in queues:
            running = (
                self.db.query(func.count(Task.id))
                .filter(Task.queue_id == q.id, Task.status == TaskStatus.RUNNING)
                .scalar() or 0
            )
            queue_utilization.append({
                "queue_name": q.name,
                "running": running,
                "limit": q.concurrency_limit,
                "utilization_pct": (running / q.concurrency_limit * 100) if q.concurrency_limit > 0 else 0,
            })

        return {
            "total_running": total_running,
            "total_capacity": total_capacity,
            "system_utilization_pct": (
                (total_running / total_capacity * 100)
                if total_capacity > 0
                else 0
            ),
            "global_limit": self._global_limit,
            "queue_utilization": queue_utilization,
        }
