"""Service layer for generating reports and exports."""

from __future__ import annotations

from datetime import timedelta
from typing import Any

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.models.task import Task
from app.models.queue import Queue
from app.models.worker import Worker
from app.models.pipeline import Pipeline, PipelineRun
from app.utils.constants import TaskStatus, PipelineStatus
from app.utils.date_utils import utc_now, start_of_day
from app.utils.csv_utils import tasks_to_csv, queues_to_csv, workers_to_csv


class ReportService:
    """Generates summary reports and data exports."""

    def __init__(self, db: Session):
        self.db = db

    def daily_summary(self, date: Any | None = None) -> dict[str, Any]:
        """Generate a daily summary report."""
        if date is None:
            day_start = start_of_day()
        else:
            day_start = start_of_day(date)
        day_end = day_start + timedelta(days=1)

        created = (
            self.db.query(func.count(Task.id))
            .filter(Task.created_at >= day_start, Task.created_at < day_end)
            .scalar() or 0
        )
        completed = (
            self.db.query(func.count(Task.id))
            .filter(
                Task.status == TaskStatus.SUCCESS,
                Task.completed_at >= day_start,
                Task.completed_at < day_end,
            )
            .scalar() or 0
        )
        failed = (
            self.db.query(func.count(Task.id))
            .filter(
                Task.status == TaskStatus.FAILED,
                Task.completed_at >= day_start,
                Task.completed_at < day_end,
            )
            .scalar() or 0
        )
        avg_duration = (
            self.db.query(func.avg(Task.duration_seconds))
            .filter(
                Task.status == TaskStatus.SUCCESS,
                Task.completed_at >= day_start,
                Task.completed_at < day_end,
            )
            .scalar()
        )

        return {
            "date": day_start.strftime("%Y-%m-%d"),
            "tasks_created": created,
            "tasks_completed": completed,
            "tasks_failed": failed,
            "success_rate": (completed / (completed + failed) * 100) if (completed + failed) > 0 else 0,
            "avg_duration_seconds": float(avg_duration) if avg_duration else None,
        }

    def queue_report(self) -> list[dict[str, Any]]:
        """Generate a report for all queues."""
        queues = self.db.query(Queue).order_by(Queue.name).all()
        report: list[dict[str, Any]] = []
        for q in queues:
            total = self.db.query(func.count(Task.id)).filter(Task.queue_id == q.id).scalar() or 0
            pending = (
                self.db.query(func.count(Task.id))
                .filter(Task.queue_id == q.id, Task.status.in_([TaskStatus.PENDING, TaskStatus.QUEUED]))
                .scalar() or 0
            )
            running = (
                self.db.query(func.count(Task.id))
                .filter(Task.queue_id == q.id, Task.status == TaskStatus.RUNNING)
                .scalar() or 0
            )
            report.append({
                "id": q.id,
                "name": q.name,
                "status": q.status,
                "total_tasks": total,
                "pending_count": pending,
                "running_count": running,
                "max_size": q.max_size,
                "max_retries": q.max_retries,
            })
        return report

    def worker_report(self) -> list[dict[str, Any]]:
        """Generate a report for all workers."""
        workers = self.db.query(Worker).order_by(Worker.started_at.desc()).all()
        report: list[dict[str, Any]] = []
        for w in workers:
            report.append({
                "id": w.id,
                "worker_id": w.worker_id,
                "hostname": w.hostname,
                "status": w.status,
                "tasks_completed": w.tasks_completed,
                "tasks_failed": w.tasks_failed,
                "cpu_usage": w.cpu_usage,
                "memory_usage": w.memory_usage,
            })
        return report

    def export_tasks_csv(
        self,
        status: str | None = None,
        queue_name: str | None = None,
        limit: int = 1000,
    ) -> str:
        """Export tasks as CSV."""
        query = self.db.query(Task)
        if status:
            query = query.filter(Task.status == status)
        if queue_name:
            queue = self.db.query(Queue).filter(Queue.name == queue_name).first()
            if queue:
                query = query.filter(Task.queue_id == queue.id)
        tasks = query.order_by(Task.created_at.desc()).limit(limit).all()
        task_dicts = []
        for t in tasks:
            queue = self.db.query(Queue).filter(Queue.id == t.queue_id).first()
            task_dicts.append({
                "id": t.id,
                "name": t.name,
                "status": t.status,
                "priority": t.priority,
                "queue_name": queue.name if queue else "",
                "created_at": t.created_at,
                "started_at": t.started_at,
                "completed_at": t.completed_at,
                "duration_seconds": t.duration_seconds,
                "retry_count": t.retry_count,
                "error_message": t.error_message,
            })
        return tasks_to_csv(task_dicts)

    def export_queues_csv(self) -> str:
        """Export queues as CSV."""
        queues = self.db.query(Queue).order_by(Queue.name).all()
        q_dicts = []
        for q in queues:
            pending = (
                self.db.query(func.count(Task.id))
                .filter(Task.queue_id == q.id, Task.status.in_([TaskStatus.PENDING, TaskStatus.QUEUED]))
                .scalar() or 0
            )
            running = (
                self.db.query(func.count(Task.id))
                .filter(Task.queue_id == q.id, Task.status == TaskStatus.RUNNING)
                .scalar() or 0
            )
            q_dicts.append({
                "id": q.id,
                "name": q.name,
                "status": q.status,
                "max_size": q.max_size,
                "max_retries": q.max_retries,
                "retry_delay": q.retry_delay,
                "timeout": q.timeout,
                "concurrency_limit": q.concurrency_limit,
                "pending_count": pending,
                "running_count": running,
            })
        return queues_to_csv(q_dicts)
