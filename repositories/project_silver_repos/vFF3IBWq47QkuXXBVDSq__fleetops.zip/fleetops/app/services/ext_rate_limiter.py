"""In-memory rate limiter with sliding window."""

from __future__ import annotations

import time
from collections import defaultdict
from threading import Lock
from typing import Any


class RateLimiter:
    """Token-bucket rate limiter with per-key tracking."""

    def __init__(self, default_limit: int = 100, default_window: int = 60):
        self.default_limit = default_limit
        self.default_window = default_window
        self._buckets: dict[str, list[float]] = defaultdict(list)
        self._lock = Lock()

    def is_allowed(
        self,
        key: str,
        limit: int | None = None,
        window: int | None = None,
    ) -> tuple[bool, dict[str, Any]]:
        """Check if a request is allowed under the rate limit.

        Returns (allowed, info) where info has remaining count and reset time.
        """
        limit = limit or self.default_limit
        window = window or self.default_window
        now = time.monotonic()
        cutoff = now - window

        with self._lock:
            timestamps = self._buckets[key]
            timestamps[:] = [ts for ts in timestamps if ts > cutoff]

            remaining = max(0, limit - len(timestamps))
            if len(timestamps) >= limit:
                oldest = min(timestamps) if timestamps else now
                retry_after = int(oldest + window - now) + 1
                return False, {
                    "limit": limit,
                    "remaining": 0,
                    "retry_after": retry_after,
                    "window": window,
                }

            timestamps.append(now)
            return True, {
                "limit": limit,
                "remaining": remaining - 1,
                "retry_after": 0,
                "window": window,
            }

    def get_usage(self, key: str, window: int | None = None) -> dict[str, Any]:
        """Get current usage stats for a key."""
        window = window or self.default_window
        now = time.monotonic()
        cutoff = now - window

        with self._lock:
            timestamps = self._buckets.get(key, [])
            active = [ts for ts in timestamps if ts > cutoff]
            return {
                "key": key,
                "count": len(active),
                "window": window,
            }

    def reset(self, key: str) -> None:
        """Reset the rate limit for a specific key."""
        with self._lock:
            self._buckets.pop(key, None)

    def reset_all(self) -> None:
        """Reset all rate limits."""
        with self._lock:
            self._buckets.clear()

    def get_all_keys(self) -> list[str]:
        """List all tracked keys."""
        with self._lock:
            return list(self._buckets.keys())
