"""Service layer for Webhook management and delivery."""

from __future__ import annotations

import json
import time
from typing import Any

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.exceptions import DuplicateError, NotFoundError, WebhookDeliveryError
from app.models.webhook import Webhook, WebhookDelivery
from app.utils.date_utils import utc_now
from app.utils.helpers import generate_webhook_secret
from app.utils.security import sign_webhook_payload
from app.utils.validators import validate_webhook_url


class WebhookService:
    """Manages webhook registrations and simulates delivery."""

    def __init__(self, db: Session):
        self.db = db

    def create(self, data: dict[str, Any]) -> Webhook:
        """Register a new webhook."""
        url = validate_webhook_url(data["url"])
        secret = generate_webhook_secret()
        events_json = json.dumps(data["events"])

        webhook = Webhook(
            name=data["name"],
            url=url,
            secret=secret,
            events=events_json,
            queue_filter=data.get("queue_filter"),
            max_retries=data.get("max_retries", 3),
            timeout=data.get("timeout", 30),
            retry_delay=data.get("retry_delay", 60),
        )
        self.db.add(webhook)
        self.db.commit()
        self.db.refresh(webhook)
        return webhook

    def get(self, webhook_id: int) -> Webhook:
        """Get a webhook by ID."""
        webhook = self.db.query(Webhook).filter(Webhook.id == webhook_id).first()
        if not webhook:
            raise NotFoundError("Webhook", webhook_id)
        return webhook

    def list_webhooks(
        self, offset: int = 0, limit: int = 20
    ) -> tuple[list[Webhook], int]:
        """List all webhooks."""
        query = self.db.query(Webhook)
        total = query.count()
        webhooks = query.order_by(Webhook.created_at.desc()).offset(offset).limit(limit).all()
        return webhooks, total

    def update(self, webhook_id: int, data: dict[str, Any]) -> Webhook:
        """Update webhook configuration."""
        webhook = self.get(webhook_id)

        if data.get("name"):
            webhook.name = data["name"]
        if data.get("url"):
            webhook.url = validate_webhook_url(data["url"])
        if data.get("events"):
            webhook.events = json.dumps(data["events"])
        if data.get("enabled") is not None:
            webhook.enabled = data["enabled"]
        if data.get("queue_filter") is not None:
            webhook.queue_filter = data["queue_filter"]
        if data.get("max_retries") is not None:
            webhook.max_retries = data["max_retries"]
        if data.get("timeout") is not None:
            webhook.timeout = data["timeout"]
        if data.get("retry_delay") is not None:
            webhook.retry_delay = data["retry_delay"]

        self.db.commit()
        self.db.refresh(webhook)
        return webhook

    def delete(self, webhook_id: int) -> None:
        """Delete a webhook and its delivery history."""
        webhook = self.get(webhook_id)
        self.db.delete(webhook)
        self.db.commit()

    def enable(self, webhook_id: int) -> Webhook:
        """Enable a webhook."""
        webhook = self.get(webhook_id)
        webhook.enabled = True
        webhook.consecutive_failures = 0
        self.db.commit()
        self.db.refresh(webhook)
        return webhook

    def disable(self, webhook_id: int) -> Webhook:
        """Disable a webhook."""
        webhook = self.get(webhook_id)
        webhook.enabled = False
        self.db.commit()
        self.db.refresh(webhook)
        return webhook

    def record_delivery(
        self,
        webhook_id: int,
        event: str,
        request_body: str | None = None,
        response_status: int | None = None,
        response_body: str | None = None,
        success: bool = True,
        attempt: int = 1,
        duration_ms: float | None = None,
        error_message: str | None = None,
    ) -> WebhookDelivery:
        """Record a webhook delivery attempt."""
        webhook = self.get(webhook_id)

        delivery = WebhookDelivery(
            webhook_id=webhook_id,
            event=event,
            request_body=request_body,
            response_status=response_status,
            response_body=response_body,
            success=success,
            attempt=attempt,
            duration_ms=duration_ms,
            error_message=error_message,
        )
        self.db.add(delivery)

        webhook.last_delivery_at = utc_now()
        webhook.last_status_code = response_status
        if success:
            webhook.consecutive_failures = 0
        else:
            webhook.consecutive_failures += 1

        self.db.commit()
        self.db.refresh(delivery)
        return delivery

    def get_deliveries(
        self,
        webhook_id: int,
        offset: int = 0,
        limit: int = 20,
    ) -> tuple[list[WebhookDelivery], int]:
        """Get delivery history for a webhook."""
        self.get(webhook_id)
        query = self.db.query(WebhookDelivery).filter(
            WebhookDelivery.webhook_id == webhook_id
        )
        total = query.count()
        deliveries = (
            query.order_by(WebhookDelivery.delivered_at.desc())
            .offset(offset)
            .limit(limit)
            .all()
        )
        return deliveries, total

    def get_matching_webhooks(self, event: str, queue_name: str | None = None) -> list[Webhook]:
        """Find webhooks that subscribe to a given event."""
        webhooks = (
            self.db.query(Webhook)
            .filter(Webhook.enabled == True)
            .all()
        )
        matching: list[Webhook] = []
        for wh in webhooks:
            events = json.loads(wh.events) if wh.events else []
            if event not in events:
                continue
            if wh.queue_filter and queue_name and wh.queue_filter != queue_name:
                continue
            matching.append(wh)
        return matching

    def fire_event(self, event: str, payload: dict[str, Any], queue_name: str | None = None) -> int:
        """Fire a webhook event to all matching subscribers (simulation)."""
        webhooks = self.get_matching_webhooks(event, queue_name)
        delivered = 0
        payload_json = json.dumps(payload, default=str)
        for wh in webhooks:
            signature = sign_webhook_payload(payload_json.encode(), wh.secret)
            self.record_delivery(
                webhook_id=wh.id,
                event=event,
                request_body=payload_json,
                response_status=200,
                success=True,
                duration_ms=15.0,
            )
            delivered += 1
        return delivered

    def rotate_secret(self, webhook_id: int) -> Webhook:
        """Generate a new signing secret for a webhook."""
        webhook = self.get(webhook_id)
        webhook.secret = generate_webhook_secret()
        self.db.commit()
        self.db.refresh(webhook)
        return webhook
