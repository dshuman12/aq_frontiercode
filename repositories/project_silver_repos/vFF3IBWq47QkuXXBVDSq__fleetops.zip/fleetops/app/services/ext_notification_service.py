"""Service layer for notification dispatch (email, Slack, webhook)."""

from __future__ import annotations

from typing import Any

from sqlalchemy.orm import Session

from app.utils.date_utils import utc_now


class NotificationChannel:
    """Base class for notification channels."""

    def send(self, recipient: str, subject: str, body: str) -> bool:
        raise NotImplementedError


class EmailChannel(NotificationChannel):
    """Email notification channel (simulated)."""

    def __init__(self, smtp_host: str = "localhost", smtp_port: int = 587):
        self.smtp_host = smtp_host
        self.smtp_port = smtp_port
        self.sent: list[dict[str, Any]] = []

    def send(self, recipient: str, subject: str, body: str) -> bool:
        self.sent.append({
            "to": recipient,
            "subject": subject,
            "body": body,
            "sent_at": utc_now().isoformat(),
        })
        return True


class SlackChannel(NotificationChannel):
    """Slack notification channel (simulated)."""

    def __init__(self, webhook_url: str = ""):
        self.webhook_url = webhook_url
        self.sent: list[dict[str, Any]] = []

    def send(self, recipient: str, subject: str, body: str) -> bool:
        self.sent.append({
            "channel": recipient,
            "text": f"*{subject}*\n{body}",
            "sent_at": utc_now().isoformat(),
        })
        return True


class NotificationService:
    """Dispatches notifications through configured channels."""

    def __init__(self, db: Session):
        self.db = db
        self._channels: dict[str, NotificationChannel] = {
            "email": EmailChannel(),
            "slack": SlackChannel(),
        }
        self._sent_log: list[dict[str, Any]] = []

    def register_channel(self, name: str, channel: NotificationChannel) -> None:
        """Register a custom notification channel."""
        self._channels[name] = channel

    def send(
        self,
        channel: str,
        recipient: str,
        subject: str,
        body: str,
    ) -> bool:
        """Send a notification via the specified channel."""
        ch = self._channels.get(channel)
        if not ch:
            return False
        success = ch.send(recipient, subject, body)
        self._sent_log.append({
            "channel": channel,
            "recipient": recipient,
            "subject": subject,
            "success": success,
            "sent_at": utc_now().isoformat(),
        })
        return success

    def notify_task_failure(
        self,
        task_id: int,
        task_name: str,
        error: str,
        recipients: list[tuple[str, str]] | None = None,
    ) -> int:
        """Send failure notifications to all configured recipients."""
        if not recipients:
            recipients = [("email", "admin@fleetops.local")]
        sent = 0
        subject = f"Task Failed: {task_name} (#{task_id})"
        body = f"Task #{task_id} ({task_name}) failed with error:\n{error}"
        for channel, recipient in recipients:
            if self.send(channel, recipient, subject, body):
                sent += 1
        return sent

    def notify_pipeline_completion(
        self,
        pipeline_name: str,
        run_id: int,
        status: str,
        recipients: list[tuple[str, str]] | None = None,
    ) -> int:
        """Send pipeline completion notifications."""
        if not recipients:
            recipients = [("email", "admin@fleetops.local")]
        sent = 0
        subject = f"Pipeline {status.title()}: {pipeline_name} (run #{run_id})"
        body = f"Pipeline '{pipeline_name}' run #{run_id} finished with status: {status}"
        for channel, recipient in recipients:
            if self.send(channel, recipient, subject, body):
                sent += 1
        return sent

    def get_sent_log(self) -> list[dict[str, Any]]:
        """Get the log of sent notifications."""
        return self._sent_log.copy()
