"""Service for scheduling and executing timed task operations."""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import Any

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.models.task import Task
from app.models.queue import Queue
from app.utils.constants import TaskStatus
from app.utils.date_utils import utc_now


class TaskScheduler:
    """Handles deferred task execution, timeout checks, and retry scheduling."""

    def __init__(self, db: Session):
        self.db = db

    def promote_scheduled_tasks(self) -> int:
        """Move tasks whose scheduled_at has passed from PENDING to QUEUED."""
        now = utc_now()
        tasks = (
            self.db.query(Task)
            .filter(
                Task.status == TaskStatus.PENDING,
                Task.scheduled_at.isnot(None),
                Task.scheduled_at <= now,
            )
            .all()
        )
        promoted = 0
        for task in tasks:
            task.status = TaskStatus.QUEUED
            promoted += 1
        self.db.commit()
        return promoted

    def promote_pending_to_queued(self, queue_name: str | None = None) -> int:
        """Move non-scheduled PENDING tasks to QUEUED."""
        query = self.db.query(Task).filter(
            Task.status == TaskStatus.PENDING,
            Task.scheduled_at.is_(None),
        )
        if queue_name:
            queue = self.db.query(Queue).filter(Queue.name == queue_name).first()
            if queue:
                query = query.filter(Task.queue_id == queue.id)
        tasks = query.all()
        for task in tasks:
            task.status = TaskStatus.QUEUED
        self.db.commit()
        return len(tasks)

    def check_timeouts(self) -> int:
        """Find running tasks that have exceeded their timeout and mark them."""
        now = utc_now()
        running = (
            self.db.query(Task)
            .filter(Task.status == TaskStatus.RUNNING, Task.started_at.isnot(None))
            .all()
        )
        timed_out = 0
        for task in running:
            elapsed = (now - task.started_at).total_seconds()
            if elapsed > task.timeout:
                task.status = TaskStatus.TIMED_OUT
                task.completed_at = now
                task.duration_seconds = elapsed
                task.error_message = f"Task exceeded timeout of {task.timeout}s (ran for {elapsed:.0f}s)"
                timed_out += 1
        self.db.commit()
        return timed_out

    def process_retries(self) -> int:
        """Move RETRYING tasks whose next_retry_at has passed back to QUEUED."""
        now = utc_now()
        retrying = (
            self.db.query(Task)
            .filter(
                Task.status == TaskStatus.RETRYING,
                Task.next_retry_at.isnot(None),
                Task.next_retry_at <= now,
            )
            .all()
        )
        processed = 0
        for task in retrying:
            task.status = TaskStatus.QUEUED
            task.next_retry_at = None
            task.started_at = None
            task.completed_at = None
            processed += 1
        self.db.commit()
        return processed

    def check_deadlines(self) -> int:
        """Cancel tasks whose deadline has passed before completion."""
        now = utc_now()
        overdue = (
            self.db.query(Task)
            .filter(
                Task.deadline.isnot(None),
                Task.deadline < now,
                Task.status.in_([TaskStatus.PENDING, TaskStatus.QUEUED]),
            )
            .all()
        )
        cancelled = 0
        for task in overdue:
            task.status = TaskStatus.CANCELLED
            task.completed_at = now
            task.error_message = "Cancelled: deadline exceeded"
            cancelled += 1
        self.db.commit()
        return cancelled

    def cleanup_stale_tasks(self, hours: int = 24) -> int:
        """Move stuck RUNNING tasks (no heartbeat) to FAILED."""
        cutoff = utc_now() - timedelta(hours=hours)
        stuck = (
            self.db.query(Task)
            .filter(
                Task.status == TaskStatus.RUNNING,
                Task.started_at < cutoff,
            )
            .all()
        )
        cleaned = 0
        for task in stuck:
            task.status = TaskStatus.FAILED
            task.completed_at = utc_now()
            task.error_message = "Task appears stuck — no progress for extended period"
            cleaned += 1
        self.db.commit()
        return cleaned

    def run_maintenance_cycle(self) -> dict[str, int]:
        """Run all scheduler maintenance tasks in sequence."""
        return {
            "promoted_scheduled": self.promote_scheduled_tasks(),
            "timeouts_detected": self.check_timeouts(),
            "retries_processed": self.process_retries(),
            "deadlines_cancelled": self.check_deadlines(),
            "stale_cleaned": self.cleanup_stale_tasks(),
        }
