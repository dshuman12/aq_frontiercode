"""Service layer for audit logging."""

from __future__ import annotations

import json
from typing import Any

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.models.audit import AuditLog
from app.utils.date_utils import utc_now


class AuditService:
    """Records and queries audit trail entries."""

    def __init__(self, db: Session):
        self.db = db

    def log(
        self,
        entity_type: str,
        entity_id: int,
        action: str,
        actor: str | None = None,
        actor_type: str = "system",
        old_values: dict | None = None,
        new_values: dict | None = None,
        details: str | None = None,
        ip_address: str | None = None,
        user_agent: str | None = None,
    ) -> AuditLog:
        """Create an audit log entry."""
        entry = AuditLog(
            entity_type=entity_type,
            entity_id=entity_id,
            action=action,
            actor=actor,
            actor_type=actor_type,
            old_values=json.dumps(old_values, default=str) if old_values else None,
            new_values=json.dumps(new_values, default=str) if new_values else None,
            details=details,
            ip_address=ip_address,
            user_agent=user_agent,
        )
        self.db.add(entry)
        self.db.commit()
        self.db.refresh(entry)
        return entry

    def get(self, log_id: int) -> AuditLog | None:
        """Get a single audit log entry."""
        return self.db.query(AuditLog).filter(AuditLog.id == log_id).first()

    def list_logs(
        self,
        entity_type: str | None = None,
        entity_id: int | None = None,
        action: str | None = None,
        actor: str | None = None,
        offset: int = 0,
        limit: int = 50,
    ) -> tuple[list[AuditLog], int]:
        """Query audit logs with optional filters."""
        query = self.db.query(AuditLog)
        if entity_type:
            query = query.filter(AuditLog.entity_type == entity_type)
        if entity_id:
            query = query.filter(AuditLog.entity_id == entity_id)
        if action:
            query = query.filter(AuditLog.action == action)
        if actor:
            query = query.filter(AuditLog.actor == actor)
        total = query.count()
        logs = query.order_by(AuditLog.created_at.desc()).offset(offset).limit(limit).all()
        return logs, total

    def count_by_action(self, hours: int = 24) -> dict[str, int]:
        """Count audit log entries by action within a time window."""
        from datetime import timedelta
        cutoff = utc_now() - timedelta(hours=hours)
        rows = (
            self.db.query(AuditLog.action, func.count(AuditLog.id))
            .filter(AuditLog.created_at >= cutoff)
            .group_by(AuditLog.action)
            .all()
        )
        return {action: count for action, count in rows}

    def purge_old_logs(self, days: int = 90) -> int:
        """Delete audit logs older than N days."""
        from datetime import timedelta
        cutoff = utc_now() - timedelta(days=days)
        count = self.db.query(AuditLog).filter(AuditLog.created_at < cutoff).delete()
        self.db.commit()
        return count
