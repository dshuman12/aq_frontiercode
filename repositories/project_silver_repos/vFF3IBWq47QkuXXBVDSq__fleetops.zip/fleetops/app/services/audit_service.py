"""Audit logging service."""
from __future__ import annotations
import json
from typing import Any
from datetime import timedelta
from sqlalchemy.orm import Session
from app.models.audit import AuditLog
from app.utils.helpers import utc_now

class AuditService:
    def __init__(self, db: Session):
        self.db = db
    def log(self, entity_type: str, entity_id: int, action: str, actor: str | None = None,
            old_values: dict | None = None, new_values: dict | None = None,
            details: str | None = None) -> AuditLog:
        entry = AuditLog(entity_type=entity_type, entity_id=entity_id, action=action,
            actor=actor, old_values=json.dumps(old_values, default=str) if old_values else None,
            new_values=json.dumps(new_values, default=str) if new_values else None, details=details)
        self.db.add(entry); self.db.commit(); self.db.refresh(entry); return entry
    def list_logs(self, entity_type: str | None = None, offset: int = 0, limit: int = 50) -> tuple[list[AuditLog], int]:
        q = self.db.query(AuditLog)
        if entity_type: q = q.filter(AuditLog.entity_type == entity_type)
        total = q.count()
        return q.order_by(AuditLog.created_at.desc()).offset(offset).limit(limit).all(), total
