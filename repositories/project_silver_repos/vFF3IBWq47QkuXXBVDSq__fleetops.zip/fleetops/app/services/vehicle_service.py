"""Vehicle fleet management service."""
from __future__ import annotations
import json
from typing import Any
from sqlalchemy import func
from sqlalchemy.orm import Session
from app.exceptions import NotFoundError, DuplicateError, InvalidStateError, VehicleGroundedError, ValidationError
from app.models.vehicle import Vehicle, VehicleLocation
from app.utils.constants import VehicleStatus, VALID_VEHICLE_TRANSITIONS
from app.utils.helpers import utc_now
from app.utils.validators import validate_vin, validate_plate, validate_vehicle_type, validate_coordinates

class VehicleService:
    def __init__(self, db: Session):
        self.db = db

    def create(self, data: dict[str, Any]) -> Vehicle:
        plate = validate_plate(data["plate"])
        vin = validate_vin(data["vin"])
        validate_vehicle_type(data["vehicle_type"])
        if self.db.query(Vehicle).filter(Vehicle.plate == plate).first():
            raise DuplicateError("Vehicle", "plate", plate)
        if self.db.query(Vehicle).filter(Vehicle.vin == vin).first():
            raise DuplicateError("Vehicle", "vin", vin)
        vehicle = Vehicle(plate=plate, vin=vin, vehicle_type=data["vehicle_type"],
            make=data.get("make"), model=data.get("model"), year=data.get("year"),
            color=data.get("color"), fuel_capacity_liters=data.get("fuel_capacity_liters", 60.0),
            fleet_name=data.get("fleet_name"),
            metadata_json=json.dumps(data["metadata"], default=str) if data.get("metadata") else None)
        self.db.add(vehicle); self.db.commit(); self.db.refresh(vehicle)
        return vehicle

    def get(self, vehicle_id: int) -> Vehicle:
        v = self.db.query(Vehicle).filter(Vehicle.id == vehicle_id).first()
        if not v: raise NotFoundError("Vehicle", vehicle_id)
        return v

    def get_by_plate(self, plate: str) -> Vehicle:
        v = self.db.query(Vehicle).filter(Vehicle.plate == plate.upper()).first()
        if not v: raise NotFoundError("Vehicle", plate)
        return v

    def list_vehicles(self, status: str | None = None, fleet: str | None = None, offset: int = 0, limit: int = 20) -> tuple[list[Vehicle], int]:
        q = self.db.query(Vehicle)
        if status: q = q.filter(Vehicle.status == status)
        if fleet: q = q.filter(Vehicle.fleet_name == fleet)
        total = q.count()
        return q.order_by(Vehicle.plate).offset(offset).limit(limit).all(), total

    def update(self, vehicle_id: int, data: dict[str, Any]) -> Vehicle:
        v = self.get(vehicle_id)
        for k in ("make", "model", "color", "fleet_name"):
            if k in data and data[k] is not None: setattr(v, k, data[k])
        if "metadata" in data:
            v.metadata_json = json.dumps(data["metadata"], default=str) if data["metadata"] else None
        self.db.commit(); self.db.refresh(v)
        return v

    def transition_status(self, vehicle_id: int, new_status: str, reason: str | None = None) -> Vehicle:
        v = self.get(vehicle_id)
        current = VehicleStatus(v.status); target = VehicleStatus(new_status)
        allowed = VALID_VEHICLE_TRANSITIONS.get(current, [])
        if target not in allowed: raise InvalidStateError("Vehicle", current.value, target.value)
        v.status = target.value
        if target == VehicleStatus.GROUNDED: v.grounded_reason = reason or "Grounded by operator"
        elif current == VehicleStatus.GROUNDED: v.grounded_reason = None
        self.db.commit(); self.db.refresh(v)
        return v

    def update_location(self, vehicle_id: int, lat: float, lon: float, speed_kmh: float = 0.0, heading: float | None = None) -> VehicleLocation:
        v = self.get(vehicle_id); validate_coordinates(lat, lon)
        v.current_lat = lat; v.current_lon = lon; v.current_speed_kmh = speed_kmh
        loc = VehicleLocation(vehicle_id=v.id, latitude=lat, longitude=lon, speed_kmh=speed_kmh, heading=heading)
        self.db.add(loc); self.db.commit(); self.db.refresh(loc)
        return loc

    def get_location_history(self, vehicle_id: int, limit: int = 100) -> list[VehicleLocation]:
        self.get(vehicle_id)
        return self.db.query(VehicleLocation).filter(VehicleLocation.vehicle_id == vehicle_id).order_by(VehicleLocation.recorded_at.desc()).limit(limit).all()

    def update_fuel(self, vehicle_id: int, level_pct: float) -> Vehicle:
        v = self.get(vehicle_id); v.fuel_level_pct = max(0.0, min(100.0, level_pct))
        self.db.commit(); self.db.refresh(v); return v

    def update_odometer(self, vehicle_id: int, km: float) -> Vehicle:
        v = self.get(vehicle_id)
        if km < v.odometer_km: raise ValidationError(f"Odometer cannot decrease: {km} < {v.odometer_km}")
        v.odometer_km = km; self.db.commit(); self.db.refresh(v); return v

    def assign_driver(self, vehicle_id: int, driver_id: int) -> Vehicle:
        v = self.get(vehicle_id)
        if v.status == VehicleStatus.GROUNDED.value:
            raise VehicleGroundedError(v.plate, v.grounded_reason or "unknown")
        from app.models.driver import Driver
        driver = self.db.query(Driver).filter(Driver.id == driver_id).first()
        if not driver: raise NotFoundError("Driver", driver_id)
        v.assigned_driver_id = driver_id; self.db.commit(); self.db.refresh(v); return v

    def unassign_driver(self, vehicle_id: int) -> Vehicle:
        v = self.get(vehicle_id); v.assigned_driver_id = None
        self.db.commit(); self.db.refresh(v); return v

    def delete(self, vehicle_id: int) -> None:
        v = self.get(vehicle_id)
        if v.status not in (VehicleStatus.AVAILABLE.value, VehicleStatus.DECOMMISSIONED.value):
            raise ValidationError(f"Cannot delete vehicle in \'{v.status}\' status")
        self.db.delete(v); self.db.commit()

    def get_fleet_stats(self, fleet_name: str | None = None) -> dict[str, Any]:
        q = self.db.query(Vehicle)
        if fleet_name: q = q.filter(Vehicle.fleet_name == fleet_name)
        total = q.count()
        statuses = self.db.query(Vehicle.status, func.count(Vehicle.id))
        if fleet_name: statuses = statuses.filter(Vehicle.fleet_name == fleet_name)
        status_map = {s: c for s, c in statuses.group_by(Vehicle.status).all()}
        avg_fuel = q.with_entities(func.avg(Vehicle.fuel_level_pct)).scalar()
        return {"total": total, "by_status": status_map, "avg_fuel_pct": float(avg_fuel) if avg_fuel else 0}

# Add project infrastructure

# Set up FastAPI skeleton

# Add domain exceptions

# Add constants and enums

# Add helper utilities

# Add input validators

# Add geospatial utilities

# Add date/time utilities

# Add security utilities

# Add output formatters

# Add CSV export helpers

# Add condition evaluation engine

# Add retry with backoff strategies

# Add rate limiter

# Add circuit breaker

# Add pagination utilities

# Add idempotency store

# Add logging config

# Add health check system

# Add Vehicle model

# Add Driver model

# Add Route and RouteStop models

# Add MaintenanceRecord model

# Add Incident model

# Add FuelEvent model

# Add Geofence model

# Add Dispatch model

# Add Alert model

# Add AuditLog model

# Add common schemas

# Add vehicle schemas

# Add driver schemas

# Add VehicleService

# Add DriverService

# Add analytics service

# Add search service

# Add report service

# Add audit service

# Add API routers

# Add middleware and error handlers

# Wire up FastAPI application

# Add CLI commands

# Add Alembic migration config

# Add CI workflow

# Add documentation

# Add test fixtures

# Add vehicle service tests

# Add driver service tests

# Add utility tests

# Add extended modules

# refactor: extract validation logic

# fix: handle edge cases in transitions

# docs: update README

# chore: formatting cleanup

# refactor: improve error messages

# fix: geofence radius validation

# chore: add type hints

# refactor: simplify queries

# fix: handle null coordinates

# chore: update dependencies

# refactor: extract constants

# fix: driver hours calculation

# docs: add API documentation

# chore: lint fixes

# refactor: improve test fixtures

# fix: maintenance status transitions

# chore: add missing init files

# refactor: simplify service constructors

# fix: fuel level clamping

# fix: odometer validation

# chore: remove dead code

# refactor: extract geo calculations

# fix: pagination edge cases

# docs: update CHANGELOG

# chore: code review fixes

# refactor: improve logging

# fix: driver shift tracking

# chore: update gitignore

# refactor: clean up imports

# fix: vehicle deletion check

# chore: add seed script

# refactor: normalize responses

# fix: audit log serialization

# docs: add contributing guide

# chore: pin dependencies

# refactor: extract middlewares

# fix: search query escaping

# chore: format code

# refactor: improve error handling

# fix: timezone handling

# chore: add health endpoint

# refactor: simplify state machines

# fix: concurrent modification handling

# docs: add deployment guide

# chore: update Docker config

# Bump version to 0.9.0

# fix: validate fleet name

# chore: final cleanup

# Bump version to 0.9.1
