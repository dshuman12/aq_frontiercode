"""Fleet analytics."""
from __future__ import annotations
from typing import Any
from sqlalchemy import func
from sqlalchemy.orm import Session
from app.models.vehicle import Vehicle
from app.models.driver import Driver
from app.utils.constants import VehicleStatus, DriverStatus

class AnalyticsService:
    def __init__(self, db: Session):
        self.db = db
    def get_dashboard(self) -> dict[str, Any]:
        tv = self.db.query(func.count(Vehicle.id)).scalar() or 0
        av = self.db.query(func.count(Vehicle.id)).filter(Vehicle.status == "available").scalar() or 0
        td = self.db.query(func.count(Driver.id)).scalar() or 0
        avg_fuel = self.db.query(func.avg(Vehicle.fuel_level_pct)).scalar()
        return {"total_vehicles": tv, "available_vehicles": av, "total_drivers": td,
            "avg_fuel_level_pct": float(avg_fuel) if avg_fuel else 0}
