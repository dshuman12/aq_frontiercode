"""Cross-entity search."""
from __future__ import annotations
from typing import Any
from sqlalchemy import or_
from sqlalchemy.orm import Session
from app.models.vehicle import Vehicle
from app.models.driver import Driver

class SearchService:
    def __init__(self, db: Session):
        self.db = db
    def global_search(self, query: str, limit: int = 10) -> dict[str, Any]:
        s = f"%{query}%"
        vehicles = self.db.query(Vehicle).filter(or_(Vehicle.plate.ilike(s), Vehicle.vin.ilike(s))).limit(limit).all()
        drivers = self.db.query(Driver).filter(or_(Driver.name.ilike(s), Driver.employee_id.ilike(s))).limit(limit).all()
        return {"vehicles": [{"id": v.id, "plate": v.plate, "status": v.status} for v in vehicles],
            "drivers": [{"id": d.id, "name": d.name, "status": d.status} for d in drivers]}
