"""Driver management service."""
from __future__ import annotations
import json
from typing import Any
from sqlalchemy import func
from sqlalchemy.orm import Session
from app.exceptions import NotFoundError, DuplicateError, InvalidStateError, DriverHoursExceededError
from app.models.driver import Driver, DriverShift
from app.utils.constants import DriverStatus, VALID_DRIVER_TRANSITIONS
from app.utils.helpers import utc_now
from app.config import settings

class DriverService:
    def __init__(self, db: Session):
        self.db = db

    def create(self, data: dict[str, Any]) -> Driver:
        if self.db.query(Driver).filter(Driver.employee_id == data["employee_id"]).first():
            raise DuplicateError("Driver", "employee_id", data["employee_id"])
        driver = Driver(employee_id=data["employee_id"], name=data["name"],
            email=data.get("email"), phone=data.get("phone"),
            license_number=data["license_number"], license_class=data.get("license_class"),
            metadata_json=json.dumps(data["metadata"], default=str) if data.get("metadata") else None)
        self.db.add(driver); self.db.commit(); self.db.refresh(driver)
        return driver

    def get(self, driver_id: int) -> Driver:
        d = self.db.query(Driver).filter(Driver.id == driver_id).first()
        if not d: raise NotFoundError("Driver", driver_id)
        return d

    def get_by_employee_id(self, eid: str) -> Driver:
        d = self.db.query(Driver).filter(Driver.employee_id == eid).first()
        if not d: raise NotFoundError("Driver", eid)
        return d

    def list_drivers(self, status: str | None = None, offset: int = 0, limit: int = 20) -> tuple[list[Driver], int]:
        q = self.db.query(Driver)
        if status: q = q.filter(Driver.status == status)
        total = q.count()
        return q.order_by(Driver.name).offset(offset).limit(limit).all(), total

    def transition_status(self, driver_id: int, new_status: str) -> Driver:
        d = self.get(driver_id)
        current = DriverStatus(d.status); target = DriverStatus(new_status)
        allowed = VALID_DRIVER_TRANSITIONS.get(current, [])
        if target not in allowed: raise InvalidStateError("Driver", current.value, target.value)
        if target == DriverStatus.DRIVING:
            if d.total_hours_today >= settings.max_driving_hours:
                raise DriverHoursExceededError(d.employee_id, d.total_hours_today, settings.max_driving_hours)
        d.status = target.value
        if target == DriverStatus.RESTING: d.last_rest_at = utc_now()
        self.db.commit(); self.db.refresh(d); return d

    def start_shift(self, driver_id: int) -> DriverShift:
        d = self.get(driver_id)
        shift = DriverShift(driver_id=d.id, start_time=utc_now())
        self.db.add(shift); self.db.commit(); self.db.refresh(shift); return shift

    def end_shift(self, shift_id: int, hours_driven: float = 0.0, distance_km: float = 0.0) -> DriverShift:
        shift = self.db.query(DriverShift).filter(DriverShift.id == shift_id).first()
        if not shift: raise NotFoundError("DriverShift", shift_id)
        shift.end_time = utc_now(); shift.hours_driven = hours_driven
        shift.distance_km = distance_km; shift.status = "completed"
        driver = self.get(shift.driver_id)
        driver.total_hours_today += hours_driven; driver.total_distance_km += distance_km
        self.db.commit(); self.db.refresh(shift); return shift

    def get_stats(self) -> dict[str, Any]:
        total = self.db.query(func.count(Driver.id)).scalar() or 0
        statuses = {s: c for s, c in self.db.query(Driver.status, func.count(Driver.id)).group_by(Driver.status).all()}
        return {"total": total, "by_status": statuses}
