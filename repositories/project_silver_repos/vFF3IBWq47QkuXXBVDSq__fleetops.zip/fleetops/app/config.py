"""Application configuration."""
from __future__ import annotations
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    database_url: str = "sqlite:///./fleetops.db"
    secret_key: str = "dev-secret-key"
    log_level: str = "INFO"
    cors_origins: str = "http://localhost:3000"
    geofence_default_radius_m: int = 500
    maintenance_overdue_days: int = 30
    fuel_alert_threshold_pct: int = 15
    speed_limit_kmh: int = 120
    max_driving_hours: int = 11
    rest_period_hours: int = 10
    dispatch_lookahead_hours: int = 24
    max_route_stops: int = 50
    max_vehicles_per_fleet: int = 500
    incident_auto_ground_vehicle: bool = True

    class Config:
        env_file = ".env"
        case_sensitive = False

settings = Settings()
