"""Celery worker configuration and task definitions."""

from __future__ import annotations

import json
import logging
import time
from typing import Any

from app.config import settings

logger = logging.getLogger("fleetops.worker")


class TaskExecutor:
    """Executes task payloads and manages worker-side lifecycle."""

    def __init__(self):
        self._handlers: dict[str, Any] = {}
        self._middleware: list[Any] = []
        self._running: dict[int, dict] = {}

    def register_handler(self, task_type: str, handler: Any) -> None:
        """Register a handler function for a task type."""
        self._handlers[task_type] = handler
        logger.info("Registered handler for task type: %s", task_type)

    def unregister_handler(self, task_type: str) -> None:
        """Remove a handler for a task type."""
        self._handlers.pop(task_type, None)

    def get_handler(self, task_type: str) -> Any | None:
        """Get the handler for a task type."""
        return self._handlers.get(task_type)

    def has_handler(self, task_type: str) -> bool:
        """Check if a handler exists for a task type."""
        return task_type in self._handlers

    def list_handlers(self) -> list[str]:
        """List all registered task types."""
        return list(self._handlers.keys())

    def add_middleware(self, middleware: Any) -> None:
        """Add execution middleware."""
        self._middleware.append(middleware)

    def execute(self, task_id: int, task_type: str, payload: dict | None = None) -> dict[str, Any]:
        """Execute a task and return the result."""
        handler = self._handlers.get(task_type)
        if not handler:
            raise ValueError(f"No handler registered for task type: {task_type}")

        self._running[task_id] = {
            "task_type": task_type,
            "started_at": time.monotonic(),
        }

        try:
            for mw in self._middleware:
                if hasattr(mw, "before_execute"):
                    mw.before_execute(task_id, task_type, payload)

            result = handler(payload or {})

            for mw in self._middleware:
                if hasattr(mw, "after_execute"):
                    mw.after_execute(task_id, task_type, result)

            elapsed = time.monotonic() - self._running[task_id]["started_at"]
            return {
                "status": "success",
                "result": result,
                "duration_seconds": elapsed,
            }
        except Exception as e:
            elapsed = time.monotonic() - self._running[task_id]["started_at"]
            logger.error("Task %d (%s) failed: %s", task_id, task_type, str(e))
            return {
                "status": "failed",
                "error": str(e),
                "duration_seconds": elapsed,
            }
        finally:
            self._running.pop(task_id, None)

    def get_running_tasks(self) -> dict[int, dict]:
        """Get currently running tasks."""
        return dict(self._running)

    def cancel_task(self, task_id: int) -> bool:
        """Request cancellation of a running task."""
        if task_id in self._running:
            self._running[task_id]["cancel_requested"] = True
            return True
        return False


class LoggingMiddleware:
    """Middleware that logs task execution."""

    def before_execute(self, task_id: int, task_type: str, payload: dict | None) -> None:
        logger.info("Starting task %d (%s)", task_id, task_type)

    def after_execute(self, task_id: int, task_type: str, result: Any) -> None:
        logger.info("Completed task %d (%s)", task_id, task_type)


class MetricsMiddleware:
    """Middleware that collects execution metrics."""

    def __init__(self):
        self.execution_count = 0
        self.success_count = 0
        self.failure_count = 0
        self.total_duration = 0.0

    def before_execute(self, task_id: int, task_type: str, payload: dict | None) -> None:
        self.execution_count += 1

    def after_execute(self, task_id: int, task_type: str, result: Any) -> None:
        self.success_count += 1

    def get_metrics(self) -> dict[str, Any]:
        return {
            "executions": self.execution_count,
            "successes": self.success_count,
            "failures": self.failure_count,
            "total_duration": self.total_duration,
            "avg_duration": (
                self.total_duration / self.execution_count
                if self.execution_count > 0
                else 0
            ),
        }


class RetryPolicy:
    """Configurable retry policy for task execution."""

    def __init__(
        self,
        max_retries: int = 3,
        base_delay: float = 1.0,
        max_delay: float = 300.0,
        backoff_factor: float = 2.0,
        retryable_errors: set[type] | None = None,
    ):
        self.max_retries = max_retries
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.backoff_factor = backoff_factor
        self.retryable_errors = retryable_errors or {Exception}

    def should_retry(self, attempt: int, error: Exception) -> bool:
        """Determine if a failed task should be retried."""
        if attempt >= self.max_retries:
            return False
        return any(isinstance(error, t) for t in self.retryable_errors)

    def get_delay(self, attempt: int) -> float:
        """Calculate the delay before the next retry."""
        delay = self.base_delay * (self.backoff_factor ** attempt)
        return min(delay, self.max_delay)

    def execute_with_retry(self, func: Any, *args: Any, **kwargs: Any) -> Any:
        """Execute a function with retry logic."""
        last_error = None
        for attempt in range(self.max_retries + 1):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                last_error = e
                if not self.should_retry(attempt, e):
                    raise
                delay = self.get_delay(attempt)
                logger.warning(
                    "Retry %d/%d after %.1fs: %s",
                    attempt + 1, self.max_retries, delay, str(e),
                )
                time.sleep(delay)
        raise last_error


class WorkerPool:
    """Manages a pool of task executors."""

    def __init__(self, pool_size: int = 4):
        self.pool_size = pool_size
        self._executors: list[TaskExecutor] = []
        self._active_count = 0

    def initialize(self) -> None:
        """Initialize the worker pool."""
        for _ in range(self.pool_size):
            executor = TaskExecutor()
            executor.add_middleware(LoggingMiddleware())
            executor.add_middleware(MetricsMiddleware())
            self._executors.append(executor)

    def get_executor(self) -> TaskExecutor | None:
        """Get an available executor from the pool."""
        if self._active_count >= self.pool_size:
            return None
        self._active_count += 1
        return self._executors[self._active_count - 1]

    def release_executor(self) -> None:
        """Release an executor back to the pool."""
        if self._active_count > 0:
            self._active_count -= 1

    def get_pool_status(self) -> dict[str, Any]:
        """Get pool status."""
        return {
            "pool_size": self.pool_size,
            "active": self._active_count,
            "available": self.pool_size - self._active_count,
        }

    def shutdown(self) -> None:
        """Shutdown the worker pool."""
        self._executors.clear()
        self._active_count = 0
