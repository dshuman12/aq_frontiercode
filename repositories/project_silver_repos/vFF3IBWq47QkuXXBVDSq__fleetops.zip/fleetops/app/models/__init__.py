from app.models.vehicle import Vehicle, VehicleLocation
from app.models.driver import Driver, DriverShift
from app.models.route import Route, RouteStop
from app.models.maintenance import MaintenanceRecord
from app.models.incident import Incident
from app.models.fuel import FuelEvent
from app.models.geofence import Geofence, GeofenceEvent
from app.models.dispatch import Dispatch
from app.models.audit import AuditLog
from app.models.alert import Alert

__all__ = ["Vehicle", "VehicleLocation", "Driver", "DriverShift", "Route", "RouteStop",
    "MaintenanceRecord", "Incident", "FuelEvent", "Geofence", "GeofenceEvent",
    "Dispatch", "AuditLog", "Alert"]
