"""Queue model — represents a named job queue with configuration."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, Enum, Integer, String, Text, Boolean, ForeignKey, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base
from app.utils.constants import QueueStatus
from app.utils.date_utils import utc_now


class Queue(Base):
    __tablename__ = "queues"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(128), unique=True, nullable=False, index=True)
    display_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(
        Enum(QueueStatus), default=QueueStatus.ACTIVE, nullable=False, index=True
    )

    max_size: Mapped[int] = mapped_column(Integer, default=10000, nullable=False)
    max_retries: Mapped[int] = mapped_column(Integer, default=3, nullable=False)
    retry_delay: Mapped[int] = mapped_column(Integer, default=60, nullable=False)
    timeout: Mapped[int] = mapped_column(Integer, default=3600, nullable=False)
    concurrency_limit: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    rate_limit: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    rate_window: Mapped[int] = mapped_column(Integer, default=60, nullable=False)

    enable_dead_letter: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    dead_letter_queue_id: Mapped[int | None] = mapped_column(
        Integer, ForeignKey("queues.id"), nullable=True
    )
    priority_enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    fifo: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=utc_now, onupdate=utc_now, nullable=False
    )
    paused_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    tasks = relationship("Task", back_populates="queue", lazy="dynamic")
    tags = relationship("QueueTag", back_populates="queue", cascade="all, delete-orphan")
    dead_letter_queue = relationship("Queue", remote_side=[id], lazy="joined")

    def __repr__(self) -> str:
        return f"<Queue id={self.id} name={self.name!r} status={self.status}>"


class QueueTag(Base):
    __tablename__ = "queue_tags"
    __table_args__ = (UniqueConstraint("queue_id", "tag", name="uq_queue_tag"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    queue_id: Mapped[int] = mapped_column(Integer, ForeignKey("queues.id"), nullable=False)
    tag: Mapped[str] = mapped_column(String(64), nullable=False, index=True)

    queue = relationship("Queue", back_populates="tags")
