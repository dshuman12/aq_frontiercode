"""Task model — represents a unit of work submitted to a queue."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import (
    DateTime, Enum, Float, Integer, String, Text, Boolean,
    ForeignKey, UniqueConstraint, Index,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base
from app.utils.constants import TaskPriority, TaskStatus
from app.utils.date_utils import utc_now


class Task(Base):
    __tablename__ = "tasks"
    __table_args__ = (
        Index("ix_tasks_status_priority", "status", "priority"),
        Index("ix_tasks_queue_status", "queue_id", "status"),
        Index("ix_tasks_scheduled_at", "scheduled_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    task_type: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    queue_id: Mapped[int] = mapped_column(Integer, ForeignKey("queues.id"), nullable=False)

    status: Mapped[str] = mapped_column(
        Enum(TaskStatus), default=TaskStatus.PENDING, nullable=False, index=True
    )
    priority: Mapped[int] = mapped_column(
        Integer, default=TaskPriority.NORMAL, nullable=False
    )

    payload: Mapped[str | None] = mapped_column(Text, nullable=True)
    result: Mapped[str | None] = mapped_column(Text, nullable=True)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    error_traceback: Mapped[str | None] = mapped_column(Text, nullable=True)

    retry_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    max_retries: Mapped[int] = mapped_column(Integer, default=3, nullable=False)
    retry_delay: Mapped[int] = mapped_column(Integer, default=60, nullable=False)
    timeout: Mapped[int] = mapped_column(Integer, default=3600, nullable=False)

    worker_id: Mapped[int | None] = mapped_column(
        Integer, ForeignKey("workers.id"), nullable=True
    )

    idempotency_key: Mapped[str | None] = mapped_column(
        String(255), unique=True, nullable=True, index=True
    )
    payload_hash: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    correlation_id: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)

    scheduled_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=utc_now, onupdate=utc_now, nullable=False
    )
    started_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    next_retry_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    deadline: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    duration_seconds: Mapped[float | None] = mapped_column(Float, nullable=True)

    is_batch: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    batch_id: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    parent_task_id: Mapped[int | None] = mapped_column(
        Integer, ForeignKey("tasks.id"), nullable=True
    )
    pipeline_run_id: Mapped[int | None] = mapped_column(
        Integer, ForeignKey("pipeline_runs.id"), nullable=True
    )
    pipeline_step_index: Mapped[int | None] = mapped_column(Integer, nullable=True)

    metadata_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    progress: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    queue = relationship("Queue", back_populates="tasks")
    worker = relationship("Worker", back_populates="tasks")
    tags = relationship("TaskTag", back_populates="task", cascade="all, delete-orphan")
    parent_task = relationship("Task", remote_side=[id], lazy="select")
    dependencies = relationship(
        "TaskDependency",
        foreign_keys="TaskDependency.task_id",
        back_populates="task",
        cascade="all, delete-orphan",
    )
    dependents = relationship(
        "TaskDependency",
        foreign_keys="TaskDependency.depends_on_id",
        back_populates="depends_on",
    )
    pipeline_run = relationship("PipelineRun", back_populates="tasks", lazy="select")

    def __repr__(self) -> str:
        return f"<Task id={self.id} name={self.name!r} status={self.status}>"

    @property
    def is_terminal(self) -> bool:
        """True if the task is in a terminal state."""
        from app.utils.constants import TERMINAL_TASK_STATES
        return TaskStatus(self.status) in TERMINAL_TASK_STATES

    @property
    def is_active(self) -> bool:
        """True if the task is actively being processed."""
        from app.utils.constants import ACTIVE_TASK_STATES
        return TaskStatus(self.status) in ACTIVE_TASK_STATES


class TaskTag(Base):
    __tablename__ = "task_tags"
    __table_args__ = (UniqueConstraint("task_id", "tag", name="uq_task_tag"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    task_id: Mapped[int] = mapped_column(Integer, ForeignKey("tasks.id"), nullable=False)
    tag: Mapped[str] = mapped_column(String(64), nullable=False, index=True)

    task = relationship("Task", back_populates="tags")


class TaskDependency(Base):
    __tablename__ = "task_dependencies"
    __table_args__ = (
        UniqueConstraint("task_id", "depends_on_id", name="uq_task_dependency"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    task_id: Mapped[int] = mapped_column(Integer, ForeignKey("tasks.id"), nullable=False)
    depends_on_id: Mapped[int] = mapped_column(Integer, ForeignKey("tasks.id"), nullable=False)

    task = relationship("Task", foreign_keys=[task_id], back_populates="dependencies")
    depends_on = relationship("Task", foreign_keys=[depends_on_id], back_populates="dependents")
