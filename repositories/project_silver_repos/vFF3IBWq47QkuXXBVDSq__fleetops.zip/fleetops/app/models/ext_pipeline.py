"""Pipeline models — multi-step task workflows."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, Enum, Integer, String, Text, Boolean, Float, ForeignKey, Index
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base
from app.utils.constants import PipelineStatus, PipelineStepStatus
from app.utils.date_utils import utc_now


class Pipeline(Base):
    __tablename__ = "pipelines"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(255), unique=True, nullable=False, index=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    version: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

    queue_name: Mapped[str] = mapped_column(String(128), nullable=False)
    on_failure: Mapped[str] = mapped_column(
        String(32), default="stop", nullable=False
    )
    max_concurrent_runs: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    timeout: Mapped[int] = mapped_column(Integer, default=7200, nullable=False)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=utc_now, onupdate=utc_now, nullable=False
    )
    metadata_json: Mapped[str | None] = mapped_column(Text, nullable=True)

    steps = relationship(
        "PipelineStep", back_populates="pipeline",
        cascade="all, delete-orphan", order_by="PipelineStep.step_index",
    )
    runs = relationship("PipelineRun", back_populates="pipeline", cascade="all, delete-orphan")

    def __repr__(self) -> str:
        return f"<Pipeline id={self.id} name={self.name!r} v={self.version}>"


class PipelineStep(Base):
    __tablename__ = "pipeline_steps"
    __table_args__ = (
        Index("ix_pipeline_step_order", "pipeline_id", "step_index"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    pipeline_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("pipelines.id"), nullable=False
    )
    step_index: Mapped[int] = mapped_column(Integer, nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    task_type: Mapped[str] = mapped_column(String(128), nullable=False)

    task_payload_template: Mapped[str | None] = mapped_column(Text, nullable=True)
    timeout: Mapped[int] = mapped_column(Integer, default=3600, nullable=False)
    max_retries: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    continue_on_failure: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    condition: Mapped[str | None] = mapped_column(Text, nullable=True)

    pipeline = relationship("Pipeline", back_populates="steps")

    def __repr__(self) -> str:
        return f"<PipelineStep pipeline={self.pipeline_id} index={self.step_index} name={self.name!r}>"


class PipelineRun(Base):
    __tablename__ = "pipeline_runs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    pipeline_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("pipelines.id"), nullable=False, index=True
    )
    status: Mapped[str] = mapped_column(
        Enum(PipelineStatus), default=PipelineStatus.PENDING, nullable=False, index=True
    )
    current_step: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    trigger: Mapped[str] = mapped_column(String(64), default="manual", nullable=False)
    correlation_id: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    input_data: Mapped[str | None] = mapped_column(Text, nullable=True)
    output_data: Mapped[str | None] = mapped_column(Text, nullable=True)

    started_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, nullable=False)
    duration_seconds: Mapped[float | None] = mapped_column(Float, nullable=True)

    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    metadata_json: Mapped[str | None] = mapped_column(Text, nullable=True)

    pipeline = relationship("Pipeline", back_populates="runs")
    step_runs = relationship(
        "PipelineStepRun", back_populates="pipeline_run",
        cascade="all, delete-orphan", order_by="PipelineStepRun.step_index",
    )
    tasks = relationship("Task", back_populates="pipeline_run", lazy="dynamic")

    def __repr__(self) -> str:
        return f"<PipelineRun id={self.id} pipeline={self.pipeline_id} status={self.status}>"


class PipelineStepRun(Base):
    __tablename__ = "pipeline_step_runs"
    __table_args__ = (
        Index("ix_step_run_order", "pipeline_run_id", "step_index"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    pipeline_run_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("pipeline_runs.id"), nullable=False
    )
    step_index: Mapped[int] = mapped_column(Integer, nullable=False)
    step_name: Mapped[str] = mapped_column(String(255), nullable=False)
    task_id: Mapped[int | None] = mapped_column(Integer, nullable=True)

    status: Mapped[str] = mapped_column(
        Enum(PipelineStepStatus), default=PipelineStepStatus.PENDING, nullable=False
    )
    started_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    duration_seconds: Mapped[float | None] = mapped_column(Float, nullable=True)

    input_data: Mapped[str | None] = mapped_column(Text, nullable=True)
    output_data: Mapped[str | None] = mapped_column(Text, nullable=True)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)

    pipeline_run = relationship("PipelineRun", back_populates="step_runs")
