"""Worker model — represents a task consumer/executor."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, Enum, Integer, String, Text, Float, ForeignKey, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base
from app.utils.constants import WorkerStatus
from app.utils.date_utils import utc_now


class Worker(Base):
    __tablename__ = "workers"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    worker_id: Mapped[str] = mapped_column(String(128), unique=True, nullable=False, index=True)
    hostname: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    pid: Mapped[int | None] = mapped_column(Integer, nullable=True)
    status: Mapped[str] = mapped_column(
        Enum(WorkerStatus), default=WorkerStatus.IDLE, nullable=False, index=True
    )

    concurrency: Mapped[int] = mapped_column(Integer, default=4, nullable=False)
    current_tasks: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    tasks_completed: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    tasks_failed: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    cpu_usage: Mapped[float | None] = mapped_column(Float, nullable=True)
    memory_usage: Mapped[float | None] = mapped_column(Float, nullable=True)
    disk_usage: Mapped[float | None] = mapped_column(Float, nullable=True)

    version: Mapped[str | None] = mapped_column(String(64), nullable=True)
    queue_names: Mapped[str | None] = mapped_column(Text, nullable=True)

    started_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, nullable=False)
    last_heartbeat: Mapped[datetime] = mapped_column(DateTime, default=utc_now, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=utc_now, onupdate=utc_now, nullable=False
    )
    stopped_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    metadata_json: Mapped[str | None] = mapped_column(Text, nullable=True)

    tasks = relationship("Task", back_populates="worker", lazy="dynamic")
    capabilities = relationship(
        "WorkerCapability", back_populates="worker", cascade="all, delete-orphan"
    )

    def __repr__(self) -> str:
        return f"<Worker id={self.id} worker_id={self.worker_id!r} status={self.status}>"


class WorkerCapability(Base):
    __tablename__ = "worker_capabilities"
    __table_args__ = (UniqueConstraint("worker_id", "capability", name="uq_worker_capability"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    worker_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("workers.id"), nullable=False
    )
    capability: Mapped[str] = mapped_column(String(128), nullable=False, index=True)

    worker = relationship("Worker", back_populates="capabilities")
