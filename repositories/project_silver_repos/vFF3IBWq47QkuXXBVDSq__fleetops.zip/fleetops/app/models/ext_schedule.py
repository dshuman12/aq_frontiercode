"""Schedule model — cron-based recurring task definitions."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, Enum, Integer, String, Text, Boolean, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base
from app.utils.constants import ScheduleStatus
from app.utils.date_utils import utc_now


class Schedule(Base):
    __tablename__ = "schedules"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(255), unique=True, nullable=False, index=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(
        Enum(ScheduleStatus), default=ScheduleStatus.ACTIVE, nullable=False, index=True
    )

    cron_expression: Mapped[str] = mapped_column(String(128), nullable=False)
    timezone: Mapped[str] = mapped_column(String(64), default="UTC", nullable=False)

    task_name: Mapped[str] = mapped_column(String(255), nullable=False)
    task_type: Mapped[str] = mapped_column(String(128), nullable=False)
    queue_name: Mapped[str] = mapped_column(String(128), nullable=False)
    task_payload: Mapped[str | None] = mapped_column(Text, nullable=True)
    task_priority: Mapped[int] = mapped_column(Integer, default=5, nullable=False)
    task_timeout: Mapped[int] = mapped_column(Integer, default=3600, nullable=False)
    task_max_retries: Mapped[int] = mapped_column(Integer, default=3, nullable=False)

    enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    max_instances: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    coalesce: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    jitter_seconds: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    last_run_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    next_run_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True, index=True)
    run_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    failure_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    starts_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=utc_now, onupdate=utc_now, nullable=False
    )

    metadata_json: Mapped[str | None] = mapped_column(Text, nullable=True)

    runs = relationship("ScheduleRun", back_populates="schedule", cascade="all, delete-orphan")

    def __repr__(self) -> str:
        return f"<Schedule id={self.id} name={self.name!r} cron={self.cron_expression!r}>"


class ScheduleRun(Base):
    __tablename__ = "schedule_runs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    schedule_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("schedules.id"), nullable=False, index=True
    )
    task_id: Mapped[int | None] = mapped_column(Integer, nullable=True)

    triggered_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, nullable=False)
    scheduled_for: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    status: Mapped[str] = mapped_column(String(32), default="triggered", nullable=False)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)

    schedule = relationship("Schedule", back_populates="runs")
