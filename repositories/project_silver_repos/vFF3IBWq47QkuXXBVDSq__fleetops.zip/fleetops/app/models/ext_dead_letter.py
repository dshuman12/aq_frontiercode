"""Dead letter queue model for failed task tracking and analysis."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, Integer, String, Text, Float, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column

from app.database import Base
from app.utils.date_utils import utc_now


class DeadLetterEntry(Base):
    __tablename__ = "dead_letter_entries"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    original_task_id: Mapped[int] = mapped_column(Integer, nullable=False, index=True)
    queue_name: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    task_name: Mapped[str] = mapped_column(String(255), nullable=False)
    task_type: Mapped[str] = mapped_column(String(128), nullable=False)

    payload: Mapped[str | None] = mapped_column(Text, nullable=True)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    error_traceback: Mapped[str | None] = mapped_column(Text, nullable=True)
    error_count: Mapped[int] = mapped_column(Integer, default=1, nullable=False)

    first_failed_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    last_failed_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, nullable=False)

    requeued: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    requeued_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    resolution: Mapped[str | None] = mapped_column(String(64), nullable=True)
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    resolved_by: Mapped[str | None] = mapped_column(String(255), nullable=True)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)

    def __repr__(self) -> str:
        return (
            f"<DeadLetterEntry id={self.id} task={self.original_task_id} "
            f"queue={self.queue_name!r}>"
        )


class MetricSnapshot(Base):
    """Point-in-time metric snapshot for historical tracking."""

    __tablename__ = "metric_snapshots"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    metric_name: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    metric_value: Mapped[float] = mapped_column(Float, nullable=False)
    labels: Mapped[str | None] = mapped_column(Text, nullable=True)
    recorded_at: Mapped[datetime] = mapped_column(
        DateTime, default=utc_now, nullable=False, index=True
    )

    def __repr__(self) -> str:
        return f"<MetricSnapshot {self.metric_name}={self.metric_value}>"
