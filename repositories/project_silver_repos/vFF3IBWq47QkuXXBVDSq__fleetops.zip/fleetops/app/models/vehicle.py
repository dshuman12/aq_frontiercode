"""Vehicle model."""
from __future__ import annotations
from datetime import datetime
from sqlalchemy import DateTime, Integer, String, Text, Float, Boolean, ForeignKey, Index
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.database import Base
from app.utils.helpers import utc_now

class Vehicle(Base):
    __tablename__ = "vehicles"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    plate: Mapped[str] = mapped_column(String(20), unique=True, nullable=False, index=True)
    vin: Mapped[str] = mapped_column(String(17), unique=True, nullable=False, index=True)
    vehicle_type: Mapped[str] = mapped_column(String(32), nullable=False)
    make: Mapped[str | None] = mapped_column(String(64), nullable=True)
    model: Mapped[str | None] = mapped_column(String(64), nullable=True)
    year: Mapped[int | None] = mapped_column(Integer, nullable=True)
    color: Mapped[str | None] = mapped_column(String(32), nullable=True)
    status: Mapped[str] = mapped_column(String(32), default="available", nullable=False, index=True)
    odometer_km: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    fuel_capacity_liters: Mapped[float] = mapped_column(Float, default=60.0, nullable=False)
    fuel_level_pct: Mapped[float] = mapped_column(Float, default=100.0, nullable=False)
    current_lat: Mapped[float | None] = mapped_column(Float, nullable=True)
    current_lon: Mapped[float | None] = mapped_column(Float, nullable=True)
    current_speed_kmh: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    assigned_driver_id: Mapped[int | None] = mapped_column(Integer, ForeignKey("drivers.id"), nullable=True)
    fleet_name: Mapped[str | None] = mapped_column(String(128), nullable=True, index=True)
    grounded_reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    last_maintenance_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    next_maintenance_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, onupdate=utc_now, nullable=False)
    metadata_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    driver = relationship("Driver", back_populates="assigned_vehicle", foreign_keys=[assigned_driver_id])
    locations = relationship("VehicleLocation", back_populates="vehicle", cascade="all, delete-orphan")
    maintenance_records = relationship("MaintenanceRecord", back_populates="vehicle")
    fuel_events = relationship("FuelEvent", back_populates="vehicle")
    def __repr__(self): return f"<Vehicle id={self.id} plate={self.plate!r} status={self.status}>"

class VehicleLocation(Base):
    __tablename__ = "vehicle_locations"
    __table_args__ = (Index("ix_vloc_vehicle_time", "vehicle_id", "recorded_at"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    vehicle_id: Mapped[int] = mapped_column(Integer, ForeignKey("vehicles.id"), nullable=False, index=True)
    latitude: Mapped[float] = mapped_column(Float, nullable=False)
    longitude: Mapped[float] = mapped_column(Float, nullable=False)
    speed_kmh: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    heading: Mapped[float | None] = mapped_column(Float, nullable=True)
    altitude_m: Mapped[float | None] = mapped_column(Float, nullable=True)
    recorded_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, nullable=False)
    vehicle = relationship("Vehicle", back_populates="locations")
