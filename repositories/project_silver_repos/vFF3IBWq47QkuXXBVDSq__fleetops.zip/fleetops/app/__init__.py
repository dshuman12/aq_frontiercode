"""FleetOps — Logistics fleet management platform."""
__version__ = "0.9.0"
