"""Domain exception hierarchy."""
from __future__ import annotations

class FleetOpsError(Exception):
    def __init__(self, message: str = "An error occurred", code: str = "FLEETOPS_ERROR"):
        self.message = message; self.code = code; super().__init__(self.message)

class NotFoundError(FleetOpsError):
    def __init__(self, resource: str, identifier):
        super().__init__(f"{resource} \'{identifier}\' not found", "NOT_FOUND")
        self.resource = resource; self.identifier = identifier

class DuplicateError(FleetOpsError):
    def __init__(self, resource: str, field: str, value: str):
        super().__init__(f"{resource} with {field}=\'{value}\' already exists", "DUPLICATE")

class InvalidStateError(FleetOpsError):
    def __init__(self, resource: str, current: str, target: str):
        super().__init__(f"Cannot transition {resource} from \'{current}\' to \'{target}\'", "INVALID_TRANSITION")
        self.current_state = current; self.target_state = target

class ValidationError(FleetOpsError):
    def __init__(self, message: str, field: str | None = None):
        super().__init__(message, "VALIDATION_ERROR"); self.field = field

class DriverHoursExceededError(FleetOpsError):
    def __init__(self, driver_id: str, hours: float, limit: float):
        super().__init__(f"Driver \'{driver_id}\' has {hours:.1f}h, limit is {limit:.1f}h", "HOURS_EXCEEDED")

class VehicleGroundedError(FleetOpsError):
    def __init__(self, vehicle_id: str, reason: str):
        super().__init__(f"Vehicle \'{vehicle_id}\' is grounded: {reason}", "VEHICLE_GROUNDED")

class GeofenceViolationError(FleetOpsError):
    def __init__(self, vehicle_id: str, zone_name: str):
        super().__init__(f"Vehicle \'{vehicle_id}\' violated geofence \'{zone_name}\'", "GEOFENCE_VIOLATION")

class MaintenanceOverdueError(FleetOpsError):
    def __init__(self, vehicle_id: str, service_type: str):
        super().__init__(f"Vehicle \'{vehicle_id}\' overdue for {service_type}", "MAINTENANCE_OVERDUE")

class RouteError(FleetOpsError):
    def __init__(self, message: str):
        super().__init__(message, "ROUTE_ERROR")

class DispatchError(FleetOpsError):
    def __init__(self, message: str):
        super().__init__(message, "DISPATCH_ERROR")

class FuelAlertError(FleetOpsError):
    def __init__(self, vehicle_id: str, level_pct: float):
        super().__init__(f"Vehicle \'{vehicle_id}\' fuel at {level_pct:.0f}%", "FUEL_ALERT")

class ComplianceError(FleetOpsError):
    def __init__(self, message: str, violation_type: str = "general"):
        super().__init__(message, "COMPLIANCE_VIOLATION"); self.violation_type = violation_type

class CircuitOpenError(FleetOpsError):
    def __init__(self, target: str):
        super().__init__(f"Circuit breaker open for \'{target}\'", "CIRCUIT_OPEN")

class RateLimitError(FleetOpsError):
    def __init__(self, key: str, limit: int):
        super().__init__(f"Rate limit exceeded for \'{key}\' ({limit}/min)", "RATE_LIMITED")
