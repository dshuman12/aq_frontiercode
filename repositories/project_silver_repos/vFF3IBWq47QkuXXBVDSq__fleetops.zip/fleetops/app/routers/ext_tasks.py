"""API routes for task management."""

from __future__ import annotations

import json
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.database import get_db
from app.schemas.task import (
    TaskCreate, TaskUpdate, TaskResponse, TaskBulkCreate,
    TaskBulkAction, TaskFilter, TaskProgress, TaskResult,
)
from app.schemas.common import PaginatedResponse, SuccessResponse, BulkActionResult
from app.services.task_service import TaskService

router = APIRouter(prefix="/api/v1/tasks", tags=["tasks"])


def _task_to_response(task) -> dict:
    tags = [t.tag for t in task.tags] if task.tags else []
    payload = json.loads(task.payload) if task.payload else None
    result = json.loads(task.result) if task.result else None
    metadata = json.loads(task.metadata_json) if task.metadata_json else None
    queue_name = task.queue.name if task.queue else None
    return {
        **{c.name: getattr(task, c.name) for c in task.__table__.columns},
        "queue_name": queue_name,
        "tags": tags,
        "payload": payload,
        "result": result,
        "metadata": metadata,
    }


@router.post("", response_model=TaskResponse, status_code=201)
def create_task(data: TaskCreate, db: Session = Depends(get_db)):
    svc = TaskService(db)
    task = svc.create(data.model_dump())
    return _task_to_response(task)


@router.get("", response_model=PaginatedResponse[TaskResponse])
def list_tasks(
    status: str | None = None,
    queue_name: str | None = None,
    task_type: str | None = None,
    search: str | None = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
):
    svc = TaskService(db)
    offset = (page - 1) * page_size
    filters = {
        "status": status, "queue_name": queue_name,
        "task_type": task_type, "search": search,
    }
    tasks, total = svc.list_tasks(filters=filters, offset=offset, limit=page_size)
    items = [_task_to_response(t) for t in tasks]
    pages = (total + page_size - 1) // page_size
    return {"items": items, "total": total, "page": page, "page_size": page_size, "pages": pages}


@router.get("/{task_id}", response_model=TaskResponse)
def get_task(task_id: int, db: Session = Depends(get_db)):
    svc = TaskService(db)
    task = svc.get(task_id)
    return _task_to_response(task)


@router.patch("/{task_id}", response_model=TaskResponse)
def update_task(task_id: int, data: TaskUpdate, db: Session = Depends(get_db)):
    svc = TaskService(db)
    task = svc.update(task_id, data.model_dump(exclude_unset=True))
    return _task_to_response(task)


@router.post("/{task_id}/cancel", response_model=TaskResponse)
def cancel_task(task_id: int, db: Session = Depends(get_db)):
    svc = TaskService(db)
    task = svc.cancel(task_id)
    return _task_to_response(task)


@router.post("/{task_id}/retry", response_model=TaskResponse)
def retry_task(task_id: int, db: Session = Depends(get_db)):
    svc = TaskService(db)
    task = svc.retry(task_id)
    return _task_to_response(task)


@router.post("/{task_id}/progress", response_model=TaskResponse)
def update_task_progress(task_id: int, data: TaskProgress, db: Session = Depends(get_db)):
    svc = TaskService(db)
    task = svc.update_progress(task_id, data.progress)
    return _task_to_response(task)


@router.post("/bulk", response_model=BulkActionResult)
def bulk_create_tasks(data: TaskBulkCreate, db: Session = Depends(get_db)):
    svc = TaskService(db)
    tasks = svc.bulk_create(
        [t.model_dump() for t in data.tasks],
        batch_id=data.batch_id,
    )
    return {"total": len(data.tasks), "succeeded": len(tasks), "failed": 0, "errors": []}


@router.post("/bulk-action", response_model=BulkActionResult)
def bulk_task_action(data: TaskBulkAction, db: Session = Depends(get_db)):
    svc = TaskService(db)
    if data.action == "cancel":
        result = svc.bulk_cancel(data.task_ids)
    else:
        result = {"total": 0, "succeeded": 0, "failed": 0, "errors": []}
    return result
