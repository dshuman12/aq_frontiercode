"""API routes for batch task operations."""

from __future__ import annotations

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.database import get_db
from app.schemas.task import TaskCreate
from app.services.batch_service import BatchService

router = APIRouter(prefix="/api/v1/batches", tags=["batches"])


@router.post("")
def create_batch(
    tasks: list[TaskCreate],
    batch_id: str | None = None,
    db: Session = Depends(get_db),
):
    svc = BatchService(db)
    return svc.create_batch([t.model_dump() for t in tasks], batch_id=batch_id)


@router.get("/{batch_id}")
def get_batch_status(batch_id: str, db: Session = Depends(get_db)):
    svc = BatchService(db)
    return svc.get_batch_status(batch_id)


@router.post("/{batch_id}/cancel")
def cancel_batch(batch_id: str, db: Session = Depends(get_db)):
    svc = BatchService(db)
    return svc.cancel_batch(batch_id)


@router.post("/{batch_id}/retry")
def retry_failed_in_batch(batch_id: str, db: Session = Depends(get_db)):
    svc = BatchService(db)
    return svc.retry_failed_in_batch(batch_id)


@router.get("")
def list_batches(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
):
    svc = BatchService(db)
    offset = (page - 1) * page_size
    batches, total = svc.list_batches(offset=offset, limit=page_size)
    pages = (total + page_size - 1) // page_size
    return {"items": batches, "total": total, "page": page, "page_size": page_size, "pages": pages}
