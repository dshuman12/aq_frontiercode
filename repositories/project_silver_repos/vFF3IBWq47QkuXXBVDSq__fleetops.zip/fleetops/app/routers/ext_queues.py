"""API routes for queue management."""

from __future__ import annotations

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.database import get_db
from app.schemas.queue import QueueCreate, QueueUpdate, QueueResponse, QueueStats, QueuePurgeRequest
from app.schemas.common import PaginatedResponse, SuccessResponse
from app.services.queue_service import QueueService

router = APIRouter(prefix="/api/v1/queues", tags=["queues"])


def _queue_to_response(queue, svc: QueueService) -> dict:
    tags = [t.tag for t in queue.tags] if queue.tags else []
    pending = svc.get_pending_count(queue.id)
    running = svc.get_running_count(queue.id)
    return {
        **{c.name: getattr(queue, c.name) for c in queue.__table__.columns},
        "tags": tags,
        "pending_count": pending,
        "running_count": running,
    }


@router.post("", response_model=QueueResponse, status_code=201)
def create_queue(data: QueueCreate, db: Session = Depends(get_db)):
    svc = QueueService(db)
    queue = svc.create(data.model_dump())
    return _queue_to_response(queue, svc)


@router.get("", response_model=PaginatedResponse[QueueResponse])
def list_queues(
    status: str | None = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
):
    svc = QueueService(db)
    offset = (page - 1) * page_size
    queues, total = svc.list_queues(status=status, offset=offset, limit=page_size)
    items = [_queue_to_response(q, svc) for q in queues]
    pages = (total + page_size - 1) // page_size
    return {"items": items, "total": total, "page": page, "page_size": page_size, "pages": pages}


@router.get("/{queue_id}", response_model=QueueResponse)
def get_queue(queue_id: int, db: Session = Depends(get_db)):
    svc = QueueService(db)
    queue = svc.get(queue_id)
    return _queue_to_response(queue, svc)


@router.patch("/{queue_id}", response_model=QueueResponse)
def update_queue(queue_id: int, data: QueueUpdate, db: Session = Depends(get_db)):
    svc = QueueService(db)
    queue = svc.update(queue_id, data.model_dump(exclude_unset=True))
    return _queue_to_response(queue, svc)


@router.delete("/{queue_id}", response_model=SuccessResponse)
def delete_queue(queue_id: int, db: Session = Depends(get_db)):
    svc = QueueService(db)
    svc.delete(queue_id)
    return {"success": True, "message": f"Queue {queue_id} deleted"}


@router.post("/{queue_id}/pause", response_model=QueueResponse)
def pause_queue(queue_id: int, db: Session = Depends(get_db)):
    svc = QueueService(db)
    queue = svc.transition_status(queue_id, "paused")
    return _queue_to_response(queue, svc)


@router.post("/{queue_id}/resume", response_model=QueueResponse)
def resume_queue(queue_id: int, db: Session = Depends(get_db)):
    svc = QueueService(db)
    queue = svc.transition_status(queue_id, "active")
    return _queue_to_response(queue, svc)


@router.get("/{queue_id}/stats", response_model=QueueStats)
def get_queue_stats(queue_id: int, db: Session = Depends(get_db)):
    svc = QueueService(db)
    return svc.get_stats(queue_id)


@router.post("/{queue_id}/purge", response_model=SuccessResponse)
def purge_queue(queue_id: int, data: QueuePurgeRequest, db: Session = Depends(get_db)):
    svc = QueueService(db)
    count = svc.purge(queue_id, data.statuses, data.older_than_hours, data.dry_run)
    verb = "would purge" if data.dry_run else "purged"
    return {"success": True, "message": f"{verb} {count} tasks"}
