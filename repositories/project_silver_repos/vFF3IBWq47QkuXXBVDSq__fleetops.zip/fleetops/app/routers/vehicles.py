from __future__ import annotations
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from app.database import get_db
from app.schemas.vehicle import VehicleCreate, VehicleUpdate, VehicleResponse
from app.schemas.common import PaginatedResponse, SuccessResponse
from app.services.vehicle_service import VehicleService
router = APIRouter(prefix="/api/v1/vehicles", tags=["vehicles"])
@router.post("", response_model=VehicleResponse, status_code=201)
def create_vehicle(data: VehicleCreate, db: Session = Depends(get_db)):
    return VehicleService(db).create(data.model_dump())
@router.get("")
def list_vehicles(status: str | None = None, fleet: str | None = None, page: int = Query(1, ge=1), page_size: int = Query(20), db: Session = Depends(get_db)):
    svc = VehicleService(db); offset = (page - 1) * page_size
    items, total = svc.list_vehicles(status=status, fleet=fleet, offset=offset, limit=page_size)
    return {"items": items, "total": total, "page": page, "page_size": page_size, "pages": (total+page_size-1)//page_size}
@router.get("/{vid}", response_model=VehicleResponse)
def get_vehicle(vid: int, db: Session = Depends(get_db)):
    return VehicleService(db).get(vid)
@router.post("/{vid}/status", response_model=VehicleResponse)
def change_status(vid: int, new_status: str, reason: str | None = None, db: Session = Depends(get_db)):
    return VehicleService(db).transition_status(vid, new_status, reason)
@router.delete("/{vid}", response_model=SuccessResponse)
def delete_vehicle(vid: int, db: Session = Depends(get_db)):
    VehicleService(db).delete(vid); return {"success": True, "message": f"Vehicle {vid} deleted"}
