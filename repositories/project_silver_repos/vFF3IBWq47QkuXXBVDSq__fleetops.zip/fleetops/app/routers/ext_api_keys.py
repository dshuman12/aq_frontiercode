"""API routes for API key management."""

from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.api_key import ApiKey
from app.utils.security import generate_api_key, hash_api_key, obfuscate_key
from app.utils.date_utils import utc_now
from app.schemas.common import SuccessResponse

router = APIRouter(prefix="/api/v1/api-keys", tags=["api-keys"])


@router.post("", status_code=201)
def create_api_key(
    name: str,
    owner: str,
    scopes: str | None = None,
    rate_limit: int = 100,
    db: Session = Depends(get_db),
):
    raw_key = generate_api_key()
    key_hash = hash_api_key(raw_key)
    api_key = ApiKey(
        name=name,
        key_hash=key_hash,
        key_prefix=raw_key[:12],
        owner=owner,
        scopes=scopes,
        rate_limit=rate_limit,
    )
    db.add(api_key)
    db.commit()
    db.refresh(api_key)
    return {
        "id": api_key.id,
        "name": api_key.name,
        "key": raw_key,
        "key_prefix": api_key.key_prefix,
        "owner": api_key.owner,
        "created_at": api_key.created_at,
    }


@router.get("")
def list_api_keys(db: Session = Depends(get_db)):
    keys = db.query(ApiKey).order_by(ApiKey.created_at.desc()).all()
    return [
        {
            "id": k.id,
            "name": k.name,
            "key_prefix": k.key_prefix,
            "owner": k.owner,
            "enabled": k.enabled,
            "is_active": k.is_active,
            "last_used_at": k.last_used_at,
            "usage_count": k.usage_count,
            "created_at": k.created_at,
        }
        for k in keys
    ]


@router.delete("/{key_id}", response_model=SuccessResponse)
def revoke_api_key(key_id: int, db: Session = Depends(get_db)):
    key = db.query(ApiKey).filter(ApiKey.id == key_id).first()
    if not key:
        return {"success": False, "message": "Key not found"}
    key.enabled = False
    key.revoked_at = utc_now()
    db.commit()
    return {"success": True, "message": f"API key {key_id} revoked"}
