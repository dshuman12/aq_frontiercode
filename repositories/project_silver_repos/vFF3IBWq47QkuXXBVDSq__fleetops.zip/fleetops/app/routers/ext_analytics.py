"""API routes for analytics and dashboard data."""

from __future__ import annotations

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.database import get_db
from app.services.analytics_service import AnalyticsService

router = APIRouter(prefix="/api/v1/analytics", tags=["analytics"])


@router.get("/dashboard")
def get_dashboard(db: Session = Depends(get_db)):
    svc = AnalyticsService(db)
    return svc.get_dashboard_summary()


@router.get("/tasks/breakdown")
def get_task_breakdown(db: Session = Depends(get_db)):
    svc = AnalyticsService(db)
    return svc.get_task_status_breakdown()


@router.get("/tasks/trends")
def get_task_trends(days: int = Query(7, ge=1, le=90), db: Session = Depends(get_db)):
    svc = AnalyticsService(db)
    return svc.get_task_trends(days)


@router.get("/errors")
def get_error_breakdown(limit: int = Query(10, ge=1, le=100), db: Session = Depends(get_db)):
    svc = AnalyticsService(db)
    return svc.get_error_breakdown(limit)


@router.get("/queues/{queue_name}/throughput")
def get_queue_throughput(
    queue_name: str, hours: int = Query(24, ge=1, le=168), db: Session = Depends(get_db)
):
    svc = AnalyticsService(db)
    return svc.get_queue_throughput(queue_name, hours)


@router.get("/pipelines")
def get_pipeline_analytics(db: Session = Depends(get_db)):
    svc = AnalyticsService(db)
    return svc.get_pipeline_analytics()
