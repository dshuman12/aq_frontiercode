"""API routes for Worker management."""

from __future__ import annotations

import json
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.database import get_db
from app.schemas.worker import WorkerRegister, WorkerHeartbeat, WorkerResponse, WorkerStats
from app.schemas.common import PaginatedResponse, SuccessResponse
from app.services.worker_service import WorkerService

router = APIRouter(prefix="/workers", tags=["workers"])


def _worker_to_response(worker) -> dict:
    queue_names = []
    if worker.queue_names:
        try:
            queue_names = json.loads(worker.queue_names)
        except (json.JSONDecodeError, TypeError):
            pass
    capabilities = [c.capability for c in worker.capabilities] if worker.capabilities else []
    return {
        "id": worker.id,
        "worker_id": worker.worker_id,
        "hostname": worker.hostname,
        "pid": worker.pid,
        "status": worker.status if isinstance(worker.status, str) else worker.status.value,
        "concurrency": worker.concurrency,
        "current_tasks": worker.current_tasks,
        "tasks_completed": worker.tasks_completed,
        "tasks_failed": worker.tasks_failed,
        "cpu_usage": worker.cpu_usage,
        "memory_usage": worker.memory_usage,
        "disk_usage": worker.disk_usage,
        "version": worker.version,
        "queue_names": queue_names,
        "capabilities": capabilities,
        "started_at": worker.started_at,
        "last_heartbeat": worker.last_heartbeat,
        "stopped_at": worker.stopped_at,
    }


@router.post("/register", response_model=WorkerResponse, status_code=201)
def register_worker(body: WorkerRegister, db: Session = Depends(get_db)):
    svc = WorkerService(db)
    worker = svc.register(body.model_dump())
    return _worker_to_response(worker)


@router.get("", response_model=PaginatedResponse[WorkerResponse])
def list_workers(
    status: str | None = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
):
    svc = WorkerService(db)
    offset = (page - 1) * page_size
    workers, total = svc.list_workers(status=status, offset=offset, limit=page_size)
    items = [_worker_to_response(w) for w in workers]
    pages = (total + page_size - 1) // page_size
    return {"items": items, "total": total, "page": page, "page_size": page_size, "pages": pages}


@router.get("/stats", response_model=WorkerStats)
def get_worker_stats(db: Session = Depends(get_db)):
    svc = WorkerService(db)
    return svc.get_stats()


@router.get("/{worker_id}", response_model=WorkerResponse)
def get_worker(worker_id: int, db: Session = Depends(get_db)):
    svc = WorkerService(db)
    worker = svc.get(worker_id)
    return _worker_to_response(worker)


@router.post("/{worker_id_str}/heartbeat", response_model=WorkerResponse)
def worker_heartbeat(worker_id_str: str, body: WorkerHeartbeat, db: Session = Depends(get_db)):
    svc = WorkerService(db)
    worker = svc.heartbeat(worker_id_str, body.model_dump())
    return _worker_to_response(worker)


@router.post("/{worker_id_str}/deregister", response_model=WorkerResponse)
def deregister_worker(worker_id_str: str, db: Session = Depends(get_db)):
    svc = WorkerService(db)
    worker = svc.deregister(worker_id_str)
    return _worker_to_response(worker)


@router.delete("/{worker_id}", response_model=SuccessResponse)
def delete_worker(worker_id: int, db: Session = Depends(get_db)):
    svc = WorkerService(db)
    svc.delete(worker_id)
    return {"success": True, "message": f"Worker {worker_id} deleted"}
