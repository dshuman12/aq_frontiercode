"""API routes for pipeline management."""

from __future__ import annotations

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.database import get_db
from app.schemas.pipeline import (
    PipelineCreate, PipelineUpdate, PipelineResponse,
    PipelineRunCreate, PipelineRunResponse,
)
from app.schemas.common import PaginatedResponse, SuccessResponse
from app.services.pipeline_service import PipelineService

router = APIRouter(prefix="/api/v1/pipelines", tags=["pipelines"])


@router.post("", response_model=PipelineResponse, status_code=201)
def create_pipeline(data: PipelineCreate, db: Session = Depends(get_db)):
    svc = PipelineService(db)
    return svc.create(data.model_dump())


@router.get("", response_model=PaginatedResponse[PipelineResponse])
def list_pipelines(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
):
    svc = PipelineService(db)
    offset = (page - 1) * page_size
    pipelines, total = svc.list_pipelines(offset=offset, limit=page_size)
    pages = (total + page_size - 1) // page_size
    return {"items": pipelines, "total": total, "page": page, "page_size": page_size, "pages": pages}


@router.get("/{pipeline_id}", response_model=PipelineResponse)
def get_pipeline(pipeline_id: int, db: Session = Depends(get_db)):
    svc = PipelineService(db)
    return svc.get(pipeline_id)


@router.patch("/{pipeline_id}", response_model=PipelineResponse)
def update_pipeline(pipeline_id: int, data: PipelineUpdate, db: Session = Depends(get_db)):
    svc = PipelineService(db)
    return svc.update(pipeline_id, data.model_dump(exclude_unset=True))


@router.delete("/{pipeline_id}", response_model=SuccessResponse)
def delete_pipeline(pipeline_id: int, db: Session = Depends(get_db)):
    svc = PipelineService(db)
    svc.delete(pipeline_id)
    return {"success": True, "message": f"Pipeline {pipeline_id} deleted"}


@router.post("/{pipeline_id}/run", response_model=PipelineRunResponse, status_code=201)
def start_pipeline_run(pipeline_id: int, data: PipelineRunCreate, db: Session = Depends(get_db)):
    svc = PipelineService(db)
    return svc.start_run(pipeline_id, data.model_dump())


@router.get("/runs/{run_id}", response_model=PipelineRunResponse)
def get_pipeline_run(run_id: int, db: Session = Depends(get_db)):
    svc = PipelineService(db)
    return svc.get_run(run_id)


@router.post("/runs/{run_id}/cancel", response_model=PipelineRunResponse)
def cancel_pipeline_run(run_id: int, db: Session = Depends(get_db)):
    svc = PipelineService(db)
    return svc.cancel_run(run_id)
