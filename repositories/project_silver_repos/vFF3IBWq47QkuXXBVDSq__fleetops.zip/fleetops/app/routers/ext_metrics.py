"""API routes for system metrics."""

from __future__ import annotations

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.database import get_db
from app.services.metrics_service import MetricsService

router = APIRouter(prefix="/api/v1/metrics", tags=["metrics"])


@router.post("")
def record_metric(
    metric_name: str,
    value: float,
    labels: dict | None = None,
    db: Session = Depends(get_db),
):
    svc = MetricsService(db)
    snapshot = svc.record(metric_name, value, labels)
    return {
        "id": snapshot.id,
        "metric_name": snapshot.metric_name,
        "value": snapshot.metric_value,
        "recorded_at": snapshot.recorded_at.isoformat() if snapshot.recorded_at else None,
    }


@router.get("")
def list_metrics(db: Session = Depends(get_db)):
    svc = MetricsService(db)
    return {"metrics": svc.list_metrics()}


@router.get("/{metric_name}")
def query_metric(
    metric_name: str,
    hours: int = Query(24, ge=1, le=720),
    aggregation: str = Query("avg"),
    db: Session = Depends(get_db),
):
    svc = MetricsService(db)
    return svc.query(metric_name, hours=hours, aggregation=aggregation)


@router.get("/{metric_name}/latest")
def get_latest_metric(metric_name: str, db: Session = Depends(get_db)):
    svc = MetricsService(db)
    value = svc.get_latest(metric_name)
    return {"metric_name": metric_name, "value": value}


@router.get("/{metric_name}/series")
def get_time_series(
    metric_name: str,
    hours: int = Query(24, ge=1),
    bucket_minutes: int = Query(60, ge=1),
    db: Session = Depends(get_db),
):
    svc = MetricsService(db)
    return svc.get_time_series(metric_name, hours=hours, bucket_minutes=bucket_minutes)
