from __future__ import annotations
from datetime import datetime
from fastapi import APIRouter, Depends
from sqlalchemy import text
from sqlalchemy.orm import Session
from app import __version__
from app.database import get_db
router = APIRouter(tags=["health"])
@router.get("/health")
def health(db: Session = Depends(get_db)):
    try: db.execute(text("SELECT 1")); st = "connected"
    except: st = "disconnected"
    return {"status": "healthy" if st == "connected" else "degraded",
        "version": __version__, "database": st, "timestamp": datetime.utcnow().isoformat()}
