"""API routes for reports and data export."""

from __future__ import annotations

from fastapi import APIRouter, Depends, Query
from fastapi.responses import PlainTextResponse
from sqlalchemy.orm import Session

from app.database import get_db
from app.services.report_service import ReportService

router = APIRouter(prefix="/api/v1/reports", tags=["reports"])


@router.get("/daily")
def daily_report(db: Session = Depends(get_db)):
    svc = ReportService(db)
    return svc.daily_summary()


@router.get("/queues")
def queue_report(db: Session = Depends(get_db)):
    svc = ReportService(db)
    return svc.queue_report()


@router.get("/workers")
def worker_report(db: Session = Depends(get_db)):
    svc = ReportService(db)
    return svc.worker_report()


@router.get("/export/tasks", response_class=PlainTextResponse)
def export_tasks(
    status: str | None = None,
    queue_name: str | None = None,
    limit: int = Query(1000, ge=1, le=10000),
    db: Session = Depends(get_db),
):
    svc = ReportService(db)
    csv = svc.export_tasks_csv(status=status, queue_name=queue_name, limit=limit)
    return PlainTextResponse(content=csv, media_type="text/csv")


@router.get("/export/queues", response_class=PlainTextResponse)
def export_queues(db: Session = Depends(get_db)):
    svc = ReportService(db)
    csv = svc.export_queues_csv()
    return PlainTextResponse(content=csv, media_type="text/csv")
