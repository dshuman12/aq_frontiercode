"""API routes for dead letter queue management."""

from __future__ import annotations

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.database import get_db
from app.services.dlq_service import DeadLetterService
from app.schemas.common import SuccessResponse

router = APIRouter(prefix="/api/v1/dlq", tags=["dead-letter-queue"])


@router.get("")
def list_entries(
    queue_name: str | None = None,
    task_type: str | None = None,
    resolved: bool | None = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
):
    svc = DeadLetterService(db)
    offset = (page - 1) * page_size
    entries, total = svc.list_entries(
        queue_name=queue_name,
        task_type=task_type,
        resolved=resolved,
        offset=offset,
        limit=page_size,
    )
    pages = (total + page_size - 1) // page_size
    items = [
        {
            "id": e.id,
            "original_task_id": e.original_task_id,
            "queue_name": e.queue_name,
            "task_name": e.task_name,
            "task_type": e.task_type,
            "error_message": e.error_message,
            "error_count": e.error_count,
            "first_failed_at": e.first_failed_at.isoformat() if e.first_failed_at else None,
            "last_failed_at": e.last_failed_at.isoformat() if e.last_failed_at else None,
            "resolution": e.resolution,
            "resolved_at": e.resolved_at.isoformat() if e.resolved_at else None,
        }
        for e in entries
    ]
    return {"items": items, "total": total, "page": page, "page_size": page_size, "pages": pages}


@router.get("/stats")
def get_dlq_stats(db: Session = Depends(get_db)):
    svc = DeadLetterService(db)
    return svc.get_stats()


@router.get("/{entry_id}")
def get_entry(entry_id: int, db: Session = Depends(get_db)):
    svc = DeadLetterService(db)
    entry = svc.get(entry_id)
    if not entry:
        return {"error": "Entry not found"}
    return {
        "id": entry.id,
        "original_task_id": entry.original_task_id,
        "queue_name": entry.queue_name,
        "task_name": entry.task_name,
        "task_type": entry.task_type,
        "payload": entry.payload,
        "error_message": entry.error_message,
        "error_traceback": entry.error_traceback,
        "error_count": entry.error_count,
        "resolution": entry.resolution,
        "notes": entry.notes,
    }


@router.post("/{entry_id}/resolve", response_model=SuccessResponse)
def resolve_entry(
    entry_id: int,
    resolution: str,
    resolved_by: str | None = None,
    notes: str | None = None,
    db: Session = Depends(get_db),
):
    svc = DeadLetterService(db)
    entry = svc.resolve(entry_id, resolution, resolved_by, notes)
    if not entry:
        return {"success": False, "message": "Entry not found"}
    return {"success": True, "message": f"Entry {entry_id} resolved"}


@router.post("/{entry_id}/requeue", response_model=SuccessResponse)
def requeue_entry(entry_id: int, db: Session = Depends(get_db)):
    svc = DeadLetterService(db)
    entry = svc.mark_requeued(entry_id)
    if not entry:
        return {"success": False, "message": "Entry not found"}
    return {"success": True, "message": f"Entry {entry_id} marked for requeue"}


@router.delete("/purge", response_model=SuccessResponse)
def purge_resolved(
    older_than_days: int = Query(30, ge=1),
    db: Session = Depends(get_db),
):
    svc = DeadLetterService(db)
    count = svc.purge_resolved(older_than_days)
    return {"success": True, "message": f"Purged {count} resolved entries"}
