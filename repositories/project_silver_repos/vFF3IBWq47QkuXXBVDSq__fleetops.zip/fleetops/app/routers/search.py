from __future__ import annotations
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from app.database import get_db
from app.services.search_service import SearchService
router = APIRouter(prefix="/api/v1/search", tags=["search"])
@router.get("")
def search(q: str = Query(..., min_length=1), db: Session = Depends(get_db)):
    return SearchService(db).global_search(q)
