"""API routes for search functionality."""

from __future__ import annotations

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.database import get_db
from app.services.search_service import SearchService

router = APIRouter(prefix="/api/v1/search", tags=["search"])


@router.get("")
def global_search(
    q: str = Query(..., min_length=1),
    limit: int = Query(10, ge=1, le=50),
    db: Session = Depends(get_db),
):
    svc = SearchService(db)
    return svc.global_search(q, limit=limit)


@router.get("/tasks")
def search_tasks(
    q: str = Query(..., min_length=1),
    status: str | None = None,
    queue_name: str | None = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
):
    svc = SearchService(db)
    offset = (page - 1) * page_size
    tasks, total = svc.search_tasks(q, status=status, queue_name=queue_name, offset=offset, limit=page_size)
    return {"items": [{"id": t.id, "name": t.name, "status": t.status} for t in tasks], "total": total}


@router.get("/queues")
def search_queues(
    q: str = Query(..., min_length=1),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
):
    svc = SearchService(db)
    offset = (page - 1) * page_size
    queues, total = svc.search_queues(q, offset=offset, limit=page_size)
    return {"items": [{"id": q.id, "name": q.name, "status": q.status} for q in queues], "total": total}


@router.get("/tags/{tag}")
def search_by_tag(
    tag: str,
    entity_type: str = Query("task"),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
):
    svc = SearchService(db)
    offset = (page - 1) * page_size
    items, total = svc.search_by_tag(tag, entity_type=entity_type, offset=offset, limit=page_size)
    return {"items": [{"id": i.id, "name": getattr(i, "name", "?")} for i in items], "total": total}
