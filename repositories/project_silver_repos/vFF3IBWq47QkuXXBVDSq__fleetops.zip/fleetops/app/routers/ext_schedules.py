"""API routes for schedule management."""

from __future__ import annotations

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.database import get_db
from app.schemas.schedule import ScheduleCreate, ScheduleUpdate, ScheduleResponse, ScheduleRunResponse
from app.schemas.common import PaginatedResponse, SuccessResponse
from app.services.schedule_service import ScheduleService

router = APIRouter(prefix="/api/v1/schedules", tags=["schedules"])


@router.post("", response_model=ScheduleResponse, status_code=201)
def create_schedule(data: ScheduleCreate, db: Session = Depends(get_db)):
    svc = ScheduleService(db)
    schedule = svc.create(data.model_dump())
    return schedule


@router.get("", response_model=PaginatedResponse[ScheduleResponse])
def list_schedules(
    status: str | None = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
):
    svc = ScheduleService(db)
    offset = (page - 1) * page_size
    schedules, total = svc.list_schedules(status=status, offset=offset, limit=page_size)
    pages = (total + page_size - 1) // page_size
    return {"items": schedules, "total": total, "page": page, "page_size": page_size, "pages": pages}


@router.get("/{schedule_id}", response_model=ScheduleResponse)
def get_schedule(schedule_id: int, db: Session = Depends(get_db)):
    svc = ScheduleService(db)
    return svc.get(schedule_id)


@router.patch("/{schedule_id}", response_model=ScheduleResponse)
def update_schedule(schedule_id: int, data: ScheduleUpdate, db: Session = Depends(get_db)):
    svc = ScheduleService(db)
    return svc.update(schedule_id, data.model_dump(exclude_unset=True))


@router.delete("/{schedule_id}", response_model=SuccessResponse)
def delete_schedule(schedule_id: int, db: Session = Depends(get_db)):
    svc = ScheduleService(db)
    svc.delete(schedule_id)
    return {"success": True, "message": f"Schedule {schedule_id} deleted"}


@router.post("/{schedule_id}/enable", response_model=ScheduleResponse)
def enable_schedule(schedule_id: int, db: Session = Depends(get_db)):
    svc = ScheduleService(db)
    return svc.enable(schedule_id)


@router.post("/{schedule_id}/disable", response_model=ScheduleResponse)
def disable_schedule(schedule_id: int, db: Session = Depends(get_db)):
    svc = ScheduleService(db)
    return svc.disable(schedule_id)


@router.post("/{schedule_id}/pause", response_model=ScheduleResponse)
def pause_schedule(schedule_id: int, db: Session = Depends(get_db)):
    svc = ScheduleService(db)
    return svc.pause(schedule_id)


@router.get("/{schedule_id}/runs", response_model=PaginatedResponse[ScheduleRunResponse])
def get_schedule_runs(
    schedule_id: int,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
):
    svc = ScheduleService(db)
    offset = (page - 1) * page_size
    runs, total = svc.get_runs(schedule_id, offset=offset, limit=page_size)
    pages = (total + page_size - 1) // page_size
    return {"items": runs, "total": total, "page": page, "page_size": page_size, "pages": pages}
