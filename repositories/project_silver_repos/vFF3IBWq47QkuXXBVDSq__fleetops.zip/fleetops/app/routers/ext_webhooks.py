"""API routes for webhook management."""

from __future__ import annotations

import json
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.database import get_db
from app.schemas.webhook import (
    WebhookCreate, WebhookUpdate, WebhookResponse,
    WebhookDeliveryResponse, WebhookTestRequest,
)
from app.schemas.common import PaginatedResponse, SuccessResponse
from app.services.webhook_service import WebhookService

router = APIRouter(prefix="/api/v1/webhooks", tags=["webhooks"])


def _webhook_to_response(webhook) -> dict:
    events = json.loads(webhook.events) if webhook.events else []
    return {
        **{c.name: getattr(webhook, c.name) for c in webhook.__table__.columns},
        "events": events,
    }


@router.post("", response_model=WebhookResponse, status_code=201)
def create_webhook(data: WebhookCreate, db: Session = Depends(get_db)):
    svc = WebhookService(db)
    webhook = svc.create(data.model_dump())
    return _webhook_to_response(webhook)


@router.get("", response_model=PaginatedResponse[WebhookResponse])
def list_webhooks(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
):
    svc = WebhookService(db)
    offset = (page - 1) * page_size
    webhooks, total = svc.list_webhooks(offset=offset, limit=page_size)
    items = [_webhook_to_response(wh) for wh in webhooks]
    pages = (total + page_size - 1) // page_size
    return {"items": items, "total": total, "page": page, "page_size": page_size, "pages": pages}


@router.get("/{webhook_id}", response_model=WebhookResponse)
def get_webhook(webhook_id: int, db: Session = Depends(get_db)):
    svc = WebhookService(db)
    return _webhook_to_response(svc.get(webhook_id))


@router.patch("/{webhook_id}", response_model=WebhookResponse)
def update_webhook(webhook_id: int, data: WebhookUpdate, db: Session = Depends(get_db)):
    svc = WebhookService(db)
    webhook = svc.update(webhook_id, data.model_dump(exclude_unset=True))
    return _webhook_to_response(webhook)


@router.delete("/{webhook_id}", response_model=SuccessResponse)
def delete_webhook(webhook_id: int, db: Session = Depends(get_db)):
    svc = WebhookService(db)
    svc.delete(webhook_id)
    return {"success": True, "message": f"Webhook {webhook_id} deleted"}


@router.post("/{webhook_id}/enable", response_model=WebhookResponse)
def enable_webhook(webhook_id: int, db: Session = Depends(get_db)):
    svc = WebhookService(db)
    return _webhook_to_response(svc.enable(webhook_id))


@router.post("/{webhook_id}/disable", response_model=WebhookResponse)
def disable_webhook(webhook_id: int, db: Session = Depends(get_db)):
    svc = WebhookService(db)
    return _webhook_to_response(svc.disable(webhook_id))


@router.post("/{webhook_id}/rotate-secret", response_model=WebhookResponse)
def rotate_webhook_secret(webhook_id: int, db: Session = Depends(get_db)):
    svc = WebhookService(db)
    return _webhook_to_response(svc.rotate_secret(webhook_id))


@router.get("/{webhook_id}/deliveries", response_model=PaginatedResponse[WebhookDeliveryResponse])
def get_webhook_deliveries(
    webhook_id: int,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
):
    svc = WebhookService(db)
    offset = (page - 1) * page_size
    deliveries, total = svc.get_deliveries(webhook_id, offset=offset, limit=page_size)
    pages = (total + page_size - 1) // page_size
    return {"items": deliveries, "total": total, "page": page, "page_size": page_size, "pages": pages}


@router.post("/{webhook_id}/test", response_model=SuccessResponse)
def test_webhook(webhook_id: int, data: WebhookTestRequest, db: Session = Depends(get_db)):
    svc = WebhookService(db)
    svc.fire_event(data.event, data.payload or {"test": True})
    return {"success": True, "message": "Test webhook delivered"}
