from __future__ import annotations
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import get_db
from app.services.analytics_service import AnalyticsService
router = APIRouter(prefix="/api/v1/analytics", tags=["analytics"])
@router.get("/dashboard")
def dashboard(db: Session = Depends(get_db)):
    return AnalyticsService(db).get_dashboard()
