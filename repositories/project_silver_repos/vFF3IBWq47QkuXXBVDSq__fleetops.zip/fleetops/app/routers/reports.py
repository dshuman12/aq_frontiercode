from __future__ import annotations
from fastapi import APIRouter, Depends
from fastapi.responses import PlainTextResponse
from sqlalchemy.orm import Session
from app.database import get_db
from app.services.report_service import ReportService
router = APIRouter(prefix="/api/v1/reports", tags=["reports"])
@router.get("/fleet")
def fleet_summary(db: Session = Depends(get_db)):
    return ReportService(db).fleet_summary()
