from __future__ import annotations
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from app.database import get_db
from app.schemas.driver import DriverCreate, DriverResponse
from app.services.driver_service import DriverService
router = APIRouter(prefix="/api/v1/drivers", tags=["drivers"])
@router.post("", response_model=DriverResponse, status_code=201)
def create_driver(data: DriverCreate, db: Session = Depends(get_db)):
    return DriverService(db).create(data.model_dump())
@router.get("/{did}", response_model=DriverResponse)
def get_driver(did: int, db: Session = Depends(get_db)):
    return DriverService(db).get(did)
@router.post("/{did}/status", response_model=DriverResponse)
def change_status(did: int, new_status: str, db: Session = Depends(get_db)):
    return DriverService(db).transition_status(did, new_status)
