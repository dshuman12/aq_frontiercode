from __future__ import annotations
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from app.exceptions import FleetOpsError, NotFoundError, DuplicateError, InvalidStateError, ValidationError

def register_error_handlers(app: FastAPI) -> None:
    @app.exception_handler(NotFoundError)
    async def not_found(r: Request, e: NotFoundError):
        return JSONResponse(status_code=404, content={"error": e.message, "code": e.code})
    @app.exception_handler(DuplicateError)
    async def dup(r: Request, e: DuplicateError):
        return JSONResponse(status_code=409, content={"error": e.message, "code": e.code})
    @app.exception_handler(InvalidStateError)
    async def inv(r: Request, e: InvalidStateError):
        return JSONResponse(status_code=422, content={"error": e.message, "code": e.code})
    @app.exception_handler(ValidationError)
    async def val(r: Request, e: ValidationError):
        return JSONResponse(status_code=400, content={"error": e.message, "code": e.code})
    @app.exception_handler(FleetOpsError)
    async def gen(r: Request, e: FleetOpsError):
        return JSONResponse(status_code=500, content={"error": e.message, "code": e.code})
