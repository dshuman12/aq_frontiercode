from __future__ import annotations
import time, logging
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response
logger = logging.getLogger("fleetops.requests")
class RequestLoggingMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next) -> Response:
        start = time.monotonic()
        response = await call_next(request)
        logger.info("%s %s %s %.1fms", request.method, request.url.path, response.status_code, (time.monotonic() - start) * 1000)
        return response
