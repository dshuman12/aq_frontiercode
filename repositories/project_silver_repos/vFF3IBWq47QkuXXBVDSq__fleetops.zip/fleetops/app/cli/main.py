"""FleetOps CLI."""
from __future__ import annotations
import argparse, sys, json
from app.database import SessionLocal, init_db
from app.services.analytics_service import AnalyticsService

def cmd_init_db(args): init_db(); print("Database initialized.")
def cmd_dashboard(args):
    db = SessionLocal()
    print(json.dumps(AnalyticsService(db).get_dashboard(), indent=2, default=str))
    db.close()

def main():
    parser = argparse.ArgumentParser(prog="fleetops")
    sub = parser.add_subparsers(dest="command")
    sub.add_parser("init-db"); sub.add_parser("dashboard")
    args = parser.parse_args()
    cmds = {"init-db": cmd_init_db, "dashboard": cmd_dashboard}
    if args.command in cmds: cmds[args.command](args)
    else: parser.print_help(); sys.exit(1)

if __name__ == "__main__": main()
