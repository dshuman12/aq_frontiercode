from __future__ import annotations
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app import __version__
from app.config import settings
from app.middleware.error_handlers import register_error_handlers
from app.middleware.request_logging import RequestLoggingMiddleware
from app.routers import health, vehicles, drivers, analytics, search, reports

def create_app() -> FastAPI:
    application = FastAPI(title="FleetOps", version=__version__)
    origins = [o.strip() for o in settings.cors_origins.split(",") if o.strip()]
    application.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
    application.add_middleware(RequestLoggingMiddleware)
    register_error_handlers(application)
    for r in [health, vehicles, drivers, analytics, search, reports]:
        application.include_router(r.router)
    return application

app = create_app()
