"""CSV export helpers."""
from __future__ import annotations

import csv
import io
from datetime import datetime
from typing import Any


def workflows_to_csv(workflows: list[dict[str, Any]]) -> str:
    if not workflows:
        return ""
    fields = ["id", "name", "status", "step_count", "created_at"]
    out = io.StringIO()
    writer = csv.DictWriter(out, fieldnames=fields, extrasaction="ignore")
    writer.writeheader()
    for w in workflows:
        row = {}
        for f in fields:
            val = w.get(f, "")
            if isinstance(val, datetime):
                val = val.isoformat()
            row[f] = val
        writer.writerow(row)
    return out.getvalue()


def events_to_csv(events: list[dict[str, Any]]) -> str:
    if not events:
        return ""
    fields = ["event_id", "event_type", "status", "channel", "created_at"]
    out = io.StringIO()
    writer = csv.DictWriter(out, fieldnames=fields, extrasaction="ignore")
    writer.writeheader()
    for e in events:
        row = {}
        for f in fields:
            val = e.get(f, "")
            if isinstance(val, datetime):
                val = val.isoformat()
            row[f] = val
        writer.writerow(row)
    return out.getvalue()


def runs_to_csv(runs: list[dict[str, Any]]) -> str:
    if not runs:
        return ""
    fields = ["run_id", "workflow_name", "status", "started_at", "completed_at", "duration_seconds"]
    out = io.StringIO()
    writer = csv.DictWriter(out, fieldnames=fields, extrasaction="ignore")
    writer.writeheader()
    for r in runs:
        row = {f: r.get(f, "") for f in fields}
        writer.writerow(row)
    return out.getvalue()


def parse_csv_header(csv_string: str) -> list[str]:
    reader = csv.reader(io.StringIO(csv_string))
    try:
        return [h.strip() for h in next(reader) if h.strip()]
    except StopIteration:
        return []
