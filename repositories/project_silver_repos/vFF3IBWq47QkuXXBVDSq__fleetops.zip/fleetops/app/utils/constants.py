"""Constants, enums, and state machines for FleetOps."""
from __future__ import annotations
from enum import Enum

class VehicleStatus(str, Enum):
    AVAILABLE = "available"
    IN_SERVICE = "in_service"
    EN_ROUTE = "en_route"
    MAINTENANCE = "maintenance"
    GROUNDED = "grounded"
    DECOMMISSIONED = "decommissioned"

class VehicleType(str, Enum):
    TRUCK = "truck"; VAN = "van"; SEDAN = "sedan"; SUV = "suv"
    MOTORCYCLE = "motorcycle"; TRAILER = "trailer"

class DriverStatus(str, Enum):
    AVAILABLE = "available"; ON_DUTY = "on_duty"; DRIVING = "driving"
    RESTING = "resting"; OFF_DUTY = "off_duty"; SUSPENDED = "suspended"
    TERMINATED = "terminated"

class RouteStatus(str, Enum):
    DRAFT = "draft"; PLANNED = "planned"; DISPATCHED = "dispatched"
    IN_PROGRESS = "in_progress"; COMPLETED = "completed"
    CANCELLED = "cancelled"; FAILED = "failed"

class StopStatus(str, Enum):
    PENDING = "pending"; ARRIVED = "arrived"; LOADING = "loading"
    UNLOADING = "unloading"; COMPLETED = "completed"
    SKIPPED = "skipped"; FAILED = "failed"

class MaintenanceType(str, Enum):
    OIL_CHANGE = "oil_change"; TIRE_ROTATION = "tire_rotation"
    BRAKE_INSPECTION = "brake_inspection"; ENGINE_SERVICE = "engine_service"
    TRANSMISSION = "transmission"; BATTERY = "battery"
    GENERAL_INSPECTION = "general_inspection"; EMERGENCY_REPAIR = "emergency_repair"

class MaintenanceStatus(str, Enum):
    SCHEDULED = "scheduled"; IN_PROGRESS = "in_progress"
    COMPLETED = "completed"; CANCELLED = "cancelled"; OVERDUE = "overdue"

class IncidentSeverity(str, Enum):
    MINOR = "minor"; MODERATE = "moderate"; MAJOR = "major"; CRITICAL = "critical"

class IncidentStatus(str, Enum):
    REPORTED = "reported"; INVESTIGATING = "investigating"
    RESOLVED = "resolved"; CLOSED = "closed"

class FuelEventType(str, Enum):
    REFUEL = "refuel"; CONSUMPTION = "consumption"
    ALERT = "alert"; THEFT_SUSPECTED = "theft_suspected"

class GeofenceType(str, Enum):
    DEPOT = "depot"; CUSTOMER = "customer"; RESTRICTED = "restricted"
    DELIVERY_ZONE = "delivery_zone"; SPEED_ZONE = "speed_zone"

class AlertType(str, Enum):
    SPEED_VIOLATION = "speed_violation"; GEOFENCE_ENTRY = "geofence_entry"
    GEOFENCE_EXIT = "geofence_exit"; FUEL_LOW = "fuel_low"
    MAINTENANCE_DUE = "maintenance_due"; HOURS_EXCEEDED = "hours_exceeded"
    IDLE_TIME = "idle_time"; HARSH_BRAKING = "harsh_braking"
    INCIDENT = "incident"

class DispatchStatus(str, Enum):
    PENDING = "pending"; ASSIGNED = "assigned"; ACCEPTED = "accepted"
    REJECTED = "rejected"; IN_TRANSIT = "in_transit"; DELIVERED = "delivered"
    FAILED = "failed"; CANCELLED = "cancelled"

VALID_VEHICLE_TRANSITIONS = {
    VehicleStatus.AVAILABLE: [VehicleStatus.IN_SERVICE, VehicleStatus.EN_ROUTE, VehicleStatus.MAINTENANCE, VehicleStatus.GROUNDED, VehicleStatus.DECOMMISSIONED],
    VehicleStatus.IN_SERVICE: [VehicleStatus.AVAILABLE, VehicleStatus.EN_ROUTE, VehicleStatus.MAINTENANCE, VehicleStatus.GROUNDED],
    VehicleStatus.EN_ROUTE: [VehicleStatus.AVAILABLE, VehicleStatus.IN_SERVICE, VehicleStatus.GROUNDED],
    VehicleStatus.MAINTENANCE: [VehicleStatus.AVAILABLE, VehicleStatus.GROUNDED],
    VehicleStatus.GROUNDED: [VehicleStatus.AVAILABLE, VehicleStatus.MAINTENANCE, VehicleStatus.DECOMMISSIONED],
    VehicleStatus.DECOMMISSIONED: [],
}

VALID_DRIVER_TRANSITIONS = {
    DriverStatus.AVAILABLE: [DriverStatus.ON_DUTY, DriverStatus.OFF_DUTY, DriverStatus.SUSPENDED],
    DriverStatus.ON_DUTY: [DriverStatus.DRIVING, DriverStatus.AVAILABLE, DriverStatus.RESTING],
    DriverStatus.DRIVING: [DriverStatus.ON_DUTY, DriverStatus.RESTING],
    DriverStatus.RESTING: [DriverStatus.AVAILABLE, DriverStatus.ON_DUTY],
    DriverStatus.OFF_DUTY: [DriverStatus.AVAILABLE],
    DriverStatus.SUSPENDED: [DriverStatus.AVAILABLE, DriverStatus.TERMINATED],
    DriverStatus.TERMINATED: [],
}

VALID_ROUTE_TRANSITIONS = {
    RouteStatus.DRAFT: [RouteStatus.PLANNED, RouteStatus.CANCELLED],
    RouteStatus.PLANNED: [RouteStatus.DISPATCHED, RouteStatus.DRAFT, RouteStatus.CANCELLED],
    RouteStatus.DISPATCHED: [RouteStatus.IN_PROGRESS, RouteStatus.CANCELLED],
    RouteStatus.IN_PROGRESS: [RouteStatus.COMPLETED, RouteStatus.FAILED, RouteStatus.CANCELLED],
    RouteStatus.COMPLETED: [],
    RouteStatus.CANCELLED: [],
    RouteStatus.FAILED: [RouteStatus.DRAFT],
}

VALID_DISPATCH_TRANSITIONS = {
    DispatchStatus.PENDING: [DispatchStatus.ASSIGNED, DispatchStatus.CANCELLED],
    DispatchStatus.ASSIGNED: [DispatchStatus.ACCEPTED, DispatchStatus.REJECTED, DispatchStatus.CANCELLED],
    DispatchStatus.ACCEPTED: [DispatchStatus.IN_TRANSIT, DispatchStatus.CANCELLED],
    DispatchStatus.REJECTED: [DispatchStatus.PENDING],
    DispatchStatus.IN_TRANSIT: [DispatchStatus.DELIVERED, DispatchStatus.FAILED],
    DispatchStatus.DELIVERED: [],
    DispatchStatus.FAILED: [DispatchStatus.PENDING],
    DispatchStatus.CANCELLED: [],
}

TERMINAL_VEHICLE_STATES = {VehicleStatus.DECOMMISSIONED}
ACTIVE_VEHICLE_STATES = {VehicleStatus.AVAILABLE, VehicleStatus.IN_SERVICE, VehicleStatus.EN_ROUTE}
TERMINAL_ROUTE_STATES = {RouteStatus.COMPLETED, RouteStatus.CANCELLED}

MAX_VIN_LENGTH = 17
MAX_PLATE_LENGTH = 20
MAX_ROUTE_NAME_LENGTH = 255
MAX_STOP_NAME_LENGTH = 255
MAX_GEOFENCE_NAME_LENGTH = 128
EARTH_RADIUS_KM = 6371.0
