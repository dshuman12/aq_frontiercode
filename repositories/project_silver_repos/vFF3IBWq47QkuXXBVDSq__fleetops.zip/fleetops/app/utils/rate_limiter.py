"""In-memory sliding-window rate limiter."""
from __future__ import annotations

import time
from collections import defaultdict
from threading import Lock
from typing import Any


class RateLimiter:
    def __init__(self, default_limit: int = 100, default_window: int = 60):
        self.default_limit = default_limit
        self.default_window = default_window
        self._buckets: dict[str, list[float]] = defaultdict(list)
        self._lock = Lock()

    def is_allowed(
        self, key: str, limit: int | None = None, window: int | None = None
    ) -> tuple[bool, dict[str, Any]]:
        limit = limit or self.default_limit
        window = window or self.default_window
        now = time.monotonic()
        with self._lock:
            ts = self._buckets[key]
            ts[:] = [t for t in ts if t > now - window]
            remaining = max(0, limit - len(ts))
            if len(ts) >= limit:
                retry_after = int(min(ts) + window - now) + 1
                return False, {
                    "limit": limit,
                    "remaining": 0,
                    "retry_after": retry_after,
                }
            ts.append(now)
            return True, {"limit": limit, "remaining": remaining - 1, "retry_after": 0}

    def reset(self, key: str) -> None:
        with self._lock:
            self._buckets.pop(key, None)

    def reset_all(self) -> None:
        with self._lock:
            self._buckets.clear()

    def get_stats(self) -> dict[str, Any]:
        with self._lock:
            return {
                "total_keys": len(self._buckets),
                "keys": list(self._buckets.keys())[:20],
            }
