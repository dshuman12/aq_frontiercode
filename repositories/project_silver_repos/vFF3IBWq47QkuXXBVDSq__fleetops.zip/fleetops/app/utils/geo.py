"""Geospatial utilities for fleet tracking."""
from __future__ import annotations
import math
from typing import Any
from app.utils.constants import EARTH_RADIUS_KM

def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Great-circle distance between two points in km."""
    lat1, lon1, lat2, lon2 = map(math.radians, [lat1, lon1, lat2, lon2])
    dlat = lat2 - lat1; dlon = lon2 - lon1
    a = math.sin(dlat / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2) ** 2
    return 2 * EARTH_RADIUS_KM * math.asin(math.sqrt(min(1.0, a)))

def point_in_circle(lat: float, lon: float, center_lat: float, center_lon: float, radius_km: float) -> bool:
    return haversine_km(lat, lon, center_lat, center_lon) <= radius_km

def bearing_degrees(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    lat1, lon1, lat2, lon2 = map(math.radians, [lat1, lon1, lat2, lon2])
    dlon = lon2 - lon1
    x = math.sin(dlon) * math.cos(lat2)
    y = math.cos(lat1) * math.sin(lat2) - math.sin(lat1) * math.cos(lat2) * math.cos(dlon)
    return (math.degrees(math.atan2(x, y)) + 360) % 360

def midpoint(lat1: float, lon1: float, lat2: float, lon2: float) -> tuple[float, float]:
    """Geographic midpoint between two coordinates."""
    lat1, lon1, lat2, lon2 = map(math.radians, [lat1, lon1, lat2, lon2])
    bx = math.cos(lat2) * math.cos(lon2 - lon1)
    by = math.cos(lat2) * math.sin(lon2 - lon1)
    lat3 = math.atan2(math.sin(lat1) + math.sin(lat2), math.sqrt((math.cos(lat1) + bx) ** 2 + by ** 2))
    lon3 = lon1 + math.atan2(by, math.cos(lat1) + bx)
    return math.degrees(lat3), math.degrees(lon3)

def total_route_distance(points: list[tuple[float, float]]) -> float:
    """Total distance along a sequence of lat/lon points."""
    if len(points) < 2: return 0.0
    return sum(haversine_km(points[i][0], points[i][1], points[i+1][0], points[i+1][1]) for i in range(len(points) - 1))

def bounding_box(center_lat: float, center_lon: float, radius_km: float) -> dict[str, float]:
    lat_delta = radius_km / 111.32
    lon_delta = radius_km / (111.32 * math.cos(math.radians(center_lat)))
    return {"min_lat": center_lat - lat_delta, "max_lat": center_lat + lat_delta,
            "min_lon": center_lon - lon_delta, "max_lon": center_lon + lon_delta}

def estimated_travel_time_hours(distance_km: float, avg_speed_kmh: float = 60.0) -> float:
    if avg_speed_kmh <= 0: return 0.0
    return distance_km / avg_speed_kmh

def speed_between_points(lat1: float, lon1: float, t1: float, lat2: float, lon2: float, t2: float) -> float:
    """Speed in km/h between two timestamped positions. t1, t2 are Unix timestamps."""
    dist = haversine_km(lat1, lon1, lat2, lon2)
    dt_hours = abs(t2 - t1) / 3600
    if dt_hours <= 0: return 0.0
    return dist / dt_hours

def is_within_geofence(lat: float, lon: float, fences: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Return all geofences that contain the given point."""
    matches = []
    for fence in fences:
        radius_km = fence.get("radius_m", 500) / 1000.0
        if point_in_circle(lat, lon, fence["latitude"], fence["longitude"], radius_km):
            matches.append(fence)
    return matches

def optimize_stop_order(stops: list[dict[str, Any]], start_lat: float, start_lon: float) -> list[dict[str, Any]]:
    """Greedy nearest-neighbor ordering of route stops."""
    if len(stops) <= 1: return stops[:]
    remaining = stops[:]; ordered = []
    current_lat, current_lon = start_lat, start_lon
    while remaining:
        nearest = min(remaining, key=lambda s: haversine_km(current_lat, current_lon, s["latitude"], s["longitude"]))
        ordered.append(nearest); remaining.remove(nearest)
        current_lat, current_lon = nearest["latitude"], nearest["longitude"]
    return ordered

def fuel_consumption_rate(distance_km: float, fuel_used_liters: float) -> float:
    """L/100km."""
    if distance_km <= 0: return 0.0
    return (fuel_used_liters / distance_km) * 100

def format_coordinates(lat: float, lon: float) -> str:
    ns = "N" if lat >= 0 else "S"
    ew = "E" if lon >= 0 else "W"
    return f"{abs(lat):.4f}\u00b0{ns}, {abs(lon):.4f}\u00b0{ew}"
