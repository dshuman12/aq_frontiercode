"""Input validation utilities for FleetOps."""
from __future__ import annotations
import re, json
from typing import Any
from app.utils.constants import (
    MAX_VIN_LENGTH, MAX_PLATE_LENGTH, MAX_ROUTE_NAME_LENGTH,
    MAX_STOP_NAME_LENGTH, MAX_GEOFENCE_NAME_LENGTH,
    VehicleType, MaintenanceType, IncidentSeverity, GeofenceType,
)

_VIN_RE = re.compile(r"^[A-HJ-NPR-Z0-9]{17}$")
_PLATE_RE = re.compile(r"^[A-Z0-9][A-Z0-9 -]{1,18}[A-Z0-9]$")
_EMAIL_RE = re.compile(r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$")
_LICENSE_RE = re.compile(r"^[A-Z0-9]{4,32}$")

def validate_vin(vin: str) -> str:
    vin = vin.strip().upper()
    if not vin: raise ValueError("VIN must not be empty")
    if len(vin) != MAX_VIN_LENGTH: raise ValueError(f"VIN must be exactly {MAX_VIN_LENGTH} characters")
    if not _VIN_RE.match(vin): raise ValueError(f"VIN contains invalid characters: \'{vin}\'")
    return vin

def validate_plate(plate: str) -> str:
    plate = plate.strip().upper()
    if not plate: raise ValueError("License plate must not be empty")
    if len(plate) > MAX_PLATE_LENGTH: raise ValueError(f"License plate exceeds {MAX_PLATE_LENGTH} characters")
    return plate

def validate_vehicle_type(vtype: str) -> str:
    try: VehicleType(vtype)
    except ValueError:
        valid = [v.value for v in VehicleType]
        raise ValueError(f"Invalid vehicle type: \'{vtype}\'. Must be one of {valid}")
    return vtype

def validate_route_name(name: str) -> str:
    name = name.strip()
    if not name: raise ValueError("Route name must not be empty")
    if len(name) > MAX_ROUTE_NAME_LENGTH: raise ValueError(f"Route name exceeds {MAX_ROUTE_NAME_LENGTH} characters")
    return name

def validate_stop_name(name: str) -> str:
    name = name.strip()
    if not name: raise ValueError("Stop name must not be empty")
    if len(name) > MAX_STOP_NAME_LENGTH: raise ValueError(f"Stop name exceeds {MAX_STOP_NAME_LENGTH} characters")
    return name

def validate_coordinates(lat: float, lon: float) -> tuple[float, float]:
    if not (-90 <= lat <= 90): raise ValueError(f"Latitude must be between -90 and 90, got {lat}")
    if not (-180 <= lon <= 180): raise ValueError(f"Longitude must be between -180 and 180, got {lon}")
    return lat, lon

def validate_geofence_name(name: str) -> str:
    name = name.strip()
    if not name: raise ValueError("Geofence name must not be empty")
    if len(name) > MAX_GEOFENCE_NAME_LENGTH: raise ValueError(f"Geofence name exceeds {MAX_GEOFENCE_NAME_LENGTH} characters")
    return name

def validate_geofence_radius(radius_m: float) -> float:
    if radius_m <= 0: raise ValueError("Geofence radius must be positive")
    if radius_m > 100000: raise ValueError("Geofence radius must not exceed 100km")
    return radius_m

def validate_email(email: str) -> str:
    email = email.strip().lower()
    if not email: raise ValueError("Email must not be empty")
    if not _EMAIL_RE.match(email): raise ValueError(f"Invalid email: \'{email}\'")
    return email

def validate_license_number(number: str) -> str:
    number = number.strip().upper()
    if not number: raise ValueError("License number must not be empty")
    if not _LICENSE_RE.match(number): raise ValueError(f"Invalid license number format: \'{number}\'")
    return number

def validate_fuel_amount(liters: float) -> float:
    if liters <= 0: raise ValueError("Fuel amount must be positive")
    if liters > 2000: raise ValueError("Fuel amount exceeds maximum (2000L)")
    return liters

def validate_odometer(km: float) -> float:
    if km < 0: raise ValueError("Odometer reading must be non-negative")
    if km > 2000000: raise ValueError("Odometer reading exceeds maximum (2M km)")
    return km

def validate_speed(kmh: float) -> float:
    if kmh < 0: raise ValueError("Speed must be non-negative")
    if kmh > 300: raise ValueError("Speed exceeds maximum (300 km/h)")
    return kmh

def validate_metadata(metadata: dict[str, Any] | None) -> dict[str, Any] | None:
    if metadata is None: return None
    if not isinstance(metadata, dict): raise ValueError("Metadata must be a JSON object")
    serialized = json.dumps(metadata, default=str)
    if len(serialized) > 65536: raise ValueError("Metadata exceeds 64KB limit")
    return metadata

def validate_maintenance_type(mtype: str) -> str:
    try: MaintenanceType(mtype)
    except ValueError:
        valid = [m.value for m in MaintenanceType]
        raise ValueError(f"Invalid maintenance type: \'{mtype}\'. Must be one of {valid}")
    return mtype

def validate_incident_severity(severity: str) -> str:
    try: IncidentSeverity(severity)
    except ValueError:
        valid = [s.value for s in IncidentSeverity]
        raise ValueError(f"Invalid severity: \'{severity}\'. Must be one of {valid}")
    return severity

def validate_geofence_type(gtype: str) -> str:
    try: GeofenceType(gtype)
    except ValueError:
        valid = [g.value for g in GeofenceType]
        raise ValueError(f"Invalid geofence type: \'{gtype}\'. Must be one of {valid}")
    return gtype
