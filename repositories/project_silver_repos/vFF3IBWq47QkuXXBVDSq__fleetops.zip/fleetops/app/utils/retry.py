"""Retry utilities with configurable backoff strategies."""
from __future__ import annotations

import logging
import random
import time
from typing import Any, Callable, TypeVar

logger = logging.getLogger("fleetops.retry")

T = TypeVar("T")


class BackoffStrategy:
    """Base backoff strategy."""

    def get_delay(self, attempt: int) -> float:
        raise NotImplementedError


class ConstantBackoff(BackoffStrategy):
    def __init__(self, delay: float = 1.0):
        self.delay = delay

    def get_delay(self, attempt: int) -> float:
        return self.delay


class LinearBackoff(BackoffStrategy):
    def __init__(self, base_delay: float = 1.0, increment: float = 1.0, max_delay: float = 60.0):
        self.base_delay = base_delay
        self.increment = increment
        self.max_delay = max_delay

    def get_delay(self, attempt: int) -> float:
        delay = self.base_delay + (self.increment * attempt)
        return min(delay, self.max_delay)


class ExponentialBackoff(BackoffStrategy):
    def __init__(
        self,
        base_delay: float = 1.0,
        factor: float = 2.0,
        max_delay: float = 300.0,
        jitter: bool = True,
    ):
        self.base_delay = base_delay
        self.factor = factor
        self.max_delay = max_delay
        self.jitter = jitter

    def get_delay(self, attempt: int) -> float:
        delay = self.base_delay * (self.factor ** attempt)
        delay = min(delay, self.max_delay)
        if self.jitter:
            delay = delay * (0.5 + random.random() * 0.5)
        return delay


class FibonacciBackoff(BackoffStrategy):
    def __init__(self, base_delay: float = 1.0, max_delay: float = 300.0):
        self.base_delay = base_delay
        self.max_delay = max_delay

    def get_delay(self, attempt: int) -> float:
        a, b = 1, 1
        for _ in range(attempt):
            a, b = b, a + b
        delay = self.base_delay * a
        return min(delay, self.max_delay)


def get_backoff_strategy(strategy: str, **kwargs) -> BackoffStrategy:
    """Factory for creating backoff strategies by name."""
    strategies = {
        "constant": ConstantBackoff,
        "linear": LinearBackoff,
        "exponential": ExponentialBackoff,
        "fibonacci": FibonacciBackoff,
    }
    cls = strategies.get(strategy)
    if cls is None:
        raise ValueError(f"Unknown backoff strategy: '{strategy}'")
    return cls(**kwargs)


def retry_with_backoff(
    func: Callable[..., T],
    max_retries: int = 3,
    backoff: BackoffStrategy | None = None,
    retryable_exceptions: tuple[type, ...] = (Exception,),
    on_retry: Callable[[int, Exception], None] | None = None,
    *args: Any,
    **kwargs: Any,
) -> T:
    if backoff is None:
        backoff = ExponentialBackoff()

    last_error: Exception | None = None
    for attempt in range(max_retries + 1):
        try:
            return func(*args, **kwargs)
        except retryable_exceptions as e:
            last_error = e
            if attempt >= max_retries:
                break
            delay = backoff.get_delay(attempt)
            logger.warning(
                "Retry %d/%d after %.2fs: %s",
                attempt + 1,
                max_retries,
                delay,
                str(e),
            )
            if on_retry:
                on_retry(attempt, e)
            time.sleep(delay)

    raise last_error  # type: ignore[misc]


class RetryContext:
    def __init__(self, max_retries: int = 3, backoff: BackoffStrategy | None = None):
        self.max_retries = max_retries
        self.backoff = backoff or ExponentialBackoff()
        self.attempts = 0
        self.last_error: Exception | None = None
        self.errors: list[Exception] = []

    @property
    def should_retry(self) -> bool:
        return self.attempts <= self.max_retries

    @property
    def delay(self) -> float:
        return self.backoff.get_delay(self.attempts - 1)

    def record_attempt(self, error: Exception | None = None) -> None:
        self.attempts += 1
        if error:
            self.last_error = error
            self.errors.append(error)

    def get_summary(self) -> dict[str, Any]:
        return {
            "attempts": self.attempts,
            "max_retries": self.max_retries,
            "errors": [str(e) for e in self.errors],
            "exhausted": self.attempts > self.max_retries,
        }
