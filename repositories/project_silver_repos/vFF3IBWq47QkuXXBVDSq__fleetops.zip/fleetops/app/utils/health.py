"""Health check utilities for monitoring system components."""

from __future__ import annotations

import time
from typing import Any, Callable
from datetime import datetime


class HealthCheck:
    """Composable health check system."""

    def __init__(self, name: str = "fleetops"):
        self.name = name
        self._checks: dict[str, Callable[[], dict[str, Any]]] = {}
        self._start_time = time.monotonic()

    def register_check(self, name: str, check_fn: Callable[[], dict[str, Any]]) -> None:
        """Register a health check function."""
        self._checks[name] = check_fn

    def run_all(self) -> dict[str, Any]:
        """Run all registered health checks."""
        results: dict[str, Any] = {}
        overall_healthy = True

        for name, check_fn in self._checks.items():
            try:
                start = time.monotonic()
                result = check_fn()
                duration = time.monotonic() - start
                result["duration_ms"] = round(duration * 1000, 2)
                results[name] = result
                if result.get("status") != "healthy":
                    overall_healthy = False
            except Exception as e:
                results[name] = {
                    "status": "unhealthy",
                    "error": str(e),
                }
                overall_healthy = False

        return {
            "name": self.name,
            "status": "healthy" if overall_healthy else "degraded",
            "uptime_seconds": time.monotonic() - self._start_time,
            "timestamp": datetime.utcnow().isoformat(),
            "checks": results,
        }

    def run_check(self, name: str) -> dict[str, Any]:
        """Run a specific health check."""
        check_fn = self._checks.get(name)
        if not check_fn:
            return {"status": "unknown", "error": f"Check '{name}' not found"}
        try:
            return check_fn()
        except Exception as e:
            return {"status": "unhealthy", "error": str(e)}


def check_database(db_session_factory: Callable) -> dict[str, Any]:
    """Health check for database connectivity."""
    try:
        from sqlalchemy import text
        session = db_session_factory()
        session.execute(text("SELECT 1"))
        session.close()
        return {"status": "healthy"}
    except Exception as e:
        return {"status": "unhealthy", "error": str(e)}


def check_disk_space(min_free_gb: float = 1.0) -> dict[str, Any]:
    """Health check for available disk space."""
    import shutil
    total, used, free = shutil.disk_usage("/")
    free_gb = free / (1024 ** 3)
    return {
        "status": "healthy" if free_gb >= min_free_gb else "warning",
        "free_gb": round(free_gb, 2),
        "total_gb": round(total / (1024 ** 3), 2),
        "used_pct": round(used / total * 100, 1),
    }


def check_memory() -> dict[str, Any]:
    """Health check for memory usage (basic)."""
    import os
    try:
        with open("/proc/meminfo") as f:
            lines = f.readlines()
        mem_info = {}
        for line in lines[:5]:
            parts = line.strip().split()
            if len(parts) >= 2:
                mem_info[parts[0].rstrip(":")] = int(parts[1])
        total = mem_info.get("MemTotal", 0)
        available = mem_info.get("MemAvailable", 0)
        used_pct = ((total - available) / total * 100) if total > 0 else 0
        return {
            "status": "healthy" if used_pct < 90 else "warning",
            "total_mb": total // 1024,
            "available_mb": available // 1024,
            "used_pct": round(used_pct, 1),
        }
    except (FileNotFoundError, KeyError):
        return {"status": "unknown", "error": "Cannot read /proc/meminfo"}
