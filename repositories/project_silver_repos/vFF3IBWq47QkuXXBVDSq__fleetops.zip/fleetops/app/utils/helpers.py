"""General-purpose helper functions."""
from __future__ import annotations
import hashlib, json, math, re, secrets, string
from datetime import datetime
from typing import Any
from uuid import uuid4

def utc_now() -> datetime: return datetime.utcnow()

def generate_vehicle_code() -> str: return f"VH-{uuid4().hex[:8].upper()}"
def generate_route_code() -> str: return f"RT-{uuid4().hex[:12]}"
def generate_dispatch_code() -> str: return f"DSP-{uuid4().hex[:8].upper()}"
def generate_api_key(prefix: str = "fo") -> str: return f"{prefix}_{secrets.token_urlsafe(32)}"
def generate_nonce(length: int = 16) -> str:
    return "".join(secrets.choice(string.ascii_letters + string.digits) for _ in range(length))

def slugify(text: str) -> str:
    text = text.lower().strip()
    text = re.sub(r"[^\w\s-]", "", text)
    return re.sub(r"[-\s]+", "-", text).strip("-")

def truncate(text: str, max_length: int = 100, suffix: str = "...") -> str:
    if len(text) <= max_length: return text
    return text[:max_length - len(suffix)] + suffix

def compute_hash(data: dict[str, Any] | str) -> str:
    if isinstance(data, dict): data = json.dumps(data, sort_keys=True, default=str)
    return hashlib.sha256(data.encode()).hexdigest()

def mask_string(value: str, visible: int = 4) -> str:
    if len(value) <= visible: return value
    return "*" * (len(value) - visible) + value[-visible:]

def format_duration(seconds: float) -> str:
    if seconds < 0: return "0s"
    hours, remainder = divmod(int(seconds), 3600)
    minutes, secs = divmod(remainder, 60)
    parts = []
    if hours: parts.append(f"{hours}h")
    if minutes: parts.append(f"{minutes}m")
    parts.append(f"{secs}s")
    return " ".join(parts)

def safe_json_loads(raw: str | None) -> dict[str, Any] | None:
    if raw is None: return None
    try: return json.loads(raw)
    except (json.JSONDecodeError, TypeError): return None

def safe_json_dumps(data: Any) -> str | None:
    if data is None: return None
    try: return json.dumps(data, default=str)
    except (TypeError, ValueError): return None

def deep_merge(base: dict, override: dict) -> dict:
    merged = base.copy()
    for key, value in override.items():
        if key in merged and isinstance(merged[key], dict) and isinstance(value, dict):
            merged[key] = deep_merge(merged[key], value)
        else: merged[key] = value
    return merged

def chunk_list(items: list, size: int) -> list[list]:
    if size <= 0: raise ValueError("chunk_size must be positive")
    return [items[i:i + size] for i in range(0, len(items), size)]

def sanitize_metadata(data: Any, max_depth: int = 5) -> Any:
    if max_depth <= 0: return "<truncated>"
    if isinstance(data, dict): return {k: sanitize_metadata(v, max_depth - 1) for k, v in data.items()}
    if isinstance(data, (list, tuple)): return [sanitize_metadata(item, max_depth - 1) for item in data]
    return data

def validate_coordinates(lat: float, lon: float) -> tuple[float, float]:
    if not (-90 <= lat <= 90): raise ValueError(f"Latitude must be between -90 and 90, got {lat}")
    if not (-180 <= lon <= 180): raise ValueError(f"Longitude must be between -180 and 180, got {lon}")
    return lat, lon

def match_event_pattern(pattern: str, event_type: str) -> bool:
    """Match event type against pattern with wildcard support."""
    if pattern == "*": return True
    return _match_parts(pattern.split("."), event_type.split("."))

def _match_parts(pattern: list[str], event: list[str]) -> bool:
    if not pattern and not event: return True
    if not pattern: return False
    if pattern[0] == "**":
        for i in range(len(event) + 1):
            if _match_parts(pattern[1:], event[i:]): return True
        return False
    if not event: return False
    if pattern[0] == "*" or pattern[0] == event[0]:
        return _match_parts(pattern[1:], event[1:])
    return False
