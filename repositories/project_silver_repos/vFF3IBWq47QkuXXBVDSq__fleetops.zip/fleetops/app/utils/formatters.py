"""Output formatting helpers."""
from __future__ import annotations

import json
from datetime import datetime
from typing import Any


def format_workflow_summary(wf: dict[str, Any]) -> str:
    return (
        f"[{wf.get('status', '?').upper():>10}] "
        f"{wf.get('name', '?')} ({wf.get('step_count', 0)} steps)"
    )


def format_run_summary(run: dict[str, Any]) -> str:
    return (
        f"[{run.get('status', '?').upper():>10}] "
        f"run={run.get('run_id', '?')} step={run.get('current_step', '?')}"
    )


def format_event_summary(evt: dict[str, Any]) -> str:
    return (
        f"[{evt.get('status', '?').upper():>10}] "
        f"{evt.get('event_type', '?')} id={evt.get('event_id', '?')}"
    )


def format_count(n: int) -> str:
    return f"{n:,}"


def format_percentage(value: float, total: float) -> str:
    if total == 0:
        return "0.0%"
    return f"{(value / total) * 100:.1f}%"


def format_duration_human(seconds: float | None) -> str:
    if seconds is None:
        return "-"
    if seconds < 60:
        return f"{seconds:.0f}s"
    minutes, secs = divmod(int(seconds), 60)
    if minutes < 60:
        return f"{minutes}m {secs}s"
    hours, mins = divmod(minutes, 60)
    return f"{hours}h {mins}m"


def format_json_pretty(data: Any) -> str:
    return json.dumps(data, indent=2, default=str)


def mask_pii(value: str, visible: int = 3) -> str:
    if len(value) <= visible:
        return "*" * len(value)
    return "*" * (len(value) - visible) + value[-visible:]


def format_bytes(n: int) -> str:
    if n < 1024:
        return f"{n}B"
    if n < 1024 * 1024:
        return f"{n / 1024:.1f}KB"
    return f"{n / (1024 * 1024):.1f}MB"
