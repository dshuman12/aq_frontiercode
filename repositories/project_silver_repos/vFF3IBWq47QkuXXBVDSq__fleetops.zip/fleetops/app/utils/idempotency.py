"""Idempotency key management for preventing duplicate task submissions."""

from __future__ import annotations

import hashlib
import json
import time
from threading import Lock
from typing import Any


class IdempotencyStore:
    """In-memory store for tracking idempotency keys.

    Prevents duplicate task submissions by tracking recently seen keys
    with a configurable time-to-live.
    """

    def __init__(self, ttl_seconds: int = 3600, max_keys: int = 100000):
        self.ttl_seconds = ttl_seconds
        self.max_keys = max_keys
        self._store: dict[str, dict[str, Any]] = {}
        self._lock = Lock()

    def check_and_set(self, key: str, value: Any = None) -> tuple[bool, Any | None]:
        """Check if a key exists and set it if not.

        Returns (is_new, existing_value):
        - (True, None) if the key is new
        - (False, existing_value) if the key already exists
        """
        now = time.monotonic()
        with self._lock:
            self._evict_expired(now)

            if key in self._store:
                entry = self._store[key]
                if now - entry["created_at"] < self.ttl_seconds:
                    return False, entry["value"]
                else:
                    del self._store[key]

            if len(self._store) >= self.max_keys:
                self._evict_oldest()

            self._store[key] = {
                "value": value,
                "created_at": now,
            }
            return True, None

    def exists(self, key: str) -> bool:
        """Check if a key exists and is not expired."""
        now = time.monotonic()
        with self._lock:
            entry = self._store.get(key)
            if entry is None:
                return False
            if now - entry["created_at"] >= self.ttl_seconds:
                del self._store[key]
                return False
            return True

    def get(self, key: str) -> Any | None:
        """Get the value for a key if it exists and is not expired."""
        now = time.monotonic()
        with self._lock:
            entry = self._store.get(key)
            if entry is None:
                return None
            if now - entry["created_at"] >= self.ttl_seconds:
                del self._store[key]
                return None
            return entry["value"]

    def remove(self, key: str) -> bool:
        """Remove a key from the store."""
        with self._lock:
            return self._store.pop(key, None) is not None

    def clear(self) -> int:
        """Clear all keys and return the count removed."""
        with self._lock:
            count = len(self._store)
            self._store.clear()
            return count

    def size(self) -> int:
        """Return the number of stored keys."""
        return len(self._store)

    def _evict_expired(self, now: float) -> int:
        """Remove all expired entries."""
        expired = [
            k for k, v in self._store.items()
            if now - v["created_at"] >= self.ttl_seconds
        ]
        for k in expired:
            del self._store[k]
        return len(expired)

    def _evict_oldest(self) -> None:
        """Remove the oldest entry to make room."""
        if not self._store:
            return
        oldest_key = min(self._store, key=lambda k: self._store[k]["created_at"])
        del self._store[oldest_key]


def generate_idempotency_key_from_payload(
    task_type: str,
    queue_name: str,
    payload: dict[str, Any] | None = None,
) -> str:
    """Generate a deterministic idempotency key from task parameters.

    This ensures that identical task submissions produce the same key,
    enabling automatic deduplication.
    """
    components = [task_type, queue_name]
    if payload:
        components.append(json.dumps(payload, sort_keys=True, default=str))
    combined = "|".join(components)
    return hashlib.sha256(combined.encode()).hexdigest()[:32]
