"""Condition evaluation engine for workflow step branching.

Supports expressions like:
    event.data.amount > 100
    event.type == 'order.created'
    prev.status == 'completed'
    prev.output.approved == true
    event.data.priority in ['high', 'critical']
"""
from __future__ import annotations

import json
import re
from typing import Any

from app.utils.helpers import resolve_json_path


def evaluate_condition(
    expression: str,
    context: dict[str, Any],
) -> bool:
    """Evaluate a condition expression against a context dict.

    Context keys:
        event.type        — the event type string
        event.data.*      — event payload fields
        prev.status       — previous step status
        prev.output.*     — previous step output fields
        run.input.*       — run-level input data

    Returns True if the condition is met, False otherwise.
    Raises ConditionError for malformed expressions.
    """
    if not expression or not expression.strip():
        return True

    expression = expression.strip()

    # Parse binary expression: <path> <op> <value>
    match = re.match(
        r"^([\w.]+)\s*(==|!=|>=|<=|>|<|in)\s*(.+)$",
        expression,
    )
    if not match:
        # Try boolean path: just "prev.success" means prev.success == true
        resolved = _resolve_path(match.group(1) if match else expression, context)
        return bool(resolved)

    path_str, operator, value_str = match.group(1), match.group(2), match.group(3).strip()
    actual = _resolve_path(path_str, context)
    expected = _parse_value(value_str)

    if operator == "==":
        return _compare_equal(actual, expected)
    elif operator == "!=":
        return not _compare_equal(actual, expected)
    elif operator == ">":
        return _compare_numeric(actual, expected, lambda a, b: a > b)
    elif operator == ">=":
        return _compare_numeric(actual, expected, lambda a, b: a >= b)
    elif operator == "<":
        return _compare_numeric(actual, expected, lambda a, b: a < b)
    elif operator == "<=":
        return _compare_numeric(actual, expected, lambda a, b: a <= b)
    elif operator == "in":
        if isinstance(expected, list):
            return actual in expected
        return str(actual) in str(expected)

    return False


def _resolve_path(path: str, context: dict[str, Any]) -> Any:
    """Resolve a dotted path against the context."""
    segments = path.split(".")
    if not segments:
        return None

    # Top-level keys: event, prev, run
    top = segments[0]
    if top not in context:
        return None

    current = context[top]
    for seg in segments[1:]:
        if isinstance(current, dict) and seg in current:
            current = current[seg]
        else:
            return None
    return current


def _parse_value(raw: str) -> Any:
    """Parse a literal value from an expression."""
    raw = raw.strip()

    # String literal
    if (raw.startswith("'") and raw.endswith("'")) or (
        raw.startswith('"') and raw.endswith('"')
    ):
        return raw[1:-1]

    # Boolean
    if raw.lower() == "true":
        return True
    if raw.lower() == "false":
        return False

    # None
    if raw.lower() in ("null", "none"):
        return None

    # List literal
    if raw.startswith("[") and raw.endswith("]"):
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            inner = raw[1:-1]
            return [_parse_value(v.strip()) for v in inner.split(",")]

    # Number
    try:
        if "." in raw:
            return float(raw)
        return int(raw)
    except ValueError:
        pass

    return raw


def _compare_equal(actual: Any, expected: Any) -> bool:
    """Compare two values for equality with type coercion."""
    if actual is None and expected is None:
        return True
    if actual is None or expected is None:
        return False
    # Boolean comparison
    if isinstance(expected, bool):
        return bool(actual) is expected
    # Numeric comparison
    try:
        return float(actual) == float(expected)
    except (ValueError, TypeError):
        pass
    return str(actual).lower() == str(expected).lower()


def _compare_numeric(actual: Any, expected: Any, op) -> bool:
    """Compare two values numerically."""
    try:
        return op(float(actual), float(expected))
    except (ValueError, TypeError):
        return False

