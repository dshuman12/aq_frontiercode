"""Pagination utilities for building paginated responses."""

from __future__ import annotations

import math
from typing import Any, TypeVar, Generic

from sqlalchemy.orm import Query


def paginate_query(
    query: Query,
    page: int = 1,
    page_size: int = 20,
) -> tuple[list[Any], int]:
    """Apply pagination to an SQLAlchemy query.

    Returns (items, total_count).
    """
    total = query.count()
    offset = (page - 1) * page_size
    items = query.offset(offset).limit(page_size).all()
    return items, total


def build_pagination_meta(
    total: int,
    page: int,
    page_size: int,
) -> dict[str, Any]:
    """Build pagination metadata for API responses."""
    pages = math.ceil(total / page_size) if page_size > 0 else 0
    return {
        "total": total,
        "page": page,
        "page_size": page_size,
        "pages": pages,
        "has_next": page < pages,
        "has_prev": page > 1,
        "next_page": page + 1 if page < pages else None,
        "prev_page": page - 1 if page > 1 else None,
    }


def validate_page_params(page: int, page_size: int, max_page_size: int = 100) -> tuple[int, int]:
    """Validate and clamp pagination parameters."""
    page = max(1, page)
    page_size = max(1, min(page_size, max_page_size))
    return page, page_size


def cursor_paginate(
    items: list[Any],
    cursor_field: str = "id",
    cursor: int | None = None,
    limit: int = 20,
) -> dict[str, Any]:
    """Cursor-based pagination for ordered lists.

    Returns dict with 'items', 'next_cursor', and 'has_more'.
    """
    if cursor is not None:
        items = [i for i in items if getattr(i, cursor_field, 0) > cursor]
    result_items = items[:limit]
    has_more = len(items) > limit
    next_cursor = (
        getattr(result_items[-1], cursor_field, None)
        if result_items
        else None
    )
    return {
        "items": result_items,
        "next_cursor": next_cursor,
        "has_more": has_more,
    }
