"""Date/time utilities."""
from __future__ import annotations
from datetime import datetime, timedelta


def utc_now() -> datetime:
    return datetime.utcnow()


def start_of_day(dt: datetime | None = None) -> datetime:
    dt = dt or utc_now()
    return dt.replace(hour=0, minute=0, second=0, microsecond=0)


def end_of_day(dt: datetime | None = None) -> datetime:
    dt = dt or utc_now()
    return dt.replace(hour=23, minute=59, second=59, microsecond=999999)


def days_ago(n: int) -> datetime:
    return utc_now() - timedelta(days=n)


def days_from_now(n: int) -> datetime:
    return utc_now() + timedelta(days=n)


def hours_between(start: datetime, end: datetime) -> float:
    return abs((end - start).total_seconds()) / 3600


def is_expired(dt: datetime, ttl_days: int) -> bool:
    return utc_now() > dt + timedelta(days=ttl_days)


def format_date(dt: datetime | None) -> str:
    if dt is None:
        return "-"
    return dt.strftime("%Y-%m-%d")


def format_datetime(dt: datetime | None) -> str:
    if dt is None:
        return "-"
    return dt.strftime("%Y-%m-%d %H:%M:%S")


def add_seconds(dt: datetime, seconds: float) -> datetime:
    return dt + timedelta(seconds=seconds)


def time_bucket(dt: datetime, bucket_minutes: int = 60) -> datetime:
    """Truncate a datetime to the nearest bucket boundary."""
    minute = (dt.minute // bucket_minutes) * bucket_minutes
    return dt.replace(minute=minute, second=0, microsecond=0)
