"""Pydantic schemas for analytics and reporting endpoints."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field


class DashboardSummary(BaseModel):
    """High-level dashboard metrics."""

    total_queues: int = 0
    active_queues: int = 0
    total_tasks: int = 0
    pending_tasks: int = 0
    running_tasks: int = 0
    completed_tasks_today: int = 0
    failed_tasks_today: int = 0
    active_workers: int = 0
    total_workers: int = 0
    active_pipelines: int = 0
    active_schedules: int = 0
    avg_task_duration: float | None = None
    task_success_rate: float | None = None
    throughput_per_minute: float = 0.0


class TaskStatusBreakdown(BaseModel):
    """Task count by status."""

    status: str
    count: int
    percentage: float


class QueueThroughput(BaseModel):
    """Queue throughput over a time window."""

    queue_name: str
    window_start: datetime
    window_end: datetime
    tasks_completed: int
    tasks_failed: int
    avg_duration_seconds: float | None
    p50_duration_seconds: float | None
    p95_duration_seconds: float | None
    p99_duration_seconds: float | None


class WorkerUtilization(BaseModel):
    """Worker utilization summary."""

    worker_id: str
    hostname: str
    utilization_pct: float
    tasks_completed: int
    tasks_failed: int
    avg_task_duration: float | None
    uptime_seconds: float


class TaskTrend(BaseModel):
    """Task trend data point for time series charts."""

    period: str
    period_start: datetime
    created: int = 0
    completed: int = 0
    failed: int = 0
    avg_wait_seconds: float | None = None
    avg_run_seconds: float | None = None


class ErrorBreakdown(BaseModel):
    """Error distribution by type."""

    error_type: str
    count: int
    percentage: float
    last_seen: datetime | None
    sample_message: str | None


class RetryAnalysis(BaseModel):
    """Retry attempt statistics."""

    total_retries: int = 0
    tasks_with_retries: int = 0
    avg_retries_per_task: float = 0.0
    retry_success_rate: float = 0.0
    max_retries_used: int = 0


class PipelineAnalytics(BaseModel):
    """Pipeline execution analytics."""

    pipeline_id: int
    pipeline_name: str
    total_runs: int = 0
    successful_runs: int = 0
    failed_runs: int = 0
    avg_duration_seconds: float | None = None
    slowest_step: str | None = None
    most_failed_step: str | None = None


class SystemMetrics(BaseModel):
    """Overall system health metrics."""

    cpu_avg: float | None = None
    memory_avg: float | None = None
    disk_avg: float | None = None
    db_connections: int = 0
    redis_connected: bool = False
    uptime_seconds: float = 0.0
    total_tasks_processed: int = 0
    tasks_per_second: float = 0.0
