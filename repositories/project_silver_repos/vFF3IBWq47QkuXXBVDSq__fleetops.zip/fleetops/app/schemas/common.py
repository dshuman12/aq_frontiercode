from __future__ import annotations
from datetime import datetime
from typing import Any, Generic, TypeVar
from pydantic import BaseModel, Field
T = TypeVar("T")
class PaginatedResponse(BaseModel, Generic[T]):
    items: list[T]; total: int; page: int; page_size: int; pages: int
class SuccessResponse(BaseModel):
    success: bool = True; message: str
class ErrorResponse(BaseModel):
    error: str; code: str
