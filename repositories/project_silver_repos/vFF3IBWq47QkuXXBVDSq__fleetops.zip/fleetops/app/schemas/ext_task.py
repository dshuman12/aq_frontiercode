"""Pydantic schemas for Task CRUD operations."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, Field


class TaskCreate(BaseModel):
    """Schema for creating a new task."""

    name: str = Field(..., min_length=1, max_length=255)
    task_type: str = Field(..., min_length=1, max_length=128)
    queue_name: str = Field(..., min_length=1, max_length=128)
    payload: dict[str, Any] | None = None
    priority: int = Field(default=5, ge=1, le=9)
    timeout: int = Field(default=3600, ge=1, le=86400)
    max_retries: int = Field(default=3, ge=0, le=10)
    retry_delay: int = Field(default=60, ge=0, le=86400)
    scheduled_at: datetime | None = None
    deadline: datetime | None = None
    idempotency_key: str | None = None
    correlation_id: str | None = None
    tags: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] | None = None
    depends_on: list[int] = Field(default_factory=list)


class TaskUpdate(BaseModel):
    """Schema for updating a task (limited fields)."""

    name: str | None = None
    priority: int | None = None
    timeout: int | None = None
    max_retries: int | None = None
    scheduled_at: datetime | None = None
    deadline: datetime | None = None
    tags: list[str] | None = None
    metadata: dict[str, Any] | None = None


class TaskResponse(BaseModel):
    """Schema for task API responses."""

    id: int
    name: str
    task_type: str
    queue_id: int
    queue_name: str | None = None
    status: str
    priority: int
    payload: dict[str, Any] | None = None
    result: dict[str, Any] | None = None
    error_message: str | None = None
    retry_count: int
    max_retries: int
    timeout: int
    worker_id: int | None = None
    idempotency_key: str | None = None
    correlation_id: str | None = None
    batch_id: str | None = None
    pipeline_run_id: int | None = None
    progress: int = 0
    scheduled_at: datetime | None = None
    created_at: datetime
    updated_at: datetime
    started_at: datetime | None = None
    completed_at: datetime | None = None
    deadline: datetime | None = None
    duration_seconds: float | None = None
    tags: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] | None = None

    model_config = {"from_attributes": True}


class TaskBulkCreate(BaseModel):
    """Schema for creating multiple tasks at once."""

    tasks: list[TaskCreate] = Field(..., min_length=1, max_length=1000)
    batch_id: str | None = None


class TaskBulkAction(BaseModel):
    """Schema for bulk task actions (cancel, retry, etc.)."""

    task_ids: list[int] = Field(..., min_length=1, max_length=1000)
    action: str = Field(..., pattern="^(cancel|retry|requeue|skip)$")


class TaskFilter(BaseModel):
    """Filter parameters for listing tasks."""

    status: str | None = None
    statuses: list[str] | None = None
    queue_name: str | None = None
    task_type: str | None = None
    priority_min: int | None = None
    priority_max: int | None = None
    created_after: datetime | None = None
    created_before: datetime | None = None
    tags: list[str] | None = None
    correlation_id: str | None = None
    batch_id: str | None = None
    search: str | None = None


class TaskProgress(BaseModel):
    """Schema for updating task progress."""

    progress: int = Field(..., ge=0, le=100)
    message: str | None = None


class TaskResult(BaseModel):
    """Schema for submitting a task result."""

    status: str = Field(..., pattern="^(success|failed)$")
    result: dict[str, Any] | None = None
    error_message: str | None = None
    error_traceback: str | None = None
    duration_seconds: float | None = None
