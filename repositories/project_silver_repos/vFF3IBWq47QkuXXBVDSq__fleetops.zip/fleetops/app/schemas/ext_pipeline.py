"""Pydantic schemas for Pipeline CRUD and execution."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field


class PipelineStepCreate(BaseModel):
    """Schema for defining a pipeline step."""

    name: str = Field(..., min_length=1, max_length=255)
    task_type: str = Field(..., min_length=1, max_length=128)
    task_payload_template: dict[str, Any] | None = None
    timeout: int = Field(default=3600, ge=1, le=86400)
    max_retries: int = Field(default=0, ge=0, le=10)
    continue_on_failure: bool = False
    condition: str | None = None


class PipelineCreate(BaseModel):
    """Schema for creating a new pipeline."""

    name: str = Field(..., min_length=1, max_length=255)
    description: str | None = None
    queue_name: str = Field(..., min_length=1, max_length=128)
    on_failure: str = Field(default="stop", pattern="^(stop|continue|skip)$")
    max_concurrent_runs: int = Field(default=1, ge=1, le=100)
    timeout: int = Field(default=7200, ge=1, le=86400)
    steps: list[PipelineStepCreate] = Field(..., min_length=1, max_length=50)
    metadata: dict[str, Any] | None = None


class PipelineUpdate(BaseModel):
    """Schema for updating a pipeline definition."""

    description: str | None = None
    queue_name: str | None = None
    on_failure: str | None = None
    max_concurrent_runs: int | None = None
    timeout: int | None = None
    enabled: bool | None = None
    steps: list[PipelineStepCreate] | None = None
    metadata: dict[str, Any] | None = None


class PipelineStepResponse(BaseModel):
    """Schema for pipeline step in responses."""

    id: int
    step_index: int
    name: str
    task_type: str
    timeout: int
    max_retries: int
    continue_on_failure: bool
    condition: str | None

    model_config = {"from_attributes": True}


class PipelineResponse(BaseModel):
    """Schema for pipeline API responses."""

    id: int
    name: str
    description: str | None
    version: int
    enabled: bool
    queue_name: str
    on_failure: str
    max_concurrent_runs: int
    timeout: int
    steps: list[PipelineStepResponse] = Field(default_factory=list)
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class PipelineRunCreate(BaseModel):
    """Schema for triggering a pipeline run."""

    input_data: dict[str, Any] | None = None
    correlation_id: str | None = None


class PipelineStepRunResponse(BaseModel):
    """Schema for pipeline step run in responses."""

    id: int
    step_index: int
    step_name: str
    task_id: int | None
    status: str
    started_at: datetime | None
    completed_at: datetime | None
    duration_seconds: float | None
    error_message: str | None

    model_config = {"from_attributes": True}


class PipelineRunResponse(BaseModel):
    """Schema for pipeline run API responses."""

    id: int
    pipeline_id: int
    status: str
    current_step: int
    trigger: str
    correlation_id: str | None
    started_at: datetime | None
    completed_at: datetime | None
    created_at: datetime
    duration_seconds: float | None
    error_message: str | None
    step_runs: list[PipelineStepRunResponse] = Field(default_factory=list)

    model_config = {"from_attributes": True}
