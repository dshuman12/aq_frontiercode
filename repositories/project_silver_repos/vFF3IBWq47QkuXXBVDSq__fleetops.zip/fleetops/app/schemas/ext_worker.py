"""Pydantic schemas for Worker registration and management."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field


class WorkerRegister(BaseModel):
    """Schema for registering a new worker."""

    worker_id: str = Field(..., min_length=1, max_length=128)
    hostname: str = Field(..., min_length=1, max_length=255)
    pid: int | None = None
    concurrency: int = Field(default=4, ge=1, le=100)
    queue_names: list[str] = Field(default_factory=list)
    capabilities: list[str] = Field(default_factory=list)
    version: str | None = None
    metadata: dict[str, Any] | None = None


class WorkerHeartbeat(BaseModel):
    """Schema for worker heartbeat updates."""

    current_tasks: int = 0
    tasks_completed: int = 0
    tasks_failed: int = 0
    cpu_usage: float | None = None
    memory_usage: float | None = None
    disk_usage: float | None = None


class WorkerResponse(BaseModel):
    """Schema for worker API responses."""

    id: int
    worker_id: str
    hostname: str
    pid: int | None
    status: str
    concurrency: int
    current_tasks: int
    tasks_completed: int
    tasks_failed: int
    cpu_usage: float | None
    memory_usage: float | None
    disk_usage: float | None
    version: str | None
    queue_names: list[str] = Field(default_factory=list)
    capabilities: list[str] = Field(default_factory=list)
    started_at: datetime
    last_heartbeat: datetime
    stopped_at: datetime | None

    model_config = {"from_attributes": True}


class WorkerStats(BaseModel):
    """Aggregated worker statistics."""

    total_workers: int = 0
    active_workers: int = 0
    idle_workers: int = 0
    offline_workers: int = 0
    total_concurrency: int = 0
    total_current_tasks: int = 0
    avg_cpu_usage: float | None = None
    avg_memory_usage: float | None = None
