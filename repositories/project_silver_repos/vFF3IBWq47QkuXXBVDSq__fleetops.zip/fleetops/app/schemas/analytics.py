from __future__ import annotations
from pydantic import BaseModel

class DashboardSummary(BaseModel):
    total_workflows: int = 0; active_workflows: int = 0
    total_runs: int = 0; running_runs: int = 0; failed_runs: int = 0
    total_events: int = 0; events_today: int = 0
    dlq_size: int = 0
