"""Pydantic schemas for Queue CRUD operations."""

from __future__ import annotations

from datetime import datetime
from typing import Optional

from pydantic import BaseModel, Field


class QueueCreate(BaseModel):
    """Schema for creating a new queue."""

    name: str = Field(..., min_length=1, max_length=128)
    display_name: str | None = None
    description: str | None = None
    max_size: int = Field(default=10000, ge=1, le=1000000)
    max_retries: int = Field(default=3, ge=0, le=10)
    retry_delay: int = Field(default=60, ge=0, le=86400)
    timeout: int = Field(default=3600, ge=1, le=86400)
    concurrency_limit: int = Field(default=0, ge=0, le=10000)
    rate_limit: int = Field(default=0, ge=0)
    rate_window: int = Field(default=60, ge=1)
    enable_dead_letter: bool = True
    dead_letter_queue_id: int | None = None
    priority_enabled: bool = True
    fifo: bool = False
    tags: list[str] = Field(default_factory=list)


class QueueUpdate(BaseModel):
    """Schema for updating an existing queue."""

    display_name: str | None = None
    description: str | None = None
    max_size: int | None = None
    max_retries: int | None = None
    retry_delay: int | None = None
    timeout: int | None = None
    concurrency_limit: int | None = None
    rate_limit: int | None = None
    rate_window: int | None = None
    enable_dead_letter: bool | None = None
    dead_letter_queue_id: int | None = None
    priority_enabled: bool | None = None
    tags: list[str] | None = None


class QueueResponse(BaseModel):
    """Schema for queue API responses."""

    id: int
    name: str
    display_name: str | None
    description: str | None
    status: str
    max_size: int
    max_retries: int
    retry_delay: int
    timeout: int
    concurrency_limit: int
    rate_limit: int
    rate_window: int
    enable_dead_letter: bool
    dead_letter_queue_id: int | None
    priority_enabled: bool
    fifo: bool
    created_at: datetime
    updated_at: datetime
    paused_at: datetime | None
    tags: list[str] = Field(default_factory=list)
    pending_count: int = 0
    running_count: int = 0

    model_config = {"from_attributes": True}


class QueueStats(BaseModel):
    """Aggregated queue statistics."""

    queue_id: int
    queue_name: str
    total_tasks: int = 0
    pending: int = 0
    queued: int = 0
    running: int = 0
    completed: int = 0
    failed: int = 0
    dead_letter: int = 0
    avg_duration_seconds: float | None = None
    throughput_per_minute: float = 0.0
    oldest_pending_age_seconds: float | None = None


class QueuePurgeRequest(BaseModel):
    """Parameters for purging tasks from a queue."""

    statuses: list[str] = Field(default_factory=lambda: ["cancelled", "dead_letter"])
    older_than_hours: int | None = None
    dry_run: bool = False
