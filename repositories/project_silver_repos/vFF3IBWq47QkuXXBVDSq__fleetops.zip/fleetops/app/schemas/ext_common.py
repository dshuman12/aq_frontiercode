"""Shared Pydantic schemas used across multiple endpoints."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Generic, TypeVar

from pydantic import BaseModel, Field

T = TypeVar("T")


class PaginationParams(BaseModel):
    """Common pagination parameters."""

    page: int = Field(default=1, ge=1)
    page_size: int = Field(default=20, ge=1, le=100)

    @property
    def offset(self) -> int:
        return (self.page - 1) * self.page_size


class PaginatedResponse(BaseModel, Generic[T]):
    """Wrapper for paginated API responses."""

    items: list[T]
    total: int
    page: int
    page_size: int
    pages: int


class SuccessResponse(BaseModel):
    """Generic success response."""

    success: bool = True
    message: str


class ErrorResponse(BaseModel):
    """Generic error response."""

    error: str
    code: str
    detail: str | None = None


class BulkActionResult(BaseModel):
    """Result of a bulk operation."""

    total: int
    succeeded: int
    failed: int
    errors: list[dict[str, Any]] = Field(default_factory=list)


class HealthCheck(BaseModel):
    """Health check response."""

    status: str = "healthy"
    version: str
    database: str = "connected"
    uptime_seconds: float | None = None
    timestamp: datetime


class StatusCount(BaseModel):
    """Count of items grouped by status."""

    status: str
    count: int


class TimeSeriesPoint(BaseModel):
    """Single data point in a time series."""

    timestamp: datetime
    value: float
    label: str | None = None
