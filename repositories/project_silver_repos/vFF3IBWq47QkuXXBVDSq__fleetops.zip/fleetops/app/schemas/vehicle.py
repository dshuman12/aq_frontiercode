from __future__ import annotations
from datetime import datetime
from typing import Any
from pydantic import BaseModel, Field
class VehicleCreate(BaseModel):
    plate: str = Field(..., min_length=2, max_length=20)
    vin: str = Field(..., min_length=17, max_length=17)
    vehicle_type: str; make: str | None = None; model: str | None = None
    year: int | None = None; color: str | None = None
    fuel_capacity_liters: float = 60.0; fleet_name: str | None = None
    metadata: dict[str, Any] | None = None
class VehicleUpdate(BaseModel):
    make: str | None = None; model: str | None = None; color: str | None = None
    fleet_name: str | None = None; metadata: dict[str, Any] | None = None
class VehicleResponse(BaseModel):
    id: int; plate: str; vin: str; vehicle_type: str; status: str
    odometer_km: float; fuel_level_pct: float; current_lat: float | None
    current_lon: float | None; assigned_driver_id: int | None
    fleet_name: str | None; created_at: datetime
    model_config = {"from_attributes": True}
