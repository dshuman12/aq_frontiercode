"""Pydantic schemas for Schedule CRUD operations."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field


class ScheduleCreate(BaseModel):
    """Schema for creating a new schedule."""

    name: str = Field(..., min_length=1, max_length=255)
    description: str | None = None
    cron_expression: str = Field(..., min_length=1, max_length=128)
    timezone: str = Field(default="UTC", max_length=64)
    task_name: str = Field(..., min_length=1, max_length=255)
    task_type: str = Field(..., min_length=1, max_length=128)
    queue_name: str = Field(..., min_length=1, max_length=128)
    task_payload: dict[str, Any] | None = None
    task_priority: int = Field(default=5, ge=1, le=9)
    task_timeout: int = Field(default=3600, ge=1, le=86400)
    task_max_retries: int = Field(default=3, ge=0, le=10)
    max_instances: int = Field(default=1, ge=1, le=100)
    coalesce: bool = True
    jitter_seconds: int = Field(default=0, ge=0, le=300)
    starts_at: datetime | None = None
    expires_at: datetime | None = None
    metadata: dict[str, Any] | None = None


class ScheduleUpdate(BaseModel):
    """Schema for updating an existing schedule."""

    description: str | None = None
    cron_expression: str | None = None
    timezone: str | None = None
    task_name: str | None = None
    task_type: str | None = None
    queue_name: str | None = None
    task_payload: dict[str, Any] | None = None
    task_priority: int | None = None
    task_timeout: int | None = None
    task_max_retries: int | None = None
    max_instances: int | None = None
    coalesce: bool | None = None
    jitter_seconds: int | None = None
    starts_at: datetime | None = None
    expires_at: datetime | None = None
    metadata: dict[str, Any] | None = None


class ScheduleResponse(BaseModel):
    """Schema for schedule API responses."""

    id: int
    name: str
    description: str | None
    status: str
    cron_expression: str
    timezone: str
    task_name: str
    task_type: str
    queue_name: str
    task_priority: int
    task_timeout: int
    task_max_retries: int
    enabled: bool
    max_instances: int
    coalesce: bool
    jitter_seconds: int
    last_run_at: datetime | None
    next_run_at: datetime | None
    run_count: int
    failure_count: int
    starts_at: datetime | None
    expires_at: datetime | None
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class ScheduleRunResponse(BaseModel):
    """Schema for schedule run history."""

    id: int
    schedule_id: int
    task_id: int | None
    triggered_at: datetime
    scheduled_for: datetime
    status: str
    error_message: str | None

    model_config = {"from_attributes": True}
