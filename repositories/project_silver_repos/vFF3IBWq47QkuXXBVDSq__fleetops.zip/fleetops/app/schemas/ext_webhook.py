"""Pydantic schemas for Webhook CRUD and delivery tracking."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field


class WebhookCreate(BaseModel):
    """Schema for creating a new webhook."""

    name: str = Field(..., min_length=1, max_length=255)
    url: str = Field(..., min_length=1, max_length=2048)
    events: list[str] = Field(..., min_length=1)
    queue_filter: str | None = None
    max_retries: int = Field(default=3, ge=0, le=10)
    timeout: int = Field(default=30, ge=1, le=120)
    retry_delay: int = Field(default=60, ge=0, le=3600)


class WebhookUpdate(BaseModel):
    """Schema for updating an existing webhook."""

    name: str | None = None
    url: str | None = None
    events: list[str] | None = None
    enabled: bool | None = None
    queue_filter: str | None = None
    max_retries: int | None = None
    timeout: int | None = None
    retry_delay: int | None = None


class WebhookResponse(BaseModel):
    """Schema for webhook API responses."""

    id: int
    name: str
    url: str
    events: list[str]
    enabled: bool
    queue_filter: str | None
    max_retries: int
    timeout: int
    retry_delay: int
    consecutive_failures: int
    last_delivery_at: datetime | None
    last_status_code: int | None
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class WebhookDeliveryResponse(BaseModel):
    """Schema for webhook delivery log entries."""

    id: int
    webhook_id: int
    event: str
    response_status: int | None
    success: bool
    attempt: int
    duration_ms: float | None
    error_message: str | None
    delivered_at: datetime

    model_config = {"from_attributes": True}


class WebhookTestRequest(BaseModel):
    """Schema for sending a test webhook delivery."""

    event: str = "task.completed"
    payload: dict[str, Any] | None = None
