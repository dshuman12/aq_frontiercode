from __future__ import annotations
from datetime import datetime
from typing import Any
from pydantic import BaseModel, Field
class DriverCreate(BaseModel):
    employee_id: str = Field(..., min_length=1, max_length=32)
    name: str = Field(..., min_length=1, max_length=255)
    license_number: str = Field(..., min_length=4, max_length=32)
    email: str | None = None; phone: str | None = None
    license_class: str | None = None; metadata: dict[str, Any] | None = None
class DriverResponse(BaseModel):
    id: int; employee_id: str; name: str; status: str
    total_hours_today: float; total_distance_km: float
    rating: float; violations_count: int; created_at: datetime
    model_config = {"from_attributes": True}
