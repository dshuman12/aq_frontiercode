# inventory-api

REST API for managing product inventory across multiple warehouses.
Handles stock reservation, order fulfillment, and low stock alerts.
Built with Go, PostgreSQL, and JWT auth.

## Running locally
cp .env.example .env
docker-compose up
