package integration_test

import (
	"context"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"inventoryapi.dev/api/internal/report"
)

func TestReport_SummaryReport_ReturnsValidStruct(t *testing.T) {
	db := testDB(t)
	svc := report.New(db)
	to := time.Now()
	from := to.AddDate(0, 0, -30)
	r, err := svc.GetSummaryReport(context.Background(), from, to)
	require.NoError(t, err)
	assert.NotNil(t, r)
	assert.True(t, r.TotalProducts >= 0)
	assert.True(t, r.TotalRevenue >= 0)
}

func TestReport_StatusDistribution_SumsToTotal(t *testing.T) {
	db := testDB(t)
	svc := report.New(db)
	rows, err := svc.GetOrderStatusDistribution(context.Background())
	require.NoError(t, err)
	total := 0.0
	for _, r := range rows {
		total += r.Percentage
	}
	if len(rows) > 0 {
		assert.InDelta(t, 100.0, total, 0.1)
	}
}

func TestReport_WarehouseUtilization_PctInRange(t *testing.T) {
	db := testDB(t)
	svc := report.New(db)
	rows, err := svc.GetWarehouseUtilization(context.Background())
	require.NoError(t, err)
	for _, r := range rows {
		assert.True(t, r.UtilizationPct >= 0 && r.UtilizationPct <= 100)
	}
}

func TestReport_RevenueTrend_OrderedChronologically(t *testing.T) {
	db := testDB(t)
	svc := report.New(db)
	points, err := svc.GetRevenueTrend(context.Background(), 30)
	require.NoError(t, err)
	for i := 1; i < len(points); i++ {
		assert.True(t, !points[i].Date.Before(points[i-1].Date))
	}
}

func TestReport_LowStockAlerts_AvailableCalc(t *testing.T) {
	db := testDB(t)
	svc := report.New(db)
	alerts, err := svc.GetLowStockAlerts(context.Background())
	require.NoError(t, err)
	for _, a := range alerts {
		assert.Equal(t, a.Quantity-a.Reserved, a.Available)
		assert.True(t, a.Available < a.ReorderPoint)
	}
}
