package integration

import (
	"os"
	"testing"

	"github.com/jmoiron/sqlx"
	_ "github.com/lib/pq"
)

var testDB *sqlx.DB

func TestMain(m *testing.M) {
	dsn := os.Getenv("TEST_DB_DSN")
	if dsn == "" {
		os.Exit(0)
	}

	var err error
	testDB, err = sqlx.Open("postgres", dsn)
	if err != nil {
		panic("failed to open test db: " + err.Error())
	}
	defer testDB.Close()

	if err := testDB.Ping(); err != nil {
		panic("failed to ping test db: " + err.Error())
	}

	setupSchema()

	code := m.Run()

	teardownSchema()
	os.Exit(code)
}

func setupSchema() {
	queries := []string{
		`CREATE TABLE IF NOT EXISTS products (
			id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
			sku VARCHAR(50) NOT NULL UNIQUE,
			name VARCHAR(200) NOT NULL,
			description TEXT,
			category VARCHAR(100),
			unit_price NUMERIC(12,2) NOT NULL DEFAULT 0,
			weight_kg NUMERIC(8,3),
			created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
			updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
		)`,
		`CREATE TABLE IF NOT EXISTS warehouses (
			id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
			name VARCHAR(200) NOT NULL,
			location VARCHAR(255),
			max_capacity INT NOT NULL DEFAULT 0,
			current_usage INT NOT NULL DEFAULT 0,
			is_active BOOLEAN NOT NULL DEFAULT true,
			created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
		)`,
		`CREATE TABLE IF NOT EXISTS inventory (
			id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
			product_id UUID NOT NULL REFERENCES products(id),
			warehouse_id UUID NOT NULL REFERENCES warehouses(id),
			quantity INT NOT NULL DEFAULT 0,
			reserved_quantity INT NOT NULL DEFAULT 0,
			reorder_point INT NOT NULL DEFAULT 10,
			reorder_quantity INT NOT NULL DEFAULT 50,
			UNIQUE(product_id, warehouse_id)
		)`,
		`CREATE TABLE IF NOT EXISTS orders (
			id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
			customer_id VARCHAR(100) NOT NULL,
			status VARCHAR(30) NOT NULL DEFAULT 'pending',
			total_amount NUMERIC(14,2) NOT NULL DEFAULT 0,
			notes TEXT,
			created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
			updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
		)`,
		`CREATE TABLE IF NOT EXISTS order_items (
			id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
			order_id UUID NOT NULL REFERENCES orders(id),
			product_id UUID NOT NULL REFERENCES products(id),
			warehouse_id UUID NOT NULL REFERENCES warehouses(id),
			requested_qty INT NOT NULL,
			fulfilled_qty INT NOT NULL DEFAULT 0,
			unit_price NUMERIC(12,2) NOT NULL
		)`,
	}
	for _, q := range queries {
		testDB.MustExec(q)
	}
}

func teardownSchema() {
	tables := []string{"order_items", "orders", "inventory", "warehouses", "products"}
	for _, t := range tables {
		testDB.Exec("DROP TABLE IF EXISTS " + t + " CASCADE")
	}
}
