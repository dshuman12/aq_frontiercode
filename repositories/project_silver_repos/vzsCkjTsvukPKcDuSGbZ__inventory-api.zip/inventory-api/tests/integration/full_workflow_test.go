package integration_test

import (
	"fmt"
	"testing"
	"time"

	"github.com/google/uuid"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"inventoryapi.dev/api/internal/model"
	"inventoryapi.dev/api/internal/repository"
	"inventoryapi.dev/api/internal/service"
)

func TestFullOrderLifecycle(t *testing.T) {
	db := testDB(t)
	productRepo := repository.NewProductRepo(db)
	warehouseRepo := repository.NewWarehouseRepo(db)
	inventoryRepo := repository.NewInventoryRepo(db)
	orderRepo := repository.NewOrderRepo(db)
	invSvc := service.NewInventoryService(inventoryRepo, warehouseRepo)
	orderSvc := service.NewOrderService(orderRepo, invSvc, productRepo)

	wh := &model.Warehouse{
		ID: uuid.New(), Name: fmt.Sprintf("Test WH %d", time.Now().UnixNano()),
		Location: "Test City", MaxCapacity: 1000, IsActive: true,
	}
	require.NoError(t, warehouseRepo.Create(wh))

	p := &model.Product{
		ID: uuid.New(), SKU: fmt.Sprintf("TST-%d", time.Now().UnixNano()),
		Name: "Test Widget", Category: "Electronics",
		UnitPrice: 49.99, WeightKg: 0.5,
	}
	require.NoError(t, productRepo.Create(p))

	inv := &model.Inventory{
		ID: uuid.New(), ProductID: p.ID, WarehouseID: wh.ID,
		Quantity: 100, ReservedQuantity: 0,
		ReorderPoint: 10, ReorderQuantity: 50,
	}
	require.NoError(t, inventoryRepo.Create(inv))

	req := &model.CreateOrderRequest{
		CustomerID: "CUST-001",
		Items: []model.OrderItemRequest{
			{ProductID: p.ID.String(), WarehouseID: wh.ID.String(), Quantity: 5},
		},
	}
	order, items, err := orderSvc.Create(req)
	require.NoError(t, err)
	assert.NotNil(t, order)
	assert.Len(t, items, 1)
	assert.Equal(t, "pending", string(order.Status))

	updated, err := inventoryRepo.GetByProductAndWarehouse(p.ID, wh.ID)
	require.NoError(t, err)
	assert.Equal(t, 5, updated.ReservedQuantity)

	err = orderSvc.Transition(order.ID.String(), model.OrderStatus("confirmed"))
	require.NoError(t, err)

	err = orderSvc.Transition(order.ID.String(), model.OrderStatus("fulfilled"))
	require.NoError(t, err)

	final, err := inventoryRepo.GetByProductAndWarehouse(p.ID, wh.ID)
	require.NoError(t, err)
	assert.Equal(t, 95, final.Quantity)
	assert.Equal(t, 0, final.ReservedQuantity)
}

func TestCancelOrderReleasesReservations(t *testing.T) {
	db := testDB(t)
	productRepo := repository.NewProductRepo(db)
	warehouseRepo := repository.NewWarehouseRepo(db)
	inventoryRepo := repository.NewInventoryRepo(db)
	orderRepo := repository.NewOrderRepo(db)
	invSvc := service.NewInventoryService(inventoryRepo, warehouseRepo)
	orderSvc := service.NewOrderService(orderRepo, invSvc, productRepo)

	wh := &model.Warehouse{
		ID: uuid.New(), Name: fmt.Sprintf("Cancel WH %d", time.Now().UnixNano()),
		MaxCapacity: 500, IsActive: true,
	}
	require.NoError(t, warehouseRepo.Create(wh))

	p := &model.Product{
		ID: uuid.New(), SKU: fmt.Sprintf("CAN-%d", time.Now().UnixNano()),
		Name: "Cancellable Item", UnitPrice: 19.99,
	}
	require.NoError(t, productRepo.Create(p))

	inv := &model.Inventory{
		ID: uuid.New(), ProductID: p.ID, WarehouseID: wh.ID,
		Quantity: 50, ReservedQuantity: 0, ReorderPoint: 5, ReorderQuantity: 20,
	}
	require.NoError(t, inventoryRepo.Create(inv))

	req := &model.CreateOrderRequest{
		CustomerID: "CUST-CANCEL",
		Items: []model.OrderItemRequest{
			{ProductID: p.ID.String(), WarehouseID: wh.ID.String(), Quantity: 10},
		},
	}
	order, _, err := orderSvc.Create(req)
	require.NoError(t, err)

	afterCreate, err := inventoryRepo.GetByProductAndWarehouse(p.ID, wh.ID)
	require.NoError(t, err)
	assert.Equal(t, 10, afterCreate.ReservedQuantity)

	err = orderSvc.Transition(order.ID.String(), model.OrderStatus("cancelled"))
	require.NoError(t, err)

	afterCancel, err := inventoryRepo.GetByProductAndWarehouse(p.ID, wh.ID)
	require.NoError(t, err)
	assert.Equal(t, 0, afterCancel.ReservedQuantity)
	assert.Equal(t, 50, afterCancel.Quantity)
}

func TestInventoryTransfer(t *testing.T) {
	db := testDB(t)
	warehouseRepo := repository.NewWarehouseRepo(db)
	productRepo := repository.NewProductRepo(db)
	inventoryRepo := repository.NewInventoryRepo(db)

	wh1 := &model.Warehouse{
		ID: uuid.New(), Name: fmt.Sprintf("Source WH %d", time.Now().UnixNano()),
		MaxCapacity: 1000, IsActive: true,
	}
	wh2 := &model.Warehouse{
		ID: uuid.New(), Name: fmt.Sprintf("Dest WH %d", time.Now().UnixNano()),
		MaxCapacity: 1000, IsActive: true,
	}
	require.NoError(t, warehouseRepo.Create(wh1))
	require.NoError(t, warehouseRepo.Create(wh2))

	p := &model.Product{
		ID: uuid.New(), SKU: fmt.Sprintf("TRF-%d", time.Now().UnixNano()),
		Name: "Transferable Product", UnitPrice: 9.99,
	}
	require.NoError(t, productRepo.Create(p))

	inv1 := &model.Inventory{
		ID: uuid.New(), ProductID: p.ID, WarehouseID: wh1.ID,
		Quantity: 100, ReorderPoint: 10, ReorderQuantity: 50,
	}
	inv2 := &model.Inventory{
		ID: uuid.New(), ProductID: p.ID, WarehouseID: wh2.ID,
		Quantity: 20, ReorderPoint: 5, ReorderQuantity: 25,
	}
	require.NoError(t, inventoryRepo.Create(inv1))
	require.NoError(t, inventoryRepo.Create(inv2))

	err := inventoryRepo.Transfer(p.ID, wh1.ID, wh2.ID, 30)
	require.NoError(t, err)

	updated1, err := inventoryRepo.GetByProductAndWarehouse(p.ID, wh1.ID)
	require.NoError(t, err)
	assert.Equal(t, 70, updated1.Quantity)

	updated2, err := inventoryRepo.GetByProductAndWarehouse(p.ID, wh2.ID)
	require.NoError(t, err)
	assert.Equal(t, 50, updated2.Quantity)
}

func TestProductCRUDLifecycle(t *testing.T) {
	db := testDB(t)
	repo := repository.NewProductRepo(db)

	p := &model.Product{
		ID: uuid.New(), SKU: fmt.Sprintf("CRUD-%d", time.Now().UnixNano()),
		Name: "CRUD Test Product", Category: "Test",
		UnitPrice: 29.99, WeightKg: 1.0,
	}
	require.NoError(t, repo.Create(p))

	fetched, err := repo.GetByID(p.ID)
	require.NoError(t, err)
	assert.Equal(t, p.SKU, fetched.SKU)
	assert.Equal(t, p.Name, fetched.Name)

	bySKU, err := repo.GetBySKU(p.SKU)
	require.NoError(t, err)
	assert.Equal(t, p.ID, bySKU.ID)

	updateReq := &model.UpdateProductRequest{
		Name: "Updated CRUD Product", Category: "Updated",
		UnitPrice: 39.99, WeightKg: 1.5,
	}
	updated, err := repo.Update(p.ID, updateReq)
	require.NoError(t, err)
	assert.Equal(t, "Updated CRUD Product", updated.Name)
	assert.Equal(t, 39.99, updated.UnitPrice)

	err = repo.Delete(p.ID)
	require.NoError(t, err)

	_, err = repo.GetByID(p.ID)
	assert.Error(t, err)
}

func TestWarehouseCapacityEnforcement(t *testing.T) {
	db := testDB(t)
	warehouseRepo := repository.NewWarehouseRepo(db)
	productRepo := repository.NewProductRepo(db)
	inventoryRepo := repository.NewInventoryRepo(db)
	invSvc := service.NewInventoryService(inventoryRepo, warehouseRepo)

	wh := &model.Warehouse{
		ID: uuid.New(), Name: fmt.Sprintf("Small WH %d", time.Now().UnixNano()),
		MaxCapacity: 10, CurrentUsage: 0, IsActive: true,
	}
	require.NoError(t, warehouseRepo.Create(wh))

	p := &model.Product{
		ID: uuid.New(), SKU: fmt.Sprintf("CAP-%d", time.Now().UnixNano()),
		Name: "Capacity Test Product", UnitPrice: 5.00,
	}
	require.NoError(t, productRepo.Create(p))

	inv := &model.Inventory{
		ID: uuid.New(), ProductID: p.ID, WarehouseID: wh.ID,
		Quantity: 8, ReorderPoint: 2, ReorderQuantity: 5,
	}
	require.NoError(t, inventoryRepo.Create(inv))

	needed, _, err := invSvc.CheckReorderNeeded(p.ID, wh.ID)
	require.NoError(t, err)
	assert.False(t, needed)
}

func TestOrderStatusTransitions(t *testing.T) {
	db := testDB(t)
	productRepo := repository.NewProductRepo(db)
	warehouseRepo := repository.NewWarehouseRepo(db)
	inventoryRepo := repository.NewInventoryRepo(db)
	orderRepo := repository.NewOrderRepo(db)
	invSvc := service.NewInventoryService(inventoryRepo, warehouseRepo)
	orderSvc := service.NewOrderService(orderRepo, invSvc, productRepo)

	wh := &model.Warehouse{
		ID: uuid.New(), Name: fmt.Sprintf("Trans WH %d", time.Now().UnixNano()),
		MaxCapacity: 500, IsActive: true,
	}
	require.NoError(t, warehouseRepo.Create(wh))
	p := &model.Product{
		ID: uuid.New(), SKU: fmt.Sprintf("TR-%d", time.Now().UnixNano()),
		Name: "Transition Product", UnitPrice: 14.99,
	}
	require.NoError(t, productRepo.Create(p))
	inv := &model.Inventory{
		ID: uuid.New(), ProductID: p.ID, WarehouseID: wh.ID,
		Quantity: 200, ReorderPoint: 10, ReorderQuantity: 50,
	}
	require.NoError(t, inventoryRepo.Create(inv))

	req := &model.CreateOrderRequest{
		CustomerID: "CUST-TRANS",
		Items: []model.OrderItemRequest{
			{ProductID: p.ID.String(), WarehouseID: wh.ID.String(), Quantity: 3},
		},
	}
	order, _, err := orderSvc.Create(req)
	require.NoError(t, err)
	assert.Equal(t, "pending", string(order.Status))

	err = orderSvc.Transition(order.ID.String(), model.OrderStatus("fulfilled"))
	assert.Error(t, err)

	err = orderSvc.Transition(order.ID.String(), model.OrderStatus("confirmed"))
	require.NoError(t, err)

	err = orderSvc.Transition(order.ID.String(), model.OrderStatus("pending"))
	assert.Error(t, err)
}
