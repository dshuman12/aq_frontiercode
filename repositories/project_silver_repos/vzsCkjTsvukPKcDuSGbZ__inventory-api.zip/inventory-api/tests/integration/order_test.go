package integration

import (
	"testing"

	"github.com/google/uuid"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"inventoryapi.dev/api/internal/model"
	"inventoryapi.dev/api/internal/repository"
)

func TestOrderCreateAndRetrieve(t *testing.T) {
	if testDB == nil {
		t.Skip("no test db")
	}

	orderRepo := repository.NewOrderRepo(testDB)
	prodRepo  := repository.NewProductRepo(testDB)
	whRepo    := repository.NewWarehouseRepo(testDB)
	invRepo   := repository.NewInventoryRepo(testDB)

	prod := &model.Product{SKU: "TEST-SKU-001", Name: "Test Product", UnitPrice: 100.0}
	require.NoError(t, prodRepo.Create(prod))

	wh := &model.Warehouse{Name: "Test WH", MaxCapacity: 1000}
	require.NoError(t, whRepo.Create(wh))

	inv := &model.Inventory{
		ProductID:   prod.ID,
		WarehouseID: wh.ID,
		Quantity:    50,
		ReorderPoint: 5,
		ReorderQuantity: 20,
	}
	require.NoError(t, invRepo.Create(inv))

	order := &model.Order{
		CustomerID:  "cust-test-001",
		Status:      model.StatusPending,
		TotalAmount: 200.0,
	}
	require.NoError(t, orderRepo.Create(order))
	assert.NotEqual(t, uuid.Nil, order.ID)

	item := &model.OrderItem{
		OrderID:      order.ID,
		ProductID:    prod.ID,
		WarehouseID:  wh.ID,
		RequestedQty: 2,
		UnitPrice:    prod.UnitPrice,
	}
	require.NoError(t, orderRepo.AddItem(item))

	fetched, err := orderRepo.GetByID(order.ID)
	require.NoError(t, err)
	assert.Equal(t, model.StatusPending, fetched.Status)
	assert.Equal(t, "cust-test-001", fetched.CustomerID)

	items, err := orderRepo.GetItems(order.ID)
	require.NoError(t, err)
	assert.Len(t, items, 1)
	assert.Equal(t, 2, items[0].RequestedQty)
}

func TestOrderStatusTransition(t *testing.T) {
	if testDB == nil {
		t.Skip("no test db")
	}

	orderRepo := repository.NewOrderRepo(testDB)

	order := &model.Order{
		CustomerID: "cust-test-002",
		Status:     model.StatusPending,
	}
	require.NoError(t, orderRepo.Create(order))

	require.NoError(t, orderRepo.UpdateStatus(order.ID, model.StatusConfirmed))

	updated, err := orderRepo.GetByID(order.ID)
	require.NoError(t, err)
	assert.Equal(t, model.StatusConfirmed, updated.Status)
}
