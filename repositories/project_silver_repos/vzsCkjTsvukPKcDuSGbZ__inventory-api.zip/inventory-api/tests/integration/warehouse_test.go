package integration_test

import (
	"fmt"
	"testing"
	"time"

	"github.com/google/uuid"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"inventoryapi.dev/api/internal/model"
	"inventoryapi.dev/api/internal/repository"
	"inventoryapi.dev/api/internal/service"
)

func TestWarehouse_CreateAndRetrieve(t *testing.T) {
	db := testDB(t)
	repo := repository.NewWarehouseRepo(db)

	wh := &model.Warehouse{
		ID: uuid.New(), Name: fmt.Sprintf("Integration WH %d", time.Now().UnixNano()),
		Location: "Mumbai, India", MaxCapacity: 5000, IsActive: true,
	}
	require.NoError(t, repo.Create(wh))

	fetched, err := repo.GetByID(wh.ID)
	require.NoError(t, err)
	assert.Equal(t, wh.Name, fetched.Name)
	assert.Equal(t, wh.Location, fetched.Location)
	assert.Equal(t, wh.MaxCapacity, fetched.MaxCapacity)
	assert.True(t, fetched.IsActive)
}

func TestWarehouse_ListActiveOnly(t *testing.T) {
	db := testDB(t)
	repo := repository.NewWarehouseRepo(db)

	active := &model.Warehouse{
		ID: uuid.New(), Name: fmt.Sprintf("Active WH %d", time.Now().UnixNano()),
		MaxCapacity: 1000, IsActive: true,
	}
	inactive := &model.Warehouse{
		ID: uuid.New(), Name: fmt.Sprintf("Inactive WH %d", time.Now().UnixNano()),
		MaxCapacity: 500, IsActive: false,
	}
	require.NoError(t, repo.Create(active))
	require.NoError(t, repo.Create(inactive))

	activeList, err := repo.List(true)
	require.NoError(t, err)
	for _, wh := range activeList {
		assert.True(t, wh.IsActive)
	}

	allList, err := repo.List(false)
	require.NoError(t, err)
	assert.True(t, len(allList) >= len(activeList))
}

func TestWarehouse_Deactivate(t *testing.T) {
	db := testDB(t)
	repo := repository.NewWarehouseRepo(db)
	svc := service.NewWarehouseService(repo)

	wh := &model.Warehouse{
		ID: uuid.New(), Name: fmt.Sprintf("Deactivate WH %d", time.Now().UnixNano()),
		MaxCapacity: 2000, IsActive: true,
	}
	require.NoError(t, repo.Create(wh))

	err := svc.Deactivate(wh.ID.String())
	require.NoError(t, err)

	updated, err := repo.GetByID(wh.ID)
	require.NoError(t, err)
	assert.False(t, updated.IsActive)
}

func TestWarehouse_CapacityInfo(t *testing.T) {
	db := testDB(t)
	repo := repository.NewWarehouseRepo(db)
	svc := service.NewWarehouseService(repo)

	wh := &model.Warehouse{
		ID: uuid.New(), Name: fmt.Sprintf("Capacity WH %d", time.Now().UnixNano()),
		MaxCapacity: 1000, CurrentUsage: 600, IsActive: true,
	}
	require.NoError(t, repo.Create(wh))

	info, err := svc.GetCapacityInfo(wh.ID.String())
	require.NoError(t, err)
	assert.Equal(t, 1000, info["max_capacity"])
	assert.Equal(t, 600, info["current_usage"])
	assert.Equal(t, 400, info["available"])
	assert.Equal(t, 60.0, info["utilization_pct"])
}

func TestWarehouse_CanAccommodate_True(t *testing.T) {
	db := testDB(t)
	repo := repository.NewWarehouseRepo(db)
	svc := service.NewWarehouseService(repo)

	wh := &model.Warehouse{
		ID: uuid.New(), Name: fmt.Sprintf("Accommodate WH %d", time.Now().UnixNano()),
		MaxCapacity: 1000, CurrentUsage: 400, IsActive: true,
	}
	require.NoError(t, repo.Create(wh))

	canFit, err := svc.CanAccommodate(wh.ID.String(), 500)
	require.NoError(t, err)
	assert.True(t, canFit)
}

func TestWarehouse_CanAccommodate_False(t *testing.T) {
	db := testDB(t)
	repo := repository.NewWarehouseRepo(db)
	svc := service.NewWarehouseService(repo)

	wh := &model.Warehouse{
		ID: uuid.New(), Name: fmt.Sprintf("Full WH %d", time.Now().UnixNano()),
		MaxCapacity: 100, CurrentUsage: 90, IsActive: true,
	}
	require.NoError(t, repo.Create(wh))

	canFit, err := svc.CanAccommodate(wh.ID.String(), 50)
	require.NoError(t, err)
	assert.False(t, canFit)
}

func TestWarehouse_CanAccommodate_Inactive(t *testing.T) {
	db := testDB(t)
	repo := repository.NewWarehouseRepo(db)
	svc := service.NewWarehouseService(repo)

	wh := &model.Warehouse{
		ID: uuid.New(), Name: fmt.Sprintf("Inactive Capacity WH %d", time.Now().UnixNano()),
		MaxCapacity: 1000, CurrentUsage: 0, IsActive: false,
	}
	require.NoError(t, repo.Create(wh))

	canFit, err := svc.CanAccommodate(wh.ID.String(), 10)
	require.NoError(t, err)
	assert.False(t, canFit)
}

func TestWarehouse_ValidateTransfer_SameWarehouse(t *testing.T) {
	db := testDB(t)
	repo := repository.NewWarehouseRepo(db)
	svc := service.NewWarehouseService(repo)

	wh := &model.Warehouse{
		ID: uuid.New(), Name: fmt.Sprintf("Same WH %d", time.Now().UnixNano()),
		MaxCapacity: 1000, IsActive: true,
	}
	require.NoError(t, repo.Create(wh))

	err := svc.ValidateTransfer(wh.ID.String(), wh.ID.String(), 10)
	assert.Error(t, err)
	assert.Contains(t, err.Error(), "different")
}

func TestWarehouse_ValidateTransfer_NegativeQty(t *testing.T) {
	db := testDB(t)
	repo := repository.NewWarehouseRepo(db)
	svc := service.NewWarehouseService(repo)

	wh1 := &model.Warehouse{ID: uuid.New(), Name: fmt.Sprintf("WH1 %d", time.Now().UnixNano()), MaxCapacity: 1000, IsActive: true}
	wh2 := &model.Warehouse{ID: uuid.New(), Name: fmt.Sprintf("WH2 %d", time.Now().UnixNano()), MaxCapacity: 1000, IsActive: true}
	require.NoError(t, repo.Create(wh1))
	require.NoError(t, repo.Create(wh2))

	err := svc.ValidateTransfer(wh1.ID.String(), wh2.ID.String(), -5)
	assert.Error(t, err)
}

func TestWarehouse_GetAllActive_ReturnsOnlyActive(t *testing.T) {
	db := testDB(t)
	repo := repository.NewWarehouseRepo(db)
	svc := service.NewWarehouseService(repo)

	active := []*model.Warehouse{
		{ID: uuid.New(), Name: fmt.Sprintf("A1 %d", time.Now().UnixNano()), MaxCapacity: 100, IsActive: true},
		{ID: uuid.New(), Name: fmt.Sprintf("A2 %d", time.Now().UnixNano()), MaxCapacity: 200, IsActive: true},
	}
	inactive := &model.Warehouse{
		ID: uuid.New(), Name: fmt.Sprintf("I1 %d", time.Now().UnixNano()),
		MaxCapacity: 300, IsActive: false,
	}
	for _, wh := range active {
		require.NoError(t, repo.Create(wh))
	}
	require.NoError(t, repo.Create(inactive))

	result, err := svc.GetAllActive()
	require.NoError(t, err)
	for _, wh := range result {
		assert.True(t, wh.IsActive)
	}
}
