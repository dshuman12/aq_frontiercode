package integration_test

import (
	"context"
	"testing"

	"github.com/google/uuid"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"inventoryapi.dev/api/internal/audit"
)

func TestAudit_Log_InsertsRecord(t *testing.T) {
	db := testDB(t)
	logger := audit.New(db)
	entityID := uuid.New()
	actorID := uuid.New()
	err := logger.Log(context.Background(), "product", entityID, "create", &actorID, "127.0.0.1", nil, map[string]string{"name": "test"})
	require.NoError(t, err)
}

func TestAudit_GetEntityHistory_ReturnsLogs(t *testing.T) {
	db := testDB(t)
	logger := audit.New(db)
	entityID := uuid.New()
	actorID := uuid.New()
	logger.Log(context.Background(), "product", entityID, "create", &actorID, "127.0.0.1", nil, nil)
	logger.Log(context.Background(), "product", entityID, "update", &actorID, "127.0.0.1", nil, nil)
	rows, err := logger.GetEntityHistory(context.Background(), "product", entityID)
	require.NoError(t, err)
	assert.Len(t, rows, 2)
}

func TestAudit_GetActorActivity_FiltersCorrectly(t *testing.T) {
	db := testDB(t)
	logger := audit.New(db)
	actorA := uuid.New()
	actorB := uuid.New()
	logger.Log(context.Background(), "order", uuid.New(), "create", &actorA, "1.1.1.1", nil, nil)
	logger.Log(context.Background(), "order", uuid.New(), "create", &actorB, "2.2.2.2", nil, nil)
	rows, err := logger.GetActorActivity(context.Background(), actorA, 10)
	require.NoError(t, err)
	for _, r := range rows {
		assert.Equal(t, actorA, *r.ActorID)
	}
}

func TestAudit_Query_WithFilter(t *testing.T) {
	db := testDB(t)
	logger := audit.New(db)
	entityID := uuid.New()
	actorID := uuid.New()
	logger.Log(context.Background(), "warehouse", entityID, "update", &actorID, "127.0.0.1", nil, nil)
	filter := audit.AuditFilter{EntityType: "warehouse", Limit: 10}
	rows, total, err := logger.Query(context.Background(), filter)
	require.NoError(t, err)
	assert.True(t, total >= 1)
	assert.NotEmpty(t, rows)
}
