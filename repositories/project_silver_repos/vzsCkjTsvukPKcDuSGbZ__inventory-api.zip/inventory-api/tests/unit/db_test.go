package unit_test

import (
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"inventoryapi.dev/api/internal/db"
)

func TestQueryBuilder_Empty(t *testing.T) {
	q := db.NewQuery("products")
	where, args := q.BuildWhere()
	assert.Equal(t, "", where)
	assert.Empty(t, args)
}

func TestQueryBuilder_SingleWhere(t *testing.T) {
	q := db.NewQuery("products")
	q.Where("category = ?", "Electronics")
	where, args := q.BuildWhere()
	assert.Contains(t, where, "WHERE")
	assert.Len(t, args, 1)
	assert.Equal(t, "Electronics", args[0])
}

func TestQueryBuilder_MultipleWhere(t *testing.T) {
	q := db.NewQuery("products")
	q.Where("category = ?", "Electronics")
	q.Where("unit_price > ?", 10.0)
	where, args := q.BuildWhere()
	assert.Contains(t, where, "AND")
	assert.Len(t, args, 2)
}

func TestQueryBuilder_WhereEqual(t *testing.T) {
	q := db.NewQuery("products")
	q.WhereEqual("status", "active")
	where, args := q.BuildWhere()
	assert.Contains(t, where, "status = $1")
	assert.Equal(t, "active", args[0])
}

func TestQueryBuilder_WhereLike(t *testing.T) {
	q := db.NewQuery("products")
	q.WhereLike("name", "widget")
	where, args := q.BuildWhere()
	assert.Contains(t, where, "ILIKE")
	assert.Equal(t, "%widget%", args[0])
}

func TestQueryBuilder_WhereDateAfter(t *testing.T) {
	q := db.NewQuery("orders")
	t1 := time.Now().AddDate(0, 0, -7)
	q.WhereDateAfter("created_at", t1)
	where, args := q.BuildWhere()
	assert.Contains(t, where, ">=")
	assert.Len(t, args, 1)
}

func TestQueryBuilder_WhereDateBefore(t *testing.T) {
	q := db.NewQuery("orders")
	t1 := time.Now()
	q.WhereDateBefore("created_at", t1)
	where, args := q.BuildWhere()
	assert.Contains(t, where, "<=")
	assert.Len(t, args, 1)
}

func TestQueryBuilder_WhereNotDeleted(t *testing.T) {
	q := db.NewQuery("products")
	q.WhereNotDeleted()
	where, _ := q.BuildWhere()
	assert.Contains(t, where, "deleted_at IS NULL")
}

func TestQueryBuilder_Limit(t *testing.T) {
	q := db.NewQuery("products")
	q.Limit(50)
	_, args := q.BuildSelect("*")
	assert.Contains(t, args, 50)
}

func TestQueryBuilder_Offset(t *testing.T) {
	q := db.NewQuery("products")
	q.Offset(20)
	_, args := q.BuildSelect("*")
	assert.Contains(t, args, 20)
}

func TestQueryBuilder_OrderBy_Valid(t *testing.T) {
	q := db.NewQuery("products")
	q.OrderBy("name", "asc")
	query, _ := q.BuildSelect("*")
	assert.Contains(t, query, "ORDER BY name ASC")
}

func TestQueryBuilder_OrderBy_InvalidDir(t *testing.T) {
	q := db.NewQuery("products")
	q.OrderBy("name", "invalid")
	query, _ := q.BuildSelect("*")
	assert.Contains(t, query, "DESC")
}

func TestBuildInsert_Basic(t *testing.T) {
	sql := db.BuildInsert("products", []string{"sku", "name", "unit_price"})
	assert.Contains(t, sql, "INSERT INTO products")
	assert.Contains(t, sql, "sku, name, unit_price")
	assert.Contains(t, sql, "$1")
	assert.Contains(t, sql, "$2")
	assert.Contains(t, sql, "$3")
	assert.Contains(t, sql, "RETURNING *")
}

func TestBuildUpdate_Basic(t *testing.T) {
	sql := db.BuildUpdate("products", []string{"name", "unit_price"}, 3)
	assert.Contains(t, sql, "UPDATE products SET")
	assert.Contains(t, sql, "name = $1")
	assert.Contains(t, sql, "unit_price = $2")
	assert.Contains(t, sql, "WHERE id = $3")
	assert.Contains(t, sql, "RETURNING *")
}

func TestBuildSoftDelete(t *testing.T) {
	sql := db.BuildSoftDelete("products")
	assert.Contains(t, sql, "UPDATE products")
	assert.Contains(t, sql, "deleted_at = NOW()")
	assert.Contains(t, sql, "WHERE id = $1")
}

func TestPaginate_FirstPage(t *testing.T) {
	limit, offset := db.Paginate(1, 20)
	assert.Equal(t, 20, limit)
	assert.Equal(t, 0, offset)
}

func TestPaginate_SecondPage(t *testing.T) {
	limit, offset := db.Paginate(2, 20)
	assert.Equal(t, 20, limit)
	assert.Equal(t, 20, offset)
}

func TestPaginate_InvalidPage(t *testing.T) {
	limit, offset := db.Paginate(0, 20)
	assert.Equal(t, 20, limit)
	assert.Equal(t, 0, offset)
}

func TestPaginate_MaxPageSize(t *testing.T) {
	limit, _ := db.Paginate(1, 500)
	assert.Equal(t, 100, limit)
}

func TestQueryBuilder_WhereIn_Empty(t *testing.T) {
	q := db.NewQuery("orders")
	q.WhereIn("status", []any{})
	where, _ := q.BuildWhere()
	assert.Equal(t, "", where)
}

func TestQueryBuilder_WhereIn_Values(t *testing.T) {
	q := db.NewQuery("orders")
	q.WhereIn("status", []any{"pending", "confirmed"})
	where, args := q.BuildWhere()
	assert.Contains(t, where, "IN")
	assert.Len(t, args, 2)
}

func TestQueryBuilder_BuildCount(t *testing.T) {
	q := db.NewQuery("products")
	q.Where("category = ?", "Electronics")
	sql, args := q.BuildCount()
	assert.Contains(t, sql, "COUNT(*)")
	assert.Contains(t, sql, "FROM products")
	assert.Len(t, args, 1)
}
