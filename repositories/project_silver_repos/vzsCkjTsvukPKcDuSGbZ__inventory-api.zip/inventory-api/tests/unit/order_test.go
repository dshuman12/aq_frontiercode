package unit

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"inventoryapi.dev/api/internal/model"
)

func TestOrderStatusConstants(t *testing.T) {
	assert.Equal(t, model.OrderStatus("pending"),   model.StatusPending)
	assert.Equal(t, model.OrderStatus("confirmed"),  model.StatusConfirmed)
	assert.Equal(t, model.OrderStatus("shipped"),    model.StatusShipped)
	assert.Equal(t, model.OrderStatus("delivered"),  model.StatusDelivered)
	assert.Equal(t, model.OrderStatus("cancelled"),  model.StatusCancelled)
}

func TestOrderInvalidTransition(t *testing.T) {
	assert.EqualError(t, model.ErrInvalidTransition, "invalid status transition")
}

func TestCreateOrderRequestValidation(t *testing.T) {
	req := model.CreateOrderRequest{
		CustomerID: "cust-123",
		Items: []model.CreateOrderItemRequest{
			{ProductID: "some-id", WarehouseID: "wh-id", Quantity: 5},
		},
	}
	assert.NotEmpty(t, req.CustomerID)
	assert.Len(t, req.Items, 1)
	assert.Equal(t, 5, req.Items[0].Quantity)
}

func TestOrderItemUnitPrice(t *testing.T) {
	item := model.OrderItem{
		RequestedQty: 3,
		UnitPrice:    99.99,
	}
	total := float64(item.RequestedQty) * item.UnitPrice
	assert.InDelta(t, 299.97, total, 0.01)
}

func TestOrderRequiresAtLeastOneItem(t *testing.T) {
	req := model.CreateOrderRequest{
		CustomerID: "cust-456",
		Items:      []model.CreateOrderItemRequest{},
	}
	assert.Empty(t, req.Items)
}
