package unit_test

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"inventoryapi.dev/api/internal/pagination"
)

func TestPagination_FromQuery_Defaults(t *testing.T) {
	p := pagination.Params{Limit: 20, Offset: 0, SortBy: "created_at", SortDir: "desc"}
	assert.Equal(t, 20, p.Limit)
	assert.Equal(t, 0, p.Offset)
}

func TestPagination_Validate_ValidParams(t *testing.T) {
	p := pagination.Params{Limit: 20, Offset: 0}
	assert.NoError(t, p.Validate())
}

func TestPagination_Validate_ZeroLimit(t *testing.T) {
	p := pagination.Params{Limit: 0, Offset: 0}
	assert.Error(t, p.Validate())
}

func TestPagination_Validate_NegativeOffset(t *testing.T) {
	p := pagination.Params{Limit: 10, Offset: -1}
	assert.Error(t, p.Validate())
}

func TestPagination_Validate_OverMaxLimit(t *testing.T) {
	p := pagination.Params{Limit: 1000, Offset: 0}
	assert.Error(t, p.Validate())
}

func TestPagination_NewMeta_CorrectPages(t *testing.T) {
	m := pagination.NewMeta(100, 20, 0)
	assert.Equal(t, 100, m.Total)
	assert.Equal(t, 5, m.Pages)
	assert.Equal(t, 1, m.Page)
	assert.True(t, m.HasNext)
	assert.False(t, m.HasPrev)
}

func TestPagination_NewMeta_LastPage(t *testing.T) {
	m := pagination.NewMeta(100, 20, 80)
	assert.Equal(t, 5, m.Page)
	assert.False(t, m.HasNext)
	assert.True(t, m.HasPrev)
}

func TestPagination_NewMeta_SinglePage(t *testing.T) {
	m := pagination.NewMeta(5, 20, 0)
	assert.Equal(t, 1, m.Pages)
	assert.False(t, m.HasNext)
	assert.False(t, m.HasPrev)
}

func TestPagination_BuildOrderClause_ValidField(t *testing.T) {
	p := pagination.Params{SortBy: "name", SortDir: "asc"}
	clause, err := pagination.BuildOrderClause(p, []string{"name", "created_at"})
	assert.NoError(t, err)
	assert.Equal(t, "ORDER BY name ASC", clause)
}

func TestPagination_BuildOrderClause_InvalidField(t *testing.T) {
	p := pagination.Params{SortBy: "malicious_field", SortDir: "asc"}
	clause, err := pagination.BuildOrderClause(p, []string{"name", "created_at"})
	assert.NoError(t, err)
	assert.Equal(t, "ORDER BY created_at DESC", clause)
}

func TestPagination_BuildOrderClause_Descending(t *testing.T) {
	p := pagination.Params{SortBy: "created_at", SortDir: "desc"}
	clause, _ := pagination.BuildOrderClause(p, []string{"name", "created_at"})
	assert.Contains(t, clause, "DESC")
}
