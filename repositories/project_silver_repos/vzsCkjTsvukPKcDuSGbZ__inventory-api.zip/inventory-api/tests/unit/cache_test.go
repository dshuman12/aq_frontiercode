package unit_test

import (
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"inventoryapi.dev/api/internal/cache"
)

func TestCache_SetAndGet(t *testing.T) {
	c := cache.New(5 * time.Minute)
	c.Set("key1", "value1")
	v, ok := c.Get("key1")
	assert.True(t, ok)
	assert.Equal(t, "value1", v)
}

func TestCache_GetMissing(t *testing.T) {
	c := cache.New(5 * time.Minute)
	_, ok := c.Get("nonexistent")
	assert.False(t, ok)
}

func TestCache_TTLExpiry(t *testing.T) {
	c := cache.New(5 * time.Minute)
	c.SetWithTTL("expiring", "val", 1*time.Millisecond)
	time.Sleep(5 * time.Millisecond)
	_, ok := c.Get("expiring")
	assert.False(t, ok)
}

func TestCache_Delete(t *testing.T) {
	c := cache.New(5 * time.Minute)
	c.Set("k", "v")
	c.Delete("k")
	_, ok := c.Get("k")
	assert.False(t, ok)
}

func TestCache_Flush(t *testing.T) {
	c := cache.New(5 * time.Minute)
	c.Set("a", 1)
	c.Set("b", 2)
	c.Set("c", 3)
	c.Flush()
	assert.Equal(t, 0, c.Size())
}

func TestCache_Size(t *testing.T) {
	c := cache.New(5 * time.Minute)
	assert.Equal(t, 0, c.Size())
	c.Set("x", 1)
	assert.Equal(t, 1, c.Size())
	c.Set("y", 2)
	assert.Equal(t, 2, c.Size())
}

func TestCache_Has(t *testing.T) {
	c := cache.New(5 * time.Minute)
	assert.False(t, c.Has("missing"))
	c.Set("present", true)
	assert.True(t, c.Has("present"))
}

func TestCache_OverwriteKey(t *testing.T) {
	c := cache.New(5 * time.Minute)
	c.Set("k", "first")
	c.Set("k", "second")
	v, ok := c.Get("k")
	assert.True(t, ok)
	assert.Equal(t, "second", v)
}
