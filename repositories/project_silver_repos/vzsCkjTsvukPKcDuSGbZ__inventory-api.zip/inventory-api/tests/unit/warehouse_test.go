package unit_test

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"inventoryapi.dev/api/internal/model"
)

func TestWarehouse_IsActive_DefaultTrue(t *testing.T) {
	w := model.Warehouse{IsActive: true}
	assert.True(t, w.IsActive)
}

func TestWarehouse_CapacityCalc_Available(t *testing.T) {
	w := model.Warehouse{MaxCapacity: 1000, CurrentUsage: 750}
	available := w.MaxCapacity - w.CurrentUsage
	assert.Equal(t, 250, available)
}

func TestWarehouse_CapacityCalc_UtilizationPct(t *testing.T) {
	maxCap := 1000
	current := 600
	pct := float64(current) / float64(maxCap) * 100
	assert.Equal(t, 60.0, pct)
}

func TestWarehouse_CapacityCalc_FullWarehouse(t *testing.T) {
	w := model.Warehouse{MaxCapacity: 100, CurrentUsage: 100}
	canFit := w.CurrentUsage+10 <= w.MaxCapacity
	assert.False(t, canFit)
}

func TestWarehouse_CapacityCalc_ZeroMaxCapacity(t *testing.T) {
	maxCap := 0
	pct := 0.0
	if maxCap > 0 {
		pct = float64(50) / float64(maxCap) * 100
	}
	assert.Equal(t, 0.0, pct)
}

func TestWarehouse_NearCapacityThreshold(t *testing.T) {
	maxCap := 1000
	current := 900
	pct := float64(current) / float64(maxCap) * 100
	isNear := pct > 85.0
	assert.True(t, isNear)
}

func TestWarehouse_AvailableSpace(t *testing.T) {
	w := model.Warehouse{MaxCapacity: 500, CurrentUsage: 200}
	assert.Equal(t, 300, w.AvailableSpace())
}
