package unit_test

import (
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"inventoryapi.dev/api/internal/validator"
)

func TestValidator_IsValidUUID_Valid(t *testing.T) {
	assert.True(t, validator.IsValidUUID("550e8400-e29b-41d4-a716-446655440000"))
}

func TestValidator_IsValidUUID_Invalid(t *testing.T) {
	assert.False(t, validator.IsValidUUID("not-a-uuid"))
	assert.False(t, validator.IsValidUUID(""))
	assert.False(t, validator.IsValidUUID("12345"))
}

func TestValidator_IsValidEmail_Valid(t *testing.T) {
	assert.True(t, validator.IsValidEmail("user@example.com"))
	assert.True(t, validator.IsValidEmail("test.user+tag@domain.co.uk"))
}

func TestValidator_IsValidEmail_Invalid(t *testing.T) {
	assert.False(t, validator.IsValidEmail("notanemail"))
	assert.False(t, validator.IsValidEmail("@domain.com"))
	assert.False(t, validator.IsValidEmail("user@"))
	assert.False(t, validator.IsValidEmail(""))
}

func TestValidator_IsValidSKU_Valid(t *testing.T) {
	assert.True(t, validator.IsValidSKU("SKU-001"))
	assert.True(t, validator.IsValidSKU("PROD123"))
	assert.True(t, validator.IsValidSKU("ABC_DEF"))
}

func TestValidator_IsValidSKU_Invalid(t *testing.T) {
	assert.False(t, validator.IsValidSKU("ab"))
	assert.False(t, validator.IsValidSKU("has spaces"))
	assert.False(t, validator.IsValidSKU(""))
}

func TestValidator_IsPositiveInt(t *testing.T) {
	assert.True(t, validator.IsPositiveInt(1))
	assert.True(t, validator.IsPositiveInt(100))
	assert.False(t, validator.IsPositiveInt(0))
	assert.False(t, validator.IsPositiveInt(-1))
}

func TestValidator_IsNonNegativeInt(t *testing.T) {
	assert.True(t, validator.IsNonNegativeInt(0))
	assert.True(t, validator.IsNonNegativeInt(1))
	assert.False(t, validator.IsNonNegativeInt(-1))
}

func TestValidator_IsValidDateRange_Valid(t *testing.T) {
	from := time.Now().AddDate(0, 0, -7)
	to := time.Now()
	assert.True(t, validator.IsValidDateRange(from, to))
}

func TestValidator_IsValidDateRange_InvalidOrder(t *testing.T) {
	from := time.Now()
	to := time.Now().AddDate(0, 0, -7)
	assert.False(t, validator.IsValidDateRange(from, to))
}

func TestValidator_IsValidDateRange_SameTime(t *testing.T) {
	t1 := time.Now()
	assert.True(t, validator.IsValidDateRange(t1, t1))
}

func TestValidator_IsInRange(t *testing.T) {
	assert.True(t, validator.IsInRange(5, 1, 10))
	assert.True(t, validator.IsInRange(1, 1, 10))
	assert.True(t, validator.IsInRange(10, 1, 10))
	assert.False(t, validator.IsInRange(0, 1, 10))
	assert.False(t, validator.IsInRange(11, 1, 10))
}

func TestValidator_IsValidStatus(t *testing.T) {
	allowed := []string{"pending", "confirmed", "fulfilled"}
	assert.True(t, validator.IsValidStatus("pending", allowed))
	assert.True(t, validator.IsValidStatus("fulfilled", allowed))
	assert.False(t, validator.IsValidStatus("invalid", allowed))
	assert.False(t, validator.IsValidStatus("", allowed))
}

func TestValidator_IsValidPagination(t *testing.T) {
	assert.True(t, validator.IsValidPagination(20, 0))
	assert.True(t, validator.IsValidPagination(1, 0))
	assert.True(t, validator.IsValidPagination(100, 50))
	assert.False(t, validator.IsValidPagination(0, 0))
	assert.False(t, validator.IsValidPagination(101, 0))
	assert.False(t, validator.IsValidPagination(10, -1))
}

func TestValidator_SanitizeString(t *testing.T) {
	assert.Equal(t, "hello world", validator.SanitizeString("  hello world  "))
	assert.Equal(t, "test", validator.SanitizeString("test"))
}

func TestValidator_NormalizeSKU(t *testing.T) {
	assert.Equal(t, "SKU-001", validator.NormalizeSKU("sku-001"))
	assert.Equal(t, "PROD123", validator.NormalizeSKU("  prod123  "))
}

func TestValidator_MultiError_AddAndCheck(t *testing.T) {
	me := validator.NewMultiError()
	assert.False(t, me.HasErrors())
	me.Add("name", "is required")
	me.Add("price", "must be positive")
	assert.True(t, me.HasErrors())
	assert.Contains(t, me.Error(), "name")
	assert.Contains(t, me.Error(), "price")
}

func TestValidator_ValidateRequired_AllPresent(t *testing.T) {
	fields := map[string]string{"name": "Widget", "sku": "SKU-001"}
	err := validator.ValidateRequired(fields)
	assert.NoError(t, err)
}

func TestValidator_ValidateRequired_MissingField(t *testing.T) {
	fields := map[string]string{"name": "", "sku": "SKU-001"}
	err := validator.ValidateRequired(fields)
	assert.Error(t, err)
}
