package unit_test

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"inventoryapi.dev/api/internal/search"
)

func TestSearchBuilder_EmptyQuery(t *testing.T) {
	b := search.NewBuilder()
	where, args := b.Build()
	assert.Equal(t, "", where)
	assert.Empty(t, args)
}

func TestSearchBuilder_TextSearch(t *testing.T) {
	b := search.NewBuilder()
	b.AddTextSearch("widget", []string{"name", "description"})
	where, args := b.Build()
	assert.Contains(t, where, "ILIKE")
	assert.Contains(t, where, "name")
	assert.Contains(t, where, "description")
	assert.Len(t, args, 2)
	assert.Equal(t, "%widget%", args[0])
}

func TestSearchBuilder_StatusFilter(t *testing.T) {
	b := search.NewBuilder()
	b.AddStatusFilter([]string{"pending", "confirmed"})
	where, args := b.Build()
	assert.Contains(t, where, "ANY")
	assert.Len(t, args, 1)
}

func TestSearchBuilder_EmptyStatusFilter(t *testing.T) {
	b := search.NewBuilder()
	b.AddStatusFilter([]string{})
	where, _ := b.Build()
	assert.Equal(t, "", where)
}

func TestSearchBuilder_OrderClause_Valid(t *testing.T) {
	b := search.NewBuilder()
	clause := b.BuildOrderClause([]string{"name", "created_at", "price"}, "name", "asc")
	assert.Equal(t, "ORDER BY name ASC", clause)
}

func TestSearchBuilder_OrderClause_InvalidField(t *testing.T) {
	b := search.NewBuilder()
	clause := b.BuildOrderClause([]string{"name", "created_at"}, "evil_field", "asc")
	assert.Equal(t, "ORDER BY created_at DESC", clause)
}

func TestSearchBuilder_ChainedConditions(t *testing.T) {
	b := search.NewBuilder()
	b.AddTextSearch("test", []string{"name"})
	b.AddStatusFilter([]string{"active"})
	where, args := b.Build()
	assert.Contains(t, where, "AND")
	assert.Len(t, args, 2)
}
