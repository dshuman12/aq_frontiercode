package unit

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"inventoryapi.dev/api/internal/model"
)

func TestProductSKUUppercase(t *testing.T) {
	req := &model.CreateProductRequest{
		SKU:       "laptop-001",
		Name:      "Laptop",
		UnitPrice: 999.99,
	}
	assert.NotEmpty(t, req.SKU)
}

func TestProductPricePositive(t *testing.T) {
	req := &model.CreateProductRequest{
		SKU:       "TEST-001",
		Name:      "Test Product",
		UnitPrice: 100.0,
	}
	assert.Greater(t, req.UnitPrice, 0.0)
}

func TestProductPriceNegative(t *testing.T) {
	req := &model.CreateProductRequest{
		SKU:       "TEST-002",
		Name:      "Invalid Product",
		UnitPrice: -50.0,
	}
	assert.Less(t, req.UnitPrice, 0.0, "negative price should fail validation")
}

func TestProductUpdateNilFields(t *testing.T) {
	req := &model.UpdateProductRequest{}
	assert.Nil(t, req.Name)
	assert.Nil(t, req.UnitPrice)
}

func TestProductUpdateWithValues(t *testing.T) {
	name := "Updated Name"
	price := 199.99
	req := &model.UpdateProductRequest{
		Name:      &name,
		UnitPrice: &price,
	}
	assert.Equal(t, "Updated Name", *req.Name)
	assert.Equal(t, 199.99, *req.UnitPrice)
}

func TestProductErrors(t *testing.T) {
	assert.EqualError(t, model.ErrDuplicateSKU, "sku already exists")
	assert.EqualError(t, model.ErrNotFound, "record not found")
}
