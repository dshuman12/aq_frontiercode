package unit

import (
	"testing"

	"github.com/google/uuid"
	"github.com/stretchr/testify/assert"
	"inventoryapi.dev/api/internal/model"
)

func TestInventoryAvailable(t *testing.T) {
	inv := &model.Inventory{
		ID:               uuid.New(),
		Quantity:         100,
		ReservedQuantity: 30,
	}
	assert.Equal(t, 70, inv.Available())
}

func TestInventoryAvailableZeroReserved(t *testing.T) {
	inv := &model.Inventory{
		Quantity:         50,
		ReservedQuantity: 0,
	}
	assert.Equal(t, 50, inv.Available())
}

func TestInventoryAvailableFullyReserved(t *testing.T) {
	inv := &model.Inventory{
		Quantity:         100,
		ReservedQuantity: 100,
	}
	assert.Equal(t, 0, inv.Available())
}

func TestInventoryReservationCheck(t *testing.T) {
	inv := &model.Inventory{
		Quantity:         50,
		ReservedQuantity: 45,
	}
	want := 10
	available := inv.Available()
	assert.Less(t, available, want, "should not be able to reserve more than available")
}

func TestInventoryErrors(t *testing.T) {
	assert.EqualError(t, model.ErrInsufficientStock, "insufficient stock")
	assert.EqualError(t, model.ErrWarehouseFull, "warehouse at capacity")
}
