package unit_test

import (
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
)

func TestReport_DateRange_DefaultLast30Days(t *testing.T) {
	to := time.Now()
	from := to.AddDate(0, 0, -30)
	assert.True(t, to.After(from))
	assert.Equal(t, 30, int(to.Sub(from).Hours()/24))
}

func TestReport_StatusCount_PercentageCalculation(t *testing.T) {
	total := 100
	fulfilled := 60
	pct := float64(fulfilled) / float64(total) * 100
	assert.Equal(t, 60.0, pct)
}

func TestReport_StatusCount_ZeroTotal(t *testing.T) {
	total := 0
	var pct float64
	if total > 0 {
		pct = float64(10) / float64(total) * 100
	}
	assert.Equal(t, 0.0, pct)
}

func TestReport_WarehouseUtilization_PctCalc(t *testing.T) {
	max := 1000
	current := 750
	pct := float64(current) / float64(max) * 100
	assert.Equal(t, 75.0, pct)
}

func TestReport_RevenueTrend_DaysParam(t *testing.T) {
	days := 30
	since := time.Now().AddDate(0, 0, -days)
	assert.True(t, time.Now().After(since))
}

func TestReport_LowStock_AvailableCalc(t *testing.T) {
	qty := 50
	reserved := 20
	available := qty - reserved
	reorderPoint := 35
	assert.Equal(t, 30, available)
	assert.True(t, available < reorderPoint)
}

func TestReport_TopProducts_LimitDefault(t *testing.T) {
	limit := 0
	if limit <= 0 {
		limit = 10
	}
	assert.Equal(t, 10, limit)
}

func TestReport_SummaryReport_AvgOrderValue(t *testing.T) {
	revenue := 5000.0
	count := 25
	avg := revenue / float64(count)
	assert.Equal(t, 200.0, avg)
}
