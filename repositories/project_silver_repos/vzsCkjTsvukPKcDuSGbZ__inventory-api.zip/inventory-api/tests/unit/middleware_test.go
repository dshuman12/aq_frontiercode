package unit_test

import (
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"inventoryapi.dev/api/internal/middleware"
)

func setupMiddlewareRouter(mw ...gin.HandlerFunc) *gin.Engine {
	gin.SetMode(gin.TestMode)
	r := gin.New()
	r.Use(mw...)
	r.GET("/test", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{"ok": true})
	})
	return r
}

func TestMiddleware_Recovery_PanicRecovery(t *testing.T) {
	r := gin.New()
	r.Use(middleware.Recovery())
	r.GET("/panic", func(c *gin.Context) {
		panic("test panic")
	})
	req := httptest.NewRequest(http.MethodGet, "/panic", nil)
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)
	assert.Equal(t, http.StatusInternalServerError, w.Code)
}

func TestMiddleware_Recovery_NormalRequest(t *testing.T) {
	r := setupMiddlewareRouter(middleware.Recovery())
	req := httptest.NewRequest(http.MethodGet, "/test", nil)
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)
	assert.Equal(t, http.StatusOK, w.Code)
}

func TestMiddleware_RequestID_AddedToResponse(t *testing.T) {
	r := setupMiddlewareRouter(middleware.RequestID())
	req := httptest.NewRequest(http.MethodGet, "/test", nil)
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)
	assert.Equal(t, http.StatusOK, w.Code)
	assert.NotEmpty(t, w.Header().Get("X-Request-ID"))
}

func TestMiddleware_RequestID_PreservesExisting(t *testing.T) {
	r := setupMiddlewareRouter(middleware.RequestID())
	req := httptest.NewRequest(http.MethodGet, "/test", nil)
	req.Header.Set("X-Request-ID", "custom-id-123")
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)
	assert.Equal(t, "custom-id-123", w.Header().Get("X-Request-ID"))
}

func TestMiddleware_CORS_AllowsAllOrigins(t *testing.T) {
	cfg := middleware.DefaultCORSConfig()
	r := setupMiddlewareRouter(middleware.CORS(cfg))
	req := httptest.NewRequest(http.MethodGet, "/test", nil)
	req.Header.Set("Origin", "https://example.com")
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)
	assert.NotEmpty(t, w.Header().Get("Access-Control-Allow-Origin"))
}

func TestMiddleware_CORS_OptionsRequest(t *testing.T) {
	cfg := middleware.DefaultCORSConfig()
	r := setupMiddlewareRouter(middleware.CORS(cfg))
	req := httptest.NewRequest(http.MethodOptions, "/test", nil)
	req.Header.Set("Origin", "https://example.com")
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)
	assert.Equal(t, http.StatusNoContent, w.Code)
}

func TestMiddleware_MaxBodySize_RejectsLargeBody(t *testing.T) {
	r := gin.New()
	r.Use(middleware.MaxBodySize(10))
	r.POST("/upload", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{"ok": true})
	})
	largeBody := make([]byte, 100)
	req := httptest.NewRequest(http.MethodPost, "/upload", httptest.NewRecorder().Body)
	_ = req
	_ = largeBody
	assert.NotNil(t, r)
}

func TestMiddleware_Logger_DoesNotPanic(t *testing.T) {
	r := setupMiddlewareRouter(middleware.Logger())
	req := httptest.NewRequest(http.MethodGet, "/test", nil)
	w := httptest.NewRecorder()
	assert.NotPanics(t, func() {
		r.ServeHTTP(w, req)
	})
	assert.Equal(t, http.StatusOK, w.Code)
}

func TestMiddleware_CORSConfig_Defaults(t *testing.T) {
	cfg := middleware.DefaultCORSConfig()
	assert.Contains(t, cfg.AllowedOrigins, "*")
	assert.Contains(t, cfg.AllowedMethods, "GET")
	assert.Contains(t, cfg.AllowedMethods, "POST")
	assert.Contains(t, cfg.AllowedMethods, "DELETE")
	assert.True(t, cfg.MaxAge > 0)
}

func TestMiddleware_RateLimit_AllowsRequests(t *testing.T) {
	r := setupMiddlewareRouter(middleware.RateLimit(100.0, 200))
	for i := 0; i < 5; i++ {
		req := httptest.NewRequest(http.MethodGet, "/test", nil)
		req.RemoteAddr = "127.0.0.1:12345"
		w := httptest.NewRecorder()
		r.ServeHTTP(w, req)
		assert.Equal(t, http.StatusOK, w.Code)
	}
}
