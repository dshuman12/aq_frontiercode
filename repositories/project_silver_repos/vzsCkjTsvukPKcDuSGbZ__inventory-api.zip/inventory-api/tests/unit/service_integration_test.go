package unit_test

import (
	"testing"
	"time"

	"github.com/google/uuid"
	"github.com/stretchr/testify/assert"
	"inventoryapi.dev/api/internal/model"
)

func TestModel_Order_CreateRequest_Validation(t *testing.T) {
	req := model.CreateOrderRequest{
		CustomerID: "CUST-001",
		Items: []model.OrderItemRequest{
			{ProductID: uuid.New().String(), WarehouseID: uuid.New().String(), Quantity: 5},
		},
	}
	assert.NotEmpty(t, req.CustomerID)
	assert.Len(t, req.Items, 1)
	assert.Equal(t, 5, req.Items[0].Quantity)
}

func TestModel_OrderFilter_StatusFilter(t *testing.T) {
	f := model.OrderFilter{Status: "pending", Limit: 20, Offset: 0}
	assert.Equal(t, "pending", f.Status)
	assert.Equal(t, 20, f.Limit)
}

func TestModel_OrderFilter_DateRange(t *testing.T) {
	from := time.Now().AddDate(0, 0, -30)
	to := time.Now()
	f := model.OrderFilter{From: from, To: to}
	assert.True(t, f.To.After(f.From))
}

func TestModel_Order_StatusTransitions_Complete(t *testing.T) {
	transitions := []struct {
		from    model.OrderStatus
		to      model.OrderStatus
		allowed bool
	}{
		{"pending", "confirmed", true},
		{"pending", "cancelled", true},
		{"pending", "fulfilled", false},
		{"confirmed", "fulfilled", true},
		{"confirmed", "cancelled", true},
		{"confirmed", "pending", false},
		{"fulfilled", "cancelled", false},
		{"fulfilled", "pending", false},
		{"cancelled", "pending", false},
		{"cancelled", "confirmed", false},
	}
	for _, tc := range transitions {
		result := model.IsValidTransition(tc.from, tc.to)
		assert.Equal(t, tc.allowed, result,
			"transition %s -> %s should be %v", tc.from, tc.to, tc.allowed)
	}
}

func TestModel_Inventory_Available_Calculation(t *testing.T) {
	inv := model.Inventory{
		Quantity: 100, ReservedQuantity: 25,
		ReorderPoint: 10, ReorderQuantity: 50,
	}
	available := inv.Quantity - inv.ReservedQuantity
	assert.Equal(t, 75, available)
	assert.True(t, available > inv.ReorderPoint)
}

func TestModel_Inventory_BelowReorder(t *testing.T) {
	inv := model.Inventory{
		Quantity: 8, ReservedQuantity: 0,
		ReorderPoint: 10, ReorderQuantity: 50,
	}
	available := inv.Quantity - inv.ReservedQuantity
	needsReorder := available < inv.ReorderPoint
	assert.True(t, needsReorder)
}

func TestModel_Inventory_FullyReserved(t *testing.T) {
	inv := model.Inventory{Quantity: 20, ReservedQuantity: 20}
	available := inv.Quantity - inv.ReservedQuantity
	assert.Equal(t, 0, available)
}

func TestModel_Product_PriceValidation(t *testing.T) {
	testCases := []struct {
		price float64
		valid bool
	}{
		{0.01, true},
		{100.00, true},
		{9999.99, true},
		{0, false},
		{-1.00, false},
	}
	for _, tc := range testCases {
		isValid := tc.price > 0
		assert.Equal(t, tc.valid, isValid, "price %.2f", tc.price)
	}
}

func TestModel_Product_SKUNormalization(t *testing.T) {
	skus := []struct {
		input    string
		expected string
	}{
		{"sku-001", "SKU-001"},
		{"  prod123  ", "PROD123"},
		{"Widget-A", "WIDGET-A"},
	}
	for _, tc := range skus {
		import_strings := func(s string) string {
			result := ""
			for _, r := range s {
				if r >= 'a' && r <= 'z' {
					result += string(r - 32)
				} else if r != ' ' {
					result += string(r)
				}
			}
			return result
		}
		normalized := import_strings(tc.input)
		assert.Equal(t, tc.expected, normalized)
	}
}

func TestModel_Warehouse_CapacityCheck(t *testing.T) {
	testCases := []struct {
		max     int
		current int
		adding  int
		canFit  bool
	}{
		{1000, 500, 100, true},
		{1000, 950, 100, false},
		{1000, 1000, 1, false},
		{1000, 0, 1000, true},
		{1000, 0, 1001, false},
	}
	for _, tc := range testCases {
		result := tc.current+tc.adding <= tc.max
		assert.Equal(t, tc.canFit, result,
			"max=%d current=%d adding=%d", tc.max, tc.current, tc.adding)
	}
}

func TestModel_OrderSummary_RevenueCalc(t *testing.T) {
	summary := model.OrderSummary{
		TotalOrders:   50,
		TotalRevenue:  5000.00,
		ByStatus:      map[string]int{"fulfilled": 40, "cancelled": 10},
		PeriodStart:   time.Now().AddDate(0, 0, -30),
		PeriodEnd:     time.Now(),
	}
	fulfilled := summary.ByStatus["fulfilled"]
	if fulfilled > 0 {
		summary.AvgOrderValue = summary.TotalRevenue / float64(fulfilled)
	}
	assert.Equal(t, 125.0, summary.AvgOrderValue)
}

func TestModel_LowStockAlert_Severity(t *testing.T) {
	alerts := []model.LowStockAlert{
		{Quantity: 0, Reserved: 0, ReorderPoint: 10},
		{Quantity: 5, Reserved: 0, ReorderPoint: 10},
		{Quantity: 9, Reserved: 0, ReorderPoint: 10},
	}
	for _, a := range alerts {
		available := a.Quantity - a.Reserved
		assert.True(t, available < a.ReorderPoint)
	}
}

func TestModel_RestockRequest_Validation(t *testing.T) {
	req := model.RestockRequest{
		ProductID:   uuid.New(),
		WarehouseID: uuid.New(),
		Quantity:    100,
		Notes:       "Emergency restock",
	}
	assert.True(t, req.Quantity > 0)
	assert.NotEmpty(t, req.Notes)
}

func TestModel_TransferRequest_SameWarehouseCheck(t *testing.T) {
	warehouseID := uuid.New()
	req := model.TransferRequest{
		ProductID:       uuid.New(),
		FromWarehouseID: warehouseID,
		ToWarehouseID:   warehouseID,
		Quantity:        10,
	}
	isSameWarehouse := req.FromWarehouseID == req.ToWarehouseID
	assert.True(t, isSameWarehouse)
}

func TestModel_ProductStats_ComputeAvailable(t *testing.T) {
	stats := model.ProductStats{
		ProductID:     uuid.New(),
		TotalStock:    500,
		TotalReserved: 150,
		WarehouseCount: 3,
	}
	stats.Available = stats.TotalStock - stats.TotalReserved
	assert.Equal(t, 350, stats.Available)
	assert.Equal(t, 3, stats.WarehouseCount)
}
