package unit_test

import (
	"strings"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"inventoryapi.dev/api/internal/export"
)

func TestExport_FormatDate(t *testing.T) {
	t1 := time.Date(2025, 3, 15, 10, 30, 0, 0, time.UTC)
	assert.Equal(t, "2025-03-15", export.FormatDate(t1))
}

func TestExport_FormatDateTime(t *testing.T) {
	t1 := time.Date(2025, 3, 15, 10, 30, 45, 0, time.UTC)
	assert.Equal(t, "2025-03-15 10:30:45", export.FormatDateTime(t1))
}

func TestExport_FormatCurrency(t *testing.T) {
	assert.Equal(t, "1234.56", export.FormatCurrency(1234.56))
	assert.Equal(t, "0.00", export.FormatCurrency(0))
	assert.Equal(t, "99.99", export.FormatCurrency(99.99))
}

func TestExport_FormatQuantity(t *testing.T) {
	assert.Equal(t, "50 units", export.FormatQuantity(50))
}

func TestExport_ToCSV_HeadersAndRows(t *testing.T) {
	headers := []string{"id", "name", "qty"}
	rows := [][]string{{"1", "Widget A", "100"}, {"2", "Widget B", "50"}}
	data, err := export.ToCSV(headers, rows)
	require.NoError(t, err)
	str := string(data)
	assert.Contains(t, str, "id,name,qty")
	assert.Contains(t, str, "Widget A")
}

func TestExport_SanitizeFilename(t *testing.T) {
	assert.Equal(t, "my_report_2025", export.SanitizeFilename("My Report 2025"))
	assert.Equal(t, "test_file", export.SanitizeFilename("test file!@#"))
}

func TestExport_BuildExportFilename(t *testing.T) {
	t1 := time.Date(2025, 3, 15, 10, 30, 0, 0, time.UTC)
	name := export.BuildExportFilename("orders", t1)
	assert.True(t, strings.HasPrefix(name, "orders_"))
	assert.True(t, strings.HasSuffix(name, ".csv"))
}

func TestExport_ParseCSVRow(t *testing.T) {
	row, err := export.ParseCSVRow(`"hello","world","123"`)
	require.NoError(t, err)
	assert.Equal(t, []string{"hello", "world", "123"}, row)
}
