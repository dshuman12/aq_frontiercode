package unit_test

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func init() {
	gin.SetMode(gin.TestMode)
}

func newTestRouter() *gin.Engine {
	r := gin.New()
	return r
}

func doRequest(t *testing.T, r *gin.Engine, method, path string, body any) *httptest.ResponseRecorder {
	var buf bytes.Buffer
	if body != nil {
		require.NoError(t, json.NewEncoder(&buf).Encode(body))
	}
	req := httptest.NewRequest(method, path, &buf)
	req.Header.Set("Content-Type", "application/json")
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)
	return w
}

func parseBody(t *testing.T, w *httptest.ResponseRecorder) map[string]any {
	var result map[string]any
	require.NoError(t, json.NewDecoder(w.Body).Decode(&result))
	return result
}

func TestHandler_PingRoute(t *testing.T) {
	r := newTestRouter()
	r.GET("/ping", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{"message": "pong"})
	})
	w := doRequest(t, r, http.MethodGet, "/ping", nil)
	assert.Equal(t, http.StatusOK, w.Code)
	body := parseBody(t, w)
	assert.Equal(t, "pong", body["message"])
}

func TestHandler_HealthRoute(t *testing.T) {
	r := newTestRouter()
	r.GET("/health", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{"status": "ok", "timestamp": time.Now().Unix()})
	})
	w := doRequest(t, r, http.MethodGet, "/health", nil)
	assert.Equal(t, http.StatusOK, w.Code)
}

func TestHandler_NotFound(t *testing.T) {
	r := newTestRouter()
	r.NoRoute(func(c *gin.Context) {
		c.JSON(http.StatusNotFound, gin.H{"error": "route not found"})
	})
	w := doRequest(t, r, http.MethodGet, "/nonexistent/path", nil)
	assert.Equal(t, http.StatusNotFound, w.Code)
}

func TestHandler_RequestID_Generated(t *testing.T) {
	r := newTestRouter()
	r.GET("/test", func(c *gin.Context) {
		reqID := c.GetHeader("X-Request-ID")
		c.JSON(http.StatusOK, gin.H{"request_id": reqID})
	})
	w := doRequest(t, r, http.MethodGet, "/test", nil)
	assert.Equal(t, http.StatusOK, w.Code)
}

func TestHandler_ValidationBadJSON(t *testing.T) {
	r := newTestRouter()
	r.POST("/products", func(c *gin.Context) {
		var req struct {
			Name string `json:"name" binding:"required"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
			return
		}
		c.JSON(http.StatusCreated, req)
	})
	req := httptest.NewRequest(http.MethodPost, "/products", bytes.NewBufferString("not json"))
	req.Header.Set("Content-Type", "application/json")
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)
	assert.Equal(t, http.StatusBadRequest, w.Code)
}

func TestHandler_PaginationParams_Defaults(t *testing.T) {
	r := newTestRouter()
	r.GET("/items", func(c *gin.Context) {
		limit := c.DefaultQuery("limit", "20")
		offset := c.DefaultQuery("offset", "0")
		c.JSON(http.StatusOK, gin.H{"limit": limit, "offset": offset})
	})
	w := doRequest(t, r, http.MethodGet, "/items", nil)
	assert.Equal(t, http.StatusOK, w.Code)
	body := parseBody(t, w)
	assert.Equal(t, "20", body["limit"])
	assert.Equal(t, "0", body["offset"])
}

func TestHandler_UUIDParam_Valid(t *testing.T) {
	id := uuid.New()
	r := newTestRouter()
	r.GET("/items/:id", func(c *gin.Context) {
		uid, err := uuid.Parse(c.Param("id"))
		if err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
			return
		}
		c.JSON(http.StatusOK, gin.H{"id": uid})
	})
	w := doRequest(t, r, http.MethodGet, "/items/"+id.String(), nil)
	assert.Equal(t, http.StatusOK, w.Code)
}

func TestHandler_UUIDParam_Invalid(t *testing.T) {
	r := newTestRouter()
	r.GET("/items/:id", func(c *gin.Context) {
		_, err := uuid.Parse(c.Param("id"))
		if err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
			return
		}
		c.JSON(http.StatusOK, gin.H{})
	})
	w := doRequest(t, r, http.MethodGet, "/items/not-a-uuid", nil)
	assert.Equal(t, http.StatusBadRequest, w.Code)
}

func TestHandler_JSONResponse_Envelope(t *testing.T) {
	r := newTestRouter()
	r.GET("/data", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{"data": gin.H{"id": "123"}, "error": nil})
	})
	w := doRequest(t, r, http.MethodGet, "/data", nil)
	assert.Equal(t, http.StatusOK, w.Code)
	body := parseBody(t, w)
	assert.NotNil(t, body["data"])
	assert.Nil(t, body["error"])
}

func TestHandler_ContentType_JSON(t *testing.T) {
	r := newTestRouter()
	r.GET("/data", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{"ok": true})
	})
	w := doRequest(t, r, http.MethodGet, "/data", nil)
	assert.Contains(t, w.Header().Get("Content-Type"), "application/json")
}

func TestHandler_PostWithBody(t *testing.T) {
	r := newTestRouter()
	r.POST("/echo", func(c *gin.Context) {
		var body map[string]any
		c.ShouldBindJSON(&body)
		c.JSON(http.StatusOK, body)
	})
	payload := map[string]any{"key": "value", "number": 42}
	w := doRequest(t, r, http.MethodPost, "/echo", payload)
	assert.Equal(t, http.StatusOK, w.Code)
	body := parseBody(t, w)
	assert.Equal(t, "value", body["key"])
}

func TestHandler_ListResponse_HasMeta(t *testing.T) {
	r := newTestRouter()
	r.GET("/list", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{
			"data":   []string{"a", "b", "c"},
			"total":  100,
			"limit":  20,
			"offset": 0,
		})
	})
	w := doRequest(t, r, http.MethodGet, "/list", nil)
	assert.Equal(t, http.StatusOK, w.Code)
	body := parseBody(t, w)
	assert.Equal(t, float64(100), body["total"])
	assert.Equal(t, float64(20), body["limit"])
}

func TestHandler_EmptyListResponse(t *testing.T) {
	r := newTestRouter()
	r.GET("/empty", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{"data": []any{}, "total": 0})
	})
	w := doRequest(t, r, http.MethodGet, "/empty", nil)
	assert.Equal(t, http.StatusOK, w.Code)
	body := parseBody(t, w)
	assert.Equal(t, float64(0), body["total"])
}

func TestHandler_DeleteReturns204(t *testing.T) {
	r := newTestRouter()
	r.DELETE("/items/:id", func(c *gin.Context) {
		c.Status(http.StatusNoContent)
	})
	w := doRequest(t, r, http.MethodDelete, "/items/"+uuid.New().String(), nil)
	assert.Equal(t, http.StatusNoContent, w.Code)
}

func TestHandler_ErrorResponse_Structure(t *testing.T) {
	r := newTestRouter()
	r.GET("/error", func(c *gin.Context) {
		c.JSON(http.StatusBadRequest, gin.H{"data": nil, "error": "something went wrong"})
	})
	w := doRequest(t, r, http.MethodGet, "/error", nil)
	assert.Equal(t, http.StatusBadRequest, w.Code)
	body := parseBody(t, w)
	assert.Nil(t, body["data"])
	assert.Equal(t, "something went wrong", body["error"])
}
