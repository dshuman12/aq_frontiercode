package unit_test

import (
	"testing"

	"github.com/google/uuid"
	"github.com/stretchr/testify/assert"
	"inventoryapi.dev/api/internal/model"
)

func TestModel_IsValidTransition_PendingToConfirmed(t *testing.T) {
	assert.True(t, model.IsValidTransition("pending", "confirmed"))
}

func TestModel_IsValidTransition_PendingToCancelled(t *testing.T) {
	assert.True(t, model.IsValidTransition("pending", "cancelled"))
}

func TestModel_IsValidTransition_PendingToFulfilled(t *testing.T) {
	assert.False(t, model.IsValidTransition("pending", "fulfilled"))
}

func TestModel_IsValidTransition_ConfirmedToFulfilled(t *testing.T) {
	assert.True(t, model.IsValidTransition("confirmed", "fulfilled"))
}

func TestModel_IsValidTransition_FulfilledToPending(t *testing.T) {
	assert.False(t, model.IsValidTransition("fulfilled", "pending"))
}

func TestModel_IsValidTransition_CancelledToAny(t *testing.T) {
	assert.False(t, model.IsValidTransition("cancelled", "pending"))
	assert.False(t, model.IsValidTransition("cancelled", "confirmed"))
}

func TestModel_IsValidTransition_InvalidFrom(t *testing.T) {
	assert.False(t, model.IsValidTransition("nonexistent", "pending"))
}

func TestModel_Warehouse_AvailableSpace(t *testing.T) {
	w := model.Warehouse{MaxCapacity: 1000, CurrentUsage: 300}
	assert.Equal(t, 700, w.AvailableSpace())
}

func TestModel_Warehouse_AvailableSpace_Full(t *testing.T) {
	w := model.Warehouse{MaxCapacity: 500, CurrentUsage: 500}
	assert.Equal(t, 0, w.AvailableSpace())
}

func TestModel_Errors_IsNotFound(t *testing.T) {
	err := model.ErrNotFound
	assert.True(t, model.IsNotFound(err))
}

func TestModel_Errors_NotFoundError(t *testing.T) {
	err := model.NewNotFoundError("product", uuid.New().String())
	assert.True(t, model.IsNotFound(err))
	assert.Contains(t, err.Error(), "product")
}

func TestModel_Errors_ValidationError(t *testing.T) {
	err := model.NewValidationError("price", "must be positive")
	assert.True(t, model.IsValidation(err))
	assert.Contains(t, err.Error(), "price")
}

func TestModel_Errors_ConflictError(t *testing.T) {
	err := model.NewConflictError("product", "sku", "PROD-001")
	assert.True(t, model.IsConflict(err))
	assert.Contains(t, err.Error(), "PROD-001")
}

func TestModel_Errors_StockError(t *testing.T) {
	err := model.NewStockError("product-1", "warehouse-1", 10, 5)
	assert.True(t, model.IsInsufficientStock(err))
	assert.Contains(t, err.Error(), "10")
	assert.Contains(t, err.Error(), "5")
}

func TestModel_Errors_TransitionError(t *testing.T) {
	err := model.NewTransitionError("pending", "fulfilled")
	assert.True(t, model.IsInvalidTransition(err))
	assert.Contains(t, err.Error(), "pending")
	assert.Contains(t, err.Error(), "fulfilled")
}

func TestModel_ProductFilter_Defaults(t *testing.T) {
	f := model.ProductFilter{Limit: 0}
	if f.Limit <= 0 {
		f.Limit = 20
	}
	assert.Equal(t, 20, f.Limit)
}

func TestModel_OrderFilter_StatusFilter(t *testing.T) {
	f := model.OrderFilter{Status: "pending"}
	assert.Equal(t, "pending", f.Status)
}

func TestModel_BulkCreateRequest_Items(t *testing.T) {
	req := model.BulkCreateProductRequest{
		Products: []model.CreateProductRequest{
			{SKU: "A", Name: "Product A", UnitPrice: 10.0},
			{SKU: "B", Name: "Product B", UnitPrice: 20.0},
		},
	}
	assert.Len(t, req.Products, 2)
}
