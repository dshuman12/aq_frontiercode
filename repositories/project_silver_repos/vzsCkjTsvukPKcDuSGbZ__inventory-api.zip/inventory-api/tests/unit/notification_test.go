package unit_test

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"inventoryapi.dev/api/internal/notification"
)

func TestNotification_Constants_Defined(t *testing.T) {
	assert.Equal(t, "pending", notification.StatusPending)
	assert.Equal(t, "sent", notification.StatusSent)
	assert.Equal(t, "failed", notification.StatusFailed)
	assert.Equal(t, "read", notification.StatusRead)
}

func TestNotification_Channels_Defined(t *testing.T) {
	assert.Equal(t, "email", notification.ChannelEmail)
	assert.Equal(t, "webhook", notification.ChannelWebhook)
	assert.Equal(t, "slack", notification.ChannelSlack)
}

func TestNotification_Render_ReplacesPlaceholders(t *testing.T) {
	svc := &notification.Service{}
	_ = svc
}

func TestNotification_Filter_DefaultLimit(t *testing.T) {
	f := notification.Filter{Limit: 0}
	if f.Limit <= 0 {
		f.Limit = 50
	}
	assert.Equal(t, 50, f.Limit)
}

func TestNotification_StatusValues_AreDistinct(t *testing.T) {
	statuses := []string{
		notification.StatusPending,
		notification.StatusSent,
		notification.StatusFailed,
		notification.StatusRead,
	}
	seen := make(map[string]bool)
	for _, s := range statuses {
		assert.False(t, seen[s], "duplicate status: "+s)
		seen[s] = true
	}
}
