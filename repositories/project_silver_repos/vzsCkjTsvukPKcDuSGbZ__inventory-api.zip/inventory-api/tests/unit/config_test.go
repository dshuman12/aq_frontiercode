package unit_test

import (
	"os"
	"testing"

	"github.com/stretchr/testify/assert"
	"inventoryapi.dev/api/internal/config"
)

func TestConfig_Load_Defaults(t *testing.T) {
	cfg := config.Load()
	assert.Equal(t, "localhost", cfg.DBHost)
	assert.Equal(t, "5432", cfg.DBPort)
	assert.Equal(t, "8080", cfg.ServerPort)
	assert.Equal(t, "info", cfg.LogLevel)
}

func TestConfig_Load_FromEnv(t *testing.T) {
	os.Setenv("DB_HOST", "testhost")
	os.Setenv("DB_PORT", "5433")
	defer os.Unsetenv("DB_HOST")
	defer os.Unsetenv("DB_PORT")
	cfg := config.Load()
	assert.Equal(t, "testhost", cfg.DBHost)
	assert.Equal(t, "5433", cfg.DBPort)
}

func TestConfig_Validate_MissingJWT(t *testing.T) {
	os.Setenv("JWT_SECRET", "")
	defer os.Setenv("JWT_SECRET", "default")
	cfg := config.Load()
	cfg.JWTSecret = ""
	err := cfg.Validate()
	assert.Error(t, err)
}

func TestConfig_Validate_ValidConfig(t *testing.T) {
	cfg := config.Load()
	cfg.JWTSecret = "supersecret"
	cfg.DBName = "testdb"
	cfg.RateLimitRPS = 10
	cfg.MaxPageSize = 100
	err := cfg.Validate()
	assert.NoError(t, err)
}

func TestConfig_DSN_Format(t *testing.T) {
	cfg := config.Load()
	cfg.DBHost = "localhost"
	cfg.DBPort = "5432"
	cfg.DBUser = "user"
	cfg.DBName = "testdb"
	dsn := cfg.DSN()
	assert.Contains(t, dsn, "localhost")
	assert.Contains(t, dsn, "5432")
	assert.Contains(t, dsn, "testdb")
}

func TestConfig_RateLimitRPS_Default(t *testing.T) {
	cfg := config.Load()
	assert.Equal(t, 10, cfg.RateLimitRPS)
}

func TestConfig_RateLimitBurst_Default(t *testing.T) {
	cfg := config.Load()
	assert.Equal(t, 20, cfg.RateLimitBurst)
}

func TestConfig_LowStockThreshold_Default(t *testing.T) {
	cfg := config.Load()
	assert.Equal(t, 10, cfg.LowStockThreshold)
}

func TestConfig_DefaultPageSize(t *testing.T) {
	cfg := config.Load()
	assert.Equal(t, 20, cfg.DefaultPageSize)
	assert.Equal(t, 100, cfg.MaxPageSize)
}

func TestConfig_IsProduction_DefaultFalse(t *testing.T) {
	os.Unsetenv("ENV")
	os.Unsetenv("ENVIRONMENT")
	cfg := config.Load()
	assert.False(t, cfg.IsProduction())
}

func TestConfig_IsDevelopment_DefaultTrue(t *testing.T) {
	os.Unsetenv("ENV")
	cfg := config.Load()
	assert.True(t, cfg.IsDevelopment())
}

func TestConfig_Validate_InvalidRateLimit(t *testing.T) {
	cfg := config.Load()
	cfg.JWTSecret = "secret"
	cfg.DBName = "db"
	cfg.RateLimitRPS = 0
	err := cfg.Validate()
	assert.Error(t, err)
}

func TestConfig_Validate_InvalidMaxPageSize(t *testing.T) {
	cfg := config.Load()
	cfg.JWTSecret = "secret"
	cfg.DBName = "db"
	cfg.RateLimitRPS = 10
	cfg.MaxPageSize = 2000
	err := cfg.Validate()
	assert.Error(t, err)
}
