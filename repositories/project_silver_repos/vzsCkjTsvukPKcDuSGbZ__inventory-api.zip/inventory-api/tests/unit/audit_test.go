package unit_test

import (
	"testing"
	"time"

	"github.com/google/uuid"
	"github.com/stretchr/testify/assert"
	"inventoryapi.dev/api/internal/audit"
)

func TestAuditFilter_DefaultLimit(t *testing.T) {
	f := audit.AuditFilter{Limit: 0}
	if f.Limit <= 0 {
		f.Limit = 50
	}
	assert.Equal(t, 50, f.Limit)
}

func TestAuditFilter_EntityIDPointer(t *testing.T) {
	id := uuid.New()
	f := audit.AuditFilter{EntityID: &id}
	assert.NotNil(t, f.EntityID)
	assert.Equal(t, id, *f.EntityID)
}

func TestAuditLog_Fields(t *testing.T) {
	log := audit.AuditLog{
		ID:         uuid.New(),
		EntityType: "product",
		EntityID:   uuid.New(),
		Action:     "create",
		CreatedAt:  time.Now(),
	}
	assert.Equal(t, "product", log.EntityType)
	assert.Equal(t, "create", log.Action)
	assert.NotZero(t, log.CreatedAt)
}

func TestAuditFilter_DateRange(t *testing.T) {
	from := time.Now().AddDate(0, 0, -7)
	to := time.Now()
	f := audit.AuditFilter{From: from, To: to}
	assert.True(t, f.To.After(f.From))
}

func TestAuditFilter_ActionFilter(t *testing.T) {
	f := audit.AuditFilter{Action: "update"}
	assert.Equal(t, "update", f.Action)
}
