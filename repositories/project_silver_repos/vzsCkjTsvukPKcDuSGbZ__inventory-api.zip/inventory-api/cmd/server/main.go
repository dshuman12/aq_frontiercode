package main

import (
	"log"

	"github.com/gin-gonic/gin"
	"inventoryapi.dev/api/internal/config"
	"inventoryapi.dev/api/internal/db"
	"inventoryapi.dev/api/internal/handler"
	"inventoryapi.dev/api/internal/middleware"
	"inventoryapi.dev/api/internal/report"
	"inventoryapi.dev/api/internal/repository"
	"inventoryapi.dev/api/internal/service"
)

func main() {
	cfg := config.Load()

	if err := cfg.Validate(); err != nil {
		log.Fatalf("config: %v", err)
	}

	conn, err := db.New(cfg)
	if err != nil {
		log.Fatalf("db: %v", err)
	}
	defer conn.Close()

	prodRepo  := repository.NewProductRepo(conn)
	whRepo    := repository.NewWarehouseRepo(conn)
	invRepo   := repository.NewInventoryRepo(conn)
	orderRepo := repository.NewOrderRepo(conn)

	prodSvc   := service.NewProductService(prodRepo)
	whSvc     := service.NewWarehouseService(whRepo)
	invSvc    := service.NewInventoryService(invRepo, whRepo)
	orderSvc  := service.NewOrderService(orderRepo, invSvc, prodRepo)
	reportSvc := service.NewReportingService(invRepo, orderRepo, cfg.LowStockThreshold)

	reportRepo := report.New(conn)

	prodH   := handler.NewProductHandler(prodSvc)
	whH     := handler.NewWarehouseHandler(whSvc)
	invH    := handler.NewInventoryHandler(invSvc)
	orderH  := handler.NewOrderHandler(orderSvc)
	reportH := handler.NewReportHandler(reportRepo, orderSvc, prodSvc, invSvc)

	_ = reportSvc

	r := gin.Default()
	r.Use(middleware.Logger())
	r.Use(middleware.RateLimit(100, 200))

	api := r.Group("/api/v1")
	api.Use(middleware.Auth(cfg.JWTSecret))
	{
		p := api.Group("/products")
		p.POST("", prodH.Create)
		p.GET("", prodH.List)
		p.GET("/:id", prodH.GetByID)
		p.PUT("/:id", prodH.Update)
		p.DELETE("/:id", prodH.Delete)

		w := api.Group("/warehouses")
		w.POST("", whH.Create)
		w.GET("", whH.List)
		w.GET("/:id", whH.GetByID)
		w.PUT("/:id/deactivate", whH.Deactivate)

		inv := api.Group("/inventory")
		inv.GET("/product/:id", invH.GetByProduct)
		inv.POST("/transfer", invH.Transfer)

		o := api.Group("/orders")
		o.POST("", orderH.Create)
		o.GET("", orderH.List)
		o.GET("/:id", orderH.GetByID)
		o.PATCH("/:id/confirm", orderH.Confirm)
		o.PATCH("/:id/fulfill", orderH.Fulfill)
		o.PATCH("/:id/cancel", orderH.Cancel)

		rep := api.Group("/reports")
		rep.GET("/low-stock", reportH.GetLowStockAlerts)
		rep.GET("/top-products", reportH.GetTopProducts)
		rep.GET("/summary", reportH.GetSummary)
		rep.GET("/revenue-trend", reportH.GetRevenueTrend)
	}

	log.Printf("starting on port %s", cfg.ServerPort)
	if err := r.Run(":" + cfg.ServerPort); err != nil {
		log.Fatal(err)
	}
}
