package notification

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"
	"time"

	"github.com/google/uuid"
	"github.com/jmoiron/sqlx"
)

const (
	StatusPending = "pending"
	StatusSent    = "sent"
	StatusFailed  = "failed"
	StatusRead    = "read"

	ChannelEmail   = "email"
	ChannelWebhook = "webhook"
	ChannelSlack   = "slack"
)

type Notification struct {
	ID          uuid.UUID       `db:"id" json:"id"`
	RecipientID uuid.UUID       `db:"recipient_id" json:"recipient_id"`
	Channel     string          `db:"channel" json:"channel"`
	Type        string          `db:"type" json:"type"`
	Title       string          `db:"title" json:"title"`
	Body        string          `db:"body" json:"body"`
	Metadata    json.RawMessage `db:"metadata" json:"metadata,omitempty"`
	Status      string          `db:"status" json:"status"`
	RetryCount  int             `db:"retry_count" json:"retry_count"`
	SentAt      *time.Time      `db:"sent_at" json:"sent_at,omitempty"`
	ReadAt      *time.Time      `db:"read_at" json:"read_at,omitempty"`
	CreatedAt   time.Time       `db:"created_at" json:"created_at"`
}

type Filter struct {
	RecipientID *uuid.UUID
	Channel     string
	Status      string
	Limit       int
	Offset      int
}

type Service struct {
	db        *sqlx.DB
	templates map[string]string
}

func New(db *sqlx.DB) *Service {
	return &Service{
		db: db,
		templates: map[string]string{
			"order_confirmed":   "Your order {order_id} has been confirmed and is being processed.",
			"order_fulfilled":   "Your order {order_id} has been fulfilled. Total: {total}.",
			"order_cancelled":   "Your order {order_id} has been cancelled.",
			"low_stock_alert":   "Product {product_name} (SKU: {sku}) is below reorder point in warehouse {warehouse}.",
			"restock_completed": "Restock completed for {product_name}. New quantity: {quantity}.",
			"transfer_done":     "Stock transfer complete: {quantity} units of {product_name} moved to {warehouse}.",
		},
	}
}

func (s *Service) Send(ctx context.Context, recipientID uuid.UUID, channel, notifType, title, body string, metadata map[string]any) error {
	var metaJSON []byte
	var err error
	if metadata != nil {
		if metaJSON, err = json.Marshal(metadata); err != nil {
			return err
		}
	}
	now := time.Now()
	q := `INSERT INTO notifications (recipient_id, channel, type, title, body, metadata, status, sent_at)
		  VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`
	_, err = s.db.ExecContext(ctx, q, recipientID, channel, notifType, title, body, metaJSON, StatusSent, now)
	return err
}

func (s *Service) BulkSend(ctx context.Context, recipientIDs []uuid.UUID, channel, notifType, title, body string) error {
	tx, err := s.db.BeginTxx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()
	now := time.Now()
	q := `INSERT INTO notifications (recipient_id, channel, type, title, body, status, sent_at)
		  VALUES ($1,$2,$3,$4,$5,$6,$7)`
	for _, rid := range recipientIDs {
		if _, err := tx.ExecContext(ctx, q, rid, channel, notifType, title, body, StatusSent, now); err != nil {
			return err
		}
	}
	return tx.Commit()
}

func (s *Service) MarkRead(ctx context.Context, id uuid.UUID) error {
	now := time.Now()
	_, err := s.db.ExecContext(ctx,
		`UPDATE notifications SET status=$1, read_at=$2 WHERE id=$3`,
		StatusRead, now, id)
	return err
}

func (s *Service) MarkDelivered(ctx context.Context, id uuid.UUID) error {
	now := time.Now()
	_, err := s.db.ExecContext(ctx,
		`UPDATE notifications SET status=$1, sent_at=$2 WHERE id=$3`,
		StatusSent, now, id)
	return err
}

func (s *Service) GetUnread(ctx context.Context, recipientID uuid.UUID) ([]Notification, error) {
	var rows []Notification
	err := s.db.SelectContext(ctx, &rows,
		`SELECT * FROM notifications WHERE recipient_id=$1 AND status IN ('pending','sent') ORDER BY created_at DESC`,
		recipientID)
	return rows, err
}

func (s *Service) GetHistory(ctx context.Context, f Filter) ([]Notification, int, error) {
	conds := " WHERE 1=1"
	args := []any{}
	n := 1
	if f.RecipientID != nil {
		conds += fmt.Sprintf(" AND recipient_id=$%d", n); args = append(args, *f.RecipientID); n++
	}
	if f.Channel != "" {
		conds += fmt.Sprintf(" AND channel=$%d", n); args = append(args, f.Channel); n++
	}
	if f.Status != "" {
		conds += fmt.Sprintf(" AND status=$%d", n); args = append(args, f.Status); n++
	}
	var total int
	if err := s.db.QueryRowContext(ctx, "SELECT COUNT(*) FROM notifications"+conds, args...).Scan(&total); err != nil {
		return nil, 0, err
	}
	lim := f.Limit; if lim <= 0 { lim = 50 }
	listQ := "SELECT * FROM notifications" + conds + fmt.Sprintf(" ORDER BY created_at DESC LIMIT $%d OFFSET $%d", n, n+1)
	args = append(args, lim, f.Offset)
	var rows []Notification
	if err := s.db.SelectContext(ctx, &rows, listQ, args...); err != nil {
		return nil, 0, err
	}
	return rows, total, nil
}

func (s *Service) RetryFailed(ctx context.Context) (int, error) {
	var failed []Notification
	err := s.db.SelectContext(ctx, &failed,
		`SELECT * FROM notifications WHERE status='failed' AND retry_count < 3 ORDER BY created_at ASC LIMIT 50`)
	if err != nil {
		return 0, err
	}
	count := 0
	for _, n := range failed {
		now := time.Now()
		_, err := s.db.ExecContext(ctx,
			`UPDATE notifications SET status=$1, sent_at=$2, retry_count=retry_count+1 WHERE id=$3`,
			StatusSent, now, n.ID)
		if err == nil {
			count++
		}
	}
	return count, nil
}

func (s *Service) Render(templateKey string, data map[string]string) string {
	tmpl, ok := s.templates[templateKey]
	if !ok {
		return templateKey
	}
	for k, v := range data {
		tmpl = strings.ReplaceAll(tmpl, "{"+k+"}", v)
	}
	return tmpl
}

type AlertLevel string

const (
	AlertInfo     AlertLevel = "info"
	AlertWarning  AlertLevel = "warning"
	AlertCritical AlertLevel = "critical"
)

type AlertMessage struct {
	Level     AlertLevel `json:"level"`
	Title     string     `json:"title"`
	Body      string     `json:"body"`
	EntityID  string     `json:"entity_id,omitempty"`
	CreatedAt time.Time  `json:"created_at"`
}

func NewAlert(level AlertLevel, title, body string) *AlertMessage {
	return &AlertMessage{
		Level:     level,
		Title:     title,
		Body:      body,
		CreatedAt: time.Now(),
	}
}

func (a *AlertMessage) IsCritical() bool {
	return a.Level == AlertCritical
}

func (a *AlertMessage) String() string {
	return "[" + string(a.Level) + "] " + a.Title + ": " + a.Body
}

type NotificationQueue struct {
	items    []*AlertMessage
	capacity int
}

func NewNotificationQueue(capacity int) *NotificationQueue {
	if capacity <= 0 {
		capacity = 100
	}
	return &NotificationQueue{
		items:    make([]*AlertMessage, 0, capacity),
		capacity: capacity,
	}
}

func (q *NotificationQueue) Push(msg *AlertMessage) bool {
	if len(q.items) >= q.capacity {
		return false
	}
	q.items = append(q.items, msg)
	return true
}

func (q *NotificationQueue) Pop() *AlertMessage {
	if len(q.items) == 0 {
		return nil
	}
	msg := q.items[0]
	q.items = q.items[1:]
	return msg
}

func (q *NotificationQueue) Len() int {
	return len(q.items)
}

func (q *NotificationQueue) IsFull() bool {
	return len(q.items) >= q.capacity
}
