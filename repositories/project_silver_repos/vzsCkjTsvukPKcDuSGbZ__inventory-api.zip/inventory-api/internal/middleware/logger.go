package middleware

import (
	"fmt"
	"log"
	"time"

	"github.com/gin-gonic/gin"
)

type LogEntry struct {
	Timestamp  time.Time
	Method     string
	Path       string
	Status     int
	Latency    time.Duration
	ClientIP   string
	UserAgent  string
	RequestID  string
	UserID     string
	BytesSent  int
	BytesRecv  int
}

func (e *LogEntry) String() string {
	return fmt.Sprintf(
		"[%s] %s %s %d %s ip=%s rid=%s",
		e.Timestamp.Format("2006-01-02 15:04:05"),
		e.Method,
		e.Path,
		e.Status,
		e.Latency.Round(time.Millisecond),
		e.ClientIP,
		e.RequestID,
	)
}

func Logger() gin.HandlerFunc {
	return func(c *gin.Context) {
		start := time.Now()
		path := c.Request.URL.Path
		raw := c.Request.URL.RawQuery

		c.Next()

		latency := time.Since(start)
		status := c.Writer.Status()
		clientIP := c.ClientIP()
		method := c.Request.Method

		if raw != "" {
			path = path + "?" + raw
		}

		requestID, _ := c.Get("request_id")
		rid := ""
		if requestID != nil {
			rid = fmt.Sprintf("%v", requestID)
		}

		entry := LogEntry{
			Timestamp: time.Now(),
			Method:    method,
			Path:      path,
			Status:    status,
			Latency:   latency,
			ClientIP:  clientIP,
			RequestID: rid,
		}

		log.Println(entry.String())
	}
}

type StructuredLogger struct {
	format string
}

func NewStructuredLogger(format string) *StructuredLogger {
	if format != "json" && format != "text" {
		format = "text"
	}
	return &StructuredLogger{format: format}
}

func (l *StructuredLogger) Middleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		start := time.Now()
		c.Next()
		latency := time.Since(start)
		if l.format == "json" {
			log.Printf(`{"ts":"%s","method":"%s","path":"%s","status":%d,"latency_ms":%d,"ip":"%s"}`,
				time.Now().Format(time.RFC3339),
				c.Request.Method,
				c.Request.URL.Path,
				c.Writer.Status(),
				latency.Milliseconds(),
				c.ClientIP(),
			)
		} else {
			log.Printf("%s %s %d %dms %s",
				c.Request.Method,
				c.Request.URL.Path,
				c.Writer.Status(),
				latency.Milliseconds(),
				c.ClientIP(),
			)
		}
	}
}

func SkipLogging(paths ...string) gin.HandlerFunc {
	skipMap := make(map[string]bool, len(paths))
	for _, p := range paths {
		skipMap[p] = true
	}
	return func(c *gin.Context) {
		if skipMap[c.Request.URL.Path] {
			c.Next()
			return
		}
		Logger()(c)
	}
}

