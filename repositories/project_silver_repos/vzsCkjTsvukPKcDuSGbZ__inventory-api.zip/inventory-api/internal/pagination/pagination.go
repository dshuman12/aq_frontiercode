package pagination

import (
	"fmt"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
)

const (
	DefaultLimit = 20
	MaxLimit     = 100
)

type Params struct {
	Limit   int
	Offset  int
	SortBy  string
	SortDir string
	Page    int
}

type Meta struct {
	Total   int `json:"total"`
	Limit   int `json:"limit"`
	Offset  int `json:"offset"`
	Page    int `json:"page"`
	Pages   int `json:"pages"`
	HasNext bool `json:"has_next"`
	HasPrev bool `json:"has_prev"`
}

func FromQuery(c *gin.Context) Params {
	limit, _ := strconv.Atoi(c.DefaultQuery("limit", "20"))
	offset, _ := strconv.Atoi(c.DefaultQuery("offset", "0"))
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	sortBy := c.DefaultQuery("sort_by", "created_at")
	sortDir := c.DefaultQuery("sort_dir", "desc")
	if limit <= 0 || limit > MaxLimit {
		limit = DefaultLimit
	}
	if offset < 0 {
		offset = 0
	}
	if page > 1 && offset == 0 {
		offset = (page - 1) * limit
	}
	return Params{Limit: limit, Offset: offset, SortBy: sortBy, SortDir: sortDir, Page: page}
}

func (p Params) Validate() error {
	if p.Limit < 1 {
		return fmt.Errorf("limit must be >= 1")
	}
	if p.Limit > MaxLimit {
		return fmt.Errorf("limit must be <= %d", MaxLimit)
	}
	if p.Offset < 0 {
		return fmt.Errorf("offset must be >= 0")
	}
	return nil
}

func BuildOrderClause(p Params, allowedFields []string) (string, error) {
	allowed := make(map[string]bool)
	for _, f := range allowedFields {
		allowed[f] = true
	}
	if !allowed[p.SortBy] {
		return "ORDER BY created_at DESC", nil
	}
	dir := "DESC"
	if strings.ToUpper(p.SortDir) == "ASC" {
		dir = "ASC"
	}
	return fmt.Sprintf("ORDER BY %s %s", p.SortBy, dir), nil
}

func NewMeta(total, limit, offset int) Meta {
	pages := total / limit
	if total%limit != 0 {
		pages++
	}
	page := offset/limit + 1
	return Meta{
		Total:   total,
		Limit:   limit,
		Offset:  offset,
		Page:    page,
		Pages:   pages,
		HasNext: offset+limit < total,
		HasPrev: offset > 0,
	}
}


type CursorPage struct {
	Data       interface{} `json:"data"`
	NextCursor string      `json:"next_cursor,omitempty"`
	PrevCursor string      `json:"prev_cursor,omitempty"`
	HasMore    bool        `json:"has_more"`
	PageSize   int         `json:"page_size"`
}

type OffsetPage struct {
	Data       interface{} `json:"data"`
	Total      int         `json:"total"`
	Page       int         `json:"page"`
	PageSize   int         `json:"page_size"`
	TotalPages int         `json:"total_pages"`
	HasNext    bool        `json:"has_next"`
	HasPrev    bool        `json:"has_prev"`
}

func NewOffsetPage(data interface{}, total, page, pageSize int) *OffsetPage {
	totalPages := total / pageSize
	if total%pageSize != 0 {
		totalPages++
	}
	return &OffsetPage{
		Data:       data,
		Total:      total,
		Page:       page,
		PageSize:   pageSize,
		TotalPages: totalPages,
		HasNext:    page < totalPages,
		HasPrev:    page > 1,
	}
}

func PageToOffset(page, pageSize int) int {
	if page < 1 {
		return 0
	}
	return (page - 1) * pageSize
}

func ValidatePaginationParams(page, pageSize int) (int, int, error) {
	if page < 1 {
		page = 1
	}
	if pageSize < 1 {
		pageSize = 20
	}
	if pageSize > 100 {
		pageSize = 100
	}
	return page, pageSize, nil
}
