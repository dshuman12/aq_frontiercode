package service

import (
	"fmt"
	"time"

	"inventoryapi.dev/api/internal/model"
	"inventoryapi.dev/api/internal/repository"
)

type ReportingService struct {
	invRepo   *repository.InventoryRepo
	orderRepo *repository.OrderRepo
	threshold int
}

func NewReportingService(inv *repository.InventoryRepo, ord *repository.OrderRepo, threshold int) *ReportingService {
	if threshold <= 0 { threshold = 10 }
	return &ReportingService{invRepo: inv, orderRepo: ord, threshold: threshold}
}

type StockReport struct {
	GeneratedAt  time.Time          `json:"generated_at"`
	LowStockItems []model.LowStockItem `json:"low_stock_items"`
	TotalAlerts  int                `json:"total_alerts"`
	CriticalCount int               `json:"critical_count"`
}

type TopProduct struct {
	ProductID   interface{} `json:"product_id"`
	ProductName interface{} `json:"product_name"`
	TotalSold   int         `json:"total_sold"`
}

func (s *ReportingService) GetLowStockReport() (*StockReport, error) {
	items, err := s.invRepo.GetLowStock(s.threshold)
	if err != nil {
		return nil, fmt.Errorf("failed to get low stock items: %w", err)
	}
	critical := 0
	for _, item := range items {
		if item.Available <= 0 {
			critical++
		}
	}
	return &StockReport{
		GeneratedAt:   time.Now(),
		LowStockItems: items,
		TotalAlerts:   len(items),
		CriticalCount: critical,
	}, nil
}

func (s *ReportingService) GetOrderVelocity(days int) (float64, error) {
	if days <= 0 { days = 30 }
	to := time.Now()
	from := to.AddDate(0, 0, -days)
	orders, err := s.orderRepo.GetByDateRange(from, to)
	if err != nil {
		return 0, err
	}
	if days == 0 { return 0, nil }
	return float64(len(orders)) / float64(days), nil
}

func (s *ReportingService) GetRevenueByPeriod(from, to time.Time) (float64, error) {
	if to.Before(from) {
		return 0, fmt.Errorf("to must be after from")
	}
	return s.orderRepo.GetRevenueByPeriod(from, to)
}

func (s *ReportingService) GetOrderCountByStatus() (map[string]int, error) {
	return s.orderRepo.CountByStatus()
}

func (s *ReportingService) GetOrderSummaryByDateRange(from, to time.Time) (map[string]any, error) {
	if to.Before(from) {
		return nil, fmt.Errorf("to date must be after from date")
	}
	diff := to.Sub(from).Hours() / 24
	if diff > 365 {
		return nil, fmt.Errorf("date range cannot exceed 365 days")
	}
	orders, err := s.orderRepo.GetByDateRange(from, to)
	if err != nil {
		return nil, err
	}
	statusCounts := make(map[string]int)
	totalRevenue := 0.0
	for _, o := range orders {
		statusCounts[string(o.Status)]++
		if o.Status == "fulfilled" {
			totalRevenue += o.TotalAmount
		}
	}
	fulfilled := statusCounts["fulfilled"]
	avgOrderValue := 0.0
	if fulfilled > 0 {
		avgOrderValue = totalRevenue / float64(fulfilled)
	}
	return map[string]any{
		"total_orders":    len(orders),
		"by_status":       statusCounts,
		"total_revenue":   totalRevenue,
		"avg_order_value": avgOrderValue,
		"period_days":     int(diff),
	}, nil
}

func (s *ReportingService) GetLowStockSummary() (map[string]any, error) {
	lowStock, err := s.invRepo.GetLowStock(s.threshold)
	if err != nil {
		return nil, err
	}
	criticalCount := 0
	for _, item := range lowStock {
		if item.Available <= 0 {
			criticalCount++
		}
	}
	return map[string]any{
		"low_stock_count": len(lowStock),
		"critical_count":  criticalCount,
		"threshold":       s.threshold,
		"items":           lowStock,
	}, nil
}

func (s *ReportingService) GetItemsNeedingReorder() ([]model.Inventory, error) {
	return s.invRepo.GetItemsNeedingReorder()
}
