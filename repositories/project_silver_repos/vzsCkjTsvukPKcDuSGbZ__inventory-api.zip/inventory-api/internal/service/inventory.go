package service

import (
	"fmt"

	"github.com/google/uuid"
	"inventoryapi.dev/api/internal/model"
	"inventoryapi.dev/api/internal/repository"
)

type InventoryService struct {
	invRepo *repository.InventoryRepo
	whRepo  *repository.WarehouseRepo
}

func NewInventoryService(inv *repository.InventoryRepo, wh *repository.WarehouseRepo) *InventoryService {
	return &InventoryService{invRepo: inv, whRepo: wh}
}

func (s *InventoryService) GetByProduct(pid uuid.UUID) ([]model.Inventory, error) {
	return s.invRepo.GetByProduct(pid)
}

func (s *InventoryService) Reserve(pid, wid uuid.UUID, qty int) error {
	if qty <= 0 {
		return fmt.Errorf("reservation quantity must be positive")
	}
	inv, err := s.invRepo.GetByProductAndWarehouse(pid, wid)
	if err != nil {
		return model.ErrNotFound
	}
	return s.invRepo.Reserve(inv.ID, qty)
}

func (s *InventoryService) Fulfill(pid, wid uuid.UUID, qty int) error {
	if qty <= 0 {
		return fmt.Errorf("fulfillment quantity must be positive")
	}
	inv, err := s.invRepo.GetByProductAndWarehouse(pid, wid)
	if err != nil {
		return model.ErrNotFound
	}
	return s.invRepo.Fulfill(inv.ID, qty)
}

func (s *InventoryService) CancelReservation(pid, wid uuid.UUID, qty int) error {
	if qty <= 0 {
		return fmt.Errorf("release quantity must be positive")
	}
	inv, err := s.invRepo.GetByProductAndWarehouse(pid, wid)
	if err != nil {
		return model.ErrNotFound
	}
	return s.invRepo.Release(inv.ID, qty)
}

func (s *InventoryService) Transfer(pid, fromWH, toWH uuid.UUID, qty int) error {
	if qty <= 0 {
		return fmt.Errorf("transfer quantity must be positive")
	}
	if fromWH == toWH {
		return model.ErrSameWarehouse
	}
	destWH, err := s.whRepo.GetByID(toWH)
	if err != nil {
		return model.ErrNotFound
	}
	if !destWH.IsActive {
		return model.ErrWarehouseInactive
	}
	if destWH.CurrentUsage+qty > destWH.MaxCapacity {
		return model.ErrWarehouseFull
	}
	return s.invRepo.Transfer(pid, fromWH, toWH, qty)
}

func (s *InventoryService) GetLowStock(threshold int) ([]model.LowStockItem, error) {
	if threshold < 0 {
		return nil, fmt.Errorf("threshold cannot be negative")
	}
	return s.invRepo.GetLowStock(threshold)
}

func (s *InventoryService) CreateInventoryRecord(inv *model.Inventory) error {
	if inv.ProductID == (uuid.UUID{}) {
		return fmt.Errorf("product_id is required")
	}
	if inv.WarehouseID == (uuid.UUID{}) {
		return fmt.Errorf("warehouse_id is required")
	}
	if inv.Quantity < 0 {
		return fmt.Errorf("quantity cannot be negative")
	}
	wh, err := s.whRepo.GetByID(inv.WarehouseID)
	if err != nil {
		return model.ErrNotFound
	}
	if !wh.IsActive {
		return model.ErrWarehouseInactive
	}
	if inv.ReorderPoint < 0 {
		inv.ReorderPoint = 10
	}
	if inv.ReorderQuantity <= 0 {
		inv.ReorderQuantity = 50
	}
	return s.invRepo.Create(inv)
}

func (s *InventoryService) GetByWarehouse(warehouseID string) ([]model.InventoryWithProduct, error) {
	uid, err := uuid.Parse(warehouseID)
	if err != nil {
		return nil, fmt.Errorf("invalid warehouse ID")
	}
	wh, err := s.whRepo.GetByID(uid)
	if err != nil || !wh.IsActive {
		return nil, model.ErrNotFound
	}
	return s.invRepo.GetByWarehouse(uid)
}

func (s *InventoryService) GetLowStockAlerts() ([]model.LowStockItem, error) {
	return s.invRepo.GetBelowReorderPoint()
}

func (s *InventoryService) BulkRestock(reqs []model.RestockRequest) error {
	for _, req := range reqs {
		if req.Quantity <= 0 {
			return fmt.Errorf("restock quantity must be positive for product %s", req.ProductID)
		}
		inv, err := s.invRepo.GetByProductAndWarehouse(req.ProductID, req.WarehouseID)
		if err != nil {
			return fmt.Errorf("inventory not found for product %s in warehouse %s", req.ProductID, req.WarehouseID)
		}
		if err := s.invRepo.UpdateQuantity(inv.ID, inv.Quantity+req.Quantity); err != nil {
			return err
		}
	}
	return nil
}

func (s *InventoryService) CalculateInventoryValue(warehouseID *string) (float64, error) {
	vals, err := s.invRepo.GetTotalValueByWarehouse()
	if err != nil {
		return 0, err
	}
	if warehouseID == nil {
		total := 0.0
		for _, v := range vals {
			total += v.TotalValue
		}
		return total, nil
	}
	uid, err := uuid.Parse(*warehouseID)
	if err != nil {
		return 0, fmt.Errorf("invalid warehouse ID")
	}
	for _, v := range vals {
		if v.WarehouseID == uid {
			return v.TotalValue, nil
		}
	}
	return 0, nil
}

func (s *InventoryService) CheckReorderNeeded(productID, warehouseID uuid.UUID) (bool, int, error) {
	inv, err := s.invRepo.GetByProductAndWarehouse(productID, warehouseID)
	if err != nil {
		return false, 0, model.ErrNotFound
	}
	available := inv.Quantity - inv.ReservedQuantity
	if available < inv.ReorderPoint {
		needed := inv.ReorderQuantity - available
		if needed < 0 {
			needed = inv.ReorderQuantity
		}
		return true, needed, nil
	}
	return false, 0, nil
}

func (s *InventoryService) GetWarehouseCapacitySummary(warehouseID string) (map[string]any, error) {
	uid, err := uuid.Parse(warehouseID)
	if err != nil {
		return nil, fmt.Errorf("invalid warehouse ID")
	}
	wh, err := s.whRepo.GetByID(uid)
	if err != nil {
		return nil, model.ErrNotFound
	}
	pct := 0.0
	if wh.MaxCapacity > 0 {
		pct = float64(wh.CurrentUsage) / float64(wh.MaxCapacity) * 100
	}
	return map[string]any{
		"warehouse_id":     wh.ID,
		"name":             wh.Name,
		"max_capacity":     wh.MaxCapacity,
		"current_usage":    wh.CurrentUsage,
		"available":        wh.MaxCapacity - wh.CurrentUsage,
		"utilization_pct":  pct,
		"is_near_capacity": pct > 85.0,
	}, nil
}

func (s *InventoryService) SetReorderThresholds(productID, warehouseID uuid.UUID, reorderPoint, reorderQty int) error {
	if reorderPoint < 0 {
		return fmt.Errorf("reorder_point cannot be negative")
	}
	if reorderQty <= 0 {
		return fmt.Errorf("reorder_quantity must be positive")
	}
	inv, err := s.invRepo.GetByProductAndWarehouse(productID, warehouseID)
	if err != nil {
		return model.ErrNotFound
	}
	return s.invRepo.SetReorderThresholds(inv.ID, reorderPoint, reorderQty)
}

