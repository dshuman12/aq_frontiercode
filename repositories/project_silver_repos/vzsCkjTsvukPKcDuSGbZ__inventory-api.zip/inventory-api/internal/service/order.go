package service

import (
	"fmt"
	"time"

	"github.com/google/uuid"
	"inventoryapi.dev/api/internal/model"
	"inventoryapi.dev/api/internal/repository"
)

type OrderService struct {
	orderRepo *repository.OrderRepo
	invSvc    *InventoryService
	prodRepo  *repository.ProductRepo
}

func NewOrderService(o *repository.OrderRepo, inv *InventoryService, p *repository.ProductRepo) *OrderService {
	return &OrderService{orderRepo: o, invSvc: inv, prodRepo: p}
}

func (s *OrderService) Create(req *model.CreateOrderRequest) (*model.Order, []model.OrderItem, error) {
	if req.CustomerID == "" {
		return nil, nil, fmt.Errorf("customer_id is required")
	}
	if len(req.Items) == 0 {
		return nil, nil, model.ErrEmptyOrder
	}
	order := &model.Order{
		ID:          uuid.New(),
		CustomerID:  req.CustomerID,
		Status:      "pending",
		Notes:       req.Notes,
		TotalAmount: 0,
	}
	if err := s.orderRepo.Create(order); err != nil {
		return nil, nil, fmt.Errorf("failed to create order: %w", err)
	}
	var items []model.OrderItem
	totalAmount := 0.0
	for _, itemReq := range req.Items {
		pid, err := uuid.Parse(itemReq.ProductID)
		if err != nil {
			return nil, nil, fmt.Errorf("invalid product ID: %s", itemReq.ProductID)
		}
		wid, err := uuid.Parse(itemReq.WarehouseID)
		if err != nil {
			return nil, nil, fmt.Errorf("invalid warehouse ID: %s", itemReq.WarehouseID)
		}
		if itemReq.Quantity <= 0 {
			return nil, nil, fmt.Errorf("quantity must be positive for product %s", itemReq.ProductID)
		}
		prod, err := s.prodRepo.GetByID(pid)
		if err != nil {
			return nil, nil, fmt.Errorf("product not found: %s", itemReq.ProductID)
		}
		inv, err := s.invSvc.invRepo.GetByProductAndWarehouse(pid, wid)
		if err != nil {
			return nil, nil, fmt.Errorf("inventory not found for product %s in warehouse %s", itemReq.ProductID, itemReq.WarehouseID)
		}
		if err := s.invSvc.invRepo.Reserve(inv.ID, itemReq.Quantity); err != nil {
			return nil, nil, model.NewStockError(itemReq.ProductID, itemReq.WarehouseID, itemReq.Quantity, inv.Quantity-inv.ReservedQuantity)
		}
		item := model.OrderItem{
			ID:           uuid.New(),
			OrderID:      order.ID,
			ProductID:    pid,
			WarehouseID:  wid,
			RequestedQty: itemReq.Quantity,
			FulfilledQty: 0,
			UnitPrice:    prod.UnitPrice,
		}
		if err := s.orderRepo.AddItem(&item); err != nil {
			return nil, nil, fmt.Errorf("failed to add order item: %w", err)
		}
		items = append(items, item)
		totalAmount += float64(itemReq.Quantity) * prod.UnitPrice
	}
	if err := s.orderRepo.UpdateTotalAmount(order.ID, totalAmount); err != nil {
		return nil, nil, err
	}
	order.TotalAmount = totalAmount
	return order, items, nil
}

func (s *OrderService) GetByID(id string) (*model.Order, []model.OrderItem, error) {
	uid, err := uuid.Parse(id)
	if err != nil {
		return nil, nil, fmt.Errorf("invalid order ID")
	}
	order, err := s.orderRepo.GetByID(uid)
	if err != nil {
		return nil, nil, err
	}
	items, err := s.orderRepo.GetItems(uid)
	if err != nil {
		return nil, nil, err
	}
	return order, items, nil
}

func (s *OrderService) Transition(id string, to model.OrderStatus) error {
	uid, err := uuid.Parse(id)
	if err != nil {
		return fmt.Errorf("invalid order ID")
	}
	order, err := s.orderRepo.GetByID(uid)
	if err != nil {
		return model.ErrNotFound
	}
	if !model.IsValidTransition(order.Status, to) {
		return model.NewTransitionError(string(order.Status), string(to))
	}
	if to == "fulfilled" || to == "partially_fulfilled" {
		if err := s.fulfillItems(uid); err != nil {
			return fmt.Errorf("failed to fulfill items: %w", err)
		}
	}
	if to == "cancelled" {
		if err := s.releaseReservations(uid); err != nil {
			return fmt.Errorf("failed to release reservations: %w", err)
		}
	}
	return s.orderRepo.UpdateStatus(uid, to)
}

func (s *OrderService) fulfillItems(orderID uuid.UUID) error {
	items, err := s.orderRepo.GetItems(orderID)
	if err != nil {
		return err
	}
	for _, item := range items {
		inv, err := s.invSvc.invRepo.GetByProductAndWarehouse(item.ProductID, item.WarehouseID)
		if err != nil {
			continue
		}
		if err := s.invSvc.invRepo.Fulfill(inv.ID, item.RequestedQty); err != nil {
			return err
		}
		s.orderRepo.UpdateItemFulfilledQty(item.ID, item.RequestedQty)
	}
	return nil
}

func (s *OrderService) releaseReservations(orderID uuid.UUID) error {
	items, err := s.orderRepo.GetItems(orderID)
	if err != nil {
		return err
	}
	for _, item := range items {
		inv, err := s.invSvc.invRepo.GetByProductAndWarehouse(item.ProductID, item.WarehouseID)
		if err != nil {
			continue
		}
		s.invSvc.invRepo.Release(inv.ID, item.RequestedQty)
	}
	return nil
}

func (s *OrderService) GetOrdersByCustomer(customerID string, limit, offset int) ([]model.Order, int, error) {
	if customerID == "" {
		return nil, 0, fmt.Errorf("customer_id cannot be empty")
	}
	return s.orderRepo.GetByCustomer(customerID, limit, offset)
}

func (s *OrderService) GetOrdersByStatus(status string) ([]model.Order, error) {
	validStatuses := map[string]bool{
		"":                   true,
		"pending":             true,
		"confirmed":           true,
		"fulfilled":           true,
		"partially_fulfilled": true,
		"cancelled":           true,
	}
	if !validStatuses[status] {
		return nil, fmt.Errorf("invalid status: %s", status)
	}
	if status == "" {
		orders, _, err := s.orderRepo.List("", 100, 0)
		return orders, err
	}
	return s.orderRepo.GetByStatus(status)
}

func (s *OrderService) BulkUpdateStatus(ids []string, status string) (int, error) {
	uids := make([]uuid.UUID, 0, len(ids))
	for _, id := range ids {
		uid, err := uuid.Parse(id)
		if err != nil {
			return 0, fmt.Errorf("invalid order ID: %s", id)
		}
		uids = append(uids, uid)
	}
	count, err := s.orderRepo.BulkUpdateStatus(uids, status)
	return int(count), err
}

func (s *OrderService) GetRevenueSummary(from, to time.Time) (float64, error) {
	if to.Before(from) {
		return 0, fmt.Errorf("to date must be after from date")
	}
	return s.orderRepo.GetRevenueByPeriod(from, to)
}

func (s *OrderService) GetStatusCounts() (map[string]int, error) {
	return s.orderRepo.CountByStatus()
}

func (s *OrderService) GetOrderSummary(from, to time.Time) (*model.OrderSummary, error) {
	if to.Before(from) {
		return nil, fmt.Errorf("to date must be after from date")
	}
	revenue, err := s.orderRepo.GetRevenueByPeriod(from, to)
	if err != nil {
		return nil, err
	}
	counts, err := s.orderRepo.CountByStatus()
	if err != nil {
		return nil, err
	}
	total := 0
	for _, c := range counts {
		total += c
	}
	summary := &model.OrderSummary{
		TotalOrders:  total,
		ByStatus:     counts,
		TotalRevenue: revenue,
		PeriodStart:  from,
		PeriodEnd:    to,
	}
	if counts["fulfilled"] > 0 {
		summary.AvgOrderValue = revenue / float64(counts["fulfilled"])
	}
	return summary, nil
}


func (s *OrderService) GetOrdersByDateRange(from, to time.Time) ([]model.Order, error) {
	if to.Before(from) {
		return nil, fmt.Errorf("to date must be after from date")
	}
	return s.orderRepo.GetByDateRange(from, to)
}
