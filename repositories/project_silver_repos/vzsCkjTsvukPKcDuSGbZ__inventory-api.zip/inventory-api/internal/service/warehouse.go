package service

import (
	"fmt"
	"strings"

	"github.com/google/uuid"
	"inventoryapi.dev/api/internal/model"
	"inventoryapi.dev/api/internal/repository"
)

type WarehouseService struct {
	repo *repository.WarehouseRepo
}

func NewWarehouseService(repo *repository.WarehouseRepo) *WarehouseService {
	return &WarehouseService{repo: repo}
}

func (s *WarehouseService) Create(req *model.CreateWarehouseRequest) (*model.Warehouse, error) {
	if strings.TrimSpace(req.Name) == "" {
		return nil, model.NewValidationError("name", "is required")
	}
	if req.MaxCapacity <= 0 {
		return nil, model.NewValidationError("max_capacity", "must be greater than zero")
	}
	w := &model.Warehouse{
		Name:        strings.TrimSpace(req.Name),
		Location:    req.Location,
		MaxCapacity: req.MaxCapacity,
		IsActive:    true,
	}
	if err := s.repo.Create(w); err != nil {
		return nil, fmt.Errorf("failed to create warehouse: %w", err)
	}
	return w, nil
}

func (s *WarehouseService) GetByID(id string) (*model.Warehouse, error) {
	uid, err := uuid.Parse(id)
	if err != nil {
		return nil, fmt.Errorf("invalid warehouse ID")
	}
	return s.repo.GetByID(uid)
}

func (s *WarehouseService) List(onlyActive bool) ([]model.Warehouse, error) {
	return s.repo.List(onlyActive)
}

func (s *WarehouseService) ListPaginated(limit, offset int, onlyActive bool) ([]model.Warehouse, int, error) {
	if limit <= 0 { limit = 20 }
	if limit > 100 { limit = 100 }
	return s.repo.ListPaginated(limit, offset, onlyActive)
}

func (s *WarehouseService) Update(id string, req *model.UpdateWarehouseRequest) (*model.Warehouse, error) {
	uid, err := uuid.Parse(id)
	if err != nil {
		return nil, fmt.Errorf("invalid warehouse ID")
	}
	if strings.TrimSpace(req.Name) == "" {
		return nil, model.NewValidationError("name", "is required")
	}
	if req.MaxCapacity <= 0 {
		return nil, model.NewValidationError("max_capacity", "must be greater than zero")
	}
	return s.repo.Update(uid, req)
}

func (s *WarehouseService) Deactivate(id string) error {
	uid, err := uuid.Parse(id)
	if err != nil {
		return fmt.Errorf("invalid warehouse ID")
	}
	if _, err := s.repo.GetByID(uid); err != nil {
		return model.ErrNotFound
	}
	return s.repo.SetActive(uid, false)
}

func (s *WarehouseService) Activate(id string) error {
	uid, err := uuid.Parse(id)
	if err != nil {
		return fmt.Errorf("invalid warehouse ID")
	}
	if _, err := s.repo.GetByID(uid); err != nil {
		return model.ErrNotFound
	}
	return s.repo.SetActive(uid, true)
}

func (s *WarehouseService) GetCapacityInfo(id string) (map[string]any, error) {
	uid, err := uuid.Parse(id)
	if err != nil {
		return nil, fmt.Errorf("invalid warehouse ID")
	}
	wh, err := s.repo.GetByID(uid)
	if err != nil {
		return nil, model.ErrNotFound
	}
	available := wh.MaxCapacity - wh.CurrentUsage
	pct := 0.0
	if wh.MaxCapacity > 0 {
		pct = float64(wh.CurrentUsage) / float64(wh.MaxCapacity) * 100
	}
	return map[string]any{
		"warehouse_id":     wh.ID,
		"name":             wh.Name,
		"max_capacity":     wh.MaxCapacity,
		"current_usage":    wh.CurrentUsage,
		"available":        available,
		"utilization_pct":  pct,
		"is_near_capacity": pct > 85.0,
	}, nil
}

func (s *WarehouseService) GetAllActive() ([]*model.Warehouse, error) {
	all, err := s.repo.List(true)
	if err != nil {
		return nil, err
	}
	result := make([]*model.Warehouse, len(all))
	for i := range all { result[i] = &all[i] }
	return result, nil
}

func (s *WarehouseService) CanAccommodate(warehouseID string, quantity int) (bool, error) {
	uid, err := uuid.Parse(warehouseID)
	if err != nil {
		return false, fmt.Errorf("invalid warehouse ID")
	}
	wh, err := s.repo.GetByID(uid)
	if err != nil {
		return false, model.ErrNotFound
	}
	if !wh.IsActive {
		return false, nil
	}
	return wh.CurrentUsage+quantity <= wh.MaxCapacity, nil
}

func (s *WarehouseService) ValidateTransfer(fromID, toID string, qty int) error {
	if fromID == toID {
		return model.ErrSameWarehouse
	}
	if qty <= 0 {
		return model.ErrInvalidQuantity
	}
	canFit, err := s.CanAccommodate(toID, qty)
	if err != nil {
		return err
	}
	if !canFit {
		return model.ErrWarehouseFull
	}
	return nil
}

func (s *WarehouseService) GetGlobalCapacityStats() (map[string]any, error) {
	total, used, err := s.repo.GetTotalCapacity()
	if err != nil {
		return nil, err
	}
	pct := 0.0
	if total > 0 {
		pct = float64(used) / float64(total) * 100
	}
	count, err := s.repo.CountActiveWarehouses()
	if err != nil {
		return nil, err
	}
	return map[string]any{
		"active_warehouses": count,
		"total_capacity":    total,
		"total_used":        used,
		"total_available":   total - used,
		"overall_pct":       pct,
	}, nil
}
