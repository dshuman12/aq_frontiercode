package service

import (
	"fmt"
	"strings"

	"github.com/google/uuid"
	"inventoryapi.dev/api/internal/model"
	"inventoryapi.dev/api/internal/repository"
)

type ProductService struct {
	repo *repository.ProductRepo
}

func NewProductService(repo *repository.ProductRepo) *ProductService {
	return &ProductService{repo: repo}
}

func (s *ProductService) Create(req *model.CreateProductRequest) (*model.Product, error) {
	if strings.TrimSpace(req.Name) == "" {
		return nil, model.NewValidationError("name", "is required")
	}
	if strings.TrimSpace(req.SKU) == "" {
		return nil, model.NewValidationError("sku", "is required")
	}
	if req.UnitPrice <= 0 {
		return nil, model.NewValidationError("unit_price", "must be greater than zero")
	}
	req.SKU = strings.ToUpper(strings.TrimSpace(req.SKU))
	existing, _ := s.repo.GetBySKU(req.SKU)
	if existing != nil {
		return nil, model.ErrDuplicateSKU
	}
	p := &model.Product{
		SKU:         req.SKU,
		Name:        strings.TrimSpace(req.Name),
		Description: req.Description,
		Category:    req.Category,
		UnitPrice:   req.UnitPrice,
		WeightKg:    req.WeightKg,
	}
	if err := s.repo.Create(p); err != nil {
		return nil, fmt.Errorf("failed to create product: %w", err)
	}
	return p, nil
}

func (s *ProductService) GetByID(id string) (*model.Product, error) {
	uid, err := uuid.Parse(id)
	if err != nil {
		return nil, fmt.Errorf("invalid product ID")
	}
	return s.repo.GetByID(uid)
}

func (s *ProductService) List(limit, offset int, category string) ([]model.Product, int, error) {
	if limit <= 0 { limit = 20 }
	if limit > 100 { limit = 100 }
	if offset < 0 { offset = 0 }
	return s.repo.List(limit, offset, category)
}

func (s *ProductService) Update(id string, req *model.UpdateProductRequest) (*model.Product, error) {
	uid, err := uuid.Parse(id)
	if err != nil {
		return nil, fmt.Errorf("invalid product ID")
	}
	if strings.TrimSpace(req.Name) == "" {
		return nil, model.NewValidationError("name", "is required")
	}
	if req.UnitPrice <= 0 {
		return nil, model.NewValidationError("unit_price", "must be greater than zero")
	}
	return s.repo.Update(uid, req)
}

func (s *ProductService) Delete(id string) error {
	uid, err := uuid.Parse(id)
	if err != nil {
		return fmt.Errorf("invalid product ID")
	}
	return s.repo.Delete(uid)
}

func (s *ProductService) SearchProducts(query string, limit, offset int) ([]*model.Product, error) {
	if strings.TrimSpace(query) == "" {
		return nil, fmt.Errorf("search query cannot be empty")
	}
	if limit <= 0 { limit = 20 }
	if limit > 100 { limit = 100 }
	return s.repo.SearchByName(strings.TrimSpace(query), limit, offset)
}

func (s *ProductService) GetByCategory(category string) ([]*model.Product, error) {
	if strings.TrimSpace(category) == "" {
		return nil, fmt.Errorf("category cannot be empty")
	}
	rows, err := s.repo.GetByCategory(category)
	if err != nil {
		return nil, err
	}
	result := make([]*model.Product, len(rows))
	for i := range rows { result[i] = &rows[i] }
	return result, nil
}

func (s *ProductService) BulkCreate(reqs []*model.CreateProductRequest) ([]*model.Product, error) {
	results := make([]*model.Product, 0, len(reqs))
	for _, req := range reqs {
		existing, _ := s.repo.GetBySKU(strings.ToUpper(req.SKU))
		if existing != nil {
			return nil, fmt.Errorf("duplicate SKU %s in bulk create", req.SKU)
		}
		p, err := s.Create(req)
		if err != nil {
			return nil, fmt.Errorf("failed to create product %s: %w", req.SKU, err)
		}
		results = append(results, p)
	}
	return results, nil
}

func (s *ProductService) GetProductStats(productID string) (*model.ProductStats, error) {
	uid, err := uuid.Parse(productID)
	if err != nil {
		return nil, fmt.Errorf("invalid product ID")
	}
	inventoryList, err := s.repo.GetInventoryForProduct(uid)
	if err != nil {
		return nil, err
	}
	stats := &model.ProductStats{ProductID: uid, WarehouseCount: len(inventoryList)}
	for _, inv := range inventoryList {
		stats.TotalStock += inv.Quantity
		stats.TotalReserved += inv.ReservedQuantity
	}
	stats.Available = stats.TotalStock - stats.TotalReserved
	return stats, nil
}

func (s *ProductService) UpdatePricing(productID string, newPrice float64) (*model.Product, error) {
	if newPrice <= 0 {
		return nil, fmt.Errorf("price must be greater than zero")
	}
	uid, err := uuid.Parse(productID)
	if err != nil {
		return nil, fmt.Errorf("invalid product ID")
	}
	if _, err := s.repo.GetByID(uid); err != nil {
		return nil, model.ErrNotFound
	}
	return s.repo.UpdatePrice(uid, newPrice)
}

func (s *ProductService) GetAllCategories() ([]string, error) {
	counts, err := s.repo.CountByCategory()
	if err != nil {
		return nil, err
	}
	cats := make([]string, 0, len(counts))
	for k := range counts { cats = append(cats, k) }
	return cats, nil
}

func (s *ProductService) GetWithInventorySummary(productID string) (*model.ProductWithInventory, error) {
	uid, err := uuid.Parse(productID)
	if err != nil {
		return nil, fmt.Errorf("invalid product ID")
	}
	return s.repo.GetWithInventorySummary(uid)
}

func (s *ProductService) ValidateSKU(sku string) error {
	sku = strings.ToUpper(strings.TrimSpace(sku))
	if len(sku) < 3 {
		return model.NewValidationError("sku", "must be at least 3 characters")
	}
	if len(sku) > 50 {
		return model.NewValidationError("sku", "must be at most 50 characters")
	}
	for _, r := range sku {
		if !isValidSKUChar(r) {
			return model.NewValidationError("sku", "can only contain letters, numbers, hyphens and underscores")
		}
	}
	return nil
}

func isValidSKUChar(r rune) bool {
	return (r >= 'A' && r <= 'Z') || (r >= '0' && r <= '9') || r == '-' || r == '_'
}
