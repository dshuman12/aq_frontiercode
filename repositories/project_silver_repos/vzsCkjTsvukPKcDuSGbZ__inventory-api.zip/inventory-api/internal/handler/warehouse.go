package handler

import (
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
	"inventoryapi.dev/api/internal/model"
	"inventoryapi.dev/api/internal/service"
)

type WarehouseHandler struct {
	svc *service.WarehouseService
}

func NewWarehouseHandler(svc *service.WarehouseService) *WarehouseHandler {
	return &WarehouseHandler{svc: svc}
}

func (h *WarehouseHandler) RegisterRoutes(rg *gin.RouterGroup) {
	rg.GET("/warehouses", h.List)
	rg.GET("/warehouses/:id", h.GetByID)
	rg.POST("/warehouses", h.Create)
	rg.PUT("/warehouses/:id", h.Update)
	rg.PUT("/warehouses/:id/deactivate", h.Deactivate)
	rg.PUT("/warehouses/:id/activate", h.Activate)
	rg.GET("/warehouses/:id/capacity", h.GetCapacity)
	rg.GET("/warehouses/stats/global", h.GetGlobalStats)
}

func (h *WarehouseHandler) List(c *gin.Context) {
	limit, _ := strconv.Atoi(c.DefaultQuery("limit", "20"))
	offset, _ := strconv.Atoi(c.DefaultQuery("offset", "0"))
	activeOnly := c.DefaultQuery("active", "true") == "true"
	if limit <= 0 || limit > 100 { limit = 20 }
	warehouses, total, err := h.svc.ListPaginated(limit, offset, activeOnly)
	if err != nil {
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondList(c, warehouses, total, limit, offset)
}

func (h *WarehouseHandler) GetByID(c *gin.Context) {
	w, err := h.svc.GetByID(c.Param("id"))
	if err != nil {
		if model.IsNotFound(err) {
			respondError(c, http.StatusNotFound, "warehouse not found")
			return
		}
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondOK(c, w)
}

func (h *WarehouseHandler) Create(c *gin.Context) {
	var req model.CreateWarehouseRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		respondError(c, http.StatusBadRequest, err.Error())
		return
	}
	if req.Name == "" {
		respondError(c, http.StatusBadRequest, "name is required")
		return
	}
	if req.MaxCapacity <= 0 {
		respondError(c, http.StatusBadRequest, "max_capacity must be positive")
		return
	}
	w, err := h.svc.Create(&req)
	if err != nil {
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondCreated(c, w)
}

func (h *WarehouseHandler) Update(c *gin.Context) {
	var req model.UpdateWarehouseRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		respondError(c, http.StatusBadRequest, err.Error())
		return
	}
	w, err := h.svc.Update(c.Param("id"), &req)
	if err != nil {
		if model.IsNotFound(err) {
			respondError(c, http.StatusNotFound, "warehouse not found")
			return
		}
		respondError(c, http.StatusBadRequest, err.Error())
		return
	}
	respondOK(c, w)
}

func (h *WarehouseHandler) Deactivate(c *gin.Context) {
	if err := h.svc.Deactivate(c.Param("id")); err != nil {
		if model.IsNotFound(err) {
			respondError(c, http.StatusNotFound, "warehouse not found")
			return
		}
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondOK(c, gin.H{"status": "deactivated"})
}

func (h *WarehouseHandler) Activate(c *gin.Context) {
	if err := h.svc.Activate(c.Param("id")); err != nil {
		if model.IsNotFound(err) {
			respondError(c, http.StatusNotFound, "warehouse not found")
			return
		}
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondOK(c, gin.H{"status": "activated"})
}

func (h *WarehouseHandler) GetCapacity(c *gin.Context) {
	info, err := h.svc.GetCapacityInfo(c.Param("id"))
	if err != nil {
		if model.IsNotFound(err) {
			respondError(c, http.StatusNotFound, "warehouse not found")
			return
		}
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondOK(c, info)
}

func (h *WarehouseHandler) GetGlobalStats(c *gin.Context) {
	stats, err := h.svc.GetGlobalCapacityStats()
	if err != nil {
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondOK(c, stats)
}
