package handler

import (
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"inventoryapi.dev/api/internal/notification"
)

type NotificationHandler struct {
	svc *notification.Service
}

func NewNotificationHandler(svc *notification.Service) *NotificationHandler {
	return &NotificationHandler{svc: svc}
}

func (h *NotificationHandler) RegisterRoutes(rg *gin.RouterGroup) {
	rg.GET("/notifications", h.List)
	rg.PUT("/notifications/:id/read", h.MarkRead)
	rg.GET("/notifications/unread", h.GetUnread)
}

func (h *NotificationHandler) List(c *gin.Context) {
	limit, _ := strconv.Atoi(c.DefaultQuery("limit", "50"))
	offset, _ := strconv.Atoi(c.DefaultQuery("offset", "0"))
	if limit <= 0 { limit = 50 }
	if limit > 200 { limit = 200 }
	f := notification.Filter{
		Channel: c.Query("channel"),
		Status:  c.Query("status"),
		Limit:   limit,
		Offset:  offset,
	}
	if ridStr := c.Query("recipient_id"); ridStr != "" {
		rid, err := uuid.Parse(ridStr)
		if err == nil {
			f.RecipientID = &rid
		}
	}
	rows, total, err := h.svc.GetHistory(c.Request.Context(), f)
	if err != nil {
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondList(c, rows, total, limit, offset)
}

func (h *NotificationHandler) MarkRead(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, http.StatusBadRequest, "invalid notification ID")
		return
	}
	if err := h.svc.MarkRead(c.Request.Context(), id); err != nil {
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondOK(c, gin.H{"marked_read": true})
}

func (h *NotificationHandler) GetUnread(c *gin.Context) {
	ridStr := c.Query("recipient_id")
	if ridStr == "" {
		respondError(c, http.StatusBadRequest, "recipient_id is required")
		return
	}
	rid, err := uuid.Parse(ridStr)
	if err != nil {
		respondError(c, http.StatusBadRequest, "invalid recipient ID")
		return
	}
	rows, err := h.svc.GetUnread(c.Request.Context(), rid)
	if err != nil {
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondOK(c, gin.H{"notifications": rows, "count": len(rows)})
}
