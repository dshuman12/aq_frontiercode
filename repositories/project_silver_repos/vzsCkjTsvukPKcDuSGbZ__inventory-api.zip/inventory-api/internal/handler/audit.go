package handler

import (
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"inventoryapi.dev/api/internal/audit"
)

type AuditHandler struct {
	logger audit.Logger
}

func NewAuditHandler(l audit.Logger) *AuditHandler {
	return &AuditHandler{logger: l}
}

func (h *AuditHandler) RegisterRoutes(rg *gin.RouterGroup) {
	rg.GET("/audit/entity/:type/:id", h.GetEntityHistory)
	rg.GET("/audit/actor/:id", h.GetActorHistory)
	rg.GET("/audit", h.QueryAuditLogs)
}

func (h *AuditHandler) GetEntityHistory(c *gin.Context) {
	entityType := c.Param("type")
	if entityType == "" {
		respondError(c, http.StatusBadRequest, "entity type is required")
		return
	}
	idStr := c.Param("id")
	entityID, err := uuid.Parse(idStr)
	if err != nil {
		respondError(c, http.StatusBadRequest, "invalid entity ID")
		return
	}
	logs, err := h.logger.GetEntityHistory(c.Request.Context(), entityType, entityID)
	if err != nil {
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondOK(c, logs)
}

func (h *AuditHandler) GetActorHistory(c *gin.Context) {
	actorID, err := uuid.Parse(c.Param("id"))
	if err != nil {
		respondError(c, http.StatusBadRequest, "invalid actor ID")
		return
	}
	limitStr := c.DefaultQuery("limit", "50")
	limit, _ := strconv.Atoi(limitStr)
	if limit <= 0 || limit > 200 {
		limit = 50
	}
	logs, err := h.logger.GetActorActivity(c.Request.Context(), actorID, limit)
	if err != nil {
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondOK(c, logs)
}

func (h *AuditHandler) QueryAuditLogs(c *gin.Context) {
	filter := audit.AuditFilter{
		EntityType: c.Query("entity_type"),
		Action:     c.Query("action"),
	}
	limitStr := c.DefaultQuery("limit", "50")
	offsetStr := c.DefaultQuery("offset", "0")
	filter.Limit, _ = strconv.Atoi(limitStr)
	filter.Offset, _ = strconv.Atoi(offsetStr)
	if filter.Limit <= 0 { filter.Limit = 50 }
	if filter.Limit > 200 { filter.Limit = 200 }
	if idStr := c.Query("entity_id"); idStr != "" {
		id, err := uuid.Parse(idStr)
		if err == nil {
			filter.EntityID = &id
		}
	}
	if idStr := c.Query("actor_id"); idStr != "" {
		id, err := uuid.Parse(idStr)
		if err == nil {
			filter.ActorID = &id
		}
	}
	logs, total, err := h.logger.Query(c.Request.Context(), filter)
	if err != nil {
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondList(c, logs, total, filter.Limit, filter.Offset)
}
