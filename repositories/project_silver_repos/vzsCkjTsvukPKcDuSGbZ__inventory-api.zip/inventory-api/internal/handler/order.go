package handler

import (
	"net/http"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"inventoryapi.dev/api/internal/model"
	"inventoryapi.dev/api/internal/service"
)

type OrderHandler struct {
	svc *service.OrderService
}

func NewOrderHandler(svc *service.OrderService) *OrderHandler {
	return &OrderHandler{svc: svc}
}

func (h *OrderHandler) RegisterRoutes(rg *gin.RouterGroup) {
	rg.GET("/orders", h.List)
	rg.GET("/orders/:id", h.GetByID)
	rg.POST("/orders", h.Create)
	rg.PUT("/orders/:id/confirm", h.Confirm)
	rg.PUT("/orders/:id/fulfill", h.Fulfill)
	rg.PUT("/orders/:id/cancel", h.Cancel)
	rg.GET("/orders/customer/:customer_id", h.GetByCustomer)
	rg.POST("/orders/bulk-status", h.BulkUpdateStatus)
	rg.GET("/orders/summary", h.GetSummary)
}

func (h *OrderHandler) List(c *gin.Context) {
	limit, _ := strconv.Atoi(c.DefaultQuery("limit", "20"))
	offset, _ := strconv.Atoi(c.DefaultQuery("offset", "0"))
	status := c.Query("status")
	if limit <= 0 || limit > 100 {
		limit = 20
	}
	orders, err := h.svc.GetOrdersByStatus(status)
	if err != nil && status != "" {
		respondError(c, http.StatusBadRequest, err.Error())
		return
	}
	if status == "" {
		counts, _ := h.svc.GetStatusCounts()
		respondOK(c, gin.H{"orders": orders, "status_counts": counts, "limit": limit, "offset": offset})
		return
	}
	respondList(c, orders, len(orders), limit, offset)
}

func (h *OrderHandler) GetByID(c *gin.Context) {
	order, items, err := h.svc.GetByID(c.Param("id"))
	if err != nil {
		if model.IsNotFound(err) {
			respondError(c, http.StatusNotFound, "order not found")
			return
		}
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondOK(c, gin.H{"order": order, "items": items})
}

func (h *OrderHandler) Create(c *gin.Context) {
	var req model.CreateOrderRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		respondError(c, http.StatusBadRequest, err.Error())
		return
	}
	if req.CustomerID == "" {
		respondError(c, http.StatusBadRequest, "customer_id is required")
		return
	}
	if len(req.Items) == 0 {
		respondError(c, http.StatusBadRequest, "order must contain at least one item")
		return
	}
	for i, item := range req.Items {
		if item.ProductID == "" {
			respondError(c, http.StatusBadRequest, "product_id is required for all items")
			return
		}
		if item.Quantity <= 0 {
			respondError(c, http.StatusBadRequest, "quantity must be positive for item "+strconv.Itoa(i+1))
			return
		}
	}
	order, items, err := h.svc.Create(&req)
	if err != nil {
		if model.IsInsufficientStock(err) {
			respondError(c, http.StatusConflict, err.Error())
			return
		}
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondCreated(c, gin.H{"order": order, "items": items})
}

func (h *OrderHandler) Confirm(c *gin.Context) {
	if err := h.svc.Transition(c.Param("id"), model.OrderStatus("confirmed")); err != nil {
		if model.IsNotFound(err) {
			respondError(c, http.StatusNotFound, "order not found")
			return
		}
		if model.IsInvalidTransition(err) {
			respondError(c, http.StatusUnprocessableEntity, err.Error())
			return
		}
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondOK(c, gin.H{"status": "confirmed"})
}

func (h *OrderHandler) Fulfill(c *gin.Context) {
	if err := h.svc.Transition(c.Param("id"), model.OrderStatus("fulfilled")); err != nil {
		if model.IsNotFound(err) {
			respondError(c, http.StatusNotFound, "order not found")
			return
		}
		if model.IsInvalidTransition(err) {
			respondError(c, http.StatusUnprocessableEntity, err.Error())
			return
		}
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondOK(c, gin.H{"status": "fulfilled"})
}

func (h *OrderHandler) Cancel(c *gin.Context) {
	if err := h.svc.Transition(c.Param("id"), model.OrderStatus("cancelled")); err != nil {
		if model.IsNotFound(err) {
			respondError(c, http.StatusNotFound, "order not found")
			return
		}
		if model.IsInvalidTransition(err) {
			respondError(c, http.StatusUnprocessableEntity, err.Error())
			return
		}
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondOK(c, gin.H{"status": "cancelled"})
}

func (h *OrderHandler) GetByCustomer(c *gin.Context) {
	customerID := c.Param("customer_id")
	limit, _ := strconv.Atoi(c.DefaultQuery("limit", "20"))
	offset, _ := strconv.Atoi(c.DefaultQuery("offset", "0"))
	if limit <= 0 || limit > 100 {
		limit = 20
	}
	orders, total, err := h.svc.GetOrdersByCustomer(customerID, limit, offset)
	if err != nil {
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondList(c, orders, total, limit, offset)
}

func (h *OrderHandler) BulkUpdateStatus(c *gin.Context) {
	var req model.BulkOrderStatusUpdate
	if err := c.ShouldBindJSON(&req); err != nil {
		respondError(c, http.StatusBadRequest, err.Error())
		return
	}
	if len(req.OrderIDs) == 0 {
		respondError(c, http.StatusBadRequest, "order_ids cannot be empty")
		return
	}
	if req.Status == "" {
		respondError(c, http.StatusBadRequest, "status is required")
		return
	}
	ids := make([]string, len(req.OrderIDs))
	for i, id := range req.OrderIDs {
		ids[i] = id.String()
	}
	count, err := h.svc.BulkUpdateStatus(ids, req.Status)
	if err != nil {
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondOK(c, gin.H{"updated": count})
}

func (h *OrderHandler) GetSummary(c *gin.Context) {
	fromStr := c.DefaultQuery("from", "")
	toStr := c.DefaultQuery("to", "")
	to := time.Now()
	from := to.AddDate(0, 0, -30)
	if fromStr != "" {
		if t, err := time.Parse("2006-01-02", fromStr); err == nil {
			from = t
		}
	}
	if toStr != "" {
		if t, err := time.Parse("2006-01-02", toStr); err == nil {
			to = t
		}
	}
	summary, err := h.svc.GetOrderSummary(from, to)
	if err != nil {
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondOK(c, summary)
}
