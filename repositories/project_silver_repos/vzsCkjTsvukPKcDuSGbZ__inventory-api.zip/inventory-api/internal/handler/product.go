package handler

import (
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
	"inventoryapi.dev/api/internal/model"
	"inventoryapi.dev/api/internal/service"
)

type ProductHandler struct {
	svc *service.ProductService
}

func NewProductHandler(svc *service.ProductService) *ProductHandler {
	return &ProductHandler{svc: svc}
}

func (h *ProductHandler) RegisterRoutes(rg *gin.RouterGroup) {
	rg.GET("/products", h.List)
	rg.GET("/products/:id", h.GetByID)
	rg.POST("/products", h.Create)
	rg.PUT("/products/:id", h.Update)
	rg.DELETE("/products/:id", h.Delete)
	rg.GET("/products/search", h.Search)
	rg.GET("/products/categories", h.GetCategories)
	rg.GET("/products/:id/stats", h.GetStats)
	rg.POST("/products/bulk", h.BulkCreate)
	rg.PUT("/products/:id/price", h.UpdatePrice)
}

func (h *ProductHandler) List(c *gin.Context) {
	limit, _ := strconv.Atoi(c.DefaultQuery("limit", "20"))
	offset, _ := strconv.Atoi(c.DefaultQuery("offset", "0"))
	category := c.Query("category")
	if limit <= 0 || limit > 100 {
		limit = 20
	}
	if offset < 0 {
		offset = 0
	}
	products, total, err := h.svc.List(limit, offset, category)
	if err != nil {
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondList(c, products, total, limit, offset)
}

func (h *ProductHandler) GetByID(c *gin.Context) {
	p, err := h.svc.GetByID(c.Param("id"))
	if err != nil {
		if model.IsNotFound(err) {
			respondError(c, http.StatusNotFound, "product not found")
			return
		}
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondOK(c, p)
}

func (h *ProductHandler) Create(c *gin.Context) {
	var req model.CreateProductRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		respondError(c, http.StatusBadRequest, err.Error())
		return
	}
	if req.Name == "" {
		respondError(c, http.StatusBadRequest, "name is required")
		return
	}
	if req.SKU == "" {
		respondError(c, http.StatusBadRequest, "sku is required")
		return
	}
	if req.UnitPrice <= 0 {
		respondError(c, http.StatusBadRequest, "unit_price must be greater than zero")
		return
	}
	p, err := h.svc.Create(&req)
	if err != nil {
		if err == model.ErrDuplicateSKU {
			respondError(c, http.StatusConflict, err.Error())
			return
		}
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondCreated(c, p)
}

func (h *ProductHandler) Update(c *gin.Context) {
	var req model.UpdateProductRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		respondError(c, http.StatusBadRequest, err.Error())
		return
	}
	if req.Name == "" {
		respondError(c, http.StatusBadRequest, "name is required")
		return
	}
	if req.UnitPrice <= 0 {
		respondError(c, http.StatusBadRequest, "unit_price must be greater than zero")
		return
	}
	p, err := h.svc.Update(c.Param("id"), &req)
	if err != nil {
		if model.IsNotFound(err) {
			respondError(c, http.StatusNotFound, "product not found")
			return
		}
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondOK(c, p)
}

func (h *ProductHandler) Delete(c *gin.Context) {
	if err := h.svc.Delete(c.Param("id")); err != nil {
		if model.IsNotFound(err) {
			respondError(c, http.StatusNotFound, "product not found")
			return
		}
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondNoContent(c)
}

func (h *ProductHandler) Search(c *gin.Context) {
	query := c.Query("q")
	if query == "" {
		respondError(c, http.StatusBadRequest, "q parameter is required")
		return
	}
	limit, _ := strconv.Atoi(c.DefaultQuery("limit", "20"))
	offset, _ := strconv.Atoi(c.DefaultQuery("offset", "0"))
	if limit <= 0 || limit > 100 {
		limit = 20
	}
	products, err := h.svc.SearchProducts(query, limit, offset)
	if err != nil {
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondOK(c, gin.H{"products": products, "query": query})
}

func (h *ProductHandler) GetCategories(c *gin.Context) {
	cats, err := h.svc.GetAllCategories()
	if err != nil {
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondOK(c, gin.H{"categories": cats})
}

func (h *ProductHandler) GetStats(c *gin.Context) {
	stats, err := h.svc.GetProductStats(c.Param("id"))
	if err != nil {
		if model.IsNotFound(err) {
			respondError(c, http.StatusNotFound, "product not found")
			return
		}
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondOK(c, stats)
}

func (h *ProductHandler) BulkCreate(c *gin.Context) {
	var req model.BulkCreateProductRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		respondError(c, http.StatusBadRequest, err.Error())
		return
	}
	if len(req.Products) == 0 {
		respondError(c, http.StatusBadRequest, "products list cannot be empty")
		return
	}
	if len(req.Products) > 100 {
		respondError(c, http.StatusBadRequest, "cannot create more than 100 products at once")
		return
	}
	ptrs := make([]*model.CreateProductRequest, len(req.Products))
	for i := range req.Products {
		ptrs[i] = &req.Products[i]
	}
	created, err := h.svc.BulkCreate(ptrs)
	if err != nil {
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondCreated(c, gin.H{"products": created, "count": len(created)})
}

func (h *ProductHandler) UpdatePrice(c *gin.Context) {
	var req struct {
		Price float64 `json:"price"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		respondError(c, http.StatusBadRequest, err.Error())
		return
	}
	if req.Price <= 0 {
		respondError(c, http.StatusBadRequest, "price must be greater than zero")
		return
	}
	p, err := h.svc.UpdatePricing(c.Param("id"), req.Price)
	if err != nil {
		if model.IsNotFound(err) {
			respondError(c, http.StatusNotFound, "product not found")
			return
		}
		respondError(c, http.StatusBadRequest, err.Error())
		return
	}
	respondOK(c, p)
}
