package handler

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

type listResponse struct {
	Data   any `json:"data"`
	Total  int `json:"total"`
	Limit  int `json:"limit"`
	Offset int `json:"offset"`
}

func respondOK(c *gin.Context, data any) {
	c.JSON(http.StatusOK, gin.H{"data": data, "error": nil})
}

func respondCreated(c *gin.Context, data any) {
	c.JSON(http.StatusCreated, gin.H{"data": data, "error": nil})
}

func respondError(c *gin.Context, status int, msg string) {
	c.JSON(status, gin.H{"data": nil, "error": msg})
}

func respondList(c *gin.Context, data any, total, limit, offset int) {
	c.JSON(http.StatusOK, listResponse{
		Data:   data,
		Total:  total,
		Limit:  limit,
		Offset: offset,
	})
}

func respondNoContent(c *gin.Context) {
	c.Status(http.StatusNoContent)
}
