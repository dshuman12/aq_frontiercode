package handler

import (
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"inventoryapi.dev/api/internal/model"
	"inventoryapi.dev/api/internal/service"
)

type InventoryHandler struct {
	svc *service.InventoryService
}

func NewInventoryHandler(svc *service.InventoryService) *InventoryHandler {
	return &InventoryHandler{svc: svc}
}

func (h *InventoryHandler) RegisterRoutes(rg *gin.RouterGroup) {
	rg.GET("/inventory/product/:product_id", h.GetByProduct)
	rg.GET("/inventory/warehouse/:warehouse_id", h.GetByWarehouse)
	rg.POST("/inventory/transfer", h.Transfer)
	rg.GET("/inventory/low-stock", h.GetLowStock)
	rg.POST("/inventory/restock", h.BulkRestock)
	rg.GET("/inventory/value", h.GetTotalValue)
	rg.GET("/inventory/product/:product_id/reorder-check", h.CheckReorder)
}

func (h *InventoryHandler) GetByProduct(c *gin.Context) {
	productID := c.Param("product_id")
	if productID == "" {
		respondError(c, http.StatusBadRequest, "product_id is required")
		return
	}
	uid, err := uuid.Parse(productID)
	if err != nil {
		respondError(c, http.StatusBadRequest, "invalid product ID")
		return
	}
	inventory, err := h.svc.GetByProduct(uid)
	if err != nil {
		if model.IsNotFound(err) {
			respondError(c, http.StatusNotFound, "product not found")
			return
		}
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondOK(c, inventory)
}

func (h *InventoryHandler) GetByWarehouse(c *gin.Context) {
	rows, err := h.svc.GetByWarehouse(c.Param("warehouse_id"))
	if err != nil {
		if model.IsNotFound(err) {
			respondError(c, http.StatusNotFound, "warehouse not found")
			return
		}
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondOK(c, gin.H{"inventory": rows, "count": len(rows)})
}

func (h *InventoryHandler) Transfer(c *gin.Context) {
	var req model.TransferRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		respondError(c, http.StatusBadRequest, err.Error())
		return
	}
	if req.ProductID == (req.ProductID) && req.FromWarehouseID == req.ToWarehouseID {
		respondError(c, http.StatusBadRequest, "source and destination warehouses must be different")
		return
	}
	if req.Quantity <= 0 {
		respondError(c, http.StatusBadRequest, "quantity must be positive")
		return
	}
	if err := h.svc.Transfer(req.ProductID, req.FromWarehouseID, req.ToWarehouseID, req.Quantity); err != nil {
		if model.IsInsufficientStock(err) {
			respondError(c, http.StatusConflict, err.Error())
			return
		}
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondOK(c, gin.H{"transferred": req.Quantity})
}

func (h *InventoryHandler) GetLowStock(c *gin.Context) {
	thresholdStr := c.DefaultQuery("threshold", "10")
	threshold, _ := strconv.Atoi(thresholdStr)
	if threshold < 0 {
		threshold = 10
	}
	items, err := h.svc.GetLowStock(threshold)
	if err != nil {
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondOK(c, gin.H{"items": items, "count": len(items), "threshold": threshold})
}

func (h *InventoryHandler) BulkRestock(c *gin.Context) {
	var req struct {
		Items []model.RestockRequest `json:"items"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		respondError(c, http.StatusBadRequest, err.Error())
		return
	}
	if len(req.Items) == 0 {
		respondError(c, http.StatusBadRequest, "items cannot be empty")
		return
	}
	if err := h.svc.BulkRestock(req.Items); err != nil {
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondOK(c, gin.H{"restocked": len(req.Items)})
}

func (h *InventoryHandler) GetTotalValue(c *gin.Context) {
	warehouseID := c.Query("warehouse_id")
	var wid *string
	if warehouseID != "" {
		wid = &warehouseID
	}
	value, err := h.svc.CalculateInventoryValue(wid)
	if err != nil {
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondOK(c, gin.H{"total_value": value, "warehouse_id": warehouseID})
}

func (h *InventoryHandler) CheckReorder(c *gin.Context) {
	warehouseID := c.Query("warehouse_id")
	if warehouseID == "" {
		respondError(c, http.StatusBadRequest, "warehouse_id is required")
		return
	}

	respondOK(c, gin.H{"product_id": c.Param("product_id"), "warehouse_id": warehouseID, "note": "use service layer for actual check"})
}
