package handler

import (
	"net/http"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"inventoryapi.dev/api/internal/report"
	"inventoryapi.dev/api/internal/service"
)

type ReportHandler struct {
	reportSvc   *report.Service
	orderSvc    *service.OrderService
	productSvc  *service.ProductService
	inventorySvc *service.InventoryService
}

func NewReportHandler(r *report.Service, o *service.OrderService, p *service.ProductService, i *service.InventoryService) *ReportHandler {
	return &ReportHandler{reportSvc: r, orderSvc: o, productSvc: p, inventorySvc: i}
}

func (h *ReportHandler) RegisterRoutes(rg *gin.RouterGroup) {
	rg.GET("/reports/summary", h.GetSummary)
	rg.GET("/reports/orders/status", h.GetOrderStatusDistribution)
	rg.GET("/reports/orders/trend", h.GetRevenueTrend)
	rg.GET("/reports/warehouses/utilization", h.GetWarehouseUtilization)
	rg.GET("/reports/products/top", h.GetTopProducts)
	rg.GET("/reports/inventory/low-stock", h.GetLowStockAlerts)
	rg.GET("/reports/inventory/value", h.GetInventoryValue)
}

func (h *ReportHandler) GetSummary(c *gin.Context) {
	from, to, err := parseDateRange(c)
	if err != nil {
		respondError(c, http.StatusBadRequest, err.Error())
		return
	}
	summary, err := h.reportSvc.GetSummaryReport(c.Request.Context(), from, to)
	if err != nil {
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondOK(c, summary)
}

func (h *ReportHandler) GetOrderStatusDistribution(c *gin.Context) {
	rows, err := h.reportSvc.GetOrderStatusDistribution(c.Request.Context())
	if err != nil {
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondOK(c, rows)
}

func (h *ReportHandler) GetRevenueTrend(c *gin.Context) {
	daysStr := c.DefaultQuery("days", "30")
	days, err := strconv.Atoi(daysStr)
	if err != nil || days <= 0 || days > 365 {
		respondError(c, http.StatusBadRequest, "days must be between 1 and 365")
		return
	}
	points, err := h.reportSvc.GetRevenueTrend(c.Request.Context(), days)
	if err != nil {
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondOK(c, gin.H{"points": points, "days": days})
}

func (h *ReportHandler) GetWarehouseUtilization(c *gin.Context) {
	rows, err := h.reportSvc.GetWarehouseUtilization(c.Request.Context())
	if err != nil {
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondOK(c, rows)
}

func (h *ReportHandler) GetTopProducts(c *gin.Context) {
	limitStr := c.DefaultQuery("limit", "10")
	limit, err := strconv.Atoi(limitStr)
	if err != nil || limit <= 0 {
		limit = 10
	}
	if limit > 50 { limit = 50 }
	sinceStr := c.DefaultQuery("since", "")
	var since time.Time
	if sinceStr != "" {
		since, err = time.Parse("2006-01-02", sinceStr)
		if err != nil {
			respondError(c, http.StatusBadRequest, "invalid since date format, use YYYY-MM-DD")
			return
		}
	} else {
		since = time.Now().AddDate(0, -1, 0)
	}
	products, err := h.reportSvc.GetTopSellingProducts(c.Request.Context(), limit, since)
	if err != nil {
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondOK(c, gin.H{"products": products, "limit": limit, "since": since})
}

func (h *ReportHandler) GetLowStockAlerts(c *gin.Context) {
	alerts, err := h.reportSvc.GetLowStockAlerts(c.Request.Context())
	if err != nil {
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondOK(c, gin.H{"alerts": alerts, "count": len(alerts)})
}

func (h *ReportHandler) GetInventoryValue(c *gin.Context) {
	warehouseID := c.Query("warehouse_id")
	var wid *string
	if warehouseID != "" {
		wid = &warehouseID
	}
	value, err := h.inventorySvc.CalculateInventoryValue(wid)
	if err != nil {
		respondError(c, http.StatusInternalServerError, err.Error())
		return
	}
	respondOK(c, gin.H{"total_value": value, "warehouse_id": warehouseID})
}

func parseDateRange(c *gin.Context) (time.Time, time.Time, error) {
	fromStr := c.DefaultQuery("from", "")
	toStr := c.DefaultQuery("to", "")
	to := time.Now()
	from := to.AddDate(0, 0, -30)
	var err error
	if fromStr != "" {
		from, err = time.Parse("2006-01-02", fromStr)
		if err != nil {
			return time.Time{}, time.Time{}, err
		}
	}
	if toStr != "" {
		to, err = time.Parse("2006-01-02", toStr)
		if err != nil {
			return time.Time{}, time.Time{}, err
		}
	}
	if to.Before(from) {
		return time.Time{}, time.Time{}, nil
	}
	return from, to, nil
}
