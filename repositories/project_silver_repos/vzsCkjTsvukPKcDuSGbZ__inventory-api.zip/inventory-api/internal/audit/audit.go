package audit

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	"github.com/google/uuid"
	"github.com/jmoiron/sqlx"
)

type AuditLog struct {
	ID         uuid.UUID       `db:"id" json:"id"`
	EntityType string          `db:"entity_type" json:"entity_type"`
	EntityID   uuid.UUID       `db:"entity_id" json:"entity_id"`
	Action     string          `db:"action" json:"action"`
	ActorID    *uuid.UUID      `db:"actor_id" json:"actor_id,omitempty"`
	ActorIP    string          `db:"actor_ip" json:"actor_ip"`
	OldData    json.RawMessage `db:"old_data" json:"old_data,omitempty"`
	NewData    json.RawMessage `db:"new_data" json:"new_data,omitempty"`
	SessionID  string          `db:"session_id" json:"session_id"`
	CreatedAt  time.Time       `db:"created_at" json:"created_at"`
}

type AuditFilter struct {
	EntityType string
	EntityID   *uuid.UUID
	ActorID    *uuid.UUID
	Action     string
	From       time.Time
	To         time.Time
	Limit      int
	Offset     int
}

type Logger interface {
	Log(ctx context.Context, entityType string, entityID uuid.UUID, action string, actorID *uuid.UUID, ip string, oldVal, newVal any) error
	Query(ctx context.Context, filter AuditFilter) ([]AuditLog, int, error)
	GetEntityHistory(ctx context.Context, entityType string, entityID uuid.UUID) ([]AuditLog, error)
	GetActorActivity(ctx context.Context, actorID uuid.UUID, limit int) ([]AuditLog, error)
}

type PostgresLogger struct {
	db *sqlx.DB
}

func New(db *sqlx.DB) *PostgresLogger {
	return &PostgresLogger{db: db}
}

func (l *PostgresLogger) Log(ctx context.Context, entityType string, entityID uuid.UUID, action string, actorID *uuid.UUID, ip string, oldVal, newVal any) error {
	var oldJSON, newJSON []byte
	var err error
	if oldVal != nil {
		if oldJSON, err = json.Marshal(oldVal); err != nil {
			return err
		}
	}
	if newVal != nil {
		if newJSON, err = json.Marshal(newVal); err != nil {
			return err
		}
	}
	q := `INSERT INTO audit_logs (entity_type, entity_id, action, actor_id, actor_ip, old_data, new_data)
		  VALUES ($1,$2,$3,$4,$5,$6,$7)`
	_, err = l.db.ExecContext(ctx, q, entityType, entityID, action, actorID, ip, oldJSON, newJSON)
	return err
}

func (l *PostgresLogger) Query(ctx context.Context, f AuditFilter) ([]AuditLog, int, error) {
	conds := " WHERE 1=1"
	args := []any{}
	n := 1
	if f.EntityType != "" {
		conds += fmt.Sprintf(" AND entity_type=$%d", n); args = append(args, f.EntityType); n++
	}
	if f.EntityID != nil {
		conds += fmt.Sprintf(" AND entity_id=$%d", n); args = append(args, *f.EntityID); n++
	}
	if f.ActorID != nil {
		conds += fmt.Sprintf(" AND actor_id=$%d", n); args = append(args, *f.ActorID); n++
	}
	if f.Action != "" {
		conds += fmt.Sprintf(" AND action=$%d", n); args = append(args, f.Action); n++
	}
	if !f.From.IsZero() {
		conds += fmt.Sprintf(" AND created_at>=$%d", n); args = append(args, f.From); n++
	}
	if !f.To.IsZero() {
		conds += fmt.Sprintf(" AND created_at<=$%d", n); args = append(args, f.To); n++
	}
	var total int
	if err := l.db.QueryRowContext(ctx, "SELECT COUNT(*) FROM audit_logs"+conds, args...).Scan(&total); err != nil {
		return nil, 0, err
	}
	lim := f.Limit; if lim <= 0 { lim = 50 }
	listQ := "SELECT * FROM audit_logs" + conds + fmt.Sprintf(" ORDER BY created_at DESC LIMIT $%d OFFSET $%d", n, n+1)
	args = append(args, lim, f.Offset)
	var rows []AuditLog
	if err := l.db.SelectContext(ctx, &rows, listQ, args...); err != nil {
		return nil, 0, err
	}
	return rows, total, nil
}

func (l *PostgresLogger) GetEntityHistory(ctx context.Context, entityType string, entityID uuid.UUID) ([]AuditLog, error) {
	var rows []AuditLog
	err := l.db.SelectContext(ctx, &rows,
		`SELECT * FROM audit_logs WHERE entity_type=$1 AND entity_id=$2 ORDER BY created_at DESC LIMIT 100`,
		entityType, entityID)
	return rows, err
}

func (l *PostgresLogger) GetActorActivity(ctx context.Context, actorID uuid.UUID, limit int) ([]AuditLog, error) {
	if limit <= 0 { limit = 50 }
	var rows []AuditLog
	err := l.db.SelectContext(ctx, &rows,
		`SELECT * FROM audit_logs WHERE actor_id=$1 ORDER BY created_at DESC LIMIT $2`,
		actorID, limit)
	return rows, err
}


func (f *AuditFilter) HasEntityFilter() bool {
	return f.EntityType != "" || f.EntityID != nil
}

func (f *AuditFilter) HasTimeRange() bool {
	return !f.From.IsZero() && !f.To.IsZero()
}

func (f *AuditFilter) IsValid() bool {
	if f.Limit < 0 || f.Offset < 0 {
		return false
	}
	return true
}

type AuditStats struct {
	TotalEvents  int            `json:"total_events"`
	ByAction     map[string]int `json:"by_action"`
	ByEntityType map[string]int `json:"by_entity_type"`
	UniqueActors int            `json:"unique_actors"`
}

func NewAuditStats() *AuditStats {
	return &AuditStats{
		ByAction:     make(map[string]int),
		ByEntityType: make(map[string]int),
	}
}

func (s *AuditStats) RecordEvent(action, entityType string) {
	s.TotalEvents++
	s.ByAction[action]++
	s.ByEntityType[entityType]++
}

type AuditSummary struct {
	EntityType  string    `json:"entity_type"`
	EntityID    string    `json:"entity_id"`
	FirstSeen   time.Time `json:"first_seen"`
	LastUpdated time.Time `json:"last_updated"`
	EventCount  int       `json:"event_count"`
}

func (s *AuditSummary) AgeInDays() int {
	return int(time.Since(s.FirstSeen).Hours() / 24)
}
