package model

import (
	"time"

	"github.com/google/uuid"
)

type Inventory struct {
	ID               uuid.UUID  `db:"id"                json:"id"`
	ProductID        uuid.UUID  `db:"product_id"        json:"product_id"`
	WarehouseID      uuid.UUID  `db:"warehouse_id"      json:"warehouse_id"`
	Quantity         int        `db:"quantity"          json:"quantity"`
	ReservedQuantity int        `db:"reserved_quantity" json:"reserved_quantity"`
	ReorderPoint     int        `db:"reorder_point"     json:"reorder_point"`
	ReorderQuantity  int        `db:"reorder_quantity"  json:"reorder_quantity"`
	LastRestockedAt  *time.Time `db:"last_restocked_at" json:"last_restocked_at,omitempty"`
}

func (i *Inventory) Available() int {
	return i.Quantity - i.ReservedQuantity
}

func (i *Inventory) NeedsReorder() bool {
	return i.Available() < i.ReorderPoint
}

func (i *Inventory) CanReserve(qty int) bool {
	return i.Available() >= qty
}

func (i *Inventory) UtilizationPct(warehouseMax int) float64 {
	if warehouseMax <= 0 {
		return 0
	}
	return float64(i.Quantity) / float64(warehouseMax) * 100
}

type CreateInventoryRequest struct {
	ProductID       uuid.UUID `json:"product_id"       binding:"required"`
	WarehouseID     uuid.UUID `json:"warehouse_id"     binding:"required"`
	Quantity        int       `json:"quantity"         binding:"gte=0"`
	ReorderPoint    int       `json:"reorder_point"`
	ReorderQuantity int       `json:"reorder_quantity"`
}

type UpdateInventoryRequest struct {
	ReorderPoint    int `json:"reorder_point"`
	ReorderQuantity int `json:"reorder_quantity"`
}

type InventoryFilter struct {
	ProductID   *uuid.UUID
	WarehouseID *uuid.UUID
	LowStock    bool
	Limit       int
	Offset      int
}

type StockReservation struct {
	InventoryID uuid.UUID
	ProductID   uuid.UUID
	WarehouseID uuid.UUID
	Quantity    int
	OrderID     uuid.UUID
}

type InventorySummary struct {
	ProductID     uuid.UUID `json:"product_id"`
	TotalStock    int       `json:"total_stock"`
	TotalReserved int       `json:"total_reserved"`
	Available     int       `json:"available"`
	Locations     int       `json:"warehouse_locations"`
}

type InventoryTransfer struct {
	FromInventoryID uuid.UUID `json:"from_inventory_id"`
	ToInventoryID   uuid.UUID `json:"to_inventory_id"`
	ProductID       uuid.UUID `json:"product_id"`
	FromWarehouseID uuid.UUID `json:"from_warehouse_id"`
	ToWarehouseID   uuid.UUID `json:"to_warehouse_id"`
	Quantity        int       `json:"quantity"`
	Notes           string    `json:"notes"`
}

type InventoryAdjustment struct {
	InventoryID uuid.UUID `json:"inventory_id"`
	ProductID   uuid.UUID `json:"product_id"`
	WarehouseID uuid.UUID `json:"warehouse_id"`
	Delta       int       `json:"delta"`
	Reason      string    `json:"reason"`
}

func (a *InventoryAdjustment) IsIncrease() bool {
	return a.Delta > 0
}

func (a *InventoryAdjustment) IsDecrease() bool {
	return a.Delta < 0
}

func (t *InventoryTransfer) IsValid() bool {
	return t.FromWarehouseID != t.ToWarehouseID && t.Quantity > 0
}

type InventorySnapshot struct {
	TakenAt       time.Time  `json:"taken_at"`
	ProductID     uuid.UUID  `json:"product_id"`
	WarehouseID   uuid.UUID  `json:"warehouse_id"`
	Quantity      int        `json:"quantity"`
	Reserved      int        `json:"reserved"`
	ReorderPoint  int        `json:"reorder_point"`
	NeedsRestock  bool       `json:"needs_restock"`
}

func NewInventorySnapshot(inv *Inventory) *InventorySnapshot {
	return &InventorySnapshot{
		TakenAt:      time.Now(),
		ProductID:    inv.ProductID,
		WarehouseID:  inv.WarehouseID,
		Quantity:     inv.Quantity,
		Reserved:     inv.ReservedQuantity,
		ReorderPoint: inv.ReorderPoint,
		NeedsRestock: inv.NeedsReorder(),
	}
}
