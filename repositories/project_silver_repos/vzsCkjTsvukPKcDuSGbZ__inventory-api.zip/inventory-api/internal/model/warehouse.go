package model

import (
	"fmt"
	"time"

	"github.com/google/uuid"
)

type Warehouse struct {
	ID           uuid.UUID `db:"id"            json:"id"`
	Name         string    `db:"name"          json:"name"`
	Location     string    `db:"location"      json:"location"`
	MaxCapacity  int       `db:"max_capacity"  json:"max_capacity"`
	CurrentUsage int       `db:"current_usage" json:"current_usage"`
	IsActive     bool      `db:"is_active"     json:"is_active"`
	CreatedAt    time.Time `db:"created_at"    json:"created_at"`
}

func (w *Warehouse) AvailableSpace() int {
	return w.MaxCapacity - w.CurrentUsage
}

func (w *Warehouse) UtilizationPct() float64 {
	if w.MaxCapacity <= 0 { return 0 }
	return float64(w.CurrentUsage) / float64(w.MaxCapacity) * 100
}

func (w *Warehouse) IsNearCapacity() bool {
	return w.UtilizationPct() > 85.0
}

func (w *Warehouse) IsFull() bool {
	return w.CurrentUsage >= w.MaxCapacity
}

func (w *Warehouse) CanAccommodate(qty int) bool {
	return w.IsActive && w.CurrentUsage+qty <= w.MaxCapacity
}

type CreateWarehouseRequest struct {
	Name        string `json:"name"         binding:"required"`
	Location    string `json:"location"`
	MaxCapacity int    `json:"max_capacity" binding:"required,gt=0"`
}

type UpdateWarehouseRequest struct {
	Name        string `json:"name"         binding:"required"`
	Location    string `json:"location"`
	MaxCapacity int    `json:"max_capacity" binding:"required,gt=0"`
}

type WarehouseFilter struct {
	IsActive *bool
	MinCap   int
	MaxCap   int
	Location string
	Limit    int
	Offset   int
}

type WarehouseCapacityStatus struct {
	WarehouseID    uuid.UUID `json:"warehouse_id"`
	Name           string    `json:"name"`
	MaxCapacity    int       `json:"max_capacity"`
	CurrentUsage   int       `json:"current_usage"`
	Available      int       `json:"available"`
	UtilizationPct float64   `json:"utilization_pct"`
	IsNearCapacity bool      `json:"is_near_capacity"`
	IsFull         bool      `json:"is_full"`
}

func NewCapacityStatus(w *Warehouse) *WarehouseCapacityStatus {
	pct := w.UtilizationPct()
	return &WarehouseCapacityStatus{
		WarehouseID:    w.ID,
		Name:           w.Name,
		MaxCapacity:    w.MaxCapacity,
		CurrentUsage:   w.CurrentUsage,
		Available:      w.AvailableSpace(),
		UtilizationPct: pct,
		IsNearCapacity: pct > 85.0,
		IsFull:         w.IsFull(),
	}
}

type WarehouseTransferRequest struct {
	ProductID       uuid.UUID `json:"product_id"        binding:"required"`
	FromWarehouseID uuid.UUID `json:"from_warehouse_id" binding:"required"`
	ToWarehouseID   uuid.UUID `json:"to_warehouse_id"   binding:"required"`
	Quantity        int       `json:"quantity"          binding:"required,gt=0"`
	Notes           string    `json:"notes"`
}

func (w *Warehouse) StatusLabel() string {
	if w.IsActive { return "active" }
	return "inactive"
}

func (w *Warehouse) CapacitySummary() string {
	return fmt.Sprintf("%d/%d units (%.0f%%)", w.CurrentUsage, w.MaxCapacity, w.UtilizationPct())
}

type WarehouseSearchFilter struct {
	Name        string
	Location    string
	IsActive    *bool
	MinCapacity int
	MaxCapacity int
	SortBy      string
	SortDir     string
}

func (f *WarehouseSearchFilter) HasLocationFilter() bool {
	return f.Location != ""
}

func (f *WarehouseSearchFilter) HasCapacityFilter() bool {
	return f.MinCapacity > 0 || f.MaxCapacity > 0
}

type WarehouseEvent struct {
	WarehouseID string    `json:"warehouse_id"`
	EventType   string    `json:"event_type"`
	OldValue    string    `json:"old_value,omitempty"`
	NewValue    string    `json:"new_value,omitempty"`
	ActorID     string    `json:"actor_id"`
	OccurredAt  time.Time `json:"occurred_at"`
}

func (e *WarehouseEvent) IsCapacityChange() bool {
	return e.EventType == "capacity_update"
}

func (e *WarehouseEvent) IsStatusChange() bool {
	return e.EventType == "activate" || e.EventType == "deactivate"
}

type WarehousePatch struct {
	Name        *string `json:"name,omitempty"`
	Location    *string `json:"location,omitempty"`
	MaxCapacity *int    `json:"max_capacity,omitempty"`
	IsActive    *bool   `json:"is_active,omitempty"`
}

func (p *WarehousePatch) HasAnyField() bool {
	return p.Name != nil || p.Location != nil || p.MaxCapacity != nil || p.IsActive != nil
}
