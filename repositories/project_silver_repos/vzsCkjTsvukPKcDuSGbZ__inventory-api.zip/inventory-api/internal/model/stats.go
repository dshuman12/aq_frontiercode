package model

import (
	"time"

	"github.com/google/uuid"
)

type LowStockAlert struct {
	InventoryID   uuid.UUID `json:"inventory_id"`
	ProductID     uuid.UUID `json:"product_id"`
	ProductSKU    string    `json:"product_sku"`
	ProductName   string    `json:"product_name"`
	WarehouseID   uuid.UUID `json:"warehouse_id"`
	WarehouseName string    `json:"warehouse_name"`
	Quantity      int       `json:"quantity"`
	Reserved      int       `json:"reserved"`
	Available     int       `json:"available"`
	ReorderPoint  int       `json:"reorder_point"`
	ShortBy       int       `json:"short_by"`
}

type StockMovement struct {
	Timestamp     time.Time  `json:"timestamp"`
	Action        string     `json:"action"`
	QuantityDelta int        `json:"quantity_delta"`
	ActorID       *uuid.UUID `json:"actor_id,omitempty"`
	Notes         string     `json:"notes"`
}

type InventoryWithProduct struct {
	Inventory
	ProductName string  `db:"product_name" json:"product_name"`
	SKU         string  `db:"sku" json:"sku"`
	UnitPrice   float64 `db:"unit_price" json:"unit_price"`
}

type WarehouseInventoryValue struct {
	WarehouseID   uuid.UUID `db:"id" json:"warehouse_id"`
	WarehouseName string    `db:"name" json:"warehouse_name"`
	TotalValue    float64   `db:"total_value" json:"total_value"`
}

type LowStockItem struct {
	ProductID     uuid.UUID `db:"product_id" json:"product_id"`
	SKU           string    `db:"sku" json:"sku"`
	ProductName   string    `db:"name" json:"product_name"`
	WarehouseID   uuid.UUID `db:"warehouse_id" json:"warehouse_id"`
	WarehouseName string    `db:"warehouse_name" json:"warehouse_name"`
	Quantity      int       `db:"quantity" json:"quantity"`
	Reserved      int       `db:"reserved_quantity" json:"reserved"`
	Available     int       `json:"available"`
	ReorderPoint  int       `db:"reorder_point" json:"reorder_point"`
}

type RestockRequest struct {
	ProductID   uuid.UUID `json:"product_id"`
	WarehouseID uuid.UUID `json:"warehouse_id"`
	Quantity    int       `json:"quantity"`
	Notes       string    `json:"notes"`
}

type TransferRequest struct {
	ProductID       uuid.UUID `json:"product_id"`
	FromWarehouseID uuid.UUID `json:"from_warehouse_id"`
	ToWarehouseID   uuid.UUID `json:"to_warehouse_id"`
	Quantity        int       `json:"quantity"`
}

type DateRangeFilter struct {
	From  time.Time `form:"from"`
	To    time.Time `form:"to"`
	Limit int       `form:"limit"`
	Offset int      `form:"offset"`
}

type InventoryValueReport struct {
	GeneratedAt     time.Time                `json:"generated_at"`
	TotalValue      float64                  `json:"total_value"`
	ByWarehouse     []WarehouseInventoryValue `json:"by_warehouse"`
	WarehouseCount  int                      `json:"warehouse_count"`
}

type StockMovementSummary struct {
	ProductID    uuid.UUID `json:"product_id"`
	ProductName  string    `json:"product_name"`
	TotalIn      int       `json:"total_in"`
	TotalOut     int       `json:"total_out"`
	NetMovement  int       `json:"net_movement"`
	PeriodStart  time.Time `json:"period_start"`
	PeriodEnd    time.Time `json:"period_end"`
}

type DashboardStats struct {
	Products    int     `json:"total_products"`
	Warehouses  int     `json:"active_warehouses"`
	Orders      int     `json:"total_orders"`
	LowStock    int     `json:"low_stock_items"`
	Revenue     float64 `json:"total_revenue"`
	PendingOrders int   `json:"pending_orders"`
}

type PaginatedProducts struct {
	Items  []Product `json:"items"`
	Total  int       `json:"total"`
	Limit  int       `json:"limit"`
	Offset int       `json:"offset"`
	Pages  int       `json:"pages"`
}

func NewPaginatedProducts(items []Product, total, limit, offset int) *PaginatedProducts {
	pages := total / limit
	if total%limit != 0 { pages++ }
	return &PaginatedProducts{Items: items, Total: total, Limit: limit, Offset: offset, Pages: pages}
}

type PaginatedOrders struct {
	Items  []Order `json:"items"`
	Total  int     `json:"total"`
	Limit  int     `json:"limit"`
	Offset int     `json:"offset"`
	Pages  int     `json:"pages"`
}

func NewPaginatedOrders(items []Order, total, limit, offset int) *PaginatedOrders {
	pages := total / limit
	if total%limit != 0 { pages++ }
	return &PaginatedOrders{Items: items, Total: total, Limit: limit, Offset: offset, Pages: pages}
}

type ReorderAlert struct {
	ProductID     uuid.UUID `json:"product_id"`
	ProductName   string    `json:"product_name"`
	WarehouseID   uuid.UUID `json:"warehouse_id"`
	WarehouseName string    `json:"warehouse_name"`
	CurrentStock  int       `json:"current_stock"`
	ReorderPoint  int       `json:"reorder_point"`
	SuggestedQty  int       `json:"suggested_qty"`
	Urgency       string    `json:"urgency"`
}

func ClassifyReorderUrgency(available, reorderPoint int) string {
	if available <= 0 {
		return "critical"
	}
	if float64(available)/float64(reorderPoint) < 0.5 {
		return "high"
	}
	return "medium"
}
func (a *ReorderAlert) NeedsImmediateAction() bool { return a.Urgency == "critical" || a.Urgency == "high" }
func (a *ReorderAlert) Description() string { return "Reorder " + a.ProductName + " in " + a.WarehouseName + ": " + a.Urgency + " urgency" }
func (a *ReorderAlert) String() string { return a.Description() }

type CapacityWarning struct {
	WarehouseID   string  `json:"warehouse_id"`
	WarehouseName string  `json:"warehouse_name"`
	CurrentPct    float64 `json:"current_pct"`
	Threshold     float64 `json:"threshold"`
}

func (w *CapacityWarning) IsOverThreshold() bool {
	return w.CurrentPct >= w.Threshold
}

type DailyRevenue struct {
	Date    string  `json:"date"`
	Revenue float64 `json:"revenue"`
	Orders  int     `json:"orders"`
}

func (d *DailyRevenue) AvgOrderValue() float64 {
	if d.Orders == 0 { return 0 }
	return d.Revenue / float64(d.Orders)
}

type SystemHealth struct {
	DBConnected     bool `json:"db_connected"`
	CacheReady      bool `json:"cache_ready"`
	PendingAlerts   int  `json:"pending_alerts"`
	LowStockCount   int  `json:"low_stock_count"`
}

func (h *SystemHealth) IsHealthy() bool {
	return h.DBConnected && h.CacheReady
}

type FulfillmentRate struct {
	TotalOrders     int     `json:"total_orders"`
	FulfilledOrders int     `json:"fulfilled_orders"`
	RatePct         float64 `json:"rate_pct"`
}

func (f *FulfillmentRate) Calculate() {
	if f.TotalOrders == 0 { f.RatePct = 0; return }
	f.RatePct = float64(f.FulfilledOrders) / float64(f.TotalOrders) * 100
}

func (f *FulfillmentRate) IsHighPerforming() bool {
	return f.RatePct >= 95.0
}

func (f *FulfillmentRate) NeedsAttention() bool {
	return f.RatePct < 80.0
}

func (f *FulfillmentRate) Label() string {
	switch {
	case f.RatePct >= 95:
		return "excellent"
	case f.RatePct >= 80:
		return "good"
	case f.RatePct >= 60:
		return "fair"
	default:
		return "poor"
	}
}
