package model

import (
	"time"

	"github.com/google/uuid"
)

type OrderStatus string

const (
	StatusPending             OrderStatus = "pending"
	StatusConfirmed           OrderStatus = "confirmed"
	StatusFulfilled           OrderStatus = "fulfilled"
	StatusPartiallyFulfilled  OrderStatus = "partially_fulfilled"
	StatusCancelled           OrderStatus = "cancelled"
)

type Order struct {
	ID          uuid.UUID   `db:"id"           json:"id"`
	CustomerID  string      `db:"customer_id"  json:"customer_id"`
	Status      OrderStatus `db:"status"       json:"status"`
	TotalAmount float64     `db:"total_amount" json:"total_amount"`
	Notes       string      `db:"notes"        json:"notes"`
	CreatedAt   time.Time   `db:"created_at"   json:"created_at"`
	UpdatedAt   time.Time   `db:"updated_at"   json:"updated_at"`
}

func (o *Order) IsCancellable() bool {
	return o.Status == StatusPending || o.Status == StatusConfirmed
}

func (o *Order) IsComplete() bool {
	return o.Status == StatusFulfilled || o.Status == StatusPartiallyFulfilled
}

func (o *Order) CanConfirm() bool {
	return o.Status == StatusPending
}

func (o *Order) CanFulfill() bool {
	return o.Status == StatusConfirmed
}

type OrderItem struct {
	ID           uuid.UUID `db:"id"            json:"id"`
	OrderID      uuid.UUID `db:"order_id"      json:"order_id"`
	ProductID    uuid.UUID `db:"product_id"    json:"product_id"`
	WarehouseID  uuid.UUID `db:"warehouse_id"  json:"warehouse_id"`
	RequestedQty int       `db:"requested_qty" json:"requested_qty"`
	FulfilledQty int       `db:"fulfilled_qty" json:"fulfilled_qty"`
	UnitPrice    float64   `db:"unit_price"    json:"unit_price"`
}

func (i *OrderItem) LineTotal() float64 {
	return float64(i.FulfilledQty) * i.UnitPrice
}

func (i *OrderItem) RequestedTotal() float64 {
	return float64(i.RequestedQty) * i.UnitPrice
}

func (i *OrderItem) IsFullyFulfilled() bool {
	return i.FulfilledQty >= i.RequestedQty
}

func (i *OrderItem) FulfillmentPct() float64 {
	if i.RequestedQty == 0 { return 0 }
	return float64(i.FulfilledQty) / float64(i.RequestedQty) * 100
}

type OrderWithItems struct {
	Order
	Items []OrderItem `json:"items"`
}

func (o *OrderWithItems) TotalRequestedValue() float64 {
	total := 0.0
	for _, item := range o.Items {
		total += item.RequestedTotal()
	}
	return total
}

func (o *OrderWithItems) TotalFulfilledValue() float64 {
	total := 0.0
	for _, item := range o.Items {
		total += item.LineTotal()
	}
	return total
}

func (o *OrderWithItems) IsFullyFulfilled() bool {
	for _, item := range o.Items {
		if !item.IsFullyFulfilled() { return false }
	}
	return len(o.Items) > 0
}

type OrderFilter struct {
	CustomerID string
	Status     string
	Statuses   []string
	From       time.Time
	To         time.Time
	MinAmount  float64
	MaxAmount  float64
	Limit      int
	Offset     int
	SortBy     string
	SortDir    string
}

type OrderItemRequest struct {
	ProductID   string `json:"product_id"`
	WarehouseID string `json:"warehouse_id"`
	Quantity    int    `json:"quantity"`
}

type CreateOrderRequest struct {
	CustomerID string             `json:"customer_id"`
	Notes      string             `json:"notes"`
	Items      []OrderItemRequest `json:"items"`
}

type UpdateOrderRequest struct {
	Notes string `json:"notes"`
}

type BulkOrderStatusUpdate struct {
	OrderIDs []uuid.UUID `json:"order_ids"`
	Status   string      `json:"status"`
}

type OrderSummary struct {
	TotalOrders   int            `json:"total_orders"`
	ByStatus      map[string]int `json:"by_status"`
	TotalRevenue  float64        `json:"total_revenue"`
	AvgOrderValue float64        `json:"avg_order_value"`
	PeriodStart   time.Time      `json:"period_start"`
	PeriodEnd     time.Time      `json:"period_end"`
}

var ValidTransitions = map[OrderStatus][]OrderStatus{
	StatusPending:   {StatusConfirmed, StatusCancelled},
	StatusConfirmed: {StatusFulfilled, StatusPartiallyFulfilled, StatusCancelled},
}

func IsValidTransition(from, to OrderStatus) bool {
	allowed, ok := ValidTransitions[from]
	if !ok { return false }
	for _, a := range allowed {
		if a == to { return true }
	}
	return false
}

func AllStatuses() []OrderStatus {
	return []OrderStatus{
		StatusPending, StatusConfirmed,
		StatusFulfilled, StatusPartiallyFulfilled, StatusCancelled,
	}
}

func IsValidOrderStatus(s string) bool {
	for _, st := range AllStatuses() {
		if string(st) == s { return true }
	}
	return false
}

func (o *Order) StatusLabel() string {
	switch o.Status {
	case StatusPending: return "Pending"
	case StatusConfirmed: return "Confirmed"
	case StatusFulfilled: return "Fulfilled"
	case StatusCancelled: return "Cancelled"
	default: return string(o.Status)
	}
}

func (o *Order) AgeInDays() int {
	return int(time.Since(o.CreatedAt).Hours() / 24)
}
