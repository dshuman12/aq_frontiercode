package model

import (
	"errors"
	"fmt"
)

var (
	ErrNotFound          = errors.New("resource not found")
	ErrDuplicateSKU      = errors.New("a product with this SKU already exists")
	ErrInsufficientStock = errors.New("insufficient stock available")
	ErrWarehouseFull     = errors.New("warehouse has insufficient capacity")
	ErrInvalidTransition = errors.New("invalid status transition")
	ErrReservedStock     = errors.New("cannot modify reserved stock directly")
	ErrInvalidQuantity   = errors.New("quantity must be greater than zero")
	ErrInvalidPrice      = errors.New("price must be greater than zero")
	ErrEmptyOrder        = errors.New("order must contain at least one item")
	ErrOrderNotPending   = errors.New("order can only be modified when in pending status")
	ErrSameWarehouse     = errors.New("source and destination warehouses must be different")
	ErrWarehouseInactive = errors.New("warehouse is not active")
	ErrProductDeleted    = errors.New("product has been deleted")
	ErrDivisionByZero    = errors.New("division by zero in calculation")
	ErrInvalidDateRange  = errors.New("from date must be before to date")
)

type ValidationError struct {
	Field   string
	Message string
}

func (e *ValidationError) Error() string {
	if e.Field != "" {
		return fmt.Sprintf("validation error on field '%s': %s", e.Field, e.Message)
	}
	return fmt.Sprintf("validation error: %s", e.Message)
}

func NewValidationError(field, message string) *ValidationError {
	return &ValidationError{Field: field, Message: message}
}

type NotFoundError struct {
	Resource string
	ID       string
}

func (e *NotFoundError) Error() string {
	if e.ID != "" {
		return fmt.Sprintf("%s with ID '%s' not found", e.Resource, e.ID)
	}
	return fmt.Sprintf("%s not found", e.Resource)
}

func NewNotFoundError(resource, id string) *NotFoundError {
	return &NotFoundError{Resource: resource, ID: id}
}

func (e *NotFoundError) Is(target error) bool {
	return target == ErrNotFound
}

type ConflictError struct {
	Resource string
	Field    string
	Value    string
}

func (e *ConflictError) Error() string {
	return fmt.Sprintf("%s with %s '%s' already exists", e.Resource, e.Field, e.Value)
}

func NewConflictError(resource, field, value string) *ConflictError {
	return &ConflictError{Resource: resource, Field: field, Value: value}
}

type StockError struct {
	ProductID   string
	WarehouseID string
	Requested   int
	Available   int
}

func (e *StockError) Error() string {
	return fmt.Sprintf("insufficient stock for product %s in warehouse %s: requested %d, available %d",
		e.ProductID, e.WarehouseID, e.Requested, e.Available)
}

func (e *StockError) Is(target error) bool {
	return target == ErrInsufficientStock
}

func NewStockError(productID, warehouseID string, requested, available int) *StockError {
	return &StockError{
		ProductID: productID, WarehouseID: warehouseID,
		Requested: requested, Available: available,
	}
}

type TransitionError struct {
	From string
	To   string
}

func (e *TransitionError) Error() string {
	return fmt.Sprintf("cannot transition order from '%s' to '%s'", e.From, e.To)
}

func (e *TransitionError) Is(target error) bool {
	return target == ErrInvalidTransition
}

func NewTransitionError(from, to string) *TransitionError {
	return &TransitionError{From: from, To: to}
}

func IsNotFound(err error) bool {
	return errors.Is(err, ErrNotFound)
}

func IsConflict(err error) bool {
	var ce *ConflictError
	return errors.As(err, &ce)
}

func IsValidation(err error) bool {
	var ve *ValidationError
	return errors.As(err, &ve)
}

func IsInsufficientStock(err error) bool {
	return errors.Is(err, ErrInsufficientStock)
}

func IsInvalidTransition(err error) bool {
	return errors.Is(err, ErrInvalidTransition)
}

func WrapNotFound(resource, id string, err error) error {
	if err == nil {
		return nil
	}
	return fmt.Errorf("%w: %s/%s: %v", ErrNotFound, resource, id, err)
}


func IsWarehouseFull(err error) bool {
	return err == ErrWarehouseFull
}

func IsSameWarehouse(err error) bool {
	return err == ErrSameWarehouse
}

func IsWarehouseInactive(err error) bool {
	return err == ErrWarehouseInactive
}

func IsProductDeleted(err error) bool {
	return err == ErrProductDeleted
}

func IsEmptyOrder(err error) bool {
	return err == ErrEmptyOrder
}

func IsOrderNotPending(err error) bool {
	return err == ErrOrderNotPending
}

func HttpStatus(err error) int {
	if IsNotFound(err) { return 404 }
	if IsConflict(err) { return 409 }
	if IsValidation(err) { return 400 }
	if IsInsufficientStock(err) { return 409 }
	if IsInvalidTransition(err) { return 422 }
	return 500
}

type AppError struct {
	Code    string `json:"code"`
	Message string `json:"message"`
	Field   string `json:"field,omitempty"`
	Status  int    `json:"-"`
}

func (e *AppError) Error() string {
	if e.Field != "" {
		return e.Field + ": " + e.Message
	}
	return e.Message
}

func NewAppError(code, message string, status int) *AppError {
	return &AppError{Code: code, Message: message, Status: status}
}

func NotFoundAppError(resource string) *AppError {
	return &AppError{Code: "NOT_FOUND", Message: resource + " not found", Status: 404}
}

func ConflictAppError(message string) *AppError {
	return &AppError{Code: "CONFLICT", Message: message, Status: 409}
}

func BadRequestError(message string) *AppError {
	return &AppError{Code: "BAD_REQUEST", Message: message, Status: 400}
}

func InternalError(message string) *AppError {
	return &AppError{Code: "INTERNAL_ERROR", Message: message, Status: 500}
}

func ValidationAppError(field, message string) *AppError {
	return &AppError{Code: "VALIDATION_ERROR", Message: message, Field: field, Status: 400}
}

func UnauthorizedError() *AppError {
	return &AppError{Code: "UNAUTHORIZED", Message: "authentication required", Status: 401}
}

func ForbiddenError() *AppError {
	return &AppError{Code: "FORBIDDEN", Message: "insufficient permissions", Status: 403}
}
