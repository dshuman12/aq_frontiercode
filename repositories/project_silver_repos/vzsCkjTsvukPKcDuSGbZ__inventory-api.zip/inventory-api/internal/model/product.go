package model

import (
	"time"

	"github.com/google/uuid"
)

type Product struct {
	ID          uuid.UUID  `db:"id"          json:"id"`
	SKU         string     `db:"sku"         json:"sku"`
	Name        string     `db:"name"        json:"name"`
	Description string     `db:"description" json:"description"`
	Category    string     `db:"category"    json:"category"`
	UnitPrice   float64    `db:"unit_price"  json:"unit_price"`
	WeightKg    float64    `db:"weight_kg"   json:"weight_kg"`
	CreatedAt   time.Time  `db:"created_at"  json:"created_at"`
	UpdatedAt   time.Time  `db:"updated_at"  json:"updated_at"`
	DeletedAt   *time.Time `db:"deleted_at"  json:"deleted_at,omitempty"`
}

func (p *Product) IsDeleted() bool {
	return p.DeletedAt != nil
}

func (p *Product) DisplayName() string {
	if p.Category != "" {
		return p.Category + " / " + p.Name
	}
	return p.Name
}

func (p *Product) PriceWithTax(taxRate float64) float64 {
	return p.UnitPrice * (1 + taxRate/100)
}

type CreateProductRequest struct {
	SKU         string  `json:"sku"         binding:"required"`
	Name        string  `json:"name"        binding:"required"`
	Description string  `json:"description"`
	Category    string  `json:"category"`
	UnitPrice   float64 `json:"unit_price"  binding:"required,gt=0"`
	WeightKg    float64 `json:"weight_kg"   binding:"gte=0"`
}

type UpdateProductRequest struct {
	Name        string  `json:"name"        binding:"required"`
	Description string  `json:"description"`
	Category    string  `json:"category"`
	UnitPrice   float64 `json:"unit_price"  binding:"required,gt=0"`
	WeightKg    float64 `json:"weight_kg"   binding:"gte=0"`
}

type ProductFilter struct {
	Category  string
	MinPrice  float64
	MaxPrice  float64
	Search    string
	InStock   bool
	Limit     int
	Offset    int
	SortBy    string
	SortDir   string
}

type ProductWithInventory struct {
	Product
	TotalStock    int `json:"total_stock"`
	TotalReserved int `json:"total_reserved"`
	Available     int `json:"available"`
}

func (p *ProductWithInventory) IsInStock() bool {
	return p.Available > 0
}

type ProductStats struct {
	ProductID      uuid.UUID `json:"product_id"`
	TotalStock     int       `json:"total_stock"`
	TotalReserved  int       `json:"total_reserved"`
	Available      int       `json:"available"`
	WarehouseCount int       `json:"warehouse_count"`
}

type BulkCreateProductRequest struct {
	Products []CreateProductRequest `json:"products"`
}

type PricingUpdateRequest struct {
	ProductID string  `json:"product_id"`
	NewPrice  float64 `json:"new_price"`
}

type ProductSortOptions struct {
	Field     string
	Direction string
	Allowed   []string
}

func DefaultProductSort() ProductSortOptions {
	return ProductSortOptions{
		Field:     "name",
		Direction: "asc",
		Allowed:   []string{"name", "sku", "unit_price", "created_at"},
	}
}

type ProductEvent struct {
	ProductID  string    `json:"product_id"`
	EventType  string    `json:"event_type"`
	OldPrice   float64   `json:"old_price,omitempty"`
	NewPrice   float64   `json:"new_price,omitempty"`
	ActorID    string    `json:"actor_id"`
	OccurredAt time.Time `json:"occurred_at"`
}

func (e *ProductEvent) IsPriceChange() bool {
	return e.EventType == "price_update"
}

type ProductImportRow struct {
	SKU         string  `csv:"sku"`
	Name        string  `csv:"name"`
	Category    string  `csv:"category"`
	UnitPrice   float64 `csv:"unit_price"`
	WeightKg    float64 `csv:"weight_kg"`
	Description string  `csv:"description"`
	RowNumber   int     `csv:"-"`
	Error       string  `csv:"-"`
}

func (r *ProductImportRow) HasError() bool {
	return r.Error != ""
}

func (r *ProductImportRow) ToCreateRequest() *CreateProductRequest {
	return &CreateProductRequest{
		SKU:         r.SKU,
		Name:        r.Name,
		Category:    r.Category,
		UnitPrice:   r.UnitPrice,
		WeightKg:    r.WeightKg,
		Description: r.Description,
	}
}
