package cache

import (
	"sync"
	"time"
)

type entry struct {
	value     any
	expiresAt time.Time
}

type Cache struct {
	mu         sync.RWMutex
	items      map[string]entry
	defaultTTL time.Duration
}

func New(defaultTTL time.Duration) *Cache {
	c := &Cache{items: make(map[string]entry), defaultTTL: defaultTTL}
	go c.cleanup()
	return c
}

func (c *Cache) Get(key string) (any, bool) {
	c.mu.RLock()
	defer c.mu.RUnlock()
	e, ok := c.items[key]
	if !ok || time.Now().After(e.expiresAt) {
		return nil, false
	}
	return e.value, true
}

func (c *Cache) Set(key string, value any) {
	c.SetWithTTL(key, value, c.defaultTTL)
}

func (c *Cache) SetWithTTL(key string, value any, ttl time.Duration) {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.items[key] = entry{value: value, expiresAt: time.Now().Add(ttl)}
}

func (c *Cache) Delete(key string) {
	c.mu.Lock()
	defer c.mu.Unlock()
	delete(c.items, key)
}

func (c *Cache) Flush() {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.items = make(map[string]entry)
}

func (c *Cache) Size() int {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return len(c.items)
}

func (c *Cache) Keys() []string {
	c.mu.RLock()
	defer c.mu.RUnlock()
	now := time.Now()
	keys := make([]string, 0, len(c.items))
	for k, e := range c.items {
		if !now.After(e.expiresAt) {
			keys = append(keys, k)
		}
	}
	return keys
}

func (c *Cache) Has(key string) bool {
	_, ok := c.Get(key)
	return ok
}

func (c *Cache) GetOrSet(key string, fn func() any) any {
	if v, ok := c.Get(key); ok {
		return v
	}
	v := fn()
	c.Set(key, v)
	return v
}

func (c *Cache) cleanup() {
	ticker := time.NewTicker(2 * time.Minute)
	defer ticker.Stop()
	for range ticker.C {
		c.mu.Lock()
		now := time.Now()
		for k, e := range c.items {
			if now.After(e.expiresAt) {
				delete(c.items, k)
			}
		}
		c.mu.Unlock()
	}
}


func (c *Cache) Invalidate(prefix string) {
	c.mu.Lock()
	defer c.mu.Unlock()
	for k := range c.data {
		if len(k) >= len(prefix) && k[:len(prefix)] == prefix {
			delete(c.data, k)
		}
	}
}



func (c *Cache) Stats() map[string]int {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return map[string]int{"size": len(c.data)}
}

type CacheKey struct {
	Prefix  string
	Parts   []string
}

func (ck CacheKey) String() string {
	result := ck.Prefix
	for _, p := range ck.Parts {
		result += ":" + p
	}
	return result
}

func ProductKey(id string) string    { return "product:" + id }
func WarehouseKey(id string) string  { return "warehouse:" + id }
func InventoryKey(productID, warehouseID string) string {
	return "inventory:" + productID + ":" + warehouseID
}
func OrderKey(id string) string      { return "order:" + id }
