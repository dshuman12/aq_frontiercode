package export

import (
	"bytes"
	"encoding/csv"
	"encoding/json"
	"fmt"
	"regexp"
	"strings"
	"time"
)

func FormatDate(t time.Time) string {
	return t.Format("2006-01-02")
}

func FormatDateTime(t time.Time) string {
	return t.Format("2006-01-02 15:04:05")
}

func FormatCurrency(amount float64) string {
	return fmt.Sprintf("%.2f", amount)
}

func FormatQuantity(qty int) string {
	return fmt.Sprintf("%d units", qty)
}

func FormatPercentage(pct float64) string {
	return fmt.Sprintf("%.1f%%", pct)
}

func ToCSV(headers []string, rows [][]string) ([]byte, error) {
	var buf bytes.Buffer
	w := csv.NewWriter(&buf)
	if err := w.Write(headers); err != nil {
		return nil, err
	}
	for _, row := range rows {
		if err := w.Write(row); err != nil {
			return nil, err
		}
	}
	w.Flush()
	if err := w.Error(); err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}

func ToJSON(data any) ([]byte, error) {
	return json.MarshalIndent(data, "", "  ")
}

func ParseCSVRow(line string) ([]string, error) {
	r := csv.NewReader(strings.NewReader(line))
	return r.Read()
}

var nonAlphanumeric = regexp.MustCompile(`[^a-z0-9_\-]`)

func SanitizeFilename(name string) string {
	lower := strings.ToLower(name)
	safe := strings.ReplaceAll(lower, " ", "_")
	safe = nonAlphanumeric.ReplaceAllString(safe, "")
	if len(safe) > 100 {
		safe = safe[:100]
	}
	return safe
}

func BuildExportFilename(prefix string, t time.Time) string {
	return prefix + "_" + t.Format("20060102_150405") + ".csv"
}

func CSVFromMaps(headers []string, records []map[string]string) ([]byte, error) {
	rows := make([][]string, len(records))
	for i, rec := range records {
		row := make([]string, len(headers))
		for j, h := range headers {
			row[j] = rec[h]
		}
		rows[i] = row
	}
	return ToCSV(headers, rows)
}

type JSONExporter struct {
	PrettyPrint bool
	OmitEmpty   bool
}

func NewJSONExporter(pretty bool) *JSONExporter {
	return &JSONExporter{PrettyPrint: pretty}
}

func (e *JSONExporter) Export(v interface{}) ([]byte, error) {
	if e.PrettyPrint {
		return json.MarshalIndent(v, "", "  ")
	}
	return json.Marshal(v)
}

func (e *JSONExporter) ContentType() string {
	return "application/json"
}

func (e *JSONExporter) FileExtension() string {
	return ".json"
}

type ExportFilter struct {
	IncludeFields []string
	ExcludeFields []string
	MaxRows       int
}

func (f *ExportFilter) ShouldInclude(field string) bool {
	if len(f.ExcludeFields) > 0 {
		for _, ef := range f.ExcludeFields {
			if ef == field {
				return false
			}
		}
	}
	if len(f.IncludeFields) > 0 {
		for _, inf := range f.IncludeFields {
			if inf == field {
				return true
			}
		}
		return false
	}
	return true
}

type ExportResult struct {
	Format      string `json:"format"`
	RowCount    int    `json:"row_count"`
	FileSizeB   int    `json:"file_size_bytes"`
	GeneratedAt string `json:"generated_at"`
	Data        []byte `json:"-"`
}

func (r *ExportResult) IsEmpty() bool {
	return r.RowCount == 0
}

func (r *ExportResult) FileSizeKB() float64 {
	return float64(r.FileSizeB) / 1024
}

type ColumnDef struct {
	Header string
	Field  string
	Width  int
	Format func(interface{}) string
}

func DefaultIntFormat(v interface{}) string {
	if n, ok := v.(int); ok {
		return fmt.Sprintf("%d", n)
	}
	return ""
}

func DefaultFloatFormat(v interface{}) string {
	if f, ok := v.(float64); ok {
		return fmt.Sprintf("%.2f", f)
	}
	return ""
}
