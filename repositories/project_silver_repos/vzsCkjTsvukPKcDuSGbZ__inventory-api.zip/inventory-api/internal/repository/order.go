package repository

import (
	"database/sql"
	"fmt"
	"time"

	"github.com/google/uuid"
	"github.com/jmoiron/sqlx"
	"inventoryapi.dev/api/internal/model"
)

type OrderRepo struct {
	db *sqlx.DB
}

func NewOrderRepo(db *sqlx.DB) *OrderRepo {
	return &OrderRepo{db: db}
}

func (r *OrderRepo) GetByID(id uuid.UUID) (*model.Order, error) {
	var o model.Order
	err := r.db.Get(&o, `SELECT * FROM orders WHERE id=$1`, id)
	if err == sql.ErrNoRows {
		return nil, model.ErrNotFound
	}
	return &o, err
}

func (r *OrderRepo) GetItems(orderID uuid.UUID) ([]model.OrderItem, error) {
	var items []model.OrderItem
	err := r.db.Select(&items, `SELECT * FROM order_items WHERE order_id=$1`, orderID)
	return items, err
}

func (r *OrderRepo) List(status string, limit, offset int) ([]model.Order, int, error) {
	if limit <= 0 { limit = 20 }
	if limit > 100 { limit = 100 }
	args := []any{}
	where := " WHERE 1=1"
	n := 1
	if status != "" {
		where += fmt.Sprintf(" AND status=$%d", n)
		args = append(args, status)
		n++
	}
	var total int
	if err := r.db.QueryRow("SELECT COUNT(*) FROM orders"+where, args...).Scan(&total); err != nil {
		return nil, 0, err
	}
	listQ := "SELECT * FROM orders" + where + fmt.Sprintf(" ORDER BY created_at DESC LIMIT $%d OFFSET $%d", n, n+1)
	args = append(args, limit, offset)
	var rows []model.Order
	if err := r.db.Select(&rows, listQ, args...); err != nil {
		return nil, 0, err
	}
	return rows, total, nil
}

func (r *OrderRepo) Create(o *model.Order) error {
	if o.ID == (uuid.UUID{}) {
		o.ID = uuid.New()
	}
	_, err := r.db.NamedExec(`
		INSERT INTO orders (id, customer_id, status, total_amount, notes)
		VALUES (:id, :customer_id, :status, :total_amount, :notes)`, o)
	return err
}

func (r *OrderRepo) AddItem(item *model.OrderItem) error {
	if item.ID == (uuid.UUID{}) {
		item.ID = uuid.New()
	}
	_, err := r.db.NamedExec(`
		INSERT INTO order_items (id, order_id, product_id, warehouse_id, requested_qty, fulfilled_qty, unit_price)
		VALUES (:id, :order_id, :product_id, :warehouse_id, :requested_qty, :fulfilled_qty, :unit_price)`, item)
	return err
}

func (r *OrderRepo) UpdateStatus(id uuid.UUID, status model.OrderStatus) error {
	_, err := r.db.Exec(
		`UPDATE orders SET status=$1, updated_at=NOW() WHERE id=$2`, status, id)
	return err
}

func (r *OrderRepo) UpdateTotalAmount(id uuid.UUID, amount float64) error {
	_, err := r.db.Exec(
		`UPDATE orders SET total_amount=$1, updated_at=NOW() WHERE id=$2`, amount, id)
	return err
}

func (r *OrderRepo) UpdateItemFulfilledQty(itemID uuid.UUID, qty int) error {
	_, err := r.db.Exec(
		`UPDATE order_items SET fulfilled_qty=$1 WHERE id=$2`, qty, itemID)
	return err
}

func (r *OrderRepo) GetByCustomer(customerID string, limit, offset int) ([]model.Order, int, error) {
	if limit <= 0 { limit = 20 }
	var total int
	if err := r.db.QueryRow(`SELECT COUNT(*) FROM orders WHERE customer_id=$1`, customerID).Scan(&total); err != nil {
		return nil, 0, err
	}
	var rows []model.Order
	err := r.db.Select(&rows,
		`SELECT * FROM orders WHERE customer_id=$1 ORDER BY created_at DESC LIMIT $2 OFFSET $3`,
		customerID, limit, offset)
	return rows, total, err
}

func (r *OrderRepo) GetByStatus(status string) ([]model.Order, error) {
	var rows []model.Order
	err := r.db.Select(&rows,
		`SELECT * FROM orders WHERE status=$1 ORDER BY created_at DESC`, status)
	return rows, err
}

func (r *OrderRepo) GetByDateRange(from, to time.Time) ([]model.Order, error) {
	var rows []model.Order
	err := r.db.Select(&rows,
		`SELECT * FROM orders WHERE created_at BETWEEN $1 AND $2 ORDER BY created_at DESC`,
		from, to)
	return rows, err
}

func (r *OrderRepo) BulkUpdateStatus(ids []uuid.UUID, status string) (int64, error) {
	if len(ids) == 0 {
		return 0, nil
	}
	placeholders := ""
	args := []any{status}
	for i, id := range ids {
		if i > 0 { placeholders += "," }
		placeholders += fmt.Sprintf("$%d", i+2)
		args = append(args, id)
	}
	res, err := r.db.Exec(
		`UPDATE orders SET status=$1, updated_at=NOW() WHERE id IN (`+placeholders+`)`,
		args...)
	if err != nil {
		return 0, err
	}
	return res.RowsAffected()
}

func (r *OrderRepo) GetRevenueByPeriod(from, to time.Time) (float64, error) {
	var total float64
	err := r.db.QueryRow(
		`SELECT COALESCE(SUM(total_amount),0) FROM orders WHERE status='fulfilled' AND created_at BETWEEN $1 AND $2`,
		from, to).Scan(&total)
	return total, err
}

func (r *OrderRepo) CountByStatus() (map[string]int, error) {
	type row struct {
		Status string `db:"status"`
		Count  int    `db:"count"`
	}
	var rows []row
	err := r.db.Select(&rows, `SELECT status, COUNT(*) as count FROM orders GROUP BY status`)
	if err != nil {
		return nil, err
	}
	result := make(map[string]int, len(rows))
	for _, r := range rows {
		result[r.Status] = r.Count
	}
	return result, nil
}

func (r *OrderRepo) GetOrderWithItems(id uuid.UUID) (*model.OrderWithItems, error) {
	order, err := r.GetByID(id)
	if err != nil {
		return nil, err
	}
	items, err := r.GetItems(id)
	if err != nil {
		return nil, err
	}
	return &model.OrderWithItems{Order: *order, Items: items}, nil
}
