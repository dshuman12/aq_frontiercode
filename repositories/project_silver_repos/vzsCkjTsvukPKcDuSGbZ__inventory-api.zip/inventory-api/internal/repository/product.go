package repository

import (
	"database/sql"
	"fmt"

	"github.com/google/uuid"
	"github.com/jmoiron/sqlx"
	"inventoryapi.dev/api/internal/model"
)

type ProductRepo struct {
	db *sqlx.DB
}

func NewProductRepo(db *sqlx.DB) *ProductRepo {
	return &ProductRepo{db: db}
}

func (r *ProductRepo) GetByID(id uuid.UUID) (*model.Product, error) {
	var p model.Product
	err := r.db.Get(&p, `SELECT * FROM products WHERE id=$1 AND deleted_at IS NULL`, id)
	if err == sql.ErrNoRows {
		return nil, model.ErrNotFound
	}
	return &p, err
}

func (r *ProductRepo) GetBySKU(sku string) (*model.Product, error) {
	var p model.Product
	err := r.db.Get(&p, `SELECT * FROM products WHERE sku=$1 AND deleted_at IS NULL`, sku)
	if err == sql.ErrNoRows {
		return nil, model.ErrNotFound
	}
	return &p, err
}

func (r *ProductRepo) List(limit, offset int, category string) ([]model.Product, int, error) {
	if limit <= 0 { limit = 20 }
	if limit > 100 { limit = 100 }
	var total int
	countQ := `SELECT COUNT(*) FROM products WHERE deleted_at IS NULL`
	args := []any{}
	n := 1
	if category != "" {
		countQ += fmt.Sprintf(" AND category=$%d", n)
		args = append(args, category)
		n++
	}
	if err := r.db.QueryRow(countQ, args...).Scan(&total); err != nil {
		return nil, 0, err
	}
	listQ := `SELECT * FROM products WHERE deleted_at IS NULL`
	if category != "" {
		listQ += fmt.Sprintf(" AND category=$%d", n-1)
	}
	listQ += fmt.Sprintf(" ORDER BY name ASC LIMIT $%d OFFSET $%d", n, n+1)
	args = append(args, limit, offset)
	var rows []model.Product
	if err := r.db.Select(&rows, listQ, args...); err != nil {
		return nil, 0, err
	}
	return rows, total, nil
}

func (r *ProductRepo) Create(p *model.Product) error {
	if p.ID == (uuid.UUID{}) {
		p.ID = uuid.New()
	}
	_, err := r.db.NamedExec(`
		INSERT INTO products (id, sku, name, description, category, unit_price, weight_kg)
		VALUES (:id, :sku, :name, :description, :category, :unit_price, :weight_kg)`,
		p)
	return err
}

func (r *ProductRepo) Update(id uuid.UUID, req *model.UpdateProductRequest) (*model.Product, error) {
	var p model.Product
	err := r.db.QueryRowx(`
		UPDATE products SET name=$1, description=$2, category=$3, unit_price=$4, weight_kg=$5, updated_at=NOW()
		WHERE id=$6 AND deleted_at IS NULL RETURNING *`,
		req.Name, req.Description, req.Category, req.UnitPrice, req.WeightKg, id,
	).StructScan(&p)
	if err == sql.ErrNoRows {
		return nil, model.ErrNotFound
	}
	return &p, err
}

func (r *ProductRepo) Delete(id uuid.UUID) error {
	result, err := r.db.Exec(
		`UPDATE products SET deleted_at=NOW() WHERE id=$1 AND deleted_at IS NULL`, id)
	if err != nil {
		return err
	}
	rows, _ := result.RowsAffected()
	if rows == 0 {
		return model.ErrNotFound
	}
	return nil
}

func (r *ProductRepo) SearchByName(query string, limit, offset int) ([]*model.Product, error) {
	if limit <= 0 { limit = 20 }
	pattern := "%" + query + "%"
	var rows []*model.Product
	err := r.db.Select(&rows,
		`SELECT * FROM products WHERE (name ILIKE $1 OR sku ILIKE $1 OR description ILIKE $1) AND deleted_at IS NULL
		 ORDER BY name ASC LIMIT $2 OFFSET $3`,
		pattern, limit, offset)
	return rows, err
}

func (r *ProductRepo) GetInventoryForProduct(productID uuid.UUID) ([]model.Inventory, error) {
	var rows []model.Inventory
	err := r.db.Select(&rows, `SELECT * FROM inventory WHERE product_id=$1`, productID)
	return rows, err
}

func (r *ProductRepo) CountByCategory() (map[string]int, error) {
	type row struct {
		Category string `db:"category"`
		Count    int    `db:"count"`
	}
	var rows []row
	err := r.db.Select(&rows,
		`SELECT category, COUNT(*) as count FROM products WHERE deleted_at IS NULL AND category != '' GROUP BY category ORDER BY count DESC`)
	if err != nil {
		return nil, err
	}
	result := make(map[string]int, len(rows))
	for _, r := range rows {
		result[r.Category] = r.Count
	}
	return result, nil
}

func (r *ProductRepo) BulkGetByIDs(ids []uuid.UUID) ([]model.Product, error) {
	if len(ids) == 0 {
		return nil, nil
	}
	query, args, err := sqlx.In(`SELECT * FROM products WHERE id IN (?) AND deleted_at IS NULL`, ids)
	if err != nil {
		return nil, err
	}
	query = r.db.Rebind(query)
	var rows []model.Product
	err = r.db.Select(&rows, query, args...)
	return rows, err
}

func (r *ProductRepo) GetExpensiveProducts(minPrice float64, limit int) ([]model.Product, error) {
	if limit <= 0 { limit = 10 }
	var rows []model.Product
	err := r.db.Select(&rows,
		`SELECT * FROM products WHERE unit_price >= $1 AND deleted_at IS NULL ORDER BY unit_price DESC LIMIT $2`,
		minPrice, limit)
	return rows, err
}

func (r *ProductRepo) UpdatePrice(id uuid.UUID, newPrice float64) (*model.Product, error) {
	var p model.Product
	err := r.db.QueryRowx(
		`UPDATE products SET unit_price=$1, updated_at=NOW() WHERE id=$2 AND deleted_at IS NULL RETURNING *`,
		newPrice, id).StructScan(&p)
	if err == sql.ErrNoRows {
		return nil, model.ErrNotFound
	}
	return &p, err
}

func (r *ProductRepo) ExistsBySKU(sku string) (bool, error) {
	var count int
	err := r.db.QueryRow(`SELECT COUNT(*) FROM products WHERE sku=$1 AND deleted_at IS NULL`, sku).Scan(&count)
	return count > 0, err
}

func (r *ProductRepo) GetByCategory(category string) ([]model.Product, error) {
	var rows []model.Product
	err := r.db.Select(&rows,
		`SELECT * FROM products WHERE category=$1 AND deleted_at IS NULL ORDER BY name ASC`, category)
	return rows, err
}

func (r *ProductRepo) GetWithInventorySummary(id uuid.UUID) (*model.ProductWithInventory, error) {
	var result model.ProductWithInventory
	err := r.db.QueryRowx(`
		SELECT p.*,
		       COALESCE(SUM(i.quantity),0) as total_stock,
		       COALESCE(SUM(i.reserved_quantity),0) as total_reserved
		FROM products p
		LEFT JOIN inventory i ON i.product_id = p.id
		WHERE p.id = $1 AND p.deleted_at IS NULL
		GROUP BY p.id, p.sku, p.name, p.description, p.category, p.unit_price, p.weight_kg, p.created_at, p.updated_at, p.deleted_at`,
		id).StructScan(&result)
	if err == sql.ErrNoRows {
		return nil, model.ErrNotFound
	}
	if err == nil {
		result.Available = result.TotalStock - result.TotalReserved
	}
	return &result, err
}
