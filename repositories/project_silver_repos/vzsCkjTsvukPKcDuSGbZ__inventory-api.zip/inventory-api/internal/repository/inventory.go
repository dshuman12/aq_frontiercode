package repository

import (
	"database/sql"
	"time"

	"github.com/google/uuid"
	"github.com/jmoiron/sqlx"
	"inventoryapi.dev/api/internal/model"
)

type InventoryRepo struct {
	db *sqlx.DB
}

func NewInventoryRepo(db *sqlx.DB) *InventoryRepo {
	return &InventoryRepo{db: db}
}

func (r *InventoryRepo) GetByProductAndWarehouse(pid, wid uuid.UUID) (*model.Inventory, error) {
	var inv model.Inventory
	err := r.db.Get(&inv,
		`SELECT * FROM inventory WHERE product_id=$1 AND warehouse_id=$2`, pid, wid)
	if err == sql.ErrNoRows {
		return nil, model.ErrNotFound
	}
	return &inv, err
}

func (r *InventoryRepo) GetByProduct(pid uuid.UUID) ([]model.Inventory, error) {
	var rows []model.Inventory
	err := r.db.Select(&rows,
		`SELECT * FROM inventory WHERE product_id=$1 ORDER BY warehouse_id`, pid)
	return rows, err
}

func (r *InventoryRepo) GetLowStock(threshold int) ([]model.LowStockItem, error) {
	if threshold <= 0 { threshold = 10 }
	var rows []model.LowStockItem
	err := r.db.Select(&rows, `
		SELECT i.product_id, p.sku, p.name as product_name,
		       i.warehouse_id, w.name as warehouse_name,
		       i.quantity, i.reserved_quantity, i.reorder_point, i.reorder_quantity
		FROM inventory i
		JOIN products p ON p.id = i.product_id
		JOIN warehouses w ON w.id = i.warehouse_id
		WHERE (i.quantity - i.reserved_quantity) < $1
		ORDER BY (i.quantity - i.reserved_quantity) ASC`,
		threshold)
	if err == nil {
		for idx := range rows {
			rows[idx].Available = rows[idx].Quantity - rows[idx].Reserved
		}
	}
	return rows, err
}

func (r *InventoryRepo) Create(inv *model.Inventory) error {
	if inv.ID == (uuid.UUID{}) {
		inv.ID = uuid.New()
	}
	_, err := r.db.NamedExec(`
		INSERT INTO inventory (id, product_id, warehouse_id, quantity, reserved_quantity, reorder_point, reorder_quantity)
		VALUES (:id, :product_id, :warehouse_id, :quantity, :reserved_quantity, :reorder_point, :reorder_quantity)`,
		inv)
	return err
}

func (r *InventoryRepo) Reserve(id uuid.UUID, qty int) error {
	result, err := r.db.Exec(`
		UPDATE inventory SET reserved_quantity = reserved_quantity + $1
		WHERE id = $2 AND (quantity - reserved_quantity) >= $1`, qty, id)
	if err != nil {
		return err
	}
	rows, _ := result.RowsAffected()
	if rows == 0 {
		return model.ErrInsufficientStock
	}
	return nil
}

func (r *InventoryRepo) Release(id uuid.UUID, qty int) error {
	_, err := r.db.Exec(`
		UPDATE inventory SET reserved_quantity = GREATEST(0, reserved_quantity - $1)
		WHERE id = $2`, qty, id)
	return err
}

func (r *InventoryRepo) Fulfill(id uuid.UUID, qty int) error {
	result, err := r.db.Exec(`
		UPDATE inventory SET
			quantity = quantity - $1,
			reserved_quantity = GREATEST(0, reserved_quantity - $1)
		WHERE id = $2 AND quantity >= $1`, qty, id)
	if err != nil {
		return err
	}
	rows, _ := result.RowsAffected()
	if rows == 0 {
		return model.ErrInsufficientStock
	}
	return nil
}

func (r *InventoryRepo) Transfer(pid, fromWH, toWH uuid.UUID, qty int) error {
	tx, err := r.db.Beginx()
	if err != nil {
		return err
	}
	defer tx.Rollback()

	result, err := tx.Exec(`
		UPDATE inventory SET quantity = quantity - $1
		WHERE product_id=$2 AND warehouse_id=$3 AND (quantity - reserved_quantity) >= $1`,
		qty, pid, fromWH)
	if err != nil {
		return err
	}
	if rows, _ := result.RowsAffected(); rows == 0 {
		return model.ErrInsufficientStock
	}

	_, err = tx.Exec(`
		INSERT INTO inventory (id, product_id, warehouse_id, quantity, reserved_quantity, reorder_point, reorder_quantity)
		VALUES (uuid_generate_v4(), $1, $2, $3, 0, 10, 50)
		ON CONFLICT (product_id, warehouse_id) DO UPDATE SET quantity = inventory.quantity + $3`,
		pid, toWH, qty)
	if err != nil {
		return err
	}
	return tx.Commit()
}

func (r *InventoryRepo) UpdateQuantity(id uuid.UUID, qty int) error {
	_, err := r.db.Exec(
		`UPDATE inventory SET quantity=$1 WHERE id=$2`, qty, id)
	return err
}

func (r *InventoryRepo) UpdateLastRestocked(id uuid.UUID, t time.Time) error {
	_, err := r.db.Exec(
		`UPDATE inventory SET last_restocked_at=$1 WHERE id=$2`, t, id)
	return err
}

func (r *InventoryRepo) GetByWarehouse(warehouseID uuid.UUID) ([]model.InventoryWithProduct, error) {
	var rows []model.InventoryWithProduct
	err := r.db.Select(&rows, `
		SELECT i.*, p.name as product_name, p.sku, p.unit_price
		FROM inventory i
		JOIN products p ON p.id = i.product_id
		WHERE i.warehouse_id = $1
		ORDER BY p.name`, warehouseID)
	return rows, err
}

func (r *InventoryRepo) GetBelowReorderPoint() ([]model.LowStockItem, error) {
	var rows []model.LowStockItem
	err := r.db.Select(&rows, `
		SELECT i.product_id, p.sku, p.name as product_name,
		       i.warehouse_id, w.name as warehouse_name,
		       i.quantity, i.reserved_quantity, i.reorder_point, i.reorder_quantity
		FROM inventory i
		JOIN products p ON p.id = i.product_id
		JOIN warehouses w ON w.id = i.warehouse_id
		WHERE (i.quantity - i.reserved_quantity) < i.reorder_point
		ORDER BY (i.quantity - i.reserved_quantity) ASC`)
	if err == nil {
		for idx := range rows {
			rows[idx].Available = rows[idx].Quantity - rows[idx].Reserved
		}
	}
	return rows, err
}

func (r *InventoryRepo) GetTotalValueByWarehouse() ([]model.WarehouseInventoryValue, error) {
	var rows []model.WarehouseInventoryValue
	err := r.db.Select(&rows, `
		SELECT w.id, w.name, COALESCE(SUM(i.quantity * p.unit_price), 0) as total_value
		FROM warehouses w
		LEFT JOIN inventory i ON i.warehouse_id = w.id
		LEFT JOIN products p ON p.id = i.product_id
		WHERE w.is_active = true
		GROUP BY w.id, w.name
		ORDER BY total_value DESC`)
	return rows, err
}

func (r *InventoryRepo) GetStockSummaryByProduct(productID uuid.UUID) (total, reserved int, err error) {
	err = r.db.QueryRow(
		`SELECT COALESCE(SUM(quantity),0), COALESCE(SUM(reserved_quantity),0) FROM inventory WHERE product_id=$1`,
		productID).Scan(&total, &reserved)
	return
}

func (r *InventoryRepo) SetReorderThresholds(id uuid.UUID, reorderPoint, reorderQty int) error {
	_, err := r.db.Exec(
		`UPDATE inventory SET reorder_point=$1, reorder_quantity=$2 WHERE id=$3`,
		reorderPoint, reorderQty, id)
	return err
}

func (r *InventoryRepo) GetItemsNeedingReorder() ([]model.Inventory, error) {
	var rows []model.Inventory
	err := r.db.Select(&rows, `
		SELECT * FROM inventory
		WHERE (quantity - reserved_quantity) < reorder_point
		ORDER BY (quantity - reserved_quantity) ASC`)
	return rows, err
}

