package repository

import (
	"database/sql"
	"fmt"

	"github.com/google/uuid"
	"github.com/jmoiron/sqlx"
	"inventoryapi.dev/api/internal/model"
)

type WarehouseRepo struct {
	db *sqlx.DB
}

func NewWarehouseRepo(db *sqlx.DB) *WarehouseRepo {
	return &WarehouseRepo{db: db}
}

func (r *WarehouseRepo) GetByID(id uuid.UUID) (*model.Warehouse, error) {
	var w model.Warehouse
	err := r.db.Get(&w, `SELECT * FROM warehouses WHERE id=$1`, id)
	if err == sql.ErrNoRows {
		return nil, model.ErrNotFound
	}
	return &w, err
}

func (r *WarehouseRepo) List(onlyActive bool) ([]model.Warehouse, error) {
	q := `SELECT * FROM warehouses`
	if onlyActive {
		q += " WHERE is_active=true"
	}
	q += " ORDER BY name ASC"
	var rows []model.Warehouse
	err := r.db.Select(&rows, q)
	return rows, err
}

func (r *WarehouseRepo) ListPaginated(limit, offset int, onlyActive bool) ([]model.Warehouse, int, error) {
	if limit <= 0 { limit = 20 }
	where := " WHERE 1=1"
	args := []any{}
	n := 1
	if onlyActive {
		where += fmt.Sprintf(" AND is_active=$%d", n)
		args = append(args, true)
		n++
	}
	var total int
	if err := r.db.QueryRow("SELECT COUNT(*) FROM warehouses"+where, args...).Scan(&total); err != nil {
		return nil, 0, err
	}
	listQ := "SELECT * FROM warehouses" + where + fmt.Sprintf(" ORDER BY name ASC LIMIT $%d OFFSET $%d", n, n+1)
	args = append(args, limit, offset)
	var rows []model.Warehouse
	if err := r.db.Select(&rows, listQ, args...); err != nil {
		return nil, 0, err
	}
	return rows, total, nil
}

func (r *WarehouseRepo) Create(w *model.Warehouse) error {
	if w.ID == (uuid.UUID{}) {
		w.ID = uuid.New()
	}
	_, err := r.db.NamedExec(`
		INSERT INTO warehouses (id, name, location, max_capacity, current_usage, is_active)
		VALUES (:id, :name, :location, :max_capacity, :current_usage, :is_active)`, w)
	return err
}

func (r *WarehouseRepo) Update(id uuid.UUID, req *model.UpdateWarehouseRequest) (*model.Warehouse, error) {
	var w model.Warehouse
	err := r.db.QueryRowx(`
		UPDATE warehouses SET name=$1, location=$2, max_capacity=$3
		WHERE id=$4 RETURNING *`,
		req.Name, req.Location, req.MaxCapacity, id,
	).StructScan(&w)
	if err == sql.ErrNoRows {
		return nil, model.ErrNotFound
	}
	return &w, err
}

func (r *WarehouseRepo) SetActive(id uuid.UUID, active bool) error {
	result, err := r.db.Exec(
		`UPDATE warehouses SET is_active=$1 WHERE id=$2`, active, id)
	if err != nil {
		return err
	}
	rows, _ := result.RowsAffected()
	if rows == 0 {
		return model.ErrNotFound
	}
	return nil
}

func (r *WarehouseRepo) UpdateCapacityUsage(id uuid.UUID, delta int) error {
	_, err := r.db.Exec(`
		UPDATE warehouses SET current_usage = GREATEST(0, current_usage + $1)
		WHERE id=$2`, delta, id)
	return err
}

func (r *WarehouseRepo) GetCapacityStats(id uuid.UUID) (maxCap, currentUsage int, err error) {
	err = r.db.QueryRow(
		`SELECT max_capacity, current_usage FROM warehouses WHERE id=$1`, id,
	).Scan(&maxCap, &currentUsage)
	return
}

func (r *WarehouseRepo) GetUtilizationSummary() ([]map[string]any, error) {
	type row struct {
		ID         uuid.UUID `db:"id"`
		Name       string    `db:"name"`
		MaxCap     int       `db:"max_capacity"`
		CurrentUse int       `db:"current_usage"`
	}
	var rows []row
	err := r.db.Select(&rows,
		`SELECT id, name, max_capacity, current_usage FROM warehouses WHERE is_active=true ORDER BY name`)
	if err != nil {
		return nil, err
	}
	result := make([]map[string]any, len(rows))
	for i, row := range rows {
		pct := 0.0
		if row.MaxCap > 0 {
			pct = float64(row.CurrentUse) / float64(row.MaxCap) * 100
		}
		result[i] = map[string]any{
			"id": row.ID, "name": row.Name,
			"max_capacity":    row.MaxCap,
			"current_usage":   row.CurrentUse,
			"available":       row.MaxCap - row.CurrentUse,
			"utilization_pct": pct,
		}
	}
	return result, nil
}

func (r *WarehouseRepo) GetNearCapacity(threshold float64) ([]model.Warehouse, error) {
	var rows []model.Warehouse
	err := r.db.Select(&rows, `
		SELECT * FROM warehouses
		WHERE is_active=true
		  AND max_capacity > 0
		  AND (CAST(current_usage AS FLOAT) / max_capacity) >= $1
		ORDER BY (CAST(current_usage AS FLOAT) / max_capacity) DESC`,
		threshold/100.0)
	return rows, err
}

func (r *WarehouseRepo) CountActiveWarehouses() (int, error) {
	var count int
	err := r.db.QueryRow(`SELECT COUNT(*) FROM warehouses WHERE is_active=true`).Scan(&count)
	return count, err
}

func (r *WarehouseRepo) GetTotalCapacity() (total, used int, err error) {
	err = r.db.QueryRow(`
		SELECT COALESCE(SUM(max_capacity),0), COALESCE(SUM(current_usage),0)
		FROM warehouses WHERE is_active=true`).Scan(&total, &used)
	return
}
