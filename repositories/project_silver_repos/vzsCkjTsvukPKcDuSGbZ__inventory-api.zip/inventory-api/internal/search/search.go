package search

import (
	"fmt"
	"strings"
	"time"

	"github.com/google/uuid"
)

type Params struct {
	Query     string
	Fields    []string
	Status    []string
	DateFrom  *time.Time
	DateTo    *time.Time
	OwnerID   *uuid.UUID
	MinAmount *float64
	MaxAmount *float64
	Limit     int
	Offset    int
	SortBy    string
	SortDir   string
}

type Builder struct {
	conditions []string
	args       []any
	n          int
}

func NewBuilder() *Builder {
	return &Builder{n: 1}
}

func (b *Builder) AddTextSearch(query string, fields []string) *Builder {
	if query == "" || len(fields) == 0 {
		return b
	}
	parts := make([]string, len(fields))
	val := "%" + query + "%"
	for i, f := range fields {
		parts[i] = fmt.Sprintf("%s ILIKE $%d", f, b.n)
		b.args = append(b.args, val)
		b.n++
	}
	b.conditions = append(b.conditions, "("+strings.Join(parts, " OR ")+")")
	return b
}

func (b *Builder) AddStatusFilter(statuses []string) *Builder {
	if len(statuses) == 0 {
		return b
	}
	b.conditions = append(b.conditions, fmt.Sprintf("status = ANY($%d)", b.n))
	b.args = append(b.args, statuses)
	b.n++
	return b
}

func (b *Builder) AddDateRange(field string, from, to *time.Time) *Builder {
	if from != nil {
		b.conditions = append(b.conditions, fmt.Sprintf("%s >= $%d", field, b.n))
		b.args = append(b.args, *from)
		b.n++
	}
	if to != nil {
		b.conditions = append(b.conditions, fmt.Sprintf("%s <= $%d", field, b.n))
		b.args = append(b.args, *to)
		b.n++
	}
	return b
}

func (b *Builder) AddOwner(ownerID *uuid.UUID) *Builder {
	if ownerID == nil {
		return b
	}
	b.conditions = append(b.conditions, fmt.Sprintf("owner_id = $%d", b.n))
	b.args = append(b.args, *ownerID)
	b.n++
	return b
}

func (b *Builder) AddAmountRange(min, max *float64) *Builder {
	if min != nil {
		b.conditions = append(b.conditions, fmt.Sprintf("amount >= $%d", b.n))
		b.args = append(b.args, *min)
		b.n++
	}
	if max != nil {
		b.conditions = append(b.conditions, fmt.Sprintf("amount <= $%d", b.n))
		b.args = append(b.args, *max)
		b.n++
	}
	return b
}

func (b *Builder) AddCustom(condition string, args ...any) *Builder {
	replaced := condition
	for _, arg := range args {
		replaced = strings.Replace(replaced, "?", fmt.Sprintf("$%d", b.n), 1)
		b.args = append(b.args, arg)
		b.n++
	}
	b.conditions = append(b.conditions, replaced)
	return b
}

func (b *Builder) Build() (string, []any) {
	if len(b.conditions) == 0 {
		return "", b.args
	}
	return "WHERE " + strings.Join(b.conditions, " AND "), b.args
}

func (b *Builder) BuildOrderClause(allowedFields []string, sortBy, sortDir string) string {
	allowed := make(map[string]bool)
	for _, f := range allowedFields {
		allowed[f] = true
	}
	if !allowed[sortBy] {
		sortBy = "created_at"
	}
	dir := "DESC"
	if strings.ToUpper(sortDir) == "ASC" {
		dir = "ASC"
	}
	return fmt.Sprintf("ORDER BY %s %s", sortBy, dir)
}

func (b *Builder) NextArgIdx() int {
	return b.n
}

type SortDirection string

const (
	SortAsc  SortDirection = "ASC"
	SortDesc SortDirection = "DESC"
)

type SortField struct {
	Column    string
	Direction SortDirection
	Allowed   []string
}

func NewSortField(col string, dir SortDirection, allowed []string) *SortField {
	return &SortField{Column: col, Direction: dir, Allowed: allowed}
}

func (sf *SortField) IsValid() bool {
	for _, a := range sf.Allowed {
		if a == sf.Column {
			return true
		}
	}
	return false
}

func (sf *SortField) ToSQL() string {
	if !sf.IsValid() {
		return ""
	}
	return sf.Column + " " + string(sf.Direction)
}

type TextSearch struct {
	Query     string
	Fields    []string
	MinLength int
}

func NewTextSearch(query string, fields []string) *TextSearch {
	return &TextSearch{Query: query, Fields: fields, MinLength: 2}
}

func (ts *TextSearch) IsValid() bool {
	return len([]rune(ts.Query)) >= ts.MinLength
}

func (ts *TextSearch) ToLikePattern() string {
	return "%" + ts.Query + "%"
}

type NumericRange struct {
	Min *float64
	Max *float64
}

func (nr *NumericRange) IsValid() bool {
	if nr.Min != nil && nr.Max != nil {
		return *nr.Min <= *nr.Max
	}
	return true
}

func (nr *NumericRange) HasMin() bool { return nr.Min != nil }
func (nr *NumericRange) HasMax() bool { return nr.Max != nil }
