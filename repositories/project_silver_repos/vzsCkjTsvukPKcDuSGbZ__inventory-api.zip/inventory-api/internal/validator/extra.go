package validator

import (
	"fmt"
	"net/url"
	"strings"
	"time"
	"unicode/utf8"
)

func IsValidURL(s string) bool {
	u, err := url.ParseRequestURI(s)
	return err == nil && u.Scheme != "" && u.Host != ""
}

func IsAlphanumeric(s string) bool {
	for _, r := range s {
		if !((r >= 'a' && r <= 'z') || (r >= 'A' && r <= 'Z') || (r >= '0' && r <= '9')) {
			return false
		}
	}
	return s != ""
}

func IsValidCurrency(amount float64) bool {
	cents := int64(amount * 100)
	return float64(cents)/100 == amount && amount >= 0
}

func MaxLength(s string, max int) bool {
	return utf8.RuneCountInString(s) <= max
}

func MinLength(s string, min int) bool {
	return utf8.RuneCountInString(s) >= min
}

func IsWithinDateBounds(t, minT, maxT time.Time) bool {
	return !t.Before(minT) && !t.After(maxT)
}

func IsFutureDate(t time.Time) bool {
	return t.After(time.Now())
}

func IsPastDate(t time.Time) bool {
	return t.Before(time.Now())
}

func ValidatePageSize(size int) error {
	if size <= 0 {
		return fmt.Errorf("page size must be positive")
	}
	if size > 100 {
		return fmt.Errorf("page size cannot exceed 100")
	}
	return nil
}

func ValidateSortDir(dir string) bool {
	d := strings.ToUpper(dir)
	return d == "ASC" || d == "DESC"
}

func ContainsOnly(s string, allowed string) bool {
	for _, r := range s {
		if !strings.ContainsRune(allowed, r) {
			return false
		}
	}
	return true
}

func IsValidOrderStatus(status string) bool {
	validStatuses := map[string]bool{
		"pending": true, "confirmed": true,
		"fulfilled": true, "partially_fulfilled": true, "cancelled": true,
	}
	return validStatuses[status]
}

func IsValidWarehouseID(id string) bool {
	return IsValidUUID(id)
}

func IsValidProductID(id string) bool {
	return IsValidUUID(id)
}
