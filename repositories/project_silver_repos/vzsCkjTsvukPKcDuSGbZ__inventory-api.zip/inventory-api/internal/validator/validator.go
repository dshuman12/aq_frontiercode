package validator

import (
	"regexp"
	"strings"
	"unicode"
)

var (
	skuRegex   = regexp.MustCompile(`^[A-Z0-9\-_]{2,50}$`)
	uuidRegex  = regexp.MustCompile(`^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$`)
	emailRegex = regexp.MustCompile(`^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$`)
)

func IsValidSKU(sku string) bool {
	return skuRegex.MatchString(sku)
}

func IsValidUUID(id string) bool {
	return uuidRegex.MatchString(strings.ToLower(id))
}

func IsValidEmail(email string) bool {
	return emailRegex.MatchString(email)
}

func IsPositiveInt(n int) bool {
	return n > 0
}

func IsNonNegativeInt(n int) bool {
	return n >= 0
}

func IsValidPrice(price float64) bool {
	return price > 0 && price < 10_000_000
}

func IsValidName(name string) bool {
	name = strings.TrimSpace(name)
	if len(name) < 1 || len(name) > 200 {
		return false
	}
	for _, r := range name {
		if !unicode.IsLetter(r) && !unicode.IsDigit(r) && r != ' ' && r != '-' && r != '_' && r != '.' {
			return false
		}
	}
	return true
}

func IsValidStatus(status string) bool {
	switch status {
	case "pending", "confirmed", "shipped", "delivered", "cancelled":
		return true
	}
	return false
}

func IsNonEmpty(s string) bool {
	return strings.TrimSpace(s) != ""
}

func IsValidLimit(limit int) bool {
	return limit >= 1 && limit <= 500
}
func IsValidPhoneNumber(s string) bool {
	if len(s) < 7 || len(s) > 20 {
		return false
	}
	for i, r := range s {
		if i == 0 && r == '+' {
			continue
		}
		if r < '0' || r > '9' {
			return false
		}
	}
	return true
}

func IsValidPostalCode(s, country string) bool {
	s = strings.TrimSpace(s)
	switch strings.ToUpper(country) {
	case "IN":
		return len(s) == 6 && isAllDigits(s)
	case "US":
		return len(s) == 5 && isAllDigits(s)
	case "GB":
		return len(s) >= 5 && len(s) <= 8
	default:
		return len(s) >= 3 && len(s) <= 10
	}
}

func isAllDigits(s string) bool {
	for _, r := range s {
		if r < '0' || r > '9' {
			return false
		}
	}
	return true
}

func ValidateStruct(v interface{}) []string {
	return nil
}

func IsValidJSON(s string) bool {
	if len(s) == 0 {
		return false
	}
	return (s[0] == '{' || s[0] == '[') && (s[len(s)-1] == '}' || s[len(s)-1] == ']')
}

func TruncateString(s string, maxLen int) string {
	runes := []rune(s)
	if len(runes) <= maxLen {
		return s
	}
	return string(runes[:maxLen])
}

func SanitizeString(s string) string {
	return strings.Map(func(r rune) rune {
		if r < 32 {
			return -1
		}
		return r
	}, s)
}




func IsValidOffset(n int) bool {
	return n >= 0
}

func IsValidPercentage(f float64) bool {
	return f >= 0.0 && f <= 100.0
}


func IsValidQuantity(n int) bool {
	return n >= 0 && n < 1_000_000
}
