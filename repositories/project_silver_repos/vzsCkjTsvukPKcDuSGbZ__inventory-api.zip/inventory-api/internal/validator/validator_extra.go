package validator

import (
	"fmt"
	"regexp"
	"strings"
	"time"
	"unicode"

	"github.com/google/uuid"
)

var (
	emailRegex = regexp.MustCompile(`^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$`)
	skuRegex   = regexp.MustCompile(`^[A-Z0-9\-_]{3,50}$`)
	phoneRegex = regexp.MustCompile(`^\+?[0-9\s\-\(\)]{7,20}$`)
)

func IsValidPhone(s string) bool {
	return phoneRegex.MatchString(strings.TrimSpace(s))
}

func IsNonEmptyString(s string) bool {
	return strings.TrimSpace(s) != ""
}

func IsPositiveFloat(f float64) bool {
	return f > 0
}

func IsInRange(n, min, max int) bool {
	return n >= min && n <= max
}

func IsInFloatRange(f, min, max float64) bool {
	return f >= min && f <= max
}

func IsValidDateRange(from, to time.Time) bool {
	return !from.IsZero() && !to.IsZero() && !to.Before(from)
}

func IsValidPagination(limit, offset int) bool {
	return limit > 0 && limit <= 100 && offset >= 0
}

func IsValidWeight(w float64) bool {
	return w > 0 && w < 100000
}

func NormalizeSKU(s string) string {
	return strings.ToUpper(strings.TrimSpace(s))
}

type FieldError struct {
	Field   string
	Message string
}

type MultiError struct {
	Errors []FieldError
}

func (m *MultiError) Error() string {
	msgs := make([]string, len(m.Errors))
	for i, e := range m.Errors {
		msgs[i] = fmt.Sprintf("%s: %s", e.Field, e.Message)
	}
	return strings.Join(msgs, "; ")
}

func (m *MultiError) Add(field, message string) {
	m.Errors = append(m.Errors, FieldError{Field: field, Message: message})
}

func (m *MultiError) HasErrors() bool {
	return len(m.Errors) > 0
}

func NewMultiError() *MultiError {
	return &MultiError{Errors: make([]FieldError, 0)}
}

func ValidateRequired(fields map[string]string) error {
	me := NewMultiError()
	for field, value := range fields {
		if strings.TrimSpace(value) == "" {
			me.Add(field, "is required")
		}
	}
	if me.HasErrors() {
		return me
	}
	return nil
}

func ValidateStringLength(field, value string, min, max int) error {
	l := len([]rune(value))
	if l < min {
		return fmt.Errorf("field '%s' must be at least %d characters", field, min)
	}
	if l > max {
		return fmt.Errorf("field '%s' must be at most %d characters", field, max)
	}
	return nil
}
