package report

import (
	"context"
	"time"

	"github.com/google/uuid"
	"github.com/jmoiron/sqlx"
)

type SummaryReport struct {
	TotalProducts    int       `json:"total_products"`
	TotalWarehouses  int       `json:"total_warehouses"`
	TotalOrders      int       `json:"total_orders"`
	FulfilledOrders  int       `json:"fulfilled_orders"`
	PendingOrders    int       `json:"pending_orders"`
	CancelledOrders  int       `json:"cancelled_orders"`
	TotalRevenue     float64   `json:"total_revenue"`
	AvgOrderValue    float64   `json:"avg_order_value"`
	LowStockProducts int       `json:"low_stock_products"`
	GeneratedAt      time.Time `json:"generated_at"`
	PeriodFrom       time.Time `json:"period_from"`
	PeriodTo         time.Time `json:"period_to"`
}

type StatusCount struct {
	Status     string  `db:"status" json:"status"`
	Count      int     `db:"count" json:"count"`
	Percentage float64 `json:"percentage"`
}

type TrendPoint struct {
	Date  time.Time `db:"date" json:"date"`
	Value float64   `db:"value" json:"value"`
	Label string    `json:"label"`
}

type WarehouseUtilization struct {
	WarehouseID     uuid.UUID `db:"id" json:"warehouse_id"`
	Name            string    `db:"name" json:"name"`
	Location        string    `db:"location" json:"location"`
	MaxCapacity     int       `db:"max_capacity" json:"max_capacity"`
	CurrentUsage    int       `db:"current_usage" json:"current_usage"`
	ReservedQty     int       `db:"reserved_qty" json:"reserved_qty"`
	UtilizationPct  float64   `json:"utilization_pct"`
}

type TopProduct struct {
	ProductID      uuid.UUID `db:"id" json:"product_id"`
	SKU            string    `db:"sku" json:"sku"`
	Name           string    `db:"name" json:"name"`
	TotalFulfilled int       `db:"total_fulfilled" json:"total_fulfilled"`
	TotalRevenue   float64   `db:"total_revenue" json:"total_revenue"`
	AvgOrderQty    float64   `db:"avg_order_qty" json:"avg_order_qty"`
}

type LowStockItem struct {
	ProductID     uuid.UUID `db:"product_id" json:"product_id"`
	SKU           string    `db:"sku" json:"sku"`
	ProductName   string    `db:"product_name" json:"product_name"`
	WarehouseID   uuid.UUID `db:"warehouse_id" json:"warehouse_id"`
	WarehouseName string    `db:"warehouse_name" json:"warehouse_name"`
	Quantity      int       `db:"quantity" json:"quantity"`
	Reserved      int       `db:"reserved_quantity" json:"reserved"`
	Available     int       `json:"available"`
	ReorderPoint  int       `db:"reorder_point" json:"reorder_point"`
	ReorderQty    int       `db:"reorder_quantity" json:"reorder_qty"`
}

type Service struct {
	db *sqlx.DB
}

func New(db *sqlx.DB) *Service {
	return &Service{db: db}
}

func (s *Service) GetSummaryReport(ctx context.Context, from, to time.Time) (*SummaryReport, error) {
	r := &SummaryReport{GeneratedAt: time.Now(), PeriodFrom: from, PeriodTo: to}
	s.db.QueryRowContext(ctx, `SELECT COUNT(*) FROM products WHERE deleted_at IS NULL`).Scan(&r.TotalProducts)
	s.db.QueryRowContext(ctx, `SELECT COUNT(*) FROM warehouses WHERE is_active=true`).Scan(&r.TotalWarehouses)
	s.db.QueryRowContext(ctx, `SELECT COUNT(*) FROM orders WHERE created_at BETWEEN $1 AND $2`, from, to).Scan(&r.TotalOrders)
	s.db.QueryRowContext(ctx, `SELECT COUNT(*) FROM orders WHERE status='fulfilled' AND created_at BETWEEN $1 AND $2`, from, to).Scan(&r.FulfilledOrders)
	s.db.QueryRowContext(ctx, `SELECT COUNT(*) FROM orders WHERE status IN ('pending','confirmed') AND created_at BETWEEN $1 AND $2`, from, to).Scan(&r.PendingOrders)
	s.db.QueryRowContext(ctx, `SELECT COUNT(*) FROM orders WHERE status='cancelled' AND created_at BETWEEN $1 AND $2`, from, to).Scan(&r.CancelledOrders)
	s.db.QueryRowContext(ctx, `SELECT COALESCE(SUM(total_amount),0) FROM orders WHERE status='fulfilled' AND created_at BETWEEN $1 AND $2`, from, to).Scan(&r.TotalRevenue)
	if r.FulfilledOrders > 0 {
		r.AvgOrderValue = r.TotalRevenue / float64(r.FulfilledOrders)
	}
	s.db.QueryRowContext(ctx, `SELECT COUNT(*) FROM inventory WHERE (quantity - reserved_quantity) < reorder_point`).Scan(&r.LowStockProducts)
	return r, nil
}

func (s *Service) GetOrderStatusDistribution(ctx context.Context) ([]StatusCount, error) {
	var rows []StatusCount
	err := s.db.SelectContext(ctx, &rows,
		`SELECT status, COUNT(*) as count FROM orders GROUP BY status ORDER BY count DESC`)
	if err != nil {
		return nil, err
	}
	var total int
	for _, r := range rows {
		total += r.Count
	}
	for i := range rows {
		if total > 0 {
			rows[i].Percentage = float64(rows[i].Count) / float64(total) * 100
		}
	}
	return rows, nil
}

func (s *Service) GetRevenueTrend(ctx context.Context, days int) ([]TrendPoint, error) {
	if days <= 0 {
		days = 30
	}
	var rows []TrendPoint
	err := s.db.SelectContext(ctx, &rows,
		`SELECT DATE_TRUNC('day', created_at) as date, COALESCE(SUM(total_amount),0) as value
		 FROM orders
		 WHERE status='fulfilled' AND created_at >= NOW() - ($1 || ' days')::INTERVAL
		 GROUP BY DATE_TRUNC('day', created_at)
		 ORDER BY date ASC`, days)
	if err != nil {
		return nil, err
	}
	for i := range rows {
		rows[i].Label = rows[i].Date.Format("Jan 02")
	}
	return rows, nil
}

func (s *Service) GetWarehouseUtilization(ctx context.Context) ([]WarehouseUtilization, error) {
	var rows []WarehouseUtilization
	err := s.db.SelectContext(ctx, &rows,
		`SELECT w.id, w.name, w.location, w.max_capacity, w.current_usage,
		        COALESCE(SUM(i.reserved_quantity),0) as reserved_qty
		 FROM warehouses w
		 LEFT JOIN inventory i ON i.warehouse_id = w.id
		 WHERE w.is_active = true
		 GROUP BY w.id, w.name, w.location, w.max_capacity, w.current_usage
		 ORDER BY w.name`)
	if err != nil {
		return nil, err
	}
	for i := range rows {
		if rows[i].MaxCapacity > 0 {
			rows[i].UtilizationPct = float64(rows[i].CurrentUsage) / float64(rows[i].MaxCapacity) * 100
		}
	}
	return rows, nil
}

func (s *Service) GetTopSellingProducts(ctx context.Context, limit int, since time.Time) ([]TopProduct, error) {
	if limit <= 0 {
		limit = 10
	}
	var rows []TopProduct
	err := s.db.SelectContext(ctx, &rows,
		`SELECT p.id, p.sku, p.name,
		        COALESCE(SUM(oi.fulfilled_qty),0) as total_fulfilled,
		        COALESCE(SUM(oi.fulfilled_qty * oi.unit_price),0) as total_revenue,
		        COALESCE(AVG(oi.fulfilled_qty),0) as avg_order_qty
		 FROM products p
		 JOIN order_items oi ON oi.product_id = p.id
		 JOIN orders o ON o.id = oi.order_id
		 WHERE o.status='fulfilled' AND o.created_at >= $1
		 GROUP BY p.id, p.sku, p.name
		 ORDER BY total_fulfilled DESC
		 LIMIT $2`, since, limit)
	return rows, err
}

func (s *Service) GetLowStockAlerts(ctx context.Context) ([]LowStockItem, error) {
	var rows []LowStockItem
	err := s.db.SelectContext(ctx, &rows,
		`SELECT i.product_id, p.sku, p.name as product_name,
		        i.warehouse_id, w.name as warehouse_name,
		        i.quantity, i.reserved_quantity, i.reorder_point, i.reorder_quantity
		 FROM inventory i
		 JOIN products p ON p.id = i.product_id
		 JOIN warehouses w ON w.id = i.warehouse_id
		 WHERE (i.quantity - i.reserved_quantity) < i.reorder_point
		 ORDER BY (i.quantity - i.reserved_quantity) ASC`)
	if err != nil {
		return nil, err
	}
	for i := range rows {
		rows[i].Available = rows[i].Quantity - rows[i].Reserved
	}
	return rows, nil
}


type TrendReport struct {
	Metric     string       `json:"metric"`
	Points     []TrendPoint `json:"points"`
	StartValue float64      `json:"start_value"`
	EndValue   float64      `json:"end_value"`
}

func (r *TrendReport) ChangePercent() float64 {
	if r.StartValue == 0 {
		return 0
	}
	return (r.EndValue - r.StartValue) / r.StartValue * 100
}

func (r *TrendReport) IsImproving() bool {
	return r.EndValue > r.StartValue
}

func (r *TrendReport) AddPoint(period string, value float64) {
	r.Points = append(r.Points, TrendPoint{Label: period, Value: value})
	if len(r.Points) == 1 {
		r.StartValue = value
	}
	r.EndValue = value
}

type WarehouseUtilisationSummary struct {
	WarehouseID   string  `json:"warehouse_id"`
	Name          string  `json:"name"`
	CapacityUsed  int     `json:"capacity_used"`
	CapacityTotal int     `json:"capacity_total"`
	PctUsed       float64 `json:"pct_used"`
}

func (w *WarehouseUtilisationSummary) IsNearFull() bool {
	return w.PctUsed > 85.0
}
