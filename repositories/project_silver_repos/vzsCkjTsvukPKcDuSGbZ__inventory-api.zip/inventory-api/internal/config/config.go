package config

import (
	"fmt"
	"os"
	"strconv"
	"time"
)

type Config struct {
	DBHost     string
	DBPort     string
	DBUser     string
	DBPassword string
	DBName     string
	DBSSLMode  string

	ServerPort      string
	ServerTimeout   time.Duration
	ShutdownTimeout time.Duration

	JWTSecret     string
	JWTExpiry     time.Duration

	RateLimitRPS   int
	RateLimitBurst int

	LogLevel  string
	LogFormat string

	MaxPageSize     int
	DefaultPageSize int

	LowStockThreshold    int
	ReorderCheckInterval time.Duration

	CacheTTL      time.Duration
	CacheMaxItems int
}

func Load() *Config {
	return &Config{
		DBHost:     getEnv("DB_HOST", "localhost"),
		DBPort:     getEnv("DB_PORT", "5432"),
		DBUser:     getEnv("DB_USER", "postgres"),
		DBPassword: getEnv("DB_PASSWORD", ""),
		DBName:     getEnv("DB_NAME", "inventory_db"),
		DBSSLMode:  getEnv("DB_SSL_MODE", "disable"),

		ServerPort:      getEnv("SERVER_PORT", "8080"),
		ServerTimeout:   getDuration("SERVER_TIMEOUT", 30*time.Second),
		ShutdownTimeout: getDuration("SHUTDOWN_TIMEOUT", 10*time.Second),

		JWTSecret: getEnv("JWT_SECRET", "change-me-in-production"),
		JWTExpiry: getDuration("JWT_EXPIRY", 24*time.Hour),

		RateLimitRPS:   getInt("RATE_LIMIT_RPS", 10),
		RateLimitBurst: getInt("RATE_LIMIT_BURST", 20),

		LogLevel:  getEnv("LOG_LEVEL", "info"),
		LogFormat: getEnv("LOG_FORMAT", "json"),

		MaxPageSize:     getInt("MAX_PAGE_SIZE", 100),
		DefaultPageSize: getInt("DEFAULT_PAGE_SIZE", 20),

		LowStockThreshold:    getInt("LOW_STOCK_THRESHOLD", 10),
		ReorderCheckInterval: getDuration("REORDER_CHECK_INTERVAL", 1*time.Hour),

		CacheTTL:      getDuration("CACHE_TTL", 5*time.Minute),
		CacheMaxItems: getInt("CACHE_MAX_ITEMS", 1000),
	}
}

func (c *Config) DSN() string {
	return fmt.Sprintf(
		"host=%s port=%s user=%s password=%s dbname=%s sslmode=%s",
		c.DBHost, c.DBPort, c.DBUser, c.DBPassword, c.DBName, c.DBSSLMode,
	)
}

func (c *Config) Validate() error {
	if c.JWTSecret == "" {
		return fmt.Errorf("JWT_SECRET is required")
	}
	if c.DBName == "" {
		return fmt.Errorf("DB_NAME is required")
	}
	if c.RateLimitRPS <= 0 {
		return fmt.Errorf("RATE_LIMIT_RPS must be positive")
	}
	if c.MaxPageSize <= 0 || c.MaxPageSize > 1000 {
		return fmt.Errorf("MAX_PAGE_SIZE must be between 1 and 1000")
	}
	return nil
}

func (c *Config) IsProduction() bool {
	return os.Getenv("ENV") == "production" || os.Getenv("ENVIRONMENT") == "production"
}

func (c *Config) IsDevelopment() bool {
	env := os.Getenv("ENV")
	return env == "" || env == "development" || env == "dev"
}

func getEnv(key, fallback string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return fallback
}

func getInt(key string, fallback int) int {
	v := os.Getenv(key)
	if v == "" {
		return fallback
	}
	n, err := strconv.Atoi(v)
	if err != nil {
		return fallback
	}
	return n
}

func getDuration(key string, fallback time.Duration) time.Duration {
	v := os.Getenv(key)
	if v == "" {
		return fallback
	}
	d, err := time.ParseDuration(v)
	if err != nil {
		return fallback
	}
	return d
}

