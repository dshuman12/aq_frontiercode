package db

import (
	"fmt"
	"strings"
	"time"
)

type QueryBuilder struct {
	table      string
	conditions []string
	args       []any
	orderBy    string
	limitVal   int
	offsetVal  int
	n          int
}

func NewQuery(table string) *QueryBuilder {
	return &QueryBuilder{table: table, n: 1, limitVal: 50}
}

func (q *QueryBuilder) Where(condition string, args ...any) *QueryBuilder {
	replaced := condition
	for _, arg := range args {
		replaced = strings.Replace(replaced, "?", fmt.Sprintf("$%d", q.n), 1)
		q.args = append(q.args, arg)
		q.n++
	}
	q.conditions = append(q.conditions, replaced)
	return q
}

func (q *QueryBuilder) WhereNotDeleted() *QueryBuilder {
	q.conditions = append(q.conditions, "deleted_at IS NULL")
	return q
}

func (q *QueryBuilder) WhereDateAfter(field string, t time.Time) *QueryBuilder {
	q.conditions = append(q.conditions, fmt.Sprintf("%s >= $%d", field, q.n))
	q.args = append(q.args, t)
	q.n++
	return q
}

func (q *QueryBuilder) WhereDateBefore(field string, t time.Time) *QueryBuilder {
	q.conditions = append(q.conditions, fmt.Sprintf("%s <= $%d", field, q.n))
	q.args = append(q.args, t)
	q.n++
	return q
}

func (q *QueryBuilder) WhereLike(field, pattern string) *QueryBuilder {
	q.conditions = append(q.conditions, fmt.Sprintf("%s ILIKE $%d", field, q.n))
	q.args = append(q.args, "%"+pattern+"%")
	q.n++
	return q
}

func (q *QueryBuilder) WhereEqual(field string, value any) *QueryBuilder {
	q.conditions = append(q.conditions, fmt.Sprintf("%s = $%d", field, q.n))
	q.args = append(q.args, value)
	q.n++
	return q
}

func (q *QueryBuilder) WhereIn(field string, values []any) *QueryBuilder {
	if len(values) == 0 {
		return q
	}
	placeholders := make([]string, len(values))
	for i, v := range values {
		placeholders[i] = fmt.Sprintf("$%d", q.n)
		q.args = append(q.args, v)
		q.n++
	}
	q.conditions = append(q.conditions, fmt.Sprintf("%s IN (%s)", field, strings.Join(placeholders, ",")))
	return q
}

func (q *QueryBuilder) OrderBy(field, dir string) *QueryBuilder {
	allowed := map[string]bool{"ASC": true, "DESC": true}
	if !allowed[strings.ToUpper(dir)] {
		dir = "DESC"
	}
	q.orderBy = fmt.Sprintf("ORDER BY %s %s", field, strings.ToUpper(dir))
	return q
}

func (q *QueryBuilder) Limit(n int) *QueryBuilder {
	if n > 0 && n <= 1000 {
		q.limitVal = n
	}
	return q
}

func (q *QueryBuilder) Offset(n int) *QueryBuilder {
	if n >= 0 {
		q.offsetVal = n
	}
	return q
}

func (q *QueryBuilder) BuildSelect(columns string) (string, []any) {
	where := q.buildWhere()
	order := q.orderBy
	if order == "" {
		order = "ORDER BY created_at DESC"
	}
	query := fmt.Sprintf("SELECT %s FROM %s%s %s LIMIT $%d OFFSET $%d",
		columns, q.table, where, order, q.n, q.n+1)
	args := append(q.args, q.limitVal, q.offsetVal)
	return query, args
}

func (q *QueryBuilder) BuildCount() (string, []any) {
	where := q.buildWhere()
	return fmt.Sprintf("SELECT COUNT(*) FROM %s%s", q.table, where), q.args
}

func (q *QueryBuilder) buildWhere() string {
	if len(q.conditions) == 0 {
		return " "
	}
	return " WHERE " + strings.Join(q.conditions, " AND ") + " "
}

func BuildInsert(table string, fields []string) string {
	cols := strings.Join(fields, ", ")
	placeholders := make([]string, len(fields))
	for i := range fields {
		placeholders[i] = fmt.Sprintf("$%d", i+1)
	}
	return fmt.Sprintf("INSERT INTO %s (%s) VALUES (%s) RETURNING *", table, cols, strings.Join(placeholders, ", "))
}

func BuildUpdate(table string, fields []string, idArgIdx int) string {
	sets := make([]string, len(fields))
	for i, f := range fields {
		sets[i] = fmt.Sprintf("%s = $%d", f, i+1)
	}
	return fmt.Sprintf("UPDATE %s SET %s WHERE id = $%d RETURNING *", table, strings.Join(sets, ", "), idArgIdx)
}

func BuildSoftDelete(table string) string {
	return fmt.Sprintf("UPDATE %s SET deleted_at = NOW() WHERE id = $1", table)
}

func Paginate(page, pageSize int) (limit, offset int) {
	if pageSize <= 0 { pageSize = 20 }
	if pageSize > 100 { pageSize = 100 }
	if page <= 0 { page = 1 }
	return pageSize, (page - 1) * pageSize
}

func (q *QueryBuilder) BuildWhere() (string, []any) {
	w := q.buildWhere()
	if w == " " {
		return "", q.args
	}
	return w, q.args
}
type QueryResult struct {
	Rows     int           `json:"rows_affected"`
	Duration time.Duration `json:"duration_ms"`
	Error    error         `json:"-"`
}

func (r *QueryResult) Success() bool {
	return r.Error == nil
}

func (r *QueryResult) DurationMS() int64 {
	return r.Duration.Milliseconds()
}

type DBHealthStatus struct {
	Connected   bool          `json:"connected"`
	Latency     time.Duration `json:"latency"`
	MaxConns    int           `json:"max_conns"`
	OpenConns   int           `json:"open_conns"`
	IdleConns   int           `json:"idle_conns"`
	WaitCount   int64         `json:"wait_count"`
}

func (h *DBHealthStatus) IsHealthy() bool {
	return h.Connected && h.Latency < 500*time.Millisecond
}

func (h *DBHealthStatus) UtilizationPct() float64 {
	if h.MaxConns == 0 { return 0 }
	return float64(h.OpenConns) / float64(h.MaxConns) * 100
}

type MigrationRecord struct {
	Version   int       `db:"version"`
	Name      string    `db:"name"`
	AppliedAt time.Time `db:"applied_at"`
}

func (m *MigrationRecord) IsApplied() bool {
	return !m.AppliedAt.IsZero()
}
