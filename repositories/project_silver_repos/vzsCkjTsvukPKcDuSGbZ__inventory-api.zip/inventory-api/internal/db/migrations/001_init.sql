CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE IF NOT EXISTS products (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sku         VARCHAR(50)    NOT NULL UNIQUE,
    name        VARCHAR(200)   NOT NULL,
    description TEXT,
    category    VARCHAR(100),
    unit_price  NUMERIC(12,2)  NOT NULL DEFAULT 0,
    weight_kg   NUMERIC(8,3),
    created_at  TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ    NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS warehouses (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name          VARCHAR(200)  NOT NULL,
    location      VARCHAR(255),
    max_capacity  INT           NOT NULL DEFAULT 0,
    current_usage INT           NOT NULL DEFAULT 0,
    is_active     BOOLEAN       NOT NULL DEFAULT true,
    created_at    TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS inventory (
    id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    product_id        UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    warehouse_id      UUID NOT NULL REFERENCES warehouses(id) ON DELETE CASCADE,
    quantity          INT  NOT NULL DEFAULT 0,
    reserved_quantity INT  NOT NULL DEFAULT 0,
    reorder_point     INT  NOT NULL DEFAULT 10,
    reorder_quantity  INT  NOT NULL DEFAULT 50,
    UNIQUE(product_id, warehouse_id)
);

CREATE TABLE IF NOT EXISTS orders (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    customer_id  VARCHAR(100)  NOT NULL,
    status       VARCHAR(30)   NOT NULL DEFAULT 'pending',
    total_amount NUMERIC(14,2) NOT NULL DEFAULT 0,
    notes        TEXT,
    created_at   TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    updated_at   TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS order_items (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_id      UUID          NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    product_id    UUID          NOT NULL REFERENCES products(id),
    warehouse_id  UUID          NOT NULL REFERENCES warehouses(id),
    requested_qty INT           NOT NULL,
    fulfilled_qty INT           NOT NULL DEFAULT 0,
    unit_price    NUMERIC(12,2) NOT NULL
);

