CREATE TABLE IF NOT EXISTS report_snapshots (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    report_type VARCHAR(100) NOT NULL,
    params JSONB,
    result JSONB NOT NULL,
    row_count INT NOT NULL DEFAULT 0,
    generated_by UUID,
    duration_ms INT,
    period_from TIMESTAMPTZ,
    period_to TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_reports_type ON report_snapshots(report_type);
CREATE INDEX IF NOT EXISTS idx_reports_created ON report_snapshots(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_reports_generator ON report_snapshots(generated_by) WHERE generated_by IS NOT NULL;

CREATE TABLE IF NOT EXISTS stock_movements (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    product_id UUID NOT NULL REFERENCES products(id),
    warehouse_id UUID NOT NULL REFERENCES warehouses(id),
    movement_type VARCHAR(50) NOT NULL,
    quantity INT NOT NULL,
    reference_type VARCHAR(50),
    reference_id UUID,
    actor_id UUID,
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT chk_movement_type CHECK (movement_type IN ('restock','fulfillment','transfer_in','transfer_out','reservation','release','adjustment'))
);

CREATE INDEX IF NOT EXISTS idx_movements_product ON stock_movements(product_id);
CREATE INDEX IF NOT EXISTS idx_movements_warehouse ON stock_movements(warehouse_id);
CREATE INDEX IF NOT EXISTS idx_movements_created ON stock_movements(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_movements_type ON stock_movements(movement_type);
