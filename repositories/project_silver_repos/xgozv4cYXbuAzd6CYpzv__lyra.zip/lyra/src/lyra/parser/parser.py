from __future__ import annotations

from typing import Sequence

from lyra.errors import ParseError, Position
from lyra.lexer import Token, TokenKind, tokenize
from lyra.parser import ast as A


class Parser:
    def __init__(self, tokens: list[Token]) -> None:
        self._tokens = tokens
        self._pos = 0

    def parse_module(self, *, default_name: str = "main") -> A.Module:
        position = self._peek().position
        name = default_name
        decls: list[A.Decl] = []
        # Optional ``module Name`` header.
        if self._consume_keyword("module"):
            name = self._expect_uident()
        while not self._at_eof():
            decls.append(self._declaration())
            self._match(TokenKind.SEMICOLON)
        return A.Module(name=name, declarations=decls, position=position)

    def parse_expr(self) -> A.Expr:
        expr = self._expression()
        if not self._at_eof():
            raise self._error("trailing tokens after expression")
        return expr

    def _declaration(self) -> A.Decl:
        tok = self._peek()
        if tok.is_keyword("let"):
            return self._let_declaration()
        if tok.is_keyword("type"):
            return self._type_declaration()
        if tok.is_keyword("import"):
            return self._import_declaration()
        if tok.is_keyword("export"):
            return self._export_declaration()
        if tok.is_keyword("extern"):
            return self._extern_declaration()
        raise self._error(f"unexpected start of declaration: {tok.text!r}")

    def _let_declaration(self) -> A.LetDecl:
        kw = self._expect_keyword("let")
        rec = bool(self._consume_keyword("rec"))
        first = self._binding(rec=rec)
        bindings: list[A.Binding] = [first]
        while self._consume_keyword("and"):
            bindings.append(self._binding(rec=rec))
        return A.LetDecl(bindings=bindings, position=kw.position)

    def _type_declaration(self) -> A.Decl:
        kw = self._expect_keyword("type")
        name = self._expect_uident()
        params: list[str] = []
        while self._peek().kind == TokenKind.LIDENT:
            params.append(self._advance().text)
        if self._match_op("="):
            # Either an alias or a sum type with constructors.
            if self._peek().kind == TokenKind.PIPE or self._peek().kind == TokenKind.UIDENT:
                cons = self._sum_type_body()
                return A.TypeDecl(name=name, params=params, constructors=cons,
                                  position=kw.position)
            body = self._type_expr()
            return A.TypeAlias(name=name, params=params, body=body, position=kw.position)
        raise self._error("expected = after type name")

    def _sum_type_body(self) -> list[A.DataCon]:
        cons: list[A.DataCon] = []
        # Allow an optional leading pipe.
        self._match(TokenKind.PIPE)
        cons.append(self._data_constructor())
        while self._match(TokenKind.PIPE):
            cons.append(self._data_constructor())
        return cons

    def _data_constructor(self) -> A.DataCon:
        name_tok = self._expect_uident_token()
        fields: list[A.TypeExpr] = []
        while self._peek_is_type_atom():
            fields.append(self._type_atom())
        return A.DataCon(name=name_tok.text, fields=fields, position=name_tok.position)

    def _import_declaration(self) -> A.ImportDecl:
        kw = self._expect_keyword("import")
        parts = [self._expect_uident()]
        while self._match(TokenKind.DOT):
            parts.append(self._expect_uident())
        module = ".".join(parts)
        alias: str | None = None
        items: list[str] | None = None
        if self._consume_keyword("as"):
            alias = self._expect_uident()
        elif self._match(TokenKind.LBRACE):
            items = []
            while True:
                items.append(self._expect_lident())
                if not self._match(TokenKind.COMMA):
                    break
            self._expect(TokenKind.RBRACE, "expected }")
        return A.ImportDecl(module=module, alias=alias, items=items, position=kw.position)

    def _export_declaration(self) -> A.ExportDecl:
        kw = self._expect_keyword("export")
        items = [self._expect_lident()]
        while self._match(TokenKind.COMMA):
            items.append(self._expect_lident())
        return A.ExportDecl(items=items, position=kw.position)

    def _extern_declaration(self) -> A.ExternDecl:
        kw = self._expect_keyword("extern")
        name = self._expect_lident()
        self._expect(TokenKind.COLON, "expected :")
        ty = self._type_expr()
        prim = ""
        if self._match_op("="):
            prim_tok = self._expect(TokenKind.STRING, "expected primitive name string")
            prim = prim_tok.text
        return A.ExternDecl(name=name, target_type=ty, primitive=prim, position=kw.position)

    def _binding(self, *, rec: bool = False) -> A.Binding:
        pat = self._pattern_atom()
        # Function-style sugar: ``let f x y = ...`` desugars to a lambda.
        params: list[A.Pattern] = []
        while self._peek_is_pattern_atom() and not self._peek().kind == TokenKind.COLON \
                and not self._is_op("="):
            params.append(self._pattern_atom())
        annotation: A.TypeExpr | None = None
        if self._match(TokenKind.COLON):
            annotation = self._type_expr()
        if not self._match_op("="):
            raise self._error("expected = in binding")
        body = self._expression()
        if params:
            body = A.Lambda(params=params, body=body, position=pat.position)
        return A.Binding(pattern=pat, expr=body, rec=rec,
                         annotation=annotation, position=pat.position)

    def _type_expr(self) -> A.TypeExpr:
        # arrow type associates right.
        ty = self._type_app()
        if self._match(TokenKind.ARROW):
            result = self._type_expr()
            return A.TyFun(params=[ty], result=result, position=ty.position)
        return ty

    def _type_app(self) -> A.TypeExpr:
        atom = self._type_atom()
        if isinstance(atom, A.TyCon) and self._peek_is_type_atom():
            args: list[A.TypeExpr] = []
            while self._peek_is_type_atom():
                args.append(self._type_atom())
            return A.TyCon(name=atom.name, args=args, position=atom.position)
        return atom

    def _type_atom(self) -> A.TypeExpr:
        tok = self._peek()
        if tok.kind == TokenKind.LIDENT:
            self._advance()
            return A.TyVar(name=tok.text, position=tok.position)
        if tok.kind == TokenKind.UIDENT:
            self._advance()
            return A.TyCon(name=tok.text, args=[], position=tok.position)
        if tok.kind == TokenKind.LPAREN:
            self._advance()
            if self._match(TokenKind.RPAREN):
                return A.TyCon(name="Unit", args=[], position=tok.position)
            first = self._type_expr()
            if self._match(TokenKind.COMMA):
                elems = [first]
                elems.append(self._type_expr())
                while self._match(TokenKind.COMMA):
                    elems.append(self._type_expr())
                self._expect(TokenKind.RPAREN, "expected )")
                return A.TyTuple(elements=elems, position=tok.position)
            self._expect(TokenKind.RPAREN, "expected )")
            return first
        if tok.kind == TokenKind.LBRACE:
            return self._type_record()
        if tok.is_keyword("forall"):
            self._advance()
            bound: list[str] = [self._expect_lident()]
            while self._peek().kind == TokenKind.LIDENT:
                bound.append(self._advance().text)
            self._expect(TokenKind.DOT, "expected . in forall")
            body = self._type_expr()
            return A.TyForall(bound=bound, body=body, position=tok.position)
        raise self._error("expected a type atom")

    def _type_record(self) -> A.TypeExpr:
        start = self._expect(TokenKind.LBRACE, "expected {")
        fields: list[tuple[str, A.TypeExpr]] = []
        if not self._match(TokenKind.RBRACE):
            while True:
                name = self._expect_lident()
                self._expect(TokenKind.COLON, "expected :")
                fields.append((name, self._type_expr()))
                if not self._match(TokenKind.COMMA):
                    break
            self._expect(TokenKind.RBRACE, "expected }")
        return A.TyRecord(fields=fields, position=start.position)

    def _peek_is_type_atom(self) -> bool:
        tok = self._peek()
        if tok.kind in {TokenKind.LIDENT, TokenKind.UIDENT, TokenKind.LPAREN, TokenKind.LBRACE}:
            return True
        if tok.is_keyword("forall"):
            return True
        return False

    def _pattern(self) -> A.Pattern:
        # `as` binds tightest: `Cons x xs as whole`.
        first = self._pattern_or()
        if self._consume_keyword("as"):
            name = self._expect_lident()
            return A.PAs(name=name, inner=first, position=first.position)
        return first

    def _pattern_or(self) -> A.Pattern:
        first = self._pattern_constructor()
        if self._peek().kind != TokenKind.PIPE:
            return first
        options: list[A.Pattern] = [first]
        while self._match(TokenKind.PIPE):
            options.append(self._pattern_constructor())
        return A.POr(options=options, position=first.position)

    def _pattern_constructor(self) -> A.Pattern:
        tok = self._peek()
        if tok.kind == TokenKind.UIDENT:
            self._advance()
            args: list[A.Pattern] = []
            while self._peek_is_pattern_atom():
                args.append(self._pattern_atom())
            return A.PCon(name=tok.text, args=args, position=tok.position)
        return self._pattern_atom()

    def _pattern_atom(self) -> A.Pattern:
        tok = self._peek()
        if tok.kind == TokenKind.UNDERSCORE:
            self._advance()
            return A.PWild(position=tok.position)
        if tok.kind == TokenKind.LIDENT:
            self._advance()
            return A.PVar(name=tok.text, position=tok.position)
        if tok.kind == TokenKind.UIDENT:
            self._advance()
            return A.PCon(name=tok.text, args=[], position=tok.position)
        if tok.kind == TokenKind.INT:
            self._advance()
            return A.PInt(value=int(tok.text), position=tok.position)
        if tok.kind == TokenKind.FLOAT:
            self._advance()
            return A.PFloat(value=float(tok.text), position=tok.position)
        if tok.kind == TokenKind.STRING:
            self._advance()
            return A.PString(value=tok.text, position=tok.position)
        if tok.kind == TokenKind.BOOL:
            self._advance()
            return A.PBool(value=tok.text == "true", position=tok.position)
        if tok.kind == TokenKind.CHAR:
            self._advance()
            return A.PChar(value=tok.text, position=tok.position)
        if tok.kind == TokenKind.LPAREN:
            self._advance()
            if self._match(TokenKind.RPAREN):
                return A.PCon(name="Unit", args=[], position=tok.position)
            first = self._pattern()
            if self._match(TokenKind.COMMA):
                items = [first]
                items.append(self._pattern())
                while self._match(TokenKind.COMMA):
                    items.append(self._pattern())
                self._expect(TokenKind.RPAREN, "expected )")
                return A.PTuple(elements=items, position=tok.position)
            self._expect(TokenKind.RPAREN, "expected )")
            return first
        if tok.kind == TokenKind.LBRACE:
            return self._pattern_record()
        raise self._error("expected a pattern")

    def _pattern_record(self) -> A.PRecord:
        start = self._expect(TokenKind.LBRACE, "expected {")
        fields: list[tuple[str, A.Pattern]] = []
        open_ = False
        if not self._match(TokenKind.RBRACE):
            while True:
                if self._is_op(".."):
                    self._advance()
                    open_ = True
                    break
                name = self._expect_lident()
                if self._match(TokenKind.COLON):
                    pat = self._pattern()
                else:
                    pat = A.PVar(name=name)
                fields.append((name, pat))
                if not self._match(TokenKind.COMMA):
                    break
            self._expect(TokenKind.RBRACE, "expected }")
        return A.PRecord(fields=fields, open=open_, position=start.position)

    def _peek_is_pattern_atom(self) -> bool:
        tok = self._peek()
        if tok.kind in {TokenKind.LIDENT, TokenKind.UIDENT, TokenKind.UNDERSCORE,
                        TokenKind.INT, TokenKind.FLOAT, TokenKind.STRING,
                        TokenKind.BOOL, TokenKind.CHAR, TokenKind.LPAREN,
                        TokenKind.LBRACE}:
            return True
        return False

    def _expression(self) -> A.Expr:
        return self._sequence()

    def _sequence(self) -> A.Expr:
        first = self._or_expr()
        if self._peek().kind != TokenKind.SEMICOLON:
            return first
        statements: list[A.Expr] = [first]
        while self._match(TokenKind.SEMICOLON):
            if self._peek().kind in {TokenKind.RBRACE, TokenKind.EOF}:
                break
            statements.append(self._or_expr())
        if len(statements) == 1:
            return first
        return A.Sequence_(statements=statements, position=first.position)

    def _or_expr(self) -> A.Expr:
        left = self._and_expr()
        while self._is_op("||"):
            self._advance()
            right = self._and_expr()
            left = A.BinOp(op="||", left=left, right=right, position=left.position)
        return left

    def _and_expr(self) -> A.Expr:
        left = self._compare_expr()
        while self._is_op("&&"):
            self._advance()
            right = self._compare_expr()
            left = A.BinOp(op="&&", left=left, right=right, position=left.position)
        return left

    def _compare_expr(self) -> A.Expr:
        left = self._concat_expr()
        while True:
            tok = self._peek()
            if tok.kind == TokenKind.OP and tok.text in {"==", "!=", "<", "<=", ">", ">="}:
                self._advance()
                right = self._concat_expr()
                left = A.BinOp(op=tok.text, left=left, right=right, position=left.position)
                continue
            return left

    def _concat_expr(self) -> A.Expr:
        left = self._addsub()
        while self._is_op("++"):
            self._advance()
            right = self._addsub()
            left = A.BinOp(op="++", left=left, right=right, position=left.position)
        return left

    def _addsub(self) -> A.Expr:
        left = self._muldiv()
        while True:
            tok = self._peek()
            if tok.kind == TokenKind.OP and tok.text in {"+", "-"}:
                self._advance()
                right = self._muldiv()
                left = A.BinOp(op=tok.text, left=left, right=right, position=left.position)
                continue
            return left

    def _muldiv(self) -> A.Expr:
        left = self._unary()
        while True:
            tok = self._peek()
            if tok.kind == TokenKind.OP and tok.text in {"*", "/", "%"}:
                self._advance()
                right = self._unary()
                left = A.BinOp(op=tok.text, left=left, right=right, position=left.position)
                continue
            return left

    def _unary(self) -> A.Expr:
        tok = self._peek()
        if tok.kind == TokenKind.OP and tok.text == "-":
            self._advance()
            inner = self._unary()
            return A.UnaryOp(op="-", operand=inner, position=tok.position)
        if tok.kind == TokenKind.OP and tok.text == "!":
            self._advance()
            inner = self._unary()
            return A.UnaryOp(op="!", operand=inner, position=tok.position)
        return self._application()

    def _application(self) -> A.Expr:
        head = self._primary()
        while self._peek_starts_argument():
            arg = self._primary()
            head = A.App(func=head, args=[arg], position=head.position)
        return head

    def _peek_starts_argument(self) -> bool:
        tok = self._peek()
        if tok.kind in {TokenKind.INT, TokenKind.FLOAT, TokenKind.STRING,
                        TokenKind.BOOL, TokenKind.CHAR, TokenKind.LIDENT,
                        TokenKind.UIDENT, TokenKind.LPAREN, TokenKind.LBRACE,
                        TokenKind.LBRACK}:
            return True
        return False

    def _primary(self) -> A.Expr:
        tok = self._peek()
        if tok.kind == TokenKind.INT:
            self._advance()
            return A.IntLit(value=int(tok.text), position=tok.position)
        if tok.kind == TokenKind.FLOAT:
            self._advance()
            return A.FloatLit(value=float(tok.text), position=tok.position)
        if tok.kind == TokenKind.STRING:
            self._advance()
            return A.StringLit(value=tok.text, position=tok.position)
        if tok.kind == TokenKind.BOOL:
            self._advance()
            return A.BoolLit(value=tok.text == "true", position=tok.position)
        if tok.kind == TokenKind.CHAR:
            self._advance()
            return A.CharLit(value=tok.text, position=tok.position)
        if tok.kind == TokenKind.LIDENT:
            self._advance()
            if self._match(TokenKind.DOT):
                # Module-qualified name or field access.
                rest = self._advance()
                if rest.kind == TokenKind.LIDENT:
                    return A.Var(name=rest.text, module=tok.text, position=tok.position)
                raise self._error("expected lower-case name after .")
            return self._field_chain(A.Var(name=tok.text, position=tok.position))
        if tok.kind == TokenKind.UIDENT:
            self._advance()
            return A.Var(name=tok.text, position=tok.position)
        if tok.kind == TokenKind.LPAREN:
            return self._paren_or_tuple()
        if tok.kind == TokenKind.LBRACE:
            return self._record_or_block()
        if tok.is_keyword("fn"):
            return self._lambda()
        if tok.is_keyword("let"):
            return self._let_expr()
        if tok.is_keyword("if"):
            return self._if_expr()
        if tok.is_keyword("match"):
            return self._match_expr()
        raise self._error(f"unexpected token {tok.text!r}")

    def _field_chain(self, head: A.Expr) -> A.Expr:
        while self._peek().kind == TokenKind.DOT:
            dot = self._advance()
            field_tok = self._advance()
            if field_tok.kind != TokenKind.LIDENT:
                raise self._error("expected field name after .")
            head = A.FieldAccess(target=head, field=field_tok.text, position=dot.position)
        return head

    def _paren_or_tuple(self) -> A.Expr:
        start = self._expect(TokenKind.LPAREN, "expected (")
        if self._match(TokenKind.RPAREN):
            return A.UnitLit(position=start.position)
        first = self._expression()
        if self._match(TokenKind.COMMA):
            elems = [first]
            elems.append(self._expression())
            while self._match(TokenKind.COMMA):
                elems.append(self._expression())
            self._expect(TokenKind.RPAREN, "expected )")
            return A.Tuple(elements=elems, position=start.position)
        self._expect(TokenKind.RPAREN, "expected )")
        return first

    def _record_or_block(self) -> A.Expr:
        start = self._expect(TokenKind.LBRACE, "expected {")
        # We treat `{ name = expr, name2 = expr2 }` as a record;
        # `{ stmt; stmt; expr }` as a block; the disambiguator is whether
        # the first lookahead is a lident followed by `=`.
        save = self._pos
        if self._peek().kind == TokenKind.LIDENT:
            self._advance()
            if self._is_op("="):
                self._pos = save
                return self._record_body(start.position)
            self._pos = save
        return self._block_body(start.position)

    def _record_body(self, start: Position) -> A.Record:
        fields: list[tuple[str, A.Expr]] = []
        if not self._match(TokenKind.RBRACE):
            while True:
                name = self._expect_lident()
                self._expect_op("=")
                fields.append((name, self._expression()))
                if not self._match(TokenKind.COMMA):
                    break
            self._expect(TokenKind.RBRACE, "expected }")
        return A.Record(fields=fields, position=start)

    def _block_body(self, start: Position) -> A.Expr:
        statements: list[A.Expr] = []
        while not self._match(TokenKind.RBRACE):
            statements.append(self._expression())
            self._match(TokenKind.SEMICOLON)
        if len(statements) == 1:
            return statements[0]
        return A.Sequence_(statements=statements, position=start)

    def _lambda(self) -> A.Lambda:
        kw = self._expect_keyword("fn")
        params: list[A.Pattern] = []
        while not self._peek().kind == TokenKind.ARROW:
            params.append(self._pattern_atom())
        self._expect(TokenKind.ARROW, "expected ->")
        body = self._expression()
        return A.Lambda(params=params, body=body, position=kw.position)

    def _let_expr(self) -> A.Let:
        kw = self._expect_keyword("let")
        rec = bool(self._consume_keyword("rec"))
        first = self._binding(rec=rec)
        bindings: list[A.Binding] = [first]
        while self._consume_keyword("and"):
            bindings.append(self._binding(rec=rec))
        self._expect_keyword("in")
        body = self._expression()
        return A.Let(bindings=bindings, body=body, position=kw.position)

    def _if_expr(self) -> A.If:
        kw = self._expect_keyword("if")
        cond = self._expression()
        self._expect_keyword("then")
        then_branch = self._expression()
        self._expect_keyword("else")
        else_branch = self._expression()
        return A.If(cond=cond, then_branch=then_branch, else_branch=else_branch,
                    position=kw.position)

    def _match_expr(self) -> A.Match:
        kw = self._expect_keyword("match")
        scrutinee = self._expression()
        self._expect(TokenKind.LBRACE, "expected { after match scrutinee")
        arms: list[A.MatchArm] = []
        while not self._match(TokenKind.RBRACE):
            arms.append(self._match_arm())
            self._match(TokenKind.COMMA) or self._match(TokenKind.SEMICOLON)
        return A.Match(scrutinee=scrutinee, arms=arms, position=kw.position)

    def _match_arm(self) -> A.MatchArm:
        pat = self._pattern()
        guard: A.Expr | None = None
        if self._consume_keyword("if"):
            guard = self._expression()
        self._expect(TokenKind.ARROW, "expected -> in match arm")
        body = self._expression()
        return A.MatchArm(pattern=pat, guard=guard, body=body, position=pat.position)

    def _at_eof(self) -> bool:
        return self._peek().kind == TokenKind.EOF

    def _peek(self) -> Token:
        return self._tokens[self._pos]

    def _peek_offset(self, n: int) -> Token:
        idx = min(self._pos + n, len(self._tokens) - 1)
        return self._tokens[idx]

    def _advance(self) -> Token:
        tok = self._tokens[self._pos]
        if self._pos < len(self._tokens) - 1:
            self._pos += 1
        return tok

    def _match(self, kind: TokenKind) -> bool:
        if self._peek().kind == kind:
            self._advance()
            return True
        return False

    def _match_op(self, symbol: str) -> bool:
        tok = self._peek()
        if tok.kind == TokenKind.OP and tok.text == symbol:
            self._advance()
            return True
        return False

    def _expect_op(self, symbol: str) -> Token:
        if self._match_op(symbol):
            return self._tokens[self._pos - 1]
        raise self._error(f"expected operator {symbol!r}")

    def _expect(self, kind: TokenKind, message: str) -> Token:
        if self._peek().kind == kind:
            return self._advance()
        raise self._error(message)

    def _consume_keyword(self, name: str) -> bool:
        if self._peek().is_keyword(name):
            self._advance()
            return True
        return False

    def _expect_keyword(self, name: str) -> Token:
        if self._peek().is_keyword(name):
            return self._advance()
        raise self._error(f"expected keyword {name!r}")

    def _expect_lident(self) -> str:
        tok = self._peek()
        if tok.kind == TokenKind.LIDENT:
            self._advance()
            return tok.text
        raise self._error("expected lower-case identifier")

    def _expect_uident(self) -> str:
        return self._expect_uident_token().text

    def _expect_uident_token(self) -> Token:
        tok = self._peek()
        if tok.kind == TokenKind.UIDENT:
            self._advance()
            return tok
        raise self._error("expected upper-case identifier")

    def _is_op(self, *symbols: str) -> bool:
        tok = self._peek()
        return tok.kind == TokenKind.OP and tok.text in symbols

    def _error(self, message: str) -> ParseError:
        tok = self._peek()
        return ParseError(message, position=tok.position,
                          context={"token": tok.text})


def parse_module(source: str, *, file: str = "<string>", default_name: str = "main") -> A.Module:
    tokens = tokenize(source, file=file)
    return Parser(tokens).parse_module(default_name=default_name)


def parse_expr(source: str, *, file: str = "<string>") -> A.Expr:
    tokens = tokenize(source, file=file)
    return Parser(tokens).parse_expr()
