from __future__ import annotations

from dataclasses import dataclass, field
from typing import Sequence

from lyra.errors import Position



@dataclass
class Node:
    position: Position = field(default_factory=Position, repr=False)



@dataclass
class TypeExpr(Node):
    pass


@dataclass
class TyVar(TypeExpr):
    name: str = ""


@dataclass
class TyCon(TypeExpr):
    name: str = ""
    args: Sequence[TypeExpr] = ()


@dataclass
class TyFun(TypeExpr):
    params: Sequence[TypeExpr] = ()
    result: TypeExpr | None = None


@dataclass
class TyForall(TypeExpr):
    bound: Sequence[str] = ()
    body: TypeExpr | None = None


@dataclass
class TyRecord(TypeExpr):
    fields: Sequence[tuple[str, TypeExpr]] = ()


@dataclass
class TyTuple(TypeExpr):
    elements: Sequence[TypeExpr] = ()



@dataclass
class Pattern(Node):
    annotation: TypeExpr | None = None


@dataclass
class PVar(Pattern):
    name: str = ""


@dataclass
class PWild(Pattern):
    pass


@dataclass
class PInt(Pattern):
    value: int = 0


@dataclass
class PFloat(Pattern):
    value: float = 0.0


@dataclass
class PString(Pattern):
    value: str = ""


@dataclass
class PBool(Pattern):
    value: bool = False


@dataclass
class PChar(Pattern):
    value: str = ""


@dataclass
class PCon(Pattern):
    name: str = ""
    args: Sequence[Pattern] = ()


@dataclass
class PTuple(Pattern):
    elements: Sequence[Pattern] = ()


@dataclass
class PRecord(Pattern):
    fields: Sequence[tuple[str, Pattern]] = ()
    open: bool = False  # `{ name; .. }` opens up the record


@dataclass
class POr(Pattern):
    options: Sequence[Pattern] = ()


@dataclass
class PAs(Pattern):
    name: str = ""
    inner: Pattern | None = None



@dataclass
class Expr(Node):
    annotation: TypeExpr | None = None


@dataclass
class IntLit(Expr):
    value: int = 0


@dataclass
class FloatLit(Expr):
    value: float = 0.0


@dataclass
class StringLit(Expr):
    value: str = ""


@dataclass
class BoolLit(Expr):
    value: bool = False


@dataclass
class CharLit(Expr):
    value: str = ""


@dataclass
class UnitLit(Expr):
    pass


@dataclass
class Var(Expr):
    name: str = ""
    module: str | None = None


@dataclass
class App(Expr):
    func: Expr | None = None
    args: Sequence[Expr] = ()


@dataclass
class Lambda(Expr):
    params: Sequence[Pattern] = ()
    body: Expr | None = None


@dataclass
class Let(Expr):
    bindings: Sequence["Binding"] = ()
    body: Expr | None = None


@dataclass
class If(Expr):
    cond: Expr | None = None
    then_branch: Expr | None = None
    else_branch: Expr | None = None


@dataclass
class Match(Expr):
    scrutinee: Expr | None = None
    arms: Sequence["MatchArm"] = ()


@dataclass
class Tuple(Expr):
    elements: Sequence[Expr] = ()


@dataclass
class Record(Expr):
    fields: Sequence[tuple[str, Expr]] = ()


@dataclass
class FieldAccess(Expr):
    target: Expr | None = None
    field: str = ""


@dataclass
class BinOp(Expr):
    op: str = ""
    left: Expr | None = None
    right: Expr | None = None


@dataclass
class UnaryOp(Expr):
    op: str = ""
    operand: Expr | None = None


@dataclass
class Annot(Expr):
    expr: Expr | None = None
    target_type: TypeExpr | None = None


@dataclass
class Sequence_(Expr):
    """Statement sequencing: ``a ; b`` -- evaluates a, throws result, then b."""

    statements: Sequence[Expr] = ()



@dataclass
class Binding(Node):
    pattern: Pattern | None = None
    expr: Expr | None = None
    rec: bool = False
    annotation: TypeExpr | None = None


@dataclass
class MatchArm(Node):
    pattern: Pattern | None = None
    guard: Expr | None = None
    body: Expr | None = None



@dataclass
class Decl(Node):
    pass


@dataclass
class LetDecl(Decl):
    bindings: Sequence[Binding] = ()


@dataclass
class TypeDecl(Decl):
    name: str = ""
    params: Sequence[str] = ()
    constructors: Sequence["DataCon"] = ()


@dataclass
class TypeAlias(Decl):
    name: str = ""
    params: Sequence[str] = ()
    body: TypeExpr | None = None


@dataclass
class DataCon(Node):
    name: str = ""
    fields: Sequence[TypeExpr] = ()


@dataclass
class ImportDecl(Decl):
    module: str = ""
    alias: str | None = None
    items: Sequence[str] | None = None


@dataclass
class ExportDecl(Decl):
    items: Sequence[str] = ()


@dataclass
class ExternDecl(Decl):
    name: str = ""
    target_type: TypeExpr | None = None
    primitive: str = ""



@dataclass
class Module(Node):
    name: str = ""
    declarations: Sequence[Decl] = ()
