from __future__ import annotations

from typing import Sequence

from lyra.parser import ast as A


def render_module(module: A.Module) -> str:
    out: list[str] = []
    if module.name and module.name != "main":
        out.append(f"module {module.name}")
    for decl in module.declarations:
        out.append(render_decl(decl))
        out.append("")
    return "\n".join(out).rstrip() + "\n"


def render_decl(decl: A.Decl) -> str:
    if isinstance(decl, A.LetDecl):
        return _render_let(decl.bindings)
    if isinstance(decl, A.TypeDecl):
        params = " " + " ".join(decl.params) if decl.params else ""
        bodies = " | ".join(_render_constructor(c) for c in decl.constructors)
        return f"type {decl.name}{params} = {bodies}"
    if isinstance(decl, A.TypeAlias):
        params = " " + " ".join(decl.params) if decl.params else ""
        body = render_type(decl.body) if decl.body else "?"
        return f"type {decl.name}{params} = {body}"
    if isinstance(decl, A.ImportDecl):
        items = ""
        if decl.items:
            items = " { " + ", ".join(decl.items) + " }"
        alias = f" as {decl.alias}" if decl.alias else ""
        return f"import {decl.module}{items}{alias}"
    if isinstance(decl, A.ExportDecl):
        return "export " + ", ".join(decl.items)
    if isinstance(decl, A.ExternDecl):
        ty = render_type(decl.target_type) if decl.target_type else "?"
        prim = f" = \"{decl.primitive}\"" if decl.primitive else ""
        return f"extern {decl.name} : {ty}{prim}"
    return type(decl).__name__


def render_expr(expr: A.Expr) -> str:
    if isinstance(expr, A.IntLit):
        return str(expr.value)
    if isinstance(expr, A.FloatLit):
        return repr(expr.value)
    if isinstance(expr, A.StringLit):
        return '"' + expr.value.replace('"', '\\"') + '"'
    if isinstance(expr, A.BoolLit):
        return "true" if expr.value else "false"
    if isinstance(expr, A.CharLit):
        return f"'{expr.value}'"
    if isinstance(expr, A.UnitLit):
        return "()"
    if isinstance(expr, A.Var):
        return expr.name
    if isinstance(expr, A.Lambda):
        params = " ".join(_render_pattern(p) for p in expr.params)
        body = render_expr(expr.body) if expr.body else "?"
        return f"fn {params} -> {body}"
    if isinstance(expr, A.App):
        head = render_expr(expr.func) if expr.func else "?"
        args = " ".join(render_expr(a) for a in expr.args)
        return f"{head} {args}"
    if isinstance(expr, A.Let):
        bindings = " and ".join(_render_binding(b) for b in expr.bindings)
        body = render_expr(expr.body) if expr.body else "?"
        return f"let {bindings} in {body}"
    if isinstance(expr, A.If):
        cond = render_expr(expr.cond) if expr.cond else "?"
        then_branch = render_expr(expr.then_branch) if expr.then_branch else "?"
        else_branch = render_expr(expr.else_branch) if expr.else_branch else "?"
        return f"if {cond} then {then_branch} else {else_branch}"
    if isinstance(expr, A.Match):
        scrut = render_expr(expr.scrutinee) if expr.scrutinee else "?"
        arms = ", ".join(_render_match_arm(a) for a in expr.arms)
        return f"match {scrut} {{ {arms} }}"
    if isinstance(expr, A.Tuple):
        return "(" + ", ".join(render_expr(e) for e in expr.elements) + ")"
    if isinstance(expr, A.Record):
        body = ", ".join(f"{n} = {render_expr(v)}" for n, v in expr.fields)
        return "{ " + body + " }"
    if isinstance(expr, A.FieldAccess):
        target = render_expr(expr.target) if expr.target else "?"
        return f"{target}.{expr.field}"
    if isinstance(expr, A.BinOp):
        left = render_expr(expr.left) if expr.left else "?"
        right = render_expr(expr.right) if expr.right else "?"
        return f"({left} {expr.op} {right})"
    if isinstance(expr, A.UnaryOp):
        operand = render_expr(expr.operand) if expr.operand else "?"
        return f"({expr.op}{operand})"
    if isinstance(expr, A.Sequence_):
        return "; ".join(render_expr(s) for s in expr.statements)
    return type(expr).__name__


def render_type(ty: A.TypeExpr | None) -> str:
    if ty is None:
        return "?"
    if isinstance(ty, A.TyVar):
        return ty.name
    if isinstance(ty, A.TyCon):
        if not ty.args:
            return ty.name
        return f"{ty.name} {' '.join(_paren_type(a) for a in ty.args)}"
    if isinstance(ty, A.TyFun):
        params = " -> ".join(_paren_type(p) for p in ty.params)
        return f"{params} -> {render_type(ty.result)}"
    if isinstance(ty, A.TyTuple):
        return "(" + ", ".join(render_type(e) for e in ty.elements) + ")"
    if isinstance(ty, A.TyRecord):
        body = ", ".join(f"{n}: {render_type(v)}" for n, v in ty.fields)
        return "{ " + body + " }"
    if isinstance(ty, A.TyForall):
        bound = " ".join(ty.bound)
        body = render_type(ty.body)
        return f"forall {bound}. {body}"
    return type(ty).__name__



def _render_let(bindings: Sequence[A.Binding]) -> str:
    return "let " + " and ".join(_render_binding(b) for b in bindings)


def _render_binding(binding: A.Binding) -> str:
    pat = _render_pattern(binding.pattern) if binding.pattern else "_"
    body = render_expr(binding.expr) if binding.expr else "?"
    annotation = ""
    if binding.annotation is not None:
        annotation = f" : {render_type(binding.annotation)}"
    rec = "rec " if binding.rec else ""
    return f"{rec}{pat}{annotation} = {body}"


def _render_constructor(con: A.DataCon) -> str:
    if not con.fields:
        return con.name
    return con.name + " " + " ".join(_paren_type(t) for t in con.fields)


def _render_match_arm(arm: A.MatchArm) -> str:
    pattern = _render_pattern(arm.pattern) if arm.pattern else "_"
    body = render_expr(arm.body) if arm.body else "?"
    guard = f" if {render_expr(arm.guard)}" if arm.guard is not None else ""
    return f"{pattern}{guard} -> {body}"


def _render_pattern(pat: A.Pattern | None) -> str:
    if pat is None:
        return "_"
    if isinstance(pat, A.PVar):
        return pat.name
    if isinstance(pat, A.PWild):
        return "_"
    if isinstance(pat, A.PInt):
        return str(pat.value)
    if isinstance(pat, A.PFloat):
        return repr(pat.value)
    if isinstance(pat, A.PString):
        return '"' + pat.value + '"'
    if isinstance(pat, A.PBool):
        return "true" if pat.value else "false"
    if isinstance(pat, A.PChar):
        return f"'{pat.value}'"
    if isinstance(pat, A.PCon):
        if not pat.args:
            return pat.name
        return pat.name + " " + " ".join(_render_pattern(a) for a in pat.args)
    if isinstance(pat, A.PTuple):
        return "(" + ", ".join(_render_pattern(e) for e in pat.elements) + ")"
    if isinstance(pat, A.POr):
        return " | ".join(_render_pattern(o) for o in pat.options)
    if isinstance(pat, A.PAs):
        inner = _render_pattern(pat.inner) if pat.inner else "_"
        return f"{inner} as {pat.name}"
    return type(pat).__name__


def _paren_type(ty: A.TypeExpr) -> str:
    text = render_type(ty)
    if isinstance(ty, (A.TyFun, A.TyForall)):
        return f"({text})"
    return text
