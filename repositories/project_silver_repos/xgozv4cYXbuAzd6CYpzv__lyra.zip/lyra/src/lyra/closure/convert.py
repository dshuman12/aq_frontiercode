from __future__ import annotations

from dataclasses import dataclass

from lyra.ir import nodes as I


def convert(module: I.Module) -> I.Module:
    converter = ClosureConverter(module)
    converter.run()
    return module


@dataclass
class _Scope:
    parameters: set[str]
    locals_: set[str]


class ClosureConverter:
    def __init__(self, module: I.Module) -> None:
        self.module = module
        self.global_names: set[str] = {b.name for b in module.globals_}
        self.global_names.update(fn.label for fn in module.functions if fn.is_top_level)

    def run(self) -> None:
        for func in list(self.module.functions):
            scope = _Scope(parameters=set(func.params), locals_=set())
            free = self._free_in_block(func.body, scope)
            free -= self.global_names
            func.upvalues = sorted(free)

    def _free_in_block(self, block: I.Block | None, scope: _Scope) -> set[str]:
        if block is None:
            return set()
        free: set[str] = set()
        local_scope = _Scope(parameters=set(scope.parameters), locals_=set(scope.locals_))
        for binding in block.bindings:
            free |= self._free_in_expr(binding.expr, local_scope)
            local_scope.locals_.add(binding.name)
        if isinstance(block.result, I.Atom):
            free |= self._free_in_atom(block.result, local_scope)
        elif isinstance(block.result, I.Expr):
            free |= self._free_in_expr(block.result, local_scope)
        return free

    def _free_in_expr(self, expr: I.Expr, scope: _Scope) -> set[str]:
        if isinstance(expr, I.AtomExpr):
            return self._free_in_atom(expr.atom, scope) if expr.atom else set()
        if isinstance(expr, I.CallExpr):
            free: set[str] = set()
            if expr.func is not None:
                free |= self._free_in_atom(expr.func, scope)
            for arg in expr.args:
                free |= self._free_in_atom(arg, scope)
            return free
        if isinstance(expr, I.PrimExpr):
            free = set()
            for arg in expr.args:
                free |= self._free_in_atom(arg, scope)
            return free
        if isinstance(expr, I.AllocExpr):
            free = set()
            for f in expr.fields:
                free |= self._free_in_atom(f, scope)
            return free
        if isinstance(expr, I.GetFieldExpr):
            return self._free_in_atom(expr.target, scope) if expr.target else set()
        if isinstance(expr, I.ClosureExpr):
            free = set()
            for u in expr.upvalues:
                free |= self._free_in_atom(u, scope)
            return free
        if isinstance(expr, I.IfExpr):
            free = self._free_in_atom(expr.cond, scope) if expr.cond else set()
            free |= self._free_in_block(expr.then_block, scope)
            free |= self._free_in_block(expr.else_block, scope)
            return free
        if isinstance(expr, I.MatchTagExpr):
            free = self._free_in_atom(expr.scrutinee, scope) if expr.scrutinee else set()
            for _, b in expr.arms:
                free |= self._free_in_block(b, scope)
            if expr.default is not None:
                free |= self._free_in_block(expr.default, scope)
            return free
        return set()

    def _free_in_atom(self, atom: I.Atom, scope: _Scope) -> set[str]:
        if not isinstance(atom, I.VarAtom):
            return set()
        if atom.name in scope.parameters or atom.name in scope.locals_:
            return set()
        if atom.name in self.global_names:
            return set()
        return {atom.name}
