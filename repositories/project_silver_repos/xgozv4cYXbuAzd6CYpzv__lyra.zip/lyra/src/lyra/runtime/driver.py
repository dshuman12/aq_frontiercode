from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from lyra.bytecode import CompiledModule, decode, encode
from lyra.closure import convert as closure_convert
from lyra.codegen import emit_module
from lyra.lower import lower_module
from lyra.match import TypeOracle, check_match
from lyra.optimize import optimize
from lyra.parser import ast as A
from lyra.parser import parse_module
from lyra.stdlib import install_primitives
from lyra.types import infer_module
from lyra.vm import VM

log = logging.getLogger(__name__)


@dataclass
class CompileResult:
    module: CompiledModule
    types: dict[str, object]


def compile_source(source: str, *, file: str = "<string>") -> CompileResult:
    ast = parse_module(source, file=file)
    types = infer_module(ast)
    _check_match_arms(ast)
    ir = lower_module(ast)
    closure_convert(ir)
    optimize(ir)
    bytecode = emit_module(ir)
    return CompileResult(module=bytecode, types=types)


def compile_file(path: str | Path) -> CompileResult:
    path = Path(path)
    source = path.read_text(encoding="utf-8")
    return compile_source(source, file=str(path))


def write_compiled(path: str | Path, compiled: CompiledModule) -> None:
    Path(path).write_bytes(encode(compiled))


def read_compiled(path: str | Path) -> CompiledModule:
    return decode(Path(path).read_bytes())


def run_compiled(compiled: CompiledModule, *, entry: str = "main") -> object:
    vm = VM(module=compiled)
    install_primitives(vm)
    return vm.run(entry=entry)


def run_source(source: str, *, file: str = "<string>", entry: str = "main") -> object:
    result = compile_source(source, file=file)
    return run_compiled(result.module, entry=entry)



def _check_match_arms(module: A.Module) -> None:
    oracle = TypeOracle()
    for decl in module.declarations:
        if isinstance(decl, A.TypeDecl):
            constructors = [
                _con_descriptor(c) for c in decl.constructors
            ]
            oracle.register(decl.name, constructors)
    for decl in module.declarations:
        _walk_match(decl, oracle)


def _con_descriptor(decl):
    from lyra.match.exhaustive import _Con

    return _Con(decl.name, len(decl.fields))


def _walk_match(decl, oracle: TypeOracle) -> None:
    from lyra.match.exhaustive import check_match

    if isinstance(decl, A.LetDecl):
        for binding in decl.bindings:
            _walk_match_in_expr(binding.expr, oracle)


def _walk_match_in_expr(expr, oracle) -> None:
    if expr is None:
        return
    if isinstance(expr, A.Match):
        check_match(expr.arms, oracle)
        for arm in expr.arms:
            _walk_match_in_expr(arm.body, oracle)
    for slot in ("func", "operand", "left", "right", "expr", "target",
                 "cond", "then_branch", "else_branch", "scrutinee", "body"):
        sub = getattr(expr, slot, None)
        if sub is not None:
            _walk_match_in_expr(sub, oracle)
    for slot in ("args", "elements", "params"):
        items = getattr(expr, slot, None)
        if items is None:
            continue
        for item in items:
            _walk_match_in_expr(item, oracle)
    if isinstance(expr, A.Let):
        for binding in expr.bindings:
            _walk_match_in_expr(binding.expr, oracle)
        _walk_match_in_expr(expr.body, oracle)
