from __future__ import annotations

from dataclasses import dataclass

from lyra.bytecode.format import CompiledModule
from lyra.types.printer import render as render_type
from lyra.types.repr import Type


@dataclass
class ModuleSummary:
    name: str
    function_count: int
    constant_count: int
    import_count: int
    export_names: list[str]
    top_level_types: list[tuple[str, str]]

    def render(self) -> str:
        out: list[str] = [f"module {self.name or '<anon>'}"]
        out.append(f"  functions : {self.function_count}")
        out.append(f"  constants : {self.constant_count}")
        out.append(f"  imports   : {self.import_count}")
        out.append(f"  exports   : {', '.join(self.export_names) or '-'}")
        if self.top_level_types:
            out.append("  bindings:")
            for name, ty in self.top_level_types:
                out.append(f"    {name} : {ty}")
        return "\n".join(out)


def summarise(
    module: CompiledModule,
    *,
    name: str = "",
    types: dict[str, Type] | None = None,
) -> ModuleSummary:
    types = types or {}
    return ModuleSummary(
        name=name,
        function_count=len(module.functions),
        constant_count=len(module.constants),
        import_count=len(module.imports),
        export_names=[n for n, _ in module.exports],
        top_level_types=[(name, render_type(ty)) for name, ty in types.items()],
    )
