from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable

from lyra.parser import ast as A
from lyra.parser.parser import parse_expr, parse_module
from lyra.types import infer_expression, infer_module
from lyra.types.env import TypeEnv, make_initial_env
from lyra.types.repr import Type


@dataclass
class ReplSession:
    type_env: TypeEnv = field(default_factory=make_initial_env)
    bindings: dict[str, Type] = field(default_factory=dict)
    line_counter: int = 0

    def reset(self) -> None:
        self.type_env = make_initial_env()
        self.bindings.clear()
        self.line_counter = 0

    def feed(self, source: str) -> ReplOutcome:
        self.line_counter += 1
        text = source.strip()
        if text.startswith("let "):
            module = parse_module(text)
            types = infer_module(module, env=self.type_env)
            for name, ty in types.items():
                self.bindings[name] = ty
            return ReplOutcome(kind="binding", types=types, names=list(types))
        expr = parse_expr(text)
        ty = infer_expression(expr, env=self.type_env)
        return ReplOutcome(kind="expression", types={"_": ty}, names=["_"])

    def known_names(self) -> Iterable[str]:
        return list(self.bindings.keys())


@dataclass
class ReplOutcome:
    kind: str
    types: dict[str, Type]
    names: list[str]

    @property
    def primary_type(self) -> Type | None:
        return next(iter(self.types.values()), None)
