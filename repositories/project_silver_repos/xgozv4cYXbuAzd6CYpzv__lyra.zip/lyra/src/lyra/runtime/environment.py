from __future__ import annotations

import hashlib
import os
from dataclasses import dataclass, field
from pathlib import Path

from lyra.bytecode.format import CompiledModule


@dataclass
class CacheEntry:
    source_hash: str
    module: CompiledModule


@dataclass
class CompileEnvironment:
    cache: dict[str, CacheEntry] = field(default_factory=dict)

    def get(self, path: Path) -> CompiledModule | None:
        path_str = str(path.resolve())
        entry = self.cache.get(path_str)
        if entry is None:
            return None
        if entry.source_hash != hash_file(path):
            return None
        return entry.module

    def put(self, path: Path, module: CompiledModule) -> None:
        path_str = str(path.resolve())
        self.cache[path_str] = CacheEntry(
            source_hash=hash_file(path),
            module=module,
        )

    def invalidate(self, path: Path) -> None:
        self.cache.pop(str(path.resolve()), None)

    def clear(self) -> None:
        self.cache.clear()


def hash_file(path: Path) -> str:
    return hashlib.blake2b(path.read_bytes(), digest_size=16).hexdigest()


def cache_path(data_dir: str, source: str) -> Path:
    digest = hashlib.blake2b(source.encode("utf-8"), digest_size=8).hexdigest()
    return Path(data_dir) / f"{digest}.lyrac"
