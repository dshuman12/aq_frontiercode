from __future__ import annotations

from dataclasses import dataclass

from lyra.bytecode.format import CompiledModule
from lyra.closure import convert as run_closure_conversion
from lyra.codegen import emit_module as run_codegen
from lyra.ir import Module as IRModule
from lyra.lower import lower_module
from lyra.optimize import optimize as run_optimize
from lyra.parser import parse_module
from lyra.parser.ast import Module as ASTModule
from lyra.resolve import resolve_module
from lyra.types import infer_module
from lyra.types.repr import Type


@dataclass
class StageResult:
    ast: ASTModule
    types: dict[str, Type]
    ir: IRModule
    bytecode: CompiledModule


def lex_and_parse(source: str, *, file: str = "<string>") -> ASTModule:
    return parse_module(source, file=file)


def resolve(ast: ASTModule) -> ASTModule:
    resolve_module(ast)
    return ast


def infer(ast: ASTModule) -> dict[str, Type]:
    return infer_module(ast)


def lower(ast: ASTModule) -> IRModule:
    return lower_module(ast)


def closure(ir: IRModule) -> IRModule:
    run_closure_conversion(ir)
    return ir


def optimise(ir: IRModule) -> IRModule:
    run_optimize(ir)
    return ir


def codegen(ir: IRModule) -> CompiledModule:
    return run_codegen(ir)


def full(source: str, *, file: str = "<string>") -> StageResult:
    ast = lex_and_parse(source, file=file)
    resolve(ast)
    types = infer(ast)
    ir = lower(ast)
    closure(ir)
    optimise(ir)
    bytecode = codegen(ir)
    return StageResult(ast=ast, types=types, ir=ir, bytecode=bytecode)
