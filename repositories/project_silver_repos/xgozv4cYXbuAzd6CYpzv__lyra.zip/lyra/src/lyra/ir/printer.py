from __future__ import annotations

from typing import Sequence

from lyra.ir import nodes as I


def render_module(module: I.Module) -> str:
    out: list[str] = [f"module {module.name or '<anon>'}"]
    if module.imports:
        out.append("imports:")
        for imp in module.imports:
            alias = f" as {imp.alias}" if imp.alias else ""
            items = ""
            if imp.items:
                items = " {" + ", ".join(imp.items) + "}"
            out.append(f"  {imp.module}{alias}{items}")
    if module.type_definitions:
        out.append("types:")
        for td in module.type_definitions:
            cons = " | ".join(f"{c.name}#{c.tag}/{c.arity}" for c in td.constructors)
            out.append(f"  {td.name} = {cons}")
    if module.globals_:
        out.append("globals:")
        for binding in module.globals_:
            out.append(f"  {binding.name} := {render_expr(binding.expr)}")
    out.append("functions:")
    for func in module.functions:
        out.append(render_function(func))
    return "\n".join(out)


def render_function(func: I.Function) -> str:
    head = (
        f"  fn {func.label}"
        f"(params={','.join(func.params) or '-'}; "
        f"upvalues={','.join(func.upvalues) or '-'})"
    )
    if func.body is None:
        return head + "  <no body>"
    return head + "\n" + render_block(func.body, indent=2)


def render_block(block: I.Block, *, indent: int = 0) -> str:
    pad = "  " * indent
    out: list[str] = []
    for binding in block.bindings:
        out.append(f"{pad}let {binding.name} = {render_expr(binding.expr)}")
    if isinstance(block.result, I.Atom):
        out.append(f"{pad}return {render_atom(block.result)}")
    elif isinstance(block.result, I.Expr):
        out.append(f"{pad}return {render_expr(block.result)}")
    return "\n".join(out)


def render_expr(expr: I.Expr) -> str:
    if isinstance(expr, I.AtomExpr):
        return render_atom(expr.atom) if expr.atom else "()"
    if isinstance(expr, I.CallExpr):
        args = ", ".join(render_atom(a) for a in expr.args)
        marker = "tail-call" if expr.is_tail else "call"
        head = render_atom(expr.func) if expr.func else "?"
        return f"{marker}({head}, [{args}])"
    if isinstance(expr, I.PrimExpr):
        args = ", ".join(render_atom(a) for a in expr.args)
        return f"prim({expr.name}, [{args}])"
    if isinstance(expr, I.AllocExpr):
        fields = ", ".join(render_atom(a) for a in expr.fields)
        return f"alloc(class={expr.class_id}, tag={expr.tag}, fields=[{fields}])"
    if isinstance(expr, I.ClosureExpr):
        ups = ", ".join(render_atom(a) for a in expr.upvalues)
        return f"closure({expr.function_label}, upvals=[{ups}])"
    if isinstance(expr, I.GetFieldExpr):
        target = render_atom(expr.target) if expr.target else "?"
        label = expr.field_name or f"#{expr.index}"
        return f"get_field({target}.{label})"
    if isinstance(expr, I.IfExpr):
        cond = render_atom(expr.cond) if expr.cond else "?"
        return f"if({cond}, ...)"
    if isinstance(expr, I.MatchTagExpr):
        scrut = render_atom(expr.scrutinee) if expr.scrutinee else "?"
        arms = ", ".join(f"#{tag}" for tag, _ in expr.arms)
        return f"match_tag({scrut}, [{arms}])"
    return type(expr).__name__


def render_atom(atom: I.Atom | None) -> str:
    if atom is None:
        return "()"
    if isinstance(atom, I.IntAtom):
        return str(atom.value)
    if isinstance(atom, I.FloatAtom):
        return repr(atom.value)
    if isinstance(atom, I.StringAtom):
        return repr(atom.value)
    if isinstance(atom, I.BoolAtom):
        return "true" if atom.value else "false"
    if isinstance(atom, I.CharAtom):
        return f"'{atom.value}'"
    if isinstance(atom, I.UnitAtom):
        return "()"
    if isinstance(atom, I.VarAtom):
        return atom.name
    return type(atom).__name__
