from __future__ import annotations

from dataclasses import dataclass, field
from typing import Sequence

from lyra.errors import Position
from lyra.types.repr import Type


@dataclass
class IR:
    position: Position = field(default_factory=Position, repr=False)



@dataclass
class Atom(IR):
    type: Type | None = None


@dataclass
class IntAtom(Atom):
    value: int = 0


@dataclass
class FloatAtom(Atom):
    value: float = 0.0


@dataclass
class StringAtom(Atom):
    value: str = ""


@dataclass
class BoolAtom(Atom):
    value: bool = False


@dataclass
class CharAtom(Atom):
    value: str = ""


@dataclass
class UnitAtom(Atom):
    pass


@dataclass
class VarAtom(Atom):
    name: str = ""



@dataclass
class Expr(IR):
    type: Type | None = None


@dataclass
class CallExpr(Expr):
    func: Atom | None = None
    args: list[Atom] = field(default_factory=list)
    is_tail: bool = False


@dataclass
class PrimExpr(Expr):
    name: str = ""
    args: list[Atom] = field(default_factory=list)


@dataclass
class AllocExpr(Expr):
    """Allocate a heap object: data constructor, tuple, record, closure."""

    class_id: int = 0
    fields: list[Atom] = field(default_factory=list)
    tag: int = 0
    label: str = ""


@dataclass
class GetFieldExpr(Expr):
    target: Atom | None = None
    index: int = 0
    field_name: str | None = None


@dataclass
class ClosureExpr(Expr):
    function_label: str = ""
    upvalues: list[Atom] = field(default_factory=list)


@dataclass
class IfExpr(Expr):
    cond: Atom | None = None
    then_block: "Block | None" = None
    else_block: "Block | None" = None


@dataclass
class MatchTagExpr(Expr):
    """Branch on a constructor tag.

    The arms are pre-sorted by tag. The default arm is required to be
    reachable iff the type is open or the match is non-exhaustive --
    the exhaustiveness checker rejects the latter, so codegen knows
    the default branch is unreachable when present.
    """

    scrutinee: Atom | None = None
    arms: list[tuple[int, "Block"]] = field(default_factory=list)
    default: "Block | None" = None


@dataclass
class AtomExpr(Expr):
    atom: Atom | None = None



@dataclass
class Binding:
    name: str
    expr: Expr


@dataclass
class Block(IR):
    bindings: list[Binding] = field(default_factory=list)
    result: Atom | Expr | None = None


@dataclass
class Function(IR):
    label: str = ""
    params: list[str] = field(default_factory=list)
    upvalues: list[str] = field(default_factory=list)
    body: Block | None = None
    type: Type | None = None
    is_top_level: bool = False


@dataclass
class Module(IR):
    name: str = ""
    functions: list[Function] = field(default_factory=list)
    globals_: list[Binding] = field(default_factory=list)
    type_definitions: list["TypeDefinition"] = field(default_factory=list)
    imports: list["ImportSpec"] = field(default_factory=list)


@dataclass
class TypeDefinition:
    name: str
    constructors: list["ConstructorSpec"]


@dataclass
class ConstructorSpec:
    name: str
    tag: int
    arity: int


@dataclass
class ImportSpec:
    module: str
    alias: str | None = None
    items: list[str] | None = None
