from __future__ import annotations

import struct
from dataclasses import dataclass, field

from lyra.constants import BYTECODE_MAGIC, BYTECODE_VERSION
from lyra.errors import CorruptModule



CONST_INT = 0x01
CONST_FLOAT = 0x02
CONST_STRING = 0x03
CONST_BOOL = 0x04
CONST_CHAR = 0x05
CONST_UNIT = 0x06


@dataclass
class Constant:
    kind: int
    value: object


@dataclass
class CompiledFunction:
    label: str
    arity: int
    upvalue_count: int
    local_count: int
    code: bytes


@dataclass
class CompiledModule:
    constants: list[Constant] = field(default_factory=list)
    functions: list[CompiledFunction] = field(default_factory=list)
    imports: list[str] = field(default_factory=list)
    exports: list[tuple[str, int]] = field(default_factory=list)
    flags: int = 0



def encode(module: CompiledModule) -> bytes:
    out = bytearray()
    out += BYTECODE_MAGIC
    out += struct.pack("<II", BYTECODE_VERSION, module.flags)
    out += struct.pack("<I", len(module.constants))
    for const in module.constants:
        out += _encode_constant(const)
    out += struct.pack("<I", len(module.functions))
    for fn in module.functions:
        out += _encode_function(fn)
    out += struct.pack("<I", len(module.imports))
    for name in module.imports:
        encoded = name.encode("utf-8")
        out += struct.pack("<H", len(encoded)) + encoded
    out += struct.pack("<I", len(module.exports))
    for name, index in module.exports:
        encoded = name.encode("utf-8")
        out += struct.pack("<H", len(encoded)) + encoded + struct.pack("<I", index)
    return bytes(out)


def _encode_constant(const: Constant) -> bytes:
    if const.kind == CONST_INT:
        return bytes([CONST_INT]) + struct.pack("<q", const.value)  # type: ignore[arg-type]
    if const.kind == CONST_FLOAT:
        return bytes([CONST_FLOAT]) + struct.pack("<d", const.value)  # type: ignore[arg-type]
    if const.kind == CONST_BOOL:
        return bytes([CONST_BOOL, 1 if const.value else 0])
    if const.kind == CONST_UNIT:
        return bytes([CONST_UNIT])
    if const.kind == CONST_CHAR:
        encoded = str(const.value).encode("utf-8")
        return bytes([CONST_CHAR, len(encoded)]) + encoded
    if const.kind == CONST_STRING:
        encoded = str(const.value).encode("utf-8")
        return bytes([CONST_STRING]) + struct.pack("<I", len(encoded)) + encoded
    raise CorruptModule(f"unknown constant kind: {const.kind}")


def _encode_function(fn: CompiledFunction) -> bytes:
    label = fn.label.encode("utf-8")
    return (
        struct.pack("<H", len(label))
        + label
        + bytes([fn.arity, fn.upvalue_count, fn.local_count])
        + struct.pack("<I", len(fn.code))
        + fn.code
    )



def decode(blob: bytes) -> CompiledModule:
    if blob[: len(BYTECODE_MAGIC)] != BYTECODE_MAGIC:
        raise CorruptModule(f"bad magic: {blob[:len(BYTECODE_MAGIC)]!r}")
    cursor = len(BYTECODE_MAGIC)
    (version, flags) = struct.unpack_from("<II", blob, cursor)
    cursor += 8
    if version != BYTECODE_VERSION:
        raise CorruptModule(f"unsupported version {version}")
    (const_count,) = struct.unpack_from("<I", blob, cursor); cursor += 4
    constants: list[Constant] = []
    for _ in range(const_count):
        const, cursor = _decode_constant(blob, cursor)
        constants.append(const)
    (fn_count,) = struct.unpack_from("<I", blob, cursor); cursor += 4
    functions: list[CompiledFunction] = []
    for _ in range(fn_count):
        fn, cursor = _decode_function(blob, cursor)
        functions.append(fn)
    (import_count,) = struct.unpack_from("<I", blob, cursor); cursor += 4
    imports: list[str] = []
    for _ in range(import_count):
        (n,) = struct.unpack_from("<H", blob, cursor); cursor += 2
        imports.append(blob[cursor: cursor + n].decode("utf-8"))
        cursor += n
    (export_count,) = struct.unpack_from("<I", blob, cursor); cursor += 4
    exports: list[tuple[str, int]] = []
    for _ in range(export_count):
        (n,) = struct.unpack_from("<H", blob, cursor); cursor += 2
        name = blob[cursor: cursor + n].decode("utf-8"); cursor += n
        (idx,) = struct.unpack_from("<I", blob, cursor); cursor += 4
        exports.append((name, idx))
    return CompiledModule(
        constants=constants, functions=functions,
        imports=imports, exports=exports, flags=flags,
    )


def _decode_constant(blob: bytes, cursor: int) -> tuple[Constant, int]:
    kind = blob[cursor]; cursor += 1
    if kind == CONST_INT:
        (value,) = struct.unpack_from("<q", blob, cursor); cursor += 8
        return Constant(kind=kind, value=value), cursor
    if kind == CONST_FLOAT:
        (value,) = struct.unpack_from("<d", blob, cursor); cursor += 8
        return Constant(kind=kind, value=value), cursor
    if kind == CONST_BOOL:
        return Constant(kind=kind, value=bool(blob[cursor])), cursor + 1
    if kind == CONST_UNIT:
        return Constant(kind=kind, value=None), cursor
    if kind == CONST_CHAR:
        n = blob[cursor]; cursor += 1
        text = blob[cursor: cursor + n].decode("utf-8"); cursor += n
        return Constant(kind=kind, value=text), cursor
    if kind == CONST_STRING:
        (n,) = struct.unpack_from("<I", blob, cursor); cursor += 4
        text = blob[cursor: cursor + n].decode("utf-8"); cursor += n
        return Constant(kind=kind, value=text), cursor
    raise CorruptModule(f"unknown constant kind: 0x{kind:02x}")


def _decode_function(blob: bytes, cursor: int) -> tuple[CompiledFunction, int]:
    (label_len,) = struct.unpack_from("<H", blob, cursor); cursor += 2
    label = blob[cursor: cursor + label_len].decode("utf-8"); cursor += label_len
    arity = blob[cursor]; cursor += 1
    upvalues = blob[cursor]; cursor += 1
    locals_ = blob[cursor]; cursor += 1
    (code_len,) = struct.unpack_from("<I", blob, cursor); cursor += 4
    code = bytes(blob[cursor: cursor + code_len]); cursor += code_len
    return (
        CompiledFunction(
            label=label, arity=arity, upvalue_count=upvalues,
            local_count=locals_, code=code,
        ),
        cursor,
    )
