from __future__ import annotations

import struct
from typing import Iterable

from lyra.bytecode.format import CompiledFunction, CompiledModule
from lyra.constants import (
    OP_ALLOC,
    OP_CALL,
    OP_DUP,
    OP_END_TRY,
    OP_GET_FIELD,
    OP_HALT,
    OP_JUMP,
    OP_JUMP_IF_FALSE,
    OP_JUMP_IF_TRUE,
    OP_LOAD_CONST,
    OP_LOAD_GLOBAL,
    OP_LOAD_LOCAL,
    OP_LOAD_TAG,
    OP_LOAD_UPVAL,
    OP_MAKE_CLOSURE,
    OP_MATCH_TAG,
    OP_NOP,
    OP_POP,
    OP_PRIM,
    OP_RETURN,
    OP_SET_FIELD,
    OP_STORE_GLOBAL,
    OP_STORE_LOCAL,
    OP_TAIL_CALL,
    OP_THROW,
    OP_TRY,
)


_OPCODE_NAMES = {
    OP_NOP: "NOP",
    OP_LOAD_CONST: "LOAD_CONST",
    OP_LOAD_LOCAL: "LOAD_LOCAL",
    OP_STORE_LOCAL: "STORE_LOCAL",
    OP_LOAD_UPVAL: "LOAD_UPVAL",
    OP_LOAD_GLOBAL: "LOAD_GLOBAL",
    OP_STORE_GLOBAL: "STORE_GLOBAL",
    OP_POP: "POP",
    OP_DUP: "DUP",
    OP_CALL: "CALL",
    OP_TAIL_CALL: "TAIL_CALL",
    OP_RETURN: "RETURN",
    OP_MAKE_CLOSURE: "MAKE_CLOSURE",
    OP_JUMP: "JUMP",
    OP_JUMP_IF_FALSE: "JUMP_IF_FALSE",
    OP_JUMP_IF_TRUE: "JUMP_IF_TRUE",
    OP_MATCH_TAG: "MATCH_TAG",
    OP_THROW: "THROW",
    OP_TRY: "TRY",
    OP_END_TRY: "END_TRY",
    OP_ALLOC: "ALLOC",
    OP_GET_FIELD: "GET_FIELD",
    OP_SET_FIELD: "SET_FIELD",
    OP_LOAD_TAG: "LOAD_TAG",
    OP_PRIM: "PRIM",
    OP_HALT: "HALT",
}


_OPS_WITH_OPERAND = frozenset(
    {
        OP_LOAD_CONST,
        OP_LOAD_LOCAL,
        OP_STORE_LOCAL,
        OP_LOAD_UPVAL,
        OP_LOAD_GLOBAL,
        OP_STORE_GLOBAL,
        OP_CALL,
        OP_TAIL_CALL,
        OP_MAKE_CLOSURE,
        OP_JUMP,
        OP_JUMP_IF_FALSE,
        OP_JUMP_IF_TRUE,
        OP_MATCH_TAG,
        OP_ALLOC,
        OP_GET_FIELD,
        OP_SET_FIELD,
        OP_PRIM,
    }
)


def disassemble_function(fn: CompiledFunction) -> str:
    out = [
        f"function {fn.label} (arity={fn.arity}, "
        f"upvalues={fn.upvalue_count}, locals={fn.local_count})"
    ]
    cursor = 0
    code = fn.code
    while cursor < len(code):
        op = code[cursor]
        if op in _OPS_WITH_OPERAND and cursor + 3 <= len(code):
            (operand,) = struct.unpack_from("<H", code, cursor + 1)
            out.append(f"  {cursor:04d}  {_OPCODE_NAMES.get(op, '???'):<14} {operand}")
            cursor += 3
        else:
            out.append(f"  {cursor:04d}  {_OPCODE_NAMES.get(op, '???')}")
            cursor += 1
    return "\n".join(out)


def disassemble_module(module: CompiledModule) -> str:
    out: list[str] = []
    out.append("constants:")
    for i, const in enumerate(module.constants):
        out.append(f"  [{i}] kind=0x{const.kind:02x} value={const.value!r}")
    if module.imports:
        out.append("imports:")
        for name in module.imports:
            out.append(f"  {name}")
    if module.exports:
        out.append("exports:")
        for name, idx in module.exports:
            out.append(f"  {name} -> #{idx}")
    out.append("functions:")
    for fn in module.functions:
        out.append(disassemble_function(fn))
    return "\n".join(out)
