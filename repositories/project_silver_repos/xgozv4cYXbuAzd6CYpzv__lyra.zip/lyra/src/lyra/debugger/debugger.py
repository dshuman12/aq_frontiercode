from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Callable

from lyra.bytecode.disasm import disassemble_function
from lyra.errors import LyraError
from lyra.objects.model import value_repr
from lyra.vm import VM

log = logging.getLogger(__name__)


@dataclass
class Breakpoint:
    function_label: str
    offset: int
    hit_count: int = 0


@dataclass
class Debugger:
    vm: VM
    breakpoints: list[Breakpoint] = field(default_factory=list)
    on_break: Callable[["DebuggerState"], None] | None = None
    step_mode: bool = False

    def add_breakpoint(self, label: str, offset: int) -> Breakpoint:
        bp = Breakpoint(function_label=label, offset=offset)
        self.breakpoints.append(bp)
        return bp

    def remove_breakpoint(self, bp: Breakpoint) -> None:
        if bp in self.breakpoints:
            self.breakpoints.remove(bp)

    def list_breakpoints(self) -> list[Breakpoint]:
        return list(self.breakpoints)

    def run(self, *, entry: str = "main") -> object:
        # Drive the VM one instruction at a time.
        self.vm.stack.push(self.vm._make_frame(  # type: ignore[attr-defined]
            self.vm._lookup_function(entry),  # type: ignore[attr-defined]
            args=[], upvalues=[],
        ))
        try:
            while self.vm.stack.frames:
                frame = self.vm.stack.current()
                if frame is None:
                    break
                if self._should_break(frame.function.label, frame.pc):
                    self._fire_break(frame)
                if frame.pc >= len(frame.function.code):
                    self.vm.stack.pop()
                    if self.vm.stack.frames:
                        self.vm.stack.current().push(None)  # type: ignore[union-attr]
                    continue
                opcode = frame.fetch_byte()
                self.vm._execute(frame, opcode)  # type: ignore[attr-defined]
        except LyraError:
            raise
        return getattr(self.vm, "_final_value", None)

    def step_over(self) -> None:
        self.step_mode = True

    def disassemble_current(self) -> str:
        frame = self.vm.stack.current()
        if frame is None:
            return "(no active frame)"
        return disassemble_function(frame.function)

    def dump_locals(self) -> str:
        frame = self.vm.stack.current()
        if frame is None:
            return "(no active frame)"
        out: list[str] = []
        for i, value in enumerate(frame.locals_):
            out.append(f"  [{i}] = {value_repr(value)}")
        return "\n".join(out)

    def dump_stack(self) -> str:
        return "\n".join(self.vm.stack.walk())

    def _should_break(self, label: str, pc: int) -> bool:
        if self.step_mode:
            self.step_mode = False
            return True
        for bp in self.breakpoints:
            if bp.function_label == label and bp.offset == pc:
                bp.hit_count += 1
                return True
        return False

    def _fire_break(self, frame) -> None:
        state = DebuggerState(
            function=frame.function.label, pc=frame.pc,
            locals_count=len(frame.locals_),
        )
        if self.on_break:
            self.on_break(state)


@dataclass
class DebuggerState:
    function: str
    pc: int
    locals_count: int
