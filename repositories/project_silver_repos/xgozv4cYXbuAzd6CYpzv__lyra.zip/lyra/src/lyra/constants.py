from __future__ import annotations

from typing import Final

BYTECODE_MAGIC: Final[bytes] = b"LYRA0001"
BYTECODE_VERSION: Final[int] = 1
MAX_LOCALS: Final[int] = 256
MAX_UPVALUES: Final[int] = 64
MAX_ARGUMENTS: Final[int] = 64
MAX_DATA_FIELDS: Final[int] = 32
MAX_OPERAND: Final[int] = 0xFFFF

OP_NOP: Final[int] = 0x00
OP_LOAD_CONST: Final[int] = 0x01
OP_LOAD_LOCAL: Final[int] = 0x02
OP_STORE_LOCAL: Final[int] = 0x03
OP_LOAD_UPVAL: Final[int] = 0x04
OP_LOAD_GLOBAL: Final[int] = 0x05
OP_STORE_GLOBAL: Final[int] = 0x06
OP_POP: Final[int] = 0x07
OP_DUP: Final[int] = 0x08

OP_CALL: Final[int] = 0x10
OP_TAIL_CALL: Final[int] = 0x11
OP_RETURN: Final[int] = 0x12
OP_MAKE_CLOSURE: Final[int] = 0x13

OP_JUMP: Final[int] = 0x20
OP_JUMP_IF_FALSE: Final[int] = 0x21
OP_JUMP_IF_TRUE: Final[int] = 0x22
OP_MATCH_TAG: Final[int] = 0x23
OP_THROW: Final[int] = 0x24
OP_TRY: Final[int] = 0x25
OP_END_TRY: Final[int] = 0x26

OP_ALLOC: Final[int] = 0x30
OP_GET_FIELD: Final[int] = 0x31
OP_SET_FIELD: Final[int] = 0x32
OP_LOAD_TAG: Final[int] = 0x33

OP_PRIM: Final[int] = 0x40  # call into the standard library

OP_HALT: Final[int] = 0xFF

# Tag bits packed into the low bit of every value: 1 means "tagged int"
# (the rest is a 63-bit signed int); 0 means "boxed" (pointer to a
# heap object).
TAG_INT_BIT: Final[int] = 1
INT_TAG_SHIFT: Final[int] = 1
MAX_TAGGED_INT: Final[int] = (1 << 62) - 1
MIN_TAGGED_INT: Final[int] = -(1 << 62)

# Object class IDs stored in the header byte.
CLASS_CLOSURE: Final[int] = 0x01
CLASS_DATA: Final[int] = 0x02
CLASS_STRING: Final[int] = 0x03
CLASS_FLOAT: Final[int] = 0x04
CLASS_BIGINT: Final[int] = 0x05
CLASS_TUPLE: Final[int] = 0x06
CLASS_LIST: Final[int] = 0x07
CLASS_MAP: Final[int] = 0x08
CLASS_RECORD: Final[int] = 0x09
CLASS_FOREIGN: Final[int] = 0x0A

DEFAULT_YOUNG_BYTES: Final[int] = 4 * 1024 * 1024  # 4 MiB
DEFAULT_OLD_BYTES: Final[int] = 32 * 1024 * 1024
DEFAULT_PROMOTION_AGE: Final[int] = 2
GC_HEADER_SIZE: Final[int] = 16  # bytes per heap object

INITIAL_GENERATION_LEVEL: Final[int] = 0
MAX_TYPE_VAR_LEVEL: Final[int] = 1024

MAX_IDENTIFIER_LEN: Final[int] = 128
MAX_TYPE_NAME_LEN: Final[int] = 128
MAX_MODULE_NAME_LEN: Final[int] = 128

DEFAULT_INITIAL_STACK: Final[int] = 1024
DEFAULT_MAX_STACK: Final[int] = 64 * 1024
DEFAULT_REPL_HISTORY: Final[str] = "~/.lyra_history"

from lyra.bytecode.format import (
    CONST_BOOL,
    CONST_CHAR,
    CONST_FLOAT,
    CONST_INT,
    CONST_STRING,
    CONST_UNIT,
)
