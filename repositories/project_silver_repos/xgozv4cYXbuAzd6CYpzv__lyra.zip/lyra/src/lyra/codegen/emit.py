from __future__ import annotations

import struct
from dataclasses import dataclass, field

from lyra.bytecode.format import (
    CONST_BOOL,
    CONST_CHAR,
    CONST_FLOAT,
    CONST_INT,
    CONST_STRING,
    CONST_UNIT,
    CompiledFunction,
    CompiledModule,
    Constant,
)
from lyra.constants import (
    OP_ALLOC,
    OP_CALL,
    OP_GET_FIELD,
    OP_HALT,
    OP_JUMP,
    OP_JUMP_IF_FALSE,
    OP_LOAD_CONST,
    OP_LOAD_GLOBAL,
    OP_LOAD_LOCAL,
    OP_LOAD_UPVAL,
    OP_MAKE_CLOSURE,
    OP_MATCH_TAG,
    OP_POP,
    OP_PRIM,
    OP_RETURN,
    OP_STORE_LOCAL,
    OP_TAIL_CALL,
)
from lyra.errors import CodegenError
from lyra.ir import nodes as I


@dataclass
class _FunctionState:
    label: str
    locals_: dict[str, int] = field(default_factory=dict)
    code: bytearray = field(default_factory=bytearray)
    constants: list[Constant] = field(default_factory=list)


class Emitter:
    def __init__(self) -> None:
        self.constants: list[Constant] = []
        self.functions: list[CompiledFunction] = []
        self.function_index: dict[str, int] = {}

    def emit_module(self, module: I.Module) -> CompiledModule:
        # Pre-register every function label so calls can reference them.
        for i, fn in enumerate(module.functions):
            self.function_index[fn.label] = i
        # Compile each function.
        for fn in module.functions:
            self.functions.append(self._emit_function(fn))
        # Globals: emit a synthetic "@module_init" function whose body
        # runs the global bindings in declaration order.
        if module.globals_:
            self.functions.append(self._emit_init(module))
        exports = [(fn.label, i) for i, fn in enumerate(self.functions)]
        return CompiledModule(
            constants=list(self.constants),
            functions=list(self.functions),
            imports=[imp.module for imp in module.imports],
            exports=exports,
        )

    def _emit_function(self, fn: I.Function) -> CompiledFunction:
        state = _FunctionState(label=fn.label)
        for i, p in enumerate(fn.params):
            state.locals_[p] = i
        for i, u in enumerate(fn.upvalues):
            # Upvalues live in their own table; we simulate via locals.
            state.locals_[u] = len(state.locals_)
        if fn.body is not None:
            self._emit_block(state, fn.body, tail=True)
        else:
            state.code.append(OP_HALT)
        return CompiledFunction(
            label=fn.label,
            arity=len(fn.params),
            upvalue_count=len(fn.upvalues),
            local_count=len(state.locals_),
            code=bytes(state.code),
        )

    def _emit_init(self, module: I.Module) -> CompiledFunction:
        state = _FunctionState(label="@module_init")
        for binding in module.globals_:
            self._emit_expr(state, binding.expr)
            slot = self._define_local(state, binding.name)
            self._emit_op_with_arg(state, OP_STORE_LOCAL, slot)
        # Push a unit constant and return.
        state.code.append(OP_LOAD_CONST)
        state.code += struct.pack("<H", self._add_constant(Constant(kind=CONST_UNIT, value=None)))
        state.code.append(OP_RETURN)
        return CompiledFunction(
            label="@module_init", arity=0, upvalue_count=0,
            local_count=len(state.locals_), code=bytes(state.code),
        )

    def _emit_block(self, state: _FunctionState, block: I.Block, *, tail: bool) -> None:
        for binding in block.bindings:
            self._emit_expr(state, binding.expr)
            slot = self._define_local(state, binding.name)
            self._emit_op_with_arg(state, OP_STORE_LOCAL, slot)
        if isinstance(block.result, I.Atom):
            self._emit_atom(state, block.result)
        elif isinstance(block.result, I.Expr):
            self._emit_expr(state, block.result)
        else:
            state.code.append(OP_LOAD_CONST)
            state.code += struct.pack(
                "<H", self._add_constant(Constant(kind=CONST_UNIT, value=None)),
            )
        if tail:
            state.code.append(OP_RETURN)

    def _emit_expr(self, state: _FunctionState, expr: I.Expr) -> None:
        if isinstance(expr, I.AtomExpr):
            if expr.atom is not None:
                self._emit_atom(state, expr.atom)
            return
        if isinstance(expr, I.CallExpr):
            for arg in expr.args:
                self._emit_atom(state, arg)
            if expr.func is not None:
                self._emit_atom(state, expr.func)
            opcode = OP_TAIL_CALL if expr.is_tail else OP_CALL
            self._emit_op_with_arg(state, opcode, len(expr.args))
            return
        if isinstance(expr, I.PrimExpr):
            for arg in expr.args:
                self._emit_atom(state, arg)
            self._emit_op_with_arg(state, OP_PRIM, _prim_index(expr.name))
            return
        if isinstance(expr, I.AllocExpr):
            for f in expr.fields:
                self._emit_atom(state, f)
            self._emit_op_with_arg(state, OP_ALLOC, expr.tag * 256 + expr.class_id)
            return
        if isinstance(expr, I.GetFieldExpr):
            if expr.target is not None:
                self._emit_atom(state, expr.target)
            self._emit_op_with_arg(state, OP_GET_FIELD, max(expr.index, 0))
            return
        if isinstance(expr, I.ClosureExpr):
            for u in expr.upvalues:
                self._emit_atom(state, u)
            idx = self.function_index.get(expr.function_label, 0)
            self._emit_op_with_arg(state, OP_MAKE_CLOSURE, idx)
            return
        if isinstance(expr, I.IfExpr):
            self._emit_if(state, expr)
            return
        if isinstance(expr, I.MatchTagExpr):
            self._emit_match(state, expr)
            return
        raise CodegenError(f"cannot emit expression: {type(expr).__name__}")

    def _emit_atom(self, state: _FunctionState, atom: I.Atom) -> None:
        if isinstance(atom, I.IntAtom):
            self._emit_op_with_arg(
                state, OP_LOAD_CONST,
                self._add_constant(Constant(kind=CONST_INT, value=atom.value)),
            )
        elif isinstance(atom, I.FloatAtom):
            self._emit_op_with_arg(
                state, OP_LOAD_CONST,
                self._add_constant(Constant(kind=CONST_FLOAT, value=atom.value)),
            )
        elif isinstance(atom, I.StringAtom):
            self._emit_op_with_arg(
                state, OP_LOAD_CONST,
                self._add_constant(Constant(kind=CONST_STRING, value=atom.value)),
            )
        elif isinstance(atom, I.BoolAtom):
            self._emit_op_with_arg(
                state, OP_LOAD_CONST,
                self._add_constant(Constant(kind=CONST_BOOL, value=atom.value)),
            )
        elif isinstance(atom, I.CharAtom):
            self._emit_op_with_arg(
                state, OP_LOAD_CONST,
                self._add_constant(Constant(kind=CONST_CHAR, value=atom.value)),
            )
        elif isinstance(atom, I.UnitAtom):
            self._emit_op_with_arg(
                state, OP_LOAD_CONST,
                self._add_constant(Constant(kind=CONST_UNIT, value=None)),
            )
        elif isinstance(atom, I.VarAtom):
            slot = state.locals_.get(atom.name)
            if slot is not None:
                self._emit_op_with_arg(state, OP_LOAD_LOCAL, slot)
            else:
                # Fall back to a global/upvalue lookup; the runtime
                # disambiguates via a side table in practice.
                self._emit_op_with_arg(
                    state, OP_LOAD_GLOBAL,
                    self._add_constant(Constant(kind=CONST_STRING, value=atom.name)),
                )
        else:
            raise CodegenError(f"unknown atom type: {type(atom).__name__}")

    def _emit_if(self, state: _FunctionState, expr: I.IfExpr) -> None:
        if expr.cond is not None:
            self._emit_atom(state, expr.cond)
        # Reserve a JUMP_IF_FALSE; patch later.
        jump_to_else = len(state.code)
        state.code.append(OP_JUMP_IF_FALSE)
        state.code += b"\x00\x00"
        if expr.then_block is not None:
            self._emit_block(state, expr.then_block, tail=False)
        # Skip past the else.
        jump_to_end = len(state.code)
        state.code.append(OP_JUMP)
        state.code += b"\x00\x00"
        # Patch the false-branch jump.
        else_target = len(state.code)
        struct.pack_into("<H", state.code, jump_to_else + 1, else_target)
        if expr.else_block is not None:
            self._emit_block(state, expr.else_block, tail=False)
        end_target = len(state.code)
        struct.pack_into("<H", state.code, jump_to_end + 1, end_target)

    def _emit_match(self, state: _FunctionState, expr: I.MatchTagExpr) -> None:
        if expr.scrutinee is not None:
            self._emit_atom(state, expr.scrutinee)
        # Encode arms as a chain of comparisons. The MATCH_TAG opcode
        # takes a tag operand and pops the scrutinee on a match.
        end_jumps: list[int] = []
        for tag, body in expr.arms:
            self._emit_op_with_arg(state, OP_MATCH_TAG, tag)
            jump_no_match = len(state.code)
            state.code.append(OP_JUMP_IF_FALSE)
            state.code += b"\x00\x00"
            self._emit_block(state, body, tail=False)
            end_jumps.append(len(state.code))
            state.code.append(OP_JUMP)
            state.code += b"\x00\x00"
            patch_target = len(state.code)
            struct.pack_into("<H", state.code, jump_no_match + 1, patch_target)
        if expr.default is not None:
            self._emit_block(state, expr.default, tail=False)
        end = len(state.code)
        for jump in end_jumps:
            struct.pack_into("<H", state.code, jump + 1, end)

    def _emit_op_with_arg(self, state: _FunctionState, op: int, arg: int) -> None:
        if not 0 <= arg <= 0xFFFF:
            raise CodegenError(f"operand 0x{arg:x} out of range")
        state.code.append(op)
        state.code += struct.pack("<H", arg)

    def _define_local(self, state: _FunctionState, name: str) -> int:
        if name in state.locals_:
            return state.locals_[name]
        slot = len(state.locals_)
        state.locals_[name] = slot
        return slot

    def _add_constant(self, const: Constant) -> int:
        for i, existing in enumerate(self.constants):
            if existing.kind == const.kind and existing.value == const.value:
                return i
        self.constants.append(const)
        return len(self.constants) - 1


_PRIM_INDEX: dict[str, int] = {
    "int_add": 0x01, "int_sub": 0x02, "int_mul": 0x03, "int_div": 0x04, "int_mod": 0x05,
    "int_neg": 0x06,
    "eq": 0x10, "ne": 0x11, "lt": 0x12, "le": 0x13, "gt": 0x14, "ge": 0x15,
    "bool_and": 0x20, "bool_or": 0x21, "bool_not": 0x22,
    "string_concat": 0x30, "string_length": 0x31,
    "print": 0x40, "println": 0x41, "read_line": 0x42,
    "list_cons": 0x50, "list_head": 0x51, "list_tail": 0x52, "list_is_empty": 0x53,
    "panic": 0xF0, "assert": 0xF1,
}


def _prim_index(name: str) -> int:
    if name not in _PRIM_INDEX:
        raise CodegenError(f"unknown primitive {name!r}")
    return _PRIM_INDEX[name]


def emit_module(module: I.Module) -> CompiledModule:
    return Emitter().emit_module(module)
