from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from lyra.bytecode.format import CompiledFunction
from lyra.objects.model import Value


@dataclass
class Frame:
    function: CompiledFunction
    locals_: list[Value] = field(default_factory=list)
    upvalues: list[Value] = field(default_factory=list)
    eval_stack: list[Value] = field(default_factory=list)
    pc: int = 0
    parent: "Frame | None" = None
    return_pc: int = 0  # where to resume the caller

    def push(self, value: Value) -> None:
        self.eval_stack.append(value)

    def pop(self) -> Value:
        return self.eval_stack.pop()

    def peek(self, depth: int = 0) -> Value:
        return self.eval_stack[-1 - depth]

    def fetch_byte(self) -> int:
        b = self.function.code[self.pc]
        self.pc += 1
        return b

    def fetch_u16(self) -> int:
        code = self.function.code
        value = code[self.pc] | (code[self.pc + 1] << 8)
        self.pc += 2
        return value

    def jump(self, target: int) -> None:
        self.pc = target


@dataclass
class CallStack:
    """Stack of frames; helpers for tail-call reuse + stack walking."""

    frames: list[Frame] = field(default_factory=list)

    def current(self) -> Frame | None:
        return self.frames[-1] if self.frames else None

    def push(self, frame: Frame) -> None:
        self.frames.append(frame)

    def pop(self) -> Frame:
        return self.frames.pop()

    def replace_top(self, frame: Frame) -> None:
        if not self.frames:
            self.frames.append(frame)
            return
        self.frames[-1] = frame

    def depth(self) -> int:
        return len(self.frames)

    def walk(self) -> list[str]:
        """Return labels of all frames, deepest first."""
        return [f.function.label for f in reversed(self.frames)]
