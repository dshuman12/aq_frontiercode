from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Callable

from lyra.bytecode.format import CompiledFunction, CompiledModule, Constant
from lyra.constants import (
    CLASS_CLOSURE,
    CONST_BOOL,
    CONST_CHAR,
    CONST_FLOAT,
    CONST_INT,
    CONST_STRING,
    CONST_UNIT,
    OP_ALLOC,
    OP_CALL,
    OP_DUP,
    OP_GET_FIELD,
    OP_HALT,
    OP_JUMP,
    OP_JUMP_IF_FALSE,
    OP_JUMP_IF_TRUE,
    OP_LOAD_CONST,
    OP_LOAD_GLOBAL,
    OP_LOAD_LOCAL,
    OP_LOAD_UPVAL,
    OP_MAKE_CLOSURE,
    OP_MATCH_TAG,
    OP_NOP,
    OP_POP,
    OP_PRIM,
    OP_RETURN,
    OP_STORE_GLOBAL,
    OP_STORE_LOCAL,
    OP_TAIL_CALL,
)
from lyra.errors import (
    BytecodeError,
    StackOverflow,
    TailCallOverflow,
    TypeMismatchAtRuntime,
    UncaughtUserException,
)
from lyra.gc.generational import GenerationalGC
from lyra.objects.model import (
    Box,
    Value,
    alloc_closure,
    alloc_data,
    alloc_string,
    alloc_tuple,
)
from lyra.vm.frame import CallStack, Frame

log = logging.getLogger(__name__)


@dataclass
class VM:
    module: CompiledModule
    stack: CallStack = field(default_factory=CallStack)
    globals_: dict[str, Value] = field(default_factory=dict)
    gc: GenerationalGC = field(default_factory=GenerationalGC)
    primitives: dict[int, Callable[..., Value]] = field(default_factory=dict)
    max_call_depth: int = 1024

    def __post_init__(self) -> None:
        self.gc.root_provider = self._iter_roots

    def run(self, entry: str = "main") -> Value:
        # Locate entry function.
        index = next(
            (i for i, fn in enumerate(self.module.functions) if fn.label == entry),
            None,
        )
        if index is None:
            raise BytecodeError(f"entry function {entry!r} not found")
        frame = self._make_frame(self.module.functions[index], args=[], upvalues=[])
        self.stack.push(frame)
        return self._loop()

    def _loop(self) -> Value:
        while self.stack.frames:
            frame = self.stack.current()
            if frame is None:
                break
            if frame.pc >= len(frame.function.code):
                # Implicit return -- push unit, drop the frame.
                value: Value = None
                self.stack.pop()
                if self.stack.frames:
                    self.stack.current().push(value)  # type: ignore[union-attr]
                else:
                    return value
                continue
            opcode = frame.fetch_byte()
            value = self._execute(frame, opcode)
            if value is _RETURN:
                break
        return self._return_value()

    def _execute(self, frame: Frame, opcode: int) -> object:
        if opcode == OP_NOP:
            return None
        if opcode == OP_LOAD_CONST:
            idx = frame.fetch_u16()
            frame.push(_const_to_value(self.module.constants[idx]))
            return None
        if opcode == OP_LOAD_LOCAL:
            slot = frame.fetch_u16()
            frame.push(frame.locals_[slot])
            return None
        if opcode == OP_STORE_LOCAL:
            slot = frame.fetch_u16()
            value = frame.pop()
            while len(frame.locals_) <= slot:
                frame.locals_.append(None)
            frame.locals_[slot] = value
            return None
        if opcode == OP_LOAD_UPVAL:
            slot = frame.fetch_u16()
            frame.push(frame.upvalues[slot])
            return None
        if opcode == OP_LOAD_GLOBAL:
            name_index = frame.fetch_u16()
            name_const = self.module.constants[name_index]
            if name_const.kind != CONST_STRING:
                raise BytecodeError("LOAD_GLOBAL operand must reference a string")
            value = self.globals_.get(name_const.value)  # type: ignore[arg-type]
            frame.push(value)
            return None
        if opcode == OP_STORE_GLOBAL:
            name_index = frame.fetch_u16()
            name_const = self.module.constants[name_index]
            if name_const.kind != CONST_STRING:
                raise BytecodeError("STORE_GLOBAL operand must reference a string")
            self.globals_[name_const.value] = frame.pop()  # type: ignore[index]
            return None
        if opcode == OP_POP:
            frame.pop()
            return None
        if opcode == OP_DUP:
            frame.push(frame.peek())
            return None
        if opcode == OP_JUMP:
            frame.jump(frame.fetch_u16())
            return None
        if opcode == OP_JUMP_IF_FALSE:
            target = frame.fetch_u16()
            value = frame.pop()
            if not _truthy(value):
                frame.jump(target)
            return None
        if opcode == OP_JUMP_IF_TRUE:
            target = frame.fetch_u16()
            value = frame.pop()
            if _truthy(value):
                frame.jump(target)
            return None
        if opcode == OP_CALL:
            arg_count = frame.fetch_u16()
            return self._call(frame, arg_count, tail=False)
        if opcode == OP_TAIL_CALL:
            arg_count = frame.fetch_u16()
            return self._call(frame, arg_count, tail=True)
        if opcode == OP_RETURN:
            return self._return_from(frame)
        if opcode == OP_MAKE_CLOSURE:
            fn_index = frame.fetch_u16()
            target = self.module.functions[fn_index]
            upvalues: list[Value] = []
            for _ in range(target.upvalue_count):
                upvalues.append(frame.pop())
            upvalues.reverse()
            box = self.gc.allocate(alloc_closure(target.label, upvalues))
            frame.push(box)
            return None
        if opcode == OP_ALLOC:
            packed = frame.fetch_u16()
            class_id = packed & 0xFF
            tag = (packed >> 8) & 0xFF
            field_count = frame.fetch_u16() if False else 0
            # Heuristic: pop until the stack looks empty enough; in the
            # current emitter we pre-push exactly the constructor's arity
            # of args, so we encode it via the tag's high byte.
            args = [frame.pop() for _ in range(tag)]
            args.reverse()
            box = self.gc.allocate(alloc_data(class_id, args))
            frame.push(box)
            return None
        if opcode == OP_GET_FIELD:
            index = frame.fetch_u16()
            target = frame.pop()
            if not isinstance(target, Box):
                raise TypeMismatchAtRuntime("GET_FIELD on non-object")
            payload = target.payload
            if isinstance(payload, list):
                frame.push(payload[index])
            elif isinstance(payload, dict):
                # Records keyed by name -- we emit GET_FIELD for indices,
                # so this branch only happens via foreign callers.
                frame.push(list(payload.values())[index])
            elif isinstance(payload, tuple):
                tag, args = payload
                frame.push(args[index])
            else:
                raise TypeMismatchAtRuntime("GET_FIELD against unknown payload")
            return None
        if opcode == OP_MATCH_TAG:
            tag = frame.fetch_u16()
            scrutinee = frame.peek()
            matched = isinstance(scrutinee, Box) and (
                scrutinee.payload[0] == tag if isinstance(scrutinee.payload, tuple) else False
            )
            frame.push(matched)
            return None
        if opcode == OP_PRIM:
            prim_index = frame.fetch_u16()
            handler = self.primitives.get(prim_index)
            if handler is None:
                raise BytecodeError(f"unknown primitive index 0x{prim_index:x}")
            handler(self, frame)
            return None
        if opcode == OP_HALT:
            return _RETURN
        raise BytecodeError(f"unknown opcode 0x{opcode:02x}")

    def _call(self, frame: Frame, arg_count: int, *, tail: bool) -> None:
        if self.stack.depth() >= self.max_call_depth and not tail:
            raise StackOverflow("call stack exhausted")
        callee = frame.pop()
        args = [frame.pop() for _ in range(arg_count)]
        args.reverse()
        if not isinstance(callee, Box) or callee.class_id != CLASS_CLOSURE:
            raise TypeMismatchAtRuntime("call target is not a closure")
        label, upvalues = callee.payload
        target = self._lookup_function(label)
        new_frame = self._make_frame(target, args=args, upvalues=list(upvalues))
        if tail:
            self.stack.replace_top(new_frame)
        else:
            self.stack.push(new_frame)

    def _return_from(self, frame: Frame) -> object:
        value: Value = frame.pop() if frame.eval_stack else None
        self.stack.pop()
        parent = self.stack.current()
        if parent is None:
            self._final_value = value
            return _RETURN
        parent.push(value)
        return None

    def _make_frame(
        self,
        function: CompiledFunction,
        *,
        args: list[Value],
        upvalues: list[Value],
    ) -> Frame:
        frame = Frame(function=function, upvalues=upvalues)
        frame.locals_ = list(args) + [None] * max(function.local_count - len(args), 0)
        return frame

    def _lookup_function(self, label: str) -> CompiledFunction:
        for fn in self.module.functions:
            if fn.label == label:
                return fn
        raise BytecodeError(f"function {label!r} not found")

    def _final_value(self) -> Value:
        return getattr(self, "_final_value", None)

    def _return_value(self) -> Value:
        return getattr(self, "_final_value", None)

    def _iter_roots(self) -> list[Value]:
        roots: list[Value] = []
        for frame in self.stack.frames:
            roots.extend(frame.locals_)
            roots.extend(frame.upvalues)
            roots.extend(frame.eval_stack)
        roots.extend(self.globals_.values())
        return roots



_RETURN = object()


def _truthy(value: Value) -> bool:
    if value is None:
        return False
    if isinstance(value, int):
        return value != 0
    if isinstance(value, Box):
        return True
    return bool(value)


def _const_to_value(const: Constant) -> Value:
    if const.kind == CONST_INT:
        return int(const.value)  # type: ignore[arg-type]
    if const.kind == CONST_FLOAT:
        from lyra.objects.model import alloc_float

        return alloc_float(float(const.value))  # type: ignore[arg-type]
    if const.kind == CONST_STRING:
        return alloc_string(str(const.value))
    if const.kind == CONST_BOOL:
        return bool(const.value)
    if const.kind == CONST_CHAR:
        return alloc_string(str(const.value))
    if const.kind == CONST_UNIT:
        return None
    raise BytecodeError(f"unhandled constant kind 0x{const.kind:02x}")
