from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

from lyra.errors import CircularImport, ModuleNotFound
from lyra.parser import parse_module
from lyra.parser.ast import ImportDecl, Module


@dataclass
class LoadedModule:
    name: str
    path: Path
    ast: Module
    dependencies: list[str]


@dataclass
class ModuleLoader:
    search_paths: list[Path] = field(default_factory=list)
    loaded: dict[str, LoadedModule] = field(default_factory=dict)
    _loading: list[str] = field(default_factory=list)

    def load(self, name: str) -> LoadedModule:
        if name in self.loaded:
            return self.loaded[name]
        if name in self._loading:
            cycle = " -> ".join(self._loading + [name])
            raise CircularImport(f"circular import: {cycle}")
        path = self._resolve(name)
        if path is None:
            raise ModuleNotFound(f"module {name!r} not found")
        source = path.read_text(encoding="utf-8")
        ast = parse_module(source, file=str(path), default_name=name)
        self._loading.append(name)
        try:
            deps = [d.module for d in ast.declarations if isinstance(d, ImportDecl)]
            for dep in deps:
                self.load(dep)
        finally:
            self._loading.pop()
        loaded = LoadedModule(name=name, path=path, ast=ast, dependencies=deps)
        self.loaded[name] = loaded
        return loaded

    def topo_order(self) -> list[LoadedModule]:
        """Return loaded modules in dependency order (deps first)."""
        visited: set[str] = set()
        order: list[LoadedModule] = []

        def visit(name: str) -> None:
            if name in visited or name not in self.loaded:
                return
            visited.add(name)
            for dep in self.loaded[name].dependencies:
                visit(dep)
            order.append(self.loaded[name])

        for n in list(self.loaded):
            visit(n)
        return order

    def _resolve(self, name: str) -> Path | None:
        relative = Path(*name.split(".")).with_suffix(".lyra")
        for base in self.search_paths:
            candidate = base / relative
            if candidate.exists():
                return candidate
        return None
