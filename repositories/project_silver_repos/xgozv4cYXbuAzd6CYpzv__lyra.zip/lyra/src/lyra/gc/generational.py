from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Iterable

from lyra.constants import (
    CLASS_CLOSURE,
    CLASS_DATA,
    CLASS_LIST,
    CLASS_MAP,
    CLASS_RECORD,
    CLASS_TUPLE,
    DEFAULT_PROMOTION_AGE,
    DEFAULT_YOUNG_BYTES,
    GC_HEADER_SIZE,
)
from lyra.objects.model import Box, Value


@dataclass
class GcStats:
    minor_collections: int = 0
    major_collections: int = 0
    bytes_allocated: int = 0
    bytes_freed: int = 0
    bytes_promoted: int = 0
    write_barriers_fired: int = 0


@dataclass
class GenerationalGC:
    """Two-space generational copying GC."""

    young_bytes_limit: int = DEFAULT_YOUNG_BYTES
    promotion_age: int = DEFAULT_PROMOTION_AGE
    young: list[Box] = field(default_factory=list)
    old: list[Box] = field(default_factory=list)
    remembered_set: set[int] = field(default_factory=set)
    stats: GcStats = field(default_factory=GcStats)
    young_used_bytes: int = 0
    root_provider: Callable[[], Iterable[Value]] | None = None

    def allocate(self, box: Box, *, size: int = GC_HEADER_SIZE) -> Box:
        if self.young_used_bytes + size > self.young_bytes_limit:
            self.minor_collect()
            if self.young_used_bytes + size > self.young_bytes_limit:
                self.major_collect()
        self.young.append(box)
        self.young_used_bytes += size
        self.stats.bytes_allocated += size
        return box

    def write_barrier(self, parent: Box, child: Value) -> None:
        """Notify the GC that ``parent`` (in old space) now references ``child``.

        If ``child`` lives in the young space, we add ``parent`` to the
        remembered set so the next minor collection scans it as a root.
        """
        if not isinstance(child, Box):
            return
        if id(parent) in self.remembered_set:
            return
        if parent in self.old and child in self.young:
            self.remembered_set.add(id(parent))
            self.stats.write_barriers_fired += 1

    def minor_collect(self) -> None:
        roots = self._collect_roots()
        live_young: set[int] = set()
        promoted: list[Box] = []
        survivors: list[Box] = []
        # Walk roots, marking reachable young objects.
        for root in roots:
            self._mark(root, live_young)
        # Pretend remembered set is a root too.
        for obj in self.young:
            if id(obj) in {id(p) for p in self.old} and obj in self.remembered_set:
                self._mark(obj, live_young)
        for obj in self.young:
            if id(obj) not in live_young:
                self.stats.bytes_freed += GC_HEADER_SIZE
                continue
            obj.age += 1
            if obj.age >= self.promotion_age:
                promoted.append(obj)
                self.stats.bytes_promoted += GC_HEADER_SIZE
            else:
                survivors.append(obj)
        self.old.extend(promoted)
        self.young = survivors
        self.young_used_bytes = len(survivors) * GC_HEADER_SIZE
        self.remembered_set.clear()
        self.stats.minor_collections += 1

    def major_collect(self) -> None:
        roots = self._collect_roots()
        live: set[int] = set()
        for root in roots:
            self._mark(root, live)
        kept_old: list[Box] = []
        for obj in self.old:
            if id(obj) in live:
                kept_old.append(obj)
            else:
                self.stats.bytes_freed += GC_HEADER_SIZE
        kept_young: list[Box] = []
        for obj in self.young:
            if id(obj) in live:
                kept_young.append(obj)
            else:
                self.stats.bytes_freed += GC_HEADER_SIZE
        self.old = kept_old
        self.young = kept_young
        self.young_used_bytes = len(kept_young) * GC_HEADER_SIZE
        self.stats.major_collections += 1
        self.remembered_set.clear()

    def _mark(self, value: Value, live: set[int]) -> None:
        if not isinstance(value, Box):
            return
        if id(value) in live:
            return
        live.add(id(value))
        for child in _children(value):
            self._mark(child, live)

    def _collect_roots(self) -> list[Value]:
        if self.root_provider is None:
            return []
        return list(self.root_provider())



def _children(box: Box) -> list[Value]:
    payload = box.payload
    if box.class_id in {CLASS_TUPLE, CLASS_LIST}:
        return list(payload)
    if box.class_id == CLASS_RECORD:
        return list(payload.values())
    if box.class_id == CLASS_DATA:
        _tag, args = payload
        return list(args)
    if box.class_id == CLASS_CLOSURE:
        _label, upvalues = payload
        return list(upvalues)
    if box.class_id == CLASS_MAP:
        out: list[Value] = []
        for k, v in payload.items():
            out.append(k)
            out.append(v)
        return out
    return []
