from __future__ import annotations

from typing import Iterator

from lyra.errors import LexerError, Position
from lyra.lexer.token import KEYWORDS, OPERATOR_SYMBOLS, Token, TokenKind, is_keyword


class Lexer:
    def __init__(self, source: str, *, file: str = "<string>") -> None:
        self.source = source
        self.file = file
        self.pos = 0
        self.line = 1
        self.column = 1

    def tokenize(self) -> list[Token]:
        return list(iter(self))

    def __iter__(self) -> Iterator[Token]:
        while True:
            tok = self._next()
            yield tok
            if tok.kind == TokenKind.EOF:
                return

    def _next(self) -> Token:
        self._skip_trivia()
        start_pos = self._pos()
        if self.pos >= len(self.source):
            return Token(TokenKind.EOF, "", start_pos)
        ch = self.source[self.pos]
        if ch.isalpha() or ch == "_":
            return self._read_word(start_pos)
        if ch.isdigit():
            return self._read_number(start_pos)
        if ch == '"':
            return self._read_string(start_pos)
        if ch == "'":
            return self._read_char(start_pos)
        return self._read_punct_or_op(start_pos)

    def _skip_trivia(self) -> None:
        while self.pos < len(self.source):
            ch = self.source[self.pos]
            if ch in " \t\r\n":
                self._advance()
                continue
            if ch == "/" and self._peek(1) == "/":
                while self.pos < len(self.source) and self.source[self.pos] != "\n":
                    self._advance()
                continue
            if ch == "/" and self._peek(1) == "*":
                self._advance(); self._advance()
                depth = 1
                while self.pos < len(self.source) and depth > 0:
                    if self.source[self.pos] == "/" and self._peek(1) == "*":
                        depth += 1
                        self._advance(); self._advance()
                    elif self.source[self.pos] == "*" and self._peek(1) == "/":
                        depth -= 1
                        self._advance(); self._advance()
                    else:
                        self._advance()
                if depth != 0:
                    raise LexerError("unterminated block comment", position=self._pos())
                continue
            return

    def _read_word(self, start: Position) -> Token:
        begin = self.pos
        first = self.source[self.pos]
        self._advance()
        while self.pos < len(self.source):
            ch = self.source[self.pos]
            if ch.isalnum() or ch == "_" or ch == "'":
                self._advance()
            else:
                break
        text = self.source[begin: self.pos]
        if text == "_":
            return Token(TokenKind.UNDERSCORE, "_", start)
        if text in {"true", "false"}:
            return Token(TokenKind.BOOL, text, start)
        if is_keyword(text):
            return Token(TokenKind.KEYWORD, text, start)
        if first.isupper():
            return Token(TokenKind.UIDENT, text, start)
        return Token(TokenKind.LIDENT, text, start)

    def _read_number(self, start: Position) -> Token:
        begin = self.pos
        seen_dot = False
        seen_exp = False
        while self.pos < len(self.source):
            ch = self.source[self.pos]
            if ch.isdigit() or ch == "_":
                self._advance()
                continue
            if ch == "." and not seen_dot and not seen_exp:
                # Look ahead: ``1..2`` is a range op, not a float.
                if self._peek(1) == ".":
                    break
                seen_dot = True
                self._advance()
                continue
            if ch in {"e", "E"} and not seen_exp:
                seen_exp = True
                self._advance()
                if self.pos < len(self.source) and self.source[self.pos] in "+-":
                    self._advance()
                continue
            break
        text = self.source[begin: self.pos].replace("_", "")
        if seen_dot or seen_exp:
            return Token(TokenKind.FLOAT, text, start)
        return Token(TokenKind.INT, text, start)

    def _read_string(self, start: Position) -> Token:
        self._advance()
        chars: list[str] = []
        while True:
            if self.pos >= len(self.source):
                raise LexerError("unterminated string literal", position=start)
            ch = self.source[self.pos]
            if ch == "\\":
                self._advance()
                if self.pos >= len(self.source):
                    raise LexerError("unterminated string escape", position=start)
                esc = self.source[self.pos]
                chars.append(_escape_char(esc, start))
                self._advance()
                continue
            if ch == '"':
                self._advance()
                return Token(TokenKind.STRING, "".join(chars), start)
            if ch == "\n":
                raise LexerError("string crosses newline", position=self._pos())
            chars.append(ch)
            self._advance()

    def _read_char(self, start: Position) -> Token:
        self._advance()
        if self.pos >= len(self.source):
            raise LexerError("unterminated char literal", position=start)
        ch = self.source[self.pos]
        if ch == "\\":
            self._advance()
            if self.pos >= len(self.source):
                raise LexerError("unterminated char escape", position=start)
            ch = _escape_char(self.source[self.pos], start)
            self._advance()
        else:
            self._advance()
        if self.pos >= len(self.source) or self.source[self.pos] != "'":
            raise LexerError("expected closing '", position=start)
        self._advance()
        return Token(TokenKind.CHAR, ch, start)

    def _read_punct_or_op(self, start: Position) -> Token:
        # Try multi-character symbols first, longest first.
        for symbol in sorted(OPERATOR_SYMBOLS, key=len, reverse=True):
            if self.source.startswith(symbol, self.pos):
                for _ in symbol:
                    self._advance()
                kind = _operator_kind(symbol)
                return Token(kind, symbol, start)
        ch = self.source[self.pos]
        single_map = {
            "(": TokenKind.LPAREN,
            ")": TokenKind.RPAREN,
            "{": TokenKind.LBRACE,
            "}": TokenKind.RBRACE,
            "[": TokenKind.LBRACK,
            "]": TokenKind.RBRACK,
            ",": TokenKind.COMMA,
            ";": TokenKind.SEMICOLON,
            ":": TokenKind.COLON,
            ".": TokenKind.DOT,
            "|": TokenKind.PIPE,
            "@": TokenKind.AT,
            "&": TokenKind.AMPERSAND,
            "`": TokenKind.BACKTICK,
        }
        if ch in single_map:
            self._advance()
            return Token(single_map[ch], ch, start)
        raise LexerError(f"unexpected character {ch!r}", position=start)

    def _advance(self) -> None:
        if self.pos >= len(self.source):
            return
        ch = self.source[self.pos]
        self.pos += 1
        if ch == "\n":
            self.line += 1
            self.column = 1
        else:
            self.column += 1

    def _peek(self, offset: int) -> str:
        idx = self.pos + offset
        if 0 <= idx < len(self.source):
            return self.source[idx]
        return ""

    def _pos(self) -> Position:
        return Position(file=self.file, line=self.line, column=self.column, offset=self.pos)



def _escape_char(esc: str, source_pos: Position) -> str:
    table = {
        "n": "\n", "t": "\t", "r": "\r", "\\": "\\",
        "'": "'", '"': '"', "0": "\0",
    }
    if esc not in table:
        raise LexerError(f"unknown escape: \\{esc}", position=source_pos)
    return table[esc]


def _operator_kind(symbol: str) -> TokenKind:
    if symbol == "->":
        return TokenKind.ARROW
    if symbol == "=>":
        return TokenKind.FAT_ARROW
    if symbol == "::":
        return TokenKind.DOUBLE_COLON
    return TokenKind.OP


def tokenize(source: str, *, file: str = "<string>") -> list[Token]:
    return Lexer(source, file=file).tokenize()
