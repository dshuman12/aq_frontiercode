from __future__ import annotations

import enum
from dataclasses import dataclass
from typing import Final

from lyra.errors import Position


class TokenKind(enum.Enum):
    # Literals
    INT = "int"
    FLOAT = "float"
    STRING = "string"
    CHAR = "char"
    BOOL = "bool"

    # Identifiers (Lyra distinguishes lowercase value names from
    # uppercase constructor / type names at the lexical level so the
    # parser does not have to disambiguate by context).
    LIDENT = "lident"
    UIDENT = "uident"

    # Keywords.
    KEYWORD = "keyword"

    # Punctuation
    LPAREN = "("
    RPAREN = ")"
    LBRACE = "{"
    RBRACE = "}"
    LBRACK = "["
    RBRACK = "]"
    COMMA = ","
    SEMICOLON = ";"
    COLON = ":"
    DOUBLE_COLON = "::"
    DOT = "."
    ARROW = "->"
    FAT_ARROW = "=>"
    PIPE = "|"
    UNDERSCORE = "_"
    AT = "@"
    AMPERSAND = "&"
    BACKTICK = "`"

    # Operators (kept as a single kind; the text picks the actual op).
    OP = "op"

    # Layout / end-of-stream
    NEWLINE = "newline"
    EOF = "eof"


@dataclass(frozen=True)
class Token:
    kind: TokenKind
    text: str
    position: Position

    def is_keyword(self, *names: str) -> bool:
        if self.kind != TokenKind.KEYWORD:
            return False
        return self.text in names

    def is_op(self, *symbols: str) -> bool:
        if self.kind != TokenKind.OP:
            return False
        return self.text in symbols

    def __repr__(self) -> str:
        return f"Token({self.kind.name}, {self.text!r}, {self.position.render()})"


KEYWORDS: Final[frozenset[str]] = frozenset(
    {
        "let", "rec", "in", "and",
        "fn", "lambda", "return",
        "if", "then", "else",
        "match", "with",
        "type", "data", "where",
        "module", "import", "export", "as",
        "true", "false",
        "do", "yield",
        "case", "of", "end",
        "extern", "foreign",
        "panic", "assert",
        "forall",
    }
)


OPERATOR_SYMBOLS: Final[tuple[str, ...]] = (
    "->", "=>", "::", "<=", ">=", "==", "!=", "<<", ">>",
    "&&", "||", "++", "..",
    "+", "-", "*", "/", "%", "<", ">", "=", "!",
)


def is_keyword(text: str) -> bool:
    return text in KEYWORDS
