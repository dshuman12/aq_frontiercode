from __future__ import annotations

from typing import Iterable


def humanise_bytes(byte_count: int) -> str:
    units = ["B", "KiB", "MiB", "GiB"]
    cursor = float(byte_count)
    for unit in units:
        if cursor < 1024:
            return f"{cursor:.1f} {unit}"
        cursor /= 1024
    return f"{cursor:.1f} TiB"


def humanise_count(count: int) -> str:
    if count >= 1_000_000:
        return f"{count / 1_000_000:.1f}M"
    if count >= 1_000:
        return f"{count / 1_000:.1f}k"
    return str(count)


def two_column_layout(items: Iterable[tuple[str, str]], *, separator: str = "  ") -> str:
    pairs = list(items)
    if not pairs:
        return ""
    width = max(len(left) for left, _ in pairs)
    return "\n".join(f"{left.ljust(width)}{separator}{right}" for left, right in pairs)


def indent_block(text: str, *, by: int = 2) -> str:
    pad = " " * by
    return "\n".join(pad + line if line else line for line in text.splitlines())
