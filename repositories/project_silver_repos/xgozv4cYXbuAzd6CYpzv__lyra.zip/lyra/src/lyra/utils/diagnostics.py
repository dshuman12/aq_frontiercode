from __future__ import annotations

from dataclasses import dataclass

from lyra.errors import LyraError, Position


@dataclass
class Diagnostic:
    code: str
    message: str
    rendered: str

    def __str__(self) -> str:
        return self.rendered


def format_error(exc: LyraError, *, source: str | None = None) -> Diagnostic:
    parts: list[str] = []
    header = f"{exc.code}: {exc}"
    parts.append(header)
    pos = exc.position
    if pos is not None and source is not None:
        snippet = _line_excerpt(source, pos)
        if snippet:
            parts.append(snippet)
    if exc.hint:
        parts.append(f"  hint: {exc.hint}")
    if exc.context:
        for k, v in exc.context.items():
            parts.append(f"  {k}: {v}")
    rendered = "\n".join(parts)
    return Diagnostic(code=exc.code, message=str(exc), rendered=rendered)


def _line_excerpt(source: str, pos: Position) -> str:
    lines = source.splitlines()
    if pos.line < 1 or pos.line > len(lines):
        return ""
    line = lines[pos.line - 1]
    pointer = " " * max(pos.column - 1, 0) + "^"
    return f"  {line}\n  {pointer}"


def format_chain(errors: list[LyraError], *, source: str | None = None) -> str:
    return "\n\n".join(str(format_error(e, source=source)) for e in errors)
