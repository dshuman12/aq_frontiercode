from __future__ import annotations

from typing import Sequence

from lyra.errors import CompilerError
from lyra.ir import nodes as I
from lyra.parser import ast as A


class Lowerer:
    def __init__(self) -> None:
        self._counter = 0
        self._functions: list[I.Function] = []

    def lower_module(self, module: A.Module) -> I.Module:
        ir_module = I.Module(name=module.name)
        for decl in module.declarations:
            if isinstance(decl, A.LetDecl):
                for binding in decl.bindings:
                    self._lower_top_binding(ir_module, binding)
            elif isinstance(decl, A.TypeDecl):
                ir_module.type_definitions.append(_type_def_from(decl))
            elif isinstance(decl, A.ImportDecl):
                ir_module.imports.append(I.ImportSpec(
                    module=decl.module, alias=decl.alias,
                    items=list(decl.items) if decl.items else None,
                ))
        ir_module.functions.extend(self._functions)
        return ir_module

    def _lower_top_binding(self, module: I.Module, binding: A.Binding) -> None:
        if not isinstance(binding.pattern, A.PVar):
            raise CompilerError(
                "top-level destructuring is not yet supported",
                position=binding.position,
            )
        name = binding.pattern.name
        if isinstance(binding.expr, A.Lambda):
            label = self._fresh_label(name)
            self._lower_lambda(label, binding.expr, top_level=True)
            module.globals_.append(I.Binding(
                name=name, expr=I.ClosureExpr(function_label=label, upvalues=[]),
            ))
            return
        block = self._fresh_block()
        atom = self._lower_expr(block, binding.expr) if binding.expr else I.UnitAtom()
        block.result = atom
        # Realise the block as a single binding by inlining its content.
        for sub in block.bindings:
            module.globals_.append(sub)
        if isinstance(atom, I.Atom):
            module.globals_.append(I.Binding(name=name, expr=I.AtomExpr(atom=atom)))
        else:
            module.globals_.append(I.Binding(name=name, expr=atom))

    def _lower_expr(self, block: I.Block, expr: A.Expr | None) -> I.Atom:
        if expr is None:
            return I.UnitAtom()
        if isinstance(expr, A.IntLit):
            return I.IntAtom(value=expr.value)
        if isinstance(expr, A.FloatLit):
            return I.FloatAtom(value=expr.value)
        if isinstance(expr, A.StringLit):
            return I.StringAtom(value=expr.value)
        if isinstance(expr, A.BoolLit):
            return I.BoolAtom(value=expr.value)
        if isinstance(expr, A.CharLit):
            return I.CharAtom(value=expr.value)
        if isinstance(expr, A.UnitLit):
            return I.UnitAtom()
        if isinstance(expr, A.Var):
            return I.VarAtom(name=expr.name)
        if isinstance(expr, A.App):
            return self._lower_app(block, expr)
        if isinstance(expr, A.Lambda):
            label = self._fresh_label("lambda")
            self._lower_lambda(label, expr, top_level=False)
            tmp = self._fresh_var()
            block.bindings.append(
                I.Binding(name=tmp, expr=I.ClosureExpr(function_label=label, upvalues=[]))
            )
            return I.VarAtom(name=tmp)
        if isinstance(expr, A.Let):
            return self._lower_let(block, expr)
        if isinstance(expr, A.If):
            return self._lower_if(block, expr)
        if isinstance(expr, A.Match):
            return self._lower_match(block, expr)
        if isinstance(expr, A.Tuple):
            atoms = [self._lower_expr(block, e) for e in expr.elements]
            tmp = self._fresh_var()
            block.bindings.append(
                I.Binding(name=tmp, expr=I.AllocExpr(
                    class_id=0x06,  # CLASS_TUPLE
                    fields=atoms, tag=0, label=f"(tuple,{len(atoms)})",
                ))
            )
            return I.VarAtom(name=tmp)
        if isinstance(expr, A.Record):
            atoms = [self._lower_expr(block, v) for _, v in expr.fields]
            tmp = self._fresh_var()
            block.bindings.append(
                I.Binding(name=tmp, expr=I.AllocExpr(
                    class_id=0x09,  # CLASS_RECORD
                    fields=atoms,
                    label=",".join(name for name, _ in expr.fields),
                ))
            )
            return I.VarAtom(name=tmp)
        if isinstance(expr, A.FieldAccess):
            target = self._lower_expr(block, expr.target)
            tmp = self._fresh_var()
            block.bindings.append(
                I.Binding(name=tmp, expr=I.GetFieldExpr(
                    target=target, field_name=expr.field, index=-1,
                ))
            )
            return I.VarAtom(name=tmp)
        if isinstance(expr, A.BinOp):
            left = self._lower_expr(block, expr.left)
            right = self._lower_expr(block, expr.right)
            tmp = self._fresh_var()
            block.bindings.append(
                I.Binding(name=tmp, expr=I.PrimExpr(
                    name=_binop_prim(expr.op), args=[left, right],
                ))
            )
            return I.VarAtom(name=tmp)
        if isinstance(expr, A.UnaryOp):
            inner = self._lower_expr(block, expr.operand)
            tmp = self._fresh_var()
            block.bindings.append(
                I.Binding(name=tmp, expr=I.PrimExpr(
                    name=_unaryop_prim(expr.op), args=[inner],
                ))
            )
            return I.VarAtom(name=tmp)
        if isinstance(expr, A.Sequence_):
            last: I.Atom = I.UnitAtom()
            for stmt in expr.statements:
                last = self._lower_expr(block, stmt)
            return last
        if isinstance(expr, A.Annot):
            return self._lower_expr(block, expr.expr) if expr.expr else I.UnitAtom()
        raise CompilerError(f"unsupported expression: {type(expr).__name__}")

    def _lower_app(self, block: I.Block, expr: A.App) -> I.Atom:
        func = self._lower_expr(block, expr.func)
        args = [self._lower_expr(block, a) for a in expr.args]
        tmp = self._fresh_var()
        block.bindings.append(
            I.Binding(name=tmp, expr=I.CallExpr(func=func, args=args))
        )
        return I.VarAtom(name=tmp)

    def _lower_lambda(self, label: str, expr: A.Lambda, *, top_level: bool) -> None:
        params: list[str] = []
        body_block = self._fresh_block()
        for pat in expr.params:
            if isinstance(pat, A.PVar):
                params.append(pat.name)
            elif isinstance(pat, A.PWild):
                params.append(self._fresh_var())
            else:
                tmp = self._fresh_var()
                params.append(tmp)
                # TODO: destructure parameter patterns into the body.
        result = self._lower_expr(body_block, expr.body) if expr.body else I.UnitAtom()
        body_block.result = result
        self._functions.append(
            I.Function(label=label, params=params, body=body_block, is_top_level=top_level)
        )

    def _lower_let(self, block: I.Block, expr: A.Let) -> I.Atom:
        for binding in expr.bindings:
            value = self._lower_expr(block, binding.expr)
            if isinstance(binding.pattern, A.PVar):
                block.bindings.append(
                    I.Binding(name=binding.pattern.name, expr=I.AtomExpr(atom=value))
                )
            else:
                # Destructuring let -- TODO; we just compute the RHS for now.
                pass
        return self._lower_expr(block, expr.body) if expr.body else I.UnitAtom()

    def _lower_if(self, block: I.Block, expr: A.If) -> I.Atom:
        cond = self._lower_expr(block, expr.cond)
        then_block = self._fresh_block()
        else_block = self._fresh_block()
        then_atom = self._lower_expr(then_block, expr.then_branch)
        else_atom = self._lower_expr(else_block, expr.else_branch)
        then_block.result = then_atom
        else_block.result = else_atom
        tmp = self._fresh_var()
        block.bindings.append(
            I.Binding(name=tmp, expr=I.IfExpr(
                cond=cond, then_block=then_block, else_block=else_block,
            ))
        )
        return I.VarAtom(name=tmp)

    def _lower_match(self, block: I.Block, expr: A.Match) -> I.Atom:
        scrutinee = self._lower_expr(block, expr.scrutinee)
        arms: list[tuple[int, I.Block]] = []
        default: I.Block | None = None
        for tag, arm in enumerate(expr.arms):
            arm_block = self._fresh_block()
            atom = self._lower_expr(arm_block, arm.body)
            arm_block.result = atom
            if isinstance(arm.pattern, (A.PVar, A.PWild)) and default is None:
                default = arm_block
            else:
                arms.append((tag, arm_block))
        tmp = self._fresh_var()
        block.bindings.append(
            I.Binding(name=tmp, expr=I.MatchTagExpr(
                scrutinee=scrutinee, arms=arms, default=default,
            ))
        )
        return I.VarAtom(name=tmp)

    def _fresh_var(self) -> str:
        self._counter += 1
        return f"$t{self._counter}"

    def _fresh_label(self, hint: str) -> str:
        self._counter += 1
        return f"{hint}_{self._counter}"

    def _fresh_block(self) -> I.Block:
        return I.Block(bindings=[], result=None)


_BINOP_PRIMS = {
    "+": "int_add", "-": "int_sub", "*": "int_mul", "/": "int_div", "%": "int_mod",
    "==": "eq", "!=": "ne", "<": "lt", "<=": "le", ">": "gt", ">=": "ge",
    "&&": "bool_and", "||": "bool_or", "++": "string_concat",
}


_UNARYOP_PRIMS = {
    "-": "int_neg", "!": "bool_not",
}


def _binop_prim(op: str) -> str:
    if op not in _BINOP_PRIMS:
        raise CompilerError(f"unsupported binary operator: {op}")
    return _BINOP_PRIMS[op]


def _unaryop_prim(op: str) -> str:
    if op not in _UNARYOP_PRIMS:
        raise CompilerError(f"unsupported unary operator: {op}")
    return _UNARYOP_PRIMS[op]


def _type_def_from(decl: A.TypeDecl) -> I.TypeDefinition:
    constructors = [
        I.ConstructorSpec(name=c.name, tag=i, arity=len(c.fields))
        for i, c in enumerate(decl.constructors)
    ]
    return I.TypeDefinition(name=decl.name, constructors=constructors)


def lower_module(module: A.Module) -> I.Module:
    return Lowerer().lower_module(module)
