from lyra.resolve.resolver import resolve_module

__all__ = ["resolve_module"]
