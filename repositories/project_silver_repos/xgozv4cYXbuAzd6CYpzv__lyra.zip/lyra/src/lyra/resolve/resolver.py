from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable

from lyra.errors import DuplicateBinding, ResolveError, UndefinedName
from lyra.parser import ast as A


@dataclass
class _Scope:
    parent: "_Scope | None" = None
    bindings: set[str] = field(default_factory=set)
    constructors: set[str] = field(default_factory=set)

    def define(self, name: str) -> None:
        if name in self.bindings:
            raise DuplicateBinding(f"name {name!r} already bound in this scope")
        self.bindings.add(name)

    def define_constructor(self, name: str) -> None:
        self.constructors.add(name)

    def resolve(self, name: str) -> bool:
        if name in self.bindings:
            return True
        if self.parent is not None:
            return self.parent.resolve(name)
        return False

    def resolve_constructor(self, name: str) -> bool:
        if name in self.constructors:
            return True
        if self.parent is not None:
            return self.parent.resolve_constructor(name)
        return False

    def child(self) -> "_Scope":
        return _Scope(parent=self)



def resolve_module(module: A.Module) -> None:
    scope = _Scope()
    # First pass: collect top-level names and constructors.
    for decl in module.declarations:
        if isinstance(decl, A.LetDecl):
            for binding in decl.bindings:
                _gather_binding_names(binding, scope)
        elif isinstance(decl, A.TypeDecl):
            for con in decl.constructors:
                scope.define_constructor(con.name)
        elif isinstance(decl, A.ImportDecl):
            if decl.alias:
                scope.define(decl.alias)
            elif decl.items:
                for item in decl.items:
                    scope.define(item)
    # Second pass: validate references.
    for decl in module.declarations:
        if isinstance(decl, A.LetDecl):
            for binding in decl.bindings:
                _resolve_binding(binding, scope)


def _gather_binding_names(binding: A.Binding, scope: _Scope) -> None:
    pat = binding.pattern
    if isinstance(pat, A.PVar):
        try:
            scope.define(pat.name)
        except DuplicateBinding:
            # top-level rebindings are allowed in some flavours of ML;
            # we permit them for simplicity.
            pass


def _resolve_binding(binding: A.Binding, scope: _Scope) -> None:
    if binding.expr is not None:
        _resolve_expr(binding.expr, scope)


def _resolve_expr(expr: A.Expr, scope: _Scope) -> None:
    if isinstance(expr, A.Var):
        if expr.module is not None:
            return  # module-qualified -- we trust the import declaration.
        if scope.resolve(expr.name) or scope.resolve_constructor(expr.name):
            return
        # Built-ins escape the resolver -- the type checker validates them.
        if expr.name in {"true", "false"}:
            return
        raise UndefinedName(f"unbound name: {expr.name}", position=expr.position)
    if isinstance(expr, A.Lambda):
        child = scope.child()
        for pat in expr.params:
            _bind_pattern(pat, child)
        if expr.body is not None:
            _resolve_expr(expr.body, child)
        return
    if isinstance(expr, A.Let):
        child = scope.child()
        for binding in expr.bindings:
            if isinstance(binding.pattern, A.PVar):
                child.define(binding.pattern.name)
            if binding.expr is not None:
                target = child if binding.rec else scope
                _resolve_expr(binding.expr, target)
        if expr.body is not None:
            _resolve_expr(expr.body, child)
        return
    if isinstance(expr, A.Match):
        if expr.scrutinee is not None:
            _resolve_expr(expr.scrutinee, scope)
        for arm in expr.arms:
            child = scope.child()
            _bind_pattern(arm.pattern, child)
            if arm.guard is not None:
                _resolve_expr(arm.guard, child)
            if arm.body is not None:
                _resolve_expr(arm.body, child)
        return
    if isinstance(expr, A.If):
        for sub in (expr.cond, expr.then_branch, expr.else_branch):
            if sub is not None:
                _resolve_expr(sub, scope)
        return
    if isinstance(expr, A.App):
        if expr.func is not None:
            _resolve_expr(expr.func, scope)
        for a in expr.args:
            _resolve_expr(a, scope)
        return
    if isinstance(expr, A.BinOp):
        if expr.left is not None:
            _resolve_expr(expr.left, scope)
        if expr.right is not None:
            _resolve_expr(expr.right, scope)
        return
    if isinstance(expr, A.UnaryOp) and expr.operand is not None:
        _resolve_expr(expr.operand, scope)
        return
    if isinstance(expr, (A.Tuple,)):
        for e in expr.elements:
            _resolve_expr(e, scope)
        return
    if isinstance(expr, A.Record):
        for _, v in expr.fields:
            _resolve_expr(v, scope)
        return
    if isinstance(expr, A.FieldAccess) and expr.target is not None:
        _resolve_expr(expr.target, scope)
        return
    if isinstance(expr, A.Sequence_):
        for stmt in expr.statements:
            _resolve_expr(stmt, scope)
        return
    if isinstance(expr, A.Annot) and expr.expr is not None:
        _resolve_expr(expr.expr, scope)
        return
    # Literals and unit need no resolution.


def _bind_pattern(pattern: A.Pattern | None, scope: _Scope) -> None:
    if pattern is None:
        return
    if isinstance(pattern, A.PVar):
        scope.define(pattern.name)
        return
    if isinstance(pattern, A.PWild):
        return
    if isinstance(pattern, A.PCon):
        for sub in pattern.args:
            _bind_pattern(sub, scope)
        return
    if isinstance(pattern, A.PTuple):
        for sub in pattern.elements:
            _bind_pattern(sub, scope)
        return
    if isinstance(pattern, A.POr):
        # Each option must bind the same names; we trust the parser.
        for option in pattern.options:
            _bind_pattern(option, scope)
        return
    if isinstance(pattern, A.PAs):
        scope.define(pattern.name)
        if pattern.inner is not None:
            _bind_pattern(pattern.inner, scope)
        return
    if isinstance(pattern, A.PRecord):
        for _, sub in pattern.fields:
            _bind_pattern(sub, scope)
        return
