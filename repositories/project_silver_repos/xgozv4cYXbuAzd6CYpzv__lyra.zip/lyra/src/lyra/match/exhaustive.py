from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Sequence

from lyra.errors import NonExhaustiveMatch, UselessPattern
from lyra.parser import ast as A


@dataclass(frozen=True)
class _Lit:
    value: object


@dataclass(frozen=True)
class _Con:
    name: str
    arity: int


_HeadCtor = _Lit | _Con | None  # None == wildcard


@dataclass
class TypeOracle:
    """Tells the algorithm the constructor signature of a type.

    The simple cases live here directly (Bool, Maybe, List); user
    types pass through ``register``.
    """

    signatures: dict[str, list[_Con]] = None  # type: ignore[assignment]

    def __post_init__(self) -> None:
        if self.signatures is None:
            self.signatures = {
                "Bool": [_Con("True", 0), _Con("False", 0)],
                "Maybe": [_Con("Nothing", 0), _Con("Just", 1)],
                "List": [_Con("Nil", 0), _Con("Cons", 2)],
            }

    def register(self, type_name: str, ctors: list[_Con]) -> None:
        self.signatures[type_name] = list(ctors)

    def constructors_of(self, type_name: str) -> list[_Con]:
        return list(self.signatures.get(type_name, []))



def check_match(arms: Sequence[A.MatchArm], oracle: TypeOracle) -> None:
    """Run exhaustiveness + usefulness checks across the arms.

    Raises ``NonExhaustiveMatch`` if a witness is missing; emits
    ``UselessPattern`` for every arm that is unreachable.
    """
    flat: list[list[A.Pattern]] = []
    for arm in arms:
        if arm.pattern is None:
            continue
        for option in _flatten_or(arm.pattern):
            flat.append([option])
    matrix: list[list[A.Pattern]] = []
    for i, row in enumerate(flat):
        if not _useful(matrix, row, oracle):
            raise UselessPattern(
                f"pattern in arm {i + 1} is unreachable",
                position=arms[min(i, len(arms) - 1)].position,
            )
        matrix.append(row)
    # Final exhaustiveness check: a fresh wildcard row must NOT be useful.
    wildcard_row = [A.PWild()]
    if _useful(matrix, wildcard_row, oracle):
        raise NonExhaustiveMatch("non-exhaustive match")


def _flatten_or(pat: A.Pattern) -> list[A.Pattern]:
    if isinstance(pat, A.POr):
        out: list[A.Pattern] = []
        for option in pat.options:
            out.extend(_flatten_or(option))
        return out
    return [pat]



def _useful(
    matrix: list[list[A.Pattern]],
    row: list[A.Pattern],
    oracle: TypeOracle,
) -> bool:
    if not row:
        # Empty row useful iff matrix is empty.
        return not matrix
    head = row[0]
    rest = row[1:]
    head_kind = _head_constructor(head)
    if isinstance(head_kind, _Con):
        return _useful(_specialise_matrix(matrix, head_kind), _specialise_row(head, rest), oracle)
    if isinstance(head_kind, _Lit):
        return _useful(_specialise_matrix_lit(matrix, head_kind), rest, oracle)
    # Wildcard or variable: split on the matrix's head columns.
    type_name = _signature_type(matrix, oracle)
    if type_name is None:
        return _useful(_default_matrix(matrix), rest, oracle)
    sig = oracle.constructors_of(type_name)
    if _matrix_covers_all(matrix, sig):
        # Every constructor appears -- recurse into each.
        for ctor in sig:
            sub_matrix = _specialise_matrix(matrix, ctor)
            sub_row = [A.PWild() for _ in range(ctor.arity)] + rest
            if _useful(sub_matrix, sub_row, oracle):
                return True
        return False
    return _useful(_default_matrix(matrix), rest, oracle)



def _head_constructor(pat: A.Pattern) -> _HeadCtor:
    if isinstance(pat, (A.PVar, A.PWild, A.PAs)):
        return None
    if isinstance(pat, A.PCon):
        return _Con(pat.name, len(pat.args))
    if isinstance(pat, A.PInt):
        return _Lit(pat.value)
    if isinstance(pat, A.PFloat):
        return _Lit(pat.value)
    if isinstance(pat, A.PString):
        return _Lit(pat.value)
    if isinstance(pat, A.PBool):
        return _Lit(pat.value)
    if isinstance(pat, A.PChar):
        return _Lit(pat.value)
    if isinstance(pat, A.PTuple):
        return _Con("(tuple)", len(pat.elements))
    return None


def _specialise_matrix(matrix: list[list[A.Pattern]], ctor: _Con) -> list[list[A.Pattern]]:
    out: list[list[A.Pattern]] = []
    for row in matrix:
        if not row:
            continue
        head = row[0]
        rest = row[1:]
        kind = _head_constructor(head)
        if isinstance(kind, _Con) and kind.name == ctor.name and kind.arity == ctor.arity:
            sub_args: list[A.Pattern] = list(_constructor_args(head))
            out.append(sub_args + rest)
        elif kind is None:
            out.append([A.PWild() for _ in range(ctor.arity)] + rest)
    return out


def _specialise_matrix_lit(matrix: list[list[A.Pattern]], lit: _Lit) -> list[list[A.Pattern]]:
    out: list[list[A.Pattern]] = []
    for row in matrix:
        if not row:
            continue
        head = row[0]
        rest = row[1:]
        kind = _head_constructor(head)
        if isinstance(kind, _Lit) and kind.value == lit.value:
            out.append(rest)
        elif kind is None:
            out.append(rest)
    return out


def _default_matrix(matrix: list[list[A.Pattern]]) -> list[list[A.Pattern]]:
    out: list[list[A.Pattern]] = []
    for row in matrix:
        if not row:
            continue
        if _head_constructor(row[0]) is None:
            out.append(row[1:])
    return out


def _specialise_row(head: A.Pattern, rest: list[A.Pattern]) -> list[A.Pattern]:
    return list(_constructor_args(head)) + rest


def _constructor_args(pat: A.Pattern) -> Iterable[A.Pattern]:
    if isinstance(pat, A.PCon):
        return pat.args
    if isinstance(pat, A.PTuple):
        return pat.elements
    return ()


def _signature_type(matrix: list[list[A.Pattern]], oracle: TypeOracle) -> str | None:
    """Find a type name based on the constructor pattern at the head."""
    for row in matrix:
        if not row:
            continue
        head = row[0]
        if isinstance(head, A.PCon):
            for type_name, ctors in oracle.signatures.items():
                if any(c.name == head.name for c in ctors):
                    return type_name
        if isinstance(head, A.PBool):
            return "Bool"
    return None


def _matrix_covers_all(matrix: list[list[A.Pattern]], sig: list[_Con]) -> bool:
    seen = {
        _head_constructor(row[0]).name  # type: ignore[union-attr]
        for row in matrix
        if row and isinstance(_head_constructor(row[0]), _Con)
    }
    return all(c.name in seen for c in sig)
