from lyra.cli.main import main

__all__ = ["main"]
