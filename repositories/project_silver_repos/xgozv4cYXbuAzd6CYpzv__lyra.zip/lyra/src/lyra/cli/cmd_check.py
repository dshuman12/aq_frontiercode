from __future__ import annotations

from pathlib import Path

import click

from lyra.parser import parse_module
from lyra.types import infer_module


@click.command()
@click.argument("source", type=click.Path(exists=True, dir_okay=False))
def check(source: str) -> None:
    """Run the type checker against SOURCE; print inferred top-level types."""
    path = Path(source)
    module = parse_module(path.read_text(encoding="utf-8"), file=str(path))
    types = infer_module(module)
    if not types:
        click.echo("(no top-level definitions)")
        return
    width = max(len(name) for name in types)
    for name, ty in types.items():
        click.echo(f"{name:<{width}}  : {ty!r}")
