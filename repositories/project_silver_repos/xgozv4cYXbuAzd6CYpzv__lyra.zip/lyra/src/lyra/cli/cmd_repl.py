from __future__ import annotations

import click
from prompt_toolkit import PromptSession
from prompt_toolkit.history import FileHistory
from rich.console import Console

from lyra.constants import DEFAULT_REPL_HISTORY
from lyra.errors import LyraError
from lyra.objects.model import value_repr
from lyra.parser import parse_expr
from lyra.runtime import run_source
from lyra.types import infer_expression


@click.command()
@click.option("--history", default=DEFAULT_REPL_HISTORY, show_default=True)
def repl(history: str) -> None:
    """Start an interactive Lyra prompt."""
    console = Console()
    session: PromptSession[str] = PromptSession(history=FileHistory(history))
    console.print("[bold]lyra[/bold] -- :q to exit")
    while True:
        try:
            line = session.prompt("lyra> ")
        except (KeyboardInterrupt, EOFError):
            console.print("bye.")
            return
        if not line.strip():
            continue
        if line.strip() in {":q", ":quit"}:
            return
        try:
            ast = parse_expr(line)
            ty = infer_expression(ast)
            console.print(f"[dim]: {ty!r}[/dim]")
            wrapped = f"let _result = {line}"
            result = run_source(wrapped, entry="@module_init")
            if result is not None:
                console.print(value_repr(result))
        except LyraError as exc:
            console.print(f"[red]{type(exc).__name__}[/red]: {exc}")
