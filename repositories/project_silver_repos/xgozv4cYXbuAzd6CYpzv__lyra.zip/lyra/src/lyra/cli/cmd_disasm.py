from __future__ import annotations

from pathlib import Path

import click

from lyra.bytecode import disassemble_module
from lyra.runtime import compile_file, read_compiled


@click.command()
@click.argument("source", type=click.Path(exists=True, dir_okay=False))
def disasm(source: str) -> None:
    """Disassemble SOURCE (.lyra or .lyrac)."""
    path = Path(source)
    compiled = (
        read_compiled(path)
        if path.suffix == ".lyrac"
        else compile_file(path).module
    )
    click.echo(disassemble_module(compiled))
