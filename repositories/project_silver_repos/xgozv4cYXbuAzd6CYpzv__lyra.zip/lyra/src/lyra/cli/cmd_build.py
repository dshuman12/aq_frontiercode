from __future__ import annotations

from pathlib import Path

import click

from lyra.runtime import compile_file, write_compiled


@click.command()
@click.argument("source", type=click.Path(exists=True, dir_okay=False))
@click.option("--output", "-o", default=None)
def build(source: str, output: str | None) -> None:
    """Compile SOURCE to bytecode."""
    src = Path(source)
    out = Path(output) if output else src.with_suffix(".lyrac")
    result = compile_file(src)
    write_compiled(out, result.module)
    click.echo(f"compiled {src} -> {out}")
