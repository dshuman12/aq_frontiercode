from __future__ import annotations

import logging

import click

from lyra import __version__
from lyra.cli.cmd_build import build as _build
from lyra.cli.cmd_check import check as _check
from lyra.cli.cmd_disasm import disasm as _disasm
from lyra.cli.cmd_fmt import fmt as _fmt
from lyra.cli.cmd_repl import repl as _repl
from lyra.cli.cmd_run import run as _run


@click.group()
@click.option("--quiet", "-q", is_flag=True, default=False)
@click.version_option(version=__version__)
def main(quiet: bool) -> None:
    """Lyra -- a small typed functional language."""
    level = logging.WARNING if quiet else logging.INFO
    logging.basicConfig(level=level, format="%(asctime)s %(levelname)-7s %(name)s: %(message)s")


main.add_command(_build, name="build")
main.add_command(_run, name="run")
main.add_command(_repl, name="repl")
main.add_command(_check, name="check")
main.add_command(_fmt, name="fmt")
main.add_command(_disasm, name="disasm")


if __name__ == "__main__":
    main()
