from __future__ import annotations

from pathlib import Path

import click

from lyra.lexer import tokenize


@click.command()
@click.argument("source", type=click.Path(exists=True, dir_okay=False))
def fmt(source: str) -> None:
    """Validate that SOURCE lexes cleanly. (Placeholder.)"""
    text = Path(source).read_text(encoding="utf-8")
    tokens = tokenize(text, file=str(source))
    click.echo(f"{len(tokens) - 1} tokens")
