from __future__ import annotations

from pathlib import Path

import click

from lyra.objects.model import value_repr
from lyra.runtime import compile_file, read_compiled, run_compiled


@click.command()
@click.argument("source", type=click.Path(exists=True, dir_okay=False))
@click.option("--entry", default="main", show_default=True)
def run(source: str, entry: str) -> None:
    """Run a Lyra source or compiled module."""
    path = Path(source)
    if path.suffix == ".lyrac":
        compiled = read_compiled(path)
    else:
        compiled = compile_file(path).module
    result = run_compiled(compiled, entry=entry)
    if result is not None:
        click.echo(value_repr(result))
