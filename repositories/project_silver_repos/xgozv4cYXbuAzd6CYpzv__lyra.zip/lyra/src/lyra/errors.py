from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class Position:
    """A source-code location."""

    file: str = "<unknown>"
    line: int = 1
    column: int = 1
    offset: int = 0

    def render(self) -> str:
        return f"{self.file}:{self.line}:{self.column}"


class LyraError(Exception):
    """Base class for everything Lyra raises internally."""

    code: str = "LY0000"

    def __init__(
        self,
        message: str = "",
        *,
        code: str | None = None,
        position: Position | None = None,
        hint: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        if code is not None:
            self.code = code
        self.position: Position | None = position
        self.hint: str | None = hint
        self.context: dict[str, Any] = dict(context or {})

    def __str__(self) -> str:
        base = super().__str__() or self.code
        if self.position is not None:
            base = f"{self.position.render()}: {base}"
        return base



class LexerError(LyraError):
    code = "LY1001"


class ParseError(LyraError):
    code = "LY1100"


class ResolveError(LyraError):
    code = "LY1200"


class UndefinedName(ResolveError):
    code = "LY1201"


class DuplicateBinding(ResolveError):
    code = "LY1202"



class TypeError_(LyraError):
    """Avoid clashing with the built-in TypeError name."""

    code = "LY2000"


class UnificationError(TypeError_):
    code = "LY2001"


class OccursCheckError(TypeError_):
    code = "LY2002"


class GeneralizationError(TypeError_):
    code = "LY2003"


class KindError(TypeError_):
    code = "LY2004"



class PatternError(LyraError):
    code = "LY3000"


class NonExhaustiveMatch(PatternError):
    code = "LY3001"


class UselessPattern(PatternError):
    code = "LY3002"



class CompilerError(LyraError):
    code = "LY4000"


class CodegenError(CompilerError):
    code = "LY4100"


class OptimizerError(CompilerError):
    code = "LY4200"



class BytecodeError(LyraError):
    code = "LY5000"


class CorruptModule(BytecodeError):
    code = "LY5001"


class RuntimeError_(LyraError):
    code = "LY6000"


class StackOverflow(RuntimeError_):
    code = "LY6001"


class HeapOverflow(RuntimeError_):
    code = "LY6002"


class TypeMismatchAtRuntime(RuntimeError_):
    code = "LY6003"


class DivisionByZero(RuntimeError_):
    code = "LY6004"


class UncaughtUserException(RuntimeError_):
    code = "LY6005"


class TailCallOverflow(RuntimeError_):
    code = "LY6006"



class ModuleError(LyraError):
    code = "LY7000"


class ModuleNotFound(ModuleError):
    code = "LY7001"


class CircularImport(ModuleError):
    code = "LY7002"
