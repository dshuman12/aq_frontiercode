from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from lyra.constants import (
    CLASS_BIGINT,
    CLASS_CLOSURE,
    CLASS_DATA,
    CLASS_FLOAT,
    CLASS_FOREIGN,
    CLASS_LIST,
    CLASS_MAP,
    CLASS_RECORD,
    CLASS_STRING,
    CLASS_TUPLE,
    INT_TAG_SHIFT,
    MAX_TAGGED_INT,
    MIN_TAGGED_INT,
    TAG_INT_BIT,
)


@dataclass
class Box:
    """A heap-allocated boxed value."""

    class_id: int
    payload: Any
    age: int = 0
    color: int = 0  # 0 = white, 1 = grey, 2 = black -- used by GC


# Lyra runtime values are either tagged ints (Python int) or Box.
Value = int | Box | None



def tag_int(value: int) -> int:
    """Encode a Python int as a tagged value if it fits."""
    if MIN_TAGGED_INT <= value <= MAX_TAGGED_INT:
        return (value << INT_TAG_SHIFT) | TAG_INT_BIT
    raise OverflowError(f"int {value} out of tagged range; needs boxing")


def is_tagged_int(value: Value) -> bool:
    return isinstance(value, int) and (value & TAG_INT_BIT) == TAG_INT_BIT


def untag_int(value: int) -> int:
    if not (value & TAG_INT_BIT):
        raise ValueError("not a tagged int")
    # Arithmetic right shift to preserve sign.
    if value & (1 << 63):
        return -((((1 << 64) - value) >> INT_TAG_SHIFT))
    return value >> INT_TAG_SHIFT



def alloc_string(text: str) -> Box:
    return Box(class_id=CLASS_STRING, payload=text)


def alloc_float(value: float) -> Box:
    return Box(class_id=CLASS_FLOAT, payload=value)


def alloc_bigint(value: int) -> Box:
    return Box(class_id=CLASS_BIGINT, payload=value)


def alloc_tuple(fields: list[Value]) -> Box:
    return Box(class_id=CLASS_TUPLE, payload=list(fields))


def alloc_record(field_names: list[str], values: list[Value]) -> Box:
    return Box(class_id=CLASS_RECORD, payload=dict(zip(field_names, values)))


def alloc_data(tag: int, args: list[Value]) -> Box:
    return Box(class_id=CLASS_DATA, payload=(tag, list(args)))


def alloc_closure(function_label: str, upvalues: list[Value]) -> Box:
    return Box(class_id=CLASS_CLOSURE, payload=(function_label, list(upvalues)))


def alloc_list(elements: list[Value]) -> Box:
    return Box(class_id=CLASS_LIST, payload=list(elements))


def alloc_map(entries: dict[Value, Value]) -> Box:
    return Box(class_id=CLASS_MAP, payload=dict(entries))


def alloc_foreign(handle: object) -> Box:
    return Box(class_id=CLASS_FOREIGN, payload=handle)



def is_string(value: Value) -> bool:
    return isinstance(value, Box) and value.class_id == CLASS_STRING


def is_float(value: Value) -> bool:
    return isinstance(value, Box) and value.class_id == CLASS_FLOAT


def is_data(value: Value) -> bool:
    return isinstance(value, Box) and value.class_id == CLASS_DATA


def is_closure(value: Value) -> bool:
    return isinstance(value, Box) and value.class_id == CLASS_CLOSURE


def is_tuple(value: Value) -> bool:
    return isinstance(value, Box) and value.class_id == CLASS_TUPLE


def is_record(value: Value) -> bool:
    return isinstance(value, Box) and value.class_id == CLASS_RECORD



def equal(a: Value, b: Value) -> bool:
    if a is b:
        return True
    if isinstance(a, int) and isinstance(b, int):
        return a == b
    if isinstance(a, Box) and isinstance(b, Box):
        if a.class_id != b.class_id:
            return False
        if a.class_id in {CLASS_STRING, CLASS_FLOAT, CLASS_BIGINT, CLASS_FOREIGN}:
            return a.payload == b.payload
        if a.class_id == CLASS_TUPLE:
            return all(equal(x, y) for x, y in zip(a.payload, b.payload))
        if a.class_id == CLASS_DATA:
            (tag_a, args_a) = a.payload
            (tag_b, args_b) = b.payload
            return tag_a == tag_b and all(equal(x, y) for x, y in zip(args_a, args_b))
        if a.class_id == CLASS_LIST:
            return len(a.payload) == len(b.payload) and \
                all(equal(x, y) for x, y in zip(a.payload, b.payload))
        if a.class_id == CLASS_RECORD:
            return a.payload.keys() == b.payload.keys() and \
                all(equal(a.payload[k], b.payload[k]) for k in a.payload)
    return False


def value_repr(value: Value) -> str:
    if value is None:
        return "()"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, Box):
        if value.class_id == CLASS_STRING:
            return repr(value.payload)
        if value.class_id == CLASS_FLOAT:
            return repr(value.payload)
        if value.class_id == CLASS_DATA:
            tag, args = value.payload
            inner = ", ".join(value_repr(a) for a in args)
            return f"#{tag}({inner})"
        if value.class_id == CLASS_TUPLE:
            return "(" + ", ".join(value_repr(a) for a in value.payload) + ")"
        if value.class_id == CLASS_RECORD:
            return "{" + ", ".join(f"{k}: {value_repr(v)}" for k, v in value.payload.items()) + "}"
        if value.class_id == CLASS_CLOSURE:
            label, _ = value.payload
            return f"<closure {label}>"
        if value.class_id == CLASS_LIST:
            return "[" + ", ".join(value_repr(x) for x in value.payload) + "]"
    return repr(value)
