from lyra.optimize.passes import (
    constant_fold,
    dead_code_elim,
    mark_tail_calls,
    optimize,
)

__all__ = ["optimize", "constant_fold", "dead_code_elim", "mark_tail_calls"]
