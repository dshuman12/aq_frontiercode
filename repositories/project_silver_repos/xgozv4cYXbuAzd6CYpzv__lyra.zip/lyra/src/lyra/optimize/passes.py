from __future__ import annotations

from collections import Counter
from typing import Iterable

from lyra.ir import nodes as I



def optimize(module: I.Module, *, max_passes: int = 4) -> I.Module:
    for _ in range(max_passes):
        before = _module_signature(module)
        constant_fold(module)
        dead_code_elim(module)
        mark_tail_calls(module)
        if before == _module_signature(module):
            break
    return module



def constant_fold(module: I.Module) -> None:
    for func in module.functions:
        if func.body is not None:
            _fold_block(func.body)
    for binding in module.globals_:
        binding.expr = _maybe_fold_expr(binding.expr)


def _fold_block(block: I.Block) -> None:
    for binding in block.bindings:
        binding.expr = _maybe_fold_expr(binding.expr)
        if isinstance(binding.expr, I.IfExpr):
            if binding.expr.then_block is not None:
                _fold_block(binding.expr.then_block)
            if binding.expr.else_block is not None:
                _fold_block(binding.expr.else_block)
        if isinstance(binding.expr, I.MatchTagExpr):
            for _, body in binding.expr.arms:
                _fold_block(body)
            if binding.expr.default is not None:
                _fold_block(binding.expr.default)


def _maybe_fold_expr(expr: I.Expr) -> I.Expr:
    if isinstance(expr, I.PrimExpr):
        if all(isinstance(a, (I.IntAtom, I.FloatAtom, I.BoolAtom)) for a in expr.args):
            value = _apply_prim(expr.name, expr.args)
            if value is not None:
                return I.AtomExpr(atom=value)
    return expr


def _apply_prim(name: str, args: list[I.Atom]) -> I.Atom | None:
    if name == "int_add" and len(args) == 2:
        a, b = args[0], args[1]
        if isinstance(a, I.IntAtom) and isinstance(b, I.IntAtom):
            return I.IntAtom(value=a.value + b.value)
    if name == "int_sub" and len(args) == 2:
        a, b = args[0], args[1]
        if isinstance(a, I.IntAtom) and isinstance(b, I.IntAtom):
            return I.IntAtom(value=a.value - b.value)
    if name == "int_mul" and len(args) == 2:
        a, b = args[0], args[1]
        if isinstance(a, I.IntAtom) and isinstance(b, I.IntAtom):
            return I.IntAtom(value=a.value * b.value)
    if name == "bool_not" and len(args) == 1:
        a = args[0]
        if isinstance(a, I.BoolAtom):
            return I.BoolAtom(value=not a.value)
    return None



def dead_code_elim(module: I.Module) -> None:
    for func in module.functions:
        if func.body is not None:
            _dce_block(func.body)


def _dce_block(block: I.Block) -> None:
    used = _used_names_in_block(block)
    new_bindings: list[I.Binding] = []
    # Walk in reverse to compute liveness incrementally.
    for binding in reversed(block.bindings):
        if binding.name in used or _has_side_effect(binding.expr):
            new_bindings.append(binding)
            used |= _used_in_expr(binding.expr)
    block.bindings = list(reversed(new_bindings))
    for binding in block.bindings:
        if isinstance(binding.expr, I.IfExpr):
            if binding.expr.then_block is not None:
                _dce_block(binding.expr.then_block)
            if binding.expr.else_block is not None:
                _dce_block(binding.expr.else_block)
        if isinstance(binding.expr, I.MatchTagExpr):
            for _, body in binding.expr.arms:
                _dce_block(body)
            if binding.expr.default is not None:
                _dce_block(binding.expr.default)


def _has_side_effect(expr: I.Expr) -> bool:
    return isinstance(expr, (I.CallExpr, I.PrimExpr, I.AllocExpr))


def _used_names_in_block(block: I.Block) -> set[str]:
    used: set[str] = set()
    if isinstance(block.result, I.Atom):
        used |= _used_in_atom(block.result)
    elif isinstance(block.result, I.Expr):
        used |= _used_in_expr(block.result)
    return used


def _used_in_atom(atom: I.Atom) -> set[str]:
    if isinstance(atom, I.VarAtom):
        return {atom.name}
    return set()


def _used_in_expr(expr: I.Expr) -> set[str]:
    out: set[str] = set()
    if isinstance(expr, I.AtomExpr) and expr.atom is not None:
        out |= _used_in_atom(expr.atom)
    elif isinstance(expr, I.CallExpr):
        if expr.func is not None:
            out |= _used_in_atom(expr.func)
        for a in expr.args:
            out |= _used_in_atom(a)
    elif isinstance(expr, I.PrimExpr):
        for a in expr.args:
            out |= _used_in_atom(a)
    elif isinstance(expr, I.AllocExpr):
        for f in expr.fields:
            out |= _used_in_atom(f)
    elif isinstance(expr, I.GetFieldExpr) and expr.target is not None:
        out |= _used_in_atom(expr.target)
    elif isinstance(expr, I.ClosureExpr):
        for u in expr.upvalues:
            out |= _used_in_atom(u)
    elif isinstance(expr, I.IfExpr):
        if expr.cond is not None:
            out |= _used_in_atom(expr.cond)
        if expr.then_block is not None:
            out |= _used_names_in_block(expr.then_block)
        if expr.else_block is not None:
            out |= _used_names_in_block(expr.else_block)
    elif isinstance(expr, I.MatchTagExpr):
        if expr.scrutinee is not None:
            out |= _used_in_atom(expr.scrutinee)
        for _, body in expr.arms:
            out |= _used_names_in_block(body)
        if expr.default is not None:
            out |= _used_names_in_block(expr.default)
    return out



def mark_tail_calls(module: I.Module) -> None:
    for func in module.functions:
        if func.body is not None:
            _mark_block_tail(func.body)


def _mark_block_tail(block: I.Block) -> None:
    if not block.bindings:
        return
    last_binding = block.bindings[-1]
    if isinstance(block.result, I.VarAtom) and block.result.name == last_binding.name:
        if isinstance(last_binding.expr, I.CallExpr):
            last_binding.expr.is_tail = True
        elif isinstance(last_binding.expr, I.IfExpr):
            if last_binding.expr.then_block is not None:
                _mark_block_tail(last_binding.expr.then_block)
            if last_binding.expr.else_block is not None:
                _mark_block_tail(last_binding.expr.else_block)
        elif isinstance(last_binding.expr, I.MatchTagExpr):
            for _, body in last_binding.expr.arms:
                _mark_block_tail(body)
            if last_binding.expr.default is not None:
                _mark_block_tail(last_binding.expr.default)



def _module_signature(module: I.Module) -> tuple:
    """Hashable signature so the driver can detect a fixed point."""
    return tuple((fn.label, len(fn.body.bindings) if fn.body else 0)
                 for fn in module.functions)
