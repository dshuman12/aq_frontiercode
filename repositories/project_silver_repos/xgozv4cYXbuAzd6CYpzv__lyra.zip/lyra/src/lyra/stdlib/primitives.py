from __future__ import annotations

import sys
from typing import Callable, Iterable

from lyra.errors import (
    DivisionByZero,
    TypeMismatchAtRuntime,
    UncaughtUserException,
)
from lyra.objects.model import (
    Box,
    Value,
    alloc_data,
    alloc_string,
    is_string,
    value_repr,
)


HandlerFn = Callable[..., None]



def _pop_int(frame) -> int:
    value = frame.pop()
    if not isinstance(value, int) or isinstance(value, bool):
        raise TypeMismatchAtRuntime(f"expected int, got {value!r}")
    return value


def _pop_bool(frame) -> bool:
    value = frame.pop()
    if not isinstance(value, bool):
        raise TypeMismatchAtRuntime(f"expected bool, got {value!r}")
    return value


def _pop_string(frame) -> str:
    value = frame.pop()
    if not is_string(value):
        raise TypeMismatchAtRuntime(f"expected string, got {value!r}")
    return value.payload  # type: ignore[union-attr]


def prim_int_add(vm, frame) -> None:
    b = _pop_int(frame); a = _pop_int(frame)
    frame.push(a + b)


def prim_int_sub(vm, frame) -> None:
    b = _pop_int(frame); a = _pop_int(frame)
    frame.push(a - b)


def prim_int_mul(vm, frame) -> None:
    b = _pop_int(frame); a = _pop_int(frame)
    frame.push(a * b)


def prim_int_div(vm, frame) -> None:
    b = _pop_int(frame); a = _pop_int(frame)
    if b == 0:
        raise DivisionByZero("integer division by zero")
    frame.push(a // b)


def prim_int_mod(vm, frame) -> None:
    b = _pop_int(frame); a = _pop_int(frame)
    if b == 0:
        raise DivisionByZero("integer modulo by zero")
    frame.push(a % b)


def prim_int_neg(vm, frame) -> None:
    a = _pop_int(frame)
    frame.push(-a)



def _pop_two(frame):
    b = frame.pop(); a = frame.pop()
    return a, b


def prim_eq(vm, frame) -> None:
    a, b = _pop_two(frame)
    frame.push(a == b)


def prim_ne(vm, frame) -> None:
    a, b = _pop_two(frame)
    frame.push(a != b)


def prim_lt(vm, frame) -> None:
    a, b = _pop_two(frame)
    frame.push(_compare(a, b) < 0)


def prim_le(vm, frame) -> None:
    a, b = _pop_two(frame)
    frame.push(_compare(a, b) <= 0)


def prim_gt(vm, frame) -> None:
    a, b = _pop_two(frame)
    frame.push(_compare(a, b) > 0)


def prim_ge(vm, frame) -> None:
    a, b = _pop_two(frame)
    frame.push(_compare(a, b) >= 0)


def _compare(a: Value, b: Value) -> int:
    if isinstance(a, int) and isinstance(b, int):
        return (a > b) - (a < b)
    if is_string(a) and is_string(b):
        sa, sb = a.payload, b.payload  # type: ignore[union-attr]
        return (sa > sb) - (sa < sb)
    raise TypeMismatchAtRuntime(f"cannot compare {a!r} and {b!r}")



def prim_bool_and(vm, frame) -> None:
    b = _pop_bool(frame); a = _pop_bool(frame)
    frame.push(a and b)


def prim_bool_or(vm, frame) -> None:
    b = _pop_bool(frame); a = _pop_bool(frame)
    frame.push(a or b)


def prim_bool_not(vm, frame) -> None:
    a = _pop_bool(frame)
    frame.push(not a)



def prim_string_concat(vm, frame) -> None:
    b = _pop_string(frame); a = _pop_string(frame)
    frame.push(alloc_string(a + b))


def prim_string_length(vm, frame) -> None:
    s = _pop_string(frame)
    frame.push(len(s))



def prim_print(vm, frame) -> None:
    value = frame.pop()
    sys.stdout.write(value_repr(value))
    frame.push(None)


def prim_println(vm, frame) -> None:
    value = frame.pop()
    sys.stdout.write(value_repr(value) + "\n")
    sys.stdout.flush()
    frame.push(None)


def prim_read_line(vm, frame) -> None:
    line = sys.stdin.readline()
    if line.endswith("\n"):
        line = line[:-1]
    frame.push(alloc_string(line))



def prim_list_cons(vm, frame) -> None:
    tail = frame.pop()
    head = frame.pop()
    frame.push(alloc_data(1, [head, tail]))  # tag 1 = Cons


def prim_list_head(vm, frame) -> None:
    value = frame.pop()
    if not isinstance(value, Box) or value.payload[0] != 1:
        raise TypeMismatchAtRuntime("head of empty list")
    frame.push(value.payload[1][0])


def prim_list_tail(vm, frame) -> None:
    value = frame.pop()
    if not isinstance(value, Box) or value.payload[0] != 1:
        raise TypeMismatchAtRuntime("tail of empty list")
    frame.push(value.payload[1][1])


def prim_list_is_empty(vm, frame) -> None:
    value = frame.pop()
    if not isinstance(value, Box):
        raise TypeMismatchAtRuntime("list_is_empty on non-list")
    frame.push(value.payload[0] == 0)



def prim_panic(vm, frame) -> None:
    message = _pop_string(frame)
    raise UncaughtUserException(f"panic: {message}")


def prim_assert(vm, frame) -> None:
    cond = frame.pop()
    if not cond:
        raise UncaughtUserException("assertion failed")
    frame.push(None)



PRIMITIVE_TABLE: dict[int, HandlerFn] = {
    0x01: prim_int_add,
    0x02: prim_int_sub,
    0x03: prim_int_mul,
    0x04: prim_int_div,
    0x05: prim_int_mod,
    0x06: prim_int_neg,
    0x10: prim_eq,
    0x11: prim_ne,
    0x12: prim_lt,
    0x13: prim_le,
    0x14: prim_gt,
    0x15: prim_ge,
    0x20: prim_bool_and,
    0x21: prim_bool_or,
    0x22: prim_bool_not,
    0x30: prim_string_concat,
    0x31: prim_string_length,
    0x40: prim_print,
    0x41: prim_println,
    0x42: prim_read_line,
    0x50: prim_list_cons,
    0x51: prim_list_head,
    0x52: prim_list_tail,
    0x53: prim_list_is_empty,
    0xF0: prim_panic,
    0xF1: prim_assert,
}


def install_primitives(vm) -> None:
    vm.primitives.update(PRIMITIVE_TABLE)
