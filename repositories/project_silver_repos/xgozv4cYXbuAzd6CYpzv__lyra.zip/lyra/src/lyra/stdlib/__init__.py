from lyra.stdlib.primitives import PRIMITIVE_TABLE, install_primitives

__all__ = ["PRIMITIVE_TABLE", "install_primitives"]
