from __future__ import annotations

from lyra.types.repr import (
    T_BOOL,
    T_INT,
    T_STRING,
    T_UNIT,
    TApp,
    TForall,
    TFun,
    TVar,
    fresh_var,
)


def build_prelude() -> dict[str, object]:
    """Return ``{name: Type}`` for every name the prelude exposes."""
    a = fresh_var(level=1, prefix="a")
    bindings: dict[str, object] = {
        "println": TForall(
            bound=[a], body=TFun(params=[a], result=T_UNIT),
        ),
        "print": TForall(
            bound=[a], body=TFun(params=[a], result=T_UNIT),
        ),
        "read_line": TFun(params=[T_UNIT], result=T_STRING),
        "panic": TFun(params=[T_STRING], result=T_UNIT),
        "assert": TFun(params=[T_BOOL], result=T_UNIT),
        "string_length": TFun(params=[T_STRING], result=T_INT),
    }
    return bindings


def list_type(elem: object) -> object:
    return TApp(name="List", args=[elem])  # type: ignore[arg-type]


def maybe_type(elem: object) -> object:
    return TApp(name="Maybe", args=[elem])  # type: ignore[arg-type]
