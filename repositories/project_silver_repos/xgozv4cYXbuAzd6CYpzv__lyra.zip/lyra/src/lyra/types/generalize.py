from __future__ import annotations

from lyra.types.repr import (
    TApp,
    TFun,
    TForall,
    TRecord,
    TTuple,
    TVar,
    Type,
    fresh_var,
)


def generalize(ty: Type, *, level: int) -> Type:
    """Wrap free type variables whose level > ``level`` in a ``forall``."""
    free = [v for v in ty.find().free_vars() if v.is_unbound() and v.level > level]
    if not free:
        return ty
    return TForall(bound=free, body=ty)


def instantiate(ty: Type, *, level: int) -> Type:
    """Replace each ``forall``-bound variable with a fresh unification var."""
    root = ty.find() if isinstance(ty, TVar) else ty
    if not isinstance(root, TForall) or root.body is None:
        return root
    mapping: dict[int, TVar] = {
        id(b): fresh_var(level=level, prefix=b.name) for b in root.bound
    }
    return _substitute(root.body, mapping)


def _substitute(ty: Type, mapping: dict[int, TVar]) -> Type:
    root = ty.find() if isinstance(ty, TVar) else ty
    if isinstance(root, TVar):
        return mapping.get(id(root), root)
    if isinstance(root, TFun):
        return TFun(
            params=[_substitute(p, mapping) for p in root.params],
            result=_substitute(root.result, mapping) if root.result is not None else None,
        )
    if isinstance(root, TApp):
        return TApp(
            name=root.name,
            args=[_substitute(a, mapping) for a in root.args],
        )
    if isinstance(root, TTuple):
        return TTuple(elements=[_substitute(e, mapping) for e in root.elements])
    if isinstance(root, TRecord):
        return TRecord(
            fields={k: _substitute(v, mapping) for k, v in root.fields.items()}
        )
    if isinstance(root, TForall) and root.body is not None:
        # Avoid capture by renaming bound vars in the inner forall.
        inner_mapping = dict(mapping)
        for b in root.bound:
            if id(b) in inner_mapping:
                inner_mapping.pop(id(b))
        new_body = _substitute(root.body, inner_mapping)
        return TForall(bound=root.bound, body=new_body)
    return root
