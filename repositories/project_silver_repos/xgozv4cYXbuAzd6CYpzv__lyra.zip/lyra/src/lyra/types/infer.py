from __future__ import annotations

from typing import Sequence

from lyra.errors import TypeError_, UndefinedName
from lyra.parser import ast as A
from lyra.types.env import ConstructorScheme, TypeEnv, make_initial_env
from lyra.types.generalize import generalize, instantiate
from lyra.types.repr import (
    T_BOOL,
    T_CHAR,
    T_FLOAT,
    T_INT,
    T_STRING,
    T_UNIT,
    TApp,
    TConst,
    TFun,
    TRecord,
    TTuple,
    TVar,
    Type,
    fresh_var,
)
from lyra.types.unify import unify


class InferenceContext:
    def __init__(self, env: TypeEnv | None = None) -> None:
        self.env = env or make_initial_env()
        self.level = 0

    def enter_level(self) -> None:
        self.level += 1

    def exit_level(self) -> None:
        self.level -= 1

    def fresh(self, prefix: str = "t") -> TVar:
        return fresh_var(level=self.level, prefix=prefix)



def infer_module(module: A.Module, *, env: TypeEnv | None = None) -> dict[str, Type]:
    ctx = InferenceContext(env)
    types: dict[str, Type] = {}
    for decl in module.declarations:
        if isinstance(decl, A.LetDecl):
            for binding in decl.bindings:
                _infer_binding(ctx, binding, top_level=True)
                if isinstance(binding.pattern, A.PVar):
                    ty = ctx.env.lookup(binding.pattern.name)
                    if ty is not None:
                        types[binding.pattern.name] = ty
        elif isinstance(decl, A.TypeDecl):
            _register_type_decl(ctx, decl)
        elif isinstance(decl, A.TypeAlias):
            _register_type_alias(ctx, decl)
        elif isinstance(decl, A.ImportDecl):
            # Imports are wired up by the module loader; the type
            # checker just trusts the env.
            continue
        elif isinstance(decl, A.ExportDecl):
            continue
        elif isinstance(decl, A.ExternDecl):
            ty = _from_type_expr(ctx, decl.target_type) if decl.target_type else ctx.fresh()
            ctx.env.define(decl.name, ty)
            types[decl.name] = ty
    return types


def infer_expression(expr: A.Expr, *, env: TypeEnv | None = None) -> Type:
    ctx = InferenceContext(env)
    return _infer(ctx, expr)



def _infer(ctx: InferenceContext, expr: A.Expr) -> Type:
    if isinstance(expr, A.IntLit):
        return T_INT
    if isinstance(expr, A.FloatLit):
        return T_FLOAT
    if isinstance(expr, A.StringLit):
        return T_STRING
    if isinstance(expr, A.BoolLit):
        return T_BOOL
    if isinstance(expr, A.CharLit):
        return T_CHAR
    if isinstance(expr, A.UnitLit):
        return T_UNIT
    if isinstance(expr, A.Var):
        return _infer_var(ctx, expr)
    if isinstance(expr, A.Lambda):
        return _infer_lambda(ctx, expr)
    if isinstance(expr, A.App):
        return _infer_app(ctx, expr)
    if isinstance(expr, A.Let):
        return _infer_let(ctx, expr)
    if isinstance(expr, A.If):
        return _infer_if(ctx, expr)
    if isinstance(expr, A.Match):
        return _infer_match(ctx, expr)
    if isinstance(expr, A.Tuple):
        return TTuple(elements=[_infer(ctx, e) for e in expr.elements])
    if isinstance(expr, A.Record):
        return TRecord(fields={k: _infer(ctx, v) for k, v in expr.fields})
    if isinstance(expr, A.FieldAccess):
        return _infer_field_access(ctx, expr)
    if isinstance(expr, A.BinOp):
        return _infer_binop(ctx, expr)
    if isinstance(expr, A.UnaryOp):
        return _infer_unaryop(ctx, expr)
    if isinstance(expr, A.Annot):
        target = _from_type_expr(ctx, expr.target_type) if expr.target_type else ctx.fresh()
        actual = _infer(ctx, expr.expr) if expr.expr else target
        unify(actual, target)
        return target
    if isinstance(expr, A.Sequence_):
        last_ty: Type = T_UNIT
        for stmt in expr.statements:
            last_ty = _infer(ctx, stmt)
        return last_ty
    raise TypeError_(f"unsupported expression node: {type(expr).__name__}")


def _infer_var(ctx: InferenceContext, expr: A.Var) -> Type:
    ty = ctx.env.lookup(expr.name)
    if ty is None:
        raise UndefinedName(f"unbound name: {expr.name}", position=expr.position)
    return instantiate(ty, level=ctx.level)


def _infer_lambda(ctx: InferenceContext, expr: A.Lambda) -> Type:
    saved = ctx.env
    ctx.env = ctx.env.child()
    param_types: list[Type] = []
    try:
        for pat in expr.params:
            ty = ctx.fresh()
            param_types.append(ty)
            _bind_pattern(ctx, pat, ty)
        body_ty = _infer(ctx, expr.body) if expr.body else T_UNIT
    finally:
        ctx.env = saved
    return TFun(params=param_types, result=body_ty)


def _infer_app(ctx: InferenceContext, expr: A.App) -> Type:
    func_ty = _infer(ctx, expr.func) if expr.func else ctx.fresh()
    arg_types = [_infer(ctx, arg) for arg in expr.args]
    result_ty = ctx.fresh()
    unify(func_ty, TFun(params=arg_types, result=result_ty))
    return result_ty


def _infer_let(ctx: InferenceContext, expr: A.Let) -> Type:
    saved = ctx.env
    ctx.env = ctx.env.child()
    try:
        for binding in expr.bindings:
            _infer_binding(ctx, binding, top_level=False)
        return _infer(ctx, expr.body) if expr.body else T_UNIT
    finally:
        ctx.env = saved


def _infer_if(ctx: InferenceContext, expr: A.If) -> Type:
    cond_ty = _infer(ctx, expr.cond) if expr.cond else T_UNIT
    unify(cond_ty, T_BOOL)
    then_ty = _infer(ctx, expr.then_branch) if expr.then_branch else T_UNIT
    else_ty = _infer(ctx, expr.else_branch) if expr.else_branch else T_UNIT
    unify(then_ty, else_ty)
    return then_ty


def _infer_match(ctx: InferenceContext, expr: A.Match) -> Type:
    scrutinee_ty = _infer(ctx, expr.scrutinee) if expr.scrutinee else ctx.fresh()
    result_ty = ctx.fresh()
    for arm in expr.arms:
        saved = ctx.env
        ctx.env = ctx.env.child()
        try:
            _bind_pattern(ctx, arm.pattern, scrutinee_ty)
            if arm.guard is not None:
                guard_ty = _infer(ctx, arm.guard)
                unify(guard_ty, T_BOOL)
            arm_ty = _infer(ctx, arm.body) if arm.body else T_UNIT
            unify(arm_ty, result_ty)
        finally:
            ctx.env = saved
    return result_ty


def _infer_binop(ctx: InferenceContext, expr: A.BinOp) -> Type:
    left = _infer(ctx, expr.left) if expr.left else ctx.fresh()
    right = _infer(ctx, expr.right) if expr.right else ctx.fresh()
    op = expr.op
    if op in {"+", "-", "*", "/", "%"}:
        unify(left, right)
        return left
    if op == "++":
        unify(left, T_STRING)
        unify(right, T_STRING)
        return T_STRING
    if op in {"==", "!=", "<", "<=", ">", ">="}:
        unify(left, right)
        return T_BOOL
    if op in {"&&", "||"}:
        unify(left, T_BOOL)
        unify(right, T_BOOL)
        return T_BOOL
    raise TypeError_(f"unsupported binary operator: {op}")


def _infer_unaryop(ctx: InferenceContext, expr: A.UnaryOp) -> Type:
    operand = _infer(ctx, expr.operand) if expr.operand else ctx.fresh()
    if expr.op == "-":
        return operand
    if expr.op == "!":
        unify(operand, T_BOOL)
        return T_BOOL
    raise TypeError_(f"unsupported unary operator: {expr.op}")


def _infer_field_access(ctx: InferenceContext, expr: A.FieldAccess) -> Type:
    target = _infer(ctx, expr.target) if expr.target else ctx.fresh()
    field_ty = ctx.fresh()
    record_ty = TRecord(fields={expr.field: field_ty})
    unify(target, record_ty)
    return field_ty



def _infer_binding(ctx: InferenceContext, binding: A.Binding, *, top_level: bool) -> None:
    ctx.enter_level()
    try:
        if binding.rec and isinstance(binding.pattern, A.PVar):
            placeholder = ctx.fresh()
            ctx.env.define(binding.pattern.name, placeholder)
            body_ty = _infer(ctx, binding.expr) if binding.expr else T_UNIT
            unify(placeholder, body_ty)
        else:
            body_ty = _infer(ctx, binding.expr) if binding.expr else T_UNIT
            _bind_pattern(ctx, binding.pattern, body_ty)
        if binding.annotation is not None:
            annotation_ty = _from_type_expr(ctx, binding.annotation)
            unify(body_ty, annotation_ty)
    finally:
        ctx.exit_level()
    # Generalize after we've left the higher level so anything still
    # at level > current must be free with respect to the outer scope.
    if isinstance(binding.pattern, A.PVar):
        existing = ctx.env.lookup(binding.pattern.name)
        if existing is not None:
            generalised = generalize(existing, level=ctx.level)
            ctx.env.define(binding.pattern.name, generalised)


def _bind_pattern(ctx: InferenceContext, pattern: A.Pattern | None, expected: Type) -> None:
    if pattern is None:
        return
    if isinstance(pattern, A.PVar):
        ctx.env.define(pattern.name, expected)
        return
    if isinstance(pattern, A.PWild):
        return
    if isinstance(pattern, A.PInt):
        unify(expected, T_INT)
        return
    if isinstance(pattern, A.PFloat):
        unify(expected, T_FLOAT)
        return
    if isinstance(pattern, A.PString):
        unify(expected, T_STRING)
        return
    if isinstance(pattern, A.PBool):
        unify(expected, T_BOOL)
        return
    if isinstance(pattern, A.PChar):
        unify(expected, T_CHAR)
        return
    if isinstance(pattern, A.PCon):
        scheme = ctx.env.lookup_constructor(pattern.name)
        if scheme is None:
            raise UndefinedName(
                f"unknown constructor {pattern.name!r}", position=pattern.position
            )
        # Instantiate the constructor's type parameters.
        mapping: dict[int, TVar] = {}
        for name in scheme.type_params:
            placeholder = ctx.fresh(prefix=name)
            mapping[hash(name)] = placeholder  # noqa: not used; keeping shape simple
        # Simple monomorphic instantiation: build fresh type variables
        # for each type parameter and substitute via name lookup.
        var_for: dict[str, TVar] = {n: ctx.fresh(prefix=n) for n in scheme.type_params}
        instantiated_args = [_substitute_named(t, var_for) for t in scheme.arg_types]
        instantiated_result = _substitute_named(scheme.result_type, var_for)
        unify(expected, instantiated_result)
        if len(pattern.args) != len(instantiated_args):
            raise TypeError_(
                f"constructor {pattern.name!r} expects {len(instantiated_args)} args, "
                f"got {len(pattern.args)}",
                position=pattern.position,
            )
        for sub_pat, sub_ty in zip(pattern.args, instantiated_args):
            _bind_pattern(ctx, sub_pat, sub_ty)
        return
    if isinstance(pattern, A.PTuple):
        elements = [ctx.fresh() for _ in pattern.elements]
        unify(expected, TTuple(elements=elements))
        for sub, ty in zip(pattern.elements, elements):
            _bind_pattern(ctx, sub, ty)
        return
    if isinstance(pattern, A.POr):
        for option in pattern.options:
            _bind_pattern(ctx, option, expected)
        return
    if isinstance(pattern, A.PAs):
        ctx.env.define(pattern.name, expected)
        if pattern.inner is not None:
            _bind_pattern(ctx, pattern.inner, expected)
        return
    raise TypeError_(f"unsupported pattern: {type(pattern).__name__}")



def _from_type_expr(ctx: InferenceContext, expr: A.TypeExpr) -> Type:
    if isinstance(expr, A.TyVar):
        # Type-level variables in source are quantified at the top-level
        # forall; for a free `a` inside an annotation we conjure a fresh
        # unification variable so `id : a -> a` works.
        existing = ctx.env.lookup(expr.name)
        if isinstance(existing, TVar):
            return existing
        var = ctx.fresh(prefix=expr.name)
        ctx.env.define(expr.name, var)
        return var
    if isinstance(expr, A.TyCon):
        if expr.name in {"Int", "Bool", "Float", "String", "Char", "Unit"}:
            base = TConst(name=expr.name)
        else:
            base = TApp(name=expr.name, args=[])
        if not expr.args:
            return base
        return TApp(name=expr.name, args=[_from_type_expr(ctx, a) for a in expr.args])
    if isinstance(expr, A.TyFun):
        return TFun(
            params=[_from_type_expr(ctx, p) for p in expr.params],
            result=_from_type_expr(ctx, expr.result) if expr.result else T_UNIT,
        )
    if isinstance(expr, A.TyTuple):
        return TTuple(elements=[_from_type_expr(ctx, e) for e in expr.elements])
    if isinstance(expr, A.TyRecord):
        return TRecord(fields={k: _from_type_expr(ctx, v) for k, v in expr.fields})
    if isinstance(expr, A.TyForall):
        body = _from_type_expr(ctx, expr.body) if expr.body else T_UNIT
        return body
    raise TypeError_(f"unknown type expression: {type(expr).__name__}")


def _substitute_named(ty: Type, mapping: dict[str, TVar]) -> Type:
    if isinstance(ty, TVar) and ty.name in mapping:
        return mapping[ty.name]
    if isinstance(ty, TFun):
        return TFun(
            params=[_substitute_named(p, mapping) for p in ty.params],
            result=_substitute_named(ty.result, mapping) if ty.result else None,
        )
    if isinstance(ty, TApp):
        return TApp(name=ty.name, args=[_substitute_named(a, mapping) for a in ty.args])
    if isinstance(ty, TTuple):
        return TTuple(elements=[_substitute_named(e, mapping) for e in ty.elements])
    if isinstance(ty, TRecord):
        return TRecord(fields={k: _substitute_named(v, mapping) for k, v in ty.fields.items()})
    return ty


def _register_type_decl(ctx: InferenceContext, decl: A.TypeDecl) -> None:
    type_var_lookup = {p: fresh_var(level=ctx.level, prefix=p) for p in decl.params}
    result_args = [type_var_lookup[p] for p in decl.params]
    result_type: Type = (
        TConst(name=decl.name) if not decl.params else TApp(name=decl.name, args=result_args)
    )
    for con in decl.constructors:
        arg_types = [_from_type_expr(ctx, t) for t in con.fields]
        # Substitute named TVars from the param scope where the AST
        # uses the same name -- our _from_type_expr helper already
        # registered them in the env on encounter.
        scheme = ConstructorScheme(
            name=con.name,
            type_params=list(decl.params),
            arg_types=arg_types,
            result_type=result_type,
            arity=len(arg_types),
        )
        ctx.env.define_constructor(con.name, scheme)


def _register_type_alias(ctx: InferenceContext, decl: A.TypeAlias) -> None:
    if decl.body is None:
        return
    ty = _from_type_expr(ctx, decl.body)
    ctx.env.define_alias(decl.name, ty)
