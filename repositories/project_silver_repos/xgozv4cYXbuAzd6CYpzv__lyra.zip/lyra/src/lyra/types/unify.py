from __future__ import annotations

from typing import Iterable

from lyra.errors import OccursCheckError, UnificationError
from lyra.types.repr import (
    TApp,
    TConst,
    TFun,
    TRecord,
    TTuple,
    TVar,
    Type,
    adjust_levels,
)


def unify(a: Type, b: Type) -> None:
    """Unify two types, mutating type variables on the way."""
    a = a.find() if isinstance(a, TVar) else a
    b = b.find() if isinstance(b, TVar) else b
    if a is b:
        return
    if isinstance(a, TVar):
        _bind(a, b)
        return
    if isinstance(b, TVar):
        _bind(b, a)
        return
    if isinstance(a, TConst) and isinstance(b, TConst):
        if a.name == b.name:
            return
        raise UnificationError(f"cannot unify {a!r} with {b!r}")
    if isinstance(a, TFun) and isinstance(b, TFun):
        if len(a.params) != len(b.params):
            raise UnificationError(
                f"function arity mismatch: {len(a.params)} vs {len(b.params)}"
            )
        for pa, pb in zip(a.params, b.params):
            unify(pa, pb)
        if a.result is None or b.result is None:
            raise UnificationError("incomplete function type during unification")
        unify(a.result, b.result)
        return
    if isinstance(a, TApp) and isinstance(b, TApp):
        if a.name != b.name:
            raise UnificationError(f"type constructor mismatch: {a.name} vs {b.name}")
        if len(a.args) != len(b.args):
            raise UnificationError(
                f"type constructor arity mismatch on {a.name}: "
                f"{len(a.args)} vs {len(b.args)}"
            )
        for pa, pb in zip(a.args, b.args):
            unify(pa, pb)
        return
    if isinstance(a, TTuple) and isinstance(b, TTuple):
        if len(a.elements) != len(b.elements):
            raise UnificationError(
                f"tuple arity mismatch: {len(a.elements)} vs {len(b.elements)}"
            )
        for pa, pb in zip(a.elements, b.elements):
            unify(pa, pb)
        return
    if isinstance(a, TRecord) and isinstance(b, TRecord):
        if set(a.fields) != set(b.fields):
            extra_a = set(a.fields) - set(b.fields)
            extra_b = set(b.fields) - set(a.fields)
            raise UnificationError(
                f"record field mismatch: only-a={sorted(extra_a)} only-b={sorted(extra_b)}"
            )
        for name in a.fields:
            unify(a.fields[name], b.fields[name])
        return
    raise UnificationError(f"cannot unify {a!r} with {b!r}")



def _bind(var: TVar, ty: Type) -> None:
    if not var.is_unbound():
        unify(var.find(), ty)
        return
    target = ty.find() if isinstance(ty, TVar) else ty
    if isinstance(target, TVar) and target is var:
        return
    if _occurs(var, target):
        raise OccursCheckError(
            f"occurs check fails: '{var.name} appears in {target!r}"
        )
    # Lower the level of every free variable in ``ty`` whose level
    # exceeds ours -- otherwise generalize() would over-quantify them.
    adjust_levels(target, max_level=var.level)
    var.forwarded = target


def _occurs(var: TVar, ty: Type) -> bool:
    seen: set[int] = set()
    return _occurs_walk(var, ty, seen)


def _occurs_walk(var: TVar, ty: Type, seen: set[int]) -> bool:
    root = ty.find() if isinstance(ty, TVar) else ty
    rid = id(root)
    if rid in seen:
        return False
    seen.add(rid)
    if root is var:
        return True
    if isinstance(root, TVar):
        return False
    if isinstance(root, TFun):
        if root.result is not None and _occurs_walk(var, root.result, seen):
            return True
        return any(_occurs_walk(var, p, seen) for p in root.params)
    if isinstance(root, TApp):
        return any(_occurs_walk(var, a, seen) for a in root.args)
    if isinstance(root, TTuple):
        return any(_occurs_walk(var, e, seen) for e in root.elements)
    if isinstance(root, TRecord):
        return any(_occurs_walk(var, v, seen) for v in root.fields.values())
    return False


def occurs(var: TVar, ty: Type) -> bool:
    """Public alias for tests."""
    return _occurs(var, ty)
