from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable, Iterator

from lyra.constants import MAX_TYPE_VAR_LEVEL



@dataclass
class Type:
    """Base class for all internal types."""

    def find(self) -> "Type":
        """Path-compress through forwarded type variables."""
        return self

    def free_vars(self) -> set["TVar"]:
        return set()


@dataclass
class TConst(Type):
    """A nullary base type: Int, Bool, String, Unit."""

    name: str = ""

    def __repr__(self) -> str:
        return self.name


@dataclass
class TApp(Type):
    """A type constructor applied to arguments: ``List Int``, ``Map K V``."""

    name: str = ""
    args: list[Type] = field(default_factory=list)

    def free_vars(self) -> set["TVar"]:
        out: set[TVar] = set()
        for a in self.args:
            out |= a.find().free_vars()
        return out

    def __repr__(self) -> str:
        if not self.args:
            return self.name
        return f"{self.name} {' '.join(_paren(a) for a in self.args)}"


@dataclass
class TFun(Type):
    """A function type: ``params -> result``."""

    params: list[Type] = field(default_factory=list)
    result: Type | None = None

    def free_vars(self) -> set["TVar"]:
        out: set[TVar] = set()
        for p in self.params:
            out |= p.find().free_vars()
        if self.result is not None:
            out |= self.result.find().free_vars()
        return out

    def __repr__(self) -> str:
        param_text = " -> ".join(_paren(p) for p in self.params) or "()"
        return f"{param_text} -> {self.result!r}"


@dataclass
class TTuple(Type):
    elements: list[Type] = field(default_factory=list)

    def free_vars(self) -> set["TVar"]:
        out: set[TVar] = set()
        for e in self.elements:
            out |= e.find().free_vars()
        return out

    def __repr__(self) -> str:
        return "(" + ", ".join(repr(e) for e in self.elements) + ")"


@dataclass
class TRecord(Type):
    fields: dict[str, Type] = field(default_factory=dict)

    def free_vars(self) -> set["TVar"]:
        out: set[TVar] = set()
        for v in self.fields.values():
            out |= v.find().free_vars()
        return out

    def __repr__(self) -> str:
        body = ", ".join(f"{k}: {v!r}" for k, v in self.fields.items())
        return "{" + body + "}"


@dataclass
class TVar(Type):
    """A unification / generic variable."""

    name: str = ""
    level: int = 0
    forwarded: "Type | None" = None

    def find(self) -> "Type":
        if self.forwarded is None:
            return self
        # Path-compress.
        root = self.forwarded.find()
        self.forwarded = root
        return root

    def free_vars(self) -> set["TVar"]:
        root = self.find()
        if isinstance(root, TVar):
            return {root}
        return root.free_vars()

    def is_unbound(self) -> bool:
        return self.forwarded is None

    def __repr__(self) -> str:
        root = self.find()
        if root is self:
            return f"'{self.name}@{self.level}"
        return repr(root)


@dataclass
class TForall(Type):
    """Generalised type. The type checker introduces these at let bindings."""

    bound: list[TVar] = field(default_factory=list)
    body: Type | None = None

    def free_vars(self) -> set[TVar]:
        if self.body is None:
            return set()
        return self.body.find().free_vars() - set(self.bound)

    def __repr__(self) -> str:
        names = " ".join(b.name for b in self.bound)
        return f"forall {names}. {self.body!r}"



T_INT = TConst(name="Int")
T_FLOAT = TConst(name="Float")
T_BOOL = TConst(name="Bool")
T_STRING = TConst(name="String")
T_CHAR = TConst(name="Char")
T_UNIT = TConst(name="Unit")



def _paren(ty: Type) -> str:
    root = ty.find() if isinstance(ty, TVar) else ty
    text = repr(root)
    if isinstance(root, (TFun, TForall)):
        return f"({text})"
    return text


_var_seq = 0


def fresh_var(*, level: int, prefix: str = "t") -> TVar:
    global _var_seq
    _var_seq += 1
    return TVar(name=f"{prefix}{_var_seq}", level=min(level, MAX_TYPE_VAR_LEVEL))


def reset_var_counter() -> None:
    global _var_seq
    _var_seq = 0


def adjust_levels(ty: Type, *, max_level: int) -> None:
    """After unification, lower the level of any free var above ``max_level``.

    Required by the level-based generalization trick: when a generic
    variable escapes into the type of an outer binding, its level
    must drop so future generalizations do not overzealously quantify
    it.
    """
    seen: set[int] = set()
    _adjust(ty, max_level, seen)


def _adjust(ty: Type, max_level: int, seen: set[int]) -> None:
    root = ty.find() if isinstance(ty, TVar) else ty
    rid = id(root)
    if rid in seen:
        return
    seen.add(rid)
    if isinstance(root, TVar) and root.is_unbound():
        if root.level > max_level:
            root.level = max_level
        return
    if isinstance(root, TFun):
        for p in root.params:
            _adjust(p, max_level, seen)
        if root.result is not None:
            _adjust(root.result, max_level, seen)
    elif isinstance(root, TApp):
        for a in root.args:
            _adjust(a, max_level, seen)
    elif isinstance(root, TTuple):
        for e in root.elements:
            _adjust(e, max_level, seen)
    elif isinstance(root, TRecord):
        for v in root.fields.values():
            _adjust(v, max_level, seen)
    elif isinstance(root, TForall) and root.body is not None:
        _adjust(root.body, max_level, seen)


def walk(ty: Type) -> Iterator[Type]:
    """Pre-order traversal across the type tree."""
    root = ty.find() if isinstance(ty, TVar) else ty
    yield root
    if isinstance(root, TFun):
        for p in root.params:
            yield from walk(p)
        if root.result is not None:
            yield from walk(root.result)
    elif isinstance(root, TApp):
        for a in root.args:
            yield from walk(a)
    elif isinstance(root, TTuple):
        for e in root.elements:
            yield from walk(e)
    elif isinstance(root, TRecord):
        for v in root.fields.values():
            yield from walk(v)
    elif isinstance(root, TForall) and root.body is not None:
        yield from walk(root.body)
