from __future__ import annotations

import string
from dataclasses import dataclass

from lyra.types.repr import (
    TApp,
    TConst,
    TFun,
    TForall,
    TRecord,
    TTuple,
    TVar,
    Type,
)


@dataclass
class _RenameContext:
    mapping: dict[int, str]
    cursor: int = 0

    def name_for(self, var: TVar) -> str:
        if id(var) not in self.mapping:
            self.mapping[id(var)] = self._next()
        return self.mapping[id(var)]

    def _next(self) -> str:
        # a, b, ..., z, aa, ab, ...
        n = self.cursor
        self.cursor += 1
        if n < 26:
            return string.ascii_lowercase[n]
        return string.ascii_lowercase[n // 26 - 1] + string.ascii_lowercase[n % 26]


def render(ty: Type) -> str:
    ctx = _RenameContext(mapping={})
    return _render(ty, ctx)


def _render(ty: Type, ctx: _RenameContext) -> str:
    root = ty.find() if isinstance(ty, TVar) else ty
    if isinstance(root, TConst):
        return root.name
    if isinstance(root, TVar):
        return "'" + ctx.name_for(root)
    if isinstance(root, TFun):
        params = " -> ".join(_paren(_render(p, ctx), p) for p in root.params)
        result = _render(root.result, ctx) if root.result is not None else "?"
        return f"{params} -> {result}"
    if isinstance(root, TApp):
        if not root.args:
            return root.name
        return root.name + " " + " ".join(_paren(_render(a, ctx), a) for a in root.args)
    if isinstance(root, TTuple):
        return "(" + ", ".join(_render(e, ctx) for e in root.elements) + ")"
    if isinstance(root, TRecord):
        body = ", ".join(f"{k}: {_render(v, ctx)}" for k, v in root.fields.items())
        return "{ " + body + " }"
    if isinstance(root, TForall):
        bound = " ".join("'" + ctx.name_for(v) for v in root.bound)
        body = _render(root.body, ctx) if root.body is not None else "?"
        return f"forall {bound}. {body}"
    return type(root).__name__


def _paren(text: str, ty: Type) -> str:
    root = ty.find() if isinstance(ty, TVar) else ty
    if isinstance(root, (TFun, TForall)):
        return f"({text})"
    return text


def explain(ty: Type) -> str:
    """Verbose form for the REPL: include levels for unification vars."""
    if isinstance(ty, TVar) and ty.is_unbound():
        return f"'{ty.name}@{ty.level}"
    return render(ty)
