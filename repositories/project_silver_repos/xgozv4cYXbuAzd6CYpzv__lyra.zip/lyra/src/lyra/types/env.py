from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable

from lyra.types.repr import TConst, Type


@dataclass
class TypeEnv:
    parent: "TypeEnv | None" = None
    bindings: dict[str, Type] = field(default_factory=dict)
    constructors: dict[str, "ConstructorScheme"] = field(default_factory=dict)
    type_aliases: dict[str, Type] = field(default_factory=dict)

    def lookup(self, name: str) -> Type | None:
        if name in self.bindings:
            return self.bindings[name]
        if self.parent is not None:
            return self.parent.lookup(name)
        return None

    def lookup_constructor(self, name: str) -> "ConstructorScheme | None":
        if name in self.constructors:
            return self.constructors[name]
        if self.parent is not None:
            return self.parent.lookup_constructor(name)
        return None

    def lookup_alias(self, name: str) -> Type | None:
        if name in self.type_aliases:
            return self.type_aliases[name]
        if self.parent is not None:
            return self.parent.lookup_alias(name)
        return None

    def define(self, name: str, ty: Type) -> None:
        self.bindings[name] = ty

    def define_constructor(self, name: str, scheme: "ConstructorScheme") -> None:
        self.constructors[name] = scheme

    def define_alias(self, name: str, ty: Type) -> None:
        self.type_aliases[name] = ty

    def child(self) -> "TypeEnv":
        return TypeEnv(parent=self)

    def names(self) -> Iterable[str]:
        cursor: TypeEnv | None = self
        while cursor is not None:
            yield from cursor.bindings.keys()
            cursor = cursor.parent


@dataclass
class ConstructorScheme:
    """Type of a data constructor: ``forall a... params -> Result a...``."""

    name: str
    type_params: list[str]
    arg_types: list[Type]
    result_type: Type
    arity: int


def make_initial_env() -> TypeEnv:
    """Default environment with built-in operators."""
    from lyra.types.repr import T_BOOL, T_INT, T_STRING

    env = TypeEnv()
    # Comparison operators are polymorphic in their argument; we leave
    # the type as a free variable that the type checker instantiates
    # for each call site.
    return env
