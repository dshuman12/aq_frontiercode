=====
News
=====

Notable changes between releases. Latest at the top.

1.0.0-rc1 (2026-03-27)
----------------------

First release candidate.

0.3.0 (2026-01-27)
------------------

0.2.0 (2025-10-23)
------------------

0.1 (early development)
-----------------------

* Lexer: longest-match operators, nested comments, source positions.
* Parser: recursive-descent w/ Pratt operator precedence; pattern grammar.
* Type system: H-M with level-based generalization, occurs check.
* Pattern matching exhaustiveness; ANF intermediate representation.
* Closure conversion, IR optimizer, bytecode format/disassembler.
* Object model and generational copying GC; write barrier; remembered set.
* VM: tail-call elimination, GC roots iteration over live frames.
* Standard library primitives; module loader with cycle detection.
* CLI: build / run / repl / check / fmt / disasm; bytecode debugger.
* Initial test suite, worked examples, Dockerfile, micro-benchmarks.
* Docs: FAQ, contributing, style, benchmarks page.
* IR printer; diagnostics formatter; resolver pass.
* Architecture and stdlib documentation; new examples.
* Tests: inference, runtime, resolver, emitter, VM basics.
* ModuleSummary; compile-environment cache.
* ReplSession; expanded bytecode and optimizer test coverage.
* Pipeline-stage helpers; resolver / lower / inspect tests.
* Round-trip parser/printer tests, string and import tests, IR invariants.
* Full disassembler coverage; lexer/parser corner cases; repl session and position tests.
* Additional sweep to round out test coverage on the long tail.
* IR invariants test (printer round-trip, label uniqueness).
* Retrospective draft committed; final pass on docs underway.
* Trimmed module docstrings and section banners; fixed VM constants import path.
