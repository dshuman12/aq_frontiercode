# TODO

- Investigate write-barrier overhead in tight loops (tracked: #14).
