# Lyra

![tests](https://img.shields.io/badge/tests-passing-brightgreen?style=flat) ![license](https://img.shields.io/badge/license-Apache--2.0-blue?style=flat)

A small statically-typed functional language with a compiler, a
bytecode virtual machine, and a generational garbage collector.

Lyra is a teaching project: each layer is small enough to read in an
afternoon and the interfaces between them are simple enough that you
can swap one out without rewriting the others.

## Documentation

Full docs are built with mkdocs (see `mkdocs.yml`); the live site is wired up via Read the Docs.

## Sample

```ocaml
type List a = Nil | Cons a (List a)

let rec length : List a -> Int =
    fn lst -> match lst {
        Nil       -> 0
        Cons _ xs -> 1 + length xs
    }

let main = print (length (Cons 1 (Cons 2 (Cons 3 Nil))))
```

## Why

Compilers, type checkers, and garbage collectors are each their own
bag of subtle bugs; doing all three in one project gives you a chance
to see how they interact. A unification bug shows up as a mystery in
the optimizer; a missing GC write barrier looks like a runtime crash;
a tail-call elimination bug masquerades as a stack overflow.

## Layers

```
src/lyra/
    lexer/      tokenizer with position tracking
    parser/     recursive-descent parser, AST
    resolve/    name resolution, scoping
    types/      Hindley-Milner inference, unification
    match/      pattern exhaustiveness, decision-tree compilation
    lower/      AST -> A-normal-form IR
    closure/    closure conversion, lambda lifting
    optimize/   constant folding, dead code, inlining
    codegen/    IR -> bytecode
    bytecode/   instruction format, on-disk module file
    vm/         stack-based interpreter
    gc/         generational copying GC
    objects/    runtime object model, tagged pointers
    stdlib/     built-in functions
    runtime/    glue between VM, GC, and stdlib
    modules/    module loader
    cli/        lyra build/run/repl/check/fmt/disasm
    repl/       interactive prompt
    debugger/   breakpoints, stepping
    utils/      helpers
```

## Quick start

```bash
pip install -e .[dev]
lyra build examples/fib.lyra
lyra run examples/fib.lyrac
lyra repl
> let double = fn x -> x * 2
double : Int -> Int
> double 21
42 : Int
```

## Documentation

- [Language tour](docs/language_tour.md)
- [Type system](docs/types.md)
- [Compiler internals](docs/compiler.md)
- [Virtual machine](docs/vm.md)
- [Garbage collector](docs/gc.md)
- [Bytecode reference](docs/bytecode.md)

## Running tests

```bash
pytest                        # full suite
pytest tests/unit/types -x    # focus on the type checker
pytest -k "exhaustive"        # one topic
```

## License

Apache 2.0 -- see LICENSE.
