from __future__ import annotations

import pytest

from lyra.types import reset_var_counter


@pytest.fixture(autouse=True)
def _reset_type_counter():
    reset_var_counter()
    yield
