from __future__ import annotations

from pathlib import Path

import pytest

from lyra.runtime import compile_file


EXAMPLES = [
    "fib.lyra",
    "list.lyra",
    "tree.lyra",
    "closure.lyra",
    "hello.lyra",
]


@pytest.mark.parametrize("name", EXAMPLES)
def test_example_compiles(name: str):
    path = Path("examples") / name
    if not path.exists():
        pytest.skip(f"{path} not present")
    result = compile_file(path)
    assert result.module.functions
