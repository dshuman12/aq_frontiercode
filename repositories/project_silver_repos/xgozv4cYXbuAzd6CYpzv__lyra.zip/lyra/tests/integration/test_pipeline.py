from __future__ import annotations

import pytest

from lyra.runtime import compile_source


def test_compile_simple_let():
    result = compile_source("let main = 42")
    assert result.module.functions
    assert "main" in result.types


def test_compile_lambda_definition():
    result = compile_source("let inc = fn x -> x + 1\nlet main = inc 41")
    labels = [fn.label for fn in result.module.functions]
    assert any("inc" in label or label == "@module_init" for label in labels)


def test_compile_recursive_function():
    result = compile_source(
        "let rec fact = fn n -> if n <= 1 then 1 else n * fact (n - 1)\n"
        "let main = fact 5"
    )
    assert "fact" in result.types
    assert "main" in result.types


def test_compile_pattern_match():
    result = compile_source(
        "type Maybe a = Nothing | Just a\n"
        "let unwrap = fn m -> match m {\n"
        "    Nothing -> 0\n"
        "    Just x  -> x\n"
        "}\n"
        "let main = unwrap (Just 7)"
    )
    assert "unwrap" in result.types


def test_compile_disasm_round_trip():
    from lyra.bytecode import decode, encode

    result = compile_source("let main = 1 + 2")
    blob = encode(result.module)
    decoded = decode(blob)
    assert len(decoded.functions) == len(result.module.functions)


def test_compile_unknown_name_raises():
    from lyra.errors import UndefinedName

    with pytest.raises(UndefinedName):
        compile_source("let main = nonexistent")
