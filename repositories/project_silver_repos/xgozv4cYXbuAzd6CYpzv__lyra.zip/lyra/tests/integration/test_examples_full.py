from __future__ import annotations

from pathlib import Path

import pytest

from lyra.runtime import compile_file


EXAMPLES = sorted(Path("examples").glob("*.lyra"))


@pytest.mark.parametrize("path", EXAMPLES, ids=lambda p: p.name)
def test_each_example_compiles(path: Path):
    if not path.exists():
        pytest.skip(f"{path} not present")
    result = compile_file(path)
    assert result.module.functions
