from __future__ import annotations

import pytest

from lyra.runtime import compile_source


def test_pipeline_match_with_constructor_args():
    result = compile_source(
        "type Pair = MkPair Int Int\n"
        "let first = fn p -> match p { MkPair a _ -> a }\n"
        "let main = first (MkPair 7 9)"
    )
    assert "first" in result.types


def test_pipeline_typed_let_annotation():
    result = compile_source(
        "let inc : Int -> Int = fn x -> x + 1\n"
        "let main = inc 5"
    )
    assert "inc" in result.types


def test_pipeline_compiles_higher_order():
    result = compile_source(
        "let twice = fn f x -> f (f x)\n"
        "let main = twice (fn n -> n + 1) 5"
    )
    assert "twice" in result.types


def test_pipeline_handles_unit_value():
    result = compile_source("let main = ()")
    assert "main" in result.types


def test_pipeline_compiles_string_pattern():
    result = compile_source(
        'let f = fn s -> match s { "x" -> 1, _ -> 0 }\n'
        'let main = f "x"'
    )
    assert "f" in result.types


def test_pipeline_emits_function_for_lambda():
    result = compile_source(
        "let id = fn x -> x\n"
        "let main = id 1"
    )
    assert any(fn.label.startswith("id") or fn.label == "@module_init"
               for fn in result.module.functions)
