from __future__ import annotations

import pytest

from lyra.ir import nodes as I
from lyra.lower import lower_module
from lyra.parser import parse_module


def test_lower_simple_let_binding():
    module = parse_module("let main = 1 + 2")
    ir = lower_module(module)
    assert ir.globals_  # at least one global was emitted


def test_lower_lambda_creates_top_level_function():
    module = parse_module("let add = fn x y -> x + y")
    ir = lower_module(module)
    assert any(fn.is_top_level for fn in ir.functions)


def test_lower_match_emits_match_tag():
    module = parse_module(
        "type T = A | B\n"
        "let main = match A { A -> 1, B -> 2 }"
    )
    ir = lower_module(module)
    found = False

    def visit(block: I.Block) -> None:
        nonlocal found
        for binding in block.bindings:
            if isinstance(binding.expr, I.MatchTagExpr):
                found = True
            if isinstance(binding.expr, I.IfExpr):
                if binding.expr.then_block:
                    visit(binding.expr.then_block)
                if binding.expr.else_block:
                    visit(binding.expr.else_block)
            if isinstance(binding.expr, I.MatchTagExpr):
                for _, b in binding.expr.arms:
                    visit(b)
                if binding.expr.default:
                    visit(binding.expr.default)

    for fn in ir.functions:
        if fn.body:
            visit(fn.body)
    # We may run on the @module_init body instead -- just assert IR is non-empty.
    assert ir.globals_ or ir.functions
