from __future__ import annotations

import pytest

from lyra.errors import NonExhaustiveMatch
from lyra.match import TypeOracle, check_match
from lyra.parser import ast as A


def make_arm(pattern, body=None):
    return A.MatchArm(pattern=pattern, body=body or A.IntLit(value=0))


def test_just_with_arg_pattern_exhaustive():
    arms = [
        make_arm(A.PCon(name="Nothing")),
        make_arm(A.PCon(name="Just", args=[A.PWild()])),
    ]
    check_match(arms, TypeOracle())


def test_just_without_nothing_nonexhaustive():
    arms = [make_arm(A.PCon(name="Just", args=[A.PWild()]))]
    with pytest.raises(NonExhaustiveMatch):
        check_match(arms, TypeOracle())


def test_string_literal_match_with_wildcard():
    arms = [
        make_arm(A.PString(value="alice")),
        make_arm(A.PWild()),
    ]
    check_match(arms, TypeOracle())


def test_int_literal_with_wildcard():
    arms = [
        make_arm(A.PInt(value=0)),
        make_arm(A.PInt(value=1)),
        make_arm(A.PWild()),
    ]
    check_match(arms, TypeOracle())


def test_or_pattern_treats_each_option_as_arm():
    arms = [
        make_arm(A.POr(options=[A.PCon(name="Nothing"),
                                  A.PCon(name="Just", args=[A.PWild()])])),
    ]
    check_match(arms, TypeOracle())


def test_useless_after_pcon_wildcard():
    arms = [
        make_arm(A.PWild()),
        make_arm(A.PCon(name="Just", args=[A.PWild()])),
    ]
    from lyra.errors import UselessPattern

    with pytest.raises(UselessPattern):
        check_match(arms, TypeOracle())
