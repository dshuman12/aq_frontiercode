from __future__ import annotations

from lyra.bytecode.format import CompiledFunction, CompiledModule
from lyra.runtime.inspect import summarise
from lyra.types import T_INT


def test_summarise_basic_counts():
    module = CompiledModule(
        functions=[CompiledFunction(label="main", arity=0,
                                     upvalue_count=0, local_count=0,
                                     code=b"\xff")],
        imports=["A"],
        exports=[("main", 0)],
    )
    summary = summarise(module, name="m")
    assert summary.function_count == 1
    assert summary.import_count == 1
    assert summary.export_names == ["main"]


def test_summarise_renders_text():
    module = CompiledModule()
    summary = summarise(module, name="m")
    text = summary.render()
    assert "module m" in text
    assert "imports" in text


def test_summarise_includes_types():
    module = CompiledModule()
    summary = summarise(module, name="m", types={"x": T_INT})
    text = summary.render()
    assert "x : Int" in text
