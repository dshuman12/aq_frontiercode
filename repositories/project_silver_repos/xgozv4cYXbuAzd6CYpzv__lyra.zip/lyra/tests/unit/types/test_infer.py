from __future__ import annotations

import pytest

from lyra.errors import UndefinedName
from lyra.parser import parse_expr, parse_module
from lyra.types import T_BOOL, T_INT, TFun, infer_expression, infer_module


def test_infer_int_literal():
    assert infer_expression(parse_expr("1")) is T_INT


def test_infer_bool_literal():
    assert infer_expression(parse_expr("true")) is T_BOOL


def test_infer_arithmetic():
    ty = infer_expression(parse_expr("1 + 2"))
    assert ty is T_INT


def test_infer_comparison_returns_bool():
    ty = infer_expression(parse_expr("1 == 2"))
    assert ty is T_BOOL


def test_infer_lambda():
    ty = infer_expression(parse_expr("fn x -> x + 1"))
    assert isinstance(ty, TFun)


def test_infer_let_polymorphism():
    module = parse_module(
        "let id = fn x -> x\n"
        "let a = id 1\n"
        "let b = id true"
    )
    types = infer_module(module)
    assert "id" in types
    assert "a" in types and "b" in types


def test_infer_undefined_name():
    with pytest.raises(UndefinedName):
        infer_expression(parse_expr("undefined_thing"))


def test_infer_if_branches_unified():
    ty = infer_expression(parse_expr("if true then 1 else 2"))
    assert ty is T_INT


def test_infer_if_branch_mismatch():
    from lyra.errors import UnificationError

    with pytest.raises(UnificationError):
        infer_expression(parse_expr("if true then 1 else \"two\""))


def test_infer_recursive_function():
    module = parse_module(
        "let rec fact = fn n -> if n == 0 then 1 else n * fact (n - 1)"
    )
    types = infer_module(module)
    assert "fact" in types
