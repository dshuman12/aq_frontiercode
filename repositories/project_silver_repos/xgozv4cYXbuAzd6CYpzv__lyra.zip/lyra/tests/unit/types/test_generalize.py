from __future__ import annotations

from lyra.types import (
    T_INT,
    TFun,
    TForall,
    TVar,
    fresh_var,
    generalize,
    instantiate,
)


def test_generalize_no_free_vars_returns_same():
    ty = TFun(params=[T_INT], result=T_INT)
    assert generalize(ty, level=0) is ty


def test_generalize_wraps_high_level_var():
    var = fresh_var(level=2)
    ty = TFun(params=[var], result=var)
    out = generalize(ty, level=1)
    assert isinstance(out, TForall)
    assert var in out.bound


def test_generalize_skips_low_level_vars():
    var = fresh_var(level=0)
    ty = TFun(params=[var], result=var)
    out = generalize(ty, level=1)
    assert not isinstance(out, TForall)


def test_instantiate_renames_bound_vars():
    var = fresh_var(level=1)
    poly = TForall(bound=[var], body=TFun(params=[var], result=var))
    fresh = instantiate(poly, level=2)
    # The variable referenced should not be the original bound var.
    assert isinstance(fresh, TFun)
    assert fresh.params[0] is not var


def test_instantiate_non_forall_returns_unchanged():
    ty = TFun(params=[T_INT], result=T_INT)
    assert instantiate(ty, level=1) is ty
