from __future__ import annotations

import pytest

from lyra.errors import OccursCheckError, UnificationError
from lyra.types import (
    T_BOOL,
    T_INT,
    TFun,
    TVar,
    fresh_var,
    occurs,
    unify,
)


def test_unify_same_concrete_type_noop():
    unify(T_INT, T_INT)


def test_unify_distinct_concrete_types_fails():
    with pytest.raises(UnificationError):
        unify(T_INT, T_BOOL)


def test_unify_var_with_concrete():
    var = fresh_var(level=0)
    unify(var, T_INT)
    assert var.find() is T_INT


def test_unify_two_vars_chain_through_find():
    a = fresh_var(level=0)
    b = fresh_var(level=0)
    unify(a, b)
    unify(b, T_INT)
    assert a.find() is T_INT


def test_unify_function_arity_mismatch():
    f1 = TFun(params=[T_INT], result=T_INT)
    f2 = TFun(params=[T_INT, T_INT], result=T_INT)
    with pytest.raises(UnificationError):
        unify(f1, f2)


def test_unify_function_same_shape():
    f1 = TFun(params=[T_INT], result=T_INT)
    f2 = TFun(params=[T_INT], result=T_INT)
    unify(f1, f2)


def test_occurs_check_detects_recursion():
    var = fresh_var(level=0)
    fn = TFun(params=[var], result=var)
    with pytest.raises(OccursCheckError):
        unify(var, fn)


def test_occurs_helper_returns_true():
    var = fresh_var(level=0)
    fn = TFun(params=[var], result=var)
    assert occurs(var, fn)


def test_occurs_unrelated_var_returns_false():
    a = fresh_var(level=0)
    b = fresh_var(level=0)
    assert not occurs(a, b)
