from __future__ import annotations

from lyra.objects.model import alloc_string, equal


def test_empty_string():
    assert alloc_string("").payload == ""


def test_unicode_string_round_trip():
    assert alloc_string("héllo").payload == "héllo"


def test_string_equality_distinct_objects():
    a = alloc_string("hi")
    b = alloc_string("hi")
    assert a is not b
    assert equal(a, b)


def test_long_string():
    s = "x" * 10_000
    assert alloc_string(s).payload == s


def test_unicode_codepoints():
    assert alloc_string("👋").payload == "👋"
