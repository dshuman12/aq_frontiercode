from __future__ import annotations

from lyra.errors import LexerError, ParseError, Position, UndefinedName
from lyra.utils.diagnostics import format_error


def test_format_error_lexer_with_source():
    err = LexerError("bad", position=Position(file="t", line=1, column=3))
    diagnostic = format_error(err, source="abcde")
    assert "bcde" in diagnostic.rendered or "abc" in diagnostic.rendered


def test_format_error_parse_no_position_no_caret():
    err = ParseError("nope")
    diag = format_error(err, source="abc")
    assert "^" not in diag.rendered


def test_format_error_undefined_name_includes_code():
    err = UndefinedName("foo")
    assert "LY1201" in format_error(err).rendered


def test_format_error_with_long_line():
    long_line = "x" * 100
    err = ParseError("oops", position=Position(file="t", line=1, column=50))
    diag = format_error(err, source=long_line)
    assert len(diag.rendered) > 0


def test_format_error_emits_hint_line():
    err = ParseError("err", hint="try removing the comma")
    diag = format_error(err)
    assert "hint:" in diag.rendered


def test_format_error_position_outside_source():
    err = ParseError("err", position=Position(file="t", line=999, column=1))
    diag = format_error(err, source="single line")
    # No exception raised; we just don't get a caret line.
    assert err.code in diag.rendered
