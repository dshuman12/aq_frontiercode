from __future__ import annotations

import pytest

from lyra.constants import (
    INT_TAG_SHIFT,
    MAX_TAGGED_INT,
    MIN_TAGGED_INT,
    TAG_INT_BIT,
)
from lyra.objects.model import is_tagged_int, tag_int, untag_int


def test_tag_int_low_bit_set():
    out = tag_int(123)
    assert out & TAG_INT_BIT


def test_int_tag_shift_is_one():
    assert INT_TAG_SHIFT == 1


def test_max_tagged_int_equals_2_pow_62_minus_one():
    assert MAX_TAGGED_INT == (1 << 62) - 1


def test_min_tagged_int_equals_neg_2_pow_62():
    assert MIN_TAGGED_INT == -(1 << 62)


def test_untag_int_inverts_tag_int():
    for v in [-100, 0, 100, MAX_TAGGED_INT, MIN_TAGGED_INT]:
        assert untag_int(tag_int(v)) == v


def test_overflow_raises():
    with pytest.raises(OverflowError):
        tag_int(MAX_TAGGED_INT + 1)
    with pytest.raises(OverflowError):
        tag_int(MIN_TAGGED_INT - 1)


def test_is_tagged_int_for_tagged_value():
    assert is_tagged_int(tag_int(5))


def test_is_tagged_int_for_box():
    from lyra.objects.model import alloc_string

    assert not is_tagged_int(alloc_string("x"))
