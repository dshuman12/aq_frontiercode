from __future__ import annotations

from lyra.runtime.session import ReplSession


def test_feed_arithmetic_returns_int_type():
    session = ReplSession()
    outcome = session.feed("1 + 1")
    assert outcome.primary_type is not None


def test_chained_let_bindings():
    session = ReplSession()
    session.feed("let x = 1")
    session.feed("let y = x + 1")
    assert "y" in session.bindings


def test_known_names_returns_a_list():
    session = ReplSession()
    session.feed("let z = 0")
    names = list(session.known_names())
    assert "z" in names


def test_reset_clears_line_counter():
    session = ReplSession()
    session.feed("let x = 1")
    session.feed("let y = 2")
    session.reset()
    assert session.line_counter == 0


def test_outcome_kind_for_let():
    session = ReplSession()
    outcome = session.feed("let q = 99")
    assert outcome.kind == "binding"


def test_outcome_kind_for_expr():
    session = ReplSession()
    outcome = session.feed("1 + 2")
    assert outcome.kind == "expression"
