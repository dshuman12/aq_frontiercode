from __future__ import annotations

from lyra.ir import nodes as I
from lyra.ir.printer import render_atom, render_block, render_function, render_module


def test_render_int_atom():
    assert render_atom(I.IntAtom(value=7)) == "7"


def test_render_var_atom():
    assert render_atom(I.VarAtom(name="x")) == "x"


def test_render_unit_when_atom_is_none():
    assert render_atom(None) == "()"


def test_render_block_with_binding_and_result():
    block = I.Block(
        bindings=[I.Binding(name="x", expr=I.AtomExpr(atom=I.IntAtom(value=1)))],
        result=I.VarAtom(name="x"),
    )
    text = render_block(block)
    assert "let x" in text
    assert "return x" in text


def test_render_function_includes_label_and_params():
    body = I.Block(bindings=[], result=I.VarAtom(name="x"))
    func = I.Function(label="f", params=["x"], body=body)
    text = render_function(func)
    assert "fn f" in text and "params=x" in text


def test_render_module_lists_globals():
    module = I.Module(
        name="demo",
        globals_=[I.Binding(name="g", expr=I.AtomExpr(atom=I.IntAtom(value=2)))],
    )
    text = render_module(module)
    assert "globals" in text and "g :=" in text


def test_render_module_handles_no_functions():
    module = I.Module(name="empty")
    text = render_module(module)
    assert "module empty" in text


def test_render_call_marks_tail():
    call = I.CallExpr(func=I.VarAtom(name="g"), args=[], is_tail=True)
    from lyra.ir.printer import render_expr

    assert render_expr(call).startswith("tail-call")


def test_render_match_lists_arms():
    expr = I.MatchTagExpr(
        scrutinee=I.VarAtom(name="x"),
        arms=[(0, I.Block()), (1, I.Block())],
    )
    from lyra.ir.printer import render_expr

    text = render_expr(expr)
    assert "#0" in text and "#1" in text
