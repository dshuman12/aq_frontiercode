from __future__ import annotations

from lyra.runtime.session import ReplSession


def test_session_starts_empty():
    session = ReplSession()
    assert list(session.known_names()) == []


def test_session_records_let_binding():
    session = ReplSession()
    outcome = session.feed("let x = 1")
    assert outcome.kind == "binding"
    assert "x" in session.bindings


def test_session_evaluates_expression_returns_type():
    session = ReplSession()
    outcome = session.feed("1 + 1")
    assert outcome.kind == "expression"
    assert outcome.primary_type is not None


def test_session_reset_clears_bindings():
    session = ReplSession()
    session.feed("let y = 42")
    session.reset()
    assert "y" not in session.bindings


def test_session_increments_line_counter():
    session = ReplSession()
    session.feed("let a = 1")
    session.feed("let b = 2")
    assert session.line_counter == 2
