from __future__ import annotations

from pathlib import Path

import pytest

from lyra.modules.loader import ModuleLoader


def write(path: Path, text: str = "let m = 1") -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)


def test_loader_resolves_one_level(tmp_path: Path):
    write(tmp_path / "M.lyra")
    loader = ModuleLoader(search_paths=[tmp_path])
    assert loader.load("M").name == "M"


def test_loader_resolves_two_levels(tmp_path: Path):
    write(tmp_path / "Std" / "M.lyra")
    loader = ModuleLoader(search_paths=[tmp_path])
    assert loader.load("Std.M").name == "Std.M"


def test_loader_resolves_three_levels(tmp_path: Path):
    write(tmp_path / "A" / "B" / "C.lyra")
    loader = ModuleLoader(search_paths=[tmp_path])
    assert loader.load("A.B.C").name == "A.B.C"


def test_loader_caches_repeated_imports(tmp_path: Path):
    write(tmp_path / "Shared.lyra")
    write(tmp_path / "L.lyra", "import Shared\nlet l = 1")
    write(tmp_path / "R.lyra", "import Shared\nlet r = 1")
    loader = ModuleLoader(search_paths=[tmp_path])
    loader.load("L")
    before = id(loader.loaded["Shared"])
    loader.load("R")
    after = id(loader.loaded["Shared"])
    assert before == after
