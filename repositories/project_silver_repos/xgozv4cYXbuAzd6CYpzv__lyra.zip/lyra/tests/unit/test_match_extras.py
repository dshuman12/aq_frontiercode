from __future__ import annotations

import pytest

from lyra.errors import NonExhaustiveMatch
from lyra.match import TypeOracle, check_match
from lyra.match.exhaustive import _Con
from lyra.parser import ast as A


def make_arm(pattern, body=None):
    return A.MatchArm(pattern=pattern, body=body or A.IntLit(value=0))


def test_register_custom_type():
    oracle = TypeOracle()
    oracle.register("Direction", [_Con("North", 0), _Con("South", 0)])
    arms = [
        make_arm(A.PCon(name="North")),
        make_arm(A.PCon(name="South")),
    ]
    check_match(arms, oracle)


def test_unknown_type_falls_back_to_default():
    oracle = TypeOracle()
    arms = [make_arm(A.PWild())]
    check_match(arms, oracle)


def test_int_literal_match_requires_wildcard():
    arms = [
        make_arm(A.PInt(value=0)),
        make_arm(A.PInt(value=1)),
    ]
    with pytest.raises(NonExhaustiveMatch):
        check_match(arms, TypeOracle())


def test_int_with_wildcard_passes():
    arms = [make_arm(A.PInt(value=0)), make_arm(A.PWild())]
    check_match(arms, TypeOracle())


def test_or_pattern_split_into_cases():
    arms = [
        make_arm(A.POr(options=[A.PBool(value=True), A.PBool(value=False)])),
    ]
    check_match(arms, TypeOracle())


def test_constructors_of_unknown_returns_empty():
    oracle = TypeOracle()
    assert oracle.constructors_of("Wat") == []
