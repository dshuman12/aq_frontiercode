from __future__ import annotations

import pytest

from lyra.objects.model import (
    alloc_closure,
    alloc_data,
    alloc_list,
    alloc_map,
    alloc_record,
    alloc_tuple,
    equal,
    is_closure,
    is_data,
    is_record,
    is_tuple,
    value_repr,
)


def test_closure_predicate():
    closure = alloc_closure("f", [])
    assert is_closure(closure)


def test_data_predicate():
    data = alloc_data(0, [])
    assert is_data(data)


def test_tuple_predicate():
    tup = alloc_tuple([1, 2])
    assert is_tuple(tup)


def test_record_predicate():
    record = alloc_record(["x", "y"], [1, 2])
    assert is_record(record)


def test_data_equality_by_tag_and_args():
    a = alloc_data(0, [1, 2])
    b = alloc_data(0, [1, 2])
    c = alloc_data(1, [1, 2])
    assert equal(a, b)
    assert not equal(a, c)


def test_list_equality_by_elements():
    a = alloc_list([1, 2, 3])
    b = alloc_list([1, 2, 3])
    assert equal(a, b)


def test_map_alloc_returns_box():
    m = alloc_map({1: 2, 3: 4})
    assert m.payload[1] == 2


def test_value_repr_unit():
    assert value_repr(None) == "()"


def test_value_repr_closure_uses_label():
    closure = alloc_closure("my_fn", [])
    text = value_repr(closure)
    assert "my_fn" in text


def test_value_repr_list_brackets():
    lst = alloc_list([1, 2, 3])
    assert value_repr(lst).startswith("[") and value_repr(lst).endswith("]")
