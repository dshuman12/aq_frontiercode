from __future__ import annotations

from pathlib import Path

import pytest

from lyra.runtime import compile_file


@pytest.mark.parametrize("name", [
    "hello.lyra",
    "fib.lyra",
    "list.lyra",
    "tree.lyra",
    "closure.lyra",
    "maybe.lyra",
    "arith.lyra",
])
def test_each_example_compiles(name: str):
    path = Path("examples") / name
    if not path.exists():
        pytest.skip(f"{path} not present")
    result = compile_file(path)
    assert result.module.functions
