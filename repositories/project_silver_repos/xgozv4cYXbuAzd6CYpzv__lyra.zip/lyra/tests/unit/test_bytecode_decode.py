from __future__ import annotations

import struct

import pytest

from lyra.bytecode.format import (
    CONST_BOOL,
    CONST_CHAR,
    CONST_FLOAT,
    CONST_INT,
    CONST_STRING,
    CONST_UNIT,
    CompiledFunction,
    CompiledModule,
    Constant,
    decode,
    encode,
)
from lyra.errors import CorruptModule


def test_unit_constant_round_trip():
    module = CompiledModule(constants=[Constant(kind=CONST_UNIT, value=None)])
    assert decode(encode(module)).constants[0].kind == CONST_UNIT


def test_char_constant_round_trip():
    module = CompiledModule(constants=[Constant(kind=CONST_CHAR, value="a")])
    assert decode(encode(module)).constants[0].value == "a"


def test_function_with_upvalues_round_trip():
    module = CompiledModule(functions=[CompiledFunction(
        label="f", arity=1, upvalue_count=2, local_count=3, code=b"\xff",
    )])
    decoded = decode(encode(module))
    assert decoded.functions[0].upvalue_count == 2
    assert decoded.functions[0].local_count == 3


def test_decode_rejects_truncated_blob():
    module = CompiledModule(functions=[CompiledFunction(
        label="f", arity=0, upvalue_count=0, local_count=0, code=b"\xff",
    )])
    blob = encode(module)[:-2]
    with pytest.raises(Exception):
        decode(blob)


def test_export_table_round_trip():
    module = CompiledModule(
        functions=[CompiledFunction(label="f", arity=0, upvalue_count=0,
                                     local_count=0, code=b"\xff")],
        exports=[("f", 0)],
    )
    decoded = decode(encode(module))
    assert decoded.exports == [("f", 0)]


def test_import_table_round_trip():
    module = CompiledModule(imports=["A.B.C", "Std.List"])
    decoded = decode(encode(module))
    assert decoded.imports == ["A.B.C", "Std.List"]
