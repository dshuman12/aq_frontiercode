from __future__ import annotations

import pytest

from lyra.runtime import compile_source


def test_compile_string_literal():
    result = compile_source('let main = "hello"')
    assert result.module.functions


def test_compile_recursive_with_typed_signature():
    result = compile_source(
        "let rec count : Int -> Int = fn n -> if n == 0 then 0 else count (n - 1)\n"
        "let main = count 3"
    )
    assert "count" in result.types


def test_compile_polymorphic_id():
    result = compile_source(
        "let id = fn x -> x\n"
        "let main = id 1"
    )
    assert "id" in result.types and "main" in result.types


def test_compile_match_with_type():
    result = compile_source(
        "type Foo = A | B Int\n"
        "let extract = fn f -> match f {\n"
        "    A   -> 0\n"
        "    B n -> n\n"
        "}\n"
        "let main = extract (B 7)"
    )
    assert "extract" in result.types


def test_compile_supports_field_access():
    result = compile_source(
        'let r = { x = 1, y = "two" }\n'
        "let main = r.x"
    )
    assert "main" in result.types


def test_compile_unused_let_does_not_fail():
    result = compile_source(
        "let unused = 1\n"
        "let main = 2"
    )
    assert "main" in result.types
