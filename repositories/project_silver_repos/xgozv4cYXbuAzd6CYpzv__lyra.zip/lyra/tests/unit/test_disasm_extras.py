from __future__ import annotations

import struct

from lyra.bytecode import (
    CompiledFunction,
    CompiledModule,
    Constant,
    CONST_INT,
    disassemble_function,
    disassemble_module,
)
from lyra.constants import (
    OP_HALT,
    OP_LOAD_CONST,
    OP_RETURN,
)


def test_disasm_round_trip_load_const_then_return():
    code = bytes([OP_LOAD_CONST]) + struct.pack("<H", 0) + bytes([OP_RETURN])
    fn = CompiledFunction(label="f", arity=0, upvalue_count=0,
                           local_count=0, code=code)
    text = disassemble_function(fn)
    assert "LOAD_CONST" in text and "RETURN" in text


def test_disasm_module_with_imports():
    module = CompiledModule(
        constants=[Constant(kind=CONST_INT, value=1)],
        imports=["Std.List"],
        exports=[("main", 0)],
        functions=[CompiledFunction(label="main", arity=0,
                                     upvalue_count=0, local_count=0,
                                     code=bytes([OP_HALT]))],
    )
    text = disassemble_module(module)
    assert "Std.List" in text
    assert "main" in text


def test_disasm_handles_no_constants():
    module = CompiledModule()
    text = disassemble_module(module)
    assert "constants" in text
