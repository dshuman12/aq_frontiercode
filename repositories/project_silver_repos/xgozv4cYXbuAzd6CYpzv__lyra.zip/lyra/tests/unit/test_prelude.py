from __future__ import annotations

from lyra.stdlib.prelude import build_prelude, list_type, maybe_type
from lyra.types import T_INT


def test_prelude_includes_println():
    bindings = build_prelude()
    assert "println" in bindings


def test_prelude_includes_panic():
    bindings = build_prelude()
    assert "panic" in bindings


def test_prelude_string_length_returns_int():
    bindings = build_prelude()
    ty = bindings["string_length"]
    assert ty.params == [(__import__('lyra.types', fromlist=['T_STRING'])).T_STRING]
    assert ty.result is T_INT


def test_list_type_constructor():
    ty = list_type(T_INT)
    assert ty.name == "List"


def test_maybe_type_constructor():
    ty = maybe_type(T_INT)
    assert ty.name == "Maybe"


def test_prelude_includes_read_line():
    assert "read_line" in build_prelude()


def test_prelude_assert_takes_bool():
    bindings = build_prelude()
    ty = bindings["assert"]
    from lyra.types import T_BOOL

    assert ty.params == [T_BOOL]
