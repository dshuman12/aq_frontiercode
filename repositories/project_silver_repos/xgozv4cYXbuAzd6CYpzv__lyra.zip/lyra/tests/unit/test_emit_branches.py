from __future__ import annotations

from lyra.codegen import emit_module
from lyra.ir import nodes as I


def make_if_module() -> I.Module:
    body = I.Block(
        bindings=[I.Binding(
            name="r",
            expr=I.IfExpr(
                cond=I.BoolAtom(value=True),
                then_block=I.Block(result=I.IntAtom(value=1)),
                else_block=I.Block(result=I.IntAtom(value=0)),
            ),
        )],
        result=I.VarAtom(name="r"),
    )
    return I.Module(functions=[I.Function(label="main", body=body, is_top_level=True)])


def test_emit_if_block_produces_jump():
    module = emit_module(make_if_module())
    assert any(0x21 in fn.code for fn in module.functions)  # OP_JUMP_IF_FALSE


def test_emit_match_tag_emits_match_op():
    body = I.Block(
        bindings=[I.Binding(
            name="r",
            expr=I.MatchTagExpr(
                scrutinee=I.IntAtom(value=0),
                arms=[(0, I.Block(result=I.IntAtom(value=1)))],
            ),
        )],
        result=I.VarAtom(name="r"),
    )
    module = emit_module(I.Module(functions=[I.Function(label="main", body=body)]))
    assert any(0x23 in fn.code for fn in module.functions)


def test_emit_call_emits_call_or_tail():
    body = I.Block(
        bindings=[I.Binding(
            name="r",
            expr=I.CallExpr(func=I.VarAtom(name="g"),
                             args=[I.IntAtom(value=1)], is_tail=False),
        )],
        result=I.VarAtom(name="r"),
    )
    module = emit_module(I.Module(functions=[I.Function(label="main", body=body)]))
    found_call = any(0x10 in fn.code for fn in module.functions)
    assert found_call


def test_emit_tail_call_distinct_from_call():
    body = I.Block(
        bindings=[I.Binding(
            name="r",
            expr=I.CallExpr(func=I.VarAtom(name="g"),
                             args=[I.IntAtom(value=1)], is_tail=True),
        )],
        result=I.VarAtom(name="r"),
    )
    module = emit_module(I.Module(functions=[I.Function(label="main", body=body)]))
    assert any(0x11 in fn.code for fn in module.functions)
