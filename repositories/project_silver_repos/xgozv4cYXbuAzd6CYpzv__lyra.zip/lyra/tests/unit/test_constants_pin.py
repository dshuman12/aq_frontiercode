from __future__ import annotations

from lyra.constants import (
    BYTECODE_MAGIC,
    BYTECODE_VERSION,
    CLASS_CLOSURE,
    CLASS_DATA,
    CLASS_STRING,
    CLASS_TUPLE,
    DEFAULT_PROMOTION_AGE,
    DEFAULT_YOUNG_BYTES,
    GC_HEADER_SIZE,
    INT_TAG_SHIFT,
    MAX_TAGGED_INT,
    MIN_TAGGED_INT,
    OP_ALLOC,
    OP_CALL,
    OP_HALT,
    OP_LOAD_CONST,
    OP_RETURN,
    OP_TAIL_CALL,
)


def test_magic_pinned():
    assert BYTECODE_MAGIC == b"LYRA0001"


def test_version_pinned():
    assert BYTECODE_VERSION == 1


def test_class_ids_distinct():
    ids = {CLASS_CLOSURE, CLASS_DATA, CLASS_STRING, CLASS_TUPLE}
    assert len(ids) == 4


def test_tag_int_shift():
    assert INT_TAG_SHIFT == 1


def test_tagged_int_range():
    assert MAX_TAGGED_INT == (1 << 62) - 1
    assert MIN_TAGGED_INT == -(1 << 62)


def test_gc_header_size_positive():
    assert GC_HEADER_SIZE > 0


def test_default_young_bytes_at_least_a_megabyte():
    assert DEFAULT_YOUNG_BYTES >= 1 << 20


def test_default_promotion_age_reasonable():
    assert 1 <= DEFAULT_PROMOTION_AGE <= 5


def test_opcodes_distinct_in_pinned_set():
    pinned = {OP_LOAD_CONST, OP_CALL, OP_TAIL_CALL, OP_RETURN, OP_ALLOC, OP_HALT}
    assert len(pinned) == 6
