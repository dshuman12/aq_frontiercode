from __future__ import annotations

from lyra.match.exhaustive import _Con, _Lit, _flatten_or
from lyra.parser import ast as A


def test_flatten_or_keeps_single():
    pat = A.PInt(value=1)
    assert _flatten_or(pat) == [pat]


def test_flatten_or_expands_options():
    inner = [A.PInt(value=1), A.PInt(value=2), A.PInt(value=3)]
    pat = A.POr(options=inner)
    assert _flatten_or(pat) == inner


def test_flatten_or_recurses():
    inner_or = A.POr(options=[A.PInt(value=1), A.PInt(value=2)])
    outer = A.POr(options=[inner_or, A.PInt(value=3)])
    assert len(_flatten_or(outer)) == 3


def test_lit_dataclass_equality():
    assert _Lit(1) == _Lit(1)
    assert _Lit(1) != _Lit(2)


def test_con_dataclass_equality():
    assert _Con("Cons", 2) == _Con("Cons", 2)
    assert _Con("Cons", 2) != _Con("Cons", 3)
