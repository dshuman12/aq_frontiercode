from __future__ import annotations

from lyra.utils.formatting import (
    humanise_bytes,
    humanise_count,
    indent_block,
    two_column_layout,
)


def test_humanise_bytes_thresholds():
    assert humanise_bytes(512).endswith("B")
    assert "KiB" in humanise_bytes(2048)
    assert "MiB" in humanise_bytes(2 * 1024 * 1024)


def test_humanise_count_simple():
    assert humanise_count(7) == "7"
    assert "k" in humanise_count(1500)
    assert "M" in humanise_count(2_500_000)


def test_two_column_layout_aligns():
    text = two_column_layout([("short", "a"), ("longer", "b")])
    lines = text.splitlines()
    assert all(len(line.split("  ")[0]) == len("longer") for line in lines)


def test_indent_block_pads_each_line():
    text = "alpha\nbeta\n"
    out = indent_block(text, by=4)
    assert all(line == "" or line.startswith("    ") for line in out.splitlines())
