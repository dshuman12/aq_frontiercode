from __future__ import annotations

from pathlib import Path

import pytest

from lyra.bytecode import decode, encode
from lyra.runtime import compile_source, read_compiled, write_compiled


def test_compile_then_round_trip_via_blob():
    result = compile_source("let main = 1 + 2")
    blob = encode(result.module)
    decoded = decode(blob)
    assert len(decoded.functions) == len(result.module.functions)


def test_compile_then_disk_round_trip(tmp_path: Path):
    result = compile_source("let main = 7")
    p = tmp_path / "m.lyrac"
    write_compiled(p, result.module)
    again = read_compiled(p)
    assert len(again.functions) == len(result.module.functions)


def test_compile_idempotent_for_same_source():
    a = compile_source("let main = 1")
    b = compile_source("let main = 1")
    # The bytecode for the same source should be byte-identical.
    assert encode(a.module) == encode(b.module)


def test_compile_handles_let_in_expr():
    result = compile_source("let main = let x = 1 in x + 1")
    assert "main" in result.types


def test_compile_handles_chained_let_in():
    result = compile_source(
        "let main = let x = 1 in let y = 2 in x + y"
    )
    assert "main" in result.types
