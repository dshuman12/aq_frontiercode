from __future__ import annotations

import pytest

from lyra.errors import LexerError
from lyra.lexer import TokenKind, tokenize


def kinds(source: str) -> list[TokenKind]:
    return [t.kind for t in tokenize(source)]


def test_empty_input_yields_only_eof():
    out = tokenize("")
    assert len(out) == 1 and out[0].kind == TokenKind.EOF


def test_lower_vs_upper_idents():
    out = tokenize("foo Foo")
    assert out[0].kind == TokenKind.LIDENT
    assert out[1].kind == TokenKind.UIDENT


def test_keywords_recognised():
    out = tokenize("let fn match type")
    assert all(t.is_keyword(t.text) for t in out[:4])


def test_underscore_as_wildcard():
    out = tokenize("_")
    assert out[0].kind == TokenKind.UNDERSCORE


def test_int_and_float_literals():
    out = tokenize("123 1.5 1e10 1_000")
    assert out[0].kind == TokenKind.INT
    assert out[1].kind == TokenKind.FLOAT
    assert out[2].kind == TokenKind.FLOAT
    assert out[3].text == "1000"


def test_string_with_escape():
    out = tokenize(r'"hello\nworld"')
    assert out[0].kind == TokenKind.STRING
    assert out[0].text == "hello\nworld"


def test_char_literal():
    out = tokenize("'a'")
    assert out[0].kind == TokenKind.CHAR
    assert out[0].text == "a"


def test_block_comment_nested():
    out = tokenize("/* outer /* inner */ outer */ x")
    assert out[0].kind == TokenKind.LIDENT and out[0].text == "x"


def test_unterminated_string_raises():
    with pytest.raises(LexerError):
        tokenize('"oops')


def test_two_char_operators():
    out = tokenize("== != <= >= -> => :: || && ++")
    operators = [t.text for t in out if t.kind in
                 (TokenKind.OP, TokenKind.ARROW, TokenKind.FAT_ARROW, TokenKind.DOUBLE_COLON)]
    assert "==" in operators and "->" in operators and "::" in operators


def test_position_tracking():
    out = tokenize("a\n  b")
    assert out[1].position.line == 2
    assert out[1].position.column == 3
