from __future__ import annotations

import pytest

from lyra.errors import ParseError
from lyra.parser import ast as A
from lyra.parser.parser import parse_expr, parse_module


def test_parse_simple_let():
    module = parse_module("let x = 1")
    assert isinstance(module.declarations[0], A.LetDecl)


def test_parse_lambda():
    expr = parse_expr("fn x -> x + 1")
    assert isinstance(expr, A.Lambda)
    assert len(expr.params) == 1


def test_parse_application_left_assoc():
    expr = parse_expr("f x y")
    assert isinstance(expr, A.App)
    assert isinstance(expr.func, A.App)


def test_parse_arithmetic_precedence():
    expr = parse_expr("1 + 2 * 3")
    assert isinstance(expr, A.BinOp) and expr.op == "+"
    assert isinstance(expr.right, A.BinOp) and expr.right.op == "*"


def test_parse_let_in():
    expr = parse_expr("let x = 1 in x + 1")
    assert isinstance(expr, A.Let)
    assert isinstance(expr.body, A.BinOp)


def test_parse_if_then_else():
    expr = parse_expr("if true then 1 else 0")
    assert isinstance(expr, A.If)


def test_parse_match_with_arms():
    expr = parse_expr("match x { 0 -> false, _ -> true }")
    assert isinstance(expr, A.Match)
    assert len(expr.arms) == 2


def test_parse_type_decl_sum():
    module = parse_module("type Maybe a = Nothing | Just a")
    decl = module.declarations[0]
    assert isinstance(decl, A.TypeDecl) and len(decl.constructors) == 2


def test_parse_type_decl_with_args():
    module = parse_module("type Pair a b = Pair a b")
    decl = module.declarations[0]
    assert isinstance(decl, A.TypeDecl)


def test_parse_module_header():
    module = parse_module("module M\nlet x = 1")
    assert module.name == "M"


def test_parse_import():
    module = parse_module("import Std.List")
    decl = module.declarations[0]
    assert isinstance(decl, A.ImportDecl)
    assert decl.module == "Std.List"


def test_parse_function_sugar():
    module = parse_module("let add x y = x + y")
    binding = module.declarations[0].bindings[0]
    assert isinstance(binding.expr, A.Lambda)
    assert len(binding.expr.params) == 2


def test_parse_tuple():
    expr = parse_expr("(1, 2, 3)")
    assert isinstance(expr, A.Tuple)
    assert len(expr.elements) == 3


def test_parse_record_literal():
    expr = parse_expr("{ x = 1, y = 2 }")
    assert isinstance(expr, A.Record)
    assert len(expr.fields) == 2


def test_parse_unit_literal():
    expr = parse_expr("()")
    assert isinstance(expr, A.UnitLit)


def test_parse_invalid_input_raises():
    with pytest.raises(ParseError):
        parse_expr("fn ->")
