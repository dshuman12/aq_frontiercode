from __future__ import annotations

import pytest

from lyra.bytecode import CompiledFunction, CompiledModule
from lyra.objects.model import alloc_string, value_repr
from lyra.stdlib import PRIMITIVE_TABLE
from lyra.vm import VM
from lyra.vm.frame import Frame


def fresh_frame() -> Frame:
    return Frame(function=CompiledFunction(label="t", arity=0,
                                            upvalue_count=0, local_count=0,
                                            code=b""))


def call_primitive(prim_index: int, *args) -> object:
    vm = VM(module=CompiledModule())
    frame = fresh_frame()
    for arg in args:
        frame.push(arg)
    PRIMITIVE_TABLE[prim_index](vm, frame)
    return frame.pop()


def test_int_add():
    assert call_primitive(0x01, 2, 3) == 5


def test_int_sub():
    assert call_primitive(0x02, 7, 2) == 5


def test_int_mul():
    assert call_primitive(0x03, 4, 3) == 12


def test_int_div():
    assert call_primitive(0x04, 7, 2) == 3


def test_int_mod():
    assert call_primitive(0x05, 7, 3) == 1


def test_int_div_by_zero_raises():
    from lyra.errors import DivisionByZero

    with pytest.raises(DivisionByZero):
        call_primitive(0x04, 1, 0)


def test_eq_int():
    assert call_primitive(0x10, 2, 2) is True


def test_lt():
    assert call_primitive(0x12, 1, 2) is True
    assert call_primitive(0x12, 2, 1) is False


def test_string_concat():
    a = alloc_string("foo")
    b = alloc_string("bar")
    out = call_primitive(0x30, a, b)
    assert out.payload == "foobar"


def test_string_length():
    s = alloc_string("hello")
    assert call_primitive(0x31, s) == 5


def test_bool_and():
    assert call_primitive(0x20, True, False) is False


def test_bool_or():
    assert call_primitive(0x21, False, True) is True


def test_panic_raises():
    from lyra.errors import UncaughtUserException

    with pytest.raises(UncaughtUserException):
        call_primitive(0xF0, alloc_string("oh no"))
