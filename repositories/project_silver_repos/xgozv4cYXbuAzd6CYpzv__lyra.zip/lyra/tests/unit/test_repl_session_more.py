from __future__ import annotations

import pytest

from lyra.runtime.session import ReplSession


def test_session_handles_chained_let_in_expressions():
    session = ReplSession()
    outcome = session.feed("let x = 1 in x + 1")
    assert outcome.kind == "expression"


def test_session_outcome_has_names():
    session = ReplSession()
    outcome = session.feed("let q = 5")
    assert "q" in outcome.names


def test_session_after_reset_no_known_names():
    session = ReplSession()
    session.feed("let foo = 1")
    session.reset()
    assert list(session.known_names()) == []


def test_outcome_primary_type_is_first_value():
    session = ReplSession()
    outcome = session.feed("1 + 2")
    assert outcome.primary_type is not None


def test_two_let_decls_same_name_overwrite_in_session():
    session = ReplSession()
    session.feed("let n = 1")
    session.feed("let n = 2")
    assert "n" in session.bindings
