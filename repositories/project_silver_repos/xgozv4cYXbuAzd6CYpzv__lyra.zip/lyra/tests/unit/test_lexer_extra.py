from __future__ import annotations

import pytest

from lyra.errors import LexerError
from lyra.lexer import TokenKind, tokenize


def test_dotdot_is_operator_not_float():
    tokens = tokenize("1..2")
    kinds = [t.kind for t in tokens]
    assert TokenKind.INT in kinds and TokenKind.OP in kinds


def test_underscore_in_int_literal():
    tokens = tokenize("1_000_000")
    assert tokens[0].text == "1000000"


def test_negative_lookahead_after_minus():
    tokens = tokenize("-1")
    assert tokens[0].kind == TokenKind.OP
    assert tokens[1].kind == TokenKind.INT


def test_string_with_tab_escape():
    tokens = tokenize(r'"a\tb"')
    assert tokens[0].text == "a\tb"


def test_unknown_escape_raises():
    with pytest.raises(LexerError):
        tokenize(r'"\q"')


def test_quoted_identifier_via_apostrophe():
    tokens = tokenize("foo' bar")
    assert tokens[0].text == "foo'"
    assert tokens[1].text == "bar"


def test_consecutive_keywords():
    tokens = tokenize("let rec fn x")
    assert tokens[0].is_keyword("let")
    assert tokens[1].is_keyword("rec")
    assert tokens[2].is_keyword("fn")


def test_block_comment_with_star_then_slash():
    tokens = tokenize("/* hi */ ok")
    assert tokens[0].kind == TokenKind.LIDENT and tokens[0].text == "ok"


def test_eof_is_idempotent():
    tokens = tokenize("")
    assert tokens[-1].kind == TokenKind.EOF


def test_position_resets_after_newline():
    tokens = tokenize("a\nb")
    assert tokens[0].position.line == 1 and tokens[0].position.column == 1
    assert tokens[1].position.line == 2 and tokens[1].position.column == 1
