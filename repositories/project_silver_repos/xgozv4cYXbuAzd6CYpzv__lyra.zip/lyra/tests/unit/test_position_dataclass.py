from __future__ import annotations

from lyra.errors import Position


def test_position_default_offset_zero():
    assert Position().offset == 0


def test_position_render_includes_file_line_col():
    pos = Position(file="m.lyra", line=10, column=5)
    assert pos.render() == "m.lyra:10:5"


def test_position_repr_does_not_explode():
    repr(Position(file="m", line=1, column=1))


def test_position_is_frozen():
    pos = Position(file="m", line=1, column=1)
    try:
        pos.line = 2  # type: ignore[misc]
    except Exception:
        pass
    assert pos.line == 1
