from __future__ import annotations

import pytest

from lyra.errors import UndefinedName
from lyra.parser import parse_module
from lyra.resolve import resolve_module


def test_imported_module_alias_visible():
    module = parse_module(
        "import Std.Map as M\n"
        "let main = M"
    )
    resolve_module(module)


def test_module_qualified_name_skips_resolve():
    module = parse_module(
        "import Std.Map\n"
        "let main = Std.lookup"
    )
    # ``Std.lookup`` is module-qualified; the resolver trusts the import decl.
    resolve_module(module)


def test_imported_items_become_local():
    module = parse_module(
        "import Std.Map { lookup, insert }\n"
        "let main = lookup"
    )
    resolve_module(module)


def test_bare_name_without_import_fails():
    module = parse_module("let main = nothing_imported")
    with pytest.raises(UndefinedName):
        resolve_module(module)
