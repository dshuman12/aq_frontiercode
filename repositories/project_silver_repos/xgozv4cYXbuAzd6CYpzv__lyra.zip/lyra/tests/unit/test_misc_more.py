from __future__ import annotations

from lyra.bytecode import CompiledModule
from lyra.constants import (
    DEFAULT_INITIAL_STACK,
    DEFAULT_MAX_STACK,
    DEFAULT_REPL_HISTORY,
    INITIAL_GENERATION_LEVEL,
    MAX_TYPE_VAR_LEVEL,
)


def test_default_stack_sizes_make_sense():
    assert DEFAULT_INITIAL_STACK > 0
    assert DEFAULT_MAX_STACK > DEFAULT_INITIAL_STACK


def test_repl_history_is_path_like_string():
    assert isinstance(DEFAULT_REPL_HISTORY, str)


def test_initial_generation_level_zero():
    assert INITIAL_GENERATION_LEVEL == 0


def test_max_type_var_level_positive():
    assert MAX_TYPE_VAR_LEVEL > 100


def test_compiled_module_default_empty():
    module = CompiledModule()
    assert module.constants == [] and module.functions == []
    assert module.imports == [] and module.exports == []
