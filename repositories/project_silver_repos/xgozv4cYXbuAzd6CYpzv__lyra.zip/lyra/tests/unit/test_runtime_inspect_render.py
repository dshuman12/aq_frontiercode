from __future__ import annotations

from lyra.bytecode.format import CompiledFunction, CompiledModule, CONST_INT, Constant
from lyra.runtime.inspect import summarise
from lyra.types import T_INT


def test_render_with_imports():
    module = CompiledModule(imports=["A", "B"])
    text = summarise(module).render()
    assert "imports" in text


def test_render_with_exports_lists_them():
    module = CompiledModule(
        functions=[CompiledFunction(label="main", arity=0,
                                     upvalue_count=0, local_count=0, code=b"\xff")],
        exports=[("main", 0)],
    )
    text = summarise(module).render()
    assert "main" in text


def test_render_default_no_exports_dash():
    module = CompiledModule()
    text = summarise(module).render()
    assert "-" in text


def test_render_with_typed_bindings_aligned():
    module = CompiledModule()
    text = summarise(module, types={"foo": T_INT, "barley": T_INT}).render()
    assert "foo" in text and "barley" in text
