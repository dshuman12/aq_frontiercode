from __future__ import annotations

import pytest

from lyra.bytecode.format import (
    CONST_INT,
    CONST_UNIT,
    CompiledFunction,
    CompiledModule,
    Constant,
    decode,
    encode,
)
from lyra.constants import (
    BYTECODE_MAGIC,
    OP_HALT,
    OP_LOAD_CONST,
    OP_RETURN,
)
from lyra.errors import LyraError
from lyra.gc import GenerationalGC, GcStats
from lyra.objects.model import Box, alloc_string, equal, value_repr
from lyra.parser import parse_expr
from lyra.parser import ast as A
from lyra.parser.printer import render_expr
from lyra.types import T_BOOL, T_INT, T_STRING, fresh_var, infer_expression


def test_lyra_error_default_code_well_formed():
    err = LyraError("x")
    assert err.code.startswith("LY")


def test_compiled_module_with_one_function_round_trip():
    fn = CompiledFunction(label="x", arity=0, upvalue_count=0,
                           local_count=0, code=bytes([OP_HALT]))
    module = CompiledModule(functions=[fn])
    assert decode(encode(module)).functions[0].label == "x"


def test_constant_int_round_trip():
    module = CompiledModule(constants=[Constant(kind=CONST_INT, value=-42)])
    assert decode(encode(module)).constants[0].value == -42


def test_constant_unit_round_trip():
    module = CompiledModule(constants=[Constant(kind=CONST_UNIT, value=None)])
    assert decode(encode(module)).constants[0].value is None


def test_bytecode_magic_first_eight_bytes():
    fn = CompiledFunction(label="x", arity=0, upvalue_count=0,
                           local_count=0, code=bytes([OP_HALT]))
    blob = encode(CompiledModule(functions=[fn]))
    assert blob[: len(BYTECODE_MAGIC)] == BYTECODE_MAGIC


def test_gc_default_stats_zero():
    stats = GcStats()
    assert stats.minor_collections == 0
    assert stats.bytes_allocated == 0


def test_gc_root_provider_callable():
    gc = GenerationalGC()
    gc.root_provider = lambda: []
    assert gc._collect_roots() == []


def test_gc_remembered_set_starts_empty():
    gc = GenerationalGC()
    assert gc.remembered_set == set()


def test_box_default_color_white():
    box = Box(class_id=1, payload="x")
    assert box.color == 0


def test_value_repr_handles_string_with_quotes():
    text = value_repr(alloc_string("a'b"))
    assert "'" in text


def test_equal_int_zero():
    assert equal(0, 0)


def test_equal_distinct_ints_false():
    assert not equal(1, 2)


def test_render_expr_does_not_crash_on_int():
    text = render_expr(A.IntLit(value=5))
    assert text == "5"


def test_render_expr_handles_lambda_in_isolation():
    expr = A.Lambda(
        params=[A.PVar(name="x")],
        body=A.Var(name="x"),
    )
    assert "fn" in render_expr(expr)


def test_inference_of_bool_arithmetic_rejects_mismatch():
    from lyra.errors import UnificationError

    with pytest.raises(UnificationError):
        infer_expression(parse_expr("1 && 2"))


def test_inference_string_predicate():
    assert infer_expression(parse_expr('"a" == "b"')) is T_BOOL


def test_fresh_var_assigned_level():
    var = fresh_var(level=4)
    assert var.level == 4


def test_load_const_then_return_pattern():
    code = bytes([OP_LOAD_CONST]) + (0).to_bytes(2, "little") + bytes([OP_RETURN])
    fn = CompiledFunction(label="x", arity=0, upvalue_count=0,
                           local_count=0, code=code)
    module = CompiledModule(constants=[Constant(kind=CONST_INT, value=99)],
                             functions=[fn])
    decoded = decode(encode(module))
    assert decoded.functions[0].code == code
