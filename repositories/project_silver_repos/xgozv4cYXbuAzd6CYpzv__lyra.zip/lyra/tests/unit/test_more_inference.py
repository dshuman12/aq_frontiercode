from __future__ import annotations

import pytest

from lyra.errors import UnificationError
from lyra.parser import parse_expr, parse_module
from lyra.types import T_BOOL, T_INT, infer_expression, infer_module


def test_infer_function_with_annotated_arg():
    module = parse_module(
        "let inc : Int -> Int = fn x -> x + 1\n"
        "let main = inc 1"
    )
    types = infer_module(module)
    assert "inc" in types


def test_infer_compare_returns_bool():
    assert infer_expression(parse_expr("1 < 2")) is T_BOOL


def test_infer_let_in_scope_returns_inner():
    ty = infer_expression(parse_expr("let x = 1 in x + 1"))
    assert ty is T_INT


def test_infer_higher_order_function():
    module = parse_module(
        "let apply = fn f x -> f x\n"
        "let main = apply (fn n -> n + 1) 1"
    )
    types = infer_module(module)
    assert "apply" in types and "main" in types


def test_infer_constructor_arity_check():
    with pytest.raises(Exception):
        infer_expression(parse_expr("Just 1 2"))


def test_infer_match_unifies_arm_types():
    module = parse_module(
        "type T = A | B\n"
        "let f = fn t -> match t {\n"
        "    A -> 0\n"
        "    B -> 1\n"
        "}"
    )
    types = infer_module(module)
    assert "f" in types
