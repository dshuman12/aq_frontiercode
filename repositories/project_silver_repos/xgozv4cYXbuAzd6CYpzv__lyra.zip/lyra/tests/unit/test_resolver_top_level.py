from __future__ import annotations

import pytest

from lyra.errors import UndefinedName
from lyra.parser import parse_module
from lyra.resolve import resolve_module


def test_top_level_function_visible_below():
    module = parse_module(
        "let f = fn x -> x\n"
        "let main = f 1"
    )
    resolve_module(module)


def test_top_level_function_visible_above():
    module = parse_module(
        "let main = f 1\n"
        "let f = fn x -> x"
    )
    resolve_module(module)


def test_constructor_resolves_anywhere():
    module = parse_module(
        "let main = Just 1\n"
        "type Maybe a = Nothing | Just a"
    )
    resolve_module(module)


def test_undefined_at_top_level_raises():
    module = parse_module("let main = oops")
    with pytest.raises(UndefinedName):
        resolve_module(module)
