from __future__ import annotations

from lyra.bytecode.format import CompiledFunction, CompiledModule, CONST_INT, Constant
from lyra.runtime.inspect import summarise


def test_summary_handles_constants_only():
    module = CompiledModule(
        constants=[Constant(kind=CONST_INT, value=1), Constant(kind=CONST_INT, value=2)],
    )
    summary = summarise(module)
    assert summary.constant_count == 2


def test_summary_uses_anon_when_no_name():
    module = CompiledModule()
    summary = summarise(module)
    assert "<anon>" in summary.render()


def test_summary_lists_export_names():
    module = CompiledModule(
        functions=[CompiledFunction(label="main", arity=0,
                                     upvalue_count=0, local_count=0,
                                     code=b"\xff")],
        exports=[("main", 0), ("alt", 0)],
    )
    summary = summarise(module)
    assert "main" in summary.export_names and "alt" in summary.export_names


def test_summary_no_bindings_section_when_types_empty():
    module = CompiledModule()
    text = summarise(module).render()
    assert "bindings" not in text
