from __future__ import annotations

from lyra.ir import nodes as I
from lyra.parser import ast as A


def test_ast_int_default_value():
    expr = A.IntLit()
    assert expr.value == 0


def test_ast_bool_default_value():
    expr = A.BoolLit()
    assert expr.value is False


def test_ast_var_default_module_is_none():
    expr = A.Var(name="x")
    assert expr.module is None


def test_ir_function_default_top_level_false():
    fn = I.Function(label="f")
    assert fn.is_top_level is False


def test_ir_block_default_empty():
    block = I.Block()
    assert block.bindings == [] and block.result is None


def test_ir_call_default_not_tail():
    call = I.CallExpr()
    assert call.is_tail is False


def test_ir_match_arm_default_empty():
    match = I.MatchTagExpr()
    assert match.arms == [] and match.default is None


def test_ir_alloc_default_class_zero():
    alloc = I.AllocExpr()
    assert alloc.class_id == 0 and alloc.tag == 0


def test_ir_constructor_spec_carries_arity():
    spec = I.ConstructorSpec(name="Cons", tag=1, arity=2)
    assert spec.arity == 2
