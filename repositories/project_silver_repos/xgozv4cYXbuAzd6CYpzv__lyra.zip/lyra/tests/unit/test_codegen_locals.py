from __future__ import annotations

from lyra.codegen import emit_module
from lyra.ir import nodes as I


def test_local_count_includes_params_and_bindings():
    body = I.Block(
        bindings=[I.Binding(name="t", expr=I.AtomExpr(atom=I.IntAtom(value=1)))],
        result=I.VarAtom(name="t"),
    )
    func = I.Function(label="f", params=["x"], body=body)
    module = emit_module(I.Module(functions=[func]))
    assert module.functions[0].local_count >= 2


def test_local_count_zero_when_no_bindings():
    body = I.Block(result=I.IntAtom(value=1))
    func = I.Function(label="f", params=[], body=body)
    module = emit_module(I.Module(functions=[func]))
    assert module.functions[0].local_count >= 0


def test_arity_matches_params():
    func = I.Function(label="f", params=["a", "b", "c"],
                       body=I.Block(result=I.VarAtom(name="a")))
    module = emit_module(I.Module(functions=[func]))
    assert module.functions[0].arity == 3


def test_module_init_function_emitted_for_globals():
    module = emit_module(I.Module(
        globals_=[I.Binding(name="x", expr=I.AtomExpr(atom=I.IntAtom(value=1)))],
    ))
    assert any(fn.label == "@module_init" for fn in module.functions)


def test_module_with_only_global_returns_unit():
    module = emit_module(I.Module(
        globals_=[I.Binding(name="x", expr=I.AtomExpr(atom=I.IntAtom(value=1)))],
    ))
    init_fn = next(fn for fn in module.functions if fn.label == "@module_init")
    # Code ends with RETURN (0x12).
    assert init_fn.code.endswith(bytes([0x12]))
