from __future__ import annotations

import pytest

from lyra.gc import GenerationalGC
from lyra.objects.model import alloc_closure, alloc_data, alloc_tuple


def test_gc_default_construction():
    gc = GenerationalGC()
    assert gc.young == [] and gc.old == []


def test_gc_stats_reset_on_construction():
    gc = GenerationalGC()
    assert gc.stats.minor_collections == 0
    assert gc.stats.major_collections == 0


def test_gc_root_provider_default_none():
    gc = GenerationalGC()
    assert gc._collect_roots() == []


def test_gc_traces_through_tuple_payload():
    gc = GenerationalGC(young_bytes_limit=128)
    inner = gc.allocate(alloc_data(0, []))
    outer = gc.allocate(alloc_tuple([inner]))
    gc.root_provider = lambda: [outer]
    gc.minor_collect()
    assert outer in gc.young or outer in gc.old


def test_gc_traces_through_closure_upvalues():
    gc = GenerationalGC(young_bytes_limit=128)
    captured = gc.allocate(alloc_data(0, []))
    closure = gc.allocate(alloc_closure("f", [captured]))
    gc.root_provider = lambda: [closure]
    gc.minor_collect()
    assert captured in gc.young or captured in gc.old


def test_write_barrier_only_when_old_to_young():
    gc = GenerationalGC()
    young_a = gc.allocate(alloc_data(0, []))
    young_b = gc.allocate(alloc_data(0, []))
    gc.write_barrier(young_a, young_b)
    assert id(young_a) not in gc.remembered_set


def test_major_collect_runs_after_minor():
    gc = GenerationalGC()
    gc.allocate(alloc_data(0, []))
    gc.root_provider = lambda: []
    gc.minor_collect()
    gc.major_collect()
    assert gc.stats.major_collections == 1
