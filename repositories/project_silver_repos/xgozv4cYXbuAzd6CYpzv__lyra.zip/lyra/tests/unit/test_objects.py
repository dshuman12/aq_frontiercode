from __future__ import annotations

import pytest

from lyra.objects.model import (
    alloc_data,
    alloc_string,
    alloc_tuple,
    equal,
    is_string,
    tag_int,
    untag_int,
    value_repr,
)


def test_tag_int_round_trip():
    assert untag_int(tag_int(42)) == 42


def test_tag_int_handles_negative():
    assert untag_int(tag_int(-7)) == -7


def test_tag_int_overflow_raises():
    with pytest.raises(OverflowError):
        tag_int(1 << 70)


def test_string_equality():
    a = alloc_string("hi")
    b = alloc_string("hi")
    assert equal(a, b)


def test_string_inequality():
    assert not equal(alloc_string("a"), alloc_string("b"))


def test_data_constructor_equality():
    a = alloc_data(0, [1, alloc_string("ok")])
    b = alloc_data(0, [1, alloc_string("ok")])
    assert equal(a, b)


def test_tuple_equality_by_elements():
    a = alloc_tuple([1, alloc_string("x")])
    b = alloc_tuple([1, alloc_string("x")])
    assert equal(a, b)


def test_value_repr_int():
    assert value_repr(7) == "7"


def test_value_repr_string():
    assert value_repr(alloc_string("hi")) == "'hi'"


def test_is_string_predicate():
    assert is_string(alloc_string("ok"))
    assert not is_string(7)
