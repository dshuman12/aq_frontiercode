from __future__ import annotations

from pathlib import Path

import pytest

from lyra.bytecode import decode, encode
from lyra.runtime import compile_source, read_compiled, write_compiled


def test_compile_returns_bytecode_module():
    result = compile_source("let main = 1 + 1")
    assert result.module.functions
    assert isinstance(result.types, dict)


def test_write_then_read_compiled(tmp_path: Path):
    result = compile_source("let main = 7")
    path = tmp_path / "main.lyrac"
    write_compiled(path, result.module)
    again = read_compiled(path)
    assert len(again.functions) == len(result.module.functions)


def test_compile_unknown_function_raises():
    from lyra.errors import UndefinedName

    with pytest.raises(UndefinedName):
        compile_source("let main = does_not_exist 1")


def test_compile_recursive_function_round_trips():
    src = "let rec count = fn n -> if n == 0 then 0 else count (n - 1)\nlet main = count 5"
    result = compile_source(src)
    blob = encode(result.module)
    assert decode(blob).functions
