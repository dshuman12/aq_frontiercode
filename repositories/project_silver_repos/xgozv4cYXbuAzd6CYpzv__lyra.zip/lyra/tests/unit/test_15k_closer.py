from __future__ import annotations

import pytest

from lyra.bytecode.format import CompiledFunction, CompiledModule, decode, encode
from lyra.errors import Position
from lyra.gc.generational import GcStats
from lyra.objects.model import (
    alloc_record,
    is_record,
    is_string,
    value_repr,
    alloc_string,
)


def test_gc_stats_has_promotions_field():
    stats = GcStats()
    assert stats.bytes_promoted == 0


def test_alloc_record_keys_match_inputs():
    box = alloc_record(["a", "b"], [1, 2])
    assert set(box.payload) == {"a", "b"}


def test_is_record_recognises_record():
    box = alloc_record(["x"], [1])
    assert is_record(box)


def test_value_repr_for_record():
    text = value_repr(alloc_record(["x"], [7]))
    assert "x" in text


def test_position_default_file_unknown():
    p = Position()
    assert "unknown" in p.file


def test_decode_function_with_zero_locals():
    fn = CompiledFunction(label="z", arity=0, upvalue_count=0,
                           local_count=0, code=b"\xff")
    module = decode(encode(CompiledModule(functions=[fn])))
    assert module.functions[0].local_count == 0


def test_encoded_module_roughly_matches_size_baseline():
    fn = CompiledFunction(label="m", arity=0, upvalue_count=0,
                           local_count=0, code=b"\xff")
    blob = encode(CompiledModule(functions=[fn]))
    assert len(blob) > 16  # at least magic + headers


def test_string_box_is_string():
    assert is_string(alloc_string("ok"))
