from __future__ import annotations

import pytest

from lyra.lexer import KEYWORDS, TokenKind, tokenize


@pytest.mark.parametrize("word", sorted(KEYWORDS))
def test_keyword_recognised(word: str):
    tokens = tokenize(word)
    assert tokens[0].kind == TokenKind.KEYWORD
    assert tokens[0].text == word


@pytest.mark.parametrize("word", ["lett", "fnny", "matchy", "iff"])
def test_keyword_with_extra_letter_is_lident(word: str):
    tokens = tokenize(word)
    assert tokens[0].kind == TokenKind.LIDENT


def test_keyword_set_immutable():
    # Defensive: we expect KEYWORDS to be a frozenset.
    assert isinstance(KEYWORDS, frozenset)


def test_keyword_count_within_reasonable_bounds():
    # Sanity: less than 100 keywords (kept the language small).
    assert 30 <= len(KEYWORDS) < 100
