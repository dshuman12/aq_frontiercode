from __future__ import annotations

from lyra.types.repr import (
    T_BOOL,
    T_INT,
    TApp,
    TFun,
    TRecord,
    TTuple,
    TVar,
    adjust_levels,
    fresh_var,
    walk,
)


def test_fresh_var_unique():
    a = fresh_var(level=0)
    b = fresh_var(level=0)
    assert a.name != b.name


def test_var_find_compresses_chain():
    a = fresh_var(level=0)
    b = fresh_var(level=0)
    a.forwarded = b
    b.forwarded = T_INT
    a.find()
    assert a.forwarded is T_INT


def test_walk_yields_each_node():
    fn = TFun(params=[T_INT], result=T_BOOL)
    nodes = list(walk(fn))
    assert T_INT in nodes and T_BOOL in nodes


def test_app_repr_includes_args():
    ty = TApp(name="List", args=[T_INT])
    assert "List" in repr(ty) and "Int" in repr(ty)


def test_tuple_repr_uses_parens():
    ty = TTuple(elements=[T_INT, T_BOOL])
    assert repr(ty).startswith("(") and repr(ty).endswith(")")


def test_record_repr_lists_fields():
    ty = TRecord(fields={"x": T_INT, "y": T_BOOL})
    assert "x:" in repr(ty)


def test_adjust_levels_lowers_high_var():
    var = fresh_var(level=5)
    fn = TFun(params=[var], result=var)
    adjust_levels(fn, max_level=2)
    assert var.level == 2


def test_adjust_levels_does_not_raise_below():
    var = fresh_var(level=1)
    adjust_levels(var, max_level=3)
    assert var.level == 1
