from __future__ import annotations

from lyra.ir import nodes as I
from lyra.optimize import optimize


def make_module() -> I.Module:
    body = I.Block(
        bindings=[
            I.Binding(name="x", expr=I.PrimExpr(name="int_add",
                                                 args=[I.IntAtom(value=2),
                                                       I.IntAtom(value=3)])),
            I.Binding(name="dead", expr=I.AtomExpr(atom=I.IntAtom(value=99))),
        ],
        result=I.VarAtom(name="x"),
    )
    func = I.Function(label="main", body=body, is_top_level=True)
    return I.Module(functions=[func])


def test_optimize_runs_to_fixed_point():
    module = make_module()
    optimize(module)
    bindings = module.functions[0].body.bindings
    # constant folding + DCE eliminate the dead binding and replace x with a literal.
    assert all(b.name != "dead" for b in bindings)
    folded = bindings[0]
    assert isinstance(folded.expr, I.AtomExpr)


def test_optimize_idempotent():
    module = make_module()
    optimize(module)
    snapshot = [b.name for b in module.functions[0].body.bindings]
    optimize(module)
    assert [b.name for b in module.functions[0].body.bindings] == snapshot


def test_optimize_handles_module_with_no_functions():
    module = I.Module()
    optimize(module)
