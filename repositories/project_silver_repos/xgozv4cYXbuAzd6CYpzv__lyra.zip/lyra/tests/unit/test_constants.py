from __future__ import annotations

from lyra.constants import (
    BYTECODE_MAGIC,
    BYTECODE_VERSION,
    DEFAULT_PROMOTION_AGE,
    DEFAULT_YOUNG_BYTES,
    MAX_TAGGED_INT,
    MIN_TAGGED_INT,
    OP_CALL,
    OP_HALT,
    OP_LOAD_CONST,
    OP_RETURN,
    OP_TAIL_CALL,
)


def test_bytecode_magic_is_lyra0001():
    assert BYTECODE_MAGIC == b"LYRA0001"


def test_bytecode_version_is_one():
    assert BYTECODE_VERSION == 1


def test_call_and_tail_call_distinct():
    assert OP_CALL != OP_TAIL_CALL


def test_load_const_distinct_from_return():
    assert OP_LOAD_CONST != OP_RETURN


def test_halt_is_max_byte():
    assert OP_HALT == 0xFF


def test_tagged_int_range_is_signed_62_bit():
    assert MAX_TAGGED_INT == (1 << 62) - 1
    assert MIN_TAGGED_INT == -(1 << 62)


def test_default_young_bytes_positive():
    assert DEFAULT_YOUNG_BYTES > 0


def test_default_promotion_age_at_least_one():
    assert DEFAULT_PROMOTION_AGE >= 1
