from __future__ import annotations

import struct

from lyra.bytecode import (
    CompiledFunction,
    CompiledModule,
    disassemble_function,
    disassemble_module,
)
from lyra.constants import (
    OP_ALLOC,
    OP_CALL,
    OP_GET_FIELD,
    OP_HALT,
    OP_JUMP,
    OP_JUMP_IF_FALSE,
    OP_JUMP_IF_TRUE,
    OP_LOAD_CONST,
    OP_LOAD_GLOBAL,
    OP_LOAD_LOCAL,
    OP_LOAD_UPVAL,
    OP_MAKE_CLOSURE,
    OP_MATCH_TAG,
    OP_NOP,
    OP_POP,
    OP_PRIM,
    OP_RETURN,
    OP_STORE_LOCAL,
    OP_TAIL_CALL,
)


def emit(*opcodes_with_operand: tuple[int, int | None]) -> bytes:
    out = bytearray()
    for op, operand in opcodes_with_operand:
        out.append(op)
        if operand is not None:
            out.extend(struct.pack("<H", operand))
    return bytes(out)


def test_disasm_each_opcode_kind():
    code = emit(
        (OP_NOP, None),
        (OP_LOAD_CONST, 0),
        (OP_LOAD_LOCAL, 0),
        (OP_STORE_LOCAL, 1),
        (OP_LOAD_UPVAL, 0),
        (OP_LOAD_GLOBAL, 0),
        (OP_POP, None),
        (OP_CALL, 1),
        (OP_TAIL_CALL, 1),
        (OP_RETURN, None),
        (OP_MAKE_CLOSURE, 0),
        (OP_JUMP, 100),
        (OP_JUMP_IF_FALSE, 100),
        (OP_JUMP_IF_TRUE, 100),
        (OP_MATCH_TAG, 0),
        (OP_ALLOC, 0),
        (OP_GET_FIELD, 0),
        (OP_PRIM, 1),
        (OP_HALT, None),
    )
    fn = CompiledFunction(label="t", arity=0, upvalue_count=0,
                           local_count=4, code=code)
    text = disassemble_function(fn)
    for token in [
        "NOP", "LOAD_CONST", "LOAD_LOCAL", "STORE_LOCAL", "LOAD_UPVAL",
        "LOAD_GLOBAL", "POP", "CALL", "TAIL_CALL", "RETURN",
        "MAKE_CLOSURE", "JUMP", "JUMP_IF_FALSE", "JUMP_IF_TRUE",
        "MATCH_TAG", "ALLOC", "GET_FIELD", "PRIM", "HALT",
    ]:
        assert token in text, f"missing opcode mnemonic: {token}"


def test_disasm_module_renders_all_sections():
    fn = CompiledFunction(label="main", arity=0, upvalue_count=0,
                           local_count=0, code=bytes([OP_HALT]))
    module = CompiledModule(
        functions=[fn],
        imports=["A"],
        exports=[("main", 0)],
    )
    text = disassemble_module(module)
    assert "constants" in text
    assert "imports" in text
    assert "exports" in text
    assert "functions" in text
