from __future__ import annotations

from lyra.errors import LexerError, ParseError, Position
from lyra.utils.diagnostics import format_chain, format_error


def test_format_error_includes_code():
    err = LexerError("oops")
    diagnostic = format_error(err)
    assert "LY1001" in diagnostic.rendered


def test_format_error_with_source_emits_caret():
    pos = Position(file="t", line=2, column=3)
    err = ParseError("bad", position=pos)
    diagnostic = format_error(err, source="ok\nbad code")
    assert "^" in diagnostic.rendered


def test_format_error_skips_caret_without_source():
    err = ParseError("bad", position=Position(file="t", line=1, column=1))
    diagnostic = format_error(err)
    assert "^" not in diagnostic.rendered


def test_format_error_with_hint():
    err = ParseError("bad", hint="did you mean ;?")
    diagnostic = format_error(err)
    assert "did you mean" in diagnostic.rendered


def test_format_chain_joins_diagnostics():
    err_a = ParseError("a")
    err_b = ParseError("b")
    text = format_chain([err_a, err_b])
    assert "a" in text and "b" in text


def test_format_error_emits_context():
    err = ParseError("bad", context={"got": "foo"})
    diagnostic = format_error(err)
    assert "got" in diagnostic.rendered
