from __future__ import annotations

from lyra.errors import Position
from lyra.lexer import Token, TokenKind


def make(kind: TokenKind, text: str = "") -> Token:
    return Token(kind=kind, text=text, position=Position())


def test_is_keyword_matches_one_of():
    tok = make(TokenKind.KEYWORD, "let")
    assert tok.is_keyword("let")
    assert tok.is_keyword("let", "rec")


def test_is_keyword_negative_for_non_keyword():
    tok = make(TokenKind.LIDENT, "x")
    assert not tok.is_keyword("x")


def test_is_op_matches():
    tok = make(TokenKind.OP, "==")
    assert tok.is_op("==", "!=")
    assert not tok.is_op("+")


def test_token_repr_includes_position():
    tok = make(TokenKind.LIDENT, "x")
    assert "LIDENT" in repr(tok)
