from __future__ import annotations

from lyra.errors import LexerError, Position
from lyra.lexer import tokenize


def test_position_dataclass_equality():
    a = Position(file="x", line=1, column=2, offset=3)
    b = Position(file="x", line=1, column=2, offset=3)
    assert a == b


def test_position_inequality_on_different_offset():
    a = Position(file="x", line=1, column=2, offset=3)
    b = Position(file="x", line=1, column=2, offset=4)
    assert a != b


def test_lexer_records_offset():
    tokens = tokenize("hello world")
    assert tokens[1].position.offset >= len("hello")


def test_lexer_position_after_block_comment():
    tokens = tokenize("/* skip */ x")
    assert tokens[0].text == "x"
    assert tokens[0].position.column > 1
