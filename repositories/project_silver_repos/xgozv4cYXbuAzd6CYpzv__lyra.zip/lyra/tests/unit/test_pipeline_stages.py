from __future__ import annotations

from lyra.runtime.compiler_pipeline import (
    closure,
    codegen,
    full,
    infer,
    lex_and_parse,
    lower,
    optimise,
    resolve,
)


def test_lex_and_parse_produces_ast():
    ast = lex_and_parse("let main = 1")
    assert ast.declarations


def test_resolve_returns_same_ast():
    ast = lex_and_parse("let main = 1")
    assert resolve(ast) is ast


def test_infer_produces_types_dict():
    ast = lex_and_parse("let main = 1")
    types = infer(ast)
    assert "main" in types


def test_lower_returns_ir_module():
    ast = lex_and_parse("let main = 1")
    ir = lower(ast)
    assert ir is not None


def test_closure_then_optimize_then_codegen():
    ir = lower(lex_and_parse("let main = 1 + 2"))
    closure(ir)
    optimise(ir)
    bc = codegen(ir)
    assert bc.functions


def test_full_pipeline_returns_stage_result():
    result = full("let main = 1 + 1")
    assert result.ast and result.types and result.bytecode


def test_full_pipeline_propagates_types():
    result = full("let inc = fn x -> x + 1")
    assert "inc" in result.types
