from __future__ import annotations

import pytest

from lyra.errors import NonExhaustiveMatch, UselessPattern
from lyra.match import TypeOracle, check_match
from lyra.parser import ast as A


def make_arm(pattern, body=None):
    return A.MatchArm(pattern=pattern, body=body or A.IntLit(value=0))


def test_bool_exhaustive():
    arms = [
        make_arm(A.PBool(value=True)),
        make_arm(A.PBool(value=False)),
    ]
    check_match(arms, TypeOracle())


def test_bool_nonexhaustive():
    arms = [make_arm(A.PBool(value=True))]
    with pytest.raises(NonExhaustiveMatch):
        check_match(arms, TypeOracle())


def test_wildcard_makes_exhaustive():
    arms = [
        make_arm(A.PBool(value=True)),
        make_arm(A.PWild()),
    ]
    check_match(arms, TypeOracle())


def test_useless_pattern_rejected():
    arms = [
        make_arm(A.PWild()),
        make_arm(A.PBool(value=True)),
    ]
    with pytest.raises(UselessPattern):
        check_match(arms, TypeOracle())


def test_list_constructors_exhaustive():
    arms = [
        make_arm(A.PCon(name="Nil")),
        make_arm(A.PCon(name="Cons", args=[A.PVar(name="x"), A.PVar(name="xs")])),
    ]
    check_match(arms, TypeOracle())


def test_list_missing_nil_nonexhaustive():
    arms = [
        make_arm(A.PCon(name="Cons", args=[A.PWild(), A.PWild()])),
    ]
    with pytest.raises(NonExhaustiveMatch):
        check_match(arms, TypeOracle())
