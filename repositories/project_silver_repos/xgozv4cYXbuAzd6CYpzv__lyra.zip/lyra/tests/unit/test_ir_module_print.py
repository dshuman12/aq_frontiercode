from __future__ import annotations

from lyra.ir import nodes as I
from lyra.ir.printer import render_module


def test_render_module_includes_imports():
    module = I.Module(
        name="m",
        imports=[I.ImportSpec(module="Std")],
    )
    text = render_module(module)
    assert "imports" in text and "Std" in text


def test_render_module_includes_type_defs():
    module = I.Module(
        name="m",
        type_definitions=[I.TypeDefinition(
            name="Color",
            constructors=[
                I.ConstructorSpec(name="Red", tag=0, arity=0),
                I.ConstructorSpec(name="Blue", tag=1, arity=0),
            ],
        )],
    )
    text = render_module(module)
    assert "Color" in text and "Red" in text


def test_render_empty_module():
    module = I.Module(name="empty")
    text = render_module(module)
    assert "module empty" in text


def test_render_module_lists_globals_and_functions():
    module = I.Module(
        name="m",
        globals_=[I.Binding(name="g", expr=I.AtomExpr(atom=I.IntAtom(value=1)))],
        functions=[I.Function(label="f", body=I.Block(result=I.IntAtom(value=2)))],
    )
    text = render_module(module)
    assert "globals" in text
    assert "fn f" in text
