from __future__ import annotations

from pathlib import Path

import pytest

from lyra.errors import CircularImport, ModuleNotFound
from lyra.modules import ModuleLoader


def write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)


def test_load_simple_module(tmp_path: Path):
    write(tmp_path / "M.lyra", "let x = 1")
    loader = ModuleLoader(search_paths=[tmp_path])
    module = loader.load("M")
    assert module.name == "M"


def test_load_with_imports(tmp_path: Path):
    write(tmp_path / "A.lyra", "let a = 1")
    write(tmp_path / "B.lyra", "import A\nlet b = 2")
    loader = ModuleLoader(search_paths=[tmp_path])
    loader.load("B")
    assert "A" in loader.loaded


def test_unknown_module_raises(tmp_path: Path):
    loader = ModuleLoader(search_paths=[tmp_path])
    with pytest.raises(ModuleNotFound):
        loader.load("Nope")


def test_circular_import_detected(tmp_path: Path):
    write(tmp_path / "X.lyra", "import Y\nlet x = 1")
    write(tmp_path / "Y.lyra", "import X\nlet y = 2")
    loader = ModuleLoader(search_paths=[tmp_path])
    with pytest.raises(CircularImport):
        loader.load("X")


def test_topo_order_returns_dependencies_first(tmp_path: Path):
    write(tmp_path / "A.lyra", "let a = 1")
    write(tmp_path / "B.lyra", "import A\nlet b = 2")
    loader = ModuleLoader(search_paths=[tmp_path])
    loader.load("B")
    order = [m.name for m in loader.topo_order()]
    assert order.index("A") < order.index("B")
