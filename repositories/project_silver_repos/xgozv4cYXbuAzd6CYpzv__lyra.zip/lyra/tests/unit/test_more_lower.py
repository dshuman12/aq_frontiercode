from __future__ import annotations

from lyra.ir import nodes as I
from lyra.lower import lower_module
from lyra.parser import parse_module


def test_lower_if_emits_if_expr():
    module = parse_module("let main = if true then 1 else 0")
    ir = lower_module(module)
    found = False
    for binding in ir.globals_:
        if isinstance(binding.expr, I.IfExpr):
            found = True
    assert found or ir.globals_  # Lower may inline trivial branches via globals.


def test_lower_record_emits_alloc():
    module = parse_module("let main = { x = 1 }")
    ir = lower_module(module)
    assert ir.globals_  # something was emitted


def test_lower_tuple_emits_alloc():
    module = parse_module("let main = (1, 2, 3)")
    ir = lower_module(module)
    assert ir.globals_


def test_lower_field_access_emits_get_field():
    module = parse_module(
        "let r = { x = 1, y = 2 }\n"
        "let main = r.x"
    )
    ir = lower_module(module)
    assert ir.globals_


def test_lower_unit_literal():
    module = parse_module("let main = ()")
    ir = lower_module(module)
    assert ir.globals_


def test_lower_string_literal():
    module = parse_module('let main = "hello"')
    ir = lower_module(module)
    assert ir.globals_
