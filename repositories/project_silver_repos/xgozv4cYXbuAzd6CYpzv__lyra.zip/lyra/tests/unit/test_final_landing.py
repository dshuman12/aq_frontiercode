from __future__ import annotations

from lyra.bytecode.format import CompiledModule, decode, encode
from lyra.gc import GenerationalGC


def test_round_trip_no_functions():
    module = CompiledModule()
    decoded = decode(encode(module))
    assert decoded.functions == []


def test_gc_object_count_grows_with_alloc():
    from lyra.objects.model import alloc_data

    gc = GenerationalGC()
    before = len(gc.young)
    gc.allocate(alloc_data(0, []))
    assert len(gc.young) == before + 1


def test_gc_minor_collect_with_no_objects_no_crash():
    gc = GenerationalGC()
    gc.root_provider = lambda: []
    gc.minor_collect()
    assert gc.young == []
