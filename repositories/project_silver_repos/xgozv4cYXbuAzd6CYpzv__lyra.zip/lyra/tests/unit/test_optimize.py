from __future__ import annotations

import pytest

from lyra.ir import nodes as I
from lyra.optimize.passes import constant_fold, dead_code_elim, mark_tail_calls


def make_block(*bindings, result=None) -> I.Block:
    return I.Block(bindings=list(bindings), result=result)


def test_constant_fold_arithmetic():
    block = make_block(
        I.Binding(name="x", expr=I.PrimExpr(name="int_add",
                                            args=[I.IntAtom(value=2),
                                                  I.IntAtom(value=3)])),
        result=I.VarAtom(name="x"),
    )
    func = I.Function(label="f", body=block)
    module = I.Module(functions=[func])
    constant_fold(module)
    folded = func.body.bindings[0].expr
    assert isinstance(folded, I.AtomExpr)
    assert isinstance(folded.atom, I.IntAtom) and folded.atom.value == 5


def test_dead_binding_dropped_when_unused():
    block = make_block(
        I.Binding(name="dead", expr=I.AtomExpr(atom=I.IntAtom(value=99))),
        I.Binding(name="live", expr=I.AtomExpr(atom=I.IntAtom(value=1))),
        result=I.VarAtom(name="live"),
    )
    func = I.Function(label="f", body=block)
    module = I.Module(functions=[func])
    dead_code_elim(module)
    names = [b.name for b in func.body.bindings]
    assert "dead" not in names
    assert "live" in names


def test_dead_call_kept_for_side_effect():
    call = I.CallExpr(func=I.VarAtom(name="g"), args=[I.IntAtom(value=1)])
    block = make_block(
        I.Binding(name="ignored", expr=call),
        I.Binding(name="live", expr=I.AtomExpr(atom=I.IntAtom(value=0))),
        result=I.VarAtom(name="live"),
    )
    func = I.Function(label="f", body=block)
    module = I.Module(functions=[func])
    dead_code_elim(module)
    assert any(b.name == "ignored" for b in func.body.bindings)


def test_mark_tail_calls_sets_flag():
    call = I.CallExpr(func=I.VarAtom(name="g"), args=[])
    block = make_block(
        I.Binding(name="r", expr=call),
        result=I.VarAtom(name="r"),
    )
    func = I.Function(label="f", body=block)
    module = I.Module(functions=[func])
    mark_tail_calls(module)
    assert call.is_tail
