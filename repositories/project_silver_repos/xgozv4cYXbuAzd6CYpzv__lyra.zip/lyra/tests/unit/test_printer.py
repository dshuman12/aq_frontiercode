from __future__ import annotations

import pytest

from lyra.parser import parse_expr, parse_module
from lyra.parser.printer import render_decl, render_expr, render_module, render_type
from lyra.parser import ast as A


@pytest.mark.parametrize("source", [
    "1",
    "true",
    "fn x -> x",
    "let x = 1 in x + 1",
    "if true then 1 else 0",
    "match x { 0 -> 1, _ -> 2 }",
    "(1, 2, 3)",
    "{ x = 1, y = 2 }",
    "fn x y -> x + y",
])
def test_expr_round_trip_renders(source):
    expr = parse_expr(source)
    text = render_expr(expr)
    assert text  # at minimum, non-empty


def test_module_render_includes_name():
    module = parse_module("module Demo\nlet x = 1")
    out = render_module(module)
    assert "module Demo" in out
    assert "let x" in out


def test_let_decl_round_trip():
    module = parse_module("let id = fn x -> x")
    out = render_decl(module.declarations[0])
    assert "fn x ->" in out


def test_type_decl_render_with_constructors():
    module = parse_module("type Maybe a = Nothing | Just a")
    out = render_decl(module.declarations[0])
    assert "Nothing" in out and "Just" in out


def test_type_alias_render():
    module = parse_module("type Pair a b = (a, b)")
    out = render_decl(module.declarations[0])
    assert "Pair" in out


def test_render_type_arrow():
    ty = A.TyFun(params=[A.TyCon(name="Int")], result=A.TyCon(name="Bool"))
    assert "->" in render_type(ty)


def test_import_decl_renders_with_alias():
    module = parse_module("import Std.List as L")
    out = render_decl(module.declarations[0])
    assert "as L" in out
