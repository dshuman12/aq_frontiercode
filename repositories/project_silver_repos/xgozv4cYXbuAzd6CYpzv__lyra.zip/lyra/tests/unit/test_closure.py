from __future__ import annotations

import pytest

from lyra.closure import convert
from lyra.ir import nodes as I


def test_no_free_vars_no_upvalues():
    body = I.Block(bindings=[], result=I.VarAtom(name="x"))
    func = I.Function(label="f", params=["x"], body=body)
    module = I.Module(functions=[func])
    convert(module)
    assert func.upvalues == []


def test_free_var_becomes_upvalue():
    body = I.Block(
        bindings=[I.Binding(
            name="r",
            expr=I.PrimExpr(name="int_add",
                            args=[I.VarAtom(name="x"), I.VarAtom(name="captured")]),
        )],
        result=I.VarAtom(name="r"),
    )
    func = I.Function(label="f", params=["x"], body=body)
    module = I.Module(functions=[func])
    convert(module)
    assert "captured" in func.upvalues


def test_global_names_excluded():
    body = I.Block(
        bindings=[I.Binding(
            name="r", expr=I.AtomExpr(atom=I.VarAtom(name="g_global")),
        )],
        result=I.VarAtom(name="r"),
    )
    func = I.Function(label="f", params=[], body=body)
    module = I.Module(
        functions=[func],
        globals_=[I.Binding(name="g_global", expr=I.AtomExpr(atom=I.IntAtom(value=1)))],
    )
    convert(module)
    assert "g_global" not in func.upvalues


def test_param_not_a_free_var():
    body = I.Block(bindings=[], result=I.VarAtom(name="x"))
    func = I.Function(label="f", params=["x"], body=body)
    module = I.Module(functions=[func])
    convert(module)
    assert "x" not in func.upvalues
