from __future__ import annotations

import pytest

from lyra.codegen import emit_module
from lyra.ir import nodes as I


def test_emit_handles_function_with_no_body():
    func = I.Function(label="f", params=[], body=None)
    module = emit_module(I.Module(functions=[func]))
    assert any(fn.label == "f" for fn in module.functions)


def test_emit_assigns_locals_to_bindings():
    body = I.Block(
        bindings=[
            I.Binding(name="a", expr=I.AtomExpr(atom=I.IntAtom(value=1))),
            I.Binding(name="b", expr=I.AtomExpr(atom=I.IntAtom(value=2))),
        ],
        result=I.VarAtom(name="b"),
    )
    func = I.Function(label="f", params=[], body=body)
    module = emit_module(I.Module(functions=[func]))
    assert module.functions[0].local_count >= 2


def test_emit_constants_pool_dedupe_strings():
    body = I.Block(
        bindings=[
            I.Binding(name="a", expr=I.AtomExpr(atom=I.StringAtom(value="x"))),
            I.Binding(name="b", expr=I.AtomExpr(atom=I.StringAtom(value="x"))),
        ],
        result=I.VarAtom(name="b"),
    )
    func = I.Function(label="f", params=[], body=body)
    module = emit_module(I.Module(functions=[func]))
    strings = [c for c in module.constants if isinstance(c.value, str) and c.value == "x"]
    assert len(strings) == 1


def test_emit_module_with_globals_emits_init_function():
    module = emit_module(I.Module(
        globals_=[I.Binding(name="g", expr=I.AtomExpr(atom=I.IntAtom(value=1)))],
    ))
    assert any(fn.label == "@module_init" for fn in module.functions)


def test_emit_handles_call_expr():
    body = I.Block(
        bindings=[I.Binding(
            name="r",
            expr=I.CallExpr(func=I.VarAtom(name="g"), args=[I.IntAtom(value=1)]),
        )],
        result=I.VarAtom(name="r"),
    )
    func = I.Function(label="f", params=[], body=body)
    module = emit_module(I.Module(functions=[func]))
    assert module.functions[0].code  # non-empty
