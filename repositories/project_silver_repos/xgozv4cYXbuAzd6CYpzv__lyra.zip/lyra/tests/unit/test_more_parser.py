from __future__ import annotations

import pytest

from lyra.errors import ParseError
from lyra.parser import ast as A
from lyra.parser.parser import parse_expr, parse_module


def test_expressions_with_negation():
    expr = parse_expr("-1")
    assert isinstance(expr, A.UnaryOp)


def test_double_negation():
    expr = parse_expr("- -1")
    assert isinstance(expr, A.UnaryOp)


def test_grouping_with_parens():
    expr = parse_expr("(1)")
    assert isinstance(expr, A.IntLit)


def test_chained_let_in():
    expr = parse_expr("let x = 1 in let y = 2 in x + y")
    assert isinstance(expr, A.Let)


def test_match_with_multiple_arms():
    expr = parse_expr("match x { 1 -> 1, 2 -> 2, _ -> 0 }")
    assert isinstance(expr, A.Match)
    assert len(expr.arms) == 3


def test_record_with_three_fields():
    expr = parse_expr("{ a = 1, b = 2, c = 3 }")
    assert isinstance(expr, A.Record)
    assert len(expr.fields) == 3


def test_lambda_with_three_params():
    expr = parse_expr("fn x y z -> x + y + z")
    assert isinstance(expr, A.Lambda)
    assert len(expr.params) == 3


def test_field_chain_three_levels():
    expr = parse_expr("a.b.c.d")
    assert isinstance(expr, A.FieldAccess)


def test_dangling_keyword_rejected():
    with pytest.raises(ParseError):
        parse_module("let")


def test_match_without_arms_fine_returns_empty():
    expr = parse_expr("match x { }")
    assert isinstance(expr, A.Match)
    assert expr.arms == []
