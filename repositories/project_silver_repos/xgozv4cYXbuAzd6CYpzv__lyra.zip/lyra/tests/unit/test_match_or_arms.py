from __future__ import annotations

import pytest

from lyra.errors import NonExhaustiveMatch
from lyra.match import TypeOracle, check_match
from lyra.parser import ast as A


def make_arm(pattern, body=None):
    return A.MatchArm(pattern=pattern, body=body or A.IntLit(value=0))


def test_or_pattern_covers_all():
    arms = [
        make_arm(A.POr(options=[A.PCon(name="Nothing"),
                                  A.PCon(name="Just", args=[A.PWild()])])),
    ]
    check_match(arms, TypeOracle())


def test_or_pattern_partial_still_nonexhaustive():
    arms = [
        make_arm(A.POr(options=[A.PCon(name="Just", args=[A.PWild()])])),
    ]
    with pytest.raises(NonExhaustiveMatch):
        check_match(arms, TypeOracle())


def test_or_with_literal_then_wildcard_redundant():
    from lyra.errors import UselessPattern

    arms = [
        make_arm(A.POr(options=[A.PInt(value=1), A.PInt(value=2)])),
        make_arm(A.PWild()),
        make_arm(A.PInt(value=3)),  # unreachable after wildcard
    ]
    with pytest.raises(UselessPattern):
        check_match(arms, TypeOracle())


def test_or_with_constructor_arms_exhaustive():
    arms = [
        make_arm(A.POr(options=[A.PCon(name="Nothing")])),
        make_arm(A.PCon(name="Just", args=[A.PWild()])),
    ]
    check_match(arms, TypeOracle())
