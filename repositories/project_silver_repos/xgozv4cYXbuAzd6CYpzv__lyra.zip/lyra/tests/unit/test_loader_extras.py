from __future__ import annotations

from pathlib import Path

import pytest

from lyra.errors import ModuleNotFound
from lyra.modules import ModuleLoader


def write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)


def test_loaded_module_carries_dependencies(tmp_path: Path):
    write(tmp_path / "A.lyra", "let a = 1")
    write(tmp_path / "B.lyra", "import A\nlet b = 2")
    loader = ModuleLoader(search_paths=[tmp_path])
    module = loader.load("B")
    assert module.dependencies == ["A"]


def test_loader_returns_path(tmp_path: Path):
    write(tmp_path / "M.lyra", "let m = 1")
    loader = ModuleLoader(search_paths=[tmp_path])
    module = loader.load("M")
    assert module.path.name == "M.lyra"


def test_resolve_with_no_search_paths_raises(tmp_path: Path):
    loader = ModuleLoader(search_paths=[])
    with pytest.raises(ModuleNotFound):
        loader.load("Anything")


def test_loader_handles_dotted_names(tmp_path: Path):
    write(tmp_path / "Std" / "List.lyra", "let nil = 0")
    loader = ModuleLoader(search_paths=[tmp_path])
    module = loader.load("Std.List")
    assert module.name == "Std.List"
