from __future__ import annotations

import pytest

from lyra.errors import UndefinedName
from lyra.parser import parse_module
from lyra.resolve import resolve_module


@pytest.mark.parametrize("source", [
    "let main = 1 + 2",
    "let main = if true then 1 else 2",
    "let main = (fn x -> x) 1",
    "let main = let y = 1 in y + 1",
    "let main = (1, 2, 3)",
    "let main = { x = 1, y = 2 }",
    "let main = { x = 1 }.x",
    "let main = -5",
    "let main = !true",
    "let main = \"a\" ++ \"b\"",
])
def test_resolver_accepts_source(source: str):
    resolve_module(parse_module(source))


@pytest.mark.parametrize("source", [
    "let main = a + 1",
    "let main = if c then 1 else 2",
    "let main = { x = q }",
])
def test_resolver_rejects_undefined(source: str):
    with pytest.raises(UndefinedName):
        resolve_module(parse_module(source))
