from __future__ import annotations

import pytest

from lyra.ir import nodes as I
from lyra.lower import lower_module
from lyra.parser import parse_module


def test_lower_arithmetic_emits_prim():
    module = parse_module("let main = 1 + 2")
    ir = lower_module(module)
    found = False

    def visit(block: I.Block) -> None:
        nonlocal found
        for binding in block.bindings:
            if isinstance(binding.expr, I.PrimExpr):
                found = True
            if isinstance(binding.expr, I.IfExpr):
                if binding.expr.then_block:
                    visit(binding.expr.then_block)
                if binding.expr.else_block:
                    visit(binding.expr.else_block)

    for fn in ir.functions:
        if fn.body:
            visit(fn.body)
    # Globals contain the result; the prim shows up either there or in init function.
    if not found:
        for binding in ir.globals_:
            if isinstance(binding.expr, I.PrimExpr):
                found = True
    assert found


def test_lower_lambda_creates_closure():
    module = parse_module("let f = fn x -> x")
    ir = lower_module(module)
    assert any(fn.is_top_level for fn in ir.functions)


def test_lower_records_type_definitions():
    module = parse_module("type Bool = T | F\nlet main = T")
    ir = lower_module(module)
    assert any(td.name == "Bool" for td in ir.type_definitions)


def test_lower_records_imports():
    module = parse_module("import Std.List\nlet main = 1")
    ir = lower_module(module)
    assert any(imp.module == "Std.List" for imp in ir.imports)
