from __future__ import annotations

from lyra.lexer import TokenKind


def test_eof_present():
    assert TokenKind.EOF


def test_arrow_distinct_from_op():
    assert TokenKind.ARROW != TokenKind.OP


def test_int_distinct_from_float():
    assert TokenKind.INT != TokenKind.FLOAT


def test_lident_distinct_from_uident():
    assert TokenKind.LIDENT != TokenKind.UIDENT


def test_value_field_unique():
    values = [k.value for k in TokenKind]
    assert len(values) == len(set(values))
