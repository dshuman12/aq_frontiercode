from __future__ import annotations

from pathlib import Path

from click.testing import CliRunner

from lyra.cli.cmd_build import build
from lyra.cli.cmd_check import check
from lyra.cli.cmd_disasm import disasm
from lyra.cli.cmd_fmt import fmt


def write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)


def test_build_creates_lyrac(tmp_path: Path):
    src = tmp_path / "m.lyra"
    write(src, "let main = 1")
    runner = CliRunner()
    result = runner.invoke(build, [str(src)])
    assert result.exit_code == 0
    assert (tmp_path / "m.lyrac").exists()


def test_build_with_explicit_output(tmp_path: Path):
    src = tmp_path / "m.lyra"
    write(src, "let main = 1")
    out = tmp_path / "alt.lyrac"
    runner = CliRunner()
    result = runner.invoke(build, [str(src), "--output", str(out)])
    assert result.exit_code == 0 and out.exists()


def test_check_prints_inferred_types(tmp_path: Path):
    src = tmp_path / "m.lyra"
    write(src, "let inc = fn x -> x + 1")
    runner = CliRunner()
    result = runner.invoke(check, [str(src)])
    assert result.exit_code == 0
    assert "inc" in result.output


def test_disasm_prints_module(tmp_path: Path):
    src = tmp_path / "m.lyra"
    write(src, "let main = 1")
    runner = CliRunner()
    result = runner.invoke(disasm, [str(src)])
    assert result.exit_code == 0
    assert "main" in result.output


def test_fmt_reports_token_count(tmp_path: Path):
    src = tmp_path / "m.lyra"
    write(src, "let main = 1")
    runner = CliRunner()
    result = runner.invoke(fmt, [str(src)])
    assert result.exit_code == 0
    assert "tokens" in result.output
