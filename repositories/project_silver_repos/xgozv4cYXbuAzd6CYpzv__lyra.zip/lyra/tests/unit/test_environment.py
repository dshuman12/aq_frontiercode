from __future__ import annotations

from pathlib import Path

import pytest

from lyra.bytecode.format import CompiledModule
from lyra.runtime.environment import CompileEnvironment, cache_path, hash_file


def test_put_and_get(tmp_path: Path):
    src = tmp_path / "m.lyra"
    src.write_text("let m = 1")
    env = CompileEnvironment()
    module = CompiledModule()
    env.put(src, module)
    assert env.get(src) is module


def test_get_returns_none_when_source_changed(tmp_path: Path):
    src = tmp_path / "m.lyra"
    src.write_text("let m = 1")
    env = CompileEnvironment()
    env.put(src, CompiledModule())
    src.write_text("let m = 2")
    assert env.get(src) is None


def test_invalidate_removes_entry(tmp_path: Path):
    src = tmp_path / "m.lyra"
    src.write_text("let m = 1")
    env = CompileEnvironment()
    env.put(src, CompiledModule())
    env.invalidate(src)
    assert env.get(src) is None


def test_clear_removes_all(tmp_path: Path):
    a = tmp_path / "a.lyra"; a.write_text("let a = 1")
    b = tmp_path / "b.lyra"; b.write_text("let b = 2")
    env = CompileEnvironment()
    env.put(a, CompiledModule())
    env.put(b, CompiledModule())
    env.clear()
    assert env.get(a) is None and env.get(b) is None


def test_hash_file_stable(tmp_path: Path):
    p = tmp_path / "m.lyra"
    p.write_text("hello")
    h1 = hash_file(p)
    h2 = hash_file(p)
    assert h1 == h2


def test_cache_path_includes_digest():
    path = cache_path("/tmp/lyra", "let main = 1")
    assert str(path).endswith(".lyrac")
