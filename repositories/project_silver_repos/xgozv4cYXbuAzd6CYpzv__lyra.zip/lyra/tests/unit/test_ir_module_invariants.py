from __future__ import annotations

from lyra.ir import nodes as I
from lyra.lower import lower_module
from lyra.parser import parse_module


def test_lowered_module_function_labels_unique():
    module = parse_module(
        "let f = fn x -> x\n"
        "let g = fn y -> y"
    )
    ir = lower_module(module)
    labels = [fn.label for fn in ir.functions]
    assert len(labels) == len(set(labels))


def test_lowered_globals_assigned_once():
    module = parse_module("let a = 1\nlet b = 2")
    ir = lower_module(module)
    names = [b.name for b in ir.globals_]
    assert "a" in names and "b" in names


def test_lowered_function_body_is_block():
    module = parse_module("let f = fn x -> x")
    ir = lower_module(module)
    fn = next(f for f in ir.functions if f.is_top_level)
    assert isinstance(fn.body, I.Block)


def test_lowered_function_records_parameters():
    module = parse_module("let f = fn x y -> x + y")
    ir = lower_module(module)
    fn = next(f for f in ir.functions if f.is_top_level)
    assert fn.params == ["x", "y"]
