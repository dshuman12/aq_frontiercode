from __future__ import annotations

from lyra.parser import ast as A
from lyra.parser.parser import parse_module


def test_parse_empty_module():
    module = parse_module("")
    assert module.declarations == []


def test_parse_module_default_name():
    module = parse_module("let x = 1")
    assert module.name == "main"


def test_parse_module_explicit_name():
    module = parse_module("module Demo\nlet x = 1")
    assert module.name == "Demo"


def test_multiple_let_decls():
    module = parse_module("let a = 1\nlet b = 2\nlet c = 3")
    assert len(module.declarations) == 3


def test_type_alias_decl():
    module = parse_module("type Name = String")
    decl = module.declarations[0]
    assert isinstance(decl, A.TypeAlias)


def test_extern_decl_records_primitive():
    module = parse_module('extern foo : Int -> Int = "int_neg"')
    decl = module.declarations[0]
    assert isinstance(decl, A.ExternDecl)


def test_export_decl_lists_items():
    module = parse_module("export a, b, c")
    decl = module.declarations[0]
    assert isinstance(decl, A.ExportDecl)
    assert list(decl.items) == ["a", "b", "c"]


def test_import_with_specific_items():
    module = parse_module("import Std.List { map, filter }")
    decl = module.declarations[0]
    assert isinstance(decl, A.ImportDecl)
    assert list(decl.items or []) == ["map", "filter"]


def test_data_constructor_with_no_fields():
    module = parse_module("type Color = Red | Green | Blue")
    decl = module.declarations[0]
    assert all(c.fields == [] for c in decl.constructors)
