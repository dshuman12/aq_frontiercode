from __future__ import annotations

import pytest

from lyra.errors import UndefinedName
from lyra.parser import parse_module
from lyra.resolve import resolve_module


def test_or_pattern_binds_each_arm():
    module = parse_module(
        "type T = A Int | B Int\n"
        "let f = fn t -> match t {\n"
        "    A x | B x -> x\n"
        "}"
    )
    resolve_module(module)


def test_as_pattern_introduces_alias():
    module = parse_module(
        "let f = fn x -> match x {\n"
        "    (1 as y) -> y\n"
        "    _        -> 0\n"
        "}"
    )
    resolve_module(module)


def test_field_access_resolves_target():
    module = parse_module(
        "let f = fn r -> r.x"
    )
    resolve_module(module)


def test_unknown_constructor_raises():
    module = parse_module("let main = NotAConstructor 1")
    with pytest.raises(UndefinedName):
        resolve_module(module)


def test_imported_alias_visible():
    module = parse_module(
        "import Std.List as L\n"
        "let main = L"
    )
    resolve_module(module)


def test_import_items_visible():
    module = parse_module(
        "import Std.List { map, filter }\n"
        "let main = map"
    )
    resolve_module(module)
