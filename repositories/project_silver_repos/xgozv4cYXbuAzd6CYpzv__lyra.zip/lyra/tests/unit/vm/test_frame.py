from __future__ import annotations

from lyra.bytecode import CompiledFunction
from lyra.vm.frame import CallStack, Frame


def make_frame() -> Frame:
    return Frame(function=CompiledFunction(label="f", arity=0,
                                            upvalue_count=0, local_count=0,
                                            code=b"\x00\x01\x02\x03\x04\x05\x06"))


def test_push_pop_round_trip():
    f = make_frame()
    f.push(1); f.push(2)
    assert f.pop() == 2
    assert f.pop() == 1


def test_peek_does_not_consume():
    f = make_frame()
    f.push(7)
    assert f.peek() == 7
    assert len(f.eval_stack) == 1


def test_fetch_byte_advances_pc():
    f = make_frame()
    f.fetch_byte()
    assert f.pc == 1


def test_fetch_u16_little_endian():
    f = make_frame()
    f.pc = 1  # skip the first byte
    value = f.fetch_u16()
    assert value == 0x0201  # bytes [1]=0x01, [2]=0x02


def test_call_stack_depth():
    s = CallStack()
    s.push(make_frame())
    s.push(make_frame())
    assert s.depth() == 2


def test_call_stack_replace_top():
    s = CallStack()
    a = make_frame()
    b = make_frame()
    s.push(a)
    s.replace_top(b)
    assert s.current() is b


def test_call_stack_walk_lists_labels():
    s = CallStack()
    s.push(make_frame())
    s.push(make_frame())
    assert len(s.walk()) == 2
