from __future__ import annotations

import pytest

from lyra.codegen.emit import _PRIM_INDEX, _prim_index


def test_prim_index_known_handlers():
    assert _prim_index("int_add") == 0x01
    assert _prim_index("eq") == 0x10
    assert _prim_index("println") == 0x41


def test_prim_index_unknown_raises():
    from lyra.errors import CodegenError

    with pytest.raises(CodegenError):
        _prim_index("never_heard_of_it")


def test_prim_index_table_distinct():
    values = list(_PRIM_INDEX.values())
    assert len(values) == len(set(values))


def test_prim_index_stable():
    # Pin a few well-known values; tests of bytecode compatibility
    # depend on these.
    assert _prim_index("string_concat") == 0x30
    assert _prim_index("bool_not") == 0x22
    assert _prim_index("panic") == 0xF0
