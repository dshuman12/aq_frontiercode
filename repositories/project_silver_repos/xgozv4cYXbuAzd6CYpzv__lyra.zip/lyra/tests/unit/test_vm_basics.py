from __future__ import annotations

import pytest

from lyra.bytecode import CompiledFunction, CompiledModule, CONST_INT, Constant
from lyra.constants import (
    OP_HALT,
    OP_LOAD_CONST,
    OP_RETURN,
)
from lyra.errors import BytecodeError
from lyra.vm import VM


def make_module(*, code: bytes, constants: list[Constant] | None = None) -> CompiledModule:
    return CompiledModule(
        constants=constants or [],
        functions=[CompiledFunction(label="main", arity=0,
                                     upvalue_count=0, local_count=0,
                                     code=code)],
    )


def test_load_const_then_return():
    code = bytes([OP_LOAD_CONST]) + (0).to_bytes(2, "little") + bytes([OP_RETURN])
    module = make_module(code=code, constants=[Constant(kind=CONST_INT, value=42)])
    vm = VM(module=module)
    assert vm.run() == 42


def test_halt_terminates_immediately():
    module = make_module(code=bytes([OP_HALT]))
    vm = VM(module=module)
    vm.run()


def test_unknown_entry_function_raises():
    module = make_module(code=bytes([OP_HALT]))
    vm = VM(module=module)
    with pytest.raises(BytecodeError):
        vm.run(entry="missing")


def test_vm_default_max_call_depth():
    module = make_module(code=bytes([OP_HALT]))
    vm = VM(module=module)
    assert vm.max_call_depth >= 64
