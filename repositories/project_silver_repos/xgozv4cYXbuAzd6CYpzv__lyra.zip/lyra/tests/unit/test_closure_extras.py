from __future__ import annotations

from lyra.closure import convert
from lyra.ir import nodes as I


def test_local_binding_not_a_free_var():
    body = I.Block(
        bindings=[I.Binding(name="t", expr=I.AtomExpr(atom=I.IntAtom(value=1)))],
        result=I.VarAtom(name="t"),
    )
    func = I.Function(label="f", params=[], body=body)
    module = I.Module(functions=[func])
    convert(module)
    assert "t" not in func.upvalues


def test_function_label_is_not_free():
    body = I.Block(
        bindings=[I.Binding(
            name="r",
            expr=I.ClosureExpr(function_label="g", upvalues=[]),
        )],
        result=I.VarAtom(name="r"),
    )
    func = I.Function(label="f", params=[], body=body)
    other = I.Function(label="g", params=[], body=I.Block(result=I.IntAtom(value=0)),
                        is_top_level=True)
    module = I.Module(functions=[func, other])
    convert(module)
    assert "g" not in func.upvalues


def test_call_with_free_function():
    body = I.Block(
        bindings=[I.Binding(
            name="r", expr=I.CallExpr(func=I.VarAtom(name="external"), args=[]),
        )],
        result=I.VarAtom(name="r"),
    )
    func = I.Function(label="f", params=[], body=body)
    module = I.Module(functions=[func])
    convert(module)
    assert "external" in func.upvalues


def test_match_arm_locals_not_captured():
    arm_block = I.Block(
        bindings=[I.Binding(name="m", expr=I.AtomExpr(atom=I.VarAtom(name="x")))],
        result=I.VarAtom(name="m"),
    )
    expr = I.MatchTagExpr(scrutinee=I.VarAtom(name="x"),
                           arms=[(0, arm_block)])
    body = I.Block(
        bindings=[I.Binding(name="r", expr=expr)],
        result=I.VarAtom(name="r"),
    )
    func = I.Function(label="f", params=["x"], body=body)
    module = I.Module(functions=[func])
    convert(module)
    assert "x" not in func.upvalues
