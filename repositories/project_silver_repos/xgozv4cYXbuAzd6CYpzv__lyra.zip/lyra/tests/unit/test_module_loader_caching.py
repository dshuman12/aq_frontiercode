from __future__ import annotations

from pathlib import Path

import pytest

from lyra.modules import ModuleLoader


def write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)


def test_load_returns_cached_object(tmp_path: Path):
    write(tmp_path / "M.lyra", "let m = 1")
    loader = ModuleLoader(search_paths=[tmp_path])
    a = loader.load("M")
    b = loader.load("M")
    assert a is b


def test_load_walks_dependencies_once(tmp_path: Path):
    write(tmp_path / "X.lyra", "let x = 1")
    write(tmp_path / "A.lyra", "import X\nlet a = 1")
    write(tmp_path / "B.lyra", "import X\nlet b = 1")
    loader = ModuleLoader(search_paths=[tmp_path])
    loader.load("A")
    loader.load("B")
    assert sum(1 for m in loader.loaded if m == "X") == 1


def test_topo_order_is_stable(tmp_path: Path):
    write(tmp_path / "A.lyra", "let a = 1")
    write(tmp_path / "B.lyra", "import A\nlet b = 1")
    loader = ModuleLoader(search_paths=[tmp_path])
    loader.load("B")
    first = [m.name for m in loader.topo_order()]
    second = [m.name for m in loader.topo_order()]
    assert first == second
