from __future__ import annotations

from lyra.ir import nodes as I
from lyra.optimize.passes import (
    constant_fold,
    dead_code_elim,
    mark_tail_calls,
    optimize,
)


def make_module() -> I.Module:
    return I.Module(functions=[])


def test_optimize_handles_empty_module():
    module = make_module()
    optimize(module)


def test_constant_fold_preserves_non_const_args():
    expr = I.PrimExpr(name="int_add",
                      args=[I.IntAtom(value=1), I.VarAtom(name="x")])
    func = I.Function(
        label="f", body=I.Block(
            bindings=[I.Binding(name="r", expr=expr)],
            result=I.VarAtom(name="r"),
        ),
    )
    module = I.Module(functions=[func])
    constant_fold(module)
    assert isinstance(func.body.bindings[0].expr, I.PrimExpr)


def test_dce_keeps_alloc_for_side_effect():
    alloc = I.AllocExpr(class_id=0x02, fields=[], tag=0)
    func = I.Function(
        label="f", body=I.Block(
            bindings=[I.Binding(name="x", expr=alloc),
                      I.Binding(name="y", expr=I.AtomExpr(atom=I.IntAtom(value=1)))],
            result=I.VarAtom(name="y"),
        ),
    )
    module = I.Module(functions=[func])
    dead_code_elim(module)
    assert any(b.name == "x" for b in func.body.bindings)


def test_mark_tail_calls_walks_into_if():
    inner_call = I.CallExpr(func=I.VarAtom(name="g"), args=[])
    inner_block = I.Block(
        bindings=[I.Binding(name="r", expr=inner_call)],
        result=I.VarAtom(name="r"),
    )
    if_expr = I.IfExpr(cond=I.BoolAtom(value=True),
                       then_block=inner_block, else_block=I.Block(result=I.IntAtom(value=0)))
    body = I.Block(
        bindings=[I.Binding(name="r", expr=if_expr)],
        result=I.VarAtom(name="r"),
    )
    func = I.Function(label="f", body=body)
    module = I.Module(functions=[func])
    mark_tail_calls(module)
    assert inner_call.is_tail
