from __future__ import annotations

import pytest

from lyra.gc import GenerationalGC
from lyra.objects.model import Box, alloc_data, alloc_tuple


def make_gc(*, young_bytes=128) -> GenerationalGC:
    gc = GenerationalGC(young_bytes_limit=young_bytes)
    return gc


def test_allocate_into_young():
    gc = make_gc()
    obj = gc.allocate(alloc_data(0, []))
    assert obj in gc.young


def test_minor_collect_promotes_after_age():
    gc = make_gc()
    box = gc.allocate(alloc_data(0, []))
    gc.root_provider = lambda: [box]
    gc.minor_collect()
    gc.minor_collect()
    assert box in gc.old


def test_minor_collect_reaps_unreachable():
    gc = make_gc()
    gc.allocate(alloc_data(0, []))
    gc.allocate(alloc_data(0, []))
    gc.root_provider = lambda: []
    gc.minor_collect()
    assert gc.young == []


def test_major_collect_clears_dead_old_objects():
    gc = make_gc()
    survivor = gc.allocate(alloc_data(0, []))
    gc.root_provider = lambda: [survivor]
    gc.minor_collect(); gc.minor_collect()
    assert survivor in gc.old
    gc.root_provider = lambda: []
    gc.major_collect()
    assert survivor not in gc.old


def test_write_barrier_records_old_to_young_pointer():
    gc = make_gc()
    parent = gc.allocate(alloc_tuple([]))
    gc.root_provider = lambda: [parent]
    gc.minor_collect(); gc.minor_collect()
    child = gc.allocate(alloc_data(0, []))
    parent.payload = [child]
    gc.write_barrier(parent, child)
    assert id(parent) in gc.remembered_set


def test_stats_count_collections():
    gc = make_gc()
    gc.root_provider = lambda: []
    gc.minor_collect()
    gc.major_collect()
    assert gc.stats.minor_collections == 1
    assert gc.stats.major_collections == 1
