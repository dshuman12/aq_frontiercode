from __future__ import annotations

from lyra.types import T_BOOL, T_INT
from lyra.types.printer import explain, render
from lyra.types.repr import TApp, TForall, TFun, TRecord, TTuple, fresh_var


def test_render_concrete_type():
    assert render(T_INT) == "Int"


def test_render_function_uses_arrow():
    fn = TFun(params=[T_INT], result=T_INT)
    assert "->" in render(fn)


def test_render_var_uses_letter():
    var = fresh_var(level=0)
    text = render(var)
    assert text.startswith("'")
    assert text[1] in "abcdefghijklmnopqrstuvwxyz"


def test_render_repeated_var_same_letter():
    var = fresh_var(level=0)
    fn = TFun(params=[var], result=var)
    text = render(fn)
    # The single bound variable should appear twice with the same letter.
    letters = [t for t in text.split() if t.startswith("'")]
    assert len(letters) >= 2 and letters[0] == letters[-1]


def test_render_tuple():
    ty = TTuple(elements=[T_INT, T_BOOL])
    assert "Int" in render(ty) and "Bool" in render(ty)


def test_render_record():
    ty = TRecord(fields={"x": T_INT})
    assert "x:" in render(ty)


def test_render_forall_lists_bound_vars():
    a = fresh_var(level=1)
    poly = TForall(bound=[a], body=TFun(params=[a], result=a))
    text = render(poly)
    assert text.startswith("forall ")


def test_explain_unbound_var_has_level():
    var = fresh_var(level=3)
    assert "@3" in explain(var)


def test_render_constructor_with_args():
    ty = TApp(name="List", args=[T_INT])
    assert render(ty).startswith("List ")
