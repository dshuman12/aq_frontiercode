from __future__ import annotations

from lyra.parser import ast as A
from lyra.parser.parser import parse_expr


def first_arm(source: str) -> A.MatchArm:
    expr = parse_expr(source)
    assert isinstance(expr, A.Match)
    return expr.arms[0]


def test_int_pattern():
    arm = first_arm("match x { 1 -> 0, _ -> 0 }")
    assert isinstance(arm.pattern, A.PInt)


def test_string_pattern():
    arm = first_arm('match x { "y" -> 0, _ -> 0 }')
    assert isinstance(arm.pattern, A.PString)


def test_bool_pattern():
    arm = first_arm("match x { true -> 0, _ -> 0 }")
    assert isinstance(arm.pattern, A.PBool)


def test_char_pattern():
    arm = first_arm("match x { 'a' -> 0, _ -> 0 }")
    assert isinstance(arm.pattern, A.PChar)


def test_tuple_pattern():
    arm = first_arm("match x { (a, b) -> 0, _ -> 0 }")
    assert isinstance(arm.pattern, A.PTuple)
    assert len(arm.pattern.elements) == 2


def test_constructor_pattern_with_args():
    arm = first_arm("match x { Cons head tail -> 0, _ -> 0 }")
    assert isinstance(arm.pattern, A.PCon)
    assert arm.pattern.name == "Cons"


def test_or_pattern_options():
    arm = first_arm("match x { 1 | 2 -> 0, _ -> 0 }")
    assert isinstance(arm.pattern, A.POr)


def test_as_pattern_alias():
    arm = first_arm("match x { (1 as y) -> 0, _ -> 0 }")
    assert isinstance(arm.pattern, A.PAs)


def test_wildcard_pattern():
    arm = first_arm("match x { _ -> 0 }")
    assert isinstance(arm.pattern, A.PWild)


def test_record_pattern_with_punned_fields():
    arm = first_arm("match x { { a, b } -> 0 }")
    assert isinstance(arm.pattern, A.PRecord)
    assert len(arm.pattern.fields) == 2
