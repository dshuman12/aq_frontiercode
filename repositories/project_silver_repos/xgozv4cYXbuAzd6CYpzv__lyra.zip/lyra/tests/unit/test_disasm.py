from __future__ import annotations

import pytest

from lyra.bytecode import (
    CompiledFunction,
    CompiledModule,
    Constant,
    CONST_INT,
    disassemble_function,
    disassemble_module,
)


def test_disassemble_function_includes_label():
    fn = CompiledFunction(label="main", arity=0, upvalue_count=0,
                           local_count=1, code=b"\x01\x00\x00")
    text = disassemble_function(fn)
    assert "main" in text
    assert "LOAD_CONST" in text


def test_disassemble_module_lists_functions():
    module = CompiledModule(
        constants=[Constant(kind=CONST_INT, value=1)],
        functions=[CompiledFunction(label="main", arity=0,
                                     upvalue_count=0, local_count=0,
                                     code=b"\xff")],
    )
    text = disassemble_module(module)
    assert "main" in text and "constants" in text


def test_disassemble_with_no_functions():
    module = CompiledModule(constants=[], functions=[])
    text = disassemble_module(module)
    assert "functions" in text


def test_disassemble_handles_unknown_opcode():
    fn = CompiledFunction(label="x", arity=0, upvalue_count=0,
                           local_count=0, code=b"\x77")
    text = disassemble_function(fn)
    assert "???" in text or "0x77" in text or "x" in text
