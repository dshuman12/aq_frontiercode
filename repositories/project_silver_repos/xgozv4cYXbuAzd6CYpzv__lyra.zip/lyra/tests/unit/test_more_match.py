from __future__ import annotations

import pytest

from lyra.errors import NonExhaustiveMatch, UselessPattern
from lyra.match import TypeOracle, check_match
from lyra.match.exhaustive import _Con
from lyra.parser import ast as A


def make_arm(pattern, body=None):
    return A.MatchArm(pattern=pattern, body=body or A.IntLit(value=0))


def test_three_constructor_type_exhaustive():
    oracle = TypeOracle()
    oracle.register("Color", [_Con("Red", 0), _Con("Green", 0), _Con("Blue", 0)])
    arms = [
        make_arm(A.PCon(name="Red")),
        make_arm(A.PCon(name="Green")),
        make_arm(A.PCon(name="Blue")),
    ]
    check_match(arms, oracle)


def test_three_constructor_type_missing_one():
    oracle = TypeOracle()
    oracle.register("Color", [_Con("Red", 0), _Con("Green", 0), _Con("Blue", 0)])
    arms = [
        make_arm(A.PCon(name="Red")),
        make_arm(A.PCon(name="Green")),
    ]
    with pytest.raises(NonExhaustiveMatch):
        check_match(arms, oracle)


def test_constructor_with_var_args_exhaustive():
    arms = [
        make_arm(A.PCon(name="Nothing")),
        make_arm(A.PCon(name="Just", args=[A.PVar(name="x")])),
    ]
    check_match(arms, TypeOracle())


def test_useless_after_exact_match():
    arms = [
        make_arm(A.PInt(value=0)),
        make_arm(A.PInt(value=0)),
        make_arm(A.PWild()),
    ]
    with pytest.raises(UselessPattern):
        check_match(arms, TypeOracle())


def test_oracle_register_overrides_existing():
    oracle = TypeOracle()
    oracle.register("Bool", [_Con("Yes", 0), _Con("No", 0)])
    arms = [
        make_arm(A.PCon(name="Yes")),
        make_arm(A.PCon(name="No")),
    ]
    check_match(arms, oracle)
