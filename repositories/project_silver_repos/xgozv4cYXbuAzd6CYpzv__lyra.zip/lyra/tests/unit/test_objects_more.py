from __future__ import annotations

from lyra.objects.model import (
    Box,
    alloc_data,
    alloc_foreign,
    alloc_list,
    alloc_string,
    alloc_tuple,
    equal,
    value_repr,
)


def test_box_age_starts_zero():
    box = Box(class_id=1, payload="x")
    assert box.age == 0


def test_box_color_starts_white():
    box = Box(class_id=1, payload="x")
    assert box.color == 0


def test_alloc_foreign_wraps_handle():
    handle = object()
    box = alloc_foreign(handle)
    assert box.payload is handle


def test_equal_distinct_classes_returns_false():
    a = alloc_string("x")
    b = alloc_data(0, [])
    assert not equal(a, b)


def test_equal_int_to_box_returns_false():
    box = alloc_string("x")
    assert not equal(7, box)


def test_value_repr_data():
    box = alloc_data(2, [1, 2])
    assert "#2" in value_repr(box)


def test_value_repr_int_zero():
    assert value_repr(0) == "0"


def test_alloc_tuple_keeps_order():
    box = alloc_tuple([3, 2, 1])
    assert box.payload == [3, 2, 1]


def test_alloc_list_distinct_payloads():
    a = alloc_list([1, 2])
    b = alloc_list([1, 2])
    assert a is not b
    assert equal(a, b)
