from __future__ import annotations

import pytest

from lyra.errors import UndefinedName
from lyra.parser import parse_module
from lyra.resolve import resolve_module


def test_resolve_simple_let():
    module = parse_module("let main = 1")
    resolve_module(module)


def test_resolve_with_lambda_binds_param():
    module = parse_module("let main = (fn x -> x) 1")
    resolve_module(module)


def test_undefined_name_raises():
    module = parse_module("let main = unknown")
    with pytest.raises(UndefinedName):
        resolve_module(module)


def test_let_in_resolves_with_scope():
    module = parse_module("let main = let x = 1 in x + 2")
    resolve_module(module)


def test_match_arm_binds_pattern_vars():
    module = parse_module(
        "type T = A | B Int\n"
        "let main = match A {\n"
        "    A   -> 0\n"
        "    B n -> n\n"
        "}"
    )
    resolve_module(module)


def test_top_level_constructors_resolve():
    module = parse_module(
        "type Bool = T | F\n"
        "let main = T"
    )
    resolve_module(module)


def test_recursive_let_self_reference():
    module = parse_module(
        "let main = let rec f = fn n -> if n == 0 then 0 else f (n - 1) in f 5"
    )
    resolve_module(module)
