from __future__ import annotations

from lyra.errors import LexerError, NonExhaustiveMatch, ParseError, Position
from lyra.utils.diagnostics import format_chain, format_error


def test_diagnostic_str_returns_rendered():
    diag = format_error(LexerError("oops"))
    assert str(diag) == diag.rendered


def test_chain_with_no_errors_returns_empty():
    assert format_chain([]) == ""


def test_format_error_preserves_position_object():
    pos = Position(file="x", line=2, column=3, offset=10)
    diag = format_error(ParseError("bad", position=pos))
    assert "x:2:3" in diag.rendered


def test_format_error_with_two_context_keys():
    err = ParseError("e", context={"a": 1, "b": 2})
    text = format_error(err).rendered
    assert "a" in text and "b" in text


def test_non_exhaustive_match_diagnostic():
    err = NonExhaustiveMatch("missing")
    text = format_error(err).rendered
    assert "LY3001" in text
