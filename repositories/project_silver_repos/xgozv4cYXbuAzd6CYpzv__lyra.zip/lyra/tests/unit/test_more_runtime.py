from __future__ import annotations

import pytest

from lyra.runtime import compile_source


def test_compile_with_two_top_level_lambdas():
    result = compile_source(
        "let inc = fn x -> x + 1\n"
        "let dec = fn x -> x - 1\n"
        "let main = inc 1"
    )
    labels = {fn.label for fn in result.module.functions}
    # Each top-level lambda becomes its own labelled function.
    assert any(label.startswith("inc") for label in labels)
    assert any(label.startswith("dec") for label in labels)


def test_compile_preserves_export_table():
    result = compile_source("let main = 1")
    assert any(name == "main" or name == "@module_init" for name, _ in result.module.exports)


def test_compile_handles_let_chain():
    result = compile_source(
        "let a = 1\n"
        "let b = a + 1\n"
        "let c = b + 1\n"
        "let main = c"
    )
    assert "a" in result.types and "c" in result.types


def test_compile_module_with_only_constructor_use():
    result = compile_source(
        "type T = A | B\n"
        "let main = A"
    )
    assert "main" in result.types


def test_compile_simple_function_pattern():
    result = compile_source(
        "type Maybe a = Nothing | Just a\n"
        "let unwrap = fn m -> match m { Nothing -> 0, Just x -> x }\n"
        "let main = unwrap (Just 7)"
    )
    assert "unwrap" in result.types
