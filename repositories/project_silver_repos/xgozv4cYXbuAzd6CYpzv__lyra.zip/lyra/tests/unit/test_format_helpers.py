from __future__ import annotations

from lyra.utils.formatting import (
    humanise_bytes,
    humanise_count,
    indent_block,
    two_column_layout,
)


def test_humanise_bytes_under_kib():
    assert humanise_bytes(0) == "0.0 B"
    assert humanise_bytes(700).endswith(" B")


def test_humanise_bytes_kib():
    assert "KiB" in humanise_bytes(2048)


def test_humanise_bytes_gib():
    assert "GiB" in humanise_bytes(2 * 1024 ** 3)


def test_humanise_bytes_tib():
    assert "TiB" in humanise_bytes(2 * 1024 ** 4)


def test_humanise_count_under_thousand():
    assert humanise_count(999) == "999"


def test_humanise_count_in_thousands():
    assert "k" in humanise_count(1500)


def test_humanise_count_in_millions():
    assert "M" in humanise_count(2_500_000)


def test_two_column_empty():
    assert two_column_layout([]) == ""


def test_two_column_with_separator():
    text = two_column_layout([("a", "1"), ("bb", "2")], separator=" | ")
    assert "a  | 1" in text or "a | 1" in text


def test_indent_block_default_two():
    text = indent_block("a\nb")
    assert text == "  a\n  b"


def test_indent_block_zero_is_passthrough():
    text = indent_block("hi", by=0)
    assert text == "hi"
