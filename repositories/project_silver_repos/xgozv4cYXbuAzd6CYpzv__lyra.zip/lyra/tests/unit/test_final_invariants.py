from __future__ import annotations

from lyra import __version__
from lyra.bytecode import disassemble_module
from lyra.bytecode.format import CompiledModule
from lyra.errors import LyraError, ParseError
from lyra.gc import GenerationalGC
from lyra.objects.model import alloc_data
from lyra.parser import parse_module
from lyra.resolve import resolve_module


def test_version_uses_dot_separator():
    assert "." in __version__


def test_lyra_error_subclass_chain():
    assert issubclass(ParseError, LyraError)


def test_disassemble_empty_module_does_not_crash():
    text = disassemble_module(CompiledModule())
    assert isinstance(text, str)


def test_resolve_handles_no_decls():
    module = parse_module("")
    resolve_module(module)


def test_gc_minor_then_major_no_crash():
    gc = GenerationalGC()
    gc.allocate(alloc_data(0, []))
    gc.root_provider = lambda: []
    gc.minor_collect()
    gc.major_collect()


def test_gc_default_promotion_age_within_bounds():
    gc = GenerationalGC()
    assert gc.promotion_age >= 1


def test_compiled_module_default_repr_does_not_throw():
    repr(CompiledModule())
