from __future__ import annotations

import pytest

from lyra.errors import UnificationError
from lyra.parser import parse_expr, parse_module
from lyra.types import T_BOOL, T_INT, T_STRING, infer_expression, infer_module


def test_infer_string_concat():
    ty = infer_expression(parse_expr('"a" ++ "b"'))
    assert ty is T_STRING


def test_infer_logical_and():
    ty = infer_expression(parse_expr("true && false"))
    assert ty is T_BOOL


def test_infer_unary_negation():
    ty = infer_expression(parse_expr("-5"))
    assert ty is T_INT


def test_infer_function_application():
    module = parse_module(
        "let inc = fn x -> x + 1\n"
        "let result = inc 41"
    )
    types = infer_module(module)
    assert "result" in types


def test_infer_polymorphic_pair():
    module = parse_module(
        "let pair = fn x y -> (x, y)\n"
        "let a = pair 1 2\n"
        "let b = pair true false"
    )
    types = infer_module(module)
    assert "a" in types and "b" in types


def test_infer_type_mismatch_in_args():
    with pytest.raises(UnificationError):
        infer_expression(parse_expr('1 + "two"'))


def test_infer_record_field_access():
    ty = infer_expression(parse_expr("{ x = 1, y = 2 }.x"))
    assert ty is T_INT


def test_infer_tuple_returns_tuple_type():
    ty = infer_expression(parse_expr("(1, true)"))
    assert ty is not None


def test_infer_let_in_inner_scope():
    ty = infer_expression(parse_expr(
        "let x = 1 in let y = 2 in x + y"
    ))
    assert ty is T_INT


def test_infer_match_arm_unification():
    module = parse_module(
        "type T = A | B\n"
        "let f = fn t -> match t {\n"
        "    A -> 0\n"
        "    B -> 1\n"
        "}"
    )
    types = infer_module(module)
    assert "f" in types
