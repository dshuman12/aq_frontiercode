from __future__ import annotations

from lyra.errors import LexerError, ParseError, Position
from lyra.utils.diagnostics import format_chain, format_error


def test_chain_separator_between_errors():
    errs = [LexerError("a"), ParseError("b")]
    text = format_chain(errs)
    assert "\n\n" in text


def test_chain_includes_each_code():
    errs = [LexerError("a"), ParseError("b")]
    text = format_chain(errs)
    assert "LY1001" in text and "LY1100" in text


def test_chain_with_source_emits_caret_for_first_only_when_positioned():
    pos = Position(file="t", line=1, column=2)
    errs = [ParseError("x", position=pos), ParseError("y")]
    text = format_chain(errs, source="abc")
    # First diagnostic includes a caret line; second one does not.
    assert "^" in text


def test_format_error_returns_diagnostic_with_code_attribute():
    diag = format_error(LexerError("oops"))
    assert diag.code == "LY1001"


def test_format_error_message_attribute():
    diag = format_error(ParseError("bad"))
    assert "bad" in diag.message
