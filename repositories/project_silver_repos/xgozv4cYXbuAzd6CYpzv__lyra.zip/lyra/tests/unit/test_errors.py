from __future__ import annotations

import pytest

from lyra.errors import (
    CircularImport,
    LexerError,
    LyraError,
    ModuleNotFound,
    NonExhaustiveMatch,
    OccursCheckError,
    ParseError,
    Position,
    UndefinedName,
)


def test_position_render():
    p = Position(file="x.lyra", line=2, column=3)
    assert p.render() == "x.lyra:2:3"


def test_lyra_error_carries_position():
    err = LyraError("boom", position=Position(file="a", line=1, column=2))
    assert "a:1:2" in str(err)


def test_lexer_error_default_code():
    assert LexerError("oops").code == "LY1001"


def test_parse_error_default_code():
    assert ParseError("oops").code == "LY1100"


def test_undefined_name_inherits_resolve():
    err = UndefinedName("missing")
    assert err.code == "LY1201"


def test_occurs_check_inherits_type_error():
    err = OccursCheckError("recursion")
    assert err.code == "LY2002"


def test_non_exhaustive_inherits_pattern_error():
    err = NonExhaustiveMatch("missing case")
    assert err.code == "LY3001"


def test_module_not_found_inherits_module():
    err = ModuleNotFound("Std.X")
    assert err.code == "LY7001"


def test_circular_import_inherits_module():
    err = CircularImport("A -> B -> A")
    assert err.code == "LY7002"
