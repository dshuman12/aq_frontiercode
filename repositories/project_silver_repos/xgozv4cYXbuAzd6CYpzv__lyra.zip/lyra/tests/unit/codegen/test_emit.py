from __future__ import annotations

import pytest

from lyra.bytecode import decode, encode
from lyra.codegen import emit_module
from lyra.ir import nodes as I


def make_simple_module() -> I.Module:
    body = I.Block(
        bindings=[I.Binding(
            name="r", expr=I.AtomExpr(atom=I.IntAtom(value=42)),
        )],
        result=I.VarAtom(name="r"),
    )
    func = I.Function(label="main", params=[], body=body, is_top_level=True)
    return I.Module(functions=[func])


def test_emit_produces_function():
    module = emit_module(make_simple_module())
    assert any(fn.label == "main" for fn in module.functions)


def test_emit_then_decode_round_trip():
    module = emit_module(make_simple_module())
    blob = encode(module)
    decoded = decode(blob)
    assert decoded.functions[0].label == module.functions[0].label


def test_constant_pool_dedup():
    body = I.Block(
        bindings=[
            I.Binding(name="a", expr=I.AtomExpr(atom=I.IntAtom(value=7))),
            I.Binding(name="b", expr=I.AtomExpr(atom=I.IntAtom(value=7))),
        ],
        result=I.VarAtom(name="b"),
    )
    func = I.Function(label="main", params=[], body=body)
    module = emit_module(I.Module(functions=[func]))
    sevens = [c for c in module.constants if c.value == 7]
    assert len(sevens) == 1
