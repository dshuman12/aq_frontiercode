from __future__ import annotations

import pytest

from lyra.bytecode import (
    CONST_INT,
    CONST_STRING,
    CompiledFunction,
    CompiledModule,
    Constant,
    decode,
    encode,
)


def test_module_encode_decode_round_trip():
    module = CompiledModule(
        constants=[Constant(kind=CONST_INT, value=42)],
        functions=[CompiledFunction(label="main", arity=0,
                                     upvalue_count=0, local_count=0,
                                     code=b"\xff")],
        imports=["Std"],
        exports=[("main", 0)],
    )
    decoded = decode(encode(module))
    assert decoded.constants[0].value == 42
    assert decoded.functions[0].label == "main"
    assert decoded.imports == ["Std"]


def test_string_constant_round_trip():
    module = CompiledModule(
        constants=[Constant(kind=CONST_STRING, value="hello")],
    )
    decoded = decode(encode(module))
    assert decoded.constants[0].value == "hello"


def test_decode_rejects_bad_magic():
    blob = b"NOTAMAGIC" + b"\x00" * 32
    with pytest.raises(Exception):
        decode(blob)


def test_decode_rejects_unknown_version():
    module = CompiledModule(constants=[], functions=[])
    blob = bytearray(encode(module))
    blob[8] = 0xFF  # corrupt the version field
    with pytest.raises(Exception):
        decode(bytes(blob))
