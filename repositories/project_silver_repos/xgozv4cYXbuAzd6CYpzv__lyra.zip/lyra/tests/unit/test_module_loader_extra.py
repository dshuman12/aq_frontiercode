from __future__ import annotations

from pathlib import Path

import pytest

from lyra.modules import ModuleLoader


def write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)


def test_topo_order_diamond(tmp_path: Path):
    write(tmp_path / "Bottom.lyra", "let b = 1")
    write(tmp_path / "Left.lyra", "import Bottom\nlet l = 1")
    write(tmp_path / "Right.lyra", "import Bottom\nlet r = 1")
    write(tmp_path / "Top.lyra", "import Left\nimport Right\nlet t = 1")
    loader = ModuleLoader(search_paths=[tmp_path])
    loader.load("Top")
    order = [m.name for m in loader.topo_order()]
    assert order.index("Bottom") < order.index("Left")
    assert order.index("Bottom") < order.index("Right")
    assert order.index("Left") < order.index("Top")
    assert order.index("Right") < order.index("Top")


def test_load_caches_repeated(tmp_path: Path):
    write(tmp_path / "M.lyra", "let m = 1")
    loader = ModuleLoader(search_paths=[tmp_path])
    a = loader.load("M")
    b = loader.load("M")
    assert a is b


def test_search_path_order(tmp_path: Path):
    base_a = tmp_path / "a"
    base_b = tmp_path / "b"
    write(base_a / "M.lyra", "let m = 1")
    write(base_b / "M.lyra", "let m = 2")
    loader = ModuleLoader(search_paths=[base_b, base_a])
    found = loader.load("M")
    assert str(base_b) in str(found.path)
