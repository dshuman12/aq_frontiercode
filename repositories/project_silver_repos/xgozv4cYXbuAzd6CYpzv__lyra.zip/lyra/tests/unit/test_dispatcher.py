from __future__ import annotations

import pytest

from lyra.bytecode import CompiledFunction, CompiledModule, CONST_INT, Constant
from lyra.constants import (
    OP_DUP,
    OP_HALT,
    OP_JUMP,
    OP_LOAD_CONST,
    OP_POP,
    OP_RETURN,
)
from lyra.errors import BytecodeError
from lyra.vm import VM


def make_vm(code: bytes, *, constants: list[Constant] | None = None) -> VM:
    return VM(module=CompiledModule(
        constants=constants or [],
        functions=[CompiledFunction(label="main", arity=0,
                                     upvalue_count=0, local_count=0,
                                     code=code)],
    ))


def test_pop_drops_top():
    code = (
        bytes([OP_LOAD_CONST]) + (0).to_bytes(2, "little") +
        bytes([OP_LOAD_CONST]) + (1).to_bytes(2, "little") +
        bytes([OP_POP, OP_RETURN])
    )
    vm = make_vm(code, constants=[
        Constant(kind=CONST_INT, value=1),
        Constant(kind=CONST_INT, value=2),
    ])
    assert vm.run() == 1


def test_dup_duplicates_top():
    code = (
        bytes([OP_LOAD_CONST]) + (0).to_bytes(2, "little") +
        bytes([OP_DUP]) +
        bytes([OP_POP, OP_RETURN])
    )
    vm = make_vm(code, constants=[Constant(kind=CONST_INT, value=42)])
    assert vm.run() == 42


def test_jump_skips_instructions():
    code = (
        bytes([OP_LOAD_CONST]) + (0).to_bytes(2, "little") +
        bytes([OP_JUMP]) + (10).to_bytes(2, "little") +
        bytes([OP_LOAD_CONST]) + (1).to_bytes(2, "little") +
        bytes([OP_RETURN])
    )
    vm = make_vm(code, constants=[
        Constant(kind=CONST_INT, value=7),
        Constant(kind=CONST_INT, value=99),
    ])
    assert vm.run() == 7


def test_unknown_opcode_raises():
    with pytest.raises(BytecodeError):
        make_vm(bytes([0x77])).run()
