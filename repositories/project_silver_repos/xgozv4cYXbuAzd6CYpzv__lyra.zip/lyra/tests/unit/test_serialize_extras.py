from __future__ import annotations

from lyra.bytecode.format import (
    CONST_FLOAT,
    CONST_STRING,
    CompiledFunction,
    CompiledModule,
    Constant,
    decode,
    encode,
)


def test_unicode_string_round_trip():
    module = CompiledModule(constants=[Constant(kind=CONST_STRING, value="héllo")])
    decoded = decode(encode(module))
    assert decoded.constants[0].value == "héllo"


def test_negative_float_round_trip():
    module = CompiledModule(constants=[Constant(kind=CONST_FLOAT, value=-1.5)])
    decoded = decode(encode(module))
    assert decoded.constants[0].value == -1.5


def test_large_function_code_round_trip():
    code = b"\xff" * 1024
    module = CompiledModule(functions=[CompiledFunction(
        label="large", arity=0, upvalue_count=0, local_count=0, code=code,
    )])
    decoded = decode(encode(module))
    assert decoded.functions[0].code == code


def test_empty_module_round_trip():
    module = CompiledModule()
    decoded = decode(encode(module))
    assert decoded.constants == [] and decoded.functions == []


def test_function_with_long_label():
    label = "x" * 200
    module = CompiledModule(functions=[CompiledFunction(
        label=label, arity=0, upvalue_count=0, local_count=0, code=b"\xff",
    )])
    decoded = decode(encode(module))
    assert decoded.functions[0].label == label


def test_imports_with_dotted_names():
    module = CompiledModule(imports=["A.B.C", "Std.List", "Foo"])
    decoded = decode(encode(module))
    assert decoded.imports == module.imports
