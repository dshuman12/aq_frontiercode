from __future__ import annotations

import pytest

from lyra.bytecode import CompiledFunction, CompiledModule
from lyra.debugger import Debugger
from lyra.vm import VM


def make_vm() -> VM:
    fn = CompiledFunction(label="main", arity=0, upvalue_count=0,
                           local_count=1, code=b"\xff")  # HALT
    return VM(module=CompiledModule(functions=[fn]))


def test_add_breakpoint_records_offset():
    debugger = Debugger(vm=make_vm())
    bp = debugger.add_breakpoint("main", 0)
    assert bp.function_label == "main"
    assert bp.offset == 0


def test_remove_breakpoint():
    debugger = Debugger(vm=make_vm())
    bp = debugger.add_breakpoint("main", 0)
    debugger.remove_breakpoint(bp)
    assert bp not in debugger.breakpoints


def test_list_breakpoints_returns_copy():
    debugger = Debugger(vm=make_vm())
    debugger.add_breakpoint("main", 0)
    snapshot = debugger.list_breakpoints()
    debugger.add_breakpoint("main", 5)
    assert len(snapshot) == 1
    assert len(debugger.list_breakpoints()) == 2


def test_step_mode_toggle():
    debugger = Debugger(vm=make_vm())
    debugger.step_over()
    assert debugger.step_mode
