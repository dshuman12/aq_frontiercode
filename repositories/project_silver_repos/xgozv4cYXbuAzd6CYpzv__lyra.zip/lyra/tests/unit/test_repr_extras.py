from __future__ import annotations

from lyra.types.repr import (
    T_BOOL,
    T_INT,
    TApp,
    TFun,
    TRecord,
    TTuple,
    fresh_var,
    walk,
)


def test_function_repr_includes_arrow():
    fn = TFun(params=[T_INT], result=T_BOOL)
    assert "->" in repr(fn)


def test_app_repr_no_args_no_parens():
    ty = TApp(name="Maybe")
    assert repr(ty) == "Maybe"


def test_tuple_repr_uses_commas():
    ty = TTuple(elements=[T_INT, T_BOOL])
    text = repr(ty)
    assert "," in text


def test_record_repr_braces():
    ty = TRecord(fields={"x": T_INT})
    text = repr(ty)
    assert text.startswith("{") and text.endswith("}")


def test_walk_includes_tuple_elements():
    ty = TTuple(elements=[T_INT, T_BOOL])
    nodes = list(walk(ty))
    assert T_INT in nodes and T_BOOL in nodes


def test_walk_includes_record_values():
    ty = TRecord(fields={"a": T_INT})
    nodes = list(walk(ty))
    assert T_INT in nodes


def test_var_repr_when_forwarded():
    var = fresh_var(level=0)
    var.forwarded = T_INT
    assert "Int" in repr(var)
