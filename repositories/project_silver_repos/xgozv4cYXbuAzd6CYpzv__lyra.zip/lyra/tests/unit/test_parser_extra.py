from __future__ import annotations

import pytest

from lyra.errors import ParseError
from lyra.parser import ast as A
from lyra.parser.parser import parse_expr, parse_module


def test_function_sugar_multiple_params():
    module = parse_module("let add x y z = x + y + z")
    binding = module.declarations[0].bindings[0]
    lam = binding.expr
    assert isinstance(lam, A.Lambda)
    assert len(lam.params) == 3


def test_let_rec_chain():
    module = parse_module(
        "let rec a = fn x -> b x and b = fn y -> a y"
    )
    decl = module.declarations[0]
    assert isinstance(decl, A.LetDecl)
    assert len(decl.bindings) == 2


def test_or_pattern_in_match():
    expr = parse_expr("match x { 1 | 2 | 3 -> 0, _ -> 1 }")
    assert isinstance(expr.arms[0].pattern, A.POr)


def test_as_pattern_binds_alias():
    expr = parse_expr("match x { (1 as y) -> y, _ -> 0 }")
    arm = expr.arms[0]
    assert isinstance(arm.pattern, A.PAs)


def test_record_field_punning_pattern():
    expr = parse_expr("match p { { x } -> x, _ -> 0 }")
    arm = expr.arms[0]
    assert isinstance(arm.pattern, A.PRecord)


def test_application_higher_order():
    expr = parse_expr("(fn f -> f 1) (fn x -> x + 1)")
    assert isinstance(expr, A.App)


def test_chained_field_access():
    expr = parse_expr("a.b.c")
    assert isinstance(expr, A.FieldAccess)
    assert isinstance(expr.target, A.FieldAccess)


def test_unit_pattern_recognised():
    expr = parse_expr("match x { () -> 0 }")
    arm = expr.arms[0]
    assert isinstance(arm.pattern, A.PCon) and arm.pattern.name == "Unit"


def test_module_export_decl():
    module = parse_module("export a, b, c")
    decl = module.declarations[0]
    assert isinstance(decl, A.ExportDecl)
    assert list(decl.items) == ["a", "b", "c"]


def test_extern_decl_with_primitive():
    module = parse_module('extern foo : Int -> Int = "int_neg"')
    decl = module.declarations[0]
    assert isinstance(decl, A.ExternDecl)
    assert decl.primitive == "int_neg"


def test_invalid_keyword_in_pattern():
    with pytest.raises(ParseError):
        parse_expr("match x { let -> 0 }")
