from __future__ import annotations

from lyra.bytecode.format import (
    CONST_BOOL,
    CONST_INT,
    CONST_STRING,
    CompiledModule,
    Constant,
    decode,
    encode,
)
from lyra.codegen.emit import Emitter


def test_emitter_dedupes_identical_int_constants():
    emitter = Emitter()
    a = emitter._add_constant(Constant(kind=CONST_INT, value=7))
    b = emitter._add_constant(Constant(kind=CONST_INT, value=7))
    assert a == b


def test_emitter_distinct_indexes_for_different_values():
    emitter = Emitter()
    a = emitter._add_constant(Constant(kind=CONST_INT, value=7))
    b = emitter._add_constant(Constant(kind=CONST_INT, value=8))
    assert a != b


def test_emitter_distinct_indexes_for_different_kinds():
    emitter = Emitter()
    a = emitter._add_constant(Constant(kind=CONST_INT, value=1))
    b = emitter._add_constant(Constant(kind=CONST_BOOL, value=True))
    assert a != b


def test_string_dedupe():
    emitter = Emitter()
    a = emitter._add_constant(Constant(kind=CONST_STRING, value="hi"))
    b = emitter._add_constant(Constant(kind=CONST_STRING, value="hi"))
    assert a == b


def test_round_trip_with_dedupe():
    module = CompiledModule(
        constants=[
            Constant(kind=CONST_INT, value=1),
            Constant(kind=CONST_STRING, value="hi"),
        ],
    )
    decoded = decode(encode(module))
    assert len(decoded.constants) == 2
