from __future__ import annotations

import pytest

from lyra import __version__
from lyra.constants import (
    BYTECODE_MAGIC,
    OP_HALT,
    OP_LOAD_CONST,
    OP_RETURN,
)


def test_version_is_string():
    assert isinstance(__version__, str)


def test_bytecode_magic_eight_bytes():
    assert len(BYTECODE_MAGIC) == 8


def test_opcodes_distinct():
    assert OP_LOAD_CONST != OP_RETURN != OP_HALT


def test_imports_resolve():
    # The act of importing each submodule is the check.
    import lyra.bytecode  # noqa
    import lyra.codegen  # noqa
    import lyra.errors  # noqa
    import lyra.gc  # noqa
    import lyra.ir  # noqa
    import lyra.lexer  # noqa
    import lyra.lower  # noqa
    import lyra.match  # noqa
    import lyra.modules  # noqa
    import lyra.objects  # noqa
    import lyra.optimize  # noqa
    import lyra.parser  # noqa
    import lyra.resolve  # noqa
    import lyra.runtime  # noqa
    import lyra.stdlib  # noqa
    import lyra.types  # noqa
    import lyra.utils  # noqa
    import lyra.vm  # noqa
