from __future__ import annotations

from pathlib import Path

import pytest

from lyra.bytecode import decode, encode
from lyra.runtime import compile_file, compile_source, write_compiled


def test_compile_module_with_type_decl():
    result = compile_source(
        "type Maybe a = Nothing | Just a\n"
        "let main = Just 7"
    )
    labels = [fn.label for fn in result.module.functions]
    assert "@module_init" in labels or any(label.endswith("_init") for label in labels)


def test_write_then_read_round_trip(tmp_path: Path):
    result = compile_source("let main = 5 + 6")
    path = tmp_path / "m.lyrac"
    write_compiled(path, result.module)
    blob = path.read_bytes()
    decoded = decode(blob)
    assert decoded.functions


def test_encode_round_trip_in_memory():
    result = compile_source("let main = true")
    blob = encode(result.module)
    decoded = decode(blob)
    assert len(decoded.constants) == len(result.module.constants)


def test_compile_file_reads_path(tmp_path: Path):
    src = tmp_path / "m.lyra"
    src.write_text("let main = 1")
    result = compile_file(src)
    assert result.module.functions


def test_pattern_decl_round_trips_via_disk(tmp_path: Path):
    src = tmp_path / "m.lyra"
    src.write_text(
        "type Color = Red | Green | Blue\n"
        "let main = Red"
    )
    result = compile_file(src)
    out = tmp_path / "m.lyrac"
    write_compiled(out, result.module)
    decoded = decode(out.read_bytes())
    assert decoded.functions
