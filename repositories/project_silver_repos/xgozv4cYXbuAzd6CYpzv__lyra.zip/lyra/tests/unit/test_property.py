from __future__ import annotations

from hypothesis import given, settings, strategies as st

from lyra.bytecode import decode, encode
from lyra.bytecode.format import (
    CONST_BOOL,
    CONST_FLOAT,
    CONST_INT,
    CONST_STRING,
    CompiledFunction,
    CompiledModule,
    Constant,
)
from lyra.lexer import tokenize
from lyra.objects.model import alloc_string, equal, tag_int, untag_int


@given(value=st.integers(min_value=-(2**62), max_value=(2**62) - 1))
@settings(deadline=None)
def test_tag_int_round_trip(value: int):
    assert untag_int(tag_int(value)) == value


@given(text=st.text(min_size=0, max_size=200))
@settings(deadline=None)
def test_string_equality_round_trip(text: str):
    assert equal(alloc_string(text), alloc_string(text))


@given(values=st.lists(st.integers(min_value=-(2**31), max_value=(2**31) - 1),
                       min_size=1, max_size=20))
@settings(deadline=None)
def test_module_constants_roundtrip(values: list[int]):
    module = CompiledModule(
        constants=[Constant(kind=CONST_INT, value=v) for v in values],
        functions=[CompiledFunction(label="main", arity=0,
                                     upvalue_count=0, local_count=0,
                                     code=b"\xff")],
    )
    decoded = decode(encode(module))
    assert [c.value for c in decoded.constants] == values


@given(value=st.floats(allow_nan=False, allow_infinity=False, width=64))
@settings(deadline=None)
def test_float_constant_round_trip(value: float):
    module = CompiledModule(constants=[Constant(kind=CONST_FLOAT, value=value)])
    decoded = decode(encode(module))
    assert decoded.constants[0].value == value


@given(value=st.booleans())
@settings(deadline=None)
def test_bool_constant_round_trip(value: bool):
    module = CompiledModule(constants=[Constant(kind=CONST_BOOL, value=value)])
    decoded = decode(encode(module))
    assert decoded.constants[0].value is value


@given(text=st.text(alphabet="abcdefghijklmno", min_size=1, max_size=20))
@settings(deadline=None)
def test_lexer_handles_simple_idents(text: str):
    tokens = tokenize(text)
    assert tokens[0].text == text
