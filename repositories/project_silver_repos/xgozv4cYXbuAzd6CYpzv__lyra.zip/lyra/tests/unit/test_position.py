from __future__ import annotations

from lyra.lexer import tokenize
from lyra.parser.parser import parse_expr


def test_lexer_tokens_carry_position():
    tokens = tokenize("let x = 1\nlet y = 2", file="demo.lyra")
    line2 = next(t for t in tokens if t.position.line == 2)
    assert line2.position.file == "demo.lyra"


def test_parsed_expression_inherits_position():
    expr = parse_expr("1 + 2")
    assert expr.position.line == 1
    assert expr.position.column >= 1


def test_position_render_format():
    from lyra.errors import Position

    pos = Position(file="x", line=5, column=12)
    assert pos.render() == "x:5:12"


def test_position_default_is_unknown_one_one():
    from lyra.errors import Position

    pos = Position()
    assert pos.line == 1 and pos.column == 1
