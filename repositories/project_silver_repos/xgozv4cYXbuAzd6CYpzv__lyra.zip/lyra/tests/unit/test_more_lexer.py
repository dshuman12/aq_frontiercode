from __future__ import annotations

import pytest

from lyra.errors import LexerError
from lyra.lexer import Lexer, TokenKind, tokenize


def test_lexer_constructor_explicit_file():
    lex = Lexer("x", file="m.lyra")
    tokens = list(lex)
    assert tokens[0].position.file == "m.lyra"


def test_long_keyword_literal():
    tokens = tokenize("annotation")  # not a keyword; should be lident
    assert tokens[0].kind == TokenKind.LIDENT


def test_at_token_recognised():
    tokens = tokenize("@x")
    assert tokens[0].kind == TokenKind.AT


def test_ampersand_token_recognised():
    tokens = tokenize("&x")
    assert tokens[0].kind == TokenKind.AMPERSAND


def test_backtick_token_recognised():
    tokens = tokenize("`x")
    assert tokens[0].kind == TokenKind.BACKTICK


def test_double_colon_recognised():
    tokens = tokenize("::")
    assert tokens[0].kind == TokenKind.DOUBLE_COLON


def test_arrow_recognised():
    tokens = tokenize("->")
    assert tokens[0].kind == TokenKind.ARROW


def test_fat_arrow_recognised():
    tokens = tokenize("=>")
    assert tokens[0].kind == TokenKind.FAT_ARROW


def test_lexer_records_offset_after_strings():
    tokens = tokenize('"hello" foo')
    assert tokens[1].text == "foo"


def test_unknown_character_raises():
    with pytest.raises(LexerError):
        tokenize("?")
