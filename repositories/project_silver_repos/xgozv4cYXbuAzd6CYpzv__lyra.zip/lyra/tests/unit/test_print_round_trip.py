from __future__ import annotations

import pytest

from lyra.parser.parser import parse_expr, parse_module
from lyra.parser.printer import render_decl, render_expr, render_module


@pytest.mark.parametrize("source", [
    "1",
    "1 + 2 * 3",
    "let x = 1 in x",
    "fn x -> x",
    "fn x y -> x + y",
    "if true then 1 else 0",
    "match x { 0 -> 1, _ -> 2 }",
    "(1, 2, 3)",
    "{ x = 1, y = 2 }",
    "true && false",
    "\"a\" ++ \"b\"",
    "-5",
    "!true",
])
def test_expr_renders_non_empty(source: str):
    text = render_expr(parse_expr(source))
    assert text


@pytest.mark.parametrize("source", [
    "let x = 1",
    "let id = fn x -> x",
    "let rec count = fn n -> if n == 0 then 0 else count (n - 1)",
    "type Maybe a = Nothing | Just a",
    "type Pair a b = (a, b)",
    "import Std.List",
    "import Std.List as L",
    "import Std.Map { lookup, insert }",
    "export a, b",
])
def test_decl_renders_non_empty(source: str):
    module = parse_module(source)
    text = render_decl(module.declarations[0])
    assert text


def test_render_module_round_trip_empty():
    text = render_module(parse_module(""))
    assert text == "\n"


def test_render_module_with_explicit_name():
    text = render_module(parse_module("module M\nlet x = 1"))
    assert text.startswith("module M")
