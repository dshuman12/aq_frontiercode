# Lyra language tour

This is the user-facing tour. If you have ever used OCaml, F#, or
Haskell the syntax should feel familiar; if you're new to ML-family
languages, the things to know are:

- Functions are first class -- you can pass them around like any
  other value.
- Types are inferred. Annotations are allowed at let-bindings; you
  rarely need them.
- Pattern matching is exhaustive: leaving out a case is a compile-time
  error, not a runtime mystery.
- Data types are sums of products: ``type Maybe a = Nothing | Just a``.

## Hello, world

```ocaml
let main = "hello, world"
```

`lyra run hello.lyra` prints the string and exits.

## Functions

```ocaml
let add = fn x y -> x + y
let inc = add 1            // partial application
let two = inc 1
```

The function-sugar form ``let add x y = x + y`` is shorthand for
the lambda above.

## Recursion

```ocaml
let rec fact = fn n ->
    if n <= 1 then 1
    else n * fact (n - 1)
```

`let rec` introduces a recursive binding. Without it, the right-hand
side cannot reference the name being bound.

## Algebraic data types

```ocaml
type List a = Nil | Cons a (List a)

let rec length = fn lst -> match lst {
    Nil       -> 0
    Cons _ xs -> 1 + length xs
}
```

`Nil` and `Cons` are the constructors of `List`. The pattern match
binds the head and tail of a non-empty list and recurses on the tail.

## Records

```ocaml
let alice = { name = "alice", age = 30 }
let same_name = alice.name == "alice"
```

Records are nominal-by-shape: two records with the same fields and
matching types are interchangeable.

## Tuples

```ocaml
let point = (1, 2)
let (x, y) = point
```

Tuples are anonymous products. Destructuring works in `let` bindings
and in patterns.

## Modules + imports

```ocaml
module MyApp

import Std.List
import Std.Map { lookup, insert }

let main = MyApp.run ()
```

A file with a `module` header at the top exports everything declared
under it; an `export` declaration narrows that to a list. Imports
either expose the whole module under a qualified name or pull
specific names into scope.

## Built-in primitives

The standard library exposes a small number of primitives via the
`OP_PRIM` opcode:

- `print` / `println` -- write a value to stdout.
- `read_line` -- read a line from stdin (returns a String).
- `panic` -- abort with an error message.
- `assert` -- fail with `assertion failed` if the argument is false.

Anything else (`map`, `filter`, sorting, ...) lives in the `Std.*`
modules implemented in Lyra itself.

## Where to next

- [Type system](types.md)
- [Compiler internals](compiler.md)
- [VM and GC](vm.md), [gc.md](gc.md)
