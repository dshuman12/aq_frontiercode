# Changelog

## 0.1.0 (alpha)

Initial release. Surface area:

- Lexer + parser for an ML-flavoured surface syntax.
- Hindley-Milner type inference with level-based generalization
  and let-polymorphism.
- Algebraic data types with exhaustive pattern matching.
- A-normal-form intermediate representation.
- Closure conversion + lambda lifting.
- Optimizer: constant folding, dead-code elimination, tail-call
  marking.
- Bytecode emitter + disassembler.
- Stack-based VM with tail-call elimination.
- Generational copying GC with write barrier and remembered set.
- Tagged-pointer object model.
- Standard-library primitives: arithmetic, comparisons, strings,
  lists, IO.
- Module loader with dependency cycle detection.
- CLI: build / run / repl / check / fmt / disasm.
- REPL with interactive type display.
- Bytecode debugger with breakpoints.

Known limitations:

- No type classes, GADTs, or higher-rank polymorphism.
- No exceptions / asynchrony / threads.
- The optimizer's inliner is a stub.
- The GC is stop-the-world, not concurrent.
- The fmt command is a placeholder.

## Roadmap

- 0.2.0: better inliner, exception handling.
- 0.3.0: proper formatter, IDE-protocol stub.
- 0.4.0: native-code emitter via LLVM.

## Contributing

See `docs/contributing.md`.
