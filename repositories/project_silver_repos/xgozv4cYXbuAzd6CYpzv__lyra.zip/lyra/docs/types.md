# Type system

Lyra has a Hindley-Milner type system: every expression has a most
general type, every let binding is generalised, and the inference
algorithm finds those types without source-level annotations.

## What types look like

The internal types live in `lyra.types.repr`. They form a small
algebra:

- **TConst** -- nullary constants: `Int`, `Bool`, `String`, `Unit`.
- **TApp** -- a constructor applied to arguments: `List Int`,
  `Map String Int`.
- **TFun** -- function types: `params -> result`.
- **TTuple** -- anonymous products: `(Int, Bool)`.
- **TRecord** -- named-field records.
- **TVar** -- a unification variable. Each one carries a *level*.
- **TForall** -- a generalised type. Introduced at let bindings.

## Levels and generalisation

Pebble's headache was MVCC; Lyra's is generalisation. The naive
algorithm (`Algorithm W`) does an O(n²) scan over the environment
each time it generalises. We use the Rémy *level-based* approach
instead:

- Every type variable has a level, initialised to the depth of the
  surrounding let bindings.
- When the inference walker enters a let, we increment the level.
- When it leaves, we decrement.
- Generalisation wraps every variable whose level is *strictly
  greater* than the current level in a forall.

The trick: a variable cannot have leaked to an outer binding unless
that binding observed it during its own inference, in which case the
unification step already lowered its level.

## Occurs check

Unification has to reject `'a -> 'a -> 'a` style infinite types.
`unify(var, ty)` walks `ty` looking for `var` before binding; if it
finds the variable inside, we raise `OccursCheckError`. Without this
the optimiser's printer would diverge.

## Algebraic data types

`type Maybe a = Nothing | Just a` registers two constructors with
the type environment. `Nothing` has type `forall a. Maybe a`; `Just`
has type `forall a. a -> Maybe a`. Pattern matches instantiate the
constructor's polytype with fresh unification variables and unify
against the scrutinee.

## Annotations

```ocaml
let id : forall a. a -> a = fn x -> x
let inc : Int -> Int = fn x -> x + 1
```

Annotations narrow inference: the inferred type must be at least as
general as the annotation. We unify the annotation with the inferred
type at the binding boundary.

## What the type checker does NOT do

- No type classes (no `Ord`, `Eq` constraint mechanism). Equality
  works for any pair of values that the unifier can compare.
- No higher-rank polymorphism. Forall quantifiers only appear at
  the top of let-bound types.
- No GADTs or existentials.

These are all reasonable extensions; each is its own design call
that we have not yet made.
