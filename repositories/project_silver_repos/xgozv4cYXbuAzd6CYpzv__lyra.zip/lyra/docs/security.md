# Security notes

Lyra is a teaching project. It was not designed for hostile inputs,
hostile networks, or anyone who is going to run untrusted Lyra
programs in their own process. A few specific notes:

## What Lyra protects against

- **Type errors at runtime.** The type checker rejects programs
  whose types do not line up. A program that compiles will not
  segfault on a type mismatch.
- **Stack overflow.** The VM caps the call stack at
  ``max_call_depth`` (default 1024); deeper non-tail recursion
  raises ``StackOverflow`` rather than blowing the C stack.
- **Use-after-free.** The garbage collector uses copying
  collection, so freed objects don't dangle.

## What Lyra does NOT protect against

- **Untrusted source code.** A malicious Lyra program can call
  primitives like ``panic`` and ``read_line``; if you exposed
  filesystem primitives to it, the program could read your files.
  Don't run untrusted code through this interpreter.
- **Resource exhaustion.** A pathological program can allocate
  forever (the GC keeps reclaiming, but the user could allocate at
  the same rate). There is no time / memory budget enforcement.
- **Side channels.** This is a Python interpreter; timing leaks and
  memory access patterns are observable.

## Reporting issues

Open an issue with a minimal reproduction. The smaller the program
that exhibits the bug, the better; we have a fixture corpus for
exactly this purpose.
