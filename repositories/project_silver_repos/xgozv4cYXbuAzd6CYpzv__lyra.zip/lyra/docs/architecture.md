# Architecture overview

This is a tour of how the layers fit together. It assumes you have
read the language tour; if not, start there.

## High-level diagram

```
                    +------------------+
                    |       SQL        |
                    |  (.lyra source)  |
                    +--------+---------+
                             |
                    lexer    v
                    +--------+---------+
                    |     Tokens       |
                    +--------+---------+
                             |
                    parser   v
                    +--------+---------+
                    |       AST        |
                    +--------+---------+
                             |
                  resolver   v
                    +--------+---------+
                    |  Resolved AST    |
                    +--------+---------+
                             |
                  type-check v
                    +--------+---------+
                    |   Typed AST      |
                    +--------+---------+
                             |
                    lower    v
                    +--------+---------+
                    |  ANF IR module   |
                    +--------+---------+
                             |
              closure-conv. v
                    +--------+---------+
                    | Top-level fns +  |
                    | explicit upvals  |
                    +--------+---------+
                             |
                  optimise   v
                    +--------+---------+
                    | Constant fold,   |
                    | DCE, tail calls  |
                    +--------+---------+
                             |
                  codegen    v
                    +--------+---------+
                    |   Bytecode       |
                    +--------+---------+
                             |
                             v
                    +------------------+    +-----------+
                    |        VM        |<-->|    GC     |
                    +------------------+    +-----------+
                             |
                             v
                    +------------------+
                    |     output       |
                    +------------------+
```

## Layers and what they own

Each layer has a single responsibility and a tiny public surface:

- **Lexer** -- bytes to tokens. Knows about source positions.
- **Parser** -- tokens to AST. Knows about precedence and the
  surface grammar.
- **Resolver** -- catches undefined and duplicate names.
- **Type checker** -- assigns each expression its most general
  type; flags pattern matches that are not exhaustive.
- **Lowerer** -- AST to IR. Drops surface sugar; everything is now
  a let-binding or a control-flow node.
- **Closure converter** -- nested lambdas become top-level
  functions with explicit upvalue parameters.
- **Optimiser** -- constant folding, dead-code elimination,
  tail-call marking.
- **Codegen** -- IR to bytecode. Assigns local slots, patches jump
  offsets, deduplicates the constant pool.
- **VM** -- a stack-based interpreter that fetches one opcode at a
  time and dispatches to a Python handler.
- **GC** -- generational copying collector. The VM tells it about
  roots; the GC handles allocation, marking, and copying.

## Data flow boundaries

The interface between adjacent layers is intentionally small. The
parser only emits AST nodes; the type checker only consumes AST
nodes; the lowerer only emits IR nodes; ...

This means each layer can be tested in isolation. It also means
adding a new feature requires touching multiple files -- not for
the cost of doing so, but to make the impact of the change
visible.

## Where the bugs live

Bugs accumulate at the layer boundaries:

- **Lexer / parser**: token kinds that don't quite match the
  parser's expectations (e.g. ``::``  vs ``OP``).
- **Type checker / lowerer**: an inferred type that the lowerer
  doesn't know how to handle.
- **Closure converter / optimiser**: an upvalue that the optimiser
  inlined away, leaving a dangling reference.
- **Optimiser / codegen**: a tail-call mark that the codegen layer
  doesn't honour.
- **VM / GC**: a write barrier that fires too late or a root walk
  that misses an in-flight value on the eval stack.

The tests target each boundary deliberately. When something breaks,
the test that catches it points straight at the layer that has
strayed from its contract.
