# Extending Lyra

A handful of common extensions and the steps each one entails. Use
this as a checklist if you find yourself implementing something we
have not built yet.

## Adding a built-in type

1. Add a `TConst` singleton in `lyra.types.repr`.
2. Update `parse_type` (in `lyra.types.sqltype` -- pebble; here, the
   inference walker handles type expressions directly) to map the
   keyword to the new type.
3. Update `_from_type_expr` in `lyra.types.infer` so the AST type
   node maps to the new internal type.
4. Wire any related primitives in `lyra.stdlib.primitives`.
5. Tests in `tests/unit/types/`.

## Adding a built-in primitive

See `docs/stdlib.md` for the full list. Short version:

1. Pick a free index.
2. Implement the handler.
3. Register it in `_PRIMITIVE_TABLE`.
4. Add to `_PRIM_INDEX` in `lyra.codegen.emit` if the compiler
   should emit it for some surface operator.
5. Tests in `tests/unit/test_stdlib.py`.

## Adding a new opcode

1. Reserve the opcode value in `lyra.constants`.
2. Implement the handler in `lyra.vm.interpreter._execute`.
3. Update the encoder in `lyra.codegen.emit` to produce it.
4. Update the disassembler in `lyra.bytecode.disasm`.
5. Bump `BYTECODE_VERSION` if the on-disk format changes; older
   `.lyrac` files will refuse to load.
6. Tests in `tests/unit/codegen/` and `tests/unit/vm/`.

## Adding a new optimiser pass

1. Add a function in `lyra.optimize.passes` that takes a module and
   mutates it in place.
2. Wire it into the driver in `optimize()`.
3. Tests in `tests/unit/test_optimize.py`.

## Adding a new declaration form

1. Define the AST node in `lyra.parser.ast`.
2. Add a parse method in `lyra.parser.parser`.
3. Handle it in `lyra.resolve.resolver`.
4. Handle it in `lyra.types.infer`.
5. Handle it in `lyra.lower.anf`.
6. Tests at every layer.

## Adding a new error code

1. Add the class in `lyra.errors` with a stable `code` attribute.
2. Add a regression test that catches it.

## Adding a CLI command

1. Drop a new `cmd_*.py` file in `lyra.cli`.
2. Add the import + `add_command` call in `lyra.cli.main`.
3. Tests via `click.testing.CliRunner`.
