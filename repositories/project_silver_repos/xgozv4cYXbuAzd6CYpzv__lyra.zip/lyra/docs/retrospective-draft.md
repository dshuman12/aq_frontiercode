# 1.0 Retrospective (draft)

## What went well

- The compiler pipeline stayed dependency-free past 1.0.
- ANF IR was the right move; pattern matching dropped in cleanly.

## What didn't

- Generalization vs. value restriction interaction surprised me twice.
- VM constants split between `lyra.constants` and `lyra.bytecode.format` caused real bugs (fixed).
