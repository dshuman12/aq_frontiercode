# Testing strategy

Each layer in the pipeline has its own folder under `tests/unit/`,
plus a few cross-cutting suites under `tests/integration/`.

## Layout

```
tests/
    conftest.py              shared fixtures
    unit/
        lexer/               token stream tests
        parser/              AST shape tests
        types/               unification, generalize, inference
        match/               exhaustiveness
        ir/                  IR printer + lower
        codegen/             emit + format round-trips
        vm/                  frame, dispatcher
        gc/                  collection cycles, write barriers
        test_*.py            misc per-module tests
    integration/
        test_pipeline.py     source -> compiled module
        test_examples.py     each example must compile
        test_pipeline_more.py edge cases that span layers
    conformance/             reserved for language-level tests
    fixtures/                shared sample programs
```

## Running

`make test` runs the whole suite. Most contributors run
`pytest tests/unit -x` while iterating because failures stop early
and cover the fastest tests. Property-based tests live in
`tests/unit/test_property.py` -- they use Hypothesis and run
relatively slowly; mark them as `slow` if they get worse.

## Fixtures

Two important fixtures live in `tests/conftest.py`:

- `_reset_type_counter` (autouse) -- prevents type-variable name
  bleeding across tests. Without it, `'t1` in test A would also
  be `'t1` in test B and the rename heuristic in
  `types.printer.render` would render them as the same letter.

## Test naming

- One file per source module, named `test_<module>.py`.
- One test function per behaviour: `test_<verb>_<context>()`.
- Tests that exercise an *error path* should match on the error
  code, not the message string.

## Fixture corpus

The `tests/fixtures/` directory is reserved for example `.lyra`
files used by multiple tests. Each test that loads a fixture must
also assert on something specific about it -- a fixture without
an assertion is dead weight.

## Coverage expectation

We aim for 90%+ line coverage on `src/lyra/`. The layers most likely
to have uncovered branches are `vm.interpreter._execute` (a big
dispatch chain) and the pretty-printer paths (rare AST shapes).
Coverage is checked with `pytest --cov`; CI fails below 80%.

## Property tests

Hypothesis is used sparingly. The cases where it has paid off:

- Tagged-int round-trip (`tag_int`/`untag_int`).
- Bytecode encode/decode round-trip with random constant tables.
- Lexer over random ASCII strings (does not crash).

Adding new property tests is welcome but they need a clear invariant
to check. Hypothesis is a sharp tool; pointing it at a function
without a property usually produces flaky tests.
