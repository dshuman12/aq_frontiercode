# Compiler internals

A Lyra program goes through five passes before it reaches the VM:

1. **Lex** -- bytes -> tokens.
2. **Parse** -- tokens -> AST.
3. **Infer** -- AST -> typed AST. Pattern-match exhaustiveness
   piggy-backs on this pass.
4. **Lower** -- AST -> IR (A-normal form).
5. **Optimise** -- IR -> IR.
6. **Codegen** -- IR -> bytecode.

Each pass is small enough to fit in one or two files. The data
shapes between passes are deliberately distinct: we do not reuse
the AST as the IR or the IR as bytecode. That keeps transformations
focused on one shape at a time.

## Lowering

The lowering pass turns a tree of expressions into a sequence of
let bindings. Each non-trivial sub-expression becomes its own
binding:

```
   1 + 2 * 3
=>
   let $t1 = 2 * 3 in
   let $t2 = 1 + $t1 in
   $t2
```

ANF makes the optimiser's job easier: every intermediate has a
name, every name has a definition, and the order of evaluation is
explicit. Codegen also benefits because each binding maps to a
single instruction.

## Closure conversion

Nested lambdas become top-level functions. The closure converter:

1. Computes the free variables of every nested function.
2. Filters out names that resolve to globals.
3. Rewrites the function's signature so it takes its captured
   variables explicitly via an `upvalues` list.
4. Replaces each lambda creation site with a `MAKE_CLOSURE` IR
   node that bundles the function label with the upvalue values.

After this pass every IR function is a top-level function -- the
codegen layer never has to emit code for a nested definition.

## Optimiser

Three classic passes, run to a fixed point:

- **Constant folding** -- evaluate `PrimExpr`s with all-literal
  arguments at compile time.
- **Dead-code elimination** -- drop let bindings whose name is
  never used and whose RHS is pure.
- **Tail-call marking** -- annotate `CallExpr`s in tail position so
  codegen emits `OP_TAIL_CALL`.

The driver iterates: DCE can expose new constants for folding, and
constant folding can produce dead bindings.

## Codegen

The bytecode emitter walks each function and produces a linear
instruction stream. Locals get slot indices in declaration order;
jumps are patched in a second pass so forward references resolve to
the right offset.

Constants pool: every immediate value (literal int, string, bool)
gets deduplicated into the module-level constant pool. The bytecode
references constants by index, keeping the instruction stream
compact.

## Why the layers don't share data

The temptation is to keep the AST and reuse it as the IR and the
bytecode. We don't, because the boundaries are where the
type-checking, optimization, and codegen invariants live. A typed
AST node is not the same shape as a typed IR node; a typed IR node
is not the same shape as a bytecode instruction. Pretending they
are is how you end up with a compiler whose passes are mysteriously
intertwined.
