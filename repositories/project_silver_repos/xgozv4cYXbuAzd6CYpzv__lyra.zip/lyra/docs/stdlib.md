# Standard library reference

The Lyra runtime exposes a small set of primitives via the
``OP_PRIM`` opcode. Each one has a numeric index that the bytecode
emitter writes inline. The user-facing names (under ``Std.*``)
ultimately compile to one of these primitives plus, in some cases,
a thin Lyra wrapper.

## Arithmetic

| Name         | Index | Type                | Notes                |
|--------------|-------|---------------------|----------------------|
| `int_add`    | 0x01  | Int -> Int -> Int   |                      |
| `int_sub`    | 0x02  | Int -> Int -> Int   |                      |
| `int_mul`    | 0x03  | Int -> Int -> Int   |                      |
| `int_div`    | 0x04  | Int -> Int -> Int   | raises on /0          |
| `int_mod`    | 0x05  | Int -> Int -> Int   | raises on %0          |
| `int_neg`    | 0x06  | Int -> Int          |                      |

## Comparison

| Name | Index | Type                       |
|------|-------|----------------------------|
| eq   | 0x10  | forall a. a -> a -> Bool   |
| ne   | 0x11  | forall a. a -> a -> Bool   |
| lt   | 0x12  | forall a. a -> a -> Bool   |
| le   | 0x13  | forall a. a -> a -> Bool   |
| gt   | 0x14  | forall a. a -> a -> Bool   |
| ge   | 0x15  | forall a. a -> a -> Bool   |

Comparisons accept any pair of values whose runtime classes match.
Mixing types raises a runtime ``TypeMismatchAtRuntime`` error;
ordinarily the type checker has caught it long before the
interpreter sees it.

## Booleans

| Name      | Index | Type             |
|-----------|-------|------------------|
| bool_and  | 0x20  | Bool -> Bool -> Bool |
| bool_or   | 0x21  | Bool -> Bool -> Bool |
| bool_not  | 0x22  | Bool -> Bool         |

## Strings

| Name            | Index | Type                   |
|-----------------|-------|------------------------|
| string_concat   | 0x30  | String -> String -> String |
| string_length   | 0x31  | String -> Int          |

## IO

| Name       | Index | Type            | Notes                       |
|------------|-------|-----------------|-----------------------------|
| print      | 0x40  | String -> Unit  | no trailing newline         |
| println    | 0x41  | String -> Unit  | trailing newline            |
| read_line  | 0x42  | Unit -> String  | reads until newline; strips it |

## List helpers

These work over the canonical ``List`` constructor `Nil` (tag 0) /
`Cons` (tag 1):

| Name           | Index | Type                          |
|----------------|-------|-------------------------------|
| list_cons      | 0x50  | a -> List a -> List a         |
| list_head      | 0x51  | List a -> a                   |
| list_tail      | 0x52  | List a -> List a              |
| list_is_empty  | 0x53  | List a -> Bool                |

`list_head` / `list_tail` raise on `Nil`; user code should pattern
match instead of relying on the primitive directly.

## Diagnostics

| Name    | Index | Type                  |
|---------|-------|-----------------------|
| panic   | 0xF0  | String -> Unit         |
| assert  | 0xF1  | Bool -> Unit           |

`panic` aborts with the supplied message; `assert` is the polite
form -- it raises with `assertion failed` when its argument is
false and is otherwise a no-op.

## Adding a primitive

1. Pick a free index in the table above.
2. Implement the handler in `lyra.stdlib.primitives`.
3. Add the name to `_PRIMITIVE_TABLE`.
4. Wire the codegen layer's `_PRIM_INDEX` if the compiler should
   emit it for some surface operator.
5. Write a test in `tests/unit/test_stdlib.py`.
