# Lyra docs

Start with `language_tour.md` if you want to learn how to write
Lyra. Pick a topic-specific doc once you know which layer you're
interested in.

| File                  | Topic                                          |
|-----------------------|------------------------------------------------|
| language_tour.md      | The user-facing surface.                       |
| types.md              | Hindley-Milner inference, generalisation, ADTs |
| compiler.md           | Pipeline, ANF lowering, closure conversion.    |
| vm.md                 | Stack-based interpreter, frames, closures.    |
| gc.md                 | Generational copying GC, write barriers.       |
| bytecode.md           | Opcode reference + module format.              |

The docs are intentionally short. The source itself is the better
reference; modules carry top-of-file docstrings explaining the *why*
in detail.
