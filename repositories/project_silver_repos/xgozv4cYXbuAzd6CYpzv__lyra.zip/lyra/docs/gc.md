# Garbage collector

Lyra ships a generational copying garbage collector. Two
generations:

- The **young** generation (nursery) is where every allocation
  starts. It is small and short-lived; minor collections happen
  when it fills up.
- The **old** generation holds long-lived objects. Minor
  collections promote survivors here; major collections sweep both
  generations.

Allocation is bump-the-pointer. Collection is "stop the world,
walk the roots, copy survivors, swap spaces, resume".

## Phases of a minor collection

1. **Root walk.** The GC asks the VM for its roots: every local,
   every upvalue, every value on every evaluation stack, plus the
   globals table.
2. **Mark.** Starting from the roots, mark every reachable object.
3. **Promote.** Survivors with `age >= promotion_age` move to the
   old generation. Survivors below the threshold stay in the young
   space and have their age bumped.
4. **Reset.** The young space is reclaimed wholesale -- no
   per-object freeing. Anything we didn't mark is gone.

A major collection adds the old generation to the walk and
includes it in the sweep.

## Write barriers

The minor collector cannot trust the young space alone: an object
in the old generation might point at a young-space object via an
intermediate field. We can't afford to scan the old generation
on every minor collection (defeats the point), so we instead
record every old-to-young pointer as it happens.

`gc.write_barrier(parent, child)` does the recording: if `parent`
is in the old space and `child` is in the young space, `parent`
gets added to the *remembered set* and is treated as a root for
the next minor collection.

The compiler emits write-barrier calls at every store into a
heap object. Forgetting one is the canonical "subtle GC bug" --
the program runs fine until the GC reclaims a still-live object,
and then it crashes minutes later when the dangling pointer is
dereferenced.

## Roots

The VM's `_iter_roots` is the single canonical source. It walks:

- every frame's local-variable array;
- every frame's upvalue array;
- every frame's evaluation stack;
- the globals table.

What it deliberately does NOT walk:

- the constant pool -- those values are immutable and never
  collected;
- the bytecode itself -- not a heap object;
- the type-checker's environment -- compile-time only.

## Tuning

`young_bytes_limit` is the biggest knob. Bigger young space means
fewer minor collections at the cost of higher pause times. The
default (4 MiB) is fine for the workloads our tests cover.

`promotion_age` controls how aggressively we promote. The default
(2) means: an object that survives two minor collections moves to
the old space. Higher values keep more objects in the young space
(faster collection, more overhead per surviving object); lower
values promote quickly (slower minor collections, more work for
major collections later).

## What this collector is NOT

- Not concurrent. Stop-the-world only.
- Not incremental. Each collection runs to completion.
- Not compacting in the old space -- old-space allocations
  fragment over time. A compacting major collection would help;
  we have not implemented one.

These are textbook extensions; each is one to three days of
focused work plus tests.
