# Contributing

Lyra is small enough that you can read it end-to-end in an
afternoon. The bar for contributions is "I read the relevant module,
I understand why it does what it does, and my change keeps that
'small enough to read end-to-end' property". A few specific notes:

## Style

`make format` runs `ruff format` + autofixes; `make lint` and `make
typecheck` are what CI checks. We aim for strict mypy on `src/`;
tests can be looser.

Functions belong in the layer they are about. The type checker does
not import from the VM; the VM does not import from the parser. A
change that adds a cross-layer reference needs a "why is this OK"
comment in the PR.

## Tests

Every change to a non-trivial module should grow at least one test.
Hypothesis is on the dev requirement list; if you are testing a
boundary condition (occurs check, write barrier, tail-call
elimination) a property test is usually shorter than enumerating
cases by hand.

Run the suite locally before opening a PR:

```bash
make test
```

## Pull requests

Keep PRs small. The maintainers' rule of thumb: if a single PR
touches more than three modules, split it unless there is a
documented reason it has to land together.

When the change crosses layers (e.g. adding a new opcode requires
updating codegen, the disassembler, AND the VM), say so in the PR
description and call out the invariants you preserved.

## Issues

Please open an issue before working on a non-trivial change. We
sometimes have a half-finished design doc for the area you are
interested in; pointing you at it saves you re-treading the same
path.

## License

By contributing, you agree your contribution is licensed under the
Apache 2.0 license listed in `LICENSE`.
