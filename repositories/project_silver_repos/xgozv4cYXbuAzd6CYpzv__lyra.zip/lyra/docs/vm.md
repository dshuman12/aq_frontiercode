# Virtual machine

The Lyra VM is a stack-based interpreter for the bytecode emitted by
the compiler. It has three pieces:

- A **call stack** of frames, one per in-flight function call.
- An **evaluation stack** per frame.
- A reference to the **garbage collector** that allocates heap
  objects on demand.

The interpreter loop fetches one opcode at a time, reads its
operand, and dispatches via a big `if/elif` chain. Each handler
either pushes/pops the eval stack, advances the program counter,
or transfers control to a different frame.

## Frames

A `Frame` carries:

- a reference to the compiled function it is executing;
- an array of local variables (parameters in slots `0..arity-1`,
  then anonymous bindings introduced by ANF);
- an array of upvalues (immutable for the lifetime of the call);
- the program counter;
- the eval stack.

We do not maintain a global "current frame" pointer; instead the
interpreter peeks at `stack.frames[-1]` whenever it needs to know.

## Tail-call elimination

When the codegen layer emits `OP_TAIL_CALL`, the VM replaces the
current top frame with the callee's frame instead of pushing a new
one. The Python call stack does not grow, and a deeply recursive
program does not blow the limit. Without this, `let rec count = fn
n -> if n == 0 then 0 else count (n - 1)` would crash on its
millionth iteration.

## Closures

A closure is a heap object carrying:

- the label of its target function;
- a copy of its captured upvalues at allocation time.

`MAKE_CLOSURE n` reads `n` upvalues off the eval stack, allocates a
closure object, and pushes it back. `CALL n` pops `n` argument
values and the closure, builds a frame, and dispatches.

## Primitives

`OP_PRIM` opcodes drop into Python-level handlers registered in
`lyra.stdlib.primitives`. Each handler pops its arguments, computes
its result, and pushes it back. Handlers can raise -- their
exceptions propagate as Lyra runtime errors.

## GC integration

The GC's `root_provider` is bound to the VM's `_iter_roots`
method, which walks the call stack collecting every local, every
upvalue, and every value in flight on an eval stack. The GC also
reads the global table.

Every `gc.allocate` call has an opportunity to trigger a minor or
major collection. The interpreter does not need to opt in: the GC
just observes that the young space is full and runs a collection
before returning the new object.

## Cancellation, exceptions, async

Not yet implemented. The `OP_THROW` / `OP_TRY` opcodes are reserved
in the encoder but the interpreter raises a Python exception from
`OP_THROW` rather than propagating through Lyra-level handlers.
That's a reasonable v1 semantics; full structured exception
handling is a future PR.

## Performance

This is a teaching VM; do not expect it to compete with PyPy, let
alone V8. A back-of-the-envelope benchmark on a 2024-era laptop
shows a tight `fib 25` loop completing in roughly two seconds.

The hot paths to expect on a profile:

1. The big `if/elif` dispatcher in `interpreter._execute`.
2. `_iter_roots` during GC -- linear in stack depth.
3. `Box` allocation -- one Python object per boxed value.

A real implementation would use computed-goto dispatch and pack
small objects into a single allocation; we leave both as exercises.
