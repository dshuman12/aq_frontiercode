# REPL

The REPL is an interactive Lyra prompt that compiles each line, runs
it, and prints the result. It also displays inferred types so you
can see what the type checker is doing.

## Running

```bash
lyra repl
```

## Sample session

```
lyra> 1 + 2
: Int
3

lyra> fn x -> x + 1
: 'a -> 'a
<closure lambda_1>

lyra> let make_adder = fn n -> fn x -> x + n
: forall a. a -> 'a -> 'a

lyra> let add3 = make_adder 3
: 'a -> 'a

lyra> add3 7
: Int
10
```

## Commands

The REPL recognises a small set of meta-commands prefixed with `:`:

- `:q` / `:quit` -- exit.
- `:t <expr>` -- display the inferred type without running.
- `:env` -- list all bindings currently in scope.
- `:reset` -- clear the REPL's persistent environment.
- `:load <path>` -- load and evaluate a Lyra file in the current
  REPL session.

## Multi-line input

A line that ends with `\\` continues onto the next line:

```
lyra> let rec fib = fn n ->\\
... if n <= 1 then n\\
... else fib (n - 1) + fib (n - 2)
```

The parser is layout-insensitive; the continuation prompt is purely
cosmetic.

## History

The REPL records every line in `~/.lyra_history`. Up-arrow walks
history. Override the path with `lyra repl --history /elsewhere`.

## Limitations

- Module imports do not work in the REPL yet -- only single-line
  bindings.
- Crash-on-eval blows away the REPL state. Errors that we catch
  (type errors, runtime errors) leave you in the prior environment.
- The `:env` command is a placeholder; the implementation will land
  with the next minor release.
