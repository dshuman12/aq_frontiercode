# Examples

The ``examples/`` directory contains small Lyra programs that
exercise a particular feature. Each one compiles cleanly with
``lyra build examples/<name>.lyra`` and runs with the matching
``.lyrac``.

| File              | Demonstrates                                    |
|-------------------|-------------------------------------------------|
| hello.lyra        | The smallest valid program.                     |
| fib.lyra          | Recursive function + tail-position arithmetic. |
| list.lyra         | ADT + pattern match + recursive helpers.       |
| tree.lyra         | Binary search tree with insert + lookup.       |
| closure.lyra      | First-class functions, captured variables.     |
| maybe.lyra        | Maybe monad: map / bind / unwrap_or.           |
| arith.lyra        | Walking a tagged AST.                          |
| option_chain.lyra | Chained Maybe with primitive string handling.  |
| stdlib_demo.lyra  | External declarations to standard-library prim |

## Running

Each example assumes the package is installed (or that you ran
``pip install -e .[dev]``). Then:

```bash
lyra build examples/fib.lyra        # produces examples/fib.lyrac
lyra run examples/fib.lyrac          # runs it
lyra run examples/fib.lyra           # compiles + runs in one go
lyra disasm examples/fib.lyra        # show the bytecode
```

## What the examples do *not* cover

- Async / IO heavy programs -- the runtime is synchronous.
- Multi-module programs -- a single file is enough for now; the
  tests in ``tests/integration`` exercise the loader.
- Error handling at the language level -- ``THROW`` / ``TRY``
  opcodes exist in the encoder but the interpreter raises a Python
  exception rather than propagating through user-defined handlers.

If you want to add an example, follow the pattern of the existing
ones: short, demonstrates one concept, ends with a ``let main =
...`` that produces an interesting value.
