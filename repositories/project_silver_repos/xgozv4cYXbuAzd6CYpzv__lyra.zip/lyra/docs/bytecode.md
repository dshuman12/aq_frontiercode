# Bytecode reference

Every instruction is one byte for the opcode plus, for most of
them, a 16-bit little-endian operand. The full set:

| Opcode            | Hex   | Operand  | Stack effect                                 |
|-------------------|-------|----------|----------------------------------------------|
| `NOP`             | 0x00  | -        | (no-op)                                      |
| `LOAD_CONST`      | 0x01  | u16      | -- pushes constants[idx]                     |
| `LOAD_LOCAL`      | 0x02  | u16      | -- pushes locals[slot]                       |
| `STORE_LOCAL`     | 0x03  | u16      | pops, writes to locals[slot]                 |
| `LOAD_UPVAL`      | 0x04  | u16      | -- pushes upvalues[slot]                     |
| `LOAD_GLOBAL`     | 0x05  | u16      | -- pushes globals[constants[idx]]            |
| `STORE_GLOBAL`    | 0x06  | u16      | pops, writes to globals[constants[idx]]      |
| `POP`             | 0x07  | -        | pops                                         |
| `DUP`             | 0x08  | -        | duplicates top                               |
| `CALL`            | 0x10  | u16      | pops args+callee, pushes result              |
| `TAIL_CALL`       | 0x11  | u16      | replaces current frame                       |
| `RETURN`          | 0x12  | -        | returns top of stack from current frame      |
| `MAKE_CLOSURE`    | 0x13  | u16      | pops upvalues, pushes a closure object       |
| `JUMP`            | 0x20  | u16      | unconditional, target = operand              |
| `JUMP_IF_FALSE`   | 0x21  | u16      | pops, jumps if false                         |
| `JUMP_IF_TRUE`    | 0x22  | u16      | pops, jumps if true                          |
| `MATCH_TAG`       | 0x23  | u16      | peeks scrutinee, pushes bool                 |
| `THROW`           | 0x24  | -        | pops, raises                                 |
| `TRY`             | 0x25  | u16      | install handler at offset                    |
| `END_TRY`         | 0x26  | -        | pop handler                                  |
| `ALLOC`           | 0x30  | u16      | pops fields, pushes new object               |
| `GET_FIELD`       | 0x31  | u16      | pops obj, pushes obj.fields[idx]             |
| `SET_FIELD`       | 0x32  | u16      | pops obj+value, mutates                      |
| `LOAD_TAG`        | 0x33  | -        | pops obj, pushes tag                         |
| `PRIM`            | 0x40  | u16      | dispatches to primitive table                |
| `HALT`            | 0xFF  | -        | terminates VM                                |

## Module file format

A compiled module on disk:

```
[8 bytes]  magic  "LYRA0001"
[u32]      version
[u32]      flags
[u32]      constant count
  [u8 kind][payload]
[u32]      function count
  [u16 label_len][label bytes]
  [u8 arity][u8 upvalues][u8 locals]
  [u32 code_len][code bytes]
[u32]      import count
  [u16 name_len][name]
[u32]      export count
  [u16 name_len][name][u32 function_index]
```

Constants:

- `0x01 INT` -- 8-byte signed little-endian.
- `0x02 FLOAT` -- 8-byte IEEE-754.
- `0x03 STRING` -- u32 length-prefixed UTF-8.
- `0x04 BOOL` -- one byte.
- `0x05 CHAR` -- one byte length, then UTF-8.
- `0x06 UNIT` -- no payload.

## Disassembly

`lyra disasm <file>` prints constants, imports, exports, and one
line per instruction:

```
function fib (arity=1, upvalues=0, locals=2)
  0000  LOAD_LOCAL     0
  0003  LOAD_CONST     1
  0006  PRIM           19   // le
  0009  JUMP_IF_FALSE  20
  ...
```

## Why the operand width is fixed at 16 bits

A 16-bit operand handles up to 65535 distinct constants, locals, or
jump targets per function. Real workloads never come close to that
limit -- in our tests the largest function has under 200 locals.
Going to 32-bit operands would double the bytecode size for a
benefit no one would feel. Future variable-width encoding (LEB128)
is a future PR.
