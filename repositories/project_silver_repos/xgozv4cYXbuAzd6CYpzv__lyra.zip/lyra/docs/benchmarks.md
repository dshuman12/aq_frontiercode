# Benchmarking guide

The `bench/` directory contains a tiny harness that times a small
set of programs through the full pipeline. It is a sanity check, not
a real benchmark.

## Running

```bash
python -m bench.run --iterations 5
```

For each program in the suite, the harness measures:

- Compile time (lex + parse + infer + lower + optimise + emit).
- Run time (VM execution to completion).

## Interpreting the numbers

Lyra is a CPython-hosted interpreter; expect numbers in the
single-digit-millisecond range for compile and double-digit-
millisecond range for run. A regression that doubles either is
worth investigating.

Hot paths to expect on a profile:

1. The big `if/elif` dispatch in `vm.interpreter._execute`.
2. The unifier's `_occurs_walk`.
3. `Box` allocation in `gc.allocate`.

Bigger young-space limits (`young_bytes_limit`) usually win 10-20%
on the recursive `fib` and tree examples by reducing minor
collection frequency.

## When a real benchmark is what you want

The harness covers the inner loop. For end-to-end measurements
(GC pause distribution, throughput on a streaming workload) you
want a different kind of test entirely. Lyra ships none; the
docs/gc.md walks through the manual steps.
