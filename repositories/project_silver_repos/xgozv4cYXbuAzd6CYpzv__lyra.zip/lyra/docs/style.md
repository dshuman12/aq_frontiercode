# Style guide

Lyra's source is meant to be read top-to-bottom. A few conventions
that follow from that, beyond what `ruff` enforces:

## Module docstrings

Every module starts with a docstring that explains what the module
is for and how it fits into the rest of the project. Five lines is
plenty; thirty is too many.

## Type annotations

Strict `mypy` is on for `src/`. Tests skip annotations on fixtures
because pytest's typing is weak; everywhere else, annotate.

## Imports

`__future__` first, then stdlib, then third-party, then `lyra.`.
Inside each block: alphabetical, sorted by `ruff`'s `isort`
implementation. Avoid lazy imports unless you have a documented
reason (avoiding a cycle, avoiding a heavy dependency at module
load).

## Errors

Every error class lives in `lyra.errors` and has a stable `code`
attribute. Tests that catch a specific error should match on the
code, not the message string.

## Logging

Use `logging.getLogger(__name__)`. Structured fields go on the
`extra=` kwarg, not into the format string.

## Functions vs classes

Prefer functions. Classes are appropriate for things that hold
mutable state across calls (the buffer pool, the lock manager, the
btree). A class with no instance state and a single method is a
function with bad spelling.

## Comments

Comment the *why*, not the *what*. `# walk the list` does not earn
its keep; `# we walk in reverse so deletes don't invalidate the
index` does.

## Names

- Compiler passes: lowercase verb (`lower`, `optimise`, `convert`).
- Data types: PascalCase noun (`Module`, `Frame`, `TVar`).
- Predicates: `is_X` or `has_X`.
- Test files: `test_<topic>.py`, one per source module.

## Exhaustive switch / match

When a function dispatches on a sum type (e.g. `_render_pattern`
in `parser/printer.py`), every constructor must have an explicit
branch. The parser's exhaustiveness checker rejects falling through
to a generic else.
