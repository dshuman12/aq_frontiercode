# FAQ

## Why another small language?

Three reasons. First, building a typed language end-to-end is the
fastest way to internalise type theory; reading papers can get you
80% there, and the last 20% are the kind of details you only notice
when you write the unifier yourself. Second, the GC is famously full
of subtle bugs that a textbook description glosses over -- having
one in front of you, with tests, beats reading about them. Third,
the surface area is small enough to fit in a single repo without
turning into a research project.

## Why ML syntax instead of S-expressions / Python-flavoured?

ML's `let` / `match` / `fn` syntax is the most concise way to write
the kinds of programs Lyra targets, and it pairs naturally with the
inference engine. S-expressions would have made the parser shorter
but most readers find them a barrier; Python-flavoured indentation
would have demanded a layout-sensitive lexer.

## Why Hindley-Milner instead of bidirectional type checking?

HM is the simplest algorithm that gives you let-polymorphism. We
don't need higher-rank types, so we don't pay the bidirectional
machinery's cost. If we ever extend Lyra with rank-2 polymorphism or
GADTs we'll switch.

## Why a tagged-pointer scheme?

Most arithmetic-heavy programs spend the bulk of their values on
integers. Tagging keeps them inline -- no allocation, no GC, no
indirection. The cost is a one-bit-shift on every int operation,
which is cheaper than a heap allocation by orders of magnitude.

## Will it ever be fast?

Not in this implementation. We are running an interpreter written
in Python on top of CPython; the constant factor is at least 100x
worse than a JIT-compiled language. A future version that emits
LLVM IR or that targets WebAssembly would close that gap.

## Why no exceptions / asynchrony / threads?

The bytecode reserves opcodes for `THROW` / `TRY`; the interpreter
falls back on Python exceptions. Asynchrony and threads are out of
scope for v1. Each one is a meaningful design call about how
runtime fibres interact with the GC and the type system, and we
have not made those calls yet.

## Can I use it in production?

Please don't. The recovery code (such as it is) has documented
gaps; the type checker has at least one known false-rejection edge
case; the GC is not concurrent. Use Lyra to prototype, to learn,
or to teach -- not to ship.

## How do I report a bug?

Open an issue with a minimal reproduction. The smaller the program
that exhibits the bug, the better; we have a fixture corpus for
exactly this purpose.
