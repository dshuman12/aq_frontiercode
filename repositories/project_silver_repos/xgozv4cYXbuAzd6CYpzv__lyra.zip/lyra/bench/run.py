from __future__ import annotations

import argparse
import time
from pathlib import Path

from lyra.runtime import compile_file, run_compiled


PROGRAMS = [
    "examples/fib.lyra",
    "examples/list.lyra",
    "examples/closure.lyra",
    "examples/tree.lyra",
]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--iterations", type=int, default=3)
    args = parser.parse_args()

    for path in PROGRAMS:
        full = Path(path)
        if not full.exists():
            print(f"(skip) {path} -- not found")
            continue
        compile_total = 0.0
        run_total = 0.0
        for _ in range(args.iterations):
            t0 = time.perf_counter()
            compiled = compile_file(full)
            compile_total += time.perf_counter() - t0
            t0 = time.perf_counter()
            run_compiled(compiled.module)
            run_total += time.perf_counter() - t0
        avg_compile = compile_total / args.iterations
        avg_run = run_total / args.iterations
        print(
            f"{path:30s}  compile={avg_compile * 1000:.2f} ms  "
            f"run={avg_run * 1000:.2f} ms"
        )


if __name__ == "__main__":
    main()
