Contributing to Lyra
====================

Thanks for the interest. Before opening a PR:

* `pytest` should stay green.
* Keep the diff focused.
* New features need tests; bug fixes need a regression test.
* `ruff check` and `ruff format` should be clean.

See ``docs/style.md`` for the conventions used in the source tree.
