# ledgercore

A double-entry accounting engine implementing Generally Accepted Accounting
Principles (GAAP) in Python. Handles multi-currency transactions, fiscal
period management, financial statement generation, and audit trails.

## Core Invariants

1. **Double-entry**: Every transaction has equal debits and credits
2. **Accounting equation**: Assets = Liabilities + Equity (always)
3. **Normal balances**: Assets/Expenses are debit-normal; Liabilities/Equity/Revenue are credit-normal
4. **Period immutability**: Closed periods cannot be modified
5. **Audit trail**: All changes are tracked; entries cannot be deleted, only reversed

## Architecture

- **core/**: Account, Money, Currency with precise decimal arithmetic
- **chart/**: Chart of accounts with hierarchical account numbering
- **journal/**: Journal entries with validation and posting
- **ledger/**: General ledger, trial balance, posting engine
- **period/**: Fiscal periods, closing entries, retained earnings rollover
- **currency/**: Exchange rates, multi-currency conversion, realized/unrealized gains
- **reports/**: Balance sheet, income statement, trial balance, cash flow
- **budget/**: Budget management and variance analysis
- **audit/**: Immutable audit trail with change tracking
- **tax/**: Tax calculation and withholding
- **recon/**: Bank reconciliation with matching algorithms

## Testing
```bash
pytest tests/ -v
```
