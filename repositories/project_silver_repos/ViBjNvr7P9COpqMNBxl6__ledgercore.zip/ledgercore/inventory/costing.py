"""Inventory costing methods: FIFO, LIFO, Weighted Average.

Inventory costing determines the cost of goods sold (COGS) and the
value of remaining inventory. The choice of method significantly
impacts financial statements, especially during inflation.

FIFO (First In, First Out):
  Oldest inventory sold first. Remaining inventory is newest (higher cost).
  COGS uses oldest costs -> lower COGS in inflation -> higher net income.

LIFO (Last In, First Out):
  Newest inventory sold first. Remaining inventory is oldest (lower cost).
  COGS uses newest costs -> higher COGS in inflation -> lower net income.
  (LIFO is not permitted under IFRS, only under US GAAP.)

Weighted Average:
  Average cost = Total Cost of Available / Total Units Available
  Applied to all units sold and remaining.

Specific Identification:
  Each unit tracked individually (for high-value items like cars).

The key challenge: tracking inventory layers (FIFO/LIFO) requires
maintaining a queue/stack of purchase lots with their costs.

Journal entries:
  Purchase: Dr. Inventory, Cr. Cash/AP
  Sale (perpetual): Dr. COGS, Cr. Inventory (at calculated cost)
  Sale (periodic): COGS calculated at period end, not per-sale
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal, ROUND_HALF_EVEN
from collections import deque
from typing import Any
from ledgercore.core.money import Money, Currency
from ledgercore.core.entry import JournalEntry


@dataclass
class InventoryLot:
    """A purchase lot of inventory."""
    lot_id: str
    purchase_date: date
    quantity: int
    unit_cost: Decimal
    remaining_quantity: int = 0

    def __post_init__(self):
        if self.remaining_quantity == 0:
            self.remaining_quantity = self.quantity

    @property
    def total_cost(self) -> Decimal:
        return self.remaining_quantity * self.unit_cost

    @property
    def is_exhausted(self) -> bool:
        return self.remaining_quantity <= 0


@dataclass
class InventoryItem:
    """An inventory item with its lot history."""
    item_id: str
    name: str
    currency: Currency
    lots: deque[InventoryLot] = field(default_factory=deque)

    @property
    def total_quantity(self) -> int:
        return sum(lot.remaining_quantity for lot in self.lots)

    @property
    def total_cost(self) -> Decimal:
        return sum(lot.total_cost for lot in self.lots)

    @property
    def average_unit_cost(self) -> Decimal:
        qty = self.total_quantity
        if qty == 0:
            return Decimal("0")
        return (self.total_cost / qty).quantize(Decimal("0.01"), rounding=ROUND_HALF_EVEN)


@dataclass
class CostResult:
    """Result of calculating cost of goods sold."""
    quantity_sold: int
    total_cost: Decimal
    lots_used: list[tuple[str, int, Decimal]] = field(default_factory=list)  # (lot_id, qty, cost)


class InventoryManager:
    """Manage inventory with configurable costing method."""

    def __init__(self, method: str = "FIFO", currency: Currency | None = None):
        self._method = method.upper()  # FIFO, LIFO, AVERAGE
        self._items: dict[str, InventoryItem] = {}
        self._currency = currency

    def add_item(self, item: InventoryItem) -> None:
        self._items[item.item_id] = item

    def get_item(self, item_id: str) -> InventoryItem | None:
        return self._items.get(item_id)

    def receive_inventory(
        self,
        item_id: str,
        lot_id: str,
        purchase_date: date,
        quantity: int,
        unit_cost: Decimal,
    ) -> InventoryLot:
        """Record inventory receipt (purchase)."""
        item = self._items.get(item_id)
        if item is None:
            raise ValueError(f"Item {item_id} not found")
        lot = InventoryLot(
            lot_id=lot_id, purchase_date=purchase_date,
            quantity=quantity, unit_cost=unit_cost,
        )
        item.lots.append(lot)
        return lot

    def calculate_cogs(self, item_id: str, quantity: int) -> CostResult:
        """Calculate cost of goods sold for a given quantity.

        Uses the configured costing method (FIFO, LIFO, or AVERAGE).
        Does NOT modify inventory — call commit_sale() after.
        """
        item = self._items.get(item_id)
        if item is None:
            raise ValueError(f"Item {item_id} not found")
        if quantity > item.total_quantity:
            raise ValueError(f"Insufficient inventory: need {quantity}, have {item.total_quantity}")

        if self._method == "FIFO":
            return self._fifo_cost(item, quantity)
        elif self._method == "LIFO":
            return self._lifo_cost(item, quantity)
        elif self._method == "AVERAGE":
            return self._average_cost(item, quantity)
        else:
            raise ValueError(f"Unknown method: {self._method}")

    def commit_sale(self, item_id: str, cost_result: CostResult) -> None:
        """Actually deduct inventory after calculating COGS."""
        item = self._items.get(item_id)
        if item is None:
            return

        if self._method == "AVERAGE":
            # Deduct from oldest lots proportionally
            remaining = cost_result.quantity_sold
            for lot in list(item.lots):
                if remaining <= 0:
                    break
                deduct = min(remaining, lot.remaining_quantity)
                lot.remaining_quantity -= deduct
                remaining -= deduct
        else:
            for lot_id, qty, _ in cost_result.lots_used:
                for lot in item.lots:
                    if lot.lot_id == lot_id:
                        lot.remaining_quantity -= qty
                        break

        # Remove exhausted lots
        item.lots = deque(lot for lot in item.lots if not lot.is_exhausted)

    def _fifo_cost(self, item: InventoryItem, quantity: int) -> CostResult:
        """FIFO: sell oldest inventory first."""
        remaining = quantity
        total_cost = Decimal("0")
        lots_used = []

        for lot in item.lots:
            if remaining <= 0:
                break
            take = min(remaining, lot.remaining_quantity)
            cost = take * lot.unit_cost
            lots_used.append((lot.lot_id, take, cost))
            total_cost += cost
            remaining -= take

        return CostResult(quantity, total_cost, lots_used)

    def _lifo_cost(self, item: InventoryItem, quantity: int) -> CostResult:
        """LIFO: sell newest inventory first."""
        remaining = quantity
        total_cost = Decimal("0")
        lots_used = []

        for lot in reversed(item.lots):
            if remaining <= 0:
                break
            take = min(remaining, lot.remaining_quantity)
            cost = take * lot.unit_cost
            lots_used.append((lot.lot_id, take, cost))
            total_cost += cost
            remaining -= take

        return CostResult(quantity, total_cost, lots_used)

    def _average_cost(self, item: InventoryItem, quantity: int) -> CostResult:
        """Weighted average cost."""
        avg = item.average_unit_cost
        total_cost = (quantity * avg).quantize(Decimal("0.01"), rounding=ROUND_HALF_EVEN)
        return CostResult(quantity, total_cost, [("average", quantity, total_cost)])

    def generate_purchase_entry(
        self,
        item_id: str,
        lot: InventoryLot,
        entry_id: str,
        inventory_account: str,
        cash_account: str,
    ) -> JournalEntry:
        """Generate journal entry for inventory purchase."""
        currency = self._items[item_id].currency
        total = Money(lot.total_cost, currency)
        entry = JournalEntry(entry_id=entry_id, entry_date=lot.purchase_date,
                           description=f"Purchase inventory: {self._items[item_id].name}")
        entry.add_debit(inventory_account, total)
        entry.add_credit(cash_account, total)
        return entry

    def generate_sale_entry(
        self,
        item_id: str,
        cost_result: CostResult,
        sale_price: Money,
        entry_id: str,
        sale_date: date,
        cogs_account: str,
        inventory_account: str,
        cash_account: str,
        revenue_account: str,
    ) -> JournalEntry:
        """Generate journal entry for inventory sale.

        Dr. Cash (sale price)
        Dr. COGS (cost of goods)
          Cr. Revenue (sale price)
          Cr. Inventory (cost of goods)
        """
        currency = self._items[item_id].currency
        cogs = Money(cost_result.total_cost, currency)
        entry = JournalEntry(entry_id=entry_id, entry_date=sale_date,
                           description=f"Sale of {self._items[item_id].name}")
        entry.add_debit(cash_account, sale_price)
        entry.add_debit(cogs_account, cogs)
        entry.add_credit(revenue_account, sale_price)
        entry.add_credit(inventory_account, cogs)
        return entry

    @property
    def item_count(self) -> int:
        return len(self._items)

    def total_inventory_value(self) -> Decimal:
        return sum(item.total_cost for item in self._items.values())
