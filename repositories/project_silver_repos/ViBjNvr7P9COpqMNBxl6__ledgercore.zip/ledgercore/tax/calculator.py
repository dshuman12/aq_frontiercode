"""Tax calculation with jurisdiction-based rules.

Supports:
- Progressive (bracketed) tax rates
- Flat tax rates
- Withholding tax on specific transaction types
- Tax-exempt accounts and thresholds
"""
from __future__ import annotations
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any
from ledgercore.core.money import Money, Currency


@dataclass
class TaxBracket:
    """A single bracket in a progressive tax schedule."""
    lower_bound: Decimal
    upper_bound: Decimal | None  # None = no upper limit
    rate: Decimal  # as decimal (0.10 = 10%)


@dataclass
class TaxSchedule:
    """A tax schedule with brackets."""
    name: str
    jurisdiction: str
    brackets: list[TaxBracket] = field(default_factory=list)
    currency: Currency | None = None

    def calculate(self, taxable_amount: Money) -> Money:
        """Calculate tax using progressive brackets.

        Each bracket's rate applies only to the portion of income
        within that bracket. This is the marginal tax rate system.
        """
        if not self.brackets:
            return Money.zero(taxable_amount.currency)

        remaining = taxable_amount.amount
        total_tax = Decimal("0")

        for bracket in sorted(self.brackets, key=lambda b: b.lower_bound):
            if remaining <= 0:
                break
            if bracket.upper_bound is not None:
                bracket_width = bracket.upper_bound - bracket.lower_bound
                taxable_in_bracket = min(remaining, bracket_width)
            else:
                taxable_in_bracket = remaining

            if taxable_in_bracket > 0:
                total_tax += taxable_in_bracket * bracket.rate
                remaining -= taxable_in_bracket

        return Money(total_tax, taxable_amount.currency)

    @property
    def effective_rate(self) -> Decimal:
        """For display only — not used in calculation."""
        if not self.brackets:
            return Decimal("0")
        return self.brackets[-1].rate


@dataclass
class WithholdingRule:
    """A withholding tax rule for specific transaction types."""
    name: str
    rate: Decimal
    applies_to_tags: set[str] = field(default_factory=set)
    threshold: Decimal = Decimal("0")  # minimum amount before withholding applies
    exempt_accounts: set[str] = field(default_factory=set)


class TaxCalculator:
    """Calculate taxes based on configured schedules and rules."""

    def __init__(self):
        self._schedules: dict[str, TaxSchedule] = {}
        self._withholding_rules: list[WithholdingRule] = []

    def add_schedule(self, schedule: TaxSchedule) -> None:
        self._schedules[schedule.name] = schedule

    def get_schedule(self, name: str) -> TaxSchedule | None:
        return self._schedules.get(name)

    def add_withholding_rule(self, rule: WithholdingRule) -> None:
        self._withholding_rules.append(rule)

    def calculate_income_tax(self, schedule_name: str, taxable_income: Money) -> Money:
        schedule = self._schedules.get(schedule_name)
        if schedule is None:
            raise ValueError(f"Tax schedule '{schedule_name}' not found")
        return schedule.calculate(taxable_income)

    def calculate_withholding(
        self, amount: Money, tags: set[str], account_number: str = ""
    ) -> Money:
        """Calculate total withholding tax for a payment."""
        total = Decimal("0")
        for rule in self._withholding_rules:
            if not rule.applies_to_tags.intersection(tags):
                continue
            if account_number in rule.exempt_accounts:
                continue
            if amount.amount < rule.threshold:
                continue
            total += amount.amount * rule.rate
        return Money(total, amount.currency)
