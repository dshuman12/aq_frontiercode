"""Payroll processing engine.

Payroll involves multiple deductions and employer contributions that
create a complex set of journal entries:

Employee perspective:
  Gross Pay
  - Federal Tax Withholding
  - State Tax Withholding
  - Social Security (employee share)
  - Medicare (employee share)
  - Health Insurance (employee share)
  - 401k Contribution
  = Net Pay (what employee receives)

Employer perspective (additional costs):
  Social Security (employer share - matches employee)
  Medicare (employer share - matches employee)
  Federal Unemployment Tax (FUTA)
  State Unemployment Tax (SUTA)
  Health Insurance (employer share)
  Workers Compensation

Journal entries for payroll:
  Dr. Salary Expense (gross pay)
  Dr. Payroll Tax Expense (employer taxes)
  Dr. Benefits Expense (employer insurance share)
    Cr. Cash (net pay to employee)
    Cr. Federal Tax Payable (withholding)
    Cr. State Tax Payable (withholding)
    Cr. Social Security Payable (both shares)
    Cr. Medicare Payable (both shares)
    Cr. Health Insurance Payable
    Cr. 401k Payable

The complexity: tax rates have thresholds (Social Security caps at
a wage base), some deductions are pre-tax (reduce taxable income),
and employer taxes are SEPARATE from employee deductions.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from typing import Any
from ledgercore.core.money import Money, Currency
from ledgercore.core.entry import JournalEntry


@dataclass
class TaxRate:
    """A payroll tax rate with optional wage base cap."""
    name: str
    rate: Decimal  # as decimal (0.062 = 6.2%)
    wage_base: Decimal | None = None  # max wages subject to this tax
    is_employer: bool = False  # employer-only tax


@dataclass
class Employee:
    """An employee record for payroll."""
    employee_id: str
    name: str
    gross_salary: Money  # per pay period
    federal_allowances: int = 1
    state: str = ""
    pre_tax_deductions: dict[str, Money] = field(default_factory=dict)  # name -> amount
    post_tax_deductions: dict[str, Money] = field(default_factory=dict)
    ytd_gross: Money = field(default_factory=lambda: Money(0, Currency("USD", "$")))
    ytd_federal_tax: Money = field(default_factory=lambda: Money(0, Currency("USD", "$")))
    ytd_social_security: Money = field(default_factory=lambda: Money(0, Currency("USD", "$")))
    is_active: bool = True


@dataclass
class PayrollResult:
    """Result of processing payroll for one employee."""
    employee_id: str
    employee_name: str
    gross_pay: Money
    federal_tax: Money
    state_tax: Money
    social_security_employee: Money
    social_security_employer: Money
    medicare_employee: Money
    medicare_employer: Money
    pre_tax_deductions: dict[str, Money] = field(default_factory=dict)
    post_tax_deductions: dict[str, Money] = field(default_factory=dict)

    @property
    def total_employee_deductions(self) -> Money:
        total = self.federal_tax + self.state_tax + self.social_security_employee + self.medicare_employee
        for v in self.pre_tax_deductions.values():
            total = total + v
        for v in self.post_tax_deductions.values():
            total = total + v
        return total

    @property
    def net_pay(self) -> Money:
        return self.gross_pay - self.total_employee_deductions

    @property
    def total_employer_cost(self) -> Money:
        return self.gross_pay + self.social_security_employer + self.medicare_employer


class PayrollProcessor:
    """Process payroll with tax calculations and journal entry generation."""

    # Standard US tax rates (simplified)
    SOCIAL_SECURITY_RATE = Decimal("0.062")
    SOCIAL_SECURITY_WAGE_BASE = Decimal("160200")  # 2023 limit
    MEDICARE_RATE = Decimal("0.0145")
    MEDICARE_ADDITIONAL_RATE = Decimal("0.009")
    MEDICARE_ADDITIONAL_THRESHOLD = Decimal("200000")

    def __init__(self, currency: Currency):
        self._currency = currency
        self._federal_brackets: list[tuple[Decimal, Decimal, Decimal]] = [
            # (lower, upper, rate)
            (Decimal("0"), Decimal("11000"), Decimal("0.10")),
            (Decimal("11000"), Decimal("44725"), Decimal("0.12")),
            (Decimal("44725"), Decimal("95375"), Decimal("0.22")),
            (Decimal("95375"), Decimal("182100"), Decimal("0.24")),
            (Decimal("182100"), Decimal("231250"), Decimal("0.32")),
            (Decimal("231250"), Decimal("578125"), Decimal("0.35")),
            (Decimal("578125"), None, Decimal("0.37")),
        ]

    def calculate_federal_tax(self, annualized_taxable: Decimal) -> Decimal:
        """Progressive federal tax on annualized taxable income."""
        tax = Decimal("0")
        remaining = annualized_taxable
        for lower, upper, rate in self._federal_brackets:
            if remaining <= 0:
                break
            if upper is not None:
                bracket_amount = min(remaining, upper - lower)
            else:
                bracket_amount = remaining
            tax += bracket_amount * rate
            remaining -= bracket_amount
        return tax

    def process_employee(
        self, employee: Employee, pay_periods_per_year: int = 26
    ) -> PayrollResult:
        """Calculate payroll for one employee for one pay period."""
        gross = employee.gross_salary
        currency = gross.currency

        # Pre-tax deductions reduce taxable income
        pre_tax_total = Money.zero(currency)
        for v in employee.pre_tax_deductions.values():
            pre_tax_total = pre_tax_total + v
        taxable = gross - pre_tax_total

        # Annualize for federal tax bracket calculation
        annualized = taxable.amount * pay_periods_per_year
        annual_tax = self.calculate_federal_tax(annualized)
        federal_tax = Money(annual_tax / pay_periods_per_year, currency)

        # State tax (simplified flat rate)
        state_rate = Decimal("0.05")  # default 5%
        state_tax = Money(taxable.amount * state_rate, currency)

        # Social Security (check wage base)
        ss_taxable = gross.amount
        ytd_wages = employee.ytd_gross.amount
        if ytd_wages + ss_taxable > self.SOCIAL_SECURITY_WAGE_BASE:
            ss_taxable = max(Decimal("0"), self.SOCIAL_SECURITY_WAGE_BASE - ytd_wages)
        ss_employee = Money(ss_taxable * self.SOCIAL_SECURITY_RATE, currency)
        ss_employer = Money(ss_taxable * self.SOCIAL_SECURITY_RATE, currency)

        # Medicare (no wage base, but additional rate above threshold)
        medicare_rate = self.MEDICARE_RATE
        if ytd_wages + gross.amount > self.MEDICARE_ADDITIONAL_THRESHOLD:
            medicare_rate += self.MEDICARE_ADDITIONAL_RATE
        medicare_employee = Money(gross.amount * medicare_rate, currency)
        medicare_employer = Money(gross.amount * self.MEDICARE_RATE, currency)

        # Update YTD
        employee.ytd_gross = employee.ytd_gross + gross
        employee.ytd_federal_tax = employee.ytd_federal_tax + federal_tax
        employee.ytd_social_security = employee.ytd_social_security + ss_employee

        return PayrollResult(
            employee_id=employee.employee_id,
            employee_name=employee.name,
            gross_pay=gross,
            federal_tax=federal_tax,
            state_tax=state_tax,
            social_security_employee=ss_employee,
            social_security_employer=ss_employer,
            medicare_employee=medicare_employee,
            medicare_employer=medicare_employer,
            pre_tax_deductions=dict(employee.pre_tax_deductions),
            post_tax_deductions=dict(employee.post_tax_deductions),
        )

    def generate_journal_entry(
        self,
        results: list[PayrollResult],
        entry_id: str,
        pay_date: date,
        accounts: dict[str, str],
    ) -> JournalEntry:
        """Generate a journal entry for a payroll run.

        accounts dict should map:
          'salary_expense', 'payroll_tax_expense', 'cash',
          'federal_tax_payable', 'state_tax_payable',
          'ss_payable', 'medicare_payable'
        """
        entry = JournalEntry(
            entry_id=entry_id,
            entry_date=pay_date,
            description=f"Payroll for {pay_date}",
        )
        currency = self._currency

        total_gross = Money.zero(currency)
        total_net = Money.zero(currency)
        total_fed_tax = Money.zero(currency)
        total_state_tax = Money.zero(currency)
        total_ss = Money.zero(currency)
        total_medicare = Money.zero(currency)
        total_employer_ss = Money.zero(currency)
        total_employer_medicare = Money.zero(currency)

        for r in results:
            total_gross = total_gross + r.gross_pay
            total_net = total_net + r.net_pay
            total_fed_tax = total_fed_tax + r.federal_tax
            total_state_tax = total_state_tax + r.state_tax
            total_ss = total_ss + r.social_security_employee + r.social_security_employer
            total_medicare = total_medicare + r.medicare_employee + r.medicare_employer
            total_employer_ss = total_employer_ss + r.social_security_employer
            total_employer_medicare = total_employer_medicare + r.medicare_employer

        # Debits
        entry.add_debit(accounts.get('salary_expense', '5100'), total_gross)
        employer_taxes = total_employer_ss + total_employer_medicare
        if not employer_taxes.is_zero:
            entry.add_debit(accounts.get('payroll_tax_expense', '5200'), employer_taxes)

        # Credits
        entry.add_credit(accounts.get('cash', '1100'), total_net)
        if not total_fed_tax.is_zero:
            entry.add_credit(accounts.get('federal_tax_payable', '2300'), total_fed_tax)
        if not total_state_tax.is_zero:
            entry.add_credit(accounts.get('state_tax_payable', '2310'), total_state_tax)
        if not total_ss.is_zero:
            entry.add_credit(accounts.get('ss_payable', '2320'), total_ss)
        if not total_medicare.is_zero:
            entry.add_credit(accounts.get('medicare_payable', '2330'), total_medicare)

        return entry

    def process_batch(
        self, employees: list[Employee], pay_periods_per_year: int = 26,
    ) -> list[PayrollResult]:
        return [self.process_employee(e, pay_periods_per_year)
                for e in employees if e.is_active]
