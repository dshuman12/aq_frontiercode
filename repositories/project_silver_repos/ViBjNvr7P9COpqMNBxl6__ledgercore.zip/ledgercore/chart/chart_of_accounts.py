"""Chart of accounts — hierarchical account registry.

The chart of accounts is the master list of all accounts. It enforces:
1. Unique account numbers
2. Valid parent-child relationships (parent must exist)
3. Account type consistency (child must match parent type)
4. System account protection (cannot delete system accounts)

Hierarchical numbering: accounts are organized in a tree.
  1000 - Assets (parent)
    1100 - Current Assets
      1110 - Cash
      1120 - Accounts Receivable
    1200 - Fixed Assets
      1210 - Equipment

Account lookup by number, by name, by type, and by parent.
"""
from __future__ import annotations
from typing import Any, Iterator
from ledgercore.core.account import Account, AccountType, infer_account_type
from ledgercore.core.money import Currency


class ChartOfAccounts:
    """Manages the hierarchical chart of accounts."""

    def __init__(self, name: str = "Default", functional_currency: Currency | None = None):
        self.name = name
        self._accounts: dict[str, Account] = {}
        self._functional_currency = functional_currency

    @property
    def functional_currency(self) -> Currency | None:
        return self._functional_currency

    def add_account(self, account: Account) -> None:
        """Add an account. Validates uniqueness and parent relationship."""
        if account.number in self._accounts:
            raise ValueError(f"Account {account.number} already exists")
        if account.parent_number and account.parent_number not in self._accounts:
            raise ValueError(
                f"Parent account {account.parent_number} does not exist"
            )
        if account.parent_number:
            parent = self._accounts[account.parent_number]
            if not account.number.startswith(account.parent_number):
                raise ValueError(
                    f"Account {account.number} number must start with "
                    f"parent {account.parent_number}"
                )
        self._accounts[account.number] = account

    def get_account(self, number: str) -> Account | None:
        return self._accounts.get(number)

    def get_account_or_raise(self, number: str) -> Account:
        acct = self._accounts.get(number)
        if acct is None:
            raise KeyError(f"Account {number} not found")
        return acct

    def remove_account(self, number: str) -> bool:
        acct = self._accounts.get(number)
        if acct is None:
            return False
        if acct.is_system:
            raise ValueError(f"Cannot delete system account {number}")
        # Check for children
        if any(a.parent_number == number for a in self._accounts.values()):
            raise ValueError(f"Cannot delete account {number}: has children")
        del self._accounts[number]
        return True

    def get_children(self, parent_number: str) -> list[Account]:
        return [a for a in self._accounts.values()
                if a.parent_number == parent_number]

    def get_descendants(self, parent_number: str) -> list[Account]:
        """Get all descendants (children, grandchildren, etc.)."""
        result = []
        for a in self._accounts.values():
            if a.number.startswith(parent_number) and a.number != parent_number:
                result.append(a)
        return sorted(result, key=lambda a: a.number)

    def get_by_type(self, account_type: AccountType) -> list[Account]:
        return sorted(
            [a for a in self._accounts.values() if a.account_type == account_type],
            key=lambda a: a.number,
        )

    def get_balance_sheet_accounts(self) -> list[Account]:
        return sorted(
            [a for a in self._accounts.values() if a.is_balance_sheet],
            key=lambda a: a.number,
        )

    def get_income_statement_accounts(self) -> list[Account]:
        return sorted(
            [a for a in self._accounts.values() if a.is_income_statement],
            key=lambda a: a.number,
        )

    def search(self, query: str) -> list[Account]:
        """Search accounts by name or number (case-insensitive)."""
        q = query.lower()
        return [a for a in self._accounts.values()
                if q in a.name.lower() or q in a.number]

    def all_accounts(self) -> list[Account]:
        return sorted(self._accounts.values(), key=lambda a: a.number)

    @property
    def account_count(self) -> int:
        return len(self._accounts)

    def __contains__(self, number: str) -> bool:
        return number in self._accounts

    def __repr__(self) -> str:
        return f"ChartOfAccounts({self.name!r}, {self.account_count} accounts)"
