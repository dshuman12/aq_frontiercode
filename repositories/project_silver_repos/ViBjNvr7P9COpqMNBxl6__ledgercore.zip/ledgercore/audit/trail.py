"""Audit trail with immutability enforcement.

Every change to the ledger is recorded in the audit trail.
Entries cannot be deleted — only reversed.

The audit trail records:
- Who made the change
- When it was made
- What was changed
- The state before and after
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any
from enum import Enum


class AuditAction(Enum):
    ENTRY_CREATED = "entry_created"
    ENTRY_POSTED = "entry_posted"
    ENTRY_REVERSED = "entry_reversed"
    ACCOUNT_CREATED = "account_created"
    ACCOUNT_MODIFIED = "account_modified"
    PERIOD_CLOSED = "period_closed"
    RATE_SET = "rate_set"


@dataclass
class AuditRecord:
    """A single audit trail record."""
    record_id: str
    action: AuditAction
    timestamp: datetime = field(default_factory=datetime.now)
    user: str = ""
    entity_type: str = ""  # "entry", "account", "period", etc.
    entity_id: str = ""
    details: dict[str, Any] = field(default_factory=dict)
    before_state: dict[str, Any] = field(default_factory=dict)
    after_state: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "record_id": self.record_id,
            "action": self.action.value,
            "timestamp": self.timestamp.isoformat(),
            "user": self.user,
            "entity_type": self.entity_type,
            "entity_id": self.entity_id,
            "details": self.details,
        }


class AuditTrail:
    """Immutable audit trail."""

    def __init__(self):
        self._records: list[AuditRecord] = []
        self._next_id = 1

    def record(
        self,
        action: AuditAction,
        entity_type: str,
        entity_id: str,
        user: str = "",
        details: dict[str, Any] | None = None,
        before_state: dict[str, Any] | None = None,
        after_state: dict[str, Any] | None = None,
    ) -> AuditRecord:
        rec = AuditRecord(
            record_id=f"AUD-{self._next_id:06d}",
            action=action,
            entity_type=entity_type,
            entity_id=entity_id,
            user=user,
            details=details or {},
            before_state=before_state or {},
            after_state=after_state or {},
        )
        self._records.append(rec)
        self._next_id += 1
        return rec

    def get_records_for_entity(self, entity_id: str) -> list[AuditRecord]:
        return [r for r in self._records if r.entity_id == entity_id]

    def get_records_by_action(self, action: AuditAction) -> list[AuditRecord]:
        return [r for r in self._records if r.action == action]

    def get_records_in_range(
        self, start: datetime, end: datetime
    ) -> list[AuditRecord]:
        return [r for r in self._records if start <= r.timestamp <= end]

    @property
    def record_count(self) -> int:
        return len(self._records)

    @property
    def all_records(self) -> list[AuditRecord]:
        return list(self._records)
