"""Multi-currency posting engine with realized and unrealized FX gains/losses.

When a transaction involves a foreign currency, we must record it in BOTH
the foreign currency (for the sub-ledger) and the functional currency
(for the general ledger). The exchange rate at the transaction date
determines the functional currency amount.

Later, when the receivable/payable is settled at a DIFFERENT rate,
the difference is a REALIZED gain or loss.

Example (functional currency = USD):
  Jan 1: Invoice customer for EUR 1,000 at rate 1.10
    Dr. Accounts Receivable  $1,100 (EUR 1,000 * 1.10)
    Cr. Revenue              $1,100

  Mar 1: Receive EUR 1,000 payment at rate 1.15
    Dr. Cash                 $1,150 (EUR 1,000 * 1.15)
    Cr. Accounts Receivable  $1,100 (original amount)
    Cr. Realized FX Gain     $50   (the difference)

If the rate had been 1.05 instead:
    Dr. Cash                 $1,050
    Dr. Realized FX Loss     $50
    Cr. Accounts Receivable  $1,100

The tricky part: at month-end, UNSETTLED foreign balances are revalued
at the current rate. This creates UNREALIZED gains/losses that must be
REVERSED at the start of the next period (to avoid double-counting
when the actual settlement happens).

Month-end revaluation (Jan 31, rate = 1.12):
  Original AR: $1,100 (at 1.10)
  Revalued AR: $1,120 (EUR 1,000 * 1.12)
  Unrealized gain: $20
    Dr. Accounts Receivable  $20
    Cr. Unrealized FX Gain   $20

Feb 1 reversal (automatic):
    Dr. Unrealized FX Gain   $20
    Cr. Accounts Receivable  $20

This ensures that when actual settlement happens, the gain/loss is
calculated against the ORIGINAL rate, not the revalued rate.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal, ROUND_HALF_EVEN
from typing import Any
from ledgercore.core.money import Money, Currency
from ledgercore.core.entry import JournalEntry, EntryType
from ledgercore.currency.exchange import ExchangeRateStore, ExchangeRate


@dataclass
class ForeignCurrencyBalance:
    """Tracks a foreign currency balance and its functional equivalent."""
    account_number: str
    foreign_amount: Money
    functional_amount: Money
    original_rate: Decimal
    transaction_date: date
    entry_id: str
    is_settled: bool = False
    settlement_rate: Decimal | None = None
    settlement_date: date | None = None


class MultiCurrencyPostingEngine:
    """Post multi-currency transactions with FX tracking."""

    def __init__(
        self,
        functional_currency: Currency,
        rate_store: ExchangeRateStore,
        realized_gain_account: str = "4800",
        realized_loss_account: str = "5800",
        unrealized_gain_account: str = "4810",
        unrealized_loss_account: str = "5810",
    ):
        self._functional = functional_currency
        self._rates = rate_store
        self._realized_gain = realized_gain_account
        self._realized_loss = realized_loss_account
        self._unrealized_gain = unrealized_gain_account
        self._unrealized_loss = unrealized_loss_account
        self._open_balances: list[ForeignCurrencyBalance] = []
        self._revaluation_entries: list[JournalEntry] = []

    def record_foreign_transaction(
        self,
        entry_id: str,
        transaction_date: date,
        debit_account: str,
        credit_account: str,
        foreign_amount: Money,
        description: str = "",
        track_for_settlement: str = "",  # account to track for settlement
    ) -> JournalEntry:
        """Record a transaction in a foreign currency.

        Converts to functional currency at the transaction date rate.
        """
        rate = self._rates.get_rate(
            foreign_amount.currency, self._functional, transaction_date
        )
        if rate is None:
            raise ValueError(
                f"No exchange rate for {foreign_amount.currency.code}/"
                f"{self._functional.code} on {transaction_date}"
            )
        functional = rate.convert(foreign_amount)
        entry = JournalEntry(
            entry_id=entry_id,
            entry_date=transaction_date,
            description=description,
        )
        entry.add_debit(debit_account, functional, description)
        entry.add_credit(credit_account, functional, description)

        if track_for_settlement:
            self._open_balances.append(ForeignCurrencyBalance(
                account_number=track_for_settlement,
                foreign_amount=foreign_amount,
                functional_amount=functional,
                original_rate=rate.rate,
                transaction_date=transaction_date,
                entry_id=entry_id,
            ))
        return entry

    def record_settlement(
        self,
        entry_id: str,
        settlement_date: date,
        original_entry_id: str,
        cash_account: str,
        receivable_payable_account: str,
        is_receivable: bool = True,
    ) -> JournalEntry | None:
        """Record settlement of a foreign currency receivable/payable.

        Computes realized FX gain/loss.
        """
        balance = None
        for b in self._open_balances:
            if b.entry_id == original_entry_id and not b.is_settled:
                balance = b
                break
        if balance is None:
            return None

        # Get current rate for conversion
        rate = self._rates.get_rate(
            balance.foreign_amount.currency, self._functional, settlement_date
        )
        if rate is None:
            return None

        settlement_functional = rate.convert(balance.foreign_amount)
        original_functional = balance.functional_amount
        fx_diff = settlement_functional - original_functional

        entry = JournalEntry(
            entry_id=entry_id,
            entry_date=settlement_date,
            description=f"Settlement of {original_entry_id}",
        )

        if is_receivable:
            entry.add_debit(cash_account, settlement_functional)
            entry.add_credit(receivable_payable_account, original_functional)
            if fx_diff.is_positive:
                entry.add_credit(self._realized_gain, fx_diff)
            elif fx_diff.is_negative:
                entry.add_debit(self._realized_loss, abs(fx_diff))
        else:
            entry.add_debit(receivable_payable_account, original_functional)
            entry.add_credit(cash_account, settlement_functional)
            if fx_diff.is_positive:
                entry.add_debit(self._realized_loss, fx_diff)
            elif fx_diff.is_negative:
                entry.add_credit(self._realized_gain, abs(fx_diff))

        balance.is_settled = True
        balance.settlement_rate = rate.rate
        balance.settlement_date = settlement_date
        return entry

    def month_end_revaluation(
        self,
        revaluation_date: date,
        entry_id_generator: Any,
    ) -> list[JournalEntry]:
        """Revalue all open foreign currency balances at month-end.

        Creates unrealized FX gain/loss entries.
        Also creates auto-reversing entries for the next day.
        """
        entries = []
        for balance in self._open_balances:
            if balance.is_settled:
                continue
            rate = self._rates.get_rate(
                balance.foreign_amount.currency, self._functional, revaluation_date
            )
            if rate is None:
                continue

            revalued = rate.convert(balance.foreign_amount)
            diff = revalued - balance.functional_amount

            if diff.is_zero:
                continue

            # Revaluation entry
            reval_entry = JournalEntry(
                entry_id=entry_id_generator(),
                entry_date=revaluation_date,
                description=f"FX revaluation: {balance.account_number} ({balance.entry_id})",
                entry_type=EntryType.ADJUSTING,
            )
            if diff.is_positive:
                reval_entry.add_debit(balance.account_number, diff)
                reval_entry.add_credit(self._unrealized_gain, diff)
            else:
                reval_entry.add_debit(self._unrealized_loss, abs(diff))
                reval_entry.add_credit(balance.account_number, abs(diff))
            entries.append(reval_entry)

            # Auto-reversing entry (next day)
            from datetime import timedelta
            reversal_date = revaluation_date + timedelta(days=1)
            reversal = reval_entry.create_reversal(
                entry_id_generator(), reversal_date
            )
            entries.append(reversal)

        self._revaluation_entries.extend(entries)
        return entries

    @property
    def open_balance_count(self) -> int:
        return sum(1 for b in self._open_balances if not b.is_settled)

    def get_open_balances(self) -> list[ForeignCurrencyBalance]:
        return [b for b in self._open_balances if not b.is_settled]
