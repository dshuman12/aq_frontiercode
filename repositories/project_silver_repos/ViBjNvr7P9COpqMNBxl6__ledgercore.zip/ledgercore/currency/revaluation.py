"""Foreign currency revaluation for unrealized gains/losses.

At period end, foreign-currency-denominated balances must be
revalued at the current exchange rate. The difference between
the recorded amount and the revalued amount is an unrealized
gain or loss.

Types of FX gains/losses:
1. Transaction gain/loss (realized): when a foreign-currency
   receivable/payable is settled at a different rate than recorded.
   Goes to income statement.

2. Translation gain/loss (unrealized): period-end revaluation of
   open foreign-currency balances.
   Goes to income statement (monetary items) or equity (non-monetary, IFRS).

Revaluation journal entries:
  If the functional currency equivalent INCREASED:
    Dr. Foreign Currency Account (increase asset)
    Cr. Unrealized FX Gain (income)

  If the functional currency equivalent DECREASED:
    Dr. Unrealized FX Loss (income)
    Cr. Foreign Currency Account (decrease asset)

The tricky part: revaluation must be REVERSED at the start of
the next period, so that when the actual transaction settles,
the gain/loss is calculated against the original rate, not the
revalued rate. This avoids double-counting.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from typing import Any
from ledgercore.core.money import Money, Currency
from ledgercore.core.entry import JournalEntry, EntryType
from ledgercore.currency.exchange import ExchangeRateStore


@dataclass
class RevaluationResult:
    """Result of revaluing a single account."""
    account_number: str
    original_balance: Money
    revalued_balance: Money
    gain_loss: Money  # positive = gain, negative = loss
    exchange_rate_used: Decimal


class CurrencyRevaluator:
    """Revalue foreign-currency balances at period end."""

    def __init__(
        self,
        rate_store: ExchangeRateStore,
        functional_currency: Currency,
        fx_gain_account: str = "4800",  # unrealized FX gain
        fx_loss_account: str = "5800",  # unrealized FX loss
    ):
        self._rates = rate_store
        self._functional = functional_currency
        self._gain_account = fx_gain_account
        self._loss_account = fx_loss_account

    def revalue_account(
        self,
        account_number: str,
        foreign_balance: Money,
        recorded_functional: Money,
        revaluation_date: date,
    ) -> RevaluationResult | None:
        """Revalue a single account's foreign balance.

        Args:
            foreign_balance: balance in foreign currency
            recorded_functional: what we have recorded in functional currency
            revaluation_date: date for the new exchange rate
        """
        if foreign_balance.currency == self._functional:
            return None  # no revaluation needed for functional currency

        new_rate = self._rates.get_rate(
            foreign_balance.currency, self._functional, revaluation_date
        )
        if new_rate is None:
            return None

        revalued = new_rate.convert(foreign_balance)
        gain_loss = revalued - recorded_functional

        return RevaluationResult(
            account_number=account_number,
            original_balance=recorded_functional,
            revalued_balance=revalued,
            gain_loss=gain_loss,
            exchange_rate_used=new_rate.rate,
        )

    def generate_revaluation_entries(
        self,
        results: list[RevaluationResult],
        entry_id_generator: Any,
        revaluation_date: date,
    ) -> list[JournalEntry]:
        """Generate journal entries for all revaluation results."""
        entries = []

        for result in results:
            if result.gain_loss.is_zero:
                continue

            entry = JournalEntry(
                entry_id=entry_id_generator(),
                entry_date=revaluation_date,
                description=f"FX revaluation: {result.account_number}",
                entry_type=EntryType.ADJUSTING,
            )

            if result.gain_loss.is_positive:
                # Gain: increase account, credit gain
                entry.add_debit(result.account_number, result.gain_loss)
                entry.add_credit(self._gain_account, result.gain_loss)
            else:
                # Loss: decrease account, debit loss
                loss_amount = abs(result.gain_loss)
                entry.add_debit(self._loss_account, loss_amount)
                entry.add_credit(result.account_number, loss_amount)

            entries.append(entry)

        return entries

    def generate_reversal_entries(
        self,
        original_entries: list[JournalEntry],
        entry_id_generator: Any,
        reversal_date: date,
    ) -> list[JournalEntry]:
        """Generate reversing entries for the revaluation.

        These are posted on the first day of the next period.
        """
        reversals = []
        for orig in original_entries:
            reversal = orig.create_reversal(entry_id_generator(), reversal_date)
            reversals.append(reversal)
        return reversals
