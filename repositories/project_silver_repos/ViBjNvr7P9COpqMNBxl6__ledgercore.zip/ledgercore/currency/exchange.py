"""Exchange rate management and currency conversion.

Multi-currency accounting adds significant complexity:

1. Each transaction may have a different exchange rate
2. Rates are directional: USD/EUR rate != EUR/USD rate (due to spread)
3. Triangulation: if we know USD/EUR and EUR/GBP, we can derive USD/GBP
4. Rate validity: rates are date-specific
5. Realized vs unrealized gains/losses:
   - Realized: when a foreign-currency receivable/payable is settled
   - Unrealized: mark-to-market revaluation of open foreign balances

Exchange rate storage:
  We store rates as (from_currency, to_currency, date) -> rate
  where rate means "1 unit of from_currency = rate units of to_currency"
  
  Example: USD/EUR = 0.85 means 1 USD = 0.85 EUR

Triangulation must detect circular conversions to avoid infinite loops.
"""
from __future__ import annotations
from dataclasses import dataclass
from datetime import date
from decimal import Decimal
from typing import Any
from ledgercore.core.money import Money, Currency


@dataclass(frozen=True)
class ExchangeRate:
    """An exchange rate between two currencies on a specific date."""
    from_currency: Currency
    to_currency: Currency
    rate: Decimal
    rate_date: date
    source: str = ""  # where this rate came from

    def convert(self, amount: Money) -> Money:
        """Convert a Money amount using this rate."""
        if amount.currency != self.from_currency:
            raise ValueError(
                f"Cannot convert {amount.currency.code} using "
                f"{self.from_currency.code}/{self.to_currency.code} rate"
            )
        return Money(amount.amount * self.rate, self.to_currency)

    @property
    def inverse(self) -> ExchangeRate:
        """Get the inverse rate (to -> from)."""
        if self.rate == 0:
            raise ZeroDivisionError("Cannot invert zero rate")
        return ExchangeRate(
            from_currency=self.to_currency,
            to_currency=self.from_currency,
            rate=Decimal("1") / self.rate,
            rate_date=self.rate_date,
            source=f"inverse of {self.source}",
        )


class ExchangeRateStore:
    """Stores and retrieves exchange rates with date lookup."""

    def __init__(self):
        # Key: (from_code, to_code, date)
        self._rates: dict[tuple[str, str, date], ExchangeRate] = {}

    def set_rate(self, rate: ExchangeRate) -> None:
        key = (rate.from_currency.code, rate.to_currency.code, rate.rate_date)
        self._rates[key] = rate

    def get_rate(
        self,
        from_currency: Currency,
        to_currency: Currency,
        rate_date: date,
    ) -> ExchangeRate | None:
        """Get a rate for a specific date.

        If exact date not found, uses the most recent rate before that date.
        """
        # Try exact date
        key = (from_currency.code, to_currency.code, rate_date)
        if key in self._rates:
            return self._rates[key]

        # Try most recent rate before the date
        best: ExchangeRate | None = None
        best_date: date | None = None
        for (fc, tc, rd), rate in self._rates.items():
            if fc == from_currency.code and tc == to_currency.code and rd <= rate_date:
                if best_date is None or rd > best_date:
                    best = rate
                    best_date = rd
        return best

    def convert(
        self,
        amount: Money,
        to_currency: Currency,
        rate_date: date,
        allow_triangulation: bool = True,
    ) -> Money | None:
        """Convert money to another currency.

        Tries direct rate first, then inverse, then triangulation.
        Returns None if no conversion path found.
        """
        if amount.currency == to_currency:
            return amount

        # Direct rate
        rate = self.get_rate(amount.currency, to_currency, rate_date)
        if rate:
            return rate.convert(amount)

        # Inverse rate
        inverse_rate = self.get_rate(to_currency, amount.currency, rate_date)
        if inverse_rate:
            return inverse_rate.inverse.convert(amount)

        # Triangulation (try all currencies as intermediaries)
        if allow_triangulation:
            return self._triangulate(amount, to_currency, rate_date, visited=set())

        return None

    def _triangulate(
        self,
        amount: Money,
        target: Currency,
        rate_date: date,
        visited: set[str],
    ) -> Money | None:
        """Find a conversion path through intermediate currencies.

        Uses BFS with cycle detection to find the shortest path.
        """
        if amount.currency.code in visited:
            return None
        visited.add(amount.currency.code)

        # Find all currencies we can convert FROM the source
        reachable: list[tuple[Currency, ExchangeRate]] = []
        for (fc, tc, rd), rate in self._rates.items():
            if fc == amount.currency.code and rd <= rate_date and tc not in visited:
                reachable.append((rate.to_currency, rate))
            if tc == amount.currency.code and rd <= rate_date and fc not in visited:
                reachable.append((rate.from_currency, rate.inverse))

        for intermediate_currency, rate in reachable:
            intermediate_amount = rate.convert(amount)
            if intermediate_currency == target:
                return intermediate_amount
            # Try converting from intermediate to target
            result = self._triangulate(intermediate_amount, target, rate_date, visited)
            if result is not None:
                return result

        return None

    def get_all_rates_for_date(self, rate_date: date) -> list[ExchangeRate]:
        return [r for r in self._rates.values() if r.rate_date == rate_date]

    @property
    def rate_count(self) -> int:
        return len(self._rates)
