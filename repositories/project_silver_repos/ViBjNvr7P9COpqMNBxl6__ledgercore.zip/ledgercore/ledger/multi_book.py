"""Multi-book accounting for parallel reporting.

Some organizations maintain multiple sets of books simultaneously:

1. GAAP book (US Generally Accepted Accounting Principles)
2. IFRS book (International Financial Reporting Standards)
3. Tax book (follows tax law, not accounting standards)
4. Management book (internal reporting, may include non-GAAP adjustments)

Differences between books:
- Depreciation methods may differ (GAAP: straight-line, Tax: MACRS)
- Revenue recognition timing may differ
- Lease accounting differs (GAAP: ASC 842, IFRS: IFRS 16)
- Inventory costing (LIFO allowed under GAAP, not IFRS)
- Some transactions only exist in certain books (tax adjustments)

Implementation:
Each book has its own GeneralLedger sharing the same ChartOfAccounts.
Journal entries are posted to specific books. Some entries are "common"
(posted to all books), while adjustment entries only go to specific books.

The complexity: when querying balances, you must specify WHICH book.
Reports can show side-by-side comparisons between books.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from typing import Any
from ledgercore.core.money import Money, Currency
from ledgercore.core.entry import JournalEntry, EntryStatus
from ledgercore.chart.chart_of_accounts import ChartOfAccounts
from ledgercore.ledger.general_ledger import GeneralLedger


class BookType:
    GAAP = "gaap"
    IFRS = "ifrs"
    TAX = "tax"
    MANAGEMENT = "management"
    STATUTORY = "statutory"


@dataclass
class BookConfig:
    """Configuration for a single book."""
    book_id: str
    name: str
    book_type: str = BookType.GAAP
    description: str = ""
    is_primary: bool = False


class MultiBookLedger:
    """Manages multiple parallel sets of books."""

    def __init__(self, chart: ChartOfAccounts):
        self._chart = chart
        self._books: dict[str, GeneralLedger] = {}
        self._configs: dict[str, BookConfig] = {}
        self._common_entries: set[str] = set()  # entry IDs posted to all books

    def add_book(self, config: BookConfig) -> GeneralLedger:
        """Add a new book. Returns the ledger for the book."""
        if config.book_id in self._books:
            raise ValueError(f"Book {config.book_id} already exists")
        ledger = GeneralLedger(self._chart)
        self._books[config.book_id] = ledger
        self._configs[config.book_id] = config
        return ledger

    def get_book(self, book_id: str) -> GeneralLedger | None:
        return self._books.get(book_id)

    def get_config(self, book_id: str) -> BookConfig | None:
        return self._configs.get(book_id)

    def post_to_book(self, book_id: str, entry: JournalEntry) -> list[str]:
        """Post an entry to a specific book only."""
        ledger = self._books.get(book_id)
        if ledger is None:
            return [f"Book {book_id} not found"]
        return ledger.post_entry(entry)

    def post_to_all_books(self, entry: JournalEntry) -> dict[str, list[str]]:
        """Post an entry to ALL books (common entry)."""
        results = {}
        for book_id, ledger in self._books.items():
            # Create a copy of the entry with unique ID per book
            book_entry = JournalEntry(
                entry_id=f"{entry.entry_id}_{book_id}",
                entry_date=entry.entry_date,
                description=entry.description,
                reference=entry.reference,
                entry_type=entry.entry_type,
            )
            for line in entry.lines:
                if line.is_debit:
                    book_entry.add_debit(line.account_number, line.debit, line.description)
                elif line.is_credit:
                    book_entry.add_credit(line.account_number, line.credit, line.description)
            errors = ledger.post_entry(book_entry)
            if errors:
                results[book_id] = errors
        self._common_entries.add(entry.entry_id)
        return results

    def get_balance(
        self, book_id: str, account_number: str, as_of: date | None = None,
    ) -> Money | None:
        """Get account balance from a specific book."""
        ledger = self._books.get(book_id)
        if ledger is None:
            return None
        return ledger.get_account_balance(account_number, as_of)

    def compare_balances(
        self, account_number: str, as_of: date | None = None,
    ) -> dict[str, Money]:
        """Get the same account's balance across all books."""
        result = {}
        for book_id, ledger in self._books.items():
            try:
                result[book_id] = ledger.get_account_balance(account_number, as_of)
            except KeyError:
                pass
        return result

    def book_differences(
        self, book_a: str, book_b: str, as_of: date | None = None,
    ) -> list[tuple[str, Money, Money, Money]]:
        """Find accounts where two books differ.

        Returns: [(account_number, book_a_balance, book_b_balance, difference)]
        """
        ledger_a = self._books.get(book_a)
        ledger_b = self._books.get(book_b)
        if ledger_a is None or ledger_b is None:
            return []

        diffs = []
        for acct in self._chart.all_accounts():
            bal_a = ledger_a.get_account_balance(acct.number, as_of)
            bal_b = ledger_b.get_account_balance(acct.number, as_of)
            if bal_a != bal_b:
                diff = bal_a - bal_b
                diffs.append((acct.number, bal_a, bal_b, diff))
        return diffs

    @property
    def book_count(self) -> int:
        return len(self._books)

    @property
    def book_ids(self) -> list[str]:
        return list(self._books.keys())
