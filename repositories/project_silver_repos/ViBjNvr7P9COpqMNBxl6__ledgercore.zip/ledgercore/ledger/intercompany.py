"""Intercompany transaction management and elimination.

When a group of companies transacts with each other, those transactions
must be eliminated in consolidated financial statements to avoid
double-counting.

Example: Parent sells inventory to Subsidiary for $100.
- Parent records $100 revenue
- Subsidiary records $100 expense
- In consolidation: eliminate $100 from both sides (net effect = 0)

Intercompany balances: if Parent owes Subsidiary $50, that shows as
a receivable for Sub and a payable for Parent. In consolidation,
both are eliminated.

The tricky part: partial ownership. If Parent owns 80% of Sub,
the elimination is only for the parent's share. The remaining 20%
is "non-controlling interest" (NCI).

Also tricky: unrealized intercompany profit. If Parent sells inventory
to Sub at a markup, and Sub hasn't sold it to a third party yet,
the profit is unrealized and must be eliminated.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from decimal import Decimal
from datetime import date
from typing import Any
from ledgercore.core.money import Money, Currency
from ledgercore.core.entry import JournalEntry, EntryType


@dataclass
class CompanyRelationship:
    """Ownership relationship between companies."""
    parent_id: str
    subsidiary_id: str
    ownership_pct: Decimal  # e.g., Decimal("0.80") for 80%
    effective_date: date


@dataclass
class IntercompanyTransaction:
    """An intercompany transaction to be eliminated."""
    transaction_id: str
    selling_company: str
    buying_company: str
    amount: Money
    transaction_date: date
    description: str = ""
    is_eliminated: bool = False
    # For unrealized profit
    profit_margin: Decimal = Decimal("0")
    inventory_sold_externally: bool = False


class IntercompanyManager:
    """Track and eliminate intercompany transactions."""

    def __init__(self):
        self._relationships: list[CompanyRelationship] = []
        self._transactions: list[IntercompanyTransaction] = []

    def add_relationship(self, rel: CompanyRelationship) -> None:
        self._relationships.append(rel)

    def get_ownership(self, parent_id: str, sub_id: str) -> Decimal:
        for rel in self._relationships:
            if rel.parent_id == parent_id and rel.subsidiary_id == sub_id:
                return rel.ownership_pct
        return Decimal("0")

    def add_transaction(self, txn: IntercompanyTransaction) -> None:
        self._transactions.append(txn)

    def generate_elimination_entries(
        self,
        period_end: date,
        revenue_account: str,
        expense_account: str,
        receivable_account: str,
        payable_account: str,
        entry_id_generator: Any,
    ) -> list[JournalEntry]:
        """Generate elimination entries for consolidated reporting.

        Creates entries that cancel out intercompany revenue/expense
        and receivable/payable balances.
        """
        entries = []

        for txn in self._transactions:
            if txn.is_eliminated:
                continue
            if txn.transaction_date > period_end:
                continue

            # Revenue/expense elimination
            entry = JournalEntry(
                entry_id=entry_id_generator(),
                entry_date=period_end,
                description=f"IC elimination: {txn.description}",
                entry_type=EntryType.ADJUSTING,
            )
            entry.add_debit(revenue_account, txn.amount)
            entry.add_credit(expense_account, txn.amount)
            entries.append(entry)

            # Receivable/payable elimination
            balance_entry = JournalEntry(
                entry_id=entry_id_generator(),
                entry_date=period_end,
                description=f"IC balance elimination: {txn.description}",
                entry_type=EntryType.ADJUSTING,
            )
            balance_entry.add_debit(payable_account, txn.amount)
            balance_entry.add_credit(receivable_account, txn.amount)
            entries.append(balance_entry)

            # Unrealized profit elimination
            if txn.profit_margin > 0 and not txn.inventory_sold_externally:
                profit = txn.amount * txn.profit_margin
                profit_entry = JournalEntry(
                    entry_id=entry_id_generator(),
                    entry_date=period_end,
                    description=f"IC unrealized profit elimination: {txn.description}",
                    entry_type=EntryType.ADJUSTING,
                )
                profit_entry.add_debit(revenue_account, profit)
                profit_entry.add_credit("1500", profit)  # inventory adjustment
                entries.append(profit_entry)

            txn.is_eliminated = True

        return entries

    @property
    def transaction_count(self) -> int:
        return len(self._transactions)

    @property
    def uneliminated_count(self) -> int:
        return sum(1 for t in self._transactions if not t.is_eliminated)
