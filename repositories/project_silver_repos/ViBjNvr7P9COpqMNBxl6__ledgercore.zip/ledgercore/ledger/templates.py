"""Journal entry templates for recurring and standard transactions.

Templates allow defining reusable journal entry patterns:
- Monthly rent payment
- Payroll processing
- Depreciation recording
- Loan payments
- Recurring invoices

Templates support:
1. Fixed amounts (exact amount each time)
2. Variable amounts (user supplies amount at creation time)
3. Calculated amounts (formula-based, e.g., percentage of another account's balance)
4. Multi-line templates (complex entries with multiple debits/credits)
5. Auto-scheduling (generate entries on specific dates)

Template variables:
  {{AMOUNT}} - replaced with actual amount at generation time
  {{DATE}} - replaced with entry date
  {{PERIOD}} - replaced with fiscal period identifier
  {{REFERENCE}} - replaced with external reference number
  {{COUNTER}} - auto-incrementing counter

The key complexity: when a template has variable amounts, the other
lines must be adjusted to maintain the double-entry balance. If the
template has 3 debit lines and 1 credit, and the credit is variable,
we can't just change the credit — the debits must be proportionally
scaled or one debit must absorb the difference.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date, timedelta
from decimal import Decimal
from typing import Any, Callable
from ledgercore.core.money import Money, Currency
from ledgercore.core.entry import JournalEntry, EntryType


class ScheduleFrequency:
    DAILY = "daily"
    WEEKLY = "weekly"
    BIWEEKLY = "biweekly"
    MONTHLY = "monthly"
    QUARTERLY = "quarterly"
    SEMI_ANNUAL = "semi_annual"
    ANNUAL = "annual"


@dataclass
class TemplateLine:
    """A line in a journal entry template."""
    account_number: str
    is_debit: bool = True
    fixed_amount: Money | None = None  # None = variable
    proportion: Decimal = Decimal("0")  # for proportional calculation
    description_template: str = ""

    @property
    def is_variable(self) -> bool:
        return self.fixed_amount is None and self.proportion == 0

    @property
    def is_proportional(self) -> bool:
        return self.proportion > 0


@dataclass
class JournalTemplate:
    """A reusable journal entry template."""
    template_id: str
    name: str
    description: str = ""
    lines: list[TemplateLine] = field(default_factory=list)
    entry_type: EntryType = EntryType.REGULAR
    schedule_frequency: str = ""
    schedule_start: date | None = None
    schedule_end: date | None = None
    is_active: bool = True
    last_generated: date | None = None
    counter: int = 0
    tags: set[str] = field(default_factory=set)

    def generate_entry(
        self,
        entry_id: str,
        entry_date: date,
        variable_amount: Money | None = None,
        reference: str = "",
        description_override: str = "",
    ) -> JournalEntry:
        """Generate a journal entry from this template.

        If the template has variable amounts, variable_amount must be provided.
        Proportional lines are calculated as a fraction of the variable amount.
        The balancing line absorbs any difference to maintain double-entry.
        """
        self.counter += 1
        entry = JournalEntry(
            entry_id=entry_id,
            entry_date=entry_date,
            description=description_override or self._expand_description(entry_date),
            reference=reference,
            entry_type=self.entry_type,
        )

        total_debit = Decimal("0")
        total_credit = Decimal("0")
        variable_line_idx = -1
        currency = None

        for i, tl in enumerate(self.lines):
            if tl.fixed_amount is not None:
                amount = tl.fixed_amount
                currency = currency or amount.currency
            elif tl.is_proportional and variable_amount is not None:
                amount = variable_amount * tl.proportion
                currency = currency or amount.currency
            elif variable_amount is not None:
                amount = variable_amount
                currency = currency or amount.currency
                variable_line_idx = i
            else:
                continue

            desc = tl.description_template or ""
            if tl.is_debit:
                entry.add_debit(tl.account_number, amount, desc)
                total_debit += amount.amount
            else:
                entry.add_credit(tl.account_number, amount, desc)
                total_credit += amount.amount

        # If unbalanced due to proportional rounding, adjust last variable line
        if currency and total_debit != total_credit:
            diff = abs(total_debit - total_credit)
            if diff > 0 and entry.lines:
                # Add balancing amount to the last line
                if total_debit > total_credit:
                    entry.add_credit(
                        self.lines[-1].account_number if not self.lines[-1].is_debit
                        else self.lines[0].account_number,
                        Money(diff, currency),
                    )
                else:
                    entry.add_debit(
                        self.lines[-1].account_number if self.lines[-1].is_debit
                        else self.lines[0].account_number,
                        Money(diff, currency),
                    )

        self.last_generated = entry_date
        return entry

    def _expand_description(self, entry_date: date) -> str:
        desc = self.description
        desc = desc.replace("{{DATE}}", entry_date.isoformat())
        desc = desc.replace("{{COUNTER}}", str(self.counter))
        return desc

    def get_next_schedule_date(self) -> date | None:
        """Calculate the next scheduled date based on frequency."""
        if not self.schedule_frequency or not self.schedule_start:
            return None
        base = self.last_generated or self.schedule_start
        if self.schedule_end and base >= self.schedule_end:
            return None
        freq = self.schedule_frequency
        if freq == ScheduleFrequency.DAILY:
            return base + timedelta(days=1)
        if freq == ScheduleFrequency.WEEKLY:
            return base + timedelta(weeks=1)
        if freq == ScheduleFrequency.BIWEEKLY:
            return base + timedelta(weeks=2)
        if freq == ScheduleFrequency.MONTHLY:
            month = base.month + 1
            year = base.year
            if month > 12:
                month = 1
                year += 1
            day = min(base.day, 28)
            return date(year, month, day)
        if freq == ScheduleFrequency.QUARTERLY:
            month = base.month + 3
            year = base.year
            while month > 12:
                month -= 12
                year += 1
            return date(year, month, min(base.day, 28))
        if freq == ScheduleFrequency.ANNUAL:
            return date(base.year + 1, base.month, base.day)
        return None


class TemplateManager:
    """Manage journal entry templates."""

    def __init__(self):
        self._templates: dict[str, JournalTemplate] = {}

    def add_template(self, template: JournalTemplate) -> None:
        self._templates[template.template_id] = template

    def get_template(self, template_id: str) -> JournalTemplate | None:
        return self._templates.get(template_id)

    def remove_template(self, template_id: str) -> bool:
        return self._templates.pop(template_id, None) is not None

    def get_due_templates(self, as_of: date) -> list[JournalTemplate]:
        """Get templates that are due for generation by the given date."""
        due = []
        for t in self._templates.values():
            if not t.is_active:
                continue
            next_date = t.get_next_schedule_date()
            if next_date and next_date <= as_of:
                due.append(t)
        return due

    def generate_all_due(
        self,
        as_of: date,
        entry_id_generator: Callable[[], str],
        variable_amounts: dict[str, Money] | None = None,
    ) -> list[JournalEntry]:
        """Generate entries for all due templates."""
        entries = []
        amounts = variable_amounts or {}
        for t in self.get_due_templates(as_of):
            next_date = t.get_next_schedule_date()
            if next_date is None:
                continue
            var_amt = amounts.get(t.template_id)
            entry = t.generate_entry(entry_id_generator(), next_date, var_amt)
            entries.append(entry)
        return entries

    @property
    def template_count(self) -> int:
        return len(self._templates)

    def all_templates(self) -> list[JournalTemplate]:
        return list(self._templates.values())
