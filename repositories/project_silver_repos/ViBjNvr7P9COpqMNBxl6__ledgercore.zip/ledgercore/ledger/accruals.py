"""Accrual and deferral management.

Accruals and deferrals are adjusting entries that align revenue and
expenses with the period they relate to (matching principle).

Types:
1. Accrued Revenue: revenue earned but not yet billed/collected
   Debit: Accrued Revenue (Asset)
   Credit: Revenue

2. Accrued Expense: expense incurred but not yet paid
   Debit: Expense
   Credit: Accrued Expense (Liability)

3. Deferred Revenue (Unearned Revenue): cash received before earning
   Initially: Debit Cash, Credit Unearned Revenue (Liability)
   Adjusting: Debit Unearned Revenue, Credit Revenue

4. Prepaid Expense: cash paid before using
   Initially: Debit Prepaid Expense (Asset), Credit Cash
   Adjusting: Debit Expense, Credit Prepaid Expense

Auto-reversing entries: some accruals are set to automatically create
a reversing entry on the first day of the next period. This simplifies
recording the actual transaction when it occurs.

Recurring entries: some accruals repeat every period (e.g., monthly
rent accrual). The engine can generate entries from templates.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date, timedelta
from typing import Any
from ledgercore.core.money import Money, Currency
from ledgercore.core.entry import JournalEntry, EntryType


class AccrualType:
    ACCRUED_REVENUE = "accrued_revenue"
    ACCRUED_EXPENSE = "accrued_expense"
    DEFERRED_REVENUE = "deferred_revenue"
    PREPAID_EXPENSE = "prepaid_expense"


@dataclass
class AccrualTemplate:
    """Template for generating recurring accrual entries."""
    template_id: str
    accrual_type: str
    description: str
    debit_account: str
    credit_account: str
    amount: Money
    frequency: str = "monthly"  # monthly, quarterly, annually
    auto_reverse: bool = False
    start_date: date | None = None
    end_date: date | None = None
    is_active: bool = True
    last_generated: date | None = None


class AccrualEngine:
    """Manage accruals, deferrals, and recurring entries."""

    def __init__(self):
        self._templates: dict[str, AccrualTemplate] = {}
        self._reversals_pending: list[tuple[str, date, JournalEntry]] = []

    def add_template(self, template: AccrualTemplate) -> None:
        self._templates[template.template_id] = template

    def get_template(self, template_id: str) -> AccrualTemplate | None:
        return self._templates.get(template_id)

    def generate_entries(
        self,
        period_end: date,
        entry_id_generator: Any,
    ) -> list[JournalEntry]:
        """Generate accrual entries for a period.

        For each active template, creates an adjusting entry dated
        at the period end.
        """
        entries = []
        for template in self._templates.values():
            if not template.is_active:
                continue
            if template.start_date and period_end < template.start_date:
                continue
            if template.end_date and period_end > template.end_date:
                continue
            # Check if already generated for this period
            if template.last_generated and template.last_generated >= period_end:
                continue

            entry = JournalEntry(
                entry_id=entry_id_generator(),
                entry_date=period_end,
                description=f"Accrual: {template.description}",
                entry_type=EntryType.ADJUSTING,
            )
            entry.add_debit(template.debit_account, template.amount)
            entry.add_credit(template.credit_account, template.amount)
            entries.append(entry)
            template.last_generated = period_end

            # Schedule reversal if auto-reverse
            if template.auto_reverse:
                reversal_date = period_end + timedelta(days=1)
                reversal = entry.create_reversal(
                    entry_id_generator(), reversal_date
                )
                self._reversals_pending.append(
                    (template.template_id, reversal_date, reversal)
                )

        return entries

    def get_pending_reversals(self, as_of: date) -> list[JournalEntry]:
        """Get reversing entries that should be posted by the given date."""
        due = []
        remaining = []
        for tid, rev_date, reversal in self._reversals_pending:
            if rev_date <= as_of:
                due.append(reversal)
            else:
                remaining.append((tid, rev_date, reversal))
        self._reversals_pending = remaining
        return due

    def remove_template(self, template_id: str) -> bool:
        return self._templates.pop(template_id, None) is not None

    @property
    def template_count(self) -> int:
        return len(self._templates)

    @property
    def pending_reversal_count(self) -> int:
        return len(self._reversals_pending)
