"""General ledger — the core accounting record.

The general ledger records all posted transactions. Each account
has a list of ledger entries (postings), and the balance is derived
from summing all entries.

Balance calculation for an account:
  If debit-normal: balance = sum(debits) - sum(credits)
  If credit-normal: balance = sum(credits) - sum(debits)

A POSITIVE balance means the account is in its "normal" state.
A NEGATIVE balance means the account is in the opposite state
(which is unusual but valid — e.g., a bank account overdraft
is an Asset with a credit balance).

Trial balance: sum of all debit balances must equal sum of all
credit balances. This is a fundamental check that the ledger is
internally consistent.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from typing import Any
from ledgercore.core.money import Money, Currency
from ledgercore.core.account import Account, NormalBalance, get_normal_balance
from ledgercore.core.entry import JournalEntry, EntryLine, EntryStatus
from ledgercore.chart.chart_of_accounts import ChartOfAccounts


@dataclass
class LedgerPosting:
    """A single posting in the ledger (one side of a journal entry line)."""
    entry_id: str
    entry_date: date
    account_number: str
    debit: Money | None = None
    credit: Money | None = None
    description: str = ""
    balance_after: Money | None = None  # running balance after this posting


class GeneralLedger:
    """The general ledger — stores all postings and computes balances."""

    def __init__(self, chart: ChartOfAccounts):
        self._chart = chart
        self._postings: dict[str, list[LedgerPosting]] = {}  # account -> postings
        self._entries: dict[str, JournalEntry] = {}  # entry_id -> entry

    @property
    def chart(self) -> ChartOfAccounts:
        return self._chart

    def post_entry(self, entry: JournalEntry) -> list[str]:
        """Post a journal entry to the ledger.

        Validates the entry, creates ledger postings, and updates
        running balances.

        Returns list of errors (empty on success).
        """
        errors = entry.validate()
        if errors:
            return errors

        if entry.entry_id in self._entries:
            return [f"Entry {entry.entry_id} already posted"]

        # Verify all accounts exist
        for line in entry.lines:
            if line.account_number not in self._chart:
                errors.append(f"Account {line.account_number} not in chart of accounts")
        if errors:
            return errors

        # Create postings
        for line in entry.lines:
            posting = LedgerPosting(
                entry_id=entry.entry_id,
                entry_date=entry.entry_date,
                account_number=line.account_number,
                debit=line.debit if line.is_debit else None,
                credit=line.credit if line.is_credit else None,
                description=line.description or entry.description,
            )
            if line.account_number not in self._postings:
                self._postings[line.account_number] = []
            self._postings[line.account_number].append(posting)

        entry.status = EntryStatus.POSTED
        entry.posted_at = entry.created_at
        self._entries[entry.entry_id] = entry
        return []

    def get_account_balance(self, account_number: str, as_of: date | None = None,
                            currency: Currency | None = None) -> Money:
        """Get the balance of an account.

        The balance sign convention:
        - Debit-normal accounts: balance = sum(debits) - sum(credits)
        - Credit-normal accounts: balance = sum(credits) - sum(debits)

        A positive balance means the account is in its normal state.
        """
        account = self._chart.get_account_or_raise(account_number)
        postings = self._postings.get(account_number, [])
        curr = currency or account.currency

        total_debit = Decimal("0")
        total_credit = Decimal("0")

        for p in postings:
            if as_of and p.entry_date > as_of:
                continue
            if p.debit and p.debit.currency == curr:
                total_debit += p.debit.amount
            if p.credit and p.credit.currency == curr:
                total_credit += p.credit.amount

        if account.normal_balance == NormalBalance.DEBIT:
            return Money(total_debit - total_credit, curr)
        else:
            return Money(total_credit - total_debit, curr)

    def get_account_postings(self, account_number: str,
                              start_date: date | None = None,
                              end_date: date | None = None) -> list[LedgerPosting]:
        """Get postings for an account within a date range."""
        postings = self._postings.get(account_number, [])
        result = []
        for p in postings:
            if start_date and p.entry_date < start_date:
                continue
            if end_date and p.entry_date > end_date:
                continue
            result.append(p)
        return sorted(result, key=lambda p: p.entry_date)

    def trial_balance(self, as_of: date | None = None,
                       currency: Currency | None = None) -> dict[str, tuple[Money, Money]]:
        """Generate trial balance: {account_number: (debit_balance, credit_balance)}.

        For trial balance, we show the balance on the normal side:
        - Debit-normal with positive balance: debit column
        - Debit-normal with negative balance: credit column
        - Credit-normal with positive balance: credit column
        - Credit-normal with negative balance: debit column

        The trial balance must have equal debit and credit totals.
        If it doesn't, there's a bug in the posting logic.
        """
        result: dict[str, tuple[Money, Money]] = {}

        for account in self._chart.all_accounts():
            balance = self.get_account_balance(account.number, as_of, currency)
            curr = currency or account.currency

            if balance.is_zero:
                result[account.number] = (Money.zero(curr), Money.zero(curr))
            elif balance.is_positive:
                if account.is_debit_normal:
                    result[account.number] = (balance, Money.zero(curr))
                else:
                    result[account.number] = (Money.zero(curr), balance)
            else:
                # Negative balance: show on the opposite side
                if account.is_debit_normal:
                    result[account.number] = (Money.zero(curr), abs(balance))
                else:
                    result[account.number] = (abs(balance), Money.zero(curr))

        return result

    def verify_trial_balance(self, as_of: date | None = None,
                              currency: Currency | None = None) -> tuple[bool, Money, Money]:
        """Verify that trial balance is balanced.

        Returns (is_balanced, total_debits, total_credits).
        """
        tb = self.trial_balance(as_of, currency)
        if not tb:
            if currency:
                return True, Money.zero(currency), Money.zero(currency)
            return True, None, None

        first_curr = None
        total_debit = Decimal("0")
        total_credit = Decimal("0")

        for acct_num, (debit, credit) in tb.items():
            if first_curr is None:
                first_curr = debit.currency
            total_debit += debit.amount
            total_credit += credit.amount

        if first_curr is None:
            return True, None, None

        d = Money(total_debit, first_curr)
        c_ = Money(total_credit, first_curr)
        return d == c_, d, c_

    def get_entry(self, entry_id: str) -> JournalEntry | None:
        return self._entries.get(entry_id)

    @property
    def entry_count(self) -> int:
        return len(self._entries)

    @property
    def posting_count(self) -> int:
        return sum(len(p) for p in self._postings.values())
