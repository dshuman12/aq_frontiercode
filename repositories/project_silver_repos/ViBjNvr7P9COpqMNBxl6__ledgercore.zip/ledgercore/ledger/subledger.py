"""Accounts Receivable and Accounts Payable sub-ledgers.

Sub-ledgers provide detailed tracking per customer/vendor while the
general ledger has only the control account total.

Key invariant: the sum of all sub-ledger balances MUST equal the
general ledger control account balance. If they don't match, there's
a posting error.

Sub-ledger entries track:
- Invoice number, date, amount
- Payment received/made, date, amount
- Credit memos (returns/adjustments)
- Aging information (days outstanding)

AR sub-ledger: tracks what customers owe us
AP sub-ledger: tracks what we owe vendors
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from typing import Any
from ledgercore.core.money import Money, Currency


class TransactionType:
    INVOICE = "invoice"
    PAYMENT = "payment"
    CREDIT_MEMO = "credit_memo"
    DEBIT_MEMO = "debit_memo"
    WRITE_OFF = "write_off"


@dataclass
class SubledgerTransaction:
    """A transaction in the sub-ledger."""
    transaction_id: str
    transaction_type: str
    transaction_date: date
    due_date: date | None = None
    amount: Money = field(default_factory=lambda: Money(0, Currency("USD", "$")))
    reference: str = ""  # invoice number, check number, etc.
    description: str = ""
    applied_to: str = ""  # for payments: which invoice this pays
    balance_remaining: Money | None = None  # remaining on this invoice
    journal_entry_id: str = ""


@dataclass
class CounterpartyAccount:
    """A customer or vendor account in the sub-ledger."""
    counterparty_id: str
    name: str
    transactions: list[SubledgerTransaction] = field(default_factory=list)
    credit_limit: Money | None = None
    payment_terms: str = "Net 30"
    is_active: bool = True

    @property
    def balance(self) -> Money:
        """Current balance (positive = owed to us for AR, owed by us for AP)."""
        if not self.transactions:
            return Money(0, Currency("USD", "$"))
        currency = self.transactions[0].amount.currency
        total = Money.zero(currency)
        for txn in self.transactions:
            if txn.transaction_type in (TransactionType.INVOICE, TransactionType.DEBIT_MEMO):
                total = total + txn.amount
            elif txn.transaction_type in (TransactionType.PAYMENT, TransactionType.CREDIT_MEMO, TransactionType.WRITE_OFF):
                total = total - txn.amount
        return total

    @property
    def open_invoices(self) -> list[SubledgerTransaction]:
        """Invoices with remaining balance."""
        result = []
        paid: dict[str, Decimal] = {}
        for txn in self.transactions:
            if txn.transaction_type == TransactionType.PAYMENT and txn.applied_to:
                paid[txn.applied_to] = paid.get(txn.applied_to, Decimal("0")) + txn.amount.amount
        for txn in self.transactions:
            if txn.transaction_type == TransactionType.INVOICE:
                paid_amount = paid.get(txn.transaction_id, Decimal("0"))
                remaining = txn.amount.amount - paid_amount
                if remaining > 0:
                    txn_copy = SubledgerTransaction(
                        transaction_id=txn.transaction_id,
                        transaction_type=txn.transaction_type,
                        transaction_date=txn.transaction_date,
                        due_date=txn.due_date,
                        amount=txn.amount,
                        reference=txn.reference,
                        balance_remaining=Money(remaining, txn.amount.currency),
                    )
                    result.append(txn_copy)
        return result

    def is_overdue(self, as_of: date) -> bool:
        for inv in self.open_invoices:
            if inv.due_date and inv.due_date < as_of:
                return True
        return False

    def days_outstanding(self, as_of: date) -> int:
        """Maximum days outstanding across open invoices."""
        max_days = 0
        for inv in self.open_invoices:
            if inv.due_date:
                days = (as_of - inv.due_date).days
                if days > max_days:
                    max_days = days
        return max_days


class Subledger:
    """Sub-ledger for AR or AP."""

    def __init__(self, ledger_type: str, control_account: str, currency: Currency):
        self._type = ledger_type  # "AR" or "AP"
        self._control_account = control_account
        self._currency = currency
        self._accounts: dict[str, CounterpartyAccount] = {}

    def add_counterparty(self, account: CounterpartyAccount) -> None:
        self._accounts[account.counterparty_id] = account

    def get_counterparty(self, counterparty_id: str) -> CounterpartyAccount | None:
        return self._accounts.get(counterparty_id)

    def record_invoice(
        self,
        counterparty_id: str,
        txn_id: str,
        inv_date: date,
        due_date: date,
        amount: Money,
        reference: str = "",
    ) -> SubledgerTransaction:
        acct = self._accounts.get(counterparty_id)
        if acct is None:
            raise ValueError(f"Counterparty {counterparty_id} not found")
        txn = SubledgerTransaction(
            transaction_id=txn_id,
            transaction_type=TransactionType.INVOICE,
            transaction_date=inv_date,
            due_date=due_date,
            amount=amount,
            reference=reference,
        )
        acct.transactions.append(txn)
        return txn

    def record_payment(
        self,
        counterparty_id: str,
        txn_id: str,
        pay_date: date,
        amount: Money,
        applied_to_invoice: str = "",
    ) -> SubledgerTransaction:
        acct = self._accounts.get(counterparty_id)
        if acct is None:
            raise ValueError(f"Counterparty {counterparty_id} not found")
        txn = SubledgerTransaction(
            transaction_id=txn_id,
            transaction_type=TransactionType.PAYMENT,
            transaction_date=pay_date,
            amount=amount,
            applied_to=applied_to_invoice,
        )
        acct.transactions.append(txn)
        return txn

    def total_balance(self) -> Money:
        total = Money.zero(self._currency)
        for acct in self._accounts.values():
            total = total + acct.balance
        return total

    def overdue_accounts(self, as_of: date) -> list[CounterpartyAccount]:
        return [a for a in self._accounts.values() if a.is_overdue(as_of)]

    def all_open_invoices(self) -> list[tuple[str, SubledgerTransaction]]:
        result = []
        for acct in self._accounts.values():
            for inv in acct.open_invoices:
                result.append((acct.counterparty_id, inv))
        return result

    @property
    def counterparty_count(self) -> int:
        return len(self._accounts)

    @property
    def control_account(self) -> str:
        return self._control_account
