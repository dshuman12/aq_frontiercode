"""Budget management and variance analysis.

Budgets are set per account per period. Variance analysis compares
actual amounts against budgeted amounts.

Variance types:
- Favorable: actual is better than budget
  - For revenue: actual > budget (more income)
  - For expenses: actual < budget (less spending)
- Unfavorable: actual is worse than budget
  - For revenue: actual < budget
  - For expenses: actual > budget

Note the asymmetry: "favorable" has OPPOSITE signs for revenue vs expense.
This is a common source of bugs.

Variance percentage: (actual - budget) / budget * 100
  For revenue: positive % = favorable
  For expenses: positive % = unfavorable (because more spending is bad)
"""
from __future__ import annotations
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any
from ledgercore.core.money import Money, Currency
from ledgercore.core.account import AccountType


@dataclass
class BudgetLine:
    """A budget amount for one account in one period."""
    account_number: str
    period_id: str
    amount: Money
    notes: str = ""


@dataclass
class VarianceResult:
    """Result of comparing actual to budget."""
    account_number: str
    account_name: str
    account_type: AccountType
    budget_amount: Money
    actual_amount: Money
    variance: Money  # actual - budget
    variance_pct: Decimal  # as percentage
    is_favorable: bool


class BudgetManager:
    """Manage budgets and compute variances."""

    def __init__(self, currency: Currency):
        self._budgets: dict[tuple[str, str], BudgetLine] = {}  # (acct, period) -> budget
        self._currency = currency

    def set_budget(self, account_number: str, period_id: str,
                   amount: Money, notes: str = "") -> None:
        key = (account_number, period_id)
        self._budgets[key] = BudgetLine(account_number, period_id, amount, notes)

    def get_budget(self, account_number: str, period_id: str) -> BudgetLine | None:
        return self._budgets.get((account_number, period_id))

    def compute_variance(
        self,
        account_number: str,
        account_name: str,
        account_type: AccountType,
        period_id: str,
        actual: Money,
    ) -> VarianceResult:
        """Compute budget variance for an account.

        The critical logic: favorable/unfavorable depends on account type.
        """
        budget_line = self.get_budget(account_number, period_id)
        budget_amount = budget_line.amount if budget_line else Money.zero(self._currency)

        variance = actual - budget_amount

        # Compute percentage
        if budget_amount.is_zero:
            variance_pct = Decimal("0")
        else:
            variance_pct = (variance.amount / budget_amount.amount * 100)

        # Determine if favorable
        # Revenue: higher actual = favorable (positive variance = good)
        # Expenses: lower actual = favorable (negative variance = good)
        if account_type in (AccountType.REVENUE,):
            is_favorable = variance.amount >= 0
        elif account_type in (AccountType.EXPENSE,):
            is_favorable = variance.amount <= 0
        else:
            is_favorable = variance.amount >= 0  # assets: more is good

        return VarianceResult(
            account_number=account_number,
            account_name=account_name,
            account_type=account_type,
            budget_amount=budget_amount,
            actual_amount=actual,
            variance=variance,
            variance_pct=variance_pct,
            is_favorable=is_favorable,
        )

    def get_budgets_for_period(self, period_id: str) -> list[BudgetLine]:
        return [bl for bl in self._budgets.values() if bl.period_id == period_id]

    @property
    def budget_count(self) -> int:
        return len(self._budgets)
