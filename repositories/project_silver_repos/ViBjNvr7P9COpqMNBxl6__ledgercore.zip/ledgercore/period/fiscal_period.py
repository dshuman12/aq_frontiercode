"""Fiscal period management with period closing.

Period closing is one of the most complex accounting operations:

1. All revenue and expense accounts are zeroed out by creating
   closing entries that transfer their balances to Retained Earnings.

2. Once closed, a period becomes IMMUTABLE — no new entries can
   be posted to a closed period.

3. The closing process:
   a. Verify trial balance is balanced
   b. For each revenue account: debit revenue, credit Income Summary
   c. For each expense account: credit expense, debit Income Summary
   d. Transfer Income Summary balance to Retained Earnings
   e. Mark period as closed

4. The Income Summary account is a temporary account that only exists
   during the closing process. Its balance after steps b+c equals
   Net Income (or Net Loss if negative).

5. After closing, all income statement accounts have zero balances.
   Their balances are now part of Retained Earnings.

6. This means the SAME account can have different balances depending
   on whether you're looking at a closed or open period.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from enum import Enum
from typing import Any
from ledgercore.core.money import Money, Currency
from ledgercore.core.entry import JournalEntry, EntryType, EntryStatus
from ledgercore.core.account import AccountType


class PeriodStatus(Enum):
    OPEN = "open"
    CLOSING = "closing"  # in the process of being closed
    CLOSED = "closed"


@dataclass
class FiscalPeriod:
    """A fiscal period (usually a month or quarter)."""
    period_id: str
    start_date: date
    end_date: date
    status: PeriodStatus = PeriodStatus.OPEN
    closed_at: date | None = None
    closed_by: str = ""
    closing_entry_ids: list[str] = field(default_factory=list)

    @property
    def is_open(self) -> bool:
        return self.status == PeriodStatus.OPEN

    @property
    def is_closed(self) -> bool:
        return self.status == PeriodStatus.CLOSED

    def contains_date(self, d: date) -> bool:
        return self.start_date <= d <= self.end_date

    def __repr__(self) -> str:
        return f"FiscalPeriod({self.period_id}, {self.start_date} to {self.end_date}, {self.status.value})"


class FiscalCalendar:
    """Manages fiscal periods and enforces period rules."""

    def __init__(self, functional_currency: Currency):
        self._periods: dict[str, FiscalPeriod] = {}
        self._period_order: list[str] = []
        self._currency = functional_currency
        self._retained_earnings_account: str = ""
        self._income_summary_account: str = ""

    def set_retained_earnings_account(self, account_number: str) -> None:
        self._retained_earnings_account = account_number

    def set_income_summary_account(self, account_number: str) -> None:
        self._income_summary_account = account_number

    def add_period(self, period: FiscalPeriod) -> None:
        if period.period_id in self._periods:
            raise ValueError(f"Period {period.period_id} already exists")
        # Verify no overlap with existing periods
        for existing in self._periods.values():
            if (period.start_date <= existing.end_date and
                period.end_date >= existing.start_date):
                raise ValueError(
                    f"Period {period.period_id} overlaps with {existing.period_id}"
                )
        self._periods[period.period_id] = period
        self._period_order.append(period.period_id)
        self._period_order.sort(key=lambda pid: self._periods[pid].start_date)

    def get_period(self, period_id: str) -> FiscalPeriod | None:
        return self._periods.get(period_id)

    def get_period_for_date(self, d: date) -> FiscalPeriod | None:
        for period in self._periods.values():
            if period.contains_date(d):
                return period
        return None

    def can_post_to_date(self, d: date) -> tuple[bool, str]:
        """Check if a transaction can be posted to a given date.

        Rules:
        1. Date must fall within a defined period
        2. That period must be open
        3. All PRIOR periods must be either open or closed (not skipped)
        """
        period = self.get_period_for_date(d)
        if period is None:
            return False, f"No fiscal period defined for {d}"
        if period.is_closed:
            return False, f"Period {period.period_id} is closed"
        return True, ""

    def close_period(
        self,
        period_id: str,
        ledger: Any,  # GeneralLedger — avoid circular import
        entry_id_generator: Any,  # callable that returns unique entry IDs
    ) -> tuple[list[str], list[JournalEntry]]:
        """Close a fiscal period.

        Creates closing entries to zero out income statement accounts
        and transfer net income to retained earnings.

        Returns (errors, closing_entries).
        """
        period = self._periods.get(period_id)
        if period is None:
            return [f"Period {period_id} not found"], []
        if period.is_closed:
            return [f"Period {period_id} already closed"], []

        if not self._retained_earnings_account:
            return ["Retained earnings account not configured"], []

        # Verify all prior periods are closed
        for pid in self._period_order:
            if pid == period_id:
                break
            prior = self._periods[pid]
            if not prior.is_closed:
                return [f"Prior period {pid} must be closed first"], []

        period.status = PeriodStatus.CLOSING
        closing_entries = []

        # Step 1: Close revenue accounts (debit revenue, credit income summary)
        # Step 2: Close expense accounts (credit expense, debit income summary)
        revenue_total = Decimal("0")
        expense_total = Decimal("0")

        chart = ledger.chart
        revenue_entry = JournalEntry(
            entry_id=entry_id_generator(),
            entry_date=period.end_date,
            description=f"Close revenue accounts for {period_id}",
            entry_type=EntryType.CLOSING,
            period_id=period_id,
        )
        expense_entry = JournalEntry(
            entry_id=entry_id_generator(),
            entry_date=period.end_date,
            description=f"Close expense accounts for {period_id}",
            entry_type=EntryType.CLOSING,
            period_id=period_id,
        )

        for account in chart.all_accounts():
            if not account.is_income_statement:
                continue
            balance = ledger.get_account_balance(
                account.number, period.end_date, self._currency
            )
            if balance.is_zero:
                continue

            if account.account_type == AccountType.REVENUE:
                # Debit revenue (decrease it to zero), credit income summary
                revenue_entry.add_debit(account.number, balance)
                revenue_total += balance.amount
            elif account.account_type == AccountType.EXPENSE:
                # Credit expense (decrease it to zero), debit income summary
                expense_entry.add_credit(account.number, balance)
                expense_total += balance.amount

        # Add income summary sides
        if revenue_total > 0 and self._income_summary_account:
            revenue_entry.add_credit(
                self._income_summary_account,
                Money(revenue_total, self._currency),
            )
            closing_entries.append(revenue_entry)

        if expense_total > 0 and self._income_summary_account:
            expense_entry.add_debit(
                self._income_summary_account,
                Money(expense_total, self._currency),
            )
            closing_entries.append(expense_entry)

        # Step 3: Transfer income summary to retained earnings
        net_income = revenue_total - expense_total
        if net_income != 0 and self._income_summary_account:
            transfer_entry = JournalEntry(
                entry_id=entry_id_generator(),
                entry_date=period.end_date,
                description=f"Transfer net income to retained earnings for {period_id}",
                entry_type=EntryType.CLOSING,
                period_id=period_id,
            )
            if net_income > 0:
                # Net income: debit income summary, credit retained earnings
                transfer_entry.add_debit(
                    self._income_summary_account,
                    Money(net_income, self._currency),
                )
                transfer_entry.add_credit(
                    self._retained_earnings_account,
                    Money(net_income, self._currency),
                )
            else:
                # Net loss: credit income summary, debit retained earnings
                transfer_entry.add_credit(
                    self._income_summary_account,
                    Money(abs(net_income), self._currency),
                )
                transfer_entry.add_debit(
                    self._retained_earnings_account,
                    Money(abs(net_income), self._currency),
                )
            closing_entries.append(transfer_entry)

        # Post all closing entries
        errors = []
        for entry in closing_entries:
            post_errors = ledger.post_entry(entry)
            if post_errors:
                errors.extend(post_errors)
                period.status = PeriodStatus.OPEN  # rollback
                return errors, []

        period.status = PeriodStatus.CLOSED
        period.closed_at = period.end_date
        period.closing_entry_ids = [e.entry_id for e in closing_entries]
        return [], closing_entries

    @property
    def periods(self) -> list[FiscalPeriod]:
        return [self._periods[pid] for pid in self._period_order]

    @property
    def open_periods(self) -> list[FiscalPeriod]:
        return [p for p in self.periods if p.is_open]

    @property
    def closed_periods(self) -> list[FiscalPeriod]:
        return [p for p in self.periods if p.is_closed]
