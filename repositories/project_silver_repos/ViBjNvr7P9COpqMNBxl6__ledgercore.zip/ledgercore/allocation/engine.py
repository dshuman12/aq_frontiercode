"""Cost allocation engine for distributing shared costs.

Cost allocation distributes indirect costs (e.g., rent, utilities, IT)
to cost centers based on allocation bases (headcount, square footage,
revenue, etc.).

Allocation methods:
1. Direct: allocate directly based on a single driver
2. Step-down: allocate service departments first, then to production
   (order matters: allocate highest-cost service dept first)
3. Reciprocal: handles mutual services between departments
   (requires solving simultaneous equations)

Step-down method complexity:
  Service Dept A provides 10% of its services to Service Dept B
  Service Dept B provides 20% of its services to Service Dept A
  
  In step-down, once Dept A is allocated, it cannot receive further
  allocations. The order of allocation affects results — this is a
  known limitation that reciprocal method fixes.

Reciprocal method:
  Set up equations:
  Total_A = Direct_A + 0.20 * Total_B
  Total_B = Direct_B + 0.10 * Total_A
  Solve simultaneously (matrix method or iterative).

Allocation journal entries:
  Dr. Cost Center Expense (receiving department)
  Cr. Cost Pool (shared expense account)
"""
from __future__ import annotations
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any
from ledgercore.core.money import Money, Currency
from ledgercore.core.entry import JournalEntry, EntryType


@dataclass
class CostCenter:
    """A cost center that receives allocated costs."""
    center_id: str
    name: str
    is_service: bool = False  # service department (for step-down)
    allocation_base_value: Decimal = Decimal("0")  # headcount, sqft, etc.
    expense_account: str = ""


@dataclass
class AllocationRule:
    """Rule for allocating a cost pool."""
    rule_id: str
    cost_pool_account: str
    description: str = ""
    allocation_base: str = ""  # "headcount", "sqft", "revenue", etc.
    targets: list[tuple[str, Decimal]] = field(default_factory=list)  # (center_id, percentage)
    method: str = "direct"  # "direct", "step_down", "reciprocal"

    @property
    def total_percentage(self) -> Decimal:
        return sum(pct for _, pct in self.targets)


@dataclass
class AllocationResult:
    """Result of a single allocation."""
    center_id: str
    center_name: str
    amount: Money
    source_pool: str
    percentage: Decimal


class AllocationEngine:
    """Distribute costs across cost centers."""

    def __init__(self, currency: Currency):
        self._currency = currency
        self._centers: dict[str, CostCenter] = {}
        self._rules: list[AllocationRule] = []

    def add_center(self, center: CostCenter) -> None:
        self._centers[center.center_id] = center

    def add_rule(self, rule: AllocationRule) -> None:
        self._rules.append(rule)

    def allocate_direct(
        self,
        pool_amount: Money,
        rule: AllocationRule,
    ) -> list[AllocationResult]:
        """Direct allocation using fixed percentages."""
        results = []
        total_pct = rule.total_percentage
        if total_pct == 0:
            return results

        for center_id, pct in rule.targets:
            center = self._centers.get(center_id)
            if center is None:
                continue
            allocated = pool_amount * (pct / total_pct)
            results.append(AllocationResult(
                center_id=center_id,
                center_name=center.name,
                amount=allocated,
                source_pool=rule.cost_pool_account,
                percentage=pct / total_pct * 100,
            ))

        return results

    def allocate_by_base(
        self,
        pool_amount: Money,
        rule: AllocationRule,
    ) -> list[AllocationResult]:
        """Allocate proportionally based on allocation base values."""
        total_base = Decimal("0")
        for center_id, _ in rule.targets:
            center = self._centers.get(center_id)
            if center:
                total_base += center.allocation_base_value

        if total_base == 0:
            return self.allocate_direct(pool_amount, rule)

        results = []
        for center_id, _ in rule.targets:
            center = self._centers.get(center_id)
            if center is None:
                continue
            share = center.allocation_base_value / total_base
            allocated = pool_amount * share
            results.append(AllocationResult(
                center_id=center_id,
                center_name=center.name,
                amount=allocated,
                source_pool=rule.cost_pool_account,
                percentage=share * 100,
            ))

        return results

    def step_down_allocation(
        self,
        pool_amounts: dict[str, Money],
        service_order: list[str],
        inter_dept_pcts: dict[str, dict[str, Decimal]],
    ) -> dict[str, list[AllocationResult]]:
        """Step-down allocation of service department costs.

        Args:
            pool_amounts: {center_id: total cost to allocate}
            service_order: order to allocate service depts (highest cost first)
            inter_dept_pcts: {from_center: {to_center: percentage}}
        """
        remaining = {k: v for k, v in pool_amounts.items()}
        all_results: dict[str, list[AllocationResult]] = {}

        for svc_center_id in service_order:
            svc_amount = remaining.get(svc_center_id, Money.zero(self._currency))
            if svc_amount.is_zero:
                continue

            pcts = inter_dept_pcts.get(svc_center_id, {})
            # Exclude already-allocated service departments
            valid_targets = {
                k: v for k, v in pcts.items()
                if k not in service_order[:service_order.index(svc_center_id)]
            }
            total_pct = sum(valid_targets.values())
            if total_pct == 0:
                continue

            results = []
            for target_id, pct in valid_targets.items():
                normalized_pct = pct / total_pct
                allocated = svc_amount * normalized_pct
                center = self._centers.get(target_id)
                results.append(AllocationResult(
                    center_id=target_id,
                    center_name=center.name if center else target_id,
                    amount=allocated,
                    source_pool=svc_center_id,
                    percentage=normalized_pct * 100,
                ))
                # Add to remaining for this target
                if target_id in remaining:
                    remaining[target_id] = remaining[target_id] + allocated
                else:
                    remaining[target_id] = allocated

            all_results[svc_center_id] = results
            # Service dept is now fully allocated
            remaining[svc_center_id] = Money.zero(self._currency)

        return all_results

    def reciprocal_allocation(
        self,
        pool_amounts: dict[str, Money],
        inter_dept_pcts: dict[str, dict[str, Decimal]],
        max_iterations: int = 50,
        tolerance: Decimal = Decimal("0.01"),
    ) -> dict[str, Money]:
        """Reciprocal allocation using iterative method.

        Solves mutual allocation between service departments
        by repeated allocation until convergence.
        """
        current = {k: v.amount for k, v in pool_amounts.items()}
        
        for _ in range(max_iterations):
            new_totals = {k: pool_amounts[k].amount for k in current}
            
            for from_id, pcts in inter_dept_pcts.items():
                from_amount = current.get(from_id, Decimal("0"))
                for to_id, pct in pcts.items():
                    if to_id in new_totals:
                        new_totals[to_id] += from_amount * pct

            max_change = max(
                abs(new_totals[k] - current[k])
                for k in current
            )
            current = new_totals

            if max_change <= tolerance:
                break

        return {k: Money(v, self._currency) for k, v in current.items()}

    def generate_entries(
        self,
        results: list[AllocationResult],
        entry_id: str,
        entry_date,
    ) -> JournalEntry:
        """Generate journal entry for allocation results."""
        from datetime import date as date_type
        entry = JournalEntry(
            entry_id=entry_id,
            entry_date=entry_date,
            description="Cost allocation",
            entry_type=EntryType.ADJUSTING,
        )
        for r in results:
            center = self._centers.get(r.center_id)
            if center and center.expense_account:
                entry.add_debit(center.expense_account, r.amount)
        # Credit the cost pool
        total_allocated = Money.zero(self._currency)
        for r in results:
            total_allocated = total_allocated + r.amount
        if not total_allocated.is_zero and results:
            entry.add_credit(results[0].source_pool, total_allocated)
        return entry

    @property
    def center_count(self) -> int:
        return len(self._centers)
