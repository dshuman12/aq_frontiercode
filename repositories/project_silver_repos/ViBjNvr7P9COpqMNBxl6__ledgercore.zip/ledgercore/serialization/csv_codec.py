"""CSV import and export for journal entries.

Supports importing transactions from bank feeds, CSV exports from
other accounting systems, and exporting journal entries for external review.

Import format (flexible, column-mapped):
  Date, Description, Account, Debit, Credit, Reference

Export format:
  Entry ID, Date, Account, Account Name, Debit, Credit, Description, Reference

Import challenges:
1. Date format detection (MM/DD/YYYY, DD/MM/YYYY, YYYY-MM-DD)
2. Number format (1,000.00 vs 1.000,00)
3. Missing account mappings
4. Unbalanced imports (bank feed has one side only — need to infer the other)
5. Duplicate detection

For bank feeds (single-sided):
  The import needs to create complete double-entry from a single line:
  If amount > 0 (deposit): Dr. Cash, Cr. Unclassified Income
  If amount < 0 (withdrawal): Dr. Unclassified Expense, Cr. Cash
  User then reclassifies the "unclassified" side.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from typing import Any
import csv
import io
from ledgercore.core.money import Money, Currency
from ledgercore.core.entry import JournalEntry, EntryLine


@dataclass
class ImportMapping:
    """Column mapping for CSV import."""
    date_col: int = 0
    description_col: int = 1
    account_col: int = 2
    debit_col: int = 3
    credit_col: int = 4
    reference_col: int = -1  # -1 = not present
    date_format: str = "%Y-%m-%d"
    has_header: bool = True
    decimal_separator: str = "."
    thousands_separator: str = ","


@dataclass
class ImportResult:
    """Result of importing a CSV file."""
    entries: list[JournalEntry] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    rows_processed: int = 0
    rows_skipped: int = 0


class CSVImporter:
    """Import journal entries from CSV."""

    def __init__(self, currency: Currency, mapping: ImportMapping | None = None):
        self._currency = currency
        self._mapping = mapping or ImportMapping()

    def import_journal_entries(
        self,
        csv_text: str,
        entry_id_generator: Any,
    ) -> ImportResult:
        """Import balanced journal entries from CSV.

        Groups consecutive lines with the same date and reference
        into a single journal entry.
        """
        result = ImportResult()
        reader = csv.reader(io.StringIO(csv_text))
        rows = list(reader)
        
        if self._mapping.has_header and rows:
            rows = rows[1:]

        current_entry: JournalEntry | None = None
        current_key = ("", "")

        for row_num, row in enumerate(rows, start=2 if self._mapping.has_header else 1):
            result.rows_processed += 1
            try:
                parsed = self._parse_row(row, row_num)
                if parsed is None:
                    result.rows_skipped += 1
                    continue

                row_date, desc, account, debit, credit, ref = parsed
                entry_key = (str(row_date), ref)

                if entry_key != current_key or current_entry is None:
                    if current_entry is not None:
                        self._finalize_entry(current_entry, result)
                    current_entry = JournalEntry(
                        entry_id=entry_id_generator(),
                        entry_date=row_date,
                        description=desc,
                        reference=ref,
                    )
                    current_key = entry_key

                if debit and debit > 0:
                    current_entry.add_debit(account, Money(debit, self._currency), desc)
                if credit and credit > 0:
                    current_entry.add_credit(account, Money(credit, self._currency), desc)

            except Exception as e:
                result.errors.append(f"Row {row_num}: {str(e)}")
                result.rows_skipped += 1

        if current_entry is not None:
            self._finalize_entry(current_entry, result)

        return result

    def import_bank_feed(
        self,
        csv_text: str,
        cash_account: str,
        default_income_account: str,
        default_expense_account: str,
        entry_id_generator: Any,
    ) -> ImportResult:
        """Import single-sided bank transactions and create double-entry.

        Each row becomes a complete journal entry with Cash on one side
        and a default account on the other.
        """
        result = ImportResult()
        reader = csv.reader(io.StringIO(csv_text))
        rows = list(reader)

        if self._mapping.has_header and rows:
            rows = rows[1:]

        for row_num, row in enumerate(rows, start=2):
            result.rows_processed += 1
            try:
                row_date = self._parse_date(row[self._mapping.date_col])
                desc = row[self._mapping.description_col] if self._mapping.description_col < len(row) else ""
                amount_str = row[self._mapping.debit_col] if self._mapping.debit_col < len(row) else "0"
                amount = self._parse_amount(amount_str)

                if amount is None or amount == 0:
                    result.rows_skipped += 1
                    continue

                entry = JournalEntry(
                    entry_id=entry_id_generator(),
                    entry_date=row_date,
                    description=desc,
                )

                if amount > 0:
                    # Deposit: Dr. Cash, Cr. Income
                    entry.add_debit(cash_account, Money(amount, self._currency))
                    entry.add_credit(default_income_account, Money(amount, self._currency))
                else:
                    # Withdrawal: Dr. Expense, Cr. Cash
                    entry.add_debit(default_expense_account, Money(abs(amount), self._currency))
                    entry.add_credit(cash_account, Money(abs(amount), self._currency))

                result.entries.append(entry)

            except Exception as e:
                result.errors.append(f"Row {row_num}: {str(e)}")
                result.rows_skipped += 1

        return result

    def _parse_row(self, row: list[str], row_num: int):
        m = self._mapping
        if len(row) <= max(m.date_col, m.account_col):
            return None

        row_date = self._parse_date(row[m.date_col])
        desc = row[m.description_col] if m.description_col < len(row) else ""
        account = row[m.account_col].strip()
        debit = self._parse_amount(row[m.debit_col]) if m.debit_col < len(row) else None
        credit = self._parse_amount(row[m.credit_col]) if m.credit_col < len(row) else None
        ref = row[m.reference_col].strip() if m.reference_col >= 0 and m.reference_col < len(row) else ""

        if not account:
            return None

        return row_date, desc, account, debit, credit, ref

    def _parse_date(self, text: str) -> date:
        text = text.strip()
        for fmt in [self._mapping.date_format, "%Y-%m-%d", "%m/%d/%Y", "%d/%m/%Y"]:
            try:
                return datetime.strptime(text, fmt).date()
            except ValueError:
                continue
        raise ValueError(f"Cannot parse date: {text}")

    def _parse_amount(self, text: str) -> Decimal | None:
        text = text.strip()
        if not text or text == "-":
            return None
        text = text.replace(self._mapping.thousands_separator, "")
        if self._mapping.decimal_separator != ".":
            text = text.replace(self._mapping.decimal_separator, ".")
        text = text.replace("$", "").replace("€", "").replace("£", "")
        try:
            return Decimal(text)
        except InvalidOperation:
            return None

    def _finalize_entry(self, entry: JournalEntry, result: ImportResult) -> None:
        errors = entry.validate()
        if errors:
            result.warnings.extend(errors)
        result.entries.append(entry)


class CSVExporter:
    """Export journal entries to CSV."""

    def export_entries(
        self,
        entries: list[JournalEntry],
        account_names: dict[str, str] | None = None,
    ) -> str:
        """Export entries to CSV format."""
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(["Entry ID", "Date", "Account", "Account Name",
                         "Debit", "Credit", "Description", "Reference"])

        names = account_names or {}
        for entry in entries:
            for line in entry.lines:
                debit_str = str(line.debit.amount) if line.is_debit else ""
                credit_str = str(line.credit.amount) if line.is_credit else ""
                writer.writerow([
                    entry.entry_id,
                    entry.entry_date.isoformat(),
                    line.account_number,
                    names.get(line.account_number, ""),
                    debit_str,
                    credit_str,
                    line.description or entry.description,
                    entry.reference,
                ])

        return output.getvalue()
