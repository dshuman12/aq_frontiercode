"""JSON serialization for ledger data."""
from __future__ import annotations
import json
from datetime import date, datetime
from decimal import Decimal
from typing import Any
from ledgercore.core.money import Money, Currency
from ledgercore.core.account import Account, AccountType
from ledgercore.core.entry import JournalEntry, EntryLine, EntryStatus, EntryType


class LedgerEncoder(json.JSONEncoder):
    def default(self, obj: Any) -> Any:
        if isinstance(obj, Decimal):
            return str(obj)
        if isinstance(obj, (date, datetime)):
            return obj.isoformat()
        if isinstance(obj, Money):
            return {"amount": str(obj.amount), "currency": obj.currency.code}
        if isinstance(obj, Currency):
            return obj.code
        if isinstance(obj, AccountType):
            return obj.value
        if isinstance(obj, (EntryStatus, EntryType)):
            return obj.value
        if isinstance(obj, set):
            return sorted(obj)
        return super().default(obj)


def encode_entry(entry: JournalEntry) -> str:
    data = {
        "entry_id": entry.entry_id,
        "entry_date": entry.entry_date.isoformat(),
        "description": entry.description,
        "reference": entry.reference,
        "status": entry.status.value,
        "entry_type": entry.entry_type.value,
        "lines": [
            {
                "account": line.account_number,
                "debit": {"amount": str(line.debit.amount), "currency": line.debit.currency.code} if line.debit else None,
                "credit": {"amount": str(line.credit.amount), "currency": line.credit.currency.code} if line.credit else None,
                "description": line.description,
            }
            for line in entry.lines
        ],
    }
    return json.dumps(data, indent=2, cls=LedgerEncoder)


def encode_account(account: Account) -> str:
    data = {
        "number": account.number,
        "name": account.name,
        "type": account.account_type.value,
        "currency": account.currency.code,
        "parent": account.parent_number,
        "active": account.is_active,
        "system": account.is_system,
        "tags": sorted(account.tags),
    }
    return json.dumps(data, indent=2)
