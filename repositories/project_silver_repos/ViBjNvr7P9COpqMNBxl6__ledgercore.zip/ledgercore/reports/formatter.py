"""Report formatting for financial statements.

Converts financial statement objects to formatted text, CSV, and
structured dictionaries for different output formats.

Text formatting handles:
- Right-aligned numbers with thousands separators
- Indentation for sub-accounts
- Underlines for subtotals
- Double underlines for grand totals
- Negative amounts in parentheses (accounting convention)
"""
from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal
from typing import Any
from ledgercore.core.money import Money, Currency
from ledgercore.reports.financial_statements import (
    BalanceSheet, IncomeStatement, ReportLine,
)


class AccountingFormatter:
    """Format monetary amounts using accounting conventions."""

    def __init__(self, currency: Currency, show_currency: bool = True):
        self._currency = currency
        self._show_currency = show_currency

    def format_amount(self, amount: Money) -> str:
        """Format a money amount in accounting style.

        Positive: $1,234.56
        Negative: ($1,234.56)
        Zero: $-
        """
        if amount.is_zero:
            prefix = f"{self._currency.symbol}" if self._show_currency else ""
            return f"{prefix}-"

        abs_amount = abs(amount)
        num_str = f"{abs_amount.amount:,.{self._currency.decimal_places}f}"
        prefix = f"{self._currency.symbol}" if self._show_currency else ""

        if amount.is_negative:
            return f"({prefix}{num_str})"
        return f"{prefix}{num_str}"

    def format_percentage(self, value: Decimal, decimals: int = 1) -> str:
        if value is None:
            return "N/A"
        return f"{value * 100:.{decimals}f}%"


class TextReportBuilder:
    """Build text-format financial reports."""

    def __init__(self, width: int = 60, formatter: AccountingFormatter | None = None):
        self._width = width
        self._formatter = formatter
        self._lines: list[str] = []

    def header(self, company: str, title: str, period: str) -> None:
        self._lines.append(company.center(self._width))
        self._lines.append(title.center(self._width))
        self._lines.append(period.center(self._width))
        self._lines.append("")

    def section_header(self, title: str) -> None:
        self._lines.append(title)

    def line_item(self, label: str, amount: Money, indent: int = 0) -> None:
        prefix = "  " * indent
        formatted = self._formatter.format_amount(amount) if self._formatter else str(amount)
        padding = self._width - len(prefix) - len(label) - len(formatted)
        self._lines.append(f"{prefix}{label}{'.' * max(1, padding)}{formatted}")

    def subtotal(self, label: str, amount: Money) -> None:
        formatted = self._formatter.format_amount(amount) if self._formatter else str(amount)
        padding = self._width - len(label) - len(formatted) - 2
        self._lines.append(f"  {label}{' ' * max(1, padding)}{formatted}")
        self._lines.append("  " + "-" * (self._width - 4))

    def grand_total(self, label: str, amount: Money) -> None:
        formatted = self._formatter.format_amount(amount) if self._formatter else str(amount)
        padding = self._width - len(label) - len(formatted)
        self._lines.append(f"{label}{'=' * max(1, padding)}{formatted}")

    def blank_line(self) -> None:
        self._lines.append("")

    def build(self) -> str:
        return "\n".join(self._lines)

    def format_balance_sheet(self, bs: BalanceSheet, company: str = "") -> str:
        self._lines = []
        self.header(company or "Company", "Balance Sheet",
                   f"As of {bs.as_of.isoformat()}")

        self.section_header("ASSETS")
        for item in bs.assets:
            self.line_item(f"  {item.account_name}", item.amount, item.indent)
        if bs.total_assets:
            self.subtotal("Total Assets", bs.total_assets)
        self.blank_line()

        self.section_header("LIABILITIES")
        for item in bs.liabilities:
            self.line_item(f"  {item.account_name}", item.amount, item.indent)
        if bs.total_liabilities:
            self.subtotal("Total Liabilities", bs.total_liabilities)
        self.blank_line()

        self.section_header("EQUITY")
        for item in bs.equity:
            self.line_item(f"  {item.account_name}", item.amount, item.indent)
        if bs.total_equity:
            self.subtotal("Total Equity", bs.total_equity)
        self.blank_line()

        if bs.total_liabilities_equity:
            self.grand_total("TOTAL LIABILITIES + EQUITY", bs.total_liabilities_equity)

        return self.build()

    def format_income_statement(self, pnl: IncomeStatement, company: str = "") -> str:
        self._lines = []
        self.header(company or "Company", "Income Statement",
                   f"{pnl.start_date.isoformat()} to {pnl.end_date.isoformat()}")

        self.section_header("REVENUE")
        for item in pnl.revenue:
            self.line_item(f"  {item.account_name}", item.amount)
        if pnl.total_revenue:
            self.subtotal("Total Revenue", pnl.total_revenue)
        self.blank_line()

        self.section_header("EXPENSES")
        for item in pnl.expenses:
            self.line_item(f"  {item.account_name}", item.amount)
        if pnl.total_expenses:
            self.subtotal("Total Expenses", pnl.total_expenses)
        self.blank_line()

        if pnl.net_income:
            self.grand_total("NET INCOME", pnl.net_income)

        return self.build()
