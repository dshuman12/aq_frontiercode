"""Comparative financial reports (period-over-period analysis).

Generates side-by-side comparisons of financial data across periods,
with variance calculations showing:
- Dollar change
- Percentage change
- Trend direction

Supports:
1. Balance Sheet comparison (two dates)
2. Income Statement comparison (two periods)
3. Trailing twelve months (TTM) analysis
4. Common-size analysis (each line as % of total)

Common-size analysis:
  Balance Sheet: each item as % of Total Assets
  Income Statement: each item as % of Revenue

This is useful for comparing companies of different sizes or
for spotting structural changes in the financial mix.

Horizontal analysis: shows dollar and percentage change
Vertical analysis: shows each item as % of a base amount
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal, ROUND_HALF_EVEN
from typing import Any
from ledgercore.core.money import Money, Currency
from ledgercore.core.account import AccountType
from ledgercore.ledger.general_ledger import GeneralLedger


@dataclass
class ComparativeLine:
    """A line in a comparative report."""
    account_number: str
    account_name: str
    current_amount: Money
    prior_amount: Money
    dollar_change: Money
    pct_change: Decimal | None = None
    current_common_size: Decimal | None = None  # as % of base
    prior_common_size: Decimal | None = None

    @property
    def change_direction(self) -> str:
        if self.dollar_change.is_positive:
            return "increase"
        if self.dollar_change.is_negative:
            return "decrease"
        return "unchanged"


@dataclass
class ComparativeReport:
    """A comparative financial report."""
    title: str
    current_period: str
    prior_period: str
    currency: Currency
    lines: list[ComparativeLine] = field(default_factory=list)
    current_total: Money | None = None
    prior_total: Money | None = None


class ComparativeAnalyzer:
    """Generate comparative financial reports."""

    def __init__(self, ledger: GeneralLedger, currency: Currency):
        self._ledger = ledger
        self._currency = currency

    def balance_sheet_comparison(
        self,
        current_date: date,
        prior_date: date,
    ) -> ComparativeReport:
        """Compare balance sheets at two dates."""
        report = ComparativeReport(
            title="Comparative Balance Sheet",
            current_period=current_date.isoformat(),
            prior_period=prior_date.isoformat(),
            currency=self._currency,
        )

        current_total = Decimal("0")
        prior_total = Decimal("0")

        for acct in self._ledger.chart.get_balance_sheet_accounts():
            curr_bal = self._ledger.get_account_balance(
                acct.number, current_date, self._currency
            )
            prior_bal = self._ledger.get_account_balance(
                acct.number, prior_date, self._currency
            )

            if curr_bal.is_zero and prior_bal.is_zero:
                continue

            change = curr_bal - prior_bal
            pct = None
            if not prior_bal.is_zero:
                pct = (change.amount / prior_bal.amount * 100).quantize(
                    Decimal("0.01"), rounding=ROUND_HALF_EVEN
                )

            report.lines.append(ComparativeLine(
                account_number=acct.number,
                account_name=acct.name,
                current_amount=curr_bal,
                prior_amount=prior_bal,
                dollar_change=change,
                pct_change=pct,
            ))

            if acct.account_type == AccountType.ASSET:
                current_total += curr_bal.amount
                prior_total += prior_bal.amount

        report.current_total = Money(current_total, self._currency)
        report.prior_total = Money(prior_total, self._currency)

        # Add common-size percentages
        if current_total > 0 or prior_total > 0:
            for line in report.lines:
                if current_total > 0:
                    line.current_common_size = (
                        line.current_amount.amount / current_total * 100
                    ).quantize(Decimal("0.01"))
                if prior_total > 0:
                    line.prior_common_size = (
                        line.prior_amount.amount / prior_total * 100
                    ).quantize(Decimal("0.01"))

        return report

    def income_statement_comparison(
        self,
        current_start: date,
        current_end: date,
        prior_start: date,
        prior_end: date,
    ) -> ComparativeReport:
        """Compare income statements for two periods."""
        report = ComparativeReport(
            title="Comparative Income Statement",
            current_period=f"{current_start} to {current_end}",
            prior_period=f"{prior_start} to {prior_end}",
            currency=self._currency,
        )

        current_revenue_total = Decimal("0")
        prior_revenue_total = Decimal("0")

        for acct in self._ledger.chart.get_income_statement_accounts():
            curr_bal = self._period_change(acct.number, current_start, current_end)
            prior_bal = self._period_change(acct.number, prior_start, prior_end)

            if curr_bal.is_zero and prior_bal.is_zero:
                continue

            change = curr_bal - prior_bal
            pct = None
            if not prior_bal.is_zero:
                pct = (change.amount / prior_bal.amount * 100).quantize(
                    Decimal("0.01"), rounding=ROUND_HALF_EVEN
                )

            report.lines.append(ComparativeLine(
                account_number=acct.number,
                account_name=acct.name,
                current_amount=curr_bal,
                prior_amount=prior_bal,
                dollar_change=change,
                pct_change=pct,
            ))

            if acct.account_type == AccountType.REVENUE:
                current_revenue_total += curr_bal.amount
                prior_revenue_total += prior_bal.amount

        # Common-size: each item as % of revenue
        for line in report.lines:
            if current_revenue_total > 0:
                line.current_common_size = (
                    line.current_amount.amount / current_revenue_total * 100
                ).quantize(Decimal("0.01"))
            if prior_revenue_total > 0:
                line.prior_common_size = (
                    line.prior_amount.amount / prior_revenue_total * 100
                ).quantize(Decimal("0.01"))

        return report

    def trend_analysis(
        self,
        account_number: str,
        dates: list[date],
    ) -> list[tuple[date, Money, Decimal | None]]:
        """Get balance at multiple dates with period-over-period change."""
        results = []
        prev: Money | None = None
        for d in sorted(dates):
            bal = self._ledger.get_account_balance(
                account_number, d, self._currency
            )
            pct = None
            if prev is not None and not prev.is_zero:
                change = bal - prev
                pct = (change.amount / prev.amount * 100).quantize(
                    Decimal("0.01"), rounding=ROUND_HALF_EVEN
                )
            results.append((d, bal, pct))
            prev = bal
        return results

    def _period_change(self, account_number: str, start: date, end: date) -> Money:
        """Net change in an account during a period."""
        from ledgercore.core.account import NormalBalance
        account = self._ledger.chart.get_account_or_raise(account_number)
        postings = self._ledger.get_account_postings(account_number, start, end)
        total_debit = Decimal("0")
        total_credit = Decimal("0")
        for p in postings:
            if p.debit and p.debit.currency == self._currency:
                total_debit += p.debit.amount
            if p.credit and p.credit.currency == self._currency:
                total_credit += p.credit.amount
        if account.normal_balance == NormalBalance.DEBIT:
            return Money(total_debit - total_credit, self._currency)
        return Money(total_credit - total_debit, self._currency)
