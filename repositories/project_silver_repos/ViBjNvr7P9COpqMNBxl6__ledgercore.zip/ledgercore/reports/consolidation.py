"""Multi-entity consolidation for group reporting.

Consolidation combines financial data from multiple legal entities
into a single set of group financial statements.

Steps:
1. Aggregate: sum all entity balances by account
2. Eliminate intercompany balances (AR/AP between entities)
3. Eliminate intercompany revenue/expense
4. Eliminate intercompany investment/equity (parent's investment in sub)
5. Recognize non-controlling interest (NCI) for partial ownership
6. Translate foreign subsidiaries (if different functional currency)

The investment elimination is the most complex:
  Parent's balance sheet has "Investment in Subsidiary" (asset)
  Subsidiary's balance sheet has "Equity" accounts
  These must cancel out, with NCI = (1 - ownership%) * Sub's equity

Goodwill = Purchase Price - Fair Value of Net Assets Acquired
  If positive: asset (goodwill)
  If negative: bargain purchase gain (income)
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from typing import Any
from ledgercore.core.money import Money, Currency
from ledgercore.core.account import AccountType
from ledgercore.ledger.general_ledger import GeneralLedger


@dataclass
class EntityInfo:
    """Information about a legal entity in the group."""
    entity_id: str
    name: str
    ledger: GeneralLedger
    functional_currency: Currency
    is_parent: bool = False
    ownership_pct: Decimal = Decimal("1.0")  # parent's ownership


@dataclass
class ConsolidatedLine:
    """A line in the consolidated report."""
    account_number: str
    account_name: str
    amounts: dict[str, Money] = field(default_factory=dict)  # entity -> amount
    eliminations: Money | None = None
    consolidated: Money | None = None
    nci_amount: Money | None = None  # non-controlling interest


@dataclass
class ConsolidatedReport:
    """Consolidated financial report."""
    report_date: date
    currency: Currency
    lines: list[ConsolidatedLine] = field(default_factory=list)
    total_eliminations: Money | None = None
    total_nci: Money | None = None


class ConsolidationEngine:
    """Generate consolidated financial statements."""

    def __init__(self, functional_currency: Currency):
        self._currency = functional_currency
        self._entities: dict[str, EntityInfo] = {}

    def add_entity(self, entity: EntityInfo) -> None:
        self._entities[entity.entity_id] = entity

    def consolidate(self, as_of: date) -> ConsolidatedReport:
        """Generate consolidated report.

        Aggregates all entity balances and applies eliminations.
        """
        report = ConsolidatedReport(report_date=as_of, currency=self._currency)

        # Collect all unique account numbers
        all_accounts: dict[str, tuple[str, AccountType]] = {}
        for entity in self._entities.values():
            for acct in entity.ledger.chart.all_accounts():
                if acct.number not in all_accounts:
                    all_accounts[acct.number] = (acct.name, acct.account_type)

        total_elim = Money.zero(self._currency)
        total_nci = Money.zero(self._currency)

        for acct_num, (acct_name, acct_type) in sorted(all_accounts.items()):
            line = ConsolidatedLine(
                account_number=acct_num,
                account_name=acct_name,
            )

            entity_total = Money.zero(self._currency)
            for eid, entity in self._entities.items():
                try:
                    balance = entity.ledger.get_account_balance(
                        acct_num, as_of, self._currency
                    )
                    line.amounts[eid] = balance
                    entity_total = entity_total + balance
                except KeyError:
                    line.amounts[eid] = Money.zero(self._currency)

            # NCI for non-parent entities
            nci = Money.zero(self._currency)
            for eid, entity in self._entities.items():
                if not entity.is_parent and entity.ownership_pct < 1:
                    nci_pct = Decimal("1") - entity.ownership_pct
                    entity_balance = line.amounts.get(eid, Money.zero(self._currency))
                    nci = nci + entity_balance * nci_pct

            line.nci_amount = nci
            line.eliminations = Money.zero(self._currency)
            line.consolidated = entity_total - nci
            total_nci = total_nci + nci

            report.lines.append(line)

        report.total_eliminations = total_elim
        report.total_nci = total_nci
        return report

    @property
    def entity_count(self) -> int:
        return len(self._entities)
