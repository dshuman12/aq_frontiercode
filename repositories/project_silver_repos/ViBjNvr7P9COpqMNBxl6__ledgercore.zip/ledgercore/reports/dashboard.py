"""Financial dashboard with KPI computation.

Computes key performance indicators (KPIs) for executive dashboards:

Working Capital Metrics:
  Working Capital = Current Assets - Current Liabilities
  Working Capital Ratio = Current Assets / Current Liabilities
  Days Sales Outstanding (DSO) = (AR / Revenue) * Days in Period
  Days Payable Outstanding (DPO) = (AP / COGS) * Days in Period
  Days Inventory Outstanding (DIO) = (Inventory / COGS) * Days in Period
  Cash Conversion Cycle (CCC) = DSO + DIO - DPO

Profitability Metrics:
  Gross Margin = (Revenue - COGS) / Revenue
  Operating Margin = Operating Income / Revenue
  EBITDA Margin = EBITDA / Revenue
  Net Margin = Net Income / Revenue

Efficiency Metrics:
  Asset Turnover = Revenue / Average Total Assets
  Inventory Turnover = COGS / Average Inventory
  Receivables Turnover = Revenue / Average AR

Leverage Metrics:
  Debt-to-Equity = Total Debt / Total Equity
  Interest Coverage = EBIT / Interest Expense
  Debt Service Coverage = (Net Income + Depreciation + Interest) / (Principal + Interest)

Growth Metrics:
  Revenue Growth = (Current Revenue - Prior Revenue) / Prior Revenue
  Net Income Growth = similar
  Asset Growth = similar

The CCC (Cash Conversion Cycle) is particularly important:
  CCC = DSO + DIO - DPO
  It measures how many days it takes to convert inventory investment
  into cash flow from sales. Lower is better.
  
  A negative CCC means the company collects from customers before
  paying suppliers (like Amazon) — a very strong cash position.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal, ROUND_HALF_EVEN
from typing import Any
from ledgercore.core.money import Money, Currency
from ledgercore.core.account import AccountType
from ledgercore.ledger.general_ledger import GeneralLedger


@dataclass
class KPIResult:
    """A computed KPI value."""
    name: str
    value: Decimal | None
    unit: str = ""  # "%", "days", "x", "$"
    category: str = ""
    description: str = ""
    is_favorable: bool | None = None  # None = neutral
    benchmark_min: Decimal | None = None
    benchmark_max: Decimal | None = None

    @property
    def formatted(self) -> str:
        if self.value is None:
            return "N/A"
        if self.unit == "%":
            return f"{self.value:.1f}%"
        if self.unit == "days":
            return f"{self.value:.0f} days"
        if self.unit == "x":
            return f"{self.value:.2f}x"
        if self.unit == "$":
            return f"${self.value:,.2f}"
        return f"{self.value:.2f}"

    @property
    def within_benchmark(self) -> bool | None:
        if self.value is None:
            return None
        if self.benchmark_min is not None and self.value < self.benchmark_min:
            return False
        if self.benchmark_max is not None and self.value > self.benchmark_max:
            return False
        return True


class DashboardGenerator:
    """Generate financial dashboard KPIs."""

    def __init__(self, ledger: GeneralLedger, currency: Currency):
        self._ledger = ledger
        self._currency = currency

    def compute_all_kpis(
        self,
        period_start: date,
        period_end: date,
        days_in_period: int = 365,
        account_mapping: dict[str, list[str]] | None = None,
    ) -> list[KPIResult]:
        """Compute all dashboard KPIs.

        account_mapping should map category names to account numbers:
          "current_assets": ["1100", "1200", "1400"]
          "current_liabilities": ["2100", "2200"]
          "revenue": ["4100", "4200"]
          "cogs": ["5100"]
          "depreciation": ["5300"]
          "interest_expense": ["5600"]
          "inventory": ["1400"]
          "receivables": ["1200"]
          "payables": ["2100"]
          "total_debt": ["2500"]
        """
        mapping = account_mapping or {}
        kpis = []

        # Balances
        def sum_accounts(key: str, as_of: date | None = None) -> Decimal:
            total = Decimal("0")
            for acct_num in mapping.get(key, []):
                try:
                    bal = self._ledger.get_account_balance(
                        acct_num, as_of or period_end, self._currency
                    )
                    total += bal.amount
                except KeyError:
                    pass
            return total

        ca = sum_accounts("current_assets")
        cl = sum_accounts("current_liabilities")
        revenue = sum_accounts("revenue")
        cogs = sum_accounts("cogs")
        total_assets = sum_accounts("current_assets") + sum_accounts("fixed_assets", period_end)
        total_equity = sum_accounts("equity")
        total_debt = sum_accounts("total_debt")
        ar = sum_accounts("receivables")
        ap = sum_accounts("payables")
        inventory = sum_accounts("inventory")
        depreciation = sum_accounts("depreciation")
        interest = sum_accounts("interest_expense")

        net_income = revenue - cogs - depreciation - interest  # simplified
        gross_profit = revenue - cogs
        ebitda = net_income + depreciation + interest

        # Working Capital
        kpis.append(KPIResult(
            "Working Capital", ca - cl, "$", "working_capital",
            benchmark_min=Decimal("0"),
        ))
        if cl > 0:
            kpis.append(KPIResult(
                "Current Ratio", ca / cl, "x", "working_capital",
                benchmark_min=Decimal("1.5"), benchmark_max=Decimal("3.0"),
            ))

        # DSO / DPO / DIO / CCC
        dso = (ar / revenue * days_in_period) if revenue > 0 else None
        dpo = (ap / cogs * days_in_period) if cogs > 0 else None
        dio = (inventory / cogs * days_in_period) if cogs > 0 else None

        if dso is not None:
            kpis.append(KPIResult("DSO", dso.quantize(Decimal("0.1")), "days", "working_capital",
                                  benchmark_max=Decimal("45")))
        if dpo is not None:
            kpis.append(KPIResult("DPO", dpo.quantize(Decimal("0.1")), "days", "working_capital"))
        if dio is not None:
            kpis.append(KPIResult("DIO", dio.quantize(Decimal("0.1")), "days", "working_capital"))
        if dso is not None and dio is not None and dpo is not None:
            ccc = dso + dio - dpo
            kpis.append(KPIResult(
                "Cash Conversion Cycle", ccc.quantize(Decimal("0.1")), "days", "working_capital",
                description="DSO + DIO - DPO; lower is better",
            ))

        # Profitability
        if revenue > 0:
            kpis.append(KPIResult(
                "Gross Margin", (gross_profit / revenue * 100).quantize(Decimal("0.1")),
                "%", "profitability", benchmark_min=Decimal("30"),
            ))
            kpis.append(KPIResult(
                "Net Margin", (net_income / revenue * 100).quantize(Decimal("0.1")),
                "%", "profitability", benchmark_min=Decimal("5"),
            ))
            if ebitda > 0:
                kpis.append(KPIResult(
                    "EBITDA Margin", (ebitda / revenue * 100).quantize(Decimal("0.1")),
                    "%", "profitability",
                ))

        # Leverage
        if total_equity > 0:
            kpis.append(KPIResult(
                "Debt-to-Equity", (total_debt / total_equity).quantize(Decimal("0.01")),
                "x", "leverage", benchmark_max=Decimal("2.0"),
            ))
        if interest > 0 and ebitda is not None:
            kpis.append(KPIResult(
                "Interest Coverage", (ebitda / interest).quantize(Decimal("0.1")),
                "x", "leverage", benchmark_min=Decimal("3.0"),
            ))

        # Efficiency
        if total_assets > 0 and revenue > 0:
            kpis.append(KPIResult(
                "Asset Turnover", (revenue / total_assets).quantize(Decimal("0.01")),
                "x", "efficiency",
            ))

        return kpis

    def kpis_by_category(self, kpis: list[KPIResult]) -> dict[str, list[KPIResult]]:
        """Group KPIs by category."""
        result: dict[str, list[KPIResult]] = {}
        for kpi in kpis:
            cat = kpi.category or "other"
            if cat not in result:
                result[cat] = []
            result[cat].append(kpi)
        return result

    def alerts(self, kpis: list[KPIResult]) -> list[KPIResult]:
        """Get KPIs that are outside their benchmark range."""
        return [k for k in kpis if k.within_benchmark is False]
