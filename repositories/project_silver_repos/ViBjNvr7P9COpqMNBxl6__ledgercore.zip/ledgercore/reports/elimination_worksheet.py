"""Consolidation elimination worksheet.

In consolidated financial statements, intercompany transactions must
be eliminated to prevent double-counting. The elimination worksheet
is a structured log of all eliminations applied.

Types of eliminations:

1. INVESTMENT ELIMINATION (most complex):
   Parent's "Investment in Subsidiary" (asset) must cancel against
   Subsidiary's equity accounts. The difference is goodwill or NCI.

   Dr. Common Stock (Sub's)
   Dr. Retained Earnings (Sub's)
   Dr. Goodwill (if purchase price > fair value of net assets)
     Cr. Investment in Subsidiary (Parent's)
     Cr. Non-Controlling Interest (if < 100% owned)

2. INTERCOMPANY REVENUE/EXPENSE:
   Dr. Intercompany Revenue
     Cr. Intercompany Expense

3. INTERCOMPANY RECEIVABLES/PAYABLES:
   Dr. Intercompany Payable
     Cr. Intercompany Receivable

4. UNREALIZED INTERCOMPANY PROFIT:
   If parent sells inventory to sub at a markup, and sub hasn't
   sold it externally yet, the profit is unrealized.
   Dr. Revenue (or Retained Earnings if prior period)
     Cr. Inventory (or COGS)

5. INTERCOMPANY DIVIDENDS:
   Parent records dividend income from sub.
   Eliminate: Dr. Dividend Income, Cr. Dividends Declared

The worksheet tracks each elimination as a separate adjustment
entry, with full audit trail of why it was made.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from typing import Any
from ledgercore.core.money import Money, Currency
from ledgercore.core.entry import JournalEntry, EntryType


class EliminationType:
    INVESTMENT = "investment"
    REVENUE_EXPENSE = "revenue_expense"
    RECEIVABLE_PAYABLE = "receivable_payable"
    UNREALIZED_PROFIT = "unrealized_profit"
    DIVIDENDS = "dividends"
    GOODWILL_IMPAIRMENT = "goodwill_impairment"


@dataclass
class EliminationEntry:
    """A single elimination in the consolidation worksheet."""
    elimination_id: str
    elimination_type: str
    description: str
    journal_entry: JournalEntry
    parent_entity: str = ""
    subsidiary_entity: str = ""
    amount: Money | None = None
    is_recurring: bool = False  # same elimination every period
    notes: str = ""


@dataclass
class InvestmentEliminationData:
    """Data needed for investment elimination."""
    parent_investment_account: str
    parent_investment_amount: Money
    sub_equity_accounts: dict[str, Money]  # account -> balance
    ownership_pct: Decimal
    fair_value_adjustments: dict[str, Money] = field(default_factory=dict)
    goodwill_account: str = "1700"
    nci_account: str = "3500"


class EliminationWorksheet:
    """Consolidation elimination worksheet."""

    def __init__(self, currency: Currency):
        self._currency = currency
        self._eliminations: list[EliminationEntry] = []

    def add_elimination(self, entry: EliminationEntry) -> None:
        self._eliminations.append(entry)

    def generate_investment_elimination(
        self,
        data: InvestmentEliminationData,
        entry_id: str,
        consolidation_date: date,
    ) -> EliminationEntry:
        """Generate the investment elimination entry.

        This is the most complex elimination:
        1. Eliminate parent's investment account
        2. Eliminate subsidiary's equity accounts
        3. Recognize goodwill (purchase price > fair value of net assets)
        4. Recognize NCI (non-controlling interest for < 100% ownership)
        """
        entry = JournalEntry(
            entry_id=entry_id,
            entry_date=consolidation_date,
            description="Investment elimination",
            entry_type=EntryType.ADJUSTING,
        )

        # Debit: eliminate sub's equity accounts
        sub_equity_total = Decimal("0")
        for acct, balance in data.sub_equity_accounts.items():
            entry.add_debit(acct, balance)
            sub_equity_total += balance.amount

        # Fair value adjustments
        fv_adj_total = Decimal("0")
        for acct, adj in data.fair_value_adjustments.items():
            if adj.is_positive:
                entry.add_debit(acct, adj)
            else:
                entry.add_credit(acct, abs(adj))
            fv_adj_total += adj.amount

        # Net assets at fair value
        net_assets_fv = sub_equity_total + fv_adj_total

        # Parent's share of net assets
        parent_share = Money(
            net_assets_fv * data.ownership_pct, self._currency
        )

        # Goodwill = Investment - Parent's share of FV net assets
        goodwill_amount = data.parent_investment_amount - parent_share
        if goodwill_amount.is_positive:
            entry.add_debit(data.goodwill_account, goodwill_amount)

        # NCI = (1 - ownership%) * Sub's equity
        if data.ownership_pct < 1:
            nci_pct = Decimal("1") - data.ownership_pct
            nci_amount = Money(sub_equity_total * nci_pct, self._currency)
            entry.add_credit(data.nci_account, nci_amount)

        # Credit: eliminate parent's investment
        entry.add_credit(
            data.parent_investment_account,
            data.parent_investment_amount,
        )

        elim = EliminationEntry(
            elimination_id=entry_id,
            elimination_type=EliminationType.INVESTMENT,
            description="Investment in subsidiary elimination",
            journal_entry=entry,
            amount=data.parent_investment_amount,
        )
        self._eliminations.append(elim)
        return elim

    def generate_intercompany_revenue_elimination(
        self,
        entry_id: str,
        consolidation_date: date,
        revenue_account: str,
        expense_account: str,
        amount: Money,
        description: str = "",
    ) -> EliminationEntry:
        """Eliminate intercompany revenue and expense."""
        entry = JournalEntry(
            entry_id=entry_id,
            entry_date=consolidation_date,
            description=description or "IC revenue/expense elimination",
            entry_type=EntryType.ADJUSTING,
        )
        entry.add_debit(revenue_account, amount)
        entry.add_credit(expense_account, amount)

        elim = EliminationEntry(
            elimination_id=entry_id,
            elimination_type=EliminationType.REVENUE_EXPENSE,
            description=description,
            journal_entry=entry,
            amount=amount,
            is_recurring=True,
        )
        self._eliminations.append(elim)
        return elim

    def generate_intercompany_balance_elimination(
        self,
        entry_id: str,
        consolidation_date: date,
        receivable_account: str,
        payable_account: str,
        amount: Money,
    ) -> EliminationEntry:
        """Eliminate intercompany receivables and payables."""
        entry = JournalEntry(
            entry_id=entry_id,
            entry_date=consolidation_date,
            description="IC receivable/payable elimination",
            entry_type=EntryType.ADJUSTING,
        )
        entry.add_debit(payable_account, amount)
        entry.add_credit(receivable_account, amount)

        elim = EliminationEntry(
            elimination_id=entry_id,
            elimination_type=EliminationType.RECEIVABLE_PAYABLE,
            description="Intercompany balance elimination",
            journal_entry=entry,
            amount=amount,
        )
        self._eliminations.append(elim)
        return elim

    def generate_unrealized_profit_elimination(
        self,
        entry_id: str,
        consolidation_date: date,
        profit_amount: Money,
        revenue_or_re_account: str,
        inventory_or_cogs_account: str,
        is_current_period: bool = True,
    ) -> EliminationEntry:
        """Eliminate unrealized intercompany profit in inventory.

        Current period: Dr. Revenue, Cr. Inventory
        Prior period: Dr. Retained Earnings, Cr. COGS
        """
        entry = JournalEntry(
            entry_id=entry_id,
            entry_date=consolidation_date,
            description="Unrealized IC profit elimination",
            entry_type=EntryType.ADJUSTING,
        )
        entry.add_debit(revenue_or_re_account, profit_amount)
        entry.add_credit(inventory_or_cogs_account, profit_amount)

        elim = EliminationEntry(
            elimination_id=entry_id,
            elimination_type=EliminationType.UNREALIZED_PROFIT,
            description="Unrealized intercompany profit",
            journal_entry=entry,
            amount=profit_amount,
        )
        self._eliminations.append(elim)
        return elim

    def all_entries(self) -> list[JournalEntry]:
        return [e.journal_entry for e in self._eliminations]

    def by_type(self, elim_type: str) -> list[EliminationEntry]:
        return [e for e in self._eliminations if e.elimination_type == elim_type]

    def total_eliminations(self) -> Money:
        total = Money.zero(self._currency)
        for e in self._eliminations:
            if e.amount:
                total = total + e.amount
        return total

    @property
    def elimination_count(self) -> int:
        return len(self._eliminations)

    def verify_all_balanced(self) -> list[str]:
        errors = []
        for e in self._eliminations:
            if not e.journal_entry.is_balanced:
                errors.append(f"Elimination {e.elimination_id} is unbalanced")
        return errors
