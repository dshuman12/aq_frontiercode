"""Accounts receivable and payable aging analysis.

Aging reports categorize outstanding balances by how long they've
been outstanding:
  Current (0-30 days)
  31-60 days
  61-90 days
  91-120 days
  Over 120 days

This is critical for:
1. Estimating bad debt allowance
2. Cash flow forecasting
3. Credit management decisions

The aging calculation is date-sensitive: the "age" of an invoice
is calculated from its due date (not invoice date) to the report date.

Aging can be done on:
- Invoice date: how old is the invoice
- Due date: how overdue is the payment

The difference matters: a Net-30 invoice created today is 0 days old
by invoice date but won't be due for 30 days.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from typing import Any
from ledgercore.core.money import Money, Currency


@dataclass
class AgingBucket:
    """An aging time bucket."""
    label: str
    min_days: int
    max_days: int | None  # None = unlimited
    total: Money = field(default_factory=lambda: Money(0, Currency("USD", "$")))
    items: list[AgingItem] = field(default_factory=list)


@dataclass
class AgingItem:
    """A single outstanding item in the aging report."""
    reference: str  # invoice number
    counterparty: str  # customer/vendor name
    invoice_date: date
    due_date: date
    amount: Money
    days_outstanding: int = 0


@dataclass
class AgingReport:
    """Complete aging analysis report."""
    report_date: date
    report_type: str  # "receivable" or "payable"
    currency: Currency
    buckets: list[AgingBucket] = field(default_factory=list)
    total: Money = field(default_factory=lambda: Money(0, Currency("USD", "$")))

    def summary(self) -> dict[str, Money]:
        return {b.label: b.total for b in self.buckets}


class AgingAnalyzer:
    """Generate aging reports for receivables and payables."""

    DEFAULT_BUCKETS = [
        (0, 30, "Current"),
        (31, 60, "31-60 Days"),
        (61, 90, "61-90 Days"),
        (91, 120, "91-120 Days"),
        (121, None, "Over 120 Days"),
    ]

    def __init__(self, currency: Currency):
        self._currency = currency

    def analyze(
        self,
        items: list[AgingItem],
        report_date: date,
        report_type: str = "receivable",
        bucket_config: list[tuple[int, int | None, str]] | None = None,
    ) -> AgingReport:
        """Generate an aging report.

        Args:
            items: list of outstanding invoices/bills
            report_date: the date to calculate aging from
            report_type: "receivable" or "payable"
            bucket_config: custom bucket definitions
        """
        config = bucket_config or self.DEFAULT_BUCKETS
        buckets = [
            AgingBucket(
                label=label,
                min_days=min_d,
                max_days=max_d,
                total=Money.zero(self._currency),
            )
            for min_d, max_d, label in config
        ]

        total = Money.zero(self._currency)

        for item in items:
            item.days_outstanding = (report_date - item.due_date).days
            if item.days_outstanding < 0:
                item.days_outstanding = 0  # not yet due

            placed = False
            for bucket in buckets:
                if bucket.max_days is None:
                    if item.days_outstanding >= bucket.min_days:
                        bucket.items.append(item)
                        bucket.total = bucket.total + item.amount
                        placed = True
                        break
                elif bucket.min_days <= item.days_outstanding <= bucket.max_days:
                    bucket.items.append(item)
                    bucket.total = bucket.total + item.amount
                    placed = True
                    break

            if not placed and buckets:
                buckets[-1].items.append(item)
                buckets[-1].total = buckets[-1].total + item.amount

            total = total + item.amount

        return AgingReport(
            report_date=report_date,
            report_type=report_type,
            currency=self._currency,
            buckets=buckets,
            total=total,
        )

    def estimate_bad_debt(
        self,
        report: AgingReport,
        rates: dict[str, Decimal] | None = None,
    ) -> Money:
        """Estimate bad debt allowance based on aging percentages.

        Default rates:
          Current: 1%
          31-60: 5%
          61-90: 15%
          91-120: 40%
          Over 120: 80%
        """
        default_rates = {
            "Current": Decimal("0.01"),
            "31-60 Days": Decimal("0.05"),
            "61-90 Days": Decimal("0.15"),
            "91-120 Days": Decimal("0.40"),
            "Over 120 Days": Decimal("0.80"),
        }
        use_rates = rates or default_rates
        total_allowance = Money.zero(self._currency)

        for bucket in report.buckets:
            rate = use_rates.get(bucket.label, Decimal("0"))
            allowance = bucket.total * rate
            total_allowance = total_allowance + allowance

        return total_allowance
