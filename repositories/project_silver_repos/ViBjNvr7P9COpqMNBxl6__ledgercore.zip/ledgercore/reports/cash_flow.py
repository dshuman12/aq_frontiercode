"""Cash flow statement generation (indirect method).

The cash flow statement reconciles net income to cash flow by
adjusting for non-cash items and changes in working capital.

Three sections:
1. Operating Activities (indirect method):
   Start with Net Income
   + Depreciation/amortization (non-cash expense added back)
   + Loss on asset disposal / - Gain on asset disposal
   - Increase in current assets (cash used to fund growth)
   + Increase in current liabilities (cash preserved)
   = Cash from Operations

2. Investing Activities:
   - Purchase of fixed assets
   + Sale of fixed assets
   - Purchase of investments
   + Sale of investments
   = Cash from Investing

3. Financing Activities:
   + Issuance of debt
   - Repayment of debt
   + Issuance of stock
   - Dividends paid
   - Treasury stock purchased
   = Cash from Financing

Net Change in Cash = Operating + Investing + Financing
Ending Cash = Beginning Cash + Net Change

The indirect method requires knowing which accounts are "operating",
"investing", or "financing" — this classification is a judgment call
and must be configured.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from typing import Any
from ledgercore.core.money import Money, Currency
from ledgercore.core.account import AccountType
from ledgercore.ledger.general_ledger import GeneralLedger


@dataclass
class CashFlowLine:
    """A line item in the cash flow statement."""
    description: str
    amount: Money
    category: str = ""  # sub-category within the section


@dataclass
class CashFlowStatement:
    """Complete cash flow statement."""
    start_date: date
    end_date: date
    currency: Currency
    operating: list[CashFlowLine] = field(default_factory=list)
    investing: list[CashFlowLine] = field(default_factory=list)
    financing: list[CashFlowLine] = field(default_factory=list)
    net_income: Money | None = None
    cash_from_operations: Money | None = None
    cash_from_investing: Money | None = None
    cash_from_financing: Money | None = None
    net_change: Money | None = None
    beginning_cash: Money | None = None
    ending_cash: Money | None = None


class CashFlowGenerator:
    """Generate cash flow statement from ledger data."""

    def __init__(
        self,
        ledger: GeneralLedger,
        currency: Currency,
        cash_accounts: set[str] | None = None,
        depreciation_accounts: set[str] | None = None,
    ):
        self._ledger = ledger
        self._currency = currency
        self._cash_accounts = cash_accounts or set()
        self._depreciation_accounts = depreciation_accounts or set()

    def generate(
        self,
        start_date: date,
        end_date: date,
        net_income: Money,
    ) -> CashFlowStatement:
        """Generate cash flow statement (indirect method)."""
        stmt = CashFlowStatement(
            start_date=start_date,
            end_date=end_date,
            currency=self._currency,
            net_income=net_income,
        )

        # Operating activities start with net income
        operating_total = net_income.amount

        # Add back depreciation
        for acct_num in self._depreciation_accounts:
            bal = self._period_change(acct_num, start_date, end_date)
            if not bal.is_zero:
                stmt.operating.append(
                    CashFlowLine(f"Depreciation ({acct_num})", bal)
                )
                operating_total += bal.amount

        # Changes in working capital (current assets and liabilities)
        chart = self._ledger.chart
        for acct in chart.all_accounts():
            if acct.number in self._cash_accounts:
                continue  # skip cash accounts themselves
            if acct.number in self._depreciation_accounts:
                continue
            if not acct.is_balance_sheet:
                continue

            change = self._period_change(acct.number, start_date, end_date)
            if change.is_zero:
                continue

            if acct.account_type == AccountType.ASSET:
                # Increase in assets = cash used (negative)
                adjustment = -change
                stmt.operating.append(
                    CashFlowLine(f"Change in {acct.name}", adjustment)
                )
                operating_total += adjustment.amount
            elif acct.account_type == AccountType.LIABILITY:
                # Increase in liabilities = cash preserved (positive)
                stmt.operating.append(
                    CashFlowLine(f"Change in {acct.name}", change)
                )
                operating_total += change.amount

        stmt.cash_from_operations = Money(operating_total, self._currency)
        stmt.cash_from_investing = Money.zero(self._currency)
        stmt.cash_from_financing = Money.zero(self._currency)
        stmt.net_change = Money(operating_total, self._currency)

        # Beginning and ending cash
        beginning = Money.zero(self._currency)
        ending = Money.zero(self._currency)
        for acct_num in self._cash_accounts:
            prev_date = date(start_date.year, start_date.month, start_date.day)
            prev_date = prev_date.replace(day=1) if start_date.day > 1 else prev_date
            beg = self._ledger.get_account_balance(acct_num, start_date, self._currency)
            end = self._ledger.get_account_balance(acct_num, end_date, self._currency)
            beginning = beginning + beg
            ending = ending + end

        stmt.beginning_cash = beginning
        stmt.ending_cash = ending

        return stmt

    def _period_change(self, account_number: str, start: date, end: date) -> Money:
        """Calculate the change in an account's balance during a period."""
        start_bal = self._ledger.get_account_balance(
            account_number, start, self._currency
        )
        end_bal = self._ledger.get_account_balance(
            account_number, end, self._currency
        )
        return end_bal - start_bal
