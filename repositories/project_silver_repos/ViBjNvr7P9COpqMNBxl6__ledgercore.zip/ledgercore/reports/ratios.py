"""Financial ratio analysis.

Computes key financial ratios from the general ledger:

Liquidity Ratios:
  Current Ratio = Current Assets / Current Liabilities
  Quick Ratio = (Cash + Receivables) / Current Liabilities
  Cash Ratio = Cash / Current Liabilities

Profitability Ratios:
  Gross Margin = Gross Profit / Revenue
  Net Margin = Net Income / Revenue
  ROA = Net Income / Total Assets
  ROE = Net Income / Shareholders' Equity

Efficiency Ratios:
  Inventory Turnover = COGS / Average Inventory
  Receivables Turnover = Revenue / Average Receivables
  Days Sales Outstanding = 365 / Receivables Turnover
  Asset Turnover = Revenue / Total Assets

Leverage Ratios:
  Debt to Equity = Total Liabilities / Shareholders' Equity
  Debt Ratio = Total Liabilities / Total Assets
  Interest Coverage = EBIT / Interest Expense

Each ratio has industry-standard thresholds for "healthy" ranges.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from typing import Any
from ledgercore.core.money import Money, Currency
from ledgercore.core.account import AccountType
from ledgercore.ledger.general_ledger import GeneralLedger


@dataclass
class RatioResult:
    """Result of a financial ratio calculation."""
    name: str
    value: Decimal | None
    category: str = ""  # "liquidity", "profitability", "efficiency", "leverage"
    description: str = ""
    healthy_min: Decimal | None = None
    healthy_max: Decimal | None = None

    @property
    def is_healthy(self) -> bool | None:
        if self.value is None:
            return None
        if self.healthy_min is not None and self.value < self.healthy_min:
            return False
        if self.healthy_max is not None and self.value > self.healthy_max:
            return False
        return True

    @property
    def formatted(self) -> str:
        if self.value is None:
            return "N/A"
        return f"{self.value:.2f}"


class RatioAnalyzer:
    """Compute financial ratios from ledger data."""

    def __init__(self, ledger: GeneralLedger, currency: Currency):
        self._ledger = ledger
        self._currency = currency

    def current_ratio(self, as_of: date) -> RatioResult:
        """Current Assets / Current Liabilities"""
        ca = self._sum_by_type(AccountType.ASSET, as_of)
        cl = self._sum_by_type(AccountType.LIABILITY, as_of)
        value = ca / cl if cl != 0 else None
        return RatioResult("Current Ratio", value, "liquidity",
                          healthy_min=Decimal("1.5"), healthy_max=Decimal("3.0"))

    def debt_to_equity(self, as_of: date) -> RatioResult:
        """Total Liabilities / Shareholders' Equity"""
        liab = self._sum_by_type(AccountType.LIABILITY, as_of)
        equity = self._sum_by_type(AccountType.EQUITY, as_of)
        value = Decimal(str(liab)) / Decimal(str(equity)) if equity != 0 else None
        return RatioResult("Debt to Equity", value, "leverage",
                          healthy_max=Decimal("2.0"))

    def debt_ratio(self, as_of: date) -> RatioResult:
        """Total Liabilities / Total Assets"""
        liab = self._sum_by_type(AccountType.LIABILITY, as_of)
        assets = self._sum_by_type(AccountType.ASSET, as_of)
        value = Decimal(str(liab)) / Decimal(str(assets)) if assets != 0 else None
        return RatioResult("Debt Ratio", value, "leverage",
                          healthy_max=Decimal("0.6"))

    def net_margin(self, start: date, end: date) -> RatioResult:
        """Net Income / Revenue"""
        revenue = self._sum_by_type(AccountType.REVENUE, end)
        expense = self._sum_by_type(AccountType.EXPENSE, end)
        net_income = revenue - expense
        value = Decimal(str(net_income)) / Decimal(str(revenue)) if revenue != 0 else None
        return RatioResult("Net Margin", value, "profitability",
                          healthy_min=Decimal("0.05"))

    def roa(self, start: date, end: date) -> RatioResult:
        """Return on Assets = Net Income / Total Assets"""
        revenue = self._sum_by_type(AccountType.REVENUE, end)
        expense = self._sum_by_type(AccountType.EXPENSE, end)
        net_income = revenue - expense
        assets = self._sum_by_type(AccountType.ASSET, end)
        value = Decimal(str(net_income)) / Decimal(str(assets)) if assets != 0 else None
        return RatioResult("Return on Assets", value, "profitability",
                          healthy_min=Decimal("0.05"))

    def roe(self, start: date, end: date) -> RatioResult:
        """Return on Equity = Net Income / Equity"""
        revenue = self._sum_by_type(AccountType.REVENUE, end)
        expense = self._sum_by_type(AccountType.EXPENSE, end)
        net_income = revenue - expense
        equity = self._sum_by_type(AccountType.EQUITY, end)
        value = Decimal(str(net_income)) / Decimal(str(equity)) if equity != 0 else None
        return RatioResult("Return on Equity", value, "profitability",
                          healthy_min=Decimal("0.10"))

    def all_ratios(self, as_of: date, period_start: date | None = None) -> list[RatioResult]:
        """Compute all available ratios."""
        results = [
            self.current_ratio(as_of),
            self.debt_to_equity(as_of),
            self.debt_ratio(as_of),
        ]
        if period_start:
            results.extend([
                self.net_margin(period_start, as_of),
                self.roa(period_start, as_of),
                self.roe(period_start, as_of),
            ])
        return results

    def _sum_by_type(self, acct_type: AccountType, as_of: date) -> Decimal:
        total = Decimal("0")
        for acct in self._ledger.chart.get_by_type(acct_type):
            bal = self._ledger.get_account_balance(acct.number, as_of, self._currency)
            total += bal.amount
        return total
