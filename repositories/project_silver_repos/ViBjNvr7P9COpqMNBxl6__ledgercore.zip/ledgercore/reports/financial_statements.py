"""Financial statement generation.

Three primary financial statements:

1. Balance Sheet (Statement of Financial Position):
   Assets = Liabilities + Equity
   Shows the financial position at a POINT IN TIME.

2. Income Statement (Profit & Loss):
   Revenue - Expenses = Net Income
   Shows performance over a PERIOD OF TIME.

3. Trial Balance:
   Total Debits = Total Credits
   Internal consistency check.

The key invariant: the Balance Sheet must ALWAYS balance.
If Assets != Liabilities + Equity, something is wrong.

The Income Statement's bottom line (Net Income) connects to the
Balance Sheet through Retained Earnings:
  Ending RE = Beginning RE + Net Income - Dividends

This means the Balance Sheet and Income Statement are not independent;
they share data through the Retained Earnings account.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from typing import Any
from ledgercore.core.money import Money, Currency
from ledgercore.core.account import AccountType
from ledgercore.ledger.general_ledger import GeneralLedger


@dataclass
class ReportLine:
    """A line item in a financial report."""
    account_number: str
    account_name: str
    amount: Money
    indent: int = 0
    is_total: bool = False
    is_subtotal: bool = False
    children: list[ReportLine] = field(default_factory=list)


@dataclass
class BalanceSheet:
    """Balance Sheet report."""
    as_of: date
    currency: Currency
    assets: list[ReportLine] = field(default_factory=list)
    liabilities: list[ReportLine] = field(default_factory=list)
    equity: list[ReportLine] = field(default_factory=list)
    total_assets: Money | None = None
    total_liabilities: Money | None = None
    total_equity: Money | None = None
    total_liabilities_equity: Money | None = None
    is_balanced: bool = False

    def verify(self) -> bool:
        """Verify Assets = Liabilities + Equity."""
        if self.total_assets and self.total_liabilities_equity:
            self.is_balanced = self.total_assets == self.total_liabilities_equity
        return self.is_balanced


@dataclass
class IncomeStatement:
    """Income Statement (P&L) report."""
    start_date: date
    end_date: date
    currency: Currency
    revenue: list[ReportLine] = field(default_factory=list)
    expenses: list[ReportLine] = field(default_factory=list)
    total_revenue: Money | None = None
    total_expenses: Money | None = None
    net_income: Money | None = None


class ReportGenerator:
    """Generate financial reports from the general ledger."""

    def __init__(self, ledger: GeneralLedger, currency: Currency):
        self._ledger = ledger
        self._currency = currency

    def balance_sheet(self, as_of: date) -> BalanceSheet:
        """Generate a balance sheet as of a given date.

        The balance sheet equation: Assets = Liabilities + Equity
        """
        chart = self._ledger.chart
        report = BalanceSheet(as_of=as_of, currency=self._currency)

        asset_total = Decimal("0")
        liability_total = Decimal("0")
        equity_total = Decimal("0")

        # Assets
        for acct in chart.get_by_type(AccountType.ASSET):
            bal = self._ledger.get_account_balance(acct.number, as_of, self._currency)
            if not bal.is_zero:
                report.assets.append(ReportLine(acct.number, acct.name, bal))
                asset_total += bal.amount

        # Contra-assets reduce total assets
        for acct in chart.get_by_type(AccountType.CONTRA_ASSET):
            bal = self._ledger.get_account_balance(acct.number, as_of, self._currency)
            if not bal.is_zero:
                report.assets.append(ReportLine(acct.number, acct.name, -bal))
                asset_total -= bal.amount

        # Liabilities
        for acct in chart.get_by_type(AccountType.LIABILITY):
            bal = self._ledger.get_account_balance(acct.number, as_of, self._currency)
            if not bal.is_zero:
                report.liabilities.append(ReportLine(acct.number, acct.name, bal))
                liability_total += bal.amount

        # Equity
        for acct in chart.get_by_type(AccountType.EQUITY):
            bal = self._ledger.get_account_balance(acct.number, as_of, self._currency)
            if not bal.is_zero:
                report.equity.append(ReportLine(acct.number, acct.name, bal))
                equity_total += bal.amount

        report.total_assets = Money(asset_total, self._currency)
        report.total_liabilities = Money(liability_total, self._currency)
        report.total_equity = Money(equity_total, self._currency)
        report.total_liabilities_equity = Money(
            liability_total + equity_total, self._currency
        )
        report.verify()
        return report

    def income_statement(self, start_date: date, end_date: date) -> IncomeStatement:
        """Generate an income statement for a period.

        Revenue - Expenses = Net Income
        """
        chart = self._ledger.chart
        report = IncomeStatement(
            start_date=start_date, end_date=end_date, currency=self._currency,
        )

        revenue_total = Decimal("0")
        expense_total = Decimal("0")

        for acct in chart.get_by_type(AccountType.REVENUE):
            # Revenue balance for the PERIOD (not cumulative)
            bal = self._period_balance(acct.number, start_date, end_date)
            if not bal.is_zero:
                report.revenue.append(ReportLine(acct.number, acct.name, bal))
                revenue_total += bal.amount

        for acct in chart.get_by_type(AccountType.EXPENSE):
            bal = self._period_balance(acct.number, start_date, end_date)
            if not bal.is_zero:
                report.expenses.append(ReportLine(acct.number, acct.name, bal))
                expense_total += bal.amount

        report.total_revenue = Money(revenue_total, self._currency)
        report.total_expenses = Money(expense_total, self._currency)
        report.net_income = Money(revenue_total - expense_total, self._currency)
        return report

    def _period_balance(self, account_number: str, start: date, end: date) -> Money:
        """Calculate the balance change for an account during a period.

        This is NOT the same as the cumulative balance. It's the NET
        change during the period (sum of debits - sum of credits for
        the period only, adjusted for normal balance).
        """
        account = self._ledger.chart.get_account_or_raise(account_number)
        postings = self._ledger.get_account_postings(account_number, start, end)

        total_debit = Decimal("0")
        total_credit = Decimal("0")

        for p in postings:
            if p.debit and p.debit.currency == self._currency:
                total_debit += p.debit.amount
            if p.credit and p.credit.currency == self._currency:
                total_credit += p.credit.amount

        from ledgercore.core.account import NormalBalance
        if account.normal_balance == NormalBalance.DEBIT:
            return Money(total_debit - total_credit, self._currency)
        else:
            return Money(total_credit - total_debit, self._currency)
