"""Revenue recognition under ASC 606 (5-step model).

ASC 606 requires a 5-step process for recognizing revenue:

1. Identify the contract with the customer
2. Identify the performance obligations in the contract
3. Determine the transaction price
4. Allocate the transaction price to the performance obligations
5. Recognize revenue when (or as) performance obligations are satisfied

Key concepts:
- Performance obligation: a promise to deliver a distinct good/service
- Point-in-time recognition: delivered at a moment (e.g., selling a product)
- Over-time recognition: delivered over a period (e.g., SaaS subscription)
- Variable consideration: estimated amounts (e.g., volume discounts, penalties)
- Contract modifications: changes to scope or price

Over-time recognition methods:
1. Output method: based on units delivered / total units
2. Input method: based on costs incurred / total expected costs
3. Time-based: straight-line over the service period

The complexity: multi-element arrangements where a single contract
has multiple obligations at different prices. The transaction price
must be allocated based on standalone selling prices, which may
require estimation.

Example: sell a phone ($800) + 2-year warranty ($200) for $900 total.
  Phone SSP = $800, Warranty SSP = $200, Total SSP = $1000
  Phone allocation = $900 * ($800/$1000) = $720
  Warranty allocation = $900 * ($200/$1000) = $180
  Phone: recognize $720 at delivery
  Warranty: recognize $180 over 24 months ($7.50/month)
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date, timedelta
from decimal import Decimal, ROUND_HALF_EVEN
from typing import Any
from ledgercore.core.money import Money, Currency
from ledgercore.core.entry import JournalEntry, EntryType


class RecognitionType:
    POINT_IN_TIME = "point_in_time"
    OVER_TIME_OUTPUT = "over_time_output"
    OVER_TIME_INPUT = "over_time_input"
    OVER_TIME_STRAIGHT_LINE = "over_time_straight_line"


@dataclass
class PerformanceObligation:
    """A single performance obligation in a contract."""
    obligation_id: str
    description: str
    standalone_selling_price: Money
    recognition_type: str = RecognitionType.POINT_IN_TIME
    # For over-time recognition
    service_start: date | None = None
    service_end: date | None = None
    # For output/input methods
    total_units: int = 0
    delivered_units: int = 0
    total_expected_cost: Money | None = None
    incurred_cost: Money | None = None
    # Allocated price (computed during allocation)
    allocated_price: Money | None = None
    # Tracking
    recognized_amount: Money | None = None
    is_satisfied: bool = False

    @property
    def completion_pct(self) -> Decimal:
        """Percentage of completion for over-time obligations."""
        if self.recognition_type == RecognitionType.OVER_TIME_OUTPUT:
            if self.total_units == 0:
                return Decimal("0")
            return Decimal(str(self.delivered_units)) / Decimal(str(self.total_units))
        if self.recognition_type == RecognitionType.OVER_TIME_INPUT:
            if self.total_expected_cost is None or self.total_expected_cost.is_zero:
                return Decimal("0")
            if self.incurred_cost is None:
                return Decimal("0")
            return self.incurred_cost.amount / self.total_expected_cost.amount
        if self.recognition_type == RecognitionType.OVER_TIME_STRAIGHT_LINE:
            if self.service_start is None or self.service_end is None:
                return Decimal("0")
            total_days = (self.service_end - self.service_start).days
            if total_days <= 0:
                return Decimal("1")
            elapsed = (date.today() - self.service_start).days
            return min(Decimal("1"), Decimal(str(elapsed)) / Decimal(str(total_days)))
        return Decimal("1") if self.is_satisfied else Decimal("0")

    @property
    def recognizable_amount(self) -> Money:
        """Amount that should be recognized so far."""
        if self.allocated_price is None:
            return Money.zero(self.standalone_selling_price.currency)
        recognized_so_far = self.recognized_amount or Money.zero(self.allocated_price.currency)
        target = self.allocated_price * self.completion_pct
        return target - recognized_so_far


@dataclass
class RevenueContract:
    """A customer contract with performance obligations."""
    contract_id: str
    customer_name: str
    contract_date: date
    transaction_price: Money
    obligations: list[PerformanceObligation] = field(default_factory=list)
    is_modified: bool = False
    modification_date: date | None = None
    deferred_revenue_account: str = "2400"
    revenue_account: str = "4100"
    receivable_account: str = "1200"

    def allocate_transaction_price(self) -> None:
        """Allocate transaction price to obligations based on relative SSP.

        This is step 4 of ASC 606.
        Allocation = Transaction Price * (SSP_i / Total SSP)
        """
        total_ssp = Decimal("0")
        for ob in self.obligations:
            total_ssp += ob.standalone_selling_price.amount
        if total_ssp == 0:
            return
        currency = self.transaction_price.currency
        allocated_total = Decimal("0")
        for i, ob in enumerate(self.obligations):
            if i == len(self.obligations) - 1:
                # Last obligation gets the remainder (avoids rounding issues)
                ob.allocated_price = Money(
                    self.transaction_price.amount - allocated_total, currency
                )
            else:
                share = ob.standalone_selling_price.amount / total_ssp
                amount = (self.transaction_price.amount * share).quantize(
                    Decimal("0.01"), rounding=ROUND_HALF_EVEN
                )
                ob.allocated_price = Money(amount, currency)
                allocated_total += amount

    @property
    def total_recognized(self) -> Money:
        currency = self.transaction_price.currency
        total = Money.zero(currency)
        for ob in self.obligations:
            if ob.recognized_amount:
                total = total + ob.recognized_amount
        return total

    @property
    def total_deferred(self) -> Money:
        return self.transaction_price - self.total_recognized


class RevenueRecognitionEngine:
    """Engine for ASC 606 revenue recognition."""

    def __init__(self, currency: Currency):
        self._currency = currency
        self._contracts: dict[str, RevenueContract] = {}

    def add_contract(self, contract: RevenueContract) -> None:
        contract.allocate_transaction_price()
        self._contracts[contract.contract_id] = contract

    def get_contract(self, contract_id: str) -> RevenueContract | None:
        return self._contracts.get(contract_id)

    def satisfy_obligation(
        self,
        contract_id: str,
        obligation_id: str,
    ) -> None:
        """Mark a point-in-time obligation as satisfied."""
        contract = self._contracts.get(contract_id)
        if contract is None:
            return
        for ob in contract.obligations:
            if ob.obligation_id == obligation_id:
                ob.is_satisfied = True
                ob.recognized_amount = ob.allocated_price
                break

    def update_progress(
        self,
        contract_id: str,
        obligation_id: str,
        delivered_units: int | None = None,
        incurred_cost: Money | None = None,
        as_of: date | None = None,
    ) -> None:
        """Update progress for an over-time obligation."""
        contract = self._contracts.get(contract_id)
        if contract is None:
            return
        for ob in contract.obligations:
            if ob.obligation_id == obligation_id:
                if delivered_units is not None:
                    ob.delivered_units = delivered_units
                if incurred_cost is not None:
                    ob.incurred_cost = incurred_cost
                break

    def recognize_revenue(
        self,
        contract_id: str,
        entry_id: str,
        recognition_date: date,
    ) -> JournalEntry | None:
        """Generate journal entry to recognize earned revenue.

        Dr. Deferred Revenue (reduce liability)
          Cr. Revenue (recognize income)
        """
        contract = self._contracts.get(contract_id)
        if contract is None:
            return None

        total_to_recognize = Money.zero(self._currency)
        for ob in contract.obligations:
            recognizable = ob.recognizable_amount
            if recognizable.is_positive:
                total_to_recognize = total_to_recognize + recognizable
                # Update tracked amount
                if ob.recognized_amount is None:
                    ob.recognized_amount = recognizable
                else:
                    ob.recognized_amount = ob.recognized_amount + recognizable

        if total_to_recognize.is_zero:
            return None

        entry = JournalEntry(
            entry_id=entry_id,
            entry_date=recognition_date,
            description=f"Revenue recognition: {contract.customer_name}",
            entry_type=EntryType.REGULAR,
        )
        entry.add_debit(contract.deferred_revenue_account, total_to_recognize)
        entry.add_credit(contract.revenue_account, total_to_recognize)
        return entry

    def record_contract_inception(
        self,
        contract_id: str,
        entry_id: str,
    ) -> JournalEntry | None:
        """Record the initial contract (cash received, deferred revenue).

        Dr. Cash/Receivable
          Cr. Deferred Revenue (full transaction price)
        """
        contract = self._contracts.get(contract_id)
        if contract is None:
            return None

        entry = JournalEntry(
            entry_id=entry_id,
            entry_date=contract.contract_date,
            description=f"Contract inception: {contract.customer_name}",
        )
        entry.add_debit(contract.receivable_account, contract.transaction_price)
        entry.add_credit(contract.deferred_revenue_account, contract.transaction_price)
        return entry

    @property
    def contract_count(self) -> int:
        return len(self._contracts)

    def total_deferred_revenue(self) -> Money:
        total = Money.zero(self._currency)
        for c in self._contracts.values():
            total = total + c.total_deferred
        return total
