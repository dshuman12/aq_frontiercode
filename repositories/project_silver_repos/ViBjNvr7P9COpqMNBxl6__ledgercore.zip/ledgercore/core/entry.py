"""Journal entries with double-entry validation.

A journal entry records a financial transaction. It consists of
two or more line items (debits and credits) that MUST balance.

The balancing rule: sum of all debit amounts must equal sum of all
credit amounts for each currency in the entry. Multi-currency entries
are allowed but each currency must independently balance.

Entry states:
  DRAFT -> POSTED -> (optionally) REVERSED
  
  DRAFT: being composed, not yet affecting balances
  POSTED: finalized, affects account balances
  REVERSED: a reversing entry has been created; original stays but
           is marked reversed. The reversal is a separate entry.

Reversing entries: instead of deleting a posted entry (which would
break the audit trail), we create a NEW entry with all debits and
credits swapped. The original entry keeps a reference to its reversal.

Adjusting entries: entries made at period-end to record accruals,
deferrals, estimates. They have a special flag because some reports
need to separate adjusting from regular entries.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date, datetime
from decimal import Decimal
from enum import Enum
from typing import Any
from ledgercore.core.money import Money, Currency, CurrencyMismatchError


class EntryStatus(Enum):
    DRAFT = "draft"
    POSTED = "posted"
    REVERSED = "reversed"


class EntryType(Enum):
    REGULAR = "regular"
    ADJUSTING = "adjusting"
    CLOSING = "closing"
    REVERSING = "reversing"
    OPENING = "opening"


@dataclass
class EntryLine:
    """A single line in a journal entry.

    Each line debits OR credits an account. The amount is always positive;
    the debit/credit flag determines the direction.

    For multi-currency entries, the line has both a native amount
    (in the account's currency) and a reporting amount (in the
    company's functional currency).
    """
    account_number: str
    debit: Money | None = None
    credit: Money | None = None
    description: str = ""
    # For multi-currency: functional currency equivalent
    reporting_debit: Money | None = None
    reporting_credit: Money | None = None

    @property
    def is_debit(self) -> bool:
        return self.debit is not None and not self.debit.is_zero

    @property
    def is_credit(self) -> bool:
        return self.credit is not None and not self.credit.is_zero

    @property
    def amount(self) -> Money:
        """The absolute amount (debit or credit)."""
        if self.is_debit:
            return self.debit
        if self.is_credit:
            return self.credit
        raise ValueError("EntryLine has no amount")

    @property
    def currency(self) -> Currency:
        if self.debit is not None:
            return self.debit.currency
        if self.credit is not None:
            return self.credit.currency
        raise ValueError("EntryLine has no currency")

    def validate(self) -> list[str]:
        """Validate this line. Returns list of error messages."""
        errors = []
        if self.debit is not None and self.credit is not None:
            if not self.debit.is_zero and not self.credit.is_zero:
                errors.append("Line cannot have both debit and credit")
        if self.debit is None and self.credit is None:
            errors.append("Line must have debit or credit")
        if self.debit is not None and self.debit.is_negative:
            errors.append("Debit amount cannot be negative")
        if self.credit is not None and self.credit.is_negative:
            errors.append("Credit amount cannot be negative")
        if not self.account_number:
            errors.append("Account number is required")
        return errors


@dataclass
class JournalEntry:
    """A complete journal entry (transaction).

    Must satisfy the double-entry invariant: for each currency,
    total debits must equal total credits.
    """
    entry_id: str
    entry_date: date
    lines: list[EntryLine] = field(default_factory=list)
    description: str = ""
    reference: str = ""  # external reference (check #, invoice #, etc.)
    status: EntryStatus = EntryStatus.DRAFT
    entry_type: EntryType = EntryType.REGULAR
    reversal_of: str = ""  # entry_id of the entry this reverses
    reversed_by: str = ""  # entry_id of the entry that reversed this
    created_at: datetime = field(default_factory=datetime.now)
    posted_at: datetime | None = None
    source_module: str = ""  # which module created this entry
    tags: set[str] = field(default_factory=set)
    period_id: str = ""  # fiscal period this belongs to

    def add_debit(self, account: str, amount: Money, description: str = "",
                  reporting_amount: Money | None = None) -> None:
        self.lines.append(EntryLine(
            account_number=account,
            debit=amount,
            description=description,
            reporting_debit=reporting_amount,
        ))

    def add_credit(self, account: str, amount: Money, description: str = "",
                   reporting_amount: Money | None = None) -> None:
        self.lines.append(EntryLine(
            account_number=account,
            credit=amount,
            description=description,
            reporting_credit=reporting_amount,
        ))

    def validate(self) -> list[str]:
        """Validate the entry. Returns list of error messages.

        Checks:
        1. At least 2 lines
        2. Each line is individually valid
        3. Debits = Credits for each currency (THE CORE INVARIANT)
        4. No zero-amount entries
        """
        errors = []
        if len(self.lines) < 2:
            errors.append("Entry must have at least 2 lines")

        for i, line in enumerate(self.lines):
            line_errors = line.validate()
            for e in line_errors:
                errors.append(f"Line {i + 1}: {e}")

        # Check balance by currency
        balance_check = self._check_balance()
        errors.extend(balance_check)

        return errors

    def _check_balance(self) -> list[str]:
        """Verify debits equal credits for each currency.

        This is the FUNDAMENTAL double-entry invariant.
        """
        errors = []
        currency_totals: dict[str, tuple[Decimal, Decimal]] = {}

        for line in self.lines:
            if line.is_debit:
                curr = line.debit.currency.code
                d, c = currency_totals.get(curr, (Decimal("0"), Decimal("0")))
                currency_totals[curr] = (d + line.debit.amount, c)
            if line.is_credit:
                curr = line.credit.currency.code
                d, c = currency_totals.get(curr, (Decimal("0"), Decimal("0")))
                currency_totals[curr] = (d, c + line.credit.amount)

        for curr, (total_debit, total_credit) in currency_totals.items():
            if total_debit != total_credit:
                errors.append(
                    f"Entry unbalanced in {curr}: "
                    f"debits={total_debit}, credits={total_credit}, "
                    f"difference={total_debit - total_credit}"
                )

        return errors

    @property
    def total_debits(self) -> dict[str, Decimal]:
        """Total debit amounts by currency."""
        result: dict[str, Decimal] = {}
        for line in self.lines:
            if line.is_debit:
                curr = line.debit.currency.code
                result[curr] = result.get(curr, Decimal("0")) + line.debit.amount
        return result

    @property
    def total_credits(self) -> dict[str, Decimal]:
        result: dict[str, Decimal] = {}
        for line in self.lines:
            if line.is_credit:
                curr = line.credit.currency.code
                result[curr] = result.get(curr, Decimal("0")) + line.credit.amount
        return result

    @property
    def is_balanced(self) -> bool:
        return len(self._check_balance()) == 0

    @property
    def is_posted(self) -> bool:
        return self.status == EntryStatus.POSTED

    @property
    def is_reversible(self) -> bool:
        return self.status == EntryStatus.POSTED and not self.reversed_by

    def create_reversal(self, new_entry_id: str, reversal_date: date) -> JournalEntry:
        """Create a reversing entry (swap all debits and credits).

        The reversing entry has the same amounts but with debits and
        credits swapped. This effectively cancels the original entry.
        """
        reversal = JournalEntry(
            entry_id=new_entry_id,
            entry_date=reversal_date,
            description=f"Reversal of {self.entry_id}: {self.description}",
            reference=self.reference,
            entry_type=EntryType.REVERSING,
            reversal_of=self.entry_id,
        )
        for line in self.lines:
            if line.is_debit:
                reversal.add_credit(
                    line.account_number, line.debit,
                    f"Reversal: {line.description}",
                )
            elif line.is_credit:
                reversal.add_debit(
                    line.account_number, line.credit,
                    f"Reversal: {line.description}",
                )
        return reversal

    def __repr__(self) -> str:
        return f"JournalEntry({self.entry_id}, {self.entry_date}, {len(self.lines)} lines)"
