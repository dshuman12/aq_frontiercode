"""Loan amortization schedule calculation.

Generates payment-by-payment schedules for:
1. Fixed-rate fully amortizing loans
2. Interest-only loans
3. Balloon payment loans
4. Variable-rate loans (ARM)

For a standard fixed-rate loan, each payment is the same amount but
the split between principal and interest changes:
- Early payments: mostly interest
- Later payments: mostly principal
This is because interest is calculated on the REMAINING balance.

Payment calculation (annuity formula):
  PMT = PV * r / (1 - (1+r)^-n)
  where r = periodic rate, n = number of periods

Rounding issue: the payment amount is rounded, but the interest
is calculated exactly. This means the final payment is often slightly
different from other payments to account for accumulated rounding errors.
We handle this by making the last payment the remaining balance + interest.

ARM (Adjustable Rate Mortgage):
  Rate changes at specified intervals. When rate changes, the payment
  is recalculated based on remaining balance and remaining term.
  Past payments stay the same; only future payments change.

Journal entries for a loan payment:
  Dr. Interest Expense (interest portion)
  Dr. Loan Payable (principal portion)
    Cr. Cash (total payment)
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date, timedelta
from decimal import Decimal, ROUND_HALF_EVEN
from typing import Any
from ledgercore.core.money import Money, Currency
from ledgercore.core.entry import JournalEntry


@dataclass
class AmortizationPayment:
    """A single payment in an amortization schedule."""
    payment_number: int
    payment_date: date
    payment_amount: Money
    principal: Money
    interest: Money
    balance_after: Money
    cumulative_interest: Money
    cumulative_principal: Money


@dataclass
class AmortizationSchedule:
    """Complete amortization schedule for a loan."""
    loan_id: str
    principal: Money
    annual_rate: Decimal
    term_months: int
    start_date: date
    payment_day: int = 1  # day of month
    payments: list[AmortizationPayment] = field(default_factory=list)

    @property
    def monthly_rate(self) -> Decimal:
        return self.annual_rate / 12

    @property
    def total_interest(self) -> Money:
        if not self.payments:
            return Money.zero(self.principal.currency)
        return self.payments[-1].cumulative_interest

    @property
    def total_paid(self) -> Money:
        total = Money.zero(self.principal.currency)
        for p in self.payments:
            total = total + p.payment_amount
        return total

    @property
    def is_paid_off(self) -> bool:
        if not self.payments:
            return False
        return self.payments[-1].balance_after.is_zero or self.payments[-1].balance_after.amount <= Decimal("0.01")


def calculate_fixed_rate_schedule(
    loan_id: str,
    principal: Money,
    annual_rate: Decimal,
    term_months: int,
    start_date: date,
    payment_day: int = 1,
) -> AmortizationSchedule:
    """Calculate a fixed-rate amortization schedule.

    Uses the annuity formula for payment calculation, with the
    last payment adjusted for rounding.
    """
    schedule = AmortizationSchedule(
        loan_id=loan_id, principal=principal, annual_rate=annual_rate,
        term_months=term_months, start_date=start_date, payment_day=payment_day,
    )

    if term_months <= 0 or principal.is_zero:
        return schedule

    currency = principal.currency
    monthly_rate = annual_rate / 12
    balance = principal.amount

    # Calculate fixed payment using annuity formula
    if monthly_rate == 0:
        payment = balance / term_months
    else:
        r = monthly_rate
        n = term_months
        payment = balance * r / (1 - (1 + r) ** (-n))

    payment = payment.quantize(Decimal("0.01"), rounding=ROUND_HALF_EVEN)

    cumulative_interest = Decimal("0")
    cumulative_principal = Decimal("0")
    current_date = _next_payment_date(start_date, payment_day)

    for i in range(1, term_months + 1):
        interest = (balance * monthly_rate).quantize(Decimal("0.01"), rounding=ROUND_HALF_EVEN)

        if i == term_months:
            # Last payment: pay off remaining balance exactly
            principal_portion = balance
            actual_payment = principal_portion + interest
        else:
            actual_payment = payment
            principal_portion = actual_payment - interest

        balance -= principal_portion
        cumulative_interest += interest
        cumulative_principal += principal_portion

        schedule.payments.append(AmortizationPayment(
            payment_number=i,
            payment_date=current_date,
            payment_amount=Money(actual_payment, currency),
            principal=Money(principal_portion, currency),
            interest=Money(interest, currency),
            balance_after=Money(max(Decimal("0"), balance), currency),
            cumulative_interest=Money(cumulative_interest, currency),
            cumulative_principal=Money(cumulative_principal, currency),
        ))

        current_date = _next_payment_date(current_date, payment_day)

    return schedule


def calculate_interest_only_schedule(
    loan_id: str,
    principal: Money,
    annual_rate: Decimal,
    term_months: int,
    io_months: int,
    start_date: date,
) -> AmortizationSchedule:
    """Interest-only schedule: IO period then fully amortizing.

    During the IO period, payments are interest-only (no principal).
    After the IO period, payments increase to amortize the full
    principal over the remaining term.
    """
    schedule = AmortizationSchedule(
        loan_id=loan_id, principal=principal, annual_rate=annual_rate,
        term_months=term_months, start_date=start_date,
    )

    currency = principal.currency
    monthly_rate = annual_rate / 12
    balance = principal.amount
    cumulative_interest = Decimal("0")
    cumulative_principal = Decimal("0")
    current_date = _next_payment_date(start_date, 1)

    # IO period
    for i in range(1, min(io_months, term_months) + 1):
        interest = (balance * monthly_rate).quantize(Decimal("0.01"), rounding=ROUND_HALF_EVEN)
        cumulative_interest += interest
        schedule.payments.append(AmortizationPayment(
            payment_number=i,
            payment_date=current_date,
            payment_amount=Money(interest, currency),
            principal=Money.zero(currency),
            interest=Money(interest, currency),
            balance_after=Money(balance, currency),
            cumulative_interest=Money(cumulative_interest, currency),
            cumulative_principal=Money(cumulative_principal, currency),
        ))
        current_date = _next_payment_date(current_date, 1)

    # Amortizing period
    remaining_months = term_months - io_months
    if remaining_months > 0 and monthly_rate > 0:
        r = monthly_rate
        n = remaining_months
        payment = balance * r / (1 - (1 + r) ** (-n))
        payment = payment.quantize(Decimal("0.01"), rounding=ROUND_HALF_EVEN)

        for i in range(io_months + 1, term_months + 1):
            interest = (balance * monthly_rate).quantize(Decimal("0.01"), rounding=ROUND_HALF_EVEN)
            if i == term_months:
                principal_portion = balance
                actual_payment = principal_portion + interest
            else:
                actual_payment = payment
                principal_portion = actual_payment - interest

            balance -= principal_portion
            cumulative_interest += interest
            cumulative_principal += principal_portion

            schedule.payments.append(AmortizationPayment(
                payment_number=i,
                payment_date=current_date,
                payment_amount=Money(actual_payment, currency),
                principal=Money(principal_portion, currency),
                interest=Money(interest, currency),
                balance_after=Money(max(Decimal("0"), balance), currency),
                cumulative_interest=Money(cumulative_interest, currency),
                cumulative_principal=Money(cumulative_principal, currency),
            ))
            current_date = _next_payment_date(current_date, 1)

    return schedule


def generate_payment_entry(
    payment: AmortizationPayment,
    entry_id: str,
    loan_account: str,
    interest_account: str,
    cash_account: str,
) -> JournalEntry:
    """Generate journal entry for a loan payment."""
    entry = JournalEntry(
        entry_id=entry_id,
        entry_date=payment.payment_date,
        description=f"Loan payment #{payment.payment_number}",
    )
    if not payment.interest.is_zero:
        entry.add_debit(interest_account, payment.interest)
    if not payment.principal.is_zero:
        entry.add_debit(loan_account, payment.principal)
    entry.add_credit(cash_account, payment.payment_amount)
    return entry


def _next_payment_date(current: date, payment_day: int) -> date:
    """Get the next payment date after current."""
    year = current.year
    month = current.month + 1
    if month > 12:
        month = 1
        year += 1
    day = min(payment_day, 28)  # safe for all months
    return date(year, month, day)
