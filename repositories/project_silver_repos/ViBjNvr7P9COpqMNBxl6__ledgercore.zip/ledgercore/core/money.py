"""Money type with decimal precision and currency awareness.

Financial calculations MUST use decimal arithmetic, not floating point.
$0.1 + $0.2 must equal $0.3 exactly, not 0.30000000000000004.

The Money class enforces:
1. Fixed-precision decimal arithmetic (configurable per currency)
2. Currency matching: cannot add USD + EUR without conversion
3. Banker's rounding (round-half-to-even) for divisions
4. Immutability: all operations return new Money objects

Negative money is allowed (represents a credit balance in a normally
debit account, or vice versa).

The sign convention: positive Money means the natural direction for the
context. Whether that's debit or credit depends on the account type
and the side of the entry.
"""
from __future__ import annotations
from decimal import Decimal, ROUND_HALF_EVEN, InvalidOperation, getcontext
from typing import Any

# Set global decimal precision high enough for financial calculations
getcontext().prec = 28


class Currency:
    """A currency with code, symbol, and decimal places."""
    __slots__ = ("code", "symbol", "decimal_places", "name")

    def __init__(self, code: str, symbol: str = "", decimal_places: int = 2, name: str = ""):
        self.code = code.upper()
        self.symbol = symbol or code
        self.decimal_places = decimal_places
        self.name = name or code

    def __eq__(self, other: object) -> bool:
        if isinstance(other, Currency):
            return self.code == other.code
        return NotImplemented

    def __hash__(self) -> int:
        return hash(self.code)

    def __repr__(self) -> str:
        return f"Currency({self.code!r})"


# Common currencies
USD = Currency("USD", "$", 2, "US Dollar")
EUR = Currency("EUR", "\u20ac", 2, "Euro")
GBP = Currency("GBP", "\u00a3", 2, "British Pound")
JPY = Currency("JPY", "\u00a5", 0, "Japanese Yen")
INR = Currency("INR", "\u20b9", 2, "Indian Rupee")


class Money:
    """Immutable monetary amount with currency.

    Uses Decimal for exact arithmetic. All operations that produce
    a result are rounded to the currency's decimal places using
    banker's rounding (ROUND_HALF_EVEN).

    Operations:
    - Addition/subtraction: same currency only (raises on mismatch)
    - Multiplication/division by scalar: OK
    - Multiplication of two Money: NOT allowed (dollars * dollars = ?)
    - Division of two Money: returns Decimal ratio (dimensionless)
    - Comparison: same currency only
    - Negation: returns Money with opposite sign
    """
    __slots__ = ("_amount", "_currency")

    def __init__(self, amount: Decimal | int | float | str, currency: Currency):
        if isinstance(amount, float):
            # Float -> string -> Decimal to avoid precision issues
            self._amount = Decimal(str(amount))
        elif isinstance(amount, Decimal):
            self._amount = amount
        else:
            self._amount = Decimal(str(amount))
        self._currency = currency
        # Quantize to currency precision
        self._amount = self._quantize(self._amount)

    def _quantize(self, value: Decimal) -> Decimal:
        """Round to currency's decimal places using banker's rounding."""
        if self._currency.decimal_places == 0:
            return value.quantize(Decimal("1"), rounding=ROUND_HALF_EVEN)
        exp = Decimal(10) ** -self._currency.decimal_places
        return value.quantize(exp, rounding=ROUND_HALF_EVEN)

    @property
    def amount(self) -> Decimal:
        return self._amount

    @property
    def currency(self) -> Currency:
        return self._currency

    @property
    def is_zero(self) -> bool:
        return self._amount == 0

    @property
    def is_positive(self) -> bool:
        return self._amount > 0

    @property
    def is_negative(self) -> bool:
        return self._amount < 0

    def __add__(self, other: Money) -> Money:
        self._check_currency(other)
        return Money(self._amount + other._amount, self._currency)

    def __sub__(self, other: Money) -> Money:
        self._check_currency(other)
        return Money(self._amount - other._amount, self._currency)

    def __mul__(self, scalar: Decimal | int | float) -> Money:
        if isinstance(scalar, Money):
            raise TypeError("Cannot multiply Money by Money")
        return Money(self._amount * Decimal(str(scalar)), self._currency)

    def __rmul__(self, scalar: Decimal | int | float) -> Money:
        return self.__mul__(scalar)

    def __truediv__(self, other: Money | Decimal | int | float) -> Money | Decimal:
        if isinstance(other, Money):
            self._check_currency(other)
            if other._amount == 0:
                raise ZeroDivisionError("Division by zero Money")
            return self._amount / other._amount
        if other == 0:
            raise ZeroDivisionError("Division by zero")
        return Money(self._amount / Decimal(str(other)), self._currency)

    def __neg__(self) -> Money:
        return Money(-self._amount, self._currency)

    def __abs__(self) -> Money:
        return Money(abs(self._amount), self._currency)

    def __eq__(self, other: object) -> bool:
        if isinstance(other, Money):
            return self._currency == other._currency and self._amount == other._amount
        return NotImplemented

    def __lt__(self, other: Money) -> bool:
        self._check_currency(other)
        return self._amount < other._amount

    def __le__(self, other: Money) -> bool:
        self._check_currency(other)
        return self._amount <= other._amount

    def __gt__(self, other: Money) -> bool:
        self._check_currency(other)
        return self._amount > other._amount

    def __ge__(self, other: Money) -> bool:
        self._check_currency(other)
        return self._amount >= other._amount

    def __hash__(self) -> int:
        return hash((self._amount, self._currency.code))

    def __repr__(self) -> str:
        return f"Money({self._amount}, {self._currency.code})"

    def __str__(self) -> str:
        return f"{self._currency.symbol}{self._amount:,.{self._currency.decimal_places}f}"

    def _check_currency(self, other: Money) -> None:
        if self._currency != other._currency:
            raise CurrencyMismatchError(
                f"Cannot operate on {self._currency.code} and {other._currency.code}"
            )

    def to_dict(self) -> dict:
        return {"amount": str(self._amount), "currency": self._currency.code}

    @staticmethod
    def zero(currency: Currency) -> Money:
        return Money(0, currency)


class CurrencyMismatchError(Exception):
    """Raised when operating on Money with different currencies."""
    pass
