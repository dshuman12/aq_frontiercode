"""Account model with type hierarchy and normal balance conventions.

The fundamental accounting complexity: different account types have
different "normal balance" sides.

DEBIT-NORMAL accounts (increase with debit):
  - Assets (cash, receivables, equipment)
  - Expenses (rent, salaries, utilities)
  - Contra-liability (e.g., bond discount)
  - Contra-equity (e.g., treasury stock)

CREDIT-NORMAL accounts (increase with credit):
  - Liabilities (payables, loans, unearned revenue)
  - Equity (common stock, retained earnings)
  - Revenue (sales, service income, interest income)
  - Contra-asset (e.g., accumulated depreciation, allowance for bad debts)

This matters because:
- A debit to an Asset INCREASES it
- A debit to a Revenue DECREASES it
- A credit to an Asset DECREASES it
- A credit to a Liability INCREASES it

Getting this wrong is the #1 source of accounting bugs. The balance()
method must account for normal direction when computing the displayed
balance.

Account numbering convention (hierarchical):
  1xxx = Assets
  2xxx = Liabilities
  3xxx = Equity
  4xxx = Revenue
  5xxx = Expenses
  The first digit determines the account type.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from decimal import Decimal
from typing import Any
from ledgercore.core.money import Money, Currency


class AccountType(Enum):
    ASSET = "asset"
    LIABILITY = "liability"
    EQUITY = "equity"
    REVENUE = "revenue"
    EXPENSE = "expense"
    CONTRA_ASSET = "contra_asset"
    CONTRA_LIABILITY = "contra_liability"
    CONTRA_EQUITY = "contra_equity"


class NormalBalance(Enum):
    DEBIT = "debit"
    CREDIT = "credit"


# Map account types to their normal balance side
NORMAL_BALANCE_MAP: dict[AccountType, NormalBalance] = {
    AccountType.ASSET: NormalBalance.DEBIT,
    AccountType.EXPENSE: NormalBalance.DEBIT,
    AccountType.CONTRA_LIABILITY: NormalBalance.DEBIT,
    AccountType.CONTRA_EQUITY: NormalBalance.DEBIT,
    AccountType.LIABILITY: NormalBalance.CREDIT,
    AccountType.EQUITY: NormalBalance.CREDIT,
    AccountType.REVENUE: NormalBalance.CREDIT,
    AccountType.CONTRA_ASSET: NormalBalance.CREDIT,
}


def get_normal_balance(account_type: AccountType) -> NormalBalance:
    return NORMAL_BALANCE_MAP[account_type]


def infer_account_type(account_number: str) -> AccountType:
    """Infer account type from the first digit of account number.

    1xxx = Asset, 2xxx = Liability, 3xxx = Equity,
    4xxx = Revenue, 5xxx = Expense
    """
    if not account_number:
        raise ValueError("Account number cannot be empty")
    first = account_number[0]
    type_map = {
        "1": AccountType.ASSET,
        "2": AccountType.LIABILITY,
        "3": AccountType.EQUITY,
        "4": AccountType.REVENUE,
        "5": AccountType.EXPENSE,
    }
    if first not in type_map:
        raise ValueError(f"Cannot infer type from account number: {account_number}")
    return type_map[first]


@dataclass
class Account:
    """A ledger account.

    Attributes:
        number: Hierarchical account number (e.g., "1100" for Cash)
        name: Human-readable name
        account_type: Type classification
        currency: Default currency for this account
        parent_number: Parent account number for sub-accounts
        is_active: Whether the account accepts new entries
        is_system: System accounts (like retained earnings) cannot be deleted
        description: Optional description
        tags: Classification tags for reporting
    """
    number: str
    name: str
    account_type: AccountType
    currency: Currency
    parent_number: str = ""
    is_active: bool = True
    is_system: bool = False
    description: str = ""
    tags: set[str] = field(default_factory=set)

    @property
    def normal_balance(self) -> NormalBalance:
        return get_normal_balance(self.account_type)

    @property
    def is_debit_normal(self) -> bool:
        return self.normal_balance == NormalBalance.DEBIT

    @property
    def is_balance_sheet(self) -> bool:
        """Balance sheet accounts: assets, liabilities, equity (+ contras)."""
        return self.account_type in (
            AccountType.ASSET, AccountType.LIABILITY, AccountType.EQUITY,
            AccountType.CONTRA_ASSET, AccountType.CONTRA_LIABILITY, AccountType.CONTRA_EQUITY,
        )

    @property
    def is_income_statement(self) -> bool:
        """Income statement accounts: revenue and expenses."""
        return self.account_type in (AccountType.REVENUE, AccountType.EXPENSE)

    @property
    def depth(self) -> int:
        """Hierarchy depth based on account number length."""
        return len(self.number)

    def is_child_of(self, parent_number: str) -> bool:
        """Check if this account is a child of the given parent."""
        return self.number.startswith(parent_number) and len(self.number) > len(parent_number)

    def __repr__(self) -> str:
        return f"Account({self.number}: {self.name})"

    def __eq__(self, other: object) -> bool:
        if isinstance(other, Account):
            return self.number == other.number
        return NotImplemented

    def __hash__(self) -> int:
        return hash(self.number)
