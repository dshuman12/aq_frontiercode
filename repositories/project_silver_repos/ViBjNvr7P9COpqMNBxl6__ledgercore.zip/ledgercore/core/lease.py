"""Lease accounting under ASC 842 / IFRS 16.

Under the new lease standards, most leases are recognized on the
balance sheet as a right-of-use (ROU) asset and a lease liability.

Classification:
- Finance lease (ASC 842) / Finance lease (IFRS 16):
  Depreciates ROU asset, interest on liability
- Operating lease (ASC 842):
  Single lease expense (straight-line), ROU asset and liability still on BS
  (IFRS 16 treats ALL leases as finance leases)

Initial measurement:
  Lease Liability = PV of future lease payments
  ROU Asset = Lease Liability + Initial Direct Costs + Prepaid Rent - Incentives

Subsequent measurement (finance):
  Dr. Depreciation Expense (ROU amortization)
  Dr. Interest Expense (on liability)
    Cr. Accumulated Depreciation (ROU)
    Cr. Lease Liability (principal reduction)

Subsequent measurement (operating under ASC 842):
  Total lease cost = sum of all payments
  Single expense per period = total cost / lease term
  Dr. Lease Expense (straight-line amount)
    Cr. ROU Asset (difference between expense and liability reduction)
    Cr. Lease Liability (actual payment minus interest)
  
The operating lease under ASC 842 is tricky because the EXPENSE is
straight-line but the LIABILITY reduces based on the amortization
schedule (like a loan). The ROU asset is a balancing figure.

Discount rate: incremental borrowing rate (IBR) if rate implicit in
lease is not determinable.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal, ROUND_HALF_EVEN
from typing import Any
from ledgercore.core.money import Money, Currency
from ledgercore.core.entry import JournalEntry, EntryType


class LeaseType:
    FINANCE = "finance"
    OPERATING = "operating"


@dataclass
class LeasePayment:
    """A scheduled lease payment."""
    period: int
    payment_date: date
    amount: Money
    principal: Money | None = None
    interest: Money | None = None


@dataclass
class Lease:
    """A lease contract."""
    lease_id: str
    description: str
    lease_type: str = LeaseType.OPERATING
    commencement_date: date = field(default_factory=date.today)
    term_months: int = 0
    monthly_payment: Money = field(default_factory=lambda: Money(0, Currency("USD","$")))
    discount_rate: Decimal = Decimal("0.05")  # annual
    initial_direct_costs: Money = field(default_factory=lambda: Money(0, Currency("USD","$")))
    # Accounts
    rou_asset_account: str = "1600"
    accumulated_amort_account: str = "1610"
    lease_liability_account: str = "2600"
    interest_account: str = "5600"
    lease_expense_account: str = "5700"
    depreciation_account: str = "5300"
    # Computed
    lease_liability: Money | None = None
    rou_asset: Money | None = None
    payments: list[LeasePayment] = field(default_factory=list)

    def calculate_initial_measurement(self) -> None:
        """Calculate initial ROU asset and lease liability.

        Liability = PV of lease payments
        ROU Asset = Liability + Initial Direct Costs
        """
        currency = self.monthly_payment.currency
        monthly_rate = self.discount_rate / 12

        # PV of annuity
        if monthly_rate == 0:
            pv = self.monthly_payment.amount * self.term_months
        else:
            r = monthly_rate
            n = self.term_months
            pv = self.monthly_payment.amount * (1 - (1 + r) ** (-n)) / r

        self.lease_liability = Money(pv.quantize(Decimal("0.01"), rounding=ROUND_HALF_EVEN), currency)
        self.rou_asset = self.lease_liability + self.initial_direct_costs

        # Generate payment schedule
        balance = pv
        self.payments = []
        for i in range(1, self.term_months + 1):
            interest = (balance * monthly_rate).quantize(Decimal("0.01"), rounding=ROUND_HALF_EVEN)
            principal = self.monthly_payment.amount - interest
            balance -= principal

            month = self.commencement_date.month + i - 1
            year = self.commencement_date.year
            while month > 12:
                month -= 12
                year += 1

            self.payments.append(LeasePayment(
                period=i,
                payment_date=date(year, month, min(self.commencement_date.day, 28)),
                amount=self.monthly_payment,
                principal=Money(principal, currency),
                interest=Money(interest, currency),
            ))

    def generate_inception_entry(self, entry_id: str) -> JournalEntry:
        """Journal entry at lease commencement.

        Dr. ROU Asset
          Cr. Lease Liability
          Cr. Cash (initial direct costs, if any paid separately)
        """
        entry = JournalEntry(
            entry_id=entry_id,
            entry_date=self.commencement_date,
            description=f"Lease commencement: {self.description}",
        )
        entry.add_debit(self.rou_asset_account, self.rou_asset)
        entry.add_credit(self.lease_liability_account, self.lease_liability)
        if not self.initial_direct_costs.is_zero:
            entry.add_credit("1100", self.initial_direct_costs)
        return entry

    def generate_payment_entry(self, period: int, entry_id: str) -> JournalEntry | None:
        """Generate entry for a lease payment."""
        if period < 1 or period > len(self.payments):
            return None

        pmt = self.payments[period - 1]

        if self.lease_type == LeaseType.FINANCE:
            # Finance: separate interest and principal
            entry = JournalEntry(
                entry_id=entry_id,
                entry_date=pmt.payment_date,
                description=f"Lease payment #{period}: {self.description}",
            )
            if pmt.interest and not pmt.interest.is_zero:
                entry.add_debit(self.interest_account, pmt.interest)
            if pmt.principal and not pmt.principal.is_zero:
                entry.add_debit(self.lease_liability_account, pmt.principal)
            entry.add_credit("1100", pmt.amount)
            return entry
        else:
            # Operating: straight-line expense
            total_cost = self.monthly_payment.amount * self.term_months
            straight_line = Money(
                (total_cost / self.term_months).quantize(Decimal("0.01"), rounding=ROUND_HALF_EVEN),
                pmt.amount.currency,
            )
            entry = JournalEntry(
                entry_id=entry_id,
                entry_date=pmt.payment_date,
                description=f"Lease payment #{period}: {self.description}",
            )
            entry.add_debit(self.lease_expense_account, straight_line)
            entry.add_credit("1100", pmt.amount)
            # ROU asset adjustment is the balancing figure
            diff = pmt.amount - straight_line
            if diff.is_positive:
                entry.add_debit(self.rou_asset_account, diff)
            elif diff.is_negative:
                entry.add_credit(self.rou_asset_account, abs(diff))
            return entry
