"""Validation helpers for accounting data integrity.

Provides pre-posting validation checks that enforce accounting rules
beyond what the individual classes check:

1. Account existence verification across all referenced accounts
2. Period validation (date falls in an open period)
3. Amount reasonableness checks (configurable thresholds)
4. Duplicate entry detection (same reference + date + amount)
5. Cross-entry consistency (related entries reference each other)
6. Chart of accounts structural integrity

These are PREVENTIVE checks run before posting, as opposed to the
DETECTIVE checks in audit trail which run after the fact.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from typing import Any
from ledgercore.core.money import Money, Currency
from ledgercore.core.entry import JournalEntry, EntryStatus
from ledgercore.core.account import AccountType
from ledgercore.chart.chart_of_accounts import ChartOfAccounts


@dataclass
class ValidationConfig:
    """Configuration for posting validation."""
    max_entry_amount: Decimal = Decimal("10000000")  # $10M default
    require_description: bool = True
    require_reference: bool = False
    min_lines: int = 2
    max_lines: int = 100
    allow_future_dates: bool = False
    max_future_days: int = 0
    check_duplicates: bool = True
    duplicate_window_days: int = 7


@dataclass
class ValidationIssue:
    """A validation issue found during pre-posting check."""
    severity: str  # "error", "warning", "info"
    message: str
    field: str = ""
    line_number: int = 0

    @property
    def is_error(self) -> bool:
        return self.severity == "error"

    @property
    def is_warning(self) -> bool:
        return self.severity == "warning"


class EntryValidator:
    """Validate journal entries before posting."""

    def __init__(self, chart: ChartOfAccounts, config: ValidationConfig | None = None):
        self._chart = chart
        self._config = config or ValidationConfig()
        self._posted_entries: list[JournalEntry] = []

    def validate(self, entry: JournalEntry) -> list[ValidationIssue]:
        """Run all validation checks on an entry."""
        issues = []
        issues.extend(self._check_basic(entry))
        issues.extend(self._check_accounts(entry))
        issues.extend(self._check_amounts(entry))
        issues.extend(self._check_balance(entry))
        if self._config.check_duplicates:
            issues.extend(self._check_duplicates(entry))
        if not self._config.allow_future_dates:
            issues.extend(self._check_date(entry))
        return issues

    def _check_basic(self, entry: JournalEntry) -> list[ValidationIssue]:
        issues = []
        if not entry.entry_id:
            issues.append(ValidationIssue("error", "Entry ID is required", "entry_id"))
        if self._config.require_description and not entry.description:
            issues.append(ValidationIssue("warning", "Description is recommended", "description"))
        if self._config.require_reference and not entry.reference:
            issues.append(ValidationIssue("warning", "Reference is recommended", "reference"))
        if len(entry.lines) < self._config.min_lines:
            issues.append(ValidationIssue("error", f"Need at least {self._config.min_lines} lines"))
        if len(entry.lines) > self._config.max_lines:
            issues.append(ValidationIssue("error", f"Too many lines: {len(entry.lines)}"))
        return issues

    def _check_accounts(self, entry: JournalEntry) -> list[ValidationIssue]:
        issues = []
        for i, line in enumerate(entry.lines):
            acct = self._chart.get_account(line.account_number)
            if acct is None:
                issues.append(ValidationIssue(
                    "error", f"Account {line.account_number} not found",
                    "account", i + 1,
                ))
            elif not acct.is_active:
                issues.append(ValidationIssue(
                    "error", f"Account {line.account_number} is inactive",
                    "account", i + 1,
                ))
        return issues

    def _check_amounts(self, entry: JournalEntry) -> list[ValidationIssue]:
        issues = []
        for i, line in enumerate(entry.lines):
            amount = line.debit or line.credit
            if amount and amount.amount > self._config.max_entry_amount:
                issues.append(ValidationIssue(
                    "warning",
                    f"Amount {amount} exceeds threshold {self._config.max_entry_amount}",
                    "amount", i + 1,
                ))
        return issues

    def _check_balance(self, entry: JournalEntry) -> list[ValidationIssue]:
        errors = entry._check_balance()
        return [ValidationIssue("error", e) for e in errors]

    def _check_duplicates(self, entry: JournalEntry) -> list[ValidationIssue]:
        issues = []
        for posted in self._posted_entries:
            if (posted.reference == entry.reference and
                posted.reference and
                abs((posted.entry_date - entry.entry_date).days) <= self._config.duplicate_window_days):
                total_d = entry.total_debits
                posted_d = posted.total_debits
                if total_d == posted_d:
                    issues.append(ValidationIssue(
                        "warning",
                        f"Possible duplicate of {posted.entry_id} "
                        f"(same reference, similar date and amount)",
                    ))
        return issues

    def _check_date(self, entry: JournalEntry) -> list[ValidationIssue]:
        issues = []
        today = date.today()
        if entry.entry_date > today:
            if self._config.max_future_days == 0:
                issues.append(ValidationIssue("error", "Future-dated entries not allowed"))
            elif (entry.entry_date - today).days > self._config.max_future_days:
                issues.append(ValidationIssue(
                    "error",
                    f"Entry date too far in future ({(entry.entry_date - today).days} days)",
                ))
        return issues

    def register_posted(self, entry: JournalEntry) -> None:
        """Track posted entries for duplicate detection."""
        self._posted_entries.append(entry)


def verify_chart_integrity(chart: ChartOfAccounts) -> list[ValidationIssue]:
    """Check structural integrity of chart of accounts."""
    issues = []
    accounts = chart.all_accounts()
    numbers = {a.number for a in accounts}

    for acct in accounts:
        if acct.parent_number and acct.parent_number not in numbers:
            issues.append(ValidationIssue(
                "error",
                f"Account {acct.number}: parent {acct.parent_number} not found",
            ))
        if acct.parent_number and not acct.number.startswith(acct.parent_number):
            issues.append(ValidationIssue(
                "warning",
                f"Account {acct.number} doesn't start with parent {acct.parent_number}",
            ))

    return issues
