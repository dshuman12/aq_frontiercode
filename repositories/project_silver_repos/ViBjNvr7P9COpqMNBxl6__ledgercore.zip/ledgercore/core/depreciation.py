"""Depreciation schedule calculation.

Implements multiple depreciation methods:

1. Straight-Line (SL): equal amount each period
   Annual = (Cost - Salvage) / Life

2. Declining Balance (DB): fixed percentage of remaining book value
   Annual = Book Value * Rate
   Rate = 1 - (Salvage/Cost)^(1/Life)

3. Double Declining Balance (DDB): 2x the straight-line rate
   Annual = Book Value * (2/Life)
   Switch to SL when SL gives higher depreciation (crossover point)

4. Sum-of-Years-Digits (SYD): accelerated, based on remaining life
   Annual = (Cost - Salvage) * (Remaining Life / Sum of Digits)
   Sum = Life * (Life + 1) / 2

5. Units of Production: based on actual usage
   Annual = (Cost - Salvage) * (Units This Period / Total Expected Units)

The DDB-to-SL switch is the tricky one: in each period, calculate both
DDB and SL on the remaining book value, and use the HIGHER amount.
The switch point depends on asset life, salvage value, and book value.

Partial-year depreciation: if an asset is acquired mid-year, the first
and last years get prorated amounts. Convention options:
- Half-year: first year gets 50% regardless of acquisition date
- Mid-month: prorate by months
- Full-month: full depreciation in month of acquisition
"""
from __future__ import annotations
from dataclasses import dataclass, field
from decimal import Decimal
from datetime import date
from typing import Any
from ledgercore.core.money import Money, Currency


class DepreciationMethod:
    STRAIGHT_LINE = "SL"
    DECLINING_BALANCE = "DB"
    DOUBLE_DECLINING = "DDB"
    SUM_OF_YEARS = "SYD"
    UNITS_OF_PRODUCTION = "UOP"


class Convention:
    HALF_YEAR = "half_year"
    MID_MONTH = "mid_month"
    FULL_MONTH = "full_month"


@dataclass
class DepreciationSchedule:
    """A complete depreciation schedule for a fixed asset."""
    asset_id: str
    asset_name: str
    cost: Money
    salvage_value: Money
    useful_life_years: int
    method: str = DepreciationMethod.STRAIGHT_LINE
    convention: str = Convention.HALF_YEAR
    placed_in_service: date = field(default_factory=date.today)
    total_units: int = 0  # for units-of-production
    entries: list[DepreciationEntry] = field(default_factory=list)

    @property
    def depreciable_base(self) -> Money:
        """Cost minus salvage value — the total amount to depreciate."""
        return self.cost - self.salvage_value

    @property
    def total_depreciation(self) -> Money:
        """Sum of all depreciation entries so far."""
        total = Money.zero(self.cost.currency)
        for entry in self.entries:
            total = total + entry.amount
        return total

    @property
    def book_value(self) -> Money:
        """Current book value: cost minus accumulated depreciation."""
        return self.cost - self.total_depreciation

    @property
    def is_fully_depreciated(self) -> bool:
        return self.book_value <= self.salvage_value


@dataclass
class DepreciationEntry:
    """A single period's depreciation amount."""
    period: int  # year number (1-based)
    year: int    # calendar year
    amount: Money
    book_value_after: Money
    accumulated: Money


def calculate_straight_line(
    cost: Money,
    salvage: Money,
    life_years: int,
    convention: str = Convention.HALF_YEAR,
    placed_date: date | None = None,
) -> list[DepreciationEntry]:
    """Calculate straight-line depreciation schedule.

    With half-year convention, first and last year get half.
    Total periods = life_years + 1 (extra partial year at end).
    """
    if life_years <= 0:
        return []

    depreciable = cost - salvage
    annual = depreciable / life_years
    currency = cost.currency
    entries = []
    accumulated = Money.zero(currency)
    current_bv = cost

    total_periods = life_years
    if convention == Convention.HALF_YEAR:
        total_periods = life_years + 1

    start_year = placed_date.year if placed_date else 2025

    for period in range(1, total_periods + 1):
        if convention == Convention.HALF_YEAR:
            if period == 1 or period == total_periods:
                dep = annual / 2
            else:
                dep = annual
        else:
            dep = annual

        # Don't depreciate below salvage value
        max_dep = current_bv - salvage
        if dep > max_dep:
            dep = max_dep
        if dep.is_negative:
            break

        accumulated = accumulated + dep
        current_bv = cost - accumulated

        entries.append(DepreciationEntry(
            period=period,
            year=start_year + period - 1,
            amount=dep,
            book_value_after=current_bv,
            accumulated=accumulated,
        ))

    return entries


def calculate_double_declining(
    cost: Money,
    salvage: Money,
    life_years: int,
    convention: str = Convention.HALF_YEAR,
    placed_date: date | None = None,
) -> list[DepreciationEntry]:
    """Double-declining balance with switch to straight-line.

    The switch happens when straight-line on remaining book value
    gives a HIGHER depreciation than DDB. This is the standard
    MACRS behavior.

    DDB rate = 2 / life_years
    Each period: DDB_amount = book_value * rate
    SL_amount = (book_value - salvage) / remaining_years
    Use max(DDB_amount, SL_amount)
    """
    if life_years <= 0:
        return []

    rate = Decimal("2") / Decimal(str(life_years))
    currency = cost.currency
    entries = []
    accumulated = Money.zero(currency)
    current_bv = cost
    start_year = placed_date.year if placed_date else 2025

    total_periods = life_years
    if convention == Convention.HALF_YEAR:
        total_periods = life_years + 1

    switched_to_sl = False

    for period in range(1, total_periods + 1):
        remaining_years = total_periods - period + 1
        if remaining_years <= 0:
            break

        # DDB amount
        ddb_amount = current_bv * rate

        # SL amount on remaining book value
        if remaining_years > 0:
            sl_amount = (current_bv - salvage) / remaining_years
        else:
            sl_amount = current_bv - salvage

        # Half-year convention for first/last year
        if convention == Convention.HALF_YEAR:
            if period == 1:
                ddb_amount = ddb_amount / 2
                sl_amount = sl_amount / 2

        # Use the higher of DDB or SL (switch point)
        if sl_amount > ddb_amount and not switched_to_sl:
            switched_to_sl = True
        dep = sl_amount if switched_to_sl else ddb_amount

        # Don't depreciate below salvage
        max_dep = current_bv - salvage
        if dep > max_dep:
            dep = max_dep
        if dep.is_negative or dep.is_zero:
            break

        accumulated = accumulated + dep
        current_bv = cost - accumulated

        entries.append(DepreciationEntry(
            period=period,
            year=start_year + period - 1,
            amount=dep,
            book_value_after=current_bv,
            accumulated=accumulated,
        ))

    return entries


def calculate_sum_of_years(
    cost: Money,
    salvage: Money,
    life_years: int,
    placed_date: date | None = None,
) -> list[DepreciationEntry]:
    """Sum-of-years-digits depreciation.

    Fraction for year n = (life - n + 1) / sum_of_digits
    sum_of_digits = life * (life + 1) / 2
    """
    if life_years <= 0:
        return []

    depreciable = cost - salvage
    sum_digits = life_years * (life_years + 1) // 2
    currency = cost.currency
    entries = []
    accumulated = Money.zero(currency)
    start_year = placed_date.year if placed_date else 2025

    for period in range(1, life_years + 1):
        remaining = life_years - period + 1
        fraction = Decimal(str(remaining)) / Decimal(str(sum_digits))
        dep = depreciable * fraction

        # Don't depreciate below salvage
        max_dep = cost - accumulated - salvage
        if dep > max_dep:
            dep = max_dep

        accumulated = accumulated + dep

        entries.append(DepreciationEntry(
            period=period,
            year=start_year + period - 1,
            amount=dep,
            book_value_after=cost - accumulated,
            accumulated=accumulated,
        ))

    return entries
