"""Fixed asset register with acquisition, depreciation, and disposal.

A fixed asset has a lifecycle:
1. Acquisition: recorded at cost (purchase price + directly attributable costs)
2. Depreciation: systematic allocation of cost over useful life
3. Impairment: if fair value drops below book value (optional write-down)
4. Disposal: sale or scrapping; gain/loss recognized

Disposal accounting:
  Book Value = Cost - Accumulated Depreciation
  If Sale Price > Book Value: Gain on Disposal (credit to income)
  If Sale Price < Book Value: Loss on Disposal (debit to income)

Journal entries for disposal:
  Dr. Cash (sale proceeds)
  Dr. Accumulated Depreciation (remove accumulated)
  Dr. Loss on Disposal (if any)
    Cr. Fixed Asset (remove at cost)
    Cr. Gain on Disposal (if any)

This is tricky because you need to remove BOTH the asset AND its
accumulated depreciation, and compute the gain/loss correctly.

Revaluation model (alternative to cost model):
  If fair value > book value: revaluation surplus (equity, not income)
  If fair value < book value: revaluation deficit (income, unless
    reversing a previous surplus)
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from typing import Any
from ledgercore.core.money import Money, Currency
from ledgercore.core.depreciation import (
    DepreciationSchedule, DepreciationEntry, DepreciationMethod, Convention,
    calculate_straight_line, calculate_double_declining, calculate_sum_of_years,
)
from ledgercore.core.entry import JournalEntry, EntryType


class AssetStatus:
    ACTIVE = "active"
    DISPOSED = "disposed"
    FULLY_DEPRECIATED = "fully_depreciated"
    IMPAIRED = "impaired"


@dataclass
class FixedAsset:
    """A fixed asset in the register."""
    asset_id: str
    name: str
    description: str = ""
    category: str = ""  # e.g., "equipment", "vehicle", "building"
    # Accounts
    asset_account: str = ""      # e.g., 1500 Equipment
    depreciation_account: str = ""  # e.g., 5300 Depreciation Expense
    accumulated_account: str = ""   # e.g., 1510 Accumulated Depreciation
    gain_loss_account: str = ""     # e.g., 4900 Gain/Loss on Disposal
    # Financials
    cost: Money = field(default_factory=lambda: Money(0, Currency("USD", "$")))
    salvage_value: Money = field(default_factory=lambda: Money(0, Currency("USD", "$")))
    useful_life_years: int = 0
    depreciation_method: str = DepreciationMethod.STRAIGHT_LINE
    convention: str = Convention.HALF_YEAR
    # Dates
    acquisition_date: date = field(default_factory=date.today)
    in_service_date: date | None = None
    disposal_date: date | None = None
    # Status
    status: str = AssetStatus.ACTIVE
    # Depreciation tracking
    depreciation_entries: list[DepreciationEntry] = field(default_factory=list)
    disposal_proceeds: Money | None = None
    tags: set[str] = field(default_factory=set)

    @property
    def accumulated_depreciation(self) -> Money:
        total = Money.zero(self.cost.currency)
        for entry in self.depreciation_entries:
            total = total + entry.amount
        return total

    @property
    def book_value(self) -> Money:
        return self.cost - self.accumulated_depreciation

    @property
    def is_fully_depreciated(self) -> bool:
        return self.book_value <= self.salvage_value

    @property
    def is_disposed(self) -> bool:
        return self.status == AssetStatus.DISPOSED

    def calculate_depreciation(self) -> list[DepreciationEntry]:
        """Calculate the full depreciation schedule."""
        if self.depreciation_method == DepreciationMethod.STRAIGHT_LINE:
            return calculate_straight_line(
                self.cost, self.salvage_value, self.useful_life_years,
                self.convention, self.in_service_date or self.acquisition_date,
            )
        elif self.depreciation_method == DepreciationMethod.DOUBLE_DECLINING:
            return calculate_double_declining(
                self.cost, self.salvage_value, self.useful_life_years,
                self.convention, self.in_service_date or self.acquisition_date,
            )
        elif self.depreciation_method == DepreciationMethod.SUM_OF_YEARS:
            return calculate_sum_of_years(
                self.cost, self.salvage_value, self.useful_life_years,
                self.in_service_date or self.acquisition_date,
            )
        return []

    def compute_disposal_gain_loss(self, sale_price: Money) -> Money:
        """Compute gain or loss on disposal.

        Positive = gain, Negative = loss.
        """
        return sale_price - self.book_value


class FixedAssetRegister:
    """Registry of all fixed assets."""

    def __init__(self):
        self._assets: dict[str, FixedAsset] = {}

    def add_asset(self, asset: FixedAsset) -> None:
        if asset.asset_id in self._assets:
            raise ValueError(f"Asset {asset.asset_id} already exists")
        self._assets[asset.asset_id] = asset

    def get_asset(self, asset_id: str) -> FixedAsset | None:
        return self._assets.get(asset_id)

    def record_acquisition(
        self,
        asset: FixedAsset,
        entry_id: str,
        cash_account: str,
    ) -> JournalEntry:
        """Generate journal entry for asset acquisition.

        Dr. Fixed Asset (at cost)
          Cr. Cash/AP (payment)
        """
        self.add_asset(asset)
        entry = JournalEntry(
            entry_id=entry_id,
            entry_date=asset.acquisition_date,
            description=f"Acquisition of {asset.name}",
        )
        entry.add_debit(asset.asset_account, asset.cost)
        entry.add_credit(cash_account, asset.cost)
        return entry

    def record_depreciation(
        self,
        asset_id: str,
        period: int,
        entry_id: str,
        entry_date: date,
    ) -> JournalEntry | None:
        """Generate journal entry for one period's depreciation.

        Dr. Depreciation Expense
          Cr. Accumulated Depreciation
        """
        asset = self._assets.get(asset_id)
        if asset is None or asset.is_disposed:
            return None

        schedule = asset.calculate_depreciation()
        if period < 1 or period > len(schedule):
            return None

        dep_entry = schedule[period - 1]
        asset.depreciation_entries.append(dep_entry)

        entry = JournalEntry(
            entry_id=entry_id,
            entry_date=entry_date,
            description=f"Depreciation: {asset.name} (period {period})",
            entry_type=EntryType.ADJUSTING,
        )
        entry.add_debit(asset.depreciation_account, dep_entry.amount)
        entry.add_credit(asset.accumulated_account, dep_entry.amount)
        return entry

    def record_disposal(
        self,
        asset_id: str,
        sale_price: Money,
        disposal_date: date,
        entry_id: str,
        cash_account: str,
    ) -> JournalEntry | None:
        """Generate journal entry for asset disposal.

        Dr. Cash (sale proceeds)
        Dr. Accumulated Depreciation (remove accumulated)
        Dr/Cr. Gain/Loss on Disposal
          Cr. Fixed Asset (remove at cost)
        """
        asset = self._assets.get(asset_id)
        if asset is None or asset.is_disposed:
            return None

        gain_loss = asset.compute_disposal_gain_loss(sale_price)
        accum = asset.accumulated_depreciation

        entry = JournalEntry(
            entry_id=entry_id,
            entry_date=disposal_date,
            description=f"Disposal of {asset.name}",
        )

        # Debit: Cash received
        if not sale_price.is_zero:
            entry.add_debit(cash_account, sale_price)

        # Debit: Remove accumulated depreciation
        if not accum.is_zero:
            entry.add_debit(asset.accumulated_account, accum)

        # Credit: Remove asset at cost
        entry.add_credit(asset.asset_account, asset.cost)

        # Gain or loss
        if gain_loss.is_positive:
            entry.add_credit(asset.gain_loss_account, gain_loss)
        elif gain_loss.is_negative:
            entry.add_debit(asset.gain_loss_account, abs(gain_loss))

        asset.status = AssetStatus.DISPOSED
        asset.disposal_date = disposal_date
        asset.disposal_proceeds = sale_price

        return entry

    def get_active_assets(self) -> list[FixedAsset]:
        return [a for a in self._assets.values() if a.status == AssetStatus.ACTIVE]

    def get_by_category(self, category: str) -> list[FixedAsset]:
        return [a for a in self._assets.values() if a.category == category]

    def total_cost(self) -> Money:
        if not self._assets:
            return Money(0, Currency("USD", "$"))
        first = next(iter(self._assets.values()))
        total = Money.zero(first.cost.currency)
        for asset in self._assets.values():
            if asset.status != AssetStatus.DISPOSED:
                total = total + asset.cost
        return total

    def total_book_value(self) -> Money:
        if not self._assets:
            return Money(0, Currency("USD", "$"))
        first = next(iter(self._assets.values()))
        total = Money.zero(first.cost.currency)
        for asset in self._assets.values():
            if asset.status != AssetStatus.DISPOSED:
                total = total + asset.book_value
        return total

    @property
    def asset_count(self) -> int:
        return len(self._assets)
