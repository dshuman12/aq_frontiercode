"""Bank reconciliation engine.

Reconciliation matches bank statement transactions against ledger entries.
The goal is to explain the difference between the bank balance and the
ledger balance.

Reconciliation equation:
  Bank Balance
  + Deposits in transit (recorded in ledger, not yet on bank statement)
  - Outstanding checks (recorded in ledger, not yet cleared by bank)
  +/- Bank errors
  = Adjusted Bank Balance

  Ledger Balance
  + Bank charges not yet recorded
  + Interest earned not yet recorded
  - NSF checks not yet recorded
  +/- Ledger errors
  = Adjusted Ledger Balance

  Adjusted Bank Balance MUST EQUAL Adjusted Ledger Balance

Matching algorithm:
1. Exact match: same amount, close dates
2. Batch match: multiple ledger entries match one bank transaction (or vice versa)
3. Partial match: amount within tolerance
4. Unmatched: requires manual review
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from typing import Any
from ledgercore.core.money import Money, Currency


@dataclass
class BankTransaction:
    """A transaction from the bank statement."""
    transaction_id: str
    transaction_date: date
    amount: Money  # positive = deposit, negative = withdrawal
    description: str = ""
    reference: str = ""
    matched: bool = False
    matched_entries: list[str] = field(default_factory=list)


@dataclass
class ReconciliationItem:
    """An item in the reconciliation."""
    description: str
    amount: Money
    category: str = ""  # "deposit_in_transit", "outstanding_check", etc.
    bank_transaction_id: str = ""
    ledger_entry_id: str = ""


@dataclass
class ReconciliationResult:
    """Result of a reconciliation."""
    bank_balance: Money
    ledger_balance: Money
    adjusted_bank_balance: Money
    adjusted_ledger_balance: Money
    matched_items: list[ReconciliationItem] = field(default_factory=list)
    deposits_in_transit: list[ReconciliationItem] = field(default_factory=list)
    outstanding_checks: list[ReconciliationItem] = field(default_factory=list)
    bank_adjustments: list[ReconciliationItem] = field(default_factory=list)
    ledger_adjustments: list[ReconciliationItem] = field(default_factory=list)
    unmatched_bank: list[BankTransaction] = field(default_factory=list)
    is_reconciled: bool = False

    def verify(self) -> bool:
        self.is_reconciled = self.adjusted_bank_balance == self.adjusted_ledger_balance
        return self.is_reconciled


class ReconciliationEngine:
    """Reconcile bank statements against ledger entries."""

    def __init__(self, tolerance: Decimal = Decimal("0.01")):
        self._tolerance = tolerance

    def match_transactions(
        self,
        bank_transactions: list[BankTransaction],
        ledger_amounts: list[tuple[str, date, Money, str]],  # (entry_id, date, amount, desc)
    ) -> tuple[list[tuple[str, str]], list[str], list[str]]:
        """Match bank transactions to ledger entries.

        Returns:
            (matches, unmatched_bank_ids, unmatched_ledger_ids)
            matches = list of (bank_id, ledger_id) pairs
        """
        matches: list[tuple[str, str]] = []
        matched_bank: set[str] = set()
        matched_ledger: set[str] = set()

        # Pass 1: exact amount match
        for bt in bank_transactions:
            if bt.transaction_id in matched_bank:
                continue
            for entry_id, entry_date, amount, desc in ledger_amounts:
                if entry_id in matched_ledger:
                    continue
                if self._amounts_match(bt.amount, amount):
                    if abs((bt.transaction_date - entry_date).days) <= 5:
                        matches.append((bt.transaction_id, entry_id))
                        matched_bank.add(bt.transaction_id)
                        matched_ledger.add(entry_id)
                        break

        # Pass 2: reference match (even if dates differ)
        for bt in bank_transactions:
            if bt.transaction_id in matched_bank:
                continue
            for entry_id, entry_date, amount, desc in ledger_amounts:
                if entry_id in matched_ledger:
                    continue
                if (bt.reference and bt.reference == desc and
                    self._amounts_match(bt.amount, amount)):
                    matches.append((bt.transaction_id, entry_id))
                    matched_bank.add(bt.transaction_id)
                    matched_ledger.add(entry_id)
                    break

        unmatched_b = [bt.transaction_id for bt in bank_transactions
                       if bt.transaction_id not in matched_bank]
        unmatched_l = [eid for eid, _, _, _ in ledger_amounts
                       if eid not in matched_ledger]

        return matches, unmatched_b, unmatched_l

    def _amounts_match(self, a: Money, b: Money) -> bool:
        """Check if two amounts match within tolerance."""
        if a.currency != b.currency:
            return False
        return abs(a.amount - b.amount) <= self._tolerance
