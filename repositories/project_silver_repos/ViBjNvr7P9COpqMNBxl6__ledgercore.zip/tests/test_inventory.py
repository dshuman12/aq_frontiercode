import pytest
from datetime import date
from decimal import Decimal
from ledgercore.core.money import Money, USD
from ledgercore.inventory.costing import InventoryManager, InventoryItem, InventoryLot

class TestFIFO:
    def test_basic(self):
        mgr = InventoryManager("FIFO", USD)
        mgr.add_item(InventoryItem("WIDGET", "Widget", USD))
        mgr.receive_inventory("WIDGET", "L1", date(2025,1,1), 100, Decimal("10"))
        mgr.receive_inventory("WIDGET", "L2", date(2025,2,1), 100, Decimal("12"))
        cogs = mgr.calculate_cogs("WIDGET", 150)
        # FIFO: 100 @ $10 + 50 @ $12 = $1600
        assert cogs.total_cost == Decimal("1600.00")

    def test_after_commit(self):
        mgr = InventoryManager("FIFO", USD)
        mgr.add_item(InventoryItem("W", "W", USD))
        mgr.receive_inventory("W", "L1", date(2025,1,1), 50, Decimal("10"))
        cogs = mgr.calculate_cogs("W", 30)
        mgr.commit_sale("W", cogs)
        item = mgr.get_item("W")
        assert item.total_quantity == 20

class TestLIFO:
    def test_basic(self):
        mgr = InventoryManager("LIFO", USD)
        mgr.add_item(InventoryItem("W", "Widget", USD))
        mgr.receive_inventory("W", "L1", date(2025,1,1), 100, Decimal("10"))
        mgr.receive_inventory("W", "L2", date(2025,2,1), 100, Decimal("12"))
        cogs = mgr.calculate_cogs("W", 150)
        # LIFO: 100 @ $12 + 50 @ $10 = $1700
        assert cogs.total_cost == Decimal("1700.00")

class TestWeightedAverage:
    def test_basic(self):
        mgr = InventoryManager("AVERAGE", USD)
        mgr.add_item(InventoryItem("W", "Widget", USD))
        mgr.receive_inventory("W", "L1", date(2025,1,1), 100, Decimal("10"))
        mgr.receive_inventory("W", "L2", date(2025,2,1), 100, Decimal("12"))
        # Average: (1000 + 1200) / 200 = $11
        item = mgr.get_item("W")
        assert item.average_unit_cost == Decimal("11.00")
        cogs = mgr.calculate_cogs("W", 150)
        assert cogs.total_cost == Decimal("1650.00")

class TestInventoryEntries:
    def test_purchase_entry(self):
        mgr = InventoryManager("FIFO", USD)
        mgr.add_item(InventoryItem("W", "Widget", USD))
        lot = mgr.receive_inventory("W", "L1", date(2025,1,1), 50, Decimal("20"))
        entry = mgr.generate_purchase_entry("W", lot, "E001", "1400", "1100")
        assert entry.is_balanced

    def test_sale_entry(self):
        mgr = InventoryManager("FIFO", USD)
        mgr.add_item(InventoryItem("W", "Widget", USD))
        mgr.receive_inventory("W", "L1", date(2025,1,1), 100, Decimal("10"))
        cogs = mgr.calculate_cogs("W", 50)
        entry = mgr.generate_sale_entry(
            "W", cogs, Money(750, USD), "E002", date(2025,2,1),
            "5000", "1400", "1100", "4100",
        )
        assert entry.is_balanced

    def test_insufficient_inventory(self):
        mgr = InventoryManager("FIFO", USD)
        mgr.add_item(InventoryItem("W", "Widget", USD))
        mgr.receive_inventory("W", "L1", date(2025,1,1), 10, Decimal("10"))
        with pytest.raises(ValueError):
            mgr.calculate_cogs("W", 50)
