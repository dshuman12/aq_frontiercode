import pytest
from datetime import date, timedelta
from ledgercore.core.money import Money, USD
from ledgercore.ledger.subledger import (
    Subledger, CounterpartyAccount, SubledgerTransaction, TransactionType,
)

class TestSubledger:
    def test_invoice_and_payment(self):
        sl = Subledger("AR", "1200", USD)
        sl.add_counterparty(CounterpartyAccount("C001", "Acme Corp"))
        sl.record_invoice("C001", "INV001", date(2025,1,1), date(2025,1,31), Money(1000, USD))
        assert sl.get_counterparty("C001").balance == Money(1000, USD)
        sl.record_payment("C001", "PMT001", date(2025,1,20), Money(600, USD), "INV001")
        assert sl.get_counterparty("C001").balance == Money(400, USD)

    def test_open_invoices(self):
        sl = Subledger("AR", "1200", USD)
        sl.add_counterparty(CounterpartyAccount("C001", "Test"))
        sl.record_invoice("C001", "INV001", date(2025,1,1), date(2025,1,31), Money(500, USD))
        sl.record_invoice("C001", "INV002", date(2025,2,1), date(2025,2,28), Money(300, USD))
        sl.record_payment("C001", "PMT001", date(2025,2,15), Money(500, USD), "INV001")
        open_inv = sl.get_counterparty("C001").open_invoices
        assert len(open_inv) == 1  # INV002 still open
        assert open_inv[0].transaction_id == "INV002"

    def test_overdue(self):
        sl = Subledger("AR", "1200", USD)
        sl.add_counterparty(CounterpartyAccount("C001", "Late Payer"))
        sl.record_invoice("C001", "INV001", date(2025,1,1), date(2025,1,31), Money(1000, USD))
        acct = sl.get_counterparty("C001")
        assert acct.is_overdue(date(2025, 3, 1))
        assert not acct.is_overdue(date(2025, 1, 15))

    def test_total_balance(self):
        sl = Subledger("AR", "1200", USD)
        sl.add_counterparty(CounterpartyAccount("C001", "A"))
        sl.add_counterparty(CounterpartyAccount("C002", "B"))
        sl.record_invoice("C001", "I1", date(2025,1,1), date(2025,1,31), Money(500, USD))
        sl.record_invoice("C002", "I2", date(2025,1,1), date(2025,1,31), Money(700, USD))
        assert sl.total_balance() == Money(1200, USD)
