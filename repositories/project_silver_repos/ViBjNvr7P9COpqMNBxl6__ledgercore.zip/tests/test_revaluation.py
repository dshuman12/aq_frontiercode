import pytest
from datetime import date
from decimal import Decimal
from ledgercore.core.money import Money, USD, EUR, Currency
from ledgercore.currency.exchange import ExchangeRate, ExchangeRateStore
from ledgercore.currency.revaluation import CurrencyRevaluator

class TestRevaluation:
    def test_gain(self):
        store = ExchangeRateStore()
        store.set_rate(ExchangeRate(EUR, USD, Decimal("1.10"), date(2025,1,1)))
        store.set_rate(ExchangeRate(EUR, USD, Decimal("1.15"), date(2025,1,31)))
        rev = CurrencyRevaluator(store, USD)
        result = rev.revalue_account(
            "1200", Money(1000, EUR), Money(1100, USD), date(2025,1,31),
        )
        assert result is not None
        assert result.gain_loss.is_positive  # EUR appreciated
        assert result.revalued_balance == Money(1150, USD)

    def test_loss(self):
        store = ExchangeRateStore()
        store.set_rate(ExchangeRate(EUR, USD, Decimal("1.10"), date(2025,1,1)))
        store.set_rate(ExchangeRate(EUR, USD, Decimal("1.05"), date(2025,1,31)))
        rev = CurrencyRevaluator(store, USD)
        result = rev.revalue_account(
            "1200", Money(1000, EUR), Money(1100, USD), date(2025,1,31),
        )
        assert result is not None
        assert result.gain_loss.is_negative

    def test_entries_balanced(self):
        store = ExchangeRateStore()
        store.set_rate(ExchangeRate(EUR, USD, Decimal("1.15"), date(2025,1,31)))
        rev = CurrencyRevaluator(store, USD)
        result = rev.revalue_account(
            "1200", Money(1000, EUR), Money(1100, USD), date(2025,1,31),
        )
        counter = [0]
        def gen_id():
            counter[0] += 1
            return f"REV{counter[0]:03d}"
        entries = rev.generate_revaluation_entries([result], gen_id, date(2025,1,31))
        assert len(entries) == 1
        assert entries[0].is_balanced

    def test_no_revaluation_for_functional(self):
        store = ExchangeRateStore()
        rev = CurrencyRevaluator(store, USD)
        result = rev.revalue_account("1100", Money(1000, USD), Money(1000, USD), date(2025,1,31))
        assert result is None
