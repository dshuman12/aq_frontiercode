import pytest
from ledgercore.core.account import (Account, AccountType, NormalBalance,
    get_normal_balance, infer_account_type)
from ledgercore.core.money import USD

class TestNormalBalance:
    def test_assets_debit_normal(self):
        assert get_normal_balance(AccountType.ASSET) == NormalBalance.DEBIT
    def test_liabilities_credit_normal(self):
        assert get_normal_balance(AccountType.LIABILITY) == NormalBalance.CREDIT
    def test_revenue_credit_normal(self):
        assert get_normal_balance(AccountType.REVENUE) == NormalBalance.CREDIT
    def test_expenses_debit_normal(self):
        assert get_normal_balance(AccountType.EXPENSE) == NormalBalance.DEBIT
    def test_contra_asset_credit_normal(self):
        assert get_normal_balance(AccountType.CONTRA_ASSET) == NormalBalance.CREDIT

class TestInferType:
    def test_asset(self):
        assert infer_account_type("1100") == AccountType.ASSET
    def test_liability(self):
        assert infer_account_type("2100") == AccountType.LIABILITY
    def test_equity(self):
        assert infer_account_type("3100") == AccountType.EQUITY
    def test_revenue(self):
        assert infer_account_type("4100") == AccountType.REVENUE
    def test_expense(self):
        assert infer_account_type("5100") == AccountType.EXPENSE

class TestAccountProperties:
    def test_balance_sheet(self):
        a = Account("1100", "Cash", AccountType.ASSET, USD)
        assert a.is_balance_sheet
        assert not a.is_income_statement
    def test_income_statement(self):
        a = Account("4100", "Sales", AccountType.REVENUE, USD)
        assert a.is_income_statement
        assert not a.is_balance_sheet
    def test_child_of(self):
        a = Account("11", "Current Assets", AccountType.ASSET, USD, parent_number="1")
        assert a.is_child_of("1")
        assert not a.is_child_of("2")
