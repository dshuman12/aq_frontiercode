import pytest
from decimal import Decimal
from datetime import date
from ledgercore.core.money import Money, USD
from ledgercore.allocation.engine import AllocationEngine, CostCenter, AllocationRule

class TestDirectAllocation:
    def test_basic(self):
        engine = AllocationEngine(USD)
        engine.add_center(CostCenter("PROD", "Production", expense_account="5100"))
        engine.add_center(CostCenter("ADMIN", "Admin", expense_account="5200"))
        rule = AllocationRule("R1", "6000", targets=[("PROD", Decimal("70")), ("ADMIN", Decimal("30"))])
        results = engine.allocate_direct(Money(10000, USD), rule)
        assert len(results) == 2
        prod = next(r for r in results if r.center_id == "PROD")
        assert prod.amount == Money(7000, USD)

    def test_by_base(self):
        engine = AllocationEngine(USD)
        engine.add_center(CostCenter("A", "Dept A", allocation_base_value=Decimal("30"), expense_account="5100"))
        engine.add_center(CostCenter("B", "Dept B", allocation_base_value=Decimal("70"), expense_account="5200"))
        rule = AllocationRule("R1", "6000", targets=[("A", Decimal("0")), ("B", Decimal("0"))])
        results = engine.allocate_by_base(Money(10000, USD), rule)
        a_result = next(r for r in results if r.center_id == "A")
        assert a_result.amount == Money(3000, USD)

class TestStepDown:
    def test_basic(self):
        engine = AllocationEngine(USD)
        engine.add_center(CostCenter("IT", "IT Dept", is_service=True, expense_account="6100"))
        engine.add_center(CostCenter("PROD", "Production", expense_account="5100"))
        engine.add_center(CostCenter("SALES", "Sales", expense_account="5200"))
        pools = {"IT": Money(10000, USD)}
        pcts = {"IT": {"PROD": Decimal("0.60"), "SALES": Decimal("0.40")}}
        results = engine.step_down_allocation(pools, ["IT"], pcts)
        assert "IT" in results
        assert len(results["IT"]) == 2

class TestReciprocal:
    def test_convergence(self):
        engine = AllocationEngine(USD)
        pools = {"A": Money(10000, USD), "B": Money(8000, USD)}
        pcts = {
            "A": {"B": Decimal("0.10")},
            "B": {"A": Decimal("0.20")},
        }
        result = engine.reciprocal_allocation(pools, pcts)
        assert result["A"].amount > Decimal("10000")  # receives from B
        assert result["B"].amount > Decimal("8000")   # receives from A

class TestEntryGeneration:
    def test_balanced(self):
        engine = AllocationEngine(USD)
        engine.add_center(CostCenter("P", "Prod", expense_account="5100"))
        engine.add_center(CostCenter("A", "Admin", expense_account="5200"))
        rule = AllocationRule("R1", "6000", targets=[("P", Decimal("60")), ("A", Decimal("40"))])
        results = engine.allocate_direct(Money(10000, USD), rule)
        entry = engine.generate_entries(results, "ALLOC001", date(2025, 1, 31))
        assert entry.is_balanced
