import pytest
from datetime import date
from decimal import Decimal
from ledgercore.core.money import Money, USD
from ledgercore.core.account import Account, AccountType
from ledgercore.core.entry import JournalEntry
from ledgercore.chart.chart_of_accounts import ChartOfAccounts
from ledgercore.ledger.general_ledger import GeneralLedger
from ledgercore.reports.consolidation import ConsolidationEngine, EntityInfo

class TestConsolidation:
    def test_basic_consolidation(self):
        # Parent
        p_chart = ChartOfAccounts("Parent", USD)
        p_chart.add_account(Account("1100", "Cash", AccountType.ASSET, USD))
        p_chart.add_account(Account("3100", "Equity", AccountType.EQUITY, USD))
        p_ledger = GeneralLedger(p_chart)
        e1 = JournalEntry("PE001", date(2025,1,1))
        e1.add_debit("1100", Money(100000, USD))
        e1.add_credit("3100", Money(100000, USD))
        p_ledger.post_entry(e1)
        # Subsidiary
        s_chart = ChartOfAccounts("Sub", USD)
        s_chart.add_account(Account("1100", "Cash", AccountType.ASSET, USD))
        s_chart.add_account(Account("3100", "Equity", AccountType.EQUITY, USD))
        s_ledger = GeneralLedger(s_chart)
        e2 = JournalEntry("SE001", date(2025,1,1))
        e2.add_debit("1100", Money(50000, USD))
        e2.add_credit("3100", Money(50000, USD))
        s_ledger.post_entry(e2)
        # Consolidate
        engine = ConsolidationEngine(USD)
        engine.add_entity(EntityInfo("PARENT", "Parent Co", p_ledger, USD, is_parent=True))
        engine.add_entity(EntityInfo("SUB", "Sub Co", s_ledger, USD, ownership_pct=Decimal("0.80")))
        report = engine.consolidate(date(2025,1,31))
        assert len(report.lines) >= 2
        # NCI should be 20% of Sub's equity
        equity_line = next(l for l in report.lines if l.account_number == "3100")
        assert equity_line.nci_amount is not None

    def test_single_entity(self):
        chart = ChartOfAccounts("Solo", USD)
        chart.add_account(Account("1100", "Cash", AccountType.ASSET, USD))
        chart.add_account(Account("3100", "Equity", AccountType.EQUITY, USD))
        ledger = GeneralLedger(chart)
        e = JournalEntry("E001", date(2025,1,1))
        e.add_debit("1100", Money(10000, USD))
        e.add_credit("3100", Money(10000, USD))
        ledger.post_entry(e)
        engine = ConsolidationEngine(USD)
        engine.add_entity(EntityInfo("SOLO", "Solo Co", ledger, USD, is_parent=True))
        report = engine.consolidate(date(2025,1,31))
        cash_line = next(l for l in report.lines if l.account_number == "1100")
        assert cash_line.consolidated == Money(10000, USD)
