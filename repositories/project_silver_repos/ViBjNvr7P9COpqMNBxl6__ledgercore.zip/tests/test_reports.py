import pytest
from datetime import date
from decimal import Decimal
from ledgercore.core.money import Money, USD
from ledgercore.core.account import Account, AccountType
from ledgercore.core.entry import JournalEntry
from ledgercore.chart.chart_of_accounts import ChartOfAccounts
from ledgercore.ledger.general_ledger import GeneralLedger
from ledgercore.reports.financial_statements import ReportGenerator

@pytest.fixture
def setup():
    chart = ChartOfAccounts("Test", USD)
    chart.add_account(Account("1100", "Cash", AccountType.ASSET, USD))
    chart.add_account(Account("2100", "AP", AccountType.LIABILITY, USD))
    chart.add_account(Account("3100", "Equity", AccountType.EQUITY, USD))
    chart.add_account(Account("4100", "Revenue", AccountType.REVENUE, USD))
    chart.add_account(Account("5100", "Expense", AccountType.EXPENSE, USD))
    ledger = GeneralLedger(chart)
    e1 = JournalEntry("E001", date(2025,1,5))
    e1.add_debit("1100", Money(10000, USD))
    e1.add_credit("3100", Money(10000, USD))
    ledger.post_entry(e1)
    e2 = JournalEntry("E002", date(2025,1,15))
    e2.add_debit("1100", Money(5000, USD))
    e2.add_credit("4100", Money(5000, USD))
    ledger.post_entry(e2)
    e3 = JournalEntry("E003", date(2025,1,20))
    e3.add_debit("5100", Money(2000, USD))
    e3.add_credit("1100", Money(2000, USD))
    ledger.post_entry(e3)
    return ledger

class TestBalanceSheet:
    def test_balanced(self, setup):
        gen = ReportGenerator(setup, USD)
        bs = gen.balance_sheet(date(2025,1,31))
        # Assets: 10000 + 5000 - 2000 = 13000 (Cash)
        # Liabilities: 0
        # Equity: 10000 (initial) but revenue/expense not closed yet
        # Before closing, BS won't balance because P&L isn't in equity
        assert bs.total_assets is not None

class TestIncomeStatement:
    def test_net_income(self, setup):
        gen = ReportGenerator(setup, USD)
        pnl = gen.income_statement(date(2025,1,1), date(2025,1,31))
        assert pnl.total_revenue == Money(5000, USD)
        assert pnl.total_expenses == Money(2000, USD)
        assert pnl.net_income == Money(3000, USD)
