import pytest
from datetime import date
from decimal import Decimal
from ledgercore.core.money import Money, USD
from ledgercore.ledger.intercompany import (
    IntercompanyManager, IntercompanyTransaction, CompanyRelationship,
)

class TestIntercompany:
    def test_elimination_entries(self):
        mgr = IntercompanyManager()
        mgr.add_relationship(CompanyRelationship("PARENT", "SUB", Decimal("0.80"), date(2025,1,1)))
        mgr.add_transaction(IntercompanyTransaction(
            "IC001", "PARENT", "SUB", Money(1000, USD), date(2025,1,15), "IC sale",
        ))
        counter = [0]
        def gen_id():
            counter[0] += 1
            return f"ELIM-{counter[0]:03d}"
        entries = mgr.generate_elimination_entries(
            date(2025,1,31), "4100", "5100", "1200", "2100", gen_id,
        )
        assert len(entries) >= 2  # revenue/expense + receivable/payable
        for e in entries:
            assert e.is_balanced

    def test_unrealized_profit(self):
        mgr = IntercompanyManager()
        mgr.add_transaction(IntercompanyTransaction(
            "IC002", "P", "S", Money(1000, USD), date(2025,1,15),
            profit_margin=Decimal("0.20"),
        ))
        counter = [0]
        def gen_id():
            counter[0] += 1
            return f"ELIM-{counter[0]:03d}"
        entries = mgr.generate_elimination_entries(
            date(2025,1,31), "4100", "5100", "1200", "2100", gen_id,
        )
        # Should have 3 entries: rev/exp, AR/AP, and unrealized profit
        assert len(entries) == 3

    def test_ownership(self):
        mgr = IntercompanyManager()
        mgr.add_relationship(CompanyRelationship("P", "S", Decimal("0.80"), date(2025,1,1)))
        assert mgr.get_ownership("P", "S") == Decimal("0.80")
        assert mgr.get_ownership("P", "X") == Decimal("0")
