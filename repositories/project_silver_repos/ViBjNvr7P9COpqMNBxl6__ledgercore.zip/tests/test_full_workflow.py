"""Comprehensive integration test: full year-end workflow."""
import pytest
from datetime import date
from decimal import Decimal
from ledgercore.core.money import Money, USD
from ledgercore.core.account import Account, AccountType
from ledgercore.core.entry import JournalEntry, EntryType
from ledgercore.chart.chart_of_accounts import ChartOfAccounts
from ledgercore.ledger.general_ledger import GeneralLedger
from ledgercore.period.fiscal_period import FiscalPeriod, FiscalCalendar
from ledgercore.reports.financial_statements import ReportGenerator
from ledgercore.reports.ratios import RatioAnalyzer
from ledgercore.budget.budget_manager import BudgetManager
from ledgercore.ledger.accruals import AccrualEngine, AccrualTemplate, AccrualType
from ledgercore.core.fixed_assets import FixedAsset, FixedAssetRegister, DepreciationMethod, Convention
from ledgercore.inventory.costing import InventoryManager, InventoryItem

class TestYearEndWorkflow:
    """Simulate a full year of business operations and year-end close."""

    def test_full_year(self):
        # Setup chart of accounts
        chart = ChartOfAccounts("Acme Corp", USD)
        for num, name, typ in [
            ("1100", "Cash", AccountType.ASSET),
            ("1200", "Accounts Receivable", AccountType.ASSET),
            ("1400", "Inventory", AccountType.ASSET),
            ("1500", "Equipment", AccountType.ASSET),
            ("1510", "Accumulated Depreciation", AccountType.CONTRA_ASSET),
            ("2100", "Accounts Payable", AccountType.LIABILITY),
            ("2500", "Loan Payable", AccountType.LIABILITY),
            ("3100", "Common Stock", AccountType.EQUITY),
            ("3200", "Retained Earnings", AccountType.EQUITY),
            ("3900", "Income Summary", AccountType.EQUITY),
            ("4100", "Sales Revenue", AccountType.REVENUE),
            ("4200", "Service Revenue", AccountType.REVENUE),
            ("5100", "Cost of Goods Sold", AccountType.EXPENSE),
            ("5200", "Salary Expense", AccountType.EXPENSE),
            ("5300", "Depreciation Expense", AccountType.EXPENSE),
            ("5400", "Rent Expense", AccountType.EXPENSE),
            ("5500", "Utilities Expense", AccountType.EXPENSE),
            ("5600", "Interest Expense", AccountType.EXPENSE),
        ]:
            chart.add_account(Account(num, name, typ, USD,
                                     is_system=(num == "3200")))

        ledger = GeneralLedger(chart)
        cal = FiscalCalendar(USD)
        cal.set_retained_earnings_account("3200")
        cal.set_income_summary_account("3900")

        # Add fiscal periods
        for m in range(1, 13):
            import calendar
            last_day = calendar.monthrange(2025, m)[1]
            cal.add_period(FiscalPeriod(
                f"2025-{m:02d}",
                date(2025, m, 1),
                date(2025, m, last_day),
            ))

        # --- January: Initial investment ---
        e = JournalEntry("JAN-001", date(2025, 1, 2))
        e.add_debit("1100", Money(100000, USD))
        e.add_credit("3100", Money(100000, USD))
        assert ledger.post_entry(e) == []

        # Take out a loan
        e = JournalEntry("JAN-002", date(2025, 1, 5))
        e.add_debit("1100", Money(50000, USD))
        e.add_credit("2500", Money(50000, USD))
        assert ledger.post_entry(e) == []

        # Buy equipment
        e = JournalEntry("JAN-003", date(2025, 1, 10))
        e.add_debit("1500", Money(30000, USD))
        e.add_credit("1100", Money(30000, USD))
        assert ledger.post_entry(e) == []

        # Purchase inventory
        e = JournalEntry("JAN-004", date(2025, 1, 15))
        e.add_debit("1400", Money(20000, USD))
        e.add_credit("1100", Money(20000, USD))
        assert ledger.post_entry(e) == []

        # --- Ongoing: Monthly operations ---
        entry_counter = [100]
        def gen_eid():
            entry_counter[0] += 1
            return f"OPS-{entry_counter[0]:04d}"

        for month in range(1, 13):
            m_date = date(2025, month, 15)

            # Revenue
            rev = JournalEntry(gen_eid(), m_date)
            rev.add_debit("1200", Money(15000, USD))
            rev.add_credit("4100", Money(15000, USD))
            assert ledger.post_entry(rev) == []

            # Collect receivables
            coll = JournalEntry(gen_eid(), m_date)
            coll.add_debit("1100", Money(14000, USD))
            coll.add_credit("1200", Money(14000, USD))
            assert ledger.post_entry(coll) == []

            # COGS
            cogs = JournalEntry(gen_eid(), date(2025, month, 20))
            cogs.add_debit("5100", Money(6000, USD))
            cogs.add_credit("1400", Money(6000, USD))
            assert ledger.post_entry(cogs) == []

            # Salaries
            sal = JournalEntry(gen_eid(), date(2025, month, 25))
            sal.add_debit("5200", Money(4000, USD))
            sal.add_credit("1100", Money(4000, USD))
            assert ledger.post_entry(sal) == []

            # Rent
            rent = JournalEntry(gen_eid(), date(2025, month, 1))
            rent.add_debit("5400", Money(1500, USD))
            rent.add_credit("1100", Money(1500, USD))
            assert ledger.post_entry(rent) == []

        # --- Year-end: Depreciation ---
        dep = JournalEntry(gen_eid(), date(2025, 12, 31))
        dep.add_debit("5300", Money(6000, USD))
        dep.add_credit("1510", Money(6000, USD))
        assert ledger.post_entry(dep) == []

        # --- Verify trial balance ---
        ok, td, tc = ledger.verify_trial_balance()
        assert ok, f"Trial balance failed: {td} != {tc}"

        # --- Income statement ---
        gen = ReportGenerator(ledger, USD)
        pnl = gen.income_statement(date(2025, 1, 1), date(2025, 12, 31))
        assert pnl.total_revenue == Money(180000, USD)  # 15000 * 12
        expected_expenses = 6000 * 12 + 4000 * 12 + 1500 * 12 + 6000
        assert pnl.total_expenses == Money(expected_expenses, USD)
        assert pnl.net_income.is_positive

        # --- Ratios ---
        analyzer = RatioAnalyzer(ledger, USD)
        ratios = analyzer.all_ratios(date(2025, 12, 31), date(2025, 1, 1))
        assert len(ratios) >= 5

        # --- Close all periods ---
        for m in range(1, 13):
            period_id = f"2025-{m:02d}"
            errors, _ = cal.close_period(period_id, ledger, gen_eid)
            assert errors == [], f"Close {period_id} failed: {errors}"

        # After closing: revenue and expense should be zero
        for acct in chart.get_by_type(AccountType.REVENUE):
            bal = ledger.get_account_balance(acct.number)
            assert bal.is_zero, f"Revenue {acct.number} not zero: {bal}"
        for acct in chart.get_by_type(AccountType.EXPENSE):
            bal = ledger.get_account_balance(acct.number)
            assert bal.is_zero, f"Expense {acct.number} not zero: {bal}"

        # Retained earnings should equal net income
        re_bal = ledger.get_account_balance("3200")
        assert re_bal == pnl.net_income

        # Trial balance STILL balanced
        ok2, _, _ = ledger.verify_trial_balance()
        assert ok2


class TestBudgetVarianceWorkflow:
    """Test budget setup, actual posting, and variance analysis."""

    def test_monthly_budget(self):
        chart = ChartOfAccounts("T", USD)
        chart.add_account(Account("1100", "Cash", AccountType.ASSET, USD))
        chart.add_account(Account("3100", "Equity", AccountType.EQUITY, USD))
        chart.add_account(Account("4100", "Revenue", AccountType.REVENUE, USD))
        chart.add_account(Account("5100", "Rent", AccountType.EXPENSE, USD))
        chart.add_account(Account("5200", "Salary", AccountType.EXPENSE, USD))
        ledger = GeneralLedger(chart)

        # Initial capital
        e = JournalEntry("E001", date(2025,1,1))
        e.add_debit("1100", Money(100000, USD))
        e.add_credit("3100", Money(100000, USD))
        ledger.post_entry(e)

        # Budget
        budget = BudgetManager(USD)
        budget.set_budget("4100", "2025-01", Money(10000, USD))
        budget.set_budget("5100", "2025-01", Money(2000, USD))
        budget.set_budget("5200", "2025-01", Money(5000, USD))

        # Actual: revenue exceeds budget, rent under, salary over
        e2 = JournalEntry("E002", date(2025,1,15))
        e2.add_debit("1100", Money(12000, USD))
        e2.add_credit("4100", Money(12000, USD))
        ledger.post_entry(e2)

        e3 = JournalEntry("E003", date(2025,1,20))
        e3.add_debit("5100", Money(1800, USD))
        e3.add_debit("5200", Money(5500, USD))
        e3.add_credit("1100", Money(7300, USD))
        ledger.post_entry(e3)

        # Variance analysis
        rev_var = budget.compute_variance("4100", "Revenue", AccountType.REVENUE, "2025-01",
                                          ledger.get_account_balance("4100"))
        assert rev_var.is_favorable  # actual > budget for revenue

        rent_var = budget.compute_variance("5100", "Rent", AccountType.EXPENSE, "2025-01",
                                           ledger.get_account_balance("5100"))
        assert rent_var.is_favorable  # actual < budget for expense

        sal_var = budget.compute_variance("5200", "Salary", AccountType.EXPENSE, "2025-01",
                                          ledger.get_account_balance("5200"))
        assert not sal_var.is_favorable  # actual > budget for expense


class TestInventoryWorkflow:
    """Test FIFO vs LIFO impact on financial statements."""

    def test_fifo_vs_lifo_cogs(self):
        # Same purchases, different COGS due to costing method
        for method in ["FIFO", "LIFO"]:
            mgr = InventoryManager(method, USD)
            mgr.add_item(InventoryItem("W", "Widget", USD))
            # Buy at increasing prices (inflation)
            mgr.receive_inventory("W", "L1", date(2025,1,1), 100, Decimal("10"))
            mgr.receive_inventory("W", "L2", date(2025,6,1), 100, Decimal("15"))
            mgr.receive_inventory("W", "L3", date(2025,9,1), 100, Decimal("20"))
            # Sell 200 units
            cogs = mgr.calculate_cogs("W", 200)
            if method == "FIFO":
                # First 100 @ $10, next 100 @ $15 = $2500
                assert cogs.total_cost == Decimal("2500.00")
            else:
                # Last 100 @ $20, next 100 @ $15 = $3500
                assert cogs.total_cost == Decimal("3500.00")
