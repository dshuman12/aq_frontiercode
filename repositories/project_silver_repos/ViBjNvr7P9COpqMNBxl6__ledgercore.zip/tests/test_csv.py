import pytest
from datetime import date
from decimal import Decimal
from ledgercore.core.money import Money, USD
from ledgercore.core.entry import JournalEntry
from ledgercore.serialization.csv_codec import CSVImporter, CSVExporter, ImportMapping

class TestCSVImport:
    def test_journal_import(self):
        csv_text = """Date,Description,Account,Debit,Credit
2025-01-15,Sale,1100,1000,
2025-01-15,Sale,4100,,1000"""
        imp = CSVImporter(USD)
        counter = [0]
        def gen_id():
            counter[0] += 1
            return f"IMP{counter[0]:03d}"
        result = imp.import_journal_entries(csv_text, gen_id)
        assert len(result.entries) >= 1
        assert result.entries[0].is_balanced

    def test_bank_feed(self):
        csv_text = """Date,Description,Amount
2025-01-10,Deposit,5000
2025-01-15,ATM Withdrawal,-200"""
        mapping = ImportMapping(date_col=0, description_col=1, debit_col=2, credit_col=2)
        imp = CSVImporter(USD, mapping)
        counter = [0]
        def gen_id():
            counter[0] += 1
            return f"BNK{counter[0]:03d}"
        result = imp.import_bank_feed(csv_text, "1100", "4900", "5900", gen_id)
        assert len(result.entries) == 2
        for e in result.entries:
            assert e.is_balanced

class TestCSVExport:
    def test_export(self):
        entries = []
        e = JournalEntry("E001", date(2025,1,15), description="Test")
        e.add_debit("1100", Money(100, USD))
        e.add_credit("4100", Money(100, USD))
        entries.append(e)
        exp = CSVExporter()
        csv_text = exp.export_entries(entries)
        assert "E001" in csv_text
        assert "1100" in csv_text
