import pytest
from datetime import date
from decimal import Decimal
from ledgercore.core.money import Money, USD
from ledgercore.reports.elimination_worksheet import (
    EliminationWorksheet, EliminationType,
    InvestmentEliminationData,
)

class TestInvestmentElimination:
    def test_100_pct_ownership(self):
        ws = EliminationWorksheet(USD)
        data = InvestmentEliminationData(
            parent_investment_account="1600",
            parent_investment_amount=Money(100000, USD),
            sub_equity_accounts={
                "3100": Money(80000, USD),
                "3200": Money(20000, USD),
            },
            ownership_pct=Decimal("1.0"),
        )
        elim = ws.generate_investment_elimination(data, "ELIM001", date(2025,12,31))
        assert elim.journal_entry.is_balanced

    def test_partial_ownership_with_goodwill(self):
        ws = EliminationWorksheet(USD)
        data = InvestmentEliminationData(
            parent_investment_account="1600",
            parent_investment_amount=Money(90000, USD),
            sub_equity_accounts={
                "3100": Money(50000, USD),
                "3200": Money(30000, USD),
            },
            ownership_pct=Decimal("0.80"),
        )
        # Parent's share of equity = 80000 * 0.80 = 64000
        # Goodwill = 90000 - 64000 = 26000
        # NCI = 80000 * 0.20 = 16000
        elim = ws.generate_investment_elimination(data, "ELIM001", date(2025,12,31))
        assert elim.journal_entry.is_balanced

    def test_all_balanced(self):
        ws = EliminationWorksheet(USD)
        ws.generate_intercompany_revenue_elimination(
            "E1", date(2025,12,31), "4100", "5100", Money(50000, USD),
        )
        ws.generate_intercompany_balance_elimination(
            "E2", date(2025,12,31), "1200", "2100", Money(10000, USD),
        )
        errors = ws.verify_all_balanced()
        assert errors == []


class TestRevenueExpenseElimination:
    def test_basic(self):
        ws = EliminationWorksheet(USD)
        elim = ws.generate_intercompany_revenue_elimination(
            "E1", date(2025,12,31), "4100", "5100", Money(25000, USD),
            "IC sales elimination",
        )
        assert elim.journal_entry.is_balanced
        assert elim.is_recurring


class TestUnrealizedProfitElimination:
    def test_current_period(self):
        ws = EliminationWorksheet(USD)
        elim = ws.generate_unrealized_profit_elimination(
            "E1", date(2025,12,31), Money(5000, USD), "4100", "1400",
        )
        assert elim.journal_entry.is_balanced
        assert elim.elimination_type == EliminationType.UNREALIZED_PROFIT
