import pytest
from datetime import date
from decimal import Decimal
from ledgercore.core.money import Money, USD
from ledgercore.core.amortization import (
    calculate_fixed_rate_schedule, calculate_interest_only_schedule,
    generate_payment_entry,
)

class TestFixedRate:
    def test_basic_schedule(self):
        schedule = calculate_fixed_rate_schedule(
            "L001", Money(100000, USD), Decimal("0.06"), 360, date(2025,1,1),
        )
        assert len(schedule.payments) == 360
        assert schedule.is_paid_off

    def test_total_principal_equals_loan(self):
        schedule = calculate_fixed_rate_schedule(
            "L001", Money(50000, USD), Decimal("0.05"), 60, date(2025,1,1),
        )
        total_principal = Decimal("0")
        for p in schedule.payments:
            total_principal += p.principal.amount
        assert abs(total_principal - Decimal("50000")) < Decimal("0.02")

    def test_early_payments_mostly_interest(self):
        schedule = calculate_fixed_rate_schedule(
            "L001", Money(200000, USD), Decimal("0.06"), 360, date(2025,1,1),
        )
        first = schedule.payments[0]
        assert first.interest > first.principal

    def test_later_payments_mostly_principal(self):
        schedule = calculate_fixed_rate_schedule(
            "L001", Money(200000, USD), Decimal("0.06"), 360, date(2025,1,1),
        )
        last = schedule.payments[-2]  # second to last
        assert last.principal > last.interest

    def test_zero_interest(self):
        schedule = calculate_fixed_rate_schedule(
            "L001", Money(12000, USD), Decimal("0"), 12, date(2025,1,1),
        )
        for p in schedule.payments:
            assert p.interest.is_zero
            assert p.principal == Money(1000, USD)

    def test_journal_entry(self):
        schedule = calculate_fixed_rate_schedule(
            "L001", Money(10000, USD), Decimal("0.06"), 12, date(2025,1,1),
        )
        entry = generate_payment_entry(
            schedule.payments[0], "PMT001", "2500", "5100", "1100",
        )
        assert entry.is_balanced


class TestInterestOnly:
    def test_io_period(self):
        schedule = calculate_interest_only_schedule(
            "L002", Money(100000, USD), Decimal("0.06"), 360, 120, date(2025,1,1),
        )
        # First 120 payments should be interest-only
        for p in schedule.payments[:120]:
            assert p.principal.is_zero
        # After IO period, principal should be paid
        assert schedule.payments[120].principal > Money.zero(USD)
