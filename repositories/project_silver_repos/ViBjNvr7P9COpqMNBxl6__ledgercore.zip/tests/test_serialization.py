import pytest
import json
from datetime import date
from ledgercore.core.money import Money, USD
from ledgercore.core.account import Account, AccountType
from ledgercore.core.entry import JournalEntry
from ledgercore.serialization.json_codec import encode_entry, encode_account

class TestSerialization:
    def test_encode_entry(self):
        e = JournalEntry("E001", date(2025,1,1), description="Test")
        e.add_debit("1100", Money(100, USD))
        e.add_credit("4100", Money(100, USD))
        j = encode_entry(e)
        data = json.loads(j)
        assert data["entry_id"] == "E001"
        assert len(data["lines"]) == 2
    def test_encode_account(self):
        a = Account("1100", "Cash", AccountType.ASSET, USD)
        j = encode_account(a)
        data = json.loads(j)
        assert data["number"] == "1100"
        assert data["type"] == "asset"
