"""Multi-period integration test: open/close/reopen workflow."""
import pytest
from datetime import date
from decimal import Decimal
from ledgercore.core.money import Money, USD
from ledgercore.core.account import Account, AccountType
from ledgercore.core.entry import JournalEntry
from ledgercore.chart.chart_of_accounts import ChartOfAccounts
from ledgercore.ledger.general_ledger import GeneralLedger
from ledgercore.period.fiscal_period import FiscalPeriod, FiscalCalendar
from ledgercore.reports.financial_statements import ReportGenerator

class TestMultiPeriod:
    def test_two_period_close(self):
        chart = ChartOfAccounts("Corp", USD)
        chart.add_account(Account("1100", "Cash", AccountType.ASSET, USD))
        chart.add_account(Account("3100", "RE", AccountType.EQUITY, USD, is_system=True))
        chart.add_account(Account("3900", "IS", AccountType.EQUITY, USD))
        chart.add_account(Account("4100", "Rev", AccountType.REVENUE, USD))
        chart.add_account(Account("5100", "Exp", AccountType.EXPENSE, USD))
        ledger = GeneralLedger(chart)
        cal = FiscalCalendar(USD)
        cal.set_retained_earnings_account("3100")
        cal.set_income_summary_account("3900")
        cal.add_period(FiscalPeriod("P1", date(2025,1,1), date(2025,1,31)))
        cal.add_period(FiscalPeriod("P2", date(2025,2,1), date(2025,2,28)))
        # Period 1 transactions
        e1 = JournalEntry("E001", date(2025,1,15))
        e1.add_debit("1100", Money(5000, USD))
        e1.add_credit("4100", Money(5000, USD))
        ledger.post_entry(e1)
        e2 = JournalEntry("E002", date(2025,1,20))
        e2.add_debit("5100", Money(2000, USD))
        e2.add_credit("1100", Money(2000, USD))
        ledger.post_entry(e2)
        # Close P1
        counter = [0]
        def gen_id():
            counter[0] += 1
            return f"CL{counter[0]:03d}"
        errors, _ = cal.close_period("P1", ledger, gen_id)
        assert errors == []
        # P1 RE should be 3000
        re1 = ledger.get_account_balance("3100")
        assert re1 == Money(3000, USD)
        # Period 2 transactions
        e3 = JournalEntry("E003", date(2025,2,10))
        e3.add_debit("1100", Money(8000, USD))
        e3.add_credit("4100", Money(8000, USD))
        ledger.post_entry(e3)
        e4 = JournalEntry("E004", date(2025,2,15))
        e4.add_debit("5100", Money(1000, USD))
        e4.add_credit("1100", Money(1000, USD))
        ledger.post_entry(e4)
        # Close P2
        errors2, _ = cal.close_period("P2", ledger, gen_id)
        assert errors2 == []
        # RE should be 3000 + 7000 = 10000
        re2 = ledger.get_account_balance("3100")
        assert re2 == Money(10000, USD)
        # Trial balance must still be balanced
        ok, _, _ = ledger.verify_trial_balance()
        assert ok

    def test_cannot_close_out_of_order(self):
        chart = ChartOfAccounts("Corp", USD)
        chart.add_account(Account("1100", "Cash", AccountType.ASSET, USD))
        chart.add_account(Account("3100", "RE", AccountType.EQUITY, USD, is_system=True))
        chart.add_account(Account("3900", "IS", AccountType.EQUITY, USD))
        chart.add_account(Account("4100", "Rev", AccountType.REVENUE, USD))
        ledger = GeneralLedger(chart)
        cal = FiscalCalendar(USD)
        cal.set_retained_earnings_account("3100")
        cal.set_income_summary_account("3900")
        cal.add_period(FiscalPeriod("P1", date(2025,1,1), date(2025,1,31)))
        cal.add_period(FiscalPeriod("P2", date(2025,2,1), date(2025,2,28)))
        counter = [0]
        def gen_id():
            counter[0] += 1
            return f"CL{counter[0]:03d}"
        # Try to close P2 before P1
        errors, _ = cal.close_period("P2", ledger, gen_id)
        assert len(errors) > 0  # P1 must be closed first
