import pytest
from datetime import date
from decimal import Decimal
from ledgercore.core.money import Money, USD, EUR, GBP, Currency
from ledgercore.currency.exchange import ExchangeRate, ExchangeRateStore

@pytest.fixture
def store():
    s = ExchangeRateStore()
    s.set_rate(ExchangeRate(USD, EUR, Decimal("0.85"), date(2025,1,1)))
    s.set_rate(ExchangeRate(EUR, GBP, Decimal("0.86"), date(2025,1,1)))
    return s

class TestConversion:
    def test_direct(self, store):
        result = store.convert(Money(100, USD), EUR, date(2025,1,1))
        assert result is not None
        assert result.currency == EUR
        assert result.amount == Decimal("85.00")
    def test_inverse(self, store):
        result = store.convert(Money(85, EUR), USD, date(2025,1,1))
        assert result is not None
        assert result.currency == USD
    def test_triangulation(self, store):
        result = store.convert(Money(100, USD), GBP, date(2025,1,1))
        assert result is not None
        assert result.currency == GBP
    def test_same_currency(self, store):
        result = store.convert(Money(100, USD), USD, date(2025,1,1))
        assert result == Money(100, USD)
    def test_no_path(self, store):
        jpy = Currency("JPY", "Y", 0)
        result = store.convert(Money(100, USD), jpy, date(2025,1,1))
        assert result is None
