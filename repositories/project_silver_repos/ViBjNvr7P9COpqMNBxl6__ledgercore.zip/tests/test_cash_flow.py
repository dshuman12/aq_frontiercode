import pytest
from datetime import date
from ledgercore.core.money import Money, USD
from ledgercore.core.account import Account, AccountType
from ledgercore.core.entry import JournalEntry
from ledgercore.chart.chart_of_accounts import ChartOfAccounts
from ledgercore.ledger.general_ledger import GeneralLedger
from ledgercore.reports.cash_flow import CashFlowGenerator

class TestCashFlow:
    def test_basic_generation(self):
        chart = ChartOfAccounts("Test", USD)
        chart.add_account(Account("1100", "Cash", AccountType.ASSET, USD))
        chart.add_account(Account("1200", "AR", AccountType.ASSET, USD))
        chart.add_account(Account("2100", "AP", AccountType.LIABILITY, USD))
        chart.add_account(Account("3100", "Equity", AccountType.EQUITY, USD))
        chart.add_account(Account("4100", "Revenue", AccountType.REVENUE, USD))
        chart.add_account(Account("5100", "Expense", AccountType.EXPENSE, USD))
        ledger = GeneralLedger(chart)
        e1 = JournalEntry("E001", date(2025,1,5))
        e1.add_debit("1100", Money(10000, USD))
        e1.add_credit("3100", Money(10000, USD))
        ledger.post_entry(e1)
        e2 = JournalEntry("E002", date(2025,1,15))
        e2.add_debit("1100", Money(5000, USD))
        e2.add_credit("4100", Money(5000, USD))
        ledger.post_entry(e2)
        gen = CashFlowGenerator(ledger, USD, cash_accounts={"1100"})
        stmt = gen.generate(date(2025,1,1), date(2025,1,31), Money(5000, USD))
        assert stmt.net_income == Money(5000, USD)
        assert stmt.ending_cash is not None
