"""Edge case tests for accounting invariants."""
import pytest
from datetime import date
from decimal import Decimal
from ledgercore.core.money import Money, USD, EUR
from ledgercore.core.account import Account, AccountType, NormalBalance
from ledgercore.core.entry import JournalEntry, EntryStatus
from ledgercore.chart.chart_of_accounts import ChartOfAccounts
from ledgercore.ledger.general_ledger import GeneralLedger

class TestNormalBalanceConventions:
    """Verify that the normal balance convention is correctly applied.
    
    The key invariant that most agents get wrong:
    - Assets INCREASE with debits (debit-normal)
    - Liabilities INCREASE with credits (credit-normal)
    - Revenue INCREASES with credits (credit-normal)
    - Expenses INCREASE with debits (debit-normal)
    """
    
    @pytest.fixture
    def ledger(self):
        chart = ChartOfAccounts("Test", USD)
        chart.add_account(Account("1100", "Cash", AccountType.ASSET, USD))
        chart.add_account(Account("2100", "Loan", AccountType.LIABILITY, USD))
        chart.add_account(Account("3100", "Equity", AccountType.EQUITY, USD))
        chart.add_account(Account("4100", "Revenue", AccountType.REVENUE, USD))
        chart.add_account(Account("5100", "Rent", AccountType.EXPENSE, USD))
        return GeneralLedger(chart)

    def test_asset_increases_with_debit(self, ledger):
        e = JournalEntry("E001", date(2025,1,1))
        e.add_debit("1100", Money(1000, USD))
        e.add_credit("3100", Money(1000, USD))
        ledger.post_entry(e)
        assert ledger.get_account_balance("1100") == Money(1000, USD)

    def test_asset_decreases_with_credit(self, ledger):
        e1 = JournalEntry("E001", date(2025,1,1))
        e1.add_debit("1100", Money(1000, USD))
        e1.add_credit("3100", Money(1000, USD))
        ledger.post_entry(e1)
        e2 = JournalEntry("E002", date(2025,1,2))
        e2.add_debit("5100", Money(200, USD))
        e2.add_credit("1100", Money(200, USD))
        ledger.post_entry(e2)
        assert ledger.get_account_balance("1100") == Money(800, USD)

    def test_liability_increases_with_credit(self, ledger):
        e = JournalEntry("E001", date(2025,1,1))
        e.add_debit("1100", Money(5000, USD))
        e.add_credit("2100", Money(5000, USD))
        ledger.post_entry(e)
        assert ledger.get_account_balance("2100") == Money(5000, USD)

    def test_revenue_increases_with_credit(self, ledger):
        e = JournalEntry("E001", date(2025,1,1))
        e.add_debit("1100", Money(3000, USD))
        e.add_credit("4100", Money(3000, USD))
        ledger.post_entry(e)
        assert ledger.get_account_balance("4100") == Money(3000, USD)

    def test_expense_increases_with_debit(self, ledger):
        e1 = JournalEntry("E001", date(2025,1,1))
        e1.add_debit("1100", Money(5000, USD))
        e1.add_credit("3100", Money(5000, USD))
        ledger.post_entry(e1)
        e2 = JournalEntry("E002", date(2025,1,2))
        e2.add_debit("5100", Money(800, USD))
        e2.add_credit("1100", Money(800, USD))
        ledger.post_entry(e2)
        assert ledger.get_account_balance("5100") == Money(800, USD)


class TestTrialBalanceInvariant:
    """Trial balance must ALWAYS be balanced after any valid posting."""
    
    def test_single_entry(self):
        chart = ChartOfAccounts("T", USD)
        chart.add_account(Account("1100", "Cash", AccountType.ASSET, USD))
        chart.add_account(Account("3100", "Equity", AccountType.EQUITY, USD))
        ledger = GeneralLedger(chart)
        e = JournalEntry("E001", date(2025,1,1))
        e.add_debit("1100", Money(10000, USD))
        e.add_credit("3100", Money(10000, USD))
        ledger.post_entry(e)
        ok, _, _ = ledger.verify_trial_balance()
        assert ok

    def test_multiple_entries(self):
        chart = ChartOfAccounts("T", USD)
        chart.add_account(Account("1100", "Cash", AccountType.ASSET, USD))
        chart.add_account(Account("1200", "AR", AccountType.ASSET, USD))
        chart.add_account(Account("2100", "AP", AccountType.LIABILITY, USD))
        chart.add_account(Account("3100", "Eq", AccountType.EQUITY, USD))
        chart.add_account(Account("4100", "Rev", AccountType.REVENUE, USD))
        chart.add_account(Account("5100", "Exp", AccountType.EXPENSE, USD))
        ledger = GeneralLedger(chart)
        entries = [
            ("E001", "1100", "3100", 50000),
            ("E002", "1200", "4100", 8000),
            ("E003", "1100", "1200", 8000),
            ("E004", "5100", "1100", 3000),
            ("E005", "1100", "2100", 15000),
        ]
        for eid, dr, cr, amt in entries:
            e = JournalEntry(eid, date(2025, 1, 15))
            e.add_debit(dr, Money(amt, USD))
            e.add_credit(cr, Money(amt, USD))
            errors = ledger.post_entry(e)
            assert errors == [], f"Entry {eid} failed: {errors}"
        ok, td, tc = ledger.verify_trial_balance()
        assert ok, f"Trial balance failed: debits={td}, credits={tc}"


class TestReversalCorrectness:
    """Reversing entries must perfectly cancel the original."""
    
    def test_reversal_cancels(self):
        chart = ChartOfAccounts("T", USD)
        chart.add_account(Account("1100", "Cash", AccountType.ASSET, USD))
        chart.add_account(Account("4100", "Revenue", AccountType.REVENUE, USD))
        ledger = GeneralLedger(chart)
        e = JournalEntry("E001", date(2025, 1, 15))
        e.add_debit("1100", Money(500, USD))
        e.add_credit("4100", Money(500, USD))
        ledger.post_entry(e)
        e.status = EntryStatus.POSTED  # ensure it's posted
        reversal = e.create_reversal("R001", date(2025, 1, 16))
        ledger.post_entry(reversal)
        assert ledger.get_account_balance("1100") == Money(0, USD)
        assert ledger.get_account_balance("4100") == Money(0, USD)


class TestAccountingEquation:
    """Assets = Liabilities + Equity must hold after every operation."""
    
    def test_equation_holds(self):
        chart = ChartOfAccounts("T", USD)
        chart.add_account(Account("1100", "Cash", AccountType.ASSET, USD))
        chart.add_account(Account("1200", "AR", AccountType.ASSET, USD))
        chart.add_account(Account("2100", "AP", AccountType.LIABILITY, USD))
        chart.add_account(Account("3100", "Equity", AccountType.EQUITY, USD))
        chart.add_account(Account("4100", "Revenue", AccountType.REVENUE, USD))
        chart.add_account(Account("5100", "Expense", AccountType.EXPENSE, USD))
        ledger = GeneralLedger(chart)
        
        # Series of transactions
        txns = [
            ("E01", [("1100", 100000, True)], [("3100", 100000, False)]),
            ("E02", [("1200", 20000, True)], [("4100", 20000, False)]),
            ("E03", [("5100", 8000, True)], [("1100", 8000, False)]),
            ("E04", [("1100", 20000, True)], [("1200", 20000, False)]),
            ("E05", [("1100", 15000, True)], [("2100", 15000, False)]),
        ]
        for eid, debits, credits in txns:
            e = JournalEntry(eid, date(2025, 1, 15))
            for acct, amt, is_dr in debits:
                e.add_debit(acct, Money(amt, USD))
            for acct, amt, is_dr in credits:
                e.add_credit(acct, Money(amt, USD))
            ledger.post_entry(e)
        
        # Check: Assets = Liabilities + Equity + (Revenue - Expenses)
        assets = Decimal("0")
        liabilities = Decimal("0")
        equity = Decimal("0")
        revenue = Decimal("0")
        expenses = Decimal("0")
        
        for acct in chart.all_accounts():
            bal = ledger.get_account_balance(acct.number)
            if acct.account_type == AccountType.ASSET:
                assets += bal.amount
            elif acct.account_type == AccountType.LIABILITY:
                liabilities += bal.amount
            elif acct.account_type == AccountType.EQUITY:
                equity += bal.amount
            elif acct.account_type == AccountType.REVENUE:
                revenue += bal.amount
            elif acct.account_type == AccountType.EXPENSE:
                expenses += bal.amount
        
        # Assets = Liabilities + Equity + Net Income
        net_income = revenue - expenses
        rhs = liabilities + equity + net_income
        assert assets == rhs, f"Equation failed: {assets} != {rhs}"
