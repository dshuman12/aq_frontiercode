import pytest
from datetime import date
from decimal import Decimal
from ledgercore.core.money import Money, USD
from ledgercore.core.lease import Lease, LeaseType

class TestLeaseAccounting:
    def test_initial_measurement(self):
        lease = Lease(
            lease_id="LS001", description="Office Lease",
            lease_type=LeaseType.OPERATING,
            commencement_date=date(2025,1,1), term_months=36,
            monthly_payment=Money(5000, USD),
            discount_rate=Decimal("0.06"),
        )
        lease.calculate_initial_measurement()
        assert lease.lease_liability is not None
        assert lease.rou_asset is not None
        assert lease.lease_liability.is_positive
        assert len(lease.payments) == 36

    def test_pv_less_than_nominal(self):
        lease = Lease(
            lease_id="LS001", description="Test",
            commencement_date=date(2025,1,1), term_months=12,
            monthly_payment=Money(1000, USD),
            discount_rate=Decimal("0.10"),
        )
        lease.calculate_initial_measurement()
        # PV should be less than 12 * 1000 = 12000
        assert lease.lease_liability < Money(12000, USD)

    def test_zero_rate(self):
        lease = Lease(
            lease_id="LS001", description="Test",
            commencement_date=date(2025,1,1), term_months=12,
            monthly_payment=Money(1000, USD),
            discount_rate=Decimal("0"),
        )
        lease.calculate_initial_measurement()
        assert lease.lease_liability == Money(12000, USD)

    def test_inception_entry_balanced(self):
        lease = Lease(
            lease_id="LS001", description="Office",
            commencement_date=date(2025,1,1), term_months=24,
            monthly_payment=Money(3000, USD),
            discount_rate=Decimal("0.05"),
        )
        lease.calculate_initial_measurement()
        entry = lease.generate_inception_entry("LS-E001")
        assert entry.is_balanced

    def test_finance_payment_entry(self):
        lease = Lease(
            lease_id="LS001", description="Equipment",
            lease_type=LeaseType.FINANCE,
            commencement_date=date(2025,1,1), term_months=24,
            monthly_payment=Money(2000, USD),
            discount_rate=Decimal("0.06"),
        )
        lease.calculate_initial_measurement()
        entry = lease.generate_payment_entry(1, "PMT-001")
        assert entry is not None
        assert entry.is_balanced

    def test_operating_payment_entry(self):
        lease = Lease(
            lease_id="LS001", description="Office",
            lease_type=LeaseType.OPERATING,
            commencement_date=date(2025,1,1), term_months=12,
            monthly_payment=Money(5000, USD),
            discount_rate=Decimal("0.05"),
        )
        lease.calculate_initial_measurement()
        entry = lease.generate_payment_entry(1, "PMT-001")
        assert entry is not None
        assert entry.is_balanced

    def test_initial_direct_costs(self):
        lease = Lease(
            lease_id="LS001", description="Test",
            commencement_date=date(2025,1,1), term_months=12,
            monthly_payment=Money(1000, USD),
            discount_rate=Decimal("0.05"),
            initial_direct_costs=Money(500, USD),
        )
        lease.calculate_initial_measurement()
        # ROU should be liability + IDC
        assert lease.rou_asset > lease.lease_liability
        diff = lease.rou_asset - lease.lease_liability
        assert diff == Money(500, USD)
