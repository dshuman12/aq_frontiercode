import pytest
from datetime import date
from decimal import Decimal
from ledgercore.core.money import Money, USD
from ledgercore.core.account import Account, AccountType
from ledgercore.core.entry import JournalEntry
from ledgercore.chart.chart_of_accounts import ChartOfAccounts
from ledgercore.ledger.multi_book import MultiBookLedger, BookConfig, BookType

@pytest.fixture
def setup():
    chart = ChartOfAccounts("Corp", USD)
    chart.add_account(Account("1100", "Cash", AccountType.ASSET, USD))
    chart.add_account(Account("1500", "Equipment", AccountType.ASSET, USD))
    chart.add_account(Account("1510", "Accum Dep", AccountType.CONTRA_ASSET, USD))
    chart.add_account(Account("3100", "Equity", AccountType.EQUITY, USD))
    chart.add_account(Account("4100", "Revenue", AccountType.REVENUE, USD))
    chart.add_account(Account("5100", "Expense", AccountType.EXPENSE, USD))
    chart.add_account(Account("5300", "Dep Expense", AccountType.EXPENSE, USD))
    mbl = MultiBookLedger(chart)
    mbl.add_book(BookConfig("gaap", "GAAP Book", BookType.GAAP, is_primary=True))
    mbl.add_book(BookConfig("tax", "Tax Book", BookType.TAX))
    return mbl

class TestMultiBook:
    def test_common_entry(self, setup):
        e = JournalEntry("E001", date(2025,1,1))
        e.add_debit("1100", Money(10000, USD))
        e.add_credit("3100", Money(10000, USD))
        errors = setup.post_to_all_books(e)
        assert not errors  # no errors in any book
        gaap_bal = setup.get_balance("gaap", "1100")
        tax_bal = setup.get_balance("tax", "1100")
        assert gaap_bal == Money(10000, USD)
        assert tax_bal == Money(10000, USD)

    def test_book_specific_entry(self, setup):
        # Common entry first
        e1 = JournalEntry("E001", date(2025,1,1))
        e1.add_debit("1100", Money(10000, USD))
        e1.add_credit("3100", Money(10000, USD))
        setup.post_to_all_books(e1)
        # GAAP depreciation: $2000
        gaap_dep = JournalEntry("GAAP-DEP", date(2025,12,31))
        gaap_dep.add_debit("5300", Money(2000, USD))
        gaap_dep.add_credit("1510", Money(2000, USD))
        setup.post_to_book("gaap", gaap_dep)
        # Tax depreciation: $3000 (different method)
        tax_dep = JournalEntry("TAX-DEP", date(2025,12,31))
        tax_dep.add_debit("5300", Money(3000, USD))
        tax_dep.add_credit("1510", Money(3000, USD))
        setup.post_to_book("tax", tax_dep)
        # Balances should differ
        gaap_dep_bal = setup.get_balance("gaap", "5300")
        tax_dep_bal = setup.get_balance("tax", "5300")
        assert gaap_dep_bal != tax_dep_bal
        assert gaap_dep_bal == Money(2000, USD)
        assert tax_dep_bal == Money(3000, USD)

    def test_compare_balances(self, setup):
        e = JournalEntry("E001", date(2025,1,1))
        e.add_debit("1100", Money(5000, USD))
        e.add_credit("3100", Money(5000, USD))
        setup.post_to_all_books(e)
        comparison = setup.compare_balances("1100")
        assert "gaap" in comparison
        assert "tax" in comparison
        assert comparison["gaap"] == comparison["tax"]

    def test_book_differences(self, setup):
        e = JournalEntry("E001", date(2025,1,1))
        e.add_debit("1100", Money(10000, USD))
        e.add_credit("3100", Money(10000, USD))
        setup.post_to_all_books(e)
        # Different depreciation
        g = JournalEntry("G1", date(2025,12,31))
        g.add_debit("5300", Money(1000, USD))
        g.add_credit("1510", Money(1000, USD))
        setup.post_to_book("gaap", g)
        t = JournalEntry("T1", date(2025,12,31))
        t.add_debit("5300", Money(2000, USD))
        t.add_credit("1510", Money(2000, USD))
        setup.post_to_book("tax", t)
        diffs = setup.book_differences("gaap", "tax")
        assert len(diffs) > 0
        # Dep expense should differ
        dep_diff = next((d for d in diffs if d[0] == "5300"), None)
        assert dep_diff is not None
