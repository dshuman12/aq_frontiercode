import pytest
from datetime import date
from decimal import Decimal
from ledgercore.core.money import Money, USD, Currency
from ledgercore.core.account import Account, AccountType
from ledgercore.core.entry import JournalEntry
from ledgercore.chart.chart_of_accounts import ChartOfAccounts
from ledgercore.ledger.general_ledger import GeneralLedger

@pytest.fixture
def ledger():
    chart = ChartOfAccounts("Test", USD)
    chart.add_account(Account("1100", "Cash", AccountType.ASSET, USD))
    chart.add_account(Account("1200", "AR", AccountType.ASSET, USD))
    chart.add_account(Account("2100", "AP", AccountType.LIABILITY, USD))
    chart.add_account(Account("3100", "Equity", AccountType.EQUITY, USD))
    chart.add_account(Account("3200", "Retained Earnings", AccountType.EQUITY, USD, is_system=True))
    chart.add_account(Account("4100", "Sales Revenue", AccountType.REVENUE, USD))
    chart.add_account(Account("5100", "Rent Expense", AccountType.EXPENSE, USD))
    chart.add_account(Account("5200", "Salary Expense", AccountType.EXPENSE, USD))
    return GeneralLedger(chart)

class TestPosting:
    def test_post_balanced_entry(self, ledger):
        e = JournalEntry("E001", date(2025, 1, 15))
        e.add_debit("1100", Money(1000, USD))
        e.add_credit("4100", Money(1000, USD))
        errors = ledger.post_entry(e)
        assert errors == []

    def test_post_unbalanced_rejected(self, ledger):
        e = JournalEntry("E002", date(2025, 1, 15))
        e.add_debit("1100", Money(1000, USD))
        e.add_credit("4100", Money(900, USD))
        errors = ledger.post_entry(e)
        assert len(errors) > 0

    def test_duplicate_rejected(self, ledger):
        e = JournalEntry("E001", date(2025, 1, 15))
        e.add_debit("1100", Money(100, USD))
        e.add_credit("4100", Money(100, USD))
        ledger.post_entry(e)
        errors = ledger.post_entry(e)
        assert len(errors) > 0

class TestBalances:
    def test_asset_balance(self, ledger):
        e = JournalEntry("E001", date(2025, 1, 15))
        e.add_debit("1100", Money(1000, USD))
        e.add_credit("4100", Money(1000, USD))
        ledger.post_entry(e)
        bal = ledger.get_account_balance("1100")
        assert bal == Money(1000, USD)

    def test_revenue_balance(self, ledger):
        e = JournalEntry("E001", date(2025, 1, 15))
        e.add_debit("1100", Money(500, USD))
        e.add_credit("4100", Money(500, USD))
        ledger.post_entry(e)
        bal = ledger.get_account_balance("4100")
        assert bal == Money(500, USD)

    def test_expense_increases_with_debit(self, ledger):
        e = JournalEntry("E001", date(2025, 1, 15))
        e.add_debit("5100", Money(200, USD))
        e.add_credit("1100", Money(200, USD))
        ledger.post_entry(e)
        bal = ledger.get_account_balance("5100")
        assert bal == Money(200, USD)

class TestTrialBalance:
    def test_balanced(self, ledger):
        e1 = JournalEntry("E001", date(2025, 1, 10))
        e1.add_debit("1100", Money(5000, USD))
        e1.add_credit("3100", Money(5000, USD))
        ledger.post_entry(e1)
        e2 = JournalEntry("E002", date(2025, 1, 15))
        e2.add_debit("5100", Money(800, USD))
        e2.add_credit("1100", Money(800, USD))
        ledger.post_entry(e2)
        is_balanced, total_d, total_c = ledger.verify_trial_balance()
        assert is_balanced
        assert total_d == total_c
