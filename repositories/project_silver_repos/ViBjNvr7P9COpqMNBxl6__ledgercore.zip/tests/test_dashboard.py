import pytest
from datetime import date
from decimal import Decimal
from ledgercore.core.money import Money, USD
from ledgercore.core.account import Account, AccountType
from ledgercore.core.entry import JournalEntry
from ledgercore.chart.chart_of_accounts import ChartOfAccounts
from ledgercore.ledger.general_ledger import GeneralLedger
from ledgercore.reports.dashboard import DashboardGenerator, KPIResult

@pytest.fixture
def setup():
    chart = ChartOfAccounts("Corp", USD)
    for n, nm, t in [
        ("1100","Cash",AccountType.ASSET),("1200","AR",AccountType.ASSET),
        ("1400","Inventory",AccountType.ASSET),("2100","AP",AccountType.LIABILITY),
        ("2500","Debt",AccountType.LIABILITY),("3100","Equity",AccountType.EQUITY),
        ("4100","Revenue",AccountType.REVENUE),("5100","COGS",AccountType.EXPENSE),
        ("5300","Depreciation",AccountType.EXPENSE),("5600","Interest",AccountType.EXPENSE),
    ]:
        chart.add_account(Account(n, nm, t, USD))
    ledger = GeneralLedger(chart)
    e = JournalEntry("E001", date(2025,1,1))
    e.add_debit("1100", Money(50000, USD))
    e.add_credit("3100", Money(50000, USD))
    ledger.post_entry(e)
    e2 = JournalEntry("E002", date(2025,1,15))
    e2.add_debit("1200", Money(20000, USD))
    e2.add_credit("4100", Money(20000, USD))
    ledger.post_entry(e2)
    e3 = JournalEntry("E003", date(2025,1,20))
    e3.add_debit("5100", Money(8000, USD))
    e3.add_credit("1400", Money(8000, USD))
    ledger.post_entry(e3)
    return ledger

class TestDashboard:
    def test_compute_kpis(self, setup):
        gen = DashboardGenerator(setup, USD)
        mapping = {
            "current_assets": ["1100", "1200", "1400"],
            "current_liabilities": ["2100"],
            "revenue": ["4100"],
            "cogs": ["5100"],
            "receivables": ["1200"],
            "payables": ["2100"],
            "inventory": ["1400"],
            "equity": ["3100"],
            "total_debt": ["2500"],
            "depreciation": ["5300"],
            "interest_expense": ["5600"],
        }
        kpis = gen.compute_all_kpis(date(2025,1,1), date(2025,1,31), 30, mapping)
        assert len(kpis) > 0
        names = [k.name for k in kpis]
        assert "Working Capital" in names

    def test_alerts(self, setup):
        gen = DashboardGenerator(setup, USD)
        kpis = [KPIResult("Test", Decimal("0.5"), "x", benchmark_min=Decimal("1.0"))]
        alerts = gen.alerts(kpis)
        assert len(alerts) == 1

    def test_kpi_formatting(self):
        k = KPIResult("Test", Decimal("45.6"), "%")
        assert "45.6%" in k.formatted
        k2 = KPIResult("Days", Decimal("30"), "days")
        assert "30 days" in k2.formatted
