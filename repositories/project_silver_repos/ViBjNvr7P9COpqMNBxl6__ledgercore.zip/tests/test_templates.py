import pytest
from datetime import date
from decimal import Decimal
from ledgercore.core.money import Money, USD
from ledgercore.core.entry import EntryType
from ledgercore.ledger.templates import (
    JournalTemplate, TemplateLine, TemplateManager, ScheduleFrequency,
)

class TestJournalTemplate:
    def test_fixed_amount(self):
        t = JournalTemplate(
            template_id="T1", name="Monthly Rent",
            lines=[
                TemplateLine("5100", True, Money(2000, USD)),
                TemplateLine("1100", False, Money(2000, USD)),
            ],
        )
        entry = t.generate_entry("E001", date(2025, 1, 31))
        assert entry.is_balanced
        assert len(entry.lines) == 2

    def test_variable_amount(self):
        t = JournalTemplate(
            template_id="T2", name="Sales Receipt",
            lines=[
                TemplateLine("1100", True),  # variable debit
                TemplateLine("4100", False),  # variable credit
            ],
        )
        entry = t.generate_entry("E002", date(2025, 1, 15), Money(500, USD))
        assert entry.is_balanced

    def test_proportional(self):
        t = JournalTemplate(
            template_id="T3", name="Tax Split",
            lines=[
                TemplateLine("5100", True),  # full amount
                TemplateLine("2300", False, proportion=Decimal("0.30")),  # 30%
                TemplateLine("1100", False, proportion=Decimal("0.70")),  # 70%
            ],
        )
        entry = t.generate_entry("E003", date(2025, 1, 15), Money(1000, USD))
        assert entry.is_balanced

    def test_counter_increments(self):
        t = JournalTemplate(
            template_id="T4", name="Test", description="Entry #{{COUNTER}}",
            lines=[
                TemplateLine("1100", True, Money(100, USD)),
                TemplateLine("4100", False, Money(100, USD)),
            ],
        )
        e1 = t.generate_entry("E1", date(2025, 1, 1))
        e2 = t.generate_entry("E2", date(2025, 2, 1))
        assert "1" in e1.description
        assert "2" in e2.description


class TestScheduling:
    def test_monthly(self):
        t = JournalTemplate(
            template_id="T1", name="Monthly",
            schedule_frequency=ScheduleFrequency.MONTHLY,
            schedule_start=date(2025, 1, 1),
            lines=[
                TemplateLine("5100", True, Money(100, USD)),
                TemplateLine("1100", False, Money(100, USD)),
            ],
        )
        next_d = t.get_next_schedule_date()
        assert next_d == date(2025, 2, 1)

    def test_quarterly(self):
        t = JournalTemplate(
            template_id="T2", name="Quarterly",
            schedule_frequency=ScheduleFrequency.QUARTERLY,
            schedule_start=date(2025, 1, 15),
            lines=[TemplateLine("5100", True, Money(100, USD)),
                   TemplateLine("1100", False, Money(100, USD))],
        )
        next_d = t.get_next_schedule_date()
        assert next_d is not None
        assert next_d.month == 4

    def test_past_end_date(self):
        t = JournalTemplate(
            template_id="T3", name="Ended",
            schedule_frequency=ScheduleFrequency.MONTHLY,
            schedule_start=date(2025, 1, 1),
            schedule_end=date(2025, 3, 1),
            last_generated=date(2025, 3, 1),
            lines=[TemplateLine("5100", True, Money(100, USD)),
                   TemplateLine("1100", False, Money(100, USD))],
        )
        assert t.get_next_schedule_date() is None


class TestTemplateManager:
    def test_due_templates(self):
        mgr = TemplateManager()
        t = JournalTemplate(
            template_id="T1", name="Rent",
            schedule_frequency=ScheduleFrequency.MONTHLY,
            schedule_start=date(2025, 1, 1),
            lines=[TemplateLine("5100", True, Money(2000, USD)),
                   TemplateLine("1100", False, Money(2000, USD))],
        )
        mgr.add_template(t)
        due = mgr.get_due_templates(date(2025, 3, 1))
        assert len(due) == 1

    def test_generate_all(self):
        mgr = TemplateManager()
        mgr.add_template(JournalTemplate(
            template_id="T1", name="R",
            schedule_frequency=ScheduleFrequency.MONTHLY,
            schedule_start=date(2025, 1, 1),
            lines=[TemplateLine("5100", True, Money(100, USD)),
                   TemplateLine("1100", False, Money(100, USD))],
        ))
        counter = [0]
        def gen(): counter[0] += 1; return f"AUTO{counter[0]:03d}"
        entries = mgr.generate_all_due(date(2025, 3, 1), gen)
        assert len(entries) >= 1
        for e in entries:
            assert e.is_balanced
