"""Integration tests: full accounting workflow."""
import pytest
from datetime import date
from decimal import Decimal
from ledgercore.core.money import Money, USD
from ledgercore.core.account import Account, AccountType
from ledgercore.core.entry import JournalEntry
from ledgercore.chart.chart_of_accounts import ChartOfAccounts
from ledgercore.ledger.general_ledger import GeneralLedger
from ledgercore.period.fiscal_period import FiscalPeriod, FiscalCalendar
from ledgercore.reports.financial_statements import ReportGenerator

class TestFullWorkflow:
    def test_month_end_close(self):
        chart = ChartOfAccounts("Corp", USD)
        chart.add_account(Account("1100", "Cash", AccountType.ASSET, USD))
        chart.add_account(Account("1200", "AR", AccountType.ASSET, USD))
        chart.add_account(Account("2100", "AP", AccountType.LIABILITY, USD))
        chart.add_account(Account("3100", "Common Stock", AccountType.EQUITY, USD))
        chart.add_account(Account("3200", "Retained Earnings", AccountType.EQUITY, USD, is_system=True))
        chart.add_account(Account("3900", "Income Summary", AccountType.EQUITY, USD))
        chart.add_account(Account("4100", "Service Revenue", AccountType.REVENUE, USD))
        chart.add_account(Account("5100", "Rent", AccountType.EXPENSE, USD))
        chart.add_account(Account("5200", "Salaries", AccountType.EXPENSE, USD))
        ledger = GeneralLedger(chart)
        cal = FiscalCalendar(USD)
        cal.set_retained_earnings_account("3200")
        cal.set_income_summary_account("3900")
        cal.add_period(FiscalPeriod("2025-01", date(2025,1,1), date(2025,1,31)))
        # Owner investment
        e1 = JournalEntry("E001", date(2025,1,1))
        e1.add_debit("1100", Money(50000, USD))
        e1.add_credit("3100", Money(50000, USD))
        ledger.post_entry(e1)
        # Earn revenue
        e2 = JournalEntry("E002", date(2025,1,15))
        e2.add_debit("1200", Money(8000, USD))
        e2.add_credit("4100", Money(8000, USD))
        ledger.post_entry(e2)
        # Collect payment
        e3 = JournalEntry("E003", date(2025,1,20))
        e3.add_debit("1100", Money(8000, USD))
        e3.add_credit("1200", Money(8000, USD))
        ledger.post_entry(e3)
        # Pay expenses
        e4 = JournalEntry("E004", date(2025,1,25))
        e4.add_debit("5100", Money(2000, USD))
        e4.add_debit("5200", Money(3000, USD))
        e4.add_credit("1100", Money(5000, USD))
        ledger.post_entry(e4)
        # Verify trial balance
        bal_ok, td, tc = ledger.verify_trial_balance()
        assert bal_ok
        # Income statement
        gen = ReportGenerator(ledger, USD)
        pnl = gen.income_statement(date(2025,1,1), date(2025,1,31))
        assert pnl.net_income == Money(3000, USD)
        # Balance sheet (before closing, revenue/expense aren't in equity yet
        # so we just verify it generates without error)
        bs = gen.balance_sheet(date(2025,1,31))
        assert bs.total_assets is not None
        # Close period
        counter = [0]
        def gen_id():
            counter[0] += 1
            return f"CL-{counter[0]:03d}"
        errors, _ = cal.close_period("2025-01", ledger, gen_id)
        assert errors == []
        # After closing, revenue/expense should be zero
        rev_bal = ledger.get_account_balance("4100")
        assert rev_bal.is_zero
        # Retained earnings should equal net income
        re_bal = ledger.get_account_balance("3200")
        assert re_bal == Money(3000, USD)
        # Trial balance still balanced after closing
        bal_ok2, _, _ = ledger.verify_trial_balance()
        assert bal_ok2
