import pytest
from decimal import Decimal
from ledgercore.core.money import Money, Currency, CurrencyMismatchError, USD, EUR, JPY

class TestMoneyArithmetic:
    def test_add(self):
        assert Money(10, USD) + Money(20, USD) == Money(30, USD)
    def test_sub(self):
        assert Money(30, USD) - Money(10, USD) == Money(20, USD)
    def test_mul_scalar(self):
        assert Money(10, USD) * 3 == Money(30, USD)
    def test_div_scalar(self):
        assert Money(30, USD) / 3 == Money(10, USD)
    def test_div_money(self):
        ratio = Money(30, USD) / Money(10, USD)
        assert ratio == Decimal("3")
    def test_negate(self):
        assert -Money(10, USD) == Money(-10, USD)
    def test_abs(self):
        assert abs(Money(-10, USD)) == Money(10, USD)

class TestCurrencyMismatch:
    def test_add_mismatch(self):
        with pytest.raises(CurrencyMismatchError):
            Money(10, USD) + Money(10, EUR)
    def test_compare_mismatch(self):
        with pytest.raises(CurrencyMismatchError):
            Money(10, USD) < Money(10, EUR)

class TestPrecision:
    def test_decimal_precision(self):
        result = Money("0.1", USD) + Money("0.2", USD)
        assert result == Money("0.30", USD)
    def test_jpy_no_decimals(self):
        m = Money("100.6", JPY)
        assert m.amount == Decimal("101")  # rounded
    def test_bankers_rounding(self):
        m = Money("2.125", USD)
        assert m.amount == Decimal("2.12")  # round half to even
        m2 = Money("2.135", USD)
        assert m2.amount == Decimal("2.14")

class TestMoneyProperties:
    def test_zero(self):
        assert Money.zero(USD).is_zero
    def test_positive(self):
        assert Money(10, USD).is_positive
    def test_negative(self):
        assert Money(-5, USD).is_negative
    def test_str(self):
        s = str(Money(1234.5, USD))
        assert "1,234.50" in s
