import pytest
from datetime import date
from decimal import Decimal
from ledgercore.core.money import Money, USD
from ledgercore.recon.reconciliation import BankTransaction, ReconciliationEngine

class TestReconciliation:
    def test_exact_match(self):
        engine = ReconciliationEngine()
        bank = [BankTransaction("B1", date(2025,1,10), Money(100, USD), reference="CHK001")]
        ledger_items = [("E1", date(2025,1,10), Money(100, USD), "CHK001")]
        matches, ub, ul = engine.match_transactions(bank, ledger_items)
        assert len(matches) == 1
        assert matches[0] == ("B1", "E1")
    def test_no_match(self):
        engine = ReconciliationEngine()
        bank = [BankTransaction("B1", date(2025,1,10), Money(100, USD))]
        ledger = [("E1", date(2025,1,10), Money(200, USD), "")]
        matches, ub, ul = engine.match_transactions(bank, ledger)
        assert len(matches) == 0
        assert "B1" in ub
    def test_tolerance(self):
        engine = ReconciliationEngine(tolerance=Decimal("0.05"))
        bank = [BankTransaction("B1", date(2025,1,10), Money("100.02", USD))]
        ledger = [("E1", date(2025,1,10), Money(100, USD), "")]
        matches, _, _ = engine.match_transactions(bank, ledger)
        assert len(matches) == 1
