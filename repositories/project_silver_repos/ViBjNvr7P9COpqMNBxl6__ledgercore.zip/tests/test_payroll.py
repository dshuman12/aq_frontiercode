import pytest
from decimal import Decimal
from datetime import date
from ledgercore.core.money import Money, USD, Currency
from ledgercore.payroll.processor import PayrollProcessor, Employee, PayrollResult

class TestPayrollProcessing:
    def test_basic_payroll(self):
        proc = PayrollProcessor(USD)
        emp = Employee(
            employee_id="EMP001", name="John Smith",
            gross_salary=Money(5000, USD),
        )
        result = proc.process_employee(emp, pay_periods_per_year=12)
        assert result.gross_pay == Money(5000, USD)
        assert result.net_pay < result.gross_pay  # deductions reduce net
        assert result.net_pay.is_positive  # but net should still be positive

    def test_social_security_cap(self):
        proc = PayrollProcessor(USD)
        emp = Employee(
            employee_id="EMP001", name="Jane Doe",
            gross_salary=Money(20000, USD),
            ytd_gross=Money(155000, USD),  # near SS wage base
        )
        result = proc.process_employee(emp, pay_periods_per_year=12)
        # SS should be capped: only $5,200 is subject to SS
        assert result.social_security_employee < Money(20000, USD) * Decimal("0.062")

    def test_employer_cost_exceeds_gross(self):
        proc = PayrollProcessor(USD)
        emp = Employee(
            employee_id="EMP001", name="Test",
            gross_salary=Money(3000, USD),
        )
        result = proc.process_employee(emp)
        assert result.total_employer_cost > result.gross_pay

    def test_journal_entry_balanced(self):
        proc = PayrollProcessor(USD)
        emp = Employee(employee_id="EMP001", name="Test", gross_salary=Money(5000, USD))
        result = proc.process_employee(emp, 12)
        accounts = {
            'salary_expense': '5100', 'payroll_tax_expense': '5200',
            'cash': '1100', 'federal_tax_payable': '2300',
            'state_tax_payable': '2310', 'ss_payable': '2320',
            'medicare_payable': '2330',
        }
        entry = proc.generate_journal_entry([result], "PR001", date(2025, 1, 31), accounts)
        assert entry.is_balanced

    def test_batch_processing(self):
        proc = PayrollProcessor(USD)
        employees = [
            Employee("E1", "Alice", Money(4000, USD)),
            Employee("E2", "Bob", Money(6000, USD)),
            Employee("E3", "Charlie", Money(5000, USD), is_active=False),
        ]
        results = proc.process_batch(employees, 12)
        assert len(results) == 2  # Charlie is inactive
