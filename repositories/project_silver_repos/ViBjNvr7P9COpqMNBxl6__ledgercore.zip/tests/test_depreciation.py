import pytest
from decimal import Decimal
from ledgercore.core.money import Money, USD
from ledgercore.core.depreciation import (
    calculate_straight_line, calculate_double_declining,
    calculate_sum_of_years, Convention, DepreciationSchedule,
)

class TestStraightLine:
    def test_basic(self):
        entries = calculate_straight_line(Money(10000, USD), Money(1000, USD), 5, Convention.FULL_MONTH)
        assert len(entries) == 5
        total = sum(e.amount.amount for e in entries)
        assert total == Decimal("9000")

    def test_half_year(self):
        entries = calculate_straight_line(Money(10000, USD), Money(0, USD), 5, Convention.HALF_YEAR)
        # First year: half, last year: half, middle: full
        assert entries[0].amount == Money(1000, USD)  # 2000/2
        assert entries[1].amount == Money(2000, USD)  # full year

    def test_book_value_never_below_salvage(self):
        entries = calculate_straight_line(Money(1000, USD), Money(200, USD), 3)
        for e in entries:
            assert e.book_value_after >= Money(200, USD)

class TestDoubleDeclining:
    def test_accelerated(self):
        entries = calculate_double_declining(Money(10000, USD), Money(1000, USD), 5)
        # First entries should be larger than later ones
        if len(entries) >= 2:
            assert entries[0].amount >= entries[-1].amount

    def test_never_below_salvage(self):
        entries = calculate_double_declining(Money(10000, USD), Money(2000, USD), 5)
        for e in entries:
            assert e.book_value_after >= Money(2000, USD) or e.book_value_after.amount >= Decimal("1999")

class TestSumOfYears:
    def test_basic(self):
        entries = calculate_sum_of_years(Money(10000, USD), Money(0, USD), 5)
        assert len(entries) == 5
        total = sum(e.amount.amount for e in entries)
        assert abs(total - Decimal("10000")) < Decimal("1")

    def test_decreasing(self):
        entries = calculate_sum_of_years(Money(10000, USD), Money(0, USD), 5)
        for i in range(len(entries) - 1):
            assert entries[i].amount >= entries[i + 1].amount
