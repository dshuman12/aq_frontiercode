import pytest
from datetime import date
from decimal import Decimal
from ledgercore.core.money import Money, USD
from ledgercore.revenue.recognition import (
    RevenueRecognitionEngine, RevenueContract, PerformanceObligation,
    RecognitionType,
)

class TestRevenueAllocation:
    def test_ssp_allocation(self):
        c = RevenueContract(
            contract_id="C001", customer_name="Acme",
            contract_date=date(2025,1,1), transaction_price=Money(900, USD),
            obligations=[
                PerformanceObligation("OB1", "Phone", Money(800, USD)),
                PerformanceObligation("OB2", "Warranty", Money(200, USD)),
            ],
        )
        c.allocate_transaction_price()
        # Phone: 900 * 800/1000 = 720
        assert c.obligations[0].allocated_price == Money(720, USD)
        # Warranty: 900 - 720 = 180 (remainder)
        assert c.obligations[1].allocated_price == Money(180, USD)
        # Total = transaction price
        total = c.obligations[0].allocated_price + c.obligations[1].allocated_price
        assert total == Money(900, USD)

    def test_single_obligation(self):
        c = RevenueContract(
            contract_id="C002", customer_name="Test",
            contract_date=date(2025,1,1), transaction_price=Money(500, USD),
            obligations=[
                PerformanceObligation("OB1", "Service", Money(500, USD)),
            ],
        )
        c.allocate_transaction_price()
        assert c.obligations[0].allocated_price == Money(500, USD)


class TestPointInTime:
    def test_recognize_on_delivery(self):
        engine = RevenueRecognitionEngine(USD)
        c = RevenueContract(
            contract_id="C001", customer_name="Acme",
            contract_date=date(2025,1,1), transaction_price=Money(1000, USD),
            obligations=[
                PerformanceObligation("OB1", "Product", Money(1000, USD)),
            ],
        )
        engine.add_contract(c)
        # Record inception
        inception = engine.record_contract_inception("C001", "E001")
        assert inception is not None
        assert inception.is_balanced
        # Satisfy obligation
        engine.satisfy_obligation("C001", "OB1")
        # After satisfaction, recognized_amount is set
        ob = c.obligations[0]
        assert ob.is_satisfied
        assert ob.recognized_amount == Money(1000, USD)

    def test_deferred_before_delivery(self):
        engine = RevenueRecognitionEngine(USD)
        c = RevenueContract(
            contract_id="C001", customer_name="Test",
            contract_date=date(2025,1,1), transaction_price=Money(500, USD),
            obligations=[
                PerformanceObligation("OB1", "Widget", Money(500, USD)),
            ],
        )
        engine.add_contract(c)
        assert engine.total_deferred_revenue() == Money(500, USD)


class TestOverTime:
    def test_output_method(self):
        engine = RevenueRecognitionEngine(USD)
        c = RevenueContract(
            contract_id="C001", customer_name="Builder",
            contract_date=date(2025,1,1), transaction_price=Money(10000, USD),
            obligations=[
                PerformanceObligation(
                    "OB1", "Construction", Money(10000, USD),
                    recognition_type=RecognitionType.OVER_TIME_OUTPUT,
                    total_units=100,
                ),
            ],
        )
        engine.add_contract(c)
        engine.update_progress("C001", "OB1", delivered_units=50)
        # 50% complete, should recognize $5000
        ob = c.obligations[0]
        assert ob.completion_pct == Decimal("0.5")
