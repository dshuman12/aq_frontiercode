import pytest
from decimal import Decimal
from ledgercore.core.money import Money, USD
from ledgercore.reports.formatter import AccountingFormatter

class TestAccountingFormatter:
    def test_positive(self):
        f = AccountingFormatter(USD)
        assert f.format_amount(Money(1234.56, USD)) == "$1,234.56"

    def test_negative(self):
        f = AccountingFormatter(USD)
        assert f.format_amount(Money(-1234.56, USD)) == "($1,234.56)"

    def test_zero(self):
        f = AccountingFormatter(USD)
        result = f.format_amount(Money.zero(USD))
        assert "-" in result

    def test_percentage(self):
        f = AccountingFormatter(USD)
        assert f.format_percentage(Decimal("0.15")) == "15.0%"

    def test_no_currency_symbol(self):
        f = AccountingFormatter(USD, show_currency=False)
        assert "$" not in f.format_amount(Money(100, USD))
