import pytest
from datetime import date, timedelta
from ledgercore.core.money import Money, USD
from ledgercore.core.entry import EntryType
from ledgercore.ledger.accruals import AccrualEngine, AccrualTemplate, AccrualType

class TestAccrualEngine:
    def test_generate_entries(self):
        engine = AccrualEngine()
        engine.add_template(AccrualTemplate(
            template_id="T1", accrual_type=AccrualType.ACCRUED_EXPENSE,
            description="Monthly rent", debit_account="5100", credit_account="2200",
            amount=Money(2000, USD),
        ))
        counter = [0]
        def gen_id():
            counter[0] += 1
            return f"ACC-{counter[0]:03d}"
        entries = engine.generate_entries(date(2025, 1, 31), gen_id)
        assert len(entries) == 1
        assert entries[0].is_balanced

    def test_auto_reverse(self):
        engine = AccrualEngine()
        engine.add_template(AccrualTemplate(
            template_id="T1", accrual_type=AccrualType.ACCRUED_EXPENSE,
            description="Test", debit_account="5100", credit_account="2200",
            amount=Money(100, USD), auto_reverse=True,
        ))
        counter = [0]
        def gen_id():
            counter[0] += 1
            return f"ACC-{counter[0]:03d}"
        engine.generate_entries(date(2025, 1, 31), gen_id)
        reversals = engine.get_pending_reversals(date(2025, 2, 1))
        assert len(reversals) == 1
        assert reversals[0].entry_type == EntryType.REVERSING

    def test_no_duplicate_generation(self):
        engine = AccrualEngine()
        engine.add_template(AccrualTemplate(
            template_id="T1", accrual_type=AccrualType.ACCRUED_EXPENSE,
            description="Test", debit_account="5100", credit_account="2200",
            amount=Money(100, USD),
        ))
        counter = [0]
        def gen_id():
            counter[0] += 1
            return f"ACC-{counter[0]:03d}"
        e1 = engine.generate_entries(date(2025, 1, 31), gen_id)
        e2 = engine.generate_entries(date(2025, 1, 31), gen_id)
        assert len(e1) == 1
        assert len(e2) == 0  # already generated
