import pytest
from datetime import date
from ledgercore.core.entry import JournalEntry, EntryLine, EntryStatus, EntryType
from ledgercore.core.money import Money, USD, EUR

class TestDoubleEntryValidation:
    def test_balanced_entry(self):
        e = JournalEntry("E001", date(2025, 1, 1))
        e.add_debit("1100", Money(100, USD))
        e.add_credit("4100", Money(100, USD))
        assert e.is_balanced
        assert e.validate() == []

    def test_unbalanced_entry(self):
        e = JournalEntry("E002", date(2025, 1, 1))
        e.add_debit("1100", Money(100, USD))
        e.add_credit("4100", Money(90, USD))
        assert not e.is_balanced
        errors = e.validate()
        assert len(errors) > 0

    def test_multi_line_balanced(self):
        e = JournalEntry("E003", date(2025, 1, 1))
        e.add_debit("5100", Money(50, USD))
        e.add_debit("5200", Money(30, USD))
        e.add_credit("1100", Money(80, USD))
        assert e.is_balanced

    def test_multi_currency_balanced(self):
        e = JournalEntry("E004", date(2025, 1, 1))
        e.add_debit("1100", Money(100, USD))
        e.add_credit("4100", Money(100, USD))
        e.add_debit("1200", Money(85, EUR))
        e.add_credit("4200", Money(85, EUR))
        assert e.is_balanced

    def test_multi_currency_unbalanced(self):
        e = JournalEntry("E005", date(2025, 1, 1))
        e.add_debit("1100", Money(100, USD))
        e.add_credit("4100", Money(85, EUR))
        assert not e.is_balanced

    def test_min_lines(self):
        e = JournalEntry("E006", date(2025, 1, 1))
        e.add_debit("1100", Money(100, USD))
        errors = e.validate()
        assert any("at least 2 lines" in err for err in errors)

class TestReversal:
    def test_create_reversal(self):
        e = JournalEntry("E001", date(2025, 1, 1))
        e.add_debit("1100", Money(100, USD))
        e.add_credit("4100", Money(100, USD))
        e.status = EntryStatus.POSTED
        reversal = e.create_reversal("R001", date(2025, 1, 2))
        assert reversal.is_balanced
        assert reversal.entry_type == EntryType.REVERSING
        assert reversal.reversal_of == "E001"
        # Reversal should swap debits and credits
        assert reversal.lines[0].is_credit  # original debit becomes credit
        assert reversal.lines[1].is_debit   # original credit becomes debit

class TestEntryLine:
    def test_both_debit_credit_invalid(self):
        line = EntryLine("1100", debit=Money(100, USD), credit=Money(50, USD))
        errors = line.validate()
        assert len(errors) > 0
    def test_negative_amount_invalid(self):
        line = EntryLine("1100", debit=Money(-10, USD))
        errors = line.validate()
        assert len(errors) > 0
