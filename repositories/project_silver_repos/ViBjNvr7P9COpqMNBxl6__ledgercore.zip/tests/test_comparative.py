import pytest
from datetime import date
from decimal import Decimal
from ledgercore.core.money import Money, USD
from ledgercore.core.account import Account, AccountType
from ledgercore.core.entry import JournalEntry
from ledgercore.chart.chart_of_accounts import ChartOfAccounts
from ledgercore.ledger.general_ledger import GeneralLedger
from ledgercore.reports.comparative import ComparativeAnalyzer

@pytest.fixture
def setup():
    chart = ChartOfAccounts("T", USD)
    chart.add_account(Account("1100", "Cash", AccountType.ASSET, USD))
    chart.add_account(Account("2100", "AP", AccountType.LIABILITY, USD))
    chart.add_account(Account("3100", "Eq", AccountType.EQUITY, USD))
    chart.add_account(Account("4100", "Rev", AccountType.REVENUE, USD))
    chart.add_account(Account("5100", "Exp", AccountType.EXPENSE, USD))
    ledger = GeneralLedger(chart)
    # Period 1 transactions
    e1 = JournalEntry("E001", date(2025,1,5))
    e1.add_debit("1100", Money(50000, USD))
    e1.add_credit("3100", Money(50000, USD))
    ledger.post_entry(e1)
    e2 = JournalEntry("E002", date(2025,1,15))
    e2.add_debit("1100", Money(10000, USD))
    e2.add_credit("4100", Money(10000, USD))
    ledger.post_entry(e2)
    e3 = JournalEntry("E003", date(2025,1,20))
    e3.add_debit("5100", Money(3000, USD))
    e3.add_credit("1100", Money(3000, USD))
    ledger.post_entry(e3)
    # Period 2 transactions
    e4 = JournalEntry("E004", date(2025,2,15))
    e4.add_debit("1100", Money(15000, USD))
    e4.add_credit("4100", Money(15000, USD))
    ledger.post_entry(e4)
    e5 = JournalEntry("E005", date(2025,2,20))
    e5.add_debit("5100", Money(4000, USD))
    e5.add_credit("1100", Money(4000, USD))
    ledger.post_entry(e5)
    return ledger

class TestBalanceSheetComparison:
    def test_basic(self, setup):
        analyzer = ComparativeAnalyzer(setup, USD)
        report = analyzer.balance_sheet_comparison(
            date(2025,2,28), date(2025,1,31),
        )
        assert len(report.lines) > 0
        # Cash should have increased
        cash = next((l for l in report.lines if l.account_number == "1100"), None)
        assert cash is not None
        assert cash.dollar_change.is_positive

    def test_common_size(self, setup):
        analyzer = ComparativeAnalyzer(setup, USD)
        report = analyzer.balance_sheet_comparison(
            date(2025,2,28), date(2025,1,31),
        )
        for line in report.lines:
            if line.current_common_size is not None:
                assert line.current_common_size >= 0

class TestIncomeStatementComparison:
    def test_basic(self, setup):
        analyzer = ComparativeAnalyzer(setup, USD)
        report = analyzer.income_statement_comparison(
            date(2025,2,1), date(2025,2,28),
            date(2025,1,1), date(2025,1,31),
        )
        assert len(report.lines) > 0
        rev = next((l for l in report.lines if l.account_number == "4100"), None)
        assert rev is not None
        # Revenue P2 ($15K) > P1 ($10K)
        assert rev.dollar_change.is_positive
        assert rev.pct_change is not None
        assert rev.pct_change == Decimal("50.00")

class TestTrendAnalysis:
    def test_basic(self, setup):
        analyzer = ComparativeAnalyzer(setup, USD)
        dates = [date(2025,1,15), date(2025,1,31), date(2025,2,28)]
        results = analyzer.trend_analysis("1100", dates)
        assert len(results) == 3
        # First entry has no pct change
        assert results[0][2] is None
        # Later entries have pct
        assert results[1][2] is not None
