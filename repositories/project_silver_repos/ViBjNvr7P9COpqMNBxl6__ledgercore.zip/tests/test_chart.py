import pytest
from ledgercore.core.account import Account, AccountType
from ledgercore.core.money import USD
from ledgercore.chart.chart_of_accounts import ChartOfAccounts

@pytest.fixture
def chart():
    c = ChartOfAccounts("Test", USD)
    c.add_account(Account("1", "Assets", AccountType.ASSET, USD))
    c.add_account(Account("11", "Current Assets", AccountType.ASSET, USD, parent_number="1"))
    c.add_account(Account("111", "Cash", AccountType.ASSET, USD, parent_number="11"))
    c.add_account(Account("2", "Liabilities", AccountType.LIABILITY, USD))
    c.add_account(Account("3", "Equity", AccountType.EQUITY, USD))
    c.add_account(Account("4", "Revenue", AccountType.REVENUE, USD))
    c.add_account(Account("5", "Expenses", AccountType.EXPENSE, USD))
    return c

class TestChartOfAccounts:
    def test_add_get(self, chart):
        a = chart.get_account("111")
        assert a is not None
        assert a.name == "Cash"
    def test_duplicate_rejected(self, chart):
        with pytest.raises(ValueError):
            chart.add_account(Account("111", "Dup", AccountType.ASSET, USD))
    def test_parent_must_exist(self):
        c = ChartOfAccounts("T", USD)
        with pytest.raises(ValueError):
            c.add_account(Account("11", "Child", AccountType.ASSET, USD, parent_number="1"))
    def test_children(self, chart):
        kids = chart.get_children("1")
        assert any(a.number == "11" for a in kids)
    def test_descendants(self, chart):
        desc = chart.get_descendants("1")
        assert any(a.number == "111" for a in desc)
    def test_by_type(self, chart):
        assets = chart.get_by_type(AccountType.ASSET)
        assert len(assets) >= 3
    def test_search(self, chart):
        results = chart.search("cash")
        assert len(results) >= 1
    def test_system_account_undeletable(self, chart):
        chart.add_account(Account("31", "RE", AccountType.EQUITY, USD, parent_number="3", is_system=True))
        with pytest.raises(ValueError):
            chart.remove_account("31")
