import pytest
from datetime import date
from decimal import Decimal
from ledgercore.core.money import Money, USD, EUR, Currency
from ledgercore.currency.exchange import ExchangeRate, ExchangeRateStore
from ledgercore.currency.multi_currency_posting import MultiCurrencyPostingEngine

@pytest.fixture
def engine():
    store = ExchangeRateStore()
    store.set_rate(ExchangeRate(EUR, USD, Decimal("1.10"), date(2025,1,1)))
    store.set_rate(ExchangeRate(EUR, USD, Decimal("1.12"), date(2025,1,31)))
    store.set_rate(ExchangeRate(EUR, USD, Decimal("1.15"), date(2025,3,1)))
    store.set_rate(ExchangeRate(EUR, USD, Decimal("1.05"), date(2025,4,1)))
    return MultiCurrencyPostingEngine(USD, store)

class TestForeignTransaction:
    def test_record(self, engine):
        entry = engine.record_foreign_transaction(
            "E001", date(2025,1,1), "1200", "4100", Money(1000, EUR),
            "Invoice to EU client", "1200",
        )
        assert entry.is_balanced

    def test_settlement_with_gain(self, engine):
        engine.record_foreign_transaction(
            "E001", date(2025,1,1), "1200", "4100", Money(1000, EUR),
            track_for_settlement="1200",
        )
        settlement = engine.record_settlement(
            "S001", date(2025,3,1), "E001", "1100", "1200", is_receivable=True,
        )
        assert settlement is not None
        assert settlement.is_balanced
        # Rate went from 1.10 to 1.15, so gain of $50

    def test_settlement_with_loss(self, engine):
        engine.record_foreign_transaction(
            "E002", date(2025,1,1), "1200", "4100", Money(1000, EUR),
            track_for_settlement="1200",
        )
        settlement = engine.record_settlement(
            "S002", date(2025,4,1), "E002", "1100", "1200", is_receivable=True,
        )
        assert settlement is not None
        assert settlement.is_balanced
        # Rate went from 1.10 to 1.05, so loss of $50


class TestRevaluation:
    def test_month_end(self, engine):
        engine.record_foreign_transaction(
            "E001", date(2025,1,1), "1200", "4100", Money(1000, EUR),
            track_for_settlement="1200",
        )
        counter = [0]
        def gen(): counter[0] += 1; return f"REV{counter[0]:03d}"
        entries = engine.month_end_revaluation(date(2025,1,31), gen)
        # Should have revaluation + reversal
        assert len(entries) == 2
        for e in entries:
            assert e.is_balanced

    def test_no_reval_after_settlement(self, engine):
        engine.record_foreign_transaction(
            "E001", date(2025,1,1), "1200", "4100", Money(1000, EUR),
            track_for_settlement="1200",
        )
        engine.record_settlement("S001", date(2025,1,15), "E001", "1100", "1200")
        counter = [0]
        def gen(): counter[0] += 1; return f"REV{counter[0]:03d}"
        entries = engine.month_end_revaluation(date(2025,1,31), gen)
        assert len(entries) == 0  # settled, nothing to revalue

    def test_open_balance_count(self, engine):
        engine.record_foreign_transaction(
            "E001", date(2025,1,1), "1200", "4100", Money(1000, EUR),
            track_for_settlement="1200",
        )
        engine.record_foreign_transaction(
            "E002", date(2025,1,5), "1200", "4100", Money(500, EUR),
            track_for_settlement="1200",
        )
        assert engine.open_balance_count == 2
        engine.record_settlement("S001", date(2025,1,15), "E001", "1100", "1200")
        assert engine.open_balance_count == 1
