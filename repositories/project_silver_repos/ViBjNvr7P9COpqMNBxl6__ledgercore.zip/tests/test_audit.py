import pytest
from ledgercore.audit.trail import AuditTrail, AuditAction

class TestAuditTrail:
    def test_record(self):
        trail = AuditTrail()
        rec = trail.record(AuditAction.ENTRY_POSTED, "entry", "E001", user="admin")
        assert rec.record_id.startswith("AUD-")
        assert trail.record_count == 1
    def test_query_by_entity(self):
        trail = AuditTrail()
        trail.record(AuditAction.ENTRY_POSTED, "entry", "E001")
        trail.record(AuditAction.ENTRY_POSTED, "entry", "E002")
        records = trail.get_records_for_entity("E001")
        assert len(records) == 1
    def test_query_by_action(self):
        trail = AuditTrail()
        trail.record(AuditAction.ENTRY_POSTED, "entry", "E001")
        trail.record(AuditAction.ACCOUNT_CREATED, "account", "1100")
        posted = trail.get_records_by_action(AuditAction.ENTRY_POSTED)
        assert len(posted) == 1
