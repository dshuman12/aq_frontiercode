import pytest
from datetime import date
from decimal import Decimal
from ledgercore.core.money import Money, USD
from ledgercore.core.account import Account, AccountType
from ledgercore.core.entry import JournalEntry
from ledgercore.chart.chart_of_accounts import ChartOfAccounts
from ledgercore.ledger.general_ledger import GeneralLedger
from ledgercore.reports.ratios import RatioAnalyzer

@pytest.fixture
def setup():
    chart = ChartOfAccounts("Test", USD)
    chart.add_account(Account("1100", "Cash", AccountType.ASSET, USD))
    chart.add_account(Account("2100", "AP", AccountType.LIABILITY, USD))
    chart.add_account(Account("3100", "Equity", AccountType.EQUITY, USD))
    chart.add_account(Account("4100", "Revenue", AccountType.REVENUE, USD))
    chart.add_account(Account("5100", "Expense", AccountType.EXPENSE, USD))
    ledger = GeneralLedger(chart)
    e1 = JournalEntry("E001", date(2025,1,1))
    e1.add_debit("1100", Money(100000, USD))
    e1.add_credit("3100", Money(100000, USD))
    ledger.post_entry(e1)
    e2 = JournalEntry("E002", date(2025,1,15))
    e2.add_debit("1100", Money(50000, USD))
    e2.add_credit("4100", Money(50000, USD))
    ledger.post_entry(e2)
    e3 = JournalEntry("E003", date(2025,1,20))
    e3.add_debit("5100", Money(20000, USD))
    e3.add_credit("1100", Money(20000, USD))
    ledger.post_entry(e3)
    e4 = JournalEntry("E004", date(2025,1,25))
    e4.add_debit("1100", Money(10000, USD))
    e4.add_credit("2100", Money(10000, USD))
    ledger.post_entry(e4)
    return ledger

class TestRatios:
    def test_current_ratio(self, setup):
        analyzer = RatioAnalyzer(setup, USD)
        r = analyzer.current_ratio(date(2025,1,31))
        assert r.value is not None
        assert r.value > 0

    def test_debt_to_equity(self, setup):
        analyzer = RatioAnalyzer(setup, USD)
        r = analyzer.debt_to_equity(date(2025,1,31))
        assert r.value is not None

    def test_net_margin(self, setup):
        analyzer = RatioAnalyzer(setup, USD)
        r = analyzer.net_margin(date(2025,1,1), date(2025,1,31))
        assert r.value is not None
        # Revenue=50000, Expense=20000, Net=30000, Margin=0.6
        assert r.value == Decimal("0.6") or abs(r.value - Decimal("0.6")) < Decimal("0.01")

    def test_all_ratios(self, setup):
        analyzer = RatioAnalyzer(setup, USD)
        ratios = analyzer.all_ratios(date(2025,1,31), date(2025,1,1))
        assert len(ratios) >= 5
