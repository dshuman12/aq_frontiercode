import pytest
from decimal import Decimal
from ledgercore.core.money import Money, USD
from ledgercore.core.account import AccountType
from ledgercore.budget.budget_manager import BudgetManager

class TestVariance:
    def test_revenue_favorable(self):
        mgr = BudgetManager(USD)
        mgr.set_budget("4100", "2025-01", Money(1000, USD))
        v = mgr.compute_variance("4100", "Sales", AccountType.REVENUE, "2025-01", Money(1200, USD))
        assert v.is_favorable
        assert v.variance == Money(200, USD)
    def test_revenue_unfavorable(self):
        mgr = BudgetManager(USD)
        mgr.set_budget("4100", "2025-01", Money(1000, USD))
        v = mgr.compute_variance("4100", "Sales", AccountType.REVENUE, "2025-01", Money(800, USD))
        assert not v.is_favorable
    def test_expense_favorable(self):
        mgr = BudgetManager(USD)
        mgr.set_budget("5100", "2025-01", Money(500, USD))
        v = mgr.compute_variance("5100", "Rent", AccountType.EXPENSE, "2025-01", Money(400, USD))
        assert v.is_favorable  # spent LESS than budget
    def test_expense_unfavorable(self):
        mgr = BudgetManager(USD)
        mgr.set_budget("5100", "2025-01", Money(500, USD))
        v = mgr.compute_variance("5100", "Rent", AccountType.EXPENSE, "2025-01", Money(600, USD))
        assert not v.is_favorable  # spent MORE than budget
