import pytest
from datetime import date
from decimal import Decimal
from ledgercore.core.money import Money, USD
from ledgercore.core.account import Account, AccountType
from ledgercore.core.entry import JournalEntry
from ledgercore.chart.chart_of_accounts import ChartOfAccounts
from ledgercore.ledger.general_ledger import GeneralLedger
from ledgercore.period.fiscal_period import FiscalPeriod, FiscalCalendar, PeriodStatus

@pytest.fixture
def setup():
    chart = ChartOfAccounts("Test", USD)
    chart.add_account(Account("1100", "Cash", AccountType.ASSET, USD))
    chart.add_account(Account("3100", "RE", AccountType.EQUITY, USD, is_system=True))
    chart.add_account(Account("3900", "Income Summary", AccountType.EQUITY, USD))
    chart.add_account(Account("4100", "Revenue", AccountType.REVENUE, USD))
    chart.add_account(Account("5100", "Expense", AccountType.EXPENSE, USD))
    ledger = GeneralLedger(chart)
    cal = FiscalCalendar(USD)
    cal.set_retained_earnings_account("3100")
    cal.set_income_summary_account("3900")
    cal.add_period(FiscalPeriod("2025-01", date(2025,1,1), date(2025,1,31)))
    return ledger, cal

class TestPeriodClosing:
    def test_close_with_net_income(self, setup):
        ledger, cal = setup
        e1 = JournalEntry("E001", date(2025,1,10))
        e1.add_debit("1100", Money(1000, USD))
        e1.add_credit("4100", Money(1000, USD))
        ledger.post_entry(e1)
        e2 = JournalEntry("E002", date(2025,1,15))
        e2.add_debit("5100", Money(300, USD))
        e2.add_credit("1100", Money(300, USD))
        ledger.post_entry(e2)
        counter = [0]
        def gen_id():
            counter[0] += 1
            return f"CL-{counter[0]:03d}"
        errors, entries = cal.close_period("2025-01", ledger, gen_id)
        assert errors == []
        assert cal.get_period("2025-01").is_closed
        re_balance = ledger.get_account_balance("3100")
        assert re_balance == Money(700, USD)

    def test_cannot_close_already_closed(self, setup):
        ledger, cal = setup
        e = JournalEntry("E001", date(2025,1,10))
        e.add_debit("1100", Money(100, USD))
        e.add_credit("4100", Money(100, USD))
        ledger.post_entry(e)
        counter = [0]
        def gen_id():
            counter[0] += 1
            return f"CL-{counter[0]:03d}"
        cal.close_period("2025-01", ledger, gen_id)
        errors, _ = cal.close_period("2025-01", ledger, gen_id)
        assert len(errors) > 0

    def test_closed_period_blocks_posting(self, setup):
        ledger, cal = setup
        e = JournalEntry("E001", date(2025,1,10))
        e.add_debit("1100", Money(100, USD))
        e.add_credit("4100", Money(100, USD))
        ledger.post_entry(e)
        counter = [0]
        def gen_id():
            counter[0] += 1
            return f"CL-{counter[0]:03d}"
        cal.close_period("2025-01", ledger, gen_id)
        can_post, msg = cal.can_post_to_date(date(2025, 1, 20))
        assert not can_post
