import pytest
from datetime import date
from decimal import Decimal
from ledgercore.core.money import Money, USD
from ledgercore.reports.aging import AgingAnalyzer, AgingItem

class TestAging:
    def test_current(self):
        analyzer = AgingAnalyzer(USD)
        items = [AgingItem("INV001", "Acme", date(2025,1,1), date(2025,1,25), Money(100, USD))]
        report = analyzer.analyze(items, date(2025, 1, 20))
        assert report.total == Money(100, USD)
        assert report.buckets[0].label == "Current"

    def test_overdue(self):
        analyzer = AgingAnalyzer(USD)
        items = [AgingItem("INV001", "Acme", date(2024,10,1), date(2024,10,31), Money(500, USD))]
        report = analyzer.analyze(items, date(2025, 3, 1))
        # 121+ days overdue
        assert any(b.label == "Over 120 Days" and not b.total.is_zero for b in report.buckets)

    def test_bad_debt_estimate(self):
        analyzer = AgingAnalyzer(USD)
        items = [
            AgingItem("INV001", "A", date(2025,1,1), date(2025,1,15), Money(1000, USD)),  # current
            AgingItem("INV002", "B", date(2024,6,1), date(2024,7,1), Money(500, USD)),    # very old
        ]
        report = analyzer.analyze(items, date(2025, 2, 1))
        estimate = analyzer.estimate_bad_debt(report)
        assert estimate > Money.zero(USD)

    def test_multiple_buckets(self):
        analyzer = AgingAnalyzer(USD)
        items = [
            AgingItem("I1", "A", date(2025,1,1), date(2025,1,20), Money(100, USD)),  # current
            AgingItem("I2", "B", date(2024,12,1), date(2024,12,15), Money(200, USD)),  # 31-60
            AgingItem("I3", "C", date(2024,11,1), date(2024,11,15), Money(300, USD)),  # 61-90
        ]
        report = analyzer.analyze(items, date(2025, 1, 25))
        non_empty = [b for b in report.buckets if not b.total.is_zero]
        assert len(non_empty) >= 2
