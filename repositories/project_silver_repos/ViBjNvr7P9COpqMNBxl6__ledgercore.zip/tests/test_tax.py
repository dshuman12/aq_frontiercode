import pytest
from decimal import Decimal
from ledgercore.core.money import Money, USD
from ledgercore.tax.calculator import TaxSchedule, TaxBracket, TaxCalculator, WithholdingRule

class TestProgressiveTax:
    def test_single_bracket(self):
        sched = TaxSchedule("flat", "US", [TaxBracket(Decimal("0"), None, Decimal("0.25"))], USD)
        tax = sched.calculate(Money(1000, USD))
        assert tax == Money(250, USD)
    def test_two_brackets(self):
        sched = TaxSchedule("prog", "US", [
            TaxBracket(Decimal("0"), Decimal("500"), Decimal("0.10")),
            TaxBracket(Decimal("500"), None, Decimal("0.20")),
        ], USD)
        tax = sched.calculate(Money(1000, USD))
        # 500 * 0.10 + 500 * 0.20 = 50 + 100 = 150
        assert tax == Money(150, USD)
    def test_below_first_bracket(self):
        sched = TaxSchedule("prog", "US", [
            TaxBracket(Decimal("0"), Decimal("500"), Decimal("0.10")),
            TaxBracket(Decimal("500"), None, Decimal("0.20")),
        ], USD)
        tax = sched.calculate(Money(300, USD))
        assert tax == Money(30, USD)

class TestWithholding:
    def test_basic(self):
        calc = TaxCalculator()
        calc.add_withholding_rule(WithholdingRule("TDS", Decimal("0.10"), {"contractor"}))
        tax = calc.calculate_withholding(Money(1000, USD), {"contractor"})
        assert tax == Money(100, USD)
    def test_exempt(self):
        calc = TaxCalculator()
        calc.add_withholding_rule(WithholdingRule("TDS", Decimal("0.10"), {"contractor"}, exempt_accounts={"1100"}))
        tax = calc.calculate_withholding(Money(1000, USD), {"contractor"}, "1100")
        assert tax == Money(0, USD)
