import pytest
from datetime import date
from decimal import Decimal
from ledgercore.core.money import Money, USD
from ledgercore.core.fixed_assets import (
    FixedAsset, FixedAssetRegister, AssetStatus, DepreciationMethod, Convention,
)

class TestFixedAssetRegister:
    def test_acquisition(self):
        reg = FixedAssetRegister()
        asset = FixedAsset(
            asset_id="FA001", name="Truck", cost=Money(50000, USD),
            salvage_value=Money(5000, USD), useful_life_years=5,
            asset_account="1500", depreciation_account="5300",
            accumulated_account="1510", gain_loss_account="4900",
            acquisition_date=date(2025, 1, 1),
        )
        entry = reg.record_acquisition(asset, "E001", "1100")
        assert entry.is_balanced
        assert reg.asset_count == 1

    def test_depreciation(self):
        reg = FixedAssetRegister()
        asset = FixedAsset(
            asset_id="FA001", name="Equipment", cost=Money(10000, USD),
            salvage_value=Money(1000, USD), useful_life_years=5,
            depreciation_method=DepreciationMethod.STRAIGHT_LINE,
            convention=Convention.FULL_MONTH,
            asset_account="1500", depreciation_account="5300",
            accumulated_account="1510", gain_loss_account="4900",
            acquisition_date=date(2025, 1, 1),
        )
        reg.add_asset(asset)
        entry = reg.record_depreciation("FA001", 1, "DEP001", date(2025, 12, 31))
        assert entry is not None
        assert entry.is_balanced

    def test_disposal_at_gain(self):
        reg = FixedAssetRegister()
        asset = FixedAsset(
            asset_id="FA001", name="Machine", cost=Money(10000, USD),
            salvage_value=Money(0, USD), useful_life_years=5,
            asset_account="1500", depreciation_account="5300",
            accumulated_account="1510", gain_loss_account="4900",
        )
        reg.add_asset(asset)
        # Record 2 years of depreciation
        for i in range(1, 3):
            reg.record_depreciation("FA001", i, f"DEP{i:03d}", date(2025 + i - 1, 12, 31))
        # Book value should be 10000 - 2*2000 = 6000 (approx)
        bv = asset.book_value
        sale_price = Money(7000, USD)
        entry = reg.record_disposal("FA001", sale_price, date(2027, 6, 1), "DISP001", "1100")
        assert entry is not None
        assert entry.is_balanced
        assert asset.is_disposed

    def test_disposal_at_loss(self):
        reg = FixedAssetRegister()
        asset = FixedAsset(
            asset_id="FA002", name="Old Van", cost=Money(20000, USD),
            salvage_value=Money(2000, USD), useful_life_years=5,
            asset_account="1500", depreciation_account="5300",
            accumulated_account="1510", gain_loss_account="4900",
        )
        reg.add_asset(asset)
        # Sell immediately (no depreciation yet, book value = cost)
        entry = reg.record_disposal("FA002", Money(15000, USD), date(2025, 6, 1), "DISP002", "1100")
        assert entry is not None
        assert entry.is_balanced
        gain_loss = asset.compute_disposal_gain_loss(Money(15000, USD))
        assert gain_loss.is_negative  # loss

    def test_total_book_value(self):
        reg = FixedAssetRegister()
        reg.add_asset(FixedAsset(
            asset_id="FA001", name="A", cost=Money(10000, USD),
            salvage_value=Money(0, USD), useful_life_years=5,
            asset_account="1500", depreciation_account="5300",
            accumulated_account="1510", gain_loss_account="4900",
        ))
        reg.add_asset(FixedAsset(
            asset_id="FA002", name="B", cost=Money(5000, USD),
            salvage_value=Money(0, USD), useful_life_years=3,
            asset_account="1500", depreciation_account="5300",
            accumulated_account="1510", gain_loss_account="4900",
        ))
        assert reg.total_cost() == Money(15000, USD)
