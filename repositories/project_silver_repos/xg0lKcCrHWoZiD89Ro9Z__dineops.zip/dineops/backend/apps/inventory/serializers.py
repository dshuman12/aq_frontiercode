from __future__ import annotations

from rest_framework import serializers

from .models import (
    InventoryCount, InventoryCountItem, InventoryItem, InventoryTransaction,
    LotTrackingRecord, LowStockAlert,
)


class InventoryItemSerializer(serializers.ModelSerializer):
    ingredient_name = serializers.CharField(source="ingredient.name", read_only=True)
    base_unit = serializers.CharField(source="ingredient.base_unit", read_only=True)
    location_name = serializers.CharField(source="location.name", read_only=True)
    total_value = serializers.DecimalField(max_digits=14, decimal_places=2, read_only=True)
    is_low = serializers.BooleanField(read_only=True)

    class Meta:
        model = InventoryItem
        fields = [
            "id", "restaurant", "location", "location_name",
            "ingredient", "ingredient_name", "base_unit",
            "quantity_on_hand", "average_cost", "total_value",
            "par_level", "reorder_point", "reorder_quantity",
            "is_active", "is_low",
            "last_counted_at", "last_received_at",
        ]
        read_only_fields = ["id", "average_cost",
                            "last_counted_at", "last_received_at"]


class CreateInventoryItemSerializer(serializers.Serializer):
    location_id = serializers.UUIDField()
    ingredient_id = serializers.UUIDField()
    par_level = serializers.DecimalField(max_digits=14, decimal_places=3, default=0)
    reorder_point = serializers.DecimalField(max_digits=14, decimal_places=3, default=0)
    reorder_quantity = serializers.DecimalField(max_digits=14, decimal_places=3, default=0)
    opening_quantity = serializers.DecimalField(max_digits=14, decimal_places=3, default=0)
    opening_cost = serializers.DecimalField(max_digits=12, decimal_places=4, default=0)


class ReceiveStockSerializer(serializers.Serializer):
    quantity = serializers.DecimalField(max_digits=14, decimal_places=3)
    unit_cost = serializers.DecimalField(max_digits=12, decimal_places=4)
    reference = serializers.CharField(required=False, allow_blank=True)
    lot_code = serializers.CharField(required=False, allow_blank=True)
    expires_at = serializers.DateField(required=False, allow_null=True)
    supplier_name = serializers.CharField(required=False, allow_blank=True)
    supplier_lot_code = serializers.CharField(required=False, allow_blank=True)


class ConsumeStockSerializer(serializers.Serializer):
    quantity = serializers.DecimalField(max_digits=14, decimal_places=3)
    kind = serializers.ChoiceField(
        choices=["usage", "waste", "transfer_out"], default="usage",
    )
    reference = serializers.CharField(required=False, allow_blank=True)


class TransferStockSerializer(serializers.Serializer):
    to_item_id = serializers.UUIDField()
    quantity = serializers.DecimalField(max_digits=14, decimal_places=3)
    reference = serializers.CharField(required=False, allow_blank=True)


class InventoryTransactionSerializer(serializers.ModelSerializer):
    ingredient_name = serializers.CharField(
        source="item.ingredient.name", read_only=True,
    )
    location_name = serializers.CharField(
        source="item.location.name", read_only=True,
    )

    class Meta:
        model = InventoryTransaction
        fields = ["id", "item", "ingredient_name", "location_name",
                  "kind", "quantity", "unit_cost", "reference",
                  "actor", "occurred_at", "notes"]


class InventoryCountSerializer(serializers.ModelSerializer):
    line_count = serializers.IntegerField(source="lines.count", read_only=True)
    location_name = serializers.CharField(source="location.name", read_only=True)

    class Meta:
        model = InventoryCount
        fields = [
            "id", "restaurant", "location", "location_name",
            "name", "status",
            "started_by", "started_at", "completed_at",
            "total_value_before", "total_value_after", "variance_value",
            "line_count", "notes",
        ]


class InventoryCountItemSerializer(serializers.ModelSerializer):
    ingredient_name = serializers.CharField(
        source="inventory_item.ingredient.name", read_only=True,
    )
    base_unit = serializers.CharField(
        source="inventory_item.ingredient.base_unit", read_only=True,
    )

    class Meta:
        model = InventoryCountItem
        fields = ["id", "count", "inventory_item", "ingredient_name", "base_unit",
                  "expected_quantity", "counted_quantity", "variance",
                  "variance_value", "counted_by", "counted_at", "notes"]


class StartCountSerializer(serializers.Serializer):
    location_id = serializers.UUIDField()
    name = serializers.CharField(max_length=160)


class SubmitCountLineSerializer(serializers.Serializer):
    counted_quantity = serializers.DecimalField(max_digits=14, decimal_places=3)
    notes = serializers.CharField(required=False, allow_blank=True)


class LotTrackingSerializer(serializers.ModelSerializer):
    class Meta:
        model = LotTrackingRecord
        fields = "__all__"


class LowStockAlertSerializer(serializers.ModelSerializer):
    ingredient_name = serializers.CharField(
        source="item.ingredient.name", read_only=True,
    )
    location_name = serializers.CharField(
        source="item.location.name", read_only=True,
    )

    class Meta:
        model = LowStockAlert
        fields = ["id", "item", "ingredient_name", "location_name",
                  "triggered_at", "triggered_quantity",
                  "reorder_point_at_alert", "resolved_at", "notified_at"]
