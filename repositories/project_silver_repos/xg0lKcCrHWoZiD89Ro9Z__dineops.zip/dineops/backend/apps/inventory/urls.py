from django.urls import path

from . import views

app_name = "inventory"

urlpatterns = [
    # Items
    path("<uuid:restaurant_id>/items/",
         views.InventoryItemListCreate.as_view(), name="item-list-create"),
    path("<uuid:restaurant_id>/items/<uuid:item_id>/",
         views.InventoryItemDetail.as_view(), name="item-detail"),
    path("<uuid:restaurant_id>/items/<uuid:item_id>/receive/",
         views.ReceiveStockView.as_view(), name="receive"),
    path("<uuid:restaurant_id>/items/<uuid:item_id>/consume/",
         views.ConsumeStockView.as_view(), name="consume"),
    path("<uuid:restaurant_id>/items/<uuid:item_id>/transfer/",
         views.TransferStockView.as_view(), name="transfer"),
    path("<uuid:restaurant_id>/items/<uuid:item_id>/transactions/",
         views.TransactionListView.as_view(), name="transactions"),

    # Counts
    path("<uuid:restaurant_id>/counts/",
         views.CountListCreate.as_view(), name="count-list-create"),
    path("<uuid:restaurant_id>/counts/<uuid:count_id>/",
         views.CountDetail.as_view(), name="count-detail"),
    path("<uuid:restaurant_id>/count-lines/<uuid:line_id>/",
         views.SubmitCountLine.as_view(), name="count-line-submit"),
    path("<uuid:restaurant_id>/counts/<uuid:count_id>/complete/",
         views.CompleteCount.as_view(), name="count-complete"),
    path("<uuid:restaurant_id>/counts/<uuid:count_id>/cancel/",
         views.CancelCount.as_view(), name="count-cancel"),

    # Reports
    path("<uuid:restaurant_id>/stock-value/<uuid:location_id>/",
         views.StockValueView.as_view(), name="stock-value"),
    path("<uuid:restaurant_id>/low-stock/",
         views.LowStockListView.as_view(), name="low-stock"),
    path("<uuid:restaurant_id>/expiring-lots/",
         views.ExpiringLotsView.as_view(), name="expiring-lots"),
    path("<uuid:restaurant_id>/alerts/low-stock/",
         views.LowStockAlertListView.as_view(), name="low-stock-alerts"),
]
