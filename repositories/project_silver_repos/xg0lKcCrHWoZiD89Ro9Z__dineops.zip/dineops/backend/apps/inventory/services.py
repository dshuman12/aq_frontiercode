from __future__ import annotations

from decimal import Decimal
from typing import Optional

from django.db import transaction
from django.db.models import F, Sum
from django.utils import timezone

from apps.common.exceptions import Conflict, NotFound, ValidationError
from apps.ingredients.models import Ingredient
from apps.locations.models import Location

from .models import (
    InventoryCount, InventoryCountItem, InventoryItem, InventoryTransaction,
    LotTrackingRecord, LowStockAlert,
)


@transaction.atomic
def create_inventory_item(*, restaurant, location: Location, ingredient: Ingredient,
                          par_level: Decimal = Decimal("0"),
                          reorder_point: Decimal = Decimal("0"),
                          reorder_quantity: Decimal = Decimal("0"),
                          opening_quantity: Decimal = Decimal("0"),
                          opening_cost: Decimal = Decimal("0")) -> InventoryItem:
    if location.restaurant_id != restaurant.id:
        raise ValidationError("location_not_in_restaurant")
    if ingredient.restaurant_id != restaurant.id:
        raise ValidationError("ingredient_not_in_restaurant")
    if InventoryItem.objects.filter(location=location, ingredient=ingredient).exists():
        raise Conflict("inventory_item_already_exists")

    item = InventoryItem.objects.create(
        restaurant=restaurant, location=location, ingredient=ingredient,
        par_level=par_level, reorder_point=reorder_point,
        reorder_quantity=reorder_quantity,
        quantity_on_hand=opening_quantity,
        average_cost=opening_cost or ingredient.cost_per_unit,
    )
    if opening_quantity > 0:
        InventoryTransaction.objects.create(
            item=item, kind="opening", quantity=opening_quantity,
            unit_cost=opening_cost or ingredient.cost_per_unit,
            occurred_at=timezone.now(),
            reference="initial",
        )
    return item


def _update_weighted_average(item: InventoryItem, quantity_in: Decimal,
                             unit_cost: Decimal) -> None:
    """Move avg cost toward unit_cost in proportion to inflow."""
    if quantity_in <= 0:
        return
    current_qty = item.quantity_on_hand
    current_avg = item.average_cost
    new_qty = current_qty + quantity_in
    if new_qty == 0:
        return
    new_avg = ((current_qty * current_avg) + (quantity_in * unit_cost)) / new_qty
    item.average_cost = new_avg.quantize(Decimal("0.0001"))


@transaction.atomic
def receive_stock(*, item: InventoryItem, quantity: Decimal, unit_cost: Decimal,
                  reference: str = "", actor=None,
                  occurred_at=None,
                  lot_code: Optional[str] = None,
                  expires_at=None,
                  supplier_name: str = "",
                  supplier_lot_code: str = "") -> InventoryTransaction:
    if quantity is None or quantity <= 0:
        raise ValidationError("invalid_quantity")
    if unit_cost is None or unit_cost < 0:
        raise ValidationError("invalid_unit_cost")
    occurred_at = occurred_at or timezone.now()

    _update_weighted_average(item, quantity, unit_cost)
    item.quantity_on_hand = item.quantity_on_hand + quantity
    item.last_received_at = occurred_at
    item.save(update_fields=[
        "quantity_on_hand", "average_cost", "last_received_at", "updated_at",
    ])

    txn = InventoryTransaction.objects.create(
        item=item, kind="receive", quantity=quantity,
        unit_cost=unit_cost, reference=reference, actor=actor,
        occurred_at=occurred_at,
    )

    if lot_code:
        LotTrackingRecord.objects.create(
            item=item, lot_code=lot_code,
            received_at=occurred_at, expires_at=expires_at,
            quantity_received=quantity, quantity_remaining=quantity,
            unit_cost=unit_cost,
            supplier_name=supplier_name,
            supplier_lot_code=supplier_lot_code,
        )

    # Resolve any open low-stock alert if we're now above reorder_point
    if item.quantity_on_hand > item.reorder_point:
        LowStockAlert.objects.filter(item=item, resolved_at__isnull=True).update(
            resolved_at=timezone.now(),
        )

    return txn


@transaction.atomic
def consume_stock(*, item: InventoryItem, quantity: Decimal,
                  kind: str = "usage", reference: str = "", actor=None,
                  occurred_at=None) -> InventoryTransaction:
    if kind not in ("usage", "waste", "transfer_out"):
        raise ValidationError("invalid_kind")
    if quantity is None or quantity <= 0:
        raise ValidationError("invalid_quantity")
    if item.quantity_on_hand < quantity:
        raise ValidationError(
            "insufficient_stock",
            f"On hand: {item.quantity_on_hand}, requested: {quantity}",
            on_hand=str(item.quantity_on_hand),
            requested=str(quantity),
        )
    occurred_at = occurred_at or timezone.now()

    item.quantity_on_hand = item.quantity_on_hand - quantity
    item.save(update_fields=["quantity_on_hand", "updated_at"])

    txn = InventoryTransaction.objects.create(
        item=item, kind=kind, quantity=-quantity,
        unit_cost=item.average_cost,
        reference=reference, actor=actor, occurred_at=occurred_at,
    )

    # Decrement lot quantities (FEFO — first expiring first out)
    remaining = quantity
    lots = (
        item.lots.filter(quantity_remaining__gt=0, is_recalled=False)
        .order_by("expires_at", "received_at")
    )
    for lot in lots:
        if remaining <= 0:
            break
        take = min(remaining, lot.quantity_remaining)
        lot.quantity_remaining = lot.quantity_remaining - take
        lot.save(update_fields=["quantity_remaining", "updated_at"])
        remaining -= take
    # If remaining > 0 here, we drew down past tracked lots — ignore silently
    # (sometimes the kitchen prepped untracked stock).

    # Trigger a low-stock alert if we just crossed reorder_point
    if (item.is_active and item.reorder_point > 0
            and item.quantity_on_hand <= item.reorder_point):
        already_open = LowStockAlert.objects.filter(
            item=item, resolved_at__isnull=True
        ).exists()
        if not already_open:
            LowStockAlert.objects.create(
                item=item,
                triggered_quantity=item.quantity_on_hand,
                reorder_point_at_alert=item.reorder_point,
            )

    return txn


@transaction.atomic
def transfer_stock(*, from_item: InventoryItem, to_item: InventoryItem,
                   quantity: Decimal, reference: str = "",
                   actor=None) -> tuple[InventoryTransaction, InventoryTransaction]:
    if from_item.ingredient_id != to_item.ingredient_id:
        raise ValidationError("ingredient_mismatch")
    if from_item.id == to_item.id:
        raise ValidationError("same_location")
    if quantity <= 0:
        raise ValidationError("invalid_quantity")
    occurred_at = timezone.now()

    out_txn = consume_stock(
        item=from_item, quantity=quantity, kind="transfer_out",
        reference=reference or f"transfer:{to_item.location.name}", actor=actor,
        occurred_at=occurred_at,
    )
    # Receive at destination at the source's average cost (no markup on transfer)
    in_txn = receive_stock(
        item=to_item, quantity=quantity, unit_cost=from_item.average_cost,
        reference=reference or f"transfer:{from_item.location.name}",
        actor=actor, occurred_at=occurred_at,
    )
    # The receive_stock above wrote a "receive" txn. Convert it to "transfer_in"
    # so reporting can distinguish purchases from transfers.
    in_txn.kind = "transfer_in"
    in_txn.save(update_fields=["kind"])
    return out_txn, in_txn


@transaction.atomic
def adjust_to_count(*, item: InventoryItem, counted_quantity: Decimal,
                    reference: str = "", actor=None) -> InventoryTransaction:
    """Reconcile a physical count: write a delta transaction."""
    if counted_quantity is None or counted_quantity < 0:
        raise ValidationError("invalid_quantity")
    delta = counted_quantity - item.quantity_on_hand
    if delta == 0:
        return None  # nothing to record
    item.quantity_on_hand = counted_quantity
    item.last_counted_at = timezone.now()
    item.save(update_fields=["quantity_on_hand", "last_counted_at", "updated_at"])
    return InventoryTransaction.objects.create(
        item=item, kind="count_adjustment", quantity=delta,
        unit_cost=item.average_cost, reference=reference, actor=actor,
        occurred_at=timezone.now(),
    )


# -------------------- Counts --------------------

@transaction.atomic
def start_inventory_count(*, restaurant, location: Location, name: str,
                          actor=None) -> InventoryCount:
    if location.restaurant_id != restaurant.id:
        raise ValidationError("location_not_in_restaurant")
    if not name.strip():
        raise ValidationError("invalid_name")
    open_count = InventoryCount.objects.filter(
        location=location, status__in=["draft", "in_progress"],
    ).first()
    if open_count:
        raise Conflict("count_already_in_progress")

    count = InventoryCount.objects.create(
        restaurant=restaurant, location=location,
        name=name.strip(), status="in_progress",
        started_by=actor, started_at=timezone.now(),
    )
    items = InventoryItem.objects.filter(location=location, is_active=True)
    total_value_before = Decimal("0")
    for inv_item in items:
        InventoryCountItem.objects.create(
            count=count, inventory_item=inv_item,
            expected_quantity=inv_item.quantity_on_hand,
        )
        total_value_before += inv_item.total_value
    count.total_value_before = total_value_before
    count.save(update_fields=["total_value_before"])
    return count


@transaction.atomic
def submit_count_line(*, line: InventoryCountItem, counted_quantity: Decimal,
                      counted_by=None, notes: str = "") -> InventoryCountItem:
    if counted_quantity is None or counted_quantity < 0:
        raise ValidationError("invalid_counted_quantity")
    line.counted_quantity = counted_quantity
    line.variance = counted_quantity - line.expected_quantity
    line.variance_value = (
        line.variance * line.inventory_item.average_cost
    ).quantize(Decimal("0.01"))
    line.counted_by = counted_by
    line.counted_at = timezone.now()
    line.notes = notes
    line.save()
    return line


@transaction.atomic
def complete_inventory_count(*, count: InventoryCount, actor=None) -> InventoryCount:
    if count.status != "in_progress":
        raise ValidationError("count_not_in_progress")
    total_value_after = Decimal("0")
    variance_value_total = Decimal("0")
    for line in count.lines.select_related("inventory_item").all():
        if line.counted_quantity is None:
            continue
        adjust_to_count(
            item=line.inventory_item,
            counted_quantity=line.counted_quantity,
            reference=f"count:{count.id}",
            actor=actor,
        )
        total_value_after += line.inventory_item.total_value
        variance_value_total += line.variance_value
    count.total_value_after = total_value_after
    count.variance_value = variance_value_total
    count.completed_at = timezone.now()
    count.status = "completed"
    count.save()
    return count


@transaction.atomic
def cancel_inventory_count(*, count: InventoryCount) -> InventoryCount:
    if count.status not in ("draft", "in_progress"):
        raise ValidationError("count_not_cancellable")
    count.status = "cancelled"
    count.completed_at = timezone.now()
    count.save(update_fields=["status", "completed_at", "updated_at"])
    return count


# -------------------- Lot recalls --------------------

@transaction.atomic
def mark_lot_recalled(*, lot: LotTrackingRecord, reason: str = "") -> LotTrackingRecord:
    """Mark a lot as recalled — future FEFO selection skips it."""
    lot.is_recalled = True
    if reason:
        lot.notes = f"{lot.notes}\nRECALLED: {reason}".strip()
    lot.save(update_fields=["is_recalled", "notes", "updated_at"])
    return lot
