from __future__ import annotations

from datetime import date, datetime, timedelta, timezone as dtz
from decimal import Decimal

import pytest

from apps.accounts.models import User
from apps.ingredients.models import Ingredient
from apps.inventory.models import InventoryTransaction
from apps.inventory.selectors import (
    expiring_lots, low_stock_items, stock_value_by_location, usage_summary,
)
from apps.inventory.services import (
    consume_stock, create_inventory_item, receive_stock,
)
from apps.locations.models import Location
from apps.restaurants.models import Restaurant


pytestmark = pytest.mark.django_db


def _setup():
    owner = User.objects.create_user(email="o@x.com", password="pwpwpwpw")
    r = Restaurant.objects.create(name="R", slug="r", owner=owner)
    loc = Location.objects.create(
        restaurant=r, name="Main", slug="main", accepts_dine_in=True,
    )
    return r, loc


class TestStockValueByLocation:
    def test_sum_value(self):
        r, loc = _setup()
        ing1 = Ingredient.objects.create(
            restaurant=r, name="A", base_unit="g",
            cost_per_unit=Decimal("0.10"),
        )
        ing2 = Ingredient.objects.create(
            restaurant=r, name="B", base_unit="g",
            cost_per_unit=Decimal("0.20"),
        )
        create_inventory_item(
            restaurant=r, location=loc, ingredient=ing1,
            opening_quantity=Decimal("100"), opening_cost=Decimal("0.10"),
        )
        create_inventory_item(
            restaurant=r, location=loc, ingredient=ing2,
            opening_quantity=Decimal("50"), opening_cost=Decimal("0.20"),
        )
        assert stock_value_by_location(r.id, loc.id) == Decimal("20.00")

    def test_inactive_excluded(self):
        r, loc = _setup()
        ing = Ingredient.objects.create(restaurant=r, name="X")
        item = create_inventory_item(
            restaurant=r, location=loc, ingredient=ing,
            opening_quantity=Decimal("10"), opening_cost=Decimal("1"),
        )
        item.is_active = False
        item.save()
        assert stock_value_by_location(r.id, loc.id) == Decimal("0.00")


class TestLowStockItems:
    def test_returns_items_at_or_below_reorder(self):
        r, loc = _setup()
        ing_low = Ingredient.objects.create(restaurant=r, name="Low")
        ing_ok = Ingredient.objects.create(restaurant=r, name="OK")
        create_inventory_item(
            restaurant=r, location=loc, ingredient=ing_low,
            reorder_point=Decimal("20"), opening_quantity=Decimal("10"),
        )
        create_inventory_item(
            restaurant=r, location=loc, ingredient=ing_ok,
            reorder_point=Decimal("20"), opening_quantity=Decimal("100"),
        )
        results = low_stock_items(r.id)
        assert len(results) == 1
        assert results[0].ingredient.name == "Low"

    def test_zero_reorder_point_excluded(self):
        r, loc = _setup()
        ing = Ingredient.objects.create(restaurant=r, name="X")
        create_inventory_item(
            restaurant=r, location=loc, ingredient=ing,
            reorder_point=Decimal("0"), opening_quantity=Decimal("0"),
        )
        assert low_stock_items(r.id) == []


class TestExpiringLots:
    def test_within_window(self):
        r, loc = _setup()
        ing = Ingredient.objects.create(restaurant=r, name="X")
        item = create_inventory_item(
            restaurant=r, location=loc, ingredient=ing,
        )
        receive_stock(
            item=item, quantity=Decimal("10"), unit_cost=Decimal("1"),
            lot_code="EXP-3D",
            expires_at=date.today() + timedelta(days=3),
        )
        receive_stock(
            item=item, quantity=Decimal("10"), unit_cost=Decimal("1"),
            lot_code="EXP-30D",
            expires_at=date.today() + timedelta(days=30),
        )
        results = expiring_lots(r.id, within_days=7)
        assert len(results) == 1
        assert results[0].lot_code == "EXP-3D"

    def test_recalled_lots_excluded(self):
        from apps.inventory.services import mark_lot_recalled
        from apps.inventory.models import LotTrackingRecord
        r, loc = _setup()
        ing = Ingredient.objects.create(restaurant=r, name="X")
        item = create_inventory_item(restaurant=r, location=loc, ingredient=ing)
        receive_stock(
            item=item, quantity=Decimal("10"), unit_cost=Decimal("1"),
            lot_code="REC", expires_at=date.today() + timedelta(days=2),
        )
        lot = LotTrackingRecord.objects.get(lot_code="REC")
        mark_lot_recalled(lot=lot)
        results = expiring_lots(r.id, within_days=7)
        assert len(results) == 0


class TestUsageSummary:
    def test_aggregates_by_kind(self):
        r, loc = _setup()
        ing = Ingredient.objects.create(restaurant=r, name="Beef",
                                        cost_per_unit=Decimal("0.05"))
        item = create_inventory_item(
            restaurant=r, location=loc, ingredient=ing,
            opening_quantity=Decimal("1000"), opening_cost=Decimal("0.05"),
        )
        consume_stock(item=item, quantity=Decimal("100"), kind="usage")
        consume_stock(item=item, quantity=Decimal("50"), kind="waste")
        consume_stock(item=item, quantity=Decimal("200"), kind="usage")
        start = datetime.now(dtz.utc) - timedelta(days=1)
        end = datetime.now(dtz.utc) + timedelta(days=1)
        result = usage_summary(r.id, start=start, end=end)
        assert len(result) == 2
        kinds = {row["kind"]: row["total_qty"] for row in result}
        assert kinds["usage"] == Decimal("-300.000")
        assert kinds["waste"] == Decimal("-50.000")
