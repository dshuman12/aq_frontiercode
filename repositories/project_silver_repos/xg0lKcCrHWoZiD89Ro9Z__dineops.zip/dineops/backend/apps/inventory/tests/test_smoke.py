import pytest

pytestmark = pytest.mark.django_db


def test_inventory_module_imports():
    from apps.inventory import models, services, selectors, tasks, views, urls
    assert all([models, services, selectors, tasks, views, urls])
