from __future__ import annotations

from datetime import date, timedelta
from decimal import Decimal

import pytest

from apps.accounts.models import User
from apps.ingredients.models import Ingredient
from apps.inventory.models import LowStockAlert
from apps.inventory.services import (
    consume_stock, create_inventory_item, mark_lot_recalled, receive_stock,
)
from apps.inventory.tasks import (
    notify_low_stock_alerts, scan_expiring_lots, scan_low_stock,
)
from apps.locations.models import Location
from apps.restaurants.models import Restaurant


pytestmark = pytest.mark.django_db


def _setup():
    owner = User.objects.create_user(email="o@x.com", password="pwpwpwpw")
    rest = Restaurant.objects.create(name="R", slug="r", owner=owner)
    loc = Location.objects.create(restaurant=rest, name="Main",
                                  slug="main", accepts_dine_in=True)
    return rest, loc


class TestScanLowStock:
    def test_opens_alert(self):
        r, loc = _setup()
        ing = Ingredient.objects.create(restaurant=r, name="X")
        # Create item already below reorder_point — but bypass automatic alert
        # by going via direct ORM
        from apps.inventory.models import InventoryItem
        item = InventoryItem.objects.create(
            restaurant=r, location=loc, ingredient=ing,
            quantity_on_hand=Decimal("5"), reorder_point=Decimal("20"),
            average_cost=Decimal("0.10"),
        )
        assert LowStockAlert.objects.filter(item=item).count() == 0
        result = scan_low_stock()
        assert result["opened"] == 1
        assert LowStockAlert.objects.filter(
            item=item, resolved_at__isnull=True,
        ).count() == 1

    def test_idempotent(self):
        r, loc = _setup()
        ing = Ingredient.objects.create(restaurant=r, name="X")
        item = create_inventory_item(
            restaurant=r, location=loc, ingredient=ing,
            reorder_point=Decimal("20"), opening_quantity=Decimal("5"),
        )
        scan_low_stock()
        scan_low_stock()
        scan_low_stock()
        assert LowStockAlert.objects.filter(
            item=item, resolved_at__isnull=True,
        ).count() == 1

    def test_skips_above_reorder(self):
        r, loc = _setup()
        ing = Ingredient.objects.create(restaurant=r, name="OK")
        create_inventory_item(
            restaurant=r, location=loc, ingredient=ing,
            reorder_point=Decimal("20"), opening_quantity=Decimal("100"),
        )
        result = scan_low_stock()
        assert result["opened"] == 0


class TestNotifyLowStock:
    def test_marks_notified(self):
        r, loc = _setup()
        ing = Ingredient.objects.create(restaurant=r, name="X")
        item = create_inventory_item(
            restaurant=r, location=loc, ingredient=ing,
            reorder_point=Decimal("20"), opening_quantity=Decimal("5"),
        )
        scan_low_stock()
        result = notify_low_stock_alerts()
        assert result["notified"] >= 1
        alert = LowStockAlert.objects.get(item=item)
        assert alert.notified_at is not None

    def test_skips_already_notified(self):
        r, loc = _setup()
        ing = Ingredient.objects.create(restaurant=r, name="X")
        item = create_inventory_item(
            restaurant=r, location=loc, ingredient=ing,
            reorder_point=Decimal("20"), opening_quantity=Decimal("5"),
        )
        scan_low_stock()
        notify_low_stock_alerts()
        result = notify_low_stock_alerts()
        assert result["notified"] == 0


class TestScanExpiringLots:
    def test_flags_close_to_expiry(self):
        r, loc = _setup()
        ing = Ingredient.objects.create(restaurant=r, name="X")
        item = create_inventory_item(restaurant=r, location=loc, ingredient=ing)
        receive_stock(
            item=item, quantity=Decimal("10"), unit_cost=Decimal("1"),
            lot_code="A", expires_at=date.today() + timedelta(days=2),
        )
        receive_stock(
            item=item, quantity=Decimal("10"), unit_cost=Decimal("1"),
            lot_code="B", expires_at=date.today() + timedelta(days=10),
        )
        result = scan_expiring_lots(within_days=3)
        assert result["flagged"] == 1

    def test_recalled_excluded(self):
        from apps.inventory.models import LotTrackingRecord
        r, loc = _setup()
        ing = Ingredient.objects.create(restaurant=r, name="X")
        item = create_inventory_item(restaurant=r, location=loc, ingredient=ing)
        receive_stock(
            item=item, quantity=Decimal("10"), unit_cost=Decimal("1"),
            lot_code="REC", expires_at=date.today() + timedelta(days=1),
        )
        lot = LotTrackingRecord.objects.get()
        mark_lot_recalled(lot=lot)
        result = scan_expiring_lots(within_days=3)
        assert result["flagged"] == 0
