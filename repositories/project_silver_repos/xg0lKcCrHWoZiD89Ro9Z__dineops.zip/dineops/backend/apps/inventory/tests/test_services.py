from __future__ import annotations

from datetime import date, timedelta
from decimal import Decimal

import pytest

from apps.accounts.models import User
from apps.common.exceptions import Conflict, ValidationError
from apps.ingredients.models import Ingredient
from apps.inventory.models import (
    InventoryCount, InventoryItem, InventoryTransaction,
    LotTrackingRecord, LowStockAlert,
)
from apps.inventory.services import (
    adjust_to_count, cancel_inventory_count, complete_inventory_count,
    consume_stock, create_inventory_item, mark_lot_recalled,
    receive_stock, start_inventory_count, submit_count_line,
    transfer_stock,
)
from apps.locations.models import Location
from apps.restaurants.models import Restaurant


pytestmark = pytest.mark.django_db


def _restaurant():
    owner = User.objects.create_user(email="o@x.com", password="pwpwpwpw")
    return Restaurant.objects.create(name="R", slug="r", owner=owner)


def _location(rest, name="Main"):
    return Location.objects.create(
        restaurant=rest, name=name, slug=name.lower(),
        accepts_dine_in=True,
    )


def _ingredient(rest, name="Tomato", base_unit="g",
                cost=Decimal("0.01"), yield_factor=Decimal("1")):
    return Ingredient.objects.create(
        restaurant=rest, name=name, base_unit=base_unit,
        cost_per_unit=cost, yield_factor=yield_factor,
    )


# -------------------- create_inventory_item --------------------

class TestCreateInventoryItem:
    def test_creates(self):
        r = _restaurant()
        loc = _location(r)
        ing = _ingredient(r)
        item = create_inventory_item(
            restaurant=r, location=loc, ingredient=ing,
            par_level=Decimal("100"), reorder_point=Decimal("20"),
            opening_quantity=Decimal("50"), opening_cost=Decimal("0.02"),
        )
        assert item.quantity_on_hand == Decimal("50.000")
        assert item.average_cost == Decimal("0.0200")
        assert InventoryTransaction.objects.filter(
            item=item, kind="opening",
        ).count() == 1

    def test_no_opening_no_txn(self):
        r = _restaurant()
        item = create_inventory_item(
            restaurant=r, location=_location(r), ingredient=_ingredient(r),
        )
        assert item.quantity_on_hand == Decimal("0.000")
        assert InventoryTransaction.objects.filter(item=item).count() == 0

    def test_duplicate_conflict(self):
        r = _restaurant()
        loc = _location(r)
        ing = _ingredient(r)
        create_inventory_item(restaurant=r, location=loc, ingredient=ing)
        with pytest.raises(Conflict):
            create_inventory_item(restaurant=r, location=loc, ingredient=ing)

    def test_cross_restaurant_rejected(self):
        r1 = _restaurant()
        r2 = Restaurant.objects.create(
            name="R2", slug="r2", owner=r1.owner,
        )
        loc = _location(r1)
        ing_in_r2 = Ingredient.objects.create(restaurant=r2, name="X")
        with pytest.raises(ValidationError):
            create_inventory_item(restaurant=r1, location=loc, ingredient=ing_in_r2)


# -------------------- receive_stock --------------------

class TestReceiveStock:
    def test_receives_and_updates_avg(self):
        r = _restaurant()
        item = create_inventory_item(
            restaurant=r, location=_location(r), ingredient=_ingredient(r),
        )
        receive_stock(item=item, quantity=Decimal("100"),
                      unit_cost=Decimal("0.05"))
        item.refresh_from_db()
        assert item.quantity_on_hand == Decimal("100.000")
        assert item.average_cost == Decimal("0.0500")
        assert item.last_received_at is not None

    def test_weighted_average(self):
        r = _restaurant()
        item = create_inventory_item(
            restaurant=r, location=_location(r), ingredient=_ingredient(r),
            opening_quantity=Decimal("100"), opening_cost=Decimal("0.04"),
        )
        # add 100 more @ 0.06 — avg should be 0.05
        receive_stock(item=item, quantity=Decimal("100"),
                      unit_cost=Decimal("0.06"))
        item.refresh_from_db()
        assert item.quantity_on_hand == Decimal("200.000")
        assert item.average_cost == Decimal("0.0500")

    def test_zero_quantity_rejected(self):
        r = _restaurant()
        item = create_inventory_item(
            restaurant=r, location=_location(r), ingredient=_ingredient(r),
        )
        with pytest.raises(ValidationError):
            receive_stock(item=item, quantity=Decimal("0"),
                          unit_cost=Decimal("0.05"))

    def test_negative_cost_rejected(self):
        r = _restaurant()
        item = create_inventory_item(
            restaurant=r, location=_location(r), ingredient=_ingredient(r),
        )
        with pytest.raises(ValidationError):
            receive_stock(item=item, quantity=Decimal("10"),
                          unit_cost=Decimal("-1"))

    def test_creates_lot(self):
        r = _restaurant()
        item = create_inventory_item(
            restaurant=r, location=_location(r), ingredient=_ingredient(r),
        )
        receive_stock(
            item=item, quantity=Decimal("10"), unit_cost=Decimal("5"),
            lot_code="LOT-1", expires_at=date.today() + timedelta(days=14),
            supplier_name="Acme",
        )
        assert LotTrackingRecord.objects.filter(item=item).count() == 1
        lot = LotTrackingRecord.objects.get()
        assert lot.lot_code == "LOT-1"
        assert lot.quantity_remaining == Decimal("10.000")

    def test_resolves_low_stock_alert_on_receive(self):
        r = _restaurant()
        item = create_inventory_item(
            restaurant=r, location=_location(r), ingredient=_ingredient(r),
            reorder_point=Decimal("20"), opening_quantity=Decimal("50"),
        )
        consume_stock(item=item, quantity=Decimal("40"))  # crosses reorder_point
        assert LowStockAlert.objects.filter(item=item, resolved_at__isnull=True).count() == 1
        receive_stock(item=item, quantity=Decimal("100"),
                      unit_cost=Decimal("0.10"))
        assert LowStockAlert.objects.filter(
            item=item, resolved_at__isnull=True,
        ).count() == 0


# -------------------- consume_stock --------------------

class TestConsumeStock:
    def test_consumes(self):
        r = _restaurant()
        item = create_inventory_item(
            restaurant=r, location=_location(r), ingredient=_ingredient(r),
            opening_quantity=Decimal("100"),
        )
        consume_stock(item=item, quantity=Decimal("30"), kind="usage")
        item.refresh_from_db()
        assert item.quantity_on_hand == Decimal("70.000")
        # txn quantity is negative
        txn = InventoryTransaction.objects.filter(kind="usage").first()
        assert txn.quantity == Decimal("-30.000")

    def test_insufficient_stock_rejected(self):
        r = _restaurant()
        item = create_inventory_item(
            restaurant=r, location=_location(r), ingredient=_ingredient(r),
            opening_quantity=Decimal("10"),
        )
        with pytest.raises(ValidationError) as exc:
            consume_stock(item=item, quantity=Decimal("50"))
        assert exc.value.code == "insufficient_stock"

    def test_invalid_kind_rejected(self):
        r = _restaurant()
        item = create_inventory_item(
            restaurant=r, location=_location(r), ingredient=_ingredient(r),
            opening_quantity=Decimal("10"),
        )
        with pytest.raises(ValidationError):
            consume_stock(item=item, quantity=Decimal("1"), kind="receive")

    def test_creates_low_stock_alert(self):
        r = _restaurant()
        item = create_inventory_item(
            restaurant=r, location=_location(r), ingredient=_ingredient(r),
            reorder_point=Decimal("20"), opening_quantity=Decimal("100"),
        )
        consume_stock(item=item, quantity=Decimal("85"))  # qty=15, below 20
        alerts = LowStockAlert.objects.filter(item=item, resolved_at__isnull=True)
        assert alerts.count() == 1
        # Consume more — should not double-fire while still below
        consume_stock(item=item, quantity=Decimal("5"))
        alerts = LowStockAlert.objects.filter(item=item, resolved_at__isnull=True)
        assert alerts.count() == 1

    def test_no_alert_when_reorder_point_zero(self):
        r = _restaurant()
        item = create_inventory_item(
            restaurant=r, location=_location(r), ingredient=_ingredient(r),
            opening_quantity=Decimal("10"),
        )
        consume_stock(item=item, quantity=Decimal("5"))
        assert LowStockAlert.objects.filter(item=item).count() == 0

    def test_decrements_lots_fefo(self):
        r = _restaurant()
        item = create_inventory_item(
            restaurant=r, location=_location(r), ingredient=_ingredient(r),
        )
        # Receive two lots with different expiry
        receive_stock(
            item=item, quantity=Decimal("50"), unit_cost=Decimal("0.10"),
            lot_code="A",
            expires_at=date.today() + timedelta(days=20),
        )
        receive_stock(
            item=item, quantity=Decimal("50"), unit_cost=Decimal("0.10"),
            lot_code="B",
            expires_at=date.today() + timedelta(days=5),  # expires sooner
        )
        consume_stock(item=item, quantity=Decimal("30"))
        # Lot B expires sooner → drained first
        lot_b = LotTrackingRecord.objects.get(lot_code="B")
        lot_a = LotTrackingRecord.objects.get(lot_code="A")
        assert lot_b.quantity_remaining == Decimal("20.000")
        assert lot_a.quantity_remaining == Decimal("50.000")

    def test_skips_recalled_lots(self):
        r = _restaurant()
        item = create_inventory_item(
            restaurant=r, location=_location(r), ingredient=_ingredient(r),
        )
        receive_stock(
            item=item, quantity=Decimal("50"), unit_cost=Decimal("0.10"),
            lot_code="A", expires_at=date.today() + timedelta(days=5),
        )
        receive_stock(
            item=item, quantity=Decimal("50"), unit_cost=Decimal("0.10"),
            lot_code="B", expires_at=date.today() + timedelta(days=20),
        )
        lot_a = LotTrackingRecord.objects.get(lot_code="A")
        mark_lot_recalled(lot=lot_a, reason="contamination")
        consume_stock(item=item, quantity=Decimal("10"))
        lot_b = LotTrackingRecord.objects.get(lot_code="B")
        # Should consume from B, not A
        assert lot_a.quantity_remaining == Decimal("50.000")
        assert lot_b.quantity_remaining == Decimal("40.000")


# -------------------- transfer_stock --------------------

class TestTransferStock:
    def test_transfer(self):
        r = _restaurant()
        ing = _ingredient(r)
        loc1 = _location(r, "Main")
        loc2 = _location(r, "Bar")
        a = create_inventory_item(
            restaurant=r, location=loc1, ingredient=ing,
            opening_quantity=Decimal("100"),
        )
        b = create_inventory_item(
            restaurant=r, location=loc2, ingredient=ing,
            opening_quantity=Decimal("0"),
        )
        out_txn, in_txn = transfer_stock(
            from_item=a, to_item=b, quantity=Decimal("30"),
        )
        a.refresh_from_db()
        b.refresh_from_db()
        assert a.quantity_on_hand == Decimal("70.000")
        assert b.quantity_on_hand == Decimal("30.000")
        assert out_txn.kind == "transfer_out"
        assert in_txn.kind == "transfer_in"

    def test_ingredient_mismatch_rejected(self):
        r = _restaurant()
        loc = _location(r)
        ing1 = _ingredient(r, name="A")
        ing2 = _ingredient(r, name="B")
        a = create_inventory_item(
            restaurant=r, location=loc, ingredient=ing1,
            opening_quantity=Decimal("10"),
        )
        b = create_inventory_item(
            restaurant=r, location=_location(r, "B"), ingredient=ing2,
        )
        with pytest.raises(ValidationError):
            transfer_stock(from_item=a, to_item=b, quantity=Decimal("1"))

    def test_same_location_rejected(self):
        r = _restaurant()
        loc = _location(r)
        ing = _ingredient(r)
        a = create_inventory_item(
            restaurant=r, location=loc, ingredient=ing,
            opening_quantity=Decimal("10"),
        )
        with pytest.raises(ValidationError):
            transfer_stock(from_item=a, to_item=a, quantity=Decimal("1"))


# -------------------- adjust_to_count --------------------

class TestAdjustToCount:
    def test_creates_adjustment_txn(self):
        r = _restaurant()
        item = create_inventory_item(
            restaurant=r, location=_location(r), ingredient=_ingredient(r),
            opening_quantity=Decimal("100"),
        )
        # We thought 100, found 95 → -5 adjustment
        txn = adjust_to_count(item=item, counted_quantity=Decimal("95"))
        item.refresh_from_db()
        assert item.quantity_on_hand == Decimal("95.000")
        assert txn.kind == "count_adjustment"
        assert txn.quantity == Decimal("-5.000")

    def test_zero_delta_no_txn(self):
        r = _restaurant()
        item = create_inventory_item(
            restaurant=r, location=_location(r), ingredient=_ingredient(r),
            opening_quantity=Decimal("100"),
        )
        result = adjust_to_count(item=item, counted_quantity=Decimal("100"))
        assert result is None


# -------------------- inventory count session --------------------

class TestCountSession:
    def test_full_lifecycle(self):
        r = _restaurant()
        loc = _location(r)
        ing1 = _ingredient(r, name="Onion", cost=Decimal("0.10"))
        ing2 = _ingredient(r, name="Garlic", cost=Decimal("0.20"))
        item1 = create_inventory_item(
            restaurant=r, location=loc, ingredient=ing1,
            opening_quantity=Decimal("100"), opening_cost=Decimal("0.10"),
        )
        item2 = create_inventory_item(
            restaurant=r, location=loc, ingredient=ing2,
            opening_quantity=Decimal("50"), opening_cost=Decimal("0.20"),
        )
        count = start_inventory_count(restaurant=r, location=loc, name="Aug 1 Count")
        assert count.lines.count() == 2
        assert count.total_value_before == Decimal("20.00")  # 100*0.10 + 50*0.20

        line1 = count.lines.get(inventory_item=item1)
        line2 = count.lines.get(inventory_item=item2)
        submit_count_line(line=line1, counted_quantity=Decimal("95"))
        submit_count_line(line=line2, counted_quantity=Decimal("52"))

        complete_inventory_count(count=count)
        item1.refresh_from_db()
        item2.refresh_from_db()
        assert item1.quantity_on_hand == Decimal("95.000")
        assert item2.quantity_on_hand == Decimal("52.000")
        count.refresh_from_db()
        assert count.status == "completed"

    def test_only_one_open_count_per_location(self):
        r = _restaurant()
        loc = _location(r)
        start_inventory_count(restaurant=r, location=loc, name="A")
        with pytest.raises(Conflict):
            start_inventory_count(restaurant=r, location=loc, name="B")

    def test_cancel_count(self):
        r = _restaurant()
        loc = _location(r)
        c = start_inventory_count(restaurant=r, location=loc, name="C")
        cancel_inventory_count(count=c)
        c.refresh_from_db()
        assert c.status == "cancelled"

    def test_complete_idempotent_blocked(self):
        r = _restaurant()
        loc = _location(r)
        c = start_inventory_count(restaurant=r, location=loc, name="C")
        complete_inventory_count(count=c)
        with pytest.raises(ValidationError):
            complete_inventory_count(count=c)

    def test_blank_count_name_rejected(self):
        r = _restaurant()
        with pytest.raises(ValidationError):
            start_inventory_count(restaurant=r, location=_location(r), name="  ")
