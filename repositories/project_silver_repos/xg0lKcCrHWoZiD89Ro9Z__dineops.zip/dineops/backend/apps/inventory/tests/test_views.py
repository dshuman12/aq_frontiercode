from decimal import Decimal

import pytest
from rest_framework.test import APIClient

from apps.accounts.models import User
from apps.ingredients.models import Ingredient
from apps.inventory.services import create_inventory_item
from apps.locations.models import Location
from apps.restaurants.models import Restaurant, RestaurantMember


pytestmark = pytest.mark.django_db


@pytest.fixture
def setup():
    owner = User.objects.create_user(email="o@x.com", password="pwpwpwpw")
    rest = Restaurant.objects.create(name="R", slug="r", owner=owner)
    loc = Location.objects.create(
        restaurant=rest, name="Main", slug="main", accepts_dine_in=True,
    )
    RestaurantMember.objects.create(
        restaurant=rest, user=owner, roles=["owner"], status="active",
    )
    server = User.objects.create_user(email="s@x.com", password="pwpwpwpw")
    RestaurantMember.objects.create(
        restaurant=rest, user=server, roles=["server"], status="active",
    )
    ing = Ingredient.objects.create(restaurant=rest, name="X", base_unit="g")
    item = create_inventory_item(
        restaurant=rest, location=loc, ingredient=ing,
        opening_quantity=Decimal("100"), opening_cost=Decimal("0.05"),
        reorder_point=Decimal("20"), reorder_quantity=Decimal("80"),
    )
    return {"rest": rest, "loc": loc, "ing": ing, "item": item,
            "owner": owner, "server": server}


def _login(u):
    c = APIClient()
    c.force_authenticate(user=u)
    return c


class TestInventoryEndpoints:
    def test_list(self, setup):
        c = _login(setup["owner"])
        resp = c.get(f"/api/inventory/{setup['rest'].id}/items/")
        assert resp.status_code == 200
        assert len(resp.data["results"]) == 1

    def test_low_only_filter(self, setup):
        c = _login(setup["owner"])
        # Currently 100 on hand, reorder 20 → not low
        resp = c.get(f"/api/inventory/{setup['rest'].id}/items/?low_only=true")
        assert len(resp.data["results"]) == 0

    def test_receive_stock(self, setup):
        c = _login(setup["owner"])
        resp = c.post(
            f"/api/inventory/{setup['rest'].id}/items/{setup['item'].id}/receive/",
            {"quantity": "50", "unit_cost": "0.05",
             "reference": "test"},
            format="json",
        )
        assert resp.status_code == 201
        setup["item"].refresh_from_db()
        assert setup["item"].quantity_on_hand == Decimal("150.000")

    def test_consume_stock(self, setup):
        c = _login(setup["owner"])
        resp = c.post(
            f"/api/inventory/{setup['rest'].id}/items/{setup['item'].id}/consume/",
            {"quantity": "30", "kind": "usage"},
            format="json",
        )
        assert resp.status_code == 201
        setup["item"].refresh_from_db()
        assert setup["item"].quantity_on_hand == Decimal("70.000")

    def test_server_cannot_receive(self, setup):
        c = _login(setup["server"])
        resp = c.post(
            f"/api/inventory/{setup['rest'].id}/items/{setup['item'].id}/receive/",
            {"quantity": "50", "unit_cost": "0.05"},
            format="json",
        )
        assert resp.status_code == 403

    def test_low_stock_alerts_endpoint(self, setup):
        # Drive item below reorder
        c = _login(setup["owner"])
        c.post(
            f"/api/inventory/{setup['rest'].id}/items/{setup['item'].id}/consume/",
            {"quantity": "85", "kind": "usage"},
            format="json",
        )
        resp = c.get(f"/api/inventory/{setup['rest'].id}/alerts/low-stock/")
        assert resp.status_code == 200
        assert len(resp.data["results"]) >= 1
