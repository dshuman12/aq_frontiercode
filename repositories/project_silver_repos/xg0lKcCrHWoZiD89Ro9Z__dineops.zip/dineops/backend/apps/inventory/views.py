from __future__ import annotations

from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common.exceptions import NotFound, PermissionDenied
from apps.ingredients.models import Ingredient
from apps.locations.models import Location
from apps.restaurants.models import Restaurant, RestaurantMember

from . import selectors, services
from .models import (
    InventoryCount, InventoryCountItem, InventoryItem, InventoryTransaction,
    LotTrackingRecord, LowStockAlert,
)
from .serializers import (
    ConsumeStockSerializer, CreateInventoryItemSerializer,
    InventoryCountItemSerializer, InventoryCountSerializer,
    InventoryItemSerializer, InventoryTransactionSerializer,
    LotTrackingSerializer, LowStockAlertSerializer,
    ReceiveStockSerializer, StartCountSerializer,
    SubmitCountLineSerializer, TransferStockSerializer,
)


def _require_member(user, restaurant_id) -> RestaurantMember:
    m = RestaurantMember.objects.filter(
        restaurant_id=restaurant_id, user=user, status="active",
    ).first()
    if not m:
        raise PermissionDenied("not_a_member")
    return m


def _can_manage_inventory(roles):
    return any(r in (
        "owner", "general_manager", "assistant_manager",
        "chef", "inventory_manager",
    ) for r in roles or [])


# -------------------- Items --------------------

class InventoryItemListCreate(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        _require_member(request.user, restaurant_id)
        qs = InventoryItem.objects.filter(
            restaurant_id=restaurant_id, is_active=True,
        ).select_related("ingredient", "location").order_by("ingredient__name")
        if (loc := request.GET.get("location_id")):
            qs = qs.filter(location_id=loc)
        if request.GET.get("low_only") == "true":
            from django.db.models import F
            qs = qs.filter(reorder_point__gt=0,
                           quantity_on_hand__lte=F("reorder_point"))
        return Response({"results": InventoryItemSerializer(qs[:1000], many=True).data})

    def post(self, request, restaurant_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_manage_inventory(member.roles):
            raise PermissionDenied()
        s = CreateInventoryItemSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        rest = Restaurant.objects.get(id=restaurant_id)
        loc = Location.objects.filter(
            id=s.validated_data["location_id"], restaurant_id=restaurant_id,
        ).first()
        ing = Ingredient.objects.filter(
            id=s.validated_data["ingredient_id"], restaurant_id=restaurant_id,
        ).first()
        if not loc or not ing:
            raise NotFound()
        item = services.create_inventory_item(
            restaurant=rest, location=loc, ingredient=ing,
            par_level=s.validated_data["par_level"],
            reorder_point=s.validated_data["reorder_point"],
            reorder_quantity=s.validated_data["reorder_quantity"],
            opening_quantity=s.validated_data["opening_quantity"],
            opening_cost=s.validated_data["opening_cost"],
        )
        return Response({"item": InventoryItemSerializer(item).data}, status=201)


class InventoryItemDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id, item_id):
        _require_member(request.user, restaurant_id)
        item = InventoryItem.objects.filter(
            id=item_id, restaurant_id=restaurant_id,
        ).select_related("ingredient", "location").first()
        if not item:
            raise NotFound()
        return Response({"item": InventoryItemSerializer(item).data})

    def patch(self, request, restaurant_id, item_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_manage_inventory(member.roles):
            raise PermissionDenied()
        item = InventoryItem.objects.filter(
            id=item_id, restaurant_id=restaurant_id,
        ).first()
        if not item:
            raise NotFound()
        for k in ("par_level", "reorder_point", "reorder_quantity", "is_active"):
            if k in request.data:
                setattr(item, k, request.data[k])
        item.save()
        return Response({"item": InventoryItemSerializer(item).data})


class ReceiveStockView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, item_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_manage_inventory(member.roles):
            raise PermissionDenied()
        item = InventoryItem.objects.filter(
            id=item_id, restaurant_id=restaurant_id,
        ).first()
        if not item:
            raise NotFound()
        s = ReceiveStockSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        txn = services.receive_stock(
            item=item, actor=request.user, **s.validated_data,
        )
        return Response({"transaction": InventoryTransactionSerializer(txn).data},
                        status=201)


class ConsumeStockView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, item_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_manage_inventory(member.roles):
            raise PermissionDenied()
        item = InventoryItem.objects.filter(
            id=item_id, restaurant_id=restaurant_id,
        ).first()
        if not item:
            raise NotFound()
        s = ConsumeStockSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        txn = services.consume_stock(
            item=item, actor=request.user, **s.validated_data,
        )
        return Response({"transaction": InventoryTransactionSerializer(txn).data},
                        status=201)


class TransferStockView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, item_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_manage_inventory(member.roles):
            raise PermissionDenied()
        from_item = InventoryItem.objects.filter(
            id=item_id, restaurant_id=restaurant_id,
        ).first()
        if not from_item:
            raise NotFound()
        s = TransferStockSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        to_item = InventoryItem.objects.filter(
            id=s.validated_data["to_item_id"], restaurant_id=restaurant_id,
        ).first()
        if not to_item:
            raise NotFound("to_item_not_found")
        out_txn, in_txn = services.transfer_stock(
            from_item=from_item, to_item=to_item,
            quantity=s.validated_data["quantity"],
            reference=s.validated_data.get("reference", ""),
            actor=request.user,
        )
        return Response({
            "out": InventoryTransactionSerializer(out_txn).data,
            "in": InventoryTransactionSerializer(in_txn).data,
        }, status=201)


# -------------------- Counts --------------------

class CountListCreate(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        _require_member(request.user, restaurant_id)
        qs = InventoryCount.objects.filter(
            restaurant_id=restaurant_id,
        ).select_related("location").order_by("-created_at")[:50]
        return Response({"results": InventoryCountSerializer(qs, many=True).data})

    def post(self, request, restaurant_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_manage_inventory(member.roles):
            raise PermissionDenied()
        s = StartCountSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        rest = Restaurant.objects.get(id=restaurant_id)
        loc = Location.objects.filter(
            id=s.validated_data["location_id"], restaurant_id=restaurant_id,
        ).first()
        if not loc:
            raise NotFound()
        count = services.start_inventory_count(
            restaurant=rest, location=loc,
            name=s.validated_data["name"],
            actor=request.user,
        )
        return Response({"count": InventoryCountSerializer(count).data}, status=201)


class CountDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id, count_id):
        _require_member(request.user, restaurant_id)
        count = InventoryCount.objects.filter(
            id=count_id, restaurant_id=restaurant_id,
        ).first()
        if not count:
            raise NotFound()
        lines = count.lines.select_related(
            "inventory_item__ingredient",
        ).all()
        return Response({
            "count": InventoryCountSerializer(count).data,
            "lines": InventoryCountItemSerializer(lines, many=True).data,
        })


class SubmitCountLine(APIView):
    permission_classes = (IsAuthenticated,)

    def patch(self, request, restaurant_id, line_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_manage_inventory(member.roles):
            raise PermissionDenied()
        line = InventoryCountItem.objects.filter(
            id=line_id, count__restaurant_id=restaurant_id,
        ).select_related("inventory_item").first()
        if not line:
            raise NotFound()
        s = SubmitCountLineSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        services.submit_count_line(
            line=line, counted_by=request.user, **s.validated_data,
        )
        return Response({"line": InventoryCountItemSerializer(line).data})


class CompleteCount(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, count_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_manage_inventory(member.roles):
            raise PermissionDenied()
        count = InventoryCount.objects.filter(
            id=count_id, restaurant_id=restaurant_id,
        ).first()
        if not count:
            raise NotFound()
        services.complete_inventory_count(count=count, actor=request.user)
        return Response({"count": InventoryCountSerializer(count).data})


class CancelCount(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, count_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_manage_inventory(member.roles):
            raise PermissionDenied()
        count = InventoryCount.objects.filter(
            id=count_id, restaurant_id=restaurant_id,
        ).first()
        if not count:
            raise NotFound()
        services.cancel_inventory_count(count=count)
        return Response({"count": InventoryCountSerializer(count).data})


# -------------------- Reports --------------------

class StockValueView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id, location_id):
        _require_member(request.user, restaurant_id)
        value = selectors.stock_value_by_location(restaurant_id, location_id)
        return Response({"location_id": str(location_id),
                         "total_value": str(value)})


class LowStockListView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        _require_member(request.user, restaurant_id)
        location_id = request.GET.get("location_id")
        items = selectors.low_stock_items(restaurant_id, location_id)
        return Response({"results": InventoryItemSerializer(items, many=True).data})


class ExpiringLotsView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        _require_member(request.user, restaurant_id)
        within = int(request.GET.get("within_days", "7"))
        lots = selectors.expiring_lots(restaurant_id, within_days=within)
        return Response({"results": LotTrackingSerializer(lots, many=True).data})


class TransactionListView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id, item_id):
        _require_member(request.user, restaurant_id)
        item = InventoryItem.objects.filter(
            id=item_id, restaurant_id=restaurant_id,
        ).first()
        if not item:
            raise NotFound()
        txns = item.transactions.all()[:200]
        return Response({"results": InventoryTransactionSerializer(txns, many=True).data})


class LowStockAlertListView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        _require_member(request.user, restaurant_id)
        qs = LowStockAlert.objects.filter(
            item__restaurant_id=restaurant_id,
            resolved_at__isnull=True,
        ).select_related("item__ingredient", "item__location").order_by("-triggered_at")
        return Response({"results": LowStockAlertSerializer(qs, many=True).data})
