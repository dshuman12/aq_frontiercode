from __future__ import annotations

from datetime import date, timedelta
from decimal import Decimal

from celery import shared_task
from django.db.models import F
from django.utils import timezone

from .models import InventoryItem, LotTrackingRecord, LowStockAlert


@shared_task(name="inventory.scan_low_stock")
def scan_low_stock() -> dict:
    """Open low-stock alerts for any item that has crossed reorder_point.
    Run on a 5-minute schedule. Idempotent — only opens an alert if none is
    already open."""

    candidates = InventoryItem.objects.filter(
        is_active=True, reorder_point__gt=0,
        quantity_on_hand__lte=F("reorder_point"),
    )
    opened = 0
    for item in candidates:
        already_open = LowStockAlert.objects.filter(
            item=item, resolved_at__isnull=True,
        ).exists()
        if not already_open:
            LowStockAlert.objects.create(
                item=item,
                triggered_quantity=item.quantity_on_hand,
                reorder_point_at_alert=item.reorder_point,
            )
            opened += 1
    return {"scanned": candidates.count(), "opened": opened}


@shared_task(name="inventory.notify_low_stock")
def notify_low_stock_alerts() -> dict:
    """Fan out open low-stock alerts via the notifications app. Run every
    15 minutes."""
    from apps.notifications.services import fan_out_low_stock_alert

    pending = LowStockAlert.objects.filter(
        resolved_at__isnull=True, notified_at__isnull=True,
    ).select_related(
        "item__ingredient", "item__location", "item__restaurant",
    )
    sent = 0
    for alert in pending:
        fan_out_low_stock_alert(alert)
        alert.notified_at = timezone.now()
        alert.save(update_fields=["notified_at"])
        sent += 1
    return {"notified": sent}


@shared_task(name="inventory.scan_expiring_lots")
def scan_expiring_lots(within_days: int = 3) -> dict:
    """Find lots expiring within `within_days` and emit a warning. Run nightly."""
    cutoff = date.today() + timedelta(days=within_days)
    lots = LotTrackingRecord.objects.filter(
        quantity_remaining__gt=0,
        is_recalled=False,
        expires_at__lte=cutoff,
    ).select_related("item__ingredient", "item__location")
    for lot in lots:
        item = lot.item
        # stub: real impl would push into notifications
        print(
            f"EXPIRING LOT: {lot.lot_code} ({item.ingredient.name} @ "
            f"{item.location.name}) — expires {lot.expires_at}, "
            f"{lot.quantity_remaining} remaining"
        )
    return {"flagged": lots.count()}


@shared_task(name="inventory.expire_zeroed_lots")
def expire_zeroed_lots() -> dict:
    """Lots whose quantity_remaining hit 0 a long time ago can be archived.
    For now we just no-op them — kept for future cleanup."""
    return {"archived": 0}
