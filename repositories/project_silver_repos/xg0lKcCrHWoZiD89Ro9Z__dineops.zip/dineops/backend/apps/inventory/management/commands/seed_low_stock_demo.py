"""Useful for screencasts: knock down a few inventory items below their
reorder point so the low-stock alert UI lights up."""
from __future__ import annotations

from decimal import Decimal

from django.core.management.base import BaseCommand

from apps.inventory.models import InventoryItem
from apps.inventory.services import consume_stock


class Command(BaseCommand):
    help = "Drive a few items below reorder point for demo purposes."

    def add_arguments(self, parser):
        parser.add_argument("--restaurant", required=True)
        parser.add_argument("--count", type=int, default=3)

    def handle(self, *args, restaurant, count, **options):
        candidates = (
            InventoryItem.objects.filter(
                restaurant__slug=restaurant,
                is_active=True,
                reorder_point__gt=0,
            )
            .exclude(quantity_on_hand__lte=Decimal("0"))
            [:count]
        )
        knocked = 0
        for item in candidates:
            target = item.reorder_point - Decimal("1")
            qty = item.quantity_on_hand - target
            if qty <= 0:
                continue
            consume_stock(item=item, quantity=qty, kind="usage",
                          reference="demo:low-stock-seed")
            knocked += 1
        self.stdout.write(self.style.SUCCESS(
            f"Knocked {knocked} items below reorder point.",
        ))
