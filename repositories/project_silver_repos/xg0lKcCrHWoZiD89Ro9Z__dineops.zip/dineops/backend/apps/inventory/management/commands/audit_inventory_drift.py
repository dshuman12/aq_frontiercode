"""Compare materialized `quantity_on_hand` to the integral of all
`InventoryTransaction` rows for each item. Reports any drift.

Run after suspected data corruption or before a major migration."""
from __future__ import annotations

from decimal import Decimal

from django.core.management.base import BaseCommand
from django.db.models import Sum

from apps.inventory.models import InventoryItem, InventoryTransaction


class Command(BaseCommand):
    help = "Audit inventory drift between materialized qty and txn integral."

    def add_arguments(self, parser):
        parser.add_argument("--restaurant", help="Slug to scope to.")
        parser.add_argument("--threshold", type=str, default="0.001",
                            help="Drift below this value is treated as zero.")

    def handle(self, *args, restaurant=None, threshold="0.001", **options):
        threshold_d = Decimal(threshold)
        qs = InventoryItem.objects.filter(is_active=True)
        if restaurant:
            qs = qs.filter(restaurant__slug=restaurant)

        drift_count = 0
        for item in qs.select_related("ingredient", "location"):
            integral = (
                InventoryTransaction.objects
                .filter(item=item)
                .aggregate(total=Sum("quantity"))["total"] or Decimal("0")
            )
            drift = item.quantity_on_hand - integral
            if abs(drift) > threshold_d:
                drift_count += 1
                self.stderr.write(
                    f"DRIFT: {item.location.name} / {item.ingredient.name}: "
                    f"materialized={item.quantity_on_hand} "
                    f"integral={integral} "
                    f"drift={drift}",
                )
        self.stdout.write(self.style.SUCCESS(
            f"Audit complete. {drift_count} items with drift > {threshold_d}.",
        ))
