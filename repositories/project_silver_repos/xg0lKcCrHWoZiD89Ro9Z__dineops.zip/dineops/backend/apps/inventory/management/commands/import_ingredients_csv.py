"""Bulk-import ingredients from a CSV. Useful at customer onboarding."""
from __future__ import annotations

import csv
from decimal import Decimal

from django.core.management.base import BaseCommand
from django.db import transaction

from apps.ingredients.models import Ingredient
from apps.restaurants.models import Restaurant


class Command(BaseCommand):
    help = "Bulk-import ingredients from a CSV (name, base_unit, cost, yield)."

    def add_arguments(self, parser):
        parser.add_argument("--restaurant", required=True)
        parser.add_argument("--file", required=True)

    @transaction.atomic
    def handle(self, *args, restaurant, file, **options):
        rest = Restaurant.objects.get(slug=restaurant)
        created = 0
        with open(file) as f:
            reader = csv.DictReader(f)
            for row in reader:
                _, was_created = Ingredient.objects.get_or_create(
                    restaurant=rest, name=row["name"].strip(),
                    defaults={
                        "base_unit": row.get("base_unit", "each"),
                        "cost_per_unit": Decimal(row.get("cost", "0")),
                        "yield_factor": Decimal(row.get("yield", "1")),
                        "sku": row.get("sku", ""),
                    },
                )
                if was_created:
                    created += 1
        self.stdout.write(self.style.SUCCESS(
            f"Created {created} ingredients (skipped existing).",
        ))
