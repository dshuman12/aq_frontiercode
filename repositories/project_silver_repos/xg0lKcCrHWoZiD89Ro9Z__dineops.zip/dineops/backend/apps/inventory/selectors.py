from __future__ import annotations

from decimal import Decimal
from typing import Iterable

from django.db.models import F, Sum

from .models import InventoryItem, InventoryTransaction


def stock_value_by_location(restaurant_id, location_id) -> Decimal:
    """Sum of (quantity_on_hand * average_cost) for active items at a location."""
    items = InventoryItem.objects.filter(
        restaurant_id=restaurant_id, location_id=location_id, is_active=True,
    )
    total = Decimal("0")
    for it in items:
        total += it.total_value
    return total.quantize(Decimal("0.01"))


def low_stock_items(restaurant_id, location_id=None) -> list[InventoryItem]:
    qs = InventoryItem.objects.filter(
        restaurant_id=restaurant_id, is_active=True,
        reorder_point__gt=0,
        quantity_on_hand__lte=F("reorder_point"),
    ).select_related("ingredient", "location")
    if location_id:
        qs = qs.filter(location_id=location_id)
    return list(qs.order_by("ingredient__name"))


def expiring_lots(restaurant_id, *, within_days: int = 7) -> list:
    from datetime import date, timedelta
    from .models import LotTrackingRecord
    cutoff = date.today() + timedelta(days=within_days)
    return list(
        LotTrackingRecord.objects.filter(
            item__restaurant_id=restaurant_id,
            quantity_remaining__gt=0,
            is_recalled=False,
            expires_at__lte=cutoff,
        ).select_related("item__ingredient", "item__location")
        .order_by("expires_at")
    )


def usage_summary(restaurant_id, *, location_id=None,
                  start, end) -> list[dict]:
    qs = InventoryTransaction.objects.filter(
        item__restaurant_id=restaurant_id,
        kind__in=["usage", "waste"],
        occurred_at__gte=start, occurred_at__lte=end,
    )
    if location_id:
        qs = qs.filter(item__location_id=location_id)
    grouped = (
        qs.values("item__ingredient__name", "kind")
          .annotate(total_qty=Sum("quantity"), total_value=Sum(
              F("quantity") * F("unit_cost"),
          ))
          .order_by("item__ingredient__name", "kind")
    )
    return list(grouped)
