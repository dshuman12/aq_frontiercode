from __future__ import annotations

import uuid
from decimal import Decimal

from django.conf import settings
from django.db import models

from apps.common.models import TimeStampedModel


class InventoryItem(TimeStampedModel):
    """The stock-on-hand record for an Ingredient, scoped to a Location.

    Each restaurant location has its own InventoryItem rows. Stock movements
    are recorded as `InventoryTransaction` rows; this row carries the rolling
    quantity-on-hand and the most-recent cost basis (weighted average).
    """

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant = models.ForeignKey(
        "restaurants.Restaurant", on_delete=models.CASCADE,
        related_name="inventory_items",
    )
    location = models.ForeignKey(
        "locations.Location", on_delete=models.CASCADE,
        related_name="inventory_items",
    )
    ingredient = models.ForeignKey(
        "ingredients.Ingredient", on_delete=models.PROTECT,
        related_name="inventory_records",
    )

    quantity_on_hand = models.DecimalField(
        max_digits=14, decimal_places=3, default=0,
        help_text="In ingredient.base_unit.",
    )
    average_cost = models.DecimalField(
        max_digits=12, decimal_places=4, default=0,
        help_text="Weighted-average cost per base_unit.",
    )

    par_level = models.DecimalField(max_digits=14, decimal_places=3, default=0)
    reorder_point = models.DecimalField(max_digits=14, decimal_places=3, default=0)
    reorder_quantity = models.DecimalField(max_digits=14, decimal_places=3, default=0)

    last_counted_at = models.DateTimeField(null=True, blank=True)
    last_received_at = models.DateTimeField(null=True, blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["location", "ingredient"], name="unique_inventory_item",
            ),
        ]
        indexes = [
            models.Index(fields=["restaurant", "is_active"]),
            models.Index(fields=["location", "ingredient"]),
        ]

    def __str__(self) -> str:
        return f"{self.ingredient.name} @ {self.location.name}: {self.quantity_on_hand}"

    @property
    def total_value(self) -> Decimal:
        return (self.quantity_on_hand * self.average_cost).quantize(Decimal("0.01"))

    @property
    def is_low(self) -> bool:
        return self.is_active and self.quantity_on_hand <= self.reorder_point


class InventoryTransaction(TimeStampedModel):
    """Every change to stock: receipts, prep usage, waste, count adjustments,
    transfers between locations. Append-only; never edited."""

    KIND_CHOICES = [
        ("receive", "Receive"),
        ("usage", "Usage"),
        ("waste", "Waste"),
        ("transfer_in", "Transfer in"),
        ("transfer_out", "Transfer out"),
        ("count_adjustment", "Count adjustment"),
        ("opening", "Opening balance"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    item = models.ForeignKey(
        InventoryItem, on_delete=models.CASCADE,
        related_name="transactions",
    )
    kind = models.CharField(max_length=20, choices=KIND_CHOICES)
    quantity = models.DecimalField(
        max_digits=14, decimal_places=3,
        help_text="Signed, in item.ingredient.base_unit. Positive = inflow.",
    )
    unit_cost = models.DecimalField(
        max_digits=12, decimal_places=4, default=0,
        help_text="Cost per base_unit at the time of the movement.",
    )
    reference = models.CharField(
        max_length=120, blank=True,
        help_text="PO number / count session / waste reason.",
    )
    notes = models.TextField(blank=True)
    actor = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="+",
    )
    occurred_at = models.DateTimeField()

    class Meta:
        ordering = ["-occurred_at", "-id"]
        indexes = [
            models.Index(fields=["item", "-occurred_at"]),
            models.Index(fields=["kind", "-occurred_at"]),
        ]


class InventoryCount(TimeStampedModel):
    """A physical inventory count session — usually weekly."""

    STATUS_CHOICES = [
        ("draft", "Draft"),
        ("in_progress", "In progress"),
        ("completed", "Completed"),
        ("cancelled", "Cancelled"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant = models.ForeignKey(
        "restaurants.Restaurant", on_delete=models.CASCADE,
        related_name="inventory_counts",
    )
    location = models.ForeignKey(
        "locations.Location", on_delete=models.CASCADE,
        related_name="inventory_counts",
    )
    name = models.CharField(max_length=160)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="draft")

    started_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="+",
    )
    started_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)

    total_value_before = models.DecimalField(
        max_digits=14, decimal_places=2, default=0,
        help_text="Snapshot of total inventory value before count adjustments.",
    )
    total_value_after = models.DecimalField(
        max_digits=14, decimal_places=2, default=0,
    )
    variance_value = models.DecimalField(
        max_digits=14, decimal_places=2, default=0,
        help_text="total_value_after - total_value_before",
    )
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["restaurant", "status"]),
        ]

    def __str__(self) -> str:
        return f"{self.name} ({self.status})"


class InventoryCountItem(TimeStampedModel):
    """One line of a count session — physical count of one ingredient."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    count = models.ForeignKey(
        InventoryCount, on_delete=models.CASCADE,
        related_name="lines",
    )
    inventory_item = models.ForeignKey(
        InventoryItem, on_delete=models.CASCADE,
        related_name="count_lines",
    )
    expected_quantity = models.DecimalField(max_digits=14, decimal_places=3)
    counted_quantity = models.DecimalField(
        max_digits=14, decimal_places=3, null=True, blank=True,
    )
    variance = models.DecimalField(
        max_digits=14, decimal_places=3, default=0,
    )
    variance_value = models.DecimalField(
        max_digits=12, decimal_places=2, default=0,
    )
    counted_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="+",
    )
    counted_at = models.DateTimeField(null=True, blank=True)
    notes = models.CharField(max_length=200, blank=True)

    class Meta:
        ordering = ["inventory_item__ingredient__name"]
        constraints = [
            models.UniqueConstraint(
                fields=["count", "inventory_item"], name="unique_count_line",
            ),
        ]


class LotTrackingRecord(TimeStampedModel):
    """For ingredients that need lot/batch traceability (meat, seafood, dairy).
    Each receipt creates a lot; usage and waste decrement specific lots.
    """

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    item = models.ForeignKey(
        InventoryItem, on_delete=models.CASCADE,
        related_name="lots",
    )
    lot_code = models.CharField(max_length=80, db_index=True)
    received_at = models.DateTimeField()
    expires_at = models.DateField(null=True, blank=True)
    quantity_received = models.DecimalField(max_digits=14, decimal_places=3)
    quantity_remaining = models.DecimalField(max_digits=14, decimal_places=3)
    unit_cost = models.DecimalField(max_digits=12, decimal_places=4, default=0)

    supplier_name = models.CharField(max_length=160, blank=True)
    supplier_lot_code = models.CharField(max_length=80, blank=True)
    notes = models.TextField(blank=True)
    is_recalled = models.BooleanField(default=False)

    class Meta:
        ordering = ["expires_at", "received_at"]
        indexes = [
            models.Index(fields=["item", "expires_at"]),
            models.Index(fields=["lot_code"]),
        ]


class LowStockAlert(TimeStampedModel):
    """Record of when an item dropped below reorder_point. Used to throttle
    notifications (don't email twice for the same alert)."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    item = models.ForeignKey(
        InventoryItem, on_delete=models.CASCADE,
        related_name="low_stock_alerts",
    )
    triggered_at = models.DateTimeField(auto_now_add=True)
    triggered_quantity = models.DecimalField(max_digits=14, decimal_places=3)
    reorder_point_at_alert = models.DecimalField(max_digits=14, decimal_places=3)
    resolved_at = models.DateTimeField(null=True, blank=True)
    notified_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-triggered_at"]
        indexes = [
            models.Index(fields=["item", "resolved_at"]),
        ]
