from django.contrib import admin

from .models import (
    InventoryCount, InventoryCountItem, InventoryItem, InventoryTransaction,
    LotTrackingRecord, LowStockAlert,
)


@admin.register(InventoryItem)
class InventoryItemAdmin(admin.ModelAdmin):
    list_display = ("ingredient", "location", "quantity_on_hand",
                    "average_cost", "reorder_point", "is_active", "is_low")
    list_filter = ("is_active", "location")
    search_fields = ("ingredient__name",)
    readonly_fields = ("average_cost", "last_received_at", "last_counted_at")


@admin.register(InventoryTransaction)
class InventoryTransactionAdmin(admin.ModelAdmin):
    list_display = ("item", "kind", "quantity", "unit_cost",
                    "reference", "occurred_at", "actor")
    list_filter = ("kind", "occurred_at")
    search_fields = ("reference",)


@admin.register(InventoryCount)
class InventoryCountAdmin(admin.ModelAdmin):
    list_display = ("name", "location", "status",
                    "started_at", "completed_at",
                    "total_value_before", "total_value_after",
                    "variance_value")
    list_filter = ("status", "location")


@admin.register(LotTrackingRecord)
class LotTrackingAdmin(admin.ModelAdmin):
    list_display = ("lot_code", "item", "received_at", "expires_at",
                    "quantity_remaining", "is_recalled")
    list_filter = ("is_recalled",)
    search_fields = ("lot_code", "supplier_lot_code")


@admin.register(LowStockAlert)
class LowStockAlertAdmin(admin.ModelAdmin):
    list_display = ("item", "triggered_at", "triggered_quantity",
                    "reorder_point_at_alert", "resolved_at", "notified_at")


admin.site.register(InventoryCountItem)
