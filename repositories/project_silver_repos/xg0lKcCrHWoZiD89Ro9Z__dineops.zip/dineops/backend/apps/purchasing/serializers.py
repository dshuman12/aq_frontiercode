from __future__ import annotations

from rest_framework import serializers

from .models import PurchaseOrder, PurchaseOrderEvent, PurchaseOrderLine


class POLineSerializer(serializers.ModelSerializer):
    ingredient_name = serializers.CharField(
        source="vendor_ingredient.ingredient.name", read_only=True,
    )
    pack_size = serializers.CharField(
        source="vendor_ingredient.pack_size", read_only=True,
    )

    class Meta:
        model = PurchaseOrderLine
        fields = [
            "id", "purchase_order", "vendor_ingredient",
            "ingredient_name", "pack_size",
            "description",
            "quantity_ordered", "unit_price", "line_total",
            "quantity_received", "received_unit_price",
            "notes",
        ]
        read_only_fields = ["id", "line_total"]


class POSerializer(serializers.ModelSerializer):
    vendor_name = serializers.CharField(source="vendor.name", read_only=True)
    location_name = serializers.CharField(source="location.name", read_only=True)
    line_count = serializers.IntegerField(source="lines.count", read_only=True)

    class Meta:
        model = PurchaseOrder
        fields = [
            "id", "restaurant", "vendor", "vendor_name",
            "location", "location_name",
            "po_number", "status",
            "expected_delivery_date", "submitted_at", "submitted_by",
            "received_at", "received_by",
            "subtotal", "tax_amount", "shipping_amount", "discount_amount",
            "total_amount", "currency",
            "delivery_notes", "internal_notes", "vendor_invoice_number",
            "line_count",
        ]
        read_only_fields = [
            "id", "po_number", "submitted_at", "submitted_by",
            "received_at", "received_by",
            "subtotal", "total_amount",
        ]


class PODetailSerializer(POSerializer):
    lines = POLineSerializer(many=True, read_only=True)

    class Meta(POSerializer.Meta):
        fields = POSerializer.Meta.fields + ["lines"]


class CreateDraftPOSerializer(serializers.Serializer):
    location_id = serializers.UUIDField()
    vendor_id = serializers.UUIDField()
    expected_delivery_date = serializers.DateField(required=False, allow_null=True)


class AddLineSerializer(serializers.Serializer):
    vendor_ingredient_id = serializers.UUIDField()
    quantity = serializers.DecimalField(max_digits=12, decimal_places=3)
    unit_price = serializers.DecimalField(
        max_digits=10, decimal_places=2, required=False, allow_null=True,
    )
    description = serializers.CharField(required=False, allow_blank=True)


class ReceiveLineSerializer(serializers.Serializer):
    quantity_received = serializers.DecimalField(max_digits=12, decimal_places=3)
    actual_unit_price = serializers.DecimalField(
        max_digits=10, decimal_places=2, required=False, allow_null=True,
    )
    lot_code = serializers.CharField(required=False, allow_blank=True)
    expires_at = serializers.DateField(required=False, allow_null=True)


class POEventSerializer(serializers.ModelSerializer):
    actor_email = serializers.CharField(source="actor.email", read_only=True)

    class Meta:
        model = PurchaseOrderEvent
        fields = ["id", "purchase_order", "actor", "actor_email",
                  "kind", "payload", "created_at"]
