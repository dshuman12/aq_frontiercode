from __future__ import annotations

from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common.exceptions import NotFound, PermissionDenied
from apps.locations.models import Location
from apps.restaurants.models import Restaurant, RestaurantMember
from apps.vendors.models import Vendor, VendorIngredient

from . import services
from .models import PurchaseOrder, PurchaseOrderLine
from .serializers import (
    AddLineSerializer, CreateDraftPOSerializer, PODetailSerializer,
    POEventSerializer, POLineSerializer, POSerializer,
    ReceiveLineSerializer,
)


def _require_member(user, restaurant_id):
    m = RestaurantMember.objects.filter(
        restaurant_id=restaurant_id, user=user, status="active",
    ).first()
    if not m:
        raise PermissionDenied("not_a_member")
    return m


def _can_purchase(roles):
    return any(r in (
        "owner", "general_manager", "assistant_manager",
        "chef", "inventory_manager", "accountant",
    ) for r in roles or [])


class POListCreate(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        _require_member(request.user, restaurant_id)
        qs = PurchaseOrder.objects.filter(
            restaurant_id=restaurant_id,
        ).select_related("vendor", "location").order_by("-created_at")
        if (status_f := request.GET.get("status")):
            qs = qs.filter(status=status_f)
        if (vendor := request.GET.get("vendor_id")):
            qs = qs.filter(vendor_id=vendor)
        return Response({"results": POSerializer(qs[:200], many=True).data})

    def post(self, request, restaurant_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_purchase(member.roles):
            raise PermissionDenied()
        s = CreateDraftPOSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        rest = Restaurant.objects.get(id=restaurant_id)
        loc = Location.objects.filter(
            id=s.validated_data["location_id"], restaurant_id=restaurant_id,
        ).first()
        vendor = Vendor.objects.filter(
            id=s.validated_data["vendor_id"], restaurant_id=restaurant_id,
        ).first()
        if not loc or not vendor:
            raise NotFound()
        po = services.create_draft_po(
            restaurant=rest, location=loc, vendor=vendor,
            actor=request.user,
            expected_delivery_date=s.validated_data.get("expected_delivery_date"),
        )
        return Response({"po": POSerializer(po).data}, status=201)


class PODetail(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id, po_id):
        _require_member(request.user, restaurant_id)
        po = PurchaseOrder.objects.filter(
            id=po_id, restaurant_id=restaurant_id,
        ).prefetch_related(
            "lines__vendor_ingredient__ingredient",
            "events__actor",
        ).first()
        if not po:
            raise NotFound()
        return Response({
            "po": PODetailSerializer(po).data,
            "events": POEventSerializer(po.events.all()[:50], many=True).data,
        })


class POAddLine(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, po_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_purchase(member.roles):
            raise PermissionDenied()
        po = PurchaseOrder.objects.filter(
            id=po_id, restaurant_id=restaurant_id,
        ).first()
        if not po:
            raise NotFound()
        s = AddLineSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        vi = VendorIngredient.objects.filter(
            id=s.validated_data["vendor_ingredient_id"],
            vendor__restaurant_id=restaurant_id,
        ).first()
        if not vi:
            raise NotFound("vendor_ingredient_not_found")
        line = services.add_line(
            po=po, vendor_ingredient=vi,
            quantity=s.validated_data["quantity"],
            unit_price=s.validated_data.get("unit_price"),
            description=s.validated_data.get("description", ""),
            actor=request.user,
        )
        return Response({"line": POLineSerializer(line).data}, status=201)


class POLineDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def patch(self, request, restaurant_id, line_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_purchase(member.roles):
            raise PermissionDenied()
        line = PurchaseOrderLine.objects.filter(
            id=line_id, purchase_order__restaurant_id=restaurant_id,
        ).select_related("purchase_order").first()
        if not line:
            raise NotFound()
        services.update_line(
            line=line,
            quantity=request.data.get("quantity"),
            unit_price=request.data.get("unit_price"),
        )
        return Response({"line": POLineSerializer(line).data})

    def delete(self, request, restaurant_id, line_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_purchase(member.roles):
            raise PermissionDenied()
        line = PurchaseOrderLine.objects.filter(
            id=line_id, purchase_order__restaurant_id=restaurant_id,
        ).first()
        if not line:
            raise NotFound()
        services.remove_line(line=line)
        return Response({"ok": True})


class POSubmit(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, po_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_purchase(member.roles):
            raise PermissionDenied()
        po = PurchaseOrder.objects.filter(
            id=po_id, restaurant_id=restaurant_id,
        ).first()
        if not po:
            raise NotFound()
        services.submit_po(po=po, actor=request.user)
        return Response({"po": POSerializer(po).data})


class POCancel(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, po_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_purchase(member.roles):
            raise PermissionDenied()
        po = PurchaseOrder.objects.filter(
            id=po_id, restaurant_id=restaurant_id,
        ).first()
        if not po:
            raise NotFound()
        services.cancel_po(po=po, actor=request.user,
                           reason=request.data.get("reason", ""))
        return Response({"po": POSerializer(po).data})


class POReceiveLine(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, line_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_purchase(member.roles):
            raise PermissionDenied()
        line = PurchaseOrderLine.objects.filter(
            id=line_id, purchase_order__restaurant_id=restaurant_id,
        ).select_related(
            "purchase_order__vendor", "vendor_ingredient__ingredient",
        ).first()
        if not line:
            raise NotFound()
        s = ReceiveLineSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        services.receive_po_line(
            line=line, actor=request.user, **s.validated_data,
        )
        return Response({"line": POLineSerializer(line).data})


class AutoReorderView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_purchase(member.roles):
            raise PermissionDenied()
        rest = Restaurant.objects.get(id=restaurant_id)
        loc = Location.objects.filter(
            id=request.data.get("location_id"), restaurant_id=restaurant_id,
        ).first()
        vendor = Vendor.objects.filter(
            id=request.data.get("vendor_id"), restaurant_id=restaurant_id,
        ).first()
        if not loc or not vendor:
            raise NotFound()
        po = services.auto_generate_reorder_po(
            restaurant=rest, location=loc, vendor=vendor, actor=request.user,
        )
        if not po:
            return Response({"po": None, "message": "no_low_stock_items"})
        return Response({"po": POSerializer(po).data}, status=201)
