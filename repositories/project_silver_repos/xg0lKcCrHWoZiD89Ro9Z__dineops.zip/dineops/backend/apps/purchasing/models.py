from __future__ import annotations

import uuid
from decimal import Decimal

from django.conf import settings
from django.db import models

from apps.common.models import TimeStampedModel


class PurchaseOrder(TimeStampedModel):
    """A formal order placed with a vendor. Lifecycle:
       draft → submitted → received (or cancelled).

    On submit we lock the line totals.
    On receive we move stock into inventory at the received qty/cost.
    """

    STATUS_CHOICES = [
        ("draft", "Draft"),
        ("submitted", "Submitted"),
        ("partially_received", "Partially received"),
        ("received", "Received"),
        ("cancelled", "Cancelled"),
        ("disputed", "Disputed"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant = models.ForeignKey(
        "restaurants.Restaurant", on_delete=models.CASCADE,
        related_name="purchase_orders",
    )
    location = models.ForeignKey(
        "locations.Location", on_delete=models.PROTECT,
        related_name="purchase_orders",
    )
    vendor = models.ForeignKey(
        "vendors.Vendor", on_delete=models.PROTECT,
        related_name="purchase_orders",
    )
    po_number = models.CharField(max_length=40, unique=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="draft")

    expected_delivery_date = models.DateField(null=True, blank=True)
    submitted_at = models.DateTimeField(null=True, blank=True)
    submitted_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="+",
    )
    received_at = models.DateTimeField(null=True, blank=True)
    received_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="received_purchase_orders",
    )

    subtotal = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    tax_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    shipping_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    discount_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    total_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    currency = models.CharField(max_length=3, default="USD")

    delivery_notes = models.TextField(blank=True)
    internal_notes = models.TextField(blank=True)
    vendor_invoice_number = models.CharField(max_length=80, blank=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["restaurant", "status"]),
            models.Index(fields=["vendor", "status"]),
            models.Index(fields=["expected_delivery_date"]),
        ]

    def __str__(self) -> str:
        return f"PO #{self.po_number}"


class PurchaseOrderLine(TimeStampedModel):
    """One line on a PO — qty of an ingredient at a quoted unit price."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    purchase_order = models.ForeignKey(
        PurchaseOrder, on_delete=models.CASCADE, related_name="lines",
    )
    vendor_ingredient = models.ForeignKey(
        "vendors.VendorIngredient", on_delete=models.PROTECT,
        related_name="po_lines",
    )
    description = models.CharField(max_length=200, blank=True)

    quantity_ordered = models.DecimalField(
        max_digits=12, decimal_places=3,
        help_text="In packs (cases). Multiply by pack_quantity for base units.",
    )
    unit_price = models.DecimalField(max_digits=10, decimal_places=2)
    line_total = models.DecimalField(max_digits=12, decimal_places=2, default=0)

    quantity_received = models.DecimalField(max_digits=12, decimal_places=3, default=0)
    received_unit_price = models.DecimalField(
        max_digits=10, decimal_places=2, null=True, blank=True,
        help_text="If different from unit_price at submit.",
    )

    notes = models.CharField(max_length=200, blank=True)

    class Meta:
        ordering = ["created_at"]


class PurchaseOrderEvent(TimeStampedModel):
    """Audit trail of state changes on a PO."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    purchase_order = models.ForeignKey(
        PurchaseOrder, on_delete=models.CASCADE, related_name="events",
    )
    actor = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="+",
    )
    kind = models.CharField(
        max_length=40,
        help_text="created / submitted / line_added / received / cancelled / etc.",
    )
    payload = models.JSONField(default=dict, blank=True)

    class Meta:
        ordering = ["-created_at"]
