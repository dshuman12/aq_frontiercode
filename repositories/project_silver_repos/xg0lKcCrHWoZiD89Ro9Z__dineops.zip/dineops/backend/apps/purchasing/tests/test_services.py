from __future__ import annotations

from datetime import date, timedelta
from decimal import Decimal

import pytest

from apps.accounts.models import User
from apps.common.exceptions import ValidationError
from apps.ingredients.models import Ingredient
from apps.inventory.models import InventoryItem
from apps.inventory.services import create_inventory_item
from apps.locations.models import Location
from apps.purchasing.models import PurchaseOrder, PurchaseOrderEvent
from apps.purchasing.services import (
    add_line, auto_generate_reorder_po, cancel_po, create_draft_po,
    receive_po_line, remove_line, submit_po, update_line,
)
from apps.restaurants.models import Restaurant
from apps.vendors.services import add_vendor_ingredient, create_vendor


pytestmark = pytest.mark.django_db


def _setup():
    owner = User.objects.create_user(email="o@x.com", password="pwpwpwpw")
    rest = Restaurant.objects.create(name="R", slug="r", owner=owner)
    loc = Location.objects.create(
        restaurant=rest, name="Main", slug="main", accepts_dine_in=True,
    )
    vendor = create_vendor(restaurant=rest, name="V")
    ing = Ingredient.objects.create(
        restaurant=rest, name="Beef", base_unit="g",
    )
    vi = add_vendor_ingredient(
        vendor=vendor, ingredient=ing, pack_size="40lb case",
        pack_quantity=Decimal("18000"), case_price=Decimal("250"),
    )
    return rest, loc, vendor, ing, vi


class TestCreateDraftPO:
    def test_creates(self):
        rest, loc, vendor, _, _ = _setup()
        po = create_draft_po(restaurant=rest, location=loc, vendor=vendor)
        assert po.status == "draft"
        assert po.po_number.startswith("R-")
        # creation event
        assert PurchaseOrderEvent.objects.filter(
            purchase_order=po, kind="created",
        ).count() == 1

    def test_unique_po_numbers(self):
        rest, loc, vendor, _, _ = _setup()
        po1 = create_draft_po(restaurant=rest, location=loc, vendor=vendor)
        po2 = create_draft_po(restaurant=rest, location=loc, vendor=vendor)
        assert po1.po_number != po2.po_number


class TestAddLine:
    def test_adds_line_and_recalcs(self):
        rest, loc, vendor, _, vi = _setup()
        po = create_draft_po(restaurant=rest, location=loc, vendor=vendor)
        line = add_line(po=po, vendor_ingredient=vi,
                        quantity=Decimal("2"), unit_price=Decimal("250"))
        po.refresh_from_db()
        assert line.line_total == Decimal("500.00")
        assert po.subtotal == Decimal("500.00")
        assert po.total_amount == Decimal("500.00")

    def test_uses_vi_price_by_default(self):
        rest, loc, vendor, _, vi = _setup()
        po = create_draft_po(restaurant=rest, location=loc, vendor=vendor)
        line = add_line(po=po, vendor_ingredient=vi, quantity=Decimal("1"))
        assert line.unit_price == Decimal("250.00")

    def test_zero_quantity_rejected(self):
        rest, loc, vendor, _, vi = _setup()
        po = create_draft_po(restaurant=rest, location=loc, vendor=vendor)
        with pytest.raises(ValidationError):
            add_line(po=po, vendor_ingredient=vi, quantity=Decimal("0"))

    def test_cross_vendor_rejected(self):
        rest, loc, vendor, _, _ = _setup()
        # different vendor's vi
        v2 = create_vendor(restaurant=rest, name="V2")
        ing2 = Ingredient.objects.create(restaurant=rest, name="X")
        vi2 = add_vendor_ingredient(
            vendor=v2, ingredient=ing2, pack_size="case",
            pack_quantity=Decimal("1"), case_price=Decimal("10"),
        )
        po = create_draft_po(restaurant=rest, location=loc, vendor=vendor)
        with pytest.raises(ValidationError):
            add_line(po=po, vendor_ingredient=vi2, quantity=Decimal("1"))

    def test_add_to_submitted_rejected(self):
        rest, loc, vendor, _, vi = _setup()
        po = create_draft_po(restaurant=rest, location=loc, vendor=vendor)
        add_line(po=po, vendor_ingredient=vi, quantity=Decimal("1"))
        submit_po(po=po)
        with pytest.raises(ValidationError):
            add_line(po=po, vendor_ingredient=vi, quantity=Decimal("1"))


class TestUpdateAndRemove:
    def test_update_line(self):
        rest, loc, vendor, _, vi = _setup()
        po = create_draft_po(restaurant=rest, location=loc, vendor=vendor)
        line = add_line(po=po, vendor_ingredient=vi, quantity=Decimal("1"))
        update_line(line=line, quantity=Decimal("3"))
        po.refresh_from_db()
        line.refresh_from_db()
        assert line.quantity_ordered == Decimal("3.000")
        assert po.subtotal == Decimal("750.00")

    def test_remove_line(self):
        rest, loc, vendor, _, vi = _setup()
        po = create_draft_po(restaurant=rest, location=loc, vendor=vendor)
        line = add_line(po=po, vendor_ingredient=vi, quantity=Decimal("1"))
        remove_line(line=line)
        po.refresh_from_db()
        assert po.subtotal == Decimal("0.00")
        assert po.lines.count() == 0


class TestSubmit:
    def test_submit(self):
        rest, loc, vendor, _, vi = _setup()
        po = create_draft_po(restaurant=rest, location=loc, vendor=vendor)
        add_line(po=po, vendor_ingredient=vi, quantity=Decimal("1"))
        submit_po(po=po)
        po.refresh_from_db()
        assert po.status == "submitted"
        assert po.submitted_at is not None

    def test_empty_po_rejected(self):
        rest, loc, vendor, _, _ = _setup()
        po = create_draft_po(restaurant=rest, location=loc, vendor=vendor)
        with pytest.raises(ValidationError):
            submit_po(po=po)

    def test_below_minimum_rejected(self):
        rest, loc, vendor, _, vi = _setup()
        vendor.minimum_order = Decimal("1000")
        vendor.save()
        po = create_draft_po(restaurant=rest, location=loc, vendor=vendor)
        add_line(po=po, vendor_ingredient=vi, quantity=Decimal("1"),
                 unit_price=Decimal("250"))  # only $250
        with pytest.raises(ValidationError) as exc:
            submit_po(po=po)
        assert exc.value.code == "below_minimum_order"


class TestCancel:
    def test_cancel_draft(self):
        rest, loc, vendor, _, _ = _setup()
        po = create_draft_po(restaurant=rest, location=loc, vendor=vendor)
        cancel_po(po=po, reason="changed mind")
        po.refresh_from_db()
        assert po.status == "cancelled"

    def test_cancel_received_rejected(self):
        rest, loc, vendor, _, vi = _setup()
        po = create_draft_po(restaurant=rest, location=loc, vendor=vendor)
        add_line(po=po, vendor_ingredient=vi, quantity=Decimal("1"))
        submit_po(po=po)
        line = po.lines.first()
        receive_po_line(line=line, quantity_received=Decimal("1"))
        po.refresh_from_db()
        with pytest.raises(ValidationError):
            cancel_po(po=po)


class TestReceive:
    def test_receive_full(self):
        rest, loc, vendor, ing, vi = _setup()
        po = create_draft_po(restaurant=rest, location=loc, vendor=vendor)
        add_line(po=po, vendor_ingredient=vi, quantity=Decimal("2"),
                 unit_price=Decimal("250"))
        submit_po(po=po)
        line = po.lines.first()
        receive_po_line(line=line, quantity_received=Decimal("2"))
        po.refresh_from_db()
        assert po.status == "received"
        # Inventory should now exist with 2 cases × 18000g = 36000g
        item = InventoryItem.objects.get(location=loc, ingredient=ing)
        assert item.quantity_on_hand == Decimal("36000.000")

    def test_partial_receive(self):
        rest, loc, vendor, ing, vi = _setup()
        po = create_draft_po(restaurant=rest, location=loc, vendor=vendor)
        add_line(po=po, vendor_ingredient=vi, quantity=Decimal("3"),
                 unit_price=Decimal("250"))
        submit_po(po=po)
        line = po.lines.first()
        receive_po_line(line=line, quantity_received=Decimal("1"))
        po.refresh_from_db()
        assert po.status == "partially_received"
        receive_po_line(line=line, quantity_received=Decimal("2"))
        po.refresh_from_db()
        assert po.status == "received"

    def test_over_receive_rejected(self):
        rest, loc, vendor, _, vi = _setup()
        po = create_draft_po(restaurant=rest, location=loc, vendor=vendor)
        add_line(po=po, vendor_ingredient=vi, quantity=Decimal("1"))
        submit_po(po=po)
        line = po.lines.first()
        with pytest.raises(ValidationError):
            receive_po_line(line=line, quantity_received=Decimal("2"))

    def test_receive_creates_lot(self):
        from apps.inventory.models import LotTrackingRecord
        rest, loc, vendor, _, vi = _setup()
        po = create_draft_po(restaurant=rest, location=loc, vendor=vendor)
        add_line(po=po, vendor_ingredient=vi, quantity=Decimal("1"))
        submit_po(po=po)
        line = po.lines.first()
        receive_po_line(
            line=line, quantity_received=Decimal("1"),
            lot_code="LOT-XYZ",
            expires_at=date.today() + timedelta(days=14),
        )
        assert LotTrackingRecord.objects.filter(lot_code="LOT-XYZ").count() == 1


class TestAutoReorder:
    def test_generates_po_for_low_items(self):
        rest, loc, vendor, ing, vi = _setup()
        # Create inventory item below reorder
        create_inventory_item(
            restaurant=rest, location=loc, ingredient=ing,
            reorder_point=Decimal("1000"),
            reorder_quantity=Decimal("18000"),
            opening_quantity=Decimal("100"),
        )
        po = auto_generate_reorder_po(
            restaurant=rest, location=loc, vendor=vendor,
        )
        assert po is not None
        assert po.lines.count() == 1
        line = po.lines.first()
        # 18000g / 18000g per pack = 1 pack
        assert line.quantity_ordered == Decimal("1.000")

    def test_returns_none_when_nothing_low(self):
        rest, loc, vendor, ing, _ = _setup()
        create_inventory_item(
            restaurant=rest, location=loc, ingredient=ing,
            reorder_point=Decimal("100"),
            reorder_quantity=Decimal("500"),
            opening_quantity=Decimal("1000"),
        )
        po = auto_generate_reorder_po(
            restaurant=rest, location=loc, vendor=vendor,
        )
        assert po is None
