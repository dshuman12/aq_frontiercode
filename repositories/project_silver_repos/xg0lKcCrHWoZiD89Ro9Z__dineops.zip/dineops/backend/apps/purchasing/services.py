from __future__ import annotations

from decimal import Decimal

from django.db import transaction
from django.utils import timezone

from apps.common.exceptions import Conflict, NotFound, ValidationError
from apps.inventory.models import InventoryItem
from apps.inventory.services import receive_stock
from apps.locations.models import Location
from apps.vendors.models import Vendor, VendorIngredient

from .models import PurchaseOrder, PurchaseOrderEvent, PurchaseOrderLine


def _next_po_number(restaurant) -> str:
    """Deterministic PO number — restaurant.slug + date + sequence."""
    today = timezone.now().date()
    prefix = f"{restaurant.slug.upper()[:6]}-{today.strftime('%Y%m%d')}"
    seq = PurchaseOrder.objects.filter(
        po_number__startswith=prefix,
    ).count() + 1
    return f"{prefix}-{seq:03d}"


@transaction.atomic
def create_draft_po(*, restaurant, location: Location, vendor: Vendor,
                    actor=None,
                    expected_delivery_date=None) -> PurchaseOrder:
    if location.restaurant_id != restaurant.id:
        raise ValidationError("location_not_in_restaurant")
    if vendor.restaurant_id != restaurant.id:
        raise ValidationError("vendor_not_in_restaurant")
    po = PurchaseOrder.objects.create(
        restaurant=restaurant, location=location, vendor=vendor,
        po_number=_next_po_number(restaurant),
        expected_delivery_date=expected_delivery_date,
        status="draft",
    )
    PurchaseOrderEvent.objects.create(
        purchase_order=po, actor=actor, kind="created",
        payload={"vendor": vendor.name, "location": location.name},
    )
    return po


def _recalc_po_totals(po: PurchaseOrder) -> None:
    subtotal = Decimal("0")
    for line in po.lines.all():
        line.line_total = (line.quantity_ordered * line.unit_price).quantize(Decimal("0.01"))
        line.save(update_fields=["line_total", "updated_at"])
        subtotal += line.line_total
    po.subtotal = subtotal
    po.total_amount = (
        po.subtotal + po.tax_amount + po.shipping_amount - po.discount_amount
    ).quantize(Decimal("0.01"))
    po.save(update_fields=["subtotal", "total_amount", "updated_at"])


@transaction.atomic
def add_line(*, po: PurchaseOrder, vendor_ingredient: VendorIngredient,
             quantity: Decimal, unit_price: Decimal | None = None,
             description: str = "", actor=None) -> PurchaseOrderLine:
    if po.status != "draft":
        raise ValidationError("po_not_in_draft")
    if vendor_ingredient.vendor_id != po.vendor_id:
        raise ValidationError("vi_not_with_vendor")
    if quantity is None or quantity <= 0:
        raise ValidationError("invalid_quantity")
    if unit_price is None:
        unit_price = vendor_ingredient.case_price
    if unit_price < 0:
        raise ValidationError("invalid_unit_price")

    line = PurchaseOrderLine.objects.create(
        purchase_order=po, vendor_ingredient=vendor_ingredient,
        quantity_ordered=quantity, unit_price=unit_price,
        description=description or vendor_ingredient.ingredient.name,
        line_total=(quantity * unit_price).quantize(Decimal("0.01")),
    )
    _recalc_po_totals(po)
    PurchaseOrderEvent.objects.create(
        purchase_order=po, actor=actor, kind="line_added",
        payload={"line_id": str(line.id),
                 "ingredient": vendor_ingredient.ingredient.name,
                 "qty": str(quantity)},
    )
    return line


@transaction.atomic
def update_line(*, line: PurchaseOrderLine,
                quantity: Decimal | None = None,
                unit_price: Decimal | None = None) -> PurchaseOrderLine:
    if line.purchase_order.status != "draft":
        raise ValidationError("po_not_in_draft")
    if quantity is not None:
        if quantity <= 0:
            raise ValidationError("invalid_quantity")
        line.quantity_ordered = quantity
    if unit_price is not None:
        if unit_price < 0:
            raise ValidationError("invalid_unit_price")
        line.unit_price = unit_price
    line.save()
    _recalc_po_totals(line.purchase_order)
    return line


@transaction.atomic
def remove_line(*, line: PurchaseOrderLine) -> None:
    po = line.purchase_order
    if po.status != "draft":
        raise ValidationError("po_not_in_draft")
    line.delete()
    _recalc_po_totals(po)


@transaction.atomic
def submit_po(*, po: PurchaseOrder, actor=None) -> PurchaseOrder:
    if po.status != "draft":
        raise ValidationError("po_not_in_draft")
    if po.lines.count() == 0:
        raise ValidationError("po_has_no_lines")
    if po.total_amount < po.vendor.minimum_order:
        raise ValidationError(
            "below_minimum_order",
            f"Order total ${po.total_amount} is below "
            f"vendor minimum ${po.vendor.minimum_order}",
        )
    po.status = "submitted"
    po.submitted_at = timezone.now()
    po.submitted_by = actor
    po.save(update_fields=["status", "submitted_at", "submitted_by", "updated_at"])
    PurchaseOrderEvent.objects.create(
        purchase_order=po, actor=actor, kind="submitted",
        payload={"total": str(po.total_amount)},
    )
    return po


@transaction.atomic
def cancel_po(*, po: PurchaseOrder, actor=None, reason: str = "") -> PurchaseOrder:
    if po.status not in ("draft", "submitted"):
        raise ValidationError("po_not_cancellable")
    po.status = "cancelled"
    po.save(update_fields=["status", "updated_at"])
    PurchaseOrderEvent.objects.create(
        purchase_order=po, actor=actor, kind="cancelled",
        payload={"reason": reason},
    )
    return po


@transaction.atomic
def receive_po_line(*, line: PurchaseOrderLine,
                    quantity_received: Decimal,
                    actual_unit_price: Decimal | None = None,
                    lot_code: str = "",
                    expires_at=None,
                    actor=None) -> PurchaseOrderLine:
    """Record a partial receipt for a single line, and post it to inventory."""
    po = line.purchase_order
    if po.status not in ("submitted", "partially_received"):
        raise ValidationError("po_not_receivable")
    if quantity_received is None or quantity_received <= 0:
        raise ValidationError("invalid_quantity_received")
    over_receive = (line.quantity_received + quantity_received) > (
        line.quantity_ordered * Decimal("1.10")
    )
    if over_receive:
        raise ValidationError(
            "over_receive_threshold",
            "Cannot receive more than 110% of ordered quantity without explicit override.",
        )

    line.quantity_received = line.quantity_received + quantity_received
    if actual_unit_price is not None:
        line.received_unit_price = actual_unit_price
    line.save()

    # Post to inventory at the received quantity * pack_quantity
    vi = line.vendor_ingredient
    inv_item = InventoryItem.objects.filter(
        location=po.location, ingredient=vi.ingredient,
    ).first()
    if not inv_item:
        # Auto-create inventory item if missing
        inv_item = InventoryItem.objects.create(
            restaurant=po.restaurant, location=po.location,
            ingredient=vi.ingredient,
        )

    base_qty = quantity_received * vi.pack_quantity
    eff_unit_price = (
        (actual_unit_price or line.unit_price) / vi.pack_quantity
    ).quantize(Decimal("0.0001"))
    receive_stock(
        item=inv_item, quantity=base_qty, unit_cost=eff_unit_price,
        reference=f"PO:{po.po_number}", actor=actor,
        lot_code=lot_code, expires_at=expires_at,
        supplier_name=po.vendor.name,
    )

    PurchaseOrderEvent.objects.create(
        purchase_order=po, actor=actor, kind="line_received",
        payload={
            "line_id": str(line.id),
            "qty": str(quantity_received),
            "unit_price": str(actual_unit_price) if actual_unit_price else None,
        },
    )

    # Recompute PO status
    fully_received_lines = sum(
        1 for ln in po.lines.all()
        if ln.quantity_received >= ln.quantity_ordered
    )
    total_lines = po.lines.count()
    if fully_received_lines == total_lines:
        po.status = "received"
        po.received_at = timezone.now()
        po.received_by = actor
        po.save(update_fields=[
            "status", "received_at", "received_by", "updated_at",
        ])
        PurchaseOrderEvent.objects.create(
            purchase_order=po, actor=actor, kind="received_in_full",
        )
    elif po.status == "submitted":
        po.status = "partially_received"
        po.save(update_fields=["status", "updated_at"])

    return line


@transaction.atomic
def auto_generate_reorder_po(*, restaurant, location: Location, vendor: Vendor,
                             actor=None) -> PurchaseOrder | None:
    """Walk the location's inventory; for any item below reorder_point that has
    an offering from `vendor`, add a line to a new draft PO at reorder_quantity."""
    items = InventoryItem.objects.filter(
        restaurant=restaurant, location=location, is_active=True,
        reorder_point__gt=0,
    )
    items = [it for it in items if it.is_low and it.reorder_quantity > 0]
    if not items:
        return None
    po = create_draft_po(restaurant=restaurant, location=location,
                         vendor=vendor, actor=actor)
    added = 0
    for item in items:
        vi = VendorIngredient.objects.filter(
            vendor=vendor, ingredient=item.ingredient, is_available=True,
        ).first()
        if not vi:
            continue
        # Convert reorder_quantity (in base_unit) to packs
        packs_needed = (item.reorder_quantity / vi.pack_quantity).quantize(Decimal("0.001"))
        if packs_needed <= 0:
            packs_needed = Decimal("1")
        add_line(po=po, vendor_ingredient=vi,
                 quantity=packs_needed, actor=actor)
        added += 1
    if added == 0:
        po.delete()
        return None
    return po
