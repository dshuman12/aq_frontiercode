from django.contrib import admin

from .models import PurchaseOrder, PurchaseOrderEvent, PurchaseOrderLine


class POLineInline(admin.TabularInline):
    model = PurchaseOrderLine
    extra = 0
    readonly_fields = ("line_total",)


class POEventInline(admin.TabularInline):
    model = PurchaseOrderEvent
    extra = 0
    readonly_fields = ("kind", "actor", "payload", "created_at")
    can_delete = False


@admin.register(PurchaseOrder)
class PurchaseOrderAdmin(admin.ModelAdmin):
    list_display = ("po_number", "vendor", "location", "status",
                    "expected_delivery_date", "total_amount")
    list_filter = ("status", "vendor")
    search_fields = ("po_number", "vendor__name", "vendor_invoice_number")
    inlines = [POLineInline, POEventInline]
    readonly_fields = ("po_number", "submitted_at", "received_at",
                       "subtotal", "total_amount")
