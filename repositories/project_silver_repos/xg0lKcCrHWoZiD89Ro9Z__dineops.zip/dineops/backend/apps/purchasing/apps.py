from django.apps import AppConfig


class PurchasingConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.purchasing"

    def ready(self):
        try:
            from . import signals  # noqa: F401
        except ImportError:
            pass
