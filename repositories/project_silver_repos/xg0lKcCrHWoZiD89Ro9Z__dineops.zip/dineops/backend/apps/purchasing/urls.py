from django.urls import path

from . import views

app_name = "purchasing"

urlpatterns = [
    path("<uuid:restaurant_id>/",
         views.POListCreate.as_view(), name="list-create"),
    path("<uuid:restaurant_id>/<uuid:po_id>/",
         views.PODetail.as_view(), name="detail"),
    path("<uuid:restaurant_id>/<uuid:po_id>/lines/",
         views.POAddLine.as_view(), name="add-line"),
    path("<uuid:restaurant_id>/<uuid:po_id>/submit/",
         views.POSubmit.as_view(), name="submit"),
    path("<uuid:restaurant_id>/<uuid:po_id>/cancel/",
         views.POCancel.as_view(), name="cancel"),
    path("<uuid:restaurant_id>/lines/<uuid:line_id>/",
         views.POLineDetail.as_view(), name="line-detail"),
    path("<uuid:restaurant_id>/lines/<uuid:line_id>/receive/",
         views.POReceiveLine.as_view(), name="line-receive"),
    path("<uuid:restaurant_id>/auto-reorder/",
         views.AutoReorderView.as_view(), name="auto-reorder"),
]
