from django.urls import path, re_path

from . import consumers


websocket_urlpatterns = [
    re_path(
        r"^ws/kitchen/(?P<location_id>[0-9a-f-]+)/$",
        consumers.KitchenScreenConsumer.as_asgi(),
    ),
    re_path(
        r"^ws/expo/(?P<location_id>[0-9a-f-]+)/$",
        consumers.ExpoBoardConsumer.as_asgi(),
    ),
]
