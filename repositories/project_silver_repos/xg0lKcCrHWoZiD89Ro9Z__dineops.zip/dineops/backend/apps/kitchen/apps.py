from django.apps import AppConfig


class KitchenConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.kitchen"

    def ready(self):
        try:
            from . import signals  # noqa: F401
        except ImportError:
            pass
