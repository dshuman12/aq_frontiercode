from __future__ import annotations

import json

from channels.db import database_sync_to_async
from channels.generic.websocket import AsyncJsonWebsocketConsumer

from apps.orders.models import Order, OrderItem
from apps.orders.serializers import (
    OrderDetailSerializer, OrderItemSerializer,
)
from apps.restaurants.models import RestaurantMember


class KitchenScreenConsumer(AsyncJsonWebsocketConsumer):
    """WebSocket fed by the kitchen screen client. Each location has a
    channel group named `kitchen.<location_id>`. We push order events here
    from `apps.orders.signals`."""

    async def connect(self):
        user = self.scope.get("user")
        if not user or not user.is_authenticated:
            await self.close(code=4001)
            return
        self.location_id = self.scope["url_route"]["kwargs"]["location_id"]
        is_member = await self._is_member_of_location(user, self.location_id)
        if not is_member:
            await self.close(code=4003)
            return
        self.group = f"kitchen.{self.location_id}"
        await self.channel_layer.group_add(self.group, self.channel_name)
        await self.accept()
        # Hello payload — initial active board state
        snapshot = await self._initial_board(self.location_id)
        await self.send_json({"type": "hello", "snapshot": snapshot})

    async def disconnect(self, code):
        if hasattr(self, "group"):
            await self.channel_layer.group_discard(self.group, self.channel_name)

    async def receive_json(self, content, **kwargs):
        action = content.get("action")
        item_id = content.get("item_id")
        if action == "mark_in_progress":
            await self._mark_in_progress(item_id)
        elif action == "mark_ready":
            await self._mark_ready(item_id)
        elif action == "mark_served":
            await self._mark_served(item_id)
        elif action == "ping":
            await self.send_json({"type": "pong"})

    # ---- group event handlers ----

    async def kitchen_event(self, event):
        # Generic forward: { type: 'kitchen.event', kind: ..., payload: ... }
        await self.send_json({
            "type": event["kind"],
            "payload": event["payload"],
        })

    # ---- DB operations ----

    @database_sync_to_async
    def _is_member_of_location(self, user, location_id) -> bool:
        from apps.locations.models import Location
        loc = Location.objects.filter(id=location_id).first()
        if not loc:
            return False
        return RestaurantMember.objects.filter(
            restaurant=loc.restaurant, user=user, status="active",
        ).exists()

    @database_sync_to_async
    def _initial_board(self, location_id) -> list:
        orders = (
            Order.objects.filter(
                location_id=location_id,
                status__in=("submitted", "in_kitchen", "ready"),
            )
            .prefetch_related("items__modifiers", "items__variant")
            .order_by("submitted_at")[:50]
        )
        return [OrderDetailSerializer(o).data for o in orders]

    @database_sync_to_async
    def _mark_in_progress(self, item_id):
        from apps.orders.services import mark_item_in_progress
        item = OrderItem.objects.filter(id=item_id).first()
        if item:
            mark_item_in_progress(item=item)

    @database_sync_to_async
    def _mark_ready(self, item_id):
        from apps.orders.services import mark_item_ready
        item = OrderItem.objects.filter(id=item_id).first()
        if item:
            mark_item_ready(item=item)

    @database_sync_to_async
    def _mark_served(self, item_id):
        from apps.orders.services import mark_item_served
        item = OrderItem.objects.filter(id=item_id).first()
        if item:
            mark_item_served(item=item)


class ExpoBoardConsumer(AsyncJsonWebsocketConsumer):
    """Expediter board — sees ready items waiting to be served."""

    async def connect(self):
        user = self.scope.get("user")
        if not user or not user.is_authenticated:
            await self.close(code=4001)
            return
        self.location_id = self.scope["url_route"]["kwargs"]["location_id"]
        self.group = f"expo.{self.location_id}"
        await self.channel_layer.group_add(self.group, self.channel_name)
        await self.accept()

    async def disconnect(self, code):
        if hasattr(self, "group"):
            await self.channel_layer.group_discard(self.group, self.channel_name)

    async def kitchen_event(self, event):
        await self.send_json(event)
