from rest_framework import serializers

from .models import Ingredient, IngredientCategory, StorageLocation


class IngredientCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = IngredientCategory
        fields = ("id", "name", "sort", "created_at")


class StorageLocationSerializer(serializers.ModelSerializer):
    class Meta:
        model = StorageLocation
        fields = ("id", "location", "name", "kind", "sort", "created_at")


class IngredientSerializer(serializers.ModelSerializer):
    effective_cost_per_unit = serializers.DecimalField(
        max_digits=12, decimal_places=4, read_only=True,
    )

    class Meta:
        model = Ingredient
        fields = (
            "id", "sku", "name", "category",
            "base_unit", "cost_per_unit", "yield_factor",
            "effective_cost_per_unit",
            "storage_location", "par_quantity", "reorder_quantity",
            "is_allergen", "allergen_tags", "notes",
            "archived_at", "created_at",
        )
        read_only_fields = ("id", "effective_cost_per_unit", "archived_at", "created_at")


class IngredientCreateSerializer(serializers.Serializer):
    name = serializers.CharField(min_length=1, max_length=200)
    sku = serializers.CharField(max_length=80, required=False, allow_blank=True)
    category_id = serializers.UUIDField(required=False, allow_null=True)
    base_unit = serializers.ChoiceField(choices=Ingredient.UNIT_CHOICES, default="each")
    cost_per_unit = serializers.DecimalField(max_digits=12, decimal_places=4, required=False, default=0)
    yield_factor = serializers.DecimalField(max_digits=5, decimal_places=4, required=False, default=1)
    storage_location_id = serializers.UUIDField(required=False, allow_null=True)
    par_quantity = serializers.DecimalField(max_digits=12, decimal_places=3, required=False, default=0)
    reorder_quantity = serializers.DecimalField(max_digits=12, decimal_places=3, required=False, default=0)
    is_allergen = serializers.BooleanField(required=False, default=False)
    allergen_tags = serializers.ListField(child=serializers.CharField(), required=False)
