from django.contrib import admin

from .models import Ingredient, IngredientCategory, StorageLocation


@admin.register(Ingredient)
class IngredientAdmin(admin.ModelAdmin):
    list_display = ("name", "restaurant", "sku", "base_unit",
                    "cost_per_unit", "yield_factor", "archived_at")
    list_filter = ("base_unit", "is_allergen")
    search_fields = ("name", "sku")


@admin.register(IngredientCategory)
class IngredientCategoryAdmin(admin.ModelAdmin):
    list_display = ("name", "restaurant", "sort")
    search_fields = ("name",)


@admin.register(StorageLocation)
class StorageLocationAdmin(admin.ModelAdmin):
    list_display = ("name", "restaurant", "location", "kind")
    list_filter = ("kind",)
