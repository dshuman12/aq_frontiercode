from decimal import Decimal

import factory
from factory.django import DjangoModelFactory

from apps.ingredients.models import Ingredient, IngredientCategory, StorageLocation
from apps.locations.tests.factories import LocationFactory
from apps.restaurants.tests.factories import RestaurantFactory


class IngredientCategoryFactory(DjangoModelFactory):
    class Meta:
        model = IngredientCategory

    restaurant = factory.SubFactory(RestaurantFactory)
    name = factory.Iterator(["Proteins", "Produce", "Dairy", "Dry goods", "Bar"])


class StorageLocationFactory(DjangoModelFactory):
    class Meta:
        model = StorageLocation

    restaurant = factory.SubFactory(RestaurantFactory)
    location = factory.SubFactory(LocationFactory)
    name = factory.Iterator(["Walk-in", "Freezer", "Dry shelf"])
    kind = "cooler"


class IngredientFactory(DjangoModelFactory):
    class Meta:
        model = Ingredient

    restaurant = factory.SubFactory(RestaurantFactory)
    name = factory.Sequence(lambda n: f"Ingredient {n}")
    base_unit = "kg"
    cost_per_unit = Decimal("4.50")
    yield_factor = Decimal("1.0000")
