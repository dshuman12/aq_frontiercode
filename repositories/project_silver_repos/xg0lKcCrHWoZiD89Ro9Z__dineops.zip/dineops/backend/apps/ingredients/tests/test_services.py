from decimal import Decimal

import pytest

from apps.common.exceptions import Conflict, ValidationError
from apps.ingredients.services import (
    archive_ingredient,
    create_category,
    create_ingredient,
    update_ingredient,
)
from apps.ingredients.tests.factories import (
    IngredientCategoryFactory,
    IngredientFactory,
)
from apps.restaurants.tests.factories import RestaurantFactory


@pytest.mark.django_db
class TestIngredientServices:
    def test_create_category_unique_per_restaurant(self):
        r = RestaurantFactory()
        create_category(restaurant=r, name="Produce")
        with pytest.raises(Conflict):
            create_category(restaurant=r, name="Produce")
        # different restaurant ok
        r2 = RestaurantFactory()
        create_category(restaurant=r2, name="Produce")

    def test_create_ingredient_with_yield_factor(self):
        r = RestaurantFactory()
        ing = create_ingredient(
            restaurant=r, name="Salmon", base_unit="kg",
            cost_per_unit=Decimal("18.00"),
            yield_factor=Decimal("0.85"),
        )
        # effective cost = 18.00 / 0.85 = 21.1764... → quantize to 4dp
        assert ing.effective_cost_per_unit == Decimal("21.1765")

    def test_create_ingredient_with_zero_yield_returns_raw_cost(self):
        r = RestaurantFactory()
        ing = create_ingredient(
            restaurant=r, name="Test", cost_per_unit=Decimal("4.00"),
            yield_factor=Decimal("1"),
        )
        assert ing.effective_cost_per_unit == Decimal("4.0000")

    def test_create_rejects_negative_cost(self):
        r = RestaurantFactory()
        with pytest.raises(ValidationError):
            create_ingredient(restaurant=r, name="X", cost_per_unit=Decimal("-1"))

    def test_create_rejects_zero_yield(self):
        r = RestaurantFactory()
        with pytest.raises(ValidationError):
            create_ingredient(restaurant=r, name="X", yield_factor=Decimal("0"))

    def test_update_filters_unknown_fields(self):
        ing = IngredientFactory(name="X")
        update_ingredient(ingredient=ing, name="Y", evil="ignored")
        ing.refresh_from_db()
        assert ing.name == "Y"

    def test_update_rejects_negative_cost(self):
        ing = IngredientFactory()
        with pytest.raises(ValidationError):
            update_ingredient(ingredient=ing, cost_per_unit=Decimal("-3"))

    def test_archive(self):
        ing = IngredientFactory()
        archive_ingredient(ingredient=ing)
        ing.refresh_from_db()
        assert ing.archived_at is not None
