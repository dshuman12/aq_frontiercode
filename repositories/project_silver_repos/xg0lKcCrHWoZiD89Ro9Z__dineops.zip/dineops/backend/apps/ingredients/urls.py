from django.urls import path

from . import views

app_name = "ingredients"

urlpatterns = [
    path("<uuid:restaurant_id>/", views.IngredientList.as_view(), name="list"),
    path("<uuid:restaurant_id>/<uuid:ingredient_id>/",
         views.IngredientDetail.as_view(), name="detail"),
    path("<uuid:restaurant_id>/categories/",
         views.CategoryListCreate.as_view(), name="categories"),
    path("<uuid:restaurant_id>/storage-locations/",
         views.StorageLocationListCreate.as_view(), name="storage-locations"),
]
