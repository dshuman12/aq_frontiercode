from __future__ import annotations

from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common.exceptions import NotFound, PermissionDenied
from apps.locations.models import Location
from apps.restaurants.models import Restaurant, RestaurantMember

from . import services
from .models import Ingredient, IngredientCategory, StorageLocation
from .serializers import (
    IngredientCategorySerializer,
    IngredientCreateSerializer,
    IngredientSerializer,
    StorageLocationSerializer,
)


def _require_member(user, restaurant_id) -> RestaurantMember:
    m = RestaurantMember.objects.filter(
        restaurant_id=restaurant_id, user=user, status="active"
    ).first()
    if not m:
        raise PermissionDenied("not_a_member")
    return m


class IngredientList(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        _require_member(request.user, restaurant_id)
        qs = Ingredient.objects.filter(
            restaurant_id=restaurant_id, archived_at__isnull=True,
        ).order_by("name")
        if (q := request.GET.get("q")):
            qs = qs.filter(name__icontains=q)
        return Response({"results": IngredientSerializer(qs[:500], many=True).data})

    def post(self, request, restaurant_id):
        member = _require_member(request.user, restaurant_id)
        if not any(r in ("owner", "general_manager", "chef", "inventory_manager")
                   for r in member.roles):
            raise PermissionDenied()
        s = IngredientCreateSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        restaurant = Restaurant.objects.get(id=restaurant_id)
        ing = services.create_ingredient(restaurant=restaurant, **s.validated_data)
        return Response({"ingredient": IngredientSerializer(ing).data},
                        status=status.HTTP_201_CREATED)


class IngredientDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id, ingredient_id):
        _require_member(request.user, restaurant_id)
        ing = Ingredient.objects.filter(
            id=ingredient_id, restaurant_id=restaurant_id
        ).first()
        if not ing:
            raise NotFound()
        return Response({"ingredient": IngredientSerializer(ing).data})

    def patch(self, request, restaurant_id, ingredient_id):
        member = _require_member(request.user, restaurant_id)
        if not any(r in ("owner", "general_manager", "chef", "inventory_manager")
                   for r in member.roles):
            raise PermissionDenied()
        ing = Ingredient.objects.filter(
            id=ingredient_id, restaurant_id=restaurant_id
        ).first()
        if not ing:
            raise NotFound()
        services.update_ingredient(ingredient=ing, **request.data)
        return Response({"ingredient": IngredientSerializer(ing).data})

    def delete(self, request, restaurant_id, ingredient_id):
        member = _require_member(request.user, restaurant_id)
        if not any(r in ("owner", "general_manager", "chef", "inventory_manager")
                   for r in member.roles):
            raise PermissionDenied()
        ing = Ingredient.objects.filter(
            id=ingredient_id, restaurant_id=restaurant_id
        ).first()
        if not ing:
            raise NotFound()
        services.archive_ingredient(ingredient=ing)
        return Response({"ok": True})


class CategoryListCreate(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        _require_member(request.user, restaurant_id)
        items = IngredientCategory.objects.filter(restaurant_id=restaurant_id).order_by("sort", "name")
        return Response({"results": IngredientCategorySerializer(items, many=True).data})

    def post(self, request, restaurant_id):
        member = _require_member(request.user, restaurant_id)
        if not any(r in ("owner", "general_manager", "chef", "inventory_manager")
                   for r in member.roles):
            raise PermissionDenied()
        restaurant = Restaurant.objects.get(id=restaurant_id)
        cat = services.create_category(
            restaurant=restaurant,
            name=request.data.get("name", ""),
            sort=request.data.get("sort", 0),
        )
        return Response({"category": IngredientCategorySerializer(cat).data}, status=201)


class StorageLocationListCreate(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        _require_member(request.user, restaurant_id)
        items = StorageLocation.objects.filter(restaurant_id=restaurant_id).order_by("sort", "name")
        return Response({"results": StorageLocationSerializer(items, many=True).data})

    def post(self, request, restaurant_id):
        member = _require_member(request.user, restaurant_id)
        if not any(r in ("owner", "general_manager", "inventory_manager")
                   for r in member.roles):
            raise PermissionDenied()
        location = Location.objects.filter(
            id=request.data.get("location_id"), restaurant_id=restaurant_id
        ).first()
        if not location:
            raise NotFound("location_not_found")
        sl = services.create_storage_location(
            restaurant=Restaurant.objects.get(id=restaurant_id),
            location=location,
            name=request.data.get("name", ""),
            kind=request.data.get("kind", "dry"),
            sort=request.data.get("sort", 0),
        )
        return Response({"storage_location": StorageLocationSerializer(sl).data}, status=201)
