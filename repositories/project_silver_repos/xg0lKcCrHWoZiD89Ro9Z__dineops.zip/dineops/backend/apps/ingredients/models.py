from __future__ import annotations

import uuid

from django.db import models

from apps.common.models import SoftDeleteModel, TimeStampedModel


class IngredientCategory(TimeStampedModel):
    """Top-level category — proteins, produce, dairy, dry goods, etc."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant = models.ForeignKey(
        "restaurants.Restaurant", on_delete=models.CASCADE,
        related_name="ingredient_categories",
    )
    name = models.CharField(max_length=120)
    sort = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["sort", "name"]
        constraints = [
            models.UniqueConstraint(fields=["restaurant", "name"],
                                    name="unique_ingredient_category_name"),
        ]


class StorageLocation(TimeStampedModel):
    """Walk-in cooler, dry storage shelf 3, freezer 2 — for inventory walks."""

    KIND_CHOICES = [
        ("dry", "Dry"),
        ("cooler", "Cooler"),
        ("freezer", "Freezer"),
        ("bar", "Bar"),
        ("other", "Other"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant = models.ForeignKey(
        "restaurants.Restaurant", on_delete=models.CASCADE,
        related_name="storage_locations",
    )
    location = models.ForeignKey(
        "locations.Location", on_delete=models.CASCADE,
        related_name="storage_locations",
    )
    name = models.CharField(max_length=120)
    kind = models.CharField(max_length=20, choices=KIND_CHOICES, default="dry")
    sort = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["sort", "name"]


class Ingredient(TimeStampedModel, SoftDeleteModel):
    """Master ingredient record. Cost-tracked, unit-tracked. Inventory state
    lives in `apps.inventory.InventoryItem` so we can index it independently.
    """

    UNIT_CHOICES = [
        ("g", "Grams"),
        ("kg", "Kilograms"),
        ("oz", "Ounces"),
        ("lb", "Pounds"),
        ("ml", "Milliliters"),
        ("l", "Liters"),
        ("cup", "Cups"),
        ("tbsp", "Tablespoons"),
        ("tsp", "Teaspoons"),
        ("each", "Each"),
        ("dozen", "Dozen"),
        ("case", "Case"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant = models.ForeignKey(
        "restaurants.Restaurant", on_delete=models.CASCADE, related_name="ingredients"
    )
    category = models.ForeignKey(
        IngredientCategory, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="ingredients",
    )
    sku = models.CharField(max_length=80, blank=True, db_index=True)
    name = models.CharField(max_length=200)

    base_unit = models.CharField(max_length=10, choices=UNIT_CHOICES, default="each")
    cost_per_unit = models.DecimalField(max_digits=12, decimal_places=4, default=0,
                                        help_text="Cost per base_unit, in restaurant currency.")
    yield_factor = models.DecimalField(max_digits=5, decimal_places=4, default=1,
                                       help_text="0.85 = 15% trim/yield loss.")

    storage_location = models.ForeignKey(
        StorageLocation, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="ingredients",
    )
    par_quantity = models.DecimalField(max_digits=12, decimal_places=3, default=0)
    reorder_quantity = models.DecimalField(max_digits=12, decimal_places=3, default=0)

    is_allergen = models.BooleanField(default=False)
    allergen_tags = models.JSONField(default=list, blank=True)
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ["name"]
        constraints = [
            models.UniqueConstraint(fields=["restaurant", "sku"], name="unique_ingredient_sku",
                                    condition=models.Q(sku__gt="")),
        ]
        indexes = [
            models.Index(fields=["restaurant", "name"]),
            models.Index(fields=["restaurant", "archived_at"]),
        ]

    def __str__(self) -> str:
        return self.name

    @property
    def effective_cost_per_unit(self):
        """Cost adjusted for yield. e.g. if yield_factor=0.85, real cost is
        cost / 0.85."""
        from decimal import Decimal

        if not self.yield_factor or self.yield_factor == 0:
            return self.cost_per_unit
        return (self.cost_per_unit / self.yield_factor).quantize(Decimal("0.0001"))
