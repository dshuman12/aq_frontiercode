from __future__ import annotations

from django.db import transaction

from apps.common.exceptions import Conflict, ValidationError

from .models import Ingredient, IngredientCategory, StorageLocation


@transaction.atomic
def create_category(*, restaurant, name: str, sort: int = 0) -> IngredientCategory:
    if not name.strip():
        raise ValidationError("invalid_name")
    if IngredientCategory.objects.filter(restaurant=restaurant, name=name).exists():
        raise Conflict("category_exists")
    return IngredientCategory.objects.create(
        restaurant=restaurant, name=name.strip(), sort=sort,
    )


@transaction.atomic
def create_storage_location(*, restaurant, location, name: str,
                            kind: str = "dry", sort: int = 0) -> StorageLocation:
    return StorageLocation.objects.create(
        restaurant=restaurant, location=location, name=name, kind=kind, sort=sort,
    )


@transaction.atomic
def create_ingredient(*, restaurant, name: str, base_unit: str = "each",
                     cost_per_unit=0, yield_factor=1, **fields) -> Ingredient:
    if not name.strip():
        raise ValidationError("invalid_name")
    if cost_per_unit and cost_per_unit < 0:
        raise ValidationError("invalid_cost")
    if yield_factor is not None and yield_factor <= 0:
        raise ValidationError("invalid_yield")
    return Ingredient.objects.create(
        restaurant=restaurant,
        name=name.strip(),
        base_unit=base_unit,
        cost_per_unit=cost_per_unit,
        yield_factor=yield_factor,
        **fields,
    )


@transaction.atomic
def update_ingredient(*, ingredient: Ingredient, **fields) -> Ingredient:
    allowed = {
        "name", "sku", "category_id", "base_unit",
        "cost_per_unit", "yield_factor",
        "storage_location_id", "par_quantity", "reorder_quantity",
        "is_allergen", "allergen_tags", "notes",
    }
    if "yield_factor" in fields and fields["yield_factor"] is not None and fields["yield_factor"] <= 0:
        raise ValidationError("invalid_yield")
    if "cost_per_unit" in fields and fields["cost_per_unit"] is not None and fields["cost_per_unit"] < 0:
        raise ValidationError("invalid_cost")
    for k, v in fields.items():
        if k in allowed and v is not None:
            setattr(ingredient, k, v)
    ingredient.save()
    return ingredient


def archive_ingredient(*, ingredient: Ingredient):
    ingredient.archive()
    return ingredient
