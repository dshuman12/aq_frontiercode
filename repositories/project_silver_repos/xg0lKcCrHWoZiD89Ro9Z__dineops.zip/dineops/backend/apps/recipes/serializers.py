from rest_framework import serializers

from .models import Recipe, RecipeIngredient, RecipeInstruction, RecipeVersion


class RecipeIngredientSerializer(serializers.ModelSerializer):
    ingredient_name = serializers.CharField(source="ingredient.name", read_only=True)

    class Meta:
        model = RecipeIngredient
        fields = ("id", "ingredient", "ingredient_name", "quantity", "unit", "notes", "sort")


class RecipeInstructionSerializer(serializers.ModelSerializer):
    class Meta:
        model = RecipeInstruction
        fields = ("id", "sort", "text", "duration_minutes")


class RecipeSerializer(serializers.ModelSerializer):
    ingredients_used = RecipeIngredientSerializer(many=True, read_only=True)
    instructions_steps = RecipeInstructionSerializer(many=True, read_only=True)

    class Meta:
        model = Recipe
        fields = (
            "id", "menu_item", "name", "slug", "kind",
            "yield_quantity", "yield_unit",
            "portion_size", "portion_unit",
            "target_food_cost_percent", "selling_price",
            "cached_total_cost", "cached_cost_per_yield_unit",
            "cached_food_cost_percent", "cached_at",
            "version", "notes", "instructions",
            "ingredients_used", "instructions_steps",
            "archived_at", "created_at",
        )
        read_only_fields = (
            "id", "slug", "version",
            "cached_total_cost", "cached_cost_per_yield_unit",
            "cached_food_cost_percent", "cached_at",
            "ingredients_used", "instructions_steps",
            "archived_at", "created_at",
        )


class RecipeCreateSerializer(serializers.Serializer):
    name = serializers.CharField(min_length=1, max_length=200)
    menu_item_id = serializers.UUIDField(required=False, allow_null=True)
    kind = serializers.ChoiceField(choices=Recipe.KIND_CHOICES, default="plate")
    yield_quantity = serializers.DecimalField(max_digits=10, decimal_places=3, default=1)
    yield_unit = serializers.CharField(max_length=20, default="each")
    portion_size = serializers.DecimalField(max_digits=10, decimal_places=3, default=1)
    portion_unit = serializers.CharField(max_length=20, default="each")
    selling_price = serializers.DecimalField(max_digits=10, decimal_places=2, default=0)
    target_food_cost_percent = serializers.DecimalField(
        max_digits=5, decimal_places=2, default=30,
    )
    notes = serializers.CharField(required=False, allow_blank=True)
    instructions = serializers.CharField(required=False, allow_blank=True)


class AddIngredientLineSerializer(serializers.Serializer):
    ingredient_id = serializers.UUIDField()
    quantity = serializers.DecimalField(max_digits=10, decimal_places=4, min_value=0)
    unit = serializers.CharField(max_length=20)
    notes = serializers.CharField(max_length=200, required=False, allow_blank=True)
    sort = serializers.IntegerField(min_value=0, default=0)


class RecipeVersionSerializer(serializers.ModelSerializer):
    class Meta:
        model = RecipeVersion
        fields = ("id", "version", "snapshot", "saved_by", "created_at")
