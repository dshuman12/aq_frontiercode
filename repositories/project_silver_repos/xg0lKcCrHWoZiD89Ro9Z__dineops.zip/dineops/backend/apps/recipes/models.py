from __future__ import annotations

import uuid
from decimal import Decimal

from django.conf import settings
from django.db import models
from django.utils.text import slugify

from apps.common.models import SoftDeleteModel, TimeStampedModel


class Recipe(TimeStampedModel, SoftDeleteModel):
    """A standardized recipe — yields N portions of a menu item."""

    KIND_CHOICES = [
        ("plate", "Plate"),
        ("batch", "Batch"),
        ("sub_recipe", "Sub-recipe"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant = models.ForeignKey(
        "restaurants.Restaurant", on_delete=models.CASCADE, related_name="recipes"
    )
    menu_item = models.ForeignKey(
        "menus.MenuItem", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="recipes",
    )
    name = models.CharField(max_length=200)
    slug = models.SlugField(max_length=80)
    kind = models.CharField(max_length=20, choices=KIND_CHOICES, default="plate")

    yield_quantity = models.DecimalField(
        max_digits=10, decimal_places=3, default=1,
        help_text="How many portions / batch units the recipe produces.",
    )
    yield_unit = models.CharField(max_length=20, default="each")
    portion_size = models.DecimalField(max_digits=10, decimal_places=3, default=1)
    portion_unit = models.CharField(max_length=20, default="each")

    target_food_cost_percent = models.DecimalField(max_digits=5, decimal_places=2, default=30)
    selling_price = models.DecimalField(max_digits=10, decimal_places=2, default=0,
                                        help_text="Snapshot — also lives on MenuItem.")

    # Cached costing results (recomputed by recipe.tasks.recalculate_recipe_cost)
    cached_total_cost = models.DecimalField(max_digits=12, decimal_places=4, default=0)
    cached_cost_per_yield_unit = models.DecimalField(max_digits=12, decimal_places=4, default=0)
    cached_food_cost_percent = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    cached_at = models.DateTimeField(null=True, blank=True)

    notes = models.TextField(blank=True)
    instructions = models.TextField(blank=True)
    version = models.PositiveIntegerField(default=1)

    class Meta:
        ordering = ["name"]
        constraints = [
            models.UniqueConstraint(fields=["restaurant", "slug"], name="unique_recipe_slug"),
        ]
        indexes = [
            models.Index(fields=["restaurant", "archived_at"]),
            models.Index(fields=["menu_item"]),
        ]

    def __str__(self) -> str:
        return self.name

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)[:80]
        super().save(*args, **kwargs)


class RecipeIngredient(TimeStampedModel):
    """A line item: this recipe uses Q of ingredient X (in unit U)."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    recipe = models.ForeignKey(
        Recipe, on_delete=models.CASCADE, related_name="ingredients_used"
    )
    ingredient = models.ForeignKey(
        "ingredients.Ingredient", on_delete=models.PROTECT,
        related_name="recipe_lines",
    )
    quantity = models.DecimalField(max_digits=10, decimal_places=4)
    unit = models.CharField(max_length=20)
    notes = models.CharField(max_length=200, blank=True)
    sort = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["sort", "id"]
        constraints = [
            models.UniqueConstraint(
                fields=["recipe", "ingredient"], name="unique_recipe_ingredient",
            ),
        ]


class RecipeInstruction(TimeStampedModel):
    """Ordered list of preparation steps for the recipe."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    recipe = models.ForeignKey(
        Recipe, on_delete=models.CASCADE, related_name="instructions_steps"
    )
    sort = models.PositiveIntegerField(default=0)
    text = models.TextField()
    duration_minutes = models.PositiveIntegerField(null=True, blank=True)

    class Meta:
        ordering = ["sort"]


class RecipeVersion(TimeStampedModel):
    """Snapshot of a recipe + ingredients before each save. Auditable history."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    recipe = models.ForeignKey(
        Recipe, on_delete=models.CASCADE, related_name="versions"
    )
    version = models.PositiveIntegerField()
    snapshot = models.JSONField()
    saved_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="+",
    )

    class Meta:
        ordering = ["-version"]
