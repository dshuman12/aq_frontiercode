"""Refresh cached recipe costs across the restaurant. Useful after a vendor
price update or a yield-factor change."""
from __future__ import annotations

from django.core.management.base import BaseCommand

from apps.recipes.models import Recipe
from apps.recipes.services import cache_recipe_cost
from apps.restaurants.models import Restaurant


class Command(BaseCommand):
    help = "Recompute cached recipe costs."

    def add_arguments(self, parser):
        parser.add_argument("--restaurant", required=True)

    def handle(self, *args, restaurant, **options):
        rest = Restaurant.objects.get(slug=restaurant)
        recipes = Recipe.objects.filter(
            restaurant=rest, archived_at__isnull=True,
        )
        for r in recipes:
            cache_recipe_cost(recipe=r)
        self.stdout.write(self.style.SUCCESS(
            f"Recomputed cost for {recipes.count()} recipes.",
        ))
