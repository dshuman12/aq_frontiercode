from django.urls import path

from . import views

app_name = "recipes"

urlpatterns = [
    path("<uuid:restaurant_id>/", views.RecipeListCreate.as_view(), name="list-create"),
    path("<uuid:restaurant_id>/<uuid:recipe_id>/",
         views.RecipeDetail.as_view(), name="detail"),
    path("<uuid:restaurant_id>/<uuid:recipe_id>/ingredients/",
         views.RecipeIngredientCreate.as_view(), name="add-ingredient"),
    path("<uuid:restaurant_id>/<uuid:recipe_id>/cost/",
         views.RecipeCostingView.as_view(), name="cost"),
    path("<uuid:restaurant_id>/<uuid:recipe_id>/versions/",
         views.RecipeVersionList.as_view(), name="versions"),
    path("<uuid:restaurant_id>/lines/<uuid:line_id>/",
         views.RecipeIngredientDetail.as_view(), name="line-detail"),
]
