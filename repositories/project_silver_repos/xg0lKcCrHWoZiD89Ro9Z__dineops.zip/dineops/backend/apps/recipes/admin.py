from django.contrib import admin

from .models import Recipe, RecipeIngredient, RecipeInstruction, RecipeVersion


class RecipeIngredientInline(admin.TabularInline):
    model = RecipeIngredient
    extra = 0


@admin.register(Recipe)
class RecipeAdmin(admin.ModelAdmin):
    list_display = ("name", "restaurant", "kind", "selling_price",
                    "cached_food_cost_percent", "version", "archived_at")
    list_filter = ("kind",)
    search_fields = ("name",)
    inlines = [RecipeIngredientInline]


@admin.register(RecipeVersion)
class RecipeVersionAdmin(admin.ModelAdmin):
    list_display = ("recipe", "version", "saved_by", "created_at")
