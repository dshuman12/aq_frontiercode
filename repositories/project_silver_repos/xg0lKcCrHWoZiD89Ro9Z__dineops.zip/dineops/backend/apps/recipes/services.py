from __future__ import annotations

from decimal import Decimal
from typing import Iterable

from django.db import transaction
from django.utils import timezone

from apps.common.exceptions import Conflict, NotFound, ValidationError
from apps.ingredients.models import Ingredient

from .models import Recipe, RecipeIngredient, RecipeInstruction, RecipeVersion


# --- unit conversion (very intentionally limited; we don't try to be a units library) ---

_WEIGHT_BASE_GRAMS = {
    "g": Decimal("1"),
    "kg": Decimal("1000"),
    "oz": Decimal("28.3495"),
    "lb": Decimal("453.5924"),
}
_VOLUME_BASE_ML = {
    "ml": Decimal("1"),
    "l": Decimal("1000"),
    "tsp": Decimal("4.92892"),
    "tbsp": Decimal("14.7868"),
    "cup": Decimal("240"),
}
_PIECE_UNITS = {"each", "dozen", "case"}


def convert_quantity(quantity: Decimal, from_unit: str, to_unit: str) -> Decimal:
    """Convert quantity between compatible units. Raises ValidationError when
    the conversion is impossible (e.g. grams → cups)."""
    if from_unit == to_unit:
        return quantity
    if from_unit in _WEIGHT_BASE_GRAMS and to_unit in _WEIGHT_BASE_GRAMS:
        grams = quantity * _WEIGHT_BASE_GRAMS[from_unit]
        return (grams / _WEIGHT_BASE_GRAMS[to_unit]).quantize(Decimal("0.0001"))
    if from_unit in _VOLUME_BASE_ML and to_unit in _VOLUME_BASE_ML:
        ml = quantity * _VOLUME_BASE_ML[from_unit]
        return (ml / _VOLUME_BASE_ML[to_unit]).quantize(Decimal("0.0001"))
    if from_unit in _PIECE_UNITS and to_unit in _PIECE_UNITS:
        # rough approximations — dozen=12, case=24
        if from_unit == "dozen" and to_unit == "each":
            return (quantity * 12).quantize(Decimal("0.0001"))
        if from_unit == "case" and to_unit == "each":
            return (quantity * 24).quantize(Decimal("0.0001"))
        if from_unit == "each" and to_unit == "dozen":
            return (quantity / 12).quantize(Decimal("0.0001"))
    raise ValidationError(
        "incompatible_units",
        f"Cannot convert {from_unit} to {to_unit}.",
        from_unit=from_unit, to_unit=to_unit,
    )


def calculate_recipe_cost(recipe: Recipe) -> dict:
    """Pure function: compute current cost from ingredient lines and prices."""
    total = Decimal("0")
    lines = []
    for line in recipe.ingredients_used.select_related("ingredient").all():
        ingredient = line.ingredient
        try:
            qty_in_base = convert_quantity(
                line.quantity, line.unit, ingredient.base_unit,
            )
        except ValidationError:
            qty_in_base = line.quantity  # fall back; UI should warn
        line_cost = qty_in_base * ingredient.effective_cost_per_unit
        total += line_cost
        lines.append({
            "ingredient_id": ingredient.id,
            "name": ingredient.name,
            "quantity": line.quantity,
            "unit": line.unit,
            "line_cost": line_cost.quantize(Decimal("0.0001")),
        })
    yield_qty = recipe.yield_quantity or Decimal("1")
    cost_per_yield = (total / yield_qty).quantize(Decimal("0.0001")) if yield_qty else total
    food_cost_pct = Decimal("0")
    if recipe.selling_price and recipe.selling_price > 0:
        food_cost_pct = (cost_per_yield / recipe.selling_price * 100).quantize(Decimal("0.01"))
    return {
        "lines": lines,
        "total_cost": total.quantize(Decimal("0.0001")),
        "cost_per_yield_unit": cost_per_yield,
        "food_cost_percent": food_cost_pct,
    }


def gross_margin_percent(cost: Decimal, selling_price: Decimal) -> Decimal:
    if not selling_price or selling_price == 0:
        return Decimal("0")
    return ((selling_price - cost) / selling_price * 100).quantize(Decimal("0.01"))


@transaction.atomic
def cache_recipe_cost(*, recipe: Recipe) -> Recipe:
    summary = calculate_recipe_cost(recipe)
    recipe.cached_total_cost = summary["total_cost"]
    recipe.cached_cost_per_yield_unit = summary["cost_per_yield_unit"]
    recipe.cached_food_cost_percent = summary["food_cost_percent"]
    recipe.cached_at = timezone.now()
    recipe.save(update_fields=[
        "cached_total_cost", "cached_cost_per_yield_unit",
        "cached_food_cost_percent", "cached_at",
    ])
    return recipe


@transaction.atomic
def create_recipe(*, restaurant, name: str, **fields) -> Recipe:
    if not name.strip():
        raise ValidationError("invalid_name")
    recipe = Recipe.objects.create(
        restaurant=restaurant,
        name=name.strip(),
        **fields,
    )
    return recipe


@transaction.atomic
def add_ingredient(*, recipe: Recipe, ingredient: Ingredient,
                   quantity: Decimal, unit: str, notes: str = "",
                   sort: int = 0) -> RecipeIngredient:
    if quantity is None or quantity <= 0:
        raise ValidationError("invalid_quantity")
    if RecipeIngredient.objects.filter(recipe=recipe, ingredient=ingredient).exists():
        raise Conflict("ingredient_already_in_recipe")
    line = RecipeIngredient.objects.create(
        recipe=recipe, ingredient=ingredient,
        quantity=quantity, unit=unit, notes=notes, sort=sort,
    )
    cache_recipe_cost(recipe=recipe)
    return line


@transaction.atomic
def update_ingredient_line(*, line: RecipeIngredient, quantity=None, unit=None,
                           notes=None) -> RecipeIngredient:
    if quantity is not None:
        if quantity <= 0:
            raise ValidationError("invalid_quantity")
        line.quantity = quantity
    if unit is not None:
        line.unit = unit
    if notes is not None:
        line.notes = notes
    line.save()
    cache_recipe_cost(recipe=line.recipe)
    return line


@transaction.atomic
def remove_ingredient(*, line: RecipeIngredient):
    recipe = line.recipe
    line.delete()
    cache_recipe_cost(recipe=recipe)


@transaction.atomic
def save_version_snapshot(*, recipe: Recipe, actor=None) -> RecipeVersion:
    """Take a snapshot of the recipe + lines for history."""
    snapshot = {
        "name": recipe.name,
        "yield_quantity": str(recipe.yield_quantity),
        "yield_unit": recipe.yield_unit,
        "portion_size": str(recipe.portion_size),
        "portion_unit": recipe.portion_unit,
        "selling_price": str(recipe.selling_price),
        "instructions": recipe.instructions,
        "lines": [
            {
                "ingredient_id": str(l.ingredient_id),
                "ingredient_name": l.ingredient.name,
                "quantity": str(l.quantity),
                "unit": l.unit,
                "notes": l.notes,
            }
            for l in recipe.ingredients_used.select_related("ingredient").all()
        ],
    }
    version = RecipeVersion.objects.create(
        recipe=recipe, version=recipe.version, snapshot=snapshot, saved_by=actor,
    )
    recipe.version = recipe.version + 1
    recipe.save(update_fields=["version"])
    return version
