"""Cross-app smoke tests for recipes module imports."""
import pytest


pytestmark = pytest.mark.django_db


def test_recipes_module_imports():
    from apps.recipes import models, services, serializers, views, urls
    assert all([models, services, serializers, views, urls])
