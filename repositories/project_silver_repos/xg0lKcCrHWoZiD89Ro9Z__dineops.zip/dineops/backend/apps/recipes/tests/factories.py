from __future__ import annotations

import uuid
from decimal import Decimal

import factory

from apps.ingredients.models import Ingredient
from apps.recipes.models import Recipe, RecipeIngredient


class RecipeFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = Recipe

    name = factory.Sequence(lambda n: f"Recipe {n}")
    yield_quantity = Decimal("1")
    yield_unit = "each"
    portion_size = Decimal("1")
    portion_unit = "each"
    selling_price = Decimal("18.00")
    target_food_cost_percent = Decimal("30")


class RecipeIngredientFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = RecipeIngredient

    quantity = Decimal("100")
    unit = "g"
    sort = 0
