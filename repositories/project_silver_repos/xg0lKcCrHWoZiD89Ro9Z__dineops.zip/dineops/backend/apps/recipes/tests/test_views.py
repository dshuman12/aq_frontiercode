from __future__ import annotations

from decimal import Decimal

import pytest
from rest_framework.test import APIClient

from apps.accounts.models import User
from apps.ingredients.models import Ingredient
from apps.recipes.models import Recipe
from apps.recipes.services import add_ingredient, create_recipe
from apps.restaurants.models import Restaurant, RestaurantMember


pytestmark = pytest.mark.django_db


def _login(user):
    client = APIClient()
    client.force_authenticate(user=user)
    return client


@pytest.fixture
def restaurant_setup():
    owner = User.objects.create_user(email="o@x.com", password="pwpwpwpw")
    rest = Restaurant.objects.create(name="R", slug="r", owner=owner)
    RestaurantMember.objects.create(
        restaurant=rest, user=owner, roles=["owner"], status="active",
    )
    chef_user = User.objects.create_user(email="chef@x.com", password="pwpwpwpw")
    RestaurantMember.objects.create(
        restaurant=rest, user=chef_user, roles=["chef"], status="active",
    )
    server_user = User.objects.create_user(email="srv@x.com", password="pwpwpwpw")
    RestaurantMember.objects.create(
        restaurant=rest, user=server_user, roles=["server"], status="active",
    )
    outsider = User.objects.create_user(email="out@x.com", password="pwpwpwpw")
    return {
        "rest": rest,
        "owner": owner,
        "chef": chef_user,
        "server": server_user,
        "outsider": outsider,
    }


class TestRecipeListCreate:
    def test_create_as_chef(self, restaurant_setup):
        s = restaurant_setup
        client = _login(s["chef"])
        resp = client.post(
            f"/api/recipes/{s['rest'].id}/",
            {"name": "Bolognese", "yield_quantity": "4", "selling_price": "18.00"},
            format="json",
        )
        assert resp.status_code == 201
        assert resp.data["recipe"]["name"] == "Bolognese"
        assert resp.data["recipe"]["slug"] == "bolognese"

    def test_server_cannot_create(self, restaurant_setup):
        s = restaurant_setup
        client = _login(s["server"])
        resp = client.post(
            f"/api/recipes/{s['rest'].id}/", {"name": "X"}, format="json",
        )
        assert resp.status_code == 403

    def test_outsider_cannot_list(self, restaurant_setup):
        s = restaurant_setup
        client = _login(s["outsider"])
        resp = client.get(f"/api/recipes/{s['rest'].id}/")
        assert resp.status_code == 403

    def test_unauth_rejected(self, restaurant_setup):
        client = APIClient()
        s = restaurant_setup
        resp = client.get(f"/api/recipes/{s['rest'].id}/")
        assert resp.status_code in (401, 403)

    def test_list_filters_by_q(self, restaurant_setup):
        s = restaurant_setup
        create_recipe(restaurant=s["rest"], name="Tomato Soup")
        create_recipe(restaurant=s["rest"], name="Beef Stew")
        client = _login(s["owner"])
        resp = client.get(f"/api/recipes/{s['rest'].id}/?q=tomato")
        assert resp.status_code == 200
        assert len(resp.data["results"]) == 1

    def test_list_excludes_archived(self, restaurant_setup):
        s = restaurant_setup
        rec = create_recipe(restaurant=s["rest"], name="Old Dish")
        rec.archive()
        create_recipe(restaurant=s["rest"], name="New Dish")
        client = _login(s["owner"])
        resp = client.get(f"/api/recipes/{s['rest'].id}/")
        assert len(resp.data["results"]) == 1


class TestRecipeDetail:
    def test_get(self, restaurant_setup):
        s = restaurant_setup
        rec = create_recipe(restaurant=s["rest"], name="Curry")
        client = _login(s["owner"])
        resp = client.get(f"/api/recipes/{s['rest'].id}/{rec.id}/")
        assert resp.status_code == 200
        assert resp.data["recipe"]["name"] == "Curry"

    def test_get_missing_404(self, restaurant_setup):
        s = restaurant_setup
        import uuid
        client = _login(s["owner"])
        resp = client.get(f"/api/recipes/{s['rest'].id}/{uuid.uuid4()}/")
        assert resp.status_code == 404

    def test_patch_creates_snapshot(self, restaurant_setup):
        s = restaurant_setup
        rec = create_recipe(restaurant=s["rest"], name="Dish")
        client = _login(s["chef"])
        resp = client.patch(
            f"/api/recipes/{s['rest'].id}/{rec.id}/",
            {"selling_price": "25.00"}, format="json",
        )
        assert resp.status_code == 200
        rec.refresh_from_db()
        assert rec.selling_price == Decimal("25.00")
        assert rec.versions.count() == 1

    def test_server_cannot_patch(self, restaurant_setup):
        s = restaurant_setup
        rec = create_recipe(restaurant=s["rest"], name="Dish")
        client = _login(s["server"])
        resp = client.patch(
            f"/api/recipes/{s['rest'].id}/{rec.id}/",
            {"name": "stolen"}, format="json",
        )
        assert resp.status_code == 403


class TestRecipeIngredientEndpoints:
    def test_add_ingredient(self, restaurant_setup):
        s = restaurant_setup
        rec = create_recipe(restaurant=s["rest"], name="Burger")
        ing = Ingredient.objects.create(
            restaurant=s["rest"], name="Beef", base_unit="g",
            cost_per_unit=Decimal("0.04"), yield_factor=Decimal("0.85"),
        )
        client = _login(s["chef"])
        resp = client.post(
            f"/api/recipes/{s['rest'].id}/{rec.id}/ingredients/",
            {"ingredient_id": str(ing.id), "quantity": "150", "unit": "g"},
            format="json",
        )
        assert resp.status_code == 201
        assert resp.data["line"]["quantity"] == "150.0000"

    def test_add_unknown_ingredient_404(self, restaurant_setup):
        import uuid
        s = restaurant_setup
        rec = create_recipe(restaurant=s["rest"], name="Burger")
        client = _login(s["chef"])
        resp = client.post(
            f"/api/recipes/{s['rest'].id}/{rec.id}/ingredients/",
            {"ingredient_id": str(uuid.uuid4()), "quantity": "1", "unit": "g"},
            format="json",
        )
        assert resp.status_code == 404

    def test_update_line(self, restaurant_setup):
        s = restaurant_setup
        rec = create_recipe(restaurant=s["rest"], name="Burger")
        ing = Ingredient.objects.create(
            restaurant=s["rest"], name="Beef", base_unit="g",
            cost_per_unit=Decimal("0.04"),
        )
        line = add_ingredient(recipe=rec, ingredient=ing,
                              quantity=Decimal("100"), unit="g")
        client = _login(s["chef"])
        resp = client.patch(
            f"/api/recipes/{s['rest'].id}/lines/{line.id}/",
            {"quantity": "200"}, format="json",
        )
        assert resp.status_code == 200
        line.refresh_from_db()
        assert line.quantity == Decimal("200.0000")

    def test_delete_line(self, restaurant_setup):
        s = restaurant_setup
        rec = create_recipe(restaurant=s["rest"], name="Burger")
        ing = Ingredient.objects.create(
            restaurant=s["rest"], name="Beef", base_unit="g",
        )
        line = add_ingredient(recipe=rec, ingredient=ing,
                              quantity=Decimal("100"), unit="g")
        client = _login(s["chef"])
        resp = client.delete(f"/api/recipes/{s['rest'].id}/lines/{line.id}/")
        assert resp.status_code == 200
        assert not type(line).objects.filter(id=line.id).exists()

    def test_server_cannot_add(self, restaurant_setup):
        s = restaurant_setup
        rec = create_recipe(restaurant=s["rest"], name="Burger")
        ing = Ingredient.objects.create(
            restaurant=s["rest"], name="Beef", base_unit="g",
        )
        client = _login(s["server"])
        resp = client.post(
            f"/api/recipes/{s['rest'].id}/{rec.id}/ingredients/",
            {"ingredient_id": str(ing.id), "quantity": "1", "unit": "g"},
            format="json",
        )
        assert resp.status_code == 403


class TestRecipeCosting:
    def test_costing_endpoint(self, restaurant_setup):
        s = restaurant_setup
        rec = create_recipe(
            restaurant=s["rest"], name="Burger",
            selling_price=Decimal("12.00"),
        )
        ing = Ingredient.objects.create(
            restaurant=s["rest"], name="Beef", base_unit="g",
            cost_per_unit=Decimal("0.05"), yield_factor=Decimal("1"),
        )
        add_ingredient(recipe=rec, ingredient=ing,
                       quantity=Decimal("100"), unit="g")
        client = _login(s["owner"])
        resp = client.get(f"/api/recipes/{s['rest'].id}/{rec.id}/cost/")
        assert resp.status_code == 200
        assert resp.data["total_cost"] == "5.0000"

    def test_versions_endpoint(self, restaurant_setup):
        s = restaurant_setup
        rec = create_recipe(restaurant=s["rest"], name="V")
        client = _login(s["chef"])
        client.patch(f"/api/recipes/{s['rest'].id}/{rec.id}/",
                     {"selling_price": "20.00"}, format="json")
        client.patch(f"/api/recipes/{s['rest'].id}/{rec.id}/",
                     {"selling_price": "22.00"}, format="json")
        resp = client.get(f"/api/recipes/{s['rest'].id}/{rec.id}/versions/")
        assert resp.status_code == 200
        assert len(resp.data["results"]) == 2
