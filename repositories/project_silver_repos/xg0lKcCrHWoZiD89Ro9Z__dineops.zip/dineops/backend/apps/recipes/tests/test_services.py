from __future__ import annotations

from decimal import Decimal

import pytest

from apps.common.exceptions import Conflict, ValidationError
from apps.ingredients.models import Ingredient
from apps.recipes.models import Recipe, RecipeIngredient, RecipeVersion
from apps.recipes.services import (
    add_ingredient,
    cache_recipe_cost,
    calculate_recipe_cost,
    convert_quantity,
    create_recipe,
    gross_margin_percent,
    remove_ingredient,
    save_version_snapshot,
    update_ingredient_line,
)
from apps.restaurants.models import Restaurant


pytestmark = pytest.mark.django_db


def _make_restaurant(owner_email="r@x.com"):
    from apps.accounts.models import User
    owner = User.objects.create_user(email=owner_email, password="pwpwpwpw")
    return Restaurant.objects.create(name="R", slug="r", owner=owner)


def _make_ingredient(restaurant, *, name="Beef", base_unit="g",
                     cost=Decimal("0.04"), yield_factor=Decimal("0.85")):
    return Ingredient.objects.create(
        restaurant=restaurant, name=name, base_unit=base_unit,
        cost_per_unit=cost, yield_factor=yield_factor,
    )


# -------------------- convert_quantity --------------------

class TestConvertQuantity:
    def test_same_unit_returns_input(self):
        assert convert_quantity(Decimal("12"), "g", "g") == Decimal("12")

    def test_kg_to_g(self):
        assert convert_quantity(Decimal("1"), "kg", "g") == Decimal("1000.0000")

    def test_lb_to_oz(self):
        # 1 lb = 16 oz (with floating constants we get ~16.0001)
        result = convert_quantity(Decimal("1"), "lb", "oz")
        assert abs(result - Decimal("16")) < Decimal("0.01")

    def test_l_to_ml(self):
        assert convert_quantity(Decimal("0.5"), "l", "ml") == Decimal("500.0000")

    def test_tbsp_to_tsp(self):
        # 1 tbsp ≈ 3 tsp
        result = convert_quantity(Decimal("1"), "tbsp", "tsp")
        assert abs(result - Decimal("3")) < Decimal("0.01")

    def test_dozen_to_each(self):
        assert convert_quantity(Decimal("2"), "dozen", "each") == Decimal("24.0000")

    def test_case_to_each(self):
        assert convert_quantity(Decimal("1"), "case", "each") == Decimal("24.0000")

    def test_each_to_dozen(self):
        assert convert_quantity(Decimal("12"), "each", "dozen") == Decimal("1.0000")

    def test_weight_to_volume_raises(self):
        with pytest.raises(ValidationError) as exc_info:
            convert_quantity(Decimal("100"), "g", "ml")
        assert exc_info.value.code == "incompatible_units"

    def test_weight_to_piece_raises(self):
        with pytest.raises(ValidationError):
            convert_quantity(Decimal("100"), "g", "each")

    def test_unknown_unit_raises(self):
        with pytest.raises(ValidationError):
            convert_quantity(Decimal("1"), "stone", "g")


# -------------------- create_recipe --------------------

class TestCreateRecipe:
    def test_creates_with_slug(self):
        r = _make_restaurant()
        rec = create_recipe(restaurant=r, name="Bolognese Pasta")
        assert rec.slug == "bolognese-pasta"
        assert rec.version == 1

    def test_blank_name_rejected(self):
        r = _make_restaurant()
        with pytest.raises(ValidationError):
            create_recipe(restaurant=r, name="   ")

    def test_extra_fields_pass_through(self):
        r = _make_restaurant()
        rec = create_recipe(
            restaurant=r, name="Stew",
            yield_quantity=Decimal("4"), yield_unit="each",
            selling_price=Decimal("22.50"),
        )
        assert rec.yield_quantity == Decimal("4.000")
        assert rec.selling_price == Decimal("22.50")


# -------------------- add_ingredient --------------------

class TestAddIngredient:
    def test_creates_line(self):
        r = _make_restaurant()
        rec = create_recipe(restaurant=r, name="Burger")
        ing = _make_ingredient(r)
        line = add_ingredient(
            recipe=rec, ingredient=ing,
            quantity=Decimal("150"), unit="g",
        )
        assert line.quantity == Decimal("150.0000")

    def test_zero_quantity_rejected(self):
        r = _make_restaurant()
        rec = create_recipe(restaurant=r, name="Burger")
        ing = _make_ingredient(r)
        with pytest.raises(ValidationError):
            add_ingredient(recipe=rec, ingredient=ing,
                           quantity=Decimal("0"), unit="g")

    def test_negative_quantity_rejected(self):
        r = _make_restaurant()
        rec = create_recipe(restaurant=r, name="Burger")
        ing = _make_ingredient(r)
        with pytest.raises(ValidationError):
            add_ingredient(recipe=rec, ingredient=ing,
                           quantity=Decimal("-2"), unit="g")

    def test_duplicate_ingredient_rejected(self):
        r = _make_restaurant()
        rec = create_recipe(restaurant=r, name="Burger")
        ing = _make_ingredient(r)
        add_ingredient(recipe=rec, ingredient=ing,
                       quantity=Decimal("150"), unit="g")
        with pytest.raises(Conflict):
            add_ingredient(recipe=rec, ingredient=ing,
                           quantity=Decimal("160"), unit="g")

    def test_triggers_cost_cache(self):
        r = _make_restaurant()
        rec = create_recipe(restaurant=r, name="Burger",
                            selling_price=Decimal("12.00"))
        ing = _make_ingredient(r, cost=Decimal("0.05"),
                               yield_factor=Decimal("1"))
        add_ingredient(recipe=rec, ingredient=ing,
                       quantity=Decimal("100"), unit="g")
        rec.refresh_from_db()
        # 100g * $0.05/g = $5.00 total cost
        assert rec.cached_total_cost == Decimal("5.0000")
        assert rec.cached_at is not None


# -------------------- update_ingredient_line --------------------

class TestUpdateIngredientLine:
    def test_updates_quantity(self):
        r = _make_restaurant()
        rec = create_recipe(restaurant=r, name="Soup")
        ing = _make_ingredient(r)
        line = add_ingredient(recipe=rec, ingredient=ing,
                              quantity=Decimal("100"), unit="g")
        update_ingredient_line(line=line, quantity=Decimal("200"))
        line.refresh_from_db()
        assert line.quantity == Decimal("200.0000")

    def test_updates_unit_and_notes(self):
        r = _make_restaurant()
        rec = create_recipe(restaurant=r, name="Soup")
        ing = _make_ingredient(r)
        line = add_ingredient(recipe=rec, ingredient=ing,
                              quantity=Decimal("100"), unit="g")
        update_ingredient_line(line=line, unit="kg", notes="diced fine")
        line.refresh_from_db()
        assert line.unit == "kg"
        assert line.notes == "diced fine"

    def test_zero_quantity_rejected(self):
        r = _make_restaurant()
        rec = create_recipe(restaurant=r, name="Soup")
        ing = _make_ingredient(r)
        line = add_ingredient(recipe=rec, ingredient=ing,
                              quantity=Decimal("100"), unit="g")
        with pytest.raises(ValidationError):
            update_ingredient_line(line=line, quantity=Decimal("0"))


# -------------------- remove_ingredient --------------------

class TestRemoveIngredient:
    def test_removes_line_and_recaches(self):
        r = _make_restaurant()
        rec = create_recipe(restaurant=r, name="Soup",
                            selling_price=Decimal("10.00"))
        ing = _make_ingredient(r, cost=Decimal("0.04"),
                               yield_factor=Decimal("1"))
        line = add_ingredient(recipe=rec, ingredient=ing,
                              quantity=Decimal("50"), unit="g")
        rec.refresh_from_db()
        assert rec.cached_total_cost > Decimal("0")
        remove_ingredient(line=line)
        assert not RecipeIngredient.objects.filter(id=line.id).exists()
        rec.refresh_from_db()
        assert rec.cached_total_cost == Decimal("0.0000")


# -------------------- calculate_recipe_cost --------------------

class TestCalculateRecipeCost:
    def test_single_ingredient(self):
        r = _make_restaurant()
        rec = create_recipe(restaurant=r, name="Plate",
                            selling_price=Decimal("20.00"))
        ing = _make_ingredient(r, cost=Decimal("0.10"),
                               yield_factor=Decimal("1"))
        add_ingredient(recipe=rec, ingredient=ing,
                       quantity=Decimal("100"), unit="g")
        result = calculate_recipe_cost(rec)
        # 100g * $0.10/g = $10.00; sold at $20 = 50%
        assert result["total_cost"] == Decimal("10.0000")
        assert result["food_cost_percent"] == Decimal("50.00")
        assert len(result["lines"]) == 1

    def test_yield_loss_increases_cost(self):
        r = _make_restaurant()
        rec = create_recipe(restaurant=r, name="Plate",
                            selling_price=Decimal("10.00"))
        # cost = $1/g, but only 80% yields → effective $1.25/g
        ing = _make_ingredient(r, cost=Decimal("1"),
                               yield_factor=Decimal("0.8"))
        add_ingredient(recipe=rec, ingredient=ing,
                       quantity=Decimal("4"), unit="g")
        result = calculate_recipe_cost(rec)
        # 4g * 1.25 = 5.00
        assert result["total_cost"] == Decimal("5.0000")

    def test_yield_quantity_divides_cost(self):
        r = _make_restaurant()
        rec = create_recipe(restaurant=r, name="Batch",
                            yield_quantity=Decimal("4"),
                            yield_unit="each",
                            selling_price=Decimal("8.00"))
        ing = _make_ingredient(r, cost=Decimal("0.05"),
                               yield_factor=Decimal("1"))
        add_ingredient(recipe=rec, ingredient=ing,
                       quantity=Decimal("400"), unit="g")
        result = calculate_recipe_cost(rec)
        # total $20, /4 portions = $5/portion
        assert result["total_cost"] == Decimal("20.0000")
        assert result["cost_per_yield_unit"] == Decimal("5.0000")

    def test_zero_selling_price_means_zero_food_cost_pct(self):
        r = _make_restaurant()
        rec = create_recipe(restaurant=r, name="Free",
                            selling_price=Decimal("0"))
        ing = _make_ingredient(r, cost=Decimal("0.05"),
                               yield_factor=Decimal("1"))
        add_ingredient(recipe=rec, ingredient=ing,
                       quantity=Decimal("10"), unit="g")
        result = calculate_recipe_cost(rec)
        assert result["food_cost_percent"] == Decimal("0")

    def test_unit_mismatch_falls_back(self):
        # If unit on line doesn't match ingredient.base_unit and isn't convertible,
        # the calculation should not crash; it falls back to raw qty * cost.
        r = _make_restaurant()
        rec = create_recipe(restaurant=r, name="Mismatch",
                            selling_price=Decimal("0"))
        ing = _make_ingredient(r, base_unit="g", cost=Decimal("0.05"),
                               yield_factor=Decimal("1"))
        add_ingredient(recipe=rec, ingredient=ing,
                       quantity=Decimal("3"), unit="each")
        result = calculate_recipe_cost(rec)
        # 3 * 0.05 (no conversion) = 0.15
        assert result["total_cost"] == Decimal("0.1500")


# -------------------- gross_margin_percent --------------------

class TestGrossMargin:
    def test_typical(self):
        # cost 5, price 20 → margin = 15/20 = 75%
        assert gross_margin_percent(Decimal("5"), Decimal("20")) == Decimal("75.00")

    def test_zero_price_returns_zero(self):
        assert gross_margin_percent(Decimal("5"), Decimal("0")) == Decimal("0")

    def test_cost_equals_price(self):
        assert gross_margin_percent(Decimal("10"), Decimal("10")) == Decimal("0.00")


# -------------------- cache_recipe_cost --------------------

class TestCacheRecipeCost:
    def test_writes_cached_fields(self):
        r = _make_restaurant()
        rec = create_recipe(restaurant=r, name="CR",
                            selling_price=Decimal("12.00"))
        ing = _make_ingredient(r, cost=Decimal("0.10"),
                               yield_factor=Decimal("1"))
        add_ingredient(recipe=rec, ingredient=ing,
                       quantity=Decimal("60"), unit="g")
        cache_recipe_cost(recipe=rec)
        rec.refresh_from_db()
        assert rec.cached_total_cost == Decimal("6.0000")
        assert rec.cached_food_cost_percent == Decimal("50.00")
        assert rec.cached_at is not None


# -------------------- save_version_snapshot --------------------

class TestSaveVersionSnapshot:
    def test_creates_snapshot_and_increments(self):
        r = _make_restaurant()
        rec = create_recipe(restaurant=r, name="Versioned",
                            selling_price=Decimal("15.00"))
        ing = _make_ingredient(r)
        add_ingredient(recipe=rec, ingredient=ing,
                       quantity=Decimal("100"), unit="g")
        original_version = rec.version
        v = save_version_snapshot(recipe=rec)
        rec.refresh_from_db()
        assert v.version == original_version
        assert rec.version == original_version + 1
        assert v.snapshot["name"] == "Versioned"
        assert len(v.snapshot["lines"]) == 1

    def test_multiple_snapshots(self):
        r = _make_restaurant()
        rec = create_recipe(restaurant=r, name="V")
        save_version_snapshot(recipe=rec)
        save_version_snapshot(recipe=rec)
        rec.refresh_from_db()
        assert RecipeVersion.objects.filter(recipe=rec).count() == 2
        assert rec.version == 3
