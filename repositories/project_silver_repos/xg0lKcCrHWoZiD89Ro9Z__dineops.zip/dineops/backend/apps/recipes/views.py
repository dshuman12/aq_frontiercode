from __future__ import annotations

from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common.exceptions import NotFound, PermissionDenied
from apps.ingredients.models import Ingredient
from apps.restaurants.models import Restaurant, RestaurantMember

from . import services
from .models import Recipe, RecipeIngredient
from .serializers import (
    AddIngredientLineSerializer,
    RecipeCreateSerializer,
    RecipeIngredientSerializer,
    RecipeSerializer,
    RecipeVersionSerializer,
)


def _require_member(user, restaurant_id) -> RestaurantMember:
    m = RestaurantMember.objects.filter(
        restaurant_id=restaurant_id, user=user, status="active"
    ).first()
    if not m:
        raise PermissionDenied("not_a_member")
    return m


def _can_write_recipes(roles):
    return any(r in ("owner", "general_manager", "chef") for r in roles or [])


class RecipeListCreate(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        _require_member(request.user, restaurant_id)
        qs = Recipe.objects.filter(
            restaurant_id=restaurant_id, archived_at__isnull=True,
        ).order_by("name")
        if (q := request.GET.get("q")):
            qs = qs.filter(name__icontains=q)
        return Response({"results": RecipeSerializer(qs[:200], many=True).data})

    def post(self, request, restaurant_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_write_recipes(member.roles):
            raise PermissionDenied()
        s = RecipeCreateSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        restaurant = Restaurant.objects.get(id=restaurant_id)
        recipe = services.create_recipe(restaurant=restaurant, **s.validated_data)
        return Response({"recipe": RecipeSerializer(recipe).data},
                        status=status.HTTP_201_CREATED)


class RecipeDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id, recipe_id):
        _require_member(request.user, restaurant_id)
        recipe = (
            Recipe.objects.filter(id=recipe_id, restaurant_id=restaurant_id)
            .prefetch_related("ingredients_used__ingredient", "instructions_steps")
            .first()
        )
        if not recipe:
            raise NotFound()
        return Response({"recipe": RecipeSerializer(recipe).data})

    def patch(self, request, restaurant_id, recipe_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_write_recipes(member.roles):
            raise PermissionDenied()
        recipe = Recipe.objects.filter(id=recipe_id, restaurant_id=restaurant_id).first()
        if not recipe:
            raise NotFound()
        # Save snapshot before changes
        services.save_version_snapshot(recipe=recipe, actor=request.user)
        for k, v in request.data.items():
            if k in (
                "name", "yield_quantity", "yield_unit",
                "portion_size", "portion_unit",
                "selling_price", "target_food_cost_percent",
                "notes", "instructions",
            ):
                setattr(recipe, k, v)
        recipe.save()
        services.cache_recipe_cost(recipe=recipe)
        return Response({"recipe": RecipeSerializer(recipe).data})


class RecipeIngredientCreate(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, recipe_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_write_recipes(member.roles):
            raise PermissionDenied()
        recipe = Recipe.objects.filter(id=recipe_id, restaurant_id=restaurant_id).first()
        if not recipe:
            raise NotFound()
        s = AddIngredientLineSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        ingredient = Ingredient.objects.filter(
            id=s.validated_data["ingredient_id"], restaurant_id=restaurant_id,
        ).first()
        if not ingredient:
            raise NotFound("ingredient_not_found")
        line = services.add_ingredient(
            recipe=recipe, ingredient=ingredient,
            quantity=s.validated_data["quantity"],
            unit=s.validated_data["unit"],
            notes=s.validated_data.get("notes", ""),
            sort=s.validated_data.get("sort", 0),
        )
        return Response({"line": RecipeIngredientSerializer(line).data}, status=201)


class RecipeIngredientDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def patch(self, request, restaurant_id, line_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_write_recipes(member.roles):
            raise PermissionDenied()
        line = RecipeIngredient.objects.filter(
            id=line_id, recipe__restaurant_id=restaurant_id,
        ).select_related("recipe").first()
        if not line:
            raise NotFound()
        services.update_ingredient_line(
            line=line,
            quantity=request.data.get("quantity"),
            unit=request.data.get("unit"),
            notes=request.data.get("notes"),
        )
        return Response({"line": RecipeIngredientSerializer(line).data})

    def delete(self, request, restaurant_id, line_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_write_recipes(member.roles):
            raise PermissionDenied()
        line = RecipeIngredient.objects.filter(
            id=line_id, recipe__restaurant_id=restaurant_id,
        ).first()
        if not line:
            raise NotFound()
        services.remove_ingredient(line=line)
        return Response({"ok": True})


class RecipeCostingView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id, recipe_id):
        _require_member(request.user, restaurant_id)
        recipe = Recipe.objects.filter(id=recipe_id, restaurant_id=restaurant_id).first()
        if not recipe:
            raise NotFound()
        return Response(services.calculate_recipe_cost(recipe))


class RecipeVersionList(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id, recipe_id):
        _require_member(request.user, restaurant_id)
        items = (
            Recipe.objects.filter(id=recipe_id, restaurant_id=restaurant_id)
            .prefetch_related("versions")
            .first()
        )
        if not items:
            raise NotFound()
        versions = items.versions.all()[:50]
        return Response({"results": RecipeVersionSerializer(versions, many=True).data})
