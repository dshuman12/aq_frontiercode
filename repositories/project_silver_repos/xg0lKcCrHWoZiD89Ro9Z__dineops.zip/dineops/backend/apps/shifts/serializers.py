from rest_framework import serializers

from .models import ShiftBreak, ShiftEditRequest, StaffShift, TimeClockEntry


class StaffShiftSerializer(serializers.ModelSerializer):
    duration_minutes = serializers.IntegerField(read_only=True)
    staff_name = serializers.SerializerMethodField()

    class Meta:
        model = StaffShift
        fields = (
            "id", "restaurant", "location", "staff", "staff_name",
            "role_label", "starts_at", "ends_at", "duration_minutes",
            "status", "notes", "created_at",
        )
        read_only_fields = ("id", "duration_minutes", "staff_name", "created_at")

    def get_staff_name(self, obj):
        return obj.staff.user.full_name


class ShiftCreateSerializer(serializers.Serializer):
    location_id = serializers.UUIDField()
    staff_id = serializers.UUIDField()
    role_label = serializers.CharField(max_length=80, required=False, allow_blank=True)
    starts_at = serializers.DateTimeField()
    ends_at = serializers.DateTimeField()
    notes = serializers.CharField(required=False, allow_blank=True)


class ShiftRescheduleSerializer(serializers.Serializer):
    starts_at = serializers.DateTimeField()
    ends_at = serializers.DateTimeField()


class TimeClockEntrySerializer(serializers.ModelSerializer):
    is_open = serializers.BooleanField(read_only=True)
    worked_minutes = serializers.IntegerField(read_only=True, source="worked_minutes")

    class Meta:
        model = TimeClockEntry
        fields = (
            "id", "staff", "shift", "location",
            "clocked_in_at", "clocked_out_at",
            "is_open", "edited", "edit_reason",
            "created_at",
        )


class ClockInSerializer(serializers.Serializer):
    location_id = serializers.UUIDField()
    staff_id = serializers.UUIDField()
    shift_id = serializers.UUIDField(required=False, allow_null=True)


class ClockOutSerializer(serializers.Serializer):
    pass


class BreakSerializer(serializers.ModelSerializer):
    class Meta:
        model = ShiftBreak
        fields = ("id", "kind", "started_at", "ended_at", "created_at")


class StartBreakSerializer(serializers.Serializer):
    kind = serializers.ChoiceField(choices=ShiftBreak.KIND_CHOICES, default="unpaid")


class EditRequestSerializer(serializers.ModelSerializer):
    class Meta:
        model = ShiftEditRequest
        fields = (
            "id", "entry", "proposed_clock_in", "proposed_clock_out",
            "reason", "status", "decided_at", "created_at",
        )
        read_only_fields = ("id", "status", "decided_at", "created_at")


class DecideEditRequestSerializer(serializers.Serializer):
    decision = serializers.ChoiceField(choices=["approved", "denied"])
