from django.urls import path

from . import views

app_name = "shifts"

urlpatterns = [
    path("<uuid:restaurant_id>/", views.ShiftListCreate.as_view(), name="list-create"),
    path("<uuid:restaurant_id>/<uuid:shift_id>/", views.ShiftDetail.as_view(), name="detail"),
    path("<uuid:restaurant_id>/clock-in/", views.ClockInView.as_view(), name="clock-in"),
    path("<uuid:restaurant_id>/entries/<uuid:entry_id>/clock-out/",
         views.ClockOutView.as_view(), name="clock-out"),
    path("<uuid:restaurant_id>/entries/<uuid:entry_id>/break/start/",
         views.BreakStartView.as_view(), name="break-start"),
    path("<uuid:restaurant_id>/breaks/<uuid:break_id>/end/",
         views.BreakEndView.as_view(), name="break-end"),
    path("<uuid:restaurant_id>/entries/<uuid:entry_id>/edit-request/",
         views.EditRequestCreate.as_view(), name="edit-request"),
    path("<uuid:restaurant_id>/edit-requests/<uuid:request_id>/decide/",
         views.EditRequestDecide.as_view(), name="edit-decide"),
    path("<uuid:restaurant_id>/labor-summary/",
         views.LaborSummaryView.as_view(), name="labor-summary"),
]
