from __future__ import annotations

import uuid
from decimal import Decimal

from django.conf import settings
from django.db import models
from django.utils import timezone

from apps.common.models import TimeStampedModel


class StaffShift(TimeStampedModel):
    """Scheduled shift for a staff member at a location."""

    STATUS_CHOICES = [
        ("scheduled", "Scheduled"),
        ("in_progress", "In progress"),
        ("completed", "Completed"),
        ("missed", "Missed"),
        ("cancelled", "Cancelled"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant = models.ForeignKey(
        "restaurants.Restaurant", on_delete=models.CASCADE, related_name="shifts"
    )
    location = models.ForeignKey(
        "locations.Location", on_delete=models.CASCADE, related_name="shifts"
    )
    staff = models.ForeignKey(
        "staff.StaffProfile", on_delete=models.CASCADE, related_name="shifts"
    )
    role_label = models.CharField(max_length=80, blank=True, help_text="e.g. Line cook")
    starts_at = models.DateTimeField(db_index=True)
    ends_at = models.DateTimeField(db_index=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="scheduled",
                              db_index=True)
    notes = models.TextField(blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="+",
    )

    class Meta:
        ordering = ["-starts_at"]
        indexes = [
            models.Index(fields=["restaurant", "starts_at"]),
            models.Index(fields=["staff", "starts_at"]),
            models.Index(fields=["location", "starts_at"]),
        ]

    @property
    def duration_minutes(self) -> int:
        return int((self.ends_at - self.starts_at).total_seconds() // 60)


class TimeClockEntry(TimeStampedModel):
    """A single clock-in/clock-out cycle. One TCE per shift, multiple breaks."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant = models.ForeignKey(
        "restaurants.Restaurant", on_delete=models.CASCADE, related_name="time_clock_entries"
    )
    location = models.ForeignKey(
        "locations.Location", on_delete=models.CASCADE, related_name="time_clock_entries"
    )
    staff = models.ForeignKey(
        "staff.StaffProfile", on_delete=models.CASCADE, related_name="time_clock_entries"
    )
    shift = models.ForeignKey(
        StaffShift, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="time_clock_entries",
    )
    clocked_in_at = models.DateTimeField()
    clocked_out_at = models.DateTimeField(null=True, blank=True)

    edited = models.BooleanField(default=False)
    edit_reason = models.CharField(max_length=200, blank=True)
    edited_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="+",
    )

    class Meta:
        ordering = ["-clocked_in_at"]
        indexes = [
            models.Index(fields=["staff", "clocked_in_at"]),
            models.Index(fields=["restaurant", "clocked_in_at"]),
        ]

    @property
    def is_open(self) -> bool:
        return self.clocked_out_at is None

    def worked_minutes(self) -> int:
        end = self.clocked_out_at or timezone.now()
        gross = int((end - self.clocked_in_at).total_seconds() // 60)
        # subtract finished breaks
        break_minutes = sum(
            b.duration_minutes() for b in self.breaks.all() if b.ended_at is not None
        )
        return max(0, gross - break_minutes)


class ShiftBreak(TimeStampedModel):
    """A break inside a TimeClockEntry."""

    KIND_CHOICES = [
        ("paid", "Paid break"),
        ("unpaid", "Unpaid break"),
        ("meal", "Meal break"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    entry = models.ForeignKey(
        TimeClockEntry, on_delete=models.CASCADE, related_name="breaks"
    )
    kind = models.CharField(max_length=20, choices=KIND_CHOICES, default="unpaid")
    started_at = models.DateTimeField()
    ended_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["started_at"]

    def duration_minutes(self) -> int:
        end = self.ended_at or timezone.now()
        return max(0, int((end - self.started_at).total_seconds() // 60))


class ShiftEditRequest(TimeStampedModel):
    """A request to edit a clocked time-clock entry. Manager approves."""

    STATUS_CHOICES = [
        ("pending", "Pending"),
        ("approved", "Approved"),
        ("denied", "Denied"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    entry = models.ForeignKey(
        TimeClockEntry, on_delete=models.CASCADE, related_name="edit_requests"
    )
    requested_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="+"
    )
    proposed_clock_in = models.DateTimeField()
    proposed_clock_out = models.DateTimeField(null=True, blank=True)
    reason = models.CharField(max_length=400)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default="pending")
    decided_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="+",
    )
    decided_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at"]
