"""Celery tasks for the shifts app."""
from __future__ import annotations

import logging
from datetime import timedelta

from celery import shared_task
from django.utils import timezone

logger = logging.getLogger("dineops.shifts")


@shared_task(name="shifts.send_shift_reminders")
def send_shift_reminders(*, lookahead_minutes: int = 60) -> int:
    """Send T-60min reminders to staff with upcoming shifts."""
    from .models import StaffShift

    cutoff_low = timezone.now() + timedelta(minutes=lookahead_minutes - 5)
    cutoff_high = timezone.now() + timedelta(minutes=lookahead_minutes + 5)
    qs = StaffShift.objects.filter(
        status="scheduled",
        starts_at__gte=cutoff_low,
        starts_at__lte=cutoff_high,
    )
    sent = 0
    for shift in qs.select_related("staff__user"):
        try:
            from apps.notifications.services import enqueue_notification

            enqueue_notification(
                user=shift.staff.user,
                kind="shift.reminder",
                title="Your shift starts soon",
                body=f"Your shift starts at {shift.starts_at:%H:%M}.",
                actor=None,
                metadata={"shift_id": str(shift.id)},
            )
            sent += 1
        except Exception as exc:  # pragma: no cover
            logger.warning("shift_reminder_failed", extra={"err": str(exc)})
    return sent


@shared_task(name="shifts.close_stale_open_entries")
def close_stale_open_entries(*, max_open_hours: int = 16) -> int:
    """Close TimeClockEntry rows that have been open for too long. Marks them
    edited so the audit trail makes the auto-close clear."""
    from .models import TimeClockEntry

    cutoff = timezone.now() - timedelta(hours=max_open_hours)
    qs = TimeClockEntry.objects.filter(
        clocked_out_at__isnull=True, clocked_in_at__lt=cutoff,
    )
    closed = 0
    for entry in qs:
        entry.clocked_out_at = entry.clocked_in_at + timedelta(hours=max_open_hours)
        entry.edited = True
        entry.edit_reason = f"auto-closed after {max_open_hours}h"
        entry.save(update_fields=["clocked_out_at", "edited", "edit_reason"])
        closed += 1
    return closed
