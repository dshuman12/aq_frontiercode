from django.apps import AppConfig


class ShiftsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.shifts"

    def ready(self):
        try:
            from . import signals  # noqa: F401
        except ImportError:
            pass
