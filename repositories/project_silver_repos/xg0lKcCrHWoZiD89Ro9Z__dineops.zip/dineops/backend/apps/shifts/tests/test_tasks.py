from datetime import timedelta

import pytest
from django.utils import timezone

from apps.shifts.tasks import close_stale_open_entries, send_shift_reminders
from apps.shifts.tests.factories import StaffShiftFactory, TimeClockEntryFactory


@pytest.mark.django_db
class TestShiftTasks:
    def test_send_shift_reminders_skips_far_future(self):
        StaffShiftFactory(
            starts_at=timezone.now() + timedelta(hours=10),
            ends_at=timezone.now() + timedelta(hours=18),
        )
        sent = send_shift_reminders()
        assert sent == 0

    def test_close_stale_open_entries_closes_old_ones(self):
        old = TimeClockEntryFactory(
            clocked_in_at=timezone.now() - timedelta(hours=24),
            clocked_out_at=None,
        )
        recent = TimeClockEntryFactory(
            clocked_in_at=timezone.now() - timedelta(hours=2),
            clocked_out_at=None,
        )
        closed = close_stale_open_entries(max_open_hours=12)
        assert closed == 1
        old.refresh_from_db()
        recent.refresh_from_db()
        assert old.clocked_out_at is not None
        assert recent.clocked_out_at is None

    def test_close_stale_marks_edited(self):
        e = TimeClockEntryFactory(
            clocked_in_at=timezone.now() - timedelta(hours=24),
            clocked_out_at=None,
        )
        close_stale_open_entries(max_open_hours=12)
        e.refresh_from_db()
        assert e.edited is True
        assert "auto-closed" in e.edit_reason
