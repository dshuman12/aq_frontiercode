from datetime import timedelta

import pytest
from django.utils import timezone
from rest_framework.test import APIClient

from apps.accounts.tests.factories import UserFactory
from apps.locations.tests.factories import LocationFactory
from apps.restaurants.tests.factories import RestaurantFactory, RestaurantMemberFactory
from apps.shifts.tests.factories import StaffShiftFactory
from apps.staff.tests.factories import StaffProfileFactory


@pytest.fixture
def authed_owner(db):
    user = UserFactory()
    r = RestaurantFactory(owner=user, name="A", slug="a-shifts")
    RestaurantMemberFactory(restaurant=r, user=user, roles=["owner"])
    client = APIClient()
    client.force_authenticate(user=user)
    return client, user, r


@pytest.mark.django_db
class TestShiftViews:
    def test_create_201(self, authed_owner):
        client, _, r = authed_owner
        staff = StaffProfileFactory(restaurant=r)
        loc = LocationFactory(restaurant=r)
        starts = timezone.now() + timedelta(hours=2)
        ends = starts + timedelta(hours=8)
        resp = client.post(f"/api/shifts/{r.id}/", {
            "location_id": str(loc.id),
            "staff_id": str(staff.id),
            "starts_at": starts.isoformat(),
            "ends_at": ends.isoformat(),
            "role_label": "Cook",
        }, format="json")
        assert resp.status_code == 201

    def test_create_overlap_409(self, authed_owner):
        client, _, r = authed_owner
        staff = StaffProfileFactory(restaurant=r)
        loc = LocationFactory(restaurant=r)
        starts = timezone.now() + timedelta(hours=2)
        StaffShiftFactory(restaurant=r, staff=staff, location=loc,
                          starts_at=starts, ends_at=starts + timedelta(hours=4))
        resp = client.post(f"/api/shifts/{r.id}/", {
            "location_id": str(loc.id),
            "staff_id": str(staff.id),
            "starts_at": (starts + timedelta(hours=2)).isoformat(),
            "ends_at": (starts + timedelta(hours=6)).isoformat(),
        }, format="json")
        assert resp.status_code == 409

    def test_clock_in_then_out(self, authed_owner):
        client, _, r = authed_owner
        staff = StaffProfileFactory(restaurant=r)
        loc = LocationFactory(restaurant=r)
        in_resp = client.post(f"/api/shifts/{r.id}/clock-in/", {
            "location_id": str(loc.id), "staff_id": str(staff.id),
        }, format="json")
        assert in_resp.status_code == 201
        entry_id = in_resp.data["entry"]["id"]
        out_resp = client.post(
            f"/api/shifts/{r.id}/entries/{entry_id}/clock-out/", {}, format="json"
        )
        assert out_resp.status_code == 200
        assert out_resp.data["entry"]["clocked_out_at"] is not None

    def test_double_clock_in_409(self, authed_owner):
        client, _, r = authed_owner
        staff = StaffProfileFactory(restaurant=r)
        loc = LocationFactory(restaurant=r)
        client.post(f"/api/shifts/{r.id}/clock-in/", {
            "location_id": str(loc.id), "staff_id": str(staff.id),
        }, format="json")
        resp = client.post(f"/api/shifts/{r.id}/clock-in/", {
            "location_id": str(loc.id), "staff_id": str(staff.id),
        }, format="json")
        assert resp.status_code == 409

    def test_labor_summary_endpoint(self, authed_owner):
        client, _, r = authed_owner
        resp = client.get(f"/api/shifts/{r.id}/labor-summary/")
        assert resp.status_code == 200
        assert "total_minutes" in resp.data
