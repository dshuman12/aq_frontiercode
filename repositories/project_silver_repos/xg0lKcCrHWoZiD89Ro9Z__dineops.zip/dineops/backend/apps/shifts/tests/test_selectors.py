from datetime import timedelta

import pytest
from django.utils import timezone

from apps.shifts.selectors import calculate_overtime_minutes, labor_summary
from apps.shifts.tests.factories import TimeClockEntryFactory
from apps.staff.tests.factories import StaffProfileFactory


@pytest.mark.django_db
def test_labor_summary_aggregates_minutes_and_cost():
    staff = StaffProfileFactory(hourly_rate_cents=2400)
    now = timezone.now()
    TimeClockEntryFactory(
        staff=staff, restaurant=staff.restaurant,
        clocked_in_at=now - timedelta(hours=8),
        clocked_out_at=now,
    )
    summary = labor_summary(restaurant_id=staff.restaurant_id)
    assert summary["total_minutes"] >= 480
    # 8 hr * $24 = $192 = 19200 cents
    assert summary["total_cost_cents"] >= 19200


@pytest.mark.django_db
def test_overtime_minutes_zero_when_under_threshold():
    staff = StaffProfileFactory()
    now = timezone.now()
    TimeClockEntryFactory(
        staff=staff, restaurant=staff.restaurant,
        clocked_in_at=now - timedelta(hours=20),
        clocked_out_at=now,
    )
    minutes = calculate_overtime_minutes(
        staff=staff, since=now - timedelta(days=7), until=now,
        threshold_hours=40,
    )
    assert minutes == 0


@pytest.mark.django_db
def test_overtime_minutes_above_threshold():
    staff = StaffProfileFactory()
    now = timezone.now()
    # 50 hours in the window
    TimeClockEntryFactory(
        staff=staff, restaurant=staff.restaurant,
        clocked_in_at=now - timedelta(hours=50),
        clocked_out_at=now,
    )
    minutes = calculate_overtime_minutes(
        staff=staff, since=now - timedelta(days=7), until=now,
        threshold_hours=40,
    )
    assert minutes >= 600  # 10 hours overtime
