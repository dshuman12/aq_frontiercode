from datetime import timedelta

import pytest
from django.utils import timezone
from freezegun import freeze_time

from apps.common.exceptions import Conflict, ValidationError
from apps.locations.tests.factories import LocationFactory
from apps.shifts.models import ShiftBreak, ShiftEditRequest, StaffShift, TimeClockEntry
from apps.shifts.services import (
    cancel_shift,
    clock_in,
    clock_out,
    decide_edit_request,
    end_break,
    reschedule_shift,
    schedule_shift,
    start_break,
    submit_edit_request,
)
from apps.shifts.tests.factories import (
    StaffShiftFactory,
    TimeClockEntryFactory,
)
from apps.staff.tests.factories import StaffProfileFactory


@pytest.mark.django_db
class TestScheduleShift:
    def test_schedule_creates(self):
        staff = StaffProfileFactory()
        loc = LocationFactory(restaurant=staff.restaurant)
        starts = timezone.now() + timedelta(hours=2)
        ends = starts + timedelta(hours=8)
        s = schedule_shift(restaurant=staff.restaurant, location=loc,
                           staff=staff, starts_at=starts, ends_at=ends)
        assert s.duration_minutes == 480
        assert s.status == "scheduled"

    def test_schedule_rejects_zero_or_negative_duration(self):
        staff = StaffProfileFactory()
        loc = LocationFactory(restaurant=staff.restaurant)
        starts = timezone.now()
        with pytest.raises(ValidationError):
            schedule_shift(restaurant=staff.restaurant, location=loc,
                           staff=staff, starts_at=starts, ends_at=starts)

    def test_schedule_rejects_overlap(self):
        staff = StaffProfileFactory()
        loc = LocationFactory(restaurant=staff.restaurant)
        a = timezone.now() + timedelta(hours=2)
        StaffShiftFactory(staff=staff, location=loc, restaurant=staff.restaurant,
                          starts_at=a, ends_at=a + timedelta(hours=4))
        with pytest.raises(Conflict):
            schedule_shift(restaurant=staff.restaurant, location=loc, staff=staff,
                           starts_at=a + timedelta(hours=2),
                           ends_at=a + timedelta(hours=6))


@pytest.mark.django_db
class TestRescheduleAndCancel:
    def test_reschedule_succeeds(self):
        s = StaffShiftFactory()
        new_start = s.starts_at + timedelta(hours=1)
        new_end = s.ends_at + timedelta(hours=1)
        reschedule_shift(shift=s, starts_at=new_start, ends_at=new_end)
        s.refresh_from_db()
        assert s.starts_at == new_start

    def test_cancel_only_for_scheduled(self):
        s = StaffShiftFactory(status="completed")
        with pytest.raises(Conflict):
            cancel_shift(shift=s)


@pytest.mark.django_db
class TestClockInOut:
    def test_clock_in_creates_open_entry(self):
        staff = StaffProfileFactory()
        loc = LocationFactory(restaurant=staff.restaurant)
        e = clock_in(staff=staff, location=loc, restaurant=staff.restaurant)
        assert e.is_open is True

    def test_double_clock_in_rejected(self):
        staff = StaffProfileFactory()
        loc = LocationFactory(restaurant=staff.restaurant)
        clock_in(staff=staff, location=loc, restaurant=staff.restaurant)
        with pytest.raises(Conflict):
            clock_in(staff=staff, location=loc, restaurant=staff.restaurant)

    def test_clock_in_links_shift_and_marks_in_progress(self):
        s = StaffShiftFactory(status="scheduled")
        e = clock_in(staff=s.staff, location=s.location,
                     restaurant=s.restaurant, shift=s)
        s.refresh_from_db()
        assert s.status == "in_progress"
        assert e.shift_id == s.id

    def test_clock_out_records_clocked_out_at(self):
        e = TimeClockEntryFactory()
        clock_out(entry=e)
        e.refresh_from_db()
        assert e.clocked_out_at is not None

    def test_clock_out_blocks_double(self):
        e = TimeClockEntryFactory(clocked_out_at=timezone.now())
        with pytest.raises(Conflict):
            clock_out(entry=e)

    def test_clock_out_validates_after_clock_in(self):
        e = TimeClockEntryFactory(clocked_in_at=timezone.now())
        with pytest.raises(ValidationError):
            clock_out(entry=e, at=e.clocked_in_at - timedelta(minutes=1))

    def test_clock_out_completes_shift_status(self):
        s = StaffShiftFactory(status="in_progress")
        e = TimeClockEntryFactory(staff=s.staff, location=s.location,
                                  restaurant=s.restaurant, shift=s)
        clock_out(entry=e)
        s.refresh_from_db()
        assert s.status == "completed"


@pytest.mark.django_db
class TestBreaks:
    def test_start_break_succeeds_when_clocked_in(self):
        e = TimeClockEntryFactory()
        b = start_break(entry=e, kind="paid")
        assert b.kind == "paid"
        assert b.ended_at is None

    def test_only_one_open_break_allowed(self):
        e = TimeClockEntryFactory()
        start_break(entry=e)
        with pytest.raises(Conflict):
            start_break(entry=e)

    def test_break_blocked_when_entry_closed(self):
        e = TimeClockEntryFactory(clocked_out_at=timezone.now())
        with pytest.raises(Conflict):
            start_break(entry=e)

    def test_end_break_records_ended_at(self):
        e = TimeClockEntryFactory()
        b = start_break(entry=e)
        end_break(brk=b)
        b.refresh_from_db()
        assert b.ended_at is not None

    def test_end_break_idempotent_blocked(self):
        e = TimeClockEntryFactory()
        b = start_break(entry=e)
        end_break(brk=b)
        with pytest.raises(Conflict):
            end_break(brk=b)

    def test_clock_out_auto_closes_open_breaks(self):
        e = TimeClockEntryFactory()
        b = start_break(entry=e)
        clock_out(entry=e)
        b.refresh_from_db()
        assert b.ended_at is not None


@pytest.mark.django_db
class TestEditRequests:
    def test_submit_creates_pending(self):
        e = TimeClockEntryFactory()
        from apps.accounts.tests.factories import UserFactory
        req = submit_edit_request(
            entry=e, requester=UserFactory(),
            proposed_clock_in=e.clocked_in_at - timedelta(minutes=15),
            proposed_clock_out=timezone.now(),
            reason="forgot to clock in",
        )
        assert req.status == "pending"

    def test_submit_invalid_range(self):
        e = TimeClockEntryFactory()
        from apps.accounts.tests.factories import UserFactory
        with pytest.raises(ValidationError):
            submit_edit_request(
                entry=e, requester=UserFactory(),
                proposed_clock_in=e.clocked_in_at + timedelta(hours=1),
                proposed_clock_out=e.clocked_in_at,
                reason="wrong",
            )

    def test_approve_applies_to_entry(self):
        e = TimeClockEntryFactory()
        from apps.accounts.tests.factories import UserFactory
        req = submit_edit_request(
            entry=e, requester=UserFactory(),
            proposed_clock_in=e.clocked_in_at - timedelta(minutes=15),
            proposed_clock_out=e.clocked_in_at + timedelta(hours=8),
            reason="x",
        )
        decide_edit_request(req=req, decision="approved",
                            decider=UserFactory())
        e.refresh_from_db()
        assert e.edited is True
        assert e.clocked_out_at is not None

    def test_decide_only_pending(self):
        e = TimeClockEntryFactory()
        from apps.accounts.tests.factories import UserFactory
        req = submit_edit_request(
            entry=e, requester=UserFactory(),
            proposed_clock_in=e.clocked_in_at,
            proposed_clock_out=e.clocked_in_at + timedelta(hours=8),
            reason="x",
        )
        decide_edit_request(req=req, decision="denied", decider=UserFactory())
        with pytest.raises(Conflict):
            decide_edit_request(req=req, decision="approved", decider=UserFactory())
