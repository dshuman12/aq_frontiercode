from datetime import timedelta

import factory
from django.utils import timezone
from factory.django import DjangoModelFactory

from apps.locations.tests.factories import LocationFactory
from apps.shifts.models import StaffShift, TimeClockEntry
from apps.staff.tests.factories import StaffProfileFactory


class StaffShiftFactory(DjangoModelFactory):
    class Meta:
        model = StaffShift

    staff = factory.SubFactory(StaffProfileFactory)
    location = factory.SubFactory(LocationFactory)
    restaurant = factory.LazyAttribute(lambda o: o.staff.restaurant)
    role_label = "Server"
    starts_at = factory.LazyFunction(lambda: timezone.now() + timedelta(hours=1))
    ends_at = factory.LazyFunction(lambda: timezone.now() + timedelta(hours=9))
    status = "scheduled"


class TimeClockEntryFactory(DjangoModelFactory):
    class Meta:
        model = TimeClockEntry

    staff = factory.SubFactory(StaffProfileFactory)
    location = factory.SubFactory(LocationFactory)
    restaurant = factory.LazyAttribute(lambda o: o.staff.restaurant)
    clocked_in_at = factory.LazyFunction(timezone.now)
