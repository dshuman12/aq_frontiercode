import pytest


pytestmark = pytest.mark.django_db


def test_shifts_imports():
    from apps.shifts import (
        models, services, selectors, serializers, tasks, views, urls,
    )
    assert all([models, services, selectors, serializers, tasks, views, urls])
