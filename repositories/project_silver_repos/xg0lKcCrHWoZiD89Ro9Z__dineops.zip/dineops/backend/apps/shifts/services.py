from __future__ import annotations

from datetime import timedelta

from django.db import transaction
from django.db.models import Q
from django.utils import timezone

from apps.common.exceptions import Conflict, NotFound, ValidationError

from .models import ShiftBreak, ShiftEditRequest, StaffShift, TimeClockEntry


def _shifts_overlapping(*, staff, starts_at, ends_at, exclude_id=None):
    qs = StaffShift.objects.filter(
        staff=staff, status__in=("scheduled", "in_progress"),
        ends_at__gt=starts_at, starts_at__lt=ends_at,
    )
    if exclude_id:
        qs = qs.exclude(id=exclude_id)
    return qs


@transaction.atomic
def schedule_shift(*, restaurant, location, staff, starts_at, ends_at,
                   role_label: str = "", notes: str = "", actor=None) -> StaffShift:
    if ends_at <= starts_at:
        raise ValidationError("invalid_range", "Shift end must be after start.")
    if _shifts_overlapping(staff=staff, starts_at=starts_at, ends_at=ends_at).exists():
        raise Conflict("shift_overlap", "Staff already has an overlapping shift.")
    return StaffShift.objects.create(
        restaurant=restaurant,
        location=location,
        staff=staff,
        role_label=role_label,
        starts_at=starts_at,
        ends_at=ends_at,
        notes=notes,
        created_by=actor,
        status="scheduled",
    )


@transaction.atomic
def reschedule_shift(*, shift: StaffShift, starts_at, ends_at) -> StaffShift:
    if ends_at <= starts_at:
        raise ValidationError("invalid_range")
    if shift.status not in ("scheduled", "in_progress"):
        raise Conflict("cannot_reschedule_terminal_shift")
    if _shifts_overlapping(
        staff=shift.staff, starts_at=starts_at, ends_at=ends_at, exclude_id=shift.id
    ).exists():
        raise Conflict("shift_overlap")
    shift.starts_at = starts_at
    shift.ends_at = ends_at
    shift.save(update_fields=["starts_at", "ends_at"])
    return shift


@transaction.atomic
def cancel_shift(*, shift: StaffShift) -> StaffShift:
    if shift.status not in ("scheduled",):
        raise Conflict("cannot_cancel_in_progress_shift")
    shift.status = "cancelled"
    shift.save(update_fields=["status"])
    return shift


@transaction.atomic
def clock_in(*, staff, location, restaurant, shift: StaffShift | None = None,
             at=None) -> TimeClockEntry:
    """Open a new TimeClockEntry. Errors if there's already an open one."""
    at = at or timezone.now()
    if TimeClockEntry.objects.filter(staff=staff, clocked_out_at__isnull=True).exists():
        raise Conflict("already_clocked_in")
    entry = TimeClockEntry.objects.create(
        restaurant=restaurant,
        location=location,
        staff=staff,
        shift=shift,
        clocked_in_at=at,
    )
    if shift and shift.status == "scheduled":
        shift.status = "in_progress"
        shift.save(update_fields=["status"])
    return entry


@transaction.atomic
def clock_out(*, entry: TimeClockEntry, at=None) -> TimeClockEntry:
    if not entry.is_open:
        raise Conflict("already_clocked_out")
    at = at or timezone.now()
    if at <= entry.clocked_in_at:
        raise ValidationError("invalid_clock_out_time")
    # close any unfinished breaks
    for b in entry.breaks.filter(ended_at__isnull=True):
        b.ended_at = at
        b.save(update_fields=["ended_at"])
    entry.clocked_out_at = at
    entry.save(update_fields=["clocked_out_at"])
    if entry.shift and entry.shift.status == "in_progress":
        entry.shift.status = "completed"
        entry.shift.save(update_fields=["status"])
    return entry


@transaction.atomic
def start_break(*, entry: TimeClockEntry, kind: str = "unpaid", at=None) -> ShiftBreak:
    if not entry.is_open:
        raise Conflict("entry_not_open")
    if entry.breaks.filter(ended_at__isnull=True).exists():
        raise Conflict("break_already_in_progress")
    return ShiftBreak.objects.create(entry=entry, kind=kind, started_at=at or timezone.now())


@transaction.atomic
def end_break(*, brk: ShiftBreak, at=None) -> ShiftBreak:
    if brk.ended_at:
        raise Conflict("break_already_ended")
    brk.ended_at = at or timezone.now()
    brk.save(update_fields=["ended_at"])
    return brk


@transaction.atomic
def submit_edit_request(*, entry: TimeClockEntry, requester,
                        proposed_clock_in, proposed_clock_out, reason: str) -> ShiftEditRequest:
    if proposed_clock_out and proposed_clock_out <= proposed_clock_in:
        raise ValidationError("invalid_range")
    return ShiftEditRequest.objects.create(
        entry=entry,
        requested_by=requester,
        proposed_clock_in=proposed_clock_in,
        proposed_clock_out=proposed_clock_out,
        reason=reason,
    )


@transaction.atomic
def decide_edit_request(*, req: ShiftEditRequest, decision: str, decider) -> ShiftEditRequest:
    if req.status != "pending":
        raise Conflict("already_decided")
    if decision not in ("approved", "denied"):
        raise ValidationError("invalid_decision")
    req.status = decision
    req.decided_by = decider
    req.decided_at = timezone.now()
    req.save(update_fields=["status", "decided_by", "decided_at"])
    if decision == "approved":
        entry = req.entry
        entry.clocked_in_at = req.proposed_clock_in
        if req.proposed_clock_out:
            entry.clocked_out_at = req.proposed_clock_out
        entry.edited = True
        entry.edit_reason = req.reason[:200]
        entry.edited_by = decider
        entry.save(update_fields=[
            "clocked_in_at", "clocked_out_at", "edited", "edit_reason", "edited_by",
        ])
    return req
