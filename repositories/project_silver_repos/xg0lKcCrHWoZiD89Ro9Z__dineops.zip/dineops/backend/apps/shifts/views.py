from __future__ import annotations

from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common.exceptions import NotFound, PermissionDenied
from apps.locations.models import Location
from apps.restaurants.models import Restaurant, RestaurantMember
from apps.staff.models import StaffProfile

from . import services
from .models import ShiftBreak, ShiftEditRequest, StaffShift, TimeClockEntry
from .selectors import labor_summary
from .serializers import (
    BreakSerializer,
    ClockInSerializer,
    DecideEditRequestSerializer,
    EditRequestSerializer,
    ShiftCreateSerializer,
    ShiftRescheduleSerializer,
    StaffShiftSerializer,
    StartBreakSerializer,
    TimeClockEntrySerializer,
)


def _require_member(user, restaurant_id) -> RestaurantMember:
    m = RestaurantMember.objects.filter(
        restaurant_id=restaurant_id, user=user, status="active"
    ).first()
    if not m:
        raise PermissionDenied("not_a_member")
    return m


class ShiftListCreate(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        _require_member(request.user, restaurant_id)
        items = (
            StaffShift.objects.filter(restaurant_id=restaurant_id)
            .select_related("staff__user", "location")
            .order_by("-starts_at")[:200]
        )
        return Response({"results": StaffShiftSerializer(items, many=True).data})

    def post(self, request, restaurant_id):
        member = _require_member(request.user, restaurant_id)
        if not any(r in ("owner", "general_manager", "assistant_manager") for r in member.roles):
            raise PermissionDenied()
        s = ShiftCreateSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        location = Location.objects.filter(
            id=s.validated_data["location_id"], restaurant_id=restaurant_id
        ).first()
        staff = StaffProfile.objects.filter(
            id=s.validated_data["staff_id"], restaurant_id=restaurant_id
        ).first()
        if not location or not staff:
            raise NotFound()
        shift = services.schedule_shift(
            restaurant=Restaurant.objects.get(id=restaurant_id),
            location=location, staff=staff,
            starts_at=s.validated_data["starts_at"],
            ends_at=s.validated_data["ends_at"],
            role_label=s.validated_data.get("role_label", ""),
            notes=s.validated_data.get("notes", ""),
            actor=request.user,
        )
        return Response({"shift": StaffShiftSerializer(shift).data},
                        status=status.HTTP_201_CREATED)


class ShiftDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id, shift_id):
        _require_member(request.user, restaurant_id)
        shift = StaffShift.objects.filter(id=shift_id, restaurant_id=restaurant_id).first()
        if not shift:
            raise NotFound()
        return Response({"shift": StaffShiftSerializer(shift).data})

    def patch(self, request, restaurant_id, shift_id):
        member = _require_member(request.user, restaurant_id)
        if not any(r in ("owner", "general_manager", "assistant_manager") for r in member.roles):
            raise PermissionDenied()
        shift = StaffShift.objects.filter(id=shift_id, restaurant_id=restaurant_id).first()
        if not shift:
            raise NotFound()
        s = ShiftRescheduleSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        services.reschedule_shift(shift=shift, **s.validated_data)
        return Response({"shift": StaffShiftSerializer(shift).data})

    def delete(self, request, restaurant_id, shift_id):
        member = _require_member(request.user, restaurant_id)
        if not any(r in ("owner", "general_manager", "assistant_manager") for r in member.roles):
            raise PermissionDenied()
        shift = StaffShift.objects.filter(id=shift_id, restaurant_id=restaurant_id).first()
        if not shift:
            raise NotFound()
        services.cancel_shift(shift=shift)
        return Response({"ok": True})


class ClockInView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id):
        _require_member(request.user, restaurant_id)
        s = ClockInSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        location = Location.objects.filter(
            id=s.validated_data["location_id"], restaurant_id=restaurant_id
        ).first()
        staff = StaffProfile.objects.filter(
            id=s.validated_data["staff_id"], restaurant_id=restaurant_id
        ).first()
        if not location or not staff:
            raise NotFound()
        shift = None
        if s.validated_data.get("shift_id"):
            shift = StaffShift.objects.filter(
                id=s.validated_data["shift_id"], restaurant_id=restaurant_id
            ).first()
        entry = services.clock_in(
            staff=staff, location=location,
            restaurant=Restaurant.objects.get(id=restaurant_id),
            shift=shift,
        )
        return Response({"entry": TimeClockEntrySerializer(entry).data}, status=201)


class ClockOutView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, entry_id):
        _require_member(request.user, restaurant_id)
        entry = TimeClockEntry.objects.filter(
            id=entry_id, restaurant_id=restaurant_id
        ).first()
        if not entry:
            raise NotFound()
        services.clock_out(entry=entry)
        return Response({"entry": TimeClockEntrySerializer(entry).data})


class BreakStartView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, entry_id):
        _require_member(request.user, restaurant_id)
        entry = TimeClockEntry.objects.filter(
            id=entry_id, restaurant_id=restaurant_id
        ).first()
        if not entry:
            raise NotFound()
        s = StartBreakSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        brk = services.start_break(entry=entry, kind=s.validated_data["kind"])
        return Response({"break": BreakSerializer(brk).data}, status=201)


class BreakEndView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, break_id):
        _require_member(request.user, restaurant_id)
        brk = ShiftBreak.objects.filter(
            id=break_id, entry__restaurant_id=restaurant_id
        ).first()
        if not brk:
            raise NotFound()
        services.end_break(brk=brk)
        return Response({"break": BreakSerializer(brk).data})


class EditRequestCreate(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, entry_id):
        _require_member(request.user, restaurant_id)
        entry = TimeClockEntry.objects.filter(
            id=entry_id, restaurant_id=restaurant_id
        ).first()
        if not entry:
            raise NotFound()
        s = EditRequestSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        req = services.submit_edit_request(
            entry=entry,
            requester=request.user,
            proposed_clock_in=s.validated_data["proposed_clock_in"],
            proposed_clock_out=s.validated_data.get("proposed_clock_out"),
            reason=s.validated_data["reason"],
        )
        return Response({"request": EditRequestSerializer(req).data}, status=201)


class EditRequestDecide(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, request_id):
        member = _require_member(request.user, restaurant_id)
        if not any(r in ("owner", "general_manager", "assistant_manager") for r in member.roles):
            raise PermissionDenied()
        req = ShiftEditRequest.objects.filter(
            id=request_id, entry__restaurant_id=restaurant_id
        ).first()
        if not req:
            raise NotFound()
        s = DecideEditRequestSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        services.decide_edit_request(
            req=req, decision=s.validated_data["decision"], decider=request.user,
        )
        return Response({"request": EditRequestSerializer(req).data})


class LaborSummaryView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        member = _require_member(request.user, restaurant_id)
        if not any(r in ("owner", "general_manager", "assistant_manager",
                         "accountant") for r in member.roles):
            raise PermissionDenied()
        from datetime import datetime
        since = request.GET.get("since")
        until = request.GET.get("until")
        since_dt = datetime.fromisoformat(since) if since else None
        until_dt = datetime.fromisoformat(until) if until else None
        return Response(labor_summary(restaurant_id=restaurant_id,
                                      since=since_dt, until=until_dt))
