from __future__ import annotations

from datetime import datetime, timedelta, timezone as dtz
from decimal import Decimal

from django.db.models import Sum

from apps.staff.models import StaffProfile

from .models import StaffShift, TimeClockEntry


def open_clock_entries(restaurant_id) -> list[TimeClockEntry]:
    return list(TimeClockEntry.objects.filter(
        shift__restaurant_id=restaurant_id,
        clocked_out_at__isnull=False,
    ).select_related("staff_profile__user"))


def upcoming_shifts(staff_profile: StaffProfile, *, days: int = 7):
    cutoff = datetime.now(dtz.utc) + timedelta(days=days)
    return list(
        StaffShift.objects.filter(
            staff_profile=staff_profile,
            start_time__lte=cutoff,
            start_time__gte=datetime.now(dtz.utc),
            status__in=("scheduled", "in_progress"),
        ).order_by("start_time")
    )


def hours_this_week(staff_profile: StaffProfile) -> Decimal:
    """Sum of worked minutes for entries that ended in the current week."""
    now = datetime.now(dtz.utc)
    monday = (now - timedelta(days=now.weekday())).replace(
        hour=0, minute=0, second=0, microsecond=0,
    )
    qs = TimeClockEntry.objects.filter(
        staff_profile=staff_profile,
        clocked_in_at__gte=monday,
        clocked_out_at__isnull=False,
    )
    minutes = sum(e.worked_minutes() for e in qs)
    return (Decimal(minutes) / 60).quantize(Decimal("0.01"))
