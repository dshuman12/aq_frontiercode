from __future__ import annotations

from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.accounts.models import User
from apps.common.exceptions import NotFound, PermissionDenied
from apps.restaurants.models import Restaurant, RestaurantMember

from . import services
from .models import StaffProfile
from .serializers import (
    StaffCreateSerializer,
    StaffProfileSerializer,
    StaffUpdateSerializer,
)


def _require_member(user, restaurant_id) -> RestaurantMember:
    member = RestaurantMember.objects.filter(
        restaurant_id=restaurant_id, user=user, status="active"
    ).first()
    if not member:
        raise PermissionDenied("not_a_member")
    return member


def _require_role(member: RestaurantMember, *roles: str):
    if not any(r in roles for r in member.roles or []):
        raise PermissionDenied()


class StaffListCreate(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        _require_member(request.user, restaurant_id)
        items = (
            StaffProfile.objects.filter(restaurant_id=restaurant_id, archived_at__isnull=True)
            .select_related("user")
            .order_by("user__full_name")
        )
        return Response({"results": StaffProfileSerializer(items, many=True).data})

    def post(self, request, restaurant_id):
        member = _require_member(request.user, restaurant_id)
        _require_role(member, "owner", "general_manager", "assistant_manager")
        s = StaffCreateSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        user = User.objects.filter(id=s.validated_data["user_id"]).first()
        if not user:
            raise NotFound("user_not_found")
        restaurant = Restaurant.objects.get(id=restaurant_id)
        profile = services.create_staff_profile(
            restaurant=restaurant, user=user,
            **{k: v for k, v in s.validated_data.items() if k != "user_id"},
        )
        return Response({"staff": StaffProfileSerializer(profile).data},
                        status=status.HTTP_201_CREATED)


class StaffDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def _get(self, restaurant_id, staff_id):
        return StaffProfile.objects.select_related("user").filter(
            id=staff_id, restaurant_id=restaurant_id
        ).first()

    def get(self, request, restaurant_id, staff_id):
        _require_member(request.user, restaurant_id)
        staff = self._get(restaurant_id, staff_id)
        if not staff:
            raise NotFound()
        return Response({"staff": StaffProfileSerializer(staff).data})

    def patch(self, request, restaurant_id, staff_id):
        member = _require_member(request.user, restaurant_id)
        _require_role(member, "owner", "general_manager", "assistant_manager")
        staff = self._get(restaurant_id, staff_id)
        if not staff:
            raise NotFound()
        s = StaffUpdateSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        services.update_staff_profile(staff=staff, **s.validated_data)
        return Response({"staff": StaffProfileSerializer(staff).data})

    def delete(self, request, restaurant_id, staff_id):
        member = _require_member(request.user, restaurant_id)
        _require_role(member, "owner", "general_manager")
        staff = self._get(restaurant_id, staff_id)
        if not staff:
            raise NotFound()
        services.archive_staff(staff=staff)
        return Response({"ok": True})
