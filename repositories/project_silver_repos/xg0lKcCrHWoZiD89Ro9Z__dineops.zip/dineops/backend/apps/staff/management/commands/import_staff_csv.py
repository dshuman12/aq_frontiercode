"""Bulk-import staff profiles from a CSV at onboarding."""
from __future__ import annotations

import csv
from decimal import Decimal

from django.core.management.base import BaseCommand
from django.db import transaction

from apps.accounts.models import User
from apps.restaurants.models import Restaurant, RestaurantMember
from apps.staff.models import StaffProfile


class Command(BaseCommand):
    help = "Bulk-import staff from CSV (email, name, role, hourly_rate)."

    def add_arguments(self, parser):
        parser.add_argument("--restaurant", required=True)
        parser.add_argument("--file", required=True)

    @transaction.atomic
    def handle(self, *args, restaurant, file, **options):
        rest = Restaurant.objects.get(slug=restaurant)
        created = 0
        with open(file) as f:
            reader = csv.DictReader(f)
            for row in reader:
                email = row["email"].strip().lower()
                u, _ = User.objects.get_or_create(
                    email=email,
                    defaults={"is_active": True},
                )
                RestaurantMember.objects.get_or_create(
                    restaurant=rest, user=u,
                    defaults={"roles": [row.get("role", "server")],
                              "status": "active"},
                )
                StaffProfile.objects.get_or_create(
                    restaurant=rest, user=u,
                    defaults={
                        "hourly_rate_cents": int(
                            (Decimal(row.get("hourly_rate", "20")) * 100)
                            .quantize(Decimal("1"))
                        ),
                        "employee_code": row.get("code", ""),
                        "job_title": row.get("title", ""),
                    },
                )
                created += 1
        self.stdout.write(self.style.SUCCESS(f"Imported {created} staff."))
