from __future__ import annotations

from decimal import Decimal

from .models import StaffProfile


def active_staff_for(restaurant_id, *, location_id=None) -> list[StaffProfile]:
    qs = StaffProfile.objects.filter(
        restaurant_id=restaurant_id, archived_at__isnull=True,
    ).select_related("user", "primary_location")
    if location_id:
        qs = qs.filter(primary_location_id=location_id)
    return list(qs.order_by("user__email"))


def hourly_rate_for(profile: StaffProfile) -> Decimal:
    return profile.hourly_rate
