from __future__ import annotations

from django.db import transaction

from apps.common.exceptions import Conflict, ValidationError

from .models import StaffProfile


@transaction.atomic
def create_staff_profile(*, restaurant, user, **fields) -> StaffProfile:
    if StaffProfile.objects.filter(restaurant=restaurant, user=user).exists():
        raise Conflict("staff_already_exists")
    if "hourly_rate_cents" in fields and fields["hourly_rate_cents"] < 0:
        raise ValidationError("invalid_rate", "Hourly rate cannot be negative.")
    return StaffProfile.objects.create(restaurant=restaurant, user=user, **fields)


@transaction.atomic
def update_staff_profile(*, staff: StaffProfile, **fields) -> StaffProfile:
    allowed = {
        "employee_code", "job_title", "employment_type",
        "primary_location_id", "location_ids",
        "hourly_rate_cents", "overtime_multiplier", "weekly_hours_target",
        "can_clock_in_remotely", "pin_code", "notes",
    }
    for k, v in fields.items():
        if k in allowed and v is not None:
            setattr(staff, k, v)
    staff.save()
    return staff


def archive_staff(*, staff: StaffProfile):
    staff.archive()
    return staff
