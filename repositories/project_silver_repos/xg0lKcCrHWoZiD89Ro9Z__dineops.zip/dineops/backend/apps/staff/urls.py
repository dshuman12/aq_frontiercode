from django.urls import path

from . import views

app_name = "staff"

urlpatterns = [
    path("<uuid:restaurant_id>/", views.StaffListCreate.as_view(), name="list-create"),
    path("<uuid:restaurant_id>/<uuid:staff_id>/", views.StaffDetail.as_view(), name="detail"),
]
