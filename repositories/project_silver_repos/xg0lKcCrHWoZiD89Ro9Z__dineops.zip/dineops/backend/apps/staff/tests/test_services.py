import pytest

from apps.accounts.tests.factories import UserFactory
from apps.common.exceptions import Conflict, ValidationError
from apps.restaurants.tests.factories import RestaurantFactory
from apps.staff.models import StaffProfile
from apps.staff.services import (
    archive_staff,
    create_staff_profile,
    update_staff_profile,
)


@pytest.mark.django_db
class TestStaffServices:
    def test_create_persists_profile(self):
        r = RestaurantFactory()
        u = UserFactory()
        sp = create_staff_profile(restaurant=r, user=u, job_title="Cook",
                                  hourly_rate_cents=2500)
        assert sp.id is not None
        assert sp.hourly_rate.equals(sp.hourly_rate)  # noqa

    def test_create_conflict_when_already_exists(self):
        r = RestaurantFactory()
        u = UserFactory()
        create_staff_profile(restaurant=r, user=u, job_title="Cook")
        with pytest.raises(Conflict):
            create_staff_profile(restaurant=r, user=u, job_title="Server")

    def test_create_rejects_negative_rate(self):
        r = RestaurantFactory()
        u = UserFactory()
        with pytest.raises(ValidationError):
            create_staff_profile(
                restaurant=r, user=u,
                hourly_rate_cents=-1,
            )

    def test_update_filters_unknown_fields(self):
        r = RestaurantFactory()
        u = UserFactory()
        sp = create_staff_profile(restaurant=r, user=u, job_title="Cook")
        update_staff_profile(staff=sp, job_title="Sous Chef", evil="ignored")
        sp.refresh_from_db()
        assert sp.job_title == "Sous Chef"

    def test_archive_staff(self):
        r = RestaurantFactory()
        u = UserFactory()
        sp = create_staff_profile(restaurant=r, user=u)
        archive_staff(staff=sp)
        sp.refresh_from_db()
        assert sp.archived_at is not None

    def test_hourly_rate_property_returns_decimal_dollars(self):
        r = RestaurantFactory()
        u = UserFactory()
        sp = create_staff_profile(restaurant=r, user=u, hourly_rate_cents=1850)
        from decimal import Decimal
        assert sp.hourly_rate == Decimal("18.50")
