import factory
from factory.django import DjangoModelFactory

from apps.accounts.tests.factories import UserFactory
from apps.restaurants.tests.factories import RestaurantFactory
from apps.staff.models import StaffProfile


class StaffProfileFactory(DjangoModelFactory):
    class Meta:
        model = StaffProfile

    user = factory.SubFactory(UserFactory)
    restaurant = factory.SubFactory(RestaurantFactory)
    job_title = factory.Iterator(["Server", "Line Cook", "Sous Chef", "Cashier"])
    employment_type = "part_time"
    hourly_rate_cents = factory.Faker("random_int", min=1500, max=4500)
