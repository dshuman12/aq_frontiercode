import pytest


pytestmark = pytest.mark.django_db


def test_staff_imports():
    from apps.staff import models, services, serializers, views, urls
    from apps.staff import selectors
    assert all([models, services, serializers, views, urls, selectors])
