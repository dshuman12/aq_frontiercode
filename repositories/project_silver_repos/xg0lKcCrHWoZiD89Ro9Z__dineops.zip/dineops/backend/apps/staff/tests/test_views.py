import pytest
from rest_framework.test import APIClient

from apps.accounts.tests.factories import UserFactory
from apps.restaurants.tests.factories import RestaurantFactory, RestaurantMemberFactory
from apps.staff.tests.factories import StaffProfileFactory


@pytest.fixture
def auth_owner_in_restaurant(db):
    user = UserFactory()
    r = RestaurantFactory(owner=user, name="A", slug=f"a-staff")
    RestaurantMemberFactory(restaurant=r, user=user, roles=["owner"])
    client = APIClient()
    client.force_authenticate(user=user)
    return client, user, r


@pytest.mark.django_db
class TestStaffViews:
    def test_list_only_active(self, auth_owner_in_restaurant):
        client, _, r = auth_owner_in_restaurant
        active = StaffProfileFactory(restaurant=r)
        archived = StaffProfileFactory(restaurant=r)
        archived.archive()
        resp = client.get(f"/api/staff/{r.id}/")
        ids = [s["id"] for s in resp.data["results"]]
        assert str(active.id) in ids
        assert str(archived.id) not in ids

    def test_create_requires_manager_role(self, db):
        chef = UserFactory()
        r = RestaurantFactory(owner=UserFactory(), name="X", slug="x-cs")
        RestaurantMemberFactory(restaurant=r, user=chef, roles=["chef"])
        client = APIClient()
        client.force_authenticate(user=chef)
        target_user = UserFactory()
        resp = client.post(f"/api/staff/{r.id}/", {
            "user_id": str(target_user.id), "job_title": "Cook",
        }, format="json")
        assert resp.status_code == 403

    def test_create_404_when_user_unknown(self, auth_owner_in_restaurant):
        import uuid

        client, _, r = auth_owner_in_restaurant
        resp = client.post(f"/api/staff/{r.id}/", {
            "user_id": str(uuid.uuid4()), "job_title": "Cook",
        }, format="json")
        assert resp.status_code == 404

    def test_archive_via_delete(self, auth_owner_in_restaurant):
        client, _, r = auth_owner_in_restaurant
        sp = StaffProfileFactory(restaurant=r)
        resp = client.delete(f"/api/staff/{r.id}/{sp.id}/")
        assert resp.status_code == 200
        sp.refresh_from_db()
        assert sp.archived_at is not None
