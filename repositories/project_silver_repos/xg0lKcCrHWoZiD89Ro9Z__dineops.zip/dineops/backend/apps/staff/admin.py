from django.contrib import admin

from .models import StaffDocument, StaffProfile


@admin.register(StaffProfile)
class StaffProfileAdmin(admin.ModelAdmin):
    list_display = ("user", "restaurant", "job_title", "employment_type", "hourly_rate_cents", "archived_at")
    search_fields = ("user__email", "user__full_name", "employee_code")
    list_filter = ("employment_type",)


@admin.register(StaffDocument)
class StaffDocumentAdmin(admin.ModelAdmin):
    list_display = ("staff", "kind", "label", "expires_at")
    list_filter = ("kind",)
