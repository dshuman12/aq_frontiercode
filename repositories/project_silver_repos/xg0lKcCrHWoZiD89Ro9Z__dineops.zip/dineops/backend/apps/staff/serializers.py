from rest_framework import serializers

from apps.accounts.serializers import UserSerializer

from .models import StaffDocument, StaffProfile


class StaffProfileSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)

    class Meta:
        model = StaffProfile
        fields = (
            "id", "user", "employee_code", "job_title", "employment_type",
            "primary_location", "location_ids",
            "hourly_rate_cents", "overtime_multiplier", "weekly_hours_target",
            "can_clock_in_remotely", "pin_code", "notes",
            "archived_at", "created_at",
        )
        read_only_fields = ("id", "user", "archived_at", "created_at")


class StaffCreateSerializer(serializers.Serializer):
    user_id = serializers.UUIDField()
    employee_code = serializers.CharField(max_length=40, required=False, allow_blank=True)
    job_title = serializers.CharField(max_length=120, required=False, allow_blank=True)
    employment_type = serializers.ChoiceField(
        choices=StaffProfile.EMPLOYMENT_CHOICES, required=False, default="part_time"
    )
    primary_location_id = serializers.UUIDField(required=False, allow_null=True)
    location_ids = serializers.ListField(child=serializers.UUIDField(), required=False)
    hourly_rate_cents = serializers.IntegerField(min_value=0, required=False, default=0)
    weekly_hours_target = serializers.DecimalField(
        max_digits=5, decimal_places=2, required=False, default=0
    )
    can_clock_in_remotely = serializers.BooleanField(required=False, default=False)
    pin_code = serializers.CharField(max_length=12, required=False, allow_blank=True)


class StaffUpdateSerializer(serializers.Serializer):
    employee_code = serializers.CharField(max_length=40, required=False, allow_blank=True)
    job_title = serializers.CharField(max_length=120, required=False, allow_blank=True)
    employment_type = serializers.ChoiceField(
        choices=StaffProfile.EMPLOYMENT_CHOICES, required=False
    )
    primary_location_id = serializers.UUIDField(required=False, allow_null=True)
    location_ids = serializers.ListField(child=serializers.UUIDField(), required=False)
    hourly_rate_cents = serializers.IntegerField(min_value=0, required=False)
    weekly_hours_target = serializers.DecimalField(
        max_digits=5, decimal_places=2, required=False
    )
    can_clock_in_remotely = serializers.BooleanField(required=False)
    pin_code = serializers.CharField(max_length=12, required=False, allow_blank=True)
    notes = serializers.CharField(required=False, allow_blank=True)


class StaffDocumentSerializer(serializers.ModelSerializer):
    class Meta:
        model = StaffDocument
        fields = ("id", "kind", "label", "url", "expires_at", "created_at")
