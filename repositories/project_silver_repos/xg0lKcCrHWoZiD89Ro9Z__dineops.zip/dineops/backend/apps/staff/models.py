from __future__ import annotations

import uuid
from decimal import Decimal

from django.conf import settings
from django.db import models

from apps.common.models import SoftDeleteModel, TimeStampedModel


class StaffProfile(TimeStampedModel, SoftDeleteModel):
    """Operational metadata about a staff member, beyond the User profile.

    A user can hold multiple staff profiles (one per restaurant) — different
    pay rates, different roles per restaurant.
    """

    EMPLOYMENT_FT = "full_time"
    EMPLOYMENT_PT = "part_time"
    EMPLOYMENT_CONTRACT = "contractor"
    EMPLOYMENT_CHOICES = [
        (EMPLOYMENT_FT, "Full-time"),
        (EMPLOYMENT_PT, "Part-time"),
        (EMPLOYMENT_CONTRACT, "Contractor"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="staff_profiles"
    )
    restaurant = models.ForeignKey(
        "restaurants.Restaurant", on_delete=models.CASCADE, related_name="staff_profiles"
    )
    employee_code = models.CharField(max_length=40, blank=True, db_index=True)
    job_title = models.CharField(max_length=120, blank=True)
    employment_type = models.CharField(
        max_length=20, choices=EMPLOYMENT_CHOICES, default=EMPLOYMENT_PT
    )
    primary_location = models.ForeignKey(
        "locations.Location", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="primary_staff",
    )
    location_ids = models.JSONField(default=list, blank=True)
    hourly_rate_cents = models.PositiveIntegerField(default=0)
    overtime_multiplier = models.DecimalField(
        max_digits=4, decimal_places=2, default=Decimal("1.5")
    )
    weekly_hours_target = models.DecimalField(
        max_digits=5, decimal_places=2, default=0,
        help_text="Used by the schedule builder.",
    )

    can_clock_in_remotely = models.BooleanField(default=False)
    pin_code = models.CharField(max_length=12, blank=True, help_text="POS clock-in PIN")
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ["user__full_name"]
        constraints = [
            models.UniqueConstraint(fields=["restaurant", "user"], name="unique_staff_member"),
        ]
        indexes = [
            models.Index(fields=["restaurant", "archived_at"]),
            models.Index(fields=["restaurant", "employee_code"]),
        ]

    def __str__(self) -> str:
        return f"{self.user.full_name} @ {self.restaurant_id}"

    @property
    def hourly_rate(self) -> Decimal:
        return Decimal(self.hourly_rate_cents) / Decimal(100)


class StaffDocument(TimeStampedModel):
    KIND_CHOICES = [
        ("id", "ID document"),
        ("contract", "Contract"),
        ("training", "Training certificate"),
        ("food_handler", "Food handler's permit"),
        ("other", "Other"),
    ]

    staff = models.ForeignKey(StaffProfile, on_delete=models.CASCADE, related_name="documents")
    kind = models.CharField(max_length=32, choices=KIND_CHOICES, default="other")
    label = models.CharField(max_length=200)
    url = models.URLField()
    expires_at = models.DateField(null=True, blank=True)
    uploaded_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="+",
    )

    class Meta:
        ordering = ["-created_at"]
