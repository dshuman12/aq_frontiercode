from django.contrib import admin

from .models import (
    Menu, MenuAvailability, MenuCategory, MenuItem, MenuItemModifierGroup,
    MenuItemVariant, ModifierGroup, ModifierOption,
)


class MenuCategoryInline(admin.TabularInline):
    model = MenuCategory
    extra = 0
    fields = ("name", "slug", "sort")
    readonly_fields = ("slug",)


class MenuItemVariantInline(admin.TabularInline):
    model = MenuItemVariant
    extra = 0


class ModifierOptionInline(admin.TabularInline):
    model = ModifierOption
    extra = 0


class MenuItemModifierGroupInline(admin.TabularInline):
    model = MenuItemModifierGroup
    extra = 0
    autocomplete_fields = ["group"]


@admin.register(Menu)
class MenuAdmin(admin.ModelAdmin):
    list_display = ("name", "kind", "restaurant", "is_default", "sort")
    list_filter = ("kind", "is_default")
    search_fields = ("name", "slug")
    inlines = [MenuCategoryInline]


@admin.register(MenuItem)
class MenuItemAdmin(admin.ModelAdmin):
    list_display = ("name", "kind", "category", "base_price",
                    "is_available", "is_featured")
    list_filter = ("kind", "is_available", "is_vegetarian", "is_vegan",
                   "contains_alcohol")
    search_fields = ("name", "slug", "sku")
    inlines = [MenuItemVariantInline, MenuItemModifierGroupInline]


@admin.register(MenuCategory)
class MenuCategoryAdmin(admin.ModelAdmin):
    list_display = ("name", "menu", "sort")
    search_fields = ("name", "slug")


@admin.register(ModifierGroup)
class ModifierGroupAdmin(admin.ModelAdmin):
    list_display = ("name", "restaurant", "is_required", "min_select", "max_select")
    search_fields = ("name",)
    inlines = [ModifierOptionInline]


admin.site.register(MenuAvailability)
