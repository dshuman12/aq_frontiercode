from datetime import time
from decimal import Decimal

import pytest

from apps.accounts.models import User
from apps.menus.selectors import (
    featured_items, items_available_now, menus_for_location,
)
from apps.menus.services import (
    add_item_availability, archive_menu, create_menu, create_menu_item,
)
from apps.restaurants.models import Restaurant


pytestmark = pytest.mark.django_db


def _restaurant():
    o = User.objects.create_user(email="o@x.com", password="pwpwpwpw")
    return Restaurant.objects.create(name="R", slug="r", owner=o)


def test_menus_excludes_archived():
    r = _restaurant()
    a = create_menu(restaurant=r, name="A")
    b = create_menu(restaurant=r, name="B")
    archive_menu(menu=a)
    out = menus_for_location(r.id)
    assert b in out
    assert a not in out


def test_featured_items():
    r = _restaurant()
    create_menu_item(restaurant=r, name="A",
                     base_price=Decimal("5"), is_featured=False)
    fi = create_menu_item(restaurant=r, name="B",
                          base_price=Decimal("5"), is_featured=True)
    out = featured_items(r.id)
    assert fi in out
    assert len(out) == 1


def test_items_available_now_filters_by_window():
    r = _restaurant()
    item = create_menu_item(restaurant=r, name="Lunch Special",
                            base_price=Decimal("12"))
    add_item_availability(item=item, weekday=2,
                          start_time=time(11, 0), end_time=time(14, 0))
    # Wed 12:00 → available
    assert item in items_available_now(r.id, weekday=2, t=time(12, 0))
    # Wed 15:00 → unavailable
    assert item not in items_available_now(r.id, weekday=2, t=time(15, 0))
