from __future__ import annotations

from datetime import time
from decimal import Decimal

import pytest

from apps.accounts.models import User
from apps.common.exceptions import Conflict, ValidationError
from apps.menus.models import (
    Menu, MenuCategory, MenuItem, MenuItemVariant, ModifierGroup, ModifierOption,
)
from apps.menus.services import (
    add_item_availability,
    add_menu_availability,
    add_modifier_option,
    add_variant,
    archive_item,
    archive_menu,
    attach_modifier_group,
    calculate_item_price,
    create_category,
    create_menu,
    create_menu_item,
    create_modifier_group,
    is_item_available_at,
    is_menu_available_at,
    update_menu_item,
    validate_modifier_selection,
)
from apps.restaurants.models import Restaurant


pytestmark = pytest.mark.django_db


def _restaurant():
    owner = User.objects.create_user(email="owner@x.com", password="pwpwpwpw")
    return Restaurant.objects.create(name="R", slug="r", owner=owner)


# -------------------- Menus --------------------

class TestCreateMenu:
    def test_creates_with_slug(self):
        r = _restaurant()
        m = create_menu(restaurant=r, name="Lunch Menu")
        assert m.slug == "lunch-menu"

    def test_blank_name_rejected(self):
        r = _restaurant()
        with pytest.raises(ValidationError):
            create_menu(restaurant=r, name="   ")

    def test_slug_collision_appends_suffix(self):
        r = _restaurant()
        a = create_menu(restaurant=r, name="Dinner")
        b = create_menu(restaurant=r, name="Dinner")
        assert a.slug == "dinner"
        assert b.slug == "dinner-2"

    def test_default_menu_unsets_others(self):
        r = _restaurant()
        a = create_menu(restaurant=r, name="A", is_default=True)
        b = create_menu(restaurant=r, name="B", is_default=True)
        a.refresh_from_db()
        assert b.is_default is True
        assert a.is_default is False

    def test_archive(self):
        r = _restaurant()
        m = create_menu(restaurant=r, name="X")
        archive_menu(menu=m)
        m.refresh_from_db()
        assert m.is_archived


class TestCreateCategory:
    def test_creates(self):
        r = _restaurant()
        m = create_menu(restaurant=r, name="Dinner")
        cat = create_category(menu=m, name="Appetizers")
        assert cat.slug == "appetizers"

    def test_blank_name(self):
        r = _restaurant()
        m = create_menu(restaurant=r, name="Dinner")
        with pytest.raises(ValidationError):
            create_category(menu=m, name="")


# -------------------- Items --------------------

class TestCreateMenuItem:
    def test_creates(self):
        r = _restaurant()
        item = create_menu_item(restaurant=r, name="Burger",
                                base_price=Decimal("12.50"))
        assert item.slug == "burger"
        assert item.base_price == Decimal("12.50")

    def test_negative_price_rejected(self):
        r = _restaurant()
        with pytest.raises(ValidationError):
            create_menu_item(restaurant=r, name="X", base_price=Decimal("-1"))

    def test_blank_name(self):
        r = _restaurant()
        with pytest.raises(ValidationError):
            create_menu_item(restaurant=r, name="   ", base_price=Decimal("5"))

    def test_with_category(self):
        r = _restaurant()
        m = create_menu(restaurant=r, name="Dinner")
        cat = create_category(menu=m, name="Mains")
        item = create_menu_item(restaurant=r, name="Steak",
                                base_price=Decimal("32"), category=cat)
        assert item.category == cat


class TestUpdateMenuItem:
    def test_updates_allowed_fields(self):
        r = _restaurant()
        item = create_menu_item(restaurant=r, name="Burger",
                                base_price=Decimal("10"))
        update_menu_item(item=item, name="Cheeseburger",
                         base_price=Decimal("12"), is_featured=True)
        item.refresh_from_db()
        assert item.name == "Cheeseburger"
        assert item.base_price == Decimal("12.00")
        assert item.is_featured is True

    def test_ignores_unknown_fields(self):
        r = _restaurant()
        item = create_menu_item(restaurant=r, name="Burger",
                                base_price=Decimal("10"))
        # nuclear_codes is not in allowed; should be silently ignored
        update_menu_item(item=item, nuclear_codes="123")

    def test_negative_price_rejected_in_update(self):
        r = _restaurant()
        item = create_menu_item(restaurant=r, name="Burger",
                                base_price=Decimal("10"))
        with pytest.raises(ValidationError):
            update_menu_item(item=item, base_price=Decimal("-5"))


class TestArchiveItem:
    def test_archive(self):
        r = _restaurant()
        item = create_menu_item(restaurant=r, name="Burger",
                                base_price=Decimal("10"))
        archive_item(item=item)
        item.refresh_from_db()
        assert item.is_archived


# -------------------- Variants --------------------

class TestVariants:
    def test_add(self):
        r = _restaurant()
        item = create_menu_item(restaurant=r, name="Pizza",
                                base_price=Decimal("12"))
        v = add_variant(item=item, name="Large", price_delta=Decimal("4"))
        assert v.price_delta == Decimal("4.00")

    def test_duplicate_name_conflict(self):
        r = _restaurant()
        item = create_menu_item(restaurant=r, name="Pizza",
                                base_price=Decimal("12"))
        add_variant(item=item, name="Small")
        with pytest.raises(Conflict):
            add_variant(item=item, name="Small")

    def test_blank_name(self):
        r = _restaurant()
        item = create_menu_item(restaurant=r, name="Pizza",
                                base_price=Decimal("12"))
        with pytest.raises(ValidationError):
            add_variant(item=item, name="   ")

    def test_default_unsets_others(self):
        r = _restaurant()
        item = create_menu_item(restaurant=r, name="Pizza",
                                base_price=Decimal("12"))
        v1 = add_variant(item=item, name="Small", is_default=True)
        v2 = add_variant(item=item, name="Large", is_default=True)
        v1.refresh_from_db()
        assert v2.is_default is True
        assert v1.is_default is False


# -------------------- Modifier groups --------------------

class TestModifierGroups:
    def test_create_group(self):
        r = _restaurant()
        g = create_modifier_group(restaurant=r, name="Toppings",
                                  is_required=True, min_select=1, max_select=3)
        assert g.is_required
        assert g.min_select == 1

    def test_min_exceeds_max_rejected(self):
        r = _restaurant()
        with pytest.raises(ValidationError):
            create_modifier_group(restaurant=r, name="Bad",
                                  min_select=5, max_select=2)

    def test_add_option(self):
        r = _restaurant()
        g = create_modifier_group(restaurant=r, name="Sauce")
        opt = add_modifier_option(group=g, name="BBQ",
                                  price_delta=Decimal("0.50"))
        assert opt.name == "BBQ"

    def test_duplicate_option_conflict(self):
        r = _restaurant()
        g = create_modifier_group(restaurant=r, name="Sauce")
        add_modifier_option(group=g, name="Ranch")
        with pytest.raises(Conflict):
            add_modifier_option(group=g, name="Ranch")

    def test_attach_group(self):
        r = _restaurant()
        item = create_menu_item(restaurant=r, name="Burger",
                                base_price=Decimal("10"))
        g = create_modifier_group(restaurant=r, name="Cheese")
        attach_modifier_group(item=item, group=g)
        with pytest.raises(Conflict):
            attach_modifier_group(item=item, group=g)


class TestValidateModifierSelection:
    def test_required_min_not_met(self):
        r = _restaurant()
        item = create_menu_item(restaurant=r, name="Burger",
                                base_price=Decimal("10"))
        g = create_modifier_group(
            restaurant=r, name="Protein",
            is_required=True, min_select=1, max_select=1,
        )
        add_modifier_option(group=g, name="Beef")
        attach_modifier_group(item=item, group=g)
        with pytest.raises(ValidationError) as exc:
            validate_modifier_selection(item=item, selections={})
        assert exc.value.code == "modifier_min_not_met"

    def test_max_exceeded(self):
        r = _restaurant()
        item = create_menu_item(restaurant=r, name="Pizza",
                                base_price=Decimal("12"))
        g = create_modifier_group(
            restaurant=r, name="Toppings",
            is_required=False, min_select=0, max_select=2,
        )
        o1 = add_modifier_option(group=g, name="Mushroom")
        o2 = add_modifier_option(group=g, name="Olive")
        o3 = add_modifier_option(group=g, name="Onion")
        attach_modifier_group(item=item, group=g)
        with pytest.raises(ValidationError) as exc:
            validate_modifier_selection(
                item=item,
                selections={str(g.id): [str(o1.id), str(o2.id), str(o3.id)]},
            )
        assert exc.value.code == "modifier_max_exceeded"

    def test_invalid_option(self):
        import uuid
        r = _restaurant()
        item = create_menu_item(restaurant=r, name="Pizza",
                                base_price=Decimal("12"))
        g = create_modifier_group(restaurant=r, name="X", max_select=5)
        attach_modifier_group(item=item, group=g)
        with pytest.raises(ValidationError) as exc:
            validate_modifier_selection(
                item=item,
                selections={str(g.id): [str(uuid.uuid4())]},
            )
        assert exc.value.code == "modifier_option_invalid"

    def test_valid_selection_passes(self):
        r = _restaurant()
        item = create_menu_item(restaurant=r, name="Burger",
                                base_price=Decimal("10"))
        g = create_modifier_group(restaurant=r, name="Cook",
                                  is_required=True, min_select=1, max_select=1)
        opt = add_modifier_option(group=g, name="Medium")
        attach_modifier_group(item=item, group=g)
        # should not raise
        validate_modifier_selection(
            item=item, selections={str(g.id): [str(opt.id)]},
        )


# -------------------- Pricing --------------------

class TestCalculateItemPrice:
    def test_base_only(self):
        r = _restaurant()
        item = create_menu_item(restaurant=r, name="Burger",
                                base_price=Decimal("10"))
        assert calculate_item_price(item=item) == Decimal("10.00")

    def test_with_variant(self):
        r = _restaurant()
        item = create_menu_item(restaurant=r, name="Pizza",
                                base_price=Decimal("12"))
        v = add_variant(item=item, name="L", price_delta=Decimal("4"))
        assert calculate_item_price(item=item, variant=v) == Decimal("16.00")

    def test_with_modifiers(self):
        r = _restaurant()
        item = create_menu_item(restaurant=r, name="Burger",
                                base_price=Decimal("10"))
        g = create_modifier_group(restaurant=r, name="Add-ons", max_select=5)
        bacon = add_modifier_option(group=g, name="Bacon",
                                    price_delta=Decimal("2"))
        avocado = add_modifier_option(group=g, name="Avocado",
                                      price_delta=Decimal("1.50"))
        price = calculate_item_price(item=item, modifier_options=[bacon, avocado])
        assert price == Decimal("13.50")

    def test_negative_clamped_to_zero(self):
        r = _restaurant()
        item = create_menu_item(restaurant=r, name="Free",
                                base_price=Decimal("1"))
        g = create_modifier_group(restaurant=r, name="Discount", max_select=1)
        coupon = add_modifier_option(group=g, name="-$5",
                                     price_delta=Decimal("-5"))
        assert calculate_item_price(item=item,
                                    modifier_options=[coupon]) == Decimal("0")


# -------------------- Availability --------------------

class TestAvailability:
    def test_add_menu_availability(self):
        r = _restaurant()
        m = create_menu(restaurant=r, name="Lunch")
        rule = add_menu_availability(
            menu=m, weekday=0, start_time=time(11, 0), end_time=time(14, 0),
        )
        assert rule.kind == "menu"

    def test_invalid_time_range(self):
        r = _restaurant()
        m = create_menu(restaurant=r, name="X")
        with pytest.raises(ValidationError):
            add_menu_availability(
                menu=m, weekday=0,
                start_time=time(14, 0), end_time=time(11, 0),
            )

    def test_invalid_weekday(self):
        r = _restaurant()
        m = create_menu(restaurant=r, name="X")
        with pytest.raises(ValidationError):
            add_menu_availability(
                menu=m, weekday=8,
                start_time=time(11, 0), end_time=time(14, 0),
            )

    def test_is_menu_available_no_rules_means_yes(self):
        r = _restaurant()
        m = create_menu(restaurant=r, name="Lunch")
        assert is_menu_available_at(m, weekday=0, time=time(12, 0))

    def test_is_menu_available_within_window(self):
        r = _restaurant()
        m = create_menu(restaurant=r, name="Lunch")
        add_menu_availability(menu=m, weekday=0,
                              start_time=time(11, 0), end_time=time(14, 0))
        assert is_menu_available_at(m, weekday=0, time=time(12, 0))
        assert not is_menu_available_at(m, weekday=0, time=time(15, 0))
        # different weekday
        assert not is_menu_available_at(m, weekday=2, time=time(12, 0))

    def test_item_unavailable_when_flag_off(self):
        r = _restaurant()
        item = create_menu_item(restaurant=r, name="X",
                                base_price=Decimal("5"), is_available=False)
        assert not is_item_available_at(item, weekday=0, time=time(12, 0))

    def test_add_item_availability(self):
        r = _restaurant()
        item = create_menu_item(restaurant=r, name="Brunch Special",
                                base_price=Decimal("15"))
        rule = add_item_availability(
            item=item, weekday=5, start_time=time(10, 0), end_time=time(14, 0),
        )
        assert rule.kind == "item"
        assert is_item_available_at(item, weekday=5, time=time(11, 0))
        assert not is_item_available_at(item, weekday=5, time=time(15, 0))
