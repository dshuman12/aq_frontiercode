from __future__ import annotations

from decimal import Decimal

import pytest
from rest_framework.test import APIClient

from apps.accounts.models import User
from apps.menus.models import Menu, MenuItem
from apps.menus.services import create_menu, create_menu_item
from apps.restaurants.models import Restaurant, RestaurantMember


pytestmark = pytest.mark.django_db


def _login(user):
    c = APIClient()
    c.force_authenticate(user=user)
    return c


@pytest.fixture
def setup():
    owner = User.objects.create_user(email="o@x.com", password="pwpwpwpw")
    rest = Restaurant.objects.create(name="R", slug="r", owner=owner)
    RestaurantMember.objects.create(
        restaurant=rest, user=owner, roles=["owner"], status="active",
    )
    server = User.objects.create_user(email="s@x.com", password="pwpwpwpw")
    RestaurantMember.objects.create(
        restaurant=rest, user=server, roles=["server"], status="active",
    )
    return {"rest": rest, "owner": owner, "server": server}


class TestMenuViews:
    def test_create_menu(self, setup):
        c = _login(setup["owner"])
        resp = c.post(f"/api/menus/{setup['rest'].id}/",
                      {"name": "Dinner Menu", "kind": "dinner"}, format="json")
        assert resp.status_code == 201
        assert resp.data["menu"]["slug"] == "dinner-menu"

    def test_server_cannot_create_menu(self, setup):
        c = _login(setup["server"])
        resp = c.post(f"/api/menus/{setup['rest'].id}/",
                      {"name": "Secret Menu"}, format="json")
        assert resp.status_code == 403

    def test_list_menus(self, setup):
        create_menu(restaurant=setup["rest"], name="Lunch")
        create_menu(restaurant=setup["rest"], name="Dinner")
        c = _login(setup["owner"])
        resp = c.get(f"/api/menus/{setup['rest'].id}/")
        assert resp.status_code == 200
        assert len(resp.data["results"]) == 2

    def test_archive_menu(self, setup):
        m = create_menu(restaurant=setup["rest"], name="X")
        c = _login(setup["owner"])
        resp = c.delete(f"/api/menus/{setup['rest'].id}/menus/{m.id}/")
        assert resp.status_code == 200
        m.refresh_from_db()
        assert m.is_archived

    def test_create_category(self, setup):
        m = create_menu(restaurant=setup["rest"], name="Dinner")
        c = _login(setup["owner"])
        resp = c.post(
            f"/api/menus/{setup['rest'].id}/menus/{m.id}/categories/",
            {"name": "Appetizers"}, format="json",
        )
        assert resp.status_code == 201


class TestMenuItemViews:
    def test_create_item(self, setup):
        c = _login(setup["owner"])
        resp = c.post(
            f"/api/menus/{setup['rest'].id}/items/",
            {"name": "Burger", "base_price": "12.50", "kind": "food"},
            format="json",
        )
        assert resp.status_code == 201
        assert resp.data["item"]["base_price"] == "12.50"

    def test_create_item_invalid_price(self, setup):
        c = _login(setup["owner"])
        resp = c.post(
            f"/api/menus/{setup['rest'].id}/items/",
            {"name": "Burger", "base_price": "not-a-number"},
            format="json",
        )
        assert resp.status_code == 400

    def test_list_items_with_kind_filter(self, setup):
        create_menu_item(restaurant=setup["rest"], name="Beer",
                         base_price=Decimal("6"), kind="alcohol")
        create_menu_item(restaurant=setup["rest"], name="Salad",
                         base_price=Decimal("8"), kind="food")
        c = _login(setup["owner"])
        resp = c.get(f"/api/menus/{setup['rest'].id}/items/?kind=alcohol")
        assert resp.status_code == 200
        assert len(resp.data["results"]) == 1
        assert resp.data["results"][0]["name"] == "Beer"

    def test_list_items_q_filter(self, setup):
        create_menu_item(restaurant=setup["rest"], name="Tomato Soup",
                         base_price=Decimal("8"))
        create_menu_item(restaurant=setup["rest"], name="Beef Stew",
                         base_price=Decimal("16"))
        c = _login(setup["owner"])
        resp = c.get(f"/api/menus/{setup['rest'].id}/items/?q=tomato")
        assert len(resp.data["results"]) == 1

    def test_list_items_available_only(self, setup):
        create_menu_item(restaurant=setup["rest"], name="A",
                         base_price=Decimal("5"), is_available=False)
        create_menu_item(restaurant=setup["rest"], name="B",
                         base_price=Decimal("5"), is_available=True)
        c = _login(setup["owner"])
        resp = c.get(f"/api/menus/{setup['rest'].id}/items/?available_only=true")
        assert len(resp.data["results"]) == 1

    def test_patch_item(self, setup):
        item = create_menu_item(restaurant=setup["rest"], name="X",
                                base_price=Decimal("10"))
        c = _login(setup["owner"])
        resp = c.patch(
            f"/api/menus/{setup['rest'].id}/items/{item.id}/",
            {"base_price": "12.99", "is_featured": True}, format="json",
        )
        assert resp.status_code == 200
        item.refresh_from_db()
        assert item.base_price == Decimal("12.99")
        assert item.is_featured is True

    def test_archive_item(self, setup):
        item = create_menu_item(restaurant=setup["rest"], name="X",
                                base_price=Decimal("10"))
        c = _login(setup["owner"])
        resp = c.delete(f"/api/menus/{setup['rest'].id}/items/{item.id}/")
        assert resp.status_code == 200
        item.refresh_from_db()
        assert item.is_archived

    def test_list_excludes_archived(self, setup):
        a = create_menu_item(restaurant=setup["rest"], name="Old",
                             base_price=Decimal("5"))
        a.archive()
        create_menu_item(restaurant=setup["rest"], name="New",
                         base_price=Decimal("5"))
        c = _login(setup["owner"])
        resp = c.get(f"/api/menus/{setup['rest'].id}/items/")
        assert len(resp.data["results"]) == 1


class TestVariants:
    def test_add_variant(self, setup):
        item = create_menu_item(restaurant=setup["rest"], name="Pizza",
                                base_price=Decimal("12"))
        c = _login(setup["owner"])
        resp = c.post(
            f"/api/menus/{setup['rest'].id}/items/{item.id}/variants/",
            {"name": "Large", "price_delta": "4"}, format="json",
        )
        assert resp.status_code == 201

    def test_server_cannot_add_variant(self, setup):
        item = create_menu_item(restaurant=setup["rest"], name="Pizza",
                                base_price=Decimal("12"))
        c = _login(setup["server"])
        resp = c.post(
            f"/api/menus/{setup['rest'].id}/items/{item.id}/variants/",
            {"name": "Large"}, format="json",
        )
        assert resp.status_code == 403


class TestModifierGroups:
    def test_create_group(self, setup):
        c = _login(setup["owner"])
        resp = c.post(
            f"/api/menus/{setup['rest'].id}/modifier-groups/",
            {"name": "Toppings", "is_required": False,
             "min_select": 0, "max_select": 3},
            format="json",
        )
        assert resp.status_code == 201
        assert resp.data["group"]["max_select"] == 3

    def test_add_option(self, setup):
        c = _login(setup["owner"])
        resp = c.post(
            f"/api/menus/{setup['rest'].id}/modifier-groups/",
            {"name": "Sauce", "max_select": 2}, format="json",
        )
        gid = resp.data["group"]["id"]
        resp = c.post(
            f"/api/menus/{setup['rest'].id}/modifier-groups/{gid}/options/",
            {"name": "Ranch", "price_delta": "0.50"}, format="json",
        )
        assert resp.status_code == 201

    def test_attach_group_to_item(self, setup):
        item = create_menu_item(restaurant=setup["rest"], name="X",
                                base_price=Decimal("10"))
        c = _login(setup["owner"])
        resp = c.post(
            f"/api/menus/{setup['rest'].id}/modifier-groups/",
            {"name": "Add-ons"}, format="json",
        )
        gid = resp.data["group"]["id"]
        resp = c.post(
            f"/api/menus/{setup['rest'].id}/items/{item.id}/modifier-groups/{gid}/",
            format="json",
        )
        assert resp.status_code == 201


class TestAvailability:
    def test_add_menu_availability(self, setup):
        m = create_menu(restaurant=setup["rest"], name="Lunch")
        c = _login(setup["owner"])
        resp = c.post(
            f"/api/menus/{setup['rest'].id}/menus/{m.id}/availability/",
            {"weekday": 0, "start_time": "11:00:00", "end_time": "14:00:00"},
            format="json",
        )
        assert resp.status_code == 201

    def test_invalid_weekday_400(self, setup):
        m = create_menu(restaurant=setup["rest"], name="Lunch")
        c = _login(setup["owner"])
        resp = c.post(
            f"/api/menus/{setup['rest'].id}/menus/{m.id}/availability/",
            {"weekday": 9, "start_time": "11:00:00", "end_time": "14:00:00"},
            format="json",
        )
        assert resp.status_code == 400
