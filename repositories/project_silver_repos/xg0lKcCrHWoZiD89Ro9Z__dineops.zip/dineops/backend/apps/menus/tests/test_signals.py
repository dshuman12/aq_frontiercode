"""Smoke test that menus signals don't break order flows."""
import pytest


pytestmark = pytest.mark.django_db


def test_menu_module_imports():
    from apps.menus import models, services, serializers, views, urls
    assert all([models, services, serializers, views, urls])
