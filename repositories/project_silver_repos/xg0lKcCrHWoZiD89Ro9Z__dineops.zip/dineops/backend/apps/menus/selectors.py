from __future__ import annotations

from datetime import time

from .models import Menu, MenuItem
from .services import is_item_available_at, is_menu_available_at


def menus_for_location(restaurant_id, *, location_id=None) -> list[Menu]:
    qs = Menu.objects.filter(
        restaurant_id=restaurant_id, archived_at__isnull=True,
    ).order_by("sort", "name")
    return list(qs)


def items_available_now(restaurant_id, *, weekday: int, t: time) -> list[MenuItem]:
    """Return items that are available given the day-of-week and time."""
    candidates = MenuItem.objects.filter(
        restaurant_id=restaurant_id, is_available=True,
        archived_at__isnull=True,
    )
    return [it for it in candidates if is_item_available_at(it, weekday=weekday, time=t)]


def featured_items(restaurant_id) -> list[MenuItem]:
    return list(MenuItem.objects.filter(
        restaurant_id=restaurant_id, is_featured=True, is_available=True,
        archived_at__isnull=True,
    ).order_by("sort", "name"))
