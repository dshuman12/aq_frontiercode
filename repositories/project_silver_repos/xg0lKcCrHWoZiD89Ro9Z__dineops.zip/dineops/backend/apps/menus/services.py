from __future__ import annotations

from decimal import Decimal
from typing import Iterable

from django.db import transaction
from django.utils.text import slugify

from apps.common.exceptions import Conflict, NotFound, ValidationError

from .models import (
    Menu, MenuAvailability, MenuCategory, MenuItem, MenuItemModifierGroup,
    MenuItemVariant, ModifierGroup, ModifierOption,
)


def _slug_unique(model, *, restaurant=None, menu=None, name: str, max_len=80):
    base = slugify(name)[:max_len] or "menu"
    candidate = base
    i = 2
    qs = model.objects.all()
    if restaurant is not None:
        qs = qs.filter(restaurant=restaurant)
    if menu is not None:
        qs = qs.filter(menu=menu)
    while qs.filter(slug=candidate).exists():
        suffix = f"-{i}"
        candidate = (base[: max_len - len(suffix)]) + suffix
        i += 1
    return candidate


# -------------------- Menus --------------------

@transaction.atomic
def create_menu(*, restaurant, name: str, kind: str = "regular", **fields) -> Menu:
    if not name.strip():
        raise ValidationError("invalid_name")
    slug = _slug_unique(Menu, restaurant=restaurant, name=name)
    menu = Menu.objects.create(
        restaurant=restaurant, name=name.strip(), slug=slug, kind=kind, **fields,
    )
    if menu.is_default:
        Menu.objects.filter(restaurant=restaurant).exclude(id=menu.id).update(is_default=False)
    return menu


@transaction.atomic
def update_menu(*, menu: Menu, **fields) -> Menu:
    allowed = {"name", "kind", "description", "sort",
               "service_charge_percent", "tax_percent", "is_default"}
    for k, v in fields.items():
        if k in allowed:
            setattr(menu, k, v)
    if fields.get("is_default"):
        Menu.objects.filter(restaurant=menu.restaurant).exclude(id=menu.id).update(is_default=False)
    menu.save()
    return menu


@transaction.atomic
def archive_menu(*, menu: Menu) -> Menu:
    menu.archive()
    return menu


# -------------------- Categories --------------------

@transaction.atomic
def create_category(*, menu: Menu, name: str, **fields) -> MenuCategory:
    if not name.strip():
        raise ValidationError("invalid_name")
    slug = _slug_unique(MenuCategory, menu=menu, name=name)
    return MenuCategory.objects.create(
        menu=menu, name=name.strip(), slug=slug, **fields,
    )


# -------------------- Items --------------------

@transaction.atomic
def create_menu_item(*, restaurant, name: str, base_price: Decimal,
                     category: MenuCategory | None = None, **fields) -> MenuItem:
    if not name.strip():
        raise ValidationError("invalid_name")
    if base_price is None or base_price < 0:
        raise ValidationError("invalid_price")
    slug = _slug_unique(MenuItem, restaurant=restaurant, name=name, max_len=120)
    return MenuItem.objects.create(
        restaurant=restaurant, name=name.strip(), slug=slug,
        base_price=base_price, category=category, **fields,
    )


@transaction.atomic
def update_menu_item(*, item: MenuItem, **fields) -> MenuItem:
    allowed = {
        "name", "kind", "description",
        "base_price", "cost_basis",
        "is_available", "is_featured", "sort",
        "image_url", "sku", "barcode",
        "contains_alcohol", "is_vegetarian", "is_vegan", "is_gluten_free",
        "spice_level", "allergen_tags", "calories",
        "requires_age_verification", "category",
    }
    if "base_price" in fields and fields["base_price"] is not None and fields["base_price"] < 0:
        raise ValidationError("invalid_price")
    for k, v in fields.items():
        if k in allowed:
            setattr(item, k, v)
    item.save()
    return item


@transaction.atomic
def archive_item(*, item: MenuItem) -> MenuItem:
    item.archive()
    return item


@transaction.atomic
def add_variant(*, item: MenuItem, name: str, price_delta: Decimal = Decimal("0"),
                is_default: bool = False, sort: int = 0) -> MenuItemVariant:
    if not name.strip():
        raise ValidationError("invalid_name")
    if MenuItemVariant.objects.filter(item=item, name=name).exists():
        raise Conflict("variant_already_exists")
    if is_default:
        MenuItemVariant.objects.filter(item=item, is_default=True).update(is_default=False)
    return MenuItemVariant.objects.create(
        item=item, name=name.strip(), price_delta=price_delta,
        is_default=is_default, sort=sort,
    )


# -------------------- Modifier groups + options --------------------

@transaction.atomic
def create_modifier_group(*, restaurant, name: str, is_required: bool = False,
                          min_select: int = 0, max_select: int = 1,
                          sort: int = 0) -> ModifierGroup:
    if min_select > max_select:
        raise ValidationError("min_select_exceeds_max_select")
    return ModifierGroup.objects.create(
        restaurant=restaurant, name=name, is_required=is_required,
        min_select=min_select, max_select=max_select, sort=sort,
    )


@transaction.atomic
def add_modifier_option(*, group: ModifierGroup, name: str,
                        price_delta: Decimal = Decimal("0"),
                        is_default: bool = False, sort: int = 0) -> ModifierOption:
    if ModifierOption.objects.filter(group=group, name=name).exists():
        raise Conflict("option_already_exists")
    return ModifierOption.objects.create(
        group=group, name=name, price_delta=price_delta,
        is_default=is_default, sort=sort,
    )


@transaction.atomic
def attach_modifier_group(*, item: MenuItem, group: ModifierGroup,
                          sort: int = 0) -> MenuItemModifierGroup:
    if MenuItemModifierGroup.objects.filter(item=item, group=group).exists():
        raise Conflict("group_already_attached")
    return MenuItemModifierGroup.objects.create(item=item, group=group, sort=sort)


def validate_modifier_selection(*, item: MenuItem, selections: dict) -> None:
    """Raise if a customer's selection for an item violates the group rules.
    selections: { modifier_group_id: [option_id, option_id, ...] }
    """
    for link in item.modifier_links.select_related("group").prefetch_related("group__options"):
        group = link.group
        chosen = selections.get(str(group.id), [])
        if group.is_required and len(chosen) < group.min_select:
            raise ValidationError(
                "modifier_min_not_met",
                fields={"group_id": str(group.id), "name": group.name,
                        "min": group.min_select},
            )
        if len(chosen) > group.max_select:
            raise ValidationError(
                "modifier_max_exceeded",
                fields={"group_id": str(group.id), "name": group.name,
                        "max": group.max_select},
            )
        valid_ids = {str(o.id) for o in group.options.all()}
        for chosen_id in chosen:
            if chosen_id not in valid_ids:
                raise ValidationError(
                    "modifier_option_invalid",
                    fields={"option_id": chosen_id},
                )


# -------------------- Pricing --------------------

def calculate_item_price(
    *,
    item: MenuItem,
    variant: MenuItemVariant | None = None,
    modifier_options: Iterable[ModifierOption] | None = None,
) -> Decimal:
    price = item.base_price
    if variant:
        price = price + variant.price_delta
    if modifier_options:
        for opt in modifier_options:
            price = price + opt.price_delta
    if price < 0:
        return Decimal("0")
    return price.quantize(Decimal("0.01"))


# -------------------- Availability --------------------

@transaction.atomic
def add_menu_availability(*, menu: Menu, weekday: int,
                          start_time, end_time) -> MenuAvailability:
    if not (0 <= weekday <= 6):
        raise ValidationError("invalid_weekday")
    if start_time >= end_time:
        raise ValidationError("invalid_time_range")
    return MenuAvailability.objects.create(
        kind="menu", menu=menu, weekday=weekday,
        start_time=start_time, end_time=end_time,
    )


@transaction.atomic
def add_item_availability(*, item: MenuItem, weekday: int,
                          start_time, end_time) -> MenuAvailability:
    if not (0 <= weekday <= 6):
        raise ValidationError("invalid_weekday")
    if start_time >= end_time:
        raise ValidationError("invalid_time_range")
    return MenuAvailability.objects.create(
        kind="item", item=item, weekday=weekday,
        start_time=start_time, end_time=end_time,
    )


def is_menu_available_at(menu: Menu, *, weekday: int, time) -> bool:
    rules = menu.availability_rules.filter(weekday=weekday)
    if not rules.exists():
        return True  # no rules = always available
    return rules.filter(start_time__lte=time, end_time__gte=time).exists()


def is_item_available_at(item: MenuItem, *, weekday: int, time) -> bool:
    if not item.is_available:
        return False
    rules = item.availability_rules.filter(weekday=weekday)
    if not rules.exists():
        return True
    return rules.filter(start_time__lte=time, end_time__gte=time).exists()
