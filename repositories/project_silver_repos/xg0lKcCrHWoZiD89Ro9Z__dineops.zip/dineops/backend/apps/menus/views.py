from __future__ import annotations

from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common.exceptions import NotFound, PermissionDenied
from apps.restaurants.models import Restaurant, RestaurantMember

from . import services
from .models import Menu, MenuCategory, MenuItem, ModifierGroup
from .serializers import (
    AddAvailabilitySerializer,
    AddModifierOptionSerializer,
    AddVariantSerializer,
    CreateCategorySerializer,
    CreateMenuItemSerializer,
    CreateMenuSerializer,
    CreateModifierGroupSerializer,
    MenuAvailabilitySerializer,
    MenuCategorySerializer,
    MenuItemSerializer,
    MenuSerializer,
    ModifierGroupSerializer,
    ModifierOptionSerializer,
)


def _require_member(user, restaurant_id) -> RestaurantMember:
    m = RestaurantMember.objects.filter(
        restaurant_id=restaurant_id, user=user, status="active",
    ).first()
    if not m:
        raise PermissionDenied("not_a_member")
    return m


def _can_manage_menu(roles):
    return any(r in ("owner", "general_manager", "assistant_manager") for r in roles or [])


# -------------------- Menus --------------------

class MenuListCreate(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        _require_member(request.user, restaurant_id)
        qs = Menu.objects.filter(
            restaurant_id=restaurant_id, archived_at__isnull=True,
        ).prefetch_related("categories__items__variants").order_by("sort", "name")
        return Response({"results": MenuSerializer(qs, many=True).data})

    def post(self, request, restaurant_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_manage_menu(member.roles):
            raise PermissionDenied()
        s = CreateMenuSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        rest = Restaurant.objects.get(id=restaurant_id)
        menu = services.create_menu(restaurant=rest, **s.validated_data)
        return Response({"menu": MenuSerializer(menu).data}, status=201)


class MenuDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id, menu_id):
        _require_member(request.user, restaurant_id)
        menu = Menu.objects.filter(id=menu_id, restaurant_id=restaurant_id).first()
        if not menu:
            raise NotFound()
        return Response({"menu": MenuSerializer(menu).data})

    def patch(self, request, restaurant_id, menu_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_manage_menu(member.roles):
            raise PermissionDenied()
        menu = Menu.objects.filter(id=menu_id, restaurant_id=restaurant_id).first()
        if not menu:
            raise NotFound()
        services.update_menu(menu=menu, **request.data)
        return Response({"menu": MenuSerializer(menu).data})

    def delete(self, request, restaurant_id, menu_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_manage_menu(member.roles):
            raise PermissionDenied()
        menu = Menu.objects.filter(id=menu_id, restaurant_id=restaurant_id).first()
        if not menu:
            raise NotFound()
        services.archive_menu(menu=menu)
        return Response({"ok": True})


# -------------------- Categories --------------------

class CategoryListCreate(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, menu_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_manage_menu(member.roles):
            raise PermissionDenied()
        menu = Menu.objects.filter(id=menu_id, restaurant_id=restaurant_id).first()
        if not menu:
            raise NotFound()
        s = CreateCategorySerializer(data=request.data)
        s.is_valid(raise_exception=True)
        cat = services.create_category(menu=menu, **s.validated_data)
        return Response({"category": MenuCategorySerializer(cat).data}, status=201)


# -------------------- Items --------------------

class MenuItemListCreate(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        _require_member(request.user, restaurant_id)
        qs = MenuItem.objects.filter(
            restaurant_id=restaurant_id, archived_at__isnull=True,
        ).prefetch_related("variants").order_by("sort", "name")
        if (q := request.GET.get("q")):
            qs = qs.filter(name__icontains=q)
        if (kind := request.GET.get("kind")):
            qs = qs.filter(kind=kind)
        if request.GET.get("available_only") == "true":
            qs = qs.filter(is_available=True)
        return Response({"results": MenuItemSerializer(qs[:500], many=True).data})

    def post(self, request, restaurant_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_manage_menu(member.roles):
            raise PermissionDenied()
        s = CreateMenuItemSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        rest = Restaurant.objects.get(id=restaurant_id)
        category = None
        cid = s.validated_data.pop("category_id", None)
        if cid:
            category = MenuCategory.objects.filter(
                id=cid, menu__restaurant_id=restaurant_id,
            ).first()
            if not category:
                raise NotFound("category_not_found")
        item = services.create_menu_item(
            restaurant=rest, category=category, **s.validated_data,
        )
        return Response({"item": MenuItemSerializer(item).data}, status=201)


class MenuItemDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id, item_id):
        _require_member(request.user, restaurant_id)
        item = MenuItem.objects.filter(
            id=item_id, restaurant_id=restaurant_id,
        ).prefetch_related("variants", "modifier_links__group__options").first()
        if not item:
            raise NotFound()
        return Response({"item": MenuItemSerializer(item).data})

    def patch(self, request, restaurant_id, item_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_manage_menu(member.roles):
            raise PermissionDenied()
        item = MenuItem.objects.filter(
            id=item_id, restaurant_id=restaurant_id,
        ).first()
        if not item:
            raise NotFound()
        services.update_menu_item(item=item, **request.data)
        return Response({"item": MenuItemSerializer(item).data})

    def delete(self, request, restaurant_id, item_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_manage_menu(member.roles):
            raise PermissionDenied()
        item = MenuItem.objects.filter(
            id=item_id, restaurant_id=restaurant_id,
        ).first()
        if not item:
            raise NotFound()
        services.archive_item(item=item)
        return Response({"ok": True})


class MenuItemVariantCreate(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, item_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_manage_menu(member.roles):
            raise PermissionDenied()
        item = MenuItem.objects.filter(
            id=item_id, restaurant_id=restaurant_id,
        ).first()
        if not item:
            raise NotFound()
        s = AddVariantSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        variant = services.add_variant(item=item, **s.validated_data)
        return Response({"variant": {
            "id": str(variant.id), "name": variant.name,
            "price_delta": str(variant.price_delta),
            "is_default": variant.is_default, "sort": variant.sort,
        }}, status=201)


# -------------------- Modifier groups --------------------

class ModifierGroupListCreate(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        _require_member(request.user, restaurant_id)
        groups = ModifierGroup.objects.filter(
            restaurant_id=restaurant_id,
        ).prefetch_related("options").order_by("sort", "name")
        return Response({"results": ModifierGroupSerializer(groups, many=True).data})

    def post(self, request, restaurant_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_manage_menu(member.roles):
            raise PermissionDenied()
        s = CreateModifierGroupSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        rest = Restaurant.objects.get(id=restaurant_id)
        group = services.create_modifier_group(restaurant=rest, **s.validated_data)
        return Response({"group": ModifierGroupSerializer(group).data}, status=201)


class ModifierOptionCreate(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, group_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_manage_menu(member.roles):
            raise PermissionDenied()
        group = ModifierGroup.objects.filter(
            id=group_id, restaurant_id=restaurant_id,
        ).first()
        if not group:
            raise NotFound()
        s = AddModifierOptionSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        opt = services.add_modifier_option(group=group, **s.validated_data)
        return Response({"option": ModifierOptionSerializer(opt).data}, status=201)


class AttachModifierGroupView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, item_id, group_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_manage_menu(member.roles):
            raise PermissionDenied()
        item = MenuItem.objects.filter(
            id=item_id, restaurant_id=restaurant_id,
        ).first()
        group = ModifierGroup.objects.filter(
            id=group_id, restaurant_id=restaurant_id,
        ).first()
        if not item or not group:
            raise NotFound()
        services.attach_modifier_group(item=item, group=group)
        return Response({"ok": True}, status=201)


# -------------------- Availability --------------------

class MenuAvailabilityCreate(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, menu_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_manage_menu(member.roles):
            raise PermissionDenied()
        menu = Menu.objects.filter(id=menu_id, restaurant_id=restaurant_id).first()
        if not menu:
            raise NotFound()
        s = AddAvailabilitySerializer(data=request.data)
        s.is_valid(raise_exception=True)
        rule = services.add_menu_availability(menu=menu, **s.validated_data)
        return Response({"rule": MenuAvailabilitySerializer(rule).data}, status=201)


class ItemAvailabilityCreate(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, item_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_manage_menu(member.roles):
            raise PermissionDenied()
        item = MenuItem.objects.filter(
            id=item_id, restaurant_id=restaurant_id,
        ).first()
        if not item:
            raise NotFound()
        s = AddAvailabilitySerializer(data=request.data)
        s.is_valid(raise_exception=True)
        rule = services.add_item_availability(item=item, **s.validated_data)
        return Response({"rule": MenuAvailabilitySerializer(rule).data}, status=201)
