from __future__ import annotations

from decimal import Decimal

from django.core.management.base import BaseCommand
from django.db import transaction

from apps.menus.services import (
    add_modifier_option, add_variant, attach_modifier_group,
    create_category, create_menu, create_menu_item, create_modifier_group,
)
from apps.restaurants.models import Restaurant


class Command(BaseCommand):
    help = "Seed a demo menu (Lunch + Dinner) for a restaurant. Usage: " \
           "manage.py seed_menu_demo <restaurant-slug>"

    def add_arguments(self, parser):
        parser.add_argument("slug", type=str)

    @transaction.atomic
    def handle(self, *args, slug, **options):
        rest = Restaurant.objects.filter(slug=slug).first()
        if not rest:
            self.stderr.write(f"No restaurant '{slug}'.")
            return

        # Lunch menu
        lunch = create_menu(restaurant=rest, name="Lunch", kind="lunch",
                            description="Mon-Fri 11am-2pm",
                            tax_percent=Decimal("8.5"))
        salads = create_category(menu=lunch, name="Salads", sort=10)
        sandwiches = create_category(menu=lunch, name="Sandwiches", sort=20)
        soups = create_category(menu=lunch, name="Soups", sort=30)

        cats_for = {
            ("Caesar Salad", "12.00"): salads,
            ("Cobb Salad", "14.50"): salads,
            ("Greek Salad", "13.00"): salads,
            ("Turkey Club", "13.50"): sandwiches,
            ("Grilled Cheese", "9.50"): sandwiches,
            ("BLT", "11.00"): sandwiches,
            ("Tomato Bisque", "8.50"): soups,
            ("Chicken Noodle", "9.00"): soups,
        }
        for (name, price), cat in cats_for.items():
            create_menu_item(restaurant=rest, name=name,
                             base_price=Decimal(price), category=cat)

        # Dinner menu
        dinner = create_menu(restaurant=rest, name="Dinner", kind="dinner",
                             description="5pm onwards", is_default=True)
        starters = create_category(menu=dinner, name="Starters", sort=10)
        mains = create_category(menu=dinner, name="Mains", sort=20)
        desserts = create_category(menu=dinner, name="Desserts", sort=30)

        steak = create_menu_item(restaurant=rest, name="NY Strip Steak",
                                 base_price=Decimal("32"), category=mains,
                                 is_featured=True)
        add_variant(item=steak, name="8oz", price_delta=Decimal("0"),
                    is_default=True)
        add_variant(item=steak, name="12oz", price_delta=Decimal("8"))
        add_variant(item=steak, name="16oz", price_delta=Decimal("16"))

        # Cooking temperature modifier (required, single-select)
        cook = create_modifier_group(
            restaurant=rest, name="Cooking Temperature",
            is_required=True, min_select=1, max_select=1,
        )
        for temp in ("Rare", "Medium Rare", "Medium", "Medium Well", "Well Done"):
            add_modifier_option(group=cook, name=temp)
        attach_modifier_group(item=steak, group=cook)

        # Sides modifier (multi-select)
        sides = create_modifier_group(
            restaurant=rest, name="Sides",
            is_required=False, min_select=0, max_select=2,
        )
        for side, delta in [
            ("Mashed Potato", "0"),
            ("French Fries", "0"),
            ("Asparagus", "2.50"),
            ("Truffle Fries", "4.00"),
        ]:
            add_modifier_option(group=sides, name=side,
                                price_delta=Decimal(delta))
        attach_modifier_group(item=steak, group=sides)

        # Other dinner items
        for name, price, cat in [
            ("Bruschetta", "9.00", starters),
            ("Calamari Fritti", "13.00", starters),
            ("Mussels Marinière", "16.00", starters),
            ("Roast Chicken", "26.00", mains),
            ("Pan-Seared Salmon", "30.00", mains),
            ("Mushroom Risotto", "22.00", mains),
            ("Tiramisu", "8.50", desserts),
            ("Chocolate Lava Cake", "9.00", desserts),
            ("Crème Brûlée", "9.50", desserts),
        ]:
            create_menu_item(restaurant=rest, name=name,
                             base_price=Decimal(price), category=cat)

        # Drinks (no category)
        bar = create_menu(restaurant=rest, name="Bar", kind="bar")
        for name, price in [
            ("House Red", "9"), ("House White", "9"),
            ("IPA Draft", "7"), ("Old Fashioned", "13"),
            ("Espresso Martini", "14"), ("Mojito", "12"),
        ]:
            create_menu_item(restaurant=rest, name=name,
                             base_price=Decimal(price), kind="alcohol",
                             contains_alcohol=True,
                             requires_age_verification=True)

        self.stdout.write(self.style.SUCCESS(
            f"Seeded demo menus for '{rest.name}'."
        ))
