from django.urls import path

from . import views

app_name = "menus"

urlpatterns = [
    # Menus
    path("<uuid:restaurant_id>/", views.MenuListCreate.as_view(), name="menu-list-create"),
    path("<uuid:restaurant_id>/menus/<uuid:menu_id>/",
         views.MenuDetail.as_view(), name="menu-detail"),
    path("<uuid:restaurant_id>/menus/<uuid:menu_id>/categories/",
         views.CategoryListCreate.as_view(), name="category-create"),
    path("<uuid:restaurant_id>/menus/<uuid:menu_id>/availability/",
         views.MenuAvailabilityCreate.as_view(), name="menu-availability"),

    # Items
    path("<uuid:restaurant_id>/items/", views.MenuItemListCreate.as_view(),
         name="item-list-create"),
    path("<uuid:restaurant_id>/items/<uuid:item_id>/",
         views.MenuItemDetail.as_view(), name="item-detail"),
    path("<uuid:restaurant_id>/items/<uuid:item_id>/variants/",
         views.MenuItemVariantCreate.as_view(), name="item-variant-create"),
    path("<uuid:restaurant_id>/items/<uuid:item_id>/availability/",
         views.ItemAvailabilityCreate.as_view(), name="item-availability"),
    path("<uuid:restaurant_id>/items/<uuid:item_id>/modifier-groups/<uuid:group_id>/",
         views.AttachModifierGroupView.as_view(), name="attach-modifier-group"),

    # Modifier groups
    path("<uuid:restaurant_id>/modifier-groups/",
         views.ModifierGroupListCreate.as_view(), name="modifier-group-list-create"),
    path("<uuid:restaurant_id>/modifier-groups/<uuid:group_id>/options/",
         views.ModifierOptionCreate.as_view(), name="modifier-option-create"),
]
