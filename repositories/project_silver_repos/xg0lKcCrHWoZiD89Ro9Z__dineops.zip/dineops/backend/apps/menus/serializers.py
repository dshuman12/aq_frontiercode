from __future__ import annotations

from rest_framework import serializers

from .models import (
    Menu, MenuAvailability, MenuCategory, MenuItem, MenuItemModifierGroup,
    MenuItemVariant, ModifierGroup, ModifierOption,
)


class MenuItemVariantSerializer(serializers.ModelSerializer):
    class Meta:
        model = MenuItemVariant
        fields = ["id", "name", "price_delta", "is_default", "sort"]


class ModifierOptionSerializer(serializers.ModelSerializer):
    class Meta:
        model = ModifierOption
        fields = ["id", "group", "name", "price_delta",
                  "is_default", "is_available", "sort"]


class ModifierGroupSerializer(serializers.ModelSerializer):
    options = ModifierOptionSerializer(many=True, read_only=True)

    class Meta:
        model = ModifierGroup
        fields = ["id", "name", "is_required", "min_select", "max_select",
                  "sort", "options"]


class MenuItemSerializer(serializers.ModelSerializer):
    variants = MenuItemVariantSerializer(many=True, read_only=True)

    class Meta:
        model = MenuItem
        fields = [
            "id", "restaurant", "category",
            "name", "slug", "kind", "description",
            "base_price", "cost_basis",
            "is_available", "is_featured", "sort",
            "image_url", "sku", "barcode",
            "contains_alcohol", "is_vegetarian", "is_vegan", "is_gluten_free",
            "spice_level", "allergen_tags", "calories",
            "requires_age_verification",
            "variants", "archived_at",
        ]
        read_only_fields = ["id", "slug", "archived_at"]


class CreateMenuItemSerializer(serializers.Serializer):
    name = serializers.CharField(max_length=160)
    base_price = serializers.DecimalField(max_digits=10, decimal_places=2)
    category_id = serializers.UUIDField(required=False, allow_null=True)
    kind = serializers.ChoiceField(choices=MenuItem.KIND_CHOICES, default="food")
    description = serializers.CharField(required=False, allow_blank=True)
    is_available = serializers.BooleanField(default=True)
    contains_alcohol = serializers.BooleanField(default=False)
    is_vegetarian = serializers.BooleanField(default=False)
    is_vegan = serializers.BooleanField(default=False)
    is_gluten_free = serializers.BooleanField(default=False)
    spice_level = serializers.IntegerField(default=0, min_value=0, max_value=5)
    allergen_tags = serializers.ListField(child=serializers.CharField(), default=list)
    sku = serializers.CharField(required=False, allow_blank=True)
    requires_age_verification = serializers.BooleanField(default=False)


class MenuCategorySerializer(serializers.ModelSerializer):
    items = MenuItemSerializer(many=True, read_only=True)

    class Meta:
        model = MenuCategory
        fields = ["id", "menu", "name", "slug", "description", "sort",
                  "items", "archived_at"]


class MenuSerializer(serializers.ModelSerializer):
    categories = MenuCategorySerializer(many=True, read_only=True)

    class Meta:
        model = Menu
        fields = [
            "id", "restaurant", "name", "slug", "kind", "description",
            "is_default", "sort",
            "service_charge_percent", "tax_percent",
            "categories", "archived_at",
        ]


class CreateMenuSerializer(serializers.Serializer):
    name = serializers.CharField(max_length=120)
    kind = serializers.ChoiceField(choices=Menu.KIND_CHOICES, default="regular")
    description = serializers.CharField(required=False, allow_blank=True)
    is_default = serializers.BooleanField(default=False)
    service_charge_percent = serializers.DecimalField(
        max_digits=5, decimal_places=2, required=False, allow_null=True,
    )
    tax_percent = serializers.DecimalField(
        max_digits=5, decimal_places=2, required=False, allow_null=True,
    )


class CreateCategorySerializer(serializers.Serializer):
    name = serializers.CharField(max_length=120)
    description = serializers.CharField(required=False, allow_blank=True)
    sort = serializers.IntegerField(default=0)


class AddVariantSerializer(serializers.Serializer):
    name = serializers.CharField(max_length=80)
    price_delta = serializers.DecimalField(max_digits=10, decimal_places=2, default=0)
    is_default = serializers.BooleanField(default=False)
    sort = serializers.IntegerField(default=0)


class CreateModifierGroupSerializer(serializers.Serializer):
    name = serializers.CharField(max_length=120)
    is_required = serializers.BooleanField(default=False)
    min_select = serializers.IntegerField(default=0, min_value=0)
    max_select = serializers.IntegerField(default=1, min_value=1)
    sort = serializers.IntegerField(default=0)


class AddModifierOptionSerializer(serializers.Serializer):
    name = serializers.CharField(max_length=120)
    price_delta = serializers.DecimalField(max_digits=10, decimal_places=2, default=0)
    is_default = serializers.BooleanField(default=False)
    sort = serializers.IntegerField(default=0)


class MenuAvailabilitySerializer(serializers.ModelSerializer):
    class Meta:
        model = MenuAvailability
        fields = ["id", "kind", "menu", "item", "weekday",
                  "start_time", "end_time"]


class AddAvailabilitySerializer(serializers.Serializer):
    weekday = serializers.IntegerField(min_value=0, max_value=6)
    start_time = serializers.TimeField()
    end_time = serializers.TimeField()
