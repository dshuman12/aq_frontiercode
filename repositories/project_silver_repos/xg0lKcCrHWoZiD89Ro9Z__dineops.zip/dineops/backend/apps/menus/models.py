from __future__ import annotations

import uuid
from decimal import Decimal

from django.db import models
from django.utils.text import slugify

from apps.common.models import SoftDeleteModel, TimeStampedModel


class Menu(TimeStampedModel, SoftDeleteModel):
    """A menu groups items shown together in the staff/server app or POS.
    Restaurants typically have a Lunch / Dinner / Brunch / Bar menu."""

    KIND_CHOICES = [
        ("regular", "Regular"),
        ("breakfast", "Breakfast"),
        ("lunch", "Lunch"),
        ("dinner", "Dinner"),
        ("brunch", "Brunch"),
        ("bar", "Bar"),
        ("happy_hour", "Happy Hour"),
        ("seasonal", "Seasonal"),
        ("event", "Event"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant = models.ForeignKey(
        "restaurants.Restaurant", on_delete=models.CASCADE, related_name="menus"
    )
    name = models.CharField(max_length=120)
    slug = models.SlugField(max_length=80)
    kind = models.CharField(max_length=20, choices=KIND_CHOICES, default="regular")
    description = models.TextField(blank=True)
    is_default = models.BooleanField(default=False)
    sort = models.PositiveIntegerField(default=0)

    # Service charge / tip override (otherwise inherits Restaurant default)
    service_charge_percent = models.DecimalField(
        max_digits=5, decimal_places=2, null=True, blank=True,
    )
    tax_percent = models.DecimalField(
        max_digits=5, decimal_places=2, null=True, blank=True,
    )

    class Meta:
        ordering = ["sort", "name"]
        constraints = [
            models.UniqueConstraint(fields=["restaurant", "slug"], name="unique_menu_slug"),
        ]

    def __str__(self) -> str:
        return self.name

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)[:80]
        super().save(*args, **kwargs)


class MenuCategory(TimeStampedModel, SoftDeleteModel):
    """Course/section within a menu — Appetizers, Mains, Desserts."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    menu = models.ForeignKey(Menu, on_delete=models.CASCADE, related_name="categories")
    name = models.CharField(max_length=120)
    slug = models.SlugField(max_length=80)
    description = models.TextField(blank=True)
    sort = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["sort", "name"]
        constraints = [
            models.UniqueConstraint(fields=["menu", "slug"], name="unique_menu_category_slug"),
        ]

    def __str__(self) -> str:
        return self.name

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)[:80]
        super().save(*args, **kwargs)


class MenuItem(TimeStampedModel, SoftDeleteModel):
    """A single thing on a menu — a dish, drink, side. Has a price and (usually)
    a recipe. May have variants and modifier groups."""

    KIND_CHOICES = [
        ("food", "Food"),
        ("beverage", "Beverage"),
        ("alcohol", "Alcohol"),
        ("dessert", "Dessert"),
        ("side", "Side"),
        ("combo", "Combo"),
        ("modifier_only", "Modifier Only"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant = models.ForeignKey(
        "restaurants.Restaurant", on_delete=models.CASCADE, related_name="menu_items"
    )
    category = models.ForeignKey(
        MenuCategory, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="items",
    )
    name = models.CharField(max_length=160)
    slug = models.SlugField(max_length=120)
    kind = models.CharField(max_length=20, choices=KIND_CHOICES, default="food")
    description = models.TextField(blank=True)

    base_price = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    cost_basis = models.DecimalField(
        max_digits=10, decimal_places=2, default=0,
        help_text="Snapshot of recipe cost at last refresh.",
    )

    is_available = models.BooleanField(default=True)
    is_featured = models.BooleanField(default=False)
    sort = models.PositiveIntegerField(default=0)

    image_url = models.CharField(max_length=500, blank=True)
    sku = models.CharField(max_length=40, blank=True, db_index=True)
    barcode = models.CharField(max_length=64, blank=True)

    # Display flags & compliance
    contains_alcohol = models.BooleanField(default=False)
    is_vegetarian = models.BooleanField(default=False)
    is_vegan = models.BooleanField(default=False)
    is_gluten_free = models.BooleanField(default=False)
    spice_level = models.PositiveSmallIntegerField(default=0)
    allergen_tags = models.JSONField(default=list, blank=True)
    calories = models.PositiveIntegerField(null=True, blank=True)

    # Compliance: bar items often hidden until age verified
    requires_age_verification = models.BooleanField(default=False)

    class Meta:
        ordering = ["sort", "name"]
        constraints = [
            models.UniqueConstraint(fields=["restaurant", "slug"], name="unique_menu_item_slug"),
        ]
        indexes = [
            models.Index(fields=["restaurant", "is_available"]),
            models.Index(fields=["restaurant", "archived_at"]),
            models.Index(fields=["category", "sort"]),
        ]

    def __str__(self) -> str:
        return self.name

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)[:120]
        super().save(*args, **kwargs)


class MenuItemVariant(TimeStampedModel):
    """Size / option variants of a single item — Small/Medium/Large pizza."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    item = models.ForeignKey(MenuItem, on_delete=models.CASCADE, related_name="variants")
    name = models.CharField(max_length=80)
    price_delta = models.DecimalField(
        max_digits=10, decimal_places=2, default=0,
        help_text="Added on top of MenuItem.base_price (negative allowed).",
    )
    is_default = models.BooleanField(default=False)
    sort = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["sort", "name"]
        constraints = [
            models.UniqueConstraint(
                fields=["item", "name"], name="unique_variant_name",
            ),
        ]

    def __str__(self) -> str:
        return f"{self.item.name} — {self.name}"


class ModifierGroup(TimeStampedModel):
    """A choice group: 'Choose protein', 'Add toppings (max 3)'. Items reference
    these groups; a single modifier group can be reused across items."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant = models.ForeignKey(
        "restaurants.Restaurant", on_delete=models.CASCADE,
        related_name="modifier_groups",
    )
    name = models.CharField(max_length=120)
    is_required = models.BooleanField(default=False)
    min_select = models.PositiveIntegerField(default=0)
    max_select = models.PositiveIntegerField(default=1)
    sort = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["sort", "name"]


class ModifierOption(TimeStampedModel):
    """An individual option inside a modifier group — 'Chicken', 'Tofu',
    'Extra cheese'."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    group = models.ForeignKey(
        ModifierGroup, on_delete=models.CASCADE, related_name="options",
    )
    name = models.CharField(max_length=120)
    price_delta = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    is_default = models.BooleanField(default=False)
    is_available = models.BooleanField(default=True)
    sort = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["sort", "name"]
        constraints = [
            models.UniqueConstraint(
                fields=["group", "name"], name="unique_modifier_option_name",
            ),
        ]


class MenuItemModifierGroup(TimeStampedModel):
    """Through table: which modifier groups apply to which menu item.
    Lets us reuse common groups (e.g. 'Cooking temperature') across multiple
    steaks without duplicating them."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    item = models.ForeignKey(
        MenuItem, on_delete=models.CASCADE, related_name="modifier_links",
    )
    group = models.ForeignKey(
        ModifierGroup, on_delete=models.CASCADE, related_name="item_links",
    )
    sort = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["sort"]
        constraints = [
            models.UniqueConstraint(
                fields=["item", "group"], name="unique_item_modifier_group",
            ),
        ]


class MenuAvailability(TimeStampedModel):
    """Time-based availability for menus or items. Lunch menu is only on
    Mon-Fri 11-2; happy hour 4-6pm. Combined with location windows."""

    KIND_CHOICES = [
        ("menu", "Menu"),
        ("item", "Item"),
    ]

    WEEKDAY_CHOICES = [
        (0, "Monday"), (1, "Tuesday"), (2, "Wednesday"), (3, "Thursday"),
        (4, "Friday"), (5, "Saturday"), (6, "Sunday"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    kind = models.CharField(max_length=10, choices=KIND_CHOICES)
    menu = models.ForeignKey(
        Menu, on_delete=models.CASCADE, null=True, blank=True,
        related_name="availability_rules",
    )
    item = models.ForeignKey(
        MenuItem, on_delete=models.CASCADE, null=True, blank=True,
        related_name="availability_rules",
    )
    weekday = models.IntegerField(choices=WEEKDAY_CHOICES)
    start_time = models.TimeField()
    end_time = models.TimeField()

    class Meta:
        ordering = ["weekday", "start_time"]
        indexes = [
            models.Index(fields=["kind", "weekday"]),
        ]
