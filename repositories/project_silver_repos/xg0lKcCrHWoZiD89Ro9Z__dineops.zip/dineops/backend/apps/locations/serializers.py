from rest_framework import serializers

from .models import BusinessHour, Holiday, KitchenStation, Location


class LocationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Location
        fields = (
            "id", "name", "slug",
            "address_line1", "address_line2", "city", "region", "country", "postal_code",
            "phone", "timezone", "seats",
            "sales_tax_percent", "service_charge_percent",
            "accepts_dine_in", "accepts_takeout", "accepts_delivery",
            "archived_at", "created_at",
        )
        read_only_fields = ("id", "slug", "archived_at", "created_at")


class LocationCreateSerializer(serializers.Serializer):
    name = serializers.CharField(min_length=2, max_length=200)
    address_line1 = serializers.CharField(max_length=200, required=False, allow_blank=True)
    address_line2 = serializers.CharField(max_length=200, required=False, allow_blank=True)
    city = serializers.CharField(max_length=120, required=False, allow_blank=True)
    region = serializers.CharField(max_length=120, required=False, allow_blank=True)
    country = serializers.CharField(max_length=120, required=False, allow_blank=True)
    postal_code = serializers.CharField(max_length=40, required=False, allow_blank=True)
    phone = serializers.CharField(max_length=40, required=False, allow_blank=True)
    timezone = serializers.CharField(max_length=64, required=False, default="UTC")
    seats = serializers.IntegerField(min_value=0, required=False, default=0)
    sales_tax_percent = serializers.DecimalField(max_digits=5, decimal_places=2, required=False, default=0)
    service_charge_percent = serializers.DecimalField(max_digits=5, decimal_places=2, required=False, default=0)
    accepts_dine_in = serializers.BooleanField(required=False, default=True)
    accepts_takeout = serializers.BooleanField(required=False, default=True)
    accepts_delivery = serializers.BooleanField(required=False, default=False)


class BusinessHourSerializer(serializers.ModelSerializer):
    class Meta:
        model = BusinessHour
        fields = ("id", "weekday", "open_time", "close_time", "closed")


class HolidaySerializer(serializers.ModelSerializer):
    class Meta:
        model = Holiday
        fields = ("id", "date", "label", "closed", "special_open_time", "special_close_time")


class StationSerializer(serializers.ModelSerializer):
    class Meta:
        model = KitchenStation
        fields = ("id", "key", "label", "sort")
