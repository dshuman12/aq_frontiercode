from __future__ import annotations

from django.db import transaction
from django.utils.text import slugify

from apps.common.exceptions import Conflict, ValidationError
from apps.restaurants.models import Restaurant

from .models import BusinessHour, Holiday, KitchenStation, Location


def _slugify_location(name: str, restaurant: Restaurant) -> str:
    base = slugify(name)[:60] or "main"
    slug = base
    suffix = 0
    while Location.objects.filter(restaurant=restaurant, slug=slug).exists():
        suffix += 1
        slug = f"{base}-{suffix}"
    return slug


@transaction.atomic
def create_location(*, restaurant: Restaurant, name: str, **fields) -> Location:
    if not name or len(name.strip()) < 2:
        raise ValidationError("invalid_name")
    return Location.objects.create(
        restaurant=restaurant,
        name=name.strip(),
        slug=_slugify_location(name, restaurant),
        **fields,
    )


@transaction.atomic
def set_business_hours(*, location: Location, hours: list[dict]) -> list[BusinessHour]:
    """Replace ALL business hours for a location."""
    BusinessHour.objects.filter(location=location).delete()
    objs = [
        BusinessHour(
            location=location,
            weekday=h["weekday"],
            open_time=h["open_time"],
            close_time=h["close_time"],
            closed=h.get("closed", False),
        )
        for h in hours
    ]
    BusinessHour.objects.bulk_create(objs)
    return list(BusinessHour.objects.filter(location=location).order_by("weekday"))


@transaction.atomic
def add_holiday(*, location: Location, **fields) -> Holiday:
    if Holiday.objects.filter(location=location, date=fields["date"]).exists():
        raise Conflict("holiday_already_exists")
    return Holiday.objects.create(location=location, **fields)


@transaction.atomic
def add_station(*, location: Location, key: str, label: str, sort: int = 0) -> KitchenStation:
    if KitchenStation.objects.filter(location=location, key=key).exists():
        raise Conflict("station_key_taken")
    return KitchenStation.objects.create(
        location=location, key=key, label=label, sort=sort,
    )


def archive_location(*, location: Location):
    location.archive()
    return location
