import pytest
from rest_framework.test import APIClient

from apps.accounts.tests.factories import UserFactory
from apps.locations.tests.factories import LocationFactory
from apps.restaurants.tests.factories import RestaurantFactory, RestaurantMemberFactory


@pytest.fixture
def authed_owner(db):
    user = UserFactory()
    restaurant = RestaurantFactory(owner=user, name="Bistro", slug="bistro")
    RestaurantMemberFactory(restaurant=restaurant, user=user, roles=["owner"])
    client = APIClient()
    client.force_authenticate(user=user)
    return client, user, restaurant


@pytest.mark.django_db
class TestLocationViews:
    def test_list_returns_active_locations_only(self, authed_owner):
        client, _, r = authed_owner
        active = LocationFactory(restaurant=r, name="A")
        archived = LocationFactory(restaurant=r, name="Old")
        archived.archive()
        resp = client.get(f"/api/locations/{r.id}/")
        names = [loc["name"] for loc in resp.data["results"]]
        assert "A" in names
        assert "Old" not in names

    def test_create_returns_201(self, authed_owner):
        client, _, r = authed_owner
        resp = client.post(f"/api/locations/{r.id}/", {
            "name": "Westside",
            "city": "Portland",
            "country": "USA",
            "seats": 80,
        }, format="json")
        assert resp.status_code == 201
        assert resp.data["location"]["seats"] == 80

    def test_create_blocked_for_chef(self, db):
        chef = UserFactory()
        r = RestaurantFactory(owner=UserFactory(), name="X", slug="x-c")
        RestaurantMemberFactory(restaurant=r, user=chef, roles=["chef"])
        client = APIClient()
        client.force_authenticate(user=chef)
        resp = client.post(f"/api/locations/{r.id}/", {"name": "Try"}, format="json")
        assert resp.status_code == 403

    def test_set_business_hours(self, authed_owner):
        client, _, r = authed_owner
        loc = LocationFactory(restaurant=r)
        resp = client.put(
            f"/api/locations/{r.id}/{loc.id}/business-hours/",
            {"hours": [
                {"weekday": 1, "open_time": "09:00", "close_time": "17:00"},
                {"weekday": 2, "open_time": "09:00", "close_time": "17:00"},
            ]},
            format="json",
        )
        assert resp.status_code == 200

    def test_holiday_create_uniqueness(self, authed_owner):
        client, _, r = authed_owner
        loc = LocationFactory(restaurant=r)
        first = client.post(
            f"/api/locations/{r.id}/{loc.id}/holidays/",
            {"date": "2024-12-25", "label": "Xmas", "closed": True},
            format="json",
        )
        assert first.status_code == 201
        dup = client.post(
            f"/api/locations/{r.id}/{loc.id}/holidays/",
            {"date": "2024-12-25", "label": "Xmas again", "closed": True},
            format="json",
        )
        assert dup.status_code == 409

    def test_station_create(self, authed_owner):
        client, _, r = authed_owner
        loc = LocationFactory(restaurant=r)
        resp = client.post(
            f"/api/locations/{r.id}/{loc.id}/stations/",
            {"key": "grill", "label": "Grill", "sort": 1},
            format="json",
        )
        assert resp.status_code == 201
