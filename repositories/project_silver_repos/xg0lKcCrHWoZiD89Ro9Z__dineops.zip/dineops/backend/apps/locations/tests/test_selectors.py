from datetime import date, time

import pytest

from apps.accounts.models import User
from apps.locations.models import BusinessHour, Holiday, Location
from apps.locations.selectors import location_is_open, open_locations
from apps.restaurants.models import Restaurant


pytestmark = pytest.mark.django_db


def _setup():
    o = User.objects.create_user(email="o@x.com", password="pwpwpwpw")
    rest = Restaurant.objects.create(name="R", slug="r", owner=o)
    loc = Location.objects.create(restaurant=rest, name="Main",
                                  slug="main", accepts_dine_in=True)
    return rest, loc


def test_open_locations_excludes_archived():
    rest, loc = _setup()
    archived = Location.objects.create(
        restaurant=rest, name="Old", slug="old",
        accepts_dine_in=True,
    )
    archived.archive()
    out = open_locations(rest.id)
    assert loc in out
    assert archived not in out


def test_location_open_within_hours():
    rest, loc = _setup()
    BusinessHour.objects.create(
        location=loc, weekday=2, open_time=time(11, 0),
        close_time=time(22, 0), closed=False,
    )
    on_date = date(2024, 1, 3)  # Wed
    assert location_is_open(loc, on_date=on_date, t=time(13, 0))
    assert not location_is_open(loc, on_date=on_date, t=time(23, 0))


def test_location_closed_on_holiday():
    rest, loc = _setup()
    BusinessHour.objects.create(
        location=loc, weekday=2, open_time=time(0, 0),
        close_time=time(23, 59), closed=False,
    )
    on_date = date(2024, 7, 4)
    Holiday.objects.create(location=loc, date=on_date, is_closed=True)
    assert not location_is_open(loc, on_date=on_date, t=time(13, 0))
