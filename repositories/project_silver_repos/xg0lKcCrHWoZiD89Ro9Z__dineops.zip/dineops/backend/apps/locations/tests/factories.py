import factory
from factory.django import DjangoModelFactory

from apps.locations.models import KitchenStation, Location
from apps.restaurants.tests.factories import RestaurantFactory


class LocationFactory(DjangoModelFactory):
    class Meta:
        model = Location

    restaurant = factory.SubFactory(RestaurantFactory)
    name = factory.Sequence(lambda n: f"Location {n}")
    slug = factory.Sequence(lambda n: f"location-{n}")
    timezone = "UTC"


class KitchenStationFactory(DjangoModelFactory):
    class Meta:
        model = KitchenStation

    location = factory.SubFactory(LocationFactory)
    key = factory.Sequence(lambda n: f"station-{n}")
    label = factory.Sequence(lambda n: f"Station {n}")
