import pytest
from datetime import date, time

from apps.common.exceptions import Conflict, ValidationError
from apps.locations.models import BusinessHour, Holiday, KitchenStation
from apps.locations.services import (
    add_holiday,
    add_station,
    archive_location,
    create_location,
    set_business_hours,
)
from apps.restaurants.tests.factories import RestaurantFactory


@pytest.mark.django_db
def test_create_location_assigns_unique_slug():
    r = RestaurantFactory()
    a = create_location(restaurant=r, name="Downtown")
    b = create_location(restaurant=r, name="Downtown")
    assert a.slug == "downtown"
    assert b.slug == "downtown-1"


@pytest.mark.django_db
def test_create_location_rejects_short_name():
    r = RestaurantFactory()
    with pytest.raises(ValidationError):
        create_location(restaurant=r, name="X")


@pytest.mark.django_db
def test_set_business_hours_replaces_existing():
    r = RestaurantFactory()
    loc = create_location(restaurant=r, name="Main")
    set_business_hours(location=loc, hours=[
        {"weekday": 1, "open_time": time(9, 0), "close_time": time(17, 0)},
        {"weekday": 2, "open_time": time(9, 0), "close_time": time(17, 0)},
    ])
    assert BusinessHour.objects.filter(location=loc).count() == 2
    set_business_hours(location=loc, hours=[
        {"weekday": 3, "open_time": time(10, 0), "close_time": time(18, 0)},
    ])
    qs = BusinessHour.objects.filter(location=loc)
    assert qs.count() == 1
    assert qs.first().weekday == 3


@pytest.mark.django_db
def test_add_holiday_unique_per_date():
    r = RestaurantFactory()
    loc = create_location(restaurant=r, name="Main")
    add_holiday(location=loc, date=date(2024, 1, 1), label="New Year")
    with pytest.raises(Conflict):
        add_holiday(location=loc, date=date(2024, 1, 1))


@pytest.mark.django_db
def test_add_station_unique_key():
    r = RestaurantFactory()
    loc = create_location(restaurant=r, name="Main")
    add_station(location=loc, key="grill", label="Grill")
    with pytest.raises(Conflict):
        add_station(location=loc, key="grill", label="Grill 2")


@pytest.mark.django_db
def test_archive_location_sets_archived_at():
    r = RestaurantFactory()
    loc = create_location(restaurant=r, name="Main")
    assert loc.archived_at is None
    archive_location(location=loc)
    loc.refresh_from_db()
    assert loc.archived_at is not None
    assert loc.is_archived
