from __future__ import annotations

from datetime import date, time

from .models import BusinessHour, Holiday, Location


def open_locations(restaurant_id) -> list[Location]:
    return list(Location.objects.filter(
        restaurant_id=restaurant_id, archived_at__isnull=True,
    ).order_by("sort", "name"))


def location_is_open(location: Location, *, on_date: date, t: time) -> bool:
    if Holiday.objects.filter(location=location, date=on_date,
                              is_closed=True).exists():
        return False
    weekday = on_date.weekday()
    hours = BusinessHour.objects.filter(
        location=location, weekday=weekday, closed=False,
    ).order_by("open_time")
    for h in hours:
        if h.open_time <= t <= h.close_time:
            return True
    return False
