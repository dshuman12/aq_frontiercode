from django.apps import AppConfig


class LocationsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.locations"

    def ready(self):
        try:
            from . import signals  # noqa: F401
        except ImportError:
            pass
