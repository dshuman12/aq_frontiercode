from __future__ import annotations

import uuid

from django.db import models

from apps.common.models import SoftDeleteModel, TimeStampedModel


class Location(TimeStampedModel, SoftDeleteModel):
    """A restaurant branch."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant = models.ForeignKey(
        "restaurants.Restaurant", on_delete=models.CASCADE, related_name="locations"
    )
    name = models.CharField(max_length=200)
    slug = models.SlugField(max_length=80)

    address_line1 = models.CharField(max_length=200, blank=True)
    address_line2 = models.CharField(max_length=200, blank=True)
    city = models.CharField(max_length=120, blank=True)
    region = models.CharField(max_length=120, blank=True)
    country = models.CharField(max_length=120, blank=True)
    postal_code = models.CharField(max_length=40, blank=True)
    phone = models.CharField(max_length=40, blank=True)

    timezone = models.CharField(max_length=64, default="UTC")
    seats = models.PositiveIntegerField(default=0)
    sales_tax_percent = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    service_charge_percent = models.DecimalField(max_digits=5, decimal_places=2, default=0)

    accepts_dine_in = models.BooleanField(default=True)
    accepts_takeout = models.BooleanField(default=True)
    accepts_delivery = models.BooleanField(default=False)

    class Meta:
        ordering = ["name"]
        constraints = [
            models.UniqueConstraint(fields=["restaurant", "slug"], name="unique_location_slug"),
        ]
        indexes = [models.Index(fields=["restaurant", "archived_at"])]

    def __str__(self) -> str:
        return f"{self.name} ({self.restaurant_id})"


class BusinessHour(models.Model):
    """A weekday open/close window for a Location."""

    WEEKDAYS = [
        (0, "Sunday"), (1, "Monday"), (2, "Tuesday"), (3, "Wednesday"),
        (4, "Thursday"), (5, "Friday"), (6, "Saturday"),
    ]

    location = models.ForeignKey(
        Location, on_delete=models.CASCADE, related_name="business_hours"
    )
    weekday = models.PositiveSmallIntegerField(choices=WEEKDAYS)
    open_time = models.TimeField()
    close_time = models.TimeField()
    closed = models.BooleanField(default=False)

    class Meta:
        ordering = ["weekday", "open_time"]
        indexes = [models.Index(fields=["location", "weekday"])]


class Holiday(models.Model):
    """A specific date the location is closed (or has special hours)."""

    location = models.ForeignKey(Location, on_delete=models.CASCADE, related_name="holidays")
    date = models.DateField()
    label = models.CharField(max_length=200, blank=True)
    closed = models.BooleanField(default=True)
    special_open_time = models.TimeField(null=True, blank=True)
    special_close_time = models.TimeField(null=True, blank=True)

    class Meta:
        ordering = ["date"]
        constraints = [
            models.UniqueConstraint(fields=["location", "date"], name="unique_holiday_date"),
        ]


class KitchenStation(models.Model):
    """A station inside a location's kitchen (grill, fry, expo, …)."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    location = models.ForeignKey(Location, on_delete=models.CASCADE, related_name="stations")
    key = models.SlugField(max_length=64)
    label = models.CharField(max_length=120)
    sort = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["sort", "label"]
        constraints = [
            models.UniqueConstraint(fields=["location", "key"], name="unique_station_key"),
        ]
