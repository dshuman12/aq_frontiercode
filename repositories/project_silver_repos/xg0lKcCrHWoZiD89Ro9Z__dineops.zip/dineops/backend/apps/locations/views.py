from __future__ import annotations

from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common.exceptions import NotFound, PermissionDenied
from apps.restaurants.models import Restaurant, RestaurantMember
from apps.restaurants.permissions import IsOwnerOrManager

from . import services
from .models import BusinessHour, Holiday, KitchenStation, Location
from .serializers import (
    BusinessHourSerializer,
    HolidaySerializer,
    LocationCreateSerializer,
    LocationSerializer,
    StationSerializer,
)


def _ensure_member(user, restaurant_id) -> RestaurantMember:
    member = RestaurantMember.objects.filter(
        restaurant_id=restaurant_id, user=user, status="active"
    ).first()
    if not member:
        raise PermissionDenied("not_a_member")
    return member


class LocationListCreate(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        _ensure_member(request.user, restaurant_id)
        items = Location.objects.filter(
            restaurant_id=restaurant_id, archived_at__isnull=True
        ).order_by("name")
        return Response({"results": LocationSerializer(items, many=True).data})

    def post(self, request, restaurant_id):
        member = _ensure_member(request.user, restaurant_id)
        if not any(r in ("owner", "general_manager") for r in member.roles):
            raise PermissionDenied()
        s = LocationCreateSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        restaurant = Restaurant.objects.get(id=restaurant_id)
        location = services.create_location(restaurant=restaurant, **s.validated_data)
        return Response({"location": LocationSerializer(location).data},
                        status=status.HTTP_201_CREATED)


class LocationDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id, location_id):
        _ensure_member(request.user, restaurant_id)
        location = Location.objects.filter(
            id=location_id, restaurant_id=restaurant_id
        ).first()
        if not location:
            raise NotFound()
        return Response({"location": LocationSerializer(location).data})

    def patch(self, request, restaurant_id, location_id):
        member = _ensure_member(request.user, restaurant_id)
        if not any(r in ("owner", "general_manager") for r in member.roles):
            raise PermissionDenied()
        location = Location.objects.filter(
            id=location_id, restaurant_id=restaurant_id
        ).first()
        if not location:
            raise NotFound()
        s = LocationSerializer(location, data=request.data, partial=True)
        s.is_valid(raise_exception=True)
        s.save()
        return Response({"location": s.data})


class BusinessHoursView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id, location_id):
        _ensure_member(request.user, restaurant_id)
        items = BusinessHour.objects.filter(
            location_id=location_id, location__restaurant_id=restaurant_id
        ).order_by("weekday", "open_time")
        return Response({"results": BusinessHourSerializer(items, many=True).data})

    def put(self, request, restaurant_id, location_id):
        member = _ensure_member(request.user, restaurant_id)
        if not any(r in ("owner", "general_manager") for r in member.roles):
            raise PermissionDenied()
        location = Location.objects.filter(
            id=location_id, restaurant_id=restaurant_id
        ).first()
        if not location:
            raise NotFound()
        items = request.data.get("hours") or []
        services.set_business_hours(location=location, hours=items)
        return Response({"ok": True})


class HolidayListCreate(APIView):
    permission_classes = (IsAuthenticated, IsOwnerOrManager)

    def get(self, request, restaurant_id, location_id):
        items = Holiday.objects.filter(
            location_id=location_id, location__restaurant_id=restaurant_id
        ).order_by("date")
        return Response({"results": HolidaySerializer(items, many=True).data})

    def post(self, request, restaurant_id, location_id):
        location = Location.objects.filter(
            id=location_id, restaurant_id=restaurant_id
        ).first()
        if not location:
            raise NotFound()
        s = HolidaySerializer(data=request.data)
        s.is_valid(raise_exception=True)
        holiday = services.add_holiday(location=location, **s.validated_data)
        return Response({"holiday": HolidaySerializer(holiday).data}, status=201)


class StationListCreate(APIView):
    permission_classes = (IsAuthenticated, IsOwnerOrManager)

    def get(self, request, restaurant_id, location_id):
        items = KitchenStation.objects.filter(
            location_id=location_id, location__restaurant_id=restaurant_id
        ).order_by("sort", "label")
        return Response({"results": StationSerializer(items, many=True).data})

    def post(self, request, restaurant_id, location_id):
        location = Location.objects.filter(
            id=location_id, restaurant_id=restaurant_id
        ).first()
        if not location:
            raise NotFound()
        s = StationSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        station = services.add_station(location=location, **s.validated_data)
        return Response({"station": StationSerializer(station).data}, status=201)
