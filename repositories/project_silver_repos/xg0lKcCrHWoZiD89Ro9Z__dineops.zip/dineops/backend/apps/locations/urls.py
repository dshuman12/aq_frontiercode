from django.urls import path

from . import views

app_name = "locations"

urlpatterns = [
    path("<uuid:restaurant_id>/", views.LocationListCreate.as_view(), name="list-create"),
    path("<uuid:restaurant_id>/<uuid:location_id>/",
         views.LocationDetail.as_view(), name="detail"),
    path("<uuid:restaurant_id>/<uuid:location_id>/business-hours/",
         views.BusinessHoursView.as_view(), name="hours"),
    path("<uuid:restaurant_id>/<uuid:location_id>/holidays/",
         views.HolidayListCreate.as_view(), name="holidays"),
    path("<uuid:restaurant_id>/<uuid:location_id>/stations/",
         views.StationListCreate.as_view(), name="stations"),
]
