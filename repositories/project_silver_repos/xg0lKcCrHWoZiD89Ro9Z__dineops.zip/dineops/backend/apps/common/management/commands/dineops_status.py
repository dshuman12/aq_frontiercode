"""Print a quick installation status — useful for deploys."""
from __future__ import annotations

from django.core.management.base import BaseCommand

from apps.common.version import __build__, __version__


class Command(BaseCommand):
    help = "Print DineOps installation status."

    def handle(self, *args, **options):
        self.stdout.write(f"DineOps v{__version__} (build {__build__})")
        from django.db import connection
        try:
            with connection.cursor() as c:
                c.execute("SELECT 1")
            self.stdout.write("  Database: ok")
        except Exception as e:
            self.stderr.write(f"  Database: ERROR {e}")
        try:
            from channels.layers import get_channel_layer
            layer = get_channel_layer()
            self.stdout.write(f"  Channels: {'ok' if layer else 'unconfigured'}")
        except Exception as e:
            self.stderr.write(f"  Channels: ERROR {e}")

        from apps.restaurants.models import Restaurant
        from apps.accounts.models import User
        self.stdout.write(f"  Restaurants: {Restaurant.objects.count()}")
        self.stdout.write(f"  Users: {User.objects.count()}")
