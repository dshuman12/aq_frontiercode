"""Seed a complete demo restaurant — owner user, members, menus, ingredients,
inventory, sample orders. Useful for screencasts and integration tests."""
from __future__ import annotations

import random
from datetime import date, datetime, timedelta, timezone as dtz
from decimal import Decimal

from django.core.management.base import BaseCommand
from django.db import transaction

from apps.accounts.models import User
from apps.ingredients.models import Ingredient
from apps.inventory.services import create_inventory_item
from apps.locations.models import Location
from apps.menus.services import (
    add_modifier_option, add_variant, attach_modifier_group,
    create_category, create_menu, create_menu_item, create_modifier_group,
)
from apps.recipes.services import add_ingredient, create_recipe
from apps.restaurants.models import Restaurant, RestaurantMember
from apps.vendors.services import add_vendor_ingredient, create_vendor


class Command(BaseCommand):
    help = "Seed a demo DineOps restaurant ('downtown-bistro')."

    def add_arguments(self, parser):
        parser.add_argument("--reset", action="store_true",
                            help="Drop existing demo restaurant first.")

    @transaction.atomic
    def handle(self, *args, reset=False, **options):
        if reset:
            Restaurant.objects.filter(slug="downtown-bistro").delete()

        # Users
        owner = self._user("owner@dineops.test")
        gm = self._user("gm@dineops.test")
        chef = self._user("chef@dineops.test")
        server = self._user("server@dineops.test")
        cashier = self._user("cashier@dineops.test")
        kitchen = self._user("kitchen@dineops.test")

        # Restaurant + members
        rest, _ = Restaurant.objects.get_or_create(
            slug="downtown-bistro",
            defaults={
                "name": "Downtown Bistro",
                "owner": owner,
                "default_tax_percent": Decimal("8.5"),
                "default_service_charge_percent": Decimal("0"),
            },
        )
        for u, role in [
            (owner, "owner"), (gm, "general_manager"),
            (chef, "chef"), (server, "server"),
            (cashier, "cashier"), (kitchen, "kitchen_staff"),
        ]:
            RestaurantMember.objects.get_or_create(
                restaurant=rest, user=u,
                defaults={"roles": [role], "status": "active"},
            )

        # Location + station + hours
        loc, _ = Location.objects.get_or_create(
            restaurant=rest, slug="main",
            defaults={
                "name": "Main", "accepts_dine_in": True,
                "accepts_takeout": True, "accepts_delivery": False,
            },
        )

        # Vendor
        vendor = create_vendor(
            restaurant=rest, name="Acme Foodservice",
            kind="broadliner", payment_terms="net_14",
        )

        # Ingredients
        ingredients_def = [
            ("Beef Chuck", "g", "0.04", "0.85"),
            ("Chicken Breast", "g", "0.025", "0.95"),
            ("Salmon Fillet", "g", "0.08", "0.90"),
            ("Tomato", "g", "0.005", "0.95"),
            ("Onion", "g", "0.003", "0.90"),
            ("Garlic", "g", "0.012", "0.95"),
            ("Olive Oil", "ml", "0.015", "1"),
            ("Butter", "g", "0.020", "1"),
            ("Flour", "g", "0.002", "1"),
            ("Mozzarella", "g", "0.018", "0.99"),
            ("Lettuce", "g", "0.006", "0.85"),
            ("Egg", "each", "0.30", "1"),
        ]
        ingredients = {}
        for name, unit, cost, yield_factor in ingredients_def:
            ing, _ = Ingredient.objects.get_or_create(
                restaurant=rest, name=name,
                defaults={
                    "base_unit": unit,
                    "cost_per_unit": Decimal(cost),
                    "yield_factor": Decimal(yield_factor),
                },
            )
            ingredients[name] = ing

            add_vendor_ingredient(
                vendor=vendor, ingredient=ing,
                pack_size="case", pack_quantity=Decimal("5000"),
                case_price=(Decimal(cost) * Decimal("5000")).quantize(
                    Decimal("0.01"),
                ),
                vendor_sku=f"ACME-{ing.name[:3].upper()}",
            )

            create_inventory_item(
                restaurant=rest, location=loc, ingredient=ing,
                par_level=Decimal("5000"),
                reorder_point=Decimal("1000"),
                reorder_quantity=Decimal("3000"),
                opening_quantity=Decimal("4000"),
                opening_cost=Decimal(cost),
            )

        # Menu
        dinner = create_menu(restaurant=rest, name="Dinner",
                             kind="dinner", is_default=True)
        starters = create_category(menu=dinner, name="Starters", sort=10)
        mains = create_category(menu=dinner, name="Mains", sort=20)
        desserts = create_category(menu=dinner, name="Desserts", sort=30)

        steak = create_menu_item(
            restaurant=rest, name="Pan-Seared Steak",
            base_price=Decimal("32.00"), category=mains,
            kind="food", is_featured=True,
        )
        add_variant(item=steak, name="8oz", is_default=True)
        add_variant(item=steak, name="12oz", price_delta=Decimal("8"))

        cook_temp = create_modifier_group(
            restaurant=rest, name="Cooking Temperature",
            is_required=True, min_select=1, max_select=1,
        )
        for t in ("Rare", "Medium Rare", "Medium", "Medium Well", "Well Done"):
            add_modifier_option(group=cook_temp, name=t)
        attach_modifier_group(item=steak, group=cook_temp)

        for name, price, cat in [
            ("Caesar Salad", "12", starters),
            ("Mussels Marinière", "16", starters),
            ("Bruschetta", "9", starters),
            ("Roast Chicken", "26", mains),
            ("Pan-Seared Salmon", "30", mains),
            ("Mushroom Risotto", "22", mains),
            ("Tiramisu", "8.50", desserts),
            ("Chocolate Lava Cake", "9.00", desserts),
        ]:
            create_menu_item(restaurant=rest, name=name,
                             base_price=Decimal(price), category=cat)

        # Recipes (just one wired up for demo)
        steak_recipe = create_recipe(
            restaurant=rest, name="Pan-Seared Steak (8oz)",
            yield_quantity=Decimal("1"), yield_unit="each",
            selling_price=Decimal("32.00"),
            menu_item=steak,
        )
        add_ingredient(recipe=steak_recipe, ingredient=ingredients["Beef Chuck"],
                       quantity=Decimal("227"), unit="g",
                       notes="trimmed, room temp")
        add_ingredient(recipe=steak_recipe, ingredient=ingredients["Olive Oil"],
                       quantity=Decimal("15"), unit="ml")
        add_ingredient(recipe=steak_recipe, ingredient=ingredients["Butter"],
                       quantity=Decimal("30"), unit="g")
        add_ingredient(recipe=steak_recipe, ingredient=ingredients["Garlic"],
                       quantity=Decimal("10"), unit="g")

        self.stdout.write(self.style.SUCCESS(
            f"Seeded demo restaurant '{rest.name}' (owner: owner@dineops.test).",
        ))

    def _user(self, email: str) -> User:
        u, created = User.objects.get_or_create(
            email=email,
            defaults={"is_active": True, "email_verified_at": datetime.now(dtz.utc)},
        )
        if created:
            u.set_password("password123!")
            u.save()
        return u
