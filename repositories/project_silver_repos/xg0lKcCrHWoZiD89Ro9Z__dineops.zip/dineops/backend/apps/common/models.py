"""Abstract base models."""
from __future__ import annotations

from django.db import models


class TimeStampedModel(models.Model):
    """Mixin: created_at / updated_at populated automatically."""

    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class SoftDeleteModel(models.Model):
    """Mixin: archived_at + helper methods. We never delete rows that have
    audit-relevant history; we set `archived_at`."""

    archived_at = models.DateTimeField(null=True, blank=True, db_index=True)

    class Meta:
        abstract = True

    def archive(self, save: bool = True):
        from django.utils import timezone

        self.archived_at = timezone.now()
        if save:
            self.save(update_fields=["archived_at"])

    @property
    def is_archived(self) -> bool:
        return self.archived_at is not None
