"""Liveness + readiness endpoints. The orchestrator (k8s, ECS, etc.) hits these
to gate traffic."""
from __future__ import annotations

from django.db import connection
from django.http import JsonResponse


def liveness(request):
    return JsonResponse({"status": "ok"})


def readiness(request):
    checks = {}
    # DB
    try:
        with connection.cursor() as c:
            c.execute("SELECT 1")
        checks["db"] = "ok"
    except Exception as e:  # noqa: BLE001
        checks["db"] = f"error: {e}"
    # Redis (channels) — skip if not configured
    try:
        from channels.layers import get_channel_layer
        layer = get_channel_layer()
        if layer:
            checks["channels"] = "ok"
    except Exception as e:  # noqa: BLE001
        checks["channels"] = f"error: {e}"

    healthy = all(v == "ok" for v in checks.values())
    return JsonResponse({"status": "ok" if healthy else "degraded",
                         "checks": checks},
                        status=200 if healthy else 503)
