"""Time/date helpers reused across apps."""
from __future__ import annotations

from datetime import date, datetime, time, timedelta, timezone


def day_window_utc(d: date) -> tuple[datetime, datetime]:
    """Return (start_utc, end_utc) for the calendar day in UTC."""
    start = datetime.combine(d, time(0, 0)).replace(tzinfo=timezone.utc)
    return start, start + timedelta(days=1)


def week_window_utc(d: date) -> tuple[datetime, datetime]:
    """Mon-Sun week containing `d`, in UTC."""
    monday = d - timedelta(days=d.weekday())
    start = datetime.combine(monday, time(0, 0)).replace(tzinfo=timezone.utc)
    return start, start + timedelta(days=7)


def parse_iso_date(value: str) -> date:
    return date.fromisoformat(value)


def hours_to_minutes(hours: float) -> int:
    return int(round(hours * 60))


def minutes_to_hours(minutes: int) -> float:
    return round(minutes / 60.0, 2)


def to_business_local(dt: datetime, tz_name: str = "UTC") -> datetime:
    """Normalize a UTC datetime into a local one for human display.
    For now, only UTC is supported in tests; production overlays with
    pytz.timezone(tz_name)."""
    return dt
