import pytest

from apps.common.permissions import has_perm


@pytest.mark.parametrize(
    "roles,perm,expected",
    [
        (["owner"], "anything.weird", True),
        (["chef"], "kitchen.update", True),
        (["chef"], "payments.create", False),
        (["server"], "payments.create", True),
        (["cashier"], "refunds.create", True),
        (["viewer"], "orders.update", False),
        (["inventory_manager"], "purchasing.create", True),
        (["accountant"], "reports.read", True),
        (["accountant"], "menus.update", False),
        (["alien"], "orders.read", False),
        ([], "anything", False),
    ],
)
def test_has_perm(roles, perm, expected):
    assert has_perm(roles, perm) is expected


def test_custom_perms_extend_base_role():
    assert has_perm(["viewer"], "orders.update") is False
    assert has_perm(["viewer"], "orders.update", custom_perms=["orders.update"]) is True


def test_wildcard_within_head():
    assert has_perm(["chef"], "recipes.create") is True
    assert has_perm(["chef"], "recipes.delete") is True


def test_multiple_roles_union():
    assert has_perm(["server", "cashier"], "refunds.create") is True
