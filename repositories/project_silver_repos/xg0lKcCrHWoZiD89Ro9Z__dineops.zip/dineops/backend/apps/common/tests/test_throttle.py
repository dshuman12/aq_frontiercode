"""Smoke tests for throttle scope wiring (the actual rate enforcement is
exercised via integration-style tests in CI)."""
from apps.common.throttle import (
    LoginRateThrottle, PasswordResetThrottle, StripeWebhookThrottle,
)


def test_login_throttle_scope():
    assert LoginRateThrottle.scope == "login"


def test_password_reset_throttle_scope():
    assert PasswordResetThrottle.scope == "password_reset"


def test_stripe_throttle_scope():
    assert StripeWebhookThrottle.scope == "stripe_webhook"
