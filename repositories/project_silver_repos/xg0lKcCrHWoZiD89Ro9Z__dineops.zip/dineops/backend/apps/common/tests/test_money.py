from decimal import Decimal

import pytest

from apps.common.money import (
    from_cents, quantize, split_evenly, to_cents,
)


class TestQuantize:
    def test_usd_2_decimals(self):
        assert quantize(Decimal("1.005")) == Decimal("1.01")

    def test_jpy_0_decimals(self):
        assert quantize(Decimal("100.7"), "JPY") == Decimal("101")

    def test_bhd_3_decimals(self):
        assert quantize(Decimal("1.2345"), "BHD") == Decimal("1.235")


class TestCents:
    def test_usd_round_trip(self):
        assert to_cents(Decimal("12.34")) == 1234
        assert from_cents(1234) == Decimal("12.34")

    def test_jpy(self):
        assert to_cents(Decimal("100"), "JPY") == 100
        assert from_cents(100, "JPY") == Decimal("100")


class TestSplitEvenly:
    def test_round(self):
        out = split_evenly(Decimal("30"), 3)
        assert out == [Decimal("10.00"), Decimal("10.00"), Decimal("10.00")]

    def test_remainder_to_first(self):
        out = split_evenly(Decimal("10"), 3)
        # 10/3 = 3.33 each, remainder 0.01 added to first
        assert out[0] == Decimal("3.34")
        assert sum(out) == Decimal("10.00")

    def test_invalid_n(self):
        with pytest.raises(ValueError):
            split_evenly(Decimal("10"), 0)
