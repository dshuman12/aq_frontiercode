from apps.common.phone import looks_like_us_phone, normalize


def test_normalize_strips():
    assert normalize("(415) 555-1234") == "4155551234"


def test_keeps_leading_plus():
    assert normalize("+1 (415) 555-1234") == "+14155551234"


def test_us_phone_validation():
    assert looks_like_us_phone("4155551234")
    assert looks_like_us_phone("+1 415-555-1234")
    assert not looks_like_us_phone("123")
