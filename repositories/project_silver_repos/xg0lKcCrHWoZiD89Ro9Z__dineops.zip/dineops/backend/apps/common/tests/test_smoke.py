"""Smoke tests for project wiring. If these fail, settings or routing is busted."""
import pytest
from django.urls import reverse
from rest_framework import status


@pytest.mark.django_db
def test_admin_is_reachable(api_client):
    """Django admin should redirect anonymous users to login."""
    resp = api_client.get("/admin/")
    assert resp.status_code in (200, 302)


@pytest.mark.django_db
def test_openapi_schema_endpoint(api_client):
    resp = api_client.get("/api/schema/")
    assert resp.status_code == status.HTTP_200_OK


@pytest.mark.django_db
def test_swagger_ui_renders(api_client):
    resp = api_client.get("/api/docs/")
    assert resp.status_code == status.HTTP_200_OK


def test_settings_module_is_test():
    from django.conf import settings

    assert "test" in settings.SETTINGS_MODULE
    assert settings.CELERY_TASK_ALWAYS_EAGER is True
