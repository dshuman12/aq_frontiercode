from apps.common.cache_keys import (
    daily_summary_key, low_stock_key, menu_for_location_key,
    recipe_cost_key, session_count_key,
)


def test_keys_are_deterministic():
    assert low_stock_key("abc") == "dineops:lowstock:abc"
    assert menu_for_location_key("xyz") == "dineops:menu:loc:xyz"
    assert daily_summary_key("a", "2024-01-01") == "dineops:daily-summary:a:2024-01-01"
    assert recipe_cost_key("r1") == "dineops:recipe-cost:r1"
    assert session_count_key("u1") == "dineops:sessions:u1"
