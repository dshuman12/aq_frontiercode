import pytest

from apps.common.exceptions import (
    Conflict,
    DomainError,
    NotFound,
    PermissionDenied,
    ValidationError,
)


def test_domain_error_default_code():
    err = DomainError()
    assert err.code == "domain_error"
    assert err.status_code == 400


def test_domain_error_custom_code_and_fields():
    err = DomainError("custom_code", "Some message", field="value")
    assert err.code == "custom_code"
    assert err.message == "Some message"
    assert err.fields == {"field": "value"}


def test_not_found_status_404():
    err = NotFound()
    assert err.status_code == 404
    assert err.code == "not_found"


def test_permission_denied_status_403():
    err = PermissionDenied()
    assert err.status_code == 403


def test_conflict_status_409():
    err = Conflict()
    assert err.status_code == 409


def test_validation_error_default_message_falls_back_to_code():
    err = ValidationError()
    assert err.message == "validation_error"
