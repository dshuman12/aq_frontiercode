import pytest

from apps.common.email_renderer import render


def test_low_stock():
    out = render(
        "low_stock", name="Sam", ingredient="Beef",
        location="Main", on_hand="2", unit="kg",
        reorder="5", dashboard_url="https://dineops.test/inventory",
    )
    assert "Beef" in out
    assert "Main" in out
    assert "5" in out


def test_unknown_template():
    with pytest.raises(KeyError):
        render("nope")


def test_safe_substitution_does_not_crash_on_missing():
    # safe_substitute leaves $x literal if missing — should not raise
    out = render("welcome", restaurant_name="X")
    assert "X" in out
