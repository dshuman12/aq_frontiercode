"""Property-style tests asserting money operations are commutative + invariant."""
from decimal import Decimal

from apps.common.money import quantize, split_evenly, to_cents


def test_split_sum_invariant():
    for total, n in [
        (Decimal("100"), 7),
        (Decimal("33.33"), 4),
        (Decimal("0.10"), 3),
        (Decimal("9999.99"), 11),
    ]:
        parts = split_evenly(total, n)
        assert sum(parts) == quantize(total)


def test_to_cents_round_trip():
    from apps.common.money import from_cents
    for amount in (Decimal("0.01"), Decimal("100"), Decimal("12345.67")):
        cents = to_cents(amount)
        assert from_cents(cents) == amount
