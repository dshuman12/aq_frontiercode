from apps.common.version import __build__, __version__


def test_version_string():
    assert __version__ == "1.0.0"


def test_build_string():
    assert __build__ == "2024-03"
