import pytest
from django.db import models

from apps.common.slugify import unique_slug_for


pytestmark = pytest.mark.django_db


def test_unique_slug_first_try():
    """If no clash, returns the basic slug."""
    from apps.menus.models import Menu
    out = unique_slug_for(Menu, "Test Menu")
    assert out == "test-menu"


def test_long_name_truncates():
    from apps.menus.models import Menu
    long_name = "A" * 200
    out = unique_slug_for(Menu, long_name)
    assert len(out) <= 80
