import pytest

from apps.common.decorators import log_call


def test_log_call_passes_through():
    @log_call("test.add")
    def add(a, b):
        return a + b
    assert add(2, 3) == 5


def test_log_call_propagates_exception():
    @log_call("test.boom")
    def boom():
        raise ValueError("boom")
    with pytest.raises(ValueError):
        boom()


def test_default_name():
    @log_call()
    def fn():
        return "ok"
    assert fn() == "ok"
