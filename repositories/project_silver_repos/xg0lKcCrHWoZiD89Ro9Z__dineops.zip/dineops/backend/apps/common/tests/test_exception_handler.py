import pytest
from rest_framework.test import APIRequestFactory

from apps.common.exception_handler import custom_exception_handler
from apps.common.exceptions import (
    Conflict,
    DomainError,
    NotFound,
    PermissionDenied,
    ValidationError,
)


class _FakeContext:
    def __init__(self):
        self.view = None


@pytest.mark.parametrize(
    "exc,expected_status,expected_code",
    [
        (DomainError("bad", "Something"), 400, "bad"),
        (NotFound(), 404, "not_found"),
        (PermissionDenied(), 403, "permission_denied"),
        (Conflict("dup_key"), 409, "dup_key"),
        (ValidationError("invalid"), 400, "invalid"),
    ],
)
def test_domain_errors_get_correct_status_codes(exc, expected_status, expected_code):
    ctx = _FakeContext()
    resp = custom_exception_handler(exc, ctx)
    assert resp.status_code == expected_status
    assert resp.data["code"] == expected_code


def test_domain_error_carries_fields():
    err = DomainError("bad", "x", field_a="hello")
    resp = custom_exception_handler(err, _FakeContext())
    assert resp.data["fields"] == {"field_a": "hello"}
