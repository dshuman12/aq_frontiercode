from datetime import date, datetime, timezone

from apps.common.timeutils import (
    day_window_utc, hours_to_minutes, minutes_to_hours, parse_iso_date,
    week_window_utc,
)


def test_day_window():
    s, e = day_window_utc(date(2024, 2, 25))
    assert s == datetime(2024, 2, 25, 0, 0, tzinfo=timezone.utc)
    assert (e - s).days == 1


def test_week_window_mon_sun():
    # 2024-02-25 is a Sunday; Mon of that week = 2024-02-19
    s, e = week_window_utc(date(2024, 2, 25))
    assert s.date() == date(2024, 2, 19)
    assert (e - s).days == 7


def test_parse_iso_date():
    assert parse_iso_date("2024-01-15") == date(2024, 1, 15)


def test_round_trip():
    assert minutes_to_hours(90) == 1.5
    assert hours_to_minutes(2.5) == 150
