from datetime import datetime, timezone

from apps.common.models import SoftDeleteModel, TimeStampedModel


def test_timestamped_fields_exist():
    fields = {f.name for f in TimeStampedModel._meta.get_fields()}
    assert "created_at" in fields
    assert "updated_at" in fields


def test_softdelete_field():
    fields = {f.name for f in SoftDeleteModel._meta.get_fields()}
    assert "archived_at" in fields
