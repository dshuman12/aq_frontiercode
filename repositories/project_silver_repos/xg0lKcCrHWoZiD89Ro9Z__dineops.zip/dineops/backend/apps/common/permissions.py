"""Reusable DRF permission classes."""
from __future__ import annotations

from rest_framework.permissions import BasePermission


class IsRestaurantMember(BasePermission):
    """Caller must be an active member of the restaurant in URL/query."""

    def has_permission(self, request, view):
        if not request.user.is_authenticated:
            return False
        restaurant_id = (
            view.kwargs.get("restaurant_id")
            or request.GET.get("restaurant")
            or getattr(request, "active_restaurant_id", None)
        )
        if not restaurant_id:
            return False
        from apps.restaurants.models import RestaurantMember

        return RestaurantMember.objects.filter(
            restaurant_id=restaurant_id,
            user=request.user,
            status="active",
        ).exists()


class HasRole(BasePermission):
    """Caller must hold one of the required roles in the active restaurant."""

    required_roles: tuple[str, ...] = ()

    def has_permission(self, request, view):
        if not request.user.is_authenticated:
            return False
        roles = getattr(request, "active_member_roles", None)
        if roles is None:
            return False
        required = getattr(view, "required_roles", self.required_roles)
        if not required:
            return False
        return any(r in required for r in roles)


def has_perm(roles: list[str], perm: str, custom_perms: list[str] | None = None) -> bool:
    """Quick policy check used by selectors when DRF permission classes don't
    fit (e.g. for filtering a queryset based on what the caller can see)."""
    from apps.common.policies import ROLE_PERMS

    union: set[str] = set(custom_perms or [])
    for r in roles or []:
        union.update(ROLE_PERMS.get(r, []))
    if "*" in union:
        return True
    if perm in union:
        return True
    head = perm.split(".", 1)[0]
    return f"{head}.*" in union
