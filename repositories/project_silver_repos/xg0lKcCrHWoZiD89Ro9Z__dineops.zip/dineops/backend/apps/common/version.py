"""DineOps version + build info. Bumped at release time."""
__version__ = "1.0.0"
__build__ = "2024-03"
__commit__ = "release"
