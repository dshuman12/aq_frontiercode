"""Standard pagination response envelope."""
from rest_framework.pagination import PageNumberPagination
from rest_framework.response import Response


class StandardPagination(PageNumberPagination):
    page_size = 50
    page_size_query_param = "page_size"
    max_page_size = 200

    def get_paginated_response(self, data):
        return Response(
            {
                "results": data,
                "total": self.page.paginator.count,
                "page": self.page.number,
                "page_count": self.page.paginator.num_pages,
                "page_size": self.page.paginator.per_page,
            }
        )
