"""Centralized cache key generators. Avoids typo-driven cache bugs."""
from __future__ import annotations


def low_stock_key(restaurant_id: str) -> str:
    return f"dineops:lowstock:{restaurant_id}"


def menu_for_location_key(location_id: str) -> str:
    return f"dineops:menu:loc:{location_id}"


def daily_summary_key(restaurant_id: str, business_date: str) -> str:
    return f"dineops:daily-summary:{restaurant_id}:{business_date}"


def recipe_cost_key(recipe_id: str) -> str:
    return f"dineops:recipe-cost:{recipe_id}"


def session_count_key(user_id: str) -> str:
    return f"dineops:sessions:{user_id}"
