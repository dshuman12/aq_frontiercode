"""Slug helpers — exposes a uniqueness-aware slugify so other apps can share."""
from __future__ import annotations

from django.utils.text import slugify as django_slugify


def unique_slug_for(model_class, name: str, *, max_len: int = 80,
                   filter_kwargs: dict | None = None) -> str:
    """Return a slug that doesn't collide on `model_class` for the given
    `filter_kwargs` scope. Appends `-2`, `-3`, ... when needed."""
    base = django_slugify(name)[:max_len] or "item"
    candidate = base
    qs = model_class.objects.all()
    if filter_kwargs:
        qs = qs.filter(**filter_kwargs)
    i = 2
    while qs.filter(slug=candidate).exists():
        suffix = f"-{i}"
        candidate = (base[: max_len - len(suffix)]) + suffix
        i += 1
    return candidate
