"""Default role → permission mapping. Custom roles per restaurant are stored
in the `Role` table; their permission strings union with these.

Permission strings are dotted: `noun.verb` (e.g. `inventory.update`).
A trailing `*` is a wildcard within a head: `inventory.*` grants
`inventory.create` AND `inventory.read`.
"""
from __future__ import annotations

ROLE_PERMS: dict[str, list[str]] = {
    "owner": ["*"],
    "general_manager": [
        "restaurant.*", "locations.*", "members.manage",
        "staff.*", "shifts.*",
        "menus.*", "recipes.*", "ingredients.*", "inventory.*",
        "vendors.*", "purchasing.*", "prep.*",
        "orders.*", "kitchen.*",
        "payments.*", "closeouts.*", "refunds.*",
        "waste.*", "tasks.*",
        "reports.read", "audit.read",
    ],
    "assistant_manager": [
        "staff.read", "shifts.*", "menus.read",
        "inventory.*", "vendors.read", "purchasing.*",
        "prep.*", "orders.*", "kitchen.*",
        "payments.*", "closeouts.*",
        "waste.*", "tasks.*",
        "reports.read",
    ],
    "chef": [
        "menus.read", "recipes.*",
        "ingredients.read", "inventory.read", "inventory.consume",
        "prep.*", "orders.read", "kitchen.*",
        "waste.create", "waste.read",
    ],
    "kitchen_staff": [
        "menus.read", "recipes.read",
        "inventory.read", "inventory.consume",
        "prep.read", "prep.update",
        "orders.read", "kitchen.update",
        "waste.create",
    ],
    "server": [
        "menus.read",
        "orders.create", "orders.read", "orders.update",
        "payments.create", "payments.read",
    ],
    "cashier": [
        "menus.read",
        "orders.read", "orders.update",
        "payments.*", "closeouts.create", "closeouts.read",
        "refunds.create",
    ],
    "inventory_manager": [
        "ingredients.*", "inventory.*",
        "vendors.*", "purchasing.*",
        "reports.read",
    ],
    "accountant": [
        "payments.read", "closeouts.read", "refunds.read",
        "reports.read", "audit.read",
    ],
    "viewer": ["menus.read", "orders.read", "reports.read"],
}
