"""Streaming CSV export helper for large reports."""
from __future__ import annotations

import csv
from typing import Iterable, Sequence

from django.http import StreamingHttpResponse


class _Echo:
    def write(self, value):
        return value


def stream_csv(filename: str, headers: Sequence[str],
               rows: Iterable[Sequence]) -> StreamingHttpResponse:
    """Stream a CSV row-by-row — useful when the report would be too big to
    buffer in memory."""
    pseudo_buffer = _Echo()
    writer = csv.writer(pseudo_buffer)

    def chunks():
        yield writer.writerow(headers)
        for row in rows:
            yield writer.writerow(row)

    response = StreamingHttpResponse(chunks(), content_type="text/csv")
    response["Content-Disposition"] = f'attachment; filename="{filename}"'
    return response
