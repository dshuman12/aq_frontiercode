"""Shared HTTP middleware: request IDs, slow-request logging."""
from __future__ import annotations

import logging
import time
import uuid


_log = logging.getLogger("dineops.requests")


class RequestIdMiddleware:
    """Stamps each request with a request_id (echoed in `X-Request-Id`)."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        rid = request.headers.get("X-Request-Id") or uuid.uuid4().hex[:16]
        request.request_id = rid
        response = self.get_response(request)
        response["X-Request-Id"] = rid
        return response


class SlowRequestLogMiddleware:
    """Log requests that take longer than `slow_threshold_ms`."""
    SLOW_MS = 1500

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        t0 = time.monotonic()
        response = self.get_response(request)
        elapsed = (time.monotonic() - t0) * 1000
        if elapsed > self.SLOW_MS:
            _log.warning(
                "slow request",
                extra={
                    "method": request.method,
                    "path": request.path,
                    "status": response.status_code,
                    "elapsed_ms": int(elapsed),
                    "request_id": getattr(request, "request_id", ""),
                },
            )
        return response
