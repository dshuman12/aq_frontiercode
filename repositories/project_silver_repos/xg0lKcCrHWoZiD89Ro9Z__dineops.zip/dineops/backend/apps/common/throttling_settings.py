"""Throttle rates for the custom DRF throttle scopes."""
from __future__ import annotations


REST_FRAMEWORK_THROTTLE_RATES = {
    "login": "10/minute",
    "password_reset": "5/hour",
    "stripe_webhook": "120/minute",
    "anon": "60/minute",
    "user": "1000/hour",
}
