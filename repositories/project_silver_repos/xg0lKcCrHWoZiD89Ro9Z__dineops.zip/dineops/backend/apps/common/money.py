"""Money / currency helpers. We intentionally keep this small — Decimal is
the canonical type, and we never use floats for money."""
from __future__ import annotations

from decimal import Decimal, ROUND_HALF_UP


CURRENCY_PRECISION = {
    "USD": 2, "CAD": 2, "EUR": 2, "GBP": 2, "AUD": 2, "MXN": 2,
    "JPY": 0,
    "BHD": 3, "KWD": 3,
}


def quantize(amount: Decimal, currency: str = "USD") -> Decimal:
    """Round amount to the currency's smallest unit (cents, etc.)."""
    places = CURRENCY_PRECISION.get(currency, 2)
    quant = Decimal(10) ** -places if places > 0 else Decimal("1")
    return amount.quantize(quant, rounding=ROUND_HALF_UP)


def to_cents(amount: Decimal, currency: str = "USD") -> int:
    factor = Decimal(10) ** CURRENCY_PRECISION.get(currency, 2)
    return int((amount * factor).quantize(Decimal("1")))


def from_cents(cents: int, currency: str = "USD") -> Decimal:
    factor = Decimal(10) ** CURRENCY_PRECISION.get(currency, 2)
    return (Decimal(cents) / factor).quantize(_quant(currency))


def _quant(currency):
    places = CURRENCY_PRECISION.get(currency, 2)
    if places == 0:
        return Decimal("1")
    return Decimal(10) ** -places


def split_evenly(total: Decimal, n: int, currency: str = "USD") -> list[Decimal]:
    """Split `total` into `n` parts as evenly as possible. Any rounding
    remainder is added to the first slice."""
    if n <= 0:
        raise ValueError("n must be positive")
    base = quantize(total / n, currency)
    out = [base] * n
    remainder = quantize(total - sum(out), currency)
    if remainder != 0:
        out[0] = quantize(out[0] + remainder, currency)
    return out
