"""Reusable decorators for service-layer functions."""
from __future__ import annotations

import functools
import logging


_log = logging.getLogger("dineops.decorators")


def log_call(name: str | None = None):
    """Decorator that logs entry+exit of a service function with timing."""
    def wrap(fn):
        op_name = name or f"{fn.__module__}.{fn.__name__}"

        @functools.wraps(fn)
        def inner(*args, **kwargs):
            import time
            t0 = time.monotonic()
            try:
                result = fn(*args, **kwargs)
                _log.debug("%s ok in %.0fms", op_name,
                           (time.monotonic() - t0) * 1000)
                return result
            except Exception as e:
                _log.warning("%s raised %s in %.0fms", op_name, type(e).__name__,
                             (time.monotonic() - t0) * 1000)
                raise
        return inner
    return wrap
