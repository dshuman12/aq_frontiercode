"""Project-wide DRF exception handler.

Catches our `DomainError`s and turns them into 4xx responses with a
consistent envelope. Falls back to DRF's default for everything else.
"""
from __future__ import annotations

from rest_framework import status as drf_status
from rest_framework.response import Response
from rest_framework.views import exception_handler as drf_exception_handler

from .exceptions import DomainError


def custom_exception_handler(exc, context):
    if isinstance(exc, DomainError):
        return Response(
            {
                "detail": exc.message,
                "code": exc.code,
                "fields": exc.fields or None,
            },
            status=exc.status_code,
        )
    response = drf_exception_handler(exc, context)
    if response is not None and isinstance(response.data, dict):
        # Normalize {"detail": ...} responses to include a `code` field
        if "code" not in response.data:
            response.data["code"] = _code_for_status(response.status_code)
    return response


def _code_for_status(code: int) -> str:
    return {
        drf_status.HTTP_400_BAD_REQUEST: "bad_request",
        drf_status.HTTP_401_UNAUTHORIZED: "not_authenticated",
        drf_status.HTTP_403_FORBIDDEN: "permission_denied",
        drf_status.HTTP_404_NOT_FOUND: "not_found",
        drf_status.HTTP_405_METHOD_NOT_ALLOWED: "method_not_allowed",
        drf_status.HTTP_409_CONFLICT: "conflict",
        drf_status.HTTP_429_TOO_MANY_REQUESTS: "rate_limited",
    }.get(code, "error")
