"""Domain exceptions raised by services and converted to 4xx by DRF.

We don't subclass DRF's APIException directly — services should be
framework-agnostic. The exception handler below maps DomainError → 4xx.
"""
from __future__ import annotations

from typing import Any


class DomainError(Exception):
    """A business-rule violation. Raised by services."""

    status_code: int = 400
    default_code: str = "domain_error"

    def __init__(self, code: str | None = None, message: str | None = None, **fields: Any):
        self.code = code or self.default_code
        self.message = message or self.code
        self.fields = fields
        super().__init__(self.message)


class NotFound(DomainError):
    status_code = 404
    default_code = "not_found"


class PermissionDenied(DomainError):
    status_code = 403
    default_code = "permission_denied"


class Conflict(DomainError):
    status_code = 409
    default_code = "conflict"


class ValidationError(DomainError):
    status_code = 400
    default_code = "validation_error"
