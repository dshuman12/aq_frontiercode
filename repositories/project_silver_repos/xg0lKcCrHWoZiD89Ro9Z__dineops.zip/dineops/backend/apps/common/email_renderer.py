"""Lightweight email template renderer. We avoid pulling in a heavy template
engine here — most outbound emails are simple notification snippets."""
from __future__ import annotations

from string import Template


_TEMPLATES = {
    "low_stock": Template(
        "Hi $name,\n\n"
        "$ingredient at $location has dropped to $on_hand $unit "
        "(reorder point: $reorder).\n"
        "View dashboard: $dashboard_url\n\n"
        "— DineOps"
    ),
    "shift_reminder": Template(
        "Hi $name,\n\n"
        "Reminder: your shift starts at $start_time at $location.\n"
        "If you can't make it, please notify your manager.\n\n"
        "— DineOps"
    ),
    "welcome": Template(
        "Welcome to $restaurant_name on DineOps!\n\n"
        "Your account is ready. Sign in: $login_url\n\n"
        "— The DineOps team"
    ),
    "password_reset": Template(
        "We received a request to reset your password.\n\n"
        "Click here to reset: $reset_url\n"
        "This link expires in 30 minutes.\n\n"
        "If you didn't request this, you can safely ignore this email."
    ),
    "po_received": Template(
        "Purchase order $po_number from $vendor has been fully received.\n"
        "Total: $$total\n"
        "Items: $line_count\n\n"
        "View: $dashboard_url"
    ),
}


def render(template_name: str, **kwargs) -> str:
    template = _TEMPLATES.get(template_name)
    if not template:
        raise KeyError(f"unknown template '{template_name}'")
    return template.safe_substitute(**kwargs)
