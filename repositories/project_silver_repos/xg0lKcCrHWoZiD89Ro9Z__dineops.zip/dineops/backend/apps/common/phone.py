"""Tiny phone-number helpers. We keep this lightweight — phonenumbers is a
heavy dep we don't need until we add SMS routing."""
from __future__ import annotations

import re


_DIGITS = re.compile(r"\D+")


def normalize(phone: str) -> str:
    """Strip non-digits but keep a leading + for international numbers."""
    if not phone:
        return ""
    has_plus = phone.startswith("+")
    digits = _DIGITS.sub("", phone)
    return ("+" + digits) if has_plus else digits


def looks_like_us_phone(phone: str) -> bool:
    norm = normalize(phone)
    if norm.startswith("+1"):
        return len(norm) == 12
    return len(norm) == 10
