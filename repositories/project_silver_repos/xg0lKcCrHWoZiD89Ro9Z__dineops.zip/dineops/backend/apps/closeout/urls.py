from django.urls import path

from . import views

app_name = "closeout"

urlpatterns = [
    path("<uuid:restaurant_id>/",
         views.CloseoutListCreate.as_view(), name="list-create"),
    path("<uuid:restaurant_id>/<uuid:closeout_id>/",
         views.CloseoutDetail.as_view(), name="detail"),
    path("<uuid:restaurant_id>/<uuid:closeout_id>/recompute/",
         views.RecomputeView.as_view(), name="recompute"),
    path("<uuid:restaurant_id>/<uuid:closeout_id>/cash/",
         views.SetCashView.as_view(), name="cash"),
    path("<uuid:restaurant_id>/<uuid:closeout_id>/submit/",
         views.SubmitView.as_view(), name="submit"),
    path("<uuid:restaurant_id>/<uuid:closeout_id>/approve/",
         views.ApproveView.as_view(), name="approve"),
]
