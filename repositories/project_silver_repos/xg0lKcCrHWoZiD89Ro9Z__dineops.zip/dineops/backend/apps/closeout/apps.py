from django.apps import AppConfig


class CloseoutConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.closeout"

    def ready(self):
        try:
            from . import signals  # noqa: F401
        except ImportError:
            pass
