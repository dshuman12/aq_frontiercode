from datetime import date
from decimal import Decimal

import pytest
from rest_framework.test import APIClient

from apps.accounts.models import User
from apps.closeout.models import DailyCloseout
from apps.locations.models import Location
from apps.restaurants.models import Restaurant, RestaurantMember


pytestmark = pytest.mark.django_db


@pytest.fixture
def setup():
    owner = User.objects.create_user(email="o@x.com", password="pwpwpwpw")
    rest = Restaurant.objects.create(name="R", slug="r", owner=owner)
    loc = Location.objects.create(
        restaurant=rest, name="Main", slug="main", accepts_dine_in=True,
    )
    RestaurantMember.objects.create(
        restaurant=rest, user=owner, roles=["owner"], status="active",
    )
    return {"rest": rest, "loc": loc, "owner": owner}


def _login(u):
    c = APIClient()
    c.force_authenticate(user=u)
    return c


def test_open_closeout_endpoint(setup):
    c = _login(setup["owner"])
    resp = c.post(
        f"/api/closeouts/{setup['rest'].id}/",
        {"location_id": str(setup["loc"].id),
         "business_date": "2024-03-09"},
        format="json",
    )
    assert resp.status_code == 201
    assert resp.data["closeout"]["status"] == "draft"


def test_set_cash_endpoint(setup):
    c = _login(setup["owner"])
    co = DailyCloseout.objects.create(
        restaurant=setup["rest"], location=setup["loc"],
        business_date=date(2024, 3, 9), status="draft",
        expected_cash_drawer=Decimal("100"),
    )
    resp = c.post(
        f"/api/closeouts/{setup['rest'].id}/{co.id}/cash/",
        {"counted_cash": "98.50"},
        format="json",
    )
    assert resp.status_code == 200
    co.refresh_from_db()
    assert co.cash_variance == Decimal("-1.50")
