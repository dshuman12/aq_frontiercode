from __future__ import annotations

from datetime import date, datetime, timedelta, timezone as dtz
from decimal import Decimal

import pytest

from apps.accounts.models import User
from apps.closeout.models import DailyCloseout
from apps.closeout.services import (
    approve_closeout, open_closeout, recompute_closeout, set_counted_cash,
    submit_closeout,
)
from apps.common.exceptions import Conflict, ValidationError
from apps.locations.models import Location
from apps.menus.services import create_menu_item
from apps.orders.services import (
    add_item, create_order, fire_to_kitchen, mark_order_served, submit_order,
    void_order,
)
from apps.payments.services import record_card_payment, record_cash_payment
from apps.restaurants.models import Restaurant


pytestmark = pytest.mark.django_db


def _setup():
    owner = User.objects.create_user(email="o@x.com", password="pwpwpwpw")
    rest = Restaurant.objects.create(
        name="R", slug="r", owner=owner,
        default_tax_percent=Decimal("0"),
        default_service_charge_percent=Decimal("0"),
    )
    loc = Location.objects.create(
        restaurant=rest, name="Main", slug="main", accepts_dine_in=True,
    )
    return rest, loc, owner


def _full_order(rest, loc, owner, price):
    item = create_menu_item(restaurant=rest, name=f"X-{price}",
                            base_price=Decimal(str(price)))
    o = create_order(restaurant=rest, location=loc,
                     table_number="1", server=owner)
    add_item(order=o, menu_item=item, quantity=1)
    submit_order(order=o)
    fire_to_kitchen(order=o)
    mark_order_served(order=o)
    o.refresh_from_db()
    return o


class TestOpenCloseout:
    def test_creates(self):
        rest, loc, owner = _setup()
        co = open_closeout(restaurant=rest, location=loc,
                           business_date=date(2023, 11, 15))
        assert co.status == "draft"

    def test_idempotent_when_draft(self):
        rest, loc, owner = _setup()
        a = open_closeout(restaurant=rest, location=loc,
                          business_date=date(2023, 11, 15))
        b = open_closeout(restaurant=rest, location=loc,
                          business_date=date(2023, 11, 15))
        assert a.id == b.id

    def test_submitted_blocks_reopen(self):
        rest, loc, owner = _setup()
        co = open_closeout(restaurant=rest, location=loc,
                           business_date=date(2023, 11, 15))
        recompute_closeout(closeout=co)
        set_counted_cash(closeout=co, counted=Decimal("0"))
        submit_closeout(closeout=co, actor=owner)
        with pytest.raises(Conflict):
            open_closeout(restaurant=rest, location=loc,
                          business_date=date(2023, 11, 15))


class TestRecompute:
    def test_aggregates_sales_and_tenders(self):
        rest, loc, owner = _setup()
        o1 = _full_order(rest, loc, owner, "20")
        o2 = _full_order(rest, loc, owner, "15")
        record_cash_payment(order=o1, amount=Decimal("20"), tip=Decimal("3"))
        record_card_payment(order=o2, amount=Decimal("15"), tip=Decimal("2"),
                            card_brand="visa", card_last4="4242")
        today = o1.created_at.date()
        co = open_closeout(restaurant=rest, location=loc, business_date=today)
        recompute_closeout(closeout=co)
        assert co.order_count == 2
        assert co.gross_sales == Decimal("35.00")
        assert co.net_sales == Decimal("35.00")
        assert co.cash_total == Decimal("20.00")
        assert co.card_total == Decimal("15.00")
        assert co.tip_total == Decimal("5.00")
        assert co.expected_cash_drawer == Decimal("20.00")

    def test_voids_excluded_from_gross(self):
        rest, loc, owner = _setup()
        o1 = _full_order(rest, loc, owner, "20")
        o2 = _full_order(rest, loc, owner, "15")
        void_order(order=o2, actor=owner, reason="walked")
        today = o1.created_at.date()
        co = open_closeout(restaurant=rest, location=loc, business_date=today)
        recompute_closeout(closeout=co)
        assert co.voided_order_count == 1
        assert co.gross_sales == Decimal("20.00")


class TestCashAndSubmit:
    def test_cash_variance(self):
        rest, loc, owner = _setup()
        o = _full_order(rest, loc, owner, "20")
        record_cash_payment(order=o, amount=Decimal("20"))
        today = o.created_at.date()
        co = open_closeout(restaurant=rest, location=loc, business_date=today)
        recompute_closeout(closeout=co)
        # Counted $19 — variance -$1
        set_counted_cash(closeout=co, counted=Decimal("19"))
        co.refresh_from_db()
        assert co.cash_variance == Decimal("-1.00")

    def test_submit_blocks_without_count(self):
        rest, loc, owner = _setup()
        co = open_closeout(restaurant=rest, location=loc,
                           business_date=date(2023, 11, 16))
        recompute_closeout(closeout=co)
        with pytest.raises(ValidationError):
            submit_closeout(closeout=co, actor=owner)

    def test_full_flow(self):
        rest, loc, owner = _setup()
        co = open_closeout(restaurant=rest, location=loc,
                           business_date=date(2023, 11, 17))
        recompute_closeout(closeout=co)
        set_counted_cash(closeout=co, counted=Decimal("0"))
        submit_closeout(closeout=co, actor=owner)
        co.refresh_from_db()
        assert co.status == "submitted"
        approve_closeout(closeout=co, actor=owner)
        co.refresh_from_db()
        assert co.status == "approved"
