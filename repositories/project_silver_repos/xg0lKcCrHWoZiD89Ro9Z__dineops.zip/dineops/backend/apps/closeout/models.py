from __future__ import annotations

import uuid
from decimal import Decimal

from django.conf import settings
from django.db import models

from apps.common.models import TimeStampedModel


class DailyCloseout(TimeStampedModel):
    """The daily Z-out / closing summary for a location.

    Snapshots gross sales, by-tender breakdown, voids, comps, taxes, and
    cash variance against the cashier's drop. Once `submitted=True` the row
    is immutable (audit-grade)."""

    STATUS_CHOICES = [
        ("draft", "Draft"),
        ("submitted", "Submitted"),
        ("approved", "Approved"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant = models.ForeignKey(
        "restaurants.Restaurant", on_delete=models.CASCADE,
        related_name="closeouts",
    )
    location = models.ForeignKey(
        "locations.Location", on_delete=models.CASCADE,
        related_name="closeouts",
    )
    business_date = models.DateField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="draft")

    # Sales aggregates
    order_count = models.PositiveIntegerField(default=0)
    voided_order_count = models.PositiveIntegerField(default=0)
    gross_sales = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    discount_total = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    void_total = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    comp_total = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    net_sales = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    tax_total = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    service_charge_total = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    tip_total = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    refund_total = models.DecimalField(max_digits=14, decimal_places=2, default=0)

    # By tender
    cash_total = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    card_total = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    stripe_total = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    other_tender_total = models.DecimalField(max_digits=14, decimal_places=2, default=0)

    # Cash drawer reconciliation
    expected_cash_drawer = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    counted_cash_drawer = models.DecimalField(
        max_digits=14, decimal_places=2, null=True, blank=True,
    )
    cash_variance = models.DecimalField(max_digits=14, decimal_places=2, default=0)

    submitted_at = models.DateTimeField(null=True, blank=True)
    submitted_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="+",
    )
    approved_at = models.DateTimeField(null=True, blank=True)
    approved_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="approved_closeouts",
    )
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ["-business_date"]
        constraints = [
            models.UniqueConstraint(
                fields=["location", "business_date"],
                name="unique_closeout_per_day",
            ),
        ]
        indexes = [
            models.Index(fields=["restaurant", "business_date"]),
        ]

    def __str__(self) -> str:
        return f"{self.location.name} — {self.business_date} ({self.status})"
