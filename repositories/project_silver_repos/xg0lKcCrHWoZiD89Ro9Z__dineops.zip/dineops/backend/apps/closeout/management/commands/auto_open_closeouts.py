"""Each location should have a draft closeout ready every morning. This
command opens them ahead of time so cashiers don't have to."""
from __future__ import annotations

from datetime import timedelta

from django.core.management.base import BaseCommand
from django.utils import timezone

from apps.closeout.models import DailyCloseout
from apps.closeout.services import open_closeout
from apps.locations.models import Location


class Command(BaseCommand):
    help = "Open draft closeouts for all active locations for yesterday."

    def add_arguments(self, parser):
        parser.add_argument("--for-date", type=str,
                            help="ISO date; default = yesterday.")

    def handle(self, *args, for_date=None, **options):
        from datetime import date as date_type
        if for_date:
            target = date_type.fromisoformat(for_date)
        else:
            target = (timezone.now() - timedelta(days=1)).date()
        opened = 0
        for loc in Location.objects.filter(archived_at__isnull=True):
            existing = DailyCloseout.objects.filter(
                location=loc, business_date=target,
            ).exists()
            if existing:
                continue
            open_closeout(restaurant=loc.restaurant, location=loc,
                          business_date=target)
            opened += 1
        self.stdout.write(self.style.SUCCESS(
            f"Opened {opened} draft closeouts for {target}.",
        ))
