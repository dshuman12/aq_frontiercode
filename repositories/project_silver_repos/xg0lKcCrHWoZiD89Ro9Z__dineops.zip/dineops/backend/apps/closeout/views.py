from __future__ import annotations

from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common.exceptions import NotFound, PermissionDenied
from apps.locations.models import Location
from apps.restaurants.models import Restaurant, RestaurantMember

from . import services
from .models import DailyCloseout
from .serializers import (
    CloseoutSerializer, OpenCloseoutSerializer, SetCountedCashSerializer,
)


def _require_member(user, restaurant_id):
    m = RestaurantMember.objects.filter(
        restaurant_id=restaurant_id, user=user, status="active",
    ).first()
    if not m:
        raise PermissionDenied("not_a_member")
    return m


def _can_submit_closeout(roles):
    return any(r in (
        "owner", "general_manager", "assistant_manager",
        "cashier", "accountant",
    ) for r in roles or [])


def _can_approve(roles):
    return any(r in ("owner", "general_manager") for r in roles or [])


class CloseoutListCreate(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        _require_member(request.user, restaurant_id)
        qs = DailyCloseout.objects.filter(
            restaurant_id=restaurant_id,
        ).order_by("-business_date")[:100]
        return Response({"results": CloseoutSerializer(qs, many=True).data})

    def post(self, request, restaurant_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_submit_closeout(member.roles):
            raise PermissionDenied()
        s = OpenCloseoutSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        rest = Restaurant.objects.get(id=restaurant_id)
        loc = Location.objects.filter(
            id=s.validated_data["location_id"], restaurant_id=restaurant_id,
        ).first()
        if not loc:
            raise NotFound()
        co = services.open_closeout(
            restaurant=rest, location=loc,
            business_date=s.validated_data["business_date"],
            actor=request.user,
        )
        services.recompute_closeout(closeout=co)
        return Response({"closeout": CloseoutSerializer(co).data}, status=201)


class CloseoutDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id, closeout_id):
        _require_member(request.user, restaurant_id)
        co = DailyCloseout.objects.filter(
            id=closeout_id, restaurant_id=restaurant_id,
        ).first()
        if not co:
            raise NotFound()
        return Response({"closeout": CloseoutSerializer(co).data})


class RecomputeView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, closeout_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_submit_closeout(member.roles):
            raise PermissionDenied()
        co = DailyCloseout.objects.filter(
            id=closeout_id, restaurant_id=restaurant_id,
        ).first()
        if not co:
            raise NotFound()
        services.recompute_closeout(closeout=co)
        return Response({"closeout": CloseoutSerializer(co).data})


class SetCashView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, closeout_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_submit_closeout(member.roles):
            raise PermissionDenied()
        co = DailyCloseout.objects.filter(
            id=closeout_id, restaurant_id=restaurant_id,
        ).first()
        if not co:
            raise NotFound()
        s = SetCountedCashSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        services.set_counted_cash(closeout=co,
                                  counted=s.validated_data["counted_cash"])
        return Response({"closeout": CloseoutSerializer(co).data})


class SubmitView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, closeout_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_submit_closeout(member.roles):
            raise PermissionDenied()
        co = DailyCloseout.objects.filter(
            id=closeout_id, restaurant_id=restaurant_id,
        ).first()
        if not co:
            raise NotFound()
        services.submit_closeout(closeout=co, actor=request.user)
        return Response({"closeout": CloseoutSerializer(co).data})


class ApproveView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, closeout_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_approve(member.roles):
            raise PermissionDenied()
        co = DailyCloseout.objects.filter(
            id=closeout_id, restaurant_id=restaurant_id,
        ).first()
        if not co:
            raise NotFound()
        services.approve_closeout(closeout=co, actor=request.user)
        return Response({"closeout": CloseoutSerializer(co).data})
