from django.contrib import admin

from .models import DailyCloseout


@admin.register(DailyCloseout)
class DailyCloseoutAdmin(admin.ModelAdmin):
    list_display = ("business_date", "location", "status",
                    "gross_sales", "net_sales", "tip_total",
                    "cash_variance")
    list_filter = ("status", "location", "business_date")
    readonly_fields = ("submitted_at", "submitted_by",
                       "approved_at", "approved_by",
                       "expected_cash_drawer", "cash_variance",
                       "gross_sales", "discount_total", "void_total",
                       "comp_total", "net_sales", "tax_total",
                       "service_charge_total", "tip_total",
                       "refund_total", "cash_total", "card_total",
                       "stripe_total", "other_tender_total")
