from __future__ import annotations

from rest_framework import serializers

from .models import DailyCloseout


class CloseoutSerializer(serializers.ModelSerializer):
    location_name = serializers.CharField(source="location.name", read_only=True)

    class Meta:
        model = DailyCloseout
        fields = "__all__"
        read_only_fields = [
            "id", "order_count", "voided_order_count",
            "gross_sales", "discount_total", "void_total", "comp_total",
            "net_sales", "tax_total", "service_charge_total", "tip_total",
            "refund_total",
            "cash_total", "card_total", "stripe_total", "other_tender_total",
            "expected_cash_drawer", "cash_variance",
            "submitted_at", "submitted_by", "approved_at", "approved_by",
        ]


class OpenCloseoutSerializer(serializers.Serializer):
    location_id = serializers.UUIDField()
    business_date = serializers.DateField()


class SetCountedCashSerializer(serializers.Serializer):
    counted_cash = serializers.DecimalField(max_digits=14, decimal_places=2)
