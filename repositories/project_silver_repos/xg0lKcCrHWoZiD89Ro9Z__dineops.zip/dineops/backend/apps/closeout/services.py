from __future__ import annotations

from datetime import datetime, time, timedelta, timezone as dtz
from decimal import Decimal

from django.db import transaction
from django.db.models import Sum
from django.utils import timezone

from apps.common.exceptions import Conflict, ValidationError
from apps.locations.models import Location
from apps.orders.models import Order, OrderItem
from apps.payments.models import Payment, Refund

from .models import DailyCloseout


@transaction.atomic
def open_closeout(*, restaurant, location: Location, business_date,
                  actor=None) -> DailyCloseout:
    if location.restaurant_id != restaurant.id:
        raise ValidationError("location_not_in_restaurant")
    existing = DailyCloseout.objects.filter(
        location=location, business_date=business_date,
    ).first()
    if existing:
        if existing.status != "draft":
            raise Conflict("closeout_already_submitted")
        return existing
    return DailyCloseout.objects.create(
        restaurant=restaurant, location=location, business_date=business_date,
    )


def _day_window(business_date) -> tuple[datetime, datetime]:
    start = datetime.combine(business_date, time(0, 0)).replace(tzinfo=dtz.utc)
    end = start + timedelta(days=1)
    return start, end


@transaction.atomic
def recompute_closeout(*, closeout: DailyCloseout) -> DailyCloseout:
    if closeout.status != "draft":
        raise ValidationError("closeout_not_draft")
    start, end = _day_window(closeout.business_date)
    location = closeout.location

    orders = Order.objects.filter(
        location=location,
        created_at__gte=start, created_at__lt=end,
    )
    closeout.order_count = orders.count()
    closeout.voided_order_count = orders.filter(status="voided").count()

    valid_orders = orders.exclude(status="voided")
    closeout.gross_sales = valid_orders.aggregate(
        s=Sum("subtotal")
    )["s"] or Decimal("0")
    closeout.discount_total = valid_orders.aggregate(
        s=Sum("discount_amount")
    )["s"] or Decimal("0")
    closeout.tax_total = valid_orders.aggregate(
        s=Sum("tax_amount")
    )["s"] or Decimal("0")
    closeout.service_charge_total = valid_orders.aggregate(
        s=Sum("service_charge_amount")
    )["s"] or Decimal("0")

    # Voids + comps from item-level
    voided_items = OrderItem.objects.filter(
        order__location=location,
        order__created_at__gte=start, order__created_at__lt=end,
        status="voided",
    )
    closeout.void_total = sum(
        ((it.unit_price * it.quantity) for it in voided_items),
        Decimal("0"),
    )

    comped_items = OrderItem.objects.filter(
        order__location=location,
        order__created_at__gte=start, order__created_at__lt=end,
        status="comped",
    )
    closeout.comp_total = sum(
        ((it.unit_price * it.quantity) for it in comped_items),
        Decimal("0"),
    )

    closeout.net_sales = (
        closeout.gross_sales - closeout.discount_total - closeout.comp_total
    ).quantize(Decimal("0.01"))

    # Payments
    payments = Payment.objects.filter(
        order__location=location,
        processed_at__gte=start, processed_at__lt=end,
        status__in=("captured", "partially_refunded"),
    )
    closeout.tip_total = payments.aggregate(s=Sum("tip_amount"))["s"] or Decimal("0")

    closeout.cash_total = payments.filter(method="cash").aggregate(
        s=Sum("amount")
    )["s"] or Decimal("0")
    closeout.card_total = payments.filter(method="card").aggregate(
        s=Sum("amount")
    )["s"] or Decimal("0")
    closeout.stripe_total = payments.filter(method="stripe").aggregate(
        s=Sum("amount")
    )["s"] or Decimal("0")
    closeout.other_tender_total = payments.exclude(
        method__in=("cash", "card", "stripe")
    ).aggregate(s=Sum("amount"))["s"] or Decimal("0")

    refunds = Refund.objects.filter(
        payment__order__location=location,
        created_at__gte=start, created_at__lt=end,
        status="succeeded",
    )
    closeout.refund_total = refunds.aggregate(
        s=Sum("amount")
    )["s"] or Decimal("0")

    closeout.expected_cash_drawer = closeout.cash_total
    if closeout.counted_cash_drawer is not None:
        closeout.cash_variance = (
            closeout.counted_cash_drawer - closeout.expected_cash_drawer
        ).quantize(Decimal("0.01"))

    closeout.save()
    return closeout


@transaction.atomic
def set_counted_cash(*, closeout: DailyCloseout, counted: Decimal) -> DailyCloseout:
    if closeout.status != "draft":
        raise ValidationError("closeout_not_draft")
    if counted < 0:
        raise ValidationError("invalid_amount")
    closeout.counted_cash_drawer = counted
    closeout.cash_variance = (counted - closeout.expected_cash_drawer).quantize(
        Decimal("0.01"),
    )
    closeout.save(update_fields=[
        "counted_cash_drawer", "cash_variance", "updated_at",
    ])
    return closeout


@transaction.atomic
def submit_closeout(*, closeout: DailyCloseout, actor=None) -> DailyCloseout:
    if closeout.status != "draft":
        raise ValidationError("closeout_not_draft")
    if closeout.counted_cash_drawer is None:
        raise ValidationError("count_cash_first")
    closeout.status = "submitted"
    closeout.submitted_at = timezone.now()
    closeout.submitted_by = actor
    closeout.save(update_fields=[
        "status", "submitted_at", "submitted_by", "updated_at",
    ])
    return closeout


@transaction.atomic
def approve_closeout(*, closeout: DailyCloseout, actor) -> DailyCloseout:
    if closeout.status != "submitted":
        raise ValidationError("closeout_not_submitted")
    closeout.status = "approved"
    closeout.approved_at = timezone.now()
    closeout.approved_by = actor
    closeout.save(update_fields=[
        "status", "approved_at", "approved_by", "updated_at",
    ])
    return closeout
