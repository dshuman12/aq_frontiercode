from __future__ import annotations

from rest_framework import serializers

from .models import StoredFile


class StoredFileSerializer(serializers.ModelSerializer):
    class Meta:
        model = StoredFile
        fields = [
            "id", "restaurant", "uploader", "kind",
            "storage_key", "public_url", "original_name",
            "content_type", "size_bytes", "sha256",
            "width", "height",
            "related_resource_type", "related_resource_id",
            "notes", "is_active", "created_at",
        ]
        read_only_fields = ["id", "created_at"]


class RegisterUploadSerializer(serializers.Serializer):
    kind = serializers.ChoiceField(choices=StoredFile.KIND_CHOICES)
    storage_key = serializers.CharField(max_length=500)
    original_name = serializers.CharField(max_length=200, required=False, allow_blank=True)
    content_type = serializers.CharField(max_length=120, required=False, allow_blank=True)
    size_bytes = serializers.IntegerField(min_value=0)
    sha256 = serializers.CharField(max_length=64, required=False, allow_blank=True)
    public_url = serializers.CharField(max_length=500, required=False, allow_blank=True)
    related_resource_type = serializers.CharField(required=False, allow_blank=True)
    related_resource_id = serializers.CharField(required=False, allow_blank=True)
    notes = serializers.CharField(required=False, allow_blank=True)
    width = serializers.IntegerField(required=False, allow_null=True)
    height = serializers.IntegerField(required=False, allow_null=True)
