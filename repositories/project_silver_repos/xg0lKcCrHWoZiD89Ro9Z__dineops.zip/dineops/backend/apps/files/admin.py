from django.contrib import admin

from .models import StoredFile


@admin.register(StoredFile)
class StoredFileAdmin(admin.ModelAdmin):
    list_display = ("kind", "original_name", "size_bytes",
                    "uploader", "is_active", "created_at")
    list_filter = ("kind", "is_active")
    search_fields = ("storage_key", "original_name", "sha256")
