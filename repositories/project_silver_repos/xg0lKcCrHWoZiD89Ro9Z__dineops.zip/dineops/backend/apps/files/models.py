from __future__ import annotations

import hashlib
import uuid

from django.conf import settings
from django.db import models

from apps.common.models import TimeStampedModel


class StoredFile(TimeStampedModel):
    """A file in restaurant-owned storage. Used for menu item photos, recipe
    photos, manager-checklist photo evidence, signature images, etc.

    The file itself lives in S3 (or compatible). This model is the metadata
    record + soft-delete + ownership + integrity hash."""

    KIND_CHOICES = [
        ("menu_item_photo", "Menu item photo"),
        ("recipe_photo", "Recipe photo"),
        ("ingredient_photo", "Ingredient photo"),
        ("waste_photo", "Waste photo"),
        ("checklist_photo", "Checklist photo"),
        ("signature", "Signature"),
        ("staff_document", "Staff document"),
        ("vendor_invoice", "Vendor invoice"),
        ("other", "Other"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant = models.ForeignKey(
        "restaurants.Restaurant", on_delete=models.CASCADE,
        related_name="files",
    )
    uploader = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="uploaded_files",
    )
    kind = models.CharField(max_length=40, choices=KIND_CHOICES)

    storage_key = models.CharField(max_length=500, unique=True,
                                   help_text="S3 object key.")
    public_url = models.CharField(max_length=500, blank=True)
    original_name = models.CharField(max_length=200, blank=True)
    content_type = models.CharField(max_length=120, blank=True)
    size_bytes = models.BigIntegerField(default=0)
    sha256 = models.CharField(max_length=64, blank=True, db_index=True)
    width = models.PositiveIntegerField(null=True, blank=True)
    height = models.PositiveIntegerField(null=True, blank=True)

    # Optional generic FK pointer for resources that own the file
    related_resource_type = models.CharField(max_length=80, blank=True)
    related_resource_id = models.CharField(max_length=80, blank=True,
                                           db_index=True)
    notes = models.CharField(max_length=300, blank=True)

    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["restaurant", "kind"]),
            models.Index(fields=["related_resource_type", "related_resource_id"]),
        ]

    @staticmethod
    def hash_bytes(data: bytes) -> str:
        return hashlib.sha256(data).hexdigest()
