from django.apps import AppConfig


class FilesConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.files"

    def ready(self):
        try:
            from . import signals  # noqa: F401
        except ImportError:
            pass
