from __future__ import annotations

import uuid
from typing import IO

from django.db import transaction

from apps.common.exceptions import ValidationError

from .models import StoredFile


MAX_FILE_BYTES = 25 * 1024 * 1024  # 25MB


@transaction.atomic
def register_uploaded_file(*, restaurant, uploader, kind: str,
                           storage_key: str, original_name: str,
                           content_type: str, size_bytes: int,
                           sha256: str = "",
                           public_url: str = "",
                           related_resource_type: str = "",
                           related_resource_id: str = "",
                           width: int | None = None,
                           height: int | None = None,
                           notes: str = "") -> StoredFile:
    """Persist a metadata record after an upload was streamed to S3."""
    if not storage_key:
        raise ValidationError("invalid_storage_key")
    if size_bytes > MAX_FILE_BYTES:
        raise ValidationError(
            "file_too_large",
            f"Max file size is {MAX_FILE_BYTES} bytes; got {size_bytes}.",
        )
    if kind not in dict(StoredFile.KIND_CHOICES):
        raise ValidationError("invalid_kind")
    return StoredFile.objects.create(
        restaurant=restaurant, uploader=uploader, kind=kind,
        storage_key=storage_key, original_name=original_name,
        content_type=content_type, size_bytes=size_bytes,
        sha256=sha256, public_url=public_url,
        related_resource_type=related_resource_type,
        related_resource_id=str(related_resource_id) if related_resource_id else "",
        width=width, height=height, notes=notes,
    )


def gen_storage_key(*, restaurant_slug: str, kind: str,
                    original_name: str = "") -> str:
    """Deterministic-ish storage key. Real impl might use date partitioning."""
    suffix = ""
    if original_name and "." in original_name:
        suffix = "." + original_name.rsplit(".", 1)[-1].lower()[:8]
    return f"{restaurant_slug}/{kind}/{uuid.uuid4().hex}{suffix}"


@transaction.atomic
def archive_file(*, file: StoredFile) -> StoredFile:
    file.is_active = False
    file.save(update_fields=["is_active", "updated_at"])
    return file
