from django.urls import path

from . import views

app_name = "files"

urlpatterns = [
    path("<uuid:restaurant_id>/",
         views.FileListCreate.as_view(), name="list-create"),
    path("<uuid:restaurant_id>/key/",
         views.GenStorageKeyView.as_view(), name="gen-key"),
    path("<uuid:restaurant_id>/<uuid:file_id>/",
         views.FileDetail.as_view(), name="detail"),
]
