from __future__ import annotations

from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common.exceptions import NotFound, PermissionDenied
from apps.restaurants.models import Restaurant, RestaurantMember

from . import services
from .models import StoredFile
from .serializers import RegisterUploadSerializer, StoredFileSerializer


def _require_member(user, restaurant_id):
    m = RestaurantMember.objects.filter(
        restaurant_id=restaurant_id, user=user, status="active",
    ).first()
    if not m:
        raise PermissionDenied("not_a_member")
    return m


class FileListCreate(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        _require_member(request.user, restaurant_id)
        qs = StoredFile.objects.filter(
            restaurant_id=restaurant_id, is_active=True,
        ).order_by("-created_at")
        if (kind := request.GET.get("kind")):
            qs = qs.filter(kind=kind)
        if (rt := request.GET.get("related_resource_type")):
            qs = qs.filter(related_resource_type=rt)
        if (rid := request.GET.get("related_resource_id")):
            qs = qs.filter(related_resource_id=rid)
        return Response({"results": StoredFileSerializer(qs[:200], many=True).data})

    def post(self, request, restaurant_id):
        _require_member(request.user, restaurant_id)
        s = RegisterUploadSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        rest = Restaurant.objects.get(id=restaurant_id)
        f = services.register_uploaded_file(
            restaurant=rest, uploader=request.user,
            **s.validated_data,
        )
        return Response({"file": StoredFileSerializer(f).data}, status=201)


class FileDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def delete(self, request, restaurant_id, file_id):
        _require_member(request.user, restaurant_id)
        f = StoredFile.objects.filter(
            id=file_id, restaurant_id=restaurant_id,
        ).first()
        if not f:
            raise NotFound()
        services.archive_file(file=f)
        return Response({"ok": True})


class GenStorageKeyView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        _require_member(request.user, restaurant_id)
        rest = Restaurant.objects.get(id=restaurant_id)
        kind = request.GET.get("kind", "other")
        original = request.GET.get("name", "")
        key = services.gen_storage_key(
            restaurant_slug=rest.slug, kind=kind, original_name=original,
        )
        return Response({"storage_key": key})
