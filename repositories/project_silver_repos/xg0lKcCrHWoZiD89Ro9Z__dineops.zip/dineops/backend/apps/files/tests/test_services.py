from __future__ import annotations

import pytest

from apps.accounts.models import User
from apps.common.exceptions import ValidationError
from apps.files.services import (
    MAX_FILE_BYTES, archive_file, gen_storage_key, register_uploaded_file,
)
from apps.restaurants.models import Restaurant


pytestmark = pytest.mark.django_db


def _setup():
    o = User.objects.create_user(email="o@x.com", password="pwpwpwpw")
    return Restaurant.objects.create(name="R", slug="myrest", owner=o), o


class TestRegisterUpload:
    def test_register(self):
        rest, owner = _setup()
        f = register_uploaded_file(
            restaurant=rest, uploader=owner, kind="menu_item_photo",
            storage_key="myrest/menu_item_photo/abc.jpg",
            original_name="burger.jpg", content_type="image/jpeg",
            size_bytes=120000, sha256="hash",
        )
        assert f.kind == "menu_item_photo"
        assert f.is_active

    def test_blank_key_rejected(self):
        rest, owner = _setup()
        with pytest.raises(ValidationError):
            register_uploaded_file(
                restaurant=rest, uploader=owner, kind="menu_item_photo",
                storage_key="", original_name="x", content_type="image/jpeg",
                size_bytes=1,
            )

    def test_too_large_rejected(self):
        rest, owner = _setup()
        with pytest.raises(ValidationError):
            register_uploaded_file(
                restaurant=rest, uploader=owner, kind="menu_item_photo",
                storage_key="x", original_name="x", content_type="image/jpeg",
                size_bytes=MAX_FILE_BYTES + 1,
            )

    def test_invalid_kind_rejected(self):
        rest, owner = _setup()
        with pytest.raises(ValidationError):
            register_uploaded_file(
                restaurant=rest, uploader=owner, kind="malware",
                storage_key="x", original_name="x", content_type="x",
                size_bytes=1,
            )


class TestArchive:
    def test_archive(self):
        rest, owner = _setup()
        f = register_uploaded_file(
            restaurant=rest, uploader=owner, kind="other",
            storage_key="x", original_name="", content_type="",
            size_bytes=10,
        )
        archive_file(file=f)
        f.refresh_from_db()
        assert not f.is_active


class TestGenKey:
    def test_basic(self):
        key = gen_storage_key(restaurant_slug="r", kind="menu_item_photo",
                              original_name="x.jpg")
        assert key.startswith("r/menu_item_photo/")
        assert key.endswith(".jpg")

    def test_no_extension(self):
        key = gen_storage_key(restaurant_slug="r", kind="other",
                              original_name="")
        assert key.startswith("r/other/")
