from __future__ import annotations

import uuid

from django.conf import settings
from django.db import models

from apps.common.models import TimeStampedModel


class ChecklistTemplate(TimeStampedModel):
    """A reusable list of tasks — opening, closing, deep clean."""

    KIND_CHOICES = [
        ("opening", "Opening"),
        ("closing", "Closing"),
        ("mid_shift", "Mid-shift"),
        ("weekly", "Weekly"),
        ("deep_clean", "Deep clean"),
        ("custom", "Custom"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant = models.ForeignKey(
        "restaurants.Restaurant", on_delete=models.CASCADE,
        related_name="checklist_templates",
    )
    location = models.ForeignKey(
        "locations.Location", on_delete=models.CASCADE,
        null=True, blank=True,
        related_name="checklist_templates",
        help_text="If set, only applies to this location; else any.",
    )
    name = models.CharField(max_length=160)
    kind = models.CharField(max_length=20, choices=KIND_CHOICES, default="custom")
    description = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["kind", "name"]


class ChecklistTemplateItem(TimeStampedModel):
    """A single task line on a template."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    template = models.ForeignKey(
        ChecklistTemplate, on_delete=models.CASCADE, related_name="items",
    )
    label = models.CharField(max_length=300)
    sort = models.PositiveIntegerField(default=0)
    requires_photo = models.BooleanField(default=False)
    requires_signature = models.BooleanField(default=False)
    expected_role = models.CharField(max_length=40, blank=True)

    class Meta:
        ordering = ["sort"]


class ManagerChecklist(TimeStampedModel):
    """An instantiated checklist — 'Opening — Mon Dec 4'."""

    STATUS_CHOICES = [
        ("pending", "Pending"),
        ("in_progress", "In progress"),
        ("completed", "Completed"),
        ("escalated", "Escalated"),
        ("skipped", "Skipped"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant = models.ForeignKey(
        "restaurants.Restaurant", on_delete=models.CASCADE,
        related_name="manager_checklists",
    )
    location = models.ForeignKey(
        "locations.Location", on_delete=models.CASCADE,
        related_name="manager_checklists",
    )
    template = models.ForeignKey(
        ChecklistTemplate, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="instances",
    )
    name = models.CharField(max_length=160)
    for_date = models.DateField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="pending")

    started_at = models.DateTimeField(null=True, blank=True)
    started_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="+",
    )
    completed_at = models.DateTimeField(null=True, blank=True)
    completed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="completed_checklists",
    )
    escalated_to = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="escalated_checklists",
    )
    escalated_reason = models.CharField(max_length=300, blank=True)
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ["-for_date", "name"]
        indexes = [
            models.Index(fields=["restaurant", "status"]),
            models.Index(fields=["for_date"]),
        ]


class ChecklistItemResult(TimeStampedModel):
    """The actual completion record for a single line on an instantiated
    checklist."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    checklist = models.ForeignKey(
        ManagerChecklist, on_delete=models.CASCADE, related_name="results",
    )
    label = models.CharField(max_length=300)
    sort = models.PositiveIntegerField(default=0)
    is_done = models.BooleanField(default=False)
    is_skipped = models.BooleanField(default=False)
    skipped_reason = models.CharField(max_length=200, blank=True)
    completed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="+",
    )
    completed_at = models.DateTimeField(null=True, blank=True)
    photo_url = models.CharField(max_length=500, blank=True)
    signature_url = models.CharField(max_length=500, blank=True)
    notes = models.CharField(max_length=300, blank=True)

    class Meta:
        ordering = ["sort"]
