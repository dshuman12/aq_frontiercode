from __future__ import annotations

from rest_framework import serializers

from .models import (
    ChecklistItemResult, ChecklistTemplate, ChecklistTemplateItem,
    ManagerChecklist,
)


class TemplateItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = ChecklistTemplateItem
        fields = ["id", "template", "label", "sort",
                  "requires_photo", "requires_signature", "expected_role"]


class TemplateSerializer(serializers.ModelSerializer):
    items = TemplateItemSerializer(many=True, read_only=True)

    class Meta:
        model = ChecklistTemplate
        fields = ["id", "restaurant", "location", "name", "kind",
                  "description", "is_active", "items"]


class CreateTemplateSerializer(serializers.Serializer):
    name = serializers.CharField(max_length=160)
    kind = serializers.ChoiceField(choices=ChecklistTemplate.KIND_CHOICES, default="custom")
    description = serializers.CharField(required=False, allow_blank=True)
    location_id = serializers.UUIDField(required=False, allow_null=True)


class AddTemplateItemSerializer(serializers.Serializer):
    label = serializers.CharField(max_length=300)
    sort = serializers.IntegerField(default=0)
    requires_photo = serializers.BooleanField(default=False)
    requires_signature = serializers.BooleanField(default=False)
    expected_role = serializers.CharField(required=False, allow_blank=True)


class ItemResultSerializer(serializers.ModelSerializer):
    completed_by_email = serializers.CharField(
        source="completed_by.email", read_only=True,
    )

    class Meta:
        model = ChecklistItemResult
        fields = ["id", "checklist", "label", "sort",
                  "is_done", "is_skipped", "skipped_reason",
                  "completed_by", "completed_by_email", "completed_at",
                  "photo_url", "signature_url", "notes"]


class ChecklistSerializer(serializers.ModelSerializer):
    location_name = serializers.CharField(source="location.name", read_only=True)
    result_count = serializers.IntegerField(source="results.count", read_only=True)

    class Meta:
        model = ManagerChecklist
        fields = ["id", "restaurant", "location", "location_name",
                  "template", "name", "for_date", "status",
                  "started_at", "started_by",
                  "completed_at", "completed_by",
                  "escalated_to", "escalated_reason",
                  "result_count", "notes"]


class ChecklistDetailSerializer(ChecklistSerializer):
    results = ItemResultSerializer(many=True, read_only=True)

    class Meta(ChecklistSerializer.Meta):
        fields = ChecklistSerializer.Meta.fields + ["results"]


class InstantiateSerializer(serializers.Serializer):
    template_id = serializers.UUIDField()
    location_id = serializers.UUIDField()
    for_date = serializers.DateField()
    name = serializers.CharField(required=False, allow_blank=True)


class MarkDoneSerializer(serializers.Serializer):
    photo_url = serializers.CharField(required=False, allow_blank=True)
    signature_url = serializers.CharField(required=False, allow_blank=True)
    notes = serializers.CharField(required=False, allow_blank=True)


class SkipItemSerializer(serializers.Serializer):
    reason = serializers.CharField(max_length=200)


class EscalateSerializer(serializers.Serializer):
    to_user_id = serializers.UUIDField()
    reason = serializers.CharField(max_length=300)
