from django.contrib import admin

from .models import (
    ChecklistItemResult, ChecklistTemplate, ChecklistTemplateItem,
    ManagerChecklist,
)


class TemplateItemInline(admin.TabularInline):
    model = ChecklistTemplateItem
    extra = 0


class ItemResultInline(admin.TabularInline):
    model = ChecklistItemResult
    extra = 0
    readonly_fields = ("completed_by", "completed_at")


@admin.register(ChecklistTemplate)
class TemplateAdmin(admin.ModelAdmin):
    list_display = ("name", "kind", "restaurant", "location", "is_active")
    list_filter = ("kind", "is_active")
    search_fields = ("name",)
    inlines = [TemplateItemInline]


@admin.register(ManagerChecklist)
class ChecklistAdmin(admin.ModelAdmin):
    list_display = ("name", "for_date", "location", "status",
                    "started_by", "completed_by")
    list_filter = ("status", "location", "for_date")
    search_fields = ("name",)
    inlines = [ItemResultInline]


admin.site.register(ChecklistItemResult)
