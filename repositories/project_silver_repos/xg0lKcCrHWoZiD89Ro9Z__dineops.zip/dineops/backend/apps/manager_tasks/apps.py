from django.apps import AppConfig


class ManagerTasksConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.manager_tasks"

    def ready(self):
        try:
            from . import signals  # noqa: F401
        except ImportError:
            pass
