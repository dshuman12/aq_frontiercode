from __future__ import annotations

from datetime import date

import pytest

from apps.accounts.models import User
from apps.common.exceptions import ValidationError
from apps.locations.models import Location
from apps.manager_tasks.services import (
    add_template_item, create_template, escalate_checklist,
    instantiate_checklist, mark_item_done, mark_item_skipped,
)
from apps.restaurants.models import Restaurant


pytestmark = pytest.mark.django_db


def _setup():
    owner = User.objects.create_user(email="o@x.com", password="pwpwpwpw")
    rest = Restaurant.objects.create(name="R", slug="r", owner=owner)
    loc = Location.objects.create(
        restaurant=rest, name="Main", slug="main", accepts_dine_in=True,
    )
    return rest, loc, owner


class TestTemplate:
    def test_create(self):
        rest, _, _ = _setup()
        t = create_template(restaurant=rest, name="Opening", kind="opening")
        assert t.kind == "opening"

    def test_blank_name(self):
        rest, _, _ = _setup()
        with pytest.raises(ValidationError):
            create_template(restaurant=rest, name="  ")

    def test_add_item(self):
        rest, _, _ = _setup()
        t = create_template(restaurant=rest, name="Opening")
        item = add_template_item(template=t, label="Wipe down line",
                                 sort=10, requires_photo=True)
        assert item.requires_photo


class TestInstantiate:
    def test_instantiate_creates_results(self):
        rest, loc, _ = _setup()
        t = create_template(restaurant=rest, name="Opening")
        add_template_item(template=t, label="A", sort=1)
        add_template_item(template=t, label="B", sort=2)
        cl = instantiate_checklist(template=t, location=loc,
                                    for_date=date(2023, 12, 8))
        assert cl.results.count() == 2
        assert cl.status == "pending"

    def test_cross_restaurant_rejected(self):
        rest, _, owner = _setup()
        rest2 = Restaurant.objects.create(name="R2", slug="r2", owner=owner)
        loc2 = Location.objects.create(
            restaurant=rest2, name="x", slug="x", accepts_dine_in=True,
        )
        t = create_template(restaurant=rest, name="X")
        with pytest.raises(ValidationError):
            instantiate_checklist(template=t, location=loc2,
                                  for_date=date(2023, 12, 8))


class TestComplete:
    def test_mark_done_advances_status(self):
        rest, loc, owner = _setup()
        t = create_template(restaurant=rest, name="T")
        add_template_item(template=t, label="A")
        cl = instantiate_checklist(template=t, location=loc,
                                    for_date=date(2023, 12, 8))
        result = cl.results.first()
        mark_item_done(result=result, actor=owner)
        cl.refresh_from_db()
        assert cl.status == "completed"

    def test_partial_progress(self):
        rest, loc, owner = _setup()
        t = create_template(restaurant=rest, name="T")
        add_template_item(template=t, label="A")
        add_template_item(template=t, label="B")
        cl = instantiate_checklist(template=t, location=loc,
                                    for_date=date(2023, 12, 8))
        first = cl.results.first()
        mark_item_done(result=first, actor=owner)
        cl.refresh_from_db()
        assert cl.status == "in_progress"

    def test_skip_requires_reason(self):
        rest, loc, owner = _setup()
        t = create_template(restaurant=rest, name="T")
        add_template_item(template=t, label="A")
        cl = instantiate_checklist(template=t, location=loc,
                                    for_date=date(2023, 12, 8))
        with pytest.raises(ValidationError):
            mark_item_skipped(result=cl.results.first(),
                              reason="  ", actor=owner)

    def test_skip(self):
        rest, loc, owner = _setup()
        t = create_template(restaurant=rest, name="T")
        add_template_item(template=t, label="A")
        cl = instantiate_checklist(template=t, location=loc,
                                    for_date=date(2023, 12, 8))
        mark_item_skipped(
            result=cl.results.first(),
            reason="Out of supplies",
            actor=owner,
        )
        result = cl.results.first()
        assert result.is_skipped
        assert result.skipped_reason == "Out of supplies"


class TestEscalate:
    def test_escalate(self):
        rest, loc, owner = _setup()
        gm = User.objects.create_user(email="gm@x.com", password="pwpwpwpw")
        t = create_template(restaurant=rest, name="T")
        cl = instantiate_checklist(template=t, location=loc,
                                    for_date=date(2023, 12, 8))
        escalate_checklist(checklist=cl, to_user=gm,
                           reason="freezer broken")
        cl.refresh_from_db()
        assert cl.status == "escalated"
        assert cl.escalated_to == gm

    def test_escalate_requires_reason(self):
        rest, loc, owner = _setup()
        gm = User.objects.create_user(email="gm@x.com", password="pwpwpwpw")
        t = create_template(restaurant=rest, name="T")
        cl = instantiate_checklist(template=t, location=loc,
                                    for_date=date(2023, 12, 8))
        with pytest.raises(ValidationError):
            escalate_checklist(checklist=cl, to_user=gm, reason="  ")
