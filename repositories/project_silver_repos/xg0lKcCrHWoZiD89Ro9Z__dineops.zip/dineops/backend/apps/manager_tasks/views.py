from __future__ import annotations

from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.accounts.models import User
from apps.common.exceptions import NotFound, PermissionDenied
from apps.locations.models import Location
from apps.restaurants.models import Restaurant, RestaurantMember

from . import services
from .models import (
    ChecklistItemResult, ChecklistTemplate, ManagerChecklist,
)
from .serializers import (
    AddTemplateItemSerializer, ChecklistDetailSerializer, ChecklistSerializer,
    CreateTemplateSerializer, EscalateSerializer, InstantiateSerializer,
    ItemResultSerializer, MarkDoneSerializer, SkipItemSerializer,
    TemplateItemSerializer, TemplateSerializer,
)


def _require_member(user, restaurant_id):
    m = RestaurantMember.objects.filter(
        restaurant_id=restaurant_id, user=user, status="active",
    ).first()
    if not m:
        raise PermissionDenied("not_a_member")
    return m


def _can_manage(roles):
    return any(r in (
        "owner", "general_manager", "assistant_manager",
    ) for r in roles or [])


def _can_complete(roles):
    return any(r in (
        "owner", "general_manager", "assistant_manager",
        "chef", "kitchen_staff", "server", "cashier", "inventory_manager",
    ) for r in roles or [])


class TemplateListCreate(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        _require_member(request.user, restaurant_id)
        qs = ChecklistTemplate.objects.filter(
            restaurant_id=restaurant_id, is_active=True,
        ).prefetch_related("items").order_by("kind", "name")
        return Response({"results": TemplateSerializer(qs, many=True).data})

    def post(self, request, restaurant_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_manage(member.roles):
            raise PermissionDenied()
        s = CreateTemplateSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        rest = Restaurant.objects.get(id=restaurant_id)
        location = None
        if s.validated_data.get("location_id"):
            location = Location.objects.filter(
                id=s.validated_data["location_id"], restaurant_id=restaurant_id,
            ).first()
        t = services.create_template(
            restaurant=rest,
            name=s.validated_data["name"],
            kind=s.validated_data["kind"],
            description=s.validated_data.get("description", ""),
            location=location,
        )
        return Response({"template": TemplateSerializer(t).data}, status=201)


class TemplateAddItem(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, template_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_manage(member.roles):
            raise PermissionDenied()
        t = ChecklistTemplate.objects.filter(
            id=template_id, restaurant_id=restaurant_id,
        ).first()
        if not t:
            raise NotFound()
        s = AddTemplateItemSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        item = services.add_template_item(template=t, **s.validated_data)
        return Response({"item": TemplateItemSerializer(item).data}, status=201)


class ChecklistListCreate(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        _require_member(request.user, restaurant_id)
        qs = ManagerChecklist.objects.filter(
            restaurant_id=restaurant_id,
        ).select_related("location", "template").order_by("-for_date")[:100]
        return Response({"results": ChecklistSerializer(qs, many=True).data})

    def post(self, request, restaurant_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_manage(member.roles):
            raise PermissionDenied()
        s = InstantiateSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        t = ChecklistTemplate.objects.filter(
            id=s.validated_data["template_id"], restaurant_id=restaurant_id,
        ).first()
        loc = Location.objects.filter(
            id=s.validated_data["location_id"], restaurant_id=restaurant_id,
        ).first()
        if not t or not loc:
            raise NotFound()
        cl = services.instantiate_checklist(
            template=t, location=loc,
            for_date=s.validated_data["for_date"],
            name=s.validated_data.get("name", ""),
        )
        return Response({"checklist": ChecklistSerializer(cl).data}, status=201)


class ChecklistDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id, checklist_id):
        _require_member(request.user, restaurant_id)
        cl = ManagerChecklist.objects.filter(
            id=checklist_id, restaurant_id=restaurant_id,
        ).prefetch_related("results").first()
        if not cl:
            raise NotFound()
        return Response({"checklist": ChecklistDetailSerializer(cl).data})


class MarkItemDone(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, result_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_complete(member.roles):
            raise PermissionDenied()
        result = ChecklistItemResult.objects.filter(
            id=result_id, checklist__restaurant_id=restaurant_id,
        ).select_related("checklist").first()
        if not result:
            raise NotFound()
        s = MarkDoneSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        services.mark_item_done(
            result=result, actor=request.user, **s.validated_data,
        )
        return Response({"result": ItemResultSerializer(result).data})


class SkipItem(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, result_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_complete(member.roles):
            raise PermissionDenied()
        result = ChecklistItemResult.objects.filter(
            id=result_id, checklist__restaurant_id=restaurant_id,
        ).first()
        if not result:
            raise NotFound()
        s = SkipItemSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        services.mark_item_skipped(
            result=result, reason=s.validated_data["reason"],
            actor=request.user,
        )
        return Response({"result": ItemResultSerializer(result).data})


class EscalateChecklist(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, checklist_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_manage(member.roles):
            raise PermissionDenied()
        cl = ManagerChecklist.objects.filter(
            id=checklist_id, restaurant_id=restaurant_id,
        ).first()
        if not cl:
            raise NotFound()
        s = EscalateSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        to_user = User.objects.filter(id=s.validated_data["to_user_id"]).first()
        if not to_user:
            raise NotFound("user_not_found")
        services.escalate_checklist(
            checklist=cl, to_user=to_user,
            reason=s.validated_data["reason"],
        )
        return Response({"checklist": ChecklistSerializer(cl).data})
