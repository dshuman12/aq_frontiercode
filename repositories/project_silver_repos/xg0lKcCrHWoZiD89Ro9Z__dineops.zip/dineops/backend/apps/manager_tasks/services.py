from __future__ import annotations

from datetime import date

from django.db import transaction
from django.utils import timezone

from apps.common.exceptions import Conflict, NotFound, ValidationError

from .models import (
    ChecklistItemResult, ChecklistTemplate, ChecklistTemplateItem,
    ManagerChecklist,
)


@transaction.atomic
def create_template(*, restaurant, name: str, kind: str = "custom",
                    description: str = "", location=None) -> ChecklistTemplate:
    if not name.strip():
        raise ValidationError("invalid_name")
    return ChecklistTemplate.objects.create(
        restaurant=restaurant, location=location,
        name=name.strip(), kind=kind, description=description,
    )


@transaction.atomic
def add_template_item(*, template: ChecklistTemplate, label: str,
                      sort: int = 0, requires_photo: bool = False,
                      requires_signature: bool = False,
                      expected_role: str = "") -> ChecklistTemplateItem:
    if not label.strip():
        raise ValidationError("invalid_label")
    return ChecklistTemplateItem.objects.create(
        template=template, label=label.strip(),
        sort=sort, requires_photo=requires_photo,
        requires_signature=requires_signature,
        expected_role=expected_role,
    )


@transaction.atomic
def instantiate_checklist(*, template: ChecklistTemplate, location,
                          for_date: date, name: str = "") -> ManagerChecklist:
    if location.restaurant_id != template.restaurant_id:
        raise ValidationError("location_not_in_restaurant")
    name = name.strip() or f"{template.name} — {for_date}"
    cl = ManagerChecklist.objects.create(
        restaurant=template.restaurant, location=location,
        template=template, name=name, for_date=for_date,
    )
    for it in template.items.all().order_by("sort"):
        ChecklistItemResult.objects.create(
            checklist=cl, label=it.label, sort=it.sort,
        )
    return cl


@transaction.atomic
def mark_item_done(*, result: ChecklistItemResult, actor=None,
                   photo_url: str = "", signature_url: str = "",
                   notes: str = "") -> ChecklistItemResult:
    result.is_done = True
    result.is_skipped = False
    result.completed_by = actor
    result.completed_at = timezone.now()
    if photo_url:
        result.photo_url = photo_url
    if signature_url:
        result.signature_url = signature_url
    if notes:
        result.notes = notes
    result.save()

    cl = result.checklist
    if cl.status == "pending":
        cl.status = "in_progress"
        cl.started_at = timezone.now()
        cl.started_by = actor
        cl.save(update_fields=["status", "started_at", "started_by", "updated_at"])

    pending = cl.results.filter(is_done=False, is_skipped=False).count()
    if pending == 0:
        cl.status = "completed"
        cl.completed_at = timezone.now()
        cl.completed_by = actor
        cl.save(update_fields=[
            "status", "completed_at", "completed_by", "updated_at",
        ])
    return result


@transaction.atomic
def mark_item_skipped(*, result: ChecklistItemResult,
                      reason: str, actor=None) -> ChecklistItemResult:
    if not reason.strip():
        raise ValidationError("skip_reason_required")
    result.is_skipped = True
    result.is_done = False
    result.skipped_reason = reason
    result.completed_by = actor
    result.completed_at = timezone.now()
    result.save()
    return result


@transaction.atomic
def escalate_checklist(*, checklist: ManagerChecklist, to_user,
                       reason: str) -> ManagerChecklist:
    if not reason.strip():
        raise ValidationError("escalation_reason_required")
    checklist.status = "escalated"
    checklist.escalated_to = to_user
    checklist.escalated_reason = reason
    checklist.save(update_fields=[
        "status", "escalated_to", "escalated_reason", "updated_at",
    ])
    return checklist
