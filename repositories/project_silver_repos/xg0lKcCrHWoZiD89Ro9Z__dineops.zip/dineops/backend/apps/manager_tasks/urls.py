from django.urls import path

from . import views

app_name = "manager_tasks"

urlpatterns = [
    path("<uuid:restaurant_id>/templates/",
         views.TemplateListCreate.as_view(), name="template-list-create"),
    path("<uuid:restaurant_id>/templates/<uuid:template_id>/items/",
         views.TemplateAddItem.as_view(), name="template-add-item"),
    path("<uuid:restaurant_id>/checklists/",
         views.ChecklistListCreate.as_view(), name="checklist-list-create"),
    path("<uuid:restaurant_id>/checklists/<uuid:checklist_id>/",
         views.ChecklistDetail.as_view(), name="checklist-detail"),
    path("<uuid:restaurant_id>/checklists/<uuid:checklist_id>/escalate/",
         views.EscalateChecklist.as_view(), name="checklist-escalate"),
    path("<uuid:restaurant_id>/results/<uuid:result_id>/done/",
         views.MarkItemDone.as_view(), name="result-done"),
    path("<uuid:restaurant_id>/results/<uuid:result_id>/skip/",
         views.SkipItem.as_view(), name="result-skip"),
]
