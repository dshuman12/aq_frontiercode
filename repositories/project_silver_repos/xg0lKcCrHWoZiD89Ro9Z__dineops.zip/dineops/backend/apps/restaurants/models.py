from __future__ import annotations

import uuid
from datetime import timedelta

from django.conf import settings
from django.db import models
from django.utils import timezone

from apps.common.models import TimeStampedModel


class Restaurant(TimeStampedModel):
    """Tenant root. Every other resource hangs off (directly or indirectly) one
    of these."""

    KIND_CHOICES = [
        ("full_service", "Full-service"),
        ("quick_service", "Quick-service"),
        ("cafe", "Cafe"),
        ("food_truck", "Food truck"),
        ("ghost_kitchen", "Ghost kitchen"),
        ("bakery", "Bakery"),
        ("bar", "Bar"),
        ("other", "Other"),
    ]

    PLAN_CHOICES = [
        ("free", "Free"),
        ("pro", "Pro"),
        ("enterprise", "Enterprise"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=200)
    slug = models.SlugField(max_length=80, unique=True, db_index=True)
    kind = models.CharField(max_length=32, choices=KIND_CHOICES, default="full_service")
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="owned_restaurants"
    )

    contact_email = models.EmailField(blank=True)
    contact_phone = models.CharField(max_length=40, blank=True)
    timezone = models.CharField(max_length=64, default="UTC")
    currency = models.CharField(max_length=3, default="USD")
    default_tax_percent = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    default_service_charge_percent = models.DecimalField(max_digits=5, decimal_places=2, default=0)

    branding_logo_url = models.URLField(blank=True)
    branding_primary_color = models.CharField(max_length=20, default="#dc2626")
    plan = models.CharField(max_length=16, choices=PLAN_CHOICES, default="free")
    status = models.CharField(
        max_length=16,
        default="active",
        choices=[("active", "Active"), ("suspended", "Suspended")],
    )

    class Meta:
        ordering = ["name"]

    def __str__(self) -> str:
        return self.name


class RestaurantMember(TimeStampedModel):
    """User ↔ Restaurant assignment with roles."""

    STATUS_ACTIVE = "active"
    STATUS_REMOVED = "removed"
    STATUS_CHOICES = [(STATUS_ACTIVE, "Active"), (STATUS_REMOVED, "Removed")]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant = models.ForeignKey(
        Restaurant, on_delete=models.CASCADE, related_name="members"
    )
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="memberships"
    )
    roles = models.JSONField(default=list, blank=True)
    custom_permissions = models.JSONField(default=list, blank=True)
    location_ids = models.JSONField(default=list, blank=True, help_text="If empty, all locations.")
    invited_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="+",
    )
    joined_at = models.DateTimeField(default=timezone.now)
    status = models.CharField(max_length=16, choices=STATUS_CHOICES, default=STATUS_ACTIVE)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["restaurant", "user"], name="unique_member"),
        ]
        indexes = [
            models.Index(fields=["restaurant", "status"]),
            models.Index(fields=["user", "status"]),
        ]

    def __str__(self) -> str:
        return f"{self.user_id} @ {self.restaurant_id}"


class Invitation(TimeStampedModel):
    """Pending invite to join a restaurant. The raw token is hashed; the
    plaintext value is only returned once on creation (for the email link)."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant = models.ForeignKey(
        Restaurant, on_delete=models.CASCADE, related_name="invitations"
    )
    email = models.EmailField(db_index=True)
    roles = models.JSONField(default=list)
    location_ids = models.JSONField(default=list, blank=True)
    invited_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="+"
    )
    token_hash = models.CharField(max_length=64, db_index=True)
    expires_at = models.DateTimeField(db_index=True)
    accepted_at = models.DateTimeField(null=True, blank=True)
    revoked_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        indexes = [models.Index(fields=["restaurant", "email"])]

    @property
    def is_active(self) -> bool:
        return self.accepted_at is None and self.revoked_at is None and self.expires_at > timezone.now()


class Role(TimeStampedModel):
    """Custom restaurant-level roles. Default roles aren't stored here — they
    live in `apps.common.policies`."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant = models.ForeignKey(Restaurant, on_delete=models.CASCADE, related_name="roles")
    key = models.SlugField(max_length=64)
    label = models.CharField(max_length=120)
    permissions = models.JSONField(default=list)
    is_system = models.BooleanField(default=False)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["restaurant", "key"], name="unique_role_key"),
        ]
