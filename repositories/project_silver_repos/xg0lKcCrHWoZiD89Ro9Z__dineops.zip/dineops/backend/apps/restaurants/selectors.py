from __future__ import annotations

from typing import Iterable

from .models import Restaurant, RestaurantMember


def list_my_restaurants(*, user) -> Iterable[Restaurant]:
    """Restaurants the user is an active member of, with role data attached
    on `_my_roles` for callers."""
    memberships = (
        RestaurantMember.objects.filter(user=user, status="active")
        .select_related("restaurant")
        .order_by("restaurant__name")
    )
    out = []
    for m in memberships:
        r = m.restaurant
        r._my_roles = m.roles
        out.append(r)
    return out


def my_active_member(*, user, restaurant_id) -> RestaurantMember | None:
    return (
        RestaurantMember.objects.filter(
            user=user, restaurant_id=restaurant_id, status="active"
        )
        .first()
    )


def list_members(*, restaurant_id):
    return (
        RestaurantMember.objects.filter(restaurant_id=restaurant_id, status="active")
        .select_related("user")
        .order_by("user__full_name")
    )
