from __future__ import annotations

from rest_framework import serializers

from apps.accounts.serializers import UserSerializer

from .models import Invitation, Restaurant, RestaurantMember, Role


class RestaurantSerializer(serializers.ModelSerializer):
    my_roles = serializers.SerializerMethodField()

    class Meta:
        model = Restaurant
        fields = (
            "id", "name", "slug", "kind",
            "contact_email", "contact_phone", "timezone", "currency",
            "default_tax_percent", "default_service_charge_percent",
            "branding_logo_url", "branding_primary_color",
            "plan", "status", "my_roles", "created_at",
        )
        read_only_fields = ("id", "slug", "plan", "status", "my_roles", "created_at")

    def get_my_roles(self, obj):
        return getattr(obj, "_my_roles", [])


class RestaurantCreateSerializer(serializers.Serializer):
    name = serializers.CharField(min_length=2, max_length=200)
    kind = serializers.ChoiceField(
        choices=Restaurant.KIND_CHOICES, required=False, default="full_service"
    )
    contact_email = serializers.EmailField(required=False, allow_blank=True)
    contact_phone = serializers.CharField(required=False, allow_blank=True, max_length=40)
    timezone = serializers.CharField(required=False, max_length=64, default="UTC")
    currency = serializers.CharField(required=False, max_length=3, default="USD")


class RestaurantUpdateSerializer(serializers.Serializer):
    name = serializers.CharField(min_length=2, max_length=200, required=False)
    kind = serializers.ChoiceField(choices=Restaurant.KIND_CHOICES, required=False)
    contact_email = serializers.EmailField(required=False, allow_blank=True)
    contact_phone = serializers.CharField(required=False, allow_blank=True, max_length=40)
    timezone = serializers.CharField(required=False, max_length=64)
    currency = serializers.CharField(required=False, max_length=3)
    default_tax_percent = serializers.DecimalField(required=False, max_digits=5, decimal_places=2, min_value=0, max_value=100)
    default_service_charge_percent = serializers.DecimalField(required=False, max_digits=5, decimal_places=2, min_value=0, max_value=100)
    branding_logo_url = serializers.URLField(required=False, allow_blank=True)
    branding_primary_color = serializers.CharField(required=False, max_length=20)


class MemberSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)

    class Meta:
        model = RestaurantMember
        fields = ("id", "user", "roles", "custom_permissions", "location_ids",
                  "joined_at", "status")


class InviteSerializer(serializers.Serializer):
    email = serializers.EmailField()
    roles = serializers.ListField(child=serializers.CharField(), allow_empty=False)
    location_ids = serializers.ListField(child=serializers.UUIDField(), required=False)


class InvitationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Invitation
        fields = ("id", "email", "roles", "location_ids", "expires_at",
                  "accepted_at", "revoked_at", "created_at")


class AcceptInvitationSerializer(serializers.Serializer):
    token = serializers.CharField()


class UpdateMemberSerializer(serializers.Serializer):
    roles = serializers.ListField(child=serializers.CharField(), allow_empty=False)
    custom_permissions = serializers.ListField(child=serializers.CharField(), required=False)
    location_ids = serializers.ListField(child=serializers.UUIDField(), required=False)


class RoleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Role
        fields = ("id", "key", "label", "permissions", "is_system", "created_at")
        read_only_fields = ("id", "is_system", "created_at")
