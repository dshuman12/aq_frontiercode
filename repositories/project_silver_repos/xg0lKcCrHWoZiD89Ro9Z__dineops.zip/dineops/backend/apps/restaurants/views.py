from __future__ import annotations

from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common.exceptions import NotFound, PermissionDenied
from apps.common.pagination import StandardPagination

from . import selectors, services
from .models import Invitation, Restaurant, RestaurantMember, Role
from .permissions import IsOwnerOrManager
from .serializers import (
    AcceptInvitationSerializer,
    InvitationSerializer,
    InviteSerializer,
    MemberSerializer,
    RestaurantCreateSerializer,
    RestaurantSerializer,
    RestaurantUpdateSerializer,
    RoleSerializer,
    UpdateMemberSerializer,
)


def _resolve_restaurant_or_403(user, restaurant_id):
    member = selectors.my_active_member(user=user, restaurant_id=restaurant_id)
    if not member:
        raise PermissionDenied("not_a_member")
    return Restaurant.objects.filter(id=restaurant_id).first(), member


class RestaurantListCreate(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request):
        items = list(selectors.list_my_restaurants(user=request.user))
        return Response({"results": RestaurantSerializer(items, many=True).data})

    def post(self, request):
        s = RestaurantCreateSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        restaurant = services.create_restaurant(owner=request.user, **{
            **s.validated_data, "timezone_": s.validated_data.pop("timezone", "UTC"),
        })
        restaurant._my_roles = ["owner"]
        return Response(
            {"restaurant": RestaurantSerializer(restaurant).data},
            status=status.HTTP_201_CREATED,
        )


class RestaurantDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        restaurant, member = _resolve_restaurant_or_403(request.user, restaurant_id)
        if not restaurant:
            raise NotFound()
        restaurant._my_roles = member.roles
        return Response({"restaurant": RestaurantSerializer(restaurant).data})

    def patch(self, request, restaurant_id):
        restaurant, member = _resolve_restaurant_or_403(request.user, restaurant_id)
        if not restaurant:
            raise NotFound()
        if not any(r in ("owner", "general_manager") for r in member.roles or []):
            raise PermissionDenied()
        s = RestaurantUpdateSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        restaurant = services.update_restaurant(restaurant=restaurant, **s.validated_data)
        restaurant._my_roles = member.roles
        return Response({"restaurant": RestaurantSerializer(restaurant).data})


class MemberListView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        _, _ = _resolve_restaurant_or_403(request.user, restaurant_id)
        items = list(selectors.list_members(restaurant_id=restaurant_id))
        return Response({"results": MemberSerializer(items, many=True).data})


class InviteCreateView(APIView):
    permission_classes = (IsAuthenticated, IsOwnerOrManager)

    def post(self, request, restaurant_id):
        restaurant = Restaurant.objects.filter(id=restaurant_id).first()
        if not restaurant:
            raise NotFound()
        s = InviteSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        invitation, _raw = services.invite_member(
            restaurant=restaurant,
            inviter=request.user,
            email=s.validated_data["email"],
            roles=s.validated_data["roles"],
            location_ids=s.validated_data.get("location_ids", []),
        )
        return Response(
            {"invitation": InvitationSerializer(invitation).data},
            status=status.HTTP_201_CREATED,
        )


class InviteAcceptView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request):
        s = AcceptInvitationSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        member = services.accept_invitation(
            raw_token=s.validated_data["token"], user=request.user,
        )
        return Response({"membership": MemberSerializer(member).data})


class MemberDetailView(APIView):
    permission_classes = (IsAuthenticated, IsOwnerOrManager)

    def patch(self, request, restaurant_id, member_id):
        member = RestaurantMember.objects.filter(
            id=member_id, restaurant_id=restaurant_id, status="active",
        ).first()
        if not member:
            raise NotFound()
        s = UpdateMemberSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        member = services.update_member_roles(
            member=member,
            roles=s.validated_data["roles"],
            custom_permissions=s.validated_data.get("custom_permissions"),
            location_ids=s.validated_data.get("location_ids"),
        )
        return Response({"membership": MemberSerializer(member).data})

    def delete(self, request, restaurant_id, member_id):
        member = RestaurantMember.objects.filter(
            id=member_id, restaurant_id=restaurant_id, status="active",
        ).first()
        if not member:
            raise NotFound()
        services.remove_member(member=member)
        return Response({"ok": True})


class RoleListCreateView(APIView):
    permission_classes = (IsAuthenticated, IsOwnerOrManager)

    def get(self, request, restaurant_id):
        items = Role.objects.filter(restaurant_id=restaurant_id).order_by("label")
        return Response({"results": RoleSerializer(items, many=True).data})

    def post(self, request, restaurant_id):
        s = RoleSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        role = Role.objects.create(restaurant_id=restaurant_id, **s.validated_data)
        return Response({"role": RoleSerializer(role).data}, status=201)
