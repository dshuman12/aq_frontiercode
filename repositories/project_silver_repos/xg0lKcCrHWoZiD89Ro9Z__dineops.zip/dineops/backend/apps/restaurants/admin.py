from django.contrib import admin

from .models import Invitation, Restaurant, RestaurantMember, Role


@admin.register(Restaurant)
class RestaurantAdmin(admin.ModelAdmin):
    list_display = ("name", "slug", "kind", "owner", "plan", "status", "created_at")
    search_fields = ("name", "slug")
    list_filter = ("kind", "plan", "status")


@admin.register(RestaurantMember)
class RestaurantMemberAdmin(admin.ModelAdmin):
    list_display = ("restaurant", "user", "roles", "status", "joined_at")
    list_filter = ("status",)
    search_fields = ("user__email", "restaurant__name")


@admin.register(Invitation)
class InvitationAdmin(admin.ModelAdmin):
    list_display = ("restaurant", "email", "roles", "expires_at", "accepted_at")
    search_fields = ("email", "restaurant__name")


@admin.register(Role)
class RoleAdmin(admin.ModelAdmin):
    list_display = ("restaurant", "key", "label", "is_system")
    search_fields = ("label", "key")
