from __future__ import annotations

from rest_framework.permissions import BasePermission

from .models import RestaurantMember


class IsOwnerOrManager(BasePermission):
    """Caller must be owner or general_manager of the restaurant in URL."""

    def has_permission(self, request, view):
        if not request.user.is_authenticated:
            return False
        rid = view.kwargs.get("restaurant_id") or request.GET.get("restaurant")
        if not rid:
            return False
        m = RestaurantMember.objects.filter(
            restaurant_id=rid, user=request.user, status="active"
        ).first()
        if not m:
            return False
        return any(r in ("owner", "general_manager") for r in m.roles or [])
