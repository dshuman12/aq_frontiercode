import pytest
from django.utils import timezone
from datetime import timedelta

from apps.accounts.tests.factories import UserFactory
from apps.common.exceptions import Conflict, NotFound, ValidationError
from apps.restaurants.models import Invitation, Restaurant, RestaurantMember
from apps.restaurants.services import (
    accept_invitation,
    create_restaurant,
    invite_member,
    remove_member,
    revoke_invitation,
    update_member_roles,
    update_restaurant,
)


@pytest.mark.django_db
class TestCreateRestaurant:
    def test_create_makes_owner_membership(self):
        owner = UserFactory()
        r = create_restaurant(owner=owner, name="Bistro Lyon")
        assert r.slug == "bistro-lyon"
        membership = RestaurantMember.objects.get(restaurant=r, user=owner)
        assert "owner" in membership.roles

    def test_create_rejects_short_name(self):
        owner = UserFactory()
        with pytest.raises(ValidationError):
            create_restaurant(owner=owner, name="X")

    def test_create_uses_owner_email_as_default_contact(self):
        owner = UserFactory(email="o@example.com")
        r = create_restaurant(owner=owner, name="Foo")
        assert r.contact_email == "o@example.com"

    def test_update_restaurant_filters_unknown_fields(self):
        owner = UserFactory()
        r = create_restaurant(owner=owner, name="X")
        update_restaurant(restaurant=r, name="Renamed", evil="ignored")
        r.refresh_from_db()
        assert r.name == "Renamed"


@pytest.mark.django_db
class TestInviteFlow:
    def test_invite_creates_pending_invitation(self):
        owner = UserFactory()
        r = create_restaurant(owner=owner, name="X")
        inv, raw = invite_member(restaurant=r, inviter=owner,
                                 email="new@example.com", roles=["chef"])
        assert inv.email == "new@example.com"
        assert inv.expires_at > timezone.now()
        assert raw  # raw token returned

    def test_invite_default_role_is_viewer_when_empty(self):
        owner = UserFactory()
        r = create_restaurant(owner=owner, name="X")
        inv, _ = invite_member(restaurant=r, inviter=owner,
                               email="new@example.com", roles=[])
        assert inv.roles == ["viewer"]

    def test_accept_invitation_creates_membership(self):
        owner = UserFactory()
        r = create_restaurant(owner=owner, name="X")
        new_user = UserFactory(email="new@example.com")
        _inv, raw = invite_member(restaurant=r, inviter=owner,
                                  email="new@example.com", roles=["chef"])
        member = accept_invitation(raw_token=raw, user=new_user)
        assert member.roles == ["chef"]
        assert member.status == "active"

    def test_accept_invitation_email_mismatch(self):
        owner = UserFactory()
        r = create_restaurant(owner=owner, name="X")
        wrong_user = UserFactory(email="wrong@example.com")
        _inv, raw = invite_member(restaurant=r, inviter=owner,
                                  email="right@example.com", roles=["chef"])
        with pytest.raises(ValidationError):
            accept_invitation(raw_token=raw, user=wrong_user)

    def test_accept_invitation_expired(self):
        owner = UserFactory()
        r = create_restaurant(owner=owner, name="X")
        new_user = UserFactory(email="new@example.com")
        inv, raw = invite_member(restaurant=r, inviter=owner,
                                 email="new@example.com", roles=["chef"])
        inv.expires_at = timezone.now() - timedelta(seconds=1)
        inv.save()
        with pytest.raises(NotFound):
            accept_invitation(raw_token=raw, user=new_user)

    def test_accept_invitation_unknown_token_raises(self):
        new_user = UserFactory()
        with pytest.raises(NotFound):
            accept_invitation(raw_token="nonsense", user=new_user)

    def test_accept_revoked_invitation_fails(self):
        owner = UserFactory()
        r = create_restaurant(owner=owner, name="X")
        new_user = UserFactory(email="new@example.com")
        inv, raw = invite_member(restaurant=r, inviter=owner,
                                 email="new@example.com", roles=["chef"])
        revoke_invitation(invitation=inv)
        with pytest.raises(NotFound):
            accept_invitation(raw_token=raw, user=new_user)

    def test_revoke_already_accepted_invitation_409(self):
        owner = UserFactory()
        r = create_restaurant(owner=owner, name="X")
        new_user = UserFactory(email="new@example.com")
        inv, raw = invite_member(restaurant=r, inviter=owner,
                                 email="new@example.com", roles=["chef"])
        accept_invitation(raw_token=raw, user=new_user)
        with pytest.raises(Conflict):
            revoke_invitation(invitation=inv)

    def test_re_accept_reactivates_removed_member(self):
        owner = UserFactory()
        r = create_restaurant(owner=owner, name="X")
        new_user = UserFactory(email="new@example.com")
        # First accept
        _inv1, raw1 = invite_member(restaurant=r, inviter=owner,
                                    email="new@example.com", roles=["chef"])
        accept_invitation(raw_token=raw1, user=new_user)
        # Remove
        member = RestaurantMember.objects.get(restaurant=r, user=new_user)
        remove_member(member=member)
        member.refresh_from_db()
        assert member.status == "removed"
        # Re-invite + accept should reactivate
        _inv2, raw2 = invite_member(restaurant=r, inviter=owner,
                                    email="new@example.com", roles=["server"])
        m2 = accept_invitation(raw_token=raw2, user=new_user)
        assert m2.status == "active"
        assert m2.roles == ["server"]


@pytest.mark.django_db
class TestMembership:
    def test_remove_owner_blocked(self):
        owner = UserFactory()
        r = create_restaurant(owner=owner, name="X")
        owner_member = RestaurantMember.objects.get(restaurant=r, user=owner)
        with pytest.raises(Conflict):
            remove_member(member=owner_member)

    def test_update_member_roles_requires_non_empty(self):
        owner = UserFactory()
        r = create_restaurant(owner=owner, name="X")
        new_user = UserFactory()
        member = RestaurantMember.objects.create(
            restaurant=r, user=new_user, roles=["chef"], status="active",
        )
        with pytest.raises(ValidationError):
            update_member_roles(member=member, roles=[])

    def test_demoting_owner_blocked(self):
        owner = UserFactory()
        r = create_restaurant(owner=owner, name="X")
        owner_member = RestaurantMember.objects.get(restaurant=r, user=owner)
        with pytest.raises(Conflict):
            update_member_roles(member=owner_member, roles=["chef"])
