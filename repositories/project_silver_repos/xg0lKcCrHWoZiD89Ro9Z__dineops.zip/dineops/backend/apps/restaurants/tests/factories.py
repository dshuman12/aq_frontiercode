import factory
from factory.django import DjangoModelFactory

from apps.accounts.tests.factories import UserFactory
from apps.restaurants.models import Restaurant, RestaurantMember


class RestaurantFactory(DjangoModelFactory):
    class Meta:
        model = Restaurant
        django_get_or_create = ("slug",)

    name = factory.Sequence(lambda n: f"Restaurant {n}")
    slug = factory.Sequence(lambda n: f"restaurant-{n}")
    kind = "full_service"
    owner = factory.SubFactory(UserFactory)
    timezone = "UTC"
    currency = "USD"


class RestaurantMemberFactory(DjangoModelFactory):
    class Meta:
        model = RestaurantMember

    restaurant = factory.SubFactory(RestaurantFactory)
    user = factory.SubFactory(UserFactory)
    roles = ["owner"]
    status = "active"
