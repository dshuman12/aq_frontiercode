import pytest

from apps.restaurants.models import Restaurant, RestaurantMember
from apps.restaurants.services import slugify_unique
from apps.restaurants.tests.factories import RestaurantFactory


@pytest.mark.django_db
def test_slugify_unique_appends_suffix_when_taken():
    RestaurantFactory(name="Mario's Pizza", slug="marios-pizza")
    s = slugify_unique("Mario's Pizza")
    assert s == "marios-pizza-1"


@pytest.mark.django_db
def test_slugify_handles_empty_input():
    assert slugify_unique("!@#$%") == "restaurant"


@pytest.mark.django_db
def test_member_unique_constraint(django_user_model):
    r = RestaurantFactory()
    u = r.owner  # already linked via owner
    # second member with same user/restaurant should fail
    with pytest.raises(Exception):
        RestaurantMember.objects.create(restaurant=r, user=u, roles=["chef"])
