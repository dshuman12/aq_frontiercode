import pytest
from rest_framework.test import APIClient

from apps.accounts.tests.factories import UserFactory
from apps.restaurants.tests.factories import RestaurantFactory, RestaurantMemberFactory


@pytest.fixture
def authed():
    user = UserFactory()
    client = APIClient()
    client.force_authenticate(user=user)
    return client, user


@pytest.mark.django_db
class TestRestaurantViews:
    def test_create_returns_201_and_full_payload(self, authed):
        client, user = authed
        resp = client.post("/api/restaurants/", {
            "name": "New Spot", "kind": "cafe",
            "timezone": "America/Los_Angeles",
        }, format="json")
        assert resp.status_code == 201
        assert resp.data["restaurant"]["slug"] == "new-spot"
        assert "owner" in resp.data["restaurant"]["my_roles"]

    def test_list_only_my_restaurants(self, authed):
        client, user = authed
        my = RestaurantFactory(owner=user)
        RestaurantMemberFactory(restaurant=my, user=user, roles=["owner"])
        # someone else's restaurant
        other_user = UserFactory()
        RestaurantFactory(owner=other_user, name="Other", slug="other")
        resp = client.get("/api/restaurants/")
        slugs = [r["slug"] for r in resp.data["results"]]
        assert my.slug in slugs
        assert "other" not in slugs

    def test_get_detail_403_for_non_member(self, authed):
        client, _ = authed
        other = UserFactory()
        r = RestaurantFactory(owner=other, name="Other", slug="other-x")
        resp = client.get(f"/api/restaurants/{r.id}/")
        assert resp.status_code == 403

    def test_patch_blocks_chef(self, authed):
        client, user = authed
        owner = UserFactory()
        r = RestaurantFactory(owner=owner, name="X", slug="x-1")
        RestaurantMemberFactory(restaurant=r, user=user, roles=["chef"])
        resp = client.patch(f"/api/restaurants/{r.id}/", {
            "name": "Tried-to-rename",
        }, format="json")
        assert resp.status_code == 403


@pytest.mark.django_db
class TestInviteEndpoints:
    def test_owner_invite_creates_pending(self, authed):
        client, user = authed
        r = RestaurantFactory(owner=user, name="A", slug="a")
        RestaurantMemberFactory(restaurant=r, user=user, roles=["owner"])
        resp = client.post(f"/api/restaurants/{r.id}/invite/", {
            "email": "new@example.com", "roles": ["chef"],
        }, format="json")
        assert resp.status_code == 201
        assert resp.data["invitation"]["email"] == "new@example.com"

    def test_chef_cannot_invite(self, authed):
        client, user = authed
        owner = UserFactory()
        r = RestaurantFactory(owner=owner, name="A", slug="a-2")
        RestaurantMemberFactory(restaurant=r, user=user, roles=["chef"])
        resp = client.post(f"/api/restaurants/{r.id}/invite/", {
            "email": "new@example.com", "roles": ["server"],
        }, format="json")
        assert resp.status_code == 403


@pytest.mark.django_db
class TestMemberEndpoints:
    def test_list_returns_active_members(self, authed):
        client, user = authed
        r = RestaurantFactory(owner=user, name="X", slug="x-3")
        RestaurantMemberFactory(restaurant=r, user=user, roles=["owner"])
        other = UserFactory()
        RestaurantMemberFactory(restaurant=r, user=other, roles=["chef"])
        # add a removed one too — should not appear
        ghost = UserFactory()
        RestaurantMemberFactory(restaurant=r, user=ghost, roles=["chef"], status="removed")
        resp = client.get(f"/api/restaurants/{r.id}/members/")
        assert resp.status_code == 200
        emails = [m["user"]["email"] for m in resp.data["results"]]
        assert ghost.email not in emails
