"""Smoke tests for restaurant model + member helpers."""
from decimal import Decimal

import pytest

from apps.accounts.models import User
from apps.restaurants.models import Restaurant, RestaurantMember


pytestmark = pytest.mark.django_db


def test_restaurant_str_repr():
    o = User.objects.create_user(email="o@x.com", password="pwpwpwpw")
    r = Restaurant.objects.create(name="Hello", slug="hello", owner=o)
    assert "Hello" in str(r)


def test_member_uniqueness():
    from django.db import IntegrityError
    o = User.objects.create_user(email="o@x.com", password="pwpwpwpw")
    r = Restaurant.objects.create(name="R", slug="r", owner=o)
    RestaurantMember.objects.create(
        restaurant=r, user=o, roles=["owner"], status="active",
    )
    with pytest.raises(IntegrityError):
        RestaurantMember.objects.create(
            restaurant=r, user=o, roles=["server"], status="active",
        )
