"""Smoke that auto-creating a member when a restaurant is created (if any
such signal exists) is well-behaved."""
import pytest

from apps.accounts.models import User
from apps.restaurants.models import Restaurant, RestaurantMember


pytestmark = pytest.mark.django_db


def test_restaurant_create_does_not_blow_up():
    o = User.objects.create_user(email="o@x.com", password="pwpwpwpw")
    Restaurant.objects.create(name="R", slug="r", owner=o)
