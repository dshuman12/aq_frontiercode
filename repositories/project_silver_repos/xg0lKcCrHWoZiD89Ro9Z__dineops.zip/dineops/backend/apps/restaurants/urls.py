from django.urls import path

from . import views

app_name = "restaurants"

urlpatterns = [
    path("", views.RestaurantListCreate.as_view(), name="list-create"),
    path("invitations/accept/", views.InviteAcceptView.as_view(), name="accept-invite"),
    path("<uuid:restaurant_id>/", views.RestaurantDetail.as_view(), name="detail"),
    path("<uuid:restaurant_id>/members/", views.MemberListView.as_view(), name="members"),
    path("<uuid:restaurant_id>/members/<uuid:member_id>/",
         views.MemberDetailView.as_view(), name="member-detail"),
    path("<uuid:restaurant_id>/invite/", views.InviteCreateView.as_view(), name="invite"),
    path("<uuid:restaurant_id>/roles/", views.RoleListCreateView.as_view(), name="roles"),
]
