"""One-off ops command — promote an existing user to be owner of a restaurant.
Useful when transferring ownership."""
from __future__ import annotations

from django.core.management.base import BaseCommand
from django.db import transaction

from apps.accounts.models import User
from apps.restaurants.models import Restaurant, RestaurantMember


class Command(BaseCommand):
    help = "Transfer ownership: --restaurant <slug> --to <email>"

    def add_arguments(self, parser):
        parser.add_argument("--restaurant", required=True)
        parser.add_argument("--to", required=True)

    @transaction.atomic
    def handle(self, *args, restaurant, to, **options):
        rest = Restaurant.objects.filter(slug=restaurant).first()
        if not rest:
            self.stderr.write(f"No restaurant '{restaurant}'.")
            return
        new_owner = User.objects.filter(email=to).first()
        if not new_owner:
            self.stderr.write(f"No user '{to}'.")
            return
        old_owner = rest.owner
        rest.owner = new_owner
        rest.save()
        # Make sure the new owner has the owner role
        m, _ = RestaurantMember.objects.get_or_create(
            restaurant=rest, user=new_owner,
            defaults={"roles": ["owner"], "status": "active"},
        )
        roles = set(m.roles or [])
        roles.add("owner")
        m.roles = sorted(roles)
        m.status = "active"
        m.save()
        self.stdout.write(self.style.SUCCESS(
            f"Transferred '{rest.name}' from {old_owner.email} to {new_owner.email}.",
        ))
