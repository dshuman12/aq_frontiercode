from __future__ import annotations

import re
import uuid
from datetime import timedelta

from django.db import transaction
from django.utils import timezone
from django.utils.text import slugify as django_slugify

from apps.accounts.models import EmailToken
from apps.common.exceptions import Conflict, NotFound, ValidationError

from .models import Invitation, Restaurant, RestaurantMember


def slugify_unique(name: str) -> str:
    """Slugify a name and ensure uniqueness across `Restaurant.slug`."""
    base = django_slugify(name)[:60] or "restaurant"
    slug = base
    suffix = 0
    while Restaurant.objects.filter(slug=slug).exists():
        suffix += 1
        slug = f"{base}-{suffix}"
    return slug


@transaction.atomic
def create_restaurant(*, owner, name: str, kind: str = "full_service",
                      contact_email: str = "", contact_phone: str = "",
                      timezone_: str = "UTC", currency: str = "USD") -> Restaurant:
    if not name or len(name.strip()) < 2:
        raise ValidationError("invalid_name", "Restaurant name must be at least 2 characters.")
    restaurant = Restaurant.objects.create(
        name=name.strip(),
        slug=slugify_unique(name),
        kind=kind,
        owner=owner,
        contact_email=contact_email or owner.email,
        contact_phone=contact_phone,
        timezone=timezone_ or owner.timezone or "UTC",
        currency=currency,
    )
    RestaurantMember.objects.create(
        restaurant=restaurant,
        user=owner,
        roles=["owner"],
        status=RestaurantMember.STATUS_ACTIVE,
    )
    return restaurant


@transaction.atomic
def update_restaurant(*, restaurant: Restaurant, **fields) -> Restaurant:
    allowed = {
        "name", "kind", "contact_email", "contact_phone", "timezone", "currency",
        "default_tax_percent", "default_service_charge_percent",
        "branding_logo_url", "branding_primary_color",
    }
    for k, v in fields.items():
        if k in allowed and v is not None:
            setattr(restaurant, k, v)
    restaurant.save()
    return restaurant


@transaction.atomic
def invite_member(*, restaurant: Restaurant, inviter, email: str,
                  roles: list[str], location_ids: list | None = None,
                  ttl_days: int = 14) -> tuple[Invitation, str]:
    """Returns (invitation, raw_token). The raw token is shown to the inviter
    once and emailed to the invitee."""
    if not roles:
        roles = ["viewer"]
    raw = EmailToken.make_raw_token(20)
    inv = Invitation.objects.create(
        restaurant=restaurant,
        email=email.lower(),
        roles=roles,
        location_ids=location_ids or [],
        invited_by=inviter,
        token_hash=EmailToken.hash_token(raw),
        expires_at=timezone.now() + timedelta(days=ttl_days),
    )
    return inv, raw


@transaction.atomic
def accept_invitation(*, raw_token: str, user) -> RestaurantMember:
    inv = Invitation.objects.filter(
        token_hash=EmailToken.hash_token(raw_token),
        accepted_at__isnull=True,
        revoked_at__isnull=True,
    ).first()
    if not inv or inv.expires_at < timezone.now():
        raise NotFound("invitation_invalid_or_expired")
    if inv.email != user.email.lower():
        raise ValidationError("email_mismatch", "Invitation is for a different email.")
    member, created = RestaurantMember.objects.get_or_create(
        restaurant=inv.restaurant,
        user=user,
        defaults={
            "roles": inv.roles,
            "location_ids": inv.location_ids,
            "invited_by": inv.invited_by,
            "status": RestaurantMember.STATUS_ACTIVE,
        },
    )
    if not created and member.status != RestaurantMember.STATUS_ACTIVE:
        member.status = RestaurantMember.STATUS_ACTIVE
        member.roles = inv.roles
        member.location_ids = inv.location_ids
        member.save(update_fields=["status", "roles", "location_ids"])
    inv.accepted_at = timezone.now()
    inv.save(update_fields=["accepted_at"])
    return member


def revoke_invitation(*, invitation: Invitation) -> Invitation:
    if invitation.accepted_at:
        raise Conflict("already_accepted")
    invitation.revoked_at = timezone.now()
    invitation.save(update_fields=["revoked_at"])
    return invitation


def remove_member(*, member: RestaurantMember):
    if "owner" in (member.roles or []):
        raise Conflict("cannot_remove_owner")
    member.status = RestaurantMember.STATUS_REMOVED
    member.save(update_fields=["status"])
    return member


def update_member_roles(*, member: RestaurantMember, roles: list[str],
                        custom_permissions: list[str] | None = None,
                        location_ids: list | None = None) -> RestaurantMember:
    if not roles:
        raise ValidationError("roles_required")
    if "owner" not in roles and "owner" in (member.roles or []):
        # transferring ownership requires explicit ownership transfer
        raise Conflict("cannot_demote_owner")
    member.roles = roles
    if custom_permissions is not None:
        member.custom_permissions = custom_permissions
    if location_ids is not None:
        member.location_ids = location_ids
    member.save(update_fields=["roles", "custom_permissions", "location_ids"])
    return member
