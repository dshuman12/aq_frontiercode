from django.urls import path

from . import views

app_name = "notifications"

urlpatterns = [
    path("inbox/", views.InboxView.as_view(), name="inbox"),
    path("inbox/<uuid:notification_id>/read/",
         views.MarkReadView.as_view(), name="mark-read"),
    path("channels/", views.ChannelListCreate.as_view(), name="channels"),
    path("channels/<uuid:channel_id>/",
         views.ChannelDetail.as_view(), name="channel-detail"),
    path("preferences/", views.PreferencesView.as_view(), name="preferences"),
]
