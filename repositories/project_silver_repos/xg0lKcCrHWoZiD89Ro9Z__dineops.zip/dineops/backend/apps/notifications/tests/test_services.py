from __future__ import annotations

from datetime import timedelta
from decimal import Decimal

import pytest

from apps.accounts.models import User
from apps.ingredients.models import Ingredient
from apps.inventory.models import LowStockAlert
from apps.inventory.services import create_inventory_item
from apps.locations.models import Location
from apps.notifications.models import (
    Notification, NotificationChannel, NotificationPreference,
    NotificationType,
)
from apps.notifications.services import (
    channels_for, dispatch_notification, fan_out_low_stock_alert,
    queue_notification,
)
from apps.restaurants.models import Restaurant, RestaurantMember


pytestmark = pytest.mark.django_db


def _u(email):
    return User.objects.create_user(email=email, password="pwpwpwpw")


class TestQueueNotification:
    def test_queues(self):
        u = _u("a@x.com")
        n = queue_notification(
            user=u, kind=NotificationType.ANNOUNCEMENT,
            title="Hello", body="World", priority=2,
        )
        assert n.status == "queued"
        assert n.title == "Hello"


class TestChannels:
    def test_returns_enabled_only(self):
        u = _u("a@x.com")
        NotificationChannel.objects.create(
            user=u, kind="email", address="a@x.com", is_enabled=True,
        )
        NotificationChannel.objects.create(
            user=u, kind="sms", address="+1", is_enabled=False,
        )
        result = channels_for(u, NotificationType.ANNOUNCEMENT)
        assert len(result) == 1
        assert result[0].kind == "email"

    def test_respects_preferences(self):
        u = _u("a@x.com")
        NotificationChannel.objects.create(
            user=u, kind="email", address="a@x.com",
        )
        NotificationPreference.objects.create(
            user=u, kind=NotificationType.ANNOUNCEMENT,
            channel="email", enabled=False,
        )
        result = channels_for(u, NotificationType.ANNOUNCEMENT)
        assert result == []

    def test_default_opt_in(self):
        # Without an explicit preference, channel is opted-in by default
        u = _u("a@x.com")
        NotificationChannel.objects.create(user=u, kind="in_app", address="")
        result = channels_for(u, NotificationType.SHIFT_REMINDER)
        assert len(result) == 1


class TestDispatch:
    def test_marks_sent(self):
        u = _u("a@x.com")
        NotificationChannel.objects.create(
            user=u, kind="email", address="a@x.com",
        )
        n = queue_notification(user=u, kind=NotificationType.ANNOUNCEMENT,
                               title="Hello")
        dispatch_notification(n)
        n.refresh_from_db()
        assert n.status == "sent"
        assert "email" in n.via_channels

    def test_no_channels_fails(self):
        u = _u("a@x.com")
        n = queue_notification(user=u, kind=NotificationType.ANNOUNCEMENT,
                               title="X")
        dispatch_notification(n)
        n.refresh_from_db()
        assert n.status == "failed"


class TestFanOutLowStock:
    def test_targets_managers_and_chef(self):
        owner = _u("o@x.com")
        rest = Restaurant.objects.create(name="R", slug="r", owner=owner)
        loc = Location.objects.create(
            restaurant=rest, name="Main", slug="main", accepts_dine_in=True,
        )
        # Add members in various roles
        chef = _u("chef@x.com")
        server = _u("srv@x.com")
        gm = _u("gm@x.com")
        for u, role in [(owner, "owner"), (chef, "chef"),
                        (server, "server"), (gm, "general_manager")]:
            RestaurantMember.objects.create(
                restaurant=rest, user=u, roles=[role], status="active",
            )

        ing = Ingredient.objects.create(restaurant=rest, name="X")
        item = create_inventory_item(
            restaurant=rest, location=loc, ingredient=ing,
            opening_quantity=Decimal("0"),
        )
        alert = LowStockAlert.objects.create(
            item=item, triggered_quantity=Decimal("0"),
            reorder_point_at_alert=Decimal("10"),
        )
        fan_out_low_stock_alert(alert)
        # owner, chef, gm = 3 notifications; server skipped
        assert Notification.objects.filter(
            kind=NotificationType.LOW_STOCK,
        ).count() == 3
