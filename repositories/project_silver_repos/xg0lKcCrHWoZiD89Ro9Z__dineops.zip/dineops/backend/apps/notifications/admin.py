from django.contrib import admin

from .models import (
    Notification, NotificationChannel, NotificationPreference,
)


@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ("title", "user", "kind", "status", "priority", "sent_at")
    list_filter = ("status", "kind", "priority")
    search_fields = ("title", "body", "user__email")
    readonly_fields = ("sent_at", "read_at", "via_channels", "failure_reason")


@admin.register(NotificationChannel)
class ChannelAdmin(admin.ModelAdmin):
    list_display = ("user", "kind", "address", "is_verified", "is_enabled")
    list_filter = ("kind", "is_verified", "is_enabled")


@admin.register(NotificationPreference)
class PreferenceAdmin(admin.ModelAdmin):
    list_display = ("user", "kind", "channel", "enabled")
    list_filter = ("kind", "channel", "enabled")
