from __future__ import annotations

import logging
from typing import Iterable

from django.db import transaction
from django.utils import timezone

from .models import (
    Notification, NotificationChannel, NotificationPreference,
    NotificationType,
)


logger = logging.getLogger("dineops.notifications")


@transaction.atomic
def queue_notification(*, user, kind: str, title: str, body: str = "",
                       payload: dict | None = None, priority: int = 2,
                       restaurant=None,
                       scheduled_for=None) -> Notification:
    """Create a notification row in 'queued' state. The Celery task
    `notifications.dispatch_pending` handles delivery."""
    return Notification.objects.create(
        user=user, restaurant=restaurant, kind=kind, title=title, body=body,
        payload=payload or {}, priority=priority,
        scheduled_for=scheduled_for,
    )


def channels_for(user, kind: str) -> list[NotificationChannel]:
    """Resolve which user channels should receive a notification of `kind`,
    honoring preferences."""
    prefs = {
        (p.kind, p.channel): p.enabled
        for p in NotificationPreference.objects.filter(user=user, kind=kind)
    }
    out = []
    for ch in NotificationChannel.objects.filter(user=user, is_enabled=True):
        if prefs.get((kind, ch.kind), True):  # default opt-in
            out.append(ch)
    return out


@transaction.atomic
def dispatch_notification(notification: Notification) -> Notification:
    """Send a queued notification through each of the user's enabled
    channels, then mark it as sent.

    For email/SMS/push we'd call out to providers; here we just record
    the channels we used and assume success. Failures across all channels
    flip status to 'failed'."""
    channels = channels_for(notification.user, notification.kind)
    if not channels:
        notification.status = "failed"
        notification.failure_reason = "no_channels"
        notification.save()
        return notification

    via = []
    for ch in channels:
        try:
            _send_via_channel(notification, ch)
            via.append(ch.kind)
        except Exception as e:  # noqa: BLE001
            logger.warning("notification %s via %s failed: %s",
                           notification.id, ch.kind, e)
    notification.via_channels = via
    notification.status = "sent" if via else "failed"
    notification.sent_at = timezone.now()
    if not via:
        notification.failure_reason = "all_channels_failed"
    notification.save(update_fields=[
        "status", "sent_at", "via_channels", "failure_reason", "updated_at",
    ])
    return notification


def _send_via_channel(notification: Notification, channel: NotificationChannel):
    """In a real install this would call SES, Twilio, FCM, etc. For now we
    log and rely on the in_app channel via the websocket consumer."""
    if channel.kind == "email":
        logger.info("[email→%s] %s", channel.address, notification.title)
    elif channel.kind == "sms":
        logger.info("[sms→%s] %s", channel.address, notification.title)
    elif channel.kind == "push":
        logger.info("[push→%s] %s", channel.address, notification.title)
    elif channel.kind == "in_app":
        # Delivered via WebSocket consumer + DB row. Nothing else to do.
        pass
    elif channel.kind == "webhook":
        # In production: requests.post(channel.address, json=...)
        logger.info("[webhook→%s] %s", channel.address, notification.title)


def mark_read(*, notification: Notification) -> Notification:
    notification.mark_read()
    return notification


def fan_out_low_stock_alert(alert) -> int:
    """Open a notification for every user with the inventory_manager role on
    the alert's restaurant."""
    from apps.restaurants.models import RestaurantMember
    item = alert.item
    members = RestaurantMember.objects.filter(
        restaurant=item.restaurant, status="active",
    ).select_related("user")
    target_roles = {"owner", "general_manager", "inventory_manager", "chef"}
    sent = 0
    for m in members:
        if not (set(m.roles or []) & target_roles):
            continue
        queue_notification(
            user=m.user,
            restaurant=item.restaurant,
            kind=NotificationType.LOW_STOCK,
            title=f"Low stock: {item.ingredient.name}",
            body=(f"{item.quantity_on_hand} {item.ingredient.base_unit} on "
                  f"hand at {item.location.name} (reorder at "
                  f"{item.reorder_point})."),
            payload={
                "alert_id": str(alert.id),
                "item_id": str(item.id),
                "ingredient_name": item.ingredient.name,
            },
            priority=1,
        )
        sent += 1
    return sent
