from __future__ import annotations

import uuid

from django.conf import settings
from django.db import models

from apps.common.models import TimeStampedModel


class NotificationChannel(TimeStampedModel):
    """Per-user delivery preferences (email, sms, push, in_app)."""

    KIND_CHOICES = [
        ("email", "Email"),
        ("sms", "SMS"),
        ("push", "Push"),
        ("in_app", "In-app"),
        ("webhook", "Webhook"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="notification_channels",
    )
    kind = models.CharField(max_length=20, choices=KIND_CHOICES)
    address = models.CharField(max_length=300, blank=True,
                               help_text="Email/phone/push token/url.")
    is_verified = models.BooleanField(default=False)
    is_enabled = models.BooleanField(default=True)
    notes = models.CharField(max_length=200, blank=True)

    class Meta:
        ordering = ["user", "kind"]
        constraints = [
            models.UniqueConstraint(
                fields=["user", "kind", "address"],
                name="unique_user_channel_address",
            ),
        ]


class NotificationType(models.TextChoices):
    LOW_STOCK = "low_stock", "Low stock"
    EXPIRING_LOT = "expiring_lot", "Expiring lot"
    SHIFT_REMINDER = "shift_reminder", "Shift reminder"
    ORDER_READY = "order_ready", "Order ready"
    PO_RECEIVED = "po_received", "Purchase order received"
    PASSWORD_RESET = "password_reset", "Password reset"
    DAILY_DIGEST = "daily_digest", "Daily digest"
    INVITATION = "invitation", "Invitation"
    INCIDENT = "incident", "Incident"
    ANNOUNCEMENT = "announcement", "Announcement"


class Notification(TimeStampedModel):
    """A delivered (or pending) notification for a user. Stores the
    payload so we can re-render in the in-app inbox or re-send."""

    STATUS_CHOICES = [
        ("queued", "Queued"),
        ("sent", "Sent"),
        ("read", "Read"),
        ("failed", "Failed"),
        ("dismissed", "Dismissed"),
    ]

    PRIORITY_CHOICES = [
        (0, "Critical"),
        (1, "High"),
        (2, "Normal"),
        (3, "Low"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="notifications",
    )
    restaurant = models.ForeignKey(
        "restaurants.Restaurant", on_delete=models.CASCADE,
        related_name="notifications", null=True, blank=True,
    )
    kind = models.CharField(max_length=40, choices=NotificationType.choices)
    title = models.CharField(max_length=200)
    body = models.TextField(blank=True)
    payload = models.JSONField(default=dict, blank=True)

    priority = models.PositiveSmallIntegerField(choices=PRIORITY_CHOICES, default=2)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="queued")
    scheduled_for = models.DateTimeField(null=True, blank=True)
    sent_at = models.DateTimeField(null=True, blank=True)
    read_at = models.DateTimeField(null=True, blank=True)
    failure_reason = models.CharField(max_length=300, blank=True)
    via_channels = models.JSONField(default=list, blank=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["user", "status"]),
            models.Index(fields=["kind"]),
            models.Index(fields=["scheduled_for"]),
        ]

    def mark_read(self):
        from django.utils import timezone
        if self.status != "read":
            self.status = "read"
            self.read_at = timezone.now()
            self.save(update_fields=["status", "read_at", "updated_at"])


class NotificationPreference(TimeStampedModel):
    """Per-user opt-in/out per notification type per channel."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="notification_preferences",
    )
    kind = models.CharField(max_length=40, choices=NotificationType.choices)
    channel = models.CharField(
        max_length=20, choices=NotificationChannel.KIND_CHOICES,
    )
    enabled = models.BooleanField(default=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["user", "kind", "channel"],
                name="unique_user_kind_channel_pref",
            ),
        ]
