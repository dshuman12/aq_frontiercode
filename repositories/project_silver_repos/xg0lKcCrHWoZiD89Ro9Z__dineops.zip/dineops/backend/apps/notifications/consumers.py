from __future__ import annotations

from channels.db import database_sync_to_async
from channels.generic.websocket import AsyncJsonWebsocketConsumer

from .models import Notification
from .serializers import NotificationSerializer


class NotificationConsumer(AsyncJsonWebsocketConsumer):
    """Per-user WebSocket — sees inbox events as they're queued."""

    async def connect(self):
        user = self.scope.get("user")
        if not user or not user.is_authenticated:
            await self.close(code=4001)
            return
        self.user_id = str(user.id)
        self.group = f"notifications.{self.user_id}"
        await self.channel_layer.group_add(self.group, self.channel_name)
        await self.accept()
        unread = await self._unread_count(user.id)
        await self.send_json({"type": "hello", "unread_count": unread})

    async def disconnect(self, code):
        if hasattr(self, "group"):
            await self.channel_layer.group_discard(self.group, self.channel_name)

    async def receive_json(self, content, **kwargs):
        if content.get("action") == "mark_read":
            await self._mark_read(content["notification_id"])

    async def notification_event(self, event):
        await self.send_json({
            "type": "notification",
            "notification": event["notification"],
        })

    @database_sync_to_async
    def _unread_count(self, user_id):
        return Notification.objects.filter(
            user_id=user_id, status__in=("queued", "sent"),
            read_at__isnull=True,
        ).count()

    @database_sync_to_async
    def _mark_read(self, notification_id):
        n = Notification.objects.filter(
            id=notification_id, user_id=self.user_id,
        ).first()
        if n:
            n.mark_read()


def push_notification_to_user(notification: Notification) -> None:
    """Broadcast a notification to the user's WebSocket group, if one exists."""
    from asgiref.sync import async_to_sync
    from channels.layers import get_channel_layer
    layer = get_channel_layer()
    if not layer:
        return
    async_to_sync(layer.group_send)(
        f"notifications.{notification.user_id}",
        {
            "type": "notification.event",
            "notification": NotificationSerializer(notification).data,
        },
    )
