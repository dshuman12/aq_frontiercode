from __future__ import annotations

from celery import shared_task
from django.utils import timezone

from .models import Notification
from .services import dispatch_notification


@shared_task(name="notifications.dispatch_pending")
def dispatch_pending() -> dict:
    """Send out queued notifications whose scheduled_for is in the past
    (or unset). Run every minute."""
    now = timezone.now()
    qs = Notification.objects.filter(status="queued").filter(
        models_filter_or_null(now)
    )
    sent = 0
    for n in qs[:200]:
        dispatch_notification(n)
        sent += 1
    return {"dispatched": sent}


def models_filter_or_null(now):
    from django.db.models import Q
    return Q(scheduled_for__lte=now) | Q(scheduled_for__isnull=True)
