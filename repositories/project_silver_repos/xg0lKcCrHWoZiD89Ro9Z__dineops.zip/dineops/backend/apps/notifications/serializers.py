from __future__ import annotations

from rest_framework import serializers

from .models import Notification, NotificationChannel, NotificationPreference


class NotificationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Notification
        fields = ["id", "user", "restaurant", "kind",
                  "title", "body", "payload", "priority",
                  "status", "scheduled_for", "sent_at", "read_at",
                  "via_channels", "failure_reason", "created_at"]


class ChannelSerializer(serializers.ModelSerializer):
    class Meta:
        model = NotificationChannel
        fields = ["id", "user", "kind", "address",
                  "is_verified", "is_enabled", "notes"]


class CreateChannelSerializer(serializers.Serializer):
    kind = serializers.ChoiceField(choices=NotificationChannel.KIND_CHOICES)
    address = serializers.CharField(max_length=300)


class PreferenceSerializer(serializers.ModelSerializer):
    class Meta:
        model = NotificationPreference
        fields = ["id", "user", "kind", "channel", "enabled"]


class SetPreferenceSerializer(serializers.Serializer):
    kind = serializers.CharField()
    channel = serializers.ChoiceField(choices=NotificationChannel.KIND_CHOICES)
    enabled = serializers.BooleanField()
