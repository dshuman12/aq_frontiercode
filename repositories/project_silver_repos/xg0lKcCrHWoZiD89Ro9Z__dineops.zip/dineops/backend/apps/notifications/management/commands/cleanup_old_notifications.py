"""Delete dismissed/sent notifications older than N days."""
from __future__ import annotations

from datetime import timedelta

from django.core.management.base import BaseCommand
from django.utils import timezone

from apps.notifications.models import Notification


class Command(BaseCommand):
    help = "Cleanup old notifications."

    def add_arguments(self, parser):
        parser.add_argument("--days", type=int, default=180)

    def handle(self, *args, days, **options):
        cutoff = timezone.now() - timedelta(days=days)
        qs = Notification.objects.filter(
            status__in=("read", "dismissed", "sent"),
            created_at__lt=cutoff,
        )
        n = qs.count()
        qs.delete()
        self.stdout.write(self.style.SUCCESS(
            f"Deleted {n} notifications older than {days} days.",
        ))
