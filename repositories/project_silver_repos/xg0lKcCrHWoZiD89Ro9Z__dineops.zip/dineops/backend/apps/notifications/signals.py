from django.db.models.signals import post_save
from django.dispatch import receiver

from .consumers import push_notification_to_user
from .models import Notification


@receiver(post_save, sender=Notification)
def fanout_notification(sender, instance: Notification, created, **kwargs):
    if created or kwargs.get("update_fields") in (None,):
        try:
            push_notification_to_user(instance)
        except Exception:
            pass
