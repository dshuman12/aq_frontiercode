from __future__ import annotations

from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common.exceptions import NotFound

from .models import Notification, NotificationChannel, NotificationPreference
from .serializers import (
    ChannelSerializer, CreateChannelSerializer, NotificationSerializer,
    PreferenceSerializer, SetPreferenceSerializer,
)


class InboxView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request):
        qs = Notification.objects.filter(user=request.user).order_by(
            "-created_at",
        )[:200]
        unread = Notification.objects.filter(
            user=request.user, status__in=("queued", "sent"),
            read_at__isnull=True,
        ).count()
        return Response({
            "results": NotificationSerializer(qs, many=True).data,
            "unread_count": unread,
        })


class MarkReadView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, notification_id):
        n = Notification.objects.filter(
            id=notification_id, user=request.user,
        ).first()
        if not n:
            raise NotFound()
        n.mark_read()
        return Response({"notification": NotificationSerializer(n).data})


class ChannelListCreate(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request):
        qs = NotificationChannel.objects.filter(user=request.user).order_by("kind")
        return Response({"results": ChannelSerializer(qs, many=True).data})

    def post(self, request):
        s = CreateChannelSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        ch = NotificationChannel.objects.create(
            user=request.user, **s.validated_data,
        )
        return Response({"channel": ChannelSerializer(ch).data}, status=201)


class ChannelDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def patch(self, request, channel_id):
        ch = NotificationChannel.objects.filter(
            id=channel_id, user=request.user,
        ).first()
        if not ch:
            raise NotFound()
        for k in ("is_enabled", "is_verified", "notes"):
            if k in request.data:
                setattr(ch, k, request.data[k])
        ch.save()
        return Response({"channel": ChannelSerializer(ch).data})

    def delete(self, request, channel_id):
        ch = NotificationChannel.objects.filter(
            id=channel_id, user=request.user,
        ).first()
        if not ch:
            raise NotFound()
        ch.delete()
        return Response({"ok": True})


class PreferencesView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request):
        qs = NotificationPreference.objects.filter(user=request.user)
        return Response({"results": PreferenceSerializer(qs, many=True).data})

    def post(self, request):
        s = SetPreferenceSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        pref, _ = NotificationPreference.objects.update_or_create(
            user=request.user,
            kind=s.validated_data["kind"],
            channel=s.validated_data["channel"],
            defaults={"enabled": s.validated_data["enabled"]},
        )
        return Response({"preference": PreferenceSerializer(pref).data})
