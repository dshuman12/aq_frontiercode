"""Reconcile our `Payment.status=captured` rows against Stripe's view of the
world. Anything missing on either side is reported."""
from __future__ import annotations

from django.core.management.base import BaseCommand

from apps.payments.models import Payment


class Command(BaseCommand):
    help = "Compare DineOps payments to Stripe (placeholder, reads metadata only)."

    def add_arguments(self, parser):
        parser.add_argument("--restaurant", required=True)

    def handle(self, *args, restaurant, **options):
        # Real impl would call stripe.PaymentIntent.list(...) and diff.
        # This stub catches the easy local issues.
        missing_intent = Payment.objects.filter(
            restaurant__slug=restaurant, method="stripe",
            status="captured",
            stripe_payment_intent_id="",
        )
        if missing_intent.exists():
            self.stderr.write(
                f"WARN: {missing_intent.count()} captured Stripe payments "
                "have no payment_intent_id.",
            )

        # Charge IDs that should not be empty for captured Stripe payments
        missing_charge = Payment.objects.filter(
            restaurant__slug=restaurant, method="stripe",
            status="captured",
            stripe_charge_id="",
        )
        if missing_charge.exists():
            self.stderr.write(
                f"WARN: {missing_charge.count()} captured Stripe payments "
                "have no charge_id (they cannot be refunded by us).",
            )

        self.stdout.write(self.style.SUCCESS("Reconciliation pass complete."))
