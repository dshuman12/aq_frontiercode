from __future__ import annotations

from rest_framework import serializers

from .models import Payment, Refund, TipDistribution


class PaymentSerializer(serializers.ModelSerializer):
    cashier_email = serializers.CharField(source="cashier.email", read_only=True)

    class Meta:
        model = Payment
        fields = [
            "id", "restaurant", "order", "method", "status",
            "amount", "tip_amount", "surcharge_amount", "currency",
            "cashier", "cashier_email", "processed_at",
            "stripe_payment_intent_id", "stripe_charge_id",
            "card_brand", "card_last4", "receipt_url",
            "failure_reason", "notes",
        ]
        read_only_fields = ["id", "status", "processed_at",
                            "stripe_payment_intent_id", "stripe_charge_id",
                            "receipt_url"]


class CashPaymentSerializer(serializers.Serializer):
    order_id = serializers.UUIDField()
    amount = serializers.DecimalField(max_digits=12, decimal_places=2)
    tip = serializers.DecimalField(
        max_digits=12, decimal_places=2, default=0,
    )


class CardPaymentSerializer(serializers.Serializer):
    order_id = serializers.UUIDField()
    amount = serializers.DecimalField(max_digits=12, decimal_places=2)
    tip = serializers.DecimalField(
        max_digits=12, decimal_places=2, default=0,
    )
    card_brand = serializers.CharField(required=False, allow_blank=True)
    card_last4 = serializers.CharField(required=False, allow_blank=True, max_length=4)


class StripeBeginSerializer(serializers.Serializer):
    order_id = serializers.UUIDField()
    amount = serializers.DecimalField(max_digits=12, decimal_places=2)
    tip = serializers.DecimalField(max_digits=12, decimal_places=2, default=0)


class StripeConfirmSerializer(serializers.Serializer):
    payment_id = serializers.UUIDField()


class RefundSerializer(serializers.ModelSerializer):
    class Meta:
        model = Refund
        fields = ["id", "payment", "amount", "reason", "status",
                  "actor", "stripe_refund_id", "failure_reason", "created_at"]


class IssueRefundSerializer(serializers.Serializer):
    amount = serializers.DecimalField(max_digits=12, decimal_places=2)
    reason = serializers.CharField(max_length=200, required=False, allow_blank=True)


class TipDistributionSerializer(serializers.ModelSerializer):
    staff_email = serializers.CharField(source="staff.email", read_only=True)

    class Meta:
        model = TipDistribution
        fields = ["id", "payment", "staff", "staff_email",
                  "role_label", "amount", "notes"]


class DistributeTipsSerializer(serializers.Serializer):
    distributions = serializers.ListField(
        child=serializers.DictField(),
    )
