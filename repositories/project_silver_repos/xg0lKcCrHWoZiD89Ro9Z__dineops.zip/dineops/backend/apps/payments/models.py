from __future__ import annotations

import uuid
from decimal import Decimal

from django.conf import settings
from django.db import models

from apps.common.models import TimeStampedModel


class Payment(TimeStampedModel):
    """Money received against an order. Multiple payments per order allowed
    (split checks, partial card + cash, etc.)."""

    METHOD_CHOICES = [
        ("cash", "Cash"),
        ("card", "Card"),
        ("stripe", "Stripe"),
        ("gift_card", "Gift card"),
        ("house_account", "House account"),
        ("comp", "Comp"),
        ("other", "Other"),
    ]

    STATUS_CHOICES = [
        ("pending", "Pending"),
        ("authorized", "Authorized"),
        ("captured", "Captured"),
        ("refunded", "Refunded"),
        ("partially_refunded", "Partially refunded"),
        ("failed", "Failed"),
        ("voided", "Voided"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant = models.ForeignKey(
        "restaurants.Restaurant", on_delete=models.CASCADE, related_name="payments",
    )
    order = models.ForeignKey(
        "orders.Order", on_delete=models.PROTECT, related_name="payments",
    )

    method = models.CharField(max_length=20, choices=METHOD_CHOICES)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="pending")
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    tip_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    surcharge_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    currency = models.CharField(max_length=3, default="USD")

    cashier = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="processed_payments",
    )
    processed_at = models.DateTimeField(null=True, blank=True)

    # Card / Stripe specifics
    stripe_payment_intent_id = models.CharField(max_length=120, blank=True, db_index=True)
    stripe_charge_id = models.CharField(max_length=120, blank=True)
    card_brand = models.CharField(max_length=20, blank=True)
    card_last4 = models.CharField(max_length=4, blank=True)
    receipt_url = models.CharField(max_length=500, blank=True)

    failure_reason = models.CharField(max_length=200, blank=True)
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["restaurant", "status"]),
            models.Index(fields=["order", "status"]),
            models.Index(fields=["method"]),
            models.Index(fields=["processed_at"]),
        ]

    def __str__(self) -> str:
        return f"{self.method} ${self.amount} on Order {self.order_id}"


class Refund(TimeStampedModel):
    """A partial or full refund against an existing Payment."""

    STATUS_CHOICES = [
        ("pending", "Pending"),
        ("succeeded", "Succeeded"),
        ("failed", "Failed"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    payment = models.ForeignKey(
        Payment, on_delete=models.CASCADE, related_name="refunds",
    )
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    reason = models.CharField(max_length=200, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="pending")
    actor = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="+",
    )
    stripe_refund_id = models.CharField(max_length=120, blank=True)
    failure_reason = models.CharField(max_length=200, blank=True)

    class Meta:
        ordering = ["-created_at"]


class TipDistribution(TimeStampedModel):
    """Records how tips on a payment were distributed to staff. Used by the
    daily closeout to print tip-out reports."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    payment = models.ForeignKey(
        Payment, on_delete=models.CASCADE, related_name="tip_distributions",
    )
    staff = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="tip_shares",
    )
    role_label = models.CharField(max_length=80,
                                  help_text="server / runner / busser / barback")
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    notes = models.CharField(max_length=200, blank=True)

    class Meta:
        ordering = ["payment", "role_label"]
