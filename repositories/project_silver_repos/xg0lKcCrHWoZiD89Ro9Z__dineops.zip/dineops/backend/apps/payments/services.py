from __future__ import annotations

from decimal import Decimal

from django.db import transaction
from django.utils import timezone

from apps.common.exceptions import Conflict, ValidationError
from apps.orders.models import Order

from .models import Payment, Refund, TipDistribution


@transaction.atomic
def record_cash_payment(*, order: Order, amount: Decimal, tip: Decimal = Decimal("0"),
                        cashier=None) -> Payment:
    if order.status in ("paid", "closed", "voided"):
        raise ValidationError("order_not_payable")
    if amount is None or amount <= 0:
        raise ValidationError("invalid_amount")
    p = Payment.objects.create(
        restaurant=order.restaurant, order=order,
        method="cash", status="captured",
        amount=amount, tip_amount=tip,
        cashier=cashier, processed_at=timezone.now(),
    )
    _apply_payment_to_order(order, p)
    return p


@transaction.atomic
def record_card_payment(*, order: Order, amount: Decimal,
                        tip: Decimal = Decimal("0"),
                        card_brand: str = "",
                        card_last4: str = "",
                        cashier=None) -> Payment:
    """Record a card payment finalized at the terminal (no Stripe)."""
    if order.status in ("paid", "closed", "voided"):
        raise ValidationError("order_not_payable")
    if amount is None or amount <= 0:
        raise ValidationError("invalid_amount")
    p = Payment.objects.create(
        restaurant=order.restaurant, order=order,
        method="card", status="captured",
        amount=amount, tip_amount=tip,
        card_brand=card_brand, card_last4=card_last4,
        cashier=cashier, processed_at=timezone.now(),
    )
    _apply_payment_to_order(order, p)
    return p


@transaction.atomic
def begin_stripe_payment(*, order: Order, amount: Decimal,
                         tip: Decimal = Decimal("0"),
                         cashier=None) -> Payment:
    """Create a pending Payment record. The caller is expected to call Stripe
    and then `confirm_stripe_payment` with the resulting payment_intent_id."""
    if order.status in ("paid", "closed", "voided"):
        raise ValidationError("order_not_payable")
    if amount is None or amount <= 0:
        raise ValidationError("invalid_amount")
    return Payment.objects.create(
        restaurant=order.restaurant, order=order,
        method="stripe", status="pending",
        amount=amount, tip_amount=tip, cashier=cashier,
    )


@transaction.atomic
def confirm_stripe_payment(*, payment: Payment,
                           stripe_payment_intent_id: str,
                           stripe_charge_id: str = "",
                           card_brand: str = "",
                           card_last4: str = "",
                           receipt_url: str = "") -> Payment:
    if payment.status != "pending":
        raise ValidationError("payment_not_pending")
    payment.stripe_payment_intent_id = stripe_payment_intent_id
    payment.stripe_charge_id = stripe_charge_id
    payment.card_brand = card_brand
    payment.card_last4 = card_last4
    payment.receipt_url = receipt_url
    payment.status = "captured"
    payment.processed_at = timezone.now()
    payment.save()
    _apply_payment_to_order(payment.order, payment)
    return payment


@transaction.atomic
def fail_stripe_payment(*, payment: Payment, reason: str) -> Payment:
    payment.status = "failed"
    payment.failure_reason = reason
    payment.save()
    return payment


def _apply_payment_to_order(order: Order, payment: Payment) -> None:
    """Update the order's amount_paid and balance_due. If balance hits 0,
    mark the order paid."""
    captured_total = sum(
        (p.amount + p.tip_amount for p in order.payments.filter(status="captured")),
        Decimal("0"),
    )
    order.amount_paid = captured_total
    order.balance_due = (order.total_amount - captured_total).quantize(Decimal("0.01"))
    if order.balance_due <= 0:
        order.status = "paid"
        order.paid_at = timezone.now()
        # Sum tips on captured payments and propagate to order.tip_amount
        order.tip_amount = sum(
            (p.tip_amount for p in order.payments.filter(status="captured")),
            Decimal("0"),
        ).quantize(Decimal("0.01"))
    order.save()


@transaction.atomic
def issue_refund(*, payment: Payment, amount: Decimal, reason: str = "",
                 actor=None) -> Refund:
    if payment.status not in ("captured", "partially_refunded"):
        raise ValidationError("payment_not_refundable")
    if amount is None or amount <= 0:
        raise ValidationError("invalid_amount")
    already = sum(
        (r.amount for r in payment.refunds.filter(status="succeeded")),
        Decimal("0"),
    )
    if already + amount > payment.amount + payment.tip_amount:
        raise ValidationError("refund_exceeds_payment")
    refund = Refund.objects.create(
        payment=payment, amount=amount, reason=reason, status="succeeded",
        actor=actor,
    )
    if (already + amount) >= (payment.amount + payment.tip_amount):
        payment.status = "refunded"
    else:
        payment.status = "partially_refunded"
    payment.save(update_fields=["status", "updated_at"])
    return refund


@transaction.atomic
def distribute_tips(*, payment: Payment, distributions: list[dict],
                    actor=None) -> list[TipDistribution]:
    """Record how tips on this payment were split across roles/staff.
    `distributions`: [{role_label, amount, staff_id?, notes?}, ...]"""
    total = sum((Decimal(str(d["amount"])) for d in distributions), Decimal("0"))
    if total > payment.tip_amount:
        raise ValidationError(
            "tip_distribution_exceeds_tip",
            f"Tried to distribute ${total}, available ${payment.tip_amount}",
        )
    out = []
    for d in distributions:
        out.append(TipDistribution.objects.create(
            payment=payment, role_label=d["role_label"],
            amount=Decimal(str(d["amount"])),
            staff_id=d.get("staff_id"),
            notes=d.get("notes", ""),
        ))
    return out
