"""Thin wrapper around the Stripe API. We keep this isolated so that:
  - tests don't accidentally hit Stripe;
  - we can swap providers (Square, Adyen, etc.) later without touching the
    services layer.

In dev/test we set STRIPE_API_KEY="" — the wrapper detects that and returns
canned responses so the rest of the app can be exercised without a live key.
"""
from __future__ import annotations

import logging
import uuid
from decimal import Decimal

from django.conf import settings


logger = logging.getLogger("dineops.payments.stripe")


class StripeError(Exception):
    pass


class _FakeStripe:
    """Stand-in implementation used when STRIPE_API_KEY is empty or
    DINEOPS_STRIPE_FAKE=1. Returns deterministic-ish IDs so tests can match."""

    def create_payment_intent(self, *, amount_cents: int, currency: str = "usd",
                              metadata: dict | None = None) -> dict:
        intent_id = f"pi_test_{uuid.uuid4().hex[:24]}"
        return {
            "id": intent_id,
            "client_secret": f"{intent_id}_secret_{uuid.uuid4().hex[:8]}",
            "status": "requires_confirmation",
            "amount": amount_cents,
            "currency": currency,
            "metadata": metadata or {},
        }

    def confirm_payment_intent(self, intent_id: str) -> dict:
        return {
            "id": intent_id,
            "status": "succeeded",
            "charges": {
                "data": [{
                    "id": f"ch_test_{uuid.uuid4().hex[:20]}",
                    "receipt_url": f"https://stripe.test/receipt/{intent_id}",
                    "payment_method_details": {
                        "card": {"brand": "visa", "last4": "4242"},
                    },
                }],
            },
        }

    def issue_refund(self, *, charge_id: str, amount_cents: int) -> dict:
        return {
            "id": f"re_test_{uuid.uuid4().hex[:20]}",
            "status": "succeeded",
            "amount": amount_cents,
            "charge": charge_id,
        }


def _real_stripe():
    """Lazy import — we don't require the package in dev/test."""
    try:
        import stripe
    except ImportError:  # pragma: no cover
        raise StripeError(
            "stripe package not installed; pip install stripe in deployment",
        )
    stripe.api_key = settings.STRIPE_API_KEY
    return stripe


def get_client():
    fake = bool(getattr(settings, "DINEOPS_STRIPE_FAKE", False))
    if fake or not getattr(settings, "STRIPE_API_KEY", ""):
        logger.info("Using fake Stripe client")
        return _FakeStripe()
    return _RealStripeAdapter()


class _RealStripeAdapter:
    """Adapter that maps our small surface onto stripe-python."""

    def __init__(self):
        self.stripe = _real_stripe()

    def create_payment_intent(self, *, amount_cents: int,
                              currency: str = "usd", metadata: dict | None = None):
        intent = self.stripe.PaymentIntent.create(
            amount=amount_cents, currency=currency,
            metadata=metadata or {},
            payment_method_types=["card"],
        )
        return {
            "id": intent["id"],
            "client_secret": intent["client_secret"],
            "status": intent["status"],
            "amount": intent["amount"],
            "currency": intent["currency"],
            "metadata": intent.get("metadata", {}),
        }

    def confirm_payment_intent(self, intent_id: str):
        intent = self.stripe.PaymentIntent.confirm(intent_id)
        return dict(intent)

    def issue_refund(self, *, charge_id: str, amount_cents: int):
        return dict(self.stripe.Refund.create(
            charge=charge_id, amount=amount_cents,
        ))


def amount_to_cents(amount: Decimal) -> int:
    return int((amount * 100).quantize(Decimal("1")))
