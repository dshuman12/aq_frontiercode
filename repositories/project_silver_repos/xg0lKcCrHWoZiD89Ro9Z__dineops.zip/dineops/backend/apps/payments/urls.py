from django.urls import path

from . import views

app_name = "payments"

urlpatterns = [
    path("<uuid:restaurant_id>/cash/",
         views.CashPaymentView.as_view(), name="cash"),
    path("<uuid:restaurant_id>/card/",
         views.CardPaymentView.as_view(), name="card"),
    path("<uuid:restaurant_id>/stripe/begin/",
         views.StripeBeginView.as_view(), name="stripe-begin"),
    path("<uuid:restaurant_id>/stripe/confirm/",
         views.StripeConfirmView.as_view(), name="stripe-confirm"),
    path("<uuid:restaurant_id>/",
         views.PaymentList.as_view(), name="list"),
    path("<uuid:restaurant_id>/<uuid:payment_id>/refund/",
         views.RefundView.as_view(), name="refund"),
    path("<uuid:restaurant_id>/<uuid:payment_id>/tip-distribution/",
         views.DistributeTipsView.as_view(), name="tip-distribution"),
]
