from __future__ import annotations

from decimal import Decimal

from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common.exceptions import NotFound, PermissionDenied
from apps.orders.models import Order
from apps.restaurants.models import Restaurant, RestaurantMember

from . import services
from .models import Payment
from .serializers import (
    CardPaymentSerializer, CashPaymentSerializer, DistributeTipsSerializer,
    IssueRefundSerializer, PaymentSerializer, RefundSerializer,
    StripeBeginSerializer, StripeConfirmSerializer, TipDistributionSerializer,
)
from .stripe_client import amount_to_cents, get_client


def _require_member(user, restaurant_id):
    m = RestaurantMember.objects.filter(
        restaurant_id=restaurant_id, user=user, status="active",
    ).first()
    if not m:
        raise PermissionDenied("not_a_member")
    return m


def _can_take_payments(roles):
    return any(r in (
        "owner", "general_manager", "assistant_manager",
        "cashier", "server",
    ) for r in roles or [])


def _can_refund(roles):
    return any(r in (
        "owner", "general_manager", "assistant_manager", "accountant",
    ) for r in roles or [])


def _get_order(restaurant_id, order_id):
    o = Order.objects.filter(id=order_id, restaurant_id=restaurant_id).first()
    if not o:
        raise NotFound("order_not_found")
    return o


class CashPaymentView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_take_payments(member.roles):
            raise PermissionDenied()
        s = CashPaymentSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        order = _get_order(restaurant_id, s.validated_data["order_id"])
        p = services.record_cash_payment(
            order=order, amount=s.validated_data["amount"],
            tip=s.validated_data["tip"], cashier=request.user,
        )
        return Response({"payment": PaymentSerializer(p).data}, status=201)


class CardPaymentView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_take_payments(member.roles):
            raise PermissionDenied()
        s = CardPaymentSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        order = _get_order(restaurant_id, s.validated_data["order_id"])
        p = services.record_card_payment(
            order=order,
            amount=s.validated_data["amount"],
            tip=s.validated_data["tip"],
            card_brand=s.validated_data.get("card_brand", ""),
            card_last4=s.validated_data.get("card_last4", ""),
            cashier=request.user,
        )
        return Response({"payment": PaymentSerializer(p).data}, status=201)


class StripeBeginView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_take_payments(member.roles):
            raise PermissionDenied()
        s = StripeBeginSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        order = _get_order(restaurant_id, s.validated_data["order_id"])
        amount = s.validated_data["amount"]
        tip = s.validated_data["tip"]
        payment = services.begin_stripe_payment(
            order=order, amount=amount, tip=tip, cashier=request.user,
        )
        client = get_client()
        intent = client.create_payment_intent(
            amount_cents=amount_to_cents(amount + tip),
            metadata={"payment_id": str(payment.id),
                      "order_id": str(order.id)},
        )
        payment.stripe_payment_intent_id = intent["id"]
        payment.save(update_fields=["stripe_payment_intent_id", "updated_at"])
        return Response({
            "payment": PaymentSerializer(payment).data,
            "client_secret": intent["client_secret"],
        }, status=201)


class StripeConfirmView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_take_payments(member.roles):
            raise PermissionDenied()
        s = StripeConfirmSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        payment = Payment.objects.filter(
            id=s.validated_data["payment_id"], restaurant_id=restaurant_id,
        ).first()
        if not payment:
            raise NotFound()
        client = get_client()
        intent = client.confirm_payment_intent(payment.stripe_payment_intent_id)
        if intent.get("status") != "succeeded":
            services.fail_stripe_payment(
                payment=payment, reason=intent.get("last_payment_error", {}).get(
                    "message", "stripe_failed",
                ),
            )
            return Response({"payment": PaymentSerializer(payment).data}, status=400)
        charge = (intent.get("charges", {}).get("data") or [{}])[0]
        services.confirm_stripe_payment(
            payment=payment,
            stripe_payment_intent_id=intent["id"],
            stripe_charge_id=charge.get("id", ""),
            card_brand=charge.get("payment_method_details", {})
                            .get("card", {}).get("brand", ""),
            card_last4=charge.get("payment_method_details", {})
                            .get("card", {}).get("last4", ""),
            receipt_url=charge.get("receipt_url", ""),
        )
        return Response({"payment": PaymentSerializer(payment).data})


class PaymentList(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        _require_member(request.user, restaurant_id)
        qs = Payment.objects.filter(
            restaurant_id=restaurant_id,
        ).order_by("-created_at")[:200]
        if (oid := request.GET.get("order_id")):
            qs = Payment.objects.filter(
                restaurant_id=restaurant_id, order_id=oid,
            ).order_by("-created_at")
        return Response({"results": PaymentSerializer(qs, many=True).data})


class RefundView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, payment_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_refund(member.roles):
            raise PermissionDenied()
        payment = Payment.objects.filter(
            id=payment_id, restaurant_id=restaurant_id,
        ).first()
        if not payment:
            raise NotFound()
        s = IssueRefundSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        refund = services.issue_refund(
            payment=payment, amount=s.validated_data["amount"],
            reason=s.validated_data.get("reason", ""), actor=request.user,
        )
        # If captured via Stripe, also call Stripe refund
        if payment.method == "stripe" and payment.stripe_charge_id:
            client = get_client()
            stripe_refund = client.issue_refund(
                charge_id=payment.stripe_charge_id,
                amount_cents=amount_to_cents(s.validated_data["amount"]),
            )
            refund.stripe_refund_id = stripe_refund.get("id", "")
            refund.save(update_fields=["stripe_refund_id", "updated_at"])
        return Response({"refund": RefundSerializer(refund).data}, status=201)


class DistributeTipsView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, payment_id):
        member = _require_member(request.user, restaurant_id)
        if not any(r in ("owner", "general_manager", "assistant_manager",
                         "cashier") for r in member.roles or []):
            raise PermissionDenied()
        payment = Payment.objects.filter(
            id=payment_id, restaurant_id=restaurant_id,
        ).first()
        if not payment:
            raise NotFound()
        s = DistributeTipsSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        rows = services.distribute_tips(
            payment=payment, distributions=s.validated_data["distributions"],
            actor=request.user,
        )
        return Response({
            "distributions": TipDistributionSerializer(rows, many=True).data,
        }, status=201)
