from django.contrib import admin

from .models import Payment, Refund, TipDistribution


class RefundInline(admin.TabularInline):
    model = Refund
    extra = 0
    readonly_fields = ("amount", "reason", "status", "actor", "created_at")
    can_delete = False


class TipDistributionInline(admin.TabularInline):
    model = TipDistribution
    extra = 0


@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ("order", "method", "status", "amount",
                    "tip_amount", "card_last4", "processed_at")
    list_filter = ("method", "status", "card_brand")
    search_fields = ("stripe_payment_intent_id", "stripe_charge_id",
                     "order__order_number")
    readonly_fields = ("processed_at", "stripe_payment_intent_id",
                       "stripe_charge_id", "receipt_url")
    inlines = [RefundInline, TipDistributionInline]


admin.site.register(Refund)
admin.site.register(TipDistribution)
