from decimal import Decimal

import pytest
from rest_framework.test import APIClient

from apps.accounts.models import User
from apps.locations.models import Location
from apps.menus.services import create_menu_item
from apps.orders.services import (
    add_item, create_order, fire_to_kitchen, mark_order_served, submit_order,
)
from apps.restaurants.models import Restaurant, RestaurantMember


pytestmark = pytest.mark.django_db


@pytest.fixture
def setup_with_order():
    owner = User.objects.create_user(email="o@x.com", password="pwpwpwpw")
    rest = Restaurant.objects.create(
        name="R", slug="r", owner=owner,
        default_tax_percent=Decimal("0"),
        default_service_charge_percent=Decimal("0"),
    )
    loc = Location.objects.create(
        restaurant=rest, name="Main", slug="main", accepts_dine_in=True,
    )
    RestaurantMember.objects.create(
        restaurant=rest, user=owner, roles=["owner"], status="active",
    )
    item = create_menu_item(restaurant=rest, name="X",
                            base_price=Decimal("20"))
    order = create_order(restaurant=rest, location=loc, table_number="1")
    add_item(order=order, menu_item=item, quantity=1)
    submit_order(order=order)
    fire_to_kitchen(order=order)
    mark_order_served(order=order)
    order.refresh_from_db()
    return {"rest": rest, "owner": owner, "order": order}


def _login(u):
    c = APIClient()
    c.force_authenticate(user=u)
    return c


def test_cash_payment(setup_with_order):
    s = setup_with_order
    c = _login(s["owner"])
    resp = c.post(
        f"/api/payments/{s['rest'].id}/cash/",
        {"order_id": str(s["order"].id),
         "amount": "20", "tip": "3"},
        format="json",
    )
    assert resp.status_code == 201
    s["order"].refresh_from_db()
    assert s["order"].status == "paid"


def test_stripe_begin_returns_secret(setup_with_order):
    s = setup_with_order
    c = _login(s["owner"])
    resp = c.post(
        f"/api/payments/{s['rest'].id}/stripe/begin/",
        {"order_id": str(s["order"].id), "amount": "20"},
        format="json",
    )
    assert resp.status_code == 201
    assert resp.data["client_secret"].startswith("pi_test_")


def test_stripe_confirm_succeeds(setup_with_order):
    s = setup_with_order
    c = _login(s["owner"])
    resp = c.post(
        f"/api/payments/{s['rest'].id}/stripe/begin/",
        {"order_id": str(s["order"].id), "amount": "20"},
        format="json",
    )
    payment_id = resp.data["payment"]["id"]
    resp = c.post(
        f"/api/payments/{s['rest'].id}/stripe/confirm/",
        {"payment_id": payment_id},
        format="json",
    )
    assert resp.status_code == 200
    assert resp.data["payment"]["status"] == "captured"
    s["order"].refresh_from_db()
    assert s["order"].status == "paid"
