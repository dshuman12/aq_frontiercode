from __future__ import annotations

from decimal import Decimal

import pytest

from apps.accounts.models import User
from apps.common.exceptions import ValidationError
from apps.locations.models import Location
from apps.menus.services import create_menu_item
from apps.orders.services import (
    add_item, create_order, fire_to_kitchen, mark_order_served, submit_order,
)
from apps.payments.models import Payment, Refund, TipDistribution
from apps.payments.services import (
    begin_stripe_payment, confirm_stripe_payment, distribute_tips,
    fail_stripe_payment, issue_refund, record_card_payment,
    record_cash_payment,
)
from apps.payments.stripe_client import _FakeStripe, amount_to_cents
from apps.restaurants.models import Restaurant


pytestmark = pytest.mark.django_db


def _setup_with_order(price=Decimal("20.00"), *, qty=1):
    owner = User.objects.create_user(email="o@x.com", password="pwpwpwpw")
    rest = Restaurant.objects.create(
        name="R", slug="r", owner=owner,
        default_tax_percent=Decimal("0"),
        default_service_charge_percent=Decimal("0"),
    )
    loc = Location.objects.create(
        restaurant=rest, name="Main", slug="main", accepts_dine_in=True,
    )
    item = create_menu_item(restaurant=rest, name="Burger",
                            base_price=price)
    order = create_order(restaurant=rest, location=loc,
                         table_number="1", server=owner)
    add_item(order=order, menu_item=item, quantity=qty)
    submit_order(order=order)
    fire_to_kitchen(order=order)
    mark_order_served(order=order)
    order.refresh_from_db()
    return rest, owner, order


class TestCashPayment:
    def test_full_payment_marks_paid(self):
        rest, owner, order = _setup_with_order()
        # total = 20, no tax/service
        record_cash_payment(order=order, amount=Decimal("20"),
                            cashier=owner)
        order.refresh_from_db()
        assert order.status == "paid"
        assert order.balance_due == Decimal("0.00")

    def test_partial_payment_remains_open(self):
        rest, owner, order = _setup_with_order()
        record_cash_payment(order=order, amount=Decimal("10"))
        order.refresh_from_db()
        assert order.status == "served"
        assert order.balance_due == Decimal("10.00")

    def test_payment_with_tip(self):
        rest, owner, order = _setup_with_order()
        record_cash_payment(order=order, amount=Decimal("20"),
                            tip=Decimal("4"))
        order.refresh_from_db()
        assert order.status == "paid"
        assert order.tip_amount == Decimal("4.00")

    def test_invalid_amount_rejected(self):
        rest, owner, order = _setup_with_order()
        with pytest.raises(ValidationError):
            record_cash_payment(order=order, amount=Decimal("0"))

    def test_already_paid_rejected(self):
        rest, owner, order = _setup_with_order()
        record_cash_payment(order=order, amount=Decimal("20"))
        order.refresh_from_db()
        with pytest.raises(ValidationError):
            record_cash_payment(order=order, amount=Decimal("5"))


class TestCardPayment:
    def test_card(self):
        rest, owner, order = _setup_with_order()
        p = record_card_payment(
            order=order, amount=Decimal("20"),
            card_brand="visa", card_last4="4242",
        )
        assert p.status == "captured"
        assert p.card_last4 == "4242"


class TestStripePayment:
    def test_begin_then_confirm(self):
        rest, owner, order = _setup_with_order()
        p = begin_stripe_payment(order=order, amount=Decimal("20"),
                                 tip=Decimal("3"))
        assert p.status == "pending"
        confirm_stripe_payment(
            payment=p,
            stripe_payment_intent_id="pi_test_xyz",
            stripe_charge_id="ch_test_xyz",
            card_brand="visa", card_last4="4242",
            receipt_url="https://stripe.test/receipt/x",
        )
        p.refresh_from_db()
        assert p.status == "captured"
        order.refresh_from_db()
        assert order.status == "paid"

    def test_fail(self):
        rest, owner, order = _setup_with_order()
        p = begin_stripe_payment(order=order, amount=Decimal("20"))
        fail_stripe_payment(payment=p, reason="card_declined")
        p.refresh_from_db()
        assert p.status == "failed"
        order.refresh_from_db()
        assert order.status != "paid"

    def test_confirm_only_pending(self):
        rest, owner, order = _setup_with_order()
        p = begin_stripe_payment(order=order, amount=Decimal("20"))
        confirm_stripe_payment(
            payment=p,
            stripe_payment_intent_id="pi_test_xyz",
        )
        with pytest.raises(ValidationError):
            confirm_stripe_payment(
                payment=p, stripe_payment_intent_id="pi_test_xyz",
            )


class TestRefund:
    def test_full_refund(self):
        rest, owner, order = _setup_with_order()
        p = record_cash_payment(order=order, amount=Decimal("20"))
        r = issue_refund(payment=p, amount=Decimal("20"),
                         reason="customer complaint", actor=owner)
        p.refresh_from_db()
        assert p.status == "refunded"
        assert r.amount == Decimal("20.00")

    def test_partial_then_full(self):
        rest, owner, order = _setup_with_order()
        p = record_cash_payment(order=order, amount=Decimal("20"))
        issue_refund(payment=p, amount=Decimal("5"), actor=owner)
        p.refresh_from_db()
        assert p.status == "partially_refunded"
        issue_refund(payment=p, amount=Decimal("15"), actor=owner)
        p.refresh_from_db()
        assert p.status == "refunded"

    def test_over_refund_rejected(self):
        rest, owner, order = _setup_with_order()
        p = record_cash_payment(order=order, amount=Decimal("20"))
        with pytest.raises(ValidationError):
            issue_refund(payment=p, amount=Decimal("25"), actor=owner)

    def test_refund_failed_payment_rejected(self):
        rest, owner, order = _setup_with_order()
        p = begin_stripe_payment(order=order, amount=Decimal("20"))
        with pytest.raises(ValidationError):
            issue_refund(payment=p, amount=Decimal("5"), actor=owner)


class TestTipDistribution:
    def test_distribute(self):
        rest, owner, order = _setup_with_order()
        p = record_cash_payment(order=order, amount=Decimal("20"),
                                tip=Decimal("4"))
        rows = distribute_tips(payment=p, distributions=[
            {"role_label": "server", "amount": "3"},
            {"role_label": "busser", "amount": "1"},
        ])
        assert len(rows) == 2

    def test_over_distribute_rejected(self):
        rest, owner, order = _setup_with_order()
        p = record_cash_payment(order=order, amount=Decimal("20"),
                                tip=Decimal("4"))
        with pytest.raises(ValidationError):
            distribute_tips(payment=p, distributions=[
                {"role_label": "server", "amount": "5"},
            ])


class TestFakeStripe:
    def test_create_intent(self):
        c = _FakeStripe()
        intent = c.create_payment_intent(amount_cents=2400, currency="usd")
        assert intent["amount"] == 2400
        assert intent["id"].startswith("pi_test_")

    def test_amount_to_cents(self):
        assert amount_to_cents(Decimal("12.34")) == 1234
        assert amount_to_cents(Decimal("100")) == 10000
