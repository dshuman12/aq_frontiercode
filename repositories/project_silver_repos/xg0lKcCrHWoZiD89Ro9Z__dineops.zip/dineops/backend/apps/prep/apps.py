from django.apps import AppConfig


class PrepConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.prep"

    def ready(self):
        try:
            from . import signals  # noqa: F401
        except ImportError:
            pass
