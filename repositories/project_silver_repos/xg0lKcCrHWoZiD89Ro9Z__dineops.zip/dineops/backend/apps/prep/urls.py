from django.urls import path

from . import views

app_name = "prep"

urlpatterns = [
    path("<uuid:restaurant_id>/lists/",
         views.PrepListListCreate.as_view(), name="list-create"),
    path("<uuid:restaurant_id>/lists/<uuid:prep_list_id>/",
         views.PrepListDetail.as_view(), name="detail"),
    path("<uuid:restaurant_id>/lists/<uuid:prep_list_id>/tasks/",
         views.AddTaskView.as_view(), name="add-task"),
    path("<uuid:restaurant_id>/lists/<uuid:prep_list_id>/publish/",
         views.PublishPrepListView.as_view(), name="publish"),
    path("<uuid:restaurant_id>/tasks/<uuid:task_id>/start/",
         views.TaskStartView.as_view(), name="start-task"),
    path("<uuid:restaurant_id>/tasks/<uuid:task_id>/complete/",
         views.TaskCompleteView.as_view(), name="complete-task"),
    path("<uuid:restaurant_id>/tasks/<uuid:task_id>/skip/",
         views.TaskSkipView.as_view(), name="skip-task"),
    path("<uuid:restaurant_id>/my-tasks/",
         views.MyTasksView.as_view(), name="my-tasks"),
    path("<uuid:restaurant_id>/summary/",
         views.DailySummaryView.as_view(), name="daily-summary"),
]
