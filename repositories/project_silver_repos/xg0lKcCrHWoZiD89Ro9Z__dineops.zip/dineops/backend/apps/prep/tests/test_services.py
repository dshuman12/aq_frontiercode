from __future__ import annotations

from datetime import date
from decimal import Decimal

import pytest

from apps.accounts.models import User
from apps.common.exceptions import ValidationError
from apps.ingredients.models import Ingredient
from apps.inventory.models import InventoryItem
from apps.inventory.services import create_inventory_item
from apps.locations.models import Location
from apps.prep.models import PrepList, PrepTask, ProductionRun
from apps.prep.services import (
    add_task, complete_task, create_prep_list, daily_summary,
    open_tasks_for_user, publish_prep_list, record_production_run,
    skip_task, start_task,
)
from apps.recipes.models import Recipe
from apps.recipes.services import add_ingredient, create_recipe
from apps.restaurants.models import Restaurant


pytestmark = pytest.mark.django_db


def _setup():
    owner = User.objects.create_user(email="o@x.com", password="pwpwpwpw")
    rest = Restaurant.objects.create(name="R", slug="r", owner=owner)
    loc = Location.objects.create(
        restaurant=rest, name="Main", slug="main", accepts_dine_in=True,
    )
    return rest, loc, owner


class TestCreatePrepList:
    def test_creates(self):
        rest, loc, owner = _setup()
        pl = create_prep_list(
            restaurant=rest, location=loc, for_date=date(2023, 10, 1),
            name="Saturday Prep", actor=owner,
        )
        assert pl.status == "draft"
        assert pl.created_by == owner

    def test_blank_name(self):
        rest, loc, owner = _setup()
        with pytest.raises(ValidationError):
            create_prep_list(
                restaurant=rest, location=loc, for_date=date(2023, 10, 1),
                name="  ",
            )

    def test_cross_restaurant_location(self):
        rest1, _, _ = _setup()
        rest2 = Restaurant.objects.create(name="R2", slug="r2", owner=rest1.owner)
        loc2 = Location.objects.create(
            restaurant=rest2, name="Other", slug="other", accepts_dine_in=True,
        )
        with pytest.raises(ValidationError):
            create_prep_list(
                restaurant=rest1, location=loc2, for_date=date(2023, 10, 1),
                name="X",
            )


class TestAddTask:
    def test_add_with_recipe(self):
        rest, loc, _ = _setup()
        pl = create_prep_list(restaurant=rest, location=loc,
                              for_date=date(2023, 10, 1), name="X")
        rec = create_recipe(restaurant=rest, name="Bolognese")
        task = add_task(prep_list=pl, description="Make bolognese",
                        recipe=rec, target_quantity=Decimal("2"))
        assert task.recipe == rec
        assert task.target_quantity == Decimal("2.000")

    def test_add_freeform(self):
        rest, loc, _ = _setup()
        pl = create_prep_list(restaurant=rest, location=loc,
                              for_date=date(2023, 10, 1), name="X")
        task = add_task(prep_list=pl, description="Butcher 3 chickens")
        assert task.recipe is None

    def test_no_description_or_recipe_rejected(self):
        rest, loc, _ = _setup()
        pl = create_prep_list(restaurant=rest, location=loc,
                              for_date=date(2023, 10, 1), name="X")
        with pytest.raises(ValidationError):
            add_task(prep_list=pl, description="")

    def test_zero_quantity_rejected(self):
        rest, loc, _ = _setup()
        pl = create_prep_list(restaurant=rest, location=loc,
                              for_date=date(2023, 10, 1), name="X")
        with pytest.raises(ValidationError):
            add_task(prep_list=pl, description="Y", target_quantity=Decimal("0"))


class TestPublish:
    def test_publish(self):
        rest, loc, _ = _setup()
        pl = create_prep_list(restaurant=rest, location=loc,
                              for_date=date(2023, 10, 1), name="X")
        add_task(prep_list=pl, description="task")
        publish_prep_list(prep_list=pl)
        pl.refresh_from_db()
        assert pl.status == "published"

    def test_publish_empty_rejected(self):
        rest, loc, _ = _setup()
        pl = create_prep_list(restaurant=rest, location=loc,
                              for_date=date(2023, 10, 1), name="X")
        with pytest.raises(ValidationError):
            publish_prep_list(prep_list=pl)


class TestTaskWorkflow:
    def test_start(self):
        rest, loc, owner = _setup()
        pl = create_prep_list(restaurant=rest, location=loc,
                              for_date=date(2023, 10, 1), name="X")
        task = add_task(prep_list=pl, description="task")
        publish_prep_list(prep_list=pl)
        start_task(task=task, actor=owner)
        task.refresh_from_db()
        pl.refresh_from_db()
        assert task.status == "in_progress"
        assert pl.status == "in_progress"

    def test_complete_no_recipe(self):
        rest, loc, owner = _setup()
        pl = create_prep_list(restaurant=rest, location=loc,
                              for_date=date(2023, 10, 1), name="X")
        task = add_task(prep_list=pl, description="task")
        complete_task(task=task, actor=owner)
        task.refresh_from_db()
        assert task.status == "completed"
        assert task.actual_quantity == task.target_quantity

    def test_complete_auto_finishes_list(self):
        rest, loc, owner = _setup()
        pl = create_prep_list(restaurant=rest, location=loc,
                              for_date=date(2023, 10, 1), name="X")
        task = add_task(prep_list=pl, description="task")
        complete_task(task=task, actor=owner)
        pl.refresh_from_db()
        assert pl.status == "completed"

    def test_skip(self):
        rest, loc, owner = _setup()
        pl = create_prep_list(restaurant=rest, location=loc,
                              for_date=date(2023, 10, 1), name="X")
        task = add_task(prep_list=pl, description="task")
        skip_task(task=task, reason="ran out of time", actor=owner)
        task.refresh_from_db()
        assert task.status == "skipped"
        assert "ran out of time" in task.notes


class TestProductionRun:
    def test_records_run_and_decrements_inventory(self):
        rest, loc, owner = _setup()
        ing = Ingredient.objects.create(
            restaurant=rest, name="Beef", base_unit="g",
            cost_per_unit=Decimal("0.05"), yield_factor=Decimal("1"),
        )
        inv = create_inventory_item(
            restaurant=rest, location=loc, ingredient=ing,
            opening_quantity=Decimal("2000"), opening_cost=Decimal("0.05"),
        )
        rec = create_recipe(restaurant=rest, name="Bolognese",
                            yield_quantity=Decimal("4"))
        add_ingredient(recipe=rec, ingredient=ing,
                       quantity=Decimal("500"), unit="g")

        run = record_production_run(
            recipe=rec, location=loc, batches_made=Decimal("2"),
            actor=owner,
        )
        assert run.batches_made == Decimal("2.00")
        # 500g × 2 batches = 1000g consumed
        inv.refresh_from_db()
        assert inv.quantity_on_hand == Decimal("1000.000")
        # Cost: 500g × $0.05 × 2 batches = $50
        assert run.total_ingredient_cost == Decimal("50.00")

    def test_zero_batches_rejected(self):
        rest, loc, _ = _setup()
        rec = create_recipe(restaurant=rest, name="X")
        with pytest.raises(ValidationError):
            record_production_run(recipe=rec, location=loc,
                                  batches_made=Decimal("0"))

    def test_completing_recipe_task_runs_production(self):
        rest, loc, owner = _setup()
        ing = Ingredient.objects.create(
            restaurant=rest, name="Beef", base_unit="g",
            cost_per_unit=Decimal("0.05"),
        )
        inv = create_inventory_item(
            restaurant=rest, location=loc, ingredient=ing,
            opening_quantity=Decimal("1000"), opening_cost=Decimal("0.05"),
        )
        rec = create_recipe(restaurant=rest, name="X")
        add_ingredient(recipe=rec, ingredient=ing,
                       quantity=Decimal("100"), unit="g")
        pl = create_prep_list(restaurant=rest, location=loc,
                              for_date=date(2023, 10, 1), name="L")
        task = add_task(prep_list=pl, description="X", recipe=rec,
                        target_quantity=Decimal("3"))
        complete_task(task=task, actor=owner)
        inv.refresh_from_db()
        # 100g × 3 batches = 300g consumed
        assert inv.quantity_on_hand == Decimal("700.000")
        assert ProductionRun.objects.filter(prep_task=task).count() == 1

    def test_skip_inventory_consumption(self):
        rest, loc, owner = _setup()
        ing = Ingredient.objects.create(restaurant=rest, name="Beef",
                                        base_unit="g",
                                        cost_per_unit=Decimal("0.05"))
        inv = create_inventory_item(
            restaurant=rest, location=loc, ingredient=ing,
            opening_quantity=Decimal("1000"), opening_cost=Decimal("0.05"),
        )
        rec = create_recipe(restaurant=rest, name="X")
        add_ingredient(recipe=rec, ingredient=ing,
                       quantity=Decimal("100"), unit="g")
        pl = create_prep_list(restaurant=rest, location=loc,
                              for_date=date(2023, 10, 1), name="L")
        task = add_task(prep_list=pl, description="X", recipe=rec)
        complete_task(task=task, actor=owner, consume_inventory=False)
        inv.refresh_from_db()
        assert inv.quantity_on_hand == Decimal("1000.000")  # untouched


class TestQueries:
    def test_open_tasks_for_user(self):
        rest, loc, owner = _setup()
        pl = create_prep_list(restaurant=rest, location=loc,
                              for_date=date(2023, 10, 1), name="L")
        task = add_task(prep_list=pl, description="A", assigned_to=owner)
        add_task(prep_list=pl, description="B")  # unassigned
        results = open_tasks_for_user(owner)
        assert len(results) == 1
        assert results[0].id == task.id

    def test_daily_summary(self):
        rest, loc, owner = _setup()
        pl = create_prep_list(restaurant=rest, location=loc,
                              for_date=date(2023, 10, 1), name="L")
        t1 = add_task(prep_list=pl, description="A")
        t2 = add_task(prep_list=pl, description="B")
        complete_task(task=t1, actor=owner)
        skip_task(task=t2, actor=owner)
        result = daily_summary(restaurant_id=rest.id, for_date=date(2023, 10, 1))
        assert result["total_tasks"] == 2
        assert result["completed"] == 1
        assert result["skipped"] == 1
