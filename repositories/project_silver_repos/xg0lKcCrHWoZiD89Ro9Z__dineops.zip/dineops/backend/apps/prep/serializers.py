from __future__ import annotations

from rest_framework import serializers

from .models import PrepList, PrepTask, ProductionRun


class PrepTaskSerializer(serializers.ModelSerializer):
    recipe_name = serializers.CharField(source="recipe.name", read_only=True)
    assigned_to_email = serializers.CharField(source="assigned_to.email", read_only=True)

    class Meta:
        model = PrepTask
        fields = [
            "id", "prep_list", "recipe", "recipe_name",
            "description", "target_quantity", "target_unit",
            "status", "priority", "estimated_minutes", "sort",
            "assigned_to", "assigned_to_email",
            "started_at", "completed_at", "completed_by",
            "actual_quantity", "notes",
        ]
        read_only_fields = ["id", "started_at", "completed_at", "completed_by"]


class PrepListSerializer(serializers.ModelSerializer):
    location_name = serializers.CharField(source="location.name", read_only=True)
    station_name = serializers.CharField(source="station.label", read_only=True)
    task_count = serializers.IntegerField(source="tasks.count", read_only=True)

    class Meta:
        model = PrepList
        fields = [
            "id", "restaurant", "location", "location_name",
            "station", "station_name",
            "name", "for_date", "status",
            "created_by", "published_at", "completed_at",
            "task_count", "notes",
        ]
        read_only_fields = ["id", "created_by",
                            "published_at", "completed_at"]


class PrepListDetailSerializer(PrepListSerializer):
    tasks = PrepTaskSerializer(many=True, read_only=True)

    class Meta(PrepListSerializer.Meta):
        fields = PrepListSerializer.Meta.fields + ["tasks"]


class CreatePrepListSerializer(serializers.Serializer):
    location_id = serializers.UUIDField()
    station_id = serializers.UUIDField(required=False, allow_null=True)
    name = serializers.CharField(max_length=160)
    for_date = serializers.DateField()


class AddTaskSerializer(serializers.Serializer):
    description = serializers.CharField(max_length=300, required=False, allow_blank=True)
    recipe_id = serializers.UUIDField(required=False, allow_null=True)
    target_quantity = serializers.DecimalField(
        max_digits=10, decimal_places=3, default=1,
    )
    target_unit = serializers.CharField(default="each")
    priority = serializers.IntegerField(min_value=0, max_value=5, default=2)
    estimated_minutes = serializers.IntegerField(min_value=0, default=0)
    sort = serializers.IntegerField(default=0)
    assigned_to = serializers.UUIDField(required=False, allow_null=True)


class CompleteTaskSerializer(serializers.Serializer):
    actual_quantity = serializers.DecimalField(
        max_digits=10, decimal_places=3, required=False, allow_null=True,
    )
    notes = serializers.CharField(required=False, allow_blank=True)
    consume_inventory = serializers.BooleanField(default=True)


class SkipTaskSerializer(serializers.Serializer):
    reason = serializers.CharField(required=False, allow_blank=True)


class ProductionRunSerializer(serializers.ModelSerializer):
    recipe_name = serializers.CharField(source="recipe.name", read_only=True)

    class Meta:
        model = ProductionRun
        fields = ["id", "prep_task", "recipe", "recipe_name",
                  "location", "batches_made",
                  "actor", "notes", "total_ingredient_cost",
                  "created_at"]
