from __future__ import annotations

import uuid

from django.conf import settings
from django.db import models

from apps.common.models import TimeStampedModel


class PrepList(TimeStampedModel):
    """A prep list for a station/shift — tells the kitchen what to make today.

    Generated automatically from upcoming sales forecasts and current inventory,
    or assembled manually by the chef.
    """

    STATUS_CHOICES = [
        ("draft", "Draft"),
        ("published", "Published"),
        ("in_progress", "In progress"),
        ("completed", "Completed"),
        ("archived", "Archived"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant = models.ForeignKey(
        "restaurants.Restaurant", on_delete=models.CASCADE,
        related_name="prep_lists",
    )
    location = models.ForeignKey(
        "locations.Location", on_delete=models.CASCADE,
        related_name="prep_lists",
    )
    station = models.ForeignKey(
        "locations.KitchenStation", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="prep_lists",
    )
    name = models.CharField(max_length=160)
    for_date = models.DateField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="draft")

    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="created_prep_lists",
    )
    published_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)

    notes = models.TextField(blank=True)

    class Meta:
        ordering = ["-for_date", "name"]
        indexes = [
            models.Index(fields=["restaurant", "for_date"]),
            models.Index(fields=["status"]),
        ]

    def __str__(self) -> str:
        return f"{self.name} — {self.for_date}"


class PrepTask(TimeStampedModel):
    """One thing to prep — typically a recipe (batch / sub-recipe), but can
    be a free-form 'butcher 3 chickens' kind of task too."""

    STATUS_CHOICES = [
        ("pending", "Pending"),
        ("in_progress", "In progress"),
        ("completed", "Completed"),
        ("skipped", "Skipped"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    prep_list = models.ForeignKey(
        PrepList, on_delete=models.CASCADE, related_name="tasks",
    )
    recipe = models.ForeignKey(
        "recipes.Recipe", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="prep_tasks",
    )
    description = models.CharField(max_length=300)
    target_quantity = models.DecimalField(max_digits=10, decimal_places=3, default=1)
    target_unit = models.CharField(max_length=20, default="each")

    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="pending")
    priority = models.PositiveSmallIntegerField(
        default=2, help_text="0 = critical, 5 = nice-to-have.",
    )
    estimated_minutes = models.PositiveIntegerField(default=0)
    sort = models.PositiveIntegerField(default=0)

    assigned_to = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="assigned_prep_tasks",
    )
    started_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    completed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="completed_prep_tasks",
    )
    actual_quantity = models.DecimalField(
        max_digits=10, decimal_places=3, null=True, blank=True,
    )
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ["sort", "priority", "id"]
        indexes = [
            models.Index(fields=["prep_list", "status"]),
            models.Index(fields=["assigned_to", "status"]),
        ]


class ProductionRun(TimeStampedModel):
    """A discrete production event — 'Made 2x batch of bolognese' — that
    decrements ingredient inventory and credits a sub-recipe (or just records
    the production for batch-cost reporting)."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    prep_task = models.ForeignKey(
        PrepTask, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="production_runs",
    )
    recipe = models.ForeignKey(
        "recipes.Recipe", on_delete=models.PROTECT,
        related_name="production_runs",
    )
    location = models.ForeignKey(
        "locations.Location", on_delete=models.CASCADE,
        related_name="production_runs",
    )
    batches_made = models.DecimalField(max_digits=8, decimal_places=2, default=1)
    actor = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="+",
    )
    notes = models.TextField(blank=True)
    total_ingredient_cost = models.DecimalField(
        max_digits=12, decimal_places=2, default=0,
    )

    class Meta:
        ordering = ["-created_at"]
