from __future__ import annotations

from datetime import date

from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.accounts.models import User
from apps.common.exceptions import NotFound, PermissionDenied
from apps.locations.models import KitchenStation, Location
from apps.recipes.models import Recipe
from apps.restaurants.models import Restaurant, RestaurantMember

from . import services
from .models import PrepList, PrepTask
from .serializers import (
    AddTaskSerializer, CompleteTaskSerializer, CreatePrepListSerializer,
    PrepListDetailSerializer, PrepListSerializer, PrepTaskSerializer,
    ProductionRunSerializer, SkipTaskSerializer,
)


def _require_member(user, restaurant_id):
    m = RestaurantMember.objects.filter(
        restaurant_id=restaurant_id, user=user, status="active",
    ).first()
    if not m:
        raise PermissionDenied("not_a_member")
    return m


def _can_manage_prep(roles):
    return any(r in (
        "owner", "general_manager", "assistant_manager", "chef",
    ) for r in roles or [])


def _can_complete_task(roles):
    return any(r in (
        "owner", "general_manager", "assistant_manager",
        "chef", "kitchen_staff",
    ) for r in roles or [])


class PrepListListCreate(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        _require_member(request.user, restaurant_id)
        qs = PrepList.objects.filter(
            restaurant_id=restaurant_id,
        ).select_related("location", "station").order_by("-for_date")
        if (date_str := request.GET.get("for_date")):
            qs = qs.filter(for_date=date_str)
        if (status_f := request.GET.get("status")):
            qs = qs.filter(status=status_f)
        return Response({"results": PrepListSerializer(qs[:200], many=True).data})

    def post(self, request, restaurant_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_manage_prep(member.roles):
            raise PermissionDenied()
        s = CreatePrepListSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        rest = Restaurant.objects.get(id=restaurant_id)
        loc = Location.objects.filter(
            id=s.validated_data["location_id"], restaurant_id=restaurant_id,
        ).first()
        if not loc:
            raise NotFound()
        station = None
        if s.validated_data.get("station_id"):
            station = KitchenStation.objects.filter(
                id=s.validated_data["station_id"], location_id=loc.id,
            ).first()
        pl = services.create_prep_list(
            restaurant=rest, location=loc, station=station,
            for_date=s.validated_data["for_date"],
            name=s.validated_data["name"], actor=request.user,
        )
        return Response({"prep_list": PrepListSerializer(pl).data}, status=201)


class PrepListDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id, prep_list_id):
        _require_member(request.user, restaurant_id)
        pl = PrepList.objects.filter(
            id=prep_list_id, restaurant_id=restaurant_id,
        ).prefetch_related("tasks__assigned_to", "tasks__recipe").first()
        if not pl:
            raise NotFound()
        return Response({"prep_list": PrepListDetailSerializer(pl).data})


class AddTaskView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, prep_list_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_manage_prep(member.roles):
            raise PermissionDenied()
        pl = PrepList.objects.filter(
            id=prep_list_id, restaurant_id=restaurant_id,
        ).first()
        if not pl:
            raise NotFound()
        s = AddTaskSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        recipe = None
        if s.validated_data.get("recipe_id"):
            recipe = Recipe.objects.filter(
                id=s.validated_data["recipe_id"], restaurant_id=restaurant_id,
            ).first()
            if not recipe:
                raise NotFound("recipe_not_found")
        assignee = None
        if s.validated_data.get("assigned_to"):
            assignee = User.objects.filter(id=s.validated_data["assigned_to"]).first()
        task = services.add_task(
            prep_list=pl, description=s.validated_data.get("description", ""),
            recipe=recipe, target_quantity=s.validated_data["target_quantity"],
            target_unit=s.validated_data["target_unit"],
            priority=s.validated_data["priority"],
            estimated_minutes=s.validated_data["estimated_minutes"],
            sort=s.validated_data["sort"],
            assigned_to=assignee,
        )
        return Response({"task": PrepTaskSerializer(task).data}, status=201)


class PublishPrepListView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, prep_list_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_manage_prep(member.roles):
            raise PermissionDenied()
        pl = PrepList.objects.filter(
            id=prep_list_id, restaurant_id=restaurant_id,
        ).first()
        if not pl:
            raise NotFound()
        services.publish_prep_list(prep_list=pl)
        return Response({"prep_list": PrepListSerializer(pl).data})


class TaskStartView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, task_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_complete_task(member.roles):
            raise PermissionDenied()
        task = PrepTask.objects.filter(
            id=task_id, prep_list__restaurant_id=restaurant_id,
        ).first()
        if not task:
            raise NotFound()
        services.start_task(task=task, actor=request.user)
        return Response({"task": PrepTaskSerializer(task).data})


class TaskCompleteView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, task_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_complete_task(member.roles):
            raise PermissionDenied()
        task = PrepTask.objects.filter(
            id=task_id, prep_list__restaurant_id=restaurant_id,
        ).select_related("prep_list", "recipe").first()
        if not task:
            raise NotFound()
        s = CompleteTaskSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        services.complete_task(task=task, actor=request.user, **s.validated_data)
        return Response({"task": PrepTaskSerializer(task).data})


class TaskSkipView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, task_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_manage_prep(member.roles):
            raise PermissionDenied()
        task = PrepTask.objects.filter(
            id=task_id, prep_list__restaurant_id=restaurant_id,
        ).first()
        if not task:
            raise NotFound()
        s = SkipTaskSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        services.skip_task(task=task, actor=request.user,
                           reason=s.validated_data.get("reason", ""))
        return Response({"task": PrepTaskSerializer(task).data})


class MyTasksView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        _require_member(request.user, restaurant_id)
        on_date = None
        if (d := request.GET.get("date")):
            on_date = date.fromisoformat(d)
        tasks = services.open_tasks_for_user(request.user, on_date=on_date)
        return Response({"results": PrepTaskSerializer(tasks, many=True).data})


class DailySummaryView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        _require_member(request.user, restaurant_id)
        d = date.fromisoformat(request.GET["date"])
        return Response(services.daily_summary(
            restaurant_id=restaurant_id, for_date=d,
        ))
