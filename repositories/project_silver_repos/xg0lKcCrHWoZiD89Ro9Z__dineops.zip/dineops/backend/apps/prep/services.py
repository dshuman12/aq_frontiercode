from __future__ import annotations

from datetime import date, datetime, time
from decimal import Decimal

from django.db import transaction
from django.utils import timezone

from apps.common.exceptions import Conflict, NotFound, ValidationError
from apps.inventory.models import InventoryItem
from apps.inventory.services import consume_stock
from apps.recipes.models import Recipe
from apps.recipes.services import calculate_recipe_cost, convert_quantity

from .models import PrepList, PrepTask, ProductionRun


@transaction.atomic
def create_prep_list(*, restaurant, location, for_date: date, name: str,
                     station=None, actor=None) -> PrepList:
    if location.restaurant_id != restaurant.id:
        raise ValidationError("location_not_in_restaurant")
    if not name.strip():
        raise ValidationError("invalid_name")
    return PrepList.objects.create(
        restaurant=restaurant, location=location, station=station,
        for_date=for_date, name=name.strip(),
        created_by=actor, status="draft",
    )


@transaction.atomic
def add_task(*, prep_list: PrepList, description: str,
             recipe: Recipe | None = None,
             target_quantity: Decimal = Decimal("1"),
             target_unit: str = "each",
             priority: int = 2, estimated_minutes: int = 0,
             sort: int = 0,
             assigned_to=None) -> PrepTask:
    if prep_list.status not in ("draft", "published", "in_progress"):
        raise ValidationError("prep_list_not_editable")
    if not description.strip() and not recipe:
        raise ValidationError("description_or_recipe_required")
    if target_quantity is None or target_quantity <= 0:
        raise ValidationError("invalid_target_quantity")
    return PrepTask.objects.create(
        prep_list=prep_list, recipe=recipe,
        description=description or (recipe.name if recipe else ""),
        target_quantity=target_quantity, target_unit=target_unit,
        priority=priority, estimated_minutes=estimated_minutes,
        sort=sort, assigned_to=assigned_to,
    )


@transaction.atomic
def publish_prep_list(*, prep_list: PrepList) -> PrepList:
    if prep_list.status != "draft":
        raise ValidationError("prep_list_not_in_draft")
    if prep_list.tasks.count() == 0:
        raise ValidationError("prep_list_has_no_tasks")
    prep_list.status = "published"
    prep_list.published_at = timezone.now()
    prep_list.save(update_fields=["status", "published_at", "updated_at"])
    return prep_list


@transaction.atomic
def assign_task(*, task: PrepTask, user) -> PrepTask:
    task.assigned_to = user
    task.save(update_fields=["assigned_to", "updated_at"])
    return task


@transaction.atomic
def start_task(*, task: PrepTask, actor=None) -> PrepTask:
    if task.status != "pending":
        raise ValidationError("task_not_pending")
    task.status = "in_progress"
    task.started_at = timezone.now()
    if not task.assigned_to and actor:
        task.assigned_to = actor
    task.save(update_fields=[
        "status", "started_at", "assigned_to", "updated_at",
    ])
    # If the parent prep_list is still 'published', flip it to in_progress
    pl = task.prep_list
    if pl.status == "published":
        pl.status = "in_progress"
        pl.save(update_fields=["status", "updated_at"])
    return task


@transaction.atomic
def complete_task(*, task: PrepTask, actor,
                  actual_quantity: Decimal | None = None,
                  consume_inventory: bool = True,
                  notes: str = "") -> PrepTask:
    if task.status not in ("in_progress", "pending"):
        raise ValidationError("task_not_completable")
    qty = actual_quantity if actual_quantity is not None else task.target_quantity
    if qty < 0:
        raise ValidationError("invalid_actual_quantity")

    task.status = "completed"
    task.completed_at = timezone.now()
    task.completed_by = actor
    task.actual_quantity = qty
    if notes:
        task.notes = notes
    task.save(update_fields=[
        "status", "completed_at", "completed_by",
        "actual_quantity", "notes", "updated_at",
    ])

    # If the task is recipe-backed, run a ProductionRun and decrement inventory
    if task.recipe and consume_inventory:
        record_production_run(
            recipe=task.recipe, location=task.prep_list.location,
            batches_made=qty, prep_task=task, actor=actor,
        )

    # Auto-complete the parent prep list if all tasks are done
    pl = task.prep_list
    pending = pl.tasks.exclude(status__in=["completed", "skipped"]).count()
    if pending == 0:
        pl.status = "completed"
        pl.completed_at = timezone.now()
        pl.save(update_fields=["status", "completed_at", "updated_at"])
    return task


@transaction.atomic
def skip_task(*, task: PrepTask, reason: str = "", actor=None) -> PrepTask:
    if task.status not in ("pending", "in_progress"):
        raise ValidationError("task_not_skippable")
    task.status = "skipped"
    task.completed_at = timezone.now()
    task.completed_by = actor
    task.notes = (task.notes + f"\nSKIPPED: {reason}").strip()
    task.save()
    return task


@transaction.atomic
def record_production_run(*, recipe: Recipe, location, batches_made: Decimal,
                          prep_task: PrepTask | None = None,
                          actor=None) -> ProductionRun:
    """Decrement inventory by recipe.lines × batches_made and write a
    ProductionRun row for cost-of-batch reporting."""
    if batches_made <= 0:
        raise ValidationError("invalid_batches")

    cost_summary = calculate_recipe_cost(recipe)
    total_ingredient_cost = cost_summary["total_cost"] * batches_made

    run = ProductionRun.objects.create(
        prep_task=prep_task, recipe=recipe, location=location,
        batches_made=batches_made, actor=actor,
        total_ingredient_cost=total_ingredient_cost.quantize(Decimal("0.01")),
    )

    for line in recipe.ingredients_used.select_related("ingredient").all():
        ingredient = line.ingredient
        # Convert recipe-line qty to ingredient base_unit
        try:
            base_qty = convert_quantity(
                line.quantity * batches_made, line.unit, ingredient.base_unit,
            )
        except ValidationError:
            base_qty = line.quantity * batches_made

        inv_item = InventoryItem.objects.filter(
            location=location, ingredient=ingredient, is_active=True,
        ).first()
        if not inv_item:
            # Skip silently — ingredient isn't tracked at this location.
            continue
        try:
            consume_stock(
                item=inv_item, quantity=base_qty, kind="usage",
                reference=f"production:{run.id}", actor=actor,
            )
        except ValidationError:
            # Insufficient stock — record but don't crash the prep flow.
            run.notes += (
                f"\nWARN: insufficient {ingredient.name} "
                f"({base_qty} {ingredient.base_unit} requested)"
            )
            run.save(update_fields=["notes"])
    return run


def open_tasks_for_user(user, *, on_date: date | None = None) -> list[PrepTask]:
    qs = PrepTask.objects.filter(
        assigned_to=user, status__in=["pending", "in_progress"],
    ).select_related("prep_list", "recipe").order_by("priority", "sort")
    if on_date:
        qs = qs.filter(prep_list__for_date=on_date)
    return list(qs)


def daily_summary(*, restaurant_id, for_date: date) -> dict:
    """Aggregate prep status across the day."""
    lists = PrepList.objects.filter(
        restaurant_id=restaurant_id, for_date=for_date,
    ).prefetch_related("tasks")
    total = pending = in_progress = completed = skipped = 0
    for pl in lists:
        for task in pl.tasks.all():
            total += 1
            if task.status == "pending":
                pending += 1
            elif task.status == "in_progress":
                in_progress += 1
            elif task.status == "completed":
                completed += 1
            elif task.status == "skipped":
                skipped += 1
    return {
        "lists": lists.count(),
        "total_tasks": total,
        "pending": pending,
        "in_progress": in_progress,
        "completed": completed,
        "skipped": skipped,
    }
