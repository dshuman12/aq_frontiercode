from django.contrib import admin

from .models import PrepList, PrepTask, ProductionRun


class PrepTaskInline(admin.TabularInline):
    model = PrepTask
    extra = 0
    fields = ("description", "recipe", "target_quantity", "target_unit",
              "status", "priority", "assigned_to")
    autocomplete_fields = ["recipe", "assigned_to"]


@admin.register(PrepList)
class PrepListAdmin(admin.ModelAdmin):
    list_display = ("name", "for_date", "location", "station", "status")
    list_filter = ("status", "for_date", "location")
    search_fields = ("name",)
    inlines = [PrepTaskInline]


@admin.register(PrepTask)
class PrepTaskAdmin(admin.ModelAdmin):
    list_display = ("description", "prep_list", "status", "priority",
                    "assigned_to", "completed_at")
    list_filter = ("status", "priority")
    search_fields = ("description",)


@admin.register(ProductionRun)
class ProductionRunAdmin(admin.ModelAdmin):
    list_display = ("recipe", "location", "batches_made",
                    "total_ingredient_cost", "created_at")
    list_filter = ("location",)
