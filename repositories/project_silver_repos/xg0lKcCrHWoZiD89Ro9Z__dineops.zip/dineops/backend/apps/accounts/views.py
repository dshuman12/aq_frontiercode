from __future__ import annotations

from django.contrib.auth import login as django_login, logout as django_logout
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from . import services
from .models import Session
from .serializers import (
    LoginSerializer,
    PasswordResetConfirmSerializer,
    PasswordResetRequestSerializer,
    RegisterSerializer,
    SessionSerializer,
    UserSerializer,
    VerifyEmailSerializer,
)


class RegisterView(APIView):
    permission_classes = (AllowAny,)

    def post(self, request):
        s = RegisterSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        user, _verify_token = services.register_user(
            email=s.validated_data["email"],
            password=s.validated_data["password"],
            full_name=s.validated_data["full_name"],
            locale=s.validated_data["locale"],
            timezone_=s.validated_data["timezone"],
        )
        django_login(request, user, backend="django.contrib.auth.backends.ModelBackend")
        services.record_session(
            user=user,
            session_key=request.session.session_key or "",
            ip=request.META.get("REMOTE_ADDR"),
            user_agent=request.headers.get("User-Agent", ""),
        )
        return Response({"user": UserSerializer(user).data}, status=status.HTTP_201_CREATED)


class LoginView(APIView):
    permission_classes = (AllowAny,)

    def post(self, request):
        s = LoginSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        user = services.login_user(
            email=s.validated_data["email"],
            password=s.validated_data["password"],
            two_factor=s.validated_data.get("two_factor"),
            request=request,
        )
        django_login(request, user)
        services.record_session(
            user=user,
            session_key=request.session.session_key or "",
            ip=request.META.get("REMOTE_ADDR"),
            user_agent=request.headers.get("User-Agent", ""),
        )
        return Response({"user": UserSerializer(user).data})


class LogoutView(APIView):
    def post(self, request):
        django_logout(request)
        return Response({"ok": True})


class MeView(APIView):
    def get(self, request):
        return Response({"user": UserSerializer(request.user).data})


class PasswordResetRequestView(APIView):
    permission_classes = (AllowAny,)

    def post(self, request):
        s = PasswordResetRequestSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        # Don't leak existence — always return ok.
        services.start_password_reset(email=s.validated_data["email"])
        return Response({"ok": True})


class PasswordResetConfirmView(APIView):
    permission_classes = (AllowAny,)

    def post(self, request):
        s = PasswordResetConfirmSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        services.apply_password_reset(
            token=s.validated_data["token"],
            new_password=s.validated_data["password"],
        )
        return Response({"ok": True})


class VerifyEmailView(APIView):
    permission_classes = (AllowAny,)

    def post(self, request):
        s = VerifyEmailSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        services.verify_email(token=s.validated_data["token"])
        return Response({"ok": True})


class SessionListView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request):
        items = (
            Session.objects.filter(user=request.user, revoked_at__isnull=True)
            .order_by("-last_seen_at")[:50]
        )
        return Response({"results": SessionSerializer(items, many=True).data})


class SessionRevokeView(APIView):
    permission_classes = (IsAuthenticated,)

    def delete(self, request, session_id):
        services.revoke_session(user=request.user, session_id=session_id)
        return Response({"ok": True})
