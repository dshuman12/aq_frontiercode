"""TOTP helpers for the 2FA flow. Uses pure stdlib hmac so we don't need
to depend on a third-party TOTP package; the algorithm is RFC 6238."""
from __future__ import annotations

import base64
import hashlib
import hmac
import os
import struct
import time
from urllib.parse import quote


def generate_secret(num_bytes: int = 20) -> str:
    """Returns a base32-encoded secret."""
    raw = os.urandom(num_bytes)
    return base64.b32encode(raw).decode().rstrip("=")


def generate_totp(secret: str, t: int | None = None, step: int = 30, digits: int = 6) -> str:
    if t is None:
        t = int(time.time())
    counter = t // step
    key = base64.b32decode(secret + "=" * ((-len(secret)) % 8), casefold=True)
    msg = struct.pack(">Q", counter)
    digest = hmac.new(key, msg, hashlib.sha1).digest()
    offset = digest[-1] & 0x0F
    code_bytes = digest[offset : offset + 4]
    code = struct.unpack(">I", code_bytes)[0] & 0x7FFFFFFF
    return str(code % (10 ** digits)).zfill(digits)


def verify_totp(secret: str, token: str, window: int = 1) -> bool:
    if not secret or not token:
        return False
    t = int(time.time())
    for delta in range(-window, window + 1):
        if generate_totp(secret, t + delta * 30) == token:
            return True
    return False


def otpauth_url(secret: str, label: str, issuer: str = "DineOps") -> str:
    label_q = quote(f"{issuer}:{label}")
    issuer_q = quote(issuer)
    return f"otpauth://totp/{label_q}?secret={secret}&issuer={issuer_q}&digits=6&period=30"
