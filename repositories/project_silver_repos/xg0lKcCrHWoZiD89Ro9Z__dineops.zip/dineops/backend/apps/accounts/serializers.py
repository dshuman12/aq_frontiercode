from __future__ import annotations

from django.contrib.auth.password_validation import validate_password
from rest_framework import serializers

from .models import Session, User


class UserSerializer(serializers.ModelSerializer):
    email_verified = serializers.BooleanField(read_only=True)
    two_factor_enabled = serializers.BooleanField(read_only=True)

    class Meta:
        model = User
        fields = (
            "id", "email", "full_name", "phone", "avatar_url",
            "timezone", "locale", "email_verified", "two_factor_enabled",
            "is_platform_admin", "created_at",
        )
        read_only_fields = ("id", "email_verified", "two_factor_enabled",
                            "is_platform_admin", "created_at")


class RegisterSerializer(serializers.Serializer):
    email = serializers.EmailField(max_length=254)
    password = serializers.CharField(write_only=True, min_length=8, max_length=128)
    full_name = serializers.CharField(max_length=120, min_length=2)
    locale = serializers.CharField(max_length=16, required=False, default="en-US")
    timezone = serializers.CharField(max_length=64, required=False, default="UTC")

    def validate_password(self, value: str) -> str:
        validate_password(value)
        if not any(c.isupper() for c in value):
            raise serializers.ValidationError("Password must contain at least one uppercase letter.")
        if not any(c.isdigit() for c in value):
            raise serializers.ValidationError("Password must contain at least one digit.")
        return value


class LoginSerializer(serializers.Serializer):
    email = serializers.EmailField()
    password = serializers.CharField(write_only=True)
    two_factor = serializers.RegexField(regex=r"^\d{6}$", required=False, allow_blank=True)


class PasswordResetRequestSerializer(serializers.Serializer):
    email = serializers.EmailField()


class PasswordResetConfirmSerializer(serializers.Serializer):
    token = serializers.CharField()
    password = serializers.CharField(min_length=8, max_length=128)


class VerifyEmailSerializer(serializers.Serializer):
    token = serializers.CharField()


class SessionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Session
        fields = ("id", "ip", "user_agent", "location", "last_seen_at", "created_at")
