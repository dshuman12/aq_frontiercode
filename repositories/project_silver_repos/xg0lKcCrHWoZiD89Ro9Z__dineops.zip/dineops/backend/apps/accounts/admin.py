from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as DjangoUserAdmin

from .models import EmailToken, Session, User


@admin.register(User)
class UserAdmin(DjangoUserAdmin):
    list_display = ("email", "full_name", "is_active", "is_staff", "email_verified", "created_at")
    search_fields = ("email", "full_name")
    ordering = ("-created_at",)
    fieldsets = (
        (None, {"fields": ("email", "password", "full_name", "phone", "avatar_url")}),
        ("Profile", {"fields": ("timezone", "locale")}),
        ("Permissions", {"fields": ("is_active", "is_staff", "is_superuser", "is_platform_admin", "groups", "user_permissions")}),
        ("2FA", {"fields": ("two_factor_enabled",)}),
        ("Important dates", {"fields": ("last_login_at", "email_verified_at", "created_at", "updated_at")}),
    )
    readonly_fields = ("last_login_at", "created_at", "updated_at")
    add_fieldsets = (
        (None, {"classes": ("wide",), "fields": ("email", "full_name", "password1", "password2")}),
    )


@admin.register(EmailToken)
class EmailTokenAdmin(admin.ModelAdmin):
    list_display = ("user", "kind", "consumed_at", "expires_at", "created_at")
    list_filter = ("kind",)
    search_fields = ("user__email",)


@admin.register(Session)
class SessionAdmin(admin.ModelAdmin):
    list_display = ("user", "ip", "last_seen_at", "revoked_at")
    search_fields = ("user__email", "ip")
