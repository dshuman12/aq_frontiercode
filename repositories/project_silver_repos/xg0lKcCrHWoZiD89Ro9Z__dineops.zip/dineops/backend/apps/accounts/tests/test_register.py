import pytest
from django.urls import reverse
from rest_framework import status

from apps.accounts.models import EmailToken, User


@pytest.mark.django_db
class TestRegister:
    url = "/api/auth/register/"

    def test_register_creates_user(self, api_client):
        resp = api_client.post(self.url, {
            "email": "ali@example.com",
            "password": "Strong1pass",
            "full_name": "Ali Hyder",
        }, format="json")
        assert resp.status_code == status.HTTP_201_CREATED
        assert resp.data["user"]["email"] == "ali@example.com"
        assert User.objects.filter(email="ali@example.com").exists()

    def test_register_creates_verify_token(self, api_client):
        api_client.post(self.url, {
            "email": "v@example.com", "password": "Strong1pass", "full_name": "V",
        }, format="json")
        assert EmailToken.objects.filter(kind="verify_email").count() == 1

    def test_register_logs_session(self, api_client):
        resp = api_client.post(self.url, {
            "email": "s@example.com", "password": "Strong1pass", "full_name": "S",
        }, format="json")
        assert resp.status_code == 201
        # Should now be authenticated
        me = api_client.get("/api/auth/me/")
        assert me.status_code == 200
        assert me.data["user"]["email"] == "s@example.com"

    def test_register_email_taken_returns_409(self, api_client):
        User.objects.create_user(email="dup@example.com", password="x", full_name="D")
        resp = api_client.post(self.url, {
            "email": "dup@example.com", "password": "Strong1pass", "full_name": "D2",
        }, format="json")
        assert resp.status_code == status.HTTP_409_CONFLICT

    def test_register_lowercases_email(self, api_client):
        api_client.post(self.url, {
            "email": "MixedCase@Example.com", "password": "Strong1pass", "full_name": "M",
        }, format="json")
        assert User.objects.filter(email="mixedcase@example.com").exists()

    def test_register_password_must_have_uppercase(self, api_client):
        resp = api_client.post(self.url, {
            "email": "u@example.com", "password": "lowercase1", "full_name": "U",
        }, format="json")
        assert resp.status_code == 400

    def test_register_password_must_have_digit(self, api_client):
        resp = api_client.post(self.url, {
            "email": "u@example.com", "password": "NoDigits", "full_name": "U",
        }, format="json")
        assert resp.status_code == 400

    def test_register_password_too_short(self, api_client):
        resp = api_client.post(self.url, {
            "email": "u@example.com", "password": "Sh1", "full_name": "U",
        }, format="json")
        assert resp.status_code == 400

    def test_register_invalid_email(self, api_client):
        resp = api_client.post(self.url, {
            "email": "not-an-email", "password": "Strong1pass", "full_name": "U",
        }, format="json")
        assert resp.status_code == 400

    def test_register_full_name_too_short(self, api_client):
        resp = api_client.post(self.url, {
            "email": "u@example.com", "password": "Strong1pass", "full_name": "X",
        }, format="json")
        assert resp.status_code == 400
