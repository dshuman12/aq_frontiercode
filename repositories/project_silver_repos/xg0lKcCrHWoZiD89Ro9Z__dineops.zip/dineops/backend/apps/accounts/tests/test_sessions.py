import pytest
from rest_framework.test import APIClient

from apps.accounts.models import Session, User


@pytest.fixture
def logged_in(db):
    User.objects.create_user(email="s@example.com", password="Strong1pass", full_name="S")
    client = APIClient()
    client.post("/api/auth/login/", {
        "email": "s@example.com", "password": "Strong1pass",
    }, format="json")
    return client


@pytest.mark.django_db
class TestSessions:
    def test_list_returns_active_sessions(self, logged_in):
        resp = logged_in.get("/api/auth/sessions/")
        assert resp.status_code == 200
        assert len(resp.data["results"]) >= 1

    def test_list_unauth_403(self, api_client):
        resp = api_client.get("/api/auth/sessions/")
        assert resp.status_code in (401, 403)

    def test_revoke_unknown_returns_404(self, logged_in):
        import uuid
        resp = logged_in.delete(f"/api/auth/sessions/{uuid.uuid4()}/")
        assert resp.status_code == 404

    def test_revoke_marks_revoked_at(self, logged_in):
        sess = Session.objects.first()
        resp = logged_in.delete(f"/api/auth/sessions/{sess.id}/")
        assert resp.status_code == 200
        sess.refresh_from_db()
        assert sess.revoked_at is not None
