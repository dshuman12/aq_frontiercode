import time

import pytest

from apps.accounts.twofactor import (
    generate_secret,
    generate_totp,
    otpauth_url,
    verify_totp,
)


def test_generate_secret_is_base32():
    s = generate_secret()
    assert len(s) > 0
    # base32 chars only
    for ch in s:
        assert ch in "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"


def test_totp_round_trip():
    secret = generate_secret()
    code = generate_totp(secret)
    assert verify_totp(secret, code) is True


def test_totp_rejects_wrong_code():
    secret = generate_secret()
    assert verify_totp(secret, "000000") is False


def test_totp_window_accepts_previous_step():
    secret = generate_secret()
    now = int(time.time())
    prev_code = generate_totp(secret, t=now - 30)
    assert verify_totp(secret, prev_code, window=1) is True


def test_totp_rejects_far_in_past():
    secret = generate_secret()
    old_code = generate_totp(secret, t=int(time.time()) - 600)
    assert verify_totp(secret, old_code, window=1) is False


def test_verify_totp_with_blank_inputs():
    assert verify_totp("", "123456") is False
    assert verify_totp(generate_secret(), "") is False


def test_otpauth_url_format():
    url = otpauth_url("ABCDEFGHIJKLMNOP", "user@example.com")
    assert url.startswith("otpauth://totp/DineOps")
    assert "secret=ABCDEFGHIJKLMNOP" in url
    assert "issuer=DineOps" in url
