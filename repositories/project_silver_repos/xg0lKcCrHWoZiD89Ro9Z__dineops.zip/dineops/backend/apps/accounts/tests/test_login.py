import pytest
from rest_framework import status

from apps.accounts.models import User


@pytest.fixture
def existing_user(db):
    return User.objects.create_user(
        email="u@example.com", password="Strong1pass", full_name="U",
    )


@pytest.mark.django_db
class TestLogin:
    url = "/api/auth/login/"

    def test_login_happy(self, api_client, existing_user):
        resp = api_client.post(self.url, {
            "email": "u@example.com", "password": "Strong1pass",
        }, format="json")
        assert resp.status_code == status.HTTP_200_OK
        assert resp.data["user"]["email"] == "u@example.com"

    def test_login_lowercase_email_match(self, api_client, existing_user):
        resp = api_client.post(self.url, {
            "email": "U@Example.com", "password": "Strong1pass",
        }, format="json")
        assert resp.status_code == 200

    def test_login_wrong_password_returns_400_invalid_credentials(self, api_client, existing_user):
        resp = api_client.post(self.url, {
            "email": "u@example.com", "password": "wrong",
        }, format="json")
        assert resp.status_code == 400
        assert resp.data["code"] == "invalid_credentials"

    def test_login_unknown_email_invalid_credentials(self, api_client):
        resp = api_client.post(self.url, {
            "email": "ghost@example.com", "password": "x",
        }, format="json")
        assert resp.status_code == 400
        assert resp.data["code"] == "invalid_credentials"

    def test_login_inactive_user(self, api_client, existing_user):
        existing_user.is_active = False
        existing_user.save()
        resp = api_client.post(self.url, {
            "email": "u@example.com", "password": "Strong1pass",
        }, format="json")
        assert resp.status_code == 400


@pytest.mark.django_db
class TestLogout:
    def test_logout_clears_session(self, api_client, existing_user):
        api_client.post("/api/auth/login/", {
            "email": "u@example.com", "password": "Strong1pass",
        }, format="json")
        resp = api_client.post("/api/auth/logout/")
        assert resp.status_code == 200
        # /me/ now requires auth → 403/401
        me = api_client.get("/api/auth/me/")
        assert me.status_code in (401, 403)
