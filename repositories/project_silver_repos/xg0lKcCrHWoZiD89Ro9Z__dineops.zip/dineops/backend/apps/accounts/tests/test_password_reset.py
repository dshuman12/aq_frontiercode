import pytest
from django.utils import timezone
from datetime import timedelta

from apps.accounts.models import EmailToken, User
from apps.accounts.services import (
    apply_password_reset,
    start_password_reset,
    verify_email,
)


@pytest.mark.django_db
class TestPasswordReset:
    def test_request_unknown_email_returns_none_no_leak(self, api_client):
        # Service-level: returns None
        assert start_password_reset(email="ghost@example.com") is None
        # API-level: still responds 200 with ok:True (don't leak existence)
        resp = api_client.post("/api/auth/password-reset/request/", {
            "email": "ghost@example.com",
        }, format="json")
        assert resp.status_code == 200
        assert resp.data["ok"] is True

    def test_request_creates_reset_token(self, api_client):
        User.objects.create_user(email="u@example.com", password="x", full_name="U")
        api_client.post("/api/auth/password-reset/request/", {"email": "u@example.com"},
                        format="json")
        assert EmailToken.objects.filter(kind="password_reset").count() == 1

    def test_apply_reset_changes_password(self, api_client):
        u = User.objects.create_user(email="u@example.com", password="OldOne1", full_name="U")
        result = start_password_reset(email="u@example.com")
        assert result is not None
        _user, raw_token = result
        apply_password_reset(token=raw_token, new_password="NewerPass2")
        u.refresh_from_db()
        assert u.check_password("NewerPass2")

    def test_apply_reset_with_bad_token_400(self, api_client):
        resp = api_client.post("/api/auth/password-reset/confirm/", {
            "token": "garbage", "password": "Strong1pass",
        }, format="json")
        assert resp.status_code == 400

    def test_apply_reset_with_expired_token(self, api_client):
        u = User.objects.create_user(email="u@example.com", password="OldOne1", full_name="U")
        result = start_password_reset(email="u@example.com")
        _user, raw_token = result
        # Force expiry
        EmailToken.objects.filter(kind="password_reset").update(
            expires_at=timezone.now() - timedelta(seconds=1)
        )
        from apps.common.exceptions import ValidationError as DomainValidationError
        with pytest.raises(DomainValidationError):
            apply_password_reset(token=raw_token, new_password="NewerPass2")

    def test_token_consumed_after_use(self, api_client):
        User.objects.create_user(email="u@example.com", password="OldOne1", full_name="U")
        _user, raw_token = start_password_reset(email="u@example.com")
        apply_password_reset(token=raw_token, new_password="NewerPass2")
        rec = EmailToken.objects.get(kind="password_reset")
        assert rec.consumed_at is not None
        # Second use should fail
        from apps.common.exceptions import ValidationError as DomainValidationError
        with pytest.raises(DomainValidationError):
            apply_password_reset(token=raw_token, new_password="X")


@pytest.mark.django_db
class TestVerifyEmail:
    def test_verify_marks_email_verified_at(self, api_client):
        from apps.accounts.services import register_user

        user, raw = register_user(email="v@example.com", password="Strong1pass", full_name="V")
        assert user.email_verified_at is None
        verify_email(token=raw)
        user.refresh_from_db()
        assert user.email_verified_at is not None

    def test_verify_with_bad_token_400(self, api_client):
        resp = api_client.post("/api/auth/verify-email/", {"token": "garbage"}, format="json")
        assert resp.status_code == 400
