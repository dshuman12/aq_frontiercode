"""Auth domain services. Side-effecting; never raise DRF exceptions directly."""
from __future__ import annotations

from datetime import timedelta

from django.contrib.auth import authenticate
from django.db import transaction
from django.utils import timezone

from apps.common.exceptions import Conflict, DomainError, NotFound, ValidationError

from .models import EmailToken, Session, User


@transaction.atomic
def register_user(*, email: str, password: str, full_name: str, locale: str = "en-US",
                  timezone_: str = "UTC") -> tuple[User, str]:
    """Register a new user; returns (user, raw_verify_token)."""
    if User.objects.filter(email__iexact=email).exists():
        raise Conflict("email_taken", "That email is already registered.")
    user = User.objects.create_user(
        email=email,
        password=password,
        full_name=full_name,
        locale=locale,
        timezone=timezone_,
    )
    raw = EmailToken.make_raw_token()
    EmailToken.objects.create(
        user=user,
        kind=EmailToken.KIND_VERIFY,
        token_hash=EmailToken.hash_token(raw),
        expires_at=timezone.now() + timedelta(hours=48),
    )
    return user, raw


def login_user(*, email: str, password: str, two_factor: str | None = None,
               request=None) -> User:
    """Authenticate; raises ValidationError on bad creds. 2FA handled here."""
    user = authenticate(request=request, username=email, password=password)
    if user is None or not user.is_active:
        raise ValidationError("invalid_credentials", "Invalid email or password.")
    if user.two_factor_enabled:
        if not two_factor:
            raise ValidationError("twofactor_required", "Two-factor code required.")
        from .twofactor import verify_totp

        if not verify_totp(user.two_factor_secret, two_factor):
            raise ValidationError("twofactor_invalid", "Invalid two-factor code.")
    user.last_login_at = timezone.now()
    user.save(update_fields=["last_login_at"])
    return user


def record_session(*, user: User, session_key: str, ip: str | None = None,
                   user_agent: str = "") -> Session:
    return Session.objects.create(
        user=user,
        session_key=session_key,
        ip=ip,
        user_agent=user_agent[:400],
    )


def revoke_session(*, user: User, session_id) -> Session:
    sess = Session.objects.filter(id=session_id, user=user, revoked_at__isnull=True).first()
    if not sess:
        raise NotFound("session_not_found")
    sess.revoked_at = timezone.now()
    sess.save(update_fields=["revoked_at"])
    return sess


@transaction.atomic
def start_password_reset(*, email: str) -> tuple[User, str] | None:
    """Returns (user, raw_token) or None — never leaks whether email exists."""
    user = User.objects.filter(email__iexact=email).first()
    if not user:
        return None
    raw = EmailToken.make_raw_token()
    EmailToken.objects.create(
        user=user,
        kind=EmailToken.KIND_RESET,
        token_hash=EmailToken.hash_token(raw),
        expires_at=timezone.now() + timedelta(hours=1),
    )
    return user, raw


@transaction.atomic
def apply_password_reset(*, token: str, new_password: str) -> User:
    rec = consume_email_token(token=token, kind=EmailToken.KIND_RESET)
    if rec is None or rec.user is None:
        raise ValidationError("invalid_or_expired_token")
    rec.user.set_password(new_password)
    rec.user.save(update_fields=["password"])
    # Revoke all existing sessions for safety
    Session.objects.filter(user=rec.user, revoked_at__isnull=True).update(
        revoked_at=timezone.now()
    )
    return rec.user


def consume_email_token(*, token: str, kind: str) -> EmailToken | None:
    """Returns the EmailToken if valid + unconsumed, marking it consumed."""
    h = EmailToken.hash_token(token)
    rec = EmailToken.objects.filter(token_hash=h, kind=kind, consumed_at__isnull=True).first()
    if rec is None or rec.expires_at < timezone.now():
        return None
    rec.consumed_at = timezone.now()
    rec.save(update_fields=["consumed_at"])
    return rec


def verify_email(*, token: str) -> User:
    rec = consume_email_token(token=token, kind=EmailToken.KIND_VERIFY)
    if rec is None or rec.user is None:
        raise ValidationError("invalid_or_expired_token")
    rec.user.mark_email_verified()
    return rec.user
