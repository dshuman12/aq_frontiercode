from __future__ import annotations

from typing import Any

from django.db import transaction

from .models import AuditEntry


@transaction.atomic
def record(*, action: str, resource_type: str, resource_id: str = "",
           resource_label: str = "",
           summary: str,
           actor=None, restaurant=None,
           severity: str = "info",
           before: dict | None = None, after: dict | None = None,
           metadata: dict | None = None,
           request=None) -> AuditEntry:
    """Generic audit recorder. Pulls IP/path/UA from `request` if given."""
    request_ip = ""
    request_path = ""
    user_agent = ""
    if request is not None:
        request_ip = request.META.get("REMOTE_ADDR", "")
        request_path = request.path
        user_agent = request.META.get("HTTP_USER_AGENT", "")[:300]

    return AuditEntry.objects.create(
        restaurant=restaurant,
        actor=actor,
        actor_email_snapshot=getattr(actor, "email", "") if actor else "",
        action=action,
        resource_type=resource_type,
        resource_id=str(resource_id),
        resource_label=resource_label[:200],
        severity=severity,
        summary=summary[:300],
        before=before or {},
        after=after or {},
        metadata=metadata or {},
        request_ip=request_ip[:64],
        request_path=request_path[:300],
        user_agent=user_agent,
    )


def diff(before: dict, after: dict) -> dict:
    """Compute a small per-field diff. Useful for audit metadata."""
    changes = {}
    keys = set(before.keys()) | set(after.keys())
    for k in keys:
        b = before.get(k)
        a = after.get(k)
        if b != a:
            changes[k] = {"before": b, "after": a}
    return changes
