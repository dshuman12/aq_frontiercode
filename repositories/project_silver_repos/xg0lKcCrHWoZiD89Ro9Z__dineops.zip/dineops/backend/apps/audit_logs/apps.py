from django.apps import AppConfig


class AuditLogsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.audit_logs"

    def ready(self):
        try:
            from . import handlers  # noqa: F401
        except ImportError:
            pass
