from __future__ import annotations

from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common.exceptions import PermissionDenied
from apps.restaurants.models import RestaurantMember

from .models import AuditEntry
from .serializers import AuditEntrySerializer


def _require_member(user, restaurant_id):
    m = RestaurantMember.objects.filter(
        restaurant_id=restaurant_id, user=user, status="active",
    ).first()
    if not m:
        raise PermissionDenied("not_a_member")
    return m


def _can_view_audit(roles):
    return any(r in ("owner", "general_manager", "accountant")
               for r in roles or [])


class AuditListView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_view_audit(member.roles):
            raise PermissionDenied()
        qs = AuditEntry.objects.filter(
            restaurant_id=restaurant_id,
        ).select_related("actor").order_by("-created_at")
        if (action := request.GET.get("action")):
            qs = qs.filter(action=action)
        if (rtype := request.GET.get("resource_type")):
            qs = qs.filter(resource_type=rtype)
        if (actor := request.GET.get("actor_id")):
            qs = qs.filter(actor_id=actor)
        if (severity := request.GET.get("severity")):
            qs = qs.filter(severity=severity)
        return Response({"results": AuditEntrySerializer(
            qs[:200], many=True,
        ).data})


class AuditDetailView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id, entry_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_view_audit(member.roles):
            raise PermissionDenied()
        e = AuditEntry.objects.filter(
            id=entry_id, restaurant_id=restaurant_id,
        ).first()
        if not e:
            from apps.common.exceptions import NotFound
            raise NotFound()
        return Response({"entry": AuditEntrySerializer(e).data})
