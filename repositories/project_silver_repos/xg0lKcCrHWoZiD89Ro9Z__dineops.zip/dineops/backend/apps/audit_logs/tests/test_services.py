from __future__ import annotations

from decimal import Decimal

import pytest

from apps.accounts.models import User
from apps.audit_logs.models import AuditEntry
from apps.audit_logs.services import diff, record
from apps.locations.models import Location
from apps.menus.services import create_menu_item
from apps.orders.services import (
    add_item, create_order, fire_to_kitchen, mark_order_served, submit_order,
    void_order,
)
from apps.payments.services import issue_refund, record_cash_payment
from apps.restaurants.models import Restaurant


pytestmark = pytest.mark.django_db


class TestRecord:
    def test_basic(self):
        u = User.objects.create_user(email="a@x.com", password="pwpwpwpw")
        e = record(
            action="test.action", resource_type="Thing",
            resource_id="123", summary="did a thing", actor=u,
        )
        assert e.actor_email_snapshot == "a@x.com"
        assert e.resource_id == "123"

    def test_records_request_metadata(self):
        from django.test import RequestFactory
        rf = RequestFactory()
        request = rf.get("/api/x/", HTTP_USER_AGENT="DineOps test client")
        u = User.objects.create_user(email="a@x.com", password="pwpwpwpw")
        e = record(
            action="x", resource_type="Y", summary="z", actor=u, request=request,
        )
        assert e.user_agent == "DineOps test client"
        assert e.request_path == "/api/x/"

    def test_diff(self):
        out = diff({"a": 1, "b": 2}, {"a": 1, "b": 3, "c": 4})
        assert "a" not in out
        assert out["b"]["before"] == 2
        assert out["c"]["after"] == 4


class TestAuditFromHandlers:
    def test_void_order_creates_audit(self):
        owner = User.objects.create_user(email="o@x.com", password="pwpwpwpw")
        rest = Restaurant.objects.create(
            name="R", slug="r", owner=owner,
            default_tax_percent=Decimal("0"),
            default_service_charge_percent=Decimal("0"),
        )
        loc = Location.objects.create(
            restaurant=rest, name="Main", slug="main", accepts_dine_in=True,
        )
        item = create_menu_item(restaurant=rest, name="X",
                                base_price=Decimal("10"))
        order = create_order(restaurant=rest, location=loc,
                             table_number="1", server=owner)
        add_item(order=order, menu_item=item, quantity=1)
        void_order(order=order, actor=owner, reason="walked")
        entries = AuditEntry.objects.filter(action="order.voided")
        assert entries.count() == 1
        e = entries.first()
        assert e.severity == "alert"

    def test_refund_creates_audit(self):
        owner = User.objects.create_user(email="o@x.com", password="pwpwpwpw")
        rest = Restaurant.objects.create(
            name="R", slug="r", owner=owner,
            default_tax_percent=Decimal("0"),
            default_service_charge_percent=Decimal("0"),
        )
        loc = Location.objects.create(
            restaurant=rest, name="Main", slug="main", accepts_dine_in=True,
        )
        item = create_menu_item(restaurant=rest, name="X",
                                base_price=Decimal("20"))
        order = create_order(restaurant=rest, location=loc,
                             table_number="1", server=owner)
        add_item(order=order, menu_item=item, quantity=1)
        submit_order(order=order)
        fire_to_kitchen(order=order)
        mark_order_served(order=order)
        order.refresh_from_db()
        p = record_cash_payment(order=order, amount=Decimal("20"))
        issue_refund(payment=p, amount=Decimal("5"), actor=owner,
                     reason="customer complaint")
        entries = AuditEntry.objects.filter(action="payment.refund")
        assert entries.count() == 1
