from django.urls import path

from . import views

app_name = "audit_logs"

urlpatterns = [
    path("<uuid:restaurant_id>/",
         views.AuditListView.as_view(), name="list"),
    path("<uuid:restaurant_id>/<uuid:entry_id>/",
         views.AuditDetailView.as_view(), name="detail"),
]
