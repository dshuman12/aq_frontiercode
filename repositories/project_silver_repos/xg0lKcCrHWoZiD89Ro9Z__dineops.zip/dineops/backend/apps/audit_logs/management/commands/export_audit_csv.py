"""Export audit entries for a date range to CSV. Used by accountants and
auditors."""
from __future__ import annotations

import csv
import sys
from datetime import datetime, time, timedelta, timezone as dtz

from django.core.management.base import BaseCommand

from apps.audit_logs.models import AuditEntry


class Command(BaseCommand):
    help = "Export audit log to CSV (writes to stdout)."

    def add_arguments(self, parser):
        parser.add_argument("--restaurant", required=True)
        parser.add_argument("--days", type=int, default=30)

    def handle(self, *args, restaurant, days, **options):
        cutoff = datetime.now(dtz.utc) - timedelta(days=days)
        qs = AuditEntry.objects.filter(
            restaurant__slug=restaurant,
            created_at__gte=cutoff,
        ).order_by("created_at")
        writer = csv.writer(sys.stdout)
        writer.writerow([
            "created_at", "actor_email", "action", "resource_type",
            "resource_id", "severity", "summary",
        ])
        for e in qs:
            writer.writerow([
                e.created_at.isoformat(),
                e.actor_email_snapshot,
                e.action,
                e.resource_type,
                e.resource_id,
                e.severity,
                e.summary,
            ])
