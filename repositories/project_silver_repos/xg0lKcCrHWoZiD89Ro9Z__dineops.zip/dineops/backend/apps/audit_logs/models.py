from __future__ import annotations

import uuid

from django.conf import settings
from django.db import models

from apps.common.models import TimeStampedModel


class AuditEntry(TimeStampedModel):
    """Generic audit log entry. Captures: who did what to which resource,
    with optional before/after diffs and request metadata."""

    SEVERITY_CHOICES = [
        ("info", "Info"),
        ("notice", "Notice"),
        ("warning", "Warning"),
        ("alert", "Alert"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant = models.ForeignKey(
        "restaurants.Restaurant", on_delete=models.CASCADE,
        null=True, blank=True, related_name="audit_entries",
    )
    actor = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="audit_entries",
    )
    actor_email_snapshot = models.EmailField(blank=True)

    action = models.CharField(max_length=80, db_index=True,
                              help_text="dotted: 'order.void', 'staff.create'")
    resource_type = models.CharField(max_length=80, db_index=True)
    resource_id = models.CharField(max_length=80, blank=True, db_index=True)
    resource_label = models.CharField(max_length=200, blank=True)

    severity = models.CharField(max_length=20, choices=SEVERITY_CHOICES,
                                default="info")
    summary = models.CharField(max_length=300)
    before = models.JSONField(default=dict, blank=True)
    after = models.JSONField(default=dict, blank=True)
    metadata = models.JSONField(default=dict, blank=True)

    request_ip = models.CharField(max_length=64, blank=True)
    request_path = models.CharField(max_length=300, blank=True)
    user_agent = models.CharField(max_length=300, blank=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["restaurant", "-created_at"]),
            models.Index(fields=["actor", "-created_at"]),
            models.Index(fields=["resource_type", "resource_id"]),
        ]
