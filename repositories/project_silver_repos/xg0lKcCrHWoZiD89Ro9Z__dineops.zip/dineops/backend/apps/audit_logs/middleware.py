"""Resolves the "active restaurant" from URL/query string and stashes it on
the request. Permission classes and selectors use it for tenant scoping.
"""
from __future__ import annotations

from typing import Any


class AuditContextMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        request.active_restaurant_id = self._resolve_restaurant_id(request)
        request.active_member_roles = []
        if request.user.is_authenticated and request.active_restaurant_id:
            from apps.restaurants.models import RestaurantMember

            member = (
                RestaurantMember.objects.filter(
                    restaurant_id=request.active_restaurant_id,
                    user=request.user,
                    status="active",
                )
                .only("roles", "custom_permissions")
                .first()
            )
            if member:
                request.active_member_roles = member.roles or []
                request.active_custom_perms = member.custom_permissions or []
        return self.get_response(request)

    def _resolve_restaurant_id(self, request) -> Any:
        match = getattr(request, "resolver_match", None)
        if match and "restaurant_id" in match.kwargs:
            return match.kwargs["restaurant_id"]
        return request.GET.get("restaurant") or request.headers.get("X-Restaurant-Id")
