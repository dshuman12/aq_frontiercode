from __future__ import annotations

from rest_framework import serializers

from .models import AuditEntry


class AuditEntrySerializer(serializers.ModelSerializer):
    actor_email = serializers.CharField(source="actor.email", read_only=True)

    class Meta:
        model = AuditEntry
        fields = ["id", "restaurant", "actor", "actor_email", "actor_email_snapshot",
                  "action", "resource_type", "resource_id", "resource_label",
                  "severity", "summary", "before", "after", "metadata",
                  "request_ip", "request_path", "user_agent",
                  "created_at"]
