from django.contrib import admin

from .models import AuditEntry


@admin.register(AuditEntry)
class AuditEntryAdmin(admin.ModelAdmin):
    list_display = ("created_at", "actor_email_snapshot", "action",
                    "resource_type", "resource_label", "severity")
    list_filter = ("action", "resource_type", "severity")
    search_fields = ("summary", "resource_label", "resource_id",
                     "actor_email_snapshot")
    readonly_fields = ("created_at", "updated_at", "actor", "before",
                       "after", "metadata", "request_ip",
                       "request_path", "user_agent")
