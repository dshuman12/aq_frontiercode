"""Bridges from app-domain events to the audit log. Wire up signals and
service-layer hooks here to keep audit recording out of the core business
logic."""
from __future__ import annotations

from django.db.models.signals import post_save
from django.dispatch import receiver

from apps.orders.models import Order, OrderEvent
from apps.payments.models import Payment, Refund

from .services import record


@receiver(post_save, sender=OrderEvent)
def audit_order_event(sender, instance: OrderEvent, created, **kwargs):
    if not created:
        return
    if instance.kind in ("voided", "discount_applied", "item_voided",
                         "item_comped"):
        order = instance.order
        record(
            action=f"order.{instance.kind}",
            resource_type="Order",
            resource_id=str(order.id),
            resource_label=f"Order #{order.order_number}",
            summary=f"{instance.kind.replace('_', ' ').title()} on order #{order.order_number}",
            actor=instance.actor,
            restaurant=order.restaurant,
            severity="alert" if instance.kind == "voided" else "notice",
            metadata=dict(instance.payload or {}),
        )


@receiver(post_save, sender=Refund)
def audit_refund(sender, instance: Refund, created, **kwargs):
    if not created:
        return
    payment = instance.payment
    record(
        action="payment.refund",
        resource_type="Refund",
        resource_id=str(instance.id),
        resource_label=f"Refund of {instance.amount} on Order #{payment.order.order_number}",
        summary=f"Refund of ${instance.amount}: {instance.reason or '(no reason)'}",
        actor=instance.actor,
        restaurant=payment.restaurant,
        severity="alert",
        metadata={"payment_id": str(payment.id), "method": payment.method},
    )
