from __future__ import annotations

import uuid
from decimal import Decimal

from django.conf import settings
from django.db import models

from apps.common.models import TimeStampedModel


class Order(TimeStampedModel):
    """A customer check / order. Orders move through:
       pending → submitted → in_kitchen → ready → served → paid → closed
    Cancellable up through 'in_kitchen' (with reason)."""

    STATUS_CHOICES = [
        ("pending", "Pending"),
        ("submitted", "Submitted"),
        ("in_kitchen", "In kitchen"),
        ("ready", "Ready"),
        ("served", "Served"),
        ("paid", "Paid"),
        ("closed", "Closed"),
        ("voided", "Voided"),
    ]

    KIND_CHOICES = [
        ("dine_in", "Dine in"),
        ("takeout", "Takeout"),
        ("delivery", "Delivery"),
        ("bar", "Bar"),
        ("counter", "Counter"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant = models.ForeignKey(
        "restaurants.Restaurant", on_delete=models.CASCADE, related_name="orders",
    )
    location = models.ForeignKey(
        "locations.Location", on_delete=models.PROTECT, related_name="orders",
    )
    order_number = models.CharField(max_length=20, db_index=True,
                                    help_text="Daily-incrementing per-location.")
    kind = models.CharField(max_length=20, choices=KIND_CHOICES, default="dine_in")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="pending")

    table_number = models.CharField(max_length=20, blank=True)
    guest_count = models.PositiveSmallIntegerField(default=1)
    customer_name = models.CharField(max_length=160, blank=True)
    customer_phone = models.CharField(max_length=40, blank=True)

    server = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="server_orders",
    )
    cashier = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="cashier_orders",
    )

    submitted_at = models.DateTimeField(null=True, blank=True)
    in_kitchen_at = models.DateTimeField(null=True, blank=True)
    ready_at = models.DateTimeField(null=True, blank=True)
    served_at = models.DateTimeField(null=True, blank=True)
    paid_at = models.DateTimeField(null=True, blank=True)
    closed_at = models.DateTimeField(null=True, blank=True)
    voided_at = models.DateTimeField(null=True, blank=True)
    void_reason = models.CharField(max_length=200, blank=True)

    subtotal = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    discount_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    discount_reason = models.CharField(max_length=200, blank=True)
    tax_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    service_charge_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    tip_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    total_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    amount_paid = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    balance_due = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    currency = models.CharField(max_length=3, default="USD")

    notes = models.TextField(blank=True)

    class Meta:
        ordering = ["-created_at"]
        constraints = [
            models.UniqueConstraint(
                fields=["location", "order_number"],
                name="unique_order_number_per_location",
            ),
        ]
        indexes = [
            models.Index(fields=["restaurant", "status"]),
            models.Index(fields=["location", "status"]),
            models.Index(fields=["table_number"]),
            models.Index(fields=["created_at"]),
        ]

    def __str__(self) -> str:
        return f"Order #{self.order_number}"

    @property
    def is_open(self) -> bool:
        return self.status not in ("paid", "closed", "voided")


class OrderItem(TimeStampedModel):
    """A line on the order. References a MenuItem at order time, captures the
    price snapshot, plus chosen variant and modifier breakdown."""

    STATUS_CHOICES = [
        ("pending", "Pending"),
        ("sent_to_kitchen", "Sent to kitchen"),
        ("in_progress", "In progress"),
        ("ready", "Ready"),
        ("served", "Served"),
        ("voided", "Voided"),
        ("comped", "Comped"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="items")
    course = models.PositiveSmallIntegerField(default=1)
    sort = models.PositiveIntegerField(default=0)

    menu_item = models.ForeignKey(
        "menus.MenuItem", on_delete=models.PROTECT, related_name="order_lines",
    )
    variant = models.ForeignKey(
        "menus.MenuItemVariant", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="+",
    )
    item_name_snapshot = models.CharField(max_length=200)
    quantity = models.PositiveIntegerField(default=1)

    unit_price = models.DecimalField(max_digits=10, decimal_places=2)
    modifiers_total = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    line_subtotal = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    discount_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    line_total = models.DecimalField(max_digits=12, decimal_places=2, default=0)

    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="pending")
    void_reason = models.CharField(max_length=200, blank=True)
    voided_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="+",
    )
    sent_at = models.DateTimeField(null=True, blank=True)
    ready_at = models.DateTimeField(null=True, blank=True)
    served_at = models.DateTimeField(null=True, blank=True)
    special_request = models.CharField(max_length=300, blank=True)
    age_verified_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="age_verified_items",
    )

    class Meta:
        ordering = ["course", "sort", "created_at"]
        indexes = [
            models.Index(fields=["order", "status"]),
            models.Index(fields=["status"]),
        ]


class OrderItemModifier(TimeStampedModel):
    """A chosen modifier option on an order item (snapshot)."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    order_item = models.ForeignKey(
        OrderItem, on_delete=models.CASCADE, related_name="modifiers",
    )
    modifier_option = models.ForeignKey(
        "menus.ModifierOption", on_delete=models.PROTECT, related_name="+",
    )
    name_snapshot = models.CharField(max_length=120)
    price_delta = models.DecimalField(max_digits=10, decimal_places=2, default=0)

    class Meta:
        ordering = ["created_at"]


class OrderEvent(TimeStampedModel):
    """Audit log of state transitions and edits on an order."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="events")
    actor = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="+",
    )
    kind = models.CharField(max_length=40)
    payload = models.JSONField(default=dict, blank=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["order", "kind"]),
        ]
