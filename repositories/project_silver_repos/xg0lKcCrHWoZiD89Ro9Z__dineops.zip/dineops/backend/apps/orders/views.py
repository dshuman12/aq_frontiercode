from __future__ import annotations

from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common.exceptions import NotFound, PermissionDenied
from apps.locations.models import Location
from apps.menus.models import MenuItem, MenuItemVariant
from apps.restaurants.models import Restaurant, RestaurantMember

from . import services
from .models import Order, OrderItem
from .serializers import (
    AddOrderItemSerializer, ApplyDiscountSerializer, ApplyTipSerializer,
    CompItemSerializer, CreateOrderSerializer, OrderDetailSerializer,
    OrderEventSerializer, OrderItemSerializer, OrderSerializer,
    VoidItemSerializer, VoidOrderSerializer,
)


def _require_member(user, restaurant_id):
    m = RestaurantMember.objects.filter(
        restaurant_id=restaurant_id, user=user, status="active",
    ).first()
    if not m:
        raise PermissionDenied("not_a_member")
    return m


def _can_take_orders(roles):
    return any(r in (
        "owner", "general_manager", "assistant_manager",
        "server", "cashier",
    ) for r in roles or [])


def _can_void(roles):
    return any(r in (
        "owner", "general_manager", "assistant_manager",
    ) for r in roles or [])


class OrderListCreate(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        _require_member(request.user, restaurant_id)
        qs = Order.objects.filter(
            restaurant_id=restaurant_id,
        ).select_related("location").order_by("-created_at")
        if (status_f := request.GET.get("status")):
            qs = qs.filter(status=status_f)
        if (location := request.GET.get("location_id")):
            qs = qs.filter(location_id=location)
        if request.GET.get("open_only") == "true":
            qs = qs.exclude(status__in=("paid", "closed", "voided"))
        return Response({"results": OrderSerializer(qs[:200], many=True).data})

    def post(self, request, restaurant_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_take_orders(member.roles):
            raise PermissionDenied()
        s = CreateOrderSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        rest = Restaurant.objects.get(id=restaurant_id)
        loc = Location.objects.filter(
            id=s.validated_data["location_id"], restaurant_id=restaurant_id,
        ).first()
        if not loc:
            raise NotFound()
        order = services.create_order(
            restaurant=rest, location=loc, server=request.user,
            kind=s.validated_data["kind"],
            table_number=s.validated_data.get("table_number", ""),
            guest_count=s.validated_data["guest_count"],
            customer_name=s.validated_data.get("customer_name", ""),
            customer_phone=s.validated_data.get("customer_phone", ""),
        )
        return Response({"order": OrderSerializer(order).data}, status=201)


class OrderDetail(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id, order_id):
        _require_member(request.user, restaurant_id)
        order = Order.objects.filter(
            id=order_id, restaurant_id=restaurant_id,
        ).prefetch_related("items__modifiers", "items__variant").first()
        if not order:
            raise NotFound()
        return Response({
            "order": OrderDetailSerializer(order).data,
            "events": OrderEventSerializer(order.events.all()[:50], many=True).data,
        })


class AddOrderItem(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, order_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_take_orders(member.roles):
            raise PermissionDenied()
        order = Order.objects.filter(
            id=order_id, restaurant_id=restaurant_id,
        ).first()
        if not order:
            raise NotFound()
        s = AddOrderItemSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        menu_item = MenuItem.objects.filter(
            id=s.validated_data["menu_item_id"], restaurant_id=restaurant_id,
        ).first()
        if not menu_item:
            raise NotFound("menu_item_not_found")
        variant = None
        if s.validated_data.get("variant_id"):
            variant = MenuItemVariant.objects.filter(
                id=s.validated_data["variant_id"], item=menu_item,
            ).first()
            if not variant:
                raise NotFound("variant_not_found")
        item = services.add_item(
            order=order, menu_item=menu_item, variant=variant,
            quantity=s.validated_data["quantity"],
            modifier_option_ids=s.validated_data.get("modifier_option_ids", []),
            special_request=s.validated_data.get("special_request", ""),
            course=s.validated_data["course"],
            age_verified_by=request.user
              if menu_item.requires_age_verification else None,
        )
        return Response({"item": OrderItemSerializer(item).data}, status=201)


class VoidOrderItem(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, item_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_void(member.roles):
            raise PermissionDenied()
        item = OrderItem.objects.filter(
            id=item_id, order__restaurant_id=restaurant_id,
        ).select_related("order").first()
        if not item:
            raise NotFound()
        s = VoidItemSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        services.void_item(item=item, actor=request.user,
                           reason=s.validated_data["reason"])
        return Response({"item": OrderItemSerializer(item).data})


class CompOrderItem(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, item_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_void(member.roles):
            raise PermissionDenied()
        item = OrderItem.objects.filter(
            id=item_id, order__restaurant_id=restaurant_id,
        ).select_related("order").first()
        if not item:
            raise NotFound()
        s = CompItemSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        services.comp_item(item=item, actor=request.user,
                           reason=s.validated_data["reason"])
        return Response({"item": OrderItemSerializer(item).data})


class SubmitOrder(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, order_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_take_orders(member.roles):
            raise PermissionDenied()
        order = Order.objects.filter(
            id=order_id, restaurant_id=restaurant_id,
        ).first()
        if not order:
            raise NotFound()
        services.submit_order(order=order, actor=request.user)
        return Response({"order": OrderSerializer(order).data})


class FireOrder(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, order_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_take_orders(member.roles):
            raise PermissionDenied()
        order = Order.objects.filter(
            id=order_id, restaurant_id=restaurant_id,
        ).first()
        if not order:
            raise NotFound()
        services.fire_to_kitchen(order=order, actor=request.user)
        return Response({"order": OrderSerializer(order).data})


class ServeOrder(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, order_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_take_orders(member.roles):
            raise PermissionDenied()
        order = Order.objects.filter(
            id=order_id, restaurant_id=restaurant_id,
        ).first()
        if not order:
            raise NotFound()
        services.mark_order_served(order=order, actor=request.user)
        return Response({"order": OrderSerializer(order).data})


class VoidOrder(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, order_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_void(member.roles):
            raise PermissionDenied()
        order = Order.objects.filter(
            id=order_id, restaurant_id=restaurant_id,
        ).first()
        if not order:
            raise NotFound()
        s = VoidOrderSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        services.void_order(order=order, actor=request.user,
                            reason=s.validated_data["reason"])
        return Response({"order": OrderSerializer(order).data})


class ApplyDiscountView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, order_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_void(member.roles):
            raise PermissionDenied()
        order = Order.objects.filter(
            id=order_id, restaurant_id=restaurant_id,
        ).first()
        if not order:
            raise NotFound()
        s = ApplyDiscountSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        services.apply_discount(
            order=order, actor=request.user, **s.validated_data,
        )
        return Response({"order": OrderSerializer(order).data})


class ApplyTipView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request, restaurant_id, order_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_take_orders(member.roles):
            raise PermissionDenied()
        order = Order.objects.filter(
            id=order_id, restaurant_id=restaurant_id,
        ).first()
        if not order:
            raise NotFound()
        s = ApplyTipSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        services.apply_tip(order=order, actor=request.user, **s.validated_data)
        return Response({"order": OrderSerializer(order).data})
