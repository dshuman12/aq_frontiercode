from __future__ import annotations

from datetime import datetime, timedelta, timezone as dtz
from decimal import Decimal

from django.db.models import Avg, Count, F, Sum

from .models import Order, OrderItem


def open_orders(restaurant_id, *, location_id=None) -> list[Order]:
    qs = Order.objects.filter(
        restaurant_id=restaurant_id,
    ).exclude(status__in=("paid", "closed", "voided"))
    if location_id:
        qs = qs.filter(location_id=location_id)
    return list(qs.order_by("-created_at"))


def average_ticket_size(restaurant_id, *, days: int = 30) -> Decimal:
    cutoff = datetime.now(dtz.utc) - timedelta(days=days)
    avg = (
        Order.objects.filter(
            restaurant_id=restaurant_id,
            status="paid", paid_at__gte=cutoff,
        ).aggregate(avg=Avg("total_amount"))["avg"]
    )
    return (avg or Decimal("0")).quantize(Decimal("0.01"))


def order_kpis(restaurant_id, *, location_id=None,
               days: int = 30) -> dict:
    cutoff = datetime.now(dtz.utc) - timedelta(days=days)
    qs = Order.objects.filter(
        restaurant_id=restaurant_id,
        created_at__gte=cutoff,
    )
    if location_id:
        qs = qs.filter(location_id=location_id)
    paid = qs.filter(status="paid")
    return {
        "orders_total": qs.count(),
        "orders_paid": paid.count(),
        "orders_voided": qs.filter(status="voided").count(),
        "average_ticket": str(
            paid.aggregate(avg=Avg("total_amount"))["avg"] or Decimal("0")
        ),
        "total_revenue": str(
            paid.aggregate(s=Sum("total_amount"))["s"] or Decimal("0")
        ),
    }


def kitchen_throughput(restaurant_id, *, location_id=None,
                       days: int = 7) -> dict:
    """Average minutes from submit → ready, by location."""
    cutoff = datetime.now(dtz.utc) - timedelta(days=days)
    items = OrderItem.objects.filter(
        order__restaurant_id=restaurant_id,
        sent_at__isnull=False, ready_at__isnull=False,
        sent_at__gte=cutoff,
    )
    if location_id:
        items = items.filter(order__location_id=location_id)
    durations = []
    for it in items.values("sent_at", "ready_at"):
        d = (it["ready_at"] - it["sent_at"]).total_seconds() / 60
        durations.append(d)
    return {
        "samples": len(durations),
        "avg_minutes": round(sum(durations) / len(durations), 2) if durations else 0,
        "p95_minutes": round(
            sorted(durations)[int(len(durations) * 0.95)] if durations else 0, 2,
        ),
    }
