from __future__ import annotations

from rest_framework import serializers

from .models import Order, OrderEvent, OrderItem, OrderItemModifier


class OrderItemModifierSerializer(serializers.ModelSerializer):
    class Meta:
        model = OrderItemModifier
        fields = ["id", "modifier_option", "name_snapshot", "price_delta"]


class OrderItemSerializer(serializers.ModelSerializer):
    modifiers = OrderItemModifierSerializer(many=True, read_only=True)
    variant_name = serializers.CharField(source="variant.name", read_only=True)

    class Meta:
        model = OrderItem
        fields = [
            "id", "order", "course", "sort",
            "menu_item", "variant", "variant_name",
            "item_name_snapshot", "quantity",
            "unit_price", "modifiers_total", "line_subtotal",
            "discount_amount", "line_total",
            "status", "void_reason", "voided_by",
            "sent_at", "ready_at", "served_at",
            "special_request",
            "modifiers", "age_verified_by",
        ]
        read_only_fields = [
            "id", "item_name_snapshot",
            "modifiers_total", "line_subtotal", "line_total",
            "sent_at", "ready_at", "served_at", "voided_by",
        ]


class OrderSerializer(serializers.ModelSerializer):
    location_name = serializers.CharField(source="location.name", read_only=True)
    item_count = serializers.IntegerField(source="items.count", read_only=True)

    class Meta:
        model = Order
        fields = [
            "id", "restaurant", "location", "location_name",
            "order_number", "kind", "status",
            "table_number", "guest_count",
            "customer_name", "customer_phone",
            "server", "cashier",
            "submitted_at", "in_kitchen_at", "ready_at", "served_at",
            "paid_at", "closed_at", "voided_at", "void_reason",
            "subtotal", "discount_amount", "discount_reason",
            "tax_amount", "service_charge_amount", "tip_amount",
            "total_amount", "amount_paid", "balance_due", "currency",
            "item_count", "notes",
        ]
        read_only_fields = [
            "id", "order_number",
            "submitted_at", "in_kitchen_at", "ready_at", "served_at",
            "paid_at", "closed_at", "voided_at",
            "subtotal", "tax_amount", "service_charge_amount",
            "total_amount", "balance_due",
        ]


class OrderDetailSerializer(OrderSerializer):
    items = OrderItemSerializer(many=True, read_only=True)

    class Meta(OrderSerializer.Meta):
        fields = OrderSerializer.Meta.fields + ["items"]


class CreateOrderSerializer(serializers.Serializer):
    location_id = serializers.UUIDField()
    kind = serializers.ChoiceField(choices=Order.KIND_CHOICES, default="dine_in")
    table_number = serializers.CharField(required=False, allow_blank=True, default="")
    guest_count = serializers.IntegerField(min_value=1, default=1)
    customer_name = serializers.CharField(required=False, allow_blank=True, default="")
    customer_phone = serializers.CharField(required=False, allow_blank=True, default="")


class AddOrderItemSerializer(serializers.Serializer):
    menu_item_id = serializers.UUIDField()
    quantity = serializers.IntegerField(min_value=1, default=1)
    variant_id = serializers.UUIDField(required=False, allow_null=True)
    modifier_option_ids = serializers.ListField(
        child=serializers.UUIDField(), required=False,
    )
    special_request = serializers.CharField(required=False, allow_blank=True)
    course = serializers.IntegerField(min_value=1, default=1)


class VoidItemSerializer(serializers.Serializer):
    reason = serializers.CharField(max_length=200)


class CompItemSerializer(serializers.Serializer):
    reason = serializers.CharField(max_length=200)


class VoidOrderSerializer(serializers.Serializer):
    reason = serializers.CharField(max_length=200)


class ApplyDiscountSerializer(serializers.Serializer):
    amount = serializers.DecimalField(max_digits=10, decimal_places=2, min_value=0)
    reason = serializers.CharField(max_length=200)


class ApplyTipSerializer(serializers.Serializer):
    amount = serializers.DecimalField(max_digits=10, decimal_places=2, min_value=0)


class OrderEventSerializer(serializers.ModelSerializer):
    actor_email = serializers.CharField(source="actor.email", read_only=True)

    class Meta:
        model = OrderEvent
        fields = ["id", "order", "actor", "actor_email",
                  "kind", "payload", "created_at"]
