from django.urls import path

from . import views

app_name = "orders"

urlpatterns = [
    path("<uuid:restaurant_id>/", views.OrderListCreate.as_view(), name="list-create"),
    path("<uuid:restaurant_id>/<uuid:order_id>/",
         views.OrderDetail.as_view(), name="detail"),
    path("<uuid:restaurant_id>/<uuid:order_id>/items/",
         views.AddOrderItem.as_view(), name="add-item"),
    path("<uuid:restaurant_id>/<uuid:order_id>/submit/",
         views.SubmitOrder.as_view(), name="submit"),
    path("<uuid:restaurant_id>/<uuid:order_id>/fire/",
         views.FireOrder.as_view(), name="fire"),
    path("<uuid:restaurant_id>/<uuid:order_id>/serve/",
         views.ServeOrder.as_view(), name="serve"),
    path("<uuid:restaurant_id>/<uuid:order_id>/void/",
         views.VoidOrder.as_view(), name="void"),
    path("<uuid:restaurant_id>/<uuid:order_id>/discount/",
         views.ApplyDiscountView.as_view(), name="discount"),
    path("<uuid:restaurant_id>/<uuid:order_id>/tip/",
         views.ApplyTipView.as_view(), name="tip"),
    path("<uuid:restaurant_id>/items/<uuid:item_id>/void/",
         views.VoidOrderItem.as_view(), name="item-void"),
    path("<uuid:restaurant_id>/items/<uuid:item_id>/comp/",
         views.CompOrderItem.as_view(), name="item-comp"),
]
