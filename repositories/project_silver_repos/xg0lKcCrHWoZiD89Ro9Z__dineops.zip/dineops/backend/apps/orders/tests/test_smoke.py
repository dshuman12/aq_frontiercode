import pytest


pytestmark = pytest.mark.django_db


def test_orders_module_imports():
    from apps.orders import models, services, signals, serializers, views, urls
    assert all([models, services, signals, serializers, views, urls])
