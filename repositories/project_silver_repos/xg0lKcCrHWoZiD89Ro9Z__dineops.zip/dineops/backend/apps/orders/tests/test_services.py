from __future__ import annotations

from decimal import Decimal

import pytest

from apps.accounts.models import User
from apps.common.exceptions import ValidationError
from apps.locations.models import Location
from apps.menus.models import MenuItem, ModifierOption
from apps.menus.services import (
    add_modifier_option, add_variant, attach_modifier_group,
    create_menu_item, create_modifier_group,
)
from apps.orders.models import Order, OrderEvent, OrderItem
from apps.orders.services import (
    add_item, apply_discount, apply_tip, comp_item, create_order,
    fire_to_kitchen, mark_item_in_progress, mark_item_ready,
    mark_order_served, submit_order, void_item, void_order,
)
from apps.restaurants.models import Restaurant


pytestmark = pytest.mark.django_db


def _setup():
    owner = User.objects.create_user(email="o@x.com", password="pwpwpwpw")
    rest = Restaurant.objects.create(
        name="R", slug="r", owner=owner,
        default_tax_percent=Decimal("8.5"),
        default_service_charge_percent=Decimal("0"),
    )
    loc = Location.objects.create(
        restaurant=rest, name="Main", slug="main", accepts_dine_in=True,
    )
    return rest, loc, owner


def _menu_item(rest, name="Burger", price="12.00", **kwargs):
    return create_menu_item(restaurant=rest, name=name,
                            base_price=Decimal(price), **kwargs)


class TestCreateOrder:
    def test_creates_dine_in(self):
        rest, loc, owner = _setup()
        order = create_order(restaurant=rest, location=loc, server=owner,
                             table_number="12", guest_count=2)
        assert order.status == "pending"
        assert order.order_number
        assert order.guest_count == 2

    def test_dine_in_requires_table(self):
        rest, loc, _ = _setup()
        with pytest.raises(ValidationError):
            create_order(restaurant=rest, location=loc)

    def test_takeout_no_table_ok(self):
        rest, loc, _ = _setup()
        order = create_order(restaurant=rest, location=loc, kind="takeout",
                             customer_name="Alice")
        assert order.kind == "takeout"

    def test_invalid_guest_count(self):
        rest, loc, _ = _setup()
        with pytest.raises(ValidationError):
            create_order(restaurant=rest, location=loc, table_number="1",
                         guest_count=0)

    def test_creation_event(self):
        rest, loc, _ = _setup()
        o = create_order(restaurant=rest, location=loc, table_number="1")
        assert OrderEvent.objects.filter(order=o, kind="created").count() == 1


class TestAddItem:
    def test_simple_add(self):
        rest, loc, _ = _setup()
        o = create_order(restaurant=rest, location=loc, table_number="1")
        item = _menu_item(rest, "Burger", "12.00")
        line = add_item(order=o, menu_item=item, quantity=2)
        assert line.line_total == Decimal("24.00")
        o.refresh_from_db()
        # subtotal 24, tax 8.5%, no service charge default-set → total 26.04
        assert o.subtotal == Decimal("24.00")

    def test_with_variant(self):
        rest, loc, _ = _setup()
        o = create_order(restaurant=rest, location=loc, table_number="1")
        item = _menu_item(rest, "Pizza", "12.00")
        variant = add_variant(item=item, name="Large", price_delta=Decimal("4"))
        line = add_item(order=o, menu_item=item, variant=variant, quantity=1)
        assert line.unit_price == Decimal("16.00")

    def test_with_modifiers(self):
        rest, loc, _ = _setup()
        o = create_order(restaurant=rest, location=loc, table_number="1")
        item = _menu_item(rest, "Burger", "10.00")
        g = create_modifier_group(restaurant=rest, name="Adds", max_select=5)
        bacon = add_modifier_option(group=g, name="Bacon",
                                    price_delta=Decimal("2"))
        attach_modifier_group(item=item, group=g)
        line = add_item(order=o, menu_item=item,
                        modifier_option_ids=[str(bacon.id)])
        assert line.line_total == Decimal("12.00")
        assert line.modifiers.count() == 1

    def test_required_modifier_min_enforced(self):
        rest, loc, _ = _setup()
        o = create_order(restaurant=rest, location=loc, table_number="1")
        item = _menu_item(rest, "Steak", "32.00")
        g = create_modifier_group(
            restaurant=rest, name="Cook",
            is_required=True, min_select=1, max_select=1,
        )
        add_modifier_option(group=g, name="Medium")
        attach_modifier_group(item=item, group=g)
        with pytest.raises(ValidationError) as exc:
            add_item(order=o, menu_item=item)
        assert exc.value.code == "modifier_min_not_met"

    def test_age_restricted_requires_verifier(self):
        rest, loc, _ = _setup()
        o = create_order(restaurant=rest, location=loc, table_number="1")
        item = _menu_item(rest, "Beer", "7.00",
                          requires_age_verification=True)
        with pytest.raises(ValidationError):
            add_item(order=o, menu_item=item, age_verified_by=None)

    def test_invalid_qty(self):
        rest, loc, _ = _setup()
        o = create_order(restaurant=rest, location=loc, table_number="1")
        item = _menu_item(rest)
        with pytest.raises(ValidationError):
            add_item(order=o, menu_item=item, quantity=0)

    def test_cannot_add_to_voided(self):
        rest, loc, owner = _setup()
        o = create_order(restaurant=rest, location=loc, table_number="1")
        item = _menu_item(rest)
        add_item(order=o, menu_item=item)
        void_order(order=o, actor=owner, reason="bug")
        with pytest.raises(ValidationError):
            add_item(order=o, menu_item=item)


class TestVoidComp:
    def test_void_item(self):
        rest, loc, owner = _setup()
        o = create_order(restaurant=rest, location=loc, table_number="1")
        item = _menu_item(rest)
        line = add_item(order=o, menu_item=item, quantity=2)
        void_item(item=line, actor=owner, reason="customer changed mind")
        line.refresh_from_db()
        o.refresh_from_db()
        assert line.status == "voided"
        assert line.line_total == Decimal("0")
        assert o.subtotal == Decimal("0")

    def test_void_requires_reason(self):
        rest, loc, owner = _setup()
        o = create_order(restaurant=rest, location=loc, table_number="1")
        item = _menu_item(rest)
        line = add_item(order=o, menu_item=item)
        with pytest.raises(ValidationError):
            void_item(item=line, actor=owner, reason="  ")

    def test_comp_item(self):
        rest, loc, owner = _setup()
        o = create_order(restaurant=rest, location=loc, table_number="1")
        item = _menu_item(rest)
        line = add_item(order=o, menu_item=item, quantity=1)
        comp_item(item=line, actor=owner, reason="kitchen burnt it")
        line.refresh_from_db()
        assert line.status == "comped"
        assert line.line_total == Decimal("0")


class TestSubmitFireServe:
    def test_submit(self):
        rest, loc, _ = _setup()
        o = create_order(restaurant=rest, location=loc, table_number="1")
        item = _menu_item(rest)
        add_item(order=o, menu_item=item)
        submit_order(order=o)
        o.refresh_from_db()
        assert o.status == "submitted"

    def test_submit_empty_rejected(self):
        rest, loc, _ = _setup()
        o = create_order(restaurant=rest, location=loc, table_number="1")
        with pytest.raises(ValidationError):
            submit_order(order=o)

    def test_fire_after_submit(self):
        rest, loc, _ = _setup()
        o = create_order(restaurant=rest, location=loc, table_number="1")
        add_item(order=o, menu_item=_menu_item(rest))
        submit_order(order=o)
        fire_to_kitchen(order=o)
        o.refresh_from_db()
        assert o.status == "in_kitchen"

    def test_item_ready_advances_order(self):
        rest, loc, _ = _setup()
        o = create_order(restaurant=rest, location=loc, table_number="1")
        line = add_item(order=o, menu_item=_menu_item(rest))
        submit_order(order=o)
        fire_to_kitchen(order=o)
        line.refresh_from_db()
        mark_item_in_progress(item=line)
        mark_item_ready(item=line)
        o.refresh_from_db()
        assert o.status == "ready"

    def test_serve_order(self):
        rest, loc, _ = _setup()
        o = create_order(restaurant=rest, location=loc, table_number="1")
        line = add_item(order=o, menu_item=_menu_item(rest))
        submit_order(order=o)
        fire_to_kitchen(order=o)
        line.refresh_from_db()
        mark_item_ready(item=line)
        mark_order_served(order=o)
        o.refresh_from_db()
        assert o.status == "served"


class TestVoidOrder:
    def test_void_order(self):
        rest, loc, owner = _setup()
        o = create_order(restaurant=rest, location=loc, table_number="1")
        line = add_item(order=o, menu_item=_menu_item(rest))
        void_order(order=o, actor=owner, reason="walked out")
        o.refresh_from_db()
        line.refresh_from_db()
        assert o.status == "voided"
        assert line.status == "voided"


class TestDiscountAndTip:
    def test_apply_discount(self):
        rest, loc, owner = _setup()
        o = create_order(restaurant=rest, location=loc, table_number="1")
        add_item(order=o, menu_item=_menu_item(rest, price="20.00"))
        apply_discount(order=o, actor=owner,
                       amount=Decimal("5"), reason="manager comp")
        o.refresh_from_db()
        assert o.discount_amount == Decimal("5.00")
        # 20 - 5 + 8.5% tax of 20 = 16.70
        assert o.total_amount == Decimal("16.70")

    def test_discount_exceeds_subtotal_rejected(self):
        rest, loc, owner = _setup()
        o = create_order(restaurant=rest, location=loc, table_number="1")
        add_item(order=o, menu_item=_menu_item(rest, price="10.00"))
        with pytest.raises(ValidationError):
            apply_discount(order=o, actor=owner,
                           amount=Decimal("100"), reason="x")

    def test_apply_tip(self):
        rest, loc, owner = _setup()
        o = create_order(restaurant=rest, location=loc, table_number="1")
        add_item(order=o, menu_item=_menu_item(rest, price="10.00"))
        apply_tip(order=o, actor=owner, amount=Decimal("3"))
        o.refresh_from_db()
        assert o.tip_amount == Decimal("3.00")

    def test_negative_tip_rejected(self):
        rest, loc, owner = _setup()
        o = create_order(restaurant=rest, location=loc, table_number="1")
        with pytest.raises(ValidationError):
            apply_tip(order=o, actor=owner, amount=Decimal("-1"))
