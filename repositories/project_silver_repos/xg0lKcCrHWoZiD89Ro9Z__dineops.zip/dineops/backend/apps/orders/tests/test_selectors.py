from datetime import datetime, timedelta, timezone as dtz
from decimal import Decimal

import pytest

from apps.accounts.models import User
from apps.locations.models import Location
from apps.menus.services import create_menu_item
from apps.orders.selectors import (
    average_ticket_size, kitchen_throughput, open_orders, order_kpis,
)
from apps.orders.services import (
    add_item, create_order, fire_to_kitchen, mark_item_ready,
    mark_order_served, submit_order, void_order,
)
from apps.payments.services import record_cash_payment
from apps.restaurants.models import Restaurant


pytestmark = pytest.mark.django_db


def _setup():
    owner = User.objects.create_user(email="o@x.com", password="pwpwpwpw")
    rest = Restaurant.objects.create(
        name="R", slug="r", owner=owner,
        default_tax_percent=Decimal("0"),
        default_service_charge_percent=Decimal("0"),
    )
    loc = Location.objects.create(
        restaurant=rest, name="Main", slug="main", accepts_dine_in=True,
    )
    return rest, loc, owner


def _full_paid_order(rest, loc, price=Decimal("20"), tip=Decimal("3")):
    item = create_menu_item(restaurant=rest, name=f"X-{price}",
                            base_price=price)
    o = create_order(restaurant=rest, location=loc, table_number="1")
    add_item(order=o, menu_item=item, quantity=1)
    submit_order(order=o)
    fire_to_kitchen(order=o)
    mark_order_served(order=o)
    o.refresh_from_db()
    record_cash_payment(order=o, amount=o.total_amount, tip=tip)
    o.refresh_from_db()
    return o


def test_open_orders_excludes_paid():
    rest, loc, _ = _setup()
    _full_paid_order(rest, loc)
    o = create_order(restaurant=rest, location=loc, table_number="2")
    add_item(order=o, menu_item=create_menu_item(
        restaurant=rest, name="A", base_price=Decimal("5"),
    ))
    submit_order(order=o)
    out = open_orders(rest.id)
    assert len(out) == 1
    assert out[0].id == o.id


def test_order_kpis_basic():
    rest, loc, _ = _setup()
    _full_paid_order(rest, loc, Decimal("20"))
    _full_paid_order(rest, loc, Decimal("30"))
    voided = create_order(restaurant=rest, location=loc, table_number="9")
    add_item(order=voided, menu_item=create_menu_item(
        restaurant=rest, name="V", base_price=Decimal("5"),
    ))
    void_order(order=voided, actor=rest.owner, reason="x")
    k = order_kpis(rest.id)
    assert k["orders_total"] >= 3
    assert k["orders_paid"] == 2
    assert k["orders_voided"] == 1


def test_average_ticket_size():
    rest, loc, _ = _setup()
    _full_paid_order(rest, loc, Decimal("20"))
    _full_paid_order(rest, loc, Decimal("40"))
    avg = average_ticket_size(rest.id)
    # totals are subtotal+tax+service+tip; here 0 tax/service, tip 3 → 23 + 43 / 2 = 33
    assert avg == Decimal("33.00")
