"""Smoke tests for the order signals — broadcasting works without erroring
when there's no channel layer configured."""
from decimal import Decimal

import pytest

from apps.accounts.models import User
from apps.locations.models import Location
from apps.menus.services import create_menu_item
from apps.orders.services import (
    add_item, create_order, fire_to_kitchen, mark_item_ready,
    submit_order,
)
from apps.restaurants.models import Restaurant


pytestmark = pytest.mark.django_db


def test_signal_does_not_crash_without_channel_layer():
    owner = User.objects.create_user(email="o@x.com", password="pwpwpwpw")
    rest = Restaurant.objects.create(
        name="R", slug="r", owner=owner,
        default_tax_percent=Decimal("0"),
    )
    loc = Location.objects.create(
        restaurant=rest, name="Main", slug="main", accepts_dine_in=True,
    )
    item = create_menu_item(restaurant=rest, name="X",
                            base_price=Decimal("10"))
    order = create_order(restaurant=rest, location=loc, table_number="1")
    line = add_item(order=order, menu_item=item)
    submit_order(order=order)
    fire_to_kitchen(order=order)
    line.refresh_from_db()
    mark_item_ready(item=line)
    # If we got here, the signal handlers were invoked without raising.
    assert True
