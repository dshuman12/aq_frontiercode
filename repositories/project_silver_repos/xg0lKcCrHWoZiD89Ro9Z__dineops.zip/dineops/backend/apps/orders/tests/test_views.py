from decimal import Decimal

import pytest
from rest_framework.test import APIClient

from apps.accounts.models import User
from apps.locations.models import Location
from apps.menus.services import create_menu_item
from apps.restaurants.models import Restaurant, RestaurantMember


pytestmark = pytest.mark.django_db


def _login(user):
    c = APIClient()
    c.force_authenticate(user=user)
    return c


@pytest.fixture
def setup():
    owner = User.objects.create_user(email="o@x.com", password="pwpwpwpw")
    rest = Restaurant.objects.create(
        name="R", slug="r", owner=owner,
        default_tax_percent=Decimal("0"),
        default_service_charge_percent=Decimal("0"),
    )
    loc = Location.objects.create(
        restaurant=rest, name="Main", slug="main", accepts_dine_in=True,
    )
    RestaurantMember.objects.create(
        restaurant=rest, user=owner, roles=["owner"], status="active",
    )
    server = User.objects.create_user(email="s@x.com", password="pwpwpwpw")
    RestaurantMember.objects.create(
        restaurant=rest, user=server, roles=["server"], status="active",
    )
    return {"rest": rest, "loc": loc, "owner": owner, "server": server}


class TestOrderEndpoints:
    def test_create_order(self, setup):
        c = _login(setup["owner"])
        resp = c.post(
            f"/api/orders/{setup['rest'].id}/",
            {"location_id": str(setup["loc"].id),
             "kind": "dine_in", "table_number": "5",
             "guest_count": 2},
            format="json",
        )
        assert resp.status_code == 201

    def test_add_item(self, setup):
        c = _login(setup["owner"])
        item = create_menu_item(restaurant=setup["rest"], name="X",
                                base_price=Decimal("10"))
        resp = c.post(
            f"/api/orders/{setup['rest'].id}/",
            {"location_id": str(setup["loc"].id), "table_number": "1"},
            format="json",
        )
        oid = resp.data["order"]["id"]
        resp = c.post(
            f"/api/orders/{setup['rest'].id}/{oid}/items/",
            {"menu_item_id": str(item.id), "quantity": 2},
            format="json",
        )
        assert resp.status_code == 201
        assert resp.data["item"]["quantity"] == 2

    def test_submit_then_serve(self, setup):
        c = _login(setup["owner"])
        item = create_menu_item(restaurant=setup["rest"], name="X",
                                base_price=Decimal("10"))
        resp = c.post(
            f"/api/orders/{setup['rest'].id}/",
            {"location_id": str(setup["loc"].id), "table_number": "1"},
            format="json",
        )
        oid = resp.data["order"]["id"]
        c.post(f"/api/orders/{setup['rest'].id}/{oid}/items/",
               {"menu_item_id": str(item.id)}, format="json")
        c.post(f"/api/orders/{setup['rest'].id}/{oid}/submit/")
        c.post(f"/api/orders/{setup['rest'].id}/{oid}/serve/")
        resp = c.get(f"/api/orders/{setup['rest'].id}/{oid}/")
        assert resp.data["order"]["status"] == "served"

    def test_server_cannot_void(self, setup):
        # server places order, but doesn't have void permission
        c = _login(setup["server"])
        item = create_menu_item(restaurant=setup["rest"], name="X",
                                base_price=Decimal("10"))
        resp = c.post(
            f"/api/orders/{setup['rest'].id}/",
            {"location_id": str(setup["loc"].id), "table_number": "1"},
            format="json",
        )
        oid = resp.data["order"]["id"]
        c.post(f"/api/orders/{setup['rest'].id}/{oid}/items/",
               {"menu_item_id": str(item.id)}, format="json")
        resp = c.post(
            f"/api/orders/{setup['rest'].id}/{oid}/void/",
            {"reason": "x"}, format="json",
        )
        assert resp.status_code == 403
