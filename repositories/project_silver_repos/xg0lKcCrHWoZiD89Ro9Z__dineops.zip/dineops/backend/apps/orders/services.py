from __future__ import annotations

from decimal import Decimal
from typing import Iterable

from django.db import transaction
from django.utils import timezone

from apps.common.exceptions import Conflict, NotFound, ValidationError
from apps.locations.models import Location
from apps.menus.models import (
    MenuItem, MenuItemVariant, ModifierOption,
)
from apps.menus.services import (
    calculate_item_price, validate_modifier_selection,
)
from apps.restaurants.models import Restaurant

from .models import Order, OrderEvent, OrderItem, OrderItemModifier


def _next_order_number(location: Location) -> str:
    today = timezone.now().date()
    prefix = today.strftime("%y%m%d")
    seq = Order.objects.filter(
        location=location, order_number__startswith=prefix,
    ).count() + 1
    return f"{prefix}-{seq:04d}"


@transaction.atomic
def create_order(*, restaurant: Restaurant, location: Location,
                 kind: str = "dine_in",
                 server=None,
                 table_number: str = "",
                 guest_count: int = 1,
                 customer_name: str = "",
                 customer_phone: str = "") -> Order:
    if location.restaurant_id != restaurant.id:
        raise ValidationError("location_not_in_restaurant")
    if kind == "dine_in" and not table_number:
        raise ValidationError("table_required_for_dine_in")
    if guest_count < 1:
        raise ValidationError("invalid_guest_count")

    order = Order.objects.create(
        restaurant=restaurant, location=location,
        order_number=_next_order_number(location),
        kind=kind, server=server,
        table_number=table_number, guest_count=guest_count,
        customer_name=customer_name, customer_phone=customer_phone,
        status="pending",
    )
    OrderEvent.objects.create(
        order=order, actor=server, kind="created",
        payload={"kind": kind, "table": table_number},
    )
    return order


def _line_subtotal(unit_price: Decimal, modifiers: list[ModifierOption],
                   quantity: int) -> tuple[Decimal, Decimal, Decimal]:
    """Return (modifiers_total, line_subtotal, line_total)."""
    mods_per = sum((m.price_delta for m in modifiers), Decimal("0"))
    per_unit = unit_price + mods_per
    if per_unit < 0:
        per_unit = Decimal("0")
    line_subtotal = (per_unit * quantity).quantize(Decimal("0.01"))
    return mods_per * quantity, line_subtotal, line_subtotal


def _recalc_order_totals(order: Order) -> None:
    subtotal = Decimal("0")
    for item in order.items.exclude(status__in=("voided", "comped")):
        subtotal += item.line_total
    order.subtotal = subtotal.quantize(Decimal("0.01"))

    # tax & service charge from restaurant defaults (location-scoped logic
    # would query the Menu's overrides; out of scope here)
    rest = order.restaurant
    if order.tax_amount == 0:
        order.tax_amount = (
            order.subtotal * (rest.default_tax_percent / 100)
        ).quantize(Decimal("0.01"))
    if order.service_charge_amount == 0:
        order.service_charge_amount = (
            order.subtotal * (rest.default_service_charge_percent / 100)
        ).quantize(Decimal("0.01"))

    order.total_amount = (
        order.subtotal + order.tax_amount + order.service_charge_amount
        + order.tip_amount - order.discount_amount
    ).quantize(Decimal("0.01"))
    order.balance_due = (order.total_amount - order.amount_paid).quantize(Decimal("0.01"))
    order.save(update_fields=[
        "subtotal", "tax_amount", "service_charge_amount",
        "total_amount", "balance_due", "updated_at",
    ])


@transaction.atomic
def add_item(*, order: Order, menu_item: MenuItem,
             quantity: int = 1,
             variant: MenuItemVariant | None = None,
             modifier_option_ids: list = None,
             special_request: str = "",
             course: int = 1,
             age_verified_by=None) -> OrderItem:
    if not order.is_open:
        raise ValidationError("order_closed")
    if menu_item.restaurant_id != order.restaurant_id:
        raise ValidationError("menu_item_not_in_restaurant")
    if quantity <= 0:
        raise ValidationError("invalid_quantity")

    # Resolve modifiers
    modifier_options = []
    selections_for_validate = {}
    if modifier_option_ids:
        modifier_options = list(
            ModifierOption.objects.filter(id__in=modifier_option_ids)
            .select_related("group")
        )
        # Group selections by modifier group
        for opt in modifier_options:
            selections_for_validate.setdefault(str(opt.group_id), []).append(str(opt.id))
        validate_modifier_selection(item=menu_item, selections=selections_for_validate)

    if menu_item.requires_age_verification and not age_verified_by:
        raise ValidationError("age_verification_required")

    unit_price = menu_item.base_price
    if variant:
        if variant.item_id != menu_item.id:
            raise ValidationError("variant_not_for_item")
        unit_price = unit_price + variant.price_delta

    mods_total, line_sub, line_total = _line_subtotal(
        unit_price, modifier_options, quantity,
    )

    item = OrderItem.objects.create(
        order=order, course=course, menu_item=menu_item,
        variant=variant,
        item_name_snapshot=menu_item.name,
        quantity=quantity, unit_price=unit_price,
        modifiers_total=mods_total, line_subtotal=line_sub,
        line_total=line_total,
        special_request=special_request,
        age_verified_by=age_verified_by,
        status="pending",
    )
    for opt in modifier_options:
        OrderItemModifier.objects.create(
            order_item=item, modifier_option=opt,
            name_snapshot=opt.name, price_delta=opt.price_delta,
        )
    OrderEvent.objects.create(
        order=order, kind="item_added",
        payload={"item_id": str(item.id), "name": menu_item.name,
                 "qty": quantity},
    )
    _recalc_order_totals(order)
    return item


@transaction.atomic
def void_item(*, item: OrderItem, actor, reason: str) -> OrderItem:
    if not reason.strip():
        raise ValidationError("void_reason_required")
    if item.status in ("voided", "served"):
        raise ValidationError("cannot_void")
    item.status = "voided"
    item.void_reason = reason
    item.voided_by = actor
    item.line_total = Decimal("0")
    item.save()
    OrderEvent.objects.create(
        order=item.order, actor=actor, kind="item_voided",
        payload={"item_id": str(item.id), "reason": reason},
    )
    _recalc_order_totals(item.order)
    return item


@transaction.atomic
def comp_item(*, item: OrderItem, actor, reason: str) -> OrderItem:
    if not reason.strip():
        raise ValidationError("comp_reason_required")
    item.status = "comped"
    item.line_total = Decimal("0")
    item.void_reason = reason
    item.voided_by = actor
    item.save()
    OrderEvent.objects.create(
        order=item.order, actor=actor, kind="item_comped",
        payload={"item_id": str(item.id), "reason": reason},
    )
    _recalc_order_totals(item.order)
    return item


@transaction.atomic
def submit_order(*, order: Order, actor=None) -> Order:
    if order.status != "pending":
        raise ValidationError("order_not_pending")
    open_items = order.items.exclude(status__in=("voided", "comped"))
    if open_items.count() == 0:
        raise ValidationError("order_empty")
    order.status = "submitted"
    order.submitted_at = timezone.now()
    order.save(update_fields=["status", "submitted_at", "updated_at"])
    open_items.update(status="sent_to_kitchen", sent_at=timezone.now())
    OrderEvent.objects.create(
        order=order, actor=actor, kind="submitted",
        payload={"item_count": open_items.count()},
    )
    return order


@transaction.atomic
def fire_to_kitchen(*, order: Order, actor=None) -> Order:
    if order.status not in ("submitted", "in_kitchen"):
        raise ValidationError("order_not_fireable")
    order.status = "in_kitchen"
    order.in_kitchen_at = order.in_kitchen_at or timezone.now()
    order.save(update_fields=["status", "in_kitchen_at", "updated_at"])
    OrderEvent.objects.create(order=order, actor=actor, kind="fired_to_kitchen")
    return order


@transaction.atomic
def mark_item_in_progress(*, item: OrderItem, actor=None) -> OrderItem:
    if item.status not in ("sent_to_kitchen", "pending"):
        raise ValidationError("invalid_state")
    item.status = "in_progress"
    item.save(update_fields=["status", "updated_at"])
    return item


@transaction.atomic
def mark_item_ready(*, item: OrderItem, actor=None) -> OrderItem:
    item.status = "ready"
    item.ready_at = timezone.now()
    item.save(update_fields=["status", "ready_at", "updated_at"])

    # If all non-voided items are ready, advance the order
    order = item.order
    pending_items = order.items.filter(
        status__in=("sent_to_kitchen", "in_progress"),
    ).count()
    if pending_items == 0:
        order.status = "ready"
        order.ready_at = timezone.now()
        order.save(update_fields=["status", "ready_at", "updated_at"])
        OrderEvent.objects.create(order=order, kind="all_items_ready")
    return item


@transaction.atomic
def mark_item_served(*, item: OrderItem, actor=None) -> OrderItem:
    item.status = "served"
    item.served_at = timezone.now()
    item.save(update_fields=["status", "served_at", "updated_at"])
    return item


@transaction.atomic
def mark_order_served(*, order: Order, actor=None) -> Order:
    if order.status not in ("ready", "in_kitchen", "submitted"):
        raise ValidationError("order_not_servable")
    order.items.filter(
        status__in=("ready", "sent_to_kitchen", "in_progress"),
    ).update(status="served", served_at=timezone.now())
    order.status = "served"
    order.served_at = timezone.now()
    order.save(update_fields=["status", "served_at", "updated_at"])
    OrderEvent.objects.create(order=order, actor=actor, kind="served")
    return order


@transaction.atomic
def void_order(*, order: Order, actor, reason: str) -> Order:
    if order.status in ("paid", "closed", "voided"):
        raise ValidationError("order_not_voidable")
    if not reason.strip():
        raise ValidationError("void_reason_required")
    order.status = "voided"
    order.voided_at = timezone.now()
    order.void_reason = reason
    order.items.exclude(status__in=("voided", "comped")).update(
        status="voided", void_reason=f"order_void:{reason}",
    )
    order.save(update_fields=[
        "status", "voided_at", "void_reason", "updated_at",
    ])
    OrderEvent.objects.create(
        order=order, actor=actor, kind="voided",
        payload={"reason": reason},
    )
    return order


@transaction.atomic
def apply_discount(*, order: Order, actor, amount: Decimal,
                   reason: str) -> Order:
    if order.status in ("paid", "closed", "voided"):
        raise ValidationError("order_not_modifiable")
    if amount < 0:
        raise ValidationError("invalid_discount")
    if amount > order.subtotal:
        raise ValidationError("discount_exceeds_subtotal")
    order.discount_amount = amount
    order.discount_reason = reason
    order.save(update_fields=["discount_amount", "discount_reason", "updated_at"])
    _recalc_order_totals(order)
    OrderEvent.objects.create(
        order=order, actor=actor, kind="discount_applied",
        payload={"amount": str(amount), "reason": reason},
    )
    return order


@transaction.atomic
def apply_tip(*, order: Order, actor, amount: Decimal) -> Order:
    if amount < 0:
        raise ValidationError("invalid_tip")
    order.tip_amount = amount
    order.save(update_fields=["tip_amount", "updated_at"])
    _recalc_order_totals(order)
    return order
