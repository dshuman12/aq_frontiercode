from __future__ import annotations

from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer
from django.db.models.signals import post_save
from django.dispatch import receiver

from .models import Order, OrderItem


def _broadcast(group: str, kind: str, payload: dict) -> None:
    layer = get_channel_layer()
    if layer is None:
        return
    async_to_sync(layer.group_send)(group, {
        "type": "kitchen.event",
        "kind": kind,
        "payload": payload,
    })


@receiver(post_save, sender=Order)
def broadcast_order_change(sender, instance: Order, created, **kwargs):
    if created:
        return  # we'll broadcast on submit, not creation (which is empty)
    if instance.status in ("submitted", "in_kitchen", "ready"):
        _broadcast(
            f"kitchen.{instance.location_id}",
            "order.updated",
            {"order_id": str(instance.id), "status": instance.status,
             "order_number": instance.order_number},
        )
    if instance.status == "ready":
        _broadcast(
            f"expo.{instance.location_id}",
            "order.ready",
            {"order_id": str(instance.id),
             "order_number": instance.order_number,
             "table_number": instance.table_number},
        )


@receiver(post_save, sender=OrderItem)
def broadcast_item_change(sender, instance: OrderItem, **kwargs):
    if instance.status in ("sent_to_kitchen", "in_progress", "ready"):
        order = instance.order
        _broadcast(
            f"kitchen.{order.location_id}",
            "item.updated",
            {"item_id": str(instance.id),
             "order_id": str(order.id),
             "status": instance.status,
             "name": instance.item_name_snapshot,
             "quantity": instance.quantity},
        )
