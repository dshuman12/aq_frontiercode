"""Operations chore: close orders that have been 'served' or 'paid' for more
than N days but never moved to 'closed'. Runs nightly via Celery beat."""
from __future__ import annotations

from datetime import timedelta

from django.core.management.base import BaseCommand
from django.utils import timezone

from apps.orders.models import Order, OrderEvent


class Command(BaseCommand):
    help = "Close orders served/paid more than N days ago."

    def add_arguments(self, parser):
        parser.add_argument("--days", type=int, default=2)

    def handle(self, *args, days=2, **options):
        cutoff = timezone.now() - timedelta(days=days)
        candidates = Order.objects.filter(
            status="paid", paid_at__lt=cutoff,
        )
        n = 0
        for o in candidates:
            o.status = "closed"
            o.closed_at = timezone.now()
            o.save(update_fields=["status", "closed_at", "updated_at"])
            OrderEvent.objects.create(order=o, kind="auto_closed",
                                       payload={"after_days": days})
            n += 1
        self.stdout.write(self.style.SUCCESS(f"Auto-closed {n} orders."))
