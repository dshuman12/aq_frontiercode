"""Generate sample orders for demo purposes — random items, mostly paid."""
from __future__ import annotations

import random
from decimal import Decimal

from django.core.management.base import BaseCommand

from apps.locations.models import Location
from apps.menus.models import MenuItem
from apps.orders.services import (
    add_item, create_order, fire_to_kitchen, mark_order_served, submit_order,
)
from apps.payments.services import record_card_payment, record_cash_payment
from apps.restaurants.models import Restaurant


class Command(BaseCommand):
    help = "Generate random demo orders for a restaurant."

    def add_arguments(self, parser):
        parser.add_argument("--restaurant", required=True)
        parser.add_argument("--count", type=int, default=20)

    def handle(self, *args, restaurant, count, **options):
        rest = Restaurant.objects.get(slug=restaurant)
        loc = Location.objects.filter(restaurant=rest).first()
        items = list(MenuItem.objects.filter(
            restaurant=rest, is_available=True, archived_at__isnull=True,
        ))
        if not items:
            self.stderr.write("No menu items.")
            return
        for _ in range(count):
            o = create_order(restaurant=rest, location=loc,
                             kind="dine_in", table_number=str(random.randint(1, 30)),
                             guest_count=random.randint(1, 4))
            for _ in range(random.randint(1, 4)):
                add_item(order=o, menu_item=random.choice(items),
                         quantity=random.randint(1, 3))
            submit_order(order=o)
            fire_to_kitchen(order=o)
            mark_order_served(order=o)
            o.refresh_from_db()
            method = random.choice(["cash", "card"])
            tip = (o.total_amount * Decimal("0.18")).quantize(Decimal("0.01"))
            if method == "cash":
                record_cash_payment(order=o, amount=o.total_amount, tip=tip)
            else:
                record_card_payment(order=o, amount=o.total_amount, tip=tip,
                                    card_brand="visa", card_last4="4242")
        self.stdout.write(self.style.SUCCESS(f"Created {count} demo orders."))
