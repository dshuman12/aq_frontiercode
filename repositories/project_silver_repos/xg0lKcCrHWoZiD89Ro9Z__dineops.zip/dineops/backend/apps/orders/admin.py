from django.contrib import admin

from .models import Order, OrderEvent, OrderItem, OrderItemModifier


class OrderItemModifierInline(admin.TabularInline):
    model = OrderItemModifier
    extra = 0
    readonly_fields = ("modifier_option", "name_snapshot", "price_delta")
    can_delete = False


class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 0
    fields = ("course", "sort", "menu_item", "quantity",
              "unit_price", "line_total", "status")
    readonly_fields = ("line_total",)


class OrderEventInline(admin.TabularInline):
    model = OrderEvent
    extra = 0
    readonly_fields = ("actor", "kind", "payload", "created_at")
    can_delete = False


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ("order_number", "kind", "status", "table_number",
                    "guest_count", "total_amount", "created_at")
    list_filter = ("status", "kind", "location")
    search_fields = ("order_number", "table_number", "customer_name")
    inlines = [OrderItemInline, OrderEventInline]
    readonly_fields = ("order_number", "subtotal", "tax_amount",
                       "service_charge_amount", "total_amount",
                       "balance_due", "submitted_at", "ready_at",
                       "served_at", "paid_at", "closed_at", "voided_at")


@admin.register(OrderItem)
class OrderItemAdmin(admin.ModelAdmin):
    list_display = ("order", "item_name_snapshot", "quantity",
                    "unit_price", "line_total", "status")
    list_filter = ("status",)
    inlines = [OrderItemModifierInline]
