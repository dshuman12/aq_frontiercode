from __future__ import annotations

from decimal import Decimal

from django.db import transaction
from django.utils import timezone

from apps.common.exceptions import ValidationError
from apps.inventory.models import InventoryItem
from apps.inventory.services import consume_stock

from .models import WasteEntry


@transaction.atomic
def log_waste(*, restaurant, inventory_item: InventoryItem, reason: str,
              quantity: Decimal, actor=None, notes: str = "",
              photo_url: str = "",
              occurred_at=None) -> WasteEntry:
    if inventory_item.restaurant_id != restaurant.id:
        raise ValidationError("inventory_item_not_in_restaurant")
    if quantity is None or quantity <= 0:
        raise ValidationError("invalid_quantity")
    if reason not in dict(WasteEntry.REASON_CHOICES):
        raise ValidationError("invalid_reason")
    occurred_at = occurred_at or timezone.now()

    unit_cost = inventory_item.average_cost
    consume_stock(
        item=inventory_item, quantity=quantity, kind="waste",
        reference=f"waste:{reason}", actor=actor, occurred_at=occurred_at,
    )
    cost = (quantity * unit_cost).quantize(Decimal("0.01"))
    return WasteEntry.objects.create(
        restaurant=restaurant, location=inventory_item.location,
        inventory_item=inventory_item,
        reason=reason, quantity=quantity,
        unit_cost_at_loss=unit_cost, cost=cost,
        actor=actor, notes=notes, photo_url=photo_url,
        occurred_at=occurred_at,
    )


def waste_summary(*, restaurant_id, start, end, location_id=None) -> dict:
    qs = WasteEntry.objects.filter(
        restaurant_id=restaurant_id,
        occurred_at__gte=start, occurred_at__lte=end,
    )
    if location_id:
        qs = qs.filter(location_id=location_id)
    by_reason: dict[str, dict] = {}
    total_cost = Decimal("0")
    total_count = 0
    for entry in qs:
        bucket = by_reason.setdefault(entry.reason, {
            "count": 0, "cost": Decimal("0"),
        })
        bucket["count"] += 1
        bucket["cost"] = (bucket["cost"] + entry.cost).quantize(Decimal("0.01"))
        total_cost += entry.cost
        total_count += 1
    return {
        "total_entries": total_count,
        "total_cost": total_cost.quantize(Decimal("0.01")),
        "by_reason": by_reason,
    }
