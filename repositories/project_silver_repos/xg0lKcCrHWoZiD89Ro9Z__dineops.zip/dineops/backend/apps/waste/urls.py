from django.urls import path

from . import views

app_name = "waste"

urlpatterns = [
    path("<uuid:restaurant_id>/",
         views.WasteListCreate.as_view(), name="list-create"),
    path("<uuid:restaurant_id>/summary/",
         views.WasteSummaryView.as_view(), name="summary"),
]
