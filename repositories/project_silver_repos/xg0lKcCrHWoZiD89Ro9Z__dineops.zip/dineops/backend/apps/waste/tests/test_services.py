from __future__ import annotations

from datetime import datetime, timedelta, timezone as dtz
from decimal import Decimal

import pytest

from apps.accounts.models import User
from apps.common.exceptions import ValidationError
from apps.ingredients.models import Ingredient
from apps.inventory.services import create_inventory_item
from apps.locations.models import Location
from apps.restaurants.models import Restaurant
from apps.waste.services import log_waste, waste_summary


pytestmark = pytest.mark.django_db


def _setup():
    owner = User.objects.create_user(email="o@x.com", password="pwpwpwpw")
    rest = Restaurant.objects.create(name="R", slug="r", owner=owner)
    loc = Location.objects.create(
        restaurant=rest, name="Main", slug="main", accepts_dine_in=True,
    )
    ing = Ingredient.objects.create(restaurant=rest, name="Lettuce",
                                    base_unit="g")
    item = create_inventory_item(
        restaurant=rest, location=loc, ingredient=ing,
        opening_quantity=Decimal("1000"), opening_cost=Decimal("0.02"),
    )
    return rest, loc, item, owner


class TestLogWaste:
    def test_creates_entry_and_decrements(self):
        rest, loc, item, owner = _setup()
        entry = log_waste(
            restaurant=rest, inventory_item=item,
            reason="spoilage", quantity=Decimal("200"), actor=owner,
        )
        assert entry.cost == Decimal("4.00")  # 200 * 0.02
        item.refresh_from_db()
        assert item.quantity_on_hand == Decimal("800.000")

    def test_invalid_reason_rejected(self):
        rest, _, item, _ = _setup()
        with pytest.raises(ValidationError):
            log_waste(restaurant=rest, inventory_item=item,
                      reason="bad_reason", quantity=Decimal("1"))

    def test_zero_qty(self):
        rest, _, item, _ = _setup()
        with pytest.raises(ValidationError):
            log_waste(restaurant=rest, inventory_item=item,
                      reason="spoilage", quantity=Decimal("0"))

    def test_cross_restaurant_rejected(self):
        rest1, _, item, owner = _setup()
        rest2 = Restaurant.objects.create(name="R2", slug="r2", owner=owner)
        with pytest.raises(ValidationError):
            log_waste(restaurant=rest2, inventory_item=item,
                      reason="spoilage", quantity=Decimal("1"))


class TestWasteSummary:
    def test_aggregates_by_reason(self):
        rest, loc, item, owner = _setup()
        log_waste(restaurant=rest, inventory_item=item,
                  reason="spoilage", quantity=Decimal("100"), actor=owner)
        log_waste(restaurant=rest, inventory_item=item,
                  reason="spoilage", quantity=Decimal("50"), actor=owner)
        log_waste(restaurant=rest, inventory_item=item,
                  reason="burn", quantity=Decimal("30"), actor=owner)
        start = datetime.now(dtz.utc) - timedelta(days=1)
        end = datetime.now(dtz.utc) + timedelta(days=1)
        summary = waste_summary(restaurant_id=rest.id, start=start, end=end)
        assert summary["total_entries"] == 3
        assert summary["by_reason"]["spoilage"]["count"] == 2
        # 150 * 0.02 = 3.00
        assert summary["by_reason"]["spoilage"]["cost"] == Decimal("3.00")
