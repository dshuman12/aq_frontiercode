from django.contrib import admin

from .models import WasteEntry


@admin.register(WasteEntry)
class WasteEntryAdmin(admin.ModelAdmin):
    list_display = ("inventory_item", "reason", "quantity", "cost",
                    "actor", "occurred_at")
    list_filter = ("reason", "location", "occurred_at")
    search_fields = ("notes", "inventory_item__ingredient__name")
