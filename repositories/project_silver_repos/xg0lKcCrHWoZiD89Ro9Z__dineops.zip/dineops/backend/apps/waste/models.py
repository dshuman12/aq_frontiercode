from __future__ import annotations

import uuid

from django.conf import settings
from django.db import models

from apps.common.models import TimeStampedModel


class WasteEntry(TimeStampedModel):
    """A single recorded waste event — a chef tossed 200g of bad lettuce.
    Decrements inventory at logging time and is included in M12 cost reports."""

    REASON_CHOICES = [
        ("spoilage", "Spoilage / expiry"),
        ("breakage", "Breakage / drop"),
        ("burn", "Burn / overcooked"),
        ("over_prep", "Over-prepared"),
        ("returned", "Customer returned"),
        ("training", "Training"),
        ("contamination", "Contamination"),
        ("recall", "Vendor recall"),
        ("other", "Other"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    restaurant = models.ForeignKey(
        "restaurants.Restaurant", on_delete=models.CASCADE,
        related_name="waste_entries",
    )
    location = models.ForeignKey(
        "locations.Location", on_delete=models.CASCADE,
        related_name="waste_entries",
    )
    inventory_item = models.ForeignKey(
        "inventory.InventoryItem", on_delete=models.PROTECT,
        related_name="waste_entries",
    )
    reason = models.CharField(max_length=20, choices=REASON_CHOICES)
    quantity = models.DecimalField(max_digits=12, decimal_places=3)
    unit_cost_at_loss = models.DecimalField(max_digits=10, decimal_places=4, default=0)
    cost = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    notes = models.CharField(max_length=300, blank=True)

    actor = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="logged_waste",
    )
    occurred_at = models.DateTimeField()
    photo_url = models.CharField(max_length=500, blank=True)

    class Meta:
        ordering = ["-occurred_at"]
        indexes = [
            models.Index(fields=["restaurant", "-occurred_at"]),
            models.Index(fields=["reason"]),
            models.Index(fields=["inventory_item"]),
        ]
