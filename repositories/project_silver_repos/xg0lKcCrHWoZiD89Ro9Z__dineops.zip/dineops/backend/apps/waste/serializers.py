from __future__ import annotations

from rest_framework import serializers

from .models import WasteEntry


class WasteEntrySerializer(serializers.ModelSerializer):
    ingredient_name = serializers.CharField(
        source="inventory_item.ingredient.name", read_only=True,
    )
    location_name = serializers.CharField(
        source="location.name", read_only=True,
    )
    actor_email = serializers.CharField(source="actor.email", read_only=True)

    class Meta:
        model = WasteEntry
        fields = [
            "id", "restaurant", "location", "location_name",
            "inventory_item", "ingredient_name",
            "reason", "quantity", "unit_cost_at_loss", "cost",
            "notes", "actor", "actor_email", "occurred_at", "photo_url",
        ]
        read_only_fields = ["id", "unit_cost_at_loss", "cost",
                            "actor", "actor_email"]


class LogWasteSerializer(serializers.Serializer):
    inventory_item_id = serializers.UUIDField()
    reason = serializers.ChoiceField(choices=WasteEntry.REASON_CHOICES)
    quantity = serializers.DecimalField(max_digits=12, decimal_places=3)
    notes = serializers.CharField(required=False, allow_blank=True)
    photo_url = serializers.CharField(required=False, allow_blank=True)
