from __future__ import annotations

from datetime import datetime, timedelta, timezone as dtz

from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common.exceptions import NotFound, PermissionDenied
from apps.inventory.models import InventoryItem
from apps.restaurants.models import Restaurant, RestaurantMember

from . import services
from .models import WasteEntry
from .serializers import LogWasteSerializer, WasteEntrySerializer


def _require_member(user, restaurant_id):
    m = RestaurantMember.objects.filter(
        restaurant_id=restaurant_id, user=user, status="active",
    ).first()
    if not m:
        raise PermissionDenied("not_a_member")
    return m


def _can_log_waste(roles):
    return any(r in (
        "owner", "general_manager", "assistant_manager",
        "chef", "kitchen_staff", "inventory_manager",
    ) for r in roles or [])


class WasteListCreate(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        _require_member(request.user, restaurant_id)
        qs = WasteEntry.objects.filter(
            restaurant_id=restaurant_id,
        ).select_related("inventory_item__ingredient", "location").order_by(
            "-occurred_at",
        )
        if (loc := request.GET.get("location_id")):
            qs = qs.filter(location_id=loc)
        if (reason := request.GET.get("reason")):
            qs = qs.filter(reason=reason)
        return Response({"results": WasteEntrySerializer(qs[:200], many=True).data})

    def post(self, request, restaurant_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_log_waste(member.roles):
            raise PermissionDenied()
        s = LogWasteSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        rest = Restaurant.objects.get(id=restaurant_id)
        item = InventoryItem.objects.filter(
            id=s.validated_data["inventory_item_id"],
            restaurant_id=restaurant_id,
        ).first()
        if not item:
            raise NotFound("inventory_item_not_found")
        entry = services.log_waste(
            restaurant=rest, inventory_item=item,
            reason=s.validated_data["reason"],
            quantity=s.validated_data["quantity"],
            notes=s.validated_data.get("notes", ""),
            photo_url=s.validated_data.get("photo_url", ""),
            actor=request.user,
        )
        return Response({"entry": WasteEntrySerializer(entry).data}, status=201)


class WasteSummaryView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        _require_member(request.user, restaurant_id)
        days = int(request.GET.get("days", "7"))
        start = datetime.now(dtz.utc) - timedelta(days=days)
        end = datetime.now(dtz.utc)
        location_id = request.GET.get("location_id")
        summary = services.waste_summary(
            restaurant_id=restaurant_id, start=start, end=end,
            location_id=location_id,
        )
        return Response(summary)
