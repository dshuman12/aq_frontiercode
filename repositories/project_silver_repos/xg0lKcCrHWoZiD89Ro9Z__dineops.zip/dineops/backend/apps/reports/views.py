from __future__ import annotations

from datetime import date

from django.http import HttpResponse
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common.exceptions import PermissionDenied
from apps.restaurants.models import RestaurantMember

from . import exports, services


def _require_member(user, restaurant_id):
    m = RestaurantMember.objects.filter(
        restaurant_id=restaurant_id, user=user, status="active",
    ).first()
    if not m:
        raise PermissionDenied("not_a_member")
    return m


def _can_view_reports(roles):
    return any(r in (
        "owner", "general_manager", "assistant_manager", "accountant",
    ) for r in roles or [])


def _date_range(request):
    start = date.fromisoformat(request.GET["start"])
    end = date.fromisoformat(request.GET["end"])
    return start, end


class SalesSummaryView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_view_reports(member.roles):
            raise PermissionDenied()
        start, end = _date_range(request)
        location_id = request.GET.get("location_id")
        result = services.sales_summary(
            restaurant_id=restaurant_id, location_id=location_id,
            start=start, end=end,
        )
        if request.GET.get("format") == "csv":
            data = exports.sales_summary_to_csv(result)
            resp = HttpResponse(data, content_type="text/csv")
            resp["Content-Disposition"] = (
                f'attachment; filename="sales-{start}-{end}.csv"'
            )
            return resp
        return Response(result)


class TopItemsView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_view_reports(member.roles):
            raise PermissionDenied()
        start, end = _date_range(request)
        result = services.top_items(
            restaurant_id=restaurant_id,
            location_id=request.GET.get("location_id"),
            start=start, end=end,
            limit=int(request.GET.get("limit", "20")),
        )
        if request.GET.get("format") == "csv":
            return HttpResponse(
                exports.top_items_to_csv(result), content_type="text/csv",
            )
        return Response({"results": result})


class VoidCompView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_view_reports(member.roles):
            raise PermissionDenied()
        start, end = _date_range(request)
        return Response(services.void_and_comp_summary(
            restaurant_id=restaurant_id, start=start, end=end,
        ))


class LaborView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_view_reports(member.roles):
            raise PermissionDenied()
        start, end = _date_range(request)
        result = services.labor_summary(
            restaurant_id=restaurant_id,
            location_id=request.GET.get("location_id"),
            start=start, end=end,
        )
        if request.GET.get("format") == "csv":
            return HttpResponse(
                exports.labor_to_csv(result), content_type="text/csv",
            )
        return Response(result)


class COGSView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_view_reports(member.roles):
            raise PermissionDenied()
        start, end = _date_range(request)
        return Response(services.cogs_summary(
            restaurant_id=restaurant_id, start=start, end=end,
        ))


class PaymentBreakdownView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, restaurant_id):
        member = _require_member(request.user, restaurant_id)
        if not _can_view_reports(member.roles):
            raise PermissionDenied()
        start, end = _date_range(request)
        return Response(services.payment_breakdown(
            restaurant_id=restaurant_id, start=start, end=end,
        ))
