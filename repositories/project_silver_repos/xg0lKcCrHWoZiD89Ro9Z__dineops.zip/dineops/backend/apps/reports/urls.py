from django.urls import path

from . import views

app_name = "reports"

urlpatterns = [
    path("<uuid:restaurant_id>/sales-summary/",
         views.SalesSummaryView.as_view(), name="sales-summary"),
    path("<uuid:restaurant_id>/top-items/",
         views.TopItemsView.as_view(), name="top-items"),
    path("<uuid:restaurant_id>/void-comp/",
         views.VoidCompView.as_view(), name="void-comp"),
    path("<uuid:restaurant_id>/labor/",
         views.LaborView.as_view(), name="labor"),
    path("<uuid:restaurant_id>/cogs/",
         views.COGSView.as_view(), name="cogs"),
    path("<uuid:restaurant_id>/payment-breakdown/",
         views.PaymentBreakdownView.as_view(), name="payment-breakdown"),
]
