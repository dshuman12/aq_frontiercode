"""CSV export helpers — used by the reports views to stream data to a file."""
from __future__ import annotations

import csv
import io
from typing import Iterable, Sequence


def to_csv(headers: Sequence[str], rows: Iterable[Sequence]) -> bytes:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(headers)
    for row in rows:
        w.writerow(row)
    return buf.getvalue().encode("utf-8")


def sales_summary_to_csv(summary: dict) -> bytes:
    headers = ["day", "order_count", "gross", "net", "tax", "tips", "total"]
    rows = [
        [r["day"], r["order_count"], r["gross"], r["net"],
         r["tax"], r["tips"], r["total"]]
        for r in summary["rows"]
    ]
    return to_csv(headers, rows)


def top_items_to_csv(items: list[dict]) -> bytes:
    headers = ["menu_item_id", "name", "units_sold", "revenue"]
    rows = [
        [it["menu_item_id"], it["name"], it["units_sold"], it["revenue"]]
        for it in items
    ]
    return to_csv(headers, rows)


def labor_to_csv(summary: dict) -> bytes:
    headers = ["staff_email", "minutes", "cost_cents"]
    rows = [
        [r["staff_email"], r["minutes"], r["cost_cents"]]
        for r in summary["by_staff"]
    ]
    return to_csv(headers, rows)
