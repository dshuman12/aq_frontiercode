from __future__ import annotations

from datetime import date, datetime, time, timedelta, timezone as dtz
from decimal import Decimal
from typing import Iterable

from django.db.models import Count, F, Sum

from apps.orders.models import Order, OrderItem
from apps.payments.models import Payment, Refund


def _day_window(d: date):
    start = datetime.combine(d, time(0, 0)).replace(tzinfo=dtz.utc)
    end = start + timedelta(days=1)
    return start, end


def sales_summary(*, restaurant_id, location_id=None,
                  start: date, end: date) -> dict:
    """Daily sales rollup over a date range."""
    s, _ = _day_window(start)
    _, e = _day_window(end)
    qs = Order.objects.filter(
        restaurant_id=restaurant_id,
        created_at__gte=s, created_at__lt=e,
    ).exclude(status="voided")
    if location_id:
        qs = qs.filter(location_id=location_id)
    daily = (
        qs.extra({"day": "date(created_at)"})
        .values("day")
        .annotate(
            order_count=Count("id"),
            gross=Sum("subtotal"),
            net=Sum(F("subtotal") - F("discount_amount")),
            tax=Sum("tax_amount"),
            tips=Sum("tip_amount"),
            total=Sum("total_amount"),
        )
        .order_by("day")
    )
    return {
        "start": str(start), "end": str(end),
        "rows": [
            {
                "day": str(row["day"]),
                "order_count": row["order_count"],
                "gross": str(row["gross"] or Decimal("0")),
                "net": str(row["net"] or Decimal("0")),
                "tax": str(row["tax"] or Decimal("0")),
                "tips": str(row["tips"] or Decimal("0")),
                "total": str(row["total"] or Decimal("0")),
            }
            for row in daily
        ],
    }


def top_items(*, restaurant_id, location_id=None,
              start: date, end: date, limit: int = 20) -> list[dict]:
    """Best-selling menu items in the period (by units, by revenue)."""
    s, _ = _day_window(start)
    _, e = _day_window(end)
    qs = OrderItem.objects.filter(
        order__restaurant_id=restaurant_id,
        order__created_at__gte=s, order__created_at__lt=e,
    ).exclude(status__in=("voided", "comped"))
    if location_id:
        qs = qs.filter(order__location_id=location_id)
    rows = (
        qs.values("menu_item_id", "item_name_snapshot")
        .annotate(units=Sum("quantity"),
                  revenue=Sum("line_total"))
        .order_by("-revenue")[:limit]
    )
    return [
        {
            "menu_item_id": str(row["menu_item_id"]),
            "name": row["item_name_snapshot"],
            "units_sold": row["units"] or 0,
            "revenue": str(row["revenue"] or Decimal("0")),
        }
        for row in rows
    ]


def void_and_comp_summary(*, restaurant_id, start: date, end: date) -> dict:
    s, _ = _day_window(start)
    _, e = _day_window(end)
    voids = OrderItem.objects.filter(
        order__restaurant_id=restaurant_id,
        order__created_at__gte=s, order__created_at__lt=e,
        status="voided",
    )
    comps = OrderItem.objects.filter(
        order__restaurant_id=restaurant_id,
        order__created_at__gte=s, order__created_at__lt=e,
        status="comped",
    )
    void_total = sum(
        ((it.unit_price * it.quantity) for it in voids),
        Decimal("0"),
    )
    comp_total = sum(
        ((it.unit_price * it.quantity) for it in comps),
        Decimal("0"),
    )
    return {
        "void_count": voids.count(),
        "void_total": str(void_total.quantize(Decimal("0.01"))),
        "comp_count": comps.count(),
        "comp_total": str(comp_total.quantize(Decimal("0.01"))),
    }


def labor_summary(*, restaurant_id, location_id=None,
                  start: date, end: date) -> dict:
    """Worked hours and dollar cost by staff. Pulls from shifts.TimeClockEntry."""
    from apps.shifts.models import TimeClockEntry
    s, _ = _day_window(start)
    _, e = _day_window(end)
    qs = TimeClockEntry.objects.filter(
        shift__restaurant_id=restaurant_id,
        clocked_in_at__gte=s, clocked_in_at__lt=e,
        clocked_out_at__isnull=False,
    ).select_related("staff_profile__user")
    if location_id:
        qs = qs.filter(shift__location_id=location_id)

    by_staff = {}
    total_minutes = 0
    total_cost_cents = 0
    for entry in qs:
        sp = entry.staff_profile
        worked = entry.worked_minutes()
        if sp.id not in by_staff:
            by_staff[sp.id] = {
                "staff_email": sp.user.email,
                "minutes": 0, "cost_cents": 0,
            }
        by_staff[sp.id]["minutes"] += worked
        cost = int(round(worked / 60 * sp.hourly_rate_cents))
        by_staff[sp.id]["cost_cents"] += cost
        total_minutes += worked
        total_cost_cents += cost
    return {
        "total_minutes": total_minutes,
        "total_hours": round(total_minutes / 60, 2),
        "total_cost": str((Decimal(total_cost_cents) / 100).quantize(Decimal("0.01"))),
        "by_staff": list(by_staff.values()),
    }


def cogs_summary(*, restaurant_id, start: date, end: date) -> dict:
    """Cost of goods sold from inventory transactions of kind 'usage' + 'waste'."""
    from apps.inventory.models import InventoryTransaction
    s, _ = _day_window(start)
    _, e = _day_window(end)
    qs = InventoryTransaction.objects.filter(
        item__restaurant_id=restaurant_id,
        kind__in=("usage", "waste"),
        occurred_at__gte=s, occurred_at__lt=e,
    )
    total = Decimal("0")
    by_kind = {"usage": Decimal("0"), "waste": Decimal("0")}
    for t in qs:
        # quantity is negative (outflow); cost magnitude = |qty| * unit_cost
        cost = (abs(t.quantity) * t.unit_cost).quantize(Decimal("0.01"))
        total += cost
        by_kind[t.kind] += cost
    return {
        "total": str(total.quantize(Decimal("0.01"))),
        "usage": str(by_kind["usage"].quantize(Decimal("0.01"))),
        "waste": str(by_kind["waste"].quantize(Decimal("0.01"))),
    }


def payment_breakdown(*, restaurant_id, start: date, end: date) -> dict:
    s, _ = _day_window(start)
    _, e = _day_window(end)
    qs = Payment.objects.filter(
        restaurant_id=restaurant_id,
        processed_at__gte=s, processed_at__lt=e,
        status__in=("captured", "partially_refunded"),
    )
    refunds = Refund.objects.filter(
        payment__restaurant_id=restaurant_id,
        created_at__gte=s, created_at__lt=e,
        status="succeeded",
    )
    by_method = (
        qs.values("method")
        .annotate(count=Count("id"), amount=Sum("amount"),
                  tips=Sum("tip_amount"))
        .order_by("method")
    )
    return {
        "by_method": [
            {
                "method": r["method"],
                "count": r["count"],
                "amount": str(r["amount"] or Decimal("0")),
                "tips": str(r["tips"] or Decimal("0")),
            }
            for r in by_method
        ],
        "refunds_count": refunds.count(),
        "refunds_total": str(refunds.aggregate(s=Sum("amount"))["s"] or Decimal("0")),
    }
