from __future__ import annotations

from datetime import date, timedelta
from decimal import Decimal

import pytest

from apps.accounts.models import User
from apps.locations.models import Location
from apps.menus.services import create_menu_item
from apps.orders.services import (
    add_item, create_order, fire_to_kitchen, mark_order_served, submit_order,
    void_item, void_order,
)
from apps.payments.services import record_card_payment, record_cash_payment
from apps.reports.exports import (
    labor_to_csv, sales_summary_to_csv, top_items_to_csv,
)
from apps.reports.services import (
    cogs_summary, payment_breakdown, sales_summary,
    top_items, void_and_comp_summary,
)
from apps.restaurants.models import Restaurant


pytestmark = pytest.mark.django_db


def _setup():
    owner = User.objects.create_user(email="o@x.com", password="pwpwpwpw")
    rest = Restaurant.objects.create(
        name="R", slug="r", owner=owner,
        default_tax_percent=Decimal("0"),
        default_service_charge_percent=Decimal("0"),
    )
    loc = Location.objects.create(
        restaurant=rest, name="Main", slug="main", accepts_dine_in=True,
    )
    return rest, loc, owner


class TestSalesSummary:
    def test_aggregates_per_day(self):
        rest, loc, owner = _setup()
        item = create_menu_item(restaurant=rest, name="X",
                                base_price=Decimal("20"))
        for _ in range(2):
            o = create_order(restaurant=rest, location=loc,
                             table_number="1", server=owner)
            add_item(order=o, menu_item=item, quantity=1)
            submit_order(order=o)
            fire_to_kitchen(order=o)
            mark_order_served(order=o)
        today = date.today()
        result = sales_summary(restaurant_id=rest.id, start=today, end=today)
        # Single row for today
        assert len(result["rows"]) == 1
        assert result["rows"][0]["order_count"] == 2

    def test_excludes_voided(self):
        rest, loc, owner = _setup()
        item = create_menu_item(restaurant=rest, name="X",
                                base_price=Decimal("10"))
        good = create_order(restaurant=rest, location=loc,
                            table_number="1", server=owner)
        add_item(order=good, menu_item=item, quantity=1)
        submit_order(order=good)
        bad = create_order(restaurant=rest, location=loc,
                           table_number="1", server=owner)
        add_item(order=bad, menu_item=item, quantity=1)
        void_order(order=bad, actor=owner, reason="walked")
        today = date.today()
        result = sales_summary(restaurant_id=rest.id, start=today, end=today)
        if result["rows"]:
            assert result["rows"][0]["order_count"] == 1


class TestTopItems:
    def test_sorts_by_revenue(self):
        rest, loc, owner = _setup()
        cheap = create_menu_item(restaurant=rest, name="Side",
                                 base_price=Decimal("2"))
        spendy = create_menu_item(restaurant=rest, name="Steak",
                                  base_price=Decimal("32"))
        for _ in range(5):  # 5 sides = $10
            o = create_order(restaurant=rest, location=loc,
                             table_number="1", server=owner)
            add_item(order=o, menu_item=cheap, quantity=1)
            submit_order(order=o)
        # 1 steak = $32
        o = create_order(restaurant=rest, location=loc,
                         table_number="1", server=owner)
        add_item(order=o, menu_item=spendy, quantity=1)
        submit_order(order=o)
        today = date.today()
        result = top_items(restaurant_id=rest.id, start=today, end=today)
        assert result[0]["name"] == "Steak"

    def test_excludes_voids(self):
        rest, loc, owner = _setup()
        item = create_menu_item(restaurant=rest, name="X",
                                base_price=Decimal("5"))
        o = create_order(restaurant=rest, location=loc,
                         table_number="1", server=owner)
        line = add_item(order=o, menu_item=item, quantity=10)
        submit_order(order=o)
        void_item(item=line, actor=owner, reason="oops")
        today = date.today()
        result = top_items(restaurant_id=rest.id, start=today, end=today)
        # No revenue should be reported
        assert result == []


class TestVoidCompSummary:
    def test_counts(self):
        rest, loc, owner = _setup()
        item = create_menu_item(restaurant=rest, name="X",
                                base_price=Decimal("10"))
        for _ in range(3):
            o = create_order(restaurant=rest, location=loc,
                             table_number="1", server=owner)
            line = add_item(order=o, menu_item=item, quantity=1)
            submit_order(order=o)
            void_item(item=line, actor=owner, reason="x")
        today = date.today()
        result = void_and_comp_summary(restaurant_id=rest.id,
                                        start=today, end=today)
        assert result["void_count"] == 3
        assert result["void_total"] == "30.00"


class TestPaymentBreakdown:
    def test_groups_by_method(self):
        rest, loc, owner = _setup()
        item = create_menu_item(restaurant=rest, name="X",
                                base_price=Decimal("20"))
        # cash order
        o1 = create_order(restaurant=rest, location=loc,
                          table_number="1", server=owner)
        add_item(order=o1, menu_item=item, quantity=1)
        submit_order(order=o1)
        fire_to_kitchen(order=o1)
        mark_order_served(order=o1)
        record_cash_payment(order=o1, amount=Decimal("20"))
        # card order
        o2 = create_order(restaurant=rest, location=loc,
                          table_number="2", server=owner)
        add_item(order=o2, menu_item=item, quantity=1)
        submit_order(order=o2)
        fire_to_kitchen(order=o2)
        mark_order_served(order=o2)
        record_card_payment(order=o2, amount=Decimal("20"),
                            card_brand="visa", card_last4="4242")

        today = date.today()
        result = payment_breakdown(restaurant_id=rest.id,
                                   start=today, end=today)
        methods = {row["method"] for row in result["by_method"]}
        assert "cash" in methods
        assert "card" in methods


class TestExports:
    def test_sales_csv(self):
        result = {"rows": [
            {"day": "2024-01-15", "order_count": 5, "gross": "200",
             "net": "190", "tax": "16", "tips": "30", "total": "236"},
        ]}
        csv_bytes = sales_summary_to_csv(result)
        assert b"day,order_count" in csv_bytes
        assert b"2024-01-15" in csv_bytes

    def test_top_items_csv(self):
        items = [{"menu_item_id": "abc", "name": "X",
                  "units_sold": 5, "revenue": "100"}]
        out = top_items_to_csv(items)
        assert b"X,5,100" in out

    def test_labor_csv(self):
        out = labor_to_csv({"by_staff": [
            {"staff_email": "a@x.com", "minutes": 60, "cost_cents": 2000},
        ]})
        assert b"a@x.com,60,2000" in out
