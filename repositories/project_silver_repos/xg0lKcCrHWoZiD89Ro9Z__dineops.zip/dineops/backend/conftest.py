"""Project-wide pytest fixtures."""
import pytest
from rest_framework.test import APIClient


@pytest.fixture
def api_client():
    return APIClient()


@pytest.fixture
def authed_client(db, django_user_model):
    """An APIClient logged in as a fresh user."""
    user = django_user_model.objects.create_user(
        email="ali@example.com",
        password="Strong1pass",
        full_name="Ali Hyder",
    )
    client = APIClient()
    client.force_authenticate(user=user)
    client.user = user
    return client


@pytest.fixture
def factories():
    """Convenience handle for the per-module factories. Imported lazily so
    individual tests don't pay the import cost of every factory."""
    from tests import factories as f

    return f
