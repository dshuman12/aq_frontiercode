from .base import *  # noqa: F401,F403

DEBUG = False
SECRET_KEY = "test-secret"

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.postgresql",
        "NAME": "dineops_test",
        "USER": "dineops",
        "PASSWORD": "dineops_dev",
        "HOST": "localhost",
        "PORT": "5432",
    }
}

# Use in-memory channel layer for tests so we don't need Redis
CHANNEL_LAYERS = {"default": {"BACKEND": "channels.layers.InMemoryChannelLayer"}}

# Eager Celery in tests
CELERY_TASK_ALWAYS_EAGER = True
CELERY_TASK_EAGER_PROPAGATES = True

# Use locmem email backend
EMAIL_BACKEND = "django.core.mail.backends.locmem.EmailBackend"

# Speed up password hashing in tests
PASSWORD_HASHERS = ["django.contrib.auth.hashers.MD5PasswordHasher"]

# In-memory file storage
DEFAULT_FILE_STORAGE = "django.core.files.storage.InMemoryStorage"
