from .base import *  # noqa: F401,F403

DEBUG = True
SECRET_KEY = "dev-secret-key-do-not-use-in-prod"
ALLOWED_HOSTS = ["*"]

INTERNAL_IPS = ["127.0.0.1"]

# Show all SQL when DEBUG=True; helpful when developing N+1 fixes.
LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "handlers": {"console": {"class": "logging.StreamHandler"}},
    "loggers": {
        "django.db.backends": {"handlers": ["console"], "level": "INFO"},
        "dineops": {"handlers": ["console"], "level": "DEBUG"},
    },
}
