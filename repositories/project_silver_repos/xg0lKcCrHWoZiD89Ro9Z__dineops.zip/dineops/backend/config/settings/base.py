"""Base settings shared across dev / prod / test."""
from pathlib import Path

from decouple import Csv, config

BASE_DIR = Path(__file__).resolve().parent.parent.parent

SECRET_KEY = config("DJANGO_SECRET_KEY", default="dev-secret-change-me")
DEBUG = False
ALLOWED_HOSTS = config("ALLOWED_HOSTS", default="localhost,127.0.0.1", cast=Csv())

INSTALLED_APPS = [
    "daphne",
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "django.contrib.postgres",
    # Third-party
    "rest_framework",
    "rest_framework_simplejwt",
    "django_filters",
    "corsheaders",
    "channels",
    "drf_spectacular",
    "django_extensions",
    # Local apps
    "apps.accounts",
    "apps.restaurants",
    "apps.locations",
    "apps.staff",
    "apps.shifts",
    "apps.menus",
    "apps.recipes",
    "apps.ingredients",
    "apps.inventory",
    "apps.vendors",
    "apps.purchasing",
    "apps.prep",
    "apps.orders",
    "apps.kitchen",
    "apps.payments",
    "apps.closeout",
    "apps.waste",
    "apps.manager_tasks",
    "apps.notifications",
    "apps.reports",
    "apps.audit_logs",
    "apps.files",
]

MIDDLEWARE = [
    "corsheaders.middleware.CorsMiddleware",
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
    "apps.audit_logs.middleware.AuditContextMiddleware",
]

ROOT_URLCONF = "config.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

WSGI_APPLICATION = "config.wsgi.application"
ASGI_APPLICATION = "config.asgi.application"

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.postgresql",
        "NAME": config("POSTGRES_DB", default="dineops"),
        "USER": config("POSTGRES_USER", default="dineops"),
        "PASSWORD": config("POSTGRES_PASSWORD", default="dineops_dev"),
        "HOST": config("POSTGRES_HOST", default="localhost"),
        "PORT": config("POSTGRES_PORT", default="5432"),
        "CONN_MAX_AGE": 60,
    }
}

AUTH_USER_MODEL = "accounts.User"

AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

LANGUAGE_CODE = "en-us"
TIME_ZONE = "UTC"
USE_I18N = True
USE_TZ = True

STATIC_URL = "/static/"
STATIC_ROOT = BASE_DIR / "staticfiles"
MEDIA_URL = "/media/"
MEDIA_ROOT = BASE_DIR / "media"

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

# === REST framework ===
REST_FRAMEWORK = {
    "DEFAULT_AUTHENTICATION_CLASSES": (
        "rest_framework.authentication.SessionAuthentication",
        "rest_framework_simplejwt.authentication.JWTAuthentication",
    ),
    "DEFAULT_PERMISSION_CLASSES": ("rest_framework.permissions.IsAuthenticated",),
    "DEFAULT_FILTER_BACKENDS": (
        "django_filters.rest_framework.DjangoFilterBackend",
        "rest_framework.filters.SearchFilter",
        "rest_framework.filters.OrderingFilter",
    ),
    "DEFAULT_PAGINATION_CLASS": "rest_framework.pagination.PageNumberPagination",
    "PAGE_SIZE": 50,
    "DEFAULT_SCHEMA_CLASS": "drf_spectacular.openapi.AutoSchema",
    "TEST_REQUEST_DEFAULT_FORMAT": "json",
}

SPECTACULAR_SETTINGS = {
    "TITLE": "DineOps API",
    "DESCRIPTION": "Restaurant back-office and operations platform.",
    "VERSION": "0.1.0",
    "SERVE_INCLUDE_SCHEMA": False,
    "COMPONENT_SPLIT_REQUEST": True,
}

# === Celery ===
CELERY_BROKER_URL = config("CELERY_BROKER_URL", default="redis://localhost:6379/0")
CELERY_RESULT_BACKEND = config("CELERY_RESULT_BACKEND", default="redis://localhost:6379/1")
CELERY_TIMEZONE = "UTC"
CELERY_TASK_TRACK_STARTED = True
CELERY_TASK_TIME_LIMIT = 30 * 60
CELERY_BEAT_SCHEDULE = {}

# === Channels ===
CHANNEL_LAYERS = {
    "default": {
        "BACKEND": "channels_redis.core.RedisChannelLayer",
        "CONFIG": {"hosts": [config("CHANNELS_REDIS_URL", default="redis://localhost:6379/2")]},
    },
}

# === CORS ===
CORS_ALLOWED_ORIGINS = config(
    "CORS_ALLOWED_ORIGINS",
    default="http://localhost:5173,http://localhost:5174",
    cast=Csv(),
)
CORS_ALLOW_CREDENTIALS = True

# === Email ===
EMAIL_BACKEND = config(
    "EMAIL_BACKEND",
    default="django.core.mail.backends.smtp.EmailBackend",
)
EMAIL_HOST = config("EMAIL_HOST", default="localhost")
EMAIL_PORT = config("EMAIL_PORT", default=1025, cast=int)
EMAIL_HOST_USER = config("EMAIL_HOST_USER", default="")
EMAIL_HOST_PASSWORD = config("EMAIL_HOST_PASSWORD", default="")
EMAIL_USE_TLS = config("EMAIL_USE_TLS", default=False, cast=bool)
DEFAULT_FROM_EMAIL = config("DEFAULT_FROM_EMAIL", default="DineOps <noreply@dineops.example>")

# === Stripe ===
STRIPE_API_KEY = config("STRIPE_SECRET_KEY", default="")
STRIPE_PUBLISHABLE_KEY = config("STRIPE_PUBLISHABLE_KEY", default="")
STRIPE_WEBHOOK_SECRET = config("STRIPE_WEBHOOK_SECRET", default="")
DINEOPS_STRIPE_FAKE = config("DINEOPS_STRIPE_FAKE", default=False, cast=bool)

# === DineOps-specific ===
DINEOPS_LOW_STOCK_CHECK_HOURS = 6
DINEOPS_OVERTIME_THRESHOLD_HOURS = 40
DINEOPS_DEFAULT_TAX_PERCENT = 0
DINEOPS_AUDIT_LOG_RETENTION_DAYS = 365

REST_FRAMEWORK["EXCEPTION_HANDLER"] = "apps.common.exception_handler.custom_exception_handler"
REST_FRAMEWORK["DEFAULT_PAGINATION_CLASS"] = "apps.common.pagination.StandardPagination"

CELERY_BEAT_SCHEDULE.update({
    "shifts.send_shift_reminders": {
        "task": "shifts.send_shift_reminders",
        "schedule": 5 * 60,  # every 5 minutes
    },
    "shifts.close_stale_open_entries": {
        "task": "shifts.close_stale_open_entries",
        "schedule": 60 * 60,  # every hour
    },
    "inventory.scan_low_stock": {
        "task": "inventory.scan_low_stock",
        "schedule": 5 * 60,  # every 5 minutes
    },
    "inventory.notify_low_stock": {
        "task": "inventory.notify_low_stock",
        "schedule": 15 * 60,  # every 15 minutes
    },
    "inventory.scan_expiring_lots": {
        "task": "inventory.scan_expiring_lots",
        "schedule": 24 * 60 * 60,  # nightly
    },
})
