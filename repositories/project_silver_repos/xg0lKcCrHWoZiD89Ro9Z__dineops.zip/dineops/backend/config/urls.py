from django.contrib import admin
from django.urls import include, path
from drf_spectacular.views import (
    SpectacularAPIView,
    SpectacularRedocView,
    SpectacularSwaggerView,
)

from apps.common.health import liveness, readiness


urlpatterns = [
    path("admin/", admin.site.urls),
    path("healthz", liveness, name="liveness"),
    path("readyz", readiness, name="readiness"),
    path("api/auth/", include("apps.accounts.urls")),
    path("api/restaurants/", include("apps.restaurants.urls")),
    path("api/locations/", include("apps.locations.urls")),
    path("api/staff/", include("apps.staff.urls")),
    path("api/shifts/", include("apps.shifts.urls")),
    path("api/menus/", include("apps.menus.urls")),
    path("api/recipes/", include("apps.recipes.urls")),
    path("api/ingredients/", include("apps.ingredients.urls")),
    path("api/inventory/", include("apps.inventory.urls")),
    path("api/vendors/", include("apps.vendors.urls")),
    path("api/purchasing/", include("apps.purchasing.urls")),
    path("api/prep-lists/", include("apps.prep.urls")),
    path("api/orders/", include("apps.orders.urls")),
    path("api/kitchen/", include("apps.kitchen.urls")),
    path("api/payments/", include("apps.payments.urls")),
    path("api/closeouts/", include("apps.closeout.urls")),
    path("api/waste/", include("apps.waste.urls")),
    path("api/tasks/", include("apps.manager_tasks.urls")),
    path("api/notifications/", include("apps.notifications.urls")),
    path("api/reports/", include("apps.reports.urls")),
    path("api/audit-logs/", include("apps.audit_logs.urls")),
    path("api/files/", include("apps.files.urls")),
    # OpenAPI
    path("api/schema/", SpectacularAPIView.as_view(), name="schema"),
    path("api/docs/", SpectacularSwaggerView.as_view(url_name="schema"), name="swagger"),
    path("api/redoc/", SpectacularRedocView.as_view(url_name="schema"), name="redoc"),
]
