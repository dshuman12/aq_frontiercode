module.exports = {
  root: true,
  env: { browser: true, es2022: true, jest: true, node: true },
  extends: [
    "eslint:recommended",
    "plugin:react/recommended",
    "plugin:react-hooks/recommended",
  ],
  settings: { react: { version: "detect" } },
  parserOptions: { ecmaFeatures: { jsx: true }, ecmaVersion: "latest", sourceType: "module" },
  rules: {
    "react/prop-types": "off",
    "react/react-in-jsx-scope": "off",
  },
};
