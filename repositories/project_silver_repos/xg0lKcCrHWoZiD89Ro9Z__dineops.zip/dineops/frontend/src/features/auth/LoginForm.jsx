import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { authApi } from "./api";

export default function LoginForm() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const nav = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    setErr("");
    setBusy(true);
    try {
      await authApi.login({ email, password });
      nav("/");
    } catch (ex) {
      setErr(ex?.response?.data?.detail || "Login failed");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-100">
      <form onSubmit={submit}
            className="bg-white p-6 rounded shadow w-full max-w-sm">
        <h1 className="text-2xl font-semibold mb-4">DineOps</h1>
        <label className="block text-sm font-medium">Email</label>
        <input type="email" value={email} required
               className="border rounded px-2 py-1 w-full mb-3"
               onChange={(e) => setEmail(e.target.value)} />
        <label className="block text-sm font-medium">Password</label>
        <input type="password" value={password} required
               className="border rounded px-2 py-1 w-full mb-3"
               onChange={(e) => setPassword(e.target.value)} />
        {err && <p className="text-red-700 text-sm mb-2">{err}</p>}
        <button type="submit" disabled={busy}
                className="w-full bg-dineops-600 text-white py-2 rounded disabled:opacity-50">
          {busy ? "Signing in…" : "Sign in"}
        </button>
      </form>
    </div>
  );
}
