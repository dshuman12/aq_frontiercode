import { api } from "../../api/client";

export const authApi = {
  login: (payload) => api.post("/api/auth/login/", payload),
  register: (payload) => api.post("/api/auth/register/", payload),
  logout: () => api.post("/api/auth/logout/"),
  me: () => api.get("/api/auth/me/"),
  startReset: (payload) => api.post("/api/auth/password-reset/", payload),
  applyReset: (payload) => api.post("/api/auth/password-reset/confirm/", payload),
  verifyEmail: (token) =>
    api.get("/api/auth/verify-email/", { params: { token } }),
  sessions: () => api.get("/api/auth/sessions/"),
  revokeSession: (id) => api.post(`/api/auth/sessions/${id}/revoke/`),
};
