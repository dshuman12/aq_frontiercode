import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { auditApi } from "./api";

const SEVERITY_COLOR = {
  info: "text-slate-600",
  notice: "text-amber-700",
  warning: "text-orange-700",
  alert: "text-red-700 font-medium",
};

export default function AuditList({ restaurantId }) {
  const [severity, setSeverity] = useState("");
  const [resourceType, setResourceType] = useState("");

  const params = {};
  if (severity) params.severity = severity;
  if (resourceType) params.resource_type = resourceType;

  const { data, isLoading } = useQuery({
    queryKey: ["audit", restaurantId, severity, resourceType],
    queryFn: async () => (await auditApi.list(restaurantId, params)).data,
  });

  const items = data?.results || [];

  return (
    <div className="p-4">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-semibold">Audit Log</h2>
        <div className="flex gap-2">
          <select value={severity} onChange={(e) => setSeverity(e.target.value)}
                  className="border rounded px-2 py-1">
            <option value="">All severities</option>
            <option value="info">Info</option>
            <option value="notice">Notice</option>
            <option value="warning">Warning</option>
            <option value="alert">Alert</option>
          </select>
          <input
            value={resourceType}
            placeholder="Resource type"
            onChange={(e) => setResourceType(e.target.value)}
            className="border rounded px-2 py-1"
          />
        </div>
      </div>
      {isLoading ? <p>Loading…</p> : (
        <table className="w-full bg-white border rounded text-sm">
          <thead className="bg-slate-100 text-left">
            <tr>
              <th className="p-2">When</th>
              <th className="p-2">Actor</th>
              <th className="p-2">Action</th>
              <th className="p-2">Resource</th>
              <th className="p-2">Severity</th>
              <th className="p-2">Summary</th>
            </tr>
          </thead>
          <tbody>
            {items.map((e) => (
              <tr key={e.id} className="border-t">
                <td className="p-2 font-mono text-xs">
                  {new Date(e.created_at).toLocaleString()}
                </td>
                <td className="p-2">{e.actor_email_snapshot}</td>
                <td className="p-2 font-mono text-xs">{e.action}</td>
                <td className="p-2">{e.resource_label}</td>
                <td className={`p-2 ${SEVERITY_COLOR[e.severity]}`}>
                  {e.severity}
                </td>
                <td className="p-2">{e.summary}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
