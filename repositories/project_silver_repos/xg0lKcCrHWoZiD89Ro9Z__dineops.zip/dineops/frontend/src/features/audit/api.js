import { api } from "../../api/client";

export const auditApi = {
  list: (rid, params = {}) => api.get(`/api/audit-logs/${rid}/`, { params }),
  detail: (rid, eid) => api.get(`/api/audit-logs/${rid}/${eid}/`),
};
