import { api } from "../../api/client";

export const staffApi = {
  list: (rid, params = {}) => api.get(`/api/staff/${rid}/`, { params }),
  detail: (rid, sid) => api.get(`/api/staff/${rid}/${sid}/`),
  create: (rid, payload) => api.post(`/api/staff/${rid}/`, payload),
  patch: (rid, sid, payload) => api.patch(`/api/staff/${rid}/${sid}/`, payload),
  archive: (rid, sid) => api.delete(`/api/staff/${rid}/${sid}/`),
};

export const shiftsApi = {
  list: (rid, params = {}) => api.get(`/api/shifts/${rid}/`, { params }),
  schedule: (rid, payload) => api.post(`/api/shifts/${rid}/`, payload),
  reschedule: (rid, sid, payload) => api.patch(`/api/shifts/${rid}/${sid}/`, payload),
  cancel: (rid, sid, payload) => api.post(`/api/shifts/${rid}/${sid}/cancel/`, payload),
  clockIn: (rid, sid) => api.post(`/api/shifts/${rid}/${sid}/clock-in/`),
  clockOut: (rid, sid) => api.post(`/api/shifts/${rid}/${sid}/clock-out/`),
};
