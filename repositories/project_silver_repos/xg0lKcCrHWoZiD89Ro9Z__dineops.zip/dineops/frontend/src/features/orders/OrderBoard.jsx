import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ordersApi } from "./api";

const STATUS_COLOR = {
  pending: "bg-slate-300",
  submitted: "bg-amber-200",
  in_kitchen: "bg-blue-200",
  ready: "bg-green-200",
  served: "bg-emerald-200",
  paid: "bg-slate-200",
  voided: "bg-red-200",
};

export default function OrderBoard({ restaurantId }) {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["orders", restaurantId, "open"],
    queryFn: async () =>
      (await ordersApi.list(restaurantId, { open_only: "true" })).data,
    refetchInterval: 5000,
  });

  if (isLoading) return <div className="p-4">Loading orders…</div>;
  const orders = data?.results || [];

  return (
    <div className="p-4">
      <h2 className="text-2xl font-semibold mb-4">Orders</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {orders.length === 0 && (
          <p className="text-slate-500">No open orders.</p>
        )}
        {orders.map((o) => (
          <div key={o.id} className="border rounded p-3 bg-white">
            <div className="flex justify-between items-start">
              <div>
                <div className="font-bold">#{o.order_number}</div>
                <div className="text-sm text-slate-600">
                  {o.kind === "dine_in" ? `Table ${o.table_number}` : o.kind}
                  · {o.guest_count} guests
                </div>
              </div>
              <span className={`text-xs px-2 py-1 rounded ${STATUS_COLOR[o.status] || "bg-slate-100"}`}>
                {o.status}
              </span>
            </div>
            <div className="mt-2 flex justify-between">
              <span className="text-sm">{o.item_count} items</span>
              <span className="font-medium">${o.total_amount}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
