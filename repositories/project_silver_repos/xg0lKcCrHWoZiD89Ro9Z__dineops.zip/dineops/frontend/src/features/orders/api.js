import { api } from "../../api/client";

export const ordersApi = {
  list: (rid, params = {}) => api.get(`/api/orders/${rid}/`, { params }),
  create: (rid, payload) => api.post(`/api/orders/${rid}/`, payload),
  detail: (rid, oid) => api.get(`/api/orders/${rid}/${oid}/`),
  addItem: (rid, oid, payload) => api.post(`/api/orders/${rid}/${oid}/items/`, payload),
  voidItem: (rid, iid, payload) => api.post(`/api/orders/${rid}/items/${iid}/void/`, payload),
  compItem: (rid, iid, payload) => api.post(`/api/orders/${rid}/items/${iid}/comp/`, payload),
  submit: (rid, oid) => api.post(`/api/orders/${rid}/${oid}/submit/`),
  fire: (rid, oid) => api.post(`/api/orders/${rid}/${oid}/fire/`),
  serve: (rid, oid) => api.post(`/api/orders/${rid}/${oid}/serve/`),
  void: (rid, oid, payload) => api.post(`/api/orders/${rid}/${oid}/void/`, payload),
  discount: (rid, oid, payload) => api.post(`/api/orders/${rid}/${oid}/discount/`, payload),
  tip: (rid, oid, payload) => api.post(`/api/orders/${rid}/${oid}/tip/`, payload),
};
