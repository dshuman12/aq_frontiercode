import { api } from "../../api/client";

export const inventoryApi = {
  list: (rid, params = {}) => api.get(`/api/inventory/${rid}/items/`, { params }),
  detail: (rid, iid) => api.get(`/api/inventory/${rid}/items/${iid}/`),
  patch: (rid, iid, payload) => api.patch(`/api/inventory/${rid}/items/${iid}/`, payload),
  receive: (rid, iid, payload) => api.post(`/api/inventory/${rid}/items/${iid}/receive/`, payload),
  consume: (rid, iid, payload) => api.post(`/api/inventory/${rid}/items/${iid}/consume/`, payload),
  transfer: (rid, iid, payload) => api.post(`/api/inventory/${rid}/items/${iid}/transfer/`, payload),
  transactions: (rid, iid) => api.get(`/api/inventory/${rid}/items/${iid}/transactions/`),
  lowStock: (rid, params = {}) => api.get(`/api/inventory/${rid}/low-stock/`, { params }),
  expiringLots: (rid, params = {}) => api.get(`/api/inventory/${rid}/expiring-lots/`, { params }),
  startCount: (rid, payload) => api.post(`/api/inventory/${rid}/counts/`, payload),
  countDetail: (rid, cid) => api.get(`/api/inventory/${rid}/counts/${cid}/`),
  submitCountLine: (rid, lid, payload) =>
    api.patch(`/api/inventory/${rid}/count-lines/${lid}/`, payload),
  completeCount: (rid, cid) => api.post(`/api/inventory/${rid}/counts/${cid}/complete/`),
};
