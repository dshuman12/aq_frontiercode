import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { inventoryApi } from "./api";

export default function InventoryList({ restaurantId }) {
  const [lowOnly, setLowOnly] = useState(false);
  const { data, isLoading } = useQuery({
    queryKey: ["inventory", restaurantId, lowOnly],
    queryFn: async () =>
      (await inventoryApi.list(restaurantId, lowOnly ? { low_only: "true" } : {})).data,
  });

  if (isLoading) return <div className="p-4">Loading…</div>;
  const items = data?.results || [];

  return (
    <div className="p-4">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-semibold">Inventory</h2>
        <label className="text-sm flex items-center gap-1">
          <input type="checkbox" checked={lowOnly}
                 onChange={(e) => setLowOnly(e.target.checked)} />
          Below reorder point only
        </label>
      </div>
      <table className="w-full bg-white border rounded">
        <thead className="bg-slate-100 text-left">
          <tr>
            <th className="p-2">Ingredient</th>
            <th className="p-2">Location</th>
            <th className="p-2">On hand</th>
            <th className="p-2">Reorder at</th>
            <th className="p-2">Cost</th>
            <th className="p-2">Value</th>
          </tr>
        </thead>
        <tbody>
          {items.map((it) => (
            <tr key={it.id} className={`border-t ${it.is_low ? "bg-amber-50" : ""}`}>
              <td className="p-2 font-medium">{it.ingredient_name}</td>
              <td className="p-2">{it.location_name}</td>
              <td className="p-2">
                {it.quantity_on_hand} {it.base_unit}
              </td>
              <td className="p-2">{it.reorder_point}</td>
              <td className="p-2">${it.average_cost}</td>
              <td className="p-2">${it.total_value}</td>
            </tr>
          ))}
          {items.length === 0 && (
            <tr><td className="p-4 text-center text-slate-500" colSpan={6}>
              No inventory items.
            </td></tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
