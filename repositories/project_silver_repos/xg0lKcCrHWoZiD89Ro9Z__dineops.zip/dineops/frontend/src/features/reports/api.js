import { api } from "../../api/client";

export const reportsApi = {
  salesSummary: (rid, params) =>
    api.get(`/api/reports/${rid}/sales-summary/`, { params }),
  topItems: (rid, params) =>
    api.get(`/api/reports/${rid}/top-items/`, { params }),
  voidComp: (rid, params) =>
    api.get(`/api/reports/${rid}/void-comp/`, { params }),
  labor: (rid, params) =>
    api.get(`/api/reports/${rid}/labor/`, { params }),
  cogs: (rid, params) =>
    api.get(`/api/reports/${rid}/cogs/`, { params }),
  paymentBreakdown: (rid, params) =>
    api.get(`/api/reports/${rid}/payment-breakdown/`, { params }),
  exportSalesCsv: (rid, params) =>
    api.get(`/api/reports/${rid}/sales-summary/`, {
      params: { ...params, format: "csv" }, responseType: "blob",
    }),
};
