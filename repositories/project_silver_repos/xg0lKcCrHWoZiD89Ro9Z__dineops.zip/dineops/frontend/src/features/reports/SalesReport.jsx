import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { reportsApi } from "./api";

function fmtCurrency(n) {
  return `$${Number(n || 0).toFixed(2)}`;
}

export default function SalesReport({ restaurantId }) {
  const today = new Date().toISOString().slice(0, 10);
  const sevenAgo = new Date(Date.now() - 6 * 86400000).toISOString().slice(0, 10);
  const [start, setStart] = useState(sevenAgo);
  const [end, setEnd] = useState(today);

  const { data, isLoading } = useQuery({
    queryKey: ["sales-summary", restaurantId, start, end],
    queryFn: async () =>
      (await reportsApi.salesSummary(restaurantId, { start, end })).data,
  });

  const downloadCsv = async () => {
    const resp = await reportsApi.exportSalesCsv(restaurantId, { start, end });
    const url = URL.createObjectURL(resp.data);
    const a = document.createElement("a");
    a.href = url;
    a.download = `sales-${start}-${end}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const rows = data?.rows ?? [];
  const totalGross = rows.reduce((s, r) => s + Number(r.gross), 0);
  const totalNet = rows.reduce((s, r) => s + Number(r.net), 0);
  const totalTips = rows.reduce((s, r) => s + Number(r.tips), 0);

  return (
    <div className="p-4">
      <div className="flex justify-between items-end mb-4">
        <h2 className="text-2xl font-semibold">Sales Report</h2>
        <div className="flex gap-2">
          <input type="date" value={start} onChange={(e) => setStart(e.target.value)}
                 className="border rounded px-2 py-1" />
          <input type="date" value={end} onChange={(e) => setEnd(e.target.value)}
                 className="border rounded px-2 py-1" />
          <button onClick={downloadCsv}
                  className="border rounded px-3 py-1 bg-slate-100 hover:bg-slate-200">
            Download CSV
          </button>
        </div>
      </div>
      {isLoading ? (
        <p>Loading…</p>
      ) : (
        <>
          <div className="grid grid-cols-3 gap-4 mb-4">
            <div className="bg-white border rounded p-4">
              <div className="text-sm text-slate-500">Gross</div>
              <div className="text-2xl font-semibold">{fmtCurrency(totalGross)}</div>
            </div>
            <div className="bg-white border rounded p-4">
              <div className="text-sm text-slate-500">Net</div>
              <div className="text-2xl font-semibold">{fmtCurrency(totalNet)}</div>
            </div>
            <div className="bg-white border rounded p-4">
              <div className="text-sm text-slate-500">Tips</div>
              <div className="text-2xl font-semibold">{fmtCurrency(totalTips)}</div>
            </div>
          </div>
          <table className="w-full bg-white border rounded">
            <thead className="bg-slate-100 text-left">
              <tr>
                <th className="p-2">Day</th>
                <th className="p-2">Orders</th>
                <th className="p-2">Gross</th>
                <th className="p-2">Net</th>
                <th className="p-2">Tax</th>
                <th className="p-2">Tips</th>
                <th className="p-2">Total</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.day} className="border-t">
                  <td className="p-2">{r.day}</td>
                  <td className="p-2">{r.order_count}</td>
                  <td className="p-2">{fmtCurrency(r.gross)}</td>
                  <td className="p-2">{fmtCurrency(r.net)}</td>
                  <td className="p-2">{fmtCurrency(r.tax)}</td>
                  <td className="p-2">{fmtCurrency(r.tips)}</td>
                  <td className="p-2 font-medium">{fmtCurrency(r.total)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </>
      )}
    </div>
  );
}
