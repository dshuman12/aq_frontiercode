import { api } from "../../api/client";

export const closeoutApi = {
  list: (rid) => api.get(`/api/closeouts/${rid}/`),
  open: (rid, payload) => api.post(`/api/closeouts/${rid}/`, payload),
  detail: (rid, cid) => api.get(`/api/closeouts/${rid}/${cid}/`),
  recompute: (rid, cid) => api.post(`/api/closeouts/${rid}/${cid}/recompute/`),
  setCash: (rid, cid, payload) =>
    api.post(`/api/closeouts/${rid}/${cid}/cash/`, payload),
  submit: (rid, cid) => api.post(`/api/closeouts/${rid}/${cid}/submit/`),
  approve: (rid, cid) => api.post(`/api/closeouts/${rid}/${cid}/approve/`),
};
