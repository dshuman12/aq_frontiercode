import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { closeoutApi } from "./api";

export default function CloseoutForm({ restaurantId, closeout }) {
  const [cash, setCash] = useState(closeout.counted_cash_drawer || "");
  const qc = useQueryClient();

  const setCashMut = useMutation({
    mutationFn: () => closeoutApi.setCash(restaurantId, closeout.id, {
      counted_cash: cash,
    }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["closeout", closeout.id] }),
  });
  const submitMut = useMutation({
    mutationFn: () => closeoutApi.submit(restaurantId, closeout.id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["closeout", closeout.id] }),
  });

  const variance = cash !== "" && closeout.expected_cash_drawer !== undefined
    ? Number(cash) - Number(closeout.expected_cash_drawer)
    : null;

  return (
    <div className="bg-white border rounded p-4">
      <div className="grid grid-cols-2 gap-4 mb-4">
        <div><span className="text-sm text-slate-500">Order count</span>
             <div className="text-lg">{closeout.order_count}</div></div>
        <div><span className="text-sm text-slate-500">Net sales</span>
             <div className="text-lg">${closeout.net_sales}</div></div>
        <div><span className="text-sm text-slate-500">Tip total</span>
             <div className="text-lg">${closeout.tip_total}</div></div>
        <div><span className="text-sm text-slate-500">Expected cash</span>
             <div className="text-lg">${closeout.expected_cash_drawer}</div></div>
      </div>

      <label className="block text-sm font-medium">Counted cash drawer</label>
      <div className="flex gap-2 mb-2">
        <input type="number" step="0.01" value={cash}
               onChange={(e) => setCash(e.target.value)}
               className="border rounded px-2 py-1" />
        <button type="button" onClick={() => setCashMut.mutate()}
                disabled={setCashMut.isPending || closeout.status !== "draft"}
                className="border rounded px-3 py-1 bg-slate-100 disabled:opacity-50">
          Save
        </button>
      </div>
      {variance !== null && (
        <p className={`text-sm mb-3 ${variance < 0 ? "text-red-700" : variance > 0 ? "text-amber-700" : "text-green-700"}`}>
          Variance: {variance > 0 ? "+" : ""}{variance.toFixed(2)}
        </p>
      )}
      {closeout.status === "draft" && (
        <button type="button" onClick={() => submitMut.mutate()}
                disabled={submitMut.isPending || cash === ""}
                className="bg-dineops-600 text-white px-4 py-2 rounded disabled:opacity-50">
          Submit closeout
        </button>
      )}
    </div>
  );
}
