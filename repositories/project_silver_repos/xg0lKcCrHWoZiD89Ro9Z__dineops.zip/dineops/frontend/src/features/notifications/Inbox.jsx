import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { notificationsApi } from "./api";

const PRIORITY_BG = {
  0: "bg-red-100 border-red-300",
  1: "bg-amber-100 border-amber-300",
  2: "bg-white border-slate-200",
  3: "bg-slate-50 border-slate-200",
};

export default function Inbox() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["inbox"],
    queryFn: async () => (await notificationsApi.inbox()).data,
    refetchInterval: 60000,
  });
  const markRead = useMutation({
    mutationFn: (id) => notificationsApi.markRead(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["inbox"] }),
  });

  if (isLoading) return <div className="p-4">Loading…</div>;
  const items = data?.results || [];
  const unread = data?.unread_count || 0;

  return (
    <div className="p-4">
      <h2 className="text-2xl font-semibold mb-4">
        Inbox {unread > 0 && (
          <span className="ml-2 text-sm bg-red-600 text-white px-2 py-1 rounded-full">
            {unread} unread
          </span>
        )}
      </h2>
      <ul className="space-y-2">
        {items.length === 0 && <p className="text-slate-500">No notifications.</p>}
        {items.map((n) => {
          const isUnread = !n.read_at && n.status !== "dismissed";
          return (
            <li key={n.id}
                className={`border rounded p-3 ${PRIORITY_BG[n.priority] || ""}
                          ${isUnread ? "border-l-4 border-l-dineops-600" : ""}`}>
              <div className="flex justify-between items-start">
                <div>
                  <div className="font-medium">{n.title}</div>
                  <div className="text-sm text-slate-600">{n.body}</div>
                  <div className="text-xs text-slate-400 mt-1">
                    {n.kind} · {new Date(n.created_at).toLocaleString()}
                  </div>
                </div>
                {isUnread && (
                  <button
                    className="text-xs underline text-slate-500 hover:text-slate-700"
                    onClick={() => markRead.mutate(n.id)}
                  >
                    mark read
                  </button>
                )}
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
