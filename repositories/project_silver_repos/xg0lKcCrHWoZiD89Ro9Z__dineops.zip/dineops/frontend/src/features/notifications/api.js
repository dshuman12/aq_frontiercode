import { api } from "../../api/client";

export const notificationsApi = {
  inbox: () => api.get("/api/notifications/inbox/"),
  markRead: (id) => api.post(`/api/notifications/inbox/${id}/read/`),
  channels: () => api.get("/api/notifications/channels/"),
  addChannel: (payload) => api.post("/api/notifications/channels/", payload),
  patchChannel: (id, payload) => api.patch(`/api/notifications/channels/${id}/`, payload),
  preferences: () => api.get("/api/notifications/preferences/"),
  setPreference: (payload) => api.post("/api/notifications/preferences/", payload),
};
