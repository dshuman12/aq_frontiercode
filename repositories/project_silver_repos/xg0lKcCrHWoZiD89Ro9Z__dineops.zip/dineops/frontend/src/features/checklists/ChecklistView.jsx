import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { checklistsApi } from "./api";

export default function ChecklistView({ restaurantId, checklistId }) {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["checklist", checklistId],
    queryFn: async () => (await checklistsApi.detail(restaurantId, checklistId)).data,
  });
  const markDone = useMutation({
    mutationFn: (resultId) => checklistsApi.markDone(restaurantId, resultId, {}),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["checklist", checklistId] }),
  });
  const skip = useMutation({
    mutationFn: ({ resultId, reason }) =>
      checklistsApi.skip(restaurantId, resultId, { reason }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["checklist", checklistId] }),
  });

  if (isLoading) return <div className="p-4">Loading…</div>;
  const cl = data?.checklist;
  if (!cl) return <div className="p-4">Not found.</div>;

  return (
    <div className="p-4">
      <h2 className="text-2xl font-semibold mb-2">{cl.name}</h2>
      <p className="text-sm text-slate-600 mb-4">
        {cl.location_name} · {cl.for_date} · status: <strong>{cl.status}</strong>
      </p>
      <ul className="space-y-2">
        {cl.results?.map((r) => (
          <li key={r.id}
              className={`border rounded p-3 flex justify-between
                ${r.is_done ? "bg-green-50 border-green-300" : ""}
                ${r.is_skipped ? "bg-slate-100" : ""}`}>
            <div>
              <div className={r.is_done ? "line-through text-slate-500" : ""}>
                {r.label}
              </div>
              {r.notes && <div className="text-xs text-slate-500">{r.notes}</div>}
              {r.is_skipped && (
                <div className="text-xs text-amber-700">
                  Skipped: {r.skipped_reason}
                </div>
              )}
            </div>
            {!r.is_done && !r.is_skipped && (
              <div className="flex gap-2">
                <button
                  onClick={() => markDone.mutate(r.id)}
                  className="text-xs px-3 py-1 bg-green-600 text-white rounded">
                  Done
                </button>
                <button
                  onClick={() => {
                    const reason = prompt("Skip reason?");
                    if (reason) skip.mutate({ resultId: r.id, reason });
                  }}
                  className="text-xs px-3 py-1 bg-slate-300 rounded">
                  Skip
                </button>
              </div>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}
