import { api } from "../../api/client";

export const checklistsApi = {
  templates: (rid) => api.get(`/api/tasks/${rid}/templates/`),
  createTemplate: (rid, payload) => api.post(`/api/tasks/${rid}/templates/`, payload),
  addTemplateItem: (rid, tid, payload) =>
    api.post(`/api/tasks/${rid}/templates/${tid}/items/`, payload),

  list: (rid) => api.get(`/api/tasks/${rid}/checklists/`),
  detail: (rid, cid) => api.get(`/api/tasks/${rid}/checklists/${cid}/`),
  instantiate: (rid, payload) => api.post(`/api/tasks/${rid}/checklists/`, payload),
  escalate: (rid, cid, payload) =>
    api.post(`/api/tasks/${rid}/checklists/${cid}/escalate/`, payload),

  markDone: (rid, rid2, payload) =>
    api.post(`/api/tasks/${rid}/results/${rid2}/done/`, payload),
  skip: (rid, rid2, payload) =>
    api.post(`/api/tasks/${rid}/results/${rid2}/skip/`, payload),
};
