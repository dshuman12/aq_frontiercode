import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { menusApi } from "./api";

const KIND_LABELS = {
  food: "Food",
  beverage: "Beverage",
  alcohol: "Alcohol",
  dessert: "Dessert",
  side: "Side",
};

export default function MenuItemList({ restaurantId }) {
  const [q, setQ] = useState("");
  const [kindFilter, setKindFilter] = useState("");
  const [availableOnly, setAvailableOnly] = useState(false);

  const params = {};
  if (q) params.q = q;
  if (kindFilter) params.kind = kindFilter;
  if (availableOnly) params.available_only = "true";

  const { data, isLoading } = useQuery({
    queryKey: ["menu-items", restaurantId, q, kindFilter, availableOnly],
    queryFn: async () => (await menusApi.listItems(restaurantId, params)).data,
  });

  if (isLoading) return <div className="p-4">Loading…</div>;
  const items = data?.results ?? [];

  return (
    <div className="p-4">
      <div className="flex gap-3 mb-4">
        <input
          className="border rounded px-2 py-1"
          placeholder="Search items…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
        <select
          className="border rounded px-2 py-1"
          value={kindFilter}
          onChange={(e) => setKindFilter(e.target.value)}
        >
          <option value="">All kinds</option>
          {Object.entries(KIND_LABELS).map(([v, l]) => (
            <option key={v} value={v}>{l}</option>
          ))}
        </select>
        <label className="text-sm flex items-center gap-1">
          <input
            type="checkbox"
            checked={availableOnly}
            onChange={(e) => setAvailableOnly(e.target.checked)}
          />
          Available only
        </label>
      </div>
      <table className="w-full border rounded">
        <thead className="bg-slate-100 text-left text-sm">
          <tr>
            <th className="p-2">Name</th>
            <th className="p-2">Kind</th>
            <th className="p-2">Price</th>
            <th className="p-2">Available</th>
            <th className="p-2">Diet</th>
          </tr>
        </thead>
        <tbody>
          {items.length === 0 && (
            <tr><td colSpan="5" className="p-4 text-slate-500 text-center">
              No items found.
            </td></tr>
          )}
          {items.map((it) => (
            <tr key={it.id} className="border-t">
              <td className="p-2 font-medium">{it.name}</td>
              <td className="p-2 text-sm">{KIND_LABELS[it.kind] || it.kind}</td>
              <td className="p-2">${it.base_price}</td>
              <td className="p-2">
                {it.is_available
                  ? <span className="text-green-700">Yes</span>
                  : <span className="text-slate-500">No</span>}
              </td>
              <td className="p-2 text-xs space-x-1">
                {it.is_vegetarian && <span className="px-1 bg-green-100 rounded">V</span>}
                {it.is_vegan && <span className="px-1 bg-green-200 rounded">VG</span>}
                {it.is_gluten_free && <span className="px-1 bg-amber-100 rounded">GF</span>}
                {it.contains_alcohol && <span className="px-1 bg-red-100 rounded">21+</span>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
