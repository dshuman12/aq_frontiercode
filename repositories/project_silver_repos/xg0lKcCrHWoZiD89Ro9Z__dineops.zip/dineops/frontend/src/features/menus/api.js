import { api } from "../../api/client";

export const menusApi = {
  list: (restaurantId) => api.get(`/api/menus/${restaurantId}/`),
  create: (restaurantId, payload) => api.post(`/api/menus/${restaurantId}/`, payload),
  detail: (restaurantId, menuId) =>
    api.get(`/api/menus/${restaurantId}/menus/${menuId}/`),
  update: (restaurantId, menuId, payload) =>
    api.patch(`/api/menus/${restaurantId}/menus/${menuId}/`, payload),
  archive: (restaurantId, menuId) =>
    api.delete(`/api/menus/${restaurantId}/menus/${menuId}/`),

  createCategory: (restaurantId, menuId, payload) =>
    api.post(`/api/menus/${restaurantId}/menus/${menuId}/categories/`, payload),

  // Items
  listItems: (restaurantId, params = {}) =>
    api.get(`/api/menus/${restaurantId}/items/`, { params }),
  createItem: (restaurantId, payload) =>
    api.post(`/api/menus/${restaurantId}/items/`, payload),
  itemDetail: (restaurantId, itemId) =>
    api.get(`/api/menus/${restaurantId}/items/${itemId}/`),
  updateItem: (restaurantId, itemId, payload) =>
    api.patch(`/api/menus/${restaurantId}/items/${itemId}/`, payload),
  archiveItem: (restaurantId, itemId) =>
    api.delete(`/api/menus/${restaurantId}/items/${itemId}/`),

  addVariant: (restaurantId, itemId, payload) =>
    api.post(`/api/menus/${restaurantId}/items/${itemId}/variants/`, payload),

  // Modifier groups
  listModifierGroups: (restaurantId) =>
    api.get(`/api/menus/${restaurantId}/modifier-groups/`),
  createModifierGroup: (restaurantId, payload) =>
    api.post(`/api/menus/${restaurantId}/modifier-groups/`, payload),
  addModifierOption: (restaurantId, groupId, payload) =>
    api.post(`/api/menus/${restaurantId}/modifier-groups/${groupId}/options/`, payload),
  attachModifierGroup: (restaurantId, itemId, groupId) =>
    api.post(`/api/menus/${restaurantId}/items/${itemId}/modifier-groups/${groupId}/`),

  // Availability
  addMenuAvailability: (restaurantId, menuId, payload) =>
    api.post(`/api/menus/${restaurantId}/menus/${menuId}/availability/`, payload),
  addItemAvailability: (restaurantId, itemId, payload) =>
    api.post(`/api/menus/${restaurantId}/items/${itemId}/availability/`, payload),
};
