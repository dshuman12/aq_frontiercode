import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { menusApi } from "./api";

export default function MenuList({ restaurantId }) {
  const { data, isLoading, isError } = useQuery({
    queryKey: ["menus", restaurantId],
    queryFn: async () => (await menusApi.list(restaurantId)).data,
  });

  if (isLoading) return <div className="p-4">Loading menus…</div>;
  if (isError) return <div className="p-4 text-red-700">Failed to load menus.</div>;

  const menus = data?.results ?? [];
  if (menus.length === 0) {
    return (
      <div className="p-4">
        <p className="text-slate-600">No menus yet.</p>
        <Link to="new" className="text-dineops-600 underline">Create one</Link>
      </div>
    );
  }

  return (
    <div className="p-4">
      <div className="flex justify-between mb-4">
        <h2 className="text-2xl font-semibold">Menus</h2>
        <Link to="new" className="bg-dineops-600 text-white px-4 py-2 rounded">
          + New Menu
        </Link>
      </div>
      <ul className="divide-y border rounded">
        {menus.map((m) => (
          <li key={m.id} className="p-4 flex justify-between items-center">
            <div>
              <Link to={m.id} className="text-lg font-medium hover:underline">
                {m.name}
              </Link>
              {m.is_default && (
                <span className="ml-2 text-xs px-2 py-0.5 bg-dineops-100 text-dineops-700 rounded">
                  default
                </span>
              )}
              <span className="ml-2 text-sm text-slate-500">{m.kind}</span>
            </div>
            <div className="text-sm text-slate-500">
              {m.categories?.length ?? 0} categories
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
