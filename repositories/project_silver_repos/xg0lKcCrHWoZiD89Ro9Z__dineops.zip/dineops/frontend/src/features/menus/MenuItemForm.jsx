import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { menusApi } from "./api";

const KINDS = [
  "food", "beverage", "alcohol", "dessert", "side", "combo", "modifier_only",
];

export default function MenuItemForm({ restaurantId, categoryId, onCreated }) {
  const [name, setName] = useState("");
  const [basePrice, setBasePrice] = useState("0.00");
  const [kind, setKind] = useState("food");
  const [containsAlcohol, setContainsAlcohol] = useState(false);
  const [vegetarian, setVegetarian] = useState(false);
  const [vegan, setVegan] = useState(false);
  const [glutenFree, setGlutenFree] = useState(false);
  const [spice, setSpice] = useState(0);

  const qc = useQueryClient();
  const mut = useMutation({
    mutationFn: (payload) => menusApi.createItem(restaurantId, payload),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["menu-items", restaurantId] });
      setName("");
      setBasePrice("0.00");
      onCreated?.();
    },
  });

  const submit = (e) => {
    e.preventDefault();
    mut.mutate({
      name,
      base_price: basePrice,
      kind,
      category_id: categoryId,
      contains_alcohol: containsAlcohol,
      is_vegetarian: vegetarian,
      is_vegan: vegan,
      is_gluten_free: glutenFree,
      spice_level: Number(spice),
    });
  };

  return (
    <form onSubmit={submit} className="p-4 border rounded space-y-3">
      <div>
        <label className="block text-sm font-medium">Item name</label>
        <input
          className="border rounded px-2 py-1 w-full"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="block text-sm font-medium">Base price</label>
          <input
            className="border rounded px-2 py-1 w-full"
            type="number" step="0.01" min="0"
            value={basePrice}
            onChange={(e) => setBasePrice(e.target.value)}
          />
        </div>
        <div>
          <label className="block text-sm font-medium">Kind</label>
          <select
            className="border rounded px-2 py-1 w-full"
            value={kind}
            onChange={(e) => setKind(e.target.value)}
          >
            {KINDS.map((k) => <option key={k} value={k}>{k}</option>)}
          </select>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-2 text-sm">
        <label><input type="checkbox" checked={containsAlcohol}
          onChange={(e) => setContainsAlcohol(e.target.checked)} /> Alcohol</label>
        <label><input type="checkbox" checked={vegetarian}
          onChange={(e) => setVegetarian(e.target.checked)} /> Vegetarian</label>
        <label><input type="checkbox" checked={vegan}
          onChange={(e) => setVegan(e.target.checked)} /> Vegan</label>
        <label><input type="checkbox" checked={glutenFree}
          onChange={(e) => setGlutenFree(e.target.checked)} /> Gluten-free</label>
      </div>
      <div>
        <label className="block text-sm font-medium">Spice (0-5)</label>
        <input
          className="border rounded px-2 py-1 w-24"
          type="number" min="0" max="5"
          value={spice}
          onChange={(e) => setSpice(e.target.value)}
        />
      </div>
      {mut.isError && (
        <p className="text-red-700 text-sm">Failed to create item.</p>
      )}
      <button
        type="submit"
        disabled={mut.isPending}
        className="bg-dineops-600 text-white px-4 py-2 rounded disabled:opacity-50"
      >
        {mut.isPending ? "Saving…" : "Add Item"}
      </button>
    </form>
  );
}
