export default function Spinner({ size = 4 }) {
  return (
    <div
      className={`inline-block w-${size} h-${size} rounded-full border-2 border-slate-300 border-t-dineops-600 animate-spin`}
    />
  );
}
