export default function EmptyState({ icon = "📭", title, message, cta, onCta }) {
  return (
    <div className="flex flex-col items-center justify-center py-12 text-center">
      <div className="text-5xl mb-3">{icon}</div>
      <h3 className="text-lg font-medium text-slate-700">{title}</h3>
      {message && <p className="text-sm text-slate-500 mt-1 max-w-md">{message}</p>}
      {cta && (
        <button
          onClick={onCta}
          className="mt-4 bg-dineops-600 text-white px-4 py-2 rounded">
          {cta}
        </button>
      )}
    </div>
  );
}
