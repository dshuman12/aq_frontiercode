const STATUS_CONFIG = {
  pending: ["bg-slate-100", "text-slate-700"],
  draft: ["bg-slate-100", "text-slate-700"],
  submitted: ["bg-amber-100", "text-amber-800"],
  in_progress: ["bg-blue-100", "text-blue-800"],
  in_kitchen: ["bg-blue-100", "text-blue-800"],
  ready: ["bg-green-100", "text-green-800"],
  served: ["bg-emerald-100", "text-emerald-800"],
  paid: ["bg-emerald-200", "text-emerald-900"],
  closed: ["bg-slate-200", "text-slate-700"],
  voided: ["bg-red-100", "text-red-800"],
  cancelled: ["bg-red-100", "text-red-800"],
  approved: ["bg-emerald-200", "text-emerald-900"],
  completed: ["bg-emerald-100", "text-emerald-800"],
  failed: ["bg-red-100", "text-red-800"],
  refunded: ["bg-amber-100", "text-amber-800"],
  partially_refunded: ["bg-amber-100", "text-amber-800"],
  escalated: ["bg-orange-100", "text-orange-800"],
};

export default function StatusPill({ status }) {
  const [bg, fg] = STATUS_CONFIG[status] || ["bg-slate-100", "text-slate-700"];
  return (
    <span className={`inline-block text-xs px-2 py-0.5 rounded ${bg} ${fg}`}>
      {String(status || "").replace("_", " ")}
    </span>
  );
}
