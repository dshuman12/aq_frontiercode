import { useEffect, useState } from "react";

let _push = null;

export function pushToast(message, kind = "info", durationMs = 3000) {
  _push?.({ id: Math.random(), message, kind, durationMs });
}

export default function ToastHost() {
  const [items, setItems] = useState([]);
  useEffect(() => {
    _push = (toast) => {
      setItems((prev) => [...prev, toast]);
      setTimeout(() => {
        setItems((prev) => prev.filter((x) => x.id !== toast.id));
      }, toast.durationMs);
    };
    return () => { _push = null; };
  }, []);

  return (
    <div className="fixed bottom-4 right-4 z-50 space-y-2">
      {items.map((t) => (
        <div key={t.id}
             className={`px-4 py-2 rounded shadow text-sm
               ${t.kind === "error" ? "bg-red-600 text-white" :
                 t.kind === "success" ? "bg-green-600 text-white" :
                 "bg-slate-800 text-white"}`}>
          {t.message}
        </div>
      ))}
    </div>
  );
}
