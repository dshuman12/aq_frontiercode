import { create } from "zustand";

export const useUiStore = create((set) => ({
  currentRestaurantId: localStorage.getItem("dineops:rid") || null,
  setRestaurantId: (id) => {
    localStorage.setItem("dineops:rid", id);
    set({ currentRestaurantId: id });
  },

  // Modal-open flags
  modals: {},
  openModal: (name) => set((s) => ({ modals: { ...s.modals, [name]: true } })),
  closeModal: (name) => set((s) => ({ modals: { ...s.modals, [name]: false } })),

  // Sidebar collapsed (compact mode)
  sidebarCollapsed: false,
  toggleSidebar: () => set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),
}));
