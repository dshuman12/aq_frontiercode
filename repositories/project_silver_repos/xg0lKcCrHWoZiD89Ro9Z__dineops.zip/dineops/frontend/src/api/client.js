import axios from "axios";

export const apiClient = axios.create({
  baseURL: "/api",
  withCredentials: true,
  headers: { "X-Requested-With": "XMLHttpRequest" },
});

apiClient.interceptors.response.use(
  (r) => r,
  (err) => {
    // Normalize {detail, code, fields} envelope so callers don't have to dig
    if (err.response?.data) {
      err.code = err.response.data.code;
      err.fields = err.response.data.fields;
    }
    return Promise.reject(err);
  }
);

export const auth = {
  login: (data) => apiClient.post("/auth/login/", data).then((r) => r.data),
  logout: () => apiClient.post("/auth/logout/").then((r) => r.data),
  me: () => apiClient.get("/auth/me/").then((r) => r.data),
  register: (data) => apiClient.post("/auth/register/", data).then((r) => r.data),
};
