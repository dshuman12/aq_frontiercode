import { NavLink } from "react-router-dom";

const NAV = [
  { to: "/", label: "Dashboard", emoji: "🏠" },
  { to: "/orders", label: "Orders", emoji: "📋" },
  { to: "/menus", label: "Menus", emoji: "🍴" },
  { to: "/recipes", label: "Recipes", emoji: "📖" },
  { to: "/inventory", label: "Inventory", emoji: "📦" },
  { to: "/vendors", label: "Vendors", emoji: "🚚" },
  { to: "/purchasing", label: "Purchasing", emoji: "🧾" },
  { to: "/prep", label: "Prep Lists", emoji: "🥕" },
  { to: "/waste", label: "Waste", emoji: "🗑️" },
  { to: "/staff", label: "Staff", emoji: "👥" },
  { to: "/shifts", label: "Shifts", emoji: "🕐" },
  { to: "/checklists", label: "Checklists", emoji: "✅" },
  { to: "/reports", label: "Reports", emoji: "📈" },
  { to: "/closeout", label: "Closeout", emoji: "💰" },
  { to: "/audit", label: "Audit Log", emoji: "🔍" },
  { to: "/settings", label: "Settings", emoji: "⚙️" },
];

export default function Sidebar() {
  return (
    <aside className="w-56 bg-slate-900 text-slate-100 min-h-screen flex flex-col">
      <header className="p-4 border-b border-slate-700">
        <span className="font-bold text-lg">DineOps</span>
      </header>
      <nav className="flex-1 overflow-y-auto py-2">
        {NAV.map((n) => (
          <NavLink
            key={n.to} to={n.to}
            className={({ isActive }) =>
              `flex items-center gap-2 px-4 py-2 text-sm hover:bg-slate-800 ${
                isActive ? "bg-slate-800 text-white" : "text-slate-300"
              }`
            }
          >
            <span>{n.emoji}</span>
            {n.label}
          </NavLink>
        ))}
      </nav>
      <footer className="p-4 text-xs text-slate-500 border-t border-slate-700">
        v1.0 · {new Date().getFullYear()}
      </footer>
    </aside>
  );
}
