import { Routes, Route, Link } from "react-router-dom";

function Home() {
  return (
    <div className="p-8">
      <h1 className="text-3xl font-semibold">DineOps</h1>
      <p className="mt-2 text-slate-600">staff dashboard scaffolding — auth coming next.</p>
      <Link to="/about" className="text-indigo-600 underline mt-4 inline-block">
        about
      </Link>
    </div>
  );
}

function About() {
  return <div className="p-8">about page</div>;
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/about" element={<About />} />
    </Routes>
  );
}
