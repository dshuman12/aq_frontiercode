module.exports = {
  testEnvironment: "jsdom",
  testMatch: ["**/__tests__/**/*.test.{js,jsx}"],
  setupFilesAfterEach: ["<rootDir>/jest.setup.js"],
  transform: { "^.+\\.(js|jsx)$": "babel-jest" },
  moduleNameMapper: { "\\.(css|less|scss)$": "<rootDir>/__mocks__/styleMock.js" },
};
