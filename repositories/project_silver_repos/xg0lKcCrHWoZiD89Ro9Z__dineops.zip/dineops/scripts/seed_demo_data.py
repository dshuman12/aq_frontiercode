#!/usr/bin/env python
"""Convenience wrapper that calls `manage.py seed_demo_data`."""
import os
import subprocess
import sys

os.chdir(os.path.join(os.path.dirname(__file__), "..", "backend"))
sys.exit(subprocess.call([sys.executable, "manage.py", "seed_demo_data"]))
