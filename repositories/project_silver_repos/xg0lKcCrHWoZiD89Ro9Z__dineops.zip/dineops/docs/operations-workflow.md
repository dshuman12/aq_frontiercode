# Operations workflow

A typical day, end-to-end:

```
07:00  Manager opens the day
       → opening checklist created from template
       → cash drawer open count recorded
       → kitchen station screens turn on
07:30  Staff clocks in
       → shift starts, break tracker armed
08:00  Prep starts
       → daily prep list materialized from yesterday's sales pace
       → station-assigned prep items go to the kitchen screen
11:30  Service starts
       → orders flow into the kitchen screen by station
       → inventory transactions deduct ingredient stock
       → waste log captures over-prep, drops, returns
14:30  Mid-shift close
       → tip-out reports
       → labor cost vs. sales ratio updated
17:30  Evening service starts
22:00  Last orders close
22:30  Manager closes the day
       → closing checklist
       → cash drawer close count + variance recorded
       → tip totals + card totals + cash totals reconciled
       → daily closeout report PDF emailed to owner + accountant
       → manager approval recorded
```

## Why prep + waste matter

Most POS systems track sales. They don't track *food cost*, which is the
real number a restaurant manager cares about. Food cost = (opening
inventory + purchases - closing inventory - waste cost) / sales. DineOps
captures every leg of that equation.

## Where Stripe fits

- Card payments at the front of house go through Stripe Terminal (or the
  manual entry flow for taxis-without-readers).
- Online ordering → Stripe Payment Intents.
- Refunds → Stripe Refunds API. We never just write to our `Refund` table
  without confirming via webhook.
