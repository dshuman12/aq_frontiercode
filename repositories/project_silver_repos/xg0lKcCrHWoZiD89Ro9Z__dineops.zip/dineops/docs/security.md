# Security Practices

## Identity

- **Email-only identity**: We do not store usernames. Email is the canonical
  identifier (lowercased, trimmed at create time).
- **Password storage**: PBKDF2 via Django's default hasher; configurable via
  `PASSWORD_HASHERS`.
- **TOTP 2FA**: Optional; RFC 6238 implementation in stdlib (no third-party
  dependency). 6-digit codes, 30-second window, ±1 step tolerance.
- **Session tokens**: Hashed before storage (`Session.token_hash`), never
  stored raw; revocation by deletion.
- **Reset tokens** (`EmailToken`): Hashed before storage; expiry timestamp
  enforced; `consumed_at` blocks reuse.

## RBAC

Roles are stored on `RestaurantMember.roles` (JSONField, list of strings).
Permission strings are dotted (`order.void`, `inventory.transfer`).

`apps.common.permissions.has_perm(roles, perm, custom_perms)` is the single
source of truth.

The `owner` role implicitly has `*` (all permissions). Custom permission
strings on `RestaurantMember.custom_permissions` add to the role-derived
set.

## PCI Scope

We process card payments through Stripe, never touching the PAN. We log:
- `card_brand` and `card_last4` (allowed under PCI).
- `stripe_payment_intent_id` (a token reference).
- The amount and tip.

We do NOT log card numbers, CVVs, or expiration dates. Payments through
the dev/test `_FakeStripe` adapter use the literal string `4242` for
`card_last4` so it's obvious in tests.

## Webhook verification

Stripe webhooks are verified with `STRIPE_WEBHOOK_SECRET` using the standard
`stripe.Webhook.construct_event` API in production. Webhook handlers are
idempotent — receiving the same event twice does not double-bill or
double-refund.

## Tenant isolation

Every multi-tenant resource has a `restaurant` FK. Service-layer functions
that take both a `restaurant` and a related object (Location, Ingredient,
etc.) explicitly verify they belong together — see e.g.
`create_inventory_item` raising `ValidationError("location_not_in_restaurant")`.

URLs are always scoped: `/api/<module>/<restaurant_id>/...`. The
`AuditContextMiddleware` extracts `restaurant_id` from URL/query/header and
attaches it to the request for downstream code.

## Rate limiting

Custom DRF throttles in `apps.common.throttle`:
- `login` — 10/minute per IP.
- `password_reset` — 5/hour per IP.
- `stripe_webhook` — 120/minute per IP (Stripe retries).
- `anon` — 60/minute, `user` — 1000/hour as defaults.

## Auditing

Money-affecting and inventory-affecting actions are recorded in
`AuditEntry`. See `docs/audit-trail.md`. Audit logs are append-only;
the Django admin is read-only on this model.

## Secrets

- All secrets via `python-decouple` from `.env`.
- `DJANGO_SECRET_KEY` rotation rotates session signing — rotate during a
  maintenance window.
- Stripe keys are never logged (we redact with a custom log filter; in dev
  they can be empty to use `_FakeStripe`).

## Dependencies

`pip-audit` is run weekly on `requirements.txt`. CVEs of severity HIGH or
above are addressed within the same week.
