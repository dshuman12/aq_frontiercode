# Architecture Overview

A bird's-eye view of how DineOps fits together.

## Layers

```
┌──────────────────────────────────────────────────────────┐
│              Staff app (React/Vite)                       │
│              Kitchen screen (React/Vite)                  │
│              Optional: 3rd-party POS sync (future)        │
└──────────────────────────────┬───────────────────────────┘
                               │ JWT + WebSocket
┌──────────────────────────────▼───────────────────────────┐
│         Django/Daphne (HTTP + WebSocket via Channels)    │
│         ┌─────────────────────────────────────────┐      │
│         │  apps.* (24 apps)                        │      │
│         │  models / services / selectors /         │      │
│         │  serializers / views / signals / tasks  │      │
│         └─────────────────────────────────────────┘      │
└────────────┬──────────────────┬──────────────────┬───────┘
             │                  │                  │
       ┌─────▼─────┐    ┌──────▼──────┐    ┌──────▼──────┐
       │ PostgreSQL│    │   Redis     │    │   Stripe    │
       │  15+      │    │ (broker +   │    │ (real or    │
       │           │    │  channels   │    │  fake)      │
       │           │    │  layer)     │    │             │
       └───────────┘    └─────────────┘    └─────────────┘
                              │
                       ┌──────▼──────┐
                       │   Celery    │
                       │ worker+beat │
                       └─────────────┘
```

## Tenant model

DineOps is multi-tenant. The Restaurant model is the tenant root. Every
multi-tenant model carries a `restaurant` FK and every API URL includes
the `restaurant_id` for explicit scoping.

## Service layer pattern

Each app follows the HackSoftware-style layout:
- `models.py` — Django models (data only, light validation).
- `services.py` — business logic (mutating operations).
- `selectors.py` — read-only query helpers.
- `serializers.py` — DRF serializers (input validation, output shaping).
- `views.py` — DRF APIView classes (HTTP-layer only, delegates to services/selectors).
- `tasks.py` — Celery tasks.
- `signals.py` / `handlers.py` — fan-out side effects.
- `urls.py` — URL routing for the app.
- `tests/` — pytest tests.

## Money + quantity types

- Money: `DecimalField(max_digits=12, decimal_places=2)` for line items;
  larger digits for aggregates. Always `Decimal`, never `float`.
- Quantities: `DecimalField(max_digits=12, decimal_places=3)` for inventory
  qty (3 decimals because a recipe might call for 0.005 kg of saffron).

## UUIDs everywhere

All PKs are `UUIDField`. See ADR 0006.

## Soft delete via archived_at

See ADR 0005.

## Permissions

Roles + custom_permissions live on `RestaurantMember`. The
`apps.common.permissions.has_perm()` function is the single check.

## Background work

Celery tasks for: shift reminders, low-stock scanning + notifications,
expiring lots, stale order cleanup, daily closeout opening, weighted-cost
recompute on bulk price updates.

## Real-time

WebSockets via Channels for: kitchen screen, expo board, per-user
notification inbox.

## External integrations

- **Stripe**: payment intents + refunds + webhook listening.
- **Email**: stdlib `string.Template` rendering, sent via SMTP / SES.
- **SMS / Push**: stubs in place; production wires Twilio + FCM.

## Failure modes

Refer to `docs/runbook.md` for operational responses to common alerts.
