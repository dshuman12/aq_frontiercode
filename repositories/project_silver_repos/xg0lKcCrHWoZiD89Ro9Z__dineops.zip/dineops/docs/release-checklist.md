# Release Checklist

Before tagging a release.

## Code

- [ ] `pytest -x` passes locally and in CI.
- [ ] `ruff check .` and `black --check .` pass.
- [ ] No `print(...)` statements outside management commands.
- [ ] No `breakpoint()` or `pdb` left in code.
- [ ] No `TODO` comments without an owner.

## Schema

- [ ] All migrations are forward + backward compatible (no `RunPython`
      that depends on Python state).
- [ ] If migrating data, there's a rollback path.
- [ ] Indexes for new query patterns are in the migration.

## Docs

- [ ] CHANGELOG.md has an entry for the new version.
- [ ] If a new public endpoint was added, `docs/api-reference.md` has it.
- [ ] If a new ADR was needed, it's in `docs/decisions/`.

## Backend

- [ ] No new dependencies pinned to floating versions.
- [ ] `requirements.txt` is sorted.
- [ ] `pip-audit` passes (or known issues are documented).
- [ ] Celery beat schedule changes are deployed BEFORE the worker code.

## Frontend

- [ ] `npm run build` succeeds with zero warnings.
- [ ] Bundle size hasn't grown by more than 10%.
- [ ] No console errors on a smoke walkthrough of key screens.

## Operations

- [ ] All env vars used by new code are documented in `.env.example`.
- [ ] Deployment script handles the migration order.
- [ ] Stripe integration tested against sandbox after deploy.
- [ ] Smoke tests pass against staging.

## Communication

- [ ] Customer success briefed on user-facing changes.
- [ ] On-call schedule confirmed for the week after release.
