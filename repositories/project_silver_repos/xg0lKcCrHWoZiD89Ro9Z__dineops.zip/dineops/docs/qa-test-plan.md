# QA Test Plan

A playbook for the QA team to follow before signing off on a release.

## Critical paths (must pass)

### Order flow

- Create dine-in order with table number, 2 guests.
- Add 3 items, one with a required modifier (cooking temp).
- Try to add an alcohol item without age verification — must reject.
- Submit order. Item statuses go to `sent_to_kitchen`.
- Fire to kitchen. Order status → `in_kitchen`.
- Kitchen marks each item ready. Order status → `ready`.
- Mark order served. Order status → `served`.
- Take cash payment with tip. Order status → `paid`.
- Verify payment row has `card_last4=""` for cash.

### Inventory

- Receive 100kg of beef at $5/kg. Verify quantity_on_hand and
  average_cost update.
- Receive 100kg more at $7/kg. Verify weighted average is $6.
- Consume 50kg as usage. Verify lot decremented FEFO.
- Mark a lot recalled. Verify next consumption skips it.
- Drive an item below reorder_point. Verify a LowStockAlert is created.

### Counts

- Start a count session. Verify line for every active item.
- Submit some lines with variance. Submit some matching expected.
- Complete the count. Verify count_adjustment transactions written.

### Closeout

- Wait until end of day with multiple paid orders.
- Open a closeout for the day.
- Recompute. Verify totals match expectations.
- Set counted cash slightly below expected. Verify variance is negative.
- Submit. Verify cannot edit anymore.
- Approve as owner. Verify status = approved.

### Refunds

- Issue a partial refund on a card payment.
- Verify Payment.status = partially_refunded.
- Issue a second refund that completes the original payment.
- Verify Payment.status = refunded.
- Verify Stripe refund ID was stored (in fake mode it's a `re_test_*`).

## Permission probing

For each role:
- `server` — can take orders, cannot void.
- `kitchen_staff` — cannot take orders or void; can complete prep tasks.
- `chef` — can manage recipes/inventory; cannot take orders.
- `inventory_manager` — can manage inventory; cannot take orders or void.
- `accountant` — can refund + see audit log + reports; cannot take orders.
- `viewer` — read-only across the board.

## Browser matrix

- Chrome (latest) on macOS / Windows.
- Safari (latest) on macOS / iPadOS.
- Edge (latest) on Windows.
- Mobile Safari (iOS 17+).
- Mobile Chrome (Android 14+).

## Performance smoke

- 200 menu items load page < 1.5s.
- Inventory page with 1000 items loads < 3s.
- Order board auto-refresh every 5s doesn't lag.
- Kitchen screen with 30 active orders renders smoothly.
