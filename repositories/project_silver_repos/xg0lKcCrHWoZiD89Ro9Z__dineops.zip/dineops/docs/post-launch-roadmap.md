# Post-Launch Roadmap

What we're considering for v1.x and v2.

## v1.1 (Q2 2024)

- Per-lot cost flow as an opt-in alternative to weighted-average.
- Negative-stock override flag for emergency prep.
- Drawer-level closeout for multi-drawer locations.
- Bug-fix backlog from pilot feedback.

## v1.2 (Q3 2024)

- 3-way invoice/PO/receipt match in payments.
- Customer-facing "house account" tab printing for fine-dining members.
- Multi-currency settlement (today the UI supports multi-currency display
  but settlement is per-restaurant).

## v1.3 (Q4 2024)

- POS device sync (Square Terminal first; Toast later).
- Multi-location pricing for chains.
- Recipe substitution rules (if ingredient X is OOS, swap to Y).

## v2.0 (2025)

- Multi-tenant analytics (compare across restaurants in a chain).
- Predictive prep (use last 4 weeks of demand to suggest prep quantities).
- AI-powered menu engineering (high-margin → push, low-margin → revisit).

## Things we're NOT doing

- Customer-facing online ordering (Toast/Square already cover this).
- Loyalty program (out of scope; integrate with a partner).
- Reservations (use OpenTable; we link orders to their booking ID later).
