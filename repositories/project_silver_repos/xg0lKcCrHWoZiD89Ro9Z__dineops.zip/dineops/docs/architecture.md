# Architecture

DineOps is a Python/Django backend with two React frontends:

- **frontend/** — staff web app (managers, servers, cashiers).
- **kitchen_screen/** — separate React app optimized for kitchen tablets.

The backend exposes a single REST API at `/api/*` plus websocket endpoints
under `/ws/*` for kitchen tickets and notifications.

## Apps and boundaries

```
accounts          → users, sessions, password reset, 2FA
restaurants       → tenant root: a restaurant + its members
locations         → branches under a restaurant
staff             → employee profiles (extends a User)
shifts            → schedule + clock-in + breaks + overtime
menus             → categories, items, modifiers, variants
recipes           → recipe + ingredient mapping + costing
ingredients       → master ingredient catalog
inventory         → stock + transactions + counts + lots + alerts
vendors           → vendor directory + product catalog
purchasing        → POs + receiving + supplier invoices
prep              → daily prep lists + batches
orders            → orders + items + modifiers + status history
kitchen           → kitchen tickets routed by station + websockets
payments          → cash + card + Stripe + reconciliation
closeout          → daily cash drawer + variance + approval
waste             → waste log + reasons + photo proof
manager_tasks     → checklist templates + assignments + proof
notifications     → in-app + email + websocket dispatch
reports           → sales / food cost / waste / labor / closeout
audit_logs        → who-did-what-when across the whole system
files             → file uploads (signed S3 URLs in prod)
```

## Service layer

We follow a service-layer pattern (HackSoftware-style):
- `models.py` — Django models, validators, helper methods.
- `selectors.py` — read-side queries. Pure DB reads. Reusable.
- `services.py` — write-side transactions. Atomic; raises domain exceptions.
- `serializers.py` — DRF serializers (input + output).
- `views.py` — DRF viewsets/APIViews. Thin: validate → delegate to service.
- `permissions.py` — DRF permission classes per resource.
- `tasks.py` — Celery tasks. Take primitive args (IDs, not objects).
- `signals.py` — Django signals. Only for cross-app side effects.
- `urls.py` — URL routes. One module per app.

## Money and units

- All currency stored as `DecimalField(max_digits=12, decimal_places=2)`.
- Quantities use `Decimal` with the unit explicitly stored on the row.
- Time clock entries store seconds as integers; computed labor cost is
  derived in selectors, not stored.

## Tenant scoping

Every resource that belongs to a restaurant carries a FK to `Restaurant`.
The middleware in `apps.audit_logs.middleware` resolves the active restaurant
from the URL pattern (`?restaurant=...` or path-based) and attaches it to
`request.active_restaurant_id`. Permission classes use this for tenant checks.

## Realtime

Django Channels with the Redis layer. We expose two websocket groups:
- `kitchen.{location_id}` — kitchen tickets + station status.
- `notifications.{user_id}` — per-user notification stream.

## Testing

- pytest + pytest-django + pytest-factoryboy.
- One factory per model in `tests/factories.py`.
- Tests live in each app's `tests/` directory and run as pytest specs.
- Fixtures in the project-level `conftest.py` (e.g. `authed_client`).
