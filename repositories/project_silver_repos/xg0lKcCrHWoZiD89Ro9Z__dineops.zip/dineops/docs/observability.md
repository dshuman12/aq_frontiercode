# Observability

How we look at production.

## Logging

We log to stdout in JSON format (configured in `config/settings/prod.py`).
Cloud logging (Datadog/CloudWatch) ingests the stream and we filter by:
- `request_id` — set by `RequestIdMiddleware`, echoed in `X-Request-Id`.
- `user_id` — added to log records via a custom filter.
- `restaurant_id` — extracted by `AuditContextMiddleware`.

Loggers used:
- `dineops.requests` — slow request warnings.
- `dineops.payments.stripe` — Stripe interaction logs.
- `dineops.notifications` — notification dispatch logs.
- `dineops.decorators` — service-layer entry/exit if `log_call` decorator is on.

## Metrics

Metrics are pushed to StatsD in production. Key metrics:
- `dineops.orders.created` — counter.
- `dineops.orders.voided` — counter (alarm if rate > 10/hour).
- `dineops.payments.captured` — counter, tagged by method.
- `dineops.payments.failed` — counter (alarm).
- `dineops.celery.{task}.{ok|err}` — counter per task.
- `dineops.kitchen.ws_clients` — gauge.
- `dineops.report.{name}.duration_ms` — histogram.

## Alerts

- `payments.failed > 5/min` for 10 min → page oncall.
- `inventory.scan_low_stock` task missed for > 20min → page.
- Daily closeout missing for any location for > 24h after business date → email manager.
- `cash_variance` > $100 on a closeout → email general_manager.

## Dashboards

We maintain three Grafana dashboards:
1. **Operations**: orders/min, kitchen latency, ws connection count.
2. **Finance**: gross sales, tip total, cash variance, refunds.
3. **System**: API latency p50/p95/p99, error rate, Celery queue depth.

## Tracing

We use OpenTelemetry with traces shipped to whatever the customer's tracing
backend is (Jaeger, Tempo, Honeycomb). Spans are added at:
- View entry (`@trace_view`).
- Service-layer functions (`@log_call` includes minimal trace metadata).
- DB queries (django-otel auto-instrumentation).

## On-call rotation

Weekly rotation; 24/7 coverage. Page tier:
- **P1**: payment processing failure, kitchen WebSocket down.
- **P2**: inventory drift > 5%, missed closeout.
- **P3**: notification dispatch lag, slow report queries.
