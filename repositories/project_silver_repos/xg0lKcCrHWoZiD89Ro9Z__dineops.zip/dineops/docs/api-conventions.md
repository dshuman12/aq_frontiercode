# API Conventions

## Authentication

All endpoints under `/api/` require `IsAuthenticated`. We use SimpleJWT —
clients send `Authorization: Bearer <token>`. Tokens expire in 1 hour;
refresh tokens last 7 days.

## URL shape

`/api/<module>/<restaurant_id>/<resource>...`

The restaurant ID is part of the URL for tenant scoping. Even for endpoints
that don't strictly need it (like `/api/auth/me/`), the convention
keeps multi-tenant data isolation explicit and audit-trail-friendly.

## HTTP methods

| Method | Semantics                                                |
|--------|----------------------------------------------------------|
| GET    | Retrieve. Idempotent.                                    |
| POST   | Create OR trigger an action (`/.../submit/`, etc.).      |
| PATCH  | Partial update. Use this, not PUT.                       |
| DELETE | Soft-delete or hard-delete depending on resource.        |

We use POST for state-transition actions (`/orders/{id}/submit/`) rather
than PATCH because they're not idempotent and don't always update the
resource directly.

## Error responses

```json
{
  "code": "domain_error_code",
  "message": "Human-readable message",
  "fields": { "field_name": ["error", ...] }
}
```

Status codes:
- `400` — `ValidationError` (bad input or business rule violation).
- `401` — unauthenticated.
- `403` — `PermissionDenied`.
- `404` — `NotFound`.
- `409` — `Conflict` (duplicate, state mismatch).
- `500` — unhandled.

## Pagination

We use a simple `?cursor=` style for endpoints that return a lot of data.
Most list endpoints currently cap at 200 results — when we hit a real
performance issue we'll add proper cursor pagination.

## Filtering

Query params on list endpoints:
- `?q=...` — text search (typically on `name`).
- `?status=...` — filter by status.
- `?location_id=...` — filter by location.
- `?start=YYYY-MM-DD&end=YYYY-MM-DD` — date range for reports.

## Format negotiation

Reports support `?format=csv` to return a CSV download instead of JSON.

## Versioning

The API is versioned by URL prefix when needed (`/api/v2/...`). For now
we're on v1, which is implicit (no version in the URL). Breaking changes
will introduce `/api/v2/` and we'll keep v1 around for at least 6 months.
