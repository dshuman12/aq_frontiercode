# Database

Postgres 15 with `uuid-ossp`, `pgcrypto`, `pg_trgm`, `btree_gin`.

## Naming conventions

- Snake-case table + column names (Django default).
- FKs end in `_id` (Django default).
- Money: `DecimalField(max_digits=12, decimal_places=2)`.
- Quantities: `DecimalField(max_digits=12, decimal_places=3)`.
- Soft delete via `archived_at` (nullable timestamp). We do not use
  `is_deleted` booleans.

## Tenancy

`Restaurant` is the tenant root. Most other tables FK to `Restaurant` for
fast WHERE filtering. We also denormalize `restaurant_id` onto child tables
where the parent already has it (e.g. `OrderItem` carries `restaurant_id`)
to avoid 3-table joins in hot reports.

## Indexes worth knowing about

- `Order(location_id, status, created_at)` — kitchen board hot path.
- `InventoryTransaction(ingredient_id, occurred_at desc)` — stock history.
- `TimeClockEntry(staff_id, clocked_in_at desc)` — labor reports.
- `WasteLog(location_id, occurred_at desc)` — waste report range queries.
- `Recipe(restaurant_id, slug)` unique — recipe lookup.

## Migrations

We don't squash migrations — easy to roll forward. Migrations are checked
into the repo. When schema changes are big, the commit message explains the
data shape changes, not just the schema diff.
