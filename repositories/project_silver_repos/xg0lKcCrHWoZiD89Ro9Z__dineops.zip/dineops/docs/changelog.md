# Changelog

## v1.0.0 — 2024-03 (Beta)

First end-to-end production release.

### Added
- Order taking (dine-in, takeout, delivery, bar, counter).
- Live kitchen screen via WebSocket.
- Inventory + recipes + costing with weighted-average cost.
- Vendor management + purchase orders with auto-reorder.
- Stripe payment integration.
- Daily closeout with cash variance.
- Manager checklists with photo evidence.
- Audit log of money/inventory/staff changes.
- Multi-channel notifications (email, sms, push, in-app, webhook).
- Reports: sales, top items, void/comp, labor, COGS, payment breakdown.
- Multi-tenant URL-scoped APIs.
- Role-based access control.

### Known limitations
- Multi-location pricing not yet supported (one price per item).
- POS device sync not yet built.
- Loyalty program not in scope for v1.
- Multi-currency UI exists but settlement currency is per-restaurant only.

## Unreleased

- Per-lot cost flow (currently weighted-average only).
- Negative-stock override flag for emergency prep.
- Drawer-level closeout for multi-drawer locations.
- 3-way invoice/PO/receipt match in payments.
- EDI 850/856 export for large vendors.
