# Audit Trail

DineOps records audit-grade entries for every state change that touches money,
inventory, or staffing. The `apps.audit_logs` module owns this.

## Recording

The recommended path is the service layer wiring (in `audit_logs/handlers.py`)
which subscribes to the appropriate signals:

- `OrderEvent` post_save → `order.voided`, `order.discount_applied`,
  `order.item_voided`, `order.item_comped`.
- `Refund` post_save → `payment.refund`.

For ad-hoc audit entries, services may call `record(...)` directly:

```python
from apps.audit_logs.services import record

record(
    action="staff.terminate",
    resource_type="StaffProfile",
    resource_id=str(profile.id),
    resource_label=profile.user.email,
    summary=f"Terminated {profile.user.email} ({reason})",
    actor=request.user,
    restaurant=profile.restaurant,
    severity="alert",
    request=request,
    metadata={"reason": reason},
)
```

## Severity ladder

| Severity   | When to use                                                          |
|------------|----------------------------------------------------------------------|
| `info`     | Routine create/update operations.                                    |
| `notice`   | Discounts, comp items — manager-level activity worth flagging.       |
| `warning`  | Permission denials, repeated failed logins.                          |
| `alert`    | Money-affecting reversals: voids, refunds, terminations.             |

## Querying

Owners and accountants can filter via `/api/audit-logs/{rid}/?action=...&actor_id=...`.
Filtering by `resource_type=Order&resource_id=<uuid>` returns the full audit
history for a single order.

## Retention

Audit entries are append-only and never deleted. The Django admin page is
read-only for AuditEntry to prevent tampering. Long-term we may compact rows
older than two years into compressed cold storage; for v1 we keep them all.

## Compliance Notes

For PCI scope reduction we deliberately do NOT log payment card numbers,
CVVs, or anything that could be PAN-derived. We DO log:
- `card_brand` and `card_last4` (already on Payment, allowed under PCI).
- `stripe_payment_intent_id` (a reference token, no card data).
- The amount and tip.

Refunds are flagged `severity=alert` so they stand out in dashboards and can
be reconciled against the Stripe ledger.
