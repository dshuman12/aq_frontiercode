# Troubleshooting

## "ChannelLayer not configured" on dev

You forgot to set `CHANNEL_LAYERS` to use Redis. Check
`config/settings/dev.py` → `CHANNEL_LAYERS["default"]["BACKEND"]` should
be `channels_redis.core.RedisChannelLayer` and `redis://localhost:6379/2`
should be reachable.

## Pytest fails with "no such table"

The first run creates the test database. If migrations are pending or were
recently added:

```bash
pytest --create-db
```

After that, `--reuse-db` is fine.

## Celery task says it ran but nothing changed

1. Make sure you have BOTH the worker AND the beat scheduler running.
   The worker alone executes tasks on demand; beat is what schedules them.
2. Check the queue isn't backlogged: `celery -A config inspect active`.
3. Check the task name in `CELERY_BEAT_SCHEDULE` matches the
   `@shared_task(name=...)` argument exactly.

## "ConnectionRefused" on Stripe in tests

That's correct — tests use the `_FakeStripe` adapter. If you see Stripe
errors in tests, make sure `STRIPE_API_KEY` is empty in your test settings
(`config/settings/test.py`).

## Frontend can't talk to backend

CORS check: `corsheaders` should be in `MIDDLEWARE` and
`CORS_ALLOWED_ORIGINS` should include your dev URL (`http://localhost:5173`).

## Migration conflict

Two devs added a migration on the same parent. Resolve with:

```bash
python manage.py makemigrations --merge
```

Don't squash across the merge boundary.

## Slow inventory page

The inventory list page can balloon if a location has thousands of
items. Add pagination on the client (we cap at 1000 today) or filter by
category/storage location.

## Stripe webhook signature mismatch

Likely causes:
- The wrong webhook secret in env (`STRIPE_WEBHOOK_SECRET`).
- Body parsing — make sure the webhook handler reads `request.body` raw,
  not the JSON-parsed view.

## Admin page shows "PermissionDenied" everywhere

The admin uses Django's auth, not our RestaurantMember-based RBAC. Make
sure `is_staff=True` for the admin user.
