# Payments & Daily Closeout

## Payments overview

A `Payment` row records money received against an `Order`. We support multiple
payment methods on a single check (split-tender), multiple checks per table
(future), and full + partial refunds.

Lifecycle:

```
pending → captured → (refunded | partially_refunded)
       \→ failed
```

| Method        | Status path                          |
|---------------|--------------------------------------|
| `cash`        | created `captured` immediately       |
| `card`        | created `captured` immediately       |
| `stripe`      | `pending` → `captured` after intent  |
| `gift_card`   | `captured`                           |
| `house_account`| `captured`                          |
| `comp`        | `captured` (zero amount)             |

When a payment is captured, we recompute the order's `amount_paid` and
`balance_due`. If `balance_due ≤ 0` we mark the order `paid`.

### Stripe flow

1. Frontend POSTs `{order_id, amount, tip}` to `/payments/stripe/begin/`.
2. Backend creates a `pending` Payment row and a Stripe PaymentIntent.
3. Frontend confirms with the Stripe SDK using `client_secret`.
4. Frontend POSTs `{payment_id}` to `/payments/stripe/confirm/`.
5. Backend pulls the latest intent state and either captures or fails.

We isolate the Stripe API behind `apps.payments.stripe_client`, with a
`_FakeStripe` adapter for dev/tests. Setting `DINEOPS_STRIPE_FAKE=1` (or
leaving `STRIPE_API_KEY` empty) routes calls to the fake.

### Tip distribution

The cashier's UI lets the user split tips on a payment by role/staff. We
record this as `TipDistribution` rows. The distribution sum cannot exceed
the payment's `tip_amount`.

## Daily Closeout

A closeout is the end-of-day Z-out for a single location on a single date.
It captures:

- Order counts (total, voided)
- Gross sales, discount total, void total, comp total → net sales
- Tax, service charge, tip totals
- Refund total
- Tender breakdown (cash, card, stripe, other)
- Cash drawer reconciliation: expected vs counted, with variance

Workflow:

```
draft  ──recompute──▶ draft  (idempotent — recompute as often as needed)
       ──set cash──▶ draft
       ──submit──▶ submitted
                     ──approve──▶ approved (immutable)
```

`recompute_closeout` walks the orders and payments for the day in the
location's timezone window and rebuilds every aggregate. This is fast and
idempotent — it's safe to call as many times as needed before submission.

Cash variance is the moment of truth. A consistent positive variance means
overcharging customers; a consistent negative variance is shrinkage.

### Why one closeout per location per date?

A single restaurant location → single physical cash drawer → single Z-out.
Multi-drawer setups would require a `Drawer` model with closeouts per drawer;
that's deferred until we have a customer that needs it.

### Approval

`approve_closeout` is gated to `owner` and `general_manager`. Once approved,
the closeout row is read-only — auditable forever, eligible for inclusion in
M12 reports and external GL exports.
