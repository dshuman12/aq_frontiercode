# Inventory

The `apps.inventory` module is the operational ledger of stock, lots, counts,
and low-stock alerts.

## Core Concepts

### InventoryItem

A row per `(Location, Ingredient)` pair. Holds:

- `quantity_on_hand` — current stock in the ingredient's `base_unit`.
- `average_cost` — weighted-average unit cost (see below).
- `par_level`, `reorder_point`, `reorder_quantity` — replenishment thresholds.

We deliberately keep `quantity_on_hand` and `average_cost` materialized on
the InventoryItem rather than computing from transactions on every read. The
authoritative event log is the `InventoryTransaction` table; the materialized
value lets the kitchen UI render a 200-row pantry list without N+1 cost
queries. Drift between the two is visible in count sessions (and is what the
"variance" row exposes).

### InventoryTransaction

Append-only log of every stock movement. Kinds:

- `opening` — initial balance when the item is created.
- `receive` — incoming purchase from a vendor.
- `usage` — consumption (recipe production, prep).
- `waste` — loss (spoilage, mistake, theft).
- `transfer_in` / `transfer_out` — between locations.
- `count_adjustment` — reconciliation after a physical count.

Quantities are signed in the ingredient's `base_unit`: positive = inflow.

### LotTrackingRecord

For ingredients that need traceability (meat, dairy, seafood). Each `receive`
with a `lot_code` creates a lot. Consumption uses **FEFO** — first-expiring,
first-out — to drain lots; recalled lots are skipped.

This gives us:
- A traceability trail for FDA recall scenarios.
- An accurate picture of which products are about to expire.
- A defensible answer to "how much of this lot did we use?"

### LowStockAlert

Created the moment an item crosses `reorder_point` on the way down. While the
alert is open (`resolved_at IS NULL`), no further alerts fire for the same
item. `inventory.notify_low_stock` runs every 15 minutes to send the alert.

When stock comes back above reorder_point (via `receive_stock`), the open
alert is auto-resolved.

## Weighted-Average Cost

We use weighted-average — not FIFO/LIFO — for cost-of-goods accounting:

```
new_avg = (current_qty × current_avg + received_qty × received_cost)
        / (current_qty + received_qty)
```

Why average:

- Restaurants buy ingredients constantly; price oscillates day-to-day.
- The kitchen doesn't want to think about "which $4/lb chicken did I just use?"
- It's the most defensible to small business accountants.

The downside is we don't track tax-optimal cost flow. That's a deliberate
trade — DineOps is operations software, not accounting software.

## Counts

Manager workflow:

1. **Start** a count (`POST /api/inventory/.../counts/`).
   This snapshots `expected_quantity` from current `quantity_on_hand` for
   every active item in the location, freezing a baseline.
2. Staff walk the cooler/dry storage and **submit** counted quantities per
   line. The line records `variance` = counted − expected and
   `variance_value` = variance × average_cost.
3. **Complete** the count. We write a `count_adjustment` transaction for any
   non-zero delta and update each item's `quantity_on_hand`.

Counts are the authoritative reconciliation point. Variance over 5% on a
single item is the operational signal that something's wrong (overpouring,
shrinkage, miscounted prep).

### Concurrency

Only one open count per location at a time. Trying to start a second raises
`Conflict("count_already_in_progress")`. This stops the "two managers each
started a count" footgun.

## Beat Schedule

| Task                              | Schedule       | Purpose                                |
|-----------------------------------|----------------|----------------------------------------|
| `inventory.scan_low_stock`        | every 5 min    | Open alerts for items below reorder    |
| `inventory.notify_low_stock`      | every 15 min   | Send mail/notification for new alerts  |
| `inventory.scan_expiring_lots`    | nightly        | Flag lots within 3 days of expiry       |

## Permissions

Inventory write operations are gated to: `owner`, `general_manager`,
`assistant_manager`, `chef`, `inventory_manager`. The plain `server` role
does NOT have inventory write — they go through the order layer (M8) which
deducts stock indirectly via recipe usage.

## Future Work

- **Negative-stock guards**: today `consume_stock` rejects below-zero.
  Some prep workflows want a "consume even if it goes negative, audit later"
  mode. We'll add a `force=True` kwarg behind a permission.
- **Per-lot cost basis**: weighted-average is good enough for most cases,
  but accountants increasingly want lot-specific cost. The `LotTrackingRecord`
  already carries `unit_cost`; we can switch to lot-cost flow without a
  schema change.
- **Stock allocation**: when an order is created we should "reserve" stock
  rather than only consume on completion. Will be revisited in M8.
