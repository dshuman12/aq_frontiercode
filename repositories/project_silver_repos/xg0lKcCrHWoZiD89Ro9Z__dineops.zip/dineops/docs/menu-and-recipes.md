# Menu and Recipe Engineering

This document describes the data model and operating concepts behind the Menu
and Recipe modules, and how they connect to the rest of the system.

## Two Worlds

DineOps draws a line between **what the customer sees** (the menu) and **how the
kitchen makes it** (the recipe).

- A **MenuItem** is a saleable thing — it has a price, an availability flag, and
  variants/modifiers the front-of-house can offer guests.
- A **Recipe** is the cost-carrying production unit — it has ingredient lines,
  yield, instructions, and version history.

A MenuItem may be linked to a Recipe (`Recipe.menu_item`), but a recipe is not
required for a MenuItem to be sold (think: a bottle of beer doesn't need a
recipe). And a recipe doesn't need a MenuItem (think: a sub-recipe like
"caramelized onions" used inside other recipes).

## Menu Topology

A `Restaurant` has many `Menu`s. A `Menu` has many `MenuCategory`s. A
`MenuCategory` has many `MenuItem`s.

`MenuItem`s also belong directly to the restaurant — so an item can be moved
between menus by changing its `category` FK.

A `MenuItem` may have:
- 0..N `MenuItemVariant`s (size/option dimensions where exactly one is picked).
- 0..N attached `ModifierGroup`s (separate questions where each can be
  required, optional, single-select, or multi-select).

### Variants vs. Modifier Groups

| Concept       | Used for                                          | Selection model     |
|---------------|---------------------------------------------------|---------------------|
| Variant       | Mutually exclusive sizes/options of the same item | Pick exactly 1      |
| Modifier      | Add-ons, customizations, side choices             | Configurable rules  |

A pizza's "Small / Medium / Large" should be variants. "Toppings" should be a
modifier group with `max_select=N`.

## Pricing

`calculate_item_price(item, variant=None, modifier_options=[])` is the source of
truth for line-item pricing in orders:

```
final_price = item.base_price
            + variant.price_delta (if variant)
            + sum(option.price_delta for selected modifier options)
clamp at 0
```

Tax and service charge are applied at the *order* level (not at the menu/item
level), using the menu override if set, otherwise the restaurant default.

## Recipe Costing

`calculate_recipe_cost(recipe)` walks each ingredient line, converts the
recipe-line quantity into the ingredient's `base_unit`, and multiplies by
`ingredient.effective_cost_per_unit` (which already factors in yield loss).

Total cost is then divided by `recipe.yield_quantity` to produce
`cost_per_yield_unit`, which we compare to the menu item's selling price to
produce a **food cost percent**:

```
food_cost_pct = cost_per_yield_unit / selling_price * 100
```

A typical target is 28-32%. The cached values on `Recipe` are refreshed every
time a line changes (via `cache_recipe_cost`) and also nightly in a Celery
beat task once we add inventory price updates in M5.

### Why effective_cost_per_unit?

If you buy a whole brisket at $8/lb but only 80% of it is usable after
trimming, your *true* cost-to-plate is $8 / 0.80 = $10/lb. We bake that math
into `Ingredient.effective_cost_per_unit` so recipe costing always sees the
real cost, not the invoice cost.

## Recipe Versioning

Every time a recipe is updated through the PATCH endpoint we snapshot the
recipe (and its lines) into a `RecipeVersion` row before applying the change.
This gives us:
- An auditable history of recipe changes (chef X bumped chicken from 200g to
  225g on this date).
- A way to roll back if costs spike unexpectedly.
- A baseline to compare against when answering "why did food cost go up?"

Snapshots are stored as JSON, not as related rows, because the ingredients
referenced may themselves be archived/deleted later. The JSON freezes the
human-readable name and quantity.

## Time-based Availability

A menu without an `availability_rules` row is always available. Once any rule
exists for that menu (or item), only the windows defined by the rules are
considered "in-service". This lets us:
- Hide the brunch menu Tuesday morning.
- Restrict the kids' menu to before 8pm.
- Run a happy-hour beer list 4-6pm M-F.

`is_menu_available_at(menu, weekday, time)` and `is_item_available_at` are the
two functions order/POS layers should call before letting staff add an item to
a check.

## Modifier Selection Validation

Before an order is sent to the kitchen we call:

```python
validate_modifier_selection(item=item, selections={
    str(group_id): [str(option_id), ...]
})
```

This raises a `ValidationError` if:
- A required group has fewer selections than its `min_select`.
- Any group has more than `max_select`.
- A selected option does not belong to the group it was claimed against.

The order layer (M8) wraps this so a rejection becomes a 400 with the field
breadcrumb pointing to the offending group.

## Open Questions / Future Work

- **Multi-location pricing**: today an item has a single `base_price`. Some
  restaurants want different prices at different locations. We'll likely
  introduce a `MenuItemPricing` table keyed on (item, location) when the need
  arises. Don't bake the assumption "one price per item" too deep.
- **Translations**: `name` and `description` will need a translation table.
  Out of scope for v1.
- **POS sync**: the modifier model should map cleanly onto Square / Toast
  modifier sets when we add POS export in a later milestone.
