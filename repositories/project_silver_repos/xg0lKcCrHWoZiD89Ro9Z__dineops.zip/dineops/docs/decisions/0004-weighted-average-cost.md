# ADR 0004 — Weighted-Average Cost (vs FIFO/LIFO)

## Context

When the same ingredient is purchased multiple times at different prices, we
need a consistent way to value a unit drawn down for usage, waste, or transfer.

Options:
- **FIFO** (first-in, first-out): consume at the cost of the oldest lot.
- **LIFO** (last-in, first-out): consume at the cost of the newest lot.
- **Specific identification**: consume at the cost of the actually-used lot.
- **Weighted average**: consume at a rolling weighted average across all
  inflows.

## Constraints

- Restaurants buy fresh ingredients daily; prices fluctuate constantly.
- Kitchen workflow is "grab whatever's at the front" — it's NOT lot-precise.
- The customer-visible plate cost is what matters operationally; tax
  optimization is a small-business accountant's job, not ours.
- We still want lot tracking for **traceability** (recalls, expiry) — not
  for cost flow.

## Decision

Use **weighted average** for cost-of-goods accounting. Store the rolling
average on `InventoryItem.average_cost`. Update it on every `receive_stock`:

```
new_avg = (qty × avg + received × received_cost) / (qty + received)
```

We separately keep `LotTrackingRecord` rows for traceability — but lots do
NOT drive cost flow. A `usage` transaction is recorded at the item's current
average cost, regardless of which lot was drawn down.

## Consequences

- **Simple**. One number per item; no per-lot cost ledger to maintain.
- **Smooth**. Ingredient cost trends are visible in food-cost-percent without
  the "this dish suddenly costs 18% more because we got a new shipment"
  flicker.
- **FDA-compliant for traceability**: lot tracking is decoupled from cost
  tracking. If lot ABC is recalled, we can find every InventoryItem holding
  remaining stock from it (`LotTrackingRecord.lot_code = ABC, is_recalled =
  False, quantity_remaining > 0` → set `is_recalled = True`).
- **NOT GAAP-precise** for tax purposes. If a restaurant needs FIFO for tax
  filings, they'll need to export the transaction log and have their
  accountant compute the alternative cost basis externally. Acceptable.

## Alternatives Considered

### Specific identification (per-lot cost)

We can layer this on later without a schema change — `LotTrackingRecord`
already has `unit_cost`. The runtime change would be: when a `usage` event
draws down lot X, the transaction's `unit_cost` becomes lot X's `unit_cost`.

We chose not to do this in v1 because:
- Most restaurants don't need it.
- It complicates the simple "what does this dish cost?" question — there's
  now a dependency on which lot was used.
- It can be added later without a migration.

### FIFO

FIFO is more common in retail accounting and gives a more defensible "cost
of goods sold" number for tax. But:
- It's expensive to compute on every read (need to walk the lot history).
- It forces a strict ordering on lots (which lot was first?), but multiple
  lots can be received the same day in unknown order.
- It's the wrong abstraction for kitchen flow — chefs aren't FIFO.

## Status

Accepted, August 2023.
