# ADR 0019 — No GraphQL

## Context

Several team members wanted to evaluate GraphQL as a replacement for the
REST API.

## Decision

We stay on REST.

## Why

- The frontend is one team consuming the API; GraphQL's "many clients,
  many shapes" advantage doesn't apply.
- Caching: HTTP caching of REST endpoints is mature; GraphQL caching
  requires Apollo or relay-style normalized stores.
- Tooling: drf-spectacular gives us OpenAPI for free.
- Authorization: REST URL-based scoping (`/api/<module>/<rid>/...`) maps
  directly to our permission checks. GraphQL would push us toward
  field-level resolvers.
- Performance: we don't have over-fetching pain points that motivate the
  GraphQL switch.

We may revisit if we add a public/partner API, where GraphQL's
introspection helps developers explore.

## Status

Accepted, June 2023.
