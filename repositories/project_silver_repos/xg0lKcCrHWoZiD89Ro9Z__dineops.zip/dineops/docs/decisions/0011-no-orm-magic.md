# ADR 0011 — No ORM Magic

## Context

Django has powerful conveniences: managers with custom querysets,
`save()` overrides that mutate other rows, `pre_save` signals that
synthesize fields, etc. These can quickly turn the data layer into a
tangle of side effects that are hard to test or reason about.

## Decision

DineOps deliberately keeps the ORM layer minimal:

1. **No custom managers** for filtering. Service-layer functions wrap
   the queries.
2. **No custom querysets**. Selectors live in `selectors.py` per app.
3. **No pre_save signals** that mutate the model in surprising ways.
   The `save()` override on `Recipe.save()` (auto-slug) is a deliberate
   exception, scoped to a single field.
4. **post_save signals** are fine for **fan-out side effects** —
   broadcasting, audit logging, queueing notifications — but they should
   never modify the same row they're reacting to.
5. **No automatic timestamps beyond auto_now / auto_now_add**: any
   business-meaningful timestamp (`paid_at`, `served_at`, etc.) is set
   explicitly in the service layer.

## Why

- Tests can stub a service function; they can't easily stub a manager
  override.
- Audit logs capture explicit actions, not implicit DB-level mutations.
- Junior developers can read the service file end-to-end and understand
  what happens, without grepping for `pre_save` handlers.

## Status

Accepted, May 2023.
