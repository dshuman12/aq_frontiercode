# ADR 0015 — Final Decisions Reaffirmed at v1

This ADR captures a few small final decisions made at v1 release time.

## Open issues kept open

The following are intentionally NOT in v1, with `docs/changelog.md`
unreleased section as the canonical list:
- Per-lot cost flow.
- EDI 850/856 export.
- Multi-location pricing.
- POS device sync.

## Bug-bash freezes

We hold a 5-day bug-bash freeze before each minor release (1.x.0). During
the freeze:
- No new features merged.
- Tests for previously fixed bugs added if missing.
- Performance tracing on the slow endpoints (orders board, inventory
  list) reviewed.

## v1 sign-off

The v1 release was sign-off by:
- Engineering: tests green, no P1 alarms during 7-day staging soak.
- Product: walkthrough of all 6 critical user flows.
- Customer success: pilot restaurant ran a real day on the system.

## Status

Accepted, March 2024. (Final v1 ADR.)
