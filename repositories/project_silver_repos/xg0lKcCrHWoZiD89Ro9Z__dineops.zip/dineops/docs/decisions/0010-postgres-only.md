# ADR 0010 — PostgreSQL Only

## Context

DineOps could in theory run on any of the major SQL databases. But choosing
one fixes our migration story, our query power, and our extension story.

## Decision

We commit to **PostgreSQL 15+** as the only supported database backend.

## Why

1. **JSONField + JSONB**: We use `JSONField` heavily on `OrderEvent`,
   `RecipeVersion.snapshot`, `AuditEntry.payload`, `Restaurant.branding`.
   JSONB indexing in Postgres is much better than MySQL's JSON.
2. **Window functions + advanced aggregates**: Reports use window
   functions for things like running totals.
3. **Postgres extensions** we rely on:
   - `uuid-ossp` for `uuid_generate_v4()` (legacy callsites).
   - `pg_trgm` for trigram-similarity search on item names.
   - `btree_gin` for compound JSONB + scalar indexes.
4. **Strict typing**: `DecimalField` round-trips losslessly. MySQL's
   `DECIMAL` rounding behavior differs in edge cases.
5. **Concurrency**: Postgres MVCC handles our high-write order volume
   without read-blocking-write artifacts.

## Consequences

- We don't test against SQLite, even for development. Use Docker.
- Migrations may use Postgres-specific operations (`CREATE EXTENSION`,
  `ALTER TYPE` enum modification).
- Customers running on-prem must run Postgres 15+.

## Status

Accepted, May 2023.
