# ADR 0012 — Frontend State Strategy

## Context

The staff app has many screens reading server-side data, and a handful of
mutations. We considered:
- Redux + redux-saga
- Zustand + custom data fetcher
- TanStack Query (formerly react-query) for server state + Zustand for UI state

## Decision

We use **TanStack Query** for server state and **Zustand** for UI state
(modal open/closed, current restaurant_id pointer, etc.). No Redux.

## Why TanStack Query

- Built-in caching, deduplication, refetch-on-focus.
- The `useQuery({ queryKey, queryFn })` pattern is small and obvious.
- Mutations come with optimistic updates and `invalidateQueries` —
  perfect for our "refresh after action" flows.

## Why Zustand for UI state

- Tiny, no boilerplate.
- Easy to read in a single file.
- Avoids the React Context re-render pitfall.

## What we explicitly do NOT do

- No global Redux store.
- No redux-saga / redux-thunk.
- No "manager pattern" with classes — Zustand stores are plain JS objects.

## Tradeoffs

- TanStack Query is opinionated; debugging stale-data issues sometimes
  requires understanding how its query keys interact.
- Zustand has no time-travel debugger like Redux DevTools. We've found
  this an acceptable trade for the simplicity.

## Status

Accepted, August 2023.
