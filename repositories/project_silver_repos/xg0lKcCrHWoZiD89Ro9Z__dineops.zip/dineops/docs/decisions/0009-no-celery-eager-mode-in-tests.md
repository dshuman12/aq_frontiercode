# ADR 0009 — No CELERY_TASK_ALWAYS_EAGER in Tests

## Context

Many Django projects set `CELERY_TASK_ALWAYS_EAGER=True` in the test
settings so that any code path that calls `task.delay()` or
`task.apply_async()` runs synchronously. This makes tests easy to write
but masks several classes of bugs:
- Tests that "pass" because they accidentally exercise the task's body
  inline, when in production the task would race the request.
- Tests that don't notice when a task is enqueued multiple times because
  there's no queue boundary.

## Decision

We do **not** set `CELERY_TASK_ALWAYS_EAGER` in the test settings.

Instead:
- Service-layer functions are tested directly. We assert side effects on
  the database, not "the task ran".
- Celery tasks are tested by importing the function and calling it
  directly (no `.delay()`).
- For tests that NEED a task to fire from a service call, we either:
  (a) call the task function inline as part of the service, or
  (b) mock `task.delay` and assert it was scheduled.

## Consequences

- Tests run faster (no Celery setup overhead).
- Tests catch task-ordering bugs.
- Slightly more boilerplate in a few places where we previously relied on
  eager mode.

## Status

Accepted, July 2023.
