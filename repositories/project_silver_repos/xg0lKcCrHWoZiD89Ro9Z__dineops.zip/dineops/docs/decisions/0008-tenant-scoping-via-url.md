# ADR 0008 — Tenant Scoping via URL

## Context

DineOps is multi-tenant: many restaurants on a shared database. We need
strong isolation, both as a data security boundary and so that requests
can be audited cleanly.

## Options

1. **Implicit scoping via session**: `request.session["restaurant_id"]`
   determines tenant.
2. **Header-based scoping**: `X-Restaurant-Id` header.
3. **URL-based scoping**: `/api/<module>/<restaurant_id>/...` (chosen).

## Decision

URL-based. Every multi-tenant endpoint takes a `restaurant_id` UUID as a
path parameter, even when redundant for a single-restaurant user.

## Pros

- The audit trail captures the scope literally in the request path —
  no magic state to inspect.
- Logs and access traces show which tenant the request was for.
- Browser bookmarks and copy-pasted URLs carry the scope.
- Federated multi-restaurant users (a regional manager with three
  locations) can naturally have different tabs open for each restaurant.

## Cons

- Slightly more verbose URLs.
- View functions all take `restaurant_id` as a parameter.

## Implementation

The `_require_member(user, restaurant_id)` helper in every viewset
verifies the request user is an active member of the restaurant. If not,
we raise `PermissionDenied("not_a_member")`.

For non-tenant-scoped endpoints (`/api/auth/login/`, `/api/auth/me/`,
`/api/notifications/inbox/`) we use the user's identity directly.

## Future work

- We may add a `current_restaurant_id` cookie/header for the staff app to
  drive default routing on the dashboard. The cookie would be a
  convenience pointer; the URL parameter remains the source of truth for
  authorization.

## Status

Accepted, May 2023.
