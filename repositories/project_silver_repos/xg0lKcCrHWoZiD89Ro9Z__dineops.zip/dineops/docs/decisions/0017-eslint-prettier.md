# ADR 0017 — ESLint + Prettier on the Frontend

## Context

The staff app and kitchen screen are React/Vite. We need formatting +
linting consistency.

## Decision

- **Prettier** for formatting (semi: true, singleQuote: false,
  tabWidth: 2). Run on save in editor.
- **ESLint** with `eslint-config-react-app` extended by our internal
  rules.
- **Husky pre-commit hook**: runs `prettier --check` and `eslint --fix`
  on staged files only (via `lint-staged`).

## Rules we add on top of defaults

- `no-console` warnings (allow only `console.error` and `console.warn`).
- `react-hooks/exhaustive-deps` enforced as error.
- Import sorting via `simple-import-sort` (so PR diffs are clean).

## Status

Accepted, August 2023.
