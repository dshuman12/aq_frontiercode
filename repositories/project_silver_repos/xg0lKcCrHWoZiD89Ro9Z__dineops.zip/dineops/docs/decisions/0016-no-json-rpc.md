# ADR 0016 — REST, Not JSON-RPC

## Context

Some teams build their internal APIs as JSON-RPC. We considered it for the
order/kitchen flow because the actions feel verb-y (`fire_order`,
`mark_ready`, `void_item`).

## Decision

We use REST (with action endpoints where appropriate) over JSON-RPC.

## Why

1. **Tooling**: drf-spectacular generates OpenAPI; Swagger / Redoc UIs
   come for free.
2. **Caching**: HTTP semantics around `GET` and idempotency are useful.
3. **Familiarity**: more contributors know REST than JSON-RPC.
4. **Browser network tab is grep-able**: `/api/orders/.../void/` is more
   informative than `{"method": "void", "params": {...}}`.

## How we do "verbs" in REST

- **POST `/api/orders/{id}/submit/`** → state transition.
- **POST `/api/orders/{id}/items/{item_id}/void/`** → action on a child.

We don't pretend these are CRUD operations. The trailing `submit`,
`void`, `serve`, `comp` are verbs. POST is the right method because they
are not idempotent.

## Status

Accepted, October 2023.
