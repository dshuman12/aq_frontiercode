# ADR 0006 — UUID Primary Keys

## Context

DineOps powers multiple restaurants on a shared database. Customers can:
- Export their own data.
- Embed their own IDs in URLs and webhooks.
- Trade data with partners (POS, accounting integrations).

Sequential integer PKs leak the platform's growth rate ("how many orders
has DineOps processed today?") and make ID guessing trivial in URL-based
endpoints.

## Decision

All primary keys are `UUIDField(primary_key=True, default=uuid.uuid4,
editable=False)` on the model itself. Foreign keys reference UUID columns;
serializers expose UUIDs as strings.

## Consequences

- **Pros**: opaque, non-guessable, no global counter to worry about,
  generated client-side or server-side, safe to embed in URLs.
- **Cons**: 16 bytes per PK instead of 8; index size larger; not
  monotonically sortable. We mitigate the index issue by using
  `uuid4()` (random) instead of `uuid1()` (timestamp-prefixed); reads
  benefit from Postgres's UUID indexing.
- **Indexing**: when we need time-ordered queries we add an explicit
  `db_index=True` on `created_at`. We use these for activity feeds,
  audit trails, and order boards.
- **External references**: the few business-meaningful identifiers
  (PO numbers, order numbers, employee codes) are kept as additional
  human-readable string fields on top of the UUID PK.

## Migrations

We started this convention in M1; every model since has used UUID PKs.
There is no legacy integer-keyed table.

## Status

Accepted, May 2023.
