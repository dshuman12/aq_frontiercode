# ADR 0007 — Event-Driven Side Effects

## Context

A single business event (an order is voided, an item is comped, a payment
is refunded) can trigger many secondary effects:
- An audit log entry.
- A notification to managers.
- A WebSocket broadcast to the kitchen.
- An update to a daily closeout aggregate.

If we cram all of these into the service that handles the primary action,
the service becomes hard to test and hard to extend.

## Decision

We separate **primary** logic from **side effects** using:
1. The **service layer** does the primary state change and any inline
   invariants.
2. **Django signals** (`post_save` on the changed model OR a custom event
   model) fan out the side effects.
3. Side-effect handlers live in their own module per-app (e.g.
   `audit_logs/handlers.py`, `orders/signals.py`).

For audit specifically, we also keep an **OrderEvent** row that stores the
intent + payload — both for inspection and to give signal handlers a single
typed record to react to.

## Consequences

- Primary services stay small and testable.
- Adding a new side effect means adding one signal handler — no
  modifications to the original service.
- Tests for primary services don't fire WebSockets or send emails because
  channel layer / network calls are isolated.

### Risks

- **Signal explosion**: too many implicit handlers can make data flow hard
  to follow. Mitigation: every handler module is one file per app, named
  clearly (`signals.py` or `handlers.py`).
- **Order of execution**: Django signal order is by registration; we don't
  rely on a specific order. Idempotency is important.
- **Failures in handlers must not break the primary action.** We try to
  catch exceptions in non-critical handlers (e.g. WebSocket fan-out).
  Critical recordings (audit) are inside the same DB transaction as the
  primary write so they roll back together.

## Status

Accepted, October 2023.
