# ADR 0014 — Email Templates as Python Strings

## Context

We need to send a few transactional emails: low-stock alerts, shift
reminders, password resets. We considered:
- Django templates with `EmailMultiAlternatives`.
- A heavy email library like Mailchimp Transactional.
- A simple `string.Template` per message kind.

## Decision

We use **`string.Template`** in `apps.common.email_renderer` for all
transactional emails. Templates are tiny — typically 5-10 lines.

## Why

- The handful of emails we send are simple and short.
- Django template inheritance is overkill for "a single greeting + body
  paragraph + signoff".
- `safe_substitute` doesn't crash on missing variables — useful when an
  upstream caller forgets a kwarg.
- Easy to test: render and assert substring inclusion.

## When to graduate

If we ever need:
- Branded HTML templates (custom styling per restaurant).
- Multiple languages.
- A/B testing of email copy.

…we'll switch to `EmailMultiAlternatives` + Django templates.

## Status

Accepted, December 2023.
