# ADR 0005 — Soft Delete via `archived_at`

## Context

Several entities in DineOps are conceptually permanent (Recipe, Location,
Vendor, Ingredient) but get retired regularly: a recipe is renamed, a
vendor is dropped, an ingredient is replaced by a substitute. We can't
hard-delete because:
- Historical orders/PO/audit entries reference these rows.
- Cost reports and recipe versions need to keep working.

## Options

1. **Hard delete** with `on_delete=PROTECT` everywhere → impossible to
   actually delete a vendor that has any history.
2. **Soft delete via `is_deleted` boolean** — the classic approach.
3. **Soft delete via `archived_at` timestamp** (chosen).
4. **Tombstone tables** — move deleted rows to a parallel "archive"
   table. Heavyweight; we've avoided this.

## Decision

We use **`archived_at: DateTimeField(null=True, blank=True)`** on the
`SoftDeleteModel` abstract base.

- A row is "archived" when `archived_at IS NOT NULL`.
- All list endpoints filter `archived_at__isnull=True` by default.
- A `.archive()` helper sets the timestamp via `update_fields` to avoid
  bumping `updated_at` unnecessarily.

## Why timestamp not boolean?

- We get "when was this archived" for free.
- Easier to write reports: "things archived in the last 30 days".
- Easier to write a future "restore + auto-cleanup" feature: archive
  everything older than X, expire after Y.
- Slightly more space, but null-storage in Postgres is cheap.

## Consequences

- New models that need soft-delete inherit `SoftDeleteModel`.
- Service layer is responsible for not creating new references to archived
  rows. We deliberately do NOT block this at the DB level — sometimes
  you want to keep using an archived ingredient while transitioning.
- Reports that span archived data filter explicitly. No ORM magic for
  archived rows.

## Status

Accepted, June 2023. Applied across Recipe, Location, Restaurant,
RestaurantMember, Ingredient, MenuItem, Menu, Vendor, StaffProfile.
