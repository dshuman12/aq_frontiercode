# ADR 0003 — Recipe Versioning Strategy

## Context

Recipes change. A chef trims grams off a portion to hit a food-cost target; an
ingredient gets reformulated; a unit of measure changes from "tsp" to "g".

We want the operations team to be able to look back and answer:
- "When did the cost on this dish go up?"
- "Who changed the curry recipe?"
- "Show me the recipe as it was on the day we ran our quarterly P&L."

## Options Considered

### A. Field-level audit log (django-simple-history)

Pros: Granular, well-trodden library, easy to query "who changed what field".
Cons: Big audit table, expensive to read for a "show the whole recipe as it
was" query, doesn't capture related rows (ingredient lines) cleanly.

### B. Append-only immutable Recipe rows

Pros: Each save creates a new Recipe; perfect history.
Cons: Every FK to Recipe (menu_item, etc.) becomes "which version of the
recipe?" — leads to a complex temporal join everywhere.

### C. Snapshot table (RecipeVersion) — chosen

Pros:
- Separates history from operational queries; recipe stays singular.
- Snapshots are JSON — can capture lines, instructions, prices in one place
  without related-row joins.
- Cheap to write, cheap to read for "show me v17".
- Stable in the face of ingredient deletions.

Cons:
- Field-level "who changed grams from 200 to 225" requires diffing JSON
  blobs. Acceptable for now; rarely needed in practice.
- Slightly harder to query "all recipes that ever used cilantro" — but that's
  a niche analytics query, not an operations query.

## Decision

We use **Option C** — `RecipeVersion(recipe, version, snapshot, saved_by)` —
written before each PATCH. The current Recipe row stores the live state.

`Recipe.version` is a monotonic counter; `RecipeVersion.version` matches the
recipe's version *at the moment of snapshot* (i.e. the version BEFORE the
upcoming edit). After a snapshot, we increment Recipe.version.

### What gets snapshotted

```json
{
  "name": "Bolognese",
  "yield_quantity": "4",
  "yield_unit": "each",
  "portion_size": "1",
  "portion_unit": "each",
  "selling_price": "18.00",
  "instructions": "...",
  "lines": [
    {"ingredient_id": "...", "ingredient_name": "Beef",
     "quantity": "500", "unit": "g", "notes": "ground"}
  ]
}
```

We deliberately store `ingredient_name` next to `ingredient_id` — if an
ingredient gets renamed or deleted, the historical version still shows the
human-readable name as it was.

### What does NOT get snapshotted

- Cached cost fields (those are derivative — recompute from line × cost).
- Image URLs (assumed stable; we use a CDN that doesn't expire).
- Created/updated timestamps of the lines.

## Consequences

- Adding fields to `Recipe` requires a deliberate decision: should the new
  field be in the snapshot? Default yes, unless it's purely derivative.
- We can roll back a recipe by reading a snapshot and re-applying it as a new
  version. (Not implemented in M4 — flagged for later.)
- For diff-style "what changed", we'll write a helper that compares the
  current recipe to its prior version. Out of scope here.

## Status

Accepted, July 2023.
