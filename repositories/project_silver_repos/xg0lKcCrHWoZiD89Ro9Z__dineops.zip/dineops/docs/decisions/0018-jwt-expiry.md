# ADR 0018 — JWT Expiry Settings

## Context

Choosing access + refresh token TTLs balances UX (don't make people log in
all the time) and security (limit damage from a stolen token).

## Decision

- **Access token**: 1 hour TTL.
- **Refresh token**: 7 days TTL, sliding refresh.
- After 30 days of inactivity, refresh is also invalidated (forced
  re-login).

## Why

- 1 hour limits exposure if a token is intercepted.
- 7 days lets staff stay logged in for a typical work week.
- 30-day inactivity catches "I left my old phone in a drawer for a month"
  cases.

## Implementation

`SIMPLE_JWT` settings in `config/settings/base.py`:

```python
SIMPLE_JWT = {
    "ACCESS_TOKEN_LIFETIME": timedelta(hours=1),
    "REFRESH_TOKEN_LIFETIME": timedelta(days=7),
    "ROTATE_REFRESH_TOKENS": True,
    "BLACKLIST_AFTER_ROTATION": True,
}
```

We also persist a `Session` row per refresh token so users (and admins)
can list and revoke active sessions.

## Status

Accepted, June 2023.
