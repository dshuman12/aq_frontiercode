# ADR-0002: Money and quantities

## Status
Accepted

## Decision
- **Money**: stored as `DecimalField(max_digits=12, decimal_places=2)` for
  customer-facing amounts. For high-precision internal math (recipe ingredient
  cost, line item cost) we sometimes use `IntegerField(...cents)` for
  efficiency.
- **Quantities**: `DecimalField(max_digits=12, decimal_places=3)` because
  recipe ingredient quantities really do need 3 decimal places (e.g.
  "0.025 kg of saffron").
- **Units**: stored alongside the quantity, never assumed.

## Consequences
- We never use `float` for anything monetary.
- DRF serializer fields use `DecimalField` to match.
- Multiplication in services explicitly converts to/from `Decimal`.
