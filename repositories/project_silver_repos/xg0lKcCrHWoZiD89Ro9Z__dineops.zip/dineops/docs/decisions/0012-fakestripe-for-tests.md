# ADR 0013 — FakeStripe Adapter for Tests

## Context

Tests should be deterministic, fast, and offline. Calling Stripe directly
from tests is slow, requires network, and mutates Stripe sandbox state.

## Decision

`apps.payments.stripe_client.get_client()` returns one of two adapters:

- `_RealStripeAdapter` — when `STRIPE_API_KEY` is set AND
  `DINEOPS_STRIPE_FAKE` is false.
- `_FakeStripe` — otherwise.

The `_FakeStripe` returns deterministic-ish responses with `pi_test_...`
and `ch_test_...` IDs that look enough like real Stripe IDs to pass
serializers and tests.

## Consequences

- Tests run offline.
- Production must explicitly set `STRIPE_API_KEY` (no default), preventing
  accidental fake-mode in prod.
- We don't test against the real Stripe API in CI. End-to-end Stripe tests
  are run nightly against a Stripe sandbox in a separate workflow.

## Status

Accepted, November 2023.
