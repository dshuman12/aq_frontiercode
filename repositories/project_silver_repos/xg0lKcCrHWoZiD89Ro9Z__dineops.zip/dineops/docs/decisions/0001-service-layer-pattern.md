# ADR-0001: Service layer pattern

## Status
Accepted

## Context
Django views default to fat ViewSets/CBVs that mix HTTP concerns with
business rules. As the system grows, this gets hard to test and impossible
to reuse from Celery / management commands / Channels consumers.

## Decision
Every Django app follows this layering:

```
models.py        — schema + lightweight invariants
selectors.py     — pure read queries (no side effects, no auth)
services.py      — write transactions; raise DomainError; framework-agnostic
serializers.py   — DRF input/output
views.py         — thin DRF views: validate, call service, serialize
permissions.py   — DRF permission classes
tasks.py         — Celery tasks; only call services
signals.py       — last resort, only for cross-app side effects
```

## Consequences
- Tests can target services directly without an HTTP layer.
- Reusing logic from a Celery task is mechanical: `from .services import ...`.
- Permissions live in two places (DRF for HTTP, manual checks in services
  when called from non-HTTP contexts) — accepted trade-off.
- Selectors prevent us from sprinkling `Model.objects.filter(...)` across
  views and templates; one place to add tenant scoping etc.
