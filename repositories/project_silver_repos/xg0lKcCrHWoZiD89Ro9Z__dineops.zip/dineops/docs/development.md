# Local Development

## One-time setup

```bash
git clone <repo>
cd dineops
cp .env.example .env  # if present
docker-compose -f docker/docker-compose.yml up -d
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py seed_demo_data
cd ../frontend && npm install
cd ../kitchen_screen && npm install
```

## Day-to-day

| Process            | Command                                      | Port |
|--------------------|----------------------------------------------|------|
| Django/Daphne      | `python manage.py runserver`                 | 8000 |
| Celery worker      | `celery -A config worker -l info`            | —    |
| Celery beat        | `celery -A config beat -l info`              | —    |
| Staff frontend     | `cd frontend && npm run dev`                 | 5173 |
| Kitchen screen     | `cd kitchen_screen && npm run dev`           | 5174 |

## Tests

```bash
cd backend
pytest -x --reuse-db
```

Common test flags:
- `-x`: stop after first failure
- `--reuse-db`: skip create/destroy each run; recreate when models change
- `-k <substring>`: run a subset
- `--cov=apps`: coverage report

## Linting + formatting

```bash
ruff check .
black --check .
```

## Migrations

When you add a new model or change a field:

```bash
python manage.py makemigrations
python manage.py migrate
```

Don't squash migrations across release boundaries; we keep them historical.

## Resetting the demo

```bash
python manage.py seed_demo_data --reset
```

## Commit conventions

- `m<scope>: <change>` for modules — e.g. `inventory: ...`, `orders: ...`.
- `frontend(<scope>): ...` for frontend changes.
- `docs: ...` for doc-only changes.
- `tests(<scope>): ...` if a commit is purely tests.

We don't enforce conventional commits — just keep messages descriptive.
