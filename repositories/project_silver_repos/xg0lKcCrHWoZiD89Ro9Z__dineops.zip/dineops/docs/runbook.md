# Operations Runbook

How to handle common operational issues.

## "Inventory drift" alarm

When the materialized `quantity_on_hand` diverges from the integral of all
`InventoryTransaction` rows. Run:

```bash
python manage.py audit_inventory_drift --restaurant <slug>
```

If drift is small (< 5 base units), it's probably from interrupted requests.
Reset the materialized values with the next physical count session.

If drift is larger or persistent, investigate:
- Race conditions in `consume_stock` (look for missing `transaction.atomic`).
- Direct DB writes that bypassed the service layer (rare).
- A failed Celery task that wrote a half-committed transaction.

## "Low-stock alerts not firing"

1. Check `inventory.scan_low_stock` ran recently in the Celery beat log.
2. Check that the InventoryItem has `is_active=True` AND `reorder_point > 0`.
3. Check `LowStockAlert` for an unresolved alert that's blocking new ones.
4. Check `Notification` rows for the relevant users.

## Stripe webhook backlog

If we're missing payment status updates:
1. Look at the most recent `payment.failed` audit entries.
2. The `_FakeStripe` adapter should NEVER be active in production —
   verify `DINEOPS_STRIPE_FAKE` is unset and `STRIPE_API_KEY` is real.
3. Stripe → Webhooks → Recent deliveries shows what was sent.

## "Cash variance" investigation

Variance > $5 should trigger a manager review. Check:
- The day's `OrderEvent.kind=item_voided` entries — staff voiding cash items
  is a flag.
- Refunds processed during the day.
- Tip distributions that don't match the payment's `tip_amount`.

## Daily backup verification

The closeout module creates an `approved` row each day. If a day is missing
an approved closeout for a location, that's a flag — either the manager
missed the close-out or the recompute task is broken.

## "Order stuck in submitted"

If the kitchen never picks up an order, the `Order.in_kitchen_at` will
remain `null`. Check:
- The `kitchen.<location_id>` channel group has at least one consumer
  (kitchen screen running).
- The `OrderEvent.kind=item_added` exists for at least one item.
- Manually call `services.fire_to_kitchen(order=...)` from the Django shell
  to recover.

## Releasing

We use trunk-based development with feature branches. To release:
1. CI green on `main`.
2. Tag: `git tag v1.x.x && git push --tags`.
3. The `release` workflow builds Docker images and applies migrations.
