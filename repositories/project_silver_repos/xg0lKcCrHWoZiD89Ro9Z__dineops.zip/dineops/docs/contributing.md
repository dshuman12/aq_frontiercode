# Contributing

Thanks for considering a contribution. This document describes how to get
started.

## Setup

See `docs/development.md` for environment setup.

## Branch + commit naming

- Branch: `feat/<short-description>`, `fix/<short-description>`,
  `docs/<short-description>`, `chore/<short-description>`.
- Commit messages: short imperative summary line ≤ 72 chars, then optional
  body. Don't bother with conventional-commits prefixes — be descriptive.

## What we look for in a PR

1. **Tests for new code**: every service-layer function should have at
   least one happy-path + one error-path test.
2. **No unnecessary abstraction**: write the small concrete thing first.
3. **Service layer over signals**: explicit code in services beats implicit
   signal-driven side effects unless we're fanning out to multiple apps.
4. **Docs**: if you're adding a new module or making a non-obvious
   architecture decision, write an ADR (`docs/decisions/`).

## What we don't merge

- New dependencies without discussion in the PR description.
- Breaking changes to public API endpoints without a `/api/v2/` migration plan.
- "Cleanup" PRs that touch many unrelated files — break them up.
- Commented-out code (delete it; git remembers).
- TODO comments without an owner or a linked issue.

## Code style

- `ruff check .` and `black .` must pass.
- 100-column line limit.
- Type hints on all service-layer function signatures.
- f-strings over `.format()`. f-strings over `%` formatting.
- Docstrings: one-line for simple functions; multi-line for non-obvious
  business logic.

## Release process

1. PR merged to `main` → CI builds Docker image, runs tests.
2. Tag a release (`git tag v1.x.x && git push --tags`).
3. The release workflow deploys to staging, runs smoke tests.
4. Manually promote staging → production after verification.
