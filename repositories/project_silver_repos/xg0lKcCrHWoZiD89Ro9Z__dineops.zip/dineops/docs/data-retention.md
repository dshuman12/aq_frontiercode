# Data Retention Policy

DineOps stores operational and business-critical data. We balance customer
need for historical analysis with the cost of storing data forever and our
GDPR-style obligations.

## Categories

| Data                          | Retention     | Notes                                |
|-------------------------------|---------------|--------------------------------------|
| Orders, OrderItems            | 7 years       | Tax/audit minimum                    |
| Payments, Refunds             | 7 years       | Required for accounting              |
| Closeouts                     | 7 years       | Source of truth for daily P&L        |
| Audit log                     | 5 years       | Append-only; compressed cold storage after 2 yrs |
| Inventory transactions        | 7 years       | Used for COGS reports                |
| Waste entries                 | 7 years       | Inventory cross-reference            |
| Staff shifts + clock entries  | 7 years       | Labor / wage compliance              |
| Recipe versions               | indefinite    | Recipe history is small              |
| User accounts                 | until revoked | Email is hashed on permanent deletion|
| Notifications                 | 180 days      | `cleanup_old_notifications` task     |
| Sessions                      | 30 days       | Auto-revoked                         |
| Email tokens (verify, reset)  | 30 days       | Auto-cleaned                         |
| WebSocket events              | not stored    | Transient                            |
| Application logs (Sentry)     | 90 days       | per Sentry retention                 |

## User-deletion request (right to erasure)

When a customer requests deletion under GDPR/CCPA:

1. Mark the user account `is_active=False` and clear PII (email →
   `<uuid>@deleted.dineops.invalid`, name → empty).
2. Audit entries reference the user via FK + `actor_email_snapshot` so
   they remain readable as historical actions, with the now-redacted
   email.
3. Orders/payments stay intact for tax purposes (7-year minimum).

## Retention enforcement

- `notifications.cleanup_old_notifications` — daily.
- Audit cold-storage compaction — quarterly manual run (no automated
  task yet; see backlog).
- Closeouts and orders retention is currently passive — we keep them
  forever and review annually.

## Backups

- Postgres point-in-time recovery (PITR) for the last 7 days.
- Daily logical backup retained for 90 days, encrypted at rest (KMS).
- Restoration tested quarterly.
