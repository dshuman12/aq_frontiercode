# Staff & shifts

## Staff profile

A `StaffProfile` is per-user-per-restaurant. The same user can have multiple
profiles across different restaurants (different rates, different roles).

## Shift lifecycle

```
scheduled → in_progress → completed
  ↓
cancelled (only from scheduled)
  ↓
missed (set by a Celery sweep)
```

## Time clock

`TimeClockEntry` is the source of truth for "who worked when." It's
explicitly decoupled from `StaffShift` so that:
- Staff can clock in without a scheduled shift (rare, but happens).
- The clock can be edited later via `ShiftEditRequest` without touching the
  shift schedule.

A staff member may have at most one **open** TimeClockEntry at a time.
Attempts to start a second one return 409 / `already_clocked_in`.

## Breaks

Each entry can have many breaks. Only one open break at a time. When the
clock-out fires, any open break is auto-closed at the same timestamp.

## Edit requests

Workflow:
1. Staff submits a `ShiftEditRequest` with proposed times.
2. Manager reviews + approves/denies.
3. On approve, the underlying `TimeClockEntry` is updated and marked
   `edited=True` with the reason copied from the request.

## Labor cost calculation

`worked_minutes()` subtracts break minutes from the gross duration. The
`labor_summary` selector aggregates this and multiplies by
`StaffProfile.hourly_rate_cents`. Overtime calculation lives in
`calculate_overtime_minutes`; default threshold is 40 hours/week.

## Background jobs

- `shifts.send_shift_reminders` — every 5 min; pings staff about shifts
  starting in ~60 min.
- `shifts.close_stale_open_entries` — every hour; closes any
  `TimeClockEntry` that's been open >16 hours, with an audit reason.
