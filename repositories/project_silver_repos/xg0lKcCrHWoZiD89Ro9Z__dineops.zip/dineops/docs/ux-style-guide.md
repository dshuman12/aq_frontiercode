# UX Style Guide

A short, opinionated guide to keep the staff dashboard consistent.

## Tone

- **Direct, not chatty.** "Order placed." not "Yay! Your order has been
  placed successfully!"
- **Operator language**, not customer-facing language. Staff use this
  app dozens of times a day; we don't need to be cute.

## Color

- **Action**: `dineops-600` (deep red) for primary call-to-action buttons.
- **Cancel/destructive**: `red-600` for confirmations, never as a primary
  CTA.
- **Status pills**:
  - submitted/queued: amber
  - in progress: blue
  - ready/done: green
  - voided/comped: red
  - paid: emerald

## Density

The dashboard is for fast users. Default to dense layouts:
- Tables: 8px vertical padding per row.
- Forms: labels above inputs, no extra wrapper divs.
- Sidebars: 14px font, 8px line-height.

## Times

Always show local restaurant time (not UTC) in the UI. The backend stores
UTC and the staff app applies the restaurant's timezone in `formatTime()`.

## Errors

- Inline next to the field, with `text-red-700`.
- Form-level errors at the top of the form, in red.
- Toast-style notifications for transient errors (network failures).

## Empty states

- Always include a CTA when the empty state is "no data yet".
- Never just say "No items found." without a button or link.

## Loading

- Skeleton placeholders for first paint.
- Spinner only for actions in progress.
- Always disable submit buttons while a mutation is pending.

## Mobile

The kitchen screen is desktop-only (intended for a wall display). The
staff app is mobile-friendly but tablet-first; designed for 768px+ screens.
Phone-sized fallback works for time-clocks and prep checklists.
