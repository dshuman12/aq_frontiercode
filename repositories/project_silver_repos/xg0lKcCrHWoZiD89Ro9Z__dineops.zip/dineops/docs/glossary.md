# Glossary

Domain terms used throughout DineOps. Add to this when terminology is
non-obvious.

| Term                  | Definition                                                |
|-----------------------|------------------------------------------------------------|
| **86'd**              | Item is unavailable today (set `is_available=False`).     |
| **Comp**              | Manager-approved zero-charge item (different from a void). |
| **Cover**             | A guest. "20 covers" = 20 guests for the night.           |
| **Cover count**       | Synonym for `guest_count` on an Order.                     |
| **Drop**              | The cashier's mid-shift cash drop into a safe.            |
| **Expo**              | Expediter — the person assembling complete orders for delivery to tables. |
| **FEFO**              | First-Expiring, First-Out (lot consumption order).        |
| **Fired**             | Order has been sent to the kitchen for preparation.       |
| **In the weeds**      | Kitchen is severely behind. (Slang, not a status.)        |
| **86'd**              | Same as "out of stock for today".                          |
| **Net sales**         | Gross sales minus discounts and comps.                    |
| **Open check**        | Order not yet paid.                                        |
| **Order in**          | Same as fired — kitchen has been told to start cooking.   |
| **Pace**              | The rate of orders per hour for the kitchen.               |
| **Par**               | Target stock level for an inventory item.                 |
| **PIN**               | A 4-6 digit numeric login used at terminals.              |
| **POS**               | Point-of-sale system (we are one).                         |
| **Prep**              | Pre-shift food preparation (mise en place).                |
| **PO**                | Purchase order to a vendor.                                |
| **Reorder point**     | Stock level that triggers a low-stock alert.               |
| **Run**               | A small amount, just-in-time made (e.g., "a run of bread").|
| **Sub-recipe**        | A recipe used as an ingredient in other recipes.          |
| **Tender**            | The payment instrument — cash, card, gift card, etc.      |
| **Tip out**           | Distribution of pooled tips to back-of-house and other roles. |
| **Top of station**    | The active prep workspace at a kitchen station.            |
| **Variance** (cash)   | Difference between expected and counted cash drawer.      |
| **Variance** (count)  | Difference between expected and physically-counted inventory. |
| **Void**              | Cancellation of an order or item, with reason.             |
| **Walk**              | Customer who left without paying.                          |
| **Yield factor**      | Percentage of an ingredient that's usable after trim.     |
| **Z-out**             | End-of-day register reset / closeout.                      |
