# Purchasing & Vendors

The purchasing module is the workflow layer that ties vendors, inventory, and
the kitchen's restocking process together.

## Lifecycle

```
   draft  ──submit──▶ submitted ──receive──▶ received
     │                    │                 (or partially_received)
     │                    └─cancel──▶ cancelled
     └──cancel──▶ cancelled
```

| Status                | Editable lines? | Affects inventory? |
|-----------------------|-----------------|--------------------|
| `draft`               | Yes             | No                 |
| `submitted`           | No              | No                 |
| `partially_received`  | No              | Yes (incrementally)|
| `received`            | No              | Yes                |
| `cancelled`           | No              | No                 |
| `disputed`            | No              | Frozen for review  |

## Receiving

A line is received in pieces. Each `receive_po_line` call:

1. Validates the line belongs to a receivable PO.
2. Caps over-receive at 110% of the ordered amount (an audit guard, not a
   physical limit — staff can override by editing manually if vendor sent
   too much).
3. Posts to `InventoryItem` for the destination location, converting from
   packs to base units (`quantity × pack_quantity`).
4. Updates the weighted-average cost using the actual unit price (not the
   ordered price).
5. Optionally creates a `LotTrackingRecord` if `lot_code`/`expires_at` are
   provided.
6. Recomputes the PO's status.

If `actual_unit_price` differs from the line's `unit_price`, we record both —
this is how you spot vendor "price creep" in the M12 reports.

## PO Numbering

`po_number` is `<RESTAURANT>-<YYYYMMDD>-<NNN>`:

```
DOWNTO-20230915-001
DOWNTO-20230915-002
```

We do this instead of a global counter because:
- Restaurants do their own daily reconciliation against vendor invoices.
- The format is human-readable and parseable.
- Uniqueness is global so accountants can search across restaurants.

## Auto-Reorder

`auto_generate_reorder_po(restaurant, location, vendor, actor)` walks all
inventory items at `location` that are at-or-below their reorder_point AND
have a positive `reorder_quantity` AND are offered by `vendor`. It builds a
draft PO with one line per matching item, ordering enough packs to cover the
reorder_quantity.

This is **not** automatic — managers explicitly trigger it from the UI.
Auto-creation of submitted POs would be too dangerous; we always leave a
human in the loop to sanity-check before committing the order.

## Permissions

PO creation, line management, submission, and receiving are all gated to:
`owner`, `general_manager`, `assistant_manager`, `chef`, `inventory_manager`,
`accountant`. Purely operational roles (`server`, `cashier`) cannot place orders.

## Future Work

- **EDI integration**: large vendors (Sysco, US Foods) accept EDI submissions.
  We'd export submitted POs to EDI 850 and consume EDI 856 ASN responses.
- **3-way match**: invoice ↔ PO ↔ receipt reconciliation in the M9 payments
  module. The data model already supports it via `vendor_invoice_number` on
  the PO and `actual_unit_price` on the line.
- **Quote/RFQ**: a `RequestForQuote` table that goes out to multiple vendors
  before a PO is created. Out of scope for v1.
