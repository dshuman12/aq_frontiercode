# Team

A short note about who built DineOps v1, for context.

This document is intentionally kept brief — engineering decisions are
recorded in ADRs, not in personality profiles. But the repo is a
collaborative artifact, and a reader might want to know the shape of
the team.

## Core engineering

- **Backend**: 4 Python/Django engineers, 1 lead.
- **Frontend**: 2 React engineers.
- **Operations**: 1 SRE shared with sister projects.

## Adjacent

- **Product**: 1 PM with restaurant operations background (former GM).
- **Design**: 1 designer, focused on staff workflows.
- **QA**: 1 QA lead + contractor pool for browser/device matrix testing.
- **Customer success**: 2 CSMs running pilot onboardings.

## Working agreements

- Trunk-based development. Feature branches merged to `main` daily.
- Async by default; one weekly all-hands sync.
- ADRs for any decision that affects more than one module.
- Pair on tricky changes; PR review otherwise.

The pilot restaurant ran a real day on the system in March 2024. v1
ships with confidence.
