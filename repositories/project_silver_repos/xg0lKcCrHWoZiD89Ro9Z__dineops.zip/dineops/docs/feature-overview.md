# Feature Overview

This document gives a high-level walk-through of every DineOps surface,
suitable for new joiners or potential customers.

## Module Map

| Module          | Purpose                                                        |
|-----------------|----------------------------------------------------------------|
| accounts        | Email-only auth, TOTP 2FA, password reset, sessions            |
| restaurants     | Tenant root, members, roles, custom permissions, invitations   |
| locations       | Branches, business hours, holidays, kitchen stations           |
| staff           | Employee profiles, hourly rate, employment type                |
| shifts          | Schedules, time clocks, breaks, edit requests, labor reports   |
| menus           | Menus / categories / items / variants / modifier groups        |
| recipes         | Standardized recipes, ingredient lines, costing, version history|
| ingredients     | Master ingredient list with yield factors                      |
| inventory       | Stock-on-hand, lots (FEFO), counts, low-stock alerts           |
| vendors         | Suppliers, vendor-ingredient prices, contacts, ratings         |
| purchasing      | POs (draft/submit/receive), auto-reorder, 3-way match data     |
| prep            | Prep lists, tasks, production runs (decrement inventory)       |
| orders          | Customer checks, line items, modifiers, void/comp/discount     |
| kitchen         | WebSocket consumers for kitchen + expo screens                 |
| payments        | Cash/card/Stripe, refunds, tip distribution                    |
| closeout        | Daily Z-out: sales, tenders, cash variance                     |
| waste           | Waste logs that decrement inventory + summary by reason        |
| manager_tasks   | Opening/closing/deep-clean checklists with photo evidence      |
| notifications   | Multi-channel notifications (email/sms/push/in-app/webhook)    |
| reports         | Sales, top items, void/comp, labor, COGS, payment breakdown    |
| audit_logs      | Append-only audit trail of money/inventory/staffing changes    |
| files           | S3-backed file metadata (photos, signatures, invoices)         |
| common          | Shared exceptions, permissions, base models, middleware        |

## Two frontends

- **Staff app** (`frontend/`): The main dashboard for managers, servers,
  cashiers — order taking, inventory management, scheduling, reports.
- **Kitchen screen** (`kitchen_screen/`): A separate React app intended for
  a wall-mounted kitchen display. WebSocket-driven, big text, big buttons.

## Run locally

```bash
docker-compose -f docker/docker-compose.yml up -d
cd backend
python manage.py migrate
python manage.py seed_demo_data --reset
python manage.py runserver  # also starts ASGI/Channels via daphne
celery -A config worker -l info
celery -A config beat -l info
cd ../frontend && npm install && npm run dev
cd ../kitchen_screen && npm install && npm run dev
```

Default demo login: `owner@dineops.test` / `password123!`

## Permissions cheat sheet

| Role               | Sees orders | Takes orders | Voids   | Refunds | Manages menu | Inventory | Reports |
|--------------------|:-----------:|:------------:|:-------:|:-------:|:------------:|:---------:|:-------:|
| owner              | ✓           | ✓            | ✓       | ✓       | ✓            | ✓         | ✓       |
| general_manager    | ✓           | ✓            | ✓       | ✓       | ✓            | ✓         | ✓       |
| assistant_manager  | ✓           | ✓            | ✓       | ✓       | ✓            | ✓         | ✓       |
| chef               | ✓           |              |         |         |              | ✓         |         |
| kitchen_staff      | ✓           |              |         |         |              |           |         |
| server             | ✓           | ✓            |         |         |              |           |         |
| cashier            | ✓           | ✓            |         |         |              |           |         |
| inventory_manager  |             |              |         |         |              | ✓         |         |
| accountant         |             |              |         | ✓       |              |           | ✓       |
| viewer             | read-only across the restaurant.                                          |
