# Onboarding a New Restaurant

This is the playbook our success team follows to spin up a new restaurant
on DineOps.

## Day 0: Account creation

1. Owner signs up via `/api/auth/register/`. Email is verified via the
   one-time link.
2. Owner creates a Restaurant. The restaurant gets a slug (which is a stable
   identifier in API URLs and report exports).
3. Owner role is assigned automatically to the creating user.

## Day 1: Locations

1. Add at least one Location with name, address, dine-in/takeout/delivery
   flags.
2. Configure business hours per weekday.
3. Add holidays the location is closed on.
4. Add kitchen stations (at least "main").

## Day 1-2: Staff

1. Invite key managers (general_manager, assistant_manager).
2. Each accepts via the email invitation link, which auto-creates a
   `RestaurantMember` and binds them to the right roles.
3. Owner adds StaffProfiles for hourly employees with employment_type and
   hourly_rate_cents.

## Day 2-5: Menu

1. Create a Menu (kind=dinner, etc.).
2. Add MenuCategories.
3. Add MenuItems with prices and dietary flags.
4. Add MenuItemVariants for size options.
5. Configure ModifierGroups for choice questions.
6. Wire ModifierGroups to items via attach_modifier_group.

## Day 3-5: Inventory + Recipes

1. Create Ingredients (or import from CSV).
2. Create InventoryItems for each (Location × Ingredient) pair with
   par/reorder/opening qty.
3. Create Recipes that reference Ingredients with quantity + unit.
4. Wire Recipes to MenuItems where applicable.

## Day 5-7: Vendors + Purchasing

1. Add Vendors with payment terms.
2. Add VendorIngredient offerings (pack_size, pack_qty, case_price).
3. Optionally mark a "preferred" offering per ingredient.

## Day 7: Go live

1. Test order flow on a single location.
2. Test payment flow with a card test charge.
3. Schedule first prep list and first opening checklist for tomorrow.
4. Monitor low-stock alerts daily for the first week.
5. Run first daily closeout end-to-end on day 1 of operation.

## Day 30: Review

1. Run `python manage.py audit_inventory_drift --restaurant <slug>`
   to verify no drift.
2. Pull a 30-day sales summary, top items, payment breakdown report.
3. Check waste-by-reason — if `over_prep` is high, recipes need adjustment.
4. Review staff hours vs. labor cost trend.
