# Disaster Recovery

How we recover from common failure modes.

## Database loss

If the primary Postgres is lost:
1. Promote the read replica (if running multi-AZ).
2. If no replica: restore from PITR snapshot. RTO: 30 minutes.
3. Apply migrations: `python manage.py migrate`.
4. Verify data integrity: `python manage.py audit_inventory_drift --restaurant <slug>`.

## Redis loss

Redis is the broker for Celery and the channel layer for WebSockets.
On loss:
1. Spin up a fresh Redis. Tasks in flight are lost.
2. Celery workers reconnect automatically.
3. WebSocket clients reconnect on the next event (the `connectKitchen`
   client backs off exponentially up to 30s).
4. Re-run `inventory.scan_low_stock` manually to catch up alerts that
   would have fired during the outage.

## Stripe outage

If Stripe is unreachable:
1. The cashier UI shows an error. Cash + card-on-terminal flows still work.
2. Pending Stripe payments stay in `pending` state. We don't auto-fail
   them — the `confirm` flow can still succeed when Stripe recovers.
3. We do NOT mark orders as paid via the Stripe path until the intent is
   confirmed.

## Application server loss

DineOps is stateless behind a load balancer. Replace the bad node; ASG
will spin up a new one.

## Data corruption (e.g., bad migration)

1. Stop traffic via load balancer.
2. Restore from PITR to before the migration.
3. Replay any payments / orders that occurred during the corruption
   window from the audit log.
4. Resume traffic.

## Customer-data exfiltration

If we suspect breach:
1. Rotate `DJANGO_SECRET_KEY` and Stripe API keys.
2. Revoke all sessions: `Session.objects.all().delete()`.
3. Force password reset for all users.
4. Audit `AuditEntry` rows for unusual access patterns.
5. Engage breach-notification lawyers (we have retainer).

## RTO / RPO targets

- **RTO** (recovery time objective): 30 minutes for any single AZ failure.
- **RPO** (recovery point objective): 5 minutes (PITR window).

## Tested quarterly

We run a planned DR drill every quarter:
- Tear down the staging DB, restore from PITR, verify orders and reports.
- Capture timing data and update this document.
