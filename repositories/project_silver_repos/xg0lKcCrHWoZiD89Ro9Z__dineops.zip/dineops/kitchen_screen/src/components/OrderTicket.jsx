import { useState, useEffect } from "react";

const STATUS_LABEL = {
  pending: "Pending",
  sent_to_kitchen: "New",
  in_progress: "Cooking",
  ready: "Ready",
  served: "Served",
  voided: "Void",
};

const STATUS_BG = {
  sent_to_kitchen: "bg-amber-100",
  in_progress: "bg-blue-100",
  ready: "bg-green-100",
  served: "bg-slate-100",
  voided: "bg-red-100",
};

function elapsed(since) {
  const ms = Date.now() - new Date(since).getTime();
  const min = Math.floor(ms / 60000);
  const sec = Math.floor((ms % 60000) / 1000);
  return `${min}:${sec.toString().padStart(2, "0")}`;
}

export default function OrderTicket({ order, onItemAction }) {
  // Re-render every second so elapsed timer updates
  const [, force] = useState(0);
  useEffect(() => {
    const t = setInterval(() => force((n) => n + 1), 1000);
    return () => clearInterval(t);
  }, []);

  return (
    <div className="border-2 border-slate-300 rounded-md bg-white p-3 shadow-sm w-72 flex-shrink-0">
      <div className="flex justify-between items-start border-b pb-2 mb-2">
        <div>
          <div className="font-bold text-lg">#{order.order_number}</div>
          <div className="text-sm text-slate-600">
            {order.kind === "dine_in" && `Table ${order.table_number}`}
            {order.kind !== "dine_in" && order.kind.toUpperCase()}
            {order.guest_count > 1 && ` · ${order.guest_count} guests`}
          </div>
        </div>
        <div className="text-right">
          <div className="font-mono text-sm">
            {elapsed(order.submitted_at || order.created_at)}
          </div>
          <div className="text-xs text-slate-500 uppercase">{order.status}</div>
        </div>
      </div>

      <ul className="space-y-2">
        {order.items
          ?.filter((it) => it.status !== "voided")
          .map((item) => (
            <li
              key={item.id}
              className={`p-2 rounded ${STATUS_BG[item.status] || "bg-white"}`}
            >
              <div className="flex justify-between items-start">
                <div>
                  <div className="font-medium">
                    {item.quantity} × {item.item_name_snapshot}
                    {item.variant_name && (
                      <span className="text-sm text-slate-500"> ({item.variant_name})</span>
                    )}
                  </div>
                  {item.modifiers?.length > 0 && (
                    <ul className="text-xs text-slate-600 ml-3">
                      {item.modifiers.map((m) => (
                        <li key={m.id}>+ {m.name_snapshot}</li>
                      ))}
                    </ul>
                  )}
                  {item.special_request && (
                    <div className="text-xs italic text-amber-700 mt-1">
                      {item.special_request}
                    </div>
                  )}
                </div>
                <span className="text-xs text-slate-500">
                  {STATUS_LABEL[item.status]}
                </span>
              </div>
              <div className="flex gap-2 mt-2">
                {item.status === "sent_to_kitchen" && (
                  <button
                    className="text-xs px-2 py-1 bg-blue-600 text-white rounded"
                    onClick={() => onItemAction?.(item, "mark_in_progress")}
                  >
                    Start
                  </button>
                )}
                {item.status === "in_progress" && (
                  <button
                    className="text-xs px-2 py-1 bg-green-600 text-white rounded"
                    onClick={() => onItemAction?.(item, "mark_ready")}
                  >
                    Ready
                  </button>
                )}
                {item.status === "ready" && (
                  <button
                    className="text-xs px-2 py-1 bg-slate-500 text-white rounded"
                    onClick={() => onItemAction?.(item, "mark_served")}
                  >
                    Served
                  </button>
                )}
              </div>
            </li>
          ))}
      </ul>
    </div>
  );
}
