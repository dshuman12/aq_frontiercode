import { Routes, Route } from "react-router-dom";

function Home() {
  return (
    <div className="p-6 text-2xl">
      DineOps Kitchen — connect a station to start receiving tickets.
    </div>
  );
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
    </Routes>
  );
}
