import { useEffect, useState, useRef } from "react";
import { connectKitchen } from "./socket";
import OrderTicket from "./components/OrderTicket";

export default function KitchenScreen({ locationId, token }) {
  const [orders, setOrders] = useState([]);
  const [connected, setConnected] = useState(false);
  const wsRef = useRef(null);

  useEffect(() => {
    const conn = connectKitchen({
      locationId, token,
      onOpen: () => setConnected(true),
      onClose: () => setConnected(false),
      onMessage: (msg) => {
        if (msg.type === "hello") {
          setOrders(msg.snapshot || []);
        } else if (msg.type === "order.updated") {
          // refetch will be added later; for now flash the row
          console.log("order updated", msg.payload);
        } else if (msg.type === "item.updated") {
          setOrders((prev) =>
            prev.map((o) => ({
              ...o,
              items: (o.items || []).map((it) =>
                it.id === msg.payload.item_id
                  ? { ...it, status: msg.payload.status }
                  : it,
              ),
            })),
          );
        }
      },
    });
    wsRef.current = conn;
    return () => conn.close();
  }, [locationId, token]);

  const handleAction = (item, action) => {
    wsRef.current?.send({ action, item_id: item.id });
  };

  const visible = orders.filter((o) =>
    ["submitted", "in_kitchen", "ready"].includes(o.status),
  );

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 p-4">
      <header className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">Kitchen Screen</h1>
        <div className="flex items-center gap-2 text-sm">
          <span
            className={`inline-block w-2 h-2 rounded-full ${
              connected ? "bg-green-500" : "bg-red-500"
            }`}
          />
          {connected ? "Connected" : "Reconnecting…"}
          <span className="text-slate-400 ml-3">
            {visible.length} active orders
          </span>
        </div>
      </header>

      <div className="flex gap-4 overflow-x-auto pb-4">
        {visible.length === 0 && (
          <p className="text-slate-400">No active orders. All caught up!</p>
        )}
        {visible.map((order) => (
          <OrderTicket
            key={order.id}
            order={order}
            onItemAction={handleAction}
          />
        ))}
      </div>
    </div>
  );
}
