// Tiny WebSocket helper that auto-reconnects with exponential backoff.
// Used by the kitchen + expo screens.

export function connectKitchen({ locationId, token, onMessage, onOpen, onClose }) {
  let ws = null;
  let backoff = 500;
  let alive = true;

  function open() {
    const proto = location.protocol === "https:" ? "wss" : "ws";
    const url = `${proto}://${location.host}/ws/kitchen/${locationId}/?token=${token}`;
    ws = new WebSocket(url);
    ws.onopen = () => {
      backoff = 500;
      onOpen?.();
    };
    ws.onmessage = (evt) => {
      try {
        const msg = JSON.parse(evt.data);
        onMessage?.(msg);
      } catch (e) {
        console.error("bad ws message", e);
      }
    };
    ws.onclose = () => {
      onClose?.();
      if (alive) {
        setTimeout(open, backoff);
        backoff = Math.min(backoff * 2, 30000);
      }
    };
    ws.onerror = (e) => console.warn("ws error", e);
  }

  open();

  return {
    send: (payload) => ws?.readyState === 1 && ws.send(JSON.stringify(payload)),
    close: () => {
      alive = false;
      ws?.close();
    },
  };
}
