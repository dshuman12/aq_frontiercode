# DineOps

Restaurant back-office and operations platform — staff shifts, food prep,
inventory, vendors, purchase orders, waste tracking, recipe costing, daily
cash closeout, and manager reports.

## Stack

- **Backend**: Python 3.11, Django 4.2, Django REST Framework, PostgreSQL 15,
  Redis, Celery, Django Channels (websockets), Stripe.
- **Frontend**: React 18 + Vite + Tailwind, TanStack Query, Zustand, React
  Hook Form + Yup.
- **Kitchen Screen**: separate React app optimized for tablets in the kitchen.
- **Tests**: pytest + pytest-django + factory-boy + DRF APIClient.
- **Linting**: Ruff + Black + Prettier.
- **API docs**: drf-spectacular (OpenAPI 3).

## Quick start

```bash
# 1. infrastructure
docker compose -f docker/docker-compose.yml up -d

# 2. backend
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements/dev.txt
python manage.py migrate
python manage.py seed_demo_data
python manage.py runserver

# 3. workers (separate terminals)
celery -A config worker -l info
celery -A config beat -l info

# 4. frontend
cd ../frontend && npm install && npm run dev

# 5. kitchen screen
cd ../kitchen_screen && npm install && npm run dev
```

Backend at `:8000`, frontend at `:5173`, kitchen at `:5174`.

## Layout

```
backend/
  config/          settings, urls, asgi, celery
  apps/
    accounts/      auth + sessions
    restaurants/   restaurant + members + invitations
    locations/     branches per restaurant
    staff/         employee profiles
    shifts/        scheduling + time clock
    menus/         categories, items, modifiers
    recipes/       costing, ingredients, versions
    ingredients/   master ingredient catalog
    inventory/     stock + counts + lots + alerts
    vendors/       vendor directory + product catalog
    purchasing/    POs + receiving
    prep/          daily prep lists
    orders/        dine-in / takeout / delivery
    kitchen/       kitchen tickets + stations
    payments/      Stripe + cash + reconciliation
    closeout/      daily closeout
    waste/         waste log + reasons
    manager_tasks/ checklists with photo proof
    notifications/ in-app + email
    reports/       sales, food cost, labor, waste
    audit_logs/    who-did-what-when
    files/         file uploads
frontend/          staff web app (React)
kitchen_screen/    tablet-optimized KDS
docs/              architecture, database, api, ops workflow
docker/            postgres + redis compose
scripts/           seed + import helpers
```
