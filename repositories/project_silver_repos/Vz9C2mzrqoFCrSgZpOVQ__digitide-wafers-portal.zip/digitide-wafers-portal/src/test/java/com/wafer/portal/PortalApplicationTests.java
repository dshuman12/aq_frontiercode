package com.wafer.portal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
