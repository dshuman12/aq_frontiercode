package com.wafer.portal.repository;

import com.wafer.portal.model.People;
import com.wafer.portal.model.Spotlight;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface SpotlightRepository extends JpaRepository<Spotlight, Long> {
    Page<Spotlight> findByIsDeletedFalse(Pageable pageable);
    Optional<Spotlight> findByIdAndIsDeletedFalse(Long aLong);

    @Query("SELECT s FROM Spotlight s WHERE s.isDeleted = false ORDER BY " +
            "CASE WHEN s.sequence IS NULL THEN 1 ELSE 0 END, s.sequence ASC")
    Page<Spotlight> findAllOrderedBySequence(Pageable pageable);

    @Query("SELECT s FROM Spotlight s WHERE s.isDeleted = false AND " +
            "(LOWER(s.title) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(s.url) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(s.video) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    Page<Spotlight> searchSpotlight(@Param("keyword") String keyword, Pageable pageable);

}
