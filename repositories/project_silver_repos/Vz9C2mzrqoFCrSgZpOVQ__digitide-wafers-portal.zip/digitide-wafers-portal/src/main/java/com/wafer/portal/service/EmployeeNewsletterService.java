package com.wafer.portal.service;

import com.wafer.portal.awsS3.S3Service;
import com.wafer.portal.dto.EmployeeNewsletterRequest;
import com.wafer.portal.dto.EmployeeNewsletterResponse;
import com.wafer.portal.model.EmployeeNewsletter;
import com.wafer.portal.repository.EmployeeNewsletterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Optional;

@Service
public class EmployeeNewsletterService {

    private static final String NEWSLETTER_FOLDER = "Employee-Newsletters";
    private static final String NEWSLETTER_THUMBNAIL = "Employee-Newsletters-Thumbnail";

    private final EmployeeNewsletterRepository repository;
    private final S3Service s3Service;

    @Autowired
    public EmployeeNewsletterService(EmployeeNewsletterRepository repository, S3Service s3Service) {
        this.repository = repository;
        this.s3Service = s3Service;
    }

    public ResponseEntity<EmployeeNewsletterResponse> uploadNewsletter(MultipartFile documentFile, MultipartFile thumbnailFile, EmployeeNewsletterRequest request) {

        try {
            if (documentFile == null || documentFile.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
            }

            String documentKey = s3Service.uploadFile(documentFile, NEWSLETTER_FOLDER);

            String thumbnailKey = null;

            if (thumbnailFile != null && !thumbnailFile.isEmpty()) {
                thumbnailKey = s3Service.uploadFile(thumbnailFile, NEWSLETTER_THUMBNAIL);
            }

            EmployeeNewsletter newNewsletter = new EmployeeNewsletter(
                    request.getDescription(),
                    documentKey,
                    thumbnailKey,
                    request.getIssueDate()
            );

            EmployeeNewsletter saved = repository.save(newNewsletter);

            return new ResponseEntity<>(mapToResponse(saved), HttpStatus.CREATED);

        } catch (IOException e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    public ResponseEntity<Page<EmployeeNewsletterResponse>> getAllNewsletters(Pageable pageable) {
        Page<EmployeeNewsletter> newsletterPage = repository.findAllByIsDeletedFalseOrderByIssueDateDesc(pageable);
        Page<EmployeeNewsletterResponse> dtoPage = newsletterPage.map(this::mapToResponse);

        return dtoPage.isEmpty() ? new ResponseEntity<>(HttpStatus.NO_CONTENT) : new ResponseEntity<>(dtoPage, HttpStatus.OK);
    }


    public ResponseEntity<EmployeeNewsletterResponse> getNewsletterById(Long id) {
        return repository.findByIdAndIsDeletedFalse(id)
                .map(newsletter -> new ResponseEntity<>(mapToResponse(newsletter), HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }


    public ResponseEntity<EmployeeNewsletterResponse> updateNewsletter(
            Long id,
            MultipartFile documentFile,
            MultipartFile thumbnailFile,
            EmployeeNewsletterRequest request) {

        return repository.findByIdAndIsDeletedFalse(id)
                .map(existingNewsletter -> {
                    try {
                        String updatedDocumentKey = existingNewsletter.getDocumentKey();

                        if (documentFile != null && !documentFile.isEmpty()) {
                            updatedDocumentKey = s3Service.updateFile(
                                    existingNewsletter.getDocumentKey(),
                                    documentFile,
                                    NEWSLETTER_FOLDER
                            );
                        }

                        String updatedThumbnailKey = existingNewsletter.getThumbnailKey();

                        if (thumbnailFile != null && !thumbnailFile.isEmpty()) {

                            updatedThumbnailKey = s3Service.updateFile(

                                    existingNewsletter.getThumbnailKey(),
                                    thumbnailFile,
                                    NEWSLETTER_THUMBNAIL
                            );
                        }

                        // Update metadata fields from the request
                        existingNewsletter.setDescription(request.getDescription());
                        existingNewsletter.setIssueDate(request.getIssueDate());
                        existingNewsletter.setDocumentKey(updatedDocumentKey);
                        existingNewsletter.setThumbnailKey(updatedThumbnailKey);

                        EmployeeNewsletter updated = repository.save(existingNewsletter);
                        return new ResponseEntity<>(mapToResponse(updated), HttpStatus.OK);

                    } catch (IOException e) {
                        return new ResponseEntity<EmployeeNewsletterResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
                    }
                })
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }


    public EmployeeNewsletter deleteNewsletter(Long id) {
        return repository.findByIdAndIsDeletedFalse(id)
                .map(newsletter -> {
                    newsletter.setDeleted(true);
                    return repository.save(newsletter); // Return the object to the Controller
                }).orElse(null);
    }

    private EmployeeNewsletterResponse mapToResponse(EmployeeNewsletter newsletter) {
        String documentLink = null;
        if (newsletter.getDocumentKey() != null) {
            documentLink = s3Service.generatePresignedUrl(newsletter.getDocumentKey());
        }
        String thumbnailLink = null;
        if (newsletter.getThumbnailKey() != null) {
            thumbnailLink = s3Service.generatePresignedUrl(newsletter.getThumbnailKey());
        }
        return new EmployeeNewsletterResponse(
                newsletter.getId(),
                newsletter.getIssueDate(),
                newsletter.getDescription(),
                documentLink,
                thumbnailLink,
                newsletter.getCreatedBy(),
                newsletter.getCreationDate(),
                newsletter.getLastModifiedBy(),
                newsletter.getLastModifiedDate()
        );
    }
}
