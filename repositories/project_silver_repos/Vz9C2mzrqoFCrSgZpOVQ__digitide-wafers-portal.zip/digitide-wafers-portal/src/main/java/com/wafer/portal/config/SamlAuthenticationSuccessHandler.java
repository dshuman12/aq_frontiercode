package com.wafer.portal.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wafer.portal.dto.SamlUserAttributes;
import com.wafer.portal.model.User;
import com.wafer.portal.repository.UserRepository;
import com.wafer.portal.service.DailyLoginActivityService;
import com.wafer.portal.service.UserService;
import com.wafer.portal.utils.CookieUtils;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.saml2.provider.service.authentication.Saml2AuthenticatedPrincipal;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;


@Component
public class SamlAuthenticationSuccessHandler implements AuthenticationSuccessHandler {

    private static final Logger logger = LoggerFactory.getLogger(SamlAuthenticationSuccessHandler.class);

    @Value("${app.domain-feurl}")
    private String frontendUrl;


    private final UserService userService;
    private final JwtTokenProvider jwtTokenProvider;
    private final CookieUtils cookieUtils;
    private final UserRepository userRepository;
    private final DailyLoginActivityService dailyLoginActivityService;

    public SamlAuthenticationSuccessHandler(UserService userService,
                                            JwtTokenProvider jwtTokenProvider,
                                            CookieUtils cookieUtils,
                                            UserRepository userRepository,
                                            DailyLoginActivityService dailyLoginActivityService) {
        this.userService = userService;
        this.jwtTokenProvider = jwtTokenProvider;
        this.cookieUtils = cookieUtils;
        this.userRepository = userRepository;
        this.dailyLoginActivityService = dailyLoginActivityService;
    }

  /* temporary comment
    @Override
    public void onAuthenticationSuccess(HttpServletRequest request,
                                        HttpServletResponse response,
                                        Authentication authentication) throws IOException, ServletException {

        if (authentication.getPrincipal() instanceof Saml2AuthenticatedPrincipal principal) {

            logger.info("=== SAML Authentication Success ===");
            logger.info("Principal Name: {}", principal.getName());
            logger.info("Registration ID: {}", principal.getRelyingPartyRegistrationId());

            logger.info("Available SAML Attributes:");
            principal.getAttributes().forEach((key, value) -> {
                logger.info("Attribute '{}': {}", key, value);
            });


            // Extract SAML attributes
            SamlUserAttributes userAttributes = extractUserAttributes(principal);
            logger.info("Extracted User Attributes: {}", userAttributes);


            // Create or update User
            User user = processUser(userAttributes);

            logger.info("Processed User: ID={}, Email={}, Username={}", user.getId(), user.getEmail(), user.getUserName());

            // Assign roles based on groups or default
            if (userAttributes.getGroups() != null && !userAttributes.getGroups().isEmpty()) {
                userService.updateUserRolesFromGroups(user, userAttributes.getGroups());
                logger.info("Updated user roles from groups: {}", userAttributes.getGroups());

            } else {
                userService.assignDefaultRole(user);
                logger.info("Assigned default role to user");

            }

            // Generate JWT token
            String jwtToken = jwtTokenProvider.generateToken(user);
            logger.info("Generated JWT token for user: {} with designation: {}", user.getEmail(), user.getDesignation());


            // Set JWT cookie
            cookieUtils.addJwtCookie(response, jwtToken);

            // Redirect to frontend
          //  response.sendRedirect("https://wafersedge-dev.digitide.com/dashboard?sso=success");
            String redirectUrl = "https://wafersedge-dev.digitide.com/?sso=success";
            logger.info("Redirecting to: {}", redirectUrl);
            response.sendRedirect(redirectUrl);
        }
    }

   */

   /* final work
    @Override
    public void onAuthenticationSuccess(HttpServletRequest request,
                                        HttpServletResponse response,
                                        Authentication authentication) throws IOException, ServletException {

        if (authentication.getPrincipal() instanceof Saml2AuthenticatedPrincipal principal) {
            logger.info("=== SAML Authentication Success ===");

            // Extract attributes directly
            SamlUserAttributes userAttributes = extractUserAttributes(principal);
            logger.info("Extracted User Attributes: {}", userAttributes);

            // 🔹 Instead of saving, just use attributes for JWT
            String jwtToken = jwtTokenProvider.generateToken(userAttributes);

            // Set JWT cookie
            cookieUtils.addJwtCookie(response, jwtToken);

            // Redirect to frontend with success flag
         //   String redirectUrl = "https://wafersedge-dev.digitide.com/?sso=success";
            String redirectUrl = "https://wafersedge-dev.digitide.com/";
            logger.info("Redirecting to: {}", redirectUrl);
            response.sendRedirect(redirectUrl);


            // (Optional) If you want to return JSON instead of redirect:
            // response.setContentType("application/json");
            // new ObjectMapper().writeValue(response.getWriter(), userAttributes);
        }
    }

    */

  /* check 1
    @Override
    public void onAuthenticationSuccess(HttpServletRequest request,
                                        HttpServletResponse response,
                                        Authentication authentication) throws IOException, ServletException {
        if (authentication.getPrincipal() instanceof Saml2AuthenticatedPrincipal principal) {
            logger.info("=== SAML Authentication Success ===");
            // Extract attributes directly
            SamlUserAttributes userAttributes = extractUserAttributes(principal);
            logger.info("Extracted User Attributes: {}", userAttributes);
            // 🔹 Instead of saving, just use attributes for JWT
            String jwtToken = jwtTokenProvider.generateToken(userAttributes);
            // Set JWT cookie
            cookieUtils.addJwtCookie(response, jwtToken);

            // 🔹 Append access token to the redirect URL
            String baseUrl = "https://wafersedge-dev.digitide.com/";
            String redirectUrl = baseUrl + "?token=" + URLEncoder.encode(jwtToken, "UTF-8");

            logger.info("Redirecting to: {}", redirectUrl);
            response.sendRedirect(redirectUrl);
        }
    }

   */
/* check2
    @Override
    public void onAuthenticationSuccess(HttpServletRequest request,
                                        HttpServletResponse response,
                                        Authentication authentication) throws IOException, ServletException {
        if (authentication.getPrincipal() instanceof Saml2AuthenticatedPrincipal principal) {
            logger.info("=== SAML Authentication Success ===");
            // Extract attributes directly
            SamlUserAttributes userAttributes = extractUserAttributes(principal);
            logger.info("Extracted User Attributes: {}", userAttributes);

            // Generate JWT token
            String jwtToken = jwtTokenProvider.generateToken(userAttributes);

            // Set JWT cookie (optional - you can keep this for automatic authentication)
            cookieUtils.addJwtCookie(response, jwtToken);

            // 🔹 Return JSON response with token and user attributes
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.setStatus(HttpServletResponse.SC_OK);

            // Add CORS headers if needed for cross-origin requests
            response.setHeader("Access-Control-Allow-Origin", "https://wafersedge-dev.digitide.com");
            response.setHeader("Access-Control-Allow-Credentials", "true");

            // Create response object with token and user attributes
            Map<String, Object> responseData = new HashMap<>();
            responseData.put("status", "success");
            responseData.put("message", "SAML authentication successful");
            responseData.put("access_token", jwtToken);
            responseData.put("token_type", "Bearer");
            responseData.put("user_attributes", userAttributes);

            // Optional: Add token expiry information
            // responseData.put("expires_in", 3600); // seconds
            // responseData.put("issued_at", System.currentTimeMillis());

            // Write JSON response
            ObjectMapper mapper = new ObjectMapper();
            mapper.writeValue(response.getWriter(), responseData);

            logger.info("Sent JSON response with access token and user attributes");
        }
    }

 */

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request,
                                        HttpServletResponse response,
                                        Authentication authentication) throws IOException, ServletException {
        if (authentication.getPrincipal() instanceof Saml2AuthenticatedPrincipal principal) {
            logger.info("=== SAML Authentication Success ===");

            // Extract attributes directly
            SamlUserAttributes userAttributes = extractUserAttributes(principal);
            logger.info("Extracted User Attributes: {}", userAttributes);

            String email = userAttributes.getEmail();

            if (email != null) {
                try {
                    dailyLoginActivityService.trackModuleLogin(email, userAttributes.getDesignation());
                    logger.info("Login activity stored for user {}", email);
                } catch (Exception e) {
                    logger.error("Failed to store login activity for user{}", email, e);
                }
            }

            // Generate JWT token
            String jwtToken = jwtTokenProvider.generateToken(userAttributes);

            // Set JWT cookie (optional - keeps session auth working)
            cookieUtils.addJwtCookie(response, jwtToken);

            // 🔹 Redirect with token as query param
           // String redirectUrl = "https://wafersedge-dev.digitide.com/?token=" + jwtToken;
            String redirectUrl = frontendUrl + "?token=" + jwtToken;

            logger.info("Redirecting to: {}", redirectUrl);
            response.sendRedirect(redirectUrl);
        }
    }

//    private SamlUserAttributes extractUserAttributes(Saml2AuthenticatedPrincipal principal) {
//        SamlUserAttributes attributes = new SamlUserAttributes();
//
//        //attributes.setEmail(getFirst(principal.getAttribute("email"), principal.getAttribute("mail")));
//        // Try email first, fallback to userPrincipalName, then employee_name
//        attributes.setEmail(getFirst(
//                principal.getAttribute("email"),
//                principal.getAttribute("mail"),
//                principal.getAttribute("userPrincipalName"),
//                principal.getAttribute("employee_name") // fallback
//        ));
//
//        attributes.setDisplayName(getFirst(principal.getAttribute("displayName"),
//                principal.getAttribute("employee_name"))); // fallback
//        attributes.setFirstName(getFirst(principal.getAttribute("givenName")));
//        attributes.setLastName(getFirst(principal.getAttribute("surname")));
//        attributes.setEmployeeId(getFirst(principal.getAttribute("employee_id")));
//        attributes.setDesignation(getFirst(principal.getAttribute("employee_designation")));
//        attributes.setPhone(getFirst(principal.getAttribute("telephoneNumber"), principal.getAttribute("phone")));
//        attributes.setGroups(principal.getAttribute("groups") != null
//                ? principal.getAttribute("groups").stream().map(Object::toString).toList()
//                : List.of());
//
//        return attributes;
//
//    }

    private SamlUserAttributes extractUserAttributes(Saml2AuthenticatedPrincipal principal) {
        SamlUserAttributes attributes = new SamlUserAttributes();

        // 🔹 Common Azure AD SAML attribute names
        attributes.setEmail(getFirst(
                principal.getAttribute("http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress"),
                principal.getAttribute("http://schemas.xmlsoap.org/ws/2005/05/identity/claims/upn"),
                principal.getAttribute("email"),
                principal.getAttribute("mail"),
                principal.getAttribute("userPrincipalName")
        ));

        attributes.setDisplayName(getFirst(
                principal.getAttribute("http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"),
                principal.getAttribute("http://schemas.microsoft.com/identity/claims/displayname"),
                principal.getAttribute("displayName"),
                principal.getAttribute("name")
        ));

        attributes.setFirstName(getFirst(
                principal.getAttribute("http://schemas.xmlsoap.org/ws/2005/05/identity/claims/givenname"),
                principal.getAttribute("givenName"),
                principal.getAttribute("firstName")
        ));

        attributes.setLastName(getFirst(
                principal.getAttribute("http://schemas.xmlsoap.org/ws/2005/05/identity/claims/surname"),
                principal.getAttribute("surname"),
                principal.getAttribute("lastName")
        ));

        attributes.setEmployeeId(getFirst(
                principal.getAttribute("http://schemas.microsoft.com/identity/claims/employeeid"),
                principal.getAttribute("employeeId"),
                principal.getAttribute("employee_id")
        ));

//        attributes.setDesignation(getFirst(
//                principal.getAttribute("http://schemas.microsoft.com/identity/claims/jobtitle"),
//                principal.getAttribute("jobTitle"),
//                principal.getAttribute("title"),
//                principal.getAttribute("designation")
//        ));

        attributes.setDesignation(getFirst(
                principal.getAttribute("http://schemas.xmlsoap.org/ws/2005/05/identity/claims/Employee Designation"),
                principal.getAttribute("http://schemas.microsoft.com/identity/claims/jobtitle"),
                principal.getAttribute("jobTitle"),
                principal.getAttribute("title"),
                principal.getAttribute("designation")
        ));


        attributes.setPhone(getFirst(
                principal.getAttribute("http://schemas.xmlsoap.org/ws/2005/05/identity/claims/mobilephone"),
                principal.getAttribute("http://schemas.xmlsoap.org/ws/2005/05/identity/claims/homephone"),
                principal.getAttribute("telephoneNumber"),
                principal.getAttribute("phone"),
                principal.getAttribute("mobile")
        ));

        // Handle groups - Azure AD typically sends groups as a multi-value attribute
        List<Object> groupsAttribute = principal.getAttribute("http://schemas.microsoft.com/ws/2008/06/identity/claims/groups");
        if (groupsAttribute == null) {
            groupsAttribute = principal.getAttribute("groups");
        }
        if (groupsAttribute == null) {
            groupsAttribute = principal.getAttribute("http://schemas.xmlsoap.org/claims/Group");
        }

        if (groupsAttribute != null && !groupsAttribute.isEmpty()) {
            attributes.setGroups(groupsAttribute.stream().map(Object::toString).toList());
        } else {
            attributes.setGroups(List.of());
        }

        // 🔹 Log what we extracted
        logger.info("Extracted attributes - Email: {}, DisplayName: {}, FirstName: {}, LastName: {}, EmployeeId: {}, Groups: {}",
                attributes.getEmail(), attributes.getDisplayName(), attributes.getFirstName(),
                attributes.getLastName(), attributes.getEmployeeId(), attributes.getGroups());

        return attributes;
    }


    private String getFirst(List<Object>... lists) {
        for (List<Object> list : lists) {
            if (list != null && !list.isEmpty() && list.get(0) != null) {
                return list.get(0).toString();
            }
        }
        return null;
    }

    private User processUser(SamlUserAttributes attributes) {
        // Use employee_name as identifier if email is missing
        String identifier = attributes.getEmail();
        if (identifier == null) {
            identifier = attributes.getDisplayName(); // fallback
        }

        if (identifier == null) {
            // Last resort: generate a temporary identifier or handle as guest
            identifier = "user_" + System.currentTimeMillis();
        }

        Optional<User> existingUser = Optional.empty();
        if (attributes.getEmail() != null) {
            existingUser = userRepository.findByEmail(attributes.getEmail());
        }
        User user;

        if (existingUser.isPresent()) {
            user = existingUser.get();
            user.setUserName(attributes.getDisplayName() != null ? attributes.getDisplayName() : user.getUserName());
            user.setEmployeeId(attributes.getEmployeeId() != null ? attributes.getEmployeeId() : user.getEmployeeId());
            user.setDesignation(attributes.getDesignation() != null ? attributes.getDesignation() : user.getDesignation()); // 🔹 add this

        } else {
            user = new User();
            user.setEmail(attributes.getEmail());
            user.setUserName(attributes.getDisplayName());
            user.setEmployeeId(attributes.getEmployeeId());
            user.setDesignation(attributes.getDesignation()); // 🔹 add this
            userRepository.save(user);
        }

        return userRepository.save(user);
       // return user;
    }
}
