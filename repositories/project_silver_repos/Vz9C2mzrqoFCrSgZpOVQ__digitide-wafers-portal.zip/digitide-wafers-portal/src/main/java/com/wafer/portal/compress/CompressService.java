package com.wafer.portal.compress;

import com.googlecode.pngtastic.core.PngImage;
import com.googlecode.pngtastic.core.PngOptimizer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;

@Service
public class CompressService {

    private static final Logger logger = LoggerFactory.getLogger(CompressService.class);

    CompressService(){}

    public byte[] compressImage(MultipartFile file) throws IOException {

        logger.info("This is inside compress image function");

        String contentType = file.getContentType();

        if (contentType == null) {
            throw new IOException("Content type is null.");
        }

        if (contentType.equalsIgnoreCase("image/png")) {
            logger.info("This is inside png compress function");
            return compressPng(file.getInputStream());

        }

        if (contentType.equalsIgnoreCase("image/jpeg") ||
                contentType.equalsIgnoreCase("image/jpg")) {
            return compressJpeg(file.getInputStream());
        }

        throw new UnsupportedOperationException("Unsupported image type: " + contentType);
    }

    // ---------------- JPEG --------------------

    public byte[] compressJpeg(InputStream inputStream) throws IOException {

        BufferedImage image = ImageIO.read(inputStream);

        if (image == null)
            throw new IOException("Failed to decode JPEG image.");

        ByteArrayOutputStream output = new ByteArrayOutputStream();

        ImageWriter writer = ImageIO.getImageWritersByFormatName("jpeg").next();
        ImageWriteParam param = writer.getDefaultWriteParam();

        param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
        param.setCompressionQuality(0.10f);

        writer.setOutput(ImageIO.createImageOutputStream(output));
        writer.write(null, new IIOImage(image, null, null), param);
        writer.dispose();

        return output.toByteArray();
    }


    // ---------------- PNG → WebP --------------------

    public byte[] compressPng(InputStream inputStream) throws IOException {

        // Load PNG
        PngImage inputImage = new PngImage(inputStream);

        // Optimize PNG
        PngOptimizer optimizer = new PngOptimizer();

        PngImage optimized = optimizer.optimize(inputImage);

        // Write optimized PNG into a byte array
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream();
             DataOutputStream dos = new DataOutputStream(baos)) {

            optimized.writeDataOutputStream(dos);
            dos.flush();

            return baos.toByteArray();
        }

    }
}

