package com.wafer.portal.model;

import com.wafer.portal.audit.Auditable;
import jakarta.persistence.*;

import java.io.Serializable;
import java.time.LocalDateTime;

@Entity
@Table(name = "surveys")
public class Survey extends Auditable<String> implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String surveyTitle;

    private String estimatedTime;

    private String image;

    private String urlLink;

    private String description;

    @Column(name = "ended_at")
    private LocalDateTime endedAt;

    @Column(name = "is_ended", nullable = false)
    private boolean isEnded = false;

    @Column(name = "is_deleted", nullable = false)
    private boolean isDeleted = false;

    @Column(name = "survey_status", nullable = false)
    private boolean surveyStatus = false;

    public Survey() {
    }

    public Survey(String surveyTitle, String estimatedTime, String image, String urlLink, String description) {
        this.surveyTitle = surveyTitle;
        this.estimatedTime = estimatedTime;
        this.image = image;
        this.urlLink = urlLink;
        this.description = description;
        this.isDeleted = false;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSurveyTitle() {
        return surveyTitle;
    }

    public void setSurveyTitle(String surveyTitle) {
        this.surveyTitle = surveyTitle;
    }

    public String getEstimatedTime() {
        return estimatedTime;
    }

    public void setEstimatedTime(String estimatedTime) {
        this.estimatedTime = estimatedTime;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getUrlLink() {
        return urlLink;
    }

    public void setUrlLink(String urlLink) {
        this.urlLink = urlLink;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDateTime getEndedAt() {
        return endedAt;
    }

    public void setEndedAt(LocalDateTime endedAt) {
        this.endedAt = endedAt;
    }

    public boolean isEnded() {
        return isEnded;
    }

    public void setEnded(boolean ended) {
        isEnded = ended;
    }

    public boolean isDeleted() {
        return isDeleted;
    }

    public void setDeleted(boolean deleted) {
        isDeleted = deleted;
    }

    public boolean isSurveyStatus() {
        return surveyStatus;
    }

    public void setSurveyStatus(boolean surveyStatus) {
        this.surveyStatus = surveyStatus;
    }
}

