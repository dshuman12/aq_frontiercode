package com.wafer.portal.dto;


public class UserLoginFrequencyDTO {

    private String userEmail;
    private String designation;
    private Long loginCount;


    public UserLoginFrequencyDTO(String userEmail, String designation, Long loginCount) {
        this.userEmail = userEmail;
        this.designation = designation;
        this.loginCount = loginCount;
    }


    public String getUserEmail() { return userEmail; }
    public String getDesignation() { return designation; }
    public Long getLoginCount() { return loginCount; }
}
