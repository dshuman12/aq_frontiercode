package com.wafer.portal.config;

import com.wafer.portal.constants.Constants;
import com.wafer.portal.repository.UserRepository;
import com.wafer.portal.service.CustomUserDetailsService;
import com.wafer.portal.service.DailyLoginActivityService;
import com.wafer.portal.service.UserService;
import com.wafer.portal.utils.CookieUtils;

// import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
// import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.core.GrantedAuthorityDefaults;
// import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
// import org.springframework.security.web.authentication.HttpStatusEntryPoint;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;

import java.util.List;

import static org.springframework.security.config.http.SessionCreationPolicy.STATELESS;

//
//@Configuration
//@EnableWebSecurity
//public class JwtSecurityConfig {
//
//    @Value("${app.domain-url}")
//    private String domainUrl;
//
//    @Value("${app.domain-feurl}")
//    private String feDomainUrl;
//
//    @Value("${app.base-url}")
//    private String baseUrl;
//
//    private final CustomUserDetailsService userDetailsService;
//    private final JwtAuthEntryPoint unauthorizedHandler;
//    private final JwtTokenProvider jwtTokenProvider;
//    private final CookieUtils cookieUtils;
//
//    public JwtSecurityConfig(CustomUserDetailsService userDetailsService,
//                             JwtAuthEntryPoint unauthorizedHandler,
//                             JwtTokenProvider jwtTokenProvider,
//                             CookieUtils cookieUtils) {
//        this.userDetailsService = userDetailsService;
//        this.unauthorizedHandler = unauthorizedHandler;
//        this.jwtTokenProvider = jwtTokenProvider;
//        this.cookieUtils = cookieUtils;
//    }
//
//    @Bean
//    public PasswordEncoder passwordEncoder() {
//        return new BCryptPasswordEncoder();
//    }
//
//    @Bean
//    public DaoAuthenticationProvider authenticationProvider() {
//        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
//        authProvider.setUserDetailsService(userDetailsService);
//        authProvider.setPasswordEncoder(passwordEncoder());
//        return authProvider;
//    }
//
//    @Bean
//    public AuthenticationManager authenticationManager(AuthenticationConfiguration authConfig) throws Exception {
//        return authConfig.getAuthenticationManager();
//    }
//
//    @Bean
//    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
//        http.csrf(AbstractHttpConfigurer::disable)
//                .cors(cors -> cors.configurationSource(request -> {
//                    var corsConfig = new org.springframework.web.cors.CorsConfiguration();
//                    corsConfig.setAllowedOrigins(List.of(feDomainUrl, domainUrl, Constants.FE_LOCAL_URL));
//                    corsConfig.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));
//                    corsConfig.setAllowedHeaders(List.of("*"));
//                    corsConfig.setAllowCredentials(true);
//                    return corsConfig;
//                }))
//                .authorizeHttpRequests(request -> request
//                                .requestMatchers(
//                                        "/swagger-ui/**",
//                                        "/v3/api-docs/**",
//                                        "/api/v1/top-news/upload"
//                                        //"/api/v1/**"
//                                ).permitAll()
////                        .anyRequest().authenticated()
//                                .anyRequest().permitAll()
//                )
//
//                .sessionManagement(manager -> manager.sessionCreationPolicy(STATELESS))
//                .exceptionHandling(ex -> ex.authenticationEntryPoint(unauthorizedHandler)) // Use your custom entry point
//                .authenticationProvider(authenticationProvider())
//                .addFilterBefore(authenticationJwtTokenFilter(), UsernamePasswordAuthenticationFilter.class);
//
//        return http.build();
//    }
//
//    @Bean
//    public JwtAuthFilter authenticationJwtTokenFilter() {
//        return new JwtAuthFilter(jwtTokenProvider, userDetailsService, cookieUtils);
//    }
//
//    @Bean
//    public GrantedAuthorityDefaults grantedAuthorityDefaults() {
//        return new GrantedAuthorityDefaults("");
//    }
//
//
//}



@Configuration
@EnableWebSecurity
public class JwtSecurityConfig {

    @Value("${app.domain-url}")
    private String domainUrl;

    @Value("${app.domain-feurl}")
    private String feDomainUrl;

    @Value("${app.base-url}")
    private String baseUrl;

    private final CustomUserDetailsService userDetailsService;
    private final JwtAuthEntryPoint unauthorizedHandler;
    private final JwtTokenProvider jwtTokenProvider;
    private final CookieUtils cookieUtils;
    private final UserService userService;
    private final UserRepository userRepository;
    private final DailyLoginActivityService dailyLoginActivityService;


    public JwtSecurityConfig(CustomUserDetailsService userDetailsService,
                             JwtAuthEntryPoint unauthorizedHandler,
                             JwtTokenProvider jwtTokenProvider,
                             CookieUtils cookieUtils, UserService userService, UserRepository userRepository, DailyLoginActivityService dailyLoginActivityService) {
        this.userDetailsService = userDetailsService;
        this.unauthorizedHandler = unauthorizedHandler;
        this.jwtTokenProvider = jwtTokenProvider;
        this.cookieUtils = cookieUtils;
        this.userService = userService;
        this.userRepository = userRepository;
        this.dailyLoginActivityService = dailyLoginActivityService;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public DaoAuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
        authProvider.setUserDetailsService(userDetailsService);
        authProvider.setPasswordEncoder(passwordEncoder());
        return authProvider;
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authConfig) throws Exception {
        return authConfig.getAuthenticationManager();
    }

//    @Bean
//    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
//        http.csrf(AbstractHttpConfigurer::disable)
//                .cors(cors -> cors.configurationSource(request -> {
//                    var corsConfig = new org.springframework.web.cors.CorsConfiguration();
//                    corsConfig.setAllowedOrigins(List.of(feDomainUrl, domainUrl, Constants.FE_LOCAL_URL));
//                    corsConfig.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));
//                    corsConfig.setAllowedHeaders(List.of("*"));
//                    corsConfig.setAllowCredentials(true);
//                    return corsConfig;
//                }))
//                .authorizeHttpRequests(request -> request
//                                .requestMatchers(
//                                        "/swagger-ui/**",
//                                        "/v3/api-docs/**",
//                                        "/api/v1/**"
//                                ).permitAll()
    ////                        .anyRequest().authenticated()
//                                .anyRequest().permitAll()
//                )
//
//                .sessionManagement(manager -> manager.sessionCreationPolicy(STATELESS))
//                .exceptionHandling(ex -> ex.authenticationEntryPoint(unauthorizedHandler)) // Use your custom entry point
//                .authenticationProvider(authenticationProvider())
//                .addFilterBefore(authenticationJwtTokenFilter(), UsernamePasswordAuthenticationFilter.class);
//
//        return http.build();
//    }


//@Bean
//public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
//    http.csrf(AbstractHttpConfigurer::disable)
//            .cors(cors -> cors.configurationSource(request -> {
//                var corsConfig = new org.springframework.web.cors.CorsConfiguration();
//                corsConfig.setAllowedOrigins(List.of(feDomainUrl, domainUrl, Constants.FE_LOCAL_URL));
//                corsConfig.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));
//                corsConfig.setAllowedHeaders(List.of("*"));
//                corsConfig.setAllowCredentials(true);
//                return corsConfig;
//            }))
//            .authorizeHttpRequests(request -> request
//                    .requestMatchers(
//                            "/swagger-ui/**",
//                            "/v3/api-docs/**",
//                            "/api/v1/**"
//                           // "/saml2/**"          // allow SAML endpoints
//                         //   "/login/saml2/**"      // allow SAML login
//                    ).permitAll()
//                    .anyRequest().authenticated()
//            )
//            // 🔹 Enable SAML login
//            .saml2Login(saml -> saml
//                    .defaultSuccessUrl("https://wafersedge-dev.digitide.com/", true) // redirect to external URL
//                    .failureUrl("/login?error=true")
//            )
//            .sessionManagement(manager -> manager.sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED))
//            .exceptionHandling(ex -> ex.authenticationEntryPoint(unauthorizedHandler))
//            .authenticationProvider(authenticationProvider())
//            .addFilterBefore(authenticationJwtTokenFilter(), UsernamePasswordAuthenticationFilter.class);
//
//    return http.build();
//}

    /*
    //temporary comment-final one

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.csrf(csrf -> csrf
                        .ignoringRequestMatchers("/saml2/**", "/login/saml2/**" ,"/api/v1/auth/add-user","/api/v1/auth/get-users","/api/v1/auth/users/{userId}/roles","/api/v1/auth/{userId}","/api/v1/events/{id}" // Add this specific endpoint
                        ) // Disable CSRF for SAML endpoints
                )
                .cors(cors -> cors.configurationSource(request -> {
                    CorsConfiguration corsConfig = new CorsConfiguration();

                    // Allow all origins
                    corsConfig.setAllowedOriginPatterns(List.of("*"));

                    // Allow all HTTP methods including OPTIONS (important for CORS preflight)
                    corsConfig.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS", "HEAD"));


                    // Allow all headers
                    corsConfig.setAllowedHeaders(List.of("*"));

                    // Allow credentials (important for SAML)
                    corsConfig.setAllowCredentials(true);

                    // Cache preflight response for 1 hour
                   corsConfig.setMaxAge(3600L);

                    return corsConfig;
                }))
                .authorizeHttpRequests(request -> request
                        .requestMatchers(
                                "/swagger-ui/**",
                                "/v3/api-docs/**",
                              "/api/v1/auth/get-roles",
                              "/api/v1/auth/get-users",
                              "/api/v1/auth/add-user",
                                "/api/v1/auth/users/{userId}/roles",
                                "/api/v1/auth/{userId}",
                              "/api/v1/events/{id}",
                              //  "/api/v1/**",
                                "/saml2/**",           // Allow SAML metadata and authentication endpoints
                                "/login/saml2/**",     // Allow SAML login endpoints
                                "/saml/**"             // Allow custom SAML endpoints if any
                        ).permitAll()
                        .requestMatchers("/api/v1/user/profile").authenticated()   // requires authentication
                        .requestMatchers("/api/v1/people/upload").authenticated()   // requires authentication

                        .anyRequest().authenticated()
                )
                // Enable SAML login
//            .saml2Login(saml -> saml
//                    .defaultSuccessUrl("https://wafersedge-dev.digitide.com/", true)
//                    .failureUrl("/login?error=true")
//            )
                .saml2Login(saml -> saml
                        .successHandler(samlAuthenticationSuccessHandler()) // Use custom success handler
                        .failureUrl("/login?error=true")
                )
                // Use NEVER for session creation to avoid conflicts between JWT and SAML
               // .sessionManagement(manager -> manager.sessionCreationPolicy(SessionCreationPolicy.NEVER))
                .sessionManagement(manager -> manager.sessionCreationPolicy(SessionCreationPolicy.STATELESS))

                .exceptionHandling(ex -> ex.authenticationEntryPoint(unauthorizedHandler))
                .authenticationProvider(authenticationProvider())
                .addFilterBefore(authenticationJwtTokenFilter(), UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

     */

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                // ----------------- CSRF -----------------
                .csrf(csrf -> csrf
                        // Ignore CSRF for stateless endpoints (JWT APIs) and SAML endpoints
                        .ignoringRequestMatchers(
                                "/saml2/**",
                                "/login/saml2/**",
                                "/api/v1/auth/add-user",
                                "/api/v1/auth/get-users",
                                "/api/v1/auth/users/{userId}/roles",
                                "/api/v1/auth/{userId}",
                                "/api/v1/auth/get-roles",
                                //"/api/v1/events/{id}",
                                "/api/v1/people/upload", // <-- Added for your upload endpoint
                                "/api/v1/video/upload",
                                "/api/v1/video/all",
                                "/api/v1/video/{id}",  //get
                                "/api/v1/video/{id}", //put
                                "/api/v1/video/{id}", //delete
                                "/api/v1/top-news/upload",
                                "/api/v1/top-news/{id}", //put
                                "/api/v1/top-news/{id}", //get
                                "/api/v1/top-news/{id}", //delete
                                "/api/v1/top-news/all",
                                "/api/v1/spotlight/upload",
                                "/api/v1/spotlight/all",
                                "/api/v1/spotlight/{id}", //get
                                "/api/v1/spotlight/{id}", //put
                                "/api/v1/spotlight/{id}", //delete
                                "/api/v1/people/all",
                                "/api/v1/people/{id}", //get
                                "/api/v1/people/{id}", //put
                                "/api/v1/people/{id}", //delete
                                "/api/v1/milestone/upload",
                                "/api/v1/milestone/all",
                                "/api/v1/milestone/{id}", //get
                                "/api/v1/milestone/{id}", //put
                                "/api/v1/milestone/{id}" ,//delete
                                "/api/v1/events/upload",
                                "/api/v1/events/employee/all",
                                "/api/v1/events/all",
                                "/api/v1/events/admin/all",
                                "/api/v1/events/{id}", //get
                                "/api/v1/events/{id}", //put
                                "/api/v1/events/{id}", //delete
                                "/api/v1/documents/upload",
                                "/api/v1/documents/all",
                                "/api/v1/documents/{id}", //get
                                "/api/v1/documents/{id}", //put
                                "/api/v1/documents/{id}", //delete
                                "/api/v1/announcement/upload",
                                "/api/v1/announcement/all",
                                "/api/v1/announcement/{id}", //get
                                "/api/v1/announcement/{id}", //put
                                "/api/v1/announcement/{id}", //delete
                                "/api/v1/all-news/upload",
                                "/api/v1/all-news/all",
                                "/api/v1/all-news/{id}", //get
                                "/api/v1/all-news/{id}", //put
                                "/api/v1/all-news/{id}",  //delete
                                "/api/v1/document-title/all",
                                "/api/v1/auth/logout",
                                "/api/v2/pic-of-the-day",
                                "/api/v2/pic-of-the-day/upload",
                                "/api/v2/pic-of-the-day/update",
                                "/api/v2/leadership",
                                "/api/v2/leadership/upload",
                                "/api/v2/leadership/all",
                                "/api/v2/leadership/{id}", //get
                                "/api/v2/leadership/{id}", //put
                                "/api/v2/leadership/{id}", //delete
                                "/api/v2/company-info",
                                "/api/v2/company-info/upload",
                                "/api/v2/company-info/all",
                                "/api/v2/company-info/{id}", //get
                                "/api/v2/company-info/{id}", //put
                                "/api/v2/company-info/{id}", //delete
                                "/api/v2/awards-and-recognition",
                                "/api/v2/awards-and-recognition/upload",
                                "/api/v2/awards-and-recognition/all",
                                "/api/v2/awards-and-recognition/{id}",
                                "/api/v2/awards-and-recognition/{id}",
                                "/api/v2/awards-and-recognition/{id}",
                                "/api/v2/mood",
                                "/api/v2/mood/history",
                                "/api/v2/mood/all-history",
                                "/api/v2/mood-of-the-day",
                                "/api/v2/marquee-headline/save",
                                "/api/v2/marquee-headline/{id}",
                                "/api/v2/marquee-headline/{id}",
                                "/api/v2/marquee-headline",
                                "/api/v2/quick-links",
                                "/api/v2/quick-links/upload",
                                "/api/v2/quick-links/all",
                                "/api/v2/quick-links/{id}",
                                "/api/v2/quick-links/{id}",
                                "/api/v2/quick-links/{id}",
                                "/api/v1/surveys",
                                "/api/v1/surveys/upload",
                                "/api/v1/surveys/all",
                                "/api/v1/surveys/{id}",
                                "/api/v1/surveys/{id}",
                                "/api/v1/surveys/{id}/end",
                                "/api/v1/surveys/{id}",
                                "/api/v1/surveys/{id}/status",
                                "/api/v1/surveys/{id}",
                                "/api/v2/quick-links-header",
                                "/api/v2/quick-links-header/upload",
                                "/api/v2/quick-links-header/{id}",
                                "/api/v2/quick-links-header/{id}",
                                "/api/v2/quick-links-header/{id}",
                                "/api/v2/quick-links-header/all",
                                "/api/v2/quick-link-sub-header",
                                "/api/v2/quick-link-sub-header/upload",
                                "/api/v2/quick-link-sub-header/{id}",
                                "/api/v2/quick-link-sub-header/{id}",
                                "/api/v2/quick-link-sub-header/{id}",
                                "/api/v2/quick-link-sub-header/all",
                                "/api/v2/search", // global search
                                "/api/v2/quick-link-sub-header/all",
                                "/api/v2/feedback",
                                "/api/v2/feedback/upload",
                                "/api/v2/feedback/{id}",
                                "/api/v2/feedback/{id}",
                                "/api/v2/feedback/{id}",
                                "/api/v2/feedback/all",
                                "/api/v2/feedback/all/history",
                                "/api/v2/document-center",
                                "/api/v2/document-center/create",
                                "/api/v2/document-center/allSectionDocuments",
                                "/api/v2/document-center/all",
                                "/api/v2/document-center/{id}",
                                "/api/v2/document-center/{id}",
                                "/api/v2/document-center/{id}",
                                "/api/v2/document-center/addSection",
                                "/api/v2/document-center/allSections",
                                "/api/v2/document-center/deleteSection/{id}",
                                "/api/v2/rewards-and-recognition/create",
                                "/api/v2/rewards-and-recognition/all",
                                "/api/v2/rewards-and-recognition/{id}",
                                "/api/v2/rewards-and-recognition/{id}",
                                "/api/v2/rewards-and-recognition/{id}",
                                "/api/v2/coffee-with-leaders/upload",
                                "/api/v2/coffee-with-leaders/all",
                                "/api/v2/coffee-with-leaders/{id}",
                                "/api/v2/coffee-with-leaders/{id}",
                                "/api/v2/coffee-with-leaders/{id}",
                                "/api/v2/employee-newsletter/upload",
                                "/api/v2/employee-newsletter/all",
                                "/api/v2/employee-newsletter/{id}",
                                "/api/v2/employee-newsletter/{id}",
                                "/api/v2/employee-newsletter/{id}",
                                "/api/v2/brand-guidelines",
                                "/api/v2/brand-guidelines/upload",
                                "/api/v2/brand-guidelines/all",
                                "/api/v2/brand-guidelines/{id}",
                                "/api/v2/brand-guidelines/{id}",
                                "/api/v2/brand-guidelines/{id}",
                                "/api/v2/brand-guidelines/deleteSection/{id}",
                                "/api/v2/help-and-support/upload",
                                "/api/v2/help-and-support/all",
                                "/api/v2/help-and-support/{id}",
                                "/api/v2/help-and-support/{id}",
                                "/api/v2/help-and-support/{id}",
                                "/api/v2/rewards-and-recognition/allSectionDocuments",
                                "/api/v2/rewards-and-recognition/addSection",
                                "/api/v2/rewards-and-recognition/allSections",
                                "/api/v2/rewards-and-recognition/deleteSection/{id}",
                                "/api/v2/rewards-and-recognition/addSubsection",
                                "/api/v2/rewards-and-recognition/allSubSection",
                                "/api/v2/rewards-and-recognition/deleteSubsection/{id}",
                                "/api/v2/rewards-and-recognition/updateSection/{id}",
                                "/api/v2/rewards-and-recognition/updateSubsection/{id}",
                                "/api/v2/document-center/updateSection/{id}",
                                "/api/v2/audit/changes",
                                "/api/v2/audit/filter",
                                "/api/v2/audit/{id}",
                                "/api/v2/dashboard/track/{moduleId}",
                                "/api/v2/dashboard/usage",
                                "/api/v2/dashboard/modules/active",
                                "/api/v2/dashboard/module/{parent_id}",
                                "api/v2/dashboard/module-breakdown",
                                "api/v2/dashboard/monthly-trend",
                                "api/v2/dashboard/deep-dive",
                                "api/v2/dashboard/time-based-clicks",
                                "api/v2/dashboard/header",
                                "api/v2/dashboard/engagement-trend",
                                "/api/v2/dashboard/login-analytics",
                                "/api/v2/dashboard/mood-percentage",
                                "/api/v2/dashboard/monthly-unique-users",
                                "/api/v2/dashboard/device-browser-breakdown",
                                "/api/v2/dashboard/system-uptime",
                                "/api/v2/dashboard/full",
                                "/api/v2/dashboard/designation-logins",
                                "/api/v2/dashboard/search-analytics",
                                "/api/v2/dashboard/top-searches",
                                "api/v2/login-activity/login-analytics",
                                "api/v2/performance/page-load",
                                "api/v2/performance/tracking/{trackingId}",
                                "api/v2/performance/api",
                                "api/v2/performance/range",
                                "api/v2/performance/summary",
                                "api/v2/performance/monthly",
                                "api/v2/performance/all",
                                "api/v2/performance/device/{deviceType}",
                                "api/v2/performance/browser/{browser}",
                                "/api/v2/system-uptime/create",
                                "/api/v2/system-uptime/all",
                                "/api/v2/system-uptime/uptime/{date}",
                                "/api/v2/system-uptime/{id}",
                                "/api/v2/search-analytics/search/click/{id}",
                                "/api/v2/login-activity/login-analytics",
                                "/api/v2/login-activity/unique-visitors",
                                "/api/v2/login-activity/dau",
                                "/api/v2/login-activity/wau",
                                "/api/v2/login-activity/mau",
                                "/api/v2/login-activity/returning-users",
                                "/api/v2/login-activity/new-users",
                                "/api/v2/login-activity/avg-login-per-user"


                                )
                )

                // ----------------- CORS -----------------
                .cors(cors -> cors.configurationSource(request -> {
                    CorsConfiguration corsConfig = new CorsConfiguration();
                    corsConfig.setAllowedOriginPatterns(List.of("*")); // Allow all origins
                    corsConfig.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS", "HEAD"));
                    corsConfig.setAllowedHeaders(List.of("*"));          // Allow all headers
                    corsConfig.setAllowCredentials(true);               // Important for SAML
                    corsConfig.setMaxAge(3600L);                        // Cache preflight for 1 hour
                    return corsConfig;
                }))

                // ----------------- Authorization -----------------
                .authorizeHttpRequests(auth -> auth
                        // Public endpoints
                        .requestMatchers(
                                "/swagger-ui/**",
                                "/v3/api-docs/**",
                               // "/api/v1/auth/get-roles",
                               // "/api/v1/auth/get-users",
                               // "/api/v1/auth/add-user",
                               // "/api/v1/auth/users/{userId}/roles",
                               // "/api/v1/auth/{userId}",
                              //  "/api/v1/events/{id}",
                                "/saml2/**",
                                "/login/saml2/**",
                                "/saml/**"
                        ).permitAll()

                        // Secured endpoints
                        .requestMatchers(
                                "/api/v1/user/profile",
                                "/api/v1/people/upload",
                                "/api/v1/video/upload",
                                "/api/v1/video/all",
                                "/api/v1/video/{id}",  //get
                                "/api/v1/video/{id}", //put
                                "/api/v1/video/{id}", //delete
                                "/api/v1/top-news/upload",
                                "/api/v1/top-news/{id}", //put
                                "/api/v1/top-news/{id}", //get
                                "/api/v1/top-news/{id}", //delete
                                "/api/v1/top-news/all",
                                "/api/v1/spotlight/upload",
                                "/api/v1/spotlight/all",
                                "/api/v1/spotlight/{id}", //get
                                "/api/v1/spotlight/{id}", //put
                                "/api/v1/spotlight/{id}", //delete
                                "/api/v1/people/all",
                                "/api/v1/people/{id}", //get
                                "/api/v1/people/{id}", //put
                                "/api/v1/people/{id}", //delete
                                "/api/v1/milestone/upload",
                                "/api/v1/milestone/all",
                                "/api/v1/milestone/{id}", //get
                                "/api/v1/milestone/{id}", //put
                                "/api/v1/milestone/{id}",//delete
                                "/api/v1/events/upload",
                                "/api/v1/events/employee/all",
                                "/api/v1/events/all",
                                "/api/v1/events/admin/all",
                                "/api/v1/events/{id}", //get
                                "/api/v1/events/{id}", //put
                                "/api/v1/events/{id}", //delete
                                "/api/v1/documents/upload",
                                "/api/v1/documents/all",
                                "/api/v1/documents/{id}", //get
                                "/api/v1/documents/{id}", //put
                                "/api/v1/documents/{id}", //delete
                                "/api/v1/auth/add-user",
                                "/api/v1/auth/get-users",
                                "/api/v1/auth/users/{userId}/roles",
                                "/api/v1/auth/{userId}",
                                "/api/v1/auth/get-roles",
                                "/api/v1/announcement/upload",
                                "/api/v1/announcement/all",
                                "/api/v1/announcement/{id}", //get
                                "/api/v1/announcement/{id}", //put
                                "/api/v1/announcement/{id}", //delete
                                "/api/v1/all-news/upload",
                                "/api/v1/all-news/all",
                                "/api/v1/all-news/{id}", //get
                                "/api/v1/all-news/{id}", //put
                                "/api/v1/all-news/{id}",  //delete
                                "/api/v1/document-title/all",
                                "/api/v1/auth/logout",
                                "/api/v2/pic-of-the-day",
                                "/api/v2/pic-of-the-day/upload",
                                "/api/v2/pic-of-the-day/update",
                                "/api/v2/leadership",
                                "/api/v2/leadership/upload",
                                "/api/v2/leadership/all",
                                "/api/v2/leadership/{id}", //get
                                "/api/v2/leadership/{id}", //put
                                "/api/v2/leadership/{id}", //delete
                                "/api/v2/company-info",
                                "/api/v2/company-info/upload",
                                "/api/v2/company-info/all",
                                "/api/v2/company-info/{id}", //get
                                "/api/v2/company-info/{id}", //put
                                "/api/v2/company-info/{id}", //delete
                                "/api/v2/awards-and-recognition",
                                "/api/v2/awards-and-recognition/upload",
                                "/api/v2/awards-and-recognition/all",
                                "/api/v2/awards-and-recognition/{id}",
                                "/api/v2/awards-and-recognition/{id}",
                                "/api/v2/awards-and-recognition/{id}",
                                "/api/v2/mood",
                                "/api/v2/mood/history",
                                "/api/v2/mood/all-history",
                                "/api/v2/mood-of-the-day",
                                "/api/v2/marquee-headline/save",
                                "/api/v2/marquee-headline/{id}",
                                "/api/v2/marquee-headline/{id}",
                                "/api/v2/marquee-headline",
                                "/api/v2/quick-links",
                                "/api/v2/quick-links/upload",
                                "/api/v2/quick-links/all",
                                "/api/v2/quick-links/{id}",
                                "/api/v2/quick-links/{id}",
                                "/api/v2/quick-links/{id}",
                                "/api/v1/surveys",
                                "/api/v1/surveys/upload",
                                "/api/v1/surveys/all",
                                "/api/v1/surveys/{id}",
                                "/api/v1/surveys/{id}",
                                "/api/v1/surveys/{id}/end",
                                "/api/v1/surveys/{id}",
                                "/api/v1/surveys/{id}/status",
                                "/api/v1/surveys/{id}",
                                "/api/v2/quick-links-header",
                                "/api/v2/quick-links-header/upload",
                                "/api/v2/quick-links-header/{id}",
                                "/api/v2/quick-links-header/{id}",
                                "/api/v2/quick-links-header/{id}",
                                "/api/v2/quick-links-header/all",
                                "/api/v2/quick-link-sub-header",
                                "/api/v2/quick-link-sub-header/upload",
                                "/api/v2/quick-link-sub-header/{id}",
                                "/api/v2/quick-link-sub-header/{id}",
                                "/api/v2/quick-link-sub-header/{id}",
                                "/api/v2/quick-link-sub-header/all",
                                "/api/v2/search", //global search
                                "/api/v2/quick-link-sub-header/all",
                                "/api/v2/feedback",
                                "/api/v2/feedback/upload",
                                "/api/v2/feedback/{id}",
                                "/api/v2/feedback/{id}",
                                "/api/v2/feedback/{id}",
                                "/api/v2/feedback/all",
                                "/api/v2/feedback/all/history",
                                "/api/v2/document-center",
                                "/api/v2/document-center/create",
                                "/api/v2/document-center/allSectionDocuments",
                                "/api/v2/document-center/all",
                                "/api/v2/document-center/{id}",
                                "/api/v2/document-center/{id}",
                                "/api/v2/document-center/{id}",
                                "/api/v2/document-center/addSection",
                                "/api/v2/document-center/allSections",
                                "/api/v2/document-center/deleteSection/{id}",
                                "/api/v2/rewards-and-recognition/create",
                                "/api/v2/rewards-and-recognition/all",
                                "/api/v2/rewards-and-recognition/{id}",
                                "/api/v2/rewards-and-recognition/{id}",
                                "/api/v2/rewards-and-recognition/{id}",
                                "/api/v2/coffee-with-leaders/upload",
                                "/api/v2/coffee-with-leaders/all",
                                "/api/v2/coffee-with-leaders/{id}",
                                "/api/v2/coffee-with-leaders/{id}",
                                "/api/v2/coffee-with-leaders/{id}",
                                "/api/v2/employee-newsletter/upload",
                                "/api/v2/employee-newsletter/all",
                                "/api/v2/employee-newsletter/{id}",
                                "/api/v2/employee-newsletter/{id}",
                                "/api/v2/employee-newsletter/{id}",
                                "/api/v2/brand-guidelines",
                                "/api/v2/brand-guidelines/upload",
                                "/api/v2/brand-guidelines/all",
                                "/api/v2/brand-guidelines/{id}",
                                "/api/v2/brand-guidelines/{id}",
                                "/api/v2/brand-guidelines/{id}",
                                "/api/v2/help-and-support/upload",
                                "/api/v2/help-and-support/all",
                                "/api/v2/help-and-support/{id}",
                                "/api/v2/help-and-support/{id}",
                                "/api/v2/help-and-support/{id}",
                                "/api/v2/rewards-and-recognition/allSectionDocuments",
                                "/api/v2/rewards-and-recognition/addSection",
                                "/api/v2/rewards-and-recognition/allSections",
                                "/api/v2/rewards-and-recognition/deleteSection/{id}",
                                "/api/v2/rewards-and-recognition/addSubsection",
                                "/api/v2/rewards-and-recognition/allSubSection",
                                "/api/v2/rewards-and-recognition/deleteSubsection/{id}",
                                "/api/v2/rewards-and-recognition/updateSection/{id}",
                                "/api/v2/rewards-and-recognition/updateSubsection/{id}",
                                "/api/v2/document-center/updateSection/{id}",
                                "/api/v2/audit/changes",
                                "/api/v2/audit/filter",
                                "/api/v2/audit/{id}",
                                "/api/v2/dashboard/track/{moduleId}",
                                "/api/v2/dashboard/usage",
                                "/api/v2/dashboard/modules/active",
                                "/api/v2/dashboard/module/{parent_id}",
                                "api/v2/dashboard/module-breakdown",
                                "api/v2/dashboard/monthly-trend",
                                "api/v2/dashboard/deep-dive",
                                "api/v2/dashboard/time-based-clicks",
                                "api/v2/dashboard/header",
                                "api/v2/dashboard/engagement-trend",
                                "/api/v2/dashboard/login-analytics",
                                "/api/v2/dashboard/mood-percentage",
                                "/api/v2/dashboard/monthly-unique-users",
                                "/api/v2/dashboard/device-browser-breakdown",
                                "/api/v2/dashboard/system-uptime",
                                "/api/v2/dashboard/full",
                                "/api/v2/dashboard/designation-logins",
                                "/api/v2/dashboard/search-analytics",
                                "/api/v2/dashboard/top-searches",
                                "api/v2/login-activity/login-analytics",
                                "api/v2/performance/page-load",
                                "api/v2/performance/tracking/{trackingId}",
                                "api/v2/performance/api",
                                "api/v2/performance/range",
                                "api/v2/performance/summary",
                                "api/v2/performance/monthly",
                                "api/v2/performance/all",
                                "api/v2/performance/device/{deviceType}",
                                "api/v2/performance/browser/{browser}",
                                "/api/v2/system-uptime/create",
                                "/api/v2/system-uptime/all",
                                "/api/v2/system-uptime/uptime/{date}",
                                "/api/v2/system-uptime/{id}",
                                "/api/v2/search-analytics/search/click/{id}",
                                "/api/v2/login-activity/login-analytics",
                                "/api/v2/login-activity/unique-visitors",
                                "/api/v2/login-activity/dau",
                                "/api/v2/login-activity/wau",
                                "/api/v2/login-activity/mau",
                                "/api/v2/login-activity/returning-users",
                                "/api/v2/login-activity/new-users",
                                "/api/v2/login-activity/avg-login-per-user"
                        ).authenticated()

                        // Any other request requires authentication
                        .anyRequest().authenticated()
                )

                // ----------------- SAML Login -----------------
                .saml2Login(saml -> saml
                        .successHandler(samlAuthenticationSuccessHandler()) // Custom success handler
                        .failureUrl("/login?error=true")
                )

                // ----------------- Session Management -----------------
                .sessionManagement(session -> session
                        .sessionCreationPolicy(SessionCreationPolicy.STATELESS) // JWT + stateless
                )

                // ----------------- Exception Handling -----------------
                .exceptionHandling(ex -> ex
                        .authenticationEntryPoint(unauthorizedHandler)
                )

                // ----------------- JWT Authentication -----------------
                .authenticationProvider(authenticationProvider())
                .addFilterBefore(authenticationJwtTokenFilter(), UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }




    @Bean
    public SamlAuthenticationSuccessHandler samlAuthenticationSuccessHandler() {
        return new SamlAuthenticationSuccessHandler(userService, jwtTokenProvider, cookieUtils, userRepository, dailyLoginActivityService);
    }





    @Bean
    public JwtAuthFilter authenticationJwtTokenFilter() {
        return new JwtAuthFilter(jwtTokenProvider, userDetailsService, cookieUtils);
    }

    @Bean
    public GrantedAuthorityDefaults grantedAuthorityDefaults() {
        return new GrantedAuthorityDefaults("");
    }


    //test
//    @Bean
//    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
//        http.csrf(csrf -> csrf
//                        .ignoringRequestMatchers("/saml2/**", "/login/saml2/**") // Disable CSRF for SAML endpoints
//                )
//                .cors(cors -> cors.configurationSource(request -> {
//                    CorsConfiguration corsConfig = new CorsConfiguration();
//
//                    // Use specific origins instead of wildcard when allowCredentials is true
//                    corsConfig.setAllowedOrigins(List.of(feDomainUrl, domainUrl, Constants.FE_LOCAL_URL));
//
//                    // Allow all HTTP methods including OPTIONS (important for CORS preflight)
//                    corsConfig.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS", "HEAD"));
//
//                    // Allow all headers
//                    corsConfig.setAllowedHeaders(List.of("*"));
//
//                    // Allow credentials (important for SAML and JWT)
//                    corsConfig.setAllowCredentials(true);
//
//                    // Cache preflight response for 1 hour
//                    corsConfig.setMaxAge(3600L);
//
//                    return corsConfig;
//                }))
//                .authorizeHttpRequests(request -> request
//                        .requestMatchers(
//                                "/swagger-ui/**",
//                                "/v3/api-docs/**",
//                                "/api/v1/**",
//                                "/saml2/**",           // Allow SAML metadata and authentication endpoints
//                                "/login/saml2/**",     // Allow SAML login endpoints
//                                "/saml/**"             // Allow custom SAML endpoints if any
//                        ).permitAll()
//                        .anyRequest().authenticated()
//                )
//                // Enable SAML login
//                .saml2Login(saml -> saml
//                        .successHandler(samlAuthenticationSuccessHandler()) // Use custom success handler
//                        .failureUrl("/login?error=true")
//                )
//                // CRITICAL FIX: Use IF_REQUIRED to allow both JWT and SAML to work
//                .sessionManagement(manager -> manager.sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED))
//                .exceptionHandling(ex -> ex.authenticationEntryPoint(unauthorizedHandler))
//                .authenticationProvider(authenticationProvider())
//                .addFilterBefore(authenticationJwtTokenFilter(), UsernamePasswordAuthenticationFilter.class);
//
//        return http.build();
//    }
}




