package com.wafer.portal.repository;

import com.wafer.portal.dto.PerformanceSummaryDTO;
import com.wafer.portal.model.PerformanceLog;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import jakarta.transaction.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface PerformanceLogRepository extends JpaRepository<PerformanceLog,Long> {

    List<PerformanceLog> findAllByTrackingId(String trackingId);

    @Modifying
    @Transactional
    @Query(value = """
INSERT INTO performance_logs_monthly
(page_name, api_name, year, month, total_requests, avg_api_time, avg_page_load, error_count)

SELECT
page_name,
api_name,
EXTRACT(YEAR FROM created_date),
EXTRACT(MONTH FROM created_date),
COUNT(*),
AVG(api_response_time_ms),
AVG(page_load_time_ms),
SUM(CASE WHEN status_code >= 400 THEN 1 ELSE 0 END)

FROM performance_logs
WHERE created_date < NOW() - INTERVAL '3 months'

GROUP BY page_name, api_name,
EXTRACT(YEAR FROM created_date),
EXTRACT(MONTH FROM created_date)

ON CONFLICT (page_name, api_name, year, month)
DO NOTHING
""", nativeQuery = true)
    void aggregateOldLogs();


    @Transactional
    @Modifying
    @Query(value="DELETE FROM performance_logs WHERE created_date < NOW() - INTERVAL '3 months'",nativeQuery = true)
    void deleteOldLogs();


    List<PerformanceLog> findByApiName(String apiName);

//    @Query(value = """
//SELECT api_name, device_type, browser, COUNT(*) as total
//FROM performance_logs
//WHERE page_load_time_ms IS NOT NULL
//AND page_load_time_ms > :threshold
//AND is_removed = false
//AND created_date BETWEEN :startDateTime AND :endDateTime
//GROUP BY api_name, device_type, browser
//ORDER BY total DESC
//LIMIT 10
//""", nativeQuery = true)
//    List<Object[]> findSlowApis(
//            Long threshold,
//            LocalDateTime startDateTime,
//            LocalDateTime endDateTime
//    );

//    @Query(value = """
//SELECT device_type, COUNT(DISTINCT tracking_id) as total
//FROM performance_logs
//WHERE is_removed = false
//AND device_type IS NOT NULL
//AND tracking_id IS NOT NULL
//AND created_date BETWEEN :startDateTime AND :endDateTime
//GROUP BY device_type
//ORDER BY total DESC
//""", nativeQuery = true)
//    List<Object[]> countByDeviceType(
//            LocalDateTime startDateTime,
//            LocalDateTime endDateTime
//    );


//    @Query(value = """
//SELECT browser, COUNT(DISTINCT tracking_id) as total
//FROM performance_logs
//WHERE is_removed = false
//AND browser IS NOT NULL
//AND browser IS NOT NULL
//AND created_date BETWEEN :startDateTime AND :endDateTime
//GROUP BY browser
//ORDER BY total DESC
//""", nativeQuery = true)
//    List<Object[]> countByBrowser(
//            LocalDateTime startDateTime,
//            LocalDateTime endDateTime
//    );

    @Query(value = """
SELECT tracking_id, page_name, MAX(page_load_time_ms) as page_load_time_ms,
       browser, device_type, os, MIN(created_date) as created_date, COUNT(*) as api_count,
       MIN(created_by) as created_by
FROM performance_logs
WHERE is_removed = false
AND device_type = :deviceType
AND created_date BETWEEN :startDateTime AND :endDateTime
AND tracking_id IS NOT NULL
GROUP BY tracking_id, page_name, browser, device_type, os
ORDER BY MIN(created_date) DESC
""", countQuery = """
SELECT COUNT(DISTINCT tracking_id)
FROM performance_logs
WHERE is_removed = false
AND device_type = :deviceType
AND created_date BETWEEN :startDateTime AND :endDateTime
AND tracking_id IS NOT NULL
""", nativeQuery = true)
    Page<Object[]> findByDeviceType(
            String deviceType,
            LocalDateTime startDateTime,
            LocalDateTime endDateTime,
            Pageable pageable
    );


    @Query(value = """
SELECT tracking_id, page_name, MAX(page_load_time_ms) as page_load_time_ms,
       browser, device_type, os, MIN(created_date) as created_date, COUNT(*) as api_count,
       MIN(created_by) as created_by
FROM performance_logs
WHERE is_removed = false
AND browser = :browser
AND created_date BETWEEN :startDateTime AND :endDateTime
AND tracking_id IS NOT NULL
GROUP BY tracking_id, page_name, browser, device_type, os
ORDER BY MIN(created_date) DESC
""", countQuery = """
SELECT COUNT(DISTINCT tracking_id)
FROM performance_logs
WHERE is_removed = false
AND browser = :browser
AND created_date BETWEEN :startDateTime AND :endDateTime
AND tracking_id IS NOT NULL
""", nativeQuery = true)
    Page<Object[]> findByBrowserType(
            String browser,
            LocalDateTime startDateTime,
            LocalDateTime endDateTime,
            Pageable pageable
    );

}