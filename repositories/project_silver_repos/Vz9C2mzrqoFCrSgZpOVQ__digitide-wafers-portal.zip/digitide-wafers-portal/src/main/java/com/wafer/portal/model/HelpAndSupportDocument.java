package com.wafer.portal.model;

import com.wafer.portal.audit.Auditable;
import jakarta.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "help_and_support_document")
public class HelpAndSupportDocument extends Auditable<String> implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String description;

    @Column(name = "document_key")
    private String documentKey;

    private Double sequence;

    private String thumbnail;

    @Column(name = "is_deleted", nullable = false)
    private boolean isDeleted = false;

    public HelpAndSupportDocument() {}

    public HelpAndSupportDocument(String description, String documentKey, Double sequence, String thumbnail) {
        this.description = description;
        this.documentKey = documentKey;
        this.sequence = sequence;
        this.thumbnail = thumbnail;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDocumentKey() {
        return documentKey;
    }

    public void setDocumentKey(String documentKey) {
        this.documentKey = documentKey;
    }

    public Double getSequence() {
        return sequence;
    }

    public void setSequence(Double sequence) {
        this.sequence = sequence;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public boolean isDeleted() {
        return isDeleted;
    }

    public void setDeleted(boolean deleted) {
        isDeleted = deleted;
    }
}