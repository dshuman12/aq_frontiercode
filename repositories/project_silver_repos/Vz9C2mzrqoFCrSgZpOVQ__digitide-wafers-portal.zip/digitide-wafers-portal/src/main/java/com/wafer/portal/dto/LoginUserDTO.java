package com.wafer.portal.dto;

import java.time.LocalDate;

public class LoginUserDTO {

    private String userEmail;
    private LocalDate loginDate;
    private String designation;

    public LoginUserDTO(String userEmail, LocalDate loginDate, String designation) {
        this.userEmail = userEmail;
        this.loginDate = loginDate;
        this.designation = designation;
    }

    public String getUserEmail() { return userEmail; }
    public LocalDate getLoginDate() { return loginDate; }
    public String getDesignation() { return designation; }
}