package com.wafer.portal.repository;

import com.wafer.portal.model.DocumentSection;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;
import java.util.List;

public interface DocumentSectionRepository extends JpaRepository<DocumentSection, Long> {

    Optional<DocumentSection> findBySectionNameIgnoreCaseAndIsDeletedFalse(String sectionName);

    List<DocumentSection> findByIsDeletedFalse();
    Page<DocumentSection> findByIsDeletedFalse(Pageable pageable);

    @Query("SELECT ds FROM DocumentSection ds WHERE ds.isDeleted = false AND " +
            "LOWER(ds.sectionName) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    List<DocumentSection> searchDocumentSections(@Param("keyword") String keyword);

}
