package com.wafer.portal.service;

import com.wafer.portal.awsS3.S3Service;
import com.wafer.portal.dto.PicOfTheDayRequest;
import com.wafer.portal.dto.PicOfTheDayResponse;
import com.wafer.portal.model.PicOfTheDay;
import com.wafer.portal.repository.PicOfTheDayRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Optional;

@Service
public class PicOfTheDayService {

    private static final String PIC_FOLDER = "Pic-Of-The-Day";

    private final PicOfTheDayRepository repository;
    private final S3Service s3Service;

    @Autowired
    public PicOfTheDayService(PicOfTheDayRepository repository, S3Service s3Service) {
        this.repository = repository;
        this.s3Service = s3Service;
    }

    public ResponseEntity<PicOfTheDayResponse> uploadPic(MultipartFile image,MultipartFile thumbnail, PicOfTheDayRequest request) {
        try {
            if (image == null || image.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
            }

            Optional<PicOfTheDay> existing = repository.findTopByIsDeletedFalseOrderByCreationDateDesc();


            String newImageKey;
            String urlKey = null;


            if (existing.isPresent()) {
                PicOfTheDay oldPic = existing.get();
                newImageKey = s3Service.updateFile(oldPic.getImage(), image, PIC_FOLDER);
                if (thumbnail != null && !thumbnail.isEmpty()) {
                    urlKey = s3Service.uploadFile(thumbnail, "Thumbnails");
                }
                oldPic.setTitle(request.getTitle());
                oldPic.setDesignation(request.getDesignation());
                oldPic.setPlace(request.getPlace());
                oldPic.setImage(newImageKey);
                oldPic.setThumbnail(urlKey);
                PicOfTheDay updated = repository.save(oldPic);
                return new ResponseEntity<>(mapToResponse(updated), HttpStatus.OK);
            } else {
                newImageKey = s3Service.uploadFile(image, PIC_FOLDER);
                if (thumbnail != null && !thumbnail.isEmpty()) {
                    urlKey = s3Service.uploadFile(thumbnail, "Thumbnails");
                }
                PicOfTheDay newPic = new PicOfTheDay();
                newPic.setTitle(request.getTitle());
                newPic.setDesignation(request.getDesignation());
                newPic.setPlace(request.getPlace());
                newPic.setImage(newImageKey);
                newPic.setThumbnail(urlKey);
                PicOfTheDay saved = repository.save(newPic);
                return new ResponseEntity<>(mapToResponse(saved), HttpStatus.CREATED);
            }

        } catch (IOException e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<PicOfTheDayResponse> getPicOfTheDay() {
        return repository.findTopByIsDeletedFalseOrderByCreationDateDesc()
                .map(pic -> new ResponseEntity<>(mapToResponse(pic), HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NO_CONTENT));
    }


    public ResponseEntity<PicOfTheDayResponse> updatePic(
            MultipartFile image,
            MultipartFile thumbnail,
            PicOfTheDayRequest request) {

        try {
            Optional<PicOfTheDay> existingOpt =
                    repository.findTopByIsDeletedFalseOrderByCreationDateDesc();

            if (existingOpt.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }

            PicOfTheDay existing = existingOpt.get();

            String updatedImageKey = existing.getImage();
            String updatedThumbnailKey = existing.getThumbnail();


            if (image != null && !image.isEmpty() && image.getOriginalFilename() != null
                    && !image.getOriginalFilename().isBlank()) {
                updatedImageKey = s3Service.updateFile(existing.getImage(), image, PIC_FOLDER);

                boolean isVideo = image.getContentType() != null &&
                        image.getContentType().startsWith("video");

                if (isVideo) {
                    if (thumbnail != null && !thumbnail.isEmpty()) {
                        updatedThumbnailKey = s3Service.updateFile(existing.getThumbnail(), thumbnail, PIC_FOLDER);
                    }
                } else {
                    if (thumbnail != null && !thumbnail.isEmpty()) {
                        updatedThumbnailKey = s3Service.updateFile(existing.getThumbnail(), thumbnail, PIC_FOLDER);
                    } else {
                        updatedThumbnailKey = null;
                    }
                }
            }
            else {
                if (thumbnail != null && !thumbnail.isEmpty()) {
                    updatedThumbnailKey = s3Service.updateFile(existing.getThumbnail(), thumbnail, PIC_FOLDER);
                }
            }

            existing.setTitle(request.getTitle());
            existing.setDesignation(request.getDesignation());
            existing.setPlace(request.getPlace());
            existing.setImage(updatedImageKey);
            existing.setThumbnail(updatedThumbnailKey);

            PicOfTheDay updated = repository.save(existing);

            return new ResponseEntity<>(mapToResponse(updated), HttpStatus.OK);

        } catch (IOException e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    private PicOfTheDayResponse mapToResponse(PicOfTheDay pic) {
        String imageUrl = s3Service.generatePresignedUrl(pic.getImage());
        String prePresignedUrl1 = null;

        if (pic.getThumbnail() != null && !pic.getThumbnail().isEmpty()) {
            prePresignedUrl1 = s3Service.generatePresignedUrl(pic.getThumbnail());
        }
        return new PicOfTheDayResponse(
                pic.getId(),
                pic.getTitle(),
                pic.getDesignation(),
                pic.getPlace(),
                imageUrl,
                prePresignedUrl1,
                pic.getCreatedBy(),
                pic.getCreationDate(),
                pic.getLastModifiedBy(),
                pic.getLastModifiedDate()
        );
    }
}
