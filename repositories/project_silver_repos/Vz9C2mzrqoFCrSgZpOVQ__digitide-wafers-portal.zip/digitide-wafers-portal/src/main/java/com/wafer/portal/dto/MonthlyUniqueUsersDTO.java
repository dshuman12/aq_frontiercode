package com.wafer.portal.dto;

public class MonthlyUniqueUsersDTO {
    private Integer year;
    private Integer month;
    private Long uniqueUsers;

    public MonthlyUniqueUsersDTO(Integer year, Integer month, Long uniqueUsers) {
        this.year = year;
        this.month = month;
        this.uniqueUsers = uniqueUsers;
    }

    public Integer getYear() { return year; }
    public Integer getMonth() { return month; }
    public Long getUniqueUsers() { return uniqueUsers; }
}