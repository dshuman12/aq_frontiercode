package com.wafer.portal.controller;

import com.wafer.portal.annotation.TrackChange;
import com.wafer.portal.awsS3.S3Service;
import com.wafer.portal.dto.MileStoneResponseDto;
import com.wafer.portal.model.MileStone;
import com.wafer.portal.service.MileStoneService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@RestController
@RequestMapping("/api/v1/milestone")
public class MileStoneController {

    private static  final Logger logger =  LoggerFactory.getLogger(MileStoneController.class);

    private final MileStoneService mileStoneService;
    private final S3Service s3Service;

    public MileStoneController(MileStoneService mileStoneService, S3Service s3Service) {
        this.mileStoneService = mileStoneService;
        this.s3Service = s3Service;
    }

    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Added", section = "Milestone")
    public ResponseEntity<MileStoneResponseDto> addMileStone(@RequestParam("content") String content,
                                                             @RequestParam(name="url", required=false) String url,
                                                             @RequestPart("image") MultipartFile image,
                                                             @RequestPart(name="thumbnail", required=false) MultipartFile thumbnail,
                                                             @RequestParam(name="sequence", required=false) Double sequence) {
        try {
            if (image.isEmpty()) {
                return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
            }
            String imageKey = s3Service.uploadFile(image, "MileStone-Images");

            String urlKey = null;
            if (thumbnail != null && !thumbnail.isEmpty()) {
                urlKey = s3Service.uploadFile(thumbnail, "MileStone-Thumbnail-Images");
            }


            MileStone mileStone = new MileStone(imageKey, urlKey, content, url,sequence);
            MileStone savedMileStone = mileStoneService.saveMileStone(mileStone);

            String preSignedUrl = s3Service.generatePresignedUrl(savedMileStone.getImageUrl());
            String prePresignedUrl1 = null;

            if (savedMileStone.getThumbnail() != null && !savedMileStone.getThumbnail().isEmpty()) {
                prePresignedUrl1 = s3Service.generatePresignedUrl(savedMileStone.getThumbnail());
            }

            MileStoneResponseDto responseDto = new MileStoneResponseDto(savedMileStone.getId(), savedMileStone.getContent(), preSignedUrl, prePresignedUrl1, savedMileStone.getUrl(), savedMileStone.getSequence(), savedMileStone.getCreatedBy(), savedMileStone.getCreationDate(), savedMileStone.getLastModifiedBy(), savedMileStone.getLastModifiedDate());
            return new ResponseEntity<>(responseDto, HttpStatus.CREATED);
        } catch (IOException e) {
            e.printStackTrace();
            logger.error("IoException occurred while uploading MileStone image", e);
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("Unexpected error occurred while MileStone image", e);
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @GetMapping("/all")
    public ResponseEntity<Page<MileStoneResponseDto>> getAllMileStones(Pageable pageable) {
        Page<MileStone> mileStonePage = mileStoneService.getAllMileStones(pageable);

        Page<MileStoneResponseDto> dtoPage = mileStonePage.map(mileStone -> {
            String preSignedUrl = s3Service.generatePresignedUrl(mileStone.getImageUrl());
            String prePresignedUrl1 = null;

            if (mileStone.getThumbnail() != null && !mileStone.getThumbnail().isEmpty()) {
                prePresignedUrl1 = s3Service.generatePresignedUrl(mileStone.getThumbnail());
            }

            return  new MileStoneResponseDto(mileStone.getId(), mileStone.getContent(), preSignedUrl,prePresignedUrl1, mileStone.getUrl(), mileStone.getSequence(), mileStone.getCreatedBy(), mileStone.getCreationDate(), mileStone.getLastModifiedBy(), mileStone.getLastModifiedDate());
        });
        return dtoPage.isEmpty() ? new ResponseEntity<>(HttpStatus.NO_CONTENT) : new ResponseEntity<>(dtoPage, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<MileStoneResponseDto> getMileStoneById(@PathVariable Long id) {
        return mileStoneService.getMileStoneById(id)
                .map(mileStone ->{
                    String preSignedUrl = s3Service.generatePresignedUrl(mileStone.getImageUrl());
                    String prePresignedUrl1 = null;

                    if (mileStone.getThumbnail() != null && !mileStone.getThumbnail().isEmpty()) {
                        prePresignedUrl1 = s3Service.generatePresignedUrl(mileStone.getThumbnail());
                    }

                    MileStoneResponseDto dto = new MileStoneResponseDto(mileStone.getId(), mileStone.getContent(), preSignedUrl, prePresignedUrl1, mileStone.getUrl(), mileStone.getSequence(), mileStone.getCreatedBy(), mileStone.getCreationDate(), mileStone.getLastModifiedBy(), mileStone.getLastModifiedDate());
                    return new ResponseEntity<>(dto, HttpStatus.OK);
                }).orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }


    @PutMapping(value = "/{id}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Edited", section = "Milestone")
    public ResponseEntity<MileStoneResponseDto> updateMileStone(@PathVariable Long id,
                                                                @RequestParam("content") String content,
                                                                @RequestParam(name="url", required=false) String url,
                                                                @RequestPart(value = "image", required = false) MultipartFile image,
                                                                @RequestPart(value = "thumbnail", required = false) MultipartFile thumbnail,
                                                                @RequestParam(name="sequence", required=false) Double sequence) {
        try {
            MileStone existing = mileStoneService.getMileStoneById(id).orElse(null);
            if (existing == null) {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
            String updatedImageKey = existing.getImageUrl();
            String updatedThumbnailKey = existing.getThumbnail();

            if (image != null && !image.isEmpty() && image.getOriginalFilename() != null
                    && !image.getOriginalFilename().isBlank()) {

                updatedImageKey = s3Service.updateFile(existing.getImageUrl(), image, "MileStone-Images");

                boolean isVideo = image.getContentType() != null &&
                        image.getContentType().startsWith("video");

                if (isVideo) {
                    if (thumbnail != null && !thumbnail.isEmpty()) {
                        updatedThumbnailKey = s3Service.updateFile(existing.getThumbnail(), thumbnail, "MileStone-Thumbnail-Images");
                    }
                } else {
                    if (thumbnail != null && !thumbnail.isEmpty()) {
                        updatedThumbnailKey = s3Service.updateFile(existing.getThumbnail(), thumbnail, "MileStone-Thumbnail-Images");
                    } else {
                        updatedThumbnailKey = null; // your rule
                    }
                }
            }
            else {
                if (thumbnail != null && !thumbnail.isEmpty()) {
                    updatedThumbnailKey = s3Service.updateFile(existing.getThumbnail(), thumbnail, "MileStone-Thumbnail-Images");
                }
            }

            existing.setImageUrl(updatedImageKey);
            existing.setThumbnail(updatedThumbnailKey);
            existing.setContent(content);
            existing.setUrl(url);
            existing.setSequence(sequence);

            MileStone updatedMileStone = mileStoneService.saveMileStone(existing);

            String preSignedUrl = s3Service.generatePresignedUrl(updatedMileStone.getImageUrl());
            String prePresignedUrl1 = null;

            if (updatedMileStone.getThumbnail() != null && !updatedMileStone.getThumbnail().isEmpty()) {
                prePresignedUrl1 = s3Service.generatePresignedUrl(updatedMileStone.getThumbnail());
            }

            MileStoneResponseDto responseDto = new MileStoneResponseDto(updatedMileStone.getId(), updatedMileStone.getContent(), preSignedUrl, prePresignedUrl1, updatedMileStone.getUrl(), updatedMileStone.getSequence(), updatedMileStone.getCreatedBy(), updatedMileStone.getCreationDate(), updatedMileStone.getLastModifiedBy(), updatedMileStone.getLastModifiedDate());
            return new ResponseEntity<>(responseDto, HttpStatus.OK);
        }catch (IOException e) {
            e.printStackTrace();
            logger.error("IoException occurred while updating MileStone image", e);
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("Unexpected error occurred while updating MileStone image", e);
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/{id}")
    @TrackChange(action = "Deleted", section = "Milestone") // Fixed action from 'Added' to 'Deleted'
    public ResponseEntity<MileStone> deleteMileStone(@PathVariable Long id) {
        try {
            MileStone result = mileStoneService.softDeleteMileStone(id);
            return (result != null)
                    ? new ResponseEntity<>(result, HttpStatus.OK)
                    : new ResponseEntity<>(HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            logger.error("Failed to soft delete milestone with ID: {}", id, e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
