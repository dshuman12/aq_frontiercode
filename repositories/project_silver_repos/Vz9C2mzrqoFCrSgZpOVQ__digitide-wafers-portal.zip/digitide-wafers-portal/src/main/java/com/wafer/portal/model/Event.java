package com.wafer.portal.model;

import com.wafer.portal.audit.Auditable;
import jakarta.persistence.*;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;

@Entity
@Table(name = "events")
public class Event extends Auditable<String> implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String eventName;

    private String eventImage;

    @Column(name="thumbnail_url")
    private String thumbnail;

    private LocalDate eventDate;

    private LocalTime startTime;

    @Column(name = "end_time", nullable = true)
    private LocalTime endTime;

    private String url;

    private Double sequence;

    @Column(name = "is_deleted", nullable = false)
    private boolean isDeleted;

    public Event() {}

    public Event(String eventName, String imageKey, String thumbnail, LocalDate eventDate, LocalTime startTime, LocalTime endTime, String url,Double sequence) {
        this.eventName = eventName;
        this.eventImage = imageKey;
        this.thumbnail = thumbnail;
        this.eventDate = eventDate;
        this.startTime = startTime;
        this.endTime = endTime;
        this.url = url;
        this.sequence=sequence;
        this.isDeleted = false;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getEventImage() {
        return eventImage;
    }

    public void setEventImage(String eventImage) {
        this.eventImage = eventImage;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public LocalDate getEventDate() {
        return eventDate;
    }

    public void setEventDate(LocalDate eventDate) {
        this.eventDate = eventDate;
    }

    public LocalTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalTime startTime) {
        this.startTime = startTime;
    }

    public LocalTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalTime endTime) {
        this.endTime = endTime;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Double getSequence() {
        return sequence;
    }

    public void setSequence(Double sequence) {
        this.sequence = sequence;
    }

    public boolean isDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(boolean deleted) {
        isDeleted = deleted;
    }
}

