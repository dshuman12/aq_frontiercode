package com.wafer.portal.service;

import com.wafer.portal.model.Spotlight;
import com.wafer.portal.repository.SpotlightRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class SpotlightService {

    @Autowired
    private SpotlightRepository spotlightRepository;

    public Spotlight saveSpotlight(Spotlight spotlight) {
        return spotlightRepository.save(spotlight);
    }

    public Page<Spotlight> getAllSpotlight(Pageable pageable) {
        return spotlightRepository.findAllOrderedBySequence(pageable);
    }

    public Optional<Spotlight> getSpotlightById(Long id) {
        return spotlightRepository.findByIdAndIsDeletedFalse(id);
    }

    public Spotlight updateSpotlight(Long id, Spotlight updatedSpotlight) {
        return spotlightRepository.findById(id).map(spotlight -> {
            spotlight.setVideo(updatedSpotlight.getVideo());
            spotlight.setTitle(updatedSpotlight.getTitle());
            spotlight.setUrl(updatedSpotlight.getUrl());
            spotlight.setSequence(updatedSpotlight.getSequence());
            return spotlightRepository.save(spotlight);
        }).orElse(null);
    }

    public Spotlight softDeleteSpotlight(Long id) {
        return spotlightRepository.findByIdAndIsDeletedFalse(id).map(spotlight -> {
            spotlight.setIsDeleted(true);
            return spotlightRepository.save(spotlight);
        }).orElse(null);
    }

}
