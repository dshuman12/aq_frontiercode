package com.wafer.portal.scheduler;

import com.wafer.portal.repository.PerformanceLogRepository;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component
public class PerformanceScheduler {

    private static final Logger logger = LoggerFactory.getLogger(PerformanceScheduler.class);

    private final PerformanceLogRepository repository;

    public PerformanceScheduler(PerformanceLogRepository repository) {
        this.repository = repository;
    }

    @Scheduled(cron = "0 0 2 1 * ?")
    public void archiveOldLogs(){

        try {

            logger.info("Starting performance logs archiving job");

            repository.aggregateOldLogs();

            repository.deleteOldLogs();

            logger.info("Performance logs archived successfully");

        } catch (Exception e) {

            logger.error("Error while archiving performance logs", e);

        }
    }


}