package com.wafer.portal.repository;

import com.wafer.portal.model.RewardsandRecognition;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

@Repository
public interface RewardsandRecognitionRepository extends JpaRepository<RewardsandRecognition,Long> {

    Optional<RewardsandRecognition> findByIdAndIsDeletedFalse(Long aLong);


    @Query("SELECT r FROM RewardsandRecognition r WHERE r.isDeleted = false ORDER BY " +
            "CASE WHEN r.sequence IS NULL THEN 1 ELSE 0 END, r.sequence ASC")
    Page<RewardsandRecognition> findAllOrderedBySequence(Pageable pageable);

    @Query("SELECT r FROM RewardsandRecognition r WHERE r.isDeleted = false AND (" +
            "LOWER(r.name) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(r.designation) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(r.description) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    Page<RewardsandRecognition> searchRewardsAndRecognition(@Param("keyword") String keyword, Pageable pageable);

    Page<RewardsandRecognition> findByIsDeletedFalse(Pageable pageable);
    List<RewardsandRecognition> findByIsDeletedFalse();

    boolean existsBySubsectionIdAndIsDeletedFalse(Long subsectionId);

}