package com.wafer.portal.dto;

public class DocumentSectionResponseDto {

    private Long id;
    private String sectionName;

    public DocumentSectionResponseDto(Long id, String sectionName) {
        this.id = id;
        this.sectionName = sectionName;
    }

    public Long getId() {
        return id;
    }

    public String getSectionName() {
        return sectionName;
    }
}
