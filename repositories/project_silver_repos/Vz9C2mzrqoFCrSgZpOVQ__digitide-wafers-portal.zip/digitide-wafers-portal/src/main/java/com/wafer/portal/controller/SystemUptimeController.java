package com.wafer.portal.controller;

import com.wafer.portal.dto.SystemUptimeRequest;
import com.wafer.portal.dto.SystemUptimeResponseDto;
import com.wafer.portal.service.SystemUptimeService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/v2/system-uptime")
public class SystemUptimeController {

    private final SystemUptimeService service;

    public SystemUptimeController(SystemUptimeService service) {
        this.service = service;
    }

    @PostMapping("/create")
    public ResponseEntity<SystemUptimeResponseDto> create(
            @RequestBody SystemUptimeRequest request) {

        return ResponseEntity.ok(service.create(request));
    }

    @GetMapping("/all")
    public ResponseEntity<List<SystemUptimeResponseDto>> getAll() {
        return ResponseEntity.ok(service.getAll());
    }

    // Get Uptime % by date
    @GetMapping("/uptime/{date}")
    public ResponseEntity<Double> getUptime(@PathVariable String date) {
        return ResponseEntity.ok(service.getUptimeByDate(LocalDate.parse(date)));
    }

}