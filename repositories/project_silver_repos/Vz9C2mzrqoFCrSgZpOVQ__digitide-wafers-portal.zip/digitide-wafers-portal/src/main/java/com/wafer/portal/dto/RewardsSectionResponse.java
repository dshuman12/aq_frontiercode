package com.wafer.portal.dto;

public class RewardsSectionResponse {
    private Long id;
    private String sectionName;

    public RewardsSectionResponse(Long id, String sectionName) {
        this.id = id;
        this.sectionName = sectionName;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setSectionName(String sectionName) {
        this.sectionName = sectionName;
    }

    public Long getId() { return id; }
    public String getSectionName() { return sectionName; }
}