package com.wafer.portal.dto;

import com.wafer.portal.model.LinkType;

public class QuickLinkSubHeaderRequest {

    private String title;
    private Long parentId;
    private String url;
    private LinkType linkType;

    public QuickLinkSubHeaderRequest() {}

    public QuickLinkSubHeaderRequest(String title, Long parentId, String url, LinkType linkType) {
        this.title = title;
        this.parentId = parentId;
        this.url = url;
        this.linkType = linkType;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Long getParentId() {
        return parentId;
    }

    public void setParentId(Long parentId) {
        this.parentId = parentId;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public LinkType getLinkType() {
        return linkType;
    }

    public void setLinkType(LinkType linkType) {
        this.linkType = linkType;
    }
}

