package com.wafer.portal.service;

import com.wafer.portal.awsS3.S3Service;
import com.wafer.portal.dto.SurveyRequest;
import com.wafer.portal.dto.SurveyResponseDto;
import com.wafer.portal.model.Survey;
import com.wafer.portal.repository.SurveyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDateTime;

@Service
public class SurveyService {

    private static final String SURVEY_FOLDER = "Survey-Images";

    private final SurveyRepository surveyRepository;
    private final S3Service s3Service;

    @Autowired
    public SurveyService(SurveyRepository surveyRepository, S3Service s3Service) {
        this.surveyRepository = surveyRepository;
        this.s3Service = s3Service;
    }

    public ResponseEntity<SurveyResponseDto> createSurvey(MultipartFile image, SurveyRequest request) {
        try {
            if (image.isEmpty()) return new ResponseEntity<>(HttpStatus.BAD_REQUEST);

            String imageKey = s3Service.uploadFile(image, SURVEY_FOLDER);
            Survey survey = new Survey(
                    request.getSurveyTitle(),
                    request.getEstimatedTime(),
                    imageKey,
                    request.getUrlLink(),
                    request.getDescription()
            );
            survey.setSurveyStatus(request.isSurveyStatus());
            Survey saved = surveyRepository.save(survey);
            return new ResponseEntity<>(mapToDto(saved), HttpStatus.CREATED);
        } catch (IOException e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Page<SurveyResponseDto>> getAllSurveys(Pageable pageable) {
        Page<Survey> surveys = surveyRepository.findByIsDeletedFalse(pageable);
        Page<SurveyResponseDto> dtoPage = surveys.map(this::mapToDto);
        return dtoPage.isEmpty() ? new ResponseEntity<>(HttpStatus.NO_CONTENT) : new ResponseEntity<>(dtoPage, HttpStatus.OK);
    }

    public ResponseEntity<SurveyResponseDto> getSurveyById(Long id) {
        return surveyRepository.findByIdAndIsDeletedFalse(id)
                .map(survey -> new ResponseEntity<>(mapToDto(survey), HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    public ResponseEntity<SurveyResponseDto> updateSurvey(Long id, MultipartFile image, SurveyRequest request) {
        return surveyRepository.findByIdAndIsDeletedFalse(id)
                .map(existing -> {
                    try {
                        if (image != null && !image.isEmpty()) {
                            String imageKey = s3Service.updateFile(existing.getImage(), image, SURVEY_FOLDER);
                            existing.setImage(imageKey);
                        }

                        existing.setSurveyTitle(request.getSurveyTitle());
                        existing.setEstimatedTime(request.getEstimatedTime());
                        existing.setUrlLink(request.getUrlLink());
                        existing.setDescription(request.getDescription());

                        Survey updated = surveyRepository.save(existing);
                        return new ResponseEntity<>(mapToDto(updated), HttpStatus.OK);
                    } catch (IOException e) {
                        return new ResponseEntity<SurveyResponseDto>(HttpStatus.INTERNAL_SERVER_ERROR);
                    }
                }).orElse(new ResponseEntity<SurveyResponseDto>(HttpStatus.NOT_FOUND));
    }

    public ResponseEntity<SurveyResponseDto> endSurvey(Long id) {
        return surveyRepository.findByIdAndIsDeletedFalse(id)
                .map(survey -> {
                    survey.setEnded(true);
                    survey.setEndedAt(LocalDateTime.now());
                    Survey updated = surveyRepository.save(survey);
                    return new ResponseEntity<>(mapToDto(updated), HttpStatus.OK);
                }).orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    public ResponseEntity<SurveyResponseDto> updateSurveyStatus(Long id, boolean status) {
        return surveyRepository.findByIdAndIsDeletedFalse(id)
                .map(survey -> {
                    survey.setSurveyStatus(status);
                    Survey updated = surveyRepository.save(survey);
                    return new ResponseEntity<>(mapToDto(updated), HttpStatus.OK);
                })
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }



    public Survey deleteSurvey(Long id) {
        return surveyRepository.findByIdAndIsDeletedFalse(id)
                .map(survey -> {
                    survey.setDeleted(true);
                    return surveyRepository.save(survey);
                }).orElse(null);
    }

    private SurveyResponseDto mapToDto(Survey survey) {
        String preSignedUrl = s3Service.generatePresignedUrl(survey.getImage());
        return new SurveyResponseDto(
                survey.getId(),
                survey.getSurveyTitle(),
                survey.getEstimatedTime(),
                preSignedUrl,
                survey.getUrlLink(),
                survey.getDescription(),
                survey.getEndedAt(),
                survey.isSurveyStatus(),
                survey.getCreatedBy(),
                survey.getCreationDate(),
                survey.getLastModifiedBy(),
                survey.getLastModifiedDate()
        );
    }
}
