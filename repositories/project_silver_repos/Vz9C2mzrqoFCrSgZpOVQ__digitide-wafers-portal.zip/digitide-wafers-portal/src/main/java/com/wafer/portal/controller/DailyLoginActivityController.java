package com.wafer.portal.controller;

import com.wafer.portal.dto.LoginAnalyticsResponseDTO;
import com.wafer.portal.dto.LoginUserDTO;
import com.wafer.portal.service.DailyLoginActivityService;
import org.springframework.web.bind.annotation.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.time.LocalDate;

@RestController
@RequestMapping("/api/v2/login-activity")
public class DailyLoginActivityController {

    private final DailyLoginActivityService dailyLoginActivityService;

    public DailyLoginActivityController(DailyLoginActivityService dailyLoginActivityService) {
        this.dailyLoginActivityService = dailyLoginActivityService;
    }

//    @GetMapping("/login-analytics")
//    public LoginAnalyticsResponseDTO getLoginAnalytics(
//            @RequestParam LocalDate fromDate,
//            @RequestParam LocalDate toDate) {
//        return dailyLoginActivityService.getLoginAnalytics(fromDate, toDate);
//    }

    @GetMapping("/unique-visitors")
    public Page<LoginUserDTO> getUniqueVisitors(
            @RequestParam LocalDate fromDate,
            @RequestParam LocalDate toDate,
            Pageable pageable) {
        return dailyLoginActivityService.getUniqueVisitorsList(fromDate, toDate, pageable);
    }


    @GetMapping("/dau")
    public Page<LoginUserDTO> getDAU(
            @RequestParam LocalDate fromDate,
            @RequestParam LocalDate toDate,
            Pageable pageable) {
        return dailyLoginActivityService.getDAUList(toDate, pageable);
    }


    @GetMapping("/wau")
    public Page<LoginUserDTO> getWAU(
            @RequestParam LocalDate fromDate,
            @RequestParam LocalDate toDate,
            Pageable pageable) {
        return dailyLoginActivityService.getWAUList(toDate, pageable);
    }


    @GetMapping("/mau")
    public Page<LoginUserDTO> getMAU(
            @RequestParam LocalDate fromDate,
            @RequestParam LocalDate toDate,
            Pageable pageable) {
        return dailyLoginActivityService.getMAUList(fromDate, toDate, pageable);
    }


    @GetMapping("/returning-users")
    public Page<LoginUserDTO> getReturningUsers(
            @RequestParam LocalDate fromDate,
            @RequestParam LocalDate toDate,
            Pageable pageable) {
        return dailyLoginActivityService.getReturningUsersList(fromDate, toDate, pageable);
    }


    @GetMapping("/new-users")
    public Page<LoginUserDTO> getNewUsers(
            @RequestParam LocalDate fromDate,
            @RequestParam LocalDate toDate,
            Pageable pageable) {
        return dailyLoginActivityService.getNewUsersList(fromDate, toDate, pageable);
    }


    @GetMapping("/avg-login-per-user")
    public Page<com.wafer.portal.dto.UserLoginFrequencyDTO> getAvgLoginPerUser(
            @RequestParam LocalDate fromDate,
            @RequestParam LocalDate toDate,
            Pageable pageable) {
        return dailyLoginActivityService.getAvgLoginPerUserList(fromDate, toDate, pageable);
    }

}
