package com.wafer.portal.dto;

public class MonthlyClicksDTO {
    private Integer year;
    private Integer month;
    private Long totalClicks;

    public MonthlyClicksDTO(Integer year, Integer month, Long totalClicks) {
        this.year = year;
        this.month = month;
        this.totalClicks = totalClicks;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public Integer getMonth() {
        return month;
    }

    public void setMonth(Integer month) {
        this.month = month;
    }

    public Long getTotalClicks() {
        return totalClicks;
    }

    public void setTotalClicks(Long totalClicks) {
        this.totalClicks = totalClicks;
    }
}
