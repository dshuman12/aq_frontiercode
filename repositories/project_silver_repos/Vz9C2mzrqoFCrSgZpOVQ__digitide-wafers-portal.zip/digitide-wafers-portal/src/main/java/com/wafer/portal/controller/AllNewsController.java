package com.wafer.portal.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.wafer.portal.annotation.TrackChange;
import com.wafer.portal.dto.AllNewsRequest;
import com.wafer.portal.dto.AllNewsResponseDto;
import com.wafer.portal.model.AllNews;
import com.wafer.portal.service.AllNewsService;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@Controller
@RestController
@RequestMapping("/api/v1/all-news")
public class AllNewsController {

    private final AllNewsService allNewsService;

    public AllNewsController(AllNewsService allNewsService) {
        this.allNewsService = allNewsService;
    }


    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Added", section = "All News")
    public ResponseEntity<AllNewsResponseDto> createNews(
            @RequestParam("image") MultipartFile image,
            @RequestParam(value="thumbnail", required = false) MultipartFile thumbnail,
            @RequestParam("request") String requestJson) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        AllNewsRequest request = mapper.readValue(requestJson, AllNewsRequest.class);
        return allNewsService.createNews(image, thumbnail, request);
    }


    @GetMapping("/all")
    public ResponseEntity<Page<AllNewsResponseDto>> getAllNews(Pageable pageable) {
        return allNewsService.getAllNews(pageable);
    }

    @GetMapping("/{id}")
    public ResponseEntity<AllNewsResponseDto> getNewsById(@PathVariable Long id) {
        return allNewsService.getNewsById(id);
    }


    @PutMapping(value = "/{id}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Edited", section = "All News")
    public ResponseEntity<AllNewsResponseDto> updateNews(
            @PathVariable Long id,
            @RequestParam(value = "image", required = false) MultipartFile image,
            @RequestParam(value = "thumbnail", required = false) MultipartFile thumbnail,
            @RequestParam("request") String requestJson) throws JsonProcessingException {

        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

        AllNewsRequest request = mapper.readValue(requestJson, AllNewsRequest.class);
        return allNewsService.updateNews(id, image, thumbnail, request);
    }


    @DeleteMapping("/{id}")
    @TrackChange(action = "Deleted", section = "All News")
    public ResponseEntity<AllNews> deleteNews(@PathVariable Long id) {
        AllNews result = allNewsService.deleteNews(id);
        return (result != null)
                ? new ResponseEntity<>(result, HttpStatus.OK)
                : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}

