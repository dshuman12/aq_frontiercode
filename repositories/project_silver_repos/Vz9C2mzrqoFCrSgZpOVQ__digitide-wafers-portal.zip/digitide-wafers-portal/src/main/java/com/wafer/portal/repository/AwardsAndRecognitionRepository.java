package com.wafer.portal.repository;

import com.wafer.portal.model.AwardsAndRecognition;
import com.wafer.portal.model.People;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface AwardsAndRecognitionRepository extends JpaRepository<AwardsAndRecognition, Long> {
    Page<AwardsAndRecognition> findByIsDeletedFalse(Pageable pageable);
    Optional<AwardsAndRecognition> findByIdAndIsDeletedFalse(Long aLong);

    @Query("SELECT a FROM AwardsAndRecognition a " +
            "WHERE a.isDeleted = false AND " +
            "(LOWER(a.title) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
            "OR LOWER(a.year) LIKE LOWER(CONCAT('%', :keyword, '%'))) ")
    Page<AwardsAndRecognition> searchAwards(@Param("keyword") String keyword, Pageable pageable);

    @Query("SELECT s FROM AwardsAndRecognition s WHERE s.isDeleted = false ORDER BY " +
            "CASE WHEN s.sequence IS NULL THEN 1 ELSE 0 END, s.sequence ASC")
    Page<AwardsAndRecognition> findAllOrderedBySequence(Pageable pageable);

}
