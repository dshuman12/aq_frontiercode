package com.wafer.portal.dto;

public class DocumentCenterResponseDto {
    private Long id;
    private Long section;
    private String sectionName;
    private String documentName;
    private String imageUrl;
    private String thumbnailUrl;
    private Double sequence;

    public DocumentCenterResponseDto(Long id, Long section, String sectionName, String documentName, String url, String thumbnailUrl, Double sequence) {
        this.id = id;
        this.section = section;
        this.sectionName = sectionName;
        this.documentName = documentName;
        this.imageUrl = url;
        this.thumbnailUrl = thumbnailUrl;
        this.sequence = sequence;
    }

    // getters/setters...
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getSection() {
        return section;
    }

    public void setSection(Long section) {
        this.section = section;
    }

    public String getSectionName() { return sectionName; }
    public void setSectionName(String sectionName) { this.sectionName = sectionName; }

    public String getDocumentName() { return documentName; }
    public void setDocumentName(String documentName) { this.documentName = documentName; }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getThumbnailUrl() {
        return thumbnailUrl;
    }

    public void setThumbnailUrl(String thumbnailUrl) {
        this.thumbnailUrl = thumbnailUrl;
    }

    public Double getSequence() {
        return sequence;
    }

    public void setSequence(Double sequence) {
        this.sequence = sequence;
    }
}
