package com.wafer.portal.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wafer.portal.annotation.TrackChange;
import com.wafer.portal.dto.HelpAndSupportDocumentRequest;
import com.wafer.portal.dto.HelpAndSupportDocumentResponse;
import com.wafer.portal.model.HelpAndSupportDocument;
import com.wafer.portal.service.HelpAndSupportDocumentService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/v2/help-and-support")
public class HelpAndSupportDocumentController {

    private final HelpAndSupportDocumentService service;
    private final ObjectMapper objectMapper = new ObjectMapper();

    public HelpAndSupportDocumentController(HelpAndSupportDocumentService service) {
        this.service = service;
        objectMapper.findAndRegisterModules();
    }

    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Added", section = "Help and Support")
    public ResponseEntity<HelpAndSupportDocumentResponse> uploadDocument(
            @RequestParam("file") MultipartFile documentFile,
            @RequestParam(value = "thumbnail", required = false) MultipartFile thumbnailFile,
            @RequestParam("request") String requestJson
    ) throws JsonProcessingException {
        HelpAndSupportDocumentRequest request = objectMapper.readValue(requestJson, HelpAndSupportDocumentRequest.class);
        return service.uploadDocument(documentFile, thumbnailFile, request);
    }

    @GetMapping("/all")
    public ResponseEntity<Page<HelpAndSupportDocumentResponse>> getAllDocuments(Pageable pageable) {
        return service.getAllDocuments(pageable);
    }

    @GetMapping("/{id}")
    public ResponseEntity<HelpAndSupportDocumentResponse> getDocumentById(@PathVariable Long id) {
        return service.getDocumentById(id);
    }

    @PutMapping(value = "/{id}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Edited", section = "Help and Support")
    public ResponseEntity<HelpAndSupportDocumentResponse> updateDocument(
            @PathVariable Long id,
            @RequestParam(value = "file", required = false) MultipartFile documentFile,
            @RequestParam(value = "thumbnail", required = false) MultipartFile thumbnailFile,
            @RequestParam("request") String requestJson
    ) throws JsonProcessingException {
        HelpAndSupportDocumentRequest request = objectMapper.readValue(requestJson, HelpAndSupportDocumentRequest.class);
        return service.updateDocument(id, documentFile, thumbnailFile, request);
    }

    @DeleteMapping("/{id}")
    @TrackChange(action = "Deleted", section = "Help and Support")
    public ResponseEntity<HelpAndSupportDocument> deleteDocument(@PathVariable Long id) { // Note: Replace HelpAndSupportDocument with your actual Model name
        HelpAndSupportDocument result = service.deleteDocument(id);
        return (result != null)
                ? new ResponseEntity<>(result, HttpStatus.OK)
                : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}