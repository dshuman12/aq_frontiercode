package com.wafer.portal.controller;


import com.wafer.portal.annotation.TrackChange;
import com.wafer.portal.awsS3.S3Service;
import com.wafer.portal.dto.AnnouncementResponseDto;
import com.wafer.portal.model.Announcements;
import com.wafer.portal.service.AnnouncementsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@RestController
@RequestMapping("/api/v1/announcement")
public class AnnouncementsController {

    private static  final Logger logger =  LoggerFactory.getLogger(AnnouncementsController.class);

    private final AnnouncementsService announcementsService;
    private final S3Service s3Service;

    public AnnouncementsController(AnnouncementsService announcementsService, S3Service s3Service) {
        this.announcementsService = announcementsService;
        this.s3Service = s3Service;
    }

    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Added", section = "Announcements")
    public ResponseEntity<AnnouncementResponseDto> addAnnouncement(@RequestParam("content") String content,
                                                                   @RequestParam(name="url", required=false) String url,
                                                                   @RequestParam(name="sequence", required=false) Double sequence,
                                                                   @RequestPart("image") MultipartFile image,
                                                                   @RequestPart(name="thumbnail", required=false) MultipartFile thumbnail) {
        try {
            if (image.isEmpty()) {
                return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
            }
            String imageKey = s3Service.uploadFile(image, "Announcement-Images");
            String urlKey = null;

            if (thumbnail != null && !thumbnail.isEmpty()) {
                urlKey = s3Service.uploadFile(thumbnail, "Announcement-Thumbnail-Images");
            }
            Announcements announcements = new Announcements(imageKey, urlKey, content, url, sequence);
            Announcements savedAnnouncements = announcementsService.saveAnnouncement(announcements);
            String preSignedUrl = s3Service.generatePresignedUrl(savedAnnouncements.getImage());
            String prePresignedUrl1 = null;

            if (savedAnnouncements.getThumbnail() != null && !savedAnnouncements.getThumbnail().isEmpty()) {
                prePresignedUrl1 = s3Service.generatePresignedUrl(savedAnnouncements.getThumbnail());
            }
            AnnouncementResponseDto responseDto = new AnnouncementResponseDto(savedAnnouncements.getId(), savedAnnouncements.getContent(), preSignedUrl, prePresignedUrl1, savedAnnouncements.getUrl(), savedAnnouncements.getSequence(), savedAnnouncements.getCreatedBy(), savedAnnouncements.getCreationDate(), savedAnnouncements.getLastModifiedBy(), savedAnnouncements.getLastModifiedDate());
            return new ResponseEntity<>(responseDto, HttpStatus.CREATED);
        }  catch (IOException e) {
            e.printStackTrace();
            logger.error("IoException occurred while uploading Announcements", e);
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("Unexpected error occurred while uploading Announcements", e);
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/all")
    public ResponseEntity<Page<AnnouncementResponseDto>> getAllAnnouncements(Pageable pageable) {
        Page<Announcements> announcementList = announcementsService.getAllAnnouncements(pageable);

        Page<AnnouncementResponseDto> dtoPage = announcementList.map(announcements -> {
            String preSignedUrl = s3Service.generatePresignedUrl(announcements.getImage());
            String prePresignedUrl1 = null;

            if (announcements.getThumbnail() != null && !announcements.getThumbnail().isEmpty()) {
                prePresignedUrl1 = s3Service.generatePresignedUrl(announcements.getThumbnail());
            }
            return new AnnouncementResponseDto(announcements.getId(), announcements.getContent(), preSignedUrl, prePresignedUrl1, announcements.getUrl(), announcements.getSequence() ,announcements.getCreatedBy(), announcements.getCreationDate(), announcements.getLastModifiedBy(), announcements.getLastModifiedDate());
        });
        return dtoPage.isEmpty() ? new ResponseEntity<>(HttpStatus.NO_CONTENT) : new ResponseEntity<>(dtoPage, HttpStatus.OK);
    }


    @GetMapping("/{id}")
    public ResponseEntity<AnnouncementResponseDto> getAnnouncementById(@PathVariable Long id) {
        return announcementsService.getAnnouncementById(id)
                .map(announcements -> {
                    String preSignedUrl = s3Service.generatePresignedUrl(announcements.getImage());
                    String prePresignedUrl1 = null;

                    if (announcements.getThumbnail() != null && !announcements.getThumbnail().isEmpty()) {
                        prePresignedUrl1 = s3Service.generatePresignedUrl(announcements.getThumbnail());
                    }
                    AnnouncementResponseDto dto = new AnnouncementResponseDto(announcements.getId(), announcements.getContent(), preSignedUrl, prePresignedUrl1, announcements.getUrl(), announcements.getSequence(), announcements.getCreatedBy(), announcements.getCreationDate(), announcements.getLastModifiedBy(), announcements.getLastModifiedDate());
                    return new ResponseEntity<>(dto,HttpStatus.OK);
                })
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }


    @PutMapping(value = "/{id}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Edited", section = "Announcements")
    public ResponseEntity<AnnouncementResponseDto> updateAnnouncement(@PathVariable Long id,
                                                                      @RequestParam("content") String content,
                                                                      @RequestParam(name="url", required=false) String url,
                                                                      @RequestParam(name="sequence", required=false) Double sequence,
                                                                      @RequestPart(value = "image", required = false) MultipartFile image,
                                                                      @RequestPart(value = "thumbnail", required = false) MultipartFile thumbnail) {
        try {
            Announcements existingAnnouncement = announcementsService.getAnnouncementById(id).orElse(null);
            if (existingAnnouncement == null) {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }

            String updatedImageKey = existingAnnouncement.getImage();
            String updatedThumbnailKey = existingAnnouncement.getThumbnail();


            if (image != null && !image.isEmpty() && image.getOriginalFilename() != null
                    && !image.getOriginalFilename().isBlank()) {

                updatedImageKey = s3Service.updateFile(existingAnnouncement.getImage(),
                        image, "Announcement-Images");

                boolean isVideo = image.getContentType() != null &&
                        image.getContentType().startsWith("video");

                if (isVideo) {
                    if (thumbnail != null && !thumbnail.isEmpty()) {
                        updatedThumbnailKey = s3Service.updateFile(existingAnnouncement.getThumbnail(),
                                thumbnail, "Announcement-Thumbnail-Images");
                    }
                } else {
                    if (thumbnail != null && !thumbnail.isEmpty()) {
                        updatedThumbnailKey = s3Service.updateFile(existingAnnouncement.getThumbnail(),
                                thumbnail, "Announcement-Thumbnail-Images");
                    } else {
                        updatedThumbnailKey = null; // your rule
                    }
                }
            }
            else {

                if (thumbnail != null && !thumbnail.isEmpty()) {
                    updatedThumbnailKey = s3Service.updateFile(existingAnnouncement.getThumbnail(),
                            thumbnail, "Announcement-Thumbnail-Images");
                }

            }


            existingAnnouncement.setContent(content);
            existingAnnouncement.setUrl(url);
            existingAnnouncement.setSequence(sequence);
            existingAnnouncement.setImage(updatedImageKey);
            existingAnnouncement.setThumbnail(updatedThumbnailKey);

            Announcements updatedAnnouncement = announcementsService.saveAnnouncement(existingAnnouncement);

            String preSignedUrl = s3Service.generatePresignedUrl(updatedAnnouncement.getImage());
            String preSignedThumbnailUrl = null;

            if (updatedAnnouncement.getThumbnail() != null && !updatedAnnouncement.getThumbnail().isEmpty()) {
                preSignedThumbnailUrl = s3Service.generatePresignedUrl(updatedAnnouncement.getThumbnail());
            }

            AnnouncementResponseDto responseDto = new AnnouncementResponseDto(
                    updatedAnnouncement.getId(),
                    updatedAnnouncement.getContent(),
                    preSignedUrl,
                    preSignedThumbnailUrl,
                    updatedAnnouncement.getUrl(),
                    updatedAnnouncement.getSequence(),
                    updatedAnnouncement.getCreatedBy(),
                    updatedAnnouncement.getCreationDate(),
                    updatedAnnouncement.getLastModifiedBy(),
                    updatedAnnouncement.getLastModifiedDate()
            );

            return new ResponseEntity<>(responseDto, HttpStatus.OK);

        } catch (IOException e) {
            logger.error("IOException while updating announcements", e);
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            logger.error("Unexpected error while updating announcements", e);
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @DeleteMapping("/{id}")
    @TrackChange(action = "Deleted", section = "Announcements")
    public ResponseEntity<Announcements> deleteAnnouncement(@PathVariable Long id) {
        Announcements result = announcementsService.softDeleteAnnouncement(id);
        return (result != null)
                ? new ResponseEntity<>(result, HttpStatus.OK)
                : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}
