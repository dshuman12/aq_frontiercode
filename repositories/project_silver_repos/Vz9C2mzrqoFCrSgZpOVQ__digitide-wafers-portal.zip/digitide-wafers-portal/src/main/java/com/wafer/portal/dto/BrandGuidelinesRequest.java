package com.wafer.portal.dto;

import jakarta.validation.constraints.NotBlank;

public class BrandGuidelinesRequest {
    @NotBlank
    private String title;
    private Double sequence;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Double getSequence() {
        return sequence;
    }

    public void setSequence(Double sequence) {
        this.sequence = sequence;
    }
}
