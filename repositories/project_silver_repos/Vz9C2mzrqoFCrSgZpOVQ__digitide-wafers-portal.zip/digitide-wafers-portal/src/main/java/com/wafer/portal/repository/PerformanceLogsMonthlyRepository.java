package com.wafer.portal.repository;

import com.wafer.portal.model.PerformanceLogsMonthly;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PerformanceLogsMonthlyRepository
        extends JpaRepository<PerformanceLogsMonthly, Long> {

    List<PerformanceLogsMonthly> findByYearAndMonth(int year, int month);
}