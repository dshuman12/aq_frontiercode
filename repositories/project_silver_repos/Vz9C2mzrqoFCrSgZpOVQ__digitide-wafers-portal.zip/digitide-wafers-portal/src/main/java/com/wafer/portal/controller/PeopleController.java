package com.wafer.portal.controller;


import com.wafer.portal.annotation.TrackChange;
import com.wafer.portal.awsS3.S3Service;
import com.wafer.portal.dto.PeopleResponseDto;
import com.wafer.portal.model.People;
import com.wafer.portal.service.PeopleService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@RestController
@RequestMapping("/api/v1/people")
public class PeopleController {

    private static  final Logger logger =  LoggerFactory.getLogger(PeopleController.class);

    private final PeopleService peopleService;
    private final S3Service s3Service;

    public PeopleController(PeopleService peopleService, S3Service s3Service) {
        this.peopleService = peopleService;
        this.s3Service = s3Service;
    }

    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Added", section = "Employee Spotlight")
    public ResponseEntity<PeopleResponseDto> addPeople(@RequestParam("content") String content,
                                                       @RequestParam(name="url", required=false) String url,
                                                       @RequestPart("image")MultipartFile image,
                                                       @RequestPart(name="thumbnail", required=false) MultipartFile thumbnail,
                                                       @RequestParam(name="sequence", required=false) Double sequence) {
        try {
            if (image.isEmpty() || image.isEmpty()) {
                return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
            }
            String imageKey = s3Service.uploadFile(image, "People-Images");
            String urlKey = null;

            if (thumbnail != null && !thumbnail.isEmpty()) {
                urlKey = s3Service.uploadFile(thumbnail, "People-Thumbnail-Images");
            }



            People people = new People(imageKey, urlKey, content, url,sequence);
            People savedPeople = peopleService.savePeople(people);

            String preSignedUrl = s3Service.generatePresignedUrl(savedPeople.getImageUrl());
            String prePresignedUrl1 = null;

            if (savedPeople.getThumbnail() != null && !savedPeople.getThumbnail().isEmpty()) {
                prePresignedUrl1 = s3Service.generatePresignedUrl(savedPeople.getThumbnail());
            }

            PeopleResponseDto responseDto = new PeopleResponseDto(savedPeople.getId(), savedPeople.getContent(), preSignedUrl, prePresignedUrl1, savedPeople.getUrl(), savedPeople.getSequence(), savedPeople.getCreatedBy(), savedPeople.getCreationDate(),savedPeople.getLastModifiedBy(), savedPeople.getLastModifiedDate());
            return new ResponseEntity<>(responseDto, HttpStatus.CREATED);
        }catch (IOException e) {
            logger.error("IoException occurred while uploading People image", e);
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            logger.error("Unexpected error occurred while adding people", e);
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/all")
    public ResponseEntity<Page<PeopleResponseDto>> getAllPeople(Pageable pageable) {
        Page<People> peoplePage = peopleService.getAllPeople(pageable);

        Page<PeopleResponseDto> dtoPage = peoplePage.map(people -> {
            String preSignedUrl = s3Service.generatePresignedUrl(people.getImageUrl());
            String prePresignedUrl1 = null;

            if (people.getThumbnail() != null && !people.getThumbnail().isEmpty()) {
                prePresignedUrl1 = s3Service.generatePresignedUrl(people.getThumbnail());
            }

            return  new PeopleResponseDto(people.getId(), people.getContent(), preSignedUrl, prePresignedUrl1, people.getUrl(), people.getSequence(), people.getCreatedBy(), people.getCreationDate(),people.getLastModifiedBy(), people.getLastModifiedDate());
        });
        return dtoPage.isEmpty() ? new ResponseEntity<>(HttpStatus.NO_CONTENT) : new ResponseEntity<>(dtoPage, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<PeopleResponseDto> getPeopleById(@PathVariable Long id) {
        return peopleService.getPeopleById(id)
                .map(people ->{
                    String preSignedUrl = s3Service.generatePresignedUrl(people.getImageUrl());
                    String prePresignedUrl1 = null;

                    if (people.getThumbnail() != null && !people.getThumbnail().isEmpty()) {
                        prePresignedUrl1 = s3Service.generatePresignedUrl(people.getThumbnail());
                    }

                    PeopleResponseDto dto = new PeopleResponseDto(people.getId(), people.getContent(), preSignedUrl, prePresignedUrl1, people.getUrl(), people.getSequence(), people.getCreatedBy(), people.getCreationDate(),people.getLastModifiedBy(), people.getLastModifiedDate());
                    return new ResponseEntity<>(dto, HttpStatus.OK);
                }).orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }


    @PutMapping(value = "/{id}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Edited", section = "Employee Spotlight")
    public ResponseEntity<PeopleResponseDto> updatePeople(@PathVariable Long id,
                                                          @RequestParam("content") String content,
                                                          @RequestParam(name="url", required=false) String url,
                                                          @RequestPart(value = "image", required = false) MultipartFile image,
                                                          @RequestPart(value = "thumbnail", required = false) MultipartFile thumbnail,
                                                          @RequestParam(name="sequence", required=false) Double sequence) {
        try {
            People existing = peopleService.getPeopleById(id).orElse(null);
            if (existing == null) {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
            String updatedImageKey = existing.getImageUrl();
            String updatedThumbnailKey = existing.getThumbnail();

            if (image != null && !image.isEmpty() && image.getOriginalFilename() != null
                    && !image.getOriginalFilename().isBlank()) {

                updatedImageKey = s3Service.updateFile(existing.getImageUrl(), image, "People-Images");

                boolean isVideo = image.getContentType() != null &&
                        image.getContentType().startsWith("video");

                if (isVideo) {
                    if (thumbnail != null && !thumbnail.isEmpty()) {
                        updatedThumbnailKey = s3Service.updateFile(existing.getThumbnail(), thumbnail, "People-Thumbnail-Images");
                    }
                } else {
                    if (thumbnail != null && !thumbnail.isEmpty()) {
                        updatedThumbnailKey = s3Service.updateFile(existing.getThumbnail(), thumbnail, "People-Thumbnail-Images");
                    } else {
                        updatedThumbnailKey = null; // your rule
                    }
                }
            }
            else {
                if (thumbnail != null && !thumbnail.isEmpty()) {
                    updatedThumbnailKey = s3Service.updateFile(existing.getThumbnail(), thumbnail, "People-Thumbnail-Images");
                }
            }

            existing.setImageUrl(updatedImageKey);
            existing.setThumbnail(updatedThumbnailKey);
            existing.setContent(content);
            existing.setUrl(url);
            existing.setSequence(sequence);

            People updatedPeople = peopleService.savePeople(existing);

            String preSignedUrl = s3Service.generatePresignedUrl(updatedPeople.getImageUrl());
            String prePresignedUrl1 = null;

            if (updatedPeople.getThumbnail() != null && !updatedPeople.getThumbnail().isEmpty()) {
                prePresignedUrl1 = s3Service.generatePresignedUrl(updatedPeople.getThumbnail());
            }

            PeopleResponseDto responseDto = new PeopleResponseDto(updatedPeople.getId(), updatedPeople.getContent(), preSignedUrl, prePresignedUrl1, updatedPeople.getUrl(), updatedPeople.getSequence(), updatedPeople.getCreatedBy(), updatedPeople.getCreationDate(),updatedPeople.getLastModifiedBy(), updatedPeople.getLastModifiedDate());
            return new ResponseEntity<>(responseDto, HttpStatus.OK);
        }catch (IOException e) {
            e.printStackTrace();
            logger.error("IoException occurred while updating people image", e);
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("Unexpected error occurred while updating people image", e);
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/{id}")
    @TrackChange(action = "Deleted", section = "Employee Spotlight")
    public ResponseEntity<People> deletePeople(@PathVariable Long id) {
        try {
            People result = peopleService.softDeletePeople(id);
            return (result != null)
                    ? new ResponseEntity<>(result, HttpStatus.OK)
                    : new ResponseEntity<>(HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            logger.error("Failed to soft delete people with ID: {}", id, e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
