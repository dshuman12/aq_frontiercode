package com.wafer.portal.service;

import com.wafer.portal.awsS3.S3Service;
import com.wafer.portal.dto.HelpAndSupportDocumentRequest;
import com.wafer.portal.dto.HelpAndSupportDocumentResponse;
import com.wafer.portal.model.HelpAndSupportDocument;
import com.wafer.portal.repository.HelpAndSupportDocumentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@Service
public class HelpAndSupportDocumentService {

    private static final String DOCUMENT_FOLDER = "Help-and-Support-Documents";
    private static final String THUMBNAIL_FOLDER = "Help-and-Support-Thumbnails";

    private final HelpAndSupportDocumentRepository repository;
    private final S3Service s3Service;

    @Autowired
    public HelpAndSupportDocumentService(HelpAndSupportDocumentRepository repository, S3Service s3Service) {
        this.repository = repository;
        this.s3Service = s3Service;
    }

    public ResponseEntity<HelpAndSupportDocumentResponse> uploadDocument(
            MultipartFile documentFile,
            MultipartFile thumbnailFile,
            HelpAndSupportDocumentRequest request) {

        if (documentFile == null || documentFile.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

        try {
            String documentKey = s3Service.uploadFile(documentFile, DOCUMENT_FOLDER);

            String thumbnailKey = null;
            String fileName = documentFile.getOriginalFilename() != null ? documentFile.getOriginalFilename().toLowerCase() : "";
            if (fileName.endsWith(".mp4") && thumbnailFile != null && !thumbnailFile.isEmpty()) {
                thumbnailKey = s3Service.uploadFile(thumbnailFile, THUMBNAIL_FOLDER);
            }

            HelpAndSupportDocument newDocument = new HelpAndSupportDocument(
                    request.getDescription(),
                    documentKey,
                    request.getSequence(),
                    thumbnailKey
            );

            HelpAndSupportDocument saved = repository.save(newDocument);
            return new ResponseEntity<>(mapToResponse(saved), HttpStatus.CREATED);

        } catch (IOException e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Page<HelpAndSupportDocumentResponse>> getAllDocuments(Pageable pageable) {

        Page<HelpAndSupportDocument> documentPage = repository.findAllByIsDeletedFalseOrderBySequenceAsc(pageable);
        Page<HelpAndSupportDocumentResponse> dtoPage = documentPage.map(this::mapToResponse);

        return dtoPage.isEmpty() ? new ResponseEntity<>(HttpStatus.NO_CONTENT) : new ResponseEntity<>(dtoPage, HttpStatus.OK);
    }

    public ResponseEntity<HelpAndSupportDocumentResponse> getDocumentById(Long id) {
        return repository.findByIdAndIsDeletedFalse(id)
                .map(document -> new ResponseEntity<>(mapToResponse(document), HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    public ResponseEntity<HelpAndSupportDocumentResponse> updateDocument(
            Long id,
            MultipartFile documentFile,
            MultipartFile thumbnailFile,
            HelpAndSupportDocumentRequest request) {

        return repository.findByIdAndIsDeletedFalse(id)
                .map(existingDocument -> {
                    try {
                        String updatedDocumentKey = existingDocument.getDocumentKey();
                        String thumbnailKey = existingDocument.getThumbnail();

                        if (documentFile != null && !documentFile.isEmpty()) {
                            updatedDocumentKey = s3Service.updateFile(
                                    existingDocument.getDocumentKey(),
                                    documentFile,
                                    DOCUMENT_FOLDER
                            );

                            String fileName = documentFile.getOriginalFilename() != null ?
                                    documentFile.getOriginalFilename().toLowerCase() : "";

                            if (!fileName.endsWith(".mp4")) {
                                thumbnailKey = null;
                            } else {
                                // If it IS an mp4, handle the thumbnail upload/update
                                if (thumbnailFile != null && !thumbnailFile.isEmpty()) {
                                    if (existingDocument.getThumbnail() != null) {
                                        thumbnailKey = s3Service.updateFile(existingDocument.getThumbnail(), thumbnailFile, THUMBNAIL_FOLDER);
                                    } else {
                                        thumbnailKey = s3Service.uploadFile(thumbnailFile, THUMBNAIL_FOLDER);
                                    }
                                }
                            }
                        } else {
                            if (thumbnailFile != null && !thumbnailFile.isEmpty()) {
                                if (existingDocument.getThumbnail() != null) {
                                    thumbnailKey = s3Service.updateFile(existingDocument.getThumbnail(), thumbnailFile, THUMBNAIL_FOLDER);
                                } else {
                                    thumbnailKey = s3Service.uploadFile(thumbnailFile, THUMBNAIL_FOLDER);
                                }
                            }
                        }

                        existingDocument.setDescription(request.getDescription());
                        existingDocument.setSequence(request.getSequence());
                        existingDocument.setDocumentKey(updatedDocumentKey);
                        existingDocument.setThumbnail(thumbnailKey);

                        HelpAndSupportDocument updated = repository.save(existingDocument);
                        return new ResponseEntity<>(mapToResponse(updated), HttpStatus.OK);

                    } catch (IOException e) {
                        return new ResponseEntity<HelpAndSupportDocumentResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
                    }
                })
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    public HelpAndSupportDocument deleteDocument(Long id) {
        return repository.findByIdAndIsDeletedFalse(id)
                .map(document -> {
                    document.setDeleted(true);
                    return repository.save(document);
                }).orElse(null);
    }

    private HelpAndSupportDocumentResponse mapToResponse(HelpAndSupportDocument document) {
        String file = null;
        if (document.getDocumentKey() != null) {
            file = s3Service.generatePresignedUrl(document.getDocumentKey());
        }

        String thumbnailUrl = (document.getThumbnail() != null) ?
                s3Service.generatePresignedUrl(document.getThumbnail()) : null;

        return new HelpAndSupportDocumentResponse(
                document.getId(),
                document.getDescription(),
                file,
                thumbnailUrl,
                document.getSequence(),
                document.getCreatedBy(),
                document.getCreationDate(),
                document.getLastModifiedBy(),
                document.getLastModifiedDate()
        );
    }
}