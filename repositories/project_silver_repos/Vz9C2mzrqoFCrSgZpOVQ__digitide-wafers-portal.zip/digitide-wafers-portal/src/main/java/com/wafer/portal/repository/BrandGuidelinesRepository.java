package com.wafer.portal.repository;

import com.wafer.portal.model.BrandGuidelines;
import com.wafer.portal.model.People;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BrandGuidelinesRepository extends JpaRepository<BrandGuidelines, Long> {
    Page<BrandGuidelines> findByIsDeletedFalse(Pageable pageable);
    Optional<BrandGuidelines> findByIdAndIsDeletedFalse(Long id);

    @Query("SELECT b FROM BrandGuidelines b WHERE b.isDeleted = false ORDER BY " +
            "CASE WHEN b.sequence IS NULL THEN 1 ELSE 0 END, b.sequence ASC")
    Page<BrandGuidelines> findAllOrderedBySequence(Pageable pageable);

    @Query("SELECT b FROM BrandGuidelines b WHERE b.isDeleted = false AND " +
            "LOWER(b.title) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    Page<BrandGuidelines> searchBrandGuidelines(@Param("keyword") String keyword, Pageable pageable);

}
