package com.wafer.portal.repository;

import com.wafer.portal.model.People;
import com.wafer.portal.model.PicOfTheDay;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PicOfTheDayRepository extends JpaRepository<PicOfTheDay, Long> {
    Optional<PicOfTheDay> findTopByIsDeletedFalseOrderByCreationDateDesc();

    @Query("SELECT p FROM PicOfTheDay p WHERE p.isDeleted = false AND " +
            "(LOWER(p.title) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(p.designation) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    List<PicOfTheDay> searchPicOfTheDay(@Param("keyword") String keyword);

    List<PicOfTheDay> findByIsDeletedFalse();

}
