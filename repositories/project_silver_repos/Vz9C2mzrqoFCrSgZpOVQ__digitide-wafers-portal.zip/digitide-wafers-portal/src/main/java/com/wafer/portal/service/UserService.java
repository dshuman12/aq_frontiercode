package com.wafer.portal.service;

import com.wafer.portal.model.Roles;
import com.wafer.portal.model.User;
import com.wafer.portal.repository.RoleRepository;
import com.wafer.portal.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class UserService {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;

    public UserService(UserRepository userRepository, RoleRepository roleRepository) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
    }

    /**
     * Assigns roles to an existing user based on SAML groups
     */
    public void updateUserRolesFromGroups(User user, List<String> groups) {
        user.getRoles().clear();

        for (String group : groups) {
            Roles role = roleRepository.findByName(mapGroupToRole(group));
            if (role != null) {
                user.getRoles().add(role);
            }
        }

        userRepository.save(user);
    }

    /**
     * Assigns roles to a new user based on SAML groups
     */
    public void assignRolesFromGroups(User user, List<String> groups) {
        for (String group : groups) {
            Roles role = roleRepository.findByName(mapGroupToRole(group));
            if (role != null) {
                user.getRoles().add(role);
            }
        }

        userRepository.save(user);
    }

    /**
     * Assigns a default role to a user if no SAML groups are present
     */
    public void assignDefaultRole(User user) {
        Roles defaultRole = roleRepository.findByName("ROLE_USER");
        if (defaultRole != null) {
            user.getRoles().add(defaultRole);
        }
        userRepository.save(user);
    }

    /**
     * Maps a SAML group name to your application's role
     */
    private String mapGroupToRole(String group) {
        switch (group.toLowerCase()) {
            case "admin":
                return "ROLE_ADMIN";
            case "manager":
                return "ROLE_MANAGER";
            default:
                return "ROLE_USER";
        }
    }

}
