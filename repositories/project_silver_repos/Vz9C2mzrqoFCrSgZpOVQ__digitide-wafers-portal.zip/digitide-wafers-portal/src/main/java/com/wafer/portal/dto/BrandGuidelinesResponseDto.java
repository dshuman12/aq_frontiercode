package com.wafer.portal.dto;

import java.time.LocalDateTime;

public class BrandGuidelinesResponseDto {

    private Long id;
    private String title;
    private String imageUrl;
    private Double sequence;



    public BrandGuidelinesResponseDto(Long id, String title, String documentUrl, Double sequence) {
        this.id = id;
        this.title = title;
        this.imageUrl = documentUrl;
        this.sequence = sequence;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public Double getSequence() {
        return sequence;
    }

    public void setSequence(Double sequence) {
        this.sequence = sequence;
    }

}
