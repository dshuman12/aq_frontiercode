package com.wafer.portal.controller;

import com.wafer.portal.dto.response.GlobalSearchResponseDTO;
import com.wafer.portal.service.GlobalSearchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/api/v2/search")
public class GlobalSearchController {

    private final GlobalSearchService globalSearchService;

    @Autowired
    public GlobalSearchController(GlobalSearchService globalSearchService) {
        this.globalSearchService = globalSearchService;
    }


    @GetMapping
    public ResponseEntity<GlobalSearchResponseDTO> search(
            @RequestParam("query") String query,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        return ResponseEntity.ok(
                globalSearchService.searchAll(query, page, size)
        );
    }


}
