package com.wafer.portal.service;


import com.wafer.portal.awsS3.S3Service;
import com.wafer.portal.dto.QuickLinkHeaderResponse;
import com.wafer.portal.dto.QuickLinkSubHeaderRequest;
import com.wafer.portal.dto.QuickLinkSubHeaderResponseDTO;
import com.wafer.portal.model.LinkType;
import com.wafer.portal.model.QuickLinkHeader;
import com.wafer.portal.model.QuickLinkSubHeader;
import com.wafer.portal.repository.QuickLinkHeaderRepository;
import com.wafer.portal.repository.QuickLinkSubHeaderRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

@Service
public class QuickLinkHeaderService {

    private static final String QUICK_LINKS_FOLDER = "Quick_Links_Pdf";

    private QuickLinkHeaderRepository repository;
    private S3Service s3Service;
    private QuickLinkSubHeaderRepository quickLinkSubHeaderRepository;

    @Autowired
    public QuickLinkHeaderService(QuickLinkHeaderRepository repository, S3Service s3Service, QuickLinkSubHeaderRepository quickLinkSubHeaderRepository) {
        this.repository = repository;
        this.s3Service = s3Service;
        this.quickLinkSubHeaderRepository = quickLinkSubHeaderRepository;
    }

    public ResponseEntity<QuickLinkHeaderResponse> createQuickLinkHeader(MultipartFile pdf, QuickLinkSubHeaderRequest request) {
        try {
            String urlKey = null;

            if (pdf != null && !pdf.isEmpty()) {
                urlKey = s3Service.uploadFile(pdf, QUICK_LINKS_FOLDER);
            }

            QuickLinkHeader quickLink = new QuickLinkHeader(request.getTitle(), urlKey);
            QuickLinkHeader saved = repository.save(quickLink);

            return new ResponseEntity<>(mapToResponseDto(saved), HttpStatus.CREATED);
        } catch (IOException e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Page<QuickLinkHeaderResponse>> getAllQuickLinkHeader(Pageable pageable) {
        Page<QuickLinkHeader> qls = repository.findByIsDeletedFalse(pageable);

        Page<QuickLinkHeaderResponse> dtoPage = qls.map(this::mapToResponseDto);
        return dtoPage.isEmpty() ? new ResponseEntity<>(HttpStatus.NO_CONTENT) : new ResponseEntity<>(dtoPage, HttpStatus.OK);
    }

    public ResponseEntity<QuickLinkHeaderResponse> getQuickLinkHeaderById(Long id) {
        return repository.findByIdAndIsDeletedFalse(id)
                .map(news -> new ResponseEntity<>(mapToResponseDto(news), HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    public ResponseEntity<QuickLinkHeaderResponse> updateQuickLinkHeader(Long id, MultipartFile pdf, QuickLinkSubHeaderRequest request) {
        return repository.findByIdAndIsDeletedFalse(id)
                .map(existingQls -> {
                    try {
                        // If a new PDF is provided, replace it in S3
                        if (pdf != null && !pdf.isEmpty()) {
                            String newPdfKey = s3Service.updateFile(existingQls.getUrl(), pdf, QUICK_LINKS_FOLDER);
                            existingQls.setUrl(newPdfKey);
                        }else{
                            existingQls.setUrl(null);
                        }
                        // Always allow title updates
                        existingQls.setTitle(request.getTitle()!=null && !request.getTitle().isEmpty()? request.getTitle() : existingQls.getTitle());

                        QuickLinkHeader updated = repository.save(existingQls);
                        return new ResponseEntity<>(mapToResponseDto(updated), HttpStatus.OK);
                    } catch (IOException e) {
                        return new ResponseEntity<QuickLinkHeaderResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
                    }
                })
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @Transactional
    public QuickLinkHeader deleteQuickLinkHeader(Long id) {
        Optional<QuickLinkHeader> headerOpt = repository.findByIdAndIsDeletedFalse(id);
        if (headerOpt.isEmpty()) {
            return null; // Return null to trigger 404 in Controller
        }

        QuickLinkHeader header = headerOpt.get();

        // Cascading soft delete for sub-headers
        List<QuickLinkSubHeader> subHeaders =
                quickLinkSubHeaderRepository.findAllByHeaderAndIsDeletedFalse(header);

        if (!subHeaders.isEmpty()) {
            subHeaders.forEach(sh -> sh.setDeleted(true));
            quickLinkSubHeaderRepository.saveAll(subHeaders);
        }

        header.setDeleted(true);
        // Returning the saved object allows the LoggingAspect to see the file/link info
        return repository.save(header);
    }

    private QuickLinkHeaderResponse mapToResponseDto(QuickLinkHeader ql) {

        String headerUrl = null;
        if (ql.getUrl() != null && !ql.getUrl().isBlank()) {
            headerUrl = s3Service.generatePresignedUrl(ql.getUrl());
        }

        List<QuickLinkSubHeaderResponseDTO> subHeaderResponses =
                ql.getSubHeaderList()
                        .stream()
                        .filter(sub -> !sub.isDeleted())
                        .map(this::mapSubHeaderToDto)
                        .toList();

        return new QuickLinkHeaderResponse(
                ql.getId(),
                ql.getTitle(),
                headerUrl,
                subHeaderResponses,
                ql.getCreatedBy(),
                ql.getCreationDate(),
                ql.getLastModifiedBy(),
                ql.getLastModifiedDate()
        );
    }

    private QuickLinkSubHeaderResponseDTO mapSubHeaderToDto(QuickLinkSubHeader sub) {

        String finalUrl;

        if (sub.getLinkType() == LinkType.FILE) {
            finalUrl = s3Service.generatePresignedUrl(sub.getUrl());
        } else {
            finalUrl = sub.getUrl();
        }

        return new QuickLinkSubHeaderResponseDTO(
                sub.getId(),
                sub.getTitle(),
                sub.getHeader() != null ? sub.getHeader().getId() : null,
                sub.getHeader() != null ? sub.getHeader().getTitle() : null,
                finalUrl,
                sub.getLinkType(),
                sub.getCreatedBy(),
                sub.getCreationDate(),
                sub.getLastModifiedBy(),
                sub.getLastModifiedDate()
        );
    }



}

