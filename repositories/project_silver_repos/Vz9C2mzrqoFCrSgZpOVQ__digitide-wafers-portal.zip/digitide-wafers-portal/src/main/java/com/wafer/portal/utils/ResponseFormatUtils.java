package com.wafer.portal.utils;

import com.wafer.portal.dto.response.BasicResponse;
import org.springframework.http.HttpStatus;

public class ResponseFormatUtils {


    public static <T> BasicResponse<T> createErrorResponse(BasicResponse<T> basicResponse, String message) {
        basicResponse.setError(message);
        if (null == basicResponse.getStatusCode()) { //condition to check
            basicResponse.setStatusCode(HttpStatus.OK.value());
        }
        basicResponse.setStatus(Boolean.FALSE);
        return basicResponse;
    }

    public static <T> BasicResponse<T> createSuccessResponse(BasicResponse<T> basicResponse, String message) {
        basicResponse.setMessage(message);
        basicResponse.setStatusCode(HttpStatus.OK.value());
        basicResponse.setStatus(Boolean.TRUE);
        return basicResponse;
    }
}
