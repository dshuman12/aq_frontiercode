package com.wafer.portal.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wafer.portal.annotation.TrackChange;
import com.wafer.portal.dto.*;
import com.wafer.portal.model.RewardsSection;
import com.wafer.portal.model.RewardsSubsection;
import com.wafer.portal.model.RewardsandRecognition;
import com.wafer.portal.service.RewardsandRecognitionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Controller
@RestController
@RequestMapping("/api/v2/rewards-and-recognition")
public class RewardsandRecognitionController {

    private final RewardsandRecognitionService RewardsandRecognitionService;

    @Autowired
    public RewardsandRecognitionController(RewardsandRecognitionService rewardsandRecognitionService) {
        this.RewardsandRecognitionService = rewardsandRecognitionService;
    }

    @PostMapping(value = "/create", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Added", section = "Rewards and Recognition")
    public ResponseEntity<RewardsandRecognitionResponse> createRewardsandRecognition(
            @RequestParam("image") MultipartFile image,
            @RequestParam("request") String requestJson) throws JsonProcessingException {
        RewardsandRecognitionRequest request = new ObjectMapper().readValue(requestJson, RewardsandRecognitionRequest.class);
        return RewardsandRecognitionService.createRewardsandRecognition(image,request);
    }

    @GetMapping("/all")
    public ResponseEntity<Page<RewardsandRecognitionResponse>> getAllRewardsandRecognition(Pageable pageable) {
        return RewardsandRecognitionService.getAllRewardsandRecognition(pageable);
    }

    @GetMapping("/{id}")
    public ResponseEntity<RewardsandRecognitionResponse> getRewardsandRecognitionById(@PathVariable Long id) {
        return RewardsandRecognitionService.getRewardsandRecognitionById(id);
    }

    @PutMapping(value = "/{id}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Edited", section = "Rewards and Recognition")
    public ResponseEntity<RewardsandRecognitionResponse> updateRewardsandRecognition(
            @PathVariable Long id,
            @RequestParam(value = "image", required = false) MultipartFile image,
            @RequestParam("request") String requestJson) throws JsonProcessingException {

        RewardsandRecognitionRequest request = new ObjectMapper().readValue(requestJson, RewardsandRecognitionRequest.class);
        return RewardsandRecognitionService.updateRewardsandRecognition(id, image, request);
    }

    @DeleteMapping("/{id}")
    @TrackChange(action = "Deleted", section = "Rewards and Recognition")
    public ResponseEntity<RewardsandRecognition> deleteRewardsandRecognition(@PathVariable Long id) {
        RewardsandRecognition result = RewardsandRecognitionService.deleteRewardsandRecognition(id);
        return (result != null)
                ? new ResponseEntity<>(result, HttpStatus.OK)
                : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

//    @GetMapping("/allSectionDocuments")
//    public ResponseEntity<List<GroupedRewardsResponse>> getAllGrouped() {
//        return ResponseEntity.ok(RewardsandRecognitionService.getGroupedRewards());
//    }

    @GetMapping("/allSectionDocuments")
    public ResponseEntity<Page<GroupedRewardsResponse>> getAllGrouped(Pageable pageable) {
        return RewardsandRecognitionService.getGroupedRewards(pageable);
    }


    @PostMapping("/addSection")
    @TrackChange(action = "Added", section = "Rewards and Recognition Section")
    public ResponseEntity<RewardsSectionResponse> createSection(
            @RequestBody RewardsSectionRequest request) {
        return RewardsandRecognitionService.addSection(request);
    }

    @GetMapping("/allSections")
    public ResponseEntity<Page<RewardsSection>> getAllSections(Pageable pageable) {
        return RewardsandRecognitionService.getAllSections(pageable);
    }



    @PostMapping("/addSubsection")
    @TrackChange(action = "Added", section = "Rewards and Recognition Sub Section")
    public ResponseEntity<RewardsSubsectionResponse> createSubsection(
            @RequestBody RewardsSubsectionRequest request) {
        return RewardsandRecognitionService.addSubsection(request);
    }

    @GetMapping("/allSubsections")
    public ResponseEntity<Page<RewardsSubsection>> getAllSubsections(Pageable pageable) {
        return RewardsandRecognitionService.getAllSubsections(pageable);
    }

    @PutMapping("/updateSection/{id}")
    @TrackChange(action = "Edited", section = "Rewards and Recognition Section")
    public ResponseEntity<RewardsSectionResponse> updateSection(
            @PathVariable Long id,
            @RequestParam("request") String requestJson) throws JsonProcessingException{
        RewardsSectionRequest request = new ObjectMapper().readValue(requestJson, RewardsSectionRequest.class);
        return RewardsandRecognitionService.updateSection(id, request);
    }

    @PutMapping("/updateSubsection/{id}")
    @TrackChange(action = "Edited", section = "Rewards and Recognition Sub Section")
    public ResponseEntity<RewardsSubsectionResponse> updateSubsection(
            @PathVariable Long id,
            @RequestParam("request") String requestJson) throws JsonProcessingException{
        RewardsSubsectionRequest request = new ObjectMapper().readValue(requestJson, RewardsSubsectionRequest.class);
        return RewardsandRecognitionService.updateSubsection(id, request);
    }



}