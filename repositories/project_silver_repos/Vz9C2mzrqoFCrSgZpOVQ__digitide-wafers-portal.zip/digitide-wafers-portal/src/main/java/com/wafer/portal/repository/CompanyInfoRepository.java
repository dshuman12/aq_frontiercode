package com.wafer.portal.repository;

import com.wafer.portal.model.CompanyInfo;
import com.wafer.portal.model.People;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;


@Repository
public interface CompanyInfoRepository extends JpaRepository<CompanyInfo,Long> {
    Page<CompanyInfo> findByIsDeletedFalse(Pageable pageable);
    Optional<CompanyInfo> findByIdAndIsDeletedFalse(Long aLong);

    Optional<CompanyInfo> findTopByIsDeletedFalseOrderByCreationDateDesc();

    @Query("SELECT c FROM CompanyInfo c " +
            "WHERE c.isDeleted = false AND " +
            "(LOWER(c.title) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
            "OR LOWER(c.description) LIKE LOWER(CONCAT('%', :keyword, '%'))) ")
    Page<CompanyInfo> searchCompanyInfo(@Param("keyword") String keyword, Pageable pageable);

}
