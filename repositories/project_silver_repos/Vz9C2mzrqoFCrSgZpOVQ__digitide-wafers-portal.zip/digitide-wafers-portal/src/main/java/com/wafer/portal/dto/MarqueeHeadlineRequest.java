package com.wafer.portal.dto;

public class MarqueeHeadlineRequest {

    private String description;// can be blank or null

    public MarqueeHeadlineRequest() {
    }

    public MarqueeHeadlineRequest(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}

