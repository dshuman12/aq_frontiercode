package com.wafer.portal.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wafer.portal.annotation.TrackChange;
import com.wafer.portal.dto.SurveyRequest;
import com.wafer.portal.dto.SurveyResponseDto;
import com.wafer.portal.model.Survey;
import com.wafer.portal.service.SurveyService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/v1/surveys")
public class SurveyController {

    private final SurveyService surveyService;

    public SurveyController(SurveyService surveyService) {
        this.surveyService = surveyService;
    }

    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Added", section = "Survey")
    public ResponseEntity<SurveyResponseDto> createSurvey(
            @RequestParam("image") MultipartFile image,
            @RequestParam("request") String requestJson) throws Exception {
        SurveyRequest request = new ObjectMapper().readValue(requestJson, SurveyRequest.class);
        return surveyService.createSurvey(image, request);
    }

    @GetMapping("/all")
    public ResponseEntity<Page<SurveyResponseDto>> getAllSurveys(Pageable pageable) {
        return surveyService.getAllSurveys(pageable);
    }

    @GetMapping("/{id}")
    public ResponseEntity<SurveyResponseDto> getSurveyById(@PathVariable Long id) {
        return surveyService.getSurveyById(id);
    }

    @PutMapping(value = "/{id}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Edited", section = "Survey")
    public ResponseEntity<SurveyResponseDto> updateSurvey(
            @PathVariable Long id,
            @RequestParam(value = "image", required = false) MultipartFile image,
            @RequestParam("request") String requestJson) throws Exception {
        SurveyRequest request = new ObjectMapper().readValue(requestJson, SurveyRequest.class);
        return surveyService.updateSurvey(id, image, request);
    }

    @PostMapping("/{id}/end")
    @TrackChange(action = "Added", section = "Survey end")
    public ResponseEntity<SurveyResponseDto> endSurvey(@PathVariable Long id) {
        return surveyService.endSurvey(id);
    }

    @PutMapping("/{id}/status")
    @TrackChange(action = "Edited", section = "Survey status")
    public ResponseEntity<SurveyResponseDto> updateSurveyStatus(
            @PathVariable Long id,
            @RequestParam("status") boolean status) {
        return surveyService.updateSurveyStatus(id, status);
    }



    @DeleteMapping("/{id}")
    @TrackChange(action = "Deleted", section = "Survey")
    public ResponseEntity<Survey> deleteSurvey(@PathVariable Long id) {
        Survey result = surveyService.deleteSurvey(id);
        return (result != null)
                ? new ResponseEntity<>(result, HttpStatus.OK)
                : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}
