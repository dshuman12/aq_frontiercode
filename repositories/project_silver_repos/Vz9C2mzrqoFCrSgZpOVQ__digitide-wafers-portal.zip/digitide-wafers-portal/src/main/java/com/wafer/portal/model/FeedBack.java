package com.wafer.portal.model;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.wafer.portal.audit.Auditable;
import jakarta.persistence.*;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "feedbacks")
public class FeedBack extends Auditable<String> implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String feedbackDescription;
    private String attachment;

    private LocalDate feedbackDate;
    private boolean actionTaken;
    private String uploadedDocument;


    @OneToMany(
            mappedBy = "feedback",
            cascade = CascadeType.ALL,
            orphanRemoval = true
    )
    @OrderBy("createdDate DESC")
    @JsonManagedReference
    private List<FeedbackAdminRemark> adminRemarks = new ArrayList<>();



    @Column(name = "mail_sent", nullable = false)
    private boolean mailSent = false;

    @Column(name = "ticket_closed", nullable = false)
    private boolean ticketClosed = false;

    @Column(name = "is_deleted",nullable = false)
    private boolean isDeleted;

    public FeedBack() {
    }

    public FeedBack(String feedbackDescription, String attachment) {
        this.feedbackDescription = feedbackDescription;
        this.attachment = attachment;
    }


    public FeedBack(String feedbackDescription, String attachment, LocalDate feedbackDate, boolean actionTaken, String uploadedDocument, boolean isDeleted) {
        this.feedbackDescription = feedbackDescription;
        this.attachment = attachment;
        this.feedbackDate = feedbackDate;
        this.actionTaken = actionTaken;
        this.uploadedDocument = uploadedDocument;
        this.isDeleted = isDeleted;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFeedbackDescription() {
        return feedbackDescription;
    }

    public void setFeedbackDescription(String feedbackDescription) {
        this.feedbackDescription = feedbackDescription;
    }

    public String getAttachment() {
        return attachment;
    }

    public void setAttachment(String attachment) {
        this.attachment = attachment;
    }

    public LocalDate getFeedbackDate() {
        return feedbackDate;
    }

    public void setFeedbackDate(LocalDate feedbackDate) {
        this.feedbackDate = feedbackDate;
    }

    public boolean isActionTaken() {
        return actionTaken;
    }

    public void setActionTaken(boolean actionTaken) {
        this.actionTaken = actionTaken;
    }

    public String getUploadedDocument() {
        return uploadedDocument;
    }

    public void setUploadedDocument(String uploadedDocument) {
        this.uploadedDocument = uploadedDocument;
    }

//    public String getAdminRemarks() {
//        return adminRemarks;
//    }
//
//    public void setAdminRemarks(String adminRemarks) {
//        this.adminRemarks = adminRemarks;
//    }


    public List<FeedbackAdminRemark> getAdminRemarks() {
        return adminRemarks;
    }

    public void setAdminRemarks(List<FeedbackAdminRemark> adminRemarks) {
        this.adminRemarks = adminRemarks;
    }

    public boolean isMailSent() {
        return mailSent;
    }

    public void setMailSent(boolean mailSent) {
        this.mailSent = mailSent;
    }

    public boolean isTicketClosed() {
        return ticketClosed;
    }

    public void setTicketClosed(boolean ticketClosed) {
        this.ticketClosed = ticketClosed;
    }

    public boolean isDeleted() {
        return isDeleted;
    }

    public void setDeleted(boolean deleted) {
        isDeleted = deleted;
    }
}
