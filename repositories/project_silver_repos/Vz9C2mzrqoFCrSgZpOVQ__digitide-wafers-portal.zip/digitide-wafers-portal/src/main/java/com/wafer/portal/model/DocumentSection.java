package com.wafer.portal.model;

import com.wafer.portal.audit.Auditable;
import jakarta.persistence.*;

import java.io.Serializable;

@Entity
@Table(name = "document_section")
public class DocumentSection  extends Auditable<String> implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "section_name", nullable = false, unique = true)
    private String sectionName;

    @Column(name = "is_deleted", nullable = false)
    private boolean isDeleted = false;

    public DocumentSection() {}

    public DocumentSection(String sectionName) {
        this.sectionName = sectionName;
        this.isDeleted = false;
    }

    // getters & setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getSectionName() { return sectionName; }
    public void setSectionName(String sectionName) { this.sectionName = sectionName; }


    public boolean isDeleted() { return isDeleted; }
    public void setIsDeleted(boolean deleted) { this.isDeleted = deleted; }

}