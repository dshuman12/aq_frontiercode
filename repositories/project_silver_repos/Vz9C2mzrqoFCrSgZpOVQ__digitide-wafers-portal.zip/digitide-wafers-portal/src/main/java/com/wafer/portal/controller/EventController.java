package com.wafer.portal.controller;

import com.wafer.portal.annotation.TrackChange;
import com.wafer.portal.awsS3.S3Service;
import com.wafer.portal.dto.EventResponseDto;
import com.wafer.portal.model.Event;
import com.wafer.portal.service.EventService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;

@RestController
@RequestMapping("/api/v1/events")
public class EventController {

    private static  final Logger logger =  LoggerFactory.getLogger(EventController.class);

    private final EventService eventService;
    private final S3Service s3Service;

    public EventController(EventService eventService, S3Service s3Service) {
        this.eventService = eventService;
        this.s3Service = s3Service;
    }

    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Added", section = "Events")
    public ResponseEntity<EventResponseDto> createEvent(@RequestParam("eventName") String eventName,
                                                         @RequestPart("eventImage") MultipartFile eventImage,
                                                        @RequestPart(value = "thumbnail",required = false) MultipartFile thumbnail,
                                                         @RequestParam("eventDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate eventDate,
                                                         @RequestParam("startTime") @DateTimeFormat(iso = DateTimeFormat.ISO.TIME) LocalTime startTime,
                                                         @RequestParam(value = "endTime", required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.TIME) LocalTime endTime,
                                                         @RequestParam(name="url",required=false) String url,
                                                        @RequestParam(name="sequence", required=false) Double sequence) {
        try {
            String imageUrl = s3Service.uploadFile(eventImage, "Event-Images");
            String urlKey = null;

            if (thumbnail != null && !thumbnail.isEmpty()) {
                urlKey = s3Service.uploadFile(thumbnail, "Event-Thumbnail-Images");
            }
            Event event = new Event(eventName, imageUrl, urlKey, eventDate, startTime, endTime,url,sequence);
            Event savedEvent = eventService.saveEvent(event);
            String preSignedUrl = s3Service.generatePresignedUrl(savedEvent.getEventImage());
            String prePresignedUrl1 = null;

            if (savedEvent.getThumbnail() != null && !savedEvent.getThumbnail().isEmpty()) {
                prePresignedUrl1 = s3Service.generatePresignedUrl(event.getThumbnail());
            }

            EventResponseDto responseDto = new EventResponseDto(savedEvent.getId(), savedEvent.getEventName(), preSignedUrl, prePresignedUrl1, savedEvent.getEventDate(), savedEvent.getStartTime(), savedEvent.getEndTime(), savedEvent.getUrl(), savedEvent.getSequence(), savedEvent.getCreatedBy(), savedEvent.getCreationDate(), savedEvent.getLastModifiedBy(), savedEvent.getLastModifiedDate());
            return new ResponseEntity<>(responseDto, HttpStatus.CREATED);
        } catch (IOException e) {
            e.printStackTrace();
            logger.error("IoException occurred while uploading Event image", e);
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("Unexpected error occurred while event image", e);
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @GetMapping("/all")
    public ResponseEntity<Page<EventResponseDto>> getAllEvents(Pageable pageable) {
        Page<Event> newsPage = eventService.getAllEvents(pageable);

        Page<EventResponseDto> dtoPage = newsPage.map(event -> {
            String preSignedUrl = s3Service.generatePresignedUrl(event.getEventImage());
            String prePresignedUrl1 = null;

            if (event.getThumbnail() != null && !event.getThumbnail().isEmpty()) {
                prePresignedUrl1 = s3Service.generatePresignedUrl(event.getThumbnail());
            }
            return  new EventResponseDto(event.getId(), event.getEventName(), preSignedUrl, prePresignedUrl1, event.getEventDate(), event.getStartTime(), event.getEndTime(), event.getUrl(), event.getSequence(), event.getCreatedBy(), event.getCreationDate(), event.getLastModifiedBy(), event.getLastModifiedDate());
        });
        return dtoPage.isEmpty() ? new ResponseEntity<>(HttpStatus.NO_CONTENT) : new ResponseEntity<>(dtoPage, HttpStatus.OK);
    }


    @GetMapping("/{id}")
    public ResponseEntity<EventResponseDto> getEventById(@PathVariable Long id) {
        return eventService.getEventById(id)
                .map(event ->{
                    String preSignedUrl = s3Service.generatePresignedUrl(event.getEventImage());
                    String prePresignedUrl1 = null;

                    if (event.getThumbnail() != null && !event.getThumbnail().isEmpty()) {
                        prePresignedUrl1 = s3Service.generatePresignedUrl(event.getThumbnail());
                    }
                    EventResponseDto dto = new EventResponseDto(event.getId(), event.getEventName(), preSignedUrl, prePresignedUrl1, event.getEventDate(), event.getStartTime(), event.getEndTime(), event.getUrl(), event.getSequence(), event.getCreatedBy(), event.getCreationDate(), event.getLastModifiedBy(), event.getLastModifiedDate());
                    return new ResponseEntity<>(dto, HttpStatus.OK);
                }).orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PutMapping(value = "/{id}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Edited", section = "Events")
    public ResponseEntity<EventResponseDto> updateEvent(@PathVariable Long id,
                                                         @RequestParam("eventName") String eventName,
                                                         @RequestPart(value = "eventImage", required = false) MultipartFile eventImage,
                                                        @RequestPart(value = "thumbnail", required = false) MultipartFile thumbnail,
                                                         @RequestParam("eventDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate eventDate,
                                                         @RequestParam("startTime") @DateTimeFormat(iso = DateTimeFormat.ISO.TIME) LocalTime startTime,
                                                         @RequestParam(value = "endTime", required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.TIME) LocalTime endTime,
                                                        @RequestParam(name="sequence", required=false) Double sequence,
                                                        @RequestParam(name="url", required=false) String url) {
        try {
            Event existing = eventService.getEventById(id).orElse(null);
            if (existing == null) return new ResponseEntity<>(HttpStatus.NOT_FOUND);

            existing.setEventName(eventName);
            existing.setEventDate(eventDate);
            existing.setStartTime(startTime);
            if (endTime != null) {
                existing.setEndTime(endTime);
            }
            existing.setUrl(url);
            existing.setSequence(sequence);

            String updatedImageKey = existing.getEventImage();
            String updatedThumbnailKey = existing.getThumbnail();

            if (eventImage != null && !eventImage.isEmpty() && eventImage.getOriginalFilename() != null
                    && !eventImage.getOriginalFilename().isBlank()) {

                updatedImageKey = s3Service.updateFile(existing.getEventImage(), eventImage, "Event-Images");

                boolean isVideo = eventImage.getContentType() != null &&
                        eventImage.getContentType().startsWith("video");

                if (isVideo) {
                    if (thumbnail != null && !thumbnail.isEmpty()) {
                        updatedThumbnailKey = s3Service.updateFile(existing.getThumbnail(), thumbnail, "Event-Thumbnail-Images");
                    }
                } else {
                    if (thumbnail != null && !thumbnail.isEmpty()) {
                        updatedThumbnailKey = s3Service.updateFile(existing.getThumbnail(), thumbnail, "Event-Thumbnail-Images");
                    } else {
                        updatedThumbnailKey = null; // your rule
                    }
                }
            }
            else {
                if (thumbnail != null && !thumbnail.isEmpty()) {
                    updatedThumbnailKey = s3Service.updateFile(existing.getThumbnail(), thumbnail, "Event-Thumbnail-Images");
                }
            }

            existing.setEventImage(updatedImageKey);
            existing.setThumbnail(updatedThumbnailKey);

            Event event = eventService.saveEvent(existing);
            String preSignedUrl = s3Service.generatePresignedUrl(event.getEventImage());
            String prePresignedUrl1 = null;

            if (event.getThumbnail() != null && !event.getThumbnail().isEmpty()) {
                prePresignedUrl1 = s3Service.generatePresignedUrl(event.getThumbnail());
            }

            EventResponseDto responseDto = new EventResponseDto(event.getId(), event.getEventName(), preSignedUrl, prePresignedUrl1, event.getEventDate(), event.getStartTime(), event.getEndTime(), event.getUrl(), event.getSequence(), event.getCreatedBy(), event.getCreationDate(), event.getLastModifiedBy(), event.getLastModifiedDate());


            return new ResponseEntity<>(responseDto, HttpStatus.OK);
        } catch (IOException e) {
            e.printStackTrace();
            logger.error("IoException occurred while updating event image", e);
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("Unexpected error occurred while updating event image", e);
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/{id}")
    @TrackChange(action = "Deleted", section = "Events")
    public ResponseEntity<Event> deleteEvent(@PathVariable Long id) {
        try {
            Event result = eventService.softDeleteEvent(id);
            return (result != null)
                    ? new ResponseEntity<>(result, HttpStatus.OK)
                    : new ResponseEntity<>(HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            logger.error("Failed to soft delete event with ID: {}", id, e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/admin/all")
    public ResponseEntity<Page<EventResponseDto>> getAllEventsForAdmin(Pageable pageable) {
        Page<Event> eventsPage = eventService.getAllEventsOrderByCreatedDateAsc(pageable);
        Page<EventResponseDto> dtoPage = eventsPage.map(event -> {
            String preSignedUrl = s3Service.generatePresignedUrl(event.getEventImage());
            String prePresignedUrl1 = null;

            if (event.getThumbnail() != null && !event.getThumbnail().isEmpty()) {
                prePresignedUrl1 = s3Service.generatePresignedUrl(event.getThumbnail());
            }
            return new EventResponseDto(event.getId(), event.getEventName(), preSignedUrl, prePresignedUrl1, event.getEventDate(), event.getStartTime(), event.getEndTime(), event.getUrl(), event.getSequence(), event.getCreatedBy(), event.getCreationDate(), event.getLastModifiedBy(), event.getLastModifiedDate());
        });

        return dtoPage.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(dtoPage);
    }

    @GetMapping("/employee/all")
    public ResponseEntity<Page<EventResponseDto>> getAllEventsForEmployee(Pageable pageable) {
        Page<Event> eventsPage = eventService.getAllEventsOrderByEventDateAsc(pageable);
        Page<EventResponseDto> dtoPage = eventsPage.map(event -> {
            String preSignedUrl = s3Service.generatePresignedUrl(event.getEventImage());
            String prePresignedUrl1 = null;

            if (event.getThumbnail() != null && !event.getThumbnail().isEmpty()) {
                prePresignedUrl1 = s3Service.generatePresignedUrl(event.getThumbnail());
            }
            return new EventResponseDto(event.getId(), event.getEventName(), preSignedUrl, prePresignedUrl1, event.getEventDate(), event.getStartTime(), event.getEndTime(), event.getUrl(), event.getSequence(), event.getCreatedBy(), event.getCreationDate(), event.getLastModifiedBy(), event.getLastModifiedDate());
        });

        return dtoPage.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(dtoPage);
    }


}

