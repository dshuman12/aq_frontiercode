package com.wafer.portal.service;

import com.wafer.portal.dto.MoodOfTheDayResponse;
import com.wafer.portal.model.DailyMood;
import com.wafer.portal.repository.DailyMoodRepository;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;

@Service
public class MoodOfTheDayService {

    private final DailyMoodRepository dailyMoodRepository;

    public MoodOfTheDayService(DailyMoodRepository dailyMoodRepository) {
        this.dailyMoodRepository = dailyMoodRepository;
    }

    public MoodOfTheDayResponse getMoodOfTheDay() {
        List<DailyMood> todaysMoods = dailyMoodRepository.findAllByOrderByCreationDateDesc()
                .stream()
                .filter(m -> m.getCreationDate().toLocalDate().isEqual(LocalDate.now()))
                .toList();

        if (todaysMoods.isEmpty()) {
            return new MoodOfTheDayResponse("");
        }

        long happyCount = todaysMoods.stream().filter(m -> m.getMood() == DailyMood.Mood.HAPPY).count();
        long neutralCount = todaysMoods.stream().filter(m -> m.getMood() == DailyMood.Mood.NEUTRAL).count();
        long sadCount = todaysMoods.stream().filter(m -> m.getMood() == DailyMood.Mood.SAD).count();

        long totalResponses = happyCount + neutralCount + sadCount;
        double averageScore = (happyCount * 3 + neutralCount * 2 + sadCount * 1) / (double) totalResponses;

        String moodOfTheDay;
        if (averageScore >= 2.5) moodOfTheDay = "Happy";
        else if (averageScore >= 1.5) moodOfTheDay = "Neutral";
        else moodOfTheDay = "Sad";

        return new MoodOfTheDayResponse(moodOfTheDay);
    }
}
