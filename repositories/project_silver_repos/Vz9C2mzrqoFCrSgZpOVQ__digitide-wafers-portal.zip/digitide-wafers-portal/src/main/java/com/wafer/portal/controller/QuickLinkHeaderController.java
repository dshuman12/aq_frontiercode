package com.wafer.portal.controller;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wafer.portal.annotation.TrackChange;
import com.wafer.portal.dto.QuickLinkHeaderResponse;
import com.wafer.portal.dto.QuickLinkSubHeaderRequest;
import com.wafer.portal.model.QuickLinkHeader;
import com.wafer.portal.service.QuickLinkHeaderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@Controller
@RestController
@RequestMapping("/api/v2/quick-links-header")
public class QuickLinkHeaderController {

    private final QuickLinkHeaderService quickLinkHeaderService;

    @Autowired
    public QuickLinkHeaderController(QuickLinkHeaderService quickLinkHeaderService) {
        this.quickLinkHeaderService = quickLinkHeaderService;
    }

    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Added", section = "Quick links Header")
    public ResponseEntity<QuickLinkHeaderResponse> createQuickLinks(
            @RequestParam(value="pdf",required = false) MultipartFile pdf,
            @RequestParam(value="request", required = false) String requestJson) throws JsonProcessingException {
        QuickLinkSubHeaderRequest request = new ObjectMapper().readValue(requestJson, QuickLinkSubHeaderRequest.class);
        return quickLinkHeaderService.createQuickLinkHeader(pdf, request);
    }
    @GetMapping("/all")
    public ResponseEntity<Page<QuickLinkHeaderResponse>> getAllQuickLink(@PageableDefault(sort = "id", direction = Sort.Direction.ASC) Pageable pageable) {
        return quickLinkHeaderService.getAllQuickLinkHeader(pageable);
    }

    @GetMapping("/{id}")
    public ResponseEntity<QuickLinkHeaderResponse> getQuickLinkById(@PathVariable Long id) {
        return quickLinkHeaderService.getQuickLinkHeaderById(id);
    }


    @PutMapping(value = "/{id}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Edited", section = "Quick links Header")
    public ResponseEntity<QuickLinkHeaderResponse> updateQuickLink(
            @PathVariable Long id,
            @RequestParam(value = "image", required = false) MultipartFile pdf,
            @RequestParam(value="request", required = false) String requestJson) throws JsonProcessingException {

        QuickLinkSubHeaderRequest request = new ObjectMapper().readValue(requestJson, QuickLinkSubHeaderRequest.class);
        return quickLinkHeaderService.updateQuickLinkHeader(id, pdf, request);
    }


    @DeleteMapping("/{id}")
    @TrackChange(action = "Deleted", section = "Quick links Header")
    public ResponseEntity<QuickLinkHeader> deleteQuickLink(@PathVariable Long id) {
        // We now expect the service to return the object so the Aspect can read it
        QuickLinkHeader result = quickLinkHeaderService.deleteQuickLinkHeader(id);

        return (result != null)
                ? new ResponseEntity<>(result, HttpStatus.OK)
                : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}
