

package com.wafer.portal.dto;

public class QuickLinkHeaderRequest {
    private String title;

    public QuickLinkHeaderRequest() {
    }

    public QuickLinkHeaderRequest(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
