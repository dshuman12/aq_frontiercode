package com.wafer.portal.dto;

import jakarta.validation.constraints.NotBlank;

public class HelpAndSupportDocumentRequest {

    @NotBlank(message = "Description is mandatory")
    private String description;
    private Double sequence;

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Double getSequence() {
        return sequence;
    }

    public void setSequence(Double sequence) {
        this.sequence = sequence;
    }
}