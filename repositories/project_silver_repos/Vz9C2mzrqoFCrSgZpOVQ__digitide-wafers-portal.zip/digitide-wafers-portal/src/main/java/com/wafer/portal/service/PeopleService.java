package com.wafer.portal.service;

import com.wafer.portal.model.People;
import com.wafer.portal.repository.PeopleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PeopleService {

    @Autowired
    private PeopleRepository peopleRepository;

    public People savePeople(People people) {
        return peopleRepository.save(people);
    }

    public Page<People> getAllPeople(Pageable pageable) {
        return peopleRepository.findAllOrderedBySequence(pageable);
    }

    public Optional<People> getPeopleById(Long id) {
        return peopleRepository.findByIdAndIsDeletedFalse(id);
    }

    public People updatePeople(Long id, People updatePeople) {
        return peopleRepository.findById(id).map(people -> {
            people.setImageUrl(updatePeople.getImageUrl());
            people.setContent(updatePeople.getContent());
            return peopleRepository.save(people);
        }).orElse(null);
    }

    public People softDeletePeople(Long id) {
        return peopleRepository.findByIdAndIsDeletedFalse(id).map(people -> {
            people.setIsDeleted(true);
            return peopleRepository.save(people);
        }).orElse(null);
    }

}
