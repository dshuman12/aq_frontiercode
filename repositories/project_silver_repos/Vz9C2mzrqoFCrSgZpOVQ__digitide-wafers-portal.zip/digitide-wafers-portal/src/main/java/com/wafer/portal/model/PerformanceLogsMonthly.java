package com.wafer.portal.model;

import jakarta.persistence.*;

@Entity
@Table(name="performance_logs_monthly")
public class PerformanceLogsMonthly {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String pageName;

    private String apiName;

    private Integer year;

    private Integer month;

    private Integer totalRequests;

    private Integer avgApiTime;

    private Integer avgPageLoad;

    private Integer errorCount;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPageName() {
        return pageName;
    }

    public void setPageName(String pageName) {
        this.pageName = pageName;
    }

    public String getApiName() {
        return apiName;
    }

    public void setApiName(String apiName) {
        this.apiName = apiName;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public Integer getMonth() {
        return month;
    }

    public void setMonth(Integer month) {
        this.month = month;
    }

    public Integer getTotalRequests() {
        return totalRequests;
    }

    public void setTotalRequests(Integer totalRequests) {
        this.totalRequests = totalRequests;
    }

    public Integer getAvgApiTime() {
        return avgApiTime;
    }

    public void setAvgApiTime(Integer avgApiTime) {
        this.avgApiTime = avgApiTime;
    }

    public Integer getAvgPageLoad() {
        return avgPageLoad;
    }

    public void setAvgPageLoad(Integer avgPageLoad) {
        this.avgPageLoad = avgPageLoad;
    }

    public Integer getErrorCount() {
        return errorCount;
    }

    public void setErrorCount(Integer errorCount) {
        this.errorCount = errorCount;
    }
}