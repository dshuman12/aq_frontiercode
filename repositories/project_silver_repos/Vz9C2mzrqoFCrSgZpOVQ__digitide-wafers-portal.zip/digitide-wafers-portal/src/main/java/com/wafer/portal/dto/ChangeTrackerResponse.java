package com.wafer.portal.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.time.LocalDateTime;

public class ChangeTrackerResponse {
    private Long id;
    private String userEmail;
    private String actionType;
    private String resourceType;
    private String sectionName;
    private String fileName;

    @JsonFormat(pattern = "dd-MMM-yyyy HH:mm")
    private LocalDateTime timestamp;

    private String fileUrl; // Maps to 'document' in your reference logic

    // Audit Metadata fields to match your reference
    private String createdBy;
    private LocalDateTime creationDate;
    private String lastModifiedBy;
    private LocalDateTime lastModifiedDate;

    public ChangeTrackerResponse() {}

    public ChangeTrackerResponse(Long id, String userEmail, String actionType, String resourceType,
                                 String sectionName, String fileName, LocalDateTime timestamp,
                                 String fileUrl, String createdBy, LocalDateTime creationDate,
                                 String lastModifiedBy, LocalDateTime lastModifiedDate) {
        this.id = id;
        this.userEmail = userEmail;
        this.actionType = actionType;
        this.resourceType = resourceType;
        this.sectionName = sectionName;
        this.fileName = fileName;
        this.timestamp = timestamp;
        this.fileUrl = fileUrl;
        this.createdBy = createdBy;
        this.creationDate = creationDate;
        this.lastModifiedBy = lastModifiedBy;
        this.lastModifiedDate = lastModifiedDate;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getActionType() {
        return actionType;
    }

    public void setActionType(String actionType) {
        this.actionType = actionType;
    }

    public String getResourceType() {
        return resourceType;
    }

    public void setResourceType(String resourceType) {
        this.resourceType = resourceType;
    }

    public String getSectionName() {
        return sectionName;
    }

    public void setSectionName(String sectionName) {
        this.sectionName = sectionName;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }

    public String getFileUrl() {
        return fileUrl;
    }

    public void setFileUrl(String fileUrl) {
        this.fileUrl = fileUrl;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public LocalDateTime getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(LocalDateTime creationDate) {
        this.creationDate = creationDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public LocalDateTime getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(LocalDateTime lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }
}