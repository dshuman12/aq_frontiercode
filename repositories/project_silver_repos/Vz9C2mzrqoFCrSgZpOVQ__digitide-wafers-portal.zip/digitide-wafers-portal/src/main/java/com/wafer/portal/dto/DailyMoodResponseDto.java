package com.wafer.portal.dto;

import com.wafer.portal.model.DailyMood;
import java.time.LocalDateTime;
import java.time.LocalDate;

public class DailyMoodResponseDto {
    private Long id;
    private String username;
    private DailyMood.Mood mood;
    private LocalDate date;

    private LocalDateTime creationDateTime;
//    private String employeeId;

    public DailyMoodResponseDto(Long id, String username, DailyMood.Mood mood, LocalDateTime creationDateTime) {
        this.id = id;
        this.username = username;
        this.mood = mood;
        this.creationDateTime = creationDateTime;
        this.date = creationDateTime.toLocalDate();
       // this.employeeId = employeeId;
    }

    // --- Getters and Setters ---
    public Long getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public DailyMood.Mood getMood() {
        return mood;
    }

    public LocalDate getDate() {
        return date;
    }

    public LocalDateTime getCreationDateTime() {
        return creationDateTime;
    }

   // public String getEmployeeId() {
//        return employeeId;
//    }
}