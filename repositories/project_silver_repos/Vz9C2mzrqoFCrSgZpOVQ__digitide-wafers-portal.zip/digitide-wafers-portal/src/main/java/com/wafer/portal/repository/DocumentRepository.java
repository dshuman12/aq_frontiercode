package com.wafer.portal.repository;

import com.wafer.portal.model.Document;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface DocumentRepository extends JpaRepository<Document, Long> {
    Page<Document> findByIsDeletedFalse(Pageable pageable);
    Optional<Document> findByIdAndIsDeletedFalse(Long aLong);

//    @Query("SELECT d FROM Document d " +
//            "WHERE d.isDeleted = false AND " +
//            "(LOWER(d.name) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
//            "OR LOWER(d.documentTitle.title) LIKE LOWER(CONCAT('%', :keyword, '%'))) ")
//    Page<Document> searchDocuments(@Param("keyword") String keyword, Pageable pageable);

    @Query("""
    SELECT d FROM Document d
    LEFT JOIN d.documentTitle dt
    WHERE d.isDeleted = false
      AND (
           LOWER(d.name) LIKE LOWER(CONCAT('%', :keyword, '%'))
        OR LOWER(dt.title) LIKE LOWER(CONCAT('%', :keyword, '%'))
      )
""")
    Page<Document> searchDocuments(@Param("keyword") String keyword, Pageable pageable);


}
