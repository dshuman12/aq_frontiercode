package com.wafer.portal.service;

import com.wafer.portal.dto.MarqueeHeadlineRequest;
import com.wafer.portal.dto.MarqueeHeadlineResponse;
import com.wafer.portal.model.MarqueeHeadline;
import com.wafer.portal.repository.MarqueeHeadlineRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class MarqueeHeadlineService {

    private final MarqueeHeadlineRepository repository;

    @Autowired
    public MarqueeHeadlineService(MarqueeHeadlineRepository repository) {
        this.repository = repository;
    }

    // 🟢 Get current headline
    public ResponseEntity<MarqueeHeadlineResponse> getHeadline() {
        Optional<MarqueeHeadline> headlineOpt = repository.findByIdAndIsDeletedFalse((short) 1);

        if (headlineOpt.isPresent()) {
            MarqueeHeadline headline = headlineOpt.get();
            return new ResponseEntity<>(mapToResponse(headline), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
    }

    public ResponseEntity<MarqueeHeadlineResponse> saveHeadline(MarqueeHeadlineRequest request) {
        Optional<MarqueeHeadline> existingOpt = repository.findByIdAndIsDeletedFalse((short) 1);

        MarqueeHeadline headline;
        if (existingOpt.isPresent()) {
            // Update existing
            headline = existingOpt.get();
            headline.setDescription(request.getDescription());
        } else {
            // Create new
            headline = new MarqueeHeadline((short) 1, request.getDescription());
        }
        MarqueeHeadline saved = repository.save(headline);
        return new ResponseEntity<>(mapToResponse(saved), HttpStatus.OK);
    }

    public MarqueeHeadline clearHeadline(Short id) {
        return repository.findByIdAndIsDeletedFalse(id)
                .map(headLine -> {
                    headLine.setDeleted(true);
                    return repository.save(headLine);
                }).orElse(null);
    }

    public ResponseEntity<MarqueeHeadlineResponse> updateMarqueHeadline(Short id, MarqueeHeadlineRequest request) {
        return repository.findByIdAndIsDeletedFalse(id)
                .map(existing -> {
                    existing.setDescription(request.getDescription());
                    MarqueeHeadline updated = repository.save(existing);
                    return new ResponseEntity<>(mapToResponse(updated), HttpStatus.OK);

                })
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));

    }

    // 🧩 Mapper method (Entity → Response DTO)
    private MarqueeHeadlineResponse mapToResponse(MarqueeHeadline entity) {
        return new MarqueeHeadlineResponse(
                entity.getId(),
                entity.getDescription(),
                entity.getCreatedBy(),
                entity.getCreationDate(),
                entity.getLastModifiedBy(),
                entity.getLastModifiedDate()
        );
    }
}

