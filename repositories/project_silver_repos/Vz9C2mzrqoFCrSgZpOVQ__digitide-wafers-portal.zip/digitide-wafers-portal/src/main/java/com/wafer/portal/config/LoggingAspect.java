package com.wafer.portal.config;

import com.wafer.portal.annotation.TrackChange;
import com.wafer.portal.service.AuditService;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import java.lang.reflect.Field;

@Aspect
@Component
public class LoggingAspect {

    @Autowired
    private AuditService auditService;

    @AfterReturning(pointcut = "@annotation(trackChange)", returning = "result")
    public void logAfter(JoinPoint joinPoint, TrackChange trackChange, Object result) {
        String email = "System";
        if (SecurityContextHolder.getContext().getAuthentication() != null) {
            email = SecurityContextHolder.getContext().getAuthentication().getName();
        }

        String rawS3Key = "N/A";
        String fileName = "N/A";

        Object data = result;
        if (result instanceof ResponseEntity<?> responseEntity) {
            data = responseEntity.getBody();
        }

        if (data != null) {
            rawS3Key = extractRawS3KeyFromEntity(data);
        }

        if ("N/A".equals(rawS3Key)) {
            Object[] args = joinPoint.getArgs();
            for (Object arg : args) {
                if (arg instanceof MultipartFile file) {
                    rawS3Key = file.getOriginalFilename(); // Or specific path logic
                } else if (arg instanceof String s && s.contains(".")) {
                    rawS3Key = s;
                }
            }
        }

        if (!"N/A".equals(rawS3Key)) {
            fileName = cleanS3Key(rawS3Key);
        }

        String resource = detectType(fileName);

        auditService.logChange(email, trackChange.action(), resource, trackChange.section(), fileName, rawS3Key);
    }

    private String extractRawS3KeyFromEntity(Object obj) {
        if (obj == null) return "N/A";

        try {
            Class<?> current = obj.getClass();

            while (current != null && current != Object.class) {
                Field[] fields = current.getDeclaredFields();
                for (Field field : fields) {
                    String fieldName = field.getName();


                    if (fieldName.equals("documentKey") ||
                            fieldName.toLowerCase().equals("documentkey") ||
                            fieldName.toLowerCase().contains("s3key") ||
                            fieldName.toLowerCase().contains("document")   ||
                            fieldName.toLowerCase().contains("image")   ||
                            fieldName.toLowerCase().contains("thumbnail") ||
                            fieldName.toLowerCase().contains("url") ||
                            fieldName.toLowerCase().contains("document_url") ||
                            fieldName.toLowerCase().contains("thumbnail_url") ||
                            fieldName.toLowerCase().contains("document_key") ||
                            fieldName.toLowerCase().contains("thumbnail_key") ||
                            fieldName.toLowerCase().contains("event_image") ||
                            fieldName.toLowerCase().contains("attachment") ||
                            fieldName.toLowerCase().contains("uploaded_document")) {

                        field.setAccessible(true);
                        Object value = field.get(obj);
                        if (value == null) continue;

                        String valueStr = value.toString();
                        if (valueStr.startsWith("http")) {
                            if (valueStr.contains(".amazonaws.com/")) {
                                String pattern = ".amazonaws.com/";
                                int startIndex = valueStr.indexOf(pattern) + pattern.length();
                                int endIndex = valueStr.indexOf("?");

                                if (endIndex != -1 && endIndex > startIndex) {
                                    String rawPath = valueStr.substring(startIndex, endIndex);
                                    return java.net.URLDecoder.decode(rawPath, java.nio.charset.StandardCharsets.UTF_8);
                                }
                            }
                            continue;
                        }
                        return valueStr;
                    }
                }
                current = current.getSuperclass();
            }
        } catch (Exception e) {
            return "N/A";
        }
        return "N/A";
    }

    private String cleanS3Key(String s3Key) {
        if (s3Key == null || s3Key.isEmpty()) return "N/A";

        String result = s3Key;

        if (result.contains("?")) {
            result = result.substring(0, result.indexOf("?"));
        }

        if (result.contains("/")) {
            result = result.substring(result.lastIndexOf("/") + 1);
        }

        if (result.contains("_")) {
            result = result.substring(result.indexOf("_") + 1);
        }

        return result;
    }

    private String detectType(String fileName) {
        if (fileName == null || fileName.equals("N/A") || fileName.trim().isEmpty()) {
            return "General";
        }

        String lower = fileName.toLowerCase();

        if (lower.endsWith(".mp4") || lower.endsWith(".avi") || lower.endsWith(".mkv") || lower.endsWith(".mov")) {
            return "Video";
        }

        if (lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".png") ||
                lower.endsWith(".gif") || lower.endsWith(".svg") || lower.endsWith(".webp")) {
            return "Image";
        }

        if (lower.endsWith(".pdf") || lower.endsWith(".docx") || lower.endsWith(".doc") ||
                lower.endsWith(".xlsx") || lower.endsWith(".xls") || lower.endsWith(".pptx") ||
                lower.endsWith(".ppt") || lower.endsWith(".txt") || lower.endsWith(".csv")) {
            return "Document";
        }

        if (lower.endsWith(".zip") || lower.endsWith(".rar") || lower.endsWith(".7z") || lower.endsWith(".tar")) {
            return "Archive";
        }

        return "File";
    }
}