package com.wafer.portal.controller;

import com.wafer.portal.dto.PageVisitDTO;
import com.wafer.portal.dto.PerformanceRequest;
import com.wafer.portal.model.PerformanceLog;
import com.wafer.portal.model.PerformanceLogsMonthly;
import com.wafer.portal.service.PerformanceService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/v2/performance")
public class PerformanceController {

    private final PerformanceService performanceService;

    public PerformanceController(PerformanceService performanceService) {
        this.performanceService = performanceService;
    }

    @PostMapping("/page-load")
    public ResponseEntity<String> updatePageLoad(@RequestBody PerformanceRequest request){
        return performanceService.updatePageLoad(request);
    }

    @GetMapping("/tracking/{trackingId}")
    public ResponseEntity<List<PerformanceLog>> getByTrackingId(@PathVariable String trackingId){
        return ResponseEntity.ok(performanceService.getLogsByTrackingId(trackingId));
    }

    @GetMapping("/api")
    public ResponseEntity<List<PerformanceLog>> getByApi(@RequestParam String apiName){
        return ResponseEntity.ok(performanceService.getLogsByApi(apiName));
    }

    @GetMapping("/monthly")
    public ResponseEntity<List<PerformanceLogsMonthly>> getMonthly(
            @RequestParam int year,
            @RequestParam int month){

        return ResponseEntity.ok(
                performanceService.getMonthlyData(year, month)
        );
    }

    @GetMapping("/all")
    public ResponseEntity<Page<PerformanceLog>> getAllLogs(Pageable pageable){
        return ResponseEntity.ok(performanceService.getAllLogs(pageable));
    }

    @GetMapping("/device/{deviceType}")
    public ResponseEntity<Page<PageVisitDTO>> getByDeviceType(
            @PathVariable String deviceType,
            @RequestParam LocalDate startDate,
            @RequestParam LocalDate endDate,
            Pageable pageable) {
        return ResponseEntity.ok(
                performanceService.getLogsByDeviceType(deviceType, startDate, endDate, pageable)
        );
    }

    @GetMapping("/browser/{browser}")
    public ResponseEntity<Page<PageVisitDTO>> getByBrowser(
            @PathVariable String browser,
            @RequestParam LocalDate startDate,
            @RequestParam LocalDate endDate,
            Pageable pageable) {
        return ResponseEntity.ok(
                performanceService.getLogsByBrowser(browser, startDate, endDate, pageable)
        );
    }


}