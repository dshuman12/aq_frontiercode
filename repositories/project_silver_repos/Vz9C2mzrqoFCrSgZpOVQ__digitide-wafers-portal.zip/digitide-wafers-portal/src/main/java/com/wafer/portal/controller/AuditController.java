package com.wafer.portal.controller;

import com.wafer.portal.dto.ChangeTrackerResponse;
import com.wafer.portal.model.ChangeTracker;
import com.wafer.portal.service.AuditService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v2/audit")
public class AuditController {

    @Autowired
    private AuditService auditService;

    @GetMapping("/changes")
    public ResponseEntity<Page<ChangeTrackerResponse>> getAuditLogs(Pageable pageable) {
        return auditService.getAllAuditLogs(pageable);
    }

    @GetMapping("/filter")
    public ResponseEntity<Page<ChangeTrackerResponse>> getAuditLogsByDate(
            @RequestParam(name = "startDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) java.time.LocalDate startDate,
            @RequestParam(name = "endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) java.time.LocalDate endDate,
            Pageable pageable) {

        return auditService.getAuditLogsByDateRange(startDate, endDate, pageable);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ChangeTracker> deleteAuditLog(@PathVariable Long id) {
        ChangeTracker deletedLog = auditService.softDeleteAuditLog(id);

        return (deletedLog != null)
                ? ResponseEntity.ok(deletedLog)
                : ResponseEntity.notFound().build();
    }
}