package com.wafer.portal.constants;

public class Constants {
    public static final String FE_LOCAL_URL= "http://localhost:5173/";

}
