package com.wafer.portal.model;

import com.wafer.portal.audit.Auditable;
import jakarta.persistence.*;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;

@Entity
@Table(name="system_uptime")
public class SystemUptime extends Auditable<String> implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "log_date")
    private LocalDate logDate;

    @Column(name = "log_start_time")
    private LocalTime logStartTime;

    @Column(name = "log_end_time")
    private LocalTime logEndTime;

    private Long duration;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDate getLogDate() {
        return logDate;
    }

    public void setLogDate(LocalDate logDate) {
        this.logDate = logDate;
    }

    public LocalTime getLogStartTime() {
        return logStartTime;
    }

    public void setLogStartTime(LocalTime logStartTime) {
        this.logStartTime = logStartTime;
    }

    public LocalTime getLogEndTime() {
        return logEndTime;
    }

    public void setLogEndTime(LocalTime logEndTime) {
        this.logEndTime = logEndTime;
    }

    public Long getDuration() {
        return duration;
    }

    public void setDuration(Long duration) {
        this.duration = duration;
    }
}