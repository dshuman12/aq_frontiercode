package com.wafer.portal.repository;

import com.wafer.portal.model.Leadership;
import com.wafer.portal.model.People;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;


@Repository
public interface LeadershipRepository extends JpaRepository<Leadership,Long> {
    Page<Leadership> findByIsDeletedFalse(Pageable pageable);
    Optional<Leadership> findByIdAndIsDeletedFalse(Long aLong);

    @Query("SELECT l FROM Leadership l WHERE l.isDeleted = false ORDER BY " +
            "CASE WHEN l.sequence IS NULL THEN 1 ELSE 0 END, l.sequence ASC")
    Page<Leadership> findAllOrderedBySequence(Pageable pageable);

    @Query("SELECT l FROM Leadership l WHERE l.isDeleted = false AND " +
            "(LOWER(l.name) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(l.designation) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    Page<Leadership> searchLeadership(@Param("keyword") String keyword, Pageable pageable);


}
