package com.wafer.portal.dto;

import java.util.List;

public class GroupedRewardsResponse {
    private Long sectionId;
    private String sectionName;
    private List<SubsectionGroupDto> subsections;

    public GroupedRewardsResponse(Long sectionId, String sectionName, List<SubsectionGroupDto> subsections) {
        this.sectionId = sectionId;
        this.sectionName = sectionName;
        this.subsections = subsections;
    }

    public Long getSectionId() {
        return sectionId;
    }

    public void setSectionId(Long sectionId) {
        this.sectionId = sectionId;
    }

    public String getSectionName() {
        return sectionName;
    }

    public void setSectionName(String sectionName) {
        this.sectionName = sectionName;
    }

    public List<SubsectionGroupDto> getSubsections() {
        return subsections;
    }

    public void setSubsections(List<SubsectionGroupDto> subsections) {
        this.subsections = subsections;
    }

    // Inner Static Class
    public static class SubsectionGroupDto {
        private Long subsectionId;
        private String subsectionName;
        private List<RewardsandRecognitionResponse> rewards;

        public SubsectionGroupDto(Long subsectionId, String subsectionName, List<RewardsandRecognitionResponse> rewards) {
            this.subsectionId = subsectionId;
            this.subsectionName = subsectionName;
            this.rewards = rewards;
        }

        public Long getSubsectionId() {
            return subsectionId;
        }

        public void setSubsectionId(Long subsectionId) {
            this.subsectionId = subsectionId;
        }

        public String getSubsectionName() {
            return subsectionName;
        }

        public void setSubsectionName(String subsectionName) {
            this.subsectionName = subsectionName;
        }

        public List<RewardsandRecognitionResponse> getRewards() {
            return rewards;
        }

        public void setRewards(List<RewardsandRecognitionResponse> rewards) {
            this.rewards = rewards;
        }
    }
}
