package com.wafer.portal.dto;


import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.util.List;

public class UpdateRoleRequest {
    @NotNull(message = "Roles cannot be null")
    @Size(min = 1, message = "At least one role must be provided")

    private List<Long> roles;

    public List<Long> getRoles() {
        return roles;
    }

    public void setRoles(List<Long> roles) {
        this.roles = roles;
    }

}

