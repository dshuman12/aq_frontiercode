package com.wafer.portal.controller;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wafer.portal.annotation.TrackChange;
import com.wafer.portal.dto.QuickLinkSubHeaderRequest;
import com.wafer.portal.dto.QuickLinkSubHeaderResponseDTO;
import com.wafer.portal.model.QuickLinkSubHeader;
import com.wafer.portal.service.QuickLinkSubHeaderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@Controller
@RestController
@RequestMapping("/api/v2/quick-link-sub-header")
public class QuickLinkSubHeaderController {

    private final QuickLinkSubHeaderService quickLinkSubHeaderService;

    @Autowired
    public QuickLinkSubHeaderController(QuickLinkSubHeaderService quickLinkSubHeaderService) {
        this.quickLinkSubHeaderService = quickLinkSubHeaderService;
    }

    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Added", section = "Quick links Sub Header")
    public ResponseEntity<QuickLinkSubHeaderResponseDTO> createQuickLinks(
            @RequestParam(value="pdf",required = false ) MultipartFile pdf,
            @RequestParam("request") String requestJson) throws JsonProcessingException {
        QuickLinkSubHeaderRequest request = new ObjectMapper().readValue(requestJson, QuickLinkSubHeaderRequest.class);
        return quickLinkSubHeaderService.createQuickLink(pdf, request);
    }
    @GetMapping("/all")
    public ResponseEntity<Page<QuickLinkSubHeaderResponseDTO>> getAllQuickLink(Pageable pageable) {
        return quickLinkSubHeaderService.getAllQuickLinks(pageable);
    }

    @GetMapping("/{id}")
    public ResponseEntity<QuickLinkSubHeaderResponseDTO> getQuickLinkById(@PathVariable Long id) {
        return quickLinkSubHeaderService.getQuickLinkById(id);
    }


    @PutMapping(value = "/{id}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Edited", section = "Quick links Sub Header")
    public ResponseEntity<QuickLinkSubHeaderResponseDTO> updateQuickLink(
            @PathVariable Long id,
            @RequestParam(value = "image", required = false) MultipartFile pdf,
            @RequestParam("request") String requestJson) throws JsonProcessingException {

        QuickLinkSubHeaderRequest request = new ObjectMapper().readValue(requestJson, QuickLinkSubHeaderRequest.class);
        return quickLinkSubHeaderService.updateQuickLink(id, pdf, request);
    }


    @DeleteMapping("/{id}")
    @TrackChange(action = "Deleted", section = "Quick links Sub Header")
    public ResponseEntity<QuickLinkSubHeader> deleteQuickLink(@PathVariable Long id) {
        QuickLinkSubHeader result = quickLinkSubHeaderService.deleteQuickLink(id);

        return (result != null)
                ? new ResponseEntity<>(result, HttpStatus.OK)
                : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}
