package com.wafer.portal.controller;

import com.wafer.portal.dto.MoodOfTheDayResponse;
import com.wafer.portal.service.MoodOfTheDayService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v2")
public class MoodOfTheDayController {

    private final MoodOfTheDayService moodOfTheDayService;

    public MoodOfTheDayController(MoodOfTheDayService moodOfTheDayService) {
        this.moodOfTheDayService = moodOfTheDayService;
    }

    @GetMapping("/mood-of-the-day")
    public ResponseEntity<MoodOfTheDayResponse> getMoodOfTheDay() {
        MoodOfTheDayResponse response = moodOfTheDayService.getMoodOfTheDay();
        return ResponseEntity.ok(response);
    }
}
