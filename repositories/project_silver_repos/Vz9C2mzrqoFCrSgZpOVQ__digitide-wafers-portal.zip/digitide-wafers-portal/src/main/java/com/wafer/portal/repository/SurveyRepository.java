package com.wafer.portal.repository;

import com.wafer.portal.model.People;
import com.wafer.portal.model.Survey;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface SurveyRepository extends JpaRepository<Survey, Long> {
    Page<Survey> findByIsDeletedFalse(Pageable pageable);
    Optional<Survey> findByIdAndIsDeletedFalse(Long id);

    @Query("SELECT s FROM Survey s WHERE s.isDeleted = false AND " +
            "(LOWER(s.surveyTitle) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(s.description) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(s.urlLink) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    Page<Survey> searchSurvey(@Param("keyword") String keyword, Pageable pageable);

}
