package com.wafer.portal.repository;

import com.wafer.portal.model.RewardsSection;
import com.wafer.portal.model.RewardsSubsection;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface RewardsSubsectionRepository extends JpaRepository<RewardsSubsection, Long> {

    Page<RewardsSubsection> findByIsDeletedFalse(Pageable pageable);
    // Find all active subsections for the grouping logic
    List<RewardsSubsection> findByIsDeletedFalse();

    Optional<RewardsSubsection> findBySubsectionNameIgnoreCaseAndIsDeletedFalse(String name);


}