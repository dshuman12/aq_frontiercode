package com.wafer.portal.dto;

import com.wafer.portal.model.DailyMood;

public class MoodPercentageDTO {

    private DailyMood.Mood mood;
    private Long count;
    private Double percentage;

    public MoodPercentageDTO(DailyMood.Mood mood, Long count, Double percentage) {
        this.mood = mood;
        this.count = count;
        this.percentage = percentage;
    }

    public DailyMood.Mood getMood() {
        return mood;
    }

    public Long getCount() {
        return count;
    }

    public Double getPercentage() {
        return percentage;
    }
}