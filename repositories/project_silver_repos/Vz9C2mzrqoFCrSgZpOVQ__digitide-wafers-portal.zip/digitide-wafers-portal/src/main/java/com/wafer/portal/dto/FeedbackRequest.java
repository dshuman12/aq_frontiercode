package com.wafer.portal.dto;

public class FeedbackRequest {
    private String feedbackDescription;

    public FeedbackRequest() {
    }

    public FeedbackRequest(String feedbackDescription) {
        this.feedbackDescription = feedbackDescription;
    }

    public String getFeedbackDescription() {
        return feedbackDescription;
    }

    public void setFeedbackDescription(String feedbackDescription) {
        this.feedbackDescription = feedbackDescription;
    }
}
