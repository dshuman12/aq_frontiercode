package com.wafer.portal.awsS3;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.HttpMethod;
import com.amazonaws.SdkClientException;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.GeneratePresignedUrlRequest;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.time.Duration;
import java.time.Instant;
import java.util.*;

@Service
public class S3Service {
    private static final Logger logger = LoggerFactory.getLogger(S3Service.class);

    private final AmazonS3 s3Client;

    @Value("${aws.s3.bucket-name}")
    private String bucketName;

    @Value("${aws.s3.folder}")
    private String folderNameS3;

    @Value("${aws.s3.url.expiration.hours}")
    private int expirationHours;


    private static final String[] ALLOWED_FILE_TYPES = {
            "image/jpeg",
            "image/jpg",
            "image/png",
            "image/gif",
            "image/webp",
            "video/mp4",
            "application/pdf",
            "application/msword", // .doc
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document", // .docx
            "application/vnd.ms-excel", // .xls
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", // .xlsx
            "application/vnd.ms-powerpoint", //.ppt
            "application/vnd.openxmlformats-officedocument.presentationml.presentation" //.pptx
    };

    public S3Service(@Value("${aws.s3.region}") String region) {
        this.s3Client = AmazonS3ClientBuilder.standard()
                .withRegion(region)
                .withCredentials(DefaultAWSCredentialsProviderChain.getInstance())
                .build();
    }

    public String uploadFile(MultipartFile file, String folderName) throws IOException {
        logger.info("upload file");
        validateFile(file);
        validateFolderName(folderName);

        String uniqueFileName = generateUniqueFileName(file, folderName);

        try (InputStream inputStream = file.getInputStream()) {
            ObjectMetadata metadata = createMetadata(file);

            PutObjectRequest putRequest = new PutObjectRequest(bucketName, uniqueFileName, inputStream, metadata);
            s3Client.putObject(putRequest);


            logger.info("File uploaded successfully to S3: {}", uniqueFileName);

//            return generatePresignedUrl(uniqueFileName);
            return uniqueFileName;


        } catch (Exception e) {
            logger.error("Failed to upload file to S3: {}", e.getMessage(), e);
            throw new IOException("Failed to upload file to S3: " + e.getMessage(), e);
        }
    }

    public List<String> uploadFiles(MultipartFile[] files, String folderName) throws IOException {
        if (files == null || files.length == 0) {
            throw new IllegalArgumentException("Files array cannot be null or empty");
        }

        List<String> uploadedUrls = new ArrayList<>();
        List<String> failedUploads = new ArrayList<>();

        for (MultipartFile file : files) {
            try {
                String url = uploadFile(file, folderName);
                uploadedUrls.add(url);
            } catch (IOException e) {
                failedUploads.add(file.getOriginalFilename());
                logger.warn("Failed to upload file: {}", file.getOriginalFilename(), e);
            }
        }

        if (!failedUploads.isEmpty()) {
            logger.warn("Some files failed to upload: {}", failedUploads);
        }

        return uploadedUrls;
    }

    public String updateFile(String oldFileUrl, MultipartFile newFile, String folderName) throws IOException {
        if (oldFileUrl == null || oldFileUrl.isEmpty()) {
            return uploadFile(newFile, folderName);
        }

        try {
            String newFileUrl = uploadFile(newFile, folderName);
            return newFileUrl;
        } catch (Exception e) {
            logger.error("Failed to update file in S3", e);
            throw new IOException("Failed to update file in S3: " + e.getMessage(), e);
        }
    }

    public void deleteFileFromS3(String fileUrl) {
        if (fileUrl == null || fileUrl.isEmpty()) {
            logger.warn("Attempted to delete null or empty file URL");
            return;
        }

        try {
            String keyName = extractKeyFromUrl(fileUrl);
            s3Client.deleteObject(bucketName, keyName);
            logger.info("File deleted successfully from S3: {}", keyName);
        } catch (Exception e) {
            logger.error("Failed to delete file from S3: {}", fileUrl, e);
            throw new IllegalStateException("Failed to delete file from S3: " + e.getMessage(), e);
        }
    }

    private void validateFile(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("File cannot be null or empty");
        }

        String contentType = file.getContentType();
        if (contentType != null && !Arrays.asList(ALLOWED_FILE_TYPES).contains(contentType.toLowerCase())) {
            throw new IllegalArgumentException("Unsupported file type: " + contentType +
                    ". Allowed types: " + Arrays.toString(ALLOWED_FILE_TYPES));
        }

        long maxFileSize = 20 * 1024 * 1024; // 20MB
        if (file.getSize() > maxFileSize) {
            throw new IllegalArgumentException("File size exceeds maximum limit of 20MB");
        }
    }

    private void validateFolderName(String folderName) {
        if (folderName == null || folderName.trim().isEmpty()) {
            throw new IllegalArgumentException("Folder name cannot be null or empty");
        }
    }

    private String generateUniqueFileName(MultipartFile file, String folderName) {
        String originalFilename = file.getOriginalFilename();
        if (originalFilename == null) {
            originalFilename = "unknown";
        }

        String cleanFolderName = folderName.replaceAll("/+", "/").replaceAll("^/|/$", "");
        String cleanBaseFolder = folderNameS3.replaceAll("/+", "/").replaceAll("^/|/$", "");

        return cleanBaseFolder + "/" + cleanFolderName + "/" + UUID.randomUUID() + "_" + originalFilename;
    }

    private ObjectMetadata createMetadata(MultipartFile file) {
        ObjectMetadata metadata = new ObjectMetadata();
        metadata.setContentType(file.getContentType());
        metadata.setContentLength(file.getSize());

        if (file.getContentType() != null && file.getContentType().startsWith("image/")) {
            metadata.setCacheControl("public, max-age=31536000");
        }

        return metadata;
    }

    private String extractKeyFromUrl(String fileUrl) {
        if (fileUrl == null || fileUrl.isEmpty()) {
            throw new IllegalArgumentException("File URL cannot be null or empty");
        }

        try {
            if (fileUrl.contains(bucketName + ".s3")) {
                int keyStartIndex = fileUrl.indexOf(".amazonaws.com/") + 15;
                return fileUrl.substring(keyStartIndex);
            } else {
                java.net.URL url = new java.net.URL(fileUrl);
                String path = url.getPath();

                if (path.startsWith("/" + bucketName + "/")) {
                    return path.substring(bucketName.length() + 2);
                } else {
                    return path.substring(1);
                }
            }
        } catch (Exception e) {
            logger.error("Failed to extract key from URL: {}", fileUrl, e);
            throw new RuntimeException("Invalid S3 URL: " + fileUrl, e);
        }
    }

    public String generatePresignedUrl(String key) {
        if (key == null || key.trim().isEmpty()) {
            throw new IllegalArgumentException("S3 object key cannot be null or empty");
        }

        try {

            Date expiration = Date.from(Instant.now().plus(Duration.ofHours(1))); // 1 hour validity

            GeneratePresignedUrlRequest presignedUrlRequest = new GeneratePresignedUrlRequest(bucketName, key)
                    .withMethod(HttpMethod.GET)
                    .withExpiration(expiration);

            URL url = s3Client.generatePresignedUrl(presignedUrlRequest);
            return url.toString();
        } catch (AmazonServiceException e) {
            throw new RuntimeException("Failed to generate pre-signed URL from S3: " + e.getMessage(), e);
        } catch (SdkClientException e) {
            throw new RuntimeException("AWS SDK client error while generating pre-signed URL: " + e.getMessage(), e);
        }
    }

    public String generatePresignedUrlUpload(String objectPath) {
        return generatePresignedUrlUpload(objectPath, expirationHours);
    }

    public String generatePresignedUrlUpload(String objectPath, int expirationHours) {
        try {
            if (objectPath == null || objectPath.trim().isEmpty()) {
                return null;
            }
            String cleanPath = objectPath.startsWith("/") ? objectPath.substring(1) : objectPath;
            String s3Key = cleanPath;

            Date expirationDate = new Date();
            long expTimeMillis = expirationDate.getTime() + (expirationHours * 60L * 60L * 1000L);
            expirationDate.setTime(expTimeMillis);
            GeneratePresignedUrlRequest generatePresignedUrlRequest =
                    new GeneratePresignedUrlRequest(bucketName, s3Key)
                            .withMethod(HttpMethod.GET)
                            .withExpiration(expirationDate);

            URL presignedUrl = s3Client.generatePresignedUrl(generatePresignedUrlRequest);
            return presignedUrl.toString();

        } catch (Exception e) {
            logger.info("Error generating presigned URL for path: " + objectPath + " - " + e.getMessage());
            return null;
        }
    }




}