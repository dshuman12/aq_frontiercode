package com.wafer.portal.model;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.wafer.portal.audit.Auditable;
import jakarta.persistence.*;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "quick_links_header")
public class QuickLinkHeader extends Auditable<String> implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String title;
    private String url;
    @Column(name = "is_deleted",nullable = false)

    @OneToMany(mappedBy = "header", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    @JsonManagedReference
    private List<QuickLinkSubHeader> subHeaderList = new ArrayList<>();

    private boolean isDeleted;

    public QuickLinkHeader() {
    }

    public QuickLinkHeader(String title, String url) {
        this.title = title;
        this.url = url;
        this.isDeleted = false;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public List<QuickLinkSubHeader> getSubHeaderList() { return subHeaderList; }

    public void setSubHeaderList(List<QuickLinkSubHeader> subHeaderList) {
        this.subHeaderList = subHeaderList;
    }

    public boolean isDeleted() {
        return isDeleted;
    }

    public void setDeleted(boolean deleted) {
        isDeleted = deleted;
    }
}
