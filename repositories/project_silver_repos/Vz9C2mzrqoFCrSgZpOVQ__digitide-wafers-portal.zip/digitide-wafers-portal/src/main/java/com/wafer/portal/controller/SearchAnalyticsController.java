package com.wafer.portal.controller;

import com.wafer.portal.service.SearchAnalyticsService;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/api/v2/search-analytics")
public class SearchAnalyticsController {

    private final SearchAnalyticsService searchAnalyticsService;

    public SearchAnalyticsController(SearchAnalyticsService searchAnalyticsService) {
        this.searchAnalyticsService = searchAnalyticsService;
    }

    @PostMapping("/search/click/{id}")
    public ResponseEntity<String> markClicked(@PathVariable Long id) {

        searchAnalyticsService.markClicked(id);

        return ResponseEntity.ok("Clicked tracked");
    }
}
