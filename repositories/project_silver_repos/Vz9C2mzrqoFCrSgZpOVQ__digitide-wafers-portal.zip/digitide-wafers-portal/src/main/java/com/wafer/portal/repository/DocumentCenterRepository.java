package com.wafer.portal.repository;

import com.wafer.portal.model.DocumentCenter;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DocumentCenterRepository extends JpaRepository<DocumentCenter, Long> {

    Optional<DocumentCenter> findByIdAndIsDeletedFalse(Long id);

    @Query("SELECT d FROM DocumentCenter d WHERE d.isDeleted = false ORDER BY " +
            "CASE WHEN d.sequence IS NULL THEN 1 ELSE 0 END, d.sequence ASC")
    Page<DocumentCenter> findAllActiveOrdered(Pageable pageable);

    List<DocumentCenter> findByIsDeletedFalse();

    boolean existsBySectionIdAndIsDeletedFalse(Long sectionId);

    @Query("""
    SELECT d
    FROM DocumentCenter d
    JOIN DocumentSection s ON s.id = d.sectionId
    WHERE d.isDeleted = false
      AND s.isDeleted = false
      AND (
           LOWER(d.documentName) LIKE LOWER(CONCAT('%', :keyword, '%'))
        OR LOWER(s.sectionName)  LIKE LOWER(CONCAT('%', :keyword, '%'))
      )
""")
    List<DocumentCenter> searchDocumentCenter(@Param("keyword") String keyword);


}
