package com.wafer.portal.repository;


import com.wafer.portal.model.Video;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface VideoRepository extends JpaRepository<Video, Long> {
    Page<Video> findByIsDeletedFalse(Pageable pageable);
    Optional<Video> findByIdAndIsDeletedFalse(Long aLong);
    Optional<Video> findTopByIsDeletedFalseOrderByCreationDateDesc();

    @Query("SELECT v FROM Video v WHERE v.isDeleted = false AND " +
            "(LOWER(v.video) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(v.thumbnail) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    List<Video> searchVideo(@Param("keyword") String keyword);
}
