package com.wafer.portal.controller;

import com.wafer.portal.dto.ApiResponse;
import com.wafer.portal.dto.LoginRequest;
import com.wafer.portal.dto.UpdateRoleRequest;
import com.wafer.portal.dto.UserRequest;
import com.wafer.portal.dto.response.BasicResponse;
import com.wafer.portal.model.User;
import com.wafer.portal.service.AuthService;
import io.swagger.annotations.Api;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/login")
    public ResponseEntity<ApiResponse> authenticateUser(@Valid @RequestBody LoginRequest loginRequest, HttpServletResponse response) {
        ApiResponse apiResponse = authService.authenticateUser(loginRequest, response);
        return new ResponseEntity<>(apiResponse, apiResponse.isSuccess() ? HttpStatus.OK : HttpStatus.UNAUTHORIZED);
    }

    @PostMapping("/register")
    public ResponseEntity<ApiResponse> registerUser(@Valid @RequestBody User user) {
        ApiResponse response = authService.registerUser(user);
        return new ResponseEntity<>(response, response.isSuccess() ? HttpStatus.CREATED : HttpStatus.BAD_REQUEST);
    }

    @GetMapping("/allUsers")
//    @PreAuthorize("hasAnyRole('Admin', 'SuperAdmin')")
    public ResponseEntity<Page<User>> getAllUsers(Pageable pageable) {
        Page<User> users = authService.getAllUsers(pageable);
        if (users.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return ResponseEntity.ok(users);
    }


    @PostMapping("/logout")
    public ResponseEntity<ApiResponse> logoutUser(
            @RequestHeader(value = "Authorization", required = false) String authHeader,
            HttpServletResponse response) {

        ApiResponse apiResponse = authService.logoutUser(authHeader, response);
        return ResponseEntity.ok(apiResponse);
    }


    @PutMapping("/users/{userId}/roles")
//    @PreAuthorize("hasRole('SuperAdmin')")
    public ResponseEntity<ApiResponse> updateUserRole(@PathVariable Long userId, @Valid @RequestBody UpdateRoleRequest updateRoleRequest, HttpServletResponse response) {
        ApiResponse apiResponse = authService.updateUserRole(userId, updateRoleRequest.getRoles(), response);
        return new ResponseEntity<>(apiResponse, apiResponse.isSuccess() ? HttpStatus.OK : HttpStatus.BAD_REQUEST);
    }

    @GetMapping("/get-roles")
        public ResponseEntity<BasicResponse<?>> getPPtList() {
        BasicResponse<?> basicResponse = authService.getRoleList();
        return ResponseEntity.status(HttpStatus.valueOf(basicResponse.getStatusCode()))
                .body(basicResponse);
    }

    @PostMapping("/add-user")
    public ResponseEntity<BasicResponse<?>> addUser(@RequestBody UserRequest userRequest) {
       try {
           BasicResponse<?> basicResponse = authService.addUser(userRequest);
           return ResponseEntity.status(HttpStatus.valueOf(basicResponse.getStatusCode()))
                   .body(basicResponse);
       }catch (Exception e){
           e.printStackTrace();
           return null;
       }
    }

    @PostMapping("/get-users")
    public ResponseEntity<?> getPageableUsers(@RequestParam(defaultValue = "0") int pageNo,
                                              @RequestParam(defaultValue = "10") int pageSize,
                                              @RequestParam(defaultValue = "id") String sortByField,
                                              @RequestParam(defaultValue = "desc") String sortDirection,
                                              @RequestParam(defaultValue = "") String search) {

        BasicResponse<?> basicResponse = authService.getPageableUsers(pageNo, pageSize, sortByField, sortDirection, search);
        return new ResponseEntity<>(basicResponse, HttpStatus.valueOf(basicResponse.getStatusCode()));
    }


    @DeleteMapping("/{userId}")
//    @PreAuthorize("hasRole('SuperAdmin')")
    public ResponseEntity<ApiResponse> deleteUser(@PathVariable Long userId) {
        ApiResponse apiResponse = authService.deleteUser(userId);
        return new ResponseEntity<>(apiResponse, apiResponse.isSuccess() ? HttpStatus.OK : HttpStatus.BAD_REQUEST);
    }






}