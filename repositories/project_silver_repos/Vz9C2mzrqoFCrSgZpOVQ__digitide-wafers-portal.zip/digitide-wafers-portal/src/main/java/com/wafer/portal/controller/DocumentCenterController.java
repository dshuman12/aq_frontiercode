package com.wafer.portal.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.wafer.portal.annotation.TrackChange;
import com.wafer.portal.dto.*;
import com.wafer.portal.model.DocumentCenter;
import com.wafer.portal.model.DocumentSection;
import com.wafer.portal.service.DocumentCenterService;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.stereotype.Controller;

import java.util.List;

@RestController
@RequestMapping("/api/v2/document-center")
public class DocumentCenterController {

    private final DocumentCenterService documentCenterService;
    private final ObjectMapper objectMapper;

    public DocumentCenterController(DocumentCenterService documentCenterService) {
        this.documentCenterService = documentCenterService;
        this.objectMapper = new ObjectMapper();
        this.objectMapper.registerModule(new JavaTimeModule());
    }

    @PostMapping(value = "/create", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Added", section = "Document Center")
    public ResponseEntity<DocumentCenterResponseDto> upload(
            @RequestParam("document") MultipartFile document,
            @RequestParam(value = "thumbnail", required = false) MultipartFile thumbnail,
            @RequestParam("request") String requestJson) throws JsonProcessingException {

        DocumentCenterRequest request = objectMapper.readValue(requestJson, DocumentCenterRequest.class);
        return documentCenterService.uploadDocument(document, thumbnail, request);
    }

    @GetMapping("/allSectionDocuments")
    public ResponseEntity<Page<SectionDocumentsDto>> getAllGrouped(Pageable pageable) {
        Page<SectionDocumentsDto> response = documentCenterService.getAllGrouped(pageable);
        return ResponseEntity.ok(response);
    }


    @GetMapping("/all")
    public ResponseEntity<Page<DocumentCenterResponseDto>> getAllDocuments(Pageable pageable) {
        return documentCenterService.getAllDocuments(pageable);
    }


    @GetMapping("/{id}")
    public ResponseEntity<DocumentCenterResponseDto> getById(@PathVariable Long id) {
        return documentCenterService.getById(id);
    }

    @PutMapping(value = "/{id}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Edited", section = "Document Center")
    public ResponseEntity<DocumentCenterResponseDto> update(
            @PathVariable Long id,
            @RequestParam(value = "document", required = false) MultipartFile document,
            @RequestParam(value = "thumbnail", required = false) MultipartFile thumbnail,
            @RequestParam("request") String requestJson) throws JsonProcessingException {

        DocumentCenterRequest request = objectMapper.readValue(requestJson, DocumentCenterRequest.class);
        return documentCenterService.updateDocument(id, document, thumbnail, request);
    }

    @DeleteMapping("/{id}")
    @TrackChange(action = "Deleted", section = "Document Center")
    public ResponseEntity<DocumentCenter> delete(@PathVariable Long id) {
        DocumentCenter result = documentCenterService.deleteDocument(id);
        return (result != null)
                ? new ResponseEntity<>(result, HttpStatus.OK)
                : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    //documentSection
    @PostMapping("/addSection")
    @TrackChange(action = "Added", section = "Document Center Section")
    public ResponseEntity<DocumentSectionResponseDto> createSection(
            @RequestBody DocumentSectionRequest request) {
        return documentCenterService.createSection(request);
    }


    @GetMapping("/allSections")
    public ResponseEntity<Page<DocumentSection>> getAllSections(Pageable pageable) {
        return documentCenterService.getAllSections(pageable);
    }


    @DeleteMapping("/deleteSection/{id}")
    @TrackChange(action = "Deleted", section = "Document Center Section")
    public ResponseEntity<Void> deleteSection(@PathVariable Long id) {
        return documentCenterService.deleteSection(id);
    }

    @PutMapping("/updateSection/{id}")
    @TrackChange(action = "Edited", section = "Document Center Section")
    public ResponseEntity<DocumentSectionResponseDto> updateSection(
            @PathVariable Long id,
            @RequestParam("request") String requestJson) throws JsonProcessingException{
        DocumentSectionRequest request = objectMapper.readValue(requestJson, DocumentSectionRequest.class);
        return documentCenterService.updateSection(id, request);
    }




}
