package com.wafer.portal.repository;

import com.wafer.portal.dto.ActiveModuleResponseDTO;
import com.wafer.portal.model.AppModule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface AppModuleRepository extends JpaRepository<AppModule, Long> {
    List<ActiveModuleResponseDTO> findByParentIdAndIsActiveTrue(Long parentId);

    @Query("""
    SELECT new com.wafer.portal.dto.ActiveModuleResponseDTO(
        m.id,
        m.moduleName,
        m.moduleCode,
        CASE WHEN m.parent IS NOT NULL THEN m.parent.id ELSE NULL END,
        m.moduleLevel
    )
    FROM AppModule m
    WHERE m.isActive = true
    ORDER BY m.moduleLevel, m.id
""")
    List<ActiveModuleResponseDTO> findAllActiveModules();

    List<AppModule> findByIsActiveTrue();

}

