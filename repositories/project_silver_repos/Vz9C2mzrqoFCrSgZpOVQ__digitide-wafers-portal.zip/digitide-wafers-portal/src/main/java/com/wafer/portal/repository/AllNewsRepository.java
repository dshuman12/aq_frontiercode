package com.wafer.portal.repository;

import com.wafer.portal.model.AllNews;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface AllNewsRepository extends JpaRepository<AllNews, Long> {
    Page<AllNews> findByIsDeletedFalse(Pageable pageable);
    Optional<AllNews> findByIdAndIsDeletedFalse(Long aLong);

    @Query("SELECT a FROM AllNews a WHERE a.isDeleted = false AND " +
            "(LOWER(a.title) LIKE LOWER(CONCAT('%', :keyword, '%')) OR LOWER(a.url) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    Page<AllNews> searchAllNews(@Param("keyword") String keyword, Pageable pageable);

    @Query("SELECT a FROM AllNews a WHERE a.isDeleted = false ORDER BY " +
            "CASE WHEN a.sequence IS NULL THEN 1 ELSE 0 END, a.sequence ASC")
    Page<AllNews> findAllOrderedBySequence(Pageable pageable);

}
