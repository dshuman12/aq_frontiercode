package com.wafer.portal.config;

import com.wafer.portal.dto.SamlUserAttributes;
import com.wafer.portal.model.User;
import io.jsonwebtoken.*;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.security.Key;
import java.util.*;
import java.util.stream.Collectors;


@Component
public class JwtTokenProvider {

    private static final Logger logger = LoggerFactory.getLogger(JwtTokenProvider.class);

    private final String jwtSecret;
    private final int jwtExpirationMs;
    private final SecretKey key;

    public JwtTokenProvider(@Value("${app.jwtSecret}") String jwtSecret,
                            @Value("${app.jwtExpirationMs}") int jwtExpirationMs) {
        this.jwtSecret = jwtSecret;
        this.jwtExpirationMs = jwtExpirationMs;

        // Base64 decode the secret string to bytes
        byte[] keyBytes = Base64.getDecoder().decode(jwtSecret);
        this.key = new SecretKeySpec(keyBytes, SignatureAlgorithm.HS256.getJcaName());
    }

    public String generateTokenByAuth(Authentication authentication) {
        User userDetails = (User) authentication.getPrincipal();

        Date now = new Date();
        Date expiryDate = new Date(now.getTime() + jwtExpirationMs);

        String roles = userDetails.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .collect(Collectors.joining(","));

        return Jwts.builder()
                .setSubject(userDetails.getUsername())
                .claim("roles", roles)
                .claim("name", userDetails.getUserName())
                .claim("designation", userDetails.getDesignation())
                .setIssuedAt(now)
                .setExpiration(expiryDate)
                .signWith(key(), SignatureAlgorithm.HS256)
                .compact();
    }

    public String generateTokenBySaml(User user) {
        return Jwts.builder()
                .setSubject(user.getEmail()) // or user.getUserName()
                .claim("roles", user.getRoles())
                .signWith(key)
                .compact();
    }

    /* temporary comment
    public String generateToken(User user) {
        return Jwts.builder()
                .setSubject(user.getEmail())
                .claim("roles", user.getRoles())
                .claim("email", user.getEmail())
                .claim("firstName", user.getUserName())
               // .claim("lastName", user.getLastName())
                .claim("displayName", user.getUserName())
                .claim("designation", user.getDesignation())
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + jwtExpirationMs))
                .signWith(key(), SignatureAlgorithm.HS256)
                .compact();
    }


     */

    public String generateToken(SamlUserAttributes attributes) {
        Map<String, Object> claims = new HashMap<>();
        claims.put("email", attributes.getEmail());
        claims.put("firstName", attributes.getFirstName());
        claims.put("lastName", attributes.getLastName());
        claims.put("displayName", attributes.getDisplayName());
        claims.put("designation", attributes.getDesignation());
        claims.put("employeeId", attributes.getEmployeeId());
        claims.put("groups", attributes.getGroups());

        Date now = new Date();
        Date expiryDate = new Date(now.getTime() + jwtExpirationMs);


        return Jwts.builder()
                .setClaims(claims)
                .setSubject(attributes.getEmail() != null ? attributes.getEmail() : attributes.getDisplayName())
                //.setIssuedAt(new Date())
                //.setExpiration(new Date(System.currentTimeMillis() + jwtExpirationMs))
                .setIssuedAt(now)
                .setExpiration(expiryDate)
                .setId(UUID.randomUUID().toString()) //  makes every token unique
                .signWith(SignatureAlgorithm.HS512, jwtSecret)
                .compact();
    }

    public Key key() {
        return Keys.hmacShaKeyFor(Decoders.BASE64.decode(jwtSecret));
    }

    public String getUsernameFromToken(String token) {
        return Jwts.parserBuilder().setSigningKey(key()).build()
                .parseClaimsJws(token)
                .getBody()
                .getSubject();
    }

    public boolean validateToken(String authToken) {
        try {
            Jwts.parserBuilder().setSigningKey(key()).build().parse(authToken);
            return true;
        } catch (MalformedJwtException ex) {
            logger.error("Invalid JWT token", ex.getMessage());
        } catch (ExpiredJwtException ex) {
            logger.error("Expired JWT token", ex.getMessage());
        } catch (UnsupportedJwtException ex) {
            logger.error("Unsupported JWT token", ex.getMessage());
        } catch (IllegalArgumentException ex) {
            logger.error("JWT claims string is empty.", ex.getMessage());
        }
        return false;
    }
    public String getClaim(String token, String claimKey) {
        try {
            Claims claims = Jwts.parserBuilder()
                    .setSigningKey(key())       // use your key() method
                    .build()
                    .parseClaimsJws(token)
                    .getBody();

            return claims.get(claimKey, String.class); // read specific claim
        } catch (Exception e) {
            logger.error("Failed to read claim '{}' from JWT: {}", claimKey, e.getMessage());
            return null;
        }
    }

    // ADD THIS NEW METHOD FOR SAML AUTHENTICATION
    public String generateTokenFromSamlAttributes(String email, String firstName, String lastName,
                                                  String displayName, String designation) {
        Date now = new Date();
        Date expiryDate = new Date(now.getTime() + jwtExpirationMs);

        JwtBuilder builder = Jwts.builder()
                .setSubject(email)
                .setIssuedAt(now)
                .setExpiration(expiryDate);

        // Add user attributes as claims
        if (firstName != null) builder.claim("firstName", firstName);
        if (lastName != null) builder.claim("lastName", lastName);
        if (displayName != null) builder.claim("displayName", displayName);
        if (designation != null) builder.claim("designation", designation);
        if (email != null) builder.claim("email", email);

        String token = builder.signWith(key(), SignatureAlgorithm.HS256).compact();

        logger.info("Generated JWT token from SAML attributes for user: {}", email);
        logger.info("Token contains designation: {}", designation);

        return token;
    }


}
//
//@Component
//public class JwtTokenProvider {
//
//    private static final Logger logger = LoggerFactory.getLogger(JwtTokenProvider.class);
//
//    @Value("${app.jwtSecret}")
//    private String jwtSecret;
//
//    @Value("${app.jwtExpirationMs}")
//    private int jwtExpirationMs;
//
//    //    public String generateToken(Authentication authentication) {
////        User userDetails = (User) authentication.getPrincipal();
////
////        Date now = new Date();
////        Date expiryDate = new Date(now.getTime() + jwtExpirationMs);
////
////        String roles = userDetails.getAuthorities().stream()
////                .map(GrantedAuthority::getAuthority)
////                .collect(Collectors.joining(","));
////
////        return Jwts.builder()
////                .setSubject(userDetails.getUsername())
////                .claim("roles", roles)
////                .claim("name", userDetails.getName())
////                .claim("designation", userDetails.getDesignation())
////                .setIssuedAt(new Date())
////                .setExpiration(expiryDate)
////                .signWith(key(), SignatureAlgorithm.HS256)
////                .compact();
////    }
//    public String generateToken(Authentication authentication) {
//        User userDetails = (User) authentication.getPrincipal();
//
//        Date now = new Date();
//        Date expiryDate = new Date(now.getTime() + jwtExpirationMs);
//
//        String roles = userDetails.getAuthorities().stream()
//                .map(GrantedAuthority::getAuthority)
//                .collect(Collectors.joining(","));
//
//        return Jwts.builder()
//                .setSubject(userDetails.getUsername())
//                .claim("roles", roles)
//                .claim("name", userDetails.getUserName())
//                .claim("designation", userDetails.getDesignation())
//                .setIssuedAt(now)
//                .setExpiration(expiryDate)
//                .signWith(key(), SignatureAlgorithm.HS256)
//                .compact();
//    }
//
//    public Key key() {
//        return Keys.hmacShaKeyFor(Decoders.BASE64.decode(jwtSecret));
//    }
//
//    public String getUsernameFromToken(String token) {
//        return Jwts.parserBuilder().setSigningKey(key()).build()
//                .parseClaimsJws(token)
//                .getBody()
//                .getSubject();
//    }
//
//    public boolean validateToken(String authToken) {
//        try {
//            Jwts.parserBuilder().setSigningKey(key()).build().parse(authToken);
//            return true;
//        } catch (MalformedJwtException ex) {
//            logger.error("Invalid JWT token", ex.getMessage());
//        } catch (ExpiredJwtException ex) {
//            logger.error("Expired JWT token", ex.getMessage());
//        } catch (UnsupportedJwtException ex) {
//            logger.error("Unsupported JWT token", ex.getMessage());
//        } catch (IllegalArgumentException ex) {
//            logger.error("JWT claims string is empty.", ex.getMessage());
//        }
//        return false;
//    }
//}

