package com.wafer.portal.dto;

import org.springframework.web.multipart.MultipartFile;

public class DocumentUploadDto {
    private String name;
    private MultipartFile file;

    public DocumentUploadDto() {}

    public DocumentUploadDto(String name, MultipartFile file) {
        this.name = name;
        this.file = file;
    }

    public String getName() {
        return name;
    }

    public MultipartFile getFile() {
        return file;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setFile(MultipartFile file) {
        this.file = file;
    }
}
