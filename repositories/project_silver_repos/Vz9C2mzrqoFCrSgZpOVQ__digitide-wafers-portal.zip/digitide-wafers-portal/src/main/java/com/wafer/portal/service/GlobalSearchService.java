package com.wafer.portal.service;

import com.wafer.portal.awsS3.S3Service;
import com.wafer.portal.dto.QuickLinkHeaderResponse;
import com.wafer.portal.dto.QuickLinkSubHeaderResponseDTO;
import com.wafer.portal.dto.response.GlobalSearchResponseDTO;
import com.wafer.portal.dto.response.VideoSectionDTO;
import com.wafer.portal.dto.response.WhatsHappeningDTO;
import com.wafer.portal.model.LinkType;
import com.wafer.portal.model.QuickLinkHeader;
import com.wafer.portal.model.SearchAnalytics;
import com.wafer.portal.repository.*;
import com.wafer.portal.search.SearchSection;
import com.wafer.portal.utils.PresignedUrlEnricher;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


@Service
public class GlobalSearchService {

    private final AllNewsRepository allNewsRepository;
    private final TopNewsRepository topNewsRepository;
    private final PeopleRepository peopleRepository;
    private final AnnouncementsRepository announcementsRepository;
    private final EventRepository eventRepository;
    private final MileStoneRepository mileStoneRepository;

    private final QuickLinkHeaderRepository quickLinkHeaderRepository;
    private final QuickLinkSubHeaderRepository quickLinkSubHeaderRepository;

    private final SpotlightRepository spotlightRepository;
    private final SurveyRepository surveyRepository;

    private final CompanyInfoRepository companyInfoRepository;
    private final LeadershipRepository leadershipRepository;

    private final AwardsAndRecognitionRepository awardsRepository;
    private final RewardsandRecognitionRepository rewardsRepository;

    private final HelpAndSupportDocumentRepository helpRepository;

    private final MarqueeHeadlineRepository marqueeRepository;
    private final PicOfTheDayRepository picOfTheDayRepository;
    private final BrandGuidelinesRepository brandGuidelinesRepository;
    private final CoffeeWithLeadersRepository coffeeWithLeadersRepository;
    private final EmployeeNewsletterRepository employeeNewsletterRepository;

    private final VideoRepository videoRepository;
    private final DocumentCenterService documentCenterService;
    private final PresignedUrlEnricher presignedUrlEnricher;
    private final SearchAnalyticsRepository searchAnalyticsRepository;

    private final S3Service s3Service;

    public GlobalSearchService(
            AllNewsRepository allNewsRepository,
            TopNewsRepository topNewsRepository,
            PeopleRepository peopleRepository,
            AnnouncementsRepository announcementsRepository,
            EventRepository eventRepository,
            MileStoneRepository mileStoneRepository,
            QuickLinkHeaderRepository quickLinkHeaderRepository,
            QuickLinkSubHeaderRepository quickLinkSubHeaderRepository,
            SpotlightRepository spotlightRepository,
            SurveyRepository surveyRepository,
            CompanyInfoRepository companyInfoRepository,
            LeadershipRepository leadershipRepository,
            AwardsAndRecognitionRepository awardsRepository,
            RewardsandRecognitionRepository rewardsRepository,
            HelpAndSupportDocumentRepository helpRepository,
            MarqueeHeadlineRepository marqueeRepository,
            PicOfTheDayRepository picOfTheDayRepository,
            BrandGuidelinesRepository brandGuidelinesRepository,
            CoffeeWithLeadersRepository coffeeWithLeadersRepository,
            EmployeeNewsletterRepository employeeNewsletterRepository,
            VideoRepository videoRepository,
            DocumentCenterService documentCenterService,
            PresignedUrlEnricher presignedUrlEnricher,
            S3Service s3Service,
            SearchAnalyticsRepository searchAnalyticsRepository
    ) {
        this.allNewsRepository = allNewsRepository;
        this.topNewsRepository = topNewsRepository;
        this.peopleRepository = peopleRepository;
        this.announcementsRepository = announcementsRepository;
        this.eventRepository = eventRepository;
        this.mileStoneRepository = mileStoneRepository;
        this.quickLinkHeaderRepository = quickLinkHeaderRepository;
        this.quickLinkSubHeaderRepository = quickLinkSubHeaderRepository;
        this.spotlightRepository = spotlightRepository;
        this.surveyRepository = surveyRepository;
        this.companyInfoRepository = companyInfoRepository;
        this.leadershipRepository = leadershipRepository;
        this.awardsRepository = awardsRepository;
        this.rewardsRepository = rewardsRepository;
        this.helpRepository = helpRepository;
        this.marqueeRepository = marqueeRepository;
        this.picOfTheDayRepository = picOfTheDayRepository;
        this.brandGuidelinesRepository = brandGuidelinesRepository;
        this.coffeeWithLeadersRepository = coffeeWithLeadersRepository;
        this.employeeNewsletterRepository = employeeNewsletterRepository;
        this.videoRepository = videoRepository;
        this.documentCenterService = documentCenterService;
        this.presignedUrlEnricher = presignedUrlEnricher;
        this.s3Service = s3Service;
        this.searchAnalyticsRepository = searchAnalyticsRepository;
    }

    @Transactional
    public GlobalSearchResponseDTO searchAll(String keyword, int page, int size) {

        Pageable pageable = PageRequest.of(page, size);

        String search = keyword.toLowerCase();
        boolean isNewsSearch =
                SearchSection.TOP_NEWS.matches(search) ||
                        SearchSection.ALL_NEWS.matches(search);

        /* ---------------- WHATS HAPPENING ---------------- */

        WhatsHappeningDTO whatsHappening = new WhatsHappeningDTO();

        whatsHappening.setAnnouncements(
                presignedUrlEnricher.enrichList(
                        SearchSection.ANNOUNCEMENTS.matches(search)
                                ? announcementsRepository.findByIsDeletedFalse(pageable).getContent()
                                : announcementsRepository.searchAnnouncements(keyword, pageable).getContent()));

        whatsHappening.setEmployeeSpotlight(presignedUrlEnricher.enrichList(
                SearchSection.EMPLOYEE_SPOTLIGHT.matches(search)
                        ? peopleRepository.findByIsDeletedFalse(pageable).getContent()
                        : peopleRepository.searchPeople(keyword, pageable).getContent()));

        whatsHappening.setEvents(presignedUrlEnricher.enrichList(
                SearchSection.EVENTS.matches(search)
                        ? eventRepository.findByIsDeletedFalse(pageable).getContent()
                        : eventRepository.searchEvents(keyword, pageable).getContent()));

        whatsHappening.setMilestones(presignedUrlEnricher.enrichList(
                SearchSection.MILESTONES.matches(search)
                        ? mileStoneRepository.findByIsDeletedFalse(pageable).getContent()
                        : mileStoneRepository.searchMilestones(keyword, pageable).getContent()));

        whatsHappening.setAllNews(presignedUrlEnricher.enrichList(
                isNewsSearch
                        ? allNewsRepository.findByIsDeletedFalse(pageable).getContent()
                        : allNewsRepository.searchAllNews(keyword, pageable).getContent()));

        /* ---------------- RESPONSE ---------------- */

        GlobalSearchResponseDTO response = new GlobalSearchResponseDTO();
        response.setWhatsHappening(whatsHappening);

        VideoSectionDTO video = new VideoSectionDTO();
        video.setVideo(presignedUrlEnricher.enrichList(
                videoRepository.searchVideo(keyword)));
        response.setVideo(video);

        response.setTopNews(presignedUrlEnricher.enrichList(
                isNewsSearch
                        ? topNewsRepository.findByIsDeletedFalse(pageable).getContent()
                        : topNewsRepository.searchTopNews(keyword, pageable).getContent()));

        if (SearchSection.DOCUMENT_CENTER.matches(search)) {
            response.setDocumentCenter(
                    documentCenterService.getAllGrouped(Pageable.unpaged()).getContent()
            );
        } else if (SearchSection.DOCUMENTS.matches(search)) {
            response.setDocumentCenter(
                    documentCenterService.searchGrouped(keyword)
            );
        }



        response.setQuickLinkHeader(
                (SearchSection.QUICK_LINK_HEADER.matches(search)
                        ? quickLinkHeaderRepository.findByIsDeletedFalse(pageable).getContent()
                        : quickLinkHeaderRepository.searchQuickLinkHeader(keyword, pageable).getContent()
                )
                        .stream()
                        .map(this::mapHeaderForSearch)
                        .toList()
        );

        response.setQuickLinkSubHeader(
                (SearchSection.QUICK_LINK_SUB_HEADER.matches(search)
                        ? quickLinkSubHeaderRepository.findByIsDeletedFalse(pageable).getContent()
                        : quickLinkSubHeaderRepository.searchQuickLinkSubHeader(keyword, pageable).getContent()
                )
                        .stream()
                        .filter(sub -> !sub.isDeleted())
                        .map(sub -> new QuickLinkSubHeaderResponseDTO(
                                sub.getId(),
                                sub.getTitle(),
                                sub.getHeader().getId(),
                                sub.getHeader().getTitle(),
                                sub.getLinkType() == LinkType.FILE
                                        ? s3Service.generatePresignedUrl(sub.getUrl())
                                        : sub.getUrl(),
                                sub.getLinkType(),
                                sub.getCreatedBy(),
                                sub.getCreationDate(),
                                sub.getLastModifiedBy(),
                                sub.getLastModifiedDate()
                        ))
                        .toList()
        );



        response.setCompanyInfo(presignedUrlEnricher.enrichList(
                SearchSection.COMPANY_INFO.matches(search)
                        ? companyInfoRepository.findByIsDeletedFalse(pageable).getContent()
                        : companyInfoRepository.searchCompanyInfo(keyword, pageable).getContent()));

        response.setSpotlight(presignedUrlEnricher.enrichList(
                SearchSection.SPOTLIGHT.matches(search)
                        ? spotlightRepository.findByIsDeletedFalse(pageable).getContent()
                        : spotlightRepository.searchSpotlight(keyword, pageable).getContent()));

        response.setSurvey(presignedUrlEnricher.enrichList(
                SearchSection.SURVEY.matches(search)
                        ? surveyRepository.findByIsDeletedFalse(pageable).getContent()
                        : surveyRepository.searchSurvey(keyword, pageable).getContent()));

        response.setLeadership(presignedUrlEnricher.enrichList(
                SearchSection.LEADERSHIP.matches(search)
                        ? leadershipRepository.findByIsDeletedFalse(pageable).getContent()
                        : leadershipRepository.searchLeadership(keyword, pageable).getContent()));

        response.setAwardsRecognition(presignedUrlEnricher.enrichList(
                SearchSection.AWARDS.matches(search)
                        ? awardsRepository.findByIsDeletedFalse(pageable).getContent()
                        : awardsRepository.searchAwards(keyword, pageable).getContent()));

        response.setRewardsAndRecognition(presignedUrlEnricher.enrichList(
                SearchSection.REWARDS_AND_RECOGNITION.matches(search)
                        ? rewardsRepository.findByIsDeletedFalse(pageable).getContent()
                        : rewardsRepository.searchRewardsAndRecognition(keyword, pageable).getContent()));

        response.setHelpAndSupport(presignedUrlEnricher.enrichList(
                SearchSection.HELP_AND_SUPPORT.matches(search)
                        ? helpRepository.findByIsDeletedFalse(pageable).getContent()
                        : helpRepository.searchHelpAndSupport(keyword, pageable).getContent()));

        response.setMarquee(presignedUrlEnricher.enrichList(
                SearchSection.MARQUEE.matches(search)
                        ? marqueeRepository.findByIsDeletedFalse()
                        : marqueeRepository.searchMarquee(keyword)));

        response.setHobbyHub(presignedUrlEnricher.enrichList(
                SearchSection.HOBBY_HUB.matches(search)
                        ? picOfTheDayRepository.findByIsDeletedFalse()
                        : picOfTheDayRepository.searchPicOfTheDay(keyword)));

        response.setBrandGuidelines(presignedUrlEnricher.enrichList(
                SearchSection.BRAND_GUIDELINES.matches(search)
                        ? brandGuidelinesRepository.findByIsDeletedFalse(pageable).getContent()
                        : brandGuidelinesRepository.searchBrandGuidelines(keyword, pageable).getContent()));

        response.setCoffeeWithLeaders(presignedUrlEnricher.enrichList(
                SearchSection.COFFEE_WITH_LEADERS.matches(search)
                        ? coffeeWithLeadersRepository.findByIsDeletedFalse(pageable).getContent()
                        : coffeeWithLeadersRepository.searchCoffeeWithLeaders(keyword, pageable).getContent()));

        response.setEmployeeNewsletter(presignedUrlEnricher.enrichList(
                SearchSection.EMPLOYEE_NEWSLETTER.matches(search)
                        ? employeeNewsletterRepository.findByIsDeletedFalse(pageable).getContent()
                        : employeeNewsletterRepository.searchEmployeeNewsletter(keyword, pageable).getContent()));

        int totalResults = calculateTotalResults(response);

        Long searchId = saveSearchAnalytics(keyword, totalResults);

        response.setSearchId(searchId);

        return response;

    }

    @Transactional
    public Long saveSearchAnalytics(String keyword, int totalResults) {
        SearchAnalytics analytics = new SearchAnalytics();
        analytics.setQuery(keyword);
        analytics.setResultCount(totalResults);

        SearchAnalytics saved = searchAnalyticsRepository.save(analytics);

        return saved.getId();
    }

    private QuickLinkHeaderResponse mapHeaderForSearch(QuickLinkHeader ql) {

        List<QuickLinkSubHeaderResponseDTO> subHeaders =
                ql.getSubHeaderList().stream()
                        .filter(sub -> !sub.isDeleted())
                        .map(sub -> new QuickLinkSubHeaderResponseDTO(
                                sub.getId(),
                                sub.getTitle(),
                                ql.getId(),
                                ql.getTitle(),
                                sub.getLinkType() == LinkType.FILE
                                        ? s3Service.generatePresignedUrl(sub.getUrl())
                                        : sub.getUrl(),
                                sub.getLinkType(),
                                sub.getCreatedBy(),
                                sub.getCreationDate(),
                                sub.getLastModifiedBy(),
                                sub.getLastModifiedDate()
                        ))
                        .toList();

        return new QuickLinkHeaderResponse(
                ql.getId(),
                ql.getTitle(),
                ql.getUrl() != null
                        ? s3Service.generatePresignedUrl(ql.getUrl())
                        : null,
                subHeaders,
                ql.getCreatedBy(),
                ql.getCreationDate(),
                ql.getLastModifiedBy(),
                ql.getLastModifiedDate()
        );
    }

//    private int calculateTotalResults(GlobalSearchResponseDTO response) {
//        int count = 0;
//
//        if (response.getTopNews() instanceof List<?> list) count += list.size();
//        if (response.getQuickLinkHeader() instanceof List<?> list) count += list.size();
//        if (response.getQuickLinkSubHeader() instanceof List<?> list) count += list.size();
//        if (response.getCompanyInfo() instanceof List<?> list) count += list.size();
//        if (response.getSpotlight() instanceof List<?> list) count += list.size();
//
//        return count;
//    }

    private int calculateTotalResults(GlobalSearchResponseDTO response) {
        int count = 0;

        java.util.function.Function<Object, Integer> sizeOf = obj -> {
            if (obj instanceof List<?> list) return list.size();
            return 0;
        };

        count += sizeOf.apply(response.getTopNews());
        count += sizeOf.apply(response.getQuickLinkHeader());
        count += sizeOf.apply(response.getQuickLinkSubHeader());
        count += sizeOf.apply(response.getCompanyInfo());
        count += sizeOf.apply(response.getSpotlight());
        count += sizeOf.apply(response.getSurvey());
        count += sizeOf.apply(response.getLeadership());
        count += sizeOf.apply(response.getAwardsRecognition());
        count += sizeOf.apply(response.getRewardsAndRecognition());
        count += sizeOf.apply(response.getHelpAndSupport());
        count += sizeOf.apply(response.getMarquee());
        count += sizeOf.apply(response.getHobbyHub());
        count += sizeOf.apply(response.getBrandGuidelines());
        count += sizeOf.apply(response.getCoffeeWithLeaders());
        count += sizeOf.apply(response.getEmployeeNewsletter());
        count += sizeOf.apply(response.getDocumentCenter());

        if (response.getVideo() != null) {
            count += sizeOf.apply(response.getVideo().getVideo());
        }

        if (response.getWhatsHappening() != null) {
            WhatsHappeningDTO wh = response.getWhatsHappening();

            count += sizeOf.apply(wh.getAnnouncements());
            count += sizeOf.apply(wh.getEmployeeSpotlight());
            count += sizeOf.apply(wh.getEvents());
            count += sizeOf.apply(wh.getMilestones());
            count += sizeOf.apply(wh.getAllNews());
        }

        return count;
    }

}