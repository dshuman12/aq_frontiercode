package com.wafer.portal.controller;

import com.wafer.portal.annotation.TrackChange;
import com.wafer.portal.dto.DailyMoodResponseDto;
import com.wafer.portal.dto.MoodSubmitRequest;
import com.wafer.portal.service.DailyMoodService;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/v2/mood")
public class DailyMoodController {

    private final DailyMoodService dailyMoodService;

    public DailyMoodController(DailyMoodService dailyMoodService) {
        this.dailyMoodService = dailyMoodService;
    }

    @PostMapping
    public ResponseEntity<?> submitMood(
            @Valid @RequestBody MoodSubmitRequest request,
            Authentication authentication) {

        String username = authentication.getName();

        return dailyMoodService.logDailyMood(request, username);
    }


    @GetMapping("/all-history")
    public ResponseEntity<Page<DailyMoodResponseDto>> getMoodHistory(
            Authentication authentication, Pageable pageable) {

        return  dailyMoodService.getAllUsersMoodHistory(pageable);
    }
    @GetMapping("/history")
    public ResponseEntity<Page<DailyMoodResponseDto>> getMoodHistory(
            @RequestParam(name = "startDate")
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) @Valid LocalDate startDate,

            @RequestParam(name = "endDate")
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) @Valid LocalDate endDate,

            Authentication authentication, Pageable pageable) {


        return dailyMoodService.getAllUsersMoodHistoryByDateRange(startDate, endDate, pageable);
    }
}