package com.wafer.portal.repository;

import com.wafer.portal.model.SearchAnalytics;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDateTime;
import java.util.List;

public interface SearchAnalyticsRepository extends JpaRepository<SearchAnalytics, Long> {

    interface SearchAnalyticsProjection {
        Long getTotalSearch();
        Long getSuccessCount();
        Long getFailureCount();
        Long getClickCount();
    }

    interface TopSearchProjection {
        String getQuery();
        Long getCount();
    }

    @Query(value = """
        SELECT 
            COUNT(*) as totalSearch,
            COUNT(*) FILTER (WHERE result_count > 0) as successCount,
            COUNT(*) FILTER (WHERE result_count = 0) as failureCount,
            COUNT(*) FILTER (WHERE clicked = true) as clickCount
        FROM search_analytics
        WHERE created_at BETWEEN :start AND :end
    """, nativeQuery = true)
    SearchAnalyticsProjection getSearchStats(LocalDateTime start, LocalDateTime end);

    @Query(value = """
    SELECT 
        query as query,
        COUNT(*) as count
    FROM search_analytics
    WHERE created_at BETWEEN :start AND :end
    GROUP BY query
    ORDER BY count DESC
    LIMIT :limit
""", nativeQuery = true)
    List<TopSearchProjection> getTopSearchQueries(
            LocalDateTime start,
            LocalDateTime end,
            int limit
    );
}