package com.wafer.portal.controller;

import org.springframework.core.io.ClassPathResource;
import org.springframework.security.core.Authentication;
import org.springframework.security.saml2.provider.service.authentication.Saml2AuthenticatedPrincipal;
import org.springframework.security.saml2.provider.service.authentication.Saml2Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1")
public class TestController {

    @GetMapping("/test-saml-file")
    public String testSamlFile() {
        try {
            ClassPathResource resource = new ClassPathResource("saml/azure-idp-metadata.xml");
            return "File exists: " + resource.exists() + ", readable: " + resource.isReadable();
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }
    @GetMapping("/me")
    public Map<String, List<Object>> userInfo(Authentication authentication) {
        if (authentication instanceof Saml2Authentication samlAuth) {
            Saml2AuthenticatedPrincipal principal = (Saml2AuthenticatedPrincipal) samlAuth.getPrincipal();
            return principal.getAttributes(); // Map<String, List<Object>>
        }
        return Map.of("error", List.of("Not authenticated"));
    }


}