package com.wafer.portal.audit.impl;

import org.springframework.data.domain.AuditorAware;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class AuditorAwareImpl implements AuditorAware<String> {


    @Override
    public Optional<String> getCurrentAuditor(){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String name = "";
        if (authentication !=null) {
            name = authentication.getName();
            String userId ="";
            if(authentication.isAuthenticated()) {
                if(authentication.getPrincipal() instanceof UserDetailsImpl) {
                    UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
                    if(null != userDetails.getId())
                        userId = userDetails.getId().toString();
                    return Optional.of(userId);
                }else if(authentication.getPrincipal() instanceof String) {
                    String value = (String) authentication.getPrincipal();
                    return Optional.of(value);
                }
            }
        }
        return Optional.of(name);
    }
}

