package com.wafer.portal.repository;

import com.wafer.portal.model.Announcements;
import com.wafer.portal.model.People;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PeopleRepository extends JpaRepository<People, Long> {
    Page<People> findByIsDeletedFalse(Pageable pageable);
    Optional<People> findByIdAndIsDeletedFalse(Long aLong);


    @Query("SELECT s FROM People s WHERE s.isDeleted = false ORDER BY " +
            "CASE WHEN s.sequence IS NULL THEN 1 ELSE 0 END, s.sequence ASC")
    Page<People> findAllOrderedBySequence(Pageable pageable);

    @Query("SELECT p FROM People p WHERE p.isDeleted = false AND " +
            "(LOWER(p.content) LIKE LOWER(CONCAT('%', :keyword, '%')) OR LOWER(p.url) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    Page<People> searchPeople(@Param("keyword") String keyword, Pageable pageable);
}
