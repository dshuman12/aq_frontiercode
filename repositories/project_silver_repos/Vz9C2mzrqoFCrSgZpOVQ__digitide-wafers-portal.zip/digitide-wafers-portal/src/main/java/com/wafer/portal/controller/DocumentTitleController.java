package com.wafer.portal.controller;


import com.wafer.portal.dto.DocumentTitleDTO;
import com.wafer.portal.model.DocumentTitle;
import com.wafer.portal.repository.DocumentTitleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/document-title")
public class DocumentTitleController {

    @Autowired
    DocumentTitleRepository documentTitleRepository;

    @GetMapping("/all")
    public ResponseEntity<Page<DocumentTitleDTO>> getAllDocumentTitle(Pageable pageable) {
        Page<DocumentTitle> documentTitle = documentTitleRepository.findAll(pageable);

        Page<DocumentTitleDTO> dtoPage = documentTitle.map(document -> {
            return  new DocumentTitleDTO(document.getId(), document.getTitle(), document.getCreatedBy(), document.getCreationDate(), document.getLastModifiedBy(), document.getLastModifiedDate() );
        });
        return dtoPage.isEmpty() ? new ResponseEntity<>(HttpStatus.NO_CONTENT) : new ResponseEntity<>(dtoPage, HttpStatus.OK);
    }

}
