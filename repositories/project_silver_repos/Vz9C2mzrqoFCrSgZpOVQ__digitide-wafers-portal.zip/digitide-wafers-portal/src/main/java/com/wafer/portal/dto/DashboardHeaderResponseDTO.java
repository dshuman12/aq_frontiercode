package com.wafer.portal.dto;

public class DashboardHeaderResponseDTO {

    private Long totalClicks;
    private String mostVisitedModule;
    private String leastVisitedModule;
    private Double avgClicksPerDay;

    public DashboardHeaderResponseDTO(Long totalClicks,
                                      String mostVisitedModule,
                                      String leastVisitedModule,
                                      Double avgClicksPerDay) {
        this.totalClicks = totalClicks;
        this.mostVisitedModule = mostVisitedModule;
        this.leastVisitedModule = leastVisitedModule;
        this.avgClicksPerDay = avgClicksPerDay;
    }

    public Long getTotalClicks() {
        return totalClicks;
    }

    public String getMostVisitedModule() {
        return mostVisitedModule;
    }

    public String getLeastVisitedModule() {
        return leastVisitedModule;
    }

    public Double getAvgClicksPerDay() {
        return avgClicksPerDay;
    }
}