package com.wafer.portal.dto;

import jakarta.validation.constraints.NotBlank;

public class SurveyRequest {
    @NotBlank
    private String surveyTitle;

    private String estimatedTime;

    private String urlLink;

    private String description;

    private boolean surveyStatus;

    public String getSurveyTitle() {
        return surveyTitle;
    }

    public void setSurveyTitle(String surveyTitle) {
        this.surveyTitle = surveyTitle;
    }

    public String getEstimatedTime() {
        return estimatedTime;
    }

    public void setEstimatedTime(String estimatedTime) {
        this.estimatedTime = estimatedTime;
    }

    public String getUrlLink() {
        return urlLink;
    }

    public void setUrlLink(String urlLink) {
        this.urlLink = urlLink;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isSurveyStatus() {
        return surveyStatus;
    }

    public void setSurveyStatus(boolean surveyStatus) {
        this.surveyStatus = surveyStatus;
    }
}
