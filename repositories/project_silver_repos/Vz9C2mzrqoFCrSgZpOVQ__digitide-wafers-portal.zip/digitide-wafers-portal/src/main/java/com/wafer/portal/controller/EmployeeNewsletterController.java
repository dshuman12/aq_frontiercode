package com.wafer.portal.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wafer.portal.annotation.TrackChange;
import com.wafer.portal.dto.EmployeeNewsletterRequest;
import com.wafer.portal.dto.EmployeeNewsletterResponse;
import com.wafer.portal.model.EmployeeNewsletter;
import com.wafer.portal.service.EmployeeNewsletterService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/v2/employee-newsletter")
public class EmployeeNewsletterController {

    private final EmployeeNewsletterService newsletterService;
    private final ObjectMapper objectMapper = new ObjectMapper(); // For parsing JSON request

    public EmployeeNewsletterController(EmployeeNewsletterService newsletterService) {
        this.newsletterService = newsletterService;
        objectMapper.findAndRegisterModules();
    }

    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Added", section = "Employee Communication")
    public ResponseEntity<EmployeeNewsletterResponse> uploadNewsletter(
            @RequestParam("document") MultipartFile documentFile,
            @RequestParam(value = "thumbnail", required = false) MultipartFile thumbnailFile,
            @RequestParam("request") String requestJson
    ) throws JsonProcessingException {
        EmployeeNewsletterRequest request = objectMapper.readValue(requestJson, EmployeeNewsletterRequest.class);
        return newsletterService.uploadNewsletter(documentFile, thumbnailFile, request);
    }

    @GetMapping("/all")
    public ResponseEntity<Page<EmployeeNewsletterResponse>> getAllNewsletters(Pageable pageable) {

        return newsletterService.getAllNewsletters(pageable);
    }

    @GetMapping("/{id}")
    public ResponseEntity<EmployeeNewsletterResponse> getNewsletterById(@PathVariable Long id) {
        return newsletterService.getNewsletterById(id);
    }

    @PutMapping(value = "/{id}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Edited", section = "Employee Communication")
    public ResponseEntity<EmployeeNewsletterResponse> updateNewsletter(
            @PathVariable Long id,
            @RequestParam(value = "document", required = false) MultipartFile documentFile,
            @RequestParam(value = "thumbnail", required = false) MultipartFile thumbnailFile,
            @RequestParam("request") String requestJson
    ) throws JsonProcessingException {
        EmployeeNewsletterRequest request = objectMapper.readValue(requestJson, EmployeeNewsletterRequest.class);
        return newsletterService.updateNewsletter(id, documentFile, thumbnailFile, request);
    }

    @DeleteMapping("/{id}")
    @TrackChange(action = "Deleted", section = "Employee Communication")
    public ResponseEntity<EmployeeNewsletter> deleteNewsletter(@PathVariable Long id) {
        EmployeeNewsletter result = newsletterService.deleteNewsletter(id);

        return (result != null)
                ? new ResponseEntity<>(result, HttpStatus.OK) 
                : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}