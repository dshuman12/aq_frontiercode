package com.wafer.portal.dto;

public class MoodOfTheDayResponse {

    private String moodOfTheDay;

    public MoodOfTheDayResponse(String moodOfTheDay) {
        this.moodOfTheDay = moodOfTheDay;
    }

    public String getMoodOfTheDay() {
        return moodOfTheDay;
    }

    public void setMoodOfTheDay(String moodOfTheDay) {
        this.moodOfTheDay = moodOfTheDay;
    }
}
