package com.wafer.portal.repository;



import com.wafer.portal.model.DocumentTitle;
import com.wafer.portal.model.People;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DocumentTitleRepository extends JpaRepository<DocumentTitle,Long> {

    Page<DocumentTitle> findAll(Pageable pageable);

    Optional<DocumentTitle> findByTitle(String title);

    @Query("SELECT dt FROM DocumentTitle dt WHERE dt.isDeleted = false AND LOWER(dt.title) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    Page<DocumentTitle> searchDocumentTitles(@Param("keyword") String keyword, Pageable pageable);

    Page<DocumentTitle> findByIsDeletedFalse(Pageable pageable);

}
