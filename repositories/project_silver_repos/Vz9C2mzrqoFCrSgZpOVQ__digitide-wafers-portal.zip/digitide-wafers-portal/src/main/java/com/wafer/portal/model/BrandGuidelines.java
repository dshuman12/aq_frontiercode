package com.wafer.portal.model;

import com.wafer.portal.audit.Auditable;
import jakarta.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "brand_guidelines")
public class BrandGuidelines extends Auditable<String> implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "title", nullable = false)
    private String title;

    @Column(name = "document_key")
    private String documentKey;

    private Double sequence;

    @Column(name = "is_deleted", nullable = false)
    private boolean isDeleted = false;

    public BrandGuidelines() {}

    public BrandGuidelines(String title, String documentKey, Double sequence) {
        this.title = title;
        this.documentKey = documentKey;
        this.sequence = sequence;
        this.isDeleted = false;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDocumentKey() { return documentKey; }
    public void setDocumentKey(String documentKey) { this.documentKey = documentKey; }
    public Double getSequence() { return sequence; }
    public void setSequence(Double sequence) { this.sequence = sequence; }
    public boolean isDeleted() { return isDeleted; }
    public void setIsDeleted(boolean deleted) { isDeleted = deleted; }
}