package com.wafer.portal.dto;

import java.util.List;

public class SectionDocumentsDto {
    private Long section;
    private String sectionName;
    private List<DocumentCenterDto> documents;

    public SectionDocumentsDto(Long section, String sectionName, List<DocumentCenterDto> documents) {
        this.section = section;
        this.sectionName = sectionName;
        this.documents = documents;
    }

    public Long getSection() {
        return section;
    }

    public void setSection(Long section) {
        this.section = section;
    }

    public String getSectionName() { return sectionName; }
    public void setSectionName(String sectionName) { this.sectionName = sectionName; }

    public List<DocumentCenterDto> getDocuments() { return documents; }
    public void setDocuments(List<DocumentCenterDto> documents) { this.documents = documents; }
}
