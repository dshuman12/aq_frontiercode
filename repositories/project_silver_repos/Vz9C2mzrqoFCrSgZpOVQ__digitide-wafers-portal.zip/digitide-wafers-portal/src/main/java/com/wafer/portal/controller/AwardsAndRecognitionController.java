package com.wafer.portal.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wafer.portal.annotation.TrackChange;
import com.wafer.portal.dto.AwardsAndRecognitionRequest;
import com.wafer.portal.dto.AwardsAndRecognitionResponseDto;
import com.wafer.portal.model.AwardsAndRecognition;
import com.wafer.portal.service.AwardsAndRecognitionService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@Controller
@RestController
@RequestMapping("/api/v2/awards-and-recognition")
public class AwardsAndRecognitionController {

    private final AwardsAndRecognitionService awardsAndRecognitionService;

    public AwardsAndRecognitionController(AwardsAndRecognitionService awardsAndRecognitionService) {
        this.awardsAndRecognitionService = awardsAndRecognitionService;
    }


    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Added", section = "Awards and Recognition")
    public ResponseEntity<AwardsAndRecognitionResponseDto> createAward(
            @RequestParam("image") MultipartFile image,
            @RequestParam("request") String requestJson) throws JsonProcessingException {
        AwardsAndRecognitionRequest request = new ObjectMapper().readValue(requestJson, AwardsAndRecognitionRequest.class);
        return awardsAndRecognitionService.createAward(image, request);
    }


    @GetMapping("/all")
    public ResponseEntity<Page<AwardsAndRecognitionResponseDto>> getAllAwards(Pageable pageable) {
        return awardsAndRecognitionService.getAllAwards(pageable);
    }

    @GetMapping("/{id}")
    public ResponseEntity<AwardsAndRecognitionResponseDto> getAwardById(@PathVariable Long id) {
        return awardsAndRecognitionService.getAwardById(id);
    }


    @PutMapping(value = "/{id}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Edited", section = "Awards and Recognition")
    public ResponseEntity<AwardsAndRecognitionResponseDto> updateAward(
            @PathVariable Long id,
            @RequestParam(value = "image", required = false) MultipartFile image,
            @RequestParam("request") String requestJson) throws JsonProcessingException {

        AwardsAndRecognitionRequest request = new ObjectMapper().readValue(requestJson, AwardsAndRecognitionRequest.class);
        return awardsAndRecognitionService.updateAward(id, image, request);
    }


    @DeleteMapping("/{id}")
    @TrackChange(action = "Deleted", section = "Awards and Recognition")
    public ResponseEntity<AwardsAndRecognition> deleteAward(@PathVariable Long id) {
        AwardsAndRecognition result = awardsAndRecognitionService.deleteAward(id);
        return (result != null)
                ? new ResponseEntity<>(result, HttpStatus.OK)
                : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}