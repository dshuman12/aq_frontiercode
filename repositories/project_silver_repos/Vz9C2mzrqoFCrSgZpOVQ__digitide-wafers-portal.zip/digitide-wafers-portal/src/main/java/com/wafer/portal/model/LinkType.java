package com.wafer.portal.model;

public enum LinkType {
    FILE,
    URL
}
