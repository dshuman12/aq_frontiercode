package com.wafer.portal.service;

import com.wafer.portal.model.SearchAnalytics;
import com.wafer.portal.repository.SearchAnalyticsRepository;
import org.springframework.stereotype.Service;

@Service
public class SearchAnalyticsService {

    private final SearchAnalyticsRepository repository;

    public SearchAnalyticsService(SearchAnalyticsRepository repository) {
        this.repository = repository;
    }

    public void markClicked(Long id) {

        SearchAnalytics data = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Not found"));

        data.setClicked(true);

        repository.save(data);
    }
}
