package com.wafer.portal.service;

import com.wafer.portal.model.FeedBack;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.services.ses.SesClient;
import software.amazon.awssdk.services.ses.model.*;

@Service
public class FeedbackEmailService {

    private static final Logger log = LoggerFactory.getLogger(FeedbackEmailService.class);
    private final SesClient sesClient;

    @Value("${app.email.from}")
    private String fromEmail;

    public FeedbackEmailService(SesClient sesClient) {
        this.sesClient = sesClient;
    }

    public void sendFeedbackStatusMail(String toEmail, FeedBack feedback) {

        String subjectText = "Feedback Status Update";
        String bodyText = buildEmailBodyText(feedback);

        SendEmailRequest request = SendEmailRequest.builder()
                .source(fromEmail)
                .destination(Destination.builder()
                        .toAddresses(toEmail)
                        .build())
                .message(Message.builder()
                        .subject(Content.builder()
                                .data(subjectText)
                                .charset("UTF-8")
                                .build())
                        .body(Body.builder()
                                .text(Content.builder()
                                        .data(bodyText)
                                        .charset("UTF-8")
                                        .build())
                                .build())
                        .build())
                .build();

        try {
            sesClient.sendEmail(request);
        } catch (SesException e) {
            log.error("SES email failed", e);
            throw e;
        }


    }


    private String buildEmailBodyText(FeedBack feedback) {

        String status = feedback.isTicketClosed() ? "Closed" : "Open";

        String latestRemark = feedback.getAdminRemarks().isEmpty()
                ? "No remarks"
                : feedback.getAdminRemarks().get(0).getRemark();

        //feedback.getAdminRemarks()


        return
                "Dear Employee,\n\n" +
                        "Thank you for sharing your feedback with us.\n\n" +
                        "We would like to inform you that your feedback has been reviewed by the HR team. " +
                        "Please find the details below:\n\n" +

                        "Feedback: " + feedback.getFeedbackDescription() + "\n\n" +

                        "Status: " + status + "\n\n" +

                        "Date: " + feedback.getFeedbackDate() + "\n\n" +

                        "HR Remarks: " + latestRemark + "\n\n" +

                        "Regards,\n" +
                        "HR Team\n\n" +

                        "Note: This is an automatic reply email. Please do not reply to this email.";
    }



//    private String buildEmailBody(FeedBack feedback) {
//        return "Dear Employee,\n\n"
//                + "Your feedback has been reviewed.\n\n"
//                + "Feedback: " + feedback.getFeedbackDescription() + "\n\n"
//                + "Status: " + (feedback.isActionTaken() ? "Action Taken" : "Pending") + "\n"
//                + "Date: " + feedback.getFeedbackDate() + "\n\n"
//                + "Admin Remarks:\n"
//                + feedback.getAdminRemarks() + "\n\n"
//                + "Regards,\n"
//                + "HR Team";
//    }
}
