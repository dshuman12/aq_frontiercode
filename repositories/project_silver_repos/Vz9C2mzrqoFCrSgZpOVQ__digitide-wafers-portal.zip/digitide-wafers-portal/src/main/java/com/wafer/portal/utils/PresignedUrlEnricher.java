package com.wafer.portal.utils;

import com.wafer.portal.awsS3.S3Service;
import jakarta.persistence.EntityManager;
import org.springframework.stereotype.Service;

import java.lang.reflect.Field;
import java.util.List;

@Service
public class PresignedUrlEnricher {

    private final S3Service s3Service;
    private final EntityManager entityManager;

    public PresignedUrlEnricher(S3Service s3Service, EntityManager entityManager) {
        this.s3Service = s3Service;
        this.entityManager = entityManager;
    }

    public void enrich(Object entity) {

        if (entity == null) return;

        try {
            entityManager.detach(entity);
        } catch (IllegalArgumentException ignored) { }

        Field[] fields = entity.getClass().getDeclaredFields();

        for (Field field : fields) {

            if (!field.getType().equals(String.class)) continue;

            field.setAccessible(true);

            try {
                Object value = field.get(entity);

                if (value == null) continue;

                String key = value.toString();

                if (key.startsWith("http")) continue;

                if (key.startsWith("wafers/")) {
                    field.set(entity, s3Service.generatePresignedUrl(key));
                }

            } catch (Exception e) {
                throw new RuntimeException(
                        "Failed to enrich presigned URL for field: "
                                + field.getName()
                                + " in "
                                + entity.getClass().getSimpleName(),
                        e
                );
            }
        }
    }

    public <T> List<T> enrichList(List<T> list) {
        list.forEach(this::enrich);
        return list;
    }
}