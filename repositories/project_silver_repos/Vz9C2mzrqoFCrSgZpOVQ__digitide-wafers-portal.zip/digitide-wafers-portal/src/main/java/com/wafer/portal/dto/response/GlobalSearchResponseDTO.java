package com.wafer.portal.dto.response;

public class GlobalSearchResponseDTO {

    private Long searchId;
    private WhatsHappeningDTO whatsHappening;
    private VideoSectionDTO video;
    private Object companyInfo;
    private Object awardsRecognition;
    private Object leadership;
    private Object marquee;
    private Object hobbyHub;
    private Object brandGuidelines;
    private Object coffeeWithLeaders;
    private Object documentCenter;
    private Object employeeNewsletter;
    private Object quickLinkHeader;
    private Object quickLinkSubHeader;
    private Object rewardsAndRecognition;
    private Object spotlight;
    private Object survey;
    private Object topNews;
    private Object helpAndSupport;

    public Long getSearchId() {
        return searchId;
    }

    public void setSearchId(Long searchId) {
        this.searchId = searchId;
    }

    public WhatsHappeningDTO getWhatsHappening() {
        return whatsHappening;
    }

    public void setWhatsHappening(WhatsHappeningDTO whatsHappening) {
        this.whatsHappening = whatsHappening;
    }

    public VideoSectionDTO getVideo() {
        return video;
    }

    public void setVideo(VideoSectionDTO video) {
        this.video = video;
    }

    public Object getCompanyInfo() {
        return companyInfo;
    }

    public void setCompanyInfo(Object companyInfo) {
        this.companyInfo = companyInfo;
    }

    public Object getAwardsRecognition() {
        return awardsRecognition;
    }

    public void setAwardsRecognition(Object awardsRecognition) {
        this.awardsRecognition = awardsRecognition;
    }

    public Object getLeadership() {
        return leadership;
    }

    public void setLeadership(Object leadership) {
        this.leadership = leadership;
    }

    public Object getMarquee() {
        return marquee;
    }

    public void setMarquee(Object marquee) {
        this.marquee = marquee;
    }

    public Object getHobbyHub() {
        return hobbyHub;
    }

    public void setHobbyHub(Object hobbyHub) {
        this.hobbyHub = hobbyHub;
    }

    public Object getBrandGuidelines() {
        return brandGuidelines;
    }

    public void setBrandGuidelines(Object brandGuidelines) {
        this.brandGuidelines = brandGuidelines;
    }

    public Object getCoffeeWithLeaders() {
        return coffeeWithLeaders;
    }

    public void setCoffeeWithLeaders(Object coffeeWithLeaders) {
        this.coffeeWithLeaders = coffeeWithLeaders;
    }

    public Object getDocumentCenter() {
        return documentCenter;
    }

    public void setDocumentCenter(Object documentCenter) {
        this.documentCenter = documentCenter;
    }

    public Object getEmployeeNewsletter() {
        return employeeNewsletter;
    }

    public void setEmployeeNewsletter(Object employeeNewsletter) {
        this.employeeNewsletter = employeeNewsletter;
    }

    public Object getQuickLinkHeader() {
        return quickLinkHeader;
    }

    public void setQuickLinkHeader(Object quickLinkHeader) {
        this.quickLinkHeader = quickLinkHeader;
    }

    public Object getQuickLinkSubHeader() {
        return quickLinkSubHeader;
    }

    public void setQuickLinkSubHeader(Object quickLinkSubHeader) {
        this.quickLinkSubHeader = quickLinkSubHeader;
    }

    public Object getRewardsAndRecognition() {
        return rewardsAndRecognition;
    }

    public void setRewardsAndRecognition(Object rewardsAndRecognition) {
        this.rewardsAndRecognition = rewardsAndRecognition;
    }

    public Object getSpotlight() {
        return spotlight;
    }

    public void setSpotlight(Object spotlight) {
        this.spotlight = spotlight;
    }

    public Object getSurvey() {
        return survey;
    }

    public void setSurvey(Object survey) {
        this.survey = survey;
    }

    public Object getTopNews() {
        return topNews;
    }

    public void setTopNews(Object topNews) {
        this.topNews = topNews;
    }

    public Object getHelpAndSupport() {
        return helpAndSupport;
    }

    public void setHelpAndSupport(Object helpAndSupport) {
        this.helpAndSupport = helpAndSupport;
    }
}
