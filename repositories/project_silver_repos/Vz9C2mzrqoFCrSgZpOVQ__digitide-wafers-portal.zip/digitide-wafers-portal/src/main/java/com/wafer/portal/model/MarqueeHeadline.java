package com.wafer.portal.model;

import com.wafer.portal.audit.Auditable;
import jakarta.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "marquee_headline")
public class MarqueeHeadline extends Auditable<String> implements Serializable {

    @Id
    @Column(columnDefinition = "SMALLINT DEFAULT 1 CHECK (id = 1)")
    private Short id = 1; // Always one record (id = 1)

    @Column(columnDefinition = "TEXT", nullable = false)
    private String description; // The marquee text

    private Boolean isDeleted;

    public MarqueeHeadline() {
    }

    public MarqueeHeadline(Short id,String description) {
        this.description = description;
        this.isDeleted = false;
    }

    // Getters and Setters
    public Short getId() {
        return id;
    }

    public void setId(Short id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Boolean getDeleted() {
        return isDeleted;
    }

    public void setDeleted(Boolean deleted) {
        isDeleted = deleted;
    }
}
