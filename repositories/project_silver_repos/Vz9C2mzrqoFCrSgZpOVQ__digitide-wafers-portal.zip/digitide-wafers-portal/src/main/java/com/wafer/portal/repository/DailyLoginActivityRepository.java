
package com.wafer.portal.repository;


import com.wafer.portal.model.DailyLoginActivity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;


public interface DailyLoginActivityRepository extends JpaRepository<DailyLoginActivity, Long> {


    Optional<DailyLoginActivity> findByUserEmailAndLoginDateAndIsDeletedFalse(
            String userEmail,
            LocalDate loginDate
    );

    @Query(value = """
       SELECT
       (SELECT COUNT(DISTINCT user_email)
        FROM daily_login_activity
        WHERE is_deleted = false
        AND login_date BETWEEN :fromDate AND :toDate),

       (SELECT COUNT(DISTINCT user_email)
        FROM daily_login_activity
        WHERE login_date = :toDate
        AND is_deleted = false),

       (SELECT COUNT(DISTINCT user_email)
        FROM daily_login_activity
        WHERE login_date BETWEEN :weekStart AND :weekEnd
        AND is_deleted = false),

       (SELECT COUNT(DISTINCT user_email)
        FROM daily_login_activity
        WHERE login_date BETWEEN :fromDate AND :toDate
        AND is_deleted = false),

       (SELECT COUNT(DISTINCT d.user_email)
        FROM daily_login_activity d
        WHERE d.is_deleted = false
        AND d.login_date BETWEEN :fromDate AND :toDate
        AND NOT EXISTS (
            SELECT 1 FROM daily_login_activity p
            WHERE p.user_email = d.user_email
            AND p.is_deleted = false
            AND p.login_date < :fromDate
        )),

       (SELECT COUNT(DISTINCT d.user_email)
        FROM daily_login_activity d
        WHERE d.is_deleted = false
        AND d.login_date BETWEEN :fromDate AND :toDate
        AND EXISTS (
            SELECT 1 FROM daily_login_activity p
            WHERE p.user_email = d.user_email
            AND p.is_deleted = false
            AND p.login_date < :fromDate
        )),


       (SELECT AVG(login_count)
        FROM (
            SELECT user_email, COUNT(*) login_count
            FROM daily_login_activity
            WHERE is_deleted = false
            AND login_date BETWEEN :fromDate AND :toDate
            GROUP BY user_email
        ) x)
   """, nativeQuery = true)
    List<Object[]> fetchLoginAnalyticsByDateRange(LocalDate fromDate, LocalDate toDate, LocalDate weekStart, LocalDate weekEnd);



//    @Query(value = """
//   SELECT
//       COALESCE(designation, 'UNKNOWN') AS designation,
//
//
//       COUNT(DISTINCT user_email) AS total,
//
//
//       COUNT(DISTINCT user_email)
//           FILTER (WHERE login_date = CURRENT_DATE) AS daily,
//
//
//       COUNT(DISTINCT user_email)
//           FILTER (WHERE login_date >= CURRENT_DATE - INTERVAL '6 days') AS weekly,
//
//
//       COUNT(DISTINCT user_email)
//           FILTER (WHERE login_date >= CURRENT_DATE - INTERVAL '29 days') AS monthly
//
//   FROM daily_login_activity
//   WHERE is_deleted = false
//   AND login_date >= CURRENT_DATE - INTERVAL '89 days'
//
//   GROUP BY designation
//   ORDER BY total DESC
//""", nativeQuery = true)
//    List<Object[]> getDesignationWiseStats();

    @Query(value = """
SELECT
    COALESCE(designation, 'UNKNOWN') AS designation,

    COUNT(DISTINCT user_email) AS total,

    COUNT(DISTINCT user_email)
        FILTER (WHERE login_date = :toDate) AS daily,

    COUNT(DISTINCT user_email)
        FILTER (WHERE login_date BETWEEN :weekStart AND :weekEnd) AS weekly,

    COUNT(DISTINCT user_email)
        FILTER (WHERE login_date BETWEEN :fromDate AND :toDate) AS monthly

FROM daily_login_activity
WHERE is_deleted = false
AND login_date BETWEEN :fromDate AND :toDate

GROUP BY designation
ORDER BY total DESC
""", nativeQuery = true)
    List<Object[]> getDesignationWiseStatsByDateRange(
            LocalDate fromDate,
            LocalDate toDate,
            LocalDate weekStart,
            LocalDate weekEnd
    );


    @Query(value = """
   SELECT user_email, MAX(login_date) AS login_date, MAX(designation) AS designation
   FROM daily_login_activity
   WHERE is_deleted = false
   AND login_date BETWEEN :fromDate AND :toDate
   GROUP BY user_email
   ORDER BY MAX(login_date) DESC
""",
            countQuery = """
   SELECT COUNT(DISTINCT user_email)
   FROM daily_login_activity
   WHERE is_deleted = false
   AND login_date BETWEEN :fromDate AND :toDate
""",
            nativeQuery = true)
    Page<Object[]> getUniqueVisitorsListByDateRange(LocalDate fromDate, LocalDate toDate, Pageable pageable);

    @Query(value = """
   SELECT DISTINCT user_email, login_date, designation
   FROM daily_login_activity
   WHERE login_date = :toDate
   AND is_deleted = false
""",
            countQuery = """
   SELECT COUNT(DISTINCT user_email)
   FROM daily_login_activity
   WHERE login_date = :toDate
   AND is_deleted = false
""",
            nativeQuery = true)
    Page<Object[]> getDAUListByDateRange(LocalDate toDate, Pageable pageable);



    @Query(value = """
   SELECT user_email, MAX(login_date), MAX(designation)
   FROM daily_login_activity
   WHERE login_date BETWEEN :weekStart AND :weekEnd
   AND is_deleted = false
   GROUP BY user_email
""",
            countQuery = """
   SELECT COUNT(DISTINCT user_email)
   FROM daily_login_activity
   WHERE login_date BETWEEN :weekStart AND :weekEnd
   AND is_deleted = false
""",
            nativeQuery = true)
    Page<Object[]> getWAUListByDateRange(LocalDate weekStart, LocalDate weekEnd, Pageable pageable);



    @Query(value = """
   SELECT user_email, MAX(login_date), MAX(designation)
   FROM daily_login_activity
   WHERE login_date BETWEEN :fromDate AND :toDate
   AND is_deleted = false
   GROUP BY user_email
""",
            countQuery = """
   SELECT COUNT(DISTINCT user_email)
   FROM daily_login_activity
   WHERE login_date BETWEEN :fromDate AND :toDate
   AND is_deleted = false
""",
            nativeQuery = true)
    Page<Object[]> getMAUListByDateRange(LocalDate fromDate, LocalDate toDate, Pageable pageable);



    @Query(value = """
   SELECT d.user_email, MAX(d.login_date), MAX(d.designation)
   FROM daily_login_activity d
   JOIN (
       SELECT user_email, MIN(login_date) first_login
       FROM daily_login_activity
       WHERE is_deleted = false
       GROUP BY user_email
   ) f ON d.user_email = f.user_email
   WHERE f.first_login < :fromDate
   AND d.login_date BETWEEN :fromDate AND :toDate
   AND d.is_deleted = false
   GROUP BY d.user_email
""",
            countQuery = """
   SELECT COUNT(*)
   FROM (
       SELECT d.user_email
       FROM daily_login_activity d
       JOIN (
           SELECT user_email, MIN(login_date) first_login
           FROM daily_login_activity
           WHERE is_deleted = false
           GROUP BY user_email
       ) f ON d.user_email = f.user_email
       WHERE f.first_login < :fromDate
       AND d.login_date BETWEEN :fromDate AND :toDate
       AND d.is_deleted = false
       GROUP BY d.user_email
   ) t
""",
            nativeQuery = true)
    Page<Object[]> getReturningUsersListByDateRange(LocalDate fromDate, LocalDate toDate, Pageable pageable);


    @Query(value = """
   SELECT user_email, first_login, designation
   FROM (
       SELECT user_email, MIN(login_date) first_login, MAX(designation) designation
       FROM daily_login_activity
       WHERE is_deleted = false
       GROUP BY user_email
   ) t
   WHERE first_login BETWEEN :fromDate AND :toDate
""",
            countQuery = """
   SELECT COUNT(*)
   FROM (
       SELECT user_email
       FROM daily_login_activity
       WHERE is_deleted = false
       GROUP BY user_email
       HAVING MIN(login_date) BETWEEN :fromDate AND :toDate
   ) t
""",
            nativeQuery = true)
    Page<Object[]> getNewUsersListByDateRange(LocalDate fromDate, LocalDate toDate, Pageable pageable);



    @Query(value = """
   SELECT
       EXTRACT(YEAR FROM login_date) AS year,
       EXTRACT(MONTH FROM login_date) AS month,
       COUNT(DISTINCT user_email) AS active_users
   FROM daily_login_activity
   WHERE is_deleted = false
   AND login_date BETWEEN :startDate AND :endDate
   GROUP BY EXTRACT(YEAR FROM login_date), EXTRACT(MONTH FROM login_date)
   ORDER BY year, month
""", nativeQuery = true)
    List<Object[]> getMonthlyActiveUsers(LocalDate startDate, LocalDate endDate);


    @Query(value = """
   SELECT user_email, MAX(designation) AS designation, COUNT(*) AS login_count
   FROM daily_login_activity
   WHERE is_deleted = false
   AND login_date BETWEEN :fromDate AND :toDate
   GROUP BY user_email
   ORDER BY login_count DESC
""",
            countQuery = """
   SELECT COUNT(DISTINCT user_email)
   FROM daily_login_activity
   WHERE is_deleted = false
   AND login_date BETWEEN :fromDate AND :toDate
""",
            nativeQuery = true)
    Page<Object[]> getAvgLoginPerUserByDateRange(LocalDate fromDate, LocalDate toDate, Pageable pageable);

}
