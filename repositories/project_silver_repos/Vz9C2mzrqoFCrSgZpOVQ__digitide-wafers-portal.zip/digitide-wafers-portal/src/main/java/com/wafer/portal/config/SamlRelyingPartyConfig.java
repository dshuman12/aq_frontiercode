package com.wafer.portal.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.saml2.provider.service.registration.*;
import org.springframework.security.saml2.provider.service.registration.RelyingPartyRegistrations;
@Configuration
public class SamlRelyingPartyConfig {

    @Value("${app.domain-url}")
    private String domainUrl;

    @Bean
    public RelyingPartyRegistrationRepository relyingPartyRegistrationRepository() {
        try {
            String baseUrl = domainUrl.endsWith("/") ?
                    domainUrl.substring(0, domainUrl.length() - 1) : domainUrl;

            RelyingPartyRegistration azure = RelyingPartyRegistrations
                    .fromMetadataLocation("classpath:saml/azure-idp-metadata.xml")
                    .registrationId("azure")
                    .entityId(baseUrl + "/saml/metadata")

                    //.entityId(baseUrl + "/saml2/service-provider-metadata/azure")
                    .assertionConsumerServiceLocation(baseUrl + "/login/saml2/sso/azure")
                    .build();

            return new InMemoryRelyingPartyRegistrationRepository(azure);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to load SAML metadata. Check if azure-idp-metadata.xml exists in src/main/resources/saml/", e);
        }
    }
}