package com.wafer.portal.dto;

import jakarta.validation.constraints.NotBlank;

import java.time.LocalDate;

public class AllNewsRequest {
    @NotBlank
    private String title;
    @NotBlank
    private String url;

    private LocalDate allNewsDate;

    private Double sequence;


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public LocalDate getAllNewsDate() {
        return allNewsDate;
    }

    public void setAllNewsDate(LocalDate allNewsDate) {
        this.allNewsDate = allNewsDate;
    }

    public Double getSequence() {
        return sequence;
    }

    public void setSequence(Double sequence) {
        this.sequence = sequence;
    }
}

