package com.wafer.portal.service;

import com.wafer.portal.awsS3.S3Service;
import com.wafer.portal.dto.AllNewsRequest;
import com.wafer.portal.dto.AllNewsResponseDto;
import com.wafer.portal.model.AllNews;
import com.wafer.portal.repository.AllNewsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@Service
public class AllNewsService {

    private static final String ALL_NEWS_FOLDER = "All-News-Images";

    private static final String THUMBNAIL_FOLDER = "All-News-Thumbnails";


    private final AllNewsRepository allNewsRepository;
    private final S3Service s3Service;

    @Autowired
    public AllNewsService(AllNewsRepository allNewsRepository, S3Service s3Service) {
        this.allNewsRepository = allNewsRepository;
        this.s3Service = s3Service;
    }

    public ResponseEntity<AllNewsResponseDto> createNews(MultipartFile image, MultipartFile thumbnail, AllNewsRequest request) {
        try {
            if (image.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
            }
            String imageKey = s3Service.uploadFile(image, ALL_NEWS_FOLDER);
            String urlKey = null;

            if (thumbnail != null && !thumbnail.isEmpty()) {
                urlKey = s3Service.uploadFile(thumbnail, THUMBNAIL_FOLDER);
            }
            AllNews news = new AllNews(imageKey, request.getTitle(), urlKey, request.getUrl(), request.getAllNewsDate(), request.getSequence());
            AllNews saved = allNewsRepository.save(news);

            return new ResponseEntity<>(mapToResponseDto(saved), HttpStatus.CREATED);
        } catch (IOException e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Page<AllNewsResponseDto>> getAllNews(Pageable pageable) {
        Page<AllNews> newsPage = allNewsRepository.findAllOrderedBySequence(pageable);
        Page<AllNewsResponseDto> dtoPage = newsPage.map(this::mapToResponseDto);
        return dtoPage.isEmpty() ? new ResponseEntity<>(HttpStatus.NO_CONTENT) : new ResponseEntity<>(dtoPage, HttpStatus.OK);
    }

    public ResponseEntity<AllNewsResponseDto> getNewsById(Long id) {
        return allNewsRepository.findByIdAndIsDeletedFalse(id)
                .map(news -> new ResponseEntity<>(mapToResponseDto(news), HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    public ResponseEntity<AllNewsResponseDto> updateNews(
            Long id,
            MultipartFile image,
            MultipartFile thumbnail,
            AllNewsRequest request) {

        return allNewsRepository.findByIdAndIsDeletedFalse(id)
                .map(existingNews -> {
                    try {
                        String updatedImageKey = existingNews.getImage();
                        String updatedThumbnailKey = existingNews.getThumbnail();

                        if (image != null && !image.isEmpty() && image.getOriginalFilename() != null
                                && !image.getOriginalFilename().isBlank()) {
                            updatedImageKey = s3Service.updateFile(existingNews.getImage(), image, ALL_NEWS_FOLDER);

                            boolean isVideo = image.getContentType() != null &&
                                    image.getContentType().startsWith("video");

                            if (isVideo) {
                                if (thumbnail != null && !thumbnail.isEmpty()) {
                                    updatedThumbnailKey = s3Service.updateFile(existingNews.getThumbnail(), thumbnail, THUMBNAIL_FOLDER);
                                }
                            } else {
                                if (thumbnail != null && !thumbnail.isEmpty()) {
                                    updatedThumbnailKey = s3Service.updateFile(existingNews.getThumbnail(), thumbnail, THUMBNAIL_FOLDER);
                                } else {
                                    updatedThumbnailKey = null;
                                }
                            }
                        }
                        else {
                            if (thumbnail != null && !thumbnail.isEmpty()) {
                                updatedThumbnailKey = s3Service.updateFile(existingNews.getThumbnail(), thumbnail, THUMBNAIL_FOLDER);
                            }
                        }

                        existingNews.setTitle(request.getTitle());
                        existingNews.setUrl(request.getUrl());
                        existingNews.setAllNewsDate(request.getAllNewsDate());
                        existingNews.setSequence(request.getSequence());
                        existingNews.setImage(updatedImageKey);
                        existingNews.setThumbnail(updatedThumbnailKey);

                        AllNews updated = allNewsRepository.save(existingNews);

                        return new ResponseEntity<>(mapToResponseDto(updated), HttpStatus.OK);

                    } catch (IOException e) {
                        return new ResponseEntity<AllNewsResponseDto>(HttpStatus.INTERNAL_SERVER_ERROR);
                    }
                })
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }


    public AllNews deleteNews(Long id) {
        return allNewsRepository.findByIdAndIsDeletedFalse(id)
                .map(news -> {
                    news.setIsDeleted(true);
                    return allNewsRepository.save(news);
                }).orElse(null);
    }

    private AllNewsResponseDto mapToResponseDto(AllNews news) {
        String preSignedUrl = s3Service.generatePresignedUrl(news.getImage());
        String prePresignedUrl1 = null;

        if (news.getThumbnail() != null && !news.getThumbnail().isEmpty()) {
            prePresignedUrl1 = s3Service.generatePresignedUrl(news.getThumbnail());
        }
        return new AllNewsResponseDto(
                news.getId(),
                news.getTitle(),
                preSignedUrl,
                prePresignedUrl1,
                news.getUrl(),
                news.getAllNewsDate(),
                news.getSequence(),
                news.getCreatedBy(),
                news.getCreationDate(),
                news.getLastModifiedBy(),
                news.getLastModifiedDate()
        );
    }
}

