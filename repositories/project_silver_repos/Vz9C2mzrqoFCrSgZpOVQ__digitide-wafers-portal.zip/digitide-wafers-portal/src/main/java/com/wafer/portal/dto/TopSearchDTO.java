package com.wafer.portal.dto;

public class TopSearchDTO {

    private String query;
    private Long count;

    public TopSearchDTO(String query, Long count) {
        this.query = query;
        this.count = count;
    }

    public String getQuery() {
        return query;
    }

    public Long getCount() {
        return count;
    }
}