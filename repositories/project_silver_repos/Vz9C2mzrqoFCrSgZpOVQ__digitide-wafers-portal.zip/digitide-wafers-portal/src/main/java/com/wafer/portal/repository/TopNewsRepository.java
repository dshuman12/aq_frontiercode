package com.wafer.portal.repository;

import com.wafer.portal.model.People;
import com.wafer.portal.model.TopNews;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TopNewsRepository extends JpaRepository<TopNews, Long> {

    @Query("SELECT t FROM TopNews t WHERE t.isDeleted = false ORDER BY t.topNewsDate DESC NULLS LAST")
    Page<TopNews> findAllWithDateSort(Pageable pageable);

    @Query("SELECT s FROM TopNews s WHERE s.isDeleted = false ORDER BY " +
            "CASE WHEN s.sequence IS NULL THEN 1 ELSE 0 END, s.sequence ASC")
    Page<TopNews> findAllOrderedBySequence(Pageable pageable);

    Page<TopNews> findByIsDeletedFalse(Pageable pageable);
    Optional<TopNews> findByIdAndIsDeletedFalse(Long aLong);

    @Query("SELECT t FROM TopNews t WHERE t.isDeleted = false AND " +
            "(LOWER(t.title) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(t.newsDescription) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(t.url) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    Page<TopNews> searchTopNews(@Param("keyword") String keyword, Pageable pageable);


}
