package com.wafer.portal.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wafer.portal.annotation.TrackChange;
import com.wafer.portal.dto.PicOfTheDayRequest;
import com.wafer.portal.dto.PicOfTheDayResponse;
import com.wafer.portal.service.PicOfTheDayService;
import jakarta.validation.Valid;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/v2/pic-of-the-day")
public class PicOfTheDayController {

    private final PicOfTheDayService picService;

    public PicOfTheDayController(PicOfTheDayService picService) {
        this.picService = picService;
    }

    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Added", section = "Pic of the Day")
    public ResponseEntity<PicOfTheDayResponse> uploadPic(
            @RequestParam("image") MultipartFile image,
            @RequestParam(value = "thumbnail", required = false) MultipartFile thumbnail,
            @RequestParam("request") String requestJson
    ) throws JsonProcessingException {
        PicOfTheDayRequest request = new ObjectMapper().readValue(requestJson, PicOfTheDayRequest.class);
        return picService.uploadPic(image, thumbnail, request);
    }

    @GetMapping
    public ResponseEntity<PicOfTheDayResponse> getPicOfTheDay() {
        return picService.getPicOfTheDay();
    }

    @PutMapping(value = "/update", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Edited", section = "Pic of the Day")
    public ResponseEntity<PicOfTheDayResponse> updatePic(
            @RequestParam(value = "image", required = false) MultipartFile image,
            @RequestParam(value = "thumbnail", required = false) MultipartFile thumbnail,
            @RequestParam("request") String requestJson
    ) throws JsonProcessingException {
        PicOfTheDayRequest request = new ObjectMapper().readValue(requestJson, PicOfTheDayRequest.class);
        return picService.updatePic(image, thumbnail, request);
    }

}
