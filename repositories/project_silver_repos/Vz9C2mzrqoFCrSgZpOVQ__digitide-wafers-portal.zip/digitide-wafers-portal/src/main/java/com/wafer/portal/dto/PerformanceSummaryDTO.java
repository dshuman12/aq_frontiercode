package com.wafer.portal.dto;

public class PerformanceSummaryDTO {

    private Long totalRequests;
    private Double avgApiTime;
    private Double avgPageLoad;
    private Long errorCount;

    public PerformanceSummaryDTO(Long totalRequests, Double avgApiTime,
                                 Double avgPageLoad, Long errorCount) {
        this.totalRequests = totalRequests;
        this.avgApiTime = avgApiTime;
        this.avgPageLoad = avgPageLoad;
        this.errorCount = errorCount;
    }

    public Long getTotalRequests() {
        return totalRequests;
    }

    public Double getAvgApiTime() {
        return avgApiTime;
    }

    public Double getAvgPageLoad() {
        return avgPageLoad;
    }

    public Long getErrorCount() {
        return errorCount;
    }
}