package com.wafer.portal.repository;

import com.wafer.portal.model.DailyMood;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface DailyMoodRepository extends JpaRepository<DailyMood, Long> {

    @Query("SELECT dm FROM DailyMood dm WHERE dm.createdBy = :createdBy AND DATE(dm.creationDate) = :moodDate")
    Optional<DailyMood> findByCreatedByAndMoodDate(@Param("createdBy") String createdBy, @Param("moodDate") LocalDate moodDate);

    List<DailyMood> findByCreatedByOrderByCreationDateDesc(String createdBy);

    List<DailyMood> findAllByOrderByCreationDateDesc();

    Page<DailyMood> findAllByOrderByCreationDateDesc(Pageable pageable);

    //only specific user mood history
    List<DailyMood> findByCreatedByAndCreationDateBetweenOrderByCreationDateDesc(
            String createdBy,
            java.time.LocalDateTime startDateTime,
            java.time.LocalDateTime endDateTime
    );

    // all users of specific mood history
    Page<DailyMood> findByCreationDateBetweenOrderByCreationDateDesc(
            java.time.LocalDateTime startDate,
            java.time.LocalDateTime endDate, Pageable pageable
    );


    @Query("SELECT d FROM DailyMood d " +
            "WHERE LOWER(d.mood) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    List<DailyMood> searchDailyMood(@Param("keyword") String keyword);

    @Query("""
SELECT dm.mood, COUNT(dm)
FROM DailyMood dm
WHERE DATE(dm.creationDate) BETWEEN :startDate AND :endDate
GROUP BY dm.mood
""")
    List<Object[]> getMoodCounts(LocalDate startDate, LocalDate endDate);

}