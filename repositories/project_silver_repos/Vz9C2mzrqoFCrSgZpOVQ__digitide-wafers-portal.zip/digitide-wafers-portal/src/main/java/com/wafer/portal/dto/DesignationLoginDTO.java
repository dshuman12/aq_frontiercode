package com.wafer.portal.dto;

public class DesignationLoginDTO {

    private String designation;
    private Long total;
    private Long daily;
    private Long weekly;
    private Long monthly;

    public DesignationLoginDTO(String designation,
                               Long total,
                               Long daily,
                               Long weekly,
                               Long monthly) {
        this.designation = designation;
        this.total = total;
        this.daily = daily;
        this.weekly = weekly;
        this.monthly = monthly;
    }

    public String getDesignation() {
        return designation;
    }

    public Long getTotal() {
        return total;
    }

    public Long getDaily() {
        return daily;
    }

    public Long getWeekly() {
        return weekly;
    }

    public Long getMonthly() {
        return monthly;
    }
}