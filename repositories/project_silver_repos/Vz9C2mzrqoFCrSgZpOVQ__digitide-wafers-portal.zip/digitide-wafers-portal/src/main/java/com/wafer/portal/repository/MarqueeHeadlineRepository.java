package com.wafer.portal.repository;

import com.wafer.portal.model.MarqueeHeadline;
import com.wafer.portal.model.People;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface MarqueeHeadlineRepository extends JpaRepository<MarqueeHeadline, Short> {
    Page<MarqueeHeadline> findByIsDeletedFalse(Pageable pageable);
    Optional<MarqueeHeadline> findByIdAndIsDeletedFalse(Short ashort);

    @Query("SELECT m FROM MarqueeHeadline m WHERE m.isDeleted = false AND " +
            "LOWER(m.description) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    List<MarqueeHeadline> searchMarquee(@Param("keyword") String keyword);

    List<MarqueeHeadline> findByIsDeletedFalse();

}
