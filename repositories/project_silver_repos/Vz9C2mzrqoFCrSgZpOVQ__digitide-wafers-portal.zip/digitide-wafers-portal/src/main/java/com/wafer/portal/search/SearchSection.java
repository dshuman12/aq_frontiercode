package com.wafer.portal.search;

public enum SearchSection {

    // News
    TOP_NEWS("top", "news", "top news"),
    ALL_NEWS("all", "news", "all news" , "what", "whats", "happening", "whats happening"),

    // Whats Happening
    EMPLOYEE_SPOTLIGHT("emp", "employee", "spot", "employee spotlight", "what", "whats", "happening", "whats happening" ),
    EVENTS("eve", "event", "events", "what", "whats", "happening", "whats happening"),
    ANNOUNCEMENTS("ann", "announce", "announcement", "announcements", "what", "whats", "happening", "whats happening"),
    MILESTONES("mile", "milestone", "milestones", "what", "whats", "happening", "whats happening"),

    // Documents
    DOCUMENTS("doc", "docs", "document", "documents"),
    DOCUMENT_CENTER("document center", "docs center", "document centre"),
    DOCUMENT_TITLES("doc", "docs", "title", "titles", "document title", "document titles"),

    // Links
    QUICK_LINK_HEADER("qui", "quick", "link", "links", "quick links"),
    QUICK_LINK_SUB_HEADER("qui", "quick", "link", "links", "quick link"),

    // Others
    //DAILY_MOOD("mood", "daily", "daily mood"),
    SPOTLIGHT("spo", "spotlight"),
    SURVEY("sur", "survey"),
    COMPANY_INFO("com", "company", "info", "company info"),
    LEADERSHIP("lea", "leader", "leaders", "leadership"),

    // Media & Branding
    MARQUEE("mar", "marquee"),
    HOBBY_HUB("hob", "hobby", "hub" , "hobby hub"),
    BRAND_GUIDELINES("bra", "gui","brand", "guideline", "guidelines", "brand guidelines"),
    COFFEE_WITH_LEADERS("cof", "lea", "coffee", "leader", "leaders", "coffee with leaders"),

    // HR & Recognition
    AWARDS("awa", "award", "awards"),
    REWARDS_AND_RECOGNITION("rew", "rec", "reward", "rewards", "recognition"),

    // Support
    //FEEDBACK("feed", "feedback"),
    HELP_AND_SUPPORT("hel", "sup", "help", "support"),
    EMPLOYEE_NEWSLETTER("emp", "new", "news", "letter","com", "communication", "employee communication", "newsletter","employee", "employee newsletter");


    private final String[] keywords;

    SearchSection(String... keywords) {
        this.keywords = keywords;
    }

//    public boolean matches(String search) {
//        for (String keyword : keywords) {
//            if (search.startsWith(keyword)) {
//                return true;
//            }
//        }
//        return false;
//    }

    public boolean matches(String search) {

        String normalized = search.trim().toLowerCase();

        for (String keyword : keywords) {

            if (normalized.equals(keyword)) {
                return true;
            }

            if (normalized.startsWith(keyword + " ")) {
                return true;
            }

            if (keyword.startsWith(normalized)) {
                return true;
            }
        }

        return false;
    }

}
