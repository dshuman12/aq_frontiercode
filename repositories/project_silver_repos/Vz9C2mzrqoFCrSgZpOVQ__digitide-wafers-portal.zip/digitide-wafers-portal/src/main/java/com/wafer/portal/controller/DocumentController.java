package com.wafer.portal.controller;

import com.wafer.portal.annotation.TrackChange;
import com.wafer.portal.awsS3.S3Service;
import com.wafer.portal.dto.DocumentResponseDto;
import com.wafer.portal.model.Document;
import com.wafer.portal.model.DocumentTitle;
import com.wafer.portal.repository.DocumentTitleRepository;
import com.wafer.portal.service.DocumentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@RestController
@RequestMapping("/api/v1/documents")
public class DocumentController {

    private static  final Logger logger =  LoggerFactory.getLogger(DocumentController.class);

    private final DocumentService documentService;
    private final S3Service s3Service;
    private final DocumentTitleRepository repository;

    public DocumentController(DocumentService documentService, S3Service s3Service, DocumentTitleRepository repository) {
        this.documentService = documentService;
        this.s3Service = s3Service;
        this.repository = repository;
    }

    @PostMapping(value = "/upload",consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Added", section = "Document")
    public ResponseEntity<DocumentResponseDto> uploadDocuments(
            @RequestParam("name") String name,
            @RequestPart("file") MultipartFile file) {

        try {

            DocumentTitle documentTitle = repository.findByTitle(name).orElse(null);

            if(documentTitle == null){
                return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
            }


            Document uploaded = documentService.uploadDocument(name, file, documentTitle);
            String preSignedUrl = s3Service.generatePresignedUrl(uploaded.getS3Url());

            DocumentResponseDto responseDto = new DocumentResponseDto(uploaded.getId(), uploaded.getName(), preSignedUrl,documentTitle.getTitle(),uploaded.getCreatedBy(), uploaded.getCreationDate(), uploaded.getLastModifiedBy(), uploaded.getLastModifiedDate());

            return new ResponseEntity<>(responseDto, HttpStatus.CREATED);

        } catch (IOException e) {
            e.printStackTrace();
            logger.error("IoException occurred while uploading documents", e);
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("Unexpected error occurred while uploading documents", e);
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/all")
    public ResponseEntity<Page<DocumentResponseDto>> getAllDocuments(Pageable pageable) {
        Page<Document> documents = documentService.getAllDocuments(pageable);

        Page<DocumentResponseDto> dtoPage = documents.map(document -> {
            String preSignedUrl = s3Service.generatePresignedUrl(document.getS3Url());
            return  new DocumentResponseDto(document.getId(), document.getName(), preSignedUrl,document.getDocumentTitle().getTitle(),document.getCreatedBy(), document.getCreationDate(), document.getLastModifiedBy(), document.getLastModifiedDate() );
        });
        return dtoPage.isEmpty() ? new ResponseEntity<>(HttpStatus.NO_CONTENT) : new ResponseEntity<>(dtoPage, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<DocumentResponseDto> getDocument(@PathVariable Long id) {
        return documentService.getDocumentById(id)
                .map(document ->{
                    String preSignedUrl = s3Service.generatePresignedUrl(document.getS3Url());
                    DocumentResponseDto dto = new DocumentResponseDto(document.getId(), document.getName(), preSignedUrl,document.getDocumentTitle().getTitle(),document.getCreatedBy(), document.getCreationDate(), document.getLastModifiedBy(), document.getLastModifiedDate());
                    return new ResponseEntity<>(dto, HttpStatus.OK);
                }).orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PutMapping(value = "/{id}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Edited", section = "Document")
    public ResponseEntity<DocumentResponseDto> updateDocument(
            @PathVariable Long id,
            @RequestParam(required = false) String name,
            @RequestPart(required = false) MultipartFile file) {
        try {
            Document updatedDoc = documentService.updateDocument(id, name, file);
            String preSignedUrl = s3Service.generatePresignedUrl(updatedDoc.getS3Url());
            DocumentResponseDto responseDto = new DocumentResponseDto(
                    updatedDoc.getId(),
                    updatedDoc.getName(),
                    preSignedUrl,
                    updatedDoc.getDocumentTitle().getTitle(),
                    updatedDoc.getCreatedBy(),
                    updatedDoc.getCreationDate(),
                    updatedDoc.getLastModifiedBy(),
                    updatedDoc.getLastModifiedDate()
            );
            return new ResponseEntity<>(responseDto, HttpStatus.OK);
        } catch (IOException e) {
            e.printStackTrace();
            logger.error("IoException occurred while updating documents", e);
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("Unexpected error occurred while updating documents", e);
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/{id}")
    @TrackChange(action = "Deleted", section = "Document")
    public ResponseEntity<Document> deleteDocument(@PathVariable Long id) {
        try {
            Document result = documentService.softDeleteDocument(id);
            return new ResponseEntity<>(result, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            logger.error("Failed to delete document with ID: {}", id, e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
