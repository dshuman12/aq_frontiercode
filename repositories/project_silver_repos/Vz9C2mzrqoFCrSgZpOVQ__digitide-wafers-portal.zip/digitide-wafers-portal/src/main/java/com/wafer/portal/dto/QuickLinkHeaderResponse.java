package com.wafer.portal.dto;

import com.wafer.portal.model.QuickLinkHeader;
import com.wafer.portal.model.QuickLinkSubHeader;

import java.time.LocalDateTime;
import java.util.List;

public class QuickLinkHeaderResponse {
    private Long id;
    private String title;
    private String url;
    private List<QuickLinkSubHeaderResponseDTO> quickLinkSubHeaderList;

    // Auditable fields
    private String createdBy;
    private LocalDateTime creationDate;
    private String lastModifiedBy;
    private LocalDateTime lastModifiedDate;

    public QuickLinkHeaderResponse() {
    }

    public QuickLinkHeaderResponse(Long id, String title, String url, List<QuickLinkSubHeaderResponseDTO> quickLinkSubHeaderList , String createdBy, LocalDateTime creationDate, String lastModifiedBy, LocalDateTime lastModifiedDate) {
        this.id = id;
        this.title = title;
        this.url = url;
        this.quickLinkSubHeaderList = quickLinkSubHeaderList;
        this.createdBy = createdBy;
        this.creationDate = creationDate;
        this.lastModifiedBy = lastModifiedBy;
        this.lastModifiedDate = lastModifiedDate;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public List<QuickLinkSubHeaderResponseDTO> getQuickLinkSubHeaderList() {
        return quickLinkSubHeaderList;
    }

    public void setQuickLinkSubHeaderList(List<QuickLinkSubHeaderResponseDTO> quickLinkSubHeaderList) {
        this.quickLinkSubHeaderList = quickLinkSubHeaderList;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public LocalDateTime getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(LocalDateTime creationDate) {
        this.creationDate = creationDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public LocalDateTime getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(LocalDateTime lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }
}
