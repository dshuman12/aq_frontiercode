package com.wafer.portal.service;

import com.wafer.portal.awsS3.S3Service;
import com.wafer.portal.model.Document;
import com.wafer.portal.model.DocumentTitle;
import com.wafer.portal.repository.DocumentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.io.IOException;
import java.util.Optional;

@Service
public class DocumentService {

    private final DocumentRepository documentRepository;
    private final S3Service s3Service;

    @Autowired
    public DocumentService(DocumentRepository documentRepository, S3Service s3Service) {
        this.documentRepository = documentRepository;
        this.s3Service = s3Service;
    }

    public Document uploadDocument(String name, MultipartFile file, DocumentTitle documentTitle) throws IOException {


        String s3Url = s3Service.uploadFile(file, "documents");


        Document document = new Document(name, s3Url, documentTitle);
        documentRepository.save(document);

        return document;
    }


    public Page<Document> getAllDocuments(Pageable pageable) {
        return documentRepository.findByIsDeletedFalse(pageable);
    }

    public Optional<Document> getDocumentById(Long id) {
        return documentRepository.findByIdAndIsDeletedFalse(id);
    }

    public Document updateDocument(Long id, String name, MultipartFile newFile) throws IOException {
        Document document = documentRepository.findByIdAndIsDeletedFalse(id)
                .orElseThrow(() -> new RuntimeException("Document not found with id " + id));

        if (!name.equals(document.getDocumentTitle().getTitle())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Document title mismatch");
        }

        if (newFile != null && !newFile.isEmpty()) {
            String newS3Url = s3Service.updateFile(document.getS3Url(), newFile, "documents");
            document.setS3Url(newS3Url);
        }


        return documentRepository.save(document);
    }

    public Document softDeleteDocument(Long id) {
        Document document = documentRepository.findByIdAndIsDeletedFalse(id)
                .orElseThrow(() -> new RuntimeException("Document not found with id " + id));

        document.setIsDeleted(true);
        return documentRepository.save(document);
    }


    //if we want to restore
    public void restoreDocument(Long id) {
        Document document = documentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Document not found with id " + id));
        document.setIsDeleted(false);
        documentRepository.save(document);
    }

}
