package com.wafer.portal.model;

import com.wafer.portal.audit.Auditable;
import jakarta.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "daily_mood", uniqueConstraints = {
        @UniqueConstraint(columnNames = {"created_by", "created_date"})
})
public class DailyMood extends Auditable<String> implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "mood", nullable = false)
    private Mood mood;


    public DailyMood() {
    }

    public DailyMood(Mood mood) {
        this.mood = mood;
    }

    // --- Enum for Mood Type ---
    public enum Mood {
        HAPPY, SAD, NEUTRAL
    }

    // --- Getters and Setters ---

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Mood getMood() {
        return mood;
    }

    public void setMood(Mood mood) {
        this.mood = mood;
    }

}