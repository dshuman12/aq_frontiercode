package com.wafer.portal.controller;

import com.wafer.portal.annotation.TrackChange;
import com.wafer.portal.dto.MarqueeHeadlineRequest;
import com.wafer.portal.dto.MarqueeHeadlineResponse;
import com.wafer.portal.model.MarqueeHeadline;
import com.wafer.portal.service.MarqueeHeadlineService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v2/marquee-headline")
public class MarqueeHeadlineController {

    private final MarqueeHeadlineService headlineService;

    public MarqueeHeadlineController(MarqueeHeadlineService headlineService) {
        this.headlineService = headlineService;
    }

    //  Get the current headline
    @GetMapping
    public ResponseEntity<MarqueeHeadlineResponse> getHeadline() {
        return headlineService.getHeadline();
    }

    @PostMapping("/save")
    @TrackChange(action = "Added", section = "Marquee Headline")
    public ResponseEntity<MarqueeHeadlineResponse> saveHeadline(
            @Valid @RequestBody MarqueeHeadlineRequest request
    ) {
        return headlineService.saveHeadline(request);
    }

    @PutMapping("/{id}")
    @TrackChange(action = "Edited", section = "Marquee Headline")
    public ResponseEntity<MarqueeHeadlineResponse> updateHeadline(
            @PathVariable Short id,
            @Valid @RequestBody MarqueeHeadlineRequest request
    ) {
        return headlineService.updateMarqueHeadline(id,request);
    }

    @DeleteMapping("/{id}")
    @TrackChange(action = "Deleted", section = "Marquee Headline")
    public ResponseEntity<MarqueeHeadline> clearHeadline(@PathVariable Short id) {
        MarqueeHeadline result = headlineService.clearHeadline(id);
        return (result != null)
                ? new ResponseEntity<>(result, HttpStatus.OK)
                : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

}
