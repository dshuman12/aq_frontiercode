package com.wafer.portal.dto;

public class TimeBasedClicksDTO {
    private String label;   // Mon, Tue OR 2026-02-20
    private Long totalClicks;

    public TimeBasedClicksDTO(String label, Long totalClicks) {
        this.label = label;
        this.totalClicks = totalClicks;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public Long getTotalClicks() {
        return totalClicks;
    }

    public void setTotalClicks(Long totalClicks) {
        this.totalClicks = totalClicks;
    }
}
