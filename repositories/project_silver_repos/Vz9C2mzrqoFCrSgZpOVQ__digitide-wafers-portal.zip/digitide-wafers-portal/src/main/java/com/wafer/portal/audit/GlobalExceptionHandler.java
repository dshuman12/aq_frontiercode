//package com.wafer.portal.audit;
//
//import com.fasterxml.jackson.core.JsonProcessingException;
//import com.fasterxml.jackson.core.type.TypeReference;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.wafer.portal.dto.response.BasicResponse;
//import com.wafer.portal.utils.Utils;
//import jakarta.validation.ConstraintViolationException;
//import jakarta.validation.ValidationException;
//import org.springframework.context.MessageSource;
//import org.springframework.core.io.buffer.DataBufferLimitException;
//import org.springframework.http.HttpHeaders;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.HttpStatusCode;
//import org.springframework.http.ResponseEntity;
//import org.springframework.http.converter.HttpMessageNotReadableException;
//import org.springframework.security.access.AccessDeniedException;
//import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
//import org.springframework.validation.FieldError;
//import org.springframework.web.bind.MethodArgumentNotValidException;
//import org.springframework.web.bind.annotation.ExceptionHandler;
//import org.springframework.web.bind.annotation.ResponseStatus;
//import org.springframework.web.bind.annotation.RestControllerAdvice;
//import org.springframework.web.context.request.WebRequest;
//import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
//
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//import java.util.stream.Collectors;
//
//@RestControllerAdvice
//public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {
//
//    public static final String ERR_MSG = "errMsg";
//    public static final String ERR_TYPE = "errType";
//    public static final String ERR_LOG_PATTERN = "Exception: ({}): {}";
//    public static final String VALIDATION_FAILED = "Validation failed";
//    public final MessageSource messageSource;
//
//    public GlobalExceptionHandler(MessageSource messageSource) {
//        this.messageSource = messageSource;
//    }
//
//    @ExceptionHandler({AuthenticationCredentialsNotFoundException.class})
//    @ResponseStatus(HttpStatus.FORBIDDEN)
//    public ResponseEntity<BasicResponse<String>> handleAuthCrdNotFoundException(AuthenticationCredentialsNotFoundException exception, WebRequest request) {
//      //  log.error("AuthenticationCredentialsNotFoundException: {}", exception.getMessage());
//        return new ResponseEntity<>(BasicResponse.createErrorResponse(exception.getMessage(), HttpStatus.FORBIDDEN), HttpStatus.FORBIDDEN);
//    }
//
//
//
//    @ExceptionHandler({ValidationException.class})
//    @ResponseStatus(HttpStatus.OK)
//    public ResponseEntity<BasicResponse<String>> handelCustomException(ValidationException exception, WebRequest request) {
//        Map<String, Object> multiErrorMap;
//        String errorMsg = exception.getMessage();
//        Map<String, Object> errorMap = Utils.getErrorMap(errorMsg);
//        errorMsg = VALIDATION_FAILED;
//        if (errorMap.containsKey(ERR_MSG)) {
//            errorMsg = (String) errorMap.get(ERR_MSG);
//            errorMap.remove(ERR_MSG);
//        }
//        if (errorMap.containsKey(ERR_TYPE)) {
//            multiErrorMap = new HashMap<>();
//            errorMap.remove(ERR_TYPE);
//            errorMap.forEach((key, value) -> {
//                Map<String, Object> errorMapReceived = Utils.getErrorMap((String) value);
//                multiErrorMap.put(key, errorMapReceived);
//            });
//        } else {
//            multiErrorMap = null;
//        }
//        return new ResponseEntity<>(BasicResponse.createErrorResponse(errorMsg, multiErrorMap != null ? multiErrorMap : errorMap, HttpStatus.OK), HttpStatus.OK);
//    }
//
//    @Override
//    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
//                                                                  HttpHeaders headers, HttpStatusCode status, WebRequest request) {
//        Map<String, Object> errorMap = new HashMap<>();
//        ex.getBindingResult().getAllErrors().forEach((error) -> {
//            String fieldName = ((FieldError) error).getField();
//            String errorMessage = error.getDefaultMessage();
//            errorMap.put(fieldName, errorMessage);
//        });
//        return new ResponseEntity<>(BasicResponse.createErrorResponse(VALIDATION_FAILED, errorMap, HttpStatus.OK), HttpStatus.OK);
//    }
//
//    @ExceptionHandler({AccessDeniedException.class})
//    @ResponseStatus(HttpStatus.FORBIDDEN)
//    public ResponseEntity<BasicResponse<String>> handelAccessDeniedException(AccessDeniedException exception, WebRequest request) {
//        logError(exception);
//        return new ResponseEntity<>(BasicResponse.createErrorResponse(exception.getMessage(), HttpStatus.FORBIDDEN), HttpStatus.NOT_FOUND);
//    }
//
//
//    @ExceptionHandler({RuntimeException.class})
//    @ResponseStatus(HttpStatus.FORBIDDEN)
//    public ResponseEntity<BasicResponse<String>> handleGlobalException(Exception exception, WebRequest request) {
//        logError(exception);
//        return new ResponseEntity<>(BasicResponse.createErrorResponse(exception.getMessage()), HttpStatus.OK);
//    }
//
//
//
//
//    @ExceptionHandler({DataBufferLimitException.class})
//    public ResponseEntity<BasicResponse<String>> handleDataBufferLimitException(DataBufferLimitException exception,
//                                                                                WebRequest request) {
//        logError(exception);
//        return new ResponseEntity<>(BasicResponse.createErrorResponse(exception.getMessage()), HttpStatus.PAYLOAD_TOO_LARGE);
//    }
//
//    private void logError(Exception exception) {
//       // log.error(ERR_LOG_PATTERN, exception.getClass().getSimpleName(), exception.getMessage());
//    }
//}
