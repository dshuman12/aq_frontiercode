package com.wafer.portal.dto;

import java.util.List;

public class DashboardFullResponseDTO {

    private DashboardHeaderResponseDTO header;
    private List<ModuleBreakdownDTO> moduleBreakdown;
    private List<ModuleBreakdownDTO> mostAndLeast;
    private List<MonthlyUniqueUsersDTO> monthlyUniqueUsers;
    //private List<MonthlyActiveUsersDTO> monthlyActiveUsers;
    private List<DeepDiveResponseDTO> deepDive;
    //private List<TimeBasedClicksDTO> timeBasedClicks;
    private EngagementTrendDTO engagementTrend;
    private List<MoodPercentageDTO> moodPercentage;
    //private List<SlowApiDTO> slowApis;
    private DeviceBrowserBreakDownDTO deviceBrowserBreakDown;
    private Double systemUptime;
    List<DesignationLoginDTO> designationLogins;
    private LoginAnalyticsResponseDTO loginAnalytics;
    private SearchAnalyticsDTO searchAnalytics;
    private List<TopSearchDTO> topSearches;

    public DashboardFullResponseDTO(
            DashboardHeaderResponseDTO header,
            List<ModuleBreakdownDTO> moduleBreakdown,
            List<ModuleBreakdownDTO> mostAndLeast,
            List<MonthlyUniqueUsersDTO> monthlyUniqueUsers,
           // List<MonthlyActiveUsersDTO> monthlyActiveUsers,
            List<DeepDiveResponseDTO> deepDive,
            //List<TimeBasedClicksDTO> timeBasedClicks,
            EngagementTrendDTO engagementTrend,
            List<MoodPercentageDTO> moodPercentage,
           // List<SlowApiDTO> slowApi,
            DeviceBrowserBreakDownDTO deviceBrowserBreakDown,
            Double systemUptime,
            List<DesignationLoginDTO> designationLogins,
            LoginAnalyticsResponseDTO loginAnalytics,
            SearchAnalyticsDTO searchAnalytics,
            List<TopSearchDTO> topSearches

    ) {
        this.header = header;
        this.moduleBreakdown = moduleBreakdown;
        this.mostAndLeast = mostAndLeast;
        this.monthlyUniqueUsers = monthlyUniqueUsers;
        //this.monthlyActiveUsers = monthlyActiveUsers;
        this.deepDive = deepDive;
        //this.timeBasedClicks = timeBasedClicks;
        this.engagementTrend = engagementTrend;
        this.moodPercentage = moodPercentage;
       // this.slowApis = slowApi;
        this.deviceBrowserBreakDown = deviceBrowserBreakDown;
        this.systemUptime = systemUptime;
        this.designationLogins = designationLogins;
        this.loginAnalytics = loginAnalytics;
        this.searchAnalytics = searchAnalytics;
        this.topSearches = topSearches;
    }

    public DashboardHeaderResponseDTO getHeader() {
        return header;
    }

    public List<ModuleBreakdownDTO> getModuleBreakdown() {
        return moduleBreakdown;
    }

    public List<ModuleBreakdownDTO> getMostAndLeast() {
        return mostAndLeast;
    }

    public List<MonthlyUniqueUsersDTO> getMonthlyUniqueUsers() {
        return monthlyUniqueUsers;
    }

//    public List<MonthlyActiveUsersDTO> getMonthlyActiveUsers() {
//        return monthlyActiveUsers;
//    }

    public List<DeepDiveResponseDTO> getDeepDive() {
        return deepDive;
    }

    /*public List<TimeBasedClicksDTO> getTimeBasedClicks() {
        return timeBasedClicks;
    }*/

    public EngagementTrendDTO getEngagementTrend() {
        return engagementTrend;
    }

    public List<MoodPercentageDTO> getMoodPercentage() {
        return moodPercentage;
    }

//    public List<SlowApiDTO> getSlowApis() {
//        return slowApis;
//    }


    public DeviceBrowserBreakDownDTO getDeviceBrowserBreakDown() {
        return deviceBrowserBreakDown;
    }

    public Double getServerUptime() {
        return systemUptime;
    }

    public List<DesignationLoginDTO> getDesignationLogins() {
        return designationLogins;
    }

    public LoginAnalyticsResponseDTO getLoginAnalytics() {
        return loginAnalytics;
    }

    public SearchAnalyticsDTO getSearchAnalytics() {
        return searchAnalytics;
    }

    public List<TopSearchDTO> getTopSearches() {
        return topSearches;
    }
}
