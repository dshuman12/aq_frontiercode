package com.wafer.portal.dto;


public class MonthlyActiveUsersDTO {

    private Integer year;
    private Integer month;
    private Long activeUsers;


    public MonthlyActiveUsersDTO(Integer year, Integer month, Long activeUsers) {
        this.year = year;
        this.month = month;
        this.activeUsers = activeUsers;
    }


    public Integer getYear() {
        return year;
    }


    public Integer getMonth() {
        return month;
    }


    public Long getActiveUsers() {
        return activeUsers;
    }
}
