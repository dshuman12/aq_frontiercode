package com.wafer.portal.repository;

import com.wafer.portal.model.SystemUptime;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface SystemUptimeRepository extends JpaRepository<SystemUptime, Long> {

    List<SystemUptime> findByLogDate(LocalDate logDate);

}