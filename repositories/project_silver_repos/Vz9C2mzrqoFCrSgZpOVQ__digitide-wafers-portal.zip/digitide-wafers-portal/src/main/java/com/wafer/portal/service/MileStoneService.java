package com.wafer.portal.service;

import com.wafer.portal.model.MileStone;
import com.wafer.portal.model.People;
import com.wafer.portal.repository.MileStoneRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MileStoneService {
    @Autowired
    private MileStoneRepository mileStoneRepository;

    public MileStone saveMileStone(MileStone mileStone) {
        return mileStoneRepository.save(mileStone);
    }

    public Page<MileStone> getAllMileStones(Pageable pageable) {
        return mileStoneRepository.findAllOrderedBySequence(pageable);
    }

    public Optional<MileStone> getMileStoneById(Long id) {
        return mileStoneRepository.findByIdAndIsDeletedFalse(id);
    }

    public MileStone updateMileStone(Long id, People updatePeople) {
        return mileStoneRepository.findById(id).map(mileStone -> {
            mileStone.setImageUrl(updatePeople.getImageUrl());
            mileStone.setContent(updatePeople.getContent());
            return mileStoneRepository.save(mileStone);
        }).orElse(null);
    }

    public MileStone softDeleteMileStone(Long id) {
        return mileStoneRepository.findByIdAndIsDeletedFalse(id).map(mileStone -> {
            mileStone.setIsDeleted(true);
            return mileStoneRepository.save(mileStone);
        }).orElse(null);
    }
}
