package com.wafer.portal.service;


import com.wafer.portal.dto.DesignationLoginDTO;
import com.wafer.portal.dto.LoginAnalyticsResponseDTO;
import com.wafer.portal.dto.LoginUserDTO;
import com.wafer.portal.dto.MonthlyActiveUsersDTO;
import com.wafer.portal.dto.UserLoginFrequencyDTO;
import com.wafer.portal.model.DailyLoginActivity;
import com.wafer.portal.repository.DailyLoginActivityRepository;
import org.springframework.stereotype.Service;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;


import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.util.List;
import java.util.Optional;


@Service
public class DailyLoginActivityService {


    private final DailyLoginActivityRepository repository;


    public DailyLoginActivityService(DailyLoginActivityRepository repository) {
        this.repository = repository;
    }




    public DailyLoginActivity trackModuleLogin(String userEmail, String designation) {


        LocalDate today = LocalDate.now();


        Optional<DailyLoginActivity> existing =
                repository.findByUserEmailAndLoginDateAndIsDeletedFalse(userEmail, today);


        if (existing.isPresent()) {


            DailyLoginActivity activity = existing.get();


            activity.setLastModifiedDate(LocalDateTime.now());


            if (designation != null) {
                activity.setDesignation(designation);
            }


            return repository.save(activity);
        }


        DailyLoginActivity activity = new DailyLoginActivity();
        activity.setUserEmail(userEmail);
        activity.setLoginDate(today);
        activity.setDesignation(designation);


        return repository.save(activity);
    }
//    public DailyLoginActivity trackModuleLogin(String userEmail , String designation) {
//
//        LocalDate today = LocalDate.now();
//
//        Optional<DailyLoginActivity> existing =
//                repository.findByUserEmailAndLoginDateAndIsDeletedFalse(
//                        userEmail, today);
//
//        if(existing.isPresent()) {
//
//            DailyLoginActivity activity = existing.get();
//
//            activity.setLastModifiedDate(LocalDateTime.now());
//
//            return repository.save(activity);
//        }
//
//        DailyLoginActivity activity =
//                new DailyLoginActivity(userEmail, today);
//
//        return repository.save(activity);
//    }


    public LoginAnalyticsResponseDTO getLoginAnalytics(LocalDate fromDate, LocalDate toDate) {


        LocalDate[] weekRange = getMonthWeekRange(toDate);
        List<Object[]> results = repository.fetchLoginAnalyticsByDateRange(fromDate, toDate, weekRange[0], weekRange[1]);


        Object[] result = results.get(0);


        return new LoginAnalyticsResponseDTO(
                ((Number) result[0]).longValue(),
                ((Number) result[1]).longValue(),
                ((Number) result[2]).longValue(),
                ((Number) result[3]).longValue(),
                ((Number) result[4]).longValue(),
                ((Number) result[5]).longValue(),
                result[6] != null ? ((Number) result[6]).doubleValue() : 0.0
        );
    }


//    public List<DesignationLoginDTO> getDesignationWiseStats() {
//
//
//        return repository.getDesignationWiseStats()
//                .stream()
//                .map(obj -> new DesignationLoginDTO(
//                        (String) obj[0],
//                        ((Number) obj[1]).longValue(),
//                        ((Number) obj[2]).longValue(),
//                        ((Number) obj[3]).longValue(),
//                        ((Number) obj[4]).longValue()
//                ))
//                .toList();
//    }

    public List<DesignationLoginDTO> getDesignationWiseStats(
            LocalDate fromDate,
            LocalDate toDate) {

        LocalDate[] weekRange = getMonthWeekRange(toDate);

        return repository.getDesignationWiseStatsByDateRange(
                        fromDate,
                        toDate,
                        weekRange[0],
                        weekRange[1]
                )
                .stream()
                .map(obj -> new DesignationLoginDTO(
                        (String) obj[0],
                        ((Number) obj[1]).longValue(),
                        ((Number) obj[2]).longValue(),
                        ((Number) obj[3]).longValue(),
                        ((Number) obj[4]).longValue()
                ))
                .toList();
    }

    public Page<LoginUserDTO> getUniqueVisitorsList(LocalDate fromDate, LocalDate toDate, Pageable pageable) {
        return repository.getUniqueVisitorsListByDateRange(fromDate, toDate, pageable).map(this::mapToDTO);
    }


    public Page<LoginUserDTO> getDAUList(LocalDate toDate, Pageable pageable) {
        return repository.getDAUListByDateRange(toDate, pageable).map(this::mapToDTO);
    }


    public Page<LoginUserDTO> getWAUList(LocalDate toDate, Pageable pageable) {
        LocalDate[] weekRange = getMonthWeekRange(toDate);
        return repository.getWAUListByDateRange(weekRange[0], weekRange[1], pageable).map(this::mapToDTO);
    }


    public Page<LoginUserDTO> getMAUList(LocalDate fromDate, LocalDate toDate, Pageable pageable) {
        return repository.getMAUListByDateRange(fromDate, toDate, pageable).map(this::mapToDTO);
    }


    public Page<LoginUserDTO> getReturningUsersList(LocalDate fromDate, LocalDate toDate, Pageable pageable) {
        return repository.getReturningUsersListByDateRange(fromDate, toDate, pageable).map(this::mapToDTO);
    }


    public Page<LoginUserDTO> getNewUsersList(LocalDate fromDate, LocalDate toDate, Pageable pageable) {
        return repository.getNewUsersListByDateRange(fromDate, toDate, pageable).map(this::mapToDTO);
    }
    public LoginUserDTO mapToDTO(Object[] r) {
        return new LoginUserDTO(
                (String) r[0],
                ((java.sql.Date) r[1]).toLocalDate(),
                (String) r[2]
        );
    }


    public List<MonthlyActiveUsersDTO> getMonthlyActiveUsers(LocalDate startDate, LocalDate endDate) {
        return repository.getMonthlyActiveUsers(startDate, endDate)
                .stream()
                .map(obj -> new MonthlyActiveUsersDTO(
                        ((Number) obj[0]).intValue(),
                        ((Number) obj[1]).intValue(),
                        ((Number) obj[2]).longValue()
                ))
                .toList();
    }


    public Page<UserLoginFrequencyDTO> getAvgLoginPerUserList(LocalDate fromDate, LocalDate toDate, Pageable pageable) {
        return repository.getAvgLoginPerUserByDateRange(fromDate, toDate, pageable).map(obj -> new UserLoginFrequencyDTO(
                (String) obj[0],
                (String) obj[1],
                ((Number) obj[2]).longValue()
        ));
    }



//      Calculates the month-based week range for a given date.
//      Week 1: 1-7, Week 2: 8-14, Week 3: 15-21, Week 4: 22-28, Week 5: 29-end of month.
//      Returns [weekStart, weekEnd].

    public LocalDate[] getMonthWeekRange(LocalDate date) {
        int dayOfMonth = date.getDayOfMonth();
        int weekIndex = (dayOfMonth - 1) / 7; // 0-based: 0,1,2,3,4
        int weekStartDay = weekIndex * 7 + 1;
        int weekEndDay = Math.min(weekStartDay + 6, YearMonth.from(date).lengthOfMonth());


        LocalDate weekStart = date.withDayOfMonth(weekStartDay);
        LocalDate weekEnd = date.withDayOfMonth(weekEndDay);
        return new LocalDate[]{weekStart, weekEnd};
    }


}
