package com.wafer.portal.model;

import com.wafer.portal.audit.Auditable;
import jakarta.persistence.*;

import java.io.Serializable;
import java.time.LocalDate;

@Entity
@Table(name = "top_news")
public class TopNews extends Auditable<String> implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;

    private String image;

    @Column(name="thumbnail_url")
    private String thumbnail;

    private String newsDescription;

    private String url;

    private LocalDate topNewsDate;

    private Double sequence;

    @Column(name = "is_deleted",nullable = false)
    private boolean isDeleted;


    public TopNews() {
    }

    public TopNews(String imageKey, String thumbnail,String url, String title, LocalDate topNewsDate, String newsDescription, Double sequence) {
        this.title = title;
        this.image = imageKey;
        this.thumbnail = thumbnail;
        this.url = url;
        this.sequence=sequence;
        this.topNewsDate = topNewsDate;
        this.newsDescription = newsDescription;
        this.isDeleted = false;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title= title;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public LocalDate getTopNewsDate() {
        return topNewsDate;
    }

    public void setTopNewsDate(LocalDate topNewsDate) {
        this.topNewsDate = topNewsDate;
    }

    public String getNewsDescription() {
        return newsDescription;
    }

    public void setNewsDescription(String newsDescription) {
        this.newsDescription = newsDescription;
    }

    public boolean isDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(boolean deleted) {
        isDeleted = deleted;
    }

    public Double getSequence() {
        return sequence;
    }

    public void setSequence(Double sequence) {
        this.sequence = sequence;
    }
}

