package com.wafer.portal.config;

import com.wafer.portal.utils.CookieUtils;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class JwtAuthFilter extends OncePerRequestFilter {

    private static final Logger logger = LoggerFactory.getLogger(JwtAuthFilter.class);

    private final JwtTokenProvider tokenProvider;
    private final UserDetailsService userDetailsService;
    private final CookieUtils cookieUtils;

    public JwtAuthFilter(JwtTokenProvider tokenProvider, UserDetailsService userDetailsService, CookieUtils cookieUtils) {
        this.tokenProvider = tokenProvider;
        this.userDetailsService = userDetailsService;
        this.cookieUtils = cookieUtils;
    }

//    @Override
//    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
//            throws ServletException, IOException {
//        try {
//            String jwt = getJwtFromRequest(request);
//
//            if (StringUtils.hasText(jwt) && tokenProvider.validateToken(jwt)) {
//                String username = tokenProvider.getUsernameFromToken(jwt);
//
//                Claims claims = Jwts.parserBuilder()
//                        .setSigningKey(tokenProvider.key())
//                        .build()
//                        .parseClaimsJws(jwt)
//                        .getBody();
//
//                String rolesString = claims.get("roles", String.class);
//                List<GrantedAuthority> authorities = Arrays.stream(rolesString.split(","))
//                        .map(SimpleGrantedAuthority::new)
//                        .collect(Collectors.toList());
//
//                UserDetails userDetails = userDetailsService.loadUserByUsername(username);
//
//                UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(userDetails, null, authorities);
//                authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
//
//                SecurityContextHolder.getContext().setAuthentication(authentication);
//            }
//        } catch (Exception ex) {
//            logger.error("Could not set user authentication in security context", ex);
//        }
//
//        filterChain.doFilter(request, response);
//    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {

        String requestUri = request.getRequestURI();
        logger.info("=== JWT Filter Processing Request: {} {} ===", request.getMethod(), requestUri);

        try {
            String jwt = getJwtFromRequest(request);
            logger.info("JWT Token extracted: {}", jwt != null ? "Present (Length: " + jwt.length() + ")" : "Not found");

            if (StringUtils.hasText(jwt)) {
                logger.info("JWT Token found, validating...");

                if (tokenProvider.validateToken(jwt)) {
                    logger.info("✓ JWT Token is VALID");

                    String username = tokenProvider.getUsernameFromToken(jwt);
                    logger.info("✓ Username extracted from token: '{}'", username);

                    Claims claims = Jwts.parserBuilder()
                            .setSigningKey(tokenProvider.key())
                            .build()
                            .parseClaimsJws(jwt)
                            .getBody();

                    logger.info("✓ JWT Claims parsed successfully: {}", claims);

                    // Handle roles claim - it could be either String or List
                    List<GrantedAuthority> authorities = new ArrayList<>();
                    Object rolesObject = claims.get("roles");

                    logger.info("Roles claim: {} (Type: {})",
                            rolesObject,
                            rolesObject != null ? rolesObject.getClass().getSimpleName() : "null");

                    if (rolesObject != null) {
                        if (rolesObject instanceof List) {
                            // Handle as List<String>
                            @SuppressWarnings("unchecked")
                            List<String> rolesList = (List<String>) rolesObject;
                            logger.info("Processing roles as List: {}", rolesList);

                            authorities = rolesList.stream()
                                    .filter(Objects::nonNull)
                                    .map(String::trim)
                                    .filter(s -> !s.isEmpty())
                                    .map(SimpleGrantedAuthority::new)
                                    .collect(Collectors.toList());

                            logger.info("✓ Authorities created from List: {}", authorities);
                        } else if (rolesObject instanceof String) {
                            // Handle as comma-separated String
                            String rolesString = (String) rolesObject;
                            logger.info("Processing roles as String: '{}'", rolesString);

                            if (StringUtils.hasText(rolesString)) {
                                authorities = Arrays.stream(rolesString.split(","))
                                        .map(String::trim)
                                        .filter(s -> !s.isEmpty())
                                        .map(SimpleGrantedAuthority::new)
                                        .collect(Collectors.toList());

                                logger.info("✓ Authorities created from String: {}", authorities);
                            }
                        }
                    } else {
                        logger.warn("⚠ Roles claim is null");
                    }

                    // If no authorities found, add default
                    if (authorities.isEmpty()) {
                        logger.info("No authorities found, adding default ROLE_USER");
                        authorities.add(new SimpleGrantedAuthority("ROLE_USER"));
                    }

                    logger.info("Final authorities list: {}", authorities);

                    // Load user details
                    logger.info("Loading user details for username: '{}'", username);
                    UserDetails userDetails = userDetailsService.loadUserByUsername(username);
                    logger.info("✓ UserDetails loaded successfully: {} (Enabled: {}, AccountNonExpired: {}, AccountNonLocked: {}, CredentialsNonExpired: {})",
                            userDetails.getUsername(),
                            userDetails.isEnabled(),
                            userDetails.isAccountNonExpired(),
                            userDetails.isAccountNonLocked(),
                            userDetails.isCredentialsNonExpired());

                    // Create authentication
                    UsernamePasswordAuthenticationToken authentication =
                            new UsernamePasswordAuthenticationToken(userDetails, null, authorities);

                    authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                    SecurityContextHolder.getContext().setAuthentication(authentication);

                    logger.info("✓ Authentication set in SecurityContext successfully");
                    logger.info("✓ Authentication details: Principal={}, Authenticated={}, Authorities={}",
                            authentication.getPrincipal() instanceof UserDetails ?
                                    ((UserDetails) authentication.getPrincipal()).getUsername() : authentication.getPrincipal(),
                            authentication.isAuthenticated(),
                            authentication.getAuthorities());

                } else {
                    logger.error("✗ JWT Token validation FAILED");
                }
            } else {
                logger.info("No JWT token found in request");
            }

            // Check final authentication state
            org.springframework.security.core.Authentication finalAuth = SecurityContextHolder.getContext().getAuthentication();
            logger.info("Final SecurityContext Authentication: {}",
                    finalAuth != null ? "Present (Authenticated: " + finalAuth.isAuthenticated() + ")" : "NULL");

        } catch (Exception ex) {
            logger.error("✗ ERROR in JWT Filter for request {} {}", request.getMethod(), requestUri, ex);
            ex.printStackTrace();

            // Clear context on error
            SecurityContextHolder.clearContext();
            logger.info("SecurityContext cleared due to error");
        }

        logger.info("=== JWT Filter completed for {} {} ===", request.getMethod(), requestUri);
        filterChain.doFilter(request, response);
    }
    private String getJwtFromRequest(HttpServletRequest request) {
        String jwt = cookieUtils.getJwtFromCookie(request);

        if (jwt == null) {
            String bearerToken = request.getHeader("Authorization");
            if (StringUtils.hasText(bearerToken) && bearerToken.startsWith("Bearer ")) {
                return bearerToken.substring(7);
            }
        }
        return jwt;
    }
}