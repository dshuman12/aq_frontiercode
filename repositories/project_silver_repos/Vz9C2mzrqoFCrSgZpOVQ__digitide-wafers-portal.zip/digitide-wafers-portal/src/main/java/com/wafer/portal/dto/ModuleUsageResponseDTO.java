package com.wafer.portal.dto;

public class ModuleUsageResponseDTO {

    private Long moduleId;
    private String moduleName;
    private Integer moduleLevel;
    private Long totalClicks;

    public ModuleUsageResponseDTO(Long moduleId, String moduleName, Integer moduleLevel, Long totalClicks) {
        this.moduleId = moduleId;
        this.moduleName = moduleName;
        this.moduleLevel = moduleLevel;
        this.totalClicks = totalClicks;
    }

    public Long getModuleId() {
        return moduleId;
    }

    public void setModuleId(Long moduleId) {
        this.moduleId = moduleId;
    }

    public String getModuleName() {
        return moduleName;
    }

    public void setModuleName(String moduleName) {
        this.moduleName = moduleName;
    }

    public Integer getModuleLevel() {
        return moduleLevel;
    }

    public void setModuleLevel(Integer moduleLevel) {
        this.moduleLevel = moduleLevel;
    }

    public Long getTotalClicks() {
        return totalClicks;
    }

    public void setTotalClicks(Long totalClicks) {
        this.totalClicks = totalClicks;
    }
}
