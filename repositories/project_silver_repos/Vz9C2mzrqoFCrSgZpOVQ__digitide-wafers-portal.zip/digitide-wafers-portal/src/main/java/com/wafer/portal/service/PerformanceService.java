package com.wafer.portal.service;

import com.wafer.portal.dto.PageVisitDTO;
import com.wafer.portal.dto.PerformanceRequest;
import com.wafer.portal.dto.PerformanceSummaryDTO;
import com.wafer.portal.model.PerformanceLog;
import com.wafer.portal.model.PerformanceLogsMonthly;
import com.wafer.portal.repository.PerformanceLogRepository;
import com.wafer.portal.repository.PerformanceLogsMonthlyRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;


@Service
public class PerformanceService {

    private final PerformanceLogRepository performanceRepository;
    private final PerformanceLogsMonthlyRepository monthlyRepository;

    public PerformanceService(PerformanceLogRepository performanceRepository, PerformanceLogsMonthlyRepository monthlyRepository) {
        this.performanceRepository = performanceRepository;
        this.monthlyRepository = monthlyRepository;
    }

    public ResponseEntity<String> updatePageLoad(PerformanceRequest request){

        List<PerformanceLog> logs =
                performanceRepository.findAllByTrackingId(request.getTrackingId());

        if(logs == null || logs.isEmpty()){
            return ResponseEntity.notFound().build();
        }

        for(PerformanceLog log : logs){
            log.setPageName(request.getPageName());
            log.setPageLoadTimeMs(request.getPageLoadTimeMs());
            log.setBrowser(request.getBrowser());
            log.setDeviceType(request.getDeviceType());
            log.setOs(request.getOs());
        }

        performanceRepository.saveAll(logs);

        return ResponseEntity.ok("Performance Updated");
    }


//    public ResponseEntity<String> updatePageLoad(PerformanceRequest request){
//
//        List<PerformanceLog> logs =
//                performanceRepository.findAllByTrackingId(request.getTrackingId());
//
//        if(logs == null || logs.isEmpty()){
//            return ResponseEntity.notFound().build();
//        }
//
//        for(PerformanceLog log : logs){
//
//            log.setPageName(request.getPageName());
//            log.setPageLoadTimeMs(request.getPageLoadTimeMs());
//            log.setBrowser(request.getBrowser());
//            log.setDeviceType(request.getDeviceType());
//            log.setOs(request.getOs());
//        }
//
//        performanceRepository.saveAll(logs);
//
//        return ResponseEntity.ok("Performance Updated");
//    }

    public List<PerformanceLog> getLogsByTrackingId(String trackingId){
        return performanceRepository.findAllByTrackingId(trackingId);
    }

    public List<PerformanceLog> getLogsByApi(String apiName){
        return performanceRepository.findByApiName(apiName);
    }

    public List<PerformanceLogsMonthly> getMonthlyData(int year, int month){
        return monthlyRepository.findByYearAndMonth(year, month);
    }

    public Page<PerformanceLog> getAllLogs(Pageable pageable){
        return performanceRepository.findAll(pageable);
    }

    public Page<PageVisitDTO> getLogsByDeviceType(String deviceType, LocalDate startDate, LocalDate endDate, Pageable pageable) {
        LocalDateTime startDateTime = startDate.atStartOfDay();
        LocalDateTime endDateTime = endDate.atTime(23, 59, 59);
        return performanceRepository.findByDeviceType(deviceType, startDateTime, endDateTime, pageable)
                .map(this::mapToPageVisitDTO);
    }


    public Page<PageVisitDTO> getLogsByBrowser(String browser, LocalDate startDate, LocalDate endDate, Pageable pageable) {
        LocalDateTime startDateTime = startDate.atStartOfDay();
        LocalDateTime endDateTime = endDate.atTime(23, 59, 59);
        return performanceRepository.findByBrowserType(browser, startDateTime, endDateTime, pageable)
                .map(this::mapToPageVisitDTO);
    }


    private PageVisitDTO mapToPageVisitDTO(Object[] obj) {
        return new PageVisitDTO(
                (String) obj[0],
                (String) obj[1],
                obj[2] != null ? ((Number) obj[2]).intValue() : null,
                (String) obj[3],
                (String) obj[4],
                (String) obj[5],
                obj[6] != null ? ((Timestamp) obj[6]).toLocalDateTime() : null,
                ((Number) obj[7]).longValue(),
                (String) obj[8]
        );
    }

}