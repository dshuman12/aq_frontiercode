package com.wafer.portal.dto.response;

public class VideoSectionDTO {
    private Object video;

    public Object getVideo() {
        return video;
    }

    public void setVideo(Object video) {
        this.video = video;
    }
}
