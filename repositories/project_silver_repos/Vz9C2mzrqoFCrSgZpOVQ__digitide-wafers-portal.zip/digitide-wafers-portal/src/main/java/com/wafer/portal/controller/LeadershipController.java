package com.wafer.portal.controller;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wafer.portal.annotation.TrackChange;
import com.wafer.portal.dto.LeadershipRequest;
import com.wafer.portal.dto.LeadershipResponseDTO;
import com.wafer.portal.model.Leadership;
import com.wafer.portal.service.LeadershipService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@Controller
@RestController
@RequestMapping("/api/v2/leadership")
public class LeadershipController {

    private final LeadershipService leadershipService;

    @Autowired
    public LeadershipController(LeadershipService leadershipService) {
        this.leadershipService = leadershipService;
    }

    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Added", section = "Leadership")
    public ResponseEntity<LeadershipResponseDTO> createLeadership(
            @RequestParam("image") MultipartFile image,
            @RequestParam("request") String requestJson) throws JsonProcessingException {
        LeadershipRequest request = new ObjectMapper().readValue(requestJson, LeadershipRequest.class);
        return leadershipService.createLeadership(image, request);
    }


    @GetMapping("/all")
    public ResponseEntity<Page<LeadershipResponseDTO>> getAllLeadership(Pageable pageable) {
        return leadershipService.getAllLeadership(pageable);
    }

    @GetMapping("/{id}")
    public ResponseEntity<LeadershipResponseDTO> getLeadershipById(@PathVariable Long id) {
        return leadershipService.getLeadershipById(id);
    }


    @PutMapping(value = "/{id}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Edited", section = "Leadership")
    public ResponseEntity<LeadershipResponseDTO> updateLeadership(
            @PathVariable Long id,
            @RequestParam(value = "image", required = false) MultipartFile image,
            @RequestParam("request") String requestJson) throws JsonProcessingException {

        LeadershipRequest request = new ObjectMapper().readValue(requestJson, LeadershipRequest.class);
        return leadershipService.updateLeadership(id, image, request);
    }


    @DeleteMapping("/{id}")
    @TrackChange(action = "Deleted", section = "Leadership")
    public ResponseEntity<Leadership> deleteLeadership(@PathVariable Long id) {
        Leadership result = leadershipService.deleteLeadership(id);
        return (result != null)
                ? new ResponseEntity<>(result, HttpStatus.OK)
                : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }


}
