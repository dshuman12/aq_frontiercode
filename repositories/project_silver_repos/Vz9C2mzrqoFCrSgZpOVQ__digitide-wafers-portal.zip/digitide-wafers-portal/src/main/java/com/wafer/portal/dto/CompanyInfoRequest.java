package com.wafer.portal.dto;

public class CompanyInfoRequest {
    private String title;
    private String description;

    public CompanyInfoRequest() {
    }

    public CompanyInfoRequest(String title, String description) {
        this.title = title;
        this.description = description;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
