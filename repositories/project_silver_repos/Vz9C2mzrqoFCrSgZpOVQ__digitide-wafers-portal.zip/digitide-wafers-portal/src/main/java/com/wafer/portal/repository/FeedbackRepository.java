package com.wafer.portal.repository;

import com.wafer.portal.model.FeedBack;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.Optional;

public interface FeedbackRepository extends JpaRepository<FeedBack, Long> {
    @EntityGraph(attributePaths = "adminRemarks")
    Page<FeedBack> findByIsDeletedFalseOrderByCreationDateDesc(Pageable pageable);

    @EntityGraph(attributePaths = "adminRemarks")
    Optional<FeedBack> findByIdAndIsDeletedFalse(Long aLong);

    @EntityGraph(attributePaths = "adminRemarks")
    Page<FeedBack> findByIsDeletedFalseAndCreationDateBetweenOrderByCreationDateDesc(
            LocalDateTime startDate,
            LocalDateTime endDate,
            Pageable pageable
    );


}
