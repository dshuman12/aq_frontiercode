package com.wafer.portal.model;

import com.wafer.portal.audit.Auditable;
import jakarta.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "rewards_subsection")
public class RewardsSubsection extends Auditable<String> implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String subsectionName;
    private boolean isDeleted = false;

    public RewardsSubsection() {
    }

    public RewardsSubsection(Long id, String subsectionName, boolean isDeleted) {
        this.id = id;
        this.subsectionName = subsectionName;
        this.isDeleted = isDeleted;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }


    public String getSubsectionName() {
        return subsectionName;
    }

    public void setSubsectionName(String subsectionName) {
        this.subsectionName = subsectionName;
    }

    public boolean isDeleted() {
        return isDeleted;
    }

    public void setDeleted(boolean deleted) {
        isDeleted = deleted;
    }
}
