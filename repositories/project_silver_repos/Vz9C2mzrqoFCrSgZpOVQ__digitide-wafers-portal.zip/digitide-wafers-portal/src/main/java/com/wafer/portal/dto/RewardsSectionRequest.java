package com.wafer.portal.dto;

public class RewardsSectionRequest {
    private String sectionName;

    public RewardsSectionRequest() {}
    public RewardsSectionRequest(String sectionName) {
        this.sectionName = sectionName;
    }

    public String getSectionName() { return sectionName; }
    public void setSectionName(String sectionName) { this.sectionName = sectionName; }
}