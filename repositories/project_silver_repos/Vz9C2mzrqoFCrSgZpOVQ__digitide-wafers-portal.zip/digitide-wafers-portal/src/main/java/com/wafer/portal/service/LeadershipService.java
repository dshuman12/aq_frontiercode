package com.wafer.portal.service;

import com.wafer.portal.awsS3.S3Service;
import com.wafer.portal.dto.LeadershipRequest;
import com.wafer.portal.dto.LeadershipResponseDTO;
import com.wafer.portal.model.Leadership;
import com.wafer.portal.repository.LeadershipRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@Service
public class LeadershipService {

    private static final String LEADERSHIP_FOLDER = "Leadership-Images";

    private final LeadershipRepository leadershipRepository;

    private final S3Service s3Service;

    @Autowired
    public LeadershipService(LeadershipRepository leadershipRepository, S3Service s3Service) {
        this.leadershipRepository = leadershipRepository;
        this.s3Service = s3Service;
    }

    public ResponseEntity<LeadershipResponseDTO> createLeadership(MultipartFile image, LeadershipRequest request) {
        try {
            if (image.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
            }
            String imageKey = s3Service.uploadFile(image, LEADERSHIP_FOLDER);
            Leadership leadership = new Leadership(request.getName(),request.getDesignation(),imageKey,request.getSequence(), request.getDescription());
            Leadership saved = leadershipRepository.save(leadership);

            return new ResponseEntity<>(mapToResponseDto(saved), HttpStatus.CREATED);
        } catch (IOException e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Page<LeadershipResponseDTO>> getAllLeadership(Pageable pageable) {
        Page<Leadership> newsPage = leadershipRepository.findAllOrderedBySequence(pageable);
        Page<LeadershipResponseDTO> dtoPage = newsPage.map(this::mapToResponseDto);
        return dtoPage.isEmpty() ? new ResponseEntity<>(HttpStatus.NO_CONTENT) : new ResponseEntity<>(dtoPage, HttpStatus.OK);
    }

    public ResponseEntity<LeadershipResponseDTO> getLeadershipById(Long id) {
        return leadershipRepository.findByIdAndIsDeletedFalse(id)
                .map(leadership -> new ResponseEntity<>(mapToResponseDto(leadership), HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    public ResponseEntity<LeadershipResponseDTO> updateLeadership(Long id,MultipartFile image, LeadershipRequest request) {
        return leadershipRepository.findByIdAndIsDeletedFalse(id)
                .map(existingLeadership -> {
                    try {
                        if (image != null && !image.isEmpty()) {
                            String newImageKey = s3Service.updateFile(existingLeadership.getImage(), image, LEADERSHIP_FOLDER);
                            existingLeadership.setImage(newImageKey);
                        }

                        existingLeadership.setName(request.getName());
                        existingLeadership.setDesignation(request.getDesignation());
                        existingLeadership.setSequence(request.getSequence());
                        existingLeadership.setDescription(request.getDescription());
                        Leadership updated = leadershipRepository.save(existingLeadership);
                        return new ResponseEntity<>(mapToResponseDto(updated), HttpStatus.OK);
                    } catch (IOException e) {
                        return new ResponseEntity<LeadershipResponseDTO>(HttpStatus.INTERNAL_SERVER_ERROR);
                    }
                })
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    public Leadership deleteLeadership(Long id) {
        return leadershipRepository.findByIdAndIsDeletedFalse(id)
                .map(ls -> {
                    ls.setDeleted(true);
                    return leadershipRepository.save(ls);
                }).orElse(null);
    }

    private LeadershipResponseDTO mapToResponseDto(Leadership saved) {
        String preSignedUrl = s3Service.generatePresignedUrl(saved.getImage());
        return new LeadershipResponseDTO(
                saved.getId(),
                saved.getName(),
                saved.getDesignation(),
                preSignedUrl,
                saved.getDescription(),
                saved.getSequence(),
                saved.getCreatedBy(),
                saved.getCreationDate(),
                saved.getLastModifiedBy(),
                saved.getLastModifiedDate()
        );
    }
}
