package com.wafer.portal.service;

import com.wafer.portal.awsS3.S3Service;
import com.wafer.portal.model.PicOfTheDay;
import com.wafer.portal.model.Video;
import com.wafer.portal.repository.VideoRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Optional;


@Service
public class VideoService {

    private final VideoRepository videoRepository;
    private final S3Service s3Service;

    private static final Logger logger = LoggerFactory.getLogger(VideoService.class);

    public VideoService(VideoRepository videoRepository, S3Service s3Service) {
        this.videoRepository = videoRepository;
        this.s3Service = s3Service;
    }

    public Video uploadVideo(MultipartFile file, MultipartFile image) {
       try {
           Optional<Video> existing = videoRepository.findTopByIsDeletedFalseOrderByCreationDateDesc();

           String newVideoKey;
           String newImageKey=null;
           if (existing.isPresent()) {
               Video oldVideo = existing.get();
               newVideoKey = s3Service.updateFile(oldVideo.getVideo(), file, "videos");

               if (image != null && !image.isEmpty()) {
                   newImageKey = s3Service.updateFile(oldVideo.getThumbnail(), image, "thumbnails");
               }


               oldVideo.setVideo(newVideoKey);
               oldVideo.setThumbnail(newImageKey);
               return videoRepository.save(oldVideo);

           } else {
               Video video = new Video();
               String videoUrl = s3Service.uploadFile(file, "videos");

               String imageUrl = null;

               if (image != null && !image.isEmpty()) {
                   imageUrl = s3Service.uploadFile(image,"thumbnails");
               }
               video.setVideo(videoUrl);
               video.setThumbnail(imageUrl);
               return videoRepository.save(video);
           }
       } catch (IOException e) {
           logger.error("Error uploading vide: {}", e.getMessage(), e);
           throw new RuntimeException("Failed to upload video");
       }
    }

    public Page<Video> getAllVideos(Pageable pageable) {
        return videoRepository.findByIsDeletedFalse(pageable);
    }

    public Optional<Video> getVideoById(Long id) {
        return videoRepository.findByIdAndIsDeletedFalse(id);
    }

    public Video updateVideo(Long id, MultipartFile newVideo, MultipartFile newThumbnail) {
       try {
           Video existingVideo = videoRepository.findByIdAndIsDeletedFalse(id)
                   .orElseThrow(() -> new RuntimeException("Video not found"));

           if (newVideo != null && !newVideo.isEmpty()) {
               String newVideoUrl = s3Service.updateFile(existingVideo.getVideo(), newVideo, "videos");
               existingVideo.setVideo(newVideoUrl);
           }

           if (newThumbnail != null && !newThumbnail.isEmpty()) {
               String newThumbnailUrl = s3Service.updateFile(existingVideo.getThumbnail(), newThumbnail, "thumbnails");
               existingVideo.setThumbnail(newThumbnailUrl);
           }
           else{
               existingVideo.setThumbnail(null);
           }
           return videoRepository.save(existingVideo);
       }catch (IOException e) {
           logger.error("Error updating vide: {}", e.getMessage(), e);
           throw new RuntimeException("Failed to update video", e);
       } catch (RuntimeException e) {
           logger.error("Error finding vide: {}", e.getMessage(), e);
           throw e;
       }
    }

    public Video softDeleteVideo(Long id) {
        try {
            Video video = videoRepository.findByIdAndIsDeletedFalse(id)
                    .orElseThrow(() -> new RuntimeException("video not found"));
            video.setDeleted(true);
            return videoRepository.save(video);
        } catch (RuntimeException e) {
            logger.error("Error deleting video: {}", e.getMessage(), e);
            throw e;
        }
    }


}
