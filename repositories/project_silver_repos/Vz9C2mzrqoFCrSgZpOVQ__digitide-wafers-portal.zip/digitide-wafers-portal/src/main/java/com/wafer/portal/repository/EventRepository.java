package com.wafer.portal.repository;

import com.wafer.portal.model.Event;
import com.wafer.portal.model.People;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface EventRepository extends JpaRepository<Event, Long> {
    Page<Event> findByIsDeletedFalse(Pageable pageable);
    Optional<Event> findByIdAndIsDeletedFalse(Long aLong);

    // For-Admin
    Page<Event> findByIsDeletedFalseOrderByCreationDateAsc(Pageable pageable);

    // For-Employee
    Page<Event> findByIsDeletedFalseOrderByEventDateAsc(Pageable pageable);


    @Query("SELECT e FROM Event e WHERE e.isDeleted = false AND " +
            "(LOWER(e.eventName) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(e.url) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    Page<Event> searchEvents(@Param("keyword") String keyword, Pageable pageable);

    @Query("SELECT s FROM Event s WHERE s.isDeleted = false ORDER BY " +
            "CASE WHEN s.sequence IS NULL THEN 1 ELSE 0 END, s.sequence ASC")
    Page<Event> findAllOrderedBySequence(Pageable pageable);

}
