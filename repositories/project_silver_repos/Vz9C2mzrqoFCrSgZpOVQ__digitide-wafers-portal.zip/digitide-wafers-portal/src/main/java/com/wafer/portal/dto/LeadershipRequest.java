package com.wafer.portal.dto;

public class LeadershipRequest {

    private String name;
    private String designation;
    private String image;
    private String description;
    private Double sequence;

    public LeadershipRequest(){}

    public LeadershipRequest(String name, String designation, String image, String description, Double sequence) {
        this.name = name;
        this.designation = designation;
        this.image = image;
        this.description = description;
        this.sequence = sequence;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Double getSequence() {
        return sequence;
    }

    public void setSequence(Double sequence) {
        this.sequence = sequence;
    }
}
