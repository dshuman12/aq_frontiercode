package com.wafer.portal.dto;

import java.time.LocalDate;
import java.util.List;

public class DashboardFilterDTO {

    private LocalDate startDate;
    private LocalDate endDate;
    private Long levelId;
    private List<Long> moduleId;
    private String type; // LEAST or MOST

    public DashboardFilterDTO(LocalDate startDate,
                           LocalDate endDate,
                           Long levelId,
                           List<Long> moduleId, String type) {
        this.startDate = startDate;
        this.endDate = endDate;
        this.levelId = levelId;
        this.moduleId = moduleId;
        this.type = type;
    }

    public DashboardFilterDTO(LocalDate startDate, LocalDate endDate) {
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public LocalDate getStartDate() { return startDate; }
    public LocalDate getEndDate() { return endDate; }
    public Long getLevelId() { return levelId; }
    public List<Long> getModuleId() { return moduleId; }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public void setLevelId(Long levelId) {
        this.levelId = levelId;
    }

    public void setModuleId(List<Long> moduleId) {
        this.moduleId = moduleId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
