package com.wafer.portal.dto;

public class SlowApiDTO {

    private String apiName;
    private Long count;
    private String device;
    private String browser;

    public SlowApiDTO(String apiName, Long count, String device, String browser) {
        this.apiName = apiName;
        this.count = count;
        this.device = device;
        this.browser = browser;
    }

    public String getApiName() {
        return apiName;
    }

    public Long getCount() {
        return count;
    }

    public String getDevice() {
        return device;
    }

    public String getBrowser() {
        return browser;
    }
}