package com.wafer.portal.repository;


import com.wafer.portal.model.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmployeeId(String employeeId);
    Optional<User> findByEmail(String email);
    Boolean existsByEmployeeId(String employeeId);
    Boolean existsByEmail(String email);

    Optional<User> findByEmailAndIsDeletedFalse(String email);
    Page<User> findAllByIsDeletedFalse(Pageable pageable);

    Optional<User> findByIdAndIsDeletedFalse(Long id);

    Page<User> findByUserNameContainingIgnoreCaseAndIsDeletedFalse(String userName, Pageable pageable);

    Optional<User> findByUserNameAndIsDeletedFalse(String userName);


}
