package com.wafer.portal.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.wafer.portal.audit.Auditable;
import jakarta.persistence.*;

import java.io.Serializable;
import java.time.LocalDateTime;

@Entity
@Table(name = "change_tracker")
public class ChangeTracker extends Auditable<String> implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String userEmail;
    private String actionType;
    private String resourceType;
    private String sectionName;
    private String fileName;

    private String s3Key;

    @Transient
    private String fileUrl;

    @Column(name = "is_deleted", nullable = false)
    private boolean isDeleted = false;

    @JsonFormat(pattern = "dd-MMM-yyyy HH:mm")
    private LocalDateTime timestamp;

    public ChangeTracker() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getUserEmail() { return userEmail; }
    public void setUserEmail(String userEmail) { this.userEmail = userEmail; }

    public String getActionType() { return actionType; }
    public void setActionType(String actionType) { this.actionType = actionType; }

    public String getResourceType() { return resourceType; }
    public void setResourceType(String resourceType) { this.resourceType = resourceType; }

    public String getSectionName() { return sectionName; }
    public void setSectionName(String sectionName) { this.sectionName = sectionName; }

    public String getFileName() { return fileName; }
    public void setFileName(String fileName) { this.fileName = fileName; }

    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }

    public String getS3Key() { return s3Key; }

    public void setS3Key(String s3Key) { this.s3Key = s3Key; }

    public String getFileUrl() { return fileUrl; }

    public void setFileUrl(String fileUrl) { this.fileUrl = fileUrl; }

    public boolean isDeleted() { return isDeleted; }

    public void setDeleted(boolean deleted) { isDeleted = deleted; }
}