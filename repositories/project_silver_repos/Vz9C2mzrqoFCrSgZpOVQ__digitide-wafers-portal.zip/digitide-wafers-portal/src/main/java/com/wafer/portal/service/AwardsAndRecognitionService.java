package com.wafer.portal.service;

import com.wafer.portal.awsS3.S3Service;
import com.wafer.portal.dto.AwardsAndRecognitionRequest;
import com.wafer.portal.dto.AwardsAndRecognitionResponseDto;
import com.wafer.portal.model.AwardsAndRecognition;
import com.wafer.portal.repository.AwardsAndRecognitionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@Service
public class AwardsAndRecognitionService {

    private static final String FOLDER_NAME = "Awards-And-Recognition-Images";


    private final AwardsAndRecognitionRepository awardsAndRecognitionRepository;
    private final S3Service s3Service;

    @Autowired
    public AwardsAndRecognitionService(AwardsAndRecognitionRepository awardsAndRecognitionRepository, S3Service s3Service) {
        this.awardsAndRecognitionRepository = awardsAndRecognitionRepository;
        this.s3Service = s3Service;
    }

    public ResponseEntity<AwardsAndRecognitionResponseDto> createAward(MultipartFile image, AwardsAndRecognitionRequest request) {
        try {
            if (image.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
            }
            String imageKey = s3Service.uploadFile(image, FOLDER_NAME);
            AwardsAndRecognition award = new AwardsAndRecognition(imageKey, request.getTitle(), request.getYear(), request.getSequence());
            AwardsAndRecognition saved = awardsAndRecognitionRepository.save(award);

            return new ResponseEntity<>(mapToResponseDto(saved), HttpStatus.CREATED);
        } catch (IOException e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Page<AwardsAndRecognitionResponseDto>> getAllAwards(Pageable pageable) {
        Page<AwardsAndRecognition> awardPage = awardsAndRecognitionRepository.findAllOrderedBySequence(pageable);
        Page<AwardsAndRecognitionResponseDto> dtoPage = awardPage.map(this::mapToResponseDto);
        return dtoPage.isEmpty() ? new ResponseEntity<>(HttpStatus.NO_CONTENT) : new ResponseEntity<>(dtoPage, HttpStatus.OK);
    }

    public ResponseEntity<AwardsAndRecognitionResponseDto> getAwardById(Long id) {
        return awardsAndRecognitionRepository.findByIdAndIsDeletedFalse(id)
                .map(award -> new ResponseEntity<>(mapToResponseDto(award), HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    public ResponseEntity<AwardsAndRecognitionResponseDto> updateAward(Long id,MultipartFile image, AwardsAndRecognitionRequest request) {
        return awardsAndRecognitionRepository.findByIdAndIsDeletedFalse(id)
                .map(existingAward -> {
                    try {
                        if (image != null && !image.isEmpty()) {
                            String newImageKey = s3Service.updateFile(existingAward.getImage(), image, FOLDER_NAME);
                            existingAward.setImage(newImageKey);
                        }

                        existingAward.setTitle(request.getTitle());
                        existingAward.setYear(request.getYear());
                        existingAward.setSequence(request.getSequence());
                        AwardsAndRecognition updated = awardsAndRecognitionRepository.save(existingAward);
                        return new ResponseEntity<>(mapToResponseDto(updated), HttpStatus.OK);
                    } catch (IOException e) {
                        return new ResponseEntity<AwardsAndRecognitionResponseDto>(HttpStatus.INTERNAL_SERVER_ERROR);
                    }
                })
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    public AwardsAndRecognition deleteAward(Long id) {
        return awardsAndRecognitionRepository.findByIdAndIsDeletedFalse(id)
                .map(award -> {
                    award.setIsDeleted(true);
                    return awardsAndRecognitionRepository.save(award);
                }).orElse(null);
    }

    private AwardsAndRecognitionResponseDto mapToResponseDto(AwardsAndRecognition award) {
        String preSignedUrl = s3Service.generatePresignedUrl(award.getImage());
        return new AwardsAndRecognitionResponseDto(
                award.getId(),
                award.getTitle(),
                preSignedUrl,
                award.getYear(),
                award.getSequence(),
                award.getCreatedBy(),
                award.getCreationDate(),
                award.getLastModifiedBy(),
                award.getLastModifiedDate()
        );
    }
}