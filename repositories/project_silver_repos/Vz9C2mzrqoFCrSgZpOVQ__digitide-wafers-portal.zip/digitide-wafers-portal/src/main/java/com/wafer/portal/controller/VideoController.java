package com.wafer.portal.controller;

import com.wafer.portal.annotation.TrackChange;
import com.wafer.portal.awsS3.S3Service;
import com.wafer.portal.dto.VideoResponseDto;
import com.wafer.portal.model.Video;
import com.wafer.portal.service.VideoService;
import org.springframework.boot.autoconfigure.graphql.GraphQlProperties;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;


@Controller
@RestController
@RequestMapping("/api/v1/video")
public class VideoController {

    private final VideoService videoService;
    private final S3Service s3Service;

    public VideoController(VideoService videoService, S3Service s3Service) {
        this.videoService = videoService;
        this.s3Service = s3Service;
    }

    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Added", section = "Video")
    public ResponseEntity<VideoResponseDto> uploadVideo(@RequestPart("video") MultipartFile video, @RequestPart(name="thumbnail",required = false) MultipartFile image) {
        try {
            Video uploadVideo = videoService.uploadVideo(video,image);
            String preSignedUrl = s3Service.generatePresignedUrl(uploadVideo.getVideo());

            String preSignedUrlImage = null;

            if (uploadVideo.getThumbnail() != null && !uploadVideo.getThumbnail().isEmpty()) {
                preSignedUrlImage = s3Service.generatePresignedUrl(uploadVideo.getThumbnail());
            }

            VideoResponseDto responseDto = new VideoResponseDto(uploadVideo.getId(),preSignedUrl,preSignedUrlImage, uploadVideo.getCreatedBy(), uploadVideo.getCreationDate(), uploadVideo.getLastModifiedBy(), uploadVideo.getLastModifiedDate());
            return new ResponseEntity<>(responseDto, HttpStatus.CREATED);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }


    @GetMapping("/all")
    public ResponseEntity<Page<VideoResponseDto>> getAllVideos(Pageable pageable) {
        Page<Video> videos = videoService.getAllVideos(pageable);

        Page<VideoResponseDto> dtoPage = videos.map(video -> {
            String preSignedUrl = s3Service.generatePresignedUrl(video.getVideo());
            String preSignedUrlImage = null;

            if (video.getThumbnail() != null && !video.getThumbnail().isEmpty()) {
                preSignedUrlImage = s3Service.generatePresignedUrl(video.getThumbnail());
            }
            return  new VideoResponseDto(video.getId(),preSignedUrl, preSignedUrlImage, video.getCreatedBy(), video.getCreationDate(), video.getLastModifiedBy(), video.getLastModifiedDate());
        });
        return dtoPage.isEmpty() ? new ResponseEntity<>(HttpStatus.NOT_FOUND) : new ResponseEntity<>(dtoPage, HttpStatus.OK);
    }


    @GetMapping("/{id}")
    public ResponseEntity<VideoResponseDto> getVideoById(@PathVariable Long id) {
        return videoService.getVideoById(id)
                .map(video ->{
                    String preSignedUrl = s3Service.generatePresignedUrl(video.getVideo());
                    String preSignedUrlImage = null;

                    if (video.getThumbnail() != null && !video.getThumbnail().isEmpty()) {
                        preSignedUrlImage = s3Service.generatePresignedUrl(video.getThumbnail());
                    }
                    VideoResponseDto dto = new VideoResponseDto(video.getId(),preSignedUrl,preSignedUrlImage, video.getCreatedBy(), video.getCreationDate(), video.getLastModifiedBy(), video.getLastModifiedDate());
                    return new ResponseEntity<>(dto, HttpStatus.OK);
                }).orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }


    @PutMapping(value = "/{id}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Edited", section = "Video")
    public ResponseEntity<VideoResponseDto> updateVideo(@PathVariable Long id,
                                         @RequestPart(value ="video", required = false) MultipartFile video,
                                                        @RequestPart(value = "thumbnail", required = false) MultipartFile image) {
        try {
            Video updatedVideo = videoService.updateVideo(id, video, image);
            String preSignedUrl = s3Service.generatePresignedUrl(updatedVideo.getVideo());
            String preSignedUrlImage = null;

            if (updatedVideo.getThumbnail() != null && !updatedVideo.getThumbnail().isEmpty()) {
                preSignedUrlImage = s3Service.generatePresignedUrl(updatedVideo.getThumbnail());
            }
            VideoResponseDto responseDto = new VideoResponseDto(updatedVideo.getId(),preSignedUrl, preSignedUrlImage, updatedVideo.getCreatedBy(), updatedVideo.getCreationDate(), updatedVideo.getLastModifiedBy(), updatedVideo.getLastModifiedDate());
            return new ResponseEntity<>(responseDto, HttpStatus.CREATED);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/{id}")
    @TrackChange(action = "Deleted", section = "Video")
    public ResponseEntity<?> deleteVideo(@PathVariable Long id) {
        try {
            Video result = videoService.softDeleteVideo(id);
            return new ResponseEntity<>(result, HttpStatus.OK);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }


}
