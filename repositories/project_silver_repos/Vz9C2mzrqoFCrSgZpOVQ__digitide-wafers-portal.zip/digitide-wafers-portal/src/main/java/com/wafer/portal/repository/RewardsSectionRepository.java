package com.wafer.portal.repository;

import com.wafer.portal.model.RewardsSection;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface RewardsSectionRepository extends JpaRepository<RewardsSection, Long> {

    // Find all sections that are not soft-deleted
    List<RewardsSection> findByIsDeletedFalse();
    Page<RewardsSection> findByIsDeletedFalse(Pageable pageable);

    Optional<RewardsSection> findBySectionNameIgnoreCaseAndIsDeletedFalse(String sectionName);

}
