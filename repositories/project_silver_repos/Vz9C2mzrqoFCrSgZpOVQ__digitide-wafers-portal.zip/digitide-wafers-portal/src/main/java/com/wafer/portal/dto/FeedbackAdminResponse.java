package com.wafer.portal.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public class FeedbackAdminResponse {
    private Long id;
    private String description;
    private String imageUrl;
    private LocalDate feedbackDate;
    private boolean actionTaken;
    private String uploadedDocument;
    private List<AdminRemarkResponse> adminRemarks;
    private boolean mailSent;
    private boolean ticketClosed;
    private String userName;
    private LocalDateTime creationDate;
    private String lastModifiedBy;
    private LocalDateTime lastModifiedDate;

    public FeedbackAdminResponse() {
    }

    public FeedbackAdminResponse(Long id, String feedbackDescription, String attachment, LocalDate feedbackDate, boolean actionTaken, String uploadedDocument, List<AdminRemarkResponse> adminRemarks
            , boolean mailSent, boolean ticketClosed, String createdBy, LocalDateTime creationDate, String lastModifiedBy, LocalDateTime lastModifiedDate) {
        this.id = id;
        this.description = feedbackDescription;
        this.imageUrl = attachment;
        this.feedbackDate = feedbackDate;
        this.actionTaken = actionTaken;
        this.uploadedDocument = uploadedDocument;
        this.adminRemarks = adminRemarks;
        this.mailSent = mailSent;
        this.ticketClosed = ticketClosed;
        this.userName = createdBy;
        this.creationDate = creationDate;
        this.lastModifiedBy = lastModifiedBy;
        this.lastModifiedDate = lastModifiedDate;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public LocalDate getFeedbackDate() {
        return feedbackDate;
    }

    public void setFeedbackDate(LocalDate feedbackDate) {
        this.feedbackDate = feedbackDate;
    }

    public boolean isActionTaken() {
        return actionTaken;
    }

    public void setActionTaken(boolean actionTaken) {
        this.actionTaken = actionTaken;
    }

    public String getUploadedDocument() {
        return uploadedDocument;
    }

    public void setUploadedDocument(String uploadedDocument) {
        this.uploadedDocument = uploadedDocument;
    }

    public List<AdminRemarkResponse> getAdminRemarks() {
        return adminRemarks;
    }

    public void setAdminRemarks(List<AdminRemarkResponse> adminRemarks) {
        this.adminRemarks = adminRemarks;
    }

    public boolean isMailSent() {
        return mailSent;
    }

    public void setMailSent(boolean mailSent) {
        this.mailSent = mailSent;
    }

    public boolean isTicketClosed() {
        return ticketClosed;
    }

    public void setTicketClosed(boolean ticketClosed) {
        this.ticketClosed = ticketClosed;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public LocalDateTime getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(LocalDateTime creationDate) {
        this.creationDate = creationDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public LocalDateTime getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(LocalDateTime lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }
}
