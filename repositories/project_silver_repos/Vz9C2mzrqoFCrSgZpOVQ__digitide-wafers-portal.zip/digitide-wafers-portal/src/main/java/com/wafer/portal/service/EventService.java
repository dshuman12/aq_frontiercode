package com.wafer.portal.service;

import com.wafer.portal.model.Event;
import com.wafer.portal.repository.EventRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class EventService {

    @Autowired
    private EventRepository eventRepository;

    public Event saveEvent(Event event) {
        return eventRepository.save(event);
    }

    public Page<Event> getAllEvents(Pageable pageable) {
        return eventRepository.findAllOrderedBySequence(pageable);
    }

    public Optional<Event> getEventById(Long id) {
        return eventRepository.findByIdAndIsDeletedFalse(id);
    }

    public Event softDeleteEvent(Long id) {
        return eventRepository.findByIdAndIsDeletedFalse(id)
                .map(event -> {
                    event.setIsDeleted(true);
                    return eventRepository.save(event);
                }).orElse(null);
    }


    public Page<Event> getAllEventsOrderByCreatedDateAsc(Pageable pageable) {
        return eventRepository.findByIsDeletedFalseOrderByCreationDateAsc(pageable);
    }

    public Page<Event> getAllEventsOrderByEventDateAsc(Pageable pageable) {
        return eventRepository.findByIsDeletedFalseOrderByEventDateAsc(pageable);
    }

}

