package com.wafer.portal.service;


import com.wafer.portal.awsS3.S3Service;
import com.wafer.portal.dto.*;
import com.wafer.portal.model.FeedBack;
import com.wafer.portal.model.FeedbackAdminRemark;
import com.wafer.portal.repository.FeedbackRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class FeedbackService {
    private static final String FEED_BACK_UPLOADS = "FeedBack-Uploads";
    private static final Logger log = LoggerFactory.getLogger(FeedbackService.class);

    private FeedbackRepository repository;
    private S3Service s3Service;
    private FeedbackEmailService feedbackEmailService;

    @Autowired
    public FeedbackService(FeedbackRepository repository, S3Service s3Service, FeedbackEmailService feedbackEmailService) {
        this.repository = repository;
        this.s3Service = s3Service;
        this.feedbackEmailService = feedbackEmailService;
    }

    @Transactional
    public ResponseEntity<FeedbackResponse> createFeedback(MultipartFile file, FeedbackRequest request) {
        try {
            String urlKey = null;

            if (file != null && !file.isEmpty()) {
                urlKey = s3Service.uploadFile(file, FEED_BACK_UPLOADS);
            }

           FeedBack feedback = new FeedBack(request.getFeedbackDescription(), urlKey);
            FeedBack saved = repository.save(feedback);

            return new ResponseEntity<>(mapToResponseDto(saved), HttpStatus.CREATED);
        } catch (IOException e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Transactional(readOnly = true)
    public ResponseEntity<Page<FeedbackResponse>> getAllFeedBack(Pageable pageable) {
        Page<FeedBack> fbs = repository.findByIsDeletedFalseOrderByCreationDateDesc(pageable);

        Page<FeedbackResponse> dtoPage = fbs.map(this::mapToResponseDto);
        return dtoPage.isEmpty() ? new ResponseEntity<>(HttpStatus.NO_CONTENT) : new ResponseEntity<>(dtoPage, HttpStatus.OK);
    }

    @Transactional(readOnly = true)
    public ResponseEntity<Page<FeedbackAdminResponse>> getAllFeedBackAdmin(Pageable pageable) {
        Page<FeedBack> fbs = repository.findByIsDeletedFalseOrderByCreationDateDesc(pageable);

        Page<FeedbackAdminResponse> dtoPage = fbs.map(this::mapToResponseDtoAdmin);
        return dtoPage.isEmpty() ? new ResponseEntity<>(HttpStatus.NO_CONTENT) : new ResponseEntity<>(dtoPage, HttpStatus.OK);
    }

    @Transactional(readOnly = true)
    public ResponseEntity<FeedbackAdminResponse> getFeedbackById(Long id) {
        return repository.findByIdAndIsDeletedFalse(id)
                .map(news -> new ResponseEntity<>(mapToResponseDtoAdmin(news), HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @Transactional
    public ResponseEntity<FeedbackResponse> updateFeedback(Long id, MultipartFile file, FeedbackRequest request) {
        return repository.findByIdAndIsDeletedFalse(id)
                .map(existingFbs -> {
                    try {
                        // If a new PDF is provided, replace it in S3
                        if (file != null && !file.isEmpty()) {
                            String newFile = s3Service.updateFile(existingFbs.getAttachment(), file, FEED_BACK_UPLOADS);
                            existingFbs.setAttachment(newFile);
                        }

                        existingFbs.setFeedbackDescription(request.getFeedbackDescription());

                        FeedBack updated = repository.save(existingFbs);
                        return new ResponseEntity<>(mapToResponseDto(updated), HttpStatus.OK);
                    } catch (IOException e) {
                        return new ResponseEntity<FeedbackResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
                    }
                })
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @Transactional
    public ResponseEntity<FeedbackAdminResponse> updateFeedbackAdmin(Long id, MultipartFile file, FeedbackAdminRequest request) {
        return repository.findByIdAndIsDeletedFalse(id)
                .map(existingFbs -> {
                    try {
                        if (file != null && !file.isEmpty()) {
                            String newFile = s3Service.updateFile(existingFbs.getUploadedDocument(), file, FEED_BACK_UPLOADS);
                            existingFbs.setAttachment(newFile);
                        }

                        boolean wasTicketAlreadyClosed = existingFbs.isTicketClosed();

                        existingFbs.setActionTaken(request.isActionTaken());
                        existingFbs.setFeedbackDate(request.getFeedbackDate());
                        if (request.getAdminRemarks() != null && !request.getAdminRemarks().isBlank()) {

                            FeedbackAdminRemark remark = new FeedbackAdminRemark();
                            remark.setRemark(request.getAdminRemarks());
                            remark.setFeedback(existingFbs);
                            remark.setCreatedBy(existingFbs.getLastModifiedBy());

                            existingFbs.getAdminRemarks().add(remark);
                        }


                        if (request.isTicketClosed()) {
                            existingFbs.setTicketClosed(true);
                        }

                        FeedBack updated = repository.save(existingFbs);

                       if (request.isSendMail() && !wasTicketAlreadyClosed) {
                           try {
                               String toEmail = updated.getCreatedBy();
                               log.info("Retrieved CreatedBy email for feedback {}: '{}'", updated.getId(), toEmail);
                               if (toEmail == null) {
                                   log.error("CreatedBy is NULL for feedback {}", updated.getId());
                               } else {
                                   toEmail = toEmail.trim();
                                   if (!toEmail.matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
                                       log.error("Invalid email detected: '{}'", toEmail);
                                   } else {
                                       feedbackEmailService.sendFeedbackStatusMail(toEmail, updated);
                                       updated.setMailSent(true);
                                       updated = repository.save(updated);
                                   }
                               }
                           } catch (Exception ex) {
                               log.error("Failed to send feedback email for id {}", updated.getId(), ex);
                           }
                       }

                        return new ResponseEntity<>(mapToResponseDtoAdmin(updated), HttpStatus.OK);
                    } catch (IOException e) {
                        return new ResponseEntity<FeedbackAdminResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
                    }
                })
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @Transactional(readOnly = true)
    public ResponseEntity<Page<FeedbackAdminResponse>> getAllFeedbackHistoryByDateRange(
            LocalDate startDate,
            LocalDate endDate,
            Pageable pageable) {

        LocalDateTime startDateTime = startDate.atStartOfDay();
        LocalDateTime endDateTime = endDate.plusDays(1).atStartOfDay(); // inclusive

        Page<FeedBack> feedbackPage =
                repository.findByIsDeletedFalseAndCreationDateBetweenOrderByCreationDateDesc(
                        startDateTime,
                        endDateTime,
                        pageable
                );

        if (feedbackPage.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }

        Page<FeedbackAdminResponse> responsePage =
                feedbackPage.map(this::mapToResponseDtoAdmin);

        return new ResponseEntity<>(responsePage, HttpStatus.OK);
    }


    @Transactional
    public FeedBack deleteFeedback(Long id) {
        Optional<FeedBack> fbsOpt = repository.findByIdAndIsDeletedFalse(id);
        if (fbsOpt.isEmpty()) {
            return null;
        }
        FeedBack fbs = fbsOpt.get();
        fbs.setDeleted(true);
        return repository.save(fbs);
    }

    private FeedbackResponse mapToResponseDto(FeedBack fb) {
        String feedbackPresignedUrl = null;

        if (fb.getAttachment() != null && !fb.getAttachment().isEmpty()) {
            feedbackPresignedUrl = s3Service.generatePresignedUrl(fb.getAttachment());
        }

        return new FeedbackResponse(
                fb.getId(),
                fb.getFeedbackDescription(),
                feedbackPresignedUrl,
                fb.getCreatedBy(),
                fb.getCreationDate(),
                fb.getLastModifiedBy(),
                fb.getLastModifiedDate()
        );
    }
    private FeedbackAdminResponse mapToResponseDtoAdmin(FeedBack fb) {
        String feedbackPresignedUrl = null;
        String uploadPresignedUrl = null;

        if (fb.getAttachment() != null && !fb.getAttachment().isEmpty()) {
            feedbackPresignedUrl = s3Service.generatePresignedUrl(fb.getAttachment());
        }
        if (fb.getUploadedDocument() != null && !fb.getUploadedDocument().isEmpty()) {
            uploadPresignedUrl = s3Service.generatePresignedUrl(fb.getAttachment());
        }

        List<AdminRemarkResponse> remarks =
                fb.getAdminRemarks().stream()
                        .map(r -> {
                            AdminRemarkResponse dto = new AdminRemarkResponse();
                            dto.setRemark(r.getRemark());
                            dto.setCreatedBy(r.getCreatedBy());
                            dto.setCreatedDate(r.getCreatedDate());
                            return dto;
                        })
                        .toList();


        return new FeedbackAdminResponse(
                fb.getId(),
                fb.getFeedbackDescription(),
                feedbackPresignedUrl,
                fb.getFeedbackDate(),
                fb.isActionTaken(),
                uploadPresignedUrl,
                remarks,
                fb.isMailSent(),
                fb.isTicketClosed(),
                fb.getCreatedBy(),
                fb.getCreationDate(),
                fb.getLastModifiedBy(),
                fb.getLastModifiedDate()
        );
    }
}
