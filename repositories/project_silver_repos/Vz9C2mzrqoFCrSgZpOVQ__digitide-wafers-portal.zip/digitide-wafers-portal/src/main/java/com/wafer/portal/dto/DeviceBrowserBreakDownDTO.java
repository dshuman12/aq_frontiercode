package com.wafer.portal.dto;

import java.util.List;
import java.util.Map;

public class DeviceBrowserBreakDownDTO {

    private List<Map<String, Object>> deviceBreakdown;
    private List<Map<String, Object>> browserBreakdown;

    public DeviceBrowserBreakDownDTO(List<Map<String, Object>> deviceBreakdown, List<Map<String, Object>> browserBreakdown) {
        this.deviceBreakdown = deviceBreakdown;
        this.browserBreakdown = browserBreakdown;
    }

    public List<Map<String, Object>> getDeviceBreakdown() {
        return deviceBreakdown;
    }

    public List<Map<String, Object>> getBrowserBreakdown() {
        return browserBreakdown;
    }
}
