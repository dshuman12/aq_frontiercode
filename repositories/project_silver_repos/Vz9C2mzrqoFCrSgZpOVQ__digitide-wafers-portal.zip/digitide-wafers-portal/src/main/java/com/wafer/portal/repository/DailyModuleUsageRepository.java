package com.wafer.portal.repository;

import com.wafer.portal.dto.*;
import com.wafer.portal.model.AppModule;
import com.wafer.portal.model.DailyModuleUsage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface DailyModuleUsageRepository extends JpaRepository<DailyModuleUsage, Long> {

    Optional<DailyModuleUsage> findByModuleAndUsageDate(AppModule module, LocalDate date);

    @Query("""
       SELECT m.id, m.moduleName, m.moduleLevel, SUM(d.clickCount)
       FROM DailyModuleUsage d
       JOIN d.module m
       WHERE d.usageDate BETWEEN :startDate AND :endDate
       GROUP BY m.id, m.moduleName, m.moduleLevel
       ORDER BY SUM(d.clickCount) DESC
       """)
    List<Object[]> getUsageBetweenDates(LocalDate startDate, LocalDate endDate);

    @Query("""
       SELECT new com.wafer.portal.dto.ModuleBreakdownDTO(
           m.id,
           m.moduleName,
           m.moduleCode,
           m.moduleLevel,
           SUM(d.clickCount),
           (SUM(d.clickCount) * 100.0 /
               SUM(SUM(d.clickCount)) OVER())
       )
       FROM DailyModuleUsage d
       JOIN d.module m
       WHERE d.usageDate BETWEEN :startDate AND :endDate
       AND (:levelId IS NULL OR m.moduleLevel = :levelId)
       AND (:moduleId IS NULL OR m.id IN :moduleId)
       GROUP BY m.id, m.moduleName, m.moduleLevel
       ORDER BY SUM(d.clickCount) DESC
       """)
    List<ModuleBreakdownDTO> getModuleBreakdown(
            LocalDate startDate,
            LocalDate endDate,
            Long levelId,
            List<Long> moduleId
    );

//    @Query("""
//       SELECT new com.wafer.portal.dto.MonthlyClicksDTO(
//           YEAR(d.usageDate),
//           MONTH(d.usageDate),
//           SUM(d.clickCount)
//       )
//       FROM DailyModuleUsage d
//       WHERE d.usageDate BETWEEN :startDate AND :endDate
//       GROUP BY YEAR(d.usageDate), MONTH(d.usageDate)
//       ORDER BY YEAR(d.usageDate), MONTH(d.usageDate)
//       """)
//    List<MonthlyClicksDTO> getMonthlyClicks(
//            LocalDate startDate,
//            LocalDate endDate
//    );



    @Query("""
    SELECT m.id, SUM(d.clickCount)
    FROM DailyModuleUsage d
    JOIN d.module m
    WHERE d.usageDate BETWEEN :startDate AND :endDate
    GROUP BY m.id
""")
    List<Object[]> getModuleClicks(LocalDate startDate, LocalDate endDate);

    @Query("""
       SELECT new com.wafer.portal.dto.TimeBasedClicksDTO(
           CAST(d.usageDate as string),
           SUM(d.clickCount)
       )
       FROM DailyModuleUsage d
       WHERE d.usageDate BETWEEN :startDate AND :endDate
       GROUP BY d.usageDate
       ORDER BY d.usageDate
       """)
    List<TimeBasedClicksDTO> getDailyClicks(
            LocalDate startDate,
            LocalDate endDate
    );

    @Query(value = """
       SELECT 
           TO_CHAR(usage_date, 'Dy') as label,
           SUM(click_count) as totalClicks
       FROM daily_module_usage
       WHERE usage_date BETWEEN :startDate AND :endDate
       GROUP BY EXTRACT(DOW FROM usage_date), 
                TO_CHAR(usage_date, 'Dy')
       ORDER BY EXTRACT(DOW FROM usage_date)
       """, nativeQuery = true)
    List<Object[]> getWeeklyClicks(
            @Param("startDate") LocalDate startDate,
            @Param("endDate") LocalDate endDate
    );


    @Query("""
    SELECT COALESCE(SUM(d.clickCount), 0)
    FROM DailyModuleUsage d
    WHERE d.usageDate BETWEEN :startDate AND :endDate
""")
    Long getTotalClicks(LocalDate startDate, LocalDate endDate);

    @Query("""
    SELECT m.moduleName, SUM(d.clickCount) as total
    FROM DailyModuleUsage d
    JOIN d.module m
    WHERE d.usageDate BETWEEN :startDate AND :endDate
    GROUP BY m.moduleName
    ORDER BY total DESC
""")
    List<Object[]> getModuleRanking(LocalDate startDate, LocalDate endDate);



}

