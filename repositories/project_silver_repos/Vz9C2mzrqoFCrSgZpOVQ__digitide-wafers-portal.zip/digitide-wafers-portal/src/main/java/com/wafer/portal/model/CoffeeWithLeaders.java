package com.wafer.portal.model;

import com.wafer.portal.audit.Auditable;
import jakarta.persistence.*;
import org.hibernate.annotations.Where;

import java.io.Serializable;

@Entity
@Table(name = "coffee_with_leaders")
@Where(clause = "is_deleted = false")
public class CoffeeWithLeaders extends Auditable<String> implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;

    private String designation;

    private String image;

    private String description;

    @Column(name="thumbnail_url")
    private String thumbnail;   // S3 key

    private Double sequence;

    @Column(name = "is_deleted", nullable = false)
    private boolean isDeleted = false;

    public CoffeeWithLeaders() {
    }

    public CoffeeWithLeaders(String title, String designation, String image, String description, String thumbnail, Double sequence) {
        this.title = title;
        this.designation = designation;
        this.image = image;
        this.description = description;
        this.thumbnail = thumbnail;
        this.sequence = sequence;
        this.isDeleted = false;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public Double getSequence() {
        return sequence;
    }

    public void setSequence(Double sequence) {
        this.sequence = sequence;
    }

    public boolean isDeleted() {
        return isDeleted;
    }

    public void setDeleted(boolean deleted) {
        isDeleted = deleted;
    }
}
