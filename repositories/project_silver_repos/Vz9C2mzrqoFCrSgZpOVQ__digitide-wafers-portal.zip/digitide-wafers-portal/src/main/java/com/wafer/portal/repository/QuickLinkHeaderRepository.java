package com.wafer.portal.repository;

import com.wafer.portal.model.People;
import com.wafer.portal.model.QuickLinkHeader;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface QuickLinkHeaderRepository extends JpaRepository<QuickLinkHeader,Long> {
    @EntityGraph(attributePaths = "subHeaderList")
    Page<QuickLinkHeader> findByIsDeletedFalse(Pageable pageable);

    @EntityGraph(attributePaths = "subHeaderList")
    Optional<QuickLinkHeader> findByIdAndIsDeletedFalse(Long aLong);

    @Query("SELECT q FROM QuickLinkHeader q WHERE q.isDeleted = false AND " +
            "(LOWER(q.title) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(q.url) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    Page<QuickLinkHeader> searchQuickLinkHeader(@Param("keyword") String keyword, Pageable pageable);
}
