package com.wafer.portal.service;

import com.wafer.portal.model.Announcements;
import com.wafer.portal.repository.AnnouncementsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AnnouncementsService {
    @Autowired
    private AnnouncementsRepository announcementsRepository;

    public Announcements saveAnnouncement(Announcements announcements) {
        return announcementsRepository.save(announcements);
    }

    public Page<Announcements> getAllAnnouncements(Pageable pageable) {
        return announcementsRepository.findAllOrderedBySequence(pageable);
    }

    public Optional<Announcements> getAnnouncementById(Long id) {
        return announcementsRepository.findByIdAndIsDeletedFalse(id);
    }

    public Announcements updateAnnouncement(Long id, Announcements updateAnnouncement) {
        return announcementsRepository.findByIdAndIsDeletedFalse(id).map(announcements -> {
            announcements.setImage(updateAnnouncement.getImage());
            announcements.setContent(updateAnnouncement.getContent());
            return announcementsRepository.save(announcements);
        }).orElse(null);
    }

    public Announcements softDeleteAnnouncement(Long id) {
        return announcementsRepository.findByIdAndIsDeletedFalse(id)
                .map(announcements -> {
                    announcements.setIsDeleted(true);
                    return announcementsRepository.save(announcements);
                }).orElse(null);
    }
}
