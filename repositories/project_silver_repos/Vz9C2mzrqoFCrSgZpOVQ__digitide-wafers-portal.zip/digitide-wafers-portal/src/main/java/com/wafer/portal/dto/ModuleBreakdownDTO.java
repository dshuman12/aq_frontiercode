package com.wafer.portal.dto;

public class ModuleBreakdownDTO {
    private Long id;
    private String moduleName;
    private String moduleCode;
    private Integer moduleLevel;
    private Long totalClicks;
    private Double contributionPercentage;

    public ModuleBreakdownDTO(Long id, String moduleName, String moduleCode, Integer moduleLevel, Long totalClicks, Double contributionPercentage) {
        this.id = id;
        this.moduleName = moduleName;
        this.moduleCode = moduleCode;
        this.moduleLevel = moduleLevel;
        this.totalClicks = totalClicks;
        this.contributionPercentage = contributionPercentage;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getModuleName() {
        return moduleName;
    }

    public void setModuleName(String moduleName) {
        this.moduleName = moduleName;
    }

    public String getModuleCode() {
        return moduleCode;
    }

    public void setModuleCode(String moduleCode) {
        this.moduleCode = moduleCode;
    }

    public Integer getModuleLevel() {
        return moduleLevel;
    }

    public void setModuleLevel(Integer moduleLevel) {
        this.moduleLevel = moduleLevel;
    }

    public Long getTotalClicks() {
        return totalClicks;
    }

    public void setTotalClicks(Long totalClicks) {
        this.totalClicks = totalClicks;
    }

    public Double getContributionPercentage() {
        return contributionPercentage;
    }

    public void setContributionPercentage(Double contributionPercentage) {
        this.contributionPercentage = contributionPercentage;
    }
}
