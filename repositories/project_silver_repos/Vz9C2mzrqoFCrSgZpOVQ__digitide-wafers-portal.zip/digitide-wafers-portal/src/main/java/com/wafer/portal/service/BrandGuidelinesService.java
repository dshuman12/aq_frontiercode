package com.wafer.portal.service;

import com.wafer.portal.awsS3.S3Service;
import com.wafer.portal.dto.BrandGuidelinesRequest;
import com.wafer.portal.dto.BrandGuidelinesResponseDto;
import com.wafer.portal.model.BrandGuidelines;
import com.wafer.portal.repository.BrandGuidelinesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@Service
public class BrandGuidelinesService {

    private static final String GUIDELINES_FOLDER = "Brand-Guidelines-Docs";
    private final BrandGuidelinesRepository repository;
    private final S3Service s3Service;

    @Autowired
    public BrandGuidelinesService(BrandGuidelinesRepository repository, S3Service s3Service) {
        this.repository = repository;
        this.s3Service = s3Service;
    }

    public ResponseEntity<BrandGuidelinesResponseDto> createGuideline(MultipartFile document, BrandGuidelinesRequest request) {
        try {
            if (document == null || document.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
            }
            String docKey = s3Service.uploadFile(document, GUIDELINES_FOLDER);
            BrandGuidelines guideline = new BrandGuidelines(request.getTitle(), docKey, request.getSequence());
            BrandGuidelines saved = repository.save(guideline);
            return new ResponseEntity<>(mapToDto(saved), HttpStatus.CREATED);
        } catch (IOException e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Page<BrandGuidelinesResponseDto>> getAll(Pageable pageable) {
        Page<BrandGuidelinesResponseDto> page = repository.findAllOrderedBySequence(pageable).map(this::mapToDto);
        return page.isEmpty() ? new ResponseEntity<>(HttpStatus.NO_CONTENT) : new ResponseEntity<>(page, HttpStatus.OK);
    }

    public ResponseEntity<BrandGuidelinesResponseDto> getById(Long id) {
        return repository.findByIdAndIsDeletedFalse(id)
                .map(guideline -> new ResponseEntity<>(mapToDto(guideline), HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    public ResponseEntity<BrandGuidelinesResponseDto> updateGuideline(
            Long id,
            MultipartFile document,
            BrandGuidelinesRequest request) {

        return repository.findByIdAndIsDeletedFalse(id)
                .map(existing -> {
                    try {
                        String updatedKey = existing.getDocumentKey();

                        if (document != null && !document.isEmpty()) {
                            updatedKey = s3Service.updateFile(existing.getDocumentKey(), document, GUIDELINES_FOLDER);
                        }

                        existing.setTitle(request.getTitle());
                        existing.setSequence(request.getSequence());
                        existing.setDocumentKey(updatedKey);

                        BrandGuidelines updated = repository.save(existing);
                        return new ResponseEntity<>(mapToDto(updated), HttpStatus.OK);

                    } catch (IOException e) {
                        return new ResponseEntity<BrandGuidelinesResponseDto>(HttpStatus.INTERNAL_SERVER_ERROR);
                    }
                })
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    public BrandGuidelines deleteGuideline(Long id) {
        return repository.findByIdAndIsDeletedFalse(id).map(g -> {
            g.setIsDeleted(true);
            return repository.save(g);
        }).orElse(null);
    }

    private BrandGuidelinesResponseDto mapToDto(BrandGuidelines entity) {
        String preSignedUrl = s3Service.generatePresignedUrl(entity.getDocumentKey());
        return new BrandGuidelinesResponseDto(
                entity.getId(),
                entity.getTitle(),
                preSignedUrl,
                entity.getSequence()
        );
    }


}
