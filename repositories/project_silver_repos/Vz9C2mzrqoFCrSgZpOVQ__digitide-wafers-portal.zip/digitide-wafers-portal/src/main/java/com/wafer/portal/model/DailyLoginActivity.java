package com.wafer.portal.model;

import com.wafer.portal.audit.Auditable;
import jakarta.persistence.*;

import java.io.Serializable;
import java.time.LocalDate;

@Entity
@Table(name = "daily_login_activity")
public class DailyLoginActivity extends Auditable<String> implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_email", nullable = false)
    private String userEmail;

    @Column(name = "login_date", nullable = false)
    private LocalDate loginDate;

    @Column(name = "designation")
    private String designation;

    @Column(name = "is_deleted")
    private boolean isDeleted = false;

    public DailyLoginActivity() {}

    public DailyLoginActivity(String userEmail, LocalDate loginDate) {
        this.userEmail = userEmail;
        this.loginDate = loginDate;
    }

    public Long getId() { return id; }
    public String getUserEmail() { return userEmail; }
    public LocalDate getLoginDate() { return loginDate; }
    public boolean isDeleted() { return isDeleted; }

    public void setId(Long id) { this.id = id; }
    public void setUserEmail(String userEmail) { this.userEmail = userEmail; }

    public void setLoginDate(LocalDate loginDate) { this.loginDate = loginDate; }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public void setDeleted(boolean deleted) { isDeleted = deleted; }
}