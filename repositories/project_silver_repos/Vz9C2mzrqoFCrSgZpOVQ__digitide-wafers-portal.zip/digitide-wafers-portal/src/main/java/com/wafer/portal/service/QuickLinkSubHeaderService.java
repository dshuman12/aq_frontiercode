package com.wafer.portal.service;


import com.wafer.portal.awsS3.S3Service;
import com.wafer.portal.dto.QuickLinkSubHeaderRequest;
import com.wafer.portal.dto.QuickLinkSubHeaderResponseDTO;
import com.wafer.portal.model.LinkType;
import com.wafer.portal.model.QuickLinkHeader;
import com.wafer.portal.model.QuickLinkSubHeader;
import com.wafer.portal.repository.QuickLinkHeaderRepository;
import com.wafer.portal.repository.QuickLinkSubHeaderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

@Service
public class QuickLinkSubHeaderService {

    private static final String QUICK_LINKS_FOLDER = "Quick_Links_Pdf";

    private QuickLinkSubHeaderRepository repository;
    private QuickLinkHeaderRepository quickLinkHeaderRepository;
    private S3Service s3Service;

    @Autowired
    public QuickLinkSubHeaderService(QuickLinkSubHeaderRepository repository, S3Service s3Service, QuickLinkHeaderRepository quickLinkHeaderRepository) {
        this.repository = repository;
        this.s3Service = s3Service;
        this.quickLinkHeaderRepository = quickLinkHeaderRepository;
    }

    @Transactional
    public ResponseEntity<QuickLinkSubHeaderResponseDTO> createQuickLink(
            MultipartFile pdf,
            QuickLinkSubHeaderRequest request) {

        validateRequest(pdf, request);

        try {
            QuickLinkHeader header = quickLinkHeaderRepository
                    .findByIdAndIsDeletedFalse(request.getParentId())
                    .orElseThrow(() -> new RuntimeException(
                            "Header not found with id: " + request.getParentId()));

            String url;
            if (request.getLinkType() == LinkType.FILE) {
                url = s3Service.uploadFile(pdf, QUICK_LINKS_FOLDER);
            } else {
                url = request.getUrl();
            }

            QuickLinkSubHeader subHeader = new QuickLinkSubHeader(
                    request.getTitle(),
                    header,
                    url,
                    request.getLinkType()
            );

            QuickLinkSubHeader saved = repository.save(subHeader);
            return new ResponseEntity<>(mapToResponseDto(saved), HttpStatus.CREATED);

        } catch (IOException e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @Transactional(readOnly = true)
    public ResponseEntity<Page<QuickLinkSubHeaderResponseDTO>> getAllQuickLinks(Pageable pageable) {
        Page<QuickLinkSubHeader> qls = repository.findByIsDeletedFalse(pageable);
        Page<QuickLinkSubHeaderResponseDTO> dtoPage = qls.map(this::mapToResponseDto);
        return dtoPage.isEmpty() ? new ResponseEntity<>(HttpStatus.NO_CONTENT) : new ResponseEntity<>(dtoPage, HttpStatus.OK);
    }

    @Transactional(readOnly = true)
    public ResponseEntity<QuickLinkSubHeaderResponseDTO> getQuickLinkById(Long id) {
        return repository.findByIdAndIsDeletedFalse(id)
                .map(news -> new ResponseEntity<>(mapToResponseDto(news), HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @Transactional
    public ResponseEntity<QuickLinkSubHeaderResponseDTO> updateQuickLink(
            Long id,
            MultipartFile pdf,
            QuickLinkSubHeaderRequest request) {



        return repository.findByIdAndIsDeletedFalse(id)
                .map(existing -> {
                    try {
                        // Title update (null or empty-safe)
                        if (request.getTitle() != null && !request.getTitle().isEmpty()) {
                            existing.setTitle(request.getTitle());
                        }

                        // LinkType update
                        if (request.getLinkType() != null) {
                            existing.setLinkType(request.getLinkType());
                        }

                        // Parent header update
                        if (request.getParentId() != null) {
                            QuickLinkHeader header = quickLinkHeaderRepository
                                    .findByIdAndIsDeletedFalse(request.getParentId())
                                    .orElseThrow(() ->
                                            new RuntimeException("Header not found with id: " + request.getParentId())
                                    );
                            existing.setHeader(header);
                        }


                        if (LinkType.FILE.equals(request.getLinkType()) && pdf != null && !pdf.isEmpty()) {
                            
                            String newKey = s3Service.updateFile(existing.getUrl(), pdf, QUICK_LINKS_FOLDER);
                            existing.setUrl(newKey);
                        }else if (request.getUrl() != null && !request.getUrl().isEmpty()) {

                            existing.setUrl(request.getUrl());
                        }

                        QuickLinkSubHeader updated = repository.save(existing);
                        return new ResponseEntity<>(mapToResponseDto(updated), HttpStatus.OK);

                    } catch (IOException e) {
                        return new ResponseEntity<QuickLinkSubHeaderResponseDTO>(
                                HttpStatus.INTERNAL_SERVER_ERROR);
                    }
                })
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));

    }


    @Transactional
    public QuickLinkSubHeader deleteQuickLink(Long id) {
        return repository.findByIdAndIsDeletedFalse(id)
                .map(qls -> {
                    qls.setDeleted(true);

                    return repository.save(qls);
                }).orElse(null);
    }

    private void validateRequest(MultipartFile pdf, QuickLinkSubHeaderRequest request) {

        if (request.getLinkType() == null) {
            throw new IllegalArgumentException("linkType is required");
        }

        if (request.getLinkType() == LinkType.FILE) {
            if (pdf == null || pdf.isEmpty()) {
                throw new IllegalArgumentException("PDF file is required for FILE linkType");
            }
        }

        if (request.getLinkType() == LinkType.URL) {
            if (request.getUrl() == null || request.getUrl().isBlank()) {
                throw new IllegalArgumentException("URL is required for URL linkType");
            }
        }
    }



    private QuickLinkSubHeaderResponseDTO mapToResponseDto(QuickLinkSubHeader ql) {

        String finalUrl;
        if (ql.getLinkType() == LinkType.FILE) {
            finalUrl = s3Service.generatePresignedUrl(ql.getUrl());
        } else {
            finalUrl = ql.getUrl();
        }

        return new QuickLinkSubHeaderResponseDTO(
                ql.getId(),
                ql.getTitle(),
                ql.getHeader() != null ? ql.getHeader().getId() : null,
                ql.getHeader() != null ? ql.getHeader().getTitle() : null,
                finalUrl,
                ql.getLinkType(),
                ql.getCreatedBy(),
                ql.getCreationDate(),
                ql.getLastModifiedBy(),
                ql.getLastModifiedDate()
        );
    }

}
