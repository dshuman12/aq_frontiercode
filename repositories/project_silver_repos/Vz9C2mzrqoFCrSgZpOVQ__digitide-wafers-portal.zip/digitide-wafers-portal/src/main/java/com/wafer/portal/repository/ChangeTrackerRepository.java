package com.wafer.portal.repository;

import com.wafer.portal.model.ChangeTracker;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.Optional;

@Repository
public interface ChangeTrackerRepository extends JpaRepository<ChangeTracker, Long> {


    Page<ChangeTracker> findByIsDeletedFalseOrderByTimestampDesc(Pageable pageable);

    Page<ChangeTracker> findByIsDeletedFalseAndTimestampBetweenOrderByTimestampDesc(
            LocalDateTime start,
            LocalDateTime end,
            Pageable pageable
    );

    Optional<ChangeTracker> findByIdAndIsDeletedFalse(Long id);
}