package com.wafer.portal.model;

import com.wafer.portal.audit.Auditable;
import jakarta.persistence.*;

import java.io.Serializable;

@Entity
@Table(name = "pic_of_the_day")
public class PicOfTheDay extends Auditable<String> implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;

    private String designation;

    private String place;

    private String image;

    @Column(name="thumbnail_url")
    private String thumbnail;   // S3 key

    @Column(name = "is_deleted", nullable = false)
    private boolean isDeleted = false;

    public PicOfTheDay() {
    }

    public PicOfTheDay(String title, String image, String thumbnail, String designation, String place) {
        this.title = title;
        this.designation = designation;
        this.place = place;
        this.image = image;
        this.thumbnail = thumbnail;
        this.isDeleted = false;
    }

    // Getters and setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public String getImage() { return image; }
    public void setImage(String image) { this.image = image; }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public boolean isDeleted() { return isDeleted; }
    public void setDeleted(boolean deleted) { isDeleted = deleted; }
}
