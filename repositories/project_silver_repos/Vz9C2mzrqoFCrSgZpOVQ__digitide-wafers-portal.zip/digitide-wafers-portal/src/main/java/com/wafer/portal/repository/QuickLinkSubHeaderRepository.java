package com.wafer.portal.repository;

import com.wafer.portal.model.QuickLinkHeader;
import com.wafer.portal.model.QuickLinkSubHeader;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface QuickLinkSubHeaderRepository extends JpaRepository<QuickLinkSubHeader,Long> {
    Page<QuickLinkSubHeader> findByIsDeletedFalse(Pageable pageable);
    Optional<QuickLinkSubHeader> findByIdAndIsDeletedFalse(Long aLong);
    List<QuickLinkSubHeader> findAllByHeaderAndIsDeletedFalse(QuickLinkHeader header);


    @Query("SELECT s FROM QuickLinkSubHeader s WHERE s.isDeleted = false AND " +
            "(LOWER(s.title) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(s.url) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(s.header.title) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    Page<QuickLinkSubHeader> searchQuickLinkSubHeader(@Param("keyword") String keyword, Pageable pageable);

}
