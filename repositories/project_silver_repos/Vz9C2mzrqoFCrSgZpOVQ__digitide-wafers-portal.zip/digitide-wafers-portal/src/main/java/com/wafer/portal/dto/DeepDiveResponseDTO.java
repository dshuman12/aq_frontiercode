package com.wafer.portal.dto;

import java.util.ArrayList;
import java.util.List;

public class DeepDiveResponseDTO {

    private Long id;
    private String moduleName;
    private Long clicks;
    private Double percentage;
    private List<DeepDiveResponseDTO> children;

    public DeepDiveResponseDTO(Long id,
                               String moduleName,
                               Long clicks,
                               Double percentage) {
        this.id = id;
        this.moduleName = moduleName;
        this.clicks = clicks;
        this.percentage = percentage;
        this.children = new ArrayList<>();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getModuleName() {
        return moduleName;
    }

    public void setModuleName(String moduleName) {
        this.moduleName = moduleName;
    }

    public Long getClicks() {
        return clicks;
    }

    public void setClicks(Long clicks) {
        this.clicks = clicks;
    }

    public Double getPercentage() {
        return percentage;
    }

    public void setPercentage(Double percentage) {
        this.percentage = percentage;
    }

    public List<DeepDiveResponseDTO> getChildren() {
        return children;
    }

    public void setChildren(List<DeepDiveResponseDTO> children) {
        this.children = children;
    }
}
