package com.wafer.portal.dto;

public class RewardsSubsectionRequest {
    private String subsectionName;

    public RewardsSubsectionRequest() {}

    public String getSubsectionName() { return subsectionName; }
    public void setSubsectionName(String subsectionName) { this.subsectionName = subsectionName; }
}