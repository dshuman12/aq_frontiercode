package com.wafer.portal.dto;

public class SearchAnalyticsDTO {

    private Long totalSearch;
    private Long successCount;
    private Long failureCount;
    private Long clickCount;
    private Double successRate;
    private Double clickThroughRate;
    private Double overallConversion;
    private Double failureRate;

    public SearchAnalyticsDTO(Long totalSearch,
                              Long successCount,
                              Long failureCount,
                              Long clickCount,
                              Double successRate,
                              Double clickThroughRate,
                              Double overallConversion,
                              Double failureRate) {

        this.totalSearch = totalSearch;
        this.successCount = successCount;
        this.failureCount = failureCount;
        this.clickCount = clickCount;
        this.successRate = successRate;
        this.clickThroughRate = clickThroughRate;
        this.overallConversion = overallConversion;
        this.failureRate = failureRate;
    }

    public Long getTotalSearch() {
        return totalSearch;
    }

    public void setTotalSearch(Long totalSearch) {
        this.totalSearch = totalSearch;
    }

    public Long getSuccessCount() {
        return successCount;
    }

    public void setSuccessCount(Long successCount) {
        this.successCount = successCount;
    }

    public Long getFailureCount() {
        return failureCount;
    }

    public void setFailureCount(Long failureCount) {
        this.failureCount = failureCount;
    }

    public Long getClickCount() {
        return clickCount;
    }

    public void setClickCount(Long clickCount) {
        this.clickCount = clickCount;
    }

    public Double getSuccessRate() {
        return successRate;
    }

    public Double getClickThroughRate() {
        return clickThroughRate;
    }

    public Double getOverallConversion() {
        return overallConversion;
    }

    public Double getFailureRate() {
        return failureRate;
    }
}