package com.wafer.portal.dto;

public class DocumentCenterDto {
    private Long id;
    private String title;
    private String imageUrl;
    private String thumbnailUrl;
    private Double sequence;

    public DocumentCenterDto(Long id, String title, String url, String thumbnailUrl, Double sequence) {
        this.id = id;
        this.title = title;
        this.imageUrl = url;
        this.thumbnailUrl=thumbnailUrl;
        this.sequence = sequence;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getThumbnailUrl() { return thumbnailUrl; }

    public void setThumbnailUrl(String thumbnailUrl) { this.thumbnailUrl = thumbnailUrl; }

    public Double getSequence() {
        return sequence;
    }

    public void setSequence(Double sequence) {
        this.sequence = sequence;
    }
}
