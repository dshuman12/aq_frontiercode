package com.wafer.portal.dto;


import java.time.LocalDateTime;


public class PageVisitDTO {


    private String trackingId;
    private String pageName;
    private Integer pageLoadTimeMs;
    private String browser;
    private String deviceType;
    private String os;
    private LocalDateTime createdDate;
    private Long apiCount;
    private String createdBy;


    public PageVisitDTO(String trackingId, String pageName, Integer pageLoadTimeMs,
                        String browser, String deviceType, String os,
                        LocalDateTime createdDate, Long apiCount, String createdBy) {
        this.trackingId = trackingId;
        this.pageName = pageName;
        this.pageLoadTimeMs = pageLoadTimeMs;
        this.browser = browser;
        this.deviceType = deviceType;
        this.os = os;
        this.createdDate = createdDate;
        this.apiCount = apiCount;
        this.createdBy = createdBy;
    }


    public String getTrackingId() { return trackingId; }
    public String getPageName() { return pageName; }
    public Integer getPageLoadTimeMs() { return pageLoadTimeMs; }
    public String getBrowser() { return browser; }
    public String getDeviceType() { return deviceType; }
    public String getOs() { return os; }
    public LocalDateTime getCreatedDate() { return createdDate; }
    public Long getApiCount() { return apiCount; }

    public String getCreatedBy() {
        return createdBy;
    }
}
