package com.wafer.portal.service;

import com.wafer.portal.awsS3.S3Service;
import com.wafer.portal.dto.*;
import com.wafer.portal.model.DocumentCenter;
import com.wafer.portal.model.DocumentSection;
import com.wafer.portal.repository.DocumentCenterRepository;
import com.wafer.portal.repository.DocumentSectionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class DocumentCenterService {

    private static final String DOCUMENT_FOLDER = "Document-Center";
    private static final String THUMBNAIL_FOLDER = "Document-Center-Thumbnails";

    private final DocumentCenterRepository documentCenterRepository;
    private final S3Service s3Service;
    private final DocumentSectionRepository documentSectionRepository;

    @Autowired
    public DocumentCenterService(DocumentCenterRepository documentCenterRepository, S3Service s3Service, DocumentSectionRepository documentSectionRepository) {
        this.documentCenterRepository = documentCenterRepository;
        this.s3Service = s3Service;
        this.documentSectionRepository = documentSectionRepository;
    }

    public ResponseEntity<DocumentCenterResponseDto> uploadDocument(MultipartFile document, MultipartFile thumbnail, DocumentCenterRequest request) {
        try {
            if (document == null || document.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
            }

            //validate section
            DocumentSection section = documentSectionRepository.findById(request.getSection())
                    .orElseThrow(() -> new RuntimeException("Section ID not found"));

            //String originalFilename = document.getOriginalFilename() == null ? "document" : document.getOriginalFilename();
            //String documentName = extractFileNameWithoutPath(originalFilename);
            //String documentName = request.getDocumentName();

            String documentKey = s3Service.uploadFile(document, DOCUMENT_FOLDER);

            String thumbnailKey = null;

            if (thumbnail != null && !thumbnail.isEmpty()) {
                thumbnailKey = s3Service.uploadFile(thumbnail, THUMBNAIL_FOLDER);
            }

            DocumentCenter entity = new DocumentCenter(request.getSection(), documentKey, request.getDocumentName(), thumbnailKey, request.getSequence());

            DocumentCenter saved = documentCenterRepository.save(entity);

            String presignedUrl = s3Service.generatePresignedUrl(saved.getDocumentKey());

            String thumbnailUrl = saved.getThumbnailKey() != null ? s3Service.generatePresignedUrl(saved.getThumbnailKey()) : null;

            DocumentCenterResponseDto dto = new DocumentCenterResponseDto(
                    saved.getId(),
                    saved.getSectionId(),
                    section.getSectionName(),
                    saved.getDocumentName(),
                    presignedUrl,
                    thumbnailUrl,
                    saved.getSequence()
            );

            return new ResponseEntity<>(dto, HttpStatus.CREATED);
        } catch (IOException e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


//    public Page<SectionDocumentsDto> getAllGrouped(Pageable pageable) {
//
//        List<DocumentCenter> allDocs = documentCenterRepository.findByIsDeletedFalse();
//
//        if (allDocs.isEmpty()) {
//            return new PageImpl<>(Collections.emptyList(), pageable, 0);
//        }
//
//        Set<Long> usedSectionIds = allDocs.stream()
//                .map(DocumentCenter::getSectionId)
//                .collect(Collectors.toSet());
//
//        Map<Long, String> sectionMap = documentSectionRepository.findAllById(usedSectionIds)
//                .stream()
//                .collect(Collectors.toMap(DocumentSection::getId, DocumentSection::getSectionName));
//
//        Map<Long, List<DocumentCenterDto>> groupedData = allDocs.stream()
//                .filter(doc -> sectionMap.containsKey(doc.getSectionId()))
//                .collect(Collectors.groupingBy(
//                        DocumentCenter::getSectionId,
//
//                        Collectors.mapping(doc -> {
//
//                            String docUrl = s3Service.generatePresignedUrl(doc.getDocumentKey());
//
//                            String thumbUrl = (doc.getThumbnailKey() != null)
//
//                                    ? s3Service.generatePresignedUrl(doc.getThumbnailKey())
//
//                                    : null;
//
//                            return new DocumentCenterDto(
//
//                                    doc.getId(),
//                                    doc.getDocumentName(),
//                                    docUrl,
//                                    thumbUrl,
//                                    doc.getSequence()
//                            );
//
//                        }, Collectors.toList())
//
//                ));
//
//        List<SectionDocumentsDto> content = groupedData.entrySet().stream()
//                .map(entry -> new SectionDocumentsDto(
//                        entry.getKey(),
//                        sectionMap.get(entry.getKey()),
//                        entry.getValue()
//                ))
//                .collect(Collectors.toList());
//
//        return new PageImpl<>(content, pageable, content.size());
//    }

    public Page<SectionDocumentsDto> getAllGrouped(Pageable pageable) {

        // 🔥 Fetch ALL documents in correct order (avoid pagination here)
        List<DocumentCenter> allDocs =
                documentCenterRepository.findAllActiveOrdered(Pageable.unpaged()).getContent();

        if (allDocs.isEmpty()) {
            return new PageImpl<>(Collections.emptyList(), pageable, 0);
        }

        // 🔹 Get section IDs used
        Set<Long> usedSectionIds = allDocs.stream()
                .map(DocumentCenter::getSectionId)
                .collect(Collectors.toSet());

        // 🔹 Map sectionId -> sectionName
        Map<Long, String> sectionMap = documentSectionRepository.findAllById(usedSectionIds)
                .stream()
                .collect(Collectors.toMap(
                        DocumentSection::getId,
                        DocumentSection::getSectionName
                ));

        // 🔥 Group by section with order preserved
        Map<Long, List<DocumentCenterDto>> groupedData = allDocs.stream()
                .filter(doc -> sectionMap.containsKey(doc.getSectionId()))
                .collect(Collectors.groupingBy(
                        DocumentCenter::getSectionId,
                        LinkedHashMap::new, // ✅ preserve section order
                        Collectors.mapping(doc -> {

                            String docUrl = s3Service.generatePresignedUrl(doc.getDocumentKey());

                            String thumbUrl = (doc.getThumbnailKey() != null)
                                    ? s3Service.generatePresignedUrl(doc.getThumbnailKey())
                                    : null;

                            return new DocumentCenterDto(
                                    doc.getId(),
                                    doc.getDocumentName(),
                                    docUrl,
                                    thumbUrl,
                                    doc.getSequence()
                            );

                        }, Collectors.toList())
                ));

        // 🔥 Sort documents inside each section
        groupedData.values().forEach(list ->
                list.sort(Comparator.comparing(
                        DocumentCenterDto::getSequence,
                        Comparator.nullsLast(Double::compareTo)
                ))
        );

        // 🔹 Convert to Section DTO list
        List<SectionDocumentsDto> allSections = groupedData.entrySet().stream()
                .map(entry -> new SectionDocumentsDto(
                        entry.getKey(),
                        sectionMap.get(entry.getKey()),
                        entry.getValue()
                ))
                .collect(Collectors.toList());

        // 🔥 Apply pagination AFTER grouping
        int start = (int) pageable.getOffset();
        int end = Math.min(start + pageable.getPageSize(), allSections.size());

        List<SectionDocumentsDto> pagedContent =
                (start > end) ? Collections.emptyList() : allSections.subList(start, end);

        return new PageImpl<>(pagedContent, pageable, allSections.size());
    }


    public ResponseEntity<Page<DocumentCenterResponseDto>> getAllDocuments(Pageable pageable) {
        Page<DocumentCenter> page = documentCenterRepository.findAllActiveOrdered(pageable);

        Page<DocumentCenterResponseDto> dtoPage = page.map(dc -> {
            DocumentSection section =
                    documentSectionRepository.findById(dc.getSectionId()).orElse(null);

            return new DocumentCenterResponseDto(
                    dc.getId(),
                    dc.getSectionId(),
                    section != null ? section.getSectionName() : "",
                    dc.getDocumentName(),
                    s3Service.generatePresignedUrl(dc.getDocumentKey()),
                    dc.getThumbnailKey() != null ? s3Service.generatePresignedUrl(dc.getThumbnailKey()) : null,
                    dc.getSequence()
            );
        });

        return dtoPage.isEmpty()
                ? new ResponseEntity<>(HttpStatus.NO_CONTENT)
                : new ResponseEntity<>(dtoPage, HttpStatus.OK);
    }

    // globalSearch (keyword based)
    public List<SectionDocumentsDto> searchGrouped(String keyword) {

        List<DocumentCenter> matchedDocs =
                documentCenterRepository.searchDocumentCenter(keyword);

        if (matchedDocs.isEmpty()) {
            return Collections.emptyList();
        }

        Set<Long> sectionIds = matchedDocs.stream()
                .map(DocumentCenter::getSectionId)
                .collect(Collectors.toSet());

        Map<Long, String> sectionMap =
                documentSectionRepository.findAllById(sectionIds)
                        .stream()
                        .collect(Collectors.toMap(
                                DocumentSection::getId,
                                DocumentSection::getSectionName
                        ));

        Map<Long, List<DocumentCenterDto>> grouped =
                matchedDocs.stream()
                        .filter(doc -> sectionMap.containsKey(doc.getSectionId()))
                        .collect(Collectors.groupingBy(
                                DocumentCenter::getSectionId,
                                Collectors.mapping(doc ->
                                                new DocumentCenterDto(
                                                        doc.getId(),
                                                        doc.getDocumentName(),
                                                        s3Service.generatePresignedUrl(doc.getDocumentKey()),
                                                        s3Service.generatePresignedUrl(doc.getThumbnailKey()),
                                                        doc.getSequence()
                                                ),
                                        Collectors.toList()
                                )
                        ));

        return grouped.entrySet().stream()
                .map(entry -> new SectionDocumentsDto(
                        entry.getKey(),
                        sectionMap.get(entry.getKey()),
                        entry.getValue()
                ))
                .collect(Collectors.toList());
    }



    public ResponseEntity<DocumentCenterResponseDto> getById(Long id) {
        return documentCenterRepository.findByIdAndIsDeletedFalse(id)
                .map(dc -> {
                    DocumentSection section = documentSectionRepository.findById(dc.getSectionId()).orElse(null);
                    String sectionName = section != null ? section.getSectionName() : "";
                    String url = s3Service.generatePresignedUrl(dc.getDocumentKey());
                    String thumbnailUrl = dc.getThumbnailKey() != null ? s3Service.generatePresignedUrl(dc.getThumbnailKey()) : null;
                    DocumentCenterResponseDto dto = new DocumentCenterResponseDto(
                            dc.getId(),
                            dc.getSectionId(),
                            sectionName,
                            dc.getDocumentName(),
                            url,
                            thumbnailUrl,
                            dc.getSequence()
                    );
                    return new ResponseEntity<>(dto, HttpStatus.OK);
                })
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    public ResponseEntity<DocumentCenterResponseDto> updateDocument(Long id, MultipartFile document, MultipartFile thumbnail, DocumentCenterRequest request) {
        return documentCenterRepository.findByIdAndIsDeletedFalse(id)
                .map(existing -> {
                    try {
                        String updatedKey = existing.getDocumentKey();
                        String updatedName = existing.getDocumentName();
                        String updatedThumbnailKey = existing.getThumbnailKey();

                        if (request != null && request.getDocumentName() != null && !request.getDocumentName().isBlank()) {
                            updatedName = request.getDocumentName();
                        }


                        if (document != null && !document.isEmpty() && document.getOriginalFilename() != null) {
                            // replace file in S3
                            updatedKey = s3Service.updateFile(existing.getDocumentKey(), document, DOCUMENT_FOLDER);
                            //String originalFilename = document.getOriginalFilename();
                            //updatedName = extractFileNameWithoutPath(originalFilename);
                        }

                        if (thumbnail != null && !thumbnail.isEmpty()) {
                            if (existing.getThumbnailKey() != null) {
                                updatedThumbnailKey = s3Service.updateFile(existing.getThumbnailKey(), thumbnail, THUMBNAIL_FOLDER);
                            } else {
                                updatedThumbnailKey = s3Service.uploadFile(thumbnail, THUMBNAIL_FOLDER);
                            }
                        }

                        if (request != null && request.getSection() != null) {
                            Optional<DocumentSection> newSectionOpt = documentSectionRepository.findById(request.getSection());
                            if (newSectionOpt.isEmpty()) {
                                return new ResponseEntity<DocumentCenterResponseDto>(HttpStatus.BAD_REQUEST);
                            }
                            existing.setSectionId(request.getSection());
                        }

                        if (request != null && request.getSequence() != null) {
                            existing.setSequence(request.getSequence());
                        }

                        existing.setDocumentKey(updatedKey);
                        existing.setDocumentName(updatedName);
                        existing.setThumbnailKey(updatedThumbnailKey);

                        DocumentCenter updated = documentCenterRepository.save(existing);

                        DocumentSection section = documentSectionRepository.findById(updated.getSectionId()).orElse(null);
                        String sectionName = section != null ? section.getSectionName() : "";

                        String url = s3Service.generatePresignedUrl(updated.getDocumentKey());
                        String thumbnailUrl = updated.getThumbnailKey() != null ? s3Service.generatePresignedUrl(updated.getThumbnailKey()) : null;
                        DocumentCenterResponseDto dto = new DocumentCenterResponseDto(
                                updated.getId(),updated.getSectionId(), sectionName, updated.getDocumentName(), url, thumbnailUrl, updated.getSequence()
                        );

                        return new ResponseEntity<>(dto, HttpStatus.OK);
                    } catch (IOException e) {
                        return new ResponseEntity<DocumentCenterResponseDto>(HttpStatus.INTERNAL_SERVER_ERROR);
                    }
                })
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    public DocumentCenter deleteDocument(Long id) {
        return documentCenterRepository.findByIdAndIsDeletedFalse(id)
                .map(dc -> {
                    dc.setIsDeleted(true);
                    return documentCenterRepository.save(dc);
                }).orElse(null);
    }

    //documentSection
    public ResponseEntity<DocumentSectionResponseDto> createSection(DocumentSectionRequest request) {

        if (request.getSectionName() == null || request.getSectionName().isBlank()) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

        Optional<DocumentSection> exists =
                documentSectionRepository
                        .findBySectionNameIgnoreCaseAndIsDeletedFalse(request.getSectionName());

        if (exists.isPresent()) {
            return new ResponseEntity<>(HttpStatus.CONFLICT);
        }

        DocumentSection section = new DocumentSection(request.getSectionName());
        DocumentSection saved = documentSectionRepository.save(section);

        DocumentSectionResponseDto response =
                new DocumentSectionResponseDto(
                        saved.getId(),
                        saved.getSectionName()
                );

        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }



    public ResponseEntity<Page<DocumentSection>> getAllSections(Pageable pageable) {

        Page<DocumentSection> page =
                documentSectionRepository.findByIsDeletedFalse(pageable);

        return page.isEmpty()
                ? new ResponseEntity<>(HttpStatus.NO_CONTENT)
                : new ResponseEntity<>(page, HttpStatus.OK);
    }

    public ResponseEntity<Void> deleteSection(Long id) {

        Optional<DocumentSection> sectionOpt =
                documentSectionRepository.findById(id);

        if (sectionOpt.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        boolean hasDocuments =
                documentCenterRepository.existsBySectionIdAndIsDeletedFalse(id);

        if (hasDocuments) {
            return new ResponseEntity<>(HttpStatus.CONFLICT);
        }

        documentSectionRepository.deleteById(id);

        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    public ResponseEntity<DocumentSectionResponseDto> updateSection(Long id, DocumentSectionRequest request){
        return documentSectionRepository.findById(id)
                .map(existingSection -> {
                    if (existingSection.isDeleted()) {
                        return new ResponseEntity<DocumentSectionResponseDto>(HttpStatus.NOT_FOUND);
                    }
                    // 2. Validate new name is not empty
                    if (request.getSectionName() == null || request.getSectionName().isBlank()) {
                        return new ResponseEntity<DocumentSectionResponseDto>(HttpStatus.BAD_REQUEST);
                    }

                    // 3. Check for name conflict (unique constraint)
                    Optional<DocumentSection> conflict = documentSectionRepository
                            .findBySectionNameIgnoreCaseAndIsDeletedFalse(request.getSectionName());

                    if (conflict.isPresent() && !conflict.get().getId().equals(id)) {
                        return new ResponseEntity<DocumentSectionResponseDto>(HttpStatus.CONFLICT);
                    }

                    // 4. Update and Save
                    existingSection.setSectionName(request.getSectionName());
                    DocumentSection updated = documentSectionRepository.save(existingSection);

                    return ResponseEntity.ok(new DocumentSectionResponseDto(updated.getId(), updated.getSectionName()));
                })
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }




//    private String extractFileNameWithoutPath(String originalFilename) {
//        String name = originalFilename;
//        int lastSlash = Math.max(name.lastIndexOf('/'), name.lastIndexOf('\\'));
//        if (lastSlash != -1) name = name.substring(lastSlash + 1);
//        return name;
//    }
}
