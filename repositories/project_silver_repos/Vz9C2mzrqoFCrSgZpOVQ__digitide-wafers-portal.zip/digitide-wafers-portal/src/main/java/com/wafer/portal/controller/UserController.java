//package com.wafer.portal.controller;
//
//import com.wafer.portal.config.JwtTokenProvider;
//import com.wafer.portal.dto.SamlUserAttributes;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.core.Authentication;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.saml2.provider.service.authentication.DefaultSaml2AuthenticatedPrincipal;
//import org.springframework.security.saml2.provider.service.authentication.Saml2Authentication;
//import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//@RestController
//@RequestMapping("/api/v1/user")
//public class UserController {
//
//    private static final Logger logger = LoggerFactory.getLogger(UserController.class);
//
//    @Autowired
//    private JwtTokenProvider jwtTokenProvider;
//
//    @GetMapping("/profile")
//    public SamlUserAttributes getProfile(Authentication authentication) {
//        logger.info("=== UserController.getProfile() called ===");
//        logger.info("Authentication type: {}", authentication != null ? authentication.getClass().getSimpleName() : "null");
//        logger.info("Authentication principal: {}", authentication != null ? authentication.getPrincipal() : "null");
//        logger.info("Is authenticated: {}", authentication != null ? authentication.isAuthenticated() : "null");
//        logger.info("Authorities: {}", authentication != null ? authentication.getAuthorities() : "null");
//
//        if (authentication == null) {
//            logger.error("Authentication is null");
//            throw new RuntimeException("User not authenticated - no authentication object");
//        }
//
//        // Handle SAML Authentication
//        if (authentication instanceof Saml2Authentication samlAuth) {
//            logger.info("Processing SAML authentication");
//            DefaultSaml2AuthenticatedPrincipal principal = (DefaultSaml2AuthenticatedPrincipal) samlAuth.getPrincipal();
//
//            SamlUserAttributes dto = new SamlUserAttributes();
//            dto.setEmail(principal.getFirstAttribute("http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress"));
//            dto.setFirstName(principal.getFirstAttribute("http://schemas.xmlsoap.org/ws/2005/05/identity/claims/givenname"));
//            dto.setLastName(principal.getFirstAttribute("http://schemas.xmlsoap.org/ws/2005/05/identity/claims/surname"));
//            dto.setDisplayName(principal.getFirstAttribute("http://schemas.microsoft.com/identity/claims/displayname"));
//            dto.setDesignation(principal.getFirstAttribute("http://schemas.xmlsoap.org/ws/2005/05/identity/claims/Employee Designation"));
//
//            logger.info("SAML user profile created: {}", dto.getEmail());
//            return dto;
//        }
//
//        // Handle JWT Authentication (UsernamePasswordAuthenticationToken)
//        else if (authentication instanceof UsernamePasswordAuthenticationToken jwtAuth) {
//            logger.info("Processing JWT authentication");
//
//            Object principal = jwtAuth.getPrincipal();
//            String username = null;
//
//            if (principal instanceof UserDetails userDetails) {
//                username = userDetails.getUsername();
//                logger.info("Username from UserDetails: {}", username);
//            } else if (principal instanceof String) {
//                username = (String) principal;
//                logger.info("Username from String principal: {}", username);
//            } else {
//                logger.error("Unknown principal type: {}", principal.getClass());
//                throw new RuntimeException("Unknown principal type in JWT authentication");
//            }
//
//            // Extract token from authentication details (or from request header)
//            String token = (String) jwtAuth.getCredentials(); // assuming credentials store the JWT string
//
//
//            String designation = null;
//            if (token != null) {
//                designation = jwtTokenProvider.getClaim(token, "designation"); // read from JWT
//                logger.info("Designation from JWT claims: {}", designation);
//            }
//
//            // For JWT authentication, we need to create a basic profile
//            // You might want to fetch user details from database here
//            SamlUserAttributes dto = new SamlUserAttributes();
//            dto.setEmail(username); // Assuming username is email
//            dto.setDisplayName(username);
//            dto.setDesignation(designation);
//
//
//            // You can extend this to fetch more user details from your database
//            // based on the username/email
//            logger.info("JWT user profile created for: {}", username);
//            return dto;
//        }
//
//        // Handle other authentication types
//        else {
//            logger.error("Unsupported authentication type: {}", authentication.getClass().getSimpleName());
//            logger.error("Expected: Saml2Authentication or UsernamePasswordAuthenticationToken");
//            throw new RuntimeException("Unsupported authentication type: " + authentication.getClass().getSimpleName());
//        }
//    }
//}


package com.wafer.portal.controller;

import com.wafer.portal.config.JwtTokenProvider;
import com.wafer.portal.dto.SamlUserAttributes;
import com.wafer.portal.model.Roles;
import com.wafer.portal.model.User;
import com.wafer.portal.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.saml2.provider.service.authentication.DefaultSaml2AuthenticatedPrincipal;
import org.springframework.security.saml2.provider.service.authentication.Saml2Authentication;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/user")
public class UserController {

    private static final Logger logger = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private JwtTokenProvider jwtTokenProvider;

    @Autowired
    private UserRepository userRepository;

    @GetMapping("/profile")
    public SamlUserAttributes getProfile(@CookieValue(value = "JWT_TOKEN", required = false) String jwtCookie,
                                         @RequestHeader(value = "Authorization", required = false) String authHeader) {
        logger.info("=== UserController.getProfile() called ===");

        String token = null;

        // 1. Try Authorization header
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            token = authHeader.substring(7);
            logger.info("Token extracted from Authorization header");
        }

        // 2. Fallback to JWT cookie
        if (token == null && jwtCookie != null) {
            token = jwtCookie;
            logger.info("Token extracted from Cookie");
        }

        if (token == null) {
            throw new RuntimeException("No JWT token found");
        }

        if (!jwtTokenProvider.validateToken(token)) {
            throw new RuntimeException("Invalid JWT token");
        }

        // 🔹 Extract all claims
        SamlUserAttributes dto = new SamlUserAttributes();
        dto.setEmail(jwtTokenProvider.getClaim(token, "email"));
        dto.setFirstName(jwtTokenProvider.getClaim(token, "firstName"));
        dto.setLastName(jwtTokenProvider.getClaim(token, "lastName"));
        dto.setDisplayName(jwtTokenProvider.getClaim(token, "displayName"));
        dto.setDesignation(jwtTokenProvider.getClaim(token, "designation"));
        dto.setEmployeeId(jwtTokenProvider.getClaim(token, "employeeId"));
        //dto.setGroups(jwtTokenProvider.getClaim(token, "groups"));

        String displayName = dto.getDisplayName();
        if (displayName != null && displayName.contains("@")) {
            String employeeId = displayName.substring(0, displayName.indexOf("@"));
            dto.setEmployeeId(employeeId);
        } else {
            dto.setEmployeeId(null);
        }

        User user = null;

        if (dto.getEmployeeId() != null) {
            user = userRepository.findByEmployeeId(dto.getEmployeeId()).orElse(null);
        }

        if (user == null && dto.getEmail() != null) {
            user = userRepository.findByEmail(dto.getEmail()).orElse(null);
        }

        if (user == null && dto.getFirstName() != null && dto.getLastName() != null) {
            String fullName = dto.getFirstName() + " " + dto.getLastName();
            user = userRepository.findByUserNameAndIsDeletedFalse(fullName).orElse(null);
        }

        if (user != null) {
            // ✅ Found user → set roles
            List<String> roleNames = user.getRoles()
                    .stream()
                    .map(Roles::getName) // assuming Roles entity has getName()
                    .collect(Collectors.toList());

            dto.setRoles(roleNames);
        } else {
            // ✅ User not found → set roles as null (or you could use empty list)
            dto.setRoles(null);
        }

        logger.info("JWT user profile reconstructed - {}", dto);
        return dto;
    }


    private String extractUsername(Object principal) {
        if (principal instanceof UserDetails userDetails) {
            logger.info("Username from UserDetails: {}", userDetails.getUsername());
            return userDetails.getUsername();
        } else if (principal instanceof String) {
            logger.info("Username from String principal: {}", principal);
            return (String) principal;
        } else {
            logger.error("Unknown principal type: {}", principal != null ? principal.getClass() : "null");
            throw new RuntimeException("Unknown principal type in JWT authentication");
        }
    }

    private String extractJwtToken(UsernamePasswordAuthenticationToken jwtAuth, String authHeader) {
        String token = null;

        // Method 1: Try to get token from Authorization header
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            token = authHeader.substring(7);
            logger.info("Token extracted from Authorization header");
        }

        // Method 2: Fallback to credentials (if token is stored there)
        if (token == null) {
            token = (String) jwtAuth.getCredentials();
            if (token != null) {
                logger.info("Token extracted from authentication credentials");
            }
        }

        if (token == null) {
            logger.warn("No JWT token found in either Authorization header or authentication credentials");
        }

        return token;
    }
}