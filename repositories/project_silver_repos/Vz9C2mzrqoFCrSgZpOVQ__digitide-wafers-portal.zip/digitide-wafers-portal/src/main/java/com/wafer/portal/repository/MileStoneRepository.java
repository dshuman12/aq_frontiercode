package com.wafer.portal.repository;

import com.wafer.portal.model.MileStone;
import com.wafer.portal.model.People;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface MileStoneRepository extends JpaRepository<MileStone, Long> {
    Page<MileStone> findByIsDeletedFalse(Pageable pageable);
    Optional<MileStone> findByIdAndIsDeletedFalse(Long aLong);


    @Query("SELECT s FROM MileStone s WHERE s.isDeleted = false ORDER BY " +
            "CASE WHEN s.sequence IS NULL THEN 1 ELSE 0 END, s.sequence ASC")
    Page<MileStone> findAllOrderedBySequence(Pageable pageable);

    @Query("SELECT m FROM MileStone m WHERE m.isDeleted = false AND " +
            "LOWER(m.content) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    Page<MileStone> searchMilestones(@Param("keyword") String keyword, Pageable pageable);

}
