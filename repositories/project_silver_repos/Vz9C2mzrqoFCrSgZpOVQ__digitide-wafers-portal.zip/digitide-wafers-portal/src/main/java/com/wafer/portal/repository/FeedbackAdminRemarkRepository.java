package com.wafer.portal.repository;

import com.wafer.portal.model.FeedbackAdminRemark;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FeedbackAdminRemarkRepository extends JpaRepository<FeedbackAdminRemark, Long> {

    List<FeedbackAdminRemark> findByFeedbackIdOrderByCreatedDateDesc(Long feedbackId);
}
