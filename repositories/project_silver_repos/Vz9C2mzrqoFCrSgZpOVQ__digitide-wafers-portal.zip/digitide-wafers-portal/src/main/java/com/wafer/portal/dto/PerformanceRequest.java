package com.wafer.portal.dto;

public class PerformanceRequest {

    private String trackingId;
    private String pageName;
    private Integer pageLoadTimeMs;
    private String browser;
    private String deviceType;
    private String os;

    public String getTrackingId() { return trackingId; }

    public void setTrackingId(String trackingId) { this.trackingId = trackingId; }

    public String getPageName() { return pageName; }

    public void setPageName(String pageName) { this.pageName = pageName; }

    public Integer getPageLoadTimeMs() { return pageLoadTimeMs; }

    public void setPageLoadTimeMs(Integer pageLoadTimeMs) { this.pageLoadTimeMs = pageLoadTimeMs; }

    public String getBrowser() { return browser; }

    public void setBrowser(String browser) { this.browser = browser; }

    public String getDeviceType() { return deviceType; }

    public void setDeviceType(String deviceType) { this.deviceType = deviceType; }

    public String getOs() { return os; }

    public void setOs(String os) { this.os = os; }
}