package com.wafer.portal.model;

import com.wafer.portal.audit.Auditable;
import jakarta.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "rewards_section")
public class RewardsSection extends Auditable<String> implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String sectionName;
    private boolean isDeleted = false;

    public RewardsSection() {
    }

    public RewardsSection(Long id, String sectionName, boolean isDeleted) {
        this.id = id;
        this.sectionName = sectionName;
        this.isDeleted = isDeleted;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSectionName() {
        return sectionName;
    }

    public void setSectionName(String sectionName) {
        this.sectionName = sectionName;
    }

    public boolean isDeleted() {
        return isDeleted;
    }

    public void setDeleted(boolean deleted) {
        isDeleted = deleted;
    }
}
