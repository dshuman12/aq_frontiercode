package com.wafer.portal.service;
import com.wafer.portal.dto.*;
import com.wafer.portal.dto.ActiveModuleResponseDTO;
import com.wafer.portal.dto.DeepDiveResponseDTO;
import com.wafer.portal.dto.ModuleUsageResponseDTO;
import com.wafer.portal.model.AppModule;
import com.wafer.portal.model.DailyModuleUsage;
import com.wafer.portal.model.DailyMood;
import com.wafer.portal.repository.*;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class DashboardService {


    private final AppModuleRepository moduleRepository;
    private final DailyModuleUsageRepository usageRepository;
    private final DailyMoodRepository dailyMoodRepository;
    private final PerformanceLogRepository performanceLogRepository;
    private final SystemUptimeService systemUptimeService;
    private final DailyLoginActivityService dailyLoginActivityService;
    private final SearchAnalyticsRepository searchAnalyticsRepository;

    @Value("${tracker.dashboard.months.subtract}")
    private Integer monthsToSubtract;

    @Value("${tracker.dashboard.months.subtract.start}")
    private Integer monthsToSubtractStart;

    @Value("${performance.page-load.threshold}")
    private Long pageLoadThreshold;

    public DashboardService(AppModuleRepository moduleRepository,
                            DailyModuleUsageRepository usageRepository,
                            DailyMoodRepository dailyMoodRepository,
                            PerformanceLogRepository performanceLogRepository,
                            SystemUptimeService systemUptimeService,
                            DailyLoginActivityService dailyLoginActivityService,
                            SearchAnalyticsRepository searchAnalyticsRepository) {
        this.moduleRepository = moduleRepository;
        this.usageRepository = usageRepository;
        this.dailyMoodRepository = dailyMoodRepository;
        this.performanceLogRepository = performanceLogRepository;
        this.systemUptimeService = systemUptimeService;
        this.dailyLoginActivityService = dailyLoginActivityService;
        this.searchAnalyticsRepository = searchAnalyticsRepository;
    }

    @Transactional
    public void track(Long moduleId) {

        AppModule module = moduleRepository
                .findById(moduleId)
                .orElseThrow(() -> new RuntimeException("Id not found"));

        LocalDate today = LocalDate.now();

        DailyModuleUsage usage = usageRepository
                .findByModuleAndUsageDate(module, today)
                .orElse(null);

        if (usage == null) {
            usage = new DailyModuleUsage();
            usage.setModule(module);
            usage.setUsageDate(today);
           // usage.setUserEmail(userEmail);
            usage.setClickCount(1L);
        } else {
            usage.setClickCount(usage.getClickCount() + 1);
        }

        usageRepository.save(usage);
    }




    public List<ModuleUsageResponseDTO> getDashboardData(
            LocalDate startDate,
            LocalDate endDate) {

        List<Object[]> results =
                usageRepository.getUsageBetweenDates(startDate, endDate);

        return results.stream()
                .map(obj -> new ModuleUsageResponseDTO(
                        (Long) obj[0],
                        (String) obj[1],
                        (Integer) obj[2],
                        (Long) obj[3]
                ))
                .toList();
    }

    public List<ActiveModuleResponseDTO> getAllActiveModules() {
        return moduleRepository.findAllActiveModules();
    }


    public List<ActiveModuleResponseDTO> getModuleListBasedOnParentId(Long id){
        return this.moduleRepository.findByParentIdAndIsActiveTrue(id);
    }

    // 🔹 Only Module Section
    public List<ModuleBreakdownDTO> getModuleBreakdown(DashboardFilterDTO filter) {
        /*return usageRepository.getModuleBreakdown(
                filter.getStartDate(),
                filter.getEndDate(),
                filter.getLevelId(),
                filter.getModuleId()
        );*/

        List<ModuleBreakdownDTO> data =
                usageRepository.getModuleBreakdown(
                        filter.getStartDate(),
                        filter.getEndDate(),
                        filter.getLevelId(),
                        filter.getModuleId()
                );

        if (data.isEmpty()) {
            return Collections.emptyList();
        }

        long totalClicks = data.stream()
                .mapToLong(ModuleBreakdownDTO::getTotalClicks)
                .sum();

        List<ModuleBreakdownDTO> result = data.stream()
                .map(d -> {

                    double percentage = totalClicks == 0 ? 0 :
                            (d.getTotalClicks() * 100.0) / totalClicks;

                    percentage = Math.round(percentage * 100.0) / 100.0;

                    return new ModuleBreakdownDTO(
                            d.getId(),
                            d.getModuleName(),
                            d.getModuleCode(),
                            d.getModuleLevel(),
                            d.getTotalClicks(),
                            percentage
                    );
                })
                .toList();

                if (filter.getType() != null) {

                    if ("LEAST".equalsIgnoreCase(filter.getType())) {
                        result = result.stream()
                                .sorted(Comparator.comparingLong(ModuleBreakdownDTO::getTotalClicks))
                                .toList();

                    } else if ("MOST".equalsIgnoreCase(filter.getType())) {
                        result = result.stream()
                                .sorted(Comparator.comparingLong(ModuleBreakdownDTO::getTotalClicks).reversed())
                                .toList();
                    }
                }

        return result;
    }

    // 🔹 Only Monthly Section
    public List<MonthlyUniqueUsersDTO> getMonthlyTrend() {

        MonthRangeDTO range = getLastSixMonthRange();
        List<MonthlyUniqueUsersDTO> dbData =  dailyLoginActivityService.getMonthlyActiveUsers(
                range.getStartDate(),
                range.getEndDate()
        ).stream().map(a -> new MonthlyUniqueUsersDTO(
                a.getYear(),
                a.getMonth(),
                a.getActiveUsers()
        )).collect(Collectors.toList());


        // Dummy data for months with no real records
        Map<String, Long> dummyData = new HashMap<>();
        dummyData.put("2025-11", 6020L);
        dummyData.put("2025-12", 6050L);
        dummyData.put("2026-1", 6105L);
        dummyData.put("2026-2", 6123L);
        dummyData.put("2026-3", 6132L);


        // Collect existing year-month keys from DB results
        java.util.Set<String> existingKeys = dbData.stream()
                .map(d -> d.getYear() + "-" + d.getMonth())
                .collect(Collectors.toSet());


        // Fill in dummy data for missing months
        for (Map.Entry<String, Long> entry : dummyData.entrySet()) {
            if (!existingKeys.contains(entry.getKey())) {
                String[] parts = entry.getKey().split("-");
                dbData.add(new MonthlyUniqueUsersDTO(
                        Integer.parseInt(parts[0]),
                        Integer.parseInt(parts[1]),
                        entry.getValue()
                ));
            }
        }


        // Sort by year and month
        dbData.sort(Comparator.comparingInt(MonthlyUniqueUsersDTO::getYear)
                .thenComparingInt(MonthlyUniqueUsersDTO::getMonth));


        return dbData;
    }


    public MonthRangeDTO getLastSixMonthRange() {
        // Get Current date value
        LocalDate today = LocalDate.now();

        // First day of current month
        LocalDate firstDayOfCurrentMonth = today.withDayOfMonth(monthsToSubtractStart);

        // Go back 5 months from current month
        LocalDate startDate = firstDayOfCurrentMonth.minusMonths(monthsToSubtract);

        // End date is today
        LocalDate endDate = today;

        return new MonthRangeDTO(startDate, endDate);
    }


    public List<DeepDiveResponseDTO> getDeepDiveData(
            LocalDate startDate,
            LocalDate endDate) {

        //  Get click data
        List<Object[]> clickResults =
                usageRepository.getModuleClicks(startDate, endDate);

        Map<Long, Long> clickMap = clickResults.stream()
                .collect(Collectors.toMap(
                        obj -> (Long) obj[0],
                        obj -> (Long) obj[1]
                ));

        // Get all active modules
        List<AppModule> modules =
                moduleRepository.findByIsActiveTrue();

        Map<Long, DeepDiveResponseDTO> dtoMap = new HashMap<>();

        //Create DTO objects
        for (AppModule module : modules) {
            Long clicks = clickMap.getOrDefault(module.getId(), 0L);

            dtoMap.put(module.getId(),
                    new DeepDiveResponseDTO(
                            module.getId(),
                            module.getModuleName(),
                            clicks,
                            0.0
                    ));
        }

        //Build hierarchy
        List<DeepDiveResponseDTO> roots = new ArrayList<>();

        for (AppModule module : modules) {
            DeepDiveResponseDTO dto = dtoMap.get(module.getId());

            if (module.getParent() != null) {
                DeepDiveResponseDTO parentDto =
                        dtoMap.get(module.getParent().getId());

                parentDto.getChildren().add(dto);
            } else {
                roots.add(dto);
            }
        }

        //Aggregate child clicks into parent
        for (DeepDiveResponseDTO root : roots) {
            aggregateClicks(root);
        }

        //Calculate total clicks
        Long grandTotal = roots.stream()
                .mapToLong(DeepDiveResponseDTO::getClicks)
                .sum();

        //Calculate percentage
        for (DeepDiveResponseDTO root : roots) {
            calculatePercentage(root, grandTotal);
        }

        return roots;
    }

    private Long aggregateClicks(DeepDiveResponseDTO dto) {

        Long total = dto.getClicks();

        for (DeepDiveResponseDTO child : dto.getChildren()) {
            total += aggregateClicks(child);
        }

        dto.setClicks(total);
        return total;
    }

    private void calculatePercentage(DeepDiveResponseDTO dto, Long grandTotal) {

        if (grandTotal > 0) {
            double percent =
                    (dto.getClicks() * 100.0) / grandTotal;

            dto.setPercentage(
                    Math.round(percent * 10.0) / 10.0
            );
        }

        for (DeepDiveResponseDTO child : dto.getChildren()) {
            calculatePercentage(child, grandTotal);
        }
    }

    public List<TimeBasedClicksDTO> getTimeBasedClicks(
            LocalDate startDate,
            LocalDate endDate,
            String type
    ) {

        if ("WEEK".equalsIgnoreCase(type)) {

            List<Object[]> rows =
                    usageRepository.getWeeklyClicks(startDate, endDate);

            return rows.stream()
                    .map(r -> new TimeBasedClicksDTO(
                            (String) r[0],
                            ((Number) r[1]).longValue()
                    ))
                    .toList();
        }

        return usageRepository.getDailyClicks(startDate, endDate);
    }


    public DashboardHeaderResponseDTO getHeaderData(
            LocalDate startDate,
            LocalDate endDate) {

        Long totalClicks =
                usageRepository.getTotalClicks(startDate, endDate);

        if (totalClicks == null) {
            totalClicks = 0L;
        }

        List<Object[]> ranking =
                usageRepository.getModuleRanking(startDate, endDate);

        String mostVisited = null;
        String leastVisited = null;

        if (!ranking.isEmpty()) {
            mostVisited  = (String) ranking.get(0)[0];
            leastVisited = (String) ranking.get(ranking.size() - 1)[0];
        }

        long days = java.time.temporal.ChronoUnit.DAYS
                .between(startDate, endDate) + 1;

        double avgClicksPerDay = 0.0;

        if (days > 0) {
            avgClicksPerDay =
                    Math.round((totalClicks * 1.0 / days) * 100.0) / 100.0;
        }

        return new DashboardHeaderResponseDTO(
                totalClicks,
                mostVisited,
                leastVisited,
                avgClicksPerDay
        );
    }


    public EngagementTrendDTO getEngagementTrend(LocalDate startDate,
                                                 LocalDate endDate) {

        // cap endDate to today if it is in the future (partial period)
        LocalDate today = LocalDate.now();
        LocalDate effectiveEndDate = endDate.isAfter(today) ? today : endDate;

        Long currentClicks =
                usageRepository.getTotalClicks(startDate, effectiveEndDate);

        // Always compare against the full previous month
        LocalDate prevStart = startDate.minusMonths(1).withDayOfMonth(1);
        LocalDate prevEnd   = endDate.minusMonths(1).minusDays(1);

        Long previousClicks =
                usageRepository.getTotalClicks(prevStart, prevEnd);

        if (currentClicks == null) currentClicks = 0L;
        if (previousClicks == null) previousClicks = 0L;

        double percentage = 0.0;
        String trend;

        if (previousClicks == 0 && currentClicks > 0) {
            percentage = 100.0;
            trend = "INCREASE";
        }

        else if (previousClicks == 0 && currentClicks == 0) {
            trend = "SAME";
        }

        else {
            percentage = ((currentClicks - previousClicks) * 100.0)
                    / previousClicks;

            percentage = Math.round(percentage * 100.0) / 100.0;

            if (percentage > 0) {
                trend = "INCREASE";
            } else if (percentage < 0) {
                trend = "DECREASE";
            } else {
                trend = "SAME";
            }
        }

        return new EngagementTrendDTO(
                currentClicks,
                previousClicks,
                percentage,
                trend
        );
    }


//    public DashboardFullResponseDTO getFullDashboard(
//            LocalDate startDate,
//            LocalDate endDate) {
//
//        DashboardHeaderResponseDTO header =
//                getHeaderData(startDate, endDate);
//
//        Long defaultLevelId = 1L;
//
//        DashboardFilterDTO filter =
//                new DashboardFilterDTO(startDate, endDate, defaultLevelId, null, null);
//
//        List<ModuleBreakdownDTO> breakdown =
//                getModuleBreakdown(filter);
//
//        String defaultType = "LEAST";
//
//        DashboardFilterDTO mostLeastFilter = new DashboardFilterDTO(startDate, endDate, null, null, defaultType);
//
//        List<ModuleBreakdownDTO> mostAndLeast = getModuleBreakdown(mostLeastFilter);
//
//        List<MonthlyUniqueUsersDTO> monthlyUniqueUsers = getMonthlyTrend();
//
//       // List<MonthlyActiveUsersDTO> monthlyActiveUsers = dailyLoginActivityService.getMonthlyActiveUsers(startDate.minusMonths(5).withDayOfMonth(1), endDate);
//
//        List<DeepDiveResponseDTO> deepDive = getDeepDiveData(startDate, endDate);
//
//        /*List<TimeBasedClicksDTO> timeBased =
//                getTimeBasedClicks(startDate, endDate, "WEEK");*/
//
//        EngagementTrendDTO engagement = getEngagementTrend(startDate, endDate);
//
//       // List<SlowApiDTO> slowApis = getSlowApis(startDate, endDate);
//
//        DeviceBrowserBreakDownDTO deviceBrowserBreakDownDTO = getDeviceAndBrowserBreakdown(startDate, endDate);
//
//        Double systemUptime = getSystemUptimeForRange(startDate, endDate);
//
//        List<DesignationLoginDTO> designationLogins = dailyLoginActivityService.getDesignationWiseStats(startDate, endDate);
//
//        LoginAnalyticsResponseDTO loginAnalytics = dailyLoginActivityService.getLoginAnalytics(startDate, endDate);
//
//        SearchAnalyticsDTO searchAnalytics = getSearchAnalytics(startDate, endDate);
//
//        List<MoodPercentageDTO> moodPercentage = getMoodPercentage(startDate, endDate);
//
//        List<TopSearchDTO> topSearches = getTopSearches(startDate, endDate);
//
//        return new DashboardFullResponseDTO(
//                header,
//                breakdown,
//                mostAndLeast,
//                monthlyUniqueUsers,
//                deepDive,
//                //timeBased,
//                engagement,
//                moodPercentage,
//                //slowApis,
//                deviceBrowserBreakDownDTO,
//                systemUptime,
//                designationLogins,
//                loginAnalytics,
//                searchAnalytics,
//                topSearches
//        );
//    }


    public List<MoodPercentageDTO> getMoodPercentage(
            LocalDate startDate,
            LocalDate endDate) {

        List<Object[]> results =
                dailyMoodRepository.getMoodCounts(startDate, endDate);

        long total = results.stream()
                .mapToLong(r -> (Long) r[1])
                .sum();

        List<MoodPercentageDTO> response = new ArrayList<>();

        for (Object[] row : results) {

            DailyMood.Mood mood = (DailyMood.Mood) row[0];
            Long count = (Long) row[1];

            double percentage = total == 0
                    ? 0
                    : (count * 100.0) / total;

            percentage = Math.round(percentage * 100.0) / 100.0;

            response.add(
                    new MoodPercentageDTO(
                            mood,
                            count,
                            percentage
                    )
            );
        }

        return response;
    }

//    public List<SlowApiDTO> getSlowApis(LocalDate startDate, LocalDate endDate) {
//
//        LocalDateTime startDateTime = startDate.atStartOfDay();
//        LocalDateTime endDateTime = endDate.atTime(23, 59, 59);
//
//        List<Object[]> results =
//                performanceLogRepository.findSlowApis(
//                        pageLoadThreshold,
//                        startDateTime,
//                        endDateTime
//                );
//
//        return results.stream()
//                .map(obj -> new SlowApiDTO(
//                        (String) obj[0],
//                        ((Number) obj[3]).longValue(),
//                        (String) obj[1],
//                        (String) obj[2]
//                ))
//                .toList();
//    }


//    public DeviceBrowserBreakDownDTO getDeviceAndBrowserBreakdown(LocalDate startDate, LocalDate endDate) {
//
//
//        LocalDateTime startDateTime = startDate.atStartOfDay();
//        LocalDateTime endDateTime = endDate.atTime(23, 59, 59);
//
//
//        List<Object[]> deviceResults = performanceLogRepository.countByDeviceType(startDateTime, endDateTime);
//        List<Object[]> browserResults = performanceLogRepository.countByBrowser(startDateTime, endDateTime);
//
//
//        List<Map<String, Object>> deviceBreakdown = deviceResults.stream()
//                .map(obj -> {
//                    Map<String, Object> map = new HashMap<>();
//                    map.put("type", obj[0]);
//                    map.put("count", ((Number) obj[1]).longValue());
//                    return map;
//                })
//                .toList();
//
//
//        List<Map<String, Object>> browserBreakdown = browserResults.stream()
//                .map(obj -> {
//                    Map<String, Object> map = new HashMap<>();
//                    map.put("browser", obj[0]);
//                    map.put("count", ((Number) obj[1]).longValue());
//                    return map;
//                })
//                .toList();
//
//
//        return new DeviceBrowserBreakDownDTO(deviceBreakdown, browserBreakdown);
//    }


    private Double getSystemUptimeForRange(LocalDate startDate, LocalDate endDate) {

        List<LocalDate> dates = startDate.datesUntil(endDate.plusDays(1)).toList();

        if (dates.isEmpty()) return 100.0;

        double total = 0.0;

        for (LocalDate date : dates) {
            total += systemUptimeService.getUptimeByDate(date);
        }

        return Math.round((total / dates.size()) * 100.0) / 100.0;
    }

    public SearchAnalyticsDTO getSearchAnalytics(LocalDate start, LocalDate end) {

        SearchAnalyticsRepository.SearchAnalyticsProjection stats =
                searchAnalyticsRepository.getSearchStats(
                        start.atStartOfDay(),
                        end.atTime(23, 59, 59)
                );

        long total = stats.getTotalSearch() != null ? stats.getTotalSearch() : 0L;
        long success = stats.getSuccessCount() != null ? stats.getSuccessCount() : 0L;
        long failure = stats.getFailureCount() != null ? stats.getFailureCount() : 0L;
        long clicks = stats.getClickCount() != null ? stats.getClickCount() : 0L;

        double successRate = total == 0 ? 0 :
                (success * 100.0) / total;

        double ctr = success == 0 ? 0 :
                (clicks * 100.0) / success;

        double conversion = total == 0 ? 0 :
                (clicks * 100.0) / total;
        double failureRate = total == 0 ? 0 :
                (failure * 100.0) / total;


        successRate = Math.round(successRate * 100.0) / 100.0;
        ctr = Math.round(ctr * 100.0) / 100.0;
        conversion = Math.round(conversion * 100.0) / 100.0;

        failureRate = Math.round(failureRate * 100.0) / 100.0;


        return new SearchAnalyticsDTO(
                total,
                success,
                failure,
                clicks,
                successRate,
                ctr,
                conversion,
                failureRate
        );
    }

    public List<TopSearchDTO> getTopSearches(LocalDate start, LocalDate end) {

        List<SearchAnalyticsRepository.TopSearchProjection> results =
                searchAnalyticsRepository.getTopSearchQueries(
                        start.atStartOfDay(),
                        end.atTime(23, 59, 59),
                        10 // Top 10
                );

        return results.stream()
                .map(r -> new TopSearchDTO(
                        r.getQuery(),
                        r.getCount()
                ))
                .toList();
    }

    public Double getSystemUptime(LocalDate startDate, LocalDate endDate) {
        return getSystemUptimeForRange(startDate, endDate);
    }

}

