//package com.wafer.portal.utils;
//
//import com.fasterxml.jackson.core.JsonProcessingException;
//import com.fasterxml.jackson.core.type.TypeReference;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.fasterxml.jackson.databind.ObjectWriter;
//import jakarta.validation.ValidationException;
//import org.apache.commons.text.WordUtils;
//import org.springframework.data.domain.PageRequest;
//import org.springframework.data.domain.Pageable;
//import org.springframework.data.domain.Sort;
//import org.springframework.security.core.Authentication;
//import org.springframework.security.core.context.SecurityContextHolder;
//
//import java.math.BigDecimal;
//import java.sql.Date;
//import java.sql.Timestamp;
//import java.text.SimpleDateFormat;
//import java.time.LocalDate;
//import java.time.LocalDateTime;
//import java.time.format.DateTimeFormatter;
//import java.util.Collection;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//import java.util.stream.Collectors;
//
//import static com.wafer.portal.audit.GlobalExceptionHandler.ERR_MSG;
//
//public class Utils {
//
//    private Utils() {
//    }
//
//
//    public static Pageable getPageable(int pageNo, int pageSize) {
//        return PageRequest.of(pageNo, pageSize);
//    }
//
//
//    public static Pageable getPageable(int pageNo, int pageSize, String sortDir, String sortBy) {
//        Sort sort = sortDir.equalsIgnoreCase(Sort.Direction.ASC.name()) ?
//                Sort.by(sortBy).ascending() : Sort.by(sortBy).descending();
//        return PageRequest.of(pageNo, pageSize, sort);
//    }
//
//    public static boolean isEmpty(Collection<?> collection) {
//        return (collection == null || collection.isEmpty());
//    }
//
//    public static boolean isEmpty(String value) {
//        return (value == null || value.trim().isEmpty());
//    }
//
//    public static <T> String getAsString(List<T> invalidIds) {
//        return invalidIds.stream()
//                .map(Object::toString)
//                .collect(Collectors.joining(","));
//    }
//
//    public static String convertObjectToJsonText(Object object) {
//        String messageJson;
//        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
//        try {
//            messageJson = ow.writeValueAsString(object);
//        } catch (JsonProcessingException e) {
//            throw new ValidationException("Json Processing failed");
//        }
//        return messageJson;
//    }
//
//
//    public static String convertMapToJsonText(Map<String, String> errorMap) {
//        return convertObjectToJsonText(errorMap);
//    }
//
//
//    public static String convertMapToJsonText2(Map<String, Object> errorMap) {
//        return convertObjectToJsonText(errorMap);
//    }
//
//
//    public static Map<String, Object> getErrorMap(String errorMsg) {
//        ObjectMapper objectMapper = new ObjectMapper();
//        Map<String, Object> errorMap = new HashMap<>();
//        try {
//            Map<String, String> errorMapReceived = objectMapper.readValue(
//                    errorMsg,
//                    new TypeReference<Map<String, String>>() {
//                    });
//            errorMap.putAll(errorMapReceived);
//        } catch (JsonProcessingException e) {
//            errorMap.put(ERR_MSG, errorMsg);
//        }
//        return errorMap;
//    }
//
//
//    public static String dateToText(Date startDate) {
//        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
//        return formatter.format(startDate);
//    }
//
//
//
//
//    public static Integer getCurrentFinancialYear() {
//        LocalDateTime current = LocalDateTime.now();
//        /*Calendar cal=Calendar.getInstance();
//        cal.set(Calendar.MONTH,3);
//        cal.set(Calendar.DAY_OF_MONTH,1);
//        if(current.isBefore(LocalDateTime.ofInstant(cal.toInstant(), ZoneId.systemDefault()))){
//            return current.getYear()-1;
//        }*/
//        return current.getYear();
//    }
//
//
//    public static String capitalize(String value) {
//        return WordUtils.capitalize(value.toLowerCase());
//    }
//
//
//    public static String setContactNoWithCountryCode(String countryCode, String phoneNumber) {
//        return (countryCode.contains("+") ? "" : "+") + countryCode + phoneNumber;
//    }
//
//
//    public static LocalDateTime getCurrentDateTime() {
//        return LocalDateTime.now();
//    }
//
//
//    public static String generateS3KeyName(String fileName) {
//        fileName = fileName.replace(" ", "_");
//        fileName = fileName.replace(".", "_");
//        return fileName + "_" + getCurrentDateTime().format(DateTimeFormatter.ofPattern("yyyy_MM_dd_HH_mm_ss"));
//    }
//
//
//    public static String getFileExtension(String docName) {
//        return docName.substring(docName.lastIndexOf(".") + 1);
//    }
//
//
//
//
//    public static String formatNumber(long number) {
//        if (number >= 1_000_000_000) {
//            return String.format("%.1fB", number / 1_000_000_000.0);
//        } else if (number >= 1_000_000) {
//            return String.format("%.1fM", number / 1_000_000.0);
//        } else if (number >= 1_000) {
//            return String.format("%.1fK", number / 1_000.0);
//        } else {
//            return String.valueOf(number);
//        }
//    }
//
//
//
//
//
//    public static LocalDateTime getLocalDateTime(Timestamp timestamp) {
//        if (timestamp == null) {
//            return null;
//        }
//        return timestamp.toLocalDateTime();
//    }
//
//
//    public static LocalDate getLocalDate(String stringCellValue) {
//        if (stringCellValue == null) {
//            return null;
//        }
//        LocalDate date = null;
//        try {
//            date = LocalDate.parse(stringCellValue, DateTimeFormatter.ofPattern("dd-MM-yyyy"));
//        } catch (Exception e) {
//
//        }
//        return date;
//    }
//
//
//
//    public static boolean isValidDouble(String str) {
//        try {
//            Double.parseDouble(str);
//            return true; // The string can be parsed to a double
//        } catch (NumberFormatException e) {
//            return false; // The string cannot be parsed to a double
//        }
//    }
//
//    public static Long getLongValue(BigDecimal bigDecimal) {
//        if (bigDecimal == null) {
//            return null;
//        }
//        //return bigDecimal.setScale(0, RoundingMode.HALF_UP);
//        return bigDecimal.longValue();
//    }
//}
