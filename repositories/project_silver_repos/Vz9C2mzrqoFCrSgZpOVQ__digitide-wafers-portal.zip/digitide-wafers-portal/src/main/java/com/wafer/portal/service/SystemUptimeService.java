package com.wafer.portal.service;
import com.wafer.portal.dto.SystemUptimeRequest;
import com.wafer.portal.dto.SystemUptimeResponseDto;
import com.wafer.portal.model.SystemUptime;
import com.wafer.portal.repository.SystemUptimeRepository;
import org.springframework.stereotype.Service;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;

@Service
public class SystemUptimeService {

    private final SystemUptimeRepository repository;

    public SystemUptimeService(SystemUptimeRepository repository) {
        this.repository = repository;
    }

    public SystemUptimeResponseDto create(SystemUptimeRequest request) {

        if (request.getLogDate() == null) {
            throw new RuntimeException("Log date is required");
        }

        if (request.getLogStartTime() == null || request.getLogEndTime() == null) {
            throw new RuntimeException("Start and End time are required");
        }

        // Cross-midnight case → split into 2 rows
        if (request.getLogEndTime().isBefore(request.getLogStartTime())) {

            // Day 1 (start → midnight)
            SystemUptime day1 = new SystemUptime();
            day1.setLogDate(request.getLogDate());
            day1.setLogStartTime(request.getLogStartTime());
            // Day 1
            day1.setLogEndTime(LocalTime.MAX);

            long duration1 = Duration.between(
                    request.getLogStartTime(),
                    LocalTime.MAX
            ).getSeconds() + 1;

            day1.setDuration(duration1);
            repository.save(day1);

            // Day 2 (midnight → end)
            SystemUptime day2 = new SystemUptime();
            day2.setLogDate(request.getLogDate().plusDays(1));
            day2.setLogStartTime(LocalTime.MIDNIGHT);
            day2.setLogEndTime(request.getLogEndTime());

            long duration2 = Duration.between(
                    LocalTime.MIDNIGHT,
                    request.getLogEndTime()
            ).getSeconds();

            day2.setDuration(duration2);
            SystemUptime saved = repository.save(day2);

            double uptime = calculateUptimePercentage(saved.getLogDate());
            return mapToDto(saved, uptime);
        }

        // Normal case
        long duration = Duration.between(
                request.getLogStartTime(),
                request.getLogEndTime()
        ).getSeconds();

        SystemUptime entity = new SystemUptime();
        entity.setLogDate(request.getLogDate());
        entity.setLogStartTime(request.getLogStartTime());
        entity.setLogEndTime(request.getLogEndTime());
        entity.setDuration(duration);

        SystemUptime saved = repository.save(entity);

        double uptime = calculateUptimePercentage(saved.getLogDate());
        return mapToDto(saved, uptime);
    }

    public Double getUptimeByDate(LocalDate date) {
        return calculateUptimePercentage(date);
    }

    public List<SystemUptimeResponseDto> getAll() {

        List<SystemUptime> all = repository.findAll();

        //Avoid repeated DB calls
        Map<LocalDate, Double> uptimeCache = new HashMap<>();

        return all.stream()
                .map(e -> {
                    uptimeCache.putIfAbsent(
                            e.getLogDate(),
                            calculateUptimePercentage(e.getLogDate())
                    );
                    return mapToDto(e, uptimeCache.get(e.getLogDate()));
                })
                .toList();
    }

    // FINAL UPTIME LOGIC
    private double calculateUptimePercentage(LocalDate date) {

        List<SystemUptime> logs = repository.findByLogDate(date);

        if (logs.isEmpty()) {
            return 100.0;
        }

        //Convert logs → intervals (handle cross-midnight)
        List<long[]> intervals = logs.stream()
                .flatMap(log -> {
                    long start = log.getLogStartTime().toSecondOfDay();
                    long end = log.getLogEndTime().toSecondOfDay();

                    if (end < start) {
                        return List.of(
                                new long[]{start, 86400},
                                new long[]{0, end}
                        ).stream();
                    } else {
                        return List.of(new long[]{start, end}).stream();
                    }
                })
                .sorted(Comparator.comparingLong(a -> a[0]))
                .toList();

        long mergedDowntime = mergeIntervals(intervals);

        long totalSeconds = 86400;

        double uptime = ((double) (totalSeconds - mergedDowntime) / totalSeconds) * 100;

        return Math.max(uptime, 0);
    }

    //MERGE OVERLAPPING INTERVALS (FINAL)
    private long mergeIntervals(List<long[]> intervals) {

        if (intervals.isEmpty()) return 0;

        long total = 0;

        long start = intervals.get(0)[0];
        long end = intervals.get(0)[1];

        for (int i = 1; i < intervals.size(); i++) {

            long currStart = intervals.get(i)[0];
            long currEnd = intervals.get(i)[1];

            if (currStart <= end) {
                end = Math.max(end, currEnd);
            } else {
                total += (end - start);
                start = currStart;
                end = currEnd;
            }
        }

        total += (end - start);

        return total;
    }

    private SystemUptimeResponseDto mapToDto(SystemUptime e, double uptime) {
        return new SystemUptimeResponseDto(
                e.getId(),
                e.getLogDate(),
                e.getLogStartTime(),
                e.getLogEndTime(),
                e.getDuration(),
                uptime
        );
    }
}