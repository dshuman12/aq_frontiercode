package com.wafer.portal.service;

import com.wafer.portal.audit.impl.UserDetailsImpl;
import com.wafer.portal.dto.DailyMoodResponseDto;
import com.wafer.portal.dto.MoodSubmitRequest;
import com.wafer.portal.model.DailyMood;
import com.wafer.portal.model.User;
import com.wafer.portal.repository.DailyMoodRepository;
import com.wafer.portal.repository.UserRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class DailyMoodService {

    private final DailyMoodRepository dailyMoodRepository;
    private final UserRepository userRepository;

    @Autowired
    public DailyMoodService(DailyMoodRepository dailyMoodRepository, UserRepository userRepository) {
        this.dailyMoodRepository = dailyMoodRepository;
        this.userRepository = userRepository;
    }

    // returning only a specific loggedIn user mood history
    public ResponseEntity<?> logDailyMood(MoodSubmitRequest request, String currentUsername) {
        LocalDate today = LocalDate.now();
        if (dailyMoodRepository.findByCreatedByAndMoodDate(currentUsername, today).isPresent()) {
            return new ResponseEntity<>("Mood already logged for today by user: " + currentUsername, HttpStatus.CONFLICT);
        }


       // User user = userOptional.get();
        //UserDetailsImpl userDetails = (UserDetailsImpl) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        DailyMood dailyMood = new DailyMood(request.getMood());
        //dailyMood.setEmployeeId(userDetails.getEmployeeId());
       // dailyMood.setEmployeeId(user.getEmployeeId());
        DailyMood savedMood = dailyMoodRepository.save(dailyMood);

        return new ResponseEntity<>(mapToResponseDto(savedMood), HttpStatus.CREATED);
    }

    public ResponseEntity<List<DailyMoodResponseDto>> getUserMoodHistory(String currentUsername) {
        List<DailyMood> moodHistory = dailyMoodRepository.findByCreatedByOrderByCreationDateDesc(currentUsername);

        if (moodHistory.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }

        List<DailyMoodResponseDto> responseList = moodHistory.stream()
                .map(this::mapToResponseDto)
                .collect(Collectors.toList());

        return new ResponseEntity<>(responseList, HttpStatus.OK);
    }

    //Returning all users history
    public ResponseEntity<Page<DailyMoodResponseDto>> getAllUsersMoodHistory(Pageable pageable) {
        Page<DailyMood> moodHistory = dailyMoodRepository.findAllByOrderByCreationDateDesc(pageable);

        if (moodHistory.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }

        Page<DailyMoodResponseDto> responsePage = moodHistory
                .map(this::mapToResponseDto);

        return new ResponseEntity<>(responsePage, HttpStatus.OK);
    }


    // Returning only specific loggedIn user history
    public ResponseEntity<List<DailyMoodResponseDto>> getUserMoodHistoryByDateRange(
            String currentUsername,
            LocalDate startDate,
            LocalDate endDate) {

        java.time.LocalDateTime startDateTime = startDate.atStartOfDay();


        java.time.LocalDateTime endDateTime = endDate.plusDays(1).atStartOfDay();


        List<DailyMood> moodHistory = dailyMoodRepository.findByCreatedByAndCreationDateBetweenOrderByCreationDateDesc(
                currentUsername,
                startDateTime,
                endDateTime
        );

        if (moodHistory.isEmpty()) {
            return new ResponseEntity<>(List.of(), HttpStatus.OK);
        }

        List<DailyMoodResponseDto> responseList = moodHistory.stream()
                .map(this::mapToResponseDto)
                .collect(Collectors.toList());

        return new ResponseEntity<>(responseList, HttpStatus.OK);
    }

    //Returning all users history of specific dates
    public ResponseEntity<Page<DailyMoodResponseDto>> getAllUsersMoodHistoryByDateRange(
            LocalDate startDate,
            LocalDate endDate, Pageable pageable) {

        LocalDateTime startDateTime = startDate.atStartOfDay();
        LocalDateTime endDateTime = endDate.plusDays(1).atStartOfDay(); // inclusive

        Page<DailyMood> moodHistoryPage =
                dailyMoodRepository.findByCreationDateBetweenOrderByCreationDateDesc(
                        startDateTime,
                        endDateTime,
                        pageable
                );

        Page<DailyMoodResponseDto> responsePage = moodHistoryPage
                .map(this::mapToResponseDto);

        return new ResponseEntity<>(responsePage, HttpStatus.OK);
    }



    private DailyMoodResponseDto mapToResponseDto(DailyMood mood) {
        return new DailyMoodResponseDto(
                mood.getId(),
                mood.getCreatedBy(),
                mood.getMood(),
                mood.getCreationDate()
        );
    }
}