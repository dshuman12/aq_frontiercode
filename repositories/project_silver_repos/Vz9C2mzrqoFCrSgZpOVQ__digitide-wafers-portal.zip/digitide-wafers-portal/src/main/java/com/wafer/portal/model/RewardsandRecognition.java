package com.wafer.portal.model;

import com.wafer.portal.audit.Auditable;
import jakarta.persistence.*;

import java.io.Serializable;

@Entity
@Table(name = "rewards_and_recognition")
public class RewardsandRecognition extends Auditable<String> implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String designation; // New field
    private String description;
    private String image;
    private String location;
    private String nameOfAward;
    private Double sequence;
    @Column(name = "section_id")
    private Long sectionId;

    @Column(name = "subsection_id")
    private Long subsectionId;
    @Column(name = "is_deleted",nullable = false)
    private boolean isDeleted;

    public RewardsandRecognition() {
    }

    public RewardsandRecognition(String name, String designation, String description, String image, String location, String nameOfAward, Double sequence, Long sectionId, Long subsectionId) {
        this.name = name;
        this.designation = designation;
        this.description = description;
        this.image = image;
        this.location = location;
        this.nameOfAward = nameOfAward;
        this.sequence = sequence;
        this.sectionId = sectionId;
        this.subsectionId = subsectionId;
        this.isDeleted = false;
    }



    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getNameOfAward() {
        return nameOfAward;
    }

    public void setNameOfAward(String nameOfAward) {
        this.nameOfAward = nameOfAward;
    }

    public Double getSequence() {
        return sequence;
    }

    public void setSequence(Double sequence) {
        this.sequence = sequence;
    }

    public Long getSectionId() {
        return sectionId;
    }

    public void setSectionId(Long sectionId) {
        this.sectionId = sectionId;
    }

    public Long getSubsectionId() {
        return subsectionId;
    }

    public void setSubsectionId(Long subsectionId) {
        this.subsectionId = subsectionId;
    }

    public boolean isDeleted() {
        return isDeleted;
    }

    public void setDeleted(boolean deleted) {
        isDeleted = deleted;
    }
}