package com.wafer.portal.dto.response;


public class WhatsHappeningDTO {

    private Object announcements;
    private Object employeeSpotlight;
    private Object events;
    private Object milestones;
    private Object allNews;

    public Object getAnnouncements() {
        return announcements;
    }

    public void setAnnouncements(Object announcements) {
        this.announcements = announcements;
    }

    public Object getEmployeeSpotlight() {
        return employeeSpotlight;
    }

    public void setEmployeeSpotlight(Object employeeSpotlight) {
        this.employeeSpotlight = employeeSpotlight;
    }

    public Object getEvents() {
        return events;
    }

    public void setEvents(Object events) {
        this.events = events;
    }

    public Object getMilestones() {
        return milestones;
    }

    public void setMilestones(Object milestones) {
        this.milestones = milestones;
    }

    public Object getAllNews() {
        return allNews;
    }

    public void setAllNews(Object allNews) {
        this.allNews = allNews;
    }
}
