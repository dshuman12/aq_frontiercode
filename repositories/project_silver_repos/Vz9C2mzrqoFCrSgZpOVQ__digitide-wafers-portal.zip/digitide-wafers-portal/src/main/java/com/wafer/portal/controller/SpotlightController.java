package com.wafer.portal.controller;


import com.wafer.portal.annotation.TrackChange;
import com.wafer.portal.awsS3.S3Service;
import com.wafer.portal.dto.SpotLightResponseDto;
import com.wafer.portal.model.Spotlight;
import com.wafer.portal.service.SpotlightService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@RestController
@RequestMapping("/api/v1/spotlight")
public class SpotlightController {

    private static  final Logger logger =  LoggerFactory.getLogger(SpotlightController.class);

    private final SpotlightService spotlightService;
    private final S3Service s3Service;

    public SpotlightController(SpotlightService spotlightService, S3Service s3Service) {
        this.spotlightService = spotlightService;
        this.s3Service = s3Service;
    }

    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Added", section = "Spotlight")
    public ResponseEntity<SpotLightResponseDto> addSptlight(@RequestParam("title") String title,
                                             @RequestPart("video") MultipartFile video,
                                                            @RequestPart(name="thumbnail",  required=false) MultipartFile thumbnail,
                                             @RequestParam(name="url", required=false) String url,
                                             @RequestParam("sequence") Double sequence) {
        try {
            if (video.isEmpty()) {
                return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
            }
            String videoKey = s3Service.uploadFile(video, "spotlight-videos");
            String urlKey = null;

            if (thumbnail != null && !thumbnail.isEmpty()) {
                urlKey = s3Service.uploadFile(thumbnail, "Thumbnails");
            }
            Spotlight spotlight = new Spotlight(title, videoKey, urlKey, url, sequence);
            Spotlight savedSpotlight = spotlightService.saveSpotlight(spotlight);

            String preSignedUrl = s3Service.generatePresignedUrl(savedSpotlight.getVideo());
            String prePresignedUrl1 = null;

            if (savedSpotlight.getThumbnail() != null && !savedSpotlight.getThumbnail().isEmpty()) {
                prePresignedUrl1 = s3Service.generatePresignedUrl(savedSpotlight.getThumbnail());
            }
            SpotLightResponseDto responseDto = new SpotLightResponseDto(savedSpotlight.getId(), spotlight.getTitle(), preSignedUrl, prePresignedUrl1,spotlight.getUrl(), savedSpotlight.getSequence(), savedSpotlight.getCreatedBy(), savedSpotlight.getCreationDate(), savedSpotlight.getLastModifiedBy(), savedSpotlight.getLastModifiedDate());
            return new ResponseEntity<>(responseDto, HttpStatus.CREATED);
        } catch (IOException e) {
            logger.error("IoException occurred while uploading spotlight image", e);
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            logger.error("Unexpected error occurred while adding spotlight", e);
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/all")
    public ResponseEntity<Page<SpotLightResponseDto>> getAllSpotlights(Pageable pageable) {
        Page<Spotlight> spotlightPage = spotlightService.getAllSpotlight(pageable);

        Page<SpotLightResponseDto> dtoPage = spotlightPage.map(spotlight -> {
            String preSignedUrl = s3Service.generatePresignedUrl(spotlight.getVideo());

            String prePresignedUrl1 = null;

            if (spotlight.getThumbnail() != null && !spotlight.getThumbnail().isEmpty()) {
                prePresignedUrl1 = s3Service.generatePresignedUrl(spotlight.getThumbnail());
            }

            return  new SpotLightResponseDto(spotlight.getId(), spotlight.getTitle(),preSignedUrl,prePresignedUrl1,spotlight.getUrl(), spotlight.getSequence(), spotlight.getCreatedBy(), spotlight.getCreationDate(), spotlight.getLastModifiedBy(), spotlight.getLastModifiedDate());
        });
        return dtoPage.isEmpty() ? new ResponseEntity<>(HttpStatus.NO_CONTENT) : new ResponseEntity<>(dtoPage, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<SpotLightResponseDto> getSpotlightById(@PathVariable Long id) {
        return spotlightService.getSpotlightById(id)
                .map(spotlight ->{
                    String preSignedUrl = s3Service.generatePresignedUrl(spotlight.getVideo());
                    String prePresignedUrl1 = null;

                    if (spotlight.getThumbnail() != null && !spotlight.getThumbnail().isEmpty()) {
                        prePresignedUrl1 = s3Service.generatePresignedUrl(spotlight.getThumbnail());
                    }
                    SpotLightResponseDto dto = new SpotLightResponseDto(spotlight.getId(), spotlight.getTitle(),preSignedUrl, prePresignedUrl1,spotlight.getUrl(), spotlight.getSequence(), spotlight.getCreatedBy(), spotlight.getCreationDate(), spotlight.getLastModifiedBy(), spotlight.getLastModifiedDate());
                    return new ResponseEntity<>(dto, HttpStatus.OK);
                }).orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }


    @PutMapping(value = "/{id}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Edited", section = "Spotlight")
    public ResponseEntity<SpotLightResponseDto> updateNews(@PathVariable Long id,
                                              @RequestParam("title") String title,
                                              @RequestPart(value = "video", required = false) MultipartFile video,
                                                           @RequestPart(value = "thumbnail", required = false) MultipartFile thumbnail,
                                              @RequestParam(name="url", required = false) String url,
                                              @RequestParam("sequence") Double sequence) {
        try {
            Spotlight existing = spotlightService.getSpotlightById(id).orElse(null);
            if (existing == null) {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }

            String updatedImageKey = existing.getVideo();
            String updatedThumbnailKey = existing.getThumbnail();

            if (video != null && !video.isEmpty() && video.getOriginalFilename() != null
                    && !video.getOriginalFilename().isBlank()) {

                updatedImageKey = s3Service.updateFile(existing.getVideo(), video, "spotlight-videos");

                boolean isVideo = video.getContentType() != null &&
                        video.getContentType().startsWith("video");

                if (isVideo) {
                    if (thumbnail != null && !thumbnail.isEmpty()) {
                        updatedThumbnailKey = s3Service.uploadFile(thumbnail, "s-thumbnails");
                    }
                } else {
                    if (thumbnail != null && !thumbnail.isEmpty()) {
                        updatedThumbnailKey = s3Service.uploadFile(thumbnail, "s-thumbnails");
                    } else {
                        updatedThumbnailKey = null; // your rule
                    }
                }
            }
            else {
                if (thumbnail != null && !thumbnail.isEmpty()) {
                    updatedThumbnailKey = s3Service.uploadFile(thumbnail, "s-thumbnails");
                }
            }

            existing.setVideo(updatedImageKey);
            existing.setThumbnail(updatedThumbnailKey);
            existing.setTitle(title);
            existing.setUrl(url);
            existing.setSequence(sequence);

            Spotlight updatedSpotlight = spotlightService.saveSpotlight(existing);

            String preSignedUrl = s3Service.generatePresignedUrl(updatedSpotlight.getVideo());

            String prePresignedUrl1 = null;

            if (updatedSpotlight.getThumbnail() != null && !updatedSpotlight.getThumbnail().isEmpty()) {
                prePresignedUrl1 = s3Service.generatePresignedUrl(updatedSpotlight.getThumbnail());
            }
            SpotLightResponseDto responseDto = new SpotLightResponseDto(updatedSpotlight.getId(), updatedSpotlight.getTitle(),preSignedUrl, prePresignedUrl1, updatedSpotlight.getUrl(), updatedSpotlight.getSequence(), updatedSpotlight.getCreatedBy(), updatedSpotlight.getCreationDate(), updatedSpotlight.getLastModifiedBy(), updatedSpotlight.getLastModifiedDate());
            return new ResponseEntity<>(responseDto, HttpStatus.OK);
        } catch (IOException e) {
            e.printStackTrace();
            logger.error("IoException occurred while updating spotlight image", e);
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("Unexpected error occurred while updation spotlight", e);
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @DeleteMapping("/{id}")
    @TrackChange(action = "Deleted", section = "Spotlight")
    public ResponseEntity<Spotlight> deleteSpotlight(@PathVariable Long id) {
        try {
            Spotlight result = spotlightService.softDeleteSpotlight(id);
            return (result != null)
                    ? new ResponseEntity<>(result, HttpStatus.OK)
                    : new ResponseEntity<>(HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            logger.error("Failed to delete spotlight with ID: {}", id, e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
