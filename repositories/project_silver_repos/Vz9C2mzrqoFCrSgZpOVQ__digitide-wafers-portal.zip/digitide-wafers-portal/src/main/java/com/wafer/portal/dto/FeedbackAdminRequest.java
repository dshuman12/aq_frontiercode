package com.wafer.portal.dto;

import java.time.LocalDate;

public class FeedbackAdminRequest {

    private LocalDate feedbackDate;
    private boolean actionTaken;
    private String adminRemarks;
    private boolean sendMail;
    private boolean ticketClosed;

    public FeedbackAdminRequest() {
    }

    public FeedbackAdminRequest(LocalDate feedbackDate, boolean actionTaken, String adminRemarks, boolean sendMail) {
        this.feedbackDate = feedbackDate;
        this.actionTaken = actionTaken;
        this.adminRemarks = adminRemarks;
        this.sendMail = sendMail;
    }

    public boolean isActionTaken() {
        return actionTaken;
    }

    public void setActionTaken(boolean actionTaken) {
        this.actionTaken = actionTaken;
    }

    public LocalDate getFeedbackDate() {
        return feedbackDate;
    }

    public void setFeedbackDate(LocalDate feedbackDate) {
        this.feedbackDate = feedbackDate;
    }

    public String getAdminRemarks() {
        return adminRemarks;
    }

    public void setAdminRemarks(String adminRemarks) {
        this.adminRemarks = adminRemarks;
    }

    public boolean isSendMail() {
        return sendMail;
    }

    public void setSendMail(boolean sendMail) {
        this.sendMail = sendMail;
    }

    public boolean isTicketClosed() {
        return ticketClosed;
    }

    public void setTicketClosed(boolean ticketClosed) {
        this.ticketClosed = ticketClosed;
    }
}
