package com.wafer.portal.controller;


import com.wafer.portal.dto.*;
import com.wafer.portal.dto.ActiveModuleResponseDTO;
import com.wafer.portal.dto.DeepDiveResponseDTO;
import com.wafer.portal.dto.ModuleUsageResponseDTO;
import com.wafer.portal.model.AppModule;
import com.wafer.portal.service.DailyLoginActivityService;
import com.wafer.portal.service.DashboardService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/v2/dashboard")
public class DashboardController {

    private final DashboardService dashboardService;
    private final DailyLoginActivityService dailyLoginActivityService;


    public DashboardController(DashboardService dashboardService, DailyLoginActivityService dailyLoginActivityService) {
        this.dashboardService = dashboardService;
        this.dailyLoginActivityService = dailyLoginActivityService;
    }


    @PostMapping("/track/{moduleId}")
    public ResponseEntity<String> trackModule(
            @PathVariable Long moduleId
    ) {
        dashboardService.track(moduleId);
        return ResponseEntity.ok("Tracked successfully");
    }


    @GetMapping("/usage")
    public ResponseEntity<List<ModuleUsageResponseDTO>> getDashboard(
            @RequestParam LocalDate startDate,
            @RequestParam LocalDate endDate) {

        return ResponseEntity.ok(
                dashboardService.getDashboardData(startDate, endDate)
        );
    }

    @GetMapping("/modules/active")
    public ResponseEntity<List<ActiveModuleResponseDTO>> getActiveModules() {
        return ResponseEntity.ok(
                dashboardService.getAllActiveModules()
        );
    }


    @GetMapping("/module/{parent_id}")
    public ResponseEntity<List<ActiveModuleResponseDTO>> getModuleListBasedOnParentId(
            @PathVariable("parent_id") Long parentId) {

        List<ActiveModuleResponseDTO> modules =
                dashboardService.getModuleListBasedOnParentId(parentId);

        return ResponseEntity.ok(modules);
    }

    // Module Breakdown and Least or Most Clicks Breakdown Section API
    @GetMapping("/module-breakdown")
    public ResponseEntity<List<ModuleBreakdownDTO>> getModuleBreakdown(
            @RequestParam LocalDate startDate,
            @RequestParam LocalDate endDate,
            @RequestParam(required = false) Long levelId,
            @RequestParam(required = false) List<Long> moduleId,
            @RequestParam(required = false) String type
    ) {

        DashboardFilterDTO filter = new DashboardFilterDTO(
                startDate, endDate, levelId, moduleId, type
        );

        return ResponseEntity.ok(
                dashboardService.getModuleBreakdown(filter)
        );
    }

    // Monthly Trend Section API
    @GetMapping("/monthly-trend")
    public ResponseEntity<List<MonthlyUniqueUsersDTO>> getMonthlyTrend() {
        return ResponseEntity.ok(
                dashboardService.getMonthlyTrend()
        );
    }

    @GetMapping("/deep-dive")
    public ResponseEntity<List<DeepDiveResponseDTO>> getDeepDive(
            @RequestParam LocalDate startDate,
            @RequestParam LocalDate endDate) {

        return ResponseEntity.ok(
                dashboardService.getDeepDiveData(startDate, endDate)
        );
    }
    @GetMapping("/time-based-clicks")
    public ResponseEntity<List<TimeBasedClicksDTO>> getTimeBasedClicks(
            @RequestParam LocalDate startDate,
            @RequestParam LocalDate endDate,
            @RequestParam(defaultValue = "WEEK") String type
    ) {

        return ResponseEntity.ok(
                dashboardService.getTimeBasedClicks(startDate, endDate, type)
        );
    }

    @GetMapping("/header")
    public ResponseEntity<DashboardHeaderResponseDTO> getHeader(
            @RequestParam LocalDate startDate,
            @RequestParam LocalDate endDate) {

        return ResponseEntity.ok(
                dashboardService.getHeaderData(startDate, endDate)
        );
    }

    @GetMapping("/engagement-trend")
    public ResponseEntity<EngagementTrendDTO> getEngagementTrend(
            @RequestParam LocalDate startDate,
            @RequestParam LocalDate endDate) {

        return ResponseEntity.ok(
                dashboardService.getEngagementTrend(startDate, endDate)
        );
    }

    @GetMapping("/login-analytics")
    public LoginAnalyticsResponseDTO getLoginAnalytics(
            @RequestParam LocalDate fromDate,
            @RequestParam LocalDate toDate) {
        return dailyLoginActivityService.getLoginAnalytics(fromDate, toDate);
    }

    @GetMapping("/mood-percentage")
    public ResponseEntity<List<MoodPercentageDTO>> getMoodPercentage(
            @RequestParam LocalDate startDate,
            @RequestParam LocalDate endDate) {

        return ResponseEntity.ok(
                dashboardService.getMoodPercentage(startDate, endDate)
        );
    }

    @GetMapping("/monthly-unique-users")
    public ResponseEntity<List<MonthlyUniqueUsersDTO>> getMonthlyUniqueUsers() {

        return ResponseEntity.ok(
                dashboardService.getMonthlyTrend()
        );
    }

//    @GetMapping("/device-browser-breakdown")
//    public ResponseEntity<DeviceBrowserBreakDownDTO> getDeviceBrowserBreakdown(
//            @RequestParam LocalDate startDate,
//            @RequestParam LocalDate endDate) {
//
//        return ResponseEntity.ok(
//                dashboardService.getDeviceAndBrowserBreakdown(startDate, endDate)
//        );
//    }

    @GetMapping("/system-uptime")
    public ResponseEntity<Double> getSystemUptime(
            @RequestParam LocalDate startDate,
            @RequestParam LocalDate endDate) {

        return ResponseEntity.ok(
                dashboardService.getSystemUptime(startDate, endDate)
        );
    }

//    @GetMapping("/designation-logins")
//    public ResponseEntity<List<DesignationLoginDTO>> getDesignationLogins() {
//
//        return ResponseEntity.ok(
//                dailyLoginActivityService.getDesignationWiseStats()
//        );
//    }

    @GetMapping("/designation-logins")
    public ResponseEntity<List<DesignationLoginDTO>> getDesignationLogins(
            @RequestParam LocalDate startDate,
            @RequestParam LocalDate endDate) {

        return ResponseEntity.ok(
                dailyLoginActivityService.getDesignationWiseStats(startDate, endDate)
        );
    }


    @GetMapping("/search-analytics")
    public ResponseEntity<SearchAnalyticsDTO> getSearchAnalytics(
            @RequestParam LocalDate startDate,
            @RequestParam LocalDate endDate) {

        return ResponseEntity.ok(
                dashboardService.getSearchAnalytics(startDate, endDate)
        );
    }

    @GetMapping("/top-searches")
    public ResponseEntity<List<TopSearchDTO>> getTopSearches(
            @RequestParam LocalDate startDate,
            @RequestParam LocalDate endDate) {

        return ResponseEntity.ok(
                dashboardService.getTopSearches(startDate, endDate)
        );
    }

//    @GetMapping("/full")
//    public ResponseEntity<DashboardFullResponseDTO> getFullDashboard(
//            @RequestParam LocalDate startDate,
//            @RequestParam LocalDate endDate) {
//
//        return ResponseEntity.ok(
//                dashboardService.getFullDashboard(startDate, endDate)
//        );
//    }

}

