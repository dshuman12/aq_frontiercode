package com.wafer.portal.model;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.wafer.portal.audit.Auditable;
import jakarta.persistence.*;

import java.io.Serializable;

@Entity
@Table(name = "documents")
public class Document extends Auditable<String> implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    @Column(name = "document_url")
    private String documentUrl;

    @Column(name = "is_deleted",nullable = false)
    private boolean isDeleted;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "document_title_id", referencedColumnName = "id", nullable = false)
    @JsonManagedReference
    private DocumentTitle documentTitle;

    public Document() {}

    public Document(String name, String s3Url, DocumentTitle documentTitle) {
        this.name = name;
        this.documentUrl = s3Url;
        this.documentTitle = documentTitle;
        this.isDeleted = false;
    }

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getS3Url() {
        return documentUrl;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setS3Url(String s3Url) {
        this.documentUrl = s3Url;
    }

    public DocumentTitle getDocumentTitle() {
        return documentTitle;
    }

    public void setDocumentTitle(DocumentTitle documentTitle) {
        this.documentTitle = documentTitle;
    }

    public boolean isDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(boolean deleted) {
        isDeleted = deleted;
    }
}
