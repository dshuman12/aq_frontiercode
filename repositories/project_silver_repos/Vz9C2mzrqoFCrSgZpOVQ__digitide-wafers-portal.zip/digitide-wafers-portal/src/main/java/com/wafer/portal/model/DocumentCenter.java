package com.wafer.portal.model;

import com.wafer.portal.audit.Auditable;
import jakarta.persistence.*;

import java.io.Serializable;

@Entity
@Table(name = "document_center")
public class DocumentCenter extends Auditable<String> implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "section_id", nullable = false)
    private Long sectionId;

    @Column(name = "document_key")
    private String documentKey;

    @Column(name = "document_name")
    private String documentName;

    @Column(name = "thumbnail_key")
    private String thumbnailKey;

    private Double sequence;

    @Column(name = "is_deleted", nullable = false)
    private boolean isDeleted = false;

    public DocumentCenter() {}

    public DocumentCenter(Long sectionId, String documentKey, String documentName, String thumbnailKey, Double sequence) {
        this.sectionId = sectionId;
        this.documentKey = documentKey;
        this.documentName = documentName;
        this.thumbnailKey = thumbnailKey;
        this.sequence = sequence;
        this.isDeleted = false;
    }

    // getters & setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }


    public Long getSectionId() {
        return sectionId;
    }

    public void setSectionId(Long sectionId) {
        this.sectionId = sectionId;
    }

    public String getDocumentKey() { return documentKey; }
    public void setDocumentKey(String documentKey) { this.documentKey = documentKey; }

    public String getDocumentName() { return documentName; }
    public void setDocumentName(String documentName) { this.documentName = documentName; }

    public String getThumbnailKey() {
        return thumbnailKey;
    }

    public void setThumbnailKey(String thumbnailKey) {
        this.thumbnailKey = thumbnailKey;
    }

    public Double getSequence() {
        return sequence;
    }

    public void setSequence(Double sequence) {
        this.sequence = sequence;
    }

    public boolean isDeleted() { return isDeleted; }
    public void setIsDeleted(boolean deleted) { this.isDeleted = deleted; }

}
