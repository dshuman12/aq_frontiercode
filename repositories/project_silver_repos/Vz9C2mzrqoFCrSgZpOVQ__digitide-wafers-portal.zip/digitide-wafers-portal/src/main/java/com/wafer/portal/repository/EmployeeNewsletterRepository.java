package com.wafer.portal.repository;

import com.wafer.portal.model.EmployeeNewsletter;
import com.wafer.portal.model.People;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface EmployeeNewsletterRepository extends JpaRepository<EmployeeNewsletter, Long> {

    Optional<EmployeeNewsletter> findByIdAndIsDeletedFalse(Long id);

    Page<EmployeeNewsletter> findAllByIsDeletedFalseOrderByIssueDateDesc(Pageable pageable);

    Page<EmployeeNewsletter> findByIsDeletedFalse(Pageable pageable);

    @Query("SELECT e FROM EmployeeNewsletter e WHERE e.isDeleted = false AND (" +
            "LOWER(e.description) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    Page<EmployeeNewsletter> searchEmployeeNewsletter(@Param("keyword") String keyword, Pageable pageable);


}