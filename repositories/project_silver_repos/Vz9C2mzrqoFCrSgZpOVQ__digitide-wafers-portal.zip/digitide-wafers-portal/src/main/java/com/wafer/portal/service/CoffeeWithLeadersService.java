package com.wafer.portal.service;

import com.wafer.portal.awsS3.S3Service;
import com.wafer.portal.dto.*;
import com.wafer.portal.model.CoffeeWithLeaders;
import com.wafer.portal.repository.CoffeeWithLeadersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Optional;


@Service
public class CoffeeWithLeadersService {
    CoffeeWithLeadersRepository repository;
    S3Service s3Service;

    private static final String FOLDER_NAME = "COFFEE-WITH-LEADERS";

    @Autowired
    public CoffeeWithLeadersService(CoffeeWithLeadersRepository repository, S3Service s3Service) {
        this.repository = repository;
        this.s3Service = s3Service;
    }

    public ResponseEntity<CoffeeWithLeadersResponse> uploadCoffeeWithLeaders(MultipartFile image, MultipartFile thumbnail, CoffeeWithLeadersRequest request){
        try {
            if (image == null || image.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
            }
            String newImageKey;
            String urlKey = null;

            newImageKey = s3Service.uploadFile(image, FOLDER_NAME);
            if (thumbnail != null && !thumbnail.isEmpty()) {
                urlKey = s3Service.uploadFile(thumbnail, "Thumbnails");
            }
            CoffeeWithLeaders cwl = new CoffeeWithLeaders(request.getTitle(), request.getDesignation(), newImageKey, request.getDescription(),  urlKey, request.getSequence());

            CoffeeWithLeaders saved = repository.save(cwl);
            return new ResponseEntity<>(mapToResponse(saved), HttpStatus.CREATED);
        } catch (IOException e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Page<CoffeeWithLeadersResponse>> getAllCoffeeWithLeaders(Pageable pageable){
        Page<CoffeeWithLeaders> cwlPage = repository.findAllOrderedBySequence(pageable);
        Page<CoffeeWithLeadersResponse> dtoPage = cwlPage.map(this::mapToResponse);
        return dtoPage.isEmpty() ? new ResponseEntity<>(HttpStatus.NO_CONTENT) : new ResponseEntity<>(dtoPage, HttpStatus.OK);

    }

    public ResponseEntity<CoffeeWithLeadersResponse> getById(Long id) {
        return repository.findByIdAndIsDeletedFalse(id)
                .map(cwls -> new ResponseEntity<>(mapToResponse(cwls), HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    public ResponseEntity<CoffeeWithLeadersResponse> updateCoffeeWithLeaders(
            Long id,
            MultipartFile image,
            MultipartFile thumbnail,
            CoffeeWithLeadersRequest request) {

        try {
            Optional<CoffeeWithLeaders> existingOpt =
                    repository.findByIdAndIsDeletedFalse(id);

            if (existingOpt.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }

            CoffeeWithLeaders existing = existingOpt.get();

            String updatedImageKey = existing.getImage();
            String updatedThumbnailKey = existing.getThumbnail();


            if (image != null && !image.isEmpty() && image.getOriginalFilename() != null
                    && !image.getOriginalFilename().isBlank()) {
                updatedImageKey = s3Service.updateFile(existing.getImage(), image, FOLDER_NAME);

                boolean isVideo = image.getContentType() != null &&
                        image.getContentType().startsWith("video");

                if (isVideo) {
                    if (thumbnail != null && !thumbnail.isEmpty()) {
                        updatedThumbnailKey = s3Service.updateFile(existing.getThumbnail(), thumbnail, "Thumbnails");
                    }
                } else {
                    if (thumbnail != null && !thumbnail.isEmpty()) {
                        updatedThumbnailKey = s3Service.updateFile(existing.getThumbnail(), thumbnail, "Thumbnails");
                    } else {
                        updatedThumbnailKey = null;
                    }
                }
            }
            else {
                if (thumbnail != null && !thumbnail.isEmpty()) {
                    updatedThumbnailKey = s3Service.updateFile(existing.getThumbnail(), thumbnail, "Thumbnails");
                }
            }

            existing.setTitle(request.getTitle());
            existing.setDesignation(request.getDesignation());
            existing.setImage(updatedImageKey);
            existing.setThumbnail(updatedThumbnailKey);
            existing.setDescription(request.getDescription());
            existing.setSequence(request.getSequence());

            CoffeeWithLeaders updated = repository.save(existing);

            return new ResponseEntity<>(mapToResponse(updated), HttpStatus.OK);

        } catch (IOException e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public CoffeeWithLeaders deleteCoffeeWithLeaders(Long id) {
        return repository.findByIdAndIsDeletedFalse(id)
                .map(cwl -> {
                    cwl.setDeleted(true);
                    return repository.save(cwl);
                }).orElse(null);
    }


    private CoffeeWithLeadersResponse mapToResponse(CoffeeWithLeaders cwl) {
        String imageUrl = s3Service.generatePresignedUrl(cwl.getImage());
        String prePresignedUrl1 = null;

        if (cwl.getThumbnail() != null && !cwl.getThumbnail().isEmpty()) {
            prePresignedUrl1 = s3Service.generatePresignedUrl(cwl.getThumbnail());
        }
        return new CoffeeWithLeadersResponse(
                cwl.getId(),
                cwl.getTitle(),
                cwl.getDesignation(),
                imageUrl,
                prePresignedUrl1,
                cwl.getDescription(),
                cwl.getSequence(),
                cwl.getCreatedBy(),
                cwl.getCreationDate(),
                cwl.getLastModifiedBy(),
                cwl.getLastModifiedDate()
        );
    }
}
