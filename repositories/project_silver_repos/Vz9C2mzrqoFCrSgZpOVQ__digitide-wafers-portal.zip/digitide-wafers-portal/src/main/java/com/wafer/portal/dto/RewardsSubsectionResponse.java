package com.wafer.portal.dto;

public class RewardsSubsectionResponse {
    private Long id;
    private String subsectionName;

    public RewardsSubsectionResponse(Long id, String subsectionName) {
        this.id = id;
        this.subsectionName = subsectionName;
    }

    public void setId(Long id) {
        this.id = id;
    }


    public void setSubsectionName(String subsectionName) {
        this.subsectionName = subsectionName;
    }

    public Long getId() { return id; }
    public String getSubsectionName() { return subsectionName; }
}