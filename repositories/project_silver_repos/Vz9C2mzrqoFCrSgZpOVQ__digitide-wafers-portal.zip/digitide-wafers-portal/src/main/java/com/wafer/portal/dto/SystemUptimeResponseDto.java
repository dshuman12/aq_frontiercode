package com.wafer.portal.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class SystemUptimeResponseDto {

    private Long id;
    private LocalDate logDate;
    private LocalTime logStartTime;
    private LocalTime logEndTime;
    private Long duration;
    private Double uptimePercentage;

    public SystemUptimeResponseDto(Long id, LocalDate logDate, LocalTime logStartTime, LocalTime logEndTime, Long duration, Double uptimePercentage) {
        this.id = id;
        this.logDate = logDate;
        this.logStartTime = logStartTime;
        this.logEndTime = logEndTime;
        this.duration = duration;
        this.uptimePercentage = uptimePercentage;
    }

    public LocalDate getLogDate() {
        return logDate;
    }

    public void setLogDate(LocalDate logDate) {
        this.logDate = logDate;
    }

    public LocalTime getLogStartTime() {
        return logStartTime;
    }

    public void setLogStartTime(LocalTime logStartTime) {
        this.logStartTime = logStartTime;
    }

    public LocalTime getLogEndTime() {
        return logEndTime;
    }

    public void setLogEndTime(LocalTime logEndTime) {
        this.logEndTime = logEndTime;
    }

    public Long getDuration() {
        return duration;
    }

    public void setDuration(Long duration) {
        this.duration = duration;
    }

    public Double getUptimePercentage() {
        return uptimePercentage;
    }

    public void setUptimePercentage(Double uptimePercentage) {
        this.uptimePercentage = uptimePercentage;
    }
}