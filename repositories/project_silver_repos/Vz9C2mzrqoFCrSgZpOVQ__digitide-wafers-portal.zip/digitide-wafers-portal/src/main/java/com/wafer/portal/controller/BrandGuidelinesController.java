package com.wafer.portal.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.wafer.portal.annotation.TrackChange;
import com.wafer.portal.dto.BrandGuidelinesRequest;
import com.wafer.portal.dto.BrandGuidelinesResponseDto;
import com.wafer.portal.model.BrandGuidelines;
import com.wafer.portal.service.BrandGuidelinesService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@Controller
@RestController
@RequestMapping("/api/v2/brand-guidelines")
public class BrandGuidelinesController {

    private final BrandGuidelinesService service;

    public BrandGuidelinesController(BrandGuidelinesService service) {
        this.service = service;
    }

    @PostMapping(value = "/create", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Added", section = "Brand Guidelines")
    public ResponseEntity<BrandGuidelinesResponseDto> create(
            @RequestParam("document") MultipartFile document,
            @RequestParam("request") String requestJson) throws JsonProcessingException {

        ObjectMapper mapper = new ObjectMapper().registerModule(new JavaTimeModule());
        BrandGuidelinesRequest request = mapper.readValue(requestJson, BrandGuidelinesRequest.class);
        return service.createGuideline(document, request);
    }

    @GetMapping("/all")
    public ResponseEntity<Page<BrandGuidelinesResponseDto>> getAll(Pageable pageable) {
        return service.getAll(pageable);
    }

    @GetMapping("/{id}")
    public ResponseEntity<BrandGuidelinesResponseDto> getById(@PathVariable Long id) {
        return service.getById(id);
    }

    @PutMapping(value = "/{id}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Edited", section = "Brand Guidelines")
    public ResponseEntity<BrandGuidelinesResponseDto> update(
            @PathVariable Long id,
            @RequestParam(value = "document", required = false) MultipartFile document,
            @RequestParam("request") String requestJson) throws JsonProcessingException {

        ObjectMapper mapper = new ObjectMapper().registerModule(new JavaTimeModule());
        BrandGuidelinesRequest request = mapper.readValue(requestJson, BrandGuidelinesRequest.class);

        return service.updateGuideline(id, document, request);
    }

    @DeleteMapping("/{id}")
    @TrackChange(action = "Deleted", section = "Brand Guidelines")
    public ResponseEntity<BrandGuidelines> delete(@PathVariable Long id) {
        BrandGuidelines result = service.deleteGuideline(id);
        return (result != null)
                ? new ResponseEntity<>(result, HttpStatus.OK)
                : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}
