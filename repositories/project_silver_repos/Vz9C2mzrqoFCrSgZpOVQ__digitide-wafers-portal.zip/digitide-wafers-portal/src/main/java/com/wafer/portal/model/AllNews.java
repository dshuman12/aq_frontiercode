package com.wafer.portal.model;

import com.wafer.portal.audit.Auditable;
import jakarta.persistence.*;

import java.io.Serializable;
import java.time.LocalDate;

@Entity
@Table(name = "all_news")
public class AllNews extends Auditable<String> implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "title", nullable = false)
    private String title;

    private String image;

    @Column(name="thumbnail_url")
    private String thumbnail;

    private String url;

    private LocalDate allNewsDate;

    private Double sequence;

    @Column(name = "is_deleted",nullable = false)
    private boolean isDeleted;


    public AllNews() {
    }

    public AllNews(String imageKey, String title, String thumbnail, String url, LocalDate allNewsDate, Double sequence) {
        this.title = title;
        this.image = imageKey;
        this.thumbnail = thumbnail;
        this.url = url;
        this.allNewsDate = allNewsDate;
        this.sequence = sequence;
        this.isDeleted = false;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title= title;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public LocalDate getAllNewsDate() {
        return allNewsDate;
    }

    public void setAllNewsDate(LocalDate allNewsDate) {
        this.allNewsDate = allNewsDate;
    }

    public Double getSequence() {
        return sequence;
    }

    public void setSequence(Double sequence) {
        this.sequence = sequence;
    }

    public boolean isDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(boolean deleted) {
        isDeleted = deleted;
    }
}

