package com.wafer.portal.dto;

public class EngagementTrendDTO {

    private Long currentClicks;
    private Long previousClicks;
    private Double percentageChange;
    private String trend;

    public EngagementTrendDTO(Long currentClicks,
                              Long previousClicks,
                              Double percentageChange,
                              String trend) {
        this.currentClicks = currentClicks;
        this.previousClicks = previousClicks;
        this.percentageChange = percentageChange;
        this.trend = trend;
    }

    public Long getCurrentClicks() {
        return currentClicks;
    }

    public Long getPreviousClicks() {
        return previousClicks;
    }

    public Double getPercentageChange() {
        return percentageChange;
    }

    public String getTrend() {
        return trend;
    }
}
