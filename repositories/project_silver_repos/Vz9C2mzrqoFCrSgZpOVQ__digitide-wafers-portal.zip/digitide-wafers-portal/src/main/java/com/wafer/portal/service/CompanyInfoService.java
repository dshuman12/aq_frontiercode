package com.wafer.portal.service;


import com.wafer.portal.awsS3.S3Service;
import com.wafer.portal.dto.CompanyInfoRequest;
import com.wafer.portal.dto.CompanyInfoResponse;
import com.wafer.portal.model.CompanyInfo;
import com.wafer.portal.repository.CompanyInfoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Optional;

@Service
public class CompanyInfoService {
    private static final String COMPANY_INFO_FOLDER = "Company-Info-Images";

    private final CompanyInfoRepository companyInfoRepository;

    private final S3Service s3Service;

    @Autowired
    public CompanyInfoService(CompanyInfoRepository companyInfoRepository, S3Service s3Service) {
        this.companyInfoRepository = companyInfoRepository;
        this.s3Service = s3Service;
    }

    public ResponseEntity<CompanyInfoResponse> createCompanyInfo(MultipartFile image, CompanyInfoRequest request) {
        try {
            if (image.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
            }
            Optional<CompanyInfo> existing = companyInfoRepository.findTopByIsDeletedFalseOrderByCreationDateDesc();

            String newImageKey;
            if (existing.isPresent()) {
                CompanyInfo oldCompanyInfo = existing.get();
                newImageKey = s3Service.updateFile(oldCompanyInfo.getImage(), image, COMPANY_INFO_FOLDER);
                oldCompanyInfo.setTitle(request.getTitle());
                oldCompanyInfo.setImage(newImageKey);
                oldCompanyInfo.setDescription(request.getDescription());
                CompanyInfo updated = companyInfoRepository.save(oldCompanyInfo);
                return new ResponseEntity<>(mapToResponseDto(updated), HttpStatus.OK);
            } else {
                String imageKey = s3Service.uploadFile(image, COMPANY_INFO_FOLDER);
                CompanyInfo companyInfo = new CompanyInfo(request.getTitle(),imageKey,request.getDescription());
                CompanyInfo saved = companyInfoRepository.save(companyInfo);
                return new ResponseEntity<>(mapToResponseDto(saved), HttpStatus.CREATED);
            }
        } catch (IOException e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Page<CompanyInfoResponse>> getAllCompanyInfo(Pageable pageable) {
        Page<CompanyInfo> companyInfoPage = companyInfoRepository.findByIsDeletedFalse(pageable);
        Page<CompanyInfoResponse> dtoPage = companyInfoPage.map(this::mapToResponseDto);
        return dtoPage.isEmpty() ? new ResponseEntity<>(HttpStatus.NO_CONTENT) : new ResponseEntity<>(dtoPage, HttpStatus.OK);
    }

    public ResponseEntity<CompanyInfoResponse> getCompanyInfoById(Long id) {
        return companyInfoRepository.findByIdAndIsDeletedFalse(id)
                .map(companyInfo -> new ResponseEntity<>(mapToResponseDto(companyInfo), HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    public ResponseEntity<CompanyInfoResponse> updateCompanyInfo(Long id,MultipartFile image, CompanyInfoRequest request) {
        return companyInfoRepository.findByIdAndIsDeletedFalse(id)
                .map(existing -> {
                    try {
                        if (image != null && !image.isEmpty()) {
                            String newImageKey = s3Service.updateFile(existing.getImage(), image, COMPANY_INFO_FOLDER);
                            existing.setImage(newImageKey);
                        }

                        existing.setTitle(request.getTitle());
                        existing.setDescription(request.getDescription());
                        CompanyInfo updated = companyInfoRepository.save(existing);
                        return new ResponseEntity<>(mapToResponseDto(updated), HttpStatus.OK);
                    } catch (IOException e) {
                        return new ResponseEntity<CompanyInfoResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
                    }
                })
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));

    }

    public CompanyInfo deleteCompanyInfo(Long id) {
        return companyInfoRepository.findByIdAndIsDeletedFalse(id)
                .map(companyInfo -> {
                    companyInfo.setDeleted(true);
                    return companyInfoRepository.save(companyInfo);
                }).orElse(null);
    }

    private CompanyInfoResponse mapToResponseDto(CompanyInfo saved) {
        String preSignedUrl = s3Service.generatePresignedUrl(saved.getImage());
        return new CompanyInfoResponse(
                saved.getId(),
                saved.getTitle(),
                preSignedUrl,
                saved.getDescription(),
                saved.getCreatedBy(),
                saved.getCreationDate(),
                saved.getLastModifiedBy(),
                saved.getLastModifiedDate()
        );
    }

}
