package com.wafer.portal.dto;

public class DocumentSectionRequest {
    private String sectionName;

    public String getSectionName() { return sectionName; }
    public void setSectionName(String sectionName) { this.sectionName = sectionName; }
}
