package com.wafer.portal.dto;

import java.time.LocalDateTime;

public class RewardsandRecognitionResponse {

    private Long id;
    private String name;
    private String designation;
    private String description;
    private String image;
    private String location;
    private String nameOfAward;
    private Double sequence;
    private Long sectionId;
    private Long subsectionId;
    private String sectionName;
    private String subsectionName;

    private String createdBy;
    private LocalDateTime creationDate;
    private String lastModifiedBy;
    private LocalDateTime lastModifiedDate;

    public RewardsandRecognitionResponse(Long id, String name, String designation, String description, String image, String location, String nameOfAward, Double sequence, Long sectionId, Long subsectionId, String sectionName, String subsectionName, String createdBy, LocalDateTime creationDate, String lastModifiedBy, LocalDateTime lastModifiedDate) {
        this.id = id;
        this.name = name;
        this.designation = designation;
        this.description = description;
        this.image = image;
        this.location = location;
        this.nameOfAward = nameOfAward;
        this.sequence = sequence;
        this.sectionId=sectionId;
        this.subsectionId=subsectionId;
        this.sectionName=sectionName;
        this.subsectionName=subsectionName;
        this.createdBy = createdBy;
        this.creationDate = creationDate;
        this.lastModifiedBy = lastModifiedBy;
        this.lastModifiedDate = lastModifiedDate;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getNameOfAward() {
        return nameOfAward;
    }

    public void setNameOfAward(String nameOfAward) {
        this.nameOfAward = nameOfAward;
    }

    public Double getSequence() {
        return sequence;
    }

    public void setSequence(Double sequence) {
        this.sequence = sequence;
    }

    public Long getSectionId() {
        return sectionId;
    }

    public void setSectionId(Long sectionId) {
        this.sectionId = sectionId;
    }

    public Long getSubsectionId() {
        return subsectionId;
    }

    public void setSubsectionId(Long subsectionId) {
        this.subsectionId = subsectionId;
    }

    public String getSectionName() {
        return sectionName;
    }

    public void setSectionName(String sectionName) {
        this.sectionName = sectionName;
    }

    public String getSubsectionName() {
        return subsectionName;
    }

    public void setSubsectionName(String subsectionName) {
        this.subsectionName = subsectionName;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public LocalDateTime getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(LocalDateTime creationDate) {
        this.creationDate = creationDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public LocalDateTime getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(LocalDateTime lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }
}