package com.wafer.portal.controller;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wafer.portal.annotation.TrackChange;
import com.wafer.portal.dto.*;
import com.wafer.portal.model.FeedBack;
import com.wafer.portal.service.FeedbackService;
import org.hibernate.type.descriptor.jdbc.OracleJsonBlobJdbcType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;

@RestController
@RequestMapping("/api/v2/feedback")
public class FeedbackController {
    private final FeedbackService feedbackService;
    private final ObjectMapper objectMapper;

    @Autowired
    public FeedbackController(FeedbackService feedbackService, ObjectMapper objectMapper) {
        this.feedbackService = feedbackService;
        this.objectMapper = objectMapper;
    }

    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<FeedbackResponse> createFeedback(
            @RequestParam(value = "file", required = false) MultipartFile file,
            @RequestParam("request") String requestJson) throws JsonProcessingException {
        FeedbackRequest request = objectMapper.readValue(requestJson, FeedbackRequest.class);
        return feedbackService.createFeedback(file, request);
    }
    @GetMapping("/all")
    public ResponseEntity<Page<FeedbackAdminResponse>> getAllFeedback(Pageable pageable) {
        return feedbackService.getAllFeedBackAdmin(pageable);
    }

    @GetMapping("/{id}")
    public ResponseEntity<FeedbackAdminResponse> getFeedbackById(@PathVariable Long id) {
        return feedbackService.getFeedbackById(id);
    }


    @PutMapping(value = "/{id}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<FeedbackAdminResponse> updateQuickLink(
            @PathVariable Long id,
            @RequestParam(value = "file", required = false) MultipartFile file,
            @RequestParam("request") String requestJson) throws JsonProcessingException {

        FeedbackAdminRequest request = objectMapper.readValue(requestJson, FeedbackAdminRequest.class);
        return feedbackService.updateFeedbackAdmin(id, file, request);
    }

    @GetMapping("/history")
    public ResponseEntity<Page<FeedbackAdminResponse>> getFeedbackHistory(
            @RequestParam("startDate")
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,

            @RequestParam("endDate")
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,

            Pageable pageable) {

        return feedbackService.getAllFeedbackHistoryByDateRange(
                startDate,
                endDate,
                pageable
        );
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<FeedBack> deleteFeedback(@PathVariable Long id) {
        FeedBack result = feedbackService.deleteFeedback(id);
        return (result != null)
                ? new ResponseEntity<>(result, HttpStatus.OK)
                : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}
