package com.wafer.portal.repository;

import com.wafer.portal.model.CoffeeWithLeaders;
import com.wafer.portal.model.People;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CoffeeWithLeadersRepository extends JpaRepository<CoffeeWithLeaders,Long> {

    Page<CoffeeWithLeaders> findByIsDeletedFalse(Pageable pageable);
    Optional<CoffeeWithLeaders> findByIdAndIsDeletedFalse(Long aLong);

    @Query("SELECT c FROM CoffeeWithLeaders c WHERE c.isDeleted = false ORDER BY " +
            "CASE WHEN c.sequence IS NULL THEN 1 ELSE 0 END, c.sequence ASC")
    Page<CoffeeWithLeaders> findAllOrderedBySequence(Pageable pageable);

    @Query("SELECT c FROM CoffeeWithLeaders c WHERE c.isDeleted = false AND (" +
            "LOWER(c.title) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(c.designation) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    Page<CoffeeWithLeaders> searchCoffeeWithLeaders(@Param("keyword") String keyword, Pageable pageable);


}
