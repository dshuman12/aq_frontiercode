package com.wafer.portal.dto;

public class LoginAnalyticsResponseDTO {

    private Long uniqueVisitors;
    private Long dailyUniqueUsers;
    private Long weeklyUniqueUsers;
    private Long monthlyUniqueUsers;
    private Long newUsers;
    private Long returningUsers;
    private Double avgLoginFrequency;

    public LoginAnalyticsResponseDTO() {}

    public LoginAnalyticsResponseDTO(Long uniqueVisitors,
                                     Long dailyUniqueUsers,
                                     Long weeklyUniqueUsers,
                                     Long monthlyUniqueUsers,
                                     Long newUsers,
                                     Long returningUsers,
                                     Double avgLoginFrequency) {
        this.uniqueVisitors = uniqueVisitors;
        this.dailyUniqueUsers = dailyUniqueUsers;
        this.weeklyUniqueUsers = weeklyUniqueUsers;
        this.monthlyUniqueUsers = monthlyUniqueUsers;
        this.newUsers = newUsers;
        this.returningUsers = returningUsers;
        this.avgLoginFrequency = avgLoginFrequency;
    }

    public Long getUniqueVisitors() { return uniqueVisitors; }
    public void setUniqueVisitors(Long uniqueVisitors) { this.uniqueVisitors = uniqueVisitors; }

    public Long getDailyUniqueUsers() {
        return dailyUniqueUsers;
    }

    public void setDailyUniqueUsers(Long dailyUniqueUsers) {
        this.dailyUniqueUsers = dailyUniqueUsers;
    }

    public Long getWeeklyUniqueUsers() {
        return weeklyUniqueUsers;
    }

    public void setWeeklyUniqueUsers(Long weeklyUniqueUsers) {
        this.weeklyUniqueUsers = weeklyUniqueUsers;
    }

    public Long getMonthlyUniqueUsers() {
        return monthlyUniqueUsers;
    }

    public void setMonthlyUniqueUsers(Long monthlyUniqueUsers) {
        this.monthlyUniqueUsers = monthlyUniqueUsers;
    }

    public Long getNewUsers() { return newUsers; }
    public void setNewUsers(Long newUsers) { this.newUsers = newUsers; }

    public Long getReturningUsers() { return returningUsers; }
    public void setReturningUsers(Long returningUsers) { this.returningUsers = returningUsers; }

    public Double getAvgLoginFrequency() { return avgLoginFrequency; }
    public void setAvgLoginFrequency(Double avgLoginFrequency) { this.avgLoginFrequency = avgLoginFrequency; }
}