package com.wafer.portal.service;

import com.wafer.portal.awsS3.S3Service;
import com.wafer.portal.dto.ChangeTrackerResponse;
import com.wafer.portal.model.ChangeTracker;
import com.wafer.portal.repository.ChangeTrackerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Service
public class AuditService {

    @Autowired
    private ChangeTrackerRepository repository;

    @Autowired
    private S3Service s3Service;

    public void logChange(String email, String action, String resource, String section, String fileName, String s3Key) {
        ChangeTracker log = new ChangeTracker();
        log.setUserEmail(email);
        log.setActionType(action);
        log.setResourceType(resource);
        log.setSectionName(section);
        log.setFileName(fileName);
        log.setS3Key(s3Key);
        log.setTimestamp(LocalDateTime.now());
        repository.save(log);
    }

    public ResponseEntity<Page<ChangeTrackerResponse>> getAllAuditLogs(Pageable pageable) {
        Page<ChangeTracker> logs = repository.findByIsDeletedFalseOrderByTimestampDesc(pageable);

        Page<ChangeTrackerResponse> responsePage = logs.map(this::mapToResponse);

        return responsePage.isEmpty()
                ? new ResponseEntity<>(HttpStatus.NO_CONTENT)
                : new ResponseEntity<>(responsePage, HttpStatus.OK);
    }

    public ResponseEntity<Page<ChangeTrackerResponse>> getAuditLogsByDateRange(LocalDate startDate, LocalDate endDate, Pageable pageable) {

        LocalDateTime startDateTime = startDate.atStartOfDay();
        LocalDateTime endDateTime = endDate.plusDays(1).atStartOfDay();

        // 1. Fetch Entities from Repository
        Page<ChangeTracker> logs = repository.findByIsDeletedFalseAndTimestampBetweenOrderByTimestampDesc(
                startDateTime,
                endDateTime,
                pageable
        );

        Page<ChangeTrackerResponse> dtoPage = logs.map(this::mapToResponse);

        return dtoPage.isEmpty()
                ? new ResponseEntity<>(HttpStatus.NO_CONTENT)
                : new ResponseEntity<>(dtoPage, HttpStatus.OK);
    }

    public ChangeTracker softDeleteAuditLog(Long id) {
        // This method stays entity-focused as it's a database command
        return repository.findByIdAndIsDeletedFalse(id)
                .map(log -> {
                    log.setDeleted(true);
                    return repository.save(log);
                }).orElse(null);
    }

    private ChangeTrackerResponse mapToResponse(ChangeTracker log) {
        String preSignedUrl;

        if (log.getS3Key() != null &&
                !log.getS3Key().trim().isEmpty()) {

            try {
                preSignedUrl = s3Service.generatePresignedUrl(log.getS3Key());
            } catch (Exception e) {
                preSignedUrl = "Link Generation Failed";
            }
        } else {
            preSignedUrl = "No file available";
        }

        return new ChangeTrackerResponse(
                log.getId(),
                log.getUserEmail(),
                log.getActionType(),
                log.getResourceType(),
                log.getSectionName(),
                log.getFileName(),
                log.getTimestamp(),
                preSignedUrl,
                log.getCreatedBy(),
                log.getCreationDate(),
                log.getLastModifiedBy(),
                log.getLastModifiedDate()
        );
    }
}