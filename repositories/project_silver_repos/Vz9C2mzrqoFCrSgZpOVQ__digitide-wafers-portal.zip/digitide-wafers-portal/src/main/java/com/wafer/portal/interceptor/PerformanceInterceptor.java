package com.wafer.portal.interceptor;

import com.wafer.portal.model.PerformanceLog;
import com.wafer.portal.repository.PerformanceLogRepository;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
public class PerformanceInterceptor implements HandlerInterceptor {

    private final PerformanceLogRepository repository;

    private final ThreadLocal<Long> startTime = new ThreadLocal<>();

    public PerformanceInterceptor(PerformanceLogRepository repository) {
        this.repository = repository;
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler){

        startTime.set(System.currentTimeMillis());
        return true;
    }


    @Override
    public void afterCompletion(HttpServletRequest request,
                                HttpServletResponse response,
                                Object handler,
                                Exception ex){

        Long start = startTime.get();

        System.out.println("Interceptor executed for: " + request.getRequestURI());

        if(start == null){
            return;
        }

        long duration = System.currentTimeMillis() - start;

        String trackingId = request.getHeader("trackingId");

        System.out.println("TrackingId header: " + trackingId);

        PerformanceLog log = new PerformanceLog();

        log.setTrackingId(trackingId);
        log.setApiName(request.getRequestURI());
        log.setApiResponseTimeMs((int) duration);
        log.setStatusCode(response.getStatus());

        repository.save(log);

        System.out.println("Performance log saved");
    }
}