package com.wafer.portal.service;


import com.wafer.portal.model.TopNews;
import com.wafer.portal.repository.TopNewsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class TopNewsService {

    @Autowired
    private TopNewsRepository topNewsRepository;

    public TopNews saveNews(TopNews news) {
        return topNewsRepository.save(news);
    }

    public Page<TopNews> getAllNews(Pageable pageable) {
        return topNewsRepository.findAllWithDateSort(pageable);
    }

    public Optional<TopNews> getNewsById(Long id) {
        return topNewsRepository.findByIdAndIsDeletedFalse(id);
    }

    public TopNews updateNews(Long id, TopNews updatedNews) {
        return topNewsRepository.findById(id).map(news -> {
            news.setImage(updatedNews.getImage());
            news.setUrl(updatedNews.getUrl());
            return topNewsRepository.save(news);
        }).orElse(null);
    }

    public TopNews softDeleteNews(Long id) {
        return topNewsRepository.findByIdAndIsDeletedFalse(id).map(topNews -> {
            topNews.setIsDeleted(true);
            return topNewsRepository.save(topNews);
        }).orElse(null);
    }

}

