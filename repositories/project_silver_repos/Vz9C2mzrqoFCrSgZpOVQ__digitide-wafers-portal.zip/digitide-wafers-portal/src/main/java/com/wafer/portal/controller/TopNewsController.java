package com.wafer.portal.controller;


import com.wafer.portal.annotation.TrackChange;
import com.wafer.portal.dto.TopNewsResponseDto;
import com.wafer.portal.dto.response.BasicResponse;
import com.wafer.portal.model.TopNews;
import com.wafer.portal.awsS3.S3Service;
import com.wafer.portal.service.TopNewsService;
import com.wafer.portal.utils.ResponseFormatUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDate;

@RestController
@RequestMapping("/api/v1/top-news")
public class TopNewsController {

    private static  final Logger logger =  LoggerFactory.getLogger(TopNewsController.class);

    private final TopNewsService topNewsService;
    private final S3Service s3Service;

    public TopNewsController(TopNewsService topNewsService, S3Service s3Service) {
        this.topNewsService = topNewsService;
        this.s3Service = s3Service;
    }

    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Added", section = "Top News")
    public ResponseEntity<BasicResponse<?>> addNews(
            @RequestParam("title") String title,
            @RequestParam(name = "url", required = false) String url,
            @RequestParam(name="topNewsDate", required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate topNewsDate,
            @RequestParam(name = "newsDescription", required = false) String newsDescription,
            @RequestPart("image") MultipartFile image,
            @RequestPart(value = "thumbnail", required = false) MultipartFile thumbnail,
            @RequestParam(name="sequence", required=false) Double sequence) {

        BasicResponse<TopNewsResponseDto> response = new BasicResponse<>();

        try {
            if (image.isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(ResponseFormatUtils.createErrorResponse(response, "File is empty"));
            }


            // Upload file to S3
            String imageKey = s3Service.uploadFile(image, "Top-News-Images");
            String urlKey = null;

            if (thumbnail != null && !thumbnail.isEmpty()) {
                urlKey = s3Service.uploadFile(thumbnail, "Thumbnails");
            }

            // Save entity
            TopNews news = new TopNews(imageKey,urlKey, url, title, topNewsDate, newsDescription, sequence);
            TopNews savedNews = topNewsService.saveNews(news);

            // Generate presigned URL
            String preSignedUrl = s3Service.generatePresignedUrl(savedNews.getImage());

            String prePresignedUrl1 = null;

            if (savedNews.getThumbnail() != null && !savedNews.getThumbnail().isEmpty()) {
                prePresignedUrl1 = s3Service.generatePresignedUrl(savedNews.getThumbnail());
            }

            // Prepare response DTO
            TopNewsResponseDto resDto = new TopNewsResponseDto(
                    savedNews.getId(),
                    savedNews.getTitle(),
                    preSignedUrl,
                    prePresignedUrl1,
                    savedNews.getUrl(),
                    savedNews.getTopNewsDate(),
                    savedNews.getNewsDescription(),
                    savedNews.getSequence(),
                    savedNews.getCreatedBy(),
                    savedNews.getCreationDate(),
                    savedNews.getLastModifiedBy(),
                    savedNews.getLastModifiedDate()
            );

            response.setData(resDto);
            response.setStatusCode(HttpStatus.OK.value());

            return ResponseEntity.ok(ResponseFormatUtils.createSuccessResponse(response, "Top news added successfully"));

        } catch (IOException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ResponseFormatUtils.createErrorResponse(response, "File upload error: " + e.getMessage()));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ResponseFormatUtils.createErrorResponse(response, "Unexpected error: " + e.getMessage()));
        }
    }

    @GetMapping("/all")
    public ResponseEntity<Page<TopNewsResponseDto>> getAllNews(Pageable pageable) {
        Page<TopNews> newsPage = topNewsService.getAllNews(pageable);


        Page<TopNewsResponseDto> dtoPage = newsPage.map(news -> {
            String preSignedUrl = s3Service.generatePresignedUrl(news.getImage());
            String prePresignedUrl1 = null;

            if (news.getThumbnail() != null && !news.getThumbnail().isEmpty()) {
                prePresignedUrl1 = s3Service.generatePresignedUrl(news.getThumbnail());
            }
            return  new TopNewsResponseDto(news.getId(), news.getTitle(), preSignedUrl,prePresignedUrl1 ,news.getUrl(), news.getTopNewsDate(), news.getNewsDescription(), news.getSequence(), news.getCreatedBy(), news.getCreationDate(), news.getLastModifiedBy(), news.getLastModifiedDate());
        });
        return dtoPage.isEmpty() ? new ResponseEntity<>(HttpStatus.NO_CONTENT) : new ResponseEntity<>(dtoPage, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<TopNewsResponseDto> getNewsById(@PathVariable Long id) {
        return topNewsService.getNewsById(id)
                .map(news ->{
                    String preSignedUrl = s3Service.generatePresignedUrl(news.getImage());
                    String prePresignedUrl1 = null;

                    if (news.getThumbnail() != null && !news.getThumbnail().isEmpty()) {
                        prePresignedUrl1 = s3Service.generatePresignedUrl(news.getThumbnail());
                    }
                    TopNewsResponseDto dto = new TopNewsResponseDto(news.getId(), news.getTitle(), preSignedUrl,prePresignedUrl1, news.getUrl(), news.getTopNewsDate(), news.getNewsDescription(), news.getSequence(), news.getCreatedBy(), news.getCreationDate(), news.getLastModifiedBy(), news.getLastModifiedDate());
                    return new ResponseEntity<>(dto, HttpStatus.OK);
                }).orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }


    @PutMapping(value = "/{id}",  consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Edited", section = "Top News")
    public ResponseEntity<TopNewsResponseDto> updateNews(@PathVariable Long id,
                                              @RequestParam("title") String title,
                                              @RequestPart(value = "image", required = false) MultipartFile image,
                                                         @RequestPart(value = "thumbnail", required = false) MultipartFile thumbnail,
                                                         @RequestParam(name="url", required=false) String url,
                                                         @RequestParam(name="topNewsDate",required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate topNewsDate,
                                                         @RequestParam(name="newsDescription", required=false) String newsDescription,
                                                         @RequestParam(name="sequence", required=false) Double sequence) {
        try {
            TopNews existing = topNewsService.getNewsById(id).orElse(null);
            if (existing == null) {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }

            String updatedImageKey = existing.getImage();
            String updatedThumbnailKey = existing.getThumbnail();

            if (image != null && !image.isEmpty() && image.getOriginalFilename() != null
                    && !image.getOriginalFilename().isBlank()) {

                updatedImageKey = s3Service.updateFile(existing.getImage(), image, "Top-News-Images");

                boolean isVideo = image.getContentType() != null &&
                        image.getContentType().startsWith("video");

                if (isVideo) {
                    if (thumbnail != null && !thumbnail.isEmpty()) {
                        updatedThumbnailKey = s3Service.uploadFile(thumbnail, "Thumbnails");
                    }
                } else {
                    if (thumbnail != null && !thumbnail.isEmpty()) {
                        updatedThumbnailKey = s3Service.uploadFile(thumbnail, "Thumbnails");
                    } else {
                        updatedThumbnailKey = null; // your rule
                    }
                }
            }
            else {
                if (thumbnail != null && !thumbnail.isEmpty()) {
                    updatedThumbnailKey = s3Service.uploadFile(thumbnail, "Thumbnails");
                }
            }

            existing.setImage(updatedImageKey);
            existing.setThumbnail(updatedThumbnailKey);
            existing.setTitle(title);
            existing.setUrl(url);
            existing.setTopNewsDate(topNewsDate);
            existing.setNewsDescription(newsDescription);
            existing.setSequence(sequence);


            TopNews updatedNews = topNewsService.saveNews(existing);

            String preSignedUrl = s3Service.generatePresignedUrl(updatedNews.getImage());
            String prePresignedUrl1 = null;

            if (updatedNews.getThumbnail() != null && !updatedNews.getThumbnail().isEmpty()) {
                prePresignedUrl1 = s3Service.generatePresignedUrl(updatedNews.getThumbnail());
            }
            TopNewsResponseDto responseDto = new TopNewsResponseDto(updatedNews.getId(), updatedNews.getTitle(), preSignedUrl,prePresignedUrl1, updatedNews.getUrl(),updatedNews.getTopNewsDate(), updatedNews.getNewsDescription(), updatedNews.getSequence(), updatedNews.getCreatedBy(), updatedNews.getCreationDate(), updatedNews.getLastModifiedBy(), updatedNews.getLastModifiedDate());
            return new ResponseEntity<>(responseDto, HttpStatus.OK);
        } catch (IOException e) {
            e.printStackTrace();
            logger.error("IOException occurred while updating news", e);
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("Unexpected exception while updating news", e);
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @DeleteMapping("/{id}")
    @TrackChange(action = "Deleted", section = "Top News")
    public ResponseEntity<TopNews> deleteNews(@PathVariable Long id) {
        try {
            TopNews result = topNewsService.softDeleteNews(id);
            return (result != null)
                    ? new ResponseEntity<>(result, HttpStatus.OK)
                    : new ResponseEntity<>(HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            logger.error("Error deleting top-news with ID " + id, e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}

