package com.wafer.portal.dto;

public class ActiveModuleResponseDTO {

    private Long id;
    private String moduleName;
    private String moduleCode;
    private Long parentId;
    private Integer moduleLevel;

    public ActiveModuleResponseDTO(Long id,
                                   String moduleName,
                                   String moduleCode,
                                   Long parentId,
                                   Integer moduleLevel) {
        this.id = id;
        this.moduleName = moduleName;
        this.moduleCode = moduleCode;
        this.parentId = parentId;
        this.moduleLevel = moduleLevel;
    }

    // getters
    public Long getId() { return id; }
    public String getModuleName() { return moduleName; }
    public String getModuleCode() { return moduleCode; }
    public Long getParentId() { return parentId; }
    public Integer getModuleLevel() { return moduleLevel; }
}
