package com.wafer.portal.dto;

import java.time.LocalDate;
import java.time.LocalTime;

public class SystemUptimeRequest {

    private LocalDate logDate;
    private LocalTime logStartTime;
    private LocalTime logEndTime;

    public LocalDate getLogDate() {
        return logDate;
    }

    public void setLogDate(LocalDate logDate) {
        this.logDate = logDate;
    }

    public LocalTime getLogStartTime() {
        return logStartTime;
    }

    public void setLogStartTime(LocalTime logStartTime) {
        this.logStartTime = logStartTime;
    }

    public LocalTime getLogEndTime() {
        return logEndTime;
    }

    public void setLogEndTime(LocalTime logEndTime) {
        this.logEndTime = logEndTime;
    }
}