package com.wafer.portal.controller;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.wafer.portal.annotation.TrackChange;
import com.wafer.portal.dto.CoffeeWithLeadersRequest;
import com.wafer.portal.dto.CoffeeWithLeadersResponse;
import com.wafer.portal.model.CoffeeWithLeaders;
import com.wafer.portal.service.CoffeeWithLeadersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@Controller
@RestController
@RequestMapping("/api/v2/coffee-with-leaders")
public class CoffeeWithLeadersController {

    @Autowired
    CoffeeWithLeadersService coffeeWithLeadersService;

    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Added", section = "Coffee with Leaders")
    public ResponseEntity<CoffeeWithLeadersResponse> createCoffeeWithLeaders(
            @RequestParam("image") MultipartFile image,
            @RequestParam(value="thumbnail", required = false) MultipartFile thumbnail,
            @RequestParam("request") String requestJson) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        CoffeeWithLeadersRequest request = mapper.readValue(requestJson, CoffeeWithLeadersRequest.class);
        return coffeeWithLeadersService.uploadCoffeeWithLeaders(image, thumbnail, request);
    }


    @GetMapping("/all")
    public ResponseEntity<Page<CoffeeWithLeadersResponse>> getAll(Pageable pageable) {
        return coffeeWithLeadersService.getAllCoffeeWithLeaders(pageable);
    }

    @GetMapping("/{id}")
    public ResponseEntity<CoffeeWithLeadersResponse> getById(@PathVariable Long id) {
        return coffeeWithLeadersService.getById(id);
    }


    @PutMapping(value = "/{id}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Edited", section = "Coffee with Leaders")
    public ResponseEntity<CoffeeWithLeadersResponse> updateCoffeeWithLeaders(
            @PathVariable Long id,
            @RequestParam(value = "image", required = false) MultipartFile image,
            @RequestParam(value = "thumbnail", required = false) MultipartFile thumbnail,
            @RequestParam("request") String requestJson) throws JsonProcessingException {

        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

        CoffeeWithLeadersRequest request = mapper.readValue(requestJson, CoffeeWithLeadersRequest.class);
        return coffeeWithLeadersService.updateCoffeeWithLeaders(id, image, thumbnail, request);
    }


    @DeleteMapping("/{id}")
    @TrackChange(action = "Deleted", section = "Coffee with Leaders")
    public ResponseEntity<CoffeeWithLeaders> deleteCoffeeWithLeaders(@PathVariable Long id) {
        CoffeeWithLeaders result = coffeeWithLeadersService.deleteCoffeeWithLeaders(id);
        return (result != null)
                ? new ResponseEntity<>(result, HttpStatus.OK)
                : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }


}
