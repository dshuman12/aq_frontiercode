package com.wafer.portal.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.wafer.portal.audit.Auditable;
import jakarta.persistence.*;

import java.io.Serializable;

@Entity
@Table(name = "quick_links_sub_header")
public class QuickLinkSubHeader extends Auditable<String> implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String title;

    private String url;

    @Enumerated(EnumType.STRING)
    @Column(name = "link_type", nullable = false)
    private LinkType linkType;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "parent_id", nullable = false)
    @JsonBackReference
    private QuickLinkHeader header;

    @Column(name = "is_deleted",nullable = false)
    private boolean isDeleted;

    public QuickLinkSubHeader() {
    }

    public QuickLinkSubHeader(String title, QuickLinkHeader header, String url, LinkType linkType) {
        this.title = title;
        this.url = url;
        this.header = header;
        this.linkType = linkType;
        this.isDeleted = false;
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public QuickLinkHeader getHeader() {
        return header;
    }

    public void setHeader(QuickLinkHeader header) {
        this.header = header;
    }

    public LinkType getLinkType() {
        return linkType;
    }

    public void setLinkType(LinkType linkType) {
        this.linkType = linkType;
    }

    public boolean isDeleted() {
        return isDeleted;
    }

    public void setDeleted(boolean deleted) {
        isDeleted = deleted;
    }


}








