package com.wafer.portal.dto;

import jakarta.validation.constraints.NotBlank;

public class AwardsAndRecognitionRequest {
    @NotBlank
    private String title;
    @NotBlank
    private String year;

    private Double sequence;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public Double getSequence() {
        return sequence;
    }

    public void setSequence(Double sequence) {
        this.sequence = sequence;
    }
}