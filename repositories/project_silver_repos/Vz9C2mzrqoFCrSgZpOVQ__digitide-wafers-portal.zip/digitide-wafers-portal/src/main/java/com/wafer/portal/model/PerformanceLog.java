package com.wafer.portal.model;

import com.wafer.portal.audit.Auditable;
import jakarta.persistence.*;

import java.io.Serializable;

@Entity
@Table(name = "performance_logs")
public class PerformanceLog extends Auditable<String> implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name="tracking_id")
    private String trackingId;

    @Column(name="page_name")
    private String pageName;

    @Column(name="api_name")
    private String apiName;

    @Column(name="api_response_time_ms")
    private Integer apiResponseTimeMs;

    @Column(name="page_load_time_ms")
    private Integer pageLoadTimeMs;

    @Column(name="status_code")
    private Integer statusCode;

    private String browser;

    @Column(name="device_type")
    private String deviceType;

    private String os;

    public Long getId() { return id; }

    public String getTrackingId() { return trackingId; }

    public void setTrackingId(String trackingId) { this.trackingId = trackingId; }

    public String getPageName() { return pageName; }

    public void setPageName(String pageName) { this.pageName = pageName; }

    public String getApiName() { return apiName; }

    public void setApiName(String apiName) { this.apiName = apiName; }

    public Integer getApiResponseTimeMs() { return apiResponseTimeMs; }

    public void setApiResponseTimeMs(Integer apiResponseTimeMs) { this.apiResponseTimeMs = apiResponseTimeMs; }

    public Integer getPageLoadTimeMs() { return pageLoadTimeMs; }

    public void setPageLoadTimeMs(Integer pageLoadTimeMs) { this.pageLoadTimeMs = pageLoadTimeMs; }

    public Integer getStatusCode() { return statusCode; }

    public void setStatusCode(Integer statusCode) { this.statusCode = statusCode; }

    public String getBrowser() { return browser; }

    public void setBrowser(String browser) { this.browser = browser; }

    public String getDeviceType() { return deviceType; }

    public void setDeviceType(String deviceType) { this.deviceType = deviceType; }

    public String getOs() { return os; }

    public void setOs(String os) { this.os = os; }
}