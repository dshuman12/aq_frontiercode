package com.wafer.portal.repository;

import com.wafer.portal.model.Roles;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RoleRepository extends JpaRepository<Roles,Long> {

    Roles findByName(String roleName);

    List<Roles> findByIsDeletedFalse();

    List<Roles> findByIdIn(List<Long> ids);


}
