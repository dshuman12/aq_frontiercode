package com.wafer.portal.repository;

import com.wafer.portal.model.HelpAndSupportDocument;
import com.wafer.portal.model.People;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface HelpAndSupportDocumentRepository extends JpaRepository<HelpAndSupportDocument, Long> {

    Optional<HelpAndSupportDocument> findByIdAndIsDeletedFalse(Long id);

    Page<HelpAndSupportDocument> findAllByIsDeletedFalseOrderBySequenceAsc(Pageable pageable);

    Page<HelpAndSupportDocument> findByIsDeletedFalse(Pageable pageable);

    @Query("SELECT h FROM HelpAndSupportDocument h WHERE h.isDeleted = false AND (" +
            "LOWER(h.description) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    Page<HelpAndSupportDocument> searchHelpAndSupport(@Param("keyword") String keyword, Pageable pageable);


}