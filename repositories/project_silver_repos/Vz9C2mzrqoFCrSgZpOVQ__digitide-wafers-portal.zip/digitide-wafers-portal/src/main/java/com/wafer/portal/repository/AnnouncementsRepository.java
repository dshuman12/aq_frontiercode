package com.wafer.portal.repository;

import com.wafer.portal.model.Announcements;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface AnnouncementsRepository extends JpaRepository<Announcements, Long> {
    Page<Announcements> findByIsDeletedFalse(Pageable pageable);
    Optional<Announcements> findByIdAndIsDeletedFalse(Long aLong);

    @Query("SELECT a FROM Announcements a " +
            "WHERE a.isDeleted = false AND " +
            "(LOWER(a.content) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
            "OR LOWER(a.url) LIKE LOWER(CONCAT('%', :keyword, '%'))) ")
    Page<Announcements> searchAnnouncements(@Param("keyword") String keyword,Pageable pageable);

    @Query("SELECT a FROM Announcements a WHERE a.isDeleted = false ORDER BY " +
            "CASE WHEN a.sequence IS NULL THEN 1 ELSE 0 END, a.sequence ASC")
    Page<Announcements> findAllOrderedBySequence(Pageable pageable);

}
