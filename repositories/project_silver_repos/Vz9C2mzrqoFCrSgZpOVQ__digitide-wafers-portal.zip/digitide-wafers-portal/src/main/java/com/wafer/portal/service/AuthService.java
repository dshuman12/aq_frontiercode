package com.wafer.portal.service;

import com.wafer.portal.config.JwtAuthFilter;
import com.wafer.portal.config.JwtTokenProvider;
import com.wafer.portal.dto.ApiResponse;
import com.wafer.portal.dto.LoginRequest;
import com.wafer.portal.dto.UserRequest;
import com.wafer.portal.dto.response.BasicResponse;
import com.wafer.portal.dto.response.RoleResponse;
import com.wafer.portal.dto.response.UserResponse;
import com.wafer.portal.exception.ResourceNotFoundException;
import com.wafer.portal.model.Roles;
import com.wafer.portal.model.User;
import com.wafer.portal.repository.RoleRepository;
import com.wafer.portal.repository.UserRepository;
import com.wafer.portal.utils.CookieUtils;
import com.wafer.portal.utils.ResponseFormatUtils;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class AuthService {
    private static final Logger logger = LoggerFactory.getLogger(AuthService.class);

    private final AuthenticationManager authenticationManager;
    private final JwtTokenProvider tokenProvider;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final CookieUtils cookieUtils;
    private final RoleRepository roleRepository;

    public AuthService(AuthenticationManager authenticationManager, JwtTokenProvider tokenProvider, UserRepository userRepository, PasswordEncoder passwordEncoder, CookieUtils cookieUtils, RoleRepository roleRepository) {
        this.authenticationManager = authenticationManager;
        this.tokenProvider = tokenProvider;
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.cookieUtils = cookieUtils;
        this.roleRepository = roleRepository;
    }

    public ApiResponse authenticateUser(LoginRequest loginRequest, HttpServletResponse response) {
        String identifier = sanitizeInput(loginRequest.getIdentifier());
        String password = loginRequest.getPassword();

        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(identifier, password)
        );

        SecurityContextHolder.getContext().setAuthentication(authentication);

        String jwt = tokenProvider.generateTokenByAuth(authentication);
        cookieUtils.addJwtCookie(response, jwt);

        User user = (User) authentication.getPrincipal();
        Map<String, Object> data = new HashMap<>();
        data.put("id", user.getId());
        data.put("roles", user.getRoles());
        data.put("name", user.getUserName());
        data.put("designation", user.getDesignation());
        data.put("employeeId", user.getEmployeeId());

        return new ApiResponse(true, "User logged in successfully!", data);
    }



    @Transactional
    public ApiResponse registerUser(User user) {
        user.setEmployeeId(sanitizeInput(user.getEmployeeId()));
        user.setEmail(sanitizeInput(user.getEmail()));

        if (userRepository.existsByEmployeeId(user.getEmployeeId())) {
            return new ApiResponse(false, "Employee ID is already taken!");
        }

        if (userRepository.existsByEmail(user.getEmail())) {
            return new ApiResponse(false, "Email Address already in use!");
        }

        user.setPassword(passwordEncoder.encode(user.getPassword()));

        // Assigning default role 'User'
        Set<String> roles = new HashSet<>();
        roles.add("User");
//        user.setRoles(roles);

        userRepository.save(user);

        return new ApiResponse(true, "User registered successfully!");
    }

    public Page<User> getAllUsers(Pageable pageable) {
        return userRepository.findAll(pageable);
    }


@Transactional
public ApiResponse updateUserRole(Long userId, List<Long> newRoleIds, HttpServletResponse response) {
    // Fetch user by ID
    User user = userRepository.findById(userId)
            .orElseThrow(() -> new ResourceNotFoundException("User not found with ID: " + userId));


    List<Roles> roles = roleRepository.findByIdIn(newRoleIds);

    if (roles.isEmpty()) {
        return new ApiResponse(false, "No valid roles found for the provided role IDs.");
    }


    Set<String> allowedRoles = Set.of("User", "Admin", "SuperAdmin");
    for (Roles role : roles) {
        if (!allowedRoles.contains(role.getName())) {
            return new ApiResponse(false, "Invalid role: " + role.getName() + ". Allowed roles are User, Admin, SuperAdmin.");
        }
    }

    user.setRoles(new ArrayList<>(new HashSet<>(roles))); // remove duplicates if any
    userRepository.save(user);

    return new ApiResponse(true, "User roles successfully updated for user ID: " + userId);
}

    public ApiResponse logoutUser(String authHeader, HttpServletResponse response) {
        // Clear JWT cookie (if any)
        cookieUtils.clearJwtCookie(response);

        // Extract token if present
        String token = null;
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            token = authHeader.substring(7);
        }

        if (token != null) {
            // Optional: blacklist/expire the token if you’re maintaining token invalidation
            logger.info("Logging out user with token: {}", token);
        }

        // Clear Spring Security context
        SecurityContextHolder.clearContext();

        return new ApiResponse(true, "User logged out successfully!");
    }

    private String sanitizeInput(String input) {
        if (input == null) {
            return null;
        }
        return input.trim();
    }

    public BasicResponse<?> getRoleList() {
        BasicResponse<List<RoleResponse>> response = new BasicResponse<>();

        List<Roles> roles = Optional.ofNullable(
                roleRepository.findByIsDeletedFalse()
        ).orElse(Collections.emptyList());

        List<RoleResponse> roleResponses = roles.stream()
                .map(r -> new RoleResponse(r.getId(), r.getName()))
                .collect(Collectors.toList());

        response.setData(roleResponses);
        response.setStatusCode(HttpStatus.OK.value());
        return ResponseFormatUtils.createSuccessResponse(response, "Role List Retrieved Successfully");

    }
    public BasicResponse<?> addUser(UserRequest request) {
        logger.info("user entry");
        BasicResponse<Object> response = new BasicResponse<>();

        try {
            // Check if email already exists
            if (userRepository.findByEmailAndIsDeletedFalse(request.getEmail()).isPresent()) {
                logger.info("user entry2");
                response.setStatusCode(HttpStatus.CONFLICT.value());
                response.setMessage("Email already exists!");
                return response;
            }

            // Fetch roles
            List<Roles> roles = roleRepository.findByIdIn(request.getRoleIds());

            // Create new user
            User user = new User();
            user.setUserName(request.getUserName());
            user.setEmail(request.getEmail());
            user.setRoles(roles);

            logger.info("user data : {}, {}, {}", user.getUserName(), user.getEmail(), user.getRoles());

            // Save user
            User savedUser = userRepository.save(user);

            // Create clean response object
            UserResponse userResponse = new UserResponse(savedUser);

            // Success response
            response.setStatusCode(HttpStatus.CREATED.value());
            response.setMessage("User created successfully");
            response.setData(userResponse);  // Set the clean UserResponse instead of User entity

            logger.info("user saved successfully: {}", response.getData());
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("Error while creating user", e);
            response.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
            response.setMessage("Failed to create user: " + e.getMessage());
        }

        return response;
    }

    public BasicResponse<?> getPageableUsers(int pageNo, int pageSize, String sortByField, String sortDirection, String search) {
        BasicResponse<Object> response = new BasicResponse<>();
        try {
            Sort sort = sortDirection.equalsIgnoreCase("asc")
                    ? Sort.by(sortByField).ascending()
                    : Sort.by(sortByField).descending();

            Pageable pageable = PageRequest.of(pageNo, pageSize, sort);

            Page<User> usersPage;
            if (search != null && !search.isEmpty()) {
                usersPage = userRepository.findByUserNameContainingIgnoreCaseAndIsDeletedFalse(search, pageable);
            } else {
                usersPage = userRepository.findAllByIsDeletedFalse(pageable);
            }

            // Convert User -> UserResponse
            Page<UserResponse> userResponses = usersPage.map(UserResponse::new);

            response.setStatusCode(HttpStatus.OK.value());
            response.setMessage("Users retrieved successfully");
            response.setData(userResponses);

        } catch (Exception e) {
            e.printStackTrace();
            response.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
            response.setMessage("Failed to retrieve users: " + e.getMessage());
        }
        return response;
    }

    @Transactional
    public ApiResponse deleteUser(Long userId) {
        User user = userRepository.findByIdAndIsDeletedFalse(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with ID: " + userId));

        user.setDeleted(true);
        userRepository.save(user);
        return new ApiResponse(true, "User deleted successfully.");
    }



}