package com.wafer.portal.controller;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.wafer.portal.awsS3.S3Service;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.net.URL;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/upload-check")
public class UploadController {

    @Autowired
    private S3Service s3Service;

    @PostMapping(value = "/bulk-upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @Operation(summary = "Uploads the portfolio invoices in bulk and returns presigned URL.")
    public ResponseEntity<?> bulkUpload(@RequestPart("file") MultipartFile file) throws IOException {
        try {
            if (file == null || file.isEmpty()) {
                return ResponseEntity.badRequest().body("File is missing or empty");
            }

            // Generate an S3 object path (you can adjust based on requirement)
            String objectPath = "portfolio-invoices/" + UUID.randomUUID() + "_" + file.getOriginalFilename();

            // Call S3 service to generate presigned upload URL
            String presignedUrl = s3Service.generatePresignedUrlUpload(objectPath);

            if (presignedUrl == null) {
                return ResponseEntity.internalServerError().body("Could not generate presigned URL");
            }

            // You may also want to return the object path (so frontend knows where to PUT the file)
            Map<String, String> response = new HashMap<>();
            response.put("uploadUrl", presignedUrl);
            response.put("objectPath", objectPath);

            return ResponseEntity.ok(response);


        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Upload failed: " + e.getMessage());
        }
    }
}
