package com.wafer.portal.controller;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wafer.portal.annotation.TrackChange;
import com.wafer.portal.dto.CompanyInfoRequest;
import com.wafer.portal.dto.CompanyInfoResponse;
import com.wafer.portal.model.CompanyInfo;
import com.wafer.portal.service.CompanyInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@Controller
@RestController
@RequestMapping("/api/v2/company-info")
public class CompanyInfoController {

    private final CompanyInfoService companyInfoService;

    @Autowired
    public CompanyInfoController(CompanyInfoService companyInfoService) {
        this.companyInfoService = companyInfoService;
    }

    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Added", section = "Company Info")
    public ResponseEntity<CompanyInfoResponse> createCompanyInfo(
            @RequestParam("image") MultipartFile image,
            @RequestParam("request") String requestJson) throws JsonProcessingException {
        CompanyInfoRequest request = new ObjectMapper().readValue(requestJson, CompanyInfoRequest.class);
        return companyInfoService.createCompanyInfo(image, request);
    }


    @GetMapping("/all")
    public ResponseEntity<Page<CompanyInfoResponse>> getAllLeadership(Pageable pageable) {
        return companyInfoService.getAllCompanyInfo(pageable);
    }

    @GetMapping("/{id}")
    public ResponseEntity<CompanyInfoResponse> getLeadershipById(@PathVariable Long id) {
        return companyInfoService.getCompanyInfoById(id);
    }


    @PutMapping(value = "/{id}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @TrackChange(action = "Edited", section = "Company Info")
    public ResponseEntity<CompanyInfoResponse> updateCompanyInfo(
            @PathVariable Long id,
            @RequestParam(value = "image", required = false) MultipartFile image,
            @RequestParam("request") String requestJson) throws JsonProcessingException {

        CompanyInfoRequest request = new ObjectMapper().readValue(requestJson, CompanyInfoRequest.class);
        return companyInfoService.updateCompanyInfo(id, image, request);
    }


    @DeleteMapping("/{id}")
    @TrackChange(action = "Deleted", section = "Company Info")
    public ResponseEntity<CompanyInfo> deleteCompanyinfo(@PathVariable Long id) {
        CompanyInfo result = companyInfoService.deleteCompanyInfo(id);
        return (result != null)
                ? new ResponseEntity<>(result, HttpStatus.OK)
                : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }


}

