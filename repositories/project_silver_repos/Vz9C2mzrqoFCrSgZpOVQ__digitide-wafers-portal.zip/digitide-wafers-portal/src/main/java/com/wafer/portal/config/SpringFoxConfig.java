package com.wafer.portal.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

import java.util.List;

@Configuration
public class SpringFoxConfig {
    @Bean
    public Docket api() {
        return new Docket(DocumentationType.SWAGGER_2)
                .select()
                .apis(RequestHandlerSelectors.any())
                .paths(PathSelectors.any())
                .build();
    }

    @Bean
    public OpenAPI customizeOpenAPI() {
        final String securitySchemeName = "bearerAuth";
        final String trackingScheme = "trackingId";
        return new OpenAPI()
                .servers(List.of(new Server().url("http://localhost:8080"),
                        new Server().url("https://wafersedge-dev-api.digitide.com/"),
                        new Server().url("https://wafersedge-uat-api.digitide.com/"),
                        new Server().url("https://wafers-api.digitide.com/")))
                .addSecurityItem(new SecurityRequirement()
                        .addList(securitySchemeName))
                .addSecurityItem(new SecurityRequirement()
                        .addList(trackingScheme))
                .components(new Components()
                        .addSecuritySchemes(securitySchemeName, new SecurityScheme()
                                .name(securitySchemeName)
                                .type(SecurityScheme.Type.HTTP)
                                .scheme("bearer")
                                .description("Provide the JWT token")
                                .bearerFormat("JWT"))
                .addSecuritySchemes(trackingScheme, new SecurityScheme()
                        .name("trackingId")
                        .type(SecurityScheme.Type.APIKEY)
                        .in(SecurityScheme.In.HEADER)
                        .description("tracking ID in header"))
                )

                .info(new Info()
                        .title("Wafer Portal")
                        .version("1.0")
                        .description("description"));
    }




    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }



    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                String[] allowedOrigins = new String[] {
                        "https://wafersedge-dev.digitide.com/",
                        "https://wafersedge-dev-api.digitide.com/",
                        "https://wafersedge-uat-api.digitide.com/",
                        "https://wafers-api.digitide.com/"


                };
                registry.addMapping("/**")
                        .allowedOrigins(allowedOrigins)
                        .allowedHeaders("*")
                        .allowedOriginPatterns("*")
                        .allowedMethods("HEAD", "GET", "PUT", "POST", "PATCH", "DELETE", "OPTIONS");
            }
        };
    }


}

