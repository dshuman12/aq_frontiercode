package com.wafer.portal.service;

import com.wafer.portal.awsS3.S3Service;
import com.wafer.portal.dto.*;
import com.wafer.portal.model.RewardsSection;
import com.wafer.portal.model.RewardsSubsection;
import com.wafer.portal.model.RewardsandRecognition;
import com.wafer.portal.repository.RewardsSectionRepository;
import com.wafer.portal.repository.RewardsSubsectionRepository;
import com.wafer.portal.repository.RewardsandRecognitionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class RewardsandRecognitionService {

    private static final String RewardsandRecognition_FOLDER = "Rewards-Images"; // New S3 folder name

    private final RewardsandRecognitionRepository RewardsandRecognitionRepository;
    private final S3Service s3Service;

    private final RewardsSectionRepository rewardsSectionRepository;
    private final RewardsSubsectionRepository rewardsSubsectionRepository;

    @Autowired
    public RewardsandRecognitionService(RewardsandRecognitionRepository RewardsandRecognitionRepository, S3Service s3Service, RewardsSectionRepository rewardsSectionRepository, RewardsSubsectionRepository rewardsSubsectionRepository) {
        this.RewardsandRecognitionRepository = RewardsandRecognitionRepository;
        this.s3Service = s3Service;
        this.rewardsSectionRepository = rewardsSectionRepository;
        this.rewardsSubsectionRepository = rewardsSubsectionRepository;
    }


    public ResponseEntity<RewardsandRecognitionResponse> createRewardsandRecognition(MultipartFile image, RewardsandRecognitionRequest request) {
        try {
            if (image.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
            }
            String imageKey = s3Service.uploadFile(image, RewardsandRecognition_FOLDER);
            RewardsandRecognition rewardsandrecognition = new RewardsandRecognition(request.getName(), request.getDesignation(), request.getDescription(), imageKey, request.getLocation(), request.getNameOfAward(), request.getSequence(), request.getSectionId(), request.getSubsectionId());

            RewardsandRecognition saved = RewardsandRecognitionRepository.save(rewardsandrecognition);

            return new ResponseEntity<>(mapToResponseDto(saved), HttpStatus.CREATED);
        } catch (IOException e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Page<RewardsandRecognitionResponse>> getAllRewardsandRecognition(Pageable pageable) {
        Page<RewardsandRecognition> newsPage = RewardsandRecognitionRepository.findAllOrderedBySequence(pageable);
        Page<RewardsandRecognitionResponse> dtoPage = newsPage.map(this::mapToResponseDto);
        return dtoPage.isEmpty() ? new ResponseEntity<>(HttpStatus.NO_CONTENT) : new ResponseEntity<>(dtoPage, HttpStatus.OK);
    }

    public ResponseEntity<RewardsandRecognitionResponse> getRewardsandRecognitionById(Long id) {
        return RewardsandRecognitionRepository.findByIdAndIsDeletedFalse(id)
                .map(RewardsandRecognition -> new ResponseEntity<>(mapToResponseDto(RewardsandRecognition), HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    public ResponseEntity<RewardsandRecognitionResponse> updateRewardsandRecognition(Long id,MultipartFile image, RewardsandRecognitionRequest request) {
        return (ResponseEntity<RewardsandRecognitionResponse>) RewardsandRecognitionRepository.findByIdAndIsDeletedFalse(id)
                .map(existingRewardsandRecognition -> {
                    try {
                        if (image != null && !image.isEmpty()) {
                            String newImageKey = s3Service.updateFile(existingRewardsandRecognition.getImage(), image, RewardsandRecognition_FOLDER);
                            existingRewardsandRecognition.setImage(newImageKey);
                        }

                        existingRewardsandRecognition.setName(request.getName());
                        existingRewardsandRecognition.setDesignation(request.getDesignation());
                        existingRewardsandRecognition.setSequence(request.getSequence());
                        existingRewardsandRecognition.setDescription(request.getDescription());
                        existingRewardsandRecognition.setLocation(request.getLocation());
                        existingRewardsandRecognition.setNameOfAward(request.getNameOfAward());
                        if (request.getSectionId() != null) {
                            existingRewardsandRecognition.setSectionId(request.getSectionId());
                        }
                        if (request.getSubsectionId() != null) {
                            existingRewardsandRecognition.setSubsectionId(request.getSubsectionId());
                        }
                        RewardsandRecognition updated = RewardsandRecognitionRepository.save(existingRewardsandRecognition);
                        return new ResponseEntity<>(mapToResponseDto(updated), HttpStatus.OK);
                    } catch (IOException e) {
                        return new ResponseEntity<RewardsandRecognitionResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
                    }
                })
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    public RewardsandRecognition deleteRewardsandRecognition(Long id) {
        return RewardsandRecognitionRepository.findByIdAndIsDeletedFalse(id)
                .map(ls -> {
                    ls.setDeleted(true);
                    return RewardsandRecognitionRepository.save(ls);
                }).orElse(null);
    }

//    public List<GroupedRewardsResponse> getGroupedRewards() {
//        List<RewardsandRecognition> allRewards = RewardsandRecognitionRepository.findByIsDeletedFalse();
//
//        Map<Long, String> sectionMap = rewardsSectionRepository.findByIsDeletedFalse()
//                .stream().collect(Collectors.toMap(RewardsSection::getId, RewardsSection::getSectionName));
//
//        Map<Long, String> subMap = rewardsSubsectionRepository.findByIsDeletedFalse()
//                .stream().collect(Collectors.toMap(RewardsSubsection::getId, RewardsSubsection::getSubsectionName));
//
//        return allRewards.stream()
//                // FIX: Handle null sectionId by mapping it to -1L
//                .collect(Collectors.groupingBy(r -> r.getSectionId() == null ? -1L : r.getSectionId()))
//                .entrySet().stream()
//                .map(sectionEntry -> {
//                    Long sId = sectionEntry.getKey();
//
//                    // Group by subsectionId
//                    List<GroupedRewardsResponse.SubsectionGroupDto> subGroups = sectionEntry.getValue().stream()
//                            // FIX: Handle null subsectionId by mapping it to -1L
//                            .collect(Collectors.groupingBy(r -> r.getSubsectionId() == null ? -1L : r.getSubsectionId()))
//                            .entrySet().stream()
//                            .map(subEntry -> new GroupedRewardsResponse.SubsectionGroupDto(
//                                    subEntry.getKey(),
//                                    subMap.getOrDefault(subEntry.getKey(), "General"),
//                                    subEntry.getValue().stream().map(this::mapToResponseDto).collect(Collectors.toList())
//                            )).collect(Collectors.toList());
//
//                    return new GroupedRewardsResponse(sId, sectionMap.getOrDefault(sId, "Other"), subGroups);
//                }).collect(Collectors.toList());
//    }

    public ResponseEntity<Page<GroupedRewardsResponse>> getGroupedRewards(Pageable pageable) {

        // 1️⃣ Paginate SECTIONS
        Page<RewardsSection> sectionPage =
                rewardsSectionRepository.findByIsDeletedFalse(pageable);

        if (sectionPage.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }

        int limit = pageable.getPageSize();

        // 2️⃣ Load ALL rewards
        List<RewardsandRecognition> allRewards =
                RewardsandRecognitionRepository.findByIsDeletedFalse();

        // 3️⃣ Load subsection map
        Map<Long, String> subMap = rewardsSubsectionRepository.findByIsDeletedFalse()
                .stream()
                .collect(Collectors.toMap(
                        RewardsSubsection::getId,
                        RewardsSubsection::getSubsectionName
                ));

        List<GroupedRewardsResponse> groupedResponses = new java.util.ArrayList<>();

        // 4️⃣ Build response for EACH SECTION
        for (RewardsSection section : sectionPage.getContent()) {

            List<GroupedRewardsResponse.SubsectionGroupDto> subGroups =
                    allRewards.stream()
                            .filter(r ->
                                    r.getSectionId() != null &&
                                            r.getSectionId().equals(section.getId())
                            )
                            .collect(Collectors.groupingBy(
                                    r -> r.getSubsectionId() == null ? -1L : r.getSubsectionId()
                            ))
                            .entrySet().stream()
                            .sorted(Map.Entry.comparingByKey())
                            .limit(limit)
                            .map(entry ->
                                    new GroupedRewardsResponse.SubsectionGroupDto(
                                            entry.getKey(),
                                            subMap.getOrDefault(entry.getKey(), "General"),
                                            entry.getValue().stream()
                                                    .sorted(SEQUENCE_COMPARATOR)
                                                    .limit(limit)
                                                    .map(this::mapToResponseDto)
                                                    .collect(Collectors.toList())
                                    )
                            )
                            .collect(Collectors.toList());

            groupedResponses.add(
                    new GroupedRewardsResponse(
                            section.getId(),
                            section.getSectionName(),
                            subGroups
                    )
            );
        }

        // 5️⃣ Handle rewards WITHOUT sectionId (GLOBAL / GENERAL)
        List<RewardsandRecognition> noSectionRewards =
                allRewards.stream()
                        .filter(r -> r.getSectionId() == null)
                        .collect(Collectors.toList());

        if (!noSectionRewards.isEmpty()) {

            List<GroupedRewardsResponse.SubsectionGroupDto> generalSubGroups =
                    noSectionRewards.stream()
                            .collect(Collectors.groupingBy(
                                    r -> r.getSubsectionId() == null ? -1L : r.getSubsectionId()
                            ))
                            .entrySet().stream()
                            .sorted(Map.Entry.comparingByKey())
                            .limit(limit)
                            .map(entry ->
                                    new GroupedRewardsResponse.SubsectionGroupDto(
                                            entry.getKey(),
                                            subMap.getOrDefault(entry.getKey(), "General"),
                                            entry.getValue().stream()
                                                    .sorted(SEQUENCE_COMPARATOR)
                                                    .limit(limit)
                                                    .map(this::mapToResponseDto)
                                                    .collect(Collectors.toList())
                                    )
                            )
                            .collect(Collectors.toList());

            groupedResponses.add(
                    new GroupedRewardsResponse(
                            -1L,
                            "General",
                            generalSubGroups
                    )
            );
        }

        // 6️⃣ Wrap into Page
        Page<GroupedRewardsResponse> responsePage =
                new PageImpl<>(groupedResponses, pageable, sectionPage.getTotalElements());

        return new ResponseEntity<>(responsePage, HttpStatus.OK);
    }


    public ResponseEntity<RewardsSectionResponse> addSection(RewardsSectionRequest request) {
        if (request.getSectionName() == null || request.getSectionName().isBlank()) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

        Optional<RewardsSection> exists = rewardsSectionRepository
                .findBySectionNameIgnoreCaseAndIsDeletedFalse(request.getSectionName());
        if (exists.isPresent()) {
            return new ResponseEntity<>(HttpStatus.CONFLICT);
        }

        RewardsSection section = new RewardsSection();
        section.setSectionName(request.getSectionName());
        RewardsSection saved = rewardsSectionRepository.save(section);

        RewardsSectionResponse response = new RewardsSectionResponse(saved.getId(), saved.getSectionName());
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    public ResponseEntity<RewardsSubsectionResponse> addSubsection(RewardsSubsectionRequest request) {
        if (request.getSubsectionName() == null || request.getSubsectionName().isBlank()) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

        // Check for duplicate name globally since they aren't tied to a section
        Optional<RewardsSubsection> exists = rewardsSubsectionRepository
                .findBySubsectionNameIgnoreCaseAndIsDeletedFalse(request.getSubsectionName());

        if (exists.isPresent()) {
            return new ResponseEntity<>(HttpStatus.CONFLICT);
        }

        RewardsSubsection sub = new RewardsSubsection();
        sub.setSubsectionName(request.getSubsectionName());
        RewardsSubsection saved = rewardsSubsectionRepository.save(sub);

        RewardsSubsectionResponse response = new RewardsSubsectionResponse(saved.getId(), saved.getSubsectionName());
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    public ResponseEntity<Page<RewardsSection>> getAllSections(Pageable pageable) {
        Page<RewardsSection> page = rewardsSectionRepository.findByIsDeletedFalse(pageable);

        return page.isEmpty()
                ? new ResponseEntity<>(HttpStatus.NO_CONTENT)
                : new ResponseEntity<>(page, HttpStatus.OK);
    }

    public ResponseEntity<Page<RewardsSubsection>> getAllSubsections(Pageable pageable) {
        Page<RewardsSubsection> page = rewardsSubsectionRepository.findByIsDeletedFalse(pageable);

        return page.isEmpty()
                ? new ResponseEntity<>(HttpStatus.NO_CONTENT)
                : new ResponseEntity<>(page, HttpStatus.OK);
    }


    private static final Comparator<RewardsandRecognition> SEQUENCE_COMPARATOR =
            Comparator.comparing(
                    RewardsandRecognition::getSequence,
                    Comparator.nullsLast(Comparator.naturalOrder())
            );

    public ResponseEntity<RewardsSectionResponse> updateSection(Long id, RewardsSectionRequest request) {
        return rewardsSectionRepository.findById(id)
                .map(existingSection -> {
                    if (existingSection.isDeleted()) {
                        return new ResponseEntity<RewardsSectionResponse>(HttpStatus.NOT_FOUND);
                    }

                    if (request.getSectionName() == null || request.getSectionName().isBlank()) {
                        return new ResponseEntity<RewardsSectionResponse>(HttpStatus.BAD_REQUEST);
                    }

                    Optional<RewardsSection> conflict = rewardsSectionRepository
                            .findBySectionNameIgnoreCaseAndIsDeletedFalse(request.getSectionName());

                    if (conflict.isPresent() && !conflict.get().getId().equals(id)) {
                        return new ResponseEntity<RewardsSectionResponse>(HttpStatus.CONFLICT);
                    }

                    existingSection.setSectionName(request.getSectionName());
                    RewardsSection saved = rewardsSectionRepository.save(existingSection);
                    return ResponseEntity.ok(new RewardsSectionResponse(saved.getId(), saved.getSectionName()));
                })
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    public ResponseEntity<RewardsSubsectionResponse> updateSubsection(Long id, RewardsSubsectionRequest request) {
        return rewardsSubsectionRepository.findById(id)
                .map(existingSub -> {
                    if (existingSub.isDeleted()) {
                        return new ResponseEntity<RewardsSubsectionResponse>(HttpStatus.NOT_FOUND);
                    }

                    if (request.getSubsectionName() == null || request.getSubsectionName().isBlank()) {
                        return new ResponseEntity<RewardsSubsectionResponse>(HttpStatus.BAD_REQUEST);
                    }

                    Optional<RewardsSubsection> conflict = rewardsSubsectionRepository
                            .findBySubsectionNameIgnoreCaseAndIsDeletedFalse(request.getSubsectionName());

                    if (conflict.isPresent() && !conflict.get().getId().equals(id)) {
                        return new ResponseEntity<RewardsSubsectionResponse>(HttpStatus.CONFLICT);
                    }

                    existingSub.setSubsectionName(request.getSubsectionName());
                    RewardsSubsection saved = rewardsSubsectionRepository.save(existingSub);
                    return ResponseEntity.ok(new RewardsSubsectionResponse(saved.getId(), saved.getSubsectionName()));
                })
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }



    private RewardsandRecognitionResponse mapToResponseDto(RewardsandRecognition saved) {

        String sectionName = "Unknown Section";
        if (saved.getSectionId() != null) {
            sectionName = rewardsSectionRepository.findById(saved.getSectionId())
                    .map(RewardsSection::getSectionName)
                    .orElse("Unknown Section");
        }

        String subsectionName = "General";
        if (saved.getSubsectionId() != null) {
            subsectionName = rewardsSubsectionRepository.findById(saved.getSubsectionId())
                    .map(RewardsSubsection::getSubsectionName)
                    .orElse("General");
        }

        String preSignedUrl = s3Service.generatePresignedUrl(saved.getImage());

        return new RewardsandRecognitionResponse(
                saved.getId(),
                saved.getName(),
                saved.getDesignation(),
                saved.getDescription(),
                preSignedUrl,
                saved.getLocation(),
                saved.getNameOfAward(),
                saved.getSequence(),
                saved.getSectionId(),
                saved.getSubsectionId(),
                sectionName,
                subsectionName,
                saved.getCreatedBy(),
                saved.getCreationDate(),
                saved.getLastModifiedBy(),
                saved.getLastModifiedDate()
        );
    }
}