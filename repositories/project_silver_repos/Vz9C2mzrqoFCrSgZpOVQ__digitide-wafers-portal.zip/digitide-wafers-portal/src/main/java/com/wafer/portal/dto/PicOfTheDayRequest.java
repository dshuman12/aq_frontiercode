package com.wafer.portal.dto;

import jakarta.validation.constraints.NotBlank;

public class PicOfTheDayRequest {
    @NotBlank
    private String title;

    private String designation;

    private String place;

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }
}
