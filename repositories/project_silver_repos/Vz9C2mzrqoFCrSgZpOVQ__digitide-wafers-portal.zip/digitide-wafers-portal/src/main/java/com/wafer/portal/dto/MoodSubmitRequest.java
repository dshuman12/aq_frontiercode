package com.wafer.portal.dto;

import com.wafer.portal.model.DailyMood;
import jakarta.validation.constraints.NotNull;

public class MoodSubmitRequest {
    @NotNull(message = "Mood cannot be null")
    private DailyMood.Mood mood;

    public DailyMood.Mood getMood() {
        return mood;
    }

    public void setMood(DailyMood.Mood mood) {
        this.mood = mood;
    }
}