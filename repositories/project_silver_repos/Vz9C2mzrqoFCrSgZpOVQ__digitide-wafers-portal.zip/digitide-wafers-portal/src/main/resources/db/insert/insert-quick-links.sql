WITH inserted_header AS (
  INSERT INTO quick_links_header (title, url, is_deleted)
  VALUES ('Code of Conduct', NULL, false)
  RETURNING id
)
INSERT INTO quick_links_sub_header (title, url, parent_id, is_deleted)
SELECT sub.title, sub.url, h.id, false
FROM inserted_header h,
     (VALUES
        ('Code of Conduct', 'https://digi-wafer-live.s3.ap-south-1.amazonaws.com/Doc/Code+of+Conduct+Policy.pdf'),
        ('Business Compliance Policy', 'https://digi-wafer-live.s3.ap-south-1.amazonaws.com/Doc/Business+Compliance+Policy.pdf'),
        ('Whistle-Blower Policy', 'https://digi-wafer-live.s3.ap-south-1.amazonaws.com/Doc/Whistle+Blower+Policy.pdf'),
        ('POSH Policy', 'https://digi-wafer-live.s3.ap-south-1.amazonaws.com/Doc/POSH+Policy.pdf')
     ) AS sub(title, url);



INSERT INTO quick_links_header (title, url, is_deleted)
VALUES ('Coffee With Leaders', '/site-under-construction', false);



INSERT INTO quick_links_header (title, url, is_deleted)
VALUES ('Employee Newsletter', '/site-under-construction', false);



INSERT INTO quick_links_header (title, url, is_deleted)
VALUES ('Career Site', 'https://iaceiz.fa.ocs.oraclecloud.com/hcmUI/CandidateExperience/en/sites/CX_1/?mode=location', false);


WITH inserted_header AS (
  INSERT INTO quick_links_header (title, url, is_deleted)
  VALUES ('Employee Policies', NULL, false)
  RETURNING id
)
INSERT INTO quick_links_sub_header (title, url, parent_id, is_deleted)
SELECT sub.title, sub.url, h.id, false
FROM inserted_header h,
     (VALUES
        ('Anti Bribery', 'https://digi-wafer-live.s3.ap-south-1.amazonaws.com/Doc/Anti+Bribery+and+Corruption+Policy.pdf'),
        ('Conflict of Interest', 'https://digi-wafer-live.s3.ap-south-1.amazonaws.com/Doc/Conflict+of+Interest+Policy.pdf'),
        ('Consensual', '/site-under-construction'),
        ('Dress Code', 'https://digi-wafer-live.s3.ap-south-1.amazonaws.com/Doc/Dress+Code+Policy.pdf'),
        ('Employee Referral', 'https://digi-wafer-live.s3.ap-south-1.amazonaws.com/Doc/Employee+Referral+Policy+.pdf'),
        ('Equal Employment', 'https://digi-wafer-live.s3.ap-south-1.amazonaws.com/Doc/Equal+Employment+Policy.pdf'),
        ('Gift Entertainment', 'https://digi-wafer-live.s3.ap-south-1.amazonaws.com/Doc/Gift+entertainment+%26+other+expenses+Policy.pdf'),
        ('Gratuity', 'https://digi-wafer-live.s3.ap-south-1.amazonaws.com/Doc/Gratuity+Policy.pdf'),
        ('Leave Policy', 'https://digi-wafer-live.s3.ap-south-1.amazonaws.com/Doc/Leave+Policy.pdf'),
        ('Rehire Policy', 'https://digi-wafer-live.s3.ap-south-1.amazonaws.com/Doc/Rehire+Policy.pdf'),
        ('Social Media Policy', 'https://digi-wafer-live.s3.ap-south-1.amazonaws.com/Doc/Social+Media+Policy.pdf')
     ) AS sub(title, url);


INSERT INTO quick_links_header (title, url, is_deleted)
VALUES ('Grievances', 'https://digi-wafer-live.s3.ap-south-1.amazonaws.com/Doc/Grievance+Redressal+Policy.pdf', false);


WITH inserted_header AS (
  INSERT INTO quick_links_header (title, url, is_deleted)
  VALUES ('Benefits Info', NULL, false)
  RETURNING id
)
INSERT INTO quick_links_sub_header (title, url, parent_id, is_deleted)
SELECT sub.title, sub.url, h.id, false
FROM inserted_header h,
     (VALUES
        ('Medical Coverage Policy', 'https://digi-wafer-live.s3.ap-south-1.amazonaws.com/Doc/DIGITIDE_INSURANCE+POLICY+-GMC.pdf'),
        ('Personal Accident Policy', 'https://digi-wafer-live.s3.ap-south-1.amazonaws.com/Doc/DIGITIDE_INSURANCE+POLICY+-+GPA.pdf'),
        ('Term Insurance Policy', 'https://digi-wafer-live.s3.ap-south-1.amazonaws.com/Doc/DIGITIDE_INSURANCE+POLICY+-+GTLI.pdf')
     ) AS sub(title, url);


INSERT INTO quick_links_header (title, url, is_deleted)
VALUES ('CSR', 'https://digi-wafer-live.s3.ap-south-1.amazonaws.com/Doc/CSR+Quick+Link.jpg', false);


INSERT INTO quick_links_header (title, url, is_deleted)
VALUES ('Holidays', '/site-under-construction', false);
