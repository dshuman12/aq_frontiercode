INSERT INTO app_modules

(module_name, module_code, parent_id, module_level, is_active, display_order, created_at, updated_at)

VALUES

('Home', 'home', Null, 1, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('My Wafers', 'my_wafers', Null, 1, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Comapny Info', 'comapny_info', Null, 1, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Document Centre', 'document_centre', Null, 1, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('More', 'more', Null, 1, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('My Payroll', 'my_payroll', Null, 1, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Video', 'video', 1, 2, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Top News', 'top_news', 1, 2, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Quick Links', 'quick_links', 1, 2, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Company Mood Today', 'company_mood_today', 1, 2, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('DigitideFlix', 'digitideflix', 1, 2, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('hobby hub', 'hobby_hub', 1, 2, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Whats Happening', 'whats_happening', 1, 2, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Surveys', 'surveys', 1, 2, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Company News', 'company_news', 13, 3, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Announcements', 'announcements', 13, 3, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Events', 'events', 13, 3, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Employee Spotlights', 'employee_spotlights', 13, 3, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Milestones', 'milestones', 13, 3, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Code of Conduct', 'code_of_conduct', 9, 3, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Coffee With Leaders', 'coffee_with_leaders', 9, 3, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Employee Communication', 'employee_communication', 9, 3, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Career Site', 'career_site', 9, 3, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Employee Policies', 'employee_policies', 9, 3, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Grievanges', 'grievanges', 9, 3, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Benifits Info', 'benifits_info', 9, 3, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('CSR', 'csr', 9, 3, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Holidays', 'holidays', 9, 3, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('POSH Policy', 'posh_policy', 20, 4, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Whistle-Blower Policy', 'whistle_blower_policy', 20, 4, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Business Compliance Policy', 'business_compliance_policy', 20, 4, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Code of Conduct', 'code_of_conduct1', 20, 4, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Anti Bribery', 'anti_bribery', 24, 4, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Conflict of Interest', 'conflict_of_interest', 24, 4, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Dress Code', 'dress_code', 24, 4, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Employee Referral', 'employee_referral', 24, 4, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Equal Employment', 'equal_employment', 24, 4, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Consensual', 'consensual', 24, 4, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Leave Policy', 'leave_policy', 24, 4, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Gift Entertainment', 'gift_entertainment', 24, 4, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Gratuity', 'gratuity', 24, 4, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Rehire Policy', 'rehire_policy', 24, 4, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Social Media Policy', 'social_media_policy', 24, 4, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Manual From Login to Booking', 'manual_from_login_to_booking', 24, 4, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Overseas Business Travel and Reimbursement Policy', 'overseas_business_travel_and_reimbursement_policy', 24, 4, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Domestic Business Travel and Reimbursement Policy', 'domestic_business_travel_and_reimbursement_policy', 24, 4, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Medical Coverage Policy', 'medical_coverage_policy', 26, 4, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Personal Accident Policy', 'personal_accident_policy', 26, 4, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Term Insurance Policy', 'term_insurance_policy', 26, 4, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('myBiz - Self Booking Tool', 'mybiz_self_booking_tool', 26, 4, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('India Holiday Calendar 2026', 'india_holiday_calendar_2026', 28, 4, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Canada - Holiday Calendar 2026', 'canada_holiday_calendar_2026', 28, 4, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('USA - Holiday Calendar 2026', 'usa_holiday_calendar_2026', 28, 4, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Philippines - Holiday Calendar 2026', 'philippines_holiday_calendar_2026', 28, 4, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Collaborative Spaces', 'collaborative_spaces', 5, 2, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Feedback & Suggestions', 'feedback_and_suggestions', 5, 2, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Help & Support', 'help_and_support', 5, 2, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

('Rewards and Recognitions', 'rewards_and_recognitions', 55, 3, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);
