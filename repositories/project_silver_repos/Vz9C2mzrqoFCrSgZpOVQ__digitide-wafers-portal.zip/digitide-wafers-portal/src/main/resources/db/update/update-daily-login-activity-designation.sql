ALTER TABLE daily_login_activity
ADD COLUMN designation VARCHAR(255);