ALTER TABLE employee_newsletter
ADD COLUMN IF NOT EXISTS thumbnail_key TEXT;