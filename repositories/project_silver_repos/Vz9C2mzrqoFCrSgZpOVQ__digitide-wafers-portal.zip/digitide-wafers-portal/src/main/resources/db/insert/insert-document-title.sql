INSERT INTO document_title (title) VALUES
  ('Employee Handbook'),
  ('Workplace Safety Guidelines'),
  ('Data Privacy Policy'),
  ('Brand Guidelines'),
  ('IT Support Guidelines'),
  ('IT Security Policy'),
  ('WFH Policy'),
  ('Insurance Guidelines');