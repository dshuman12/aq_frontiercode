DELETE FROM app_modules
WHERE module_code = 'feedback_and_suggestions';