ALTER TABLE documents
ALTER COLUMN document_url TYPE TEXT;