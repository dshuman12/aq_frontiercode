ALTER TABLE change_tracker
DROP COLUMN s3Key;

ALTER TABLE change_tracker
ADD COLUMN s3Key TEXT;