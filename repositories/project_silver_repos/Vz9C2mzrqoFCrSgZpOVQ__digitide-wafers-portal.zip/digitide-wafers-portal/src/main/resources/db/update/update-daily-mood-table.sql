ALTER TABLE daily_mood ADD COLUMN employee_id VARCHAR(255) NULL;

UPDATE daily_mood SET employee_id = 'UNKNOWN' WHERE employee_id IS NULL;

ALTER TABLE daily_mood ALTER COLUMN employee_id SET NOT NULL;