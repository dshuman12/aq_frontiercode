CREATE TABLE surveys (
    id bigserial PRIMARY KEY,
    survey_title TEXT NOT NULL,
    estimated_time TEXT,
    image TEXT,
    url_link TEXT,
    description TEXT,
    ended_at TIMESTAMP(6),
    is_ended BOOLEAN DEFAULT FALSE,
    is_deleted bool NULL DEFAULT false,
    created_by varchar(255) NULL,
    created_date timestamp(6) NULL,
    is_removed bool NULL DEFAULT false,
    is_active bool NULL DEFAULT false,
    modified_by varchar(255) NULL,
    modified_date timestamp(6) NULL
);
