CREATE TABLE events (
    id bigserial PRIMARY KEY,
    event_name VARCHAR(255) NOT NULL,
    event_image TEXT,
    event_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    is_deleted bool NULL DEFAULT false,
    created_by varchar(255) NULL,
    created_date timestamp(6) NULL,
    is_removed bool NULL DEFAULT false,
    is_active bool NULL DEFAULT false,
    modified_by varchar(255) NULL,
    modified_date timestamp(6) NULL
);
