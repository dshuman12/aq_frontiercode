CREATE TABLE search_analytics (
    id BIGSERIAL PRIMARY KEY,
    query TEXT,
    result_count INTEGER,
    clicked BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);