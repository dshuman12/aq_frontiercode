DELETE FROM app_modules
WHERE parent_id IN (
    SELECT id
    FROM app_modules
    WHERE module_code IN ('code_of_conduct','employee_policies')
);

DELETE FROM app_modules
WHERE module_code IN (
    'leave_policy',
    'gift_entertainment',
    'gratuity',
    'rehire_policy',
    'social_media_policy',
    'manual_from_login_to_booking',
    'overseas_business_travel_and_reimbursement_policy',
    'domestic_business_travel_and_reimbursement_policy',
    'posh_policy',
    'whistle_blower_policy',
    'business_compliance_policy',
    'code_of_conduct1',
    'anti_bribery',
    'conflict_of_interest',
    'dress_code',
    'employee_referral',
    'equal_employment'
);