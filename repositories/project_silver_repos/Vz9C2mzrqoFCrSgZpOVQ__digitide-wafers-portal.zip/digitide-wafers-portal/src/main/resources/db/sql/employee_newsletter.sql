CREATE TABLE employee_newsletter (
    id bigserial PRIMARY KEY,
    description TEXT,
    document_key TEXT,
    issue_date DATE NOT NULL,
    is_deleted bool NULL DEFAULT false,
    created_by varchar(255) NULL,
    created_date timestamp(6) NULL,
    is_removed bool NULL DEFAULT false,
    is_active bool NULL DEFAULT false,
    modified_by varchar(255) NULL,
    modified_date timestamp(6) NULL
);