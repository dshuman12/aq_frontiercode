-- Index for date-range queries: COUNT(DISTINCT user_email) filtered by login_date range
CREATE INDEX IF NOT EXISTS idx_login_activity_date_email
    ON daily_login_activity (login_date, user_email)
    WHERE is_deleted = false;


-- Index for per-user aggregation: MIN(login_date) per user_email
CREATE INDEX IF NOT EXISTS idx_login_activity_email_date
    ON daily_login_activity (user_email, login_date)
    WHERE is_deleted = false;


-- Index for designation-based analytics
CREATE INDEX IF NOT EXISTS idx_login_activity_designation
    ON daily_login_activity (designation, login_date, user_email)
    WHERE is_deleted = false;
