CREATE TABLE performance_logs_monthly (
    id BIGSERIAL PRIMARY KEY,
    page_name VARCHAR(255),
    api_name VARCHAR(255),
    year INT,
    month INT,
    total_requests INT,
    avg_api_time INT,
    avg_page_load INT,
    error_count INT,
    created_at TIMESTAMP
);