UPDATE app_modules
SET
    module_name = 'SHE Newsletter',
    module_code = 'she_newsletter',
    updated_at = CURRENT_TIMESTAMP
WHERE module_code = 'Grievances';