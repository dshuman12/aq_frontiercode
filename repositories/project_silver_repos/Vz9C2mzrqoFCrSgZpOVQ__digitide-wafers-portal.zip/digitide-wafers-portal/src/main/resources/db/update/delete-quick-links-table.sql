DROP TABLE IF EXISTS quick_links;
