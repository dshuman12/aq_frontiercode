ALTER TABLE performance_logs_monthly
ADD CONSTRAINT unique_performance_month
UNIQUE (page_name, api_name, year, month);