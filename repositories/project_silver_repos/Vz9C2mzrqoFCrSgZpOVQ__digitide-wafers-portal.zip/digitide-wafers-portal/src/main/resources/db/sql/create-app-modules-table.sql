CREATE TABLE app_modules (
    id BIGSERIAL PRIMARY KEY,

    module_name VARCHAR(150) NOT NULL,

    module_code VARCHAR(100) NOT NULL UNIQUE,

    parent_id BIGINT NULL,

    module_level INT NOT NULL,
    -- 1 = Root
    -- 2 = Submodule
    -- 3 = Child
    -- 4 = Item

    is_active BOOLEAN DEFAULT TRUE,

    display_order INT NULL,

    created_at TIMESTAMP(6) DEFAULT CURRENT_TIMESTAMP,

    updated_at TIMESTAMP(6) DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_parent_module
        FOREIGN KEY (parent_id)
        REFERENCES app_modules(id)
        ON DELETE CASCADE
);
