-- CLEAN OLD DATA
DELETE FROM daily_module_usage
WHERE usage_date BETWEEN '2025-10-01' AND '2026-02-28';


-- ================= FEBRUARY (~560K) =================
-- Per day ≈ 20,000

INSERT INTO daily_module_usage (module_id, usage_date, click_count)
SELECT 1, d::date, 13000
FROM generate_series('2026-02-01', '2026-02-28', interval '1 day') d;

INSERT INTO daily_module_usage (module_id, usage_date, click_count)
SELECT 2, d::date, 3000
FROM generate_series('2026-02-01', '2026-02-28', interval '1 day') d;

INSERT INTO daily_module_usage (module_id, usage_date, click_count)
SELECT 3, d::date, 4000
FROM generate_series('2026-02-01', '2026-02-28', interval '1 day') d;


-- ================= JANUARY (~530K) =================
-- Per day ≈ 17,100

INSERT INTO daily_module_usage (module_id, usage_date, click_count)
SELECT 1, d::date, 11000
FROM generate_series('2026-01-01', '2026-01-31', interval '1 day') d;

INSERT INTO daily_module_usage (module_id, usage_date, click_count)
SELECT 2, d::date, 2400
FROM generate_series('2026-01-01', '2026-01-31', interval '1 day') d;

INSERT INTO daily_module_usage (module_id, usage_date, click_count)
SELECT 3, d::date, 3700
FROM generate_series('2026-01-01', '2026-01-31', interval '1 day') d;


-- ================= DECEMBER (~500K) =================
-- Per day ≈ 16,100

INSERT INTO daily_module_usage (module_id, usage_date, click_count)
SELECT 1, d::date, 10500
FROM generate_series('2025-12-01', '2025-12-31', interval '1 day') d;

INSERT INTO daily_module_usage (module_id, usage_date, click_count)
SELECT 2, d::date, 2300
FROM generate_series('2025-12-01', '2025-12-31', interval '1 day') d;

INSERT INTO daily_module_usage (module_id, usage_date, click_count)
SELECT 3, d::date, 3300
FROM generate_series('2025-12-01', '2025-12-31', interval '1 day') d;


-- ================= NOVEMBER (~470K) =================
-- Per day ≈ 15,700

INSERT INTO daily_module_usage (module_id, usage_date, click_count)
SELECT 1, d::date, 10000
FROM generate_series('2025-11-01', '2025-11-30', interval '1 day') d;

INSERT INTO daily_module_usage (module_id, usage_date, click_count)
SELECT 2, d::date, 2200
FROM generate_series('2025-11-01', '2025-11-30', interval '1 day') d;

INSERT INTO daily_module_usage (module_id, usage_date, click_count)
SELECT 3, d::date, 3500
FROM generate_series('2025-11-01', '2025-11-30', interval '1 day') d;

-- ================= OCTOBER (~400K) =================
-- Per day ≈ 13,000

INSERT INTO daily_module_usage (module_id, usage_date, click_count)
SELECT 1, d::date, 8500
FROM generate_series('2025-10-01', '2025-10-31', interval '1 day') d;

INSERT INTO daily_module_usage (module_id, usage_date, click_count)
SELECT 2, d::date, 1800
FROM generate_series('2025-10-01', '2025-10-31', interval '1 day') d;

INSERT INTO daily_module_usage (module_id, usage_date, click_count)
SELECT 3, d::date, 2700
FROM generate_series('2025-10-01', '2025-10-31', interval '1 day') d;
