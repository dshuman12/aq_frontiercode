UPDATE app_modules
SET is_active = false,
    updated_at = CURRENT_TIMESTAMP
WHERE module_code = 'help_and_support';