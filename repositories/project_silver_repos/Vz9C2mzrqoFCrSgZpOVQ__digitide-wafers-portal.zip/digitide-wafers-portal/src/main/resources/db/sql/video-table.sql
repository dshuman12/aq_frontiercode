CREATE TABLE video (
    id bigserial PRIMARY KEY,
    video TEXT,
    is_deleted BOOLEAN NOT NULL,
    created_by varchar(255) NULL,
    created_date timestamp(6) NULL,
    is_removed bool NULL DEFAULT false,
    is_active bool NULL DEFAULT false,
    modified_by varchar(255) NULL,
    modified_date timestamp(6) NULL
);

