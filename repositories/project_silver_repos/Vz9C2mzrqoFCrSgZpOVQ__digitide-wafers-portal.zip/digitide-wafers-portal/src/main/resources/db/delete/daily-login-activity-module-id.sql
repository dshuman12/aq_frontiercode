ALTER TABLE daily_login_activity
DROP CONSTRAINT IF EXISTS unique_user_module_date;

ALTER TABLE daily_login_activity
DROP COLUMN IF EXISTS module_id;

ALTER TABLE daily_login_activity
ADD CONSTRAINT unique_user_login_date
UNIQUE (user_email, login_date);