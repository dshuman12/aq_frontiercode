CREATE TABLE document_title (
    id bigserial PRIMARY KEY,
    title VARCHAR(255) NOT NULL UNIQUE,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by varchar(255) NULL,
    created_date timestamp(6) NULL,
    is_deleted bool NULL DEFAULT false,
    is_removed bool NULL DEFAULT false,
    is_active bool NULL DEFAULT false,
    modified_by varchar(255) NULL,
    modified_date timestamp(6) NULL
);