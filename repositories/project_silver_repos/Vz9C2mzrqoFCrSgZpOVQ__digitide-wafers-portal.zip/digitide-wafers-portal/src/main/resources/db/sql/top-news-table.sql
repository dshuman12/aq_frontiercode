CREATE TABLE top_news (
    id bigserial PRIMARY KEY,
    title TEXT NOT NULL,
    image TEXT,
    news_description TEXT NOT NULL,
    is_deleted bool NULL DEFAULT false,
    created_by varchar(255) NULL,
    created_date timestamp(6) NULL,
    is_removed bool NULL DEFAULT false,
    is_active bool NULL DEFAULT false,
    modified_by varchar(255) NULL,
    modified_date timestamp(6) NULL
);
