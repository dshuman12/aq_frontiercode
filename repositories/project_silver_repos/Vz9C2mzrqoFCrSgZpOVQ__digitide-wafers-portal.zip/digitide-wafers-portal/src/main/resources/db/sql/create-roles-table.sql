CREATE TABLE roles (
    id bigserial NOT NULL,
    "name" VARCHAR(255),
    "slug" VARCHAR(255),
     is_deleted bool NULL DEFAULT false,
     created_by varchar(255) NULL,
     created_date timestamp(6) NULL,
     is_removed bool NULL DEFAULT false,
     is_active bool NULL DEFAULT false,
     modified_by varchar(255) NULL,
     modified_date timestamp(6) NULL,
     CONSTRAINT roles_pkey PRIMARY KEY (id)

);