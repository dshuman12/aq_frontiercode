ALTER TABLE document_center
ADD COLUMN IF NOT EXISTS is_removed bool NULL DEFAULT false;