ALTER TABLE performance_logs
ADD COLUMN is_active bool NULL DEFAULT false,
ADD COLUMN is_removed bool NULL DEFAULT false;
