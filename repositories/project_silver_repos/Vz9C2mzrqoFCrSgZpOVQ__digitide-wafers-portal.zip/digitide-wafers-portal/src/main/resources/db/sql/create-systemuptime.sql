CREATE TABLE system_uptime (
    id BIGSERIAL PRIMARY KEY,

    log_date DATE NOT NULL,
    log_start_time TIME NOT NULL,
    log_end_time TIME NOT NULL,
    duration BIGINT,

    created_by varchar(255) NULL,
    created_date timestamp(6) NULL,
    is_removed bool NULL DEFAULT false,
    is_active bool NULL DEFAULT false,
    modified_by varchar(255) NULL,
    modified_date timestamp(6) NULL
);