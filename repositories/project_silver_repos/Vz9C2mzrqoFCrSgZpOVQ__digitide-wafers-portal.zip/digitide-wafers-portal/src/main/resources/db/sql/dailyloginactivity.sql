CREATE TABLE daily_login_activity (
    id BIGSERIAL PRIMARY KEY,
    user_email VARCHAR(255) NOT NULL,
    module_id BIGINT NOT NULL,
    login_date DATE NOT NULL,

    created_by varchar(255) NOT NULL,
    created_date timestamp(6) NOT NULL,
    modified_by varchar(255) NULL,
    modified_date timestamp(6) NULL,
    is_removed bool DEFAULT false,
    is_active bool DEFAULT false,

    is_deleted BOOLEAN DEFAULT FALSE,

    CONSTRAINT unique_user_module_date
    UNIQUE (user_email, module_id, login_date)
);
