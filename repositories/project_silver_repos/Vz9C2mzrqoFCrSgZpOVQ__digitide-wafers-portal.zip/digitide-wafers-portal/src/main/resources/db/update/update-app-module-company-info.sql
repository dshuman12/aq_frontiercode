UPDATE app_modules
SET
    module_name = 'Company Info',
    module_code = 'company_info',
    updated_at = CURRENT_TIMESTAMP
WHERE module_code = 'comapny_info';