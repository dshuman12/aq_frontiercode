CREATE TABLE performance_logs (
    id BIGSERIAL PRIMARY KEY,
    tracking_id VARCHAR(100),
    page_name VARCHAR(255),
    api_name VARCHAR(255),
    api_response_time_ms INT,
    page_load_time_ms INT,
    status_code INT,
    browser VARCHAR(100),
    device_type VARCHAR(50),
    os VARCHAR(100),
    created_by VARCHAR(100),
    modified_by VARCHAR(100),
    created_date TIMESTAMP,
    modified_date TIMESTAMP
);