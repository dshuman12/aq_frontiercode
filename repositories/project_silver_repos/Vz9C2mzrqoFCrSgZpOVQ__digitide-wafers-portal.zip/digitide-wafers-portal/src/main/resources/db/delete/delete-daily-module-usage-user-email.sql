ALTER TABLE daily_module_usage
DROP COLUMN user_email;