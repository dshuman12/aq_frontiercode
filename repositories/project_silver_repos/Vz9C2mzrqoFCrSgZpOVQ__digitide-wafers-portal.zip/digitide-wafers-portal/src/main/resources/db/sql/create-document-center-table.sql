CREATE TABLE document_center (
    id bigserial PRIMARY KEY,
    section_id BIGINT NOT NULL,
    document_key TEXT,
    document_name TEXT,
    is_deleted bool NULL DEFAULT false,
    is_active bool NULL DEFAULT false,
    created_by varchar(255) NULL,
    created_date timestamp(6) NULL,
    modified_by varchar(255) NULL,
    modified_date timestamp(6) NULL
);
