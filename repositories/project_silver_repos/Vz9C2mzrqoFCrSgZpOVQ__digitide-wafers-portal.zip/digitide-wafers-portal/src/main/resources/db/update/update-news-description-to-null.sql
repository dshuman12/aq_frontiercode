ALTER TABLE top_news
ALTER COLUMN news_description DROP NOT NULL;
