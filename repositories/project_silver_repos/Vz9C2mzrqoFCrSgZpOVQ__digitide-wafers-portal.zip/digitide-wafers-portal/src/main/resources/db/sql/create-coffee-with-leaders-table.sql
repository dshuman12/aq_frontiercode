CREATE TABLE coffee_with_leaders (
    id BIGSERIAL PRIMARY KEY,
    title VARCHAR(255),
    designation VARCHAR(255),
    image VARCHAR(500),
    thumbnail_url VARCHAR(500),
    sequence DOUBLE PRECISION,
    is_deleted BOOLEAN NOT NULL DEFAULT FALSE,
    created_by varchar(255) NULL,
    created_date timestamp(6) NULL,
    is_removed bool NULL DEFAULT false,
    is_active bool NULL DEFAULT false,
    modified_by varchar(255) NULL,
    modified_date timestamp(6) NULL
);