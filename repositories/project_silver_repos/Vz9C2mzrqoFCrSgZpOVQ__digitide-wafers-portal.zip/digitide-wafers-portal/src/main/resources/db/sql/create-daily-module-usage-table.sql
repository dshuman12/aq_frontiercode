CREATE TABLE daily_module_usage (
    id BIGSERIAL PRIMARY KEY,

    module_id BIGINT NOT NULL,

    usage_date DATE NOT NULL,

    click_count BIGINT DEFAULT 0,

    created_at TIMESTAMP(6) DEFAULT CURRENT_TIMESTAMP,

    updated_at TIMESTAMP(6) DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_usage_module
        FOREIGN KEY (module_id)
        REFERENCES app_modules(id)
        ON DELETE CASCADE,

    CONSTRAINT uk_daily_usage
        UNIQUE (module_id, usage_date)
);
