CREATE TABLE daily_mood (
    id bigserial PRIMARY KEY,
    mood VARCHAR(20) NOT NULL CHECK (mood IN ('HAPPY', 'SAD', 'NEUTRAL')),

    created_by varchar(255) NOT NULL,
    created_date timestamp(6) NOT NULL,
    modified_by varchar(255) NULL,
    modified_date timestamp(6) NULL,
    is_removed bool DEFAULT false,
    is_active bool DEFAULT false,

    UNIQUE (created_by, created_date)
);