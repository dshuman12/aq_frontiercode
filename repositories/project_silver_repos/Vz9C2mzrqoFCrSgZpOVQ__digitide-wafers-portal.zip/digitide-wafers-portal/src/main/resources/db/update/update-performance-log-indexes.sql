CREATE INDEX IF NOT EXISTS idx_perf_logs_device_type_created_date
ON performance_logs (device_type, created_date)
WHERE is_removed = false;


CREATE INDEX IF NOT EXISTS idx_perf_logs_browser_created_date
ON performance_logs (browser, created_date)
WHERE is_removed = false;


CREATE INDEX IF NOT EXISTS idx_perf_logs_created_date
ON performance_logs (created_date)
WHERE is_removed = false;
