CREATE TABLE quick_links (
    id bigserial PRIMARY KEY,
    title TEXT NOT NULL,
    parent_id bigint NULL,
    order_index bigint,
    sub_header_title TEXT,
    pdf_links TEXT,
    is_deleted bool NULL DEFAULT false,
    created_by varchar(255) NULL,
    created_date timestamp(6) NULL,
    is_removed bool NULL DEFAULT false,
    is_active bool NULL DEFAULT false,
    modified_by varchar(255) NULL,
    modified_date timestamp(6) NULL
);