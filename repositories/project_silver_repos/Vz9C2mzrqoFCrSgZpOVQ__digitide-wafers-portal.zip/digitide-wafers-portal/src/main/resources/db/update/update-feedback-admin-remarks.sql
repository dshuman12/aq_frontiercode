ALTER TABLE feedbacks
DROP COLUMN IF EXISTS admin_remarks;