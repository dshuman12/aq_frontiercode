INSERT INTO app_modules
(module_name, module_code, parent_id, module_level, is_active, display_order, created_at, updated_at)
VALUES
('EUREKA – Our Innovation hub', 'eureka_our_innovation_hub', NULL, 1, true, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);