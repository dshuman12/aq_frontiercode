ALTER TABLE quick_links_sub_header
ADD COLUMN link_type VARCHAR(20) NOT NULL DEFAULT 'FILE';
