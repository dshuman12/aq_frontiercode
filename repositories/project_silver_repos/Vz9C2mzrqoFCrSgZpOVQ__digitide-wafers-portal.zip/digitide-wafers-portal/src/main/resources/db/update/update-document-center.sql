ALTER TABLE document_center
ADD COLUMN IF NOT EXISTS thumbnail_key TEXT;