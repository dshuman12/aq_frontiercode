CREATE TABLE feedback_admin_remarks (
    id BIGSERIAL PRIMARY KEY,
    feedback_id BIGINT NOT NULL,
    remark VARCHAR(1000) NOT NULL,
    created_by VARCHAR(255),
    created_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_feedback_remark
        FOREIGN KEY (feedback_id)
        REFERENCES feedbacks(id)
        ON DELETE CASCADE
);
