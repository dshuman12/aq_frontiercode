
ALTER TABLE documents
ADD COLUMN document_title_id BIGINT NOT NULL;

ALTER TABLE documents
ADD CONSTRAINT fk_document_title
FOREIGN KEY (document_title_id)
REFERENCES document_title(id);
