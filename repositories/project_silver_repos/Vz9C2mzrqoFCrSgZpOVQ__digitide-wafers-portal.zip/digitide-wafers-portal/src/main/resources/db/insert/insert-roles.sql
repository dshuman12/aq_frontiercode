INSERT INTO roles (id,name,slug)
VALUES(1,'Admin','admin')