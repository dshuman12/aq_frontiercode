ALTER TABLE rewards_and_recognition
ADD COLUMN IF NOT EXISTS section_id BIGINT,
ADD COLUMN IF NOT EXISTS subsection_id BIGINT;