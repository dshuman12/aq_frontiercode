UPDATE app_modules
SET
    module_name = 'Grievances',
    module_code = 'Grievances',
    updated_at = CURRENT_TIMESTAMP
WHERE module_code = 'grievanges';

UPDATE app_modules
SET
    module_name = 'Benefits Info',
    module_code = 'benefits_info',
    updated_at = CURRENT_TIMESTAMP
WHERE module_code = 'benifits_info';
