CREATE TABLE spotlights (
    id bigserial PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    video TEXT,
    is_deleted bool NULL DEFAULT false,
    created_by varchar(255) NULL,
    created_date timestamp(6) NULL,
    is_removed bool NULL DEFAULT false,
    is_active bool NULL DEFAULT false,
    modified_by varchar(255) NULL,
    modified_date timestamp(6) NULL
);
