CREATE TABLE feedbacks (
    id bigserial PRIMARY KEY,
    feedback_description VARCHAR(255) NOT NULL,
    attachment VARCHAR(512),
    feedback_date DATE,
    uploaded_document VARCHAR(512),
    action_taken bool NULL DEFAULT false,
    is_deleted bool NULL DEFAULT false,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by varchar(255) NULL,
    created_date timestamp(6) NULL,
    is_removed bool NULL DEFAULT false,
    is_active bool NULL DEFAULT false,
    modified_by varchar(255) NULL,
    modified_date timestamp(6) NULL
);