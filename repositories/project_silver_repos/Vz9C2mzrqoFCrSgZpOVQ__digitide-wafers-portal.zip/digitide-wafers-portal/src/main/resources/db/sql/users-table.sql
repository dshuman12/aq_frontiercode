CREATE TABLE public.users (
    id bigserial NOT NULL,
    employee_id VARCHAR(255)  NULL,
    "user_name" varchar(255) NULL,
    "email" varchar(255) NULL,
    "password" varchar(255) NULL,
    "designation" varchar(255) NULL,
    "is_password_set_by_user" bool NULL DEFAULT false,
    is_deleted bool NULL DEFAULT false,
    created_by varchar(255) NULL,
    created_date timestamp(6) NULL,
    is_removed bool NULL DEFAULT false,
    is_active bool NULL DEFAULT false,
    modified_by varchar(255) NULL,
    modified_date timestamp(6) NULL,
    CONSTRAINT users_pkey PRIMARY KEY (id)
);

CREATE TABLE user_roles (
    user_id BIGINT NOT NULL,
    role_id BIGINT NOT NULL,
    PRIMARY KEY (user_id, role_id),
    CONSTRAINT fk_user FOREIGN KEY (user_id) REFERENCES users(id),
    CONSTRAINT fk_role FOREIGN KEY (role_id) REFERENCES roles(id)
);

