ALTER TABLE surveys
ADD COLUMN IF NOT EXISTS survey_status bool NULL DEFAULT false;