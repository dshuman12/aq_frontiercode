ALTER TABLE top_news
ADD COLUMN IF NOT EXISTS thumbnail_url TEXT;
ALTER TABLE spotlights
ADD COLUMN IF NOT EXISTS thumbnail_url TEXT;
ALTER TABLE pic_of_the_day
ADD COLUMN IF NOT EXISTS thumbnail_url TEXT;