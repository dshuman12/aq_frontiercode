ALTER TABLE coffee_with_leaders
ADD COLUMN IF NOT EXISTS description TEXT;