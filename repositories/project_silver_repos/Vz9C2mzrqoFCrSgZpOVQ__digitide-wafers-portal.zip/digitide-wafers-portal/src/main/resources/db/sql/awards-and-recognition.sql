CREATE TABLE awards_and_recognition (
    id bigserial PRIMARY KEY,
    image TEXT,
    title TEXT NOT NULL,
    year TEXT NULL,
    is_deleted bool NULL DEFAULT false,
    created_by varchar(255) NULL,
    created_date timestamp(6) NULL,
    is_removed bool NULL DEFAULT false,
    is_active bool NULL DEFAULT false,
    modified_by varchar(255) NULL,
    modified_date timestamp(6) NULL
);