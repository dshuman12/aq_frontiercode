ALTER TABLE daily_module_usage
ADD COLUMN user_email VARCHAR(255) DEFAULT 'unknown_user';