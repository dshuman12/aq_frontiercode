-- CLEAN OLD DATA
DELETE FROM daily_module_usage
WHERE usage_date BETWEEN '2025-10-01' AND '2026-02-28';

-- October
-- My Wafers (~67%)
INSERT INTO daily_module_usage (module_id, usage_date, click_count)
SELECT 1, d::date, 10500
FROM generate_series('2025-10-01', '2025-10-31', interval '1 day') d;

-- My Payroll (~13%)
INSERT INTO daily_module_usage (module_id, usage_date, click_count)
SELECT 2, d::date, 2100
FROM generate_series('2025-10-01', '2025-10-31', interval '1 day') d;

-- Home (~15%)
INSERT INTO daily_module_usage (module_id, usage_date, click_count)
SELECT 3, d::date, 2600
FROM generate_series('2025-10-01', '2025-10-31', interval '1 day') d;


-- November
-- My Wafers (~67%)
INSERT INTO daily_module_usage (module_id, usage_date, click_count)
SELECT 1, d::date, 10500
FROM generate_series('2025-11-01', '2025-11-30', interval '1 day') d;

-- My Payroll (~13%)
INSERT INTO daily_module_usage (module_id, usage_date, click_count)
SELECT 2, d::date, 2100
FROM generate_series('2025-11-01', '2025-11-30', interval '1 day') d;

-- Home (~15%)
INSERT INTO daily_module_usage (module_id, usage_date, click_count)
SELECT 3, d::date, 2600
FROM generate_series('2025-11-01', '2025-11-30', interval '1 day') d;


-- December
-- My Wafers
INSERT INTO daily_module_usage (module_id, usage_date, click_count)
SELECT 1, d::date, 11500
FROM generate_series('2025-12-01', '2025-12-31', interval '1 day') d;

-- My Payroll
INSERT INTO daily_module_usage (module_id, usage_date, click_count)
SELECT 2, d::date, 2300
FROM generate_series('2025-12-01', '2025-12-31', interval '1 day') d;

-- Home
INSERT INTO daily_module_usage (module_id, usage_date, click_count)
SELECT 3, d::date, 2800
FROM generate_series('2025-12-01', '2025-12-31', interval '1 day') d;


-- January
-- My Wafers
INSERT INTO daily_module_usage (module_id, usage_date, click_count)
SELECT 1, d::date, 11000
FROM generate_series('2026-01-01', '2026-01-31', interval '1 day') d;

-- My Payroll
INSERT INTO daily_module_usage (module_id, usage_date, click_count)
SELECT 2, d::date, 2200
FROM generate_series('2026-01-01', '2026-01-31', interval '1 day') d;

-- Home
INSERT INTO daily_module_usage (module_id, usage_date, click_count)
SELECT 3, d::date, 2700
FROM generate_series('2026-01-01', '2026-01-31', interval '1 day') d;

-- February
-- My Wafers
INSERT INTO daily_module_usage (module_id, usage_date, click_count)
SELECT 1, d::date, 10500
FROM generate_series('2026-02-01', '2026-02-28', interval '1 day') d;

-- My Payroll
INSERT INTO daily_module_usage (module_id, usage_date, click_count)
SELECT 2, d::date, 2100
FROM generate_series('2026-02-01', '2026-02-28', interval '1 day') d;

-- Home
INSERT INTO daily_module_usage (module_id, usage_date, click_count)
SELECT 3, d::date, 2600
FROM generate_series('2026-02-01', '2026-02-28', interval '1 day') d;