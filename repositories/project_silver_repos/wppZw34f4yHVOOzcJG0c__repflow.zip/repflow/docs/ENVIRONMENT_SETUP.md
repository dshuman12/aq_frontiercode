# Environment Setup Guide

This guide explains how to set up your local development environment for the Repflow backend.

## Quick Start

1. Copy `env.example` to `.env.local`:
   ```bash
   cp env.example .env.local
   ```

2. Fill in all required environment variables (see sections below)

3. Start the development server:
   ```bash
   pipenv run dev
   ```

## Required Environment Variables

### AWS Cognito Configuration (Required for Authentication)

**Why Cognito?** The backend uses AWS Cognito for JWT authentication. When users log in through the frontend, Cognito issues JWT tokens that the backend validates.

**What is JWKS?** JWKS (JSON Web Key Set) is a set of public keys used to verify JWT tokens. Cognito exposes these keys at a public URL. The backend fetches these keys on startup to validate incoming JWT tokens.

**Required Variables:**
```bash
COGNITO_REGION=us-east-2                    # AWS region where your Cognito User Pool is located
COGNITO_POOL_ID=us-east-2_UOedUZggp         # Your Cognito User Pool ID
COGNITO_CLIENT_ID=1jcl067l8ampqksfh3103mv5s3 # Your Cognito App Client ID
```

**Where to find these:**
1. Go to AWS Console → Cognito → User Pools
2. Select your User Pool
3. **COGNITO_REGION**: Check the AWS region in the URL or pool details
4. **COGNITO_POOL_ID**: Found in "General settings" → "Pool Id"
5. **COGNITO_CLIENT_ID**: Found in "App integration" → "App clients" → Client ID

**Common Issues:**
- ❌ **"JWK public key not found"**: Cognito variables are missing or incorrect
- ❌ **"JWK invalid"**: Token issuer doesn't match your Cognito User Pool
- ✅ **Fix**: Ensure `COGNITO_REGION` and `COGNITO_POOL_ID` match your frontend's Cognito configuration

### MongoDB Configuration (Required)

```bash
MONGODB_URL=mongodb+srv://user:password@cluster.mongodb.net/repflow
```

**Where to find this:**
- MongoDB Atlas → Clusters → Connect → Connection String
- Or use a local MongoDB instance: `mongodb://localhost:27017/repflow`

### OpenAI API Key (Required for Email Agent)

```bash
OPENAI_API_KEY=sk-proj-...
```

**Where to find this:**
- OpenAI Dashboard → API Keys → Create new secret key

### Backend API Configuration

```bash
API_BASE_URL=http://localhost:8000          # Backend URL
API_AUTH_TOKEN=your_service_account_token   # Service account token for Lambda/automation
```

### AWS Configuration (Required for Email Sending)

```bash
AWS_ACCESS_KEY_ID=your_access_key
AWS_SECRET_ACCESS_KEY=your_secret_key
AWS_REGION=us-east-2
```

**Where to find these:**
- AWS Console → IAM → Users → Your User → Security Credentials → Access Keys

### Stripe Configuration (Required for Payments)

```bash
STRIPE_SECRET_KEY=sk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...
```

**Where to find these:**
- Stripe Dashboard → Developers → API Keys
- Stripe Dashboard → Developers → Webhooks → Your Webhook → Signing Secret

## Environment File Structure

The project uses `.env.local` for local development. This file is gitignored and should contain your actual credentials.

**Never commit `.env.local` to git!**

## Troubleshooting

### Authentication Errors

**Error: "JWK public key not found"**
- **Cause**: Cognito configuration is missing or incorrect
- **Fix**: 
  1. Verify `COGNITO_REGION` and `COGNITO_POOL_ID` are set correctly
  2. Check that the JWKS URL is accessible: `https://cognito-idp.{region}.amazonaws.com/{pool_id}/.well-known/jwks.json`
  3. Ensure your frontend and backend use the same Cognito User Pool

**Error: "'JWTBearer' object has no attribute 'claims'"**
- **Cause**: This is a code issue, not an environment issue
- **Fix**: Ensure you're using `Depends(get_auth)` not `Depends(auth)` in your routes

### Database Connection Errors

**Error: "Connection refused" or "Authentication failed"**
- **Cause**: MongoDB URL is incorrect or database is not accessible
- **Fix**: 
  1. Verify `MONGODB_URL` is correct
  2. Check MongoDB Atlas IP whitelist (if using Atlas)
  3. Verify database user has correct permissions

### API Key Errors

**Error: "Invalid API key"**
- **Cause**: API key is missing or incorrect
- **Fix**: Verify the key is set correctly in `.env.local` and matches the service

## Why So Much Error Handling?

The JWKS loading has extensive error handling because:

1. **Graceful Degradation**: The server should start even if Cognito isn't configured (for local dev without auth)
2. **Key Rotation**: Cognito rotates keys periodically - the code reloads JWKS when keys aren't found
3. **Network Issues**: JWKS is fetched from AWS - network failures shouldn't crash the server
4. **Configuration Errors**: Missing env vars should log warnings, not crash

This allows developers to work on non-auth features even if Cognito isn't set up, while still providing clear errors when auth is needed.

## Production vs Development

**Development (`.env.local`):**
- Use test/staging credentials
- Local MongoDB or dev cluster
- Test Stripe keys (`sk_test_...`)

**Production:**
- Use production credentials
- Production MongoDB cluster
- Live Stripe keys (`sk_live_...`)
- Ensure all required variables are set

## Next Steps

After setting up your environment:

1. **Test Authentication**: Try logging in through the frontend
2. **Test API Endpoints**: Use Postman or curl to test protected endpoints
3. **Check Logs**: Monitor server logs for any configuration warnings
4. **Verify JWKS Loading**: Check logs for "JWKS loaded successfully with X keys"

## Additional Resources

- [AWS Cognito Documentation](https://docs.aws.amazon.com/cognito/)
- [JWT.io](https://jwt.io/) - Debug JWT tokens
- [MongoDB Atlas Setup](https://www.mongodb.com/docs/atlas/getting-started/)
- [FastAPI Security](https://fastapi.tiangolo.com/tutorial/security/)
