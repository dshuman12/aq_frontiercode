# Production vs development deployment

Single checklist for **MongoDB** (`repflow` vs `repflow_dev`), **Cognito**, **App Runner** (including console steps and the dev secret script), **repflow-frontend**, and CORS. Region in examples: **US East (Ohio) `us-east-2`**.

## 1. MongoDB Atlas (one cluster is OK)

| Layer | Production | Development |
|--------|------------|---------------|
| Cluster | Your Atlas cluster (e.g. `dev-repflow`) | Same or separate cluster |
| Database name (`MONGODB_DATABASE`) | `repflow` | `repflow_dev` |

Ensure the database user in `MONGODB_URL` can read/write the DB you target (`readWrite` on `repflow` and `repflow_dev` if both are used).

## 2. Backend: App Runner (prod vs dev)

App Runner always reads **`apprunner.yaml`** at the repo root for the branch it deploys. This repo splits **by Git branch**:

| Stack | Git branch | `apprunner.yaml` contents | `MONGODB_DATABASE` | Cognito pool |
|-------|------------|---------------------------|--------------------|--------------|
| Production | **`main`** | Prod pool + `repflow` DB | `repflow` | `us-east-2_UOedUZggp` |
| Development | **`dev`** | Dev pool + `repflow_dev` | `repflow_dev` | `us-east-2_s82ysRbW8` |

**`apprunner.dev.yaml`** is a duplicate of the **`dev`** branch `apprunner.yaml` for docs/search; change **`apprunner.yaml` on `dev`** for real deploys.

**Merge safety:** Merging `dev` → `main` will conflict on `apprunner.yaml` — **keep `main`’s production file** (do not replace prod Cognito/DB with dev values).

**Secrets (quick vs recommended):** Both files can reference the same Secrets Manager JSON as prod (this account: **`prod/Repflow`**; override **`PROD_SECRET_ID`** in the script if your name differs). Mongo is still split by **`MONGODB_DATABASE`**. For safer dev (test Stripe + dev **`API_BASE_URL`**), use **section 4** to clone into **`dev/Repflow-stack`** and update ARNs in **`apprunner.yaml` on `dev`** (and **`apprunner.dev.yaml`** if you keep them identical).

## 3. Dev App Runner: environment variables and secrets

### Why the console may not show “Environment variables”

If the service is wired to a **configuration file in the repo** (`apprunner.yaml` at the repo root, **Configuration source = Repository**), AWS **does not expose** those runtime settings in the console for editing — it reads **`run.env`** and **`run.secrets`** from the file on each deploy. The docs state that with a configuration file, **additional settings are hidden in the console** ([Configure an App Runner service](https://docs.aws.amazon.com/apprunner/latest/dg/manage-configure.html)).

**What to do (this repo):** the **`dev`** branch **`apprunner.yaml`** already contains the dev `run.env` / `run.secrets` stack. Point your **dev** App Runner service at the **`dev`** branch and redeploy. Production stays on **`main`**.

Check **Configuration** → **Source and deployment**: branch should be **`dev`** for the dev API service, **`main`** for production.

### If the console *does* let you edit (configuration from API / console)

1. **App Runner** → region **`us-east-2`** → open the **dev** service.
2. **Configuration** tab → **Edit**.
3. Open **Configure service** (not only “Configure build”).
4. Under **Service settings**, find **Environment variables - optional** ([Managing environment variables](https://docs.aws.amazon.com/apprunner/latest/dg/env-variable-manage.html)).
5. Add rows with source **Plain text** for the table below. For `MONGODB_URL`, Stripe, etc., use **Secrets Manager** and the same ARNs as in `apprunner.dev.yaml` (or your dev secret after section 4).

| Name | Value |
|------|--------|
| `COGNITO_REGION` | `us-east-2` |
| `COGNITO_POOL_ID` | `us-east-2_s82ysRbW8` |
| `COGNITO_CLIENT_ID` | `7mfnjnh9b4i464qlmt42c24fjk` |
| `MONGODB_DATABASE` | `repflow_dev` |
| `AWS_REGION` | `us-east-2` |
| `FROM_EMAIL` | `noreply@usereflow.me` (or your dev sender) |
| `YOUTUBE_REDIRECT_URI` | `http://localhost:3000/api/youtube/oauth/callback` (or your dev web URL + `/api/youtube/oauth/callback`) |
| `FRONTEND_URL` | `http://localhost:3000` (or your real dev site URL) |

Do **not** add a variable named `PORT` — it is reserved by App Runner.

6. **Save changes** → wait for deployment → open `https://<your-dev-service>/docs` or your health route.

## 4. Dev secret: clone prod (test Stripe + dev `API_BASE_URL`)

Run this from a machine whose **AWS credentials** can `GetSecretValue` on the **prod** Repflow secret (default **`prod/Repflow`**, set **`PROD_SECRET_ID`** otherwise) and `CreateSecret` / `PutSecretValue` on **`dev/Repflow-stack`** (or your **`DEV_SECRET_ID`**). Requires **AWS CLI** and **`jq`**.

**Interactive:**

```bash
cd /path/to/repflow
chmod +x scripts/create_dev_repflow_secret.sh
./scripts/create_dev_repflow_secret.sh
```

Prompts: dev App Runner base URL (no trailing slash), `sk_test_...`, optional test `whsec_...`. The script creates or updates **`dev/Repflow-stack`** and prints a full **`secrets:`** YAML block.

**After the script succeeds:**

1. Replace the entire **`secrets:`** section in **`apprunner.yaml`** on the **`dev`** branch (and **`apprunner.dev.yaml`** if you keep them identical) with the printed block — each `value-from` must use the **new** secret ARN suffix the script echoed.
2. Commit and push **`dev`** so the dev App Runner service redeploys (repository configuration source).
3. In **repflow-frontend** `.env.local`, set **`NEXT_PUBLIC_API_BASE_URL`** to that same dev App Runner URL (no trailing slash) so the UI hits the API whose secret now has matching **`API_BASE_URL`**.

**Non-interactive:**

```bash
export AWS_REGION=us-east-2
export DEV_SECRET_ID=dev/Repflow-stack
export DEV_API_BASE=https://YOUR-DEV-ID.us-east-2.awsapprunner.com
export DEV_STRIPE_SECRET=sk_test_xxxxxxxx
export DEV_STRIPE_WHSEC=whsec_xxxxxxxx   # optional
./scripts/create_dev_repflow_secret.sh
```

Fully unattended: `DEV_NONINTERACTIVE=1` plus **`DEV_API_BASE`** (required). If you omit **`DEV_STRIPE_SECRET`** / **`DEV_STRIPE_WHSEC`**, cloned JSON keeps prod values for those keys — avoid that when prod uses **live** Stripe.

## 5. repflow-frontend `.env.local`

Copy from **`env.example`** if you do not have a file yet. Keep **`.env.local` out of git** (it is gitignored).

| Variable | Rule |
|----------|------|
| `NEXT_PUBLIC_API_BASE_URL` | Same **stack** as the backend you call (dev App Runner URL or `http://localhost:8000` for local API). No trailing slash. |
| `AWS_COGNITO_USER_POOL_ID` / `AWS_COGNITO_CLIENT_ID` / `AWS_COGNITO_CLIENT_SECRET` | **Same pool and app client** as that backend’s `COGNITO_POOL_ID` / `COGNITO_CLIENT_ID` (dev pool `us-east-2_s82ysRbW8` + dev client when using the dev API). |
| Stripe (`NEXT_PUBLIC_STRIPE_*`, `STRIPE_SECRET_KEY`, payment links) | Dev/local: set **`NEXT_PUBLIC_STRIPE_TEST_MODE=true`**, **`pk_test`/`sk_test`**, and **test** Payment Links (Dashboard → Test mode). Production App Runner: omit test mode; use **`pk_live`/`sk_live`** and live links (see **`repflow-frontend/env.example`**). |
| `NEXTAUTH_URL` | For local Next.js: `http://localhost:3000`. |

Do **not** mix prod Cognito with a dev API URL (or the reverse).

## 6. CORS

**Defaults** in **`app.py`** include `http://localhost:3000`, common App Runner hosts, and **`https://creator.userepflow.com`**.

**Extra origins:** set **`CORS_ALLOWED_ORIGINS`** to a comma-separated list (no spaces around commas, or trim them in code — values are trimmed). App Runner: add a plain `env` entry in **`apprunner.yaml`** on **`dev`** (already present with an empty default; set the value to e.g. `https://your-preview.vercel.app`). Local: add to **`.env`**.

If the browser reports a CORS error, the **request’s `Origin` header** must appear in the merged list — add it via **`CORS_ALLOWED_ORIGINS`** and redeploy.

## 7. Optional: separate prod Atlas cluster

For paying users, use a dedicated **production** cluster for `repflow`, keep `dev-repflow` + `repflow_dev` for engineering. See `docs/BACKEND-REWORK.md`.

## Quick verification

**HTTP (dev or prod API URL, no trailing slash):**

```bash
cd /path/to/repflow
chmod +x scripts/verify_deployment_env.sh
API_BASE_URL=https://YOUR-DEV-ID.us-east-2.awsapprunner.com ./scripts/verify_deployment_env.sh
```

**Manual:**

- **Mongo:** Atlas **Data Explorer** → **`repflow_dev`** gains data when you exercise the **dev** API only (check prod DB is untouched if you intended dev-only traffic).
- **Cognito:** ID/access token issuer / pool matches **dev** pool `us-east-2_s82ysRbW8` when using the dev stack.
- **Frontend:** **`NEXT_PUBLIC_API_BASE_URL`** and **`AWS_COGNITO_*`** both target **dev** or **prod** together, never mixed.
- **CORS:** If a browser origin is blocked, add it to **`CORS_ALLOWED_ORIGINS`** (§6) and redeploy the API.
