# Testing Booking Link Feature

This guide explains how to test the AI Agent Booking Link feature using curl commands.

## Overview

The booking link feature allows creators to add a Calendly or other booking link to their profile. When a sponsorship prospect asks to book/schedule a call (detected via keywords), the AI agent automatically includes the creator's booking link in the response.

## Prerequisites

1. Backend server running: `pipenv run dev` (runs on `http://localhost:8000`)
2. A valid JWT token from Cognito (for user endpoints)
3. A user account in the database

## Testing Profile Endpoints

### 1. Get Current User Profile

Retrieve the current user's profile to see if `bookingLink` is set:

```bash
curl -X GET "http://localhost:8000/users/profile" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" | jq .
```

**Expected Response:**
```json
{
  "id": "user-uuid",
  "name": "Creator Name",
  "email": "creator@example.com",
  "repflow_username": "creatorusername",
  "bookingLink": "https://calendly.com/creator/meeting",
  ...
}
```

### 2. Update Booking Link (Recommended - Simple Endpoint)

Set or update just the booking link using the dedicated endpoint:

```bash
curl -X PATCH "http://localhost:8000/users/profile/booking-link" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "bookingLink": "https://calendly.com/creator/meeting"
  }' | jq .
```

**Response:** Returns the updated UserProfile object.

### 3. Remove Booking Link

To remove the booking link, set it to `null`:

```bash
curl -X PATCH "http://localhost:8000/users/profile/booking-link" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "bookingLink": null
  }' | jq .
```

### Alternative: Update Full Profile (Advanced)

You can also update the booking link as part of the full profile update:

```bash
curl -X PUT "http://localhost:8000/users/profile" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "id": "user-uuid",
    "name": "Creator Name",
    "email": "creator@example.com",
    "repflow_username": "creatorusername",
    "bookingLink": "https://calendly.com/creator/meeting",
    "subscription": {
      "tier": "pro",
      "status": "active"
    }
  }' | jq .
```

**Note:** The PUT endpoint requires all required fields (`id`, `name`, `email`, `repflow_username`, `subscription`). Use the PATCH endpoint above for simpler updates.

## Testing Booking Link in Email Agent

### Prerequisites for Email Testing

1. Create a service account with FSM permissions (see `docs/retool-fsm-tester.md`)
2. Set `API_AUTH_TOKEN` in your `.env.local` file
3. Ensure a user exists in the database with:
   - `profile.repflow_username` matching the local part of the test email
   - `profile.bookingLink` set to a valid URL

### Test Email with Booking Intent

Send an email that triggers booking link inclusion:

```bash
curl -X POST "http://localhost:8000/fsm/simulate/email" \
  -H "Authorization: ServiceAccount YOUR_SERVICE_ACCOUNT_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "subject": "Partnership inquiry - let'\''s schedule a call",
    "from_email": "brand@example.com",
    "to_email": "CREATOR_USERNAME@creator.userepflow.com",
    "content": "Hi! We would love to discuss a partnership opportunity. Can we book a call to discuss this further?"
  }' | jq .
```

**Booking Keywords Detected:**
The agent detects these keywords: `book`, `schedule`, `scheduling`, `calendly`, `calendar`, `call`, `meeting`, `chat`, `discuss`, `talk`, `zoom`, `meet`

**Expected Response:**
The `fsm_result.response_to_send` (or `reply_message.content`) should include:
```
... [normal response text] ...

You can book a time that works for you here: https://calendly.com/creator/meeting
```

### Test Email Without Booking Intent

Send an email that does NOT trigger booking link:

```bash
curl -X POST "http://localhost:8000/fsm/simulate/email" \
  -H "Authorization: ServiceAccount YOUR_SERVICE_ACCOUNT_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "subject": "Partnership inquiry",
    "from_email": "brand@example.com",
    "to_email": "CREATOR_USERNAME@creator.userepflow.com",
    "content": "Hi! We would love to discuss a partnership opportunity. What are your rates?"
  }' | jq .
```

**Expected Response:**
The response should NOT include the booking link since no booking keywords were detected.

## Troubleshooting

### Booking Link Not Appearing

1. **Check if booking link is set:**
   ```bash
   curl -X GET "http://localhost:8000/users/profile" \
     -H "Authorization: Bearer YOUR_JWT_TOKEN" | jq .bookingLink
   ```

2. **Check if booking keywords are present:**
   - The email content or subject must contain: `book`, `schedule`, `scheduling`, `calendly`, `calendar`, `call`, `meeting`, `chat`, `discuss`, `talk`, `zoom`, or `meet`

3. **Verify user exists:**
   - Ensure the user's `repflow_username` matches the local part of `to_email` in the test

### Getting JWT Token

If you need a JWT token for testing:

1. Use your frontend application to log in and capture the JWT token from the Authorization header
2. Or use AWS Cognito CLI/API to get a token for testing
3. Or use Postman/Insomnia with your Cognito credentials

## Implementation Details

- **Profile Endpoint:** `PUT /users/profile` (requires full UserProfile object)
- **Booking Link Field:** `bookingLink: Optional[HttpUrl]` in UserProfile model
- **Detection Logic:** `lambda_handler/lambda_function.py` lines 760-765
- **Keywords:** Defined in `BOOKING_INTENT_KEYWORDS` regex pattern (line 49-52)
