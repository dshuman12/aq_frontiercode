# Retool FSM Tester (Local)

Chat with the production FSM flow (no SES/S3) via `POST /fsm/simulate/email`, exposed through ngrok.

## 1) Backend + Auth prerequisites

- Run MongoDB locally (`MONGODB_URL`/`MONGODB_DATABASE` in `.env`).
- Create a service account with all required FSM permissions and keep the printed API key:

  ```bash
  cd repflow
  python - <<'PY'
  import asyncio
  from auth.service_auth import generate_api_key, hash_api_key
  from database.database import init_database, close_database
  from database.models.service_account import ServiceAccount, ServiceAccountStatus

  async def main():
      await init_database()
      api_key = generate_api_key()
      sa = ServiceAccount(
          service_name="retool-fsm-tester",
          api_key_hash=hash_api_key(api_key),
          permissions=[
              "fsm:test",
              "users:read_by_username",
              "leads:read",
              "leads:create", 
              "leads:update",
              "processed_emails:read",
              "processed_emails:create",
              "blacklist:read",
              "conversations:read",
              "conversations:create"
          ],
          status=ServiceAccountStatus.ACTIVE,
          created_by="local-dev",
          description="Temporary key for Retool FSM tester",
      )
      await sa.insert()
      print(f"\nRetool FSM Tester API key (copy this): {api_key}\n")
      await close_database()
  asyncio.run(main())
  PY
  ```

- `.env` essentials: `MONGODB_URL`, `MONGODB_DATABASE`, `API_AUTH_TOKEN=<the API key>`, `API_BASE_URL=http://localhost:8000`.
- Start the API: `cd repflow && uvicorn app:app --reload --host 0.0.0.0 --port 8000`.
- Expose it: `ngrok http 8000` and copy the `https://<subdomain>.ngrok.io` URL.

## 2) FSM shim endpoint

- `POST /fsm/simulate/email` (requires `Authorization: ServiceAccount <API_KEY>`)
  - Body: `{ "subject": "", "content": "", "from_email": "", "to_email": "", "thread_id": "optional", "message_id": "optional" }`
  - Returns: `fsm_result` (state + AI reply), `conversation_history`, `state_history`, `lead_state`, `reply_message`, `thread_id`, `message_id`.

## 3) Build the Retool app (empty app)

1. Add resource: REST API, base URL = your ngrok URL.
   - **Authentication**: Select "Bearer Token" and enter your service account API key.
   - **OR** use Headers section: Add header with key `Authorization` and value `ServiceAccount <API_KEY>`.
   - **Note**: If Retool rejects "Authorization" as a header name, use the Bearer Token authentication option instead (the API accepts both formats).
2. Query `sendEmail`: POST `/fsm/simulate/email` with JSON bound to inputs + optional `thread_id` state.
3. Components:
   - Inputs: `fromEmail`, `toEmail`, `subjectInput`; TextArea `emailBody`.
   - Temporary state `threadId` (set to `sendEmail.data.thread_id` after first send).
   - Button “Send email” → runs `sendEmail` (include `thread_id: threadId.value` if set).
   - TextArea “Conversation” ← `sendEmail.data.conversation_history`.
   - Text “Current state” ← `sendEmail.data.fsm_result.new_state`.
   - Table “State history” ← `sendEmail.data.state_history`.
   - Text “AI reply” ← `sendEmail.data.fsm_result.response_to_send`.
4. Flow: Send first email (captures `thread_id`), keep sending follow-ups with same `thread_id` to stay in-thread. FSM responds and advances state each time.

## 4) Tips

- Update the Retool base URL whenever ngrok restarts.
- State/trigger list lives in `lambda/fsm/state_machine.py` and `lambda/fsm/transitions.py`.
- If you already have a service account, add all required permissions (`fsm:test`, `users:read_by_username`, `leads:*`, `processed_emails:*`, `blacklist:read`, `conversations:*`) and reuse its key.

---

## 5) Testing the direct rate ask (rate range instead of reject)

When the prospect **asks for the creator's rate** (e.g. "what is your preferred rate?") instead of stating their budget, the agent should reply with a **rate range** (min to 2× min) instead of the "budget below minimum" rejection.

**Prerequisites:** Same as above: backend running, `API_AUTH_TOKEN` in env, user in DB whose `profile.repflow_username` matches the local part of `to_email`. That user's `preferences.absoluteMinimumRate` (default 1000) is used for the range.

**Test with curl** (replace `YOUR_SERVICE_ACCOUNT_API_KEY` and `CREATOR_USERNAME`):

```bash
curl -s -X POST "http://localhost:8000/fsm/simulate/email" \
  -H "Authorization: ServiceAccount YOUR_SERVICE_ACCOUNT_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "subject": "Partnership inquiry",
    "from_email": "brand@example.com",
    "to_email": "CREATOR_USERNAME@creator.userepflow.com",
    "content": "What is your preferred rate? We want to form a partnership that you are excited about!"
  }' | jq .
```

**Check:** `fsm_result.response_to_send` (or `reply_message.content`) should contain a **rate range** like: *"For this type of project, {name}'s rates typically range from $1000 to $2000, depending on scope. Happy to discuss what would work for your campaign."* (numbers depend on the creator's `absoluteMinimumRate`). `fsm_result.new_state` should be `needs_info`, not `rejected`.
