# FSM Sample Test Conversations

Use these in `scripts/fsm_chat.py` or `POST /fsm/simulate/email` to test everything implemented: **thread-per-subject**, **auto-category rejection**, **multi-deliverable deal display**, and **re-engagement + deal creation**.

**Prerequisites**

- Backend running: `pipenv run dev` (or uvicorn on port 8000).
- `API_AUTH_TOKEN` and `OPENAI_API_KEY` set (e.g. in `.env.local`).
- Creator user exists for `to_email` (e.g. `chikaosro@creator.userepflow.com`) with:
  - **autoRejectCategories**: include `"dating apps"` (for Scenario 1).
  - **absoluteMinimumRate**: e.g. `5000` (so we can test budget reject then re-engage in Scenario 3).
- For multi-deliverable (Scenario 2), no special config; parser should output one line per platform.

Use **one thread per scenario** (new `from_email` or new subject for Scenario 4). In `fsm_chat.py`, use a single session per scenario; for different subjects, change `SUBJECT` and run again or use curl with a different `subject`.

---

## Scenario 1: Auto-category rejection (qualify first, then category message)

Tests: **Qualify with website, rate, deliverables, timeline → then reply with category rejection; no deal, no “pass to creator”.**

**Setup:** Creator has `autoRejectCategories: ["dating apps"]`.

| Step | You (prospect) | Expected agent behavior |
|------|----------------|--------------------------|
| 1 | Hi, we're a dating app and would love to partner with you for a sponsored integration. Can we discuss? | Asks for missing details (e.g. website, rate, deliverables, timeline). |
| 2 | We're SwipeRight — website swipe right.com. We can do $8k flat for 2 YouTube integrations (60 sec each) and 1 Instagram story with link. Need it live by March 15, 2025. Contact is Jane Doe, jane@swiperight.com. | Has all required fields. **Expected reply:** “[Creator name] is not currently accepting partnerships in this category. If that changes, [Creator name] will reach out.” **No deal created; no “pass to creator”.** |

**What to verify**

- Lead reaches `NEEDS_EVALUATION` with brand_category set (e.g. “dating app”).
- Category matches “dating apps” → REJECT with the exact category message.
- `should_route_to_creator` is false; no new deal for this thread.

---

## Scenario 2: Multi-deliverable formatting (deal card line-by-line with icons)

Tests: **Multiple platforms in one deal → stored and returned as one line per platform for deal card (YouTube icon + text, Instagram icon + text).**

| Step | You (prospect) | Expected agent behavior |
|------|----------------|--------------------------|
| 1 | We'd like to do a sponsorship: 2x 60 sec YouTube integrations and 1x Instagram Story with link. Budget $12k, timeline by end of January 2025. Brand: Acme, site acme.com. I'm John, john@acme.com. | May ask for any missing fields (e.g. contact name already there). |
| 2 | John Smith, Brand Manager. Category: Tech. Deal type: flat fee. | Qualifies; moves to evaluation and then deal creation. |
| 3 | (Wait for reply) | Agent creates deal and sends confirmation. |

**What to verify**

- A **deal** is created for this thread.
- **GET /deals** or **GET /deals/{id}** returns `deliverablesDisplay` like:
  - `{ "platform": "youtube", "text": "2x 60 sec integrations" }`
  - `{ "platform": "instagram", "text": "1x Story Post w/ Link" }` (or equivalent).
- Deal card can render: `[YouTube Icon] 2x 60 sec integrations` and `[Instagram Icon] 1x Story Post w/ Link` on separate lines.

---

## Scenario 3: Re-engagement after rejection + deal creation

Tests: **Reject (e.g. budget) → prospect replies with better offer → context-aware “Thanks for the update — I've passed this along to [creator]…” and a deal is created when routing to creator.**

**Setup:** Creator `absoluteMinimumRate` e.g. 5000 so first offer can be rejected.

| Step | You (prospect) | Expected agent behavior |
|------|----------------|--------------------------|
| 1 | Partnership inquiry: we want 1 YouTube integration for $2k. Brand: Beta, beta.com. I'm Sam, sam@beta.com. Category: Fitness. | May ask for more details or evaluate. |
| 2 | 1x 60 sec YouTube integration, $2k flat, due Feb 28 2025. Deal type flat fee. | **Rejects** (budget below minimum): “Unfortunately, that budget is below [creator]'s minimum…” → state REJECTED. |
| 3 | We can increase to $6k for the same 1x 60 sec YouTube integration. Let's do it. | **Expected:** “Thanks for the update — I've passed this along to [Creator name], and we'll be in touch shortly.” **A deal is created** for this thread (route_email_to_creator creates deal when lead has no deal_id). |

**What to verify**

- After step 2, lead is REJECTED; no deal yet.
- After step 3, reply uses **“Thanks for the update”** (not the generic “Thanks for your message!”).
- Lead gets a `deal_id`; **GET /deals** shows a new deal for this thread.

---

## Scenario 4: Multi-thread (same sender, different subjects = different threads)

Tests: **Same sender email, different subject → different thread_id → separate leads/deals (e.g. agency with multiple brands).**

**How to run**

- **Thread A:** Use subject **“Partnership with Brand A”** and send 1–2 messages (e.g. “Hi, Brand A here, we’d like to partner…”). Note `thread_id` from response.
- **Thread B:** Use subject **“Partnership with Brand B”** and send 1–2 messages (e.g. “Hi, Brand B here, different campaign…”). Note `thread_id` from response.

Use the same `from_email` (e.g. agency@media.com) and same `to_email` (creator).

**What to verify**

- `thread_id` for Thread A ≠ `thread_id` for Thread B.
- **GET /leads/thread/{thread_id}** returns different leads for each thread.
- Two separate conversations/deals can exist for the same sender.

**Example (curl)**

```bash
# Thread A
curl -s -X POST http://localhost:8000/fsm/simulate/email \
  -H "Authorization: ServiceAccount $API_AUTH_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"subject":"Partnership with Brand A","from_email":"agency@media.com","to_email":"chikaosro@creator.userepflow.com","content":"Hi, Brand A here. We want a YouTube integration for $10k."}' | jq '.thread_id'

# Thread B (same from_email, different subject)
curl -s -X POST http://localhost:8000/fsm/simulate/email \
  -H "Authorization: ServiceAccount $API_AUTH_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"subject":"Partnership with Brand B","from_email":"agency@media.com","to_email":"chikaosro@creator.userepflow.com","content":"Hi, Brand B here. Different campaign, 1 Instagram post for $5k."}' | jq '.thread_id'
```

The two `thread_id` values should differ.

---

## Quick reference: one script that runs Scenario 2 (multi-deliverable)

Run in order in a single `fsm_chat.py` session (same thread):

```
You (prospect): We'd like to do a sponsorship: 2x 60 sec YouTube integrations and 1x Instagram Story with link. Budget $12k, timeline by end of January 2025. Brand: Acme, site acme.com. I'm John Smith, Brand Manager, john@acme.com. Category: Tech. Deal type: flat fee.
```

Then send any follow-up if the agent asks for more info. After a deal is created, call **GET /deals** and check `deliverablesDisplay` for line-by-line platform + text.

---

## Checklist

| Feature | Scenario | Pass criteria |
|--------|----------|----------------|
| Auto-category rejection message + no deal | 1 | Category reply exact; no deal; no route to creator |
| Multi-deliverable deal card (line-by-line + icon key) | 2 | Deal has `deliverablesDisplay` with one entry per platform |
| Re-engagement message + deal on “pass along” | 3 | “Thanks for the update” and new deal created |
| Thread = sender + recipient + subject | 4 | Same sender, different subject → different `thread_id` |
