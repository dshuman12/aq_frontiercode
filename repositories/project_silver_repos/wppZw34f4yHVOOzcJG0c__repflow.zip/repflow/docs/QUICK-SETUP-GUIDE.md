# Stripe: dev vs production

Keep **test** Stripe on dev/local and **live** Stripe on production. Never mix (e.g. live Payment Links with `pk_test`).

More context: [DEPLOYMENT-ENVIRONMENTS.md](./DEPLOYMENT-ENVIRONMENTS.md) §4–§5, `repflow-frontend/env.example`.

---

## Automated: wire the Next app (local `.env.local`)

You still copy **two** keys once from Stripe (same page); the script creates products/prices/payment links if needed and merges everything into `.env.local`.

1. `cd repflow-frontend`
2. `cp .env.stripe.secrets.example .env.stripe.secrets` — edit and set:
   - **Test:** [dashboard.stripe.com/test/apikeys](https://dashboard.stripe.com/test/apikeys) → `STRIPE_SECRET_KEY` + `STRIPE_PUBLISHABLE_KEY`
   - **Live:** [dashboard.stripe.com/apikeys](https://dashboard.stripe.com/apikeys) → `sk_live_` + `pk_live_`
3. `npm run stripe:sync` — writes a marked block into **`.env.local`** (creates `Repflow | Starter/Growth/Scale` products, monthly+yearly USD prices, Payment Links with stable metadata).

| Command | Purpose |
|---------|---------|
| `npm run stripe:sync` | Update `.env.local` |
| `npm run stripe:sync:dry` | Print the block only (e.g. paste into App Runner / Vercel) |

- **Test keys** → script sets `NEXT_PUBLIC_STRIPE_TEST_MODE=true`.
- **Live keys** → script omits test mode (use live defaults in app when vars missing).

`.env.stripe.secrets` is gitignored. Do **not** commit `.env.local`.

**Hosted prod/dev:** run `stripe:sync:dry` with the right keys, copy the printed lines into your host’s env UI, then rebuild so `NEXT_PUBLIC_*` are embedded.

---

## Can I do this with Stripe MCP (e.g. in Cursor)?

**Partly.** The MCP talks to Stripe’s API using **one** secret key configured on the MCP server. That key decides test vs live — there is **no separate “test mode” switch** in MCP.

| MCP secret key | What you get |
|----------------|----------------|
| `sk_test_...` | Test **Prices**, **Payment Links**, customers, etc. |
| `sk_live_...` | Live objects only |

**What MCP can automate:** list/create products & prices, **create Payment Links** (`create_payment_link`), list customers, subscriptions, etc. — same flows as the guide, without the Dashboard toggle.

**What MCP does *not* replace by itself:** merging into **`.env.local`** — use **`npm run stripe:sync`** above instead, or paste MCP output manually.

**Setup:** In Cursor, open the Stripe MCP configuration and set the API key to **`sk_test_...`** for dev work or **`sk_live_...`** for production-only operations. Then use MCP tools to create links and copy URLs into your env files.

**If the Dashboard has no “Test mode” toggle:** open test keys directly: [dashboard.stripe.com/test/apikeys](https://dashboard.stripe.com/test/apikeys). Some accounts (restricted roles, certain org layouts) hide the old toggle; test vs live is still determined by which keys and URLs you use.

---

## Frontend (`repflow-frontend`)

Signup uses **Payment Link** URLs + **`price_...`** IDs from env. Server routes (confirm payment, upgrade card, etc.) use **`STRIPE_SECRET_KEY`**.

### Development / dev deployment

1. In [Stripe Dashboard](https://dashboard.stripe.com), turn **Test mode** **on**.
2. Create **test** Payment Links for Starter, Growth, Scale — **monthly and yearly** — tied to test **Prices** (`price_...`).
3. Set in `.env.local` or your **dev** host env (build-time for `NEXT_PUBLIC_*`):

| Variable | Value |
|----------|--------|
| `NEXT_PUBLIC_STRIPE_TEST_MODE` | `true` |
| `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY` | `pk_test_...` |
| `STRIPE_SECRET_KEY` | `sk_test_...` |
| `NEXT_PUBLIC_STRIPE_STARTER_PAYMENT_LINK` | test link URL |
| `NEXT_PUBLIC_STRIPE_GROWTH_PAYMENT_LINK` | test link URL |
| `NEXT_PUBLIC_STRIPE_SCALE_PAYMENT_LINK` | test link URL |
| `NEXT_PUBLIC_STRIPE_*_YEARLY_PAYMENT_LINK` | three test yearly URLs |
| `NEXT_PUBLIC_STRIPE_*_PRICE_ID` | test **`price_...`** IDs (not `prod_...`) |

If **`NEXT_PUBLIC_STRIPE_TEST_MODE=true`**, missing links/price env vars stay **empty** — you must set all of them so checkout is not live.

### Production

1. **Test mode** **off** in Dashboard.
2. Do **not** set `NEXT_PUBLIC_STRIPE_TEST_MODE` (or set `false`). Then live defaults in code apply when an env var is omitted, or set explicit live values in `apprunner.yaml` / Vercel.

| Variable | Value |
|----------|--------|
| `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY` | `pk_live_...` |
| `STRIPE_SECRET_KEY` | `sk_live_...` (e.g. Secrets Manager) |
| Payment link + price env vars | **Live** links and **`price_...`** IDs |

---

## Backend (`repflow`)

Webhooks and server-side Stripe use **`STRIPE_SECRET_KEY`** from the API’s environment (e.g. AWS Secrets Manager).

| Stack | Stripe secret |
|--------|----------------|
| **Dev** App Runner | `sk_test_...` in **`dev/Repflow-stack`** (see `scripts/create_dev_repflow_secret.sh`) |
| **Prod** App Runner | `sk_live_...` in prod secret |

Use a **test** webhook signing secret (`whsec_...`) for dev if you forward test events.

---

## After changing Stripe env

Rebuild/redeploy the **frontend** so **`NEXT_PUBLIC_*`** values are embedded. Redeploy the **API** if you change its Stripe secret or webhook secret.
