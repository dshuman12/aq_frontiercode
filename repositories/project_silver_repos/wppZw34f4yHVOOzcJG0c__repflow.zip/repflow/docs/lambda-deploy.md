# Deploy Email Automation to AWS Lambda

This guide covers building the deployment package and deploying the FSM email handler to AWS Lambda (triggered by SES when emails are received).

## 1. Build the deployment package

**Must run from the `lambda_handler` directory** (the script expects `lambda_function.py` and `requirements.txt` in the current directory):

```bash
cd lambda_handler
python package.py
```

- Installs dependencies for **Linux x86_64** (Lambda runtime) into a `package/` folder.
- Zips dependencies at the root, then adds `lambda_function.py`, `api_client.py`, and the `ai_agents/`, `fsm/`, `database/`, `business/` modules.
- Output: **`lambda_handler/lambda_deployment_package.zip`** (often ~45MB+).

Use this zip as the Lambda deployment package in the next steps.

## 2. Create or update the Lambda function

### Option A: Terminal only (AWS CLI + script)

From the **project root**, with the zip already built:

1. **Set env vars** (export in the same shell or put in `scripts/deploy.env` and the script will source it):

   ```bash
   export API_BASE_URL="https://api.repflow.com"
   export API_AUTH_TOKEN="your-service-account-key"
   export S3_BUCKET="your-email-bucket"
   export SES_REGION="us-east-2"
   export OPENAI_API_KEY="sk-..."
   # optional: FRONTEND_URL, DEMO_EMAIL_AGENT_DISABLE_SEND, LAMBDA_FUNCTION_NAME, AWS_REGION
   ```

2. **One-time: create IAM role + Lambda**

   ```bash
   chmod +x scripts/deploy_lambda.sh
   ./scripts/deploy_lambda.sh create
   ```

3. **Update code + config (env vars, timeout, memory)**

   ```bash
   ./scripts/deploy_lambda.sh update
   ```

4. **Later: code-only redeploy**

   ```bash
   ./scripts/deploy_lambda.sh code
   ```

5. **SES trigger (no console)** – add receipt rule so SES stores mail in S3 and invokes Lambda:

   ```bash
   ./scripts/deploy_lambda.sh ses-trigger
   ```

   Uses `S3_BUCKET` and `SES_REGION` from `scripts/deploy.env`. Mail to `*@repflow.me` (or set `RECIPIENT_DOMAIN` in deploy.env) will trigger the rule. Optional: `SES_RULE_SET_NAME` (default: `default`).

   **Before running:** (1) Ensure the rule set exists; if not: `aws ses create-receipt-rule-set --region $SES_REGION --rule-set-name default` then `aws ses set-active-receipt-rule-set --region $SES_REGION --rule-set-name default`. (2) S3 bucket must have a policy allowing SES to write (see [AWS: Giving Amazon SES permission to write to your Amazon S3 bucket](https://docs.aws.amazon.com/ses/latest/dg/receiving-email-permissions.html#receiving-email-permissions-s3)).

### Option B: AWS Console (web UI)

1. **Lambda** → Create function (or open the existing one).
2. **Runtime:** Python 3.13 (or the version `package.py` used; see `--python-version` in `package.py`).
3. **Handler:** `lambda_function.lambda_handler`
4. **Code:** Upload `lambda_deployment_package.zip` (or upload via S3 and point Lambda to it).
5. **Configuration → General:**
   - Memory: 512 MB or higher (OpenAI + FSM).
   - Timeout: 60–120 seconds.
6. **Configuration → Environment variables:** Add (see below).

### Option C: AWS CLI (manual)

If you prefer not to use the script:

```bash
# Create function (first time; use an existing or new IAM role ARN)
aws lambda create-function \
  --function-name repflow-email-handler \
  --runtime python3.13 \
  --handler lambda_function.lambda_handler \
  --role arn:aws:iam::ACCOUNT_ID:role/YOUR_LAMBDA_EXECUTION_ROLE \
  --zip-file fileb://lambda_handler/lambda_deployment_package.zip \
  --timeout 120 \
  --memory-size 512

# Update code (subsequent deploys)
aws lambda update-function-code \
  --function-name repflow-email-handler \
  --zip-file fileb://lambda_handler/lambda_deployment_package.zip

# Set env vars (use Variables key in JSON)
aws lambda update-function-configuration \
  --function-name repflow-email-handler \
  --environment 'Variables={API_BASE_URL=https://...,API_AUTH_TOKEN=...,S3_BUCKET=...,SES_REGION=us-east-2,OPENAI_API_KEY=...}'
```

Replace `ACCOUNT_ID` and `YOUR_LAMBDA_EXECUTION_ROLE` with your role that has Lambda execution permissions.

## 3. Environment variables

Set these in Lambda **Configuration → Environment variables**:

| Variable | Required | Description |
|----------|----------|-------------|
| `API_BASE_URL` | Yes | Backend API base URL (e.g. `https://api.repflow.com`). |
| `API_AUTH_TOKEN` | Yes | Service account API key for backend (leads, conversations, deals, etc.). |
| `S3_BUCKET` | Yes | S3 bucket where SES stores incoming emails (path prefix: `emails/`). |
| `SES_REGION` | Yes | SES region (e.g. `us-east-2`). |
| `OPENAI_API_KEY` | Yes | OpenAI API key for classification and other agents. |
| `DEMO_EMAIL_AGENT_DISABLE_SEND` | No | Set to `true` to disable sending replies via SES (for testing). Omit or `false` in production. |
| `INBOUND_EMAIL_DOMAIN` | No | Domain for creator inboxes (e.g. `repflow.me`). Used to pick the correct `To` when SES delivers mail with multiple recipients. Default: `repflow.me`. Must match your SES receipt rule recipient domain. |

Optional: `FRONTEND_URL` if you use it in response links.

## 4. IAM permissions

The Lambda execution role needs:

- **S3:** `GetObject` on the bucket used for incoming mail (e.g. `arn:aws:s3:::YOUR_BUCKET/emails/*`).
- **SES:** `SendEmail` (and optionally `SendRawEmail`) in the same region as `SES_REGION`.
- **CloudWatch Logs:** Create log group and write log streams (auto if using the default Lambda execution role).
- **VPC:** Only if your backend is in a VPC; then add VPC config and ensure NAT/security groups allow HTTPS to your API.

## 5. Trigger: SES receipt rule

The handler expects an **SES receipt rule** event: `event["Records"][0]["ses"]`. It also reads the raw email from S3 at `s3_key = "emails/" + message_id`.

1. **SES** → **Receipt rules** (in the region matching `SES_REGION`).
2. Create or edit a rule that matches incoming mail (e.g. recipient `*@repflow.me`).
3. **Actions** for the rule:
   - **S3:** Store incoming email in `S3_BUCKET` (so objects land under a path your code expects; the code uses `emails/<message_id>`).
   - **Lambda:** Invoke `repflow-email-handler` (or your function name).

If your rule stores mail under a different prefix, you’ll need to align either the rule or the code (e.g. `s3_key` in `lambda_function.py`).

## 6. Verify deployment

- Send a test email to an address that matches the SES receipt rule.
- Check **CloudWatch** → Log groups → `/aws/lambda/repflow-email-handler` for logs and errors.
- Confirm the backend receives lead/conversation updates (e.g. via your API or DB).

## 7. Redeploy after code changes

```bash
cd lambda_handler
python package.py
# Then upload the new lambda_deployment_package.zip via Console or:
aws lambda update-function-code \
  --function-name repflow-email-handler \
  --zip-file fileb://lambda_deployment_package.zip
```

## Troubleshooting

- **Handler / import errors:** Ensure the zip has `lambda_function.py` and the `ai_agents`, `fsm`, `database`, `business`, and `api_client` modules at the root (no extra top-level folder inside the zip).
- **Timeout:** Increase Lambda timeout (e.g. 120 s) and/or memory; OpenAI and multiple FSM steps can be slow.
- **S3 key not found:** Confirm SES is writing to the same bucket and path pattern (`emails/<message_id>` or adjust code).
- **SES “Email address not verified”:** In sandbox, verify sender and recipient addresses in SES.
