import hashlib
import secrets
from typing import Optional, Union, List
from datetime import datetime, timezone

from fastapi import HTTPException, status, Header, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from starlette.requests import Request

from database.models.service_account import ServiceAccount, ServiceAccountStatus
from utils.error_handler import ErrorCodes, raise_http_exception
import logging

logger = logging.getLogger("uvicorn.error")


class ServiceAccountCredentials:
    """Represents authenticated service account credentials."""

    def __init__(self, service_account: ServiceAccount):
        self.service_account = service_account
        self.service_name = service_account.service_name
        self.permissions = service_account.permissions
        self.uuid = service_account.uuid

    def has_permission(self, permission: str) -> bool:
        """Check if the service account has a specific permission."""
        return permission in self.permissions

    def require_permission(self, permission: str) -> None:
        """Raise HTTPException if the service account lacks a permission."""
        if not self.has_permission(permission):
            raise_http_exception(
                ErrorCodes.INSUFFICIENT_PERMISSIONS,
                f"Service account '{self.service_name}' lacks permission: {permission}",
            )


def hash_api_key(api_key: str) -> str:
    """Hash an API key for secure storage."""
    return hashlib.sha256(api_key.encode()).hexdigest()


def generate_api_key() -> str:
    """Generate a secure API key."""
    return secrets.token_urlsafe(32)


async def get_service_account_from_header(
    authorization: str = Header(None),
) -> Optional[ServiceAccountCredentials]:
    """Extract and validate service account from Authorization header."""
    if not authorization:
        return None

    if not authorization.startswith("ServiceAccount "):
        return None

    try:
        # Extract API key from header
        api_key = authorization.split(" ", 1)[1]

        # Hash the provided key for comparison
        api_key_hash = hash_api_key(api_key)

        # Find service account by hashed key
        service_account = await ServiceAccount.find_one(
            ServiceAccount.api_key_hash == api_key_hash
        )

        if not service_account:
            return None

        # Check if service account is active
        if service_account.status != ServiceAccountStatus.ACTIVE:
            raise_http_exception(
                ErrorCodes.FORBIDDEN,
                f"Service account '{service_account.service_name}' is {service_account.status.value}",
            )


        # Check if service account has expired
        if service_account.expires_at and service_account.expires_at < datetime.now(
            timezone.utc
        ):
            # Update status to expired
            service_account.status = ServiceAccountStatus.EXPIRED
            await service_account.save()

            raise_http_exception(
                ErrorCodes.FORBIDDEN,
                f"Service account '{service_account.service_name}' has expired",
            )

        # Update last_used_at timestamp
        service_account.last_used_at = datetime.now(timezone.utc)
        await service_account.save()

        return ServiceAccountCredentials(service_account)

    except Exception as e:
        if isinstance(e, HTTPException):
            raise e
        # Don't log the actual API key for security
        print(f"Error validating service account: {str(e)}")
        return None


class ServiceAccountBearer(HTTPBearer):
    """HTTPBearer subclass for service account authentication."""

    def __init__(self, auto_error: bool = True):
        super().__init__(auto_error=auto_error)

    async def __call__(self, request: Request) -> Optional[ServiceAccountCredentials]:
        credentials: HTTPAuthorizationCredentials = await super().__call__(request)

        if not credentials:
            return None

        if credentials.scheme != "ServiceAccount":
            if self.auto_error:
                raise_http_exception(
                    ErrorCodes.INVALID_TOKEN,
                    "Invalid authentication scheme. Expected 'ServiceAccount'",
                )
            return None

        # Reconstruct the authorization header
        authorization = f"ServiceAccount {credentials.credentials}"
        return await get_service_account_from_header(authorization)


# Global service account bearer instance
service_auth = ServiceAccountBearer(auto_error=False)


async def get_service_account(
    credentials: Optional[ServiceAccountCredentials] = Depends(service_auth),
) -> Optional[ServiceAccountCredentials]:
    """Dependency to get service account credentials (optional)."""
    return credentials


async def require_service_account(
    credentials: Optional[ServiceAccountCredentials] = Depends(service_auth),
) -> ServiceAccountCredentials:
    """Dependency to require service account authentication."""
    if not credentials:
        raise_http_exception(
            ErrorCodes.UNAUTHORIZED, "Service account authentication required"
        )
    return credentials


def require_service_permission(permission: str):
    """Dependency factory to require a specific service account permission."""

    async def _require_permission(
        credentials: ServiceAccountCredentials = Depends(require_service_account),
    ) -> ServiceAccountCredentials:
        credentials.require_permission(permission)
        return credentials

    return _require_permission


# Combined authentication types
AuthContext = Union[str, ServiceAccountCredentials]  # User ID string or ServiceAccount


async def get_auth_context(authorization: str = Header(None)) -> Optional[AuthContext]:
    """Get authentication context from either JWT or Service Account."""
    if not authorization:
        return None

    # Try service account first (ServiceAccount scheme)
    if authorization.startswith("ServiceAccount "):
        return await get_service_account_from_header(authorization)

    # Try JWT authentication (Bearer scheme)
    elif authorization.startswith("Bearer "):
        logger.info("Trying JWT authentication")
        # Import here to avoid circular imports
        from routers.utils import auth

        # Extract the token from the Bearer header
        token = authorization.replace("Bearer ", "").strip()

        if not token:
            logger.warning("Empty token in Bearer header")
            return None

        # Create a proper request object for JWT validation
        from fastapi import Request
        from starlette.datastructures import Headers

        # Create a mock request that the JWTBearer class can process
        headers = Headers({"authorization": authorization})
        request = Request(
            {
                "type": "http",
                "method": "GET",
                "path": "/",
                "headers": headers.raw,
                "query_string": b"",
                "server": ("localhost", 8000),
            }
        )

        logger.info(f"Processing Bearer token: {token[:20]}...")

        # Try JWT authentication first (wrap in try-except to handle non-JWT tokens)
        jwt_credentials = None
        try:
            jwt_credentials = await auth(request)
        except (ValueError, HTTPException, Exception) as e:
            # Token is not a valid JWT format - will try as service account below
            logger.debug(
                f"JWT validation failed (expected for service account keys): {type(e).__name__}"
            )
            jwt_credentials = None

        if jwt_credentials:
            logger.info("JWT authentication successful")

            # Extract user ID from JWT claims using the same logic as get_current_user
            user_id = None
            try:
                if "cognito:username" in jwt_credentials.claims:
                    user_id = jwt_credentials.claims["cognito:username"]
                elif "username" in jwt_credentials.claims:
                    user_id = jwt_credentials.claims["username"]
                elif "sub" in jwt_credentials.claims:
                    user_id = jwt_credentials.claims["sub"]
                elif "email" in jwt_credentials.claims:
                    user_id = jwt_credentials.claims["email"]

                if user_id:
                    logger.info(f"Extracted user ID from JWT: {user_id}")

                    # Validate that the user exists in the database
                    from database.models.user import User

                    user = await User.find_one(User.uuid == user_id)

                    if user:
                        logger.info(f"User validation successful for: {user_id}")
                        return user_id
                    else:
                        logger.warning(f"User not found in database: {user_id}")
                        return None
                else:
                    logger.warning("No valid user ID found in JWT claims")
                    return None

            except Exception as e:
                logger.error(f"Error extracting user ID from JWT claims: {e}")
                return None
        else:
            # JWT validation failed - try as service account API key (for Retool compatibility)
            try:
                # Try treating the Bearer token as a service account API key
                service_auth_header = f"ServiceAccount {token}"
                service_account = await get_service_account_from_header(
                    service_auth_header
                )
                if service_account:
                    return service_account
            except Exception as e:
                logger.debug(f"Service account fallback failed: {e}")
                pass

            return None

    return None


async def get_current_user_or_service(
    auth_context: Optional[AuthContext] = Depends(get_auth_context),
) -> AuthContext:
    """Dependency that requires either user JWT or service account authentication."""
    if not auth_context:
        raise_http_exception(
            ErrorCodes.UNAUTHORIZED, "Authentication required (JWT or Service Account)"
        )
    return auth_context


def is_service_account(auth_context: AuthContext) -> bool:
    """Check if auth context is a service account."""
    return isinstance(auth_context, ServiceAccountCredentials)


def is_user_auth(auth_context: AuthContext) -> bool:
    """Check if auth context is a user (JWT)."""
    return isinstance(auth_context, str)


def get_user_id(auth_context: AuthContext) -> Optional[str]:
    """Extract user ID from auth context if it's user auth."""
    if is_user_auth(auth_context):
        return auth_context
    return None


def get_service_account_from_context(
    auth_context: AuthContext,
) -> Optional[ServiceAccountCredentials]:
    """Extract service account from auth context if it's service account auth."""
    if is_service_account(auth_context):
        return auth_context
    return None
