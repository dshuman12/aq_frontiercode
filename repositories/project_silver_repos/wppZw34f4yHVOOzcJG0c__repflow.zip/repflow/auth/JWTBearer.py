from typing import Dict, Optional, List, Any, Union

from fastapi import HTTPException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import jwt, jwk, JWTError
from jose.utils import base64url_decode
from pydantic import BaseModel
from starlette.requests import Request
from fastapi import status

JWK = Dict[str, str]


class JWKS(BaseModel):
    keys: List[JWK]


class JWTAuthorizationCredentials(BaseModel):
    jwt_token: str
    header: Dict[str, str]
    claims: Dict[str, Any]  # Changed to accept mixed types (strings, integers, etc.)
    signature: str
    message: str


class JWTBearer(HTTPBearer):
    def __init__(self, jwks: JWKS, auto_error: bool = True):
        super().__init__(auto_error=auto_error)

        self.kid_to_jwk = {jwk["kid"]: jwk for jwk in jwks.keys}

    def verify_jwk_token(self, jwt_credentials: JWTAuthorizationCredentials) -> bool:
        token_kid = jwt_credentials.header.get("kid")
        available_kids = list(self.kid_to_jwk.keys())
        
        try:
            public_key = self.kid_to_jwk[token_kid]
        except KeyError:
            # Log detailed error for debugging
            import logging
            logger = logging.getLogger("uvicorn.error")
            logger.error(
                f"JWK public key not found. Token kid: '{token_kid}', "
                f"Available kids: {available_kids}, "
                f"Total keys in JWKS: {len(self.kid_to_jwk)}"
            )
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"JWK public key not found. Token key ID '{token_kid}' not in JWKS. "
                       f"Available keys: {available_kids}. "
                       f"The backend must use the same Cognito User Pool and region as this app."
            )

        key = jwk.construct(public_key)
        decoded_signature = base64url_decode(jwt_credentials.signature.encode())

        return key.verify(jwt_credentials.message.encode(), decoded_signature)

    async def __call__(self, request: Request) -> Optional[JWTAuthorizationCredentials]:
        credentials: HTTPAuthorizationCredentials = await super().__call__(request)
        
        # Need to update this to account for different Cognito issuers
        if credentials:
            
            if not credentials.scheme == "Bearer":
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN, detail="Wrong authentication method"
                )

            jwt_token = credentials.credentials

            # A valid JWT has three dot-separated parts (header.payload.signature).
            # Guard against malformed tokens so we raise a clear 403 instead of
            # letting a ValueError propagate past the CORS middleware.
            parts = jwt_token.rsplit(".", 1)
            if len(parts) != 2 or not parts[0] or not parts[1]:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Malformed JWT token",
                )
            message, signature = parts

            try:
                # Decode and log the JWT payload
                header = jwt.get_unverified_header(jwt_token)
                claims = jwt.get_unverified_claims(jwt_token)
                
                # Verify issuer matches expected Cognito User Pool
                import os
                cognito_region = os.environ.get("COGNITO_REGION")
                cognito_pool_id = os.environ.get("COGNITO_POOL_ID")
                if cognito_region and cognito_pool_id:
                    expected_issuer = f"https://cognito-idp.{cognito_region}.amazonaws.com/{cognito_pool_id}"
                    token_issuer = claims.get("iss")
                    if token_issuer and token_issuer != expected_issuer:
                        import logging
                        logger = logging.getLogger("uvicorn.error")
                        logger.warning(
                            f"Token issuer mismatch. Expected: {expected_issuer}, "
                            f"Got: {token_issuer}"
                        )
                
                jwt_credentials = JWTAuthorizationCredentials(
                    jwt_token=jwt_token,
                    header=header,
                    claims=claims,
                    signature=signature,
                    message=message,
                )
            except JWTError:
                raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="JWK invalid")

            if not self.verify_jwk_token(jwt_credentials):
                raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="JWK invalid")

            return jwt_credentials