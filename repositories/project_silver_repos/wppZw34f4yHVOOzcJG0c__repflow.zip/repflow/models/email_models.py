"""
Email-related Pydantic models for request/response validation.
"""

from pydantic import BaseModel, EmailStr, Field, field_validator, model_validator, ConfigDict
from typing import List, Optional, Dict, Any
from datetime import datetime


class EmailRequest(BaseModel):
    """Request model for sending a single email."""
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "to_addresses": ["recipient@example.com"],
                "subject": "Test Email",
                "body_text": "This is a test email sent via AWS SES.",
                "body_html": "<h1>Test Email</h1><p>This is a test email sent via AWS SES.</p>",
                "from_address": "sender@example.com"
            }
        }
    )
    
    to_addresses: List[EmailStr] = Field(..., description="List of recipient email addresses", min_length=1)
    subject: str = Field(..., description="Email subject line", max_length=998)
    body_text: Optional[str] = Field(None, description="Plain text email body")
    body_html: Optional[str] = Field(None, description="HTML email body")
    from_address: Optional[EmailStr] = Field(None, description="Sender email address (uses default if not provided)")
    cc_addresses: Optional[List[EmailStr]] = Field(None, description="List of CC email addresses")
    bcc_addresses: Optional[List[EmailStr]] = Field(None, description="List of BCC email addresses")
    reply_to_addresses: Optional[List[EmailStr]] = Field(None, description="List of reply-to email addresses")
    configuration_set_name: Optional[str] = Field(None, description="SES configuration set name")
    
    # Conversation-related fields
    deal_id: Optional[str] = Field(None, description="ID of deal this email belongs to")
    user_id: Optional[str] = Field(None, description="ID of user sending the email")
    sender_name: Optional[str] = Field(None, description="Name of the sender")
    
    @field_validator('to_addresses', 'cc_addresses', 'bcc_addresses', 'reply_to_addresses')
    @classmethod
    def validate_email_lists(cls, v: Optional[List[EmailStr]]) -> Optional[List[EmailStr]]:
        """Validate email address lists."""
        if v is not None and len(v) == 0:
            return None  # Convert empty lists to None
        return v
    
    @model_validator(mode='after')
    def validate_body_content(self) -> 'EmailRequest':
        """Ensure at least one body type is provided."""
        if not self.body_text and not self.body_html:
            raise ValueError('Either body_text or body_html must be provided')
        return self


class BulkEmailRequest(BaseModel):
    """Request model for sending bulk emails."""
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "emails": [
                    {
                        "to_addresses": ["user1@example.com"],
                        "subject": "Welcome to our service!",
                        "body_text": "Welcome! Thanks for joining us."
                    },
                    {
                        "to_addresses": ["user2@example.com"],
                        "subject": "Your order confirmation",
                        "body_html": "<h1>Order Confirmed</h1><p>Your order has been confirmed.</p>"
                    }
                ],
                "default_from_address": "noreply@example.com"
            }
        }
    )
    
    emails: List[EmailRequest] = Field(..., description="List of emails to send", min_length=1, max_length=50)
    default_from_address: Optional[EmailStr] = Field(None, description="Default sender address for all emails")


class EmailResponse(BaseModel):
    """Response model for email sending operations."""
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "success": True,
                "message_id": "0000014a-f896-4c07-b8ff-example-message-id",
                "to_addresses": ["recipient@example.com"],
                "subject": "Test Email",
                "timestamp": "2024-01-15T10:30:00Z"
            }
        }
    )
    
    success: bool = Field(..., description="Whether the email was sent successfully")
    message_id: Optional[str] = Field(None, description="AWS SES Message ID")
    to_addresses: List[str] = Field(..., description="List of recipient addresses")
    subject: str = Field(..., description="Email subject")
    error: Optional[str] = Field(None, description="Error message if sending failed")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="When the email was processed")
    
    # Conversation-related response fields
    conversation_message_id: Optional[str] = Field(None, description="ID of the message created in conversation")
    conversation_id: Optional[str] = Field(None, description="ID of the conversation the message was added to")


class BulkEmailResponse(BaseModel):
    """Response model for bulk email operations."""
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "total_emails": 2,
                "successful_emails": 2,
                "failed_emails": 0,
                "results": [
                    {
                        "success": True,
                        "message_id": "0000014a-f896-4c07-b8ff-example-message-id-1",
                        "to_addresses": ["user1@example.com"],
                        "subject": "Welcome to our service!"
                    },
                    {
                        "success": True,
                        "message_id": "0000014a-f896-4c07-b8ff-example-message-id-2",
                        "to_addresses": ["user2@example.com"],
                        "subject": "Your order confirmation"
                    }
                ]
            }
        }
    )
    
    total_emails: int = Field(..., description="Total number of emails processed")
    successful_emails: int = Field(..., description="Number of emails sent successfully")
    failed_emails: int = Field(..., description="Number of emails that failed to send")
    results: List[EmailResponse] = Field(..., description="Individual results for each email")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="When the bulk operation was processed")


class SESQuotaResponse(BaseModel):
    """Response model for SES quota information."""
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "max_24_hour_send": 200.0,
                "max_send_rate": 1.0,
                "sent_last_24_hours": 5.0
            }
        }
    )
    
    max_24_hour_send: float = Field(..., description="Maximum emails that can be sent in 24 hours")
    max_send_rate: float = Field(..., description="Maximum emails that can be sent per second")
    sent_last_24_hours: float = Field(..., description="Number of emails sent in the last 24 hours")


class EmailVerificationRequest(BaseModel):
    """Request model for email address verification."""
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "email_address": "verify@example.com"
            }
        }
    )
    
    email_address: EmailStr = Field(..., description="Email address to verify")


class EmailVerificationResponse(BaseModel):
    """Response model for email verification operations."""
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "success": True,
                "email_address": "verify@example.com",
                "message": "Verification email sent successfully"
            }
        }
    )
    
    success: bool = Field(..., description="Whether the verification request was sent successfully")
    email_address: str = Field(..., description="Email address that was verified")
    message: str = Field(..., description="Status message")


class VerifiedEmailsResponse(BaseModel):
    """Response model for listing verified email addresses."""
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "verified_emails": [
                    "noreply@example.com",
                    "support@example.com"
                ],
                "count": 2
            }
        }
    )
    
    verified_emails: List[str] = Field(..., description="List of verified email addresses")
    count: int = Field(..., description="Number of verified email addresses")
