"""
Centralized error handling utilities for the API.
Provides consistent error responses and status codes across all endpoints.
"""

import logging
from typing import Any, Dict, Optional, NoReturn
from bson.errors import BSONError
from fastapi import HTTPException, status
from fastapi.exceptions import RequestValidationError
from pydantic import BaseModel, ValidationError
from pymongo.errors import PyMongoError

logger = logging.getLogger("uvicorn.error")


class ErrorResponse(BaseModel):
    """Standard error response model."""

    error: str
    detail: Optional[str] = None
    status_code: int
    timestamp: Optional[str] = None


class APIError(Exception):
    """Custom API error exception with status code and details."""

    def __init__(
        self,
        message: str,
        status_code: int = status.HTTP_500_INTERNAL_SERVER_ERROR,
        detail: Optional[str] = None,
        log_level: str = "error",
    ):
        self.message = message
        self.status_code = status_code
        self.detail = detail
        self.log_level = log_level
        super().__init__(message)

    def to_http_exception(self) -> HTTPException:
        """Convert to FastAPI HTTPException."""
        return HTTPException(
            status_code=self.status_code,
            detail={
                "error": self.message,
                "detail": self.detail,
                "status_code": self.status_code,
            },
        )


class ErrorCodes:
    """Standardized error codes and messages."""

    # Authentication & Authorization
    UNAUTHORIZED = APIError(
        "Authentication required",
        status.HTTP_401_UNAUTHORIZED,
        "Valid authentication credentials are required to access this resource",
    )

    FORBIDDEN = APIError(
        "Access denied",
        status.HTTP_403_FORBIDDEN,
        "You don't have permission to perform this action",
    )

    INVALID_TOKEN = APIError(
        "Invalid authentication token",
        status.HTTP_401_UNAUTHORIZED,
        "The provided authentication token is invalid or expired",
    )

    INSUFFICIENT_PERMISSIONS = APIError(
        "Insufficient permissions",
        status.HTTP_403_FORBIDDEN,
        "Your account lacks the required permissions for this action",
    )

    # Validation
    VALIDATION_ERROR = APIError(
        "Validation failed",
        status.HTTP_422_UNPROCESSABLE_ENTITY,
        "The request data contains validation errors",
    )

    INVALID_INPUT = APIError(
        "Invalid input",
        status.HTTP_400_BAD_REQUEST,
        "The provided input data is invalid",
    )

    MISSING_REQUIRED_FIELD = APIError(
        "Missing required field",
        status.HTTP_400_BAD_REQUEST,
        "One or more required fields are missing",
    )

    # Resource Not Found
    NOT_FOUND = APIError(
        "Resource not found",
        status.HTTP_404_NOT_FOUND,
        "The requested resource does not exist",
    )

    USER_NOT_FOUND = APIError(
        "User not found", status.HTTP_404_NOT_FOUND, "The specified user does not exist"
    )

    DEAL_NOT_FOUND = APIError(
        "Deal not found",
        status.HTTP_404_NOT_FOUND,
        "The specified deal does not exist or you don't have access to it",
    )

    CONVERSATION_NOT_FOUND = APIError(
        "Conversation not found",
        status.HTTP_404_NOT_FOUND,
        "The specified conversation does not exist or you don't have access to it",
    )

    # Conflict
    ALREADY_EXISTS = APIError(
        "Resource already exists",
        status.HTTP_409_CONFLICT,
        "A resource with this identifier already exists",
    )

    CONVERSATION_ALREADY_EXISTS = APIError(
        "Conversation already exists",
        status.HTTP_409_CONFLICT,
        "A conversation already exists for this deal",
    )

    # Business Logic
    INELIGIBLE_STATUS = APIError(
        "Resource not eligible",
        status.HTTP_400_BAD_REQUEST,
        "The resource is not in an eligible state for this operation",
    )

    NO_EMAIL_CONTACT = APIError(
        "No email contact",
        status.HTTP_400_BAD_REQUEST,
        "The deal has no email contact to create a conversation",
    )

    # Rate Limiting & Quotas
    RATE_LIMITED = APIError(
        "Rate limit exceeded",
        status.HTTP_429_TOO_MANY_REQUESTS,
        "You have exceeded the rate limit for this endpoint",
    )

    QUOTA_EXCEEDED = APIError(
        "Quota exceeded",
        status.HTTP_429_TOO_MANY_REQUESTS,
        "You have exceeded your service quota",
    )

    # Service Errors
    EMAIL_SERVICE_ERROR = APIError(
        "Email service error",
        status.HTTP_503_SERVICE_UNAVAILABLE,
        "The email service is temporarily unavailable",
    )

    DATABASE_ERROR = APIError(
        "Database error",
        status.HTTP_503_SERVICE_UNAVAILABLE,
        "A database error occurred while processing your request",
    )

    EXTERNAL_SERVICE_ERROR = APIError(
        "External service error",
        status.HTTP_502_BAD_GATEWAY,
        "An external service is temporarily unavailable",
    )

    # Server Errors
    INTERNAL_ERROR = APIError(
        "Internal server error",
        status.HTTP_500_INTERNAL_SERVER_ERROR,
        "An unexpected error occurred while processing your request",
    )


def handle_api_error(error: Exception, context: str = "") -> HTTPException:
    """
    Convert any exception to a standardized HTTPException.

    Args:
        error: The exception to handle
        context: Additional context for logging (e.g., endpoint name)

    Returns:
        HTTPException with standardized error format
    """
    if isinstance(error, APIError):
        # Log the error with appropriate level
        if error.log_level == "error":
            logger.error(f"{context}: {error.message} - {error.detail}")
        elif error.log_level == "warning":
            logger.warning(f"{context}: {error.message} - {error.detail}")
        elif error.log_level == "info":
            logger.info(f"{context}: {error.message} - {error.detail}")

        return error.to_http_exception()

    elif isinstance(error, HTTPException):
        # Already an HTTPException, just ensure consistent format
        logger.error(f"{context}: HTTP {error.status_code} - {error.detail}")
        return error

    elif isinstance(error, ValueError):
        # Validation errors
        logger.warning(f"{context}: Validation error - {str(error)}")
        return ErrorCodes.VALIDATION_ERROR.to_http_exception()

    elif isinstance(error, ValidationError):
        logger.warning(f"{context}: Pydantic validation - {error!s}")
        return HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail={
                "error": ErrorCodes.VALIDATION_ERROR.message,
                "detail": error.errors(include_url=False),
                "status_code": status.HTTP_422_UNPROCESSABLE_ENTITY,
            },
        )

    elif isinstance(error, RequestValidationError):
        # FastAPI body/query validation (not the same type as pydantic.ValidationError)
        logger.warning(f"{context}: Request validation - {error.errors()}")
        return HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail={
                "error": ErrorCodes.VALIDATION_ERROR.message,
                "detail": error.errors(),
                "status_code": status.HTTP_422_UNPROCESSABLE_ENTITY,
            },
        )

    elif isinstance(error, (PyMongoError, BSONError)):
        logger.error(f"{context}: Database driver error - {type(error).__name__}: {error!s}")
        return HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={
                "error": ErrorCodes.DATABASE_ERROR.message,
                "detail": f"{type(error).__name__}: {error!s}",
                "status_code": status.HTTP_503_SERVICE_UNAVAILABLE,
            },
        )

    elif isinstance(error, (KeyError, AttributeError)):
        error_message = str(error)
        logger.warning(f"{context}: Missing data - {error_message}")

        # Create HTTPException with the actual error message as detail
        return HTTPException(
            status_code=ErrorCodes.MISSING_REQUIRED_FIELD.status_code,
            detail={
                "error": ErrorCodes.MISSING_REQUIRED_FIELD.message,
                "detail": error_message,  # Use the actual error message
                "status_code": ErrorCodes.MISSING_REQUIRED_FIELD.status_code,
            },
        )

    else:
        # Unexpected errors
        logger.error(
            f"{context}: Unexpected error - {type(error).__name__}: {str(error)}"
        )
        return ErrorCodes.INTERNAL_ERROR.to_http_exception()


def create_error_response(
    message: str,
    status_code: int = status.HTTP_500_INTERNAL_SERVER_ERROR,
    detail: Optional[str] = None,
    **kwargs,
) -> Dict[str, Any]:
    """
    Create a standardized error response dictionary.

    Args:
        message: Error message
        status_code: HTTP status code
        detail: Additional error details
        **kwargs: Additional fields to include in response

    Returns:
        Dictionary with standardized error format
    """
    from datetime import datetime, timezone

    response = {
        "error": message,
        "status_code": status_code,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }

    if detail:
        response["detail"] = detail

    response.update(kwargs)
    return response


def raise_http_exception(
    error_code: APIError, detail: Optional[str] = None, **kwargs
) -> NoReturn:
    """
    Raise an HTTPException with standardized format.

    Args:
        error_code: Standardized error code
        detail: Additional error details
        **kwargs: Additional fields to include in response
    """
    response = create_error_response(
        message=error_code.message,
        status_code=error_code.status_code,
        detail=detail if detail is not None else error_code.detail,
        **kwargs,
    )

    raise HTTPException(status_code=error_code.status_code, detail=response)


# Decorator for consistent error handling
def handle_errors(context: str = ""):
    """
    Decorator for consistent error handling in endpoint functions.

    Args:
        context: Context name for logging (e.g., endpoint name)
    """

    def decorator(func):
        import functools

        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            try:
                return await func(*args, **kwargs)
            except Exception as e:
                raise handle_api_error(e, context or func.__name__)

        return wrapper

    return decorator
