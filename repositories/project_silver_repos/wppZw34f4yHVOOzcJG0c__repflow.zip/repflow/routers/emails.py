"""
Email router for sending emails via AWS SES.
Provides endpoints for single emails, bulk emails, and SES management.
"""

from fastapi import APIRouter, HTTPException, status, Depends
from typing import List

from routers.utils import (
    get_current_user,
    require_user_or_service_permission,
    AuthContext,
    is_user_auth,
    get_user_id,
)
from models.email_models import (
    EmailRequest,
    BulkEmailRequest,
    EmailResponse,
    BulkEmailResponse,
    SESQuotaResponse,
    EmailVerificationRequest,
    EmailVerificationResponse,
    VerifiedEmailsResponse,
)
from services.email_service import email_service
from utils.error_handler import handle_errors, raise_http_exception, ErrorCodes
import logging

# Configure logger for this module
logger = logging.getLogger("uvicorn.error")
router = APIRouter(prefix="/emails", tags=["emails"])


@router.post("/send", response_model=EmailResponse)
@handle_errors("Send email")
async def send_email(
    email_request: EmailRequest,
    auth_context: AuthContext = Depends(
        require_user_or_service_permission("emails:send")
    ),
) -> EmailResponse:
    """
    Send a single email via AWS SES.

    Args:
        email_request: Email data including recipients, subject, and body
        auth_context: Authentication context (user or service account)

    Returns:
        EmailResponse with success status and message ID
    """
    # Validate required fields
    if not email_request.to_addresses:
        raise_http_exception(
            ErrorCodes.MISSING_REQUIRED_FIELD,
            "At least one recipient email address is required",
        )

    if not email_request.subject or not email_request.subject.strip():
        raise_http_exception(
            ErrorCodes.MISSING_REQUIRED_FIELD, "Email subject is required"
        )

    if not email_request.body_text and not email_request.body_html:
        raise_http_exception(
            ErrorCodes.MISSING_REQUIRED_FIELD,
            "Either body_text or body_html is required",
        )

    try:
        # Send the email
        result = await email_service.send_email(
            to_addresses=email_request.to_addresses,
            subject=email_request.subject,
            body_text=email_request.body_text,
            body_html=email_request.body_html,
            from_address=email_request.from_address,
            cc_addresses=email_request.cc_addresses,
            bcc_addresses=email_request.bcc_addresses,
            reply_to_addresses=email_request.reply_to_addresses,
            configuration_set_name=email_request.configuration_set_name,
            deal_id=email_request.deal_id,
            user_id=email_request.user_id,
        )

        return EmailResponse(
            success=result["success"],
            message_id=result["message_id"],
            to_addresses=result["to_addresses"],
            subject=result["subject"],
        )

    except ValueError as e:
        logger.warning(f"Email validation error: {e}")
        raise_http_exception(
            ErrorCodes.VALIDATION_ERROR, f"Email validation failed: {str(e)}"
        )
    except Exception as e:
        if isinstance(e, HTTPException):
            raise e
        logger.error(f"Error sending email: {e}")
        raise_http_exception(
            ErrorCodes.EMAIL_SERVICE_ERROR, f"Failed to send email: {str(e)}"
        )

        return EmailResponse(
            success=result["success"],
            message_id=result["message_id"],
            to_addresses=result["to_addresses"],
            subject=result["subject"],
        )




@router.post("/send/bulk", response_model=BulkEmailResponse)
async def send_bulk_emails(
    bulk_request: BulkEmailRequest,
    auth_context: AuthContext = Depends(
        require_user_or_service_permission("emails:send_bulk")
    ),
) -> BulkEmailResponse:
    """
    Send multiple emails in bulk via AWS SES.

    Args:
        bulk_request: Bulk email data with list of emails to send
        auth_context: Authentication context (user or service account)

    Returns:
        BulkEmailResponse with results for each email

    Raises:
        HTTPException: If bulk email operation fails
    """
    try:
        # Log the sender context
        if is_user_auth(auth_context):
            sender_id = get_user_id(auth_context)
            logger.info(
                f"User {sender_id} sending {len(bulk_request.emails)} bulk emails"
            )
        else:
            sender_id = auth_context.service_account.service_name
            logger.info(
                f"Service account {sender_id} sending {len(bulk_request.emails)} bulk emails"
            )

        # Convert EmailRequest objects to dictionaries for the service
        email_dicts = []
        for email_req in bulk_request.emails:
            email_dict = {
                "to_addresses": email_req.to_addresses,
                "subject": email_req.subject,
                "body_text": email_req.body_text,
                "body_html": email_req.body_html,
                "from_address": email_req.from_address,
                "cc_addresses": email_req.cc_addresses,
                "bcc_addresses": email_req.bcc_addresses,
                "reply_to_addresses": email_req.reply_to_addresses,
                "configuration_set_name": email_req.configuration_set_name,
            }
            # Remove None values to avoid issues
            email_dict = {k: v for k, v in email_dict.items() if v is not None}
            email_dicts.append(email_dict)

        # Send bulk emails
        results = await email_service.send_bulk_email(
            emails=email_dicts, default_from_address=bulk_request.default_from_address
        )

        # Convert results to response models
        email_responses = []
        successful_count = 0
        failed_count = 0

        for result in results:
            if result.get("success", False):
                successful_count += 1
                email_responses.append(
                    EmailResponse(
                        success=True,
                        message_id=result["message_id"],
                        to_addresses=result["to_addresses"],
                        subject=result["subject"],
                    )
                )
            else:
                failed_count += 1
                email_responses.append(
                    EmailResponse(
                        success=False,
                        message_id=None,
                        to_addresses=result.get("to_addresses", []),
                        subject="Failed to send",
                        error=result.get("error", "Unknown error"),
                    )
                )

        return BulkEmailResponse(
            total_emails=len(bulk_request.emails),
            successful_emails=successful_count,
            failed_emails=failed_count,
            results=email_responses,
        )

    except Exception as e:
        logger.error(f"Error sending bulk emails: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to send bulk emails: {str(e)}",
        )


@router.get("/quota", response_model=SESQuotaResponse)
async def get_ses_quota(
    auth_context: AuthContext = Depends(
        require_user_or_service_permission("emails:read_quota")
    ),
) -> SESQuotaResponse:
    """
    Get current SES sending quota and rate limits.

    Args:
        auth_context: Authentication context (user or service account)

    Returns:
        SESQuotaResponse with quota information

    Raises:
        HTTPException: If quota retrieval fails
    """
    try:
        quota_info = email_service.get_send_quota()

        return SESQuotaResponse(
            max_24_hour_send=quota_info["max_24_hour_send"],
            max_send_rate=quota_info["max_send_rate"],
            sent_last_24_hours=quota_info["sent_last_24_hours"],
        )

    except Exception as e:
        logger.error(f"Error getting SES quota: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get SES quota: {str(e)}",
        )


@router.post("/verify", response_model=EmailVerificationResponse)
async def verify_email_address(
    verification_request: EmailVerificationRequest,
    auth_context: AuthContext = Depends(
        require_user_or_service_permission("emails:verify")
    ),
) -> EmailVerificationResponse:
    """
    Send verification email for an email address in SES.

    Args:
        verification_request: Email address to verify
        auth_context: Authentication context (user or service account)

    Returns:
        EmailVerificationResponse with verification status

    Raises:
        HTTPException: If verification request fails
    """
    try:
        success = email_service.verify_email_identity(
            verification_request.email_address
        )

        if success:
            message = "Verification email sent successfully"
            logger.info(
                f"Verification email sent to: {verification_request.email_address}"
            )
        else:
            message = "Failed to send verification email"
            logger.warning(
                f"Failed to send verification email to: {verification_request.email_address}"
            )

        return EmailVerificationResponse(
            success=success,
            email_address=verification_request.email_address,
            message=message,
        )

    except Exception as e:
        logger.error(f"Error verifying email address: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to verify email address: {str(e)}",
        )


@router.get("/verified", response_model=VerifiedEmailsResponse)
async def get_verified_emails(
    auth_context: AuthContext = Depends(
        require_user_or_service_permission("emails:read_verified")
    ),
) -> VerifiedEmailsResponse:
    """
    Get list of verified email addresses in SES.

    Args:
        auth_context: Authentication context (user or service account)

    Returns:
        VerifiedEmailsResponse with list of verified emails

    Raises:
        HTTPException: If retrieval fails
    """
    try:
        verified_emails = email_service.list_verified_email_addresses()

        return VerifiedEmailsResponse(
            verified_emails=verified_emails, count=len(verified_emails)
        )

    except Exception as e:
        logger.error(f"Error getting verified emails: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get verified emails: {str(e)}",
        )


# Health check endpoint for email service
@router.get("/health")
async def email_service_health(current_user: str = Depends(get_current_user)) -> dict:
    """
    Check email service health and connectivity.

    Args:
        current_user: Authenticated user

    Returns:
        Health status information
    """
    try:
        # Try to get quota as a health check
        quota_info = email_service.get_send_quota()

        return {
            "status": "healthy",
            "service": "AWS SES",
            "region": email_service.aws_region,
            "quota_check": "passed",
            "max_send_rate": quota_info["max_send_rate"],
        }

    except Exception as e:
        logger.error(f"Email service health check failed: {e}")
        return {
            "status": "unhealthy",
            "service": "AWS SES",
            "region": email_service.aws_region,
            "error": str(e),
        }
