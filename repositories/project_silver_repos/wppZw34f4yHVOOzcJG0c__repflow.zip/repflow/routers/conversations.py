from fastapi import APIRouter, HTTPException, status, Query, Depends
from typing import List, Optional, Dict, Any
from datetime import datetime, timezone
from beanie.odm.fields import PydanticObjectId
from database.models.message import (
    Conversation,
    Message,
    ConversationType,
    ConversationStatus,
    MessageType,
    ConversationSummary,
)
from database.models.deal import Deal
from database.models.lead import LeadQualificationData
from database.models.brand import Brand
from database.models.contact import Contact as CRMContact
from database.models.user import User
from .utils import (
    register_crud_from_model,
    get_current_user,
    require_user_or_service_permission,
    AuthContext,
)
import logging

router = APIRouter(prefix="/conversations", tags=["conversations"])
logger = logging.getLogger("uvicorn.error")


@router.get("/all", response_model=List[Conversation])
async def get_all_conversations_for_user(
    current_user: str = Depends(get_current_user),
    limit: int = Query(
        default=50,
        ge=1,
        le=500,
        description="Maximum number of conversations to return",
    ),
    offset: int = Query(default=0, ge=0, description="Number of conversations to skip"),
    conversation_type: Optional[ConversationType] = Query(
        default=None, description="Filter by conversation type"
    ),
    deal_id: Optional[str] = Query(
        default=None, description="Filter by specific deal ID"
    ),
    conversationStatus: Optional[ConversationStatus] = Query(
        default=None, description="Filter by conversation status"
    ),
    unread_only: bool = Query(
        default=False, description="Return only conversations with unread messages"
    ),
    processing_states: Optional[str] = Query(
        default=None,
        description="Comma-separated list of processing states to filter by",
    ),
    search: Optional[str] = Query(
        default=None, description="Search query for sender name, email, or brand name"
    ),
) -> List[Conversation]:
    """
    Get all conversations for the authenticated user across all their deals.

    Args:
        current_user: The authenticated user from JWT token
        limit: Maximum number of conversations to return
        offset: Number of conversations to skip
        conversation_type: Filter by conversation type (email or ai_chat)
        deal_id: Filter by specific deal ID
        conversationStatus: Filter by conversation status
        unread_only: Return only conversations with unread messages
        processing_states: Comma-separated list of processing states to filter by
        search: Search query for sender name, email, or brand name

    Returns:
        List of conversations for the user

    Raises:
        HTTPException: If user not found or access denied
    """
    try:
        logger.info(f"Getting all conversations for user: {current_user}")
        # Find the user by UUID from token
        user = await User.find_one(User.uuid == current_user)
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
            )

        # Build query filters
        filters: Dict[str, Any] = {"userId": user.uuid}

        if conversation_type:
            filters["conversationType"] = conversation_type

        if deal_id:
            filters["dealId"] = deal_id

        if conversationStatus:
            filters["status"] = conversationStatus

        if unread_only:
            filters["unreadCount"] = {"$gt": 0}

        # Apply search filter if provided
        if search:
            search_regex = {"$regex": search, "$options": "i"}
            filters["$or"] = [
                {"contactName": search_regex},
                {"contactEmail": search_regex},
                {"name": search_regex},
            ]
            # If searching, we typically ignore folder/processing_states filters
            # unless explicitly required otherwise. The user request says "ignore the current folder".
            logger.info(
                f"Search active: '{search}'. Ignoring processing_states filter."
            )
        else:
            # Only apply processing_states filter if NOT searching
            if processing_states:
                # We need to filter based on LeadQualificationData
                # This is a bit complex since it requires a join-like operation or two queries
                # For MongoDB, we'll fetch conversations first (with limit/offset applied later ideally,
                # but here we might need a different approach if the filter is strict)

                # NOTE: The original implementation was inefficient (fetching all then filtering).
                # To keep it safe and strictly follow "ignore current folder" on search,
                # we just skip this block if search is present.
                pass

        logger.info(f"Querying conversations with filters: {filters}")

        # Query conversations with pagination
        # Note: If processing_states is used (and not searching), we handle it below
        if not search and processing_states:
            # Fetch potentially more items to filter in memory - strictly speaking this is inefficient
            # but matches the existing pattern in the file (which I'm replacing part of).
            # However, to be cleaner, I will keep the original logic for processing_states BUT
            # only if search is NOT active.

            conversations = await Conversation.find(
                filters,
                sort=[("lastMessageAt", -1)],  # Sort by most recent first
                limit=500,  # Fetch more to filter in memory
            ).to_list()

            state_list = [s.strip() for s in processing_states.split(",")]
            logger.info(f"Filtering by processing states: {state_list}")

            filtered_conversations = []
            for conv in conversations:
                if conv.threadId:
                    # Find lead by thread_id
                    lead = await LeadQualificationData.find_one(
                        LeadQualificationData.thread_id == conv.threadId
                    )
                    if lead and lead.processing_state.value in state_list:
                        # Add processing_state to conversation metadata
                        if not conv.metadata:
                            conv.metadata = {}
                        conv.metadata["processingState"] = lead.processing_state.value
                        filtered_conversations.append(conv)

            # Apply pagination manually after filtering
            filtered_conversations_page = filtered_conversations[
                offset : offset + limit
            ]

            # Fetch Deals to enrich metadata for the filtered page
            deal_uuids = [c.dealId for c in filtered_conversations_page if c.dealId]
            deals = await Deal.find({"uuid": {"$in": deal_uuids}}).to_list()
            deal_map = {d.uuid: d for d in deals}

            # Batch fetch brands for all deals
            brand_ids = [d.brandId for d in deals if d.brandId]
            brands = await Brand.find({"uuid": {"$in": brand_ids}}).to_list()
            brand_map = {b.uuid: b for b in brands}

            for conv in filtered_conversations_page:
                if conv.dealId and conv.dealId in deal_map:
                    deal = deal_map[conv.dealId]
                    # brandName and tags
                    brand = brand_map.get(deal.brandId) if deal.brandId else None
                    conv.metadata["brandName"] = (
                        brand.name if brand else "Unknown Company"
                    )
                    tags = []
                    if deal.isPriority:
                        tags.append("Priority Deal")
                    if deal.isHighValue:
                        tags.append("High Value")
                    conv.metadata["tags"] = tags

            logger.info(
                f"Found {len(filtered_conversations)} conversations matching processing states"
            )
            return filtered_conversations_page

        else:
            # Standard query with pagination (used for Search OR when no specific processing_states)
            conversations = await Conversation.find(
                filters,
                limit=limit,
                skip=offset,
                sort=[("lastMessageAt", -1)],  # Sort by most recent first
            ).to_list()

            # Enrich with processing state AND Deal info (brand name, tags)
            # Collect all deal IDs first
            deal_uuids = [conv.dealId for conv in conversations if conv.dealId]
            deals = await Deal.find({"uuid": {"$in": deal_uuids}}).to_list()
            deal_map = {d.uuid: d for d in deals}

            # Batch fetch brands for all deals
            brand_ids = [d.brandId for d in deals if d.brandId]
            brands = await Brand.find({"uuid": {"$in": brand_ids}}).to_list()
            brand_map = {b.uuid: b for b in brands}

            for conv in conversations:
                # Add processing state if needed
                if conv.threadId:
                    lead = await LeadQualificationData.find_one(
                        LeadQualificationData.thread_id == conv.threadId
                    )
                    if lead:
                        if not conv.metadata:
                            conv.metadata = {}
                        conv.metadata["processingState"] = lead.processing_state.value

                # Add Deal info (Brand Name, Tags)
                if conv.dealId and conv.dealId in deal_map:
                    deal = deal_map[conv.dealId]
                    if not conv.metadata:
                        conv.metadata = {}

                    # Add Brand Name (fetch from brand collection)
                    brand = brand_map.get(deal.brandId) if deal.brandId else None
                    conv.metadata["brandName"] = (
                        brand.name if brand else "Unknown Company"
                    )

                    # Add Tags
                    tags = []
                    if deal.isPriority:
                        tags.append("Priority Deal")
                    if deal.isHighValue:
                        tags.append("High Value")
                    conv.metadata["tags"] = tags

            logger.info(
                f"Found {len(conversations)} conversations for user: {current_user}"
            )
            return conversations

    except HTTPException:
        raise
    except Exception as e:
        print(f"Error retrieving conversations for user: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while retrieving conversations",
        )


@router.get("/deal/{deal_id}", response_model=List[Conversation])
async def get_conversations_for_deal(
    deal_id: str,
    current_user: str = Depends(get_current_user),
    limit: int = Query(
        default=50,
        ge=1,
        le=500,
        description="Maximum number of conversations to return",
    ),
    offset: int = Query(default=0, ge=0, description="Number of conversations to skip"),
    conversation_type: Optional[ConversationType] = Query(
        default=None, description="Filter by conversation type"
    ),
    conversationStatus: Optional[ConversationStatus] = Query(
        default=None, description="Filter by conversation status"
    ),
    unread_only: bool = Query(
        default=False, description="Return only conversations with unread messages"
    ),
) -> List[Conversation]:
    """
    Get all conversations for a specific deal for the authenticated user.

    Args:
        deal_id: The ID of the deal
        current_user: The authenticated user from JWT token
        limit: Maximum number of conversations to return
        offset: Number of conversations to skip
        conversation_type: Filter by conversation type (email or ai_chat)
        conversationStatus: Filter by conversation status
        unread_only: Return only conversations with unread messages

    Returns:
        List of conversations for the deal

    Raises:
        HTTPException: If deal or user not found, or access denied
    """
    try:
        # Validate user exists
        user = await User.find_one(User.uuid == current_user)
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
            )

        # Validate deal exists and belongs to user
        try:
            deal_object_id = PydanticObjectId(deal_id)
        except Exception:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid deal ID format"
            )

        deal = await Deal.find_one(Deal.id == deal_object_id)
        if not deal:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Deal not found"
            )

        # Build query filters
        filters = {"dealId": deal_object_id, "userId": user.uuid}

        if conversation_type:
            filters["conversationType"] = conversation_type

        if conversationStatus:
            filters["status"] = conversationStatus

        if unread_only:
            filters["unreadCount"] = {"$gt": 0}

        # Query conversations with pagination
        conversations = await Conversation.find(
            filters,
            limit=limit,
            skip=offset,
            sort=[("lastMessageAt", -1)],  # Sort by most recent first
        ).to_list()

        return conversations

    except HTTPException:
        raise
    except Exception as e:
        print(f"Error retrieving conversations for deal: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while retrieving conversations",
        )


@router.get("/{conversation_id}/messages", response_model=List[Message])
async def get_messages_for_conversation(
    conversation_id: str,
    current_user: str = Depends(get_current_user),
    limit: int = Query(
        default=100, ge=1, le=1000, description="Maximum number of messages to return"
    ),
    offset: int = Query(default=0, ge=0, description="Number of messages to skip"),
    message_type: Optional[MessageType] = Query(
        default=None, description="Filter by message type"
    ),
    unread_only: bool = Query(default=False, description="Return only unread messages"),
) -> List[Message]:
    """
    Get all messages for a specific conversation owned by the authenticated user.

    Args:
        conversation_id: The ID of the conversation
        current_user: The authenticated user from JWT token
        limit: Maximum number of messages to return
        offset: Number of messages to skip
        message_type: Filter by message type (email or ai_assistant)
        unread_only: Return only unread messages

    Returns:
        List of messages for the conversation

    Raises:
        HTTPException: If conversation or user not found, or access denied
    """
    try:
        # Validate conversation exists and belongs to user
        if not conversation_id or not isinstance(conversation_id, str):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid conversation ID format",
            )

        conversation = await Conversation.find_one(Conversation.uuid == conversation_id)
        if not conversation:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Conversation not found"
            )

        # Build query filters
        filters = {"conversationId": conversation_id}

        if message_type:
            filters["messageType"] = message_type

        if unread_only:
            filters["readAt"] = None

        logger.info(f"Querying messages with filters: {filters}")
        # Query messages with pagination
        messages = await Message.find(
            filters,
            limit=limit,
            skip=offset,
            sort=[("sentAt", 1)],  # Sort by oldest first for conversation view
        ).to_list()

        return messages

    except HTTPException:
        raise
    except Exception as e:
        print(f"Error retrieving messages for conversation: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while retrieving messages",
        )


@router.get("/thread/{thread_id}", response_model=Optional[Conversation])
async def get_conversation_by_thread_id(
    thread_id: str,
    auth_context: AuthContext = Depends(
        require_user_or_service_permission("conversations:read")
    ),
) -> Optional[Conversation]:
    """
    Get conversation by thread ID.

    Args:
        thread_id: The email thread ID
        auth_context: Authentication context

    Returns:
        Conversation if found, None otherwise
    """
    try:
        conversation = await Conversation.find_one(Conversation.threadId == thread_id)
        return conversation

    except Exception as e:
        logger.error(
            f"Error retrieving conversation by thread_id {thread_id}: {str(e)}"
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while retrieving conversation",
        )


@router.get("/thread/{thread_id}/messages", response_model=List[Message])
async def get_messages_by_thread_id(
    thread_id: str,
    limit: int = Query(
        default=50, ge=1, le=1000, description="Maximum messages to return"
    ),
    auth_context: AuthContext = Depends(
        require_user_or_service_permission("messages:read")
    ),
) -> List[Message]:
    """
    Get all messages for a conversation by thread ID.
    Used by Lambda to fetch conversation history for AI agents.

    Args:
        thread_id: The email thread ID
        limit: Maximum number of messages to return
        auth_context: Authentication context

    Returns:
        List of messages sorted by sentAt (oldest first)
    """
    try:
        # Find conversation by thread_id
        conversation = await Conversation.find_one(Conversation.threadId == thread_id)
        if not conversation:
            return []

        # Get messages for this conversation, sorted by sentAt (oldest first)
        messages = (
            await Message.find({"conversationId": conversation.uuid})
            .sort("sentAt")
            .limit(limit)
            .to_list()
        )

        return messages

    except Exception as e:
        logger.error(f"Error retrieving messages by thread_id {thread_id}: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while retrieving messages",
        )


@router.get("/summary", response_model=ConversationSummary)
async def get_conversation_summary_for_user(
    current_user: str = Depends(get_current_user),
) -> ConversationSummary:
    """
    Get conversation summary for the authenticated user across all their deals.

    Args:
        current_user: The authenticated user from JWT token

    Returns:
        Conversation summary for the user

    Raises:
        HTTPException: If user not found or access denied
    """
    try:
        # Find the user by UUID from token
        user = await User.find_one(User.uuid == current_user)
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
            )

        # Get conversation counts
        total_conversations = await Conversation.find({"userId": user.uuid}).count()
        email_conversations = await Conversation.find(
            {"userId": user.uuid, "conversationType": ConversationType.EMAIL}
        ).count()
        ai_chats = await Conversation.find(
            {"userId": user.uuid, "conversationType": ConversationType.AI_CHAT}
        ).count()
        active_conversations = await Conversation.find(
            {"userId": user.uuid, "status": ConversationStatus.ACTIVE}
        ).count()

        # Get total unread messages across all conversations
        total_unread = await Message.find({"userId": user.uuid, "readAt": None}).count()

        # Get last activity timestamp
        last_conversation = (
            await Conversation.find({"userId": user.uuid})
            .sort([("lastMessageAt", -1)])
            .limit(1)
            .to_list()
        )

        last_activity_at = None
        if last_conversation and last_conversation[0].lastMessageAt:
            last_activity_at = last_conversation[0].lastMessageAt

        summary = ConversationSummary(
            totalConversations=total_conversations,
            emailConversations=email_conversations,
            aiChats=ai_chats,
            activeConversations=active_conversations,
            totalUnreadMessages=total_unread,
            lastActivityAt=last_activity_at,
        )

        return summary

    except HTTPException:
        raise
    except Exception as e:
        print(f"Error retrieving conversation summary for user: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while retrieving conversation summary",
        )


@router.get("/unread-counts", response_model=Dict[str, int])
async def get_unread_counts_by_state(
    current_user: str = Depends(get_current_user),
) -> Dict[str, int]:
    """
    Get unread conversation counts grouped by processing state.

    Args:
        current_user: The authenticated user from JWT token

    Returns:
        Dictionary mapping processing state to count of unread conversations
    """
    try:
        user = await User.find_one(User.uuid == current_user)
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
            )

        # distinct unread conversations
        conversations = await Conversation.find(
            {"userId": user.uuid, "unreadCount": {"$gt": 0}}
        ).to_list()

        counts: Dict[str, int] = {}

        for conv in conversations:
            state = "unknown"
            if conv.threadId:
                lead = await LeadQualificationData.find_one(
                    LeadQualificationData.thread_id == conv.threadId
                )
                if lead:
                    state = lead.processing_state.value

            counts[state] = counts.get(state, 0) + 1

        logger.info(f"Unread counts for user {current_user}: {counts}")
        return counts

    except HTTPException:
        raise
    except Exception as e:
        print(f"Error retrieving unread counts: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while retrieving unread counts",
        )


@router.patch("/{conversation_id}/mark-read")
async def mark_conversation_as_read(
    conversation_id: str, current_user: str = Depends(get_current_user)
) -> Conversation:
    """
    Mark all messages in a conversation as read for the authenticated user.

    Args:
        conversation_id: The ID of the conversation
        current_user: The authenticated user from JWT token

    Returns:
        Updated conversation object

    Raises:
        HTTPException: If conversation or user not found, or access denied
    """
    try:
        # Validate user exists
        user = await User.find_one(User.uuid == current_user)
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
            )

        # Validate conversation exists and belongs to user
        if not conversation_id or not isinstance(conversation_id, str):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid conversation ID format",
            )

        conversation = await Conversation.find_one(
            Conversation.uuid == conversation_id, Conversation.userId == user.uuid
        )
        if not conversation:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Conversation not found"
            )

        # Mark all unread messages in this conversation as read
        await Message.find(
            {
                "conversationId": conversation_id,
                "userId": user.uuid,
                "readAt": None,
            }
        ).update_many(
            {
                "$set": {
                    "readAt": datetime.now(timezone.utc),
                    "updatedAt": datetime.now(timezone.utc),
                }
            }
        )

        # Update conversation unread count
        conversation.unreadCount = 0
        conversation.updatedAt = datetime.now()

        # Save the updated conversation
        updated_conversation = await conversation.save()

        return updated_conversation

    except HTTPException:
        raise
    except Exception as e:
        print(f"Error marking conversation as read: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while marking conversation as read",
        )


@router.post("/for-deal", response_model=Conversation)
async def create_conversation_for_deal(
    deal_id: str = Query(..., description="UUID of the deal"),
    thread_id: Optional[str] = Query(None, description="Email thread ID to link"),
    auth_context: AuthContext = Depends(
        require_user_or_service_permission("conversations:create")
    ),
) -> Conversation:
    """
    Create a conversation for a deal with optional thread_id.
    Used by Lambda when creating deals from qualified leads.

    Args:
        deal_id: UUID of the deal
        thread_id: Optional email thread ID to link
        auth_context: Authentication context

    Returns:
        Created or existing conversation
    """
    try:
        # Find the deal
        deal = await Deal.find_one(Deal.uuid == deal_id)
        if not deal:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Deal {deal_id} not found",
            )

        # Check if conversation already exists for this deal
        existing_conversation = await Conversation.find_one(
            Conversation.dealId == deal.uuid
        )

        if existing_conversation:
            # If thread_id provided but not set on existing conversation, update it
            if thread_id and not existing_conversation.threadId:
                existing_conversation.threadId = thread_id
                existing_conversation.updatedAt = datetime.now(timezone.utc)
                await existing_conversation.save()
                logger.info(
                    f"Updated conversation {existing_conversation.uuid} with threadId {thread_id}"
                )

            return existing_conversation

        # Fetch brand by ID for company name
        company_name = "Unknown Company"
        if deal.brandId:
            brand = await Brand.find_one(Brand.uuid == deal.brandId)
            if brand:
                company_name = brand.name

        # Fetch primary contact info by ID
        primary_contact_email = None
        primary_contact_name = company_name

        if deal.contactId:
            contact = await CRMContact.find_one(CRMContact.uuid == deal.contactId)
            if contact and contact.email and contact.email.strip():
                primary_contact_email = contact.email
                primary_contact_name = contact.name

        # Create new conversation
        conversation = Conversation(
            name=f"{company_name} - {deal.dealType.value}",
            status=ConversationStatus.ACTIVE,
            dealId=deal.uuid,
            userId=deal.userId,
            contactName=primary_contact_name,
            contactEmail=primary_contact_email,
            subject=f"Partnership Discussion - {company_name}",
            threadId=thread_id,  # Set threadId here
            createdAt=datetime.now(timezone.utc),
            updatedAt=datetime.now(timezone.utc),
        )

        await conversation.insert()
        logger.info(
            f"✅ Created conversation {conversation.uuid} for deal {deal.uuid} with threadId {thread_id}"
        )

        return conversation

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating conversation for deal: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while creating conversation",
        )


@router.post("/pre-deal", response_model=Conversation)
async def create_pre_deal_conversation(
    thread_id: str = Query(..., description="Email thread ID"),
    user_id: str = Query(..., description="User UUID"),
    contact_email: str = Query(..., description="Contact email address"),
    contact_name: str = Query(..., description="Contact name"),
    subject: str = Query(..., description="Email subject"),
    auth_context: AuthContext = Depends(
        require_user_or_service_permission("conversations:create")
    ),
) -> Conversation:
    """
    Create a pre-deal conversation for storing emails before a deal is created.
    Used by Lambda when receiving emails that don't have an associated deal yet.

    Args:
        thread_id: Email thread ID
        user_id: User UUID
        contact_email: Contact email address
        contact_name: Contact name
        subject: Email subject
        auth_context: Authentication context

    Returns:
        Created or existing conversation
    """
    try:
        # Check if conversation already exists for this thread
        existing_conversation = await Conversation.find_one(
            Conversation.threadId == thread_id
        )

        if existing_conversation:
            logger.info(
                f"Found existing conversation {existing_conversation.uuid} for thread {thread_id}"
            )
            return existing_conversation

        # Create new pre-deal conversation
        conversation = Conversation(
            name=f"Email from {contact_name}",
            status=ConversationStatus.ACTIVE,
            conversationType=ConversationType.PRE_DEAL,
            dealId=None,  # No deal yet
            userId=user_id,
            contactName=contact_name,
            contactEmail=contact_email,
            subject=subject,
            threadId=thread_id,
            createdAt=datetime.now(timezone.utc),
            updatedAt=datetime.now(timezone.utc),
        )

        await conversation.insert()
        logger.info(
            f"✅ Created pre-deal conversation {conversation.uuid} for thread {thread_id}"
        )

        return conversation

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating pre-deal conversation: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while creating pre-deal conversation",
        )


# Mark conversation as read
@router.post("/{conversation_id}/read", response_model=Conversation)
async def mark_conversation_as_read(
    conversation_id: str, current_user: str = Depends(get_current_user)
) -> Conversation:
    """
    Mark a message as read for the authenticated user.

    Args:
        message_id: The ID of the message to mark as read
        current_user: The authenticated user from JWT token

    Returns:
        Updated message object

    Raises:
        HTTPException: If message or user not found, or access denied
    """
    try:
        # Validate user exists
        user = await User.find_one(User.uuid == current_user)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        # Validate conversation exists and belongs to user
        if not conversation_id or not isinstance(conversation_id, str):
            raise HTTPException(
                status_code=400, detail="Invalid conversation ID format"
            )

        conversation = await Conversation.find_one(
            Conversation.uuid == conversation_id, Conversation.userId == user.uuid
        )

        if not conversation:
            raise HTTPException(status_code=404, detail="Conversation not found")

        # Mark as read
        conversation.unreadCount = 0
        conversation.updatedAt = datetime.now()

        # Mark all messages in the conversation as read
        await Message.find(
            {
                "conversationId": conversation_id,
            }
        ).update_many(
            {
                "$set": {
                    "readAt": datetime.now(),
                    "updatedAt": datetime.now(),
                }
            }
        )

        # Save the updated message
        updated_conversation = await conversation.save()

        return updated_conversation

    except HTTPException:
        raise
    except Exception as e:
        print(f"Error marking conversation as read: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail="Internal server error while marking conversation as read",
        )


@router.patch("/{conversation_id}/link-deal", response_model=Conversation)
async def link_conversation_to_deal(
    conversation_id: str,
    deal_id: str = Query(..., description="UUID of the deal to link"),
    auth_context: AuthContext = Depends(
        require_user_or_service_permission("conversations:update")
    ),
) -> Conversation:
    """
    Link an existing conversation to a deal.
    Used when a deal is created from a qualified lead to associate the pre-deal conversation.

    Args:
        conversation_id: UUID of the conversation to update
        deal_id: UUID of the deal to link
        auth_context: Authentication context

    Returns:
        Updated conversation
    """
    try:
        # Find the conversation
        conversation = await Conversation.find_one(Conversation.uuid == conversation_id)
        if not conversation:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Conversation {conversation_id} not found",
            )

        # Validate deal exists
        deal = await Deal.find_one(Deal.uuid == deal_id)
        if not deal:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Deal {deal_id} not found",
            )

        # Fetch brand name for conversation name
        company_name = "Unknown Company"
        if deal.brandId:
            brand = await Brand.find_one(Brand.uuid == deal.brandId)
            if brand:
                company_name = brand.name

        # Update conversation with deal reference
        conversation.dealId = deal_id
        conversation.conversationType = ConversationType.EMAIL  # Upgrade from PRE_DEAL
        conversation.name = f"{company_name} - {deal.dealType.value}"
        conversation.updatedAt = datetime.now(timezone.utc)

        await conversation.save()
        logger.info(f"✅ Linked conversation {conversation_id} to deal {deal_id}")

        # Also update all messages in this conversation to have the deal_id
        await Message.find({"conversationId": conversation_id}).update_many(
            {
                "$set": {
                    "dealId": deal_id,
                    "updatedAt": datetime.now(timezone.utc),
                }
            }
        )
        logger.info(
            f"✅ Updated messages in conversation {conversation_id} with deal {deal_id}"
        )

        return conversation

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error linking conversation to deal: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while linking conversation to deal",
        )


@router.post("/", response_model=Conversation)
async def create_conversation(
    conversation: Conversation, current_user: str = Depends(get_current_user)
) -> Conversation:
    """
    Create a new conversation for the authenticated user.

    Args:
        conversation: The conversation data
        current_user: The authenticated user from JWT token

    Returns:
        Created conversation object

    Raises:
        HTTPException: If user not found or validation fails
    """
    try:
        # Validate user exists
        user = await User.find_one(User.uuid == current_user)
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
            )

        # Validate deal exists only if dealId is provided (not for pre-deal conversations)
        if conversation.dealId:
            deal = await Deal.find_one(Deal.uuid == conversation.dealId)
            if not deal:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND, detail="Deal not found"
                )
        else:
            # Set conversation type to PRE_DEAL if no dealId
            conversation.conversationType = ConversationType.PRE_DEAL

        # Set user ID and timestamps
        conversation.userId = user.uuid
        conversation.createdAt = datetime.now(timezone.utc)
        conversation.updatedAt = datetime.now(timezone.utc)

        # Save the conversation
        created_conversation = await conversation.save()

        return created_conversation

    except HTTPException:
        raise
    except Exception as e:
        print(f"Error creating conversation: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while creating conversation",
        )


# Common email domains to exclude from domain-based matching
COMMON_EMAIL_DOMAINS = [
    "gmail.com",
    "outlook.com",
    "yahoo.com",
    "hotmail.com",
    "icloud.com",
    "aol.com",
    "protonmail.com",
    "mail.com",
    "zoho.com",
    "yandex.com",
    "gmx.com",
    "live.com",
]


@router.get("/brand/{brand_id}", response_model=List[Conversation])
async def get_conversations_for_brand(
    brand_id: str,
    current_user: str = Depends(get_current_user),
    limit: int = Query(
        default=50,
        ge=1,
        le=500,
        description="Maximum number of conversations to return",
    ),
    offset: int = Query(default=0, ge=0, description="Number of conversations to skip"),
) -> List[Conversation]:
    """
    Get all conversations associated with a brand.

    Matching logic:
    1. Contact email matches any of the brand's linked contacts
    2. Contact email domain matches brand's email_domain (if not a common domain)

    Args:
        brand_id: The UUID of the brand
        current_user: The authenticated user from JWT token
        limit: Maximum number of conversations to return
        offset: Number of conversations to skip

    Returns:
        List of conversations for the brand
    """
    from database.models.brand import Brand
    from database.models.contact import Contact

    try:
        # Validate user exists
        user = await User.find_one(User.uuid == current_user)
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
            )

        # Get the brand
        brand = await Brand.find_one(
            Brand.uuid == brand_id, Brand.user_id == current_user
        )
        if not brand:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Brand not found"
            )

        # Get all contacts linked to this brand
        contacts = await Contact.find(
            Contact.user_id == current_user, {"brand_ids": brand_id}
        ).to_list()

        # Collect unique email addresses from contacts
        contact_emails = set()
        for contact in contacts:
            if contact.email:
                contact_emails.add(contact.email.lower())

        # Build query conditions
        conditions = []

        # Condition 1: Contact email is in linked contacts
        if contact_emails:
            conditions.append({"contactEmail": {"$in": list(contact_emails)}})

        # Condition 2: Contact email domain matches brand's domain
        if (
            brand.email_domain
            and brand.email_domain.lower() not in COMMON_EMAIL_DOMAINS
        ):
            domain_regex = f"@{brand.email_domain.lower()}$"
            conditions.append(
                {"contactEmail": {"$regex": domain_regex, "$options": "i"}}
            )

        if not conditions:
            # No matching criteria - return empty list
            return []

        # Build final query
        query = {"userId": current_user, "$or": conditions}

        logger.info(f"Fetching conversations for brand {brand_id} with query: {query}")

        # Query conversations with pagination
        conversations = await Conversation.find(
            query,
            limit=limit,
            skip=offset,
            sort=[("lastMessageAt", -1)],  # Sort by most recent first
        ).to_list()

        logger.info(f"Found {len(conversations)} conversations for brand {brand_id}")
        return conversations

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error retrieving conversations for brand: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while retrieving conversations",
        )
