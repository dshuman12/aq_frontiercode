"""
Contacts router - CRUD API for contact management in the CRM.
"""

from auth.service_auth import AuthContext
from fastapi import APIRouter, Depends, Query
from typing import Optional, List
from datetime import datetime, timezone
from pydantic import BaseModel, EmailStr, ConfigDict
from pydantic.alias_generators import to_camel
import logging

from .utils import get_current_user, require_user_or_service_permission, is_user_auth, get_user_id
from database.models.contact import Contact
from database.models.brand import Brand
from database.models.deal import Deal
from utils.error_handler import handle_errors, raise_http_exception, ErrorCodes, APIError

router = APIRouter(prefix="/contacts", tags=["contacts"])
logger = logging.getLogger("uvicorn.error")


async def compute_brand_metrics_batch(brand_ids: List[str], user_id: str) -> dict[str, tuple[float, int]]:
    """
    Compute total revenue and deal count for multiple brands in a single query.
    Returns dict mapping brand_id -> (total_revenue, deal_count).
    """
    if not brand_ids:
        return {}

    # Fetch all deals for these brands in one query
    deals = await Deal.find(
        Deal.userId == user_id,
        {"brandId": {"$in": brand_ids}}
    ).to_list()

    # Aggregate by brand_id
    metrics: dict[str, tuple[float, int]] = {bid: (0.0, 0) for bid in brand_ids}
    for deal in deals:
        if deal.brandId and deal.brandId in metrics:
            current_revenue, current_count = metrics[deal.brandId]
            metrics[deal.brandId] = (current_revenue + deal.value, current_count + 1)

    return metrics


# Custom error codes for contacts
class ContactErrorCodes:
    CONTACT_NOT_FOUND = APIError(
        "Contact not found",
        404,
        "The specified contact does not exist or you don't have access to it",
    )
    CONTACT_ALREADY_EXISTS = APIError(
        "Contact already exists",
        409,
        "A contact with this email already exists",
    )


# Request/Response models
class ContactCreate(BaseModel):
    """Request model for creating a contact."""
    name: str
    email: EmailStr
    title: Optional[str] = None
    phone: Optional[str] = None
    is_agency_contact: bool = False
    brand_id: Optional[str] = None  # Optionally link to a brand on creation
    role: Optional[str] = None  # Role at the brand
    is_primary: bool = False  # Whether this is the primary contact for the brand
    notes: Optional[str] = None
    user_id: Optional[str] = None  # Required for service account auth


class ContactUpdate(BaseModel):
    """Request model for updating a contact."""
    name: Optional[str] = None
    email: Optional[EmailStr] = None
    title: Optional[str] = None
    phone: Optional[str] = None
    is_agency_contact: Optional[bool] = None
    notes: Optional[str] = None


class ContactResponse(BaseModel):
    """Response model for a contact."""
    uuid: str
    name: str
    email: str
    title: Optional[str] = None
    phone: Optional[str] = None
    is_agency_contact: bool
    notes: Optional[str] = None
    brands_count: int = 0
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
        from_attributes=True,
    )


class ContactBrandLinkedResponse(BaseModel):
    """Response model for a brand linked to a contact."""
    uuid: str
    name: str
    website: Optional[str] = None
    category: Optional[str] = None
    logo_url: Optional[str] = None
    is_agency: bool
    total_revenue: float
    deal_count: int
    role: Optional[str] = None
    is_primary: bool

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
        from_attributes=True,
    )


class ContactWithBrandsResponse(ContactResponse):
    """Response model for a contact with full brand details."""
    brands: List[ContactBrandLinkedResponse] = []

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
        from_attributes=True,
    )


class ContactsListResponse(BaseModel):
    """Response model for paginated contacts list."""
    contacts: List[ContactResponse]
    total: int
    page: int
    limit: int
    has_more: bool

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
        from_attributes=True,
    )


@router.get("/")
@handle_errors("Get all contacts")
async def get_contacts(
    page: int = Query(1, ge=1, description="Page number"),
    limit: int = Query(20, ge=1, le=100, description="Items per page"),
    search: Optional[str] = Query(None, description="Search by name or email"),
    is_agency_contact: Optional[bool] = Query(None, description="Filter by agency contact"),
    brand_id: Optional[str] = Query(None, description="Filter by brand"),
    current_user: str = Depends(get_current_user),
) -> ContactsListResponse:
    """
    Get all contacts for the current user with pagination, search, and filtering.
    """
    logger.info(f"Getting contacts for user: {current_user}, page={page}, limit={limit}")
    
    # Build query
    query: dict = {"user_id": current_user}
    
    if search:
        query["$or"] = [
            {"name": {"$regex": search, "$options": "i"}},
            {"email": {"$regex": search, "$options": "i"}},
        ]
    
    if is_agency_contact is not None:
        query["is_agency_contact"] = is_agency_contact
    
    if brand_id:
        query["brand_ids"] = brand_id
    
    # Get total count
    total = await Contact.find(query).count()
    
    # Get paginated results
    skip = (page - 1) * limit
    contacts = await Contact.find(query).skip(skip).limit(limit).to_list()
    
    # Build response
    contact_responses = [
        ContactResponse(
            uuid=contact.uuid,
            name=contact.name,
            email=contact.email,
            title=contact.title,
            phone=contact.phone,
            is_agency_contact=contact.is_agency_contact,
            notes=contact.notes,
            brands_count=len(contact.brand_ids),
            created_at=contact.created_at,
            updated_at=contact.updated_at,
        )
        for contact in contacts
    ]
    
    return ContactsListResponse(
        contacts=contact_responses,
        total=total,
        page=page,
        limit=limit,
        has_more=(skip + len(contacts)) < total,
    )


@router.get("/{contact_id}")
@handle_errors("Get contact by ID")
async def get_contact(
    contact_id: str,
    current_user: str = Depends(get_current_user),
) -> ContactWithBrandsResponse:
    """
    Get a specific contact by ID with all linked brands.
    """
    logger.info(f"Getting contact {contact_id} for user: {current_user}")
    
    contact = await Contact.find_one(Contact.uuid == contact_id, Contact.user_id == current_user)
    if not contact:
        raise_http_exception(ContactErrorCodes.CONTACT_NOT_FOUND)

    # Batch compute metrics for all brands linked to this contact
    brand_metrics = await compute_brand_metrics_batch(contact.brand_ids, current_user)

    # Get all brands linked to this contact
    brands_list = []
    for brand_id in contact.brand_ids:
        brand = await Brand.find_one(Brand.uuid == brand_id, Brand.user_id == current_user)
        if brand:
            total_revenue, deal_count = brand_metrics.get(brand_id, (0.0, 0))
            brands_list.append(ContactBrandLinkedResponse(
                uuid=brand.uuid,
                name=brand.name,
                website=brand.website,
                category=brand.category,
                logo_url=brand.logo_url,
                is_agency=brand.is_agency,
                total_revenue=total_revenue,
                deal_count=deal_count,
                role=contact.brand_roles.get(brand_id),
                is_primary=brand_id in contact.primary_for_brands,
            ))

    return ContactWithBrandsResponse(
        uuid=contact.uuid,
        name=contact.name,
        email=contact.email,
        title=contact.title,
        phone=contact.phone,
        is_agency_contact=contact.is_agency_contact,
        notes=contact.notes,
        brands_count=len(brands_list),
        brands=brands_list,
        created_at=contact.created_at,
        updated_at=contact.updated_at,
    )


@router.post("/")
@handle_errors("Create contact")
async def create_contact(
    contact_data: ContactCreate,
    current_user: str = Depends(get_current_user),
) -> ContactResponse:
    """
    Create a new contact.
    """
    logger.info(f"Creating contact '{contact_data.name}' ({contact_data.email}) for user: {current_user}")
    
    # Check for existing contact with same email
    existing = await Contact.find_one(
        Contact.user_id == current_user,
        Contact.email == str(contact_data.email)
    )
    if existing:
        raise_http_exception(ContactErrorCodes.CONTACT_ALREADY_EXISTS)
    
    # Prepare brand linking
    brand_ids: List[str] = []
    brand_roles: dict = {}
    primary_for_brands: List[str] = []
    brand: Optional[Brand] = None
    
    if contact_data.brand_id:
        # Verify brand exists
        brand = await Brand.find_one(
            Brand.uuid == contact_data.brand_id,
            Brand.user_id == current_user
        )
        if not brand:
            raise_http_exception(ErrorCodes.NOT_FOUND, "Brand not found")
        
        brand_ids.append(contact_data.brand_id)
        if contact_data.role:
            brand_roles[contact_data.brand_id] = contact_data.role
        if contact_data.is_primary:
            primary_for_brands.append(contact_data.brand_id)
    
    # Infer agency contact from email domain
    is_agency_contact = contact_data.is_agency_contact
    if not is_agency_contact and brand:
        # Check if the linked brand is an agency
        if brand.is_agency:
            is_agency_contact = True
    
    # Create contact
    contact = Contact(
        name=contact_data.name,
        email=str(contact_data.email),
        title=contact_data.title,
        phone=contact_data.phone,
        is_agency_contact=is_agency_contact,
        notes=contact_data.notes,
        user_id=current_user,
        brand_ids=brand_ids,
        brand_roles=brand_roles,
        primary_for_brands=primary_for_brands,
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    
    await contact.insert()
    logger.info(f"✅ Created contact {contact.uuid} for user: {current_user}")
    
    return ContactResponse(
        uuid=contact.uuid,
        name=contact.name,
        email=contact.email,
        title=contact.title,
        phone=contact.phone,
        is_agency_contact=contact.is_agency_contact,
        notes=contact.notes,
        brands_count=len(contact.brand_ids),
        created_at=contact.created_at,
        updated_at=contact.updated_at,
    )


@router.post("/find-or-create")
@handle_errors("Find or create contact")
async def find_or_create_contact(
    contact_data: ContactCreate,
    auth_context: AuthContext = Depends(
        require_user_or_service_permission("contacts:create")
    ),
) -> ContactResponse:
    """
    Find existing contact by email or create a new one.

    This endpoint is idempotent - calling it multiple times with the same email
    will return the same contact. Useful for automation workflows.

    For service account auth, user_id must be provided in the request body.
    """
    # Handle different auth contexts
    if is_user_auth(auth_context):
        current_user = get_user_id(auth_context)
    else:
        # Service account - must provide user_id in request
        if not contact_data.user_id:
            raise_http_exception(
                ErrorCodes.MISSING_REQUIRED_FIELD,
                "Service accounts must specify user_id when creating contacts",
            )
        current_user = contact_data.user_id

    logger.info(f"Find-or-create contact '{contact_data.name}' ({contact_data.email}) for user: {current_user}")

    # Check for existing contact with same email
    existing = await Contact.find_one(
        Contact.user_id == current_user,
        Contact.email == str(contact_data.email)
    )

    if existing:
        logger.info(f"Found existing contact {existing.uuid} for email {contact_data.email}")
        return ContactResponse(
            uuid=existing.uuid,
            name=existing.name,
            email=existing.email,
            title=existing.title,
            phone=existing.phone,
            is_agency_contact=existing.is_agency_contact,
            notes=existing.notes,
            brands_count=len(existing.brand_ids),
            created_at=existing.created_at,
            updated_at=existing.updated_at,
        )

    # Prepare brand linking
    brand_ids: List[str] = []
    brand_roles: dict = {}
    primary_for_brands: List[str] = []
    brand: Optional[Brand] = None

    if contact_data.brand_id:
        # Verify brand exists
        brand = await Brand.find_one(
            Brand.uuid == contact_data.brand_id,
            Brand.user_id == current_user
        )
        if not brand:
            raise_http_exception(ErrorCodes.NOT_FOUND, "Brand not found")

        brand_ids.append(contact_data.brand_id)
        if contact_data.role:
            brand_roles[contact_data.brand_id] = contact_data.role
        if contact_data.is_primary:
            primary_for_brands.append(contact_data.brand_id)

    # Infer agency contact from email domain
    is_agency_contact = contact_data.is_agency_contact
    if not is_agency_contact and brand:
        # Check if the linked brand is an agency
        if brand.is_agency:
            is_agency_contact = True

    # Create contact
    contact = Contact(
        name=contact_data.name,
        email=str(contact_data.email),
        title=contact_data.title,
        phone=contact_data.phone,
        is_agency_contact=is_agency_contact,
        notes=contact_data.notes,
        user_id=current_user,
        brand_ids=brand_ids,
        brand_roles=brand_roles,
        primary_for_brands=primary_for_brands,
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )

    await contact.insert()
    logger.info(f"✅ Created new contact {contact.uuid} for user: {current_user}")

    return ContactResponse(
        uuid=contact.uuid,
        name=contact.name,
        email=contact.email,
        title=contact.title,
        phone=contact.phone,
        is_agency_contact=contact.is_agency_contact,
        notes=contact.notes,
        brands_count=len(contact.brand_ids),
        created_at=contact.created_at,
        updated_at=contact.updated_at,
    )


@router.put("/{contact_id}")
@handle_errors("Update contact")
async def update_contact(
    contact_id: str,
    contact_data: ContactUpdate,
    current_user: str = Depends(get_current_user),
) -> ContactResponse:
    """
    Update an existing contact.
    """
    logger.info(f"Updating contact {contact_id} for user: {current_user}")
    
    contact = await Contact.find_one(Contact.uuid == contact_id, Contact.user_id == current_user)
    if not contact:
        raise_http_exception(ContactErrorCodes.CONTACT_NOT_FOUND)
    
    # Check for email conflict if email is being updated
    if contact_data.email and str(contact_data.email) != contact.email:
        existing = await Contact.find_one(
            Contact.user_id == current_user,
            Contact.email == str(contact_data.email)
        )
        if existing:
            raise_http_exception(ContactErrorCodes.CONTACT_ALREADY_EXISTS)
    
    # Update fields
    update_data = contact_data.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        if field == "email" and value is not None:
            value = str(value)
        setattr(contact, field, value)
    
    contact.updated_at = datetime.now(timezone.utc)
    await contact.save()
    
    logger.info(f"✅ Updated contact {contact_id} for user: {current_user}")
    
    return ContactResponse(
        uuid=contact.uuid,
        name=contact.name,
        email=contact.email,
        title=contact.title,
        phone=contact.phone,
        is_agency_contact=contact.is_agency_contact,
        notes=contact.notes,
        brands_count=len(contact.brand_ids),
        created_at=contact.created_at,
        updated_at=contact.updated_at,
    )


@router.delete("/{contact_id}")
@handle_errors("Delete contact")
async def delete_contact(
    contact_id: str,
    current_user: str = Depends(get_current_user),
) -> dict:
    """
    Delete a contact.
    """
    logger.info(f"Deleting contact {contact_id} for user: {current_user}")
    
    contact = await Contact.find_one(Contact.uuid == contact_id, Contact.user_id == current_user)
    if not contact:
        raise_http_exception(ContactErrorCodes.CONTACT_NOT_FOUND)
    
    # Delete the contact
    await contact.delete()
    
    logger.info(f"✅ Deleted contact {contact_id}")
    return {
        "success": True,
        "message": f"Contact {contact_id} deleted successfully",
    }


@router.get("/{contact_id}/brands")
@handle_errors("Get contact brands")
async def get_contact_brands(
    contact_id: str,
    current_user: str = Depends(get_current_user),
) -> List[ContactBrandLinkedResponse]:
    """
    Get all brands linked to a specific contact.
    """
    logger.info(f"Getting brands for contact {contact_id}, user: {current_user}")
    
    contact = await Contact.find_one(Contact.uuid == contact_id, Contact.user_id == current_user)
    if not contact:
        raise_http_exception(ContactErrorCodes.CONTACT_NOT_FOUND)

    # Batch compute metrics for all brands linked to this contact
    brand_metrics = await compute_brand_metrics_batch(contact.brand_ids, current_user)

    # Get brands
    brands_list = []
    for brand_id in contact.brand_ids:
        brand = await Brand.find_one(Brand.uuid == brand_id, Brand.user_id == current_user)
        if brand:
            total_revenue, deal_count = brand_metrics.get(brand_id, (0.0, 0))
            brands_list.append(ContactBrandLinkedResponse(
                uuid=brand.uuid,
                name=brand.name,
                website=brand.website,
                category=brand.category,
                logo_url=brand.logo_url,
                is_agency=brand.is_agency,
                total_revenue=total_revenue,
                deal_count=deal_count,
                role=contact.brand_roles.get(brand_id),
                is_primary=brand_id in contact.primary_for_brands,
            ))

    return brands_list
