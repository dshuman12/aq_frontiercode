from fastapi import APIRouter, HTTPException, status, Depends, Query
from typing import List, Optional
from datetime import datetime, timezone

from database.models.service_account import (
    ServiceAccount, 
    CreateServiceAccountRequest, 
    ServiceAccountResponse,
    CreateServiceAccountResponse,
    ServiceAccountStatus,
    LAMBDA_PERMISSIONS,
    ALL_PERMISSIONS
)
from auth.service_auth import (
    generate_api_key, 
    hash_api_key, 
    require_service_permission,
    ServiceAccountCredentials
)
from routers.utils import get_current_user
import logging

router = APIRouter(prefix="/service-accounts", tags=["service-accounts"])
logger = logging.getLogger('uvicorn.error')


@router.post("/", response_model=CreateServiceAccountResponse)
async def create_service_account(
    request: CreateServiceAccountRequest,
    current_user: str = Depends(get_current_user)
) -> CreateServiceAccountResponse:
    """Create a new service account. Requires admin user authentication."""
    try:
        # Check if service name already exists
        existing = await ServiceAccount.find_one(
            ServiceAccount.service_name == request.service_name
        )
        if existing:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=f"Service account with name '{request.service_name}' already exists"
            )
        
        # Generate API key
        api_key = generate_api_key()
        api_key_hash = hash_api_key(api_key)
        
        # Create service account
        service_account = ServiceAccount(
            service_name=request.service_name,
            api_key_hash=api_key_hash,
            permissions=request.permissions,
            expires_at=request.expires_at,
            created_by=current_user,
            description=request.description
        )
        
        # Save to database
        saved_account = await service_account.insert()
        
        logger.info(f"Created service account '{request.service_name}' by user {current_user}")
        
        # Return response with API key (only time it's exposed)
        return CreateServiceAccountResponse(
            uuid=saved_account.uuid,
            service_name=saved_account.service_name,
            permissions=saved_account.permissions,
            status=saved_account.status,
            expires_at=saved_account.expires_at,
            created_at=saved_account.created_at,
            last_used_at=saved_account.last_used_at,
            created_by=saved_account.created_by,
            description=saved_account.description,
            api_key=api_key  # Only returned during creation
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating service account: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while creating service account"
        )


@router.get("/", response_model=List[ServiceAccountResponse])
async def list_service_accounts(
    current_user: str = Depends(get_current_user),
    status_filter: Optional[ServiceAccountStatus] = Query(default=None, description="Filter by status"),
    limit: int = Query(default=100, ge=1, le=1000, description="Maximum number of accounts to return"),
    offset: int = Query(default=0, ge=0, description="Number of accounts to skip")
) -> List[ServiceAccountResponse]:
    """List all service accounts. Requires admin user authentication."""
    try:
        # Build query filters
        filters = {}
        if status_filter:
            filters["status"] = status_filter
        
        # Query service accounts with pagination
        accounts = await ServiceAccount.find(
            filters,
            limit=limit,
            skip=offset,
            sort=[("created_at", -1)]
        ).to_list()
        
        # Convert to response format
        return [
            ServiceAccountResponse(
                uuid=account.uuid,
                service_name=account.service_name,
                permissions=account.permissions,
                status=account.status,
                expires_at=account.expires_at,
                created_at=account.created_at,
                last_used_at=account.last_used_at,
                created_by=account.created_by,
                description=account.description
            )
            for account in accounts
        ]
        
    except Exception as e:
        logger.error(f"Error listing service accounts: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while listing service accounts"
        )


@router.get("/{account_uuid}", response_model=ServiceAccountResponse)
async def get_service_account(
    account_uuid: str,
    current_user: str = Depends(get_current_user)
) -> ServiceAccountResponse:
    """Get a specific service account by UUID. Requires admin user authentication."""
    try:
        account = await ServiceAccount.find_one(ServiceAccount.uuid == account_uuid)
        if not account:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Service account not found"
            )
        
        return ServiceAccountResponse(
            uuid=account.uuid,
            service_name=account.service_name,
            permissions=account.permissions,
            status=account.status,
            expires_at=account.expires_at,
            created_at=account.created_at,
            last_used_at=account.last_used_at,
            created_by=account.created_by,
            description=account.description
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting service account: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while getting service account"
        )


@router.put("/{account_uuid}/status", response_model=ServiceAccountResponse)
async def update_service_account_status(
    account_uuid: str,
    new_status: ServiceAccountStatus,
    current_user: str = Depends(get_current_user)
) -> ServiceAccountResponse:
    """Update service account status. Requires admin user authentication."""
    try:
        account = await ServiceAccount.find_one(ServiceAccount.uuid == account_uuid)
        if not account:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Service account not found"
            )
        
        old_status = account.status
        account.status = new_status
        await account.save()
        
        logger.info(f"Updated service account '{account.service_name}' status from {old_status} to {new_status} by user {current_user}")
        
        return ServiceAccountResponse(
            uuid=account.uuid,
            service_name=account.service_name,
            permissions=account.permissions,
            status=account.status,
            expires_at=account.expires_at,
            created_at=account.created_at,
            last_used_at=account.last_used_at,
            created_by=account.created_by,
            description=account.description
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating service account status: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while updating service account"
        )


@router.post("/{account_uuid}/rotate-key", response_model=CreateServiceAccountResponse)
async def rotate_service_account_key(
    account_uuid: str,
    current_user: str = Depends(get_current_user)
) -> CreateServiceAccountResponse:
    """Rotate the API key for a service account. Requires admin user authentication."""
    try:
        account = await ServiceAccount.find_one(ServiceAccount.uuid == account_uuid)
        if not account:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Service account not found"
            )
        
        # Generate new API key
        new_api_key = generate_api_key()
        new_api_key_hash = hash_api_key(new_api_key)
        
        # Update account
        account.api_key_hash = new_api_key_hash
        await account.save()
        
        logger.info(f"Rotated API key for service account '{account.service_name}' by user {current_user}")
        
        # Return response with new API key
        return CreateServiceAccountResponse(
            uuid=account.uuid,
            service_name=account.service_name,
            permissions=account.permissions,
            status=account.status,
            expires_at=account.expires_at,
            created_at=account.created_at,
            last_used_at=account.last_used_at,
            created_by=account.created_by,
            description=account.description,
            api_key=new_api_key  # New API key
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error rotating service account key: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while rotating service account key"
        )


@router.delete("/{account_uuid}")
async def delete_service_account(
    account_uuid: str,
    current_user: str = Depends(get_current_user)
) -> dict:
    """Delete a service account. Requires admin user authentication."""
    try:
        account = await ServiceAccount.find_one(ServiceAccount.uuid == account_uuid)
        if not account:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Service account not found"
            )
        
        service_name = account.service_name
        await account.delete()
        
        logger.info(f"Deleted service account '{service_name}' by user {current_user}")
        
        return {"message": f"Service account '{service_name}' deleted successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting service account: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while deleting service account"
        )


# Utility endpoints

@router.get("/permissions/lambda")
async def get_lambda_permissions(
    current_user: str = Depends(get_current_user)
) -> dict:
    """Get the standard set of Lambda permissions."""
    return {
        "permissions": LAMBDA_PERMISSIONS,
        "description": "Standard permissions for Lambda email automation service"
    }


@router.get("/permissions/all")
async def get_all_permissions(
    current_user: str = Depends(get_current_user)
) -> dict:
    """Get all available permissions."""
    return {
        "permissions": ALL_PERMISSIONS,
        "description": "All available service account permissions"
    }


# Service account self-introspection (for service accounts to check their own status)

@router.get("/me", response_model=ServiceAccountResponse)
async def get_my_service_account(
    service_creds: ServiceAccountCredentials = Depends(require_service_permission("service_accounts:read"))
) -> ServiceAccountResponse:
    """Get information about the current service account (self-introspection)."""
    account = service_creds.service_account
    
    return ServiceAccountResponse(
        uuid=account.uuid,
        service_name=account.service_name,
        permissions=account.permissions,
        status=account.status,
        expires_at=account.expires_at,
        created_at=account.created_at,
        last_used_at=account.last_used_at,
        created_by=account.created_by,
        description=account.description
    )
