from fastapi import APIRouter, HTTPException, status, Query, Depends
from typing import List, Optional
from datetime import datetime, timezone
from database.models.lead import (
    LeadQualificationData,
    LeadStatus,
    ProcessedEmail,
    BlacklistedEmail,
)
from database.models.user import User
from .utils import (
    get_current_user,
    require_user_or_service_permission,
    AuthContext,
    is_user_auth,
    get_user_id,
)
import logging

router = APIRouter(prefix="/leads", tags=["leads"])
logger = logging.getLogger("uvicorn.error")


# Lead qualification endpoints
@router.get("/")
async def get_all_leads(
    current_user: str = Depends(get_current_user),
    limit: int = Query(
        default=100, ge=1, le=1000, description="Maximum number of leads to return"
    ),
    offset: int = Query(default=0, ge=0, description="Number of leads to skip"),
    status: Optional[LeadStatus] = Query(
        default=None, description="Filter by lead status"
    ),
    email: Optional[str] = Query(default=None, description="Filter by email address"),
) -> List[LeadQualificationData]:
    """Get all leads for the authenticated user."""
    try:
        # Build query filters
        filters = {}

        if status:
            filters["status"] = status

        if email:
            filters["email"] = email

        # Query leads with pagination
        leads = await LeadQualificationData.find(
            filters,
            limit=limit,
            skip=offset,
            sort=[("created_at", -1)],  # Sort by most recent first
        ).to_list()

        return leads

    except Exception as e:
        logger.error(f"Error retrieving leads: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while retrieving leads",
        )


@router.get("/thread/{thread_id}")
async def get_lead_by_thread_id(
    thread_id: str,
    auth_context: AuthContext = Depends(
        require_user_or_service_permission("leads:read")
    ),
) -> Optional[LeadQualificationData]:
    """Get lead by thread ID."""
    try:
        lead = await LeadQualificationData.find_one({"thread_id": thread_id})
        return lead

    except Exception as e:
        logger.error(f"Error retrieving lead by thread_id {thread_id}: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while retrieving lead",
        )


@router.get("/{lead_uuid}")
async def get_lead_by_uuid(
    lead_uuid: str, current_user: str = Depends(get_current_user)
) -> Optional[LeadQualificationData]:
    """Get lead by UUID."""
    try:
        lead = await LeadQualificationData.find_one({"uuid": lead_uuid})
        return lead

    except Exception as e:
        logger.error(f"Error retrieving lead {lead_uuid}: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while retrieving lead",
        )


@router.put("/{lead_uuid}")
async def update_lead(
    lead_uuid: str,
    lead_data: LeadQualificationData,
    auth_context: AuthContext = Depends(
        require_user_or_service_permission("leads:update")
    ),
) -> LeadQualificationData:
    """Update an existing lead."""
    try:
        lead = await LeadQualificationData.find_one({"uuid": lead_uuid})
        if not lead:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Lead not found"
            )

        # Update fields
        update_dict = lead_data.model_dump(exclude={"id", "_id", "uuid"})
        await lead.update({"$set": update_dict})
        
        # Refresh lead
        lead = await LeadQualificationData.find_one({"uuid": lead_uuid})
        return lead

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating lead {lead_uuid}: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while updating lead",
        )


@router.post("/")
async def create_lead(
    lead: LeadQualificationData,
    auth_context: AuthContext = Depends(
        require_user_or_service_permission("leads:create")
    ),
) -> LeadQualificationData:
    """Create a new lead."""
    try:
        # Set timestamps
        now = datetime.now(timezone.utc)
        lead.created_at = now
        lead.updated_at = now

        # Insert the lead
        created_lead = await lead.insert()
        logger.info(f"Created lead with UUID: {created_lead.uuid}")

        return created_lead

    except Exception as e:
        logger.error(f"Error creating lead: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while creating lead",
        )


@router.patch("/{lead_uuid}/status")
async def update_lead_status(
    lead_uuid: str,
    new_status: LeadStatus,
    current_user: str = Depends(get_current_user),
) -> LeadQualificationData:
    """Update lead status."""
    try:
        # Get existing lead
        lead = await LeadQualificationData.find_one({"uuid": lead_uuid})
        if not lead:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Lead not found"
            )

        # Update status
        lead.status = new_status
        lead.updated_at = datetime.now(timezone.utc)

        # Save the lead
        await lead.save()
        logger.info(f"Updated lead {lead_uuid} status to {new_status}")

        return lead

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating lead status {lead_uuid}: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while updating lead status",
        )


@router.patch("/thread/{thread_id}/qualify")
async def mark_lead_qualified(
    thread_id: str,
    auth_context: AuthContext = Depends(
        require_user_or_service_permission("leads:update")
    ),
) -> Optional[LeadQualificationData]:
    """Mark a lead as qualified by thread ID."""
    try:
        lead = await LeadQualificationData.find_one({"thread_id": thread_id})
        if not lead:
            return None

        lead.status = LeadStatus.QUALIFIED
        lead.updated_at = datetime.now(timezone.utc)
        await lead.save()

        logger.info(f"Marked lead {lead.uuid} as qualified")
        return lead

    except Exception as e:
        logger.error(f"Error marking lead qualified for thread {thread_id}: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while marking lead qualified",
        )


# Processed email endpoints
@router.get("/processed-emails/")
async def get_processed_emails(
    current_user: str = Depends(get_current_user),
    limit: int = Query(
        default=100,
        ge=1,
        le=1000,
        description="Maximum number of processed emails to return",
    ),
    offset: int = Query(
        default=0, ge=0, description="Number of processed emails to skip"
    ),
) -> List[ProcessedEmail]:
    """Get all processed emails."""
    try:
        processed_emails = await ProcessedEmail.find(
            {}, limit=limit, skip=offset, sort=[("processed_at", -1)]
        ).to_list()

        return processed_emails

    except Exception as e:
        logger.error(f"Error retrieving processed emails: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while retrieving processed emails",
        )


@router.get("/processed-emails/{message_id}")
async def check_email_processed(
    message_id: str,
    auth_context: AuthContext = Depends(
        require_user_or_service_permission("processed_emails:read")
    ),
) -> bool:
    """Check if an email was already processed."""
    try:
        processed = await ProcessedEmail.find_one({"message_id": message_id})
        return processed is not None

    except Exception as e:
        logger.error(f"Error checking processed email {message_id}: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while checking processed email",
        )


@router.post("/processed-emails/")
async def mark_email_processed(
    message_id: str,
    thread_id: str,
    auth_context: AuthContext = Depends(
        require_user_or_service_permission("processed_emails:create")
    ),
) -> ProcessedEmail:
    """Mark an email as processed."""
    try:
        processed_email = ProcessedEmail(
            message_id=message_id,
            thread_id=thread_id,
            processed_at=datetime.now(timezone.utc),
        )

        await processed_email.insert()
        logger.info(f"Marked email {message_id} as processed")

        return processed_email

    except Exception as e:
        logger.error(f"Error marking email processed {message_id}: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while marking email processed",
        )


# Blacklist endpoints
@router.get("/blacklist/")
async def get_blacklisted_emails(
    current_user: str = Depends(get_current_user),
    limit: int = Query(
        default=100,
        ge=1,
        le=1000,
        description="Maximum number of blacklisted emails to return",
    ),
    offset: int = Query(
        default=0, ge=0, description="Number of blacklisted emails to skip"
    ),
) -> List[BlacklistedEmail]:
    """Get all blacklisted emails."""
    try:
        blacklisted = await BlacklistedEmail.find(
            {}, limit=limit, skip=offset, sort=[("created_at", -1)]
        ).to_list()

        return blacklisted

    except Exception as e:
        logger.error(f"Error retrieving blacklisted emails: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while retrieving blacklisted emails",
        )


@router.get("/blacklist/{email}")
async def check_email_blacklisted(
    email: str,
    auth_context: AuthContext = Depends(
        require_user_or_service_permission("blacklist:read")
    ),
) -> bool:
    """Check if an email address is blacklisted."""
    try:
        blacklisted = await BlacklistedEmail.find_one({"email": email.lower()})
        return blacklisted is not None

    except Exception as e:
        logger.error(f"Error checking blacklisted email {email}: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while checking blacklisted email",
        )


@router.post("/blacklist/")
async def add_email_to_blacklist(
    email: str,
    reason: Optional[str] = None,
    current_user: str = Depends(get_current_user),
) -> BlacklistedEmail:
    """Add an email address to the blacklist."""
    try:
        blacklisted_email = BlacklistedEmail(
            email=email.lower(), reason=reason, created_at=datetime.now(timezone.utc)
        )

        await blacklisted_email.insert()
        logger.info(f"Added email {email} to blacklist")

        return blacklisted_email

    except Exception as e:
        logger.error(f"Error adding email to blacklist {email}: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while adding email to blacklist",
        )


@router.delete("/blacklist/{email}")
async def remove_email_from_blacklist(
    email: str, current_user: str = Depends(get_current_user)
) -> bool:
    """Remove an email address from the blacklist."""
    try:
        blacklisted = await BlacklistedEmail.find_one({"email": email.lower()})
        if not blacklisted:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Email not found in blacklist",
            )

        await blacklisted.delete()
        logger.info(f"Removed email {email} from blacklist")

        return True

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error removing email from blacklist {email}: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while removing email from blacklist",
        )
