"""HTTP shim to exercise the production FSM path without SES/S3."""

from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Annotated

# Load .env / .env.local from project root so API_AUTH_TOKEN is set when create_api_client() runs
_project_root = Path(__file__).resolve().parent.parent
try:
    from dotenv import load_dotenv
    load_dotenv(_project_root / ".env")
    load_dotenv(_project_root / ".env.local")
except ImportError:
    pass

from fastapi import APIRouter, Depends, HTTPException
from fastapi.encoders import jsonable_encoder
from pydantic import BaseModel, Field

from routers.utils import AuthContext, require_user_or_service_permission
from utils.error_handler import handle_errors, raise_http_exception, ErrorCodes

# Load the Lambda code directly so we reuse the production FSM and helpers
import sys

lambda_path = Path(__file__).resolve().parent.parent / "lambda_handler"
if str(lambda_path) not in sys.path:
    sys.path.append(str(lambda_path))

from lambda_function import (  # type: ignore  # imported via sys.path modification
    EmailEvent,
    create_api_client,
    generate_thread_id,
    process_email_event,
    convert_lead_to_api_format,
)

router = APIRouter(prefix="/fsm", tags=["fsm"])


class PreferencesOverride(BaseModel):
    """Optional overrides for creator preferences during simulation."""

    absoluteMinimumRate: Optional[float] = Field(
        default=None, description="Minimum acceptable rate in USD"
    )
    autoRejectCategories: Optional[List[str]] = Field(
        default=None, description="Categories to auto-reject"
    )
    partnershipTypes: Optional[Dict[str, bool]] = Field(
        default=None,
        description="Partnership types accepted (flatRate, affiliate, performanceHybrid, custom)",
    )


class SimulateEmailRequest(BaseModel):
    # Primary fields (used internally) - all optional to allow custom validation
    subject: Optional[str] = None
    from_email: Annotated[Optional[str], Field(alias="from")] = None
    to_email: Annotated[Optional[str], Field(alias="to")] = None
    content: Annotated[Optional[str], Field(alias="body")] = None
    thread_id: Optional[str] = None
    message_id: Optional[str] = None

    # Optional preferences override for demo simulation
    preferences_override: Optional[PreferencesOverride] = Field(
        default=None,
        description="Override creator preferences for this simulation",
    )

    model_config = {"populate_by_name": True}

    def validate_and_normalize(self) -> "SimulateEmailRequest":
        """Normalize field names and validate required fields."""
        # Collect all missing required fields
        missing_fields = []

        if not self.from_email:
            missing_fields.append("from_email")
        if not self.to_email:
            missing_fields.append("to_email")
        if not self.content:
            missing_fields.append("content")
        if not self.subject:
            missing_fields.append("subject")

        if missing_fields:
            if len(missing_fields) == 1:
                raise ValueError(f"{missing_fields[0]} is required")
            else:
                raise ValueError(f"{', '.join(missing_fields)} are required")

        return self


def _stringify(value: Any) -> Any:
    return value.value if hasattr(value, "value") else value


def _serialize_state_history(state_history: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    serialized: List[Dict[str, Any]] = []
    for entry in state_history:
        serialized.append(
            {
                "from": _stringify(entry.get("from")),
                "to": _stringify(entry.get("to")),
                "trigger": _stringify(entry.get("trigger")),
                "event": _stringify(entry.get("event")),
                "timestamp": entry.get("timestamp"),
                "metadata": entry.get("metadata"),
            }
        )
    return serialized


def _serialize_lead(lead_obj: Any) -> Optional[Dict[str, Any]]:
    """Normalize lead for transport to the demo UI."""
    if lead_obj is None:
        return None

    lead_dict = jsonable_encoder(lead_obj)
    try:
        # Ensure datetimes are stringified and nested metadata is safe for transport
        formatted = convert_lead_to_api_format(lead_obj.model_dump())
        lead_dict.update({k: v for k, v in formatted.items() if v is not None})
    except Exception:
        # Fallback to jsonable_encoder output only
        pass
    return lead_dict


def _build_thread_snapshot(
    thread_id: str,
    message_id: str,
    fsm_result: Any,
    conversation_history: str,
    state_history: List[Dict[str, Any]],
    lead_obj: Any,
    reply_message: Optional[Dict[str, Any]],
) -> Dict[str, Any]:
    lead_state = _stringify(getattr(lead_obj, "processing_state", None))
    fsm_payload = (
        {
            "success": getattr(fsm_result, "success", None),
            "new_state": _stringify(getattr(fsm_result, "new_state", None)),
            "trigger": _stringify(getattr(fsm_result, "trigger", None)),
            "response_to_send": getattr(fsm_result, "response_to_send", None),
            "should_send_email": getattr(fsm_result, "should_send_email", None),
            "should_route_to_creator": getattr(
                fsm_result, "should_route_to_creator", None
            ),
            "metadata": getattr(fsm_result, "metadata", None),
            "error": getattr(fsm_result, "error", None),
        }
        if fsm_result
        else None
    )

    return {
        "thread_id": thread_id,
        "message_id": message_id,
        "lead_state": lead_state,
        "lead": _serialize_lead(lead_obj),
        "fsm_result": fsm_payload,
        "state_history": _serialize_state_history(state_history),
        "conversation_history": conversation_history,
        "reply_message": reply_message,
    }


@router.post("/simulate/email")
@handle_errors("FSM simulate email")
async def simulate_email_event(
    payload: SimulateEmailRequest,
    auth_context: AuthContext = Depends(require_user_or_service_permission("fsm:test")),
) -> Dict[str, Any]:
    """Simulate an inbound email through the production FSM path."""
    # Normalize field names and validate required fields
    try:
        payload = payload.validate_and_normalize()
    except ValueError as e:
        raise_http_exception(ErrorCodes.MISSING_REQUIRED_FIELD, str(e))
    except Exception as e:
        # Catch any other validation errors (including Pydantic validation errors)
        raise_http_exception(
            ErrorCodes.MISSING_REQUIRED_FIELD, f"Validation error: {str(e)}"
        )

    if not payload.content or not payload.content.strip():
        raise_http_exception(ErrorCodes.INVALID_INPUT, "Email content cannot be empty")

    message_id = (
        payload.message_id
        or f"sim-{int(datetime.now(timezone.utc).timestamp() * 1000)}"
    )
    thread_id = payload.thread_id or generate_thread_id(
        payload.from_email, payload.to_email, payload.subject
    )

    try:
        email_event = EmailEvent(
            message_id=message_id,
            thread_id=thread_id,
            sender_email=payload.from_email,
            recipient_email=payload.to_email,
            subject=payload.subject,
            content=payload.content,
            timestamp=datetime.now(timezone.utc),
            s3_bucket="",
            s3_key="",
        )

        api_client = create_api_client()
        async with api_client:
            # Convert preferences_override to dict for the lambda function
            prefs_override = None
            if payload.preferences_override:
                prefs_override = payload.preferences_override.model_dump(
                    exclude_none=True
                )
            result = await process_email_event(
                api_client, email_event, payload.content, prefs_override
            )

        fsm_result = result.get("result")
        if fsm_result is None:
            # A skip or failure path (user not found, blacklisted, etc.)
            lambda_body = result.get("lambda_body", {"message": "Processing skipped"})
            message = lambda_body.pop("message", "Email processing skipped")
            raise_http_exception(
                ErrorCodes.INELIGIBLE_STATUS,
                message,
                **lambda_body,
            )
    except Exception as e:
        if isinstance(e, HTTPException):
            raise e
        raise_http_exception(
            ErrorCodes.INTERNAL_ERROR, f"Failed to process email simulation: {str(e)}"
        )

    snapshot = _build_thread_snapshot(
        thread_id=thread_id,
        message_id=message_id,
        fsm_result=fsm_result,
        conversation_history=result.get("conversation_history", ""),
        state_history=result.get("state_history", []),
        lead_obj=result.get("lead"),
        reply_message=result.get("reply_message"),
    )

    return {**snapshot, "snapshot": snapshot}
