from fastapi import APIRouter, HTTPException, Query, Depends
from typing import List, Optional
from datetime import datetime
from beanie.odm.fields import PydanticObjectId
from database.models.message import (
    Message,
    MessageType,
    MessageStatus,
    MessageSummary,
    Conversation,
)
from database.models.deal import Deal
from database.models.user import User
from .utils import (
    get_current_user,
    require_user_or_service_permission,
    AuthContext,
    is_service_account,
    get_user_id,
)

router = APIRouter(prefix="/messages", tags=["messages"])

@router.get("/all")
async def get_all_messages_for_user(
    current_user: str = Depends(get_current_user),
    limit: int = Query(
        default=100,
        ge=1,
        le=1000,
        description="Maximum number of messages to return per conversation",
    ),
    offset: int = Query(
        default=0, ge=0, description="Number of messages to skip per conversation"
    ),
    message_type: Optional[MessageType] = Query(
        default=None, description="Filter by message type"
    ),
    deal_id: Optional[str] = Query(
        default=None, description="Filter by specific deal ID"
    ),
    status: Optional[MessageStatus] = Query(
        default=None, description="Filter by message status"
    ),
    unread_only: bool = Query(default=False, description="Return only unread messages"),
    conversation_limit: int = Query(
        default=50,
        ge=1,
        le=500,
        description="Maximum number of conversations to return",
    ),
    conversation_offset: int = Query(
        default=0, ge=0, description="Number of conversations to skip"
    ),
) -> dict:
    """
    Get all conversations for the authenticated user and all messages in those conversations.

    Args:
        current_user: The authenticated user from JWT token
        limit: Maximum number of messages to return per conversation
        offset: Number of messages to skip per conversation
        message_type: Filter by message type (email or ai_assistant)
        deal_id: Filter by specific deal ID
        status: Filter by message status
        unread_only: Return only unread messages
        conversation_limit: Maximum number of conversations to return
        conversation_offset: Number of conversations to skip

    Returns:
        Dictionary containing conversations and their messages

    Raises:
        HTTPException: If user not found or access denied
    """
    try:
        print(f"Getting all messages for user: {current_user}")
        # Find the user by UUID from token
        user = await User.find_one(User.uuid == current_user)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        # Build conversation query filters
        conversation_filters = {"userId": user.uuid}

        if deal_id:
            try:
                deal_object_id = PydanticObjectId(deal_id)
                conversation_filters["dealId"] = deal_object_id
            except Exception:
                raise HTTPException(status_code=400, detail="Invalid deal ID format")

        # Get conversations with pagination
        conversations = await Conversation.find(
            conversation_filters,
            limit=conversation_limit,
            skip=conversation_offset,
            sort=[("lastMessageAt", -1)],  # Sort by most recent first
        ).to_list()

        print(f"Conversations: {conversations}")
        # Build message query filters
        message_filters = {"userId": user.uuid}

        if message_type:
            message_filters["messageType"] = message_type

        if deal_id:
            message_filters["dealId"] = deal_object_id

        if status:
            message_filters["status"] = status

        if unread_only:
            message_filters["readAt"] = None

        # Get all messages for the user (with filters)
        all_messages = await Message.find(
            message_filters, sort=[("sentAt", -1)]  # Sort by most recent first
        ).to_list()

        # Group messages by conversation
        conversation_messages = {}
        for message in all_messages:
            conv_id = str(message.conversationId)
            if conv_id not in conversation_messages:
                conversation_messages[conv_id] = []
            conversation_messages[conv_id].append(message)

        # Build response with conversations and their messages
        result = {
            "conversations": [],
            "totalConversations": len(conversations),
            "totalMessages": len(all_messages),
            "userUuid": current_user,
        }

        for conversation in conversations:
            conv_id = str(conversation.id)
            messages = conversation_messages.get(conv_id, [])

            # Apply pagination to messages within each conversation
            paginated_messages = messages[offset : offset + limit]

            conversation_data = {
                "conversation": conversation,
                "messages": paginated_messages,
                "totalMessages": len(messages),
                "hasMoreMessages": len(messages) > offset + limit,
            }

            result["conversations"].append(conversation_data)

        return result

    except HTTPException:
        raise
    except Exception as e:
        print(f"Error retrieving conversations and messages for user: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail="Internal server error while retrieving conversations and messages",
        )


@router.get("/conversations", response_model=List[Conversation])
async def get_conversations_for_user(
    current_user: str = Depends(get_current_user),
    limit: int = Query(
        default=50,
        ge=1,
        le=500,
        description="Maximum number of conversations to return",
    ),
    offset: int = Query(default=0, ge=0, description="Number of conversations to skip"),
    deal_id: Optional[str] = Query(
        default=None, description="Filter by specific deal ID"
    ),
    conversation_type: Optional[str] = Query(
        default=None, description="Filter by conversation type (email or ai_chat)"
    ),
    unread_only: bool = Query(
        default=False, description="Return only conversations with unread messages"
    ),
) -> List[Conversation]:
    """
    Get all conversations for the authenticated user (without messages) - useful for conversation list views.

    Args:
        current_user: The authenticated user from JWT token
        limit: Maximum number of conversations to return
        offset: Number of conversations to skip
        deal_id: Filter by specific deal ID
        conversation_type: Filter by conversation type (email or ai_chat)
        unread_only: Return only conversations with unread messages

    Returns:
        List of conversations for the user

    Raises:
        HTTPException: If user not found or access denied
    """
    try:
        # Find the user by UUID from token
        user = await User.find_one(User.uuid == current_user)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        # Build query filters
        filters = {"userId": user.uuid}

        if deal_id:
            try:
                deal_object_id = PydanticObjectId(deal_id)
                filters["dealId"] = deal_object_id
            except Exception:
                raise HTTPException(status_code=400, detail="Invalid deal ID format")

        if conversation_type:
            filters["conversationType"] = conversation_type

        if unread_only:
            filters["unreadCount"] = {"$gt": 0}

        # Query conversations with pagination
        conversations = await Conversation.find(
            filters,
            limit=limit,
            skip=offset,
            sort=[("lastMessageAt", -1)],  # Sort by most recent first
        ).to_list()

        return conversations

    except HTTPException:
        raise
    except Exception as e:
        print(f"Error retrieving conversations for user: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail="Internal server error while retrieving conversations",
        )


@router.get("/deal/{deal_id}", response_model=List[Message])
async def get_messages_for_deal(
    deal_id: str,
    current_user: str = Depends(get_current_user),
    limit: int = Query(
        default=100, ge=1, le=1000, description="Maximum number of messages to return"
    ),
    offset: int = Query(default=0, ge=0, description="Number of messages to skip"),
    message_type: Optional[MessageType] = Query(
        default=None, description="Filter by message type"
    ),
    status: Optional[MessageStatus] = Query(
        default=None, description="Filter by message status"
    ),
    unread_only: bool = Query(default=False, description="Return only unread messages"),
) -> List[Message]:
    """
    Get all messages for a specific deal for the authenticated user.

    Args:
        deal_id: The ID of the deal
        current_user: The authenticated user from JWT token
        limit: Maximum number of messages to return
        offset: Number of messages to skip
        message_type: Filter by message type (email or ai_assistant)
        status: Filter by message status
        unread_only: Return only unread messages

    Returns:
        List of messages for the deal

    Raises:
        HTTPException: If deal or user not found, or access denied
    """
    try:
        # Validate user exists
        user = await User.find_one(User.uuid == current_user)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        # Validate deal exists and belongs to user
        try:
            deal_object_id = PydanticObjectId(deal_id)
        except Exception:
            raise HTTPException(status_code=400, detail="Invalid deal ID format")

        deal = await Deal.find_one(Deal.id == deal_object_id)
        if not deal:
            raise HTTPException(status_code=404, detail="Deal not found")

        # Build query filters
        filters = {"deal_id": deal_object_id, "user_id": user.uuid}

        if message_type:
            filters["message_type"] = message_type

        if status:
            filters["status"] = status

        if unread_only:
            filters["read_at"] = None

        # Query messages with pagination
        messages = await Message.find(
            filters,
            limit=limit,
            skip=offset,
            sort=[("sentAt", -1)],  # Sort by most recent first
        ).to_list()

        return messages

    except HTTPException:
        raise
    except Exception as e:
        print(f"Error retrieving messages for deal: {str(e)}")
        raise HTTPException(
            status_code=500, detail="Internal server error while retrieving messages"
        )


@router.get("/summary", response_model=List[MessageSummary])
async def get_message_summary_for_user(
    current_user: str = Depends(get_current_user),
) -> List[MessageSummary]:
    """
    Get message summary for all deals belonging to the authenticated user.

    Args:
        current_user: The authenticated user from JWT token

    Returns:
        List of message summaries for each deal

    Raises:
        HTTPException: If user not found or access denied
    """
    try:
        # Find the user by UUID from token
        user = await User.find_one(User.uuid == current_user)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        # Get all deals for the user
        deals = await Deal.find(Deal.createdBy == user.uuid).to_list()

        summaries = []

        for deal in deals:
            # Get message counts for this deal
            total_messages = await Message.find(
                {"dealId": deal.id, "userId": user.uuid}
            ).count()

            email_messages = await Message.find(
                {
                    "dealId": deal.id,
                    "userId": user.uuid,
                    "messageType": MessageType.EMAIL,
                }
            ).count()

            ai_messages = await Message.find(
                {
                    "dealId": deal.id,
                    "userId": user.uuid,
                    "messageType": MessageType.AI_ASSISTANT,
                }
            ).count()

            unread_count = await Message.find(
                {"dealId": deal.id, "userId": user.uuid, "readAt": None}
            ).count()

            # Get the last message
            last_message = (
                await Message.find({"dealId": deal.id, "userId": user.uuid})
                .sort([("sent_at", -1)])
                .limit(1)
                .to_list()
            )

            last_message_at = None
            last_message_type = None
            last_message_preview = None

            if last_message:
                last_message_at = last_message[0].sentAt
                last_message_type = last_message[0].messageType
                # Create a preview (first 100 characters)
                last_message_preview = (
                    last_message[0].content[:100] + "..."
                    if len(last_message[0].content) > 100
                    else last_message[0].content
                )

            summary = MessageSummary(
                dealId=deal.id,
                totalMessages=total_messages,
                emailMessages=email_messages,
                aiMessages=ai_messages,
                unreadCount=unread_count,
                lastMessageAt=last_message_at,
                lastMessageType=last_message_type,
                lastMessagePreview=last_message_preview,
            )

            summaries.append(summary)

        return summaries

    except HTTPException:
        raise
    except Exception as e:
        print(f"Error retrieving message summary for user: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail="Internal server error while retrieving message summary",
        )


@router.get("/deal/{deal_id}/summary", response_model=MessageSummary)
async def get_message_summary_for_deal(
    deal_id: str, current_user: str = Depends(get_current_user)
) -> MessageSummary:
    """
    Get message summary for a specific deal for the authenticated user.

    Args:
        deal_id: The ID of the deal
        current_user: The authenticated user from JWT token

    Returns:
        Message summary for the deal

    Raises:
        HTTPException: If deal or user not found, or access denied
    """
    try:
        # Validate user exists
        user = await User.find_one(User.uuid == current_user)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        # Validate deal exists
        try:
            deal_object_id = PydanticObjectId(deal_id)
        except Exception:
            raise HTTPException(status_code=400, detail="Invalid deal ID format")

        deal = await Deal.find_one(Deal.id == deal_object_id)
        if not deal:
            raise HTTPException(status_code=404, detail="Deal not found")

        # Get message counts for this deal
        total_messages = await Message.find(
            {"dealId": deal_object_id, "userId": user.uuid}
        ).count()

        email_messages = await Message.find(
            {
                "dealId": deal_object_id,
                "userId": user.uuid,
                "messageType": MessageType.EMAIL,
            }
        ).count()

        ai_messages = await Message.find(
            {
                "dealId": deal_object_id,
                "userId": user.uuid,
                "messageType": MessageType.AI_ASSISTANT,
            }
        ).count()

        unread_count = await Message.find(
            {"dealId": deal_object_id, "userId": user.uuid, "readAt": None}
        ).count()

        # Get the last message
        last_message = (
            await Message.find({"dealId": deal_object_id, "userId": user.uuid})
            .sort([("sent_at", -1)])
            .limit(1)
            .to_list()
        )

        last_message_at = None
        last_message_type = None
        last_message_preview = None

        if last_message:
            last_message_at = last_message[0].sentAt
            last_message_type = last_message[0].messageType
            # Create a preview (first 100 characters)
            last_message_preview = (
                last_message[0].content[:100] + "..."
                if len(last_message[0].content) > 100
                else last_message[0].content
            )

        summary = MessageSummary(
            dealId=deal_object_id,
            totalMessages=total_messages,
            emailMessages=email_messages,
            aiMessages=ai_messages,
            unreadCount=unread_count,
            lastMessageAt=last_message_at,
            lastMessageType=last_message_type,
            lastMessagePreview=last_message_preview,
        )

        return summary

    except HTTPException:
        raise
    except Exception as e:
        print(f"Error retrieving message summary for deal: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail="Internal server error while retrieving message summary",
        )


@router.patch("/{message_id}/read")
async def mark_message_as_read(
    message_id: str, current_user: str = Depends(get_current_user)
) -> Message:
    """
    Mark a message as read for the authenticated user.

    Args:
        message_id: The ID of the message to mark as read
        current_user: The authenticated user from JWT token

    Returns:
        Updated message object

    Raises:
        HTTPException: If message or user not found, or access denied
    """
    try:
        # Validate user exists
        user = await User.find_one(User.uuid == current_user)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        # Validate message exists and belongs to user
        if not message_id or not isinstance(message_id, str):
            raise HTTPException(status_code=400, detail="Invalid message ID format")

        message = await Message.find_one(
            Message.uuid == message_id, Message.userId == user.uuid
        )

        if not message:
            raise HTTPException(status_code=404, detail="Message not found")

        # Mark as read
        message.readAt = datetime.now()
        message.updatedAt = datetime.now()

        # Save the updated message
        updated_message = await message.save()

        return updated_message

    except HTTPException:
        raise
    except Exception as e:
        print(f"Error marking message as read: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail="Internal server error while marking message as read",
        )


@router.get("/unread-count")
async def get_unread_message_count(
    current_user: str = Depends(get_current_user),
) -> dict:
    """
    Get the total count of unread messages for the authenticated user across all deals.

    Args:
        current_user: The authenticated user from JWT token

    Returns:
        Dictionary with unread message counts

    Raises:
        HTTPException: If user not found or access denied
    """
    try:
        # Find the user by UUID from token
        user = await User.find_one(User.uuid == current_user)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        # Get unread counts by type
        total_unread = await Message.find({"userId": user.uuid, "readAt": None}).count()

        email_unread = await Message.find(
            {"userId": user.uuid, "readAt": None, "messageType": MessageType.EMAIL}
        ).count()

        ai_unread = await Message.find(
            {
                "userId": user.uuid,
                "readAt": None,
                "messageType": MessageType.AI_ASSISTANT,
            }
        ).count()

        return {
            "totalUnread": total_unread,
            "emailUnread": email_unread,
            "aiUnread": ai_unread,
            "userUuid": current_user,
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"Error retrieving unread message count: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail="Internal server error while retrieving unread message count",
        )


@router.post("/", response_model=Message)
async def create_message(
    message: Message,
    auth_context: AuthContext = Depends(
        require_user_or_service_permission("messages:create")
    ),
) -> Message:
    """
    Create a new message and update the associated conversation.

    Supports both user JWT auth and service account auth (for Lambda handler).
    - For users: userId is taken from the JWT token, ownership is validated.
    - For service accounts: userId must be provided in the message body, ownership check is skipped.

    Args:
        message: The message data
        auth_context: Authentication context (user or service account)

    Returns:
        Created message object

    Raises:
        HTTPException: If user, conversation, or deal not found or validation fails
    """

    try:
        # Determine user context based on auth type
        if is_service_account(auth_context):
            # Service account - userId must be in request body
            if not message.userId:
                raise HTTPException(
                    status_code=400,
                    detail="userId is required for service account requests",
                )
            user_uuid = message.userId
        else:
            # User auth - get from token
            user_uuid = get_user_id(auth_context)

        # Validate user exists
        user = await User.find_one(User.uuid == user_uuid)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        # Validate conversation exists (conversationId is UUID string)
        conversation = await Conversation.find_one(
            Conversation.uuid == message.conversationId
        )
        if not conversation:
            raise HTTPException(status_code=404, detail="Conversation not found")

        # For user auth, verify ownership; for service accounts, skip ownership check
        if not is_service_account(auth_context):
            if conversation.userId != user_uuid:
                raise HTTPException(status_code=403, detail="Access denied")

        # Validate deal exists only if dealId is provided (not for pre-deal messages)
        if message.dealId:
            deal = await Deal.find_one(Deal.uuid == message.dealId)
            if not deal:
                raise HTTPException(status_code=404, detail="Deal not found")

        # Set user ID and timestamps
        message.userId = user_uuid
        message.createdAt = datetime.now()
        message.updatedAt = datetime.now()

        # Calculate thread position if not set
        if not message.threadPosition:
            last_message = (
                await Message.find({"conversationId": message.conversationId})
                .sort([("threadPosition", -1)])
                .limit(1)
                .to_list()
            )

            if last_message:
                message.threadPosition = last_message[0].threadPosition + 1
            else:
                message.threadPosition = 1

        # Save the message
        created_message = await message.save()

        # Update conversation metadata
        conversation.lastMessage = (
            message.content[:100] + "..."
            if len(message.content) > 100
            else message.content
        )
        conversation.lastMessageAt = message.sentAt
        conversation.messageCount += 1
        conversation.updatedAt = datetime.now()

        # Increment unread count if message is unread and from someone else
        if not message.readAt and message.senderId != user_uuid:
            conversation.unreadCount += 1

        await conversation.save()

        return created_message

    except HTTPException:
        raise
    except Exception as e:
        print(f"Error creating message: {str(e)}")
        raise HTTPException(
            status_code=500, detail="Internal server error while creating message"
        )
