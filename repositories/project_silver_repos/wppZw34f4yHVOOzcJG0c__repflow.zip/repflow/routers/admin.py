from fastapi import APIRouter, Depends, HTTPException, Query, status
from auth.JWTBearer import JWTAuthorizationCredentials
from routers.utils import get_auth
from database.models.user import User
from database.models.deal import Deal
from collections import defaultdict
from typing import Dict, Any, Optional
from pydantic import BaseModel, Field
from datetime import datetime
import logging

logger = logging.getLogger("uvicorn.error")
router = APIRouter(prefix="/admin", tags=["admin"])


async def verify_admin(credentials: JWTAuthorizationCredentials = Depends(get_auth)):
    """Verify user is in admin group - uses existing JWT verification"""
    groups = credentials.claims.get("cognito:groups", [])

    if "admin" not in groups:
        logger.warning(
            f"Non-admin user attempted to access admin endpoint: {credentials.claims.get('sub', 'unknown')}"
        )
        raise HTTPException(status_code=403, detail="Admin access required")

    user_id = credentials.claims.get("sub")
    if not user_id:
        raise HTTPException(status_code=403, detail="User ID not found in token")

    return user_id


@router.get("/users")
async def list_all_users(
    skip: int = Query(0, ge=0, description="Number of users to skip"),
    limit: int = Query(
        50, ge=1, le=200, description="Maximum number of users to return"
    ),
    admin_id: str = Depends(verify_admin),
) -> Dict[str, Any]:
    """
    Get paginated list of all users with stats - admin only.

    Returns:
        - users: List of user objects with stats
        - total: Total count of users
        - skip: Number of skipped users
        - limit: Max number of users returned
    """
    logger.info(f"Admin {admin_id} requesting all users (skip={skip}, limit={limit})")

    # Get users with pagination
    users = await User.find_all().skip(skip).limit(limit).to_list()
    total_count = await User.count()

    if not users:
        return {"users": [], "total": 0, "skip": skip, "limit": limit}

    # Batch fetch all deals (avoid N+1 queries)
    user_ids = [u.uuid for u in users]
    all_deals = await Deal.find({"userId": {"$in": user_ids}}).to_list()

    # Group deals by user ID
    deals_by_user = defaultdict(list)
    for deal in all_deals:
        deals_by_user[deal.userId].append(deal)

    # Build result
    result = []
    for user in users:
        user_deals = deals_by_user.get(user.uuid, [])
        # Calculate revenue from deal values
        revenue = sum(getattr(d, "value", 0) or 0 for d in user_deals)

        tags = []
        if (
            user.profile
            and hasattr(user.profile, "foundingCreator")
            and user.profile.foundingCreator
        ):
            tags.append("founding-creator")

        result.append(
            {
                "id": user.uuid,
                "name": (
                    user.profile.name
                    if (user.profile and hasattr(user.profile, "name"))
                    else "N/A"
                ),
                "email": (
                    user.profile.email
                    if (user.profile and hasattr(user.profile, "email"))
                    else "N/A"
                ),
                "status": "active",  # Could be enhanced to check actual status
                "plan": (
                    user.profile.subscription.tier
                    if (
                        user.profile
                        and hasattr(user.profile, "subscription")
                        and user.profile.subscription
                        and hasattr(user.profile.subscription, "tier")
                    )
                    else "starter"
                ),
                "tags": tags,
                "joinDate": user.createdAt.isoformat() if user.createdAt else None,
                "lastActive": user.updatedAt.isoformat() if user.updatedAt else None,
                "deals": len(user_deals),
                "revenue": revenue,
            }
        )

    logger.info(f"Returning {len(result)} users to admin {admin_id}")
    return {"users": result, "total": total_count, "skip": skip, "limit": limit}


class UserBadgesUpdate(BaseModel):
    """Request model for updating user badges"""
    foundingCreator: Optional[bool] = Field(
        None, description="Whether the user has the 'First 100 Founder Creator' badge"
    )


class UserBadgesResponse(BaseModel):
    """Response model for user badges"""
    foundingCreator: bool = Field(
        ..., description="Whether the user has the 'First 100 Founder Creator' badge"
    )


@router.get("/users/{user_id}")
async def get_user_details(
    user_id: str, admin_id: str = Depends(verify_admin)
) -> Dict[str, Any]:
    """
    Get detailed user information including deals, referrals, billing, and badges - admin only.
    Returns all data needed for the user detail modal in one response.
    """
    logger.info(f"Admin {admin_id} requesting details for user {user_id}")

    user = await User.find_one(User.uuid == user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    # Profile
    tags = []
    if (
        user.profile
        and hasattr(user.profile, "foundingCreator")
        and user.profile.foundingCreator
    ):
        tags.append("founding-creator")

    profile = {
        "id": user.uuid,
        "name": user.profile.name if user.profile else "N/A",
        "email": user.profile.email if user.profile else "N/A",
        "status": "active" if user.isActive else "inactive",
        "plan": (
            user.profile.subscription.tier
            if user.profile and user.profile.subscription
            else "starter"
        ),
        "tags": tags,
        "joinDate": user.createdAt.isoformat() if user.createdAt else None,
        "lastActive": user.updatedAt.isoformat() if user.updatedAt else None,
    }

    # Badges
    badges = {
        "foundingCreator": (
            user.profile.foundingCreator
            if (user.profile and hasattr(user.profile, "foundingCreator"))
            else False
        ),
    }

    # Deals
    user_deals = await Deal.find(Deal.userId == user_id).to_list()
    deals = [
        {
            "id": str(d.id),
            "title": d.title,
            "status": d.status.value if hasattr(d.status, "value") else str(d.status),
            "value": d.value,
            "type": (
                d.dealType.value
                if hasattr(d.dealType, "value")
                else str(d.dealType)
            ),
            "createdAt": d.createdAt.isoformat() if d.createdAt else None,
        }
        for d in user_deals
    ]

    # Referrals
    referral_stats = None
    referral_history = []
    if user.referralData:
        rd = user.referralData
        completed = [
            r for r in rd.referralHistory if r.status == "completed"
        ]
        pending = [r for r in rd.referralHistory if r.status == "pending"]
        total_rewards = sum(r.revenue for r in completed)

        referral_stats = {
            "totalReferrals": rd.totalReferrals,
            "completedReferrals": len(completed),
            "pendingReferrals": len(pending),
            "totalRevenue": rd.totalRevenue,
            "totalRewards": total_rewards,
            "referralCode": rd.referralCode,
            "referralLink": str(rd.referralLink) if rd.referralLink else None,
        }

        referral_history = [
            {
                "referralId": rh.id,
                "referredUserName": rh.referredUserName,
                "status": rh.status,
                "revenue": rh.revenue,
                "date": rh.date.isoformat() if rh.date else None,
            }
            for rh in rd.referralHistory
        ]

    # Billing
    billing = None
    if user.billingInfo:
        bi = user.billingInfo
        billing = {
            "cardLast4": bi.cardLast4,
            "cardBrand": bi.cardBrand,
            "expirationMonth": bi.expirationMonth,
            "expirationYear": bi.expirationYear,
            "nextBillingDate": (
                bi.nextBillingDate.isoformat() if bi.nextBillingDate else None
            ),
            "billingEmail": bi.billingEmail,
            "billingAddress": (
                bi.billingAddress.model_dump() if bi.billingAddress else None
            ),
            "paymentMethodId": bi.paymentMethodId,
        }

    # Subscription
    subscription = None
    if user.profile and user.profile.subscription:
        sub = user.profile.subscription
        subscription = {
            "tier": sub.tier,
            "status": sub.status,
            "currentPeriodEnd": (
                sub.currentPeriodEnd.isoformat() if sub.currentPeriodEnd else None
            ),
        }

    return {
        "profile": profile,
        "badges": badges,
        "deals": deals,
        "referralStats": referral_stats,
        "referralHistory": referral_history,
        "billing": billing,
        "subscription": subscription,
    }


@router.patch("/users/{user_id}/badges")
async def update_user_badges(
    user_id: str,
    badges_update: UserBadgesUpdate,
    admin_id: str = Depends(verify_admin),
) -> UserBadgesResponse:
    """
    Update badges for a specific user - admin only.

    Args:
        user_id: UUID of the user to update
        badges_update: UserBadgesUpdate with badge values to update
        admin_id: Authenticated admin user ID

    Returns:
        UserBadgesResponse with updated badge values
    """
    logger.info(
        f"Admin {admin_id} updating badges for user {user_id}: {badges_update.model_dump()}"
    )

    user = await User.find_one(User.uuid == user_id)

    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
        )

    # Ensure user has a profile
    if not user.profile:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="User profile not found",
        )

    # Update badges
    updated = False
    if badges_update.foundingCreator is not None:
        user.profile.foundingCreator = badges_update.foundingCreator
        updated = True
        logger.info(
            f"Updated foundingCreator badge for user {user_id} to {badges_update.foundingCreator}"
        )

    if updated:
        user.profile.updatedAt = datetime.utcnow()
        user.updatedAt = datetime.utcnow()
        await user.save()
        logger.info(f"Successfully updated badges for user {user_id}")

    return UserBadgesResponse(
        foundingCreator=user.profile.foundingCreator,
    )
