from fastapi import APIRouter, Depends, HTTPException, status, Query
from auth.JWTBearer import JWTAuthorizationCredentials
from .utils import (
    get_current_user,
    require_user_or_service_permission,
    AuthContext,
    is_user_auth,
    get_user_id,
    auth,
)
from typing import Optional
from database.models.deal import Deal, DealStatus, Deliverable, DeliverableContent
from database.models.message import Conversation, ConversationType, ConversationStatus
from datetime import datetime, timezone
from typing import List, Dict, Any
import logging
from utils.error_handler import handle_errors, raise_http_exception, ErrorCodes
from pydantic import BaseModel, ConfigDict
from database.models.brand import Brand
from database.models.contact import Contact as CRMContact
import humps


def to_camel(string):
    return humps.camelize(string)


router = APIRouter(prefix="/deals", tags=["deals"])
logger = logging.getLogger("uvicorn.error")


# Response models for deals with populated relations
class BrandInDealResponse(BaseModel):
    """Simplified brand data for deal responses."""

    uuid: str
    name: str
    website: Optional[str] = None
    logo_url: Optional[str] = None
    is_agency: bool = False

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
        from_attributes=True,
    )


class ContactInDealResponse(BaseModel):
    """Simplified contact data for deal responses."""

    uuid: str
    name: str
    email: str
    title: Optional[str] = None
    phone: Optional[str] = None
    role: Optional[str] = None
    is_primary: bool = False

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
        from_attributes=True,
    )


# Canonical platform keys for deal card icon mapping (e.g. YouTube, Instagram)
PLATFORM_ICON_KEYS = frozenset(
    {"youtube", "instagram", "tiktok", "video", "podcast", "twitter"}
)


def build_deliverables_display(deal: Deal) -> List[Dict[str, str]]:
    """
    Build a line-by-line list of deliverables for the deal card.
    Each item has 'platform' (icon key) and 'text' so the UI can render:
    [Platform Icon] description per line.
    """
    lines: List[Dict[str, str]] = []
    if not deal.deliverables:
        return lines
    for d in deal.deliverables:
        for content in d.contents:
            platform = (content.contentType or "").strip().lower()
            if platform not in PLATFORM_ICON_KEYS and platform:
                # Keep unknown platforms as-is for future icon support
                pass
            text = (content.text or "").strip()
            if text:
                lines.append({"platform": platform or "video", "text": text})
    return lines


@router.get("/")
@handle_errors("Get all deals")
async def get_all(
    userId: Optional[str] = Query(
        None, description="User ID to fetch deals for (admin only)"
    ),
    credentials: JWTAuthorizationCredentials = Depends(auth),
) -> List[Dict[str, Any]]:
    """
    Get all deals for the current user, or for a specific user if admin.

    Args:
        userId: Optional user ID (admin only). If not provided, returns current user's deals.
        credentials: JWT credentials from authentication

    Returns:
        List of deals
    """
    current_user = None
    try:
        # Extract current user ID from token
        if "cognito:username" in credentials.claims:
            current_user = credentials.claims["cognito:username"]
        elif "username" in credentials.claims:
            current_user = credentials.claims["username"]
        elif "sub" in credentials.claims:
            current_user = credentials.claims["sub"]
        elif "email" in credentials.claims:
            current_user = credentials.claims["email"]
        else:
            raise_http_exception(
                ErrorCodes.INVALID_TOKEN, "No user identifier found in token"
            )
    except KeyError:
        raise_http_exception(ErrorCodes.INVALID_TOKEN, "User ID not found in token")

    # If requesting another user's data, verify admin access
    if userId and userId != current_user:
        groups = credentials.claims.get("cognito:groups", [])
        if "admin" not in groups:
            logger.warning(
                f"Non-admin user {current_user} attempted to access deals for user {userId}"
            )
            raise_http_exception(
                ErrorCodes.INSUFFICIENT_PERMISSIONS,
                "Admin access required to view other users' deals",
            )
        target_user = userId
        logger.info(f"Admin {current_user} accessing deals for user {target_user}")
    else:
        target_user = current_user

    logger.info(f"Getting all {Deal.__name__} for user: {target_user}")

    # Get all deals
    deals = await Deal.find(Deal.userId == target_user).to_list()

    # Batch fetch brands
    brand_ids = [d.brandId for d in deals if d.brandId]
    brands = []
    if brand_ids:
        brands = await Brand.find(
            Brand.user_id == target_user, {"uuid": {"$in": brand_ids}}
        ).to_list()
    brand_map = {b.uuid: b for b in brands}

    # Batch fetch contacts
    contact_ids = [d.contactId for d in deals if d.contactId]
    contacts = []
    if contact_ids:
        contacts = await CRMContact.find(
            CRMContact.user_id == target_user, {"uuid": {"$in": contact_ids}}
        ).to_list()
    contact_map = {c.uuid: c for c in contacts}

    # Build response with populated data
    result = []
    for deal in deals:
        # Populate brand
        brand_data = None
        if deal.brandId and deal.brandId in brand_map:
            brand = brand_map[deal.brandId]
            brand_data = BrandInDealResponse(
                uuid=brand.uuid,
                name=brand.name,
                website=brand.website,
                logo_url=brand.logo_url,
                is_agency=brand.is_agency,
            )

        # Populate contact
        contact_data = None
        if deal.contactId and deal.contactId in contact_map:
            contact = contact_map[deal.contactId]
            role = contact.brand_roles.get(deal.brandId) if deal.brandId else None
            is_primary = (
                deal.brandId in contact.primary_for_brands if deal.brandId else False
            )

            contact_data = ContactInDealResponse(
                uuid=contact.uuid,
                name=contact.name,
                email=contact.email,
                title=contact.title,
                phone=contact.phone,
                role=role,
                is_primary=is_primary,
            )

        # Convert and append; add line-by-line deliverables for deal card (icon + text per line)
        deal_dict = deal.model_dump(mode="json")
        deal_dict["brand"] = brand_data.model_dump(mode="json") if brand_data else None
        deal_dict["contact"] = (
            contact_data.model_dump(mode="json") if contact_data else None
        )
        deal_dict["deliverablesDisplay"] = build_deliverables_display(deal)
        result.append(deal_dict)

    return result


@router.get("/{id}")
@handle_errors("Get deal by ID")
async def get_by_id(
    id: str, current_user: str = Depends(get_current_user)
) -> Dict[str, Any]:
    """Get a specific deal by ID with populated brand and contact."""
    logger.info(f"Getting {Deal.__name__} {id} for user: {current_user}")

    deal = await Deal.find_one(Deal.uuid == id, Deal.userId == current_user)
    if not deal:
        raise_http_exception(ErrorCodes.DEAL_NOT_FOUND, f"Deal with ID {id} not found")

    # Populate brand
    brand_data = None
    if deal.brandId:
        brand = await Brand.find_one(
            Brand.uuid == deal.brandId, Brand.user_id == current_user
        )
        if brand:
            brand_data = BrandInDealResponse(
                uuid=brand.uuid,
                name=brand.name,
                website=brand.website,
                logo_url=brand.logo_url,
                is_agency=brand.is_agency,
            )

    # Populate contact
    contact_data = None
    if deal.contactId:
        contact = await CRMContact.find_one(
            CRMContact.uuid == deal.contactId, CRMContact.user_id == current_user
        )
        if contact:
            # Get role from brand relationship if available
            role = contact.brand_roles.get(deal.brandId) if deal.brandId else None
            is_primary = (
                deal.brandId in contact.primary_for_brands if deal.brandId else False
            )

            contact_data = ContactInDealResponse(
                uuid=contact.uuid,
                name=contact.name,
                email=contact.email,
                title=contact.title,
                phone=contact.phone,
                role=role,
                is_primary=is_primary,
            )

    # Convert deal to dict and add populated relations and line-by-line deliverables
    deal_dict = deal.dict()
    deal_dict["brand"] = brand_data.dict() if brand_data else None
    deal_dict["contact"] = contact_data.dict() if contact_data else None
    deal_dict["deliverablesDisplay"] = build_deliverables_display(deal)

    return deal_dict


@router.post("/")
@handle_errors("Create deal")
async def create(
    item: Deal,
    auth_context: AuthContext = Depends(
        require_user_or_service_permission("deals:create")
    ),
) -> Deal:
    """
    Create a new deal and automatically create an associated conversation.

    Args:
        item: The deal data
        auth_context: Authentication context (user or service account)

    Returns:
        Created deal object
    """
    # Handle different auth contexts
    if is_user_auth(auth_context):
        # User authentication - use their user ID
        current_user = get_user_id(auth_context)
        item.userId = current_user
    else:
        # Service account - deal must already have userId set
        if not hasattr(item, "userId") or not item.userId:
            raise_http_exception(
                ErrorCodes.MISSING_REQUIRED_FIELD,
                "Service accounts must specify userId when creating deals",
            )
        current_user = item.userId

    logger.info(f"Creating {Deal.__name__} for user: {current_user}")
    item.createdAt = datetime.now(timezone.utc)
    item.updatedAt = datetime.now(timezone.utc)

    try:
        # Create the deal first
        created_deal = await item.insert()

        # Check if deal meets criteria and create conversation if eligible
        conversation_result = await check_deal_and_create_conversation(created_deal)

        if conversation_result["success"]:
            logger.info(
                f"✅ Created deal {created_deal.uuid} and conversation {conversation_result['conversation_id']} for user: {current_user}"
            )
        else:
            logger.info(
                f"✅ Created deal {created_deal.uuid} for user: {current_user} (conversation not created: {conversation_result['reason']})"
            )

        return created_deal

    except Exception as e:
        if isinstance(e, HTTPException):
            raise e
        logger.error(f"Error creating deal and conversation: {str(e)}")
        raise_http_exception(
            ErrorCodes.INTERNAL_ERROR,
            f"Failed to create deal and associated conversation: {str(e)}",
        )


@router.put("/{id}")
@handle_errors("Update deal")
async def update(
    id: str, item: Deal, current_user: str = Depends(get_current_user)
) -> Deal:
    """Update a deal by ID."""
    logger.info(f"Updating {Deal.__name__} {id} for user: {current_user}")

    if item.uuid != id:
        raise_http_exception(
            ErrorCodes.INVALID_INPUT,
            "ID mismatch between URL parameter and deal object",
        )

    existing_doc = await Deal.find_one(Deal.uuid == id, Deal.userId == current_user)
    if not existing_doc:
        raise_http_exception(ErrorCodes.DEAL_NOT_FOUND, f"Deal with ID {id} not found")

    # Preserve user ID and timestamps
    item.userId = existing_doc.userId
    item.createdAt = existing_doc.createdAt
    item.updatedAt = datetime.now(timezone.utc)

    try:
        # Update the deal
        updated_deal = await item.replace()

        # Check if deal meets criteria and create conversation if eligible
        conversation_result = await check_deal_and_create_conversation(updated_deal)

        if conversation_result["success"]:
            logger.info(
                f"✅ Updated deal {updated_deal.uuid} and created conversation {conversation_result['conversation_id']} for user: {current_user}"
            )
        else:
            logger.info(
                f"✅ Updated deal {updated_deal.uuid} for user: {current_user} (conversation not created: {conversation_result['reason']})"
            )

        return updated_deal

    except Exception as e:
        if isinstance(e, HTTPException):
            raise e
        logger.error(f"Error updating deal {id}: {str(e)}")
        raise_http_exception(
            ErrorCodes.INTERNAL_ERROR, f"Failed to update deal: {str(e)}"
        )


@router.delete("/{id}")
@handle_errors("Delete deal")
async def delete(id: str, current_user: str = Depends(get_current_user)) -> dict:
    """Delete a deal by ID."""
    logger.info(f"Deleting {Deal.__name__} {id} for user: {current_user}")

    # Only allow deletion if the item belongs to the current user
    doc = await Deal.find_one(Deal.uuid == id, Deal.userId == current_user)
    if not doc:
        raise_http_exception(ErrorCodes.DEAL_NOT_FOUND, f"Deal with ID {id} not found")

    try:
        result = await doc.delete()
        return {
            "success": result is not None,
            "message": f"Deal {id} deleted successfully",
        }
    except Exception as e:
        logger.error(f"Error deleting deal {id}: {str(e)}")
        raise_http_exception(
            ErrorCodes.INTERNAL_ERROR, f"Failed to delete deal: {str(e)}"
        )


@router.patch("/{deal_id}/link-contact")
@handle_errors("Link contact to deal")
async def link_contact_to_deal(
    deal_id: str,
    contact_id: str = Query(..., description="Contact UUID to link to the deal"),
    auth_context: AuthContext = Depends(
        require_user_or_service_permission("deals:update")
    ),
) -> Deal:
    """
    Link a CRM contact to a deal.

    Args:
        deal_id: The deal UUID
        contact_id: The contact UUID to link
        auth_context: Authentication context (user or service account)

    Returns:
        Updated deal object
    """
    # Handle different auth contexts
    if is_user_auth(auth_context):
        current_user = get_user_id(auth_context)
    else:
        # Service account - need to find deal to get user ID
        deal = await Deal.find_one(Deal.uuid == deal_id)
        if not deal:
            raise_http_exception(
                ErrorCodes.DEAL_NOT_FOUND, f"Deal with ID {deal_id} not found"
            )
        current_user = deal.userId

    logger.info(
        f"Linking contact {contact_id} to deal {deal_id} for user: {current_user}"
    )

    # Find the deal
    deal = await Deal.find_one(Deal.uuid == deal_id, Deal.userId == current_user)
    if not deal:
        raise_http_exception(
            ErrorCodes.DEAL_NOT_FOUND, f"Deal with ID {deal_id} not found"
        )

    # Update the contact ID
    deal.contactId = contact_id
    deal.updatedAt = datetime.now(timezone.utc)

    await deal.save()

    logger.info(f"✅ Linked contact {contact_id} to deal {deal_id}")
    return deal


async def check_deal_and_create_conversation(deal: Deal) -> Dict[str, Any]:
    """
    Check if a deal meets the criteria for conversation creation and create one if it does.

    Criteria:
    1. The deal has an email contact (via contactId)
    2. The deal isn't in the status of Complete, Archive or Lost

    Args:
        deal: The deal to check

    Returns:
        Dict with result information including success status, conversation_id if created, and reason
    """
    from database.models.contact import Contact as CRMContact
    from database.models.brand import Brand

    try:
        # Fetch contact by ID
        primary_contact_email = None
        primary_contact_name = None

        if deal.contactId:
            contact = await CRMContact.find_one(CRMContact.uuid == deal.contactId)
            if contact and contact.email and contact.email.strip():
                primary_contact_email = contact.email
                primary_contact_name = contact.name

        # Fetch brand by ID for company name
        company_name = "Unknown Company"
        if deal.brandId:
            brand = await Brand.find_one(Brand.uuid == deal.brandId)
            if brand:
                company_name = brand.name

        # Use brand name as fallback for contact name
        if not primary_contact_name:
            primary_contact_name = company_name

        if not primary_contact_email:
            return {
                "success": False,
                "reason": "No email contact found",
                "deal_id": deal.uuid,
                "deal_title": deal.title,
            }

        # Check if deal status is valid (not Complete, Archive, or Lost)
        invalid_statuses = {DealStatus.COMPLETE, DealStatus.ARCHIVE, DealStatus.LOST}
        if deal.status in invalid_statuses:
            return {
                "success": False,
                "reason": f"Deal status '{deal.status.value}' is not eligible for conversation creation",
                "deal_id": deal.uuid,
                "deal_title": deal.title,
            }

        # Check if conversation already exists for this deal
        existing_conversation = await Conversation.find_one(
            Conversation.dealId == deal.uuid
        )

        if existing_conversation:
            return {
                "success": False,
                "reason": "Conversation already exists for this deal",
                "deal_id": deal.uuid,
                "deal_title": deal.title,
                "existing_conversation_id": existing_conversation.uuid,
            }

        # Create conversation
        conversation = Conversation(
            name=f"{company_name} - {deal.dealType.value}",
            status=ConversationStatus.ACTIVE,
            dealId=deal.uuid,
            userId=deal.userId,
            contactName=primary_contact_name,
            contactEmail=primary_contact_email,
            subject=f"Partnership Discussion - {company_name}",
            createdAt=datetime.now(timezone.utc),
            updatedAt=datetime.now(timezone.utc),
            avatar=None,
            lastMessage=None,
            lastMessageAt=None,
            threadId=None,
        )

        # Save the conversation
        await conversation.insert()

        logger.info(
            f"✅ Created conversation {conversation.uuid} for deal {deal.uuid} ({deal.title})"
        )

        return {
            "success": True,
            "reason": "Conversation created successfully",
            "deal_id": deal.uuid,
            "deal_title": deal.title,
            "conversation_id": conversation.uuid,
            "contact_name": primary_contact_name,
            "contact_email": primary_contact_email,
        }

    except Exception as e:
        logger.error(
            f"Error checking deal {deal.uuid} and creating conversation: {str(e)}"
        )
        return {
            "success": False,
            "reason": f"Error creating conversation: {str(e)}",
            "deal_id": deal.uuid,
            "deal_title": deal.title,
        }
