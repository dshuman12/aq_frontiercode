from fastapi import APIRouter, HTTPException, status, Depends, Query
from auth.JWTBearer import JWTAuthorizationCredentials
from .utils import get_current_user, auth
from database.models.user import User
from database.models.referral import Referral, ReferralStatus
from database.models.user import ReferralHistory
from services.referral_service import referral_service
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta
import logging
import uuid

# Configure logger for this module
logger = logging.getLogger("uvicorn.error")
router = APIRouter(prefix="/referrals", tags=["referrals"])


class ReferralCodeRequest(BaseModel):
    """Request model for validating a referral code"""

    referralCode: str = Field(..., description="The referral code to validate")


class ReferralCodeResponse(BaseModel):
    """Response model for referral code validation"""

    isValid: bool = Field(..., description="Whether the referral code is valid")
    referrerName: Optional[str] = Field(
        default=None, description="Name of the referring user"
    )
    referrerUsername: Optional[str] = Field(
        default=None, description="Username of the referring user"
    )
    message: str = Field(..., description="Status message")


class CreateReferralRequest(BaseModel):
    """Request model for creating a referral record"""

    referralCode: str = Field(..., description="The referral code being used")
    stripeCustomerId: Optional[str] = Field(
        default=None, description="Stripe customer ID of the referee"
    )
    refereeUserId: Optional[str] = Field(
        default=None, description="User ID of the referee (for webhook usage)"
    )


class WebhookCreateReferralRequest(BaseModel):
    """Request model for creating a referral record from webhook"""

    referralCode: str = Field(..., description="The referral code being used")
    stripeCustomerId: str = Field(..., description="Stripe customer ID of the referee")
    refereeUserId: str = Field(..., description="User ID of the referee")
    refereeEmail: str = Field(..., description="Email of the referee")


class CreateReferralResponse(BaseModel):
    """Response model for creating a referral record"""

    success: bool = Field(
        ..., description="Whether the referral was created successfully"
    )
    referralId: Optional[str] = Field(
        default=None, description="ID of the created referral record"
    )
    message: str = Field(..., description="Status message")


class ReferralStatsResponse(BaseModel):
    """Response model for referral statistics"""

    totalReferrals: int = Field(..., description="Total number of referrals made")
    completedReferrals: int = Field(..., description="Number of completed referrals")
    pendingReferrals: int = Field(..., description="Number of pending referrals")
    totalRevenue: float = Field(..., description="Total revenue from referrals")
    totalRewards: float = Field(..., description="Total rewards earned")
    referralCode: Optional[str] = Field(
        default=None, description="User's referral code"
    )
    referralLink: Optional[str] = Field(
        default=None, description="User's referral link"
    )


class ReferralHistoryItem(BaseModel):
    """Model for individual referral history item"""

    referralId: str = Field(..., description="Referral ID")
    referredUserName: str = Field(..., description="Name of the referred user")
    status: str = Field(..., description="Status of the referral")
    revenue: float = Field(..., description="Revenue generated")
    date: datetime = Field(..., description="Date of the referral")


class CompleteReferralRequest(BaseModel):
    """Request model for completing a referral"""

    referralId: str = Field(..., description="ID of the referral to complete")
    revenue: float = Field(..., description="Revenue generated from the referral")


class WebhookCompleteReferralRequest(BaseModel):
    """Request model for completing a referral from webhook"""

    referralId: str = Field(..., description="ID of the referral to complete")
    revenue: float = Field(..., description="Revenue generated from the referral")


class UpdateReferrerHistoryRequest(BaseModel):
    """Request model for updating referrer's history from webhook"""

    referralCode: str = Field(..., description="The referral code that was used")
    customerEmail: str = Field(
        ..., description="Email of the customer who used the referral"
    )
    tier: str = Field(..., description="Subscription tier purchased")
    amount: float = Field(..., description="Amount paid (after discount)")


class FrontendReferralCompletionRequest(BaseModel):
    """Request model for frontend referral completion"""

    referralCode: str = Field(..., description="The referral code that was used")
    customerEmail: str = Field(
        ..., description="Email of the customer who used the referral"
    )
    tier: str = Field(..., description="Subscription tier purchased")
    amount: float = Field(..., description="Amount paid (after discount)")
    stripeCustomerId: Optional[str] = Field(
        default=None, description="Stripe customer ID"
    )


@router.post("/validate-code", response_model=ReferralCodeResponse)
async def validate_referral_code(request: ReferralCodeRequest) -> ReferralCodeResponse:
    """
    Validate a referral code.

    Args:
        request: ReferralCodeRequest containing the referral code to validate

    Returns:
        ReferralCodeResponse with validation result and referrer information
    """
    try:
        logger.info(f"Validating referral code: {request.referralCode}")

        # Validate the referral code
        referrer = await referral_service.validate_referral_code(request.referralCode)

        if not referrer:
            return ReferralCodeResponse(
                isValid=False, message="Invalid or expired referral code"
            )

        return ReferralCodeResponse(
            isValid=True,
            referrerName=referrer.profile.name,
            referrerUsername=referrer.profile.repflow_username,
            message="Valid referral code",
        )

    except Exception as e:
        logger.error(f"Error validating referral code: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while validating referral code",
        )


@router.post("/create", response_model=CreateReferralResponse)
async def create_referral(
    request: CreateReferralRequest, current_user: str = Depends(get_current_user)
) -> CreateReferralResponse:
    """
    Create a referral record when someone uses a referral code.

    Args:
        request: CreateReferralRequest with referral code and optional Stripe customer ID
        current_user: Authenticated user from JWT token

    Returns:
        CreateReferralResponse with creation result
    """
    try:
        logger.info(
            f"Creating referral for user {current_user} with code: {request.referralCode}"
        )

        # Validate the referral code and get referrer
        referrer = await referral_service.validate_referral_code(request.referralCode)

        if not referrer:
            return CreateReferralResponse(
                success=False, message="Invalid or expired referral code"
            )

        # Check if user is trying to refer themselves
        if referrer.uuid == current_user:
            return CreateReferralResponse(
                success=False, message="Cannot use your own referral code"
            )

        # Check if user has already used a referral code
        existing_referral = await Referral.find_one(
            Referral.referralCustomerId == current_user
        )

        if existing_referral:
            return CreateReferralResponse(
                success=False, message="You have already used a referral code"
            )

        # Create referral record
        referral = await referral_service.create_referral_record(
            referrer=referrer,
            referee_user_id=current_user,
            stripe_customer_id=request.stripeCustomerId,
        )

        logger.info(f"Created referral record {referral.referralId}")

        return CreateReferralResponse(
            success=True,
            referralId=referral.referralId,
            message="Referral record created successfully",
        )

    except Exception as e:
        logger.error(f"Error creating referral: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while creating referral",
        )


@router.post("/webhook/create", response_model=CreateReferralResponse)
async def create_referral_webhook(
    request: WebhookCreateReferralRequest,
) -> CreateReferralResponse:
    """
    Create a referral record from webhook (no authentication required).

    Args:
        request: WebhookCreateReferralRequest with referral code and user information

    Returns:
        CreateReferralResponse with creation result
    """
    try:
        logger.info(
            f"Creating referral from webhook for user {request.refereeUserId} with code: {request.referralCode}"
        )

        # Validate the referral code and get referrer
        referrer = await referral_service.validate_referral_code(request.referralCode)

        if not referrer:
            return CreateReferralResponse(
                success=False, message="Invalid or expired referral code"
            )

        # Check if user is trying to refer themselves
        if referrer.uuid == request.refereeUserId:
            return CreateReferralResponse(
                success=False, message="Cannot use your own referral code"
            )

        # Check if user has already used a referral code
        existing_referral = await Referral.find_one(
            Referral.referralCustomerId == request.refereeUserId
        )

        if existing_referral:
            return CreateReferralResponse(
                success=False, message="User has already used a referral code"
            )

        # Create referral record
        referral = await referral_service.create_referral_record(
            referrer=referrer,
            referee_user_id=request.refereeUserId,
            stripe_customer_id=request.stripeCustomerId,
        )

        logger.info(f"Created referral record {referral.referralId} from webhook")

        return CreateReferralResponse(
            success=True,
            referralId=referral.referralId,
            message="Referral record created successfully",
        )

    except Exception as e:
        logger.error(f"Error creating referral from webhook: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while creating referral",
        )


@router.post("/webhook/complete")
async def complete_referral_webhook(
    request: WebhookCompleteReferralRequest,
) -> Dict[str, Any]:
    """
    Complete a referral from webhook (no authentication required).

    Args:
        request: WebhookCompleteReferralRequest with referral ID and revenue

    Returns:
        Dict with completion result
    """
    try:
        logger.info(
            f"Completing referral {request.referralId} from webhook with revenue: ${request.revenue}"
        )

        # Find the referral record
        referral = await Referral.find_one(Referral.referralId == request.referralId)

        if not referral:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Referral not found"
            )

        # Complete the referral
        updated_referral, updated_referrer, updated_referee = (
            await referral_service.complete_referral(referral, request.revenue)
        )

        # Apply referrer discount for next billing cycle
        if updated_referrer:
            await referral_service.apply_referrer_discount(
                updated_referrer,
                datetime.utcnow() + timedelta(days=30),  # Next billing cycle
            )

        logger.info(
            f"Completed referral {request.referralId} from webhook with revenue: ${request.revenue}"
        )

        return {
            "success": True,
            "message": "Referral completed successfully",
            "referralId": updated_referral.referralId,
            "revenue": updated_referral.referralRevenue,
            "referrerReward": updated_referral.referrerReward,
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error completing referral from webhook: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while completing referral",
        )


@router.post("/frontend/complete")
async def complete_referral_frontend(
    request: FrontendReferralCompletionRequest,
) -> Dict[str, Any]:
    """
    Complete a referral from frontend with all processing logic handled on backend.

    Args:
        request: FrontendReferralCompletionRequest with referral details

    Returns:
        Dict with completion result
    """
    try:
        logger.info(
            f"Processing frontend referral completion for code: {request.referralCode}, customer: {request.customerEmail}"
        )

        # Validate the referral code and get referrer
        referrer = await referral_service.validate_referral_code(request.referralCode)

        if not referrer:
            logger.warning(f"No referrer found for code: {request.referralCode}")
            return {"success": False, "message": "Invalid or expired referral code"}

        # Get user ID from email
        referee_user = await User.find_one(User.profile.email == request.customerEmail)
        if not referee_user:
            logger.warning(f"No user found for email: {request.customerEmail}")
            return {"success": False, "message": "User not found"}

        # Check if user is trying to refer themselves
        if referrer.uuid == referee_user.uuid:
            return {"success": False, "message": "Cannot use your own referral code"}

        # Check if user has already used a referral code
        existing_referral = await Referral.find_one(
            Referral.referralCustomerId == referee_user.uuid
        )

        if existing_referral:
            return {
                "success": False,
                "message": "User has already used a referral code",
            }

        # Create referral record
        referral = await referral_service.create_referral_record(
            referrer=referrer,
            referee_user_id=referee_user.uuid,
            stripe_customer_id=request.stripeCustomerId,
        )

        logger.info(f"Created referral record {referral.referralId}")

        # Complete the referral with revenue information
        updated_referral, updated_referrer, updated_referee = (
            await referral_service.complete_referral(referral, request.amount)
        )

        # Apply referrer discount for next billing cycle
        if updated_referrer:
            await referral_service.apply_referrer_discount(
                updated_referrer,
                datetime.utcnow() + timedelta(days=30),  # Next billing cycle
            )

        # Update referrer's history with the successful referral
        if updated_referrer and updated_referrer.referralData:
            # Create new referral history item
            history_item = ReferralHistory(
                id=str(uuid.uuid4()),
                referredUserName=request.customerEmail,
                status="completed",
                revenue=request.amount,
                date=datetime.utcnow(),
            )

            # Add to referrer's history
            updated_referrer.referralData.referralHistory.append(history_item)
            updated_referrer.referralData.totalReferrals += 1
            updated_referrer.referralData.totalRevenue += request.amount
            updated_referrer.referralData.updatedAt = datetime.utcnow()

            # Save the updated referrer
            await updated_referrer.save()

            logger.info(
                f"Updated referrer history for {updated_referrer.uuid}: {len(updated_referrer.referralData.referralHistory)} total referrals"
            )

        logger.info(
            f"Successfully completed referral {referral.referralId} with revenue: ${request.amount}"
        )

        return {
            "success": True,
            "message": "Referral completed successfully",
            "referralId": referral.referralId,
            "revenue": request.amount,
            "referrerReward": (
                updated_referral.referrerReward if updated_referral else 0
            ),
            "totalReferrals": (
                updated_referrer.referralData.totalReferrals
                if updated_referrer and updated_referrer.referralData
                else 0
            ),
            "totalRevenue": (
                updated_referrer.referralData.totalRevenue
                if updated_referrer and updated_referrer.referralData
                else 0
            ),
        }

    except Exception as e:
        logger.error(f"Error processing frontend referral completion: {str(e)}")
        return {
            "success": False,
            "message": f"Error processing referral completion: {str(e)}",
        }


@router.post("/webhook/update-referrer-history")
async def update_referrer_history_webhook(
    request: UpdateReferrerHistoryRequest,
) -> Dict[str, Any]:
    """
    Update referrer's history when someone uses their referral code (no authentication required).

    Args:
        request: UpdateReferrerHistoryRequest with referral details

    Returns:
        Dict with update result
    """
    try:
        logger.info(
            f"Updating referrer history for code: {request.referralCode}, customer: {request.customerEmail}"
        )

        # Find the user who owns this referral code
        referrer = await referral_service.validate_referral_code(request.referralCode)

        if not referrer:
            logger.warning(f"No referrer found for code: {request.referralCode}")
            return {"success": False, "message": "Referral code not found"}

        # Ensure referrer has referral data
        referrer = await referral_service.ensure_user_has_referral_data(referrer)

        if not referrer.referralData:
            logger.error(f"Referrer {referrer.uuid} has no referral data")
            return {"success": False, "message": "Referrer has no referral data"}

        # Create new referral history item
        history_item = ReferralHistory(
            id=str(uuid.uuid4()),
            referredUserName=request.customerEmail,
            status="completed",
            revenue=request.amount,
            date=datetime.utcnow(),
        )

        # Add to referrer's history
        referrer.referralData.referralHistory.append(history_item)
        referrer.referralData.totalReferrals += 1
        referrer.referralData.totalRevenue += request.amount
        referrer.referralData.updatedAt = datetime.utcnow()

        # Save the updated referrer
        await referrer.save()

        logger.info(
            f"Updated referrer history for {referrer.uuid}: {len(referrer.referralData.referralHistory)} total referrals"
        )

        return {
            "success": True,
            "message": "Referrer history updated successfully",
            "referrerId": referrer.uuid,
            "totalReferrals": referrer.referralData.totalReferrals,
            "totalRevenue": referrer.referralData.totalRevenue,
        }

    except Exception as e:
        logger.error(f"Error updating referrer history: {str(e)}")
        return {
            "success": False,
            "message": f"Error updating referrer history: {str(e)}",
        }


@router.get("/test-db")
async def test_database_connection() -> Dict[str, Any]:
    """
    Test database connection and Referral model.

    Returns:
        Dict with test results
    """
    try:
        # Test database connection by counting referrals
        referral_count = await Referral.count()

        # Test creating a simple referral record
        test_referral = Referral(
            referralId="test-referral-123",
            referralCreatorId="test-creator-123",
            referralCustomerId="test-customer-123",
            referralCode="123ABC",  # 6-character alphanumeric test code
            status=ReferralStatus.PENDING,
            stripePromotionCodeId="promo_test123",
        )

        # Try to insert (but don't actually save to avoid test data)
        logger.info("Database connection test successful")

        return {
            "success": True,
            "message": "Database connection successful",
            "referralCount": referral_count,
            "modelTest": "Referral model structure is valid",
        }

    except Exception as e:
        logger.error(f"Database test failed: {str(e)}")
        return {
            "success": False,
            "message": f"Database test failed: {str(e)}",
            "error": str(e),
        }


@router.get("/stats", response_model=ReferralStatsResponse)
async def get_referral_stats(
    userId: Optional[str] = Query(
        None, description="User ID to fetch stats for (admin only)"
    ),
    credentials: JWTAuthorizationCredentials = Depends(auth),
) -> ReferralStatsResponse:
    """
    Get referral statistics for the authenticated user, or for a specific user if admin.

    Args:
        userId: Optional user ID (admin only). If not provided, returns current user's stats.
        credentials: JWT credentials from authentication

    Returns:
        ReferralStatsResponse with referral statistics
    """
    try:
        # Extract current user ID from token
        current_user = None
        if "cognito:username" in credentials.claims:
            current_user = credentials.claims["cognito:username"]
        elif "username" in credentials.claims:
            current_user = credentials.claims["username"]
        elif "sub" in credentials.claims:
            current_user = credentials.claims["sub"]
        elif "email" in credentials.claims:
            current_user = credentials.claims["email"]

        if not current_user:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="User ID not found in token",
            )

        # If requesting another user's data, verify admin access
        if userId and userId != current_user:
            groups = credentials.claims.get("cognito:groups", [])
            if "admin" not in groups:
                logger.warning(
                    f"Non-admin user {current_user} attempted to access referral stats for user {userId}"
                )
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Admin access required to view other users' referral stats",
                )
            target_user = userId
            logger.info(
                f"Admin {current_user} accessing referral stats for user {target_user}"
            )
        else:
            target_user = current_user

        logger.info(f"Getting referral stats for user: {target_user}")

        # Find the user
        user = await User.find_one(User.uuid == target_user)

        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
            )

        # Ensure user has referral data
        user = await referral_service.ensure_user_has_referral_data(user)

        # Get referral stats
        stats = await referral_service.get_referral_stats(user)

        return ReferralStatsResponse(**stats)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting referral stats: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while getting referral stats",
        )


@router.get("/history")
async def get_referral_history(
    userId: Optional[str] = Query(
        None, description="User ID to fetch history for (admin only)"
    ),
    credentials: JWTAuthorizationCredentials = Depends(auth),
) -> List[ReferralHistoryItem]:
    """
    Get referral history for the authenticated user, or for a specific user if admin.

    Args:
        userId: Optional user ID (admin only). If not provided, returns current user's history.
        credentials: JWT credentials from authentication

    Returns:
        List of ReferralHistoryItem with referral history
    """
    try:
        # Extract current user ID from token
        current_user = None
        if "cognito:username" in credentials.claims:
            current_user = credentials.claims["cognito:username"]
        elif "username" in credentials.claims:
            current_user = credentials.claims["username"]
        elif "sub" in credentials.claims:
            current_user = credentials.claims["sub"]
        elif "email" in credentials.claims:
            current_user = credentials.claims["email"]

        if not current_user:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="User ID not found in token",
            )

        # If requesting another user's data, verify admin access
        if userId and userId != current_user:
            groups = credentials.claims.get("cognito:groups", [])
            if "admin" not in groups:
                logger.warning(
                    f"Non-admin user {current_user} attempted to access referral history for user {userId}"
                )
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Admin access required to view other users' referral history",
                )
            target_user = userId
            logger.info(
                f"Admin {current_user} accessing referral history for user {target_user}"
            )
        else:
            target_user = current_user

        logger.info(f"Getting referral history for user: {target_user}")

        # Find the user
        user = await User.find_one(User.uuid == target_user)

        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
            )

        # Ensure user has referral data
        user = await referral_service.ensure_user_has_referral_data(user)

        if not user.referralData or not user.referralData.referralHistory:
            return []

        # Convert referral history to response format
        history = []
        for item in user.referralData.referralHistory:
            history.append(
                ReferralHistoryItem(
                    referralId=item.id,
                    referredUserName=item.referredUserName,
                    status=item.status,
                    revenue=item.revenue,
                    date=item.date,
                )
            )

        return history

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting referral history: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while getting referral history",
        )


@router.post("/complete")
async def complete_referral(
    request: CompleteReferralRequest, current_user: str = Depends(get_current_user)
) -> Dict[str, Any]:
    """
    Complete a referral when payment is made.

    Args:
        request: CompleteReferralRequest with referral ID and revenue
        current_user: Authenticated user from JWT token

    Returns:
        Dict with completion result
    """
    try:
        logger.info(
            f"Completing referral {request.referralId} for user: {current_user}"
        )

        # Find the referral record
        referral = await Referral.find_one(Referral.referralId == request.referralId)

        if not referral:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Referral not found"
            )

        # Verify the referral belongs to the current user
        if referral.referralCustomerId != current_user:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You are not authorized to complete this referral",
            )

        # Complete the referral
        updated_referral, updated_referrer, updated_referee = (
            await referral_service.complete_referral(referral, request.revenue)
        )

        # Apply referrer discount for next billing cycle
        if updated_referrer:
            await referral_service.apply_referrer_discount(
                updated_referrer,
                datetime.utcnow() + timedelta(days=30),  # Next billing cycle
            )

        logger.info(
            f"Completed referral {request.referralId} with revenue: ${request.revenue}"
        )

        return {
            "success": True,
            "message": "Referral completed successfully",
            "referralId": updated_referral.referralId,
            "revenue": updated_referral.referralRevenue,
            "referrerReward": updated_referral.referrerReward,
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error completing referral: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while completing referral",
        )


@router.post("/generate")
async def generate_referral_code(
    current_user: str = Depends(get_current_user),
) -> Dict[str, Any]:
    """
    Generate (regenerate) a new referral code for the authenticated user.

    Args:
        current_user: Authenticated user from JWT token

    Returns:
        Dict with new referral code and link
    """
    try:
        logger.info(f"Generating new referral code for user: {current_user}")

        # Find the user
        user = await User.find_one(User.uuid == current_user)

        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
            )

        # Regenerate referral code
        updated_user = await referral_service.regenerate_referral_code(user)

        if not updated_user.referralData:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to generate referral code",
            )

        return {
            "success": True,
            "message": "Referral code generated successfully",
            "referralCode": updated_user.referralData.referralCode,
            "referralLink": str(updated_user.referralData.referralLink),
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error generating referral code: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Internal server error while generating referral code: {str(e)}",
        )


@router.post("/setup")
async def setup_referral_program(
    current_user: str = Depends(get_current_user),
) -> Dict[str, Any]:
    """
    Set up referral program for the authenticated user.

    Args:
        current_user: Authenticated user from JWT token

    Returns:
        Dict with setup result
    """
    try:
        logger.info(f"Setting up referral program for user: {current_user}")

        # Find the user
        user = await User.find_one(User.uuid == current_user)

        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
            )

        # Ensure referral program is set up (will create if doesn't exist)
        updated_user = await referral_service.ensure_user_has_referral_data(user)

        return {
            "success": True,
            "message": "Referral program set up successfully",
            "referralCode": updated_user.referralData.referralCode,
            "referralLink": str(updated_user.referralData.referralLink),
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error setting up referral program: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while setting up referral program",
        )
