from fastapi import APIRouter, HTTPException, status, Depends, Request, Query
from pymongo.errors import DuplicateKeyError
from .utils import (
    register_crud_from_model,
    get_current_user,
    require_user_or_service_permission,
    AuthContext,
    is_user_auth,
    get_user_id,
    is_admin_user,
    auth,
)
from auth.JWTBearer import JWTAuthorizationCredentials
from database.models.user import (
    User,
    UserPreferences,
    Deliverable,
    UserProfile,
    Platform,
    PlatformType,
    PlatformMetrics,
    BillingInfo,
    Subscription,
    YouTubeAnalytics,
    InstagramAnalytics,
)
from services.youtube_analytics_service_legacy import youtube_analytics_service
from services.instagram_analytics_service import instagram_analytics_service, InstagramReconnectionRequired
from services.instagram_oauth_service import instagram_oauth_service
from datetime import datetime
from pydantic import BaseModel, Field, HttpUrl
from typing import List, Optional, Dict, Any
import logging

# Configure logger for this module
logger = logging.getLogger("uvicorn.error")
router = APIRouter(prefix="/users", tags=["users"])



class UserEmailRequest(BaseModel):
    """Request model for user email lookup"""
    email: str


class UserIdResponse(BaseModel):
    """Response model for user ID lookup"""
    userId: str
    email: str
    name: str
    repflow_username: str

class UserUsernameRequest(BaseModel):
    """Request model for user repflow username lookup"""

    repflow_username: str


class PaymentMethodUpdateRequest(BaseModel):
    """Request model for updating user payment method and billing info"""
    
    billingInfo: BillingInfo = Field(..., description="Updated billing information including card details and address")
    paymentMethodId: str = Field(..., description="Payment method ID from payment processor (e.g., Stripe payment method ID)")
    
    class Config:
        json_schema_extra = {
            "example": {
                "billingInfo": {
                    "cardLast4": "4242",
                    "cardBrand": "visa",
                    "nextBillingDate": "2024-02-15T00:00:00Z",
                    "expirationMonth": 12,
                    "expirationYear": 2025,
                    "billingEmail": "billing@example.com",
                    "billingAddress": {
                        "line1": "123 Main Street",
                        "line2": "Apt 4B",
                        "city": "New York",
                        "state": "NY",
                        "postalCode": "10001",
                        "country": "United States"
                    }
                },
                "paymentMethodId": "pm_1234567890abcdef"
            }
        }


class SubscriptionUpdateRequest(BaseModel):
    """Request model for updating user subscription"""
    
    subscription: Subscription = Field(..., description="Updated subscription information")
    
    class Config:
        json_schema_extra = {
            "example": {
                "subscription": {
                    "tier": "Premium",
                    "status": "active",
                    "currentPeriodEnd": "2024-03-15T00:00:00Z"
                }
            }
        }


@router.post("/")
async def create(item: User) -> User:
    logger.info(f"Creating {User.__name__} for user: {item.uuid}")
    try:
        existing = await User.find_one(User.profile.email == item.profile.email)
    except Exception as e:
        logger.exception(
            "User existence check failed for email %s: %s", item.profile.email, e
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"Database error while checking user: {e!s}",
        ) from e

    # Idempotent: if the same user retries onboarding, update instead of rejecting.
    # This handles cases where the first "Complete Setup" created the user but
    # the subsequent sign-in failed, leaving the user on the onboarding page.
    if existing:
        if existing.uuid == item.uuid:
            logger.info(f"User {item.profile.email} already exists with same uuid, updating profile")
            existing.profile = item.profile
            existing.preferences = item.preferences
            existing.billingInfo = item.billingInfo
            existing.isActive = item.isActive
            existing.isVerified = item.isVerified
            existing.updatedAt = item.updatedAt
            try:
                await existing.save()
            except Exception as e:
                logger.exception("User update failed for %s: %s", item.uuid, e)
                raise HTTPException(
                    status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                    detail=f"Database error while updating user: {e!s}",
                ) from e
            logger.info(f"Updated existing {User.__name__} for user: {item.uuid}")
            return existing
        logger.warning(f"User already exists with different uuid: {item.profile.email}")
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="User already exists")

    # Create the user (surface DB errors — generic handler would hide the real cause)
    try:
        created_user = await item.insert()
    except DuplicateKeyError as e:
        logger.warning("Duplicate key creating user %s: %s", item.uuid, e)
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="A user with this id or email already exists",
        ) from e
    except Exception as e:
        logger.exception("User insert failed for %s: %s", item.uuid, e)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"Database error while creating user: {e!s}",
        ) from e

    # Set up referral program for the new user
    try:
        from services.referral_service import referral_service
        created_user = await referral_service.setup_user_referral_program(created_user)
        logger.info(f"Set up referral program for new user: {created_user.uuid}")
    except Exception as e:
        logger.error(f"Failed to set up referral program for user {created_user.uuid}: {str(e)}")
        # Don't fail user creation if referral setup fails

    logger.info(f"Created {User.__name__} for user: {item.uuid}")
    return created_user


@router.post("/by-email")
async def get_user_id_by_email(
    request: UserEmailRequest
) -> UserIdResponse:
    """
    Get user ID by email address.
    
    Args:
        request: UserEmailRequest containing the email address to look up
        current_user: Authenticated user from JWT token
    
    Returns:
        UserIdResponse containing userId, email, and name
        
    Raises:
        HTTPException: If user not found or not authorized
    """
    try:        
        # Extract email from request body
        email = request.email
        
        # Convert email from byte string to decoded string if needed
        if isinstance(email, bytes):
            try:
                email = email.decode('utf-8')
            except UnicodeDecodeError:
                # Try other common encodings if UTF-8 fails
                try:
                    email = email.decode('latin-1')
                except UnicodeDecodeError:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="Invalid email encoding"
                    )
        
        logger.info(f"🔍 Looking up user by email: {email}")
        
        # Find the user by email
        user = await User.find_one(User.profile.email == email)
        
        if not user:
            logger.warning(f"❌ User not found for email: {email}")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"User with email {email} not found"
            )
        
        logger.info(f"✅ Found user: {user.profile.name} (ID: {user.uuid})")
        
        return UserIdResponse(
            userId=user.uuid,
            email=user.profile.email,
            name=user.profile.name,
            repflow_username=user.profile.repflow_username
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error retrieving user: {str(e)}"
        )


@router.get("/")
async def get_by_id(current_user: str = Depends(get_current_user)) -> User | None:
    # Only return item if it belongs to the current user
    print(f"Getting {User.__name__} for user: {current_user}")
    user = await User.find_one(User.uuid == current_user)
    
    # Ensure user has referral data - automatically initialize if missing
    if user and (not user.referralData or not user.referralData.isActive):
        try:
            from services.referral_service import referral_service
            user = await referral_service.ensure_user_has_referral_data(user)
            logger.info(f"Initialized referral data for user: {current_user}")
        except Exception as e:
            logger.error(f"Failed to initialize referral data for user {current_user}: {str(e)}")
            # Don't fail the request if referral setup fails
    
    return user


@router.get("/all")
async def get_all_users() -> List[User]:
    """
    Get all users and their data without requiring authentication.
    
    Returns:
        List of all users with their complete data
    """
    try:
        logger.info("Fetching all users")
        users = await User.find_all().to_list()
        logger.info(f"Successfully retrieved {len(users)} users")
        return users
    except Exception as e:
        logger.error(f"Error retrieving all users: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while retrieving users"
        )


@router.get("/{user_id}/public")
async def get_public_user_by_id(user_id: str) -> User | None:
    # Only return item if it belongs to the current user
    print(f"Getting {User.__name__} for user: {user_id}")
    return await User.find_one(User.uuid == user_id)


@router.post("/by-repflow-username")
async def get_user_by_repflow_username(
    request: UserUsernameRequest,
    auth_context: AuthContext = Depends(
        require_user_or_service_permission("users:read_by_username")
    ),
) -> User:
    """
    Get user ID by repflow username.

    Args:
        request: UserUsernameRequest containing the repflow_username to look up
        current_user: Authenticated user from JWT token

    Returns:
        Full User model containing all fields

    Raises:
        HTTPException: If user not found or not authorized
    """
    try:
        import re
        from bson.regex import Regex
        
        username = request.repflow_username.strip()
        logger.info(f"🔍 Looking up user by repflow_username: '{username}'")
        
        # Use bson.regex.Regex with explicit 'i' flag for case-insensitive matching
        # Python's re.IGNORECASE doesn't reliably translate to MongoDB's $options across PyMongo versions
        pattern = Regex(f"^{re.escape(username)}$", "i")
        user = await User.find_one(User.profile.repflow_username == pattern)

        if not user:
            logger.warning(
                f"❌ User not found for repflow username: '{request.repflow_username}'"
            )
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"User with repflow username '{request.repflow_username}' not found",
            )

        logger.info(f"✅ Found user: {user.profile.name} (UUID: {user.uuid}, DB Username: {user.profile.repflow_username})")

        return user

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error retrieving user: {str(e)}",
        )


@router.put("/preferences")
async def update_user_preferences(
    preferences: UserPreferences, current_user: str = Depends(get_current_user)
) -> User:
    """
    Update user preferences for a specific user.

    Args:
        user_uuid: The UUID of the user whose preferences to update
        preferences: The new UserPreferences object

    Returns:
        The updated User object

    Raises:
        HTTPException: If user not found, access denied, or validation fails
    """
    try:
        # Find the user by UUID
        user = await User.find_one(User.uuid == current_user)

        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
            )

        # For now, allow any authenticated user to update preferences
        # In a production system, you might want to add additional authorization checks
        # such as checking if current_user == user_uuid or if current_user has admin privileges

        # Update the preferences
        user.preferences = preferences

        # Update the timestamp
        user.updatedAt = datetime.utcnow()

        # Save the updated user
        updated_user = await user.save()

        return updated_user

    except HTTPException:
        # Re-raise HTTP exceptions
        raise
    except Exception as e:
        # Log the error and return a generic error message
        print(f"Error updating user preferences: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while updating preferences",
        )


@router.get("/preferences")
async def get_user_preferences(
    auth_context: AuthContext = Depends(
        require_user_or_service_permission("users:read_preferences")
    ),
) -> UserPreferences:
    """
    Get user preferences for the authenticated user.

    Args:
        current_user: The authenticated user from JWT token

    Returns:
        The UserPreferences object

    Raises:
        HTTPException: If user not found or access denied
    """
    try:
        # Handle different auth contexts
        if is_user_auth(auth_context):
            # User authentication - get preferences for authenticated user
            current_user = get_user_id(auth_context)
            user = await User.find_one(User.uuid == current_user)
        else:
            # Service account - this endpoint requires a user_id parameter for service accounts
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Service accounts must use /users/{user_id}/preferences endpoint",
            )

        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
            )

        # Return the user preferences
        return user.preferences

    except HTTPException:
        # Re-raise HTTP exceptions
        raise
    except Exception as e:
        # Log the error and return a generic error message
        print(f"Error retrieving user preferences: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while retrieving preferences",
        )


@router.patch("/preferences/deliverables")
async def update_user_deliverables(
    deliverables: list[Deliverable], current_user: str = Depends(get_current_user)
) -> User:
    """
    Update only the deliverables part of user preferences for the authenticated user.

    Args:
        deliverables: List of new deliverables
        current_user: The authenticated user from JWT token

    Returns:
        The updated User object

    Raises:
        HTTPException: If user not found, access denied, or validation fails
    """
    try:
        # Find the user by UUID from token
        user = await User.find_one(User.uuid == current_user)

        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
            )

        # Update only the deliverables
        user.preferences.deliverables = deliverables

        # Update the timestamp
        user.updatedAt = datetime.utcnow()

        # Save the updated user
        updated_user = await user.save()

        return updated_user

    except HTTPException:
        # Re-raise HTTP exceptions
        raise
    except Exception as e:
        # Log the error and return a generic error message
        print(f"Error updating user deliverables: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while updating deliverables",
        )


@router.patch("/preferences/partnership")
async def update_user_partnership_preferences(
    partnership_preferences: dict, current_user: str = Depends(get_current_user)
) -> User:
    """
    Update only the partnership preferences part of user preferences for the authenticated user.

    Args:
        partnership_preferences: Dictionary containing partnership preference updates
        current_user: The authenticated user from JWT token

    Returns:
        The updated User object

    Raises:
        HTTPException: If user not found, access denied, or validation fails
    """
    try:
        # Find the user by UUID from token
        user = await User.find_one(User.uuid == current_user)

        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
            )

        # Update partnership preferences fields
        for key, value in partnership_preferences.items():
            if hasattr(user.preferences.partnershipTypes, key):
                setattr(user.preferences.partnershipTypes, key, value)

        # Update the timestamp
        user.updatedAt = datetime.utcnow()

        # Save the updated user
        updated_user = await user.save()

        return updated_user

    except HTTPException:
        # Re-raise HTTP exceptions
        raise
    except Exception as e:
        # Log the error and return a generic error message
        print(f"Error updating partnership preferences: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while updating partnership preferences",
        )


@router.patch("/preferences/notifications")
async def update_user_notification_preferences(
    notification_preferences: dict, current_user: str = Depends(get_current_user)
) -> User:
    """
    Update only the notification preferences part of user preferences for the authenticated user.

    Args:
        notification_preferences: Dictionary containing notification preference updates
        current_user: The authenticated user from JWT token

    Returns:
        The updated User object

    Raises:
        HTTPException: If user not found, access denied, or validation fails
    """
    try:
        # Find the user by UUID from token
        user = await User.find_one(User.uuid == current_user)

        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
            )

        # Update notification preferences fields
        for key, value in notification_preferences.items():
            if hasattr(user.preferences, key):
                setattr(user.preferences, key, value)

        # Update the timestamp
        user.updatedAt = datetime.utcnow()

        # Save the updated user
        updated_user = await user.save()

        return updated_user

    except HTTPException:
        # Re-raise HTTP exceptions
        raise
    except Exception as e:
        # Log the error and return a generic error message
        print(f"Error updating notification preferences: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while updating notification preferences",
        )


@router.put("/profile")
async def update_user_profile(
    profile: UserProfile, current_user: str = Depends(get_current_user)
) -> User:
    """
    Update user profile for the authenticated user.

    Args:
        profile: The new UserProfile object with updated information
        current_user: The authenticated user from JWT token

    Returns:
        The updated User object

    Raises:
        HTTPException: If user not found, access denied, or validation fails
    """
    try:
        # Find the user by UUID from token
        user = await User.find_one(User.uuid == current_user)

        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
            )

        # Update the profile
        user.profile = profile
        user.updatedAt = datetime.utcnow()

        # Save the updated user
        await user.save()

        logger.info(f"✅ Updated profile for user: {current_user}")
        return user

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating user profile: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while updating user profile",
        )


@router.get("/profile")
async def get_user_profile(
    current_user: str = Depends(get_current_user),
) -> UserProfile:
    """
    Get user profile for the authenticated user.

    Args:
        current_user: The authenticated user from JWT token

    Returns:
        The UserProfile object

    Raises:
        HTTPException: If user not found or access denied
    """
    try:
        # Find the user by UUID from token
        user = await User.find_one(User.uuid == current_user)

        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
            )

        logger.info(f"✅ Retrieved profile for user: {current_user}")
        return user.profile

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error retrieving user profile: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while retrieving user profile",
        )


class BookingLinkUpdateRequest(BaseModel):
    """Request model for updating booking link"""
    bookingLink: Optional[HttpUrl] = Field(default=None, description="Calendly or other booking link URL")


@router.patch("/profile/booking-link")
async def update_booking_link(
    booking_link_update: BookingLinkUpdateRequest,
    current_user: str = Depends(get_current_user),
) -> UserProfile:
    """
    Update user's booking link (Calendly or other booking service).
    
    This link is automatically included in AI agent email responses when
    sponsorship prospects ask to book or schedule a call.
    
    Args:
        booking_link_update: BookingLinkUpdateRequest containing the booking link URL
        current_user: The authenticated user from JWT token
    
    Returns:
        The updated UserProfile object
        
    Raises:
        HTTPException: If user not found, access denied, or validation fails
    """
    try:
        # Find the user by UUID from token
        user = await User.find_one(User.uuid == current_user)
        
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
            )
        
        # Update only the booking link
        user.profile.bookingLink = booking_link_update.bookingLink
        user.updatedAt = datetime.utcnow()
        
        # Save the updated user
        await user.save()
        
        logger.info(f"✅ Updated booking link for user: {current_user}")
        return user.profile
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating booking link: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while updating booking link",
        )


@router.patch("/update-billing")
async def update_payment_method(
    payment_update: PaymentMethodUpdateRequest,
    current_user: str = Depends(get_current_user),
) -> User:
    """
    Update user's payment method and billing information.
    
    Args:
        payment_update: PaymentMethodUpdateRequest containing billing info and payment method ID
        current_user: The authenticated user from JWT token
    
    Returns:
        The updated User object
        
    Raises:
        HTTPException: If user not found, access denied, or validation fails
    """
    try:
        # Find the user by UUID from token
        user = await User.find_one(User.uuid == current_user)
        
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
            )
        
        # Update the billing info with the payment method ID
        updated_billing_info = payment_update.billingInfo
        updated_billing_info.paymentMethodId = payment_update.paymentMethodId
        
        # Update the user's billing information
        user.billingInfo = updated_billing_info
        user.updatedAt = datetime.utcnow()
        
        # Save the updated user
        await user.save()
        
        logger.info(f"✅ Updated payment method for user: {current_user}")
        return user
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating payment method: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while updating payment method",
        )


@router.get("/billing-info")
async def get_billing_info(
    request: Request,
    userId: Optional[str] = Query(None, description="User ID for admin access"),
    current_user: str = Depends(get_current_user),
    credentials: JWTAuthorizationCredentials = Depends(auth),
) -> BillingInfo:
    """
    Get user's current billing information.
    
    Supports admin access: if userId is provided and the current user is an admin,
    returns billing info for the specified user.
    
    Args:
        request: FastAPI request object
        userId: Optional user ID for admin access
        current_user: The authenticated user from JWT token
        credentials: JWT credentials for admin check
    
    Returns:
        The user's BillingInfo object
        
    Raises:
        HTTPException: If user not found, no billing info exists, or admin access denied
    """
    try:
        # Determine which user's billing info to retrieve
        target_user_id = current_user
        
        # If userId is provided, check if current user is admin
        if userId:
            if not is_admin_user(credentials):
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Admin access required to view other users' billing information"
                )
            target_user_id = userId
            logger.info(f"Admin {current_user} accessing billing info for user: {userId}")
        
        # Find the user by UUID
        user = await User.find_one(User.uuid == target_user_id)
        
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
            )
        
        if not user.billingInfo:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, 
                detail="No billing information found for user"
            )
        
        logger.info(f"✅ Retrieved billing info for user: {target_user_id}")
        return user.billingInfo
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error retrieving billing info: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while retrieving billing information",
        )


@router.patch("/update-subscription")
async def update_subscription(
    subscription_update: SubscriptionUpdateRequest,
    current_user: str = Depends(get_current_user),
) -> User:
    """
    Update user's subscription information.
    
    Args:
        subscription_update: SubscriptionUpdateRequest containing updated subscription details
        current_user: The authenticated user from JWT token
    
    Returns:
        The updated User object
        
    Raises:
        HTTPException: If user not found, access denied, or validation fails
    """
    try:
        # Find the user by UUID from token
        user = await User.find_one(User.uuid == current_user)
        
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
            )
        
        # Update the user's subscription
        user.profile.subscription = subscription_update.subscription
        user.updatedAt = datetime.utcnow()
        
        # Save the updated user
        await user.save()
        
        logger.info(f"✅ Updated subscription for user: {current_user} to tier: {subscription_update.subscription.tier}")
        return user
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating subscription: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while updating subscription",
        )


@router.get("/subscription")
async def get_subscription(
    request: Request,
    userId: Optional[str] = Query(None, description="User ID for admin access"),
    current_user: str = Depends(get_current_user),
    credentials: JWTAuthorizationCredentials = Depends(auth),
) -> Subscription:
    """
    Get user's current subscription information.
    
    Supports admin access: if userId is provided and the current user is an admin,
    returns subscription info for the specified user.
    
    Args:
        request: FastAPI request object
        userId: Optional user ID for admin access
        current_user: The authenticated user from JWT token
        credentials: JWT credentials for admin check
    
    Returns:
        The user's Subscription object
        
    Raises:
        HTTPException: If user not found, no subscription exists, or admin access denied
    """
    try:
        # Determine which user's subscription to retrieve
        target_user_id = current_user
        
        # If userId is provided, check if current user is admin
        if userId:
            if not is_admin_user(credentials):
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Admin access required to view other users' subscription information"
                )
            target_user_id = userId
            logger.info(f"Admin {current_user} accessing subscription for user: {userId}")
        
        # Find the user by UUID
        user = await User.find_one(User.uuid == target_user_id)
        
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
            )
        
        if not user.profile.subscription:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, 
                detail="No subscription information found for user"
            )
        
        logger.info(f"✅ Retrieved subscription for user: {target_user_id}")
        return user.profile.subscription
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error retrieving subscription: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while retrieving subscription information",
        )


# Platform Management Routes


@router.get("/platforms")
async def get_user_platforms(
    current_user: str = Depends(get_current_user),
) -> List[Platform]:
    """
    Get all platforms for the authenticated user.

    Args:
        current_user: The authenticated user from JWT token

    Returns:
        List of user's platforms

    Raises:
        HTTPException: If user not found or access denied
    """
    try:
        # Find the user by UUID from token
        user = await User.find_one(User.uuid == current_user)

        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
            )

        logger.info(
            f"✅ Retrieved {len(user.platforms)} platforms for user: {current_user}"
        )
        return user.platforms

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error retrieving user platforms: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while retrieving user platforms",
        )


@router.post("/platforms")
async def add_user_platform(
    platform: Platform, current_user: str = Depends(get_current_user)
) -> User:
    """
    Add a new platform to the authenticated user or update existing platform.

    If a platform with the same handle and platform type already exists,
    it will be updated with the new data. Otherwise, a new platform will be added.

    Args:
        platform: The platform data to add or update
        current_user: The authenticated user from JWT token

    Returns:
        Updated user object with new or updated platform

    Raises:
        HTTPException: If user not found or validation fails
    """
    try:
        # Find the user by UUID from token
        user = await User.find_one(User.uuid == current_user)

        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
            )

        # Check if platform with same handle already exists
        existing_platform_index = None
        for i, p in enumerate(user.platforms):
            if p.handle == platform.handle and p.platformType == platform.platformType:
                existing_platform_index = i
                break

        if existing_platform_index is not None:
            # Update existing platform
            user.platforms[existing_platform_index] = platform
            user.updatedAt = datetime.utcnow()
            await user.save()
            
            logger.info(f"✅ Updated platform '{platform.name}' for user: {current_user}")
            return user
        else:
            # Add the new platform
            logger.info(f"Adding new platform: {platform}")
            user.platforms.append(platform)
            user.updatedAt = datetime.utcnow()
            await user.save()

            logger.info(f"✅ Added platform '{platform.name}' for user: {current_user}")
            return user

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error adding user platform: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while adding user platform",
        )


@router.put("/platforms/{platform_handle}")
async def update_user_platform(
    platform_handle: str,
    platform: Platform,
    current_user: str = Depends(get_current_user),
) -> User:
    """
    Update an existing platform for the authenticated user.

    Args:
        platform_handle: The handle of the platform to update
        platform: The updated platform data
        current_user: The authenticated user from JWT token

    Returns:
        Updated user object

    Raises:
        HTTPException: If user not found, platform not found, or validation fails
    """
    try:
        # Find the user by UUID from token
        user = await User.find_one(User.uuid == current_user)

        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
            )

        # Find the platform to update
        platform_index = next(
            (i for i, p in enumerate(user.platforms) if p.handle == platform_handle),
            None,
        )

        if platform_index is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Platform with handle '{platform_handle}' not found",
            )

        # Update the platform
        user.platforms[platform_index] = platform
        user.updatedAt = datetime.utcnow()

        # Save the updated user
        await user.save()

        logger.info(f"✅ Updated platform '{platform.name}' for user: {current_user}")
        return user

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating user platform: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while updating user platform",
        )


@router.delete("/platforms/{platform_handle}")
async def delete_user_platform(
    platform_handle: str, current_user: str = Depends(get_current_user)
) -> User:
    """
    Delete a platform from the authenticated user.

    Args:
        platform_handle: The handle of the platform to delete
        current_user: The authenticated user from JWT token

    Returns:
        Updated user object without the deleted platform

    Raises:
        HTTPException: If user not found or platform not found
    """
    try:
        # Find the user by UUID from token
        user = await User.find_one(User.uuid == current_user)

        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
            )

        # Find the platform to delete
        platform_index = next(
            (i for i, p in enumerate(user.platforms) if p.handle == platform_handle),
            None,
        )

        if platform_index is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Platform with handle '{platform_handle}' not found",
            )

        # Remove the platform
        deleted_platform = user.platforms.pop(platform_index)
        user.updatedAt = datetime.utcnow()

        # Save the updated user
        await user.save()

        logger.info(
            f"✅ Deleted platform '{deleted_platform.name}' for user: {current_user}"
        )
        return user

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting user platform: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while deleting user platform",
        )


@router.patch("/platforms/{platform_handle}/metrics")
async def update_platform_metrics(
    platform_handle: str,
    metrics: PlatformMetrics,
    current_user: str = Depends(get_current_user),
) -> User:
    """
    Update metrics for a specific platform.

    Args:
        platform_handle: The handle of the platform to update
        metrics: The updated metrics data
        current_user: The authenticated user from JWT token

    Returns:
        Updated user object

    Raises:
        HTTPException: If user not found or platform not found
    """
    try:
        # Find the user by UUID from token
        user = await User.find_one(User.uuid == current_user)

        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
            )

        # Find the platform to update
        platform_index = next(
            (i for i, p in enumerate(user.platforms) if p.handle == platform_handle),
            None,
        )

        if platform_index is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Platform with handle '{platform_handle}' not found",
            )

        # Update the platform metrics
        user.platforms[platform_index].metrics = metrics
        user.platforms[platform_index].lastUpdated = datetime.utcnow()
        user.updatedAt = datetime.utcnow()

        # Save the updated user
        await user.save()

        logger.info(
            f"✅ Updated metrics for platform '{platform_handle}' for user: {current_user}"
        )
        return user

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating platform metrics: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while updating platform metrics",
        )


class YouTubeAnalyticsRequest(BaseModel):
    """Request model for fetching YouTube analytics"""
    channelId: Optional[str] = Field(None, description="YouTube channel ID (optional)")
    include_demographics: bool = Field(default=False, description="Whether to include demographic data (requires OAuth)")
    oauth_credentials: Optional[Dict[str, Any]] = Field(None, description="OAuth credentials for accessing private analytics data")


class YouTubeAnalyticsResponse(BaseModel):
    """Response model for YouTube analytics"""
    success: bool = Field(..., description="Whether the fetch was successful")
    message: str = Field(..., description="Status message")
    analytics: Optional[YouTubeAnalytics] = Field(None, description="YouTube analytics data")
    channelId: Optional[str] = Field(None, description="Channel ID that was processed")


@router.post("/youtube-analytics", response_model=YouTubeAnalyticsResponse)
async def fetch_youtube_analytics(
    request: YouTubeAnalyticsRequest,
    current_user: str = Depends(get_current_user)
) -> YouTubeAnalyticsResponse:
    """
    Fetch YouTube analytics for a specific channel or user's YouTube platform.
    
    If channelId is provided, fetch analytics for that specific channel.
    If not provided, use the authenticated user's YouTube platform handle.
    
    Args:
        request: YouTube analytics request with optional channelId
        current_user: The authenticated user from JWT token
        
    Returns:
        Response with YouTube analytics data
    """
    try:
        logger.info(f"Fetching YouTube analytics for user: {current_user}")
        
        # Find the user
        user = await User.find_one(User.uuid == current_user)
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found"
            )
        
        channel_handle = None
        channel_id = request.channelId
        
        # If no channelId provided, get it from user's YouTube platform
        if not channel_id:
            if not user.platforms:
                return YouTubeAnalyticsResponse(
                    success=False,
                    message="User has no platforms configured",
                    analytics=None,
                    channelId=None
                )
            
            # Find YouTube platform
            youtube_platform = None
            for platform in user.platforms:
                if (hasattr(platform, 'platformType') and 
                    platform.platformType == PlatformType.YOUTUBE and 
                    hasattr(platform, 'isActive') and 
                    platform.isActive):
                    youtube_platform = platform
                    break
            
            if not youtube_platform:
                return YouTubeAnalyticsResponse(
                    success=False,
                    message="User has no active YouTube platforms",
                    analytics=None,
                    channelId=None
                )
            
            channel_handle = youtube_platform.handle
            logger.info(f"Using YouTube platform handle: {channel_handle}")
        
        # Prepare OAuth credentials - try stored tokens first, then provided tokens
        credentials = None
        
        # First, try to get OAuth credentials from user's YouTube platform
        if not channel_id and user.platforms:
            youtube_platform = None
            for platform in user.platforms:
                if (hasattr(platform, 'platformType') and 
                    platform.platformType == PlatformType.YOUTUBE and 
                    hasattr(platform, 'isActive') and 
                    platform.isActive):
                    youtube_platform = platform
                    break
            
            if youtube_platform and hasattr(youtube_platform, 'customFields') and youtube_platform.customFields:
                stored_tokens = youtube_platform.customFields.get('oauth_tokens')
                if stored_tokens:
                    try:
                        credentials = youtube_analytics_service.create_credentials_from_tokens(stored_tokens)
                        logger.info("🔑 Using stored OAuth credentials from user's YouTube platform")
                    except Exception as e:
                        logger.warning(f"Failed to create credentials from stored OAuth data: {e}")
        
        # If no stored credentials, try provided credentials
        if not credentials and request.oauth_credentials:
            try:
                credentials = youtube_analytics_service.create_credentials_from_tokens(request.oauth_credentials)
                logger.info("🔑 Using provided OAuth credentials for YouTube analytics")
            except Exception as e:
                logger.warning(f"Failed to create credentials from provided OAuth data: {e}")
                return YouTubeAnalyticsResponse(
                    success=False,
                    message="Invalid OAuth credentials provided",
                    analytics=None,
                    channelId=channel_id or channel_handle
                )
        
        # Check if demographics are requested but no credentials provided
        if request.include_demographics and not credentials:
            logger.warning("Demographics requested but no OAuth credentials available")
            return YouTubeAnalyticsResponse(
                success=False,
                message="OAuth credentials required for demographic data. Please authenticate your YouTube account first.",
                analytics=None,
                channelId=channel_id or channel_handle
            )
        
        # Check if credentials are available
        if not credentials:
            logger.warning("No OAuth credentials available")
            return YouTubeAnalyticsResponse(
                success=False,
                message="OAuth credentials required for YouTube analytics. Please authenticate your YouTube account first.",
                analytics=None,
                channelId=channel_id or channel_handle
            )
        
        # Fetch analytics using credentials
        analytics = await youtube_analytics_service.get_channel_analytics(
            credentials=credentials,
            include_demographics=request.include_demographics
        )
        processed_channel_id = analytics.channelId if analytics else None
        
        if analytics:
            logger.info(f"Successfully fetched YouTube analytics for channel: {processed_channel_id}")
            
            # Store analytics in user's platform if we have a YouTube platform
            if not channel_id and user.platforms:
                # Find and update the YouTube platform
                for i, platform in enumerate(user.platforms):
                    if (hasattr(platform, 'platformType') and 
                        platform.platformType == PlatformType.YOUTUBE and 
                        hasattr(platform, 'isActive') and 
                        platform.isActive):
                        
                        # Update platform with analytics data
                        user.platforms[i].youtubeAnalytics = analytics
                        user.platforms[i].lastUpdated = datetime.utcnow()
                        
                        # Update metrics if available
                        # if not user.platforms[i].metrics:
                        #     user.platforms[i].metrics = PlatformMetrics()
                        
                        # if analytics.subscriberCount:
                        #     user.platforms[i].metrics.subscribers = str(analytics.subscriberCount)
                        # if analytics.viewCount:
                        #     user.platforms[i].metrics.totalViews = str(analytics.viewCount)
                        # if analytics.videoCount:
                        #     user.platforms[i].metrics.totalPosts = str(analytics.videoCount)
                        
                        # Update custom fields with YouTube-specific data
                        if not user.platforms[i].customFields:
                            user.platforms[i].customFields = {}
                        
                        # Store YouTube-specific analytics data in custom fields
                        if analytics.channelId:
                            user.platforms[i].customFields["channelId"] = analytics.channelId
                        if analytics.topVideoTitle:
                            user.platforms[i].customFields["topVideoTitle"] = analytics.topVideoTitle
                        if analytics.topVideoViews:
                            user.platforms[i].customFields["topVideoViews"] = analytics.topVideoViews
                        if analytics.estimatedRevenue:
                            user.platforms[i].customFields["estimatedRevenue"] = analytics.estimatedRevenue
                        
                        break
                
                # Save the updated user
                user.updatedAt = datetime.utcnow()
                await user.save()
                logger.info(f"Updated YouTube platform with analytics for user: {current_user}")
            
            return YouTubeAnalyticsResponse(
                success=True,
                message="YouTube analytics fetched successfully",
                analytics=analytics,
                channelId=processed_channel_id
            )
        else:
            logger.warning(f"Failed to fetch YouTube analytics for channel: {processed_channel_id}")
            return YouTubeAnalyticsResponse(
                success=False,
                message="Failed to fetch YouTube analytics. Check logs for details.",
                analytics=None,
                channelId=processed_channel_id
            )
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching YouTube analytics for user {current_user}: {str(e)}")
        return YouTubeAnalyticsResponse(
            success=False,
            message=f"Internal server error: {str(e)}",
            analytics=None,
            channelId=None
        )


@router.get("/youtube-analytics/{channel_id}")
async def get_youtube_analytics_by_channel(
    channel_id: str,
    current_user: str = Depends(get_current_user)
) -> YouTubeAnalyticsResponse:
    """
    Fetch YouTube analytics for a specific channel ID.
    
    Args:
        channel_id: YouTube channel ID
        current_user: The authenticated user from JWT token
        
    Returns:
        Response with YouTube analytics data
    """
    try:
        logger.info(f"Fetching YouTube analytics for channel: {channel_id}")
        
        # This endpoint requires OAuth access token - return error for now
        logger.warning(f"YouTube analytics by channel ID requires OAuth access token")
        return YouTubeAnalyticsResponse(
            success=False,
            message="This endpoint requires OAuth authentication. Please use the main YouTube analytics endpoint with proper authentication.",
            analytics=None,
            channelId=channel_id
        )
            
    except Exception as e:
        logger.error(f"Error fetching YouTube analytics for channel {channel_id}: {str(e)}")
        return YouTubeAnalyticsResponse(
            success=False,
            message=f"Internal server error: {str(e)}",
            analytics=None,
            channelId=channel_id
        )


class InstagramAnalyticsRequest(BaseModel):
    """Request model for fetching Instagram analytics"""
    accessToken: str = Field(..., description="Instagram access token")
    instagramUserId: str = Field(..., description="Instagram user ID")
    platform: Optional[Platform] = Field(None, description="Existing platform data to update")


class InstagramAnalyticsResponse(BaseModel):
    """Response model for Instagram analytics"""
    success: bool = Field(..., description="Whether the fetch was successful")
    message: str = Field(..., description="Status message")
    analytics: Optional[InstagramAnalytics] = Field(None, description="Instagram analytics data")
    updatedPlatform: Optional[Platform] = Field(None, description="Updated platform data")


@router.post("/instagram-analytics", response_model=InstagramAnalyticsResponse)
async def fetch_instagram_analytics(
    request: InstagramAnalyticsRequest,
    current_user: str = Depends(get_current_user)
) -> InstagramAnalyticsResponse:
    """
    Fetch Instagram analytics and update platform data.
    
    This endpoint fetches Instagram analytics using the provided access token
    and Instagram user ID, then updates the user's platform with the new data.
    
    Args:
        request: Instagram analytics request with access token and user ID
        current_user: The authenticated user from JWT token
        
    Returns:
        Response with Instagram analytics data and updated platform
    """
    try:
        logger.info(f"Fetching Instagram analytics for user: {current_user}")
        
        # Validate required fields
        if not request.accessToken or not request.instagramUserId:
            return InstagramAnalyticsResponse(
                success=False,
                message="Access token and Instagram user ID are required",
                analytics=None,
                updatedPlatform=None
            )
        
        # Fetch Instagram analytics
        analytics = await instagram_analytics_service.get_instagram_analytics(
            instagram_user_id=request.instagramUserId,
            access_token=request.accessToken
        )
        
        if not analytics:
            return InstagramAnalyticsResponse(
                success=False,
                message="Failed to fetch Instagram analytics. Check access token and permissions.",
                analytics=None,
                updatedPlatform=None
            )
        
        # Find the user
        user = await User.find_one(User.uuid == current_user)
        if not user:
            return InstagramAnalyticsResponse(
                success=False,
                message="User not found",
                analytics=analytics,
                updatedPlatform=None
            )
        
        # Update platform if provided or find existing Instagram platform
        updated_platform = None
        if request.platform:
            # Update the provided platform with new analytics
            updated_platform = request.platform
            updated_platform.instagramAnalytics = analytics
            updated_platform.lastUpdated = datetime.utcnow()
            
            # Update metrics
            if not updated_platform.metrics:
                updated_platform.metrics = PlatformMetrics()
            
            updated_platform.metrics.subscribers = str(analytics.followers or 0)
            updated_platform.metrics.avgShortViews = str(analytics.shortViews or 0)
            updated_platform.metrics.totalViews = str(analytics.totalReach or 0)
            
            # Update custom fields
            if not updated_platform.customFields:
                updated_platform.customFields = {}
            
            updated_platform.customFields["mediaCount"] = analytics.totalPosts
            updated_platform.customFields["profilePictureUrl"] = None  # Would need separate API call
            
            # Save the updated user
            user.updatedAt = datetime.utcnow()
            await user.save()
            
            logger.info(f"Successfully updated Instagram platform for user: {current_user}")
        
        return InstagramAnalyticsResponse(
            success=True,
            message="Instagram analytics fetched and platform updated successfully",
            analytics=analytics,
            updatedPlatform=updated_platform
        )
        
    except InstagramReconnectionRequired as e:
        logger.warning(f"Instagram reconnection required for user {current_user}: {str(e)}")
        raise HTTPException(
            status_code=203,
            detail="Instagram account needs to be reconnected. Please re-authenticate your Instagram account."
        )
    except Exception as e:
        logger.error(f"Error fetching Instagram analytics for user {current_user}: {str(e)}")
        return InstagramAnalyticsResponse(
            success=False,
            message=f"Internal server error: {str(e)}",
            analytics=None,
            updatedPlatform=None
        )


@router.get("/instagram-analytics/{instagram_user_id}")
async def get_instagram_analytics_by_user_id(
    instagram_user_id: str,
    access_token: str,
    current_user: str = Depends(get_current_user)
) -> InstagramAnalyticsResponse:
    """
    Fetch Instagram analytics for a specific Instagram user ID.
    
    Args:
        instagram_user_id: Instagram user ID
        access_token: Instagram access token
        current_user: The authenticated user from JWT token
        
    Returns:
        Response with Instagram analytics data
    """
    try:
        logger.info(f"Fetching Instagram analytics for Instagram user: {instagram_user_id}")
        
        # Fetch analytics for the specific Instagram user
        analytics = await instagram_analytics_service.get_instagram_analytics(
            instagram_user_id=instagram_user_id,
            access_token=access_token
        )
        
        if analytics:
            logger.info(f"Successfully fetched Instagram analytics for user: {instagram_user_id}")
            return InstagramAnalyticsResponse(
                success=True,
                message="Instagram analytics fetched successfully",
                analytics=analytics,
                updatedPlatform=None
            )
        else:
            logger.warning(f"Failed to fetch Instagram analytics for user: {instagram_user_id}")
            return InstagramAnalyticsResponse(
                success=False,
                message="Failed to fetch Instagram analytics. Check access token and permissions.",
                analytics=None,
                updatedPlatform=None
            )
            
    except InstagramReconnectionRequired as e:
        logger.warning(f"Instagram reconnection required for user {instagram_user_id}: {str(e)}")
        raise HTTPException(
            status_code=203,
            detail="Instagram account needs to be reconnected. Please re-authenticate your Instagram account."
        )
    except Exception as e:
        logger.error(f"Error fetching Instagram analytics for user {instagram_user_id}: {str(e)}")
        return InstagramAnalyticsResponse(
            success=False,
            message=f"Internal server error: {str(e)}",
            analytics=None,
            updatedPlatform=None
        )


class YouTubeOAuthRequest(BaseModel):
    """Request model for YouTube OAuth authorization"""
    state: Optional[str] = Field(None, description="Optional state parameter for security")


class YouTubeOAuthResponse(BaseModel):
    """Response model for YouTube OAuth authorization"""
    success: bool = Field(..., description="Whether the request was successful")
    message: str = Field(..., description="Status message")
    authorizationUrl: Optional[str] = Field(None, description="OAuth authorization URL")
    state: Optional[str] = Field(None, description="State parameter for security")


class YouTubeOAuthCallbackRequest(BaseModel):
    """Request model for YouTube OAuth callback"""
    code: str = Field(..., description="Authorization code from OAuth callback")
    state: Optional[str] = Field(None, description="State parameter for verification")


class YouTubeOAuthCallbackResponse(BaseModel):
    """Response model for YouTube OAuth callback"""
    success: bool = Field(..., description="Whether the token exchange was successful")
    message: str = Field(..., description="Status message")
    tokens: Optional[Dict[str, Any]] = Field(None, description="Token information")
    channelInfo: Optional[Dict[str, Any]] = Field(None, description="Channel information")


@router.post("/youtube-oauth/authorize", response_model=YouTubeOAuthResponse)
async def youtube_oauth_authorize(
    request: YouTubeOAuthRequest,
    current_user: str = Depends(get_current_user)
) -> YouTubeOAuthResponse:
    """
    Generate YouTube OAuth authorization URL.
    
    Args:
        request: OAuth authorization request with optional state
        current_user: The authenticated user from JWT token
        
    Returns:
        Response with authorization URL
    """
    try:
        logger.info(f"Generating YouTube OAuth authorization URL for user: {current_user}")
        
        # Generate authorization URL
        auth_url = youtube_analytics_service.get_oauth_authorization_url(
            state=request.state or current_user
        )
        logger.info(f"YouTube OAuth authorization URL generated successfully: {auth_url}")
        
        return YouTubeOAuthResponse(
            success=True,
            message="YouTube OAuth authorization URL generated successfully",
            authorizationUrl=auth_url,
            state=request.state or current_user
        )
        
    except Exception as e:
        logger.error(f"Error generating YouTube OAuth URL for user {current_user}: {str(e)}")
        return YouTubeOAuthResponse(
            success=False,
            message=f"Error generating authorization URL: {str(e)}",
            authorizationUrl=None,
            state=None
        )


@router.post("/youtube-oauth/callback", response_model=YouTubeOAuthCallbackResponse)
async def youtube_oauth_callback(
    request: YouTubeOAuthCallbackRequest,
    current_user: str = Depends(get_current_user)
) -> YouTubeOAuthCallbackResponse:
    """
    Handle YouTube OAuth callback, exchange code for tokens, and associate with user account.
    
    This endpoint:
    1. Exchanges the authorization code for OAuth tokens
    2. Gets the channel information using the OAuth credentials
    3. Associates the OAuth tokens and channel info with the user's account
    4. Creates or updates the YouTube platform entry
    
    Args:
        request: OAuth callback request with authorization code
        current_user: The authenticated user from JWT token
        
    Returns:
        Response with tokens and channel information
    """
    try:
        logger.info(f"Processing YouTube OAuth callback for user: {current_user}")
        
        # Find the user
        user = await User.find_one(User.uuid == current_user)
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found"
            )
        
        # Exchange authorization code for tokens
        logger.info("🔄 Exchanging authorization code for tokens")
        token_info = youtube_analytics_service.exchange_code_for_token(request.code)
        
        # Create credentials from tokens
        logger.info("🔑 Creating credentials from tokens")
        credentials = youtube_analytics_service.create_credentials_from_tokens(token_info)
        
        # Get channel information using OAuth credentials
        logger.info("📺 Getting channel information from OAuth credentials")
        channel_info = youtube_analytics_service.get_channel_info_from_credentials(credentials)
        
        if not channel_info:
            logger.warning("⚠️ No channel information found")
            return YouTubeOAuthCallbackResponse(
                success=False,
                message="Could not retrieve channel information",
                tokens=token_info,
                channelInfo=None
            )
        
        logger.info(f"✅ Channel information retrieved: {channel_info.get('title', 'Unknown')} ({channel_info.get('channelId', 'Unknown ID')})")
        
        # Create or update YouTube platform entry
        logger.info("🔧 Creating/updating YouTube platform entry")
        
        # Initialize platforms list if it doesn't exist
        if not user.platforms:
            user.platforms = []
        
        # Find existing YouTube platform
        youtube_platform = None
        for i, platform in enumerate(user.platforms):
            if (hasattr(platform, 'platformType') and 
                platform.platformType == PlatformType.YOUTUBE):
                youtube_platform = platform
                break
        
        # Create new platform or update existing one
        if youtube_platform:
            logger.info("📝 Updating existing YouTube platform")
            # Update existing platform
            youtube_platform.name = channel_info.get('title', 'YouTube Channel')
            youtube_platform.handle = channel_info.get('customUrl', f"@{channel_info.get('title', '')}")
            youtube_platform.isActive = True
            youtube_platform.lastUpdated = datetime.utcnow()
            # Store OAuth tokens in custom fields
            youtube_platform.customFields['oauth_tokens'] = token_info
            youtube_platform.customFields['channel_id'] = channel_info.get('channelId')
            youtube_platform.customFields['channel_title'] = channel_info.get('title')
        else:
            logger.info("🆕 Creating new YouTube platform")
            # Create new platform
            youtube_platform = Platform(
                name=channel_info.get('title', 'YouTube Channel'),
                platformType=PlatformType.YOUTUBE,
                handle=channel_info.get('customUrl', f"@{channel_info.get('title', '')}"),
                isActive=True,
                lastUpdated=datetime.utcnow(),
                customFields={
                    'oauth_tokens': token_info,
                    'channel_id': channel_info.get('channelId'),
                    'channel_title': channel_info.get('title')
                }
            )
            user.platforms.append(youtube_platform)
        
        # Save user with updated platform
        user.updatedAt = datetime.utcnow()
        await user.save()
        
        logger.info(f"✅ YouTube OAuth callback completed successfully for user: {current_user}")
        logger.info(f"   - Channel: {channel_info.get('title')}")
        logger.info(f"   - Channel ID: {channel_info.get('channelId')}")
        logger.info(f"   - Platform updated: {'Yes' if youtube_platform else 'No'}")
        
        return YouTubeOAuthCallbackResponse(
            success=True,
            message="YouTube account connected successfully",
            tokens=token_info,
            channelInfo=channel_info
        )
        
    except Exception as e:
        logger.error(f"❌ Error processing YouTube OAuth callback for user {current_user}: {str(e)}")
        return YouTubeOAuthCallbackResponse(
            success=False,
            message=f"Error processing OAuth callback: {str(e)}",
            tokens=None,
            channelInfo=None
        )


@router.post("/youtube-oauth/validate")
async def youtube_oauth_validate(
    tokens: Dict[str, Any],
    current_user: str = Depends(get_current_user)
) -> Dict[str, Any]:
    """
    Validate YouTube OAuth tokens and get channel information.
    
    Args:
        tokens: Token information dictionary
        current_user: The authenticated user from JWT token
        
    Returns:
        Validation result and channel information
    """
    try:
        logger.info(f"Validating YouTube OAuth tokens for user: {current_user}")
        
        # Create credentials from tokens
        credentials = youtube_analytics_service.create_credentials_from_tokens(tokens)
        
        # Refresh credentials if needed
        credentials = youtube_analytics_service.refresh_credentials(credentials)
        
        # Validate credentials
        is_valid = youtube_analytics_service.validate_credentials(credentials)
        
        if is_valid:
            # Get channel information
            channel_info = youtube_analytics_service.get_channel_info_from_credentials(credentials)
            
            return {
                "success": True,
                "message": "YouTube OAuth tokens are valid",
                "channelInfo": channel_info,
                "isValid": True
            }
        else:
            return {
                "success": False,
                "message": "YouTube OAuth tokens are invalid or expired",
                "channelInfo": None,
                "isValid": False
            }
            
    except Exception as e:
        logger.error(f"Error validating YouTube OAuth tokens for user {current_user}: {str(e)}")
        return {
            "success": False,
            "message": f"Error validating tokens: {str(e)}",
            "channelInfo": None,
            "isValid": False
        }


# --- Instagram OAuth (same pattern as YouTube) ---
class InstagramOAuthRequest(BaseModel):
    state: Optional[str] = Field(None, description="Optional state for CSRF")


class InstagramOAuthResponse(BaseModel):
    success: bool
    message: str
    authorizationUrl: Optional[str] = None
    state: Optional[str] = None


class InstagramOAuthCallbackRequest(BaseModel):
    code: str = Field(..., description="Authorization code from callback")
    state: Optional[str] = None


class InstagramOAuthCallbackResponse(BaseModel):
    success: bool
    message: str
    tokens: Optional[Dict[str, Any]] = None
    user: Optional[Dict[str, Any]] = None


@router.post("/instagram-oauth/authorize", response_model=InstagramOAuthResponse)
async def instagram_oauth_authorize(
    request: InstagramOAuthRequest,
    current_user: str = Depends(get_current_user),
) -> InstagramOAuthResponse:
    try:
        state = request.state or current_user
        auth_url = instagram_oauth_service.get_oauth_authorization_url(state=state)
        return InstagramOAuthResponse(
            success=True,
            message="Instagram OAuth URL generated",
            authorizationUrl=auth_url,
            state=state,
        )
    except Exception as e:
        logger.error(f"Instagram OAuth authorize error: {e}")
        return InstagramOAuthResponse(
            success=False, message=str(e), authorizationUrl=None, state=None
        )


@router.post("/instagram-oauth/callback", response_model=InstagramOAuthCallbackResponse)
async def instagram_oauth_callback(
    request: InstagramOAuthCallbackRequest,
    current_user: str = Depends(get_current_user),
) -> InstagramOAuthCallbackResponse:
    try:
        user = await User.find_one(User.uuid == current_user)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        result = await instagram_oauth_service.exchange_code_for_token(request.code)
        if not result:
            return InstagramOAuthCallbackResponse(
                success=False, message="Token exchange failed", tokens=None, user=None
            )
        tokens = result["tokens"]
        u = result["user"]
        if not user.platforms:
            user.platforms = []
        existing = next(
            (p for p in user.platforms if getattr(p, "platformType", None) == PlatformType.INSTAGRAM),
            None,
        )
        if existing:
            existing.name = u.get("name", existing.name)
            existing.handle = u.get("handle", existing.handle)
            existing.customFields = existing.customFields or {}
            existing.customFields["oauth_tokens"] = tokens
            existing.lastUpdated = datetime.utcnow()
        else:
            user.platforms.append(
                Platform(
                    name=u.get("name", "Instagram"),
                    handle=u.get("handle", "@instagram"),
                    platformType=PlatformType.INSTAGRAM,
                    isActive=True,
                    lastUpdated=datetime.utcnow(),
                    customFields={"oauth_tokens": tokens},
                )
            )
        user.updatedAt = datetime.utcnow()
        await user.save()
        return InstagramOAuthCallbackResponse(
            success=True, message="Instagram connected", tokens=tokens, user=u
        )
    except Exception as e:
        logger.error(f"Instagram OAuth callback error: {e}")
        return InstagramOAuthCallbackResponse(
            success=False, message=str(e), tokens=None, user=None
        )


