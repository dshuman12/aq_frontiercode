import logging
from typing import Any, Dict, Type, Union

from beanie import Document
from fastapi import APIRouter, Depends, HTTPException, status, Header
from starlette.requests import Request

import os

import requests
from dotenv import load_dotenv

from auth.JWTBearer import JWKS, JWTBearer, JWTAuthorizationCredentials
from auth.service_auth import (
    AuthContext,
    ServiceAccountCredentials,
    get_current_user_or_service,
    is_user_auth,
    is_service_account,
    get_user_id,
)

load_dotenv()  # Load from .env file
load_dotenv(".env.local")  # Also load from .env.local file for local overrides

logger = logging.getLogger("uvicorn.error")

# Lazy loading of JWKS - reload if empty on each request
_jwks = None
_auth = None


def _load_jwks():
    """Load JWKS from Cognito."""
    global _jwks
    cognito_region = os.environ.get("COGNITO_REGION")
    cognito_pool_id = os.environ.get("COGNITO_POOL_ID")

    if not cognito_region or not cognito_pool_id:
        logger.warning(
            "COGNITO_REGION or COGNITO_POOL_ID not set. JWT authentication will fail. "
            "Please set these environment variables in your .env.local file."
        )
        # Return empty JWKS to prevent startup failure
        return JWKS.model_validate({"keys": []})

    try:
        jwks_url = f"https://cognito-idp.{cognito_region}.amazonaws.com/{cognito_pool_id}/.well-known/jwks.json"
        logger.info(f"Loading JWKS from: {jwks_url}")
        response = requests.get(jwks_url, timeout=5)
        response.raise_for_status()
        jwks_data = JWKS.model_validate(response.json())
        logger.info(f"JWKS loaded successfully with {len(jwks_data.keys)} keys")
        return jwks_data
    except Exception as e:
        logger.error(f"Failed to load JWKS from Cognito: {e}. JWT authentication will fail.")
        # Return empty JWKS to prevent startup failure
        return JWKS.model_validate({"keys": []})


def _ensure_jwks_loaded(force_reload: bool = False):
    """Ensure JWKS is loaded, reload if empty or if forced."""
    global _jwks, _auth, auth
    cognito_region = os.environ.get("COGNITO_REGION")
    cognito_pool_id = os.environ.get("COGNITO_POOL_ID")
    
    # Reload if JWKS is empty (no keys) and env vars are now set, or if forced
    if force_reload or not _jwks or len(_jwks.keys) == 0:
        if cognito_region and cognito_pool_id:
            logger.info("Reloading JWKS (was empty, env vars now available, or forced reload)")
            _jwks = _load_jwks()
            if _jwks and len(_jwks.keys) > 0:
                _auth = JWTBearer(_jwks)
                auth = _auth  # Update the exported auth variable
                logger.info(f"JWKS reloaded successfully with {len(_jwks.keys)} keys")
            else:
                logger.warning("JWKS reload returned empty keys")
    return _jwks, _auth


# Try to load JWKS, but don't fail if env vars aren't set
try:
    _jwks = _load_jwks()
    _auth = JWTBearer(_jwks)
    jwks = _jwks
    auth = _auth
except Exception as e:
    logger.warning(
        f"Could not initialize JWKS at startup: {e}. Will retry on first use."
    )
    # Create a dummy JWKS to prevent import errors
    _jwks = JWKS.model_validate({"keys": []})
    _auth = JWTBearer(_jwks)
    jwks = _jwks
    auth = _auth


async def get_auth(request: Request) -> JWTAuthorizationCredentials:
    """Get auth dependency, ensuring JWKS is loaded and up-to-date.
    
    This function ensures JWKS is loaded, then calls the JWTBearer instance
    to validate the JWT token and return the credentials.
    """
    # Always ensure JWKS is loaded before using auth
    _ensure_jwks_loaded()
    
    # Check if we need to reload (if auth instance has no keys)
    if _auth and len(_auth.kid_to_jwk) == 0:
        cognito_region = os.environ.get("COGNITO_REGION")
        cognito_pool_id = os.environ.get("COGNITO_POOL_ID")
        if cognito_region and cognito_pool_id:
            logger.info("Auth instance has no keys, forcing JWKS reload...")
            _ensure_jwks_loaded(force_reload=True)
    
    # Call the JWTBearer instance to get credentials
    if not _auth:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Authentication service not available"
        )
    
    return await _auth(request)


async def get_current_user(
    credentials: JWTAuthorizationCredentials = Depends(get_auth),
) -> str:
    try:
        # Try different possible username fields in Cognito JWT
        if "cognito:username" in credentials.claims:
            return credentials.claims["cognito:username"]
        elif "username" in credentials.claims:
            return credentials.claims["username"]
        elif "sub" in credentials.claims:
            return credentials.claims["sub"]
        elif "email" in credentials.claims:
            return credentials.claims["email"]
        else:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Username not found in token",
            )
    except KeyError:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN, detail="Username missing"
        )


def is_admin_user(credentials: JWTAuthorizationCredentials) -> bool:
    """
    Check if the user is an admin based on Cognito groups in JWT token.

    Args:
        credentials: JWT authorization credentials from the token

    Returns:
        True if user is in admin group, False otherwise
    """
    try:
        groups = credentials.claims.get("cognito:groups", [])
        if isinstance(groups, str):
            groups = [groups]
        return "admin" in groups
    except (KeyError, AttributeError):
        return False




def require_user_or_service_permission(permission: str = None):
    """Dependency factory that requires either user auth or service account with permission."""

    async def _require_auth(
        auth_context: AuthContext = Depends(get_current_user_or_service),
    ) -> AuthContext:
        # If it's a service account, check permissions
        if is_service_account(auth_context):
            if permission:
                auth_context.require_permission(permission)
        # User auth is always allowed (no permission check needed)

        return auth_context

    return _require_auth


def register_crud_from_model(model: Type[Document], router: APIRouter):
    """Register CRUD operations for a model"""

    @router.get("/")
    async def get_all(current_user: str = Depends(get_current_user)) -> list[model]:
        print(f"Getting all {model.__name__} for user: {current_user}")
        return await model.find(model.userId == current_user).to_list()

    @router.get("/{id}")
    async def get_by_id(
        id: str, current_user: str = Depends(get_current_user)
    ) -> model | None:
        # Only return item if it belongs to the current user
        print(f"Getting {model.__name__} {id} for user: {current_user}")
        return await model.find_one(model.uuid == id, model.userId == current_user)

    @router.post("/")
    async def create(
        item: model, current_user: str = Depends(get_current_user)
    ) -> model:
        print(f"Creating {model.__name__} for user: {current_user}")
        return await item.insert()

    @router.put("/{id}")
    async def update(
        id: str, item: model, current_user: str = Depends(get_current_user)
    ) -> model:
        print(f"Updating {model.__name__} {id} for user: {current_user}")

        if item.uuid != id:
            raise HTTPException(status_code=400, detail="ID mismatch")

        existing_doc = await model.find_one(model.uuid == id)
        if existing_doc is None:
            raise HTTPException(
                status_code=404, detail="Item not found or access denied"
            )

        # # Ensure the user_id remains the same
        # if hasattr(item, 'user_id'):
        #     item.user_id = existing_doc.user_id

        return await item.replace()

    @router.delete("/{id}")
    async def delete(id: str, current_user: str = Depends(get_current_user)) -> bool:
        print(f"Deleting {model.__name__} {id} for user: {current_user}")

        # Only allow deletion if the item belongs to the current user
        doc = await model.find_one(model.uuid == id, model.user_id == current_user)
        if doc is None:
            raise HTTPException(
                status_code=404, detail="Item not found or access denied"
            )

        return await doc.delete() is not None

    return router
