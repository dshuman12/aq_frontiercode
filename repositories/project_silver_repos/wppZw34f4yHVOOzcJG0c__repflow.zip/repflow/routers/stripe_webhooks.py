"""
Stripe webhook handlers for processing subscription and payment events.
"""

import os
import logging
import stripe
import requests
from datetime import datetime
from fastapi import APIRouter, Request, HTTPException, status
from fastapi.responses import JSONResponse
from typing import Dict, Any, Optional
from database.models.user import User, BillingInfo, BillingAddress, Subscription

# Configure logging
logger = logging.getLogger("uvicorn.error")

# Initialize Stripe - Load from environment variables
stripe.api_key = os.getenv("STRIPE_SECRET_KEY")
webhook_secret = os.getenv("STRIPE_WEBHOOK_SECRET")

router = APIRouter(
    prefix="/stripe",
    tags=["stripe"],
)

# Backend API base URL for internal calls
API_BASE_URL = os.getenv("API_BASE_URL", "http://localhost:8000")


async def find_user_by_stripe_customer(
    customer_id: str, customer_email: Optional[str] = None
) -> Optional[User]:
    """
    Find a user by Stripe customer ID or email.

    Args:
        customer_id: Stripe customer ID
        customer_email: Optional customer email for fallback lookup

    Returns:
        User object if found, None otherwise
    """
    try:
        # Try to find by email if provided
        if customer_email:
            logger.info(f"🔍 Searching for user by email: {customer_email}")
            user = await User.find_one({"profile.email": customer_email})
            if user:
                logger.info(f"✅ Found user by email: {user.uuid}")
                return user

        # Try to get customer from Stripe and use email
        if not customer_email:
            try:
                customer = stripe.Customer.retrieve(customer_id)
                customer_email = customer.get("email")
                if customer_email:
                    logger.info(
                        f"📧 Retrieved email from Stripe customer: {customer_email}"
                    )
                    user = await User.find_one({"profile.email": customer_email})
                    if user:
                        logger.info(
                            f"✅ Found user by Stripe-retrieved email: {user.uuid}"
                        )
                        return user
            except Exception as e:
                logger.warning(f"⚠️ Could not retrieve customer from Stripe: {e}")

        logger.warning(f"⚠️ User not found for Stripe customer: {customer_id}")
        return None

    except Exception as e:
        logger.error(f"❌ Error finding user by Stripe customer: {e}")
        return None


async def sync_subscription_to_mongodb(
    subscription: Any, invoice: Optional[Dict[str, Any]] = None
):
    """
    Sync Stripe subscription and billing data to MongoDB.

    Args:
        subscription: Stripe subscription object
        invoice: Optional Stripe invoice object for billing details
    """
    try:
        customer_id = (
            subscription.get("customer")
            if isinstance(subscription, dict)
            else subscription.customer
        )

        # Get customer email from Stripe
        customer_email = None
        try:
            customer = stripe.Customer.retrieve(customer_id)
            customer_email = customer.get("email")
        except Exception as e:
            logger.warning(f"⚠️ Could not retrieve customer from Stripe: {e}")

        # Find user
        user = await find_user_by_stripe_customer(customer_id, customer_email)
        if not user:
            logger.warning(
                f"⚠️ User not found for Stripe customer {customer_id}, skipping sync"
            )
            return

        logger.info(f"🔄 Syncing subscription data for user: {user.uuid}")

        # Extract subscription data
        if isinstance(subscription, dict):
            sub_status = subscription.get("status", "active")
            sub_tier = subscription.get("metadata", {}).get("tier", "Premium")
            period_end = subscription.get("current_period_end")
        else:
            sub_status = subscription.status
            sub_tier = (
                subscription.metadata.get("tier", "Premium")
                if subscription.metadata
                else "Premium"
            )
            period_end = subscription.current_period_end

        # Update subscription
        if period_end:
            period_end_dt = datetime.fromtimestamp(period_end)
            user.profile.subscription = Subscription(
                tier=sub_tier, status=sub_status, currentPeriodEnd=period_end_dt
            )
            logger.info(
                f"✅ Updated subscription: {sub_tier} - {sub_status} (ends {period_end_dt})"
            )

        # Update billing info if invoice is provided
        if invoice:
            await update_billing_info_from_invoice(user, invoice, customer_id)

        # Save user
        user.updatedAt = datetime.utcnow()
        await user.save()
        logger.info(
            f"✅ Successfully synced subscription data to MongoDB for user: {user.uuid}"
        )

    except Exception as e:
        logger.error(f"❌ Error syncing subscription to MongoDB: {e}")
        import traceback

        logger.error(traceback.format_exc())


async def update_billing_info_from_invoice(
    user: User, invoice: Dict[str, Any], customer_id: str
):
    """
    Update user billing info from Stripe invoice and customer data.

    Args:
        user: User object to update
        invoice: Stripe invoice object
        customer_id: Stripe customer ID
    """
    try:
        # Retrieve customer from Stripe
        customer = stripe.Customer.retrieve(customer_id)

        # Get payment method from invoice
        payment_intent_id = invoice.get("payment_intent")
        if payment_intent_id:
            try:
                payment_intent = stripe.PaymentIntent.retrieve(payment_intent_id)
                if payment_intent.payment_method:
                    pm = stripe.PaymentMethod.retrieve(payment_intent.payment_method)
                    card = pm.card if hasattr(pm, "card") else None

                    if card:
                        # Get billing address from customer
                        billing_address = None
                        if customer.get("address"):
                            addr = customer.address
                            billing_address = BillingAddress(
                                line1=addr.get("line1", ""),
                                line2=addr.get("line2"),
                                city=addr.get("city", ""),
                                state=addr.get("state", ""),
                                postalCode=addr.get("postal_code", ""),
                                country=addr.get("country", "United States"),
                            )

                        # Calculate next billing date from subscription
                        next_billing = None
                        if invoice.get("subscription"):
                            sub = stripe.Subscription.retrieve(invoice["subscription"])
                            if sub.current_period_end:
                                next_billing = datetime.fromtimestamp(
                                    sub.current_period_end
                                )

                        # Update or create billing info
                        user.billingInfo = BillingInfo(
                            cardLast4=card.last4,
                            cardBrand=card.brand,
                            nextBillingDate=next_billing or datetime.utcnow(),
                            expirationMonth=card.exp_month,
                            expirationYear=card.exp_year,
                            paymentMethodId=pm.id,
                            billingEmail=customer.get("email"),
                            billingAddress=billing_address,
                        )
                        logger.info(
                            f"✅ Updated billing info: {card.brand} •••• {card.last4}"
                        )
            except Exception as e:
                logger.warning(f"⚠️ Could not retrieve payment method details: {e}")

    except Exception as e:
        logger.error(f"❌ Error updating billing info from invoice: {e}")


async def update_subscription_status_on_payment_failure(subscription: Any):
    """
    Update subscription status to past_due or unpaid when payment fails.

    Args:
        subscription: Stripe subscription object
    """
    try:
        customer_id = (
            subscription.get("customer")
            if isinstance(subscription, dict)
            else subscription.customer
        )

        # Get customer email
        customer_email = None
        try:
            customer = stripe.Customer.retrieve(customer_id)
            customer_email = customer.get("email")
        except Exception as e:
            logger.warning(f"⚠️ Could not retrieve customer from Stripe: {e}")

        # Find user
        user = await find_user_by_stripe_customer(customer_id, customer_email)
        if not user:
            logger.warning(
                f"⚠️ User not found for Stripe customer {customer_id}, skipping status update"
            )
            return

        # Update subscription status
        if isinstance(subscription, dict):
            sub_status = subscription.get("status", "past_due")
            period_end = subscription.get("current_period_end")
        else:
            sub_status = subscription.status
            period_end = subscription.current_period_end

        if user.profile.subscription and period_end:
            period_end_dt = datetime.fromtimestamp(period_end)
            user.profile.subscription.status = sub_status
            user.profile.subscription.currentPeriodEnd = period_end_dt
            user.updatedAt = datetime.utcnow()
            await user.save()
            logger.info(
                f"✅ Updated subscription status to {sub_status} for user: {user.uuid}"
            )

    except Exception as e:
        logger.error(f"❌ Error updating subscription status on payment failure: {e}")


async def mark_subscription_canceled(subscription: Any):
    """
    Mark subscription as canceled in MongoDB.

    Args:
        subscription: Stripe subscription object
    """
    try:
        customer_id = (
            subscription.get("customer")
            if isinstance(subscription, dict)
            else subscription.customer
        )

        # Get customer email
        customer_email = None
        try:
            customer = stripe.Customer.retrieve(customer_id)
            customer_email = customer.get("email")
        except Exception as e:
            logger.warning(f"⚠️ Could not retrieve customer from Stripe: {e}")

        # Find user
        user = await find_user_by_stripe_customer(customer_id, customer_email)
        if not user:
            logger.warning(
                f"⚠️ User not found for Stripe customer {customer_id}, skipping cancellation"
            )
            return

        # Mark subscription as canceled
        if user.profile.subscription:
            user.profile.subscription.status = "canceled"
            if isinstance(subscription, dict):
                period_end = subscription.get("current_period_end")
            else:
                period_end = subscription.current_period_end

            if period_end:
                user.profile.subscription.currentPeriodEnd = datetime.fromtimestamp(
                    period_end
                )

            user.updatedAt = datetime.utcnow()
            await user.save()
            logger.info(f"✅ Marked subscription as canceled for user: {user.uuid}")

    except Exception as e:
        logger.error(f"❌ Error marking subscription as canceled: {e}")


@router.post("/webhook")
async def stripe_webhook(request: Request):
    """
    Handle Stripe webhook events.
    This endpoint should be configured in your Stripe Dashboard.
    """
    logger.info("🔔 Stripe webhook endpoint called")

    try:
        # Validate Stripe API key is configured
        if not stripe.api_key:
            logger.error(
                "❌ Stripe API key not configured - check STRIPE_SECRET_KEY environment variable"
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Stripe API key not configured",
            )

        # Get the raw body and signature
        body = await request.body()
        signature = request.headers.get("stripe-signature")

        logger.info(f"📥 Webhook request received:")
        logger.info(f"   - Body length: {len(body)} bytes")
        logger.info(f"   - Has signature: {'Yes' if signature else 'No'}")
        logger.info(
            f"   - Webhook secret configured: {'Yes' if webhook_secret else 'No'}"
        )
        logger.info(
            f"   - Stripe API key configured: {'Yes' if stripe.api_key else 'No'}"
        )

        if not webhook_secret:
            logger.error(
                "❌ Missing webhook secret - check STRIPE_WEBHOOK_SECRET environment variable"
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Webhook secret not configured",
            )

        if not signature:
            logger.error("❌ Missing webhook signature")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Missing webhook signature",
            )

        # Verify the webhook signature
        logger.info("🔐 Verifying webhook signature...")
        try:
            event = stripe.Webhook.construct_event(body, signature, webhook_secret)
            logger.info("✅ Webhook signature verified successfully")
            logger.info(f"📋 Event details:")
            logger.info(f"   - Event ID: {event.get('id', 'Unknown')}")
            logger.info(f"   - Event type: {event.get('type', 'Unknown')}")
            logger.info(f"   - Created: {event.get('created', 'Unknown')}")

        except ValueError as e:
            logger.error(f"❌ Invalid payload: {e}")
            logger.error(f"   - Body preview: {body[:100]}...")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid payload"
            )
        except stripe.error.SignatureVerificationError as e:
            logger.error(f"❌ Invalid signature: {e}")
            logger.error(f"   - Signature: {signature[:50]}...")
            logger.error(
                f"   - Webhook secret length: {len(webhook_secret) if webhook_secret else 0}"
            )
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid signature"
            )

        # Process the event
        logger.info(f"🚀 Processing Stripe event: {event.get('type')}")
        await process_stripe_event(event)

        logger.info("✅ Webhook processed successfully")
        return JSONResponse(content={"received": True})

    except HTTPException as he:
        logger.error(f"❌ HTTP Exception in webhook handler: {he.detail}")
        raise
    except Exception as e:
        logger.error(f"❌ Unexpected error in webhook handler: {e}")
        logger.error(f"   - Error type: {type(e).__name__}")
        import traceback

        logger.error(f"   - Traceback: {traceback.format_exc()}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Webhook handler failed",
        )


async def process_stripe_event(event: Dict[str, Any]):
    """Process different types of Stripe events."""
    event_type = event["type"]
    event_data = event["data"]["object"]

    logger.info(f"🔄 Processing Stripe event: {event_type}")
    logger.info(f"📊 Event data summary:")
    logger.info(f"   - Object ID: {event_data.get('id', 'Unknown')}")
    logger.info(f"   - Object type: {event_data.get('object', 'Unknown')}")

    # Log additional context based on event type
    if "subscription" in event_type:
        logger.info(f"   - Customer: {event_data.get('customer', 'Unknown')}")
        logger.info(f"   - Status: {event_data.get('status', 'Unknown')}")
    elif "invoice" in event_type:
        logger.info(f"   - Customer: {event_data.get('customer', 'Unknown')}")
        logger.info(
            f"   - Amount: {event_data.get('amount_paid', 0) / 100 if event_data.get('amount_paid') else 0}"
        )
    elif "payment_intent" in event_type:
        logger.info(
            f"   - Amount: {event_data.get('amount', 0) / 100 if event_data.get('amount') else 0}"
        )
        logger.info(f"   - Currency: {event_data.get('currency', 'Unknown')}")

    try:
        if event_type == "invoice.payment_succeeded":
            logger.info("📈 Handling invoice payment succeeded")
            await handle_invoice_payment_succeeded(event_data)
        elif event_type == "invoice.payment_failed":
            logger.info("📉 Handling invoice payment failed")
            await handle_invoice_payment_failed(event_data)
        elif event_type == "customer.subscription.created":
            logger.info("🆕 Handling subscription created")
            await handle_subscription_created(event_data)
        elif event_type == "customer.subscription.updated":
            logger.info("🔄 Handling subscription updated")
            await handle_subscription_updated(event_data)
        elif event_type == "customer.subscription.deleted":
            logger.info("🗑️ Handling subscription deleted")
            await handle_subscription_deleted(event_data)
        elif event_type == "payment_intent.succeeded":
            logger.info("💳 Handling payment intent succeeded")
            await handle_payment_intent_succeeded(event_data)
        elif event_type == "payment_intent.payment_failed":
            logger.info("❌ Handling payment intent failed")
            await handle_payment_intent_failed(event_data)
        else:
            logger.info(f"⚠️ Unhandled event type: {event_type}")
            logger.info("   - This event type is not configured for processing")

        logger.info(f"✅ Successfully processed {event_type}")

    except Exception as e:
        logger.error(f"❌ Error processing {event_type}: {e}")
        logger.error(f"   - Error type: {type(e).__name__}")
        import traceback

        logger.error(f"   - Traceback: {traceback.format_exc()}")
        # Don't raise here - we want to acknowledge receipt even if processing fails


async def handle_invoice_payment_succeeded(invoice: Dict[str, Any]):
    """Handle successful invoice payments."""
    logger.info(f"💰 Invoice payment succeeded: {invoice['id']}")
    logger.info(f"📋 Invoice details:")
    logger.info(f"   - Customer: {invoice.get('customer', 'Unknown')}")
    logger.info(f"   - Amount paid: ${invoice.get('amount_paid', 0) / 100}")
    logger.info(f"   - Currency: {invoice.get('currency', 'Unknown')}")
    logger.info(f"   - Status: {invoice.get('status', 'Unknown')}")

    if invoice.get("subscription"):
        logger.info(f"🔄 This is a subscription payment")
        logger.info(f"   - Subscription ID: {invoice['subscription']}")

        try:
            # This is a subscription payment
            logger.info("📡 Retrieving subscription details from Stripe...")
            subscription = stripe.Subscription.retrieve(invoice["subscription"])

            logger.info(f"✅ Subscription retrieved successfully:")
            logger.info(f"   - Subscription ID: {subscription.id}")
            logger.info(f"   - Customer: {subscription.customer}")
            logger.info(f"   - Status: {subscription.status}")
            logger.info(
                f"   - Current period: {subscription.current_period_start} - {subscription.current_period_end}"
            )
            logger.info(
                f"   - Metadata: {dict(subscription.metadata) if subscription.metadata else {}}"
            )

            # Sync subscription and billing data to MongoDB
            await sync_subscription_to_mongodb(subscription, invoice)

        except Exception as e:
            logger.error(f"❌ Error retrieving subscription: {e}")
            logger.error(f"   - Subscription ID: {invoice['subscription']}")
    else:
        logger.info("💳 This is a one-time payment (no subscription)")

    logger.info("✅ Invoice payment succeeded handling completed")


async def handle_invoice_payment_failed(invoice: Dict[str, Any]):
    """Handle failed invoice payments."""
    logger.error(f"💸 Invoice payment failed: {invoice['id']}")
    logger.error(f"📋 Failed invoice details:")
    logger.error(f"   - Customer: {invoice.get('customer', 'Unknown')}")
    logger.error(f"   - Amount due: ${invoice.get('amount_due', 0) / 100}")
    logger.error(f"   - Currency: {invoice.get('currency', 'Unknown')}")
    logger.error(f"   - Attempt count: {invoice.get('attempt_count', 'Unknown')}")
    logger.error(
        f"   - Next payment attempt: {invoice.get('next_payment_attempt', 'Unknown')}"
    )

    if invoice.get("subscription"):
        logger.error(f"🔄 This is a subscription payment failure")
        logger.error(f"   - Subscription ID: {invoice['subscription']}")

        try:
            # This is a subscription payment failure
            logger.info("📡 Retrieving subscription details from Stripe...")
            subscription = stripe.Subscription.retrieve(invoice["subscription"])

            logger.error(f"📊 Failed subscription details:")
            logger.error(f"   - Subscription ID: {subscription.id}")
            logger.error(f"   - Customer: {subscription.customer}")
            logger.error(f"   - Status: {subscription.status}")
            logger.error(
                f"   - Days until due: {subscription.days_until_due if hasattr(subscription, 'days_until_due') else 'N/A'}"
            )
            logger.error(
                f"   - Metadata: {dict(subscription.metadata) if subscription.metadata else {}}"
            )

            # Update subscription status to past_due or unpaid
            await update_subscription_status_on_payment_failure(subscription)

        except Exception as e:
            logger.error(f"❌ Error retrieving failed subscription: {e}")
            logger.error(f"   - Subscription ID: {invoice['subscription']}")
    else:
        logger.error("💳 This is a one-time payment failure (no subscription)")

    logger.info("✅ Invoice payment failed handling completed")


async def handle_subscription_created(subscription: Dict[str, Any]):
    """Handle new subscription creation."""
    logger.info(f"🆕 Subscription created: {subscription['id']}")
    logger.info(f"📊 Subscription details:")
    logger.info(f"   - Customer: {subscription['customer']}")
    logger.info(f"   - Status: {subscription['status']}")
    logger.info(
        f"   - Current period: {subscription.get('current_period_start')} - {subscription.get('current_period_end')}"
    )
    logger.info(
        f"   - Cancel at period end: {subscription.get('cancel_at_period_end', False)}"
    )
    logger.info(f"   - Trial end: {subscription.get('trial_end', 'No trial')}")

    metadata = subscription.get("metadata", {})
    logger.info(f"📋 Subscription metadata: {dict(metadata) if metadata else 'None'}")

    # Check for promotion codes used in this subscription
    logger.info("🎟️ Checking for promotion codes...")
    try:
        await handle_promotion_code_usage(subscription)
        logger.info("✅ Promotion code check completed")
    except Exception as e:
        logger.error(f"❌ Error checking promotion codes: {e}")

    # Handle payment link subscriptions
    if metadata.get("source") == "payment_link":
        logger.info("🔗 Payment link subscription detected")
        logger.info(f"   - Source: {metadata.get('source')}")
        logger.info(f"   - Email: {metadata.get('email', 'Not provided')}")
        logger.info(f"   - Tier: {metadata.get('tier', 'Not provided')}")

        # Handle referral completion if referral code is present
        if metadata.get("referralCode"):
            logger.info(
                f"🎯 Referral code found in metadata: {metadata['referralCode']}"
            )
            try:
                await complete_referral_from_webhook(
                    referral_code=metadata["referralCode"],
                    customer_email=metadata.get("email"),
                    tier=metadata.get("tier"),
                    stripe_customer_id=subscription["customer"],
                    subscription_id=subscription["id"],
                )
                logger.info("✅ Referral completion attempted")
            except Exception as e:
                logger.error(f"❌ Error completing referral: {e}")
        else:
            logger.info("ℹ️ No referral code in payment link metadata")
    else:
        logger.info("💳 Direct subscription (not from payment link)")

    # Sync subscription data to MongoDB
    await sync_subscription_to_mongodb(subscription, None)

    logger.info("✅ Subscription created handling completed")


async def handle_subscription_updated(subscription: Dict[str, Any]):
    """Handle subscription updates."""
    logger.info(f"🔄 Subscription updated: {subscription['id']}")
    logger.info(f"📊 Updated subscription details:")
    logger.info(f"   - Customer: {subscription['customer']}")
    logger.info(f"   - New status: {subscription['status']}")
    logger.info(
        f"   - Cancel at period end: {subscription.get('cancel_at_period_end', False)}"
    )
    logger.info(
        f"   - Current period: {subscription.get('current_period_start')} - {subscription.get('current_period_end')}"
    )
    logger.info(f"   - Canceled at: {subscription.get('canceled_at', 'Not canceled')}")
    logger.info(f"   - Trial end: {subscription.get('trial_end', 'No trial')}")

    # Log what type of update this might be
    if subscription.get("cancel_at_period_end"):
        logger.info("⚠️ Subscription scheduled for cancellation at period end")
    elif subscription.get("canceled_at"):
        logger.info("❌ Subscription has been canceled")
    elif subscription["status"] == "active":
        logger.info("✅ Subscription is active")
    elif subscription["status"] == "past_due":
        logger.warning("⚠️ Subscription is past due")
    elif subscription["status"] == "unpaid":
        logger.warning("💸 Subscription is unpaid")

    metadata = subscription.get("metadata", {})
    logger.info(f"📋 Subscription metadata: {dict(metadata) if metadata else 'None'}")

    # Sync updated subscription data to MongoDB
    await sync_subscription_to_mongodb(subscription, None)

    logger.info("✅ Subscription updated handling completed")


async def handle_subscription_deleted(subscription: Dict[str, Any]):
    """Handle subscription deletion."""
    logger.info(f"🗑️ Subscription deleted: {subscription['id']}")
    logger.info(f"📊 Deleted subscription details:")
    logger.info(f"   - Customer: {subscription['customer']}")
    logger.info(f"   - Final status: {subscription['status']}")
    logger.info(f"   - Canceled at: {subscription.get('canceled_at', 'Unknown')}")
    logger.info(f"   - Ended at: {subscription.get('ended_at', 'Unknown')}")
    logger.info(
        f"   - Last period: {subscription.get('current_period_start')} - {subscription.get('current_period_end')}"
    )

    metadata = subscription.get("metadata", {})
    logger.info(
        f"📋 Deleted subscription metadata: {dict(metadata) if metadata else 'None'}"
    )

    # Log cancellation reason if available
    cancellation_details = subscription.get("cancellation_details", {})
    if cancellation_details:
        logger.info(f"📝 Cancellation details:")
        logger.info(f"   - Reason: {cancellation_details.get('reason', 'Unknown')}")
        logger.info(f"   - Comment: {cancellation_details.get('comment', 'None')}")
        logger.info(f"   - Feedback: {cancellation_details.get('feedback', 'None')}")

    # Mark subscription as canceled in MongoDB
    await mark_subscription_canceled(subscription)

    logger.info("✅ Subscription deleted handling completed")


async def handle_payment_intent_succeeded(payment_intent: Dict[str, Any]):
    """Handle successful payment intents."""
    logger.info(f"💳 Payment intent succeeded: {payment_intent['id']}")
    logger.info(f"📊 Payment intent details:")
    logger.info(f"   - Amount: ${payment_intent.get('amount', 0) / 100}")
    logger.info(f"   - Currency: {payment_intent.get('currency', 'Unknown')}")
    logger.info(f"   - Status: {payment_intent.get('status', 'Unknown')}")
    logger.info(f"   - Customer: {payment_intent.get('customer', 'Unknown')}")

    # For subscription setup intents
    metadata = payment_intent.get("metadata", {})
    logger.info(f"📋 Payment intent metadata: {dict(metadata) if metadata else 'None'}")

    if metadata.get("subscription_id"):
        logger.info(f"🔗 Setup intent for subscription: {metadata['subscription_id']}")
        logger.info("   - This payment intent was used to set up a subscription")
    else:
        logger.info("💰 One-time payment intent (not subscription setup)")

    logger.info("✅ Payment intent succeeded handling completed")


async def handle_payment_intent_failed(payment_intent: Dict[str, Any]):
    """Handle failed payment intents."""
    logger.error(f"❌ Payment intent failed: {payment_intent['id']}")
    logger.error(f"📊 Failed payment intent details:")
    logger.error(f"   - Amount: ${payment_intent.get('amount', 0) / 100}")
    logger.error(f"   - Currency: {payment_intent.get('currency', 'Unknown')}")
    logger.error(f"   - Status: {payment_intent.get('status', 'Unknown')}")
    logger.error(f"   - Customer: {payment_intent.get('customer', 'Unknown')}")

    last_payment_error = payment_intent.get("last_payment_error", {})
    if last_payment_error:
        logger.error(f"💸 Failure details:")
        logger.error(f"   - Message: {last_payment_error.get('message', 'Unknown')}")
        logger.error(f"   - Code: {last_payment_error.get('code', 'Unknown')}")
        logger.error(f"   - Type: {last_payment_error.get('type', 'Unknown')}")
        logger.error(
            f"   - Decline code: {last_payment_error.get('decline_code', 'Unknown')}"
        )
    else:
        logger.error("   - No specific error details available")

    metadata = payment_intent.get("metadata", {})
    logger.error(
        f"📋 Failed payment metadata: {dict(metadata) if metadata else 'None'}"
    )

    logger.info("✅ Payment intent failed handling completed")


async def complete_referral_from_webhook(
    referral_code: str,
    customer_email: str,
    tier: str,
    stripe_customer_id: str,
    subscription_id: str,
):
    """Complete referral processing via webhook."""
    logger.info(f"🎯 Starting referral completion via webhook")
    logger.info(f"📋 Referral details:")
    logger.info(f"   - Referral code: {referral_code}")
    logger.info(f"   - Customer email: {customer_email}")
    logger.info(f"   - Tier: {tier}")
    logger.info(f"   - Stripe customer ID: {stripe_customer_id}")
    logger.info(f"   - Subscription ID: {subscription_id}")

    try:
        # Call the existing referral completion endpoint
        logger.info(
            f"📡 Calling referral completion endpoint: {API_BASE_URL}/referrals/complete"
        )

        payload = {
            "referralCode": referral_code,
            "customerEmail": customer_email,
            "tier": tier,
            "stripeCustomerId": stripe_customer_id,
            "subscriptionId": subscription_id,
        }
        logger.info(f"📤 Request payload: {payload}")

        response = requests.post(
            f"{API_BASE_URL}/referrals/complete",
            json=payload,
            headers={"Content-Type": "application/json"},
            timeout=30,
        )

        logger.info(f"📥 Response status: {response.status_code}")

        if response.status_code == 200:
            logger.info(
                f"✅ Referral completed successfully via webhook for subscription: {subscription_id}"
            )
            try:
                response_data = response.json()
                logger.info(f"📊 Response data: {response_data}")
            except:
                logger.info("📊 Response data: (not JSON or empty)")
        else:
            logger.error(f"❌ Failed to complete referral via webhook")
            logger.error(f"   - Status code: {response.status_code}")
            logger.error(f"   - Response text: {response.text}")

    except requests.exceptions.Timeout:
        logger.error(f"⏰ Timeout error completing referral via webhook (30s timeout)")
    except requests.exceptions.ConnectionError as e:
        logger.error(f"🔌 Connection error completing referral via webhook: {e}")
    except Exception as e:
        logger.error(f"❌ Unexpected error completing referral via webhook: {e}")
        logger.error(f"   - Error type: {type(e).__name__}")
        import traceback

        logger.error(f"   - Traceback: {traceback.format_exc()}")


async def handle_promotion_code_usage(subscription: Dict[str, Any]):
    """
    Handle promotion code usage when a subscription is created.
    Find the user who owns the promotion code and update their referral history.
    """
    logger.info(
        f"🎟️ Checking promotion code usage for subscription: {subscription['id']}"
    )

    try:
        # Get the latest invoice for this subscription to check for promotion codes
        latest_invoice_id = subscription.get("latest_invoice")
        logger.info(f"📄 Latest invoice ID: {latest_invoice_id}")

        if not latest_invoice_id:
            logger.info(
                "ℹ️ No latest invoice found for subscription - skipping promotion code check"
            )
            return

        # Retrieve the invoice to check for discounts/promotion codes
        logger.info("📡 Retrieving invoice from Stripe...")
        try:
            # First try to get invoice with expanded discounts
            invoice = stripe.Invoice.retrieve(
                latest_invoice_id,
                expand=["discounts.coupon", "discounts.promotion_code"],
            )
            logger.info("✅ Retrieved invoice with expanded discounts")
        except Exception as e:
            logger.warning(f"⚠️ Could not retrieve invoice with expanded discounts: {e}")
            logger.info("📡 Retrieving invoice without expansion...")
            invoice = stripe.Invoice.retrieve(latest_invoice_id)

        logger.info(f"📋 Invoice retrieved:")
        logger.info(f"   - Invoice ID: {invoice.id}")
        logger.info(f"   - Customer: {invoice.customer}")
        logger.info(
            f"   - Amount: ${invoice.amount_paid / 100 if invoice.amount_paid else 0}"
        )
        logger.info(f"   - Discounts count: {len(invoice.get('discounts', []))}")

        # Check if there are any discounts applied
        if not invoice.get("discounts") or len(invoice["discounts"]) == 0:
            logger.info("ℹ️ No discounts found on invoice - no promotion codes used")
            return

        logger.info(f"🎯 Found {len(invoice['discounts'])} discount(s) on invoice")

        # Process each discount (there could be multiple)
        for i, discount in enumerate(invoice["discounts"]):
            logger.info(f"🔍 Processing discount #{i+1}:")
            logger.info(f"   - Discount type: {type(discount).__name__}")
            logger.info(f"   - Discount value: {discount}")

            # Handle case where discount might be a string ID instead of an object
            if isinstance(discount, str):
                logger.warning(
                    f"⚠️ Discount is a string ID ({discount}) - cannot process without expansion"
                )
                logger.warning(
                    "   - Skipping this discount as Stripe discounts cannot be retrieved directly"
                )
                logger.warning(
                    "   - To fix: Configure webhook to expand 'data.object.latest_invoice.discounts' in Stripe Dashboard"
                )
                logger.warning(
                    "   - Or use a different approach to get promotion code information"
                )
                continue

            # Now process the discount object
            if not isinstance(discount, dict) and hasattr(discount, "to_dict"):
                # Convert Stripe object to dict for easier access
                discount = discount.to_dict()
            elif not isinstance(discount, dict):
                logger.error(f"❌ Unexpected discount format: {type(discount)}")
                continue

            coupon = discount.get("coupon")
            promotion_code = discount.get("promotion_code")

            logger.info(f"   - Has promotion code: {'Yes' if promotion_code else 'No'}")
            logger.info(f"   - Has coupon: {'Yes' if coupon else 'No'}")

            if promotion_code:
                # Handle promotion code (could be string ID or object)
                if isinstance(promotion_code, str):
                    promotion_code_id = promotion_code
                    logger.info(f"🎟️ Processing promotion code ID: {promotion_code_id}")
                else:
                    promotion_code_id = (
                        promotion_code.get("id")
                        if hasattr(promotion_code, "get")
                        else str(promotion_code)
                    )
                    logger.info(
                        f"🎟️ Processing promotion code object: {promotion_code_id}"
                    )

                try:
                    # Get the promotion code details
                    logger.info("📡 Retrieving promotion code details from Stripe...")
                    promo_code_obj = stripe.PromotionCode.retrieve(promotion_code_id)
                    promo_code_value = promo_code_obj.get("code")

                    logger.info(f"✅ Promotion code retrieved:")
                    logger.info(f"   - Code: {promo_code_value}")
                    logger.info(
                        f"   - Active: {promo_code_obj.get('active', 'Unknown')}"
                    )
                    logger.info(
                        f"   - Times redeemed: {promo_code_obj.get('times_redeemed', 'Unknown')}"
                    )

                    # Find the user who owns this promotion code
                    await process_promotion_code_referral(
                        promotion_code=promo_code_value,
                        stripe_promotion_code_id=promotion_code_id,
                        subscription=subscription,
                        invoice=invoice,
                    )

                except Exception as e:
                    logger.error(
                        f"❌ Error processing promotion code {promotion_code_id}: {e}"
                    )

            elif coupon:
                # Handle coupon (could be string ID or object)
                if isinstance(coupon, str):
                    logger.info(f"🎫 Processing coupon ID: {coupon}")
                    try:
                        # Retrieve full coupon object
                        coupon_obj = stripe.Coupon.retrieve(coupon)
                        coupon_id = coupon
                        coupon_metadata = coupon_obj.get("metadata", {})
                    except Exception as e:
                        logger.error(f"❌ Error retrieving coupon {coupon}: {e}")
                        continue
                else:
                    # Coupon is already an object
                    coupon_id = coupon.get("id")
                    coupon_metadata = coupon.get("metadata", {})
                    logger.info(f"🎫 Processing coupon object: {coupon_id}")

                logger.info(
                    f"📋 Coupon metadata: {dict(coupon_metadata) if coupon_metadata else 'None'}"
                )

                if coupon_metadata.get("referral_code"):
                    logger.info(
                        f"🎯 Found referral code in coupon metadata: {coupon_metadata['referral_code']}"
                    )

                    try:
                        await process_promotion_code_referral(
                            promotion_code=coupon_metadata["referral_code"],
                            stripe_promotion_code_id=coupon_id,
                            subscription=subscription,
                            invoice=invoice,
                        )
                    except Exception as e:
                        logger.error(
                            f"❌ Error processing coupon referral {coupon_id}: {e}"
                        )
                else:
                    logger.info("ℹ️ Coupon has no referral code in metadata")
            else:
                logger.warning("⚠️ Discount found but no promotion code or coupon data")

        # If we couldn't process discounts from invoice, try alternative approach
        # Check if subscription has discount information
        if subscription.get("discount"):
            logger.info(
                "🔄 Trying alternative approach: checking subscription discount..."
            )
            try:
                await process_subscription_discount(subscription)
            except Exception as e:
                logger.error(f"❌ Error processing subscription discount: {e}")

        logger.info("✅ Promotion code usage check completed")

    except Exception as e:
        logger.error(f"❌ Error handling promotion code usage: {e}")
        logger.error(f"   - Error type: {type(e).__name__}")
        import traceback

        logger.error(f"   - Traceback: {traceback.format_exc()}")


async def process_subscription_discount(subscription: Dict[str, Any]):
    """
    Alternative method to process promotion codes from subscription discount.
    """
    logger.info("🔄 Processing subscription discount as alternative approach")

    discount = subscription.get("discount")
    if not discount:
        logger.info("ℹ️ No discount found on subscription")
        return

    logger.info(f"📋 Subscription discount details:")
    logger.info(f"   - Discount type: {type(discount).__name__}")

    # Handle discount object
    if isinstance(discount, str):
        logger.warning(f"⚠️ Subscription discount is string ID: {discount}")
        return

    # Convert to dict if needed
    if not isinstance(discount, dict) and hasattr(discount, "to_dict"):
        discount = discount.to_dict()
    elif not isinstance(discount, dict):
        logger.error(f"❌ Unexpected subscription discount format: {type(discount)}")
        return

    coupon = discount.get("coupon")
    promotion_code = discount.get("promotion_code")

    logger.info(f"   - Has promotion code: {'Yes' if promotion_code else 'No'}")
    logger.info(f"   - Has coupon: {'Yes' if coupon else 'No'}")

    # Create a mock invoice for the processing function
    mock_invoice = {
        "id": f"mock_invoice_for_{subscription['id']}",
        "customer": subscription["customer"],
        "lines": {"data": []},  # We'll calculate from subscription
        "amount_paid": 0,  # Will be calculated
    }

    # Try to get subscription amount for revenue calculation
    if subscription.get("items") and subscription["items"].get("data"):
        total_amount = 0
        for item in subscription["items"]["data"]:
            if item.get("price") and item.get("price", {}).get("unit_amount"):
                total_amount += item["price"]["unit_amount"]
        mock_invoice["amount_paid"] = total_amount
        mock_invoice["lines"]["data"] = [
            {"amount": total_amount, "description": "Subscription"}
        ]

    if promotion_code:
        # Handle promotion code from subscription
        if isinstance(promotion_code, str):
            promotion_code_id = promotion_code
        else:
            promotion_code_id = (
                promotion_code.get("id")
                if hasattr(promotion_code, "get")
                else str(promotion_code)
            )

        logger.info(f"🎟️ Processing subscription promotion code: {promotion_code_id}")

        try:
            promo_code_obj = stripe.PromotionCode.retrieve(promotion_code_id)
            promo_code_value = promo_code_obj.get("code")

            logger.info(f"✅ Subscription promotion code retrieved: {promo_code_value}")

            await process_promotion_code_referral(
                promotion_code=promo_code_value,
                stripe_promotion_code_id=promotion_code_id,
                subscription=subscription,
                invoice=mock_invoice,
            )
        except Exception as e:
            logger.error(f"❌ Error processing subscription promotion code: {e}")

    elif coupon:
        # Handle coupon from subscription
        if isinstance(coupon, str):
            try:
                coupon_obj = stripe.Coupon.retrieve(coupon)
                coupon_id = coupon
                coupon_metadata = coupon_obj.get("metadata", {})
            except Exception as e:
                logger.error(f"❌ Error retrieving subscription coupon: {e}")
                return
        else:
            coupon_id = coupon.get("id")
            coupon_metadata = coupon.get("metadata", {})

        logger.info(f"🎫 Processing subscription coupon: {coupon_id}")

        if coupon_metadata.get("referral_code"):
            logger.info(
                f"🎯 Found referral code in subscription coupon: {coupon_metadata['referral_code']}"
            )

            try:
                await process_promotion_code_referral(
                    promotion_code=coupon_metadata["referral_code"],
                    stripe_promotion_code_id=coupon_id,
                    subscription=subscription,
                    invoice=mock_invoice,
                )
            except Exception as e:
                logger.error(f"❌ Error processing subscription coupon referral: {e}")
        else:
            logger.info("ℹ️ Subscription coupon has no referral code in metadata")


async def process_promotion_code_referral(
    promotion_code: str,
    stripe_promotion_code_id: str,
    subscription: Dict[str, Any],
    invoice: Dict[str, Any],
):
    """
    Process referral when a promotion code is used.
    Find the referrer and update their referral history.
    """
    logger.info(f"🎯 Processing promotion code referral")
    logger.info(f"📋 Referral processing details:")
    logger.info(f"   - Promotion code: {promotion_code}")
    logger.info(f"   - Stripe promotion code ID: {stripe_promotion_code_id}")
    logger.info(f"   - Subscription ID: {subscription['id']}")
    logger.info(f"   - Invoice ID: {invoice['id']}")

    try:
        # Import here to avoid circular imports
        logger.info("📦 Importing database models...")
        from database.models.user import User, ReferralHistory
        from database.models.referral import Referral, ReferralStatus

        # Find the user who owns this promotion code (referrer)
        logger.info(f"🔍 Searching for user with referral code: {promotion_code}")
        referrer = await User.find_one({"referralData.referralCode": promotion_code})

        if not referrer:
            logger.warning(f"⚠️ No user found with referral code: {promotion_code}")
            logger.warning("   - This promotion code may not be a referral code")
            logger.warning("   - Or the referrer may not exist in the database")
            return

        logger.info(f"✅ Found referrer:")
        logger.info(f"   - Username: {referrer.profile.repflow_username}")
        logger.info(f"   - UUID: {referrer.uuid}")
        logger.info(f"   - Email: {referrer.profile.email}")
        logger.info(
            f"   - Current total referrals: {referrer.referralData.totalReferrals if referrer.referralData else 0}"
        )

        # Get customer information
        customer_id = subscription["customer"]
        logger.info(f"📡 Retrieving customer information for: {customer_id}")

        customer = stripe.Customer.retrieve(customer_id)
        customer_email = customer.get("email", "Unknown")

        logger.info(f"👤 Customer details:")
        logger.info(f"   - Customer ID: {customer_id}")
        logger.info(f"   - Email: {customer_email}")
        logger.info(f"   - Name: {customer.get('name', 'Unknown')}")

        # Calculate revenue from the subscription
        logger.info("💰 Calculating revenue from invoice...")
        revenue = 0.0

        if invoice.get("lines") and invoice["lines"].get("data"):
            logger.info(f"📊 Processing {len(invoice['lines']['data'])} line item(s):")

            for i, line_item in enumerate(invoice["lines"]["data"]):
                line_amount = line_item.get("amount", 0) / 100
                revenue += line_amount
                logger.info(
                    f"   - Line {i+1}: ${line_amount} ({line_item.get('description', 'No description')})"
                )
        else:
            logger.warning("⚠️ No line items found in invoice")

        logger.info(f"💵 Total calculated revenue: ${revenue}")

        # Find existing referral record or create new one
        logger.info("🔍 Checking for existing referral record...")
        existing_referral = await Referral.find_one(
            {"referralCode": promotion_code, "stripeCustomerId": customer_id}
        )

        if existing_referral:
            logger.info(
                f"📝 Updating existing referral: {existing_referral.referralId}"
            )
            logger.info(f"   - Previous status: {existing_referral.status}")
            logger.info(f"   - Previous revenue: ${existing_referral.referralRevenue}")

            # Update existing referral
            existing_referral.status = ReferralStatus.COMPLETED
            existing_referral.completedAt = datetime.utcnow()
            existing_referral.referralRevenue = revenue
            existing_referral.referrerReward = revenue * 0.20  # 20% reward
            existing_referral.metadata.update(
                {
                    "subscription_id": subscription["id"],
                    "invoice_id": invoice["id"],
                    "stripe_promotion_code_id": stripe_promotion_code_id,
                }
            )

            logger.info("💾 Saving updated referral...")
            await existing_referral.save()
            logger.info(f"✅ Updated existing referral: {existing_referral.referralId}")

            referral_id = existing_referral.referralId
        else:
            logger.info("🆕 Creating new referral record...")

            # Create new referral record
            import uuid

            referral_id = str(uuid.uuid4())

            logger.info(f"📝 New referral details:")
            logger.info(f"   - Referral ID: {referral_id}")
            logger.info(f"   - Revenue: ${revenue}")
            logger.info(f"   - Reward (20%): ${revenue * 0.20}")

            new_referral = Referral(
                referralId=referral_id,
                referralCreatorId=referrer.uuid,
                referralCode=promotion_code,
                status=ReferralStatus.COMPLETED,
                stripePromotionCodeId=stripe_promotion_code_id,
                stripeCustomerId=customer_id,
                referralRevenue=revenue,
                referrerReward=revenue * 0.20,
                completedAt=datetime.utcnow(),
                metadata={
                    "subscription_id": subscription["id"],
                    "invoice_id": invoice["id"],
                    "customer_email": customer_email,
                    "completed_via": "webhook_promotion_code",
                },
            )

            logger.info("💾 Saving new referral...")
            await new_referral.create()
            logger.info(f"✅ Created new referral: {referral_id}")

        # Update referrer's referral data
        if referrer.referralData:
            logger.info("📊 Updating referrer's referral data...")

            old_totals = {
                "referrals": referrer.referralData.totalReferrals,
                "revenue": referrer.referralData.totalRevenue,
                "payouts": referrer.referralData.pendingPayouts,
            }

            referrer.referralData.totalReferrals += 1
            referrer.referralData.totalRevenue += revenue
            referrer.referralData.pendingPayouts += revenue * 0.20

            logger.info(f"📈 Referrer data changes:")
            logger.info(
                f"   - Total referrals: {old_totals['referrals']} → {referrer.referralData.totalReferrals}"
            )
            logger.info(
                f"   - Total revenue: ${old_totals['revenue']:.2f} → ${referrer.referralData.totalRevenue:.2f}"
            )
            logger.info(
                f"   - Pending payouts: ${old_totals['payouts']:.2f} → ${referrer.referralData.pendingPayouts:.2f}"
            )

            # Add to referral history
            history_item = ReferralHistory(
                id=referral_id,
                referredUserName=customer_email,
                status="completed",
                revenue=revenue,
                date=datetime.utcnow(),
            )

            logger.info(f"📝 Adding to referral history:")
            logger.info(f"   - Referred user: {customer_email}")
            logger.info(f"   - Revenue: ${revenue}")
            logger.info(f"   - Date: {datetime.utcnow()}")

            referrer.referralData.referralHistory.append(history_item)

            # Update timestamps
            referrer.referralData.updatedAt = datetime.utcnow()
            referrer.updatedAt = datetime.utcnow()

            logger.info("💾 Saving updated referrer data...")
            await referrer.save()

            logger.info(
                f"✅ Successfully updated referrer {referrer.profile.repflow_username}:"
            )
            logger.info(f"   - Total referrals: {referrer.referralData.totalReferrals}")
            logger.info(
                f"   - Total revenue: ${referrer.referralData.totalRevenue:.2f}"
            )
            logger.info(
                f"   - Pending payouts: ${referrer.referralData.pendingPayouts:.2f}"
            )
            logger.info(
                f"   - History entries: {len(referrer.referralData.referralHistory)}"
            )
        else:
            logger.warning(f"⚠️ Referrer {referrer.uuid} has no referralData")
            logger.warning("   - This user may not have referral system set up")

        logger.info("✅ Promotion code referral processing completed successfully")

    except Exception as e:
        logger.error(f"❌ Error processing promotion code referral: {e}")
        logger.error(f"   - Error type: {type(e).__name__}")
        logger.error(f"   - Promotion code: {promotion_code}")
        logger.error(f"   - Subscription ID: {subscription.get('id', 'Unknown')}")
        import traceback

        logger.error(f"   - Traceback: {traceback.format_exc()}")
        raise
