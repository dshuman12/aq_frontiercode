"""
Brands router - CRUD API for brand management in the CRM.
"""

from fastapi import APIRouter, Depends, Query
from typing import Optional, List
from datetime import datetime, timezone
from pydantic import BaseModel, ConfigDict
from pydantic.alias_generators import to_camel
import logging
import re

from .utils import (
    get_current_user,
    require_user_or_service_permission,
    AuthContext,
    is_user_auth,
    get_user_id,
)
from database.models.brand import Brand
from database.models.contact import Contact
from database.models.deal import Deal
from utils.error_handler import handle_errors, raise_http_exception, ErrorCodes, APIError

router = APIRouter(prefix="/brands", tags=["brands"])
logger = logging.getLogger("uvicorn.error")


async def compute_brand_metrics_batch(brand_ids: List[str], user_id: str) -> dict[str, tuple[float, int]]:
    """
    Compute total revenue and deal count for multiple brands in a single query.
    Returns dict mapping brand_id -> (total_revenue, deal_count).
    """
    if not brand_ids:
        return {}

    # Fetch all deals for these brands in one query
    deals = await Deal.find(
        Deal.userId == user_id,
        {"brandId": {"$in": brand_ids}}
    ).to_list()

    # Aggregate by brand_id
    metrics: dict[str, tuple[float, int]] = {bid: (0.0, 0) for bid in brand_ids}
    for deal in deals:
        if deal.brandId and deal.brandId in metrics:
            current_revenue, current_count = metrics[deal.brandId]
            metrics[deal.brandId] = (current_revenue + deal.value, current_count + 1)

    return metrics


async def compute_brand_metrics(brand_id: str, user_id: str) -> tuple[float, int]:
    """
    Compute total revenue and deal count for a single brand.
    Returns (total_revenue, deal_count).
    """
    deals = await Deal.find(
        Deal.userId == user_id,
        Deal.brandId == brand_id
    ).to_list()

    total_revenue = sum(deal.value for deal in deals)
    return total_revenue, len(deals)


# Custom error codes for brands
class BrandErrorCodes:
    BRAND_NOT_FOUND = APIError(
        "Brand not found",
        404,
        "The specified brand does not exist or you don't have access to it",
    )
    BRAND_ALREADY_EXISTS = APIError(
        "Brand already exists",
        409,
        "A brand with this name already exists",
    )


# Request/Response models
class BrandCreate(BaseModel):
    """Request model for creating a brand."""
    name: str
    website: Optional[str] = None
    category: Optional[str] = None
    logo_url: Optional[str] = None
    is_agency: bool = False
    agency_name: Optional[str] = None
    email_domain: Optional[str] = None
    notes: Optional[str] = None


class BrandUpdate(BaseModel):
    """Request model for updating a brand."""
    name: Optional[str] = None
    website: Optional[str] = None
    category: Optional[str] = None
    logo_url: Optional[str] = None
    is_agency: Optional[bool] = None
    agency_name: Optional[str] = None
    email_domain: Optional[str] = None
    notes: Optional[str] = None
    current_status: Optional[str] = None


class BrandResponse(BaseModel):
    """Response model for a brand with contacts count."""
    uuid: str
    name: str
    website: Optional[str] = None
    category: Optional[str] = None
    logo_url: Optional[str] = None
    is_agency: bool
    agency_name: Optional[str] = None
    email_domain: Optional[str] = None
    total_revenue: float
    deal_count: int
    last_touchpoint: Optional[datetime] = None
    current_status: Optional[str] = None
    notes: Optional[str] = None
    contacts_count: int = 0
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
        from_attributes=True,
    )


class BrandContactLinkedResponse(BaseModel):
    """Response model for a contact linked to a brand."""
    uuid: str
    name: str
    email: str
    title: Optional[str] = None
    phone: Optional[str] = None
    is_agency_contact: bool
    notes: Optional[str] = None
    role: Optional[str] = None
    is_primary: bool

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
        from_attributes=True,
    )


class BrandWithContactsResponse(BrandResponse):
    """Response model for a brand with full contact details."""
    contacts: List[BrandContactLinkedResponse] = []

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
        from_attributes=True,
    )


class BrandsListResponse(BaseModel):
    """Response model for paginated brands list."""
    brands: List[BrandResponse]
    total: int
    page: int
    limit: int
    has_more: bool

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
        from_attributes=True,
    )


@router.get("/")
@handle_errors("Get all brands")
async def get_brands(
    page: int = Query(1, ge=1, description="Page number"),
    limit: int = Query(20, ge=1, le=100, description="Items per page"),
    search: Optional[str] = Query(None, description="Search by brand name or contact name/email"),
    category: Optional[str] = Query(None, description="Filter by category"),
    is_agency: Optional[bool] = Query(None, description="Filter by agency type"),
    sort_by: Optional[str] = Query(None, description="Field to sort by (e.g., name, total_revenue, last_touchpoint)"),
    sort_order: str = Query("desc", description="Sort order (asc or desc)"),
    current_user: str = Depends(get_current_user),
) -> BrandsListResponse:
    """
    Get all brands for the current user with pagination, search, and filtering.
    """
    logger.info(f"Getting brands for user: {current_user}, page={page}, limit={limit}, sort={sort_by} {sort_order}")
    
    # Build query
    query: dict = {"user_id": current_user}
    
    if search:
        # Escape special regex characters
        search_regex = re.escape(search)
        
        # Find contacts matching search (name or email)
        matching_contacts = await Contact.find(
            {"user_id": current_user, 
             "$or": [
                 {"name": {"$regex": search_regex, "$options": "i"}},
                 {"email": {"$regex": search_regex, "$options": "i"}}
             ]}
        ).to_list()
        
        # Get brand IDs from matching contacts
        contact_brand_ids = set()
        for contact in matching_contacts:
            contact_brand_ids.update(contact.brand_ids)
            
        # Update query to find brands matching name OR having matching contacts
        query["$or"] = [
            {"name": {"$regex": search_regex, "$options": "i"}},
            {"uuid": {"$in": list(contact_brand_ids)}}
        ]
    
    if category:
        query["category"] = category
    
    if is_agency is not None:
        query["is_agency"] = is_agency
    
    # Get total count
    total = await Brand.find(query).count()
    
    # Define sort prefix
    sort_prefix = "-" if sort_order.lower() == "desc" else "+"
    
    # Map sort_by frontend names to backend field names if they differ
    sort_field = sort_by
    if sort_by == "name" or sort_by == "brand":
        sort_field = "name"
    elif sort_by == "status":
        sort_field = "current_status"
    elif sort_by == "type":
        sort_field = "is_agency"

    # Get paginated results
    skip = (page - 1) * limit
    find_query = Brand.find(query)
    
    if sort_field:
        find_query = find_query.sort(f"{sort_prefix}{sort_field}")
    else:
        # Default sort by updated_at desc
        find_query = find_query.sort("-updated_at")
        
    brands = await find_query.skip(skip).limit(limit).to_list()

    # Get brand IDs for batch queries
    brand_ids = [brand.uuid for brand in brands]

    # Batch compute metrics for all brands
    brand_metrics = await compute_brand_metrics_batch(brand_ids, current_user)

    # Get contacts count for each brand
    brand_responses = []
    for brand in brands:
        contacts_count = await Contact.find(
            Contact.user_id == current_user,
            {"brand_ids": brand.uuid}
        ).count()

        total_revenue, deal_count = brand_metrics.get(brand.uuid, (0.0, 0))

        brand_responses.append(BrandResponse(
            uuid=brand.uuid,
            name=brand.name,
            website=brand.website,
            category=brand.category,
            logo_url=brand.logo_url,
            is_agency=brand.is_agency,
            agency_name=brand.agency_name,
            email_domain=brand.email_domain,
            total_revenue=total_revenue,
            deal_count=deal_count,
            last_touchpoint=brand.last_touchpoint,
            current_status=brand.current_status,
            notes=brand.notes,
            contacts_count=contacts_count,
            created_at=brand.created_at,
            updated_at=brand.updated_at,
        ))
    
    return BrandsListResponse(
        brands=brand_responses,
        total=total,
        page=page,
        limit=limit,
        has_more=(skip + len(brands)) < total,
    )


@router.get("/{brand_id}")
@handle_errors("Get brand by ID")
async def get_brand(
    brand_id: str,
    current_user: str = Depends(get_current_user),
) -> BrandWithContactsResponse:
    """
    Get a specific brand by ID with all linked contacts.
    """
    logger.info(f"Getting brand {brand_id} for user: {current_user}")
    
    brand = await Brand.find_one(Brand.uuid == brand_id, Brand.user_id == current_user)
    if not brand:
        raise_http_exception(BrandErrorCodes.BRAND_NOT_FOUND)
    
    # Get all contacts linked to this brand
    contacts = await Contact.find(
        Contact.user_id == current_user,
        {"brand_ids": brand_id}
    ).to_list()
    
    # Format contacts with their role at this brand
    contacts_list = []
    for contact in contacts:
        contacts_list.append(BrandContactLinkedResponse(
            uuid=contact.uuid,
            name=contact.name,
            email=contact.email,
            title=contact.title,
            phone=contact.phone,
            is_agency_contact=contact.is_agency_contact,
            notes=contact.notes,
            role=contact.brand_roles.get(brand_id),
            is_primary=brand_id in contact.primary_for_brands,
        ))

    # Compute metrics from deals
    total_revenue, deal_count = await compute_brand_metrics(brand_id, current_user)

    return BrandWithContactsResponse(
        uuid=brand.uuid,
        name=brand.name,
        website=brand.website,
        category=brand.category,
        logo_url=brand.logo_url,
        is_agency=brand.is_agency,
        agency_name=brand.agency_name,
        email_domain=brand.email_domain,
        total_revenue=total_revenue,
        deal_count=deal_count,
        last_touchpoint=brand.last_touchpoint,
        current_status=brand.current_status,
        notes=brand.notes,
        contacts_count=len(contacts),
        contacts=contacts_list,
        created_at=brand.created_at,
        updated_at=brand.updated_at,
    )


class BrandFindOrCreateRequest(BaseModel):
    """Request model for finding or creating a brand."""
    name: str
    website: Optional[str] = None
    category: Optional[str] = None
    user_id: Optional[str] = None  # Used by Lambda (service account)


@router.post("/find-or-create")
@handle_errors("Find or create brand")
async def find_or_create_brand(
    request: BrandFindOrCreateRequest,
    auth_context: AuthContext = Depends(
        require_user_or_service_permission("brands:create")
    ),
) -> BrandResponse:
    """
    Find an existing brand by name or create a new one.
    Used by Lambda and frontend to ensure brand entities exist before deal creation.

    For service account auth, user_id must be provided in the request body.
    """
    # Handle different auth contexts
    if is_user_auth(auth_context):
        user_id = get_user_id(auth_context)
    else:
        # Service account - must provide user_id in request
        if not request.user_id:
            raise_http_exception(
                ErrorCodes.MISSING_REQUIRED_FIELD,
                "Service accounts must provide user_id in request body"
            )
        user_id = request.user_id

    logger.info(f"Find or create brand '{request.name}' for user: {user_id}")

    # Try to find existing brand
    existing = await Brand.find_one(
        Brand.user_id == user_id,
        Brand.name == request.name
    )

    if existing:
        logger.info(f"Found existing brand {existing.uuid} for '{request.name}'")
        contacts_count = await Contact.find(
            Contact.user_id == user_id,
            {"brand_ids": existing.uuid}
        ).count()

        # Compute metrics from deals
        total_revenue, deal_count = await compute_brand_metrics(existing.uuid, user_id)

        return BrandResponse(
            uuid=existing.uuid,
            name=existing.name,
            website=existing.website,
            category=existing.category,
            logo_url=existing.logo_url,
            is_agency=existing.is_agency,
            agency_name=existing.agency_name,
            email_domain=existing.email_domain,
            total_revenue=total_revenue,
            deal_count=deal_count,
            last_touchpoint=existing.last_touchpoint,
            current_status=existing.current_status,
            notes=existing.notes,
            contacts_count=contacts_count,
            created_at=existing.created_at,
            updated_at=existing.updated_at,
        )

    # Create new brand
    brand = Brand(
        name=request.name,
        website=request.website,
        category=request.category,
        user_id=user_id,
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )

    await brand.insert()
    logger.info(f"✅ Created new brand {brand.uuid} for '{request.name}'")

    return BrandResponse(
        uuid=brand.uuid,
        name=brand.name,
        website=brand.website,
        category=brand.category,
        logo_url=brand.logo_url,
        is_agency=brand.is_agency,
        agency_name=brand.agency_name,
        email_domain=brand.email_domain,
        total_revenue=0.0,
        deal_count=0,
        last_touchpoint=brand.last_touchpoint,
        current_status=brand.current_status,
        notes=brand.notes,
        contacts_count=0,
        created_at=brand.created_at,
        updated_at=brand.updated_at,
    )


@router.post("/")
@handle_errors("Create brand")
async def create_brand(
    brand_data: BrandCreate,
    current_user: str = Depends(get_current_user),
) -> BrandResponse:
    """
    Create a new brand.
    """
    logger.info(f"Creating brand '{brand_data.name}' for user: {current_user}")
    
    # Check for existing brand with same name
    existing = await Brand.find_one(
        Brand.user_id == current_user,
        Brand.name == brand_data.name
    )
    if existing:
        raise_http_exception(BrandErrorCodes.BRAND_ALREADY_EXISTS)
    
    # Create brand
    brand = Brand(
        name=brand_data.name,
        website=brand_data.website,
        category=brand_data.category,
        logo_url=brand_data.logo_url,
        is_agency=brand_data.is_agency,
        agency_name=brand_data.agency_name,
        email_domain=brand_data.email_domain,
        notes=brand_data.notes,
        user_id=current_user,
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    
    await brand.insert()
    logger.info(f"✅ Created brand {brand.uuid} for user: {current_user}")
    
    return BrandResponse(
        uuid=brand.uuid,
        name=brand.name,
        website=brand.website,
        category=brand.category,
        logo_url=brand.logo_url,
        is_agency=brand.is_agency,
        agency_name=brand.agency_name,
        email_domain=brand.email_domain,
        total_revenue=0.0,
        deal_count=0,
        last_touchpoint=brand.last_touchpoint,
        current_status=brand.current_status,
        notes=brand.notes,
        contacts_count=0,
        created_at=brand.created_at,
        updated_at=brand.updated_at,
    )


@router.put("/{brand_id}")
@handle_errors("Update brand")
async def update_brand(
    brand_id: str,
    brand_data: BrandUpdate,
    current_user: str = Depends(get_current_user),
) -> BrandResponse:
    """
    Update an existing brand.
    """
    logger.info(f"Updating brand {brand_id} for user: {current_user}")
    
    brand = await Brand.find_one(Brand.uuid == brand_id, Brand.user_id == current_user)
    if not brand:
        raise_http_exception(BrandErrorCodes.BRAND_NOT_FOUND)
    
    # Check for name conflict if name is being updated
    if brand_data.name and brand_data.name != brand.name:
        existing = await Brand.find_one(
            Brand.user_id == current_user,
            Brand.name == brand_data.name
        )
        if existing:
            raise_http_exception(BrandErrorCodes.BRAND_ALREADY_EXISTS)
    
    # Update fields
    update_data = brand_data.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(brand, field, value)
    
    brand.updated_at = datetime.now(timezone.utc)
    await brand.save()
    
    # Get contacts count
    contacts_count = await Contact.find(
        Contact.user_id == current_user,
        {"brand_ids": brand_id}
    ).count()

    # Compute metrics from deals
    total_revenue, deal_count = await compute_brand_metrics(brand_id, current_user)

    logger.info(f"✅ Updated brand {brand_id} for user: {current_user}")

    return BrandResponse(
        uuid=brand.uuid,
        name=brand.name,
        website=brand.website,
        category=brand.category,
        logo_url=brand.logo_url,
        is_agency=brand.is_agency,
        agency_name=brand.agency_name,
        email_domain=brand.email_domain,
        total_revenue=total_revenue,
        deal_count=deal_count,
        last_touchpoint=brand.last_touchpoint,
        current_status=brand.current_status,
        notes=brand.notes,
        contacts_count=contacts_count,
        created_at=brand.created_at,
        updated_at=brand.updated_at,
    )


@router.delete("/{brand_id}")
@handle_errors("Delete brand")
async def delete_brand(
    brand_id: str,
    current_user: str = Depends(get_current_user),
) -> dict:
    """
    Delete a brand. This will also unlink all contacts from this brand.
    """
    logger.info(f"Deleting brand {brand_id} for user: {current_user}")
    
    brand = await Brand.find_one(Brand.uuid == brand_id, Brand.user_id == current_user)
    if not brand:
        raise_http_exception(BrandErrorCodes.BRAND_NOT_FOUND)
    
    # Remove this brand from all contacts' brand_ids
    contacts = await Contact.find(
        Contact.user_id == current_user,
        {"brand_ids": brand_id}
    ).to_list()
    
    for contact in contacts:
        contact.brand_ids = [bid for bid in contact.brand_ids if bid != brand_id]
        contact.primary_for_brands = [bid for bid in contact.primary_for_brands if bid != brand_id]
        if brand_id in contact.brand_roles:
            del contact.brand_roles[brand_id]
        contact.updated_at = datetime.now(timezone.utc)
        await contact.save()
    
    # Delete the brand
    await brand.delete()
    
    logger.info(f"✅ Deleted brand {brand_id} and unlinked {len(contacts)} contacts")
    return {
        "success": True,
        "message": f"Brand {brand_id} deleted successfully",
        "contacts_unlinked": len(contacts),
    }


@router.get("/{brand_id}/contacts")
@handle_errors("Get brand contacts")
async def get_brand_contacts(
    brand_id: str,
    current_user: str = Depends(get_current_user),
) -> List[BrandContactLinkedResponse]:
    """
    Get all contacts linked to a specific brand.
    """
    logger.info(f"Getting contacts for brand {brand_id}, user: {current_user}")
    
    # Verify brand exists
    brand = await Brand.find_one(Brand.uuid == brand_id, Brand.user_id == current_user)
    if not brand:
        raise_http_exception(BrandErrorCodes.BRAND_NOT_FOUND)
    
    # Get contacts
    contacts = await Contact.find(
        Contact.user_id == current_user,
        {"brand_ids": brand_id}
    ).to_list()
    
    return [
        BrandContactLinkedResponse(
            uuid=contact.uuid,
            name=contact.name,
            email=contact.email,
            title=contact.title,
            phone=contact.phone,
            is_agency_contact=contact.is_agency_contact,
            notes=contact.notes,
            role=contact.brand_roles.get(brand_id),
            is_primary=brand_id in contact.primary_for_brands,
        )
        for contact in contacts
    ]


@router.post("/{brand_id}/contacts/{contact_id}")
@handle_errors("Link contact to brand")
async def link_contact_to_brand(
    brand_id: str,
    contact_id: str,
    role: Optional[str] = Query(None, description="Contact's role at this brand"),
    is_primary: bool = Query(False, description="Whether this is the primary contact"),
    current_user: str = Depends(get_current_user),
) -> dict:
    """
    Link an existing contact to a brand.
    """
    logger.info(f"Linking contact {contact_id} to brand {brand_id}")
    
    # Verify brand exists
    brand = await Brand.find_one(Brand.uuid == brand_id, Brand.user_id == current_user)
    if not brand:
        raise_http_exception(BrandErrorCodes.BRAND_NOT_FOUND)
    
    # Verify contact exists
    contact = await Contact.find_one(Contact.uuid == contact_id, Contact.user_id == current_user)
    if not contact:
        raise_http_exception(ErrorCodes.NOT_FOUND, "Contact not found")
    
    # Link contact to brand
    if brand_id not in contact.brand_ids:
        contact.brand_ids.append(brand_id)
    
    if role:
        contact.brand_roles[brand_id] = role
    
    if is_primary and brand_id not in contact.primary_for_brands:
        contact.primary_for_brands.append(brand_id)
    elif not is_primary and brand_id in contact.primary_for_brands:
        contact.primary_for_brands.remove(brand_id)
    
    contact.updated_at = datetime.now(timezone.utc)
    await contact.save()
    
    logger.info(f"✅ Linked contact {contact_id} to brand {brand_id}")
    return {
        "success": True,
        "message": f"Contact {contact_id} linked to brand {brand_id}",
    }


@router.get("/{brand_id}/deals")
@handle_errors("Get brand deals")
async def get_brand_deals(
    brand_id: str,
    current_user: str = Depends(get_current_user),
) -> List[dict]:
    """
    Get all deals linked to a specific brand.
    """
    from database.models.deal import Deal
    
    logger.info(f"Getting deals for brand {brand_id}, user: {current_user}")
    
    # Verify brand exists
    brand = await Brand.find_one(Brand.uuid == brand_id, Brand.user_id == current_user)
    if not brand:
        raise_http_exception(BrandErrorCodes.BRAND_NOT_FOUND)
    
    # Get deals linked by brandId
    deals = await Deal.find(
        Deal.userId == current_user,
        Deal.brandId == brand_id
    ).to_list()
    
    return [
        {
            "uuid": deal.uuid,
            "title": deal.title,
            "brandId": deal.brandId,
            "brandName": brand.name,  # Use the brand we already fetched
            "status": deal.status.value if hasattr(deal.status, 'value') else deal.status,
            "value": deal.value,
            "valueCurrency": deal.valueCurrency,
            "dealType": deal.dealType.value if hasattr(deal.dealType, 'value') else deal.dealType,
            "dateReceived": deal.dateReceived.isoformat() if deal.dateReceived else None,
            "dueDate": deal.dueDate.isoformat() if deal.dueDate else None,
            "lastActivity": deal.lastActivity.isoformat() if deal.lastActivity else None,
            "createdAt": deal.createdAt.isoformat() if deal.createdAt else None,
        }
        for deal in deals
    ]


@router.delete("/{brand_id}/contacts/{contact_id}")
@handle_errors("Unlink contact from brand")
async def unlink_contact_from_brand(
    brand_id: str,
    contact_id: str,
    current_user: str = Depends(get_current_user),
) -> dict:
    """
    Unlink a contact from a brand.
    """
    logger.info(f"Unlinking contact {contact_id} from brand {brand_id}")
    
    # Verify brand exists
    brand = await Brand.find_one(Brand.uuid == brand_id, Brand.user_id == current_user)
    if not brand:
        raise_http_exception(BrandErrorCodes.BRAND_NOT_FOUND)
    
    # Verify contact exists
    contact = await Contact.find_one(Contact.uuid == contact_id, Contact.user_id == current_user)
    if not contact:
        raise_http_exception(ErrorCodes.NOT_FOUND, "Contact not found")
    
    # Unlink contact from brand
    if brand_id in contact.brand_ids:
        contact.brand_ids.remove(brand_id)
    
    if brand_id in contact.primary_for_brands:
        contact.primary_for_brands.remove(brand_id)
    
    if brand_id in contact.brand_roles:
        del contact.brand_roles[brand_id]
    
    contact.updated_at = datetime.now(timezone.utc)
    await contact.save()
    
    logger.info(f"✅ Unlinked contact {contact_id} from brand {brand_id}")
    return {
        "success": True,
        "message": f"Contact {contact_id} unlinked from brand {brand_id}",
    }
