import os
from contextlib import asynccontextmanager
import logging
import uvicorn
from fastapi import FastAPI, Depends
import warnings

# Suppress Pydantic warnings
try:
    from pydantic.warnings import (
        PydanticDeprecatedSince20,
        UnsupportedFieldAttributeWarning,
    )

    warnings.filterwarnings("ignore", category=PydanticDeprecatedSince20)
    warnings.filterwarnings("ignore", category=UnsupportedFieldAttributeWarning)
except ImportError:
    # The warning classes may not exist in older/newer Pydantic versions; safe to ignore if not present.
    pass

from routers import (
    deals,
    user,
    messages,
    conversations,
    leads,
    service_accounts,
    emails,
    referrals,
    stripe_webhooks,
    admin,
    fsm_simulator,
    brands,
    contacts,
)
from auth.JWTBearer import JWTBearer
from routers.utils import jwks, auth, get_current_user
from database.database import init_database, close_database
from fastapi.middleware.cors import CORSMiddleware
from middleware.error_handler import ErrorHandlerMiddleware, setup_exception_handlers

logger = logging.getLogger("uvicorn.error")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifespan event handler for database connection."""
    # Startup
    await init_database()
    logger.info("Application startup complete - database initialized")
    yield
    # Shutdown
    await close_database()
    logger.info("Application shutdown complete")


app = FastAPI(lifespan=lifespan)
logger = logging.getLogger("uvicorn.error")

# Browser origins allowed for CORS. Extend with CORS_ALLOWED_ORIGINS (comma-separated) for previews
# or new deploy URLs without a code change — see docs/DEPLOYMENT-ENVIRONMENTS.md §6.
_default_origins = [
    "http://localhost:3000",
    "http://localhost:3001",  # Admin panel
    "https://pjarnibjib.us-east-2.awsapprunner.com",  # Legacy dev App Runner
    "https://i2mk8mby5p.us-east-2.awsapprunner.com",  # Dev App Runner
    "https://cnhp2ujpjm.us-east-2.awsapprunner.com",  # Prod Endpoint
    "https://creator.userepflow.com",  # Prod web
]
_extra_origins = [
    o.strip()
    for o in os.environ.get("CORS_ALLOWED_ORIGINS", "").split(",")
    if o.strip()
]
# Dedupe while preserving order
origins = list(dict.fromkeys(_default_origins + _extra_origins))

# Starlette middleware order: last added = outermost (runs first).
# CORS must be outermost so its headers are added to ALL responses,
# including errors caught by ErrorHandlerMiddleware.
app.add_middleware(ErrorHandlerMiddleware)
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Setup global exception handlers
setup_exception_handlers(app)

app.include_router(deals.router)
app.include_router(user.router)
app.include_router(messages.router)
app.include_router(conversations.router)
app.include_router(leads.router)
app.include_router(service_accounts.router)
app.include_router(emails.router)
app.include_router(referrals.router)
app.include_router(stripe_webhooks.router)
app.include_router(admin.router)
app.include_router(fsm_simulator.router)
app.include_router(brands.router)
app.include_router(contacts.router)


@app.get("/health")
async def health():
    return {"message": "OK"}


if __name__ == "__main__":
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=int(os.getenv("PORT", 8000)),
        log_config="log_conf.yaml",
        forwarded_allow_ips="*",
    )
