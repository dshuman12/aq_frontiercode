#!/usr/bin/env python3
"""
Interactive FSM simulator: send messages back and forth in one thread.

Usage:
  export API_AUTH_TOKEN=your_service_account_key   # or use .env.local
  export FSM_FROM_EMAIL=brand@acme.com             # optional, default below
  export FSM_TO_EMAIL=chikaosro@creator.userepflow.com
  pipenv run python scripts/fsm_chat.py

Then type the prospect's message and press Enter. The agent reply is printed.
Type 'quit' or 'exit' to stop. Thread ID is kept so the conversation continues.
"""

import json
import os
import sys

try:
    from dotenv import load_dotenv
    load_dotenv()
    load_dotenv(".env.local")
except ImportError:
    pass

import urllib.request
import urllib.error

BASE_URL = os.environ.get("API_BASE_URL", "http://localhost:8000").rstrip("/")
API_TOKEN = os.environ.get("API_AUTH_TOKEN", "")
DEFAULT_FROM = os.environ.get("FSM_FROM_EMAIL", "brand@acme.com")
DEFAULT_TO = os.environ.get("FSM_TO_EMAIL", "chikaosro@creator.userepflow.com")
SUBJECT = "Partnership inquiry"


def send_message(content: str, thread_id: str | None = None) -> dict:
    """POST to /fsm/simulate/email and return the JSON response."""
    url = f"{BASE_URL}/fsm/simulate/email"
    body = {
        "subject": SUBJECT,
        "from_email": DEFAULT_FROM,
        "to_email": DEFAULT_TO,
        "content": content.strip(),
    }
    if thread_id:
        body["thread_id"] = thread_id

    req = urllib.request.Request(
        url,
        data=json.dumps(body).encode("utf-8"),
        headers={
            "Authorization": f"ServiceAccount {API_TOKEN}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=60) as resp:
        return json.loads(resp.read().decode("utf-8"))


def main():
    if not API_TOKEN:
        print("Set API_AUTH_TOKEN (e.g. in .env.local) and try again.", file=sys.stderr)
        sys.exit(1)

    thread_id: str | None = None
    print("FSM chat (prospect → agent). Same thread for the whole session.")
    print("Type your message and Enter. 'quit' or 'exit' to stop.\n")

    while True:
        try:
            user_input = input("You (prospect): ").strip()
        except EOFError:
            break
        if not user_input:
            continue
        if user_input.lower() in ("quit", "exit", "q"):
            break

        try:
            out = send_message(user_input, thread_id=thread_id)
        except urllib.error.HTTPError as e:
            print(f"Error {e.code}: {e.read().decode()}\n")
            continue
        except Exception as e:
            print(f"Error: {e}\n")
            continue

        thread_id = out.get("thread_id") or thread_id
        reply = out.get("reply_message") or {}
        content = reply.get("content") or out.get("fsm_result", {}).get("response_to_send") or "(no reply)"
        state = out.get("lead_state") or out.get("fsm_result", {}).get("new_state") or "?"

        print(f"\nAgent ({state}): {content}\n")


if __name__ == "__main__":
    main()
