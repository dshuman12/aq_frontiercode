#!/usr/bin/env bash
# Clone prod Repflow JSON secret into a new secret for dev App Runner (test Stripe + dev API_BASE_URL).
# Requires: aws CLI, jq, permission secretsmanager:GetSecretValue + CreateSecret (or PutSecretValue).
#
# Interactive: run with no args; you will be prompted.
# Non-interactive: set DEV_API_BASE, and optionally DEV_STRIPE_SECRET, DEV_STRIPE_WHSEC, DEV_SECRET_ID, AWS_REGION.
set -euo pipefail

REGION="${AWS_REGION:-us-east-2}"
# Default matches friendly name in this account; override if yours differs (e.g. legacy name).
PROD_SECRET_ID="${PROD_SECRET_ID:-prod/Repflow}"
NEW_SECRET_ID="${DEV_SECRET_ID:-dev/Repflow-stack}"

echo "Reading prod secret: $PROD_SECRET_ID ($REGION)..."
RAW=$(aws secretsmanager get-secret-value --secret-id "$PROD_SECRET_ID" --region "$REGION" --query SecretString --output text)

if ! echo "$RAW" | jq -e . >/dev/null 2>&1; then
  echo "Error: prod secret must be a JSON object (same shape as console \"plaintext\" key/value secret)."
  exit 1
fi

if [[ -n "${DEV_API_BASE:-}" ]]; then
  DEV_API_BASE_RESOLVED="$DEV_API_BASE"
else
  read -r -p "Dev App Runner API_BASE_URL (e.g. https://xxxx.us-east-2.awsapprunner.com): " DEV_API_BASE_RESOLVED
fi

if [[ -n "${DEV_STRIPE_SECRET+x}" ]]; then
  DEV_STRIPE="${DEV_STRIPE_SECRET-}"
elif [[ "${DEV_NONINTERACTIVE:-}" == "1" ]]; then
  DEV_STRIPE=""
else
  read -r -p "Stripe STRIPE_SECRET_KEY for dev [sk_test_...] (leave blank to keep prod value — not recommended): " DEV_STRIPE
fi

if [[ -n "${DEV_STRIPE_WHSEC+x}" ]]; then
  DEV_WHSEC="${DEV_STRIPE_WHSEC-}"
elif [[ "${DEV_NONINTERACTIVE:-}" == "1" ]]; then
  DEV_WHSEC=""
else
  read -r -p "Stripe STRIPE_WEBHOOK_SECRET for dev [whsec_... test] (leave blank to keep prod value): " DEV_WHSEC
fi

NEW_JSON=$(echo "$RAW" | jq --arg api "${DEV_API_BASE_RESOLVED:-}" \
  --arg sk "${DEV_STRIPE:-}" --arg wh "${DEV_WHSEC:-}" '
  .API_BASE_URL = (if $api != "" then $api else .API_BASE_URL end)
  | .STRIPE_SECRET_KEY = (if $sk != "" then $sk else .STRIPE_SECRET_KEY end)
  | .STRIPE_WEBHOOK_SECRET = (if $wh != "" then $wh else .STRIPE_WEBHOOK_SECRET end)
')

if aws secretsmanager describe-secret --secret-id "$NEW_SECRET_ID" --region "$REGION" &>/dev/null; then
  echo "Updating existing secret $NEW_SECRET_ID"
  aws secretsmanager put-secret-value --secret-id "$NEW_SECRET_ID" --region "$REGION" --secret-string "$NEW_JSON"
else
  echo "Creating secret $NEW_SECRET_ID"
  aws secretsmanager create-secret --name "$NEW_SECRET_ID" --region "$REGION" --secret-string "$NEW_JSON"
fi

ARN=$(aws secretsmanager describe-secret --secret-id "$NEW_SECRET_ID" --region "$REGION" --query ARN --output text)
echo ""
echo "Dev secret ARN: $ARN"
echo ""
echo "Paste this block into apprunner.dev.yaml (replace the entire 'secrets:' section), then mirror the same"
echo "secret key bindings in the App Runner console for your DEV service, or commit and redeploy."
echo ""
KEYS=(MONGODB_URL STRIPE_SECRET_KEY STRIPE_WEBHOOK_SECRET API_BASE_URL API_AUTH_TOKEN DEMO_EMAIL_AGENT_DISABLE_SEND OPENAI_API_KEY)
echo "  secrets:"
for k in "${KEYS[@]}"; do
  echo "    - name: $k"
  echo "      value-from: \"${ARN}:${k}::\""
done
echo ""
