#!/usr/bin/env python3
"""
Check service account permissions and help fix 403 errors.
"""

import os
import sys
import json

try:
    from dotenv import load_dotenv
    load_dotenv()
    load_dotenv(".env.local")
except ImportError:
    pass

import urllib.request
import urllib.error

BASE_URL = os.environ.get("API_BASE_URL", "http://localhost:8000").rstrip("/")
API_TOKEN = os.environ.get("API_AUTH_TOKEN", "")


def check_permissions():
    """Check what permissions the current service account has."""
    url = f"{BASE_URL}/service-accounts/me"
    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"ServiceAccount {API_TOKEN}",
            "Content-Type": "application/json",
        },
        method="GET",
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return data
    except urllib.error.HTTPError as e:
        if e.code == 403:
            print("❌ 403 Forbidden - Service account doesn't have 'service_accounts:read' permission")
            return None
        print(f"❌ Error {e.code}: {e.read().decode()}")
        return None
    except Exception as e:
        print(f"❌ Error: {e}")
        return None


def main():
    if not API_TOKEN:
        print("❌ Set API_AUTH_TOKEN (e.g. in .env.local) and try again.", file=sys.stderr)
        sys.exit(1)

    print("🔍 Checking Service Account Permissions\n")
    print("=" * 60)
    
    account_info = check_permissions()
    
    if account_info:
        print(f"✅ Service Account: {account_info.get('service_name', 'Unknown')}")
        print(f"📋 Status: {account_info.get('status', 'Unknown')}")
        print(f"\n📝 Current Permissions ({len(account_info.get('permissions', []))}):")
        for perm in account_info.get('permissions', []):
            print(f"   - {perm}")
        
        required_perms = ["deals:create", "deals:update", "deals:read"]
        missing_perms = [p for p in required_perms if p not in account_info.get('permissions', [])]
        
        if missing_perms:
            print(f"\n⚠️  Missing Required Permissions:")
            for perm in missing_perms:
                print(f"   - {perm}")
            print("\n💡 To fix this:")
            print("   1. Update the service account in the database to include these permissions")
            print("   2. Or create a new service account with LAMBDA_PERMISSIONS")
            print("   3. Update API_AUTH_TOKEN in .env.local with the new token")
        else:
            print("\n✅ All required permissions are present!")
            print("   If you're still getting 403 errors, check:")
            print("   - Service account status is 'active'")
            print("   - Service account hasn't expired")
            print("   - API token matches the service account")
    else:
        print("\n❌ Could not retrieve service account info.")
        print("\n💡 Possible issues:")
        print("   1. Service account doesn't exist or token is invalid")
        print("   2. Service account doesn't have 'service_accounts:read' permission")
        print("   3. Backend server is not running")
        print("\n🔧 To create/update a service account:")
        print("   - Use the /service-accounts/ endpoint (requires admin user auth)")
        print("   - Include 'deals:create', 'deals:update', 'deals:read' permissions")


if __name__ == "__main__":
    main()
