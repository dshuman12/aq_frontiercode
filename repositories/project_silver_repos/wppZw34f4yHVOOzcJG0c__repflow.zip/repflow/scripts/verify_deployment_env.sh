#!/usr/bin/env bash
# Quick checks from docs/DEPLOYMENT-ENVIRONMENTS.md (Quick verification).
# Usage:
#   API_BASE_URL=https://YOUR-DEV.us-east-2.awsapprunner.com ./scripts/verify_deployment_env.sh
#   # or (frontend repo):
#   NEXT_PUBLIC_API_BASE_URL=https://... ./scripts/verify_deployment_env.sh
set -euo pipefail

API="${API_BASE_URL:-${NEXT_PUBLIC_API_BASE_URL:-}}"
if [[ -z "$API" ]]; then
  echo "Set API_BASE_URL or NEXT_PUBLIC_API_BASE_URL (no trailing slash)." >&2
  exit 1
fi
API="${API%/}"

echo "== GET $API/health =="
if command -v curl >/dev/null 2>&1; then
  curl -sfS "$API/health" && echo "" || { echo "curl failed (is the API up?)" >&2; exit 1; }
else
  echo "Install curl to run the HTTP check." >&2
  exit 1
fi

echo ""
echo "== Manual checks (same stack for each environment) =="
echo "  MongoDB: Atlas Data Explorer → repflow_dev gains writes only when using the dev API + MONGODB_DATABASE=repflow_dev."
echo "  Cognito: JWT issuer / pool id matches backend COGNITO_POOL_ID (dev: us-east-2_s82ysRbW8)."
echo "  Frontend: NEXT_PUBLIC_API_BASE_URL and AWS_COGNITO_* both target dev OR prod — never mixed."
echo ""
echo "  Optional: open $API/docs in a browser; if the page calls the API from a non-localhost origin, add it via CORS_ALLOWED_ORIGINS (see DEPLOYMENT-ENVIRONMENTS §6)."
