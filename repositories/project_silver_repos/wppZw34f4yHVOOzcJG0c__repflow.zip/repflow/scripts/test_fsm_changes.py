#!/usr/bin/env python3
"""
Test script to verify all FSM changes:
1. Email signature format
2. Deal type rejection messages
3. Proposal link (public)
4. Booking link phrasing
5. Brand comment removal
"""

import json
import os
import sys
import time

try:
    from dotenv import load_dotenv
    load_dotenv()
    load_dotenv(".env.local")
except ImportError:
    pass

import urllib.request
import urllib.error

BASE_URL = os.environ.get("API_BASE_URL", "http://localhost:8000").rstrip("/")
API_TOKEN = os.environ.get("API_AUTH_TOKEN", "")
DEFAULT_FROM = os.environ.get("FSM_FROM_EMAIL", "brand@acme.com")
DEFAULT_TO = os.environ.get("FSM_TO_EMAIL", "chikaosro@creator.userepflow.com")
SUBJECT = "Partnership inquiry"


def send_message(content: str, thread_id: str | None = None) -> dict:
    """POST to /fsm/simulate/email and return the JSON response."""
    url = f"{BASE_URL}/fsm/simulate/email"
    body = {
        "subject": SUBJECT,
        "from_email": DEFAULT_FROM,
        "to_email": DEFAULT_TO,
        "content": content.strip(),
    }
    if thread_id:
        body["thread_id"] = thread_id

    req = urllib.request.Request(
        url,
        data=json.dumps(body).encode("utf-8"),
        headers={
            "Authorization": f"ServiceAccount {API_TOKEN}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=60) as resp:
        return json.loads(resp.read().decode("utf-8"))


def check_signature(response_text: str) -> bool:
    """Check if signature format is correct."""
    has_agent_signature = "'s Agent" in response_text or "Agent" in response_text
    has_support_link = "support@userepflow.com" in response_text or "mailto: support@userepflow.com" in response_text
    return has_agent_signature and has_support_link


def main():
    if not API_TOKEN:
        print("❌ Set API_AUTH_TOKEN (e.g. in .env.local) and try again.", file=sys.stderr)
        sys.exit(1)

    print("🧪 Testing FSM Changes\n")
    print("=" * 60)
    
    thread_id: str | None = None
    tests_passed = 0
    tests_failed = 0
    
    # Test 1: Initial sponsorship inquiry
    print("\n📧 Test 1: Initial sponsorship inquiry")
    print("-" * 60)
    test1_msg = "Hi, we want to sponsor a video. Budget $10k. Brand: Acme. Website: acme.com. Category: Tech. Contact: john@acme.com. Deliverables: 1x YouTube integration."
    print(f"You (prospect): {test1_msg}")
    
    try:
        out = send_message(test1_msg, thread_id=thread_id)
        thread_id = out.get("thread_id") or thread_id
        reply = out.get("reply_message") or {}
        content = reply.get("content") or out.get("fsm_result", {}).get("response_to_send") or "(no reply)"
        state = out.get("lead_state") or out.get("fsm_result", {}).get("new_state") or "?"
        
        print(f"\nAgent ({state}): {content}")
        print(f"\nFull response keys: {list(out.keys())}")
        if 'fsm_result' in out:
            print(f"FSM result: {out.get('fsm_result', {})}")
        
        # Check signature
        if check_signature(content):
            print("✅ Signature format: PASSED")
            tests_passed += 1
        else:
            print("❌ Signature format: FAILED")
            print(f"   Content contains 'Agent': {'Agent' in content}")
            print(f"   Content contains 'support': {'support@userepflow.com' in content}")
            print(f"   Full content length: {len(content)}")
            tests_failed += 1
        
        time.sleep(1)
    except Exception as e:
        print(f"❌ Error: {e}")
        tests_failed += 1
    
    # Test 2: Deal type rejection (Affiliate)
    print("\n📧 Test 2: Deal type rejection (Affiliate)")
    print("-" * 60)
    test2_msg = "We want to do an affiliate partnership. Budget $5000. Brand: TestBrand. Website: testbrand.com. Category: E-commerce. Contact: contact@testbrand.com. Deliverables: 1x YouTube integration."
    print(f"You (prospect): {test2_msg}")
    
    try:
        out = send_message(test2_msg, thread_id=None)  # New thread
        reply = out.get("reply_message") or {}
        content = reply.get("content") or out.get("fsm_result", {}).get("response_to_send") or "(no reply)"
        state = out.get("lead_state") or out.get("fsm_result", {}).get("new_state") or "?"
        
        print(f"\nAgent ({state}): {content}")
        
        # Check for deal type rejection message
        has_deal_type_rejection = "not accepting new" in content.lower() and "affiliate" in content.lower()
        has_flexibility_ask = "flexibility" in content.lower() and "re-evaluate" in content.lower()
        
        if has_deal_type_rejection and has_flexibility_ask:
            print("✅ Deal type rejection message: PASSED")
            tests_passed += 1
        else:
            print("❌ Deal type rejection message: FAILED")
            print(f"   Expected: 'not accepting new Affiliate partnerships' and 'flexibility'")
            tests_failed += 1
        
        time.sleep(1)
    except Exception as e:
        print(f"❌ Error: {e}")
        tests_failed += 1
    
    # Test 3: Budget below minimum (should ask about rates)
    print("\n📧 Test 3: Budget below minimum")
    print("-" * 60)
    test3_msg = "Hi, we want to sponsor a video. Budget $500. Brand: LowBudget. Website: lowbudget.com. Category: Tech. Contact: contact@lowbudget.com. Deliverables: 1x YouTube integration."
    print(f"You (prospect): {test3_msg}")
    
    try:
        out = send_message(test3_msg, thread_id=None)  # New thread
        reply = out.get("reply_message") or {}
        content = reply.get("content") or out.get("fsm_result", {}).get("response_to_send") or "(no reply)"
        state = out.get("lead_state") or out.get("fsm_result", {}).get("new_state") or "?"
        
        print(f"\nAgent ({state}): {content[:200]}...")
        
        # Check for budget rejection or rate range
        has_budget_rejection = "below" in content.lower() and "minimum" in content.lower()
        has_rate_range = "range from" in content.lower() and "$" in content
        
        if has_budget_rejection or has_rate_range:
            print("✅ Budget handling: PASSED")
            tests_passed += 1
        else:
            print("❌ Budget handling: FAILED")
            tests_failed += 1
        
        time.sleep(1)
    except Exception as e:
        print(f"❌ Error: {e}")
        tests_failed += 1
    
    # Test 4: Ask for preferred rate
    print("\n📧 Test 4: Ask for preferred rate")
    print("-" * 60)
    test4_msg = "What is your preferred rate for a YouTube integration?"
    print(f"You (prospect): {test4_msg}")
    
    try:
        out = send_message(test4_msg, thread_id=None)  # New thread
        reply = out.get("reply_message") or {}
        content = reply.get("content") or out.get("fsm_result", {}).get("response_to_send") or "(no reply)"
        state = out.get("lead_state") or out.get("fsm_result", {}).get("new_state") or "?"
        
        print(f"\nAgent ({state}): {content}")
        
        # Check for rate range response
        has_rate_range = "range from" in content.lower() and "$" in content
        
        if has_rate_range:
            print("✅ Rate range response: PASSED")
            tests_passed += 1
        else:
            print("❌ Rate range response: FAILED")
            tests_failed += 1
        
        time.sleep(1)
    except Exception as e:
        print(f"❌ Error: {e}")
        tests_failed += 1
    
    # Test 5: Qualified deal (check proposal link)
    print("\n📧 Test 5: Qualified deal (check proposal link)")
    print("-" * 60)
    test5_msg = "Hi, we want to sponsor a video. Budget $15k. Brand: QualifiedBrand. Website: qualified.com. Category: Tech. Contact: contact@qualified.com. Deliverables: 1x YouTube integration. Deadline: March 2026."
    print(f"You (prospect): {test5_msg}")
    
    try:
        out = send_message(test5_msg, thread_id=None)  # New thread
        reply = out.get("reply_message") or {}
        content = reply.get("content") or out.get("fsm_result", {}).get("response_to_send") or "(no reply)"
        state = out.get("lead_state") or out.get("fsm_result", {}).get("new_state") or "?"
        
        print(f"\nAgent ({state}): {content}")
        
        # Check for proposal link (should be public, no userId)
        has_proposal_link = "/proposal" in content
        has_userid_param = "userId=" in content
        
        if has_proposal_link and not has_userid_param:
            print("✅ Proposal link (public): PASSED")
            tests_passed += 1
        elif has_proposal_link:
            print("⚠️  Proposal link found but still has userId parameter")
            tests_failed += 1
        else:
            print("⚠️  Proposal link not found in response")
        
        # Check for booking link phrasing if present
        if "calendar:" in content.lower() or "calendly" in content.lower():
            has_correct_phrasing = "discuss the partner details" in content.lower() or "brief call" in content.lower()
            if has_correct_phrasing:
                print("✅ Booking link phrasing: PASSED")
                tests_passed += 1
            else:
                print("⚠️  Booking link found but phrasing may need update")
        
        time.sleep(1)
    except Exception as e:
        print(f"❌ Error: {e}")
        tests_failed += 1
    
    # Summary
    print("\n" + "=" * 60)
    print("📊 Test Summary")
    print("=" * 60)
    print(f"✅ Passed: {tests_passed}")
    print(f"❌ Failed: {tests_failed}")
    print(f"📈 Total: {tests_passed + tests_failed}")
    
    if tests_failed == 0:
        print("\n🎉 All tests passed!")
        return 0
    else:
        print(f"\n⚠️  {tests_failed} test(s) failed. Please review the output above.")
        return 1


if __name__ == "__main__":
    sys.exit(main())
