#!/usr/bin/env python3
"""
Test FSM changes that don't require deal creation.
This tests: signatures, booking links, deal type rejections, rate ranges.
"""

import json
import os
import sys
import time

try:
    from dotenv import load_dotenv
    load_dotenv()
    load_dotenv(".env.local")
except ImportError:
    pass

import urllib.request
import urllib.error

BASE_URL = os.environ.get("API_BASE_URL", "http://localhost:8000").rstrip("/")
API_TOKEN = os.environ.get("API_AUTH_TOKEN", "")
DEFAULT_FROM = os.environ.get("FSM_FROM_EMAIL", "brand@acme.com")
DEFAULT_TO = os.environ.get("FSM_TO_EMAIL", "chikaosro@creator.userepflow.com")
SUBJECT = "Partnership inquiry"


def send_message(content: str, thread_id: str | None = None) -> dict:
    """POST to /fsm/simulate/email and return the JSON response."""
    url = f"{BASE_URL}/fsm/simulate/email"
    body = {
        "subject": SUBJECT,
        "from_email": DEFAULT_FROM,
        "to_email": DEFAULT_TO,
        "content": content.strip(),
    }
    if thread_id:
        body["thread_id"] = thread_id

    req = urllib.request.Request(
        url,
        data=json.dumps(body).encode("utf-8"),
        headers={
            "Authorization": f"ServiceAccount {API_TOKEN}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=60) as resp:
        return json.loads(resp.read().decode("utf-8"))


def check_signature(response_text: str) -> tuple[bool, str]:
    """Check if signature format is correct."""
    has_agent = "'s Agent" in response_text or "Agent" in response_text
    has_support = "support@userepflow.com" in response_text or "mailto: support@userepflow.com" in response_text
    has_best = "Best," in response_text
    
    if has_agent and has_support and has_best:
        return True, "✅ Signature format correct"
    else:
        missing = []
        if not has_best:
            missing.append("'Best,'")
        if not has_agent:
            missing.append("'Agent'")
        if not has_support:
            missing.append("'support@userepflow.com'")
        return False, f"❌ Missing: {', '.join(missing)}"


def main():
    if not API_TOKEN:
        print("❌ Set API_AUTH_TOKEN (e.g. in .env.local) and try again.", file=sys.stderr)
        sys.exit(1)

    print("🧪 Testing FSM Changes (Without Deal Creation)\n")
    print("=" * 70)
    
    thread_id: str | None = None
    tests_passed = 0
    tests_failed = 0
    
    # Test 1: Ask for preferred rate (should get rate range, no deal creation needed)
    print("\n📧 Test 1: Ask for preferred rate")
    print("-" * 70)
    test1_msg = "What is your preferred rate for a YouTube integration?"
    print(f"You (prospect): {test1_msg}")
    
    try:
        out = send_message(test1_msg, thread_id=None)
        reply = out.get("reply_message") or {}
        content = reply.get("content") or out.get("fsm_result", {}).get("response_to_send") or "(no reply)"
        state = out.get("lead_state") or out.get("fsm_result", {}).get("new_state") or "?"
        
        print(f"\nAgent ({state}):")
        print(content)
        print()
        
        # Check signature
        sig_ok, sig_msg = check_signature(content)
        print(sig_msg)
        if sig_ok:
            tests_passed += 1
        else:
            tests_failed += 1
        
        # Check for rate range
        has_rate_range = "range from" in content.lower() and "$" in content
        if has_rate_range:
            print("✅ Rate range response: PASSED")
            tests_passed += 1
        else:
            print("⚠️  Rate range not found (may be in different state)")
        
        # Check booking link phrasing
        if "calendar:" in content.lower() or "calendly" in content.lower():
            has_correct_phrasing = "discuss the partner details" in content.lower() or "brief call" in content.lower()
            if has_correct_phrasing:
                print("✅ Booking link phrasing: PASSED")
                tests_passed += 1
            else:
                print("⚠️  Booking link found but phrasing may need update")
        
        time.sleep(1)
    except Exception as e:
        print(f"❌ Error: {e}")
        tests_failed += 1
    
    # Test 2: Low budget (should reject, no deal creation)
    print("\n📧 Test 2: Budget below minimum")
    print("-" * 70)
    test2_msg = "Hi, we want to sponsor a video. Budget $500. Brand: LowBudget. Website: lowbudget.com. Category: Tech. Contact: contact@lowbudget.com. Deliverables: 1x YouTube integration."
    print(f"You (prospect): {test2_msg[:80]}...")
    
    try:
        out = send_message(test2_msg, thread_id=None)
        reply = out.get("reply_message") or {}
        content = reply.get("content") or out.get("fsm_result", {}).get("response_to_send") or "(no reply)"
        state = out.get("lead_state") or out.get("fsm_result", {}).get("new_state") or "?"
        
        print(f"\nAgent ({state}):")
        print(content[:300] + "..." if len(content) > 300 else content)
        print()
        
        # Check signature
        sig_ok, sig_msg = check_signature(content)
        print(sig_msg)
        if sig_ok:
            tests_passed += 1
        else:
            tests_failed += 1
        
        # Check for budget rejection
        has_budget_rejection = "below" in content.lower() and "minimum" in content.lower()
        if has_budget_rejection:
            print("✅ Budget rejection message: PASSED")
            tests_passed += 1
        else:
            print("⚠️  Budget rejection message not found")
        
        time.sleep(1)
    except Exception as e:
        print(f"❌ Error: {e}")
        tests_failed += 1
    
    # Test 3: Affiliate deal type (should reject with specific message)
    print("\n📧 Test 3: Affiliate deal type rejection")
    print("-" * 70)
    test3_msg = "We want to do an affiliate partnership. Budget $5000. Brand: TestBrand. Website: testbrand.com. Category: E-commerce. Contact: contact@testbrand.com. Deliverables: 1x YouTube integration."
    print(f"You (prospect): {test3_msg[:80]}...")
    
    try:
        out = send_message(test3_msg, thread_id=None)
        reply = out.get("reply_message") or {}
        content = reply.get("content") or out.get("fsm_result", {}).get("response_to_send") or "(no reply)"
        state = out.get("lead_state") or out.get("fsm_result", {}).get("new_state") or "?"
        
        print(f"\nAgent ({state}):")
        print(content)
        print()
        
        # Check signature
        sig_ok, sig_msg = check_signature(content)
        print(sig_msg)
        if sig_ok:
            tests_passed += 1
        else:
            tests_failed += 1
        
        # Check for deal type rejection
        has_deal_type_rejection = "not accepting new" in content.lower() and "affiliate" in content.lower()
        has_flexibility = "flexibility" in content.lower() and "re-evaluate" in content.lower()
        
        if has_deal_type_rejection and has_flexibility:
            print("✅ Deal type rejection message: PASSED")
            tests_passed += 1
        elif has_deal_type_rejection:
            print("⚠️  Deal type rejection found but missing flexibility ask")
        else:
            print("⚠️  Deal type rejection message not found")
        
        time.sleep(1)
    except Exception as e:
        print(f"❌ Error: {e}")
        tests_failed += 1
    
    # Summary
    print("\n" + "=" * 70)
    print("📊 Test Summary")
    print("=" * 70)
    print(f"✅ Passed: {tests_passed}")
    print(f"❌ Failed: {tests_failed}")
    print(f"📈 Total: {tests_passed + tests_failed}")
    
    if tests_failed == 0:
        print("\n🎉 All tests passed!")
        return 0
    else:
        print(f"\n⚠️  {tests_failed} test(s) failed or need attention.")
        print("\n💡 Note: Some features require deal creation to fully test.")
        print("   Fix authentication first, then run: pipenv run python scripts/test_fsm_changes.py")
        return 1


if __name__ == "__main__":
    sys.exit(main())
