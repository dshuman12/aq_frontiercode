#!/usr/bin/env bash
#
# Deploy repflow email handler to AWS Lambda from the terminal (AWS CLI).
# Run from project root. Requires: aws CLI, zip already built (lambda_handler/lambda_deployment_package.zip).
#
# 1) Set env vars (export or create scripts/deploy.env and source it):
#    API_BASE_URL, API_AUTH_TOKEN, S3_BUCKET, SES_REGION, OPENAI_API_KEY
#    LAMBDA_FUNCTION_NAME (default: repflow-email-handler)
#    AWS_REGION (default: us-east-2)
#
# 2) One-time: create IAM role and Lambda:
#    ./scripts/deploy_lambda.sh create
#
# 3) Update code + config (env vars, timeout, memory):
#    ./scripts/deploy_lambda.sh update
#
# 4) Code-only (quick redeploy):
#    ./scripts/deploy_lambda.sh code
#
# 5) SES trigger (no console): add receipt rule so SES invokes Lambda + stores email in S3:
#    ./scripts/deploy_lambda.sh ses-trigger
#    Optional: RECIPIENT_DOMAIN=repflow.me (default) — mail to *@repflow.me triggers the rule.
#

set -e

FUNCTION_NAME="${LAMBDA_FUNCTION_NAME:-repflow-email-handler}"
AWS_REGION="${AWS_REGION:-us-east-2}"
ZIP_PATH="lambda_handler/lambda_deployment_package.zip"
ROLE_NAME="${FUNCTION_NAME}-role"
POLICY_NAME="${FUNCTION_NAME}-policy"

# Optional: load deploy env (create from .env.local and remove secrets you don't want in shell history)
if [ -f "scripts/deploy.env" ]; then
  set -a
  source scripts/deploy.env
  set +a
fi

required_vars="API_BASE_URL API_AUTH_TOKEN S3_BUCKET SES_REGION OPENAI_API_KEY"
check_vars() {
  for v in $required_vars; do
    if [ -z "${!v}" ]; then
      echo "Missing required env var: $v"
      exit 1
    fi
  done
}

# Create IAM role for Lambda (one-time). Prints only the role ARN to stdout (for capture).
create_role() {
  ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
  ROLE_ARN="arn:aws:iam::${ACCOUNT_ID}:role/${ROLE_NAME}"

  if aws iam get-role --role-name "$ROLE_NAME" >/dev/null 2>&1; then
    echo "Role $ROLE_NAME already exists: $ROLE_ARN" >&2
    echo "$ROLE_ARN"
    return
  fi

  aws iam create-role \
    --role-name "$ROLE_NAME" \
    --assume-role-policy-document '{
      "Version": "2012-10-17",
      "Statement": [{
        "Effect": "Allow",
        "Principal": { "Service": "lambda.amazonaws.com" },
        "Action": "sts:AssumeRole"
      }]
    }' >/dev/null

  aws iam attach-role-policy \
    --role-name "$ROLE_NAME" \
    --policy-arn "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole" >/dev/null

  # Inline policy: S3 GetObject on bucket, SES SendEmail in region
  aws iam put-role-policy \
    --role-name "$ROLE_NAME" \
    --policy-name "$POLICY_NAME" \
    --policy-document "{
      \"Version\": \"2012-10-17\",
      \"Statement\": [
        {
          \"Effect\": \"Allow\",
          \"Action\": [\"s3:GetObject\"],
          \"Resource\": \"arn:aws:s3:::${S3_BUCKET}/emails/*\"
        },
        {
          \"Effect\": \"Allow\",
          \"Action\": [\"ses:SendEmail\", \"ses:SendRawEmail\"],
          \"Resource\": \"*\"
        }
      ]
    }" >/dev/null

  echo "Created role $ROLE_ARN (wait 10s for IAM propagation)..." >&2
  sleep 10
  echo "$ROLE_ARN"
}

cmd="${1:-update}"
case "$cmd" in
  create)
    check_vars
    if [ ! -f "$ZIP_PATH" ]; then
      echo "Build the zip first: cd lambda_handler && python package.py"
      exit 1
    fi
    ROLE_ARN=$(create_role)
    echo "Creating Lambda function..."
    aws lambda create-function \
      --region "$AWS_REGION" \
      --function-name "$FUNCTION_NAME" \
      --runtime python3.13 \
      --handler lambda_function.lambda_handler \
      --role "$ROLE_ARN" \
      --zip-file "fileb://${ZIP_PATH}" \
      --timeout 120 \
      --memory-size 512
    echo "Created. Run './scripts/deploy_lambda.sh update' to set env vars."
    ;;
  update)
    check_vars
    if [ ! -f "$ZIP_PATH" ]; then
      echo "Build the zip first: cd lambda_handler && python package.py"
      exit 1
    fi
    echo "Updating code..."
    aws lambda update-function-code \
      --region "$AWS_REGION" \
      --function-name "$FUNCTION_NAME" \
      --zip-file "fileb://${ZIP_PATH}"
    echo "Updating config (timeout, memory, env)..."
    if command -v jq >/dev/null 2>&1; then
      ENV_JSON=$(jq -n \
        --arg u "$API_BASE_URL" --arg t "$API_AUTH_TOKEN" --arg b "$S3_BUCKET" \
        --arg r "$SES_REGION" --arg o "$OPENAI_API_KEY" \
        '{Variables: {API_BASE_URL: $u, API_AUTH_TOKEN: $t, S3_BUCKET: $b, SES_REGION: $r, OPENAI_API_KEY: $o}}')
      [ -n "${FRONTEND_URL:-}" ] && ENV_JSON=$(echo "$ENV_JSON" | jq --arg f "$FRONTEND_URL" '.Variables.FRONTEND_URL = $f')
      [ -n "${DEMO_EMAIL_AGENT_DISABLE_SEND:-}" ] && ENV_JSON=$(echo "$ENV_JSON" | jq --arg d "$DEMO_EMAIL_AGENT_DISABLE_SEND" '.Variables.DEMO_EMAIL_AGENT_DISABLE_SEND = $d')
    else
      ENV_JSON="{\"Variables\":{\"API_BASE_URL\":\"${API_BASE_URL//\"/\\\"}\",\"API_AUTH_TOKEN\":\"${API_AUTH_TOKEN//\"/\\\"}\",\"S3_BUCKET\":\"${S3_BUCKET//\"/\\\"}\",\"SES_REGION\":\"${SES_REGION//\"/\\\"}\",\"OPENAI_API_KEY\":\"${OPENAI_API_KEY//\"/\\\"}\"}}"
    fi
    aws lambda update-function-configuration \
      --region "$AWS_REGION" \
      --function-name "$FUNCTION_NAME" \
      --timeout 120 \
      --memory-size 512 \
      --environment "$ENV_JSON"
    echo "Done. Trigger: add Lambda action to your SES receipt rule (SES console or CLI)."
    ;;
  code)
    if [ ! -f "$ZIP_PATH" ]; then
      echo "Build the zip first: cd lambda_handler && python package.py"
      exit 1
    fi
    aws lambda update-function-code \
      --region "$AWS_REGION" \
      --function-name "$FUNCTION_NAME" \
      --zip-file "fileb://${ZIP_PATH}"
    echo "Code updated."
    ;;
  ses-trigger)
    if [ -z "${S3_BUCKET:-}" ] || [ -z "${SES_REGION:-}" ]; then
      echo "Missing S3_BUCKET or SES_REGION (set in scripts/deploy.env or export)."
      exit 1
    fi
    RECIPIENT_DOMAIN="${RECIPIENT_DOMAIN:-repflow.me}"
    RULE_SET_NAME="${SES_RULE_SET_NAME:-default}"
    ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
    FUNC_ARN="arn:aws:lambda:${AWS_REGION}:${ACCOUNT_ID}:function:${FUNCTION_NAME}"
    echo "Adding Lambda permission for SES to invoke..."
    aws lambda add-permission \
      --region "$AWS_REGION" \
      --function-name "$FUNCTION_NAME" \
      --statement-id "ses-invoke-repflow" \
      --action "lambda:InvokeFunction" \
      --principal "ses.amazonaws.com" 2>/dev/null || true
    echo "Adding SES receipt rule (S3 + Lambda) in region $SES_REGION..."
    if command -v jq >/dev/null 2>&1; then
      RULE_JSON=$(jq -n \
        --arg name "RepflowEmailHandler" \
        --arg bucket "$S3_BUCKET" \
        --arg fn "$FUNC_ARN" \
        --arg domain "$RECIPIENT_DOMAIN" \
        '{
          Name: $name,
          Enabled: true,
          Recipients: [$domain],
          Actions: [
            { S3Action: { BucketName: $bucket, ObjectKeyPrefix: "emails/" } },
            { LambdaAction: { FunctionArn: $fn, InvocationType: "Event" } }
          ]
        }')
    else
      RULE_JSON="{\"Name\":\"RepflowEmailHandler\",\"Enabled\":true,\"Recipients\":[\"${RECIPIENT_DOMAIN}\"],\"Actions\":[{\"S3Action\":{\"BucketName\":\"${S3_BUCKET}\",\"ObjectKeyPrefix\":\"emails/\"}},{\"LambdaAction\":{\"FunctionArn\":\"${FUNC_ARN}\",\"InvocationType\":\"Event\"}}]}"
    fi
    if ! aws ses create-receipt-rule \
      --region "$SES_REGION" \
      --rule-set-name "$RULE_SET_NAME" \
      --rule "$RULE_JSON" 2>/dev/null; then
      echo "Rule exists, updating..."
      aws ses update-receipt-rule \
        --region "$SES_REGION" \
        --rule-set-name "$RULE_SET_NAME" \
        --rule "$RULE_JSON"
    fi
    echo "Done. Mail to *@${RECIPIENT_DOMAIN} will be stored in s3://${S3_BUCKET}/emails/ and trigger ${FUNCTION_NAME}."
    echo "Ensure the default rule set is active: aws ses set-active-receipt-rule-set --region $SES_REGION --rule-set-name $RULE_SET_NAME"
    ;;
  *)
    echo "Usage: $0 create | update | code | ses-trigger"
    echo "  create      - one-time: create IAM role + Lambda function"
    echo "  update      - update code + config (env vars, timeout, memory)"
    echo "  code        - update code only"
    echo "  ses-trigger - add SES receipt rule (S3 + Lambda) so mail triggers the handler (no console)"
    exit 1
    ;;
esac
