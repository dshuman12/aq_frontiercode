#!/usr/bin/env python3
"""
Script to help fix service account authentication issues.
This script will help you create or update a service account with the correct permissions.
"""

import os
import sys
import json

try:
    from dotenv import load_dotenv
    load_dotenv()
    load_dotenv(".env.local")
except ImportError:
    pass

BASE_URL = os.environ.get("API_BASE_URL", "http://localhost:8000").rstrip("/")

# Required permissions for Lambda/FSM to work
LAMBDA_PERMISSIONS = [
    "leads:read",
    "leads:create",
    "leads:update",
    "deals:create",
    "deals:update",
    "deals:read",
    "processed_emails:read",
    "processed_emails:create",
    "blacklist:read",
    "users:read_by_email",
    "users:read_preferences",
    "messages:create",
    "conversations:read",
    "conversations:create",
    "conversations:update",
    "brands:read",
    "brands:create",
    "contacts:read",
    "contacts:create",
    "service_accounts:read",  # For self-introspection
]


def print_instructions():
    """Print instructions for creating/updating service account."""
    print("=" * 70)
    print("🔧 Service Account Setup Instructions")
    print("=" * 70)
    print("\nTo fix the 403 authentication errors, you need to:")
    print("\n1. Create or update a service account with these permissions:")
    print("\n   Required Permissions:")
    for perm in LAMBDA_PERMISSIONS:
        print(f"      - {perm}")
    
    print("\n2. Option A: Create via API (requires admin user JWT token):")
    print("""
   curl -X POST "http://localhost:8000/service-accounts/" \\
     -H "Authorization: Bearer YOUR_ADMIN_JWT_TOKEN" \\
     -H "Content-Type: application/json" \\
     -d '{
       "service_name": "email_automation_lambda",
       "permissions": """ + json.dumps(LAMBDA_PERMISSIONS, indent=6) + """,
       "description": "Lambda handler for email automation FSM"
     }'
   
   Save the returned 'api_key' and update API_AUTH_TOKEN in .env.local
   """)
    
    print("\n3. Option B: Update existing service account via MongoDB:")
    print("""
   Connect to MongoDB and run:
   
   db.service_accounts.updateOne(
     { service_name: "email_automation_lambda" },
     { 
       $set: { 
         permissions: """ + json.dumps(LAMBDA_PERMISSIONS, indent=9) + """,
         status: "active"
       }
     }
   )
   """)
    
    print("\n4. Option C: Create via Python script (if you have admin access):")
    print("""
   from database.models.service_account import ServiceAccount, LAMBDA_PERMISSIONS
   from auth.service_auth import hash_api_key, generate_api_key
   from datetime import datetime, timezone
   
   # Generate new API key
   api_key = generate_api_key()
   api_key_hash = hash_api_key(api_key)
   
   # Create service account
   service_account = ServiceAccount(
       service_name="email_automation_lambda",
       api_key_hash=api_key_hash,
       permissions=LAMBDA_PERMISSIONS,
       status="active",
       created_by="admin_user_id",
       description="Lambda handler for email automation FSM"
   )
   await service_account.insert()
   
   print(f"Service account created! API Key: {api_key}")
   print("Update API_AUTH_TOKEN in .env.local with this key")
   """)
    
    print("\n5. After updating, verify with:")
    print("   pipenv run python scripts/check_service_account.py")
    print("\n" + "=" * 70)


if __name__ == "__main__":
    print_instructions()
