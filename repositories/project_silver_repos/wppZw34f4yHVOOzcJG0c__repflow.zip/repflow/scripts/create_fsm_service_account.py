"""
Create a service account with FSM/simulator permissions and print its API key.

Run from the project root (repflow/) so imports resolve. Requires MongoDB and
.env / .env.local with MONGODB_URL (and optionally MONGODB_DATABASE).

Usage:
  cd repflow
  pipenv run python scripts/create_fsm_service_account.py

Then copy the printed API key into .env.local as API_AUTH_TOKEN=...
"""

import asyncio
import os
import sys

# Load .env / .env.local when run as script
try:
    from dotenv import load_dotenv
    load_dotenv()
    load_dotenv(".env.local")
except ImportError:
    pass

# Project root = parent of scripts/
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)


async def main():
    from auth.service_auth import generate_api_key, hash_api_key
    from database.database import init_database, close_database
    from database.models.service_account import ServiceAccount, ServiceAccountStatus

    await init_database()

    api_key = generate_api_key()
    sa = ServiceAccount(
        service_name="fsm-simulator",
        api_key_hash=hash_api_key(api_key),
        permissions=[
            "fsm:test",
            "users:read_by_username",
            "leads:read",
            "leads:create",
            "leads:update",
            "processed_emails:read",
            "processed_emails:create",
            "blacklist:read",
            "simple_messages:read",
            "simple_messages:create",
            "conversations:read",
            "conversations:create",
        ],
        status=ServiceAccountStatus.ACTIVE,
        created_by="scripts/create_fsm_service_account",
        description="Service account for FSM simulator and local testing",
    )
    await sa.insert()

    await close_database()

    print("\n  Service account created.")
    print("  Copy this API key and add it to .env.local as API_AUTH_TOKEN=<key>\n")
    print(f"  {api_key}\n")


if __name__ == "__main__":
    asyncio.run(main())
