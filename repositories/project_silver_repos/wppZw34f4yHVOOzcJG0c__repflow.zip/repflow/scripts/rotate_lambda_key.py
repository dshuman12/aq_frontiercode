#!/usr/bin/env python3
"""
Rotate the Lambda service account API key using raw pymongo (no Beanie needed).

1. Connects to MongoDB
2. Finds service account(s)
3. Generates a new API key + SHA256 hash
4. Updates the service account in MongoDB
5. Prints the new key

Usage:
  python3 scripts/rotate_lambda_key.py
"""

import hashlib
import secrets
from pymongo import MongoClient

MONGODB_URL = "mongodb+srv://chikaosro_db_user:ziOBqqY3FibLptO0@dev-repflow.lgywrkz.mongodb.net/repflow?retryWrites=true&w=majority&appName=dev-repflow"
DB_NAME = "repflow"

# Full permissions the Lambda needs
LAMBDA_PERMISSIONS = [
    "leads:read", "leads:create", "leads:update",
    "deals:create", "deals:update", "deals:read",
    "processed_emails:read", "processed_emails:create",
    "blacklist:read",
    "users:read_by_username", "users:read_by_email", "users:read_preferences",
    "messages:create",
    "conversations:read", "conversations:create", "conversations:update",
    "brands:read", "brands:create",
    "contacts:read", "contacts:create",
    "service_accounts:read",
]


def generate_api_key() -> str:
    return secrets.token_urlsafe(32)


def hash_api_key(api_key: str) -> str:
    return hashlib.sha256(api_key.encode()).hexdigest()


def main():
    client = MongoClient(MONGODB_URL)
    db = client[DB_NAME]
    collection = db["service_accounts"]

    # List all service accounts
    all_accounts = list(collection.find({}))
    print(f"\nFound {len(all_accounts)} service account(s):")
    for sa in all_accounts:
        print(f"  - {sa.get('service_name')} | status={sa.get('status')} | last_used={sa.get('last_used_at')}")
        print(f"    hash={sa.get('api_key_hash', '')[:16]}...")

    # Generate new key
    new_key = generate_api_key()
    new_hash = hash_api_key(new_key)

    # Find the Lambda service account
    target = collection.find_one({"service_name": {"$regex": "lambda|email", "$options": "i"}})
    if not target:
        target = collection.find_one({"status": "active"})
    if not target:
        target = collection.find_one({})

    if target:
        print(f"\nRotating key for: {target.get('service_name')}")
        # Merge permissions
        existing_perms = target.get("permissions", [])
        merged = list(set(existing_perms + LAMBDA_PERMISSIONS))

        collection.update_one(
            {"_id": target["_id"]},
            {"$set": {
                "api_key_hash": new_hash,
                "status": "active",
                "permissions": merged,
            }}
        )
        print(f"  Updated hash, status=active, permissions ({len(merged)} perms)")
    else:
        print("\nNo service account found. Creating one...")
        from datetime import datetime, timezone
        import uuid as _uuid
        collection.insert_one({
            "uuid": str(_uuid.uuid4()),
            "service_name": "email_automation_lambda",
            "api_key_hash": new_hash,
            "permissions": LAMBDA_PERMISSIONS,
            "status": "active",
            "created_by": "scripts/rotate_lambda_key",
            "description": "Lambda handler for email automation",
            "created_at": datetime.now(timezone.utc),
        })
        print("  Created new service account.")

    client.close()

    print(f"\n{'='*60}")
    print(f"  NEW API KEY: {new_key}")
    print(f"{'='*60}\n")
    return new_key


if __name__ == "__main__":
    main()
