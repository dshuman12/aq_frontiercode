# Agent Guidelines for Repflow Backend

## Git / App Runner
- **Branch order:** Land changes on **`dev`** first (push `origin/dev`), then merge into **`main`** (`origin/main`). `apprunner.yaml` differs by branch (dev pool vs prod pool); never fast-forward `dev` to `main` without restoring the dev stack in `apprunner.yaml` on `dev`.
- See `docs/DEPLOYMENT-ENVIRONMENTS.md` for prod vs dev Cognito and secrets.

## Build/Lint/Test Commands
- **Run all tests**: `pipenv run test` or `pytest`
- **Run single test**: `pytest tests/test_db.py` (replace with specific test file)
- **Format code**: `pipenv run format` or `black . && isort .`
- **Lint code**: `pipenv run lint` or `flake8 . && mypy .`
- **Start dev server**: `pipenv run dev` or `uvicorn app:app --host 0.0.0.0 --port 8000 --reload --log-level debug`

## Code Style Guidelines
- **Python version**: 3.11+
- **Import style**: Use isort for import organization (standard library first, then third-party, then local)
- **Formatting**: Use Black for code formatting
- **Type hints**: Use Pydantic models and type hints throughout
- **Error handling**: Use FastAPI's HTTPException for API errors, implement proper exception handling middleware
- **Naming**: Use snake_case for variables/functions, PascalCase for classes
- **Database**: Use Beanie ODM with MongoDB, inherit from CRUDDocument for models
- **Authentication**: Use JWTBearer for protected routes, implement proper auth context
- **Async**: Use async/await throughout for database operations and API endpoints

## OAuth (YouTube, Instagram only)
Backend-driven OAuth for portfolio connections. TikTok and X are manual-add only. Set in env:
- **YouTube**: existing `YOUTUBE_CLIENT_ID`, `YOUTUBE_CLIENT_SECRET`, optional `YOUTUBE_REDIRECT_URI` (default: `{REPFLOW_FRONTEND_URL}/auth/youtube/callback`).
- **Instagram**: `INSTAGRAM_OAUTH_CLIENT_ID`, `INSTAGRAM_OAUTH_CLIENT_SECRET`, optional `INSTAGRAM_OAUTH_REDIRECT_URI` (default: `{REPFLOW_FRONTEND_URL}/auth/instagram/callback`).
- **Frontend base**: `REPFLOW_FRONTEND_URL` (e.g. `https://creator.userepflow.com`). Register the callback URLs in each provider’s app config.