"""
Migration Script: Migrate Deal Inline Fields to CRM Entities

This script migrates existing deals that have inline `company` and `keyContacts`
fields to use the CRM Brand and Contact collections instead.

For each deal:
1. If `company` exists: Find or create a Brand with that name, set `brandId`
2. If `keyContacts` exists: Find or create a Contact for primary contact, set `contactId`
3. Remove the old inline fields from the deal document

Usage:
    cd repflow
    pipenv run python migrations/migrate_deal_inline_to_crm.py

Options:
    --dry-run    Preview changes without modifying the database
    --verbose    Show detailed progress for each deal
"""

import asyncio
import argparse
from datetime import datetime, timezone
from typing import Optional
from motor.motor_asyncio import AsyncIOMotorClient
from beanie import init_beanie

from database.models.deal import Deal
from database.models.brand import Brand
from database.models.contact import Contact
from config import get_settings


async def find_or_create_brand(
    user_id: str,
    company_name: str,
    dry_run: bool = False,
    verbose: bool = False
) -> Optional[str]:
    """
    Find an existing brand by name for the user, or create a new one.
    Returns the brand's UUID.
    """
    # Look for existing brand
    existing_brand = await Brand.find_one(
        Brand.user_id == user_id,
        Brand.name == company_name
    )

    if existing_brand:
        if verbose:
            print(f"    Found existing brand: {company_name} (UUID: {existing_brand.uuid})")
        return existing_brand.uuid

    if dry_run:
        if verbose:
            print(f"    [DRY RUN] Would create brand: {company_name}")
        return None

    # Create new brand
    new_brand = Brand(
        name=company_name,
        user_id=user_id,
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    await new_brand.insert()

    if verbose:
        print(f"    Created new brand: {company_name} (UUID: {new_brand.uuid})")

    return new_brand.uuid


async def find_or_create_contact(
    user_id: str,
    contact_data: dict,
    brand_id: Optional[str] = None,
    dry_run: bool = False,
    verbose: bool = False
) -> Optional[str]:
    """
    Find an existing contact by email for the user, or create a new one.
    Returns the contact's UUID.
    """
    email = contact_data.get("email")
    if not email:
        if verbose:
            print(f"    Skipping contact without email: {contact_data.get('name', 'Unknown')}")
        return None

    # Look for existing contact
    existing_contact = await Contact.find_one(
        Contact.user_id == user_id,
        Contact.email == email
    )

    if existing_contact:
        if verbose:
            print(f"    Found existing contact: {email} (UUID: {existing_contact.uuid})")

        # If brand_id provided and not already linked, add it
        if brand_id and brand_id not in existing_contact.brand_ids and not dry_run:
            existing_contact.brand_ids.append(brand_id)
            existing_contact.updated_at = datetime.now(timezone.utc)
            await existing_contact.save()
            if verbose:
                print(f"    Linked contact to brand: {brand_id}")

        return existing_contact.uuid

    if dry_run:
        if verbose:
            print(f"    [DRY RUN] Would create contact: {email}")
        return None

    # Create new contact
    new_contact = Contact(
        name=contact_data.get("name", "Unknown"),
        email=email,
        title=contact_data.get("role") or contact_data.get("title"),
        user_id=user_id,
        brand_ids=[brand_id] if brand_id else [],
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    await new_contact.insert()

    if verbose:
        print(f"    Created new contact: {email} (UUID: {new_contact.uuid})")

    return new_contact.uuid


async def migrate_deals(dry_run: bool = False, verbose: bool = False):
    """
    Main migration function. Iterates through all deals and migrates
    inline company/keyContacts to CRM Brand/Contact references.
    """
    settings = get_settings()

    # Connect to MongoDB
    client = AsyncIOMotorClient(settings.mongodb_url)
    db = client[settings.mongodb_database]

    # Initialize Beanie with all document models
    await init_beanie(database=db, document_models=[Deal, Brand, Contact])

    print("=" * 60)
    print("Deal Inline to CRM Migration")
    print("=" * 60)
    if dry_run:
        print("MODE: DRY RUN (no changes will be made)")
    else:
        print("MODE: LIVE (changes will be applied)")
    print("=" * 60)

    # Get raw collection to find deals with old fields
    deals_collection = db["deals"]

    # Find deals that have company or keyContacts fields
    query = {
        "$or": [
            {"company": {"$exists": True}},
            {"keyContacts": {"$exists": True, "$ne": []}}
        ]
    }

    cursor = deals_collection.find(query)
    deals_to_migrate = await cursor.to_list(length=None)

    print(f"\nFound {len(deals_to_migrate)} deals to migrate\n")

    if len(deals_to_migrate) == 0:
        print("No deals need migration. All done!")
        return

    # Statistics
    stats = {
        "total": len(deals_to_migrate),
        "brands_created": 0,
        "brands_reused": 0,
        "contacts_created": 0,
        "contacts_reused": 0,
        "deals_updated": 0,
        "errors": 0,
    }

    for i, deal_doc in enumerate(deals_to_migrate, 1):
        deal_id = str(deal_doc.get("_id"))
        deal_uuid = deal_doc.get("uuid", deal_id)
        company = deal_doc.get("company")
        key_contacts = deal_doc.get("keyContacts", [])
        user_id = deal_doc.get("userId")

        if verbose:
            print(f"\n[{i}/{stats['total']}] Processing deal: {deal_uuid}")
            print(f"    Company: {company}")
            print(f"    Key Contacts: {len(key_contacts)}")

        if not user_id:
            print(f"  WARNING: Deal {deal_uuid} has no userId, skipping")
            stats["errors"] += 1
            continue

        update_fields = {}
        unset_fields = {}

        # Migrate company to Brand
        brand_id = None
        if company:
            brand_existed = await Brand.find_one(
                Brand.user_id == user_id,
                Brand.name == company
            )

            brand_id = await find_or_create_brand(
                user_id=user_id,
                company_name=company,
                dry_run=dry_run,
                verbose=verbose
            )

            if brand_id:
                update_fields["brandId"] = brand_id
                if brand_existed:
                    stats["brands_reused"] += 1
                else:
                    stats["brands_created"] += 1

            unset_fields["company"] = ""

        # Migrate keyContacts to Contact (use primary contact - first in list)
        if key_contacts and len(key_contacts) > 0:
            primary_contact = key_contacts[0]

            contact_existed = None
            if primary_contact.get("email"):
                contact_existed = await Contact.find_one(
                    Contact.user_id == user_id,
                    Contact.email == primary_contact.get("email")
                )

            contact_id = await find_or_create_contact(
                user_id=user_id,
                contact_data=primary_contact,
                brand_id=brand_id,
                dry_run=dry_run,
                verbose=verbose
            )

            if contact_id:
                update_fields["contactId"] = contact_id
                if contact_existed:
                    stats["contacts_reused"] += 1
                else:
                    stats["contacts_created"] += 1

            unset_fields["keyContacts"] = ""

        # Apply updates to the deal
        if not dry_run and (update_fields or unset_fields):
            update_ops = {}
            if update_fields:
                update_ops["$set"] = update_fields
            if unset_fields:
                update_ops["$unset"] = unset_fields

            await deals_collection.update_one(
                {"_id": deal_doc["_id"]},
                update_ops
            )
            stats["deals_updated"] += 1

            if verbose:
                print(f"    Updated deal with: {update_fields}")
        elif dry_run:
            if verbose:
                print(f"    [DRY RUN] Would update with: {update_fields}")
                print(f"    [DRY RUN] Would remove fields: {list(unset_fields.keys())}")

    # Print summary
    print("\n" + "=" * 60)
    print("Migration Summary")
    print("=" * 60)
    print(f"Total deals processed:    {stats['total']}")
    print(f"Deals updated:            {stats['deals_updated']}")
    print(f"Brands created:           {stats['brands_created']}")
    print(f"Brands reused:            {stats['brands_reused']}")
    print(f"Contacts created:         {stats['contacts_created']}")
    print(f"Contacts reused:          {stats['contacts_reused']}")
    print(f"Errors:                   {stats['errors']}")
    print("=" * 60)

    if dry_run:
        print("\nThis was a DRY RUN. No changes were made.")
        print("Run without --dry-run to apply changes.")
    else:
        print("\nMigration complete!")


def main():
    parser = argparse.ArgumentParser(
        description="Migrate Deal inline fields (company, keyContacts) to CRM entities"
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Preview changes without modifying the database"
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Show detailed progress for each deal"
    )

    args = parser.parse_args()

    asyncio.run(migrate_deals(dry_run=args.dry_run, verbose=args.verbose))


if __name__ == "__main__":
    main()
