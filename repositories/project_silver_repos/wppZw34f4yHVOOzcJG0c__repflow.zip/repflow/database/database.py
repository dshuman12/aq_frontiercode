import logging
import os

import certifi
from pymongo import AsyncMongoClient
from beanie import init_beanie
from .models.deal import Deal
from .models.user import User
from .models.message import Message, Conversation
from .models.lead import LeadQualificationData, ProcessedEmail, BlacklistedEmail
from .models.service_account import ServiceAccount
from .models.referral import Referral
from .models.brand import Brand
from .models.contact import Contact

logger = logging.getLogger("uvicorn.error")


def _sanitize_mongo_url_for_log(url: str) -> str:
    """Redact user:password from a MongoDB URI so logs never leak credentials."""
    for prefix in ("mongodb+srv://", "mongodb://"):
        if url.startswith(prefix):
            rest = url[len(prefix) :]
            if "@" in rest:
                _, host_and_path = rest.split("@", 1)
                return f"{prefix}***:***@{host_and_path}"
    return "***redacted***"


class Database:
    client: AsyncMongoClient = None
    database_name: str = None

    async def connect_to_mongo(self):
        """Create database connection."""
        # Get MongoDB connection string from environment variable
        mongo_url = os.getenv("MONGODB_URL", "mongodb://localhost:27017")
        self.database_name = os.getenv("MONGODB_DATABASE", "repflow")

        # Use certifi CA bundle so TLS to Atlas works on macOS (avoids CERTIFICATE_VERIFY_FAILED)
        logger.info("Connecting to MongoDB %s", _sanitize_mongo_url_for_log(mongo_url))
        self.client = AsyncMongoClient(mongo_url, tlsCAFile=certifi.where())

        # Initialize Beanie with the document models
        await init_beanie(
            database=self.client[self.database_name],
            document_models=[
                Deal,
                User,
                Message,
                Conversation,
                LeadQualificationData,
                ProcessedEmail,
                BlacklistedEmail,
                ServiceAccount,
                Referral,
                Brand,
                Contact,
            ],
        )

        logger.info("Connected to MongoDB database: %s", self.database_name)

    async def close_mongo_connection(self):
        """Close database connection."""
        if self.client:
            await self.client.close()
            logger.info("MongoDB connection closed.")


# Create a global database instance
db = Database()


async def get_database() -> Database:
    """Get database instance."""
    return db


async def get_deals_collection():
    """Get the deals collection."""
    return Deal


# Initialize database connection on startup
async def init_database():
    """Initialize database connection."""
    await db.connect_to_mongo()


# Close database connection on shutdown
async def close_database():
    """Close database connection."""
    await db.close_mongo_connection()
