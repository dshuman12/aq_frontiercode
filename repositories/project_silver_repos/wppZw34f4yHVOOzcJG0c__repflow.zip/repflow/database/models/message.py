from enum import Enum
from typing import List, Optional, Dict, Any
from pydantic import Field, BaseModel, ConfigDict, EmailStr
from datetime import datetime, timezone
from beanie.odm.fields import PydanticObjectId
from .common import CRUDDocument


class MessageType(str, Enum):
    EMAIL = "email"
    AI_ASSISTANT = "ai_assistant"


class ConversationType(str, Enum):
    EMAIL = "email"
    AI_CHAT = "ai_chat"
    PRE_DEAL = "pre_deal"  # Pre-deal conversations before a deal is created


class ConversationStatus(str, Enum):
    ACTIVE = "active"
    DRAFT = "draft"
    ARCHIVED = "archived"
    COMPLETED = "completed"


class MessageStatus(str, Enum):
    SENT = "sent"
    RECEIVED = "received"
    DRAFT = "draft"
    FAILED = "failed"
    PENDING = "pending"


class EmailMessage(BaseModel):
    """Email-specific message data"""
    subject: Optional[str] = Field(None, description="Email subject")
    toEmails: List[EmailStr] = Field(..., description="Recipient email addresses")
    ccEmails: List[EmailStr] = Field(default_factory=list, description="CC email addresses")
    bccEmails: List[EmailStr] = Field(default_factory=list, description="BCC email addresses")
    replyTo: Optional[EmailStr] = Field(None, description="Reply-to email address")
    emailId: Optional[str] = Field(None, description="External email system ID")
    attachments: List[Dict[str, Any]] = Field(default_factory=list, description="Email attachments")
    headers: Dict[str, str] = Field(default_factory=dict, description="Email headers")
    isImportant: bool = Field(default=False, description="Whether the email is marked as important")


class AIAssistantMessage(BaseModel):
    """AI Assistant-specific message data"""
    assistantId: str = Field(..., description="ID of the AI assistant that generated this message")
    assistantName: str = Field(..., description="Name of the AI assistant")
    modelUsed: Optional[str] = Field(None, description="AI model used to generate the message")
    promptTokens: Optional[int] = Field(None, description="Number of tokens in the prompt")
    completionTokens: Optional[int] = Field(None, description="Number of tokens in the completion")
    totalTokens: Optional[int] = Field(None, description="Total tokens used")
    temperature: Optional[float] = Field(None, description="Temperature setting used")
    maxTokens: Optional[int] = Field(None, description="Maximum tokens setting")
    contextData: Dict[str, Any] = Field(default_factory=dict, description="Additional context data used by AI")
    confidenceScore: Optional[float] = Field(None, description="AI confidence score for the response")
    suggestions: List[str] = Field(default_factory=list, description="AI-generated suggestions")
    actionTaken: Optional[str] = Field(None, description="Action taken by the AI assistant")


class Conversation(CRUDDocument):
    """Conversation model that groups related messages together"""
    id: Optional[PydanticObjectId] = Field(default_factory=PydanticObjectId, alias="_id")
    
    # Core conversation fields
    name: str = Field(..., description="Display name for the conversation (e.g., company name)")
    status: ConversationStatus = Field(default=ConversationStatus.ACTIVE, description="Conversation status")
    
    # Relationships
    dealId: Optional[str] = Field(None, description="UUID of the deal this conversation belongs to (None for pre-deal conversations)")
    userId: str = Field(..., description="User UUID of the user this conversation belongs to")

    # Conversation type
    conversationType: ConversationType = Field(default=ConversationType.EMAIL, description="Type of conversation")
    
    # Contact information
    contactName: str = Field(..., description="Name of the primary contact")
    contactEmail: Optional[EmailStr] = Field(None, description="Email of the primary contact")
    avatar: Optional[str] = Field(None, description="Avatar URL for the contact")
    
    # Conversation metadata
    subject: Optional[str] = Field(None, description="Subject line for email conversations")
    lastMessage: Optional[str] = Field(None, description="Preview of the last message")
    lastMessageAt: Optional[datetime] = Field(None, description="Timestamp of the last message")
    unreadCount: int = Field(default=0, description="Number of unread messages")
    messageCount: int = Field(default=0, description="Total number of messages in conversation")
    
    # Email-specific fields (for email conversations)
    participants: List[str] = Field(default_factory=list, description="List of email addresses in the conversation")
    threadId: Optional[str] = Field(None, description="Email thread ID for email conversations")
    
    # Timestamps
    createdAt: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updatedAt: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    
    # Additional metadata
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Additional conversation metadata")
    
    model_config = ConfigDict(
        populate_by_name_alias=True,
        json_encoders={
            datetime: lambda v: v.replace(microsecond=0).isoformat(),
            PydanticObjectId: str
        }
    )


class Message(CRUDDocument):
    """Message model that can represent both email conversations and AI assistant messages"""
    id: Optional[PydanticObjectId] = Field(default_factory=PydanticObjectId, alias="_id")
    
    # Core message fields
    messageType: MessageType = Field(..., description="Type of message (email or ai_assistant)")
    content: str = Field(..., description="Main message content")
    status: MessageStatus = Field(default=MessageStatus.SENT, description="Message status")
    
    # Relationships
    conversationId: str = Field(..., description="ID of the conversation this message belongs to")
    dealId: Optional[str] = Field(None, description="ID of the deal this message belongs to (None for pre-deal messages)")
    userId: str = Field(..., description="ID of the user this message belongs to")
    
    # Sender information
    senderName: str = Field(..., description="Name of the message sender")
    senderEmail: Optional[EmailStr] = Field(None, description="Email of the message sender")
    senderId: Optional[str] = Field(None, description="ID of the sender (for AI messages, this would be the assistant ID)")
    senderAvatar: Optional[str] = Field(None, description="Avatar of the message sender")
    
    # Message threading (for email conversations)
    inReplyTo: Optional[str] = Field(None, description="ID of the message this is replying to")
    threadPosition: int = Field(default=0, description="Position of this message in the thread")
    
    # Message metadata
    isInternal: bool = Field(default=False, description="Whether this is an internal message")
    isAutomated: bool = Field(default=False, description="Whether this message was generated automatically")
    priority: int = Field(default=0, description="Message priority (0=normal, 1=high, 2=urgent)")
    tags: List[str] = Field(default_factory=list, description="Message tags for categorization")
    
    # Type-specific data
    emailData: Optional[EmailMessage] = Field(None, description="Email-specific data (only for email messages)")
    aiData: Optional[AIAssistantMessage] = Field(None, description="AI assistant-specific data (only for AI messages)")
    
    # Timestamps
    sentAt: datetime = Field(default_factory=lambda: datetime.now(timezone.utc), description="When the message was sent")
    receivedAt: Optional[datetime] = Field(None, description="When the message was received")
    readAt: Optional[datetime] = Field(None, description="When the message was read")
    createdAt: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updatedAt: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    
    # Additional metadata
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Additional metadata")
    externalId: Optional[str] = Field(None, description="External system ID (e.g., email message ID)")
    
    model_config = ConfigDict(
        populate_by_name_alias=True,
        json_encoders={
            datetime: lambda v: v.replace(microsecond=0).isoformat(),
            PydanticObjectId: str
        }
    )


class MessageThread(BaseModel):
    """Represents a conversation thread containing multiple messages"""
    threadId: str = Field(..., description="Unique thread identifier")
    dealId: str = Field(..., description="ID of the deal this thread belongs to")
    userId: str = Field(..., description="ID of the user this thread belongs to")
    subject: Optional[str] = Field(None, description="Thread subject")
    participants: List[str] = Field(..., description="List of participant email addresses or IDs")
    messageCount: int = Field(default=0, description="Number of messages in this thread")
    lastMessageAt: Optional[datetime] = Field(None, description="Timestamp of the last message")
    isActive: bool = Field(default=True, description="Whether the thread is still active")
    createdAt: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updatedAt: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    
    model_config = ConfigDict(
        json_encoders={
            datetime: lambda v: v.replace(microsecond=0).isoformat()
        }
    )


class ConversationSummary(BaseModel):
    """Summary of conversations for a user"""
    totalConversations: int = Field(default=0, description="Total number of conversations")
    emailConversations: int = Field(default=0, description="Number of email conversations")
    aiChats: int = Field(default=0, description="Number of AI chat conversations")
    activeConversations: int = Field(default=0, description="Number of active conversations")
    totalUnreadMessages: int = Field(default=0, description="Total number of unread messages across all conversations")
    lastActivityAt: Optional[datetime] = Field(None, description="Timestamp of the last activity across all conversations")
    
    model_config = ConfigDict(
        json_encoders={
            datetime: lambda v: v.replace(microsecond=0).isoformat(),
            PydanticObjectId: str
        }
    )


class MessageSummary(BaseModel):
    """Summary of messages for a deal"""
    dealId: str = Field(..., description="ID of the deal")
    totalConversations: int = Field(default=0, description="Total number of conversations")
    totalMessages: int = Field(default=0, description="Total number of messages")
    emailMessages: int = Field(default=0, description="Number of email messages")
    aiMessages: int = Field(default=0, description="Number of AI assistant messages")
    unreadCount: int = Field(default=0, description="Number of unread messages")
    lastMessageAt: Optional[datetime] = Field(None, description="Timestamp of the last message")
    lastMessageType: Optional[MessageType] = Field(None, description="Type of the last message")
    lastMessagePreview: Optional[str] = Field(None, description="Preview of the last message")
    
    model_config = ConfigDict(
        json_encoders={
            datetime: lambda v: v.replace(microsecond=0).isoformat()
        }
    )
