from database.models.common import CRUDDocument
from beanie.odm.fields import PydanticObjectId
from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime
from enum import Enum


class ServiceAccountStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    EXPIRED = "expired"
    REVOKED = "revoked"


class ServiceAccount(CRUDDocument):
    """Service account model for API authentication."""

    id: Optional[PydanticObjectId] = Field(
        default=None, description="MongoDB document ObjectID", exclude=True
    )
    service_name: str = Field(
        ...,
        description="Unique identifier for the service (e.g., 'email_automation_lambda')",
    )
    api_key_hash: str = Field(
        ..., description="Hashed version of the API key for security"
    )
    permissions: List[str] = Field(
        default_factory=list,
        description="List of permissions granted to this service account",
    )
    status: ServiceAccountStatus = Field(
        default=ServiceAccountStatus.ACTIVE,
        description="Current status of the service account",
    )
    expires_at: Optional[datetime] = Field(
        default=None,
        description="When this service account expires (None for no expiration)",
    )
    created_at: datetime = Field(
        default_factory=datetime.utcnow,
        description="When the service account was created",
    )
    last_used_at: Optional[datetime] = Field(
        default=None, description="When the service account was last used"
    )
    created_by: str = Field(..., description="User ID who created this service account")
    description: Optional[str] = Field(
        default=None, description="Optional description of the service account purpose"
    )

    class Settings:
        name = "service_accounts"
        indexes = ["service_name", "status", "expires_at", "created_by"]

    class Config:
        json_encoders = {datetime: lambda v: v.isoformat()}
        validate_by_name = True


class CreateServiceAccountRequest(BaseModel):
    """Request model for creating a service account."""

    service_name: str = Field(..., description="Unique name for the service")
    permissions: List[str] = Field(..., description="List of permissions to grant")
    expires_at: Optional[datetime] = Field(
        default=None, description="Optional expiration date"
    )
    description: Optional[str] = Field(default=None, description="Optional description")


class ServiceAccountResponse(BaseModel):
    """Response model for service account operations."""

    uuid: str
    service_name: str
    permissions: List[str]
    status: ServiceAccountStatus
    expires_at: Optional[datetime]
    created_at: datetime
    last_used_at: Optional[datetime]
    created_by: str
    description: Optional[str]

    class Config:
        json_encoders = {datetime: lambda v: v.isoformat()}


class CreateServiceAccountResponse(ServiceAccountResponse):
    """Response model when creating a service account (includes API key)."""

    api_key: str = Field(
        ..., description="The generated API key (only returned once during creation)"
    )


# Predefined permission sets
LAMBDA_PERMISSIONS = [
    "leads:read",
    "leads:create",
    "leads:update",
    "deals:create",
    "processed_emails:read",
    "processed_emails:create",
    "blacklist:read",
    "users:read_by_email",
    "users:read_preferences",
    "messages:create",
]

ALL_PERMISSIONS = LAMBDA_PERMISSIONS + [
    "leads:delete",
    "deals:read",
    "deals:update",
    "deals:delete",
    "processed_emails:delete",
    "blacklist:create",
    "blacklist:update",
    "blacklist:delete",
    "users:create",
    "users:update",
    "users:delete",
    "service_accounts:create",
    "service_accounts:read",
    "service_accounts:update",
    "service_accounts:delete",
]
