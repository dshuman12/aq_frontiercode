from database.models.common import CRUDDocument
from beanie.odm.fields import PydanticObjectId
from pydantic import BaseModel, Field, EmailStr, HttpUrl
from typing import List, Optional, Dict, Any
from datetime import datetime
from enum import Enum


class PartnershipType(str, Enum):
    FLAT_RATE = "flat_rate"
    PERFORMANCE_HYBRID = "performance_hybrid"
    AFFILIATE = "affiliate"
    CUSTOM = "custom"


class RateType(str, Enum):
    CPM = "CPM"  # Cost Per Mille (per 1000 views)
    CVV = "CVV"  # Cost Per View
    FLAT = "FLAT"  # Flat rate
    PERCENTAGE = "PERCENTAGE"  # Percentage of sales


class PricingTier(str, Enum):
    LOW_TIER = "low_tier"
    PREMIUM_TIER = "premium_tier"
    ULTRA_PREMIUM = "ultra_premium"


class DeliverableType(str, Enum):
    PRE_MID_ROLL_AD = "Pre/Mid-Roll Ad"
    STREAM_SPONSORSHIP = "Stream Sponsorship"
    YOUTUBE_VIDEO = "YouTube Video"
    INSTAGRAM_POST = "Instagram Post"
    TIKTOK_VIDEO = "TikTok Video"
    PODCAST_EPISODE = "Podcast Episode"
    BLOG_POST = "Blog Post"
    TWITTER_THREAD = "Twitter Thread"
    CUSTOM = "Custom"


class DeliverableContent(BaseModel):
    account: Optional[str] = Field(
        default=None, description="Social media account handle"
    )
    deliverableType: str


class Deliverable(BaseModel):
    id: int
    bundle: bool = Field(default=False, description="Whether this is a bundle")
    content: List[DeliverableContent] = Field(default_factory=list)
    account: Optional[str] = Field(
        default=None, description="Social media account handle"
    )
    deliverableType: str
    tier: Optional[PricingTier] = Field(default=None)
    rate: float = Field(..., description="Rate amount")
    rateType: RateType
    lockRate: bool = Field(default=False, description="Whether rate is locked")
    price: float = Field(..., description="Final price in USD")
    createdAt: datetime = Field(default_factory=datetime.utcnow)
    updatedAt: datetime = Field(default_factory=datetime.utcnow)


class PartnershipPreferences(BaseModel):
    flatRate: bool = Field(default=True, description="Accept flat rate deals")
    performanceHybrid: bool = Field(
        default=False, description="Accept performance/hybrid deals"
    )
    affiliate: bool = Field(default=True, description="Accept affiliate deals")
    ugc: bool = Field(default=False, description="Accept UGC deals")
    gifting: bool = Field(default=False, description="Accept Gifting deals")
    # Matches repflow-frontend onboarding (events partnerships)
    events: bool = Field(default=False, description="Accept events-related deals")
    custom: bool = Field(default=False, description="Accept custom deal structures")


class PricingTierConfig(BaseModel):
    enabled: bool = Field(default=True, description="Whether this tier is enabled")
    categories: List[str] = Field(
        default_factory=list, description="Categories that fall under this tier"
    )


class PricingTiers(BaseModel):
    lowTier: PricingTierConfig = Field(
        default_factory=lambda: PricingTierConfig(
            enabled=True, categories=["Local Businesses"]
        )
    )
    premiumTier: PricingTierConfig = Field(
        default_factory=lambda: PricingTierConfig(
            enabled=True, categories=["Tech Companies"]
        )
    )
    ultraPremium: PricingTierConfig = Field(
        default_factory=lambda: PricingTierConfig(enabled=False, categories=[])
    )


class SocialLinks(BaseModel):
    instagram: Optional[HttpUrl] = None
    youtube: Optional[HttpUrl] = None
    tiktok: Optional[HttpUrl] = None
    twitter: Optional[HttpUrl] = None
    linkedin: Optional[HttpUrl] = None
    facebook: Optional[HttpUrl] = None


class Subscription(BaseModel):
    tier: str = Field(default="Growth", description="Subscription tier name")
    status: str = Field(default="active", description="Subscription status")
    currentPeriodEnd: datetime = Field(..., description="When current period ends")


class BillingAddress(BaseModel):
    line1: str
    line2: Optional[str] = None
    city: str
    state: str
    postalCode: str
    country: str = Field(default="United States")


class BillingInfo(BaseModel):
    cardLast4: str
    cardBrand: Optional[str] = None
    nextBillingDate: datetime
    expirationMonth: int
    paymentMethodId: Optional[str] = None
    expirationYear: int
    billingEmail: Optional[EmailStr] = None
    billingAddress: Optional[BillingAddress] = None


class ReferralHistory(BaseModel):
    id: str
    referredUserName: str
    status: str = Field(..., description="Status: completed, pending, etc.")
    revenue: float
    date: datetime


class ReferralData(BaseModel):
    referralCode: str
    referralLink: HttpUrl
    totalReferrals: int = Field(default=0)
    totalRevenue: float = Field(default=0.0)
    pendingPayouts: float = Field(default=0.0)
    referralHistory: List[ReferralHistory] = Field(default_factory=list)
    # Stripe integration fields
    stripePromotionCodeId: Optional[str] = Field(
        default=None,
        description="Stripe promotion code ID for this user's referral code",
    )
    isActive: bool = Field(
        default=True, description="Whether the referral program is active for this user"
    )
    createdAt: datetime = Field(default_factory=datetime.utcnow)
    updatedAt: datetime = Field(default_factory=datetime.utcnow)


class TeamMember(BaseModel):
    id: str
    name: str
    email: EmailStr
    avatar: Optional[str] = None
    role: str
    status: str = Field(
        default="active", description="Status: active, pending, inactive"
    )
    invitedAt: datetime
    lastActive: Optional[datetime] = Field(default=None)


class UserPreferences(BaseModel):
    # Partnership and negotiation preferences
    partnershipTypes: PartnershipPreferences = Field(
        default_factory=PartnershipPreferences
    )

    # Pricing and deliverables
    absoluteMinimumRate: float = Field(
        default=1000.0, description="Lowest acceptable rate in USD"
    )
    deliverables: List[Deliverable] = Field(default_factory=list)
    pricingTiers: PricingTiers = Field(default_factory=PricingTiers)

    # Auto-reject settings
    autoRejectCategories: List[str] = Field(
        default_factory=lambda: [
            "Nutritional Supplements",
            "Crypto/Blockchain/NFTs",
            "Video Games",
        ],
        description="Industries to automatically reject",
    )

    # Additional preferences
    preferredContactMethod: str = Field(
        default="email", description="Preferred contact method"
    )
    responseTimeHours: int = Field(
        default=24, description="Expected response time in hours"
    )
    timezone: str = Field(default="America/New_York", description="User's timezone")
    language: str = Field(default="en", description="Preferred language")

    # Notification preferences
    emailNotifications: bool = Field(default=True)
    pushNotifications: bool = Field(default=True)
    dealAlerts: bool = Field(default=True)
    weeklyReports: bool = Field(default=True)


class UserProfile(BaseModel):
    id: str
    name: str
    email: EmailStr
    repflow_username: str
    avatar: Optional[str] = None
    bio: Optional[str] = None
    tags: Optional[List[str]] = None
    location: Optional[str] = None
    website: Optional[HttpUrl] = None
    socialLinks: SocialLinks = Field(default_factory=SocialLinks)
    bookingLink: Optional[HttpUrl] = Field(default=None)
    subscription: Subscription
    foundingCreator: bool = Field(
        default=False, description="Whether the user is a founding creator (first 100)"
    )
    createdAt: datetime = Field(default_factory=datetime.utcnow)
    updatedAt: datetime = Field(default_factory=datetime.utcnow)


class PlatformType(str, Enum):
    YOUTUBE = "youtube"
    INSTAGRAM = "instagram"
    TIKTOK = "tiktok"
    TWITTER = "twitter"
    LINKEDIN = "linkedin"
    FACEBOOK = "facebook"
    TWITCH = "twitch"
    PODCAST = "podcast"
    BLOG = "blog"
    WEBSITE = "website"
    OTHER = "other"


class YouTubeAnalytics(BaseModel):
    """YouTube channel analytics data"""

    # Channel metrics
    subscriberCount: Optional[int] = Field(None, description="Total subscriber count")
    videoCount: Optional[int] = Field(None, description="Total video count")
    viewCount: Optional[int] = Field(None, description="Total view count")

    # Recent performance (last 28 days)
    recentViews: Optional[int] = Field(None, description="Views in last 28 days")
    recentWatchTimeMinutes: Optional[int] = Field(
        None, description="Watch time in minutes (last 28 days)"
    )
    recentSubscribersGained: Optional[int] = Field(
        None, description="Subscribers gained in last 28 days"
    )
    recentSubscribersLost: Optional[int] = Field(
        None, description="Subscribers lost in last 28 days"
    )

    # Engagement metrics
    averageViewDuration: Optional[float] = Field(
        None, description="Average view duration in seconds"
    )

    # Revenue metrics (if available)
    estimatedRevenue: Optional[float] = Field(
        None, description="Estimated revenue (last 28 days)"
    )

    # Top performing content
    topVideoTitle: Optional[str] = Field(
        None, description="Title of top performing video"
    )
    topVideoViews: Optional[int] = Field(
        None, description="Views of top performing video"
    )

    # Demographics data
    demographicsByAge: Optional[Dict[str, int]] = Field(
        None, description="Viewer demographics by age group"
    )
    demographicsByGender: Optional[Dict[str, int]] = Field(
        None, description="Viewer demographics by gender"
    )
    demographicsByCountry: Optional[Dict[str, int]] = Field(
        None, description="Viewer demographics by country"
    )

    # Analytics metadata
    lastUpdated: datetime = Field(
        default_factory=datetime.utcnow, description="When analytics were last updated"
    )
    channelId: Optional[str] = Field(None, description="YouTube channel ID")

    model_config = {"json_encoders": {datetime: lambda v: v.isoformat()}}


class InstagramAnalytics(BaseModel):
    """Instagram account analytics data"""

    # Core metrics
    followers: Optional[int] = Field(None, description="Total follower count")
    totalReach: Optional[int] = Field(None, description="Total reach across all posts")
    shortViews: Optional[int] = Field(
        None, description="Total views on short-form content (Reels)"
    )
    totalEngagedUsers: Optional[int] = Field(
        None, description="Total number of engaged users"
    )

    # Engagement metrics
    engagementRate: Optional[float] = Field(
        None, description="Overall engagement rate percentage"
    )
    averageLikes: Optional[float] = Field(None, description="Average likes per post")
    averageComments: Optional[float] = Field(
        None, description="Average comments per post"
    )
    averageShares: Optional[float] = Field(None, description="Average shares per post")

    # Content metrics
    totalPosts: Optional[int] = Field(None, description="Total number of posts")
    totalStories: Optional[int] = Field(None, description="Total number of stories")
    totalReels: Optional[int] = Field(None, description="Total number of Reels")

    # Recent performance (last 28 days)
    recentFollowersGained: Optional[int] = Field(
        None, description="Followers gained in last 28 days"
    )
    recentReach: Optional[int] = Field(None, description="Reach in last 28 days")
    recentEngagement: Optional[int] = Field(
        None, description="Total engagement in last 28 days"
    )
    recentReelsViews: Optional[int] = Field(
        None, description="Reels views in last 28 days"
    )

    # Demographics data
    demographicsByAge: Optional[Dict[str, int]] = Field(
        None, description="Follower demographics by age group"
    )
    demographicsByGender: Optional[Dict[str, int]] = Field(
        None, description="Follower demographics by gender"
    )
    demographicsByCountry: Optional[Dict[str, int]] = Field(
        None, description="Follower demographics by country"
    )
    demographicsByCity: Optional[Dict[str, int]] = Field(
        None, description="Follower demographics by city"
    )

    # Top performing content
    topPostLikes: Optional[int] = Field(
        None, description="Likes on top performing post"
    )
    topPostComments: Optional[int] = Field(
        None, description="Comments on top performing post"
    )
    topReelViews: Optional[int] = Field(
        None, description="Views on top performing Reel"
    )

    # Analytics metadata
    lastUpdated: datetime = Field(
        default_factory=datetime.utcnow, description="When analytics were last updated"
    )
    accountId: Optional[str] = Field(None, description="Instagram account ID")

    model_config = {"json_encoders": {datetime: lambda v: v.isoformat()}}


class PlatformMetrics(BaseModel):
    """Platform performance metrics"""

    subscribers: Optional[str] = Field(
        None, description="Number of subscribers/followers"
    )
    avgVideoViews: Optional[str] = Field(None, description="Average video views")
    avgShortViews: Optional[str] = Field(
        None, description="Average short-form content views"
    )
    engagementRate: Optional[str] = Field(
        None, description="Engagement rate percentage"
    )
    totalViews: Optional[str] = Field(
        None, description="Total views across all content"
    )
    avgLikes: Optional[str] = Field(None, description="Average likes per post")
    avgComments: Optional[str] = Field(None, description="Average comments per post")
    avgShares: Optional[str] = Field(None, description="Average shares per post")
    monthlyReach: Optional[str] = Field(None, description="Monthly reach/impressions")
    demographics: Optional[Dict[str, Any]] = Field(
        default_factory=dict, description="Audience demographics"
    )

    model_config = {"json_encoders": {datetime: lambda v: v.isoformat()}}


class Platform(BaseModel):
    """Social media platform information for a user"""

    name: str = Field(..., description="Platform name (e.g., 'Sarah Tech Reviews')")
    handle: str = Field(
        ..., description="Platform handle/URL (e.g., 'youtube.com/sarahtechreviews')"
    )
    platformType: PlatformType = Field(..., description="Type of platform")
    icon: Optional[str] = Field(
        None, description="Icon name or component (e.g., 'Youtube')"
    )
    verified: bool = Field(default=False, description="Whether the account is verified")
    color: Optional[str] = Field(
        None, description="Theme color for the platform (e.g., 'text-red-500')"
    )
    metrics: PlatformMetrics = Field(
        default_factory=PlatformMetrics, description="Platform performance metrics"
    )

    # Instagram-specific analytics
    instagramAnalytics: Optional[InstagramAnalytics] = Field(
        None, description="Instagram account analytics (only for Instagram platforms)"
    )
    # YouTube-specific analytics
    youtubeAnalytics: Optional[YouTubeAnalytics] = Field(
        None, description="YouTube channel analytics (only for YouTube platforms)"
    )
    isActive: bool = Field(
        default=True, description="Whether this platform is currently active"
    )
    connectedAt: datetime = Field(
        default_factory=datetime.utcnow, description="When the platform was connected"
    )
    lastUpdated: datetime = Field(
        default_factory=datetime.utcnow, description="When metrics were last updated"
    )
    customFields: Dict[str, Any] = Field(
        default_factory=dict, description="Platform-specific custom fields"
    )

    model_config = {"json_encoders": {datetime: lambda v: v.isoformat()}}


class User(CRUDDocument):
    id: Optional[PydanticObjectId] = Field(
        default=None, description="MongoDB document ObjectID", exclude=True
    )
    uuid: str = Field(..., description="Unique user identifier")
    profile: UserProfile
    preferences: UserPreferences = Field(default_factory=UserPreferences)
    platforms: List[Platform] = Field(
        default_factory=list, description="User's social media platforms"
    )
    billingInfo: Optional[BillingInfo] = Field(default=None)
    referralData: Optional[ReferralData] = Field(default=None)
    teamMembers: List[TeamMember] = Field(default_factory=list)

    # Authentication and security
    isActive: bool = Field(default=True)
    isVerified: bool = Field(default=False)
    lastLogin: Optional[datetime] = Field(default=None)

    # Timestamps
    createdAt: datetime = Field(default_factory=datetime.utcnow)
    updatedAt: datetime = Field(default_factory=datetime.utcnow)

    class Config:
        json_encoders = {datetime: lambda v: v.isoformat()}
        validate_by_name = True
