from database.models.common import CRUDDocument
from beanie.odm.fields import PydanticObjectId
from pydantic import BaseModel, Field, EmailStr
from typing import Optional
from datetime import datetime
from enum import Enum


class ReferralStatus(str, Enum):
    """Status of a referral"""
    PENDING = "pending"
    COMPLETED = "completed"
    EXPIRED = "expired"
    CANCELLED = "cancelled"


class Referral(CRUDDocument):
    """Referral model for tracking referral relationships"""
    id: Optional[PydanticObjectId] = Field(
        default=None, description="MongoDB document ObjectID", exclude=True
    )
    referralId: str = Field(..., description="Unique referral identifier")
    referralCreatorId: str = Field(..., description="ID of the user who created the referral (referrer)")
    referralCustomerId: Optional[str] = Field(default=None, description="ID of the user who used the referral (referee)")
    
    # Referral details
    referralCode: str = Field(..., description="The referral code used")
    status: ReferralStatus = Field(default=ReferralStatus.PENDING, description="Current status of the referral")
    
    # Stripe integration
    stripePromotionCodeId: str = Field(..., description="Stripe promotion code ID")
    stripeCustomerId: Optional[str] = Field(default=None, description="Stripe customer ID of the referee")
      
    # Tracking information
    createdAt: datetime = Field(default_factory=datetime.utcnow)
    completedAt: Optional[datetime] = Field(default=None, description="When the referral was completed")
    expiresAt: Optional[datetime] = Field(default=None, description="When the referral expires")
    
    # Revenue tracking
    referralRevenue: float = Field(default=0.0, description="Revenue generated from this referral")
    referrerReward: float = Field(default=0.0, description="Reward amount for the referrer")
    
    # Additional metadata
    metadata: dict = Field(default_factory=dict, description="Additional metadata for the referral")
    
    class Config:
        json_encoders = {datetime: lambda v: v.isoformat()}
        validate_by_name = True
    
    class Settings:
        indexes = [
            "referralId",
            "referralCreatorId", 
            "referralCustomerId",
            "referralCode",
            "status",
            "stripePromotionCodeId"
        ]
