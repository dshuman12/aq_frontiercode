"""
Brand model for CRM functionality.
Represents a brand/company that the creator works with.
"""

from typing import Optional
from datetime import datetime, timezone
from pydantic import Field, ConfigDict
from beanie.odm.fields import PydanticObjectId
from .common import CRUDDocument


class Brand(CRUDDocument):
    """
    Brand model representing a company/brand the creator works with.

    This is the primary entity in the CRM, with contacts linked to brands.
    Metrics like total_revenue and deal_count are computed on-the-fly from deals.
    """

    id: Optional[PydanticObjectId] = Field(
        default_factory=PydanticObjectId, alias="_id"
    )
    
    # Core brand information
    name: str = Field(..., description="Brand/company name")
    website: Optional[str] = Field(None, description="Brand website URL")
    category: Optional[str] = Field(
        None, description="Brand category (e.g., 'Tech', 'Fashion', 'Gaming')"
    )
    logo_url: Optional[str] = Field(None, description="URL to brand logo image")
    
    # Agency information
    is_agency: bool = Field(
        False, description="Whether this entity is an agency rather than a direct brand"
    )
    agency_name: Optional[str] = Field(
        None, description="Parent agency name if this brand is represented by an agency"
    )
    email_domain: Optional[str] = Field(
        None, 
        description="Email domain for agency detection (e.g., 'nike.com')"
    )
    
    # Multi-tenant support
    user_id: str = Field(..., description="User ID who owns this brand record")

    # Status and activity tracking
    last_touchpoint: Optional[datetime] = Field(
        None, description="Date of last interaction/activity with this brand"
    )
    current_status: Optional[str] = Field(
        None, description="Current status derived from latest deal (e.g., 'Active', 'Negotiating')"
    )
    
    # Notes
    notes: Optional[str] = Field(None, description="Free-form notes about this brand")
    
    # Timestamps
    created_at: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        description="When this brand record was created"
    )
    updated_at: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        description="When this brand record was last updated"
    )

    model_config = ConfigDict(
        populate_by_name=True,
        json_encoders={
            datetime: lambda v: v.replace(microsecond=0).isoformat(),
            PydanticObjectId: str,
        },
    )

    class Settings:
        name = "brands"
        indexes = [
            "uuid",
            "user_id",
            "name",
            [("user_id", 1), ("name", 1)],  # Compound index for user+name queries
            [("user_id", 1), ("email_domain", 1)],  # For agency detection
            [("user_id", 1), ("is_agency", 1)],  # Filter by agency type
            [("user_id", 1), ("category", 1)],  # Filter by category
        ]
