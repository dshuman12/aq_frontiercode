from typing import Optional
from beanie import Document
from beanie.odm.fields import PydanticObjectId
from pydantic import Field, computed_field, model_validator
import uuid


class CRUDDocument(Document):
    id: Optional[PydanticObjectId] = Field(
        default=None, description="MongoDB document ObjectID", exclude=True
    )
    uuid: str = Field(default_factory=lambda: str(uuid.uuid4()))

    @model_validator(mode="before")
    def validate_id(cls, data):
        if isinstance(data, dict):
            if "mongo_id" in data:
                data["id"] = PydanticObjectId(data["mongo_id"])
                del data["mongo_id"]
        return data

    @computed_field
    @property
    def mongo_id(self) -> str:
        return str(self.id) if self.id else ""

    class Settings:
        indexes = ["uuid"]