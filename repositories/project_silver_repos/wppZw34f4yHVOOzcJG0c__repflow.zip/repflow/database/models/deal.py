from enum import Enum
from typing import List, Optional
from pydantic import Field, field_validator, BaseModel, ConfigDict
from datetime import datetime, date, timezone
from beanie.odm.fields import PydanticObjectId
from .common import CRUDDocument


class DealStatus(str, Enum):
    NEW_OFFER = "New Offer"
    NEGOTIATING = "Negotiating"
    CONTRACTING = "Contracting"
    DRAFTING = "Drafting"
    LIVE = "Live"
    COMPLETE = "Complete"
    ARCHIVE = "Archive"
    LOST = "Lost"
    ABANDONED = "Abandoned"


class DealType(str, Enum):
    FLAT_RATE = "Flat Rate"
    AFFILIATE = "Affiliate"
    UGC = "UGC"
    SPONSORED_POST = "Sponsored Post"
    BRAND_PARTNERSHIP = "Brand Partnership"
    REVENUE_SHARE = "Revenue Share"


class DueDateType(str, Enum):
    SPECIFIC = "specific"
    REMINDER = "reminder"


class DealSource(str, Enum):
    INBOUND = "inbound"
    SHARED = "shared"
    REPFLOW = "Repflow"


class DeliverableContent(BaseModel):
    contentType: str = Field(
        ...,
        description="Type of content (youtube, tiktok, video, podcast, instagram, twitter)",
    )
    text: str = Field(..., description="Description of the deliverable")


class Deliverable(BaseModel):
    contents: List[DeliverableContent] = Field(
        ..., description="List of deliverable contents"
    )
    isBundle: bool = Field(False, description="Whether the deliverable is a bundle")

    draftLink: Optional[str] = Field(None, description="Link to draft content")
    invoiceLink: Optional[str] = Field(None, description="Link to invoice")
    createdAt: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updatedAt: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    model_config = ConfigDict(
        json_encoders={datetime: lambda v: v.replace(microsecond=0).isoformat()}
    )


class Communication(BaseModel):
    sender: str = Field(..., description="Name of the sender")
    message: str = Field(..., description="Message content")
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    avatar: Optional[str] = Field(None, description="Avatar URL")
    isYou: bool = Field(
        False, description="Whether the message is from the current user"
    )
    createdAt: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    model_config = ConfigDict(
        json_encoders={datetime: lambda v: v.replace(microsecond=0).isoformat()}
    )


class StageHistory(BaseModel):
    stage: DealStatus = Field(..., description="Stage name")
    enteredAt: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    exitedAt: Optional[datetime] = Field(None, description="When the stage was exited")
    daysInStage: Optional[int] = Field(
        None, description="Number of days spent in this stage"
    )
    createdAt: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    model_config = ConfigDict(
        json_encoders={datetime: lambda v: v.replace(microsecond=0).isoformat()}
    )


class Brief(BaseModel):
    link: str = Field(..., description="Link to the brief")
    promoCode: str = Field(..., description="Promotional code")


class Deal(CRUDDocument):
    id: Optional[PydanticObjectId] = Field(
        default_factory=PydanticObjectId, alias="_id"
    )
    title: str = Field(..., description="Deal title")
    source: DealSource = Field(..., description="Source of the deal")
    status: DealStatus = Field(..., description="Current deal status")
    dealType: DealType = Field(..., description="Type of deal")
    lastActivity: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    value: float = Field(..., description="Deal value in USD")
    valueCurrency: str = Field("USD", description="Currency of the deal value")
    performanceRate: Optional[str] = Field(None, description="Performance rate for affiliate or performance based deals")
    dueDate: Optional[date] = Field(None, description="Due date for the deal")
    dueDateType: DueDateType = Field(
        DueDateType.REMINDER, description="Type of due date"
    )
    reminderDays: Optional[int] = Field(
        3, description="Days before due date to send reminder"
    )
    isPriority: bool = Field(False, description="Whether this is a priority deal")
    isHighValue: bool = Field(False, description="Whether this is a high-value deal")
    isAiPaused: bool = Field(False, description="Whether AI automation is paused")
    dateReceived: date = Field(..., description="Date when the deal was received")
    comments: Optional[str] = Field(None, description="Additional comments")
    brief: Brief = Field(..., description="Brief information")
    deliverables: List[Deliverable] = Field(
        default_factory=list, description="List of deliverables"
    )
    communicationHistory: List[Communication] = Field(
        default_factory=list, description="Communication history"
    )
    timeInStage: Optional[int] = Field(None, description="Days in current stage")
    createdAt: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updatedAt: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    userId: Optional[str] = Field(None, description="User ID who owns the deal")
    createdBy: Optional[str] = Field(None, description="User ID who created the deal")
    updatedBy: Optional[str] = Field(
        None, description="User ID who last updated the deal"
    )

    # CRM Integration - links to Brand and Contact models
    brandId: Optional[str] = Field(None, description="Linked Brand UUID from CRM")
    contactId: Optional[str] = Field(
        None, description="Primary Contact UUID for this deal from CRM"
    )

    @field_validator("value")
    @classmethod
    def validate_value(cls, v):
        if v < 0:
            raise ValueError("Value must be positive")
        return v

    @field_validator("reminderDays")
    @classmethod
    def validate_reminder_days(cls, v):
        if v is not None and v < 0:
            raise ValueError("Reminder days must be positive")
        return v

    @field_validator("dateReceived", mode="before")
    @classmethod
    def validate_date_received(cls, v):
        """Convert datetime strings to date objects for dateReceived field."""
        if isinstance(v, str):
            try:
                # Try to parse as datetime first
                dt = datetime.fromisoformat(v.replace("Z", "+00:00"))
                return dt.date()
            except ValueError:
                try:
                    # Try to parse as date
                    return datetime.strptime(v, "%Y-%m-%d").date()
                except ValueError:
                    raise ValueError(
                        f"Invalid date format: {v}. Expected YYYY-MM-DD or ISO datetime string."
                    )
        elif isinstance(v, datetime):
            return v.date()
        elif isinstance(v, date):
            return v
        else:
            raise ValueError(f"Invalid type for dateReceived: {type(v)}")

    @field_validator("dueDate", mode="before")
    @classmethod
    def validate_due_date(cls, v):
        """Convert datetime strings to date objects for dueDate field."""
        if v is None:
            return v
        if isinstance(v, str):
            try:
                # Try to parse as datetime first
                dt = datetime.fromisoformat(v.replace("Z", "+00:00"))
                return dt.date()
            except ValueError:
                try:
                    # Try to parse as date
                    return datetime.strptime(v, "%Y-%m-%d").date()
                except ValueError:
                    raise ValueError(
                        f"Invalid date format: {v}. Expected YYYY-MM-DD or ISO datetime string."
                    )
        elif isinstance(v, datetime):
            return v.date()
        elif isinstance(v, date):
            return v
        else:
            raise ValueError(f"Invalid type for dueDate: {type(v)}")

    model_config = ConfigDict(
        populate_by_name_alias=True,
        json_encoders={
            datetime: lambda v: v.replace(microsecond=0).isoformat(),
            date: lambda v: v.isoformat(),
            PydanticObjectId: str,
        },
    )
