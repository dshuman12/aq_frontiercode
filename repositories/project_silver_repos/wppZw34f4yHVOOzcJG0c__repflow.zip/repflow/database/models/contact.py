"""
Contact model for CRM functionality.
Represents a person/contact at a brand that the creator works with.
"""

from typing import List, Optional, Dict
from datetime import datetime, timezone
from pydantic import Field, EmailStr, ConfigDict
from beanie.odm.fields import PydanticObjectId
from .common import CRUDDocument


class Contact(CRUDDocument):
    """
    Contact model representing a person at a brand.
    
    Contacts can be linked to multiple brands via brand_ids (many-to-many).
    Agency contacts are detected via email domain matching.
    """

    id: Optional[PydanticObjectId] = Field(
        default_factory=PydanticObjectId, alias="_id"
    )
    
    # Core contact information
    name: str = Field(..., description="Contact's full name")
    email: EmailStr = Field(..., description="Contact's email address")
    title: Optional[str] = Field(
        None, description="Job title (e.g., 'Marketing Manager', 'Brand Partnerships')"
    )
    phone: Optional[str] = Field(None, description="Contact's phone number")
    
    # Agency detection
    is_agency_contact: bool = Field(
        False, 
        description="Whether this contact works for an agency (inferred from email domain)"
    )
    
    # Multi-tenant support
    user_id: str = Field(..., description="User ID who owns this contact record")
    
    # Brand relationships (many-to-many)
    brand_ids: List[str] = Field(
        default_factory=list, 
        description="List of brand UUIDs this contact is associated with"
    )
    
    # Role at each brand (optional - for tracking different roles at different brands)
    # This is stored as a dict mapping brand_id to role
    brand_roles: Dict[str, str] = Field(
        default_factory=dict,
        description="Mapping of brand_id to contact's role/title at that brand"
    )
    
    # Primary contact flag per brand
    primary_for_brands: List[str] = Field(
        default_factory=list,
        description="List of brand UUIDs where this contact is the primary contact"
    )
    
    # Notes
    notes: Optional[str] = Field(None, description="Free-form notes about this contact")
    
    # Timestamps
    created_at: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        description="When this contact record was created"
    )
    updated_at: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        description="When this contact record was last updated"
    )

    model_config = ConfigDict(
        populate_by_name=True,
        json_encoders={
            datetime: lambda v: v.replace(microsecond=0).isoformat(),
            PydanticObjectId: str,
        },
    )

    class Settings:
        name = "contacts"
        indexes = [
            "uuid",
            "user_id",
            "email",
            [("user_id", 1), ("email", 1)],  # Unique per user
            [("user_id", 1), ("is_agency_contact", 1)],  # Filter by agency contacts
            [("user_id", 1), ("brand_ids", 1)],  # Find contacts for a brand
        ]
