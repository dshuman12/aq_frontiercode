from enum import Enum
from typing import List, Optional, Literal, Dict, Any
from pydantic import Field, BaseModel, EmailStr
from datetime import datetime, timezone
from beanie.odm.fields import PydanticObjectId
from .common import CRUDDocument
from .deal import DeliverableContent


class LeadStatus(str, Enum):
    NEW = "new"
    IN_PROGRESS = "in_progress"
    QUALIFIED = "qualified"
    DISQUALIFIED = "disqualified"


class EmailProcessingState(str, Enum):
    """Unified FSM state for email processing."""

    NEEDS_CLASSIFICATION = "NEEDS_CLASSIFICATION"
    NEEDS_INFO = "NEEDS_INFO"
    NEEDS_EVALUATION = "NEEDS_EVALUATION"
    NEEDS_NEGOTIATION = "NEEDS_NEGOTIATION"
    READY_FOR_DEAL = "READY_FOR_DEAL"
    DEAL_CREATED = "DEAL_CREATED"
    NEEDS_RETRY = "NEEDS_RETRY"

    REJECTED_NON_SPONSORSHIP = "REJECTED_NON_SPONSORSHIP"

    REJECTED = "REJECTED"
    ERROR_CLASSIFICATION_FAILED = "ERROR_CLASSIFICATION_FAILED"
    ERROR_DEAL_CREATION_FAILED = "ERROR_DEAL_CREATION_FAILED"

    COMPLETE = "COMPLETE"
    GHOSTED = "GHOSTED"
    ABANDONED = "ABANDONED"
    LOST = "LOST"

    @classmethod
    def _missing_(cls, value: object):
        if not isinstance(value, str):
            return None

        value_upper = value.upper()
        # Direct match for new format
        for member in cls:
            if member.value == value_upper:
                return member

        # Legacy mapping
        legacy_map = {
            "lead_needs_classification": cls.NEEDS_CLASSIFICATION,
            "needs_classification": cls.NEEDS_CLASSIFICATION,
            "needs_info": cls.NEEDS_INFO,
            "needs_evaluation": cls.NEEDS_EVALUATION,
            "needs_negotiation": cls.NEEDS_NEGOTIATION,
            "ready_for_deal": cls.READY_FOR_DEAL,
            "existing_deal": cls.DEAL_CREATED,
            "deal_created": cls.DEAL_CREATED,
            "needs_retry": cls.NEEDS_RETRY,
            "rejected_non_sponsorship": cls.REJECTED_NON_SPONSORSHIP,
            "rejected": cls.REJECTED,
            "error_classification_failed": cls.ERROR_CLASSIFICATION_FAILED,
            "error_deal_creation_failed": cls.ERROR_DEAL_CREATION_FAILED,
            "existing_deal_complete": cls.COMPLETE,
            "complete": cls.COMPLETE,
            "ghosted": cls.GHOSTED,
            "abandoned": cls.ABANDONED,
            "lost": cls.LOST,
        }
        return legacy_map.get(value.lower())


class StateCategory(str, Enum):
    """High-level state categorization."""

    SPONSORSHIP = "sponsorship"
    NON_SPONSORSHIP = "non_sponsorship"
    REJECTED = "rejected"
    ARCHIVE = "archive"


def get_state_category(state: EmailProcessingState) -> StateCategory:
    """Get the category for a given state."""
    sponsorship_states = {
        EmailProcessingState.NEEDS_CLASSIFICATION,
        EmailProcessingState.NEEDS_INFO,
        EmailProcessingState.NEEDS_EVALUATION,
        EmailProcessingState.NEEDS_NEGOTIATION,
        EmailProcessingState.READY_FOR_DEAL,
        EmailProcessingState.DEAL_CREATED,
        EmailProcessingState.NEEDS_RETRY,
    }
    rejected_states = {
        EmailProcessingState.REJECTED,
        EmailProcessingState.ERROR_CLASSIFICATION_FAILED,
        EmailProcessingState.ERROR_DEAL_CREATION_FAILED,
    }
    archive_states = {
        EmailProcessingState.COMPLETE,
        EmailProcessingState.GHOSTED,
        EmailProcessingState.ABANDONED,
        EmailProcessingState.LOST,
    }

    if state in sponsorship_states:
        return StateCategory.SPONSORSHIP
    if state == EmailProcessingState.REJECTED_NON_SPONSORSHIP:
        return StateCategory.NON_SPONSORSHIP
    if state in rejected_states:
        return StateCategory.REJECTED
    if state in archive_states:
        return StateCategory.ARCHIVE
    return StateCategory.SPONSORSHIP


class TransitionTrigger(str, Enum):
    """What triggered the state transition."""

    AI = "ai"
    EMAIL = "email"
    TIME = "time"
    API = "api"
    MANUAL = "manual"
    RETRY = "retry"


class StateTransitionRecord(BaseModel):
    """Record of state transition with trigger."""

    from_state: str
    to_state: str
    trigger: TransitionTrigger
    event: str
    timestamp: datetime
    metadata: Optional[Dict[str, Any]] = None


class LeadQualificationData(CRUDDocument):
    """Lead qualification data model using Beanie."""

    id: Optional[PydanticObjectId] = Field(
        default_factory=PydanticObjectId, alias="_id", exclude=True
    )
    userId: str = Field(..., description="User ID of the user who owns the lead")
    email: EmailStr = Field(..., description="Lead email address")
    thread_id: str = Field(..., description="Email thread ID")

    brand_name: Optional[str] = Field(None, description="Brand name")
    brand_website: Optional[str] = Field(None, description="Brand website")
    brand_category: Optional[str] = Field(None, description="Brand category")
    brand_contact_name: Optional[str] = Field(None, description="Brand contact name")
    brand_contact_email: Optional[EmailStr] = Field(
        None, description="Brand contact email"
    )
    contact_type: Optional[str] = Field(
        None, description="Contact type (Brand Direct, Agency, etc.)"
    )
    contact_title: Optional[str] = Field(
        None,
        description="Contact job title (Marketing Manager, Brand Manager, Founder, etc.)",
    )
    deal_type: Optional[
        Literal[
            "Flat Rate",
            "Affiliate",
            "UGC",
            "Sponsored Post",
            "Brand Partnership",
            "Revenue Share",
        ]
    ] = Field(None, description="Deal type")
    deliverables: Optional[list[DeliverableContent]] = Field(
        None, description="Deliverables description"
    )
    budget: Optional[str] = Field(None, description="Budget information")
    deadline: Optional[str] = Field(
        None,
        description="Deadline information (concise string, e.g., 'January 15, 2025' or '2 Instagram posts in January')",
    )
    brand_comment: Optional[str] = Field(None, description="Brand comment")

    status: LeadStatus = Field(default=LeadStatus.NEW, description="Lead status")
    processing_state: EmailProcessingState = Field(
        default=EmailProcessingState.NEEDS_CLASSIFICATION
    )
    state_history: List[StateTransitionRecord] = Field(default_factory=list)
    state_metadata: Dict[str, Any] = Field(default_factory=dict)
    deal_id: Optional[str] = Field(default=None)
    follow_up_count: int = Field(default=0)
    negotiation_round: int = Field(default=0)
    retry_count: int = Field(default=0)
    last_state_change: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc)
    )
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    def validate_for_update(self) -> bool:
        """Validate that the lead object is ready for update operations."""
        if not self.id:
            print("ERROR: Lead missing _id field")
            return False
        if not self.email:
            print("ERROR: Lead missing email field")
            return False
        if not self.thread_id:
            print("ERROR: Lead missing thread_id field")
            return False
        return True

    def get_missing_fields(self) -> List[str]:
        """Get list of missing required fields.

        Note: contact_title is auto-detected and NOT a required field.
        contact_type (brand vs agency) is required if not auto-detected from research.
        """
        missing = []
        required_fields = {
            "brand_name": "Brand Name",
            "brand_website": "Brand Website",
            "brand_category": "Brand Category",
            "brand_contact_name": "Brand Contact Name",
            "brand_contact_email": "Brand Contact Email",
            "deliverables": "Deliverables",
            "budget": "Budget",
            "deadline": "Deadline",
            "deal_type": "Deal Type",
            "contact_type": "Contact Type",
            # Note: contact_title is NOT required - it's auto-detected from email signature
        }

        for field, display_name in required_fields.items():
            if not getattr(self, field):
                missing.append(display_name)
        return missing

    def is_complete(self) -> bool:
        """Check if all required fields are filled."""
        return len(self.get_missing_fields()) == 0

    class Config:
        populate_by_name_alias = True

    class Settings:
        collection = "leads"
        indexes = ["thread_id", "email", "status", "processing_state", "deal_id"]


class ProcessedEmail(CRUDDocument):
    """Processed email tracking model using Beanie."""

    id: Optional[PydanticObjectId] = Field(
        default_factory=PydanticObjectId, alias="_id"
    )
    message_id: str = Field(..., description="Email message ID")
    thread_id: str = Field(..., description="Email thread ID")
    processed_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    class Config:
        populate_by_name_alias = True

    class Settings:
        collection = "processed_emails"
        indexes = ["message_id", "thread_id"]


class BlacklistedEmail(CRUDDocument):
    """Blacklisted email model using Beanie."""

    id: Optional[PydanticObjectId] = Field(
        default_factory=PydanticObjectId, alias="_id"
    )
    email: EmailStr = Field(..., description="Blacklisted email address")
    reason: Optional[str] = Field(None, description="Reason for blacklisting")
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    class Config:
        populate_by_name_alias = True

    class Settings:
        collection = "blacklist"
        indexes = ["email"]
