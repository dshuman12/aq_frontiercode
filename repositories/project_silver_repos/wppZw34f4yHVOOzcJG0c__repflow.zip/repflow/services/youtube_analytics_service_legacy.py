"""
YouTube Analytics Service
Fetches YouTube channel analytics using the YouTube Analytics API.
"""

import os
import json
import logging
from datetime import datetime, timezone, timedelta
from typing import Optional, Dict, Any, List
from googleapiclient.discovery import build
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.errors import HttpError

from database.models.user import YouTubeAnalytics

REPFLOW_FRONTEND_URL = "https://creator.userepflow.com"

logger = logging.getLogger("uvicorn.error")


class YouTubeAnalyticsService:
    """Service for fetching YouTube channel analytics."""

    def __init__(self):
        """Initialize the YouTube Analytics service."""
        logger.info("🎬 Initializing YouTube Analytics Service")

        self.api_service_name = "youtubeAnalytics"
        self.api_version = "v2"
        self.youtube_data_service_name = "youtube"
        self.youtube_data_api_version = "v3"
        self.api_key = "AIzaSyAI1BbRTUyT_A01zCYrAKcU-vc71ELifzk"

        # OAuth configuration
        self.client_id = (
            "620137782462-8nukt3nbvrjair76dt75ls62cnri9siq.apps.googleusercontent.com"
        )
        self.client_secret = "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"
        self.redirect_uri = os.getenv(
            "YOUTUBE_REDIRECT_URI", f"{REPFLOW_FRONTEND_URL}/auth/youtube/callback"
        )
        self.scopes = [
            "https://www.googleapis.com/auth/youtube.readonly",
            "https://www.googleapis.com/auth/yt-analytics.readonly",
            "https://www.googleapis.com/auth/yt-analytics-monetary.readonly",
        ]

        logger.info(f"📊 YouTube Analytics Service initialized with:")
        logger.info(f"   - API Service: {self.api_service_name} v{self.api_version}")
        logger.info(
            f"   - YouTube Data API: {self.youtube_data_service_name} v{self.youtube_data_api_version}"
        )
        logger.info(f"   - Redirect URI: {self.redirect_uri}")
        logger.info(f"   - Scopes: {', '.join(self.scopes)}")

        if not self.api_key:
            logger.warning(
                "⚠️ YOUTUBE_API_KEY not set - YouTube analytics will not work"
            )
        else:
            logger.info("✅ YouTube API key configured")

        if not self.client_id or not self.client_secret:
            logger.warning(
                "⚠️ YOUTUBE_CLIENT_ID or YOUTUBE_CLIENT_SECRET not set - OAuth will not work"
            )
        else:
            logger.info("✅ YouTube OAuth credentials configured")

    def _build_youtube_analytics_service(self, credentials: Credentials):
        """Build YouTube Analytics API service with OAuth credentials."""
        logger.info("🔧 Building YouTube Analytics service with OAuth credentials")
        logger.info(f"   - Service: {self.api_service_name} {self.api_version}")
        logger.info(f"   - Credentials: {'Valid' if credentials else 'None'}")

        try:
            logger.info(
                f"Building YouTube Analytics service with credentials: {credentials.to_json()}"
            )
            service = build(
                self.api_service_name, self.api_version, credentials=credentials
            )
            logger.info("✅ YouTube Analytics service built successfully with OAuth")
            return service
        except Exception as e:
            logger.error(f"❌ Failed to build YouTube Analytics service: {e}")
            logger.error(f"   - Service: {self.api_service_name}")
            logger.error(f"   - Version: {self.api_version}")
            raise

    def _build_youtube_data_service(self, credentials: Credentials):
        """Build YouTube Data API service with OAuth credentials."""
        logger.info("🔧 Building YouTube Data service with OAuth credentials")
        logger.info(
            f"   - Service: {self.youtube_data_service_name} v{self.youtube_data_api_version}"
        )
        logger.info(f"   - Credentials: {'Valid' if credentials else 'None'}")

        try:
            logger.info(
                f"Building YouTube Data service with credentials: {credentials}"
            )
            service = build(
                self.youtube_data_service_name,
                self.youtube_data_api_version,
                credentials=credentials,
            )
            logger.info("✅ YouTube Data service built successfully with OAuth")
            return service
        except Exception as e:
            logger.error(f"❌ Failed to build YouTube Data service: {e}")
            logger.error(f"   - Service: {self.youtube_data_service_name}")
            logger.error(f"   - Version: {self.youtube_data_api_version}")
            raise

    async def get_channel_analytics(
        self, credentials: Credentials, include_demographics: bool = False
    ) -> Optional[YouTubeAnalytics]:
        """
        Fetch YouTube channel analytics using OAuth credentials.

        Args:
            credentials: OAuth2 credentials (required)
            include_demographics: Whether to include demographic data

        Returns:
            YouTubeAnalytics object with channel data
        """
        logger.info("🎬 Starting YouTube channel analytics fetch")
        logger.info(f"   - Has credentials: {'Yes' if credentials else 'No'}")
        logger.info(
            f"   - Include demographics: {'Yes' if include_demographics else 'No'}"
        )

        try:
            # Get basic channel statistics using OAuth
            logger.info("📊 Step 1: Fetching basic channel statistics")
            basic_stats = await self._get_basic_channel_stats(credentials)
            logger.info(f"   - Basic stats fetched: {'Yes' if basic_stats else 'No'}")

            # Extract channel ID for use in detailed analytics
            channel_id = None
            if basic_stats:
                channel_id = basic_stats.get("channelId")
                logger.info(f"   - Channel ID: {channel_id}")
                logger.info(
                    f"   - Subscriber count: {basic_stats.get('subscriberCount', 'N/A')}"
                )
                logger.info(f"   - Video count: {basic_stats.get('videoCount', 'N/A')}")
                logger.info(f"   - View count: {basic_stats.get('viewCount', 'N/A')}")

            # Get detailed analytics with OAuth credentials and channel ID
            logger.info("🔐 Step 2: Fetching detailed analytics with OAuth credentials")
            detailed_analytics = await self._get_detailed_analytics(
                credentials, channel_id
            )
            logger.info(
                f"   - Detailed analytics fetched: {'Yes' if detailed_analytics else 'No'}"
            )

            # Get demographic analytics if requested
            demographic_analytics = None
            if include_demographics:
                logger.info("👥 Step 3: Fetching demographic analytics")
                try:
                    demographic_analytics = await self._get_demographic_analytics(
                        credentials, channel_id
                    )
                    logger.info(f"   - Demographic analytics: {demographic_analytics}")
                    logger.info(f"✅ Demographic analytics fetched")
                    logger.info(
                        f"   - Age demographics: {'Yes' if demographic_analytics.get('demographicsByAge') else 'No'}"
                    )
                    logger.info(
                        f"   - Gender demographics: {'Yes' if demographic_analytics.get('demographicsByGender') else 'No'}"
                    )
                    logger.info(
                        f"   - Country demographics: {'Yes' if demographic_analytics.get('demographicsByCountry') else 'No'}"
                    )
                except Exception as e:
                    logger.warning(f"⚠️ Failed to fetch demographic analytics: {e}")
                    # Continue without demographics rather than failing completely
            else:
                logger.info("ℹ️ Step 3: Skipping demographic analytics (not requested)")

            # Combine data into YouTubeAnalytics object
            logger.info("🔧 Step 4: Combining analytics data")
            analytics_data = {
                "channelId": "MINE",  # Using 'MINE' for OAuth-based calls
                "lastUpdated": datetime.utcnow(),
            }

            # Add basic stats
            if basic_stats:
                analytics_data.update(basic_stats)
                logger.info("   - Basic stats added to analytics data")

            # Add detailed analytics
            if detailed_analytics:
                analytics_data.update(detailed_analytics)
                logger.info("   - Detailed analytics added to analytics data")

            # Add demographic analytics
            if demographic_analytics:
                analytics_data.update(demographic_analytics)
                logger.info("   - Demographic analytics added to analytics data")
                logger.info(
                    f"   - Demographics keys: {list(demographic_analytics.keys())}"
                )
                for key, value in demographic_analytics.items():
                    if value:
                        logger.info(
                            f"   - {key}: {len(value) if isinstance(value, dict) else type(value)} items"
                        )
                    else:
                        logger.info(f"   - {key}: None/Empty")
            else:
                logger.info("   - No demographic analytics to add")

            logger.info(f"Analytics data: {analytics_data}")
            # Create the YouTubeAnalytics object
            youtube_analytics_obj = YouTubeAnalytics(**analytics_data)

            logger.info("✅ YouTubeAnalytics object created successfully")
            logger.info(f"   - Total data fields: {len(analytics_data)}")
            logger.info(f"   - Channel ID: {analytics_data.get('channelId')}")
            logger.info(f"   - Last updated: {analytics_data.get('lastUpdated')}")

            # Log demographic fields specifically
            logger.info("📊 Demographics verification:")
            logger.info(
                f"   - demographicsByAge: {'Present' if youtube_analytics_obj.demographicsByAge else 'None'}"
            )
            logger.info(
                f"   - demographicsByGender: {'Present' if youtube_analytics_obj.demographicsByGender else 'None'}"
            )
            logger.info(
                f"   - demographicsByCountry: {'Present' if youtube_analytics_obj.demographicsByCountry else 'None'}"
            )

            return youtube_analytics_obj

        except Exception as e:
            logger.error(f"❌ Error fetching YouTube analytics: {e}")
            logger.error(f"   - Error type: {type(e).__name__}")
            logger.error(f"   - Has credentials: {'Yes' if credentials else 'No'}")
            return None

    async def _get_basic_channel_stats(
        self, credentials: Credentials
    ) -> Optional[Dict[str, Any]]:
        """Get basic channel statistics using YouTube Data API with OAuth."""
        try:
            youtube = self._build_youtube_data_service(credentials)

            response = (
                youtube.channels().list(part="statistics,snippet", mine=True).execute()
            )

            logger.info(f"Response: {response}")
            if not response.get("items"):
                logger.warning("No channel found for authenticated user")
                return None

            channel = response["items"][0]
            statistics = channel.get("statistics", {})
            snippet = channel.get("snippet", {})
            channel_id = channel.get("id")

            logger.info(f"📺 Channel ID found: {channel_id}")

            return {
                "channelId": channel_id,
                "subscriberCount": int(statistics.get("subscriberCount", 0)),
                "videoCount": int(statistics.get("videoCount", 0)),
                "viewCount": int(statistics.get("viewCount", 0)),
            }

        except HttpError as e:
            if e.resp.status == 403:
                logger.warning(
                    "API quota exceeded or invalid credentials for authenticated user"
                )
            else:
                logger.error(f"YouTube Data API error for authenticated user: {e}")
            return None
        except Exception as e:
            logger.error(f"Error getting basic stats for authenticated user: {e}")
            return None

    async def _get_detailed_analytics(
        self, credentials: Credentials, channel_id: Optional[str] = None
    ) -> Optional[Dict[str, Any]]:
        """Get detailed analytics using YouTube Analytics API (requires OAuth)."""
        try:
            logger.info(
                f"🔍 Building analytics service with credentials: {credentials}"
            )
            analytics = self._build_youtube_analytics_service(credentials)

            # Calculate date range (last 28 days)
            end_date = datetime.now(timezone.utc).date()
            start_date = end_date - timedelta(days=28)

            logger.info(f"FETCHING DETAILED ANALYTICS")
            if channel_id:
                logger.info(f"📺 Using specific channel ID: {channel_id}")
            else:
                logger.info("📺 Using authenticated user's channel (mine=True)")

            # Get analytics data - use specific channel ID if provided, otherwise use 'mine=True'
            query_params = {
                "startDate": start_date.isoformat(),
                "endDate": end_date.isoformat(),
                "metrics": "views,subscribersGained,subscribersLost,estimatedMinutesWatched,averageViewDuration",
                "dimensions": "day",
            }

            if channel_id:
                query_params["ids"] = f"channel=={channel_id}"
            else:
                query_params["mine"] = True

            response = analytics.reports().query(**query_params).execute()

            logger.info(f"FETCHED DETAILED ANALYTICS")
            if not response.get("rows"):
                logger.warning("No analytics data found for authenticated user")
                return {}

            # Aggregate the data
            total_views = sum(row[1] for row in response["rows"])
            total_subscribers_gained = sum(row[2] for row in response["rows"])
            total_subscribers_lost = sum(row[3] for row in response["rows"])
            total_watch_time_minutes = sum(row[4] for row in response["rows"])
            avg_view_duration = sum(row[5] for row in response["rows"]) / len(
                response["rows"]
            )
            total_revenue = (
                sum(row[6] for row in response["rows"])
                if len(response["rows"][0]) > 6
                else 0
            )

            return {
                "recentViews": total_views,
                "recentSubscribersGained": total_subscribers_gained,
                "recentSubscribersLost": total_subscribers_lost,
                "recentWatchTimeMinutes": total_watch_time_minutes,
                "averageViewDuration": avg_view_duration,
                "estimatedRevenue": total_revenue,
            }

        except HttpError as e:
            if e.resp.status == 403:
                logger.warning(
                    "Insufficient permissions for detailed analytics for authenticated user"
                )
            else:
                logger.error(f"YouTube Analytics API error for authenticated user: {e}")
            return {}
        except Exception as e:
            logger.error(
                f"Error getting detailed analytics for authenticated user: {e}"
            )
            return {}

    async def get_top_videos(
        self, channel_id: str, credentials: Optional[Credentials] = None
    ) -> Optional[Dict[str, Any]]:
        """Get top performing videos for the channel."""
        try:
            youtube = self._build_youtube_data_service(credentials)

            # Get recent videos
            search_response = (
                youtube.search()
                .list(
                    channelId=channel_id,
                    part="id,snippet",
                    order="viewCount",
                    type="video",
                    maxResults=5,
                    publishedAfter=(
                        datetime.now(timezone.utc) - timedelta(days=30)
                    ).isoformat(),
                )
                .execute()
            )

            if not search_response.get("items"):
                return None

            # Get video statistics
            video_ids = [item["id"]["videoId"] for item in search_response["items"]]
            videos_response = (
                youtube.videos()
                .list(part="statistics,snippet", id=",".join(video_ids))
                .execute()
            )

            if videos_response.get("items"):
                top_video = videos_response["items"][0]
                return {
                    "topVideoTitle": top_video["snippet"]["title"],
                    "topVideoViews": int(top_video["statistics"].get("viewCount", 0)),
                }

            return None

        except Exception as e:
            logger.error(f"Error getting top videos for channel {channel_id}: {e}")
            return None

    def get_oauth_authorization_url(self, state: Optional[str] = None) -> str:
        """
        Generate OAuth authorization URL for YouTube access.

        Args:
            state: Optional state parameter for security

        Returns:
            Authorization URL for OAuth flow
        """
        logger.info("🔐 Generating YouTube OAuth authorization URL")
        logger.info(f"   - State parameter: {state if state else 'None'}")
        logger.info(
            f"   - Client ID: {self.client_id[:10]}..." if self.client_id else "None"
        )
        logger.info(f"   - Redirect URI: {self.redirect_uri}")
        logger.info(f"   - Scopes: {', '.join(self.scopes)}")

        try:
            if not self.client_id:
                logger.error("❌ YOUTUBE_CLIENT_ID not configured")
                raise ValueError("YOUTUBE_CLIENT_ID not configured")

            logger.info("🔧 Creating OAuth InstalledAppFlow instance")
            flow_instance = InstalledAppFlow.from_client_config(
                {
                    "installed": {
                        "client_id": self.client_id,
                        "client_secret": self.client_secret,
                        "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                        "token_uri": "https://oauth2.googleapis.com/token",
                        "redirect_uris": [self.redirect_uri],
                    }
                },
                scopes=self.scopes,
            )
            flow_instance.redirect_uri = self.redirect_uri
            logger.info("✅ OAuth InstalledAppFlow instance created successfully")

            logger.info("🌐 Generating authorization URL")
            auth_url, _ = flow_instance.authorization_url(
                access_type="offline",
                include_granted_scopes="true",
                prompt="consent",  # Force consent screen to ensure refresh token
                state=state,
            )

            logger.info(f"✅ YouTube OAuth authorization URL generated successfully")
            logger.info(f"   - URL length: {len(auth_url)} characters")
            logger.info(f"   - Contains state: {'Yes' if state in auth_url else 'No'}")
            return auth_url

        except Exception as e:
            logger.error(f"❌ Error generating OAuth authorization URL: {e}")
            logger.error(f"   - Error type: {type(e).__name__}")
            logger.error(
                f"   - Client ID configured: {'Yes' if self.client_id else 'No'}"
            )
            logger.error(
                f"   - Client secret configured: {'Yes' if self.client_secret else 'No'}"
            )
            raise

    def exchange_code_for_token(self, authorization_code: str) -> Dict[str, Any]:
        """
        Exchange authorization code for access and refresh tokens.

        Args:
            authorization_code: Authorization code from OAuth callback

        Returns:
            Dictionary containing tokens and credentials info
        """
        logger.info("🔄 Exchanging YouTube OAuth authorization code for tokens")
        logger.info(
            f"   - Authorization code length: {len(authorization_code)} characters"
        )
        logger.info(f"   - Client ID configured: {'Yes' if self.client_id else 'No'}")
        logger.info(
            f"   - Client secret configured: {'Yes' if self.client_secret else 'No'}"
        )

        try:
            if not self.client_id or not self.client_secret:
                logger.error("❌ OAuth credentials not configured")
                raise ValueError("OAuth credentials not configured")

            logger.info(
                "🔧 Creating OAuth InstalledAppFlow instance for token exchange"
            )
            flow_instance = InstalledAppFlow.from_client_config(
                {
                    "installed": {
                        "client_id": self.client_id,
                        "client_secret": self.client_secret,
                        "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                        "token_uri": "https://oauth2.googleapis.com/token",
                        "redirect_uris": [self.redirect_uri],
                    }
                },
                scopes=self.scopes,
            )
            flow_instance.redirect_uri = self.redirect_uri
            logger.info("✅ OAuth InstalledAppFlow instance created for token exchange")

            # Exchange code for tokens
            logger.info("🔄 Exchanging authorization code for tokens")
            flow_instance.fetch_token(code=authorization_code)
            logger.info("✅ Authorization code exchanged for tokens successfully")

            credentials = flow_instance.credentials
            logger.info(f"📋 Extracting token information: {credentials.to_json()}")

            # Extract token information
            token_info = {
                "access_token": credentials.token,
                "refresh_token": credentials.refresh_token,
                "token_uri": credentials.token_uri,
                "client_id": credentials.client_id,
                "client_secret": credentials.client_secret,
                "scopes": credentials.scopes,
                "expiry": (
                    credentials.expiry.isoformat() if credentials.expiry else None
                ),
            }

            logger.info("✅ Successfully exchanged authorization code for tokens")
            logger.info(
                f"   - Access token length: {len(credentials.token) if credentials.token else 0} characters"
            )
            logger.info(
                f"   - Has refresh token: {'Yes' if credentials.refresh_token else 'No'}"
            )
            logger.info(
                f"   - Token expiry: {credentials.expiry if credentials.expiry else 'No expiry'}"
            )
            logger.info(
                f"   - Scopes granted: {', '.join(credentials.scopes) if credentials.scopes else 'None'}"
            )

            # Additional debugging for refresh token
            if not credentials.refresh_token:
                logger.warning(
                    "⚠️ No refresh token received - this may cause issues with token renewal"
                )
                logger.warning(
                    "   - This can happen if the user has already granted permissions"
                )
                logger.warning("   - Try revoking permissions and re-authorizing")
                logger.warning(
                    "   - Or ensure 'prompt=consent' is used in authorization URL"
                )
            else:
                logger.info(
                    f"✅ Refresh token received: {len(credentials.refresh_token)} characters"
                )

            return token_info

        except Exception as e:
            logger.error(f"❌ Error exchanging authorization code for tokens: {e}")
            logger.error(f"   - Error type: {type(e).__name__}")
            logger.error(f"   - Authorization code length: {len(authorization_code)}")
            logger.error(
                f"   - Client ID configured: {'Yes' if self.client_id else 'No'}"
            )
            logger.error(
                f"   - Client secret configured: {'Yes' if self.client_secret else 'No'}"
            )
            raise

    def create_credentials_from_tokens(self, token_info: Dict[str, Any]) -> Credentials:
        """
        Create Credentials object from stored token information.

        Args:
            token_info: Dictionary containing token information

        Returns:
            Credentials object for API calls
        """
        logger.info("🔑 Creating YouTube OAuth credentials from token info")
        logger.info(f"   - Token info keys: {list(token_info.keys())}")
        logger.info(
            f"   - Has access token: {'Yes' if token_info.get('access_token') else 'No'}"
        )
        logger.info(
            f"   - Has refresh token: {'Yes' if token_info.get('refresh_token') else 'No'}"
        )
        logger.info(f"   - Has expiry: {'Yes' if token_info.get('expiry') else 'No'}")
        logger.info(f"   - Service client_id: {'Yes' if self.client_id else 'No'}")
        logger.info(
            f"   - Service client_secret: {'Yes' if self.client_secret else 'No'}"
        )

        # Validate required fields - only access_token is absolutely required
        if not token_info.get("access_token"):
            logger.error("❌ Missing required access_token")
            raise ValueError("Missing required access_token")

        logger.info(f"Token info: {token_info}")
        # Check if refresh token is available for token refresh capability
        has_refresh_token = bool(token_info.get("refresh_token"))
        logger.info(f"   - Has refresh token: {'Yes' if has_refresh_token else 'No'}")

        # Only require client credentials if refresh token is present
        if has_refresh_token:
            if not self.client_id or not self.client_secret:
                logger.warning(
                    "⚠️ Service OAuth credentials not configured - token refresh will not be available"
                )
                logger.info("ℹ️ Continuing without token refresh capability")
        else:
            logger.info(
                "ℹ️ No refresh token provided - token refresh will not be available"
            )

        try:
            # Create credentials with available fields
            logger.info("🔧 Creating Credentials object")
            credentials = Credentials(
                token=token_info.get("access_token"),
                refresh_token=token_info.get("refresh_token"),
                token_uri=token_info.get(
                    "token_uri", "https://oauth2.googleapis.com/token"
                ),
                client_id=(
                    self.client_id if has_refresh_token else None
                ),  # Only if refresh token available
                client_secret=(
                    self.client_secret if has_refresh_token else None
                ),  # Only if refresh token available
                scopes=token_info.get("scopes", self.scopes),
            )

            if has_refresh_token and self.client_id and self.client_secret:
                logger.info(
                    "✅ Credentials object created successfully with refresh capability"
                )
            else:
                logger.info(
                    "✅ Credentials object created successfully (no refresh capability)"
                )

            # Set expiry if provided
            if token_info.get("expiry"):
                logger.info("⏰ Setting token expiry")
                credentials.expiry = datetime.fromisoformat(
                    token_info["expiry"].replace("Z", "+00:00")
                )
                logger.info(f"   - Expiry set to: {credentials.expiry}")
            else:
                logger.info("ℹ️ No expiry information provided")

            logger.info("✅ Successfully created credentials from token info")
            logger.info(
                f"   - Access token length: {len(credentials.token) if credentials.token else 0} characters"
            )
            logger.info(
                f"   - Has refresh token: {'Yes' if credentials.refresh_token else 'No'}"
            )
            logger.info(f"   - Token URI: {credentials.token_uri}")
            logger.info(f"   - Client ID: {'Yes' if credentials.client_id else 'No'}")
            logger.info(
                f"   - Client Secret: {'Yes' if credentials.client_secret else 'No'}"
            )
            logger.info(
                f"   - Scopes: {', '.join(credentials.scopes) if credentials.scopes else 'None'}"
            )

            if has_refresh_token and self.client_id and self.client_secret:
                logger.info("🔄 Credentials ready for token refresh operations")
            else:
                logger.info("ℹ️ Credentials created without token refresh capability")

            return credentials

        except Exception as e:
            logger.error(f"❌ Error creating credentials from tokens: {e}")
            logger.error(f"   - Error type: {type(e).__name__}")
            logger.error(
                f"   - Token info keys: {list(token_info.keys()) if token_info else 'None'}"
            )
            raise

    def refresh_credentials(self, credentials: Credentials) -> Credentials:
        """
        Refresh expired credentials.

        Args:
            credentials: Expired credentials object

        Returns:
            Refreshed credentials object
        """
        logger.info("🔄 Attempting to refresh YouTube OAuth credentials")
        logger.info(
            f"   - Credentials expired: {'Yes' if credentials.expired else 'No'}"
        )
        logger.info(
            f"   - Has refresh token: {'Yes' if credentials.refresh_token else 'No'}"
        )
        logger.info(f"   - Has client_id: {'Yes' if credentials.client_id else 'No'}")
        logger.info(
            f"   - Has client_secret: {'Yes' if credentials.client_secret else 'No'}"
        )
        logger.info(f"   - Token URI: {credentials.token_uri}")

        try:
            if (
                credentials.expired
                and credentials.refresh_token
                and credentials.client_id
                and credentials.client_secret
            ):
                logger.info("🔧 Refreshing expired credentials")
                request = Request()
                credentials.refresh(request)
                logger.info("✅ Successfully refreshed YouTube credentials")
                logger.info(
                    f"   - New access token length: {len(credentials.token) if credentials.token else 0} characters"
                )
                logger.info(
                    f"   - New expiry: {credentials.expiry if credentials.expiry else 'No expiry'}"
                )
            elif credentials.expired and not credentials.refresh_token:
                logger.warning("⚠️ Credentials expired but no refresh token available")
            elif credentials.expired and not (
                credentials.client_id and credentials.client_secret
            ):
                logger.warning(
                    "⚠️ Credentials expired but client credentials not available for refresh"
                )
            else:
                logger.info("ℹ️ Credentials not expired, no refresh needed")
            return credentials

        except Exception as e:
            logger.error(f"❌ Error refreshing credentials: {e}")
            logger.error(f"   - Error type: {type(e).__name__}")
            logger.error(
                f"   - Credentials expired: {'Yes' if credentials.expired else 'No'}"
            )
            logger.error(
                f"   - Has refresh token: {'Yes' if credentials.refresh_token else 'No'}"
            )
            logger.error(
                f"   - Has client_id: {'Yes' if credentials.client_id else 'No'}"
            )
            logger.error(
                f"   - Has client_secret: {'Yes' if credentials.client_secret else 'No'}"
            )
            raise

    def get_channel_info_from_credentials(
        self, credentials: Credentials
    ) -> Dict[str, Any]:
        """
        Get channel information using OAuth credentials.

        Args:
            credentials: OAuth credentials

        Returns:
            Dictionary with channel information
        """
        try:
            youtube = self._build_youtube_data_service(credentials)

            # Get channel information
            response = (
                youtube.channels()
                .list(part="snippet,contentDetails,statistics", mine=True)
                .execute()
            )

            if not response.get("items"):
                raise ValueError("No channels found for authenticated user")

            channel = response["items"][0]
            channel_info = {
                "channelId": channel["id"],
                "title": channel["snippet"]["title"],
                "description": channel["snippet"]["description"],
                "subscriberCount": int(channel["statistics"].get("subscriberCount", 0)),
                "videoCount": int(channel["statistics"].get("videoCount", 0)),
                "viewCount": int(channel["statistics"].get("viewCount", 0)),
                "thumbnailUrl": channel["snippet"]["thumbnails"]["default"]["url"],
            }

            logger.info(f"Retrieved channel info for: {channel_info['title']}")
            return channel_info

        except Exception as e:
            logger.error(f"Error getting channel info from credentials: {e}")
            raise

    def validate_credentials(self, credentials: Credentials) -> bool:
        """
        Validate if credentials are still valid.

        Args:
            credentials: Credentials to validate

        Returns:
            True if credentials are valid, False otherwise
        """
        try:
            # Try to make a simple API call
            youtube = self._build_youtube_data_service(credentials)
            youtube.channels().list(part="id", mine=True).execute()
            return True

        except Exception as e:
            logger.warning(f"Credentials validation failed: {e}")
            return False

    async def _get_demographic_analytics(
        self, credentials: Credentials, channel_id: Optional[str] = None
    ) -> Optional[Dict[str, Any]]:
        """
        Fetch demographic analytics for authenticated user using OAuth credentials.

        Args:
            credentials: OAuth credentials for YouTube Analytics API

        Returns:
            Dictionary containing demographic data or None if failed
        """
        try:
            logger.info("Fetching demographic analytics for authenticated user")

            # Build YouTube Analytics API service
            youtube_analytics = self._build_youtube_analytics_service(credentials)

            # Get age demographics
            age_demographics = await self._get_age_demographics(
                youtube_analytics, channel_id
            )

            logger.info(f"Age demographics: {age_demographics}")

            # Get gender demographics
            gender_demographics = await self._get_gender_demographics(
                youtube_analytics, channel_id
            )

            logger.info(f"Gender demographics: {gender_demographics}")

            # Get country demographics
            country_demographics = await self._get_country_demographics(
                youtube_analytics, channel_id
            )

            logger.info(f"Country demographics: {country_demographics}")

            # Combine demographic data
            demographics = {}
            if age_demographics:
                demographics["demographicsByAge"] = age_demographics
            if gender_demographics:
                demographics["demographicsByGender"] = gender_demographics
            if country_demographics:
                demographics["demographicsByCountry"] = country_demographics

            logger.info(f"Demographics: {demographics}")
            return demographics

        except Exception as e:
            logger.error(
                f"Error fetching demographic analytics for authenticated user: {e}"
            )
            return None

    async def _get_age_demographics(
        self, youtube_analytics, channel_id: Optional[str] = None
    ) -> Optional[Dict[str, int]]:
        """Get age demographics for authenticated user."""
        try:
            # Use specific channel ID if provided, otherwise use MINE
            ids_param = f"channel=={channel_id}" if channel_id else "channel==MINE"
            logger.info(f"📊 Age demographics using: {ids_param}")

            request = youtube_analytics.reports().query(
                ids=ids_param,
                startDate="2023-01-01",
                endDate="2023-12-31",
                metrics="viewerPercentage",
                dimensions="ageGroup",
            )

            response = request.execute()

            if "rows" in response:
                demographics = {}
                for row in response["rows"]:
                    age_group = row[0]
                    percentage = int(row[1])
                    demographics[age_group] = percentage
                return demographics

            return None

        except Exception as e:
            logger.error(f"Error fetching age demographics: {e}")
            return None

    async def _get_gender_demographics(
        self, youtube_analytics, channel_id: Optional[str] = None
    ) -> Optional[Dict[str, int]]:
        """Get gender demographics for authenticated user."""
        try:
            # Use specific channel ID if provided, otherwise use MINE
            ids_param = f"channel=={channel_id}" if channel_id else "channel==MINE"
            logger.info(f"📊 Gender demographics using: {ids_param}")

            request = youtube_analytics.reports().query(
                ids=ids_param,
                startDate="2023-01-01",
                endDate="2023-12-31",
                metrics="viewerPercentage",
                dimensions="gender",
            )

            response = request.execute()

            if "rows" in response:
                demographics = {}
                for row in response["rows"]:
                    gender = row[0]
                    percentage = int(row[1])
                    demographics[gender] = percentage
                return demographics

            return None

        except Exception as e:
            logger.error(f"Error fetching gender demographics: {e}")
            return None

    async def _get_country_demographics(
        self, youtube_analytics, channel_id: Optional[str] = None
    ) -> Optional[Dict[str, int]]:
        """Get country demographics for authenticated user."""
        try:
            # Use specific channel ID if provided, otherwise use MINE
            ids_param = f"channel=={channel_id}" if channel_id else "channel==MINE"
            logger.info(f"📊 Country demographics using: {ids_param}")

            request = youtube_analytics.reports().query(
                ids=ids_param,
                startDate="2023-01-01",
                endDate="2023-12-31",
                metrics="viewerPercentage",
                dimensions="country",
            )

            response = request.execute()

            if "rows" in response:
                demographics = {}
                for row in response["rows"]:
                    country = row[0]
                    percentage = int(row[1])
                    demographics[country] = percentage
                return demographics

            return None

        except Exception as e:
            logger.error(f"Error fetching country demographics: {e}")
            return None


# Global YouTube Analytics service instance
youtube_analytics_service = YouTubeAnalyticsService()
