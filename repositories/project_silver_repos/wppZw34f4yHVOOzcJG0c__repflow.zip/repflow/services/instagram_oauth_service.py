"""
Instagram OAuth service: authorize URL and token exchange.
Uses env vars INSTAGRAM_OAUTH_CLIENT_ID, INSTAGRAM_OAUTH_CLIENT_SECRET, INSTAGRAM_OAUTH_REDIRECT_URI.
"""

import logging
import os
from typing import Any, Dict, Optional
from urllib.parse import urlencode

import httpx

logger = logging.getLogger("uvicorn.error")

# Default redirect for frontend callback page (must match Meta app config)
REPFLOW_FRONTEND_URL = os.getenv("REPFLOW_FRONTEND_URL", "https://creator.userepflow.com")


class InstagramOAuthService:
    def __init__(self) -> None:
        self.client_id = os.getenv("INSTAGRAM_OAUTH_CLIENT_ID", "")
        self.client_secret = os.getenv("INSTAGRAM_OAUTH_CLIENT_SECRET", "")
        self.redirect_uri = os.getenv(
            "INSTAGRAM_OAUTH_REDIRECT_URI",
            f"{REPFLOW_FRONTEND_URL}/auth/instagram/callback",
        )
        self.scopes = [
            "instagram_basic",
            "instagram_manage_insights",
        ]
        if not self.client_id or not self.client_secret:
            logger.warning("INSTAGRAM_OAUTH_CLIENT_ID or INSTAGRAM_OAUTH_CLIENT_SECRET not set")

    def get_oauth_authorization_url(self, state: Optional[str] = None) -> str:
        params = {
            "client_id": self.client_id,
            "redirect_uri": self.redirect_uri,
            "scope": ",".join(self.scopes),
            "response_type": "code",
        }
        if state:
            params["state"] = state
        url = f"https://api.instagram.com/oauth/authorize?{urlencode(params)}"
        logger.info("Instagram OAuth URL generated")
        return url

    async def exchange_code_for_token(self, code: str) -> Optional[Dict[str, Any]]:
        """Exchange authorization code for short-lived token, then long-lived token and user info."""
        if not self.client_id or not self.client_secret:
            logger.error("Instagram OAuth credentials not configured")
            return None
        async with httpx.AsyncClient() as client:
            # Short-lived token
            token_resp = await client.post(
                "https://api.instagram.com/oauth/access_token",
                data={
                    "client_id": self.client_id,
                    "client_secret": self.client_secret,
                    "grant_type": "authorization_code",
                    "redirect_uri": self.redirect_uri,
                    "code": code,
                },
                headers={"Content-Type": "application/x-www-form-urlencoded"},
            )
            if token_resp.status_code != 200:
                logger.error("Instagram token exchange failed: %s", token_resp.text)
                return None
            data = token_resp.json()
            access_token = data.get("access_token")
            user_id = data.get("user_id")
            if not access_token or not user_id:
                logger.error("Instagram response missing access_token or user_id")
                return None
            # Long-lived token (60 days)
            long_resp = await client.get(
                "https://graph.instagram.com/access_token",
                params={
                    "grant_type": "ig_exchange_token",
                    "client_secret": self.client_secret,
                    "access_token": access_token,
                },
            )
            if long_resp.status_code == 200:
                long_data = long_resp.json()
                access_token = long_data.get("access_token", access_token)
                expires_in = long_data.get("expires_in", 5184000)
            else:
                expires_in = 3600
            # User info
            me_resp = await client.get(
                "https://graph.instagram.com/me",
                params={
                    "fields": "id,username,name,account_type,profile_picture_url,followers_count,media_count",
                    "access_token": access_token,
                },
            )
            username = user_id
            name = f"Instagram ({user_id})"
            if me_resp.status_code == 200:
                me = me_resp.json()
                username = me.get("username", username)
                name = me.get("name") or me.get("username") or name
            token_info = {
                "access_token": access_token,
                "user_id": user_id,
                "expires_in": expires_in,
            }
            user_info = {
                "user_id": user_id,
                "username": username,
                "name": name,
                "handle": f"@{username}",
            }
            return {"tokens": token_info, "user": user_info}


instagram_oauth_service = InstagramOAuthService()
