import os
import stripe
import uuid
import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, Tuple
from database.models.user import User, ReferralData, ReferralHistory
from database.models.referral import Referral, ReferralStatus
from pydantic import HttpUrl

# Configure logging
logger = logging.getLogger("uvicorn.error")

# Initialize Stripe
stripe.api_key = os.getenv("STRIPE_SECRET_KEY")

# Frontend URL for referral links (configurable via environment variable)
FRONTEND_URL = os.getenv("FRONTEND_URL", "https://creator.userepflow.com")


class ReferralService:
    """Service for managing referral programs and Stripe integration"""

    def __init__(self):
        self.discount_percentage = 20.0  # 20% discount
        self.referrer_discount_percentage = (
            20.0  # 20% discount for referrer on next billing cycle
        )

    async def generate_referral_code(self, user: User) -> str:
        """
        Generate a unique alphanumeric referral code for a user.

        Args:
            user: User object to generate referral code for

        Returns:
            str: Generated unique alphanumeric referral code
        """
        import random
        import string

        # Generate a unique 6-character code using timestamp + random characters
        # This ensures uniqueness without database validation
        timestamp = str(int(datetime.utcnow().timestamp()))[
            -3:
        ]  # Last 3 digits of timestamp
        random_chars = "".join(
            random.choices(string.ascii_uppercase + string.digits, k=3)
        )

        # Combine timestamp and random characters for guaranteed uniqueness (6 chars total)
        code = f"{timestamp}{random_chars}"

        logger.info(f"Generated unique alphanumeric referral code: {code}")
        return code

    async def create_stripe_promotion_code(
        self, referral_code: str, coupon_id: Optional[str] = None
    ) -> Tuple[str, str]:
        """
        Create a Stripe promotion code for the referral.

        Args:
            referral_code: The referral code
            coupon_id: Optional coupon ID to attach to the promotion code

        Returns:
            Tuple[str, str]: (promotion_code_id, coupon_id)
        """
        try:
            # Create coupon if not provided
            if not coupon_id:
                coupon = stripe.Coupon.create(
                    percent_off=self.discount_percentage,
                    duration="once",  # One-time discount
                    name=f"Referral Discount - {referral_code}",
                    metadata={
                        "referral_code": referral_code,
                        "type": "referral_discount",
                    },
                )
                coupon_id = coupon.id
                logger.info(f"Created Stripe coupon: {coupon_id}")

            # Create promotion code
            # Stripe API now requires a 'promotion' object instead of direct 'coupon' parameter
            promotion_code = stripe.PromotionCode.create(
                promotion={
                    "type": "coupon",
                    "coupon": coupon_id,
                },
                code=referral_code,
                max_redemptions=None,  # No limit on redemptions
                expires_at=int(
                    (datetime.utcnow() + timedelta(days=365)).timestamp()
                ),  # Valid for 1 year
                metadata={"referral_code": referral_code, "type": "referral_discount"},
            )

            logger.info(f"Created Stripe promotion code: {promotion_code.id}")
            return promotion_code.id, coupon_id

        except stripe.error.StripeError as e:
            logger.error(f"Stripe error creating promotion code: {str(e)}")
            raise Exception(f"Failed to create Stripe promotion code: {str(e)}")
        except Exception as e:
            logger.error(f"Error creating Stripe promotion code: {str(e)}")
            raise

    async def setup_user_referral_program(
        self, user: User, force_setup: bool = False
    ) -> User:
        """
        Set up referral program for a new user by generating referral code and creating Stripe promotion code.

        Args:
            user: User object to set up referral program for
            force_setup: Whether to force setup even if referral data already exists

        Returns:
            User: Updated user object with referral data
        """
        try:
            # Check if referral program is already set up
            if user.referralData and user.referralData.isActive and not force_setup:
                logger.info(f"Referral program already set up for user {user.uuid}")
                return user
            # Generate referral code
            referral_code = await self.generate_referral_code(user)

            # Create Stripe promotion code
            promotion_code_id, coupon_id = await self.create_stripe_promotion_code(
                referral_code
            )

            # Create referral data using the proper model
            referral_link = f"{FRONTEND_URL}/signup?ref={referral_code}"
            referral_data = ReferralData(
                referralCode=referral_code,
                referralLink=HttpUrl(referral_link),
                totalReferrals=0,
                totalRevenue=0.0,
                pendingPayouts=0.0,
                referralHistory=[],
                stripePromotionCodeId=promotion_code_id,
                isActive=True,
                createdAt=datetime.utcnow(),
                updatedAt=datetime.utcnow(),
            )

            # Update user with referral data
            user.referralData = referral_data
            user.updatedAt = datetime.utcnow()

            # Save user
            await user.save()

            logger.info(
                f"Set up referral program for user {user.uuid} with code: {referral_code}"
            )
            return user

        except Exception as e:
            logger.error(
                f"Error setting up referral program for user {user.uuid}: {str(e)}"
            )
            # Caller may continue without referral data; do not re-raise
            return user

    async def validate_referral_code(self, referral_code: str) -> Optional[User]:
        """
        Validate a referral code and return the referring user.

        Args:
            referral_code: The referral code to validate

        Returns:
            Optional[User]: The referring user if code is valid, None otherwise
        """
        try:
            user = await User.find_one({"referralData.referralCode": referral_code})

            if not user or not user.referralData or not user.referralData.isActive:
                logger.warning(f"Invalid or inactive referral code: {referral_code}")
                return None

            logger.info(f"Valid referral code found for user: {user.uuid}")
            return user

        except Exception as e:
            logger.error(f"Error validating referral code {referral_code}: {str(e)}")
            return None

    async def create_referral_record(
        self,
        referrer: User,
        referee_user_id: str,
        stripe_customer_id: Optional[str] = None,
    ) -> Referral:
        """
        Create a referral record when someone uses a referral code.

        Args:
            referrer: User who created the referral code
            referee_user_id: ID of the user who used the referral code
            stripe_customer_id: Stripe customer ID of the referee

        Returns:
            Referral: Created referral record
        """
        try:
            referral_id = str(uuid.uuid4())

            # Create referral record
            referral = Referral(
                referralId=referral_id,
                referralCreatorId=referrer.uuid,
                referralCustomerId=referee_user_id,
                referralCode=referrer.referralData.referralCode,
                status=ReferralStatus.PENDING,
                stripePromotionCodeId=referrer.referralData.stripePromotionCodeId,
                stripeCustomerId=stripe_customer_id,
                expiresAt=datetime.utcnow() + timedelta(days=30),  # Expires in 30 days
            )

            # Save referral record
            logger.info(
                f"Attempting to insert referral record {referral_id} into database..."
            )
            await referral.insert()
            logger.info(
                f"Successfully inserted referral record {referral_id} into database"
            )

            # Verify the record was saved
            saved_referral = await Referral.find_one(Referral.referralId == referral_id)
            if saved_referral:
                logger.info(
                    f"Verified referral record {referral_id} exists in database"
                )
            else:
                logger.error(
                    f"Failed to verify referral record {referral_id} in database"
                )

            logger.info(
                f"Created referral record {referral_id} for referrer {referrer.uuid} and referee {referee_user_id}"
            )
            return referral

        except Exception as e:
            logger.error(f"Error creating referral record: {str(e)}")
            raise

    async def complete_referral(
        self, referral: Referral, revenue: float
    ) -> Tuple[Referral, User, User]:
        """
        Complete a referral when the referee makes a payment.

        Args:
            referral: Referral record to complete
            revenue: Revenue generated from the referral

        Returns:
            Tuple[Referral, User, User]: (updated_referral, updated_referrer, updated_referee)
        """
        try:
            # Update referral status
            referral.status = ReferralStatus.COMPLETED
            referral.completedAt = datetime.utcnow()
            referral.referralRevenue = revenue
            referral.referrerReward = revenue * (
                self.referrer_discount_percentage / 100
            )

            await referral.save()

            # Update referrer's referral data
            referrer = await User.find_one(User.uuid == referral.referralCreatorId)
            if referrer and referrer.referralData:
                referrer.referralData.totalReferrals += 1
                referrer.referralData.totalRevenue += revenue
                referrer.referralData.pendingPayouts += referral.referrerReward
                referrer.referralData.updatedAt = datetime.utcnow()

                # Add to referral history
                history_item = ReferralHistory(
                    id=referral.referralId,
                    referredUserName="New User",  # You might want to fetch the actual name
                    status="completed",
                    revenue=revenue,
                    date=datetime.utcnow(),
                )
                referrer.referralData.referralHistory.append(history_item)

                await referrer.save()

            # Update referee user (if needed)
            referee = await User.find_one(User.uuid == referral.referralCustomerId)
            if referee:
                referee.updatedAt = datetime.utcnow()
                await referee.save()

            logger.info(
                f"Completed referral {referral.referralId} with revenue: ${revenue}"
            )
            return referral, referrer, referee

        except Exception as e:
            logger.error(f"Error completing referral {referral.referralId}: {str(e)}")
            raise

    async def apply_referrer_discount(
        self, referrer: User, next_billing_date: datetime
    ) -> bool:
        """
        Apply discount to referrer's next billing cycle.

        Args:
            referrer: User who should receive the discount
            next_billing_date: When the next billing cycle starts

        Returns:
            bool: True if discount was applied successfully
        """
        try:
            # Create a coupon for the referrer's next billing cycle
            coupon = stripe.Coupon.create(
                percent_off=self.referrer_discount_percentage,
                duration="once",
                name=f"Referrer Reward - {referrer.referralData.referralCode}",
                metadata={
                    "user_id": referrer.uuid,
                    "type": "referrer_reward",
                    "referral_code": referrer.referralData.referralCode,
                },
            )

            # You would typically associate this coupon with the user's subscription
            # This depends on your subscription management system
            logger.info(
                f"Created referrer reward coupon {coupon.id} for user {referrer.uuid}"
            )

            return True

        except Exception as e:
            logger.error(
                f"Error applying referrer discount for user {referrer.uuid}: {str(e)}"
            )
            return False

    async def get_referral_stats(self, user: User) -> Dict[str, Any]:
        """
        Get referral statistics for a user.

        Args:
            user: User to get stats for

        Returns:
            Dict[str, Any]: Referral statistics
        """
        try:
            # Get all referrals created by this user
            referrals = await Referral.find(
                Referral.referralCreatorId == user.uuid
            ).to_list()

            stats = {
                "totalReferrals": len(referrals),
                "completedReferrals": len(
                    [r for r in referrals if r.status == ReferralStatus.COMPLETED]
                ),
                "pendingReferrals": len(
                    [r for r in referrals if r.status == ReferralStatus.PENDING]
                ),
                "totalRevenue": sum(r.referralRevenue for r in referrals),
                "totalRewards": sum(r.referrerReward for r in referrals),
                "referralCode": (
                    user.referralData.referralCode if user.referralData else None
                ),
                "referralLink": (
                    str(user.referralData.referralLink) if user.referralData else None
                ),
            }

            return stats

        except Exception as e:
            logger.error(f"Error getting referral stats for user {user.uuid}: {str(e)}")
            return {}

    async def regenerate_referral_code(self, user: User) -> User:
        """
        Regenerate a new referral code for an existing user.
        This creates a new code and Stripe promotion code, replacing the old one.

        Args:
            user: User object to regenerate referral code for

        Returns:
            User: Updated user object with new referral data
        """
        try:
            # Ensure user has referral data first
            if not user.referralData:
                logger.info(f"User {user.uuid} has no referral data, setting up first")
                return await self.setup_user_referral_program(user, force_setup=True)

            # Generate new referral code
            new_referral_code = await self.generate_referral_code(user)

            # Create new Stripe promotion code
            promotion_code_id, coupon_id = await self.create_stripe_promotion_code(
                new_referral_code
            )

            # Update referral data with new code
            referral_link = f"{FRONTEND_URL}/signup?ref={new_referral_code}"
            user.referralData.referralCode = new_referral_code
            user.referralData.referralLink = HttpUrl(referral_link)
            user.referralData.stripePromotionCodeId = promotion_code_id
            user.referralData.updatedAt = datetime.utcnow()
            user.updatedAt = datetime.utcnow()

            # Save user
            await user.save()

            logger.info(
                f"Regenerated referral code for user {user.uuid}: {new_referral_code}"
            )
            return user

        except Exception as e:
            logger.error(
                f"Error regenerating referral code for user {user.uuid}: {str(e)}"
            )
            raise

    async def ensure_user_has_referral_data(self, user: User) -> User:
        """
        Ensure a user has referral data. If not, set it up.

        Args:
            user: User object to check and potentially set up

        Returns:
            User: User with referral data (either existing or newly created)
        """
        try:
            if not user.referralData or not user.referralData.isActive:
                logger.info(f"Setting up referral data for user {user.uuid}")
                return await self.setup_user_referral_program(user, force_setup=True)
            return user
        except Exception as e:
            logger.error(f"Error ensuring referral data for user {user.uuid}: {str(e)}")
            return user


# Create singleton instance
referral_service = ReferralService()
