"""
YouTube Analytics Service - Direct API Version
Fetches YouTube channel analytics using direct HTTP API calls instead of googleapiclient.
"""

import os
import json
import logging
import httpx
from datetime import datetime, timezone, timedelta
from typing import Optional, Dict, Any, List
from urllib.parse import urlencode

from database.models.user import YouTubeAnalytics

REPFLOW_FRONTEND_URL = "https://creator.userepflow.com"

logger = logging.getLogger('uvicorn.error')


class YouTubeAnalyticsService:
    """Service for fetching YouTube channel analytics using direct API calls."""
    
    def __init__(self):
        """Initialize the YouTube Analytics service."""
        logger.info("🎬 Initializing YouTube Analytics Service (Direct API)")
        
        self.youtube_data_api_base = "https://www.googleapis.com/youtube/v3"
        self.youtube_analytics_api_base = "https://youtubeanalytics.googleapis.com/v2"
        self.api_key = 'AIzaSyAI1BbRTUyT_A01zCYrAKcU-vc71ELifzk'
        
        # OAuth configuration
        self.client_id = "620137782462-8nukt3nbvrjair76dt75ls62cnri9siq.apps.googleusercontent.com"
        self.client_secret = "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"
        self.redirect_uri = os.getenv('YOUTUBE_REDIRECT_URI', f'{REPFLOW_FRONTEND_URL}/auth/youtube/callback')
        self.scopes = [
            'https://www.googleapis.com/auth/youtube.readonly',
            'https://www.googleapis.com/auth/yt-analytics.readonly',
            'https://www.googleapis.com/auth/yt-analytics-monetary.readonly'
        ]
        
        logger.info(f"📊 YouTube Analytics Service initialized with:")
        logger.info(f"   - YouTube Data API: {self.youtube_data_api_base}")
        logger.info(f"   - YouTube Analytics API: {self.youtube_analytics_api_base}")
        logger.info(f"   - Redirect URI: {self.redirect_uri}")
        logger.info(f"   - Scopes: {', '.join(self.scopes)}")
        
        if not self.api_key:
            logger.warning("⚠️ YOUTUBE_API_KEY not set - YouTube analytics will not work")
        else:
            logger.info("✅ YouTube API key configured")
        
        if not self.client_id or not self.client_secret:
            logger.warning("⚠️ YOUTUBE_CLIENT_ID or YOUTUBE_CLIENT_SECRET not set - OAuth will not work")
        else:
            logger.info("✅ YouTube OAuth credentials configured")

    async def _make_authenticated_request(
        self, 
        url: str, 
        access_token: str, 
        params: Optional[Dict[str, Any]] = None
    ) -> Optional[Dict[str, Any]]:
        """Make an authenticated HTTP request to YouTube API."""
        try:
            headers = {
                'Authorization': f'Bearer {access_token}',
                'Accept': 'application/json'
            }
            
            async with httpx.AsyncClient() as client:
                logger.info(f"🌐 Making authenticated request to: {url}")
                logger.info(f"   - Params: {params}")
                
                response = await client.get(url, headers=headers, params=params)
                
                if response.status_code == 200:
                    data = response.json()
                    logger.info(f"✅ Request successful: {response.status_code}")
                    return data
                else:
                    logger.error(f"❌ Request failed: {response.status_code}")
                    logger.error(f"   - Response: {response.text}")
                    return None
                    
        except Exception as e:
            logger.error(f"❌ Error making authenticated request: {e}")
            return None

    async def _get_basic_channel_stats(self, access_token: str) -> Optional[Dict[str, Any]]:
        """Get basic channel statistics using YouTube Data API."""
        try:
            logger.info("📊 Fetching basic channel statistics")
            
            url = f"{self.youtube_data_api_base}/channels"
            params = {
                'part': 'statistics,snippet',
                'mine': 'true'
            }
            
            response = await self._make_authenticated_request(url, access_token, params)
            
            if response and response.get('items'):
                channel = response['items'][0]
                stats = channel.get('statistics', {})
                snippet = channel.get('snippet', {})
                
                result = {
                    'subscriberCount': int(stats.get('subscriberCount', 0)),
                    'videoCount': int(stats.get('videoCount', 0)),
                    'viewCount': int(stats.get('viewCount', 0)),
                    'channelId': channel.get('id'),
                    'channelTitle': snippet.get('title'),
                    'channelDescription': snippet.get('description'),
                    'publishedAt': snippet.get('publishedAt')
                }
                
                logger.info(f"✅ Basic stats fetched successfully")
                logger.info(f"   - Subscribers: {result['subscriberCount']:,}")
                logger.info(f"   - Videos: {result['videoCount']:,}")
                logger.info(f"   - Views: {result['viewCount']:,}")
                
                return result
            else:
                logger.warning("⚠️ No channel data found")
                return None
                
        except Exception as e:
            logger.error(f"❌ Error fetching basic channel stats: {e}")
            return None

    async def _get_detailed_analytics(self, access_token: str) -> Optional[Dict[str, Any]]:
        """Get detailed analytics using YouTube Analytics API."""
        try:
            logger.info("📈 Fetching detailed analytics")
            
            # Calculate date range (last 28 days)
            end_date = datetime.now(timezone.utc).date()
            start_date = end_date - timedelta(days=28)
            
            url = f"{self.youtube_analytics_api_base}/reports"
            params = {
                'ids': 'channel==MINE',
                'startDate': start_date.isoformat(),
                'endDate': end_date.isoformat(),
                'metrics': 'views,subscribersGained,subscribersLost,estimatedMinutesWatched,averageViewDuration',
                'dimensions': 'day'
            }
            
            response = await self._make_authenticated_request(url, access_token, params)
            
            if response and response.get('rows'):
                # Process the analytics data
                total_views = 0
                total_subscribers_gained = 0
                total_subscribers_lost = 0
                total_watch_time = 0
                total_avg_duration = 0
                row_count = len(response['rows'])
                
                for row in response['rows']:
                    # Row format: [date, views, subscribersGained, subscribersLost, watchTime, avgDuration]
                    if len(row) >= 6:
                        total_views += row[1] or 0
                        total_subscribers_gained += row[2] or 0
                        total_subscribers_lost += row[3] or 0
                        total_watch_time += row[4] or 0
                        total_avg_duration += row[5] or 0
                
                result = {
                    'recentViews': total_views,
                    'recentSubscribersGained': total_subscribers_gained,
                    'recentSubscribersLost': total_subscribers_lost,
                    'recentWatchTimeMinutes': total_watch_time,
                    'averageViewDuration': total_avg_duration / row_count if row_count > 0 else 0
                }
                
                logger.info(f"✅ Detailed analytics fetched successfully")
                logger.info(f"   - Recent views: {result['recentViews']:,}")
                logger.info(f"   - Subscribers gained: {result['recentSubscribersGained']:,}")
                logger.info(f"   - Watch time (minutes): {result['recentWatchTimeMinutes']:,}")
                
                return result
            else:
                logger.warning("⚠️ No analytics data found")
                return {}
                
        except Exception as e:
            logger.error(f"❌ Error fetching detailed analytics: {e}")
            return {}

    async def _get_top_videos(self, access_token: str) -> Optional[Dict[str, Any]]:
        """Get top performing videos."""
        try:
            logger.info("🏆 Fetching top performing videos")
            
            # First, get recent videos
            url = f"{self.youtube_data_api_base}/search"
            params = {
                'part': 'id',
                'forMine': 'true',
                'type': 'video',
                'order': 'date',
                'maxResults': 10,
                'publishedAfter': (datetime.now(timezone.utc) - timedelta(days=30)).isoformat()
            }
            
            search_response = await self._make_authenticated_request(url, access_token, params)
            
            if not search_response or not search_response.get('items'):
                logger.warning("⚠️ No recent videos found")
                return {}
            
            # Get video IDs
            video_ids = [item['id']['videoId'] for item in search_response['items']]
            
            # Get video statistics
            url = f"{self.youtube_data_api_base}/videos"
            params = {
                'part': 'statistics,snippet',
                'id': ','.join(video_ids)
            }
            
            videos_response = await self._make_authenticated_request(url, access_token, params)
            
            if videos_response and videos_response.get('items'):
                # Find the video with most views
                top_video = None
                max_views = 0
                
                for video in videos_response['items']:
                    stats = video.get('statistics', {})
                    view_count = int(stats.get('viewCount', 0))
                    
                    if view_count > max_views:
                        max_views = view_count
                        top_video = video
                
                if top_video:
                    snippet = top_video.get('snippet', {})
                    result = {
                        'topVideoTitle': snippet.get('title'),
                        'topVideoViews': max_views
                    }
                    
                    logger.info(f"✅ Top video found: {result['topVideoTitle']}")
                    logger.info(f"   - Views: {result['topVideoViews']:,}")
                    
                    return result
            
            logger.warning("⚠️ No top video data found")
            return {}
            
        except Exception as e:
            logger.error(f"❌ Error fetching top videos: {e}")
            return {}

    async def _get_revenue_data(self, access_token: str) -> Optional[Dict[str, Any]]:
        """Get estimated revenue data (requires monetization permissions)."""
        try:
            logger.info("💰 Fetching revenue data")
            
            # Calculate date range (last 28 days)
            end_date = datetime.now(timezone.utc).date()
            start_date = end_date - timedelta(days=28)
            
            url = f"{self.youtube_analytics_api_base}/reports"
            params = {
                'ids': 'channel==MINE',
                'startDate': start_date.isoformat(),
                'endDate': end_date.isoformat(),
                'metrics': 'estimatedRevenue',
                'dimensions': 'day'
            }
            
            response = await self._make_authenticated_request(url, access_token, params)
            
            if response and response.get('rows'):
                total_revenue = 0
                for row in response['rows']:
                    if len(row) >= 2:
                        total_revenue += row[1] or 0
                
                result = {
                    'estimatedRevenue': total_revenue
                }
                
                logger.info(f"✅ Revenue data fetched: ${result['estimatedRevenue']:.2f}")
                return result
            else:
                logger.info("ℹ️ No revenue data available (may require monetization)")
                return {}
                
        except Exception as e:
            logger.warning(f"⚠️ Could not fetch revenue data: {e}")
            return {}

    async def get_channel_analytics(
        self,
        access_token: str,
        include_demographics: bool = False
    ) -> Optional[YouTubeAnalytics]:
        """
        Fetch YouTube channel analytics using OAuth access token.
        
        Args:
            access_token: OAuth2 access token (required)
            include_demographics: Whether to include demographic data (not implemented in direct API version)
            
        Returns:
            YouTubeAnalytics object with channel data
        """
        logger.info("🎬 Starting YouTube channel analytics fetch (Direct API)")
        logger.info(f"   - Has access token: {'Yes' if access_token else 'No'}")
        logger.info(f"   - Include demographics: {'Yes' if include_demographics else 'No'}")
        
        if include_demographics:
            logger.warning("⚠️ Demographics not implemented in direct API version")
        
        try:
            # Fetch all data in parallel
            logger.info("📊 Fetching all analytics data...")
            
            async with httpx.AsyncClient() as client:
                # Get basic channel stats
                basic_stats = await self._get_basic_channel_stats(access_token)
                
                # Get detailed analytics
                detailed_analytics = await self._get_detailed_analytics(access_token)
                
                # Get top videos
                top_videos = await self._get_top_videos(access_token)
                
                # Get revenue data
                revenue_data = await self._get_revenue_data(access_token)
            
            # Combine all data
            analytics_data = {}
            
            if basic_stats:
                analytics_data.update(basic_stats)
            
            if detailed_analytics:
                analytics_data.update(detailed_analytics)
            
            if top_videos:
                analytics_data.update(top_videos)
            
            if revenue_data:
                analytics_data.update(revenue_data)
            
            # Create YouTubeAnalytics object
            youtube_analytics = YouTubeAnalytics(
                subscriberCount=analytics_data.get('subscriberCount'),
                videoCount=analytics_data.get('videoCount'),
                viewCount=analytics_data.get('viewCount'),
                recentViews=analytics_data.get('recentViews'),
                recentWatchTimeMinutes=analytics_data.get('recentWatchTimeMinutes'),
                recentSubscribersGained=analytics_data.get('recentSubscribersGained'),
                recentSubscribersLost=analytics_data.get('recentSubscribersLost'),
                averageViewDuration=analytics_data.get('averageViewDuration'),
                estimatedRevenue=analytics_data.get('estimatedRevenue'),
                topVideoTitle=analytics_data.get('topVideoTitle'),
                topVideoViews=analytics_data.get('topVideoViews'),
                channelId=analytics_data.get('channelId'),
                lastUpdated=datetime.utcnow()
            )
            
            logger.info("✅ YouTube analytics compilation completed successfully")
            logger.info(f"   - Subscriber count: {youtube_analytics.subscriberCount or 0:,}")
            logger.info(f"   - Video count: {youtube_analytics.videoCount or 0:,}")
            logger.info(f"   - Total views: {youtube_analytics.viewCount or 0:,}")
            logger.info(f"   - Recent views: {youtube_analytics.recentViews or 0:,}")
            logger.info(f"   - Top video: {youtube_analytics.topVideoTitle or 'N/A'}")
            
            return youtube_analytics
            
        except Exception as e:
            logger.error(f"❌ Error fetching YouTube analytics: {e}")
            return None

    def get_oauth_authorization_url(self, state: Optional[str] = None) -> str:
        """
        Generate OAuth authorization URL for YouTube API access.
        
        Args:
            state: Optional state parameter for security
            
        Returns:
            Authorization URL for user to visit
        """
        logger.info("🔐 Generating OAuth authorization URL")
        
        params = {
            'client_id': self.client_id,
            'redirect_uri': self.redirect_uri,
            'scope': ' '.join(self.scopes),
            'response_type': 'code',
            'access_type': 'offline',
            'prompt': 'consent'
        }
        
        if state:
            params['state'] = state
        
        auth_url = f"https://accounts.google.com/o/oauth2/auth?{urlencode(params)}"
        
        logger.info(f"✅ OAuth URL generated: {auth_url}")
        return auth_url

    async def exchange_code_for_token(self, authorization_code: str) -> Optional[Dict[str, Any]]:
        """
        Exchange authorization code for access token.
        
        Args:
            authorization_code: Authorization code from OAuth callback
            
        Returns:
            Token data including access_token and refresh_token
        """
        logger.info("🔄 Exchanging authorization code for access token")
        
        try:
            url = "https://oauth2.googleapis.com/token"
            data = {
                'client_id': self.client_id,
                'client_secret': self.client_secret,
                'code': authorization_code,
                'grant_type': 'authorization_code',
                'redirect_uri': self.redirect_uri
            }
            
            async with httpx.AsyncClient() as client:
                response = await client.post(url, data=data)
                
                if response.status_code == 200:
                    token_data = response.json()
                    logger.info("✅ Successfully exchanged code for token")
                    logger.info(f"   - Access token: {'Present' if token_data.get('access_token') else 'Missing'}")
                    logger.info(f"   - Refresh token: {'Present' if token_data.get('refresh_token') else 'Missing'}")
                    logger.info(f"   - Expires in: {token_data.get('expires_in', 'Unknown')} seconds")
                    
                    return token_data
                else:
                    logger.error(f"❌ Token exchange failed: {response.status_code}")
                    logger.error(f"   - Response: {response.text}")
                    return None
                    
        except Exception as e:
            logger.error(f"❌ Error exchanging code for token: {e}")
            return None

    async def refresh_access_token(self, refresh_token: str) -> Optional[Dict[str, Any]]:
        """
        Refresh access token using refresh token.
        
        Args:
            refresh_token: Refresh token from previous OAuth flow
            
        Returns:
            New token data
        """
        logger.info("🔄 Refreshing access token")
        
        try:
            url = "https://oauth2.googleapis.com/token"
            data = {
                'client_id': self.client_id,
                'client_secret': self.client_secret,
                'refresh_token': refresh_token,
                'grant_type': 'refresh_token'
            }
            
            async with httpx.AsyncClient() as client:
                response = await client.post(url, data=data)
                
                if response.status_code == 200:
                    token_data = response.json()
                    logger.info("✅ Successfully refreshed access token")
                    logger.info(f"   - New access token: {'Present' if token_data.get('access_token') else 'Missing'}")
                    logger.info(f"   - Expires in: {token_data.get('expires_in', 'Unknown')} seconds")
                    
                    return token_data
                else:
                    logger.error(f"❌ Token refresh failed: {response.status_code}")
                    logger.error(f"   - Response: {response.text}")
                    return None
                    
        except Exception as e:
            logger.error(f"❌ Error refreshing access token: {e}")
            return None

    async def validate_access_token(self, access_token: str) -> bool:
        """
        Validate if access token is still valid.
        
        Args:
            access_token: Access token to validate
            
        Returns:
            True if token is valid, False otherwise
        """
        logger.info("🔍 Validating access token")
        
        try:
            url = f"{self.youtube_data_api_base}/channels"
            params = {
                'part': 'id',
                'mine': 'true'
            }
            
            response = await self._make_authenticated_request(url, access_token, params)
            
            if response:
                logger.info("✅ Access token is valid")
                return True
            else:
                logger.warning("⚠️ Access token is invalid or expired")
                return False
                
        except Exception as e:
            logger.error(f"❌ Error validating access token: {e}")
            return False


# Create a singleton instance
youtube_analytics_service = YouTubeAnalyticsService()
