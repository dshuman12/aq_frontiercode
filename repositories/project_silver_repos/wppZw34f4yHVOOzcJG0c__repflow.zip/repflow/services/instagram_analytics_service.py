"""
Instagram Analytics Service
Fetches Instagram account analytics using the Instagram Graph API.
"""

import os
import asyncio
import logging
import httpx
from datetime import datetime, timezone
from typing import Optional, Dict, Any
from database.models.user import InstagramAnalytics

logger = logging.getLogger('uvicorn.error')


class InstagramReconnectionRequired(Exception):
    """Exception raised when Instagram account needs to be reconnected."""
    pass


class InstagramAnalyticsService:
    """Service for fetching Instagram account analytics."""
    
    def __init__(self):
        """Initialize the Instagram Analytics service."""
        self.api_base_url = "https://graph.instagram.com/v23.0"
        
    async def get_account_data(self, access_token: str) -> Dict[str, Any]:
        """
        Fetch basic Instagram account data.
        
        Args:
            access_token: Instagram access token
            
        Returns:
            Dictionary with account data
        """
        try:
            async with httpx.AsyncClient() as client:
                # Fetch basic account information
                response = await client.get(
                    f"{self.api_base_url}/me",
                    params={
                        "fields": "user_id,username,name,account_type,profile_picture_url,followers_count,follows_count,media_count",
                        "access_token": access_token
                    }
                )
                
                if not response.is_success:
                    logger.error(f"Instagram API request failed: {response.status_code} - {response.text}")
                    raise InstagramReconnectionRequired("Instagram account needs to be reconnected")
                
                account_data = response.json()
                logger.info(f"Fetched Instagram account data for user: {account_data.get('username')}")
                
                # Fetch insights for reach and content views
                insights_data = await self._fetch_insights(access_token)
                
                # Calculate metrics
                avg_short_views = 0
                total_reach = 0
                monthly_reach = 0
                
                if insights_data:
                    avg_short_views = insights_data.get("avg_short_views", 0)
                    total_reach = insights_data.get("total_reach", 0)
                    monthly_reach = insights_data.get("monthly_reach", 0)
                
                return {
                    "followers_count": account_data.get("followers_count", 0),
                    "media_count": account_data.get("media_count", 0),
                    "profile_picture_url": account_data.get("profile_picture_url"),
                    "avg_short_views": avg_short_views,
                    "total_reach": total_reach,
                    "monthly_reach": monthly_reach,
                }
                
        except Exception as e:
            logger.error(f"Error fetching Instagram account data: {e}")
            return {
                "followers_count": 0,
                "media_count": 0,
                "profile_picture_url": None,
                "avg_short_views": 0,
                "total_reach": 0,
                "monthly_reach": 0,
            }
    
    async def _fetch_insights(self, access_token: str) -> Optional[Dict[str, Any]]:
        """Fetch Instagram insights data."""
        try:
            # Calculate date range (last 30 days)
            since_timestamp = int((datetime.now(timezone.utc).timestamp()) - (30 * 24 * 60 * 60))
            until_timestamp = int(datetime.now(timezone.utc).timestamp())
            
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    f"{self.api_base_url}/me/insights",
                    params={
                        "metric": "reach,content_views",
                        "period": "day",
                        "since": since_timestamp,
                        "until": until_timestamp,
                        "access_token": access_token
                    }
                )
                
                if not response.is_success:
                    logger.error(f"Instagram insights API request failed: {response.status_code} - {response.text}")
                    raise InstagramReconnectionRequired("Instagram account needs to be reconnected")
                
                insights_data = response.json()
                
                # Calculate metrics from insights
                avg_short_views = 0
                total_reach = 0
                monthly_reach = 0
                
                if insights_data.get("data"):
                    reach_data = next((item for item in insights_data["data"] if item.get("name") == "reach"), None)
                    content_views_data = next((item for item in insights_data["data"] if item.get("name") == "content_views"), None)
                    
                    if content_views_data and content_views_data.get("values"):
                        total_content_views = sum(day.get("value", 0) for day in content_views_data["values"])
                        avg_short_views = int(total_content_views / len(content_views_data["values"]))
                    
                    if reach_data and reach_data.get("values"):
                        total_reach = sum(day.get("value", 0) for day in reach_data["values"])
                        monthly_reach = reach_data.get("total_value", 0)
                
                return {
                    "avg_short_views": avg_short_views,
                    "total_reach": total_reach,
                    "monthly_reach": monthly_reach,
                }
                
        except InstagramReconnectionRequired:
            raise
        except Exception as e:
            logger.error(f"Error fetching Instagram insights: {e}")
            raise InstagramReconnectionRequired("Instagram account needs to be reconnected")
    
    async def get_demographic_insights(self, instagram_user_id: str, access_token: str) -> Dict[str, Any]:
        """
        Fetch Instagram demographic insights.
        
        Args:
            instagram_user_id: Instagram user ID
            access_token: Instagram access token
            
        Returns:
            Dictionary with demographic data
        """
        try:
            logger.info(f"Fetching demographic insights for Instagram user: {instagram_user_id}")
            
            # Initialize result object
            final_result = {
                "countries": {},
                "ageGroups": {},
                "genders": {},
                "totalEngagedUsers": 0
            }
            
            # Fetch demographics in parallel
            async with httpx.AsyncClient() as client:
                tasks = [
                    self._fetch_age_demographics(client, instagram_user_id, access_token),
                    self._fetch_gender_demographics(client, instagram_user_id, access_token),
                    self._fetch_country_demographics(client, instagram_user_id, access_token)
                ]
                
                results = await asyncio.gather(*tasks, return_exceptions=True)
                
                # Process results
                for i, result in enumerate(results):
                    if isinstance(result, Exception):
                        raise result
                    
                    if result:
                        if i == 0:  # Age demographics
                            self._process_age_data(result, final_result)
                        elif i == 1:  # Gender demographics
                            self._process_gender_data(result, final_result)
                        elif i == 2:  # Country demographics
                            self._process_country_data(result, final_result)
            
            logger.info(f"Demographic insights completed for user: {instagram_user_id}")
            return final_result
            
        except InstagramReconnectionRequired:
            raise
        except Exception as e:
            logger.error(f"Error fetching demographic insights: {e}")
            raise InstagramReconnectionRequired("Instagram account needs to be reconnected")
    
    async def _fetch_age_demographics(self, client: httpx.AsyncClient, instagram_user_id: str, access_token: str) -> Optional[Dict]:
        """Fetch age demographics."""
        try:
            response = await client.get(
                f"{self.api_base_url}/{instagram_user_id}/insights",
                params={
                    "metric": "follower_demographics",
                    "period": "lifetime",
                    "timeframe": "this_month",
                    "breakdown": "age",
                    "metric_type": "total_value",
                    "access_token": access_token
                }
            )
            if not response.is_success:
                logger.error(f"Instagram age demographics API request failed: {response.status_code} - {response.text}")
                raise InstagramReconnectionRequired("Instagram account needs to be reconnected")
            return response.json()
        except InstagramReconnectionRequired:
            raise
        except Exception as e:
            logger.error(f"Error fetching age demographics: {e}")
            raise InstagramReconnectionRequired("Instagram account needs to be reconnected")
    
    async def _fetch_gender_demographics(self, client: httpx.AsyncClient, instagram_user_id: str, access_token: str) -> Optional[Dict]:
        """Fetch gender demographics."""
        try:
            response = await client.get(
                f"{self.api_base_url}/{instagram_user_id}/insights",
                params={
                    "metric": "follower_demographics",
                    "period": "lifetime",
                    "timeframe": "this_month",
                    "breakdown": "gender",
                    "metric_type": "total_value",
                    "access_token": access_token
                }
            )
            if not response.is_success:
                logger.error(f"Instagram gender demographics API request failed: {response.status_code} - {response.text}")
                raise InstagramReconnectionRequired("Instagram account needs to be reconnected")
            return response.json()
        except InstagramReconnectionRequired:
            raise
        except Exception as e:
            logger.error(f"Error fetching gender demographics: {e}")
            raise InstagramReconnectionRequired("Instagram account needs to be reconnected")
    
    async def _fetch_country_demographics(self, client: httpx.AsyncClient, instagram_user_id: str, access_token: str) -> Optional[Dict]:
        """Fetch country demographics."""
        try:
            response = await client.get(
                f"{self.api_base_url}/{instagram_user_id}/insights",
                params={
                    "metric": "follower_demographics",
                    "period": "lifetime",
                    "timeframe": "this_month",
                    "breakdown": "country",
                    "metric_type": "total_value",
                    "access_token": access_token
                }
            )
            if not response.is_success:
                logger.error(f"Instagram country demographics API request failed: {response.status_code} - {response.text}")
                raise InstagramReconnectionRequired("Instagram account needs to be reconnected")
            return response.json()
        except InstagramReconnectionRequired:
            raise
        except Exception as e:
            logger.error(f"Error fetching country demographics: {e}")
            raise InstagramReconnectionRequired("Instagram account needs to be reconnected")
    
    def _process_age_data(self, age_data: Dict, final_result: Dict) -> None:
        """Process age demographic data."""
        try:
            demographic_info = age_data.get("data", [{}])[0]
            if demographic_info.get("total_value", {}).get("breakdowns"):
                for breakdown in demographic_info["total_value"]["breakdowns"]:
                    if "age" in breakdown.get("dimension_keys", []) and breakdown.get("results"):
                        for result in breakdown["results"]:
                            if result.get("dimension_values") and result.get("value", 0) > 0:
                                age_index = breakdown["dimension_keys"].index("age")
                                if age_index < len(result["dimension_values"]):
                                    age_group = result["dimension_values"][age_index]
                                    value = result["value"]
                                    final_result["ageGroups"][age_group] = final_result["ageGroups"].get(age_group, 0) + value
                                    final_result["totalEngagedUsers"] += value
        except Exception as e:
            logger.error(f"Error processing age data: {e}")
    
    def _process_gender_data(self, gender_data: Dict, final_result: Dict) -> None:
        """Process gender demographic data."""
        try:
            demographic_info = gender_data.get("data", [{}])[0]
            if demographic_info.get("total_value", {}).get("breakdowns"):
                for breakdown in demographic_info["total_value"]["breakdowns"]:
                    if "gender" in breakdown.get("dimension_keys", []) and breakdown.get("results"):
                        for result in breakdown["results"]:
                            if result.get("dimension_values") and result.get("value", 0) > 0:
                                gender_index = breakdown["dimension_keys"].index("gender")
                                if gender_index < len(result["dimension_values"]):
                                    gender = result["dimension_values"][gender_index]
                                    value = result["value"]
                                    formatted_gender = gender.capitalize()
                                    final_result["genders"][formatted_gender] = final_result["genders"].get(formatted_gender, 0) + value
                                    final_result["totalEngagedUsers"] += value
        except Exception as e:
            logger.error(f"Error processing gender data: {e}")
    
    def _process_country_data(self, country_data: Dict, final_result: Dict) -> None:
        """Process country demographic data."""
        try:
            country_names = {
                'US': 'United States', 'ES': 'Spain', 'AR': 'Argentina', 'RU': 'Russia',
                'MA': 'Morocco', 'LA': 'Laos', 'IQ': 'Iraq', 'MX': 'Mexico',
                'FR': 'France', 'NL': 'Netherlands', 'TR': 'Turkey', 'GB': 'United Kingdom',
                'CA': 'Canada', 'AU': 'Australia', 'DE': 'Germany', 'IT': 'Italy',
                'BR': 'Brazil', 'IN': 'India', 'JP': 'Japan', 'CN': 'China'
            }
            
            demographic_info = country_data.get("data", [{}])[0]
            if demographic_info.get("total_value", {}).get("breakdowns"):
                for breakdown in demographic_info["total_value"]["breakdowns"]:
                    if "country" in breakdown.get("dimension_keys", []) and breakdown.get("results"):
                        for result in breakdown["results"]:
                            if result.get("dimension_values") and result.get("value", 0) > 0:
                                country_index = breakdown["dimension_keys"].index("country")
                                if country_index < len(result["dimension_values"]):
                                    country_code = result["dimension_values"][country_index]
                                    value = result["value"]
                                    country_name = country_names.get(country_code, country_code)
                                    final_result["countries"][country_name] = final_result["countries"].get(country_name, 0) + value
                                    final_result["totalEngagedUsers"] += value
        except Exception as e:
            logger.error(f"Error processing country data: {e}")
    
    async def get_instagram_analytics(
        self,
        instagram_user_id: str,
        access_token: str
    ) -> Optional[InstagramAnalytics]:
        """
        Fetch complete Instagram analytics.
        
        Args:
            instagram_user_id: Instagram user ID
            access_token: Instagram access token
            
        Returns:
            InstagramAnalytics object with complete data
        """
        try:
            logger.info(f"Fetching Instagram analytics for user: {instagram_user_id}")
            
            # Fetch account data and demographics in parallel
            account_data, demographics = await asyncio.gather(
                self.get_account_data(access_token),
                self.get_demographic_insights(instagram_user_id, access_token)
            )
            
            # Create InstagramAnalytics object
            analytics_data = {
                'accountId': instagram_user_id,
                'lastUpdated': datetime.utcnow(),
                'followers': account_data.get('followers_count', 0),
                'totalReach': account_data.get('total_reach', 0),
                'shortViews': account_data.get('avg_short_views', 0),
                'totalEngagedUsers': demographics.get('totalEngagedUsers', 0),
                'totalPosts': account_data.get('media_count', 0),
                'recentReach': account_data.get('total_reach', 0),
                'recentReelsViews': account_data.get('avg_short_views', 0),
                'demographicsByAge': demographics.get('ageGroups', {}),
                'demographicsByGender': demographics.get('genders', {}),
                'demographicsByCountry': demographics.get('countries', {}),
            }
            
            return InstagramAnalytics(**analytics_data)
            
        except InstagramReconnectionRequired:
            raise
        except Exception as e:
            logger.error(f"Error fetching Instagram analytics: {e}")
            raise InstagramReconnectionRequired("Instagram account needs to be reconnected")


# Global Instagram Analytics service instance
instagram_analytics_service = InstagramAnalyticsService()
