"""
AWS SES Email Service
Handles email sending functionality using Amazon Simple Email Service (SES).
"""

import os
import boto3
from botocore.exceptions import ClientError, BotoCoreError
from typing import List, Optional, Dict, Any
from datetime import datetime, timezone
import logging

# Import database models
from database.models.message import Message, MessageType, MessageStatus, EmailMessage, Conversation
from database.models.deal import Deal
from beanie.odm.fields import PydanticObjectId

logger = logging.getLogger('uvicorn.error')


class EmailService:
    """Service for sending emails via AWS SES."""
    
    def __init__(self):
        """Initialize the SES client with AWS credentials from environment."""
        self.aws_region = os.getenv('AWS_REGION', 'us-east-2')
        self.ses_client = None
        self._initialize_ses_client()
    
    def _initialize_ses_client(self):
        """Initialize the AWS SES client."""
        try:
            self.ses_client = boto3.client(
                'ses',
                region_name=self.aws_region,
                aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'),
                aws_secret_access_key=os.getenv('AWS_SECRET_ACCESS_KEY')
            )
            logger.info(f"SES client initialized for region: {self.aws_region}")
        except Exception as e:
            logger.error(f"Failed to initialize SES client: {e}")
            raise
    
    async def _find_conversation_by_deal_id(self, deal_id: str) -> Optional[str]:
        """
        Find the conversation ID associated with a deal ID.
        
        Args:
            deal_id: The deal ID to search for
            
        Returns:
            Conversation ID if found, None otherwise
        """
        try:
            conversation = await Conversation.find_one(Conversation.dealId == deal_id)
            if conversation:
                logger.debug(f"Found conversation {conversation.uuid} for deal {deal_id}")
                return conversation.uuid
            else:
                logger.warning(f"No conversation found for deal {deal_id}")
                return None
        except Exception as e:
            logger.error(f"Error finding conversation for deal {deal_id}: {e}")
            return None
    
    async def _create_message_in_conversation(
        self,
        conversation_id: str,
        deal_id: str,
        user_id: str,
        sender_name: str,
        sender_email: str,
        subject: str,
        content: str,
        message_id: str,
        to_addresses: List[str],
        cc_addresses: Optional[List[str]] = None,
        bcc_addresses: Optional[List[str]] = None,
        reply_to_addresses: Optional[List[str]] = None
    ) -> Optional[Message]:
        """
        Create a message record in the conversation after successful email send.
        
        Args:
            conversation_id: ID of the conversation to add the message to
            deal_id: ID of the deal this message belongs to
            user_id: ID of the user who sent the email
            sender_name: Name of the sender
            sender_email: Email of the sender
            subject: Email subject
            content: Email content (text or HTML)
            message_id: AWS SES message ID
            to_addresses: List of recipient addresses
            cc_addresses: List of CC addresses
            bcc_addresses: List of BCC addresses
            reply_to_addresses: List of reply-to addresses
            
        Returns:
            Created Message object or None if creation failed
        """
        try:
            # Create email-specific data
            email_data = EmailMessage(
                subject=subject,
                toEmails=to_addresses,
                ccEmails=cc_addresses or [],
                bccEmails=bcc_addresses or [],
                replyTo=reply_to_addresses[0] if reply_to_addresses else None,
                emailId=message_id,
                attachments=[],
                headers={},
                isImportant=False
            )
            
            # Create the message
            message = Message(
                messageType=MessageType.EMAIL,
                content=content,
                status=MessageStatus.SENT,
                conversationId=conversation_id,
                dealId=deal_id,
                userId=user_id,
                senderName=sender_name,
                senderEmail=sender_email,
                senderId=user_id,
                senderAvatar=None,
                inReplyTo=None,
                threadPosition=0,
                isInternal=False,
                isAutomated=False,
                priority=0,
                tags=[],
                emailData=email_data,
                aiData=None,
                sentAt=datetime.now(timezone.utc),
                receivedAt=None,
                readAt=None,
                createdAt=datetime.now(timezone.utc),
                updatedAt=datetime.now(timezone.utc),
                metadata={},
                externalId=message_id
            )
            
            # Save the message
            await message.insert()
            
            logger.info(f"✅ Created message {message.uuid} in conversation {conversation_id}")
            return message
            
        except Exception as e:
            logger.error(f"Failed to create message in conversation {conversation_id}: {e}")
            return None
    
    async def send_email(
        self,
        to_addresses: List[str],
        subject: str,
        body_text: Optional[str] = None,
        body_html: Optional[str] = None,
        from_address: Optional[str] = None,
        cc_addresses: Optional[List[str]] = None,
        bcc_addresses: Optional[List[str]] = None,
        reply_to_addresses: Optional[List[str]] = None,
        configuration_set_name: Optional[str] = None,
        # Conversation-related parameters
        deal_id: Optional[str] = None,
        user_id: Optional[str] = None,
        sender_name: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Send an email via AWS SES and optionally create a message in a conversation.
        
        Args:
            to_addresses: List of recipient email addresses
            subject: Email subject line
            body_text: Plain text email body (optional if body_html provided)
            body_html: HTML email body (optional if body_text provided)
            from_address: Sender email address (uses default if not provided)
            cc_addresses: List of CC email addresses
            bcc_addresses: List of BCC email addresses
            reply_to_addresses: List of reply-to email addresses
            configuration_set_name: SES configuration set name
            deal_id: ID of deal this email belongs to (required for conversation message creation)
            user_id: ID of user sending the email (required for conversation message creation)
            sender_name: Name of the sender (optional)
        
        Returns:
            Dictionary containing message ID, conversation message info, and other response data
            
        Raises:
            ValueError: If neither body_text nor body_html is provided
            ClientError: If AWS SES API call fails
        """
        if not body_text and not body_html:
            raise ValueError("Either body_text or body_html must be provided")
        
        if not from_address:
            from_address = os.getenv('SES_FROM_EMAIL', 'noreply@example.com')
        
        try:
            # Build the destination
            destination = {'ToAddresses': to_addresses}
            if cc_addresses:
                destination['CcAddresses'] = cc_addresses
            if bcc_addresses:
                destination['BccAddresses'] = bcc_addresses
            
            # Build the message body
            body = {}
            if body_text:
                body['Text'] = {'Data': body_text, 'Charset': 'UTF-8'}
            if body_html:
                body['Html'] = {'Data': body_html, 'Charset': 'UTF-8'}
            
            # Build the message
            message = {
                'Subject': {'Data': subject, 'Charset': 'UTF-8'},
                'Body': body
            }
            
            # Prepare the send_email parameters
            send_params = {
                'Source': from_address,
                'Destination': destination,
                'Message': message
            }
            
            # Add optional parameters
            if reply_to_addresses:
                send_params['ReplyToAddresses'] = reply_to_addresses
            if configuration_set_name:
                send_params['ConfigurationSetName'] = configuration_set_name
            
            # Send the email
            logger.info(f"Sending email to {len(to_addresses)} recipients: {', '.join(to_addresses[:3])}{'...' if len(to_addresses) > 3 else ''}")
            
            response = self.ses_client.send_email(**send_params)
            
            message_id = response['MessageId']
            logger.info(f"Email sent successfully. Message ID: {message_id}")
            
            # Create message in conversation if deal_id is provided
            conversation_message = None
            conversation_id = None
            
            logger.info(f"Deal ID: {deal_id}, User ID: {user_id}, Sender Name: {sender_name}, From Address: {from_address}")
            if deal_id and user_id:
                try:
                    # Find conversation ID if not provided
                    conversation_id = await self._find_conversation_by_deal_id(deal_id)
                    
                    if conversation_id:
                        # Use provided sender name or default to from_address
                        sender_name_to_use = sender_name or from_address
                        
                        # Use body_text as content, fallback to body_html if no text
                        content = body_text or body_html or ""
                        
                        conversation_message = await self._create_message_in_conversation(
                            conversation_id=conversation_id,
                            deal_id=deal_id,
                            user_id=user_id,
                            sender_name=sender_name_to_use,
                            sender_email=from_address,
                            subject=subject,
                            content=content,
                            message_id=message_id,
                            to_addresses=to_addresses,
                            cc_addresses=cc_addresses,
                            bcc_addresses=bcc_addresses,
                            reply_to_addresses=reply_to_addresses
                        )
                    else:
                        logger.warning(f"No conversation found for deal {deal_id}, skipping message creation")
                except Exception as e:
                    logger.warning(f"Failed to create conversation message: {e}")
            
            result = {
                'success': True,
                'message_id': message_id,
                'response_metadata': response.get('ResponseMetadata', {}),
                'to_addresses': to_addresses,
                'subject': subject
            }
            
            # Add conversation message info if created
            if conversation_message:
                result['conversation_message_id'] = conversation_message.uuid
                result['conversation_id'] = conversation_id
                logger.info(f"✅ Email sent and message added to conversation {conversation_id}")
            elif deal_id:
                logger.warning(f"Email sent but failed to add message to conversation for deal {deal_id}")
            
            return result
            
        except ClientError as e:
            error_code = e.response['Error']['Code']
            error_message = e.response['Error']['Message']
            logger.error(f"SES ClientError ({error_code}): {error_message}")
            
            # Handle specific SES errors
            if error_code == 'MessageRejected':
                raise ValueError(f"Email rejected by SES: {error_message}")
            elif error_code == 'MailFromDomainNotVerified':
                raise ValueError(f"Sender domain not verified in SES: {error_message}")
            elif error_code == 'ConfigurationSetDoesNotExist':
                raise ValueError(f"Configuration set does not exist: {error_message}")
            else:
                raise Exception(f"SES error ({error_code}): {error_message}")
                
        except BotoCoreError as e:
            logger.error(f"BotoCore error: {e}")
            raise Exception(f"AWS service error: {e}")
        except Exception as e:
            logger.error(f"Unexpected error sending email: {e}")
            raise
    
    async def send_bulk_email(
        self,
        emails: List[Dict[str, Any]],
        default_from_address: Optional[str] = None,
        # Default conversation parameters for all emails in bulk
        default_conversation_id: Optional[str] = None,
        default_deal_id: Optional[str] = None,
        default_user_id: Optional[str] = None,
        default_sender_name: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Send multiple emails in bulk.
        
        Args:
            emails: List of email dictionaries, each containing email parameters
            default_from_address: Default sender address if not specified in individual emails
            default_conversation_id: Default conversation ID for all emails
            default_deal_id: Default deal ID for all emails
            default_user_id: Default user ID for all emails
            default_sender_name: Default sender name for all emails
        
        Returns:
            List of results for each email sent
        """
        results = []
        
        for i, email_data in enumerate(emails):
            try:
                # Use default from address if not specified
                if 'from_address' not in email_data and default_from_address:
                    email_data['from_address'] = default_from_address
                
                # Use default conversation parameters if not specified in individual email
                if 'conversation_id' not in email_data and default_conversation_id:
                    email_data['conversation_id'] = default_conversation_id
                if 'deal_id' not in email_data and default_deal_id:
                    email_data['deal_id'] = default_deal_id
                if 'user_id' not in email_data and default_user_id:
                    email_data['user_id'] = default_user_id
                if 'sender_name' not in email_data and default_sender_name:
                    email_data['sender_name'] = default_sender_name
                
                # Note: conversation_id will be automatically found by deal_id in send_email method
                
                result = await self.send_email(**email_data)
                results.append(result)
                
            except Exception as e:
                logger.error(f"Failed to send bulk email {i + 1}: {e}")
                results.append({
                    'success': False,
                    'error': str(e),
                    'email_index': i,
                    'to_addresses': email_data.get('to_addresses', [])
                })
        
        return results
    
    def get_send_quota(self) -> Dict[str, Any]:
        """
        Get the current SES sending quota and rate limits.
        
        Returns:
            Dictionary containing quota information
        """
        try:
            response = self.ses_client.get_send_quota()
            return {
                'max_24_hour_send': response['Max24HourSend'],
                'max_send_rate': response['MaxSendRate'],
                'sent_last_24_hours': response['SentLast24Hours']
            }
        except ClientError as e:
            logger.error(f"Error getting SES quota: {e}")
            raise
    
    def verify_email_identity(self, email_address: str) -> bool:
        """
        Verify an email address with SES.
        
        Args:
            email_address: Email address to verify
            
        Returns:
            True if verification request was sent successfully
        """
        try:
            self.ses_client.verify_email_identity(EmailAddress=email_address)
            logger.info(f"Verification email sent to: {email_address}")
            return True
        except ClientError as e:
            logger.error(f"Error verifying email identity: {e}")
            return False
    
    def list_verified_email_addresses(self) -> List[str]:
        """
        Get list of verified email addresses in SES.
        
        Returns:
            List of verified email addresses
        """
        try:
            response = self.ses_client.list_verified_email_addresses()
            return response['VerifiedEmailAddresses']
        except ClientError as e:
            logger.error(f"Error listing verified email addresses: {e}")
            return []


# Global email service instance
email_service = EmailService()
