#!/usr/bin/env python3
"""
Test script to verify MongoDB connection and deals collection setup.
Run this script to test if the database connection is working properly.
"""

import asyncio
import os
from database.database import init_database, close_database
from database.models.deal import Deal, ContactType


async def test_database_connection():
    """Test the database connection and basic CRUD operations."""
    try:
        print("🔌 Connecting to MongoDB...")
        await init_database()
        print("✅ Successfully connected to MongoDB!")
        
        # Test creating a sample deal
        print("\n📝 Creating a sample deal...")
        sample_deal = Deal(
            brand_name="Test Brand",
            brand_website="https://testbrand.com",
            brand_category="Technology",
            contact_name="John Doe",
            contact_email="john@testbrand.com",
            contact_type=ContactType.BRAND_DIRECT,
            deliverables=["Website Design", "Brand Identity"],
            budget="$10,000 - $15,000",
            deadline="2024-03-31",
            brand_comment="Looking for a modern, clean design"
        )
        
        # Insert the deal
        inserted_deal = await sample_deal.insert()
        print(f"✅ Sample deal created with ID: {inserted_deal.id}")
        
        # Test retrieving the deal
        print("\n🔍 Retrieving the created deal...")
        retrieved_deal = await Deal.find_one(Deal.id == inserted_deal.id)
        if retrieved_deal:
            print(f"✅ Deal retrieved successfully: {retrieved_deal.brand_name}")
        else:
            print("❌ Failed to retrieve the deal")
        
        # Test listing all deals
        print("\n📋 Listing all deals...")
        all_deals = await Deal.find_all().to_list()
        print(f"✅ Found {len(all_deals)} deals in the collection")
        
        # Test updating the deal
        print("\n✏️ Updating the deal...")
        retrieved_deal.brand_comment = "Updated comment for testing"
        updated_deal = await retrieved_deal.replace()
        print(f"✅ Deal updated successfully: {updated_deal.brand_comment}")
        
        # Test deleting the deal
        print("\n🗑️ Deleting the test deal...")
        delete_result = await retrieved_deal.delete()
        if delete_result:
            print("✅ Test deal deleted successfully")
        else:
            print("❌ Failed to delete the test deal")
        
        # Verify deletion
        remaining_deals = await Deal.find_all().to_list()
        print(f"✅ Remaining deals in collection: {len(remaining_deals)}")
        
    except Exception as e:
        print(f"❌ Error during database test: {str(e)}")
        raise
    finally:
        print("\n🔌 Closing database connection...")
        await close_database()
        print("✅ Database connection closed")


async def test_collection_info():
    """Test getting collection information."""
    try:
        await init_database()
        
        # Get collection statistics
        collection = Deal.get_motor_collection()
        stats = await collection.aggregate([
            {"$group": {
                "_id": None,
                "total_documents": {"$sum": 1},
                "avg_budget_length": {"$avg": {"$strLenCP": "$budget"}}
            }}
        ]).to_list(length=1)
        
        if stats:
            print(f"📊 Collection Statistics:")
            print(f"   Total documents: {stats[0].get('total_documents', 0)}")
            print(f"   Average budget field length: {stats[0].get('avg_budget_length', 0):.2f}")
        
        await close_database()
        
    except Exception as e:
        print(f"❌ Error getting collection info: {str(e)}")


if __name__ == "__main__":
    print("🧪 Testing MongoDB Connection and Deals Collection")
    print("=" * 50)
    
    # Set default environment variables if not set
    if not os.getenv("MONGODB_URL"):
        os.environ["MONGODB_URL"] = "mongodb://localhost:27017"
    if not os.getenv("MONGODB_DATABASE"):
        os.environ["MONGODB_DATABASE"] = "repflow"
    
    print(f"🔧 Using MongoDB URL: {os.getenv('MONGODB_URL')}")
    print(f"🔧 Using Database: {os.getenv('MONGODB_DATABASE')}")
    print()
    
    # Run the tests
    asyncio.run(test_database_connection())
    print("\n" + "=" * 50)
    asyncio.run(test_collection_info())
    
    print("\n🎉 All tests completed!")
