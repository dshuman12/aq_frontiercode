import sys
import os

# Add current directory to sys.path to simulate lambda environment root
sys.path.append(os.getcwd())

print(f"Testing imports with sys.path: {sys.path}")

modules_to_test = [
    "ai_agents.parsing_agent",
    "ai_agents.evaluation_agent",
    "fsm.context",
    "fsm.states.needs_classification",
    "fsm.states.needs_negotiation",
    "fsm.states.needs_info",
    "fsm.states.ready_for_deal",
    "fsm.states.deal_created",
    "business.deal_creation",
    "business.qualification",
    "api_client",
    # "lambda_function" # Might have side effects or require env vars
]

for module in modules_to_test:
    try:
        __import__(module)
        print(f"SUCCESS: Imported {module}")
    except Exception as e:
        print(f"ERROR: Failed to import {module}: {e}")
