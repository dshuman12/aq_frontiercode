#!/usr/bin/env python3
"""
AWS Lambda entrypoint for email automation using the unified FSM.
"""

import json
import os
import boto3
import email
import re
import traceback
from typing import Dict, List, Optional, Any
from database.database import init_database
from datetime import datetime, timezone
from dataclasses import dataclass
from email_reply_parser import EmailReplyParser
from fsm import FSMContext, FSMEvent, FSMState, StateMachine
from database.models.lead import (
    LeadQualificationData,
    EmailProcessingState,
    StateTransitionRecord,
    TransitionTrigger,
)
from api_client import (
    APIClient,
    create_api_client,
    convert_lead_to_api_format,
    convert_message_to_api_format,
    UserDTO,  # Use lightweight User DTO instead of Beanie Document
)

# Alias for type consistency
User = UserDTO

# Environment variables
S3_BUCKET = os.environ.get("S3_BUCKET", "")
SES_REGION = os.environ.get("SES_REGION", "us-east-2")
DISABLE_SES_SEND = os.environ.get("DEMO_EMAIL_AGENT_DISABLE_SEND", "true").lower() in (
    "1",
    "true",
    "yes",
)

# AWS clients
s3_client = boto3.client("s3")
ses_client = boto3.client("ses", region_name=SES_REGION)

# Keywords that suggest the prospect wants to book or schedule a call (AI agent should include creator's booking link)
BOOKING_INTENT_KEYWORDS = re.compile(
    r"\b(book|schedule|scheduling|calendly|calendar|call|meeting|chat|discuss|talk|zoom|meet)\b",
    re.IGNORECASE,
)


def _inbound_suggests_booking(content: str, subject: str = "") -> bool:
    """True if the prospect's message suggests they want to book/schedule a call."""
    combined = f"{subject} {content}"
    return bool(BOOKING_INTENT_KEYWORDS.search(combined))


@dataclass
class EmailEvent:
    """Parsed email event from SES."""

    message_id: str
    thread_id: str
    sender_email: str
    recipient_email: str
    subject: str
    content: str
    timestamp: datetime
    s3_bucket: str
    s3_key: str


# Database Operations via API
async def get_lead_by_thread_id(api_client, thread_id: str) -> Optional[Dict]:
    try:
        return await api_client.get_lead_by_thread_id(thread_id)
    except Exception as e:
        print(f"Error fetching lead by thread_id {thread_id}: {e}")
        return None


async def create_lead(
    api_client: APIClient, email_addr: str, thread_id: str, user_id: str
) -> Optional[Dict]:
    try:
        now = datetime.now(timezone.utc)
        lead_data = {
            "email": email_addr,
            "thread_id": thread_id,
            "userId": user_id,
            "status": "new",
            "processing_state": EmailProcessingState.NEEDS_CLASSIFICATION.value,
            "state_metadata": {},
            "created_at": now,
            "updated_at": now,
        }
        lead_data = convert_lead_to_api_format(lead_data)
        return await api_client.create_lead(lead_data)
    except Exception as e:
        print(f"Error creating lead: {e}")
        return None


async def update_lead(
    api_client: APIClient,
    lead_id: str,
    thread_id: str,
    lead_data: LeadQualificationData,
) -> Optional[Dict]:
    try:
        lead_data.thread_id = thread_id
        # Use model_dump() without mode="json" and let convert_lead_to_api_format handle serialization
        lead_dict = lead_data.model_dump()
        # Manually convert PydanticObjectId to string if present
        if "id" in lead_dict and lead_dict["id"] is not None:
            lead_dict["id"] = str(lead_dict["id"])
        update_data = convert_lead_to_api_format(lead_dict)
        return await api_client.update_lead(lead_id, update_data)
    except Exception as e:
        print(f"Error updating lead: {e}")
        return None


async def was_email_processed(api_client, message_id: str) -> bool:
    try:
        return await api_client.check_email_processed(message_id)
    except Exception as e:
        print(f"Error checking processed email: {e}")
        return False


async def mark_email_processed(api_client, message_id: str, thread_id: str) -> bool:
    try:
        result = await api_client.mark_email_processed(message_id, thread_id)
        return result is not None
    except Exception as e:
        print(f"Error marking email processed: {e}")
        return False


async def is_blacklisted(api_client, email_addr: str) -> bool:
    try:
        return await api_client.check_email_blacklisted(email_addr.lower())
    except Exception as e:
        print(f"Error checking blacklist: {e}")
        return False


async def store_message(
    api_client: APIClient,
    message_data: Dict,
    user_id: str,
    conversation: Optional[Dict] = None,
) -> bool:
    """Store a message in a conversation.

    If conversation is provided, uses it. Otherwise, creates/gets a pre-deal conversation.
    """
    try:
        thread_id = message_data.get("thread_id")
        sender_email = message_data.get("sender_email")
        recipient_email = message_data.get("recipient_email")
        subject = message_data.get("subject", "")
        content = message_data.get("content", "")
        direction = message_data.get("direction", "inbound")
        timestamp = message_data.get("timestamp")

        # Get or create conversation
        if conversation is None:
            conversation = await api_client.get_conversation_by_thread_id(thread_id)

        if conversation is None:
            # Create pre-deal conversation
            contact_email = sender_email if direction == "inbound" else recipient_email
            contact_name = contact_email.split("@")[
                0
            ]  # Use email prefix as name initially

            conversation = await api_client.create_pre_deal_conversation(
                thread_id=thread_id,
                user_id=user_id,
                contact_email=contact_email,
                contact_name=contact_name,
                subject=subject,
            )

            if not conversation:
                print(f"Failed to create pre-deal conversation for thread {thread_id}")
                return False

        # Create message in the conversation
        message_payload = {
            "messageType": "email",
            "content": content,
            "status": "received" if direction == "inbound" else "sent",
            "conversationId": conversation.get("uuid"),
            "dealId": conversation.get("dealId"),  # Will be None for pre-deal
            "userId": user_id,
            "senderName": (
                sender_email.split("@")[0]
                if direction == "inbound"
                else recipient_email.split("@")[0]
            ),
            "senderEmail": sender_email if direction == "inbound" else recipient_email,
            "senderId": sender_email if direction == "inbound" else recipient_email,
            "threadPosition": 0,
            "isInternal": False,
            "isAutomated": False,
            "priority": 0,
            "tags": [],
            "emailData": {
                "subject": subject,
                "toEmails": (
                    [recipient_email] if direction == "inbound" else [sender_email]
                ),
                "emailId": message_data.get("message_id"),
            },
            "sentAt": (
                timestamp.isoformat() if isinstance(timestamp, datetime) else timestamp
            ),
            "receivedAt": (
                datetime.now(timezone.utc).isoformat()
                if direction == "inbound"
                else None
            ),
        }

        result = await api_client.create_message_for_conversation(message_payload)
        return bool(result)
    except Exception as e:
        print(f"Error storing message: {e}")
        return False


async def get_conversation_history(
    api_client, thread_id: str, limit: int = 50
) -> List[Dict]:
    try:
        messages = await api_client.get_conversation_history(thread_id, limit)
        return messages or []
    except Exception as e:
        print(f"Error fetching conversation history: {e}")
        return []


def format_conversation_history(messages: List[Dict]) -> str:
    """Format conversation history for AI context.

    Handles Message model fields from the Conversations/Messages system.
    """
    if not messages:
        return ""

    formatted_history = "CONVERSATION HISTORY:\n"
    for i, message in enumerate(messages, 1):
        is_current = i == len(messages)
        marker = "[CURRENT MESSAGE]" if is_current else f"[MESSAGE {i}]"

        # Extract fields from Message model
        sender_email = message.get("senderEmail", "")
        email_data = message.get("emailData", {}) or {}
        to_emails = email_data.get("toEmails", [])
        recipient_email = to_emails[0] if to_emails else ""
        subject = email_data.get("subject", "")
        sent_at = message.get("sentAt", "")

        # Determine direction from status (sent=outbound, received=inbound)
        status = message.get("status", "")
        direction = "OUTBOUND" if status == "sent" else "INBOUND"

        formatted_history += f"""
--- {marker} ---
From: {sender_email}
To: {recipient_email}
Subject: {subject}
Date: {sent_at}
Direction: {direction}

{message.get("content", "")}
"""
    return formatted_history


def extract_email_address(from_header: str) -> str:
    email_match = re.search(r"<([^>]+)>|([^\s<>]+@[^\s<>]+)", from_header)
    if email_match:
        return email_match.group(1) or email_match.group(2)
    return from_header.strip()


def _normalize_inbound_domain(domain: str) -> str:
    """Lowercase host part; allow accidental @prefix in env."""
    d = (domain or "").strip().lower().lstrip("@")
    return d


def resolve_inbound_recipient_email(mail: dict, inbound_domain: str) -> str:
    """Resolve creator inbox from SES mail for multi-recipient messages.

    Prefer mail.destination, then commonHeaders.to for inbound_domain,
    else first To. See SES inbound notification destination field.
    """
    domain = _normalize_inbound_domain(inbound_domain) or "repflow.me"

    def _matching_addresses(raw_list: Optional[List[str]]) -> List[str]:
        matched: List[str] = []
        seen: set[str] = set()
        for raw in raw_list or []:
            if not raw:
                continue
            norm = extract_email_address(raw).lower().strip()
            if not norm or norm in seen:
                continue
            seen.add(norm)
            if norm.endswith("@" + domain):
                matched.append(norm)
        return matched

    dest_matches = _matching_addresses(mail.get("destination"))
    if len(dest_matches) == 1:
        return dest_matches[0]
    if len(dest_matches) > 1:
        chosen = sorted(dest_matches)[0]
        print(
            f"[SES] Multiple @{domain} recipients in destination; "
            f"using {chosen}"
        )
        return chosen

    header_to = mail.get("commonHeaders", {}).get("to") or []
    to_matches = _matching_addresses(header_to)
    if len(to_matches) == 1:
        return to_matches[0]
    if len(to_matches) > 1:
        chosen = sorted(to_matches)[0]
        print(
            f"[SES] Multiple @{domain} recipients in To header; "
            f"using {chosen}"
        )
        return chosen

    if header_to:
        return extract_email_address(header_to[0])
    return ""


def normalize_subject_for_thread(subject: str) -> str:
    if not subject:
        return ""
    normalized = re.sub(r"^(re:|fwd:|fw:)\s*", "", subject, flags=re.IGNORECASE).strip()
    return " ".join(normalized.split())


def _normalize_subject_for_thread(subject: str) -> str:
    """Normalize subject so 'Re: Partnership with Brand A' matches 'Partnership with Brand A'."""
    if not subject or not isinstance(subject, str):
        return ""
    s = subject.strip()
    # Strip leading Re:/Fwd:/Fw: and similar (allow optional whitespace after colon)
    prefix = re.compile(r"^(re|fwd?|fw)\s*:\s*", re.IGNORECASE)
    while True:
        m = prefix.match(s)
        if not m:
            break
        s = s[m.end() :].strip()
    return s.lower()


def generate_thread_id(sender_email: str, recipient_email: str, subject: str) -> str:
    """One thread per (sender, recipient, subject) so one sender can have multiple deals (e.g. agency/brands)."""
    import hashlib

    sender_clean = sender_email.lower().strip()
    recipient_clean = recipient_email.lower().strip()
    subject_normalized = _normalize_subject_for_thread(subject or "")
    emails_sorted = sorted([sender_clean, recipient_clean])
    thread_string = "|".join(emails_sorted) + "|" + subject_normalized
    thread_hash = hashlib.sha256(thread_string.encode("utf-8")).hexdigest()[:16]
    return thread_hash


def parse_ses_event(event: Dict[str, Any]) -> EmailEvent:
    ses_record = event["Records"][0]["ses"]
    mail = ses_record["mail"]
    message_id = mail["messageId"]
    timestamp = datetime.fromisoformat(mail["timestamp"].replace("Z", "+00:00"))
    sender_email = extract_email_address(mail["commonHeaders"]["from"][0])
    inbound_domain = os.environ.get("INBOUND_EMAIL_DOMAIN", "repflow.me")
    recipient_email = resolve_inbound_recipient_email(mail, inbound_domain)
    if not recipient_email:
        to_header = mail.get("commonHeaders", {}).get("to") or []
        recipient_email = (
            extract_email_address(to_header[0]) if to_header else ""
        )
    subject = mail.get("commonHeaders", {}).get("subject", "")
    thread_id = generate_thread_id(sender_email, recipient_email, subject)
    s3_bucket = S3_BUCKET
    s3_key = "emails/" + message_id
    return EmailEvent(
        message_id=message_id,
        thread_id=thread_id,
        sender_email=sender_email,
        recipient_email=recipient_email,
        subject=subject,
        content="",
        timestamp=timestamp,
        s3_bucket=s3_bucket,
        s3_key=s3_key,
    )


def fetch_email_from_s3(bucket: str, key: str) -> str:
    try:
        response = s3_client.get_object(Bucket=bucket, Key=key)
        email_content = response["Body"].read().decode("utf-8")
        msg = email.message_from_string(email_content)
        text_content = ""
        if msg.is_multipart():
            for part in msg.walk():
                if part.get_content_type() == "text/plain":
                    payload = part.get_payload(decode=True)
                    if isinstance(payload, bytes):
                        text_content += payload.decode("utf-8")
                    elif isinstance(payload, str):
                        text_content += payload
        else:
            if msg.get_content_type() == "text/plain":
                payload = msg.get_payload(decode=True)
                if isinstance(payload, bytes):
                    text_content = payload.decode("utf-8")
                elif isinstance(payload, str):
                    text_content = payload
        if not text_content.strip():
            if msg.is_multipart():
                for part in msg.walk():
                    if part.get_content_type().startswith("text/"):
                        payload = part.get_payload(decode=True)
                        if isinstance(payload, bytes):
                            text_content += payload.decode("utf-8", errors="ignore")
                        elif isinstance(payload, str):
                            text_content += payload
            else:
                payload = msg.get_payload(decode=True)
                if isinstance(payload, bytes):
                    text_content = payload.decode("utf-8", errors="ignore")
                elif isinstance(payload, str):
                    text_content = payload
        return text_content.strip()
    except Exception as e:
        print(f"Error fetching email from S3: {e}")
        return ""


def send_ses_reply(
    to_email: str,
    from_email: str,
    subject: str,
    body: str,
    user: User,
    in_reply_to_id: Optional[str] = None,
) -> bool:
    try:
        if DISABLE_SES_SEND:
            print("SES send disabled for demo; skipping actual send.")
            return True

        # Signature is already added in process_email_event before calling send_ses_reply
        # This function just sends the already-signed body
        body_with_signature = body
        message = {
            "Subject": {"Data": subject, "Charset": "UTF-8"},
            "Body": {"Text": {"Data": body_with_signature, "Charset": "UTF-8"}},
        }
        response = ses_client.send_email(
            Source=from_email, Destination={"ToAddresses": [to_email]}, Message=message
        )
        print(f"Email sent successfully. Message ID: {response['MessageId']}")
        return True
    except Exception as e:
        print(f"Error sending SES reply: {e}")
        return False


async def route_email_to_creator(
    api_client: APIClient,
    lead: LeadQualificationData,
    user: User,
    email_event: EmailEvent,
    email_content: str,
    fsm_context: Optional[FSMContext] = None,
) -> None:
    """Route to creator: ensure a deal exists so the creator has something to act on.

    The incoming message is already stored by store_message() before the FSM runs.
    When the lead has no deal_id (e.g. we're "passing along" after a rejection or
    fail-safe), we create a deal so the creator sees it in their pipeline and the
    thread is linked to that deal.
    """
    try:
        from business.deal_creation import create_deal_from_qualified_lead

        deal_id = lead.deal_id
        if not deal_id:
            deal_id = await create_deal_from_qualified_lead(api_client, lead)
            if deal_id:
                lead.deal_id = deal_id
                if fsm_context is not None:
                    fsm_context.deal_id = deal_id
                print(
                    f"✅ Created deal {deal_id} for thread {lead.thread_id} (pass-along to creator)"
                )
        if deal_id:
            print(
                f"✅ Email routed to creator conversation for thread {lead.thread_id}, "
                f"deal_id={deal_id}"
            )
        else:
            print(
                f"✅ Email routed to creator (no deal created) for thread {lead.thread_id}"
            )
    except Exception as e:
        print(f"Error routing email to creator: {e}")


async def process_email_event(
    api_client: APIClient,
    email_event: EmailEvent,
    email_content: str,
    preferences_override: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Core email processing flow shared by Lambda and local testers.

    Args:
        api_client: API client for database operations
        email_event: Parsed email event data
        email_content: Raw email content
        preferences_override: Optional dict to override creator preferences during simulation.
            Supported keys: absoluteMinimumRate, autoRejectCategories, partnershipTypes
    """
    # Ensure OPENAI_API_KEY is loaded when running locally (e.g. FSM simulator) so classification works
    if not os.environ.get("OPENAI_API_KEY"):
        try:
            from pathlib import Path
            from dotenv import load_dotenv
            for name in (".env", ".env.local"):
                path = Path(name)
                if path.is_file():
                    load_dotenv(path)
                    if os.environ.get("OPENAI_API_KEY"):
                        break
        except Exception:
            pass

    lead: Optional[LeadQualificationData] = None
    reply_message: Optional[Dict[str, Any]] = None

    repflow_username = email_event.recipient_email.split("@")[0].lower().strip()
    user = await api_client.get_user_by_repflow_username(repflow_username)
    if not user:
        return {
            "lambda_body": {"message": "User not found"},
            "lead": None,
            "result": None,
            "conversation_history": "",
            "state_history": [],
            "event_type": FSMEvent.EMAIL_RECEIVED,
            "reply_message": None,
        }

    if await was_email_processed(api_client, email_event.message_id):
        return {
            "lambda_body": {"message": "Email already processed"},
            "lead": None,
            "result": None,
            "conversation_history": "",
            "state_history": [],
            "event_type": FSMEvent.EMAIL_RECEIVED,
            "reply_message": None,
        }

    clean_email = extract_email_address(email_event.sender_email)
    if await is_blacklisted(api_client, clean_email):
        await mark_email_processed(
            api_client, email_event.message_id, email_event.thread_id
        )
        return {
            "lambda_body": {"message": "Email blacklisted"},
            "lead": None,
            "result": None,
            "conversation_history": "",
            "state_history": [],
            "event_type": FSMEvent.EMAIL_RECEIVED,
            "reply_message": None,
        }

    if re.search(r"no-reply|noreply|no-response", clean_email, re.IGNORECASE):
        await mark_email_processed(
            api_client, email_event.message_id, email_event.thread_id
        )
        return {
            "lambda_body": {"message": "No-reply email skipped"},
            "lead": None,
            "result": None,
            "conversation_history": "",
            "state_history": [],
            "event_type": FSMEvent.EMAIL_RECEIVED,
            "reply_message": None,
        }

    incoming_message = {
        "message_id": email_event.message_id,
        "thread_id": email_event.thread_id,
        "sender_email": email_event.sender_email,
        "recipient_email": email_event.recipient_email,
        "subject": email_event.subject,
        "content": email_content,
        "direction": "inbound",
        "timestamp": email_event.timestamp,
    }
    # Parse the email content with mail-parser-reply
    latest_reply = EmailReplyParser().parse_reply(email_content)

    incoming_message["content"] = latest_reply

    await store_message(api_client, incoming_message, user_id=user.uuid)

    lead_dict = await get_lead_by_thread_id(api_client, email_event.thread_id)
    if lead_dict:
        lead = LeadQualificationData.model_validate(lead_dict)
    else:
        created_lead = await create_lead(
            api_client, email_event.sender_email, email_event.thread_id, user.uuid
        )
        if not created_lead:
            return {
                "lambda_body": {"error": "Failed to create lead"},
                "lead": None,
                "result": None,
                "conversation_history": "",
                "state_history": [],
                "event_type": FSMEvent.EMAIL_RECEIVED,
                "reply_message": None,
            }
        lead = LeadQualificationData.model_validate(created_lead)
        lead_dict = created_lead

    assert lead is not None

    # Use UUID first (simulator and API expect UUID), fallback to _id/ObjectId if present
    lead_id_value = str(
        lead.uuid
        or (lead_dict.get("uuid") if lead_dict else None)
        or (lead.id if lead.id else (lead_dict.get("_id") if lead_dict else None))
    )
    if not lead_id_value or lead_id_value == "None":
        return {
            "lambda_body": {"error": "Lead missing id"},
            "lead": None,
            "result": None,
            "conversation_history": "",
            "state_history": [],
            "event_type": FSMEvent.EMAIL_RECEIVED,
            "reply_message": None,
        }

    conversation_messages = await get_conversation_history(
        api_client, email_event.thread_id
    )
    conversation_history = format_conversation_history(conversation_messages)

    # If no history (e.g. new thread or messages not yet available), use current email so classifier has content
    current_email_context = {
        "subject": email_event.subject,
        "content": email_content,
        "from": email_event.sender_email,
        "to": email_event.recipient_email,
        "timestamp": email_event.timestamp,
    }
    if not (conversation_history or "").strip():
        conversation_history = (
            "CONVERSATION HISTORY:\n"
            "--- [CURRENT MESSAGE] ---\n"
            f"From: {email_event.sender_email}\n"
            f"To: {email_event.recipient_email}\n"
            f"Subject: {email_event.subject}\n"
            f"Direction: INBOUND\n\n"
            f"{email_content or ''}"
        )

    starting_processing_state = lead.processing_state
    event_type = FSMEvent.EMAIL_RECEIVED
    if lead.processing_state == EmailProcessingState.DEAL_CREATED and lead.deal_id:
        event_type = FSMEvent.DEAL_CONVERSATION_EMAIL

    # Apply preferences override if provided (for demo/simulation purposes)
    if preferences_override:
        print(f"[FSM] Applying preferences override: {preferences_override}")
        # Create a copy of user preferences to avoid mutating the original
        from copy import deepcopy

        overridden_prefs = deepcopy(user.preferences)

        if "absoluteMinimumRate" in preferences_override:
            overridden_prefs.absoluteMinimumRate = preferences_override[
                "absoluteMinimumRate"
            ]

        if "autoRejectCategories" in preferences_override:
            overridden_prefs.autoRejectCategories = preferences_override[
                "autoRejectCategories"
            ]

        if "partnershipTypes" in preferences_override:
            pt = preferences_override["partnershipTypes"]
            if "flatRate" in pt:
                overridden_prefs.partnershipTypes.flatRate = pt["flatRate"]
            if "affiliate" in pt:
                overridden_prefs.partnershipTypes.affiliate = pt["affiliate"]
            if "performanceHybrid" in pt:
                overridden_prefs.partnershipTypes.performanceHybrid = pt[
                    "performanceHybrid"
                ]
            if "custom" in pt:
                overridden_prefs.partnershipTypes.custom = pt["custom"]

        # Create a shallow copy of user with overridden preferences
        user = user.copy_with_updates(update={"preferences": overridden_prefs})

    fsm_context = FSMContext(
        lead=lead,
        user=user,
        conversation_history=conversation_history,
        current_email=current_email_context,
        api_client=api_client,
        state_metadata=lead.state_metadata.copy(),
        deal_id=lead.deal_id,
    )

    initial_state = (
        FSMState(lead.processing_state)
        if isinstance(lead.processing_state, str)
        else FSMState(lead.processing_state.value)
    )
    fsm = StateMachine(fsm_context, initial_state)

    # Execution Loop for Chained Transitions
    MAX_STEPS = 5
    current_event = event_type
    result = None

    for step_idx in range(MAX_STEPS):
        previous_state = fsm.get_current_state()
        result = await fsm.process_event(current_event)

        print(
            f"[FSM] result step={step_idx} "
            f"new_state={result.new_state} "
            f"trigger={result.trigger} "
            f"should_send_email={result.should_send_email} "
            f"should_route_to_creator={result.should_route_to_creator} "
            f"response_len={len(result.response_to_send) if result.response_to_send else 0} "
            f"metadata={result.metadata}"
        )

        # If finalized with output, break
        if result.should_send_email or result.should_route_to_creator:
            break

        # If auto-transition/reset is needed, continue
        # TransitionTrigger.EMAIL (from terminal state reset) or AI (sequenced step)
        if result.success and (
            result.trigger == TransitionTrigger.AI
            or result.trigger == TransitionTrigger.EMAIL
        ):
            if result.new_state == previous_state:
                # Avoid infinite loop if state doesn't change
                break
            continue

        break

    if result is None:
        raise RuntimeError("FSM failed to produce a result")

    # FAIL-SAFE: Ensure we never drop an email silently
    if not result.should_send_email and not result.should_route_to_creator:
        print(
            "[FSM] FAIL-SAFE TRIGGERED: No response generated. Forcing generic response."
        )
        result.should_send_email = True
        result.should_route_to_creator = True
        creator_name = user.profile.name or "the team"
        # Re-engagement after rejection: use context-aware wording so we don't sound thread-blind
        if starting_processing_state in (
            EmailProcessingState.REJECTED,
            EmailProcessingState.REJECTED_NON_SPONSORSHIP,
        ):
            result.response_to_send = (
                f"Thanks for the update — I've passed this along to {creator_name}, "
                "and we'll be in touch shortly."
            )
        else:
            result.response_to_send = (
                f"Thanks for your message! I've passed this along to {creator_name}, "
                "and we'll be in touch shortly."
            )

    # Persist and return the lead instance that the FSM mutated (parser fills budget/deadline/etc.)
    lead = fsm_context.lead

    if result.should_route_to_creator:
        await route_email_to_creator(
            api_client, lead, user, email_event, email_content, fsm_context
        )

    if result.should_send_email and result.response_to_send:
        reply_subject = email_event.subject
        if not reply_subject.lower().startswith("re:"):
            reply_subject = f"Re: {reply_subject}"
        # Append creator's booking link if set (optional - always include if available)
        reply_body = result.response_to_send
        booking_link = getattr(user.profile, "bookingLink", None) if user and user.profile else None
        if booking_link:
            creator_name = (
                user.profile.name
                if user and user.profile and user.profile.name
                else "the team"
            )
            link_str = str(booking_link)
            reply_body = (
                f"{reply_body.rstrip()}\n\n"
                f"If you'd like to discuss the partner details over a brief call, here is {creator_name}'s calendar: {link_str}"
            )
        # Add signature to reply body for both SES send and simulator response
        creator_name = user.profile.name if user and user.profile and user.profile.name else "the team"
        signature = (
            f"\n\nBest,\n{creator_name}'s Agent\n\n"
            f"Email Support -> Contact: support@userepflow.com"
        )
        reply_body_with_signature = reply_body + signature
        
        success = send_ses_reply(
            email_event.sender_email,
            email_event.recipient_email,
            reply_subject,
            reply_body_with_signature,
            user,
            email_event.message_id,
        )
        if success:
            reply_message = {
                "message_id": f"reply-{email_event.message_id}-{int(datetime.now(timezone.utc).timestamp())}",
                "thread_id": email_event.thread_id,
                "sender_email": email_event.recipient_email,
                "recipient_email": email_event.sender_email,
                "subject": reply_subject,
                "content": reply_body_with_signature,  # Include signature in reply message
                "direction": "outbound",
                "timestamp": datetime.now(timezone.utc),
            }
            await store_message(api_client, reply_message, user_id=user.uuid)

    prev_state = starting_processing_state
    lead.processing_state = EmailProcessingState(result.new_state.value)
    lead.state_metadata = fsm_context.state_metadata
    lead.last_state_change = datetime.now(timezone.utc)
    lead.follow_up_count = fsm_context.get_follow_up_count()
    lead.negotiation_round = fsm_context.get_negotiation_round()
    lead.retry_count = fsm_context.get_retry_count()
    lead.deal_id = fsm_context.deal_id

    lead.state_history.append(
        StateTransitionRecord(
            from_state=(
                prev_state.value if hasattr(prev_state, "value") else str(prev_state)
            ),
            to_state=(
                lead.processing_state.value
                if hasattr(lead.processing_state, "value")
                else str(lead.processing_state)
            ),
            trigger=result.trigger,
            event=event_type.value,
            timestamp=datetime.now(timezone.utc),
            metadata=result.metadata,
        )
    )

    await update_lead(api_client, lead_id_value, lead.thread_id, lead)
    await mark_email_processed(
        api_client, email_event.message_id, email_event.thread_id
    )

    return {
        "lambda_body": {
            "message": "Email processed successfully",
            "message_id": email_event.message_id,
            "sender": email_event.sender_email,
            "reply_sent": result.should_send_email,
            "agent_type": "unified-fsm",
        },
        "lead": lead,
        "result": result,
        "conversation_history": conversation_history,
        "state_history": fsm.state_history,
        "event_type": event_type,
        "reply_message": reply_message,
    }


async def async_lambda_handler(event, context):
    api_client: Optional[APIClient] = None
    lead: Optional[LeadQualificationData] = None
    try:
        print(f"Received event: {json.dumps(event)}")
        api_client = create_api_client()
        async with api_client:
            email_event = parse_ses_event(event)
            print(f"Processing email from {email_event.sender_email}")
            email_content = fetch_email_from_s3(
                email_event.s3_bucket, email_event.s3_key
            )
            response_data = await process_email_event(
                api_client, email_event, email_content
            )
            lead = response_data.get("lead")
            return {
                "statusCode": 200,
                "body": json.dumps(response_data["lambda_body"]),
            }

    except Exception as e:
        print(f"Error in Lambda handler: {e}")
        traceback.print_exc()
        if lead and api_client:
            lead.processing_state = EmailProcessingState.ERROR_CLASSIFICATION_FAILED
            lead.state_metadata["error_message"] = str(e)
            lead.retry_count += 1
            # Safely get lead ID - if lead.id is None, we can't update the lead record
            if lead.id is not None:
                await update_lead(api_client, str(lead.id), lead.thread_id, lead)
        return {"statusCode": 500, "body": json.dumps({"error": str(e)})}


def lambda_handler(event, context):
    import asyncio

    return asyncio.run(async_lambda_handler(event, context))
