#!/usr/bin/env python3
"""
AWS Lambda Deployment Package Builder

This script automates the creation of a .zip deployment package for AWS Lambda
following the AWS documentation guidelines. It creates a deployment package
with all dependencies installed at the root level as required by Lambda.

Usage:
    python package.py

The script will:
1. Create a 'package' directory for dependencies
2. Install all dependencies from requirements.txt into the package directory
3. Create a .zip file with dependencies at the root
4. Add lambda_function.py to the root of the .zip file
5. Clean up temporary files

Output: lambda_deployment_package.zip
"""

import os
import sys
import shutil
import subprocess
import zipfile
from pathlib import Path


def run_command(command: list, cwd: str | None = None) -> bool:
    """
    Run a shell command and return success status.

    Args:
        command: List of command parts
        cwd: Working directory for the command

    Returns:
        True if command succeeded, False otherwise
    """
    try:
        print(f"Running: {' '.join(command)}")
        result = subprocess.run(
            command, cwd=cwd, check=True, capture_output=True, text=True
        )
        if result.stdout:
            print(result.stdout)
        return True
    except subprocess.CalledProcessError as e:
        print(f"Error running command: {e}")
        if e.stderr:
            print(f"Error output: {e.stderr}")
        return False


def create_deployment_package():
    """Create AWS Lambda deployment package following AWS guidelines."""

    # Get the current directory (lambda directory)
    lambda_dir = Path.cwd()
    package_dir = lambda_dir / "package"
    zip_filename = "lambda_deployment_package.zip"
    zip_path = lambda_dir / zip_filename

    print("=== AWS Lambda Deployment Package Builder ===")
    print(f"Working directory: {lambda_dir}")

    # Step 1: Clean up any existing package directory and zip file
    print("\n1. Cleaning up existing files...")
    if package_dir.exists():
        print(f"Removing existing package directory: {package_dir}")
        shutil.rmtree(package_dir)

    if zip_path.exists():
        print(f"Removing existing zip file: {zip_path}")
        zip_path.unlink()

    # Step 2: Create package directory
    print("\n2. Creating package directory...")
    package_dir.mkdir(exist_ok=True)
    print(f"Created directory: {package_dir}")

    # Step 3: Install dependencies
    print("\n3. Installing dependencies from requirements.txt...")
    if not (lambda_dir / "requirements.txt").exists():
        print("Error: requirements.txt not found!")
        return False

    # Install dependencies to package directory
    install_success = run_command(
        [
            sys.executable,
            "-m",
            "pip",
            "install",
            "--platform",
            "manylinux2014_x86_64",
            "--implementation",
            "cp",
            "--python-version",
            "3.13",
            "--only-binary=:all:",
            "--target",
            str(package_dir),
            "-r",
            "requirements.txt",
            "--upgrade",
        ]
    )

    if not install_success:
        print("Failed to install dependencies!")
        return False

    print("Dependencies installed successfully!")

    # Step 4: Create zip file with dependencies at root
    print("\n4. Creating zip file with dependencies...")

    try:
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
            # Add all files from package directory to root of zip
            for root, dirs, files in os.walk(package_dir):
                for file in files:
                    file_path = Path(root) / file
                    # Calculate relative path from package directory
                    relative_path = file_path.relative_to(package_dir)
                    # Add to zip at root level
                    zipf.write(file_path, str(relative_path))

        print(f"Created zip file: {zip_path}")

    except Exception as e:
        print(f"Error creating zip file: {e}")
        return False

    # Step 5: Add lambda_function.py to root of zip
    print("\n5. Adding lambda_function.py to zip file...")

    lambda_function_path = lambda_dir / "lambda_function.py"
    if not lambda_function_path.exists():
        print("Error: lambda_function.py not found!")
        return False

    try:
        with zipfile.ZipFile(zip_path, "a", zipfile.ZIP_DEFLATED) as zipf:
            zipf.write(lambda_function_path, "lambda_function.py")

        print("Added lambda_function.py to zip file!")

    except Exception as e:
        print(f"Error adding lambda_function.py: {e}")
        return False

    # Step 6: Add additional modules to zip if they exist
    print("\n6. Adding additional modules...")
    
    modules_to_add = ["database", "ai_agents", "fsm", "business"]
    
    for module_name in modules_to_add:
        module_dir = lambda_dir / module_name
        if module_dir.exists():
            try:
                with zipfile.ZipFile(zip_path, "a", zipfile.ZIP_DEFLATED) as zipf:
                    for root, dirs, files in os.walk(module_dir):
                        for file in files:
                            if file.endswith(".py"):
                                file_path = Path(root) / file
                                relative_path = file_path.relative_to(lambda_dir)
                                zipf.write(file_path, str(relative_path))

                print(f"Added {module_name} module to zip file!")

            except Exception as e:
                print(f"Error adding {module_name} module: {e}")
                return False
        else:
            print(f"No {module_name} directory found, skipping...")

    api_client_path = lambda_dir / "api_client.py"
    if not api_client_path.exists():
        print("Error: api_client.py not found!")
        return False

    try:
        with zipfile.ZipFile(zip_path, "a", zipfile.ZIP_DEFLATED) as zipf:
            zipf.write(api_client_path, "api_client.py")

        print("Added api_client.py to zip file!")

    except Exception as e:
        print(f"Error adding api_client.py: {e}")
        return False

    # Step 7: Clean up package directory
    print("\n7. Cleaning up temporary files...")
    if package_dir.exists():
        shutil.rmtree(package_dir)
        print("Removed temporary package directory")

    # Step 8: Verify zip file structure
    print("\n8. Verifying zip file structure...")
    try:
        with zipfile.ZipFile(zip_path, "r") as zipf:
            file_list = zipf.namelist()

            # Check for lambda_function.py at root
            if "lambda_function.py" not in file_list:
                print("Warning: lambda_function.py not found at root of zip!")
                return False

            # Show first few files for verification
            print("Zip file contents (first 10 files):")
            for i, filename in enumerate(file_list[:10]):
                print(f"  {filename}")

            if len(file_list) > 10:
                print(f"  ... and {len(file_list) - 10} more files")

            print(f"\nTotal files in zip: {len(file_list)}")

    except Exception as e:
        print(f"Error verifying zip file: {e}")
        return False

    print(f"\n✅ SUCCESS! Deployment package created: {zip_filename}")
    print(f"📦 File size: {zip_path.stat().st_size / 1024 / 1024:.2f} MB")
    print("\nYou can now upload this zip file to AWS Lambda!")

    return True


def main():
    """Main entry point."""

    # Check if we're in the lambda directory
    if not Path("lambda_function.py").exists():
        print(
            "Error: This script must be run from the lambda directory containing lambda_function.py"
        )
        print("Current directory:", Path.cwd())
        sys.exit(1)

    # Check if requirements.txt exists
    if not Path("requirements.txt").exists():
        print("Error: requirements.txt not found in current directory")
        sys.exit(1)

    # Create the deployment package
    success = create_deployment_package()

    if not success:
        print("\n❌ Failed to create deployment package!")
        sys.exit(1)

    sys.exit(0)


if __name__ == "__main__":
    main()
