from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional

from database.models.deal import (
    Deal,
    DealStatus,
    DealType,
    DueDateType,
    Deliverable,
    DeliverableContent,
    Brief,
    DealSource,
)
from database.models.lead import LeadQualificationData
from api_client import APIClient
from business.qualification import (
    extract_budget_value,
    determine_deal_type_from_budget,
)


async def create_deal_from_qualified_lead(
    api_client: APIClient, lead: LeadQualificationData
) -> Optional[str]:
    """Create or update a Deal object from a qualified lead via API.
    
    If lead.deal_id exists, updates the existing deal with new information.
    Otherwise, creates a new deal.
    """
    try:
        # Check if a deal already exists for this lead
        existing_deal = None
        if lead.deal_id:
            try:
                existing_deal = await api_client.get_deal(lead.deal_id)
                if existing_deal:
                    print(f"✅ Found existing deal {lead.deal_id}, will update with new budget/info")
            except Exception as e:
                print(f"⚠️ Could not fetch existing deal {lead.deal_id}: {e}, will create new deal")
        budget_value = extract_budget_value(lead.budget or "")
        if budget_value == 0.0:
            budget_value = 1000.0

        deal_type_str = determine_deal_type_from_budget(lead.budget or "")

        deal_type_mapping = {
            "FLAT_RATE": DealType.FLAT_RATE,
            "AFFILIATE": DealType.AFFILIATE,
            "UGC": DealType.UGC,
            "SPONSORED_POST": DealType.SPONSORED_POST,
            "BRAND_PARTNERSHIP": DealType.BRAND_PARTNERSHIP,
            "REVENUE_SHARE": DealType.REVENUE_SHARE,
        }
        deal_type = deal_type_mapping.get(deal_type_str, DealType.FLAT_RATE)

        deliverables: list[Deliverable] = []
        if lead.deliverables:
            for deliverable in lead.deliverables:
                deliverables.append(
                    Deliverable(
                        contents=[
                            DeliverableContent(contentType=deliverable.contentType, text=deliverable.text)
                        ],
                        isBundle=False,
                        draftLink=None,
                        invoiceLink=None,
                    )
                )

        # Create/find CRM Brand entity before deal creation
        brand_id = None
        if lead.brand_name:
            try:
                brand_data = {
                    "name": lead.brand_name,
                    "website": lead.brand_website,
                    "category": lead.brand_category,
                    "user_id": lead.userId,  # Required for service account auth
                }
                created_brand = await api_client.find_or_create_brand(brand_data)
                if created_brand:
                    brand_id = created_brand.get("uuid")
                    print(f"✅ Created/found CRM brand {brand_id} for {lead.brand_name}")
            except Exception as brand_err:
                # Log warning but continue - brand creation is not critical
                print(f"⚠️ Failed to create CRM brand: {brand_err}")


        # Create/find CRM Contact entity before deal creation
        contact_id = None
        if lead.brand_contact_email:
            try:
                # Determine if contact is agency-based
                is_agency_contact = (lead.contact_type or "").lower() == "agency"

                contact_data = {
                    "name": lead.brand_contact_name or "Unknown",
                    "email": lead.brand_contact_email,
                    "title": lead.contact_title,
                    "is_agency_contact": is_agency_contact,
                    "notes": f"Auto-created from email lead - {lead.brand_name}",
                    "user_id": lead.userId,  # Required for service account auth
                    "brand_id": brand_id,
                }
                created_contact = await api_client.find_or_create_contact(contact_data)
                if created_contact:
                    contact_id = created_contact.get("uuid")
                    print(f"✅ Created/found CRM contact {contact_id} for email {lead.brand_contact_email}")
            except Exception as contact_err:
                # Log warning but continue - contact creation is not critical
                print(f"⚠️ Failed to create CRM contact: {contact_err}")

        brief = Brief(
            link="https://placeholder.com/brief",
            promoCode="PENDING",
        )

        # Note: deadline is now a flexible string (e.g., "2 posts in January")
        # We keep due_date as None since deadline may not be a parseable date
        due_date = None

        # Build internal comments with lead details (only editable by creator user)
        # Brand comments are not included here - they should be added separately by the brand
        comments_parts = []
        lead_info = [
            f"Brand: {lead.brand_name or 'Unknown'}",
            f"Website: {lead.brand_website or 'Not provided'}",
            f"Category: {lead.brand_category or 'Unknown'}",
            f"Contact: {lead.brand_contact_name or 'Unknown'} ({lead.brand_contact_email or 'No email'})",
            f"Contact Type: {lead.contact_type or 'Unknown'}",
            f"Contact Title: {lead.contact_title or 'Unknown'}",
            f"Budget: {lead.budget or 'Not specified'}",
            f"Deadline: {lead.deadline or 'TBD'}",
            f"Deliverables: {lead.deliverables or 'Not specified'}",
        ]
        comments_parts.append("Lead Details: " + " | ".join(lead_info))
        comments_parts.append("Source: Email automation")

        final_comments = " | ".join(comments_parts)

        deal = Deal(
            title=f"Partnership with {lead.brand_name or 'Unknown Company'}",
            source=DealSource.REPFLOW,
            status=DealStatus.NEW_OFFER,
            dealType=deal_type,
            value=budget_value,
            valueCurrency="USD",
            dueDate=due_date,
            dueDateType=DueDateType.REMINDER,
            reminderDays=3,
            isPriority=False,
            isHighValue=budget_value >= 5000,
            isAiPaused=False,
            dateReceived=datetime.now(timezone.utc).date(),
            comments=final_comments,
            brief=brief,
            deliverables=deliverables,
            communicationHistory=[],
            timeInStage=0,
            userId=lead.userId,
            createdBy="email_automation",
            updatedBy="email_automation",
            brandId=brand_id,  # Link to CRM brand
            contactId=contact_id,  # Link to CRM contact
        )

        deal_data = deal.model_dump(mode="json")
        
        # Update existing deal or create new one
        if existing_deal:
            # Update existing deal with new budget and other updated information
            # Preserve existing communication history and other fields that shouldn't be overwritten
            deal_data["uuid"] = lead.deal_id
            if existing_deal.get("communicationHistory"):
                deal_data["communicationHistory"] = existing_deal.get("communicationHistory")
            if existing_deal.get("createdAt"):
                deal_data["createdAt"] = existing_deal.get("createdAt")
            if existing_deal.get("createdBy"):
                deal_data["createdBy"] = existing_deal.get("createdBy")
            # Update timestamp and updatedBy
            deal_data["updatedAt"] = datetime.now(timezone.utc).isoformat()
            deal_data["updatedBy"] = "email_automation"
            
            updated_deal = await api_client.update_deal(lead.deal_id, deal_data)
            if updated_deal:
                deal_id = updated_deal.get("uuid") or lead.deal_id
                print(f"✅ Updated deal {deal_id} with new budget: ${budget_value}")
                return deal_id
        else:
            # Create new deal
            created_deal = await api_client.create_deal(deal_data)
            if created_deal:
                # Use 'uuid' as the primary deal identifier (consistent with CRUDDocument)
                deal_id = created_deal.get("uuid")

                # Link existing conversation to the new deal (if one exists for this thread)
                if lead.thread_id:
                    conversation = await api_client.get_conversation_by_thread_id(lead.thread_id)
                    if conversation and conversation.get("uuid"):
                        await api_client.link_conversation_to_deal(
                            conversation_id=conversation.get("uuid"),
                            deal_id=deal_id,
                        )
                        print(f"✅ Linked conversation {conversation.get('uuid')} to deal {deal_id}")

                return deal_id

        return None

    except Exception as exc:
        raise RuntimeError(f"Error creating deal from qualified lead: {exc}") from exc
