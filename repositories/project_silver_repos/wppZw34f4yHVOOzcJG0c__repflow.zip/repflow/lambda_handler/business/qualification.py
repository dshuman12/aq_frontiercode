import re
from typing import List, Set

from database.models.lead import LeadQualificationData
from database.models.user import PartnershipPreferences, UserPreferences


# Semantic category equivalences - categories in the same group should match each other
# Each tuple represents a group of equivalent/related categories
CATEGORY_EQUIVALENCES: List[Set[str]] = [
    # Gaming-related categories
    {"gaming", "video games", "games", "esports", "gaming & entertainment", "mobile gaming"},
    # Crypto-related categories
    {"crypto", "cryptocurrency", "blockchain", "nft", "nfts", "web3", "crypto/blockchain/nfts"},
    # Health supplements
    {"nutritional supplements", "supplements", "dietary supplements", "vitamins", "health supplements"},
    # Adult/gambling
    {"gambling", "casino", "betting", "adult", "adult content"},
    # Alcohol/tobacco
    {"alcohol", "tobacco", "vaping", "cigarettes", "e-cigarettes"},
]


def categories_match(brand_category: str, reject_category: str) -> bool:
    """
    Check if a brand category matches a reject category.
    
    Uses multiple matching strategies:
    1. Bidirectional substring matching (either contains the other)
    2. Semantic equivalence matching (e.g., "Gaming" matches "Video Games")
    
    Args:
        brand_category: The category detected for the brand (e.g., "Gaming")
        reject_category: The category the creator wants to reject (e.g., "Video Games")
        
    Returns:
        True if the categories should be considered a match (i.e., should reject)
    """
    brand_lower = brand_category.lower().strip()
    reject_lower = reject_category.lower().strip()
    
    # Empty check
    if not brand_lower or not reject_lower:
        return False
    
    # Strategy 1: Exact match
    if brand_lower == reject_lower:
        return True
    
    # Strategy 2: Bidirectional substring matching
    # Check if either category contains the other
    if reject_lower in brand_lower or brand_lower in reject_lower:
        return True
    
    # Strategy 3: Semantic equivalence matching
    # Find which equivalence group(s) each category belongs to
    brand_groups: List[Set[str]] = []
    reject_groups: List[Set[str]] = []
    
    for equiv_group in CATEGORY_EQUIVALENCES:
        # Check if brand category matches any term in this group
        for term in equiv_group:
            if term in brand_lower or brand_lower in term:
                brand_groups.append(equiv_group)
                break
        
        # Check if reject category matches any term in this group
        for term in equiv_group:
            if term in reject_lower or reject_lower in term:
                reject_groups.append(equiv_group)
                break
    
    # If they share any equivalence group, they match
    for brand_group in brand_groups:
        if brand_group in reject_groups:
            return True
    
    return False


def check_qualification_criteria(
    lead: LeadQualificationData, preferences: UserPreferences
) -> bool:
    """
    Check if the lead passes qualification criteria for deal creation.

    Validates:
    1. Required fields for deal creation (brand_name, brand_category, budget, deliverables)
    2. Budget meets minimum rate requirement
    3. Brand category not in auto-reject list
    4. Partnership type compatibility with user preferences
    5. Contact information availability
    6. Field quality validation (minimum lengths, etc.)
    """
    try:
        missing_fields = lead.get_missing_fields()
        if len(missing_fields) > 0:
            return False

        if lead.budget:
            budget_value = extract_budget_value(lead.budget)
            if budget_value < preferences.absoluteMinimumRate:
                return False
        else:
            return False

        brand_category = lead.brand_category or ""
        for reject_category in preferences.autoRejectCategories:
            if categories_match(brand_category, reject_category):
                return False

        deal_type = determine_deal_type_from_budget(lead.budget or "")
        if not is_partnership_type_accepted(deal_type, preferences.partnershipTypes):
            return False

        has_contact_info = (
            lead.brand_contact_name
            or lead.brand_contact_email
            or lead.email
        )
        if not has_contact_info:
            return False

        if lead.brand_name and len(lead.brand_name.strip()) < 2:
            return False

        if lead.deliverables:
            for deliverable in lead.deliverables:
                if len(deliverable.strip()) < 5:
                    return False

        return True

    except Exception:
        return False


def extract_budget_value(budget_str: str) -> float:
    """Extract numeric budget value from budget string.

    Handles formats like:
    - "$5,000", "$5000", "5000 USD"
    - "$5K", "$5k" (thousands)
    - "$5,000 - $10,000" (ranges - takes lower bound)
    - "5000" (plain numbers)
    """
    if not budget_str:
        return 0.0

    try:
        # Normalize the string
        clean_budget = (
            budget_str.replace("$", "")
            .replace(",", "")
            .replace("USD", "")
            .replace("usd", "")
            .strip()
        )

        # Handle K/k suffix (e.g., "5K" = 5000)
        k_match = re.search(r"(\d+(?:\.\d+)?)\s*[kK](?:\b|$)", clean_budget)
        if k_match:
            return float(k_match.group(1)) * 1000

        # Try to find numbers with optional decimals
        budget_numbers = re.findall(r"\d+(?:\.\d+)?", clean_budget)

        if budget_numbers:
            return float(budget_numbers[0])

        # Check for range format like "5000 - 10000"
        range_match = re.search(
            r"(\d+(?:\.\d+)?)\s*[-–]\s*(\d+(?:\.\d+)?)", clean_budget
        )
        if range_match:
            return float(range_match.group(1))

    except (ValueError, AttributeError) as e:
        print(f"[QUALIFICATION] Warning: Failed to parse budget '{budget_str}': {e}")

    return 0.0


def determine_deal_type_from_budget(budget_str: str) -> str:
    """Determine deal type based on budget description."""
    if not budget_str:
        return "FLAT_RATE"

    budget_lower = budget_str.lower()

    if any(term in budget_lower for term in ["affiliate", "commission", "%"]):
        return "AFFILIATE"
    if "ugc" in budget_lower:
        return "UGC"
    if "sponsored" in budget_lower:
        return "SPONSORED_POST"
    if "partnership" in budget_lower:
        return "BRAND_PARTNERSHIP"
    if any(term in budget_lower for term in ["revenue", "share"]):
        return "REVENUE_SHARE"
    if any(term in budget_lower for term in ["performance", "hybrid"]):
        return "PERFORMANCE_HYBRID"
    return "FLAT_RATE"


def is_partnership_type_accepted(
    deal_type: str, partnership_prefs: PartnershipPreferences
) -> bool:
    """Check if the deal type is accepted based on partnership preferences."""
    deal_type_mapping = {
        "FLAT_RATE": partnership_prefs.flatRate,
        "AFFILIATE": partnership_prefs.affiliate,
        "UGC": partnership_prefs.flatRate,
        "SPONSORED_POST": partnership_prefs.flatRate,
        "BRAND_PARTNERSHIP": partnership_prefs.custom,
        "REVENUE_SHARE": partnership_prefs.performanceHybrid,
        "PERFORMANCE_HYBRID": partnership_prefs.performanceHybrid,
    }

    return deal_type_mapping.get(deal_type, partnership_prefs.custom)
