"""
API client for Lambda function to interact with the backend API.
"""

import os
import json
import aiohttp
import asyncio
from typing import Dict, List, Optional, Any, Union
from datetime import datetime
from dataclasses import dataclass
from pydantic import BaseModel, Field
from copy import deepcopy


# Lightweight User models for API client (no Beanie/MongoDB dependency)
# These mirror the essential structure from database.models.user but are pure Pydantic
class UserProfileDTO(BaseModel):
    """Minimal user profile for API operations."""

    id: Optional[str] = None
    name: str = ""
    email: str = ""
    repflow_username: str = ""
    avatar: Optional[str] = None
    bio: Optional[str] = None

    model_config = {"extra": "allow"}  # Allow extra fields


class PartnershipPreferencesDTO(BaseModel):
    """Partnership preferences DTO."""

    flatRate: bool = True
    performanceHybrid: bool = False
    affiliate: bool = True
    ugc: bool = False
    gifting: bool = False
    custom: bool = False

    model_config = {"extra": "allow"}


class UserPreferencesDTO(BaseModel):
    """User preferences for API operations."""

    partnershipTypes: PartnershipPreferencesDTO = Field(
        default_factory=PartnershipPreferencesDTO
    )
    absoluteMinimumRate: float = 1000.0
    autoRejectCategories: List[str] = Field(default_factory=list)
    deliverables: List[Dict[str, Any]] = Field(
        default_factory=list
    )  # Keep as dict to avoid validation issues

    model_config = {"extra": "allow"}  # Allow extra fields


class UserDTO(BaseModel):
    """Lightweight User model for API client operations.

    This mirrors the essential User structure from database.models.user
    but doesn't inherit from Beanie Document, avoiding MongoDB initialization requirements.
    """

    uuid: str = ""
    profile: UserProfileDTO = Field(default_factory=UserProfileDTO)
    preferences: UserPreferencesDTO = Field(default_factory=UserPreferencesDTO)
    platforms: List[Dict[str, Any]] = Field(default_factory=list)
    isActive: bool = True
    isVerified: bool = False

    model_config = {"extra": "allow"}  # Allow extra fields from API response

    def copy_with_updates(self, update: Optional[Dict[str, Any]] = None) -> "UserDTO":
        """Copy model with optional updates.

        Note: Named differently from model_copy to avoid signature conflicts with Pydantic v2.
        """
        if update:
            data = self.model_dump()
            data.update(update)
            return UserDTO.model_validate(data)
        return UserDTO.model_validate(self.model_dump())


# Alias for backwards compatibility
User = UserDTO


@dataclass
class APIConfig:
    """API configuration."""

    base_url: str
    auth_token: str
    timeout: int = 30


class APIClient:
    """Client for making API calls to the backend."""

    def __init__(self, config: APIConfig):
        self.config = config
        self.session: Optional[aiohttp.ClientSession] = None

    async def __aenter__(self):
        """Async context manager entry."""
        self.session = aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=self.config.timeout),
            headers={
                "Authorization": f"ServiceAccount {self.config.auth_token}",
                "Content-Type": "application/json",
            },
        )
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        if self.session:
            await self.session.close()

    async def _make_request(
        self,
        method: str,
        endpoint: str,
        data: Optional[Dict] = None,
        params: Optional[Dict] = None,
    ) -> Optional[Any]:
        """Make an HTTP request to the API."""
        if not self.session:
            raise RuntimeError("APIClient must be used as async context manager")

        # Normalize URL to avoid double slashes
        base = self.config.base_url.rstrip("/")
        ep = endpoint if endpoint.startswith("/") else f"/{endpoint}"
        url = f"{base}{ep}"

        try:
            async with self.session.request(
                method=method, url=url, json=data, params=params
            ) as response:
                if response.status == 404:
                    return None

                try:
                    response.raise_for_status()
                except aiohttp.ClientError as e:
                    print(f"API request failed: {method} {url} - {e}")
                    print(f"Response: {await response.text()}")
                    raise

                if response.content_type == "application/json":
                    return await response.json()
                else:
                    return {"message": await response.text()}

        except aiohttp.ClientError as e:
            print(f"API request failed: {method} {url} - {e}")
            raise

    # Lead management endpoints
    async def get_lead_by_thread_id(self, thread_id: str) -> Optional[Dict]:
        """Get lead by thread ID."""
        return await self._make_request("GET", f"/leads/thread/{thread_id}")

    async def create_lead(self, lead_data: Dict) -> Optional[Dict]:
        """Create a new lead."""
        return await self._make_request("POST", "/leads/", data=lead_data)

    async def update_lead(self, lead_id: str, lead_data: Dict) -> Optional[Dict]:
        """Update an existing lead."""
        return await self._make_request("PUT", f"/leads/{lead_id}", data=lead_data)

    async def mark_lead_qualified(self, thread_id: str) -> Optional[Dict]:
        """Mark a lead as qualified."""
        return await self._make_request("PATCH", f"/leads/thread/{thread_id}/qualify")

    # Deal management endpoints
    async def create_deal(self, deal_data: Dict) -> Optional[Dict]:
        """Create a new deal."""
        return await self._make_request("POST", "/deals/", data=deal_data)

    async def get_deal(self, deal_id: str) -> Optional[Dict]:
        """Get a deal by ID."""
        return await self._make_request("GET", f"/deals/{deal_id}")

    async def update_deal(self, deal_id: str, deal_data: Dict) -> Optional[Dict]:
        """Update an existing deal."""
        return await self._make_request("PUT", f"/deals/{deal_id}", data=deal_data)

    async def link_contact_to_deal(
        self, deal_id: str, contact_id: str
    ) -> Optional[Dict]:
        """Link a contact to a deal."""
        return await self._make_request(
            "PATCH", f"/deals/{deal_id}/link-contact", params={"contact_id": contact_id}
        )

    # Contact management endpoints
    async def find_or_create_contact(self, contact_data: Dict) -> Optional[Dict]:
        """Find existing contact by email or create a new one."""
        return await self._make_request(
            "POST", "/contacts/find-or-create", data=contact_data
        )

    # Brand management endpoints
    async def find_or_create_brand(self, brand_data: Dict) -> Optional[Dict]:
        """Find existing brand by name or create a new one."""
        return await self._make_request(
            "POST", "/brands/find-or-create", data=brand_data
        )

    # Processed email endpoints
    async def check_email_processed(self, message_id: str) -> bool:
        """Check if email was already processed."""
        result = await self._make_request(
            "GET", f"/leads/processed-emails/{message_id}"
        )
        return bool(result) if result is not None else False

    async def mark_email_processed(
        self, message_id: str, thread_id: str
    ) -> Optional[Dict]:
        """Mark email as processed."""
        return await self._make_request(
            "POST",
            "/leads/processed-emails/",
            params={"message_id": message_id, "thread_id": thread_id},
        )

    # Blacklist endpoints
    async def check_email_blacklisted(self, email: str) -> bool:
        """Check if email is blacklisted."""
        result = await self._make_request("GET", f"/leads/blacklist/{email}")
        return bool(result) if result is not None else False

    # Conversation endpoints
    async def get_conversation_by_thread_id(self, thread_id: str) -> Optional[Dict]:
        """Get conversation by thread ID."""
        return await self._make_request("GET", f"/conversations/thread/{thread_id}")

    async def get_conversation_history(
        self, thread_id: str, limit: int = 50
    ) -> List[Dict]:
        """Get conversation history (messages) for a thread."""
        result = await self._make_request(
            "GET",
            f"/conversations/thread/{thread_id}/messages",
            params={"limit": limit},
        )
        return result or []

    async def create_conversation_for_deal(
        self, deal_id: str, thread_id: Optional[str] = None
    ) -> Optional[Dict]:
        """Create or get conversation for a deal with optional thread_id."""
        return await self._make_request(
            "POST",
            "/conversations/for-deal",
            params={"deal_id": deal_id, "thread_id": thread_id},
        )

    async def create_pre_deal_conversation(
        self,
        thread_id: str,
        user_id: str,
        contact_email: str,
        contact_name: str,
        subject: str,
    ) -> Optional[Dict]:
        """Create a pre-deal conversation for storing emails before a deal is created."""
        return await self._make_request(
            "POST",
            "/conversations/pre-deal",
            params={
                "thread_id": thread_id,
                "user_id": user_id,
                "contact_email": contact_email,
                "contact_name": contact_name,
                "subject": subject,
            },
        )

    async def link_conversation_to_deal(
        self, conversation_id: str, deal_id: str
    ) -> Optional[Dict]:
        """Link an existing conversation to a deal."""
        return await self._make_request(
            "PATCH",
            f"/conversations/{conversation_id}/link-deal",
            params={"deal_id": deal_id},
        )

    # Message endpoints
    async def create_message_for_conversation(
        self, message_data: Dict
    ) -> Optional[Dict]:
        """Create a message in a conversation."""
        return await self._make_request("POST", "/messages/", data=message_data)

    # User endpoints
    async def get_user_by_repflow_username(
        self, repflow_username: str
    ) -> Optional[User]:
        """Get user by repflow username."""
        result = await self._make_request(
            "POST",
            "/users/by-repflow-username",
            data={"repflow_username": repflow_username},
        )
        if result is None:
            return None
        try:
            # UserDTO is lightweight and lenient - should handle API response directly
            return User.model_validate(result)
        except Exception as e:
            print(f"Warning: User model validation failed: {e}")
            # Even with lenient model, if validation fails, return None
            return None


def create_api_client() -> APIClient:
    """Create API client with configuration from environment variables."""
    base_url = os.environ.get("API_BASE_URL", "")
    auth_token = os.environ.get("API_AUTH_TOKEN", "")

    if not base_url:
        raise ValueError("API_BASE_URL environment variable is required")

    if not auth_token:
        raise ValueError("API_AUTH_TOKEN environment variable is required")

    config = APIConfig(base_url=base_url, auth_token=auth_token, timeout=30)

    return APIClient(config)


# Helper functions for data conversion
def convert_datetime_for_api(dt: datetime) -> Optional[str]:
    """Convert datetime to API-compatible string."""
    if not dt:
        return None
    if isinstance(dt, datetime):
        return dt.isoformat()
    # Already a string or unsupported type; return as-is to avoid serialization errors
    return dt


def convert_nested_datetimes(value: Any) -> Any:
    """Recursively convert datetime values to ISO strings for safe JSON serialization."""
    if isinstance(value, datetime):
        return convert_datetime_for_api(value)
    if isinstance(value, list):
        return [convert_nested_datetimes(item) for item in value]
    if isinstance(value, dict):
        return {k: convert_nested_datetimes(v) for k, v in value.items()}
    return value


def convert_lead_to_api_format(lead_data: Dict) -> Dict:
    """Convert lead data to API format."""
    api_data = lead_data.copy()

    # Convert datetime fields
    for field in ("created_at", "updated_at", "last_state_change"):
        if field in api_data:
            api_data[field] = convert_datetime_for_api(api_data[field])

    # Convert nested state history timestamps
    if "state_history" in api_data and isinstance(api_data["state_history"], list):
        converted_history = []
        for record in api_data["state_history"]:
            record_dict = (
                record.model_dump() if hasattr(record, "model_dump") else dict(record)
            )
            if "timestamp" in record_dict:
                record_dict["timestamp"] = convert_datetime_for_api(
                    record_dict["timestamp"]
                )
            converted_history.append(record_dict)
        api_data["state_history"] = converted_history

    return convert_nested_datetimes(api_data)


def convert_message_to_api_format(message_data: Dict) -> Dict:
    """Convert message data to API format."""
    api_data = message_data.copy()

    # Convert datetime fields
    if "timestamp" in api_data:
        api_data["timestamp"] = convert_datetime_for_api(api_data["timestamp"])
    if "created_at" in api_data:
        api_data["created_at"] = convert_datetime_for_api(api_data["created_at"])

    return convert_nested_datetimes(api_data)


def convert_deal_to_api_format(deal_data: Dict) -> Dict:
    """Convert deal data to API format."""
    api_data = deal_data.copy()

    # Convert datetime fields
    if "dateReceived" in api_data:
        api_data["dateReceived"] = convert_datetime_for_api(api_data["dateReceived"])
    if "dueDate" in api_data:
        api_data["dueDate"] = convert_datetime_for_api(api_data["dueDate"])
    if "createdAt" in api_data:
        api_data["createdAt"] = convert_datetime_for_api(api_data["createdAt"])
    if "updatedAt" in api_data:
        api_data["updatedAt"] = convert_datetime_for_api(api_data["updatedAt"])

    return convert_nested_datetimes(api_data)
