from typing import List, Optional

from agents import Agent, Runner, AgentOutputSchema
from pydantic import BaseModel, Field


class FollowUpResponse(BaseModel):
    """Follow-up email content for missing info collection."""

    follow_up_text: str = Field(..., description="Polished follow-up email text")


follow_up_agent = Agent(
    name="Info Follow-Up Agent",
    instructions="""
You are a sponsorship follow-up assistant. Follow this exact style:
- Tone: polite, matter-of-fact, one short paragraph, no fluff, no signature.
- Brevity: stay under ~80 words; prefer 1–2 sentences.
- Structure: (1) acknowledge the details received, (2) if the lead showed confusion or asked a question, briefly answer/clarify that once, (3) make ONE clear ask for the remaining fields.
- Clarifications: infer from context—only clarify if the lead asked or showed confusion; do not invent extra definitions; never repeat the same clarification.
- Ask: limit the ask to the missing fields provided in the task input; do not add extra asks.

This is the list of fields that you could be asked to follow up on:
COMPANY INFORMATION:
- brand_name: Brand/company name (required for deal creation)
- brand_website: Company website URL
- brand_category: Brand category or industry

FINANCIAL TERMS:
- budget: Budget/compensation offered (flat fee, affiliate %, hybrid terms, gifting value)

DELIVERABLES:
- deliverables: List of deliverables for the deal. ContentType is the platform (youtube, tiktok, video, podcast, instagram, twitter) and text is the description of the deliverable.

TIMELINE:
- deadline: Project deadline, campaign launch date, or content due date. Return a concise string that preserves all key details (dates, number of deliverables, platforms mentioned). Examples: "January 15, 2025", "2 Instagram posts by end of January 2025", "Campaign launches March 1st". Keep it brief but don't lose important information.
DEAL STRUCTURE:
- deal_type: Deal structure (one-time sponsorship, flat fee, affiliate/rev share, gifting, hybrid, ongoing, or similar phrasing)

CONTACT INFORMATION:
- brand_contact_name: Primary contact name (from signature, sender, or signoff)
- brand_contact_email: Primary contact email (from metadata or signature)  
- contact_type: Whether email is from "Brand Direct" (the brand itself) or "Agency" (a PR/marketing/talent agency representing a brand). Look for agency signals like "on behalf of", "our client", agency-sounding email domains.
- contact_title: Contact's job title/role (Marketing Manager, Brand Manager, Founder, PR Director, Account Executive, CEO, etc.). ALWAYS try to extract this from the email signature block or introduction. Common patterns:
  * "John Smith, Marketing Manager" or "Jane Doe | Brand Director"
  * Title under name in signature
  * Introduction like "I'm the Marketing Lead at..."

ADDITIONAL CONTEXT:
- brand_comment: Any additional context, campaign goals, special requirements, or notes that would be useful for deal management
""",
    output_type=FollowUpResponse,
    tools=[],
)


async def generate_follow_up(
    missing_fields: List[str],
    latest_message: Optional[str],
    conversation_history: Optional[str] = None,
) -> str:
    """Generate a follow-up message using the AI agent."""
    print(
        "[FOLLOW_UP] invoked "
        f"missing_count={len(missing_fields)} "
        f"has_latest={'yes' if latest_message else 'no'} "
        f"has_history={'yes' if conversation_history else 'no'}"
    )
    missing_text = (
        ", ".join(missing_fields[:3]) if missing_fields else "the remaining details"
    )
    latest_snippet = latest_message or "No new inbound message content."
    history = conversation_history or "No prior conversation history."

    prompt = f"""
Conversation history:
{history}

Latest inbound message (from lead):
{latest_snippet}

Missing fields to request:
{missing_text}

Compose the follow-up email that meets the instructions.
"""
    result = await Runner.run(follow_up_agent, prompt)
    follow_up = result.final_output_as(FollowUpResponse).follow_up_text
    print(
        "[FOLLOW_UP] success "
        f"text_len={len(follow_up)} "
        f"preview={repr(follow_up[:120])}"
    )
    return follow_up
