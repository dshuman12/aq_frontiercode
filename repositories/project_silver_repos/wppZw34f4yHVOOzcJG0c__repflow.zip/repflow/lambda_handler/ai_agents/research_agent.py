"""
Research agent that uses web search to gather brand information from email domains.

This agent is called when brand_category or brand_website are missing, using the
lead's email domain to search for information before asking the user.

Enhanced to detect agency emails and extract brand names from email content when
the email domain differs from the actual brand being represented.
"""

import re
from typing import Optional, List
from pydantic import BaseModel, Field

from agents import Agent, Runner, AgentOutputSchema, WebSearchTool


# Patterns that suggest an agency/PR/marketing company domain
AGENCY_DOMAIN_PATTERNS = [
    r"agency",
    r"creative",
    r"media",
    r"marketing",
    r"digital",
    r"studio",
    r"group",
    r"partners",
    r"communications",
    r"pr\b",
    r"public.?relations",
    r"consulting",
    r"consult",
    r"mgmt",
    r"management",
    r"talent",
    r"influencer",
    r"social",
    r"brand(?:ing)?",
    r"advertis",
    r"promo",
]

# Common agency type keywords found in email signatures or content
AGENCY_CONTENT_KEYWORDS = [
    "on behalf of",
    "representing",
    "our client",
    "for our client",
    "for my client",
    "the brand",
    "brand partner",
    "partnered with",
    "working with",
    "agency",
    "talent management",
    "influencer marketing",
    "brand collaboration",
]


def is_agency_domain(domain: str) -> bool:
    """Check if a domain appears to be an agency/PR/marketing company."""
    if not domain:
        return False
    domain_lower = domain.lower()
    for pattern in AGENCY_DOMAIN_PATTERNS:
        if re.search(pattern, domain_lower):
            return True
    return False


def has_agency_content_signals(email_content: str, email_subject: str = "") -> bool:
    """Check if email content contains signals that it's from an agency."""
    combined = f"{email_subject} {email_content}".lower()
    for keyword in AGENCY_CONTENT_KEYWORDS:
        if keyword in combined:
            return True
    return False


class BrandResearchResponse(BaseModel):
    """Response from the Brand Research Agent."""

    brand_name: Optional[str] = Field(
        None,
        description="The official brand/company name found through research",
    )
    brand_website: Optional[str] = Field(
        None,
        description="The official company website URL (e.g., https://example.com)",
    )
    brand_category: Optional[str] = Field(
        None,
        description="The brand's industry/category (e.g., Technology, Fashion, Beauty, Food & Beverage, etc.)",
    )
    brand_description: Optional[str] = Field(
        None,
        description="A brief description of what the company does",
    )
    confidence: float = Field(
        ...,
        description="Confidence score (0-1) that the research found the correct brand matching the email domain",
    )
    is_agency: bool = Field(
        False,
        description="Whether the researched company is an agency, PR firm, marketing company, or talent management company (NOT a product/consumer brand)",
    )
    research_notes: Optional[str] = Field(
        None,
        description="Any additional notes about the research findings or uncertainty",
    )


# Create the web search tool
web_search_tool = WebSearchTool()

brand_research_agent = Agent(
    name="Brand Research Agent",
    instructions="""
You are a Brand Research Agent that helps identify and categorize companies from email domains.

Your job is to research a brand/company based on:
1. The sender's email domain (e.g., "acme.com" from "john@acme.com")
2. Any brand name mentioned in the email
3. Context from the email content

Use web search to find:
1. The official company name
2. The company's website URL  
3. The brand category/industry
4. A brief description of what the company does
5. WHETHER THIS IS AN AGENCY (critical - see below)

AGENCY DETECTION (CRITICAL):
Set is_agency=true if the company is ANY of the following:
- Marketing agency
- PR firm / Public relations company
- Advertising agency
- Talent management company
- Influencer marketing agency
- Creative agency
- Media buying agency
- Digital marketing agency
- Brand management company
- Communications agency
- Any company whose primary business is representing OTHER brands/clients

Signs of an agency on their website:
- "We work with brands", "Our clients include", "Client portfolio"
- Services like "influencer marketing", "brand partnerships", "talent representation"
- Case studies featuring multiple different brands
- Language about "representing" or "managing" talent/creators/brands
- B2B service offerings rather than consumer products

Set is_agency=false only if the company is a direct consumer brand that sells its own products/services.

IMPORTANT RULES:
- Search using the email domain as the primary identifier
- If the domain is a common email provider (gmail.com, outlook.com, yahoo.com, etc.), focus on the brand name from the email instead
- If you find a company website, verify it matches the email domain
- Only provide information you are confident about - set fields to null if uncertain
- ALWAYS set the is_agency field accurately based on your research
- Set confidence score based on how well the research matches:
  - 0.9-1.0: Strong match - found official website matching domain, clear company info
  - 0.7-0.9: Good match - found company info but some details unclear
  - 0.5-0.7: Partial match - found some info but uncertainty remains
  - Below 0.5: Low confidence - could not verify or conflicting information

For brand_category, use one of these standard categories:
- Technology
- Fashion & Apparel
- Beauty & Cosmetics
- Health & Wellness
- Food & Beverage
- Gaming & Entertainment
- Finance & FinTech
- Automotive
- Travel & Hospitality
- Sports & Fitness
- Home & Garden
- Pet Products
- Baby & Kids
- Electronics & Gadgets
- Education
- Business Services (use for agencies if they don't fit elsewhere)
- Other (specify in notes)

If is_agency=true, note the agency name in research_notes and include any brands they appear to represent.
""",
    output_type=BrandResearchResponse,
    tools=[web_search_tool],
)


class BrandExtractionResponse(BaseModel):
    """Response from the Brand Extraction Agent."""

    brand_names: List[str] = Field(
        default_factory=list,
        description="List of brand/company names mentioned in the email that appear to be the sponsoring brand (not the agency)",
    )
    is_agency_email: bool = Field(
        False,
        description="Whether this email appears to be from an agency/PR firm representing a brand",
    )
    agency_name: Optional[str] = Field(
        None,
        description="Name of the agency if identified",
    )
    primary_brand: Optional[str] = Field(
        None,
        description="The most likely brand being represented if identifiable",
    )
    confidence: float = Field(
        0.0,
        description="Confidence score (0-1) in the brand extraction",
    )


brand_extraction_agent = Agent(
    name="Brand Extraction Agent",
    instructions="""
You are a Brand Extraction Agent specialized in identifying brand names from influencer outreach emails.

Your job is to analyze email content (subject and body) to:
1. Determine if the email is from an agency/PR firm/marketing company representing a brand
2. Extract any brand names mentioned that appear to be the actual sponsoring brand

KEY SIGNALS OF AGENCY EMAILS:
- Phrases like "on behalf of", "representing", "our client", "working with", "partnered with"
- Email domain doesn't match the brand discussed in the email
- Marketing/PR company language in signature
- References to "the brand" as a third party

EXTRACTING BRAND NAMES:
- Look for brand names mentioned as partnership opportunities
- Brand names often appear in subject lines (e.g., "Partnership with [Brand Name]")
- Brand names in the email body near words like "campaign", "collaboration", "sponsorship"
- Product or company names that are clearly the focus of the partnership

OUTPUT RULES:
- List all potential brand names found (not agency names)
- Set primary_brand to the most likely brand being represented
- Set is_agency_email to true if signals suggest agency representation
- Set confidence based on clarity of brand identification
- If no clear brand is found, leave brand_names empty

Be conservative - only extract names that clearly appear to be brands seeking sponsorship.
""",
    output_type=BrandExtractionResponse,
    tools=[],
)


async def extract_brand_from_email(
    email_subject: str,
    email_content: str,
    sender_domain: Optional[str] = None,
) -> Optional[BrandExtractionResponse]:
    """
    Extract brand names from email content using AI.
    
    This is called when we detect the email might be from an agency.
    
    Args:
        email_subject: The email subject line
        email_content: The email body content
        sender_domain: The sender's email domain (for context)
        
    Returns:
        BrandExtractionResponse with extracted brand info, or None if extraction fails
    """
    try:
        print(f"[BRAND_EXTRACT] Analyzing email for brand mentions...")
        
        extraction_input = f"""
Analyze this email to identify any brands being represented:

SENDER DOMAIN: {sender_domain or 'Unknown'}

SUBJECT: {email_subject}

EMAIL CONTENT:
{email_content[:2000]}

Identify:
1. Is this from an agency/PR firm/marketing company?
2. What brand(s) are mentioned as the sponsoring brand?
3. Which brand is most likely the one seeking sponsorship?
"""
        
        result = await Runner.run(brand_extraction_agent, extraction_input)
        extraction = result.final_output_as(BrandExtractionResponse)
        
        print(
            f"[BRAND_EXTRACT] result "
            f"is_agency={extraction.is_agency_email} "
            f"brands={extraction.brand_names} "
            f"primary={extraction.primary_brand or '-'} "
            f"confidence={extraction.confidence}"
        )
        
        return extraction
        
    except Exception as exc:
        print(f"[BRAND_EXTRACT] Error extracting brand: {exc}")
        return None


def extract_email_domain(email: str) -> Optional[str]:
    """Extract the domain from an email address."""
    if not email or "@" not in email:
        return None
    domain = email.split("@")[-1].lower().strip()
    
    # Skip common email providers - these don't help with brand research
    common_providers = {
        "gmail.com", "yahoo.com", "outlook.com", "hotmail.com", 
        "aol.com", "icloud.com", "mail.com", "protonmail.com",
        "live.com", "msn.com", "ymail.com", "pm.me"
    }
    if domain in common_providers:
        return None
    return domain


async def research_brand(
    email: str,
    brand_name: Optional[str] = None,
    email_content: Optional[str] = None,
    max_retries: int = 1,
) -> Optional[BrandResearchResponse]:
    """
    Research a brand using web search based on email domain and context.
    
    Args:
        email: The sender's email address
        brand_name: Optional brand name if already extracted from email
        email_content: Optional email content for additional context
        max_retries: Number of retry attempts
        
    Returns:
        BrandResearchResponse with research findings, or None if research fails
    """
    domain = extract_email_domain(email)
    
    # If no searchable domain and no brand name, can't do research
    if not domain and not brand_name:
        print("[BRAND_RESEARCH] No searchable domain or brand name, skipping research")
        return None
    
    attempt = 0
    last_error: Optional[Exception] = None
    
    while attempt <= max_retries:
        try:
            print(
                f"[BRAND_RESEARCH] attempt={attempt + 1}/{max_retries + 1} "
                f"domain={domain or 'N/A'} brand={brand_name or 'N/A'}"
            )
            
            # Build the research prompt
            search_context = []
            if domain:
                search_context.append(f"Email domain: {domain}")
            if brand_name:
                search_context.append(f"Brand name mentioned: {brand_name}")
            if email_content:
                # Take first 500 chars of email for context
                snippet = email_content[:500].replace("\n", " ")
                search_context.append(f"Email excerpt: {snippet}")
            
            research_input = f"""
Please research this brand/company and provide structured information:

{chr(10).join(search_context)}

Search for:
1. The company's official website (should match the email domain if provided)
2. What industry/category they operate in
3. A brief description of what they do

If the email domain is from an agency or marketing company, try to identify both the agency and any brand they might represent.
"""
            
            result = await Runner.run(brand_research_agent, research_input)
            research = result.final_output_as(BrandResearchResponse)
            
            print(
                f"[BRAND_RESEARCH] success "
                f"brand={research.brand_name or '-'} "
                f"website={research.brand_website or '-'} "
                f"category={research.brand_category or '-'} "
                f"confidence={research.confidence}"
            )
            
            # Only return if we have reasonable confidence
            if research.confidence >= 0.5:
                return research
            else:
                print(
                    f"[BRAND_RESEARCH] Low confidence ({research.confidence}), "
                    "discarding results"
                )
                return None
                
        except Exception as exc:
            last_error = exc
            attempt += 1
            print(f"[BRAND_RESEARCH] error attempt={attempt}: {exc}")
            if attempt > max_retries:
                print(f"[BRAND_RESEARCH] Max retries exceeded: {last_error}")
                return None
    
    return None


async def research_and_fill_missing_fields(
    email: str,
    existing_brand_name: Optional[str] = None,
    existing_brand_website: Optional[str] = None,
    existing_brand_category: Optional[str] = None,
    email_content: Optional[str] = None,
    email_subject: Optional[str] = None,
) -> dict:
    """
    Research brand info to fill missing fields.
    
    Enhanced to detect agency emails and extract brand names from email content
    when the email domain differs from the actual brand being represented.
    
    Detection happens in two phases:
    1. Pre-research: Check domain patterns and email content for agency signals
    2. Post-research: If website research reveals it's an agency, re-run with brand extraction
    
    Only performs research if brand_category or brand_website is missing.
    Returns a dict of fields that were successfully researched.
    
    Args:
        email: The sender's email address
        existing_brand_name: Current brand name (may be None)
        existing_brand_website: Current website (may be None) 
        existing_brand_category: Current category (may be None)
        email_content: Email content for context
        email_subject: Email subject line for context
        
    Returns:
        Dict with researched field values (only includes fields that were found)
    """
    # Check if we need to research anything
    needs_website = not existing_brand_website
    needs_category = not existing_brand_category
    
    if not needs_website and not needs_category:
        print("[BRAND_RESEARCH] All brand info already present, skipping research")
        return {}
    
    print(
        f"[BRAND_RESEARCH] Missing fields: "
        f"website={needs_website} category={needs_category}"
    )
    
    domain = extract_email_domain(email)
    brand_to_research = existing_brand_name
    extraction_result: Optional[BrandExtractionResponse] = None
    is_agency = False
    agency_detected_by = None  # Track how agency was detected
    
    # PHASE 1: Pre-research agency detection (domain patterns + email content)
    agency_domain_detected = is_agency_domain(domain) if domain else False
    agency_content_detected = has_agency_content_signals(
        email_content or "", email_subject or ""
    )
    
    if agency_domain_detected or agency_content_detected:
        print(
            f"[BRAND_RESEARCH] Phase 1 - Agency signals detected: "
            f"domain_match={agency_domain_detected} content_match={agency_content_detected}"
        )
        agency_detected_by = "pre_research"
        
        # Run brand extraction to find the actual brand being represented
        if email_content or email_subject:
            extraction_result = await extract_brand_from_email(
                email_subject=email_subject or "",
                email_content=email_content or "",
                sender_domain=domain,
            )
            
            if extraction_result and extraction_result.primary_brand:
                # Use the extracted brand for research instead of domain
                brand_to_research = extraction_result.primary_brand
                is_agency = extraction_result.is_agency_email
                print(
                    f"[BRAND_RESEARCH] Using extracted brand for research: "
                    f"{brand_to_research}"
                )
    
    # Run initial web research
    # Store original research separately so we can track agency vs brand info
    initial_research = await research_brand(
        email=email,
        brand_name=brand_to_research,
        email_content=email_content,
    )
    
    if not initial_research:
        print("[BRAND_RESEARCH] No research results to apply")
        return {}
    
    # Track the agency's website separately from the brand's website
    agency_website = None
    agency_name_from_research = None
    
    # If initial research found an agency, store its info
    if initial_research.is_agency:
        agency_website = initial_research.brand_website
        agency_name_from_research = initial_research.brand_name
    
    # Use initial research as starting point
    research = initial_research
    brand_research_succeeded = False
    
    # PHASE 2: Post-research agency detection (based on website content)
    # If we didn't detect agency before, but research shows it's an agency, re-run
    if not is_agency and initial_research.is_agency:
        print(
            f"[BRAND_RESEARCH] Phase 2 - Website research indicates agency: "
            f"'{initial_research.brand_name}' is an agency"
        )
        agency_detected_by = "website_research"
        is_agency = True
        
        # Run brand extraction now that we know it's an agency
        if (email_content or email_subject) and not extraction_result:
            print("[BRAND_RESEARCH] Running brand extraction after agency detection...")
            extraction_result = await extract_brand_from_email(
                email_subject=email_subject or "",
                email_content=email_content or "",
                sender_domain=domain,
            )
            
            if extraction_result and extraction_result.primary_brand:
                # Re-run research with the extracted brand
                print(
                    f"[BRAND_RESEARCH] Re-running research with extracted brand: "
                    f"{extraction_result.primary_brand}"
                )
                brand_research = await research_brand(
                    email=email,
                    brand_name=extraction_result.primary_brand,
                    email_content=email_content,
                )
                
                # Use the new research if it's better (non-agency result)
                if brand_research and not brand_research.is_agency:
                    print(
                        f"[BRAND_RESEARCH] Found actual brand: {brand_research.brand_name} "
                        f"(website: {brand_research.brand_website})"
                    )
                    research = brand_research
                    brand_to_research = extraction_result.primary_brand
                    brand_research_succeeded = True
                elif brand_research:
                    print(
                        f"[BRAND_RESEARCH] Re-research also found agency, "
                        f"not using agency website as brand website"
                    )
    elif is_agency and extraction_result and extraction_result.primary_brand:
        # Agency was detected in Phase 1, research the extracted brand
        print(
            f"[BRAND_RESEARCH] Researching extracted brand: {extraction_result.primary_brand}"
        )
        brand_research = await research_brand(
            email=email,
            brand_name=extraction_result.primary_brand,
            email_content=email_content,
        )
        
        if brand_research and not brand_research.is_agency:
            print(
                f"[BRAND_RESEARCH] Found actual brand: {brand_research.brand_name} "
                f"(website: {brand_research.brand_website})"
            )
            research = brand_research
            brand_research_succeeded = True
    
    # Build result dict with only the fields we successfully found
    result = {}
    
    # CRITICAL FIX: Only set brand_website if we have the actual brand's website
    # Do NOT use the agency's website as the brand website
    if needs_website:
        if is_agency:
            # Only set brand_website if we successfully researched the actual brand
            if brand_research_succeeded and research.brand_website:
                result["brand_website"] = research.brand_website
                print(f"[BRAND_RESEARCH] Using brand website: {research.brand_website}")
            else:
                print(
                    f"[BRAND_RESEARCH] Agency detected but brand website not found. "
                    f"Leaving brand_website empty (agency website: {agency_website})"
                )
        elif research.brand_website:
            # Not an agency, use the researched website
            result["brand_website"] = research.brand_website
        
    if needs_category and research.brand_category:
        result["brand_category"] = research.brand_category
    
    # Also provide brand_name if we found a better one
    if not existing_brand_name and research.brand_name:
        result["brand_name"] = research.brand_name
    
    # Auto-detect contact_type based on agency detection
    # "Agency" if we detected agency signals, otherwise "Brand Direct"
    if is_agency:
        result["contact_type"] = "Agency"
    elif research.confidence >= 0.7:
        # Only set Brand Direct if we're confident about the research
        result["contact_type"] = "Brand Direct"
    
    # Store research metadata with agency info
    metadata = {
        "confidence": research.confidence,
        "description": research.brand_description,
        "notes": research.research_notes,
        "is_agency_email": is_agency,
        "agency_detected_by": agency_detected_by,
    }
    
    # Store agency website separately so it's visible in UI but not confused with brand
    if is_agency:
        metadata["agency_website"] = agency_website
        metadata["agency_name"] = (
            extraction_result.agency_name if extraction_result and extraction_result.agency_name
            else agency_name_from_research or "Unknown Agency"
        )
    
    # Include agency details if extracted
    if extraction_result:
        metadata["agency_detected"] = extraction_result.is_agency_email
        if extraction_result.agency_name:
            metadata["agency_name"] = extraction_result.agency_name
        metadata["extracted_brands"] = extraction_result.brand_names
        metadata["extraction_confidence"] = extraction_result.confidence
    
    result["_research_metadata"] = metadata
    
    print(
        f"[BRAND_RESEARCH] Filled fields: {list(k for k in result.keys() if not k.startswith('_'))}"
    )
    if is_agency:
        final_agency_name = metadata.get("agency_name", "unknown")
        print(
            f"[BRAND_RESEARCH] Note: Email from agency '{final_agency_name}' "
            f"(detected by: {agency_detected_by})"
        )
        if brand_to_research and brand_to_research != existing_brand_name:
            print(f"[BRAND_RESEARCH] Representing brand: {brand_to_research}")
    
    return result

