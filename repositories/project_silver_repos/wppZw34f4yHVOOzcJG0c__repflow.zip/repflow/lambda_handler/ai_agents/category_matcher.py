"""
AI-powered category matching agent.

Uses an LLM to determine if a detected brand category semantically matches
any of the creator's auto-reject categories. This is more robust than
text-based matching because it understands semantic relationships.

For example:
- "Gaming" matches "Video Games" ✓
- "Crypto" matches "Blockchain/NFTs" ✓  
- "Fashion" does NOT match "Video Games" ✗
"""

from typing import List, Optional, Dict

from agents import Agent, Runner, AgentOutputSchema
from pydantic import BaseModel, Field


class CategoryMatchResult(BaseModel):
    """Response from the Category Matching Agent."""
    
    matches: bool = Field(
        ...,
        description="True if the brand category semantically matches ANY of the reject categories"
    )
    matched_category: Optional[str] = Field(
        None,
        description="The specific reject category that matched, if any"
    )
    confidence: float = Field(
        ...,
        description="Confidence score from 0.0 to 1.0"
    )
    reasoning: str = Field(
        ...,
        description="Brief explanation of why the categories do or don't match"
    )


category_matching_agent = Agent(
    name="Category Matching Agent",
    instructions="""
You are a Category Matching Agent that determines if a brand's category semantically matches any categories that a content creator wants to reject.

Your job is to analyze:
1. The brand's detected category (e.g., "Gaming", "Technology", "Fashion")  
2. A list of categories the creator wants to auto-reject

You must determine if the brand category is semantically equivalent to, a subset of, or closely related to ANY of the reject categories.

MATCHING RULES:
- Match if the brand category IS the reject category (exact match)
- Match singular/plural and minor wording (e.g. "dating app" matches "dating apps", "gambling" matches "gambling apps")
- Match if the brand category is a SUBSET of the reject category (e.g., "Mobile Gaming" is part of "Video Games")
- Match if the brand category is a SUPERSET that primarily contains the reject category (e.g., "Gaming & Entertainment" primarily involves "Video Games")
- Match if they are SYNONYMS or commonly used interchangeably (e.g., "Gaming" = "Video Games", "Crypto" = "Blockchain")
- Match if the brand would PRIMARILY be associated with the reject category in common usage

DO NOT MATCH if:
- The categories are completely unrelated
- The overlap is only tangential or minimal
- The association is a stretch or requires assumptions

Examples of matches:
- "Gaming" matches "Video Games" (synonyms)
- "Esports" matches "Video Games" (subset)
- "Mobile Gaming" matches "Video Games" (subset)
- "Cryptocurrency" matches "Crypto/Blockchain/NFTs" (synonym)
- "NFT Marketplace" matches "Crypto/Blockchain/NFTs" (subset)
- "Diet Pills" matches "Nutritional Supplements" (related)
- "Online Casino" matches "Gambling" (subset)

Examples of NON-matches:
- "Technology" does NOT match "Video Games" (too broad, tech includes many non-gaming things)
- "Entertainment" does NOT match "Video Games" (too broad)
- "E-commerce" does NOT match "Crypto/Blockchain/NFTs" (unrelated)
- "Fitness" does NOT match "Nutritional Supplements" (related but distinct industries)

Be conservative - only match if you are confident the creator would consider this a match.
""",
    output_type=CategoryMatchResult,
    tools=[],
)


# In-memory cache for category match results
# Key: (brand_category, frozenset of reject_categories)
# Value: CategoryMatchResult
_category_cache: Dict[tuple, CategoryMatchResult] = {}


async def check_category_match(
    brand_category: str,
    reject_categories: List[str],
) -> CategoryMatchResult:
    """
    Use AI to determine if a brand category matches any reject categories.
    
    This function caches results to avoid repeated API calls for the same
    category combinations.
    
    Args:
        brand_category: The detected category for the brand (e.g., "Gaming")
        reject_categories: List of categories the creator wants to reject
        
    Returns:
        CategoryMatchResult with match status, matched category, confidence, and reasoning
    """
    # Early return if no reject categories
    if not reject_categories:
        return CategoryMatchResult(
            matches=False,
            matched_category=None,
            confidence=1.0,
            reasoning="No reject categories specified"
        )
    
    # Early return if no brand category
    if not brand_category or not brand_category.strip():
        return CategoryMatchResult(
            matches=False,
            matched_category=None,
            confidence=1.0,
            reasoning="No brand category to match"
        )
    
    # Check cache
    cache_key = (brand_category.lower().strip(), frozenset(c.lower() for c in reject_categories))
    if cache_key in _category_cache:
        cached = _category_cache[cache_key]
        print(f"[CATEGORY_MATCH] Cache hit: '{brand_category}' -> matches={cached.matches}")
        return cached
    
    # Run AI agent
    print(f"[CATEGORY_MATCH] Checking if '{brand_category}' matches any of: {reject_categories}")
    
    match_input = f"""
Determine if this brand category matches any of the creator's auto-reject categories.

BRAND CATEGORY: {brand_category}

CREATOR'S AUTO-REJECT CATEGORIES:
{chr(10).join(f"- {cat}" for cat in reject_categories)}

Does the brand category "{brand_category}" semantically match any of these reject categories?
If yes, specify which one it matches and explain why.
If no, explain why it doesn't match any of them.
"""
    
    try:
        result = await Runner.run(category_matching_agent, match_input)
        match_result = result.final_output_as(CategoryMatchResult)
        
        print(
            f"[CATEGORY_MATCH] Result: matches={match_result.matches} "
            f"matched='{match_result.matched_category or 'None'}' "
            f"confidence={match_result.confidence} "
            f"reason='{match_result.reasoning}'"
        )
        
        # Cache the result
        _category_cache[cache_key] = match_result
        
        return match_result
        
    except Exception as exc:
        print(f"[CATEGORY_MATCH] Error running agent: {exc}")
        # On error, return no match (fail open to avoid blocking legitimate leads)
        return CategoryMatchResult(
            matches=False,
            matched_category=None,
            confidence=0.0,
            reasoning=f"Error during matching: {str(exc)}"
        )


def clear_category_cache():
    """Clear the category matching cache. Useful for testing."""
    global _category_cache
    _category_cache = {}
    print("[CATEGORY_MATCH] Cache cleared")
