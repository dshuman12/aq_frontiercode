from __future__ import annotations

from typing import List

from agents import Agent, Runner, AgentOutputSchema
from pydantic import BaseModel, Field

from database.models.lead import LeadQualificationData
from database.models.user import User


class PreferenceEvaluationDraftResponse(BaseModel):
    """Expansive response from the Preference Evaluation Agent."""

    recommendation: str = Field(
        ...,
        description="CONTINUE, NEGOTIATE, REJECT",
    )
    communication_tone: str = Field(
        default="professional",
        description="Recommended tone: professional, warm, firm, etc.",
    )
    key_messages: List[str] = Field(
        default=[], description="Key messages to convey in response"
    )
    draft_response: str = Field(
        ..., description="Complete draft response based on recommendation"
    )


comprehensive_preference_agent = Agent(
    name="Comprehensive Preference Evaluation Agent",
    instructions="""
You are an Advanced Creator Preference Evaluation and Response Strategy Agent.
Your job is to comprehensively evaluate leads, determine action plans, and draft appropriate responses.

You receive:
1) Complete lead information (all extracted fields)
2) Creator preferences (minimum rates, categories, partnership types)
3) Creator's platform focus and audience
4) Conversation history

Your responsibilities:
A) EVALUATE the lead against creator preferences
B) DETERMINE the appropriate action (CONTINUE/NEGOTIATE/REJECT  )
C) DRAFT a complete response based on your recommendation
D) PROVIDE comprehensive analysis and strategy

EVALUATION CRITERIA:
- Budget meets minimum requirements
- Category aligns with creator's brand
- Partnership type is acceptable
- Deliverables match creator's capabilities
- Timeline is feasible

Comprehensively evaluate this lead, determine the appropriate action, and draft a complete response. Your response should be in the following format:
{
  "recommendation": "<CONTINUE | NEGOTIATE | REJECT>",
  "draft_response": "<response text>"
}

Rules:
- If more information is needed, set recommendation to CONTINUE
- If the lead matches most preferences, and the fields not matching are not the auto-reject categories, set recommendation to NEGOTIATE
- If the lead matches most preferences, and the fields not matching are the auto-reject categories, set recommendation to REJECT
- If negotiation has been attempted but failed, set recommendation to REJECT

MISSING INFORMATION HANDLING:
If any information is missing, set recommendation to CONTINUE and identify:
- What specific information is needed
- Why it's important for evaluation
- How to ask for it professionally

RESPONSE DRAFTING GUIDELINES:
- Match tone to recommendation (warm for CONTINUE, firm for NEGOTIATE, polite for REJECT)
- Be specific about what you need (for REQUEST_MORE_INFO)
- Include creator's value proposition when negotiating
- Keep professional but approachable
- Include relevant creator stats/portfolio when beneficial
- Address specific concerns or highlight opportunities
- Set clear expectations for next steps

BUSINESS INTELLIGENCE:
- Assess market value of the opportunity
- Identify strategic benefits beyond payment
- Flag potential risks or red flags
- Consider long-term relationship value

Rules:
- Be thorough in evaluation - consider all aspects
- Provide actionable insights and specific recommendations
- Draft responses that sound like a professional talent agent
- Include creator's portfolio/stats when relevant
- Be honest about fit but maintain professionalism
- Consider creator's growth stage and goals
- Maximum 125 words for draft responses
- Do not include an email signature in draft responses

Output comprehensive JSON with all analysis, recommendations, and draft response.
""",
    output_type=PreferenceEvaluationDraftResponse,
    tools=[],
)


async def run_preference_evaluation(
    lead: LeadQualificationData, user: User, conversation_history: str
) -> PreferenceEvaluationDraftResponse:
    """Execute the preference evaluation agent."""
    creator_name = user.profile.name or "our creator"
    prefs = user.preferences

    platform_context = ""
    if getattr(user, "platforms", None):
        active_platforms = [
            platform.platformType.value.title()
            for platform in user.platforms[:3]
            if platform.isActive
        ]
        if active_platforms:
            platform_context = f"Primary Platforms: {', '.join(active_platforms)}"

    preference_input = f"""
COMPREHENSIVE LEAD INFORMATION:
{lead.model_dump_json(indent=2)}

MISSING FIELDS:
{", ".join(lead.get_missing_fields())}

CREATOR PREFERENCES:
- Name: {creator_name}
- Minimum Rate: ${prefs.absoluteMinimumRate}
- Auto-Reject Categories: {", ".join(prefs.autoRejectCategories)}
- Partnership Types: Flat Rate: {prefs.partnershipTypes.flatRate}, Affiliate: {prefs.partnershipTypes.affiliate}, Performance Hybrid: {prefs.partnershipTypes.performanceHybrid}
- {platform_context}

CONVERSATION HISTORY:
{conversation_history}
"""
    preference_result = await Runner.run(
        comprehensive_preference_agent, preference_input
    )
    return preference_result.final_output_as(PreferenceEvaluationDraftResponse)
