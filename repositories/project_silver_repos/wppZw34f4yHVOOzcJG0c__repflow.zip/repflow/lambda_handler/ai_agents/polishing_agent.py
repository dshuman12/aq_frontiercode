from typing import Optional

from agents import Agent, Runner, AgentOutputSchema
from pydantic import BaseModel, Field


class QAPolisherResponse(BaseModel):
    """Response from the QA/Talent Agent Polisher."""

    polished_reply: str = Field(
        ..., description="Final polished email text under 125 words"
    )
    should_send: bool = Field(
        default=True, description="Whether the email should be sent"
    )


qa_polisher_agent = Agent(
    name="QA Polisher Agent",
    instructions="""
You are a Quality Assurance Agent specializing in sponsorship negotiations.
Your job: polish draft emails so they read as if sent by a top-tier digital talent agent representing the creator.

Rules:
- Maintain professionalism, warmth, and confidence.
- Avoid jargon, filler, or desperate tone.
- Keep the word count of the email draft under 125 words
- Structure emails clearly: greeting → concise value → clear ask/next step.
- Emphasize the creator's professionalism, past sponsor success, and readiness to deliver.
- If countering, anchor confidently with the creator's rate and highlight ROI.
- Do not include any signature or sign-off in your response.
- If there is a signature in the draft response, remove it.

Output the final polished email text only.
""",
    output_type=QAPolisherResponse,
    tools=[],
)


async def polish_response(
    draft: str, context: Optional[str] = None, tone: str = "professional"
) -> QAPolisherResponse:
    """Polish a draft response using the QA agent."""
    print(
        "[QA_POLISHER] invoked "
        f"tone={tone} "
        f"context_provided={'yes' if context else 'no'} "
        f"draft_len={len(draft)}"
    )
    polisher_input = f"""
DRAFT RESPONSE TO POLISH:
{draft}

CONTEXT: 
- Recommendation: {context or 'CONTINUE'}
- Tone: {tone}
"""
    polisher_result = await Runner.run(qa_polisher_agent, polisher_input)
    response = polisher_result.final_output_as(QAPolisherResponse)
    print(
        "[QA_POLISHER] success "
        f"should_send={response.should_send} "
        f"result_len={len(response.polished_reply)}"
    )
    return response
