from typing import Optional, List
from pydantic import BaseModel, Field, EmailStr
from datetime import datetime, timezone

from agents import Agent, Runner, AgentOutputSchema

from database.models.lead import LeadQualificationData, DeliverableContent
from fsm.context import FSMContext


class DealParserResponse(BaseModel):
    """Response from the Deal Parser Agent."""

    brand_name: Optional[str] = Field(None, description="Brand/company name")
    brand_website: Optional[str] = Field(None, description="Company website URL")
    brand_category: Optional[str] = Field(
        None, description="Brand category or industry"
    )
    budget: Optional[str] = Field(None, description="Budget/compensation offered")
    deliverables: Optional[List[DeliverableContent]] = Field(
        None,
        description="List of deliverables for the deal. ContentType is the platform (youtube, tiktok, video, podcast, instagram, twitter) and text is the description of the deliverable.",
    )
    deal_type: Optional[str] = Field(
        None,
        description="Deal structure (e.g., one-time sponsorship, flat fee, affiliate, rev share, gifting, hybrid, ongoing)",
    )
    deadline: Optional[str] = Field(
        None,
        description="Project due date in the format of YYYY-MM-DD",
    )
    brand_contact_name: Optional[str] = Field(None, description="Primary contact name")
    brand_contact_email: Optional[EmailStr] = Field(
        None, description="Primary contact email"
    )
    contact_type: Optional[str] = Field(
        None,
        description="Whether the contact is from a Brand Direct or an Agency/PR/Marketing company",
    )
    contact_title: Optional[str] = Field(
        None,
        description="Contact's job title extracted from signature or email content (Marketing Manager, Brand Manager, Founder, PR Director, etc.)",
    )
    brand_comment: Optional[str] = Field(
        None, description="Additional context or notes"
    )


deal_parser_agent = Agent(
    name="Deal Parser Agent",
    instructions="""
You are an Email Deal Parser focused on extracting essential information for deal creation.
You receive:
1) A conversation history (multiple emails in a thread)
2) Existing lead information from previous emails (if any)
3) Current email content

Your job is to extract and UPDATE essential deal information needed to create a Deal record.

Extract/update these ESSENTIAL fields when available:

COMPANY INFORMATION:
- brand_name: Brand/company name (required for deal creation)
- brand_website: Company website URL
- brand_category: Brand category or industry

FINANCIAL TERMS:
- budget: Budget/compensation offered (flat fee, affiliate %, hybrid terms, gifting value)

DELIVERABLES:
- deliverables: List of deliverables for the deal. Use ONE entry per platform line so the deal card can show each line with its platform icon. ContentType = platform (youtube, tiktok, video, podcast, instagram, twitter). Text = that platform's description (e.g. "2x 60 sec Integrations", "1x Story Post w/ Link"). Example: two lines "2x YouTube integrations, 1x Instagram story" -> [{ contentType: "youtube", text: "2x 60 sec Integrations" }, { contentType: "instagram", text: "1x Story Post w/ Link" }].

TIMELINE:
- deadline: Project due date in the format of YYYY-MM-DD
DEAL STRUCTURE:
- deal_type: Deal structure (one-time sponsorship, flat fee, affiliate/rev share, gifting, hybrid, ongoing, or similar phrasing)

CONTACT INFORMATION:
- brand_contact_name: Primary contact name (from signature, sender, or signoff)
- brand_contact_email: Primary contact email (from metadata or signature)  
- contact_type: Whether email is from "Brand Direct" (the brand itself) or "Agency" (a PR/marketing/talent agency representing a brand). Look for agency signals like "on behalf of", "our client", agency-sounding email domains.
- contact_title: Contact's job title/role (Marketing Manager, Brand Manager, Founder, PR Director, Account Executive, CEO, etc.). ALWAYS try to extract this from the email signature block or introduction. Common patterns:
  * "John Smith, Marketing Manager" or "Jane Doe | Brand Director"
  * Title under name in signature
  * Introduction like "I'm the Marketing Lead at..."

ADDITIONAL CONTEXT:
- brand_comment: Any additional context, campaign goals, special requirements, or notes that would be useful for deal management

Rules:
- MERGE new information with existing data - don't overwrite good data with null
- Only update fields when you find NEW or BETTER information
- If existing data conflicts with new data, prefer the more recent/specific information
- Do not invent details; only extract what exists in the conversation
- Normalize to clean values (remove filler words, standardize formats)
- For deadline: Capture the essential timing info concisely. If the original mentions deliverables with dates (like "2 posts in January"), preserve that context. Always include the year when a month/date is mentioned.
- If unknown or unchanged, set null (existing data will be preserved)
- Focus on information that directly helps create and manage the deal
- Be concise but thorough - capture the essential business details
- For contact_title: CAREFULLY examine email signatures, which often contain job titles beneath the name
- For contact_type: Default to "Brand Direct" unless there are clear agency signals

Output JSON with only the essential fields needed for deal creation.
""",
    output_type=DealParserResponse,
    tools=[],
)


def _concise_deadline(value: Optional[str]) -> Optional[str]:
    """Ensure deadline string is concise and clean."""
    if value is None:
        return None

    # Just clean up whitespace - the AI should already produce concise strings
    text = value.strip()
    if not text:
        return None

    return text


def _normalize_deal_type(value: Optional[str]) -> Optional[str]:
    """Map free-form deal type text to the limited allowed set; drop if unknown."""
    if not value:
        return None
    normalized = value.strip().lower()
    candidates = {
        "flat rate": "Flat Rate",
        "flat": "Flat Rate",
        "one time": "Flat Rate",
        "one-time": "Flat Rate",
        "one-time sponsorship": "Flat Rate",
        "one-time deal": "Flat Rate",
        "one time sponsorship": "Flat Rate",
        "sponsorship": "Sponsored Post",
        "sponsored post": "Sponsored Post",
        "sponsored": "Sponsored Post",
        "ugc": "UGC",
        "user generated content": "UGC",
        "affiliate": "Affiliate",
        "rev share": "Revenue Share",
        "revenue share": "Revenue Share",
        "brand partnership": "Brand Partnership",
        "partnership": "Brand Partnership",
    }

    for key, mapped in candidates.items():
        if key in normalized:
            return mapped
    return None


async def run_deal_parser(
    conversation_history: str, existing_lead: Optional[LeadQualificationData] = None
) -> DealParserResponse:
    """Execute parsing agent and merge with existing lead info."""
    print("[DEAL_PARSER] invoked " f"existing_lead={'yes' if existing_lead else 'no'}")
    existing_lead_context = (
        existing_lead.model_dump()
        if existing_lead
        else "None (new conversation; fill from scratch)"
    )

    parser_input = f"""
TODAY (for resolving relative dates):
{datetime.now(timezone.utc).date().isoformat()}

EXISTING LEAD INFORMATION, ANY FIELD THAT IS RELATED TO LEAD QUALIFICATION AND IS NULL IS UNKNOWN:
{existing_lead_context}

CONVERSATION HISTORY:
{conversation_history}

Extract and update comprehensive structured deal information from this sponsorship opportunity conversation.
Build upon existing information and extract ALL possible fields mentioned or implied.
"""
    parser_result = await Runner.run(deal_parser_agent, parser_input)
    parsed = parser_result.final_output_as(DealParserResponse)
    parsed.deadline = _concise_deadline(parsed.deadline)
    parsed.deal_type = _normalize_deal_type(parsed.deal_type)
    print(
        "[DEAL_PARSER] success "
        f"brand={parsed.brand_name or '-'} "
        f"budget={parsed.budget or '-'} "
        f"deadline={parsed.deadline or '-'}"
    )
    return parsed


def merge_lead_data(
    existing_lead: LeadQualificationData, parsed_lead: DealParserResponse
) -> LeadQualificationData:
    merged = existing_lead.model_dump()
    parsed_data = parsed_lead.model_dump()
    for field, value in parsed_data.items():
        if value not in (None, "", [], {}):
            merged[field] = value
    return LeadQualificationData.model_validate(merged)


async def parse_lead_update(context: FSMContext) -> LeadQualificationData:
    """Parse latest email into the FSM context lead.

    This function:
    1. Runs the deal parser to extract structured info from the conversation
    2. Merges parsed info with existing lead data
    3. If brand_category or brand_website is still missing, runs web research
       using the sender's email domain to fill in the gaps
    """
    parsed = await run_deal_parser(context.conversation_history, context.lead)
    context.lead = merge_lead_data(context.lead, parsed)
    print(
        "[DEAL_PARSER] merged lead "
        f"brand={context.lead.brand_name or '-'} "
        f"budget={context.lead.budget or '-'} "
        f"deadline={context.lead.deadline or '-'}"
    )

    # Check if we need to research brand info
    needs_research = not context.lead.brand_category or not context.lead.brand_website

    if needs_research:
        print(
            "[DEAL_PARSER] Brand info incomplete, initiating web research... "
            f"category={context.lead.brand_category or 'MISSING'} "
            f"website={context.lead.brand_website or 'MISSING'}"
        )

        try:
            # Import here to avoid circular imports
            from .research_agent import research_and_fill_missing_fields

            # Get the email content and subject from context if available
            email_content = None
            email_subject = None
            if context.current_email:
                email_content = context.current_email.get("content", "")
                email_subject = context.current_email.get("subject", "")

            # Research using the lead's email (with agency detection)
            research_results = await research_and_fill_missing_fields(
                email=context.lead.email,
                existing_brand_name=context.lead.brand_name,
                existing_brand_website=context.lead.brand_website,
                existing_brand_category=context.lead.brand_category,
                email_content=email_content,
                email_subject=email_subject,
            )

            # Apply researched fields to the lead
            if research_results:
                for field, value in research_results.items():
                    if field.startswith("_"):
                        # Store metadata separately
                        if field == "_research_metadata":
                            context.state_metadata["brand_research"] = value
                        continue
                    if value and not getattr(context.lead, field, None):
                        setattr(context.lead, field, value)
                        print(f"[DEAL_PARSER] Applied researched {field}={value}")

        except Exception as e:
            # Research is best-effort; don't fail the parsing if it errors
            print(f"[DEAL_PARSER] Brand research failed (non-fatal): {e}")

    print(
        "[DEAL_PARSER] final lead "
        f"brand={context.lead.brand_name or '-'} "
        f"category={context.lead.brand_category or '-'} "
        f"website={context.lead.brand_website or '-'}"
    )
    return context.lead
