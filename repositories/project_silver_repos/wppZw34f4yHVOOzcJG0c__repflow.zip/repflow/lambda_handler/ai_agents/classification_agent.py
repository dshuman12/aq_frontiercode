from typing import Optional

from agents import Agent, Runner, AgentOutputSchema
from pydantic import BaseModel, Field


class DealFilterResponse(BaseModel):
    """Response from the Deal Filter Agent."""

    classification: str = Field(
        ..., description="Sponsorship | Non-Sponsorship | Other"
    )
    subcategory: str = Field(
        ...,
        description="Specific subcategory like flat, affiliate, hybrid, gifting, ugc, event, press, recruiting, spam, etc.",
    )
    confidence: float = Field(
        ..., description="Confidence score for the classification (0-1)"
    )


deal_filter_agent = Agent(
    name="Deal Filter Agent",
    instructions="""
You are an Email Deal Filter for a content creator's inbox.
Your job is to classify each email into one of three categories:

1. Sponsorship / Revenue Opportunity
   - Paid Sponsorship (flat rate)
   - Affiliate Offer
   - Performance / Hybrid (MG + performance, CPA, CPC, CPM)
   - Product Seeding / Gifting
   - UGC / Freelance Content Request (content for brand-owned channels)

2. Non-Sponsorship / Business
   - Events/Press invites, equity partnerships, collaboration with another creator, casting/appearance request, speaking opportunities

3. Other (ignore)
   - Fan mail, donations, platform notices, agencies recruiting, feedback, spam, newsletters, cold irrelevant outreach, system alerts, job offers, recruiting.

Rules:
- If any budget/payment language is present, prefer category (1).
- If the prospect asks for the creator's rate, preferred rate, budget, or pricing for a partnership/collaboration, classify as Sponsorship (subcategory flat or custom) with high confidence.
- If gifting/product only, choose sponsorship → Gifting.
- If multiple apply, pick the highest ID category in Sponsorship (flat > affiliate > hybrid > gifting > ugc).
- If no clear business opportunity, classify as Other.

Output JSON only:
{
  "classification": "<Sponsorship | Non-Sponsorship | Other>",
  "subcategory": "<flat | affiliate | hybrid | gifting | ugc | event | press | recruiting | spam | etc.>",
  "confidence": <0..1>
}
""",
    output_type=DealFilterResponse,
    tools=[],
)


async def run_deal_filter(conversation_history: str, max_retries: int = 2) -> DealFilterResponse:
    """Execute the classification agent with lightweight retry handling."""
    attempt = 0
    last_error: Optional[Exception] = None
    while attempt <= max_retries:
        try:
            print(f"[DEAL_FILTER] attempt={attempt + 1}/{max_retries + 1}")
            filter_input = f"""
CONVERSATION HISTORY:
{conversation_history}

Classify this email conversation into one of the three categories and provide the appropriate subcategory.
"""
            result = await Runner.run(deal_filter_agent, filter_input)
            try:
                parsed = result.final_output_as(DealFilterResponse)
                print(
                    "[DEAL_FILTER] success "
                    f"classification={parsed.classification} "
                    f"subcategory={parsed.subcategory} "
                    f"confidence={parsed.confidence}"
                )
                return parsed
            except Exception as parse_exc:
                print(
                    "[DEAL_FILTER] parse_error "
                    f"error={parse_exc} "
                    f"raw_result={repr(result)}"
                )
                raise
        except Exception as exc:  # pragma: no cover - guarded by retries
            print(f"[DEAL_FILTER] error attempt={attempt + 1} error={exc}")
            if "api_key" in str(exc).lower() or "apikey" in str(exc).lower():
                print("CRITICAL: OpenAI API Key might be missing or invalid. Check OPENAI_API_KEY env var.")
            last_error = exc
            attempt += 1
            if attempt > max_retries:
                raise
    # If loop exits without return, raise last error
    if last_error:
        raise last_error
    raise RuntimeError("Classification agent failed without raising an error")
