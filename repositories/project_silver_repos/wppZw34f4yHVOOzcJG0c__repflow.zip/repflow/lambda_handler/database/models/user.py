from .common import CRUDDocument
from beanie.odm.fields import PydanticObjectId
from pydantic import BaseModel, Field, EmailStr, HttpUrl, ConfigDict
from typing import List, Optional, Dict, Any
from datetime import datetime
from enum import Enum
import uuid


class PartnershipType(str, Enum):
    FLAT_RATE = "flat_rate"
    PERFORMANCE_HYBRID = "performance_hybrid"
    AFFILIATE = "affiliate"
    CUSTOM = "custom"


class RateType(str, Enum):
    CPM = "CPM"  # Cost Per Mille (per 1000 views)
    CVV = "CVV"  # Cost Per View
    FLAT = "FLAT"  # Flat rate
    PERCENTAGE = "PERCENTAGE"  # Percentage of sales


class PricingTier(str, Enum):
    LOW_TIER = "low_tier"
    PREMIUM_TIER = "premium_tier"
    ULTRA_PREMIUM = "ultra_premium"


class DeliverableType(str, Enum):
    PRE_MID_ROLL_AD = "Pre/Mid-Roll Ad"
    STREAM_SPONSORSHIP = "Stream Sponsorship"
    YOUTUBE_VIDEO = "YouTube Video"
    INSTAGRAM_POST = "Instagram Post"
    TIKTOK_VIDEO = "TikTok Video"
    PODCAST_EPISODE = "Podcast Episode"
    BLOG_POST = "Blog Post"
    TWITTER_THREAD = "Twitter Thread"
    CUSTOM = "Custom"


class Deliverable(BaseModel):
    id: int
    account: str = Field(..., description="Social media account handle")
    deliverableType: DeliverableType
    tier: PricingTier
    rate: float = Field(..., description="Rate amount")
    rateType: RateType
    lockRate: bool = Field(default=False, description="Whether rate is locked")
    price: float = Field(..., description="Final price in USD")
    createdAt: datetime = Field(default_factory=datetime.utcnow)
    updatedAt: datetime = Field(default_factory=datetime.utcnow)


class PartnershipPreferences(BaseModel):
    flatRate: bool = Field(default=True, description="Accept flat rate deals")
    performanceHybrid: bool = Field(
        default=False, description="Accept performance/hybrid deals"
    )
    affiliate: bool = Field(default=True, description="Accept affiliate deals")
    custom: bool = Field(default=False, description="Accept custom deal structures")


class NegotiationPreferences(BaseModel):
    bundleDeals: bool = Field(default=True, description="Enable bundle deals")
    crossPostingUpsell: bool = Field(
        default=False, description="Enable cross-posting upsell"
    )
    rushProposalFee: bool = Field(default=True, description="Enable rush proposal fees")
    minimumDaysWithoutRushFee: int = Field(
        default=5, description="Minimum days before rush fee applies"
    )


class PricingTierConfig(BaseModel):
    enabled: bool = Field(default=True, description="Whether this tier is enabled")
    categories: List[str] = Field(
        default_factory=list, description="Categories that fall under this tier"
    )


class PricingTiers(BaseModel):
    lowTier: PricingTierConfig = Field(
        default_factory=lambda: PricingTierConfig(
            enabled=True, categories=["Local Businesses"]
        )
    )
    premiumTier: PricingTierConfig = Field(
        default_factory=lambda: PricingTierConfig(
            enabled=True, categories=["Tech Companies"]
        )
    )
    ultraPremium: PricingTierConfig = Field(
        default_factory=lambda: PricingTierConfig(enabled=False, categories=[])
    )


class SocialLinks(BaseModel):
    instagram: Optional[HttpUrl] = None
    youtube: Optional[HttpUrl] = None
    tiktok: Optional[HttpUrl] = None
    twitter: Optional[HttpUrl] = None
    linkedin: Optional[HttpUrl] = None
    facebook: Optional[HttpUrl] = None


class Subscription(BaseModel):
    tier: str = Field(default="Growth", description="Subscription tier name")
    status: str = Field(default="active", description="Subscription status")
    currentPeriodEnd: datetime = Field(..., description="When current period ends")


class BillingAddress(BaseModel):
    line1: str
    line2: Optional[str] = None
    city: str
    state: str
    postalCode: str
    country: str = Field(default="United States")


class BillingInfo(BaseModel):
    cardLast4: str
    cardBrand: str
    nextBillingDate: datetime
    billingEmail: EmailStr
    billingAddress: BillingAddress


class ReferralHistory(BaseModel):
    id: str
    referredUserName: str
    status: str = Field(..., description="Status: completed, pending, etc.")
    revenue: float
    date: datetime


class ReferralData(BaseModel):
    referralCode: str
    referralLink: HttpUrl
    totalReferrals: int = Field(default=0)
    totalRevenue: float = Field(default=0.0)
    pendingPayouts: float = Field(default=0.0)
    referralHistory: List[ReferralHistory] = Field(default_factory=list)


class TeamMember(BaseModel):
    id: str
    name: str
    email: EmailStr
    avatar: Optional[str] = None
    role: str
    status: str = Field(
        default="active", description="Status: active, pending, inactive"
    )
    invitedAt: datetime
    lastActive: Optional[datetime] = Field(default=None)


class UserPreferences(BaseModel):
    # Partnership and negotiation preferences
    partnershipTypes: PartnershipPreferences = Field(
        default_factory=PartnershipPreferences
    )
    negotiationOptions: NegotiationPreferences = Field(
        default_factory=NegotiationPreferences
    )

    # Pricing and deliverables
    absoluteMinimumRate: float = Field(
        default=1000.0, description="Lowest acceptable rate in USD"
    )
    deliverables: List[Deliverable] = Field(default_factory=list)
    pricingTiers: PricingTiers = Field(default_factory=PricingTiers)

    # Auto-reject settings
    autoRejectCategories: List[str] = Field(
        default_factory=lambda: [
            "Nutritional Supplements",
            "Crypto/Blockchain/NFTs",
            "Video Games",
        ],
        description="Industries to automatically reject",
    )

    # Additional preferences
    preferredContactMethod: str = Field(
        default="email", description="Preferred contact method"
    )
    responseTimeHours: int = Field(
        default=24, description="Expected response time in hours"
    )
    timezone: str = Field(default="America/New_York", description="User's timezone")
    language: str = Field(default="en", description="Preferred language")

    # Notification preferences
    emailNotifications: bool = Field(default=True)
    pushNotifications: bool = Field(default=True)
    dealAlerts: bool = Field(default=True)
    weeklyReports: bool = Field(default=True)


class UserProfile(BaseModel):
    id: str
    name: str
    email: EmailStr
    repflow_username: str
    avatar: Optional[str] = None
    bio: Optional[str] = None
    tags: Optional[List[str]] = None
    location: Optional[str] = None
    website: Optional[HttpUrl] = None
    socialLinks: SocialLinks = Field(default_factory=SocialLinks)
    bookingLink: Optional[HttpUrl] = Field(default=None)
    subscription: Subscription
    createdAt: datetime = Field(default_factory=datetime.utcnow)
    updatedAt: datetime = Field(default_factory=datetime.utcnow)


class PlatformType(str, Enum):
    YOUTUBE = "youtube"
    INSTAGRAM = "instagram"
    TIKTOK = "tiktok"
    TWITTER = "twitter"
    LINKEDIN = "linkedin"
    FACEBOOK = "facebook"
    TWITCH = "twitch"
    PODCAST = "podcast"
    BLOG = "blog"
    WEBSITE = "website"
    OTHER = "other"


class PlatformMetrics(BaseModel):
    """Platform performance metrics"""

    subscribers: Optional[str] = Field(
        default=None, description="Number of subscribers/followers"
    )
    avgVideoViews: Optional[str] = Field(default=None, description="Average video views")
    avgShortViews: Optional[str] = Field(
        default=None, description="Average short-form content views"
    )
    engagementRate: Optional[str] = Field(
        default=None, description="Engagement rate percentage"
    )
    totalViews: Optional[str] = Field(
        default=None, description="Total views across all content"
    )
    avgLikes: Optional[str] = Field(default=None, description="Average likes per post")
    avgComments: Optional[str] = Field(default=None, description="Average comments per post")
    avgShares: Optional[str] = Field(default=None, description="Average shares per post")
    monthlyReach: Optional[str] = Field(default=None, description="Monthly reach/impressions")
    demographics: Optional[Dict[str, Any]] = Field(
        default_factory=dict, description="Audience demographics"
    )

    model_config = ConfigDict()


class Platform(BaseModel):
    """Social media platform information for a user"""

    name: str = Field(..., description="Platform name (e.g., 'Sarah Tech Reviews')")
    handle: str = Field(
        ..., description="Platform handle/URL (e.g., 'youtube.com/sarahtechreviews')"
    )
    platformType: PlatformType = Field(..., description="Type of platform")
    icon: Optional[str] = Field(
        None, description="Icon name or component (e.g., 'Youtube')"
    )
    verified: bool = Field(default=False, description="Whether the account is verified")
    color: Optional[str] = Field(
        None, description="Theme color for the platform (e.g., 'text-red-500')"
    )
    metrics: PlatformMetrics = Field(
        default_factory=lambda: PlatformMetrics(), description="Platform performance metrics"
    )
    isActive: bool = Field(
        default=True, description="Whether this platform is currently active"
    )
    connectedAt: datetime = Field(
        default_factory=datetime.utcnow, description="When the platform was connected"
    )
    lastUpdated: datetime = Field(
        default_factory=datetime.utcnow, description="When metrics were last updated"
    )
    customFields: Dict[str, Any] = Field(
        default_factory=dict, description="Platform-specific custom fields"
    )

    model_config = {"json_encoders": {datetime: lambda v: v.isoformat()}}


class User(CRUDDocument):
    id: Optional[PydanticObjectId] = Field(
        default=None, description="MongoDB document ObjectID"
    )
    uuid: str = Field(default_factory=lambda: str(uuid.uuid4()), description="Unique user identifier")
    profile: UserProfile
    preferences: UserPreferences = Field(default_factory=UserPreferences)
    platforms: List[Platform] = Field(
        default_factory=list, description="User's social media platforms"
    )
    billingInfo: Optional[BillingInfo] = Field(default=None)
    referralData: Optional[ReferralData] = Field(default=None)
    teamMembers: List[TeamMember] = Field(default_factory=list)

    # Authentication and security
    isActive: bool = Field(default=True)
    isVerified: bool = Field(default=False)
    lastLogin: Optional[datetime] = Field(default=None)

    # Timestamps
    createdAt: datetime = Field(default_factory=datetime.utcnow)
    updatedAt: datetime = Field(default_factory=datetime.utcnow)

    model_config = ConfigDict(
        populate_by_name=True
    )
