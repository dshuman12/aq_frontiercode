import datetime
from typing import Optional
from beanie.odm.fields import PydanticObjectId
from pydantic import Field, computed_field, model_validator, BaseModel, ConfigDict
import uuid


class CRUDDocument(BaseModel):
    id: Optional[str] = Field(
        default=None,
        description="MongoDB document ObjectID",
    )
    uuid: str = Field(default_factory=lambda: str(uuid.uuid4()))

    @model_validator(mode="before")
    def validate_id(cls, data):
        if isinstance(data, dict):
            if "mongo_id" in data:
                data["id"] = str(data["mongo_id"])
                del data["mongo_id"]

            if "id" in data and isinstance(data["id"], PydanticObjectId):
                data["id"] = str(data["id"])
        return data

    class Settings:
        indexes = ["uuid"]

    model_config = ConfigDict(
        json_encoders={
            datetime: lambda v: v.replace(microsecond=0).isoformat(),
            datetime.date: lambda v: v.isoformat(),
            PydanticObjectId: str,
        },
    )
