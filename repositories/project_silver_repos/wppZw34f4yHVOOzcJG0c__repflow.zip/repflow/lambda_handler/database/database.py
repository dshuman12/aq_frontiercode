import os
from typing import Optional
from beanie import init_beanie
from .models.deal import Deal
from .models.user import User
from .models.message import Message, Conversation
from .models.lead import LeadQualificationData, ProcessedEmail, BlacklistedEmail
from pymongo import AsyncMongoClient


class Database:
    client: Optional[AsyncMongoClient] = None
    database_name: Optional[str] = None

    async def connect_to_mongo(self):
        """Create database connection."""
        # Get MongoDB connection string from environment variable
        mongo_url = os.getenv("MONGODB_URL", "mongodb://localhost:27017")
        self.database_name = os.getenv("MONGODB_DATABASE", "repflow")

        # Create motor client
        print("Connecting to MongoDB", mongo_url)
        self.client = AsyncMongoClient(mongo_url)

        # Initialize Beanie with the document models
        if self.client is None:
            raise Exception("Database client is not initialized")

        await init_beanie(
            database=self.client[self.database_name],
            document_models=[
                Deal,
                User,
                Message,
                Conversation,
                LeadQualificationData,
                ProcessedEmail,
                BlacklistedEmail,
            ],
        )

        print(f"Connected to MongoDB database: {self.database_name}")

    async def close_mongo_connection(self):
        """Close database connection."""
        if self.client:
            await self.client.close()
            print("MongoDB connection closed.")


# Create a global database instance
db = Database()


async def get_database() -> Database:
    """Get database instance."""
    return db


async def get_deals_collection():
    """Get the deals collection."""
    return Deal


# Initialize database connection on startup
async def init_database():
    """Initialize database connection."""
    await db.connect_to_mongo()


# Close database connection on shutdown
async def close_database():
    """Close database connection."""
    await db.close_mongo_connection()
