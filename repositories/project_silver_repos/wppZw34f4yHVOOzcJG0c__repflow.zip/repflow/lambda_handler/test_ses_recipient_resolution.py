"""Unit tests for resolve_inbound_recipient_email (multi-recipient SES)."""

from lambda_function import resolve_inbound_recipient_email


def test_destination_wins_when_to_header_has_gmail_first():
    mail = {
        "destination": ["loki@repflow.me"],
        "commonHeaders": {
            "to": [
                "lokivkp@gmail.com",
                "loki@repflow.me",
            ],
        },
    }
    got = resolve_inbound_recipient_email(mail, "repflow.me")
    assert got == "loki@repflow.me"


def test_to_header_scan_when_destination_empty():
    mail = {
        "destination": [],
        "commonHeaders": {
            "to": [
                "lokivkp@gmail.com",
                "Loki Agent <loki@repflow.me>",
            ],
        },
    }
    got = resolve_inbound_recipient_email(mail, "repflow.me")
    assert got == "loki@repflow.me"


def test_single_to_recipient_unchanged():
    mail = {
        "commonHeaders": {
            "to": ["solo@repflow.me"],
        },
    }
    got = resolve_inbound_recipient_email(mail, "repflow.me")
    assert got == "solo@repflow.me"


def test_non_matching_to_falls_back_to_first_address():
    mail = {
        "commonHeaders": {
            "to": ["only@gmail.com"],
        },
    }
    got = resolve_inbound_recipient_email(mail, "repflow.me")
    assert got == "only@gmail.com"


def test_normalize_domain_strips_at_prefix():
    mail = {
        "destination": ["u@repflow.me"],
        "commonHeaders": {"to": ["other@gmail.com"]},
    }
    got = resolve_inbound_recipient_email(mail, "@repflow.me")
    assert got == "u@repflow.me"


def test_multiple_destination_same_domain_picks_sorted_first(capsys):
    mail = {
        "destination": ["zebra@repflow.me", "alpha@repflow.me"],
        "commonHeaders": {"to": []},
    }
    got = resolve_inbound_recipient_email(mail, "repflow.me")
    assert got == "alpha@repflow.me"
    err = capsys.readouterr().out
    assert "Multiple @repflow.me recipients in destination" in err


def test_empty_to_returns_empty_string():
    mail = {"commonHeaders": {"to": []}}
    assert resolve_inbound_recipient_email(mail, "repflow.me") == ""
