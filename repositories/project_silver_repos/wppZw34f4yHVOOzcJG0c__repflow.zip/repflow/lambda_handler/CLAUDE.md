# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Overview

This is the **Lambda Handler** for the Repflow email automation system. It processes incoming emails via AWS SES, runs them through a finite state machine (FSM), and uses OpenAI agents for classification, negotiation, and deal creation.

## Common Commands

```bash
# Create deployment package (run from lambda_handler directory)
python package.py

# Run tests
pytest

# Install dependencies (for local development)
pip install -r requirements.txt
```

## Architecture

### Email Processing Flow

```
AWS SES → S3 (raw email) → Lambda Handler → FSM → AI Agents → API Backend
                                                       ↓
                                              SES (reply email)
```

1. **SES receives email** → stores raw email in S3
2. **Lambda triggered** → fetches email from S3, parses headers/content
3. **FSM processes** → determines current state, runs appropriate AI agent
4. **Agent generates response** → FSM transitions state, sends reply via SES
5. **State persisted** → Lead updated via API client to backend

### Directory Structure

```
lambda_handler/
├── lambda_function.py    # Main Lambda entrypoint + email processing
├── api_client.py         # HTTP client for backend API calls
├── package.py            # Deployment package builder
├── ai_agents/            # OpenAI agent implementations
│   ├── classification_agent.py   # Classifies emails (sponsorship vs non-sponsorship)
│   ├── parsing_agent.py          # Extracts deal details from emails
│   ├── evaluation_agent.py       # Evaluates deals against creator preferences
│   ├── research_agent.py         # Researches brands via web
│   ├── followup_agent.py         # Generates follow-up questions
│   ├── polishing_agent.py        # Polishes email responses
│   └── category_matcher.py       # Matches brand categories
├── fsm/                  # Finite State Machine
│   ├── state_machine.py  # Core FSM logic
│   ├── context.py        # FSM context (lead, user, conversation)
│   ├── events.py         # FSM events and triggers
│   ├── transitions.py    # Transition result types
│   └── states/           # State handlers
│       ├── needs_classification.py
│       ├── needs_info.py
│       ├── needs_evaluation.py
│       ├── needs_negotiation.py
│       ├── ready_for_deal.py
│       ├── deal_created.py
│       ├── terminal_states.py
│       └── error_states.py
├── database/             # Pydantic models (Beanie ODM)
│   └── models/
│       ├── lead.py       # LeadQualificationData, EmailProcessingState
│       ├── deal.py       # Deal model
│       └── common.py     # CRUDDocument base class
└── business/             # Business logic utilities
```

### FSM States

The email processing FSM has these states defined in `EmailProcessingState`:

| State | Description |
|-------|-------------|
| `NEEDS_CLASSIFICATION` | Initial state - classify if email is sponsorship-related |
| `NEEDS_INFO` | Missing deal details - request more info via follow-up |
| `NEEDS_EVALUATION` | Evaluate deal against creator preferences |
| `NEEDS_NEGOTIATION` | Handle negotiation (budget/terms discussions) |
| `READY_FOR_DEAL` | All info gathered - ready to create deal |
| `DEAL_CREATED` | Deal created, route to creator dashboard |
| `REJECTED` | Deal rejected (bad fit, low budget, etc.) |
| `REJECTED_NON_SPONSORSHIP` | Email not sponsorship-related |
| `ERROR_*` | Error states for failed operations |
| `COMPLETE/GHOSTED/ABANDONED/LOST` | Terminal archive states |

### Key Components

**`lambda_function.py`**:
- `lambda_handler()` - Main Lambda entrypoint
- `parse_ses_event()` - Parse SES notification
- `fetch_email_from_s3()` - Fetch raw email content
- `process_email_event()` - Core processing orchestration
- `send_ses_reply()` - Send response via SES

**`api_client.py`**:
- `APIClient` - Async HTTP client for backend API
- `UserDTO` - Lightweight user model (avoids Beanie initialization in Lambda)
- Uses `API_BASE_URL` and `API_AUTH_TOKEN` environment variables

**FSM Context (`fsm/context.py`)**:
- Holds `lead`, `user`, `conversation_history`, `current_email`
- Tracks `state_metadata`, `deal_id`, follow-up/negotiation counts

### Environment Variables

```bash
# Required
API_BASE_URL=https://api.repflow.com
API_AUTH_TOKEN=<service-account-token>
S3_BUCKET=<email-bucket-name>
SES_REGION=us-east-2

# Optional
DEMO_EMAIL_AGENT_DISABLE_SEND=true  # Disable actual SES sends
OPENAI_API_KEY=<key>                # For AI agents
```

### Deployment

The `package.py` script creates a Lambda deployment package:

1. Installs dependencies to `package/` directory (Linux x86_64 binaries)
2. Zips all dependencies at root level
3. Adds `lambda_function.py`, `api_client.py`, and module directories
4. Output: `lambda_deployment_package.zip` (~45MB)

```bash
python package.py
# Upload lambda_deployment_package.zip to AWS Lambda
```

### Testing Locally

The Lambda can be tested locally by calling `process_email_event()` directly with mock data:

```python
import asyncio
from lambda_function import process_email_event, EmailEvent, create_api_client

async def test():
    api_client = create_api_client()
    async with api_client:
        email_event = EmailEvent(
            message_id="test-123",
            thread_id="thread-abc",
            sender_email="brand@example.com",
            recipient_email="creator@repflow.com",
            subject="Partnership Opportunity",
            content="",
            timestamp=datetime.now(timezone.utc),
            s3_bucket="test-bucket",
            s3_key="test-key"
        )
        result = await process_email_event(api_client, email_event, "Email content here")
        print(result)

asyncio.run(test())
```

### Important Notes

- **UserDTO vs Beanie User**: Lambda uses `UserDTO` (lightweight Pydantic model) instead of Beanie `User` to avoid MongoDB initialization requirements
- **Thread ID generation**: Thread IDs are SHA256 hashes of sorted email addresses + normalized subject
- **Fail-safe**: FSM has a fail-safe that generates a generic response if no output is produced
- **State persistence**: Lead state is persisted via API calls to the backend, not direct MongoDB access
