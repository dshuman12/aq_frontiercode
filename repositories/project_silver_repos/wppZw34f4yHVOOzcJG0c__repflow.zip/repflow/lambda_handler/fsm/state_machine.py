from __future__ import annotations

import logging
from datetime import datetime, timezone

from typing import Any, Dict, List, Optional

from .context import FSMContext
from .events import FSMEvent
from database.models.lead import TransitionTrigger

logger = logging.getLogger(__name__)


from database.models.lead import EmailProcessingState as FSMState


from .transitions import StateTransitionResult, TransitionValidator  # noqa: E402


class StateMachine:
    """Core FSM orchestrator."""

    def __init__(self, context: FSMContext, initial_state: FSMState):
        self.context = context
        self.current_state = initial_state
        self.state_history: List[Dict[str, Any]] = []

    def get_current_state(self) -> FSMState:
        return self.current_state

    async def process_event(self, event: FSMEvent) -> StateTransitionResult:
        """Process an event through the current state handler."""
        state_handler = self._get_state_handler()
        await state_handler.on_enter(self.context)

        result = await state_handler.handle(self.context, event)
        if not result.success:
            logger.warning(
                "State handler reported failure",
                extra={"state": self.current_state, "error": result.error},
            )
            return result

        if not TransitionValidator.validate(self.current_state, event, result.new_state):
            error_message = (
                f"Illegal transition {self.current_state} -> {result.new_state} "
                f"for event {event}"
            )
            logger.error(error_message)
            return StateTransitionResult(
                success=False,
                new_state=self.current_state,
                trigger=result.trigger,
                response_to_send=None,
                should_send_email=False,
                should_route_to_creator=False,
                metadata=result.metadata,
                error=error_message,
            )

        await state_handler.on_exit(self.context)
        await state_handler.persist_transition(self.context, result)
        self._record_transition(event, result)
        self.current_state = result.new_state
        return result

    async def transition_to(
        self,
        new_state: FSMState,
        trigger: TransitionTrigger,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> bool:
        """Imperative transition to a new state."""
        event = FSMEvent.MANUAL_OVERRIDE
        if not TransitionValidator.validate(self.current_state, event, new_state):
            return False

        transition_result = StateTransitionResult(
            success=True,
            new_state=new_state,
            trigger=trigger,
            response_to_send=None,
            should_send_email=False,
            should_route_to_creator=False,
            metadata=metadata or {},
        )
        handler = self._get_state_handler()
        await handler.persist_transition(self.context, transition_result)
        self._record_transition(event, transition_result)
        self.current_state = new_state
        return True

    def _record_transition(self, event: FSMEvent, result: StateTransitionResult) -> None:
        self.state_history.append(
            {
                "from": self.current_state,
                "to": result.new_state,
                "trigger": result.trigger,
                "event": event,
                "timestamp": datetime.now(timezone.utc),
                "metadata": result.metadata,
            }
        )

    def _get_state_handler(self):
        # Lazy import to avoid circular dependency at module load
        from .registry import StateRegistry

        return StateRegistry.get_state(self.current_state)
