from enum import Enum


from database.models.lead import TransitionTrigger


class FSMEvent(str, Enum):
    """Events that can be processed by the unified FSM."""

    EMAIL_RECEIVED = "email_received"
    DEAL_CONVERSATION_EMAIL = "deal_conversation_email"
    CLASSIFICATION_COMPLETE = "classification_complete"
    INFO_UPDATED = "info_updated"
    EVALUATION_COMPLETE = "evaluation_complete"
    NEGOTIATION_RESPONSE = "negotiation_response"
    DEAL_CREATED = "deal_created"
    TIMEOUT = "timeout"
    ERROR_OCCURRED = "error_occurred"
    RETRY_TRIGGERED = "retry_triggered"
    MANUAL_OVERRIDE = "manual_override"
