from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from database.models.lead import LeadQualificationData, EmailProcessingState

from api_client import APIClient, convert_lead_to_api_format, UserDTO

# Use UserDTO instead of Beanie's User model
User = UserDTO


EmailContent = Dict[str, Any]


@dataclass
class FSMContext:
    """Shared context passed between FSM states."""

    lead: LeadQualificationData
    user: User
    conversation_history: str
    current_email: EmailContent
    api_client: APIClient
    state_metadata: Dict[str, Any] = field(default_factory=dict)
    deal_id: Optional[str] = None

    def set_transition_metadata(self, key: str, value: Any) -> None:
        self.state_metadata[key] = value

    def get_transition_metadata(self, key: str, default: Any = None) -> Any:
        return self.state_metadata.get(key, default)

    def get_negotiation_round(self) -> int:
        return int(self.state_metadata.get("negotiation_round", 0))

    def increment_negotiation_round(self) -> None:
        round_num = self.get_negotiation_round() + 1
        self.state_metadata["negotiation_round"] = round_num

    def add_counter_offer(self, offer: Dict[str, Any]) -> None:
        offers = self.state_metadata.get("counter_offers", [])
        offers.append(offer)
        self.state_metadata["counter_offers"] = offers

    def get_counter_offers(self) -> List[Dict[str, Any]]:
        return list(self.state_metadata.get("counter_offers", []))

    def get_missing_fields(self) -> List[str]:
        return list(self.state_metadata.get("missing_fields", []))

    def set_missing_fields(self, fields: List[str]) -> None:
        self.state_metadata["missing_fields"] = fields

    def get_follow_up_count(self) -> int:
        return int(self.state_metadata.get("follow_up_count", 0))

    def increment_follow_up_count(self) -> None:
        self.state_metadata["follow_up_count"] = self.get_follow_up_count() + 1

    def get_last_follow_up_time(self) -> Optional[datetime]:
        return self.state_metadata.get("last_follow_up_time")

    def set_last_follow_up_time(self, time: datetime) -> None:
        self.state_metadata["last_follow_up_time"] = time

    def get_retry_count(self) -> int:
        return int(self.state_metadata.get("retry_count", 0))

    def increment_retry_count(self) -> None:
        self.state_metadata["retry_count"] = self.get_retry_count() + 1

    def get_last_error(self) -> Optional[str]:
        return self.state_metadata.get("error_message")

    def set_last_error(self, error: str) -> None:
        self.state_metadata["error_message"] = error

    async def persist_state(self) -> None:
        """Persist lead state and metadata to the backend immediately."""
        if not self.api_client:
            return

        now = datetime.now(timezone.utc)
        self.lead.processing_state = getattr(
            self.lead,
            "processing_state",
            EmailProcessingState.NEEDS_CLASSIFICATION,
        )
        self.lead.state_metadata = self.state_metadata
        self.lead.last_state_change = now
        self.lead.updated_at = now
        self.lead.follow_up_count = self.get_follow_up_count()
        self.lead.negotiation_round = self.get_negotiation_round()
        self.lead.retry_count = self.get_retry_count()
        self.lead.deal_id = self.deal_id

        lead_data = convert_lead_to_api_format(self.lead.model_dump())
        lead_identifier = getattr(self.lead, "uuid", None) or (
            str(self.lead.id) if self.lead.id else None
        )
        if not lead_identifier:
            # Without an identifier we can't persist; leave early rather than raising
            print("[FSM] persist_state skipped: missing lead identifier")
            return

        await self.api_client.update_lead(lead_identifier, lead_data)
