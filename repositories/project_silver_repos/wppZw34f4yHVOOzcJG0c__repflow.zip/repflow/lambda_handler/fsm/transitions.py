from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Tuple

from .events import FSMEvent, TransitionTrigger
from .state_machine import FSMState


@dataclass
class StateTransitionResult:
    """Result of processing an event and transitioning state."""

    success: bool
    new_state: FSMState
    trigger: TransitionTrigger
    response_to_send: str | None
    should_send_email: bool
    should_route_to_creator: bool
    metadata: Dict[str, Any]
    error: str | None = None


class TransitionValidator:
    """Validates transitions based on declared FSM rules."""

    @staticmethod
    def validate(
        current_state: FSMState, event: FSMEvent, target_state: FSMState
    ) -> bool:
        allowed = VALID_TRANSITIONS.get((current_state, event), [])
        return any(state == target_state for state, _ in allowed)

    @staticmethod
    def get_trigger_for(
        current_state: FSMState, event: FSMEvent, target_state: FSMState
    ) -> TransitionTrigger | None:
        for state, trigger in VALID_TRANSITIONS.get((current_state, event), []):
            if state == target_state:
                return trigger
        return None


# VALID_TRANSITIONS defines legal target states per (state, event) pair, paired with the transition trigger.
VALID_TRANSITIONS: Dict[Tuple[FSMState, FSMEvent], List[Tuple[FSMState, TransitionTrigger]]] = {
    # Routing from initial email handling
    (
        FSMState.NEEDS_CLASSIFICATION,
        FSMEvent.EMAIL_RECEIVED,
    ): [
        (FSMState.NEEDS_CLASSIFICATION, TransitionTrigger.EMAIL),
        (FSMState.REJECTED_NON_SPONSORSHIP, TransitionTrigger.AI),
        (FSMState.REJECTED, TransitionTrigger.AI),
        (FSMState.NEEDS_INFO, TransitionTrigger.AI),
        (FSMState.NEEDS_EVALUATION, TransitionTrigger.AI),
        (FSMState.ERROR_CLASSIFICATION_FAILED, TransitionTrigger.AI),
    ],
    # Classification completion
    (
        FSMState.NEEDS_CLASSIFICATION,
        FSMEvent.CLASSIFICATION_COMPLETE,
    ): [
        (FSMState.REJECTED_NON_SPONSORSHIP, TransitionTrigger.AI),
        (FSMState.REJECTED, TransitionTrigger.AI),
        (FSMState.NEEDS_INFO, TransitionTrigger.AI),
        (FSMState.NEEDS_EVALUATION, TransitionTrigger.AI),
        (FSMState.ERROR_CLASSIFICATION_FAILED, TransitionTrigger.AI),
    ],
    # Info gathering
    (
        FSMState.NEEDS_INFO,
        FSMEvent.EMAIL_RECEIVED,
    ): [
        (FSMState.READY_FOR_DEAL, TransitionTrigger.AI),
        (FSMState.NEEDS_NEGOTIATION, TransitionTrigger.AI),
        (FSMState.REJECTED, TransitionTrigger.AI),
        (FSMState.NEEDS_EVALUATION, TransitionTrigger.EMAIL),
        (FSMState.NEEDS_INFO, TransitionTrigger.EMAIL),
    ],
    (
        FSMState.NEEDS_INFO,
        FSMEvent.INFO_UPDATED,
    ): [
        (FSMState.READY_FOR_DEAL, TransitionTrigger.AI),
        (FSMState.NEEDS_NEGOTIATION, TransitionTrigger.AI),
        (FSMState.REJECTED, TransitionTrigger.AI),
        (FSMState.NEEDS_EVALUATION, TransitionTrigger.EMAIL),
        (FSMState.NEEDS_INFO, TransitionTrigger.EMAIL),
    ],
    (
        FSMState.NEEDS_INFO,
        FSMEvent.TIMEOUT,
    ): [
        (FSMState.GHOSTED, TransitionTrigger.TIME),
    ],
    # Evaluation
    (
        FSMState.NEEDS_EVALUATION,
        FSMEvent.EMAIL_RECEIVED,
    ): [
        (FSMState.READY_FOR_DEAL, TransitionTrigger.AI),
        (FSMState.NEEDS_NEGOTIATION, TransitionTrigger.AI),
        (FSMState.REJECTED, TransitionTrigger.AI),
        (FSMState.NEEDS_INFO, TransitionTrigger.AI),
    ],
    (
        FSMState.NEEDS_EVALUATION,
        FSMEvent.EVALUATION_COMPLETE,
    ): [
        (FSMState.READY_FOR_DEAL, TransitionTrigger.AI),
        (FSMState.NEEDS_NEGOTIATION, TransitionTrigger.AI),
        (FSMState.REJECTED, TransitionTrigger.AI),
        (FSMState.NEEDS_INFO, TransitionTrigger.AI),
    ],
    # Negotiation
    (
        FSMState.NEEDS_NEGOTIATION,
        FSMEvent.EMAIL_RECEIVED,
    ): [
        (FSMState.READY_FOR_DEAL, TransitionTrigger.EMAIL),
        (FSMState.NEEDS_NEGOTIATION, TransitionTrigger.EMAIL),
        (FSMState.REJECTED, TransitionTrigger.MANUAL),
    ],
    (
        FSMState.NEEDS_NEGOTIATION,
        FSMEvent.NEGOTIATION_RESPONSE,
    ): [
        (FSMState.READY_FOR_DEAL, TransitionTrigger.EMAIL),
        (FSMState.NEEDS_NEGOTIATION, TransitionTrigger.EMAIL),
        (FSMState.REJECTED, TransitionTrigger.MANUAL),
    ],
    (
        FSMState.NEEDS_NEGOTIATION,
        FSMEvent.TIMEOUT,
    ): [
        (FSMState.GHOSTED, TransitionTrigger.TIME),
    ],
    # Deal creation - triggered by EMAIL_RECEIVED continuing from evaluation/info gathering
    (
        FSMState.READY_FOR_DEAL,
        FSMEvent.EMAIL_RECEIVED,
    ): [
        (FSMState.DEAL_CREATED, TransitionTrigger.API),
        (FSMState.ERROR_DEAL_CREATION_FAILED, TransitionTrigger.API),
    ],
    (
        FSMState.READY_FOR_DEAL,
        FSMEvent.EVALUATION_COMPLETE,
    ): [
        (FSMState.DEAL_CREATED, TransitionTrigger.API),
        (FSMState.ERROR_DEAL_CREATION_FAILED, TransitionTrigger.API),
    ],
    (
        FSMState.READY_FOR_DEAL,
        FSMEvent.DEAL_CREATED,
    ): [
        (FSMState.DEAL_CREATED, TransitionTrigger.API),
        (FSMState.ERROR_DEAL_CREATION_FAILED, TransitionTrigger.API),
    ],
    # Existing deal conversations
    (
        FSMState.DEAL_CREATED,
        FSMEvent.DEAL_CONVERSATION_EMAIL,
    ): [
        (FSMState.DEAL_CREATED, TransitionTrigger.EMAIL),
    ],
    (
        FSMState.DEAL_CREATED,
        FSMEvent.MANUAL_OVERRIDE,
    ): [
        (FSMState.COMPLETE, TransitionTrigger.MANUAL),
        (FSMState.ABANDONED, TransitionTrigger.MANUAL),
        (FSMState.LOST, TransitionTrigger.MANUAL),
    ],
    # Error handling and retries
    (
        FSMState.ERROR_CLASSIFICATION_FAILED,
        FSMEvent.RETRY_TRIGGERED,
    ): [
        (FSMState.NEEDS_RETRY, TransitionTrigger.RETRY),
        (FSMState.REJECTED, TransitionTrigger.RETRY),
    ],
    (
        FSMState.ERROR_DEAL_CREATION_FAILED,
        FSMEvent.RETRY_TRIGGERED,
    ): [
        (FSMState.NEEDS_RETRY, TransitionTrigger.RETRY),
        (FSMState.REJECTED, TransitionTrigger.RETRY),
    ],
    (
        FSMState.NEEDS_RETRY,
        FSMEvent.RETRY_TRIGGERED,
    ): [
        (FSMState.NEEDS_CLASSIFICATION, TransitionTrigger.RETRY),
    ],
    # Re-engagement transitions from terminal states
    (
        FSMState.REJECTED_NON_SPONSORSHIP,
        FSMEvent.EMAIL_RECEIVED,
    ): [(FSMState.NEEDS_CLASSIFICATION, TransitionTrigger.EMAIL)],
    (FSMState.REJECTED, FSMEvent.EMAIL_RECEIVED): [
        (FSMState.NEEDS_CLASSIFICATION, TransitionTrigger.EMAIL)
    ],
    (FSMState.GHOSTED, FSMEvent.EMAIL_RECEIVED): [
        (FSMState.NEEDS_CLASSIFICATION, TransitionTrigger.EMAIL)
    ],
    (FSMState.COMPLETE, FSMEvent.EMAIL_RECEIVED): [
        (FSMState.NEEDS_CLASSIFICATION, TransitionTrigger.EMAIL)
    ],
    (FSMState.ABANDONED, FSMEvent.EMAIL_RECEIVED): [
        (FSMState.NEEDS_CLASSIFICATION, TransitionTrigger.EMAIL)
    ],
    (FSMState.LOST, FSMEvent.EMAIL_RECEIVED): [
        (FSMState.NEEDS_CLASSIFICATION, TransitionTrigger.EMAIL)
    ],
}
