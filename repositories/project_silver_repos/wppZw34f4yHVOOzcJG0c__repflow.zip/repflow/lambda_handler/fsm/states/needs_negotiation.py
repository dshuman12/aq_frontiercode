from __future__ import annotations

from ai_agents.parsing_agent import parse_lead_update
from ..analyzers import ConversationAnalyzer, QualificationAnalyzer
from ..context import FSMContext
from ..events import FSMEvent, TransitionTrigger
from ..state_machine import FSMState
from ..transitions import StateTransitionResult
from .base import State


class NeedsNegotiationState(State):
    """Handles negotiation rounds and ghosting detection."""

    MAX_NEGOTIATION_ROUNDS = 3

    async def handle(
        self, context: FSMContext, event: FSMEvent
    ) -> StateTransitionResult:
        conversation_analyzer = ConversationAnalyzer()
        if event == FSMEvent.TIMEOUT or conversation_analyzer.should_trigger_ghosting(
            context, FSMState.NEEDS_NEGOTIATION
        ):
            metadata = {
                "negotiation_round": context.get_negotiation_round(),
                "follow_up_count": context.get_follow_up_count(),
            }
            return StateTransitionResult(
                success=True,
                new_state=FSMState.GHOSTED,
                trigger=TransitionTrigger.TIME,
                response_to_send=None,
                should_send_email=False,
                should_route_to_creator=False,
                metadata=metadata,
            )

        await parse_lead_update(context)
        analyzer = QualificationAnalyzer()
        fit_score = await analyzer.calculate_fit_score(context.lead, context.user.preferences)
        negotiability = analyzer.assess_negotiability(
            context.lead, context.user.preferences
        )

        round_num = context.get_negotiation_round()
        if round_num >= self.MAX_NEGOTIATION_ROUNDS or not negotiability.negotiable:
            metadata = {
                "negotiation_round": round_num,
                "fit_score": fit_score,
                "negotiable": negotiability.negotiable,
            }
            return StateTransitionResult(
                success=True,
                new_state=FSMState.REJECTED,
                trigger=TransitionTrigger.MANUAL,
                response_to_send=None,
                should_send_email=False,
                should_route_to_creator=False,
                metadata=metadata,
            )

        if fit_score >= 70:
            metadata = {
                "negotiation_round": round_num,
                "fit_score": fit_score,
                "negotiable": negotiability.negotiable,
            }
            return StateTransitionResult(
                success=True,
                new_state=FSMState.READY_FOR_DEAL,
                trigger=TransitionTrigger.EMAIL,
                response_to_send=None,
                should_send_email=False,
                should_route_to_creator=False,
                metadata=metadata,
            )

        # Continue negotiating
        context.increment_negotiation_round()
        metadata = {
            "negotiation_round": context.get_negotiation_round(),
            "fit_score": fit_score,
            "negotiable": negotiability.negotiable,
        }
        context.increment_follow_up_count()
        metadata["follow_up_count"] = context.get_follow_up_count()

        return StateTransitionResult(
            success=True,
            new_state=FSMState.NEEDS_NEGOTIATION,
            trigger=TransitionTrigger.EMAIL,
            response_to_send=None,
            should_send_email=False,
            should_route_to_creator=False,
            metadata=metadata,
        )
