from __future__ import annotations

from ..analyzers import QualificationAnalyzer
from ..context import FSMContext
from ..events import FSMEvent, TransitionTrigger
from ..response_utils import (
    prospect_asking_for_creator_rate,
    build_rate_range_response,
    build_deal_type_rejection_response,
)
from business.qualification import determine_deal_type_from_budget
from ..state_machine import FSMState
from ..transitions import StateTransitionResult
from .base import State


class NeedsEvaluationState(State):
    """Evaluates lead quality against preferences."""

    async def handle(
        self, context: FSMContext, event: FSMEvent
    ) -> StateTransitionResult:
        if event not in {FSMEvent.EVALUATION_COMPLETE, FSMEvent.EMAIL_RECEIVED}:
            return StateTransitionResult(
                success=False,
                new_state=context.lead.processing_state,
                trigger=TransitionTrigger.MANUAL,
                response_to_send=None,
                should_send_email=False,
                should_route_to_creator=False,
                metadata=context.state_metadata,
                error=f"Unsupported event {event} for evaluation",
            )

        analyzer = QualificationAnalyzer()
        result = await analyzer.analyze(context.lead, context.user.preferences)

        metadata = {
            "evaluation_score": result.fit_score,
            "failed_constraints": result.failed_constraints,
            "reasons": result.reasons,
        }

        creator_name = context.user.profile.name if context.user and context.user.profile and context.user.profile.name else "the team"
        recommendation = result.recommendation
        
        response_text = None
        should_send_email = False
        should_route_to_creator = False

        if recommendation == "ACCEPT":
            # Transition to READY_FOR_DEAL without sending email - the deal creation
            # state will send the thank you email after creating the deal
            next_state = FSMState.READY_FOR_DEAL
        elif recommendation == "NEGOTIATE":
            next_state = FSMState.NEEDS_NEGOTIATION
            should_route_to_creator = True
            should_send_email = True
            response_text = (
                f"Thanks so much for the details! I'm sending this over to {creator_name} who will follow up with more details shortly."
            )
        elif recommendation == "NEEDS_INFO":
            next_state = FSMState.NEEDS_INFO
        else:
            # REJECT: do not route to creator and do not create a deal
            reasons_str = " ".join(result.reasons).lower()
            latest_message = (
                context.current_email.get("content") if context.current_email else None
            )
            # If prospect asked for our rate (not stating theirs), reply with rate range instead of rejecting
            if "budget" in reasons_str and prospect_asking_for_creator_rate(
                latest_message
            ):
                next_state = FSMState.NEEDS_INFO
                should_send_email = True
                min_rate = getattr(
                    context.user.preferences,
                    "absoluteMinimumRate",
                    1000.0,
                )
                response_text = build_rate_range_response(creator_name, min_rate)
            else:
                next_state = FSMState.REJECTED
                should_send_email = True
                should_route_to_creator = False  # Explicit: no deal, no pass-along for rejects
                # Auto-reject category: use exact wording; we qualified first (website, rate, deliverables, timeline)
                cat_match = getattr(result, "category_match_result", None)
                if cat_match and getattr(cat_match, "matches", False):
                    response_text = (
                        f"{creator_name} is not currently accepting partnerships in this category. "
                        f"If that changes, {creator_name} will reach out."
                    )
                elif "budget" in reasons_str:
                    response_text = (
                        f"Thanks for sharing those details. Unfortunately, that budget is below {creator_name}'s minimum for this type of project, "
                        "so we won't be able to move forward. Best of luck with the campaign!"
                    )
                elif "category" in reasons_str:
                    response_text = (
                        f"{creator_name} is not currently accepting partnerships in this category. "
                        f"If that changes, {creator_name} will reach out."
                    )
                elif "deal type" in reasons_str:
                    # Extract deal type from lead (prefer explicit deal_type, fallback to inferring from budget)
                    deal_type = context.lead.deal_type or determine_deal_type_from_budget(context.lead.budget or "")
                    response_text = build_deal_type_rejection_response(creator_name, deal_type)
                else:
                    response_text = (
                        "Thanks for the info. Unfortunately, this doesn't look like a good fit for us right now. "
                        "Best of luck with the campaign!"
                    )

        return StateTransitionResult(
            success=True,
            new_state=next_state,
            trigger=TransitionTrigger.AI,
            response_to_send=response_text,
            should_send_email=should_send_email,
            should_route_to_creator=should_route_to_creator,
            metadata=metadata,
        )
