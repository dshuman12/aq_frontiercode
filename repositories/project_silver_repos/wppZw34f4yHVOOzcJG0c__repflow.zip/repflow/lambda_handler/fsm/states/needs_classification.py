from __future__ import annotations



from ai_agents.classification_agent import run_deal_filter
from ai_agents.parsing_agent import parse_lead_update
from ..analyzers import InfoAnalyzer
from ..context import FSMContext
from ..events import FSMEvent
from database.models.lead import TransitionTrigger
from ..state_machine import FSMState
from ..transitions import StateTransitionResult
from .base import State


class NeedsClassificationState(State):
    """Runs deal classification and routes to info or evaluation."""

    async def handle(
        self, context: FSMContext, event: FSMEvent
    ) -> StateTransitionResult:
        if event not in {FSMEvent.EMAIL_RECEIVED, FSMEvent.CLASSIFICATION_COMPLETE}:
            return StateTransitionResult(
                success=False,
                new_state=context.lead.processing_state,
                trigger=TransitionTrigger.MANUAL,
                response_to_send=None,
                should_send_email=False,
                should_route_to_creator=False,
                metadata=context.state_metadata,
                error=f"Unsupported event {event} for classification",
            )

        try:
            filter_response = await run_deal_filter(context.conversation_history)
        except Exception as exc:
            context.set_last_error(str(exc))
            context.increment_retry_count()
            metadata = {
                "error_message": str(exc),
                "retry_count": context.get_retry_count(),
            }
            return StateTransitionResult(
                success=True,
                new_state=FSMState.ERROR_CLASSIFICATION_FAILED,
                trigger=TransitionTrigger.AI,
                response_to_send=None,
                should_send_email=False,
                should_route_to_creator=False,
                metadata=metadata,
                error=str(exc),
            )

        if filter_response.classification == "Other" or (
            filter_response.confidence is not None and filter_response.confidence < 0.75
        ):
            metadata = {
                "classification": filter_response.classification,
                "subcategory": filter_response.subcategory,
                "confidence": filter_response.confidence,
            }
            return StateTransitionResult(
                success=True,
                new_state=FSMState.REJECTED,
                trigger=TransitionTrigger.AI,
                response_to_send=None,
                should_send_email=False,
                should_route_to_creator=True,
                metadata=metadata,
            )

        if filter_response.classification != "Sponsorship":
            metadata = {
                "classification": filter_response.classification,
                "subcategory": filter_response.subcategory,
                "confidence": filter_response.confidence,
            }
            return StateTransitionResult(
                success=True,
                new_state=FSMState.REJECTED_NON_SPONSORSHIP,
                trigger=TransitionTrigger.AI,
                response_to_send=None,
                should_send_email=False,
                should_route_to_creator=True,
                metadata=metadata,
            )

        # Parse lead info to ensure we have updated context before info analysis
        await parse_lead_update(context)

        info_analyzer = InfoAnalyzer()
        analysis = info_analyzer.analyze_completeness(context.lead)
        missing_fields = [field.name for field in analysis.missing_fields]
        context.set_missing_fields(missing_fields)
        metadata = {"missing_fields": missing_fields}

        next_state = (
            FSMState.NEEDS_INFO if missing_fields else FSMState.NEEDS_EVALUATION
        )

        return StateTransitionResult(
            success=True,
            new_state=next_state,
            trigger=TransitionTrigger.AI,
            response_to_send=analysis.suggested_question if missing_fields else None,
            should_send_email=bool(missing_fields and analysis.suggested_question),
            should_route_to_creator=False,
            metadata=metadata,
        )
