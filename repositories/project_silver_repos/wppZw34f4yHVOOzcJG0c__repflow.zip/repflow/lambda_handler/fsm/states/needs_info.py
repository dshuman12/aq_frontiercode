from __future__ import annotations

from typing import Optional

from ai_agents.parsing_agent import parse_lead_update
from ai_agents.followup_agent import generate_follow_up
from ..analyzers import ConversationAnalyzer, InfoAnalyzer, QualificationAnalyzer
from ..context import FSMContext
from ..events import FSMEvent, TransitionTrigger
from ..response_utils import (
    prospect_asking_for_creator_rate,
    build_rate_range_response,
    build_deal_type_rejection_response,
)
from business.qualification import determine_deal_type_from_budget
from ..state_machine import FSMState
from ..transitions import StateTransitionResult
from .base import State

# Module-level marker to confirm which file is loaded at runtime
# print(f"[NEEDS_INFO] module loaded from {__file__}")


class NeedsInfoState(State):
    """Handles targeted information gathering."""

    @staticmethod
    def _fallback_follow_up(
        missing_fields, latest_message: Optional[str], default_prompt: str
    ) -> str:
        """Fallback text if the AI follow-up agent fails."""
        if not default_prompt:
            default_prompt = "Could you share the remaining details so we can proceed?"

        clarifications = []
        if latest_message:
            lower_msg = latest_message.lower()
            if "deal type" in lower_msg:
                clarifications.append(
                    "Deal type refers to how the collaboration is structured (flat fee, affiliate/rev share, gifting, or hybrid)."
                )
            if "deadline" in lower_msg or "timeline" in lower_msg:
                clarifications.append(
                    "For the deadline/timeline, let me know when content should go live; relative dates like “next month” are fine."
                )
            if "?" in lower_msg and not clarifications:
                clarifications.append("Happy to clarify anything you asked above.")

        if clarifications:
            return " ".join(clarifications + [default_prompt])
        return default_prompt

    async def handle(
        self, context: FSMContext, event: FSMEvent
    ) -> StateTransitionResult:
        # Entry trace to confirm this code path executes and which event is driving it
        print(
            f"[NEEDS_INFO] handle enter event={event} state={context.lead.processing_state} "
            f"follow_up_count={context.get_follow_up_count()}"
        )

        # conversation_analyzer = ConversationAnalyzer()
        # Only ghost on explicit timeout events; avoid misfiring during live replies
        if event == FSMEvent.TIMEOUT:
            metadata = {
                "follow_up_count": context.get_follow_up_count(),
                "missing_fields": context.get_missing_fields(),
            }
            return StateTransitionResult(
                success=True,
                new_state=FSMState.GHOSTED,
                trigger=TransitionTrigger.TIME,
                response_to_send=None,
                should_send_email=False,
                should_route_to_creator=False,
                metadata=metadata,
            )

        await parse_lead_update(context)
        info_analyzer = InfoAnalyzer()
        latest_message = (
            context.current_email.get("content") if context.current_email else None
        )
        analysis = info_analyzer.analyze_completeness(
            context.lead, latest_message=latest_message
        )
        missing_fields = [field.name for field in analysis.missing_fields]
        context.set_missing_fields(missing_fields)

        metadata = {
            "missing_fields": missing_fields,
            "follow_up_count": context.get_follow_up_count(),
        }

        # Debug trace to confirm the inbound content and missing fields seen by this state
        print(
            f"[NEEDS_INFO] latest_message={repr(latest_message)} missing_fields={missing_fields} "
            f"follow_up_count={metadata['follow_up_count']}"
        )

        if not missing_fields:
            # Immediately evaluate now that we have all required info
            evaluator = QualificationAnalyzer()
            eval_result = await evaluator.analyze(context.lead, context.user.preferences)

            metadata.update(
                {
                    "evaluation_score": eval_result.fit_score,
                    "failed_constraints": eval_result.failed_constraints,
                    "reasons": eval_result.reasons,
                }
            )

            recommendation = eval_result.recommendation
            response_text = None
            should_route_to_creator = False
            should_send_email = False
            creator_name = context.user.profile.name if context.user and context.user.profile and context.user.profile.name else "the team"

            if recommendation == "ACCEPT":
                # Transition to READY_FOR_DEAL without sending email - the deal creation
                # state will send the thank you email after creating the deal
                next_state = FSMState.READY_FOR_DEAL
            elif recommendation == "NEGOTIATE":
                next_state = FSMState.NEEDS_NEGOTIATION
                should_route_to_creator = True
                should_send_email = True
                response_text = (
                    f"Thanks so much for the details! I'm sending this over to {creator_name} who will follow up with more details shortly."
                )
            elif recommendation == "NEEDS_INFO":
                next_state = FSMState.NEEDS_INFO
            else:
                reasons_str = " ".join(eval_result.reasons).lower()
                # If prospect asked for our rate (not stating theirs), reply with rate range instead of rejecting
                if "budget" in reasons_str and prospect_asking_for_creator_rate(latest_message):
                    next_state = FSMState.NEEDS_INFO
                    should_send_email = True
                    min_rate = getattr(
                        context.user.preferences,
                        "absoluteMinimumRate",
                        1000.0,
                    )
                    response_text = build_rate_range_response(creator_name, min_rate)
                else:
                    next_state = FSMState.REJECTED
                    should_send_email = True
                    if "budget" in reasons_str:
                        response_text = (
                            f"Thanks for sharing those details. Unfortunately, that budget is below {creator_name}'s minimum for this type of project, "
                            "so we won't be able to move forward. Best of luck with the campaign!"
                        )
                    elif "category" in reasons_str:
                        response_text = (
                            f"Thanks for the info. Unfortunately, {creator_name} isn't taking on partnerships in this category at the moment. "
                            "Best of luck with the campaign!"
                        )
                    elif "deal type" in reasons_str:
                        # Extract deal type from lead (prefer explicit deal_type, fallback to inferring from budget)
                        deal_type = context.lead.deal_type or determine_deal_type_from_budget(context.lead.budget or "")
                        response_text = build_deal_type_rejection_response(creator_name, deal_type)
                    else:
                        response_text = (
                            "Thanks for the info. Unfortunately, this doesn't look like a good fit for us right now. "
                            "Best of luck with the campaign!"
                        )

            return StateTransitionResult(
                success=True,
                new_state=next_state,
                trigger=TransitionTrigger.AI,
                response_to_send=response_text,
                should_send_email=should_send_email,
                should_route_to_creator=should_route_to_creator,
                metadata=metadata,
            )

        # Still missing information - stay in NEEDS_INFO and send targeted follow-up
        context.increment_follow_up_count()
        metadata["follow_up_count"] = context.get_follow_up_count()

        follow_up_text = analysis.suggested_question
        ai_follow_up_used = False
        fallback_used = False

        # Prefer AI-crafted follow-up if available
        try:
            follow_up_text = await generate_follow_up(
                missing_fields=missing_fields,
                latest_message=latest_message,
                conversation_history=context.conversation_history,
            )
            ai_follow_up_used = True
            print("[NEEDS_INFO] generate_follow_up succeeded")
        except Exception as exc:
            print(f"[NEEDS_INFO] generate_follow_up failed: {exc}")

        # As a final guard, add a lightweight clarification fallback if AI didn't adjust
        if follow_up_text == analysis.suggested_question:
            fallback_used = True
            follow_up_text = self._fallback_follow_up(
                missing_fields, latest_message, analysis.suggested_question
            )

        follow_up_source = "ai" if ai_follow_up_used and not fallback_used else "static"
        metadata["follow_up_source"] = follow_up_source
        metadata["follow_up_fallback_used"] = fallback_used
        print(
            "[NEEDS_INFO] follow_up_selected "
            f"source={follow_up_source} fallback_used={fallback_used} "
            f"preview={repr(follow_up_text[:120])}"
        )

        return StateTransitionResult(
            success=True,
            new_state=FSMState.NEEDS_INFO,
            trigger=TransitionTrigger.EMAIL,
            response_to_send=follow_up_text,
            should_send_email=bool(follow_up_text),
            should_route_to_creator=False,
            metadata=metadata,
        )
