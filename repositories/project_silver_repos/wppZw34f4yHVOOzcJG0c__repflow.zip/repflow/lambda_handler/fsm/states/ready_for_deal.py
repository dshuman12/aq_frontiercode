from __future__ import annotations

import os

from business.deal_creation import create_deal_from_qualified_lead
from ..context import FSMContext
from ..events import FSMEvent, TransitionTrigger
from ..state_machine import FSMState
from ..transitions import StateTransitionResult
from .base import State

FRONTEND_URL = os.environ.get("FRONTEND_URL", "https://creator.userepflow.com")


class ReadyForDealState(State):
    """Creates deals and routes to deal conversations."""

    async def handle(
        self, context: FSMContext, event: FSMEvent
    ) -> StateTransitionResult:
        if event not in {
            FSMEvent.DEAL_CREATED,
            FSMEvent.EVALUATION_COMPLETE,
            FSMEvent.EMAIL_RECEIVED,
        }:
            return StateTransitionResult(
                success=False,
                new_state=context.lead.processing_state,
                trigger=TransitionTrigger.MANUAL,
                response_to_send=None,
                should_send_email=False,
                should_route_to_creator=False,
                metadata=context.state_metadata,
                error=f"Unsupported event {event} for ready_for_deal",
            )

        creator_name = (
            context.user.profile.name
            if context.user and context.user.profile and context.user.profile.name
            else "the team"
        )

        try:
            deal_id = await create_deal_from_qualified_lead(
                context.api_client, context.lead
            )
            if deal_id:
                context.deal_id = deal_id
                metadata = {"deal_id": deal_id}
                # Public proposal link that allows visitors to browse and contact creators
                proposal_link = f"{FRONTEND_URL}/proposal"
                response_text = (
                    f"Thanks so much for the details! I've created a proposal and sent it over to {creator_name}, "
                    f"who will follow up with you shortly.\n\n"
                    f"In the meantime, feel free to check out other creators here: {proposal_link}"
                )
                return StateTransitionResult(
                    success=True,
                    new_state=FSMState.DEAL_CREATED,
                    trigger=TransitionTrigger.API,
                    response_to_send=response_text,
                    should_send_email=True,
                    should_route_to_creator=True,
                    metadata=metadata,
                )
        except Exception as exc:
            context.set_last_error(str(exc))
            context.increment_retry_count()
            metadata = {
                "error_message": str(exc),
                "retry_count": context.get_retry_count(),
            }
            return StateTransitionResult(
                success=True,
                new_state=FSMState.ERROR_DEAL_CREATION_FAILED,
                trigger=TransitionTrigger.API,
                response_to_send=None,
                should_send_email=False,
                should_route_to_creator=False,
                metadata=metadata,
                error=str(exc),
            )

        metadata = {"error_message": "Deal creation returned no ID"}
        return StateTransitionResult(
            success=True,
            new_state=FSMState.ERROR_DEAL_CREATION_FAILED,
            trigger=TransitionTrigger.API,
            response_to_send=None,
            should_send_email=False,
            should_route_to_creator=False,
            metadata=metadata,
            error="Deal creation failed",
        )
