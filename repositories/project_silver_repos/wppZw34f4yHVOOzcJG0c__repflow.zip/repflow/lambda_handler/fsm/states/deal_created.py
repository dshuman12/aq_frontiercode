from __future__ import annotations

from ..context import FSMContext
from ..events import FSMEvent, TransitionTrigger
from fsm.state_machine import FSMState
from ..transitions import StateTransitionResult
from .base import State


class ExistingDealState(State):
    """Handles ongoing conversations for an existing deal."""

    async def handle(
        self, context: FSMContext, event: FSMEvent
    ) -> StateTransitionResult:
        if event == FSMEvent.DEAL_CONVERSATION_EMAIL:
            metadata = {
                "deal_id": context.deal_id or context.lead.deal_id,
                "conversation_thread_id": context.lead.thread_id,
            }
            return StateTransitionResult(
                success=True,
                new_state=FSMState.DEAL_CREATED,
                trigger=TransitionTrigger.EMAIL,
                response_to_send=None,
                should_send_email=False,
                should_route_to_creator=True,
                metadata=metadata,
            )

        if event == FSMEvent.MANUAL_OVERRIDE:
            # Manual overrides are handled upstream; keep state unchanged here.
            return StateTransitionResult(
                success=True,
                new_state=FSMState.DEAL_CREATED,
                trigger=TransitionTrigger.MANUAL,
                response_to_send=None,
                should_send_email=False,
                should_route_to_creator=True,
                metadata=context.state_metadata,
            )

        return StateTransitionResult(
            success=False,
            new_state=context.lead.processing_state,
            trigger=TransitionTrigger.MANUAL,
            response_to_send=None,
            should_send_email=False,
            should_route_to_creator=False,
            metadata=context.state_metadata,
            error=f"Unsupported event {event} for existing_deal",
        )
