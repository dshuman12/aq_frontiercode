from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Dict

from ..context import FSMContext
from ..events import FSMEvent
from ..state_machine import FSMState
from ..transitions import StateTransitionResult


class State(ABC):
    """Abstract base for all FSM states."""

    @abstractmethod
    async def handle(self, context: FSMContext, event: FSMEvent) -> StateTransitionResult:
        raise NotImplementedError

    async def on_enter(self, context: FSMContext) -> None:
        return None

    async def on_exit(self, context: FSMContext) -> None:
        return None

    def can_transition_to(self, target_state: FSMState) -> bool:
        return True

    def get_state_metadata_schema(self) -> Dict[str, type]:
        return {}

    async def persist_transition(
        self, context: FSMContext, result: StateTransitionResult
    ) -> None:
        context.lead.processing_state = result.new_state
        context.state_metadata.update(result.metadata or {})
        await context.persist_state()
