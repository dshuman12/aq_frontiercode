from __future__ import annotations

from ..context import FSMContext
from ..events import FSMEvent, TransitionTrigger
from ..state_machine import FSMState
from ..transitions import StateTransitionResult
from ..response_utils import (
    prospect_asking_for_creator_rate,
    build_rate_range_response,
)
from ..analyzers import QualificationAnalyzer
from ai_agents.parsing_agent import parse_lead_update
from business.qualification import extract_budget_value
from .base import State


class _TerminalState(State):
    target_state: FSMState

    def __init__(self, target_state: FSMState):
        self.target_state = target_state

    async def handle(
        self, context: FSMContext, event: FSMEvent
    ) -> StateTransitionResult:
        if event == FSMEvent.EMAIL_RECEIVED:
            # Reset any stale metadata when re-engaging from a terminal state.
            context.state_metadata = {}
            return StateTransitionResult(
                success=True,
                new_state=FSMState.NEEDS_CLASSIFICATION,
                trigger=TransitionTrigger.EMAIL,
                response_to_send=None,
                should_send_email=False,
                should_route_to_creator=False,
                metadata=context.state_metadata,
            )
        return StateTransitionResult(
            success=True,
            new_state=self.target_state,
            trigger=TransitionTrigger.MANUAL,
            response_to_send=None,
            should_send_email=False,
            should_route_to_creator=False,
            metadata=context.state_metadata,
        )


class CompleteState(_TerminalState):
    def __init__(self):
        super().__init__(FSMState.COMPLETE)


class RejectedState(_TerminalState):
    """Handles re-engagement after rejection, especially for budget negotiations."""

    def __init__(self):
        super().__init__(FSMState.REJECTED)

    async def handle(
        self, context: FSMContext, event: FSMEvent
    ) -> StateTransitionResult:
        if event == FSMEvent.EMAIL_RECEIVED:
            # Parse the new email to extract any updated information
            await parse_lead_update(context)
            
            latest_message = (
                context.current_email.get("content") if context.current_email else None
            )
            creator_name = (
                context.user.profile.name
                if context.user and context.user.profile and context.user.profile.name
                else "the team"
            )

            # Check if brand is asking about preferred rates
            if prospect_asking_for_creator_rate(latest_message):
                # Respond with rate range and transition to NEEDS_INFO to continue conversation
                min_rate = getattr(
                    context.user.preferences,
                    "absoluteMinimumRate",
                    1000.0,
                )
                response_text = build_rate_range_response(creator_name, min_rate)
                return StateTransitionResult(
                    success=True,
                    new_state=FSMState.NEEDS_INFO,
                    trigger=TransitionTrigger.EMAIL,
                    response_to_send=response_text,
                    should_send_email=True,
                    should_route_to_creator=False,
                    metadata=context.state_metadata,
                )

            # Check if brand has agreed to a new budget that meets minimum requirements
            if context.lead.budget:
                budget_value = extract_budget_value(context.lead.budget)
                min_rate = getattr(
                    context.user.preferences,
                    "absoluteMinimumRate",
                    1000.0,
                )
                
                if budget_value >= min_rate:
                    # Re-evaluate the lead with the new budget
                    analyzer = QualificationAnalyzer()
                    result = await analyzer.analyze(context.lead, context.user.preferences)
                    
                    if result.recommendation in ("ACCEPT", "NEGOTIATE"):
                        # Budget now meets requirements - route to creator
                        # This will create/update deal and link conversation
                        response_text = (
                            f"Thanks for the update! I've passed this along to {creator_name}, "
                            "and we'll be in touch shortly."
                        )
                        return StateTransitionResult(
                            success=True,
                            new_state=FSMState.NEEDS_EVALUATION,
                            trigger=TransitionTrigger.EMAIL,
                            response_to_send=response_text,
                            should_send_email=True,
                            should_route_to_creator=True,
                            metadata={
                                **context.state_metadata,
                                "re_engagement": True,
                                "budget_updated": True,
                                "new_budget": budget_value,
                            },
                        )

            # Default: reset to classification for other types of re-engagement
            context.state_metadata = {}
            return StateTransitionResult(
                success=True,
                new_state=FSMState.NEEDS_CLASSIFICATION,
                trigger=TransitionTrigger.EMAIL,
                response_to_send=None,
                should_send_email=False,
                should_route_to_creator=False,
                metadata=context.state_metadata,
            )
        
        return StateTransitionResult(
            success=True,
            new_state=self.target_state,
            trigger=TransitionTrigger.MANUAL,
            response_to_send=None,
            should_send_email=False,
            should_route_to_creator=False,
            metadata=context.state_metadata,
        )


class RejectedNonSponsorshipState(_TerminalState):
    def __init__(self):
        super().__init__(FSMState.REJECTED_NON_SPONSORSHIP)


class GhostedState(_TerminalState):
    def __init__(self):
        super().__init__(FSMState.GHOSTED)


class AbandonedState(_TerminalState):
    def __init__(self):
        super().__init__(FSMState.ABANDONED)


class LostState(_TerminalState):
    def __init__(self):
        super().__init__(FSMState.LOST)
