from __future__ import annotations

from datetime import datetime, timezone

from ..context import FSMContext
from ..events import FSMEvent, TransitionTrigger
from ..state_machine import FSMState
from ..transitions import StateTransitionResult
from .base import State


class ErrorClassificationFailedState(State):
    """Handles AI classification errors with retry logic."""

    MAX_RETRIES = 3

    async def handle(
        self, context: FSMContext, event: FSMEvent
    ) -> StateTransitionResult:
        retry_count = context.get_retry_count()
        metadata = {
            "error_message": context.get_last_error(),
            "retry_count": retry_count,
            "last_attempt_time": datetime.now(timezone.utc),
        }

        if retry_count < self.MAX_RETRIES:
            return StateTransitionResult(
                success=True,
                new_state=FSMState.NEEDS_RETRY,
                trigger=TransitionTrigger.RETRY,
                response_to_send=None,
                should_send_email=False,
                should_route_to_creator=False,
                metadata=metadata,
            )

        return StateTransitionResult(
            success=True,
            new_state=FSMState.REJECTED,
            trigger=TransitionTrigger.RETRY,
            response_to_send=None,
            should_send_email=False,
            should_route_to_creator=False,
            metadata=metadata,
        )


class ErrorDealCreationFailedState(State):
    """Handles deal creation errors with retry logic."""

    MAX_RETRIES = 3

    async def handle(
        self, context: FSMContext, event: FSMEvent
    ) -> StateTransitionResult:
        retry_count = context.get_retry_count()
        metadata = {
            "error_message": context.get_last_error(),
            "retry_count": retry_count,
            "last_attempt_time": datetime.now(timezone.utc),
        }

        if retry_count < self.MAX_RETRIES:
            return StateTransitionResult(
                success=True,
                new_state=FSMState.NEEDS_RETRY,
                trigger=TransitionTrigger.RETRY,
                response_to_send=None,
                should_send_email=False,
                should_route_to_creator=False,
                metadata=metadata,
            )

        return StateTransitionResult(
            success=True,
            new_state=FSMState.REJECTED,
            trigger=TransitionTrigger.RETRY,
            response_to_send=None,
            should_send_email=False,
            should_route_to_creator=False,
            metadata=metadata,
        )


class NeedsRetryState(State):
    """Waits for retry trigger and resets FSM."""

    async def handle(
        self, context: FSMContext, event: FSMEvent
    ) -> StateTransitionResult:
        metadata = {
            "scheduled_retry_time": datetime.now(timezone.utc),
            "retry_count": context.get_retry_count(),
        }
        return StateTransitionResult(
            success=True,
            new_state=FSMState.NEEDS_CLASSIFICATION,
            trigger=TransitionTrigger.RETRY,
            response_to_send=None,
            should_send_email=False,
            should_route_to_creator=False,
            metadata=metadata,
        )
