"""Shared helpers for FSM response text (e.g. rate-range when prospect asks for our rate)."""

import re
from typing import Optional

# Phrases where the prospect is asking for the creator's rate, not stating their budget
_PROSPECT_ASKING_RATE = re.compile(
    r"\b(what('s| is)\s+(your|the)\s+(preferred\s+)?(rate|budget|price)|"
    r"your\s+(preferred\s+)?(rate|budget|price)|"
    r"what\s+do\s+you\s+charge|how\s+much\s+(do\s+you\s+charge|for\s+this)|"
    r"(could|can)\s+you\s+share\s+(your\s+)?(rate|budget|pricing)|"
    r"what('s| are)\s+your\s+rates?)\b",
    re.IGNORECASE,
)


def prospect_asking_for_creator_rate(message: Optional[str]) -> bool:
    """True if the prospect's message is asking for our rate/price, not stating their budget."""
    if not message or not message.strip():
        return False
    return bool(_PROSPECT_ASKING_RATE.search(message))


def build_rate_range_response(creator_name: str, min_rate: float) -> str:
    """Response giving a rate range (min to 100% of min) to keep leverage without shutting down."""
    max_rate = min_rate * 2.0
    min_str = f"{int(min_rate)}" if min_rate == int(min_rate) else f"{min_rate:,.2f}"
    max_str = f"{int(max_rate)}" if max_rate == int(max_rate) else f"{max_rate:,.2f}"
    return (
        f"For this type of project, {creator_name}'s rates typically range from "
        f"${min_str} to ${max_str}, depending on scope. "
        "Happy to discuss what would work for your campaign."
    )


def format_deal_type_for_display(deal_type: str) -> str:
    """Convert deal type string (e.g., 'AFFILIATE' or 'Flat Rate') to human-readable format (e.g., 'Affiliate')."""
    if not deal_type:
        return "partnership"
    
    # Mapping for uppercase codes (e.g., "AFFILIATE", "FLAT_RATE")
    deal_type_mapping = {
        "FLAT_RATE": "Flat Rate",
        "AFFILIATE": "Affiliate",
        "UGC": "UGC",
        "SPONSORED_POST": "Sponsored Post",
        "BRAND_PARTNERSHIP": "Brand Partnership",
        "REVENUE_SHARE": "Revenue Share",
        "PERFORMANCE_HYBRID": "Performance Hybrid",
    }
    
    # Check if it's already in a readable format (contains spaces or is title case)
    if " " in deal_type or deal_type[0].isupper():
        # Already in readable format, return as-is
        return deal_type
    
    # Try mapping from uppercase code
    mapped = deal_type_mapping.get(deal_type.upper())
    if mapped:
        return mapped
    
    # Fallback: title case
    return deal_type.title()


def build_deal_type_rejection_response(creator_name: str, deal_type: str) -> str:
    """Build rejection response for unsupported deal types, asking about flexibility."""
    formatted_deal_type = format_deal_type_for_display(deal_type)
    return (
        f"Unfortunately, {creator_name} is not accepting new {formatted_deal_type} partnerships at this time. "
        f"If there is any flexibility in the partnership structure, we can re-evaluate."
    )
