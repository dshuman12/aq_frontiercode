from dataclasses import dataclass
from typing import List, Optional

from database.models.lead import LeadQualificationData
from database.models.user import UserPreferences

from business.qualification import (
    extract_budget_value,
    determine_deal_type_from_budget,
    is_partnership_type_accepted,
)

from ai_agents.category_matcher import check_category_match, CategoryMatchResult


@dataclass
class ConstraintResult:
    passed: bool
    reasons: List[str]
    category_match_result: Optional[CategoryMatchResult] = None


@dataclass
class NegotiabilityAssessment:
    negotiable: bool
    reasons: List[str]


@dataclass
class QualificationResult:
    recommendation: str  # ACCEPT | NEGOTIATE | REJECT | NEEDS_INFO
    reasons: List[str]
    fit_score: float
    failed_constraints: List[str]
    category_match_result: Optional[CategoryMatchResult] = None


class QualificationAnalyzer:
    """Evaluates whether a lead meets user preferences and business rules.

    Uses AI-powered category matching to determine if a brand's category
    semantically matches any of the creator's auto-reject categories.
    """

    async def analyze(
        self, lead: LeadQualificationData, prefs: UserPreferences
    ) -> QualificationResult:
        print(
            f"[QUALIFICATION] Analyzing lead for qualification:\n"
            f"  Lead budget: {lead.budget}\n"
            f"  Lead category: {lead.brand_category}\n"
            f"  Lead deliverables: {lead.deliverables}\n"
            f"  Creator minimum rate: ${prefs.absoluteMinimumRate}\n"
            f"  Creator auto-reject categories: {prefs.autoRejectCategories}\n"
            f"  Creator partnership types: flatRate={prefs.partnershipTypes.flatRate}, "
            f"affiliate={prefs.partnershipTypes.affiliate}, "
            f"performanceHybrid={prefs.partnershipTypes.performanceHybrid}, "
            f"custom={prefs.partnershipTypes.custom}"
        )

        hard_constraints = await self.check_hard_constraints(lead, prefs)
        if not hard_constraints.passed:
            print(
                f"[QUALIFICATION] RESULT: REJECT - Hard constraints failed: "
                f"{hard_constraints.reasons}"
            )
            return QualificationResult(
                recommendation="REJECT",
                reasons=hard_constraints.reasons,
                fit_score=0.0,
                failed_constraints=hard_constraints.reasons,
                category_match_result=hard_constraints.category_match_result,
            )

        missing_fields = lead.get_missing_fields()
        if missing_fields:
            print(
                f"[QUALIFICATION] RESULT: NEEDS_INFO - Missing fields: "
                f"{', '.join(missing_fields)}"
            )
            return QualificationResult(
                recommendation="NEEDS_INFO",
                reasons=[f"Missing fields: {', '.join(missing_fields)}"],
                fit_score=0.0,
                failed_constraints=[],
            )

        soft_constraints = self.check_soft_constraints(lead, prefs)
        fit_score = await self.calculate_fit_score(
            lead, prefs, hard_constraints.category_match_result
        )
        if not soft_constraints.passed:
            negotiability = self.assess_negotiability(lead, prefs)
            recommendation = "NEGOTIATE" if negotiability.negotiable else "REJECT"
            reasons = soft_constraints.reasons + negotiability.reasons
            print(
                f"[QUALIFICATION] RESULT: {recommendation} - Soft constraints failed: "
                f"{soft_constraints.reasons}, fit_score={fit_score}"
            )
            return QualificationResult(
                recommendation=recommendation,
                reasons=reasons,
                fit_score=fit_score,
                failed_constraints=soft_constraints.reasons,
            )

        print(
            f"[QUALIFICATION] RESULT: ACCEPT - Lead meets all preferences, "
            f"fit_score={fit_score}"
        )
        return QualificationResult(
            recommendation="ACCEPT",
            reasons=["Lead meets preferences"],
            fit_score=fit_score,
            failed_constraints=[],
        )

    async def check_hard_constraints(
        self, lead: LeadQualificationData, prefs: UserPreferences
    ) -> ConstraintResult:
        reasons: List[str] = []
        category_match_result: Optional[CategoryMatchResult] = None

        # Budget guardrail
        budget_value = extract_budget_value(lead.budget or "")
        print(
            f"[QUALIFICATION] Hard constraints check:\n"
            f"  Extracted budget value: ${budget_value}\n"
            f"  Creator minimum rate: ${prefs.absoluteMinimumRate}"
        )

        if budget_value <= 0:
            reasons.append("No budget provided")
            print("[QUALIFICATION] FAIL: No budget provided or could not parse budget")
        elif budget_value < prefs.absoluteMinimumRate:
            reasons.append(
                f"Budget ${budget_value} below minimum ${prefs.absoluteMinimumRate}"
            )
            print(
                f"[QUALIFICATION] FAIL: Budget ${budget_value} is below "
                f"creator's minimum rate ${prefs.absoluteMinimumRate}"
            )
        else:
            print(
                f"[QUALIFICATION] PASS: Budget ${budget_value} meets "
                f"minimum rate ${prefs.absoluteMinimumRate}"
            )

        # Category exclusions - using AI-powered matching
        brand_category = lead.brand_category or ""
        if brand_category and prefs.autoRejectCategories:
            category_match_result = await check_category_match(
                brand_category=brand_category,
                reject_categories=prefs.autoRejectCategories,
            )

            if category_match_result.matches:
                matched_cat = category_match_result.matched_category or "unknown"
                reasons.append(f"Category '{brand_category}' is auto-rejected")
                print(
                    f"[QUALIFICATION] FAIL: Category '{brand_category}' matches "
                    f"auto-reject category '{matched_cat}' "
                    f"(AI confidence: {category_match_result.confidence}, "
                    f"reason: {category_match_result.reasoning})"
                )
            else:
                print(
                    f"[QUALIFICATION] PASS: Category '{brand_category}' is not in reject list "
                    f"(AI reason: {category_match_result.reasoning})"
                )
        else:
            print(
                f"[QUALIFICATION] PASS: Category '{brand_category}' - no reject categories to check"
            )

        # Partnership preferences
        deal_type = determine_deal_type_from_budget(lead.budget or "")
        if not is_partnership_type_accepted(deal_type, prefs.partnershipTypes):
            reasons.append(f"Deal type {deal_type} not accepted")
            print(
                f"[QUALIFICATION] FAIL: Deal type '{deal_type}' not accepted by creator"
            )
        else:
            print(f"[QUALIFICATION] PASS: Deal type '{deal_type}' is accepted")

        passed = len(reasons) == 0
        print(
            f"[QUALIFICATION] Hard constraints result: {'PASSED' if passed else 'FAILED'} "
            f"(failures: {reasons if reasons else 'none'})"
        )
        return ConstraintResult(
            passed=passed, reasons=reasons, category_match_result=category_match_result
        )

    def check_soft_constraints(
        self, lead: LeadQualificationData, prefs: UserPreferences
    ) -> ConstraintResult:
        reasons: List[str] = []
        pass
        return ConstraintResult(passed=len(reasons) == 0, reasons=reasons)

    def assess_negotiability(
        self, lead: LeadQualificationData, prefs: UserPreferences
    ) -> NegotiabilityAssessment:
        reasons: List[str] = []
        budget_value = extract_budget_value(lead.budget or "")
        min_rate = prefs.absoluteMinimumRate
        negotiation_threshold = 0.7 * min_rate
        negotiable = budget_value >= negotiation_threshold

        print(
            f"[QUALIFICATION] Negotiability assessment:\n"
            f"  Budget: ${budget_value}\n"
            f"  Minimum rate: ${min_rate}\n"
            f"  Negotiation threshold (70%): ${negotiation_threshold}\n"
            f"  Negotiable: {negotiable}"
        )

        if negotiable:
            reasons.append("Budget near threshold; negotiable")
        else:
            reasons.append("Budget far below threshold")

        return NegotiabilityAssessment(negotiable=negotiable, reasons=reasons)

    async def calculate_fit_score(
        self,
        lead: LeadQualificationData,
        prefs: UserPreferences,
        category_match_result: Optional[CategoryMatchResult] = None,
    ) -> float:
        """Calculate a fit score for the lead.

        If category_match_result is provided, reuses that result instead of
        making another AI call.
        """
        score = 0.0
        total = 3

        budget_value = extract_budget_value(lead.budget or "")
        if budget_value >= prefs.absoluteMinimumRate:
            score += 1

        # Reuse category match result if available, otherwise check
        if category_match_result is not None:
            category_matches = category_match_result.matches
        elif lead.brand_category and prefs.autoRejectCategories:
            result = await check_category_match(
                brand_category=lead.brand_category,
                reject_categories=prefs.autoRejectCategories,
            )
            category_matches = result.matches
        else:
            category_matches = False

        if not category_matches:
            score += 1

        if lead.deliverables:
            score += 1

        return round((score / total) * 100, 2)
