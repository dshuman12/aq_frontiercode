from dataclasses import dataclass
from typing import List, Optional

from database.models.lead import LeadQualificationData


@dataclass
class FieldInfo:
    name: str
    priority: int


@dataclass
class InfoAnalysis:
    missing_fields: List[FieldInfo]
    suggested_question: str


class InfoAnalyzer:
    """Analyzes completeness of lead information."""

    def analyze_completeness(
        self, lead: LeadQualificationData, latest_message: Optional[str] = None
    ) -> InfoAnalysis:
        missing = self.get_missing_critical_fields(lead)
        question = self.suggest_next_question(missing, latest_message)
        return InfoAnalysis(missing_fields=missing, suggested_question=question)

    def get_missing_critical_fields(self, lead: LeadQualificationData) -> List[FieldInfo]:
        missing_fields = lead.get_missing_fields()
        return sorted(
            [FieldInfo(name=field, priority=self.get_field_priority(field)) for field in missing_fields],
            key=lambda f: f.priority,
        )

    def get_field_priority(self, field_name: str) -> int:
        """Get priority for a missing field.
        
        Note: Contact Type (brand vs agency) is lowest priority as it's often
        auto-detected from research. Contact Title (job title) is NOT in this
        list as it's auto-detected from email signatures and not required.
        """
        priority_map = {
            "Budget": 1,
            "Deliverables": 2,
            "Brand Name": 3,
            "Brand Website": 4,
            "Brand Category": 5,
            "Brand Contact Name": 6,
            "Brand Contact Email": 7,
            "Deadline": 8,
            "Deal Type": 9,
            "Contact Type": 10,  # Brand Direct vs Agency - often auto-detected
        }
        return priority_map.get(field_name, 99)

    def suggest_next_question(
        self, missing_fields: List[FieldInfo], latest_message: Optional[str]
    ) -> str:
        if not missing_fields:
            return ""
        field_names = [field.name for field in missing_fields[:3]]
        fields_formatted = ", ".join(field_names)

        clarifications: List[str] = []
        if latest_message:
            lower_msg = latest_message.lower()
            if "deal type" in lower_msg:
                clarifications.append(
                    "On your deal type question: it's the collaboration structure (flat fee, affiliate/rev share, gifting, hybrid). If you're unsure, tell me your budget or preference and I'll recommend an option."
                )
            if "deadline" in lower_msg or "timeline" in lower_msg:
                clarifications.append(
                    "On your timeline question: it's the go-live date. If you give a relative date like “next month,” I'll convert it to a concrete calendar date."
                )
            if "?" in lower_msg and not clarifications:
                clarifications.append(
                    "Happy to clarify anything you asked above before we proceed."
                )

        clarification_text = (" ".join(clarifications) + " ") if clarifications else ""

        return (
            f"Thanks for the details so far. {clarification_text}Could you share {fields_formatted} so we can evaluate and finalize next steps?"
        )
