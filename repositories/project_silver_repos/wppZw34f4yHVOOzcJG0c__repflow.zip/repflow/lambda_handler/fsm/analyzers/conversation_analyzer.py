from dataclasses import dataclass
from enum import Enum
from typing import Optional

from ..state_machine import FSMState
from ..context import FSMContext


class EngagementLevel(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


@dataclass
class SentimentResult:
    score: float
    label: str
    rationale: Optional[str] = None


class ConversationAnalyzer:
    """Lightweight heuristics for conversation health."""

    def analyze_sentiment(self, conversation_history: str) -> SentimentResult:
        # Placeholder sentiment analysis; real implementation would call an NLP model.
        sentiment_score = 0.0
        if "thank" in conversation_history.lower():
            sentiment_score += 0.2
        return SentimentResult(
            score=sentiment_score,
            label="positive" if sentiment_score > 0 else "neutral",
        )

    def count_ai_follow_ups(self, context: FSMContext) -> int:
        return context.get_follow_up_count()

    def detect_ghosting(self, context: FSMContext) -> bool:
        return self.count_ai_follow_ups(context) >= 4

    def assess_engagement_level(self, conversation_history: str) -> EngagementLevel:
        message_count = conversation_history.count("---")
        if message_count > 6:
            return EngagementLevel.HIGH
        if message_count > 3:
            return EngagementLevel.MEDIUM
        return EngagementLevel.LOW

    def should_trigger_ghosting(
        self, context: FSMContext, state: FSMState
    ) -> bool:
        if state not in {
            FSMState.NEEDS_INFO,
            FSMState.NEEDS_NEGOTIATION,
        }:
            return False
        return self.detect_ghosting(context)
