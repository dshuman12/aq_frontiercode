from typing import Dict, Type

from .state_machine import FSMState
from .states import (
    State,
    NeedsClassificationState,
    NeedsInfoState,
    NeedsEvaluationState,
    NeedsNegotiationState,
    ReadyForDealState,
    ExistingDealState,
    CompleteState,
    RejectedState,
    RejectedNonSponsorshipState,
    GhostedState,
    AbandonedState,
    LostState,
    ErrorClassificationFailedState,
    ErrorDealCreationFailedState,
    NeedsRetryState,
)


class StateRegistry:
    """Registry mapping FSMState enum to State class instances.
    
    This registry validates at import time that all FSMState enum members
    have registered handlers, preventing KeyError issues at runtime.
    """

    _states: Dict[FSMState, Type[State]] = {
        FSMState.NEEDS_CLASSIFICATION: NeedsClassificationState,
        FSMState.NEEDS_INFO: NeedsInfoState,
        FSMState.NEEDS_EVALUATION: NeedsEvaluationState,
        FSMState.NEEDS_NEGOTIATION: NeedsNegotiationState,
        FSMState.READY_FOR_DEAL: ReadyForDealState,
        FSMState.DEAL_CREATED: ExistingDealState,
        FSMState.COMPLETE: CompleteState,
        FSMState.REJECTED: RejectedState,
        FSMState.REJECTED_NON_SPONSORSHIP: RejectedNonSponsorshipState,
        FSMState.GHOSTED: GhostedState,
        FSMState.ABANDONED: AbandonedState,
        FSMState.LOST: LostState,
        FSMState.ERROR_CLASSIFICATION_FAILED: ErrorClassificationFailedState,
        FSMState.ERROR_DEAL_CREATION_FAILED: ErrorDealCreationFailedState,
        FSMState.NEEDS_RETRY: NeedsRetryState,
    }

    @classmethod
    def get_state(cls, state: FSMState) -> State:
        """Get the state handler for a given FSMState.
        
        Args:
            state: The FSMState enum member to look up.
            
        Returns:
            An instance of the corresponding State handler.
            
        Raises:
            ValueError: If the state is not a valid FSMState or not registered.
        """
        # Handle string inputs by converting to FSMState
        if isinstance(state, str):
            try:
                state = FSMState(state)
            except ValueError:
                raise ValueError(
                    f"Invalid state string '{state}'. "
                    f"Valid states are: {[s.value for s in FSMState]}"
                )
        
        # Validate it's actually an FSMState enum member
        if not isinstance(state, FSMState):
            raise ValueError(
                f"Expected FSMState enum, got {type(state).__name__}: {state}"
            )
        
        # Look up the state handler
        state_cls = cls._states.get(state)
        if state_cls is None:
            raise ValueError(
                f"State {state.name} ({state.value}) is not registered. "
                f"Add it to StateRegistry._states."
            )
        
        return state_cls()

    @classmethod
    def validate_registry(cls) -> None:
        """Validate that all FSMState enum members have registered handlers.
        
        This is called at module import time to catch configuration errors early.
        
        Raises:
            RuntimeError: If any FSMState members are missing handlers.
        """
        missing = []
        for state in list(FSMState):
            if state not in cls._states:
                missing.append(state.name)
        
        if missing:
            raise RuntimeError(
                f"StateRegistry is missing handlers for: {', '.join(missing)}. "
                f"Add them to StateRegistry._states in registry.py."
            )


# Validate registry at import time to catch configuration errors early
StateRegistry.validate_registry()

