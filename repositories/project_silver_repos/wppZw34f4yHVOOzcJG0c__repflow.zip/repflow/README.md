# RepFlow - Email Agent

A FastAPI-based application for managing deals with MongoDB integration.

## Features

- MongoDB database integration using Beanie ODM
- CRUD operations for deals management
- JWT authentication with AWS Cognito
- RESTful API endpoints

## Prerequisites

- Python 3.13+
- MongoDB (local or cloud instance)
- AWS Cognito setup (for authentication)

## Installation

1. Clone the repository
2. Install dependencies:
   ```bash
   pipenv install
   ```

3. Set up environment variables:
   ```bash
   # Copy the example file
   cp env.example .env.local
   
   # Edit .env.local with your actual values
   # See docs/ENVIRONMENT_SETUP.md for detailed instructions
   ```
   
   **Quick setup:**
   - Copy `env.example` to `.env.local`
   - Fill in required variables (see `docs/ENVIRONMENT_SETUP.md` for details)
   - Most important: `COGNITO_REGION`, `COGNITO_POOL_ID`, `MONGODB_URL`, `OPENAI_API_KEY`

## Database Setup

The application uses MongoDB with Beanie ODM. The deals collection is automatically created when the application starts.

### MongoDB Connection

The application connects to MongoDB using the following configuration:
- **URL**: `MONGODB_URL` (default: `mongodb://localhost:27017`)
- **Database name**: `MONGODB_DATABASE` (default: `repflow`). Use `repflow` for production and `repflow_dev` for local/dev/staging when both databases live on the same Atlas cluster. See `docs/ENVIRONMENT_SETUP.md` and `docs/DEPLOYMENT-ENVIRONMENTS.md`.
- **Collection**: `deals` (automatically created)

### Deal Model Structure

Each deal document contains:
- `id`: MongoDB ObjectID
- `uuid`: Unique identifier
- `brand_name`: Name of the brand
- `brand_website`: Website URL
- `brand_category`: Industry category
- `contact_name`: Contact person name
- `contact_email`: Contact email
- `contact_type`: Agency or Brand Direct
- `deliverables`: List of required deliverables
- `budget`: Project budget
- `deadline`: Project deadline
- `brand_comment`: Additional comments
- `created_at`: Creation timestamp
- `updated_at`: Last update timestamp

## Running the Application

### Development Mode
```bash
pipenv run dev
```

### Production Mode
```bash
pipenv run start
```

## API Endpoints

### Deals Management

- `GET /deals/` - Get all deals
- `GET /deals/{id}` - Get deal by ID
- `POST /deals/` - Create new deal
- `PUT /deals/{id}` - Update existing deal
- `DELETE /deals/{id}` - Delete deal

### Health Check
- `GET /health` - Application health status

## Authentication

The application uses JWT authentication with AWS Cognito. All deal endpoints require valid authentication.

**How it works:**
- Frontend authenticates users via AWS Cognito
- Cognito issues JWT tokens
- Backend validates tokens using JWKS (JSON Web Key Set) from Cognito
- JWKS contains public keys used to verify JWT signatures

**Setup:**
- Configure `COGNITO_REGION` and `COGNITO_POOL_ID` in `.env.local`
- Backend automatically fetches JWKS from Cognito on startup
- See `docs/ENVIRONMENT_SETUP.md` for detailed setup instructions

**Common Issues:**
- "JWK public key not found" → Check Cognito configuration
- "JWK invalid" → Ensure frontend and backend use the same Cognito User Pool

## Development

### Code Formatting
```bash
pipenv run format
```

### Linting
```bash
pipenv run lint
```

### Testing
```bash
pipenv run test
```

## Project Structure

```
repflow/
├── app.py                 # FastAPI application entry point
├── database/
│   ├── __init__.py
│   ├── database.py        # MongoDB connection and setup
│   └── models/
│       ├── common.py      # Base document model
│       └── deal.py        # Deal model definition
├── routers/
│   ├── deals.py          # Deals API routes
│   └── utils.py          # CRUD utilities
├── auth/
│   └── JWTBearer.py      # JWT authentication
├── Pipfile               # Python dependencies
└── README.md             # This file
```
