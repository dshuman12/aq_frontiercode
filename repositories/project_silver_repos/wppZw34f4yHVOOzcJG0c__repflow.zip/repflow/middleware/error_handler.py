"""
Global exception handler middleware for consistent error responses.
"""

import logging
from typing import Any
from fastapi import Request, Response, HTTPException
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

from utils.error_handler import handle_api_error, create_error_response

logger = logging.getLogger("uvicorn.error")


class ErrorHandlerMiddleware(BaseHTTPMiddleware):
    """Middleware to handle all exceptions and return consistent error responses."""

    async def dispatch(self, request: Request, call_next: Any) -> Response:
        try:
            response = await call_next(request)
            return response
        except Exception as e:
            # Convert the exception to a standardized HTTPException
            http_exception = handle_api_error(e, f"{request.method} {request.url.path}")

            # Extract error details
            status_code = http_exception.status_code
            detail = http_exception.detail

            # Ensure detail is a dictionary for consistent format
            if isinstance(detail, str):
                error_response = create_error_response(
                    message="Error occurred", status_code=status_code, detail=detail
                )
            elif isinstance(detail, dict):
                error_response = detail
            else:
                error_response = create_error_response(
                    message="Error occurred",
                    status_code=status_code,
                    detail=str(detail),
                )

            # Log the error
            logger.error(
                f"Request failed: {request.method} {request.url.path} - {status_code} - {error_response}"
            )

            return JSONResponse(status_code=status_code, content=error_response)


def setup_exception_handlers(app):
    """Setup global exception handlers for the FastAPI app."""

    @app.exception_handler(HTTPException)
    async def http_exception_handler(request: Request, exc: HTTPException):
        """Handle HTTPExceptions with consistent format."""
        # Ensure detail is in consistent format
        if isinstance(exc.detail, str):
            error_response = create_error_response(
                message="HTTP Error", status_code=exc.status_code, detail=exc.detail
            )
        elif isinstance(exc.detail, dict):
            error_response = exc.detail
        else:
            error_response = create_error_response(
                message="HTTP Error",
                status_code=exc.status_code,
                detail=str(exc.detail),
            )

        # Log the error
        logger.warning(
            f"HTTP exception: {request.method} {request.url.path} - {exc.status_code} - {error_response}"
        )

        return JSONResponse(status_code=exc.status_code, content=error_response)

    @app.exception_handler(Exception)
    async def general_exception_handler(request: Request, exc: Exception):
        """Handle unexpected exceptions with consistent format."""
        # Convert to standardized error
        http_exception = handle_api_error(exc, f"{request.method} {request.url.path}")

        return await http_exception_handler(request, http_exception)
