import { colorize, stripColors, createGradient, Colors } from '../../../packages/cli/src/formatters/colors';

describe('Colors', () => {
  describe('colorize', () => {
    it('should apply color codes', () => {
      const result = colorize('test', 'red');
      expect(result).toContain('\x1b[31m');
      expect(result).toContain('\x1b[0m');
      expect(result).toContain('test');
    });

    it('should apply multiple colors', () => {
      const result = colorize('test', 'bold', 'red');
      expect(result).toContain('\x1b[1m');
      expect(result).toContain('\x1b[31m');
    });
  });

  describe('stripColors', () => {
    it('should remove ANSI codes', () => {
      const colored = `${Colors.red}test${Colors.reset}`;
      expect(stripColors(colored)).toBe('test');
    });

    it('should handle plain text', () => {
      expect(stripColors('plain')).toBe('plain');
    });
  });

  describe('createGradient', () => {
    it('should create a gradient string', () => {
      const result = createGradient('hello', [255, 0, 0], [0, 0, 255]);
      expect(result).toContain('h');
      expect(result).toContain('o');
    });
  });
});
