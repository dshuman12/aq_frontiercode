import { Theme } from '../../../packages/cli/src/ui/theme';

describe('Theme', () => {
  let theme: Theme;

  beforeEach(() => {
    theme = new Theme(true);
  });

  describe('color methods', () => {
    it('should apply success color', () => {
      const result = theme.success('ok');
      expect(result).toContain('ok');
    });

    it('should apply error color', () => {
      const result = theme.error('fail');
      expect(result).toContain('fail');
    });

    it('should apply warning color', () => {
      const result = theme.warning('warn');
      expect(result).toContain('warn');
    });

    it('should apply info color', () => {
      const result = theme.info('info');
      expect(result).toContain('info');
    });

    it('should apply dim color', () => {
      const result = theme.dim('dimmed');
      expect(result).toContain('dimmed');
    });

    it('should apply bold', () => {
      const result = theme.bold('bold');
      expect(result).toContain('bold');
    });
  });

  describe('header', () => {
    it('should create a header with borders', () => {
      const result = theme.header('Test Header');
      expect(result).toContain('Test Header');
      expect(result).toContain('─');
    });
  });

  describe('box', () => {
    it('should create a box with title and content', () => {
      const result = theme.box('Title', 'Content line');
      expect(result).toContain('Title');
      expect(result).toContain('Content line');
      expect(result).toContain('╭');
      expect(result).toContain('╰');
    });
  });

  describe('table', () => {
    it('should format headers and rows', () => {
      const result = theme.table(
        ['Name', 'Value'],
        [['foo', 'bar'], ['baz', 'qux']],
      );
      expect(result).toContain('Name');
      expect(result).toContain('foo');
      expect(result).toContain('baz');
    });
  });

  describe('progressBar', () => {
    it('should show progress', () => {
      const result = theme.progressBar(50, 100);
      expect(result).toContain('50%');
    });

    it('should cap at 100%', () => {
      const result = theme.progressBar(200, 100);
      expect(result).toContain('100%');
    });
  });

  describe('badge', () => {
    it('should create a badge', () => {
      const result = theme.badge('PASS', 'success');
      expect(result).toContain('[PASS]');
    });
  });

  describe('keyValue', () => {
    it('should format key-value pair', () => {
      const result = theme.keyValue('name', 'test');
      expect(result).toContain('name');
      expect(result).toContain('test');
    });
  });

  describe('list', () => {
    it('should format unordered list', () => {
      const result = theme.list(['item1', 'item2']);
      expect(result).toContain('item1');
      expect(result).toContain('item2');
    });

    it('should format ordered list', () => {
      const result = theme.list(['first', 'second'], true);
      expect(result).toContain('1.');
      expect(result).toContain('2.');
    });
  });

  describe('no color mode', () => {
    it('should return plain text', () => {
      const noColorTheme = new Theme(false);
      const result = noColorTheme.success('ok');
      expect(result).toBe('ok');
    });
  });
});
