import { TableFormatter } from '../../../packages/cli/src/formatters/table';

describe('TableFormatter', () => {
  let formatter: TableFormatter;

  beforeEach(() => {
    formatter = new TableFormatter();
  });

  describe('format', () => {
    it('should format a simple table', () => {
      const result = formatter.format(
        ['Name', 'Age'],
        [['Alice', '30'], ['Bob', '25']],
      );

      expect(result).toContain('Name');
      expect(result).toContain('Age');
      expect(result).toContain('Alice');
      expect(result).toContain('30');
      expect(result).toContain('Bob');
      expect(result).toContain('25');
    });

    it('should handle empty rows', () => {
      const result = formatter.format(['Header'], []);
      expect(result).toContain('Header');
    });

    it('should handle varying column widths', () => {
      const result = formatter.format(
        ['Short', 'A Longer Header'],
        [['x', 'y'], ['longer cell', 'z']],
      );

      const lines = result.split('\n');
      expect(lines.length).toBe(4);
    });
  });

  describe('formatCompact', () => {
    it('should format without separator', () => {
      const result = formatter.formatCompact(
        ['A', 'B'],
        [['1', '2']],
      );

      const lines = result.split('\n');
      expect(lines.length).toBe(2);
    });
  });

  describe('formatMarkdown', () => {
    it('should format as markdown table', () => {
      const result = formatter.formatMarkdown(
        ['Name', 'Value'],
        [['foo', 'bar']],
      );

      expect(result).toContain('|');
      expect(result).toContain('---');
      expect(result).toContain('foo');
    });
  });
});
