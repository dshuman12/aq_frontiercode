import { ConfigLoader, DEFAULT_CONFIG } from '@commitcraft/core';

describe('ConfigLoader', () => {
  describe('createDefault', () => {
    it('should return a valid default configuration', () => {
      const config = ConfigLoader.createDefault();

      expect(config).toBeDefined();
      expect(config.ai).toBeDefined();
      expect(config.ai.provider).toBe('claude');
      expect(config.ai.model).toBe('claude-sonnet-4-20250514');
      expect(config.commit).toBeDefined();
      expect(config.commit.format).toBeDefined();
      expect(config.git).toBeDefined();
    });
  });

  describe('DEFAULT_CONFIG', () => {
    it('should have all required sections', () => {
      expect(DEFAULT_CONFIG.ai).toBeDefined();
      expect(DEFAULT_CONFIG.commit).toBeDefined();
      expect(DEFAULT_CONFIG.git).toBeDefined();
      expect(DEFAULT_CONFIG.output).toBeDefined();
      expect(DEFAULT_CONFIG.cache).toBeDefined();
    });

    it('should have valid AI defaults', () => {
      expect(DEFAULT_CONFIG.ai.provider).toBe('claude');
      expect(DEFAULT_CONFIG.ai.model).toBe('claude-sonnet-4-20250514');
      expect(DEFAULT_CONFIG.ai.maxTokens).toBeGreaterThan(0);
      expect(DEFAULT_CONFIG.ai.temperature).toBeGreaterThanOrEqual(0);
      expect(DEFAULT_CONFIG.ai.temperature).toBeLessThanOrEqual(1);
    });

    it('should have valid commit defaults', () => {
      expect(DEFAULT_CONFIG.commit.maxSubjectLength).toBe(72);
      expect(typeof DEFAULT_CONFIG.commit.includeBody).toBe('boolean');
    });

    it('should have valid git defaults', () => {
      expect(DEFAULT_CONFIG.git.contextLines).toBeGreaterThanOrEqual(0);
      expect(DEFAULT_CONFIG.git.maxDiffSize).toBeGreaterThan(0);
    });
  });
});
