import {
  generateId,
  hashContent,
  hashDiff,
  generateCacheKey,
  maskApiKey,
  isValidApiKeyFormat,
  constantTimeEqual,
} from '@commitcraft/core';

describe('Crypto Utilities', () => {
  describe('generateId', () => {
    it('should generate a string id', () => {
      const id = generateId();
      expect(typeof id).toBe('string');
      expect(id.length).toBeGreaterThan(0);
    });

    it('should generate unique ids', () => {
      const ids = new Set(Array.from({ length: 100 }, () => generateId()));
      expect(ids.size).toBe(100);
    });

    it('should respect prefix', () => {
      const id = generateId('test');
      expect(id.startsWith('test_')).toBe(true);
    });
  });

  describe('hashContent', () => {
    it('should produce consistent hashes', () => {
      const h1 = hashContent('hello');
      const h2 = hashContent('hello');
      expect(h1).toBe(h2);
    });

    it('should produce different hashes for different content', () => {
      const h1 = hashContent('hello');
      const h2 = hashContent('world');
      expect(h1).not.toBe(h2);
    });

    it('should produce hex string', () => {
      const hash = hashContent('test');
      expect(hash).toMatch(/^[a-f0-9]+$/);
    });
  });

  describe('hashDiff', () => {
    it('should produce a 16-character hash', () => {
      const hash = hashDiff('some diff content');
      expect(hash.length).toBe(16);
    });
  });

  describe('generateCacheKey', () => {
    it('should generate key from parts', () => {
      const key = generateCacheKey(['part1', 'part2', 'part3']);
      expect(typeof key).toBe('string');
      expect(key.length).toBe(24);
    });

    it('should produce consistent keys', () => {
      const k1 = generateCacheKey(['a', 'b']);
      const k2 = generateCacheKey(['a', 'b']);
      expect(k1).toBe(k2);
    });
  });

  describe('maskApiKey', () => {
    it('should mask the middle of the key', () => {
      const masked = maskApiKey('sk-ant-api-1234567890abcdef');
      expect(masked.startsWith('sk-a')).toBe(true);
      expect(masked.endsWith('cdef')).toBe(true);
      expect(masked).toContain('*');
    });

    it('should fully mask short keys', () => {
      const masked = maskApiKey('short');
      expect(masked).toBe('*****');
    });
  });

  describe('isValidApiKeyFormat', () => {
    it('should accept valid Anthropic keys', () => {
      expect(isValidApiKeyFormat('sk-ant-api-very-long-key-here-12345')).toBe(true);
    });

    it('should reject short keys', () => {
      expect(isValidApiKeyFormat('short')).toBe(false);
    });

    it('should reject empty strings', () => {
      expect(isValidApiKeyFormat('')).toBe(false);
    });
  });

  describe('constantTimeEqual', () => {
    it('should return true for equal strings', () => {
      expect(constantTimeEqual('hello', 'hello')).toBe(true);
    });

    it('should return false for different strings', () => {
      expect(constantTimeEqual('hello', 'world')).toBe(false);
    });

    it('should return false for different lengths', () => {
      expect(constantTimeEqual('short', 'longer')).toBe(false);
    });
  });
});
