import {
  DiffAnalyzer,
  DiffParser,
  CommitType,
  FileChangeType,
} from '@commitcraft/core';

describe('DiffAnalyzer', () => {
  let analyzer: DiffAnalyzer;
  let parser: DiffParser;

  beforeEach(() => {
    analyzer = new DiffAnalyzer();
    parser = new DiffParser();
  });

  describe('analyze', () => {
    it('should suggest feat for new file additions', () => {
      const diff = `diff --git a/src/new-feature.ts b/src/new-feature.ts
new file mode 100644
index 0000000..abc1234
--- /dev/null
+++ b/src/new-feature.ts
@@ -0,0 +1,10 @@
+export class NewFeature {
+  private readonly name: string;
+
+  constructor(name: string) {
+    this.name = name;
+  }
+
+  execute(): void {
+  }
+}
`;

      const parsed = parser.parse(diff);
      const result = analyzer.analyze(parsed);

      expect(result.suggestedType).toBe(CommitType.FEAT);
    });

    it('should suggest fix for small changes in existing files', () => {
      const diff = `diff --git a/src/handler.ts b/src/handler.ts
index abc1234..def5678 100644
--- a/src/handler.ts
+++ b/src/handler.ts
@@ -15,3 +15,4 @@
   handle(request: Request): Response {
+    if (!request) throw new Error('Invalid request');
     return processRequest(request);
   }
`;

      const parsed = parser.parse(diff);
      const result = analyzer.analyze(parsed);

      expect([CommitType.FIX, CommitType.FEAT]).toContain(result.suggestedType);
    });

    it('should suggest test for test file changes', () => {
      const diff = `diff --git a/tests/handler.test.ts b/tests/handler.test.ts
new file mode 100644
index 0000000..abc1234
--- /dev/null
+++ b/tests/handler.test.ts
@@ -0,0 +1,15 @@
+describe('Handler', () => {
+  it('should handle valid request', () => {
+    const handler = new Handler();
+    const result = handler.handle({ valid: true });
+    expect(result.status).toBe(200);
+  });
+
+  it('should reject invalid request', () => {
+    const handler = new Handler();
+    expect(() => handler.handle(null)).toThrow();
+  });
+});
`;

      const parsed = parser.parse(diff);
      const result = analyzer.analyze(parsed);

      expect(result.suggestedType).toBe(CommitType.TEST);
    });

    it('should suggest docs for documentation changes', () => {
      const diff = `diff --git a/README.md b/README.md
index abc1234..def5678 100644
--- a/README.md
+++ b/README.md
@@ -1,3 +1,10 @@
 # My Project
 
+## Installation
+
+Run the following command:
+
+\`\`\`bash
+npm install my-project
+\`\`\`
`;

      const parsed = parser.parse(diff);
      const result = analyzer.analyze(parsed);

      expect(result.suggestedType).toBe(CommitType.DOCS);
    });

    it('should assess complexity', () => {
      const diff = `diff --git a/file.ts b/file.ts
index abc1234..def5678 100644
--- a/file.ts
+++ b/file.ts
@@ -1 +1,2 @@
+const x = 1;
 export {};
`;

      const parsed = parser.parse(diff);
      const result = analyzer.analyze(parsed);

      expect(result.complexity).toBeDefined();
      expect(result.complexity.level).toBeDefined();
      expect(result.complexity.score).toBeGreaterThanOrEqual(0);
    });

    it('should handle empty diff', () => {
      const parsed = parser.parse('');
      const result = analyzer.analyze(parsed);

      expect(result.suggestedType).toBe(CommitType.CHORE);
      expect(result.confidence).toBeLessThan(1);
    });
  });
});
