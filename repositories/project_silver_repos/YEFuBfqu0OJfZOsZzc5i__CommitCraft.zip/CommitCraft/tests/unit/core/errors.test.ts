import {
  CommitCraftError,
  ErrorCode,
  isRetryableError,
  formatError,
} from '@commitcraft/core';

describe('CommitCraftError', () => {
  describe('constructor', () => {
    it('should create error with code and message', () => {
      const error = new CommitCraftError(
        ErrorCode.GIT_NOT_REPOSITORY,
        'Not a git repository',
      );

      expect(error.code).toBe(ErrorCode.GIT_NOT_REPOSITORY);
      expect(error.message).toBe('Not a git repository');
      expect(error.name).toBe('CommitCraftError');
      expect(error.timestamp).toBeInstanceOf(Date);
    });

    it('should include details', () => {
      const error = new CommitCraftError(
        ErrorCode.AI_REQUEST_FAILED,
        'Request failed',
        { statusCode: 500, retryable: true },
      );

      expect(error.details.statusCode).toBe(500);
      expect(error.details.retryable).toBe(true);
    });
  });

  describe('toJSON', () => {
    it('should serialize to JSON', () => {
      const error = new CommitCraftError(
        ErrorCode.CONFIG_PARSE_ERROR,
        'Parse error',
      );

      const json = error.toJSON();
      expect(json.name).toBe('CommitCraftError');
      expect(json.code).toBe(ErrorCode.CONFIG_PARSE_ERROR);
      expect(json.message).toBe('Parse error');
      expect(json.timestamp).toBeDefined();
    });
  });

  describe('isCommitCraftError', () => {
    it('should return true for CommitCraftError instances', () => {
      const error = new CommitCraftError(ErrorCode.UNKNOWN_ERROR, 'test');
      expect(CommitCraftError.isCommitCraftError(error)).toBe(true);
    });

    it('should return false for regular errors', () => {
      expect(CommitCraftError.isCommitCraftError(new Error('test'))).toBe(false);
    });
  });

  describe('fromError', () => {
    it('should wrap regular errors', () => {
      const original = new Error('original message');
      const wrapped = CommitCraftError.fromError(original);

      expect(wrapped).toBeInstanceOf(CommitCraftError);
      expect(wrapped.message).toBe('original message');
    });

    it('should return CommitCraftError as-is', () => {
      const original = new CommitCraftError(ErrorCode.AI_TIMEOUT, 'timeout');
      const result = CommitCraftError.fromError(original);
      expect(result).toBe(original);
    });
  });

  describe('wrapAsync', () => {
    it('should return value on success', async () => {
      const result = await CommitCraftError.wrapAsync(
        async () => 42,
        ErrorCode.UNKNOWN_ERROR,
      );
      expect(result).toBe(42);
    });

    it('should wrap thrown errors', async () => {
      await expect(
        CommitCraftError.wrapAsync(
          async () => { throw new Error('fail'); },
          ErrorCode.AI_REQUEST_FAILED,
          'Custom message',
        ),
      ).rejects.toThrow(CommitCraftError);
    });
  });
});

describe('isRetryableError', () => {
  it('should return true for retryable error codes', () => {
    expect(isRetryableError(new CommitCraftError(ErrorCode.AI_RATE_LIMITED, 'rate limited'))).toBe(true);
    expect(isRetryableError(new CommitCraftError(ErrorCode.AI_TIMEOUT, 'timeout'))).toBe(true);
    expect(isRetryableError(new CommitCraftError(ErrorCode.AI_REQUEST_FAILED, 'failed'))).toBe(true);
  });

  it('should return false for non-retryable errors', () => {
    expect(isRetryableError(new CommitCraftError(ErrorCode.AI_INVALID_API_KEY, 'invalid'))).toBe(false);
    expect(isRetryableError(new CommitCraftError(ErrorCode.CONFIG_PARSE_ERROR, 'parse'))).toBe(false);
  });

  it('should return false for regular errors', () => {
    expect(isRetryableError(new Error('test'))).toBe(false);
  });
});

describe('formatError', () => {
  it('should format CommitCraftError', () => {
    const error = new CommitCraftError(ErrorCode.GIT_NOT_REPOSITORY, 'Not a repo');
    expect(formatError(error)).toBe('[GIT_NOT_REPOSITORY] Not a repo');
  });

  it('should format regular errors', () => {
    expect(formatError(new Error('test'))).toBe('test');
  });

  it('should format non-error values', () => {
    expect(formatError('string error')).toBe('string error');
  });
});
