import { FileCategorizer, FileCategory } from '@commitcraft/core';

describe('FileCategorizer', () => {
  let categorizer: FileCategorizer;

  beforeEach(() => {
    categorizer = new FileCategorizer();
  });

  describe('categorize', () => {
    it('should categorize source code files', () => {
      expect(categorizer.categorize('src/index.ts')).toBe(FileCategory.SOURCE);
      expect(categorizer.categorize('lib/utils.py')).toBe(FileCategory.SOURCE);
      expect(categorizer.categorize('main.go')).toBe(FileCategory.SOURCE);
    });

    it('should categorize test files', () => {
      expect(categorizer.categorize('tests/unit.test.ts')).toBe(FileCategory.TEST);
      expect(categorizer.categorize('__tests__/foo.ts')).toBe(FileCategory.TEST);
      expect(categorizer.categorize('spec/bar.spec.js')).toBe(FileCategory.TEST);
      expect(categorizer.categorize('test_handler.py')).toBe(FileCategory.TEST);
    });

    it('should categorize configuration files', () => {
      expect(categorizer.categorize('package.json')).toBe(FileCategory.CONFIG);
      expect(categorizer.categorize('tsconfig.json')).toBe(FileCategory.CONFIG);
      expect(categorizer.categorize('.eslintrc.json')).toBe(FileCategory.CONFIG);
      expect(categorizer.categorize('webpack.config.js')).toBe(FileCategory.CONFIG);
    });

    it('should categorize documentation files', () => {
      expect(categorizer.categorize('README.md')).toBe(FileCategory.DOCUMENTATION);
      expect(categorizer.categorize('docs/guide.md')).toBe(FileCategory.DOCUMENTATION);
      expect(categorizer.categorize('CHANGELOG.md')).toBe(FileCategory.DOCUMENTATION);
    });

    it('should categorize build files', () => {
      expect(categorizer.categorize('Makefile')).toBe(FileCategory.BUILD);
      expect(categorizer.categorize('Dockerfile')).toBe(FileCategory.BUILD);
      expect(categorizer.categorize('build.gradle')).toBe(FileCategory.BUILD);
    });

    it('should categorize CI files', () => {
      expect(categorizer.categorize('.github/workflows/ci.yml')).toBe(FileCategory.CI);
      expect(categorizer.categorize('.circleci/config.yml')).toBe(FileCategory.CI);
      expect(categorizer.categorize('.travis.yml')).toBe(FileCategory.CI);
    });

    it('should categorize dependency files', () => {
      expect(categorizer.categorize('package-lock.json')).toBe(FileCategory.DEPENDENCY);
      expect(categorizer.categorize('yarn.lock')).toBe(FileCategory.DEPENDENCY);
      expect(categorizer.categorize('Cargo.lock')).toBe(FileCategory.DEPENDENCY);
    });

    it('should categorize style files', () => {
      expect(categorizer.categorize('styles.css')).toBe(FileCategory.STYLE);
      expect(categorizer.categorize('theme.scss')).toBe(FileCategory.STYLE);
    });

    it('should categorize assets', () => {
      expect(categorizer.categorize('logo.png')).toBe(FileCategory.ASSET);
      expect(categorizer.categorize('icon.svg')).toBe(FileCategory.ASSET);
      expect(categorizer.categorize('font.woff2')).toBe(FileCategory.ASSET);
    });

    it('should return OTHER for unknown files', () => {
      expect(categorizer.categorize('random.xyz')).toBe(FileCategory.OTHER);
    });
  });
});
