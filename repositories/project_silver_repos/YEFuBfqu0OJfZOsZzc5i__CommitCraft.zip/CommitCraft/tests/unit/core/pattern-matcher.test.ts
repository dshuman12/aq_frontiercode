import { PatternMatcher, CommitType } from '@commitcraft/core';

describe('PatternMatcher', () => {
  let matcher: PatternMatcher;

  beforeEach(() => {
    matcher = new PatternMatcher();
  });

  describe('match', () => {
    it('should match conventional commit patterns', () => {
      const messages = [
        'feat: add login',
        'fix(auth): resolve bug',
        'docs: update readme',
        'chore: bump deps',
      ];

      const matches = matcher.match(messages);
      const conventional = matches.find((m) => m.pattern.name === 'conventional-commit');

      expect(conventional).toBeDefined();
      expect(conventional!.confidence).toBe(1);
    });

    it('should detect merge commit patterns', () => {
      const messages = [
        'Merge branch "feature" into main',
        'Merge pull request #42 from user/branch',
        'feat: normal commit',
      ];

      const matches = matcher.match(messages);
      const merge = matches.find((m) => m.pattern.name === 'merge-commit');

      expect(merge).toBeDefined();
    });

    it('should handle no matches', () => {
      const messages = ['random message', 'another one'];
      const matches = matcher.match(messages);
      const conventional = matches.find((m) => m.pattern.name === 'conventional-commit');
      expect(conventional).toBeUndefined();
    });
  });

  describe('suggestType', () => {
    it('should suggest most common type', () => {
      const messages = [
        'feat: add a',
        'feat: add b',
        'feat: add c',
        'fix: bug d',
      ];

      const suggestion = matcher.suggestType(messages);
      expect(suggestion).not.toBeNull();
      expect(suggestion!.type).toBe(CommitType.FEAT);
      expect(suggestion!.confidence).toBe(0.75);
    });

    it('should return null for non-conventional messages', () => {
      const messages = ['random', 'messages', 'here'];
      const suggestion = matcher.suggestType(messages);
      expect(suggestion).toBeNull();
    });
  });

  describe('suggestScope', () => {
    it('should suggest most common scope', () => {
      const messages = [
        'feat(auth): add login',
        'fix(auth): bug fix',
        'feat(api): endpoint',
      ];

      const suggestion = matcher.suggestScope(messages);
      expect(suggestion).not.toBeNull();
      expect(suggestion!.scope).toBe('auth');
    });

    it('should return null when no scopes used', () => {
      const messages = ['feat: no scope', 'fix: also none'];
      const suggestion = matcher.suggestScope(messages);
      expect(suggestion).toBeNull();
    });
  });

  describe('findSimilar', () => {
    it('should find similar commits', () => {
      const message = {
        type: CommitType.FEAT,
        scope: 'auth',
        subject: 'add user login',
        body: null,
        footer: null,
        breaking: false,
        issues: [],
      };

      const history = [
        'feat(auth): add user registration',
        'fix(db): update schema',
        'feat(auth): add oauth login',
      ];

      const similar = matcher.findSimilar(message, history);
      expect(similar.length).toBeGreaterThan(0);
      expect(similar[0].similarity).toBeGreaterThan(0);
    });
  });
});
