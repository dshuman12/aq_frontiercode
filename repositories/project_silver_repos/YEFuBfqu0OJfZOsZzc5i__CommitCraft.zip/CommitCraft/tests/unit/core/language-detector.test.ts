import { LanguageDetector } from '@commitcraft/core';

describe('LanguageDetector', () => {
  let detector: LanguageDetector;

  beforeEach(() => {
    detector = new LanguageDetector();
  });

  describe('detect', () => {
    it('should detect TypeScript files', () => {
      expect(detector.detect('src/index.ts')).toBe('TypeScript');
      expect(detector.detect('component.tsx')).toBe('TypeScript');
    });

    it('should detect JavaScript files', () => {
      expect(detector.detect('app.js')).toBe('JavaScript');
      expect(detector.detect('component.jsx')).toBe('JavaScript');
    });

    it('should detect Python files', () => {
      expect(detector.detect('main.py')).toBe('Python');
    });

    it('should detect Rust files', () => {
      expect(detector.detect('lib.rs')).toBe('Rust');
    });

    it('should detect Go files', () => {
      expect(detector.detect('main.go')).toBe('Go');
    });

    it('should detect Java files', () => {
      expect(detector.detect('App.java')).toBe('Java');
    });

    it('should detect CSS files', () => {
      expect(detector.detect('styles.css')).toBe('CSS');
      expect(detector.detect('styles.scss')).toBe('SCSS');
    });

    it('should detect markup files', () => {
      expect(detector.detect('index.html')).toBe('HTML');
      expect(detector.detect('template.htm')).toBe('HTML');
    });

    it('should detect special filenames', () => {
      expect(detector.detect('Dockerfile')).toBe('Dockerfile');
      expect(detector.detect('Makefile')).toBe('Makefile');
      expect(detector.detect('.gitignore')).toBe('Git');
    });

    it('should return null for unknown extensions', () => {
      expect(detector.detect('file.xyz')).toBeNull();
    });
  });

  describe('isSourceCode', () => {
    it('should identify source code files', () => {
      expect(detector.isSourceCode('index.ts')).toBe(true);
      expect(detector.isSourceCode('main.py')).toBe(true);
      expect(detector.isSourceCode('lib.rs')).toBe(true);
    });

    it('should not identify non-source files', () => {
      expect(detector.isSourceCode('README.md')).toBe(false);
      expect(detector.isSourceCode('config.json')).toBe(false);
      expect(detector.isSourceCode('image.png')).toBe(false);
    });
  });

  describe('isTestFile', () => {
    it('should identify test files', () => {
      expect(detector.isTestFile('test/index.test.ts')).toBe(true);
      expect(detector.isTestFile('__tests__/foo.ts')).toBe(true);
      expect(detector.isTestFile('spec/bar.spec.js')).toBe(true);
      expect(detector.isTestFile('test_something.py')).toBe(true);
    });

    it('should not identify regular files as test files', () => {
      expect(detector.isTestFile('src/index.ts')).toBe(false);
      expect(detector.isTestFile('utils/helper.js')).toBe(false);
    });
  });

  describe('isConfigFile', () => {
    it('should identify configuration files', () => {
      expect(detector.isConfigFile('package.json')).toBe(true);
      expect(detector.isConfigFile('tsconfig.json')).toBe(true);
      expect(detector.isConfigFile('.eslintrc.json')).toBe(true);
      expect(detector.isConfigFile('.prettierrc')).toBe(true);
      expect(detector.isConfigFile('webpack.config.js')).toBe(true);
    });
  });

  describe('isDocumentation', () => {
    it('should identify documentation files', () => {
      expect(detector.isDocumentation('README.md')).toBe(true);
      expect(detector.isDocumentation('docs/guide.md')).toBe(true);
      expect(detector.isDocumentation('CHANGELOG.md')).toBe(true);
      expect(detector.isDocumentation('LICENSE')).toBe(true);
    });
  });
});
