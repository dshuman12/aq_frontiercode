import {
  ConventionalCommitFormatter,
  CommitType,
  CommitFormat,
} from '@commitcraft/core';

describe('ConventionalCommitFormatter', () => {
  let formatter: ConventionalCommitFormatter;

  beforeEach(() => {
    formatter = new ConventionalCommitFormatter();
  });

  describe('format', () => {
    it('should format a basic commit message', () => {
      const result = formatter.format({
        type: CommitType.FEAT,
        scope: null,
        subject: 'add user authentication',
        body: null,
        footer: null,
        breaking: false,
        issues: [],
      });

      expect(result).toBe('feat: add user authentication');
    });

    it('should format with scope', () => {
      const result = formatter.format({
        type: CommitType.FIX,
        scope: 'auth',
        subject: 'resolve login redirect issue',
        body: null,
        footer: null,
        breaking: false,
        issues: [],
      });

      expect(result).toBe('fix(auth): resolve login redirect issue');
    });

    it('should format with breaking change indicator', () => {
      const result = formatter.format({
        type: CommitType.FEAT,
        scope: 'api',
        subject: 'change response format',
        body: null,
        footer: 'Users must update their API clients',
        breaking: true,
        issues: [],
      });

      expect(result).toContain('feat(api)!:');
      expect(result).toContain('BREAKING CHANGE:');
    });

    it('should format with body', () => {
      const result = formatter.format({
        type: CommitType.REFACTOR,
        scope: null,
        subject: 'restructure database module',
        body: 'This refactors the entire database access layer\nto use the repository pattern.',
        footer: null,
        breaking: false,
        issues: [],
      });

      expect(result).toContain('refactor: restructure database module');
      expect(result).toContain('\n\nThis refactors');
    });

    it('should format with issue references', () => {
      const result = formatter.format({
        type: CommitType.FIX,
        scope: null,
        subject: 'prevent null pointer exception',
        body: null,
        footer: null,
        breaking: false,
        issues: ['#123', '#456'],
      });

      expect(result).toContain('Refs: #123, #456');
    });
  });

  describe('parse', () => {
    it('should parse a simple conventional commit', () => {
      const result = formatter.parse('feat: add new feature');

      expect(result).not.toBeNull();
      expect(result!.type).toBe(CommitType.FEAT);
      expect(result!.subject).toBe('add new feature');
      expect(result!.scope).toBeNull();
    });

    it('should parse commit with scope', () => {
      const result = formatter.parse('fix(parser): handle edge case');

      expect(result).not.toBeNull();
      expect(result!.type).toBe(CommitType.FIX);
      expect(result!.scope).toBe('parser');
      expect(result!.subject).toBe('handle edge case');
    });

    it('should parse breaking change', () => {
      const result = formatter.parse('feat(api)!: change endpoint format');

      expect(result).not.toBeNull();
      expect(result!.breaking).toBe(true);
    });

    it('should parse commit with body', () => {
      const result = formatter.parse(
        'docs: update readme\n\nThis updates the installation instructions\nand adds new examples.',
      );

      expect(result).not.toBeNull();
      expect(result!.body).toContain('installation instructions');
    });

    it('should return null for non-conventional messages', () => {
      expect(formatter.parse('random commit message')).toBeNull();
      expect(formatter.parse('Updated stuff')).toBeNull();
      expect(formatter.parse('')).toBeNull();
    });

    it('should detect conventional format', () => {
      expect(formatter.isConventional('feat: something')).toBe(true);
      expect(formatter.isConventional('fix(scope): something')).toBe(true);
      expect(formatter.isConventional('not conventional')).toBe(false);
    });
  });

  describe('validate', () => {
    it('should validate a correct commit message', () => {
      const result = formatter.validate('feat: add new feature');
      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it('should reject messages without type', () => {
      const result = formatter.validate(': missing type');
      expect(result.valid).toBe(false);
    });

    it('should reject messages without subject', () => {
      const result = formatter.validate('feat:');
      expect(result.valid).toBe(false);
    });
  });
});
