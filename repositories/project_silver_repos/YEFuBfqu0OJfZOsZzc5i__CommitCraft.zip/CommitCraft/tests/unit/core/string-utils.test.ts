import {
  truncate,
  capitalize,
  decapitalize,
  toKebabCase,
  toCamelCase,
  toPascalCase,
  toSnakeCase,
  pluralize,
  wrapText,
  indent,
  dedent,
  stripAnsi,
  escapeRegex,
  hashString,
} from '@commitcraft/core';

describe('String Utilities', () => {
  describe('truncate', () => {
    it('should not truncate short strings', () => {
      expect(truncate('hello', 10)).toBe('hello');
    });

    it('should truncate long strings with ellipsis', () => {
      expect(truncate('hello world', 8)).toBe('hello...');
    });

    it('should use custom suffix', () => {
      expect(truncate('hello world', 8, '--')).toBe('hello --');
    });
  });

  describe('capitalize', () => {
    it('should capitalize first letter', () => {
      expect(capitalize('hello')).toBe('Hello');
    });

    it('should handle empty string', () => {
      expect(capitalize('')).toBe('');
    });
  });

  describe('decapitalize', () => {
    it('should lowercase first letter', () => {
      expect(decapitalize('Hello')).toBe('hello');
    });
  });

  describe('case conversions', () => {
    it('should convert to kebab case', () => {
      expect(toKebabCase('helloWorld')).toBe('hello-world');
      expect(toKebabCase('Hello World')).toBe('hello-world');
    });

    it('should convert to camel case', () => {
      expect(toCamelCase('hello-world')).toBe('helloWorld');
      expect(toCamelCase('hello_world')).toBe('helloWorld');
    });

    it('should convert to pascal case', () => {
      expect(toPascalCase('hello-world')).toBe('HelloWorld');
    });

    it('should convert to snake case', () => {
      expect(toSnakeCase('helloWorld')).toBe('hello_world');
      expect(toSnakeCase('Hello World')).toBe('hello_world');
    });
  });

  describe('pluralize', () => {
    it('should not pluralize for count 1', () => {
      expect(pluralize('file', 1)).toBe('file');
    });

    it('should add s for regular nouns', () => {
      expect(pluralize('file', 2)).toBe('files');
    });

    it('should add es for sibilant endings', () => {
      expect(pluralize('class', 2)).toBe('classes');
      expect(pluralize('box', 2)).toBe('boxes');
    });

    it('should handle y endings', () => {
      expect(pluralize('category', 2)).toBe('categories');
    });

    it('should handle irregular nouns', () => {
      expect(pluralize('child', 2)).toBe('children');
      expect(pluralize('person', 2)).toBe('people');
    });
  });

  describe('wrapText', () => {
    it('should not wrap short text', () => {
      expect(wrapText('short', 72)).toBe('short');
    });

    it('should wrap long text at word boundaries', () => {
      const text = 'This is a very long line that should be wrapped at word boundaries to fit within the specified width';
      const result = wrapText(text, 40);
      const lines = result.split('\n');
      for (const line of lines) {
        expect(line.length).toBeLessThanOrEqual(40);
      }
    });
  });

  describe('indent', () => {
    it('should indent text', () => {
      expect(indent('hello\nworld', 2)).toBe('  hello\n  world');
    });
  });

  describe('dedent', () => {
    it('should remove common indentation', () => {
      const text = '    hello\n    world';
      const result = dedent(text);
      expect(result).toBe('hello\nworld');
    });
  });

  describe('stripAnsi', () => {
    it('should remove ANSI escape codes', () => {
      expect(stripAnsi('\x1b[31mred\x1b[0m')).toBe('red');
    });

    it('should leave plain text unchanged', () => {
      expect(stripAnsi('plain')).toBe('plain');
    });
  });

  describe('escapeRegex', () => {
    it('should escape regex special characters', () => {
      expect(escapeRegex('hello.world')).toBe('hello\\.world');
      expect(escapeRegex('a[b]c')).toBe('a\\[b\\]c');
    });
  });

  describe('hashString', () => {
    it('should produce consistent hashes', () => {
      const h1 = hashString('hello');
      const h2 = hashString('hello');
      expect(h1).toBe(h2);
    });

    it('should produce different hashes for different strings', () => {
      const h1 = hashString('hello');
      const h2 = hashString('world');
      expect(h1).not.toBe(h2);
    });
  });
});
