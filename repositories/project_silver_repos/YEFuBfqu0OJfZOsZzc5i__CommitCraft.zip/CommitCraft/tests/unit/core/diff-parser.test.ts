import { DiffParser, FileChangeType, DiffLineType } from '@commitcraft/core';

describe('DiffParser', () => {
  let parser: DiffParser;

  beforeEach(() => {
    parser = new DiffParser();
  });

  describe('parse', () => {
    it('should parse a simple diff with one file', () => {
      const diff = `diff --git a/src/index.ts b/src/index.ts
index abc1234..def5678 100644
--- a/src/index.ts
+++ b/src/index.ts
@@ -1,3 +1,4 @@
 import { foo } from './foo';
+import { bar } from './bar';
 
 export function main() {
`;

      const result = parser.parse(diff);

      expect(result.files.length).toBe(1);
      expect(result.files[0].path).toBe('src/index.ts');
      expect(result.files[0].changeType).toBe(FileChangeType.MODIFIED);
      expect(result.totalAdditions).toBeGreaterThan(0);
    });

    it('should parse diffs with multiple files', () => {
      const diff = `diff --git a/file1.ts b/file1.ts
index abc1234..def5678 100644
--- a/file1.ts
+++ b/file1.ts
@@ -1,2 +1,3 @@
 line1
+line2
 line3
diff --git a/file2.ts b/file2.ts
new file mode 100644
index 0000000..abc1234
--- /dev/null
+++ b/file2.ts
@@ -0,0 +1,2 @@
+new line1
+new line2
`;

      const result = parser.parse(diff);

      expect(result.files.length).toBe(2);
      expect(result.files[0].path).toBe('file1.ts');
      expect(result.files[1].path).toBe('file2.ts');
      expect(result.files[1].changeType).toBe(FileChangeType.ADDED);
    });

    it('should handle deleted files', () => {
      const diff = `diff --git a/removed.ts b/removed.ts
deleted file mode 100644
index abc1234..0000000
--- a/removed.ts
+++ /dev/null
@@ -1,3 +0,0 @@
-line1
-line2
-line3
`;

      const result = parser.parse(diff);

      expect(result.files.length).toBe(1);
      expect(result.files[0].changeType).toBe(FileChangeType.DELETED);
      expect(result.totalDeletions).toBe(3);
    });

    it('should handle renamed files', () => {
      const diff = `diff --git a/old-name.ts b/new-name.ts
similarity index 100%
rename from old-name.ts
rename to new-name.ts
`;

      const result = parser.parse(diff);

      expect(result.files.length).toBe(1);
      expect(result.files[0].changeType).toBe(FileChangeType.RENAMED);
    });

    it('should handle empty diff', () => {
      const result = parser.parse('');
      expect(result.files.length).toBe(0);
      expect(result.totalAdditions).toBe(0);
      expect(result.totalDeletions).toBe(0);
    });

    it('should count additions and deletions correctly', () => {
      const diff = `diff --git a/file.ts b/file.ts
index abc1234..def5678 100644
--- a/file.ts
+++ b/file.ts
@@ -1,4 +1,4 @@
 kept
-removed1
-removed2
+added1
+added2
+added3
 kept
`;

      const result = parser.parse(diff);

      expect(result.totalAdditions).toBe(3);
      expect(result.totalDeletions).toBe(2);
    });

    it('should respect max size limit', () => {
      const diff = 'a'.repeat(200);
      const result = parser.parse(diff, 100);
      expect(result.truncated).toBe(true);
    });

    it('should parse hunks correctly', () => {
      const diff = `diff --git a/test.ts b/test.ts
index abc1234..def5678 100644
--- a/test.ts
+++ b/test.ts
@@ -10,5 +10,6 @@
 context line
+added line
 context line
@@ -30,3 +31,4 @@
 another context
+another addition
 end
`;

      const result = parser.parse(diff);

      expect(result.files[0].hunks.length).toBe(2);
    });
  });
});
