import { Logger, LogLevel } from '@commitcraft/core';

describe('Logger', () => {
  afterEach(() => {
    Logger.resetInstance();
  });

  describe('getInstance', () => {
    it('should return singleton instance', () => {
      const logger1 = Logger.getInstance();
      const logger2 = Logger.getInstance();
      expect(logger1).toBe(logger2);
    });
  });

  describe('log levels', () => {
    it('should support setting log level', () => {
      const logger = Logger.getInstance({ level: LogLevel.DEBUG });
      logger.setLevel(LogLevel.ERROR);

      const spy = jest.spyOn(process.stdout, 'write').mockImplementation(() => true);
      logger.info('should not appear');
      expect(spy).not.toHaveBeenCalled();
      spy.mockRestore();
    });

    it('should output error messages', () => {
      const logger = Logger.getInstance({ level: LogLevel.ERROR });

      const spy = jest.spyOn(process.stderr, 'write').mockImplementation(() => true);
      logger.error('test error');
      expect(spy).toHaveBeenCalled();
      spy.mockRestore();
    });

    it('should respect log level hierarchy', () => {
      const logger = Logger.getInstance({ level: LogLevel.WARN });

      const stdoutSpy = jest.spyOn(process.stdout, 'write').mockImplementation(() => true);
      const stderrSpy = jest.spyOn(process.stderr, 'write').mockImplementation(() => true);

      logger.debug('debug msg');
      logger.info('info msg');
      expect(stdoutSpy).not.toHaveBeenCalled();

      logger.warn('warn msg');
      expect(stderrSpy).toHaveBeenCalled();

      stdoutSpy.mockRestore();
      stderrSpy.mockRestore();
    });
  });

  describe('resetInstance', () => {
    it('should reset the singleton', () => {
      const logger1 = Logger.getInstance({ level: LogLevel.DEBUG });
      Logger.resetInstance();
      const logger2 = Logger.getInstance({ level: LogLevel.ERROR });
      expect(logger1).not.toBe(logger2);
    });
  });
});
