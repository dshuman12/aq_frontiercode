import { CommitValidator, CommitType } from '@commitcraft/core';

describe('CommitValidator', () => {
  let validator: CommitValidator;

  beforeEach(() => {
    validator = new CommitValidator();
  });

  describe('validate', () => {
    it('should validate a correct commit message', () => {
      const result = validator.validate({
        type: CommitType.FEAT,
        scope: null,
        subject: 'add user authentication',
        body: null,
        footer: null,
        breaking: false,
        issues: [],
      });

      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it('should reject empty subject', () => {
      const result = validator.validate({
        type: CommitType.FEAT,
        scope: null,
        subject: '',
        body: null,
        footer: null,
        breaking: false,
        issues: [],
      });

      expect(result.valid).toBe(false);
      expect(result.errors.length).toBeGreaterThan(0);
    });

    it('should warn about long subject lines', () => {
      const result = validator.validate({
        type: CommitType.FEAT,
        scope: null,
        subject: 'a'.repeat(100),
        body: null,
        footer: null,
        breaking: false,
        issues: [],
      });

      expect(result.warnings.length).toBeGreaterThan(0);
    });

    it('should warn about subjects ending with period', () => {
      const result = validator.validate({
        type: CommitType.FIX,
        scope: null,
        subject: 'fix the bug.',
        body: null,
        footer: null,
        breaking: false,
        issues: [],
      });

      expect(result.warnings.some((w) => w.includes('period'))).toBe(true);
    });

    it('should accept valid scope', () => {
      const result = validator.validate(
        {
          type: CommitType.FEAT,
          scope: 'auth',
          subject: 'add login',
          body: null,
          footer: null,
          breaking: false,
          issues: [],
        },
        { validScopes: ['auth', 'api', 'ui'] },
      );

      expect(result.valid).toBe(true);
    });

    it('should reject invalid scope when scopes are specified', () => {
      const result = validator.validate(
        {
          type: CommitType.FEAT,
          scope: 'unknown',
          subject: 'add login',
          body: null,
          footer: null,
          breaking: false,
          issues: [],
        },
        { validScopes: ['auth', 'api', 'ui'] },
      );

      expect(result.valid).toBe(false);
    });

    it('should validate allowed types', () => {
      const result = validator.validate(
        {
          type: CommitType.CHORE,
          scope: null,
          subject: 'update deps',
          body: null,
          footer: null,
          breaking: false,
          issues: [],
        },
        { allowedTypes: [CommitType.FEAT, CommitType.FIX] },
      );

      expect(result.valid).toBe(false);
    });
  });
});
