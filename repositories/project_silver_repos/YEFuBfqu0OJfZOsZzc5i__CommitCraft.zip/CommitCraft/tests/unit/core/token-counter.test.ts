import { TokenCounter } from '@commitcraft/core';

describe('TokenCounter', () => {
  let counter: TokenCounter;

  beforeEach(() => {
    counter = new TokenCounter();
  });

  describe('count', () => {
    it('should count tokens in a string', () => {
      const count = counter.count('Hello, world! This is a test.');
      expect(count).toBeGreaterThan(0);
    });

    it('should return 0 for empty string', () => {
      expect(counter.count('')).toBe(0);
    });

    it('should handle multi-word strings', () => {
      const short = counter.count('hello');
      const long = counter.count('hello world this is a longer sentence with more words');
      expect(long).toBeGreaterThan(short);
    });
  });

  describe('estimateCost', () => {
    it('should estimate cost for tokens', () => {
      const cost = counter.estimateCost(1000, 500, 'claude-sonnet-4-20250514');
      expect(cost).toBeGreaterThan(0);
    });

    it('should return 0 for zero tokens', () => {
      const cost = counter.estimateCost(0, 0, 'claude-sonnet-4-20250514');
      expect(cost).toBe(0);
    });
  });

  describe('isWithinLimit', () => {
    it('should return true when within limit', () => {
      expect(counter.isWithinLimit('short text', 1000)).toBe(true);
    });

    it('should return false when exceeding limit', () => {
      const longText = 'word '.repeat(10000);
      expect(counter.isWithinLimit(longText, 100)).toBe(false);
    });
  });

  describe('truncateToLimit', () => {
    it('should not truncate short text', () => {
      const text = 'short text';
      const result = counter.truncateToLimit(text, 1000);
      expect(result).toBe(text);
    });

    it('should truncate long text', () => {
      const text = 'word '.repeat(10000);
      const result = counter.truncateToLimit(text, 100);
      expect(counter.count(result)).toBeLessThanOrEqual(100);
    });
  });
});
