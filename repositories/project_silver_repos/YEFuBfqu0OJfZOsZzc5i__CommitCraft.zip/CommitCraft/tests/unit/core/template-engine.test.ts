import { TemplateEngine, CommitType } from '@commitcraft/core';

describe('TemplateEngine', () => {
  let engine: TemplateEngine;

  beforeEach(() => {
    engine = new TemplateEngine();
  });

  describe('render', () => {
    it('should replace simple variables', () => {
      const result = engine.render('{{type}}: {{subject}}', {
        type: 'feat',
        scope: '',
        subject: 'add feature',
        body: '',
        footer: '',
        breaking: false,
        issues: [],
        hasScope: false,
        hasBody: false,
        hasFooter: false,
        hasBreaking: false,
        hasIssues: false,
      });

      expect(result).toBe('feat: add feature');
    });

    it('should handle conditionals', () => {
      const template = '{{type}}{{#if hasScope}}({{scope}}){{/if}}: {{subject}}';

      const withScope = engine.render(template, {
        type: 'feat',
        scope: 'auth',
        subject: 'add login',
        body: '',
        footer: '',
        breaking: false,
        issues: [],
        hasScope: true,
        hasBody: false,
        hasFooter: false,
        hasBreaking: false,
        hasIssues: false,
      });

      expect(withScope).toBe('feat(auth): add login');

      const withoutScope = engine.render(template, {
        type: 'feat',
        scope: '',
        subject: 'add login',
        body: '',
        footer: '',
        breaking: false,
        issues: [],
        hasScope: false,
        hasBody: false,
        hasFooter: false,
        hasBreaking: false,
        hasIssues: false,
      });

      expect(withoutScope).toBe('feat: add login');
    });

    it('should handle else conditionals', () => {
      const template = '{{#if hasBody}}Body: {{body}}{{#else}}No body{{/if}}';

      const withBody = engine.render(template, {
        type: 'feat',
        scope: '',
        subject: 'test',
        body: 'some body',
        footer: '',
        breaking: false,
        issues: [],
        hasScope: false,
        hasBody: true,
        hasFooter: false,
        hasBreaking: false,
        hasIssues: false,
      });

      expect(withBody).toContain('Body: some body');
    });
  });

  describe('helpers', () => {
    it('should support uppercase helper', () => {
      engine.registerHelper('upper', (args) => String(args[0] ?? '').toUpperCase());

      const result = engine.render('{{#upper type}}', {
        type: 'feat',
        scope: '',
        subject: 'test',
        body: '',
        footer: '',
        breaking: false,
        issues: [],
        hasScope: false,
        hasBody: false,
        hasFooter: false,
        hasBreaking: false,
        hasIssues: false,
      });

      expect(result).toBe('FEAT');
    });
  });

  describe('partials', () => {
    it('should resolve partials', () => {
      engine.registerPartial('header', '{{type}}: {{subject}}');

      const result = engine.render('{{> header}}', {
        type: 'feat',
        scope: '',
        subject: 'new feature',
        body: '',
        footer: '',
        breaking: false,
        issues: [],
        hasScope: false,
        hasBody: false,
        hasFooter: false,
        hasBreaking: false,
        hasIssues: false,
      });

      expect(result).toBe('feat: new feature');
    });
  });

  describe('createFromMessage', () => {
    it('should create context from commit message', () => {
      const context = TemplateEngine.createFromMessage({
        type: CommitType.FEAT,
        scope: 'auth',
        subject: 'add login',
        body: 'Some body text',
        footer: null,
        breaking: false,
        issues: ['#123'],
      });

      expect(context.type).toBe('feat');
      expect(context.scope).toBe('auth');
      expect(context.hasScope).toBe(true);
      expect(context.hasBody).toBe(true);
      expect(context.hasFooter).toBe(false);
      expect(context.hasIssues).toBe(true);
    });
  });
});
