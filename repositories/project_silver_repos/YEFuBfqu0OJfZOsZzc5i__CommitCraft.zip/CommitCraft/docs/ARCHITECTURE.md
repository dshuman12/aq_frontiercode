# CommitCraft Architecture

## Overview

CommitCraft is a TypeScript monorepo using npm workspaces. It consists of three packages that share a common core library.

## Package Structure

### @commitcraft/core

The core library provides all shared functionality:

**Types** (`types/`)
- `CommitType` — Enum of 11 conventional commit types
- `CommitMessage` — Interface for structured commit messages
- `CommitCraftConfig` — Full configuration schema
- `DiffFile`, `DiffHunk`, `DiffLine` — Parsed diff structures
- `AIProvider` — Provider abstraction interface

**Config** (`config/`)
- `ConfigLoader` — Loads config from files, environment, and defaults
- `ConfigValidator` — Validates config using Zod schemas
- `DEFAULT_CONFIG` — Sensible defaults for all options

**Git** (`git/`)
- `GitRepository` — Git operations wrapper (using simple-git)
- `DiffParser` — Parses unified diff format into structured data
- `LanguageDetector` — Detects programming languages from file paths
- `StagedFilesAnalyzer` — Analyzes staged files with categorization

**AI** (`ai/`)
- `ClaudeProvider` — Anthropic API integration with retry logic
- `PromptBuilder` — Constructs system and user prompts
- `ResponseParser` — Parses and normalizes AI responses
- `TokenCounter` — Estimates tokens and costs
- `ProviderFactory` — Creates providers from configuration

**Commit** (`commit/`)
- `ConventionalCommitFormatter` — Format/parse/validate conventional commits
- `MessageBuilder` — Orchestrates message generation
- `CommitValidator` — Validates messages against configurable rules
- `CommitFormatter` — Multi-format output (conventional, angular, karma)

**Analysis** (`analysis/`)
- `DiffAnalyzer` — Analyzes diffs for type suggestion and complexity
- `FileCategorizer` — Categorizes files (source, test, config, docs, etc.)
- `ChangeDetector` — Detects specific change types (function, class, import, etc.)

**Templates** (`templates/`)
- `TemplateEngine` — Handlebars-like template rendering
- `BuiltinTemplateRegistry` — Built-in commit message templates
- `CustomTemplateManager` — User-defined templates

**History** (`history/`)
- `CommitHistory` — Analyzes past commit messages
- `PatternMatcher` — Detects commit message patterns

**Cache** (`cache/`)
- `MemoryCache` — In-memory LRU cache with TTL
- `FileCache` — File-system based persistent cache

**Logger** (`logger/`)
- `Logger` — Singleton structured logger with levels and file output

**Utils** (`utils/`)
- Error classes and codes
- String manipulation utilities
- Cryptographic helpers

### commitcraft (CLI)

**Commands** (`commands/`)
- `generate` — Main command: analyze diff, generate message, commit
- `config` — Show/set/get/list/validate configuration
- `init` — Initialize CommitCraft in a repository
- `history` — Analyze commit history patterns
- `hook` — Install/uninstall/status of git hooks

**UI** (`ui/`)
- `Spinner` — Animated progress indicator
- `PromptUI` — Interactive prompts (select, confirm, input, checkbox)
- `DiffDisplay` — Colored diff output with file categorization
- `Theme` — Consistent color and formatting

**Formatters** (`formatters/`)
- `TableFormatter` — ASCII table rendering
- `Colors` — ANSI color utilities

### commitcraft-vscode (VS Code Extension)

**Commands** (`commands/`)
- `generate-message` — Generate commit message from staged changes
- `commit` — Commit with generated/edited message
- `configure` — Quick configuration via command palette
- `history` — Show commit history analysis in webview

**Providers** (`providers/`)
- `StatusBarProvider` — Status bar item with states
- `StagedChangesTreeProvider` — Tree view of staged files
- `HistoryTreeProvider` — Tree view of commit history
- `HoverProvider` — Git blame hover information

**Services** (`services/`)
- `GitService` — Bridge between VS Code git API and core
- `AIService` — AI provider management for extension
- `ConfigService` — VS Code settings wrapper
- `TelemetryService` — Anonymous usage tracking
- `NotificationService` — User notification management

**Webview** (`webview/`)
- `PanelManager` — Webview panel lifecycle management
- `WebviewMessageHandler` — Message passing between extension and webviews

## Data Flow

```
User stages changes
        ↓
Git diff --staged
        ↓
DiffParser.parse()
        ↓
DiffAnalyzer.analyze() + StagedFilesAnalyzer.analyze()
        ↓
PromptBuilder.buildSystemPrompt() + buildUserPrompt()
        ↓
ClaudeProvider.generateCommitMessage()
        ↓
ResponseParser.parse()
        ↓
CommitValidator.validate()
        ↓
ConventionalCommitFormatter.format()
        ↓
User reviews / edits
        ↓
GitRepository.commit()
```

## Configuration Priority

Configuration is resolved in this order (highest to lowest priority):

1. CLI flags / command arguments
2. Environment variables (`COMMITCRAFT_*`)
3. Project config file (`.commitcraft.json` in repo root)
4. Global config file (`~/.commitcraft.json`)
5. VS Code settings (for extension only)
6. Default values

## Error Handling

All errors use the `CommitCraftError` class with typed error codes:
- `CONFIG_*` — Configuration errors
- `GIT_*` — Git operation errors
- `AI_*` — AI provider errors
- `TEMPLATE_*` — Template errors
- `HOOK_*` — Hook execution errors
- `CACHE_*` — Cache errors

Retryable errors (rate limits, timeouts, transient failures) are automatically retried with exponential backoff.

## Security

- API keys are never logged or stored in plain text
- Keys are masked in config output (`sk-a****cdef`)
- No telemetry is sent by default
- Git hooks are validated before installation
