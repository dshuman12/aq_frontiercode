# CommitCraft API Reference

## Core Package (@commitcraft/core)

### GitRepository

```typescript
const repo = new GitRepository(workingDir?: string);

await repo.getRoot();                  // string
await repo.getBranch();                // string
await repo.getStatus();               // StatusResult
await repo.getStagedDiff(options?);    // string
await repo.getStagedFiles();           // StagedFile[]
await repo.getRecentCommits(count);    // string[]
await repo.commit(message, options?);  // string (hash)
await repo.stageFiles(paths);         // void
await repo.unstageFiles(paths);       // void
await repo.getFileContent(path, ref); // string
await repo.getBlame(path);            // BlameInfo[]
await repo.getInfo();                 // RepositoryInfo
await repo.getRepoName();             // string
```

### DiffParser

```typescript
const parser = new DiffParser();
const result = parser.parse(rawDiff, maxSize?);

// Result: ParsedDiff
// - files: DiffFile[]
// - totalAdditions: number
// - totalDeletions: number
// - truncated: boolean
```

### ConfigLoader

```typescript
const loader = new ConfigLoader(searchDir?: string);
const config = await loader.load();

// Static
const defaults = ConfigLoader.createDefault();
```

### MessageBuilder

```typescript
const builder = new MessageBuilder();
const result = await builder.generate(
  provider,      // AIProvider
  parsedDiff,    // ParsedDiff
  options,       // CommitMessageOptions
  context,       // PromptContext
);

// Result: GenerateResult
// - message: CommitMessage
// - formatted: string
// - validation: ValidationResult
// - usage: TokenUsage
// - model: string
// - latency: number
```

### ConventionalCommitFormatter

```typescript
const formatter = new ConventionalCommitFormatter();

formatter.format(message);             // string
formatter.parse(rawMessage);           // CommitMessage | null
formatter.validate(rawMessage);        // ValidationResult
formatter.isConventional(message);     // boolean
```

### CommitValidator

```typescript
const validator = new CommitValidator();

const result = validator.validate(message, options?);
// Result: ValidationResult
// - valid: boolean
// - errors: string[]
// - warnings: string[]
```

### DiffAnalyzer

```typescript
const analyzer = new DiffAnalyzer();
const result = analyzer.analyze(parsedDiff);

// Result: AnalysisResult
// - suggestedType: CommitType
// - confidence: number
// - patterns: Pattern[]
// - complexity: ComplexityAssessment
```

### TemplateEngine

```typescript
const engine = new TemplateEngine();

engine.registerHelper(name, fn);
engine.registerPartial(name, template);
const output = engine.render(template, context);

const context = TemplateEngine.createFromMessage(commitMessage);
```

### MemoryCache

```typescript
const cache = new MemoryCache<T>({ maxEntries: 100, ttl: 3600000 });

cache.set(key, value, ttl?);
cache.get(key);              // T | null
cache.has(key);              // boolean
cache.delete(key);           // boolean
cache.clear();
cache.size();                // number
cache.getStats();            // CacheStats
```

### Logger

```typescript
const logger = Logger.getInstance({ level: LogLevel.INFO });

logger.debug(message, ...args);
logger.info(message, ...args);
logger.warn(message, ...args);
logger.error(message, ...args);
logger.setLevel(level);
```

### Error Handling

```typescript
throw new CommitCraftError(ErrorCode.GIT_NOT_REPOSITORY, 'Not a repo');

CommitCraftError.isCommitCraftError(error);  // boolean
CommitCraftError.fromError(error, code?);    // CommitCraftError
CommitCraftError.wrapAsync(fn, code, msg?);  // Promise<T>

isRetryableError(error);                     // boolean
formatError(error);                          // string
```

## Types

### CommitType

```typescript
enum CommitType {
  FEAT = 'feat',
  FIX = 'fix',
  DOCS = 'docs',
  STYLE = 'style',
  REFACTOR = 'refactor',
  PERF = 'perf',
  TEST = 'test',
  BUILD = 'build',
  CI = 'ci',
  CHORE = 'chore',
  REVERT = 'revert',
}
```

### CommitMessage

```typescript
interface CommitMessage {
  type: CommitType;
  scope: string | null;
  subject: string;
  body: string | null;
  footer: string | null;
  breaking: boolean;
  issues: string[];
}
```

### CommitFormat

```typescript
enum CommitFormat {
  CONVENTIONAL = 'conventional',
  ANGULAR = 'angular',
  KARMA = 'karma',
  CUSTOM = 'custom',
}
```
