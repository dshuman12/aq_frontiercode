# CommitCraft

AI-powered commit message generator for VS Code and CLI. Generate conventional, high-quality commit messages from your staged changes using Claude AI.

## Features

- **AI-Powered Generation** — Analyzes your staged diff and generates conventional commit messages using Claude Sonnet 4
- **VS Code Extension** — One-click "Generate Commit Message" button in the Source Control panel
- **CLI Tool** — Run `commitcraft` in any git repo to generate messages from your terminal
- **Conventional Commits** — Supports feat, fix, docs, style, refactor, perf, test, build, ci, chore, revert types
- **Smart Analysis** — Detects file types, change patterns, and complexity to suggest the right commit type
- **History Analysis** — Analyzes past commits to match your project's conventions
- **Configurable** — Per-repo `.commitcraft.json` config, VS Code settings, environment variables, and CLI flags
- **Git Hooks** — Install prepare-commit-msg or commit-msg hooks for automatic generation or validation
- **Template Engine** — Built-in and custom templates for message formatting
- **Multi-Format** — Conventional Commits, Angular, Karma, and custom formats

## Quick Start

### CLI

```bash
npm install -g commitcraft

# Set your API key
export COMMITCRAFT_API_KEY=sk-ant-your-key

# Stage changes and generate
git add .
commitcraft
```

### VS Code Extension

1. Install "CommitCraft" from the VS Code Marketplace
2. Set your API key in Settings > CommitCraft > AI > API Key
3. Stage your changes
4. Click the sparkle icon in the Source Control panel

## Installation

### CLI (npm)

```bash
npm install -g commitcraft
# or
yarn global add commitcraft
# or
pnpm add -g commitcraft
```

### VS Code Extension

Search for "CommitCraft" in the VS Code Extensions marketplace, or:

```bash
code --install-extension devaansh-kathuria.commitcraft-vscode
```

### From Source

```bash
git clone https://github.com/DevaanshKathuria/Whatsapp-Automation.git commitcraft
cd commitcraft
npm install
npm run build
```

## Configuration

### Config File (.commitcraft.json)

Create a `.commitcraft.json` in your project root:

```json
{
  "ai": {
    "provider": "claude",
    "model": "claude-sonnet-4-20250514"
  },
  "commit": {
    "format": "conventional",
    "maxSubjectLength": 72,
    "includeBody": true,
    "emoji": false,
    "allowedTypes": ["feat", "fix", "docs", "refactor", "test", "chore"]
  },
  "git": {
    "excludePatterns": ["*.lock", "dist/**"],
    "contextLines": 3
  }
}
```

### Environment Variables

| Variable | Description |
|---|---|
| `COMMITCRAFT_API_KEY` | Anthropic API key |
| `COMMITCRAFT_MODEL` | AI model override |
| `COMMITCRAFT_FORMAT` | Commit format override |
| `COMMITCRAFT_MAX_TOKENS` | Max tokens for response |

### VS Code Settings

All settings are under `commitcraft.*`:

| Setting | Default | Description |
|---|---|---|
| `ai.provider` | `claude` | AI provider |
| `ai.model` | `claude-sonnet-4-20250514` | Model to use |
| `ai.apiKey` | — | API key |
| `ai.maxTokens` | `1024` | Max response tokens |
| `ai.temperature` | `0.3` | Generation temperature |
| `commit.format` | `conventional` | Message format |
| `commit.maxSubjectLength` | `72` | Max subject length |
| `commit.includeBody` | `true` | Include body |
| `commit.emoji` | `false` | Use emoji |
| `commit.autoStage` | `false` | Auto-stage all changes |

## CLI Usage

### Generate a commit message

```bash
commitcraft                          # Generate from staged changes
commitcraft gen                      # Alias
commitcraft -t fix                   # Force type
commitcraft -s auth                  # Force scope
commitcraft --dry-run                # Generate without committing
commitcraft -y                       # Auto-confirm
commitcraft --emoji                  # Include emoji
commitcraft --format angular         # Use Angular format
```

### Configuration

```bash
commitcraft init                     # Initialize config in current repo
commitcraft config show              # Show current config
commitcraft config set ai.model claude-3-haiku-20240307
commitcraft config get commit.format
commitcraft config list              # List all options
commitcraft config validate          # Validate config
```

### History Analysis

```bash
commitcraft history analyze          # Analyze commit patterns
commitcraft history types            # Show most used types
commitcraft history scopes           # Show most used scopes
commitcraft history patterns         # Detect patterns
```

### Git Hooks

```bash
commitcraft hook install                      # Install prepare-commit-msg
commitcraft hook install --type commit-msg    # Install commit-msg validator
commitcraft hook uninstall --all              # Remove all hooks
commitcraft hook status                       # Show hook status
```

## Architecture

CommitCraft is built as a TypeScript monorepo with three packages:

```
packages/
├── core/           # Shared library: types, config, git, AI, analysis
│   ├── types/      # TypeScript interfaces and enums
│   ├── config/     # Configuration loading and validation
│   ├── git/        # Git operations, diff parsing, language detection
│   ├── ai/         # AI provider abstraction, prompt building, response parsing
│   ├── commit/     # Commit formatting, validation, conventional commits
│   ├── analysis/   # Diff analysis, file categorization, change detection
│   ├── templates/  # Template engine, built-in and custom templates
│   ├── history/    # Commit history analysis, pattern matching
│   ├── cache/      # In-memory and file-based caching
│   ├── logger/     # Structured logging
│   └── utils/      # Error handling, string utilities, crypto
├── cli/            # Command-line interface
│   ├── commands/   # CLI commands (generate, config, init, history, hook)
│   ├── ui/         # Terminal UI (spinner, prompts, diff display, theme)
│   ├── formatters/ # Output formatting (tables, colors)
│   └── utils/      # Terminal utilities
└── vscode/         # VS Code extension
    ├── commands/   # Extension commands
    ├── providers/  # Status bar, tree views, hover
    ├── services/   # Git, AI, config, telemetry, notifications
    ├── webview/    # Webview panels and message handling
    └── utils/      # Workspace and disposable utilities
```

## Supported Commit Types

| Type | Description | Emoji |
|---|---|---|
| `feat` | New feature | ✨ |
| `fix` | Bug fix | 🐛 |
| `docs` | Documentation | 📝 |
| `style` | Code style (formatting) | 💄 |
| `refactor` | Code refactoring | ♻️ |
| `perf` | Performance improvement | ⚡ |
| `test` | Adding/updating tests | ✅ |
| `build` | Build system changes | 📦 |
| `ci` | CI configuration | 👷 |
| `chore` | Maintenance tasks | 🔧 |
| `revert` | Reverting changes | ⏪ |

## How It Works

1. **Stage Detection** — CommitCraft reads your staged changes via `git diff --staged`
2. **Diff Parsing** — The diff is parsed into structured data (files, hunks, changes)
3. **Analysis** — Changes are analyzed for type, complexity, and patterns
4. **Prompt Building** — A context-rich prompt is constructed with diff summary, file categories, and project context
5. **AI Generation** — Claude generates a conventional commit message based on the analysis
6. **Validation** — The message is validated against configured rules
7. **Preview** — You review, edit, or regenerate before committing

## Development

```bash
# Clone and install
git clone https://github.com/DevaanshKathuria/Whatsapp-Automation.git commitcraft
cd commitcraft
npm install

# Build all packages
npm run build

# Run tests
npm test

# Lint
npm run lint

# Type check
npm run typecheck
```

## Tech Stack

- **Language**: TypeScript 5.3+
- **AI**: Claude Sonnet 4 (Anthropic API)
- **Git**: simple-git
- **CLI**: Commander.js
- **VS Code**: Extension API 1.85+
- **Testing**: Jest
- **Linting**: ESLint + Prettier
- **Build**: TypeScript compiler (tsc)
- **Package Manager**: npm workspaces

## License

MIT
