import * as vscode from 'vscode';

import { WebviewMessage } from './panel-manager';

export type MessageHandler = (payload: unknown) => Promise<void> | void;

export class WebviewMessageHandler {
  private readonly handlers: Map<string, MessageHandler> = new Map();
  private readonly disposables: vscode.Disposable[] = [];

  registerHandler(type: string, handler: MessageHandler): void {
    this.handlers.set(type, handler);
  }

  unregisterHandler(type: string): void {
    this.handlers.delete(type);
  }

  attachToPanel(panel: vscode.WebviewPanel): void {
    const disposable = panel.webview.onDidReceiveMessage(
      async (message: WebviewMessage) => {
        const handler = this.handlers.get(message.type);
        if (handler) {
          try {
            await handler(message.payload);
          } catch (error) {
            const errorMessage = error instanceof Error ? error.message : String(error);
            panel.webview.postMessage({
              type: 'error',
              payload: { message: errorMessage, originalType: message.type },
            }).then(
              () => {},
              () => {},
            );
          }
        }
      },
    );

    this.disposables.push(disposable);
  }

  dispose(): void {
    for (const disposable of this.disposables) {
      disposable.dispose();
    }
    this.disposables.length = 0;
    this.handlers.clear();
  }
}

export function createStandardHandlers(): Map<string, MessageHandler> {
  const handlers = new Map<string, MessageHandler>();

  handlers.set('openSettings', async () => {
    await vscode.commands.executeCommand(
      'workbench.action.openSettings',
      'commitcraft',
    );
  });

  handlers.set('generateMessage', async () => {
    await vscode.commands.executeCommand('commitcraft.generateMessage');
  });

  handlers.set('commit', async () => {
    await vscode.commands.executeCommand('commitcraft.commit');
  });

  handlers.set('showHistory', async () => {
    await vscode.commands.executeCommand('commitcraft.showHistory');
  });

  handlers.set('copyToClipboard', async (payload: unknown) => {
    if (typeof payload === 'string') {
      await vscode.env.clipboard.writeText(payload);
      vscode.window.showInformationMessage('Copied to clipboard');
    }
  });

  handlers.set('openExternal', async (payload: unknown) => {
    if (typeof payload === 'string') {
      await vscode.env.openExternal(vscode.Uri.parse(payload));
    }
  });

  return handlers;
}
