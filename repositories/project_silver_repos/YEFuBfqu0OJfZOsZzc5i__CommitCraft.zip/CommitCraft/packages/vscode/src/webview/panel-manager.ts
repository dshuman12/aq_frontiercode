import * as vscode from 'vscode';

export class PanelManager {
  private readonly panels: Map<string, vscode.WebviewPanel> = new Map();

  createOrShow(
    viewType: string,
    title: string,
    options: PanelOptions = {},
  ): vscode.WebviewPanel {
    const existing = this.panels.get(viewType);
    if (existing) {
      existing.reveal(options.viewColumn ?? vscode.ViewColumn.One);
      return existing;
    }

    const panel = vscode.window.createWebviewPanel(
      viewType,
      title,
      options.viewColumn ?? vscode.ViewColumn.One,
      {
        enableScripts: options.enableScripts ?? true,
        retainContextWhenHidden: options.retainContext ?? false,
        localResourceRoots: options.localResourceRoots,
      },
    );

    panel.onDidDispose(() => {
      this.panels.delete(viewType);
    });

    this.panels.set(viewType, panel);
    return panel;
  }

  get(viewType: string): vscode.WebviewPanel | undefined {
    return this.panels.get(viewType);
  }

  has(viewType: string): boolean {
    return this.panels.has(viewType);
  }

  dispose(viewType: string): void {
    const panel = this.panels.get(viewType);
    if (panel) {
      panel.dispose();
      this.panels.delete(viewType);
    }
  }

  disposeAll(): void {
    for (const panel of this.panels.values()) {
      panel.dispose();
    }
    this.panels.clear();
  }

  setHtml(viewType: string, html: string): void {
    const panel = this.panels.get(viewType);
    if (panel) {
      panel.webview.html = html;
    }
  }

  postMessage(viewType: string, message: WebviewMessage): void {
    const panel = this.panels.get(viewType);
    if (panel) {
      panel.webview.postMessage(message).then(
        () => {},
        () => {},
      );
    }
  }

  onMessage(
    viewType: string,
    handler: (message: WebviewMessage) => void,
  ): vscode.Disposable | null {
    const panel = this.panels.get(viewType);
    if (!panel) return null;

    return panel.webview.onDidReceiveMessage(handler);
  }
}

export interface PanelOptions {
  viewColumn?: vscode.ViewColumn;
  enableScripts?: boolean;
  retainContext?: boolean;
  localResourceRoots?: vscode.Uri[];
}

export interface WebviewMessage {
  type: string;
  payload?: unknown;
}
