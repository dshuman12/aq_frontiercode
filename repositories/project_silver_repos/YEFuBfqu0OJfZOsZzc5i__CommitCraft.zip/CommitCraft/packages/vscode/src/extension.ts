import * as vscode from 'vscode';

import { registerGenerateMessageCommand } from './commands/generate-message';
import { registerCommitCommand } from './commands/commit';
import { registerConfigureCommand } from './commands/configure';
import { registerHistoryCommand } from './commands/history';
import { StatusBarProvider } from './providers/status-bar';
import { StagedChangesTreeProvider } from './providers/tree-view';
import { HistoryTreeProvider } from './providers/history-tree';
import { HoverProvider } from './providers/hover';
import { GitService } from './services/git-service';
import { AIService } from './services/ai-service';
import { ConfigService } from './services/config-service';
import { TelemetryService } from './services/telemetry';
import { NotificationService } from './services/notification';

let outputChannel: vscode.OutputChannel;

export function activate(context: vscode.ExtensionContext): void {
  outputChannel = vscode.window.createOutputChannel('CommitCraft');
  outputChannel.appendLine('CommitCraft extension activated');

  const configService = new ConfigService();
  const gitService = new GitService(outputChannel);
  const aiService = new AIService(configService, outputChannel);
  const telemetryService = new TelemetryService(configService);
  const notificationService = new NotificationService();

  const statusBar = new StatusBarProvider();
  context.subscriptions.push(statusBar);

  const stagedTreeProvider = new StagedChangesTreeProvider(gitService);
  const historyTreeProvider = new HistoryTreeProvider(gitService);

  vscode.window.registerTreeDataProvider('commitcraft.staged', stagedTreeProvider);
  vscode.window.registerTreeDataProvider('commitcraft.history', historyTreeProvider);

  const hoverProvider = new HoverProvider(gitService);
  const hoverRegistration = vscode.languages.registerHoverProvider(
    { scheme: 'file' },
    hoverProvider,
  );
  context.subscriptions.push(hoverRegistration);

  registerGenerateMessageCommand(
    context,
    gitService,
    aiService,
    configService,
    statusBar,
    notificationService,
    telemetryService,
    outputChannel,
  );

  registerCommitCommand(
    context,
    gitService,
    configService,
    statusBar,
    notificationService,
    outputChannel,
  );

  registerConfigureCommand(context, configService, outputChannel);
  registerHistoryCommand(context, gitService, outputChannel);

  context.subscriptions.push(
    vscode.commands.registerCommand('commitcraft.regenerate', async () => {
      await vscode.commands.executeCommand('commitcraft.generateMessage');
    }),
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('commitcraft.selectAlternative', async () => {
      notificationService.showInfo('Alternative selection is available after generating a message');
    }),
  );

  context.subscriptions.push(
    vscode.workspace.onDidChangeConfiguration((event) => {
      if (event.affectsConfiguration('commitcraft')) {
        configService.reload();
        aiService.reconfigure(configService);
        outputChannel.appendLine('Configuration reloaded');
      }
    }),
  );

  context.subscriptions.push(outputChannel);

  statusBar.setReady();
  outputChannel.appendLine('CommitCraft ready');
}

export function deactivate(): void {
  outputChannel?.appendLine('CommitCraft extension deactivated');
}
