import * as vscode from 'vscode';

import {
  DiffParser,
  MessageBuilder,
  DiffAnalyzer,
  StagedFilesAnalyzer,
  CommitMessageOptions,
  CommitFormat,
  PromptContext,
} from '@commitcraft/core';

import { GitService } from '../services/git-service';
import { AIService } from '../services/ai-service';
import { ConfigService } from '../services/config-service';
import { StatusBarProvider } from '../providers/status-bar';
import { NotificationService } from '../services/notification';
import { TelemetryService } from '../services/telemetry';

let lastGeneratedMessage: string | null = null;

export function registerGenerateMessageCommand(
  context: vscode.ExtensionContext,
  gitService: GitService,
  aiService: AIService,
  configService: ConfigService,
  statusBar: StatusBarProvider,
  notificationService: NotificationService,
  telemetryService: TelemetryService,
  outputChannel: vscode.OutputChannel,
): void {
  const disposable = vscode.commands.registerCommand(
    'commitcraft.generateMessage',
    async () => {
      try {
        statusBar.setGenerating();
        outputChannel.appendLine('Generating commit message...');

        const repo = gitService.getRepository();
        if (!repo) {
          notificationService.showError('No git repository found. Open a folder with a git repository.');
          statusBar.setReady();
          return;
        }

        const hasStagedChanges = await gitService.hasStagedChanges();
        if (!hasStagedChanges) {
          const autoStage = configService.get<boolean>('commit.autoStage', false);

          if (autoStage) {
            await gitService.stageAll();
            outputChannel.appendLine('Auto-staged all changes');
          } else {
            const action = await vscode.window.showWarningMessage(
              'No staged changes. Stage all changes?',
              'Stage All',
              'Cancel',
            );

            if (action === 'Stage All') {
              await gitService.stageAll();
            } else {
              statusBar.setReady();
              return;
            }
          }
        }

        const diff = await gitService.getStagedDiff();
        if (!diff || diff.trim().length === 0) {
          notificationService.showWarning('Staged diff is empty');
          statusBar.setReady();
          return;
        }

        const diffParser = new DiffParser();
        const parsedDiff = diffParser.parse(diff, 50000);

        const diffAnalyzer = new DiffAnalyzer();
        const analysis = diffAnalyzer.analyze(parsedDiff);

        outputChannel.appendLine(`Analysis: type=${analysis.suggestedType}, confidence=${Math.round(analysis.confidence * 100)}%`);

        const coreRepo = gitService.getCoreRepository();
        let recentCommits: string[] = [];
        let repoName = 'unknown';
        let branchName = 'main';

        if (coreRepo) {
          recentCommits = await coreRepo.getRecentCommits(5);
          repoName = await coreRepo.getRepoName();
          branchName = await coreRepo.getBranch();
        }

        const stagedReport = coreRepo
          ? await new StagedFilesAnalyzer(coreRepo).analyze()
          : null;

        const commitOptions: CommitMessageOptions = {
          maxSubjectLength: configService.get<number>('commit.maxSubjectLength', 72),
          includeBody: configService.get<boolean>('commit.includeBody', true),
          includeFooter: false,
          includeBreakingChanges: true,
          includeIssueReferences: true,
          format: configService.get<CommitFormat>('commit.format', CommitFormat.CONVENTIONAL),
          language: 'en',
          emoji: configService.get<boolean>('commit.emoji', false),
        };

        const context: PromptContext = {
          repoName,
          branchName,
          recentCommits,
          fileCategories: stagedReport
            ? Object.fromEntries(
                [...stagedReport.categories.entries()].map(([k, v]) => [k, v.length]),
              )
            : {},
          projectType: stagedReport?.summary.primaryLanguage ?? null,
          conventionExamples: recentCommits.filter((c) => /^\w+(\([^)]+\))?!?:/.test(c)),
          additionalContext: null,
        };

        const provider = aiService.getProvider();
        if (!provider) {
          const action = await vscode.window.showErrorMessage(
            'API key not configured. Set it in settings.',
            'Open Settings',
          );
          if (action === 'Open Settings') {
            await vscode.commands.executeCommand(
              'workbench.action.openSettings',
              'commitcraft.ai.apiKey',
            );
          }
          statusBar.setReady();
          return;
        }

        const messageBuilder = new MessageBuilder();
        const result = await messageBuilder.generate(
          provider,
          parsedDiff,
          commitOptions,
          context,
        );

        lastGeneratedMessage = result.formatted;

        const scmInput = gitService.getScmInputBox();
        if (scmInput) {
          scmInput.value = result.formatted;
        }

        statusBar.setReady();

        const costInfo = `Tokens: ${result.usage.totalTokens} | Cost: $${result.usage.estimatedCost.toFixed(6)} | ${result.latency}ms`;
        outputChannel.appendLine(`Generated: ${result.formatted.split('\n')[0]}`);
        outputChannel.appendLine(costInfo);

        notificationService.showInfo(`Commit message generated (${costInfo})`);

        telemetryService.trackEvent('message_generated', {
          type: result.message.type,
          model: result.model,
          tokens: result.usage.totalTokens,
          latency: result.latency,
        });

        provider.dispose();
      } catch (error) {
        statusBar.setError();

        const message = error instanceof Error ? error.message : String(error);
        outputChannel.appendLine(`Error: ${message}`);
        notificationService.showError(`Failed to generate: ${message}`);
      }
    },
  );

  context.subscriptions.push(disposable);
}

export function getLastGeneratedMessage(): string | null {
  return lastGeneratedMessage;
}
