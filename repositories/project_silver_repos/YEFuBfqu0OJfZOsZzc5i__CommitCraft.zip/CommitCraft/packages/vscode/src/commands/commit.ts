import * as vscode from 'vscode';

import { GitService } from '../services/git-service';
import { ConfigService } from '../services/config-service';
import { StatusBarProvider } from '../providers/status-bar';
import { NotificationService } from '../services/notification';

export function registerCommitCommand(
  context: vscode.ExtensionContext,
  gitService: GitService,
  configService: ConfigService,
  statusBar: StatusBarProvider,
  notificationService: NotificationService,
  outputChannel: vscode.OutputChannel,
): void {
  const disposable = vscode.commands.registerCommand(
    'commitcraft.commit',
    async () => {
      try {
        const repo = gitService.getRepository();
        if (!repo) {
          notificationService.showError('No git repository found');
          return;
        }

        const scmInput = gitService.getScmInputBox();
        const message = scmInput?.value;

        if (!message || message.trim().length === 0) {
          const action = await vscode.window.showWarningMessage(
            'No commit message. Generate one first?',
            'Generate',
            'Cancel',
          );

          if (action === 'Generate') {
            await vscode.commands.executeCommand('commitcraft.generateMessage');
          }
          return;
        }

        const hasStagedChanges = await gitService.hasStagedChanges();
        if (!hasStagedChanges) {
          const action = await vscode.window.showWarningMessage(
            'No staged changes. Stage all changes?',
            'Stage All',
            'Cancel',
          );

          if (action === 'Stage All') {
            await gitService.stageAll();
          } else {
            return;
          }
        }

        statusBar.setCommitting();

        const coreRepo = gitService.getCoreRepository();
        if (coreRepo) {
          const signOff = configService.get<boolean>('commit.signOff', false);
          const gpgSign = configService.get<boolean>('commit.gpgSign', false);

          const commitHash = await coreRepo.commit(message, {
            signOff,
            gpgSign,
          });

          if (scmInput) {
            scmInput.value = '';
          }

          outputChannel.appendLine(`Committed: ${commitHash.substring(0, 8)} - ${message.split('\n')[0]}`);

          statusBar.setReady();
          notificationService.showInfo(`Committed: ${commitHash.substring(0, 8)}`);
        } else {
          await vscode.commands.executeCommand('git.commit');

          if (scmInput) {
            scmInput.value = '';
          }

          statusBar.setReady();
          outputChannel.appendLine(`Committed via VS Code git: ${message.split('\n')[0]}`);
        }
      } catch (error) {
        statusBar.setError();

        const errorMessage = error instanceof Error ? error.message : String(error);
        outputChannel.appendLine(`Commit error: ${errorMessage}`);
        notificationService.showError(`Commit failed: ${errorMessage}`);
      }
    },
  );

  context.subscriptions.push(disposable);
}
