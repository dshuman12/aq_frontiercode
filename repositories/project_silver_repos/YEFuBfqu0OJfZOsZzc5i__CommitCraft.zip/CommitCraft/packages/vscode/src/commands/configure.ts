import * as vscode from 'vscode';

import { ConfigService } from '../services/config-service';

export function registerConfigureCommand(
  context: vscode.ExtensionContext,
  configService: ConfigService,
  outputChannel: vscode.OutputChannel,
): void {
  const disposable = vscode.commands.registerCommand(
    'commitcraft.configure',
    async () => {
      const options = [
        {
          label: '$(key) Set API Key',
          description: 'Configure your Anthropic API key',
          action: 'apiKey',
        },
        {
          label: '$(symbol-enum) Change Model',
          description: 'Select AI model',
          action: 'model',
        },
        {
          label: '$(symbol-number) Max Subject Length',
          description: `Current: ${configService.get<number>('commit.maxSubjectLength', 72)}`,
          action: 'maxLength',
        },
        {
          label: '$(symbol-boolean) Include Body',
          description: `Current: ${configService.get<boolean>('commit.includeBody', true)}`,
          action: 'includeBody',
        },
        {
          label: '$(smiley) Emoji',
          description: `Current: ${configService.get<boolean>('commit.emoji', false)}`,
          action: 'emoji',
        },
        {
          label: '$(settings-gear) Open Settings',
          description: 'Open VS Code settings for CommitCraft',
          action: 'openSettings',
        },
      ];

      const selected = await vscode.window.showQuickPick(options, {
        placeHolder: 'Configure CommitCraft',
      });

      if (!selected) return;

      switch (selected.action) {
        case 'apiKey': {
          const key = await vscode.window.showInputBox({
            prompt: 'Enter your Anthropic API key',
            password: true,
            placeHolder: 'sk-ant-...',
          });

          if (key) {
            await configService.set('ai.apiKey', key);
            outputChannel.appendLine('API key updated');
            vscode.window.showInformationMessage('API key saved');
          }
          break;
        }

        case 'model': {
          const models = [
            {
              label: 'Claude Sonnet 4',
              description: 'claude-sonnet-4-20250514 - Best quality',
              value: 'claude-sonnet-4-20250514',
            },
            {
              label: 'Claude 3.5 Sonnet',
              description: 'claude-3-5-sonnet-20241022 - High quality',
              value: 'claude-3-5-sonnet-20241022',
            },
            {
              label: 'Claude 3 Haiku',
              description: 'claude-3-haiku-20240307 - Fast and cheap',
              value: 'claude-3-haiku-20240307',
            },
          ];

          const model = await vscode.window.showQuickPick(models, {
            placeHolder: 'Select AI model',
          });

          if (model) {
            await configService.set('ai.model', model.value);
            outputChannel.appendLine(`Model changed to ${model.value}`);
          }
          break;
        }

        case 'maxLength': {
          const length = await vscode.window.showInputBox({
            prompt: 'Maximum subject line length',
            value: String(configService.get<number>('commit.maxSubjectLength', 72)),
            validateInput: (value) => {
              const num = parseInt(value, 10);
              if (isNaN(num) || num < 20 || num > 200) {
                return 'Enter a number between 20 and 200';
              }
              return null;
            },
          });

          if (length) {
            await configService.set('commit.maxSubjectLength', parseInt(length, 10));
          }
          break;
        }

        case 'includeBody': {
          const current = configService.get<boolean>('commit.includeBody', true);
          await configService.set('commit.includeBody', !current);
          vscode.window.showInformationMessage(
            `Include body: ${!current ? 'enabled' : 'disabled'}`,
          );
          break;
        }

        case 'emoji': {
          const current = configService.get<boolean>('commit.emoji', false);
          await configService.set('commit.emoji', !current);
          vscode.window.showInformationMessage(
            `Emoji: ${!current ? 'enabled' : 'disabled'}`,
          );
          break;
        }

        case 'openSettings': {
          await vscode.commands.executeCommand(
            'workbench.action.openSettings',
            'commitcraft',
          );
          break;
        }
      }
    },
  );

  context.subscriptions.push(disposable);
}
