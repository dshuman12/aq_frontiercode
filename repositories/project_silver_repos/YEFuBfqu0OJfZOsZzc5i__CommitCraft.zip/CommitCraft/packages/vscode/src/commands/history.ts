import * as vscode from 'vscode';

import { CommitHistory } from '@commitcraft/core';

import { GitService } from '../services/git-service';

export function registerHistoryCommand(
  context: vscode.ExtensionContext,
  gitService: GitService,
  outputChannel: vscode.OutputChannel,
): void {
  const disposable = vscode.commands.registerCommand(
    'commitcraft.showHistory',
    async () => {
      try {
        const coreRepo = gitService.getCoreRepository();
        if (!coreRepo) {
          vscode.window.showErrorMessage('No git repository found');
          return;
        }

        const history = new CommitHistory(coreRepo);

        await vscode.window.withProgress(
          {
            location: vscode.ProgressLocation.Notification,
            title: 'Analyzing commit history...',
            cancellable: false,
          },
          async () => {
            const analysis = await history.analyze(100);

            const panel = vscode.window.createWebviewPanel(
              'commitcraft.historyAnalysis',
              'CommitCraft - History Analysis',
              vscode.ViewColumn.One,
              { enableScripts: true },
            );

            panel.webview.html = buildHistoryHtml(analysis);

            outputChannel.appendLine(
              `History analysis: ${analysis.entries.length} commits, ${analysis.conventionalPercentage}% conventional`,
            );
          },
        );
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        outputChannel.appendLine(`History error: ${message}`);
        vscode.window.showErrorMessage(`Failed to analyze history: ${message}`);
      }
    },
  );

  context.subscriptions.push(disposable);
}

interface HistoryAnalysisData {
  entries: Array<{ isConventional: boolean }>;
  conventionalPercentage: number;
  typeDistribution: Record<string, number>;
  scopeDistribution: Record<string, number>;
  averageSubjectLength: number;
  consistencyScore: number;
  commonPatterns: string[];
}

function buildHistoryHtml(analysis: HistoryAnalysisData): string {
  const typeRows = Object.entries(analysis.typeDistribution)
    .sort((a, b) => b[1] - a[1])
    .map(
      ([type, count]) =>
        `<tr><td>${type}</td><td>${count}</td><td>${Math.round((count / analysis.entries.length) * 100)}%</td></tr>`,
    )
    .join('');

  const scopeRows = Object.entries(analysis.scopeDistribution)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .map(([scope, count]) => `<tr><td>${scope}</td><td>${count}</td></tr>`)
    .join('');

  const patterns = analysis.commonPatterns
    .map((p) => `<li>${p}</li>`)
    .join('');

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>CommitCraft History Analysis</title>
<style>
body { font-family: var(--vscode-font-family); color: var(--vscode-foreground); background: var(--vscode-editor-background); padding: 20px; }
h1 { color: var(--vscode-textLink-foreground); }
h2 { color: var(--vscode-textLink-activeForeground); margin-top: 24px; }
.stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin: 16px 0; }
.stat-card { background: var(--vscode-editor-inactiveSelectionBackground); padding: 16px; border-radius: 8px; }
.stat-value { font-size: 24px; font-weight: bold; color: var(--vscode-textLink-foreground); }
.stat-label { font-size: 12px; opacity: 0.7; }
table { width: 100%; border-collapse: collapse; margin: 8px 0; }
th, td { text-align: left; padding: 8px 12px; border-bottom: 1px solid var(--vscode-panel-border); }
th { font-weight: bold; opacity: 0.8; }
ul { padding-left: 20px; }
li { margin: 4px 0; }
</style>
</head>
<body>
<h1>Commit History Analysis</h1>
<div class="stats">
<div class="stat-card"><div class="stat-value">${analysis.entries.length}</div><div class="stat-label">Total Commits</div></div>
<div class="stat-card"><div class="stat-value">${analysis.conventionalPercentage}%</div><div class="stat-label">Conventional</div></div>
<div class="stat-card"><div class="stat-value">${analysis.averageSubjectLength}</div><div class="stat-label">Avg Subject Length</div></div>
<div class="stat-card"><div class="stat-value">${analysis.consistencyScore}/100</div><div class="stat-label">Consistency Score</div></div>
</div>
<h2>Type Distribution</h2>
<table><tr><th>Type</th><th>Count</th><th>Percentage</th></tr>${typeRows}</table>
${scopeRows ? `<h2>Top Scopes</h2><table><tr><th>Scope</th><th>Count</th></tr>${scopeRows}</table>` : ''}
${patterns ? `<h2>Patterns</h2><ul>${patterns}</ul>` : ''}
</body>
</html>`;
}
