import * as vscode from 'vscode';

import { CommitHistory } from '@commitcraft/core';

import { GitService } from '../services/git-service';

export class HistoryTreeProvider implements vscode.TreeDataProvider<HistoryItem> {
  private readonly onDidChangeTreeDataEmitter = new vscode.EventEmitter<HistoryItem | undefined>();
  readonly onDidChangeTreeData = this.onDidChangeTreeDataEmitter.event;

  private readonly gitService: GitService;

  constructor(gitService: GitService) {
    this.gitService = gitService;
  }

  refresh(): void {
    this.onDidChangeTreeDataEmitter.fire(undefined);
  }

  getTreeItem(element: HistoryItem): vscode.TreeItem {
    return element;
  }

  async getChildren(_element?: HistoryItem): Promise<HistoryItem[]> {
    const coreRepo = this.gitService.getCoreRepository();
    if (!coreRepo) {
      return [
        new HistoryItem(
          'No repository found',
          '',
          vscode.TreeItemCollapsibleState.None,
          'info',
        ),
      ];
    }

    try {
      const history = new CommitHistory(coreRepo);
      const entries = await history.getHistory(20);

      if (entries.length === 0) {
        return [
          new HistoryItem(
            'No commits yet',
            '',
            vscode.TreeItemCollapsibleState.None,
            'info',
          ),
        ];
      }

      return entries.map((entry) => {
        const subject = entry.message.split('\n')[0];
        const shortHash = entry.hash.substring(0, 8);
        const date = entry.date.toLocaleDateString();

        const icon = entry.isConventional ? 'pass' : 'circle-outline';

        const item = new HistoryItem(
          subject,
          `${shortHash} • ${date}`,
          vscode.TreeItemCollapsibleState.None,
          'commit',
        );

        item.iconPath = new vscode.ThemeIcon(icon);
        item.tooltip = [
          `Hash: ${entry.hash}`,
          `Author: ${entry.author}`,
          `Date: ${entry.date.toISOString()}`,
          `Conventional: ${entry.isConventional ? 'Yes' : 'No'}`,
          '',
          entry.message,
        ].join('\n');

        return item;
      });
    } catch {
      return [
        new HistoryItem(
          'Error loading history',
          '',
          vscode.TreeItemCollapsibleState.None,
          'error',
        ),
      ];
    }
  }

  dispose(): void {
    this.onDidChangeTreeDataEmitter.dispose();
  }
}

export class HistoryItem extends vscode.TreeItem {
  constructor(
    public readonly label: string,
    public readonly description: string,
    public readonly collapsibleState: vscode.TreeItemCollapsibleState,
    public readonly itemType: 'commit' | 'info' | 'error',
  ) {
    super(label, collapsibleState);

    if (itemType === 'info') {
      this.iconPath = new vscode.ThemeIcon('info');
    } else if (itemType === 'error') {
      this.iconPath = new vscode.ThemeIcon('error');
    }
  }
}
