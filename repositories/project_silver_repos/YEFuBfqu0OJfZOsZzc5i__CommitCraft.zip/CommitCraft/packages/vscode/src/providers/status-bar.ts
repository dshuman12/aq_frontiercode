import * as vscode from 'vscode';

export class StatusBarProvider implements vscode.Disposable {
  private readonly statusBarItem: vscode.StatusBarItem;

  constructor() {
    this.statusBarItem = vscode.window.createStatusBarItem(
      vscode.StatusBarAlignment.Left,
      100,
    );
    this.statusBarItem.command = 'commitcraft.generateMessage';
    this.setReady();
    this.statusBarItem.show();
  }

  setReady(): void {
    this.statusBarItem.text = '$(sparkle) CommitCraft';
    this.statusBarItem.tooltip = 'Click to generate a commit message';
    this.statusBarItem.backgroundColor = undefined;
  }

  setGenerating(): void {
    this.statusBarItem.text = '$(loading~spin) Generating...';
    this.statusBarItem.tooltip = 'Generating commit message...';
    this.statusBarItem.backgroundColor = undefined;
  }

  setCommitting(): void {
    this.statusBarItem.text = '$(sync~spin) Committing...';
    this.statusBarItem.tooltip = 'Creating commit...';
    this.statusBarItem.backgroundColor = undefined;
  }

  setError(): void {
    this.statusBarItem.text = '$(error) CommitCraft';
    this.statusBarItem.tooltip = 'An error occurred. Click to retry.';
    this.statusBarItem.backgroundColor = new vscode.ThemeColor(
      'statusBarItem.errorBackground',
    );
  }

  setSuccess(): void {
    this.statusBarItem.text = '$(pass) CommitCraft';
    this.statusBarItem.tooltip = 'Commit created successfully';
    this.statusBarItem.backgroundColor = undefined;

    setTimeout(() => this.setReady(), 3000);
  }

  dispose(): void {
    this.statusBarItem.dispose();
  }
}
