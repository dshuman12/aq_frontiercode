import * as vscode from 'vscode';

import { GitService } from '../services/git-service';

export class HoverProvider implements vscode.HoverProvider {
  private readonly gitService: GitService;

  constructor(gitService: GitService) {
    this.gitService = gitService;
  }

  async provideHover(
    document: vscode.TextDocument,
    position: vscode.Position,
    _token: vscode.CancellationToken,
  ): Promise<vscode.Hover | null> {
    const coreRepo = this.gitService.getCoreRepository();
    if (!coreRepo) return null;

    const wordRange = document.getWordRangeAtPosition(position);
    if (!wordRange) return null;

    const relativePath = vscode.workspace.asRelativePath(document.uri);

    try {
      const blameInfo = await coreRepo.getBlame(relativePath);
      const lineBlame = blameInfo.find(
        (b) => b.finalLine === position.line + 1,
      );

      if (!lineBlame) return null;

      const content = new vscode.MarkdownString();
      content.appendMarkdown(`**CommitCraft Blame**\n\n`);
      content.appendMarkdown(`- **Author:** ${lineBlame.author}\n`);
      content.appendMarkdown(`- **Date:** ${lineBlame.timestamp.toLocaleDateString()}\n`);
      content.appendMarkdown(`- **Commit:** \`${lineBlame.hash.substring(0, 8)}\`\n`);
      content.appendMarkdown(`- **Message:** ${lineBlame.summary}\n`);

      return new vscode.Hover(content, wordRange);
    } catch {
      return null;
    }
  }
}
