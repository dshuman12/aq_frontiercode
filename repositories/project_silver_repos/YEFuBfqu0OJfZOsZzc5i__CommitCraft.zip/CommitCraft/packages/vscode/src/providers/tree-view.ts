import * as vscode from 'vscode';
import * as path from 'path';

import { GitService } from '../services/git-service';

export class StagedChangesTreeProvider implements vscode.TreeDataProvider<StagedChangeItem> {
  private readonly onDidChangeTreeDataEmitter = new vscode.EventEmitter<StagedChangeItem | undefined>();
  readonly onDidChangeTreeData = this.onDidChangeTreeDataEmitter.event;

  private readonly gitService: GitService;
  private refreshInterval: ReturnType<typeof setInterval> | null = null;

  constructor(gitService: GitService) {
    this.gitService = gitService;
    this.startAutoRefresh();
  }

  refresh(): void {
    this.onDidChangeTreeDataEmitter.fire(undefined);
  }

  getTreeItem(element: StagedChangeItem): vscode.TreeItem {
    return element;
  }

  async getChildren(_element?: StagedChangeItem): Promise<StagedChangeItem[]> {
    const coreRepo = this.gitService.getCoreRepository();
    if (!coreRepo) {
      return [
        new StagedChangeItem(
          'No repository found',
          '',
          vscode.TreeItemCollapsibleState.None,
          'info',
        ),
      ];
    }

    try {
      const stagedFiles = await coreRepo.getStagedFiles();

      if (stagedFiles.length === 0) {
        return [
          new StagedChangeItem(
            'No staged changes',
            'Stage files to generate a commit message',
            vscode.TreeItemCollapsibleState.None,
            'info',
          ),
        ];
      }

      return stagedFiles.map((file) => {
        const fileName = path.basename(file.path);
        const dirName = path.dirname(file.path);
        const statusIcon = this.getStatusIcon(file.status);

        const item = new StagedChangeItem(
          `${statusIcon} ${fileName}`,
          dirName === '.' ? '' : dirName,
          vscode.TreeItemCollapsibleState.None,
          'file',
        );

        item.tooltip = `${file.path} (${file.status})`;
        item.resourceUri = vscode.Uri.file(
          path.join(vscode.workspace.workspaceFolders?.[0]?.uri.fsPath ?? '', file.path),
        );

        return item;
      });
    } catch {
      return [
        new StagedChangeItem(
          'Error loading staged files',
          '',
          vscode.TreeItemCollapsibleState.None,
          'error',
        ),
      ];
    }
  }

  private getStatusIcon(status: string): string {
    switch (status) {
      case 'added':
        return 'A';
      case 'modified':
        return 'M';
      case 'deleted':
        return 'D';
      case 'renamed':
        return 'R';
      case 'copied':
        return 'C';
      default:
        return '?';
    }
  }

  private startAutoRefresh(): void {
    this.refreshInterval = setInterval(() => this.refresh(), 5000);
  }

  dispose(): void {
    if (this.refreshInterval) {
      clearInterval(this.refreshInterval);
    }
    this.onDidChangeTreeDataEmitter.dispose();
  }
}

export class StagedChangeItem extends vscode.TreeItem {
  constructor(
    public readonly label: string,
    public readonly description: string,
    public readonly collapsibleState: vscode.TreeItemCollapsibleState,
    public readonly itemType: 'file' | 'info' | 'error',
  ) {
    super(label, collapsibleState);

    if (itemType === 'info') {
      this.iconPath = new vscode.ThemeIcon('info');
    } else if (itemType === 'error') {
      this.iconPath = new vscode.ThemeIcon('error');
    }
  }
}
