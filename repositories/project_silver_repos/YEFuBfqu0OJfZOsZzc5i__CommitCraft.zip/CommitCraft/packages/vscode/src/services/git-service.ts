import * as vscode from 'vscode';

import { GitRepository } from '@commitcraft/core';

interface GitExtensionAPI {
  getAPI(version: number): GitAPI;
}

interface GitAPI {
  repositories: GitAPIRepository[];
  onDidOpenRepository: vscode.Event<GitAPIRepository>;
  onDidCloseRepository: vscode.Event<GitAPIRepository>;
}

interface GitAPIRepository {
  rootUri: vscode.Uri;
  inputBox: { value: string };
  state: {
    HEAD: { name?: string; commit?: string } | undefined;
    indexChanges: Array<{ uri: vscode.Uri; status: number }>;
    workingTreeChanges: Array<{ uri: vscode.Uri; status: number }>;
  };
  diff(cached?: boolean): Promise<string>;
  add(uris: vscode.Uri[]): Promise<void>;
  commit(message: string): Promise<void>;
}

export class GitService {
  private gitApi: GitAPI | null = null;
  private coreRepo: GitRepository | null = null;
  private readonly outputChannel: vscode.OutputChannel;

  constructor(outputChannel: vscode.OutputChannel) {
    this.outputChannel = outputChannel;
    this.initializeGitApi();
    this.initializeCoreRepo();
  }

  private initializeGitApi(): void {
    try {
      const gitExtension = vscode.extensions.getExtension<GitExtensionAPI>('vscode.git');
      if (gitExtension) {
        if (gitExtension.isActive) {
          this.gitApi = gitExtension.exports.getAPI(1);
        } else {
          void gitExtension.activate().then((ext) => {
            this.gitApi = ext.getAPI(1);
          }, () => {
            this.outputChannel.appendLine('Failed to activate git extension');
          });
        }
      }
    } catch {
      this.outputChannel.appendLine('Git extension not available');
    }
  }

  private initializeCoreRepo(): void {
    const workspaceRoot = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
    if (workspaceRoot) {
      try {
        this.coreRepo = new GitRepository(workspaceRoot);
      } catch {
        this.outputChannel.appendLine('Failed to initialize git repository');
      }
    }
  }

  getRepository(): GitAPIRepository | null {
    if (!this.gitApi || this.gitApi.repositories.length === 0) {
      return null;
    }
    return this.gitApi.repositories[0];
  }

  getCoreRepository(): GitRepository | null {
    return this.coreRepo;
  }

  getScmInputBox(): { value: string } | null {
    const repo = this.getRepository();
    return repo?.inputBox ?? null;
  }

  async hasStagedChanges(): Promise<boolean> {
    const repo = this.getRepository();
    if (!repo) return false;
    return repo.state.indexChanges.length > 0;
  }

  async getStagedDiff(): Promise<string | null> {
    const repo = this.getRepository();
    if (!repo) return null;

    try {
      return await repo.diff(true);
    } catch {
      this.outputChannel.appendLine('Failed to get staged diff');
      return null;
    }
  }

  async stageAll(): Promise<void> {
    const repo = this.getRepository();
    if (!repo) return;

    const uris = repo.state.workingTreeChanges.map((change) => change.uri);
    if (uris.length > 0) {
      await repo.add(uris);
    }
  }

  async getCurrentBranch(): Promise<string | null> {
    const repo = this.getRepository();
    return repo?.state.HEAD?.name ?? null;
  }

  async getHeadCommit(): Promise<string | null> {
    const repo = this.getRepository();
    return repo?.state.HEAD?.commit ?? null;
  }

  getStagedFileCount(): number {
    const repo = this.getRepository();
    return repo?.state.indexChanges.length ?? 0;
  }

  getWorkingTreeFileCount(): number {
    const repo = this.getRepository();
    return repo?.state.workingTreeChanges.length ?? 0;
  }
}
