import * as vscode from 'vscode';

export class ConfigService {
  private config: vscode.WorkspaceConfiguration;

  constructor() {
    this.config = vscode.workspace.getConfiguration('commitcraft');
  }

  get<T>(key: string, defaultValue: T): T {
    return this.config.get<T>(key, defaultValue);
  }

  async set(key: string, value: unknown): Promise<void> {
    await this.config.update(key, value, vscode.ConfigurationTarget.Global);
  }

  async setWorkspace(key: string, value: unknown): Promise<void> {
    await this.config.update(key, value, vscode.ConfigurationTarget.Workspace);
  }

  reload(): void {
    this.config = vscode.workspace.getConfiguration('commitcraft');
  }

  getAll(): Record<string, unknown> {
    return {
      ai: {
        provider: this.get('ai.provider', 'claude'),
        model: this.get('ai.model', 'claude-sonnet-4-20250514'),
        apiKey: this.get('ai.apiKey', '') ? '***' : '',
        maxTokens: this.get('ai.maxTokens', 1024),
        temperature: this.get('ai.temperature', 0.3),
      },
      commit: {
        format: this.get('commit.format', 'conventional'),
        maxSubjectLength: this.get('commit.maxSubjectLength', 72),
        includeBody: this.get('commit.includeBody', true),
        emoji: this.get('commit.emoji', false),
        autoStage: this.get('commit.autoStage', false),
      },
      telemetry: {
        enabled: this.get('telemetry.enabled', false),
      },
    };
  }

  hasApiKey(): boolean {
    const key = this.get('ai.apiKey', '');
    if (key) return true;
    return Boolean(process.env.COMMITCRAFT_API_KEY ?? process.env.ANTHROPIC_API_KEY);
  }

  onConfigChange(callback: (event: vscode.ConfigurationChangeEvent) => void): vscode.Disposable {
    return vscode.workspace.onDidChangeConfiguration((event) => {
      if (event.affectsConfiguration('commitcraft')) {
        this.reload();
        callback(event);
      }
    });
  }
}
