import { ConfigService } from './config-service';
import { generateAnonymousId } from '@commitcraft/core';

export interface TelemetryEvent {
  name: string;
  properties: Record<string, unknown>;
  timestamp: Date;
}

export class TelemetryService {
  private readonly configService: ConfigService;
  private readonly events: TelemetryEvent[] = [];
  private readonly anonymousId: string;
  private readonly maxBufferSize = 100;

  constructor(configService: ConfigService) {
    this.configService = configService;
    this.anonymousId = generateAnonymousId();
  }

  trackEvent(name: string, properties: Record<string, unknown> = {}): void {
    if (!this.isEnabled()) return;

    const event: TelemetryEvent = {
      name,
      properties: {
        ...properties,
        anonymousId: this.anonymousId,
        extensionVersion: '1.0.0',
        platform: process.platform,
        nodeVersion: process.version,
      },
      timestamp: new Date(),
    };

    this.events.push(event);

    if (this.events.length > this.maxBufferSize) {
      this.events.splice(0, this.events.length - this.maxBufferSize);
    }
  }

  trackError(error: Error, context: Record<string, unknown> = {}): void {
    this.trackEvent('error', {
      errorName: error.name,
      errorMessage: error.message,
      ...context,
    });
  }

  getEvents(): TelemetryEvent[] {
    return [...this.events];
  }

  clearEvents(): void {
    this.events.length = 0;
  }

  isEnabled(): boolean {
    return this.configService.get<boolean>('telemetry.enabled', false);
  }

  dispose(): void {
    this.clearEvents();
  }
}
