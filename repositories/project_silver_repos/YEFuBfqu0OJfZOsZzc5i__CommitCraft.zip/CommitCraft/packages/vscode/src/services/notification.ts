import * as vscode from 'vscode';

export class NotificationService {
  private readonly notificationHistory: NotificationRecord[] = [];

  showInfo(message: string): void {
    this.record('info', message);
    vscode.window.showInformationMessage(`CommitCraft: ${message}`);
  }

  showWarning(message: string): void {
    this.record('warning', message);
    vscode.window.showWarningMessage(`CommitCraft: ${message}`);
  }

  showError(message: string): void {
    this.record('error', message);
    vscode.window.showErrorMessage(`CommitCraft: ${message}`);
  }

  async showInfoWithActions(
    message: string,
    ...actions: string[]
  ): Promise<string | undefined> {
    this.record('info', message);
    return vscode.window.showInformationMessage(
      `CommitCraft: ${message}`,
      ...actions,
    );
  }

  async showWarningWithActions(
    message: string,
    ...actions: string[]
  ): Promise<string | undefined> {
    this.record('warning', message);
    return vscode.window.showWarningMessage(
      `CommitCraft: ${message}`,
      ...actions,
    );
  }

  async showErrorWithActions(
    message: string,
    ...actions: string[]
  ): Promise<string | undefined> {
    this.record('error', message);
    return vscode.window.showErrorMessage(
      `CommitCraft: ${message}`,
      ...actions,
    );
  }

  showProgress(
    title: string,
    task: (progress: vscode.Progress<{ message?: string; increment?: number }>) => Promise<void>,
  ): Thenable<void> {
    return vscode.window.withProgress(
      {
        location: vscode.ProgressLocation.Notification,
        title: `CommitCraft: ${title}`,
        cancellable: false,
      },
      task,
    );
  }

  getHistory(): NotificationRecord[] {
    return [...this.notificationHistory];
  }

  clearHistory(): void {
    this.notificationHistory.length = 0;
  }

  private record(level: 'info' | 'warning' | 'error', message: string): void {
    this.notificationHistory.push({
      level,
      message,
      timestamp: new Date(),
    });

    if (this.notificationHistory.length > 50) {
      this.notificationHistory.splice(0, this.notificationHistory.length - 50);
    }
  }
}

export interface NotificationRecord {
  level: 'info' | 'warning' | 'error';
  message: string;
  timestamp: Date;
}
