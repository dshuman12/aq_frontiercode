import * as vscode from 'vscode';

import {
  AIProvider,
  AIProviderType,
  ProviderFactory,
} from '@commitcraft/core';

import { ConfigService } from './config-service';

export class AIService {
  private provider: AIProvider | null = null;
  private configService: ConfigService;
  private readonly outputChannel: vscode.OutputChannel;

  constructor(configService: ConfigService, outputChannel: vscode.OutputChannel) {
    this.configService = configService;
    this.outputChannel = outputChannel;
  }

  getProvider(): AIProvider | null {
    const apiKey = this.getApiKey();

    if (!apiKey) {
      this.outputChannel.appendLine('No API key configured');
      return null;
    }

    if (this.provider) {
      this.provider.dispose();
    }

    try {
      this.provider = ProviderFactory.create({
        type: this.configService.get<string>('ai.provider', 'claude') as AIProviderType,
        apiKey,
        model: this.configService.get<string>('ai.model', 'claude-sonnet-4-20250514'),
        baseUrl: null,
        maxTokens: this.configService.get<number>('ai.maxTokens', 1024),
        temperature: this.configService.get<number>('ai.temperature', 0.3),
        topP: 0.9,
        timeout: 30000,
      });

      return this.provider;
    } catch (error) {
      this.outputChannel.appendLine(
        `Failed to create AI provider: ${error instanceof Error ? error.message : String(error)}`,
      );
      return null;
    }
  }

  reconfigure(configService: ConfigService): void {
    this.configService = configService;
    if (this.provider) {
      this.provider.dispose();
      this.provider = null;
    }
  }

  private getApiKey(): string | null {
    const configKey = this.configService.get<string>('ai.apiKey', '');
    if (configKey) return configKey;

    const envKey = process.env.COMMITCRAFT_API_KEY ?? process.env.ANTHROPIC_API_KEY;
    return envKey ?? null;
  }

  async validateApiKey(): Promise<boolean> {
    const provider = this.getProvider();
    if (!provider) return false;

    try {
      return await provider.validateApiKey();
    } catch {
      return false;
    }
  }

  dispose(): void {
    if (this.provider) {
      this.provider.dispose();
      this.provider = null;
    }
  }
}
