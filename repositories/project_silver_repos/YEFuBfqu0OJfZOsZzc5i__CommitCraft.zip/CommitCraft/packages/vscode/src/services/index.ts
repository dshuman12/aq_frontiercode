export { GitService } from './git-service';
export { AIService } from './ai-service';
export { ConfigService } from './config-service';
export { TelemetryService } from './telemetry';
export type { TelemetryEvent } from './telemetry';
export { NotificationService } from './notification';
export type { NotificationRecord } from './notification';
