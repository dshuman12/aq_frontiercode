import * as vscode from 'vscode';

export class DisposableManager implements vscode.Disposable {
  private readonly disposables: vscode.Disposable[] = [];
  private disposed = false;

  add(disposable: vscode.Disposable): void {
    if (this.disposed) {
      disposable.dispose();
      return;
    }
    this.disposables.push(disposable);
  }

  addMany(disposables: vscode.Disposable[]): void {
    for (const disposable of disposables) {
      this.add(disposable);
    }
  }

  register<T extends vscode.Disposable>(disposable: T): T {
    this.add(disposable);
    return disposable;
  }

  dispose(): void {
    if (this.disposed) return;
    this.disposed = true;

    const errors: Error[] = [];

    for (const disposable of this.disposables) {
      try {
        disposable.dispose();
      } catch (error) {
        errors.push(error instanceof Error ? error : new Error(String(error)));
      }
    }

    this.disposables.length = 0;

    if (errors.length > 0) {
      throw new AggregateError(errors, `Failed to dispose ${errors.length} resource(s)`);
    }
  }

  get isDisposed(): boolean {
    return this.disposed;
  }

  get count(): number {
    return this.disposables.length;
  }
}

export function toDisposable(fn: () => void): vscode.Disposable {
  return { dispose: fn };
}

export function combineDisposables(...disposables: vscode.Disposable[]): vscode.Disposable {
  return {
    dispose: () => {
      for (const d of disposables) {
        d.dispose();
      }
    },
  };
}

export class LazyDisposable<T extends vscode.Disposable> implements vscode.Disposable {
  private instance: T | null = null;
  private disposed = false;
  private readonly factory: () => T;

  constructor(factory: () => T) {
    this.factory = factory;
  }

  get value(): T {
    if (this.disposed) {
      throw new Error('Disposed');
    }
    if (!this.instance) {
      this.instance = this.factory();
    }
    return this.instance;
  }

  get isCreated(): boolean {
    return this.instance !== null;
  }

  dispose(): void {
    if (this.disposed) return;
    this.disposed = true;
    this.instance?.dispose();
    this.instance = null;
  }
}

export class RefCountedDisposable implements vscode.Disposable {
  private refCount = 1;
  private readonly disposable: vscode.Disposable;

  constructor(disposable: vscode.Disposable) {
    this.disposable = disposable;
  }

  acquire(): void {
    this.refCount++;
  }

  dispose(): void {
    this.refCount--;
    if (this.refCount <= 0) {
      this.disposable.dispose();
    }
  }
}

class AggregateError extends Error {
  readonly errors: Error[];

  constructor(errors: Error[], message: string) {
    super(message);
    this.name = 'AggregateError';
    this.errors = errors;
  }
}
