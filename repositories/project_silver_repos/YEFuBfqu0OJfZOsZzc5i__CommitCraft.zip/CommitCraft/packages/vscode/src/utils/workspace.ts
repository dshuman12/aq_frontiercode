import * as vscode from 'vscode';
import * as path from 'path';
import * as fs from 'fs';

export function getWorkspaceRoot(): string | null {
  return vscode.workspace.workspaceFolders?.[0]?.uri.fsPath ?? null;
}

export function isGitRepository(): boolean {
  const root = getWorkspaceRoot();
  if (!root) return false;
  return fs.existsSync(path.join(root, '.git'));
}

export function hasConfigFile(): boolean {
  const root = getWorkspaceRoot();
  if (!root) return false;

  const configFiles = [
    '.commitcraft.json',
    '.commitcraftrc',
    '.commitcraftrc.json',
    'commitcraft.config.js',
  ];

  return configFiles.some((file) => fs.existsSync(path.join(root, file)));
}

export function getRelativePath(absolutePath: string): string {
  const root = getWorkspaceRoot();
  if (!root) return absolutePath;
  return path.relative(root, absolutePath);
}

export function getAbsolutePath(relativePath: string): string | null {
  const root = getWorkspaceRoot();
  if (!root) return null;
  return path.join(root, relativePath);
}

export function findFiles(pattern: string): Thenable<vscode.Uri[]> {
  return vscode.workspace.findFiles(pattern, '**/node_modules/**');
}

export function getWorkspaceName(): string {
  return vscode.workspace.name ?? 'Unknown';
}

export function isFileOpen(filePath: string): boolean {
  const uri = vscode.Uri.file(filePath);
  return vscode.window.visibleTextEditors.some(
    (editor) => editor.document.uri.fsPath === uri.fsPath,
  );
}

export function getActiveFileLanguage(): string | null {
  const editor = vscode.window.activeTextEditor;
  return editor?.document.languageId ?? null;
}

export function getActiveFilePath(): string | null {
  const editor = vscode.window.activeTextEditor;
  return editor?.document.uri.fsPath ?? null;
}
