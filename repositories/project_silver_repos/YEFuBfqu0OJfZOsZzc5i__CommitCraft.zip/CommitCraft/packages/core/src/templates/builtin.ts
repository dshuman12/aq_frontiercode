export interface BuiltinTemplate {
  name: string;
  description: string;
  subject: string;
  body: string | null;
  footer: string | null;
}

export const BUILTIN_TEMPLATES: Record<string, BuiltinTemplate> = {
  conventional: {
    name: 'Conventional Commits',
    description: 'Standard conventional commits format',
    subject: '{{type}}{{#if hasScope}}({{scope}}){{/if}}{{#if hasBreaking}}!{{/if}}: {{subject}}',
    body: '{{#if hasBody}}{{body}}{{/if}}',
    footer: '{{#if hasBreaking}}BREAKING CHANGE: {{footer}}{{/if}}{{#if hasIssues}}\nRefs: {{issues}}{{/if}}',
  },
  angular: {
    name: 'Angular',
    description: 'Angular commit message format',
    subject: '{{type}}{{#if hasScope}}({{scope}}){{/if}}: {{subject}}',
    body: '{{#if hasBody}}{{body}}{{/if}}',
    footer: '{{#if hasBreaking}}BREAKING CHANGE: {{footer}}{{/if}}{{#if hasIssues}}\nCloses {{issues}}{{/if}}',
  },
  emoji: {
    name: 'Emoji',
    description: 'Commit messages with emoji prefixes',
    subject: '{{#emoji type}} {{type}}{{#if hasScope}}({{scope}}){{/if}}: {{subject}}',
    body: '{{#if hasBody}}{{body}}{{/if}}',
    footer: '{{#if hasIssues}}Refs: {{issues}}{{/if}}',
  },
  minimal: {
    name: 'Minimal',
    description: 'Simple one-line commit messages',
    subject: '{{type}}: {{subject}}',
    body: null,
    footer: null,
  },
  detailed: {
    name: 'Detailed',
    description: 'Verbose commit messages with full context',
    subject: '{{type}}{{#if hasScope}}({{scope}}){{/if}}: {{subject}}',
    body: '{{#if hasBody}}{{body}}\n\nAffected files: {{fileCount}}{{/if}}',
    footer: '{{#if hasBreaking}}BREAKING CHANGE: {{footer}}{{/if}}{{#if hasIssues}}\nRefs: {{issues}}{{/if}}{{#if signOff}}\nSigned-off-by: {{signOff}}{{/if}}',
  },
};

export class BuiltinTemplateRegistry {
  private readonly templates: Map<string, BuiltinTemplate>;

  constructor() {
    this.templates = new Map(Object.entries(BUILTIN_TEMPLATES));
  }

  get(name: string): BuiltinTemplate | null {
    return this.templates.get(name) ?? null;
  }

  getAll(): BuiltinTemplate[] {
    return [...this.templates.values()];
  }

  getNames(): string[] {
    return [...this.templates.keys()];
  }

  has(name: string): boolean {
    return this.templates.has(name);
  }

  register(name: string, template: BuiltinTemplate): void {
    this.templates.set(name, template);
  }

  unregister(name: string): boolean {
    return this.templates.delete(name);
  }
}
