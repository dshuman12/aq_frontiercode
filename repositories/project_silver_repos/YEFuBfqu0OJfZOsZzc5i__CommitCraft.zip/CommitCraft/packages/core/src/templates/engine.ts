import { CommitMessage, COMMIT_TYPE_CONFIGS } from '../types/commit';

export class TemplateEngine {
  private readonly helpers: Map<string, TemplateHelper> = new Map();
  private readonly partials: Map<string, string> = new Map();

  constructor() {
    this.registerDefaultHelpers();
  }

  registerHelper(name: string, helper: TemplateHelper): void {
    this.helpers.set(name, helper);
  }

  registerPartial(name: string, template: string): void {
    this.partials.set(name, template);
  }

  render(template: string, context: TemplateContext): string {
    let result = template;

    result = this.resolvePartials(result);
    result = this.resolveHelpers(result, context);
    result = this.resolveVariables(result, context);
    result = this.resolveConditionals(result, context);
    result = this.cleanupWhitespace(result);

    return result;
  }

  private resolvePartials(template: string): string {
    return template.replace(/\{\{>\s*(\w+)\s*\}\}/g, (_match, name: string) => {
      return this.partials.get(name) ?? '';
    });
  }

  private resolveHelpers(template: string, context: TemplateContext): string {
    return template.replace(
      /\{\{#(\w+)\s+([^}]+)\}\}/g,
      (_match, helperName: string, args: string) => {
        const helper = this.helpers.get(helperName);
        if (!helper) return '';

        const resolvedArgs = args.split(/\s+/).map((arg) => {
          if (arg.startsWith('"') && arg.endsWith('"')) {
            return arg.slice(1, -1);
          }
          return this.getContextValue(context, arg);
        });

        return helper(resolvedArgs, context);
      },
    );
  }

  private resolveVariables(template: string, context: TemplateContext): string {
    return template.replace(/\{\{(\w[\w.]*)\}\}/g, (_match, path: string) => {
      const value = this.getContextValue(context, path);
      return value !== null && value !== undefined ? String(value) : '';
    });
  }

  private resolveConditionals(template: string, context: TemplateContext): string {
    return template.replace(
      /\{\{#if\s+(\w[\w.]*)\}\}([\s\S]*?)(?:\{\{#else\}\}([\s\S]*?))?\{\{\/if\}\}/g,
      (_match, condition: string, trueBranch: string, falseBranch: string | undefined) => {
        const value = this.getContextValue(context, condition);
        if (value) {
          return trueBranch;
        }
        return falseBranch ?? '';
      },
    );
  }

  private getContextValue(context: TemplateContext, path: string): unknown {
    const parts = path.split('.');
    let current: unknown = context;

    for (const part of parts) {
      if (current === null || current === undefined || typeof current !== 'object') {
        return undefined;
      }
      current = (current as Record<string, unknown>)[part];
    }

    return current;
  }

  private cleanupWhitespace(text: string): string {
    return text
      .replace(/\n{3,}/g, '\n\n')
      .trim();
  }

  private registerDefaultHelpers(): void {
    this.registerHelper('uppercase', (args: unknown[]): string => {
      return String(args[0] ?? '').toUpperCase();
    });

    this.registerHelper('lowercase', (args: unknown[]): string => {
      return String(args[0] ?? '').toLowerCase();
    });

    this.registerHelper('capitalize', (args: unknown[]): string => {
      const str = String(args[0] ?? '');
      return str.charAt(0).toUpperCase() + str.slice(1);
    });

    this.registerHelper('truncate', (args: unknown[]): string => {
      const str = String(args[0] ?? '');
      const maxLength = Number(args[1] ?? 50);
      if (str.length <= maxLength) return str;
      return str.substring(0, maxLength - 3) + '...';
    });

    this.registerHelper('emoji', (args: unknown[]): string => {
      const type = String(args[0] ?? '');
      const config = Object.values(COMMIT_TYPE_CONFIGS).find((c) => c.type === type);
      return config?.emoji ?? '';
    });

    this.registerHelper('wrap', (args: unknown[]): string => {
      const text = String(args[0] ?? '');
      const maxWidth = Number(args[1] ?? 72);
      return this.wrapText(text, maxWidth);
    });
  }

  private wrapText(text: string, maxWidth: number): string {
    const words = text.split(' ');
    const lines: string[] = [];
    let currentLine = '';

    for (const word of words) {
      if (currentLine.length + word.length + 1 > maxWidth && currentLine.length > 0) {
        lines.push(currentLine);
        currentLine = word;
      } else {
        currentLine = currentLine ? `${currentLine} ${word}` : word;
      }
    }

    if (currentLine) lines.push(currentLine);
    return lines.join('\n');
  }

  static createFromMessage(message: CommitMessage): TemplateContext {
    return {
      type: message.type,
      scope: message.scope ?? '',
      subject: message.subject,
      body: message.body ?? '',
      footer: message.footer ?? '',
      breaking: message.breaking,
      issues: message.issues,
      hasScope: message.scope !== null,
      hasBody: message.body !== null,
      hasFooter: message.footer !== null,
      hasBreaking: message.breaking,
      hasIssues: message.issues.length > 0,
    };
  }
}

export type TemplateHelper = (args: unknown[], context: TemplateContext) => string;

export interface TemplateContext {
  type: string;
  scope: string;
  subject: string;
  body: string;
  footer: string;
  breaking: boolean;
  issues: string[];
  hasScope: boolean;
  hasBody: boolean;
  hasFooter: boolean;
  hasBreaking: boolean;
  hasIssues: boolean;
  [key: string]: unknown;
}
