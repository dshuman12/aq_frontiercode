import * as fs from 'fs';
import * as path from 'path';

import { CommitCraftError, ErrorCode } from '../utils/errors';

import { TemplateEngine, TemplateContext } from './engine';

export interface CustomTemplate {
  name: string;
  description: string;
  subject: string;
  body: string | null;
  footer: string | null;
  variables: TemplateVariable[];
}

export interface TemplateVariable {
  name: string;
  description: string;
  required: boolean;
  defaultValue: string | null;
}

export class CustomTemplateManager {
  private readonly engine: TemplateEngine;
  private readonly templates: Map<string, CustomTemplate> = new Map();

  constructor() {
    this.engine = new TemplateEngine();
  }

  load(templatePath: string): CustomTemplate {
    if (!fs.existsSync(templatePath)) {
      throw new CommitCraftError(
        ErrorCode.TEMPLATE_NOT_FOUND,
        `Template file not found: ${templatePath}`,
      );
    }

    const content = fs.readFileSync(templatePath, 'utf-8');
    const template = this.parseTemplate(content, path.basename(templatePath, path.extname(templatePath)));
    this.templates.set(template.name, template);
    return template;
  }

  loadFromConfig(templates: Record<string, string>): void {
    for (const [name, subject] of Object.entries(templates)) {
      this.templates.set(name, {
        name,
        description: `Custom template: ${name}`,
        subject,
        body: null,
        footer: null,
        variables: this.extractVariables(subject),
      });
    }
  }

  render(templateName: string, context: TemplateContext): RenderedTemplate {
    const template = this.templates.get(templateName);
    if (!template) {
      throw new CommitCraftError(
        ErrorCode.TEMPLATE_NOT_FOUND,
        `Template not found: ${templateName}`,
      );
    }

    const subject = this.engine.render(template.subject, context);
    const body = template.body ? this.engine.render(template.body, context) : null;
    const footer = template.footer ? this.engine.render(template.footer, context) : null;

    return { subject, body, footer };
  }

  get(name: string): CustomTemplate | null {
    return this.templates.get(name) ?? null;
  }

  getAll(): CustomTemplate[] {
    return [...this.templates.values()];
  }

  has(name: string): boolean {
    return this.templates.has(name);
  }

  register(template: CustomTemplate): void {
    this.templates.set(template.name, template);
  }

  remove(name: string): boolean {
    return this.templates.delete(name);
  }

  private parseTemplate(content: string, defaultName: string): CustomTemplate {
    try {
      const parsed = JSON.parse(content) as Partial<CustomTemplate>;
      return {
        name: parsed.name ?? defaultName,
        description: parsed.description ?? '',
        subject: parsed.subject ?? '{{type}}: {{subject}}',
        body: parsed.body ?? null,
        footer: parsed.footer ?? null,
        variables: parsed.variables ?? this.extractVariables(parsed.subject ?? ''),
      };
    } catch {
      return {
        name: defaultName,
        description: '',
        subject: content.split('\n')[0] ?? '{{type}}: {{subject}}',
        body: content.split('\n').slice(1).join('\n') || null,
        footer: null,
        variables: this.extractVariables(content),
      };
    }
  }

  private extractVariables(template: string): TemplateVariable[] {
    const matches = template.matchAll(/\{\{(\w+)\}\}/g);
    const seen = new Set<string>();
    const variables: TemplateVariable[] = [];

    for (const match of matches) {
      const name = match[1];
      if (!seen.has(name)) {
        seen.add(name);
        variables.push({
          name,
          description: '',
          required: true,
          defaultValue: null,
        });
      }
    }

    return variables;
  }
}

export interface RenderedTemplate {
  subject: string;
  body: string | null;
  footer: string | null;
}
