import * as fs from 'fs';
import * as path from 'path';

import { CommitCraftConfig, ConfigSource, PartialConfig, ConfigOverrides } from '../types/config';
import { CommitCraftError, ErrorCode } from '../utils/errors';

import { DEFAULT_CONFIG, CONFIG_FILE_NAMES, ENV_MAPPINGS } from './defaults';
import { commitCraftConfigSchema } from './schema';
import { ConfigValidator } from './validator';

export class ConfigLoader {
  private readonly validator: ConfigValidator;
  private readonly overrides: ConfigOverrides[] = [];
  private cachedConfig: CommitCraftConfig | null = null;

  constructor() {
    this.validator = new ConfigValidator();
  }

  async load(cwd: string = process.cwd()): Promise<CommitCraftConfig> {
    if (this.cachedConfig) {
      return this.cachedConfig;
    }

    const fileConfig = await this.loadFromFile(cwd);
    const envConfig = this.loadFromEnvironment();

    const merged = this.mergeConfigs(
      DEFAULT_CONFIG,
      fileConfig,
      envConfig,
      ...this.overrides.sort((a, b) => a.priority - b.priority).map((o) => o.values),
    );

    const validated = this.validateAndParse(merged);
    this.cachedConfig = validated;
    return validated;
  }

  addOverride(override: ConfigOverrides): void {
    this.overrides.push(override);
    this.cachedConfig = null;
  }

  removeOverride(source: ConfigSource): void {
    const index = this.overrides.findIndex((o) => o.source === source);
    if (index !== -1) {
      this.overrides.splice(index, 1);
      this.cachedConfig = null;
    }
  }

  clearCache(): void {
    this.cachedConfig = null;
  }

  async loadFromFile(cwd: string): Promise<PartialConfig> {
    for (const fileName of CONFIG_FILE_NAMES) {
      const filePath = path.join(cwd, fileName);
      if (fs.existsSync(filePath)) {
        return this.parseConfigFile(filePath);
      }
    }

    const parentDir = path.dirname(cwd);
    if (parentDir !== cwd) {
      return this.loadFromFile(parentDir);
    }

    return {};
  }

  private async parseConfigFile(filePath: string): Promise<PartialConfig> {
    const ext = path.extname(filePath).toLowerCase();
    const content = fs.readFileSync(filePath, 'utf-8');

    switch (ext) {
      case '.json':
      case '': {
        try {
          return JSON.parse(content) as PartialConfig;
        } catch {
          throw new CommitCraftError(
            ErrorCode.CONFIG_PARSE_ERROR,
            `Failed to parse config file: ${filePath}`,
          );
        }
      }
      case '.yaml':
      case '.yml': {
        return this.parseYamlConfig(content, filePath);
      }
      case '.js':
      case '.ts': {
        return this.loadJsConfig(filePath);
      }
      default:
        throw new CommitCraftError(
          ErrorCode.CONFIG_INVALID_FORMAT,
          `Unsupported config file format: ${ext}`,
        );
    }
  }

  private parseYamlConfig(content: string, filePath: string): PartialConfig {
    try {
      const lines = content.split('\n');
      const result: Record<string, unknown> = {};
      const stack: Array<{ indent: number; obj: Record<string, unknown> }> = [
        { indent: -1, obj: result },
      ];

      for (const rawLine of lines) {
        const trimmed = rawLine.trim();
        if (!trimmed || trimmed.startsWith('#')) {
          continue;
        }

        const indent = rawLine.length - rawLine.trimStart().length;
        const match = trimmed.match(/^([^:]+):\s*(.*)$/);
        if (!match) {
          continue;
        }

        const key = match[1].trim();
        const rawValue = match[2].trim();

        while (stack.length > 1 && stack[stack.length - 1].indent >= indent) {
          stack.pop();
        }

        const parent = stack[stack.length - 1].obj;

        if (rawValue === '' || rawValue === undefined) {
          const newObj: Record<string, unknown> = {};
          parent[key] = newObj;
          stack.push({ indent, obj: newObj });
        } else {
          parent[key] = this.parseYamlValue(rawValue);
        }
      }

      return result as PartialConfig;
    } catch {
      throw new CommitCraftError(
        ErrorCode.CONFIG_PARSE_ERROR,
        `Failed to parse YAML config: ${filePath}`,
      );
    }
  }

  private parseYamlValue(value: string): unknown {
    if (value === 'true') return true;
    if (value === 'false') return false;
    if (value === 'null') return null;

    const num = Number(value);
    if (!isNaN(num) && value !== '') return num;

    if ((value.startsWith('"') && value.endsWith('"')) ||
        (value.startsWith("'") && value.endsWith("'"))) {
      return value.slice(1, -1);
    }

    if (value.startsWith('[') && value.endsWith(']')) {
      const inner = value.slice(1, -1);
      return inner.split(',').map((item) => this.parseYamlValue(item.trim()));
    }

    return value;
  }

  private async loadJsConfig(filePath: string): Promise<PartialConfig> {
    try {
      const module = await import(filePath) as { default?: PartialConfig } & PartialConfig;
      return (module.default ?? module) as PartialConfig;
    } catch {
      throw new CommitCraftError(
        ErrorCode.CONFIG_PARSE_ERROR,
        `Failed to load JS/TS config: ${filePath}`,
      );
    }
  }

  loadFromEnvironment(): PartialConfig {
    const config: Record<string, unknown> = {};

    for (const [envKey, configPath] of Object.entries(ENV_MAPPINGS)) {
      const value = process.env[envKey];
      if (value !== undefined) {
        this.setNestedValue(config, configPath, this.parseEnvValue(value));
      }
    }

    return config as PartialConfig;
  }

  private parseEnvValue(value: string): unknown {
    if (value === 'true') return true;
    if (value === 'false') return false;
    if (value === 'null') return null;

    const num = Number(value);
    if (!isNaN(num) && value !== '') return num;

    return value;
  }

  private setNestedValue(obj: Record<string, unknown>, path: string, value: unknown): void {
    const parts = path.split('.');
    let current = obj;

    for (let i = 0; i < parts.length - 1; i++) {
      const key = parts[i];
      if (!(key in current) || typeof current[key] !== 'object') {
        current[key] = {};
      }
      current = current[key] as Record<string, unknown>;
    }

    current[parts[parts.length - 1]] = value;
  }

  private mergeConfigs(...configs: PartialConfig[]): PartialConfig {
    const result: Record<string, unknown> = {};

    for (const config of configs) {
      this.deepMerge(result, config as Record<string, unknown>);
    }

    return result as PartialConfig;
  }

  private deepMerge(target: Record<string, unknown>, source: Record<string, unknown>): void {
    for (const key of Object.keys(source)) {
      const sourceValue = source[key];
      const targetValue = target[key];

      if (
        sourceValue !== null &&
        typeof sourceValue === 'object' &&
        !Array.isArray(sourceValue) &&
        targetValue !== null &&
        typeof targetValue === 'object' &&
        !Array.isArray(targetValue)
      ) {
        this.deepMerge(
          targetValue as Record<string, unknown>,
          sourceValue as Record<string, unknown>,
        );
      } else if (sourceValue !== undefined) {
        target[key] = sourceValue;
      }
    }
  }

  private validateAndParse(config: PartialConfig): CommitCraftConfig {
    const parseResult = commitCraftConfigSchema.safeParse(config);

    if (!parseResult.success) {
      const errors = parseResult.error.errors.map(
        (e) => `${e.path.join('.')}: ${e.message}`,
      );
      throw new CommitCraftError(
        ErrorCode.CONFIG_VALIDATION_ERROR,
        `Invalid configuration:\n${errors.join('\n')}`,
      );
    }

    this.validator.validate(parseResult.data as unknown as CommitCraftConfig);
    return parseResult.data as unknown as CommitCraftConfig;
  }

  static async createFromFile(filePath: string): Promise<CommitCraftConfig> {
    const loader = new ConfigLoader();
    const dir = path.dirname(filePath);
    return loader.load(dir);
  }

  static createDefault(): CommitCraftConfig {
    return { ...DEFAULT_CONFIG };
  }
}
