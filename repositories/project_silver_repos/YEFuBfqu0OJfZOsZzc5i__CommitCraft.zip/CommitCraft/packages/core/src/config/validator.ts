import { CommitCraftConfig, LogLevel } from '../types/config';
import { CommitCraftError, ErrorCode } from '../utils/errors';

export interface ValidationResult {
  valid: boolean;
  errors: ValidationError[];
  warnings: ValidationWarning[];
}

export interface ValidationError {
  path: string;
  message: string;
  value: unknown;
}

export interface ValidationWarning {
  path: string;
  message: string;
  suggestion: string;
}

export class ConfigValidator {
  validate(config: CommitCraftConfig): ValidationResult {
    const errors: ValidationError[] = [];
    const warnings: ValidationWarning[] = [];

    this.validateAIConfig(config, errors, warnings);
    this.validateCommitConfig(config, errors, warnings);
    this.validateGitConfig(config, errors, warnings);
    this.validateOutputConfig(config, errors, warnings);
    this.validateCacheConfig(config, errors, warnings);
    this.validateTemplateConfig(config, errors, warnings);
    this.validateScopeConfig(config, errors, warnings);

    if (errors.length > 0) {
      throw new CommitCraftError(
        ErrorCode.CONFIG_VALIDATION_ERROR,
        `Configuration validation failed:\n${errors.map((e) => `  ${e.path}: ${e.message}`).join('\n')}`,
      );
    }

    return { valid: true, errors, warnings };
  }

  private validateAIConfig(
    config: CommitCraftConfig,
    _errors: ValidationError[],
    warnings: ValidationWarning[],
  ): void {
    const { ai } = config;

    if (ai.temperature > 1.0) {
      warnings.push({
        path: 'ai.temperature',
        message: 'High temperature may produce inconsistent results',
        suggestion: 'Consider using a value between 0.1 and 0.5 for commit messages',
      });
    }

    if (ai.maxTokens > 2048) {
      warnings.push({
        path: 'ai.maxTokens',
        message: 'High max tokens may increase API costs',
        suggestion: 'Commit messages rarely need more than 1024 tokens',
      });
    }

    if (ai.retryAttempts > 5) {
      warnings.push({
        path: 'ai.retryAttempts',
        message: 'High retry count may cause long waits on failures',
        suggestion: 'Consider using 3 or fewer retry attempts',
      });
    }

    if (ai.timeout < 5000) {
      warnings.push({
        path: 'ai.timeout',
        message: 'Low timeout may cause premature request failures',
        suggestion: 'Consider using at least 10000ms timeout',
      });
    }
  }

  private validateCommitConfig(
    config: CommitCraftConfig,
    errors: ValidationError[],
    _warnings: ValidationWarning[],
  ): void {
    const { commit } = config;

    if (commit.maxSubjectLength < 20) {
      errors.push({
        path: 'commit.maxSubjectLength',
        message: 'Subject length must be at least 20 characters',
        value: commit.maxSubjectLength,
      });
    }

    if (commit.allowedTypes.length === 0) {
      errors.push({
        path: 'commit.allowedTypes',
        message: 'At least one commit type must be allowed',
        value: commit.allowedTypes,
      });
    }

    if (commit.defaultType && !commit.allowedTypes.includes(commit.defaultType)) {
      errors.push({
        path: 'commit.defaultType',
        message: 'Default type must be in the allowed types list',
        value: commit.defaultType,
      });
    }
  }

  private validateGitConfig(
    config: CommitCraftConfig,
    errors: ValidationError[],
    warnings: ValidationWarning[],
  ): void {
    const { git } = config;

    if (git.maxDiffSize < 1000) {
      errors.push({
        path: 'git.maxDiffSize',
        message: 'Max diff size must be at least 1000 characters',
        value: git.maxDiffSize,
      });
    }

    if (git.maxDiffSize > 200000) {
      warnings.push({
        path: 'git.maxDiffSize',
        message: 'Very large diff sizes may cause slow API responses',
        suggestion: 'Consider limiting diff size to 50000 characters',
      });
    }

    for (const pattern of git.excludePatterns) {
      if (git.includePatterns.includes(pattern)) {
        errors.push({
          path: 'git.excludePatterns',
          message: `Pattern "${pattern}" appears in both include and exclude lists`,
          value: pattern,
        });
      }
    }
  }

  private validateOutputConfig(
    config: CommitCraftConfig,
    _errors: ValidationError[],
    warnings: ValidationWarning[],
  ): void {
    const { output } = config;

    if (output.verbose && output.quiet) {
      warnings.push({
        path: 'output',
        message: 'Both verbose and quiet are enabled; quiet takes precedence',
        suggestion: 'Disable one of these options',
      });
    }

    if (output.json && output.color) {
      warnings.push({
        path: 'output',
        message: 'Color output with JSON may cause parsing issues',
        suggestion: 'Disable color when using JSON output',
      });
    }

    if (output.logLevel === LogLevel.DEBUG && !output.verbose) {
      warnings.push({
        path: 'output.logLevel',
        message: 'Debug log level without verbose mode may miss some output',
        suggestion: 'Enable verbose mode with debug log level',
      });
    }
  }

  private validateCacheConfig(
    config: CommitCraftConfig,
    _errors: ValidationError[],
    warnings: ValidationWarning[],
  ): void {
    const { cache } = config;

    if (cache.enabled && cache.ttl === 0) {
      warnings.push({
        path: 'cache.ttl',
        message: 'Cache is enabled but TTL is 0; items will expire immediately',
        suggestion: 'Set a TTL value or disable caching',
      });
    }

    if (cache.maxEntries > 5000) {
      warnings.push({
        path: 'cache.maxEntries',
        message: 'Large cache size may consume significant disk space',
        suggestion: 'Consider limiting to 1000 entries or fewer',
      });
    }
  }

  private validateTemplateConfig(
    config: CommitCraftConfig,
    errors: ValidationError[],
    _warnings: ValidationWarning[],
  ): void {
    const { templates } = config;

    if (!templates.subjectTemplate.includes('{{type}}')) {
      errors.push({
        path: 'templates.subjectTemplate',
        message: 'Subject template must include {{type}} placeholder',
        value: templates.subjectTemplate,
      });
    }

    if (!templates.subjectTemplate.includes('{{subject}}')) {
      errors.push({
        path: 'templates.subjectTemplate',
        message: 'Subject template must include {{subject}} placeholder',
        value: templates.subjectTemplate,
      });
    }
  }

  private validateScopeConfig(
    config: CommitCraftConfig,
    _errors: ValidationError[],
    warnings: ValidationWarning[],
  ): void {
    const { scopes } = config;

    if (scopes.required && scopes.predefined.length === 0 && !scopes.autoDetect) {
      warnings.push({
        path: 'scopes',
        message: 'Scope is required but no predefined scopes and auto-detect is disabled',
        suggestion: 'Add predefined scopes or enable auto-detection',
      });
    }

    const names = scopes.predefined.map((s) => s.name);
    const duplicates = names.filter((name, index) => names.indexOf(name) !== index);
    if (duplicates.length > 0) {
      warnings.push({
        path: 'scopes.predefined',
        message: `Duplicate scope names: ${duplicates.join(', ')}`,
        suggestion: 'Remove duplicate scope definitions',
      });
    }
  }
}
