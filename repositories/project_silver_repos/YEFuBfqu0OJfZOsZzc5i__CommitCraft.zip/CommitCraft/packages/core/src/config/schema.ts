import { z } from 'zod';

import { CommitFormat, CommitType } from '../types/commit';
import { LogLevel } from '../types/config';

export const aiConfigSchema = z.object({
  provider: z.string().default('claude'),
  model: z.string().default('claude-sonnet-4-20250514'),
  apiKey: z.string().default(''),
  maxTokens: z.number().int().min(1).max(4096).default(1024),
  temperature: z.number().min(0).max(2).default(0.3),
  topP: z.number().min(0).max(1).default(0.9),
  timeout: z.number().int().min(1000).max(120000).default(30000),
  retryAttempts: z.number().int().min(0).max(10).default(3),
  retryDelay: z.number().int().min(100).max(30000).default(1000),
  baseUrl: z.string().url().nullable().default(null),
});

export const commitConfigSchema = z.object({
  format: z.nativeEnum(CommitFormat).default(CommitFormat.CONVENTIONAL),
  maxSubjectLength: z.number().int().min(20).max(200).default(72),
  maxBodyLineLength: z.number().int().min(20).max(200).default(100),
  includeBody: z.boolean().default(true),
  includeFooter: z.boolean().default(false),
  includeBreakingChanges: z.boolean().default(true),
  includeIssueReferences: z.boolean().default(true),
  defaultType: z.nativeEnum(CommitType).nullable().default(null),
  allowedTypes: z.array(z.nativeEnum(CommitType)).default(Object.values(CommitType)),
  language: z.string().min(2).max(5).default('en'),
  emoji: z.boolean().default(false),
  signOff: z.boolean().default(false),
  gpgSign: z.boolean().default(false),
});

export const gitConfigSchema = z.object({
  stagedOnly: z.boolean().default(true),
  excludePatterns: z.array(z.string()).default([]),
  includePatterns: z.array(z.string()).default([]),
  maxDiffSize: z.number().int().min(1000).max(500000).default(50000),
  contextLines: z.number().int().min(0).max(20).default(3),
  followRenames: z.boolean().default(true),
  ignoreWhitespace: z.boolean().default(false),
});

export const outputConfigSchema = z.object({
  verbose: z.boolean().default(false),
  color: z.boolean().default(true),
  json: z.boolean().default(false),
  quiet: z.boolean().default(false),
  logLevel: z.nativeEnum(LogLevel).default(LogLevel.INFO),
  logFile: z.string().nullable().default(null),
});

export const cacheConfigSchema = z.object({
  enabled: z.boolean().default(true),
  ttl: z.number().int().min(0).default(3600000),
  maxEntries: z.number().int().min(0).max(10000).default(100),
  directory: z.string().default('.commitcraft/cache'),
});

export const telemetryConfigSchema = z.object({
  enabled: z.boolean().default(false),
  anonymousId: z.string().nullable().default(null),
  endpoint: z.string().url().nullable().default(null),
});

export const hooksConfigSchema = z.object({
  preGenerate: z.string().nullable().default(null),
  postGenerate: z.string().nullable().default(null),
  preCommit: z.string().nullable().default(null),
  postCommit: z.string().nullable().default(null),
});

export const templateConfigSchema = z.object({
  subjectTemplate: z.string().default('{{type}}{{scope}}: {{subject}}'),
  bodyTemplate: z.string().nullable().default(null),
  footerTemplate: z.string().nullable().default(null),
  customTemplates: z.record(z.string(), z.string()).default({}),
});

export const scopeDefinitionSchema = z.object({
  name: z.string().min(1),
  description: z.string(),
  paths: z.array(z.string()),
});

export const scopeConfigSchema = z.object({
  predefined: z.array(scopeDefinitionSchema).default([]),
  autoDetect: z.boolean().default(true),
  required: z.boolean().default(false),
});

export const commitCraftConfigSchema = z.object({
  ai: aiConfigSchema.default({}),
  commit: commitConfigSchema.default({}),
  git: gitConfigSchema.default({}),
  output: outputConfigSchema.default({}),
  cache: cacheConfigSchema.default({}),
  telemetry: telemetryConfigSchema.default({}),
  hooks: hooksConfigSchema.default({}),
  templates: templateConfigSchema.default({}),
  scopes: scopeConfigSchema.default({}),
});

export type ValidatedConfig = z.infer<typeof commitCraftConfigSchema>;
