import { CommitFormat, CommitType } from '../types/commit';
import {
  CommitCraftConfig,
  LogLevel,
} from '../types/config';

export const DEFAULT_CONFIG: CommitCraftConfig = {
  ai: {
    provider: 'claude',
    model: 'claude-sonnet-4-20250514',
    apiKey: '',
    maxTokens: 1024,
    temperature: 0.3,
    topP: 0.9,
    timeout: 30000,
    retryAttempts: 3,
    retryDelay: 1000,
    baseUrl: null,
  },
  commit: {
    format: CommitFormat.CONVENTIONAL,
    maxSubjectLength: 72,
    maxBodyLineLength: 100,
    includeBody: true,
    includeFooter: false,
    includeBreakingChanges: true,
    includeIssueReferences: true,
    defaultType: null,
    allowedTypes: Object.values(CommitType),
    language: 'en',
    emoji: false,
    signOff: false,
    gpgSign: false,
  },
  git: {
    stagedOnly: true,
    excludePatterns: [
      '*.lock',
      'package-lock.json',
      'yarn.lock',
      'pnpm-lock.yaml',
      '*.min.js',
      '*.min.css',
      '*.map',
      'dist/**',
      'build/**',
      'coverage/**',
    ],
    includePatterns: [],
    maxDiffSize: 50000,
    contextLines: 3,
    followRenames: true,
    ignoreWhitespace: false,
  },
  output: {
    verbose: false,
    color: true,
    json: false,
    quiet: false,
    logLevel: LogLevel.INFO,
    logFile: null,
  },
  cache: {
    enabled: true,
    ttl: 3600000,
    maxEntries: 100,
    directory: '.commitcraft/cache',
  },
  telemetry: {
    enabled: false,
    anonymousId: null,
    endpoint: null,
  },
  hooks: {
    preGenerate: null,
    postGenerate: null,
    preCommit: null,
    postCommit: null,
  },
  templates: {
    subjectTemplate: '{{type}}{{scope}}: {{subject}}',
    bodyTemplate: null,
    footerTemplate: null,
    customTemplates: {},
  },
  scopes: {
    predefined: [],
    autoDetect: true,
    required: false,
  },
};

export const CONFIG_FILE_NAMES = [
  '.commitcraft.json',
  '.commitcraftrc',
  '.commitcraftrc.json',
  '.commitcraftrc.yaml',
  '.commitcraftrc.yml',
  'commitcraft.config.js',
  'commitcraft.config.ts',
];

export const ENV_PREFIX = 'COMMITCRAFT_';

export const ENV_MAPPINGS: Record<string, string> = {
  COMMITCRAFT_API_KEY: 'ai.apiKey',
  COMMITCRAFT_MODEL: 'ai.model',
  COMMITCRAFT_PROVIDER: 'ai.provider',
  COMMITCRAFT_MAX_TOKENS: 'ai.maxTokens',
  COMMITCRAFT_TEMPERATURE: 'ai.temperature',
  COMMITCRAFT_FORMAT: 'commit.format',
  COMMITCRAFT_MAX_SUBJECT_LENGTH: 'commit.maxSubjectLength',
  COMMITCRAFT_INCLUDE_BODY: 'commit.includeBody',
  COMMITCRAFT_EMOJI: 'commit.emoji',
  COMMITCRAFT_LANGUAGE: 'commit.language',
  COMMITCRAFT_VERBOSE: 'output.verbose',
  COMMITCRAFT_LOG_LEVEL: 'output.logLevel',
  COMMITCRAFT_CACHE_ENABLED: 'cache.enabled',
  COMMITCRAFT_TELEMETRY: 'telemetry.enabled',
};
