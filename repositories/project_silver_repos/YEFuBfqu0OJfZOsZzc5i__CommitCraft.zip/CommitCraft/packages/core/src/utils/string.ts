export function truncate(str: string, maxLength: number, suffix: string = '...'): string {
  if (str.length <= maxLength) return str;
  return str.substring(0, maxLength - suffix.length) + suffix;
}

export function capitalize(str: string): string {
  if (!str) return str;
  return str.charAt(0).toUpperCase() + str.slice(1);
}

export function decapitalize(str: string): string {
  if (!str) return str;
  return str.charAt(0).toLowerCase() + str.slice(1);
}

export function toKebabCase(str: string): string {
  return str
    .replace(/([a-z])([A-Z])/g, '$1-$2')
    .replace(/[\s_]+/g, '-')
    .toLowerCase();
}

export function toCamelCase(str: string): string {
  return str
    .replace(/[-_\s]+(.)?/g, (_match, char: string | undefined) =>
      char ? char.toUpperCase() : '',
    )
    .replace(/^[A-Z]/, (char) => char.toLowerCase());
}

export function toPascalCase(str: string): string {
  const camel = toCamelCase(str);
  return capitalize(camel);
}

export function toSnakeCase(str: string): string {
  return str
    .replace(/([a-z])([A-Z])/g, '$1_$2')
    .replace(/[-\s]+/g, '_')
    .toLowerCase();
}

export function pluralize(word: string, count: number): string {
  if (count === 1) return word;

  const irregulars: Record<string, string> = {
    child: 'children',
    person: 'people',
    man: 'men',
    woman: 'women',
    mouse: 'mice',
    goose: 'geese',
    tooth: 'teeth',
    foot: 'feet',
    datum: 'data',
    index: 'indices',
  };

  const lower = word.toLowerCase();
  if (irregulars[lower]) {
    return word[0] === word[0].toUpperCase()
      ? capitalize(irregulars[lower])
      : irregulars[lower];
  }

  if (word.endsWith('s') || word.endsWith('sh') || word.endsWith('ch') ||
      word.endsWith('x') || word.endsWith('z')) {
    return word + 'es';
  }

  if (word.endsWith('y') && !/[aeiou]y$/i.test(word)) {
    return word.slice(0, -1) + 'ies';
  }

  if (word.endsWith('f')) {
    return word.slice(0, -1) + 'ves';
  }

  if (word.endsWith('fe')) {
    return word.slice(0, -2) + 'ves';
  }

  return word + 's';
}

export function wrapText(text: string, maxWidth: number = 72): string {
  return text.split('\n').map((line) => wrapLine(line, maxWidth)).join('\n');
}

function wrapLine(line: string, maxWidth: number): string {
  if (line.length <= maxWidth) return line;

  const words = line.split(' ');
  const lines: string[] = [];
  let current = '';

  for (const word of words) {
    if (current.length + word.length + 1 > maxWidth && current.length > 0) {
      lines.push(current);
      current = word;
    } else {
      current = current ? `${current} ${word}` : word;
    }
  }

  if (current) lines.push(current);
  return lines.join('\n');
}

export function indent(text: string, spaces: number = 2): string {
  const prefix = ' '.repeat(spaces);
  return text.split('\n').map((line) => prefix + line).join('\n');
}

export function dedent(text: string): string {
  const lines = text.split('\n');
  const nonEmptyLines = lines.filter((line) => line.trim().length > 0);

  if (nonEmptyLines.length === 0) return text;

  const minIndent = Math.min(
    ...nonEmptyLines.map((line) => line.length - line.trimStart().length),
  );

  return lines.map((line) => line.substring(minIndent)).join('\n');
}

export function stripAnsi(str: string): string {
  return str.replace(/\x1b\[[0-9;]*m/g, '');
}

export function escapeRegex(str: string): string {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

export function hashString(str: string): string {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return Math.abs(hash).toString(36);
}
