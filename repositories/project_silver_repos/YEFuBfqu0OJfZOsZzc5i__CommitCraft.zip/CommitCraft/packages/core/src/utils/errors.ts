export enum ErrorCode {
  CONFIG_PARSE_ERROR = 'CONFIG_PARSE_ERROR',
  CONFIG_INVALID_FORMAT = 'CONFIG_INVALID_FORMAT',
  CONFIG_VALIDATION_ERROR = 'CONFIG_VALIDATION_ERROR',
  CONFIG_NOT_FOUND = 'CONFIG_NOT_FOUND',

  GIT_NOT_REPOSITORY = 'GIT_NOT_REPOSITORY',
  GIT_NO_STAGED_CHANGES = 'GIT_NO_STAGED_CHANGES',
  GIT_COMMAND_FAILED = 'GIT_COMMAND_FAILED',
  GIT_COMMIT_FAILED = 'GIT_COMMIT_FAILED',
  GIT_DIFF_TOO_LARGE = 'GIT_DIFF_TOO_LARGE',

  AI_REQUEST_FAILED = 'AI_REQUEST_FAILED',
  AI_PARSE_ERROR = 'AI_PARSE_ERROR',
  AI_RATE_LIMITED = 'AI_RATE_LIMITED',
  AI_INVALID_API_KEY = 'AI_INVALID_API_KEY',
  AI_PROVIDER_NOT_FOUND = 'AI_PROVIDER_NOT_FOUND',
  AI_TIMEOUT = 'AI_TIMEOUT',

  TEMPLATE_NOT_FOUND = 'TEMPLATE_NOT_FOUND',
  TEMPLATE_PARSE_ERROR = 'TEMPLATE_PARSE_ERROR',
  TEMPLATE_RENDER_ERROR = 'TEMPLATE_RENDER_ERROR',

  HOOK_EXECUTION_FAILED = 'HOOK_EXECUTION_FAILED',
  HOOK_NOT_FOUND = 'HOOK_NOT_FOUND',

  CACHE_READ_ERROR = 'CACHE_READ_ERROR',
  CACHE_WRITE_ERROR = 'CACHE_WRITE_ERROR',

  UNKNOWN_ERROR = 'UNKNOWN_ERROR',
}

export class CommitCraftError extends Error {
  readonly code: ErrorCode;
  readonly details: Record<string, unknown>;
  readonly timestamp: Date;

  constructor(
    code: ErrorCode,
    message: string,
    details: Record<string, unknown> = {},
  ) {
    super(message);
    this.name = 'CommitCraftError';
    this.code = code;
    this.details = details;
    this.timestamp = new Date();

    Object.setPrototypeOf(this, CommitCraftError.prototype);
  }

  toJSON(): Record<string, unknown> {
    return {
      name: this.name,
      code: this.code,
      message: this.message,
      details: this.details,
      timestamp: this.timestamp.toISOString(),
      stack: this.stack,
    };
  }

  static isCommitCraftError(error: unknown): error is CommitCraftError {
    return error instanceof CommitCraftError;
  }

  static fromError(error: Error, code: ErrorCode = ErrorCode.UNKNOWN_ERROR): CommitCraftError {
    if (error instanceof CommitCraftError) {
      return error;
    }

    return new CommitCraftError(code, error.message, {
      originalName: error.name,
      originalStack: error.stack,
    });
  }

  static wrap(
    fn: () => void,
    code: ErrorCode,
    message?: string,
  ): void {
    try {
      fn();
    } catch (error) {
      if (error instanceof CommitCraftError) {
        throw error;
      }
      throw new CommitCraftError(
        code,
        message ?? (error instanceof Error ? error.message : String(error)),
      );
    }
  }

  static async wrapAsync<T>(
    fn: () => Promise<T>,
    code: ErrorCode,
    message?: string,
  ): Promise<T> {
    try {
      return await fn();
    } catch (error) {
      if (error instanceof CommitCraftError) {
        throw error;
      }
      throw new CommitCraftError(
        code,
        message ?? (error instanceof Error ? error.message : String(error)),
      );
    }
  }
}

export function isRetryableError(error: unknown): boolean {
  if (error instanceof CommitCraftError) {
    return [
      ErrorCode.AI_REQUEST_FAILED,
      ErrorCode.AI_RATE_LIMITED,
      ErrorCode.AI_TIMEOUT,
      ErrorCode.GIT_COMMAND_FAILED,
    ].includes(error.code);
  }
  return false;
}

export function formatError(error: unknown): string {
  if (error instanceof CommitCraftError) {
    return `[${error.code}] ${error.message}`;
  }
  if (error instanceof Error) {
    return error.message;
  }
  return String(error);
}
