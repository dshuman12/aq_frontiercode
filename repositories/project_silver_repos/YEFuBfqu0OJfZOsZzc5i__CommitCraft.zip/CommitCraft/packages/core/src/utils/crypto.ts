import * as crypto from 'crypto';

export function generateId(prefix: string = '', length: number = 12): string {
  const id = crypto.randomBytes(length).toString('hex').substring(0, length);
  return prefix ? `${prefix}_${id}` : id;
}

export function hashContent(content: string, algorithm: string = 'sha256'): string {
  return crypto.createHash(algorithm).update(content).digest('hex');
}

export function hashDiff(diff: string): string {
  return hashContent(diff).substring(0, 16);
}

export function generateCacheKey(parts: string[]): string {
  const combined = parts.join('::');
  return hashContent(combined).substring(0, 24);
}

export function generateAnonymousId(): string {
  return crypto.randomUUID();
}

export function maskApiKey(apiKey: string): string {
  if (apiKey.length <= 8) {
    return '*'.repeat(apiKey.length);
  }

  const prefix = apiKey.substring(0, 4);
  const suffix = apiKey.substring(apiKey.length - 4);
  const masked = '*'.repeat(Math.min(apiKey.length - 8, 20));

  return `${prefix}${masked}${suffix}`;
}

export function isValidApiKeyFormat(apiKey: string): boolean {
  if (!apiKey || apiKey.length < 10) {
    return false;
  }

  if (apiKey.startsWith('sk-ant-')) {
    return apiKey.length > 20;
  }

  if (apiKey.startsWith('sk-')) {
    return apiKey.length > 20;
  }

  return apiKey.length >= 10;
}

export function constantTimeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) {
    return false;
  }

  const bufA = Buffer.from(a);
  const bufB = Buffer.from(b);
  return crypto.timingSafeEqual(bufA, bufB);
}
