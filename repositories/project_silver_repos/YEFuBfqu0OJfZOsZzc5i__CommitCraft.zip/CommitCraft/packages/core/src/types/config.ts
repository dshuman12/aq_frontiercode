import { CommitFormat, CommitType } from './commit';

export enum ConfigSource {
  DEFAULT = 'default',
  FILE = 'file',
  ENVIRONMENT = 'environment',
  CLI_ARG = 'cli_arg',
  VSCODE_SETTING = 'vscode_setting',
}

export interface CommitCraftConfig {
  ai: AIConfig;
  commit: CommitConfig;
  git: GitConfig;
  output: OutputConfig;
  cache: CacheConfig;
  telemetry: TelemetryConfig;
  hooks: HooksConfig;
  templates: TemplateConfig;
  scopes: ScopeConfig;
}

export interface AIConfig {
  provider: string;
  model: string;
  apiKey: string;
  maxTokens: number;
  temperature: number;
  topP: number;
  timeout: number;
  retryAttempts: number;
  retryDelay: number;
  baseUrl: string | null;
}

export interface CommitConfig {
  format: CommitFormat;
  maxSubjectLength: number;
  maxBodyLineLength: number;
  includeBody: boolean;
  includeFooter: boolean;
  includeBreakingChanges: boolean;
  includeIssueReferences: boolean;
  defaultType: CommitType | null;
  allowedTypes: CommitType[];
  language: string;
  emoji: boolean;
  signOff: boolean;
  gpgSign: boolean;
}

export interface GitConfig {
  stagedOnly: boolean;
  excludePatterns: string[];
  includePatterns: string[];
  maxDiffSize: number;
  contextLines: number;
  followRenames: boolean;
  ignoreWhitespace: boolean;
}

export interface OutputConfig {
  verbose: boolean;
  color: boolean;
  json: boolean;
  quiet: boolean;
  logLevel: LogLevel;
  logFile: string | null;
}

export enum LogLevel {
  DEBUG = 'debug',
  INFO = 'info',
  WARN = 'warn',
  ERROR = 'error',
  SILENT = 'silent',
}

export interface CacheConfig {
  enabled: boolean;
  ttl: number;
  maxEntries: number;
  directory: string;
}

export interface TelemetryConfig {
  enabled: boolean;
  anonymousId: string | null;
  endpoint: string | null;
}

export interface HooksConfig {
  preGenerate: string | null;
  postGenerate: string | null;
  preCommit: string | null;
  postCommit: string | null;
}

export interface TemplateConfig {
  subjectTemplate: string;
  bodyTemplate: string | null;
  footerTemplate: string | null;
  customTemplates: Record<string, string>;
}

export interface ScopeConfig {
  predefined: ScopeDefinition[];
  autoDetect: boolean;
  required: boolean;
}

export interface ScopeDefinition {
  name: string;
  description: string;
  paths: string[];
}

export type PartialConfig = {
  [K in keyof CommitCraftConfig]?: Partial<CommitCraftConfig[K]>;
};

export interface ConfigOverrides {
  source: ConfigSource;
  values: PartialConfig;
  priority: number;
}
