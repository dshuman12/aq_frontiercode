export enum CommitType {
  FEAT = 'feat',
  FIX = 'fix',
  DOCS = 'docs',
  STYLE = 'style',
  REFACTOR = 'refactor',
  PERF = 'perf',
  TEST = 'test',
  BUILD = 'build',
  CI = 'ci',
  CHORE = 'chore',
  REVERT = 'revert',
}

export interface CommitScope {
  name: string;
  description: string;
  patterns: string[];
}

export interface CommitMessage {
  type: CommitType;
  scope: string | null;
  subject: string;
  body: string | null;
  footer: string | null;
  breaking: boolean;
  issues: string[];
}

export interface CommitMessageOptions {
  type?: CommitType;
  scope?: string;
  maxSubjectLength: number;
  includeBody: boolean;
  includeFooter: boolean;
  includeBreakingChanges: boolean;
  includeIssueReferences: boolean;
  format: CommitFormat;
  language: string;
  emoji: boolean;
}

export enum CommitFormat {
  CONVENTIONAL = 'conventional',
  ANGULAR = 'angular',
  KARMA = 'karma',
  CUSTOM = 'custom',
}

export interface CommitTypeConfig {
  type: CommitType;
  label: string;
  description: string;
  emoji: string;
}

export const COMMIT_TYPE_CONFIGS: Record<CommitType, CommitTypeConfig> = {
  [CommitType.FEAT]: {
    type: CommitType.FEAT,
    label: 'Features',
    description: 'A new feature',
    emoji: '✨',
  },
  [CommitType.FIX]: {
    type: CommitType.FIX,
    label: 'Bug Fixes',
    description: 'A bug fix',
    emoji: '🐛',
  },
  [CommitType.DOCS]: {
    type: CommitType.DOCS,
    label: 'Documentation',
    description: 'Documentation only changes',
    emoji: '📚',
  },
  [CommitType.STYLE]: {
    type: CommitType.STYLE,
    label: 'Styles',
    description: 'Changes that do not affect the meaning of the code',
    emoji: '💎',
  },
  [CommitType.REFACTOR]: {
    type: CommitType.REFACTOR,
    label: 'Code Refactoring',
    description: 'A code change that neither fixes a bug nor adds a feature',
    emoji: '♻️',
  },
  [CommitType.PERF]: {
    type: CommitType.PERF,
    label: 'Performance Improvements',
    description: 'A code change that improves performance',
    emoji: '⚡',
  },
  [CommitType.TEST]: {
    type: CommitType.TEST,
    label: 'Tests',
    description: 'Adding missing tests or correcting existing tests',
    emoji: '🧪',
  },
  [CommitType.BUILD]: {
    type: CommitType.BUILD,
    label: 'Builds',
    description: 'Changes that affect the build system or external dependencies',
    emoji: '🏗️',
  },
  [CommitType.CI]: {
    type: CommitType.CI,
    label: 'Continuous Integration',
    description: 'Changes to CI configuration files and scripts',
    emoji: '🤖',
  },
  [CommitType.CHORE]: {
    type: CommitType.CHORE,
    label: 'Chores',
    description: 'Other changes that do not modify src or test files',
    emoji: '🔧',
  },
  [CommitType.REVERT]: {
    type: CommitType.REVERT,
    label: 'Reverts',
    description: 'Reverts a previous commit',
    emoji: '⏪',
  },
};
