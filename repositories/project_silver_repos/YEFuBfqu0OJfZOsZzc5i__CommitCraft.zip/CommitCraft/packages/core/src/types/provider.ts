import { CommitMessage, CommitMessageOptions } from './commit';
import { ParsedDiff } from './diff';

export enum AIProviderType {
  CLAUDE = 'claude',
  OPENAI = 'openai',
  LOCAL = 'local',
}

export interface AIProviderConfig {
  type: AIProviderType;
  apiKey: string;
  model: string;
  baseUrl: string | null;
  maxTokens: number;
  temperature: number;
  topP: number;
  timeout: number;
}

export interface TokenUsage {
  promptTokens: number;
  completionTokens: number;
  totalTokens: number;
  estimatedCost: number;
}

export interface AIResponse {
  message: CommitMessage;
  alternatives: CommitMessage[];
  usage: TokenUsage;
  latency: number;
  model: string;
  cached: boolean;
}

export interface AIRequestOptions {
  diff: ParsedDiff;
  commitOptions: CommitMessageOptions;
  context: PromptContext;
  signal?: AbortSignal;
}

export interface PromptContext {
  repoName: string | null;
  branchName: string | null;
  recentCommits: string[];
  fileCategories: Record<string, number>;
  projectType: string | null;
  conventionExamples: string[];
  additionalContext: string | null;
}

export interface ModelInfo {
  id: string;
  name: string;
  provider: AIProviderType;
  maxInputTokens: number;
  maxOutputTokens: number;
  costPerInputToken: number;
  costPerOutputToken: number;
  supportsStreaming: boolean;
}

export interface RateLimitInfo {
  remaining: number;
  limit: number;
  resetAt: Date;
  retryAfter: number | null;
}

export interface ProviderCapabilities {
  streaming: boolean;
  functionCalling: boolean;
  multipleAlternatives: boolean;
  maxAlternatives: number;
  tokenCounting: boolean;
}

export interface AIProvider {
  readonly type: AIProviderType;
  readonly capabilities: ProviderCapabilities;

  generateCommitMessage(options: AIRequestOptions): Promise<AIResponse>;
  estimateTokens(text: string): number;
  getModelInfo(): ModelInfo;
  getRateLimitInfo(): Promise<RateLimitInfo | null>;
  validateApiKey(): Promise<boolean>;
  dispose(): void;
}
