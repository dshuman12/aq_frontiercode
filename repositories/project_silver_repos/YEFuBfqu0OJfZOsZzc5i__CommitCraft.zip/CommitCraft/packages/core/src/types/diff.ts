export enum DiffLineType {
  ADDITION = 'addition',
  DELETION = 'deletion',
  CONTEXT = 'context',
  HEADER = 'header',
  NO_NEWLINE = 'no_newline',
}

export enum FileChangeType {
  ADDED = 'added',
  MODIFIED = 'modified',
  DELETED = 'deleted',
  RENAMED = 'renamed',
  COPIED = 'copied',
  TYPE_CHANGED = 'type_changed',
}

export interface DiffLine {
  type: DiffLineType;
  content: string;
  oldLineNumber: number | null;
  newLineNumber: number | null;
}

export interface DiffHunk {
  oldStart: number;
  oldLines: number;
  newStart: number;
  newLines: number;
  header: string;
  lines: DiffLine[];
}

export interface DiffStats {
  additions: number;
  deletions: number;
  changes: number;
  filesChanged: number;
}

export interface DiffFile {
  oldPath: string;
  newPath: string;
  changeType: FileChangeType;
  hunks: DiffHunk[];
  stats: DiffStats;
  isBinary: boolean;
  language: string | null;
  similarity: number | null;
}

export interface ParsedDiff {
  files: DiffFile[];
  stats: DiffStats;
  raw: string;
  truncated: boolean;
}

export interface FileChange {
  path: string;
  changeType: FileChangeType;
  additions: number;
  deletions: number;
  language: string | null;
  category: FileCategory;
}

export enum FileCategory {
  SOURCE = 'source',
  TEST = 'test',
  CONFIG = 'config',
  DOCUMENTATION = 'documentation',
  BUILD = 'build',
  CI = 'ci',
  ASSET = 'asset',
  DEPENDENCY = 'dependency',
  MIGRATION = 'migration',
  STYLE = 'style',
  OTHER = 'other',
}
