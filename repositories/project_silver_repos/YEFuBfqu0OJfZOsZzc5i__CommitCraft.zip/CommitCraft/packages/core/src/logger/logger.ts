import * as fs from 'fs';
import { LogLevel } from '../types/config';

export class Logger {
  private static instance: Logger | null = null;
  private level: LogLevel;
  private readonly logFile: string | null;
  private readonly useColor: boolean;

  private constructor(options: LoggerOptions = {}) {
    this.level = options.level ?? LogLevel.INFO;
    this.logFile = options.logFile ?? null;
    this.useColor = options.color ?? true;
  }

  static getInstance(options?: LoggerOptions): Logger {
    if (!Logger.instance) {
      Logger.instance = new Logger(options);
    }
    return Logger.instance;
  }

  static resetInstance(): void {
    Logger.instance = null;
  }

  setLevel(level: LogLevel): void {
    this.level = level;
  }

  debug(message: string, ...args: unknown[]): void {
    this.log(LogLevel.DEBUG, message, args);
  }

  info(message: string, ...args: unknown[]): void {
    this.log(LogLevel.INFO, message, args);
  }

  warn(message: string, ...args: unknown[]): void {
    this.log(LogLevel.WARN, message, args);
  }

  error(message: string, ...args: unknown[]): void {
    this.log(LogLevel.ERROR, message, args);
  }

  private log(level: LogLevel, message: string, args: unknown[]): void {
    if (!this.shouldLog(level)) return;

    const timestamp = new Date().toISOString();
    const levelStr = level.toUpperCase().padEnd(5);
    const formattedArgs = args.length > 0
      ? ' ' + args.map((a) => this.formatArg(a)).join(' ')
      : '';

    const plainMessage = `[${timestamp}] ${levelStr} ${message}${formattedArgs}`;

    if (this.logFile) {
      this.writeToFile(plainMessage);
    }

    if (this.level === LogLevel.SILENT) return;

    const coloredMessage = this.useColor
      ? `${this.getColor(level)}[${timestamp}] ${levelStr}${this.resetColor()} ${message}${formattedArgs}`
      : plainMessage;

    switch (level) {
      case LogLevel.ERROR:
        process.stderr.write(coloredMessage + '\n');
        break;
      case LogLevel.WARN:
        process.stderr.write(coloredMessage + '\n');
        break;
      default:
        process.stdout.write(coloredMessage + '\n');
    }
  }

  private shouldLog(level: LogLevel): boolean {
    const levels = [LogLevel.DEBUG, LogLevel.INFO, LogLevel.WARN, LogLevel.ERROR, LogLevel.SILENT];
    return levels.indexOf(level) >= levels.indexOf(this.level);
  }

  private getColor(level: LogLevel): string {
    switch (level) {
      case LogLevel.DEBUG:
        return '\x1b[36m';
      case LogLevel.INFO:
        return '\x1b[32m';
      case LogLevel.WARN:
        return '\x1b[33m';
      case LogLevel.ERROR:
        return '\x1b[31m';
      default:
        return '';
    }
  }

  private resetColor(): string {
    return '\x1b[0m';
  }

  private formatArg(arg: unknown): string {
    if (arg instanceof Error) {
      return `${arg.message}\n${arg.stack ?? ''}`;
    }
    if (typeof arg === 'object') {
      return JSON.stringify(arg, null, 2);
    }
    return String(arg);
  }

  private writeToFile(message: string): void {
    if (!this.logFile) return;

    try {
      fs.appendFileSync(this.logFile, message + '\n', 'utf-8');
    } catch {
      process.stderr.write(`Failed to write to log file: ${this.logFile}\n`);
    }
  }
}

export interface LoggerOptions {
  level?: LogLevel;
  logFile?: string | null;
  color?: boolean;
}
