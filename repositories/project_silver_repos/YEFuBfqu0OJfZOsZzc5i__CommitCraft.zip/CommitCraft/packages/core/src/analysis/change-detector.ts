import { DiffFile, DiffHunk, DiffLineType, ParsedDiff } from '../types/diff';

export interface DetectedChange {
  type: ChangeType;
  description: string;
  file: string;
  startLine: number;
  endLine: number;
  significance: 'high' | 'medium' | 'low';
}

export enum ChangeType {
  FUNCTION_ADDED = 'function_added',
  FUNCTION_MODIFIED = 'function_modified',
  FUNCTION_REMOVED = 'function_removed',
  CLASS_ADDED = 'class_added',
  CLASS_MODIFIED = 'class_modified',
  CLASS_REMOVED = 'class_removed',
  IMPORT_ADDED = 'import_added',
  IMPORT_REMOVED = 'import_removed',
  VARIABLE_ADDED = 'variable_added',
  VARIABLE_MODIFIED = 'variable_modified',
  ERROR_HANDLING_ADDED = 'error_handling_added',
  ERROR_HANDLING_MODIFIED = 'error_handling_modified',
  INTERFACE_ADDED = 'interface_added',
  INTERFACE_MODIFIED = 'interface_modified',
  TYPE_ADDED = 'type_added',
  CONDITIONAL_ADDED = 'conditional_added',
  CONDITIONAL_MODIFIED = 'conditional_modified',
  RETURN_MODIFIED = 'return_modified',
  STRING_LITERAL_CHANGED = 'string_literal_changed',
  COMMENT_CHANGED = 'comment_changed',
  WHITESPACE_CHANGED = 'whitespace_changed',
}

export class ChangeDetector {
  detect(diff: ParsedDiff): DetectedChange[] {
    const changes: DetectedChange[] = [];

    for (const file of diff.files) {
      if (file.isBinary) continue;
      changes.push(...this.analyzeFile(file));
    }

    return changes.sort((a, b) => {
      const sigOrder = { high: 0, medium: 1, low: 2 };
      return sigOrder[a.significance] - sigOrder[b.significance];
    });
  }

  private analyzeFile(file: DiffFile): DetectedChange[] {
    const changes: DetectedChange[] = [];

    for (const hunk of file.hunks) {
      changes.push(...this.analyzeHunk(file.newPath, hunk));
    }

    return changes;
  }

  private analyzeHunk(filePath: string, hunk: DiffHunk): DetectedChange[] {
    const changes: DetectedChange[] = [];
    const addedLines = hunk.lines.filter((l) => l.type === DiffLineType.ADDITION);
    const removedLines = hunk.lines.filter((l) => l.type === DiffLineType.DELETION);

    for (const line of addedLines) {
      const content = line.content.trim();
      const lineNum = line.newLineNumber ?? hunk.newStart;

      if (this.isFunctionDeclaration(content)) {
        changes.push({
          type: ChangeType.FUNCTION_ADDED,
          description: this.extractFunctionName(content),
          file: filePath,
          startLine: lineNum,
          endLine: lineNum,
          significance: 'high',
        });
      }

      if (this.isClassDeclaration(content)) {
        changes.push({
          type: ChangeType.CLASS_ADDED,
          description: this.extractClassName(content),
          file: filePath,
          startLine: lineNum,
          endLine: lineNum,
          significance: 'high',
        });
      }

      if (this.isInterfaceDeclaration(content)) {
        changes.push({
          type: ChangeType.INTERFACE_ADDED,
          description: this.extractInterfaceName(content),
          file: filePath,
          startLine: lineNum,
          endLine: lineNum,
          significance: 'medium',
        });
      }

      if (this.isTypeDeclaration(content)) {
        changes.push({
          type: ChangeType.TYPE_ADDED,
          description: this.extractTypeName(content),
          file: filePath,
          startLine: lineNum,
          endLine: lineNum,
          significance: 'medium',
        });
      }

      if (this.isImportStatement(content)) {
        changes.push({
          type: ChangeType.IMPORT_ADDED,
          description: content,
          file: filePath,
          startLine: lineNum,
          endLine: lineNum,
          significance: 'low',
        });
      }

      if (this.isErrorHandling(content)) {
        changes.push({
          type: ChangeType.ERROR_HANDLING_ADDED,
          description: 'Error handling added',
          file: filePath,
          startLine: lineNum,
          endLine: lineNum,
          significance: 'medium',
        });
      }

      if (this.isConditional(content)) {
        changes.push({
          type: ChangeType.CONDITIONAL_ADDED,
          description: 'Conditional logic added',
          file: filePath,
          startLine: lineNum,
          endLine: lineNum,
          significance: 'medium',
        });
      }
    }

    for (const line of removedLines) {
      const content = line.content.trim();
      const lineNum = line.oldLineNumber ?? hunk.oldStart;

      if (this.isFunctionDeclaration(content)) {
        changes.push({
          type: ChangeType.FUNCTION_REMOVED,
          description: this.extractFunctionName(content),
          file: filePath,
          startLine: lineNum,
          endLine: lineNum,
          significance: 'high',
        });
      }

      if (this.isClassDeclaration(content)) {
        changes.push({
          type: ChangeType.CLASS_REMOVED,
          description: this.extractClassName(content),
          file: filePath,
          startLine: lineNum,
          endLine: lineNum,
          significance: 'high',
        });
      }

      if (this.isImportStatement(content)) {
        changes.push({
          type: ChangeType.IMPORT_REMOVED,
          description: content,
          file: filePath,
          startLine: lineNum,
          endLine: lineNum,
          significance: 'low',
        });
      }
    }

    return changes;
  }

  private isFunctionDeclaration(content: string): boolean {
    return (
      /^(export\s+)?(async\s+)?function\s+\w+/.test(content) ||
      /^(export\s+)?(const|let|var)\s+\w+\s*=\s*(async\s+)?\(/.test(content) ||
      /^(public|private|protected|static)\s+(async\s+)?\w+\s*\(/.test(content) ||
      /^\w+\s*\([^)]*\)\s*[:{]/.test(content)
    );
  }

  private isClassDeclaration(content: string): boolean {
    return /^(export\s+)?(abstract\s+)?class\s+\w+/.test(content);
  }

  private isInterfaceDeclaration(content: string): boolean {
    return /^(export\s+)?interface\s+\w+/.test(content);
  }

  private isTypeDeclaration(content: string): boolean {
    return /^(export\s+)?type\s+\w+\s*=/.test(content);
  }

  private isImportStatement(content: string): boolean {
    return /^import\s+/.test(content) || /^from\s+/.test(content) || /^require\s*\(/.test(content);
  }

  private isErrorHandling(content: string): boolean {
    return /\b(try|catch|throw|Error|reject)\b/.test(content);
  }

  private isConditional(content: string): boolean {
    return /^(if|else|switch|case)\s*[\s(]/.test(content);
  }

  private extractFunctionName(content: string): string {
    const match = content.match(/function\s+(\w+)/) ??
      content.match(/(const|let|var)\s+(\w+)\s*=/) ??
      content.match(/(\w+)\s*\(/);

    if (match) {
      return match[2] ?? match[1];
    }
    return 'anonymous';
  }

  private extractClassName(content: string): string {
    const match = content.match(/class\s+(\w+)/);
    return match?.[1] ?? 'UnknownClass';
  }

  private extractInterfaceName(content: string): string {
    const match = content.match(/interface\s+(\w+)/);
    return match?.[1] ?? 'UnknownInterface';
  }

  private extractTypeName(content: string): string {
    const match = content.match(/type\s+(\w+)/);
    return match?.[1] ?? 'UnknownType';
  }
}
