import * as path from 'path';

import { FileCategory, FileChange } from '../types/diff';
import { LanguageDetector } from '../git/language-detector';

export interface CategorizationResult {
  categories: Map<FileCategory, CategorizedFiles>;
  primaryCategory: FileCategory;
  distribution: CategoryDistribution;
}

export interface CategorizedFiles {
  files: FileChange[];
  totalAdditions: number;
  totalDeletions: number;
  languages: string[];
}

export interface CategoryDistribution {
  percentages: Record<string, number>;
  dominant: FileCategory;
  mixed: boolean;
}

export class FileCategorizer {
  private readonly languageDetector: LanguageDetector;
  private readonly customRules: CategorizationRule[] = [];

  constructor() {
    this.languageDetector = new LanguageDetector();
  }

  addRule(rule: CategorizationRule): void {
    this.customRules.push(rule);
  }

  categorize(files: FileChange[]): CategorizationResult {
    const categories = new Map<FileCategory, CategorizedFiles>();

    for (const file of files) {
      const category = this.categorizeFile(file);
      const existing = categories.get(category) ?? {
        files: [],
        totalAdditions: 0,
        totalDeletions: 0,
        languages: [],
      };

      existing.files.push(file);
      existing.totalAdditions += file.additions;
      existing.totalDeletions += file.deletions;
      if (file.language && !existing.languages.includes(file.language)) {
        existing.languages.push(file.language);
      }

      categories.set(category, existing);
    }

    const distribution = this.calculateDistribution(categories, files.length);
    const primaryCategory = distribution.dominant;

    return { categories, primaryCategory, distribution };
  }

  categorizeFile(file: FileChange): FileCategory {
    for (const rule of this.customRules) {
      const result = rule.match(file);
      if (result !== null) {
        return result;
      }
    }

    return this.defaultCategorize(file.path);
  }

  private defaultCategorize(filePath: string): FileCategory {
    const basename = path.basename(filePath);
    const ext = path.extname(filePath).toLowerCase();
    const lowerPath = filePath.toLowerCase();

    if (this.isTestPath(lowerPath, basename)) return FileCategory.TEST;
    if (this.isCIPath(lowerPath)) return FileCategory.CI;
    if (this.isMigrationPath(lowerPath)) return FileCategory.MIGRATION;
    if (this.isDependencyFile(basename)) return FileCategory.DEPENDENCY;
    if (this.isDocPath(lowerPath, ext)) return FileCategory.DOCUMENTATION;
    if (this.isAssetFile(ext)) return FileCategory.ASSET;
    if (this.isStyleFile(ext)) return FileCategory.STYLE;
    if (this.isBuildFile(lowerPath, basename)) return FileCategory.BUILD;
    if (this.isConfigFile(lowerPath, basename, ext)) return FileCategory.CONFIG;
    if (this.languageDetector.isSourceCode(filePath)) return FileCategory.SOURCE;

    return FileCategory.OTHER;
  }

  private isTestPath(lowerPath: string, basename: string): boolean {
    return (
      lowerPath.includes('__tests__') ||
      lowerPath.includes('/test/') ||
      lowerPath.includes('/tests/') ||
      lowerPath.includes('/spec/') ||
      lowerPath.includes('/specs/') ||
      basename.includes('.test.') ||
      basename.includes('.spec.') ||
      basename.startsWith('test_') ||
      basename.includes('_test.')
    );
  }

  private isCIPath(lowerPath: string): boolean {
    return (
      lowerPath.includes('.github/workflows') ||
      lowerPath.includes('.github/actions') ||
      lowerPath.includes('.gitlab-ci') ||
      lowerPath.includes('.circleci') ||
      lowerPath.includes('jenkinsfile') ||
      lowerPath.includes('.travis.yml') ||
      lowerPath.includes('azure-pipelines')
    );
  }

  private isMigrationPath(lowerPath: string): boolean {
    return (
      lowerPath.includes('/migrations/') ||
      lowerPath.includes('/migrate/') ||
      lowerPath.includes('/migration/') ||
      lowerPath.includes('alembic/versions')
    );
  }

  private isDependencyFile(basename: string): boolean {
    const depFiles = new Set([
      'package-lock.json',
      'yarn.lock',
      'pnpm-lock.yaml',
      'Cargo.lock',
      'go.sum',
      'Pipfile.lock',
      'Gemfile.lock',
      'composer.lock',
      'poetry.lock',
    ]);
    return depFiles.has(basename);
  }

  private isDocPath(lowerPath: string, ext: string): boolean {
    const docExtensions = new Set(['.md', '.mdx', '.rst', '.txt', '.adoc']);
    return (
      docExtensions.has(ext) ||
      lowerPath.includes('/docs/') ||
      lowerPath.includes('/documentation/')
    );
  }

  private isAssetFile(ext: string): boolean {
    const assetExtensions = new Set([
      '.png', '.jpg', '.jpeg', '.gif', '.svg', '.ico', '.webp',
      '.mp4', '.webm', '.mp3', '.wav', '.ogg',
      '.woff', '.woff2', '.ttf', '.eot', '.otf',
      '.pdf', '.zip', '.tar', '.gz',
    ]);
    return assetExtensions.has(ext);
  }

  private isStyleFile(ext: string): boolean {
    return new Set(['.css', '.scss', '.sass', '.less', '.styl']).has(ext);
  }

  private isBuildFile(lowerPath: string, basename: string): boolean {
    const buildFiles = new Set([
      'makefile', 'cmakeLists.txt', 'build.gradle', 'build.gradle.kts',
      'pom.xml', 'build.sbt',
    ]);
    return (
      buildFiles.has(basename.toLowerCase()) ||
      lowerPath.includes('webpack') ||
      lowerPath.includes('rollup') ||
      lowerPath.includes('vite.config') ||
      lowerPath.includes('esbuild') ||
      lowerPath.includes('dockerfile')
    );
  }

  private isConfigFile(lowerPath: string, basename: string, ext: string): boolean {
    const configExtensions = new Set(['.json', '.yaml', '.yml', '.toml', '.ini', '.cfg']);
    return (
      (configExtensions.has(ext) && basename.startsWith('.')) ||
      basename.includes('config') ||
      basename.includes('rc') ||
      lowerPath.includes('.vscode/') ||
      lowerPath.includes('.idea/')
    );
  }

  private calculateDistribution(
    categories: Map<FileCategory, CategorizedFiles>,
    totalFiles: number,
  ): CategoryDistribution {
    const percentages: Record<string, number> = {};
    let maxCategory = FileCategory.OTHER;
    let maxCount = 0;

    for (const [category, data] of categories) {
      const percentage = Math.round((data.files.length / totalFiles) * 100);
      percentages[category] = percentage;

      if (data.files.length > maxCount) {
        maxCount = data.files.length;
        maxCategory = category;
      }
    }

    return {
      percentages,
      dominant: maxCategory,
      mixed: categories.size > 2,
    };
  }
}

export interface CategorizationRule {
  name: string;
  match(file: FileChange): FileCategory | null;
}
