export { DiffAnalyzer } from './diff-analyzer';
export type { AnalysisResult, ChangeComplexity, ChangePattern, AnalysisSummary } from './diff-analyzer';
export { FileCategorizer } from './file-categorizer';
export type { CategorizationResult, CategorizedFiles, CategoryDistribution, CategorizationRule } from './file-categorizer';
export { ChangeDetector, ChangeType } from './change-detector';
export type { DetectedChange } from './change-detector';
