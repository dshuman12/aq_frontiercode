import { CommitType } from '../types/commit';
import { DiffLineType, FileChangeType, ParsedDiff } from '../types/diff';

export interface AnalysisResult {
  suggestedType: CommitType;
  confidence: number;
  reasoning: string;
  complexity: ChangeComplexity;
  patterns: ChangePattern[];
  summary: AnalysisSummary;
}

export interface ChangeComplexity {
  score: number;
  level: 'trivial' | 'simple' | 'moderate' | 'complex' | 'major';
  factors: string[];
}

export interface ChangePattern {
  name: string;
  description: string;
  confidence: number;
  files: string[];
}

export interface AnalysisSummary {
  primaryAction: string;
  affectedAreas: string[];
  changeCharacter: string;
}

export class DiffAnalyzer {
  analyze(diff: ParsedDiff): AnalysisResult {
    const patterns = this.detectPatterns(diff);
    const suggestedType = this.inferCommitType(diff, patterns);
    const confidence = this.calculateConfidence(diff, patterns, suggestedType);
    const complexity = this.assessComplexity(diff);
    const summary = this.buildSummary(diff, patterns, suggestedType);
    const reasoning = this.buildReasoning(diff, patterns, suggestedType);

    return {
      suggestedType,
      confidence,
      reasoning,
      complexity,
      patterns,
      summary,
    };
  }

  private detectPatterns(diff: ParsedDiff): ChangePattern[] {
    const patterns: ChangePattern[] = [];

    patterns.push(...this.detectNewFeaturePattern(diff));
    patterns.push(...this.detectBugFixPattern(diff));
    patterns.push(...this.detectRefactorPattern(diff));
    patterns.push(...this.detectTestPattern(diff));
    patterns.push(...this.detectDocPattern(diff));
    patterns.push(...this.detectConfigPattern(diff));
    patterns.push(...this.detectStylePattern(diff));
    patterns.push(...this.detectDependencyPattern(diff));

    return patterns.sort((a, b) => b.confidence - a.confidence);
  }

  private detectNewFeaturePattern(diff: ParsedDiff): ChangePattern[] {
    const patterns: ChangePattern[] = [];
    const newFiles = diff.files.filter((f) => f.changeType === FileChangeType.ADDED);
    const heavyAdditions = diff.files.filter(
      (f) => f.stats.additions > f.stats.deletions * 3 && f.stats.additions > 10,
    );

    if (newFiles.length > 0) {
      patterns.push({
        name: 'new-files',
        description: `${newFiles.length} new file(s) added`,
        confidence: 0.7,
        files: newFiles.map((f) => f.newPath),
      });
    }

    if (heavyAdditions.length > 0) {
      patterns.push({
        name: 'heavy-additions',
        description: 'Significantly more additions than deletions',
        confidence: 0.5,
        files: heavyAdditions.map((f) => f.newPath),
      });
    }

    return patterns;
  }

  private detectBugFixPattern(diff: ParsedDiff): ChangePattern[] {
    const patterns: ChangePattern[] = [];
    const fixIndicators = ['fix', 'bug', 'issue', 'error', 'handle', 'catch', 'throw', 'null', 'undefined', 'NaN'];

    const filesWithFixes: string[] = [];
    for (const file of diff.files) {
      for (const hunk of file.hunks) {
        const addedContent = hunk.lines
          .filter((l) => l.type === DiffLineType.ADDITION)
          .map((l) => l.content.toLowerCase())
          .join(' ');

        if (fixIndicators.some((indicator) => addedContent.includes(indicator))) {
          filesWithFixes.push(file.newPath);
          break;
        }
      }
    }

    if (filesWithFixes.length > 0) {
      const isSmallChange = diff.stats.changes < 50;
      patterns.push({
        name: 'bug-fix-indicators',
        description: 'Error handling or fix-related changes detected',
        confidence: isSmallChange ? 0.6 : 0.4,
        files: filesWithFixes,
      });
    }

    return patterns;
  }

  private detectRefactorPattern(diff: ParsedDiff): ChangePattern[] {
    const patterns: ChangePattern[] = [];
    const renamedFiles = diff.files.filter((f) => f.changeType === FileChangeType.RENAMED);
    const balancedChanges = diff.files.filter(
      (f) =>
        f.stats.additions > 0 &&
        f.stats.deletions > 0 &&
        Math.abs(f.stats.additions - f.stats.deletions) < Math.min(f.stats.additions, f.stats.deletions) * 0.5,
    );

    if (renamedFiles.length > 0) {
      patterns.push({
        name: 'file-renames',
        description: `${renamedFiles.length} file(s) renamed`,
        confidence: 0.7,
        files: renamedFiles.map((f) => `${f.oldPath} → ${f.newPath}`),
      });
    }

    if (balancedChanges.length > 0 && balancedChanges.length === diff.files.length) {
      patterns.push({
        name: 'balanced-changes',
        description: 'Balanced additions and deletions suggest restructuring',
        confidence: 0.5,
        files: balancedChanges.map((f) => f.newPath),
      });
    }

    return patterns;
  }

  private detectTestPattern(diff: ParsedDiff): ChangePattern[] {
    const testFiles = diff.files.filter((f) =>
      /\.(test|spec)\.(ts|js|tsx|jsx)$/.test(f.newPath) ||
      f.newPath.includes('__tests__') ||
      f.newPath.includes('test/') ||
      f.newPath.includes('tests/'),
    );

    if (testFiles.length > 0 && testFiles.length === diff.files.length) {
      return [{
        name: 'test-only',
        description: 'Changes are limited to test files',
        confidence: 0.9,
        files: testFiles.map((f) => f.newPath),
      }];
    }

    if (testFiles.length > 0) {
      return [{
        name: 'includes-tests',
        description: `${testFiles.length} test file(s) modified`,
        confidence: 0.3,
        files: testFiles.map((f) => f.newPath),
      }];
    }

    return [];
  }

  private detectDocPattern(diff: ParsedDiff): ChangePattern[] {
    const docFiles = diff.files.filter((f) =>
      /\.(md|mdx|txt|rst|adoc)$/.test(f.newPath) ||
      f.newPath.toLowerCase().includes('docs/') ||
      f.newPath.toLowerCase().includes('documentation/') ||
      f.newPath.toLowerCase() === 'readme.md' ||
      f.newPath.toLowerCase() === 'changelog.md',
    );

    if (docFiles.length > 0 && docFiles.length === diff.files.length) {
      return [{
        name: 'docs-only',
        description: 'Changes are limited to documentation',
        confidence: 0.95,
        files: docFiles.map((f) => f.newPath),
      }];
    }

    return [];
  }

  private detectConfigPattern(diff: ParsedDiff): ChangePattern[] {
    const configFiles = diff.files.filter((f) =>
      f.newPath.startsWith('.') ||
      /\.(json|yaml|yml|toml|ini|cfg)$/.test(f.newPath) ||
      f.newPath.includes('config') ||
      f.newPath.includes('Dockerfile') ||
      f.newPath.includes('Makefile'),
    );

    if (configFiles.length > 0 && configFiles.length === diff.files.length) {
      return [{
        name: 'config-only',
        description: 'Changes are limited to configuration files',
        confidence: 0.8,
        files: configFiles.map((f) => f.newPath),
      }];
    }

    return [];
  }

  private detectStylePattern(diff: ParsedDiff): ChangePattern[] {
    const styleFiles = diff.files.filter((f) =>
      /\.(css|scss|sass|less|styl)$/.test(f.newPath),
    );

    const formattingOnly = diff.files.every((f) => {
      if (f.stats.additions !== f.stats.deletions) return false;
      return f.hunks.every((hunk) => {
        const added = hunk.lines.filter((l) => l.type === DiffLineType.ADDITION).map((l) => l.content.trim());
        const deleted = hunk.lines.filter((l) => l.type === DiffLineType.DELETION).map((l) => l.content.trim());
        return added.length === deleted.length && added.every((line, i) => line === deleted[i]);
      });
    });

    if (formattingOnly && diff.files.length > 0) {
      return [{
        name: 'formatting-only',
        description: 'Changes appear to be formatting/whitespace only',
        confidence: 0.9,
        files: diff.files.map((f) => f.newPath),
      }];
    }

    if (styleFiles.length > 0 && styleFiles.length === diff.files.length) {
      return [{
        name: 'style-only',
        description: 'Changes are limited to style files',
        confidence: 0.8,
        files: styleFiles.map((f) => f.newPath),
      }];
    }

    return [];
  }

  private detectDependencyPattern(diff: ParsedDiff): ChangePattern[] {
    const depFiles = diff.files.filter((f) =>
      f.newPath === 'package.json' ||
      f.newPath === 'package-lock.json' ||
      f.newPath === 'yarn.lock' ||
      f.newPath === 'pnpm-lock.yaml' ||
      f.newPath === 'Cargo.toml' ||
      f.newPath === 'Cargo.lock' ||
      f.newPath === 'go.mod' ||
      f.newPath === 'go.sum' ||
      f.newPath === 'requirements.txt' ||
      f.newPath === 'Pipfile.lock' ||
      f.newPath === 'Gemfile.lock',
    );

    if (depFiles.length > 0 && depFiles.length === diff.files.length) {
      return [{
        name: 'dependency-update',
        description: 'Changes are limited to dependency files',
        confidence: 0.85,
        files: depFiles.map((f) => f.newPath),
      }];
    }

    return [];
  }

  private inferCommitType(diff: ParsedDiff, patterns: ChangePattern[]): CommitType {
    const typeScores = new Map<CommitType, number>();

    for (const pattern of patterns) {
      const typeMapping = this.patternToTypeMapping(pattern.name);
      for (const [type, weight] of typeMapping) {
        const current = typeScores.get(type) ?? 0;
        typeScores.set(type, current + pattern.confidence * weight);
      }
    }

    if (typeScores.size === 0) {
      return this.inferFromStats(diff);
    }

    const sorted = [...typeScores.entries()].sort((a, b) => b[1] - a[1]);
    return sorted[0][0];
  }

  private patternToTypeMapping(patternName: string): Map<CommitType, number> {
    const mappings: Record<string, Array<[CommitType, number]>> = {
      'new-files': [[CommitType.FEAT, 1.0]],
      'heavy-additions': [[CommitType.FEAT, 0.8], [CommitType.REFACTOR, 0.2]],
      'bug-fix-indicators': [[CommitType.FIX, 1.0]],
      'file-renames': [[CommitType.REFACTOR, 1.0]],
      'balanced-changes': [[CommitType.REFACTOR, 0.7], [CommitType.FIX, 0.3]],
      'test-only': [[CommitType.TEST, 1.0]],
      'includes-tests': [[CommitType.FEAT, 0.5], [CommitType.FIX, 0.3], [CommitType.TEST, 0.2]],
      'docs-only': [[CommitType.DOCS, 1.0]],
      'config-only': [[CommitType.CHORE, 0.6], [CommitType.BUILD, 0.4]],
      'formatting-only': [[CommitType.STYLE, 1.0]],
      'style-only': [[CommitType.STYLE, 1.0]],
      'dependency-update': [[CommitType.BUILD, 0.6], [CommitType.CHORE, 0.4]],
    };

    const mapping = mappings[patternName] ?? [[CommitType.CHORE, 1.0]];
    return new Map(mapping);
  }

  private inferFromStats(diff: ParsedDiff): CommitType {
    if (diff.stats.filesChanged === 0) return CommitType.CHORE;
    if (diff.stats.additions > diff.stats.deletions * 2) return CommitType.FEAT;
    if (diff.stats.deletions > diff.stats.additions * 2) return CommitType.REFACTOR;
    return CommitType.CHORE;
  }

  private calculateConfidence(
    diff: ParsedDiff,
    patterns: ChangePattern[],
    _suggestedType: CommitType,
  ): number {
    if (patterns.length === 0) return 0.3;

    const topPattern = patterns[0];
    let confidence = topPattern.confidence;

    if (patterns.length === 1) {
      confidence *= 1.2;
    } else if (patterns.length > 3) {
      confidence *= 0.8;
    }

    if (diff.stats.filesChanged <= 3) {
      confidence *= 1.1;
    } else if (diff.stats.filesChanged > 10) {
      confidence *= 0.8;
    }

    return Math.min(Math.max(confidence, 0.1), 1.0);
  }

  private assessComplexity(diff: ParsedDiff): ChangeComplexity {
    const factors: string[] = [];
    let score = 0;

    score += Math.min(diff.stats.filesChanged * 2, 20);
    if (diff.stats.filesChanged > 5) factors.push(`${diff.stats.filesChanged} files changed`);

    score += Math.min(diff.stats.changes * 0.1, 30);
    if (diff.stats.changes > 100) factors.push(`${diff.stats.changes} total line changes`);

    const languages = new Set(diff.files.map((f) => f.language).filter(Boolean));
    score += languages.size * 3;
    if (languages.size > 2) factors.push(`${languages.size} languages involved`);

    const hasNewFiles = diff.files.some((f) => f.changeType === FileChangeType.ADDED);
    const hasDeletedFiles = diff.files.some((f) => f.changeType === FileChangeType.DELETED);
    if (hasNewFiles && hasDeletedFiles) {
      score += 10;
      factors.push('Mix of file additions and deletions');
    }

    let level: ChangeComplexity['level'];
    if (score < 10) level = 'trivial';
    else if (score < 25) level = 'simple';
    else if (score < 50) level = 'moderate';
    else if (score < 80) level = 'complex';
    else level = 'major';

    return { score: Math.min(score, 100), level, factors };
  }

  private buildSummary(
    diff: ParsedDiff,
    patterns: ChangePattern[],
    suggestedType: CommitType,
  ): AnalysisSummary {
    const primaryAction = this.determinePrimaryAction(diff, suggestedType);
    const affectedAreas = this.determineAffectedAreas(diff);
    const changeCharacter = patterns.length > 0
      ? patterns[0].description
      : `${diff.stats.filesChanged} file(s) modified`;

    return { primaryAction, affectedAreas, changeCharacter };
  }

  private determinePrimaryAction(diff: ParsedDiff, type: CommitType): string {
    switch (type) {
      case CommitType.FEAT: return 'Adding new functionality';
      case CommitType.FIX: return 'Fixing an issue';
      case CommitType.REFACTOR: return 'Restructuring code';
      case CommitType.DOCS: return 'Updating documentation';
      case CommitType.TEST: return 'Modifying tests';
      case CommitType.STYLE: return 'Formatting changes';
      case CommitType.BUILD: return 'Build system changes';
      case CommitType.CI: return 'CI/CD changes';
      case CommitType.PERF: return 'Performance improvements';
      default: return `Modifying ${diff.stats.filesChanged} file(s)`;
    }
  }

  private determineAffectedAreas(diff: ParsedDiff): string[] {
    const areas = new Set<string>();

    for (const file of diff.files) {
      const parts = file.newPath.split('/');
      if (parts.length > 1) {
        areas.add(parts[0]);
      }
    }

    return [...areas];
  }

  private buildReasoning(
    diff: ParsedDiff,
    patterns: ChangePattern[],
    suggestedType: CommitType,
  ): string {
    const parts: string[] = [];

    parts.push(`Suggested type: ${suggestedType}`);
    parts.push(`Files changed: ${diff.stats.filesChanged}`);
    parts.push(`Lines: +${diff.stats.additions}/-${diff.stats.deletions}`);

    if (patterns.length > 0) {
      parts.push('Detected patterns:');
      for (const pattern of patterns.slice(0, 3)) {
        parts.push(`  - ${pattern.name}: ${pattern.description} (${Math.round(pattern.confidence * 100)}%)`);
      }
    }

    return parts.join('\n');
  }
}
