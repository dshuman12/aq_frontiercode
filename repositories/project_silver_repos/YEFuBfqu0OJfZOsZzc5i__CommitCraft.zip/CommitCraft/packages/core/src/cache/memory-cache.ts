export interface CacheEntry<T> {
  value: T;
  expiresAt: number;
  createdAt: number;
  accessCount: number;
  lastAccessed: number;
}

export class MemoryCache<T> {
  private readonly entries: Map<string, CacheEntry<T>> = new Map();
  private readonly maxEntries: number;
  private readonly defaultTtl: number;

  constructor(options: MemoryCacheOptions = {}) {
    this.maxEntries = options.maxEntries ?? 100;
    this.defaultTtl = options.ttl ?? 3600000;
  }

  get(key: string): T | null {
    const entry = this.entries.get(key);

    if (!entry) return null;

    if (Date.now() > entry.expiresAt) {
      this.entries.delete(key);
      return null;
    }

    entry.accessCount++;
    entry.lastAccessed = Date.now();
    return entry.value;
  }

  set(key: string, value: T, ttl?: number): void {
    if (this.entries.size >= this.maxEntries) {
      this.evict();
    }

    const now = Date.now();
    this.entries.set(key, {
      value,
      expiresAt: now + (ttl ?? this.defaultTtl),
      createdAt: now,
      accessCount: 0,
      lastAccessed: now,
    });
  }

  has(key: string): boolean {
    const entry = this.entries.get(key);
    if (!entry) return false;

    if (Date.now() > entry.expiresAt) {
      this.entries.delete(key);
      return false;
    }

    return true;
  }

  delete(key: string): boolean {
    return this.entries.delete(key);
  }

  clear(): void {
    this.entries.clear();
  }

  size(): number {
    this.removeExpired();
    return this.entries.size;
  }

  keys(): string[] {
    this.removeExpired();
    return [...this.entries.keys()];
  }

  getStats(): CacheStats {
    this.removeExpired();

    let totalAccessCount = 0;
    let oldestEntry = Date.now();
    let newestEntry = 0;

    for (const entry of this.entries.values()) {
      totalAccessCount += entry.accessCount;
      if (entry.createdAt < oldestEntry) oldestEntry = entry.createdAt;
      if (entry.createdAt > newestEntry) newestEntry = entry.createdAt;
    }

    return {
      size: this.entries.size,
      maxSize: this.maxEntries,
      totalAccessCount,
      oldestEntryAge: this.entries.size > 0 ? Date.now() - oldestEntry : 0,
      newestEntryAge: this.entries.size > 0 ? Date.now() - newestEntry : 0,
    };
  }

  private evict(): void {
    this.removeExpired();

    if (this.entries.size < this.maxEntries) return;

    let lruKey: string | null = null;
    let lruTime = Infinity;

    for (const [key, entry] of this.entries) {
      if (entry.lastAccessed < lruTime) {
        lruTime = entry.lastAccessed;
        lruKey = key;
      }
    }

    if (lruKey) {
      this.entries.delete(lruKey);
    }
  }

  private removeExpired(): void {
    const now = Date.now();
    for (const [key, entry] of this.entries) {
      if (now > entry.expiresAt) {
        this.entries.delete(key);
      }
    }
  }
}

export interface MemoryCacheOptions {
  maxEntries?: number;
  ttl?: number;
}

export interface CacheStats {
  size: number;
  maxSize: number;
  totalAccessCount: number;
  oldestEntryAge: number;
  newestEntryAge: number;
}
