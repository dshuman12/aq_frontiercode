import * as fs from 'fs';
import * as path from 'path';
import * as crypto from 'crypto';

export interface FileCacheOptions {
  directory: string;
  ttl: number;
  maxEntries: number;
}

interface FileCacheEntry<T> {
  value: T;
  expiresAt: number;
  createdAt: number;
  key: string;
}

export class FileCache<T> {
  private readonly directory: string;
  private readonly ttl: number;
  private readonly maxEntries: number;

  constructor(options: FileCacheOptions) {
    this.directory = options.directory;
    this.ttl = options.ttl;
    this.maxEntries = options.maxEntries;
    this.ensureDirectory();
  }

  get(key: string): T | null {
    const filePath = this.getFilePath(key);

    if (!fs.existsSync(filePath)) return null;

    try {
      const content = fs.readFileSync(filePath, 'utf-8');
      const entry = JSON.parse(content) as FileCacheEntry<T>;

      if (Date.now() > entry.expiresAt) {
        this.delete(key);
        return null;
      }

      return entry.value;
    } catch {
      this.delete(key);
      return null;
    }
  }

  set(key: string, value: T, ttl?: number): void {
    this.ensureDirectory();
    this.enforceMaxEntries();

    const entry: FileCacheEntry<T> = {
      value,
      expiresAt: Date.now() + (ttl ?? this.ttl),
      createdAt: Date.now(),
      key,
    };

    const filePath = this.getFilePath(key);
    fs.writeFileSync(filePath, JSON.stringify(entry, null, 2), 'utf-8');
  }

  has(key: string): boolean {
    return this.get(key) !== null;
  }

  delete(key: string): boolean {
    const filePath = this.getFilePath(key);

    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
      return true;
    }

    return false;
  }

  clear(): void {
    if (!fs.existsSync(this.directory)) return;

    const files = fs.readdirSync(this.directory);
    for (const file of files) {
      if (file.endsWith('.json')) {
        fs.unlinkSync(path.join(this.directory, file));
      }
    }
  }

  size(): number {
    if (!fs.existsSync(this.directory)) return 0;

    const files = fs.readdirSync(this.directory).filter((f) => f.endsWith('.json'));
    return files.length;
  }

  keys(): string[] {
    if (!fs.existsSync(this.directory)) return [];

    const result: string[] = [];
    const files = fs.readdirSync(this.directory).filter((f) => f.endsWith('.json'));

    for (const file of files) {
      try {
        const content = fs.readFileSync(path.join(this.directory, file), 'utf-8');
        const entry = JSON.parse(content) as FileCacheEntry<T>;
        if (Date.now() <= entry.expiresAt) {
          result.push(entry.key);
        }
      } catch {
        continue;
      }
    }

    return result;
  }

  cleanup(): number {
    if (!fs.existsSync(this.directory)) return 0;

    let removed = 0;
    const files = fs.readdirSync(this.directory).filter((f) => f.endsWith('.json'));

    for (const file of files) {
      const filePath = path.join(this.directory, file);
      try {
        const content = fs.readFileSync(filePath, 'utf-8');
        const entry = JSON.parse(content) as FileCacheEntry<T>;
        if (Date.now() > entry.expiresAt) {
          fs.unlinkSync(filePath);
          removed++;
        }
      } catch {
        fs.unlinkSync(filePath);
        removed++;
      }
    }

    return removed;
  }

  private getFilePath(key: string): string {
    const hash = crypto.createHash('sha256').update(key).digest('hex').substring(0, 16);
    return path.join(this.directory, `${hash}.json`);
  }

  private ensureDirectory(): void {
    if (!fs.existsSync(this.directory)) {
      fs.mkdirSync(this.directory, { recursive: true });
    }
  }

  private enforceMaxEntries(): void {
    if (!fs.existsSync(this.directory)) return;

    const files = fs.readdirSync(this.directory)
      .filter((f) => f.endsWith('.json'))
      .map((f) => ({
        name: f,
        path: path.join(this.directory, f),
        mtime: fs.statSync(path.join(this.directory, f)).mtimeMs,
      }))
      .sort((a, b) => a.mtime - b.mtime);

    while (files.length >= this.maxEntries) {
      const oldest = files.shift();
      if (oldest) {
        fs.unlinkSync(oldest.path);
      }
    }
  }
}
