import { CommitMessage, CommitType } from '../types/commit';
import { ConventionalCommitFormatter } from '../commit/conventional';
import { GitRepository } from '../git/repository';

export interface HistoryEntry {
  hash: string;
  message: string;
  parsed: CommitMessage | null;
  author: string;
  date: Date;
  isConventional: boolean;
}

export interface HistoryAnalysis {
  entries: HistoryEntry[];
  conventionalPercentage: number;
  typeDistribution: Record<string, number>;
  scopeDistribution: Record<string, number>;
  averageSubjectLength: number;
  commonPatterns: string[];
  consistencyScore: number;
}

export class CommitHistory {
  private readonly repo: GitRepository;
  private readonly formatter: ConventionalCommitFormatter;

  constructor(repo: GitRepository) {
    this.repo = repo;
    this.formatter = new ConventionalCommitFormatter();
  }

  async getHistory(count: number = 50): Promise<HistoryEntry[]> {
    const git = this.repo.getSimpleGit();
    const log = await git.log({ maxCount: count });

    return log.all.map((entry) => {
      const parsed = this.formatter.parse(entry.message);
      return {
        hash: entry.hash,
        message: entry.message,
        parsed,
        author: entry.author_name,
        date: new Date(entry.date),
        isConventional: parsed !== null,
      };
    });
  }

  async analyze(count: number = 100): Promise<HistoryAnalysis> {
    const entries = await this.getHistory(count);
    const conventional = entries.filter((e) => e.isConventional);

    const typeDistribution: Record<string, number> = {};
    const scopeDistribution: Record<string, number> = {};
    let totalSubjectLength = 0;

    for (const entry of conventional) {
      if (entry.parsed) {
        typeDistribution[entry.parsed.type] =
          (typeDistribution[entry.parsed.type] ?? 0) + 1;

        if (entry.parsed.scope) {
          scopeDistribution[entry.parsed.scope] =
            (scopeDistribution[entry.parsed.scope] ?? 0) + 1;
        }

        totalSubjectLength += entry.parsed.subject.length;
      }
    }

    const averageSubjectLength =
      conventional.length > 0
        ? Math.round(totalSubjectLength / conventional.length)
        : 0;

    const commonPatterns = this.detectPatterns(entries);
    const consistencyScore = this.calculateConsistencyScore(entries);

    return {
      entries,
      conventionalPercentage:
        entries.length > 0
          ? Math.round((conventional.length / entries.length) * 100)
          : 0,
      typeDistribution,
      scopeDistribution,
      averageSubjectLength,
      commonPatterns,
      consistencyScore,
    };
  }

  async getRecentConventionalExamples(count: number = 5): Promise<string[]> {
    const entries = await this.getHistory(50);
    return entries
      .filter((e) => e.isConventional)
      .slice(0, count)
      .map((e) => e.message.split('\n')[0]);
  }

  async getMostUsedTypes(limit: number = 5): Promise<Array<{ type: CommitType; count: number }>> {
    const analysis = await this.analyze();
    return Object.entries(analysis.typeDistribution)
      .map(([type, count]) => ({ type: type as CommitType, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, limit);
  }

  async getMostUsedScopes(limit: number = 5): Promise<Array<{ scope: string; count: number }>> {
    const analysis = await this.analyze();
    return Object.entries(analysis.scopeDistribution)
      .map(([scope, count]) => ({ scope, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, limit);
  }

  private detectPatterns(entries: HistoryEntry[]): string[] {
    const patterns: string[] = [];

    const conventional = entries.filter((e) => e.isConventional);

    if (conventional.length > entries.length * 0.8) {
      patterns.push('Consistent use of conventional commits');
    }

    const withScopes = conventional.filter((e) => e.parsed?.scope);
    if (withScopes.length > conventional.length * 0.5) {
      patterns.push('Frequent use of scopes');
    }

    const withBody = entries.filter((e) => e.message.includes('\n\n'));
    if (withBody.length > entries.length * 0.3) {
      patterns.push('Detailed commit bodies are common');
    }

    const avgLength =
      entries.length > 0
        ? entries.reduce((sum, e) => sum + e.message.split('\n')[0].length, 0) / entries.length
        : 0;

    if (avgLength < 50) {
      patterns.push('Short, concise subject lines');
    } else if (avgLength > 72) {
      patterns.push('Longer subject lines (may exceed recommended limit)');
    }

    return patterns;
  }

  private calculateConsistencyScore(entries: HistoryEntry[]): number {
    if (entries.length === 0) return 100;

    let score = 100;

    const conventionalRatio = entries.filter((e) => e.isConventional).length / entries.length;
    score *= conventionalRatio;

    const subjectLengths = entries.map((e) => e.message.split('\n')[0].length);
    const avgLength = subjectLengths.reduce((a, b) => a + b, 0) / subjectLengths.length;
    const variance =
      subjectLengths.reduce((sum, len) => sum + Math.pow(len - avgLength, 2), 0) /
      subjectLengths.length;
    const stdDev = Math.sqrt(variance);

    if (stdDev > 20) {
      score *= 0.8;
    }

    return Math.round(Math.max(0, Math.min(100, score)));
  }
}
