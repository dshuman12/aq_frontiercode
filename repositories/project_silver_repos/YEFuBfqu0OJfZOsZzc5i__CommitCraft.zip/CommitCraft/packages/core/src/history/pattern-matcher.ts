import { CommitMessage, CommitType } from '../types/commit';

export interface PatternMatch {
  pattern: CommitPattern;
  confidence: number;
  examples: string[];
}

export interface CommitPattern {
  name: string;
  description: string;
  regex: RegExp;
  type: CommitType | null;
  scope: string | null;
}

export class PatternMatcher {
  private readonly patterns: CommitPattern[] = [];

  constructor() {
    this.registerDefaultPatterns();
  }

  addPattern(pattern: CommitPattern): void {
    this.patterns.push(pattern);
  }

  match(commitMessages: string[]): PatternMatch[] {
    const matches: PatternMatch[] = [];

    for (const pattern of this.patterns) {
      const matchingMessages = commitMessages.filter((msg) =>
        pattern.regex.test(msg),
      );

      if (matchingMessages.length > 0) {
        matches.push({
          pattern,
          confidence: matchingMessages.length / commitMessages.length,
          examples: matchingMessages.slice(0, 3),
        });
      }
    }

    return matches.sort((a, b) => b.confidence - a.confidence);
  }

  findSimilar(message: CommitMessage, commitMessages: string[]): SimilarCommit[] {
    const results: SimilarCommit[] = [];

    for (const msg of commitMessages) {
      const similarity = this.calculateSimilarity(message, msg);
      if (similarity > 0.3) {
        results.push({ message: msg, similarity });
      }
    }

    return results.sort((a, b) => b.similarity - a.similarity).slice(0, 5);
  }

  private calculateSimilarity(message: CommitMessage, rawMessage: string): number {
    const subject = rawMessage.split('\n')[0].toLowerCase();
    const messageSubject = `${message.type}${message.scope ? `(${message.scope})` : ''}: ${message.subject}`.toLowerCase();

    const tokens1 = new Set(messageSubject.split(/\W+/));
    const tokens2 = new Set(subject.split(/\W+/));

    let intersection = 0;
    for (const token of tokens1) {
      if (tokens2.has(token)) {
        intersection++;
      }
    }

    const union = new Set([...tokens1, ...tokens2]).size;
    return union > 0 ? intersection / union : 0;
  }

  suggestType(commitMessages: string[]): TypeSuggestion | null {
    const typeCounts = new Map<CommitType, number>();

    for (const msg of commitMessages) {
      const match = msg.match(/^(\w+)(?:\([^)]*\))?!?:/);
      if (match) {
        const type = match[1].toLowerCase() as CommitType;
        if (Object.values(CommitType).includes(type)) {
          typeCounts.set(type, (typeCounts.get(type) ?? 0) + 1);
        }
      }
    }

    if (typeCounts.size === 0) return null;

    const sorted = [...typeCounts.entries()].sort((a, b) => b[1] - a[1]);
    const [mostCommon, count] = sorted[0];

    return {
      type: mostCommon,
      confidence: count / commitMessages.length,
      alternativeTypes: sorted.slice(1, 4).map(([type]) => type),
    };
  }

  suggestScope(commitMessages: string[]): ScopeSuggestion | null {
    const scopeCounts = new Map<string, number>();

    for (const msg of commitMessages) {
      const match = msg.match(/^\w+\(([^)]+)\)/);
      if (match) {
        const scope = match[1];
        scopeCounts.set(scope, (scopeCounts.get(scope) ?? 0) + 1);
      }
    }

    if (scopeCounts.size === 0) return null;

    const sorted = [...scopeCounts.entries()].sort((a, b) => b[1] - a[1]);
    const [mostCommon, count] = sorted[0];

    return {
      scope: mostCommon,
      confidence: count / commitMessages.length,
      alternativeScopes: sorted.slice(1, 4).map(([scope]) => scope),
    };
  }

  private registerDefaultPatterns(): void {
    this.addPattern({
      name: 'conventional-commit',
      description: 'Standard conventional commit format',
      regex: /^(feat|fix|docs|style|refactor|perf|test|build|ci|chore|revert)(\([^)]+\))?!?:\s.+/,
      type: null,
      scope: null,
    });

    this.addPattern({
      name: 'merge-commit',
      description: 'Git merge commit',
      regex: /^Merge\s+(branch|pull\s+request|commit)\s+/,
      type: null,
      scope: null,
    });

    this.addPattern({
      name: 'revert-commit',
      description: 'Revert commit',
      regex: /^Revert\s+".*"/,
      type: CommitType.REVERT,
      scope: null,
    });

    this.addPattern({
      name: 'wip-commit',
      description: 'Work in progress commit',
      regex: /^(WIP|wip|Work in progress)/i,
      type: CommitType.CHORE,
      scope: null,
    });

    this.addPattern({
      name: 'version-bump',
      description: 'Version bump commit',
      regex: /^(v?\d+\.\d+\.\d+|bump|release|version)/i,
      type: CommitType.CHORE,
      scope: null,
    });
  }
}

export interface SimilarCommit {
  message: string;
  similarity: number;
}

export interface TypeSuggestion {
  type: CommitType;
  confidence: number;
  alternativeTypes: CommitType[];
}

export interface ScopeSuggestion {
  scope: string;
  confidence: number;
  alternativeScopes: string[];
}
