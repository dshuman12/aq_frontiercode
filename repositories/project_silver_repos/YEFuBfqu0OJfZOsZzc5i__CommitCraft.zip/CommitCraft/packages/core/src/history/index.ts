export { CommitHistory } from './commit-history';
export type { HistoryEntry, HistoryAnalysis } from './commit-history';
export { PatternMatcher } from './pattern-matcher';
export type { PatternMatch, CommitPattern, SimilarCommit, TypeSuggestion, ScopeSuggestion } from './pattern-matcher';
