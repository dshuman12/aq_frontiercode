import { CommitMessage, CommitType } from '../types/commit';
import { CommitCraftError, ErrorCode } from '../utils/errors';

export class ResponseParser {
  parse(rawResponse: string): CommitMessage {
    const cleaned = this.extractJson(rawResponse);
    const parsed = this.parseJson(cleaned);
    return this.validateAndNormalize(parsed);
  }

  parseMultiple(rawResponse: string): CommitMessage[] {
    const cleaned = this.extractJsonArray(rawResponse);
    const parsed = this.parseJsonArray(cleaned);
    return parsed.map((item) => this.validateAndNormalize(item));
  }

  private extractJson(text: string): string {
    const jsonBlockMatch = text.match(/```(?:json)?\s*\n?([\s\S]*?)\n?```/);
    if (jsonBlockMatch) {
      return jsonBlockMatch[1].trim();
    }

    const objectMatch = text.match(/\{[\s\S]*\}/);
    if (objectMatch) {
      return objectMatch[0];
    }

    return text.trim();
  }

  private extractJsonArray(text: string): string {
    const jsonBlockMatch = text.match(/```(?:json)?\s*\n?([\s\S]*?)\n?```/);
    if (jsonBlockMatch) {
      return jsonBlockMatch[1].trim();
    }

    const arrayMatch = text.match(/\[[\s\S]*\]/);
    if (arrayMatch) {
      return arrayMatch[0];
    }

    return text.trim();
  }

  private parseJson(text: string): RawCommitResponse {
    try {
      return JSON.parse(text) as RawCommitResponse;
    } catch {
      throw new CommitCraftError(
        ErrorCode.AI_PARSE_ERROR,
        `Failed to parse AI response as JSON: ${text.substring(0, 200)}`,
      );
    }
  }

  private parseJsonArray(text: string): RawCommitResponse[] {
    try {
      const parsed = JSON.parse(text) as unknown;
      if (Array.isArray(parsed)) {
        return parsed as RawCommitResponse[];
      }
      return [parsed as RawCommitResponse];
    } catch {
      throw new CommitCraftError(
        ErrorCode.AI_PARSE_ERROR,
        `Failed to parse AI response array: ${text.substring(0, 200)}`,
      );
    }
  }

  private validateAndNormalize(raw: RawCommitResponse): CommitMessage {
    const type = this.normalizeType(raw.type);
    const scope = this.normalizeScope(raw.scope);
    const subject = this.normalizeSubject(raw.subject);
    const body = this.normalizeBody(raw.body);
    const footer = this.normalizeFooter(raw.footer);
    const breaking = raw.breaking === true;
    const issues = this.normalizeIssues(raw.issues);

    if (!subject) {
      throw new CommitCraftError(
        ErrorCode.AI_PARSE_ERROR,
        'AI response missing required subject field',
      );
    }

    return { type, scope, subject, body, footer, breaking, issues };
  }

  private normalizeType(type: unknown): CommitType {
    if (typeof type !== 'string') {
      return CommitType.CHORE;
    }

    const lower = type.toLowerCase().trim();
    const typeMap: Record<string, CommitType> = {
      feat: CommitType.FEAT,
      feature: CommitType.FEAT,
      fix: CommitType.FIX,
      bugfix: CommitType.FIX,
      docs: CommitType.DOCS,
      doc: CommitType.DOCS,
      documentation: CommitType.DOCS,
      style: CommitType.STYLE,
      refactor: CommitType.REFACTOR,
      perf: CommitType.PERF,
      performance: CommitType.PERF,
      test: CommitType.TEST,
      tests: CommitType.TEST,
      build: CommitType.BUILD,
      ci: CommitType.CI,
      chore: CommitType.CHORE,
      revert: CommitType.REVERT,
    };

    return typeMap[lower] ?? CommitType.CHORE;
  }

  private normalizeScope(scope: unknown): string | null {
    if (scope === null || scope === undefined || scope === '') {
      return null;
    }
    if (typeof scope !== 'string') {
      return null;
    }

    const cleaned = scope.trim().toLowerCase().replace(/[^a-z0-9-_]/g, '-');
    return cleaned || null;
  }

  private normalizeSubject(subject: unknown): string {
    if (typeof subject !== 'string' || !subject.trim()) {
      return '';
    }

    let normalized = subject.trim();

    normalized = normalized.charAt(0).toUpperCase() + normalized.slice(1);

    if (normalized.endsWith('.')) {
      normalized = normalized.slice(0, -1);
    }

    return normalized;
  }

  private normalizeBody(body: unknown): string | null {
    if (body === null || body === undefined || body === '') {
      return null;
    }
    if (typeof body !== 'string') {
      return null;
    }

    return body.trim() || null;
  }

  private normalizeFooter(footer: unknown): string | null {
    if (footer === null || footer === undefined || footer === '') {
      return null;
    }
    if (typeof footer !== 'string') {
      return null;
    }

    return footer.trim() || null;
  }

  private normalizeIssues(issues: unknown): string[] {
    if (!Array.isArray(issues)) {
      return [];
    }

    return issues
      .filter((item): item is string => typeof item === 'string')
      .map((issue) => {
        const trimmed = issue.trim();
        if (trimmed.match(/^\d+$/)) {
          return `#${trimmed}`;
        }
        return trimmed;
      })
      .filter((issue) => issue.length > 0);
  }
}

interface RawCommitResponse {
  type?: unknown;
  scope?: unknown;
  subject?: unknown;
  body?: unknown;
  footer?: unknown;
  breaking?: unknown;
  issues?: unknown;
}
