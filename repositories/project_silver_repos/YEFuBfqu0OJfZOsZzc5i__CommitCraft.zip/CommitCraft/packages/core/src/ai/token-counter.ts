export class TokenCounter {
  private readonly averageCharsPerToken: number = 4;

  count(text: string): number {
    return this.estimateByCharCount(text);
  }

  countMessages(messages: TokenMessage[]): number {
    let total = 0;

    for (const message of messages) {
      total += 4;
      total += this.count(message.role);
      total += this.count(message.content);
    }

    total += 2;
    return total;
  }

  private estimateByCharCount(text: string): number {
    if (!text) return 0;

    let tokenEstimate = 0;
    const words = text.split(/\s+/);

    for (const word of words) {
      if (word.length === 0) continue;

      if (this.isCodeToken(word)) {
        tokenEstimate += Math.ceil(word.length / 3);
      } else if (this.isPunctuation(word)) {
        tokenEstimate += 1;
      } else if (this.isNumber(word)) {
        tokenEstimate += Math.ceil(word.length / 2);
      } else {
        tokenEstimate += Math.ceil(word.length / this.averageCharsPerToken);
      }
    }

    const newlineCount = (text.match(/\n/g) ?? []).length;
    tokenEstimate += Math.ceil(newlineCount * 0.5);

    return Math.max(1, tokenEstimate);
  }

  private isCodeToken(word: string): boolean {
    return /[{}()\[\];:.,<>=!&|^~?@#$%*/\\+-]/.test(word) && word.length > 1;
  }

  private isPunctuation(word: string): boolean {
    return /^[{}()\[\];:.,<>=!&|^~?@#$%*/\\+-]$/.test(word);
  }

  private isNumber(word: string): boolean {
    return /^\d+(\.\d+)?$/.test(word);
  }

  estimateCost(
    inputTokens: number,
    outputTokens: number,
    costPerInputToken: number,
    costPerOutputToken: number,
  ): CostEstimate {
    const inputCost = inputTokens * costPerInputToken;
    const outputCost = outputTokens * costPerOutputToken;

    return {
      inputTokens,
      outputTokens,
      totalTokens: inputTokens + outputTokens,
      inputCost,
      outputCost,
      totalCost: inputCost + outputCost,
      currency: 'USD',
    };
  }

  isWithinLimit(text: string, maxTokens: number): boolean {
    return this.count(text) <= maxTokens;
  }

  truncateToLimit(text: string, maxTokens: number): TruncationResult {
    const currentTokens = this.count(text);

    if (currentTokens <= maxTokens) {
      return { text, truncated: false, originalTokens: currentTokens, finalTokens: currentTokens };
    }

    const ratio = maxTokens / currentTokens;
    const targetLength = Math.floor(text.length * ratio * 0.9);
    const truncated = text.substring(0, targetLength);

    const lastNewline = truncated.lastIndexOf('\n');
    const cleanTruncated = lastNewline > targetLength * 0.8
      ? truncated.substring(0, lastNewline)
      : truncated;

    const finalText = cleanTruncated + '\n... (truncated)';

    return {
      text: finalText,
      truncated: true,
      originalTokens: currentTokens,
      finalTokens: this.count(finalText),
    };
  }
}

export interface TokenMessage {
  role: string;
  content: string;
}

export interface CostEstimate {
  inputTokens: number;
  outputTokens: number;
  totalTokens: number;
  inputCost: number;
  outputCost: number;
  totalCost: number;
  currency: string;
}

export interface TruncationResult {
  text: string;
  truncated: boolean;
  originalTokens: number;
  finalTokens: number;
}
