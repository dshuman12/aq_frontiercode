import { CommitFormat, CommitMessageOptions, CommitType, COMMIT_TYPE_CONFIGS } from '../types/commit';
import { ParsedDiff, DiffFile, FileCategory } from '../types/diff';
import { PromptContext } from '../types/provider';

export class PromptBuilder {
  buildSystemPrompt(options: CommitMessageOptions): string {
    const formatDescription = this.getFormatDescription(options.format);
    const typeDescriptions = this.getTypeDescriptions(options);

    const parts = [
      'You are an expert software engineer that generates precise, descriptive git commit messages.',
      '',
      `Generate commit messages in ${formatDescription} format.`,
      '',
      'Rules:',
      `- Subject line must be ${options.maxSubjectLength} characters or fewer`,
      '- Use imperative mood in the subject line (e.g., "add" not "added" or "adds")',
      '- Do not end the subject line with a period',
      '- Capitalize the first letter of the subject after the type/scope prefix',
      '- Be specific and descriptive about what changed and why',
    ];

    if (options.includeBody) {
      parts.push(
        '- Include a body that explains the motivation for the change',
        '- Wrap body lines at 100 characters',
        '- Separate subject from body with a blank line',
      );
    }

    if (options.includeBreakingChanges) {
      parts.push('- Note any breaking changes with BREAKING CHANGE: prefix in the footer');
    }

    if (options.includeIssueReferences) {
      parts.push('- Reference related issues if apparent from the code changes');
    }

    if (options.emoji) {
      parts.push('- Include an appropriate emoji prefix');
    }

    parts.push('', 'Available commit types:', ...typeDescriptions);

    parts.push(
      '',
      'Response format:',
      'Return ONLY a JSON object with this structure:',
      '{',
      '  "type": "<commit_type>",',
      '  "scope": "<scope_or_null>",',
      '  "subject": "<subject_line>",',
      '  "body": "<body_or_null>",',
      '  "footer": "<footer_or_null>",',
      '  "breaking": false,',
      '  "issues": []',
      '}',
    );

    return parts.join('\n');
  }

  buildUserPrompt(
    diff: ParsedDiff,
    options: CommitMessageOptions,
    context: PromptContext,
  ): string {
    const parts: string[] = [];

    if (context.repoName) {
      parts.push(`Repository: ${context.repoName}`);
    }
    if (context.branchName) {
      parts.push(`Branch: ${context.branchName}`);
    }

    if (context.recentCommits.length > 0) {
      parts.push('', 'Recent commits for style reference:');
      for (const commit of context.recentCommits.slice(0, 5)) {
        parts.push(`  - ${commit}`);
      }
    }

    if (Object.keys(context.fileCategories).length > 0) {
      parts.push('', 'File categories in this change:');
      for (const [category, count] of Object.entries(context.fileCategories)) {
        parts.push(`  - ${category}: ${count} file(s)`);
      }
    }

    if (context.projectType) {
      parts.push(`\nProject type: ${context.projectType}`);
    }

    if (context.additionalContext) {
      parts.push(`\nAdditional context: ${context.additionalContext}`);
    }

    parts.push('', 'Changes summary:', this.buildDiffSummary(diff));

    if (options.type) {
      parts.push(`\nForced commit type: ${options.type}`);
    }

    if (options.scope) {
      parts.push(`Forced scope: ${options.scope}`);
    }

    parts.push('', 'Diff:', this.buildDiffContent(diff));

    parts.push(
      '',
      'Generate a commit message based on the above changes.',
      'Return ONLY the JSON object, no other text.',
    );

    return parts.join('\n');
  }

  buildAlternativesPrompt(
    originalMessage: string,
    diff: ParsedDiff,
    count: number,
  ): string {
    return [
      `Given this commit message: "${originalMessage}"`,
      `And these changes:`,
      this.buildDiffSummary(diff),
      '',
      `Generate ${count} alternative commit messages with different perspectives.`,
      'Return a JSON array of commit message objects.',
    ].join('\n');
  }

  private buildDiffSummary(diff: ParsedDiff): string {
    const parts: string[] = [
      `Files changed: ${diff.stats.filesChanged}`,
      `Additions: +${diff.stats.additions}`,
      `Deletions: -${diff.stats.deletions}`,
      '',
    ];

    for (const file of diff.files) {
      const changeSymbol = this.getChangeSymbol(file);
      parts.push(`${changeSymbol} ${file.newPath} (+${file.stats.additions}/-${file.stats.deletions})`);
    }

    return parts.join('\n');
  }

  private buildDiffContent(diff: ParsedDiff): string {
    const maxDiffLines = 500;
    const lines: string[] = [];
    let totalLines = 0;

    for (const file of diff.files) {
      if (file.isBinary) {
        lines.push(`Binary file changed: ${file.newPath}`);
        continue;
      }

      lines.push(`--- ${file.oldPath}`);
      lines.push(`+++ ${file.newPath}`);

      for (const hunk of file.hunks) {
        lines.push(`@@ -${hunk.oldStart},${hunk.oldLines} +${hunk.newStart},${hunk.newLines} @@ ${hunk.header}`);
        for (const line of hunk.lines) {
          if (totalLines >= maxDiffLines) {
            lines.push('... (diff truncated)');
            return lines.join('\n');
          }
          const prefix = this.getLinePrefix(line.type);
          lines.push(`${prefix}${line.content}`);
          totalLines++;
        }
      }
      lines.push('');
    }

    return lines.join('\n');
  }

  private getChangeSymbol(file: DiffFile): string {
    switch (file.changeType) {
      case 'added':
        return 'A';
      case 'deleted':
        return 'D';
      case 'renamed':
        return 'R';
      case 'copied':
        return 'C';
      default:
        return 'M';
    }
  }

  private getLinePrefix(type: string): string {
    switch (type) {
      case 'addition':
        return '+';
      case 'deletion':
        return '-';
      default:
        return ' ';
    }
  }

  private getFormatDescription(format: CommitFormat): string {
    switch (format) {
      case CommitFormat.CONVENTIONAL:
        return 'Conventional Commits (type(scope): subject)';
      case CommitFormat.ANGULAR:
        return 'Angular (type(scope): subject)';
      case CommitFormat.KARMA:
        return 'Karma (type(scope): subject)';
      case CommitFormat.CUSTOM:
        return 'Custom template-based';
      default:
        return 'Conventional Commits';
    }
  }

  private getTypeDescriptions(options: CommitMessageOptions): string[] {
    const allowedTypes = options.type
      ? [options.type]
      : Object.values(CommitType);

    return allowedTypes.map((type) => {
      const config = COMMIT_TYPE_CONFIGS[type];
      const emoji = options.emoji ? ` ${config.emoji}` : '';
      return `  - ${type}${emoji}: ${config.description}`;
    });
  }

  estimatePromptSize(diff: ParsedDiff, context: PromptContext): PromptSizeEstimate {
    const systemPrompt = this.buildSystemPrompt({
      maxSubjectLength: 72,
      includeBody: true,
      includeFooter: false,
      includeBreakingChanges: true,
      includeIssueReferences: true,
      format: CommitFormat.CONVENTIONAL,
      language: 'en',
      emoji: false,
    });

    const userPrompt = this.buildUserPrompt(diff, {
      maxSubjectLength: 72,
      includeBody: true,
      includeFooter: false,
      includeBreakingChanges: true,
      includeIssueReferences: true,
      format: CommitFormat.CONVENTIONAL,
      language: 'en',
      emoji: false,
    }, context);

    const estimatedTokens = Math.ceil((systemPrompt.length + userPrompt.length) / 4);

    return {
      systemPromptChars: systemPrompt.length,
      userPromptChars: userPrompt.length,
      totalChars: systemPrompt.length + userPrompt.length,
      estimatedTokens,
      withinLimits: estimatedTokens < 100000,
    };
  }
}

export interface PromptSizeEstimate {
  systemPromptChars: number;
  userPromptChars: number;
  totalChars: number;
  estimatedTokens: number;
  withinLimits: boolean;
}

export function buildCategoryMap(files: { category: FileCategory }[]): Record<string, number> {
  const map: Record<string, number> = {};
  for (const file of files) {
    map[file.category] = (map[file.category] ?? 0) + 1;
  }
  return map;
}
