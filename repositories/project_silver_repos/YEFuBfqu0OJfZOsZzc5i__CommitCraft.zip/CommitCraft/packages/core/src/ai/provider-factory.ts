import { AIProvider, AIProviderConfig, AIProviderType } from '../types/provider';
import { CommitCraftError, ErrorCode } from '../utils/errors';

import { ClaudeProvider } from './claude-provider';

export class ProviderFactory {
  private static readonly providers = new Map<string, ProviderConstructor>();

  static {
    ProviderFactory.register(AIProviderType.CLAUDE, ClaudeProvider);
  }

  static register(type: string, constructor: ProviderConstructor): void {
    ProviderFactory.providers.set(type, constructor);
  }

  static create(config: AIProviderConfig): AIProvider {
    const Constructor = ProviderFactory.providers.get(config.type);

    if (!Constructor) {
      throw new CommitCraftError(
        ErrorCode.AI_PROVIDER_NOT_FOUND,
        `Unknown AI provider: ${config.type}. Available: ${[...ProviderFactory.providers.keys()].join(', ')}`,
      );
    }

    return new Constructor(config);
  }

  static getAvailableProviders(): string[] {
    return [...ProviderFactory.providers.keys()];
  }

  static isProviderAvailable(type: string): boolean {
    return ProviderFactory.providers.has(type);
  }

  static createFromEnv(type: AIProviderType = AIProviderType.CLAUDE): AIProvider {
    const apiKey = process.env.COMMITCRAFT_API_KEY ?? process.env.ANTHROPIC_API_KEY ?? '';
    const model = process.env.COMMITCRAFT_MODEL ?? 'claude-sonnet-4-20250514';

    return ProviderFactory.create({
      type,
      apiKey,
      model,
      baseUrl: process.env.COMMITCRAFT_BASE_URL ?? null,
      maxTokens: parseInt(process.env.COMMITCRAFT_MAX_TOKENS ?? '1024', 10),
      temperature: parseFloat(process.env.COMMITCRAFT_TEMPERATURE ?? '0.3'),
      topP: parseFloat(process.env.COMMITCRAFT_TOP_P ?? '0.9'),
      timeout: parseInt(process.env.COMMITCRAFT_TIMEOUT ?? '30000', 10),
    });
  }
}

type ProviderConstructor = new (config: AIProviderConfig) => AIProvider;
