import Anthropic, { type ClientOptions } from '@anthropic-ai/sdk';

import {
  AIProvider,
  AIProviderConfig,
  AIProviderType,
  AIRequestOptions,
  AIResponse,
  ModelInfo,
  ProviderCapabilities,
  RateLimitInfo,
  TokenUsage,
} from '../types/provider';
import { CommitCraftError, ErrorCode } from '../utils/errors';

import { PromptBuilder } from './prompt-builder';
import { ResponseParser } from './response-parser';
import { TokenCounter } from './token-counter';

const CLAUDE_MODELS: Record<string, ModelInfo> = {
  'claude-sonnet-4-20250514': {
    id: 'claude-sonnet-4-20250514',
    name: 'Claude Sonnet 4',
    provider: AIProviderType.CLAUDE,
    maxInputTokens: 200000,
    maxOutputTokens: 8192,
    costPerInputToken: 0.000003,
    costPerOutputToken: 0.000015,
    supportsStreaming: true,
  },
  'claude-3-5-sonnet-20241022': {
    id: 'claude-3-5-sonnet-20241022',
    name: 'Claude 3.5 Sonnet',
    provider: AIProviderType.CLAUDE,
    maxInputTokens: 200000,
    maxOutputTokens: 8192,
    costPerInputToken: 0.000003,
    costPerOutputToken: 0.000015,
    supportsStreaming: true,
  },
  'claude-3-haiku-20240307': {
    id: 'claude-3-haiku-20240307',
    name: 'Claude 3 Haiku',
    provider: AIProviderType.CLAUDE,
    maxInputTokens: 200000,
    maxOutputTokens: 4096,
    costPerInputToken: 0.00000025,
    costPerOutputToken: 0.00000125,
    supportsStreaming: true,
  },
};

export class ClaudeProvider implements AIProvider {
  readonly type = AIProviderType.CLAUDE;
  readonly capabilities: ProviderCapabilities = {
    streaming: true,
    functionCalling: true,
    multipleAlternatives: true,
    maxAlternatives: 5,
    tokenCounting: true,
  };

  private readonly client: Anthropic;
  private readonly config: AIProviderConfig;
  private readonly promptBuilder: PromptBuilder;
  private readonly responseParser: ResponseParser;
  private readonly tokenCounter: TokenCounter;
  private rateLimitState: RateLimitInfo | null = null;

  constructor(config: AIProviderConfig) {
    this.config = config;
    this.promptBuilder = new PromptBuilder();
    this.responseParser = new ResponseParser();
    this.tokenCounter = new TokenCounter();

    const clientOptions: ClientOptions = {
      apiKey: config.apiKey,
      timeout: config.timeout,
    };

    if (config.baseUrl) {
      clientOptions.baseURL = config.baseUrl;
    }

    this.client = new Anthropic(clientOptions);
  }

  async generateCommitMessage(options: AIRequestOptions): Promise<AIResponse> {
    const startTime = Date.now();

    const systemPrompt = this.promptBuilder.buildSystemPrompt(options.commitOptions);
    const userPrompt = this.promptBuilder.buildUserPrompt(
      options.diff,
      options.commitOptions,
      options.context,
    );

    let lastError: Error | null = null;
    const maxRetries = 3;

    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        const response = await this.makeRequest(systemPrompt, userPrompt, options.signal);
        const latency = Date.now() - startTime;

        const message = this.responseParser.parse(response.content);

        const usage: TokenUsage = {
          promptTokens: response.inputTokens,
          completionTokens: response.outputTokens,
          totalTokens: response.inputTokens + response.outputTokens,
          estimatedCost: this.calculateCost(response.inputTokens, response.outputTokens),
        };

        return {
          message,
          alternatives: [],
          usage,
          latency,
          model: this.config.model,
          cached: false,
        };
      } catch (error) {
        lastError = error instanceof Error ? error : new Error(String(error));

        if (this.isRetryableError(error) && attempt < maxRetries) {
          const delay = this.calculateBackoff(attempt);
          await this.sleep(delay);
          continue;
        }

        if (this.isRateLimitError(error)) {
          this.updateRateLimitState(error);
          throw new CommitCraftError(
            ErrorCode.AI_RATE_LIMITED,
            'API rate limit exceeded. Please try again later.',
          );
        }

        throw error;
      }
    }

    throw new CommitCraftError(
      ErrorCode.AI_REQUEST_FAILED,
      `Failed after ${maxRetries + 1} attempts: ${lastError?.message ?? 'Unknown error'}`,
    );
  }

  private async makeRequest(
    systemPrompt: string,
    userPrompt: string,
    signal?: AbortSignal,
  ): Promise<ClaudeResponse> {
    try {
      const requestOptions: Anthropic.MessageCreateParamsNonStreaming = {
        model: this.config.model,
        max_tokens: this.config.maxTokens,
        temperature: this.config.temperature,
        top_p: this.config.topP,
        system: systemPrompt,
        messages: [
          {
            role: 'user',
            content: userPrompt,
          },
        ],
      };

      const response = await this.client.messages.create(requestOptions, {
        signal: signal as AbortSignal | undefined,
      });

      const textContent = response.content.find((block) => block.type === 'text');
      if (!textContent || textContent.type !== 'text') {
        throw new CommitCraftError(
          ErrorCode.AI_PARSE_ERROR,
          'No text content in API response',
        );
      }

      return {
        content: textContent.text,
        inputTokens: response.usage.input_tokens,
        outputTokens: response.usage.output_tokens,
        stopReason: response.stop_reason ?? 'end_turn',
      };
    } catch (error) {
      if (error instanceof CommitCraftError) {
        throw error;
      }

      if (error instanceof Anthropic.APIError) {
        throw new CommitCraftError(
          ErrorCode.AI_REQUEST_FAILED,
          `Claude API error: ${error.message} (status: ${error.status})`,
        );
      }

      throw new CommitCraftError(
        ErrorCode.AI_REQUEST_FAILED,
        `Unexpected error: ${error instanceof Error ? error.message : String(error)}`,
      );
    }
  }

  estimateTokens(text: string): number {
    return this.tokenCounter.count(text);
  }

  getModelInfo(): ModelInfo {
    return (
      CLAUDE_MODELS[this.config.model] ?? {
        id: this.config.model,
        name: this.config.model,
        provider: AIProviderType.CLAUDE,
        maxInputTokens: 200000,
        maxOutputTokens: 4096,
        costPerInputToken: 0.000003,
        costPerOutputToken: 0.000015,
        supportsStreaming: true,
      }
    );
  }

  async getRateLimitInfo(): Promise<RateLimitInfo | null> {
    return this.rateLimitState;
  }

  async validateApiKey(): Promise<boolean> {
    try {
      await this.client.messages.create({
        model: this.config.model,
        max_tokens: 1,
        messages: [{ role: 'user', content: 'ping' }],
      });
      return true;
    } catch (error) {
      if (error instanceof Anthropic.AuthenticationError) {
        return false;
      }
      return true;
    }
  }

  dispose(): void {
    this.rateLimitState = null;
  }

  private calculateCost(inputTokens: number, outputTokens: number): number {
    const model = this.getModelInfo();
    return (
      inputTokens * model.costPerInputToken + outputTokens * model.costPerOutputToken
    );
  }

  private isRetryableError(error: unknown): boolean {
    if (error instanceof Anthropic.APIError) {
      return error.status === 429 || error.status === 500 || error.status === 503;
    }
    return false;
  }

  private isRateLimitError(error: unknown): boolean {
    if (error instanceof Anthropic.APIError) {
      return error.status === 429;
    }
    return false;
  }

  private updateRateLimitState(error: unknown): void {
    if (error instanceof Anthropic.APIError) {
      const headers = error.headers;
      const retryAfter = headers?.['retry-after'];

      this.rateLimitState = {
        remaining: 0,
        limit: 0,
        resetAt: new Date(Date.now() + (retryAfter ? parseInt(String(retryAfter), 10) * 1000 : 60000)),
        retryAfter: retryAfter ? parseInt(String(retryAfter), 10) : 60,
      };
    }
  }

  private calculateBackoff(attempt: number): number {
    const base = 1000;
    const maxDelay = 30000;
    const delay = Math.min(base * Math.pow(2, attempt), maxDelay);
    const jitter = Math.random() * delay * 0.1;
    return delay + jitter;
  }

  private sleep(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
}

interface ClaudeResponse {
  content: string;
  inputTokens: number;
  outputTokens: number;
  stopReason: string;
}
