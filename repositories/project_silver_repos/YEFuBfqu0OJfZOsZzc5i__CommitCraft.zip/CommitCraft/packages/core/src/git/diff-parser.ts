import {
  DiffFile,
  DiffHunk,
  DiffLineType,
  DiffStats,
  FileChangeType,
  ParsedDiff,
} from '../types/diff';

import { LanguageDetector } from './language-detector';

export class DiffParser {
  private readonly languageDetector: LanguageDetector;

  constructor() {
    this.languageDetector = new LanguageDetector();
  }

  parse(rawDiff: string, maxSize?: number): ParsedDiff {
    const truncated = maxSize !== undefined && rawDiff.length > maxSize;
    const diffContent = truncated ? rawDiff.substring(0, maxSize) : rawDiff;

    const files = this.parseFiles(diffContent);
    const stats = this.calculateTotalStats(files);

    return {
      files,
      stats,
      raw: rawDiff,
      truncated,
    };
  }

  private parseFiles(content: string): DiffFile[] {
    const fileChunks = this.splitIntoFileChunks(content);
    return fileChunks.map((chunk) => this.parseFileChunk(chunk));
  }

  private splitIntoFileChunks(content: string): string[] {
    const chunks: string[] = [];
    const lines = content.split('\n');
    let currentChunk: string[] = [];

    for (const line of lines) {
      if (line.startsWith('diff --git') && currentChunk.length > 0) {
        chunks.push(currentChunk.join('\n'));
        currentChunk = [];
      }
      currentChunk.push(line);
    }

    if (currentChunk.length > 0) {
      chunks.push(currentChunk.join('\n'));
    }

    return chunks;
  }

  private parseFileChunk(chunk: string): DiffFile {
    const lines = chunk.split('\n');
    const header = this.parseFileHeader(lines);
    const hunks = this.parseHunks(lines);
    const stats = this.calculateFileStats(hunks);
    const language = this.languageDetector.detect(header.newPath || header.oldPath);

    return {
      oldPath: header.oldPath,
      newPath: header.newPath,
      changeType: header.changeType,
      hunks,
      stats,
      isBinary: header.isBinary,
      language,
      similarity: header.similarity,
    };
  }

  private parseFileHeader(lines: string[]): FileHeader {
    let oldPath = '';
    let newPath = '';
    let changeType = FileChangeType.MODIFIED;
    let isBinary = false;
    let similarity: number | null = null;

    for (const line of lines) {
      if (line.startsWith('diff --git')) {
        const match = line.match(/^diff --git a\/(.+) b\/(.+)$/);
        if (match) {
          oldPath = match[1];
          newPath = match[2];
        }
      } else if (line.startsWith('new file mode')) {
        changeType = FileChangeType.ADDED;
      } else if (line.startsWith('deleted file mode')) {
        changeType = FileChangeType.DELETED;
      } else if (line.startsWith('rename from')) {
        changeType = FileChangeType.RENAMED;
        oldPath = line.substring(12);
      } else if (line.startsWith('rename to')) {
        newPath = line.substring(10);
      } else if (line.startsWith('copy from')) {
        changeType = FileChangeType.COPIED;
      } else if (line.startsWith('similarity index')) {
        const match = line.match(/similarity index (\d+)%/);
        if (match) {
          similarity = parseInt(match[1], 10);
        }
      } else if (line.startsWith('Binary files')) {
        isBinary = true;
      } else if (line.startsWith('--- ')) {
        const path = line.substring(4);
        if (path !== '/dev/null') {
          oldPath = path.replace(/^a\//, '');
        }
      } else if (line.startsWith('+++ ')) {
        const path = line.substring(4);
        if (path !== '/dev/null') {
          newPath = path.replace(/^b\//, '');
        }
      }
    }

    return { oldPath, newPath, changeType, isBinary, similarity };
  }

  private parseHunks(lines: string[]): DiffHunk[] {
    const hunks: DiffHunk[] = [];
    let currentHunk: DiffHunk | null = null;
    let oldLine = 0;
    let newLine = 0;

    for (const line of lines) {
      const hunkMatch = line.match(/^@@\s+-(\d+)(?:,(\d+))?\s+\+(\d+)(?:,(\d+))?\s+@@(.*)$/);

      if (hunkMatch) {
        if (currentHunk) {
          hunks.push(currentHunk);
        }

        oldLine = parseInt(hunkMatch[1], 10);
        newLine = parseInt(hunkMatch[3], 10);

        currentHunk = {
          oldStart: oldLine,
          oldLines: parseInt(hunkMatch[2] ?? '1', 10),
          newStart: newLine,
          newLines: parseInt(hunkMatch[4] ?? '1', 10),
          header: hunkMatch[5]?.trim() ?? '',
          lines: [],
        };
        continue;
      }

      if (!currentHunk) {
        continue;
      }

      if (line.startsWith('+')) {
        currentHunk.lines.push({
          type: DiffLineType.ADDITION,
          content: line.substring(1),
          oldLineNumber: null,
          newLineNumber: newLine++,
        });
      } else if (line.startsWith('-')) {
        currentHunk.lines.push({
          type: DiffLineType.DELETION,
          content: line.substring(1),
          oldLineNumber: oldLine++,
          newLineNumber: null,
        });
      } else if (line.startsWith(' ')) {
        currentHunk.lines.push({
          type: DiffLineType.CONTEXT,
          content: line.substring(1),
          oldLineNumber: oldLine++,
          newLineNumber: newLine++,
        });
      } else if (line.startsWith('\\ No newline at end of file')) {
        currentHunk.lines.push({
          type: DiffLineType.NO_NEWLINE,
          content: line,
          oldLineNumber: null,
          newLineNumber: null,
        });
      }
    }

    if (currentHunk) {
      hunks.push(currentHunk);
    }

    return hunks;
  }

  private calculateFileStats(hunks: DiffHunk[]): DiffStats {
    let additions = 0;
    let deletions = 0;

    for (const hunk of hunks) {
      for (const line of hunk.lines) {
        if (line.type === DiffLineType.ADDITION) {
          additions++;
        } else if (line.type === DiffLineType.DELETION) {
          deletions++;
        }
      }
    }

    return {
      additions,
      deletions,
      changes: additions + deletions,
      filesChanged: 1,
    };
  }

  private calculateTotalStats(files: DiffFile[]): DiffStats {
    let additions = 0;
    let deletions = 0;

    for (const file of files) {
      additions += file.stats.additions;
      deletions += file.stats.deletions;
    }

    return {
      additions,
      deletions,
      changes: additions + deletions,
      filesChanged: files.length,
    };
  }
}

interface FileHeader {
  oldPath: string;
  newPath: string;
  changeType: FileChangeType;
  isBinary: boolean;
  similarity: number | null;
}
