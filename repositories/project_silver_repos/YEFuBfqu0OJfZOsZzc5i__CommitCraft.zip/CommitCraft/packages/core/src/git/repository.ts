import * as path from 'path';

import simpleGit, { SimpleGit, StatusResult, LogResult, DefaultLogFields } from 'simple-git';

import { CommitCraftError, ErrorCode } from '../utils/errors';

export interface RepositoryInfo {
  root: string;
  branch: string;
  remote: string | null;
  remoteUrl: string | null;
  isDirty: boolean;
  hasStaged: boolean;
  commitCount: number;
}

export interface StagedFileInfo {
  path: string;
  status: StagedFileStatus;
  oldPath: string | null;
}

export enum StagedFileStatus {
  ADDED = 'added',
  MODIFIED = 'modified',
  DELETED = 'deleted',
  RENAMED = 'renamed',
  COPIED = 'copied',
}

export class GitRepository {
  private readonly git: SimpleGit;
  private readonly workDir: string;
  private cachedRoot: string | null = null;

  constructor(workDir: string = process.cwd()) {
    this.workDir = workDir;
    this.git = simpleGit(workDir);
  }

  async getRoot(): Promise<string> {
    if (this.cachedRoot) {
      return this.cachedRoot;
    }

    try {
      const root = await this.git.revparse(['--show-toplevel']);
      this.cachedRoot = root.trim();
      return this.cachedRoot;
    } catch {
      throw new CommitCraftError(
        ErrorCode.GIT_NOT_REPOSITORY,
        `Not a git repository: ${this.workDir}`,
      );
    }
  }

  async getBranch(): Promise<string> {
    try {
      const branch = await this.git.revparse(['--abbrev-ref', 'HEAD']);
      return branch.trim();
    } catch {
      throw new CommitCraftError(ErrorCode.GIT_COMMAND_FAILED, 'Failed to get current branch');
    }
  }

  async getRemote(): Promise<string | null> {
    try {
      const remotes = await this.git.getRemotes(true);
      const origin = remotes.find((r) => r.name === 'origin');
      return origin?.refs?.fetch ?? null;
    } catch {
      return null;
    }
  }

  async getStatus(): Promise<StatusResult> {
    try {
      return await this.git.status();
    } catch {
      throw new CommitCraftError(ErrorCode.GIT_COMMAND_FAILED, 'Failed to get git status');
    }
  }

  async getInfo(): Promise<RepositoryInfo> {
    const root = await this.getRoot();
    const branch = await this.getBranch();
    const remoteUrl = await this.getRemote();
    const status = await this.getStatus();

    let commitCount = 0;
    try {
      const log = await this.git.log();
      commitCount = log.total;
    } catch {
      commitCount = 0;
    }

    return {
      root,
      branch,
      remote: remoteUrl ? 'origin' : null,
      remoteUrl,
      isDirty: status.files.length > 0,
      hasStaged: status.staged.length > 0,
      commitCount,
    };
  }

  async getStagedDiff(options: StagedDiffOptions = {}): Promise<string> {
    const args = ['--staged'];

    if (options.contextLines !== undefined) {
      args.push(`-U${options.contextLines}`);
    }

    if (options.ignoreWhitespace) {
      args.push('-w');
    }

    if (options.followRenames) {
      args.push('-M');
    }

    try {
      return await this.git.diff(args);
    } catch {
      throw new CommitCraftError(ErrorCode.GIT_COMMAND_FAILED, 'Failed to get staged diff');
    }
  }

  async getStagedFiles(): Promise<StagedFileInfo[]> {
    const status = await this.getStatus();
    const files: StagedFileInfo[] = [];

    for (const file of status.staged) {
      const statusCode = status.files.find(
        (f) => f.path === file || f.path.endsWith(file),
      );

      let fileStatus: StagedFileStatus;
      const indexStatus = statusCode?.index ?? 'M';

      switch (indexStatus) {
        case 'A':
          fileStatus = StagedFileStatus.ADDED;
          break;
        case 'D':
          fileStatus = StagedFileStatus.DELETED;
          break;
        case 'R':
          fileStatus = StagedFileStatus.RENAMED;
          break;
        case 'C':
          fileStatus = StagedFileStatus.COPIED;
          break;
        default:
          fileStatus = StagedFileStatus.MODIFIED;
      }

      files.push({
        path: file,
        status: fileStatus,
        oldPath: statusCode?.from ?? null,
      });
    }

    return files;
  }

  async getRecentCommits(count: number = 10): Promise<string[]> {
    try {
      const log: LogResult<DefaultLogFields> = await this.git.log({
        maxCount: count,
      });
      return log.all.map((entry) => entry.message);
    } catch {
      return [];
    }
  }

  async getRepoName(): Promise<string> {
    const root = await this.getRoot();
    return path.basename(root);
  }

  async commit(message: string, options: CommitOptions = {}): Promise<string> {
    const args: string[] = [];

    if (options.signOff) {
      args.push('--signoff');
    }

    if (options.gpgSign) {
      args.push('-S');
    }

    if (options.allowEmpty) {
      args.push('--allow-empty');
    }

    try {
      const result = await this.git.commit(message, args);
      return result.commit;
    } catch (error) {
      throw new CommitCraftError(
        ErrorCode.GIT_COMMIT_FAILED,
        `Failed to create commit: ${error instanceof Error ? error.message : String(error)}`,
      );
    }
  }

  async stageFiles(files: string[]): Promise<void> {
    try {
      await this.git.add(files);
    } catch {
      throw new CommitCraftError(ErrorCode.GIT_COMMAND_FAILED, 'Failed to stage files');
    }
  }

  async unstageFiles(files: string[]): Promise<void> {
    try {
      await this.git.reset(['HEAD', '--', ...files]);
    } catch {
      throw new CommitCraftError(ErrorCode.GIT_COMMAND_FAILED, 'Failed to unstage files');
    }
  }

  async getFileContent(filePath: string, ref: string = 'HEAD'): Promise<string | null> {
    try {
      return await this.git.show([`${ref}:${filePath}`]);
    } catch {
      return null;
    }
  }

  async getBlame(filePath: string): Promise<BlameInfo[]> {
    try {
      const raw = await this.git.raw(['blame', '--porcelain', filePath]);
      return this.parseBlame(raw);
    } catch {
      return [];
    }
  }

  private parseBlame(raw: string): BlameInfo[] {
    const lines = raw.split('\n');
    const results: BlameInfo[] = [];
    let current: Partial<BlameInfo> = {};

    for (const line of lines) {
      if (line.match(/^[0-9a-f]{40}/)) {
        if (current.hash) {
          results.push(current as BlameInfo);
        }
        const parts = line.split(' ');
        current = {
          hash: parts[0],
          originalLine: parseInt(parts[1], 10),
          finalLine: parseInt(parts[2], 10),
        };
      } else if (line.startsWith('author ')) {
        current.author = line.substring(7);
      } else if (line.startsWith('author-time ')) {
        current.timestamp = new Date(parseInt(line.substring(12), 10) * 1000);
      } else if (line.startsWith('summary ')) {
        current.summary = line.substring(8);
      }
    }

    if (current.hash) {
      results.push(current as BlameInfo);
    }

    return results;
  }

  getSimpleGit(): SimpleGit {
    return this.git;
  }
}

export interface StagedDiffOptions {
  contextLines?: number;
  ignoreWhitespace?: boolean;
  followRenames?: boolean;
}

export interface CommitOptions {
  signOff?: boolean;
  gpgSign?: boolean;
  allowEmpty?: boolean;
}

export interface BlameInfo {
  hash: string;
  author: string;
  timestamp: Date;
  summary: string;
  originalLine: number;
  finalLine: number;
}
