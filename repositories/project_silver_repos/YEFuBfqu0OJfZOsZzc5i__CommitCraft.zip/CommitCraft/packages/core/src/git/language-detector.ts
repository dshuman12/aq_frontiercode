import * as path from 'path';

export class LanguageDetector {
  private readonly extensionMap: Map<string, string>;
  private readonly filenameMap: Map<string, string>;

  constructor() {
    this.extensionMap = new Map([
      ['.ts', 'TypeScript'],
      ['.tsx', 'TypeScript'],
      ['.js', 'JavaScript'],
      ['.jsx', 'JavaScript'],
      ['.mjs', 'JavaScript'],
      ['.cjs', 'JavaScript'],
      ['.py', 'Python'],
      ['.rb', 'Ruby'],
      ['.rs', 'Rust'],
      ['.go', 'Go'],
      ['.java', 'Java'],
      ['.kt', 'Kotlin'],
      ['.kts', 'Kotlin'],
      ['.scala', 'Scala'],
      ['.cs', 'C#'],
      ['.fs', 'F#'],
      ['.c', 'C'],
      ['.h', 'C'],
      ['.cpp', 'C++'],
      ['.hpp', 'C++'],
      ['.cc', 'C++'],
      ['.cxx', 'C++'],
      ['.swift', 'Swift'],
      ['.m', 'Objective-C'],
      ['.mm', 'Objective-C++'],
      ['.php', 'PHP'],
      ['.pl', 'Perl'],
      ['.pm', 'Perl'],
      ['.r', 'R'],
      ['.R', 'R'],
      ['.lua', 'Lua'],
      ['.sh', 'Shell'],
      ['.bash', 'Shell'],
      ['.zsh', 'Shell'],
      ['.fish', 'Shell'],
      ['.ps1', 'PowerShell'],
      ['.psm1', 'PowerShell'],
      ['.html', 'HTML'],
      ['.htm', 'HTML'],
      ['.css', 'CSS'],
      ['.scss', 'SCSS'],
      ['.sass', 'Sass'],
      ['.less', 'Less'],
      ['.vue', 'Vue'],
      ['.svelte', 'Svelte'],
      ['.json', 'JSON'],
      ['.yaml', 'YAML'],
      ['.yml', 'YAML'],
      ['.toml', 'TOML'],
      ['.xml', 'XML'],
      ['.md', 'Markdown'],
      ['.mdx', 'MDX'],
      ['.rst', 'reStructuredText'],
      ['.sql', 'SQL'],
      ['.graphql', 'GraphQL'],
      ['.gql', 'GraphQL'],
      ['.proto', 'Protocol Buffers'],
      ['.tf', 'Terraform'],
      ['.hcl', 'HCL'],
      ['.dart', 'Dart'],
      ['.ex', 'Elixir'],
      ['.exs', 'Elixir'],
      ['.erl', 'Erlang'],
      ['.hrl', 'Erlang'],
      ['.hs', 'Haskell'],
      ['.ml', 'OCaml'],
      ['.mli', 'OCaml'],
      ['.clj', 'Clojure'],
      ['.cljs', 'ClojureScript'],
      ['.elm', 'Elm'],
      ['.nim', 'Nim'],
      ['.zig', 'Zig'],
      ['.wasm', 'WebAssembly'],
      ['.sol', 'Solidity'],
    ]);

    this.filenameMap = new Map([
      ['Dockerfile', 'Docker'],
      ['Makefile', 'Makefile'],
      ['CMakeLists.txt', 'CMake'],
      ['Jenkinsfile', 'Groovy'],
      ['Vagrantfile', 'Ruby'],
      ['Gemfile', 'Ruby'],
      ['Rakefile', 'Ruby'],
      ['Cargo.toml', 'Rust'],
      ['go.mod', 'Go'],
      ['go.sum', 'Go'],
      ['pom.xml', 'Java'],
      ['build.gradle', 'Gradle'],
      ['build.gradle.kts', 'Gradle'],
      ['.gitignore', 'Git'],
      ['.gitattributes', 'Git'],
      ['.editorconfig', 'EditorConfig'],
      ['.prettierrc', 'Prettier'],
      ['.eslintrc', 'ESLint'],
      ['.babelrc', 'Babel'],
    ]);
  }

  detect(filePath: string): string | null {
    const basename = path.basename(filePath);

    const filenameMatch = this.filenameMap.get(basename);
    if (filenameMatch) {
      return filenameMatch;
    }

    const ext = path.extname(filePath).toLowerCase();
    return this.extensionMap.get(ext) ?? null;
  }

  isSourceCode(filePath: string): boolean {
    const language = this.detect(filePath);
    if (!language) {
      return false;
    }

    const nonSourceLanguages = new Set([
      'JSON',
      'YAML',
      'TOML',
      'XML',
      'Markdown',
      'MDX',
      'reStructuredText',
      'Git',
      'EditorConfig',
      'Prettier',
      'ESLint',
      'Babel',
    ]);

    return !nonSourceLanguages.has(language);
  }

  isTestFile(filePath: string): boolean {
    const basename = path.basename(filePath);
    const testPatterns = [
      /\.test\./,
      /\.spec\./,
      /_test\./,
      /test_/,
      /\.tests\./,
      /\.specs\./,
      /__tests__/,
      /__test__/,
    ];

    return testPatterns.some((pattern) => pattern.test(basename) || pattern.test(filePath));
  }

  isConfigFile(filePath: string): boolean {
    const basename = path.basename(filePath);
    const ext = path.extname(filePath).toLowerCase();

    const configExtensions = new Set(['.json', '.yaml', '.yml', '.toml', '.xml', '.ini', '.cfg']);
    const configPrefixes = ['.', 'config', 'settings'];
    const configFilenames = new Set([
      'Makefile',
      'Dockerfile',
      'docker-compose.yml',
      'docker-compose.yaml',
      'Procfile',
      'Vagrantfile',
    ]);

    if (configFilenames.has(basename)) {
      return true;
    }

    if (configExtensions.has(ext) && configPrefixes.some((p) => basename.startsWith(p))) {
      return true;
    }

    return false;
  }

  isDocumentation(filePath: string): boolean {
    const ext = path.extname(filePath).toLowerCase();
    const docExtensions = new Set(['.md', '.mdx', '.rst', '.txt', '.adoc']);

    if (docExtensions.has(ext)) {
      return true;
    }

    const lowerPath = filePath.toLowerCase();
    return lowerPath.includes('docs/') || lowerPath.includes('documentation/');
  }
}
