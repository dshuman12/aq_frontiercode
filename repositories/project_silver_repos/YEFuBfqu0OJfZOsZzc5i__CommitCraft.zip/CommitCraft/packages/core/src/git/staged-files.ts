import { FileCategory, FileChange, FileChangeType } from '../types/diff';

import { LanguageDetector } from './language-detector';
import { GitRepository, StagedFileInfo, StagedFileStatus } from './repository';

export class StagedFilesAnalyzer {
  private readonly repo: GitRepository;
  private readonly languageDetector: LanguageDetector;

  constructor(repo: GitRepository) {
    this.repo = repo;
    this.languageDetector = new LanguageDetector();
  }

  async analyze(): Promise<StagedFilesReport> {
    const stagedFiles = await this.repo.getStagedFiles();
    const diff = await this.repo.getStagedDiff();
    const changes = this.buildFileChanges(stagedFiles, diff);
    const categories = this.categorizeChanges(changes);
    const summary = this.buildSummary(changes, categories);

    return {
      files: changes,
      categories,
      summary,
      totalFiles: changes.length,
      totalAdditions: changes.reduce((sum, c) => sum + c.additions, 0),
      totalDeletions: changes.reduce((sum, c) => sum + c.deletions, 0),
    };
  }

  private buildFileChanges(stagedFiles: StagedFileInfo[], diff: string): FileChange[] {
    const diffStats = this.parseDiffStats(diff);

    return stagedFiles.map((file) => {
      const stats = diffStats.get(file.path) ?? { additions: 0, deletions: 0 };
      const language = this.languageDetector.detect(file.path);
      const category = this.categorizeFile(file.path);

      return {
        path: file.path,
        changeType: this.mapStatus(file.status),
        additions: stats.additions,
        deletions: stats.deletions,
        language,
        category,
      };
    });
  }

  private parseDiffStats(diff: string): Map<string, { additions: number; deletions: number }> {
    const stats = new Map<string, { additions: number; deletions: number }>();
    const lines = diff.split('\n');
    let currentFile = '';
    let additions = 0;
    let deletions = 0;

    for (const line of lines) {
      const fileMatch = line.match(/^diff --git a\/(.+) b\/(.+)$/);
      if (fileMatch) {
        if (currentFile) {
          stats.set(currentFile, { additions, deletions });
        }
        currentFile = fileMatch[2];
        additions = 0;
        deletions = 0;
        continue;
      }

      if (line.startsWith('+') && !line.startsWith('+++')) {
        additions++;
      } else if (line.startsWith('-') && !line.startsWith('---')) {
        deletions++;
      }
    }

    if (currentFile) {
      stats.set(currentFile, { additions, deletions });
    }

    return stats;
  }

  private mapStatus(status: StagedFileStatus): FileChangeType {
    switch (status) {
      case StagedFileStatus.ADDED:
        return FileChangeType.ADDED;
      case StagedFileStatus.DELETED:
        return FileChangeType.DELETED;
      case StagedFileStatus.RENAMED:
        return FileChangeType.RENAMED;
      case StagedFileStatus.COPIED:
        return FileChangeType.COPIED;
      default:
        return FileChangeType.MODIFIED;
    }
  }

  private categorizeFile(filePath: string): FileCategory {
    if (this.languageDetector.isTestFile(filePath)) {
      return FileCategory.TEST;
    }

    if (this.languageDetector.isDocumentation(filePath)) {
      return FileCategory.DOCUMENTATION;
    }

    if (this.languageDetector.isConfigFile(filePath)) {
      return FileCategory.CONFIG;
    }

    const lowerPath = filePath.toLowerCase();

    if (lowerPath.includes('.github/') || lowerPath.includes('.gitlab-ci') ||
        lowerPath.includes('jenkinsfile') || lowerPath.includes('.circleci/')) {
      return FileCategory.CI;
    }

    if (lowerPath.includes('migration') || lowerPath.includes('migrate')) {
      return FileCategory.MIGRATION;
    }

    if (lowerPath.endsWith('.lock') || lowerPath.includes('package-lock') ||
        lowerPath.includes('yarn.lock') || lowerPath.includes('pnpm-lock')) {
      return FileCategory.DEPENDENCY;
    }

    if (lowerPath.includes('webpack') || lowerPath.includes('rollup') ||
        lowerPath.includes('vite.config') || lowerPath.includes('tsconfig') ||
        lowerPath.includes('babel') || lowerPath.includes('makefile') ||
        lowerPath.includes('dockerfile') || lowerPath.includes('cmake')) {
      return FileCategory.BUILD;
    }

    const ext = filePath.split('.').pop()?.toLowerCase();
    if (ext && ['png', 'jpg', 'jpeg', 'gif', 'svg', 'ico', 'webp', 'mp4', 'webm',
                'woff', 'woff2', 'ttf', 'eot', 'otf'].includes(ext)) {
      return FileCategory.ASSET;
    }

    if (ext && ['css', 'scss', 'sass', 'less', 'styl'].includes(ext)) {
      return FileCategory.STYLE;
    }

    if (this.languageDetector.isSourceCode(filePath)) {
      return FileCategory.SOURCE;
    }

    return FileCategory.OTHER;
  }

  private categorizeChanges(changes: FileChange[]): Map<FileCategory, FileChange[]> {
    const categories = new Map<FileCategory, FileChange[]>();

    for (const change of changes) {
      const existing = categories.get(change.category) ?? [];
      existing.push(change);
      categories.set(change.category, existing);
    }

    return categories;
  }

  private buildSummary(
    changes: FileChange[],
    categories: Map<FileCategory, FileChange[]>,
  ): StagedFilesSummary {
    const languageCounts = new Map<string, number>();
    for (const change of changes) {
      if (change.language) {
        languageCounts.set(change.language, (languageCounts.get(change.language) ?? 0) + 1);
      }
    }

    const primaryLanguage = [...languageCounts.entries()]
      .sort((a, b) => b[1] - a[1])[0]?.[0] ?? null;

    const categoryBreakdown: Record<string, number> = {};
    for (const [category, files] of categories) {
      categoryBreakdown[category] = files.length;
    }

    return {
      primaryLanguage,
      languageCounts: Object.fromEntries(languageCounts),
      categoryBreakdown,
      hasSourceChanges: categories.has(FileCategory.SOURCE),
      hasTestChanges: categories.has(FileCategory.TEST),
      hasConfigChanges: categories.has(FileCategory.CONFIG),
      hasDocChanges: categories.has(FileCategory.DOCUMENTATION),
      hasBuildChanges: categories.has(FileCategory.BUILD),
    };
  }
}

export interface StagedFilesReport {
  files: FileChange[];
  categories: Map<FileCategory, FileChange[]>;
  summary: StagedFilesSummary;
  totalFiles: number;
  totalAdditions: number;
  totalDeletions: number;
}

export interface StagedFilesSummary {
  primaryLanguage: string | null;
  languageCounts: Record<string, number>;
  categoryBreakdown: Record<string, number>;
  hasSourceChanges: boolean;
  hasTestChanges: boolean;
  hasConfigChanges: boolean;
  hasDocChanges: boolean;
  hasBuildChanges: boolean;
}
