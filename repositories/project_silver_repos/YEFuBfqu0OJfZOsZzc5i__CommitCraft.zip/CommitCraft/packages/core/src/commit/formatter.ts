import { CommitFormat, CommitMessage, COMMIT_TYPE_CONFIGS } from '../types/commit';

export class CommitFormatter {
  private readonly format: CommitFormat;

  constructor(format: CommitFormat = CommitFormat.CONVENTIONAL) {
    this.format = format;
  }

  formatMessage(message: CommitMessage, options: FormatterOptions = {}): string {
    switch (this.format) {
      case CommitFormat.ANGULAR:
        return this.formatAngular(message, options);
      case CommitFormat.KARMA:
        return this.formatKarma(message, options);
      case CommitFormat.CUSTOM:
        return this.formatCustom(message, options);
      case CommitFormat.CONVENTIONAL:
      default:
        return this.formatConventional(message, options);
    }
  }

  private formatConventional(message: CommitMessage, options: FormatterOptions): string {
    return this.buildMessage(message, options);
  }

  private formatAngular(message: CommitMessage, options: FormatterOptions): string {
    return this.buildMessage(message, options);
  }

  private formatKarma(message: CommitMessage, options: FormatterOptions): string {
    return this.buildMessage(message, options);
  }

  private formatCustom(message: CommitMessage, options: FormatterOptions): string {
    if (!options.template) {
      return this.buildMessage(message, options);
    }

    return this.applyTemplate(options.template, message, options);
  }

  private buildMessage(message: CommitMessage, options: FormatterOptions): string {
    const parts: string[] = [];

    const subject = this.buildSubject(message, options);
    parts.push(subject);

    if (message.body) {
      parts.push('');
      const wrappedBody = this.wrapLines(message.body, options.maxBodyLineLength ?? 100);
      parts.push(wrappedBody);
    }

    const footer = this.buildFooter(message);
    if (footer) {
      parts.push('');
      parts.push(footer);
    }

    return parts.join('\n');
  }

  private buildSubject(message: CommitMessage, options: FormatterOptions): string {
    let subject = '';

    if (options.emoji) {
      const config = COMMIT_TYPE_CONFIGS[message.type];
      subject += `${config.emoji} `;
    }

    subject += message.type;

    if (message.scope) {
      subject += `(${message.scope})`;
    }

    if (message.breaking) {
      subject += '!';
    }

    subject += ': ';
    subject += message.subject;

    const maxLength = options.maxSubjectLength ?? 72;
    if (subject.length > maxLength) {
      subject = subject.substring(0, maxLength - 3) + '...';
    }

    return subject;
  }

  private buildFooter(message: CommitMessage): string | null {
    const parts: string[] = [];

    if (message.breaking) {
      parts.push(`BREAKING CHANGE: ${message.footer ?? message.subject}`);
    } else if (message.footer) {
      parts.push(message.footer);
    }

    if (message.issues.length > 0) {
      parts.push(`Refs: ${message.issues.join(', ')}`);
    }

    return parts.length > 0 ? parts.join('\n') : null;
  }

  private wrapLines(text: string, maxWidth: number): string {
    return text
      .split('\n')
      .map((line) => this.wrapLine(line, maxWidth))
      .join('\n');
  }

  private wrapLine(line: string, maxWidth: number): string {
    if (line.length <= maxWidth) return line;

    const words = line.split(' ');
    const lines: string[] = [];
    let current = '';

    for (const word of words) {
      if (current.length + word.length + 1 > maxWidth && current.length > 0) {
        lines.push(current);
        current = word;
      } else {
        current = current ? `${current} ${word}` : word;
      }
    }

    if (current) lines.push(current);
    return lines.join('\n');
  }

  private applyTemplate(
    template: string,
    message: CommitMessage,
    options: FormatterOptions,
  ): string {
    const variables: Record<string, string> = {
      type: message.type,
      scope: message.scope ? `(${message.scope})` : '',
      subject: message.subject,
      body: message.body ?? '',
      footer: message.footer ?? '',
      breaking: message.breaking ? '!' : '',
      issues: message.issues.join(', '),
      emoji: options.emoji ? COMMIT_TYPE_CONFIGS[message.type].emoji : '',
    };

    let result = template;
    for (const [key, value] of Object.entries(variables)) {
      result = result.replace(new RegExp(`\\{\\{${key}\\}\\}`, 'g'), value);
    }

    return result;
  }
}

export interface FormatterOptions {
  maxSubjectLength?: number;
  maxBodyLineLength?: number;
  emoji?: boolean;
  template?: string;
  signOff?: string;
}
