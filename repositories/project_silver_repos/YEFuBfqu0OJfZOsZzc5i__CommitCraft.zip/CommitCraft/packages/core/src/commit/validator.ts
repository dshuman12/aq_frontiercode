import { CommitMessage, CommitType } from '../types/commit';

export interface CommitValidationRule {
  name: string;
  severity: 'error' | 'warning' | 'info';
  validate(message: CommitMessage): CommitRuleResult;
}

export interface CommitRuleResult {
  passed: boolean;
  message: string;
}

export interface CommitValidationReport {
  valid: boolean;
  score: number;
  results: Array<{
    rule: string;
    severity: 'error' | 'warning' | 'info';
    passed: boolean;
    message: string;
  }>;
}

export class CommitValidator {
  private readonly rules: CommitValidationRule[] = [];

  constructor(options: CommitValidatorOptions = {}) {
    this.registerDefaultRules(options);
  }

  addRule(rule: CommitValidationRule): void {
    this.rules.push(rule);
  }

  validate(message: CommitMessage): CommitValidationReport {
    const results = this.rules.map((rule) => {
      const result = rule.validate(message);
      return {
        rule: rule.name,
        severity: rule.severity,
        passed: result.passed,
        message: result.message,
      };
    });

    const errors = results.filter((r) => r.severity === 'error' && !r.passed);
    const warnings = results.filter((r) => r.severity === 'warning' && !r.passed);
    const total = results.length;
    const passed = results.filter((r) => r.passed).length;

    const score = total > 0 ? Math.round((passed / total) * 100) : 100;

    return {
      valid: errors.length === 0,
      score: warnings.length > 0 ? Math.max(score - warnings.length * 5, 0) : score,
      results,
    };
  }

  private registerDefaultRules(options: CommitValidatorOptions): void {
    this.addRule({
      name: 'type-required',
      severity: 'error',
      validate: (message: CommitMessage): CommitRuleResult => ({
        passed: Object.values(CommitType).includes(message.type),
        message: `Commit type "${message.type}" is ${Object.values(CommitType).includes(message.type) ? 'valid' : 'invalid'}`,
      }),
    });

    this.addRule({
      name: 'subject-required',
      severity: 'error',
      validate: (message: CommitMessage): CommitRuleResult => ({
        passed: message.subject.length > 0,
        message: message.subject.length > 0 ? 'Subject is present' : 'Subject is required',
      }),
    });

    this.addRule({
      name: 'subject-max-length',
      severity: 'error',
      validate: (message: CommitMessage): CommitRuleResult => {
        const maxLength = options.maxSubjectLength ?? 72;
        const length = message.subject.length;
        return {
          passed: length <= maxLength,
          message: length <= maxLength
            ? `Subject length (${length}) within limit (${maxLength})`
            : `Subject too long: ${length} > ${maxLength}`,
        };
      },
    });

    this.addRule({
      name: 'subject-min-length',
      severity: 'warning',
      validate: (message: CommitMessage): CommitRuleResult => ({
        passed: message.subject.length >= 10,
        message: message.subject.length >= 10
          ? 'Subject has sufficient detail'
          : 'Subject may be too short to be descriptive',
      }),
    });

    this.addRule({
      name: 'subject-no-period',
      severity: 'warning',
      validate: (message: CommitMessage): CommitRuleResult => ({
        passed: !message.subject.endsWith('.'),
        message: message.subject.endsWith('.')
          ? 'Subject should not end with a period'
          : 'Subject does not end with a period',
      }),
    });

    this.addRule({
      name: 'subject-capitalized',
      severity: 'info',
      validate: (message: CommitMessage): CommitRuleResult => ({
        passed: message.subject.length === 0 || /^[A-Z]/.test(message.subject),
        message: /^[A-Z]/.test(message.subject)
          ? 'Subject is capitalized'
          : 'Subject should start with a capital letter',
      }),
    });

    this.addRule({
      name: 'subject-imperative',
      severity: 'info',
      validate: (message: CommitMessage): CommitRuleResult => {
        const pastTenseWords = ['added', 'fixed', 'removed', 'updated', 'changed', 'moved', 'created'];
        const firstWord = message.subject.split(' ')[0]?.toLowerCase() ?? '';
        const isPastTense = pastTenseWords.includes(firstWord);
        return {
          passed: !isPastTense,
          message: isPastTense
            ? `Subject should use imperative mood: "${firstWord}" → "${this.toImperative(firstWord)}"`
            : 'Subject uses imperative mood',
        };
      },
    });

    this.addRule({
      name: 'body-line-length',
      severity: 'warning',
      validate: (message: CommitMessage): CommitRuleResult => {
        if (!message.body) return { passed: true, message: 'No body to validate' };
        const maxLength = options.maxBodyLineLength ?? 100;
        const lines = message.body.split('\n');
        const longLines = lines.filter((line) => line.length > maxLength);
        return {
          passed: longLines.length === 0,
          message: longLines.length === 0
            ? 'Body lines within length limit'
            : `${longLines.length} body line(s) exceed ${maxLength} characters`,
        };
      },
    });

    this.addRule({
      name: 'scope-valid',
      severity: 'warning',
      validate: (message: CommitMessage): CommitRuleResult => {
        if (!message.scope) return { passed: true, message: 'No scope to validate' };
        const valid = /^[a-z][a-z0-9-_]*$/.test(message.scope);
        return {
          passed: valid,
          message: valid
            ? 'Scope format is valid'
            : 'Scope should be lowercase alphanumeric with hyphens/underscores',
        };
      },
    });

    if (options.requireScope) {
      this.addRule({
        name: 'scope-required',
        severity: 'error',
        validate: (message: CommitMessage): CommitRuleResult => ({
          passed: message.scope !== null && message.scope.length > 0,
          message: message.scope ? 'Scope is present' : 'Scope is required',
        }),
      });
    }

    if (options.allowedTypes && options.allowedTypes.length > 0) {
      const allowed = options.allowedTypes;
      this.addRule({
        name: 'type-allowed',
        severity: 'error',
        validate: (message: CommitMessage): CommitRuleResult => ({
          passed: allowed.includes(message.type),
          message: allowed.includes(message.type)
            ? `Type "${message.type}" is allowed`
            : `Type "${message.type}" not in allowed list: ${allowed.join(', ')}`,
        }),
      });
    }
  }

  private toImperative(word: string): string {
    const mapping: Record<string, string> = {
      added: 'add',
      fixed: 'fix',
      removed: 'remove',
      updated: 'update',
      changed: 'change',
      moved: 'move',
      created: 'create',
    };
    return mapping[word] ?? word;
  }
}

export interface CommitValidatorOptions {
  maxSubjectLength?: number;
  maxBodyLineLength?: number;
  requireScope?: boolean;
  allowedTypes?: CommitType[];
}
