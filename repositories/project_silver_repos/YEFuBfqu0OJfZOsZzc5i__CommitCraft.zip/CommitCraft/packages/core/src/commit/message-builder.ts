import { CommitMessage, CommitMessageOptions, CommitType } from '../types/commit';
import { ParsedDiff } from '../types/diff';
import {
  AIProvider,
  AIRequestOptions,
  AIResponse,
  PromptContext,
} from '../types/provider';

import { ConventionalCommitFormatter, FormatOptions } from './conventional';

export class MessageBuilder {
  private readonly formatter: ConventionalCommitFormatter;

  constructor() {
    this.formatter = new ConventionalCommitFormatter();
  }

  async generate(
    provider: AIProvider,
    diff: ParsedDiff,
    options: CommitMessageOptions,
    context: PromptContext,
  ): Promise<GenerationResult> {
    const requestOptions: AIRequestOptions = {
      diff,
      commitOptions: options,
      context,
    };

    const response = await provider.generateCommitMessage(requestOptions);

    const message = this.applyOptions(response.message, options);
    const formatted = this.formatter.format(message, {
      maxSubjectLength: options.maxSubjectLength,
      emoji: options.emoji,
    });

    const validation = this.formatter.validate(message, {
      maxSubjectLength: options.maxSubjectLength,
    });

    return {
      message,
      formatted,
      alternatives: response.alternatives.map((alt) => ({
        message: this.applyOptions(alt, options),
        formatted: this.formatter.format(this.applyOptions(alt, options), {
          maxSubjectLength: options.maxSubjectLength,
          emoji: options.emoji,
        }),
      })),
      usage: response.usage,
      latency: response.latency,
      validation,
      model: response.model,
    };
  }

  private applyOptions(message: CommitMessage, options: CommitMessageOptions): CommitMessage {
    const result = { ...message };

    if (options.type) {
      result.type = options.type;
    }

    if (options.scope) {
      result.scope = options.scope;
    }

    if (!options.includeBody) {
      result.body = null;
    }

    if (!options.includeFooter) {
      result.footer = null;
    }

    if (!options.includeBreakingChanges) {
      result.breaking = false;
    }

    if (!options.includeIssueReferences) {
      result.issues = [];
    }

    return result;
  }

  format(message: CommitMessage, options: FormatOptions = {}): string {
    return this.formatter.format(message, options);
  }

  parse(commitString: string): CommitMessage | null {
    return this.formatter.parse(commitString);
  }

  createEmpty(type: CommitType = CommitType.CHORE): CommitMessage {
    return {
      type,
      scope: null,
      subject: '',
      body: null,
      footer: null,
      breaking: false,
      issues: [],
    };
  }

  merge(base: CommitMessage, override: Partial<CommitMessage>): CommitMessage {
    return {
      type: override.type ?? base.type,
      scope: override.scope !== undefined ? override.scope : base.scope,
      subject: override.subject ?? base.subject,
      body: override.body !== undefined ? override.body : base.body,
      footer: override.footer !== undefined ? override.footer : base.footer,
      breaking: override.breaking ?? base.breaking,
      issues: override.issues ?? base.issues,
    };
  }

  validate(message: CommitMessage, maxSubjectLength: number = 72): MessageValidation {
    return this.formatter.validate(message, { maxSubjectLength });
  }

  buildFromResponse(response: AIResponse, options: CommitMessageOptions): GenerationResult {
    const message = this.applyOptions(response.message, options);
    const formatted = this.formatter.format(message, {
      maxSubjectLength: options.maxSubjectLength,
      emoji: options.emoji,
    });

    const validation = this.formatter.validate(message, {
      maxSubjectLength: options.maxSubjectLength,
    });

    return {
      message,
      formatted,
      alternatives: response.alternatives.map((alt) => {
        const applied = this.applyOptions(alt, options);
        return {
          message: applied,
          formatted: this.formatter.format(applied, {
            maxSubjectLength: options.maxSubjectLength,
            emoji: options.emoji,
          }),
        };
      }),
      usage: response.usage,
      latency: response.latency,
      validation,
      model: response.model,
    };
  }
}

export interface GenerationResult {
  message: CommitMessage;
  formatted: string;
  alternatives: Array<{
    message: CommitMessage;
    formatted: string;
  }>;
  usage: {
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
    estimatedCost: number;
  };
  latency: number;
  validation: MessageValidation;
  model: string;
}

export interface MessageValidation {
  valid: boolean;
  errors: string[];
  warnings: string[];
}
