import { CommitFormat, CommitMessage, CommitType, COMMIT_TYPE_CONFIGS } from '../types/commit';

export class ConventionalCommitFormatter {
  format(message: CommitMessage, options: FormatOptions = {}): string {
    const parts: string[] = [];

    const subject = this.formatSubject(message, options);
    parts.push(subject);

    if (message.body) {
      parts.push('');
      parts.push(this.wrapText(message.body, options.maxBodyLineLength ?? 100));
    }

    const footer = this.formatFooter(message);
    if (footer) {
      parts.push('');
      parts.push(footer);
    }

    return parts.join('\n');
  }

  formatSubject(message: CommitMessage, options: FormatOptions = {}): string {
    const maxLength = options.maxSubjectLength ?? 72;
    const useEmoji = options.emoji ?? false;

    let subject = '';

    if (useEmoji) {
      const config = COMMIT_TYPE_CONFIGS[message.type];
      subject += `${config.emoji} `;
    }

    subject += message.type;

    if (message.scope) {
      subject += `(${message.scope})`;
    }

    if (message.breaking) {
      subject += '!';
    }

    subject += ': ';
    subject += message.subject;

    if (subject.length > maxLength) {
      subject = subject.substring(0, maxLength - 3) + '...';
    }

    return subject;
  }

  private formatFooter(message: CommitMessage): string | null {
    const parts: string[] = [];

    if (message.breaking) {
      const breakingDesc = message.footer ?? message.subject;
      parts.push(`BREAKING CHANGE: ${breakingDesc}`);
    } else if (message.footer) {
      parts.push(message.footer);
    }

    if (message.issues.length > 0) {
      const issueRefs = message.issues.map((issue) => {
        if (issue.startsWith('#')) return issue;
        if (issue.match(/^\d+$/)) return `#${issue}`;
        return issue;
      });

      parts.push(`Refs: ${issueRefs.join(', ')}`);
    }

    return parts.length > 0 ? parts.join('\n') : null;
  }

  private wrapText(text: string, maxWidth: number): string {
    const lines = text.split('\n');
    const wrapped: string[] = [];

    for (const line of lines) {
      if (line.length <= maxWidth) {
        wrapped.push(line);
        continue;
      }

      const words = line.split(' ');
      let currentLine = '';

      for (const word of words) {
        if (currentLine.length + word.length + 1 > maxWidth && currentLine.length > 0) {
          wrapped.push(currentLine);
          currentLine = word;
        } else {
          currentLine = currentLine ? `${currentLine} ${word}` : word;
        }
      }

      if (currentLine) {
        wrapped.push(currentLine);
      }
    }

    return wrapped.join('\n');
  }

  parse(commitString: string): CommitMessage | null {
    const lines = commitString.split('\n');
    const subjectLine = lines[0];

    if (!subjectLine) return null;

    const match = subjectLine.match(
      /^(?:[\p{Emoji_Presentation}\p{Extended_Pictographic}]\s+)?(\w+)(?:\(([^)]+)\))?(!)?\s*:\s*(.+)$/u,
    );

    if (!match) return null;

    const [, typeStr, scope, breaking, subject] = match;
    const type = this.parseType(typeStr);

    let body: string | null = null;
    let footer: string | null = null;
    const issues: string[] = [];
    let isBreaking = breaking === '!';

    const remaining = lines.slice(1);
    let bodyStarted = false;
    let footerStarted = false;
    const bodyLines: string[] = [];
    const footerLines: string[] = [];

    for (const line of remaining) {
      if (!bodyStarted && line === '') {
        bodyStarted = true;
        continue;
      }

      if (bodyStarted && !footerStarted) {
        if (line.startsWith('BREAKING CHANGE:') || line.startsWith('Refs:') || line.match(/^[\w-]+:\s/)) {
          footerStarted = true;
        }
      }

      if (footerStarted) {
        footerLines.push(line);

        if (line.startsWith('BREAKING CHANGE:')) {
          isBreaking = true;
        }

        const issueMatch = line.match(/#(\d+)/g);
        if (issueMatch) {
          issues.push(...issueMatch);
        }
      } else if (bodyStarted) {
        bodyLines.push(line);
      }
    }

    if (bodyLines.length > 0) {
      body = bodyLines.join('\n').trim() || null;
    }

    if (footerLines.length > 0) {
      footer = footerLines.join('\n').trim() || null;
    }

    return {
      type,
      scope: scope ?? null,
      subject: subject.trim(),
      body,
      footer,
      breaking: isBreaking,
      issues,
    };
  }

  private parseType(typeStr: string): CommitType {
    const lower = typeStr.toLowerCase();
    const mapping: Record<string, CommitType> = {};

    for (const type of Object.values(CommitType)) {
      mapping[type] = type;
    }

    return mapping[lower] ?? CommitType.CHORE;
  }

  validate(message: CommitMessage, options: ValidationOptions = {}): ValidationResult {
    const errors: string[] = [];
    const warnings: string[] = [];

    if (!Object.values(CommitType).includes(message.type)) {
      errors.push(`Invalid commit type: ${message.type}`);
    }

    if (!message.subject) {
      errors.push('Subject is required');
    }

    const maxSubject = options.maxSubjectLength ?? 72;
    const formatted = this.formatSubject(message);
    if (formatted.length > maxSubject) {
      errors.push(
        `Subject line too long: ${formatted.length} characters (max ${maxSubject})`,
      );
    }

    if (message.subject && message.subject.endsWith('.')) {
      warnings.push('Subject should not end with a period');
    }

    if (message.subject && /^[a-z]/.test(message.subject)) {
      warnings.push('Subject should start with a capital letter');
    }

    if (message.body) {
      const maxBody = options.maxBodyLineLength ?? 100;
      const bodyLines = message.body.split('\n');
      const longLines = bodyLines.filter((line) => line.length > maxBody);
      if (longLines.length > 0) {
        warnings.push(`${longLines.length} body line(s) exceed ${maxBody} characters`);
      }
    }

    if (options.requiredScope && !message.scope) {
      errors.push('Scope is required');
    }

    if (options.allowedTypes && !options.allowedTypes.includes(message.type)) {
      errors.push(
        `Type "${message.type}" is not allowed. Allowed: ${options.allowedTypes.join(', ')}`,
      );
    }

    return {
      valid: errors.length === 0,
      errors,
      warnings,
    };
  }

  isConventional(commitString: string): boolean {
    return this.parse(commitString) !== null;
  }

  getTypeFromFormat(format: CommitFormat, typeStr: string): CommitType {
    switch (format) {
      case CommitFormat.ANGULAR:
      case CommitFormat.KARMA:
      case CommitFormat.CONVENTIONAL:
      default:
        return this.parseType(typeStr);
    }
  }
}

export interface FormatOptions {
  maxSubjectLength?: number;
  maxBodyLineLength?: number;
  emoji?: boolean;
}

export interface ValidationOptions {
  maxSubjectLength?: number;
  maxBodyLineLength?: number;
  requiredScope?: boolean;
  allowedTypes?: CommitType[];
}

export interface ValidationResult {
  valid: boolean;
  errors: string[];
  warnings: string[];
}
