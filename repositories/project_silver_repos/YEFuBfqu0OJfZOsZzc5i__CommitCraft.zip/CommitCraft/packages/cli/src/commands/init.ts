import * as fs from 'fs';
import * as path from 'path';

import { Command } from 'commander';

import { CommitFormat, CommitType, DEFAULT_CONFIG } from '@commitcraft/core';

import { PromptUI } from '../ui/prompt';
import { Theme } from '../ui/theme';
import { Spinner } from '../ui/spinner';

export function registerInitCommand(program: Command): void {
  program
    .command('init')
    .description('Initialize CommitCraft in the current repository')
    .option('-y, --yes', 'Use default configuration')
    .option('--force', 'Overwrite existing configuration')
    .action(async (options: { yes?: boolean; force?: boolean }) => {
      const theme = new Theme();
      const spinner = new Spinner();

      const configPath = path.join(process.cwd(), '.commitcraft.json');

      if (fs.existsSync(configPath) && !options.force) {
        process.stderr.write(
          theme.warning('Configuration file already exists. Use --force to overwrite.\n'),
        );
        process.exit(1);
      }

      let config: Record<string, unknown>;

      if (options.yes) {
        config = createDefaultConfig();
      } else {
        config = await promptForConfig();
      }

      spinner.start('Creating configuration file...');

      try {
        fs.writeFileSync(configPath, JSON.stringify(config, null, 2) + '\n', 'utf-8');
        spinner.succeed(`Created ${configPath}`);

        const gitignorePath = path.join(process.cwd(), '.gitignore');
        if (fs.existsSync(gitignorePath)) {
          const content = fs.readFileSync(gitignorePath, 'utf-8');
          if (!content.includes('.commitcraft/cache')) {
            fs.appendFileSync(gitignorePath, '\n.commitcraft/cache\n');
            process.stdout.write(theme.dim('  Updated .gitignore\n'));
          }
        }

        process.stdout.write('\n' + theme.success('CommitCraft initialized successfully!') + '\n');
        process.stdout.write(theme.dim('\nNext steps:\n'));
        process.stdout.write(theme.dim('  1. Set your API key: export COMMITCRAFT_API_KEY=your-key\n'));
        process.stdout.write(theme.dim('  2. Stage some changes: git add .\n'));
        process.stdout.write(theme.dim('  3. Generate a message: commitcraft\n\n'));
      } catch (error) {
        spinner.fail('Failed to create configuration');
        process.stderr.write(
          theme.error(`Error: ${error instanceof Error ? error.message : String(error)}\n`),
        );
        process.exit(1);
      }
    });
}

async function promptForConfig(): Promise<Record<string, unknown>> {
  const promptUI = new PromptUI();

  const provider = await promptUI.select('AI Provider:', [
    { name: 'Claude (Anthropic)', value: 'claude' },
    { name: 'Other (configure manually)', value: 'other' },
  ]);

  const model = provider === 'claude'
    ? await promptUI.select('Model:', [
        { name: 'Claude Sonnet 4 (recommended)', value: 'claude-sonnet-4-20250514' },
        { name: 'Claude 3.5 Sonnet', value: 'claude-3-5-sonnet-20241022' },
        { name: 'Claude 3 Haiku (faster, cheaper)', value: 'claude-3-haiku-20240307' },
      ])
    : await promptUI.input('Model name:', 'claude-sonnet-4-20250514');

  const format = await promptUI.select('Commit format:', [
    { name: 'Conventional Commits', value: CommitFormat.CONVENTIONAL },
    { name: 'Angular', value: CommitFormat.ANGULAR },
    { name: 'Karma', value: CommitFormat.KARMA },
  ]);

  const maxSubjectLength = await promptUI.input('Max subject length:', '72');
  const includeBody = await promptUI.confirm('Include commit body?', true);
  const emoji = await promptUI.confirm('Use emoji in commits?', false);

  const defaultTypes = Object.values(CommitType);
  const allowedTypes = await promptUI.checkbox(
    'Allowed commit types:',
    defaultTypes.map((t) => ({ name: t, value: t, checked: true })),
  );

  return {
    ai: {
      provider: provider as string,
      model: model as string,
    },
    commit: {
      format,
      maxSubjectLength: parseInt(maxSubjectLength as string, 10) || 72,
      includeBody,
      emoji,
      allowedTypes: allowedTypes.length > 0 ? allowedTypes : defaultTypes,
    },
  };
}

function createDefaultConfig(): Record<string, unknown> {
  return {
    ai: {
      provider: DEFAULT_CONFIG.ai.provider,
      model: DEFAULT_CONFIG.ai.model,
    },
    commit: {
      format: DEFAULT_CONFIG.commit.format,
      maxSubjectLength: DEFAULT_CONFIG.commit.maxSubjectLength,
      includeBody: DEFAULT_CONFIG.commit.includeBody,
      emoji: DEFAULT_CONFIG.commit.emoji,
    },
    git: {
      excludePatterns: DEFAULT_CONFIG.git.excludePatterns,
    },
  };
}
