import { Command } from 'commander';

import {
  ConfigLoader,
  GitRepository,
  DiffParser,
  MessageBuilder,
  ProviderFactory,
  CommitType,
  CommitFormat,
  CommitMessageOptions,
  AIProviderType,
  StagedFilesAnalyzer,
  DiffAnalyzer,
  CommitCraftError,
  ErrorCode,
  PromptContext,
} from '@commitcraft/core';

import { Spinner } from '../ui/spinner';
import { PromptUI } from '../ui/prompt';
import { DiffDisplay } from '../ui/diff-display';
import { Theme } from '../ui/theme';

export function registerGenerateCommand(program: Command): void {
  program
    .command('generate')
    .alias('gen')
    .alias('g')
    .description('Generate a commit message from staged changes')
    .option('-t, --type <type>', 'Force a specific commit type (feat, fix, etc.)')
    .option('-s, --scope <scope>', 'Force a specific scope')
    .option('--no-body', 'Skip generating commit body')
    .option('--no-edit', 'Skip editing the generated message')
    .option('--dry-run', 'Generate message without committing')
    .option('-y, --yes', 'Auto-confirm the generated message')
    .option('--max-length <length>', 'Maximum subject line length', '72')
    .option('--format <format>', 'Commit format (conventional, angular, karma)')
    .option('--emoji', 'Include emoji in commit message')
    .option('--alternatives <count>', 'Number of alternative messages to generate', '0')
    .action(async (options: GenerateOptions) => {
      await executeGenerate(options, program);
    });

  program
    .action(async () => {
      const opts = program.opts() as GlobalOptions;
      await executeGenerate({
        type: undefined,
        scope: undefined,
        body: true,
        edit: true,
        dryRun: false,
        yes: false,
        maxLength: '72',
        format: undefined,
        emoji: false,
        alternatives: '0',
        ...opts,
      }, program);
    });
}

async function executeGenerate(options: GenerateOptions, _program: Command): Promise<void> {
  const theme = new Theme();
  const spinner = new Spinner();
  const promptUI = new PromptUI();
  const diffDisplay = new DiffDisplay();

  try {
    spinner.start('Loading configuration...');
    const configLoader = new ConfigLoader();
    const config = await configLoader.load();
    spinner.succeed('Configuration loaded');

    spinner.start('Checking repository...');
    const repo = new GitRepository();
    const info = await repo.getInfo();

    if (!info.hasStaged) {
      spinner.fail('No staged changes found');
      process.stdout.write(theme.warning('\nStage your changes first:\n'));
      process.stdout.write(theme.dim('  git add <files>\n'));
      process.stdout.write(theme.dim('  git add -p\n\n'));
      process.exit(1);
    }
    spinner.succeed(`Repository: ${info.root} (${info.branch})`);

    spinner.start('Analyzing staged changes...');
    const stagedAnalyzer = new StagedFilesAnalyzer(repo);
    const report = await stagedAnalyzer.analyze();
    spinner.succeed(`${report.totalFiles} file(s) staged (+${report.totalAdditions}/-${report.totalDeletions})`);

    diffDisplay.showStagedSummary(report);

    spinner.start('Parsing diff...');
    const rawDiff = await repo.getStagedDiff({
      contextLines: config.git.contextLines,
      ignoreWhitespace: config.git.ignoreWhitespace,
      followRenames: config.git.followRenames,
    });

    const diffParser = new DiffParser();
    const parsedDiff = diffParser.parse(rawDiff, config.git.maxDiffSize);
    spinner.succeed('Diff parsed');

    const diffAnalyzer = new DiffAnalyzer();
    const analysis = diffAnalyzer.analyze(parsedDiff);

    process.stdout.write(
      theme.dim(`  Suggested type: ${analysis.suggestedType} (${Math.round(analysis.confidence * 100)}% confidence)\n`),
    );
    process.stdout.write(
      theme.dim(`  Complexity: ${analysis.complexity.level} (score: ${analysis.complexity.score})\n\n`),
    );

    const commitOptions = buildCommitOptions(options, config);
    const recentCommits = await repo.getRecentCommits(5);

    const context: PromptContext = {
      repoName: await repo.getRepoName(),
      branchName: info.branch,
      recentCommits,
      fileCategories: Object.fromEntries(
        [...report.categories.entries()].map(([k, v]) => [k, v.length]),
      ),
      projectType: report.summary.primaryLanguage,
      conventionExamples: recentCommits.filter((c) =>
        /^\w+(\([^)]+\))?!?:/.test(c),
      ),
      additionalContext: null,
    };

    spinner.start('Generating commit message with AI...');
    const provider = ProviderFactory.create({
      type: config.ai.provider as AIProviderType,
      apiKey: config.ai.apiKey,
      model: config.ai.model,
      baseUrl: config.ai.baseUrl,
      maxTokens: config.ai.maxTokens,
      temperature: config.ai.temperature,
      topP: config.ai.topP,
      timeout: config.ai.timeout,
    });

    const messageBuilder = new MessageBuilder();
    const result = await messageBuilder.generate(
      provider,
      parsedDiff,
      commitOptions,
      context,
    );
    spinner.succeed('Message generated');

    process.stdout.write('\n' + theme.box('Generated Commit Message', result.formatted) + '\n');

    if (result.validation.warnings.length > 0) {
      for (const warning of result.validation.warnings) {
        process.stdout.write(theme.warning(`  Warning: ${warning}\n`));
      }
    }

    process.stdout.write(
      theme.dim(`\n  Model: ${result.model} | Tokens: ${result.usage.totalTokens} | Cost: $${result.usage.estimatedCost.toFixed(6)} | Latency: ${result.latency}ms\n\n`),
    );

    if (options.dryRun) {
      process.stdout.write(theme.info('Dry run mode - not committing\n'));
      return;
    }

    let finalMessage = result.formatted;

    if (options.edit && !options.yes) {
      const action = await promptUI.selectAction([
        { name: 'Commit with this message', value: 'commit' },
        { name: 'Edit the message', value: 'edit' },
        { name: 'Regenerate', value: 'regenerate' },
        { name: 'Cancel', value: 'cancel' },
      ]);

      switch (action) {
        case 'edit': {
          const edited = await promptUI.editMessage(finalMessage);
          if (edited) {
            finalMessage = edited;
          }
          break;
        }
        case 'regenerate':
          process.stdout.write(theme.info('Regenerating...\n'));
          return executeGenerate(options, _program);
        case 'cancel':
          process.stdout.write(theme.info('Cancelled\n'));
          return;
        case 'commit':
        default:
          break;
      }
    }

    spinner.start('Creating commit...');
    const commitHash = await repo.commit(finalMessage, {
      signOff: config.commit.signOff,
      gpgSign: config.commit.gpgSign,
    });
    spinner.succeed(`Committed: ${commitHash.substring(0, 8)}`);

    process.stdout.write('\n' + theme.success('Commit created successfully!') + '\n\n');

    provider.dispose();
  } catch (error) {
    spinner.fail('Failed');

    if (CommitCraftError.isCommitCraftError(error)) {
      if (error.code === ErrorCode.AI_INVALID_API_KEY) {
        process.stderr.write(theme.error('\nInvalid API key. Set your key:\n'));
        process.stderr.write(theme.dim('  export COMMITCRAFT_API_KEY=your-key\n'));
        process.stderr.write(theme.dim('  commitcraft config set ai.apiKey your-key\n\n'));
      } else if (error.code === ErrorCode.GIT_NOT_REPOSITORY) {
        process.stderr.write(theme.error('\nNot in a git repository.\n'));
        process.stderr.write(theme.dim('  Initialize with: git init\n\n'));
      } else {
        process.stderr.write(theme.error(`\n${error.message}\n\n`));
      }
    } else {
      process.stderr.write(
        theme.error(`\nUnexpected error: ${error instanceof Error ? error.message : String(error)}\n\n`),
      );
    }

    process.exit(1);
  }
}

function buildCommitOptions(
  options: GenerateOptions,
  config: ReturnType<typeof ConfigLoader.createDefault>,
): CommitMessageOptions {
  return {
    type: options.type ? (options.type as CommitType) : undefined,
    scope: options.scope,
    maxSubjectLength: parseInt(options.maxLength, 10) || config.commit.maxSubjectLength,
    includeBody: options.body !== false && config.commit.includeBody,
    includeFooter: config.commit.includeFooter,
    includeBreakingChanges: config.commit.includeBreakingChanges,
    includeIssueReferences: config.commit.includeIssueReferences,
    format: (options.format as CommitFormat) ?? config.commit.format,
    language: config.commit.language,
    emoji: options.emoji || config.commit.emoji,
  };
}

interface GenerateOptions {
  type?: string;
  scope?: string;
  body?: boolean;
  edit?: boolean;
  dryRun?: boolean;
  yes?: boolean;
  maxLength: string;
  format?: string;
  emoji?: boolean;
  alternatives: string;
  verbose?: boolean;
}

interface GlobalOptions {
  verbose?: boolean;
  color?: boolean;
  json?: boolean;
  quiet?: boolean;
}
