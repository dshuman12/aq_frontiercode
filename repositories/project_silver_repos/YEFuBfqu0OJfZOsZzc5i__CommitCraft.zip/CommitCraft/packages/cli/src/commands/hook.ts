import * as fs from 'fs';
import * as path from 'path';

import { Command } from 'commander';

import { GitRepository } from '@commitcraft/core';

import { Theme } from '../ui/theme';
import { Spinner } from '../ui/spinner';

const PREPARE_COMMIT_MSG_HOOK = `#!/bin/sh
if [ -z "$2" ] || [ "$2" = "message" ]; then
  exec < /dev/tty
  commitcraft generate --no-edit --yes > "$1.tmp" 2>/dev/null
  if [ $? -eq 0 ] && [ -s "$1.tmp" ]; then
    mv "$1.tmp" "$1"
  else
    rm -f "$1.tmp"
  fi
fi
`;

const COMMIT_MSG_HOOK = `#!/bin/sh
COMMIT_MSG_FILE="$1"
COMMIT_MSG=$(cat "$COMMIT_MSG_FILE")

if echo "$COMMIT_MSG" | head -1 | grep -qE "^(feat|fix|docs|style|refactor|perf|test|build|ci|chore|revert)(\\([^)]+\\))?!?:"; then
  exit 0
fi

echo "CommitCraft: Commit message does not follow conventional commits format."
echo "Expected: type(scope): subject"
echo "Got: $(echo "$COMMIT_MSG" | head -1)"
echo ""
echo "Use 'commitcraft generate' to create a proper commit message."
exit 1
`;

export function registerHookCommand(program: Command): void {
  const hookCmd = program
    .command('hook')
    .description('Manage git hooks for CommitCraft');

  hookCmd
    .command('install')
    .description('Install git hooks')
    .option('--type <type>', 'Hook type (prepare-commit-msg, commit-msg)', 'prepare-commit-msg')
    .option('--force', 'Overwrite existing hooks')
    .action(async (options: { type: string; force?: boolean }) => {
      const theme = new Theme();
      const spinner = new Spinner();

      try {
        const repo = new GitRepository();
        const root = await repo.getRoot();
        const hooksDir = path.join(root, '.git', 'hooks');

        if (!fs.existsSync(hooksDir)) {
          fs.mkdirSync(hooksDir, { recursive: true });
        }

        const hookPath = path.join(hooksDir, options.type);

        if (fs.existsSync(hookPath) && !options.force) {
          const existing = fs.readFileSync(hookPath, 'utf-8');
          if (!existing.includes('commitcraft')) {
            process.stderr.write(
              theme.warning(`Hook ${options.type} already exists. Use --force to overwrite.\n`),
            );
            process.exit(1);
          }
        }

        spinner.start(`Installing ${options.type} hook...`);

        const hookContent = options.type === 'commit-msg'
          ? COMMIT_MSG_HOOK
          : PREPARE_COMMIT_MSG_HOOK;

        fs.writeFileSync(hookPath, hookContent, { mode: 0o755 });
        spinner.succeed(`Installed ${options.type} hook`);

        process.stdout.write(theme.dim(`  Location: ${hookPath}\n\n`));
      } catch (error) {
        spinner.fail('Failed to install hook');
        process.stderr.write(
          theme.error(`Error: ${error instanceof Error ? error.message : String(error)}\n`),
        );
        process.exit(1);
      }
    });

  hookCmd
    .command('uninstall')
    .description('Remove git hooks')
    .option('--type <type>', 'Hook type to remove', 'prepare-commit-msg')
    .option('--all', 'Remove all CommitCraft hooks')
    .action(async (options: { type: string; all?: boolean }) => {
      const theme = new Theme();
      const spinner = new Spinner();

      try {
        const repo = new GitRepository();
        const root = await repo.getRoot();
        const hooksDir = path.join(root, '.git', 'hooks');

        const hookTypes = options.all
          ? ['prepare-commit-msg', 'commit-msg']
          : [options.type];

        for (const hookType of hookTypes) {
          const hookPath = path.join(hooksDir, hookType);

          if (fs.existsSync(hookPath)) {
            const content = fs.readFileSync(hookPath, 'utf-8');
            if (content.includes('commitcraft') || content.includes('CommitCraft')) {
              spinner.start(`Removing ${hookType} hook...`);
              fs.unlinkSync(hookPath);
              spinner.succeed(`Removed ${hookType} hook`);
            } else {
              process.stdout.write(
                theme.dim(`  ${hookType}: Not a CommitCraft hook, skipping\n`),
              );
            }
          } else {
            process.stdout.write(
              theme.dim(`  ${hookType}: Not installed\n`),
            );
          }
        }
      } catch (error) {
        spinner.fail('Failed to uninstall hook');
        process.stderr.write(
          theme.error(`Error: ${error instanceof Error ? error.message : String(error)}\n`),
        );
        process.exit(1);
      }
    });

  hookCmd
    .command('status')
    .description('Show installed hooks status')
    .action(async () => {
      const theme = new Theme();

      try {
        const repo = new GitRepository();
        const root = await repo.getRoot();
        const hooksDir = path.join(root, '.git', 'hooks');
        const hookTypes = ['prepare-commit-msg', 'commit-msg', 'pre-commit', 'post-commit'];

        process.stdout.write('\n' + theme.header('Git Hooks Status') + '\n\n');

        for (const hookType of hookTypes) {
          const hookPath = path.join(hooksDir, hookType);
          const exists = fs.existsSync(hookPath);

          if (exists) {
            const content = fs.readFileSync(hookPath, 'utf-8');
            const isCommitCraft = content.includes('commitcraft') || content.includes('CommitCraft');

            if (isCommitCraft) {
              process.stdout.write(theme.success(`  ${hookType}: Installed (CommitCraft)\n`));
            } else {
              process.stdout.write(theme.warning(`  ${hookType}: Installed (other)\n`));
            }
          } else {
            process.stdout.write(theme.dim(`  ${hookType}: Not installed\n`));
          }
        }

        process.stdout.write('\n');
      } catch (error) {
        process.stderr.write(
          theme.error(`Error: ${error instanceof Error ? error.message : String(error)}\n`),
        );
        process.exit(1);
      }
    });
}
