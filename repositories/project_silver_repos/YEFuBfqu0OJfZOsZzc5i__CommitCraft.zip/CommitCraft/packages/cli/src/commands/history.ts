import { Command } from 'commander';

import {
  GitRepository,
  CommitHistory,
  PatternMatcher,
} from '@commitcraft/core';

import { Theme } from '../ui/theme';
import { TableFormatter } from '../formatters/table';
import { Spinner } from '../ui/spinner';

export function registerHistoryCommand(program: Command): void {
  const historyCmd = program
    .command('history')
    .alias('hist')
    .description('Analyze commit history');

  historyCmd
    .command('analyze')
    .description('Analyze commit message patterns')
    .option('-n, --count <count>', 'Number of commits to analyze', '100')
    .action(async (options: { count: string }) => {
      const theme = new Theme();
      const spinner = new Spinner();
      const table = new TableFormatter();

      try {
        spinner.start('Analyzing commit history...');
        const repo = new GitRepository();
        const history = new CommitHistory(repo);
        const analysis = await history.analyze(parseInt(options.count, 10));
        spinner.succeed(`Analyzed ${analysis.entries.length} commits`);

        process.stdout.write('\n' + theme.header('Commit History Analysis') + '\n\n');

        process.stdout.write(`  Conventional commits: ${analysis.conventionalPercentage}%\n`);
        process.stdout.write(`  Average subject length: ${analysis.averageSubjectLength} chars\n`);
        process.stdout.write(`  Consistency score: ${analysis.consistencyScore}/100\n\n`);

        if (Object.keys(analysis.typeDistribution).length > 0) {
          process.stdout.write(theme.subheader('Type Distribution') + '\n');
          const typeRows = Object.entries(analysis.typeDistribution)
            .sort((a, b) => b[1] - a[1])
            .map(([type, count]) => {
              const percentage = Math.round((count / analysis.entries.length) * 100);
              const bar = '█'.repeat(Math.ceil(percentage / 5));
              return [type, String(count), `${percentage}%`, bar];
            });

          process.stdout.write(
            table.format(['Type', 'Count', '%', 'Distribution'], typeRows) + '\n\n',
          );
        }

        if (Object.keys(analysis.scopeDistribution).length > 0) {
          process.stdout.write(theme.subheader('Top Scopes') + '\n');
          const scopeRows = Object.entries(analysis.scopeDistribution)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 10)
            .map(([scope, count]) => [scope, String(count)]);

          process.stdout.write(
            table.format(['Scope', 'Count'], scopeRows) + '\n\n',
          );
        }

        if (analysis.commonPatterns.length > 0) {
          process.stdout.write(theme.subheader('Patterns') + '\n');
          for (const pattern of analysis.commonPatterns) {
            process.stdout.write(`  - ${pattern}\n`);
          }
          process.stdout.write('\n');
        }
      } catch (error) {
        spinner.fail('Analysis failed');
        process.stderr.write(
          theme.error(`Error: ${error instanceof Error ? error.message : String(error)}\n`),
        );
        process.exit(1);
      }
    });

  historyCmd
    .command('types')
    .description('Show most used commit types')
    .option('-n, --count <count>', 'Number of types to show', '10')
    .action(async (options: { count: string }) => {
      const theme = new Theme();
      const table = new TableFormatter();

      try {
        const repo = new GitRepository();
        const history = new CommitHistory(repo);
        const types = await history.getMostUsedTypes(parseInt(options.count, 10));

        process.stdout.write('\n' + theme.header('Most Used Commit Types') + '\n\n');

        const rows = types.map(({ type, count }) => [type, String(count)]);
        process.stdout.write(table.format(['Type', 'Count'], rows) + '\n');
      } catch (error) {
        process.stderr.write(
          theme.error(`Error: ${error instanceof Error ? error.message : String(error)}\n`),
        );
        process.exit(1);
      }
    });

  historyCmd
    .command('scopes')
    .description('Show most used scopes')
    .option('-n, --count <count>', 'Number of scopes to show', '10')
    .action(async (options: { count: string }) => {
      const theme = new Theme();
      const table = new TableFormatter();

      try {
        const repo = new GitRepository();
        const history = new CommitHistory(repo);
        const scopes = await history.getMostUsedScopes(parseInt(options.count, 10));

        process.stdout.write('\n' + theme.header('Most Used Scopes') + '\n\n');

        const rows = scopes.map(({ scope, count }) => [scope, String(count)]);
        process.stdout.write(table.format(['Scope', 'Count'], rows) + '\n');
      } catch (error) {
        process.stderr.write(
          theme.error(`Error: ${error instanceof Error ? error.message : String(error)}\n`),
        );
        process.exit(1);
      }
    });

  historyCmd
    .command('patterns')
    .description('Detect commit message patterns')
    .option('-n, --count <count>', 'Number of commits to analyze', '50')
    .action(async (options: { count: string }) => {
      const theme = new Theme();

      try {
        const repo = new GitRepository();
        const commits = await repo.getRecentCommits(parseInt(options.count, 10));
        const matcher = new PatternMatcher();
        const matches = matcher.match(commits);

        process.stdout.write('\n' + theme.header('Detected Patterns') + '\n\n');

        if (matches.length === 0) {
          process.stdout.write(theme.dim('  No patterns detected\n\n'));
          return;
        }

        for (const match of matches) {
          const confidence = Math.round(match.confidence * 100);
          process.stdout.write(`  ${match.pattern.name} (${confidence}% match)\n`);
          process.stdout.write(theme.dim(`    ${match.pattern.description}\n`));
          if (match.examples.length > 0) {
            process.stdout.write(theme.dim(`    Example: ${match.examples[0]}\n`));
          }
          process.stdout.write('\n');
        }

        const typeSuggestion = matcher.suggestType(commits);
        if (typeSuggestion) {
          process.stdout.write(
            theme.info(
              `Suggested default type: ${typeSuggestion.type} (${Math.round(typeSuggestion.confidence * 100)}% confidence)\n`,
            ),
          );
        }
      } catch (error) {
        process.stderr.write(
          theme.error(`Error: ${error instanceof Error ? error.message : String(error)}\n`),
        );
        process.exit(1);
      }
    });
}
