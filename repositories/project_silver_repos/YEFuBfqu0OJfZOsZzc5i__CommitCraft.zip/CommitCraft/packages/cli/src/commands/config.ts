import * as fs from 'fs';
import * as path from 'path';

import { Command } from 'commander';

import { ConfigLoader, DEFAULT_CONFIG } from '@commitcraft/core';

import { Theme } from '../ui/theme';
import { TableFormatter } from '../formatters/table';

export function registerConfigCommand(program: Command): void {
  const configCmd = program
    .command('config')
    .description('Manage CommitCraft configuration');

  configCmd
    .command('show')
    .description('Display current configuration')
    .option('--path <path>', 'Show config value at path (e.g., ai.model)')
    .action(async (options: { path?: string }) => {
      const theme = new Theme();
      const configLoader = new ConfigLoader();

      try {
        const config = await configLoader.load();

        if (options.path) {
          const value = getNestedValue(config, options.path);
          if (value !== undefined) {
            process.stdout.write(`${options.path} = ${JSON.stringify(value, null, 2)}\n`);
          } else {
            process.stderr.write(theme.error(`Config path not found: ${options.path}\n`));
            process.exit(1);
          }
        } else {
          const masked = maskSensitiveValues(config);
          process.stdout.write(JSON.stringify(masked, null, 2) + '\n');
        }
      } catch (error) {
        process.stderr.write(
          theme.error(`Failed to load config: ${error instanceof Error ? error.message : String(error)}\n`),
        );
        process.exit(1);
      }
    });

  configCmd
    .command('set <path> <value>')
    .description('Set a configuration value')
    .option('-g, --global', 'Set in global config (~/.commitcraft.json)')
    .action(async (configPath: string, value: string, options: { global?: boolean }) => {
      const theme = new Theme();

      try {
        const configFile = options.global
          ? path.join(process.env.HOME ?? '~', '.commitcraft.json')
          : path.join(process.cwd(), '.commitcraft.json');

        let existingConfig: Record<string, unknown> = {};
        if (fs.existsSync(configFile)) {
          existingConfig = JSON.parse(fs.readFileSync(configFile, 'utf-8')) as Record<string, unknown>;
        }

        const parsedValue = parseValue(value);
        setNestedValue(existingConfig, configPath, parsedValue);

        fs.writeFileSync(configFile, JSON.stringify(existingConfig, null, 2) + '\n', 'utf-8');
        process.stdout.write(theme.success(`Set ${configPath} = ${JSON.stringify(parsedValue)} in ${configFile}\n`));
      } catch (error) {
        process.stderr.write(
          theme.error(`Failed to set config: ${error instanceof Error ? error.message : String(error)}\n`),
        );
        process.exit(1);
      }
    });

  configCmd
    .command('get <path>')
    .description('Get a configuration value')
    .action(async (configPath: string) => {
      const theme = new Theme();
      const configLoader = new ConfigLoader();

      try {
        const config = await configLoader.load();
        const value = getNestedValue(config, configPath);

        if (value !== undefined) {
          process.stdout.write(`${JSON.stringify(value)}\n`);
        } else {
          process.stderr.write(theme.error(`Config path not found: ${configPath}\n`));
          process.exit(1);
        }
      } catch (error) {
        process.stderr.write(
          theme.error(`Failed to get config: ${error instanceof Error ? error.message : String(error)}\n`),
        );
        process.exit(1);
      }
    });

  configCmd
    .command('list')
    .description('List all configuration options')
    .action(() => {
      const table = new TableFormatter();
      const flatConfig = flattenObject(DEFAULT_CONFIG);

      const rows = Object.entries(flatConfig).map(([key, value]) => ({
        path: key,
        default: JSON.stringify(value),
        type: typeof value,
      }));

      process.stdout.write(
        table.format(
          ['Path', 'Default', 'Type'],
          rows.map((r) => [r.path, r.default, r.type]),
        ) + '\n',
      );
    });

  configCmd
    .command('reset')
    .description('Reset configuration to defaults')
    .option('-g, --global', 'Reset global config')
    .action((options: { global?: boolean }) => {
      const theme = new Theme();
      const configFile = options.global
        ? path.join(process.env.HOME ?? '~', '.commitcraft.json')
        : path.join(process.cwd(), '.commitcraft.json');

      if (fs.existsSync(configFile)) {
        fs.unlinkSync(configFile);
        process.stdout.write(theme.success(`Removed ${configFile}\n`));
      } else {
        process.stdout.write(theme.info(`No config file found at ${configFile}\n`));
      }
    });

  configCmd
    .command('validate')
    .description('Validate current configuration')
    .action(async () => {
      const theme = new Theme();
      const configLoader = new ConfigLoader();

      try {
        await configLoader.load();
        process.stdout.write(theme.success('Configuration is valid\n'));
      } catch (error) {
        process.stderr.write(
          theme.error(`Configuration validation failed:\n${error instanceof Error ? error.message : String(error)}\n`),
        );
        process.exit(1);
      }
    });
}

function getNestedValue(obj: unknown, path: string): unknown {
  const parts = path.split('.');
  let current = obj;

  for (const part of parts) {
    if (current === null || current === undefined || typeof current !== 'object') {
      return undefined;
    }
    current = (current as Record<string, unknown>)[part];
  }

  return current;
}

function setNestedValue(obj: Record<string, unknown>, path: string, value: unknown): void {
  const parts = path.split('.');
  let current = obj;

  for (let i = 0; i < parts.length - 1; i++) {
    const key = parts[i];
    if (!(key in current) || typeof current[key] !== 'object') {
      current[key] = {};
    }
    current = current[key] as Record<string, unknown>;
  }

  current[parts[parts.length - 1]] = value;
}

function parseValue(value: string): unknown {
  if (value === 'true') return true;
  if (value === 'false') return false;
  if (value === 'null') return null;

  const num = Number(value);
  if (!isNaN(num) && value !== '') return num;

  try {
    return JSON.parse(value) as unknown;
  } catch {
    return value;
  }
}

function maskSensitiveValues(config: unknown): unknown {
  if (typeof config !== 'object' || config === null) return config;

  const result: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(config as Record<string, unknown>)) {
    if (key.toLowerCase().includes('key') || key.toLowerCase().includes('secret') ||
        key.toLowerCase().includes('token') || key.toLowerCase().includes('password')) {
      if (typeof value === 'string' && value.length > 0) {
        result[key] = value.substring(0, 4) + '****' + value.substring(value.length - 4);
      } else {
        result[key] = value;
      }
    } else if (typeof value === 'object' && value !== null) {
      result[key] = maskSensitiveValues(value);
    } else {
      result[key] = value;
    }
  }
  return result;
}

function flattenObject(obj: unknown, prefix: string = ''): Record<string, unknown> {
  const result: Record<string, unknown> = {};

  if (typeof obj !== 'object' || obj === null) {
    return { [prefix]: obj };
  }

  for (const [key, value] of Object.entries(obj as Record<string, unknown>)) {
    const fullKey = prefix ? `${prefix}.${key}` : key;

    if (typeof value === 'object' && value !== null && !Array.isArray(value)) {
      Object.assign(result, flattenObject(value, fullKey));
    } else {
      result[fullKey] = value;
    }
  }

  return result;
}
