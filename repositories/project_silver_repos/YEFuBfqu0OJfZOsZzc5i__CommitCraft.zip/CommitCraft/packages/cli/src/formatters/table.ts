export class TableFormatter {
  private readonly padding: number;
  private readonly borderChar: string;

  constructor(options: TableFormatterOptions = {}) {
    this.padding = options.padding ?? 1;
    this.borderChar = options.borderChar ?? '│';
  }

  format(headers: string[], rows: string[][]): string {
    const colWidths = this.calculateColumnWidths(headers, rows);
    const lines: string[] = [];

    const headerLine = this.formatRow(headers, colWidths);
    lines.push(headerLine);

    const separator = colWidths
      .map((w) => '─'.repeat(w + this.padding * 2))
      .join('┼');
    lines.push(separator);

    for (const row of rows) {
      lines.push(this.formatRow(row, colWidths));
    }

    return lines.join('\n');
  }

  formatCompact(headers: string[], rows: string[][]): string {
    const colWidths = this.calculateColumnWidths(headers, rows);
    const lines: string[] = [];

    lines.push(this.formatRow(headers, colWidths));

    for (const row of rows) {
      lines.push(this.formatRow(row, colWidths));
    }

    return lines.join('\n');
  }

  formatMarkdown(headers: string[], rows: string[][]): string {
    const colWidths = this.calculateColumnWidths(headers, rows);
    const lines: string[] = [];

    const headerLine = '| ' + headers
      .map((h, i) => h.padEnd(colWidths[i]))
      .join(' | ') + ' |';
    lines.push(headerLine);

    const separator = '| ' + colWidths
      .map((w) => '-'.repeat(w))
      .join(' | ') + ' |';
    lines.push(separator);

    for (const row of rows) {
      const dataLine = '| ' + row
        .map((cell, i) => (cell ?? '').padEnd(colWidths[i]))
        .join(' | ') + ' |';
      lines.push(dataLine);
    }

    return lines.join('\n');
  }

  private formatRow(cells: string[], colWidths: number[]): string {
    const pad = ' '.repeat(this.padding);
    return cells
      .map((cell, i) => {
        const width = colWidths[i] ?? 0;
        return `${pad}${(cell ?? '').padEnd(width)}${pad}`;
      })
      .join(this.borderChar);
  }

  private calculateColumnWidths(headers: string[], rows: string[][]): number[] {
    return headers.map((header, index) => {
      const dataWidths = rows.map((row) => (row[index] ?? '').length);
      return Math.max(header.length, ...dataWidths);
    });
  }
}

export interface TableFormatterOptions {
  padding?: number;
  borderChar?: string;
}
