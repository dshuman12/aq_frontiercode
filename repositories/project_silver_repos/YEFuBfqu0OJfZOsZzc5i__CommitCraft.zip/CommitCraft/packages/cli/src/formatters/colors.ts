export const Colors = {
  reset: '\x1b[0m',
  bold: '\x1b[1m',
  dim: '\x1b[2m',
  italic: '\x1b[3m',
  underline: '\x1b[4m',
  inverse: '\x1b[7m',
  strikethrough: '\x1b[9m',

  black: '\x1b[30m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m',
  white: '\x1b[37m',
  gray: '\x1b[90m',

  bgBlack: '\x1b[40m',
  bgRed: '\x1b[41m',
  bgGreen: '\x1b[42m',
  bgYellow: '\x1b[43m',
  bgBlue: '\x1b[44m',
  bgMagenta: '\x1b[45m',
  bgCyan: '\x1b[46m',
  bgWhite: '\x1b[47m',
} as const;

export type ColorName = keyof typeof Colors;

export function colorize(text: string, ...colors: ColorName[]): string {
  if (!supportsColor()) return text;
  const codes = colors.map((c) => Colors[c]).join('');
  return `${codes}${text}${Colors.reset}`;
}

export function supportsColor(): boolean {
  if (process.env.NO_COLOR !== undefined) return false;
  if (process.env.FORCE_COLOR !== undefined) return true;
  if (process.stdout.isTTY === false) return false;
  return true;
}

export function stripColors(text: string): string {
  return text.replace(/\x1b\[[0-9;]*m/g, '');
}

export function rgb(r: number, g: number, b: number): string {
  return `\x1b[38;2;${r};${g};${b}m`;
}

export function bgRgb(r: number, g: number, b: number): string {
  return `\x1b[48;2;${r};${g};${b}m`;
}

export function createGradient(text: string, startColor: [number, number, number], endColor: [number, number, number]): string {
  if (!supportsColor()) return text;

  const chars = [...text];
  const length = chars.length;

  return chars.map((char, index) => {
    const ratio = length > 1 ? index / (length - 1) : 0;
    const r = Math.round(startColor[0] + (endColor[0] - startColor[0]) * ratio);
    const g = Math.round(startColor[1] + (endColor[1] - startColor[1]) * ratio);
    const b = Math.round(startColor[2] + (endColor[2] - startColor[2]) * ratio);
    return `${rgb(r, g, b)}${char}`;
  }).join('') + Colors.reset;
}
