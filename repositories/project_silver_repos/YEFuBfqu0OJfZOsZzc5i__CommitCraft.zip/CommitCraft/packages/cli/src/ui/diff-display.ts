import { StagedFilesReport, FileCategory, FileChange, FileChangeType } from '@commitcraft/core';

export class DiffDisplay {
  showStagedSummary(report: StagedFilesReport): void {
    process.stdout.write('\n');

    const grouped = this.groupByCategory(report.files);

    for (const [category, files] of grouped) {
      const label = this.getCategoryLabel(category);
      process.stdout.write(`  \x1b[1m${label}\x1b[0m\n`);

      for (const file of files) {
        const icon = this.getChangeIcon(file.changeType);
        const color = this.getChangeColor(file.changeType);
        const stats = this.formatStats(file.additions, file.deletions);
        const lang = file.language ? ` \x1b[2m(${file.language})\x1b[0m` : '';

        process.stdout.write(`    ${color}${icon}\x1b[0m ${file.path}${lang} ${stats}\n`);
      }
      process.stdout.write('\n');
    }
  }

  showDiff(diff: string, maxLines: number = 50): void {
    const lines = diff.split('\n');
    const displayLines = lines.slice(0, maxLines);

    for (const line of displayLines) {
      if (line.startsWith('+') && !line.startsWith('+++')) {
        process.stdout.write(`\x1b[32m${line}\x1b[0m\n`);
      } else if (line.startsWith('-') && !line.startsWith('---')) {
        process.stdout.write(`\x1b[31m${line}\x1b[0m\n`);
      } else if (line.startsWith('@@')) {
        process.stdout.write(`\x1b[36m${line}\x1b[0m\n`);
      } else if (line.startsWith('diff --git')) {
        process.stdout.write(`\x1b[1m${line}\x1b[0m\n`);
      } else {
        process.stdout.write(`${line}\n`);
      }
    }

    if (lines.length > maxLines) {
      process.stdout.write(
        `\x1b[2m... and ${lines.length - maxLines} more lines\x1b[0m\n`,
      );
    }
  }

  showFileList(files: FileChange[]): void {
    const maxPathLength = Math.max(...files.map((f) => f.path.length), 0);

    for (const file of files) {
      const icon = this.getChangeIcon(file.changeType);
      const color = this.getChangeColor(file.changeType);
      const paddedPath = file.path.padEnd(maxPathLength);
      const stats = this.formatStats(file.additions, file.deletions);

      process.stdout.write(`  ${color}${icon}\x1b[0m ${paddedPath} ${stats}\n`);
    }
  }

  private groupByCategory(files: FileChange[]): Map<FileCategory, FileChange[]> {
    const grouped = new Map<FileCategory, FileChange[]>();

    for (const file of files) {
      const existing = grouped.get(file.category) ?? [];
      existing.push(file);
      grouped.set(file.category, existing);
    }

    return grouped;
  }

  private getCategoryLabel(category: FileCategory): string {
    const labels: Record<string, string> = {
      source: 'Source Files',
      test: 'Tests',
      config: 'Configuration',
      documentation: 'Documentation',
      build: 'Build System',
      ci: 'CI/CD',
      asset: 'Assets',
      dependency: 'Dependencies',
      migration: 'Migrations',
      style: 'Styles',
      other: 'Other',
    };
    return labels[category] ?? 'Other';
  }

  private getChangeIcon(changeType: FileChangeType): string {
    switch (changeType) {
      case FileChangeType.ADDED:
        return '+';
      case FileChangeType.DELETED:
        return '-';
      case FileChangeType.RENAMED:
        return '→';
      case FileChangeType.COPIED:
        return '⊕';
      default:
        return '~';
    }
  }

  private getChangeColor(changeType: FileChangeType): string {
    switch (changeType) {
      case FileChangeType.ADDED:
        return '\x1b[32m';
      case FileChangeType.DELETED:
        return '\x1b[31m';
      case FileChangeType.RENAMED:
        return '\x1b[33m';
      default:
        return '\x1b[36m';
    }
  }

  private formatStats(additions: number, deletions: number): string {
    const parts: string[] = [];
    if (additions > 0) parts.push(`\x1b[32m+${additions}\x1b[0m`);
    if (deletions > 0) parts.push(`\x1b[31m-${deletions}\x1b[0m`);
    return parts.length > 0 ? `(${parts.join(' ')})` : '';
  }
}
