import * as readline from 'readline';

export interface SelectOption<T = string> {
  name: string;
  value: T;
  checked?: boolean;
}

export class PromptUI {
  async select<T = string>(
    message: string,
    choices: SelectOption<T>[],
  ): Promise<T> {
    const rl = this.createReadline();

    return new Promise((resolve) => {
      process.stdout.write(`\x1b[36m?\x1b[0m ${message}\n`);
      choices.forEach((choice, index) => {
        process.stdout.write(`  ${index + 1}. ${choice.name}\n`);
      });

      rl.question('  Select (number): ', (answer) => {
        rl.close();
        const index = parseInt(answer, 10) - 1;
        if (index >= 0 && index < choices.length) {
          resolve(choices[index].value);
        } else {
          resolve(choices[0].value);
        }
      });
    });
  }

  async selectAction<T = string>(
    choices: SelectOption<T>[],
  ): Promise<T> {
    return this.select('What would you like to do?', choices);
  }

  async input(message: string, defaultValue?: string): Promise<string> {
    const rl = this.createReadline();
    const defaultDisplay = defaultValue ? ` (${defaultValue})` : '';

    return new Promise((resolve) => {
      rl.question(`\x1b[36m?\x1b[0m ${message}${defaultDisplay} `, (answer) => {
        rl.close();
        resolve(answer.trim() || defaultValue || '');
      });
    });
  }

  async confirm(message: string, defaultValue: boolean = true): Promise<boolean> {
    const rl = this.createReadline();
    const hint = defaultValue ? '(Y/n)' : '(y/N)';

    return new Promise((resolve) => {
      rl.question(`\x1b[36m?\x1b[0m ${message} ${hint} `, (answer) => {
        rl.close();
        if (!answer.trim()) {
          resolve(defaultValue);
        } else {
          resolve(answer.trim().toLowerCase().startsWith('y'));
        }
      });
    });
  }

  async checkbox<T = string>(
    message: string,
    choices: SelectOption<T>[],
  ): Promise<T[]> {
    const rl = this.createReadline();

    return new Promise((resolve) => {
      process.stdout.write(`\x1b[36m?\x1b[0m ${message}\n`);
      choices.forEach((choice, index) => {
        const checked = choice.checked ? '[x]' : '[ ]';
        process.stdout.write(`  ${index + 1}. ${checked} ${choice.name}\n`);
      });

      rl.question('  Select (comma-separated numbers, or "all"): ', (answer) => {
        rl.close();

        if (answer.trim().toLowerCase() === 'all') {
          resolve(choices.map((c) => c.value));
          return;
        }

        const indices = answer
          .split(',')
          .map((s) => parseInt(s.trim(), 10) - 1)
          .filter((i) => i >= 0 && i < choices.length);

        if (indices.length === 0) {
          resolve(choices.filter((c) => c.checked).map((c) => c.value));
        } else {
          resolve(indices.map((i) => choices[i].value));
        }
      });
    });
  }

  async editMessage(message: string): Promise<string | null> {
    const rl = this.createReadline();

    return new Promise((resolve) => {
      process.stdout.write('\x1b[36m?\x1b[0m Edit the commit message (empty to keep current):\n');
      process.stdout.write(`\x1b[2m${message}\x1b[0m\n\n`);

      rl.question('New message (or press Enter to keep): ', (answer) => {
        rl.close();
        const trimmed = answer.trim();
        resolve(trimmed || null);
      });
    });
  }

  async password(message: string): Promise<string> {
    const rl = this.createReadline();

    return new Promise((resolve) => {
      process.stdout.write(`\x1b[36m?\x1b[0m ${message} `);

      const stdin = process.stdin;
      const originalRawMode = stdin.isRaw;

      if (stdin.isTTY) {
        stdin.setRawMode(true);
      }

      let password = '';

      const onData = (char: Buffer): void => {
        const c = char.toString('utf-8');

        if (c === '\n' || c === '\r') {
          if (stdin.isTTY) {
            stdin.setRawMode(originalRawMode ?? false);
          }
          stdin.removeListener('data', onData);
          process.stdout.write('\n');
          rl.close();
          resolve(password);
        } else if (c === '\u0003') {
          process.exit(1);
        } else if (c === '\u007f' || c === '\b') {
          if (password.length > 0) {
            password = password.slice(0, -1);
            process.stdout.write('\b \b');
          }
        } else {
          password += c;
          process.stdout.write('*');
        }
      };

      stdin.on('data', onData);
    });
  }

  private createReadline(): readline.Interface {
    return readline.createInterface({
      input: process.stdin,
      output: process.stdout,
    });
  }
}
