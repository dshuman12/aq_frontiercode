const SPINNER_FRAMES = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏'];

export class Spinner {
  private intervalId: ReturnType<typeof setInterval> | null = null;
  private frameIndex = 0;
  private currentMessage = '';
  private isSpinning = false;

  start(message: string): void {
    this.stop();
    this.currentMessage = message;
    this.isSpinning = true;
    this.frameIndex = 0;

    this.render();
    this.intervalId = setInterval(() => {
      this.frameIndex = (this.frameIndex + 1) % SPINNER_FRAMES.length;
      this.render();
    }, 80);
  }

  stop(): void {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    this.isSpinning = false;
    this.clearLine();
  }

  succeed(message?: string): void {
    this.stop();
    const text = message ?? this.currentMessage;
    process.stdout.write(`\x1b[32m✓\x1b[0m ${text}\n`);
  }

  fail(message?: string): void {
    this.stop();
    const text = message ?? this.currentMessage;
    process.stderr.write(`\x1b[31m✗\x1b[0m ${text}\n`);
  }

  warn(message?: string): void {
    this.stop();
    const text = message ?? this.currentMessage;
    process.stdout.write(`\x1b[33m⚠\x1b[0m ${text}\n`);
  }

  info(message?: string): void {
    this.stop();
    const text = message ?? this.currentMessage;
    process.stdout.write(`\x1b[36mℹ\x1b[0m ${text}\n`);
  }

  update(message: string): void {
    this.currentMessage = message;
    if (this.isSpinning) {
      this.render();
    }
  }

  private render(): void {
    this.clearLine();
    const frame = SPINNER_FRAMES[this.frameIndex];
    process.stdout.write(`\x1b[36m${frame}\x1b[0m ${this.currentMessage}`);
  }

  private clearLine(): void {
    process.stdout.write('\r\x1b[K');
  }
}
