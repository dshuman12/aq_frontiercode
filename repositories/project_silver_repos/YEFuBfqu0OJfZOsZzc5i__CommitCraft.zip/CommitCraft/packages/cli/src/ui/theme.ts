export class Theme {
  private readonly colorEnabled: boolean;

  constructor(colorEnabled: boolean = true) {
    this.colorEnabled = colorEnabled && process.stdout.isTTY !== false;
  }

  success(text: string): string {
    return this.color('\x1b[32m', text);
  }

  error(text: string): string {
    return this.color('\x1b[31m', text);
  }

  warning(text: string): string {
    return this.color('\x1b[33m', text);
  }

  info(text: string): string {
    return this.color('\x1b[36m', text);
  }

  dim(text: string): string {
    return this.color('\x1b[2m', text);
  }

  bold(text: string): string {
    return this.color('\x1b[1m', text);
  }

  underline(text: string): string {
    return this.color('\x1b[4m', text);
  }

  header(text: string): string {
    const line = '─'.repeat(text.length + 4);
    return [
      this.dim(line),
      this.bold(`  ${text}  `),
      this.dim(line),
    ].join('\n');
  }

  subheader(text: string): string {
    return `  ${this.bold(text)}`;
  }

  box(title: string, content: string): string {
    const lines = content.split('\n');
    const maxWidth = Math.max(
      title.length + 4,
      ...lines.map((l) => l.length + 4),
    );

    const topBorder = `╭${'─'.repeat(maxWidth)}╮`;
    const titleLine = `│ ${this.bold(title)}${' '.repeat(maxWidth - title.length - 2)} │`;
    const separator = `├${'─'.repeat(maxWidth)}┤`;
    const bottomBorder = `╰${'─'.repeat(maxWidth)}╯`;

    const contentLines = lines.map((line) => {
      const padding = ' '.repeat(Math.max(0, maxWidth - line.length - 2));
      return `│ ${line}${padding} │`;
    });

    return [
      this.dim(topBorder),
      titleLine,
      this.dim(separator),
      ...contentLines,
      this.dim(bottomBorder),
    ].join('\n');
  }

  table(headers: string[], rows: string[][]): string {
    const colWidths = headers.map((h, i) => {
      const dataMax = Math.max(...rows.map((r) => (r[i] ?? '').length), 0);
      return Math.max(h.length, dataMax);
    });

    const headerLine = headers
      .map((h, i) => h.padEnd(colWidths[i]))
      .join(' │ ');

    const separator = colWidths.map((w) => '─'.repeat(w)).join('─┼─');

    const dataLines = rows.map((row) =>
      row.map((cell, i) => (cell ?? '').padEnd(colWidths[i])).join(' │ '),
    );

    return [
      this.bold(headerLine),
      this.dim(separator),
      ...dataLines,
    ].join('\n');
  }

  progressBar(current: number, total: number, width: number = 30): string {
    const percentage = Math.min(Math.max(current / total, 0), 1);
    const filled = Math.round(width * percentage);
    const empty = width - filled;

    const bar = '█'.repeat(filled) + '░'.repeat(empty);
    const percent = `${Math.round(percentage * 100)}%`;

    return `${this.info(bar)} ${percent}`;
  }

  badge(text: string, type: 'success' | 'error' | 'warning' | 'info' = 'info'): string {
    const colorFn = {
      success: this.success.bind(this),
      error: this.error.bind(this),
      warning: this.warning.bind(this),
      info: this.info.bind(this),
    };

    return colorFn[type](`[${text}]`);
  }

  keyValue(key: string, value: string): string {
    return `${this.dim(key + ':')} ${value}`;
  }

  list(items: string[], ordered: boolean = false): string {
    return items
      .map((item, index) => {
        const prefix = ordered ? `${index + 1}.` : '•';
        return `  ${this.dim(prefix)} ${item}`;
      })
      .join('\n');
  }

  private color(code: string, text: string): string {
    if (!this.colorEnabled) return text;
    return `${code}${text}\x1b[0m`;
  }
}
