export function getTerminalWidth(): number {
  return process.stdout.columns ?? 80;
}

export function getTerminalHeight(): number {
  return process.stdout.rows ?? 24;
}

export function clearScreen(): void {
  process.stdout.write('\x1b[2J\x1b[H');
}

export function clearLine(): void {
  process.stdout.write('\r\x1b[K');
}

export function moveCursor(x: number, y: number): void {
  if (y > 0) process.stdout.write(`\x1b[${y}B`);
  if (y < 0) process.stdout.write(`\x1b[${-y}A`);
  if (x > 0) process.stdout.write(`\x1b[${x}C`);
  if (x < 0) process.stdout.write(`\x1b[${-x}D`);
}

export function hideCursor(): void {
  process.stdout.write('\x1b[?25l');
}

export function showCursor(): void {
  process.stdout.write('\x1b[?25h');
}

export function saveCursorPosition(): void {
  process.stdout.write('\x1b[s');
}

export function restoreCursorPosition(): void {
  process.stdout.write('\x1b[u');
}

export function isInteractive(): boolean {
  return Boolean(process.stdin.isTTY && process.stdout.isTTY);
}

export function setupGracefulExit(cleanup?: () => void): void {
  const handler = (): void => {
    showCursor();
    cleanup?.();
    process.exit(0);
  };

  process.on('SIGINT', handler);
  process.on('SIGTERM', handler);
  process.on('exit', () => {
    showCursor();
  });
}

export function truncateToWidth(text: string, maxWidth?: number): string {
  const width = maxWidth ?? getTerminalWidth();
  if (text.length <= width) return text;
  return text.substring(0, width - 3) + '...';
}

export function centerText(text: string, width?: number): string {
  const totalWidth = width ?? getTerminalWidth();
  if (text.length >= totalWidth) return text;
  const padding = Math.floor((totalWidth - text.length) / 2);
  return ' '.repeat(padding) + text;
}

export function rightAlign(text: string, width?: number): string {
  const totalWidth = width ?? getTerminalWidth();
  if (text.length >= totalWidth) return text;
  return ' '.repeat(totalWidth - text.length) + text;
}

export function horizontalRule(char: string = '─', width?: number): string {
  const totalWidth = width ?? getTerminalWidth();
  return char.repeat(totalWidth);
}
