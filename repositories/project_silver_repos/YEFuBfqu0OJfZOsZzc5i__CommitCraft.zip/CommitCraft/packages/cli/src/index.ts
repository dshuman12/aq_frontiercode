import { Command } from 'commander';

import { registerGenerateCommand } from './commands/generate';
import { registerConfigCommand } from './commands/config';
import { registerInitCommand } from './commands/init';
import { registerHistoryCommand } from './commands/history';
import { registerHookCommand } from './commands/hook';

export function createProgram(): Command {
  const program = new Command();

  program
    .name('commitcraft')
    .description('AI-powered commit message generator')
    .version('1.0.0')
    .option('-v, --verbose', 'Enable verbose output')
    .option('--no-color', 'Disable colored output')
    .option('--json', 'Output in JSON format')
    .option('-q, --quiet', 'Suppress non-essential output');

  registerGenerateCommand(program);
  registerConfigCommand(program);
  registerInitCommand(program);
  registerHistoryCommand(program);
  registerHookCommand(program);

  program
    .command('version')
    .description('Show version information')
    .action(() => {
      const info = {
        name: 'commitcraft',
        version: '1.0.0',
        node: process.version,
        platform: process.platform,
        arch: process.arch,
      };
      process.stdout.write(JSON.stringify(info, null, 2) + '\n');
    });

  return program;
}

export { registerGenerateCommand } from './commands/generate';
export { registerConfigCommand } from './commands/config';
export { registerInitCommand } from './commands/init';
export { registerHistoryCommand } from './commands/history';
export { registerHookCommand } from './commands/hook';
