# Contributing to CommitCraft

## Development Setup

```bash
git clone https://github.com/DevaanshKathuria/Whatsapp-Automation.git commitcraft
cd commitcraft
npm install
npm run build
```

## Project Structure

```
commitcraft/
├── packages/
│   ├── core/       # Shared library
│   ├── cli/        # CLI tool
│   └── vscode/     # VS Code extension
├── tests/
│   ├── unit/       # Unit tests
│   └── integration/ # Integration tests
├── docs/           # Documentation
└── package.json    # Root workspace config
```

## Development Workflow

1. Create a feature branch from `main`
2. Make your changes
3. Run lint and type checks: `npm run lint && npm run typecheck`
4. Run tests: `npm test`
5. Submit a pull request

## Commit Convention

This project uses conventional commits. Use CommitCraft itself to generate messages:

```bash
git add .
npx commitcraft
```

## Code Standards

- TypeScript strict mode
- ESLint with the project config
- Prettier for formatting (100 char width, 2-space indent)
- No `any` types
- Comprehensive error handling using `CommitCraftError`

## Testing

```bash
npm test                   # Run all tests
npm test -- --watch        # Watch mode
npm test -- --coverage     # With coverage
```

## Building

```bash
npm run build              # Build all packages
npm run clean              # Clean build artifacts
```

## Adding a New AI Provider

1. Create a new provider class implementing `AIProvider` in `packages/core/src/ai/`
2. Register it in `ProviderFactory`
3. Add configuration options to the config schema
4. Update documentation

## Adding a New CLI Command

1. Create the command file in `packages/cli/src/commands/`
2. Register it in `packages/cli/src/index.ts`
3. Add tests
4. Update CLI usage documentation

## License

By contributing, you agree that your contributions will be licensed under the MIT License.
