# Changelog

All notable changes to this project are documented here.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- `pantry healthcheck` subcommand for liveness probes.
- `pantry config check` validates environment variables and filesystem
  permissions before the service is started.
- Optional Prometheus metrics endpoint, gated by `PANTRY_METRICS_BIND`.
- Structured JSON log output, enabled by `PANTRY_LOG_FORMAT=json`.
- Reference deployment artifacts under `deploy/` (systemd unit,
  nginx fragment, docker-compose file, Grafana dashboard).

### Changed
- Removed the "personal" framing from the README and the design notes;
  documentation is now written for an operations audience.
- Container runtime user changed from numeric uid 1000 (which clashed
  with the upstream `node` user on alpine) to a dedicated `cook` user
  at uid 1100.

### Security
- Documented the disclosure process in `SECURITY.md`.
- Added CodeQL workflow against the TypeScript source.
- Added Trivy scan against the published container image.

## [0.4.0] - 2026-04-22

### Added
- Multi-household / multi-site partitioning at the data-directory level
  (`PANTRY_HOUSEHOLD` env var).
- `pantry replicate --to <peer>` for one-shot rsync to a peer host.
- File-level advisory locking to serialize concurrent CLI invocations
  against the same data directory.
- Token-bucket throttle for batch importers.
- `pantry archive` / `pantry restore` for offline backup tarballs.

### Changed
- Recipe storage moved to its own JSON-per-record directory, allowing
  recipe edits to be versioned independently of item churn.
- Default `noUncheckedIndexedAccess` enabled in `tsconfig.json`; all
  internal callers updated.

### Fixed
- Race condition in the atomic-rename path on tmpfs filesystems where
  `link()` is unsupported.
- `pantry import` no longer truncates on a CSV with a trailing newline
  inside a quoted field.

## [0.3.0] - 2026-02-11

### Added
- Reports suite: waste, frequent items, weekly plan adherence,
  inventory delta, dashboard, healthcheck, alerts.
- Read-only LAN web dashboard (`pantry serve`) with no client-side
  JavaScript.
- ANSI-color helper that honors `NO_COLOR` and `--no-color`.

### Changed
- The on-disk schema gained an explicit `schemaVersion` field. Existing
  stores are migrated transparently on first read.

## [0.2.0] - 2025-12-03

### Added
- Recipe domain (`pantry recipe add|edit|list|show|delete`).
- Shopping list builder (`pantry shop`) that diffs a meal plan against
  the current pantry contents.
- Importer suite for CSV receipts and JSONL meal histories.
- Exporter suite (Markdown, CSV, HTML, YAML, iCal, OPML).

## [0.1.0] - 2025-08-12

### Added
- Initial public release.
- Item / lot domain with JSON-file-per-record storage.
- Atomic write helpers (`tmpfile + rename`).
- Stdlib-only CLI dispatcher with subcommand registration via
  side-effect imports.
- `pantry list`, `pantry add`, `pantry use`, `pantry move`,
  `pantry expire` subcommands.

[Unreleased]: https://github.com/pantry-tools/pantry/compare/v0.4.0...HEAD
[0.4.0]: https://github.com/pantry-tools/pantry/compare/v0.3.0...v0.4.0
[0.3.0]: https://github.com/pantry-tools/pantry/compare/v0.2.0...v0.3.0
[0.2.0]: https://github.com/pantry-tools/pantry/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/pantry-tools/pantry/releases/tag/v0.1.0
