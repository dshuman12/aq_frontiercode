# Pantry export

_generated as a snapshot_


## item-001

slug: item-001
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-002

slug: item-002
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-003

slug: item-003
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-004

slug: item-004
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-005

slug: item-005
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-006

slug: item-006
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-007

slug: item-007
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-008

slug: item-008
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-009

slug: item-009
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-010

slug: item-010
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-011

slug: item-011
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-012

slug: item-012
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-013

slug: item-013
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-014

slug: item-014
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-015

slug: item-015
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-016

slug: item-016
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-017

slug: item-017
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-018

slug: item-018
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-019

slug: item-019
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-020

slug: item-020
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-021

slug: item-021
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-022

slug: item-022
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-023

slug: item-023
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-024

slug: item-024
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-025

slug: item-025
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-026

slug: item-026
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-027

slug: item-027
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-028

slug: item-028
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-029

slug: item-029
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-030

slug: item-030
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-031

slug: item-031
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-032

slug: item-032
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-033

slug: item-033
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-034

slug: item-034
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-035

slug: item-035
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-036

slug: item-036
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-037

slug: item-037
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-038

slug: item-038
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-039

slug: item-039
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-040

slug: item-040
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-041

slug: item-041
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-042

slug: item-042
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-043

slug: item-043
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-044

slug: item-044
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-045

slug: item-045
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-046

slug: item-046
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-047

slug: item-047
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-048

slug: item-048
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-049

slug: item-049
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-050

slug: item-050
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-051

slug: item-051
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-052

slug: item-052
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-053

slug: item-053
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-054

slug: item-054
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-055

slug: item-055
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-056

slug: item-056
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-057

slug: item-057
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-058

slug: item-058
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-059

slug: item-059
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-060

slug: item-060
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-061

slug: item-061
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-062

slug: item-062
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-063

slug: item-063
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-064

slug: item-064
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-065

slug: item-065
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-066

slug: item-066
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-067

slug: item-067
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-068

slug: item-068
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-069

slug: item-069
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-070

slug: item-070
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-071

slug: item-071
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-072

slug: item-072
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-073

slug: item-073
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-074

slug: item-074
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-075

slug: item-075
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-076

slug: item-076
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-077

slug: item-077
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-078

slug: item-078
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-079

slug: item-079
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-080

slug: item-080
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-081

slug: item-081
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-082

slug: item-082
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-083

slug: item-083
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-084

slug: item-084
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-085

slug: item-085
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-086

slug: item-086
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-087

slug: item-087
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-088

slug: item-088
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-089

slug: item-089
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-090

slug: item-090
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-091

slug: item-091
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-092

slug: item-092
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-093

slug: item-093
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-094

slug: item-094
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-095

slug: item-095
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-096

slug: item-096
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-097

slug: item-097
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-098

slug: item-098
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-099

slug: item-099
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-100

slug: item-100
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-101

slug: item-101
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-102

slug: item-102
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-103

slug: item-103
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-104

slug: item-104
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-105

slug: item-105
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-106

slug: item-106
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-107

slug: item-107
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-108

slug: item-108
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-109

slug: item-109
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-110

slug: item-110
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-111

slug: item-111
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-112

slug: item-112
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-113

slug: item-113
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-114

slug: item-114
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-115

slug: item-115
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-116

slug: item-116
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-117

slug: item-117
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-118

slug: item-118
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-119

slug: item-119
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-120

slug: item-120
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-121

slug: item-121
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-122

slug: item-122
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-123

slug: item-123
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-124

slug: item-124
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-125

slug: item-125
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-126

slug: item-126
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-127

slug: item-127
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-128

slug: item-128
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-129

slug: item-129
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-130

slug: item-130
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-131

slug: item-131
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-132

slug: item-132
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-133

slug: item-133
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-134

slug: item-134
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-135

slug: item-135
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-136

slug: item-136
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-137

slug: item-137
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-138

slug: item-138
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-139

slug: item-139
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-140

slug: item-140
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-141

slug: item-141
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-142

slug: item-142
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-143

slug: item-143
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-144

slug: item-144
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-145

slug: item-145
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-146

slug: item-146
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-147

slug: item-147
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-148

slug: item-148
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-149

slug: item-149
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-150

slug: item-150
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-151

slug: item-151
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-152

slug: item-152
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-153

slug: item-153
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-154

slug: item-154
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-155

slug: item-155
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-156

slug: item-156
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-157

slug: item-157
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-158

slug: item-158
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-159

slug: item-159
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-160

slug: item-160
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-161

slug: item-161
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-162

slug: item-162
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-163

slug: item-163
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-164

slug: item-164
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-165

slug: item-165
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-166

slug: item-166
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-167

slug: item-167
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-168

slug: item-168
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-169

slug: item-169
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-170

slug: item-170
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-171

slug: item-171
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-172

slug: item-172
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-173

slug: item-173
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-174

slug: item-174
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-175

slug: item-175
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-176

slug: item-176
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-177

slug: item-177
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-178

slug: item-178
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-179

slug: item-179
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-180

slug: item-180
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-181

slug: item-181
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-182

slug: item-182
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-183

slug: item-183
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-184

slug: item-184
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-185

slug: item-185
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-186

slug: item-186
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-187

slug: item-187
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-188

slug: item-188
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-189

slug: item-189
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-190

slug: item-190
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-191

slug: item-191
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-192

slug: item-192
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-193

slug: item-193
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-194

slug: item-194
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-195

slug: item-195
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-196

slug: item-196
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-197

slug: item-197
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-198

slug: item-198
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-199

slug: item-199
category: pantry
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry
  - lot 4: 400g in fridge

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.


## item-200

slug: item-200
category: oils
created: 2026-04-01
updated: 2026-04-30

lots:
  - lot 1: 100g in pantry
  - lot 2: 200g in fridge
  - lot 3: 300g in pantry

Notes:
Some longer notes about this item: I bought it from the local market and it's been on the shelf since last spring. It rotates through every couple weeks and I haven't had any complaints. I tend to buy these in pairs because they're cheap and useful across many recipes. The backup has saved me on more than one Sunday morning.

