# Year-in-pantry report


## 2026-01


### week 1

- 2026-01-01: cooked lentil-stew for 4 servings; pantry warm; nothing wasted.
- 2026-01-02: cooked chickpea-curry for 5 servings; pantry warm; nothing wasted.
- 2026-01-03: cooked cacio-e-pepe for 2 servings; pantry warm; nothing wasted.
- 2026-01-04: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-01-05: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-01-06: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-01-07: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.

### week 2

- 2026-01-08: cooked chickpea-curry for 5 servings; pantry warm; nothing wasted.
- 2026-01-09: cooked cacio-e-pepe for 2 servings; pantry warm; nothing wasted.
- 2026-01-10: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-01-11: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-01-12: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-01-13: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.
- 2026-01-14: cooked lentil-stew for 3 servings; pantry warm; nothing wasted.

### week 3

- 2026-01-15: cooked cacio-e-pepe for 2 servings; pantry warm; nothing wasted.
- 2026-01-16: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-01-17: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-01-18: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-01-19: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.
- 2026-01-20: cooked lentil-stew for 3 servings; pantry warm; nothing wasted.
- 2026-01-21: cooked chickpea-curry for 4 servings; pantry warm; nothing wasted.

### week 4

- 2026-01-22: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-01-23: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-01-24: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-01-25: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.
- 2026-01-26: cooked lentil-stew for 3 servings; pantry warm; nothing wasted.
- 2026-01-27: cooked chickpea-curry for 4 servings; pantry warm; nothing wasted.
- 2026-01-28: cooked cacio-e-pepe for 5 servings; pantry warm; nothing wasted.

### Notes for 2026-01

- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.

## 2026-02


### week 1

- 2026-02-01: cooked lentil-stew for 4 servings; pantry warm; nothing wasted.
- 2026-02-02: cooked chickpea-curry for 5 servings; pantry warm; nothing wasted.
- 2026-02-03: cooked cacio-e-pepe for 2 servings; pantry warm; nothing wasted.
- 2026-02-04: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-02-05: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-02-06: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-02-07: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.

### week 2

- 2026-02-08: cooked chickpea-curry for 5 servings; pantry warm; nothing wasted.
- 2026-02-09: cooked cacio-e-pepe for 2 servings; pantry warm; nothing wasted.
- 2026-02-10: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-02-11: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-02-12: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-02-13: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.
- 2026-02-14: cooked lentil-stew for 3 servings; pantry warm; nothing wasted.

### week 3

- 2026-02-15: cooked cacio-e-pepe for 2 servings; pantry warm; nothing wasted.
- 2026-02-16: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-02-17: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-02-18: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-02-19: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.
- 2026-02-20: cooked lentil-stew for 3 servings; pantry warm; nothing wasted.
- 2026-02-21: cooked chickpea-curry for 4 servings; pantry warm; nothing wasted.

### week 4

- 2026-02-22: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-02-23: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-02-24: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-02-25: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.
- 2026-02-26: cooked lentil-stew for 3 servings; pantry warm; nothing wasted.
- 2026-02-27: cooked chickpea-curry for 4 servings; pantry warm; nothing wasted.
- 2026-02-28: cooked cacio-e-pepe for 5 servings; pantry warm; nothing wasted.

### Notes for 2026-02

- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.

## 2026-03


### week 1

- 2026-03-01: cooked lentil-stew for 4 servings; pantry warm; nothing wasted.
- 2026-03-02: cooked chickpea-curry for 5 servings; pantry warm; nothing wasted.
- 2026-03-03: cooked cacio-e-pepe for 2 servings; pantry warm; nothing wasted.
- 2026-03-04: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-03-05: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-03-06: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-03-07: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.

### week 2

- 2026-03-08: cooked chickpea-curry for 5 servings; pantry warm; nothing wasted.
- 2026-03-09: cooked cacio-e-pepe for 2 servings; pantry warm; nothing wasted.
- 2026-03-10: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-03-11: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-03-12: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-03-13: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.
- 2026-03-14: cooked lentil-stew for 3 servings; pantry warm; nothing wasted.

### week 3

- 2026-03-15: cooked cacio-e-pepe for 2 servings; pantry warm; nothing wasted.
- 2026-03-16: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-03-17: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-03-18: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-03-19: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.
- 2026-03-20: cooked lentil-stew for 3 servings; pantry warm; nothing wasted.
- 2026-03-21: cooked chickpea-curry for 4 servings; pantry warm; nothing wasted.

### week 4

- 2026-03-22: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-03-23: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-03-24: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-03-25: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.
- 2026-03-26: cooked lentil-stew for 3 servings; pantry warm; nothing wasted.
- 2026-03-27: cooked chickpea-curry for 4 servings; pantry warm; nothing wasted.
- 2026-03-28: cooked cacio-e-pepe for 5 servings; pantry warm; nothing wasted.

### Notes for 2026-03

- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.

## 2026-04


### week 1

- 2026-04-01: cooked lentil-stew for 4 servings; pantry warm; nothing wasted.
- 2026-04-02: cooked chickpea-curry for 5 servings; pantry warm; nothing wasted.
- 2026-04-03: cooked cacio-e-pepe for 2 servings; pantry warm; nothing wasted.
- 2026-04-04: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-04-05: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-04-06: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-04-07: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.

### week 2

- 2026-04-08: cooked chickpea-curry for 5 servings; pantry warm; nothing wasted.
- 2026-04-09: cooked cacio-e-pepe for 2 servings; pantry warm; nothing wasted.
- 2026-04-10: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-04-11: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-04-12: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-04-13: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.
- 2026-04-14: cooked lentil-stew for 3 servings; pantry warm; nothing wasted.

### week 3

- 2026-04-15: cooked cacio-e-pepe for 2 servings; pantry warm; nothing wasted.
- 2026-04-16: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-04-17: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-04-18: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-04-19: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.
- 2026-04-20: cooked lentil-stew for 3 servings; pantry warm; nothing wasted.
- 2026-04-21: cooked chickpea-curry for 4 servings; pantry warm; nothing wasted.

### week 4

- 2026-04-22: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-04-23: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-04-24: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-04-25: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.
- 2026-04-26: cooked lentil-stew for 3 servings; pantry warm; nothing wasted.
- 2026-04-27: cooked chickpea-curry for 4 servings; pantry warm; nothing wasted.
- 2026-04-28: cooked cacio-e-pepe for 5 servings; pantry warm; nothing wasted.

### Notes for 2026-04

- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.

## 2026-05


### week 1

- 2026-05-01: cooked lentil-stew for 4 servings; pantry warm; nothing wasted.
- 2026-05-02: cooked chickpea-curry for 5 servings; pantry warm; nothing wasted.
- 2026-05-03: cooked cacio-e-pepe for 2 servings; pantry warm; nothing wasted.
- 2026-05-04: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-05-05: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-05-06: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-05-07: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.

### week 2

- 2026-05-08: cooked chickpea-curry for 5 servings; pantry warm; nothing wasted.
- 2026-05-09: cooked cacio-e-pepe for 2 servings; pantry warm; nothing wasted.
- 2026-05-10: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-05-11: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-05-12: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-05-13: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.
- 2026-05-14: cooked lentil-stew for 3 servings; pantry warm; nothing wasted.

### week 3

- 2026-05-15: cooked cacio-e-pepe for 2 servings; pantry warm; nothing wasted.
- 2026-05-16: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-05-17: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-05-18: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-05-19: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.
- 2026-05-20: cooked lentil-stew for 3 servings; pantry warm; nothing wasted.
- 2026-05-21: cooked chickpea-curry for 4 servings; pantry warm; nothing wasted.

### week 4

- 2026-05-22: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-05-23: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-05-24: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-05-25: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.
- 2026-05-26: cooked lentil-stew for 3 servings; pantry warm; nothing wasted.
- 2026-05-27: cooked chickpea-curry for 4 servings; pantry warm; nothing wasted.
- 2026-05-28: cooked cacio-e-pepe for 5 servings; pantry warm; nothing wasted.

### Notes for 2026-05

- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.

## 2026-06


### week 1

- 2026-06-01: cooked lentil-stew for 4 servings; pantry warm; nothing wasted.
- 2026-06-02: cooked chickpea-curry for 5 servings; pantry warm; nothing wasted.
- 2026-06-03: cooked cacio-e-pepe for 2 servings; pantry warm; nothing wasted.
- 2026-06-04: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-06-05: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-06-06: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-06-07: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.

### week 2

- 2026-06-08: cooked chickpea-curry for 5 servings; pantry warm; nothing wasted.
- 2026-06-09: cooked cacio-e-pepe for 2 servings; pantry warm; nothing wasted.
- 2026-06-10: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-06-11: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-06-12: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-06-13: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.
- 2026-06-14: cooked lentil-stew for 3 servings; pantry warm; nothing wasted.

### week 3

- 2026-06-15: cooked cacio-e-pepe for 2 servings; pantry warm; nothing wasted.
- 2026-06-16: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-06-17: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-06-18: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-06-19: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.
- 2026-06-20: cooked lentil-stew for 3 servings; pantry warm; nothing wasted.
- 2026-06-21: cooked chickpea-curry for 4 servings; pantry warm; nothing wasted.

### week 4

- 2026-06-22: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-06-23: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-06-24: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-06-25: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.
- 2026-06-26: cooked lentil-stew for 3 servings; pantry warm; nothing wasted.
- 2026-06-27: cooked chickpea-curry for 4 servings; pantry warm; nothing wasted.
- 2026-06-28: cooked cacio-e-pepe for 5 servings; pantry warm; nothing wasted.

### Notes for 2026-06

- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.

## 2026-07


### week 1

- 2026-07-01: cooked lentil-stew for 4 servings; pantry warm; nothing wasted.
- 2026-07-02: cooked chickpea-curry for 5 servings; pantry warm; nothing wasted.
- 2026-07-03: cooked cacio-e-pepe for 2 servings; pantry warm; nothing wasted.
- 2026-07-04: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-07-05: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-07-06: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-07-07: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.

### week 2

- 2026-07-08: cooked chickpea-curry for 5 servings; pantry warm; nothing wasted.
- 2026-07-09: cooked cacio-e-pepe for 2 servings; pantry warm; nothing wasted.
- 2026-07-10: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-07-11: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-07-12: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-07-13: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.
- 2026-07-14: cooked lentil-stew for 3 servings; pantry warm; nothing wasted.

### week 3

- 2026-07-15: cooked cacio-e-pepe for 2 servings; pantry warm; nothing wasted.
- 2026-07-16: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-07-17: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-07-18: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-07-19: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.
- 2026-07-20: cooked lentil-stew for 3 servings; pantry warm; nothing wasted.
- 2026-07-21: cooked chickpea-curry for 4 servings; pantry warm; nothing wasted.

### week 4

- 2026-07-22: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-07-23: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-07-24: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-07-25: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.
- 2026-07-26: cooked lentil-stew for 3 servings; pantry warm; nothing wasted.
- 2026-07-27: cooked chickpea-curry for 4 servings; pantry warm; nothing wasted.
- 2026-07-28: cooked cacio-e-pepe for 5 servings; pantry warm; nothing wasted.

### Notes for 2026-07

- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.

## 2026-08


### week 1

- 2026-08-01: cooked lentil-stew for 4 servings; pantry warm; nothing wasted.
- 2026-08-02: cooked chickpea-curry for 5 servings; pantry warm; nothing wasted.
- 2026-08-03: cooked cacio-e-pepe for 2 servings; pantry warm; nothing wasted.
- 2026-08-04: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-08-05: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-08-06: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-08-07: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.

### week 2

- 2026-08-08: cooked chickpea-curry for 5 servings; pantry warm; nothing wasted.
- 2026-08-09: cooked cacio-e-pepe for 2 servings; pantry warm; nothing wasted.
- 2026-08-10: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-08-11: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-08-12: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-08-13: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.
- 2026-08-14: cooked lentil-stew for 3 servings; pantry warm; nothing wasted.

### week 3

- 2026-08-15: cooked cacio-e-pepe for 2 servings; pantry warm; nothing wasted.
- 2026-08-16: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-08-17: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-08-18: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-08-19: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.
- 2026-08-20: cooked lentil-stew for 3 servings; pantry warm; nothing wasted.
- 2026-08-21: cooked chickpea-curry for 4 servings; pantry warm; nothing wasted.

### week 4

- 2026-08-22: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-08-23: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-08-24: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-08-25: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.
- 2026-08-26: cooked lentil-stew for 3 servings; pantry warm; nothing wasted.
- 2026-08-27: cooked chickpea-curry for 4 servings; pantry warm; nothing wasted.
- 2026-08-28: cooked cacio-e-pepe for 5 servings; pantry warm; nothing wasted.

### Notes for 2026-08

- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.

## 2026-09


### week 1

- 2026-09-01: cooked lentil-stew for 4 servings; pantry warm; nothing wasted.
- 2026-09-02: cooked chickpea-curry for 5 servings; pantry warm; nothing wasted.
- 2026-09-03: cooked cacio-e-pepe for 2 servings; pantry warm; nothing wasted.
- 2026-09-04: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-09-05: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-09-06: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-09-07: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.

### week 2

- 2026-09-08: cooked chickpea-curry for 5 servings; pantry warm; nothing wasted.
- 2026-09-09: cooked cacio-e-pepe for 2 servings; pantry warm; nothing wasted.
- 2026-09-10: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-09-11: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-09-12: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-09-13: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.
- 2026-09-14: cooked lentil-stew for 3 servings; pantry warm; nothing wasted.

### week 3

- 2026-09-15: cooked cacio-e-pepe for 2 servings; pantry warm; nothing wasted.
- 2026-09-16: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-09-17: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-09-18: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-09-19: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.
- 2026-09-20: cooked lentil-stew for 3 servings; pantry warm; nothing wasted.
- 2026-09-21: cooked chickpea-curry for 4 servings; pantry warm; nothing wasted.

### week 4

- 2026-09-22: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-09-23: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-09-24: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-09-25: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.
- 2026-09-26: cooked lentil-stew for 3 servings; pantry warm; nothing wasted.
- 2026-09-27: cooked chickpea-curry for 4 servings; pantry warm; nothing wasted.
- 2026-09-28: cooked cacio-e-pepe for 5 servings; pantry warm; nothing wasted.

### Notes for 2026-09

- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.

## 2026-10


### week 1

- 2026-10-01: cooked lentil-stew for 4 servings; pantry warm; nothing wasted.
- 2026-10-02: cooked chickpea-curry for 5 servings; pantry warm; nothing wasted.
- 2026-10-03: cooked cacio-e-pepe for 2 servings; pantry warm; nothing wasted.
- 2026-10-04: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-10-05: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-10-06: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-10-07: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.

### week 2

- 2026-10-08: cooked chickpea-curry for 5 servings; pantry warm; nothing wasted.
- 2026-10-09: cooked cacio-e-pepe for 2 servings; pantry warm; nothing wasted.
- 2026-10-10: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-10-11: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-10-12: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-10-13: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.
- 2026-10-14: cooked lentil-stew for 3 servings; pantry warm; nothing wasted.

### week 3

- 2026-10-15: cooked cacio-e-pepe for 2 servings; pantry warm; nothing wasted.
- 2026-10-16: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-10-17: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-10-18: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-10-19: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.
- 2026-10-20: cooked lentil-stew for 3 servings; pantry warm; nothing wasted.
- 2026-10-21: cooked chickpea-curry for 4 servings; pantry warm; nothing wasted.

### week 4

- 2026-10-22: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-10-23: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-10-24: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-10-25: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.
- 2026-10-26: cooked lentil-stew for 3 servings; pantry warm; nothing wasted.
- 2026-10-27: cooked chickpea-curry for 4 servings; pantry warm; nothing wasted.
- 2026-10-28: cooked cacio-e-pepe for 5 servings; pantry warm; nothing wasted.

### Notes for 2026-10

- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.

## 2026-11


### week 1

- 2026-11-01: cooked lentil-stew for 4 servings; pantry warm; nothing wasted.
- 2026-11-02: cooked chickpea-curry for 5 servings; pantry warm; nothing wasted.
- 2026-11-03: cooked cacio-e-pepe for 2 servings; pantry warm; nothing wasted.
- 2026-11-04: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-11-05: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-11-06: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-11-07: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.

### week 2

- 2026-11-08: cooked chickpea-curry for 5 servings; pantry warm; nothing wasted.
- 2026-11-09: cooked cacio-e-pepe for 2 servings; pantry warm; nothing wasted.
- 2026-11-10: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-11-11: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-11-12: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-11-13: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.
- 2026-11-14: cooked lentil-stew for 3 servings; pantry warm; nothing wasted.

### week 3

- 2026-11-15: cooked cacio-e-pepe for 2 servings; pantry warm; nothing wasted.
- 2026-11-16: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-11-17: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-11-18: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-11-19: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.
- 2026-11-20: cooked lentil-stew for 3 servings; pantry warm; nothing wasted.
- 2026-11-21: cooked chickpea-curry for 4 servings; pantry warm; nothing wasted.

### week 4

- 2026-11-22: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-11-23: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-11-24: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-11-25: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.
- 2026-11-26: cooked lentil-stew for 3 servings; pantry warm; nothing wasted.
- 2026-11-27: cooked chickpea-curry for 4 servings; pantry warm; nothing wasted.
- 2026-11-28: cooked cacio-e-pepe for 5 servings; pantry warm; nothing wasted.

### Notes for 2026-11

- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.

## 2026-12


### week 1

- 2026-12-01: cooked lentil-stew for 4 servings; pantry warm; nothing wasted.
- 2026-12-02: cooked chickpea-curry for 5 servings; pantry warm; nothing wasted.
- 2026-12-03: cooked cacio-e-pepe for 2 servings; pantry warm; nothing wasted.
- 2026-12-04: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-12-05: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-12-06: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-12-07: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.

### week 2

- 2026-12-08: cooked chickpea-curry for 5 servings; pantry warm; nothing wasted.
- 2026-12-09: cooked cacio-e-pepe for 2 servings; pantry warm; nothing wasted.
- 2026-12-10: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-12-11: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-12-12: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-12-13: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.
- 2026-12-14: cooked lentil-stew for 3 servings; pantry warm; nothing wasted.

### week 3

- 2026-12-15: cooked cacio-e-pepe for 2 servings; pantry warm; nothing wasted.
- 2026-12-16: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-12-17: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-12-18: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-12-19: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.
- 2026-12-20: cooked lentil-stew for 3 servings; pantry warm; nothing wasted.
- 2026-12-21: cooked chickpea-curry for 4 servings; pantry warm; nothing wasted.

### week 4

- 2026-12-22: cooked tomato-soup for 3 servings; pantry warm; nothing wasted.
- 2026-12-23: cooked scrambled-eggs for 4 servings; pantry warm; nothing wasted.
- 2026-12-24: cooked minestrone for 5 servings; pantry warm; nothing wasted.
- 2026-12-25: cooked rice-bowl for 2 servings; pantry warm; nothing wasted.
- 2026-12-26: cooked lentil-stew for 3 servings; pantry warm; nothing wasted.
- 2026-12-27: cooked chickpea-curry for 4 servings; pantry warm; nothing wasted.
- 2026-12-28: cooked cacio-e-pepe for 5 servings; pantry warm; nothing wasted.

### Notes for 2026-12

- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
- A note from the cook about something that happened with an ingredient or the meal: how it tasted, what surprised us, who joined for dinner, what the kids thought. Lessons for next time.
