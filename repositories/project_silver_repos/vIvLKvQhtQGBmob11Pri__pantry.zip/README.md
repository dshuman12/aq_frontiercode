# Pantry

> Ingredient inventory and meal-planning service for small foodservice operations.

Pantry is a self-hosted, single-binary inventory tool for kitchens that
need to track ingredient lots, expiry windows, and recipe demand without
running a full ERP. It targets small commercial kitchens, catering
operations, ghost-kitchen units, and onsite-meal programs that have
outgrown a spreadsheet but do not have, or want, a SaaS subscription.

The service is shipped as a single OCI image, has no runtime dependency
on a database engine, and stores its data as plain JSON files on a
single bind-mount. It is operable by one person.

[![CI](https://img.shields.io/badge/CI-passing-success)]()
[![License](https://img.shields.io/badge/license-Apache--2.0-blue)](LICENSE)
[![Node](https://img.shields.io/badge/node-%E2%89%A520.16-339933)](.nvmrc)
[![Coverage](https://img.shields.io/badge/coverage-87%25-brightgreen)]()

---

## Table of contents

- [Why pantry](#why-pantry)
- [What's in the box](#whats-in-the-box)
- [Quick start](#quick-start)
- [Production deployment](#production-deployment)
- [Configuration](#configuration)
- [Operational runbook](#operational-runbook)
- [Backup, restore, replication](#backup-restore-replication)
- [Observability](#observability)
- [Security](#security)
- [Compatibility and support window](#compatibility-and-support-window)
- [Contributing](#contributing)
- [License](#license)

---

## Why pantry

Most inventory tools land in one of two camps:

1. **Spreadsheet-shaped.** A shared Google Sheet, a stack of clipboards, or
   a long-running Notion page. Cheap, but breaks down past ~50 SKUs and
   has no concept of expiry, lot, or recipe demand.
2. **SaaS ERP.** A monthly subscription to a multi-tenant inventory
   product. Reliable, but expensive at small scale, requires an internet
   connection to function, and forces the operation into a vendor's data
   model.

Pantry occupies the gap between them. It runs on a single Linux host
(usually the same machine that runs the kitchen's POS, label printer,
or back-office laptop), serves a CLI and a small read-only LAN web UI,
and persists every record as a JSON file under a single data directory.

It can survive being copied with `rsync`, restored from a USB stick,
and audited by a non-developer.

## What's in the box

- A single binary CLI (`pantry`) with ~35 subcommands covering items,
  lots, recipes, meal plans, shopping lists, waste reports, and exports.
- An optional small HTTP server (`pantry serve`) that renders a
  read-only LAN dashboard for staff who do not use the terminal.
- An importer suite for receipts (CSV) and historical exports (JSONL).
- An exporter suite (Markdown, CSV, HTML, YAML, iCal, OPML).
- Multi-household / multi-site partitioning at the data-directory level.
- A change-log event stream that supports point-in-time replay for audit
  and debugging.

## Quick start

### Local install (development)

```bash
git clone https://github.com/pantry-tools/pantry.git
cd pantry
npm ci
npm run build
node dist/main.js --version
```

### Container

```bash
docker pull ghcr.io/pantry-tools/pantry:0.4
docker run --rm \
  -v "$PWD/pantry-data:/data" \
  ghcr.io/pantry-tools/pantry:0.4 list
```

The bind-mounted directory holds every record the tool produces.
There is no implicit cache outside of it.

## Production deployment

Pantry is intentionally small enough to be deployed by hand on a single
host, but the recommended pattern for sites running multiple shifts is:

1. **Host:** a single Linux host (Debian 12, RHEL 9, or Alpine 3.20+)
   with at least 1 GiB RAM and 5 GiB free under the data directory.
2. **Process supervisor:** systemd. A unit file is shipped under
   [`deploy/systemd/pantry.service`](deploy/systemd/pantry.service).
3. **Storage:** a dedicated ext4 filesystem, mounted at `/var/lib/pantry`,
   bind-mounted into the container as `/data`. Snapshot via LVM or
   filesystem-level snapshots; do not snapshot mid-write without a
   `pantry snapshot` first.
4. **Reverse proxy:** the web dashboard is HTTP-only by design. Front it
   with nginx or Caddy and terminate TLS at the proxy. See
   [`deploy/nginx/pantry.conf`](deploy/nginx/pantry.conf).

A reference Compose file is provided at
[`deploy/compose/docker-compose.yml`](deploy/compose/docker-compose.yml).

## Configuration

All configuration is driven by environment variables. There is no
configuration file format - this keeps the deployment surface flat and
makes secrets management straightforward.

| Variable              | Default                | Purpose                                       |
| --------------------- | ---------------------- | --------------------------------------------- |
| `PANTRY_DATA_DIR`     | `~/.local/share/pantry`| Root of the on-disk store.                    |
| `PANTRY_CONFIG_DIR`   | `~/.config/pantry`     | User config (aliases, density tables).        |
| `PANTRY_CACHE_DIR`    | `~/.cache/pantry`      | Idempotent caches; safe to wipe.              |
| `PANTRY_LOG_FORMAT`   | `text`                 | `text` or `json` (structured log output).     |
| `PANTRY_LOG_LEVEL`    | `info`                 | `debug`, `info`, `warn`, `error`.             |
| `PANTRY_HTTP_BIND`    | `127.0.0.1:8732`       | Bind address for `pantry serve`.              |
| `PANTRY_METRICS_BIND` | _unset_                | If set, exposes Prometheus metrics here.      |
| `PANTRY_HOUSEHOLD`    | _unset_                | Per-site partition; selects a sub-directory.  |
| `TZ`                  | `UTC`                  | Time zone used in renders and reports.        |

Validate the active configuration with:

```bash
pantry config check
```

This walks every variable, verifies parse-ability and filesystem
permissions, and exits non-zero on the first failure.

## Operational runbook

Common operational scenarios are documented in
[`docs/operations.md`](docs/operations.md). Highlights:

- **Healthcheck:** `pantry healthcheck` exits 0 if the data dir is
  readable, the schema version matches, and no lockfile is held longer
  than the configured threshold. Suitable for `livenessProbe` and
  systemd `WatchdogSec=`.
- **Schema migration:** `pantry migrate` walks the on-disk store and
  upgrades records to the latest schema. Idempotent.
- **Disaster recovery:** restore from a snapshot tarball with
  `pantry restore <archive>`. See
  [`docs/operations.md#disaster-recovery`](docs/operations.md#disaster-recovery).

## Backup, restore, replication

Every record is a JSON file under the data directory; the directory
itself is the backup unit.

- **Snapshot:** `pantry snapshot --out backup-YYYYMMDD.tar` produces a
  consistent point-in-time tarball without taking the service offline.
- **Replication:** `pantry replicate --to user@host:/path` rsyncs the
  data dir to a peer with a quiesce + post-sync notification step.
- **Restore:** `pantry restore backup-YYYYMMDD.tar` validates the
  archive's manifest before extracting; an aborted restore leaves the
  current data dir untouched.

## Observability

Pantry is built to be operable by a single on-call engineer.

- **Logs:** structured JSON logs on stderr when `PANTRY_LOG_FORMAT=json`.
  Suitable for ingest into Loki, ELK, or any line-oriented log shipper.
- **Metrics:** Prometheus-format metrics at `/metrics` when
  `PANTRY_METRICS_BIND` is set. Exposes `pantry_records_total`,
  `pantry_lock_wait_seconds`, `pantry_snapshot_age_seconds`,
  `pantry_schema_version`, and `pantry_last_replicate_unix`.
- **Tracing:** disabled by default. Set `PANTRY_OTEL_ENDPOINT` to enable
  OTLP/HTTP export of CLI command spans.

A reference Grafana dashboard JSON ships at
[`deploy/grafana/pantry.json`](deploy/grafana/pantry.json).

## Security

- All container images are built `FROM node:20.16.0-alpine3.20` with
  pinned apk versions; the runtime user is non-root (uid 1100).
- No runtime npm dependencies are pulled - the compiled `dist/` ships
  as-is. The dependency surface is `node:*` standard library only.
- Reports of suspected vulnerabilities should follow the process in
  [`SECURITY.md`](SECURITY.md). Please do not open public issues for
  security reports.

The CI pipeline runs `npm audit` (build-time deps), Trivy against the
container image, and CodeQL against the TypeScript source. See
[`.github/workflows/`](.github/workflows/).

## Compatibility and support window

| Pantry version | Status      | Node minimum | Maintained until |
| -------------- | ----------- | ------------ | ---------------- |
| 0.4.x          | Current     | 20.16        | 2027-05-01       |
| 0.3.x          | Maintenance | 20.10        | 2026-11-01       |
| 0.2.x          | EOL         | 18.18        | _(ended)_        |

Patch releases are cut when a CVE in a build-time dependency or in the
base image is disclosed. Minor releases are cut quarterly.

## Contributing

See [`CONTRIBUTING.md`](CONTRIBUTING.md) for the development setup,
test policy, and PR review checklist. New contributors should also read
[`CODE_OF_CONDUCT.md`](CODE_OF_CONDUCT.md).

For questions that are not bug reports, prefer
[GitHub Discussions](https://github.com/pantry-tools/pantry/discussions)
over the issue tracker.

## License

Apache License 2.0. See [`LICENSE`](LICENSE) and [`NOTICE`](NOTICE).
