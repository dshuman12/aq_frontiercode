<!--
Thanks for contributing to pantry. Please fill out this template so the
reviewers can move quickly.
-->

## Summary

<!-- 1-3 sentences describing the change and the user-visible effect. -->

## Motivation

<!-- Link to the issue or discussion this PR resolves. If there is no
prior discussion, briefly explain why this change is worth making. -->

Refs: #

## Type of change

- [ ] Bug fix (non-breaking change which fixes an issue)
- [ ] New feature (non-breaking change which adds functionality)
- [ ] Breaking change (fix or feature that would cause existing
      behavior to change)
- [ ] Documentation update
- [ ] Internal refactor / build / CI

## Checklist

- [ ] My code follows the project style (`npm run lint` passes).
- [ ] I have added tests that cover the new behavior, including at
      least one failure path where applicable.
- [ ] I have updated `CHANGELOG.md` under `[Unreleased]` if this PR
      changes user-visible behavior.
- [ ] If this PR changes the on-disk schema, I have added a migration
      step in `src/core/migrate.ts` and bumped `schemaVersion`.
- [ ] If this PR changes a CLI flag or environment variable, I have
      updated `README.md` and `docs/`.

## Additional notes

<!-- Anything reviewers should focus on, screenshots of CLI output,
benchmark numbers, deployment caveats, etc. -->
