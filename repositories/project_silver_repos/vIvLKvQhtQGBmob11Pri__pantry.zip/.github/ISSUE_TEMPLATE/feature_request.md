---
name: Feature request
about: Propose a new feature or enhancement
title: "feat: <one-line summary>"
labels: ["enhancement", "needs-triage"]
assignees: []
---

## Problem

<!-- What problem are you trying to solve? Who has it, and how often? -->

## Proposed solution

<!-- Describe the change you would like. CLI surface, env var, on-disk
schema impact, etc. -->

## Alternatives considered

<!-- Other approaches you considered and why you rejected them. -->

## Impact

- Affected subcommand(s):
- Breaks existing behavior? (yes / no)
- Requires a schema migration? (yes / no)
- Requires a new dependency? (yes / no - new runtime deps are unlikely
  to be accepted)

## Additional context

<!-- Mockups, prior-art links, related issues. -->

## Checklist

- [ ] I have searched existing issues and discussions for duplicates.
- [ ] I have read `CONTRIBUTING.md` and understand the "small on
      purpose" policy.
