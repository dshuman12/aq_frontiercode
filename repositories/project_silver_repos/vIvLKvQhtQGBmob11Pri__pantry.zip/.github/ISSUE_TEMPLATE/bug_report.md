---
name: Bug report
about: Report a defect in pantry
title: "bug: <one-line summary>"
labels: ["bug", "needs-triage"]
assignees: []
---

## Summary

<!-- One or two sentences describing the bug. -->

## Environment

- pantry version (`pantry --version`):
- Node.js version (`node -v`):
- Operating system / distribution:
- Deployment shape (host CLI, container, systemd, compose, ...):

## Reproduction

<!-- The smallest set of commands / fixture data we need to reproduce. -->

```bash
pantry ...
```

## Expected behavior

<!-- What should have happened. -->

## Actual behavior

<!-- What actually happened. Include the error message verbatim. -->

```
<paste here>
```

## Logs

<!-- Run with PANTRY_LOG_LEVEL=debug PANTRY_LOG_FORMAT=json and paste
the relevant lines. Redact anything operationally sensitive. -->

<details>
<summary>debug log</summary>

```
<paste here>
```

</details>

## Additional context

<!-- Anything else: recent upgrades, related issues, workarounds. -->

## Checklist

- [ ] I have searched existing issues for duplicates.
- [ ] I am running a supported version (see `SECURITY.md`).
- [ ] I can reproduce this against a clean data directory.
