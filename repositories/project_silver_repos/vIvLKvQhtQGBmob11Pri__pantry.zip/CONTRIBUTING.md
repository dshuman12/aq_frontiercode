# Contributing to pantry

Thanks for your interest. This document describes how to set up a local
development environment, the test policy, and the review checklist that
the maintainers apply to pull requests.

## Ground rules

- Pantry is small on purpose. We say no to features more often than yes.
  If your change adds a new subcommand, please open a discussion first.
- Runtime code must depend only on the Node.js standard library.
  Build-time and test-time dependencies are limited to TypeScript and
  `@types/node`. New dependencies require maintainer sign-off.
- Every public function must have a paired test in `*.test.ts`. We
  measure coverage but do not enforce a hard floor; reviewers will
  flag uncovered branches that look load-bearing.

## Local setup

```bash
git clone https://github.com/pantry-tools/pantry.git
cd pantry
npm ci
npm run build
npm test
```

Required toolchain:

- Node.js >= 20.16.0 (we test against 20.16 and 22.x in CI).
- TypeScript 5.6.3 (pinned in `package.json`).
- A Linux-flavored shell. macOS works for development; Windows is not
  tested.

## Branching model

- `main` is the integration branch. CI must be green before merge.
- Release branches are cut from `main` as `release/0.4.x` and receive
  cherry-picked patches only.
- Feature branches should be named `<area>/<short-slug>`, e.g.
  `importers/csv-multiline-quotes`.

## Commit message style

We use a lightweight, area-prefixed convention:

```
<area>: <imperative summary>

<body, optional, wrapped at 72 cols>

Refs: #<issue>
```

Examples:

```
importers/csv: support multiline quoted fields
core/store: fix race in atomic-rename on tmpfs
docs/operations: document the snapshot quiesce procedure
```

Avoid `wip`, `fix stuff`, or messages without a subject area.

## Tests

- Unit tests live next to the code, named `<file>.test.ts`. They are
  compiled with the rest of the project and executed via the Node test
  runner.
- Importer / exporter round-trip tests live in `src/importers/` and
  `src/exporters/`. They use fixture files committed under
  `fixtures/` and must not write outside `/tmp`.
- Every PR runs the full `npm test` suite in CI under both the minimum
  and current Node minor.

Run a single test file locally:

```bash
node --test --test-reporter spec dist/core/units.test.js
```

## Reviewing PRs

Reviewers check:

1. Tests cover the new behavior, including at least one failure path.
2. Public API changes (CLI flags, env vars, on-disk schema) are
   documented in `CHANGELOG.md` and, for schema changes, ship with a
   migration step in `src/core/migrate.ts`.
3. No new runtime dependencies. No new build-time dependencies without
   discussion.
4. The diff is the smallest one that solves the problem.
5. Commit messages are area-prefixed and intelligible in `git log`.

## Reporting bugs

Use the bug report template under `.github/ISSUE_TEMPLATE/`. Include
the pantry version (`pantry --version`), Node version, OS, and a
minimal reproduction. Attach a sanitized data dir snippet only if
needed and free of operationally sensitive information.

## Code of conduct

Participation in the project is governed by
[`CODE_OF_CONDUCT.md`](CODE_OF_CONDUCT.md).
