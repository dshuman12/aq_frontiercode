# Security policy

## Supported versions

| Version | Supported | Notes                                  |
| ------- | --------- | -------------------------------------- |
| 0.4.x   | Yes       | Current release line.                  |
| 0.3.x   | Yes       | Maintenance only; security fixes only. |
| 0.2.x   | No        | End-of-life as of 2025-12-01.          |
| < 0.2   | No        | Pre-release; do not deploy.            |

A version is "supported" if it will receive a patch release for a
security advisory rated High or Critical (CVSS v3.1 >= 7.0). Lower
severity issues are batched into the next minor release.

## Reporting a vulnerability

**Please do not open a public GitHub issue.** Coordinated disclosure is
strongly preferred.

Send a report to **security@pantry-tools.example**. Encrypt with the
maintainers' GPG key (fingerprint published at
`/.well-known/security.txt` on the project website).

A report should include, where possible:

- Affected pantry version(s) and deployment shape (CLI, container,
  systemd, etc.).
- A minimal reproduction (commands, fixture data, or a small patch).
- Your assessment of impact (data loss, privilege escalation, RCE,
  denial of service).
- Whether you intend to publish, and a target disclosure date.

## What to expect

| Step                                  | Target                |
| ------------------------------------- | --------------------- |
| Acknowledgement of receipt            | within 2 business days |
| Triage (confirmed / not-an-issue)     | within 5 business days |
| Patch landed in main + backports      | within 14 days         |
| Coordinated public disclosure         | with reporter consent  |

We will credit reporters in the release notes unless they request
otherwise. We do not currently operate a paid bug-bounty program.

## Out of scope

- Self-XSS in the read-only LAN dashboard when accessed by a
  privileged operator on `127.0.0.1`. Pantry's threat model assumes a
  trusted operator on a trusted host; do not expose the HTTP server to
  the public internet.
- Denial of service via resource exhaustion when the operator
  intentionally feeds large fixtures (`pantry import bigfile.csv`).
- Issues that require physical access to the data directory.
- Bugs in third-party rsync, systemd, Docker, or kernel components.

## Threat model

- **Trust boundary:** the data directory and the host filesystem.
  Everything inside the boundary is trusted; everything outside is not.
- **Inputs:** CSV/JSONL imports, HTTP requests to the LAN dashboard,
  CLI flags. All are validated at the boundary.
- **Outputs:** JSON files (atomic rename), HTTP responses (read-only),
  log lines (structured, no PII by default).
- **Secrets:** none in the data dir. The optional `PANTRY_OTEL_ENDPOINT`
  environment variable may carry a token; it is never logged.

## Cryptographic assumptions

Pantry does not implement any cryptographic primitive. Snapshots are
plain tarballs; if an operator needs at-rest encryption they should use
LUKS, eCryptfs, or filesystem-level encryption underneath the data dir.
