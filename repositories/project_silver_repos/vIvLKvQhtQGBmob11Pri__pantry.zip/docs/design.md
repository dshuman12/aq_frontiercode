# Design notes

This document records the architectural decisions that shape pantry,
along with the trade-offs the maintainers accepted in each case. It is
intended as background reading for new contributors and reviewers.

## Why JSON-file-per-record instead of SQLite

The first prototype used `better-sqlite3` and was abandoned within
weeks. The two specific failure modes that drove the rewrite were:

1. **Concurrent access from background jobs.** Operators commonly run
   `pantry snapshot` and `pantry replicate` from cron while staff are
   issuing `pantry add` from a terminal. SQLite's write lock surfaced
   as occasional `SQLITE_BUSY` errors that were difficult to surface
   gracefully through the CLI.
2. **`rsync` of a SQLite file mid-write is unsafe.** Per-record JSON
   files survive an interrupted copy: the result is a slightly smaller
   library, not a corrupt database.

The cost is that `pantry list` re-reads every file. For a typical
deployment (a few hundred items, a few thousand lots) this completes
in under 100 ms on commodity hardware, which is well within the
project's latency budget.

## Why no runtime npm dependencies

Runtime code depends only on the Node.js standard library. Build-time
dependencies are limited to TypeScript and `@types/node`, both pinned
exactly. The container image runs the compiled `dist/` directly with no
`npm install` step at runtime.

The cost is that pantry re-implements a small CSV parser, a flag
parser, and an ANSI-color helper. Each is intentionally small and is
fully covered by unit tests.

This policy is enforced socially via the contributor guide; new runtime
dependencies require maintainer sign-off.

## Why the import-side-effect dispatch registry

Subcommand modules call `register()` from import side-effects, and
`main.ts` lists each module with `import "./cli/commands/foo.js"`.
Adding a subcommand is one new file plus one import line; there is no
central dispatch table to keep in sync, and removing a subcommand is a
single deletion.

The trade-off is that test isolation needs `dispatch.reset()` between
test files; this is well-encapsulated and has not caused friction in
practice.

## Why two distinct stores (items vs recipes)

Recipes change slowly: an operator edits one occasionally and then
leaves it untouched for months. Items churn continuously as lots are
added and consumed. Splitting them into separate directories keeps the
items directory uncluttered and lets recipe edits adopt a different
lifecycle, including the option to `git`-version the recipe directory
in isolation.

## Why hundreds of canonical slugs are hard-coded in `categories.ts`

Free-form ingredient names are notoriously unreliable to auto-categorize.
A small static table of canonical slugs gives `pantry add "Olive Oil"`
a deterministic way to land in `oils` without resorting to fuzzy or
machine-learned classification, both of which are difficult to debug
when they misfire.

## Areas the maintainers expect to revisit

- The CSV parser does not yet support multiline quoted fields. Real-world
  receipts occasionally include them; the importer rejects such rows
  rather than misparsing them.
- The HTML dashboard is server-rendered with no JavaScript. A minimal
  client-side filter would improve usability for staff with large
  inventories; the constraint is that the project ships no client-side
  build pipeline today.
- The meal-plan format is editable by hand but does not have a
  dedicated editor subcommand. `pantry plan edit` is on the roadmap.
