# Papa Rellena

A long-form notes file for Papa Rellena, accumulated from multiple cookings.

## Overview

Papa Rellena has earned a permanent spot in the rotation. The first few times
I followed the source recipe to the letter; over months the dish has
quietly converged to a personal version that I find more reliable.

## Origin

The recipe came from a cookbook borrowed from the library years ago. I
copied the bones into the pantry app on a Saturday morning and added the
adjustments below over the following months.

## My adjustments

1. Salt the aromatics earlier than the recipe suggests. They soften faster
   and absorb the flavors more deeply.
2. Use slightly more papa rellena than the recipe calls for.
   The dish wants the depth and never goes overboard at +25%.
3. Add a finishing acid - a teaspoon of lemon juice or a splash of
   vinegar at the very end. The brightness lifts everything else.

## What goes wrong

- Too high a heat collapses the texture; keep it at a lazy simmer.
- Adding the wet ingredients too early makes the aromatics steam instead
  of caramelise. Pause until they're properly golden.
- Skipping the resting time at the end leaves the dish thin. Five minutes
  off the heat is non-negotiable.

## Substitutions that worked

- ingredient A: works in a pinch.
- ingredient B: better than original, surprisingly.
- ingredient C: noticeably worse - skip.

## Pairings

This goes with crusty bread, a glass of unoaked white, or for a more
casual evening just sparkling water with a wedge of lime. A simple side
salad works; anything more elaborate fights for attention.

## Storage

Keeps for ~3 days in the fridge in a glass container. The flavor improves
slightly on day 2 and starts to degrade by day 4. Freezing works but the
texture suffers; I'd rather make a fresh batch than thaw an old one.

## When I make it most

Sundays in shoulder seasons - too cool for cold food, not so cold I want
something heavier. Also the kind of weeknight where I have a little extra
time and want a meal that smells good while it cooks.

## Related ideas

- A version with ingredient X swapped in is on my list to try.
- A weekend doubling-up batch fits in the big pot if I scale carefully.
- A summer riff on this with cold pasta is intriguing but unrelated.

## Notes from specific cookings

### April Saturday
First batch I really nailed. Reduced the salt by 10%, leaned harder on
the herb at the end, and let it rest 7 minutes instead of 5. Best version
to date.

### March weeknight
Rushed through the prep. The texture was a bit muddy and the flavors
hadn't fully integrated. Lesson: don't rush this one.

### A pair of guests
Doubled the batch for company. Worked fine in the bigger pot. Increased
the herbs less than proportionally (about 1.5x rather than 2x) and that
felt right - more would have been too aggressive.
