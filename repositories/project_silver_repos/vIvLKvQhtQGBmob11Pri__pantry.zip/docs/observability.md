# Observability

Pantry is built to be operable by a single on-call engineer. The
observability surface is intentionally narrow: structured logs,
Prometheus metrics, and an explicit healthcheck. There is no built-in
APM, no profiling endpoint, and no debug dashboard.

## Logs

The structured logger (see `src/core/structured-log.ts`) emits one
line per log event to stderr. Two output formats are supported:

- `text` (default) -- human-readable, suitable for `journalctl` or
  ad-hoc tailing during development.
- `json` -- one JSON object per line, suitable for ingestion into
  Loki, ELK, Vector, or any line-oriented log shipper.

Switch formats with `PANTRY_LOG_FORMAT=json` and the level threshold
with `PANTRY_LOG_LEVEL=info|debug|warn|error`.

JSON record schema:

| Field   | Type    | Notes                                          |
| ------- | ------- | ---------------------------------------------- |
| `ts`    | string  | RFC 3339 / ISO 8601 timestamp in UTC.          |
| `level` | string  | One of `debug`, `info`, `warn`, `error`.       |
| `msg`   | string  | Human-readable message.                        |
| ...     | various | Additional structured fields per call site.    |

The logger does not emit PII by default. Importer modules redact
`barcode` and `customerNote` fields before they hit the log line.

## Metrics

The metrics registry (see `src/core/metrics.ts`) implements the two
metric families that the reference Grafana dashboard needs: counters
and gauges. Histograms and summaries are intentionally not supported.

Set `PANTRY_METRICS_BIND=host:port` to expose `/metrics` over HTTP.
The metrics endpoint is independent of the dashboard endpoint and
should be bound to a separate address.

### Exposed series

| Metric                       | Type    | Labels        | Notes                                       |
| ---------------------------- | ------- | ------------- | ------------------------------------------- |
| `pantry_items_total`         | gauge   |               | Distinct items currently tracked.           |
| `pantry_lots_total`          | gauge   |               | Lots across all items.                      |
| `pantry_recipes_total`       | gauge   |               | Stored recipes.                             |
| `pantry_records_total`       | counter |               | Records written to disk since startup.      |
| `pantry_imports_total`       | counter | `source`      | Records imported, by source (`csv`, `jsonl`). |
| `pantry_lock_wait_seconds`   | gauge   |               | Most recent advisory-lock wait time.        |
| `pantry_snapshot_age_seconds`| gauge   |               | Wall time of the most recent successful snapshot. |
| `pantry_schema_version`      | gauge   |               | On-disk schema version.                     |
| `pantry_build_info`          | gauge   | `version`     | Always 1; the version label is the payload. |
| `pantry_last_replicate_unix` | gauge   | `peer`        | Unix time of last successful replicate run. |

### Reference dashboard

`deploy/grafana/pantry.json` is a starter dashboard with four stat
panels (counts), two timeseries (writes and imports), and two
operational gauges (lock wait and snapshot age). Import via the
Grafana UI or provision through `grafana-provisioning`.

### Recommended alerts

```yaml
groups:
  - name: pantry
    rules:
      - alert: PantrySchemaMismatch
        expr: pantry_schema_version != 4
        for: 5m
        labels: { severity: critical }
        annotations:
          summary: "Pantry schema version drifted from expected (4)"

      - alert: PantrySnapshotStale
        expr: time() - pantry_snapshot_age_seconds > 36 * 3600
        for: 30m
        labels: { severity: warning }
        annotations:
          summary: "No successful snapshot in over 36 hours"

      - alert: PantryLockBacklog
        expr: pantry_lock_wait_seconds > 5
        for: 10m
        labels: { severity: warning }
        annotations:
          summary: "Sustained advisory-lock wait above 5s"

      - alert: PantryHealthcheckFailing
        expr: up{job="pantry"} == 0
        for: 2m
        labels: { severity: critical }
        annotations:
          summary: "Pantry scrape target is down"
```

## Tracing

Distributed tracing is disabled by default. Set
`PANTRY_OTEL_ENDPOINT=https://otel.example.lan:4318/v1/traces` to
enable OTLP/HTTP export of CLI command spans. Spans are short-lived
and cheap to drop, so an unreachable collector does not block CLI
execution.

Tracing is most useful when correlating slow CLI invocations against
log entries -- the `trace_id` field is added to every JSON log line
emitted within an active span.
