# Deployment guide

Pantry is shipped as a single OCI image. There is no agent, no
sidecar, and no required external service. This document walks through
the three deployment shapes the project officially supports:

1. Single host with systemd (recommended for most operations).
2. Single host with docker-compose (recommended when an existing
   compose stack is already in place).
3. Kubernetes (supported but largely unnecessary at the scale pantry
   targets).

## Host requirements

| Resource           | Minimum   | Recommended | Notes                                  |
| ------------------ | --------- | ----------- | -------------------------------------- |
| OS                 | Linux     | Debian 12 / Alpine 3.20 / RHEL 9 | macOS works for development. |
| CPU                | 1 vCPU    | 2 vCPU      | Pantry is I/O-bound, not CPU-bound.    |
| RAM                | 256 MiB   | 512 MiB     | Set `MemoryMax=512M` in the systemd unit. |
| Disk under data dir| 1 GiB     | 5 GiB       | Per-record JSON stays small; snapshots add ~1.2x of the live dir. |
| Network            | LAN only  | LAN + outbound HTTPS for image pulls | Public exposure is not supported. |

## Single host with systemd

This is the canonical shape: one host, one systemd unit, one bind mount.

### 1. Create the service user and data directory

```bash
sudo useradd --system --no-create-home --home-dir /var/lib/pantry --shell /usr/sbin/nologin pantry
sudo install -d -o pantry -g pantry -m 0750 /var/lib/pantry /var/lib/pantry/data /var/lib/pantry/config /var/lib/pantry/cache
```

### 2. Install the binary

The release tarball ships the compiled `dist/` and a launcher script.

```bash
curl -fL -o pantry-0.4.0.tar.gz \
  https://github.com/pantry-tools/pantry/releases/download/v0.4.0/pantry-0.4.0-noarch.tar.gz
curl -fL -o pantry-0.4.0.tar.gz.sha256 \
  https://github.com/pantry-tools/pantry/releases/download/v0.4.0/pantry-0.4.0-noarch.tar.gz.sha256
sha256sum -c pantry-0.4.0.tar.gz.sha256
sudo tar -C /opt -xzf pantry-0.4.0.tar.gz
sudo ln -sfn /opt/pantry-0.4.0 /opt/pantry
sudo install -m 0755 /opt/pantry/bin/pantry /usr/local/bin/pantry
```

### 3. Install the systemd unit

```bash
sudo install -m 0644 deploy/systemd/pantry.service /etc/systemd/system/pantry.service
sudo systemctl daemon-reload
sudo systemctl enable --now pantry.service
sudo systemctl status pantry.service
```

### 4. Verify

```bash
pantry --version
sudo -u pantry pantry healthcheck --verbose
sudo -u pantry pantry config check
curl -s http://127.0.0.1:9732/metrics | head
```

## Single host with docker-compose

Use when you already run a compose stack (for example, you front
several internal tools with the same Caddy or Traefik instance).

```bash
git clone https://github.com/pantry-tools/pantry.git
cd pantry/deploy/compose
PANTRY_PUBLIC_HOST=pantry.example.lan docker compose up -d
docker compose logs -f pantry
```

The reference compose file expects a Caddyfile at `./Caddyfile`; copy
the one shipped under `deploy/compose/Caddyfile` and edit the host.

## Kubernetes

Pantry is not particularly well-suited to Kubernetes; its data model
assumes a single writer against a single PVC. If you nonetheless want
to run it in-cluster:

- Deploy as a `StatefulSet` with `replicas: 1` and a single PVC.
- Set the rolling-update strategy to `OnDelete` to avoid two pods
  ever holding the data dir at the same time.
- Use the dedicated `pantry healthcheck` command for both the
  `livenessProbe` and the `readinessProbe`.
- Scrape `/metrics` via a `PodMonitor` if you run the
  Prometheus Operator; otherwise an annotation-based scrape works.

A reference manifest is intentionally not shipped in-tree; this
deployment shape is rare enough that the project does not commit to
maintaining it.

## TLS termination

Pantry's HTTP server speaks plain HTTP and binds to `127.0.0.1` by
default. Always front it with a reverse proxy that terminates TLS:

- nginx fragment: `deploy/nginx/pantry.conf`.
- Caddyfile: `deploy/compose/Caddyfile`.

If you cannot front it with a proxy, do not expose the service to the
network at all. The threat model assumes a trusted operator on the
loopback interface.

## Backups

The shipping pattern is a daily `pantry snapshot` cron + a weekly
off-site sync. A reference cron entry:

```
# /etc/cron.d/pantry-snapshot
30 2 * * *  pantry  /usr/local/bin/pantry snapshot --out /var/backups/pantry/pantry-$(date +\%F).tar
0 3 * * 0   pantry  rsync -a /var/backups/pantry/ backups@offsite:/srv/backups/pantry/
```

Snapshots are tarballs; they are compressible but not deduplicable.
Allocate roughly one snapshot's worth of disk per retained day.
