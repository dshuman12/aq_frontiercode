# Install

Three supported install paths. For production deployments, prefer
the container image; the source build is documented for contributors
and for hosts where pulling an OCI image is impractical.

## From source

```
git clone https://github.com/pantry-tools/pantry.git
cd pantry
npm ci          # installs only typescript + @types/node
npm run build   # tsc -> dist/
npm test
sudo install -m 0755 dist/main.js /usr/local/bin/pantry
```

Requires Node 20.16 or newer.

## From the published container image

```
docker pull ghcr.io/pantry-tools/pantry:0.4.0
docker run --rm -v "$PWD/pantry-data:/data" \
  ghcr.io/pantry-tools/pantry:0.4.0 list
```

The image entrypoint executes `node /usr/local/lib/pantry/main.js`.
The `/data` mount holds the persistent on-disk store (data, config,
cache subdirectories).

## From the release tarball

```
curl -fL -o pantry-0.4.0.tar.gz \
  https://github.com/pantry-tools/pantry/releases/download/v0.4.0/pantry-0.4.0-noarch.tar.gz
curl -fL -o pantry-0.4.0.tar.gz.sha256 \
  https://github.com/pantry-tools/pantry/releases/download/v0.4.0/pantry-0.4.0-noarch.tar.gz.sha256
sha256sum -c pantry-0.4.0.tar.gz.sha256
sudo tar -C /opt -xzf pantry-0.4.0.tar.gz
sudo ln -sfn /opt/pantry-0.4.0 /opt/pantry
sudo install -m 0755 /opt/pantry/bin/pantry /usr/local/bin/pantry
```

For a full systemd-managed install, see
[`docs/deployment.md`](deployment.md#single-host-with-systemd).

## First run

```
pantry --version
pantry config check
pantry config show
pantry config set default_location pantry
pantry config set expiring_window_days 14
pantry add "Olive Oil" --qty 500ml --where pantry --best-by 2027-01-30
pantry expiring
```
