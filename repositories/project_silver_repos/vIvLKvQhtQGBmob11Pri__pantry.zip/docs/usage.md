# Usage cookbook

A reference for the most common day-to-day operations. Every command
also has a short description in `pantry --help`; this page collects
them in one place for new operators.

## Adding inventory

```
pantry add olive-oil --qty 500ml --where pantry --best-by 2027-01-30
pantry add "All Purpose Flour" --qty 2kg --where pantry --notes "King Arthur"
pantry add eggs --qty 12 --where fridge --best-by 2026-05-22
```

When the slug is omitted, the name is automatically sluggified
(`"Olive Oil"` -> `olive-oil`). Slugs are the stable identifier the
tool uses internally.

## Consuming inventory

```
pantry use olive-oil --qty 30ml
pantry use 17 --qty 100g
```

Quantities are subtracted from the oldest lot first. Lots that reach
zero are removed automatically; the underlying item record is
preserved for historical reporting.

## Importing a receipt

The CSV importer accepts any subset of the columns
`item,slug,qty,where,best_by,category,notes`.

```
pantry import-receipt fixtures/receipts/saturday-shop.csv
```

The importer logs structured events (`pantry_imports_total`) for
visibility into per-source throughput.

## What is expiring soon?

```
pantry expiring                    # default 7-day window
pantry expiring --within 14
```

The expiry report is the data source for the dashboard's "expiring
soon" panel and for the `expiry-window` Prometheus alert.

## From recipes to a shopping list

```
pantry shop minestrone bolognese
pantry shop --from 2026-04-15 --to 2026-04-21
```

The first form takes recipe slugs directly. The second computes the
shortfall against the meal plan written by `pantry plan add` for the
given date range.

## Reports

```
pantry dash                  # one-screen overview
pantry report waste --month 2026-04
pantry report frequent --from 2026-01-01 --to 2026-04-30
pantry report weekly --from 2026-04-01 --to 2026-04-30
```

Each report renders a fixed-width ASCII table; pipe through `less -S`
for wide outputs.

## Search

```
pantry search "category:dairy where:fridge"
pantry search "expiring:7"
pantry search "notes:'whole grain'"
```

The query language is intentionally small. See `src/core/query-builder.ts`
for the supported predicates.

## Backup and restore

```
pantry backup --out /var/backups/pantry-2026-04-15.json
pantry restore /var/backups/pantry-2026-04-15.json --into ./recovered
```

For full snapshots that include the configuration directory, prefer
`pantry snapshot` (see [`docs/operations.md`](operations.md#disaster-recovery)).

## Serving the LAN dashboard

```
pantry serve --addr 0.0.0.0:8088
```

The dashboard is read-only and emits no client-side JavaScript. It
ships without authentication; production deployments must front it
with a reverse proxy that handles TLS and any access control. See
[`deploy/nginx/pantry.conf`](../deploy/nginx/pantry.conf) for the
reference configuration.

## Healthcheck and metrics

```
pantry healthcheck                 # silent; exits 0 if healthy
pantry healthcheck --verbose       # one-line summary on stderr
pantry config check                # validate environment variables
pantry metrics                     # print Prometheus-format metrics
```

`pantry healthcheck` is intended for `livenessProbe` use; `pantry metrics`
backs the optional `/metrics` HTTP endpoint enabled by
`PANTRY_METRICS_BIND`.
