# Internal change log

A development-flavored log of what landed when. The user-facing
release notes live in the top-level [`CHANGELOG.md`](../CHANGELOG.md);
this file is retained for contributor archaeology.

## 2025-08
- Scaffolding: `package.json`, `tsconfig.json`, `package-lock.json`.
- CLI: stdlib-based dispatcher, flag parser, registry.

## 2025-09
- Units: quantity parsing and formatting.
- Paths: XDG-aware data / config / cache resolution.
- Item: `Item` and `Lot` types.

## 2025-10
- Store: per-item JSON files with atomic writes.
- `format/table`: ASCII column rendering.
- `format/color`: minimal ANSI helpers.
- Date math (UTC throughout).
- CLI: `list`, `show`.

## 2025-11
- CLI: `add`, `rm`, `use`.
- `main.ts` wires every subcommand via side-effect imports.

## 2025-12
- Recipe domain + per-recipe store.
- Shopping-list builder.
- Meal-plan persistence.

## 2026-01
- `expiring` report subcommand.

## 2026-02
- Importers: CSV parser, receipt importer, JSONL importer.

## 2026-03
- Exporters: Markdown, CSV, HTML.
- Search query language.

## 2026-04
- Reports: waste, frequent, weekly.
- Config domain.
- Event log.
- Archive (backup + restore).
- HTTP server (read-only LAN dashboard).
- Dashboard report.
- Fuzzy match + substitution suggestions.
- Healthcheck report.

## 2026-05
- Bulk CLI wirings and `main.ts`.
- Reports: alerts, prep, pricing, convert.
- Modules: index, diff, snapshot, meal-history.
- Reports: streaks, forecast, categories, tags.
- Reference fixture set (30+ recipes).
- Pure-Node Dockerfile.
- Production hygiene pass: README, LICENSE, CHANGELOG, SECURITY,
  CONTRIBUTING, CODEOWNERS, CODE_OF_CONDUCT, GitHub workflows
  (CI, CodeQL, container, release), dependabot, deploy artifacts
  (systemd, nginx, compose, Grafana), structured logger, metrics
  registry, config validator, healthcheck + metrics subcommands.
