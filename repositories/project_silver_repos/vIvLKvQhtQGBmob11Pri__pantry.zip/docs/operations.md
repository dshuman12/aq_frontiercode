# Operations runbook

This runbook covers the operational scenarios that come up most often
on a single-host pantry deployment. It is written for an on-call
engineer who already has shell access to the host and is familiar with
systemd or docker-compose.

## Healthcheck

`pantry healthcheck` is the canonical liveness probe. It exits 0 when
all of the following are true:

- The data directory exists, is a directory, and is readable + writable
  by the current user.
- No advisory lockfile is older than `--lock-max-age` seconds (default
  30s).

Use it in:

- systemd: `WatchdogSec=60` plus a periodic `ExecStartPre=` invocation.
- Kubernetes: `livenessProbe.exec.command: [/usr/local/bin/pantry, healthcheck]`.
- docker-compose: see `deploy/compose/docker-compose.yml`.

For an interactive sanity check, prefer `pantry health`, which reads
the store and prints a multi-line summary instead of returning an
exit code.

## Configuration validation

Always run `pantry config check` before starting the service in a new
environment. It walks every documented `PANTRY_*` variable and reports:

- `ERROR` -- the service will fail to start or behave incorrectly.
- `WARN`  -- the service will start but the operator should review.
- `INFO`  -- the variable is unset and the documented default applies.

The same validator is invoked by the `ExecStartPre=` hook in the
shipped systemd unit.

## Schema migration

The on-disk schema is versioned. On startup the service compares the
active code's `schemaVersion` to the value recorded in the data dir.
If they differ:

1. The service refuses to start.
2. Run `pantry migrate` to walk the store and rewrite records.
3. Migration is idempotent. Re-running on an already-migrated store
   exits 0 with no changes.

A migration that fails halfway through leaves the partially-migrated
records in place and exits non-zero. Fix the underlying issue, then
re-run; the migrator skips records already at the target version.

## Disaster recovery

The data dir is a single bind mount of plain JSON files. Recovery is
deliberately uncomplicated.

### From a snapshot tarball

```bash
sudo systemctl stop pantry
mv /var/lib/pantry/data /var/lib/pantry/data.broken.$(date +%s)
sudo -u pantry pantry restore /backups/pantry-2026-04-22.tar
sudo systemctl start pantry
sudo systemctl status pantry
```

`pantry restore` validates the archive's manifest before extracting;
an aborted restore leaves the data dir untouched.

### From a peer (replication)

If `pantry replicate --to peer:/var/lib/pantry/data` has been running
on a cron, the peer holds a lagging copy. Cut over with:

```bash
# On the peer, become primary:
sudo systemctl start pantry

# On the broken primary, after triage, re-seed from the new primary:
sudo -u pantry pantry replicate --from new-primary:/var/lib/pantry/data
```

Replication is one-way; ensure exactly one host is writing at a time.

## Stale lockfile

Symptom: `pantry healthcheck --verbose` reports `stale lockfile`, and
CLI invocations hang.

Cause: a previous invocation crashed without releasing the file-level
advisory lock (rare; only happens when a child process is `kill -9`'d
or the host loses power mid-write).

Procedure:

```bash
sudo systemctl stop pantry
sudo -u pantry pantry healthcheck --verbose --lock-max-age 0
# Confirm the lock is the only complaint, then:
sudo -u pantry rm /var/lib/pantry/data/.lock
sudo systemctl start pantry
```

Do not delete a lockfile while the service is running.

## Log volume

The structured JSON log emits one line per CLI invocation and one line
per HTTP request. For a small operation this is well under 100 KB/day.
For a busy site, set `PANTRY_LOG_LEVEL=warn` in the systemd unit to
suppress the per-request access lines while keeping warnings + errors.

A deployment that cannot tolerate log loss should ship logs off-host
with `journalctl -u pantry -o json` or rely on the docker-compose
`json-file` driver's rotation.

## Upgrades

Patch releases (0.4.x -> 0.4.y) are drop-in. Pull the new image, restart
the service, confirm `pantry healthcheck` exits 0.

Minor releases (0.4.x -> 0.5.0) may carry a schema migration. The
release notes will say so explicitly. Procedure:

```bash
sudo systemctl stop pantry
docker pull ghcr.io/pantry-tools/pantry:0.5.0
# Tag the previous image for rollback:
docker tag ghcr.io/pantry-tools/pantry:0.4.5 ghcr.io/pantry-tools/pantry:rollback
sudo -u pantry pantry migrate
sudo systemctl start pantry
sudo systemctl status pantry
sudo -u pantry pantry healthcheck --verbose
```

If migration fails, restore the rollback image and the data dir from a
pre-upgrade snapshot.

## On-call cheat sheet

| Symptom                                  | First action                                   |
| ---------------------------------------- | ---------------------------------------------- |
| Service fails to start                   | `journalctl -u pantry -n 200`                  |
| Service is up but `healthcheck` fails    | `pantry healthcheck --verbose`                 |
| 5xx from the dashboard                   | `journalctl -u pantry --since "10 min ago"`    |
| `migration required` log line on start   | `pantry migrate`                               |
| Disk filling up                          | `du -sh /var/lib/pantry/data /var/lib/pantry/cache` |
| Snapshot job alerting `snapshot_age`     | `pantry snapshot --out /backups/$(date +%F).tar` |
