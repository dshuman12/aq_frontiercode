// Export the pantry as an OPML outline (plays well with outliners).

import type { Item } from "../core/item.js";

function escape(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

export function render(items: Item[]): string {
  const byCat = new Map<string, Item[]>();
  for (const item of items) {
    const cat = item.category ?? "(none)";
    if (!byCat.has(cat)) byCat.set(cat, []);
    byCat.get(cat)!.push(item);
  }
  const lines: string[] = [];
  lines.push('<?xml version="1.0" encoding="UTF-8"?>');
  lines.push('<opml version="2.0">');
  lines.push("  <head><title>pantry</title></head>");
  lines.push("  <body>");
  for (const [cat, list] of [...byCat.entries()].sort()) {
    lines.push(`    <outline text="${escape(cat)}">`);
    for (const item of list.sort((a, b) => a.slug.localeCompare(b.slug))) {
      lines.push(`      <outline text="${escape(item.slug)}" _note="${escape(item.name)}">`);
      for (const lot of item.lots) {
        const bb = lot.bestBy ? ` (best by ${lot.bestBy})` : "";
        lines.push(`        <outline text="${escape(`#${lot.id} - ${lot.qty.value} ${lot.qty.kind} in ${lot.where}${bb}`)}"/>`);
      }
      lines.push(`      </outline>`);
    }
    lines.push(`    </outline>`);
  }
  lines.push("  </body>");
  lines.push("</opml>");
  return lines.join("\n") + "\n";
}

export function summary(items: Item[]): string {
  return `${items.length} items, ${items.reduce((a, i) => a + i.lots.length, 0)} lots`;
}
