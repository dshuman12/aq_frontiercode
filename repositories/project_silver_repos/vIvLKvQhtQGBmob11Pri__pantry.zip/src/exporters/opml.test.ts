import { test } from "node:test";
import assert from "node:assert/strict";
import { render, summary } from "./opml.js";
import type { Item } from "../core/item.js";

const today = "2026-04-15";

const sample: Item[] = [
  {
    id: 1, slug: "olive-oil", name: "Olive Oil", category: "oils",
    lots: [{
      id: 1, qty: { value: 500, kind: "volume" }, addedAt: today, where: "pantry",
      bestBy: "2027-01-30",
    }],
    createdAt: today, updatedAt: today,
  },
];

test("renders document skeleton", () => {
  const out = render(sample);
  assert.match(out, /<\?xml version="1.0"/);
  assert.match(out, /<opml version="2.0">/);
});

test("groups by category", () => {
  const out = render(sample);
  assert.match(out, /text="oils"/);
});

test("includes lot lines", () => {
  const out = render(sample);
  assert.match(out, /best by 2027-01-30/);
});

test("escapes special characters", () => {
  const items: Item[] = [{
    id: 1, slug: "x", name: "<bad>", lots: [],
    createdAt: today, updatedAt: today,
  }];
  const out = render(items);
  assert.equal(out.includes("<bad>"), false);
  assert.match(out, /&lt;bad&gt;/);
});

test("summary string", () => {
  assert.match(summary(sample), /1 items/);
});

test("empty input still produces a valid OPML", () => {
  const out = render([]);
  assert.match(out, /<opml/);
  assert.match(out, /<\/opml>/);
});

test("(none) category for items without category", () => {
  const items: Item[] = [{
    id: 1, slug: "x", name: "X", lots: [],
    createdAt: today, updatedAt: today,
  }];
  const out = render(items);
  assert.match(out, /\(none\)/);
});
