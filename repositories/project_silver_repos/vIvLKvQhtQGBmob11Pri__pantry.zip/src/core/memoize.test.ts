import { test } from "node:test";
import assert from "node:assert/strict";
import { memoize, memoizeWithTTL } from "./memoize.js";

test("memoize caches results", () => {
  let calls = 0;
  const fn = memoize((k: string) => { calls++; return k.toUpperCase(); });
  assert.equal(fn("a"), "A");
  assert.equal(fn("a"), "A");
  assert.equal(calls, 1);
});

test("memoize different keys", () => {
  let calls = 0;
  const fn = memoize((k: string) => { calls++; return k; });
  fn("a"); fn("b"); fn("a");
  assert.equal(calls, 2);
});

test("memoizeWithTTL respects expiry", async () => {
  let calls = 0;
  const fn = memoizeWithTTL((k: string) => { calls++; return k; }, 30);
  fn("a"); fn("a");
  assert.equal(calls, 1);
  await new Promise((r) => setTimeout(r, 50));
  fn("a");
  assert.equal(calls, 2);
});

test("memoizeWithTTL rejects non-positive TTL", () => {
  assert.throws(() => memoizeWithTTL((k) => k, 0));
});
