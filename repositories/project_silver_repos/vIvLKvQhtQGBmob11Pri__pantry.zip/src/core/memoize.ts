// Tiny memoize helper. Caches result of fn(arg) where arg is a string.

export function memoize<T>(fn: (key: string) => T): (key: string) => T {
  const cache = new Map<string, T>();
  return (key: string) => {
    const cached = cache.get(key);
    if (cached !== undefined) return cached;
    const v = fn(key);
    cache.set(key, v);
    return v;
  };
}

export function memoizeWithTTL<T>(
  fn: (key: string) => T,
  ttlMs: number,
): (key: string) => T {
  if (ttlMs <= 0) throw new Error("ttl: must be positive");
  const cache = new Map<string, { value: T; expires: number }>();
  return (key: string) => {
    const now = Date.now();
    const entry = cache.get(key);
    if (entry && entry.expires > now) return entry.value;
    const v = fn(key);
    cache.set(key, { value: v, expires: now + ttlMs });
    return v;
  };
}
