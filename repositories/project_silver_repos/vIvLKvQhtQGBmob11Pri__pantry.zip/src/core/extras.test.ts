import { test } from "node:test";
import assert from "node:assert/strict";
import {
  chunk, clamp, compact, defined, groupBy,
  inRange, maxBy, partition, sumBy, uniq,
} from "./extras.js";

test("clamp", () => {
  assert.equal(clamp(5, 0, 10), 5);
  assert.equal(clamp(-1, 0, 10), 0);
  assert.equal(clamp(11, 0, 10), 10);
  assert.equal(clamp(NaN, 0, 10), 0);
});

test("inRange", () => {
  assert.equal(inRange(5, 0, 10), true);
  assert.equal(inRange(-1, 0, 10), false);
  assert.equal(inRange(11, 0, 10), false);
});

test("defined", () => {
  assert.equal(defined(0), true);
  assert.equal(defined(""), true);
  assert.equal(defined(null), false);
  assert.equal(defined(undefined), false);
});

test("compact drops null/undefined", () => {
  assert.deepEqual(compact([1, null, 2, undefined, 3]), [1, 2, 3]);
});

test("uniq dedupes preserving order", () => {
  assert.deepEqual(uniq([1, 2, 1, 3, 2]), [1, 2, 3]);
});

test("chunk", () => {
  assert.deepEqual(chunk([1, 2, 3, 4, 5], 2), [[1, 2], [3, 4], [5]]);
  assert.deepEqual(chunk([], 5), []);
  assert.throws(() => chunk([1], 0));
});

test("partition", () => {
  const [evens, odds] = partition([1, 2, 3, 4], (n) => n % 2 === 0);
  assert.deepEqual(evens, [2, 4]);
  assert.deepEqual(odds, [1, 3]);
});

test("sumBy", () => {
  assert.equal(sumBy([{n:1},{n:2},{n:3}], (x) => x.n), 6);
});

test("maxBy", () => {
  assert.equal(maxBy([{n:1},{n:5},{n:3}], (x) => x.n)?.n, 5);
  assert.equal(maxBy([], () => 1), null);
});

test("groupBy", () => {
  const out = groupBy([1, 2, 3, 4], (n) => n % 2 === 0 ? "even" : "odd");
  assert.deepEqual(out.get("even"), [2, 4]);
  assert.deepEqual(out.get("odd"), [1, 3]);
});
