// Shared suffix array helper for fast prefix matches over slugs.
// Used by `pantry whereis` to make the fuzzy lookup snappier as the
// pantry grows.

export class SlugIndex {
  private slugs: string[];

  constructor(slugs: string[]) {
    this.slugs = slugs.slice().sort();
  }

  /** Return slugs starting with the given prefix. */
  startsWith(prefix: string): string[] {
    if (prefix === "") return this.slugs.slice();
    const lo = lowerBound(this.slugs, prefix);
    const out: string[] = [];
    for (let i = lo; i < this.slugs.length; i++) {
      const s = this.slugs[i]!;
      if (!s.startsWith(prefix)) break;
      out.push(s);
    }
    return out;
  }

  /** Return slugs containing the given infix substring. */
  contains(infix: string): string[] {
    if (infix === "") return this.slugs.slice();
    return this.slugs.filter((s) => s.includes(infix));
  }

  size(): number {
    return this.slugs.length;
  }

  has(slug: string): boolean {
    const lo = lowerBound(this.slugs, slug);
    return lo < this.slugs.length && this.slugs[lo] === slug;
  }
}

function lowerBound(arr: string[], target: string): number {
  let lo = 0, hi = arr.length;
  while (lo < hi) {
    const mid = (lo + hi) >> 1;
    if (arr[mid]! < target) lo = mid + 1;
    else hi = mid;
  }
  return lo;
}

export function newIndex(slugs: string[]): SlugIndex {
  return new SlugIndex(slugs);
}
