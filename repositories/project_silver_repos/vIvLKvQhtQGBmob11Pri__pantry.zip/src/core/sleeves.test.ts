import { test } from "node:test";
import assert from "node:assert/strict";
import { bookmark, envelope, indexCard, shelfTag, spineLabel } from "./sleeves.js";
import type { Item } from "./item.js";

const today = "2026-04-15";

const item: Item = {
  id: 1, slug: "olive-oil", name: "Olive Oil", category: "oils",
  lots: [
    { id: 1, qty: { value: 500, kind: "volume" }, addedAt: today, where: "pantry", bestBy: "2027-01-30" },
    { id: 2, qty: { value: 250, kind: "volume" }, addedAt: today, where: "pantry" },
  ],
  createdAt: today, updatedAt: today,
};

test("shelfTag includes name + slug + lot count", () => {
  const out = shelfTag(item);
  assert.match(out, /Olive Oil/);
  assert.match(out, /olive-oil/);
  assert.match(out, /lots: 2/);
});

test("shelfTag total line included when single-kind", () => {
  const out = shelfTag(item);
  assert.match(out, /total:/);
});

test("spineLabel includes category when present", () => {
  assert.equal(spineLabel(item), "olive-oil [oils]");
});

test("spineLabel without category", () => {
  const it: Item = { ...item }; delete it.category;
  assert.equal(spineLabel(it), "olive-oil");
});

test("indexCard includes separators + lots", () => {
  const out = indexCard(item);
  assert.match(out, /---/);
  assert.match(out, /lot 1/);
  assert.match(out, /lot 2/);
});

test("indexCard includes barcode when set", () => {
  const out = indexCard({ ...item, barcode: "12345" });
  assert.match(out, /barcode:.+12345/);
});

test("bookmark", () => {
  assert.equal(bookmark(item), "[olive-oil] Olive Oil (2 lots)");
});

test("envelope wraps a label + bookmarks", () => {
  const out = envelope([item], "Sunday cook");
  assert.match(out, /Sunday cook/);
  assert.match(out, /olive-oil/);
});

test("envelope on empty list", () => {
  const out = envelope([], "x");
  assert.match(out, /\(0 items\)/);
});
