// TTL cache for transient lookups (path -> last-touched timestamp).
// Used by the importers to skip files that have already been processed
// within the configured idempotency window.

export class TTLCache<T> {
  private store = new Map<string, { value: T; expires: number }>();
  private ttlMs: number;
  constructor(ttlMs: number) {
    if (ttlMs <= 0) throw new Error("ttl: must be positive");
    this.ttlMs = ttlMs;
  }
  set(key: string, value: T): void {
    this.store.set(key, { value, expires: Date.now() + this.ttlMs });
  }
  get(key: string): T | undefined {
    const entry = this.store.get(key);
    if (!entry) return undefined;
    if (entry.expires < Date.now()) {
      this.store.delete(key);
      return undefined;
    }
    return entry.value;
  }
  has(key: string): boolean {
    return this.get(key) !== undefined;
  }
  size(): number {
    return this.store.size;
  }
  reap(): number {
    const now = Date.now();
    let removed = 0;
    for (const [k, v] of this.store) {
      if (v.expires < now) {
        this.store.delete(k);
        removed++;
      }
    }
    return removed;
  }
  clear(): void {
    this.store.clear();
  }
  keys(): string[] {
    return [...this.store.keys()];
  }
}

export function newTTL<T>(ms: number): TTLCache<T> {
  return new TTLCache<T>(ms);
}
