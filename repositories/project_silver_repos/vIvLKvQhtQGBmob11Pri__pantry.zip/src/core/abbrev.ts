// Map "kg" / "lb" / "tbsp" abbreviations to their canonical form.
// Used by the importer to handle whatever abbreviation the user typed.

const TABLE: Record<string, string> = {
  // mass
  g: "g",
  gram: "g",
  grams: "g",
  gr: "g",
  kg: "kg",
  kilogram: "kg",
  kilograms: "kg",
  kgs: "kg",
  oz: "oz",
  ounce: "oz",
  ounces: "oz",
  lb: "lb",
  lbs: "lb",
  pound: "lb",
  pounds: "lb",
  // volume
  ml: "ml",
  milliliter: "ml",
  milliliters: "ml",
  millilitre: "ml",
  millilitres: "ml",
  l: "l",
  liter: "l",
  liters: "l",
  litre: "l",
  litres: "l",
  tsp: "tsp",
  teaspoon: "tsp",
  teaspoons: "tsp",
  tbsp: "tbsp",
  tablespoon: "tbsp",
  tablespoons: "tbsp",
  cup: "cup",
  cups: "cup",
  pint: "pint",
  pints: "pint",
  qt: "qt",
  quart: "qt",
  quarts: "qt",
  gal: "gal",
  gallon: "gal",
  gallons: "gal",
  // count
  ea: "ea",
  each: "ea",
  unit: "ea",
  units: "ea",
  pcs: "ea",
  piece: "ea",
  pieces: "ea",
  ct: "ea",
  count: "ea",
  dozen: "dozen",
  doz: "dozen",
  pair: "pair",
};

export function canonicalUnit(input: string): string | null {
  const key = input.trim().toLowerCase();
  if (key === "") return null;
  return TABLE[key] ?? null;
}

export function knownAbbreviations(): string[] {
  return Object.keys(TABLE).sort();
}

export function isKnown(input: string): boolean {
  return canonicalUnit(input) !== null;
}

export function suggestNormalisation(text: string): string {
  return text.replace(
    /(\d+(?:\.\d+)?)\s*([a-zA-Z]+)/g,
    (_, num, unit) => {
      const can = canonicalUnit(unit);
      if (can) return `${num}${can}`;
      return _;
    },
  );
}

export function categoryOf(unit: string): "mass" | "volume" | "count" | null {
  const can = canonicalUnit(unit);
  if (!can) return null;
  if (["g", "kg", "oz", "lb"].includes(can)) return "mass";
  if (["ml", "l", "tsp", "tbsp", "cup", "pint", "qt", "gal"].includes(can)) return "volume";
  return "count";
}
