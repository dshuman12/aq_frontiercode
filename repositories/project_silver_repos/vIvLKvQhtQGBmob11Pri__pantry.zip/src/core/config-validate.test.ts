import { test } from "node:test";
import assert from "node:assert/strict";
import { formatHuman, validate } from "./config-validate.js";

const trueFn = () => true;
const falseFn = () => false;

test("empty env yields one info note for the data dir default", () => {
  const r = validate({ env: {}, fileExists: trueFn, isWritable: trueFn });
  assert.equal(r.ok, true);
  assert.equal(r.findings.length, 1);
  assert.equal(r.findings[0]!.variable, "PANTRY_DATA_DIR");
  assert.equal(r.findings[0]!.severity, "info");
});

test("invalid log level is a warning, not an error", () => {
  const r = validate({
    env: { PANTRY_LOG_LEVEL: "trace" },
    fileExists: trueFn,
    isWritable: trueFn,
  });
  assert.equal(r.ok, true);
  const f = r.findings.find((f) => f.variable === "PANTRY_LOG_LEVEL");
  assert.equal(f?.severity, "warn");
});

test("invalid log format is a warning", () => {
  const r = validate({
    env: { PANTRY_LOG_FORMAT: "logfmt" },
    fileExists: trueFn,
    isWritable: trueFn,
  });
  assert.equal(r.ok, true);
  assert.ok(r.findings.find((f) => f.variable === "PANTRY_LOG_FORMAT"));
});

test("malformed bind addr is an error", () => {
  const r = validate({
    env: { PANTRY_HTTP_BIND: "no-port-here" },
    fileExists: trueFn,
    isWritable: trueFn,
  });
  assert.equal(r.ok, false);
});

test("bind port out of range is an error", () => {
  const r = validate({
    env: { PANTRY_METRICS_BIND: "0.0.0.0:99999" },
    fileExists: trueFn,
    isWritable: trueFn,
  });
  assert.equal(r.ok, false);
  const f = r.findings.find((f) => f.variable === "PANTRY_METRICS_BIND");
  assert.match(f?.message ?? "", /out of range/);
});

test("relative data dir path is an error", () => {
  const r = validate({
    env: { PANTRY_DATA_DIR: "relative/path" },
    fileExists: trueFn,
    isWritable: trueFn,
  });
  assert.equal(r.ok, false);
});

test("missing data dir produces a warning", () => {
  const r = validate({
    env: { PANTRY_DATA_DIR: "/var/lib/pantry-missing" },
    fileExists: falseFn,
    isWritable: falseFn,
  });
  assert.equal(r.ok, true);
  const f = r.findings.find((f) => f.variable === "PANTRY_DATA_DIR");
  assert.equal(f?.severity, "warn");
});

test("data dir present but not writable is an error", () => {
  const r = validate({
    env: { PANTRY_DATA_DIR: "/var/lib/pantry-readonly" },
    fileExists: trueFn,
    isWritable: falseFn,
  });
  assert.equal(r.ok, false);
});

test("PANTRY_HOUSEHOLD with whitespace is rejected", () => {
  const r = validate({
    env: { PANTRY_HOUSEHOLD: "main kitchen" },
    fileExists: trueFn,
    isWritable: trueFn,
  });
  assert.equal(r.ok, false);
});

test("invalid TZ is rejected", () => {
  const r = validate({
    env: { TZ: "Atlantis/Mid_Ocean" },
    fileExists: trueFn,
    isWritable: trueFn,
  });
  assert.equal(r.ok, false);
});

test("formatHuman renders an OK summary on a clean run", () => {
  const out = formatHuman({ ok: true, findings: [] });
  assert.match(out, /configuration: OK/);
});

test("formatHuman lists every finding", () => {
  const out = formatHuman({
    ok: false,
    findings: [
      { severity: "error", variable: "X", message: "bad" },
      { severity: "warn", variable: "Y", message: "iffy" },
    ],
  });
  assert.match(out, /ERROR X: bad/);
  assert.match(out, / WARN Y: iffy/);
  assert.match(out, /configuration: FAIL/);
});
