import { test } from "node:test";
import assert from "node:assert/strict";
import { Registry } from "./metrics.js";

test("counter starts at 0 implicitly and increments", () => {
  const r = new Registry();
  const c = r.counter("pantry_records_total", "records written");
  c.inc();
  c.inc({}, 4);
  const out = r.render();
  assert.match(out, /^# HELP pantry_records_total records written$/m);
  assert.match(out, /^# TYPE pantry_records_total counter$/m);
  assert.match(out, /^pantry_records_total 5$/m);
});

test("counter inc with negative throws", () => {
  const r = new Registry();
  const c = r.counter("x_total", "h");
  assert.throws(() => c.inc({}, -1));
});

test("counter with labels keeps per-series totals", () => {
  const r = new Registry();
  const c = r.counter("pantry_imports_total", "imports by source");
  c.inc({ source: "csv" });
  c.inc({ source: "csv" });
  c.inc({ source: "jsonl" });
  const out = r.render();
  assert.match(out, /pantry_imports_total\{source="csv"\} 2/);
  assert.match(out, /pantry_imports_total\{source="jsonl"\} 1/);
});

test("gauge set / inc / dec", () => {
  const r = new Registry();
  const g = r.gauge("pantry_lock_wait_seconds", "current lock wait");
  g.set(0.4);
  g.inc(0.1);
  g.dec(0.05);
  assert.match(r.render(), /pantry_lock_wait_seconds 0\.450?/);
});

test("redefining a name with a different type throws", () => {
  const r = new Registry();
  r.counter("x", "h");
  assert.throws(() => r.gauge("x", "h"));
});

test("invalid metric name is rejected", () => {
  const r = new Registry();
  assert.throws(() => r.counter("not-allowed!", "h"));
  assert.throws(() => r.counter("0starts_with_digit", "h"));
});

test("labels are escaped", () => {
  const r = new Registry();
  const c = r.counter("x", "h");
  c.inc({ note: 'a"b\\c' });
  const out = r.render();
  assert.match(out, /note="a\\"b\\\\c"/);
});

test("rendering deterministically sorts metrics + labels", () => {
  const r = new Registry();
  const c = r.counter("z", "h");
  c.inc({ b: "2", a: "1" });
  const g = r.gauge("a", "h");
  g.set(7);
  const out = r.render();
  const lines = out.trim().split("\n");
  assert.equal(lines[0], "# HELP a h");
  assert.equal(lines[1], "# TYPE a gauge");
  assert.equal(lines[2], "a 7");
  assert.equal(lines[3], "# HELP z h");
  assert.match(lines[5] ?? "", /^z\{a="1",b="2"\} 1$/);
});

test("size counts series across families", () => {
  const r = new Registry();
  const c = r.counter("c", "h");
  c.inc({ a: "1" });
  c.inc({ a: "2" });
  const g = r.gauge("g", "h");
  g.set(0);
  assert.equal(r.size(), 3);
});

test("non-finite gauge values render as Prometheus specials", () => {
  const r = new Registry();
  const g = r.gauge("x", "h");
  g.set(Number.POSITIVE_INFINITY);
  assert.match(r.render(), /^x \+Inf$/m);
  g.set(Number.NaN);
  assert.match(r.render(), /^x NaN$/m);
});
