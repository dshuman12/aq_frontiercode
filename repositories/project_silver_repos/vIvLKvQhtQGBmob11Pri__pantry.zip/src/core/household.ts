// Multi-household support: each household has its own storage
// directory under data/households/<id>/. Useful when one machine
// hosts both the personal kitchen and a shared communal one.

import fs from "node:fs/promises";
import path from "node:path";
import { dataDir } from "../core/paths.js";

export interface Household {
  id: string;
  name: string;
  description?: string;
  members?: string[];
  default?: boolean;
}

export interface HouseholdsFile {
  households: Household[];
}

export function file(): string {
  return path.join(dataDir(), "households.json");
}

export async function load(): Promise<HouseholdsFile> {
  try {
    return JSON.parse(await fs.readFile(file(), "utf8")) as HouseholdsFile;
  } catch (err) {
    if (isENOENT(err)) {
      return { households: [{ id: "default", name: "Household", default: true }] };
    }
    throw err;
  }
}

export async function save(f: HouseholdsFile): Promise<void> {
  validate(f);
  await fs.mkdir(dataDir(), { recursive: true });
  const tmp = file() + ".tmp";
  await fs.writeFile(tmp, JSON.stringify(f, null, 2), "utf8");
  await fs.rename(tmp, file());
}

export async function add(h: Household): Promise<void> {
  const f = await load();
  if (f.households.some((x) => x.id === h.id)) {
    throw new Error(`household: id "${h.id}" already exists`);
  }
  f.households.push(h);
  await save(f);
}

export async function remove(id: string): Promise<boolean> {
  const f = await load();
  const before = f.households.length;
  f.households = f.households.filter((h) => h.id !== id);
  await save(f);
  return f.households.length < before;
}

export async function setDefault(id: string): Promise<void> {
  const f = await load();
  let found = false;
  for (const h of f.households) {
    h.default = h.id === id;
    if (h.id === id) found = true;
  }
  if (!found) throw new Error(`household: id "${id}" not found`);
  await save(f);
}

export function validate(f: HouseholdsFile): void {
  if (!Array.isArray(f.households)) {
    throw new Error("households must be an array");
  }
  const ids = new Set<string>();
  for (const h of f.households) {
    if (!h.id) throw new Error("household entry missing id");
    if (ids.has(h.id)) throw new Error(`duplicate household id: ${h.id}`);
    ids.add(h.id);
  }
}

export function defaultHousehold(f: HouseholdsFile): Household | null {
  return f.households.find((h) => h.default) ?? f.households[0] ?? null;
}

export function rootFor(h: Household): string {
  if (h.id === "default") return dataDir();
  return path.join(dataDir(), "households", h.id);
}

function isENOENT(err: unknown): boolean {
  return typeof err === "object" && err !== null &&
    (err as { code?: string }).code === "ENOENT";
}
