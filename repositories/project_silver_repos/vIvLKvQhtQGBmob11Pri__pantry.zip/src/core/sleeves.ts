// Render single-item "sleeves" - small text blocks like a shelf-tag
// or back-of-jar summary.

import type { Item } from "./item.js";
import { totalQuantity } from "./item.js";
import { format as fmtQ } from "./units.js";

export function shelfTag(item: Item): string {
  const total = totalQuantity(item);
  const totalLine = total ? `total: ${fmtQ(total)}` : "";
  const lines = [
    item.name,
    item.slug,
    `lots: ${item.lots.length}`,
  ];
  if (totalLine) lines.push(totalLine);
  return lines.join("\n") + "\n";
}

export function spineLabel(item: Item): string {
  const cat = item.category ? ` [${item.category}]` : "";
  return `${item.slug}${cat}`;
}

export function indexCard(item: Item): string {
  const sep = "-".repeat(36);
  const total = totalQuantity(item);
  const out: string[] = [];
  out.push(item.name);
  out.push(sep);
  out.push(`slug:     ${item.slug}`);
  if (item.category) out.push(`category: ${item.category}`);
  if (item.barcode) out.push(`barcode:  ${item.barcode}`);
  out.push(`created:  ${item.createdAt}`);
  out.push(`updated:  ${item.updatedAt}`);
  if (total) out.push(`total:    ${fmtQ(total)}`);
  out.push(sep);
  for (const lot of item.lots) {
    const bb = lot.bestBy ? `  best-by ${lot.bestBy}` : "";
    out.push(`  lot ${lot.id}: ${fmtQ(lot.qty)} in ${lot.where}${bb}`);
  }
  out.push(sep);
  return out.join("\n") + "\n";
}

export function bookmark(item: Item): string {
  return `[${item.slug}] ${item.name} (${item.lots.length} lots)`;
}

export function envelope(items: Item[], label: string): string {
  const lines: string[] = [];
  lines.push(`# ${label}`);
  lines.push(`(${items.length} items)`);
  lines.push("");
  for (const item of items) lines.push(bookmark(item));
  return lines.join("\n") + "\n";
}
