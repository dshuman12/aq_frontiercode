import { test } from "node:test";
import assert from "node:assert/strict";
import path from "node:path";
import os from "node:os";
import fs from "node:fs/promises";
import * as h from "./household.js";

async function sandbox() {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), "pantry-hh-"));
  process.env.PANTRY_DATA_DIR = path.join(dir, "data");
  process.env.PANTRY_CONFIG_DIR = path.join(dir, "cfg");
  process.env.PANTRY_CACHE_DIR = path.join(dir, "cache");
}

test("load on missing returns default household", async () => {
  await sandbox();
  const f = await h.load();
  assert.equal(f.households.length, 1);
  assert.equal(f.households[0]?.id, "default");
});

test("add inserts new household", async () => {
  await sandbox();
  await h.add({ id: "shared", name: "Shared" });
  const f = await h.load();
  assert.equal(f.households.length, 2);
});

test("add rejects duplicate id", async () => {
  await sandbox();
  await assert.rejects(() => h.add({ id: "default", name: "x" }));
});

test("remove drops a household", async () => {
  await sandbox();
  await h.add({ id: "shared", name: "Shared" });
  assert.equal(await h.remove("shared"), true);
  assert.equal(await h.remove("missing"), false);
});

test("setDefault flips the flag", async () => {
  await sandbox();
  await h.add({ id: "shared", name: "Shared" });
  await h.setDefault("shared");
  const f = await h.load();
  const def = f.households.find((x) => x.default);
  assert.equal(def?.id, "shared");
});

test("setDefault on missing throws", async () => {
  await sandbox();
  await assert.rejects(() => h.setDefault("missing"));
});

test("validate rejects duplicate ids", () => {
  assert.throws(() => h.validate({
    households: [{ id: "x", name: "" }, { id: "x", name: "" }],
  }));
});

test("validate rejects missing id", () => {
  assert.throws(() => h.validate({
    households: [{ id: "", name: "x" }],
  }));
});

test("defaultHousehold prefers explicit default", async () => {
  await sandbox();
  await h.add({ id: "shared", name: "Shared" });
  await h.setDefault("shared");
  const f = await h.load();
  assert.equal(h.defaultHousehold(f)?.id, "shared");
});

test("defaultHousehold falls back to first when none flagged", () => {
  const got = h.defaultHousehold({
    households: [
      { id: "a", name: "A" },
      { id: "b", name: "B" },
    ],
  });
  assert.equal(got?.id, "a");
});

test("rootFor", async () => {
  await sandbox();
  const root = h.rootFor({ id: "shared", name: "Shared" });
  assert.match(root, /shared/);
});
