import { test } from "node:test";
import assert from "node:assert/strict";
import { batch, newThrottle } from "./throttle.js";

test("rejects negative interval", () => {
  assert.throws(() => newThrottle(-1));
});

test("interval=0 runs immediately", async () => {
  const t = newThrottle(0);
  const out = await t.run(async () => 42);
  assert.equal(out, 42);
});

test("waits between calls", async () => {
  const t = newThrottle(20);
  const start = Date.now();
  await t.run(async () => undefined);
  await t.run(async () => undefined);
  const elapsed = Date.now() - start;
  assert.ok(elapsed >= 20);
});

test("batch runs jobs in order", async () => {
  const log: number[] = [];
  await batch([
    async () => { log.push(1); },
    async () => { log.push(2); },
    async () => { log.push(3); },
  ], 0);
  assert.deepEqual(log, [1, 2, 3]);
});

test("batch returns the resolved values", async () => {
  const out = await batch<number>([
    async () => 10,
    async () => 20,
  ], 0);
  assert.deepEqual(out, [10, 20]);
});

test("reset clears the next-fire time", async () => {
  const t = newThrottle(100);
  await t.run(async () => undefined);
  t.reset();
  const start = Date.now();
  await t.run(async () => undefined);
  assert.ok(Date.now() - start < 50);
});
