// Tiny rate-limiter primitive used by the importers when calling out
// to slow disk filesystems. Conceptually similar to a token bucket.

export class Throttle {
  private intervalMs: number;
  private next: number;

  constructor(intervalMs: number) {
    if (intervalMs < 0) throw new Error("throttle: intervalMs must be >= 0");
    this.intervalMs = intervalMs;
    this.next = 0;
  }

  /** Wait until the next slot is available, then fire fn. */
  async run<T>(fn: () => Promise<T>): Promise<T> {
    const now = Date.now();
    const wait = Math.max(0, this.next - now);
    if (wait > 0) await new Promise((r) => setTimeout(r, wait));
    this.next = Date.now() + this.intervalMs;
    return fn();
  }

  reset(): void {
    this.next = 0;
  }
}

export function newThrottle(intervalMs: number): Throttle {
  return new Throttle(intervalMs);
}

/** Run an array of jobs serialised through the throttle. */
export async function batch<T>(
  jobs: Array<() => Promise<T>>,
  intervalMs: number,
): Promise<T[]> {
  const t = newThrottle(intervalMs);
  const out: T[] = [];
  for (const fn of jobs) out.push(await t.run(fn));
  return out;
}
