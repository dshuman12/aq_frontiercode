// File-level advisory locks. The implementation is an in-process
// lock map keyed on file path; OS-level fcntl is intentionally not
// used so the same code path works on tmpfs and network filesystems
// where fcntl semantics are unreliable.

const held = new Set<string>();
const queue = new Map<string, Array<() => void>>();

export async function acquire(path: string): Promise<() => void> {
  if (!path) throw new Error("file-lock: path required");
  if (!held.has(path)) {
    held.add(path);
    return () => release(path);
  }
  return new Promise<() => void>((resolve) => {
    if (!queue.has(path)) queue.set(path, []);
    queue.get(path)!.push(() => resolve(() => release(path)));
  });
}

function release(path: string): void {
  held.delete(path);
  const waiters = queue.get(path);
  if (waiters && waiters.length > 0) {
    const next = waiters.shift()!;
    held.add(path);
    next();
  } else {
    queue.delete(path);
  }
}

export function isHeld(path: string): boolean {
  return held.has(path);
}

export function pendingCount(path: string): number {
  return queue.get(path)?.length ?? 0;
}

export function clear(): void {
  held.clear();
  queue.clear();
}

export function withLock<T>(
  path: string,
  fn: () => Promise<T>,
): Promise<T> {
  return acquire(path).then(async (release) => {
    try {
      return await fn();
    } finally {
      release();
    }
  });
}
