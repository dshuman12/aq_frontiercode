import { test } from "node:test";
import assert from "node:assert/strict";
import { createLogger } from "./structured-log.js";

function captured(): { lines: string[]; sink: (s: string) => void } {
  const lines: string[] = [];
  return { lines, sink: (s: string) => lines.push(s) };
}

test("text format includes level + message", () => {
  const c = captured();
  const log = createLogger({ format: "text", level: "debug", sink: c.sink });
  log.info("hello");
  assert.equal(c.lines.length, 1);
  assert.match(c.lines[0]!, / INFO {2}hello$/);
});

test("text format renders fields key=value", () => {
  const c = captured();
  const log = createLogger({ format: "text", level: "debug", sink: c.sink });
  log.warn("slow op", { ms: 412, op: "list" });
  assert.match(c.lines[0]!, /ms=412/);
  assert.match(c.lines[0]!, /op=list/);
});

test("json format produces valid JSON", () => {
  const c = captured();
  const log = createLogger({ format: "json", level: "debug", sink: c.sink });
  log.info("hi", { who: "test" });
  const parsed = JSON.parse(c.lines[0]!);
  assert.equal(parsed.msg, "hi");
  assert.equal(parsed.level, "info");
  assert.equal(parsed.who, "test");
  assert.match(parsed.ts, /^\d{4}-\d{2}-\d{2}T/);
});

test("level filter suppresses lower levels", () => {
  const c = captured();
  const log = createLogger({ format: "json", level: "warn", sink: c.sink });
  log.debug("d");
  log.info("i");
  log.warn("w");
  log.error("e");
  assert.equal(c.lines.length, 2);
  assert.equal(JSON.parse(c.lines[0]!).level, "warn");
  assert.equal(JSON.parse(c.lines[1]!).level, "error");
});

test("child logger inherits + overrides fields", () => {
  const c = captured();
  const log = createLogger({ format: "json", level: "debug", sink: c.sink, bound: { a: 1 } });
  const child = log.child({ b: 2 });
  child.info("x", { c: 3 });
  const parsed = JSON.parse(c.lines[0]!);
  assert.equal(parsed.a, 1);
  assert.equal(parsed.b, 2);
  assert.equal(parsed.c, 3);
});

test("setLevel adjusts threshold at runtime", () => {
  const c = captured();
  const log = createLogger({ format: "json", level: "info", sink: c.sink });
  log.debug("d1");
  assert.equal(c.lines.length, 0);
  log.setLevel("debug");
  log.debug("d2");
  assert.equal(c.lines.length, 1);
});

test("error fields are serialized as a string", () => {
  const c = captured();
  const log = createLogger({ format: "json", level: "debug", sink: c.sink });
  log.error("boom", { err: new Error("disk full") });
  const parsed = JSON.parse(c.lines[0]!);
  assert.match(parsed.err, /disk full/);
});

test("text format quotes values containing whitespace", () => {
  const c = captured();
  const log = createLogger({ format: "text", level: "debug", sink: c.sink });
  log.info("x", { msg: "hello world" });
  assert.match(c.lines[0]!, /msg="hello world"/);
});

test("invalid level falls back to info via env", () => {
  const prev = process.env.PANTRY_LOG_LEVEL;
  process.env.PANTRY_LOG_LEVEL = "trace-please";
  try {
    const c = captured();
    const log = createLogger({ sink: c.sink, format: "json" });
    log.debug("d");
    log.info("i");
    assert.equal(c.lines.length, 1);
  } finally {
    if (prev === undefined) delete process.env.PANTRY_LOG_LEVEL;
    else process.env.PANTRY_LOG_LEVEL = prev;
  }
});
