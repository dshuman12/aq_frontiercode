// Structured logger. Emits either human-readable text (default) or
// JSON Lines on stderr, depending on PANTRY_LOG_FORMAT.
//
// The level filter honors PANTRY_LOG_LEVEL. Only the standard set of
// levels (debug/info/warn/error) is supported; anything else falls back
// to "info".

export type LogLevel = "debug" | "info" | "warn" | "error";

export type LogFields = Readonly<Record<string, unknown>>;

export interface Logger {
  debug(msg: string, fields?: LogFields): void;
  info(msg: string, fields?: LogFields): void;
  warn(msg: string, fields?: LogFields): void;
  error(msg: string, fields?: LogFields): void;
  child(fields: LogFields): Logger;
  setLevel(level: LogLevel): void;
}

const ORDER: Record<LogLevel, number> = {
  debug: 10,
  info: 20,
  warn: 30,
  error: 40,
};

function parseLevel(raw: string | undefined): LogLevel {
  if (!raw) return "info";
  const lc = raw.toLowerCase();
  if (lc === "debug" || lc === "info" || lc === "warn" || lc === "error") {
    return lc;
  }
  return "info";
}

function parseFormat(raw: string | undefined): "text" | "json" {
  return raw && raw.toLowerCase() === "json" ? "json" : "text";
}

export interface LoggerOptions {
  level?: LogLevel;
  format?: "text" | "json";
  bound?: LogFields;
  sink?: (line: string) => void;
}

export function createLogger(opts: LoggerOptions = {}): Logger {
  let level: LogLevel = opts.level ?? parseLevel(process.env.PANTRY_LOG_LEVEL);
  const format = opts.format ?? parseFormat(process.env.PANTRY_LOG_FORMAT);
  const bound: LogFields = opts.bound ?? {};
  const sink = opts.sink ?? ((line: string) => {
    process.stderr.write(line + "\n");
  });

  const enabled = (l: LogLevel): boolean => ORDER[l] >= ORDER[level];

  const emit = (l: LogLevel, msg: string, fields?: LogFields): void => {
    if (!enabled(l)) return;
    const merged: Record<string, unknown> = { ...bound, ...(fields ?? {}) };
    if (format === "json") {
      const safe: Record<string, unknown> = {};
      for (const [k, v] of Object.entries(merged)) safe[k] = jsonSafe(v);
      const record = {
        ts: new Date().toISOString(),
        level: l,
        msg,
        ...safe,
      };
      sink(JSON.stringify(record));
      return;
    }
    const ts = new Date().toISOString();
    const tag = l.toUpperCase().padEnd(5, " ");
    const tail = formatFields(merged);
    sink(`${ts} ${tag} ${msg}${tail}`);
  };

  return {
    debug: (m, f) => emit("debug", m, f),
    info: (m, f) => emit("info", m, f),
    warn: (m, f) => emit("warn", m, f),
    error: (m, f) => emit("error", m, f),
    child: (fields) =>
      createLogger({
        level,
        format,
        bound: { ...bound, ...fields },
        sink,
      }),
    setLevel: (l) => {
      level = l;
    },
  };
}

function formatFields(fields: LogFields): string {
  const keys = Object.keys(fields);
  if (keys.length === 0) return "";
  const parts: string[] = [];
  for (const k of keys) {
    const v = fields[k];
    parts.push(`${k}=${formatScalar(v)}`);
  }
  return " " + parts.join(" ");
}

function jsonSafe(v: unknown): unknown {
  if (v instanceof Error) return `${v.name}: ${v.message}`;
  return v;
}

function formatScalar(v: unknown): string {
  if (v === null || v === undefined) return "-";
  if (typeof v === "string") {
    return /\s/.test(v) ? JSON.stringify(v) : v;
  }
  if (typeof v === "number" || typeof v === "boolean") return String(v);
  if (v instanceof Error) return JSON.stringify(`${v.name}: ${v.message}`);
  try {
    return JSON.stringify(v);
  } catch {
    return "<unserializable>";
  }
}

let defaultLogger: Logger | null = null;

export function getLogger(): Logger {
  if (!defaultLogger) defaultLogger = createLogger();
  return defaultLogger;
}

export function resetDefaultLogger(): void {
  defaultLogger = null;
}
