import { test } from "node:test";
import assert from "node:assert/strict";
import { newTTL } from "./ttl-cache.js";

test("rejects non-positive TTL", () => {
  assert.throws(() => newTTL(0));
  assert.throws(() => newTTL(-5));
});

test("set + get works", () => {
  const c = newTTL<number>(1000);
  c.set("k", 42);
  assert.equal(c.get("k"), 42);
});

test("has reflects presence", () => {
  const c = newTTL<number>(1000);
  c.set("k", 1);
  assert.equal(c.has("k"), true);
  assert.equal(c.has("missing"), false);
});

test("size", () => {
  const c = newTTL<number>(1000);
  c.set("a", 1); c.set("b", 2);
  assert.equal(c.size(), 2);
});

test("clear empties", () => {
  const c = newTTL<number>(1000);
  c.set("k", 1);
  c.clear();
  assert.equal(c.size(), 0);
});

test("keys returns inserted keys", () => {
  const c = newTTL<number>(1000);
  c.set("a", 1); c.set("b", 2);
  assert.deepEqual([...c.keys()].sort(), ["a", "b"]);
});

test("reap returns 0 on empty", () => {
  assert.equal(newTTL(1000).reap(), 0);
});
