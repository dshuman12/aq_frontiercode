import { test } from "node:test";
import assert from "node:assert/strict";
import { newIndex } from "./slug-index.js";

const slugs = ["apple", "applesauce", "banana", "blueberry", "cherry", "olive-oil"];

test("startsWith returns matching prefixes", () => {
  const idx = newIndex(slugs);
  assert.deepEqual(idx.startsWith("app"), ["apple", "applesauce"]);
});

test("startsWith empty prefix returns all", () => {
  const idx = newIndex(slugs);
  assert.equal(idx.startsWith("").length, slugs.length);
});

test("startsWith no match returns empty", () => {
  const idx = newIndex(slugs);
  assert.deepEqual(idx.startsWith("zzz"), []);
});

test("contains returns infix matches", () => {
  const idx = newIndex(slugs);
  assert.deepEqual(idx.contains("err"), ["blueberry", "cherry"]);
});

test("contains empty returns all", () => {
  const idx = newIndex(slugs);
  assert.equal(idx.contains("").length, slugs.length);
});

test("size", () => {
  assert.equal(newIndex(slugs).size(), slugs.length);
});

test("has true / false", () => {
  const idx = newIndex(slugs);
  assert.equal(idx.has("apple"), true);
  assert.equal(idx.has("missing"), false);
});

test("constructor sorts input", () => {
  const idx = newIndex(["banana", "apple"]);
  assert.deepEqual(idx.startsWith(""), ["apple", "banana"]);
});
