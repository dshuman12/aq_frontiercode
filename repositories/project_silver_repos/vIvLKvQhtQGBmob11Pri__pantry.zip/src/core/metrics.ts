// Prometheus text-format metrics registry.
//
// We only implement the two metric families the operations team actually
// scrapes: counters and gauges. No histograms, no summaries - those are
// not used by the reference Grafana dashboard, and adding them would
// double the surface area of this module.

export type Labels = Readonly<Record<string, string>>;

interface Series {
  labels: Labels;
  value: number;
}

interface Family {
  name: string;
  help: string;
  type: "counter" | "gauge";
  series: Map<string, Series>;
}

export class Registry {
  private families = new Map<string, Family>();

  counter(name: string, help: string): Counter {
    const fam = this.ensure(name, help, "counter");
    return new Counter(fam);
  }

  gauge(name: string, help: string): Gauge {
    const fam = this.ensure(name, help, "gauge");
    return new Gauge(fam);
  }

  private ensure(name: string, help: string, type: "counter" | "gauge"): Family {
    if (!isValidName(name)) {
      throw new Error(`metrics: invalid metric name '${name}'`);
    }
    const existing = this.families.get(name);
    if (existing) {
      if (existing.type !== type) {
        throw new Error(`metrics: ${name} already registered as ${existing.type}`);
      }
      return existing;
    }
    const fam: Family = { name, help, type, series: new Map() };
    this.families.set(name, fam);
    return fam;
  }

  /** Render the registry as a Prometheus text-format payload. */
  render(): string {
    const out: string[] = [];
    const sortedNames = [...this.families.keys()].sort();
    for (const name of sortedNames) {
      const fam = this.families.get(name)!;
      out.push(`# HELP ${fam.name} ${escapeHelp(fam.help)}`);
      out.push(`# TYPE ${fam.name} ${fam.type}`);
      const sortedKeys = [...fam.series.keys()].sort();
      for (const key of sortedKeys) {
        const s = fam.series.get(key)!;
        out.push(`${fam.name}${formatLabels(s.labels)} ${formatValue(s.value)}`);
      }
    }
    return out.join("\n") + (out.length > 0 ? "\n" : "");
  }

  /** For tests and `pantry config check`. */
  size(): number {
    let n = 0;
    for (const fam of this.families.values()) n += fam.series.size;
    return n;
  }

  reset(): void {
    this.families.clear();
  }
}

class Counter {
  constructor(private readonly fam: Family) {}

  inc(labels: Labels = {}, by: number = 1): void {
    if (by < 0) throw new Error("counter: cannot decrement");
    const key = labelKey(labels);
    const series = this.fam.series.get(key);
    if (series) {
      series.value += by;
    } else {
      this.fam.series.set(key, { labels, value: by });
    }
  }
}

class Gauge {
  constructor(private readonly fam: Family) {}

  set(value: number, labels: Labels = {}): void {
    const key = labelKey(labels);
    const existing = this.fam.series.get(key);
    if (existing) {
      existing.value = value;
    } else {
      this.fam.series.set(key, { labels, value });
    }
  }

  inc(by: number = 1, labels: Labels = {}): void {
    this.adjust(by, labels);
  }

  dec(by: number = 1, labels: Labels = {}): void {
    this.adjust(-by, labels);
  }

  private adjust(delta: number, labels: Labels): void {
    const key = labelKey(labels);
    const series = this.fam.series.get(key);
    if (series) {
      series.value += delta;
    } else {
      this.fam.series.set(key, { labels, value: delta });
    }
  }
}

function isValidName(name: string): boolean {
  return /^[A-Za-z_][A-Za-z0-9_]*$/.test(name);
}

function labelKey(labels: Labels): string {
  const keys = Object.keys(labels).sort();
  if (keys.length === 0) return "";
  return keys.map((k) => `${k}=${labels[k]}`).join(",");
}

function formatLabels(labels: Labels): string {
  const keys = Object.keys(labels).sort();
  if (keys.length === 0) return "";
  const parts = keys.map((k) => `${k}="${escapeLabel(labels[k] ?? "")}"`);
  return `{${parts.join(",")}}`;
}

function escapeLabel(value: string): string {
  return value.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\n/g, "\\n");
}

function escapeHelp(help: string): string {
  return help.replace(/\\/g, "\\\\").replace(/\n/g, "\\n");
}

function formatValue(value: number): string {
  if (!Number.isFinite(value)) {
    if (Number.isNaN(value)) return "NaN";
    return value > 0 ? "+Inf" : "-Inf";
  }
  return String(value);
}

let defaultRegistry: Registry | null = null;

export function defaultMetrics(): Registry {
  if (!defaultRegistry) defaultRegistry = new Registry();
  return defaultRegistry;
}

export function resetDefaultMetrics(): void {
  defaultRegistry = null;
}
