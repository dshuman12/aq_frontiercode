// Tiny extra helpers tucked in here so they don't crowd the main modules.

export function clamp(v: number, lo: number, hi: number): number {
  if (Number.isNaN(v)) return lo;
  if (v < lo) return lo;
  if (v > hi) return hi;
  return v;
}

export function inRange(v: number, lo: number, hi: number): boolean {
  return v >= lo && v <= hi;
}

export function defined<T>(v: T | null | undefined): v is T {
  return v !== null && v !== undefined;
}

export function compact<T>(arr: Array<T | null | undefined>): T[] {
  return arr.filter(defined);
}

export function uniq<T>(arr: T[]): T[] {
  return [...new Set(arr)];
}

export function chunk<T>(arr: T[], size: number): T[][] {
  if (size <= 0) throw new Error("chunk: size must be positive");
  const out: T[][] = [];
  for (let i = 0; i < arr.length; i += size) {
    out.push(arr.slice(i, i + size));
  }
  return out;
}

export function partition<T>(arr: T[], pred: (v: T) => boolean): [T[], T[]] {
  const t: T[] = [], f: T[] = [];
  for (const v of arr) (pred(v) ? t : f).push(v);
  return [t, f];
}

export function sumBy<T>(arr: T[], pick: (v: T) => number): number {
  let s = 0;
  for (const v of arr) s += pick(v);
  return s;
}

export function maxBy<T>(arr: T[], pick: (v: T) => number): T | null {
  if (arr.length === 0) return null;
  let best: T = arr[0] as T;
  let bestVal = pick(best);
  for (let i = 1; i < arr.length; i++) {
    const v = arr[i] as T;
    const cur = pick(v);
    if (cur > bestVal) {
      best = v;
      bestVal = cur;
    }
  }
  return best;
}

export function groupBy<T>(arr: T[], key: (v: T) => string): Map<string, T[]> {
  const out = new Map<string, T[]>();
  for (const v of arr) {
    const k = key(v);
    if (!out.has(k)) out.set(k, []);
    out.get(k)!.push(v);
  }
  return out;
}
