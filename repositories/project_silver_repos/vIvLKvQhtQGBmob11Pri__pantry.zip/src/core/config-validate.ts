// Config validator. Walks the documented PANTRY_* environment
// variables, parses each, and reports problems back to the caller.
//
// The validator is deliberately separate from the env consumers
// (paths.ts, structured-log.ts, ...) so `pantry config check` can run
// before the rest of the program has touched the filesystem.

import * as fs from "node:fs";
import * as path from "node:path";

export type Severity = "error" | "warn" | "info";

export interface Finding {
  severity: Severity;
  variable: string;
  message: string;
}

export interface CheckResult {
  ok: boolean;
  findings: Finding[];
}

export interface CheckEnv {
  env: NodeJS.ProcessEnv;
  /** Replaceable for tests. */
  fileExists?: (p: string) => boolean;
  isWritable?: (p: string) => boolean;
}

export function validate(opts: CheckEnv): CheckResult {
  const env = opts.env;
  const fileExists = opts.fileExists ?? defaultExists;
  const isWritable = opts.isWritable ?? defaultWritable;
  const findings: Finding[] = [];

  checkLogLevel(env, findings);
  checkLogFormat(env, findings);
  checkBindAddr(env, "PANTRY_HTTP_BIND", findings);
  checkBindAddr(env, "PANTRY_METRICS_BIND", findings);
  checkDir(env, "PANTRY_DATA_DIR", findings, fileExists, isWritable, true);
  checkDir(env, "PANTRY_CONFIG_DIR", findings, fileExists, isWritable, false);
  checkDir(env, "PANTRY_CACHE_DIR", findings, fileExists, isWritable, false);
  checkHousehold(env, findings);
  checkTimeZone(env, findings);

  const ok = findings.every((f) => f.severity !== "error");
  return { ok, findings };
}

function checkLogLevel(env: NodeJS.ProcessEnv, out: Finding[]): void {
  const v = env.PANTRY_LOG_LEVEL;
  if (!v) return;
  if (!["debug", "info", "warn", "error"].includes(v.toLowerCase())) {
    out.push({
      severity: "warn",
      variable: "PANTRY_LOG_LEVEL",
      message: `unrecognized value '${v}', falling back to 'info'`,
    });
  }
}

function checkLogFormat(env: NodeJS.ProcessEnv, out: Finding[]): void {
  const v = env.PANTRY_LOG_FORMAT;
  if (!v) return;
  if (!["text", "json"].includes(v.toLowerCase())) {
    out.push({
      severity: "warn",
      variable: "PANTRY_LOG_FORMAT",
      message: `unrecognized value '${v}', falling back to 'text'`,
    });
  }
}

function checkBindAddr(
  env: NodeJS.ProcessEnv,
  key: string,
  out: Finding[],
): void {
  const v = env[key];
  if (!v) return;
  const m = v.match(/^(.+):(\d+)$/);
  if (!m) {
    out.push({
      severity: "error",
      variable: key,
      message: `expected host:port, got '${v}'`,
    });
    return;
  }
  const port = Number(m[2]);
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    out.push({
      severity: "error",
      variable: key,
      message: `port ${m[2]} is out of range (1-65535)`,
    });
  }
}

function checkDir(
  env: NodeJS.ProcessEnv,
  key: string,
  out: Finding[],
  fileExists: (p: string) => boolean,
  isWritable: (p: string) => boolean,
  required: boolean,
): void {
  const v = env[key];
  if (!v) {
    if (required) {
      out.push({
        severity: "info",
        variable: key,
        message: "unset; falling back to XDG default",
      });
    }
    return;
  }
  if (!path.isAbsolute(v)) {
    out.push({
      severity: "error",
      variable: key,
      message: `must be an absolute path, got '${v}'`,
    });
    return;
  }
  if (!fileExists(v)) {
    out.push({
      severity: "warn",
      variable: key,
      message: `directory does not yet exist: ${v}`,
    });
    return;
  }
  if (!isWritable(v)) {
    out.push({
      severity: "error",
      variable: key,
      message: `directory is not writable by the current user: ${v}`,
    });
  }
}

function checkHousehold(env: NodeJS.ProcessEnv, out: Finding[]): void {
  const v = env.PANTRY_HOUSEHOLD;
  if (!v) return;
  if (!/^[a-z0-9-]+$/.test(v)) {
    out.push({
      severity: "error",
      variable: "PANTRY_HOUSEHOLD",
      message: `must match [a-z0-9-]+, got '${v}'`,
    });
  }
}

function checkTimeZone(env: NodeJS.ProcessEnv, out: Finding[]): void {
  const v = env.TZ;
  if (!v) return;
  try {
    new Intl.DateTimeFormat("en-US", { timeZone: v }).format(new Date());
  } catch {
    out.push({
      severity: "error",
      variable: "TZ",
      message: `not a recognized IANA time zone: '${v}'`,
    });
  }
}

function defaultExists(p: string): boolean {
  try {
    return fs.statSync(p).isDirectory();
  } catch {
    return false;
  }
}

function defaultWritable(p: string): boolean {
  try {
    fs.accessSync(p, fs.constants.W_OK);
    return true;
  } catch {
    return false;
  }
}

export function formatHuman(result: CheckResult): string {
  if (result.findings.length === 0) {
    return "configuration: OK\n";
  }
  const lines: string[] = [];
  for (const f of result.findings) {
    const tag =
      f.severity === "error" ? "ERROR" : f.severity === "warn" ? " WARN" : " INFO";
    lines.push(`${tag} ${f.variable}: ${f.message}`);
  }
  lines.push(result.ok ? "configuration: OK (with warnings)" : "configuration: FAIL");
  return lines.join("\n") + "\n";
}
