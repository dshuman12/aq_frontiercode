import { test } from "node:test";
import assert from "node:assert/strict";
import { acquire, clear, isHeld, pendingCount, withLock } from "./file-lock.js";

test("acquire + release", async () => {
  clear();
  const release = await acquire("/x");
  assert.equal(isHeld("/x"), true);
  release();
  assert.equal(isHeld("/x"), false);
});

test("acquire blocks until release", async () => {
  clear();
  const log: string[] = [];
  const r1 = await acquire("/x");
  log.push("first");
  const second = acquire("/x").then((release) => {
    log.push("second");
    release();
  });
  assert.equal(pendingCount("/x"), 1);
  r1();
  await second;
  assert.deepEqual(log, ["first", "second"]);
});

test("acquire requires path", async () => {
  await assert.rejects(() => acquire(""));
});

test("withLock releases on success", async () => {
  clear();
  const out = await withLock("/x", async () => 42);
  assert.equal(out, 42);
  assert.equal(isHeld("/x"), false);
});

test("withLock releases on error", async () => {
  clear();
  await assert.rejects(() => withLock("/x", async () => {
    throw new Error("boom");
  }));
  assert.equal(isHeld("/x"), false);
});

test("clear empties everything", async () => {
  clear();
  await acquire("/x");
  clear();
  assert.equal(isHeld("/x"), false);
  assert.equal(pendingCount("/x"), 0);
});
