// `pantry metrics` - print the current Prometheus-format metrics to
// stdout. Used both for ad-hoc inspection and as the body of the
// optional /metrics HTTP endpoint when PANTRY_METRICS_BIND is set.

import { register } from "../dispatch.js";
import { defaultMetrics } from "../../core/metrics.js";
import * as store from "../../core/store.js";
import * as recipes from "../../core/recipe-store.js";

const SCHEMA_VERSION = 4;

register({
  name: "metrics",
  short: "print current metrics in Prometheus text format",
  run: async () => {
    const reg = defaultMetrics();
    const items = await store.list();
    const allRecipes = await recipes.list();

    const lots = items.reduce((n, i) => n + i.lots.length, 0);
    const itemsGauge = reg.gauge("pantry_items_total", "tracked item count");
    itemsGauge.set(items.length);
    const lotsGauge = reg.gauge("pantry_lots_total", "tracked lot count");
    lotsGauge.set(lots);
    const recipesGauge = reg.gauge("pantry_recipes_total", "stored recipe count");
    recipesGauge.set(allRecipes.length);
    const schemaGauge = reg.gauge("pantry_schema_version", "on-disk schema version");
    schemaGauge.set(SCHEMA_VERSION);
    const buildGauge = reg.gauge("pantry_build_info", "build info (always 1)");
    buildGauge.set(1, { version: "0.4.0" });

    process.stdout.write(reg.render());
    return 0;
  },
});