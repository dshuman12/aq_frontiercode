// `pantry healthcheck` - silent liveness probe.
//
// This is the command intended for systemd `WatchdogSec=` and Kubernetes
// `livenessProbe`/`readinessProbe`. It exits 0 if the service is healthy
// and non-zero if not, with no stdout output by default. Pass --verbose
// for a one-line summary on stderr.

import { parseFlags, register, flagBool, flagInt } from "../dispatch.js";
import * as fs from "node:fs/promises";
import * as path from "node:path";
import { dataDir } from "../../core/paths.js";

register({
  name: "healthcheck",
  short: "exit 0 if the service is healthy (probe-friendly)",
  run: async (args) => {
    const { flags } = parseFlags(args);
    const verbose = flagBool(flags, "verbose");
    const lockMaxAge = flagInt(flags, "lock-max-age", 30);

    const errs: string[] = [];
    const dir = dataDir();

    try {
      const st = await fs.stat(dir);
      if (!st.isDirectory()) errs.push(`data dir is not a directory: ${dir}`);
    } catch (e) {
      errs.push(`data dir unreadable: ${dir} (${(e as Error).message})`);
    }

    try {
      await fs.access(dir, fs.constants.R_OK | fs.constants.W_OK);
    } catch {
      errs.push(`data dir not r/w by current user: ${dir}`);
    }

    const lock = path.join(dir, ".lock");
    try {
      const st = await fs.stat(lock);
      const ageSec = (Date.now() - st.mtimeMs) / 1000;
      if (ageSec > lockMaxAge) {
        errs.push(`stale lockfile: ${lock} (${Math.round(ageSec)}s old)`);
      }
    } catch {
      // No lockfile is the healthy case.
    }

    if (errs.length > 0) {
      if (verbose) {
        for (const m of errs) process.stderr.write(`healthcheck: ${m}\n`);
      }
      return 1;
    }
    if (verbose) process.stderr.write("healthcheck: OK\n");
    return 0;
  },
});