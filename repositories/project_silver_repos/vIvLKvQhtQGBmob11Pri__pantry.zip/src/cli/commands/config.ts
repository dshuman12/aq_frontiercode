// `pantry config show|set|check` - thin wrapper over core/config and
// the standalone environment validator.

import { parseFlags, register } from "../dispatch.js";
import * as config from "../../core/config.js";
import { formatHuman, validate } from "../../core/config-validate.js";

register({
  name: "config",
  short: "view, change, or validate config (show/set/check)",
  run: async (args) => {
    const { positional } = parseFlags(args);
    if (positional.length === 0 || positional[0] === "show") {
      const c = await config.load();
      process.stdout.write(JSON.stringify(c, null, 2) + "\n");
      return 0;
    }
    if (positional[0] === "set") {
      if (positional.length !== 3) {
        throw new Error("config set: expected <field> <value>");
      }
      await config.set(positional[1]!, positional[2]!);
      return 0;
    }
    if (positional[0] === "check") {
      const result = validate({ env: process.env });
      process.stdout.write(formatHuman(result));
      return result.ok ? 0 : 1;
    }
    throw new Error(`config: unknown subcommand ${positional[0]}`);
  },
});
