# Security

## Reporting

If you find a security issue, please email asifhammad84@gmail.com
with subject `[tideway-security]`. Don't open a public issue.

I'll respond within 7 days with either a fix timeline or a request
for more information. If I don't respond, escalate via a DM on the
maintainer's preferred social channel.

## Threat model

Tideway runs in-process inside a trusted service. The threat model is
narrow:

- Untrusted job inputs: handlers receive caller-supplied input. The
  runtime treats the input as opaque bytes; handlers are responsible
  for validating their own input.
- Local-host only: the wire socket is a unix domain socket bound to
  a path the operator chooses. Filesystem permissions on that path
  are the access-control mechanism.
- No remote callers: the wire protocol is not designed for adversarial
  network input. Don't bind it to a TCP port without putting your own
  authn/authz in front.

What the runtime guarantees:

- Frame size is hard-capped (MAX_FRAME_BYTES = 1 MiB). A peer can't
  exhaust memory by claiming a huge frame in the length prefix.
- Handlers run inside a structured execution context with cancellation
  hooks. A handler that hangs is bounded by the lease TTL.
- The store is opened with `pragma foreign_keys = ON`; corrupted
  references between tables are rejected at write time.

What the runtime does NOT guarantee:

- Resource limits on individual handlers (CPU, memory). The runtime
  inherits OS-level limits; bad handlers can burn CPU.
- Sandbox isolation. Handlers run in the same process as the runtime.
  A handler that calls `process.exit()` will take down the runtime.

## Dependency policy

Runtime dependencies are minimal (kleur, better-sqlite3). Each new
runtime dep needs a justification in the PR.

We don't run automated CVE scans on every push; the dep set is small
enough that manual auditing on each release is feasible. The `yarn
audit` output is checked at release time.
