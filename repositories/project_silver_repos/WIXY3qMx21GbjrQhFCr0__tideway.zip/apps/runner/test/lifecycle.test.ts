import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { Lifecycle, LifecycleError } from '../src/lifecycle.ts';

describe('Lifecycle', () => {
  it('starts in starting', () => {
    const lc = new Lifecycle();
    assert.equal(lc.current(), 'starting');
    assert.equal(lc.is('starting'), true);
  });

  it('starting -> running', () => {
    const lc = new Lifecycle();
    lc.transition('running');
    assert.equal(lc.current(), 'running');
  });

  it('starting -> stopped (early abort path)', () => {
    const lc = new Lifecycle();
    lc.transition('stopped');
    assert.equal(lc.current(), 'stopped');
  });

  it('running -> draining -> stopped', () => {
    const lc = new Lifecycle();
    lc.transition('running');
    lc.transition('draining');
    lc.transition('stopped');
    assert.equal(lc.current(), 'stopped');
  });

  it('rejects illegal transitions', () => {
    const lc = new Lifecycle();
    assert.throws(() => lc.transition('draining'), LifecycleError);
  });

  it('fails on backward transitions', () => {
    const lc = new Lifecycle();
    lc.transition('running');
    assert.throws(() => lc.transition('starting'), LifecycleError);
  });

  it('stopped is terminal', () => {
    const lc = new Lifecycle();
    lc.transition('stopped');
    assert.throws(() => lc.transition('running'), LifecycleError);
    assert.throws(() => lc.transition('draining'), LifecycleError);
  });
});

describe('Lifecycle: listeners', () => {
  it('onChange fires on every transition', () => {
    const lc = new Lifecycle();
    const events: Array<{ s: string; prev: string }> = [];
    lc.onChange((s, prev) => events.push({ s, prev }));
    lc.transition('running');
    lc.transition('draining');
    assert.equal(events.length, 2);
    assert.deepEqual(events[0], { s: 'running', prev: 'starting' });
    assert.deepEqual(events[1], { s: 'draining', prev: 'running' });
  });

  it('returned unsubscribe stops further events', () => {
    const lc = new Lifecycle();
    const events: string[] = [];
    const off = lc.onChange((s) => events.push(s));
    lc.transition('running');
    off();
    lc.transition('draining');
    assert.deepEqual(events, ['running']);
  });
});

describe('Lifecycle: waitFor', () => {
  it('resolves immediately if already in target state', async () => {
    const lc = new Lifecycle();
    await lc.waitFor('starting');
  });

  it('resolves when the transition happens', async () => {
    const lc = new Lifecycle();
    setTimeout(() => lc.transition('running'), 5);
    await lc.waitFor('running', 1000);
    assert.equal(lc.current(), 'running');
  });

  it('bails on on timeout', async () => {
    const lc = new Lifecycle();
    await assert.rejects(lc.waitFor('running', 5));
  });
});
