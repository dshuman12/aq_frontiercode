import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { Graph } from '../../../packages/dag/src/index.ts';
import type { RunState } from '../../../packages/runstate/src/index.ts';
import {
  generateRunId,
  submitOne,
  validateSubmit,
  type SubmitContext,
  type WorkflowNode,
} from '../src/submit.ts';

function fakeContext(): SubmitContext {
  const created: string[] = [];
  const ctx: SubmitContext = {
    now: 1000,
    graph: new Graph<WorkflowNode>(),
    states: new Map<string, RunState>(),
    onCreated: (runId) => created.push(runId),
  };
  // Attach the captured array to the context object for assertion.
  (ctx as SubmitContext & { created: string[] }).created = created;
  return ctx;
}

describe('generateRunId', () => {
  it('starts with the r- prefix', () => {
    assert.match(generateRunId(), /^r-/);
  });

  it('produces distinct ids', () => {
    const a = generateRunId();
    const b = generateRunId();
    assert.notEqual(a, b);
  });
});

describe('submitOne', () => {
  it('creates a fresh run', () => {
    const ctx = fakeContext();
    const r = submitOne({ handler: 'h', input: 1 }, ctx);
    assert.equal(r.dedup, false);
    assert.equal(ctx.graph.has(r.runId), true);
    assert.equal(ctx.states.has(r.runId), true);
  });

  it('honors caller-supplied runId', () => {
    const ctx = fakeContext();
    const r = submitOne({ runId: 'specific-id', handler: 'h', input: 1 }, ctx);
    assert.equal(r.runId, 'specific-id');
    assert.equal(ctx.graph.has('specific-id'), true);
  });

  it('treats re-submission of the same id as dedup, not error', () => {
    const ctx = fakeContext();
    submitOne({ runId: 'fixed', handler: 'h', input: 1 }, ctx);
    const r2 = submitOne({ runId: 'fixed', handler: 'h', input: 2 }, ctx);
    assert.equal(r2.dedup, true);
  });

  it('attaches parents as edges', () => {
    const ctx = fakeContext();
    submitOne({ runId: 'p', handler: 'h', input: 1 }, ctx);
    submitOne({ runId: 'c', handler: 'h', input: 2, parents: ['p'] }, ctx);
    assert.equal(ctx.graph.hasEdge('p', 'c'), true);
  });

  it('throws on unknown parent', () => {
    const ctx = fakeContext();
    assert.throws(() => submitOne({ handler: 'h', input: 1, parents: ['ghost'] }, ctx));
  });

  it('absolute deadline = now + deadlineMs', () => {
    const ctx = fakeContext();
    const r = submitOne({ handler: 'h', input: 1, deadlineMs: 5000 }, ctx);
    assert.equal(ctx.graph.get(r.runId).declaredDeadline, 6000);
  });

  it('Infinity deadline when not specified', () => {
    const ctx = fakeContext();
    const r = submitOne({ handler: 'h', input: 1 }, ctx);
    assert.equal(ctx.graph.get(r.runId).declaredDeadline, Infinity);
  });

  it('default queue/priority are sensible', () => {
    const ctx = fakeContext();
    const r = submitOne({ handler: 'h', input: 1 }, ctx);
    const node = ctx.graph.get(r.runId);
    assert.equal(node.queue, 'default');
    assert.equal(node.priority, 0);
  });

  it('onCreated fires with the new runId', () => {
    const ctx = fakeContext() as SubmitContext & { created: string[] };
    submitOne({ runId: 'r-1', handler: 'h', input: 1 }, ctx);
    assert.deepEqual(ctx.created, ['r-1']);
  });
});

describe('validateSubmit', () => {
  const known = new Set(['email', 'audit']);

  it('accepts a registered handler', () => {
    assert.deepEqual(validateSubmit({ handler: 'email', input: 1 }, known), []);
  });

  it('rejects empty handler', () => {
    const errs = validateSubmit({ handler: '', input: 1 }, known);
    assert.equal(errs.length, 1);
    assert.equal(errs[0]!.field, 'handler');
  });

  it('fails on unknown handler', () => {
    const errs = validateSubmit({ handler: 'send-sms', input: 1 }, known);
    assert.equal(errs.length, 1);
  });

  it('bails on non-integer priority', () => {
    const errs = validateSubmit({ handler: 'email', input: 1, priority: 3.14 }, known);
    assert.equal(errs.length, 1);
    assert.equal(errs[0]!.field, 'priority');
  });

  it('complains about deadlineMs <= 0', () => {
    assert.equal(validateSubmit({ handler: 'email', input: 1, deadlineMs: 0 }, known).length, 1);
    assert.equal(validateSubmit({ handler: 'email', input: 1, deadlineMs: -10 }, known).length, 1);
  });

  it('refuses very long idempotency key', () => {
    const errs = validateSubmit(
      { handler: 'email', input: 1, idempotencyKey: 'x'.repeat(1000) },
      known,
    );
    assert.equal(errs.length, 1);
  });

  it('blows up on non-array parents', () => {
    const errs = validateSubmit(
      { handler: 'email', input: 1, parents: 'p1' as unknown as string[] },
      known,
    );
    assert.equal(errs.length, 1);
  });

  it('accumulates multiple errors', () => {
    const errs = validateSubmit(
      { handler: '', input: 1, priority: 0.5, deadlineMs: -1 },
      known,
    );
    assert.equal(errs.length, 3);
  });
});
