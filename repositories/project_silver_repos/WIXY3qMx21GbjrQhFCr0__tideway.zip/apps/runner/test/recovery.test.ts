import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { MemoryStore } from '../../../packages/store/src/index.ts';
import type { LogEntry } from '../../../packages/replay/src/index.ts';
import { recover } from '../src/recovery.ts';

const t = (n: number) => BigInt(n);

const created = (lsn: number, runId: string, at = 0): LogEntry => ({
  lsn,
  runId,
  kind: 'created',
  at: t(at),
});

const dispatchEvent = (lsn: number, runId: string, leaseExpiresAt: number): LogEntry => ({
  lsn,
  runId,
  event: { kind: 'dispatch', at: t(0), workerId: 'w', leaseExpiresAt: t(leaseExpiresAt) },
});

describe('recover', () => {
  it('returns an empty report for an empty store', async () => {
    const store = new MemoryStore();
    const r = await recover(store);
    assert.equal(r.recoveredRuns, 0);
    assert.equal(r.appliedEntries, 0);
    assert.equal(r.expiredLeasesRequeued, 0);
  });

  it('reconstructs created runs', async () => {
    const store = new MemoryStore();
    store.appendLog([created(1, 'r1', 100), created(2, 'r2', 200)]);
    const r = await recover(store);
    assert.equal(r.recoveredRuns, 2);
    assert.equal(r.states.get('r1')?.kind, 'queued');
  });

  it('requeues runs whose lease expired during outage', async () => {
    const store = new MemoryStore();
    store.appendLog([
      created(1, 'r1'),
      // Dispatch with lease that expires at t=500.
      dispatchEvent(2, 'r1', 500),
    ]);
    // Recovery starts at now=1000, after the lease expired.
    const r = await recover(store, { now: 1000 });
    assert.equal(r.expiredLeasesRequeued, 1);
    assert.equal(r.states.get('r1')?.kind, 'queued');
  });

  it('does NOT requeue runs whose lease is still valid', async () => {
    const store = new MemoryStore();
    store.appendLog([created(1, 'r1'), dispatchEvent(2, 'r1', 5000)]);
    const r = await recover(store, { now: 1000 });
    assert.equal(r.expiredLeasesRequeued, 0);
    assert.equal(r.states.get('r1')?.kind, 'running');
  });

  it('reports highWaterMark from the highest LSN read', async () => {
    const store = new MemoryStore();
    store.appendLog([created(1, 'r1'), created(2, 'r2'), created(3, 'r3')]);
    const r = await recover(store);
    assert.equal(r.highWaterMark, 3);
  });

  it('handles batched reads', async () => {
    const store = new MemoryStore();
    const entries: LogEntry[] = [];
    for (let i = 1; i <= 250; i += 1) entries.push(created(i, `r${i}`));
    store.appendLog(entries);
    const r = await recover(store, { batchSize: 100 });
    assert.equal(r.recoveredRuns, 250);
    assert.equal(r.highWaterMark, 250);
  });

  it('counts skipped entries', async () => {
    const store = new MemoryStore();
    store.appendLog([
      created(1, 'r1'),
      // illegal transition: heartbeat from queued
      {
        lsn: 2,
        runId: 'r1',
        event: { kind: 'heartbeat', at: t(0), leaseExpiresAt: t(1000) },
      },
    ]);
    const r = await recover(store);
    assert.equal(r.appliedEntries, 1);
    assert.equal(r.skippedEntries, 1);
  });
});
