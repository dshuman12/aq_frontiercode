import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { HandlerRegistry } from '../src/registry.ts';

describe('HandlerRegistry', () => {
  it('starts empty', () => {
    const r = new HandlerRegistry();
    assert.equal(r.size(), 0);
    assert.deepEqual(r.list(), []);
  });

  it('register adds a handler', () => {
    const r = new HandlerRegistry();
    r.register('h', () => 1);
    assert.equal(r.has('h'), true);
    assert.equal(r.size(), 1);
  });

  it('register refuses duplicate name', () => {
    const r = new HandlerRegistry();
    r.register('h', () => 1);
    assert.throws(() => r.register('h', () => 2));
  });

  it('get returns the registered function', async () => {
    const r = new HandlerRegistry();
    r.register('h', () => 42);
    const fn = r.get('h')!;
    const out = await fn(
      {
        signal: new AbortController().signal,
        runId: 'r-1',
        attempt: 1,
        heartbeat: () => undefined,
        log: () => undefined,
      },
      undefined,
    );
    assert.equal(out, 42);
  });

  it('get on unknown returns undefined', () => {
    const r = new HandlerRegistry();
    assert.equal(r.get('ghost'), undefined);
  });

  it('list returns a sorted array', () => {
    const r = new HandlerRegistry();
    r.register('zebra', () => 1);
    r.register('apple', () => 1);
    r.register('mango', () => 1);
    assert.deepEqual(r.list(), ['apple', 'mango', 'zebra']);
  });

  it('override replaces an existing handler', () => {
    const r = new HandlerRegistry();
    r.register('h', () => 1);
    r.override('h', () => 2);
    assert.equal(r.has('h'), true);
    assert.equal(r.size(), 1);
  });
});
