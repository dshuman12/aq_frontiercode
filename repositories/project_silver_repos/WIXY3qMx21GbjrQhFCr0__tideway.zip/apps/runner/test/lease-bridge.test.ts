import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { LeaseLost } from '../../../packages/failure/src/index.ts';
import { LeaseRegistry } from '../../../packages/leasing/src/index.ts';
import { LeaseBridge } from '../src/lease-bridge.ts';

class FakeClock {
  constructor(public t = 0) {}
  now = () => this.t;
  advance(ms: number) {
    this.t += ms;
  }
}

describe('LeaseBridge: acquire / release', () => {
  it('acquire returns a lease id', () => {
    const c = new FakeClock(0);
    const registry = new LeaseRegistry({ clock: c.now });
    const bridge = new LeaseBridge({
      registry,
      defaultTtlMs: 30_000,
      reaperIntervalMs: 5000,
      onLeaseExpired: () => undefined,
    });
    const leaseId = bridge.acquire('r-1', 'worker-1');
    assert.ok(leaseId);
  });

  it('acquire returns null if a non-expired lease is held', () => {
    const c = new FakeClock(0);
    const registry = new LeaseRegistry({ clock: c.now });
    const bridge = new LeaseBridge({
      registry,
      defaultTtlMs: 30_000,
      reaperIntervalMs: 5000,
      onLeaseExpired: () => undefined,
    });
    bridge.acquire('r-1', 'worker-A');
    const second = bridge.acquire('r-1', 'worker-B');
    assert.equal(second, null);
  });

  it('release frees the slot', () => {
    const c = new FakeClock(0);
    const registry = new LeaseRegistry({ clock: c.now });
    const bridge = new LeaseBridge({
      registry,
      defaultTtlMs: 30_000,
      reaperIntervalMs: 5000,
      onLeaseExpired: () => undefined,
    });
    const id = bridge.acquire('r-1', 'worker-A')!;
    bridge.release(id);
    const second = bridge.acquire('r-1', 'worker-B');
    assert.ok(second);
  });
});

describe('LeaseBridge: heartbeat', () => {
  it('extends an active lease', () => {
    const c = new FakeClock(0);
    const registry = new LeaseRegistry({ clock: c.now });
    const bridge = new LeaseBridge({
      registry,
      defaultTtlMs: 1000,
      reaperIntervalMs: 100,
      onLeaseExpired: () => undefined,
    });
    const id = bridge.acquire('r-1', 'worker-A')!;
    c.advance(500);
    const beat = bridge.heartbeatFn(id);
    beat(); // does not throw
    c.advance(800);
    // Without a heartbeat we'd be expired; with the heartbeat we extended.
    assert.ok(registry.getByLease(id));
  });

  it('throws LeaseLost when the lease is already expired', () => {
    const c = new FakeClock(0);
    const registry = new LeaseRegistry({ clock: c.now });
    const bridge = new LeaseBridge({
      registry,
      defaultTtlMs: 1000,
      reaperIntervalMs: 100,
      onLeaseExpired: () => undefined,
    });
    const id = bridge.acquire('r-1', 'worker-A')!;
    c.advance(2000);
    const beat = bridge.heartbeatFn(id);
    assert.throws(() => beat(), LeaseLost);
  });
});

describe('LeaseBridge: sweep', () => {
  it('reclaims expired leases', () => {
    const c = new FakeClock(0);
    const registry = new LeaseRegistry({ clock: c.now });
    const expired: string[] = [];
    const bridge = new LeaseBridge({
      registry,
      defaultTtlMs: 1000,
      reaperIntervalMs: 100,
      onLeaseExpired: (_id, runId) => expired.push(runId),
    });
    bridge.acquire('r-1', 'worker-A');
    bridge.acquire('r-2', 'worker-B');
    c.advance(2000);
    const reclaimed = bridge.sweep();
    assert.equal(reclaimed, 2);
    assert.deepEqual(expired.sort(), ['r-1', 'r-2']);
  });

  it('reports zero reclaimed when nothing is expired', () => {
    const c = new FakeClock(0);
    const registry = new LeaseRegistry({ clock: c.now });
    const bridge = new LeaseBridge({
      registry,
      defaultTtlMs: 30_000,
      reaperIntervalMs: 5000,
      onLeaseExpired: () => undefined,
    });
    bridge.acquire('r-1', 'worker-A');
    assert.equal(bridge.sweep(), 0);
  });

  it('metrics() reports counters', () => {
    const c = new FakeClock(0);
    const registry = new LeaseRegistry({ clock: c.now });
    const bridge = new LeaseBridge({
      registry,
      defaultTtlMs: 1000,
      reaperIntervalMs: 100,
      onLeaseExpired: () => undefined,
    });
    bridge.acquire('r-1', 'worker-A');
    c.advance(2000);
    bridge.sweep();
    const m = bridge.metrics();
    assert.equal(m.sweepCount, 1);
    assert.equal(m.reclaimedCount, 1);
    assert.equal(m.activeCount, 0);
  });
});
