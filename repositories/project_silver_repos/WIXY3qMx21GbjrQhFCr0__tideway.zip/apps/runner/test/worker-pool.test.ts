import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { WorkerPool } from '../src/worker-pool.ts';
import type { Handler } from '../../../packages/worker/src/index.ts';

describe('WorkerPool: capacity', () => {
  it('refuses size < 1', () => {
    assert.throws(() => new WorkerPool(0));
    assert.throws(() => new WorkerPool(-1));
  });

  it('starts with all slots free', () => {
    const p = new WorkerPool(4);
    assert.equal(p.size(), 4);
    assert.equal(p.busy(), 0);
    assert.equal(p.free(), 4);
  });

  it('tryAcquire decrements free', () => {
    const p = new WorkerPool(2);
    const a = p.tryAcquire();
    const b = p.tryAcquire();
    const c = p.tryAcquire();
    assert.ok(a);
    assert.ok(b);
    assert.equal(c, null);
    assert.equal(p.free(), 0);
  });

  it('release frees a slot', () => {
    const p = new WorkerPool(1);
    const a = p.tryAcquire()!;
    p.release(a);
    assert.equal(p.free(), 1);
  });

  it('release on already-free slot is a no-op', () => {
    const p = new WorkerPool(1);
    const a = p.tryAcquire()!;
    p.release(a);
    p.release(a);
    assert.equal(p.free(), 1);
  });
});

describe('WorkerPool: awaitFree', () => {
  it('resolves immediately when a slot is free', async () => {
    const p = new WorkerPool(2);
    const slot = await p.awaitFree();
    assert.ok(slot);
  });

  it('resolves once a slot is released', async () => {
    const p = new WorkerPool(1);
    const a = p.tryAcquire()!;
    let resolved = false;
    const promise = p.awaitFree().then((s) => {
      resolved = true;
      return s;
    });
    assert.equal(resolved, false);
    p.release(a);
    const s = await promise;
    assert.ok(s);
    assert.equal(resolved, true);
  });
});

describe('WorkerPool: dispatch', () => {
  it('runs a successful handler', async () => {
    const p = new WorkerPool(2);
    const handler: Handler<number, number> = (_ctx, x) => x * 2;
    const result = await p.dispatch({
      runId: 'r-1',
      attempt: 1,
      handler,
      input: 7,
      signal: new AbortController().signal,
    });
    assert.equal(result.kind, 'ok');
    if (result.kind === 'ok') assert.equal(result.result, 14);
    assert.equal(p.busy(), 0);
  });

  it('releases slot even on handler throw', async () => {
    const p = new WorkerPool(1);
    const handler: Handler<void, void> = () => {
      throw new Error('boom');
    };
    const result = await p.dispatch({
      runId: 'r-1',
      attempt: 1,
      handler,
      input: undefined,
      signal: new AbortController().signal,
    });
    assert.equal(result.kind, 'fail');
    assert.equal(p.free(), 1);
  });

  it('totalDispatched increments', async () => {
    const p = new WorkerPool(2);
    const handler: Handler<void, void> = () => undefined;
    await p.dispatch({
      runId: 'r-1',
      attempt: 1,
      handler,
      input: undefined,
      signal: new AbortController().signal,
    });
    await p.dispatch({
      runId: 'r-2',
      attempt: 1,
      handler,
      input: undefined,
      signal: new AbortController().signal,
    });
    assert.equal(p.totalDispatched(), 2);
  });

  it('forwards heartbeat callback', async () => {
    const p = new WorkerPool(1);
    let beats = 0;
    const handler: Handler<void, void> = (ctx) => {
      ctx.heartbeat();
      ctx.heartbeat();
    };
    await p.dispatch({
      runId: 'r-1',
      attempt: 1,
      handler,
      input: undefined,
      signal: new AbortController().signal,
      onHeartbeat: () => (beats += 1),
    });
    assert.equal(beats, 2);
  });
});
