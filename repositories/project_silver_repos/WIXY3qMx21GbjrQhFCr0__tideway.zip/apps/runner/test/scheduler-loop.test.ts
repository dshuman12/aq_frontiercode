import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { Graph } from '../../../packages/dag/src/index.ts';
import { initialState, transition, type RunState } from '../../../packages/runstate/src/index.ts';
import { QueueLimits } from '../../../packages/scheduler/src/index.ts';
import { tickOnce, type SchedulerState, type WorkflowNode } from '../src/scheduler-loop.ts';

const t = (n: number) => BigInt(n);

const node = (handler = 'h'): WorkflowNode => ({
  handler,
  input: {},
  queue: 'default',
  priority: 0,
  declaredDeadline: Infinity,
});

function buildState(setup: (g: Graph<WorkflowNode>) => void): SchedulerState {
  const graph = new Graph<WorkflowNode>();
  setup(graph);
  const states = new Map<string, RunState>();
  for (const id of graph.allNodes()) states.set(id, initialState(t(0)));
  return { graph, states, limits: new QueueLimits() };
}

describe('tickOnce', () => {
  it('dispatches a single ready node', () => {
    const dispatched: string[] = [];
    const state = buildState((g) => g.addNode('a', node()));
    const r = tickOnce(state, { now: 1000, freeWorkers: 4 }, (id) => dispatched.push(id));
    assert.equal(r.appliedDispatch, 1);
    assert.deepEqual(dispatched, ['a']);
    assert.equal(state.states.get('a')?.kind, 'running');
  });

  it('respects free worker count', () => {
    const dispatched: string[] = [];
    const state = buildState((g) => {
      for (let i = 0; i < 5; i += 1) g.addNode(`n${i}`, node());
    });
    const r = tickOnce(state, { now: 1000, freeWorkers: 2 }, (id) => dispatched.push(id));
    assert.equal(r.appliedDispatch, 2);
  });

  it('cancels nodes whose deadline has passed', () => {
    const state = buildState((g) => {
      const n = node();
      n.declaredDeadline = 500;
      g.addNode('a', n);
    });
    const r = tickOnce(state, { now: 1000, freeWorkers: 4 }, () => undefined);
    assert.equal(r.appliedCancellations, 1);
    assert.equal(state.states.get('a')?.kind, 'canceled');
  });

  it('cascades parent failure to children', () => {
    const state = buildState((g) => {
      g.addNode('a', node()).addNode('b', node()).addEdge('a', 'b');
    });
    let s = state.states.get('a')!;
    s = transition(s, { kind: 'dispatch', at: t(10), workerId: 'w', leaseExpiresAt: t(60_000) });
    s = transition(s, { kind: 'fail', at: t(20), failureKind: 'permanent', message: 'bad' });
    state.states.set('a', s);

    const r = tickOnce(state, { now: 30, freeWorkers: 4 }, () => undefined);
    assert.equal(r.appliedCancellations, 1);
    assert.equal(state.states.get('b')?.kind, 'canceled');
  });

  it('ordering: highest priority dispatched first when deadlines equal', () => {
    const dispatched: string[] = [];
    const state = buildState((g) => {
      const lo = node();
      lo.priority = 1;
      const hi = node();
      hi.priority = 5;
      g.addNode('lo', lo);
      g.addNode('hi', hi);
    });
    tickOnce(state, { now: 1000, freeWorkers: 1 }, (id) => dispatched.push(id));
    assert.deepEqual(dispatched, ['hi']);
  });

  it('does NOT redispatch a running node', () => {
    const dispatched: string[] = [];
    const state = buildState((g) => g.addNode('a', node()));
    let s = state.states.get('a')!;
    s = transition(s, { kind: 'dispatch', at: t(10), workerId: 'w', leaseExpiresAt: t(60_000) });
    state.states.set('a', s);
    tickOnce(state, { now: 1000, freeWorkers: 4 }, (id) => dispatched.push(id));
    assert.deepEqual(dispatched, []);
  });

  it('returns the decision in the report', () => {
    const state = buildState((g) => g.addNode('a', node()));
    const r = tickOnce(state, { now: 1000, freeWorkers: 4 }, () => undefined);
    assert.deepEqual(r.decision.dispatch, ['a']);
  });
});
