// Scheduler tick loop.
//
// Runs `decide()` every config.schedulerIntervalMs against the current
// run map, dispatching ready nodes through the worker pool. The loop is
// driven by setInterval; the runner clears it on shutdown.
//
// We keep the tick body as a pure function (`tickOnce`) so it's testable
// without setting up timers; the loop wrapper is a few lines that schedule
// it.

import type { Graph, NodeId } from '@tideway/dag';
import type { DeadlinedNode } from '@tideway/deadline';
import { propagate } from '@tideway/deadline';
import type { RunState } from '@tideway/runstate';
import { transition } from '@tideway/runstate';
import {
  decide,
  QueueLimits,
  type Decision,
  type SchedulableNode,
} from '@tideway/scheduler';

export type WorkflowNode = SchedulableNode & DeadlinedNode & { handler: string; input: unknown };

export interface SchedulerState {
  graph: Graph<WorkflowNode>;
  states: Map<NodeId, RunState>;
  limits: QueueLimits;
}

export interface DispatchHook {
  (id: NodeId, node: WorkflowNode): void;
}

export interface TickReport {
  decision: Decision;
  appliedDispatch: number;
  appliedCancellations: number;
}

const t = (n: number) => BigInt(n);

export function tickOnce(
  state: SchedulerState,
  ctx: { now: number; freeWorkers: number },
  onDispatch: DispatchHook,
): TickReport {
  const propagated = propagate(state.graph);
  const decision = decide(state.graph, state.states, state.limits, {
    now: ctx.now,
    freeWorkers: ctx.freeWorkers,
    effectiveDeadline: propagated.effective,
  });

  let appliedDispatch = 0;
  for (const id of decision.dispatch) {
    const current = state.states.get(id);
    if (!current) continue;
    const next = transition(current, {
      kind: 'dispatch',
      at: t(ctx.now),
      workerId: '*pending*',
      leaseExpiresAt: t(ctx.now + 30_000),
    });
    state.states.set(id, next);
    onDispatch(id, state.graph.get(id));
    appliedDispatch += 1;
  }

  let appliedCancellations = 0;
  for (const id of decision.cancel) {
    const current = state.states.get(id);
    if (!current || current.kind !== 'queued') continue;
    state.states.set(
      id,
      transition(current, { kind: 'cancel', at: t(ctx.now), reason: 'deadline' }),
    );
    appliedCancellations += 1;
  }
  for (const id of decision.parentFailureCancel) {
    const current = state.states.get(id);
    if (!current || current.kind !== 'queued') continue;
    state.states.set(
      id,
      transition(current, { kind: 'cancel', at: t(ctx.now), reason: 'parent_failure' }),
    );
    appliedCancellations += 1;
  }

  return { decision, appliedDispatch, appliedCancellations };
}

export class SchedulerLoop {
  private timer: NodeJS.Timeout | undefined;
  private stopped = false;

  constructor(
    private readonly state: SchedulerState,
    private readonly intervalMs: number,
    private readonly getFreeWorkers: () => number,
    private readonly onDispatch: DispatchHook,
  ) {}

  start(): void {
    if (this.timer) return;
    this.timer = setInterval(() => {
      if (this.stopped) return;
      tickOnce(this.state, { now: Date.now(), freeWorkers: this.getFreeWorkers() }, this.onDispatch);
    }, this.intervalMs);
  }

  stop(): void {
    this.stopped = true;
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = undefined;
    }
  }

  // For tests that want to run the loop synchronously.
  tickNow(now: number = Date.now()): TickReport {
    return tickOnce(this.state, { now, freeWorkers: this.getFreeWorkers() }, this.onDispatch);
  }
}
