// Runner lifecycle states.
//
// At startup the runner is `starting`. It transitions to `running` once
// the store is open and migrations are applied; to `draining` when the
// operator asks it to wind down (drain command); to `stopped` when all
// inflight runs have completed and the store is closed.

export type RunnerStatus = 'starting' | 'running' | 'draining' | 'stopped';

export class LifecycleError extends Error {
  override readonly name = 'LifecycleError';
}

export class Lifecycle {
  private state: RunnerStatus = 'starting';
  private readonly listeners: Array<(s: RunnerStatus, prev: RunnerStatus) => void> = [];

  current(): RunnerStatus {
    return this.state;
  }

  is(state: RunnerStatus): boolean {
    return this.state === state;
  }

  transition(target: RunnerStatus): void {
    const legal = legalTransitions[this.state];
    if (!legal.includes(target)) {
      throw new LifecycleError(`illegal lifecycle transition: ${this.state} -> ${target}`);
    }
    const prev = this.state;
    this.state = target;
    for (const l of this.listeners) l(target, prev);
  }

  onChange(fn: (s: RunnerStatus, prev: RunnerStatus) => void): () => void {
    this.listeners.push(fn);
    return () => {
      const i = this.listeners.indexOf(fn);
      if (i >= 0) this.listeners.splice(i, 1);
    };
  }

  // Useful for waiting on a specific state from a test or shutdown
  // routine.
  waitFor(state: RunnerStatus, timeoutMs = 5000): Promise<void> {
    if (this.state === state) return Promise.resolve();
    return new Promise((resolve, reject) => {
      const t = setTimeout(() => {
        unsubscribe();
        reject(new Error(`timed out waiting for ${state}; current=${this.state}`));
      }, timeoutMs);
      const unsubscribe = this.onChange((s) => {
        if (s === state) {
          clearTimeout(t);
          unsubscribe();
          resolve();
        }
      });
    });
  }
}

const legalTransitions: Record<RunnerStatus, RunnerStatus[]> = {
  starting: ['running', 'stopped'],
  running: ['draining', 'stopped'],
  draining: ['stopped'],
  stopped: [],
};
