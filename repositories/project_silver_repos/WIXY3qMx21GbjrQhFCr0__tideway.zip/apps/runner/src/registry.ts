// Handler registry. Maps a handler name (string) to the function that
// runs it. The runner registers a fixed set at startup; user code can
// also register at runtime via the public API.
//
// We keep this as a thin wrapper around a Map so that test code can
// stub specific handlers without spinning up the full runner.

import type { Handler } from '@tideway/worker';

export class HandlerRegistry {
  private readonly handlers = new Map<string, Handler<unknown, unknown>>();

  register<I, O>(name: string, handler: Handler<I, O>): void {
    if (this.handlers.has(name)) {
      throw new Error(`handler already registered: ${name}`);
    }
    this.handlers.set(name, handler as Handler<unknown, unknown>);
  }

  get(name: string): Handler<unknown, unknown> | undefined {
    return this.handlers.get(name);
  }

  has(name: string): boolean {
    return this.handlers.has(name);
  }

  size(): number {
    return this.handlers.size;
  }

  // For diagnostics. Returns a sorted list of registered names.
  list(): string[] {
    return Array.from(this.handlers.keys()).sort();
  }

  // Replace an existing handler. Used in test setup; production code
  // never calls this.
  override<I, O>(name: string, handler: Handler<I, O>): void {
    this.handlers.set(name, handler as Handler<unknown, unknown>);
  }
}
