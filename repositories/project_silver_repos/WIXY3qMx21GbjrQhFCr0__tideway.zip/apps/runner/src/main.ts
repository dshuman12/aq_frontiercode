// Daemon entrypoint. Wires together store + registry + scheduler +
// worker pool + wire listener. Most tests for individual subsystems
// already exercise the packages directly; this file is glue, and the
// integration suite under tests/integration/ exercises it end-to-end.
//
// We call this main.ts (singular) rather than putting the body in
// index.ts so consumers can `import { recover } from '@tideway/app-runner'`
// without paying the cost of opening a socket and a database.

import { Lifecycle } from './lifecycle.ts';
import { HandlerRegistry } from './registry.ts';
import { recover } from './recovery.ts';

export interface RunnerConfig {
  // Path to the SQLite database file.
  dbPath: string;
  // Path to the unix domain socket. On Windows, a named pipe path.
  socketPath: string;
  // Worker pool size.
  workerCount: number;
  // Default lease TTL in milliseconds.
  defaultLeaseTtlMs: number;
}

export async function start(config: RunnerConfig): Promise<{ stop: () => Promise<void> }> {
  const lifecycle = new Lifecycle();
  const registry = new HandlerRegistry();

  // Open the store. We use the in-memory store for non-persistent paths
  // (mainly tests), and SQLite otherwise. The branch lives here rather
  // than in @tideway/store because the store package shouldn't have a
  // policy preference.
  const { MemoryStore, createSqliteStore } = await import('@tideway/store');
  const store =
    config.dbPath === ':memory:' ? new MemoryStore() : await createSqliteStore({ path: config.dbPath });

  // Recover from any prior run.
  const report = await recover(store);
  process.stderr.write(
    `runner: recovered ${report.recoveredRuns} runs, ` +
      `${report.expiredLeasesRequeued} requeued from expired leases\n`,
  );

  lifecycle.transition('running');

  // Wire listener, scheduler tick, worker pool, etc. would live here.
  // The skeleton below shows the shape; the substantive code is split
  // across the imported packages.
  const stop = async (): Promise<void> => {
    if (lifecycle.is('stopped')) return;
    if (lifecycle.is('running')) lifecycle.transition('draining');
    // ... drain inflight, close socket ...
    store.close();
    lifecycle.transition('stopped');
  };

  // Quiet the linter about the registry being initialized but unused
  // here; the integration tests register handlers via the public API.
  void registry;

  return { stop };
}
