// Lease bridge: ties the lease registry's TTL semantics to the
// worker's heartbeat callbacks.
//
// When a worker starts a job, the runner acquires a lease and passes
// `onHeartbeat = () => leaseRegistry.heartbeat(leaseId)` to the worker.
// On crash or wedged event-loop, the heartbeat doesn't fire, the lease
// expires, and the reaper sweeps. The bridge owns this lifecycle so
// the rest of the runner doesn't have to thread leaseId through every
// dispatch path.

import { LeaseLost } from '@tideway/failure';
import type { LeaseId, LeaseRegistry } from '@tideway/leasing';

export interface BridgeOptions {
  registry: LeaseRegistry;
  defaultTtlMs: number;
  reaperIntervalMs: number;
  // Called when the reaper sweep finds an expired lease. The runner
  // uses this to flip the corresponding RunState back to queued and
  // emit a `lease_expire` event.
  onLeaseExpired: (leaseId: LeaseId, runId: string, workerId: string) => void;
}

export class LeaseBridge {
  private timer: NodeJS.Timeout | undefined;
  private sweepCount = 0;
  private reclaimedCount = 0;

  constructor(private readonly opts: BridgeOptions) {}

  start(): void {
    if (this.timer) return;
    this.timer = setInterval(() => this.sweep(), this.opts.reaperIntervalMs);
  }

  stop(): void {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = undefined;
    }
  }

  // Run one reaper sweep. Returns the number of leases reclaimed.
  sweep(): number {
    const expired = this.opts.registry.sweepExpired();
    this.sweepCount += 1;
    this.reclaimedCount += expired.length;
    for (const lease of expired) {
      this.opts.onLeaseExpired(lease.id, lease.runId, lease.workerId);
    }
    return expired.length;
  }

  // Acquire a lease for the given run. Returns null if another worker
  // already holds an unexpired lease (which the scheduler shouldn't
  // dispatch to in the first place, but defense in depth).
  acquire(runId: string, workerId: string): LeaseId | null {
    const lease = this.opts.registry.acquire(runId, workerId, {
      ttlMs: this.opts.defaultTtlMs,
    });
    return lease ? lease.id : null;
  }

  // Build a heartbeat callback bound to a specific lease. Throws
  // LeaseLost if the lease is gone (typically because the reaper got
  // there first); callers should catch that and abort the worker.
  heartbeatFn(leaseId: LeaseId): () => void {
    return () => {
      const renewed = this.opts.registry.heartbeat(leaseId, { ttlMs: this.opts.defaultTtlMs });
      if (!renewed) {
        throw new LeaseLost(leaseId);
      }
    };
  }

  release(leaseId: LeaseId): void {
    this.opts.registry.release(leaseId);
  }

  metrics(): { sweepCount: number; reclaimedCount: number; activeCount: number } {
    return {
      sweepCount: this.sweepCount,
      reclaimedCount: this.reclaimedCount,
      activeCount: this.opts.registry.size(),
    };
  }
}
