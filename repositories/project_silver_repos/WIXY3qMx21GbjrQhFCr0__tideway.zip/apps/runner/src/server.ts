// Wire-protocol server.
//
// Listens on a unix domain socket. Each accepted connection completes
// the handshake, reads a single request frame, dispatches to the
// runtime, and writes the response. Pipelined requests are NOT
// supported on a single connection; clients open a fresh connection
// per command. This is fine for a tooling-grade RPC.

import { createServer, type Server, type Socket } from 'node:net';
import {
  FrameReassembler,
  PROTOCOL_VERSION,
  checkHandshake,
  decodeRequest,
  encodeResponse,
  handshakeBytes,
  type Request,
  type Response,
} from '@tideway/wire';

export type RequestHandler = (req: Request) => Promise<Response> | Response;

export interface ServerOptions {
  socketPath: string;
  handle: RequestHandler;
  onError?: (err: Error) => void;
}

export class WireServer {
  private server: Server | undefined;

  constructor(private readonly opts: ServerOptions) {}

  start(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.server = createServer((sock) => this.handleConnection(sock));
      this.server.on('error', (err) => {
        this.opts.onError?.(err as Error);
        reject(err);
      });
      this.server.listen(this.opts.socketPath, () => resolve());
    });
  }

  stop(): Promise<void> {
    return new Promise((resolve) => {
      if (!this.server) return resolve();
      this.server.close(() => resolve());
    });
  }

  private handleConnection(sock: Socket): void {
    const reassembler = new FrameReassembler();
    let handshakeDone = false;

    sock.on('data', async (chunk: Buffer) => {
      try {
        if (!handshakeDone) {
          const r = checkHandshake(chunk);
          if (!r.ok) {
            sock.end();
            return;
          }
          handshakeDone = true;
          // Echo the version byte to confirm the handshake.
          sock.write(handshakeBytes());
          // Any tail bytes after the handshake are the start of the
          // request frame.
          const tail = chunk.subarray(1);
          if (tail.byteLength > 0) {
            const frames = reassembler.push(tail);
            if (frames.length > 0) {
              await this.handleFrame(sock, frames[0]!);
            }
          }
          return;
        }
        const frames = reassembler.push(chunk);
        for (const frame of frames) {
          await this.handleFrame(sock, frame);
          break; // single request per connection
        }
      } catch (err) {
        this.opts.onError?.(err as Error);
        sock.end();
      }
    });

    sock.on('error', (err) => {
      this.opts.onError?.(err);
    });
  }

  private async handleFrame(sock: Socket, frame: Buffer): Promise<void> {
    let req: Request;
    try {
      req = decodeRequest(frame);
    } catch (err) {
      const res: Response = {
        ok: false,
        error: { code: 'BAD_REQUEST', message: (err as Error).message },
      };
      sock.write(encodeResponse(res));
      sock.end();
      return;
    }
    let res: Response;
    try {
      res = await this.opts.handle(req);
    } catch (err) {
      res = {
        ok: false,
        error: { code: 'INTERNAL', message: (err as Error).message },
      };
    }
    sock.write(encodeResponse(res));
    sock.end();
  }

  protocolVersion(): number {
    return PROTOCOL_VERSION;
  }
}
