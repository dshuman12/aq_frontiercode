// Worker pool.
//
// Holds a fixed number of worker slots. Handlers run inside `slot.run()`
// which wraps the user-supplied handler with the worker-side
// machinery (heartbeat to lease, abort signal, output capture). When a
// slot returns, it bumps free count and signals waiters.

import type { Handler, WorkResult } from '@tideway/worker';
import { run } from '@tideway/worker';

export interface PoolSlot {
  index: number;
  workerId: string;
  busy: boolean;
}

export interface DispatchTask<I, O> {
  runId: string;
  attempt: number;
  handler: Handler<I, O>;
  input: I;
  signal: AbortSignal;
  onHeartbeat?: () => void;
  onLog?: (level: 'info' | 'warn' | 'error', msg: string) => void;
}

export class WorkerPool {
  private readonly slots: PoolSlot[];
  private readonly waiters: Array<() => void> = [];
  private dispatched = 0;

  constructor(size: number) {
    if (size < 1) throw new RangeError(`pool size must be >= 1, got ${size}`);
    this.slots = Array.from({ length: size }, (_, i) => ({
      index: i,
      workerId: `worker-${i}`,
      busy: false,
    }));
  }

  size(): number {
    return this.slots.length;
  }

  busy(): number {
    return this.slots.filter((s) => s.busy).length;
  }

  free(): number {
    return this.slots.length - this.busy();
  }

  totalDispatched(): number {
    return this.dispatched;
  }

  // Acquire a free slot. Returns null if everything's busy.
  tryAcquire(): PoolSlot | null {
    const slot = this.slots.find((s) => !s.busy);
    if (!slot) return null;
    slot.busy = true;
    return slot;
  }

  // Wait until a slot becomes free. Used by the scheduler loop's
  // synchronous fallback path; in normal operation tryAcquire returns
  // immediately.
  awaitFree(): Promise<PoolSlot> {
    const slot = this.tryAcquire();
    if (slot) return Promise.resolve(slot);
    return new Promise((resolve) => {
      this.waiters.push(() => {
        const next = this.tryAcquire();
        if (next) resolve(next);
      });
    });
  }

  release(slot: PoolSlot): void {
    if (!slot.busy) return;
    slot.busy = false;
    const w = this.waiters.shift();
    if (w) w();
  }

  // Run the task in a slot, releasing on completion. Returns the
  // WorkResult; the caller decides what to do with it (transition the
  // runstate, persist, etc.).
  async dispatch<I, O>(task: DispatchTask<I, O>): Promise<WorkResult<O>> {
    const slot = await this.awaitFree();
    this.dispatched += 1;
    try {
      const result = await run(task.handler, task.input, {
        runId: task.runId,
        attempt: task.attempt,
        signal: task.signal,
        ...(task.onHeartbeat ? { onHeartbeat: task.onHeartbeat } : {}),
        ...(task.onLog ? { onLog: task.onLog } : {}),
      });
      return result;
    } finally {
      this.release(slot);
    }
  }
}
