// Submit API.
//
// The thing handlers and operators call to put work into the runtime.
// Splits into two paths: in-process (a function call from the embedding
// service) and over-the-wire (the console CLI uses this through the
// wire layer). Both end up at `submitOne` here.

import { Graph, type NodeId } from '@tideway/dag';
import type { DeadlinedNode } from '@tideway/deadline';
import { initialState, type RunState } from '@tideway/runstate';
import type { SchedulableNode } from '@tideway/scheduler';

export type WorkflowNode = SchedulableNode & DeadlinedNode & { handler: string; input: unknown };

export interface SubmitInput {
  // Caller-supplied id; if absent, generated.
  runId?: string;
  // Handler name. Must be registered with the runner.
  handler: string;
  // Input payload, opaque to the runtime.
  input: unknown;
  // Optional fields.
  idempotencyKey?: string;
  priority?: number;
  deadlineMs?: number; // relative; absolute computed from now
  queue?: string;
  parents?: string[]; // run ids of parents this submission depends on
}

export interface SubmitResult {
  runId: string;
  // True if the submission was deduplicated against an existing
  // idempotency entry. The caller may want to surface this.
  dedup: boolean;
}

const t = (n: number) => BigInt(n);

// Generate a run id. Format: "r-<random hex>". Not load-bearing for
// uniqueness (the registry catches collisions), just stable enough that
// operator-readable.
export function generateRunId(): string {
  let out = '';
  while (out.length < 12) {
    out += Math.floor(Math.random() * 0xffffffff)
      .toString(16)
      .padStart(8, '0');
  }
  return `r-${out.slice(0, 12)}`;
}

export interface SubmitContext {
  now: number;
  graph: Graph<WorkflowNode>;
  states: Map<NodeId, RunState>;
  // Called when the submission is fresh (not deduped).
  onCreated: (runId: string) => void;
}

export function submitOne(input: SubmitInput, ctx: SubmitContext): SubmitResult {
  const runId = input.runId ?? generateRunId();
  if (ctx.graph.has(runId)) {
    // Re-submission of the same run id. We treat this as a no-op, not
    // an error, because the caller might be retrying the submit itself
    // after a timeout where the prior call actually succeeded.
    return { runId, dedup: true };
  }

  const node: WorkflowNode = {
    handler: input.handler,
    input: input.input,
    queue: input.queue ?? 'default',
    priority: input.priority ?? 0,
    declaredDeadline: input.deadlineMs !== undefined ? ctx.now + input.deadlineMs : Infinity,
  };
  ctx.graph.addNode(runId, node);
  for (const parent of input.parents ?? []) {
    if (!ctx.graph.has(parent)) {
      throw new Error(`unknown parent: ${parent}`);
    }
    ctx.graph.addEdge(parent, runId);
  }
  ctx.states.set(runId, initialState(t(ctx.now)));
  ctx.onCreated(runId);
  return { runId, dedup: false };
}

// Validate a submission before adding it to the graph. The runner calls
// this before submitOne so that bad submissions don't dirty the graph.
export interface SubmitValidationError {
  field: string;
  message: string;
}

export function validateSubmit(
  input: SubmitInput,
  registeredHandlers: Set<string>,
): SubmitValidationError[] {
  const errors: SubmitValidationError[] = [];
  if (!input.handler) {
    errors.push({ field: 'handler', message: 'handler is required' });
  } else if (!registeredHandlers.has(input.handler)) {
    errors.push({ field: 'handler', message: `unknown handler: ${input.handler}` });
  }
  if (input.priority !== undefined && !Number.isInteger(input.priority)) {
    errors.push({ field: 'priority', message: 'priority must be an integer' });
  }
  if (input.deadlineMs !== undefined && (input.deadlineMs <= 0 || !Number.isFinite(input.deadlineMs))) {
    errors.push({ field: 'deadlineMs', message: 'deadlineMs must be > 0 and finite' });
  }
  if (input.idempotencyKey !== undefined && input.idempotencyKey.length > 256) {
    errors.push({ field: 'idempotencyKey', message: 'idempotencyKey must be <= 256 chars' });
  }
  if (input.parents !== undefined && !Array.isArray(input.parents)) {
    errors.push({ field: 'parents', message: 'parents must be an array of run ids' });
  }
  return errors;
}
