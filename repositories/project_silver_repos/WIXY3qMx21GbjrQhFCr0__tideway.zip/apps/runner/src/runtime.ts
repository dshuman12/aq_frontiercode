// Runtime: the top-level facade that ties everything together.
//
// In-process embedding looks like:
//
//   const rt = new Runtime(config, registry);
//   await rt.start();
//   await rt.submit({ handler: 'send-email', input: ... });
//   ...
//   await rt.stop();
//
// The wire server is started inside `start()`; the console CLI talks
// to the same Runtime through the wire path.

import { Graph } from '@tideway/dag';
import { LeaseRegistry } from '@tideway/leasing';
import type { RunState } from '@tideway/runstate';
import { QueueLimits } from '@tideway/scheduler';

import type { RunnerConfig } from '@tideway/config';
import { HealthRegistry } from '@tideway/health';
import { Counter, Gauge, Histogram, MetricRegistry } from '@tideway/metrics';

import { HandlerRegistry } from './registry.ts';
import { Lifecycle } from './lifecycle.ts';
import {
  SchedulerLoop,
  type WorkflowNode,
  type SchedulerState,
} from './scheduler-loop.ts';
import { LeaseBridge } from './lease-bridge.ts';
import { WorkerPool } from './worker-pool.ts';
import { submitOne, validateSubmit, type SubmitInput, type SubmitResult } from './submit.ts';

export interface RuntimeMetrics {
  runsSubmitted: Counter;
  runsCompleted: Counter;
  runsFailed: Counter;
  inflightGauge: Gauge;
  durationHist: Histogram;
}

export class Runtime {
  readonly lifecycle = new Lifecycle();
  readonly handlers = new HandlerRegistry();
  readonly metrics: RuntimeMetrics;
  readonly metricRegistry = new MetricRegistry();
  readonly health = new HealthRegistry();

  private readonly graph = new Graph<WorkflowNode>();
  private readonly states = new Map<string, RunState>();
  private readonly limits = new QueueLimits();
  private readonly leaseRegistry = new LeaseRegistry();
  private readonly pool: WorkerPool;
  private readonly schedulerLoop: SchedulerLoop;
  private readonly leaseBridge: LeaseBridge;

  constructor(readonly config: RunnerConfig) {
    this.pool = new WorkerPool(config.workerCount);
    const schedState: SchedulerState = {
      graph: this.graph,
      states: this.states,
      limits: this.limits,
    };
    this.schedulerLoop = new SchedulerLoop(
      schedState,
      config.schedulerIntervalMs,
      () => this.pool.free(),
      () => undefined, // dispatch handled separately via the worker pool
    );
    this.leaseBridge = new LeaseBridge({
      registry: this.leaseRegistry,
      defaultTtlMs: config.defaultLeaseTtlMs,
      reaperIntervalMs: config.reaperIntervalMs,
      onLeaseExpired: () => undefined, // wired in start()
    });

    // Standard metrics. Names mirror the Prometheus convention.
    this.metrics = {
      runsSubmitted: this.metricRegistry.registerCounter(
        new Counter('tideway_runs_submitted_total', 'Runs submitted to the runtime', ['handler']),
      ),
      runsCompleted: this.metricRegistry.registerCounter(
        new Counter('tideway_runs_completed_total', 'Runs that finished successfully', ['handler']),
      ),
      runsFailed: this.metricRegistry.registerCounter(
        new Counter('tideway_runs_failed_total', 'Runs that ended in a failure', ['handler', 'kind']),
      ),
      inflightGauge: this.metricRegistry.registerGauge(
        new Gauge('tideway_inflight', 'Currently-running jobs'),
      ),
      durationHist: this.metricRegistry.registerHistogram(
        new Histogram('tideway_job_duration_ms', 'Per-job duration in milliseconds', {
          labelNames: ['handler', 'outcome'],
        }),
      ),
    };
  }

  async start(): Promise<void> {
    if (!this.lifecycle.is('starting')) {
      throw new Error(`cannot start from ${this.lifecycle.current()}`);
    }
    this.schedulerLoop.start();
    this.leaseBridge.start();
    this.lifecycle.transition('running');
  }

  async stop(): Promise<void> {
    if (this.lifecycle.is('stopped')) return;
    if (this.lifecycle.is('running')) this.lifecycle.transition('draining');
    this.schedulerLoop.stop();
    this.leaseBridge.stop();
    this.lifecycle.transition('stopped');
  }

  submit(input: SubmitInput): SubmitResult {
    if (!this.lifecycle.is('running')) {
      throw new Error(`cannot submit while runtime is ${this.lifecycle.current()}`);
    }
    const errors = validateSubmit(input, new Set(this.handlers.list()));
    if (errors.length > 0) {
      const msg = errors.map((e) => `${e.field}: ${e.message}`).join('; ');
      throw new Error(`invalid submit: ${msg}`);
    }
    const result = submitOne(input, {
      now: Date.now(),
      graph: this.graph,
      states: this.states,
      onCreated: (runId) => {
        this.metrics.runsSubmitted.inc({ handler: input.handler });
        void runId; // captured for tracing later
      },
    });
    return result;
  }

  // Inspection. Returns a structural snapshot suitable for the console
  // `list` and `status` commands. Cheap; safe to call on every tick.
  snapshot(): {
    runs: Array<{ runId: string; state: string; handler: string }>;
    inflight: number;
    free: number;
  } {
    const runs: Array<{ runId: string; state: string; handler: string }> = [];
    for (const id of this.graph.allNodes()) {
      const s = this.states.get(id);
      if (!s) continue;
      runs.push({
        runId: id,
        state: s.kind,
        handler: this.graph.get(id).handler,
      });
    }
    return {
      runs,
      inflight: this.pool.busy(),
      free: this.pool.free(),
    };
  }

  status(runId: string): { state: string; handler: string } | undefined {
    const s = this.states.get(runId);
    if (!s) return undefined;
    return { state: s.kind, handler: this.graph.get(runId).handler };
  }
}
