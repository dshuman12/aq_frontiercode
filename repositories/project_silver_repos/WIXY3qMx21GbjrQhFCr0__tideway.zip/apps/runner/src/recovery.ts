// Crash recovery: at startup, replay the event log to rebuild
// in-memory state. Returns a structured `RecoveryReport` so the runner
// can log how many runs were recovered and how many had to be marked
// requeued (because their leases had expired during the outage).

import { replayAll, type LogEntry } from '@tideway/replay';
import type { RunState } from '@tideway/runstate';
import type { Store } from '@tideway/store';

export interface RecoveryReport {
  recoveredRuns: number;
  appliedEntries: number;
  skippedEntries: number;
  expiredLeasesRequeued: number;
  highWaterMark: number;
  states: Map<string, RunState>;
}

export interface RecoveryOptions {
  // The wall-clock time at which recovery starts. Used to detect leases
  // that expired during the outage. Defaults to Date.now().
  now?: number;
  // Cap on entries read from the store in one batch. Multiple batches
  // are read until the store returns fewer than `batchSize`. Default:
  // 10_000.
  batchSize?: number;
}

export async function recover(store: Store, opts: RecoveryOptions = {}): Promise<RecoveryReport> {
  const now = opts.now ?? Date.now();
  const batchSize = opts.batchSize ?? 10_000;

  const allEntries: LogEntry[] = [];
  let cursor = 0;
  while (true) {
    const batch = store.readLog({ sinceLsn: cursor, limit: batchSize });
    allEntries.push(...batch);
    if (batch.length < batchSize) break;
    cursor = batch[batch.length - 1]!.lsn;
  }

  const result = replayAll(allEntries);

  // Walk recovered states and detect any that are 'running' with an
  // expired lease. These need to be flipped back to queued so the
  // scheduler picks them up after recovery.
  let requeued = 0;
  for (const [runId, state] of result.states) {
    if (state.kind === 'running' && Number(state.leaseExpiresAt) <= now) {
      // Treat the run as if its lease just expired. We don't write a
      // lease_expire event here because writing more events during
      // recovery couples replay and persistence in an awkward way; the
      // runner does that immediately after recovery is finished, on
      // the live path.
      result.states.set(runId, { kind: 'queued', enqueuedAt: BigInt(now) });
      requeued += 1;
    }
  }

  return {
    recoveredRuns: result.states.size,
    appliedEntries: result.applied,
    skippedEntries: result.skipped,
    expiredLeasesRequeued: requeued,
    highWaterMark: result.lastLsn,
    states: result.states,
  };
}
