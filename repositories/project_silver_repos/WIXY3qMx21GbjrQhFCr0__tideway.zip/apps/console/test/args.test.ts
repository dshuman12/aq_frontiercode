import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { ArgError, HELP_TEXT, parse } from '../src/args.ts';

describe('parse: help', () => {
  it('empty -> help', () => {
    assert.equal(parse([]).command, 'help');
  });

  it('"help" -> help', () => {
    assert.equal(parse(['help']).command, 'help');
  });

  it('"--help" -> help', () => {
    assert.equal(parse(['--help']).command, 'help');
  });

  it('"-h" -> help', () => {
    assert.equal(parse(['-h']).command, 'help');
  });

  it('help with topic', () => {
    const r = parse(['help', 'submit']);
    assert.equal(r.command, 'help');
    if (r.command === 'help') assert.equal(r.topic, 'submit');
  });
});

describe('parse: submit', () => {
  it('parses required flags', () => {
    const r = parse(['submit', '--handler', 'send-email', '--input', '{"to":"a"}']);
    assert.equal(r.command, 'submit');
    if (r.command === 'submit') {
      assert.equal(r.handler, 'send-email');
      assert.equal(r.inputJson, '{"to":"a"}');
    }
  });

  it('rejects missing handler', () => {
    assert.throws(() => parse(['submit', '--input', '{}']), ArgError);
  });

  it('fails on missing input', () => {
    assert.throws(() => parse(['submit', '--handler', 'h']), ArgError);
  });

  it('parses optional flags', () => {
    const r = parse([
      'submit',
      '--handler',
      'h',
      '--input',
      '{}',
      '--idempotency-key',
      'k',
      '--priority',
      '5',
      '--deadline-ms',
      '60000',
      '--queue',
      'db',
    ]);
    if (r.command === 'submit') {
      assert.equal(r.idempotencyKey, 'k');
      assert.equal(r.priority, 5);
      assert.equal(r.deadlineMs, 60_000);
      assert.equal(r.queue, 'db');
    }
  });

  it('uses default socket if --socket not provided', () => {
    const r = parse(['submit', '--handler', 'h', '--input', '{}']);
    if (r.command === 'submit') {
      assert.match(r.socket, /tideway\.sock$/);
    }
  });

  it('honors --socket', () => {
    const r = parse(['submit', '--handler', 'h', '--input', '{}', '--socket', '/tmp/t.sock']);
    if (r.command === 'submit') assert.equal(r.socket, '/tmp/t.sock');
  });
});

describe('parse: status / cancel / tail', () => {
  it('status requires --run-id', () => {
    assert.throws(() => parse(['status']), ArgError);
  });

  it('status round-trips', () => {
    const r = parse(['status', '--run-id', 'r-1']);
    assert.equal(r.command, 'status');
  });

  it('cancel with optional --reason', () => {
    const r = parse(['cancel', '--run-id', 'r-1', '--reason', 'oops']);
    if (r.command === 'cancel') assert.equal(r.reason, 'oops');
  });

  it('tail requires --run-id', () => {
    assert.throws(() => parse(['tail']), ArgError);
  });
});

describe('parse: list', () => {
  it('defaults limit to 50', () => {
    const r = parse(['list']);
    if (r.command === 'list') assert.equal(r.limit, 50);
  });

  it('honors --limit and --state', () => {
    const r = parse(['list', '--limit', '200', '--state', 'running']);
    if (r.command === 'list') {
      assert.equal(r.limit, 200);
      assert.equal(r.state, 'running');
    }
  });
});

describe('parse: drain', () => {
  it('defaults to graceful', () => {
    const r = parse(['drain']);
    if (r.command === 'drain') assert.equal(r.graceful, true);
  });

  it('--force flips to non-graceful', () => {
    const r = parse(['drain', '--force']);
    if (r.command === 'drain') assert.equal(r.graceful, false);
  });
});

describe('parse: dlq', () => {
  it('inspect with filters', () => {
    const r = parse(['dlq', 'inspect', '--handler', 'h', '--failure-kind', 'permanent']);
    assert.equal(r.command, 'dlq.inspect');
    if (r.command === 'dlq.inspect') {
      assert.equal(r.handler, 'h');
      assert.equal(r.failureKind, 'permanent');
    }
  });

  it('replay with --run-id', () => {
    const r = parse(['dlq', 'replay', '--run-id', 'r-1']);
    assert.equal(r.command, 'dlq.replay');
  });

  it('drop requires --run-id', () => {
    assert.throws(() => parse(['dlq', 'drop']), ArgError);
  });

  it('bails on unknown dlq subcommand', () => {
    assert.throws(() => parse(['dlq', 'frobnicate']), ArgError);
  });
});

describe('parse: cron', () => {
  it('list-fires with --expr and default count', () => {
    const r = parse(['cron', 'list-fires', '--expr', '0 9 * * 1-5']);
    assert.equal(r.command, 'cron.list-fires');
    if (r.command === 'cron.list-fires') {
      assert.equal(r.expression, '0 9 * * 1-5');
      assert.equal(r.count, 5);
    }
  });

  it('list-fires with --count', () => {
    const r = parse(['cron', 'list-fires', '--expr', '* * * * *', '--count', '10']);
    if (r.command === 'cron.list-fires') assert.equal(r.count, 10);
  });
});

describe('parse: errors', () => {
  it('complains about unknown command', () => {
    assert.throws(() => parse(['obliterate']), ArgError);
  });
});

describe('HELP_TEXT', () => {
  it('mentions every subcommand', () => {
    for (const cmd of ['submit', 'status', 'tail', 'cancel', 'list', 'drain', 'dlq', 'cron']) {
      assert.match(HELP_TEXT, new RegExp(cmd));
    }
  });
});
