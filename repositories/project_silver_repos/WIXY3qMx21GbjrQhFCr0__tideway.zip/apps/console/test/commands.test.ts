import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import {
  runCancel,
  runCronListFires,
  runDlqDrop,
  runDlqInspect,
  runDlqReplay,
  runDrain,
  runList,
  runStatus,
  runSubmit,
  type CommandContext,
  type RuntimeClient,
} from '../src/commands.ts';

function fakeClient(overrides: Partial<RuntimeClient> = {}): RuntimeClient {
  return {
    submit: async () => ({ runId: 'r-fake', dedup: false }),
    status: async () => ({ state: 'running', handler: 'h', attempt: 1 }),
    list: async () => [],
    cancel: async () => ({ accepted: true }),
    drain: async () => ({ inflight: 0 }),
    dlqInspect: async () => [],
    dlqReplay: async () => [],
    dlqDrop: async () => ({ dropped: true }),
    ...overrides,
  };
}

function ctx(overrides: Partial<CommandContext> = {}): CommandContext & { stdout: string[]; stderr: string[] } {
  const stdout: string[] = [];
  const stderr: string[] = [];
  return {
    client: overrides.client ?? fakeClient(),
    out: (s) => stdout.push(s),
    err: (s) => stderr.push(s),
    color: overrides.color ?? false,
    now: overrides.now ?? (() => 1_000_000),
    stdout,
    stderr,
  };
}

describe('runSubmit', () => {
  it('returns 0 on success', async () => {
    const c = ctx();
    const code = await runSubmit(
      { command: 'submit', handler: 'h', inputJson: '{"a":1}', socket: '/tmp/s' },
      c,
    );
    assert.equal(code, 0);
    assert.match(c.stdout.join(''), /run r-fake/);
  });

  it('reports dedup on repeated submission', async () => {
    const c = ctx({
      client: fakeClient({
        submit: async () => ({ runId: 'r-fake', dedup: true }),
      }),
    });
    await runSubmit(
      { command: 'submit', handler: 'h', inputJson: '{}', socket: '/tmp/s' },
      c,
    );
    assert.match(c.stdout.join(''), /deduplicated/);
  });

  it('returns 2 on bad JSON input', async () => {
    const c = ctx();
    const code = await runSubmit(
      { command: 'submit', handler: 'h', inputJson: '{not json', socket: '/tmp/s' },
      c,
    );
    assert.equal(code, 2);
    assert.match(c.stderr.join(''), /must be valid JSON/);
  });

  it('passes optional fields through to the client', async () => {
    let captured: Parameters<RuntimeClient['submit']>[0] | undefined;
    const c = ctx({
      client: fakeClient({
        submit: async (opts) => {
          captured = opts;
          return { runId: 'r-fake', dedup: false };
        },
      }),
    });
    await runSubmit(
      {
        command: 'submit',
        handler: 'h',
        inputJson: '{}',
        idempotencyKey: 'k',
        priority: 5,
        deadlineMs: 10_000,
        queue: 'db',
        socket: '/tmp/s',
      },
      c,
    );
    assert.equal(captured?.idempotencyKey, 'k');
    assert.equal(captured?.priority, 5);
    assert.equal(captured?.deadlineMs, 10_000);
    assert.equal(captured?.queue, 'db');
  });
});

describe('runStatus', () => {
  it('reports state', async () => {
    const c = ctx();
    const code = await runStatus({ command: 'status', runId: 'r-1', socket: '/tmp/s' }, c);
    assert.equal(code, 0);
    assert.match(c.stdout.join(''), /state=running/);
  });

  it('reports unknown run as a failure', async () => {
    const c = ctx({
      client: fakeClient({ status: async () => undefined }),
    });
    const code = await runStatus({ command: 'status', runId: 'r-ghost', socket: '/tmp/s' }, c);
    assert.equal(code, 1);
    assert.match(c.stderr.join(''), /unknown run/);
  });

  it('shows duration when start+end available', async () => {
    const c = ctx({
      client: fakeClient({
        status: async () => ({
          state: 'succeeded',
          handler: 'h',
          attempt: 1,
          startedAt: 1000,
          finishedAt: 3500,
        }),
      }),
    });
    await runStatus({ command: 'status', runId: 'r-1', socket: '/tmp/s' }, c);
    assert.match(c.stdout.join(''), /duration=2\.5s/);
  });
});

describe('runList', () => {
  it('shows "(none)" when empty', async () => {
    const c = ctx();
    await runList({ command: 'list', limit: 50, socket: '/tmp/s' }, c);
    assert.match(c.stdout.join(''), /\(none\)/);
  });

  it('renders a table when populated', async () => {
    const c = ctx({
      client: fakeClient({
        list: async () => [
          { runId: 'r-1', state: 'running', handler: 'email', enqueuedAt: 999_000 },
          { runId: 'r-2', state: 'queued', handler: 'audit', enqueuedAt: 999_500 },
        ],
      }),
    });
    await runList({ command: 'list', limit: 50, socket: '/tmp/s' }, c);
    const out = c.stdout.join('');
    assert.match(out, /RUN ID/);
    assert.match(out, /r-1/);
    assert.match(out, /r-2/);
  });

  it('forwards state filter', async () => {
    let capturedFilter: { state?: string; limit?: number } | undefined;
    const c = ctx({
      client: fakeClient({
        list: async (f) => {
          capturedFilter = f;
          return [];
        },
      }),
    });
    await runList(
      { command: 'list', state: 'running', limit: 10, socket: '/tmp/s' },
      c,
    );
    assert.equal(capturedFilter?.state, 'running');
    assert.equal(capturedFilter?.limit, 10);
  });
});

describe('runCancel', () => {
  it('reports success', async () => {
    const c = ctx();
    const code = await runCancel({ command: 'cancel', runId: 'r-1', socket: '/tmp/s' }, c);
    assert.equal(code, 0);
    assert.match(c.stdout.join(''), /canceled r-1/);
  });

  it('reports rejection', async () => {
    const c = ctx({ client: fakeClient({ cancel: async () => ({ accepted: false }) }) });
    const code = await runCancel({ command: 'cancel', runId: 'r-1', socket: '/tmp/s' }, c);
    assert.equal(code, 1);
  });
});

describe('runDrain', () => {
  it('reports inflight count', async () => {
    const c = ctx({ client: fakeClient({ drain: async () => ({ inflight: 5 }) }) });
    await runDrain({ command: 'drain', graceful: true, socket: '/tmp/s' }, c);
    assert.match(c.stdout.join(''), /5 inflight/);
  });
});

describe('runDlqInspect', () => {
  it('shows "(none)" when empty', async () => {
    const c = ctx();
    await runDlqInspect({ command: 'dlq.inspect', limit: 50, socket: '/tmp/s' }, c);
    assert.match(c.stdout.join(''), /\(none\)/);
  });

  it('shows entries with handler/kind/attempt/message', async () => {
    const c = ctx({
      client: fakeClient({
        dlqInspect: async () => [
          {
            runId: 'r-1',
            handler: 'email',
            failureKind: 'permanent',
            message: 'smtp 550',
            finalAttempt: 3,
            enteredAt: 0,
            tags: ['network'],
          },
        ],
      }),
    });
    await runDlqInspect({ command: 'dlq.inspect', limit: 50, socket: '/tmp/s' }, c);
    const out = c.stdout.join('');
    assert.match(out, /handler=email/);
    assert.match(out, /attempt=3/);
    assert.match(out, /smtp 550/);
    assert.match(out, /network/);
  });
});

describe('runDlqReplay', () => {
  it('reports replay count', async () => {
    const c = ctx({
      client: fakeClient({
        dlqReplay: async () => [{ runId: 'r-1' }, { runId: 'r-2' }],
      }),
    });
    await runDlqReplay({ command: 'dlq.replay', socket: '/tmp/s' }, c);
    assert.match(c.stdout.join(''), /replayed 2 entries/);
  });
});

describe('runDlqDrop', () => {
  it('reports success', async () => {
    const c = ctx();
    const code = await runDlqDrop({ command: 'dlq.drop', runId: 'r-1', socket: '/tmp/s' }, c);
    assert.equal(code, 0);
  });

  it('reports not-in-dlq', async () => {
    const c = ctx({ client: fakeClient({ dlqDrop: async () => ({ dropped: false }) }) });
    const code = await runDlqDrop({ command: 'dlq.drop', runId: 'r-1', socket: '/tmp/s' }, c);
    assert.equal(code, 1);
  });
});

describe('runCronListFires', () => {
  it('emits ISO strings', async () => {
    const c = ctx();
    const code = await runCronListFires(
      { command: 'cron.list-fires', expression: '0 9 * * 1-5', count: 2 },
      c,
    );
    assert.equal(code, 0);
    const out = c.stdout.join('');
    assert.match(out, /^\d{4}-\d{2}-\d{2}T09:00:00\.000Z/m);
  });

  it('reports cron parse errors', async () => {
    const c = ctx();
    const code = await runCronListFires(
      { command: 'cron.list-fires', expression: 'garbage', count: 2 },
      c,
    );
    assert.equal(code, 1);
    assert.match(c.stderr.join(''), /cron error/);
  });
});
