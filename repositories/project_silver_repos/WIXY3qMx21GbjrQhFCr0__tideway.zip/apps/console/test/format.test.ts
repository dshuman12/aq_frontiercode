import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import {
  bytes,
  colorState,
  colorStatus,
  duration,
  emitJson,
  relativeTime,
  table,
} from '../src/format.ts';

describe('table', () => {
  it('renders header + separator + rows', () => {
    const out = table(
      [{ header: 'A' }, { header: 'B' }],
      [
        ['1', '2'],
        ['33', '44'],
      ],
    );
    const lines = out.split('\n');
    assert.equal(lines.length, 4);
    assert.match(lines[0]!, /A/);
    assert.match(lines[0]!, /B/);
  });

  it('right-aligns when requested', () => {
    const out = table(
      [{ header: 'X', align: 'right', width: 4 }],
      [['1'], ['22']],
    );
    const lines = out.split('\n');
    assert.match(lines[2]!, /^   1/);
    assert.match(lines[3]!, /^  22/);
  });

  it('handles empty rows', () => {
    const out = table([{ header: 'A' }], []);
    const lines = out.split('\n');
    assert.equal(lines.length, 2); // header + separator
  });
});

describe('bytes', () => {
  it('emits B for small numbers', () => {
    assert.equal(bytes(100), '100 B');
  });

  it('emits KB / MB / GB', () => {
    assert.equal(bytes(2048), '2.0 KB');
    assert.match(bytes(2 * 1024 * 1024), /MB$/);
    assert.match(bytes(3 * 1024 * 1024 * 1024), /GB$/);
  });

  it('caps at TB', () => {
    assert.match(bytes(5 * 1024 ** 4), /TB$/);
  });
});

describe('duration', () => {
  it('milliseconds', () => {
    assert.equal(duration(500), '500ms');
  });

  it('seconds', () => {
    assert.equal(duration(2500), '2.5s');
  });

  it('minutes-seconds', () => {
    assert.equal(duration(90_000), '1m30s');
  });

  it('hours-minutes', () => {
    assert.equal(duration(3 * 3_600_000 + 5 * 60_000), '3h5m');
  });
});

describe('relativeTime', () => {
  it('"just now" for very recent', () => {
    assert.equal(relativeTime(1000, 1500), 'just now');
  });

  it('"in the future" for negative delta', () => {
    assert.equal(relativeTime(2000, 1000), 'in the future');
  });

  it('"X ago" for older', () => {
    assert.match(relativeTime(0, 5000), /ago$/);
  });
});

describe('colorState / colorStatus', () => {
  it('returns the state name when no kleur dye', () => {
    // We can't easily detect ANSI without parsing; just check the output
    // contains the state string somewhere.
    const out = colorState('running');
    assert.match(out, /running/);
  });

  it('passes unknown states through', () => {
    const out = colorState('mystery_state');
    assert.match(out, /mystery_state/);
  });

  it('healthy / degraded / unhealthy round-trip the name', () => {
    assert.match(colorStatus('healthy'), /healthy/);
    assert.match(colorStatus('degraded'), /degraded/);
    assert.match(colorStatus('unhealthy'), /unhealthy/);
  });
});

describe('emitJson', () => {
  it('pretty-prints with trailing newline', () => {
    const out = emitJson({ a: 1, b: 'two' });
    assert.match(out, /\n$/);
    assert.match(out, /"a": 1/);
  });
});
