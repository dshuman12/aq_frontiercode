import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import {
  renderDlqEntry,
  renderError,
  renderList,
  renderRunSummary,
  renderUpcomingFires,
  type RunSummary,
} from '../src/render.ts';

const sum = (overrides: Partial<RunSummary> = {}): RunSummary => ({
  runId: 'r-1',
  handler: 'h',
  state: 'queued',
  attempt: 1,
  ...overrides,
});

describe('renderRunSummary', () => {
  it('contains all key facts', () => {
    const out = renderRunSummary(sum({ state: 'running' }), { color: false });
    assert.match(out, /run r-1/);
    assert.match(out, /state=running/);
    assert.match(out, /handler=h/);
    assert.match(out, /attempt=1/);
  });

  it('uncolored output has no ANSI codes', () => {
    const out = renderRunSummary(sum({ state: 'running' }), { color: false });
    assert.equal(out.includes('\x1b['), false);
  });
});

describe('renderList', () => {
  it('joins rows with newlines', () => {
    const out = renderList([sum({ runId: 'r-1' }), sum({ runId: 'r-2' })], { color: false });
    assert.equal(out.split('\n').length, 2);
  });

  it('returns "(none)" when empty', () => {
    assert.equal(renderList([]), '(none)');
  });
});

describe('renderDlqEntry', () => {
  it('formats with all fields', () => {
    const out = renderDlqEntry(
      {
        runId: 'r-1',
        handler: 'h',
        failureKind: 'permanent',
        message: 'boom',
        finalAttempt: 3,
        enteredAt: 1000,
        tags: ['alpha', 'beta'],
      },
      { color: false },
    );
    assert.match(out, /dlq r-1/);
    assert.match(out, /kind=permanent/);
    assert.match(out, /attempt=3/);
    assert.match(out, /alpha, beta/);
    assert.match(out, /-- boom/);
  });

  it('omits tag bracket when no tags', () => {
    const out = renderDlqEntry(
      {
        runId: 'r-1',
        handler: 'h',
        failureKind: 'retryable',
        message: 'x',
        finalAttempt: 1,
        enteredAt: 0,
        tags: [],
      },
      { color: false },
    );
    assert.equal(out.includes('['), false);
  });
});

describe('renderError', () => {
  it('prefixes with "error:"', () => {
    const out = renderError('oh no', { color: false });
    assert.match(out, /^error:/);
    assert.match(out, /oh no/);
  });
});

describe('renderUpcomingFires', () => {
  it('emits ISO strings', () => {
    const out = renderUpcomingFires([new Date('2026-05-08T09:00:00Z'), new Date('2026-05-09T09:00:00Z')]);
    assert.match(out, /2026-05-08T09:00:00\.000Z/);
    assert.match(out, /2026-05-09T09:00:00\.000Z/);
  });

  it('says "(no upcoming firings)" when empty', () => {
    assert.equal(renderUpcomingFires([]), '(no upcoming firings)');
  });
});
