// Output rendering for the `tideway` CLI.
//
// We use kleur for ANSI color (small, no transitive deps). All renderers
// take values + optional opts and return a string; the main CLI writes
// the string to stdout. This keeps every renderer trivially testable.

import kleur from 'kleur';

export interface RunSummary {
  runId: string;
  handler: string;
  state: string;
  attempt: number;
  enqueuedAt?: number;
  startedAt?: number;
  finishedAt?: number;
}

export function renderRunSummary(s: RunSummary, opts: { color?: boolean } = {}): string {
  const color = opts.color ?? true;
  const stateColor = color ? colorForState(s.state) : (str: string) => str;
  return [
    `run ${s.runId}`,
    `state=${stateColor(s.state)}`,
    `handler=${s.handler}`,
    `attempt=${s.attempt}`,
  ].join(' ');
}

export function renderList(rows: RunSummary[], opts: { color?: boolean } = {}): string {
  if (rows.length === 0) return '(none)';
  return rows.map((r) => renderRunSummary(r, opts)).join('\n');
}

export function renderDlqEntry(
  entry: {
    runId: string;
    handler: string;
    failureKind: string;
    message: string;
    finalAttempt: number;
    enteredAt: number;
    tags: string[];
  },
  opts: { color?: boolean } = {},
): string {
  const color = opts.color ?? true;
  const kind = color ? kleur.red(entry.failureKind) : entry.failureKind;
  const tags = entry.tags.length > 0 ? ` [${entry.tags.join(', ')}]` : '';
  return `dlq ${entry.runId} handler=${entry.handler} kind=${kind} attempt=${entry.finalAttempt}${tags} -- ${entry.message}`;
}

export function renderError(msg: string, opts: { color?: boolean } = {}): string {
  const color = opts.color ?? true;
  return `${color ? kleur.red('error:') : 'error:'} ${msg}`;
}

export function renderUpcomingFires(dates: Date[]): string {
  if (dates.length === 0) return '(no upcoming firings)';
  return dates.map((d) => d.toISOString()).join('\n');
}

function colorForState(state: string): (s: string) => string {
  switch (state) {
    case 'running':
      return kleur.cyan;
    case 'succeeded':
      return kleur.green;
    case 'failed':
    case 'timed_out':
      return kleur.red;
    case 'canceled':
      return kleur.gray;
    case 'queued':
    case 'retry_scheduled':
      return kleur.yellow;
    default:
      return (s: string) => s;
  }
}
