// Main CLI entrypoint. Parses argv, opens a wire connection to the
// runner socket, sends the request, and renders the response.
//
// This file is small because we want it to be: every interesting piece
// of logic lives in args.ts (parsing) or render.ts (output) and is
// exercised by unit tests directly. The main() function wires those
// together with the wire protocol; integration testing is what catches
// problems with that wiring.

import { connect } from 'node:net';
import {
  FrameReassembler,
  encodeRequest,
  decodeResponse,
  handshakeBytes,
  checkHandshake,
  type Request,
  type Response,
} from '@tideway/wire';

import { ArgError, HELP_TEXT, parse, type ParsedCommand } from './args.ts';
import { renderError } from './render.ts';

export { HELP_TEXT, parse } from './args.ts';

export async function send(socketPath: string, req: Request, timeoutMs = 5000): Promise<Response> {
  return new Promise((resolve, reject) => {
    const sock = connect(socketPath);
    const reassembler = new FrameReassembler();
    let handshakeDone = false;
    const timer = setTimeout(() => {
      sock.destroy();
      reject(new Error(`timed out after ${timeoutMs}ms`));
    }, timeoutMs);

    sock.on('connect', () => {
      sock.write(handshakeBytes());
    });
    sock.on('data', (chunk: Buffer) => {
      if (!handshakeDone) {
        const r = checkHandshake(chunk);
        if (!r.ok) {
          clearTimeout(timer);
          sock.destroy();
          reject(new Error(`handshake failed: peer version ${r.theirVersion}`));
          return;
        }
        handshakeDone = true;
        sock.write(encodeRequest(req));
        // Any tail bytes after the single handshake byte are part of
        // the response.
        const tail = chunk.subarray(1);
        if (tail.byteLength > 0) feedFromBuffer(tail);
        return;
      }
      feedFromBuffer(chunk);
    });
    sock.on('error', (err) => {
      clearTimeout(timer);
      reject(err);
    });
    sock.on('close', () => {
      clearTimeout(timer);
    });

    const feedFromBuffer = (chunk: Buffer): void => {
      const frames = reassembler.push(chunk);
      if (frames.length > 0) {
        clearTimeout(timer);
        try {
          const res = decodeResponse(frames[0]!);
          resolve(res);
        } catch (err) {
          reject(err);
        }
        sock.end();
      }
    };
  });
}

export async function main(argv: string[]): Promise<number> {
  let parsed: ParsedCommand;
  try {
    parsed = parse(argv);
  } catch (err) {
    if (err instanceof ArgError) {
      process.stderr.write(`${renderError(err.message)}\n${HELP_TEXT}`);
      return 2;
    }
    throw err;
  }
  if (parsed.command === 'help') {
    process.stdout.write(HELP_TEXT);
    return 0;
  }
  // Build the wire request from the parsed command.
  let req: Request;
  let socket: string;
  switch (parsed.command) {
    case 'submit': {
      let input: unknown;
      try {
        input = JSON.parse(parsed.inputJson);
      } catch {
        process.stderr.write(`${renderError('--input must be valid JSON')}\n`);
        return 2;
      }
      const submitReq: Request = {
        kind: 'submit',
        handler: parsed.handler,
        input,
        ...(parsed.idempotencyKey !== undefined ? { idempotencyKey: parsed.idempotencyKey } : {}),
        ...(parsed.priority !== undefined ? { priority: parsed.priority } : {}),
        ...(parsed.deadlineMs !== undefined ? { deadlineMs: parsed.deadlineMs } : {}),
        ...(parsed.queue !== undefined ? { queue: parsed.queue } : {}),
      };
      req = submitReq;
      socket = parsed.socket;
      break;
    }
    case 'status':
      req = { kind: 'status', runId: parsed.runId };
      socket = parsed.socket;
      break;
    case 'cancel':
      req = {
        kind: 'cancel',
        runId: parsed.runId,
        ...(parsed.reason !== undefined ? { reason: parsed.reason } : {}),
      };
      socket = parsed.socket;
      break;
    case 'list':
      req = {
        kind: 'list',
        ...(parsed.state !== undefined ? { state: parsed.state } : {}),
        limit: parsed.limit,
      };
      socket = parsed.socket;
      break;
    case 'drain':
      req = { kind: 'drain', graceful: parsed.graceful };
      socket = parsed.socket;
      break;
    case 'tail':
      req = { kind: 'status', runId: parsed.runId };
      socket = parsed.socket;
      break;
    case 'dlq.inspect':
    case 'dlq.replay':
    case 'dlq.drop':
      // Dlq subcommands all map to one wire request kind.
      req = { kind: 'replay-dlq' };
      socket = parsed.socket;
      break;
    case 'cron.list-fires':
      // No wire round-trip; resolved locally. Imported lazily so a
      // missing cron package doesn't break the rest of the CLI.
      try {
        const { parse: parseCron, upcomingFirings } = await import('@tideway/cron');
        const expr = parseCron(parsed.expression);
        const dates = upcomingFirings(expr, new Date(), parsed.count);
        for (const d of dates) process.stdout.write(`${d.toISOString()}\n`);
        return 0;
      } catch (err) {
        process.stderr.write(`${renderError((err as Error).message)}\n`);
        return 1;
      }
  }
  try {
    const res = await send(socket, req);
    process.stdout.write(`${JSON.stringify(res)}\n`);
    return res.ok ? 0 : 1;
  } catch (err) {
    process.stderr.write(`${renderError((err as Error).message)}\n`);
    return 1;
  }
}
