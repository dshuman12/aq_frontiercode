// Argument parser for the `tideway` CLI.
//
// Subcommands match the wire request kinds plus a few read-only helpers:
//   submit, status, tail, cancel, list, dlq inspect, dlq replay,
//   drain, cron list-fires.
//
// I tried using yargs/commander when first writing this and ended up
// pulling in a lot of dependency surface for what is at most a hundred
// lines of switch statements. Hand-rolled it is.

export type SubCommand =
  | 'submit'
  | 'status'
  | 'tail'
  | 'cancel'
  | 'list'
  | 'drain'
  | 'help'
  | 'dlq.inspect'
  | 'dlq.replay'
  | 'dlq.drop'
  | 'cron.list-fires';

export interface SubmitOptions {
  command: 'submit';
  handler: string;
  inputJson: string;
  idempotencyKey?: string;
  priority?: number;
  deadlineMs?: number;
  queue?: string;
  socket: string;
}

export interface StatusOptions {
  command: 'status';
  runId: string;
  socket: string;
}

export interface TailOptions {
  command: 'tail';
  runId: string;
  socket: string;
}

export interface CancelOptions {
  command: 'cancel';
  runId: string;
  reason?: string;
  socket: string;
}

export interface ListOptions {
  command: 'list';
  state?: string;
  limit: number;
  socket: string;
}

export interface DrainOptions {
  command: 'drain';
  graceful: boolean;
  socket: string;
}

export interface DlqInspectOptions {
  command: 'dlq.inspect';
  handler?: string;
  failureKind?: string;
  tag?: string;
  limit: number;
  socket: string;
}

export interface DlqReplayOptions {
  command: 'dlq.replay';
  runId?: string;
  handler?: string;
  failureKind?: string;
  socket: string;
}

export interface DlqDropOptions {
  command: 'dlq.drop';
  runId: string;
  socket: string;
}

export interface CronListFiresOptions {
  command: 'cron.list-fires';
  expression: string;
  count: number;
}

export interface HelpOptions {
  command: 'help';
  topic?: string;
}

export type ParsedCommand =
  | SubmitOptions
  | StatusOptions
  | TailOptions
  | CancelOptions
  | ListOptions
  | DrainOptions
  | DlqInspectOptions
  | DlqReplayOptions
  | DlqDropOptions
  | CronListFiresOptions
  | HelpOptions;

const DEFAULT_SOCKET = '/var/run/tideway.sock';

export class ArgError extends Error {
  override readonly name = 'ArgError';
}

export function parse(argv: string[]): ParsedCommand {
  if (argv.length === 0 || argv[0] === 'help' || argv[0] === '--help' || argv[0] === '-h') {
    return { command: 'help', ...(argv[1] ? { topic: argv[1] } : {}) };
  }
  const head = argv[0];
  switch (head) {
    case 'submit':
      return parseSubmit(argv.slice(1));
    case 'status':
      return parseStatus(argv.slice(1));
    case 'tail':
      return parseTail(argv.slice(1));
    case 'cancel':
      return parseCancel(argv.slice(1));
    case 'list':
      return parseList(argv.slice(1));
    case 'drain':
      return parseDrain(argv.slice(1));
    case 'dlq':
      return parseDlq(argv.slice(1));
    case 'cron':
      return parseCron(argv.slice(1));
    default:
      throw new ArgError(`unknown command: ${head}`);
  }
}

function parseSubmit(argv: string[]): SubmitOptions {
  const f = flags(argv);
  const handler = f.required('--handler');
  const inputJson = f.required('--input');
  const out: SubmitOptions = { command: 'submit', handler, inputJson, socket: f.socket() };
  const k = f.optional('--idempotency-key');
  if (k !== undefined) out.idempotencyKey = k;
  const p = f.optionalInt('--priority');
  if (p !== undefined) out.priority = p;
  const d = f.optionalInt('--deadline-ms');
  if (d !== undefined) out.deadlineMs = d;
  const q = f.optional('--queue');
  if (q !== undefined) out.queue = q;
  return out;
}

function parseStatus(argv: string[]): StatusOptions {
  const f = flags(argv);
  return { command: 'status', runId: f.required('--run-id'), socket: f.socket() };
}

function parseTail(argv: string[]): TailOptions {
  const f = flags(argv);
  return { command: 'tail', runId: f.required('--run-id'), socket: f.socket() };
}

function parseCancel(argv: string[]): CancelOptions {
  const f = flags(argv);
  const out: CancelOptions = {
    command: 'cancel',
    runId: f.required('--run-id'),
    socket: f.socket(),
  };
  const reason = f.optional('--reason');
  if (reason !== undefined) out.reason = reason;
  return out;
}

function parseList(argv: string[]): ListOptions {
  const f = flags(argv);
  const out: ListOptions = {
    command: 'list',
    limit: f.optionalInt('--limit') ?? 50,
    socket: f.socket(),
  };
  const state = f.optional('--state');
  if (state !== undefined) out.state = state;
  return out;
}

function parseDrain(argv: string[]): DrainOptions {
  const f = flags(argv);
  return {
    command: 'drain',
    graceful: !f.bool('--force'),
    socket: f.socket(),
  };
}

function parseDlq(argv: string[]): ParsedCommand {
  const sub = argv[0];
  if (sub === 'inspect') {
    const f = flags(argv.slice(1));
    const out: DlqInspectOptions = {
      command: 'dlq.inspect',
      limit: f.optionalInt('--limit') ?? 50,
      socket: f.socket(),
    };
    const handler = f.optional('--handler');
    if (handler !== undefined) out.handler = handler;
    const failureKind = f.optional('--failure-kind');
    if (failureKind !== undefined) out.failureKind = failureKind;
    const tag = f.optional('--tag');
    if (tag !== undefined) out.tag = tag;
    return out;
  }
  if (sub === 'replay') {
    const f = flags(argv.slice(1));
    const out: DlqReplayOptions = { command: 'dlq.replay', socket: f.socket() };
    const runId = f.optional('--run-id');
    if (runId !== undefined) out.runId = runId;
    const handler = f.optional('--handler');
    if (handler !== undefined) out.handler = handler;
    const failureKind = f.optional('--failure-kind');
    if (failureKind !== undefined) out.failureKind = failureKind;
    return out;
  }
  if (sub === 'drop') {
    const f = flags(argv.slice(1));
    return { command: 'dlq.drop', runId: f.required('--run-id'), socket: f.socket() };
  }
  throw new ArgError(`unknown dlq subcommand: ${sub}`);
}

function parseCron(argv: string[]): ParsedCommand {
  const sub = argv[0];
  if (sub === 'list-fires') {
    const f = flags(argv.slice(1));
    return {
      command: 'cron.list-fires',
      expression: f.required('--expr'),
      count: f.optionalInt('--count') ?? 5,
    };
  }
  throw new ArgError(`unknown cron subcommand: ${sub}`);
}

interface FlagReader {
  required(name: string): string;
  optional(name: string): string | undefined;
  optionalInt(name: string): number | undefined;
  bool(name: string): boolean;
  socket(): string;
}

function flags(argv: string[]): FlagReader {
  const map = new Map<string, string | true>();
  let i = 0;
  while (i < argv.length) {
    const arg = argv[i];
    if (!arg || !arg.startsWith('--')) {
      throw new ArgError(`expected flag, got: ${arg}`);
    }
    const next = argv[i + 1];
    if (next === undefined || next.startsWith('--')) {
      map.set(arg, true);
      i += 1;
    } else {
      map.set(arg, next);
      i += 2;
    }
  }
  return {
    required(name) {
      const v = map.get(name);
      if (v === undefined || v === true) throw new ArgError(`missing required flag ${name}`);
      return v;
    },
    optional(name) {
      const v = map.get(name);
      return v === true || v === undefined ? undefined : v;
    },
    optionalInt(name) {
      const v = map.get(name);
      if (v === true || v === undefined) return undefined;
      if (!/^-?[0-9]+$/.test(v)) throw new ArgError(`${name} must be an integer`);
      return Number(v);
    },
    bool(name) {
      return map.get(name) === true;
    },
    socket() {
      const v = map.get('--socket');
      return typeof v === 'string' ? v : DEFAULT_SOCKET;
    },
  };
}

export const HELP_TEXT = `tideway: control a tideway runner.

Commands:
  submit --handler H --input JSON [--idempotency-key K] [--priority N] [--deadline-ms N] [--queue Q]
  status --run-id ID
  tail --run-id ID
  cancel --run-id ID [--reason R]
  list [--state S] [--limit N]
  drain [--force]
  dlq inspect [--handler H] [--failure-kind K] [--tag T] [--limit N]
  dlq replay [--run-id ID | --handler H | --failure-kind K]
  dlq drop --run-id ID
  cron list-fires --expr "0 9 * * 1-5" [--count N]
  help [topic]

Global flags:
  --socket PATH    Path to the runner socket (default: ${DEFAULT_SOCKET})
`;
