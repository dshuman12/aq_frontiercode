// Output formatters that the various subcommands use.
//
// Each subcommand picks one of two output modes: human (default,
// kleur-colored, table-friendly) or json (--json flag). Formatters
// here take a typed value and return a string.

import kleur from 'kleur';

export interface ColumnSpec {
  header: string;
  width?: number;
  align?: 'left' | 'right';
}

export function table(columns: ColumnSpec[], rows: string[][]): string {
  const widths = columns.map((c, i) => {
    const headerW = c.header.length;
    const dataW = rows.length === 0 ? 0 : Math.max(...rows.map((r) => (r[i] ?? '').length));
    return c.width ?? Math.max(headerW, dataW);
  });
  const header = columns.map((c, i) => pad(c.header, widths[i]!, c.align ?? 'left')).join('  ');
  const sep = widths.map((w) => '-'.repeat(w)).join('  ');
  const body = rows.map((row) =>
    row.map((cell, i) => pad(cell ?? '', widths[i]!, columns[i]?.align ?? 'left')).join('  '),
  );
  return [header, sep, ...body].join('\n');
}

function pad(s: string, w: number, align: 'left' | 'right'): string {
  if (s.length >= w) return s;
  const padding = ' '.repeat(w - s.length);
  return align === 'right' ? padding + s : s + padding;
}

export function bytes(n: number): string {
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let size = n;
  let i = 0;
  while (size >= 1024 && i < units.length - 1) {
    size /= 1024;
    i += 1;
  }
  return `${size.toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
}

export function duration(ms: number): string {
  if (ms < 1000) return `${ms}ms`;
  if (ms < 60_000) return `${(ms / 1000).toFixed(1)}s`;
  if (ms < 3_600_000) return `${Math.floor(ms / 60_000)}m${Math.floor((ms % 60_000) / 1000)}s`;
  return `${Math.floor(ms / 3_600_000)}h${Math.floor((ms % 3_600_000) / 60_000)}m`;
}

export function relativeTime(thenMs: number, nowMs: number = Date.now()): string {
  const delta = nowMs - thenMs;
  if (delta < 0) return 'in the future';
  if (delta < 1000) return 'just now';
  return `${duration(delta)} ago`;
}

export function colorState(state: string): string {
  switch (state) {
    case 'running':
      return kleur.cyan(state);
    case 'succeeded':
      return kleur.green(state);
    case 'failed':
    case 'timed_out':
      return kleur.red(state);
    case 'canceled':
      return kleur.gray(state);
    case 'queued':
    case 'retry_scheduled':
      return kleur.yellow(state);
    default:
      return state;
  }
}

export function colorStatus(status: string): string {
  switch (status) {
    case 'healthy':
      return kleur.green(status);
    case 'degraded':
      return kleur.yellow(status);
    case 'unhealthy':
      return kleur.red(status);
    default:
      return status;
  }
}

export function emitJson(value: unknown): string {
  return JSON.stringify(value, null, 2) + '\n';
}
