// Per-subcommand handler functions.
//
// Each handler takes a typed options object (parsed from argv) and a
// "client" abstraction for talking to the runner. The client is
// dependency-injected so that tests can use a fake; production wires it
// to the wire-protocol path.

import {
  bytes,
  colorState,
  colorStatus,
  duration,
  emitJson,
  relativeTime,
  table,
} from './format.ts';
import type {
  SubmitOptions,
  StatusOptions,
  ListOptions,
  CancelOptions,
  DrainOptions,
  DlqInspectOptions,
  DlqReplayOptions,
  DlqDropOptions,
  TailOptions,
  CronListFiresOptions,
} from './args.ts';

export interface RuntimeClient {
  submit(opts: { handler: string; input: unknown; idempotencyKey?: string; priority?: number; deadlineMs?: number; queue?: string }): Promise<{ runId: string; dedup: boolean }>;
  status(runId: string): Promise<{ state: string; handler: string; attempt?: number; startedAt?: number; finishedAt?: number } | undefined>;
  list(filter?: { state?: string; limit?: number }): Promise<Array<{ runId: string; state: string; handler: string; enqueuedAt?: number }>>;
  cancel(runId: string, reason?: string): Promise<{ accepted: boolean }>;
  drain(graceful: boolean): Promise<{ inflight: number }>;
  dlqInspect(filter?: { handler?: string; failureKind?: string; tag?: string; limit?: number }): Promise<Array<{ runId: string; handler: string; failureKind: string; message: string; finalAttempt: number; enteredAt: number; tags: string[] }>>;
  dlqReplay(filter?: { runId?: string; handler?: string; failureKind?: string }): Promise<Array<{ runId: string }>>;
  dlqDrop(runId: string): Promise<{ dropped: boolean }>;
}

export interface CommandContext {
  client: RuntimeClient;
  out: (s: string) => void;
  err: (s: string) => void;
  // Optional override for color. Defaults to true; tests pass false to
  // make assertions readable.
  color: boolean;
  // Optional now() for relative-time formatting.
  now: () => number;
}

const ok = 0;
const fail = 1;
const usage = 2;

export async function runSubmit(opts: SubmitOptions, ctx: CommandContext): Promise<number> {
  let input: unknown;
  try {
    input = JSON.parse(opts.inputJson);
  } catch (err) {
    ctx.err(`error: --input must be valid JSON: ${(err as Error).message}\n`);
    return usage;
  }
  const result = await ctx.client.submit({
    handler: opts.handler,
    input,
    ...(opts.idempotencyKey !== undefined ? { idempotencyKey: opts.idempotencyKey } : {}),
    ...(opts.priority !== undefined ? { priority: opts.priority } : {}),
    ...(opts.deadlineMs !== undefined ? { deadlineMs: opts.deadlineMs } : {}),
    ...(opts.queue !== undefined ? { queue: opts.queue } : {}),
  });
  ctx.out(`run ${result.runId}${result.dedup ? ' (deduplicated)' : ''}\n`);
  return ok;
}

export async function runStatus(opts: StatusOptions, ctx: CommandContext): Promise<number> {
  const r = await ctx.client.status(opts.runId);
  if (!r) {
    ctx.err(`unknown run: ${opts.runId}\n`);
    return fail;
  }
  const stateColored = ctx.color ? colorState(r.state) : r.state;
  let line = `run ${opts.runId} state=${stateColored} handler=${r.handler}`;
  if (r.attempt !== undefined) line += ` attempt=${r.attempt}`;
  if (r.startedAt !== undefined && r.finishedAt !== undefined) {
    line += ` duration=${duration(r.finishedAt - r.startedAt)}`;
  }
  ctx.out(line + '\n');
  return ok;
}

export async function runTail(opts: TailOptions, ctx: CommandContext): Promise<number> {
  // Today this is a one-shot status with a poll loop disabled. The
  // streaming version comes in a later release; until then, "tail" is
  // an alias for "status" that the operator can run in a watch loop.
  return runStatus({ command: 'status', runId: opts.runId, socket: opts.socket }, ctx);
}

export async function runList(opts: ListOptions, ctx: CommandContext): Promise<number> {
  const filter: { state?: string; limit?: number } = { limit: opts.limit };
  if (opts.state !== undefined) filter.state = opts.state;
  const rows = await ctx.client.list(filter);
  if (rows.length === 0) {
    ctx.out('(none)\n');
    return ok;
  }
  const out = table(
    [
      { header: 'RUN ID' },
      { header: 'STATE' },
      { header: 'HANDLER' },
      { header: 'ENQUEUED' },
    ],
    rows.map((r) => [
      r.runId,
      ctx.color ? colorState(r.state) : r.state,
      r.handler,
      r.enqueuedAt !== undefined ? relativeTime(r.enqueuedAt, ctx.now()) : '',
    ]),
  );
  ctx.out(out + '\n');
  return ok;
}

export async function runCancel(opts: CancelOptions, ctx: CommandContext): Promise<number> {
  const result = await ctx.client.cancel(opts.runId, opts.reason);
  if (!result.accepted) {
    ctx.err(`cancel rejected: run ${opts.runId} not eligible\n`);
    return fail;
  }
  ctx.out(`canceled ${opts.runId}\n`);
  return ok;
}

export async function runDrain(opts: DrainOptions, ctx: CommandContext): Promise<number> {
  const result = await ctx.client.drain(opts.graceful);
  ctx.out(`drain initiated; ${result.inflight} inflight\n`);
  return ok;
}

export async function runDlqInspect(opts: DlqInspectOptions, ctx: CommandContext): Promise<number> {
  const filter: { handler?: string; failureKind?: string; tag?: string; limit?: number } = {
    limit: opts.limit,
  };
  if (opts.handler !== undefined) filter.handler = opts.handler;
  if (opts.failureKind !== undefined) filter.failureKind = opts.failureKind;
  if (opts.tag !== undefined) filter.tag = opts.tag;
  const entries = await ctx.client.dlqInspect(filter);
  if (entries.length === 0) {
    ctx.out('(none)\n');
    return ok;
  }
  for (const e of entries) {
    const tags = e.tags.length > 0 ? ` [${e.tags.join(', ')}]` : '';
    const kind = ctx.color ? colorState(e.failureKind === 'permanent' ? 'failed' : e.failureKind) : e.failureKind;
    ctx.out(
      `dlq ${e.runId} handler=${e.handler} kind=${kind} attempt=${e.finalAttempt}${tags} -- ${e.message}\n`,
    );
  }
  return ok;
}

export async function runDlqReplay(opts: DlqReplayOptions, ctx: CommandContext): Promise<number> {
  const filter: { runId?: string; handler?: string; failureKind?: string } = {};
  if (opts.runId !== undefined) filter.runId = opts.runId;
  if (opts.handler !== undefined) filter.handler = opts.handler;
  if (opts.failureKind !== undefined) filter.failureKind = opts.failureKind;
  const replayed = await ctx.client.dlqReplay(filter);
  ctx.out(`replayed ${replayed.length} entries\n`);
  for (const r of replayed) {
    ctx.out(`  ${r.runId}\n`);
  }
  return ok;
}

export async function runDlqDrop(opts: DlqDropOptions, ctx: CommandContext): Promise<number> {
  const result = await ctx.client.dlqDrop(opts.runId);
  if (!result.dropped) {
    ctx.err(`run ${opts.runId} not in dlq\n`);
    return fail;
  }
  ctx.out(`dropped ${opts.runId}\n`);
  return ok;
}

export async function runCronListFires(opts: CronListFiresOptions, ctx: CommandContext): Promise<number> {
  // Local computation; no client round-trip.
  try {
    const { parse, upcomingFirings } = await import('@tideway/cron');
    const expr = parse(opts.expression);
    const dates = upcomingFirings(expr, new Date(), opts.count);
    if (dates.length === 0) {
      ctx.out('(no upcoming firings)\n');
      return ok;
    }
    for (const d of dates) ctx.out(`${d.toISOString()}\n`);
    return ok;
  } catch (err) {
    ctx.err(`cron error: ${(err as Error).message}\n`);
    return fail;
  }
}

// Convenience for build-summary, a status of the runtime as a whole.
export async function summarizeRuntime(
  result: { inflight: number; free: number; runs: Array<{ state: string }> },
  ctx: CommandContext,
): Promise<void> {
  const counts: Record<string, number> = {};
  for (const r of result.runs) counts[r.state] = (counts[r.state] ?? 0) + 1;
  ctx.out(`inflight: ${result.inflight}, free workers: ${result.free}\n`);
  for (const [state, n] of Object.entries(counts)) {
    const colored = ctx.color ? colorState(state) : state;
    ctx.out(`  ${colored.padEnd(20)} ${n}\n`);
  }
  // Also write health line once we have the data.
  void colorStatus;
  void bytes;
  void emitJson;
}
