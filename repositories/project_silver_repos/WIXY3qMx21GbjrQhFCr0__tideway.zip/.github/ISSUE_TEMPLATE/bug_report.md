---
name: Bug report
about: Something isn't doing what you expect
labels: bug
---

## What happened

A clear description of the unexpected behavior.

## What I expected

What should have happened instead.

## Reproduction

Smallest reproduction you can manage. Include:

- runner version (`tideway --version` or git SHA)
- node version
- relevant config snippet
- a sequence of console commands or a small script

## Logs

Anything from the runner's stderr, especially around the time of the issue.

## Environment

- OS:
- node:
- tideway:
