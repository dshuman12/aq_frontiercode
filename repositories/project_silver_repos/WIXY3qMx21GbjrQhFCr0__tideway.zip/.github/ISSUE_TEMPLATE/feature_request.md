---
name: Feature request
about: A new capability or significant change to existing behavior
labels: enhancement
---

## What

The proposed feature.

## Why

The use case. Concrete is better than abstract: "I'm building X, I hit Y, I want Z" beats "tideway should support general Z".

## Have you considered an RFC?

For anything that changes documented decisions, please draft an RFC under `docs/rfcs/` and link it here. The RFC review is where the actual design discussion lives; the issue tracker is for catching regressions and small additions.

## Alternatives

What else could solve the underlying problem.
