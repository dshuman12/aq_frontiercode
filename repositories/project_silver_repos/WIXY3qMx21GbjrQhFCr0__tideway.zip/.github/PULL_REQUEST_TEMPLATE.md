## What

Briefly describe what this PR changes and why.

## Test plan

- [ ] `npm run ci` is green locally
- [ ] If this changes runtime behavior, an integration test under `tests/integration/` was added or updated
- [ ] If this changes a documented decision, the relevant RFC was updated

## Notes

Anything reviewers should know that isn't obvious from the diff. Tradeoffs you considered, alternatives you rejected, things that scared you, things that surprised you.

## Migration

If this is breaking for downstream consumers, describe what they need to do.
