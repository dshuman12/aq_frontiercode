import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { extract, validate, transform, load, notify, type RawRow } from '../src/handlers.ts';

const ctxFor = () => {
  const logs: string[] = [];
  return {
    ctx: {
      signal: new AbortController().signal,
      runId: 'r-test',
      attempt: 1,
      heartbeat: () => undefined,
      log: (level: string, msg: string) => logs.push(`${level}: ${msg}`),
    },
    logs,
  };
};

describe('extract', () => {
  it('produces pageSize rows', async () => {
    const { ctx } = ctxFor();
    const out = await extract(ctx, { sourceUri: 's3://x', since: 0, pageSize: 5 });
    assert.equal(out.rows.length, 5);
  });

  it('logs the source uri', async () => {
    const { ctx, logs } = ctxFor();
    await extract(ctx, { sourceUri: 's3://x', since: 0, pageSize: 1 });
    assert.ok(logs.some((l) => l.includes('s3://x')));
  });

  it('produces stable row ids based on (since, index)', async () => {
    const { ctx } = ctxFor();
    const a = await extract(ctx, { sourceUri: 'x', since: 1000, pageSize: 3 });
    const b = await extract(ctx, { sourceUri: 'x', since: 1000, pageSize: 3 });
    assert.deepEqual(a.rows.map((r) => r.id), b.rows.map((r) => r.id));
  });
});

describe('validate', () => {
  const sampleRow = (overrides: Partial<RawRow> = {}): RawRow => ({
    id: 'row-1',
    payload: { value: 1, label: 'one' },
    source: 'x',
    receivedAt: 0,
    ...overrides,
  });

  it('separates valid from rejected', () => {
    const { ctx } = ctxFor();
    const out = validate(ctx, {
      rows: [
        sampleRow({ id: 'a' }),
        sampleRow({ id: 'b', payload: null as unknown as Record<string, unknown> }),
      ],
    });
    assert.equal(out.valid.length, 1);
    assert.equal(out.rejected.length, 1);
    assert.equal(out.rejected[0]!.reason, 'payload is not an object');
  });

  it('warns on missing fields without rejecting', () => {
    const { ctx } = ctxFor();
    const out = validate(ctx, { rows: [sampleRow({ payload: { value: 1 } })] });
    assert.equal(out.valid.length, 1);
    assert.deepEqual(out.valid[0]!.warnings, ['missing label field']);
  });
});

describe('transform', () => {
  it('coerces stringified numbers', () => {
    const { ctx } = ctxFor();
    const out = transform(ctx, {
      rows: [
        {
          id: 'r-1',
          payload: { value: '42', label: 'x' },
          source: 's',
          receivedAt: 0,
          warnings: [],
        },
      ],
    });
    assert.equal(out.rows[0]!.amount, 42);
  });

  it('throws JobFailure on unparseable value', () => {
    const { ctx } = ctxFor();
    assert.throws(() =>
      transform(ctx, {
        rows: [
          {
            id: 'r-1',
            payload: { value: 'not-a-number', label: 'x' },
            source: 's',
            receivedAt: 0,
            warnings: [],
          },
        ],
      }),
    );
  });
});

describe('load', () => {
  it('reports inserted and duplicate counts', async () => {
    const { ctx } = ctxFor();
    const out = await load(ctx, {
      target: 'pg://x',
      rows: [
        { id: '1', ts: 0, category: 'a', amount: 1, source: 's' },
        { id: '1', ts: 0, category: 'a', amount: 1, source: 's' }, // duplicate id
        { id: '2', ts: 0, category: 'a', amount: 2, source: 's' },
      ],
    });
    assert.equal(out.inserted, 2);
    assert.equal(out.duplicates, 1);
  });
});

describe('notify', () => {
  it('returns sent count = recipient count', async () => {
    const { ctx } = ctxFor();
    const out = await notify(ctx, {
      recipients: ['a@x', 'b@x', 'c@x'],
      subject: 's',
      body: 'b',
    });
    assert.equal(out.sent, 3);
  });

  it('returns 0 sent for empty recipient list', async () => {
    const { ctx } = ctxFor();
    const out = await notify(ctx, { recipients: [], subject: 's', body: 'b' });
    assert.equal(out.sent, 0);
  });
});
