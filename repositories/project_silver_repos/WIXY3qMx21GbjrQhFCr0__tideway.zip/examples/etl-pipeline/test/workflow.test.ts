import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { buildSteps, validateSteps, type PipelineConfig } from '../src/workflow.ts';

const config: PipelineConfig = {
  sourceUri: 's3://my-bucket/data',
  targetUri: 'pg://warehouse/events',
  notifyRecipients: ['ops@example.com'],
  pageSize: 100,
};

describe('buildSteps', () => {
  it('produces 5 steps for the standard pipeline', () => {
    const steps = buildSteps('run-1', config);
    assert.equal(steps.length, 5);
  });

  it('the parent chain is linear extract -> notify', () => {
    const steps = buildSteps('run-1', config);
    const [extract, validate, transform, load, notify] = steps;
    assert.deepEqual(extract!.parents, []);
    assert.deepEqual(validate!.parents, [extract!.id]);
    assert.deepEqual(transform!.parents, [validate!.id]);
    assert.deepEqual(load!.parents, [transform!.id]);
    assert.deepEqual(notify!.parents, [load!.id]);
  });

  it('inputBuilder for extract pulls from config', () => {
    const steps = buildSteps('run-1', config);
    const ctx = { runId: 'run-1', config, outputs: new Map() };
    const input = steps[0]!.inputBuilder(ctx) as { sourceUri: string; pageSize: number };
    assert.equal(input.sourceUri, 's3://my-bucket/data');
    assert.equal(input.pageSize, 100);
  });

  it('inputBuilder for validate pulls from extract output', () => {
    const steps = buildSteps('run-1', config);
    const ctx = {
      runId: 'run-1',
      config,
      outputs: new Map<string, unknown>([
        ['run-1-extract', { rows: [{ id: 'a' }, { id: 'b' }] }],
      ]),
    };
    const input = steps[1]!.inputBuilder(ctx) as { rows: unknown[] };
    assert.equal(input.rows.length, 2);
  });

  it('inputBuilder for notify produces a recap message', () => {
    const steps = buildSteps('run-1', config);
    const ctx = {
      runId: 'run-1',
      config,
      outputs: new Map<string, unknown>([
        ['run-1-load', { inserted: 100, duplicates: 5 }],
      ]),
    };
    const input = steps[4]!.inputBuilder(ctx) as { body: string; subject: string };
    assert.match(input.body, /Loaded 100 rows/);
    assert.match(input.body, /5 duplicates/);
  });
});

describe('validateSteps', () => {
  it('accepts the standard pipeline', () => {
    const r = validateSteps(buildSteps('run-1', config));
    assert.equal(r.ok, true);
    assert.deepEqual(r.errors, []);
  });

  it('rejects duplicate step ids', () => {
    const steps = buildSteps('run-1', config);
    steps.push({ ...steps[0]! });
    const r = validateSteps(steps);
    assert.equal(r.ok, false);
    assert.match(r.errors[0]!, /duplicate step id/);
  });

  it('fails on self-parent', () => {
    const steps = buildSteps('run-1', config);
    steps[0]!.parents = [steps[0]!.id];
    const r = validateSteps(steps);
    assert.equal(r.ok, false);
    assert.match(r.errors[0]!, /lists itself as a parent/);
  });

  it('bails on forward-reference parent', () => {
    const steps = buildSteps('run-1', config);
    steps[0]!.parents = [steps[2]!.id];
    const r = validateSteps(steps);
    assert.equal(r.ok, false);
    assert.match(r.errors[0]!, /not declared earlier/);
  });
});
