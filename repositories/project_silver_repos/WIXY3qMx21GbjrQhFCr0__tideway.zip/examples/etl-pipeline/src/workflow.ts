// ETL pipeline workflow definition.
//
// Wires the five handlers from handlers.ts into a DAG. The shape:
//
//   extract -> validate -> transform -> load -> notify
//
// Each step depends on the previous one's success. A real production
// workflow would also have:
//   - a sentinel "no new data" branch from extract that skips the rest
//   - a separate path for the rejected rows that go to a human queue
//
// This example keeps it simple to stay focused on the runtime's API.

export interface PipelineConfig {
  sourceUri: string;
  targetUri: string;
  notifyRecipients: string[];
  pageSize: number;
}

// Definition of a single step in the workflow. The runtime consumes
// these via the submit API.
export interface StepDef {
  id: string;
  handler: string;
  parents: string[];
  inputBuilder: (ctx: WorkflowContext) => unknown;
}

export interface WorkflowContext {
  runId: string;
  config: PipelineConfig;
  // Outputs from prior steps, keyed by step id. The workflow builder
  // populates this as it walks.
  outputs: Map<string, unknown>;
}

export function buildSteps(runId: string, config: PipelineConfig): StepDef[] {
  return [
    {
      id: `${runId}-extract`,
      handler: 'etl.extract',
      parents: [],
      inputBuilder: () => ({
        sourceUri: config.sourceUri,
        since: Date.now() - 24 * 60 * 60 * 1000,
        pageSize: config.pageSize,
      }),
    },
    {
      id: `${runId}-validate`,
      handler: 'etl.validate',
      parents: [`${runId}-extract`],
      inputBuilder: (ctx) => ({
        rows: (ctx.outputs.get(`${runId}-extract`) as { rows: unknown[] })?.rows ?? [],
      }),
    },
    {
      id: `${runId}-transform`,
      handler: 'etl.transform',
      parents: [`${runId}-validate`],
      inputBuilder: (ctx) => ({
        rows: (ctx.outputs.get(`${runId}-validate`) as { valid: unknown[] })?.valid ?? [],
      }),
    },
    {
      id: `${runId}-load`,
      handler: 'etl.load',
      parents: [`${runId}-transform`],
      inputBuilder: (ctx) => ({
        rows: (ctx.outputs.get(`${runId}-transform`) as { rows: unknown[] })?.rows ?? [],
        target: config.targetUri,
      }),
    },
    {
      id: `${runId}-notify`,
      handler: 'etl.notify',
      parents: [`${runId}-load`],
      inputBuilder: (ctx) => {
        const loadResult = ctx.outputs.get(`${runId}-load`) as
          | { inserted: number; duplicates: number }
          | undefined;
        const inserted = loadResult?.inserted ?? 0;
        const duplicates = loadResult?.duplicates ?? 0;
        return {
          recipients: config.notifyRecipients,
          subject: `ETL pipeline ${runId} complete`,
          body: `Loaded ${inserted} rows (${duplicates} duplicates skipped) from ${config.sourceUri}.`,
        };
      },
    },
  ];
}

// Validate that the steps form a legitimate DAG: every parent reference
// points at an earlier step in the list, no cycles, no self-references.
export function validateSteps(steps: StepDef[]): { ok: boolean; errors: string[] } {
  const errors: string[] = [];
  const ids = new Set<string>();
  for (let i = 0; i < steps.length; i += 1) {
    const step = steps[i]!;
    if (ids.has(step.id)) {
      errors.push(`duplicate step id: ${step.id}`);
    }
    ids.add(step.id);
    for (const p of step.parents) {
      if (p === step.id) {
        errors.push(`step ${step.id} lists itself as a parent`);
      }
      if (!ids.has(p)) {
        errors.push(`step ${step.id} parent ${p} is not declared earlier`);
      }
    }
  }
  return { ok: errors.length === 0, errors };
}
