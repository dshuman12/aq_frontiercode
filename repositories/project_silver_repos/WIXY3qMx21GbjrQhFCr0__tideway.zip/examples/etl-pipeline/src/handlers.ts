// ETL pipeline example handlers.
//
// Five handlers that together form a daily-ingest workflow:
//   - extract: pull rows from an external source (here: synthetic)
//   - validate: schema-check each row, separate good from bad
//   - transform: enrich, type-coerce, normalize
//   - load: insert into the target store
//   - notify: send a summary email
//
// Each handler is small and focused. The interesting part is how they
// chain together via the runtime's submit API; see workflow.ts.

import { JobFailure, Retryable } from '@tideway/failure';
import type { Handler } from '@tideway/worker';

export interface RawRow {
  id: string;
  payload: Record<string, unknown>;
  source: string;
  receivedAt: number;
}

export interface ValidatedRow {
  id: string;
  payload: Record<string, unknown>;
  source: string;
  receivedAt: number;
  warnings: string[];
}

export interface TransformedRow {
  id: string;
  ts: number;
  category: string;
  amount: number;
  source: string;
}

export interface ExtractInput {
  sourceUri: string;
  since: number; // ms since epoch
  pageSize: number;
}

export interface ExtractOutput {
  rows: RawRow[];
  cursor: string | null;
}

export const extract: Handler<ExtractInput, ExtractOutput> = async (ctx, input) => {
  ctx.log('info', `extract: source=${input.sourceUri} since=${input.since}`);
  // Simulated: produce N synthetic rows. A real handler would call out
  // to whatever the source uri represents.
  const rows: RawRow[] = [];
  for (let i = 0; i < input.pageSize; i += 1) {
    if (ctx.signal.aborted) {
      throw new Retryable('aborted mid-extract');
    }
    rows.push({
      id: `row-${input.since}-${i}`,
      payload: { value: i, label: `row ${i}` },
      source: input.sourceUri,
      receivedAt: input.since + i * 1000,
    });
    if (i % 50 === 0) ctx.heartbeat();
  }
  return { rows, cursor: null };
};

export interface ValidateInput {
  rows: RawRow[];
}

export interface ValidateOutput {
  valid: ValidatedRow[];
  rejected: { row: RawRow; reason: string }[];
}

export const validate: Handler<ValidateInput, ValidateOutput> = (ctx, input) => {
  const valid: ValidatedRow[] = [];
  const rejected: { row: RawRow; reason: string }[] = [];
  for (const row of input.rows) {
    if (typeof row.payload !== 'object' || row.payload === null) {
      rejected.push({ row, reason: 'payload is not an object' });
      continue;
    }
    const warnings: string[] = [];
    if (!('value' in row.payload)) warnings.push('missing value field');
    if (!('label' in row.payload)) warnings.push('missing label field');
    valid.push({
      id: row.id,
      payload: row.payload,
      source: row.source,
      receivedAt: row.receivedAt,
      warnings,
    });
  }
  ctx.log('info', `validate: ${valid.length} valid, ${rejected.length} rejected`);
  return { valid, rejected };
};

export interface TransformInput {
  rows: ValidatedRow[];
}

export interface TransformOutput {
  rows: TransformedRow[];
}

export const transform: Handler<TransformInput, TransformOutput> = (_ctx, input) => {
  const out: TransformedRow[] = [];
  for (const row of input.rows) {
    const value = typeof row.payload.value === 'number' ? row.payload.value : Number(row.payload.value);
    if (!Number.isFinite(value)) {
      // Treat as permanent failure for this batch; the operator shouldn't
      // expect us to silently drop unparseable values.
      throw new JobFailure(`unparseable value in row ${row.id}: ${row.payload.value}`);
    }
    out.push({
      id: row.id,
      ts: row.receivedAt,
      category: typeof row.payload.label === 'string' ? row.payload.label : 'unknown',
      amount: value,
      source: row.source,
    });
  }
  return { rows: out };
};

export interface LoadInput {
  rows: TransformedRow[];
  target: string;
}

export interface LoadOutput {
  inserted: number;
  duplicates: number;
}

export const load: Handler<LoadInput, LoadOutput> = async (ctx, input) => {
  ctx.log('info', `load: target=${input.target} rows=${input.rows.length}`);
  // A real handler would talk to the target db; we simulate with a tiny
  // dedup-by-id check. The runtime's idempotency layer means this entire
  // handler can be safely retried without double-loading.
  const seen = new Set<string>();
  let dup = 0;
  for (const row of input.rows) {
    if (seen.has(row.id)) {
      dup += 1;
    } else {
      seen.add(row.id);
    }
    if (seen.size % 100 === 0) ctx.heartbeat();
  }
  return { inserted: seen.size, duplicates: dup };
};

export interface NotifyInput {
  recipients: string[];
  subject: string;
  body: string;
}

export interface NotifyOutput {
  sent: number;
}

export const notify: Handler<NotifyInput, NotifyOutput> = async (ctx, input) => {
  if (input.recipients.length === 0) {
    return { sent: 0 };
  }
  ctx.log('info', `notify: ${input.recipients.length} recipients`);
  // Simulated send; would normally hit the email service.
  return { sent: input.recipients.length };
};
