// Image processor example.
//
// Each upload triggers a fan-out workflow:
//   - inspect: read image metadata (width, height, format)
//   - in parallel:
//     - resize-thumbnail (200x200)
//     - resize-medium (800x800)
//     - extract-exif
//   - finalize: emit one summary record after all three complete
//
// This shape exercises the runtime's fan-out, fan-in, and parallel-
// dispatch behavior. The handlers themselves are deliberately small;
// what matters is how the workflow definition wires them.

import { JobFailure, Retryable } from '@tideway/failure';
import type { Handler } from '@tideway/worker';

export interface ImageMeta {
  width: number;
  height: number;
  format: 'jpeg' | 'png' | 'webp' | 'gif';
  bytes: number;
}

export interface InspectInput {
  uploadId: string;
  storageUri: string;
}

export interface InspectOutput {
  meta: ImageMeta;
}

export const inspect: Handler<InspectInput, InspectOutput> = async (ctx, input) => {
  ctx.log('info', `inspect: upload=${input.uploadId} uri=${input.storageUri}`);
  // A real handler would fetch the bytes and parse headers; we use a
  // stub that maps uploadId -> meta deterministically for tests.
  if (input.uploadId.startsWith('bad-')) {
    throw new JobFailure(`upload ${input.uploadId} is not a valid image`);
  }
  if (input.uploadId.startsWith('flake-')) {
    throw new Retryable(`transient read error on ${input.uploadId}`);
  }
  // Deterministic synthetic meta. Real implementation reads exif.
  return {
    meta: {
      width: 1024,
      height: 768,
      format: 'jpeg',
      bytes: 250_000,
    },
  };
};

export interface ResizeInput {
  uploadId: string;
  sourceUri: string;
  targetWidth: number;
  targetHeight: number;
  outputBucket: string;
}

export interface ResizeOutput {
  outputUri: string;
  bytes: number;
}

export const resize: Handler<ResizeInput, ResizeOutput> = async (ctx, input) => {
  ctx.log('info', `resize ${input.targetWidth}x${input.targetHeight}: ${input.uploadId}`);
  // Simulated. A real handler runs sharp/imagemagick.
  if (input.targetWidth <= 0 || input.targetHeight <= 0) {
    throw new JobFailure('target dimensions must be positive');
  }
  // Tiny CPU-loop to demonstrate heartbeat usage.
  for (let i = 0; i < 5; i += 1) {
    if (ctx.signal.aborted) throw new Retryable('aborted during resize');
    ctx.heartbeat();
  }
  return {
    outputUri: `${input.outputBucket}/${input.uploadId}-${input.targetWidth}x${input.targetHeight}.jpg`,
    bytes: input.targetWidth * input.targetHeight * 3,
  };
};

export interface ExtractExifInput {
  uploadId: string;
  sourceUri: string;
}

export interface ExtractExifOutput {
  exif: {
    cameraModel?: string;
    capturedAt?: number;
    gps?: { lat: number; lng: number };
    iso?: number;
    aperture?: number;
  };
}

export const extractExif: Handler<ExtractExifInput, ExtractExifOutput> = async (ctx, input) => {
  ctx.log('info', `exif: ${input.uploadId}`);
  // Real implementation parses the JPEG/PNG header. Stub returns a
  // synthetic block.
  return {
    exif: {
      cameraModel: 'Synthetic Test Camera',
      capturedAt: Date.now() - 60_000,
      iso: 200,
      aperture: 2.8,
    },
  };
};

export interface FinalizeInput {
  uploadId: string;
  meta: ImageMeta;
  variants: Array<{ label: string; uri: string; bytes: number }>;
  exif: ExtractExifOutput['exif'];
}

export interface FinalizeOutput {
  recordId: string;
  totalBytes: number;
}

export const finalize: Handler<FinalizeInput, FinalizeOutput> = async (ctx, input) => {
  const totalBytes = input.variants.reduce((acc, v) => acc + v.bytes, 0) + input.meta.bytes;
  ctx.log('info', `finalize ${input.uploadId}: ${input.variants.length} variants, ${totalBytes} bytes`);
  return {
    recordId: `rec-${input.uploadId}`,
    totalBytes,
  };
};

// Helper used by the workflow definition when constructing the finalize
// step's input from the prior siblings' outputs.
export function combineVariants(
  thumbnail: ResizeOutput,
  medium: ResizeOutput,
): Array<{ label: string; uri: string; bytes: number }> {
  return [
    { label: 'thumbnail', uri: thumbnail.outputUri, bytes: thumbnail.bytes },
    { label: 'medium', uri: medium.outputUri, bytes: medium.bytes },
  ];
}
