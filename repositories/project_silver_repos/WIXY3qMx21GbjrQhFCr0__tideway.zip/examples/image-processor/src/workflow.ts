// Image processor workflow definition.

export interface ImageWorkflowConfig {
  outputBucket: string;
  thumbnailSize: number;
  mediumSize: number;
}

export interface ImageStep {
  id: string;
  handler: string;
  parents: string[];
  declaredDeadlineMs?: number;
}

export function buildImageSteps(uploadId: string, config: ImageWorkflowConfig): ImageStep[] {
  const inspect = `${uploadId}/inspect`;
  const thumb = `${uploadId}/thumbnail`;
  const medium = `${uploadId}/medium`;
  const exif = `${uploadId}/exif`;
  const finalize = `${uploadId}/finalize`;

  return [
    { id: inspect, handler: 'image.inspect', parents: [], declaredDeadlineMs: 30_000 },
    { id: thumb, handler: 'image.resize', parents: [inspect], declaredDeadlineMs: 60_000 },
    { id: medium, handler: 'image.resize', parents: [inspect], declaredDeadlineMs: 60_000 },
    { id: exif, handler: 'image.extractExif', parents: [inspect], declaredDeadlineMs: 30_000 },
    { id: finalize, handler: 'image.finalize', parents: [thumb, medium, exif], declaredDeadlineMs: 30_000 },
  ];
}

// Returns the layer-grouping for the image workflow. Layer 0 is just
// inspect; layer 1 is the three parallel resize/exif steps; layer 2 is
// finalize. Useful for visualizing.
export function workflowLayers(steps: ImageStep[]): string[][] {
  const idIndex = new Map<string, number>();
  steps.forEach((s, i) => idIndex.set(s.id, i));
  const inDeg = new Map<string, number>();
  for (const s of steps) inDeg.set(s.id, s.parents.length);

  let frontier: string[] = steps.filter((s) => s.parents.length === 0).map((s) => s.id);
  const layers: string[][] = [];
  while (frontier.length > 0) {
    layers.push([...frontier].sort());
    const next: string[] = [];
    for (const id of frontier) {
      for (const s of steps) {
        if (!s.parents.includes(id)) continue;
        const remaining = inDeg.get(s.id)! - 1;
        inDeg.set(s.id, remaining);
        if (remaining === 0) next.push(s.id);
      }
    }
    frontier = next;
  }
  return layers;
}
