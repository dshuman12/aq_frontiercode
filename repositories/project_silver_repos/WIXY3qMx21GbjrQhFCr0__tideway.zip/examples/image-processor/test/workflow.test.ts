import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { buildImageSteps, workflowLayers } from '../src/workflow.ts';

describe('buildImageSteps', () => {
  it('produces 5 steps', () => {
    const steps = buildImageSteps('u-1', { outputBucket: 'b', thumbnailSize: 200, mediumSize: 800 });
    assert.equal(steps.length, 5);
  });

  it('inspect has no parents', () => {
    const steps = buildImageSteps('u-1', { outputBucket: 'b', thumbnailSize: 200, mediumSize: 800 });
    const inspect = steps.find((s) => s.id.endsWith('/inspect'))!;
    assert.deepEqual(inspect.parents, []);
  });

  it('finalize depends on all 3 sibling steps', () => {
    const steps = buildImageSteps('u-1', { outputBucket: 'b', thumbnailSize: 200, mediumSize: 800 });
    const finalize = steps.find((s) => s.id.endsWith('/finalize'))!;
    assert.equal(finalize.parents.length, 3);
  });

  it('every step has a deadline', () => {
    const steps = buildImageSteps('u-1', { outputBucket: 'b', thumbnailSize: 200, mediumSize: 800 });
    for (const s of steps) {
      assert.ok(s.declaredDeadlineMs !== undefined);
    }
  });
});

describe('workflowLayers', () => {
  it('produces 3 layers for the standard image workflow', () => {
    const steps = buildImageSteps('u-1', { outputBucket: 'b', thumbnailSize: 200, mediumSize: 800 });
    const layers = workflowLayers(steps);
    assert.equal(layers.length, 3);
  });

  it('layer 1 has 3 parallel steps', () => {
    const steps = buildImageSteps('u-1', { outputBucket: 'b', thumbnailSize: 200, mediumSize: 800 });
    const layers = workflowLayers(steps);
    assert.equal(layers[1]!.length, 3);
  });

  it('layer 0 is just inspect', () => {
    const steps = buildImageSteps('u-1', { outputBucket: 'b', thumbnailSize: 200, mediumSize: 800 });
    const layers = workflowLayers(steps);
    assert.equal(layers[0]!.length, 1);
    assert.match(layers[0]![0]!, /inspect$/);
  });

  it('layer 2 is just finalize', () => {
    const steps = buildImageSteps('u-1', { outputBucket: 'b', thumbnailSize: 200, mediumSize: 800 });
    const layers = workflowLayers(steps);
    assert.equal(layers[2]!.length, 1);
    assert.match(layers[2]![0]!, /finalize$/);
  });
});
