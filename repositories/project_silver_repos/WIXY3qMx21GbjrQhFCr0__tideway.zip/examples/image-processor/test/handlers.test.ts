import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { JobFailure, Retryable } from '../../../packages/failure/src/index.ts';
import {
  combineVariants,
  extractExif,
  finalize,
  inspect,
  resize,
} from '../src/handlers.ts';

const ctxFor = () => ({
  signal: new AbortController().signal,
  runId: 'r-test',
  attempt: 1,
  heartbeat: () => undefined,
  log: () => undefined,
});

describe('inspect', () => {
  it('returns meta for a normal upload', async () => {
    const out = await inspect(ctxFor(), { uploadId: 'u-1', storageUri: 's3://x' });
    assert.equal(out.meta.format, 'jpeg');
    assert.ok(out.meta.bytes > 0);
  });

  it('throws JobFailure for "bad-*" upload ids', async () => {
    await assert.rejects(inspect(ctxFor(), { uploadId: 'bad-corrupt', storageUri: 's3://x' }), JobFailure);
  });

  it('throws Retryable for "flake-*" upload ids', async () => {
    await assert.rejects(inspect(ctxFor(), { uploadId: 'flake-1', storageUri: 's3://x' }), Retryable);
  });
});

describe('resize', () => {
  it('returns an output uri tied to dimensions', async () => {
    const out = await resize(ctxFor(), {
      uploadId: 'u-1',
      sourceUri: 's3://x',
      targetWidth: 200,
      targetHeight: 200,
      outputBucket: 's3://output',
    });
    assert.match(out.outputUri, /200x200/);
  });

  it('refuses non-positive dimensions', async () => {
    await assert.rejects(
      resize(ctxFor(), {
        uploadId: 'u-1',
        sourceUri: 's3://x',
        targetWidth: 0,
        targetHeight: 200,
        outputBucket: 's3://output',
      }),
    );
  });

  it('byte estimate scales with area', async () => {
    const small = await resize(ctxFor(), {
      uploadId: 'u', sourceUri: 's', targetWidth: 100, targetHeight: 100, outputBucket: 'b',
    });
    const big = await resize(ctxFor(), {
      uploadId: 'u', sourceUri: 's', targetWidth: 200, targetHeight: 200, outputBucket: 'b',
    });
    assert.ok(big.bytes > small.bytes);
  });
});

describe('extractExif', () => {
  it('returns a populated exif block', async () => {
    const out = await extractExif(ctxFor(), { uploadId: 'u-1', sourceUri: 's' });
    assert.ok(out.exif.cameraModel);
    assert.ok(out.exif.iso);
  });
});

describe('finalize', () => {
  it('sums variant bytes plus meta bytes', async () => {
    const out = await finalize(ctxFor(), {
      uploadId: 'u-1',
      meta: { width: 100, height: 100, format: 'jpeg', bytes: 1000 },
      variants: [
        { label: 'a', uri: 'x', bytes: 500 },
        { label: 'b', uri: 'y', bytes: 250 },
      ],
      exif: {},
    });
    assert.equal(out.totalBytes, 1750);
  });

  it('builds a record id from uploadId', async () => {
    const out = await finalize(ctxFor(), {
      uploadId: 'u-99',
      meta: { width: 1, height: 1, format: 'jpeg', bytes: 0 },
      variants: [],
      exif: {},
    });
    assert.equal(out.recordId, 'rec-u-99');
  });
});

describe('combineVariants', () => {
  it('produces labeled entries from sibling outputs', () => {
    const out = combineVariants(
      { outputUri: 's3://t', bytes: 100 },
      { outputUri: 's3://m', bytes: 1000 },
    );
    assert.equal(out.length, 2);
    assert.equal(out[0]!.label, 'thumbnail');
    assert.equal(out[1]!.label, 'medium');
  });
});
