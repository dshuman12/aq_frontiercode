// Cron-driven scheduling for the daily report.

import type { CronExpression } from '@tideway/cron';
import { parse, nextFireAfter, upcomingFirings } from '@tideway/cron';

export interface ReportScheduleConfig {
  // Cron expression in UTC. Default: 06:00 UTC every day.
  expression: string;
  recipients: string[];
  format: 'html' | 'markdown' | 'json';
  regions: Array<'na' | 'emea' | 'apac'>;
  segments: Array<'new' | 'returning'>;
}

export const DEFAULT_REPORT_CONFIG: ReportScheduleConfig = {
  expression: '0 6 * * *',
  recipients: [],
  format: 'markdown',
  regions: ['na', 'emea', 'apac'],
  segments: ['new', 'returning'],
};

export function parseSchedule(config: ReportScheduleConfig): CronExpression {
  return parse(config.expression);
}

export function nextRunAfter(config: ReportScheduleConfig, now: Date = new Date()): Date | null {
  return nextFireAfter(parseSchedule(config), now);
}

export function upcomingRuns(config: ReportScheduleConfig, now: Date, count: number): Date[] {
  return upcomingFirings(parseSchedule(config), now, count);
}

export interface ReportRun {
  reportDate: string; // YYYY-MM-DD
  scheduledFor: Date;
}

export function buildRuns(config: ReportScheduleConfig, now: Date, count: number): ReportRun[] {
  const dates = upcomingRuns(config, now, count);
  return dates.map((d) => ({
    reportDate: d.toISOString().slice(0, 10),
    scheduledFor: d,
  }));
}
