// Scheduled-report example.
//
// A daily report that runs at 06:00 UTC, queries multiple data sources
// in parallel, aggregates, formats, and emails. Demonstrates cron
// integration alongside fan-out + aggregate.
//
// The handlers are deliberately thin so the example stays readable.
// Real production handlers would have more validation, retries on
// specific error classes, and more careful resource management.

import type { Handler } from '@tideway/worker';

export interface QuerySalesInput {
  date: string; // YYYY-MM-DD
  region: 'na' | 'emea' | 'apac';
}

export interface QuerySalesOutput {
  region: string;
  totalRevenue: number;
  orderCount: number;
}

export const querySales: Handler<QuerySalesInput, QuerySalesOutput> = async (ctx, input) => {
  ctx.log('info', `query-sales: date=${input.date} region=${input.region}`);
  // Synthetic data so the example is deterministic.
  const seed = hashOf(input.date + input.region);
  const orderCount = (seed % 100) + 50;
  const avgRevenue = 50 + (seed % 200);
  return {
    region: input.region,
    totalRevenue: orderCount * avgRevenue,
    orderCount,
  };
};

export interface QueryUserGrowthInput {
  date: string;
  segment: 'new' | 'returning';
}

export interface QueryUserGrowthOutput {
  segment: string;
  count: number;
  weekOverWeekDelta: number;
}

export const queryUserGrowth: Handler<QueryUserGrowthInput, QueryUserGrowthOutput> = async (
  ctx,
  input,
) => {
  ctx.log('info', `user-growth: date=${input.date} segment=${input.segment}`);
  const seed = hashOf(input.date + input.segment);
  const count = (seed % 1000) + 200;
  const wow = ((seed % 41) - 20) / 100; // -20% to +20%
  return { segment: input.segment, count, weekOverWeekDelta: wow };
};

export interface AggregateInput {
  sales: QuerySalesOutput[];
  growth: QueryUserGrowthOutput[];
}

export interface AggregateOutput {
  totalRevenue: number;
  totalOrders: number;
  totalUsers: number;
  highlights: string[];
}

export const aggregate: Handler<AggregateInput, AggregateOutput> = (ctx, input) => {
  let totalRevenue = 0;
  let totalOrders = 0;
  for (const s of input.sales) {
    totalRevenue += s.totalRevenue;
    totalOrders += s.orderCount;
  }
  let totalUsers = 0;
  for (const g of input.growth) totalUsers += g.count;

  const highlights: string[] = [];
  const topRegion = [...input.sales].sort((a, b) => b.totalRevenue - a.totalRevenue)[0];
  if (topRegion) {
    highlights.push(`Top region: ${topRegion.region} ($${topRegion.totalRevenue})`);
  }
  for (const g of input.growth) {
    if (g.weekOverWeekDelta > 0.1) {
      highlights.push(`Strong growth in ${g.segment}: +${(g.weekOverWeekDelta * 100).toFixed(0)}% WoW`);
    }
  }
  ctx.log('info', `aggregate: ${totalOrders} orders, ${totalUsers} users`);
  return { totalRevenue, totalOrders, totalUsers, highlights };
};

export interface RenderReportInput {
  date: string;
  data: AggregateOutput;
  format: 'html' | 'markdown' | 'json';
}

export interface RenderReportOutput {
  body: string;
  subject: string;
}

export const renderReport: Handler<RenderReportInput, RenderReportOutput> = (_ctx, input) => {
  const subject = `Daily Report - ${input.date}`;
  let body = '';
  switch (input.format) {
    case 'json':
      body = JSON.stringify(input.data, null, 2);
      break;
    case 'markdown':
      body = renderMarkdown(input.date, input.data);
      break;
    case 'html':
      body = renderHtml(input.date, input.data);
      break;
  }
  return { body, subject };
};

export interface SendReportInput {
  recipients: string[];
  subject: string;
  body: string;
  format: 'html' | 'markdown' | 'json';
}

export interface SendReportOutput {
  delivered: number;
}

export const sendReport: Handler<SendReportInput, SendReportOutput> = async (ctx, input) => {
  ctx.log('info', `send-report: ${input.recipients.length} recipients`);
  // Real implementation: hit the email service. Stub returns the count
  // verbatim so tests can assert.
  return { delivered: input.recipients.length };
};

function renderMarkdown(date: string, data: AggregateOutput): string {
  const lines: string[] = [];
  lines.push(`# Daily Report - ${date}`);
  lines.push('');
  lines.push(`- Total revenue: $${data.totalRevenue}`);
  lines.push(`- Total orders: ${data.totalOrders}`);
  lines.push(`- Total users: ${data.totalUsers}`);
  if (data.highlights.length > 0) {
    lines.push('');
    lines.push('## Highlights');
    for (const h of data.highlights) lines.push(`- ${h}`);
  }
  return lines.join('\n');
}

function renderHtml(date: string, data: AggregateOutput): string {
  const items: string[] = [];
  items.push(`<h1>Daily Report - ${escapeHtml(date)}</h1>`);
  items.push('<ul>');
  items.push(`<li>Total revenue: $${data.totalRevenue}</li>`);
  items.push(`<li>Total orders: ${data.totalOrders}</li>`);
  items.push(`<li>Total users: ${data.totalUsers}</li>`);
  items.push('</ul>');
  if (data.highlights.length > 0) {
    items.push('<h2>Highlights</h2><ul>');
    for (const h of data.highlights) items.push(`<li>${escapeHtml(h)}</li>`);
    items.push('</ul>');
  }
  return items.join('');
}

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// Tiny deterministic non-crypto hash. Used to make synthetic data
// reproducible in tests.
function hashOf(s: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i += 1) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  return h;
}
