import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import {
  DEFAULT_REPORT_CONFIG,
  buildRuns,
  nextRunAfter,
  parseSchedule,
  upcomingRuns,
} from '../src/schedule.ts';

describe('parseSchedule', () => {
  it('parses the default expression', () => {
    const expr = parseSchedule(DEFAULT_REPORT_CONFIG);
    assert.deepEqual(expr.hour, [6]);
    assert.deepEqual(expr.minute, [0]);
  });
});

describe('nextRunAfter', () => {
  it('returns next 06:00 UTC', () => {
    const result = nextRunAfter(DEFAULT_REPORT_CONFIG, new Date('2026-05-08T05:00:00Z'));
    assert.equal(result?.toISOString(), '2026-05-08T06:00:00.000Z');
  });

  it('rolls to the following day if past 06:00 today', () => {
    const result = nextRunAfter(DEFAULT_REPORT_CONFIG, new Date('2026-05-08T07:00:00Z'));
    assert.equal(result?.toISOString(), '2026-05-09T06:00:00.000Z');
  });
});

describe('upcomingRuns', () => {
  it('returns count entries', () => {
    const dates = upcomingRuns(DEFAULT_REPORT_CONFIG, new Date('2026-05-01T00:00:00Z'), 7);
    assert.equal(dates.length, 7);
  });

  it('every entry is at 06:00 UTC', () => {
    const dates = upcomingRuns(DEFAULT_REPORT_CONFIG, new Date('2026-05-01T00:00:00Z'), 5);
    for (const d of dates) {
      assert.equal(d.getUTCHours(), 6);
      assert.equal(d.getUTCMinutes(), 0);
    }
  });
});

describe('buildRuns', () => {
  it('produces ReportRun entries with reportDate and scheduledFor', () => {
    const runs = buildRuns(DEFAULT_REPORT_CONFIG, new Date('2026-05-01T00:00:00Z'), 3);
    assert.equal(runs.length, 3);
    assert.match(runs[0]!.reportDate, /^\d{4}-\d{2}-\d{2}$/);
    assert.ok(runs[0]!.scheduledFor instanceof Date);
  });
});

describe('config customization', () => {
  it('honors a different cron expression', () => {
    const config = { ...DEFAULT_REPORT_CONFIG, expression: '0 12 * * 1' }; // Mondays at noon UTC
    const r = nextRunAfter(config, new Date('2026-05-04T08:00:00Z')); // Monday
    assert.equal(r?.toISOString(), '2026-05-04T12:00:00.000Z');
  });

  it('different region/segment lists pass through', () => {
    const config = { ...DEFAULT_REPORT_CONFIG, regions: ['na' as const], segments: ['new' as const] };
    assert.deepEqual(config.regions, ['na']);
    assert.deepEqual(config.segments, ['new']);
  });
});
