import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import {
  aggregate,
  querySales,
  queryUserGrowth,
  renderReport,
  sendReport,
} from '../src/handlers.ts';

const ctxFor = () => ({
  signal: new AbortController().signal,
  runId: 'r-test',
  attempt: 1,
  heartbeat: () => undefined,
  log: () => undefined,
});

describe('querySales', () => {
  it('returns deterministic output for the same inputs', async () => {
    const a = await querySales(ctxFor(), { date: '2026-05-01', region: 'na' });
    const b = await querySales(ctxFor(), { date: '2026-05-01', region: 'na' });
    assert.deepEqual(a, b);
  });

  it('different regions produce different outputs', async () => {
    const a = await querySales(ctxFor(), { date: '2026-05-01', region: 'na' });
    const b = await querySales(ctxFor(), { date: '2026-05-01', region: 'emea' });
    assert.notDeepEqual(a, b);
  });
});

describe('queryUserGrowth', () => {
  it('produces a numeric count', async () => {
    const out = await queryUserGrowth(ctxFor(), { date: '2026-05-01', segment: 'new' });
    assert.ok(out.count > 0);
  });

  it('weekOverWeekDelta is in [-0.20, 0.20]', async () => {
    const out = await queryUserGrowth(ctxFor(), { date: '2026-05-01', segment: 'new' });
    assert.ok(out.weekOverWeekDelta >= -0.20);
    assert.ok(out.weekOverWeekDelta <= 0.20);
  });
});

describe('aggregate', () => {
  it('sums revenues and orders', () => {
    const out = aggregate(ctxFor(), {
      sales: [
        { region: 'na', totalRevenue: 100, orderCount: 10 },
        { region: 'emea', totalRevenue: 50, orderCount: 5 },
      ],
      growth: [],
    });
    assert.equal(out.totalRevenue, 150);
    assert.equal(out.totalOrders, 15);
  });

  it('identifies the top region', () => {
    const out = aggregate(ctxFor(), {
      sales: [
        { region: 'na', totalRevenue: 100, orderCount: 10 },
        { region: 'emea', totalRevenue: 500, orderCount: 5 },
      ],
      growth: [],
    });
    assert.match(out.highlights[0]!, /Top region: emea/);
  });

  it('flags strong growth in highlights', () => {
    const out = aggregate(ctxFor(), {
      sales: [],
      growth: [{ segment: 'new', count: 200, weekOverWeekDelta: 0.15 }],
    });
    assert.ok(out.highlights.some((h) => /Strong growth in new/.test(h)));
  });

  it('does NOT flag flat growth', () => {
    const out = aggregate(ctxFor(), {
      sales: [],
      growth: [{ segment: 'new', count: 200, weekOverWeekDelta: 0.05 }],
    });
    assert.ok(!out.highlights.some((h) => /Strong growth/.test(h)));
  });
});

describe('renderReport', () => {
  const data = {
    totalRevenue: 1000,
    totalOrders: 50,
    totalUsers: 200,
    highlights: ['Top region: na ($1000)'],
  };

  it('json format is valid JSON', () => {
    const out = renderReport(ctxFor(), { date: '2026-05-01', data, format: 'json' });
    assert.doesNotThrow(() => JSON.parse(out.body));
  });

  it('markdown format includes the date in the heading', () => {
    const out = renderReport(ctxFor(), { date: '2026-05-01', data, format: 'markdown' });
    assert.match(out.body, /^# Daily Report - 2026-05-01/);
  });

  it('html format escapes the date', () => {
    const out = renderReport(ctxFor(), { date: '2026<bad>', data, format: 'html' });
    assert.match(out.body, /2026&lt;bad&gt;/);
  });

  it('subject contains the date', () => {
    const out = renderReport(ctxFor(), { date: '2026-05-01', data, format: 'markdown' });
    assert.equal(out.subject, 'Daily Report - 2026-05-01');
  });

  it('markdown highlights section present when highlights exist', () => {
    const out = renderReport(ctxFor(), { date: '2026-05-01', data, format: 'markdown' });
    assert.match(out.body, /## Highlights/);
  });
});

describe('sendReport', () => {
  it('delivered count == recipient count', async () => {
    const out = await sendReport(ctxFor(), {
      recipients: ['a', 'b', 'c'],
      subject: 's',
      body: 'b',
      format: 'markdown',
    });
    assert.equal(out.delivered, 3);
  });
});
