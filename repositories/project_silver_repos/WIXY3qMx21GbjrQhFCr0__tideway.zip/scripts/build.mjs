#!/usr/bin/env node
// Direct esbuild driver. We bundle each package's src/index.ts to dist/index.js
// without going through tsc. tsc is run separately (yarn typecheck) for type
// checking only. This split is intentional: it shaves ~3s off the inner build
// loop and keeps the build pipeline obvious.
//
// One quirk worth noting: esbuild does not emit declaration files. The .d.ts
// emit happens in a second pass via tsc --emitDeclarationOnly, which is
// noticeably slower. Run with --no-types to skip that pass during dev.

import { build } from 'esbuild';
import { readdirSync, statSync, existsSync } from 'node:fs';
import { resolve, join } from 'node:path';
import { spawnSync } from 'node:child_process';

const ROOT = resolve(process.cwd());
const ROOTS = ['packages', 'apps', 'tools'];
const args = new Set(process.argv.slice(2));
const skipTypes = args.has('--no-types');

function findPackages() {
  const out = [];
  for (const root of ROOTS) {
    const dir = join(ROOT, root);
    if (!existsSync(dir)) continue;
    for (const name of readdirSync(dir)) {
      const pkg = join(dir, name);
      if (!statSync(pkg).isDirectory()) continue;
      const entry = join(pkg, 'src', 'index.ts');
      if (existsSync(entry)) out.push({ name, dir: pkg, entry });
    }
  }
  return out;
}

async function buildOne(pkg) {
  const start = Date.now();
  await build({
    entryPoints: [pkg.entry],
    outfile: join(pkg.dir, 'dist', 'index.js'),
    bundle: false,
    platform: 'node',
    target: 'node20',
    format: 'esm',
    sourcemap: true,
  });
  const ms = Date.now() - start;
  console.log(`  built ${pkg.name} (${ms}ms)`);
}

async function main() {
  const pkgs = findPackages();
  console.log(`building ${pkgs.length} packages...`);
  for (const p of pkgs) {
    await buildOne(p);
  }
  if (!skipTypes) {
    console.log('emitting .d.ts via tsc...');
    const r = spawnSync('npx', ['tsc', '-p', 'tsconfig.json', '--emitDeclarationOnly'], {
      stdio: 'inherit',
      shell: true,
    });
    if (r.status !== 0) process.exit(r.status ?? 1);
  }
  console.log('done.');
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
