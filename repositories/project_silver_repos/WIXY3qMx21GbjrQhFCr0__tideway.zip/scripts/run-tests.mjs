#!/usr/bin/env node
// Test runner that resolves all test files via fs.readdir and feeds the
// list to node --test. We don't rely on shell glob expansion because
// it differs across platforms (Windows cmd doesn't expand globs;
// Linux sh does, but npm scripts run via /bin/sh which expands ./*
// inconsistently across distros).

import { readdir } from 'node:fs/promises';
import { spawn } from 'node:child_process';
import { existsSync } from 'node:fs';
import { join } from 'node:path';

const ROOTS = ['packages', 'apps', 'tools', 'examples'];

async function findTestFiles() {
  const out = [];
  for (const root of ROOTS) {
    if (!existsSync(root)) continue;
    const subdirs = await readdir(root, { withFileTypes: true });
    for (const sub of subdirs) {
      if (!sub.isDirectory()) continue;
      const testDir = join(root, sub.name, 'test');
      if (!existsSync(testDir)) continue;
      const files = await readdir(testDir);
      for (const f of files) {
        if (f.endsWith('.test.ts')) {
          out.push(join(testDir, f));
        }
      }
    }
  }
  // tests/** are nested two levels deep
  if (existsSync('tests')) {
    for (const sub of await readdir('tests', { withFileTypes: true })) {
      if (!sub.isDirectory()) continue;
      const dir = join('tests', sub.name);
      for (const f of await readdir(dir)) {
        if (f.endsWith('.test.ts')) out.push(join(dir, f));
      }
    }
  }
  return out;
}

const files = await findTestFiles();
if (files.length === 0) {
  console.error('no test files found');
  process.exit(1);
}

const args = ['--import', 'tsx', '--test', ...files];
const child = spawn(process.execPath, args, { stdio: 'inherit' });
child.on('exit', (code) => process.exit(code ?? 1));
