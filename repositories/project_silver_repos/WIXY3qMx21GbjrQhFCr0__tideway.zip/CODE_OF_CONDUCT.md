# Code of conduct

Be kind. Assume good intent. Disagree about technical decisions
without making it personal.

If something happens that violates this, mail the maintainer
(see SECURITY.md for the address). Reports stay between the
reporter and the maintainer unless the reporter explicitly says
otherwise.

This document is deliberately short. Longer codes of conduct exist
and you can adopt one if you want. The substance of "be kind" is the
same.
