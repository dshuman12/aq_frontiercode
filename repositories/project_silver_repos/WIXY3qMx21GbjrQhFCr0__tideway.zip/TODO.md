# TODO

Grab-bag of stuff I want to get to. Sorted only loosely; the items
near the top are the ones I actually think about. The rest are
parking-spots so I don't forget.

## Should fix

- [ ] Lease-budget per handler-class. Right now lease TTL is global;
      handlers that legitimately need 5-minute leases shouldn't have
      to bump the global default. Probably exposes via the registry's
      register() options.
- [ ] Outbox depth alarm. Currently we only have a static threshold
      (10k). Should be a derivative ("growing for > 5 minutes"); a
      sustained-but-stable depth isn't an outage.
- [ ] `force-requeue` console subcommand. Operators have asked for
      this several times; the reason it's not done is in the runbook
      (`incident-stuck-lease.md`). Worth revisiting.

## Want to do

- [ ] examples/ directory with three real-shape workflows. The README
      points at it and the directory doesn't exist yet, which is
      embarrassing.
- [ ] Benchmarks for the scheduler with random DAGs at 1k/10k/100k
      nodes. The microbench harness exists in spirit but isn't wired
      to anything.
- [ ] OTel SDK adapter as a separate package, so users who want full
      OTel can swap our in-tree exporter for the real one.
- [ ] RFC 0012 (fan-out / fan-in semantics) needs to land. It's been
      WIP for a month.

## Nice to have

- [ ] Better cron-grammar errors. "out-of-bounds: '99' (allowed 0-59)"
      could include which field (minute) without too much ceremony.
- [ ] Console `tail` subcommand should actually tail (currently it's
      a one-shot status query in disguise).
- [ ] A `tideway doctor` subcommand that sweeps the database for
      common corruption patterns.

## Won't do (recording so the next person doesn't ask)

- [ ] Cross-host distribution. RFC 0013.
- [ ] Locale-aware cron. RFC 0011.
- [ ] Plugin/handler hot-reload. The complexity vs benefit doesn't
      pencil out for an embedded runtime.

## Also

There's some test cruft I should clean up: the conformance runner
re-implements the dispatch+transition loop that the real runner uses,
so the conformance tests can drift from real behavior. Long-term we
should have the conformance runner USE the real scheduler/worker code
paths. Short-term it's fine.
