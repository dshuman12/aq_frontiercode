# Changelog

The format is loosely based on [Keep a Changelog](https://keepachangelog.com/).

## [0.4.0] - 2026-05-08

### Added

- `@tideway/tool-loadgen`: synthetic DAG submitter for capacity
  planning. Five shapes (chain, fan-out, fan-out-fan-in, deep-tree,
  diamonds) plus a token-bucket rate limiter.
- `@tideway/dlq`: bulk replay and bulk drop with filter support.
- Cron `nextFireAfter` now correctly handles leap-year February 29.
- Tracing: `Tracer.withSpan` for fn-scoped spans with automatic
  exception recording.

### Changed

- Lease TTL default reduced from 60s to 30s. The reaper-detection-
  latency tradeoff was wrong at 60s for the workloads we measured.
- Outbox flush is now per-partition concurrent. Previously every
  message went sequentially, which was a bottleneck for
  high-fan-out workflows.

### Fixed

- `replay.replayAll` no longer crashes on a corrupted log entry; it
  records the first illegal transition in the result and continues.
- `cron.parse` now rejects out-of-range values per field, including
  the previously-undetected `weekday=7` (we use 0-6).
- Race in `idempotency.acquire` where two concurrent submissions
  with the same key could both receive `kind: 'fresh'`.

### Migration

None.

## [0.3.0] - 2026-04-01

### Added

- DLQ replay tooling.
- Cron-scheduled workflows.

### Changed

- `runstate.transition` now requires opts.attempt for retry_scheduled
  -> running transitions to disambiguate the attempt counter.

### Known issues

There's a clock-skew edge case in `leasing.heartbeat` that fires when
the system clock jumps backward. We hit it once during a maintenance
window. The fix is in 0.4.0; in the meantime, avoid running tideway
on a host that resyncs its clock by more than a second at a time.

### Migration

Per-handler retry policies now require an explicit `cap` field. If
you have handlers registered with a bare `exponential({ base, factor
})`, add `cap: <ms>`. Without a cap, retries can grow unbounded;
0.3.0 caught the most egregious case (a 6-month wait between
retries) in production.

## [0.2.0] - 2026-02-22

### Added

- Transactional outbox.
- Idempotency registry.
- SQLite store.

### Changed

**Breaking.** The `Handler` type signature changed from
`(input) => Promise<O>` to `(ctx, input) => Promise<O>`. The
`JobContext` provides cancellation, heartbeat, and logging hooks.

### Migration

Update handler signatures to take a context as first argument:

```ts
// before
const handler = async (input: Input): Promise<Output> => { ... }

// after
const handler: Handler<Input, Output> = async (ctx, input) => {
  // use ctx.signal for cancellation
  // call ctx.heartbeat() during long work
  ...
}
```

## [0.1.0] - 2026-01-15

Initial public release. Runtime + scheduler + worker pool +
in-memory store. No persistence.
