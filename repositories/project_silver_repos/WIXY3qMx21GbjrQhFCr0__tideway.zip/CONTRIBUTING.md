# Contributing to tideway

Thanks for the interest. This document captures how I work on this
repo so a contribution doesn't have to round-trip on stylistic
issues.

## Setup

```bash
npm ci
npm run ci
```

`npm run ci` runs typecheck + lint + test. If any of those is red on a
fresh clone, that's a bug; please file an issue.

Node 20.10 or newer is required. The Makefile target `make install`
is equivalent to `npm ci --immutable` and is what CI runs.

## Workspace layout

```
packages/   # the runtime libraries
apps/       # the runner daemon + console CLI
tools/      # operator tools (loadgen, migrate)
tests/      # cross-package integration / conformance / fuzz
docs/       # RFCs, runbooks, reference
```

Each package owns its own `package.json` and exports through
`src/index.ts`. New packages should follow the same shape; copy any
existing one and rename.

## Running a single test

```bash
node --import tsx --test packages/runstate/test/transition.test.ts
```

`npm test` runs everything. `npm test:one PATH` runs a specific
file.

## Style

- TypeScript strict mode; we use `noUncheckedIndexedAccess` and
  `exactOptionalPropertyTypes`. The compiler complains where you'd
  expect.
- Prettier with the defaults in `.prettierrc.yaml`. Run `npm run format`
  before committing if your editor doesn't do it on save.
- ESLint flat config in `eslint.config.js`. The big rules: no
  unused vars (`_`-prefixed allowed), no `console.log` in library
  code (apps/tools are exempt).

## Commits

Imperative mood, no conventional-commits prefix. Examples:

```
add cron parser
fix off-by-one in btree split
remove unused outbox stale-flush helper
make replay tolerate non-monotonic LSN
```

Group related changes into one commit. A commit should describe a
unit of work, not a particular file changed.

The author email and name on every commit must be your real one.

## Tests

Every public function needs at least one test. The bar for new
features is:

- a happy-path test
- a test for each documented edge case
- if the function does FSM/state-management work: tests for every
  illegal-input case

Tests use Node's built-in `node:test` runner via tsx. No vitest, no
jest. The `describe` / `it` API is the same; assertions use
`node:assert/strict`.

## Documentation

If your change adjusts behavior described in an RFC, update the RFC.
If your change adjusts behavior NOT described in an RFC and the
behavior is surprising-to-discover, write a new RFC.

Runbooks live in `docs/runbooks/`. If your change affects an existing
incident pattern, update the runbook.

## What I will not merge

- Bare `any` types in library code (apps/tools have a more
  permissive lint config).
- New runtime dependencies without a comment explaining why we
  couldn't do it without one. The existing dep set (kleur,
  better-sqlite3) is small and intentional.
- Tests that assert on implementation details (variable names,
  specific error message strings, internal data shapes). Test
  behavior.
- Commits that mix unrelated changes. Split them.
- "Refactor" PRs that don't have a concrete improvement they're
  buying. Refactor in service of a fix or a feature.

## Filing issues

If you can reproduce, include:

- runner version
- node version
- relevant config from `tideway.config.json` if you have one
- the simplest reproduction you can manage

If you can't reproduce, that's also a useful issue to file - "this
happened once, here's what I have" is sometimes the best we can do
for distributed-systems issues.

## Code of conduct

See [CODE_OF_CONDUCT.md](CODE_OF_CONDUCT.md). Be kind.

## Releases

Releases are cut by the maintainer per the procedure in
[docs/runbooks/release.md](docs/runbooks/release.md). Contributors
don't need to think about this.
