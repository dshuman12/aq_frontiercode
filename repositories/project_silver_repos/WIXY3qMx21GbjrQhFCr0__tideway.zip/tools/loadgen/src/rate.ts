// Rate limiting: a token bucket so loadgen can sustain a steady rate
// without bursting.
//
// We allocate `rate` tokens per second. When the caller wants to fire a
// request, they ask the bucket; if it returns >0 they fire and the bucket
// debits; if it returns 0 they wait. The bucket refills based on
// wall-clock time, not call frequency, so a slow consumer doesn't get
// "credit" for the time it spent stalled.

export class TokenBucket {
  private tokens: number;
  private lastRefill: number;

  constructor(
    private readonly capacity: number,
    private readonly ratePerSec: number,
    private readonly clock: () => number = Date.now,
  ) {
    if (capacity <= 0) throw new RangeError('capacity must be > 0');
    if (ratePerSec <= 0) throw new RangeError('ratePerSec must be > 0');
    this.tokens = capacity;
    this.lastRefill = clock();
  }

  // Try to take one token. Returns true if granted.
  take(): boolean {
    this.refill();
    if (this.tokens >= 1) {
      this.tokens -= 1;
      return true;
    }
    return false;
  }

  // Time (ms) until the bucket has at least 1 token.
  timeUntilNext(): number {
    this.refill();
    if (this.tokens >= 1) return 0;
    const need = 1 - this.tokens;
    return Math.ceil((need / this.ratePerSec) * 1000);
  }

  available(): number {
    this.refill();
    return this.tokens;
  }

  private refill(): void {
    const now = this.clock();
    const elapsed = (now - this.lastRefill) / 1000;
    if (elapsed <= 0) return;
    this.tokens = Math.min(this.capacity, this.tokens + elapsed * this.ratePerSec);
    this.lastRefill = now;
  }
}
