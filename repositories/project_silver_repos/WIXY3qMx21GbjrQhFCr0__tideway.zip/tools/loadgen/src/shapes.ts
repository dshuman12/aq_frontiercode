// Synthetic DAG shape generators for load testing.
//
// Each shape produces a list of `Node` declarations the loadgen tool
// then sends to the runner over the wire as `submit` requests. The
// shapes are deliberately small and named after what they exercise so
// we can read the load-test output and know what was tested.

export interface Node {
  id: string;
  parents: string[];
}

// Pure chain: a -> b -> c -> ... -> z. Stresses sequential dispatch.
export function chain(length: number): Node[] {
  const out: Node[] = [];
  for (let i = 0; i < length; i += 1) {
    out.push({
      id: `n${i}`,
      parents: i === 0 ? [] : [`n${i - 1}`],
    });
  }
  return out;
}

// Fan-out: one root with N independent leaves. Stresses parallel
// dispatch and queue caps.
export function fanOut(width: number): Node[] {
  const out: Node[] = [{ id: 'root', parents: [] }];
  for (let i = 0; i < width; i += 1) {
    out.push({ id: `leaf${i}`, parents: ['root'] });
  }
  return out;
}

// Fan-out then fan-in: one root, N parallel children, one terminal node
// that depends on all of them. Stresses both parallel dispatch and the
// barrier-wait that fan-in implies.
export function fanOutFanIn(width: number): Node[] {
  const out: Node[] = [{ id: 'root', parents: [] }];
  const midIds: string[] = [];
  for (let i = 0; i < width; i += 1) {
    out.push({ id: `mid${i}`, parents: ['root'] });
    midIds.push(`mid${i}`);
  }
  out.push({ id: 'tail', parents: midIds });
  return out;
}

// Deep tree: a balanced binary tree with `depth` levels. Stresses
// scheduler decisions when the layering result has medium depth and
// medium width simultaneously.
export function deepTree(depth: number): Node[] {
  const out: Node[] = [];
  // Level 0 has 1 node, level 1 has 2, ... level depth-1 has 2^(depth-1).
  for (let level = 0; level < depth; level += 1) {
    const count = 2 ** level;
    for (let i = 0; i < count; i += 1) {
      const id = `l${level}-${i}`;
      const parents: string[] = [];
      if (level > 0) {
        parents.push(`l${level - 1}-${i >> 1}`);
      }
      out.push({ id, parents });
    }
  }
  return out;
}

// Diamond chain: A -> {B,C} -> D -> {E,F} -> G ... a sequence of
// diamonds. Stresses fan-in/fan-out repeatedly.
export function diamonds(count: number): Node[] {
  const out: Node[] = [];
  let prevTail = 'd0-tail';
  out.push({ id: prevTail, parents: [] });
  for (let i = 0; i < count; i += 1) {
    const a = `d${i + 1}-a`;
    const b = `d${i + 1}-b`;
    const tail = `d${i + 1}-tail`;
    out.push({ id: a, parents: [prevTail] });
    out.push({ id: b, parents: [prevTail] });
    out.push({ id: tail, parents: [a, b] });
    prevTail = tail;
  }
  return out;
}

export type ShapeName = 'chain' | 'fan-out' | 'fan-out-fan-in' | 'deep-tree' | 'diamonds';

export function build(shape: ShapeName, size: number): Node[] {
  switch (shape) {
    case 'chain':
      return chain(size);
    case 'fan-out':
      return fanOut(size);
    case 'fan-out-fan-in':
      return fanOutFanIn(size);
    case 'deep-tree':
      return deepTree(size);
    case 'diamonds':
      return diamonds(size);
  }
}
