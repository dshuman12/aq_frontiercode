// loadgen: a small CLI that generates synthetic load against a tideway
// runner. It does NOT directly speak the wire protocol; it builds DAG
// shape descriptions and emits them as JSON for piping into the
// console's batch-submit subcommand. (Splitting the network layer out of
// the load tool keeps the tool itself testable without a live runner.)

export { build, chain, fanOut, fanOutFanIn, deepTree, diamonds, type Node, type ShapeName } from './shapes.ts';
export { TokenBucket } from './rate.ts';

export interface LoadgenArgs {
  shape: 'chain' | 'fan-out' | 'fan-out-fan-in' | 'deep-tree' | 'diamonds';
  size: number;
  ratePerSec: number;
  totalRuns: number;
  outputJson: boolean;
}

export class LoadgenArgsError extends Error {
  override readonly name = 'LoadgenArgsError';
}

export function parseArgs(argv: string[]): LoadgenArgs {
  let shape: LoadgenArgs['shape'] = 'chain';
  let size = 10;
  let ratePerSec = 10;
  let totalRuns = 100;
  let outputJson = false;
  let i = 0;
  while (i < argv.length) {
    const arg = argv[i];
    switch (arg) {
      case '--shape': {
        const v = argv[i + 1];
        if (v === undefined) throw new LoadgenArgsError('missing value for --shape');
        if (!['chain', 'fan-out', 'fan-out-fan-in', 'deep-tree', 'diamonds'].includes(v)) {
          throw new LoadgenArgsError(`unknown shape: ${v}`);
        }
        shape = v as LoadgenArgs['shape'];
        i += 2;
        break;
      }
      case '--size':
        size = parseIntStrict(argv[i + 1], '--size');
        i += 2;
        break;
      case '--rate':
        ratePerSec = parseIntStrict(argv[i + 1], '--rate');
        i += 2;
        break;
      case '--runs':
        totalRuns = parseIntStrict(argv[i + 1], '--runs');
        i += 2;
        break;
      case '--json':
        outputJson = true;
        i += 1;
        break;
      case '--help':
      case '-h':
        i += 1;
        break;
      default:
        throw new LoadgenArgsError(`unknown flag: ${arg}`);
    }
  }
  if (size <= 0) throw new LoadgenArgsError('--size must be > 0');
  if (ratePerSec <= 0) throw new LoadgenArgsError('--rate must be > 0');
  if (totalRuns <= 0) throw new LoadgenArgsError('--runs must be > 0');
  return { shape, size, ratePerSec, totalRuns, outputJson };
}

function parseIntStrict(v: string | undefined, name: string): number {
  if (v === undefined) throw new LoadgenArgsError(`missing value for ${name}`);
  if (!/^[0-9]+$/.test(v)) throw new LoadgenArgsError(`${name} must be a non-negative integer`);
  return Number(v);
}

export const HELP_TEXT = `tideway-loadgen: generate synthetic DAG submissions for the runner.

Usage:
  tideway-loadgen --shape SHAPE --size N --runs R --rate RPS [--json]

Shapes:
  chain            Sequential A -> B -> C ... of length N
  fan-out          One root with N parallel leaves
  fan-out-fan-in   One root, N parallel mid, one tail (barrier)
  deep-tree        Balanced binary tree of depth N
  diamonds         N chained diamonds

Flags:
  --shape SHAPE    DAG shape (default: chain)
  --size N         Shape parameter (default: 10)
  --runs R         Total submissions to emit (default: 100)
  --rate RPS       Submissions per second (default: 10)
  --json           Emit one JSON object per line instead of human text
`;
