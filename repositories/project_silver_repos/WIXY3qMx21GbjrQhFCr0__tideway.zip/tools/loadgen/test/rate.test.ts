import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { TokenBucket } from '../src/rate.ts';

class FakeClock {
  constructor(public t = 0) {}
  now = () => this.t;
  advance(ms: number) {
    this.t += ms;
  }
}

describe('TokenBucket', () => {
  it('starts with capacity tokens', () => {
    const c = new FakeClock(0);
    const b = new TokenBucket(5, 1, c.now);
    for (let i = 0; i < 5; i += 1) assert.equal(b.take(), true);
    assert.equal(b.take(), false);
  });

  it('refills at the configured rate', () => {
    const c = new FakeClock(0);
    const b = new TokenBucket(2, 1, c.now); // 1 token/sec
    b.take();
    b.take();
    assert.equal(b.take(), false);
    c.advance(1000);
    assert.equal(b.take(), true);
  });

  it('caps refill at capacity', () => {
    const c = new FakeClock(0);
    const b = new TokenBucket(2, 10, c.now);
    b.take();
    b.take();
    c.advance(60_000);
    // Should only refill to capacity, not unlimited.
    let granted = 0;
    while (b.take() && granted < 100) granted += 1;
    assert.equal(granted, 2);
  });

  it('timeUntilNext is 0 when tokens available', () => {
    const c = new FakeClock(0);
    const b = new TokenBucket(1, 1, c.now);
    assert.equal(b.timeUntilNext(), 0);
  });

  it('timeUntilNext reflects refill rate', () => {
    const c = new FakeClock(0);
    const b = new TokenBucket(1, 2, c.now); // 2 tokens/sec -> 500ms each
    b.take();
    assert.equal(b.timeUntilNext(), 500);
  });

  it('rejects non-positive capacity', () => {
    assert.throws(() => new TokenBucket(0, 1));
  });

  it('fails on non-positive rate', () => {
    assert.throws(() => new TokenBucket(1, 0));
  });

  it('available reflects current count', () => {
    const c = new FakeClock(0);
    const b = new TokenBucket(3, 1, c.now);
    b.take();
    const a = b.available();
    assert.ok(a >= 1.99 && a <= 2.01); // floating-point fuzz
  });
});
