import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { build, chain, deepTree, diamonds, fanOut, fanOutFanIn } from '../src/shapes.ts';

describe('chain', () => {
  it('produces N nodes with linear parent chain', () => {
    const c = chain(5);
    assert.equal(c.length, 5);
    assert.deepEqual(c[0]!.parents, []);
    assert.deepEqual(c[4]!.parents, ['n3']);
  });

  it('size=1 has a single node with no parents', () => {
    const c = chain(1);
    assert.equal(c.length, 1);
    assert.deepEqual(c[0]!.parents, []);
  });
});

describe('fanOut', () => {
  it('one root, N leaves', () => {
    const f = fanOut(4);
    assert.equal(f.length, 5);
    assert.deepEqual(f[0]!.parents, []);
    for (let i = 1; i <= 4; i += 1) {
      assert.deepEqual(f[i]!.parents, ['root']);
    }
  });
});

describe('fanOutFanIn', () => {
  it('one root, N mid, one tail with N parents', () => {
    const f = fanOutFanIn(3);
    assert.equal(f.length, 5); // 1 root + 3 mid + 1 tail
    const tail = f[f.length - 1]!;
    assert.equal(tail.id, 'tail');
    assert.equal(tail.parents.length, 3);
  });
});

describe('deepTree', () => {
  it('depth=1 -> 1 node', () => {
    const t = deepTree(1);
    assert.equal(t.length, 1);
  });

  it('depth=3 -> 1+2+4 = 7 nodes', () => {
    const t = deepTree(3);
    assert.equal(t.length, 7);
  });

  it('every non-root has one parent', () => {
    const t = deepTree(4);
    for (const n of t) {
      if (n.id !== 'l0-0') {
        assert.equal(n.parents.length, 1);
      }
    }
  });
});

describe('diamonds', () => {
  it('count=1 -> head + 2 mid + tail = 4 nodes', () => {
    const d = diamonds(1);
    assert.equal(d.length, 4);
  });

  it('chained diamonds connect tails to next heads', () => {
    const d = diamonds(2);
    // Tail of first diamond is parent of both mids of the second.
    const d2a = d.find((n) => n.id === 'd2-a')!;
    const d2b = d.find((n) => n.id === 'd2-b')!;
    assert.deepEqual(d2a.parents, ['d1-tail']);
    assert.deepEqual(d2b.parents, ['d1-tail']);
  });
});

describe('build dispatcher', () => {
  it('routes by shape name', () => {
    assert.equal(build('chain', 3).length, 3);
    assert.equal(build('fan-out', 3).length, 4);
    assert.equal(build('fan-out-fan-in', 3).length, 5);
    assert.equal(build('deep-tree', 3).length, 7);
    assert.equal(build('diamonds', 1).length, 4);
  });
});
