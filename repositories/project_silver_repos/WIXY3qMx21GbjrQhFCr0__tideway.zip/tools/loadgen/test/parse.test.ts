import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { HELP_TEXT, LoadgenArgsError, parseArgs } from '../src/index.ts';

describe('parseArgs', () => {
  it('returns defaults when no flags given', () => {
    const r = parseArgs([]);
    assert.equal(r.shape, 'chain');
    assert.equal(r.size, 10);
    assert.equal(r.ratePerSec, 10);
    assert.equal(r.totalRuns, 100);
    assert.equal(r.outputJson, false);
  });

  it('parses every flag', () => {
    const r = parseArgs([
      '--shape',
      'fan-out',
      '--size',
      '50',
      '--rate',
      '25',
      '--runs',
      '500',
      '--json',
    ]);
    assert.deepEqual(r, {
      shape: 'fan-out',
      size: 50,
      ratePerSec: 25,
      totalRuns: 500,
      outputJson: true,
    });
  });

  it('rejects unknown shape', () => {
    assert.throws(() => parseArgs(['--shape', 'fractal']), LoadgenArgsError);
  });

  it('fails on negative size', () => {
    assert.throws(() => parseArgs(['--size', '-3']), LoadgenArgsError);
  });

  it('bails on non-integer size', () => {
    assert.throws(() => parseArgs(['--size', 'oops']), LoadgenArgsError);
  });

  it('complains about rate=0', () => {
    assert.throws(() => parseArgs(['--rate', '0']), LoadgenArgsError);
  });

  it('refuses unknown flag', () => {
    assert.throws(() => parseArgs(['--burninate']), LoadgenArgsError);
  });

  it('-h is accepted as a shortcut for help', () => {
    const r = parseArgs(['-h']);
    assert.deepEqual(r.shape, 'chain'); // defaults preserved
  });
});

describe('HELP_TEXT', () => {
  it('mentions every shape', () => {
    for (const s of ['chain', 'fan-out', 'fan-out-fan-in', 'deep-tree', 'diamonds']) {
      assert.match(HELP_TEXT, new RegExp(s));
    }
  });
});
