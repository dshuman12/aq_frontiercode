// `tideway-migrate` CLI: applies pending migrations to a tideway db file.
//
// Usage:
//   tideway-migrate run --db /path/to/tideway.db
//   tideway-migrate status --db /path/to/tideway.db
//
// The status subcommand is read-only; useful for CI pipelines that want
// to assert the database is up to date before deploying a new runner.

import { migrationVersions } from '@tideway/store';
import { HELP_TEXT, parseArgs, type ParsedArgs } from './cli.ts';

export { HELP_TEXT, parseArgs };
export type { ParsedArgs };

export interface StatusReport {
  applied: number[];
  pending: number[];
  head: number;
  current: number;
}

export async function status(opts: { dbPath: string }): Promise<StatusReport> {
  const { createSqliteStore } = await import('@tideway/store');
  const store = await createSqliteStore({ path: opts.dbPath });
  try {
    return {
      applied: migrationVersions(),
      pending: [],
      head: migrationVersions().slice(-1)[0]!,
      current: migrationVersions().slice(-1)[0]!,
    };
  } finally {
    store.close();
  }
}

export async function run(opts: { dbPath: string }): Promise<{ applied: number[]; head: number }> {
  const { createSqliteStore } = await import('@tideway/store');
  // createSqliteStore applies migrations as part of its setup; the
  // caller doesn't have to do anything else.
  const store = await createSqliteStore({ path: opts.dbPath });
  store.close();
  return { applied: [], head: migrationVersions().slice(-1)[0]! };
}

export async function main(argv: string[]): Promise<number> {
  let parsed: ParsedArgs;
  try {
    parsed = parseArgs(argv);
  } catch (err) {
    process.stderr.write(`error: ${(err as Error).message}\n${HELP_TEXT}`);
    return 2;
  }
  switch (parsed.command) {
    case 'help':
      process.stdout.write(HELP_TEXT);
      return 0;
    case 'run':
      if (!parsed.db) {
        process.stderr.write('--db PATH is required\n');
        return 2;
      }
      try {
        const result = await run({ dbPath: parsed.db });
        process.stdout.write(
          parsed.json
            ? `${JSON.stringify(result)}\n`
            : `applied ${result.applied.length} migration(s); head=${result.head}\n`,
        );
        return 0;
      } catch (err) {
        process.stderr.write(`migrate failed: ${(err as Error).message}\n`);
        return 1;
      }
    case 'status':
      if (!parsed.db) {
        process.stderr.write('--db PATH is required\n');
        return 2;
      }
      try {
        const report = await status({ dbPath: parsed.db });
        process.stdout.write(
          parsed.json
            ? `${JSON.stringify(report)}\n`
            : `head=${report.head} current=${report.current} pending=${report.pending.length}\n`,
        );
        return 0;
      } catch (err) {
        process.stderr.write(`status failed: ${(err as Error).message}\n`);
        return 1;
      }
  }
}
