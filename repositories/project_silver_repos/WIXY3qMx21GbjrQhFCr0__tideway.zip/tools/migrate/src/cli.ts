// CLI argument parsing and help text. Lives separately from index.ts
// so that unit tests of the parser don't transitively load the store
// dependency (which itself optionally requires better-sqlite3).

export interface ParsedArgs {
  command: 'run' | 'status' | 'help';
  db?: string;
  json: boolean;
}

export function parseArgs(argv: string[]): ParsedArgs {
  const out: ParsedArgs = { command: 'help', json: false };
  if (argv.length === 0) return out;
  const cmd = argv[0];
  if (cmd === 'run' || cmd === 'status') {
    out.command = cmd;
  } else if (cmd === 'help' || cmd === '--help' || cmd === '-h') {
    out.command = 'help';
    return out;
  } else {
    throw new Error(`unknown command: ${cmd}`);
  }
  let i = 1;
  while (i < argv.length) {
    const arg = argv[i];
    if (arg === '--db') {
      out.db = argv[i + 1];
      i += 2;
      continue;
    }
    if (arg === '--json') {
      out.json = true;
      i += 1;
      continue;
    }
    throw new Error(`unknown flag: ${arg}`);
  }
  return out;
}

export const HELP_TEXT = `tideway-migrate: schema migrations for the tideway store.

Usage:
  tideway-migrate run --db PATH        Apply pending migrations.
  tideway-migrate status --db PATH     Print pending and applied versions.
  tideway-migrate help

Flags:
  --db PATH       Path to the SQLite database file.
  --json          Emit machine-readable output (status only).
`;
