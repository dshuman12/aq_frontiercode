import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { HELP_TEXT, parseArgs } from '../src/cli.ts';

describe('parseArgs', () => {
  it('defaults to help on empty argv', () => {
    const r = parseArgs([]);
    assert.equal(r.command, 'help');
  });

  it('parses help / --help / -h', () => {
    assert.equal(parseArgs(['help']).command, 'help');
    assert.equal(parseArgs(['--help']).command, 'help');
    assert.equal(parseArgs(['-h']).command, 'help');
  });

  it('parses run --db path', () => {
    const r = parseArgs(['run', '--db', '/var/tideway.db']);
    assert.equal(r.command, 'run');
    assert.equal(r.db, '/var/tideway.db');
  });

  it('parses status --db path --json', () => {
    const r = parseArgs(['status', '--db', '/var/x.db', '--json']);
    assert.equal(r.command, 'status');
    assert.equal(r.db, '/var/x.db');
    assert.equal(r.json, true);
  });

  it('json flag without command not allowed standalone', () => {
    assert.throws(() => parseArgs(['--json']));
  });

  it('rejects unknown command', () => {
    assert.throws(() => parseArgs(['unknown-command']));
  });

  it('fails on unknown flag', () => {
    assert.throws(() => parseArgs(['run', '--db', 'x', '--flubber']));
  });
});

describe('HELP_TEXT', () => {
  it('mentions all subcommands', () => {
    assert.match(HELP_TEXT, /run/);
    assert.match(HELP_TEXT, /status/);
    assert.match(HELP_TEXT, /help/);
  });

  it('describes the --db and --json flags', () => {
    assert.match(HELP_TEXT, /--db/);
    assert.match(HELP_TEXT, /--json/);
  });
});
