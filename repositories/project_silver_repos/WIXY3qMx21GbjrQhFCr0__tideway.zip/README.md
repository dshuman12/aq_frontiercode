# tideway

An in-process workflow runtime for Node. DAG-shaped execution with
durable retries, transactional outbox, and caller-keyed idempotency.

Tideway is what you embed in your service when you'd otherwise write
ad-hoc try/retry loops or pull in a broker like BullMQ + Redis. It
runs in a single Node process, persists state to a local SQLite file,
and recovers automatically on crash.

## Status

Active development. Public API is stable for the package set listed
in [docs/architecture.md](docs/architecture.md). RFC 0012 (fan-in /
fan-out semantics) is still draft and may produce a behavior change
in 0.5.0; nothing else is expected to break.

## What it does

- DAG executor: declare nodes with parents, the runtime dispatches in
  topological order with deadline-aware scheduling
- Durable retries: configurable per-policy backoff with jitter
- Caller-keyed idempotency: pass an `idempotencyKey` and the runtime
  guarantees one execution per (handler, key) within a TTL window
- Transactional outbox: side-effects commit atomically with the run
  state change
- Cron-scheduled workflows
- Dead-letter queue with operator inspection and replay tooling
- OpenTelemetry-shaped span emission
- A console CLI for inspection / cancel / drain / dlq operations

## What it does NOT do

- Cross-host distribution (use Temporal). See RFC 0013.
- Locale-aware cron (UTC only). See RFC 0011.
- Time-travel debugging beyond replay-from-event-log.

## Quick start

```bash
npm ci
npm run build
npm test
```

To embed the runtime in your service:

```ts
import { start } from '@tideway/app-runner';

const runtime = await start({
  dbPath: '/var/lib/tideway/tideway.db',
  socketPath: '/var/run/tideway.sock',
  workerCount: 8,
  defaultLeaseTtlMs: 30_000,
});

// register handlers, submit work, etc.
// (see examples/ - not yet present, sorry)

await runtime.stop();
```

## Architecture

See [docs/architecture.md](docs/architecture.md). The short version:
the runtime is split into 16 packages plus 2 apps and 2 tools. Each
package has a single responsibility. The runner daemon glues them
together; everything below the runner is testable in isolation.

## Design decisions

Major decisions live in [docs/rfcs/](docs/rfcs/). The most useful
ones to read first:

- [0001 in-process runtime shape](docs/rfcs/0001-runtime-shape.md)
- [0003 caller-keyed idempotency](docs/rfcs/0003-idempotency-model.md)
- [0007 transactional outbox](docs/rfcs/0007-outbox.md)

## Operations

Runbooks for common incidents: [docs/runbooks/](docs/runbooks/).

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md). Short version: tests must
pass, lint must be clean, commits are imperative-mood plain prose.

## License

MIT.
