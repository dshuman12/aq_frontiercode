// Conformance scenarios.
//
// Each scenario describes:
//   - a small DAG (with declared queue, priority, deadline, fail/succeed
//     hint per node)
//   - a sequence of "ticks" the scheduler experiences
//   - the expected runstate.kind for each node at the end
//
// The conformance runner walks each scenario and asserts. The point is
// to have many small parameterized scenarios that catch regressions in
// scheduler/runstate composition; if one scenario fails, the failure
// message identifies which scenario without you having to re-read the
// implementation.

export interface ScenarioNode {
  id: string;
  parents: string[];
  queue?: string;
  priority?: number;
  // Deadline declared at this node, in ms-since-epoch. Use Infinity for
  // unbounded.
  deadline?: number;
  // What the worker would return if dispatched.
  outcome: 'succeed' | 'fail-permanent' | 'fail-retryable';
}

export interface Scenario {
  name: string;
  nodes: ScenarioNode[];
  // The simulated scheduler tick interval and total ticks. Each tick the
  // scheduler decides what to dispatch, and (in the simulator) every
  // dispatched node immediately resolves per its outcome.
  initialNow: number;
  tickMs: number;
  maxTicks: number;
  // Expected end states keyed by node id.
  expected: Record<string, 'succeeded' | 'failed' | 'canceled' | 'queued' | 'running'>;
}

export const SCENARIOS: Scenario[] = [
  {
    name: 'linear-success-chain',
    nodes: [
      { id: 'a', parents: [], outcome: 'succeed' },
      { id: 'b', parents: ['a'], outcome: 'succeed' },
      { id: 'c', parents: ['b'], outcome: 'succeed' },
    ],
    initialNow: 1000,
    tickMs: 100,
    maxTicks: 10,
    expected: { a: 'succeeded', b: 'succeeded', c: 'succeeded' },
  },
  {
    name: 'fan-out-fan-in-success',
    nodes: [
      { id: 'root', parents: [], outcome: 'succeed' },
      { id: 'm1', parents: ['root'], outcome: 'succeed' },
      { id: 'm2', parents: ['root'], outcome: 'succeed' },
      { id: 'm3', parents: ['root'], outcome: 'succeed' },
      { id: 'tail', parents: ['m1', 'm2', 'm3'], outcome: 'succeed' },
    ],
    initialNow: 1000,
    tickMs: 100,
    maxTicks: 20,
    expected: { root: 'succeeded', m1: 'succeeded', m2: 'succeeded', m3: 'succeeded', tail: 'succeeded' },
  },
  {
    name: 'parent-fails-children-canceled',
    nodes: [
      { id: 'a', parents: [], outcome: 'fail-permanent' },
      { id: 'b', parents: ['a'], outcome: 'succeed' },
      { id: 'c', parents: ['b'], outcome: 'succeed' },
    ],
    initialNow: 1000,
    tickMs: 100,
    maxTicks: 10,
    // a fails, b is canceled (parent failure), c is canceled on the
    // following tick (b is now terminal-canceled, which is treated as
    // parent failure for c).
    expected: { a: 'failed', b: 'canceled', c: 'canceled' },
  },
  {
    name: 'one-branch-fails-other-succeeds',
    nodes: [
      { id: 'root', parents: [], outcome: 'succeed' },
      { id: 'left', parents: ['root'], outcome: 'fail-permanent' },
      { id: 'right', parents: ['root'], outcome: 'succeed' },
    ],
    initialNow: 1000,
    tickMs: 100,
    maxTicks: 10,
    expected: { root: 'succeeded', left: 'failed', right: 'succeeded' },
  },
  {
    name: 'deadline-breach-cancels-everything',
    nodes: [
      { id: 'a', parents: [], outcome: 'succeed', deadline: 500 },
      { id: 'b', parents: ['a'], outcome: 'succeed' },
      { id: 'c', parents: ['b'], outcome: 'succeed' },
    ],
    initialNow: 1000, // already past 500
    tickMs: 100,
    maxTicks: 10,
    expected: { a: 'canceled', b: 'canceled', c: 'canceled' },
  },
  {
    name: 'diamond-success',
    nodes: [
      { id: 'a', parents: [], outcome: 'succeed' },
      { id: 'b', parents: ['a'], outcome: 'succeed' },
      { id: 'c', parents: ['a'], outcome: 'succeed' },
      { id: 'd', parents: ['b', 'c'], outcome: 'succeed' },
    ],
    initialNow: 1000,
    tickMs: 100,
    maxTicks: 15,
    expected: { a: 'succeeded', b: 'succeeded', c: 'succeeded', d: 'succeeded' },
  },
  {
    name: 'partial-deadline-leaves-root-running',
    nodes: [
      { id: 'a', parents: [], outcome: 'succeed' },
      { id: 'b', parents: ['a'], outcome: 'succeed', deadline: 500 },
    ],
    initialNow: 1000,
    tickMs: 100,
    maxTicks: 10,
    expected: { a: 'succeeded', b: 'canceled' },
  },
];
