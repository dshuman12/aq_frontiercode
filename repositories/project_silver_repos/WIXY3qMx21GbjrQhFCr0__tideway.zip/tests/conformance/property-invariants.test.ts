// Property-style conformance suite.
//
// Each property is asserted across many randomly-generated inputs.
// Failures bisect cleanly because the seed is fixed and the input
// is reconstructed from the same seed inside the failure message.
//
// These properties are the ones we care about most operationally:
//
//   - The FSM never produces an "unknown" state from a legal event
//     sequence.
//   - DAG topological order respects every parent->child edge.
//   - Replay of any prefix of a valid event log produces a state
//     that the in-line apply would have produced at that LSN.
//   - The deadline propagation rule (min over parents + own) is
//     monotone: tighter parents never loosen a child.
//
// We bound each property at 200 trials. The CI nightly job overrides
// this to 5000 via TIDEWAY_FUZZ_TRIALS.

import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { Graph } from '../../packages/dag/src/index.ts';
import { topologicalOrder } from '../../packages/dag/src/topology.ts';
import { propagate, type DeadlinedNode } from '../../packages/deadline/src/index.ts';
import { initialState, transition, type Event, type RunState } from '../../packages/runstate/src/index.ts';
import { replayAll, type LogEntry } from '../../packages/replay/src/index.ts';

const TRIALS = Number(process.env.TIDEWAY_FUZZ_TRIALS ?? 200);

class Rng {
  private state: number;
  constructor(seed: number) {
    this.state = (seed >>> 0) || 1;
  }
  next(): number {
    let x = this.state;
    x ^= x << 13;
    x ^= x >>> 17;
    x ^= x << 5;
    return (this.state = x >>> 0);
  }
  int(n: number): number {
    return this.next() % n;
  }
  pick<T>(arr: T[]): T {
    return arr[this.int(arr.length)]!;
  }
}

const t = (n: number) => BigInt(n);

function randomDag(rng: Rng, n: number, edgeProb: number): Graph<DeadlinedNode> {
  const g = new Graph<DeadlinedNode>();
  for (let i = 0; i < n; i += 1) {
    g.addNode(`n${i}`, { declaredDeadline: rng.int(2) === 0 ? Infinity : 1000 + rng.int(10_000) });
  }
  for (let i = 0; i < n; i += 1) {
    for (let j = i + 1; j < n; j += 1) {
      if (rng.next() / 0xffffffff < edgeProb) {
        g.addEdge(`n${i}`, `n${j}`);
      }
    }
  }
  return g;
}

describe('property: topo order respects every edge', () => {
  it('parent precedes every child', () => {
    const rng = new Rng(0xcafe1);
    for (let trial = 0; trial < TRIALS; trial += 1) {
      const g = randomDag(rng, 10 + rng.int(15), 0.2);
      const r = topologicalOrder(g);
      if (!r.acyclic) continue; // generator is acyclic, but defense
      const pos = new Map<string, number>();
      r.order.forEach((id, i) => pos.set(id, i));
      for (const id of g.allNodes()) {
        for (const c of g.childrenOf(id)) {
          assert.ok(
            pos.get(id)! < pos.get(c)!,
            `trial ${trial}: ${id} (pos ${pos.get(id)}) >= ${c} (pos ${pos.get(c)})`,
          );
        }
      }
    }
  });
});

describe('property: deadline propagation is monotone', () => {
  it('tightening any parent never loosens a child', () => {
    const rng = new Rng(0xfee2);
    for (let trial = 0; trial < TRIALS; trial += 1) {
      const g = randomDag(rng, 8 + rng.int(8), 0.3);
      const before = propagate(g);

      // Pick a node with at least one declared deadline and tighten it.
      const targets = g.allNodes().filter((id) => g.get(id).declaredDeadline !== Infinity);
      if (targets.length === 0) continue;
      const target = rng.pick(targets);
      const original = g.get(target).declaredDeadline;
      g.updateValue(target, { declaredDeadline: original / 2 });
      const after = propagate(g);

      // For every node, after.effective <= before.effective.
      for (const id of g.allNodes()) {
        assert.ok(
          (after.effective.get(id) ?? Infinity) <= (before.effective.get(id) ?? Infinity),
          `trial ${trial}: ${id} loosened from ${before.effective.get(id)} to ${after.effective.get(id)}`,
        );
      }
    }
  });
});

describe('property: prefix replay equivalence', () => {
  it('replay of N events == in-line apply through N events', () => {
    const rng = new Rng(0xa7c5);
    for (let trial = 0; trial < Math.min(TRIALS, 50); trial += 1) {
      // Build a valid event sequence by stepping through legal transitions.
      const runId = `r-${trial}`;
      const log: LogEntry[] = [{ lsn: 1, runId, kind: 'created', at: t(0) }];
      let state: RunState = initialState(t(0));
      let lsn = 2;
      let now = 1;
      let attempt = 1;

      for (let step = 0; step < 6; step += 1) {
        const events = legalEvents(state, attempt, now);
        if (events.length === 0) break;
        const event = rng.pick(events);
        try {
          state = transition(state, event, event.kind === 'dispatch' ? { attempt } : {});
        } catch {
          break;
        }
        log.push({
          lsn: lsn++,
          runId,
          event,
          ...(event.kind === 'dispatch' ? { attempt } : {}),
        });
        if (event.kind === 'dispatch' && state.kind === 'running') {
          // attempt increments only on retry-scheduled -> running
        }
        now += 100;
        if (
          state.kind === 'succeeded' ||
          state.kind === 'failed' ||
          state.kind === 'canceled' ||
          state.kind === 'timed_out'
        ) {
          break;
        }
      }

      // Pick a random prefix and assert replay equivalence.
      const prefixLen = 1 + rng.int(log.length);
      const prefix = log.slice(0, prefixLen);
      // Replay the prefix.
      const r = replayAll(prefix);
      // Re-apply manually.
      let manual: RunState = initialState(t(0));
      for (let i = 1; i < prefixLen; i += 1) {
        const entry = log[i]!;
        if ('event' in entry) {
          try {
            manual = transition(
              manual,
              entry.event,
              entry.attempt !== undefined ? { attempt: entry.attempt } : {},
            );
          } catch {
            // illegal sub-sequence; replay should also have skipped.
          }
        }
      }
      const recovered = r.states.get(runId);
      assert.equal(
        recovered?.kind,
        manual.kind,
        `trial ${trial}, prefix ${prefixLen}: replay=${recovered?.kind}, manual=${manual.kind}`,
      );
    }
  });
});

function legalEvents(state: RunState, _attempt: number, now: number): Event[] {
  switch (state.kind) {
    case 'queued':
      return [
        { kind: 'dispatch', at: t(now), workerId: 'w', leaseExpiresAt: t(now + 30_000) },
        { kind: 'cancel', at: t(now), reason: 'external' },
        { kind: 'time_out', at: t(now), deadlineWas: t(now - 1) },
      ];
    case 'running':
      return [
        { kind: 'heartbeat', at: t(now), leaseExpiresAt: t(now + 30_000) },
        { kind: 'succeed', at: t(now), result: null },
        { kind: 'fail', at: t(now), failureKind: 'permanent', message: 'x' },
        { kind: 'schedule_retry', at: t(now), nextAttemptAt: t(now + 1000) },
        { kind: 'cancel', at: t(now), reason: 'external' },
        { kind: 'lease_expire', at: t(now) },
      ];
    case 'retry_scheduled':
      return [
        { kind: 'requeue', at: t(now) },
        { kind: 'cancel', at: t(now), reason: 'external' },
      ];
    default:
      return [];
  }
}

// Cycle-detection rotation property is covered in tests/fuzz/random-dag.test.ts;
// no need to re-test here.
