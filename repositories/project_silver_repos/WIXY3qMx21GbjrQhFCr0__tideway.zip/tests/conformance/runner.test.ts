// Conformance runner: walks each scenario through the simulated
// scheduler + transition machinery and asserts the expected end states.
//
// One subtle thing we get for free here: every scenario exercises the
// same loop, so a regression in any one of {dispatch, transition,
// deadline propagation, parent-failure cancellation} usually breaks
// multiple scenarios with consistent failure shapes, which makes the
// regression visible at a glance in CI.

import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { Graph } from '../../packages/dag/src/index.ts';
import { propagate, type DeadlinedNode } from '../../packages/deadline/src/index.ts';
import {
  type RunState,
  initialState,
  transition,
} from '../../packages/runstate/src/index.ts';
import { QueueLimits, decide, type SchedulableNode } from '../../packages/scheduler/src/index.ts';

import { SCENARIOS, type Scenario } from './scenarios.ts';

const t = (n: number) => BigInt(n);

type Node = SchedulableNode & DeadlinedNode & { outcome: Scenario['nodes'][0]['outcome'] };

function run(scenario: Scenario): Map<string, RunState> {
  const g = new Graph<Node>();
  for (const n of scenario.nodes) {
    g.addNode(n.id, {
      queue: n.queue ?? 'default',
      priority: n.priority ?? 0,
      declaredDeadline: n.deadline ?? Infinity,
      outcome: n.outcome,
    });
  }
  for (const n of scenario.nodes) {
    for (const p of n.parents) g.addEdge(p, n.id);
  }
  const states = new Map<string, RunState>();
  for (const id of g.allNodes()) states.set(id, initialState(t(0)));
  const limits = new QueueLimits();
  const propagated = propagate(g);

  let now = scenario.initialNow;
  for (let tick = 0; tick < scenario.maxTicks; tick += 1) {
    const decision = decide(g, states, limits, {
      now,
      freeWorkers: 16,
      effectiveDeadline: propagated.effective,
    });

    // Apply dispatch -> resolve immediately according to outcome.
    for (const id of decision.dispatch) {
      let s = states.get(id)!;
      s = transition(s, {
        kind: 'dispatch',
        at: t(now),
        workerId: 'w',
        leaseExpiresAt: t(now + 30_000),
      });
      const outcome = g.get(id).outcome;
      if (outcome === 'succeed') {
        s = transition(s, { kind: 'succeed', at: t(now + 10), result: null });
      } else if (outcome === 'fail-permanent') {
        s = transition(s, {
          kind: 'fail',
          at: t(now + 10),
          failureKind: 'permanent',
          message: 'scenario-failed',
        });
      } else if (outcome === 'fail-retryable') {
        s = transition(s, {
          kind: 'fail',
          at: t(now + 10),
          failureKind: 'retryable',
          message: 'scenario-retry',
        });
      }
      states.set(id, s);
      limits.release(g.get(id).queue);
    }

    // Apply cancel + parent-failure-cancel.
    for (const id of decision.cancel) {
      const s = states.get(id);
      if (!s || s.kind !== 'queued') continue;
      states.set(id, transition(s, { kind: 'cancel', at: t(now), reason: 'deadline' }));
    }
    for (const id of decision.parentFailureCancel) {
      const s = states.get(id);
      if (!s || s.kind !== 'queued') continue;
      states.set(id, transition(s, { kind: 'cancel', at: t(now), reason: 'parent_failure' }));
    }

    now += scenario.tickMs;

    // Early exit if nothing active.
    const active = Array.from(states.values()).some(
      (s) => s.kind === 'queued' || s.kind === 'running' || s.kind === 'retry_scheduled',
    );
    if (!active) break;
  }
  return states;
}

describe('conformance', () => {
  for (const scenario of SCENARIOS) {
    it(`scenario: ${scenario.name}`, () => {
      const final = run(scenario);
      for (const [id, expectedKind] of Object.entries(scenario.expected)) {
        const actual = final.get(id);
        assert.ok(actual, `node ${id} missing from final states`);
        assert.equal(
          actual!.kind,
          expectedKind,
          `node ${id}: expected ${expectedKind}, got ${actual!.kind}`,
        );
      }
    });
  }
});
