// Property-style fuzz of the runstate FSM.
//
// We generate random valid event sequences (using a grammar that only
// emits transitions legal from the current state) and assert that:
//
//   - replayAll on the resulting log produces the same final state as
//     the in-line transition application
//   - the FSM never throws on a sequence we generated
//   - applying the sequence twice (replay then replay) produces the
//     same end state (idempotence)

import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import {
  type Event,
  type RunState,
  initialState,
  transition,
} from '../../packages/runstate/src/index.ts';
import { replayAll, type LogEntry } from '../../packages/replay/src/index.ts';

class Rng {
  private state: number;
  constructor(seed: number) {
    this.state = seed >>> 0 || 1;
  }
  next(): number {
    let x = this.state;
    x ^= x << 13;
    x ^= x >>> 17;
    x ^= x << 5;
    this.state = x >>> 0;
    return this.state;
  }
  int(n: number): number {
    return this.next() % n;
  }
  pick<T>(arr: T[]): T {
    return arr[this.int(arr.length)]!;
  }
}

const t = (n: number) => BigInt(n);

interface RandomSession {
  log: LogEntry[];
  finalState: RunState;
}

function generate(rng: Rng): RandomSession {
  const runId = `r-${rng.int(10_000)}`;
  let lsn = 1;
  let now = 0;
  const log: LogEntry[] = [{ lsn: lsn++, runId, kind: 'created', at: t(now) }];
  let state: RunState = initialState(t(now));
  let attempt = 1;

  for (let step = 0; step < 30; step += 1) {
    now += 1 + rng.int(1000);
    const events = legalEvents(state, attempt, now);
    if (events.length === 0) break;
    const choice = rng.pick(events);
    if (choice.kind === 'dispatch' && state.kind === 'retry_scheduled') {
      attempt = state.attempt + 1;
    } else if (choice.kind === 'dispatch' && state.kind === 'queued') {
      // attempt stays whatever it was; first dispatch uses opts={attempt}
    }
    state = transition(state, choice, choice.kind === 'dispatch' ? { attempt } : {});
    log.push({ lsn: lsn++, runId, event: choice, ...(choice.kind === 'dispatch' ? { attempt } : {}) });

    if (
      state.kind === 'succeeded' ||
      state.kind === 'failed' ||
      state.kind === 'canceled' ||
      state.kind === 'timed_out'
    ) {
      break;
    }
  }
  return { log, finalState: state };
}

function legalEvents(state: RunState, attempt: number, now: number): Event[] {
  switch (state.kind) {
    case 'queued':
      return [
        { kind: 'dispatch', at: t(now), workerId: 'w', leaseExpiresAt: t(now + 30_000) },
        { kind: 'cancel', at: t(now), reason: 'external' },
        { kind: 'time_out', at: t(now), deadlineWas: t(now - 1) },
      ];
    case 'running':
      return [
        { kind: 'heartbeat', at: t(now), leaseExpiresAt: t(now + 30_000) },
        { kind: 'succeed', at: t(now), result: null },
        { kind: 'fail', at: t(now), failureKind: 'permanent', message: 'x' },
        { kind: 'schedule_retry', at: t(now), nextAttemptAt: t(now + 1000) },
        { kind: 'cancel', at: t(now), reason: 'external' },
        { kind: 'time_out', at: t(now), deadlineWas: t(now - 1) },
        { kind: 'lease_expire', at: t(now) },
      ];
    case 'retry_scheduled':
      return [
        { kind: 'requeue', at: t(now) },
        { kind: 'dispatch', at: t(now), workerId: 'w', leaseExpiresAt: t(now + 30_000) },
        { kind: 'cancel', at: t(now), reason: 'external' },
      ];
    default:
      return [];
  }
  // Reserved: attempt is read by callers via opts; not used to filter
  // legal events here.
  void attempt;
}

describe('fuzz: FSM event sequences', () => {
  it('replay produces the same final state as in-line application', () => {
    const rng = new Rng(0xfa57);
    for (let trial = 0; trial < 100; trial += 1) {
      const session = generate(rng);
      const r = replayAll(session.log);
      const recovered = Array.from(r.states.values())[0];
      assert.equal(
        recovered?.kind,
        session.finalState.kind,
        `trial ${trial}: replay diverged from in-line`,
      );
    }
  });

  it('replay is idempotent: replaying an empty extra batch does not change state', () => {
    const rng = new Rng(0x1d77);
    for (let trial = 0; trial < 50; trial += 1) {
      const session = generate(rng);
      const a = replayAll(session.log);
      const b = replayAll(session.log);
      const aFinal = Array.from(a.states.values())[0];
      const bFinal = Array.from(b.states.values())[0];
      assert.equal(aFinal?.kind, bFinal?.kind);
    }
  });

  it('every generated sequence ends in an active or terminal state', () => {
    const rng = new Rng(0x5eed);
    for (let trial = 0; trial < 50; trial += 1) {
      const session = generate(rng);
      const valid = [
        'queued',
        'running',
        'retry_scheduled',
        'succeeded',
        'failed',
        'canceled',
        'timed_out',
      ];
      assert.ok(valid.includes(session.finalState.kind), `unknown end state: ${session.finalState.kind}`);
    }
  });
});

describe('fuzz: replay tolerates corruption', () => {
  it('skipping a few entries never crashes replay', () => {
    const rng = new Rng(0xb4ad);
    for (let trial = 0; trial < 30; trial += 1) {
      const session = generate(rng);
      // Drop a random middle entry. Any resulting illegal-transition
      // skips should be reflected in r.skipped, not in a thrown error.
      if (session.log.length < 3) continue;
      const dropAt = 1 + rng.int(session.log.length - 2);
      const corrupted = [...session.log.slice(0, dropAt), ...session.log.slice(dropAt + 1)];
      const r = replayAll(corrupted);
      assert.ok(r.applied + r.skipped === corrupted.length);
    }
  });
});
