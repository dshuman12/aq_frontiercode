// Property-style fuzz tests for DAG construction and validation.
//
// The seed is fixed so failures are reproducible. A failure in CI shows
// the seed in its trace, and re-running with the same seed reproduces.

import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { Graph } from '../../packages/dag/src/index.ts';
import { cycles, isAcyclic } from '../../packages/dag/src/cycles.ts';
import { topologicalOrder } from '../../packages/dag/src/topology.ts';
import { parallelizable } from '../../packages/dag/src/layers.ts';
import { validate } from '../../packages/dag/src/index.ts';

class Rng {
  private state: number;
  constructor(seed: number) {
    this.state = seed >>> 0 || 1;
  }
  // xorshift32
  next(): number {
    let x = this.state;
    x ^= x << 13;
    x ^= x >>> 17;
    x ^= x << 5;
    this.state = x >>> 0;
    return this.state;
  }
  int(n: number): number {
    return this.next() % n;
  }
}

function randomAcyclicGraph(rng: Rng, nodeCount: number, edgeProb: number): Graph<null> {
  const g = new Graph<null>();
  for (let i = 0; i < nodeCount; i += 1) g.addNode(`n${i}`, null);
  // Edges only go from lower-index to higher-index, which guarantees
  // acyclicity.
  for (let i = 0; i < nodeCount; i += 1) {
    for (let j = i + 1; j < nodeCount; j += 1) {
      if (rng.next() / 0xffffffff < edgeProb) {
        g.addEdge(`n${i}`, `n${j}`);
      }
    }
  }
  return g;
}

describe('fuzz: random acyclic graphs', () => {
  it('isAcyclic is always true for graphs constructed with strictly-increasing edges', () => {
    const rng = new Rng(0xfeed);
    for (let trial = 0; trial < 50; trial += 1) {
      const g = randomAcyclicGraph(rng, 20 + rng.int(30), 0.1 + (rng.int(100) / 100) * 0.3);
      assert.equal(isAcyclic(g), true, `trial ${trial}: graph reported as cyclic`);
    }
  });

  it('topologicalOrder returns every node exactly once', () => {
    const rng = new Rng(0xc0de);
    for (let trial = 0; trial < 50; trial += 1) {
      const g = randomAcyclicGraph(rng, 30, 0.2);
      const r = topologicalOrder(g);
      assert.equal(r.acyclic, true);
      assert.equal(r.order.length, g.size());
      assert.equal(new Set(r.order).size, g.size());
    }
  });

  it('topologicalOrder respects edges: parent comes before child', () => {
    const rng = new Rng(0xbeef);
    for (let trial = 0; trial < 30; trial += 1) {
      const g = randomAcyclicGraph(rng, 25, 0.25);
      const r = topologicalOrder(g);
      const positions = new Map<string, number>();
      r.order.forEach((id, i) => positions.set(id, i));
      for (const id of g.allNodes()) {
        for (const child of g.childrenOf(id)) {
          assert.ok(
            positions.get(id)! < positions.get(child)!,
            `parent ${id} appeared after child ${child}`,
          );
        }
      }
    }
  });

  it('parallelizable: every node ends up in exactly one layer', () => {
    const rng = new Rng(0xdecaf);
    for (let trial = 0; trial < 30; trial += 1) {
      const g = randomAcyclicGraph(rng, 20, 0.2);
      const layering = parallelizable(g);
      const seen = new Set<string>();
      for (const layer of layering.layers) {
        for (const id of layer) {
          assert.equal(seen.has(id), false, `node ${id} in multiple layers`);
          seen.add(id);
        }
      }
      assert.equal(seen.size, g.size());
    }
  });

  it('parallelizable layer N has no edges into layer < N', () => {
    const rng = new Rng(0xb0a7);
    for (let trial = 0; trial < 30; trial += 1) {
      const g = randomAcyclicGraph(rng, 15, 0.3);
      const layering = parallelizable(g);
      const layerOf = new Map<string, number>();
      layering.layers.forEach((layer, i) => layer.forEach((id) => layerOf.set(id, i)));
      for (const id of g.allNodes()) {
        for (const child of g.childrenOf(id)) {
          const parentLayer = layerOf.get(id)!;
          const childLayer = layerOf.get(child)!;
          assert.ok(
            childLayer > parentLayer,
            `child ${child} in layer ${childLayer} <= parent ${id} in ${parentLayer}`,
          );
        }
      }
    }
  });

  it('validate accepts every random acyclic graph', () => {
    const rng = new Rng(0xa11ce);
    for (let trial = 0; trial < 30; trial += 1) {
      const g = randomAcyclicGraph(rng, 10 + rng.int(20), 0.15);
      const r = validate(g);
      // The only failure mode is "no roots" if every node ended up with
      // a parent, which is impossible here (n0 always has zero parents).
      assert.equal(r.ok, true, `trial ${trial}: ${r.issues.map((i) => i.message).join(', ')}`);
    }
  });
});

describe('fuzz: cycle injection', () => {
  it('injecting a back-edge along an existing forward path always produces a detected cycle', () => {
    const rng = new Rng(0xcafe);
    let trialsWithPaths = 0;
    for (let trial = 0; trial < 50; trial += 1) {
      const g = randomAcyclicGraph(rng, 15, 0.4);
      // Find a (lo, hi) pair where hi is reachable from lo. If none, skip
      // this trial -- low-density graphs simply don't have one. The
      // assertion below is conditioned on the precondition holding.
      const ids = g.allNodes();
      let lo: string | undefined;
      let hi: string | undefined;
      for (let i = 0; i < ids.length && !lo; i += 1) {
        const reach = g.descendants([ids[i]!]);
        for (let j = i + 1; j < ids.length; j += 1) {
          if (reach.has(ids[j]!)) {
            lo = ids[i];
            hi = ids[j];
            break;
          }
        }
      }
      if (!lo || !hi) continue;
      trialsWithPaths += 1;
      g.addEdge(hi, lo);
      const r = cycles(g);
      assert.ok(r.length > 0, `trial ${trial}: cycle injection along a forward path went undetected`);
    }
    // Make sure we exercised the property at least a few times.
    assert.ok(
      trialsWithPaths >= 5,
      `only ${trialsWithPaths} trials had a forward path; tune density`,
    );
  });
});
