// Crash recovery integration test.
//
// We simulate the runner crashing partway through a workflow by
// constructing a log of events, calling recover() against a store
// loaded with that log, and verifying the rebuilt state matches what
// the runner would have had in memory just before the crash.

import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { MemoryStore } from '../../packages/store/src/index.ts';
import type { LogEntry } from '../../packages/replay/src/index.ts';
import { recover } from '../../apps/runner/src/recovery.ts';

const t = (n: number) => BigInt(n);

const created = (lsn: number, runId: string, at = 0): LogEntry => ({
  lsn,
  runId,
  kind: 'created',
  at: t(at),
});

describe('integration: crash recovery', () => {
  it('reconstructs a 3-run mixed-state snapshot', async () => {
    const store = new MemoryStore();
    store.appendLog([
      // r1: queued (just created)
      created(1, 'r1', 100),
      // r2: was running with valid lease at crash time
      created(2, 'r2', 200),
      {
        lsn: 3,
        runId: 'r2',
        event: { kind: 'dispatch', at: t(220), workerId: 'w', leaseExpiresAt: t(60_000) },
      },
      // r3: had succeeded before the crash
      created(4, 'r3', 300),
      {
        lsn: 5,
        runId: 'r3',
        event: { kind: 'dispatch', at: t(310), workerId: 'w', leaseExpiresAt: t(60_000) },
      },
      {
        lsn: 6,
        runId: 'r3',
        event: { kind: 'succeed', at: t(330), result: { ok: true } },
      },
    ]);

    const r = await recover(store, { now: 1000 });
    assert.equal(r.recoveredRuns, 3);
    assert.equal(r.expiredLeasesRequeued, 0);
    assert.equal(r.states.get('r1')?.kind, 'queued');
    assert.equal(r.states.get('r2')?.kind, 'running');
    assert.equal(r.states.get('r3')?.kind, 'succeeded');
    assert.equal(r.highWaterMark, 6);
  });

  it('requeues runs whose leases expired during the outage window', async () => {
    const store = new MemoryStore();
    // Two runs, both running. r1's lease expires at 500; r2's at 5000.
    // The outage spans now=300..now=2000, so by recovery time r1 is
    // dead but r2 is still alive.
    store.appendLog([
      created(1, 'r1', 100),
      {
        lsn: 2,
        runId: 'r1',
        event: { kind: 'dispatch', at: t(120), workerId: 'w', leaseExpiresAt: t(500) },
      },
      created(3, 'r2', 100),
      {
        lsn: 4,
        runId: 'r2',
        event: { kind: 'dispatch', at: t(120), workerId: 'w', leaseExpiresAt: t(5000) },
      },
    ]);
    const r = await recover(store, { now: 2000 });
    assert.equal(r.expiredLeasesRequeued, 1);
    assert.equal(r.states.get('r1')?.kind, 'queued');
    assert.equal(r.states.get('r2')?.kind, 'running');
  });

  it('prefix replay equivalence: stopping at LSN N gives state-at-N', async () => {
    const fullLog: LogEntry[] = [
      created(1, 'r1', 100),
      {
        lsn: 2,
        runId: 'r1',
        event: { kind: 'dispatch', at: t(120), workerId: 'w', leaseExpiresAt: t(60_000) },
      },
      {
        lsn: 3,
        runId: 'r1',
        event: { kind: 'succeed', at: t(140), result: 'done' },
      },
    ];

    // Replay through LSN 2 and check r1 is running. We pass an explicit
    // `now` close to the lease window, otherwise the default now=Date.now()
    // sees the lease as long-expired and requeues the run.
    const partial = new MemoryStore();
    partial.appendLog(fullLog.slice(0, 2));
    const r2 = await recover(partial, { now: 130 });
    assert.equal(r2.states.get('r1')?.kind, 'running');

    // Now full replay; r1 must be succeeded regardless of `now`.
    const full = new MemoryStore();
    full.appendLog(fullLog);
    const r3 = await recover(full);
    assert.equal(r3.states.get('r1')?.kind, 'succeeded');
  });

  it('handles a corrupted log entry without aborting the whole recovery', async () => {
    const store = new MemoryStore();
    store.appendLog([
      created(1, 'r1', 100),
      // Illegal: heartbeat from queued.
      {
        lsn: 2,
        runId: 'r1',
        event: { kind: 'heartbeat', at: t(120), leaseExpiresAt: t(500) },
      },
      // Recover continues with a real dispatch.
      {
        lsn: 3,
        runId: 'r1',
        event: { kind: 'dispatch', at: t(130), workerId: 'w', leaseExpiresAt: t(60_000) },
      },
    ]);
    const r = await recover(store, { now: 200 });
    assert.equal(r.appliedEntries, 2);
    assert.equal(r.skippedEntries, 1);
    assert.equal(r.states.get('r1')?.kind, 'running');
  });

  it('starts cleanly from an empty store', async () => {
    const r = await recover(new MemoryStore());
    assert.equal(r.recoveredRuns, 0);
    assert.equal(r.appliedEntries, 0);
    assert.equal(r.highWaterMark, 0);
    assert.equal(r.states.size, 0);
  });
});
