// Deadline cascade integration.
//
// A workflow declares a tight deadline at the root. The deadline must
// propagate to every descendant; nodes whose effective deadline lapses
// before their dispatch turn must be canceled with reason='deadline'
// rather than dispatched and discovered mid-execution.

import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { Graph } from '../../packages/dag/src/index.ts';
import {
  type RunState,
  initialState,
  transition,
} from '../../packages/runstate/src/index.ts';
import { QueueLimits, decide, type SchedulableNode } from '../../packages/scheduler/src/index.ts';
import { propagate, type DeadlinedNode } from '../../packages/deadline/src/index.ts';

type Node = SchedulableNode & DeadlinedNode;

const t = (n: number) => BigInt(n);

const node = (declaredDeadline: number): Node => ({
  queue: 'default',
  priority: 0,
  declaredDeadline,
});

describe('integration: deadline cascade', () => {
  it('deadline at the root binds every descendant', () => {
    const g = new Graph<Node>();
    g.addNode('root', node(2000));
    g.addNode('mid', node(Infinity));
    g.addNode('leaf', node(Infinity));
    g.addEdge('root', 'mid').addEdge('mid', 'leaf');
    const p = propagate(g);
    assert.equal(p.effective.get('root'), 2000);
    assert.equal(p.effective.get('mid'), 2000);
    assert.equal(p.effective.get('leaf'), 2000);
  });

  it('scheduler cancels a queued node whose effective deadline already breached', () => {
    const g = new Graph<Node>();
    g.addNode('a', node(1000));
    const states = new Map<string, RunState>();
    states.set('a', initialState(t(0)));
    const propagated = propagate(g);
    const decision = decide(g, states, new QueueLimits(), {
      now: 1500,
      freeWorkers: 8,
      effectiveDeadline: propagated.effective,
    });
    assert.deepEqual(decision.cancel, ['a']);
    assert.deepEqual(decision.dispatch, []);
  });

  it('a child inherits parent deadline even if its own is laxer', () => {
    const g = new Graph<Node>();
    g.addNode('parent', node(500));
    g.addNode('child', node(10_000));
    g.addEdge('parent', 'child');
    const p = propagate(g);
    assert.equal(p.effective.get('child'), 500);
  });

  it('diamond child takes the strictest of multiple parents', () => {
    const g = new Graph<Node>();
    g.addNode('p1', node(2000));
    g.addNode('p2', node(800));
    g.addNode('child', node(Infinity));
    g.addEdge('p1', 'child').addEdge('p2', 'child');
    const p = propagate(g);
    assert.equal(p.effective.get('child'), 800);
  });

  it('parent failure cancels descendants on the next tick', () => {
    const g = new Graph<Node>();
    g.addNode('a', node(Infinity));
    g.addNode('b', node(Infinity));
    g.addEdge('a', 'b');
    const states = new Map<string, RunState>();
    let s = initialState(t(0));
    s = transition(s, {
      kind: 'dispatch',
      at: t(10),
      workerId: 'w',
      leaseExpiresAt: t(60_000),
    });
    s = transition(s, { kind: 'fail', at: t(20), failureKind: 'permanent', message: 'x' });
    states.set('a', s);
    states.set('b', initialState(t(0)));
    const propagated = propagate(g);
    const decision = decide(g, states, new QueueLimits(), {
      now: 30,
      freeWorkers: 8,
      effectiveDeadline: propagated.effective,
    });
    assert.deepEqual(decision.parentFailureCancel, ['b']);
  });

  it('deadline ordering: scheduler dispatches the earliest-deadline node first', () => {
    const g = new Graph<Node>();
    g.addNode('low-prio', node(5000));
    g.addNode('high-prio', node(1500));
    const states = new Map<string, RunState>();
    states.set('low-prio', initialState(t(0)));
    states.set('high-prio', initialState(t(0)));
    const propagated = propagate(g);
    const decision = decide(g, states, new QueueLimits(), {
      now: 1000,
      freeWorkers: 1,
      effectiveDeadline: propagated.effective,
    });
    assert.deepEqual(decision.dispatch, ['high-prio']);
  });

  it('child of a long parent inherits no deadline if neither declared one', () => {
    const g = new Graph<Node>();
    g.addNode('a', node(Infinity));
    g.addNode('b', node(Infinity));
    g.addEdge('a', 'b');
    const p = propagate(g);
    assert.equal(p.effective.get('b'), Infinity);
  });
});
