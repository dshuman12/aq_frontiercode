// Integration: the observability bridge.
//
// The runtime exposes metrics, audit events, and pulse heartbeats via
// distinct packages, but they share a few cross-cutting invariants that
// only show up when the three are exercised together. This file checks
// those invariants.

import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { AuditLog, isSubmit } from '../../packages/audit/src/index.ts';
import { Counter, Gauge, MetricRegistry, exportPrometheus } from '../../packages/metrics/src/index.ts';
import { HealthRegistry, alwaysHealthy, thresholdProbe } from '../../packages/health/src/index.ts';
import { PulseMonitor } from '../../packages/pulse/src/index.ts';

class FakeClock {
  constructor(public t = 1000) {}
  now = () => this.t;
  advance(ms: number) {
    this.t += ms;
  }
}

describe('integration: metrics + audit work together', () => {
  it('every audit submit increments a counter cell', () => {
    const audit = new AuditLog();
    const reg = new MetricRegistry();
    const submits = reg.registerCounter(new Counter('audit_submits_total', 'Audit submits', ['handler']));
    audit.attachSink((e) => {
      if (isSubmit(e)) submits.inc({ handler: e.handler });
    });

    audit.append({ kind: 'submit', runId: 'r-1', handler: 'email', dedup: false });
    audit.append({ kind: 'submit', runId: 'r-2', handler: 'email', dedup: false });
    audit.append({ kind: 'submit', runId: 'r-3', handler: 'audit', dedup: false });

    assert.equal(submits.get({ handler: 'email' }), 2);
    assert.equal(submits.get({ handler: 'audit' }), 1);
  });

  it('Prometheus export contains audit-driven counters', () => {
    const audit = new AuditLog();
    const reg = new MetricRegistry();
    const submits = reg.registerCounter(new Counter('runs_total', 'Total runs', ['handler']));
    audit.attachSink((e) => {
      if (isSubmit(e)) submits.inc({ handler: e.handler });
    });
    audit.append({ kind: 'submit', runId: 'r-1', handler: 'email', dedup: false });

    const out = exportPrometheus(reg);
    assert.match(out, /runs_total\{handler="email"\} 1/);
  });
});

describe('integration: health + pulse', () => {
  it('a stalled pulse source surfaces as a degraded health probe', async () => {
    const c = new FakeClock(1000);
    const pulse = new PulseMonitor({ clock: c.now });
    pulse.register('scheduler', 1000);
    pulse.beat('scheduler');

    const health = new HealthRegistry({ clock: c.now });
    health.register('pulse-scheduler', () => {
      const status = pulse.status('scheduler');
      return status === 'healthy'
        ? { status: 'healthy' }
        : { status: 'unhealthy', message: 'scheduler tick has stalled' };
    });

    let snap = await health.tick();
    assert.equal(snap.status, 'healthy');

    // Stall the scheduler pulse.
    c.advance(2000);
    snap = await health.forceTick();
    assert.equal(snap.status, 'unhealthy');
    assert.match(snap.probes['pulse-scheduler']?.message ?? '', /stalled/);
  });

  it('threshold probe wired to a gauge tracks degradation correctly', async () => {
    const reg = new MetricRegistry();
    const dlqDepth = reg.registerGauge(new Gauge('tideway_dlq_depth', 'Dead-letter depth'));
    const health = new HealthRegistry();
    health.register('dlq-depth', thresholdProbe({
      read: () => dlqDepth.get(),
      warn: 100,
      fail: 1000,
      message: (v) => `dlq depth is ${v}`,
    }));

    dlqDepth.set(50);
    let snap = await health.tick();
    assert.equal(snap.status, 'healthy');

    dlqDepth.set(200);
    snap = await health.forceTick();
    assert.equal(snap.status, 'degraded');
    assert.match(snap.probes['dlq-depth']?.message ?? '', /200/);

    dlqDepth.set(2000);
    snap = await health.forceTick();
    assert.equal(snap.status, 'unhealthy');
  });
});

describe('integration: audit pruning preserves seq monotonicity', () => {
  it('after prune, new appends keep advancing seq from the pre-prune high-water', () => {
    const c = new FakeClock(0);
    const audit = new AuditLog({ clock: c.now });
    audit.append({ kind: 'drain', graceful: true, inflightAtTime: 0 });
    audit.append({ kind: 'drain', graceful: true, inflightAtTime: 0 });
    c.advance(2000);
    audit.append({ kind: 'drain', graceful: true, inflightAtTime: 0 });
    audit.prune(1000);
    const e = audit.append({ kind: 'drain', graceful: true, inflightAtTime: 0 });
    assert.equal(e.seq, 4);
  });
});

describe('integration: combined health + metrics export', () => {
  it('runtime snapshot view: counters, gauges, and health all readable in one pass', async () => {
    const reg = new MetricRegistry();
    const health = new HealthRegistry();

    reg.registerCounter(new Counter('runs_completed_total', 'Completed', ['handler'])).inc({ handler: 'h' }, 5);
    reg.registerGauge(new Gauge('inflight', 'Inflight')).set(3);
    health.register('store', alwaysHealthy());

    const metricsOut = exportPrometheus(reg);
    const healthSnap = await health.tick();

    assert.match(metricsOut, /runs_completed_total/);
    assert.match(metricsOut, /inflight 3/);
    assert.equal(healthSnap.status, 'healthy');
  });
});

describe('integration: pulse aggregate matches per-source view', () => {
  it('overall stalled when any source stalls', () => {
    const c = new FakeClock(1000);
    const pulse = new PulseMonitor({ clock: c.now });
    pulse.register('a', 1000);
    pulse.register('b', 500);
    pulse.beat('a');
    pulse.beat('b');

    c.advance(750);
    pulse.beat('a');

    // 'b' is past its 500ms window without a beat -> stalled.
    assert.equal(pulse.status('b'), 'stalled');
    assert.equal(pulse.overall(), 'stalled');
  });

  it('snapshot reports correct status for each source', () => {
    const c = new FakeClock(0);
    const pulse = new PulseMonitor({ clock: c.now });
    pulse.register('fast', 100);
    pulse.register('slow', 5000);
    c.advance(200);
    const snap = pulse.snapshot();
    const fast = snap.find((s) => s.name === 'fast')!;
    const slow = snap.find((s) => s.name === 'slow')!;
    assert.equal(fast.status, 'stalled');
    assert.equal(slow.status, 'healthy');
  });
});
