// Full crash-recovery cycle integration test.
//
// This is the test that exists because we lost a workflow once. The
// scenario:
//
//   1. Submit a 6-node DAG. Dispatch the first three.
//   2. Pretend the runner crashes (we serialize the event log to
//      memory).
//   3. Spin up a new "process" backed by the same MemoryStore.
//   4. recover() should rebuild the in-memory state map exactly as
//      the live runner had it before the crash.
//   5. The recovered runtime continues dispatching from where the
//      old one left off; final state of every node matches a
//      no-crash baseline.
//
// We deliberately test against the no-crash baseline rather than a
// hand-written expected map, because a manual expected map drifts as
// the FSM evolves; the baseline is what we actually care about.

import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { Graph } from '../../packages/dag/src/index.ts';
import { propagate, type DeadlinedNode } from '../../packages/deadline/src/index.ts';
import {
  initialState,
  transition,
  type Event,
  type RunState,
} from '../../packages/runstate/src/index.ts';
import { QueueLimits, decide, type SchedulableNode } from '../../packages/scheduler/src/index.ts';
import { replayAll, type LogEntry } from '../../packages/replay/src/index.ts';
import { MemoryStore } from '../../packages/store/src/index.ts';
import { recover } from '../../apps/runner/src/recovery.ts';

type Node = SchedulableNode & DeadlinedNode;

const t = (n: number) => BigInt(n);

const node = (queue = 'default'): Node => ({
  queue,
  priority: 0,
  declaredDeadline: Infinity,
});

interface Sim {
  graph: Graph<Node>;
  states: Map<string, RunState>;
  limits: QueueLimits;
  log: LogEntry[];
  lsn: number;
  now: number;
}

function buildSim(): Sim {
  const graph = new Graph<Node>();
  graph.addNode('extract', node());
  graph.addNode('clean', node());
  graph.addNode('enrich', node());
  graph.addNode('reduce', node());
  graph.addNode('serialize', node());
  graph.addNode('publish', node());
  graph.addEdge('extract', 'clean').addEdge('clean', 'enrich').addEdge('enrich', 'reduce');
  graph.addEdge('reduce', 'serialize').addEdge('serialize', 'publish');
  const states = new Map<string, RunState>();
  for (const id of graph.allNodes()) states.set(id, initialState(t(0)));
  const log: LogEntry[] = [];
  let lsn = 1;
  for (const id of graph.allNodes()) {
    log.push({ lsn: lsn++, runId: id, kind: 'created', at: t(0) });
  }
  return { graph, states, limits: new QueueLimits(), log, lsn, now: 1000 };
}

function runOneTick(sim: Sim, freeWorkers = 4): void {
  const propagated = propagate(sim.graph);
  const decision = decide(sim.graph, sim.states, sim.limits, {
    now: sim.now,
    freeWorkers,
    effectiveDeadline: propagated.effective,
  });
  for (const id of decision.dispatch) {
    let s = sim.states.get(id)!;
    const dispatchEvent: Event = {
      kind: 'dispatch',
      at: t(sim.now),
      workerId: 'w-1',
      leaseExpiresAt: t(sim.now + 60_000),
    };
    s = transition(s, dispatchEvent);
    sim.log.push({ lsn: sim.lsn++, runId: id, event: dispatchEvent });
    // Resolve immediately for determinism.
    const succeedEvent: Event = { kind: 'succeed', at: t(sim.now + 100), result: { id } };
    s = transition(s, succeedEvent);
    sim.log.push({ lsn: sim.lsn++, runId: id, event: succeedEvent });
    sim.states.set(id, s);
    sim.limits.release(sim.graph.get(id).queue);
  }
  sim.now += 200;
}

describe('integration: full recovery cycle', () => {
  it('recover() rebuilds in-memory state matching the live runner before crash', async () => {
    const sim = buildSim();
    runOneTick(sim);
    runOneTick(sim);
    runOneTick(sim);

    // Snapshot live state.
    const liveStates = new Map<string, string>();
    for (const [id, s] of sim.states) liveStates.set(id, s.kind);

    // "Crash and recover": persist log into a MemoryStore, recover.
    const store = new MemoryStore();
    store.appendLog(sim.log);
    const report = await recover(store, { now: sim.now });

    // Recovered state must match live state.
    for (const [id, kind] of liveStates) {
      assert.equal(report.states.get(id)?.kind, kind, `${id} diverged`);
    }
    assert.equal(report.skippedEntries, 0);
  });

  it('continuing from recovered state produces the same final outcome as a no-crash run', async () => {
    // Baseline: run a fresh sim to completion without crashing.
    const baseline = buildSim();
    while (Array.from(baseline.states.values()).some(
      (s) => s.kind === 'queued' || s.kind === 'running' || s.kind === 'retry_scheduled',
    )) {
      runOneTick(baseline);
      if (baseline.now > 100_000) break; // safety bound
    }

    // Crash: same sim, halt midway.
    const crashed = buildSim();
    runOneTick(crashed);
    runOneTick(crashed);

    // Recover from the partial log.
    const store = new MemoryStore();
    store.appendLog(crashed.log);
    const report = await recover(store, { now: crashed.now });

    // Re-attach recovered state into a fresh sim and continue.
    const resumed: Sim = {
      graph: crashed.graph,
      states: report.states,
      limits: new QueueLimits(),
      log: [...crashed.log],
      lsn: crashed.lsn,
      now: crashed.now,
    };
    while (Array.from(resumed.states.values()).some(
      (s) => s.kind === 'queued' || s.kind === 'running' || s.kind === 'retry_scheduled',
    )) {
      runOneTick(resumed);
      if (resumed.now > 100_000) break;
    }

    // Compare final states.
    for (const id of baseline.graph.allNodes()) {
      assert.equal(
        resumed.states.get(id)?.kind,
        baseline.states.get(id)?.kind,
        `${id}: resumed=${resumed.states.get(id)?.kind}, baseline=${baseline.states.get(id)?.kind}`,
      );
    }
  });

  it('multi-crash chain: recover, run a tick, crash again, recover again', async () => {
    const sim = buildSim();
    runOneTick(sim);

    // First crash.
    let store = new MemoryStore();
    store.appendLog(sim.log);
    let report = await recover(store, { now: sim.now });
    assert.equal(report.skippedEntries, 0);

    // Continue with a fresh sim view from the recovery.
    const sim2: Sim = {
      graph: sim.graph,
      states: report.states,
      limits: new QueueLimits(),
      log: [...sim.log],
      lsn: sim.lsn,
      now: sim.now,
    };
    runOneTick(sim2);
    runOneTick(sim2);

    // Second crash.
    store = new MemoryStore();
    store.appendLog(sim2.log);
    report = await recover(store, { now: sim2.now });
    assert.equal(report.skippedEntries, 0);

    // Recovered state must contain a "running"-or-later entry for the
    // earliest nodes.
    assert.equal(report.states.get('extract')?.kind, 'succeeded');
    assert.equal(report.states.get('clean')?.kind, 'succeeded');
  });

  it('recovery is deterministic across replay equivalence (no temporal drift)', async () => {
    const sim = buildSim();
    runOneTick(sim);
    runOneTick(sim);

    const store = new MemoryStore();
    store.appendLog(sim.log);

    const a = await recover(store, { now: sim.now });
    const b = await recover(store, { now: sim.now });
    for (const id of sim.graph.allNodes()) {
      assert.equal(a.states.get(id)?.kind, b.states.get(id)?.kind);
    }
  });

  it('replay ignores duplicate creation entries gracefully', async () => {
    const sim = buildSim();
    runOneTick(sim);
    // Inject a duplicate creation for the first node.
    const dup: LogEntry = { lsn: 9999, runId: 'extract', kind: 'created', at: t(0) };
    const corrupted = [...sim.log, dup];
    const r = replayAll(corrupted);
    assert.ok(r.skipped >= 1);
  });
});
