// End-to-end success scenario.
//
// Submits a 5-node DAG, walks it through dispatch + success transitions,
// and verifies the final state matches what we'd expect from a real
// workflow that ran without errors.
//
// We do NOT spin up the runner daemon here; that would require sockets
// and an event loop. Instead we wire the same packages together by
// hand. This is the canonical "integration but not e2e" test shape:
// real component composition, no I/O.

import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { Graph } from '../../packages/dag/src/index.ts';
import {
  type RunState,
  initialState,
  transition,
} from '../../packages/runstate/src/index.ts';
import { QueueLimits, decide, type SchedulableNode } from '../../packages/scheduler/src/index.ts';
import { propagate, type DeadlinedNode } from '../../packages/deadline/src/index.ts';

type Node = SchedulableNode & DeadlinedNode;

const t = (n: number) => BigInt(n);

const node = (queue = 'default', priority = 0, deadline = Infinity): Node => ({
  queue,
  priority,
  declaredDeadline: deadline,
});

describe('integration: end-to-end 5-node DAG success', () => {
  it('walks a chain through queued -> running -> succeeded for every node', async () => {
    const g = new Graph<Node>();
    g.addNode('extract', node());
    g.addNode('transform', node());
    g.addNode('validate', node());
    g.addNode('load', node());
    g.addNode('notify', node());
    g.addEdge('extract', 'transform');
    g.addEdge('transform', 'validate');
    g.addEdge('validate', 'load');
    g.addEdge('load', 'notify');

    const states = new Map<string, RunState>();
    for (const id of g.allNodes()) states.set(id, initialState(t(0)));

    const limits = new QueueLimits();
    const propagated = propagate(g);

    let now = 1000;
    let dispatched = 0;
    let succeeded = 0;

    // Tick until everything is terminal. We give it a generous bound so
    // a regression that breaks dispatch surfaces as a test failure
    // rather than a hang.
    for (let tick = 0; tick < 50; tick += 1) {
      const decision = decide(g, states, limits, {
        now,
        freeWorkers: 4,
        effectiveDeadline: propagated.effective,
      });
      if (decision.dispatch.length === 0) {
        // Anything still active? If not, we're done.
        const anyActive = Array.from(states.values()).some(
          (s) => s.kind === 'queued' || s.kind === 'running' || s.kind === 'retry_scheduled',
        );
        if (!anyActive) break;
        // Advance time to make any retry_scheduled eligible. None here.
        now += 1000;
        continue;
      }
      for (const id of decision.dispatch) {
        const s = states.get(id)!;
        const dispatched_state = transition(s, {
          kind: 'dispatch',
          at: t(now),
          workerId: 'w1',
          leaseExpiresAt: t(now + 30_000),
        });
        states.set(id, dispatched_state);
        dispatched += 1;
        // Immediately succeed.
        const ok = transition(dispatched_state, {
          kind: 'succeed',
          at: t(now + 100),
          result: { node: id },
        });
        states.set(id, ok);
        limits.release(g.get(id).queue);
        succeeded += 1;
      }
      now += 200;
    }

    assert.equal(dispatched, 5);
    assert.equal(succeeded, 5);
    for (const id of g.allNodes()) {
      assert.equal(states.get(id)?.kind, 'succeeded');
    }
  });

  it('respects topological order: a child never runs before its parent succeeds', async () => {
    const g = new Graph<Node>();
    g.addNode('a', node());
    g.addNode('b', node());
    g.addNode('c', node());
    g.addEdge('a', 'b').addEdge('b', 'c');

    const states = new Map<string, RunState>();
    for (const id of g.allNodes()) states.set(id, initialState(t(0)));
    const limits = new QueueLimits();
    const propagated = propagate(g);

    const dispatchOrder: string[] = [];
    let now = 1000;

    for (let tick = 0; tick < 20; tick += 1) {
      const decision = decide(g, states, limits, {
        now,
        freeWorkers: 4,
        effectiveDeadline: propagated.effective,
      });
      if (decision.dispatch.length === 0) {
        const active = Array.from(states.values()).some(
          (s) => s.kind === 'queued' || s.kind === 'running',
        );
        if (!active) break;
      }
      for (const id of decision.dispatch) {
        dispatchOrder.push(id);
        const s = states.get(id)!;
        const r = transition(
          transition(s, {
            kind: 'dispatch',
            at: t(now),
            workerId: 'w',
            leaseExpiresAt: t(now + 30_000),
          }),
          { kind: 'succeed', at: t(now + 50), result: null },
        );
        states.set(id, r);
        limits.release(g.get(id).queue);
      }
      now += 200;
    }

    assert.deepEqual(dispatchOrder, ['a', 'b', 'c']);
  });

  it('parallelizes a fan-out within free-worker bounds', async () => {
    const g = new Graph<Node>();
    g.addNode('root', node());
    for (let i = 0; i < 4; i += 1) {
      g.addNode(`leaf${i}`, node());
      g.addEdge('root', `leaf${i}`);
    }
    const states = new Map<string, RunState>();
    for (const id of g.allNodes()) states.set(id, initialState(t(0)));
    const limits = new QueueLimits();
    const propagated = propagate(g);

    // Tick 1: only root is eligible.
    let dec = decide(g, states, limits, {
      now: 1000,
      freeWorkers: 8,
      effectiveDeadline: propagated.effective,
    });
    assert.deepEqual(dec.dispatch, ['root']);

    // Run root to success.
    let s = transition(states.get('root')!, {
      kind: 'dispatch',
      at: t(1000),
      workerId: 'w',
      leaseExpiresAt: t(31_000),
    });
    s = transition(s, { kind: 'succeed', at: t(1100), result: null });
    states.set('root', s);
    limits.release('default');

    // Tick 2: all 4 leaves eligible. With free=8 they all dispatch.
    dec = decide(g, states, limits, {
      now: 1200,
      freeWorkers: 8,
      effectiveDeadline: propagated.effective,
    });
    assert.equal(dec.dispatch.length, 4);
  });
});
