// Idempotency end-to-end flow.
//
// Verifies the join semantics: two submissions with the same
// (handler, key) coexist correctly across the inflight/result
// transitions.

import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { Registry } from '../../packages/idempotency/src/index.ts';

class FakeClock {
  constructor(public t = 0) {}
  now = () => this.t;
  advance(ms: number) {
    this.t += ms;
  }
}

describe('integration: idempotency flow', () => {
  it('first submitter runs; second submitter joins', () => {
    const c = new FakeClock(0);
    const r = new Registry({ clock: c.now });
    const a = r.acquire('email', 'order-37', 'run-A');
    assert.equal(a.kind, 'fresh');
    const b = r.acquire('email', 'order-37', 'run-B');
    assert.equal(b.kind, 'join');
    if (b.kind === 'join') {
      assert.equal(b.ownerRunId, 'run-A');
    }
  });

  it('after completion, third submitter gets the cached result', () => {
    const c = new FakeClock(0);
    const r = new Registry({ clock: c.now });
    r.acquire('email', 'order-37', 'run-A');
    r.complete('email', 'order-37', { messageId: 'msg-1' });
    const c1 = r.acquire('email', 'order-37', 'run-C');
    assert.equal(c1.kind, 'result');
    if (c1.kind === 'result' && c1.status.kind === 'completed') {
      assert.deepEqual(c1.status.result, { messageId: 'msg-1' });
    }
  });

  it('after TTL expires, the same key is fresh again', () => {
    const c = new FakeClock(0);
    const r = new Registry({ clock: c.now, defaultTtlMs: 1000 });
    r.acquire('email', 'order-37', 'run-A');
    r.complete('email', 'order-37', { messageId: 'msg-1' });
    c.advance(2000);
    const fresh = r.acquire('email', 'order-37', 'run-D');
    assert.equal(fresh.kind, 'fresh');
  });

  it('failed jobs are also cached and short-circuit subsequent submissions', () => {
    const c = new FakeClock(0);
    const r = new Registry({ clock: c.now });
    r.acquire('email', 'order-37', 'run-A');
    r.fail('email', 'order-37', { message: 'smtp 550', kind: 'permanent' });
    const c2 = r.acquire('email', 'order-37', 'run-B');
    assert.equal(c2.kind, 'result');
    if (c2.kind === 'result' && c2.status.kind === 'failed') {
      assert.equal(c2.status.failureKind, 'permanent');
    }
  });

  it('abandoning an inflight allows a fresh re-attempt', () => {
    const c = new FakeClock(0);
    const r = new Registry({ clock: c.now });
    r.acquire('email', 'order-37', 'run-A');
    r.abandon('email', 'order-37');
    const fresh = r.acquire('email', 'order-37', 'run-B');
    assert.equal(fresh.kind, 'fresh');
  });

  it('three concurrent submissions: one fresh, two join', () => {
    const c = new FakeClock(0);
    const r = new Registry({ clock: c.now });
    const a = r.acquire('h', 'k', 'run-A');
    const b = r.acquire('h', 'k', 'run-B');
    const cc = r.acquire('h', 'k', 'run-C');
    assert.equal(a.kind, 'fresh');
    assert.equal(b.kind, 'join');
    assert.equal(cc.kind, 'join');
    if (b.kind === 'join') assert.equal(b.ownerRunId, 'run-A');
    if (cc.kind === 'join') assert.equal(cc.ownerRunId, 'run-A');
  });

  it('different handlers do not collide on the same key', () => {
    const c = new FakeClock(0);
    const r = new Registry({ clock: c.now });
    const a = r.acquire('email', 'k', 'run-A');
    const b = r.acquire('audit', 'k', 'run-B');
    assert.equal(a.kind, 'fresh');
    assert.equal(b.kind, 'fresh');
  });
});
