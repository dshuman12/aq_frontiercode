import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { Graph } from '../src/graph.ts';
import { validate } from '../src/validate.ts';

describe('validate', () => {
  it('accepts a chain', () => {
    const g = new Graph<null>();
    g.addNode('a', null).addNode('b', null).addEdge('a', 'b');
    const r = validate(g);
    assert.equal(r.ok, true);
    assert.equal(r.issues.length, 0);
  });

  it('rejects an empty graph by default', () => {
    const r = validate(new Graph<null>());
    assert.equal(r.ok, false);
    assert.equal(r.issues[0]!.kind, 'no_roots');
  });

  it('accepts an empty graph with allowEmpty: true', () => {
    const r = validate(new Graph<null>(), { allowEmpty: true });
    assert.equal(r.ok, true);
  });

  it('reports a single cycle', () => {
    const g = new Graph<null>();
    g.addNode('a', null).addNode('b', null).addEdge('a', 'b').addEdge('b', 'a');
    const r = validate(g);
    assert.equal(r.ok, false);
    const cycle = r.issues.find((i) => i.kind === 'cycle');
    assert.ok(cycle);
    assert.match(cycle!.message, /cycle:/);
  });

  it('reports multiple cycles separately', () => {
    const g = new Graph<null>();
    g.addNode('a', null).addNode('b', null).addNode('x', null).addNode('y', null);
    g.addEdge('a', 'b').addEdge('b', 'a');
    g.addEdge('x', 'y').addEdge('y', 'x');
    const r = validate(g);
    const cycles = r.issues.filter((i) => i.kind === 'cycle');
    assert.equal(cycles.length, 2);
  });

  it('reports no_roots when there are no roots and no cycles', () => {
    // This is constructively impossible without a cycle, but we test the
    // branch by constructing a 2-cycle (which yields cycle issue + no
    // roots, but the no_roots branch only fires when cycles is empty).
    // Instead exercise this with a graph that has a cycle THAT IS ALSO
    // the only thing in the graph -- the cycle reporter fires, but we
    // also see "no roots".
    const g = new Graph<null>();
    g.addNode('a', null).addNode('b', null).addEdge('a', 'b').addEdge('b', 'a');
    const r = validate(g);
    assert.equal(r.ok, false);
    const noRoots = r.issues.find((i) => i.kind === 'no_roots');
    assert.ok(noRoots);
  });

  it('the message of a cycle issue lists the nodes', () => {
    const g = new Graph<null>();
    g.addNode('a', null).addNode('b', null).addNode('c', null);
    g.addEdge('a', 'b').addEdge('b', 'c').addEdge('c', 'a');
    const r = validate(g);
    const cycle = r.issues.find((i) => i.kind === 'cycle')!;
    // All three node names appear, in some order.
    assert.match(cycle.message, /a/);
    assert.match(cycle.message, /b/);
    assert.match(cycle.message, /c/);
  });

  it('reports width_exceeded when fan-out exceeds the cap', () => {
    const g = new Graph<null>();
    g.addNode('root', null);
    for (let i = 0; i < 12; i += 1) {
      g.addNode(`leaf${i}`, null);
      g.addEdge('root', `leaf${i}`);
    }
    const r = validate(g, { maxWidth: 10 });
    const w = r.issues.find((i) => i.kind === 'width_exceeded');
    assert.ok(w);
  });

  it('does NOT report width_exceeded when fan-out is within cap', () => {
    const g = new Graph<null>();
    g.addNode('root', null);
    for (let i = 0; i < 5; i += 1) {
      g.addNode(`leaf${i}`, null);
      g.addEdge('root', `leaf${i}`);
    }
    const r = validate(g, { maxWidth: 10 });
    assert.equal(r.ok, true);
  });

  it('issue.nodes for a cycle is the cycle members', () => {
    const g = new Graph<null>();
    g.addNode('a', null).addNode('b', null).addNode('c', null);
    g.addEdge('a', 'b').addEdge('b', 'c').addEdge('c', 'a');
    const r = validate(g);
    const cycle = r.issues.find((i) => i.kind === 'cycle')!;
    assert.deepEqual([...cycle.nodes].sort(), ['a', 'b', 'c']);
  });

  it('a clean diamond passes', () => {
    const g = new Graph<null>();
    g.addNode('a', null).addNode('b', null).addNode('c', null).addNode('d', null);
    g.addEdge('a', 'b').addEdge('a', 'c').addEdge('b', 'd').addEdge('c', 'd');
    const r = validate(g);
    assert.equal(r.ok, true);
  });
});
