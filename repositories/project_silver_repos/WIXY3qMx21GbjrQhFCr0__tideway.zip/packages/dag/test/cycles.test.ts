import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { Graph } from '../src/graph.ts';
import { cycles, isAcyclic } from '../src/cycles.ts';

describe('cycles', () => {
  it('reports nothing on a chain', () => {
    const g = new Graph<null>();
    g.addNode('a', null).addNode('b', null).addNode('c', null);
    g.addEdge('a', 'b').addEdge('b', 'c');
    assert.deepEqual(cycles(g), []);
  });

  it('reports nothing on a diamond', () => {
    const g = new Graph<null>();
    g.addNode('a', null).addNode('b', null).addNode('c', null).addNode('d', null);
    g.addEdge('a', 'b').addEdge('a', 'c').addEdge('b', 'd').addEdge('c', 'd');
    assert.deepEqual(cycles(g), []);
  });

  it('finds a 2-cycle', () => {
    const g = new Graph<null>();
    g.addNode('a', null).addNode('b', null);
    g.addEdge('a', 'b').addEdge('b', 'a');
    const c = cycles(g);
    assert.equal(c.length, 1);
    assert.deepEqual([...c[0]!].sort(), ['a', 'b']);
  });

  it('finds a 3-cycle', () => {
    const g = new Graph<null>();
    g.addNode('a', null).addNode('b', null).addNode('c', null);
    g.addEdge('a', 'b').addEdge('b', 'c').addEdge('c', 'a');
    const c = cycles(g);
    assert.equal(c.length, 1);
    assert.deepEqual([...c[0]!].sort(), ['a', 'b', 'c']);
  });

  it('finds two independent cycles', () => {
    // a-b-a, x-y-x
    const g = new Graph<null>();
    g.addNode('a', null).addNode('b', null).addNode('x', null).addNode('y', null);
    g.addEdge('a', 'b').addEdge('b', 'a');
    g.addEdge('x', 'y').addEdge('y', 'x');
    const c = cycles(g);
    assert.equal(c.length, 2);
    const sorted = c.map((cyc) => [...cyc].sort()).sort();
    assert.deepEqual(sorted, [['a', 'b'], ['x', 'y']]);
  });

  it('ignores nodes outside the SCC', () => {
    // pre -> a -> b -> a
    const g = new Graph<null>();
    g.addNode('pre', null).addNode('a', null).addNode('b', null);
    g.addEdge('pre', 'a').addEdge('a', 'b').addEdge('b', 'a');
    const c = cycles(g);
    assert.equal(c.length, 1);
    assert.deepEqual([...c[0]!].sort(), ['a', 'b']);
  });

  it('handles a deep chain without stack overflow', () => {
    // 5000 deep chain, no cycle. The point is the iterative Tarjan.
    const g = new Graph<null>();
    for (let i = 0; i < 5000; i += 1) {
      g.addNode(`n${i}`, null);
      if (i > 0) g.addEdge(`n${i - 1}`, `n${i}`);
    }
    assert.deepEqual(cycles(g), []);
  });

  it('finds an SCC larger than 3', () => {
    // a -> b -> c -> d -> a
    const g = new Graph<null>();
    g.addNode('a', null).addNode('b', null).addNode('c', null).addNode('d', null);
    g.addEdge('a', 'b').addEdge('b', 'c').addEdge('c', 'd').addEdge('d', 'a');
    const c = cycles(g);
    assert.equal(c.length, 1);
    assert.equal(c[0]!.length, 4);
  });
});

describe('isAcyclic', () => {
  it('is true for a chain', () => {
    const g = new Graph<null>();
    g.addNode('a', null).addNode('b', null).addEdge('a', 'b');
    assert.equal(isAcyclic(g), true);
  });

  it('is false for a 2-cycle', () => {
    const g = new Graph<null>();
    g.addNode('a', null).addNode('b', null).addEdge('a', 'b').addEdge('b', 'a');
    assert.equal(isAcyclic(g), false);
  });

  it('is true for an empty graph', () => {
    assert.equal(isAcyclic(new Graph<null>()), true);
  });
});
