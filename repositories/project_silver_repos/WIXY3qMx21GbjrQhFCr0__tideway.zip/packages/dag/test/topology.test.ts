import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { Graph, GraphError } from '../src/graph.ts';
import { topologicalOrder, topologicalSort } from '../src/topology.ts';

describe('topologicalOrder on simple shapes', () => {
  it('orders a chain a -> b -> c', () => {
    const g = new Graph<null>();
    g.addNode('a', null).addNode('b', null).addNode('c', null);
    g.addEdge('a', 'b').addEdge('b', 'c');
    const r = topologicalOrder(g);
    assert.equal(r.acyclic, true);
    assert.deepEqual(r.order, ['a', 'b', 'c']);
  });

  it('orders a diamond with parents-before-child', () => {
    // a -> b -> d
    //  \-> c -/
    const g = new Graph<null>();
    g.addNode('a', null).addNode('b', null).addNode('c', null).addNode('d', null);
    g.addEdge('a', 'b').addEdge('a', 'c').addEdge('b', 'd').addEdge('c', 'd');
    const r = topologicalOrder(g);
    assert.deepEqual(r.order, ['a', 'b', 'c', 'd']);
  });

  it('orders fan-out by insertion order on ties', () => {
    const g = new Graph<null>();
    g.addNode('root', null);
    g.addNode('z', null);
    g.addNode('a', null);
    g.addNode('m', null);
    g.addEdge('root', 'z').addEdge('root', 'a').addEdge('root', 'm');
    const r = topologicalOrder(g);
    assert.deepEqual(r.order, ['root', 'z', 'a', 'm']);
  });

  it('handles disconnected components', () => {
    const g = new Graph<null>();
    g.addNode('a', null).addNode('b', null);
    g.addNode('x', null).addNode('y', null);
    g.addEdge('a', 'b').addEdge('x', 'y');
    const r = topologicalOrder(g);
    // Insertion order: a=0, b=1, x=2, y=3. Roots are a and x. After
    // popping a, b becomes available with a lower insertion index than
    // x's already-queued slot, so b is dequeued before x. End order:
    // a, b, x, y.
    assert.deepEqual(r.order, ['a', 'b', 'x', 'y']);
  });
});

describe('topologicalOrder on cyclic graphs', () => {
  it('reports !acyclic on a 2-cycle', () => {
    const g = new Graph<null>();
    g.addNode('a', null).addNode('b', null);
    g.addEdge('a', 'b').addEdge('b', 'a');
    const r = topologicalOrder(g);
    assert.equal(r.acyclic, false);
    assert.equal(r.order.length, 0);
    assert.deepEqual(r.remaining.sort(), ['a', 'b']);
  });

  it('reports prefix that could be ordered before getting stuck', () => {
    // pre -> a -> b -> a (cycle)
    const g = new Graph<null>();
    g.addNode('pre', null).addNode('a', null).addNode('b', null);
    g.addEdge('pre', 'a').addEdge('a', 'b').addEdge('b', 'a');
    const r = topologicalOrder(g);
    assert.equal(r.acyclic, false);
    assert.deepEqual(r.order, ['pre']);
    assert.deepEqual(r.remaining.sort(), ['a', 'b']);
  });
});

describe('topologicalSort', () => {
  it('returns the order on an acyclic graph', () => {
    const g = new Graph<null>();
    g.addNode('a', null).addNode('b', null).addEdge('a', 'b');
    assert.deepEqual(topologicalSort(g), ['a', 'b']);
  });

  it('throws on a cyclic graph', () => {
    const g = new Graph<null>();
    g.addNode('a', null).addNode('b', null).addEdge('a', 'b').addEdge('b', 'a');
    assert.throws(() => topologicalSort(g), GraphError);
  });
});

describe('topologicalOrder is deterministic', () => {
  it('produces the same order across two builds with the same insertion sequence', () => {
    const build = () => {
      const g = new Graph<null>();
      ['p', 'q', 'r', 's', 't'].forEach((id) => g.addNode(id, null));
      g.addEdge('p', 'r').addEdge('q', 'r').addEdge('r', 's').addEdge('r', 't');
      return g;
    };
    assert.deepEqual(topologicalOrder(build()).order, topologicalOrder(build()).order);
  });
});
