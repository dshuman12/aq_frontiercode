import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { Graph } from '../src/graph.ts';
import { slice, descendantSubgraph, ancestorSubgraph } from '../src/slice.ts';

const buildTree = () => {
  // a -> b -> d
  //  \-> c -> e
  //       \-> f
  const g = new Graph<{ tag: string }>();
  g.addNode('a', { tag: 'root' });
  g.addNode('b', { tag: 'mid' });
  g.addNode('c', { tag: 'mid' });
  g.addNode('d', { tag: 'leaf' });
  g.addNode('e', { tag: 'leaf' });
  g.addNode('f', { tag: 'leaf' });
  g.addEdge('a', 'b').addEdge('a', 'c');
  g.addEdge('b', 'd');
  g.addEdge('c', 'e').addEdge('c', 'f');
  return g;
};

describe('slice', () => {
  it('keeps only nodes the predicate accepts', () => {
    const g = buildTree();
    const s = slice(g, (_, v) => v.tag !== 'leaf');
    assert.deepEqual(s.allNodes().sort(), ['a', 'b', 'c']);
  });

  it('drops edges that cross the predicate boundary', () => {
    const g = buildTree();
    const s = slice(g, (_, v) => v.tag !== 'leaf');
    // a -> b and a -> c remain. b -> d, c -> e, c -> f all dropped.
    assert.equal(s.edgeCount(), 2);
    assert.equal(s.hasEdge('a', 'b'), true);
    assert.equal(s.hasEdge('a', 'c'), true);
  });

  it('does not synthesize transitive edges through dropped nodes', () => {
    const g = new Graph<string>();
    g.addNode('a', 'keep').addNode('b', 'drop').addNode('c', 'keep');
    g.addEdge('a', 'b').addEdge('b', 'c');
    const s = slice(g, (_, v) => v === 'keep');
    assert.deepEqual(s.allNodes().sort(), ['a', 'c']);
    assert.equal(s.hasEdge('a', 'c'), false);
  });

  it('slices an empty graph to an empty graph', () => {
    const s = slice(new Graph<number>(), () => true);
    assert.equal(s.size(), 0);
  });

  it('predicate-receives-id-and-value', () => {
    const g = buildTree();
    let sawA = false;
    slice(g, (id, v) => {
      if (id === 'a') {
        sawA = true;
        assert.equal(v.tag, 'root');
      }
      return true;
    });
    assert.equal(sawA, true);
  });
});

describe('descendantSubgraph', () => {
  it('returns the seed plus everything downstream', () => {
    const g = buildTree();
    const s = descendantSubgraph(g, ['c']);
    assert.deepEqual(s.allNodes().sort(), ['c', 'e', 'f']);
    assert.equal(s.hasEdge('c', 'e'), true);
    assert.equal(s.hasEdge('c', 'f'), true);
  });

  it('with multiple seeds, unions them', () => {
    const g = buildTree();
    const s = descendantSubgraph(g, ['b', 'c']);
    assert.deepEqual(s.allNodes().sort(), ['b', 'c', 'd', 'e', 'f']);
  });

  it('with a leaf seed, returns just the leaf', () => {
    const g = buildTree();
    const s = descendantSubgraph(g, ['d']);
    assert.deepEqual(s.allNodes(), ['d']);
    assert.equal(s.edgeCount(), 0);
  });
});

describe('ancestorSubgraph', () => {
  it('returns the seed plus everything upstream', () => {
    const g = buildTree();
    const s = ancestorSubgraph(g, ['e']);
    assert.deepEqual(s.allNodes().sort(), ['a', 'c', 'e']);
    assert.equal(s.hasEdge('a', 'c'), true);
    assert.equal(s.hasEdge('c', 'e'), true);
  });

  it('with a root seed, returns just the root', () => {
    const g = buildTree();
    const s = ancestorSubgraph(g, ['a']);
    assert.deepEqual(s.allNodes(), ['a']);
  });
});
