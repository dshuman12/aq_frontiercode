import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { Graph, GraphError } from '../src/graph.ts';

describe('Graph constructors', () => {
  it('starts empty', () => {
    const g = Graph.empty<string>();
    assert.equal(g.size(), 0);
    assert.equal(g.edgeCount(), 0);
  });

  it('addNode bumps size', () => {
    const g = new Graph<number>();
    g.addNode('a', 1).addNode('b', 2);
    assert.equal(g.size(), 2);
  });

  it('addNode rejects duplicates', () => {
    const g = new Graph<number>();
    g.addNode('a', 1);
    assert.throws(() => g.addNode('a', 2), GraphError);
  });

  it('addNode rejects empty id', () => {
    const g = new Graph<number>();
    assert.throws(() => g.addNode('', 1), GraphError);
  });
});

describe('Graph.addEdge', () => {
  it('adds an edge between known nodes', () => {
    const g = new Graph<number>();
    g.addNode('a', 1).addNode('b', 2).addEdge('a', 'b');
    assert.equal(g.hasEdge('a', 'b'), true);
    assert.equal(g.edgeCount(), 1);
  });

  it('throws on unknown source', () => {
    const g = new Graph<number>();
    g.addNode('a', 1);
    assert.throws(() => g.addEdge('zzz', 'a'), GraphError);
  });

  it('throws on unknown target', () => {
    const g = new Graph<number>();
    g.addNode('a', 1);
    assert.throws(() => g.addEdge('a', 'zzz'), GraphError);
  });

  it('refuses self-loop', () => {
    const g = new Graph<number>();
    g.addNode('a', 1);
    assert.throws(() => g.addEdge('a', 'a'), GraphError);
  });

  it('is idempotent on duplicate edges', () => {
    const g = new Graph<number>();
    g.addNode('a', 1).addNode('b', 2);
    g.addEdge('a', 'b');
    g.addEdge('a', 'b');
    assert.equal(g.edgeCount(), 1);
  });

  it('updates parents and children both', () => {
    const g = new Graph<number>();
    g.addNode('a', 1).addNode('b', 2).addEdge('a', 'b');
    assert.deepEqual(g.childrenOf('a'), ['b']);
    assert.deepEqual(g.parentsOf('b'), ['a']);
    assert.deepEqual(g.parentsOf('a'), []);
    assert.deepEqual(g.childrenOf('b'), []);
  });
});

describe('Graph.get / has / updateValue', () => {
  it('get returns the stored value', () => {
    const g = new Graph<{ tag: string }>();
    g.addNode('a', { tag: 'first' });
    assert.deepEqual(g.get('a'), { tag: 'first' });
  });

  it('get throws on unknown', () => {
    const g = new Graph<number>();
    assert.throws(() => g.get('nope'), GraphError);
  });

  it('updateValue replaces the value', () => {
    const g = new Graph<number>();
    g.addNode('a', 1);
    g.updateValue('a', 99);
    assert.equal(g.get('a'), 99);
  });

  it('updateValue throws on unknown', () => {
    const g = new Graph<number>();
    assert.throws(() => g.updateValue('a', 1));
  });

  it('has reports membership', () => {
    const g = new Graph<number>();
    g.addNode('a', 1);
    assert.equal(g.has('a'), true);
    assert.equal(g.has('b'), false);
  });
});

describe('roots / leaves / allNodes', () => {
  it('finds roots in a fork', () => {
    const g = new Graph<null>();
    g.addNode('a', null).addNode('b', null).addNode('c', null);
    g.addEdge('a', 'c').addEdge('b', 'c');
    assert.deepEqual(g.roots(), ['a', 'b']);
    assert.deepEqual(g.leaves(), ['c']);
  });

  it('returns all roots when graph is fully disconnected', () => {
    const g = new Graph<null>();
    g.addNode('a', null).addNode('b', null).addNode('c', null);
    assert.deepEqual(g.roots(), ['a', 'b', 'c']);
    assert.deepEqual(g.leaves(), ['a', 'b', 'c']);
  });

  it('allNodes preserves insertion order', () => {
    const g = new Graph<number>();
    g.addNode('z', 1).addNode('a', 2).addNode('m', 3);
    assert.deepEqual(g.allNodes(), ['z', 'a', 'm']);
  });
});

describe('descendants / ancestors', () => {
  // a -> b -> c
  //      \-> d
  const build = () => {
    const g = new Graph<null>();
    g.addNode('a', null).addNode('b', null).addNode('c', null).addNode('d', null);
    g.addEdge('a', 'b').addEdge('b', 'c').addEdge('b', 'd');
    return g;
  };

  it('descendants from root covers everything', () => {
    const g = build();
    const d = g.descendants(['a']);
    assert.deepEqual([...d].sort(), ['a', 'b', 'c', 'd']);
  });

  it('descendants from middle covers self + downstream only', () => {
    const g = build();
    const d = g.descendants(['b']);
    assert.deepEqual([...d].sort(), ['b', 'c', 'd']);
  });

  it('descendants from leaf is just the leaf', () => {
    const g = build();
    assert.deepEqual([...g.descendants(['c'])], ['c']);
  });

  it('ancestors from leaf walks back to root', () => {
    const g = build();
    const a = g.ancestors(['c']);
    assert.deepEqual([...a].sort(), ['a', 'b', 'c']);
  });

  it('descendants throws on unknown seed', () => {
    const g = build();
    assert.throws(() => g.descendants(['ghost']), GraphError);
  });

  it('descendants from multiple seeds unions them', () => {
    const g = build();
    const d = g.descendants(['c', 'd']);
    assert.deepEqual([...d].sort(), ['c', 'd']);
  });

  it('descendants is empty for empty seeds', () => {
    const g = build();
    assert.deepEqual([...g.descendants([])], []);
  });
});

describe('childrenOf / parentsOf ordering', () => {
  it('orders by insertion order, not lexicographic', () => {
    const g = new Graph<null>();
    g.addNode('parent', null);
    g.addNode('z_child', null);
    g.addNode('a_child', null);
    g.addNode('m_child', null);
    g.addEdge('parent', 'a_child');
    g.addEdge('parent', 'm_child');
    g.addEdge('parent', 'z_child');
    // insertion order of the children themselves was z, a, m, so that's
    // the order we get back.
    assert.deepEqual(g.childrenOf('parent'), ['z_child', 'a_child', 'm_child']);
  });
});
