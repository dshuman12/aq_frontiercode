import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { Graph, GraphError } from '../src/graph.ts';
import { parallelizable, layerOf } from '../src/layers.ts';

describe('parallelizable', () => {
  it('a chain has depth=N, width=1', () => {
    const g = new Graph<null>();
    g.addNode('a', null).addNode('b', null).addNode('c', null);
    g.addEdge('a', 'b').addEdge('b', 'c');
    const r = parallelizable(g);
    assert.deepEqual(r.layers, [['a'], ['b'], ['c']]);
    assert.equal(r.depth, 3);
    assert.equal(r.width, 1);
  });

  it('a fan-out is depth=2, width=N', () => {
    const g = new Graph<null>();
    g.addNode('root', null);
    for (let i = 0; i < 5; i += 1) {
      g.addNode(`leaf${i}`, null);
      g.addEdge('root', `leaf${i}`);
    }
    const r = parallelizable(g);
    assert.equal(r.depth, 2);
    assert.equal(r.width, 5);
    assert.deepEqual(r.layers[0], ['root']);
    assert.equal(r.layers[1]!.length, 5);
  });

  it('a diamond is depth=3, width=2', () => {
    const g = new Graph<null>();
    g.addNode('a', null).addNode('b', null).addNode('c', null).addNode('d', null);
    g.addEdge('a', 'b').addEdge('a', 'c').addEdge('b', 'd').addEdge('c', 'd');
    const r = parallelizable(g);
    assert.deepEqual(r.layers, [['a'], ['b', 'c'], ['d']]);
    assert.equal(r.depth, 3);
    assert.equal(r.width, 2);
  });

  it('places fan-in at the layer matching its slowest parent', () => {
    // a -> b -> d
    // a -> c -> e -> d
    // d should land in layer 3 (after e), not layer 2 (after b).
    const g = new Graph<null>();
    g.addNode('a', null)
      .addNode('b', null)
      .addNode('c', null)
      .addNode('d', null)
      .addNode('e', null);
    g.addEdge('a', 'b').addEdge('a', 'c').addEdge('b', 'd').addEdge('c', 'e').addEdge('e', 'd');
    const r = parallelizable(g);
    assert.equal(r.layers.length, 4);
    assert.deepEqual(r.layers[0], ['a']);
    assert.deepEqual(r.layers[1]!.sort(), ['b', 'c']);
    assert.deepEqual(r.layers[2], ['e']);
    assert.deepEqual(r.layers[3], ['d']);
  });

  it('throws on a cyclic graph', () => {
    const g = new Graph<null>();
    g.addNode('a', null).addNode('b', null).addEdge('a', 'b').addEdge('b', 'a');
    assert.throws(() => parallelizable(g), GraphError);
  });

  it('handles disconnected components in the same layering pass', () => {
    const g = new Graph<null>();
    g.addNode('a', null).addNode('b', null).addNode('x', null).addNode('y', null);
    g.addEdge('a', 'b').addEdge('x', 'y');
    const r = parallelizable(g);
    assert.equal(r.depth, 2);
    assert.deepEqual(r.layers[0]!.sort(), ['a', 'x']);
    assert.deepEqual(r.layers[1]!.sort(), ['b', 'y']);
  });
});

describe('layerOf', () => {
  it('returns the index of the layer containing the node', () => {
    const g = new Graph<null>();
    g.addNode('a', null).addNode('b', null).addEdge('a', 'b');
    const layering = parallelizable(g);
    assert.equal(layerOf(layering, 'a'), 0);
    assert.equal(layerOf(layering, 'b'), 1);
  });

  it('returns -1 for an unknown node', () => {
    const g = new Graph<null>();
    g.addNode('a', null);
    const layering = parallelizable(g);
    assert.equal(layerOf(layering, 'ghost'), -1);
  });
});
