// Topological order via Kahn's algorithm.
//
// Why Kahn rather than DFS-based topo: Kahn's algorithm naturally produces
// a stable order keyed on insertion index when ties are broken by
// `Graph.indexOf`. DFS topo orders depend on traversal order in a way
// that's harder to reason about for callers. Stability matters because
// the scheduler dispatches in topo order and operators rely on the
// dispatched-at-time correlating with the order they declared the nodes.

import { Graph, type NodeId, GraphError } from './graph.ts';

export interface TopologicalOrder {
  order: NodeId[];
  // True if and only if the input was a DAG. When false, `order` contains
  // the prefix of nodes Kahn's algorithm could process before getting
  // stuck, which is sometimes useful to display.
  acyclic: boolean;
  remaining: NodeId[]; // nodes that could not be ordered (only non-empty when !acyclic)
}

export function topologicalOrder<T>(graph: Graph<T>): TopologicalOrder {
  const inDegree = new Map<NodeId, number>();
  for (const id of graph.allNodes()) {
    inDegree.set(id, graph.parentsOf(id).length);
  }

  // Stable order: the queue is kept sorted by insertion index. We use a
  // sorted-insert approach since the queue is small (|roots| at any time
  // is usually <= 10 in real workloads). For huge graphs a heap would be
  // faster but we don't need that.
  const queue: NodeId[] = graph.roots();
  const order: NodeId[] = [];
  while (queue.length > 0) {
    queue.sort((a, b) => graph.indexOf(a) - graph.indexOf(b));
    const next = queue.shift()!;
    order.push(next);
    for (const child of graph.childrenOf(next)) {
      const remaining = inDegree.get(child)! - 1;
      inDegree.set(child, remaining);
      if (remaining === 0) queue.push(child);
    }
  }

  if (order.length === graph.size()) {
    return { order, acyclic: true, remaining: [] };
  }
  const ordered = new Set(order);
  const remaining = graph
    .allNodes()
    .filter((id) => !ordered.has(id))
    .sort((a, b) => graph.indexOf(a) - graph.indexOf(b));
  return { order, acyclic: false, remaining };
}

export function topologicalSort<T>(graph: Graph<T>): NodeId[] {
  const r = topologicalOrder(graph);
  if (!r.acyclic) {
    throw new GraphError(
      `graph contains cycles; cannot topologically sort. ${r.remaining.length} unordered nodes remaining.`,
    );
  }
  return r.order;
}
