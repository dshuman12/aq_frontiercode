// Cycle detection via Tarjan's strongly-connected-components algorithm.
//
// We return ALL non-trivial SCCs (size >= 2) as cycles. Self-loops would
// also count as a 1-element SCC with a self-edge, but Graph.addEdge
// rejects self-loops at construction time so we don't need to check
// here.
//
// Tarjan's runs in O(V + E) and gives us all cycles in one pass; using
// it here also doubles as input to the validator (which wants to be
// able to display every cycle, not just the first one found).

import { Graph, type NodeId } from './graph.ts';

export type Cycle = NodeId[];

interface VertexState {
  index: number;
  lowlink: number;
  onStack: boolean;
}

export function cycles<T>(graph: Graph<T>): Cycle[] {
  // Iterative Tarjan to avoid blowing the call stack on deep DAGs.
  // The recursive form is more readable but a 50k-node chain will
  // overflow the default v8 stack. Asking the user to bump
  // --stack-size on every run is hostile.
  const state = new Map<NodeId, VertexState>();
  const stack: NodeId[] = [];
  const out: Cycle[] = [];
  let counter = 0;

  type Frame = { v: NodeId; iter: Iterator<NodeId>; current?: NodeId };
  const callStack: Frame[] = [];

  const strongconnect = (root: NodeId): void => {
    state.set(root, { index: counter, lowlink: counter, onStack: true });
    counter += 1;
    stack.push(root);
    callStack.push({ v: root, iter: graph.childrenOf(root)[Symbol.iterator]() });

    while (callStack.length > 0) {
      const frame = callStack[callStack.length - 1]!;
      // If we just returned from a child, propagate its lowlink.
      if (frame.current !== undefined) {
        const childState = state.get(frame.current)!;
        const vState = state.get(frame.v)!;
        if (childState.lowlink < vState.lowlink) vState.lowlink = childState.lowlink;
        frame.current = undefined;
      }
      const step = frame.iter.next();
      if (step.done) {
        // Pop SCC if v is a root.
        const vState = state.get(frame.v)!;
        if (vState.lowlink === vState.index) {
          const component: NodeId[] = [];
          // eslint-disable-next-line no-constant-condition
          while (true) {
            const w = stack.pop()!;
            const ws = state.get(w)!;
            ws.onStack = false;
            component.push(w);
            if (w === frame.v) break;
          }
          if (component.length > 1) {
            // Reverse so the cycle reads in declaration order, which makes
            // error messages easier on humans.
            out.push(component.reverse());
          }
        }
        callStack.pop();
        continue;
      }
      const w = step.value;
      const ws = state.get(w);
      if (!ws) {
        state.set(w, { index: counter, lowlink: counter, onStack: true });
        counter += 1;
        stack.push(w);
        frame.current = w;
        callStack.push({ v: w, iter: graph.childrenOf(w)[Symbol.iterator]() });
      } else if (ws.onStack) {
        const vState = state.get(frame.v)!;
        if (ws.index < vState.lowlink) vState.lowlink = ws.index;
      }
      // else: w is in a fully processed SCC; skip
    }
  };

  for (const id of graph.allNodes()) {
    if (!state.has(id)) strongconnect(id);
  }
  return out;
}

export function isAcyclic<T>(graph: Graph<T>): boolean {
  return cycles(graph).length === 0;
}
