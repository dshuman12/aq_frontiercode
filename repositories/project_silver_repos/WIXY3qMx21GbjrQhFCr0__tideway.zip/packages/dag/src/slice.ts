// Structural slicing: build a sub-DAG consisting only of the nodes that
// satisfy a predicate, plus all edges between them. Nodes that fail the
// predicate are dropped, and edges that cross the predicate boundary are
// dropped too (we don't synthesize transitive edges through dropped
// nodes - that would change reachability semantics).
//
// This is used by the scheduler to ask "of all jobs in this workflow,
// which ones are still relevant given the current cancellation /
// deadline state?", and by the dlq replay to re-instantiate just the
// failed-and-downstream subset.

import { Graph, type NodeId } from './graph.ts';

export function slice<T>(graph: Graph<T>, predicate: (id: NodeId, value: T) => boolean): Graph<T> {
  const out = new Graph<T>();
  const keep: NodeId[] = [];
  for (const id of graph.allNodes()) {
    const value = graph.get(id);
    if (predicate(id, value)) {
      out.addNode(id, value);
      keep.push(id);
    }
  }
  const keepSet = new Set(keep);
  for (const id of keep) {
    for (const child of graph.childrenOf(id)) {
      if (keepSet.has(child)) out.addEdge(id, child);
    }
  }
  return out;
}

// Subgraph rooted at the given seeds: every descendant of a seed,
// including the seeds themselves. Useful for "show me the work still to
// do downstream of this node".
export function descendantSubgraph<T>(graph: Graph<T>, seeds: NodeId[]): Graph<T> {
  const reach = graph.descendants(seeds);
  return slice(graph, (id) => reach.has(id));
}

// The mirror: nodes that are ancestors of any seed (and the seeds).
// Useful for "what produced this output?".
export function ancestorSubgraph<T>(graph: Graph<T>, seeds: NodeId[]): Graph<T> {
  const reach = graph.ancestors(seeds);
  return slice(graph, (id) => reach.has(id));
}
