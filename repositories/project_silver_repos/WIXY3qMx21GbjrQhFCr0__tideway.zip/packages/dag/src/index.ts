// Public surface for @tideway/dag. We re-export everything that's
// callable from outside the package; internal helpers (the iterative
// Tarjan frame structure, for instance) stay scoped to their files.

export { Graph, GraphError, type NodeId, type NodeRecord } from './graph.ts';
export { topologicalOrder, topologicalSort, type TopologicalOrder } from './topology.ts';
export { cycles, isAcyclic, type Cycle } from './cycles.ts';
export { parallelizable, layerOf, type LayeringResult, type Layer } from './layers.ts';
export { slice, descendantSubgraph, ancestorSubgraph } from './slice.ts';
export {
  validate,
  type ValidationReport,
  type ValidationIssue,
  type ValidationOptions,
  type IssueKind,
} from './validate.ts';
