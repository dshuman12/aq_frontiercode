// Graph: a directed graph backed by adjacency lists.
//
// The shape we need from this module is small and well-known: add nodes,
// add edges, ask for parents/children, ask for the set of all nodes
// reachable from a starting set. The wider API (topological order, cycle
// detection, layering, slicing) is split into sibling modules that each
// take a `Graph<T>` and return a result. Keeping those separate from the
// data structure makes them straightforward to test in isolation and
// keeps Graph itself unopinionated about traversal order.
//
// One choice worth flagging: we store children and parents both. That
// doubles the memory footprint but it's worth it - every algorithm in
// the runtime needs `parents(id)` somewhere, and computing it on demand
// from the children-only representation would be O(E) per call. With
// the maximum DAG sizes we care about (~10k nodes) the duplication is
// negligible, and it lets `parents()` be O(1).

import { TidewayError } from '@tideway/failure';

export type NodeId = string;

export class GraphError extends TidewayError {
  override readonly name = 'GraphError';
}

export interface NodeRecord<T> {
  id: NodeId;
  value: T;
  // Insertion order is preserved so deterministic traversals are stable
  // across runs without needing the caller to sort.
  insertionIndex: number;
}

export class Graph<T> {
  private readonly nodes = new Map<NodeId, NodeRecord<T>>();
  private readonly outgoing = new Map<NodeId, Set<NodeId>>();
  private readonly incoming = new Map<NodeId, Set<NodeId>>();
  private nextIndex = 0;

  static empty<T>(): Graph<T> {
    return new Graph<T>();
  }

  size(): number {
    return this.nodes.size;
  }

  edgeCount(): number {
    let total = 0;
    for (const out of this.outgoing.values()) total += out.size;
    return total;
  }

  has(id: NodeId): boolean {
    return this.nodes.has(id);
  }

  get(id: NodeId): T {
    const rec = this.nodes.get(id);
    if (!rec) throw new GraphError(`unknown node: ${id}`);
    return rec.value;
  }

  addNode(id: NodeId, value: T): this {
    if (this.nodes.has(id)) {
      throw new GraphError(`duplicate node: ${id}`);
    }
    if (id === '') {
      throw new GraphError('node id must be non-empty');
    }
    this.nodes.set(id, { id, value, insertionIndex: this.nextIndex });
    this.outgoing.set(id, new Set());
    this.incoming.set(id, new Set());
    this.nextIndex += 1;
    return this;
  }

  // Update the value for an existing node. We don't allow changing a node's
  // id (renaming) because every other algorithm caches NodeIds, and the
  // bookkeeping to invalidate those caches is more code than it's worth.
  // If you need to rename a node, build a new graph from a transformation.
  updateValue(id: NodeId, value: T): this {
    const rec = this.nodes.get(id);
    if (!rec) throw new GraphError(`unknown node: ${id}`);
    rec.value = value;
    return this;
  }

  addEdge(from: NodeId, to: NodeId): this {
    if (!this.nodes.has(from)) throw new GraphError(`unknown source: ${from}`);
    if (!this.nodes.has(to)) throw new GraphError(`unknown target: ${to}`);
    if (from === to) {
      throw new GraphError(`self-loop not allowed: ${from} -> ${to}`);
    }
    // Idempotent: adding an existing edge is a no-op rather than an error.
    // Real-world callers (the validator, especially) build graphs by
    // walking declarations that may name the same dependency twice; making
    // them dedup before calling here is unhelpful churn.
    this.outgoing.get(from)!.add(to);
    this.incoming.get(to)!.add(from);
    return this;
  }

  hasEdge(from: NodeId, to: NodeId): boolean {
    const out = this.outgoing.get(from);
    return out ? out.has(to) : false;
  }

  childrenOf(id: NodeId): NodeId[] {
    const out = this.outgoing.get(id);
    if (!out) throw new GraphError(`unknown node: ${id}`);
    return Array.from(out).sort((a, b) => this.indexOf(a) - this.indexOf(b));
  }

  parentsOf(id: NodeId): NodeId[] {
    const inc = this.incoming.get(id);
    if (!inc) throw new GraphError(`unknown node: ${id}`);
    return Array.from(inc).sort((a, b) => this.indexOf(a) - this.indexOf(b));
  }

  // Roots: nodes with no incoming edges. Stable insertion order.
  roots(): NodeId[] {
    const out: NodeId[] = [];
    for (const rec of this.iterRecordsInsertionOrder()) {
      if (this.incoming.get(rec.id)!.size === 0) out.push(rec.id);
    }
    return out;
  }

  // Leaves: nodes with no outgoing edges.
  leaves(): NodeId[] {
    const out: NodeId[] = [];
    for (const rec of this.iterRecordsInsertionOrder()) {
      if (this.outgoing.get(rec.id)!.size === 0) out.push(rec.id);
    }
    return out;
  }

  // All node ids in insertion order. Useful for tests and dumps.
  allNodes(): NodeId[] {
    return Array.from(this.iterRecordsInsertionOrder()).map((r) => r.id);
  }

  // Reachable forward (via outgoing edges) from any of the given seeds.
  // The seeds themselves are included.
  descendants(seeds: NodeId[] | Iterable<NodeId>): Set<NodeId> {
    return this.reach(seeds, 'forward');
  }

  // Reachable backward (via incoming edges) from any of the given seeds.
  ancestors(seeds: NodeId[] | Iterable<NodeId>): Set<NodeId> {
    return this.reach(seeds, 'backward');
  }

  indexOf(id: NodeId): number {
    const rec = this.nodes.get(id);
    if (!rec) throw new GraphError(`unknown node: ${id}`);
    return rec.insertionIndex;
  }

  private *iterRecordsInsertionOrder(): IterableIterator<NodeRecord<T>> {
    // Map iteration is insertion-ordered in JS, so this is just `this.nodes.values()`.
    // Keeping a method wrapper so future changes to the storage strategy
    // don't ripple through every caller.
    yield* this.nodes.values();
  }

  private reach(seeds: NodeId[] | Iterable<NodeId>, direction: 'forward' | 'backward'): Set<NodeId> {
    const seen = new Set<NodeId>();
    const stack: NodeId[] = [];
    for (const s of seeds) {
      if (!this.nodes.has(s)) throw new GraphError(`unknown seed: ${s}`);
      if (!seen.has(s)) {
        seen.add(s);
        stack.push(s);
      }
    }
    const adj = direction === 'forward' ? this.outgoing : this.incoming;
    while (stack.length > 0) {
      const cur = stack.pop()!;
      for (const next of adj.get(cur)!) {
        if (!seen.has(next)) {
          seen.add(next);
          stack.push(next);
        }
      }
    }
    return seen;
  }
}
