// DAG validation: a single entry point that checks every property the
// runtime relies on. The result is a `ValidationReport` with one
// classified issue per problem; callers decide whether any one is fatal.
//
// Properties checked:
//   - acyclic
//   - every declared edge connects two existing nodes (Graph.addEdge
//     enforces this at construction time, so this is just a defense in
//     depth)
//   - the graph has at least one root
//   - the graph is "reachable from roots" - every node is a descendant
//     of some root. (A node with parents but no path from any root is
//     impossible in a DAG, but we check anyway because if Graph ever
//     drops the self-loop guard this becomes possible to hit.)
//   - "fan width" doesn't exceed a configurable cap (defaults to 10000
//     so it's effectively only a guard against truly pathological
//     inputs).

import { Graph, type NodeId } from './graph.ts';
import { cycles } from './cycles.ts';

export type IssueKind =
  | 'cycle'
  | 'no_roots'
  | 'unreachable_from_root'
  | 'width_exceeded'
  | 'orphan';

export interface ValidationIssue {
  kind: IssueKind;
  message: string;
  // The set of nodes most directly involved in this issue. For cycle
  // issues this is the cycle members; for unreachable_from_root it's the
  // unreachable nodes.
  nodes: NodeId[];
}

export interface ValidationReport {
  ok: boolean;
  issues: ValidationIssue[];
}

export interface ValidationOptions {
  // Maximum width (number of nodes in any one layer). Defaults to 10_000.
  maxWidth?: number;
  // If true, an empty graph is considered valid. Default is false because
  // the scheduler can't make progress on an empty graph and silently
  // accepting one tends to mask configuration errors upstream.
  allowEmpty?: boolean;
}

export function validate<T>(graph: Graph<T>, opts: ValidationOptions = {}): ValidationReport {
  const issues: ValidationIssue[] = [];
  const maxWidth = opts.maxWidth ?? 10_000;
  const allowEmpty = opts.allowEmpty ?? false;

  if (graph.size() === 0) {
    if (allowEmpty) return { ok: true, issues: [] };
    issues.push({
      kind: 'no_roots',
      message: 'graph is empty',
      nodes: [],
    });
    return { ok: false, issues };
  }

  const cyc = cycles(graph);
  for (const c of cyc) {
    issues.push({
      kind: 'cycle',
      message: `cycle: ${c.join(' -> ')} -> ${c[0]}`,
      nodes: c,
    });
  }

  const roots = graph.roots();
  if (roots.length === 0) {
    issues.push({
      kind: 'no_roots',
      message: 'no root nodes (every node has a parent, which only happens with cycles)',
      nodes: [],
    });
  } else if (cyc.length === 0) {
    // Reachability check is meaningless if cycles are present.
    const reachable = graph.descendants(roots);
    const orphans = graph.allNodes().filter((id) => !reachable.has(id));
    for (const o of orphans) {
      issues.push({
        kind: 'unreachable_from_root',
        message: `node ${o} is not reachable from any root`,
        nodes: [o],
      });
    }
  }

  // Width check: only meaningful if acyclic.
  if (cyc.length === 0 && roots.length > 0) {
    let widest = 0;
    for (const id of graph.allNodes()) {
      const c = graph.childrenOf(id).length;
      if (c > widest) widest = c;
    }
    if (widest > maxWidth) {
      issues.push({
        kind: 'width_exceeded',
        message: `node has ${widest} children (max ${maxWidth})`,
        nodes: [],
      });
    }
  }

  return { ok: issues.length === 0, issues };
}
