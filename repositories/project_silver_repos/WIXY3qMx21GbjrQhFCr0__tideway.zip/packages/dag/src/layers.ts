// Parallelizable layers: group nodes into the largest sets that can run
// concurrently. Layer 0 is roots; layer N+1 is everything whose every
// parent is in layer <= N.
//
// This is the form the scheduler actually consumes. The scheduler then
// applies concurrency caps per queue, deadline checks, etc., but the
// "what could in principle run together" answer comes from here.
//
// Implementation: BFS by in-degree, identical to Kahn's first sweep
// except that we collect each "wave" rather than emitting one node at a
// time.

import { Graph, type NodeId, GraphError } from './graph.ts';

export type Layer = NodeId[];

export interface LayeringResult {
  layers: Layer[];
  // The width is the largest layer's size. For a chain it's 1; for a
  // pure fan-out from one root to N leaves it's N.
  width: number;
  // The depth is the number of layers. This is the critical-path length
  // assuming each node takes 1 unit of time.
  depth: number;
}

export function parallelizable<T>(graph: Graph<T>): LayeringResult {
  const inDegree = new Map<NodeId, number>();
  for (const id of graph.allNodes()) {
    inDegree.set(id, graph.parentsOf(id).length);
  }

  let frontier: NodeId[] = graph.roots();
  const layers: Layer[] = [];
  const placed = new Set<NodeId>();

  while (frontier.length > 0) {
    const layer = [...frontier].sort((a, b) => graph.indexOf(a) - graph.indexOf(b));
    layers.push(layer);
    for (const id of layer) placed.add(id);

    const next: NodeId[] = [];
    for (const id of layer) {
      for (const child of graph.childrenOf(id)) {
        const remaining = inDegree.get(child)! - 1;
        inDegree.set(child, remaining);
        if (remaining === 0) next.push(child);
      }
    }
    frontier = next;
  }

  if (placed.size !== graph.size()) {
    throw new GraphError(
      `graph contains cycles; cannot layer. placed=${placed.size}, total=${graph.size()}`,
    );
  }

  let width = 0;
  for (const l of layers) {
    if (l.length > width) width = l.length;
  }
  return { layers, width, depth: layers.length };
}

// Find the layer containing a node, or -1 if the node isn't placed
// (cycle member, or unknown). Linear-scan; not used in hot paths.
export function layerOf(layering: LayeringResult, id: NodeId): number {
  for (let i = 0; i < layering.layers.length; i += 1) {
    if (layering.layers[i]!.includes(id)) return i;
  }
  return -1;
}
