import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import type { Event } from '@tideway/runstate';
import { replayAll, replayOne, type LogEntry } from '../src/index.ts';

const t = (n: number) => BigInt(n);

const created = (lsn: number, runId: string, at = 0): LogEntry => ({
  lsn,
  runId,
  kind: 'created',
  at: t(at),
});

const evt = (lsn: number, runId: string, event: Event, attempt?: number): LogEntry => ({
  lsn,
  runId,
  event,
  ...(attempt !== undefined ? { attempt } : {}),
});

describe('replayAll: empty', () => {
  it('produces empty state on empty log', () => {
    const r = replayAll([]);
    assert.equal(r.states.size, 0);
    assert.equal(r.applied, 0);
    assert.equal(r.skipped, 0);
    assert.equal(r.lastLsn, 0);
  });
});

describe('replayAll: single run lifecycle', () => {
  it('reconstructs queued state from creation alone', () => {
    const r = replayAll([created(1, 'r1', 100)]);
    const s = r.states.get('r1');
    assert.equal(s?.kind, 'queued');
    assert.equal(r.applied, 1);
  });

  it('reconstructs running state through dispatch', () => {
    const r = replayAll([
      created(1, 'r1'),
      evt(2, 'r1', { kind: 'dispatch', at: t(10), workerId: 'w', leaseExpiresAt: t(1000) }),
    ]);
    const s = r.states.get('r1');
    assert.equal(s?.kind, 'running');
    assert.equal(r.applied, 2);
  });

  it('reconstructs succeeded state through full chain', () => {
    const r = replayAll([
      created(1, 'r1'),
      evt(2, 'r1', { kind: 'dispatch', at: t(10), workerId: 'w', leaseExpiresAt: t(1000) }),
      evt(3, 'r1', { kind: 'succeed', at: t(20), result: { ok: true } }),
    ]);
    const s = r.states.get('r1');
    assert.equal(s?.kind, 'succeeded');
    if (s?.kind === 'succeeded') {
      assert.deepEqual(s.result, { ok: true });
    }
  });

  it('handles a retry cycle ending in success', () => {
    const r = replayAll([
      created(1, 'r1'),
      evt(2, 'r1', { kind: 'dispatch', at: t(10), workerId: 'w', leaseExpiresAt: t(1000) }),
      evt(3, 'r1', { kind: 'schedule_retry', at: t(20), nextAttemptAt: t(100) }),
      evt(4, 'r1', { kind: 'requeue', at: t(100) }),
      evt(5, 'r1', { kind: 'dispatch', at: t(110), workerId: 'w', leaseExpiresAt: t(2000) }, 2),
      evt(6, 'r1', { kind: 'succeed', at: t(120), result: 42 }),
    ]);
    const s = r.states.get('r1');
    assert.equal(s?.kind, 'succeeded');
    if (s?.kind === 'succeeded') {
      assert.equal(s.attempt, 2);
      assert.equal(s.result, 42);
    }
  });
});

describe('replayAll: multiple runs interleaved', () => {
  it('keeps independent runs separate', () => {
    const r = replayAll([
      created(1, 'r1'),
      created(2, 'r2'),
      evt(3, 'r1', { kind: 'dispatch', at: t(10), workerId: 'w', leaseExpiresAt: t(1000) }),
      evt(4, 'r2', { kind: 'cancel', at: t(15), reason: 'external' }),
      evt(5, 'r1', { kind: 'succeed', at: t(20), result: null }),
    ]);
    assert.equal(r.states.get('r1')?.kind, 'succeeded');
    assert.equal(r.states.get('r2')?.kind, 'canceled');
  });
});

describe('replayAll: anomalies', () => {
  it('skips event for unknown run, recording firstIllegal', () => {
    const r = replayAll([
      evt(1, 'ghost', { kind: 'dispatch', at: t(0), workerId: 'w', leaseExpiresAt: t(100) }),
    ]);
    assert.equal(r.applied, 0);
    assert.equal(r.skipped, 1);
    assert.equal(r.firstIllegal?.runId, 'ghost');
  });

  it('skips duplicate creation', () => {
    const r = replayAll([created(1, 'r1'), created(2, 'r1')]);
    assert.equal(r.applied, 1);
    assert.equal(r.skipped, 1);
    assert.equal(r.firstIllegal?.reason, 'duplicate creation');
  });

  it('skips an illegal transition without crashing', () => {
    const r = replayAll([
      created(1, 'r1'),
      evt(2, 'r1', { kind: 'heartbeat', at: t(10), leaseExpiresAt: t(100) }), // illegal: queued + heartbeat
    ]);
    assert.equal(r.applied, 1);
    assert.equal(r.skipped, 1);
    assert.match(r.firstIllegal!.reason, /illegal transition/);
  });

  it('skips an out-of-order LSN entry', () => {
    const r = replayAll([
      created(5, 'r1'),
      evt(3, 'r1', { kind: 'cancel', at: t(20), reason: 'external' }), // lsn 3 < 5
    ]);
    assert.equal(r.applied, 1);
    assert.equal(r.skipped, 1);
    assert.match(r.firstIllegal!.reason, /non-monotonic/);
  });

  it('records lastLsn even when entries were skipped', () => {
    const r = replayAll([
      evt(1, 'ghost', { kind: 'dispatch', at: t(0), workerId: 'w', leaseExpiresAt: t(100) }),
      created(2, 'r1'),
    ]);
    assert.equal(r.lastLsn, 2);
  });
});

describe('replayAll: idempotence', () => {
  it('replaying the same log twice gives the same final states', () => {
    const log: LogEntry[] = [
      created(1, 'r1'),
      created(2, 'r2'),
      evt(3, 'r1', { kind: 'dispatch', at: t(10), workerId: 'w', leaseExpiresAt: t(1000) }),
      evt(4, 'r1', { kind: 'fail', at: t(20), failureKind: 'permanent', message: 'x' }),
      evt(5, 'r2', { kind: 'cancel', at: t(15), reason: 'external' }),
    ];
    const a = replayAll(log);
    const b = replayAll(log);
    assert.deepEqual(
      [...a.states.entries()].map(([k, v]) => [k, v.kind]),
      [...b.states.entries()].map(([k, v]) => [k, v.kind]),
    );
  });
});

describe('replayAll: prefix equivalence', () => {
  it('replaying a prefix gives the state at that point', () => {
    const log: LogEntry[] = [
      created(1, 'r1'),
      evt(2, 'r1', { kind: 'dispatch', at: t(10), workerId: 'w', leaseExpiresAt: t(1000) }),
      evt(3, 'r1', { kind: 'succeed', at: t(20), result: 1 }),
    ];
    const after2 = replayAll(log.slice(0, 2));
    assert.equal(after2.states.get('r1')?.kind, 'running');
    const after3 = replayAll(log);
    assert.equal(after3.states.get('r1')?.kind, 'succeeded');
  });
});

describe('replayOne', () => {
  it('returns the state of the chosen run only', () => {
    const log: LogEntry[] = [
      created(1, 'r1'),
      created(2, 'r2'),
      evt(3, 'r2', { kind: 'cancel', at: t(10), reason: 'external' }),
    ];
    const s = replayOne('r2', log);
    assert.equal(s?.kind, 'canceled');
  });

  it('returns undefined for an unknown run', () => {
    const s = replayOne('ghost', [created(1, 'r1')]);
    assert.equal(s, undefined);
  });
});
