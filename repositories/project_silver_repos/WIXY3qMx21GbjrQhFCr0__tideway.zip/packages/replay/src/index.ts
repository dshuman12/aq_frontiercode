// Crash recovery: deterministic replay of an event log.
//
// Persistence in tideway is event-sourced. The store records every state
// transition as a `LoggedEvent` keyed by RunId and a monotonic LSN. After a
// crash, the runner reads all events in LSN order and replays them through
// the FSM to rebuild the in-memory `Map<RunId, RunState>`.
//
// Two correctness properties this module guarantees:
//
//   1. Replay equivalence: feeding any prefix of the log into `replayAll`
//      produces the exact RunState that existed at the moment that LSN was
//      written. This is what makes cross-process resumption work.
//
//   2. Idempotence: replaying the same log twice produces the same result.
//      This matters because the runner replays at startup and then keeps
//      receiving live events; if the boundary between "recovered" and
//      "live" is fuzzy, we want double-applies to be safe.
//
// The replayer also tracks which events were skipped due to invalid
// transitions and surfaces them in the result. In production these should
// always be zero; if not, the operator has a problem (a corrupted log, a
// version skew between writer and reader). The replay still completes
// rather than erroring out, on the theory that a partially-recovered
// runtime is usually more useful than no runtime.

import {
  IllegalTransition,
  initialState,
  transition,
  type Event,
  type RunState,
} from '@tideway/runstate';

export type RunId = string;
export type LSN = number;

export interface LoggedEvent {
  lsn: LSN;
  runId: RunId;
  event: Event;
  // The attempt option that was applied to `transition`, if any. We
  // record it because the FSM doesn't always have enough information to
  // reconstruct the attempt from state alone (specifically the
  // queued->running transition with attempt > 1).
  attempt?: number;
}

// "Genesis" markers that introduce a new run. We store them as their own
// kind because the `transition` function doesn't have a "create" event;
// the initial state is constructed via initialState(at).
export interface RunCreated {
  lsn: LSN;
  runId: RunId;
  kind: 'created';
  at: bigint;
}

export type LogEntry = LoggedEvent | RunCreated;

export interface ReplayResult {
  states: Map<RunId, RunState>;
  // The highest LSN observed during replay. Used by callers to know where
  // to start tailing for live events.
  lastLsn: LSN;
  // Counts. `applied` includes both creations and transitions; `skipped`
  // are events that hit an IllegalTransition. The first illegal transition
  // is captured for diagnostics.
  applied: number;
  skipped: number;
  firstIllegal?: { lsn: LSN; runId: RunId; eventKind: string; reason: string };
}

export function replayAll(log: Iterable<LogEntry>): ReplayResult {
  const states = new Map<RunId, RunState>();
  let lastLsn: LSN = 0;
  let applied = 0;
  let skipped = 0;
  let firstIllegal: ReplayResult['firstIllegal'];

  let prevLsn = -1;
  for (const entry of log) {
    if (entry.lsn <= prevLsn) {
      // The log MUST be in monotonic LSN order. Out-of-order entries are
      // a corruption signal; skip them and record. Calling code can
      // surface this and operators can decide what to do.
      skipped += 1;
      if (!firstIllegal) {
        firstIllegal = {
          lsn: entry.lsn,
          runId: entry.runId,
          eventKind: 'kind' in entry ? entry.kind : entry.event.kind,
          reason: `non-monotonic LSN (got ${entry.lsn}, prev was ${prevLsn})`,
        };
      }
      continue;
    }
    prevLsn = entry.lsn;

    if ('kind' in entry && entry.kind === 'created') {
      if (states.has(entry.runId)) {
        skipped += 1;
        if (!firstIllegal) {
          firstIllegal = {
            lsn: entry.lsn,
            runId: entry.runId,
            eventKind: 'created',
            reason: 'duplicate creation',
          };
        }
      } else {
        states.set(entry.runId, initialState(entry.at));
        applied += 1;
      }
      lastLsn = entry.lsn;
      continue;
    }

    const logged = entry as LoggedEvent;
    const state = states.get(logged.runId);
    if (!state) {
      // Event arrived without a creation record. Treat as a skip. This
      // can happen if the writer reordered or if the log was truncated.
      skipped += 1;
      if (!firstIllegal) {
        firstIllegal = {
          lsn: logged.lsn,
          runId: logged.runId,
          eventKind: logged.event.kind,
          reason: 'event for unknown run',
        };
      }
      lastLsn = logged.lsn;
      continue;
    }
    try {
      const next = transition(
        state,
        logged.event,
        logged.attempt !== undefined ? { attempt: logged.attempt } : {},
      );
      states.set(logged.runId, next);
      applied += 1;
    } catch (err) {
      if (err instanceof IllegalTransition) {
        skipped += 1;
        if (!firstIllegal) {
          firstIllegal = {
            lsn: logged.lsn,
            runId: logged.runId,
            eventKind: logged.event.kind,
            reason: err.message,
          };
        }
      } else {
        throw err;
      }
    }
    lastLsn = logged.lsn;
  }

  return firstIllegal !== undefined
    ? { states, lastLsn, applied, skipped, firstIllegal }
    : { states, lastLsn, applied, skipped };
}

// Replay only events for a single run. Useful when investigating a
// specific run's history without paying the cost of replaying the whole
// log.
export function replayOne(runId: RunId, log: Iterable<LogEntry>): RunState | undefined {
  const filtered: LogEntry[] = [];
  for (const entry of log) {
    if (entry.runId === runId) filtered.push(entry);
  }
  const result = replayAll(filtered);
  return result.states.get(runId);
}
