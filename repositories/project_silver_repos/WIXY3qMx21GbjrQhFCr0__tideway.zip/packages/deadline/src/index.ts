// Deadline propagation across a DAG.
//
// A node's effective deadline is the minimum of:
//   - its own declared deadline (if any)
//   - the effective deadline of every parent (recursively)
//
// In other words: a child cannot outlive its parent's deadline. This is
// the natural reading of "deadline" in workflow-orchestration land:
// once the wall clock hits the workflow-level deadline, no descendant
// has any business still running.
//
// The math is straightforward, but two edge cases bit us during
// implementation:
//
//   1. Nodes without a declared deadline. We model this as Infinity rather
//      than `null` so the min-reduction is uniform; the JSON serializer
//      converts back to `null` on output.
//
//   2. Diamonds. With two parents that each have different effective
//      deadlines, we take min. This matters because if one parent expires
//      first, the slower-deadline parent can keep running but its child
//      must already be considered breached.

import { Graph, type NodeId } from '@tideway/dag';

// ms-since-epoch. Infinity means "no declared deadline".
export type Deadline = number;

export interface DeadlinedNode {
  declaredDeadline: Deadline; // Infinity = no declared deadline
}

export interface PropagatedDeadlines {
  effective: Map<NodeId, Deadline>;
}

export function propagate<T extends DeadlinedNode>(graph: Graph<T>): PropagatedDeadlines {
  const effective = new Map<NodeId, Deadline>();

  // Topological order via in-degree countdown (we re-implement here rather
  // than depending on dag.topology so we don't need a circular import; the
  // logic is simple enough that the duplication is cheaper than the
  // alternative).
  const inDeg = new Map<NodeId, number>();
  for (const id of graph.allNodes()) inDeg.set(id, graph.parentsOf(id).length);

  let frontier = graph.roots();
  while (frontier.length > 0) {
    const next: NodeId[] = [];
    // Process this layer fully before advancing.
    for (const id of frontier) {
      const value = graph.get(id);
      const parents = graph.parentsOf(id);
      let bound = value.declaredDeadline;
      for (const p of parents) {
        const pe = effective.get(p);
        if (pe === undefined) {
          // Should be impossible in a true DAG with this traversal, but if it
          // happens we treat the parent as unbounded rather than crashing,
          // and we'll log it via the runner's tracing layer (not here).
          continue;
        }
        if (pe < bound) bound = pe;
      }
      effective.set(id, bound);
    }
    for (const id of frontier) {
      for (const child of graph.childrenOf(id)) {
        const remaining = inDeg.get(child)! - 1;
        inDeg.set(child, remaining);
        if (remaining === 0) next.push(child);
      }
    }
    frontier = next;
  }

  return { effective };
}

// Has the deadline been breached? Calling code typically asks this just
// before dispatching, with `now = Date.now()`.
export function isBreached(deadline: Deadline, now: number): boolean {
  return now >= deadline;
}

// Time remaining in milliseconds. A negative number means already
// breached. Infinity means unbounded.
export function remaining(deadline: Deadline, now: number): number {
  if (deadline === Infinity) return Infinity;
  return deadline - now;
}

// Find every node that, given `now`, has already breached its effective
// deadline. Useful for the cancellation sweep that runs once per scheduler
// tick.
export function breachedNodes(p: PropagatedDeadlines, now: number): NodeId[] {
  const out: NodeId[] = [];
  for (const [id, eff] of p.effective) {
    if (isBreached(eff, now)) out.push(id);
  }
  return out;
}

// FixedDeadline / RelativeDeadline / NoDeadline -> absolute Deadline.
// Used at submission time to normalize whatever form the caller gave us.
export type DeadlineSpec =
  | { kind: 'absolute'; at: number }
  | { kind: 'relative'; afterMs: number }
  | { kind: 'none' };

export function resolve(spec: DeadlineSpec, now: number): Deadline {
  switch (spec.kind) {
    case 'absolute':
      return spec.at;
    case 'relative':
      return now + spec.afterMs;
    case 'none':
      return Infinity;
  }
}
