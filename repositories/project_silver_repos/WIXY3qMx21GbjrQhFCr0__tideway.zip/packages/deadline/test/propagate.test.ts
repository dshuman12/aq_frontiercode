import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { Graph } from '@tideway/dag';
import {
  breachedNodes,
  isBreached,
  propagate,
  remaining,
  resolve,
  type DeadlinedNode,
} from '../src/index.ts';

const node = (declared: number): DeadlinedNode => ({ declaredDeadline: declared });

describe('propagate', () => {
  it('a chain inherits the strictest deadline', () => {
    // a (deadline 1000) -> b (no deadline) -> c (deadline 5000)
    const g = new Graph<DeadlinedNode>();
    g.addNode('a', node(1000));
    g.addNode('b', node(Infinity));
    g.addNode('c', node(5000));
    g.addEdge('a', 'b').addEdge('b', 'c');
    const p = propagate(g);
    assert.equal(p.effective.get('a'), 1000);
    assert.equal(p.effective.get('b'), 1000);
    assert.equal(p.effective.get('c'), 1000);
  });

  it('a child with a tighter deadline wins over its parent', () => {
    // a (5000) -> b (1000)
    const g = new Graph<DeadlinedNode>();
    g.addNode('a', node(5000));
    g.addNode('b', node(1000));
    g.addEdge('a', 'b');
    const p = propagate(g);
    assert.equal(p.effective.get('a'), 5000);
    assert.equal(p.effective.get('b'), 1000);
  });

  it('a diamond child takes the min of both parents', () => {
    // a (5000), x (3000) both feed c (no deadline)
    const g = new Graph<DeadlinedNode>();
    g.addNode('a', node(5000));
    g.addNode('x', node(3000));
    g.addNode('c', node(Infinity));
    g.addEdge('a', 'c').addEdge('x', 'c');
    const p = propagate(g);
    assert.equal(p.effective.get('c'), 3000);
  });

  it('roots get their declared deadline verbatim', () => {
    const g = new Graph<DeadlinedNode>();
    g.addNode('r1', node(1000));
    g.addNode('r2', node(Infinity));
    const p = propagate(g);
    assert.equal(p.effective.get('r1'), 1000);
    assert.equal(p.effective.get('r2'), Infinity);
  });

  it('handles a 4-deep chain', () => {
    const g = new Graph<DeadlinedNode>();
    g.addNode('a', node(2000)).addNode('b', node(Infinity)).addNode('c', node(Infinity));
    g.addNode('d', node(Infinity));
    g.addEdge('a', 'b').addEdge('b', 'c').addEdge('c', 'd');
    const p = propagate(g);
    for (const id of ['a', 'b', 'c', 'd']) {
      assert.equal(p.effective.get(id), 2000);
    }
  });

  it('every node gets an entry, even unbounded ones', () => {
    const g = new Graph<DeadlinedNode>();
    g.addNode('a', node(Infinity)).addNode('b', node(Infinity));
    g.addEdge('a', 'b');
    const p = propagate(g);
    assert.equal(p.effective.size, 2);
    assert.equal(p.effective.get('a'), Infinity);
    assert.equal(p.effective.get('b'), Infinity);
  });
});

describe('isBreached / remaining', () => {
  it('isBreached is true when now >= deadline', () => {
    assert.equal(isBreached(1000, 1000), true);
    assert.equal(isBreached(1000, 1001), true);
    assert.equal(isBreached(1000, 999), false);
  });

  it('isBreached on Infinity is always false', () => {
    assert.equal(isBreached(Infinity, 1e15), false);
  });

  it('remaining is deadline - now', () => {
    assert.equal(remaining(2000, 500), 1500);
  });

  it('remaining is negative after breach', () => {
    assert.equal(remaining(1000, 1500), -500);
  });

  it('remaining is Infinity for unbounded', () => {
    assert.equal(remaining(Infinity, 1000), Infinity);
  });
});

describe('breachedNodes', () => {
  it('returns only the nodes whose effective deadline is reached', () => {
    const g = new Graph<DeadlinedNode>();
    g.addNode('a', node(1000)).addNode('b', node(2000));
    const p = propagate(g);
    assert.deepEqual(breachedNodes(p, 1500).sort(), ['a']);
    assert.deepEqual(breachedNodes(p, 2500).sort(), ['a', 'b']);
    assert.deepEqual(breachedNodes(p, 500), []);
  });
});

describe('resolve', () => {
  it('absolute returns at', () => {
    assert.equal(resolve({ kind: 'absolute', at: 5000 }, 1000), 5000);
  });

  it('relative adds to now', () => {
    assert.equal(resolve({ kind: 'relative', afterMs: 1500 }, 1000), 2500);
  });

  it('none returns Infinity', () => {
    assert.equal(resolve({ kind: 'none' }, 1000), Infinity);
  });
});
