// Health probes.
//
// A probe is a named function that returns a `ProbeResult`. The runner
// registers a fixed set at startup; operators can register their own.
// The aggregate health view is the worst-case across all probes.
//
// We support three states (healthy / degraded / unhealthy) rather than
// two because k8s-style readiness has cases where the runner is
// functional-but-degraded - the dlq is full, the outbox is backed up -
// and we want operators to see those as a yellow signal rather than a
// binary "is it up or not".

export type HealthStatus = 'healthy' | 'degraded' | 'unhealthy';

export interface ProbeResult {
  status: HealthStatus;
  // Free-form message describing the result. Goes into the JSON
  // response when the operator queries /health.
  message?: string;
  // Optional structured details. Useful for "the lease registry has
  // size N which is X% of the configured cap".
  details?: Record<string, unknown>;
  // The wall-clock time this probe was last evaluated. Set by the
  // runner, not by individual probes.
  evaluatedAt?: number;
}

export type Probe = () => ProbeResult | Promise<ProbeResult>;

export interface ProbeRegistration {
  name: string;
  probe: Probe;
  // How often to evaluate. Default: every 5 seconds.
  intervalMs: number;
  // If a probe takes longer than this, it's reported as unhealthy
  // with a timeout message.
  timeoutMs: number;
  // The latest result, populated by the registry on each evaluation.
  latest?: ProbeResult;
}

// Worst-case aggregation: unhealthy beats degraded beats healthy.
const STATUS_RANK: Record<HealthStatus, number> = {
  healthy: 0,
  degraded: 1,
  unhealthy: 2,
};

export function combine(statuses: HealthStatus[]): HealthStatus {
  let worst: HealthStatus = 'healthy';
  for (const s of statuses) {
    if (STATUS_RANK[s] > STATUS_RANK[worst]) worst = s;
  }
  return worst;
}

// Common probe builders. The runner uses these to register its standard
// set; user code can add custom ones.

export function thresholdProbe(opts: {
  read: () => number;
  warn: number;
  fail: number;
  message?: (v: number) => string;
}): Probe {
  return () => {
    const v = opts.read();
    if (v >= opts.fail) {
      return {
        status: 'unhealthy',
        message: opts.message ? opts.message(v) : `value ${v} >= fail threshold ${opts.fail}`,
        details: { value: v, threshold: opts.fail },
      };
    }
    if (v >= opts.warn) {
      return {
        status: 'degraded',
        message: opts.message ? opts.message(v) : `value ${v} >= warn threshold ${opts.warn}`,
        details: { value: v, threshold: opts.warn },
      };
    }
    return { status: 'healthy', details: { value: v } };
  };
}

export function alwaysHealthy(): Probe {
  return () => ({ status: 'healthy' });
}

export function alwaysUnhealthy(message: string): Probe {
  return () => ({ status: 'unhealthy', message });
}
