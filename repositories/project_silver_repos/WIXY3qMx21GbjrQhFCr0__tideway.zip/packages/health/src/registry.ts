// HealthRegistry: holds probes and runs them on a schedule.
//
// We implement the scheduling here rather than in the runner because
// having it next to the probes makes it easier to reason about ordering
// (the next-evaluation time is a property of each probe). The runner
// invokes `tick(now)` on its event loop.

import {
  combine,
  type HealthStatus,
  type Probe,
  type ProbeRegistration,
  type ProbeResult,
} from './probes.ts';

export interface AggregateHealth {
  status: HealthStatus;
  probes: Record<string, ProbeResult>;
  evaluatedAt: number;
}

export class HealthRegistry {
  private readonly probes = new Map<string, ProbeRegistration>();
  private readonly nextEvalAt = new Map<string, number>();
  private readonly clock: () => number;

  constructor(opts?: { clock?: () => number }) {
    this.clock = opts?.clock ?? Date.now;
  }

  register(name: string, probe: Probe, opts: { intervalMs?: number; timeoutMs?: number } = {}): void {
    if (this.probes.has(name)) {
      throw new Error(`probe already registered: ${name}`);
    }
    this.probes.set(name, {
      name,
      probe,
      intervalMs: opts.intervalMs ?? 5000,
      timeoutMs: opts.timeoutMs ?? 2000,
    });
    this.nextEvalAt.set(name, 0);
  }

  unregister(name: string): boolean {
    this.nextEvalAt.delete(name);
    return this.probes.delete(name);
  }

  has(name: string): boolean {
    return this.probes.has(name);
  }

  // Evaluate all probes that are due. Returns a fresh aggregate snapshot.
  async tick(): Promise<AggregateHealth> {
    const now = this.clock();
    const due: ProbeRegistration[] = [];
    for (const reg of this.probes.values()) {
      if ((this.nextEvalAt.get(reg.name) ?? 0) <= now) {
        due.push(reg);
      }
    }
    await Promise.all(
      due.map(async (reg) => {
        const result = await runWithTimeout(reg.probe, reg.timeoutMs);
        result.evaluatedAt = now;
        reg.latest = result;
        this.nextEvalAt.set(reg.name, now + reg.intervalMs);
      }),
    );
    return this.snapshot();
  }

  // Evaluate every probe right now, ignoring schedules. Used when the
  // operator hits /health/refresh.
  async forceTick(): Promise<AggregateHealth> {
    const now = this.clock();
    await Promise.all(
      Array.from(this.probes.values()).map(async (reg) => {
        const result = await runWithTimeout(reg.probe, reg.timeoutMs);
        result.evaluatedAt = now;
        reg.latest = result;
        this.nextEvalAt.set(reg.name, now + reg.intervalMs);
      }),
    );
    return this.snapshot();
  }

  // Return the latest aggregate without re-evaluating.
  snapshot(): AggregateHealth {
    const probes: Record<string, ProbeResult> = {};
    const statuses: HealthStatus[] = [];
    let latestEvaluated = 0;
    for (const reg of this.probes.values()) {
      if (reg.latest) {
        probes[reg.name] = reg.latest;
        statuses.push(reg.latest.status);
        if ((reg.latest.evaluatedAt ?? 0) > latestEvaluated) {
          latestEvaluated = reg.latest.evaluatedAt ?? 0;
        }
      } else {
        // Never evaluated. Treat as degraded with a "pending" message;
        // an unhealthy default would cause noisy alerts during startup.
        const pending: ProbeResult = { status: 'degraded', message: 'pending first evaluation' };
        probes[reg.name] = pending;
        statuses.push('degraded');
      }
    }
    return {
      status: combine(statuses),
      probes,
      evaluatedAt: latestEvaluated,
    };
  }

  size(): number {
    return this.probes.size;
  }
}

async function runWithTimeout(probe: Probe, timeoutMs: number): Promise<ProbeResult> {
  let timer: NodeJS.Timeout | undefined;
  try {
    const result = await Promise.race([
      Promise.resolve().then(() => probe()),
      new Promise<ProbeResult>((resolve) => {
        timer = setTimeout(() => {
          resolve({
            status: 'unhealthy',
            message: `probe timed out after ${timeoutMs}ms`,
          });
        }, timeoutMs);
      }),
    ]);
    return result;
  } catch (err) {
    return {
      status: 'unhealthy',
      message: err instanceof Error ? err.message : String(err),
    };
  } finally {
    if (timer) clearTimeout(timer);
  }
}
