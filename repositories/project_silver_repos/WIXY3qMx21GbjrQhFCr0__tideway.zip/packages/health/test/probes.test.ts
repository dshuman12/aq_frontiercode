import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { alwaysHealthy, alwaysUnhealthy, combine, thresholdProbe } from '../src/probes.ts';

describe('combine', () => {
  it('all healthy -> healthy', () => {
    assert.equal(combine(['healthy', 'healthy', 'healthy']), 'healthy');
  });

  it('any degraded -> degraded', () => {
    assert.equal(combine(['healthy', 'degraded', 'healthy']), 'degraded');
  });

  it('any unhealthy -> unhealthy', () => {
    assert.equal(combine(['degraded', 'unhealthy', 'healthy']), 'unhealthy');
  });

  it('empty -> healthy', () => {
    assert.equal(combine([]), 'healthy');
  });
});

describe('thresholdProbe', () => {
  it('healthy below warn', () => {
    let v = 5;
    const p = thresholdProbe({ read: () => v, warn: 10, fail: 20 });
    assert.equal(p().status, 'healthy');
    v = 9;
    assert.equal(p().status, 'healthy');
  });

  it('degraded between warn and fail', () => {
    let v = 10;
    const p = thresholdProbe({ read: () => v, warn: 10, fail: 20 });
    assert.equal(p().status, 'degraded');
    v = 15;
    assert.equal(p().status, 'degraded');
  });

  it('unhealthy at or above fail', () => {
    let v = 20;
    const p = thresholdProbe({ read: () => v, warn: 10, fail: 20 });
    assert.equal(p().status, 'unhealthy');
    v = 100;
    assert.equal(p().status, 'unhealthy');
  });

  it('details include value and threshold', () => {
    const p = thresholdProbe({ read: () => 15, warn: 10, fail: 20 });
    const r = p();
    if ('details' in r && r.details) {
      assert.equal(r.details.value, 15);
      assert.equal(r.details.threshold, 10);
    }
  });

  it('custom message function is called', () => {
    const p = thresholdProbe({
      read: () => 25,
      warn: 10,
      fail: 20,
      message: (v) => `outbox depth is ${v}`,
    });
    assert.equal(p().message, 'outbox depth is 25');
  });
});

describe('alwaysHealthy / alwaysUnhealthy', () => {
  it('alwaysHealthy returns healthy', () => {
    assert.equal(alwaysHealthy()().status, 'healthy');
  });

  it('alwaysUnhealthy carries the message', () => {
    const r = alwaysUnhealthy('on fire')();
    assert.equal(r.status, 'unhealthy');
    assert.equal(r.message, 'on fire');
  });
});
