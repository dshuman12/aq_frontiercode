import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { alwaysHealthy, alwaysUnhealthy } from '../src/probes.ts';
import { HealthRegistry } from '../src/registry.ts';

class FakeClock {
  constructor(public t = 0) {}
  now = () => this.t;
  advance(ms: number) {
    this.t += ms;
  }
}

describe('HealthRegistry', () => {
  it('starts empty', () => {
    const r = new HealthRegistry();
    assert.equal(r.size(), 0);
    const snap = r.snapshot();
    assert.equal(snap.status, 'healthy');
  });

  it('register adds a probe', () => {
    const r = new HealthRegistry();
    r.register('store', alwaysHealthy());
    assert.equal(r.has('store'), true);
    assert.equal(r.size(), 1);
  });

  it('register refuses duplicate name', () => {
    const r = new HealthRegistry();
    r.register('p', alwaysHealthy());
    assert.throws(() => r.register('p', alwaysHealthy()));
  });

  it('unregister removes', () => {
    const r = new HealthRegistry();
    r.register('p', alwaysHealthy());
    assert.equal(r.unregister('p'), true);
    assert.equal(r.has('p'), false);
  });

  it('snapshot before any tick has degraded probes', () => {
    const r = new HealthRegistry();
    r.register('p', alwaysHealthy());
    const snap = r.snapshot();
    assert.equal(snap.probes.p?.status, 'degraded');
    assert.match(snap.probes.p?.message ?? '', /pending/);
  });

  it('tick evaluates probes', async () => {
    const c = new FakeClock(1000);
    const r = new HealthRegistry({ clock: c.now });
    r.register('p', alwaysHealthy());
    const snap = await r.tick();
    assert.equal(snap.status, 'healthy');
    assert.equal(snap.probes.p?.status, 'healthy');
  });

  it('tick respects intervalMs', async () => {
    const c = new FakeClock(1000);
    const r = new HealthRegistry({ clock: c.now });
    let evaluations = 0;
    r.register('p', () => {
      evaluations += 1;
      return { status: 'healthy' };
    }, { intervalMs: 5000 });
    await r.tick();
    await r.tick();
    assert.equal(evaluations, 1);
    c.advance(6000);
    await r.tick();
    assert.equal(evaluations, 2);
  });

  it('forceTick re-evaluates regardless of schedule', async () => {
    const c = new FakeClock(1000);
    const r = new HealthRegistry({ clock: c.now });
    let evaluations = 0;
    r.register('p', () => {
      evaluations += 1;
      return { status: 'healthy' };
    }, { intervalMs: 60_000 });
    await r.tick();
    await r.forceTick();
    await r.forceTick();
    assert.equal(evaluations, 3);
  });

  it('aggregate is worst across probes', async () => {
    const r = new HealthRegistry();
    r.register('a', alwaysHealthy());
    r.register('b', alwaysUnhealthy('boom'));
    const snap = await r.tick();
    assert.equal(snap.status, 'unhealthy');
  });

  it('probe that throws is reported as unhealthy', async () => {
    const r = new HealthRegistry();
    r.register('p', () => {
      throw new Error('blew up');
    });
    const snap = await r.tick();
    assert.equal(snap.probes.p?.status, 'unhealthy');
    assert.match(snap.probes.p?.message ?? '', /blew up/);
  });

  it('probe that times out is reported as unhealthy', async () => {
    const r = new HealthRegistry();
    r.register('p', () => new Promise(() => {}), { timeoutMs: 10 });
    const snap = await r.tick();
    assert.equal(snap.probes.p?.status, 'unhealthy');
    assert.match(snap.probes.p?.message ?? '', /timed out/);
  });

  it('evaluatedAt is set on results', async () => {
    const c = new FakeClock(1234);
    const r = new HealthRegistry({ clock: c.now });
    r.register('p', alwaysHealthy());
    const snap = await r.tick();
    assert.equal(snap.probes.p?.evaluatedAt, 1234);
  });
});
