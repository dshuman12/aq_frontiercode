import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import type { LogEntry } from '@tideway/replay';
import { MemoryStore } from '../src/memory.ts';
import type { IdempotencyRecord, OutboxRecord } from '../src/types.ts';

const t = (n: number) => BigInt(n);

const created = (lsn: number, runId: string, at = 0): LogEntry => ({
  lsn,
  runId,
  kind: 'created',
  at: t(at),
});

describe('MemoryStore: log', () => {
  it('starts at hwm=0', () => {
    const s = new MemoryStore();
    assert.equal(s.highWater(), 0);
  });

  it('appendLog advances hwm', () => {
    const s = new MemoryStore();
    s.appendLog([created(1, 'r1'), created(2, 'r2')]);
    assert.equal(s.highWater(), 2);
  });

  it('readLog returns everything by default', () => {
    const s = new MemoryStore();
    s.appendLog([created(1, 'r1'), created(2, 'r2')]);
    const out = s.readLog();
    assert.equal(out.length, 2);
  });

  it('readLog with sinceLsn skips earlier entries', () => {
    const s = new MemoryStore();
    s.appendLog([created(1, 'r1'), created(2, 'r2'), created(3, 'r3')]);
    const out = s.readLog({ sinceLsn: 1 });
    assert.deepEqual(
      out.map((e) => e.runId),
      ['r2', 'r3'],
    );
  });

  it('readLog with runId filter returns only that runs entries', () => {
    const s = new MemoryStore();
    s.appendLog([created(1, 'r1'), created(2, 'r2'), created(3, 'r1')]);
    const out = s.readLog({ runId: 'r1' });
    assert.equal(out.length, 2);
  });

  it('readLog respects limit', () => {
    const s = new MemoryStore();
    for (let i = 1; i <= 10; i += 1) s.appendLog([created(i, `r${i}`)]);
    const out = s.readLog({ limit: 3 });
    assert.equal(out.length, 3);
  });
});

describe('MemoryStore: idempotency', () => {
  const rec = (overrides: Partial<IdempotencyRecord> = {}): IdempotencyRecord => ({
    handler: 'h',
    key: 'k',
    hash: 'abc',
    expiresAt: 1_000_000,
    status: 'inflight',
    ...overrides,
  });

  it('put + get round-trips', () => {
    const s = new MemoryStore();
    s.putIdempotency(rec());
    const out = s.getIdempotency('h', 'k');
    assert.equal(out?.handler, 'h');
    assert.equal(out?.status, 'inflight');
  });

  it('put with same handler+key overwrites', () => {
    const s = new MemoryStore();
    s.putIdempotency(rec({ status: 'inflight' }));
    s.putIdempotency(rec({ status: 'completed', resultJson: '"42"' }));
    const out = s.getIdempotency('h', 'k');
    assert.equal(out?.status, 'completed');
    assert.equal(out?.resultJson, '"42"');
  });

  it('different handler+key are independent', () => {
    const s = new MemoryStore();
    s.putIdempotency(rec({ handler: 'h1', key: 'k1' }));
    s.putIdempotency(rec({ handler: 'h2', key: 'k1' }));
    s.putIdempotency(rec({ handler: 'h1', key: 'k2' }));
    assert.ok(s.getIdempotency('h1', 'k1'));
    assert.ok(s.getIdempotency('h2', 'k1'));
    assert.ok(s.getIdempotency('h1', 'k2'));
    assert.equal(s.getIdempotency('h2', 'k2'), undefined);
  });

  it('delete removes', () => {
    const s = new MemoryStore();
    s.putIdempotency(rec());
    assert.equal(s.deleteIdempotency('h', 'k'), true);
    assert.equal(s.getIdempotency('h', 'k'), undefined);
  });

  it('delete on unknown returns false', () => {
    const s = new MemoryStore();
    assert.equal(s.deleteIdempotency('h', 'k'), false);
  });

  it('sweepIdempotency removes expired entries', () => {
    const s = new MemoryStore();
    s.putIdempotency(rec({ key: 'k1', expiresAt: 1000 }));
    s.putIdempotency(rec({ key: 'k2', expiresAt: 5000 }));
    const removed = s.sweepIdempotency(2000);
    assert.equal(removed, 1);
    assert.equal(s.getIdempotency('h', 'k1'), undefined);
    assert.ok(s.getIdempotency('h', 'k2'));
  });
});

describe('MemoryStore: outbox', () => {
  const ob = (overrides: Partial<OutboxRecord> = {}): OutboxRecord => ({
    id: 'm1',
    destination: 'wire:peer',
    bodyJson: '{}',
    partition: 'default',
    enqueuedAt: 0,
    attempts: 0,
    nextAttemptAt: 0,
    delivered: false,
    quarantined: false,
    ...overrides,
  });

  it('put + read round-trip', () => {
    const s = new MemoryStore();
    s.putOutbox(ob());
    const all = s.readOutbox();
    assert.equal(all.length, 1);
    assert.equal(all[0]!.id, 'm1');
  });

  it('readOutbox filter by delivered=false', () => {
    const s = new MemoryStore();
    s.putOutbox(ob({ id: 'a', delivered: false }));
    s.putOutbox(ob({ id: 'b', delivered: true }));
    const out = s.readOutbox({ delivered: false });
    assert.deepEqual(
      out.map((r) => r.id),
      ['a'],
    );
  });

  it('updateOutbox patches in place', () => {
    const s = new MemoryStore();
    s.putOutbox(ob());
    assert.equal(s.updateOutbox('m1', { delivered: true, attempts: 3 }), true);
    const out = s.readOutbox()[0];
    assert.equal(out!.delivered, true);
    assert.equal(out!.attempts, 3);
  });

  it('updateOutbox on unknown returns false', () => {
    const s = new MemoryStore();
    assert.equal(s.updateOutbox('ghost', { delivered: true }), false);
  });

  it('deleteOutbox removes', () => {
    const s = new MemoryStore();
    s.putOutbox(ob());
    assert.equal(s.deleteOutbox('m1'), true);
    assert.equal(s.readOutbox().length, 0);
  });

  it('readOutbox honors limit', () => {
    const s = new MemoryStore();
    for (let i = 0; i < 5; i += 1) s.putOutbox(ob({ id: `m${i}` }));
    assert.equal(s.readOutbox({ limit: 2 }).length, 2);
  });
});

describe('MemoryStore: close is a no-op', () => {
  it('does not throw', () => {
    const s = new MemoryStore();
    s.close();
    s.close();
  });
});
