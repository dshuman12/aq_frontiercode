import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { migrationVersions, runMigrations } from '../src/migrations.ts';

// Minimal in-memory fake of the better-sqlite3 surface, just enough to
// exercise the migration runner. We're not testing SQL semantics here;
// that's covered separately when better-sqlite3 is available.
class FakeDb {
  schemaMigrations: Array<{ version: number; description: string; applied_at: number }> = [];
  execed: string[] = [];

  prepare(sql: string) {
    return {
      run: (...params: unknown[]) => {
        if (sql.includes('INTO schema_migrations')) {
          this.schemaMigrations.push({
            version: params[0] as number,
            description: params[1] as string,
            applied_at: params[2] as number,
          });
        }
        return { lastInsertRowid: 0, changes: 1 };
      },
      get: () => {
        if (sql.includes('MAX(version)')) {
          const max =
            this.schemaMigrations.length === 0
              ? 0
              : this.schemaMigrations.reduce((m, r) => Math.max(m, r.version), 0);
          return { v: max };
        }
        return undefined;
      },
      all: () => this.schemaMigrations.slice(),
    };
  }

  exec(sql: string) {
    this.execed.push(sql);
  }

  transaction<T>(fn: () => T): () => T {
    return fn;
  }
}

describe('migrationVersions', () => {
  it('returns the list of known versions in order', () => {
    const versions = migrationVersions();
    assert.deepEqual(versions, [...versions].sort((a, b) => a - b));
    assert.ok(versions.length > 0);
  });
});

describe('runMigrations on a fresh database', () => {
  it('applies every migration', () => {
    const db = new FakeDb();
    const result = runMigrations(db);
    assert.deepEqual(result.applied, migrationVersions());
    assert.equal(result.head, migrationVersions()[migrationVersions().length - 1]);
  });

  it('records each migration in schema_migrations', () => {
    const db = new FakeDb();
    runMigrations(db);
    assert.equal(db.schemaMigrations.length, migrationVersions().length);
  });
});

describe('runMigrations is idempotent on a current database', () => {
  it('applies nothing on second run', () => {
    const db = new FakeDb();
    runMigrations(db);
    const second = runMigrations(db);
    assert.deepEqual(second.applied, []);
  });
});
