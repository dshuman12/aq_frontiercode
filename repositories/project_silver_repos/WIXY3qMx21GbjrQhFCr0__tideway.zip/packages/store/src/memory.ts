// In-memory store. Useful for tests and ephemeral workflows that don't
// need crash recovery. Implements the same interface as the sqlite store,
// so all calling code is portable.

import type { LogEntry, LSN, RunId } from '@tideway/replay';
import type { IdempotencyRecord, OutboxRecord, Store } from './types.ts';

export class MemoryStore implements Store {
  private readonly log: LogEntry[] = [];
  private readonly idempotency = new Map<string, IdempotencyRecord>();
  private readonly outbox = new Map<string, OutboxRecord>();
  private hwm: LSN = 0;

  appendLog(entries: LogEntry[]): LSN {
    for (const entry of entries) {
      this.log.push(entry);
      if (entry.lsn > this.hwm) this.hwm = entry.lsn;
    }
    return this.hwm;
  }

  readLog(opts?: { sinceLsn?: LSN; runId?: RunId; limit?: number }): LogEntry[] {
    const since = opts?.sinceLsn ?? -1;
    const limit = opts?.limit ?? Infinity;
    const out: LogEntry[] = [];
    for (const entry of this.log) {
      if (entry.lsn <= since) continue;
      if (opts?.runId !== undefined && entry.runId !== opts.runId) continue;
      out.push(entry);
      if (out.length >= limit) break;
    }
    return out;
  }

  highWater(): LSN {
    return this.hwm;
  }

  putIdempotency(record: IdempotencyRecord): void {
    this.idempotency.set(idempotencyKey(record.handler, record.key), record);
  }

  getIdempotency(handler: string, key: string): IdempotencyRecord | undefined {
    return this.idempotency.get(idempotencyKey(handler, key));
  }

  deleteIdempotency(handler: string, key: string): boolean {
    return this.idempotency.delete(idempotencyKey(handler, key));
  }

  sweepIdempotency(now: number): number {
    let removed = 0;
    for (const [k, v] of this.idempotency) {
      if (v.expiresAt <= now) {
        this.idempotency.delete(k);
        removed += 1;
      }
    }
    return removed;
  }

  putOutbox(record: OutboxRecord): void {
    this.outbox.set(record.id, { ...record });
  }

  updateOutbox(id: string, patch: Partial<OutboxRecord>): boolean {
    const existing = this.outbox.get(id);
    if (!existing) return false;
    this.outbox.set(id, { ...existing, ...patch });
    return true;
  }

  readOutbox(opts?: { delivered?: boolean; quarantined?: boolean; limit?: number }): OutboxRecord[] {
    const limit = opts?.limit ?? Infinity;
    const out: OutboxRecord[] = [];
    for (const r of this.outbox.values()) {
      if (opts?.delivered !== undefined && r.delivered !== opts.delivered) continue;
      if (opts?.quarantined !== undefined && r.quarantined !== opts.quarantined) continue;
      out.push(r);
      if (out.length >= limit) break;
    }
    return out;
  }

  deleteOutbox(id: string): boolean {
    return this.outbox.delete(id);
  }

  close(): void {
    // Nothing to do.
  }
}

function idempotencyKey(handler: string, key: string): string {
  return `${handler} ${key}`;
}
