// Storage interface.
//
// The store has three jobs:
//
//   1. Append events to a per-run log with monotonic LSN. The runner
//      reads this log on startup to rebuild in-memory state via
//      @tideway/replay.
//
//   2. Persist outbox messages so that a crash mid-flush doesn't drop
//      side-effects.
//
//   3. Persist idempotency-registry entries so that the (handler, key)
//      dedup window survives restarts.
//
// We define an abstract interface here so we can have both an in-memory
// implementation (for tests + ephemeral workflows) and a SQLite-backed
// one (for production). The SQLite version is in sqlite.ts; it depends
// on `better-sqlite3` which is an optional dependency. If the native
// module isn't built (e.g. in CI environments without a C++ toolchain),
// the in-memory store is the fallback.
//
// One thing to note about the interface design: there's no separate
// transaction object. Each method either commits in full or throws. The
// SQLite implementation wraps each method body in a transaction
// internally. This is simpler than the alternative (handing out a `Tx`
// object) at the cost of some flexibility, but in this codebase nothing
// straddles a transaction boundary so we don't need that flexibility.

import type { LogEntry, LSN, RunId } from '@tideway/replay';

export interface IdempotencyRecord {
  handler: string;
  key: string;
  hash: string;
  expiresAt: number;
  status: 'inflight' | 'completed' | 'failed';
  resultJson?: string;
  failureMessage?: string;
  failureKind?: string;
  ownerRunId?: string;
}

export interface OutboxRecord {
  id: string;
  destination: string;
  bodyJson: string;
  partition: string;
  enqueuedAt: number;
  attempts: number;
  nextAttemptAt: number;
  delivered: boolean;
  quarantined: boolean;
}

export interface Store {
  // --- event log
  appendLog(entries: LogEntry[]): LSN; // returns the new high-water mark
  readLog(opts?: { sinceLsn?: LSN; runId?: RunId; limit?: number }): LogEntry[];
  highWater(): LSN;

  // --- idempotency
  putIdempotency(record: IdempotencyRecord): void;
  getIdempotency(handler: string, key: string): IdempotencyRecord | undefined;
  deleteIdempotency(handler: string, key: string): boolean;
  sweepIdempotency(now: number): number;

  // --- outbox
  putOutbox(record: OutboxRecord): void;
  updateOutbox(id: string, patch: Partial<OutboxRecord>): boolean;
  readOutbox(opts?: { delivered?: boolean; quarantined?: boolean; limit?: number }): OutboxRecord[];
  deleteOutbox(id: string): boolean;

  // --- lifecycle
  close(): void;
}
