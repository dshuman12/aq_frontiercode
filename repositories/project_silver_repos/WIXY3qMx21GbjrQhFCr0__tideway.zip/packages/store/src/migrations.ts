// Database migrations.
//
// Migrations are forward-only and tracked in a `schema_migrations` table.
// On startup, we read the current version and apply any newer migrations
// in order. This is deliberately less elaborate than a tool like knex's
// migrations - we don't have rollback, parameterized arguments, or
// staging environments. For a single-process workflow runtime that's
// fine; the migrations themselves are short and self-contained.

interface DbHandle {
  prepare(sql: string): {
    run(...params: unknown[]): { lastInsertRowid: number | bigint; changes: number };
    get(...params: unknown[]): unknown;
    all(...params: unknown[]): unknown[];
  };
  exec(sql: string): void;
  transaction<T>(fn: () => T): () => T;
}

interface Migration {
  version: number;
  description: string;
  apply: (db: DbHandle) => void;
}

const MIGRATIONS: Migration[] = [
  {
    version: 1,
    description: 'initial schema',
    apply: (db) => {
      db.exec(`
        CREATE TABLE IF NOT EXISTS schema_migrations (
          version INTEGER PRIMARY KEY,
          description TEXT NOT NULL,
          applied_at INTEGER NOT NULL
        );

        CREATE TABLE IF NOT EXISTS event_log (
          lsn INTEGER PRIMARY KEY,
          run_id TEXT NOT NULL,
          kind TEXT NOT NULL,
          payload_json TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS event_log_run_idx ON event_log(run_id, lsn);

        CREATE TABLE IF NOT EXISTS idempotency (
          handler TEXT NOT NULL,
          key TEXT NOT NULL,
          hash TEXT NOT NULL,
          expires_at INTEGER NOT NULL,
          status TEXT NOT NULL,
          result_json TEXT,
          failure_message TEXT,
          failure_kind TEXT,
          owner_run_id TEXT,
          PRIMARY KEY (handler, key)
        );
        CREATE INDEX IF NOT EXISTS idempotency_expiry_idx ON idempotency(expires_at);

        CREATE TABLE IF NOT EXISTS outbox (
          id TEXT PRIMARY KEY,
          destination TEXT NOT NULL,
          body_json TEXT NOT NULL,
          partition TEXT NOT NULL,
          enqueued_at INTEGER NOT NULL,
          attempts INTEGER NOT NULL DEFAULT 0,
          next_attempt_at INTEGER NOT NULL DEFAULT 0,
          delivered INTEGER NOT NULL DEFAULT 0,
          quarantined INTEGER NOT NULL DEFAULT 0
        );
        CREATE INDEX IF NOT EXISTS outbox_due_idx ON outbox(delivered, quarantined, next_attempt_at);
      `);
    },
  },
  {
    version: 2,
    description: 'add event_log timestamp for diagnostics',
    apply: (db) => {
      // SQLite supports adding a column with a default. We backfill via
      // the column default since older rows have no recorded timestamp.
      db.exec(
        `ALTER TABLE event_log ADD COLUMN written_at INTEGER NOT NULL DEFAULT 0`,
      );
    },
  },
];

export function runMigrations(db: DbHandle): { applied: number[]; head: number } {
  // Bootstrap: schema_migrations may not exist yet on a fresh db.
  db.exec(`CREATE TABLE IF NOT EXISTS schema_migrations (
    version INTEGER PRIMARY KEY,
    description TEXT NOT NULL,
    applied_at INTEGER NOT NULL
  )`);

  const current = (db.prepare(`SELECT COALESCE(MAX(version), 0) AS v FROM schema_migrations`).get() as
    | { v: number }
    | undefined) ?? { v: 0 };
  const applied: number[] = [];
  const insertVersion = db.prepare(
    `INSERT INTO schema_migrations (version, description, applied_at) VALUES (?, ?, ?)`,
  );

  for (const m of MIGRATIONS) {
    if (m.version <= current.v) continue;
    const tx = db.transaction(() => {
      m.apply(db);
      insertVersion.run(m.version, m.description, Date.now());
    });
    tx();
    applied.push(m.version);
  }

  return { applied, head: MIGRATIONS[MIGRATIONS.length - 1]?.version ?? 0 };
}

export function migrationVersions(): number[] {
  return MIGRATIONS.map((m) => m.version);
}
