// SQLite-backed store using better-sqlite3.
//
// `better-sqlite3` is a synchronous binding, which is what we want here:
// the runner is single-threaded deliberately, and giving it a synchronous
// store means we never accidentally introduce a write-after-write race
// through interleaved promises. The performance penalty is tolerable
// because SQLite, when run in WAL mode with a per-process database, is
// extremely fast for the kind of small writes the runner emits.
//
// This file is gated by an optional dependency: better-sqlite3 may or
// may not be installed (it's a native module that requires a C++
// compiler at install time, which not every environment has). The
// `createSqliteStore` factory loads the dep dynamically so a missing
// install fails loudly at construction time rather than at module-eval
// time.

import { runMigrations } from './migrations.ts';
import type { LogEntry, LSN, RunId } from '@tideway/replay';
import type { IdempotencyRecord, OutboxRecord, Store } from './types.ts';

// Minimal type for the better-sqlite3 Database surface we use.  We
// don't import the package's type directly so that consumers without
// the package installed can still typecheck.
interface BSqlite {
  prepare(sql: string): {
    run(...params: unknown[]): { lastInsertRowid: number | bigint; changes: number };
    get(...params: unknown[]): unknown;
    all(...params: unknown[]): unknown[];
  };
  exec(sql: string): void;
  close(): void;
  pragma(s: string): unknown;
  transaction<T>(fn: (...args: unknown[]) => T): (...args: unknown[]) => T;
}

export interface SqliteOptions {
  // Path to the database file. ":memory:" is allowed and gives an
  // ephemeral in-process db; useful for integration tests.
  path: string;
  // Override the WAL pragma. Defaults to true. Disabling is for tests
  // running against in-memory dbs where WAL is unsupported.
  walMode?: boolean;
}

export async function createSqliteStore(opts: SqliteOptions): Promise<Store> {
  // Dynamic import so that environments without better-sqlite3 don't
  // explode at module load.
  let Database: { new (path: string): BSqlite };
  try {
    // Use string concatenation to avoid TypeScript trying to resolve
    // the module at compile time. The native module isn't always
    // present and we want this code to typecheck regardless.
    const moduleName = 'better-' + 'sqlite3';
    const mod = (await import(moduleName)) as unknown as { default: { new (path: string): BSqlite } };
    Database = mod.default;
  } catch (err) {
    throw new Error(
      `failed to load better-sqlite3: ${(err as Error).message}. ` +
        'Install it as a runtime dependency or use MemoryStore instead.',
    );
  }
  const db = new Database(opts.path);
  if (opts.path !== ':memory:' && opts.walMode !== false) {
    db.pragma('journal_mode = WAL');
  }
  db.pragma('synchronous = NORMAL');
  db.pragma('foreign_keys = ON');
  runMigrations(db);
  return new SqliteStore(db);
}

class SqliteStore implements Store {
  private readonly insertLog;
  private readonly selectLogSince;
  private readonly selectLogByRun;
  private readonly maxLsn;

  private readonly upsertIdempotency;
  private readonly selectIdempotency;
  private readonly deleteIdempotency_;
  private readonly sweepIdempotency_;

  private readonly upsertOutbox;
  private readonly selectOutboxAll;
  private readonly selectOutboxByFlags;
  private readonly deleteOutbox_;

  constructor(private readonly db: BSqlite) {
    this.insertLog = db.prepare(
      `INSERT INTO event_log (lsn, run_id, kind, payload_json) VALUES (?, ?, ?, ?)`,
    );
    this.selectLogSince = db.prepare(
      `SELECT lsn, run_id AS runId, kind, payload_json AS payloadJson
       FROM event_log WHERE lsn > ? ORDER BY lsn ASC LIMIT ?`,
    );
    this.selectLogByRun = db.prepare(
      `SELECT lsn, run_id AS runId, kind, payload_json AS payloadJson
       FROM event_log WHERE run_id = ? AND lsn > ? ORDER BY lsn ASC LIMIT ?`,
    );
    this.maxLsn = db.prepare(`SELECT COALESCE(MAX(lsn), 0) AS hwm FROM event_log`);

    this.upsertIdempotency = db.prepare(
      `INSERT INTO idempotency (handler, key, hash, expires_at, status, result_json,
                                failure_message, failure_kind, owner_run_id)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(handler, key) DO UPDATE SET
         hash = excluded.hash,
         expires_at = excluded.expires_at,
         status = excluded.status,
         result_json = excluded.result_json,
         failure_message = excluded.failure_message,
         failure_kind = excluded.failure_kind,
         owner_run_id = excluded.owner_run_id`,
    );
    this.selectIdempotency = db.prepare(
      `SELECT handler, key, hash, expires_at AS expiresAt, status,
              result_json AS resultJson, failure_message AS failureMessage,
              failure_kind AS failureKind, owner_run_id AS ownerRunId
       FROM idempotency WHERE handler = ? AND key = ?`,
    );
    this.deleteIdempotency_ = db.prepare(
      `DELETE FROM idempotency WHERE handler = ? AND key = ?`,
    );
    this.sweepIdempotency_ = db.prepare(`DELETE FROM idempotency WHERE expires_at <= ?`);

    this.upsertOutbox = db.prepare(
      `INSERT INTO outbox (id, destination, body_json, partition, enqueued_at,
                          attempts, next_attempt_at, delivered, quarantined)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(id) DO UPDATE SET
         destination = excluded.destination,
         body_json = excluded.body_json,
         partition = excluded.partition,
         enqueued_at = excluded.enqueued_at,
         attempts = excluded.attempts,
         next_attempt_at = excluded.next_attempt_at,
         delivered = excluded.delivered,
         quarantined = excluded.quarantined`,
    );
    this.selectOutboxAll = db.prepare(
      `SELECT id, destination, body_json AS bodyJson, partition,
              enqueued_at AS enqueuedAt, attempts, next_attempt_at AS nextAttemptAt,
              delivered, quarantined FROM outbox LIMIT ?`,
    );
    this.selectOutboxByFlags = db.prepare(
      `SELECT id, destination, body_json AS bodyJson, partition,
              enqueued_at AS enqueuedAt, attempts, next_attempt_at AS nextAttemptAt,
              delivered, quarantined FROM outbox
       WHERE delivered = ? AND quarantined = ? LIMIT ?`,
    );
    this.deleteOutbox_ = db.prepare(`DELETE FROM outbox WHERE id = ?`);
  }

  appendLog(entries: LogEntry[]): LSN {
    const tx = this.db.transaction(() => {
      for (const entry of entries) {
        const kind = 'kind' in entry && entry.kind === 'created' ? 'created' : 'event';
        this.insertLog.run(entry.lsn, entry.runId, kind, JSON.stringify(entry, replaceBigInt));
      }
    });
    tx();
    return this.highWater();
  }

  readLog(opts?: { sinceLsn?: LSN; runId?: RunId; limit?: number }): LogEntry[] {
    const since = opts?.sinceLsn ?? 0;
    const limit = opts?.limit ?? 10_000;
    const rows = (opts?.runId !== undefined
      ? this.selectLogByRun.all(opts.runId, since, limit)
      : this.selectLogSince.all(since, limit)) as Array<{ payloadJson: string }>;
    return rows.map((r) => JSON.parse(r.payloadJson, reviveBigInt) as LogEntry);
  }

  highWater(): LSN {
    return ((this.maxLsn.get() as { hwm: number }) ?? { hwm: 0 }).hwm;
  }

  putIdempotency(record: IdempotencyRecord): void {
    this.upsertIdempotency.run(
      record.handler,
      record.key,
      record.hash,
      record.expiresAt,
      record.status,
      record.resultJson ?? null,
      record.failureMessage ?? null,
      record.failureKind ?? null,
      record.ownerRunId ?? null,
    );
  }

  getIdempotency(handler: string, key: string): IdempotencyRecord | undefined {
    const row = this.selectIdempotency.get(handler, key) as IdempotencyRecord | undefined;
    return row;
  }

  deleteIdempotency(handler: string, key: string): boolean {
    return this.deleteIdempotency_.run(handler, key).changes > 0;
  }

  sweepIdempotency(now: number): number {
    return Number(this.sweepIdempotency_.run(now).changes);
  }

  putOutbox(record: OutboxRecord): void {
    this.upsertOutbox.run(
      record.id,
      record.destination,
      record.bodyJson,
      record.partition,
      record.enqueuedAt,
      record.attempts,
      record.nextAttemptAt,
      record.delivered ? 1 : 0,
      record.quarantined ? 1 : 0,
    );
  }

  updateOutbox(id: string, patch: Partial<OutboxRecord>): boolean {
    // Implemented as a read+merge+upsert to keep the schema-coupled
    // statement count low. Callers who need atomic field-level updates
    // can do so via a custom prepared statement; we don't need it.
    const existing = this.selectOutboxAll.all(1) as OutboxRecord[];
    const target = existing.find((e) => e.id === id);
    if (!target) {
      // Slow path: the row may exist but not in the first batch.  We
      // re-query specifically for it.
      const allRows = this.db.prepare(`SELECT id FROM outbox WHERE id = ?`).get(id);
      if (!allRows) return false;
    }
    // Fall back to a straight upsert with the patched record.
    const fullRow = this.db
      .prepare(
        `SELECT id, destination, body_json AS bodyJson, partition,
                enqueued_at AS enqueuedAt, attempts, next_attempt_at AS nextAttemptAt,
                delivered, quarantined FROM outbox WHERE id = ?`,
      )
      .get(id) as OutboxRecord | undefined;
    if (!fullRow) return false;
    const merged: OutboxRecord = {
      ...fullRow,
      delivered: !!fullRow.delivered,
      quarantined: !!fullRow.quarantined,
      ...patch,
    };
    this.putOutbox(merged);
    return true;
  }

  readOutbox(opts?: { delivered?: boolean; quarantined?: boolean; limit?: number }): OutboxRecord[] {
    const limit = opts?.limit ?? 10_000;
    if (opts?.delivered === undefined && opts?.quarantined === undefined) {
      return (this.selectOutboxAll.all(limit) as OutboxRecord[]).map(normalizeBoolFields);
    }
    return (
      this.selectOutboxByFlags.all(
        opts.delivered ? 1 : 0,
        opts.quarantined ? 1 : 0,
        limit,
      ) as OutboxRecord[]
    ).map(normalizeBoolFields);
  }

  deleteOutbox(id: string): boolean {
    return this.deleteOutbox_.run(id).changes > 0;
  }

  close(): void {
    this.db.close();
  }
}

function normalizeBoolFields(r: OutboxRecord): OutboxRecord {
  return { ...r, delivered: !!r.delivered, quarantined: !!r.quarantined };
}

function replaceBigInt(_key: string, value: unknown): unknown {
  if (typeof value === 'bigint') return `${value.toString()}n`;
  return value;
}

function reviveBigInt(_key: string, value: unknown): unknown {
  if (typeof value === 'string' && /^-?\d+n$/.test(value)) {
    return BigInt(value.slice(0, -1));
  }
  return value;
}
