// Worker leasing.
//
// A worker that picks up a job acquires a lease (TTL ~30s) which it
// heartbeats every 10s. If the worker dies, the lease expires and the
// reaper sweep makes the job available to other workers. The lease is
// the unit of "I have this job and I'm working on it"; without leases we
// either need a global lock (kills concurrency) or accept double-runs.
//
// Why not just use a database row lock? Two reasons:
//
//   1. SQLite, our store, doesn't have row-level locks - just db-level
//      ones. We'd serialize all worker operations.
//
//   2. Even with a real RDBMS, "I'm holding a lock" survives only as long
//      as the connection. A worker on a flaky network can hold a lock,
//      get partitioned, and the reaper would take 30+ seconds to detect
//      it via TCP keepalive. A TTL-based lease is observable purely from
//      the store side without trusting connection state.
//
// The lease registry below is in-memory. The runner mirrors it to the
// store on every acquire/heartbeat/release; on crash recovery the runner
// rebuilds the in-memory registry from the store. So the leasing package
// itself doesn't need to know about persistence.

export type LeaseId = string;
export type RunId = string;
export type WorkerId = string;

export interface Lease {
  id: LeaseId;
  runId: RunId;
  workerId: WorkerId;
  acquiredAt: number; // ms since epoch
  expiresAt: number;
}

export class LeaseRegistry {
  // Indexed both ways. Lookups by runId are by far the most common
  // (acquire and reaper-sweep both want "is this run held? by whom?"),
  // and lookups by leaseId happen for heartbeat/release calls.
  private readonly byRun = new Map<RunId, Lease>();
  private readonly byLease = new Map<LeaseId, Lease>();

  // Time-source injection. Defaults to Date.now. Tests pass a fake clock.
  private readonly clock: () => number;

  constructor(opts?: { clock?: () => number }) {
    this.clock = opts?.clock ?? Date.now;
  }

  // Try to acquire a lease for `runId`. Fails (returns null) if there's
  // already a non-expired lease on it. The TTL defaults to 30 seconds; the
  // runner overrides per-job-type as needed.
  acquire(runId: RunId, workerId: WorkerId, opts?: { ttlMs?: number; leaseId?: LeaseId }): Lease | null {
    const now = this.clock();
    const ttl = opts?.ttlMs ?? 30_000;

    const existing = this.byRun.get(runId);
    if (existing && existing.expiresAt > now) {
      return null;
    }
    // If an expired lease is in the way, sweep it now so the new lease
    // doesn't have a phantom predecessor.
    //
    // FIXME: clock-skew edge case. If `now` jumps backward relative to a
    // recently-set expiresAt, we'll think the lease is still alive when
    // the wall clock has actually passed it. Mitigated by the runner
    // calling sweepExpired periodically with a stable monotonic clock,
    // but not eliminated. See also CHANGELOG 0.3.0 known issue.
    if (existing) {
      this.byRun.delete(runId);
      this.byLease.delete(existing.id);
    }

    const lease: Lease = {
      id: opts?.leaseId ?? randomId(),
      runId,
      workerId,
      acquiredAt: now,
      expiresAt: now + ttl,
    };
    this.byRun.set(runId, lease);
    this.byLease.set(lease.id, lease);
    return lease;
  }

  // Extend an existing lease. Fails if the lease isn't held or has already
  // expired. The caller is responsible for catching this and reacquiring
  // (typically via the reaper path).
  heartbeat(leaseId: LeaseId, opts?: { ttlMs?: number }): Lease | null {
    const now = this.clock();
    const ttl = opts?.ttlMs ?? 30_000;
    const lease = this.byLease.get(leaseId);
    if (!lease) return null;
    if (lease.expiresAt <= now) {
      // Expired in the meantime. Sweep it on the way out so that the
      // caller gets a definitive "no" rather than thinking they have
      // something they don't.
      this.byLease.delete(leaseId);
      this.byRun.delete(lease.runId);
      return null;
    }
    lease.expiresAt = now + ttl;
    return lease;
  }

  // Release a lease cleanly. Returns true if a lease was released; false
  // if there was nothing to release.
  release(leaseId: LeaseId): boolean {
    const lease = this.byLease.get(leaseId);
    if (!lease) return false;
    this.byLease.delete(leaseId);
    this.byRun.delete(lease.runId);
    return true;
  }

  // Returns the current lease for `runId`, or null. Does not check
  // expiry; callers that care about freshness should compare expiresAt
  // against the clock themselves. The reaper actively wants to see
  // expired leases, so the no-expiry-check behavior is deliberate.
  getByRun(runId: RunId): Lease | null {
    return this.byRun.get(runId) ?? null;
  }

  getByLease(leaseId: LeaseId): Lease | null {
    return this.byLease.get(leaseId) ?? null;
  }

  // Sweep expired leases. Returns the list of swept leases so the caller
  // can flip the corresponding RunStates from 'running' back to 'queued'.
  sweepExpired(): Lease[] {
    const now = this.clock();
    const swept: Lease[] = [];
    for (const lease of this.byLease.values()) {
      if (lease.expiresAt <= now) swept.push(lease);
    }
    for (const lease of swept) {
      this.byLease.delete(lease.id);
      this.byRun.delete(lease.runId);
    }
    return swept;
  }

  size(): number {
    return this.byRun.size;
  }

  // Snapshot for diagnostics. Order is insertion-stable since we use a
  // Map underneath.
  list(): Lease[] {
    return Array.from(this.byLease.values());
  }
}

// Local id generator. Not cryptographically random; fine for
// process-local lease ids that don't leak. We do NOT use Math.random as
// the only entropy because in our test suite we replace the clock and
// then notice every random id collides; the high-resolution timer breaks
// that tie.
function randomId(): string {
  const ts = (typeof performance !== 'undefined' ? performance.now() : Date.now()).toString(36);
  const r = Math.random().toString(36).slice(2, 10);
  return `lease-${ts.replace('.', '')}-${r}`;
}
