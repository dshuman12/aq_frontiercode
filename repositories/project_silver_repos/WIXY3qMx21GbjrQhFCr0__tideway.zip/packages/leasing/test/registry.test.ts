import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { LeaseRegistry } from '../src/index.ts';

class FakeClock {
  constructor(public t = 0) {}
  now = (): number => this.t;
  advance(ms: number) {
    this.t += ms;
  }
}

describe('acquire', () => {
  it('grants a lease when nothing is held', () => {
    const c = new FakeClock(1000);
    const r = new LeaseRegistry({ clock: c.now });
    const lease = r.acquire('run-1', 'worker-A');
    assert.ok(lease);
    assert.equal(lease!.runId, 'run-1');
    assert.equal(lease!.workerId, 'worker-A');
    assert.equal(lease!.acquiredAt, 1000);
    assert.equal(lease!.expiresAt, 31_000);
  });

  it('refuses if a non-expired lease is held', () => {
    const c = new FakeClock(1000);
    const r = new LeaseRegistry({ clock: c.now });
    r.acquire('run-1', 'worker-A');
    const second = r.acquire('run-1', 'worker-B');
    assert.equal(second, null);
  });

  it('grants if the prior lease has expired', () => {
    const c = new FakeClock(1000);
    const r = new LeaseRegistry({ clock: c.now });
    r.acquire('run-1', 'worker-A', { ttlMs: 5000 });
    c.advance(6000);
    const second = r.acquire('run-1', 'worker-B');
    assert.ok(second);
    assert.equal(second!.workerId, 'worker-B');
  });

  it('honors a custom TTL', () => {
    const c = new FakeClock(0);
    const r = new LeaseRegistry({ clock: c.now });
    const lease = r.acquire('run-1', 'w', { ttlMs: 1500 });
    assert.equal(lease!.expiresAt, 1500);
  });

  it('honors a caller-supplied leaseId', () => {
    const c = new FakeClock(0);
    const r = new LeaseRegistry({ clock: c.now });
    const lease = r.acquire('run-1', 'w', { leaseId: 'fixed-id' });
    assert.equal(lease!.id, 'fixed-id');
  });

  it('size grows with each fresh lease', () => {
    const c = new FakeClock(0);
    const r = new LeaseRegistry({ clock: c.now });
    r.acquire('r1', 'w');
    r.acquire('r2', 'w');
    r.acquire('r3', 'w');
    assert.equal(r.size(), 3);
  });
});

describe('heartbeat', () => {
  it('extends the expiry by ttl from now', () => {
    const c = new FakeClock(1000);
    const r = new LeaseRegistry({ clock: c.now });
    const lease = r.acquire('r1', 'w', { ttlMs: 5000 })!;
    c.advance(2000);
    const extended = r.heartbeat(lease.id, { ttlMs: 5000 });
    assert.ok(extended);
    assert.equal(extended!.expiresAt, 8000);
  });

  it('refuses to extend an unknown leaseId', () => {
    const c = new FakeClock(1000);
    const r = new LeaseRegistry({ clock: c.now });
    assert.equal(r.heartbeat('not-a-real-id'), null);
  });

  it('refuses to extend an already-expired lease and sweeps it', () => {
    const c = new FakeClock(0);
    const r = new LeaseRegistry({ clock: c.now });
    const lease = r.acquire('r1', 'w', { ttlMs: 1000 })!;
    c.advance(1500);
    assert.equal(r.heartbeat(lease.id), null);
    // After the failed heartbeat, the lease must be gone, otherwise a
    // re-acquire would find a stale entry.
    assert.equal(r.getByLease(lease.id), null);
    assert.equal(r.getByRun('r1'), null);
  });
});

describe('release', () => {
  it('releases a held lease', () => {
    const c = new FakeClock(0);
    const r = new LeaseRegistry({ clock: c.now });
    const lease = r.acquire('r1', 'w')!;
    assert.equal(r.release(lease.id), true);
    assert.equal(r.getByRun('r1'), null);
  });

  it('release on unknown id returns false', () => {
    const r = new LeaseRegistry();
    assert.equal(r.release('ghost'), false);
  });

  it('release frees the slot for re-acquire', () => {
    const c = new FakeClock(0);
    const r = new LeaseRegistry({ clock: c.now });
    const a = r.acquire('r1', 'w-a')!;
    r.release(a.id);
    const b = r.acquire('r1', 'w-b');
    assert.ok(b);
    assert.equal(b!.workerId, 'w-b');
  });
});

describe('sweepExpired', () => {
  it('returns and removes only the expired leases', () => {
    const c = new FakeClock(0);
    const r = new LeaseRegistry({ clock: c.now });
    r.acquire('r1', 'w', { ttlMs: 1000 });
    r.acquire('r2', 'w', { ttlMs: 5000 });
    c.advance(2000);
    const swept = r.sweepExpired();
    assert.equal(swept.length, 1);
    assert.equal(swept[0]!.runId, 'r1');
    assert.equal(r.getByRun('r2'), null === null ? r.getByRun('r2') : null);
    assert.ok(r.getByRun('r2'));
    assert.equal(r.getByRun('r1'), null);
  });

  it('returns empty when nothing is expired', () => {
    const c = new FakeClock(0);
    const r = new LeaseRegistry({ clock: c.now });
    r.acquire('r1', 'w', { ttlMs: 5000 });
    assert.deepEqual(r.sweepExpired(), []);
  });

  it('handles repeated calls idempotently', () => {
    const c = new FakeClock(0);
    const r = new LeaseRegistry({ clock: c.now });
    r.acquire('r1', 'w', { ttlMs: 1000 });
    c.advance(2000);
    const first = r.sweepExpired();
    const second = r.sweepExpired();
    assert.equal(first.length, 1);
    assert.equal(second.length, 0);
  });
});

describe('list / getBy*', () => {
  it('list returns every active lease', () => {
    const c = new FakeClock(0);
    const r = new LeaseRegistry({ clock: c.now });
    r.acquire('r1', 'w');
    r.acquire('r2', 'w');
    assert.equal(r.list().length, 2);
  });

  it('getByRun returns the lease', () => {
    const c = new FakeClock(0);
    const r = new LeaseRegistry({ clock: c.now });
    const lease = r.acquire('r1', 'w')!;
    assert.equal(r.getByRun('r1')?.id, lease.id);
  });

  it('getByLease returns the lease', () => {
    const c = new FakeClock(0);
    const r = new LeaseRegistry({ clock: c.now });
    const lease = r.acquire('r1', 'w')!;
    assert.equal(r.getByLease(lease.id)?.runId, 'r1');
  });

  it('getByRun does not check expiry (reaper sees expired leases)', () => {
    const c = new FakeClock(0);
    const r = new LeaseRegistry({ clock: c.now });
    const lease = r.acquire('r1', 'w', { ttlMs: 1000 })!;
    c.advance(2000);
    // Without sweep, the lease is still in the index. This is intentional.
    assert.equal(r.getByRun('r1')?.id, lease.id);
  });
});

describe('race scenarios', () => {
  it('two acquires for the same runId at the same instant: only the first wins', () => {
    const c = new FakeClock(1000);
    const r = new LeaseRegistry({ clock: c.now });
    const a = r.acquire('r1', 'A');
    const b = r.acquire('r1', 'B');
    assert.ok(a);
    assert.equal(b, null);
  });
});
