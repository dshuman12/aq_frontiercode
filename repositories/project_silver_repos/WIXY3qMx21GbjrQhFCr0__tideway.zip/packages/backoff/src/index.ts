// Retry backoff policies.
//
// A Policy is a pure function `(attempt: number) => Duration`. Attempt 1 is
// the first retry (the original try is attempt 0 by convention; the policy
// is never asked about attempt 0 because the original attempt is dispatched
// without delay).
//
// Jitter is applied as a separate composition layer rather than baked into
// each policy. The reasoning: most callers want jitter, but the math for
// "policy with bounded jitter" is identical regardless of which underlying
// policy is in use, so DRY says factor it out.
//
// Notable design decision: durations are plain numbers (milliseconds). I
// considered a dedicated `Duration` opaque type but it added type ceremony
// without catching real bugs - everywhere the runtime touches durations it
// already knows the unit. The downside is that someone reading
// `nextAttemptAt = now + policy(attempt)` has to know "policy returns ms"
// from context. Acceptable trade.

export type Duration = number; // milliseconds

export type Policy = (attempt: number) => Duration;

export interface JitterOptions {
  // 'none' returns the policy value verbatim.
  // 'full'  -> uniform in [0, policy(attempt)].
  // 'equal' -> policy(attempt)/2 + uniform in [0, policy(attempt)/2].
  // 'decorrelated' uses the AWS-style formula:
  //   sleep = min(cap, random_between(base, prevSleep * 3))
  //   This requires history (the previous sleep), so jitter('decorrelated')
  //   returns a stateful Policy.
  kind: 'none' | 'full' | 'equal' | 'decorrelated';
  // For decorrelated only.
  base?: Duration;
  cap?: Duration;
  // Random source. Defaults to Math.random. Tests should pass a fixed RNG.
  rng?: () => number;
}

export function exponential(opts: { base: Duration; factor?: number; cap: Duration }): Policy {
  const factor = opts.factor ?? 2;
  if (opts.base <= 0) throw new RangeError('exponential base must be > 0');
  if (opts.cap < opts.base) throw new RangeError('exponential cap must be >= base');
  if (factor <= 1) throw new RangeError('exponential factor must be > 1');
  return (attempt) => {
    if (attempt < 1) throw new RangeError('attempt must be >= 1');
    const raw = opts.base * factor ** (attempt - 1);
    return Math.min(opts.cap, raw);
  };
}

export function linear(opts: { step: Duration; cap: Duration }): Policy {
  if (opts.step <= 0) throw new RangeError('linear step must be > 0');
  if (opts.cap < opts.step) throw new RangeError('linear cap must be >= step');
  return (attempt) => {
    if (attempt < 1) throw new RangeError('attempt must be >= 1');
    return Math.min(opts.cap, opts.step * attempt);
  };
}

export function fibonacci(opts: { unit: Duration; cap: Duration }): Policy {
  if (opts.unit <= 0) throw new RangeError('fibonacci unit must be > 0');
  if (opts.cap < opts.unit) throw new RangeError('fibonacci cap must be >= unit');
  // Sequence: f(1)=1, f(2)=1, f(3)=2, f(4)=3, f(5)=5...
  return (attempt) => {
    if (attempt < 1) throw new RangeError('attempt must be >= 1');
    if (attempt === 1 || attempt === 2) return Math.min(opts.cap, opts.unit);
    let a = 1;
    let b = 1;
    for (let i = 3; i <= attempt; i += 1) {
      const next = a + b;
      a = b;
      b = next;
      if (b * opts.unit >= opts.cap) return opts.cap;
    }
    return Math.min(opts.cap, b * opts.unit);
  };
}

export function constant(opts: { delay: Duration }): Policy {
  if (opts.delay < 0) throw new RangeError('constant delay must be >= 0');
  return () => opts.delay;
}

// Custom: just an identity wrapper. Provided so user code can write
//   policy: custom((n) => n * 1000)
// as a self-documenting callsite, rather than passing a bare arrow.
//
// (See also the old "v0.2 retry strategy" approach in commit 0fa3a9d
// for context on why we settled on this shape - the pre-0.2 design
// had retry policies as classes, which was rejected as too verbose.)
export function custom(fn: Policy): Policy {
  return fn;
}

export function jitter(policy: Policy, opts: JitterOptions): Policy {
  const rng = opts.rng ?? Math.random;
  switch (opts.kind) {
    case 'none':
      return policy;
    case 'full':
      return (attempt) => {
        const v = policy(attempt);
        return rng() * v;
      };
    case 'equal':
      return (attempt) => {
        const v = policy(attempt);
        return v / 2 + rng() * (v / 2);
      };
    case 'decorrelated': {
      if (opts.base === undefined || opts.cap === undefined) {
        throw new RangeError('decorrelated jitter requires base and cap');
      }
      const base = opts.base;
      const cap = opts.cap;
      let prev = base;
      return (attempt) => {
        if (attempt < 1) throw new RangeError('attempt must be >= 1');
        const upper = Math.min(cap, prev * 3);
        const lower = base;
        const sleep = lower + rng() * (upper - lower);
        prev = sleep;
        return sleep;
      };
    }
  }
}

// Capped: hard-clip the output of any policy. Useful as the outermost
// wrapper to enforce a budget regardless of which underlying policy is
// configured.
export function capped(policy: Policy, cap: Duration): Policy {
  if (cap <= 0) throw new RangeError('cap must be > 0');
  return (attempt) => Math.min(cap, policy(attempt));
}

// "Will the next retry definitely fit before the deadline?" Caller passes a
// deadline expressed as ms-since-epoch. Returns true iff
// (now + policy(attempt)) <= deadline. Used by the scheduler to short-circuit
// retries that would exhaust the budget before they could fire.
export function willFitBeforeDeadline(
  policy: Policy,
  attempt: number,
  now: number,
  deadline: number,
): boolean {
  return now + policy(attempt) <= deadline;
}
