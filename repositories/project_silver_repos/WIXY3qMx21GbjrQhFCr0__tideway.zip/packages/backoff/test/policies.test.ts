import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import {
  capped,
  constant,
  custom,
  exponential,
  fibonacci,
  jitter,
  linear,
  willFitBeforeDeadline,
} from '../src/index.ts';

describe('exponential', () => {
  const p = exponential({ base: 100, factor: 2, cap: 30_000 });

  it('attempt 1 returns base', () => {
    assert.equal(p(1), 100);
  });

  it('grows by factor each attempt', () => {
    assert.equal(p(2), 200);
    assert.equal(p(3), 400);
    assert.equal(p(4), 800);
    assert.equal(p(10), 51_200 > 30_000 ? 30_000 : 51_200);
  });

  it('caps at the configured cap', () => {
    assert.equal(p(20), 30_000);
  });

  it('throws on attempt < 1', () => {
    assert.throws(() => p(0), RangeError);
  });

  it('factor=3 also works', () => {
    const q = exponential({ base: 50, factor: 3, cap: 1e9 });
    assert.equal(q(1), 50);
    assert.equal(q(2), 150);
    assert.equal(q(3), 450);
  });

  it('rejects non-positive base', () => {
    assert.throws(() => exponential({ base: 0, cap: 1000 }), RangeError);
  });

  it('fails on cap below base', () => {
    assert.throws(() => exponential({ base: 100, cap: 50 }), RangeError);
  });

  it('bails on factor <= 1', () => {
    assert.throws(() => exponential({ base: 100, factor: 1, cap: 1000 }), RangeError);
    assert.throws(() => exponential({ base: 100, factor: 0.5, cap: 1000 }), RangeError);
  });
});

describe('linear', () => {
  const p = linear({ step: 200, cap: 5_000 });

  it('attempt N returns N * step (until cap)', () => {
    assert.equal(p(1), 200);
    assert.equal(p(2), 400);
    assert.equal(p(5), 1_000);
  });

  it('caps', () => {
    assert.equal(p(50), 5_000);
  });

  it('complains about step <= 0', () => {
    assert.throws(() => linear({ step: 0, cap: 1000 }), RangeError);
  });
});

describe('fibonacci', () => {
  const p = fibonacci({ unit: 100, cap: 10_000 });

  it('produces 1, 1, 2, 3, 5, 8, 13... times unit', () => {
    assert.equal(p(1), 100);
    assert.equal(p(2), 100);
    assert.equal(p(3), 200);
    assert.equal(p(4), 300);
    assert.equal(p(5), 500);
    assert.equal(p(6), 800);
    assert.equal(p(7), 1_300);
  });

  it('caps cleanly', () => {
    assert.equal(p(30), 10_000);
  });
});

describe('constant', () => {
  it('always returns the same delay', () => {
    const p = constant({ delay: 1500 });
    assert.equal(p(1), 1500);
    assert.equal(p(2), 1500);
    assert.equal(p(99), 1500);
  });

  it('zero delay is permitted', () => {
    const p = constant({ delay: 0 });
    assert.equal(p(1), 0);
  });

  it('refuses negative delay', () => {
    assert.throws(() => constant({ delay: -1 }), RangeError);
  });
});

describe('custom', () => {
  it('returns the function it was given', () => {
    const f = (n: number) => n * 1000;
    const p = custom(f);
    assert.equal(p(3), 3000);
  });
});

describe('jitter', () => {
  const seq = (vals: number[]) => {
    let i = 0;
    return () => {
      const v = vals[i % vals.length]!;
      i += 1;
      return v;
    };
  };

  it('kind: none is identity', () => {
    const p = jitter(constant({ delay: 100 }), { kind: 'none' });
    assert.equal(p(1), 100);
    assert.equal(p(2), 100);
  });

  it('kind: full produces values in [0, policy]', () => {
    const p = jitter(constant({ delay: 100 }), { kind: 'full', rng: seq([0, 0.5, 0.999]) });
    assert.equal(p(1), 0);
    assert.equal(p(2), 50);
    assert.ok(p(3) < 100);
  });

  it('kind: equal produces values in [policy/2, policy]', () => {
    const p = jitter(constant({ delay: 100 }), { kind: 'equal', rng: seq([0, 0.5, 1]) });
    assert.equal(p(1), 50);
    assert.equal(p(2), 75);
    assert.equal(p(3), 100);
  });

  it('kind: decorrelated grows from base', () => {
    const p = jitter(constant({ delay: 0 }), {
      kind: 'decorrelated',
      base: 100,
      cap: 10_000,
      rng: seq([0, 0, 0]),
    });
    // With rng=0 every time, sleep = base + 0 * (upper - base) = base = 100
    // each iteration, so prev stays at 100 and we keep returning 100.
    assert.equal(p(1), 100);
    assert.equal(p(2), 100);
  });

  it('kind: decorrelated grows toward cap with rng=1', () => {
    const p = jitter(constant({ delay: 0 }), {
      kind: 'decorrelated',
      base: 100,
      cap: 100_000,
      rng: () => 1 - 1e-12, // effectively 1, but strict < 1 to mirror Math.random
    });
    const a = p(1);
    const b = p(2);
    const c = p(3);
    // Each call's upper bound is min(cap, prev * 3). prev starts at base.
    // With rng -> 1, sleep -> upper.
    assert.ok(a > 100);
    assert.ok(b > a);
    assert.ok(c > b);
    assert.ok(c <= 100_000);
  });

  it('decorrelated requires base and cap', () => {
    assert.throws(() => jitter(constant({ delay: 0 }), { kind: 'decorrelated' }), RangeError);
  });
});

describe('capped', () => {
  it('clips outputs above the cap', () => {
    const p = capped(linear({ step: 500, cap: 1e9 }), 2_000);
    assert.equal(p(1), 500);
    assert.equal(p(4), 2_000);
    assert.equal(p(100), 2_000);
  });

  it('refuses non-positive cap', () => {
    assert.throws(() => capped(constant({ delay: 0 }), 0), RangeError);
  });
});

describe('willFitBeforeDeadline', () => {
  it('is true when there is room', () => {
    const p = constant({ delay: 100 });
    assert.equal(willFitBeforeDeadline(p, 1, 1000, 1500), true);
  });

  it('is false when retry would breach', () => {
    const p = constant({ delay: 1000 });
    assert.equal(willFitBeforeDeadline(p, 1, 1000, 1500), false);
  });

  it('is true on the boundary', () => {
    const p = constant({ delay: 500 });
    assert.equal(willFitBeforeDeadline(p, 1, 1000, 1500), true);
  });
});
