// Failure taxonomy for tideway.
//
// Job handlers run in user code, so any value can come back as a thrown
// error: a real Error, a string, a plain object with a message, undefined.
// The runtime needs a small fixed taxonomy to decide what to do next, so
// every thrown thing gets normalized through `classify` into a FailureKind.
//
// The five kinds map to distinct downstream behaviors:
//   retryable  -> schedule a retry per the policy attached to the job
//   permanent  -> skip retries; mark the run failed and propagate to children
//   canceled   -> the run was killed externally or by deadline; do not retry
//   lease_lost -> the worker lost its lease; another worker may pick up
//   wire       -> protocol-layer transport error; not the user's fault

export type FailureKind = 'retryable' | 'permanent' | 'canceled' | 'lease_lost' | 'wire';

export interface FailureRecord {
  kind: FailureKind;
  message: string;
  // The original thrown value, normalized to a JSON-safe shape. Useful for
  // forensic purposes; not load-bearing for the FSM.
  detail?: unknown;
  // Optional cause chain (errors with .cause set). Captured at classify-time.
  causes?: string[];
}

export class TidewayError extends Error {
  override readonly name: string = 'TidewayError';
  constructor(message: string, options?: { cause?: unknown }) {
    super(message);
    if (options && 'cause' in options) {
      // Node 16+ exposes `cause` natively, but we set it via Object.defineProperty
      // for the rare case the runtime is older or has been monkey-patched. (Yes
      // this came up once. Yes I am still annoyed about it.)
      Object.defineProperty(this, 'cause', { value: options.cause, configurable: true });
    }
  }
}

export class JobFailure extends TidewayError {
  override readonly name = 'JobFailure';
  readonly retryable: boolean;
  constructor(message: string, opts?: { retryable?: boolean; cause?: unknown }) {
    super(message, opts?.cause !== undefined ? { cause: opts.cause } : undefined);
    this.retryable = opts?.retryable ?? false;
  }
}

export class Retryable extends TidewayError {
  override readonly name = 'Retryable';
  constructor(message: string, opts?: { cause?: unknown }) {
    super(message, opts);
  }
}

export class Canceled extends TidewayError {
  override readonly name = 'Canceled';
  readonly reason: 'deadline' | 'external' | 'parent_failure';
  constructor(reason: 'deadline' | 'external' | 'parent_failure', message?: string) {
    super(message ?? `canceled: ${reason}`);
    this.reason = reason;
  }
}

export class LeaseLost extends TidewayError {
  override readonly name = 'LeaseLost';
  readonly leaseId: string;
  constructor(leaseId: string, message?: string) {
    super(message ?? `lease lost: ${leaseId}`);
    this.leaseId = leaseId;
  }
}

export class WireError extends TidewayError {
  override readonly name = 'WireError';
  readonly code: string;
  constructor(code: string, message: string, opts?: { cause?: unknown }) {
    super(message, opts);
    this.code = code;
  }
}

// classify normalizes any thrown value into a FailureRecord. The order of
// instanceof checks matters: subclasses come before their bases. (Right now
// we only have one level of hierarchy, but if anyone adds a subclass later
// they should put it above its parent.)
export function classify(err: unknown): FailureRecord {
  if (err instanceof Canceled) {
    return { kind: 'canceled', message: err.message, detail: { reason: err.reason } };
  }
  if (err instanceof LeaseLost) {
    return { kind: 'lease_lost', message: err.message, detail: { leaseId: err.leaseId } };
  }
  if (err instanceof WireError) {
    return { kind: 'wire', message: err.message, detail: { code: err.code } };
  }
  if (err instanceof JobFailure) {
    return {
      kind: err.retryable ? 'retryable' : 'permanent',
      message: err.message,
      causes: collectCauseMessages(err),
    };
  }
  if (err instanceof Retryable) {
    return { kind: 'retryable', message: err.message, causes: collectCauseMessages(err) };
  }
  if (err instanceof Error) {
    // Foreign Error: assume retryable. The reasoning is that bugs in user
    // code that throw a plain Error are usually transient (a missing file,
    // a network blip), and the operator can mark a particular handler as
    // non-retryable explicitly via `JobFailure` if they know better.
    return { kind: 'retryable', message: err.message || err.name, causes: collectCauseMessages(err) };
  }
  if (typeof err === 'string') {
    return { kind: 'retryable', message: err };
  }
  if (err && typeof err === 'object' && 'message' in err && typeof (err as { message: unknown }).message === 'string') {
    return { kind: 'retryable', message: (err as { message: string }).message, detail: err };
  }
  return { kind: 'retryable', message: 'unknown error', detail: err };
}

function collectCauseMessages(err: Error, depth = 0): string[] | undefined {
  if (depth > 8) return undefined;
  const cause = (err as Error & { cause?: unknown }).cause;
  if (!cause) return undefined;
  const out: string[] = [];
  let current: unknown = cause;
  let safety = 0;
  while (current && safety < 8) {
    if (current instanceof Error) {
      out.push(current.message || current.name);
      current = (current as Error & { cause?: unknown }).cause;
    } else if (typeof current === 'string') {
      out.push(current);
      break;
    } else {
      break;
    }
    safety += 1;
  }
  return out.length > 0 ? out : undefined;
}

// Convenience: is this failure something the scheduler should re-attempt?
export function isRetryable(record: FailureRecord): boolean {
  return record.kind === 'retryable';
}

export function isTerminal(record: FailureRecord): boolean {
  return record.kind === 'permanent' || record.kind === 'canceled';
}
