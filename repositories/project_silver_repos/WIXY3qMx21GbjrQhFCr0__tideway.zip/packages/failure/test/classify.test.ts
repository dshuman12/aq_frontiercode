import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import {
  Canceled,
  JobFailure,
  LeaseLost,
  Retryable,
  WireError,
  classify,
  isRetryable,
  isTerminal,
} from '../src/index.ts';

describe('classify', () => {
  it('marks JobFailure with retryable=false as permanent', () => {
    const r = classify(new JobFailure('handler bug'));
    assert.equal(r.kind, 'permanent');
    assert.equal(r.message, 'handler bug');
  });

  it('marks JobFailure with retryable=true as retryable', () => {
    const r = classify(new JobFailure('flaky', { retryable: true }));
    assert.equal(r.kind, 'retryable');
  });

  it('marks Retryable as retryable', () => {
    const r = classify(new Retryable('try again'));
    assert.equal(r.kind, 'retryable');
  });

  it('marks Canceled as canceled with reason in detail', () => {
    const r = classify(new Canceled('deadline'));
    assert.equal(r.kind, 'canceled');
    assert.deepEqual(r.detail, { reason: 'deadline' });
  });

  it('marks LeaseLost as lease_lost', () => {
    const r = classify(new LeaseLost('lease-abc'));
    assert.equal(r.kind, 'lease_lost');
    assert.deepEqual(r.detail, { leaseId: 'lease-abc' });
  });

  it('marks WireError as wire with code in detail', () => {
    const r = classify(new WireError('FRAME_TOO_LARGE', 'over budget'));
    assert.equal(r.kind, 'wire');
    assert.deepEqual(r.detail, { code: 'FRAME_TOO_LARGE' });
  });

  it('treats foreign Error as retryable', () => {
    const r = classify(new Error('oh no'));
    assert.equal(r.kind, 'retryable');
    assert.equal(r.message, 'oh no');
  });

  it('treats string throws as retryable', () => {
    const r = classify('something exploded');
    assert.equal(r.kind, 'retryable');
    assert.equal(r.message, 'something exploded');
  });

  it('treats { message } objects as retryable', () => {
    const r = classify({ message: 'duck-typed', code: 7 });
    assert.equal(r.kind, 'retryable');
    assert.equal(r.message, 'duck-typed');
  });

  it('falls back to "unknown error" for opaque values', () => {
    const r = classify(42);
    assert.equal(r.kind, 'retryable');
    assert.equal(r.message, 'unknown error');
    assert.equal(r.detail, 42);
  });

  it('falls back to "unknown error" for null', () => {
    const r = classify(null);
    assert.equal(r.kind, 'retryable');
    assert.equal(r.message, 'unknown error');
  });

  it('captures cause chain on Retryable', () => {
    const root = new Error('root cause');
    const middle = new Error('middle');
    Object.defineProperty(middle, 'cause', { value: root });
    const top = new Retryable('top', { cause: middle });
    const r = classify(top);
    assert.deepEqual(r.causes, ['middle', 'root cause']);
  });

  it('caps cause chain at 8 levels deep', () => {
    let err: Error & { cause?: unknown } = new Error('level-0');
    for (let i = 1; i < 20; i += 1) {
      const next = new Error(`level-${i}`) as Error & { cause?: unknown };
      next.cause = err;
      err = next;
    }
    const r = classify(err);
    assert.ok(r.causes);
    assert.ok(r.causes.length <= 8);
  });

  it('skips cause field if absent', () => {
    const r = classify(new Retryable('lonely'));
    assert.equal(r.causes, undefined);
  });
});

describe('isRetryable / isTerminal', () => {
  it('isRetryable is true only for retryable kind', () => {
    assert.equal(isRetryable({ kind: 'retryable', message: '' }), true);
    assert.equal(isRetryable({ kind: 'permanent', message: '' }), false);
    assert.equal(isRetryable({ kind: 'canceled', message: '' }), false);
    assert.equal(isRetryable({ kind: 'lease_lost', message: '' }), false);
    assert.equal(isRetryable({ kind: 'wire', message: '' }), false);
  });

  it('isTerminal covers permanent and canceled', () => {
    assert.equal(isTerminal({ kind: 'permanent', message: '' }), true);
    assert.equal(isTerminal({ kind: 'canceled', message: '' }), true);
    assert.equal(isTerminal({ kind: 'retryable', message: '' }), false);
    assert.equal(isTerminal({ kind: 'lease_lost', message: '' }), false);
    assert.equal(isTerminal({ kind: 'wire', message: '' }), false);
  });
});

describe('error class identity', () => {
  it('JobFailure is an instanceof Error', () => {
    assert.ok(new JobFailure('x') instanceof Error);
  });

  it('Canceled exposes its reason', () => {
    const c = new Canceled('parent_failure');
    assert.equal(c.reason, 'parent_failure');
    assert.match(c.message, /parent_failure/);
  });

  it('LeaseLost exposes its leaseId', () => {
    const ll = new LeaseLost('abc-123');
    assert.equal(ll.leaseId, 'abc-123');
  });

  it('WireError exposes its code', () => {
    const w = new WireError('CHECKSUM_MISMATCH', 'bad bytes');
    assert.equal(w.code, 'CHECKSUM_MISMATCH');
  });

  it('JobFailure preserves cause via Error.cause', () => {
    const root = new Error('root');
    const top = new JobFailure('wrapped', { cause: root });
    // cause is non-enumerable but readable
    assert.equal((top as Error & { cause?: unknown }).cause, root);
  });
});
