import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { Inflight, type RunningRecord } from '../src/index.ts';

const rec = (runId: string, deadlineAt = Infinity, startedAt = 0): RunningRecord => ({
  runId,
  workerId: 'w',
  startedAt,
  deadlineAt,
});

describe('Inflight basics', () => {
  it('starts empty', () => {
    const i = new Inflight();
    assert.equal(i.size(), 0);
    assert.equal(i.earliestDeadline(), undefined);
  });

  it('add/has/get round-trips', () => {
    const i = new Inflight();
    i.add(rec('r1', 1000));
    assert.equal(i.has('r1'), true);
    assert.equal(i.get('r1')?.deadlineAt, 1000);
    assert.equal(i.size(), 1);
  });

  it('add throws on duplicate', () => {
    const i = new Inflight();
    i.add(rec('r1'));
    assert.throws(() => i.add(rec('r1')));
  });

  it('remove returns the record and shrinks size', () => {
    const i = new Inflight();
    i.add(rec('r1', 1000));
    const removed = i.remove('r1');
    assert.equal(removed?.runId, 'r1');
    assert.equal(i.has('r1'), false);
    assert.equal(i.size(), 0);
  });

  it('remove on unknown id returns undefined', () => {
    const i = new Inflight();
    assert.equal(i.remove('ghost'), undefined);
  });

  it('list returns every record', () => {
    const i = new Inflight();
    i.add(rec('r1'));
    i.add(rec('r2'));
    i.add(rec('r3'));
    const list = i.list();
    assert.equal(list.length, 3);
    assert.deepEqual(list.map((r) => r.runId).sort(), ['r1', 'r2', 'r3']);
  });
});

describe('Inflight: heap ordering', () => {
  it('earliestDeadline returns the soonest deadline', () => {
    const i = new Inflight();
    i.add(rec('r1', 5000));
    i.add(rec('r2', 1000));
    i.add(rec('r3', 3000));
    assert.equal(i.earliestDeadline()?.runId, 'r2');
  });

  it('earliestDeadline updates when the soonest is removed', () => {
    const i = new Inflight();
    i.add(rec('r1', 5000));
    i.add(rec('r2', 1000));
    i.remove('r2');
    // Next-soonest is r1.
    assert.equal(i.earliestDeadline()?.runId, 'r1');
  });

  it('earliestDeadline with ties returns one of the tied runs', () => {
    const i = new Inflight();
    i.add(rec('r1', 1000));
    i.add(rec('r2', 1000));
    const e = i.earliestDeadline();
    assert.ok(['r1', 'r2'].includes(e!.runId));
  });

  it('updateDeadline re-keys the heap', () => {
    const i = new Inflight();
    i.add(rec('r1', 5000));
    i.add(rec('r2', 3000));
    i.updateDeadline('r1', 1000);
    assert.equal(i.earliestDeadline()?.runId, 'r1');
  });

  it('updateDeadline returns false on unknown', () => {
    const i = new Inflight();
    assert.equal(i.updateDeadline('ghost', 10), false);
  });
});

describe('popExpired', () => {
  it('pops only entries with deadline <= now', () => {
    const i = new Inflight();
    i.add(rec('r1', 1000));
    i.add(rec('r2', 5000));
    i.add(rec('r3', 2000));
    const popped = i.popExpired(2500);
    assert.deepEqual(
      popped.map((p) => p.runId).sort(),
      ['r1', 'r3'],
    );
    assert.equal(i.has('r2'), true);
    assert.equal(i.size(), 1);
  });

  it('pops nothing when none expired', () => {
    const i = new Inflight();
    i.add(rec('r1', 5000));
    assert.deepEqual(i.popExpired(1000), []);
  });

  it('handles popping all entries cleanly', () => {
    const i = new Inflight();
    i.add(rec('r1', 100));
    i.add(rec('r2', 200));
    const popped = i.popExpired(10_000);
    assert.equal(popped.length, 2);
    assert.equal(i.size(), 0);
    assert.equal(i.earliestDeadline(), undefined);
  });

  it('handles infinite deadlines by never popping them', () => {
    const i = new Inflight();
    i.add(rec('r-infty', Infinity));
    assert.deepEqual(i.popExpired(Number.MAX_SAFE_INTEGER), []);
    assert.equal(i.size(), 1);
  });

  it('handles a stress sweep across many entries', () => {
    const i = new Inflight();
    for (let k = 0; k < 100; k += 1) {
      i.add(rec(`r${k}`, k * 10));
    }
    // Expire the first half.
    const popped = i.popExpired(490); // deadlines 0..490 -> 50 records
    assert.equal(popped.length, 50);
    assert.equal(i.size(), 50);
    // The remaining heap-min must be 500.
    assert.equal(i.earliestDeadline()?.deadline, 500);
  });
});
