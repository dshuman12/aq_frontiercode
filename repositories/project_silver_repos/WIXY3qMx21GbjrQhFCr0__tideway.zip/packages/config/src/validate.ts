// Config validation.
//
// Walks an unknown input, type-checks each field, fills in defaults for
// anything missing, and accumulates all validation errors in one pass.
// Returning all errors at once is more useful than failing on the first
// one because it lets the operator fix everything in one edit.

import { DEFAULTS, type RunnerConfig, type ValidationError, type ValidationResult } from './schema.ts';

type Path = string;

class V {
  errors: ValidationError[] = [];

  fail(path: Path, message: string): void {
    this.errors.push({ path, message });
  }

  asObject(value: unknown, path: Path): Record<string, unknown> | undefined {
    if (value === undefined) return undefined;
    if (value === null || typeof value !== 'object' || Array.isArray(value)) {
      this.fail(path, `expected object, got ${describe(value)}`);
      return undefined;
    }
    return value as Record<string, unknown>;
  }

  asString(value: unknown, path: Path, fallback: string): string {
    if (value === undefined) return fallback;
    if (typeof value !== 'string') {
      this.fail(path, `expected string, got ${describe(value)}`);
      return fallback;
    }
    return value;
  }

  asPositiveInt(value: unknown, path: Path, fallback: number): number {
    if (value === undefined) return fallback;
    if (typeof value !== 'number' || !Number.isInteger(value) || value < 1) {
      this.fail(path, `expected positive integer, got ${describe(value)}`);
      return fallback;
    }
    return value;
  }

  asNonNegativeInt(value: unknown, path: Path, fallback: number): number {
    if (value === undefined) return fallback;
    if (typeof value !== 'number' || !Number.isInteger(value) || value < 0) {
      this.fail(path, `expected non-negative integer, got ${describe(value)}`);
      return fallback;
    }
    return value;
  }

  asEnum<T extends string>(
    value: unknown,
    path: Path,
    options: readonly T[],
    fallback: T,
  ): T {
    if (value === undefined) return fallback;
    if (typeof value !== 'string' || !options.includes(value as T)) {
      this.fail(path, `expected one of ${JSON.stringify(options)}, got ${describe(value)}`);
      return fallback;
    }
    return value as T;
  }

  asStringArray(value: unknown, path: Path, fallback: string[]): string[] {
    if (value === undefined) return fallback;
    if (!Array.isArray(value)) {
      this.fail(path, `expected array of strings, got ${describe(value)}`);
      return fallback;
    }
    const out: string[] = [];
    for (let i = 0; i < value.length; i += 1) {
      const elem = value[i];
      if (typeof elem !== 'string') {
        this.fail(`${path}[${i}]`, `expected string, got ${describe(elem)}`);
        continue;
      }
      out.push(elem);
    }
    return out;
  }
}

function describe(value: unknown): string {
  if (value === null) return 'null';
  if (Array.isArray(value)) return 'array';
  return typeof value;
}

export function validate(input: unknown): ValidationResult {
  const v = new V();
  const root = v.asObject(input, '$') ?? {};

  const tracing: Record<string, unknown> = v.asObject(root.tracing, '$.tracing') ?? {};
  const health: Record<string, unknown> = v.asObject(root.health, '$.health') ?? {};

  const config: RunnerConfig = {
    dbPath: v.asString(root.dbPath, '$.dbPath', DEFAULTS.dbPath),
    socketPath: v.asString(root.socketPath, '$.socketPath', DEFAULTS.socketPath),
    workerCount: v.asPositiveInt(root.workerCount, '$.workerCount', DEFAULTS.workerCount),
    defaultLeaseTtlMs: v.asPositiveInt(root.defaultLeaseTtlMs, '$.defaultLeaseTtlMs', DEFAULTS.defaultLeaseTtlMs),
    schedulerIntervalMs: v.asPositiveInt(
      root.schedulerIntervalMs,
      '$.schedulerIntervalMs',
      DEFAULTS.schedulerIntervalMs,
    ),
    reaperIntervalMs: v.asPositiveInt(root.reaperIntervalMs, '$.reaperIntervalMs', DEFAULTS.reaperIntervalMs),
    outboxFlushIntervalMs: v.asPositiveInt(
      root.outboxFlushIntervalMs,
      '$.outboxFlushIntervalMs',
      DEFAULTS.outboxFlushIntervalMs,
    ),
    idempotencyTtlMs: v.asPositiveInt(
      root.idempotencyTtlMs,
      '$.idempotencyTtlMs',
      DEFAULTS.idempotencyTtlMs,
    ),
    tracing: {
      exporter: v.asEnum(
        tracing.exporter,
        '$.tracing.exporter',
        ['noop', 'jsonl-stdout'] as const,
        DEFAULTS.tracing.exporter,
      ),
    },
    health: {
      enabledProbes: v.asStringArray(
        health.enabledProbes,
        '$.health.enabledProbes',
        DEFAULTS.health.enabledProbes,
      ),
      intervalMs: v.asPositiveInt(health.intervalMs, '$.health.intervalMs', DEFAULTS.health.intervalMs),
    },
    logLevel: v.asEnum(
      root.logLevel,
      '$.logLevel',
      ['debug', 'info', 'warn', 'error'] as const,
      DEFAULTS.logLevel,
    ),
  };

  // Cross-field constraints.
  if (config.schedulerIntervalMs > config.defaultLeaseTtlMs) {
    v.fail(
      '$.schedulerIntervalMs',
      `must be <= defaultLeaseTtlMs (${config.defaultLeaseTtlMs}); the scheduler can't keep up otherwise`,
    );
  }
  if (config.reaperIntervalMs > config.defaultLeaseTtlMs) {
    v.fail(
      '$.reaperIntervalMs',
      `must be <= defaultLeaseTtlMs (${config.defaultLeaseTtlMs}); expired leases would not be reclaimed in time`,
    );
  }

  if (v.errors.length > 0) {
    return { ok: false, errors: v.errors };
  }
  return { ok: true, config, errors: [] };
}
