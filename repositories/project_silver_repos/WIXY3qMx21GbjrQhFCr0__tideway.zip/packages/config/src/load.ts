// Config loading from a file or environment.
//
// Two paths into a Config: a JSON config file (the production path),
// or environment variables (the convenience path for ad-hoc overrides
// and tests). Env-var overrides are applied AFTER the file load, so
// `TIDEWAY_WORKER_COUNT=16` overrides whatever's in the json file.

import { readFileSync } from 'node:fs';
import { validate } from './validate.ts';
import type { RunnerConfig, ValidationResult } from './schema.ts';

export interface LoadOptions {
  // Path to a json config file. Optional; if absent we just use
  // defaults plus env overrides.
  filePath?: string;
  // Override the default env-var lookup. Useful for tests; production
  // code uses process.env.
  env?: Record<string, string | undefined>;
}

export function load(opts: LoadOptions = {}): ValidationResult {
  let raw: unknown = {};
  if (opts.filePath) {
    try {
      const text = readFileSync(opts.filePath, 'utf8');
      raw = JSON.parse(text);
    } catch (err) {
      return {
        ok: false,
        errors: [{ path: '$', message: `failed to load ${opts.filePath}: ${(err as Error).message}` }],
      };
    }
  }
  raw = applyEnvOverrides(raw, opts.env ?? process.env);
  return validate(raw);
}

// Map of env var names to dotted-path locations in the config tree.
// Only fields that real operators actually override are exposed here;
// everything else has to go through the json file.
const ENV_MAP: Array<{ env: string; path: string[]; cast: (v: string) => unknown }> = [
  { env: 'TIDEWAY_DB_PATH', path: ['dbPath'], cast: (v) => v },
  { env: 'TIDEWAY_SOCKET_PATH', path: ['socketPath'], cast: (v) => v },
  { env: 'TIDEWAY_WORKER_COUNT', path: ['workerCount'], cast: (v) => Number(v) },
  { env: 'TIDEWAY_LEASE_TTL_MS', path: ['defaultLeaseTtlMs'], cast: (v) => Number(v) },
  { env: 'TIDEWAY_LOG_LEVEL', path: ['logLevel'], cast: (v) => v },
  { env: 'TIDEWAY_TRACING_EXPORTER', path: ['tracing', 'exporter'], cast: (v) => v },
];

function applyEnvOverrides(
  raw: unknown,
  env: Record<string, string | undefined>,
): unknown {
  const obj: Record<string, unknown> =
    raw && typeof raw === 'object' && !Array.isArray(raw) ? { ...(raw as Record<string, unknown>) } : {};

  for (const m of ENV_MAP) {
    const v = env[m.env];
    if (v === undefined || v === '') continue;
    setAt(obj, m.path, m.cast(v));
  }
  return obj;
}

function setAt(target: Record<string, unknown>, path: string[], value: unknown): void {
  if (path.length === 0) return;
  if (path.length === 1) {
    target[path[0]!] = value;
    return;
  }
  const head = path[0]!;
  const next = target[head];
  const child: Record<string, unknown> =
    next && typeof next === 'object' && !Array.isArray(next) ? { ...(next as Record<string, unknown>) } : {};
  target[head] = child;
  setAt(child, path.slice(1), value);
}

// Convenience: load + throw on failure. Used at runner startup where the
// config either works or we crash and the supervisor restarts us.
export function loadOrThrow(opts: LoadOptions = {}): RunnerConfig {
  const result = load(opts);
  if (!result.ok || !result.config) {
    const msgs = result.errors.map((e) => `  ${e.path}: ${e.message}`).join('\n');
    throw new Error(`invalid configuration:\n${msgs}`);
  }
  return result.config;
}
