// Configuration schema for the runner.
//
// We define the full config shape here in TypeScript. A loaded config
// JSON / TOML document is passed through `validate()` which produces
// either a typed Config or a list of errors. Defaults are applied
// at validation time so calling code can pretend the config came in
// fully-populated.
//
// We do NOT use a third-party validation library (zod, ajv, etc.)
// because the schema is small enough that hand-rolled validation is
// shorter and produces better error messages for our specific cases
// ("the workerCount field must be a positive integer; got 'six'").

export interface RunnerConfig {
  // Path to the SQLite database file. ':memory:' is allowed and gives
  // an ephemeral in-process db.
  dbPath: string;
  // Path to the unix socket the wire protocol listens on.
  socketPath: string;
  // Worker pool size. Must be >= 1.
  workerCount: number;
  // Default lease TTL in milliseconds.
  defaultLeaseTtlMs: number;
  // How often the scheduler tick fires.
  schedulerIntervalMs: number;
  // How often the lease reaper sweeps.
  reaperIntervalMs: number;
  // How often the outbox flush loop runs.
  outboxFlushIntervalMs: number;
  // Default idempotency TTL.
  idempotencyTtlMs: number;
  // Tracing exporter. 'noop' or 'jsonl-stdout'.
  tracing: { exporter: 'noop' | 'jsonl-stdout' };
  // Health probes that the runner registers automatically. Default:
  // store + outbox + lease.
  health: {
    enabledProbes: string[];
    intervalMs: number;
  };
  // Logging level.
  logLevel: 'debug' | 'info' | 'warn' | 'error';
}

export const DEFAULTS: RunnerConfig = {
  dbPath: '/var/lib/tideway/tideway.db',
  socketPath: '/var/run/tideway.sock',
  workerCount: 8,
  defaultLeaseTtlMs: 30_000,
  schedulerIntervalMs: 100,
  reaperIntervalMs: 5_000,
  outboxFlushIntervalMs: 100,
  idempotencyTtlMs: 24 * 60 * 60 * 1000,
  tracing: { exporter: 'noop' },
  health: {
    enabledProbes: ['store', 'outbox', 'lease'],
    intervalMs: 5_000,
  },
  logLevel: 'info',
};

export interface ValidationError {
  path: string;
  message: string;
}

export interface ValidationResult {
  ok: boolean;
  config?: RunnerConfig;
  errors: ValidationError[];
}
