import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { mkdtempSync, writeFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

import { load, loadOrThrow } from '../src/load.ts';

function tempJson(contents: unknown): string {
  const dir = mkdtempSync(join(tmpdir(), 'tideway-config-'));
  const path = join(dir, 'config.json');
  writeFileSync(path, JSON.stringify(contents), 'utf8');
  return path;
}

describe('load: file path', () => {
  it('reads a json config file', () => {
    const path = tempJson({ workerCount: 16 });
    try {
      const r = load({ filePath: path, env: {} });
      assert.equal(r.ok, true);
      assert.equal(r.config?.workerCount, 16);
    } finally {
      rmSync(path, { force: true });
    }
  });

  it('reports a parse error with the file path in the message', () => {
    const dir = mkdtempSync(join(tmpdir(), 'tideway-config-'));
    const path = join(dir, 'broken.json');
    writeFileSync(path, '{ not json', 'utf8');
    try {
      const r = load({ filePath: path, env: {} });
      assert.equal(r.ok, false);
      assert.match(r.errors[0]!.message, /failed to load/);
    } finally {
      rmSync(path, { force: true });
    }
  });

  it('with no file path uses defaults', () => {
    const r = load({ env: {} });
    assert.equal(r.ok, true);
    assert.equal(r.config?.workerCount, 8);
  });
});

describe('load: env overrides', () => {
  it('TIDEWAY_WORKER_COUNT overrides workerCount', () => {
    const r = load({ env: { TIDEWAY_WORKER_COUNT: '20' } });
    assert.equal(r.config?.workerCount, 20);
  });

  it('TIDEWAY_DB_PATH overrides dbPath', () => {
    const r = load({ env: { TIDEWAY_DB_PATH: '/tmp/x.db' } });
    assert.equal(r.config?.dbPath, '/tmp/x.db');
  });

  it('TIDEWAY_TRACING_EXPORTER overrides nested field', () => {
    const r = load({ env: { TIDEWAY_TRACING_EXPORTER: 'jsonl-stdout' } });
    assert.equal(r.config?.tracing.exporter, 'jsonl-stdout');
  });

  it('env override on top of file', () => {
    const path = tempJson({ workerCount: 8 });
    try {
      const r = load({ filePath: path, env: { TIDEWAY_WORKER_COUNT: '32' } });
      assert.equal(r.config?.workerCount, 32);
    } finally {
      rmSync(path, { force: true });
    }
  });

  it('empty env value is ignored', () => {
    const r = load({ env: { TIDEWAY_WORKER_COUNT: '' } });
    assert.equal(r.config?.workerCount, 8);
  });

  it('invalid env value triggers validation error', () => {
    const r = load({ env: { TIDEWAY_WORKER_COUNT: 'sixteen' } });
    assert.equal(r.ok, false);
  });
});

describe('loadOrThrow', () => {
  it('returns config on success', () => {
    const config = loadOrThrow({ env: {} });
    assert.equal(config.workerCount, 8);
  });

  it('throws on validation failure', () => {
    assert.throws(() => loadOrThrow({ env: { TIDEWAY_WORKER_COUNT: '-1' } }));
  });

  it('thrown error includes per-field messages', () => {
    try {
      loadOrThrow({ env: { TIDEWAY_WORKER_COUNT: '-5', TIDEWAY_LOG_LEVEL: 'verbose' } });
      assert.fail('expected throw');
    } catch (err) {
      const msg = (err as Error).message;
      assert.match(msg, /workerCount/);
      assert.match(msg, /logLevel/);
    }
  });
});
