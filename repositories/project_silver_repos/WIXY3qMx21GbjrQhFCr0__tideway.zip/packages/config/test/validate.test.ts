import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { DEFAULTS } from '../src/schema.ts';
import { validate } from '../src/validate.ts';

describe('validate: empty input', () => {
  it('produces all defaults', () => {
    const r = validate({});
    assert.equal(r.ok, true);
    assert.deepEqual(r.config, DEFAULTS);
  });

  it('rejects non-object root', () => {
    const r = validate('not-an-object');
    assert.equal(r.ok, false);
    assert.match(r.errors[0]!.message, /expected object/);
  });

  it('treats null root as empty object', () => {
    const r = validate(null);
    assert.equal(r.ok, false);
  });
});

describe('validate: simple fields', () => {
  it('accepts a valid dbPath', () => {
    const r = validate({ dbPath: '/srv/tideway.db' });
    assert.equal(r.config?.dbPath, '/srv/tideway.db');
  });

  it('fails on non-string dbPath', () => {
    const r = validate({ dbPath: 42 });
    assert.equal(r.ok, false);
    assert.match(r.errors[0]!.message, /expected string/);
  });

  it('bails on zero workerCount', () => {
    const r = validate({ workerCount: 0 });
    assert.equal(r.ok, false);
    assert.match(r.errors[0]!.message, /positive integer/);
  });

  it('complains about negative workerCount', () => {
    const r = validate({ workerCount: -5 });
    assert.equal(r.ok, false);
  });

  it('refuses non-integer workerCount', () => {
    const r = validate({ workerCount: 3.14 });
    assert.equal(r.ok, false);
  });

  it('blows up on unknown logLevel', () => {
    const r = validate({ logLevel: 'verbose' });
    assert.equal(r.ok, false);
    assert.match(r.errors[0]!.message, /one of/);
  });

  it('accepts valid logLevel', () => {
    for (const l of ['debug', 'info', 'warn', 'error']) {
      const r = validate({ logLevel: l });
      assert.equal(r.ok, true);
      assert.equal(r.config?.logLevel, l);
    }
  });
});

describe('validate: nested objects', () => {
  it('accepts valid tracing.exporter', () => {
    const r = validate({ tracing: { exporter: 'jsonl-stdout' } });
    assert.equal(r.config?.tracing.exporter, 'jsonl-stdout');
  });

  it('errors on invalid tracing.exporter', () => {
    const r = validate({ tracing: { exporter: 'datadog' } });
    assert.equal(r.ok, false);
    assert.match(r.errors[0]!.path, /tracing\.exporter/);
  });

  it('accepts valid health.enabledProbes', () => {
    const r = validate({ health: { enabledProbes: ['store'], intervalMs: 1000 } });
    assert.deepEqual(r.config?.health.enabledProbes, ['store']);
  });

  it('throws on non-string element in health.enabledProbes', () => {
    const r = validate({ health: { enabledProbes: ['store', 42] } });
    assert.equal(r.ok, false);
    assert.match(r.errors[0]!.path, /enabledProbes\[1\]/);
  });
});

describe('validate: cross-field constraints', () => {
  it('rejects schedulerIntervalMs > defaultLeaseTtlMs', () => {
    const r = validate({ schedulerIntervalMs: 60_000, defaultLeaseTtlMs: 10_000 });
    assert.equal(r.ok, false);
    assert.match(r.errors[0]!.message, /must be <= defaultLeaseTtlMs/);
  });

  it('fails on reaperIntervalMs > defaultLeaseTtlMs', () => {
    const r = validate({ reaperIntervalMs: 60_000, defaultLeaseTtlMs: 30_000 });
    assert.equal(r.ok, false);
  });

  it('accepts boundary equality', () => {
    const r = validate({ schedulerIntervalMs: 30_000, defaultLeaseTtlMs: 30_000 });
    assert.equal(r.ok, true);
  });
});

describe('validate: error accumulation', () => {
  it('reports multiple errors in one pass', () => {
    const r = validate({
      workerCount: -1,
      logLevel: 'verbose',
      tracing: { exporter: 'datadog' },
    });
    assert.equal(r.ok, false);
    assert.equal(r.errors.length, 3);
  });
});
