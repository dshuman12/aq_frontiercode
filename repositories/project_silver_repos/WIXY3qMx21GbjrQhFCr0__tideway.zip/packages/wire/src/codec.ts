// Wire protocol: framing and per-message codecs.
//
// The runner exposes a unix socket; the console connects and sends
// length-prefixed JSON messages. Frame layout:
//
//   [4 bytes BE u32 length][body bytes...]
//
// The first byte of every connection is a version handshake byte. The
// peer that initiates the connection sends its version; the responder
// either accepts (responds with the same byte) or rejects (closes the
// socket with no body). This keeps backward-compatibility checks one
// byte instead of dozens.
//
// The body is always JSON. We do NOT use a binary serialization (proto-
// buf, msgpack) because the message volumes are low - one message per
// CLI command, basically - and the diagnosability win of "you can read
// the wire bytes with `cat`" is large.

import { WireError } from '@tideway/failure';

export const PROTOCOL_VERSION = 1;
export const MAX_FRAME_BYTES = 1024 * 1024; // 1 MiB

export type RequestKind = 'submit' | 'status' | 'cancel' | 'list' | 'drain' | 'replay-dlq';

export interface SubmitRequest {
  kind: 'submit';
  handler: string;
  input: unknown;
  idempotencyKey?: string;
  priority?: number;
  deadlineMs?: number;
  queue?: string;
  tags?: string[];
}

export interface StatusRequest {
  kind: 'status';
  runId: string;
}

export interface CancelRequest {
  kind: 'cancel';
  runId: string;
  reason?: string;
}

export interface ListRequest {
  kind: 'list';
  state?: string;
  limit?: number;
}

export interface DrainRequest {
  kind: 'drain';
  graceful: boolean;
}

export interface ReplayDlqRequest {
  kind: 'replay-dlq';
  runId?: string;
  filter?: { handler?: string; failureKind?: string; tag?: string };
}

export type Request =
  | SubmitRequest
  | StatusRequest
  | CancelRequest
  | ListRequest
  | DrainRequest
  | ReplayDlqRequest;

export interface Response {
  ok: boolean;
  body?: unknown;
  error?: { code: string; message: string };
}

// --- Frame encoding/decoding ---

export function encodeFrame(body: Buffer | Uint8Array): Buffer {
  if (body.byteLength > MAX_FRAME_BYTES) {
    throw new WireError('FRAME_TOO_LARGE', `frame is ${body.byteLength} bytes (max ${MAX_FRAME_BYTES})`);
  }
  const header = Buffer.alloc(4);
  header.writeUInt32BE(body.byteLength, 0);
  // Concat into a single Buffer so callers can socket.write(frame) once.
  const out = Buffer.alloc(4 + body.byteLength);
  header.copy(out, 0);
  Buffer.from(body).copy(out, 4);
  return out;
}

export function decodeFrame(input: Buffer): { body: Buffer; consumed: number } | { partial: true } {
  if (input.byteLength < 4) return { partial: true };
  const len = input.readUInt32BE(0);
  if (len > MAX_FRAME_BYTES) {
    throw new WireError('FRAME_TOO_LARGE', `frame claims ${len} bytes (max ${MAX_FRAME_BYTES})`);
  }
  if (input.byteLength < 4 + len) return { partial: true };
  return { body: input.subarray(4, 4 + len), consumed: 4 + len };
}

// Stream reassembler: keeps a tail buffer and yields frames as they
// complete. Used by both client and server.
export class FrameReassembler {
  private buf: Buffer = Buffer.alloc(0);

  push(chunk: Buffer): Buffer[] {
    this.buf = Buffer.concat([this.buf, chunk]);
    const out: Buffer[] = [];
    while (true) {
      const r = decodeFrame(this.buf);
      if ('partial' in r) break;
      out.push(r.body);
      this.buf = this.buf.subarray(r.consumed);
    }
    return out;
  }

  pending(): number {
    return this.buf.byteLength;
  }
}

// --- Request/response codecs ---

export function encodeRequest(req: Request): Buffer {
  return encodeFrame(Buffer.from(JSON.stringify(req), 'utf8'));
}

export function decodeRequest(body: Buffer): Request {
  let parsed: unknown;
  try {
    parsed = JSON.parse(body.toString('utf8'));
  } catch (err) {
    throw new WireError('BAD_JSON', `request body is not JSON: ${(err as Error).message}`);
  }
  validateRequest(parsed);
  return parsed as Request;
}

export function encodeResponse(res: Response): Buffer {
  return encodeFrame(Buffer.from(JSON.stringify(res), 'utf8'));
}

export function decodeResponse(body: Buffer): Response {
  let parsed: unknown;
  try {
    parsed = JSON.parse(body.toString('utf8'));
  } catch (err) {
    throw new WireError('BAD_JSON', `response body is not JSON: ${(err as Error).message}`);
  }
  if (!parsed || typeof parsed !== 'object' || !('ok' in parsed)) {
    throw new WireError('BAD_RESPONSE', 'response missing required "ok" field');
  }
  return parsed as Response;
}

function validateRequest(value: unknown): void {
  if (!value || typeof value !== 'object') {
    throw new WireError('BAD_REQUEST', 'request must be a JSON object');
  }
  const obj = value as { kind?: unknown };
  if (typeof obj.kind !== 'string') {
    throw new WireError('BAD_REQUEST', 'request missing "kind" field');
  }
  const validKinds: RequestKind[] = ['submit', 'status', 'cancel', 'list', 'drain', 'replay-dlq'];
  if (!validKinds.includes(obj.kind as RequestKind)) {
    throw new WireError('UNKNOWN_KIND', `unknown request kind: ${obj.kind}`);
  }
}

// --- Handshake ---

export function handshakeBytes(): Buffer {
  return Buffer.from([PROTOCOL_VERSION]);
}

export function checkHandshake(received: Buffer): { ok: boolean; theirVersion: number } {
  if (received.byteLength < 1) return { ok: false, theirVersion: 0 };
  const v = received[0]!;
  return { ok: v === PROTOCOL_VERSION, theirVersion: v };
}
