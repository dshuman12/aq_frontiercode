import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { WireError } from '@tideway/failure';
import {
  FrameReassembler,
  PROTOCOL_VERSION,
  checkHandshake,
  decodeFrame,
  decodeRequest,
  decodeResponse,
  encodeFrame,
  encodeRequest,
  encodeResponse,
  handshakeBytes,
  type Request,
} from '../src/index.ts';

describe('encodeFrame / decodeFrame', () => {
  it('round-trips a small frame', () => {
    const body = Buffer.from('hello', 'utf8');
    const frame = encodeFrame(body);
    const r = decodeFrame(frame);
    assert.ok(!('partial' in r));
    if (!('partial' in r)) {
      assert.equal(r.body.toString('utf8'), 'hello');
      assert.equal(r.consumed, frame.byteLength);
    }
  });

  it('decode reports partial when fewer than 4 header bytes', () => {
    const r = decodeFrame(Buffer.from([0, 0]));
    assert.deepEqual(r, { partial: true });
  });

  it('decode reports partial when body is incomplete', () => {
    const frame = encodeFrame(Buffer.from('hello'));
    const truncated = frame.subarray(0, frame.byteLength - 1);
    const r = decodeFrame(truncated);
    assert.deepEqual(r, { partial: true });
  });

  it('encode rejects oversize frames', () => {
    const body = Buffer.alloc(2 * 1024 * 1024);
    assert.throws(() => encodeFrame(body), WireError);
  });

  it('decode rejects frames whose header claims oversize length', () => {
    const header = Buffer.alloc(4);
    header.writeUInt32BE(2 * 1024 * 1024, 0);
    assert.throws(() => decodeFrame(header), WireError);
  });
});

describe('FrameReassembler', () => {
  it('yields a frame split across two pushes', () => {
    const r = new FrameReassembler();
    const frame = encodeFrame(Buffer.from('hello'));
    const half = Math.floor(frame.byteLength / 2);
    assert.deepEqual(r.push(frame.subarray(0, half)), []);
    const yielded = r.push(frame.subarray(half));
    assert.equal(yielded.length, 1);
    assert.equal(yielded[0]!.toString('utf8'), 'hello');
  });

  it('yields multiple frames in one push', () => {
    const r = new FrameReassembler();
    const a = encodeFrame(Buffer.from('one'));
    const b = encodeFrame(Buffer.from('two'));
    const yielded = r.push(Buffer.concat([a, b]));
    assert.equal(yielded.length, 2);
    assert.equal(yielded[0]!.toString('utf8'), 'one');
    assert.equal(yielded[1]!.toString('utf8'), 'two');
  });

  it('keeps tail bytes for the next call', () => {
    const r = new FrameReassembler();
    const a = encodeFrame(Buffer.from('one'));
    const b = encodeFrame(Buffer.from('two'));
    const combined = Buffer.concat([a, b]);
    // Cut between the two frames partway into b's header.
    const cut = a.byteLength + 2;
    const yielded1 = r.push(combined.subarray(0, cut));
    assert.equal(yielded1.length, 1);
    assert.ok(r.pending() > 0);
    const yielded2 = r.push(combined.subarray(cut));
    assert.equal(yielded2.length, 1);
    assert.equal(yielded2[0]!.toString('utf8'), 'two');
  });
});

describe('encodeRequest / decodeRequest', () => {
  it('round-trips a submit request', () => {
    const req: Request = {
      kind: 'submit',
      handler: 'send-email',
      input: { to: 'a@b.c' },
      idempotencyKey: 'order-37',
    };
    const frame = encodeRequest(req);
    const decoded = decodeRequest(decodeAndUnframe(frame));
    assert.deepEqual(decoded, req);
  });

  it('round-trips a status request', () => {
    const req: Request = { kind: 'status', runId: 'r-1' };
    const frame = encodeRequest(req);
    const decoded = decodeRequest(decodeAndUnframe(frame));
    assert.deepEqual(decoded, req);
  });

  it('round-trips a list request with all fields', () => {
    const req: Request = { kind: 'list', state: 'running', limit: 50 };
    const frame = encodeRequest(req);
    const decoded = decodeRequest(decodeAndUnframe(frame));
    assert.deepEqual(decoded, req);
  });

  it('decode rejects bad JSON', () => {
    assert.throws(() => decodeRequest(Buffer.from('{not-json}')), WireError);
  });

  it('decode rejects missing kind', () => {
    assert.throws(() => decodeRequest(Buffer.from('{"foo":"bar"}')), WireError);
  });

  it('decode rejects unknown kind', () => {
    assert.throws(() => decodeRequest(Buffer.from('{"kind":"obliterate"}')), WireError);
  });

  it('decode rejects non-object', () => {
    assert.throws(() => decodeRequest(Buffer.from('"a string"')), WireError);
  });
});

describe('encodeResponse / decodeResponse', () => {
  it('round-trips a success response', () => {
    const res = { ok: true, body: { runId: 'r-1' } };
    const frame = encodeResponse(res);
    const decoded = decodeResponse(decodeAndUnframe(frame));
    assert.deepEqual(decoded, res);
  });

  it('round-trips an error response', () => {
    const res = { ok: false, error: { code: 'NOT_FOUND', message: 'no such run' } };
    const frame = encodeResponse(res);
    const decoded = decodeResponse(decodeAndUnframe(frame));
    assert.deepEqual(decoded, res);
  });

  it('decode rejects bad JSON', () => {
    assert.throws(() => decodeResponse(Buffer.from('{nope')), WireError);
  });

  it('decode rejects missing ok field', () => {
    assert.throws(() => decodeResponse(Buffer.from('{"body":1}')), WireError);
  });
});

describe('handshake', () => {
  it('handshakeBytes produces a single byte equal to PROTOCOL_VERSION', () => {
    const b = handshakeBytes();
    assert.equal(b.byteLength, 1);
    assert.equal(b[0], PROTOCOL_VERSION);
  });

  it('checkHandshake accepts our version', () => {
    const r = checkHandshake(handshakeBytes());
    assert.equal(r.ok, true);
    assert.equal(r.theirVersion, PROTOCOL_VERSION);
  });

  it('checkHandshake rejects another version', () => {
    const r = checkHandshake(Buffer.from([99]));
    assert.equal(r.ok, false);
    assert.equal(r.theirVersion, 99);
  });

  it('checkHandshake on empty buffer is rejected', () => {
    const r = checkHandshake(Buffer.alloc(0));
    assert.equal(r.ok, false);
  });
});

// Helper: a frame contains a length prefix, but the codec tests above
// pass body buffers (post-unwrap) through decodeRequest/Response. We
// re-unwrap the frame here when round-tripping through encodeRequest.
function decodeAndUnframe(frame: Buffer): Buffer {
  const r = decodeFrame(frame);
  if ('partial' in r) throw new Error('test bug: partial frame');
  return r.body;
}
