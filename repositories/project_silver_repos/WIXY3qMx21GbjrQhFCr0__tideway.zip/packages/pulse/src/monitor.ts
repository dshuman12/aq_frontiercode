// Pulse: heartbeat/liveness monitoring across the runtime's internal
// loops.
//
// Each long-running loop (scheduler tick, lease reaper, outbox flush)
// records a heartbeat after each cycle. The pulse monitor watches them
// and alerts when a loop hasn't pulsed within its configured window -
// usually means the event loop is wedged or a long synchronous task
// is blocking everything else.
//
// Pulse is in-tree because it has to be: external monitoring would
// not detect "the event loop is blocked" until the kernel kills the
// process or operators notice the runner stopped responding to
// requests. Internal heartbeats make that visible from the runner's
// own metrics surface.

export interface PulseEntry {
  name: string;
  // The window of time within which the pulse must arrive. If it's been
  // longer than maxIntervalMs since the last beat, the entry is
  // considered stalled.
  maxIntervalMs: number;
  lastBeatAt: number;
  beatCount: number;
}

export type PulseStatus = 'healthy' | 'stalled';

export interface PulseSnapshot {
  name: string;
  status: PulseStatus;
  ageMs: number;
  beatCount: number;
}

export class PulseMonitor {
  private readonly entries = new Map<string, PulseEntry>();
  private readonly clock: () => number;

  constructor(opts?: { clock?: () => number }) {
    this.clock = opts?.clock ?? Date.now;
  }

  // Register a new pulse source. The first beat is implicit - we treat
  // it as just-registered so the entry doesn't immediately appear
  // stalled.
  register(name: string, maxIntervalMs: number): void {
    if (this.entries.has(name)) {
      throw new Error(`pulse already registered: ${name}`);
    }
    if (maxIntervalMs <= 0) {
      throw new RangeError(`maxIntervalMs must be > 0, got ${maxIntervalMs}`);
    }
    this.entries.set(name, {
      name,
      maxIntervalMs,
      lastBeatAt: this.clock(),
      beatCount: 0,
    });
  }

  unregister(name: string): boolean {
    return this.entries.delete(name);
  }

  // Record a beat from the named source.
  beat(name: string): void {
    const entry = this.entries.get(name);
    if (!entry) {
      // Unknown sources are silently ignored. A real production system
      // would log them; here we want pulse to be invisible to
      // unrelated callers.
      return;
    }
    entry.lastBeatAt = this.clock();
    entry.beatCount += 1;
  }

  has(name: string): boolean {
    return this.entries.has(name);
  }

  status(name: string): PulseStatus {
    const entry = this.entries.get(name);
    if (!entry) return 'healthy'; // unknown -> healthy by default
    return this.clock() - entry.lastBeatAt > entry.maxIntervalMs ? 'stalled' : 'healthy';
  }

  ageMs(name: string): number | undefined {
    const entry = this.entries.get(name);
    if (!entry) return undefined;
    return this.clock() - entry.lastBeatAt;
  }

  snapshot(): PulseSnapshot[] {
    const out: PulseSnapshot[] = [];
    const now = this.clock();
    for (const entry of this.entries.values()) {
      const age = now - entry.lastBeatAt;
      out.push({
        name: entry.name,
        status: age > entry.maxIntervalMs ? 'stalled' : 'healthy',
        ageMs: age,
        beatCount: entry.beatCount,
      });
    }
    return out;
  }

  // Aggregate worst-case across all registered sources.
  overall(): PulseStatus {
    for (const entry of this.entries.values()) {
      if (this.clock() - entry.lastBeatAt > entry.maxIntervalMs) return 'stalled';
    }
    return 'healthy';
  }

  size(): number {
    return this.entries.size;
  }
}
