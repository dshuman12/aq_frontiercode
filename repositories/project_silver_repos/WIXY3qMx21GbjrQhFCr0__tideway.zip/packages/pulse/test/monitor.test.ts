import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { PulseMonitor } from '../src/monitor.ts';

class FakeClock {
  constructor(public t = 1000) {}
  now = () => this.t;
  advance(ms: number) {
    this.t += ms;
  }
}

describe('PulseMonitor: registration', () => {
  it('starts empty', () => {
    const m = new PulseMonitor();
    assert.equal(m.size(), 0);
    assert.deepEqual(m.snapshot(), []);
  });

  it('register adds an entry', () => {
    const m = new PulseMonitor();
    m.register('scheduler', 1000);
    assert.equal(m.size(), 1);
    assert.equal(m.has('scheduler'), true);
  });

  it('register refuses duplicate name', () => {
    const m = new PulseMonitor();
    m.register('a', 1000);
    assert.throws(() => m.register('a', 1000));
  });

  it('register refuses non-positive maxInterval', () => {
    const m = new PulseMonitor();
    assert.throws(() => m.register('a', 0));
    assert.throws(() => m.register('a', -10));
  });

  it('unregister returns true on existing, false on missing', () => {
    const m = new PulseMonitor();
    m.register('a', 1000);
    assert.equal(m.unregister('a'), true);
    assert.equal(m.unregister('b'), false);
  });
});

describe('PulseMonitor: status', () => {
  it('newly-registered entry is healthy', () => {
    const c = new FakeClock(1000);
    const m = new PulseMonitor({ clock: c.now });
    m.register('a', 5000);
    assert.equal(m.status('a'), 'healthy');
  });

  it('stalls when lastBeat is older than maxInterval', () => {
    const c = new FakeClock(1000);
    const m = new PulseMonitor({ clock: c.now });
    m.register('a', 1000);
    c.advance(1500);
    assert.equal(m.status('a'), 'stalled');
  });

  it('beat resets the staleness window', () => {
    const c = new FakeClock(1000);
    const m = new PulseMonitor({ clock: c.now });
    m.register('a', 1000);
    c.advance(800);
    m.beat('a');
    c.advance(800);
    assert.equal(m.status('a'), 'healthy');
  });

  it('unknown name reports healthy by default', () => {
    const m = new PulseMonitor();
    assert.equal(m.status('ghost'), 'healthy');
  });
});

describe('PulseMonitor: beat', () => {
  it('beat on unknown is a no-op', () => {
    const m = new PulseMonitor();
    m.beat('ghost'); // should not throw
  });

  it('beat increments beatCount', () => {
    const c = new FakeClock(1000);
    const m = new PulseMonitor({ clock: c.now });
    m.register('a', 1000);
    m.beat('a');
    m.beat('a');
    m.beat('a');
    const snap = m.snapshot()[0]!;
    assert.equal(snap.beatCount, 3);
  });
});

describe('PulseMonitor: snapshot', () => {
  it('reports each entry with status, ageMs, beatCount', () => {
    const c = new FakeClock(1000);
    const m = new PulseMonitor({ clock: c.now });
    m.register('scheduler', 1000);
    m.register('reaper', 2000);
    c.advance(1500);
    m.beat('scheduler');
    const snap = m.snapshot();
    const sched = snap.find((s) => s.name === 'scheduler')!;
    assert.equal(sched.status, 'healthy');
    assert.equal(sched.ageMs, 0);
    const reaper = snap.find((s) => s.name === 'reaper')!;
    assert.equal(reaper.status, 'healthy');
    assert.equal(reaper.ageMs, 1500);
  });
});

describe('PulseMonitor: overall', () => {
  it('healthy if all healthy', () => {
    const c = new FakeClock(1000);
    const m = new PulseMonitor({ clock: c.now });
    m.register('a', 5000);
    m.register('b', 5000);
    assert.equal(m.overall(), 'healthy');
  });

  it('stalled if any stalled', () => {
    const c = new FakeClock(1000);
    const m = new PulseMonitor({ clock: c.now });
    m.register('a', 5000);
    m.register('b', 100);
    c.advance(500);
    assert.equal(m.overall(), 'stalled');
  });

  it('empty monitor is healthy', () => {
    const m = new PulseMonitor();
    assert.equal(m.overall(), 'healthy');
  });
});

describe('PulseMonitor: ageMs', () => {
  it('returns undefined for unknown name', () => {
    const m = new PulseMonitor();
    assert.equal(m.ageMs('ghost'), undefined);
  });

  it('returns the gap between now and lastBeat', () => {
    const c = new FakeClock(1000);
    const m = new PulseMonitor({ clock: c.now });
    m.register('a', 5000);
    c.advance(750);
    assert.equal(m.ageMs('a'), 750);
  });
});
