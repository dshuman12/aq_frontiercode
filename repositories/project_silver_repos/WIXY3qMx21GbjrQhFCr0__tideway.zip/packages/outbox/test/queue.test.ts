import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { OutboxQueue, type OutboxMessage } from '../src/index.ts';

const msg = (
  id: string,
  partition = 'default',
  enqueuedAt = 1000,
  body: unknown = { v: 1 },
): OutboxMessage => ({
  id,
  destination: 'wire:peer',
  body,
  partition,
  enqueuedAt,
  attempts: 0,
  nextAttemptAt: enqueuedAt,
});

describe('enqueue / size', () => {
  it('starts empty', () => {
    const q = new OutboxQueue();
    assert.equal(q.size(), 0);
  });

  it('enqueue adds to size', () => {
    const q = new OutboxQueue();
    q.enqueue(msg('m1'));
    q.enqueue(msg('m2'));
    assert.equal(q.size(), 2);
  });

  it('refuses duplicate id', () => {
    const q = new OutboxQueue();
    q.enqueue(msg('m1'));
    assert.throws(() => q.enqueue(msg('m1')));
  });
});

describe('due', () => {
  it('returns the head of every partition with work', () => {
    const q = new OutboxQueue();
    q.enqueue(msg('a1', 'p1', 100));
    q.enqueue(msg('a2', 'p1', 200)); // not due yet because a1 is head
    q.enqueue(msg('b1', 'p2', 100));
    const due = q.due(150);
    // Heads are a1 (due) and b1 (due). a2 is not at head.
    assert.deepEqual(
      due.map((m) => m.id).sort(),
      ['a1', 'b1'],
    );
  });

  it('respects nextAttemptAt for the head', () => {
    const q = new OutboxQueue();
    q.enqueue(msg('a1', 'p1', 200));
    assert.deepEqual(q.due(100), []);
    assert.deepEqual(
      q.due(200).map((m) => m.id),
      ['a1'],
    );
  });

  it('returns nothing when all partitions empty', () => {
    const q = new OutboxQueue();
    assert.deepEqual(q.due(1000), []);
  });
});

describe('ack', () => {
  it('removes the head and exposes the next', () => {
    const q = new OutboxQueue();
    q.enqueue(msg('a1', 'p1'));
    q.enqueue(msg('a2', 'p1'));
    assert.equal(q.ack('a1'), true);
    const due = q.due(2000);
    assert.deepEqual(
      due.map((m) => m.id),
      ['a2'],
    );
  });

  it('refuses to ack a non-head message', () => {
    const q = new OutboxQueue();
    q.enqueue(msg('a1', 'p1'));
    q.enqueue(msg('a2', 'p1'));
    assert.equal(q.ack('a2'), false);
  });

  it('refuses to ack unknown id', () => {
    const q = new OutboxQueue();
    assert.equal(q.ack('ghost'), false);
  });

  it('size shrinks on ack', () => {
    const q = new OutboxQueue();
    q.enqueue(msg('a1', 'p1'));
    q.ack('a1');
    assert.equal(q.size(), 0);
  });

  it('compacts the buffer after many acks', () => {
    const q = new OutboxQueue();
    for (let i = 0; i < 100; i += 1) q.enqueue(msg(`m${i}`, 'p1'));
    for (let i = 0; i < 80; i += 1) q.ack(`m${i}`);
    // Internal compaction should have happened; remaining size = 20.
    assert.equal(q.size(), 20);
    const remaining = q.listPartition('p1').map((m) => m.id);
    assert.equal(remaining.length, 20);
    assert.equal(remaining[0], 'm80');
  });
});

describe('nack', () => {
  it('bumps attempts and schedules retry', () => {
    const q = new OutboxQueue();
    q.enqueue(msg('a1', 'p1', 100));
    const r = q.nack('a1', { now: 200, retryDelay: 500, maxAttempts: 5, reason: 'boom' });
    assert.equal(r.quarantined, false);
    const due = q.due(300);
    assert.equal(due.length, 0);
    const dueLater = q.due(700);
    assert.deepEqual(
      dueLater.map((m) => m.id),
      ['a1'],
    );
  });

  it('quarantines after maxAttempts', () => {
    const q = new OutboxQueue();
    q.enqueue(msg('a1', 'p1'));
    let r;
    for (let i = 0; i < 3; i += 1) {
      r = q.nack('a1', { now: i * 1000, retryDelay: 100, maxAttempts: 3, reason: 'r' });
    }
    assert.equal(r!.quarantined, true);
    assert.equal(q.size(), 0);
    assert.equal(q.quarantineSize(), 1);
  });

  it('quarantine pops from partition head', () => {
    const q = new OutboxQueue();
    q.enqueue(msg('a1', 'p1'));
    q.enqueue(msg('a2', 'p1'));
    for (let i = 0; i < 3; i += 1) {
      q.nack('a1', { now: i * 1000, retryDelay: 100, maxAttempts: 3, reason: 'r' });
    }
    // a1 is quarantined; a2 should now be at head.
    const due = q.due(10_000);
    assert.deepEqual(
      due.map((m) => m.id),
      ['a2'],
    );
  });

  it('nack on unknown id is a no-op', () => {
    const q = new OutboxQueue();
    const r = q.nack('ghost', { now: 0, retryDelay: 100, maxAttempts: 3, reason: 'r' });
    assert.equal(r.quarantined, false);
  });
});

describe('quarantine inspection / rehabilitation / drop', () => {
  it('rehabilitate brings a quarantined back with attempts=0', () => {
    const q = new OutboxQueue();
    q.enqueue(msg('a1', 'p1'));
    for (let i = 0; i < 3; i += 1) {
      q.nack('a1', { now: i * 1000, retryDelay: 100, maxAttempts: 3, reason: 'r' });
    }
    assert.equal(q.rehabilitate('a1'), true);
    const due = q.due(10_000);
    assert.equal(due.length, 1);
    assert.equal(due[0]!.attempts, 0);
  });

  it('rehabilitate on unknown returns false', () => {
    const q = new OutboxQueue();
    assert.equal(q.rehabilitate('ghost'), false);
  });

  it('dropQuarantined removes the entry permanently', () => {
    const q = new OutboxQueue();
    q.enqueue(msg('a1', 'p1'));
    for (let i = 0; i < 3; i += 1) {
      q.nack('a1', { now: i * 1000, retryDelay: 100, maxAttempts: 3, reason: 'r' });
    }
    assert.equal(q.dropQuarantined('a1'), true);
    assert.equal(q.quarantineSize(), 0);
  });

  it('inspectQuarantine returns all quarantined messages', () => {
    const q = new OutboxQueue();
    q.enqueue(msg('a', 'p'));
    q.enqueue(msg('b', 'p'));
    for (let i = 0; i < 3; i += 1) q.nack('a', { now: 0, retryDelay: 1, maxAttempts: 3, reason: '' });
    // Now b is head; quarantine 'b' too.
    for (let i = 0; i < 3; i += 1) q.nack('b', { now: 0, retryDelay: 1, maxAttempts: 3, reason: '' });
    const list = q.inspectQuarantine();
    assert.equal(list.length, 2);
  });
});

describe('partitions', () => {
  it('cross-partition messages are independently due', () => {
    const q = new OutboxQueue();
    q.enqueue(msg('a', 'p1', 100));
    q.enqueue(msg('b', 'p2', 100));
    const due = q.due(150);
    assert.deepEqual(
      due.map((m) => m.id).sort(),
      ['a', 'b'],
    );
  });

  it('listPartition shows undelivered tail', () => {
    const q = new OutboxQueue();
    q.enqueue(msg('a', 'p1'));
    q.enqueue(msg('b', 'p1'));
    q.ack('a');
    const remaining = q.listPartition('p1').map((m) => m.id);
    assert.deepEqual(remaining, ['b']);
  });

  it('partitions_() lists known partition names', () => {
    const q = new OutboxQueue();
    q.enqueue(msg('a', 'p1'));
    q.enqueue(msg('b', 'p2'));
    assert.deepEqual(q.partitions_().sort(), ['p1', 'p2']);
  });
});
