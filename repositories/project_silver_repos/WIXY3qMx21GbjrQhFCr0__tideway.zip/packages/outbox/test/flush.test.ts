import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { OutboxQueue, flush, type OutboxMessage, type Sink } from '../src/index.ts';

const msg = (id: string, partition = 'default'): OutboxMessage => ({
  id,
  destination: 'sink',
  body: { id },
  partition,
  enqueuedAt: 0,
  attempts: 0,
  nextAttemptAt: 0,
});

describe('flush: happy path', () => {
  it('delivers all due messages and returns their ids', async () => {
    const q = new OutboxQueue();
    q.enqueue(msg('a', 'p1'));
    q.enqueue(msg('b', 'p2'));
    const seen: string[] = [];
    const sink: Sink = (m) => {
      seen.push(m.id);
    };
    const r = await flush(q, sink, { now: 100 });
    assert.deepEqual(r.delivered.sort(), ['a', 'b']);
    assert.equal(r.failed.length, 0);
    assert.deepEqual(seen.sort(), ['a', 'b']);
    assert.equal(q.size(), 0);
  });

  it('respects batchSize', async () => {
    const q = new OutboxQueue();
    for (let i = 0; i < 10; i += 1) q.enqueue(msg(`m${i}`, `p${i}`));
    const sink: Sink = () => undefined;
    const r = await flush(q, sink, { now: 100, batchSize: 3 });
    assert.equal(r.delivered.length, 3);
    assert.equal(q.size(), 7);
  });

  it('does NOT touch messages that are not due', async () => {
    const q = new OutboxQueue();
    q.enqueue({ ...msg('a'), nextAttemptAt: 5000 });
    const sink: Sink = () => {
      throw new Error('should not be called');
    };
    const r = await flush(q, sink, { now: 1000 });
    assert.equal(r.delivered.length, 0);
    assert.equal(q.size(), 1);
  });
});

describe('flush: failure path', () => {
  it('failures move to nack, not quarantine, on first try', async () => {
    const q = new OutboxQueue();
    q.enqueue(msg('a'));
    const sink: Sink = () => {
      throw new Error('temporary');
    };
    const r = await flush(q, sink, { now: 100, retryDelayMs: 500, maxAttempts: 3 });
    assert.equal(r.failed.length, 1);
    assert.equal(r.failed[0]!.reason, 'temporary');
    assert.equal(q.size(), 1);
    assert.equal(q.quarantineSize(), 0);
  });

  it('failures eventually quarantine after maxAttempts', async () => {
    const q = new OutboxQueue();
    q.enqueue(msg('a'));
    const sink: Sink = () => {
      throw new Error('still bad');
    };
    for (let i = 0; i < 3; i += 1) {
      await flush(q, sink, { now: i * 1000, retryDelayMs: 0, maxAttempts: 3 });
    }
    assert.equal(q.size(), 0);
    assert.equal(q.quarantineSize(), 1);
  });

  it('failure on partition head blocks subsequent messages in that partition', async () => {
    const q = new OutboxQueue();
    q.enqueue(msg('a1', 'p1'));
    q.enqueue(msg('a2', 'p1'));
    let calls = 0;
    const sink: Sink = (m) => {
      calls += 1;
      if (m.id === 'a1') throw new Error('head failed');
    };
    await flush(q, sink, { now: 100, retryDelayMs: 1000, maxAttempts: 5 });
    assert.equal(calls, 1); // a2 was NOT attempted
  });

  it('failure on one partition does NOT block another', async () => {
    const q = new OutboxQueue();
    q.enqueue(msg('a', 'p-bad'));
    q.enqueue(msg('b', 'p-good'));
    const sink: Sink = (m) => {
      if (m.partition === 'p-bad') throw new Error('badness');
    };
    const r = await flush(q, sink, { now: 100, retryDelayMs: 1000, maxAttempts: 5 });
    assert.deepEqual(r.delivered, ['b']);
    assert.equal(r.failed.length, 1);
    assert.equal(q.size(), 1);
  });
});

describe('flush: idempotence', () => {
  it('replaying a flush after a delivered ack is a no-op for that id', async () => {
    const q = new OutboxQueue();
    q.enqueue(msg('a'));
    const sink: Sink = () => undefined;
    const r1 = await flush(q, sink, { now: 100 });
    const r2 = await flush(q, sink, { now: 200 });
    assert.deepEqual(r1.delivered, ['a']);
    assert.deepEqual(r2.delivered, []);
  });
});
