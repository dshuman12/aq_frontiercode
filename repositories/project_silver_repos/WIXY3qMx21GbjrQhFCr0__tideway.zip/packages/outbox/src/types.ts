// Outbox types. Side-effects in tideway are emitted as `OutboxMessage`s
// inside the same transaction that updates the run's state. A flush loop
// drains them later, providing at-least-once delivery to the eventual
// consumer (the wire layer for cross-process messages, or a local
// callback for in-process messages).

export type MessageId = string;

export interface OutboxMessage {
  id: MessageId;
  // Logical destination. Examples: "wire:peer-A", "callback:on-job-done",
  // "tracing:span-finish". The dispatcher routes by prefix.
  destination: string;
  // The opaque body. Outbox doesn't care about the shape; the destination
  // handler does.
  body: unknown;
  // Idempotency partition for ordered delivery. Messages with the same
  // partition are delivered in insertion order; different partitions can
  // be delivered concurrently. Default: "default".
  partition: string;
  enqueuedAt: number;
  // attempts: incremented on each unsuccessful flush.
  attempts: number;
  // nextAttemptAt: when the flush loop should next try this message.
  nextAttemptAt: number;
}

export interface FlushResult {
  delivered: MessageId[];
  failed: { id: MessageId; reason: string }[];
}

// A `Sink` is what the flush loop calls to actually deliver. Sinks are
// not part of this package; this is the type contract.
export type Sink = (msg: OutboxMessage) => Promise<void> | void;
