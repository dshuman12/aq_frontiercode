// Outbox flush loop.
//
// Pulls messages whose nextAttemptAt has come due, calls the configured
// sink, then ack/nack based on the outcome. Errors thrown by the sink
// turn into nack with the error message as the reason.
//
// The flush function below is a single pass; the runner schedules it
// repeatedly via setInterval. We keep the loop logic out of this
// package because timer ownership belongs to the runner (which already
// owns the lifecycle of every long-running thing).

import type { FlushResult, MessageId, Sink } from './types.ts';
import type { OutboxQueue } from './queue.ts';

export interface FlushOptions {
  now: number;
  // Maximum messages to attempt in this pass. The runner calls flush
  // repeatedly; bounding per-call work prevents one slow sink from
  // monopolizing the event loop.
  batchSize?: number;
  retryDelayMs?: number;
  maxAttempts?: number;
}

export async function flush(queue: OutboxQueue, sink: Sink, opts: FlushOptions): Promise<FlushResult> {
  const batchSize = opts.batchSize ?? 64;
  const retryDelay = opts.retryDelayMs ?? 1000;
  const maxAttempts = opts.maxAttempts ?? 5;

  const due = queue.due(opts.now).slice(0, batchSize);
  const delivered: MessageId[] = [];
  const failed: { id: MessageId; reason: string }[] = [];

  // Group by partition so we can dispatch partitions in parallel but
  // preserve sequential delivery within each partition.
  const byPartition = new Map<string, typeof due>();
  for (const msg of due) {
    let arr = byPartition.get(msg.partition);
    if (!arr) {
      arr = [];
      byPartition.set(msg.partition, arr);
    }
    arr.push(msg);
  }

  // Within a partition, deliver one at a time. Across partitions, dispatch
  // concurrently.
  //
  // FIXME: this is fine for partition counts up to ~100. Above that, we
  // should batch the per-partition Promise.all() calls so we don't fan
  // out 1000 concurrent sink calls. Hasn't been a real problem; deferred.
  await Promise.all(
    Array.from(byPartition.values()).map(async (msgs) => {
      for (const msg of msgs) {
        try {
          await sink(msg);
          if (queue.ack(msg.id)) delivered.push(msg.id);
          else {
            // Ack returned false. This means the message was no longer at
            // the head when we got here -- another flush call interleaved.
            // Treat as a no-op; the next flush will pick up the new head.
          }
        } catch (err) {
          const reason = err instanceof Error ? err.message : String(err);
          queue.nack(msg.id, { now: opts.now, retryDelay, maxAttempts, reason });
          failed.push({ id: msg.id, reason });
          // Stop processing this partition on first failure; subsequent
          // messages in the partition must wait until the head is drained
          // (otherwise we'd violate per-partition ordering).
          break;
        }
      }
    }),
  );

  return { delivered, failed };
}
