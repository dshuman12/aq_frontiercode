export type { MessageId, OutboxMessage, FlushResult, Sink } from './types.ts';
export { OutboxQueue } from './queue.ts';
export { flush, type FlushOptions } from './flush.ts';
