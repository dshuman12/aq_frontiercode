// In-memory outbox queue.
//
// Messages are stored partitioned. Within a partition, delivery is
// sequential (we never advance to the next message until the prior one
// is delivered or quarantined). Across partitions, delivery is
// concurrent.
//
// The flush loop is implemented in `flush.ts`; this module just owns the
// queue state.

import type { MessageId, OutboxMessage } from './types.ts';

// Internal: each partition is a doubly-linked-list-style array (we use a
// plain array because the message volumes we deal with are small enough
// that O(n) head-removal is fine). The `head` pointer is the index of the
// first undelivered message; `tail` is the array length.
interface Partition {
  buf: OutboxMessage[];
  head: number;
}

export class OutboxQueue {
  private readonly partitions = new Map<string, Partition>();
  private readonly byId = new Map<MessageId, OutboxMessage>();
  // Quarantine for messages that have failed more than the budget; the
  // operator inspects via the console and decides whether to retry or
  // drop. We keep them out of the main `partitions` so the flush loop
  // doesn't keep retrying.
  private readonly quarantined = new Map<MessageId, OutboxMessage>();

  enqueue(msg: OutboxMessage): void {
    if (this.byId.has(msg.id)) {
      throw new Error(`duplicate outbox id: ${msg.id}`);
    }
    let part = this.partitions.get(msg.partition);
    if (!part) {
      part = { buf: [], head: 0 };
      this.partitions.set(msg.partition, part);
    }
    part.buf.push(msg);
    this.byId.set(msg.id, msg);
  }

  // Get the head of every partition that has work due (nextAttemptAt <=
  // now). The flush loop calls this once per tick and dispatches to sinks.
  due(now: number): OutboxMessage[] {
    const out: OutboxMessage[] = [];
    for (const part of this.partitions.values()) {
      const head = part.buf[part.head];
      if (head && head.nextAttemptAt <= now) {
        out.push(head);
      }
    }
    return out;
  }

  // Mark delivered: pops from its partition. Returns true if the message
  // was at a head position and was removed; false otherwise (which
  // probably means a duplicate ack arrived).
  ack(id: MessageId): boolean {
    const msg = this.byId.get(id);
    if (!msg) return false;
    const part = this.partitions.get(msg.partition);
    if (!part) return false;
    if (part.buf[part.head]?.id !== id) return false;
    part.head += 1;
    this.byId.delete(id);
    // Compact when the head has wandered far. We don't compact every ack
    // because that's O(n) and the head-pointer scheme keeps memory usage
    // bounded already; we only compact when waste exceeds a threshold.
    if (part.head > 32 && part.head > part.buf.length / 2) {
      part.buf = part.buf.slice(part.head);
      part.head = 0;
    }
    return true;
  }

  // Mark a delivery attempt failed. Bumps attempts, schedules a retry
  // via `nextAttemptAt = now + retryDelay`. If attempts >= maxAttempts,
  // moves to quarantine.
  nack(
    id: MessageId,
    opts: { now: number; retryDelay: number; maxAttempts: number; reason: string },
  ): { quarantined: boolean } {
    const msg = this.byId.get(id);
    if (!msg) return { quarantined: false };
    msg.attempts += 1;
    if (msg.attempts >= opts.maxAttempts) {
      // Quarantine.
      const part = this.partitions.get(msg.partition);
      if (part && part.buf[part.head]?.id === id) {
        part.head += 1;
      }
      this.byId.delete(id);
      this.quarantined.set(id, msg);
      return { quarantined: true };
    }
    msg.nextAttemptAt = opts.now + opts.retryDelay;
    return { quarantined: false };
  }

  size(): number {
    return this.byId.size;
  }

  quarantineSize(): number {
    return this.quarantined.size;
  }

  inspectQuarantine(): OutboxMessage[] {
    return Array.from(this.quarantined.values());
  }

  // Operator action: pull a quarantined message back into its partition
  // with a fresh attempt count. Returns false if the id isn't in
  // quarantine.
  rehabilitate(id: MessageId): boolean {
    const msg = this.quarantined.get(id);
    if (!msg) return false;
    this.quarantined.delete(id);
    msg.attempts = 0;
    msg.nextAttemptAt = 0;
    let part = this.partitions.get(msg.partition);
    if (!part) {
      part = { buf: [], head: 0 };
      this.partitions.set(msg.partition, part);
    }
    part.buf.push(msg);
    this.byId.set(msg.id, msg);
    return true;
  }

  // Drop quarantined message. Returns true if dropped.
  dropQuarantined(id: MessageId): boolean {
    return this.quarantined.delete(id);
  }

  // Listing helpers. These are O(n) and only used by tooling, so the
  // cost is acceptable.
  listPartition(partition: string): OutboxMessage[] {
    const part = this.partitions.get(partition);
    if (!part) return [];
    return part.buf.slice(part.head);
  }

  partitions_(): string[] {
    return Array.from(this.partitions.keys());
  }
}
