// Compute the next moment a cron expression would fire.
//
// We work in UTC to avoid the worst of the DST tarpit. If a caller wants
// "9am New York time every weekday", they translate the wall-clock time
// to a UTC offset themselves and pass that to the cron expression. The
// runner doesn't try to be clever about local time because doing so
// correctly requires a tz database we don't want to depend on.
//
// FIXME: there's a corner case where a cron with day-of-month = 31 and
// month = 4 (a 30-day month) iterates the full 5 years before returning
// null. We could short-circuit by precomputing which (month, dom) pairs
// are unreachable, but the saving is microseconds per call and I haven't
// been bitten by it in practice.
//
// The algorithm is straightforward "find smallest valid (Y, M, D, H, m)
// strictly greater than `from`". We bound iteration at +5 years; if we
// can't find a match by then the expression is unsatisfiable for this
// year cycle (which can happen with day=31 month=2, for instance).

import type { CronExpression } from './parser.ts';

export function nextFireAfter(expr: CronExpression, from: Date): Date | null {
  // Move to the next minute boundary so we don't fire at the exact
  // moment we were called.
  const start = new Date(from.getTime());
  start.setUTCSeconds(0, 0);
  start.setUTCMinutes(start.getUTCMinutes() + 1);

  const limit = new Date(start.getTime());
  limit.setUTCFullYear(limit.getUTCFullYear() + 5);

  // We iterate forward through candidate minutes in a structured way:
  // outer-most year/month, then day, then hour, then minute. Each level
  // jumps to the next legal value rather than incrementing by one.

  for (let cur = new Date(start.getTime()); cur < limit; ) {
    const month = cur.getUTCMonth() + 1;
    if (!expr.month.includes(month)) {
      // Skip to first day of next legal month.
      const nextMonth = nextValueOrWrap(expr.month, month);
      if (nextMonth.value === month) break;
      if (nextMonth.wrapped) {
        cur = new Date(Date.UTC(cur.getUTCFullYear() + 1, nextMonth.value - 1, 1, 0, 0, 0));
      } else {
        cur = new Date(Date.UTC(cur.getUTCFullYear(), nextMonth.value - 1, 1, 0, 0, 0));
      }
      continue;
    }
    const day = cur.getUTCDate();
    const wd = cur.getUTCDay();
    if (!expr.day.includes(day) || !expr.weekday.includes(wd)) {
      // Move to next day; if month boundary crossed, we'll re-check above.
      cur = new Date(Date.UTC(cur.getUTCFullYear(), cur.getUTCMonth(), day + 1, 0, 0, 0));
      continue;
    }
    const hour = cur.getUTCHours();
    if (!expr.hour.includes(hour)) {
      const nextHour = nextValueOrWrap(expr.hour, hour);
      if (nextHour.wrapped) {
        // Roll to next day.
        cur = new Date(Date.UTC(cur.getUTCFullYear(), cur.getUTCMonth(), day + 1, 0, 0, 0));
      } else {
        cur = new Date(Date.UTC(cur.getUTCFullYear(), cur.getUTCMonth(), day, nextHour.value, 0, 0));
      }
      continue;
    }
    const minute = cur.getUTCMinutes();
    if (!expr.minute.includes(minute)) {
      const nextMinute = nextValueOrWrap(expr.minute, minute);
      if (nextMinute.wrapped) {
        // Roll to next hour.
        cur = new Date(Date.UTC(cur.getUTCFullYear(), cur.getUTCMonth(), day, hour + 1, 0, 0));
      } else {
        cur = new Date(Date.UTC(cur.getUTCFullYear(), cur.getUTCMonth(), day, hour, nextMinute.value, 0));
      }
      continue;
    }
    return cur;
  }
  return null;
}

// Find the smallest value in `values` >= `current`. If none exists,
// returns the smallest value in the set with wrapped=true, signaling
// that the caller should advance the next-coarser unit.
function nextValueOrWrap(values: number[], current: number): { value: number; wrapped: boolean } {
  for (const v of values) {
    if (v >= current) return { value: v, wrapped: false };
  }
  return { value: values[0]!, wrapped: true };
}

// Convenience: the next N firings, useful for "show me the upcoming
// schedule" displays in the console.
export function upcomingFirings(expr: CronExpression, after: Date, n: number): Date[] {
  const out: Date[] = [];
  let cur = new Date(after.getTime());
  for (let i = 0; i < n; i += 1) {
    const next = nextFireAfter(expr, cur);
    if (!next) return out;
    out.push(next);
    cur = next;
  }
  return out;
}
