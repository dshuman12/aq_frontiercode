// Cron expression parser.
//
// Accepts the classical 5-field form:
//   minute  hour  day-of-month  month  day-of-week
//
// Each field supports:
//   *           any value
//   N           a single value
//   N-M         inclusive range
//   N,M,K       discrete list
//   */S         step starting at field min, every S
//   N/S         step starting at N, every S
//   N-M/S       step within range, every S
//
// We deliberately do NOT support:
//   - 6-field (with seconds) or 7-field (with year)
//   - "L" / "W" / "#" extensions
//   - Named months/days ("JAN", "MON")
//
// The reasoning is in docs/rfcs/0011-cron-semantics.md: the named
// extensions interact badly with locale handling, and supporting them
// without bugs is a research project on its own. Five fields, numeric
// only, no surprises.

export interface CronExpression {
  // Each field is a sorted set of allowed values (no duplicates).
  minute: number[]; // 0-59
  hour: number[]; // 0-23
  day: number[]; // 1-31
  month: number[]; // 1-12
  weekday: number[]; // 0-6, Sunday = 0
  // The original source string, preserved for error messages and tests.
  source: string;
}

const FIELD_BOUNDS: Array<[number, number]> = [
  [0, 59],
  [0, 23],
  [1, 31],
  [1, 12],
  [0, 6],
];

export class CronParseError extends Error {
  override readonly name = 'CronParseError';
}

export function parse(source: string): CronExpression {
  const trimmed = source.trim();
  if (!trimmed) throw new CronParseError('empty cron expression');
  const parts = trimmed.split(/\s+/);
  if (parts.length !== 5) {
    throw new CronParseError(
      `expected 5 fields (minute hour day month weekday), got ${parts.length}: "${source}"`,
    );
  }
  const [minute, hour, day, month, weekday] = parts.map((p, i) => parseField(p, FIELD_BOUNDS[i]!));
  return {
    minute: minute!,
    hour: hour!,
    day: day!,
    month: month!,
    weekday: weekday!,
    source: trimmed,
  };
}

function parseField(field: string, bounds: [number, number]): number[] {
  const [min, max] = bounds;
  const values = new Set<number>();
  for (const piece of field.split(',')) {
    expandPiece(piece, min, max, values);
  }
  if (values.size === 0) {
    throw new CronParseError(`empty field after parse: "${field}"`);
  }
  return Array.from(values).sort((a, b) => a - b);
}

function expandPiece(piece: string, min: number, max: number, into: Set<number>): void {
  // Step form: <range>/<step>
  let step = 1;
  let rangePart = piece;
  const slash = piece.indexOf('/');
  if (slash >= 0) {
    rangePart = piece.slice(0, slash);
    const stepStr = piece.slice(slash + 1);
    if (!/^[0-9]+$/.test(stepStr)) {
      throw new CronParseError(`invalid step: "${piece}"`);
    }
    step = Number(stepStr);
    if (step <= 0) throw new CronParseError(`step must be > 0: "${piece}"`);
  }
  let lo = min;
  let hi = max;
  if (rangePart === '' || rangePart === '*') {
    // entire range
  } else if (rangePart.includes('-')) {
    const [loStr, hiStr] = rangePart.split('-');
    if (loStr === undefined || hiStr === undefined) throw new CronParseError(`bad range: "${piece}"`);
    if (!/^[0-9]+$/.test(loStr) || !/^[0-9]+$/.test(hiStr)) {
      throw new CronParseError(`bad range: "${piece}"`);
    }
    lo = Number(loStr);
    hi = Number(hiStr);
    if (lo < min || lo > max || hi < min || hi > max) {
      throw new CronParseError(`out-of-bounds range "${piece}" (allowed ${min}-${max})`);
    }
    if (lo > hi) throw new CronParseError(`reversed range: "${piece}"`);
  } else {
    if (!/^[0-9]+$/.test(rangePart)) throw new CronParseError(`invalid value: "${piece}"`);
    const v = Number(rangePart);
    if (v < min || v > max) throw new CronParseError(`out-of-bounds: "${piece}" (allowed ${min}-${max})`);
    if (slash >= 0) {
      // N/S form means "starting at N, every S, up to max"
      lo = v;
      hi = max;
    } else {
      into.add(v);
      return;
    }
  }
  for (let v = lo; v <= hi; v += step) into.add(v);
}

export function describe(expr: CronExpression): string {
  const allMins = expr.minute.length === 60;
  const allHours = expr.hour.length === 24;
  if (allMins && allHours) return 'every minute';
  if (expr.minute.length === 1 && allHours) return `at minute ${expr.minute[0]} of every hour`;
  if (expr.minute.length === 1 && expr.hour.length === 1) {
    return `daily at ${pad2(expr.hour[0]!)}:${pad2(expr.minute[0]!)}`;
  }
  return `cron(${expr.source})`;
}

function pad2(n: number): string {
  return n < 10 ? `0${n}` : `${n}`;
}
