import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { CronParseError, parse, describe as describeExpr } from '../src/parser.ts';

describe('parse: simple', () => {
  it('parses "0 0 * * *" (daily at midnight UTC)', () => {
    const e = parse('0 0 * * *');
    assert.deepEqual(e.minute, [0]);
    assert.deepEqual(e.hour, [0]);
    assert.equal(e.day.length, 31);
    assert.equal(e.month.length, 12);
    assert.equal(e.weekday.length, 7);
  });

  it('parses "* * * * *" as everything', () => {
    const e = parse('* * * * *');
    assert.equal(e.minute.length, 60);
    assert.equal(e.hour.length, 24);
  });

  it('parses a single specific value in each field', () => {
    const e = parse('5 13 1 6 3');
    assert.deepEqual(e.minute, [5]);
    assert.deepEqual(e.hour, [13]);
    assert.deepEqual(e.day, [1]);
    assert.deepEqual(e.month, [6]);
    assert.deepEqual(e.weekday, [3]);
  });
});

describe('parse: lists, ranges, steps', () => {
  it('parses comma list "5,10,15 * * * *"', () => {
    const e = parse('5,10,15 * * * *');
    assert.deepEqual(e.minute, [5, 10, 15]);
  });

  it('parses range "10-15 * * * *"', () => {
    const e = parse('10-15 * * * *');
    assert.deepEqual(e.minute, [10, 11, 12, 13, 14, 15]);
  });

  it('parses step "*/15 * * * *"', () => {
    const e = parse('*/15 * * * *');
    assert.deepEqual(e.minute, [0, 15, 30, 45]);
  });

  it('parses range step "10-30/5 * * * *"', () => {
    const e = parse('10-30/5 * * * *');
    assert.deepEqual(e.minute, [10, 15, 20, 25, 30]);
  });

  it('parses N/S form "10/15 * * * *"', () => {
    const e = parse('10/15 * * * *');
    assert.deepEqual(e.minute, [10, 25, 40, 55]);
  });

  it('parses combined "0,30 9-17/2 * * 1-5"', () => {
    const e = parse('0,30 9-17/2 * * 1-5');
    assert.deepEqual(e.minute, [0, 30]);
    assert.deepEqual(e.hour, [9, 11, 13, 15, 17]);
    assert.deepEqual(e.weekday, [1, 2, 3, 4, 5]);
  });

  it('deduplicates overlapping list entries', () => {
    const e = parse('5,5,5,5 * * * *');
    assert.deepEqual(e.minute, [5]);
  });
});

describe('parse: errors', () => {
  it('rejects empty', () => {
    assert.throws(() => parse(''), CronParseError);
    assert.throws(() => parse('   '), CronParseError);
  });

  it('fails on fewer than 5 fields', () => {
    assert.throws(() => parse('* * * *'), CronParseError);
  });

  it('bails on more than 5 fields', () => {
    assert.throws(() => parse('* * * * * *'), CronParseError);
  });

  it('complains about out-of-range minute', () => {
    assert.throws(() => parse('60 * * * *'), CronParseError);
  });

  it('refuses out-of-range hour', () => {
    assert.throws(() => parse('* 24 * * *'), CronParseError);
  });

  it('blows up on day=0 (1-based)', () => {
    assert.throws(() => parse('* * 0 * *'), CronParseError);
  });

  it('errors on month=13', () => {
    assert.throws(() => parse('* * * 13 *'), CronParseError);
  });

  it('throws on weekday=7 (we use 0-6)', () => {
    assert.throws(() => parse('* * * * 7'), CronParseError);
  });

  it('fails on reversed range', () => {
    assert.throws(() => parse('30-10 * * * *'), CronParseError);
  });

  it('fails on step=0', () => {
    assert.throws(() => parse('*/0 * * * *'), CronParseError);
  });

  it('bails on garbage', () => {
    assert.throws(() => parse('hello there general kenobi'), CronParseError);
  });

  it('complains about month=JAN (named not supported)', () => {
    assert.throws(() => parse('* * * JAN *'), CronParseError);
  });
});

describe('describe', () => {
  it('every minute', () => {
    assert.equal(describeExpr(parse('* * * * *')), 'every minute');
  });

  it('at minute N of every hour', () => {
    assert.equal(describeExpr(parse('15 * * * *')), 'at minute 15 of every hour');
  });

  it('daily at HH:MM', () => {
    assert.equal(describeExpr(parse('30 9 * * *')), 'daily at 09:30');
  });

  it('falls back to source for unrecognized shapes', () => {
    assert.match(describeExpr(parse('0,30 * * * *')), /^cron\(/);
  });
});
