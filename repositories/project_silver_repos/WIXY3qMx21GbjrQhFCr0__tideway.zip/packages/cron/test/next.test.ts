import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { parse } from '../src/parser.ts';
import { nextFireAfter, upcomingFirings } from '../src/next.ts';

const at = (iso: string) => new Date(iso);

describe('nextFireAfter: every minute', () => {
  it('rolls to the next minute boundary', () => {
    const e = parse('* * * * *');
    const r = nextFireAfter(e, at('2026-05-08T12:34:17Z'));
    assert.equal(r!.toISOString(), '2026-05-08T12:35:00.000Z');
  });

  it('does NOT return the same minute when called exactly on the boundary', () => {
    const e = parse('* * * * *');
    const r = nextFireAfter(e, at('2026-05-08T12:34:00Z'));
    assert.equal(r!.toISOString(), '2026-05-08T12:35:00.000Z');
  });
});

describe('nextFireAfter: hourly', () => {
  it('"0 * * * *" fires at the next top of hour', () => {
    const e = parse('0 * * * *');
    const r = nextFireAfter(e, at('2026-05-08T12:34:00Z'));
    assert.equal(r!.toISOString(), '2026-05-08T13:00:00.000Z');
  });
});

describe('nextFireAfter: daily', () => {
  it('"30 9 * * *" fires at next 09:30 UTC', () => {
    const e = parse('30 9 * * *');
    const r = nextFireAfter(e, at('2026-05-08T08:00:00Z'));
    assert.equal(r!.toISOString(), '2026-05-08T09:30:00.000Z');
  });

  it('rolls to the next day if past today\'s firing', () => {
    const e = parse('30 9 * * *');
    const r = nextFireAfter(e, at('2026-05-08T10:00:00Z'));
    assert.equal(r!.toISOString(), '2026-05-09T09:30:00.000Z');
  });
});

describe('nextFireAfter: weekday filter', () => {
  it('"0 9 * * 1" -> next Monday at 09:00', () => {
    // 2026-05-08 is a Friday (UTC).
    const e = parse('0 9 * * 1');
    const r = nextFireAfter(e, at('2026-05-08T12:00:00Z'));
    assert.equal(r!.toISOString(), '2026-05-11T09:00:00.000Z');
  });

  it('"0 9 * * 1-5" skips weekends', () => {
    const e = parse('0 9 * * 1-5');
    const r = nextFireAfter(e, at('2026-05-09T12:00:00Z')); // Saturday
    assert.equal(r!.toISOString(), '2026-05-11T09:00:00.000Z'); // Monday
  });
});

describe('nextFireAfter: month rollover', () => {
  it('"0 0 1 * *" rolls to first of next month', () => {
    const e = parse('0 0 1 * *');
    const r = nextFireAfter(e, at('2026-05-15T12:00:00Z'));
    assert.equal(r!.toISOString(), '2026-06-01T00:00:00.000Z');
  });
});

describe('nextFireAfter: pathological', () => {
  it('"0 0 31 2 *" returns null (Feb 31 never exists)', () => {
    const e = parse('0 0 31 2 *');
    const r = nextFireAfter(e, at('2026-01-01T00:00:00Z'));
    assert.equal(r, null);
  });

  it('"0 0 30 2 *" returns null (Feb 30 never exists)', () => {
    const e = parse('0 0 30 2 *');
    const r = nextFireAfter(e, at('2026-01-01T00:00:00Z'));
    assert.equal(r, null);
  });

  it('"0 0 29 2 *" finds a leap-year match within 5 years', () => {
    const e = parse('0 0 29 2 *');
    // 2028 is a leap year.
    const r = nextFireAfter(e, at('2026-01-01T00:00:00Z'));
    assert.equal(r!.toISOString(), '2028-02-29T00:00:00.000Z');
  });
});

describe('nextFireAfter: every 15 minutes', () => {
  it('rolls correctly across the hour', () => {
    const e = parse('*/15 * * * *');
    let cur = at('2026-05-08T12:00:00Z');
    const expected = [
      '2026-05-08T12:15:00.000Z',
      '2026-05-08T12:30:00.000Z',
      '2026-05-08T12:45:00.000Z',
      '2026-05-08T13:00:00.000Z',
    ];
    for (const exp of expected) {
      const next = nextFireAfter(e, cur)!;
      assert.equal(next.toISOString(), exp);
      cur = next;
    }
  });
});

describe('upcomingFirings', () => {
  it('returns the next N firings', () => {
    const e = parse('0 9 * * 1-5');
    const list = upcomingFirings(e, at('2026-05-04T00:00:00Z'), 5);
    // Mon 5/4 .. Fri 5/8 weekdays.
    assert.equal(list.length, 5);
    assert.equal(list[0]!.toISOString(), '2026-05-04T09:00:00.000Z');
    assert.equal(list[4]!.toISOString(), '2026-05-08T09:00:00.000Z');
  });

  it('returns an empty array if the expression never fires', () => {
    const e = parse('0 0 31 2 *');
    assert.deepEqual(upcomingFirings(e, at('2026-01-01T00:00:00Z'), 5), []);
  });

  it('returns fewer than N if expression eventually exhausts', () => {
    // Hard to construct a "fires 3 times then stops" pattern in plain
    // cron, so we just verify N=0 is honored.
    const e = parse('* * * * *');
    assert.deepEqual(upcomingFirings(e, at('2026-01-01T00:00:00Z'), 0), []);
  });
});
