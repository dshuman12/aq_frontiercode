// Dead-letter queue.
//
// When a run exhausts its retry policy or fails permanently, the runner
// records it here. Operators inspect and replay from the dlq via the
// console CLI; replays re-issue the run with attempt=0 and a fresh
// idempotency window. Drops permanently abandon a run.
//
// The dlq is in-memory in the same shape as everything else; the runner
// mirrors to the store.

import type { FailureKind } from '@tideway/failure';

export type RunId = string;

export interface DlqEntry {
  runId: RunId;
  handler: string;
  failureKind: FailureKind;
  message: string;
  // The attempt number at which the run gave up.
  finalAttempt: number;
  enteredAt: number;
  // Original input payload (opaque to the dlq itself).
  input: unknown;
  // Free-form tags so operators can group entries by failure shape.
  tags: string[];
}

export interface InspectFilters {
  failureKind?: FailureKind | FailureKind[];
  handler?: string;
  tag?: string;
  // ms since epoch; entries with enteredAt < before are excluded.
  enteredSince?: number;
  // Limit results.
  limit?: number;
}

export class DeadLetterQueue {
  private readonly entries = new Map<RunId, DlqEntry>();
  // Insertion-ordered runIds to keep `inspect` deterministic.
  private readonly insertionOrder: RunId[] = [];
  private readonly clock: () => number;

  constructor(opts?: { clock?: () => number }) {
    this.clock = opts?.clock ?? Date.now;
  }

  enqueue(entry: Omit<DlqEntry, 'enteredAt'>): DlqEntry {
    if (this.entries.has(entry.runId)) {
      throw new Error(`already in dlq: ${entry.runId}`);
    }
    const stored: DlqEntry = { ...entry, enteredAt: this.clock() };
    this.entries.set(entry.runId, stored);
    this.insertionOrder.push(entry.runId);
    return stored;
  }

  get(runId: RunId): DlqEntry | undefined {
    return this.entries.get(runId);
  }

  size(): number {
    return this.entries.size;
  }

  // Returns matching entries in insertion order, oldest first.
  inspect(filters: InspectFilters = {}): DlqEntry[] {
    const out: DlqEntry[] = [];
    const limit = filters.limit ?? Infinity;

    let kindMatch: ((k: FailureKind) => boolean) | undefined;
    if (filters.failureKind) {
      const allowed = Array.isArray(filters.failureKind)
        ? new Set<FailureKind>(filters.failureKind)
        : new Set<FailureKind>([filters.failureKind]);
      kindMatch = (k) => allowed.has(k);
    }

    for (const runId of this.insertionOrder) {
      if (out.length >= limit) break;
      const entry = this.entries.get(runId);
      if (!entry) continue;
      if (kindMatch && !kindMatch(entry.failureKind)) continue;
      if (filters.handler && entry.handler !== filters.handler) continue;
      if (filters.tag && !entry.tags.includes(filters.tag)) continue;
      if (filters.enteredSince !== undefined && entry.enteredAt < filters.enteredSince) continue;
      out.push(entry);
    }
    return out;
  }

  // Replay: returns the entry (with attempt reset to 0) and removes it
  // from the dlq. The runner takes the result, re-creates the run, and
  // submits it. Returns undefined if the run isn't in the dlq.
  replay(runId: RunId): { entry: DlqEntry } | undefined {
    const entry = this.entries.get(runId);
    if (!entry) return undefined;
    this.entries.delete(runId);
    const idx = this.insertionOrder.indexOf(runId);
    if (idx >= 0) this.insertionOrder.splice(idx, 1);
    // We deliberately don't mutate the entry's finalAttempt; the runner
    // looks at finalAttempt for trace continuity (so the new attempt
    // chain starts from zero but a status query can still see "this run
    // previously failed at attempt 4").
    return { entry: { ...entry } };
  }

  // Drop without replay. Returns true if something was dropped.
  drop(runId: RunId): boolean {
    if (!this.entries.has(runId)) return false;
    this.entries.delete(runId);
    const idx = this.insertionOrder.indexOf(runId);
    if (idx >= 0) this.insertionOrder.splice(idx, 1);
    return true;
  }

  // Bulk drop matching filters. Returns the number dropped.
  bulkDrop(filters: InspectFilters): number {
    const matches = this.inspect(filters);
    let dropped = 0;
    for (const entry of matches) {
      if (this.drop(entry.runId)) dropped += 1;
    }
    return dropped;
  }

  // Bulk replay matching filters. Returns the popped entries (the runner
  // re-submits them).
  bulkReplay(filters: InspectFilters): DlqEntry[] {
    const matches = this.inspect(filters);
    const out: DlqEntry[] = [];
    for (const m of matches) {
      const r = this.replay(m.runId);
      if (r) out.push(r.entry);
    }
    return out;
  }

  // Aggregate counts by failureKind. Useful for the "what's broken?"
  // dashboard.
  countByKind(): Record<FailureKind, number> {
    const init: Record<FailureKind, number> = {
      retryable: 0,
      permanent: 0,
      canceled: 0,
      lease_lost: 0,
      wire: 0,
    };
    for (const entry of this.entries.values()) {
      init[entry.failureKind] += 1;
    }
    return init;
  }
}
