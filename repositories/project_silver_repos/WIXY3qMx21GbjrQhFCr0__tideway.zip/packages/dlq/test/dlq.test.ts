import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { DeadLetterQueue, type DlqEntry } from '../src/index.ts';

class FakeClock {
  constructor(public t = 0) {}
  now = () => this.t;
  advance(ms: number) {
    this.t += ms;
  }
}

const entryOf = (overrides: Partial<Omit<DlqEntry, 'enteredAt'>> = {}): Omit<DlqEntry, 'enteredAt'> => ({
  runId: 'run-1',
  handler: 'handler-A',
  failureKind: 'permanent',
  message: 'hard fail',
  finalAttempt: 3,
  input: { foo: 'bar' },
  tags: [],
  ...overrides,
});

describe('enqueue / get / size', () => {
  it('stores an entry and assigns enteredAt', () => {
    const c = new FakeClock(5000);
    const q = new DeadLetterQueue({ clock: c.now });
    const stored = q.enqueue(entryOf());
    assert.equal(stored.enteredAt, 5000);
    assert.equal(q.size(), 1);
    assert.equal(q.get('run-1')?.runId, 'run-1');
  });

  it('refuses to enqueue the same runId twice', () => {
    const q = new DeadLetterQueue();
    q.enqueue(entryOf());
    assert.throws(() => q.enqueue(entryOf()));
  });

  it('keeps independent entries separate', () => {
    const q = new DeadLetterQueue();
    q.enqueue(entryOf({ runId: 'r1' }));
    q.enqueue(entryOf({ runId: 'r2' }));
    q.enqueue(entryOf({ runId: 'r3' }));
    assert.equal(q.size(), 3);
  });
});

describe('inspect', () => {
  const seed = (q: DeadLetterQueue) => {
    q.enqueue(entryOf({ runId: 'p1', failureKind: 'permanent', handler: 'send-email' }));
    q.enqueue(entryOf({ runId: 'p2', failureKind: 'permanent', handler: 'compute-tax' }));
    q.enqueue(entryOf({ runId: 'r1', failureKind: 'retryable', handler: 'send-email', tags: ['network'] }));
    q.enqueue(entryOf({ runId: 'c1', failureKind: 'canceled', handler: 'send-email', tags: ['network', 'urgent'] }));
  };

  it('without filters returns everything in insertion order', () => {
    const q = new DeadLetterQueue();
    seed(q);
    const all = q.inspect();
    assert.deepEqual(
      all.map((e) => e.runId),
      ['p1', 'p2', 'r1', 'c1'],
    );
  });

  it('filters by single failureKind', () => {
    const q = new DeadLetterQueue();
    seed(q);
    const perm = q.inspect({ failureKind: 'permanent' });
    assert.deepEqual(
      perm.map((e) => e.runId),
      ['p1', 'p2'],
    );
  });

  it('filters by multiple failureKinds (array)', () => {
    const q = new DeadLetterQueue();
    seed(q);
    const out = q.inspect({ failureKind: ['retryable', 'canceled'] });
    assert.deepEqual(
      out.map((e) => e.runId).sort(),
      ['c1', 'r1'],
    );
  });

  it('filters by handler', () => {
    const q = new DeadLetterQueue();
    seed(q);
    const emails = q.inspect({ handler: 'send-email' });
    assert.deepEqual(
      emails.map((e) => e.runId),
      ['p1', 'r1', 'c1'],
    );
  });

  it('filters by tag', () => {
    const q = new DeadLetterQueue();
    seed(q);
    const networked = q.inspect({ tag: 'network' });
    assert.deepEqual(
      networked.map((e) => e.runId),
      ['r1', 'c1'],
    );
  });

  it('honors limit', () => {
    const q = new DeadLetterQueue();
    seed(q);
    const out = q.inspect({ limit: 2 });
    assert.equal(out.length, 2);
  });

  it('combines filters with AND semantics', () => {
    const q = new DeadLetterQueue();
    seed(q);
    const out = q.inspect({ handler: 'send-email', failureKind: 'permanent' });
    assert.deepEqual(
      out.map((e) => e.runId),
      ['p1'],
    );
  });

  it('filters by enteredSince', () => {
    const c = new FakeClock(0);
    const q = new DeadLetterQueue({ clock: c.now });
    q.enqueue(entryOf({ runId: 'old' }));
    c.advance(1000);
    q.enqueue(entryOf({ runId: 'new' }));
    const out = q.inspect({ enteredSince: 500 });
    assert.deepEqual(
      out.map((e) => e.runId),
      ['new'],
    );
  });
});

describe('replay', () => {
  it('removes the entry and returns it', () => {
    const q = new DeadLetterQueue();
    q.enqueue(entryOf());
    const r = q.replay('run-1');
    assert.ok(r);
    assert.equal(r!.entry.runId, 'run-1');
    assert.equal(q.size(), 0);
  });

  it('preserves finalAttempt for trace continuity', () => {
    const q = new DeadLetterQueue();
    q.enqueue(entryOf({ finalAttempt: 7 }));
    const r = q.replay('run-1');
    assert.equal(r!.entry.finalAttempt, 7);
  });

  it('returns undefined for unknown runId', () => {
    const q = new DeadLetterQueue();
    assert.equal(q.replay('ghost'), undefined);
  });
});

describe('drop / bulkDrop / bulkReplay', () => {
  it('drop removes one entry', () => {
    const q = new DeadLetterQueue();
    q.enqueue(entryOf({ runId: 'r1' }));
    q.enqueue(entryOf({ runId: 'r2' }));
    assert.equal(q.drop('r1'), true);
    assert.equal(q.size(), 1);
    assert.equal(q.get('r1'), undefined);
  });

  it('drop returns false for unknown', () => {
    const q = new DeadLetterQueue();
    assert.equal(q.drop('ghost'), false);
  });

  it('bulkDrop with a filter drops matching entries', () => {
    const q = new DeadLetterQueue();
    q.enqueue(entryOf({ runId: 'p1', failureKind: 'permanent' }));
    q.enqueue(entryOf({ runId: 'p2', failureKind: 'permanent' }));
    q.enqueue(entryOf({ runId: 'r1', failureKind: 'retryable' }));
    const dropped = q.bulkDrop({ failureKind: 'permanent' });
    assert.equal(dropped, 2);
    assert.equal(q.size(), 1);
  });

  it('bulkReplay returns matching entries and removes them', () => {
    const q = new DeadLetterQueue();
    q.enqueue(entryOf({ runId: 'r1', failureKind: 'retryable' }));
    q.enqueue(entryOf({ runId: 'r2', failureKind: 'retryable' }));
    q.enqueue(entryOf({ runId: 'p1', failureKind: 'permanent' }));
    const replayed = q.bulkReplay({ failureKind: 'retryable' });
    assert.equal(replayed.length, 2);
    assert.equal(q.size(), 1);
  });
});

describe('countByKind', () => {
  it('aggregates counts per failure kind', () => {
    const q = new DeadLetterQueue();
    q.enqueue(entryOf({ runId: 'p1', failureKind: 'permanent' }));
    q.enqueue(entryOf({ runId: 'p2', failureKind: 'permanent' }));
    q.enqueue(entryOf({ runId: 'r1', failureKind: 'retryable' }));
    const counts = q.countByKind();
    assert.equal(counts.permanent, 2);
    assert.equal(counts.retryable, 1);
    assert.equal(counts.canceled, 0);
    assert.equal(counts.wire, 0);
    assert.equal(counts.lease_lost, 0);
  });
});
