import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { InMemoryExporter, JsonlExporter, Tracer } from '../src/index.ts';

const fakeClock = () => {
  let t = 0n;
  return {
    now: () => {
      t += 1n;
      return t;
    },
    set: (v: bigint) => {
      t = v;
    },
  };
};

const fakeIdgen = () => {
  let i = 0;
  return () => {
    i += 1;
    return `id${i.toString().padStart(14, '0')}`;
  };
};

describe('Tracer.startSpan', () => {
  it('creates a span with the given name and default kind', () => {
    const exp = new InMemoryExporter();
    const c = fakeClock();
    const t = new Tracer({ exporter: exp, clock: c.now, idgen: fakeIdgen() });
    const span = t.startSpan('my-span');
    span.end();
    assert.equal(exp.spans.length, 1);
    assert.equal(exp.spans[0]!.name, 'my-span');
    assert.equal(exp.spans[0]!.kind, 'internal');
  });

  it('honors a custom kind', () => {
    const exp = new InMemoryExporter();
    const t = new Tracer({ exporter: exp, idgen: fakeIdgen() });
    const span = t.startSpan('x', { kind: 'server' });
    span.end();
    assert.equal(exp.spans[0]!.kind, 'server');
  });

  it('inherits traceId from a parent context', () => {
    const exp = new InMemoryExporter();
    const t = new Tracer({ exporter: exp, idgen: fakeIdgen() });
    const parent = { traceId: 'fixed-trace-id-32-chars-12345678', spanId: 'parent-span-x123' };
    const span = t.startSpan('child', { parent });
    span.end();
    assert.equal(exp.spans[0]!.context.traceId, parent.traceId);
    assert.notEqual(exp.spans[0]!.context.spanId, parent.spanId);
    assert.equal(exp.spans[0]!.parent?.spanId, parent.spanId);
  });

  it('records start and end timestamps', () => {
    const exp = new InMemoryExporter();
    const c = fakeClock();
    c.set(100n);
    const t = new Tracer({ exporter: exp, clock: c.now, idgen: fakeIdgen() });
    const span = t.startSpan('x');
    c.set(200n);
    span.end();
    assert.ok(exp.spans[0]!.startTimeUnixNano < exp.spans[0]!.endTimeUnixNano!);
  });

  it('end is idempotent', () => {
    const exp = new InMemoryExporter();
    const t = new Tracer({ exporter: exp, idgen: fakeIdgen() });
    const span = t.startSpan('x');
    span.end();
    span.end();
    span.end();
    assert.equal(exp.spans.length, 1);
  });
});

describe('Span.setAttribute / addEvent', () => {
  it('attributes are visible in the exported span', () => {
    const exp = new InMemoryExporter();
    const t = new Tracer({ exporter: exp, idgen: fakeIdgen() });
    const span = t.startSpan('x');
    span.setAttribute('runId', 'r-1').setAttribute('attempt', 3).setAttribute('replay', false);
    span.end();
    assert.deepEqual(exp.spans[0]!.attributes, { runId: 'r-1', attempt: 3, replay: false });
  });

  it('events accumulate', () => {
    const exp = new InMemoryExporter();
    const t = new Tracer({ exporter: exp, idgen: fakeIdgen() });
    const span = t.startSpan('x');
    span.addEvent('phase-1', { ok: true });
    span.addEvent('phase-2');
    span.end();
    assert.equal(exp.spans[0]!.events.length, 2);
    assert.equal(exp.spans[0]!.events[0]!.name, 'phase-1');
    assert.deepEqual(exp.spans[0]!.events[0]!.attributes, { ok: true });
  });

  it('post-end mutations are noops', () => {
    const exp = new InMemoryExporter();
    const t = new Tracer({ exporter: exp, idgen: fakeIdgen() });
    const span = t.startSpan('x');
    span.end();
    span.setAttribute('after-end', 'nope');
    span.addEvent('ghost');
    // Exporter saw the pre-end state. The spans[0] was a structuredClone
    // so attribute mutations on `_data` (post-end) wouldn't have shown
    // up anyway, but we want to verify the public API is also a noop.
    assert.equal(exp.spans[0]!.attributes['after-end'], undefined);
    assert.equal(exp.spans[0]!.events.length, 0);
  });
});

describe('Span.recordException', () => {
  it('adds an exception event with type, message, stack', () => {
    const exp = new InMemoryExporter();
    const t = new Tracer({ exporter: exp, idgen: fakeIdgen() });
    const span = t.startSpan('x');
    const err = new Error('boom');
    span.recordException(err);
    span.end();
    const ev = exp.spans[0]!.events[0]!;
    assert.equal(ev.name, 'exception');
    assert.equal(ev.attributes['exception.message'], 'boom');
    assert.equal(ev.attributes['exception.type'], 'Error');
  });

  it('flips status to error if previously unset', () => {
    const exp = new InMemoryExporter();
    const t = new Tracer({ exporter: exp, idgen: fakeIdgen() });
    const span = t.startSpan('x');
    span.recordException(new Error('boom'));
    span.end();
    assert.equal(exp.spans[0]!.status.code, 'error');
  });

  it('preserves explicit status when one was already set', () => {
    const exp = new InMemoryExporter();
    const t = new Tracer({ exporter: exp, idgen: fakeIdgen() });
    const span = t.startSpan('x');
    span.setStatus('ok');
    span.recordException(new Error('boom'));
    span.end();
    assert.equal(exp.spans[0]!.status.code, 'ok');
  });

  it('handles non-Error throws', () => {
    const exp = new InMemoryExporter();
    const t = new Tracer({ exporter: exp, idgen: fakeIdgen() });
    const span = t.startSpan('x');
    span.recordException('a string');
    span.end();
    const ev = exp.spans[0]!.events[0]!;
    assert.equal(ev.attributes['exception.message'], 'a string');
    assert.equal(ev.attributes['exception.type'], 'string');
  });
});

describe('Tracer.withSpan', () => {
  it('records ok status on success', async () => {
    const exp = new InMemoryExporter();
    const t = new Tracer({ exporter: exp, idgen: fakeIdgen() });
    const result = await t.withSpan('w', () => 42);
    assert.equal(result, 42);
    assert.equal(exp.spans[0]!.status.code, 'ok');
  });

  it('records error status and rethrows on throw', async () => {
    const exp = new InMemoryExporter();
    const t = new Tracer({ exporter: exp, idgen: fakeIdgen() });
    await assert.rejects(t.withSpan('w', () => Promise.reject(new Error('nope'))));
    assert.equal(exp.spans[0]!.status.code, 'error');
    assert.ok(exp.spans[0]!.events.find((e) => e.name === 'exception'));
  });

  it('passes the span to the callback for mid-flight attribution', async () => {
    const exp = new InMemoryExporter();
    const t = new Tracer({ exporter: exp, idgen: fakeIdgen() });
    await t.withSpan('w', (span) => {
      span.setAttribute('worked', 'yes');
    });
    assert.equal(exp.spans[0]!.attributes.worked, 'yes');
  });
});

describe('JsonlExporter', () => {
  it('emits one line per span with bigints as strings', () => {
    const lines: string[] = [];
    const exp = new JsonlExporter((l) => lines.push(l));
    const t = new Tracer({ exporter: exp, idgen: fakeIdgen() });
    t.startSpan('a').end();
    t.startSpan('b').end();
    assert.equal(lines.length, 2);
    const parsed = JSON.parse(lines[0]!);
    assert.equal(parsed.name, 'a');
    assert.equal(typeof parsed.startTimeUnixNano, 'string');
  });
});

describe('InMemoryExporter.reset', () => {
  it('clears captured spans', () => {
    const exp = new InMemoryExporter();
    const t = new Tracer({ exporter: exp, idgen: fakeIdgen() });
    t.startSpan('a').end();
    exp.reset();
    assert.equal(exp.spans.length, 0);
  });
});
