// Tracing: a small, OpenTelemetry-shaped span emitter.
//
// We don't take a hard dependency on @opentelemetry/api because it's
// non-trivial to install correctly and the surface we actually need is
// small: start a span, set attributes, record an exception, end. The
// exporter abstraction lets the runner pipe spans wherever it wants
// (default: discard; provided: jsonl-to-stdout for local debugging).
//
// The span shape we emit IS OTel-compatible enough that swapping in the
// real OTel SDK is a one-file change in the runner; the rest of the
// codebase touches `Tracer` and `Span` only through the interfaces
// exported here.

export type SpanId = string;
export type TraceId = string;

export type SpanKind = 'internal' | 'producer' | 'consumer' | 'client' | 'server';
export type SpanStatusCode = 'unset' | 'ok' | 'error';

export interface SpanContext {
  traceId: TraceId;
  spanId: SpanId;
}

export interface SpanData {
  context: SpanContext;
  parent?: SpanContext;
  name: string;
  kind: SpanKind;
  startTimeUnixNano: bigint;
  endTimeUnixNano?: bigint;
  attributes: Record<string, string | number | boolean>;
  status: { code: SpanStatusCode; message?: string };
  events: SpanEvent[];
}

export interface SpanEvent {
  name: string;
  timeUnixNano: bigint;
  attributes: Record<string, string | number | boolean>;
}

export interface Span {
  // Set or replace an attribute. Returns the span for chaining.
  setAttribute(key: string, value: string | number | boolean): Span;
  // Add a structured event with optional attributes.
  addEvent(name: string, attributes?: Record<string, string | number | boolean>): Span;
  // Record an exception against this span. Sets status to 'error' if it
  // wasn't already set.
  recordException(err: unknown): Span;
  // Set the status code/message.
  setStatus(code: SpanStatusCode, message?: string): Span;
  // End the span. Subsequent operations are silently ignored, which
  // matches OTel semantics.
  end(): void;
  // The data backing this span. Mostly for tests; the exporter receives
  // a copy via `Tracer.onEnd`.
  data(): SpanData;
}

export interface Exporter {
  export(span: SpanData): void;
}

export interface TracerOptions {
  // The exporter that receives ended spans. Defaults to a noop.
  exporter?: Exporter;
  // Time source for span timestamps. Defaults to a hrtime-based clock.
  clock?: () => bigint;
  // Random source for ids. Defaults to crypto.randomBytes via Node.
  idgen?: () => string;
}

export class Tracer {
  private readonly exporter: Exporter;
  private readonly clock: () => bigint;
  private readonly idgen: () => string;

  constructor(opts: TracerOptions = {}) {
    this.exporter = opts.exporter ?? { export: () => undefined };
    this.clock = opts.clock ?? defaultClock;
    this.idgen = opts.idgen ?? defaultIdgen;
  }

  startSpan(name: string, opts: { kind?: SpanKind; parent?: SpanContext } = {}): Span {
    const traceId = opts.parent?.traceId ?? this.makeTraceId();
    const spanId = this.makeSpanId();
    const data: SpanData = {
      context: { traceId, spanId },
      ...(opts.parent !== undefined ? { parent: opts.parent } : {}),
      name,
      kind: opts.kind ?? 'internal',
      startTimeUnixNano: this.clock(),
      attributes: {},
      status: { code: 'unset' },
      events: [],
    };
    return new SpanImpl(data, this.clock, this.exporter);
  }

  // Run `fn` inside a span; ends the span automatically and propagates
  // exceptions after recording them. The fn receives the span so it can
  // attach attributes mid-flight.
  async withSpan<T>(
    name: string,
    fn: (span: Span) => Promise<T> | T,
    opts: { kind?: SpanKind; parent?: SpanContext } = {},
  ): Promise<T> {
    const span = this.startSpan(name, opts);
    try {
      const result = await fn(span);
      if (span.data().status.code === 'unset') span.setStatus('ok');
      return result;
    } catch (err) {
      span.recordException(err);
      throw err;
    } finally {
      span.end();
    }
  }

  private makeTraceId(): TraceId {
    return `${this.idgen()}${this.idgen()}`.slice(0, 32);
  }

  private makeSpanId(): SpanId {
    return this.idgen().slice(0, 16);
  }
}

class SpanImpl implements Span {
  private ended = false;
  constructor(
    private readonly _data: SpanData,
    private readonly clock: () => bigint,
    private readonly exporter: Exporter,
  ) {}

  setAttribute(key: string, value: string | number | boolean): Span {
    if (this.ended) return this;
    this._data.attributes[key] = value;
    return this;
  }

  addEvent(name: string, attributes: Record<string, string | number | boolean> = {}): Span {
    if (this.ended) return this;
    this._data.events.push({
      name,
      timeUnixNano: this.clock(),
      attributes,
    });
    return this;
  }

  recordException(err: unknown): Span {
    if (this.ended) return this;
    const message = err instanceof Error ? err.message : String(err);
    const stack = err instanceof Error && err.stack ? err.stack : '';
    this.addEvent('exception', {
      'exception.type': err instanceof Error ? err.name : typeof err,
      'exception.message': message,
      'exception.stacktrace': stack,
    });
    if (this._data.status.code === 'unset') {
      this._data.status = { code: 'error', message };
    }
    return this;
  }

  setStatus(code: SpanStatusCode, message?: string): Span {
    if (this.ended) return this;
    this._data.status = message !== undefined ? { code, message } : { code };
    return this;
  }

  end(): void {
    if (this.ended) return;
    this.ended = true;
    this._data.endTimeUnixNano = this.clock();
    // Pass a frozen copy so the exporter doesn't observe later edits.
    // (It can't get any anyway because subsequent set/addEvent are
    // noops, but defense in depth is cheap.)
    this.exporter.export(structuredClone(this._data));
  }

  data(): SpanData {
    return this._data;
  }
}

// --- Provided exporters ---

// Captures spans into an array. Useful for tests and the metrics
// dashboard.
export class InMemoryExporter implements Exporter {
  readonly spans: SpanData[] = [];
  export(span: SpanData): void {
    this.spans.push(span);
  }
  reset(): void {
    this.spans.length = 0;
  }
}

// Emits one span per line as JSON to a writable. Default writable is
// process.stdout; in production the runner pipes this to a sidecar that
// forwards to the OTel collector.
export class JsonlExporter implements Exporter {
  constructor(private readonly write: (line: string) => void = (l) => process.stdout.write(l)) {}
  export(span: SpanData): void {
    this.write(`${JSON.stringify(span, replaceBigInt)}\n`);
  }
}

function replaceBigInt(_key: string, value: unknown): unknown {
  if (typeof value === 'bigint') return value.toString();
  return value;
}

function defaultClock(): bigint {
  // process.hrtime.bigint returns nanoseconds since process start; we
  // shift it into the unix-epoch range so the values match OTel's
  // expected "time since unix epoch in nanoseconds" representation.
  // Process-relative time is fine for the runner (everything is a single
  // process anyway), but the unix-epoch alignment makes traces interop-
  // friendly.
  return BigInt(Date.now()) * 1_000_000n + (process.hrtime.bigint() % 1_000_000n);
}

function defaultIdgen(): string {
  // 16-hex-character ids. Not cryptographically random; spans are not
  // adversarial. Math.random is fine for the entropy we need here.
  let out = '';
  while (out.length < 16) {
    out += Math.floor(Math.random() * 0xffffffff)
      .toString(16)
      .padStart(8, '0');
  }
  return out.slice(0, 16);
}
