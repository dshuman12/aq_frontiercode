import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { Registry } from '../src/index.ts';

class FakeClock {
  constructor(public t = 0) {}
  now = () => this.t;
  advance(ms: number) {
    this.t += ms;
  }
}

describe('acquire on a fresh key', () => {
  it('returns kind=fresh', () => {
    const c = new FakeClock(1000);
    const r = new Registry({ clock: c.now });
    const out = r.acquire('handler-A', 'key-1', 'run-001');
    assert.equal(out.kind, 'fresh');
    if (out.kind === 'fresh') {
      assert.equal(out.entry.status.kind, 'inflight');
    }
  });

  it('records the runId on the inflight entry', () => {
    const c = new FakeClock(0);
    const r = new Registry({ clock: c.now });
    r.acquire('h', 'k', 'run-99');
    const entry = r.get('h', 'k');
    assert.equal(entry?.status.kind, 'inflight');
    if (entry?.status.kind === 'inflight') {
      assert.equal(entry.status.runId, 'run-99');
    }
  });
});

describe('acquire while a prior is in flight', () => {
  it('returns kind=join with the owner run id', () => {
    const c = new FakeClock(0);
    const r = new Registry({ clock: c.now });
    r.acquire('h', 'k', 'first');
    const out = r.acquire('h', 'k', 'second');
    assert.equal(out.kind, 'join');
    if (out.kind === 'join') {
      assert.equal(out.ownerRunId, 'first');
    }
  });
});

describe('acquire after a prior completes', () => {
  it('returns kind=result with the stored result', () => {
    const c = new FakeClock(0);
    const r = new Registry({ clock: c.now });
    r.acquire('h', 'k', 'run-1');
    r.complete('h', 'k', { receipt: 'abc' });
    const out = r.acquire('h', 'k', 'run-2');
    assert.equal(out.kind, 'result');
    if (out.kind === 'result' && out.status.kind === 'completed') {
      assert.deepEqual(out.status.result, { receipt: 'abc' });
    }
  });

  it('returns kind=result with stored failure for failed prior', () => {
    const c = new FakeClock(0);
    const r = new Registry({ clock: c.now });
    r.acquire('h', 'k', 'run-1');
    r.fail('h', 'k', { message: 'nope', kind: 'permanent' });
    const out = r.acquire('h', 'k', 'run-2');
    assert.equal(out.kind, 'result');
    if (out.kind === 'result' && out.status.kind === 'failed') {
      assert.equal(out.status.failureMessage, 'nope');
      assert.equal(out.status.failureKind, 'permanent');
    }
  });
});

describe('TTL expiry', () => {
  it('a fresh acquire after TTL expiry runs again', () => {
    const c = new FakeClock(0);
    const r = new Registry({ clock: c.now, defaultTtlMs: 1000 });
    r.acquire('h', 'k', 'run-1');
    r.complete('h', 'k', 1);
    c.advance(1500);
    const out = r.acquire('h', 'k', 'run-2');
    assert.equal(out.kind, 'fresh');
  });

  it('within TTL the prior result is still served', () => {
    const c = new FakeClock(0);
    const r = new Registry({ clock: c.now, defaultTtlMs: 5000 });
    r.acquire('h', 'k', 'run-1');
    r.complete('h', 'k', 1);
    c.advance(1000);
    const out = r.acquire('h', 'k', 'run-2');
    assert.equal(out.kind, 'result');
  });

  it('per-call ttl overrides default', () => {
    const c = new FakeClock(0);
    const r = new Registry({ clock: c.now, defaultTtlMs: 60_000 });
    r.acquire('h', 'k', 'run-1', { ttlMs: 100 });
    r.complete('h', 'k', 1);
    c.advance(200);
    const out = r.acquire('h', 'k', 'run-2');
    assert.equal(out.kind, 'fresh');
  });
});

describe('handler scoping', () => {
  it('same key under different handlers does NOT collide', () => {
    const c = new FakeClock(0);
    const r = new Registry({ clock: c.now });
    r.acquire('email-send', 'order-37', 'run-1');
    const out = r.acquire('audit-log', 'order-37', 'run-2');
    assert.equal(out.kind, 'fresh');
  });
});

describe('complete/fail', () => {
  it('complete on unknown returns false', () => {
    const r = new Registry();
    assert.equal(r.complete('h', 'k', 1), false);
  });

  it('complete on already-completed returns false', () => {
    const c = new FakeClock(0);
    const r = new Registry({ clock: c.now });
    r.acquire('h', 'k', 'run-1');
    r.complete('h', 'k', 1);
    assert.equal(r.complete('h', 'k', 2), false);
  });

  it('fail on already-completed returns false', () => {
    const c = new FakeClock(0);
    const r = new Registry({ clock: c.now });
    r.acquire('h', 'k', 'run-1');
    r.complete('h', 'k', 1);
    assert.equal(r.fail('h', 'k', { message: 'too late', kind: 'permanent' }), false);
  });
});

describe('abandon', () => {
  it('clears an inflight entry; next acquire is fresh', () => {
    const c = new FakeClock(0);
    const r = new Registry({ clock: c.now });
    r.acquire('h', 'k', 'run-1');
    assert.equal(r.abandon('h', 'k'), true);
    assert.equal(r.size(), 0);
    const out = r.acquire('h', 'k', 'run-2');
    assert.equal(out.kind, 'fresh');
  });

  it('refuses to abandon a completed entry', () => {
    const c = new FakeClock(0);
    const r = new Registry({ clock: c.now });
    r.acquire('h', 'k', 'run-1');
    r.complete('h', 'k', 'val');
    assert.equal(r.abandon('h', 'k'), false);
  });
});

describe('sweepExpired', () => {
  it('removes entries past their TTL and returns the count', () => {
    const c = new FakeClock(0);
    const r = new Registry({ clock: c.now, defaultTtlMs: 1000 });
    r.acquire('h', 'k1', 'run-1');
    r.acquire('h', 'k2', 'run-2');
    r.complete('h', 'k1', 1);
    r.complete('h', 'k2', 2);
    c.advance(2000);
    assert.equal(r.sweepExpired(), 2);
    assert.equal(r.size(), 0);
  });
});

describe('hash stability', () => {
  it('same handler+key produces the same hash across instances', () => {
    const c = new FakeClock(0);
    const r1 = new Registry({ clock: c.now });
    const r2 = new Registry({ clock: c.now });
    r1.acquire('h', 'k', 'run-1');
    r2.acquire('h', 'k', 'run-2');
    assert.equal(r1.get('h', 'k')?.hash, r2.get('h', 'k')?.hash);
  });
});
