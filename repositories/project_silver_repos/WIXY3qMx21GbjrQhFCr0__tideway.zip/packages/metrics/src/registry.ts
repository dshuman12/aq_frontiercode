// Registry: holds every metric so the exporter can iterate them all in
// one place. The runner registers its standard set at startup.

import { Counter } from './counter.ts';
import { Gauge } from './gauge.ts';
import { Histogram } from './histogram.ts';

export class MetricRegistry {
  private readonly counters = new Map<string, Counter>();
  private readonly gauges = new Map<string, Gauge>();
  private readonly histograms = new Map<string, Histogram>();

  registerCounter(c: Counter): Counter {
    if (this.has(c.name)) {
      throw new Error(`metric already registered: ${c.name}`);
    }
    this.counters.set(c.name, c);
    return c;
  }

  registerGauge(g: Gauge): Gauge {
    if (this.has(g.name)) {
      throw new Error(`metric already registered: ${g.name}`);
    }
    this.gauges.set(g.name, g);
    return g;
  }

  registerHistogram(h: Histogram): Histogram {
    if (this.has(h.name)) {
      throw new Error(`metric already registered: ${h.name}`);
    }
    this.histograms.set(h.name, h);
    return h;
  }

  has(name: string): boolean {
    return this.counters.has(name) || this.gauges.has(name) || this.histograms.has(name);
  }

  // Returns all metrics; useful for the exporter that walks them.
  all(): { counters: Counter[]; gauges: Gauge[]; histograms: Histogram[] } {
    return {
      counters: Array.from(this.counters.values()),
      gauges: Array.from(this.gauges.values()),
      histograms: Array.from(this.histograms.values()),
    };
  }

  reset(): void {
    for (const c of this.counters.values()) c.reset();
    for (const g of this.gauges.values()) g.reset();
    for (const h of this.histograms.values()) h.reset();
  }

  // Reset AND deregister. Mostly for tests that build a fresh registry
  // per test.
  clear(): void {
    this.counters.clear();
    this.gauges.clear();
    this.histograms.clear();
  }
}
