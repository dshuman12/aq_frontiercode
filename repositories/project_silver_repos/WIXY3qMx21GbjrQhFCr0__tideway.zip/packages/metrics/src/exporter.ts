// Prometheus-text-format exporter.
//
// We emit the simplest legal subset of the exposition format. There's a
// formal spec but for our purposes the rules are:
//
//   - one HELP comment per metric name
//   - one TYPE comment per metric name (counter | gauge | histogram)
//   - sample lines for each labeled cell
//   - histograms emit `_bucket{le="..."}`, `_sum`, `_count` lines
//
// We do NOT emit OpenMetrics extensions (exemplars, _created timestamps).
// Plain Prometheus is what the in-tree dashboard expects; if a user
// wants OpenMetrics they're better served by piping through the OTel
// SDK.

import type { Counter } from './counter.ts';
import type { Gauge } from './gauge.ts';
import type { Histogram } from './histogram.ts';
import type { MetricRegistry } from './registry.ts';

export function exportPrometheus(registry: MetricRegistry): string {
  const all = registry.all();
  const lines: string[] = [];
  for (const c of all.counters) emitCounter(c, lines);
  for (const g of all.gauges) emitGauge(g, lines);
  for (const h of all.histograms) emitHistogram(h, lines);
  return lines.join('\n') + (lines.length > 0 ? '\n' : '');
}

function emitCounter(c: Counter, lines: string[]): void {
  lines.push(`# HELP ${c.name} ${escapeHelp(c.description)}`);
  lines.push(`# TYPE ${c.name} counter`);
  for (const cell of c.snapshot()) {
    lines.push(`${c.name}${formatLabels(cell.labels)} ${cell.value}`);
  }
}

function emitGauge(g: Gauge, lines: string[]): void {
  lines.push(`# HELP ${g.name} ${escapeHelp(g.description)}`);
  lines.push(`# TYPE ${g.name} gauge`);
  for (const cell of g.snapshot()) {
    lines.push(`${g.name}${formatLabels(cell.labels)} ${cell.value}`);
  }
}

function emitHistogram(h: Histogram, lines: string[]): void {
  lines.push(`# HELP ${h.name} ${escapeHelp(h.description)}`);
  lines.push(`# TYPE ${h.name} histogram`);
  for (const cell of h.snapshot()) {
    const baseLabels = cell.labels;
    for (const b of cell.buckets) {
      const labels = { ...baseLabels, le: String(b.upperBound) };
      lines.push(`${h.name}_bucket${formatLabels(labels)} ${b.count}`);
    }
    // The +Inf bucket is implicit at the count.
    const infLabels = { ...baseLabels, le: '+Inf' };
    lines.push(`${h.name}_bucket${formatLabels(infLabels)} ${cell.count}`);
    lines.push(`${h.name}_sum${formatLabels(baseLabels)} ${cell.sum}`);
    lines.push(`${h.name}_count${formatLabels(baseLabels)} ${cell.count}`);
  }
}

function formatLabels(labels: Record<string, string>): string {
  const keys = Object.keys(labels).sort();
  if (keys.length === 0) return '';
  const parts = keys.map((k) => `${k}="${escapeLabelValue(labels[k]!)}"`);
  return `{${parts.join(',')}}`;
}

function escapeHelp(s: string): string {
  return s.replace(/\\/g, '\\\\').replace(/\n/g, '\\n');
}

function escapeLabelValue(v: string): string {
  return v.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n');
}
