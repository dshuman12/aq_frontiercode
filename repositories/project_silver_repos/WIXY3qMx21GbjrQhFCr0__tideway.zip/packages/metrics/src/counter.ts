// Counters: monotonically-increasing values.
//
// A counter has a name (immutable) and a current value (only goes up).
// Labels add cardinality - each unique combination of label values
// produces an independent counter under the same name.
//
// Why no `Counter.set()` method: counters that can decrease silently
// produce non-monotonic data, which breaks every consumer that expects
// rate-of-change to be non-negative. If you need a value that goes
// down, use a Gauge.

export type LabelSet = Readonly<Record<string, string>>;

export interface CounterSnapshot {
  name: string;
  description: string;
  labels: LabelSet;
  value: number;
}

export class Counter {
  private readonly cells = new Map<string, number>();

  constructor(
    readonly name: string,
    readonly description: string,
    readonly labelNames: readonly string[] = [],
  ) {
    if (!/^[a-z_][a-z0-9_]*$/.test(name)) {
      throw new RangeError(`metric name must match [a-z_][a-z0-9_]*: ${name}`);
    }
    for (const ln of labelNames) {
      if (!/^[a-z_][a-z0-9_]*$/.test(ln)) {
        throw new RangeError(`label name must match [a-z_][a-z0-9_]*: ${ln}`);
      }
    }
  }

  inc(labels: LabelSet = {}, by = 1): void {
    if (by < 0) {
      throw new RangeError(`Counter.inc requires by >= 0, got ${by}`);
    }
    if (by === 0) return;
    this.assertLabelKeysMatch(labels);
    const key = encodeLabels(labels, this.labelNames);
    this.cells.set(key, (this.cells.get(key) ?? 0) + by);
  }

  get(labels: LabelSet = {}): number {
    this.assertLabelKeysMatch(labels);
    const key = encodeLabels(labels, this.labelNames);
    return this.cells.get(key) ?? 0;
  }

  // Total across all label combinations. Useful for "what's the overall
  // rate?" queries and aggregations the Prometheus exporter cares about.
  total(): number {
    let sum = 0;
    for (const v of this.cells.values()) sum += v;
    return sum;
  }

  // List every cell as a snapshot. Order is insertion-stable.
  snapshot(): CounterSnapshot[] {
    const out: CounterSnapshot[] = [];
    for (const [key, value] of this.cells) {
      out.push({
        name: this.name,
        description: this.description,
        labels: decodeLabels(key, this.labelNames),
        value,
      });
    }
    return out;
  }

  // Reset all cells. Tests use this; production rarely should.
  reset(): void {
    this.cells.clear();
  }

  private assertLabelKeysMatch(labels: LabelSet): void {
    const got = Object.keys(labels).sort();
    const want = [...this.labelNames].sort();
    if (got.length !== want.length || got.some((k, i) => k !== want[i])) {
      throw new RangeError(
        `label set mismatch for ${this.name}: expected ${JSON.stringify(want)}, got ${JSON.stringify(got)}`,
      );
    }
  }
}

// Encode labels as a stable key. We sort the keys so {a:1,b:2} and
// {b:2,a:1} hash the same. Values are escaped against `=` and `,` so
// the encoding is unambiguous.
export function encodeLabels(labels: LabelSet, labelNames: readonly string[]): string {
  if (labelNames.length === 0) return '';
  const parts: string[] = [];
  for (const name of [...labelNames].sort()) {
    const v = labels[name];
    if (v === undefined) {
      throw new RangeError(`missing label value: ${name}`);
    }
    parts.push(`${name}=${escapeLabel(v)}`);
  }
  return parts.join(',');
}

export function decodeLabels(key: string, labelNames: readonly string[]): LabelSet {
  if (labelNames.length === 0 || key === '') return {};
  const out: Record<string, string> = {};
  for (const part of key.split(',')) {
    const eq = part.indexOf('=');
    if (eq < 0) continue;
    const k = part.slice(0, eq);
    const v = unescapeLabel(part.slice(eq + 1));
    out[k] = v;
  }
  return out;
}

function escapeLabel(v: string): string {
  return v.replace(/\\/g, '\\\\').replace(/=/g, '\\=').replace(/,/g, '\\,');
}

function unescapeLabel(v: string): string {
  return v.replace(/\\,/g, ',').replace(/\\=/g, '=').replace(/\\\\/g, '\\');
}
