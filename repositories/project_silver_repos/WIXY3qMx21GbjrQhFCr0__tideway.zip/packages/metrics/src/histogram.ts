// Histograms: bucketed observation counts plus running sum and count.
//
// We use explicit bucket boundaries (Prometheus-style) rather than
// computing percentiles. Computing percentiles cheaply is hard; getting
// the wrong percentile is worse than not having one. Operators read
// bucket counts and either trust them or compute approximate
// percentiles in their dashboard.

import { encodeLabels, decodeLabels, type LabelSet } from './counter.ts';

export interface HistogramCell {
  bucketCounts: number[]; // count per (sorted) boundary, +inf bucket implicit at the end
  sum: number;
  count: number;
}

export interface HistogramSnapshot {
  name: string;
  description: string;
  labels: LabelSet;
  buckets: { upperBound: number; count: number }[];
  sum: number;
  count: number;
}

// Standard latency-style bucket boundaries in milliseconds. Used by the
// runner's job-duration histogram. Operators can override with explicit
// bounds in the constructor.
export const DEFAULT_LATENCY_BUCKETS_MS: readonly number[] = [
  1, 5, 10, 25, 50, 100, 250, 500, 1000, 2500, 5000, 10_000, 30_000, 60_000,
];

export class Histogram {
  private readonly cells = new Map<string, HistogramCell>();
  readonly buckets: readonly number[];

  constructor(
    readonly name: string,
    readonly description: string,
    opts: {
      buckets?: readonly number[];
      labelNames?: readonly string[];
    } = {},
  ) {
    if (!/^[a-z_][a-z0-9_]*$/.test(name)) {
      throw new RangeError(`metric name must match [a-z_][a-z0-9_]*: ${name}`);
    }
    const bounds = opts.buckets ?? DEFAULT_LATENCY_BUCKETS_MS;
    // Ensure sorted ascending and unique.
    for (let i = 1; i < bounds.length; i += 1) {
      if (bounds[i]! <= bounds[i - 1]!) {
        throw new RangeError(`bucket boundaries must be strictly ascending: ${JSON.stringify(bounds)}`);
      }
    }
    this.buckets = bounds;
    this.labelNames = opts.labelNames ?? [];
  }

  readonly labelNames: readonly string[];

  observe(value: number, labels: LabelSet = {}): void {
    if (!Number.isFinite(value)) return;
    this.assertLabelKeysMatch(labels);
    const key = encodeLabels(labels, this.labelNames);
    let cell = this.cells.get(key);
    if (!cell) {
      cell = {
        bucketCounts: new Array(this.buckets.length).fill(0),
        sum: 0,
        count: 0,
      };
      this.cells.set(key, cell);
    }
    cell.count += 1;
    cell.sum += value;
    // Bucket counts are cumulative up to and including the boundary.
    for (let i = 0; i < this.buckets.length; i += 1) {
      if (value <= this.buckets[i]!) cell.bucketCounts[i]! += 1;
    }
  }

  // Approximate percentile from the cumulative bucket counts. Linear
  // interpolation within the matching bucket. Returns undefined for an
  // empty histogram.
  percentile(p: number, labels: LabelSet = {}): number | undefined {
    if (p < 0 || p > 100) throw new RangeError('percentile must be in [0, 100]');
    this.assertLabelKeysMatch(labels);
    const cell = this.cells.get(encodeLabels(labels, this.labelNames));
    if (!cell || cell.count === 0) return undefined;
    const target = (p / 100) * cell.count;
    let prevCum = 0;
    let prevBound = 0;
    for (let i = 0; i < this.buckets.length; i += 1) {
      const cum = cell.bucketCounts[i]!;
      const bound = this.buckets[i]!;
      if (cum >= target) {
        if (cum === prevCum) return bound;
        const frac = (target - prevCum) / (cum - prevCum);
        return prevBound + frac * (bound - prevBound);
      }
      prevCum = cum;
      prevBound = bound;
    }
    return this.buckets[this.buckets.length - 1];
  }

  snapshot(): HistogramSnapshot[] {
    const out: HistogramSnapshot[] = [];
    for (const [key, cell] of this.cells) {
      out.push({
        name: this.name,
        description: this.description,
        labels: decodeLabels(key, this.labelNames),
        buckets: this.buckets.map((upperBound, i) => ({
          upperBound,
          count: cell.bucketCounts[i]!,
        })),
        sum: cell.sum,
        count: cell.count,
      });
    }
    return out;
  }

  reset(): void {
    this.cells.clear();
  }

  private assertLabelKeysMatch(labels: LabelSet): void {
    const got = Object.keys(labels).sort();
    const want = [...this.labelNames].sort();
    if (got.length !== want.length || got.some((k, i) => k !== want[i])) {
      throw new RangeError(
        `label set mismatch for ${this.name}: expected ${JSON.stringify(want)}, got ${JSON.stringify(got)}`,
      );
    }
  }
}
