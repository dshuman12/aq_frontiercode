// Gauges: values that can move up or down.
//
// Where a counter only knows about deltas, a gauge tracks an absolute
// instantaneous value. Examples: in-flight job count, queue depth,
// memory usage. Setting overrides; inc/dec adjust relative to current.

import { encodeLabels, decodeLabels, type LabelSet } from './counter.ts';

export interface GaugeSnapshot {
  name: string;
  description: string;
  labels: LabelSet;
  value: number;
}

export class Gauge {
  private readonly cells = new Map<string, number>();

  constructor(
    readonly name: string,
    readonly description: string,
    readonly labelNames: readonly string[] = [],
  ) {
    if (!/^[a-z_][a-z0-9_]*$/.test(name)) {
      throw new RangeError(`metric name must match [a-z_][a-z0-9_]*: ${name}`);
    }
  }

  set(value: number, labels: LabelSet = {}): void {
    if (!Number.isFinite(value)) {
      throw new RangeError(`gauge value must be finite, got ${value}`);
    }
    this.assertLabelKeysMatch(labels);
    const key = encodeLabels(labels, this.labelNames);
    this.cells.set(key, value);
  }

  inc(labels: LabelSet = {}, by = 1): void {
    this.assertLabelKeysMatch(labels);
    const key = encodeLabels(labels, this.labelNames);
    this.cells.set(key, (this.cells.get(key) ?? 0) + by);
  }

  dec(labels: LabelSet = {}, by = 1): void {
    this.inc(labels, -by);
  }

  get(labels: LabelSet = {}): number {
    this.assertLabelKeysMatch(labels);
    const key = encodeLabels(labels, this.labelNames);
    return this.cells.get(key) ?? 0;
  }

  snapshot(): GaugeSnapshot[] {
    const out: GaugeSnapshot[] = [];
    for (const [key, value] of this.cells) {
      out.push({
        name: this.name,
        description: this.description,
        labels: decodeLabels(key, this.labelNames),
        value,
      });
    }
    return out;
  }

  reset(): void {
    this.cells.clear();
  }

  private assertLabelKeysMatch(labels: LabelSet): void {
    const got = Object.keys(labels).sort();
    const want = [...this.labelNames].sort();
    if (got.length !== want.length || got.some((k, i) => k !== want[i])) {
      throw new RangeError(
        `label set mismatch for ${this.name}: expected ${JSON.stringify(want)}, got ${JSON.stringify(got)}`,
      );
    }
  }
}
