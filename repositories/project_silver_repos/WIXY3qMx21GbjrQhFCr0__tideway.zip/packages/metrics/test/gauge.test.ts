import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { Gauge } from '../src/gauge.ts';

describe('Gauge: set / get', () => {
  it('starts at 0', () => {
    const g = new Gauge('inflight', 'Inflight runs');
    assert.equal(g.get(), 0);
  });

  it('set replaces value', () => {
    const g = new Gauge('inflight', 'd');
    g.set(7);
    g.set(3);
    assert.equal(g.get(), 3);
  });

  it('refuses NaN / Infinity', () => {
    const g = new Gauge('x', 'd');
    assert.throws(() => g.set(NaN), RangeError);
    assert.throws(() => g.set(Infinity), RangeError);
  });
});

describe('Gauge: inc / dec', () => {
  it('inc adds', () => {
    const g = new Gauge('x', 'd');
    g.set(10);
    g.inc({}, 5);
    assert.equal(g.get(), 15);
  });

  it('dec subtracts', () => {
    const g = new Gauge('x', 'd');
    g.set(10);
    g.dec({}, 3);
    assert.equal(g.get(), 7);
  });

  it('can go negative (unlike a counter)', () => {
    const g = new Gauge('x', 'd');
    g.dec({}, 5);
    assert.equal(g.get(), -5);
  });

  it('default inc/dec is by 1', () => {
    const g = new Gauge('x', 'd');
    g.inc();
    g.inc();
    g.dec();
    assert.equal(g.get(), 1);
  });
});

describe('Gauge: labels', () => {
  it('cells are independent per label set', () => {
    const g = new Gauge('queue_depth', 'd', ['queue']);
    g.set(5, { queue: 'db' });
    g.set(2, { queue: 'api' });
    assert.equal(g.get({ queue: 'db' }), 5);
    assert.equal(g.get({ queue: 'api' }), 2);
  });

  it('snapshot includes every cell', () => {
    const g = new Gauge('queue_depth', 'd', ['queue']);
    g.set(5, { queue: 'db' });
    g.set(2, { queue: 'api' });
    const snap = g.snapshot();
    assert.equal(snap.length, 2);
  });
});

describe('Gauge: reset', () => {
  it('clears all cells', () => {
    const g = new Gauge('x', 'd', ['k']);
    g.set(5, { k: 'a' });
    g.set(7, { k: 'b' });
    g.reset();
    assert.equal(g.get({ k: 'a' }), 0);
    assert.equal(g.snapshot().length, 0);
  });
});
