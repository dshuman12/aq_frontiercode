import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { DEFAULT_LATENCY_BUCKETS_MS, Histogram } from '../src/histogram.ts';

describe('Histogram: construction', () => {
  it('accepts default buckets', () => {
    const h = new Histogram('latency', 'd');
    assert.deepEqual([...h.buckets], [...DEFAULT_LATENCY_BUCKETS_MS]);
  });

  it('rejects non-ascending buckets', () => {
    assert.throws(() => new Histogram('x', 'd', { buckets: [1, 5, 3] }));
  });

  it('fails on duplicate bucket boundaries', () => {
    assert.throws(() => new Histogram('x', 'd', { buckets: [1, 1, 5] }));
  });
});

describe('Histogram: observe', () => {
  it('starts empty', () => {
    const h = new Histogram('x', 'd', { buckets: [10, 100] });
    const snap = h.snapshot();
    assert.equal(snap.length, 0);
  });

  it('counts observations within each bucket cumulatively', () => {
    const h = new Histogram('x', 'd', { buckets: [10, 100, 1000] });
    h.observe(5);
    h.observe(50);
    h.observe(500);
    h.observe(5000);
    const snap = h.snapshot()[0]!;
    // Cumulative buckets: <=10 -> 1, <=100 -> 2, <=1000 -> 3, <=Inf -> 4
    assert.equal(snap.buckets[0]!.count, 1);
    assert.equal(snap.buckets[1]!.count, 2);
    assert.equal(snap.buckets[2]!.count, 3);
    assert.equal(snap.count, 4);
    assert.equal(snap.sum, 5555);
  });

  it('boundary value goes into the matching bucket', () => {
    const h = new Histogram('x', 'd', { buckets: [10] });
    h.observe(10);
    const snap = h.snapshot()[0]!;
    assert.equal(snap.buckets[0]!.count, 1);
  });

  it('non-finite observations are silently dropped', () => {
    const h = new Histogram('x', 'd');
    h.observe(NaN);
    h.observe(Infinity);
    assert.equal(h.snapshot().length, 0);
  });

  it('different label sets are independent', () => {
    const h = new Histogram('latency', 'd', { buckets: [10, 100], labelNames: ['queue'] });
    h.observe(5, { queue: 'db' });
    h.observe(50, { queue: 'api' });
    const snap = h.snapshot();
    assert.equal(snap.length, 2);
  });
});

describe('Histogram: percentile', () => {
  it('returns undefined for empty histogram', () => {
    const h = new Histogram('x', 'd');
    assert.equal(h.percentile(50), undefined);
  });

  it('p50 of even distribution lands in the middle bucket', () => {
    const h = new Histogram('x', 'd', { buckets: [10, 20, 30, 40] });
    for (let i = 1; i <= 40; i += 1) h.observe(i);
    const p50 = h.percentile(50)!;
    assert.ok(p50 >= 20 && p50 <= 30);
  });

  it('p100 is the largest bucket boundary', () => {
    const h = new Histogram('x', 'd', { buckets: [1, 2, 3] });
    h.observe(1);
    h.observe(2);
    h.observe(3);
    assert.equal(h.percentile(100), 3);
  });

  it('bails on p out of [0, 100]', () => {
    const h = new Histogram('x', 'd');
    assert.throws(() => h.percentile(-1));
    assert.throws(() => h.percentile(101));
  });
});

describe('Histogram: reset', () => {
  it('clears observations', () => {
    const h = new Histogram('x', 'd');
    h.observe(5);
    h.reset();
    assert.equal(h.snapshot().length, 0);
  });
});
