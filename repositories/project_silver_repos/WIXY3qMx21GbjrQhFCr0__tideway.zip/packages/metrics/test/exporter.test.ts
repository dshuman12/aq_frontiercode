import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { Counter } from '../src/counter.ts';
import { Gauge } from '../src/gauge.ts';
import { Histogram } from '../src/histogram.ts';
import { MetricRegistry } from '../src/registry.ts';
import { exportPrometheus } from '../src/exporter.ts';

describe('exportPrometheus', () => {
  it('returns empty for empty registry', () => {
    assert.equal(exportPrometheus(new MetricRegistry()), '');
  });

  it('emits HELP and TYPE for a counter', () => {
    const r = new MetricRegistry();
    const c = r.registerCounter(new Counter('runs_total', 'Total runs.'));
    c.inc({}, 5);
    const out = exportPrometheus(r);
    assert.match(out, /# HELP runs_total Total runs\./);
    assert.match(out, /# TYPE runs_total counter/);
    assert.match(out, /runs_total 5/);
  });

  it('emits labeled samples', () => {
    const r = new MetricRegistry();
    const c = r.registerCounter(new Counter('runs_total', 'd', ['handler']));
    c.inc({ handler: 'email' }, 2);
    c.inc({ handler: 'audit' }, 3);
    const out = exportPrometheus(r);
    assert.match(out, /runs_total\{handler="email"\} 2/);
    assert.match(out, /runs_total\{handler="audit"\} 3/);
  });

  it('emits gauge type correctly', () => {
    const r = new MetricRegistry();
    const g = r.registerGauge(new Gauge('inflight', 'd'));
    g.set(7);
    const out = exportPrometheus(r);
    assert.match(out, /# TYPE inflight gauge/);
    assert.match(out, /inflight 7/);
  });

  it('emits histogram with bucket lines, sum, count', () => {
    const r = new MetricRegistry();
    const h = r.registerHistogram(new Histogram('latency_ms', 'd', { buckets: [10, 100] }));
    h.observe(5);
    h.observe(50);
    h.observe(500);
    const out = exportPrometheus(r);
    assert.match(out, /# TYPE latency_ms histogram/);
    assert.match(out, /latency_ms_bucket\{le="10"\} 1/);
    assert.match(out, /latency_ms_bucket\{le="100"\} 2/);
    assert.match(out, /latency_ms_bucket\{le="\+Inf"\} 3/);
    assert.match(out, /latency_ms_sum 555/);
    assert.match(out, /latency_ms_count 3/);
  });

  it('escapes label values containing quotes and backslashes', () => {
    const r = new MetricRegistry();
    const c = r.registerCounter(new Counter('x', 'd', ['k']));
    c.inc({ k: 'a"b' });
    c.inc({ k: 'a\\b' });
    const out = exportPrometheus(r);
    assert.match(out, /k="a\\"b"/);
    assert.match(out, /k="a\\\\b"/);
  });

  it('orders label keys lexicographically in output', () => {
    const r = new MetricRegistry();
    const c = r.registerCounter(new Counter('x', 'd', ['z', 'a']));
    c.inc({ a: '1', z: '2' });
    const out = exportPrometheus(r);
    assert.match(out, /\{a="1",z="2"\}/);
  });
});
