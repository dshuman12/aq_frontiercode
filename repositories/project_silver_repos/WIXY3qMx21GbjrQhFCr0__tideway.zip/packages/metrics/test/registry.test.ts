import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { Counter } from '../src/counter.ts';
import { Gauge } from '../src/gauge.ts';
import { Histogram } from '../src/histogram.ts';
import { MetricRegistry } from '../src/registry.ts';

describe('MetricRegistry', () => {
  it('starts empty', () => {
    const r = new MetricRegistry();
    const all = r.all();
    assert.equal(all.counters.length, 0);
    assert.equal(all.gauges.length, 0);
    assert.equal(all.histograms.length, 0);
  });

  it('registerCounter / Gauge / Histogram', () => {
    const r = new MetricRegistry();
    r.registerCounter(new Counter('c', 'd'));
    r.registerGauge(new Gauge('g', 'd'));
    r.registerHistogram(new Histogram('h', 'd'));
    const all = r.all();
    assert.equal(all.counters.length, 1);
    assert.equal(all.gauges.length, 1);
    assert.equal(all.histograms.length, 1);
  });

  it('refuses duplicate name across types', () => {
    const r = new MetricRegistry();
    r.registerCounter(new Counter('shared', 'd'));
    assert.throws(() => r.registerGauge(new Gauge('shared', 'd')));
    assert.throws(() => r.registerHistogram(new Histogram('shared', 'd')));
  });

  it('has reports membership', () => {
    const r = new MetricRegistry();
    r.registerCounter(new Counter('foo', 'd'));
    assert.equal(r.has('foo'), true);
    assert.equal(r.has('bar'), false);
  });

  it('reset clears values but keeps registrations', () => {
    const r = new MetricRegistry();
    const c = r.registerCounter(new Counter('foo', 'd'));
    c.inc();
    r.reset();
    assert.equal(c.get(), 0);
    assert.equal(r.has('foo'), true);
  });

  it('clear deregisters everything', () => {
    const r = new MetricRegistry();
    r.registerCounter(new Counter('foo', 'd'));
    r.clear();
    assert.equal(r.has('foo'), false);
  });
});
