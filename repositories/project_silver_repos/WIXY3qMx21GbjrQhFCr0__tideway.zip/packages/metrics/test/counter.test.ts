import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { Counter } from '../src/counter.ts';

describe('Counter: construction', () => {
  it('accepts a valid name', () => {
    const c = new Counter('runs_total', 'Total runs');
    assert.equal(c.name, 'runs_total');
    assert.equal(c.description, 'Total runs');
  });

  it('rejects an invalid metric name', () => {
    assert.throws(() => new Counter('Runs', 'no'), RangeError);
    assert.throws(() => new Counter('1runs', 'no'), RangeError);
    assert.throws(() => new Counter('runs-total', 'no'), RangeError);
  });

  it('fails on invalid label name', () => {
    assert.throws(() => new Counter('ok', 'd', ['Bad']), RangeError);
  });
});

describe('Counter: inc/get without labels', () => {
  it('starts at 0', () => {
    const c = new Counter('x', 'x');
    assert.equal(c.get(), 0);
  });

  it('inc adds 1 by default', () => {
    const c = new Counter('x', 'x');
    c.inc();
    c.inc();
    assert.equal(c.get(), 2);
  });

  it('inc by N adds N', () => {
    const c = new Counter('x', 'x');
    c.inc({}, 7);
    assert.equal(c.get(), 7);
  });

  it('inc by 0 is a no-op', () => {
    const c = new Counter('x', 'x');
    c.inc({}, 0);
    assert.equal(c.get(), 0);
  });

  it('refuses negative inc', () => {
    const c = new Counter('x', 'x');
    assert.throws(() => c.inc({}, -1), RangeError);
  });
});

describe('Counter: labels', () => {
  it('different label values produce independent cells', () => {
    const c = new Counter('runs_total', 'd', ['handler']);
    c.inc({ handler: 'email' });
    c.inc({ handler: 'email' });
    c.inc({ handler: 'audit' });
    assert.equal(c.get({ handler: 'email' }), 2);
    assert.equal(c.get({ handler: 'audit' }), 1);
  });

  it('same label set in different orders hashes the same', () => {
    const c = new Counter('x', 'd', ['a', 'b']);
    c.inc({ a: '1', b: '2' });
    c.inc({ b: '2', a: '1' });
    assert.equal(c.get({ a: '1', b: '2' }), 2);
  });

  it('throws on missing label value', () => {
    const c = new Counter('x', 'd', ['handler']);
    assert.throws(() => c.inc({} as { handler: string }), RangeError);
  });

  it('throws on extra label key', () => {
    const c = new Counter('x', 'd', ['handler']);
    assert.throws(() => c.inc({ handler: 'h', extra: 'e' } as { handler: string }), RangeError);
  });

  it('escapes label values containing , = and \\', () => {
    const c = new Counter('x', 'd', ['h']);
    c.inc({ h: 'a,b' });
    c.inc({ h: 'a=b' });
    c.inc({ h: 'a\\b' });
    assert.equal(c.get({ h: 'a,b' }), 1);
    assert.equal(c.get({ h: 'a=b' }), 1);
    assert.equal(c.get({ h: 'a\\b' }), 1);
  });
});

describe('Counter: total / snapshot / reset', () => {
  it('total sums all label cells', () => {
    const c = new Counter('runs_total', 'd', ['handler']);
    c.inc({ handler: 'a' }, 3);
    c.inc({ handler: 'b' }, 4);
    assert.equal(c.total(), 7);
  });

  it('snapshot returns one entry per cell', () => {
    const c = new Counter('runs_total', 'd', ['handler']);
    c.inc({ handler: 'a' }, 3);
    c.inc({ handler: 'b' }, 4);
    const snap = c.snapshot();
    assert.equal(snap.length, 2);
    assert.equal(snap.find((s) => s.labels.handler === 'a')?.value, 3);
    assert.equal(snap.find((s) => s.labels.handler === 'b')?.value, 4);
  });

  it('reset clears all cells', () => {
    const c = new Counter('x', 'd');
    c.inc({}, 5);
    c.reset();
    assert.equal(c.get(), 0);
    assert.equal(c.snapshot().length, 0);
  });
});
