import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { QueueLimits } from '../src/concurrency.ts';

describe('QueueLimits', () => {
  it('default cap is Infinity', () => {
    const q = new QueueLimits();
    assert.equal(q.cap('anything'), Infinity);
  });

  it('honors a configured default', () => {
    const q = new QueueLimits({ defaultCap: 5 });
    assert.equal(q.cap('whatever'), 5);
  });

  it('per-queue cap overrides default', () => {
    const q = new QueueLimits({ defaultCap: 5 });
    q.setCap('db', 2);
    assert.equal(q.cap('db'), 2);
    assert.equal(q.cap('api'), 5);
  });

  it('refuses negative cap', () => {
    const q = new QueueLimits();
    assert.throws(() => q.setCap('x', -1), RangeError);
  });

  it('acquire bumps current up to cap', () => {
    const q = new QueueLimits();
    q.setCap('db', 2);
    assert.equal(q.acquire('db'), true);
    assert.equal(q.acquire('db'), true);
    assert.equal(q.acquire('db'), false);
    assert.equal(q.current('db'), 2);
  });

  it('release decrements current', () => {
    const q = new QueueLimits();
    q.setCap('db', 2);
    q.acquire('db');
    q.acquire('db');
    q.release('db');
    assert.equal(q.current('db'), 1);
    assert.equal(q.acquire('db'), true);
  });

  it('release on zero current is a no-op', () => {
    const q = new QueueLimits();
    q.setCap('db', 2);
    q.release('db');
    q.release('db');
    assert.equal(q.current('db'), 0);
  });

  it('available reports remaining capacity', () => {
    const q = new QueueLimits();
    q.setCap('db', 3);
    q.acquire('db');
    assert.equal(q.available('db'), 2);
    q.acquire('db');
    q.acquire('db');
    assert.equal(q.available('db'), 0);
  });

  it('available is Infinity for an unbounded queue', () => {
    const q = new QueueLimits();
    assert.equal(q.available('default'), Infinity);
  });

  it('cap of zero blocks all dispatch', () => {
    const q = new QueueLimits();
    q.setCap('blocked', 0);
    assert.equal(q.acquire('blocked'), false);
  });

  it('snapshot includes both capped and uncapped queues that have activity', () => {
    const q = new QueueLimits();
    q.setCap('db', 3);
    q.acquire('db');
    q.acquire('api'); // implicit cap = Infinity
    const snap = q.snapshot();
    assert.equal(snap['db']!.cap, 3);
    assert.equal(snap['db']!.current, 1);
    assert.equal(snap['api']!.cap, Infinity);
    assert.equal(snap['api']!.current, 1);
  });
});
