import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { Graph } from '@tideway/dag';
import { initialState, transition, type RunState } from '@tideway/runstate';
import { QueueLimits } from '../src/concurrency.ts';
import { decide, type SchedulableNode } from '../src/dispatch.ts';

const t = (n: number) => BigInt(n);

const node = (queue = 'default', priority = 0, deadline = Infinity): SchedulableNode => ({
  queue,
  priority,
  declaredDeadline: deadline,
});

const ctx = (now = 1000, freeWorkers = 10, deadlines: Record<string, number> = {}) => ({
  now,
  freeWorkers,
  effectiveDeadline: new Map(Object.entries(deadlines)),
});

describe('decide: single ready node', () => {
  it('dispatches a queued node with no parents', () => {
    const g = new Graph<SchedulableNode>();
    g.addNode('a', node());
    const states = new Map<string, RunState>();
    states.set('a', initialState(t(0)));
    const r = decide(g, states, new QueueLimits(), ctx());
    assert.deepEqual(r.dispatch, ['a']);
    assert.deepEqual(r.cancel, []);
  });

  it('does NOT dispatch a node whose parent is still running', () => {
    const g = new Graph<SchedulableNode>();
    g.addNode('a', node()).addNode('b', node()).addEdge('a', 'b');
    const states = new Map<string, RunState>();
    states.set('a', transition(initialState(t(0)), {
      kind: 'dispatch', at: t(10), workerId: 'w', leaseExpiresAt: t(1000),
    }));
    states.set('b', initialState(t(0)));
    const r = decide(g, states, new QueueLimits(), ctx());
    assert.deepEqual(r.dispatch, []);
  });

  it('dispatches a child once its parent succeeds', () => {
    const g = new Graph<SchedulableNode>();
    g.addNode('a', node()).addNode('b', node()).addEdge('a', 'b');
    const states = new Map<string, RunState>();
    let s = initialState(t(0));
    s = transition(s, { kind: 'dispatch', at: t(10), workerId: 'w', leaseExpiresAt: t(1000) });
    s = transition(s, { kind: 'succeed', at: t(20), result: null });
    states.set('a', s);
    states.set('b', initialState(t(0)));
    const r = decide(g, states, new QueueLimits(), ctx());
    assert.deepEqual(r.dispatch, ['b']);
  });
});

describe('decide: parent failure cancellation', () => {
  it('cancels a child whose parent failed', () => {
    const g = new Graph<SchedulableNode>();
    g.addNode('a', node()).addNode('b', node()).addEdge('a', 'b');
    const states = new Map<string, RunState>();
    let s = initialState(t(0));
    s = transition(s, { kind: 'dispatch', at: t(10), workerId: 'w', leaseExpiresAt: t(1000) });
    s = transition(s, { kind: 'fail', at: t(20), failureKind: 'permanent', message: 'x' });
    states.set('a', s);
    states.set('b', initialState(t(0)));
    const r = decide(g, states, new QueueLimits(), ctx());
    assert.deepEqual(r.parentFailureCancel, ['b']);
    assert.deepEqual(r.dispatch, []);
  });

  it('cancels every transitive child of a failed root', () => {
    // a -> b -> c, a fails -> b cancels (this tick), c can't yet because
    // its parent isn't terminal-failed yet (b is still queued). Next tick
    // would cancel c. Here we just check b.
    const g = new Graph<SchedulableNode>();
    g.addNode('a', node()).addNode('b', node()).addNode('c', node());
    g.addEdge('a', 'b').addEdge('b', 'c');
    const states = new Map<string, RunState>();
    let s = initialState(t(0));
    s = transition(s, { kind: 'dispatch', at: t(10), workerId: 'w', leaseExpiresAt: t(1000) });
    s = transition(s, { kind: 'fail', at: t(20), failureKind: 'permanent', message: 'x' });
    states.set('a', s);
    states.set('b', initialState(t(0)));
    states.set('c', initialState(t(0)));
    const r = decide(g, states, new QueueLimits(), ctx());
    assert.deepEqual(r.parentFailureCancel, ['b']);
  });
});

describe('decide: deadline handling', () => {
  it('cancels nodes whose effective deadline is breached', () => {
    const g = new Graph<SchedulableNode>();
    g.addNode('a', node());
    const states = new Map<string, RunState>();
    states.set('a', initialState(t(0)));
    const r = decide(g, states, new QueueLimits(), ctx(2000, 10, { a: 1500 }));
    assert.deepEqual(r.cancel, ['a']);
    assert.deepEqual(r.dispatch, []);
  });

  it('orders by earliest effective deadline first', () => {
    const g = new Graph<SchedulableNode>();
    g.addNode('a', node()).addNode('b', node()).addNode('c', node());
    const states = new Map<string, RunState>();
    for (const id of ['a', 'b', 'c']) states.set(id, initialState(t(0)));
    const r = decide(
      g,
      states,
      new QueueLimits(),
      ctx(1000, 10, { a: 5000, b: 2000, c: 3000 }),
    );
    assert.deepEqual(r.dispatch, ['b', 'c', 'a']);
  });
});

describe('decide: retry_scheduled', () => {
  it('does NOT dispatch a retry_scheduled node before nextAttemptAt', () => {
    const g = new Graph<SchedulableNode>();
    g.addNode('a', node());
    const states = new Map<string, RunState>();
    let s = initialState(t(0));
    s = transition(s, { kind: 'dispatch', at: t(10), workerId: 'w', leaseExpiresAt: t(1000) });
    s = transition(s, { kind: 'schedule_retry', at: t(20), nextAttemptAt: t(5000) });
    states.set('a', s);
    const r = decide(g, states, new QueueLimits(), ctx(2000));
    assert.deepEqual(r.dispatch, []);
  });

  it('dispatches a retry_scheduled node once nextAttemptAt has arrived', () => {
    const g = new Graph<SchedulableNode>();
    g.addNode('a', node());
    const states = new Map<string, RunState>();
    let s = initialState(t(0));
    s = transition(s, { kind: 'dispatch', at: t(10), workerId: 'w', leaseExpiresAt: t(1000) });
    s = transition(s, { kind: 'schedule_retry', at: t(20), nextAttemptAt: t(5000) });
    states.set('a', s);
    const r = decide(g, states, new QueueLimits(), ctx(5500));
    assert.deepEqual(r.dispatch, ['a']);
  });
});

describe('decide: priority and insertion-order', () => {
  it('dispatches higher priority first when deadlines tie', () => {
    const g = new Graph<SchedulableNode>();
    g.addNode('low', node('default', 1));
    g.addNode('high', node('default', 5));
    const states = new Map<string, RunState>();
    states.set('low', initialState(t(0)));
    states.set('high', initialState(t(0)));
    const r = decide(g, states, new QueueLimits(), ctx());
    assert.deepEqual(r.dispatch, ['high', 'low']);
  });

  it('breaks priority ties by insertion order', () => {
    const g = new Graph<SchedulableNode>();
    g.addNode('first', node());
    g.addNode('second', node());
    const states = new Map<string, RunState>();
    states.set('first', initialState(t(0)));
    states.set('second', initialState(t(0)));
    const r = decide(g, states, new QueueLimits(), ctx());
    assert.deepEqual(r.dispatch, ['first', 'second']);
  });
});

describe('decide: queue caps and free workers', () => {
  it('respects per-queue caps', () => {
    const g = new Graph<SchedulableNode>();
    g.addNode('a', node('db'));
    g.addNode('b', node('db'));
    g.addNode('c', node('db'));
    const states = new Map<string, RunState>();
    for (const id of ['a', 'b', 'c']) states.set(id, initialState(t(0)));
    const limits = new QueueLimits();
    limits.setCap('db', 2);
    const r = decide(g, states, limits, ctx());
    assert.equal(r.dispatch.length, 2);
  });

  it('respects free worker count globally', () => {
    const g = new Graph<SchedulableNode>();
    for (let i = 0; i < 5; i += 1) g.addNode(`n${i}`, node());
    const states = new Map<string, RunState>();
    for (const id of g.allNodes()) states.set(id, initialState(t(0)));
    const r = decide(g, states, new QueueLimits(), ctx(1000, 3));
    assert.equal(r.dispatch.length, 3);
  });

  it('does not let a full queue starve a different queue', () => {
    const g = new Graph<SchedulableNode>();
    g.addNode('a', node('db'));
    g.addNode('b', node('db'));
    g.addNode('c', node('api'));
    const states = new Map<string, RunState>();
    for (const id of g.allNodes()) states.set(id, initialState(t(0)));
    const limits = new QueueLimits();
    limits.setCap('db', 1);
    const r = decide(g, states, limits, ctx());
    // a (db) and c (api) get dispatched. b (db) is deferred.
    assert.deepEqual(r.dispatch.sort(), ['a', 'c']);
  });
});

describe('decide: skips terminal and unknown nodes', () => {
  it('does not dispatch an already-succeeded node', () => {
    const g = new Graph<SchedulableNode>();
    g.addNode('a', node());
    const states = new Map<string, RunState>();
    let s = initialState(t(0));
    s = transition(s, { kind: 'dispatch', at: t(10), workerId: 'w', leaseExpiresAt: t(1000) });
    s = transition(s, { kind: 'succeed', at: t(20), result: 1 });
    states.set('a', s);
    const r = decide(g, states, new QueueLimits(), ctx());
    assert.deepEqual(r.dispatch, []);
  });

  it('skips nodes with no state entry', () => {
    const g = new Graph<SchedulableNode>();
    g.addNode('a', node());
    const states = new Map<string, RunState>(); // empty
    const r = decide(g, states, new QueueLimits(), ctx());
    assert.deepEqual(r.dispatch, []);
  });
});
