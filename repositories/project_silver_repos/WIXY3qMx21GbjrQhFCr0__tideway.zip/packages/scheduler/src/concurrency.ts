// Queue-level concurrency caps.
//
// A "queue" is just a string label attached to each node. Operators use
// queues to keep, say, the database-write workload from drowning out the
// API-call workload. The scheduler tracks a running count per queue and
// rejects dispatch when a node would exceed its queue's cap.
//
// The data structure is deliberately minimal: a Map<string, number> for
// caps and another for current counts. Nothing here is concurrent-safe;
// the scheduler runs single-threaded inside the runner's event loop.

export type QueueName = string;

export class QueueLimits {
  private readonly caps = new Map<QueueName, number>();
  private readonly running = new Map<QueueName, number>();
  private readonly defaultCap: number;

  constructor(opts?: { defaultCap?: number }) {
    this.defaultCap = opts?.defaultCap ?? Infinity;
  }

  setCap(queue: QueueName, cap: number): void {
    if (cap < 0) throw new RangeError(`cap must be >= 0, got ${cap}`);
    this.caps.set(queue, cap);
  }

  cap(queue: QueueName): number {
    return this.caps.get(queue) ?? this.defaultCap;
  }

  current(queue: QueueName): number {
    return this.running.get(queue) ?? 0;
  }

  available(queue: QueueName): number {
    const c = this.cap(queue);
    if (c === Infinity) return Infinity;
    return Math.max(0, c - this.current(queue));
  }

  // Try to reserve a slot. Returns true on success. Does not throw on a
  // miss because callers always have a sensible thing to do (defer the
  // dispatch); throwing would just force every callsite into a try/catch.
  //
  // XXX magic number alert: 0 is a valid cap (means "queue paused"), but
  // negative caps are rejected at setCap. The reasoning was that an
  // operator who types `--cap=-5` probably made a typo, but I'm not 100%
  // sure that's right -- it might be cleaner to clamp instead.
  acquire(queue: QueueName): boolean {
    const c = this.cap(queue);
    const cur = this.current(queue);
    if (cur >= c) return false;
    this.running.set(queue, cur + 1);
    return true;
  }

  release(queue: QueueName): void {
    const cur = this.current(queue);
    if (cur === 0) {
      // Releasing without a prior acquire is a programmer error, but we
      // floor at 0 rather than throwing because in production we have
      // seen a runner crash in this exact spot when a cleanup race
      // released twice. Better to lose a slot than to crash.
      return;
    }
    this.running.set(queue, cur - 1);
  }

  snapshot(): Record<QueueName, { cap: number; current: number }> {
    const out: Record<QueueName, { cap: number; current: number }> = {};
    const seen = new Set<QueueName>();
    for (const q of this.caps.keys()) {
      seen.add(q);
      out[q] = { cap: this.cap(q), current: this.current(q) };
    }
    for (const q of this.running.keys()) {
      if (seen.has(q)) continue;
      out[q] = { cap: this.cap(q), current: this.current(q) };
    }
    return out;
  }
}
