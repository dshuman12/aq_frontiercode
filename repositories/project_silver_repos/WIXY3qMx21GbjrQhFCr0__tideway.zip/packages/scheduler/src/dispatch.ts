// The scheduler's core decision: given the current state of a workflow
// (DAG + per-node runstate) and resource availability (queues, workers),
// return the set of nodes to dispatch right now.
//
// The function is pure: no I/O, no clock, no random. The runner is
// responsible for calling `decide` once per tick, applying the resulting
// `Dispatch` decisions, and persisting the new state. This split keeps
// the scheduler trivially testable.
//
// The dispatch order matters. Within a single tick we order by:
//   1. Lowest effective deadline first (most urgent).
//   2. Higher priority next.
//   3. Insertion-order tiebreak.
//
// The deadline-first ordering is important: under load, the runtime
// should drop work that has no chance of finishing in time rather than
// dispatching it and discovering the breach mid-execution. (Discovery
// mid-execution still works, but it wastes a worker slot.)

import type { Graph, NodeId } from '@tideway/dag';
import { isBreached } from '@tideway/deadline';
import type { RunState } from '@tideway/runstate';
import type { QueueLimits, QueueName } from './concurrency.ts';

export interface SchedulableNode {
  queue: QueueName;
  priority: number; // higher first
  declaredDeadline: number; // Infinity = no declared deadline
}

export interface Decision {
  // Nodes the runner should dispatch right now.
  dispatch: NodeId[];
  // Nodes the runner should mark canceled with reason='deadline'.
  // (Deadline breached before we could dispatch.)
  cancel: NodeId[];
  // Nodes the runner should mark canceled with reason='parent_failure'.
  parentFailureCancel: NodeId[];
}

export interface DecideContext {
  now: number;
  effectiveDeadline: Map<NodeId, number>;
  // Number of free worker slots in total. The scheduler caps dispatch at
  // this number after queue-level caps.
  freeWorkers: number;
}

export function decide<T extends SchedulableNode>(
  graph: Graph<T>,
  states: Map<NodeId, RunState>,
  limits: QueueLimits,
  ctx: DecideContext,
): Decision {
  const dispatch: NodeId[] = [];
  const cancel: NodeId[] = [];
  const parentFailureCancel: NodeId[] = [];

  // First sweep: figure out which nodes are eligible.
  // A node is eligible iff:
  //   - its state is 'queued' or 'retry_scheduled' with nextAttemptAt <= now
  //   - every parent is in a terminal-success state
  //   - it isn't already deadline-breached (in which case we cancel it
  //     instead of dispatching)
  //   - none of its parents failed terminally (in which case we
  //     parent-failure-cancel)
  const eligible: NodeId[] = [];

  for (const id of graph.allNodes()) {
    const state = states.get(id);
    if (!state) continue; // unknown to scheduler; treat as not-yet-submitted

    // Skip terminal states.
    if (
      state.kind === 'succeeded' ||
      state.kind === 'failed' ||
      state.kind === 'canceled' ||
      state.kind === 'timed_out'
    ) {
      continue;
    }

    // Skip currently running.
    if (state.kind === 'running') continue;

    // retry_scheduled: only eligible if its nextAttemptAt has come due.
    if (state.kind === 'retry_scheduled') {
      if (Number(state.nextAttemptAt) > ctx.now) continue;
    }

    // Check parent states.
    const parents = graph.parentsOf(id);
    let parentFailed = false;
    let parentsAllSucceeded = true;
    for (const p of parents) {
      const ps = states.get(p);
      if (!ps) {
        parentsAllSucceeded = false;
        break;
      }
      if (ps.kind === 'failed' || ps.kind === 'canceled' || ps.kind === 'timed_out') {
        parentFailed = true;
        break;
      }
      if (ps.kind !== 'succeeded') {
        parentsAllSucceeded = false;
        break;
      }
    }
    if (parentFailed) {
      parentFailureCancel.push(id);
      continue;
    }
    if (!parentsAllSucceeded) continue;

    // Deadline check.
    const eff = ctx.effectiveDeadline.get(id) ?? Infinity;
    if (isBreached(eff, ctx.now)) {
      cancel.push(id);
      continue;
    }

    eligible.push(id);
  }

  // ----------------------------------------------------------------------
  // Abandoned experiment: work-stealing across queues.
  //
  // The idea was that if queue A is at its cap but queue B has free
  // capacity AND a node in B is blocked on a deadline, we'd "steal" the
  // node into queue A's capacity. In a 2-queue test it looked promising
  // but it interacted awfully with the deadline ordering: stealing
  // changed the dispatch order, which changed which node hit its
  // deadline first, which changed which nodes were stolen on the next
  // tick. Convergence was not guaranteed.
  //
  // Leaving the sketch here so I don't accidentally re-derive it. If
  // queue caps become a real bottleneck, the right fix is probably
  // dynamic cap adjustment (e.g., per-queue caps that scale with idle
  // workers), not stealing.
  //
  // for (const id of eligible) {
  //   const value = graph.get(id);
  //   if (limits.available(value.queue) <= 0) {
  //     // Find a queue with capacity AND no eligible nodes of its own.
  //     const stealTarget = findStealableQueue(limits, eligible, graph);
  //     if (stealTarget) {
  //       limits.acquire(stealTarget); // borrow capacity
  //       dispatch.push(id);
  //     }
  //   }
  // }
  // ----------------------------------------------------------------------

  // Second sweep: order by deadline, priority, insertion. Then pick as
  // many as fit under queue caps and free workers.
  //
  // XXX I'm not 100% sure the priority-vs-deadline ordering is right.
  // Right now deadline beats priority always; an operator with a
  // priority-9 job at deadline=10s and a priority-1 job at deadline=2s
  // sees the priority-1 dispatched first because its deadline is
  // tighter. That feels wrong but I can't think of a case where it's
  // actually wrong, so leaving it currently. If it becomes a problem,
  // option is to add a "priority floor" that overrides deadline for
  // priority >= floor.
  eligible.sort((a, b) => {
    const da = ctx.effectiveDeadline.get(a) ?? Infinity;
    const db = ctx.effectiveDeadline.get(b) ?? Infinity;
    if (da !== db) return da - db;
    const pa = graph.get(a).priority;
    const pb = graph.get(b).priority;
    if (pa !== pb) return pb - pa; // higher priority first
    return graph.indexOf(a) - graph.indexOf(b);
  });

  let workers = ctx.freeWorkers;
  for (const id of eligible) {
    if (workers <= 0) break;
    const value = graph.get(id);
    if (limits.acquire(value.queue)) {
      dispatch.push(id);
      workers -= 1;
    }
    // else: queue full, defer. Don't break -- a different queue may have
    // capacity for the next node.
  }

  return { dispatch, cancel, parentFailureCancel };
}
