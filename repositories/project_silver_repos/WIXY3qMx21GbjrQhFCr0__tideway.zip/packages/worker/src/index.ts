// Worker: the per-job execution context.
//
// A handler is a user-provided function from `JobContext` to a result. The
// worker wraps that with everything around the handler that the runtime
// needs: AbortSignal for cancellation, lease heartbeating, output
// capture, normalized failure classification.
//
// The worker doesn't know about persistence, schedulers, or queues. It
// gets a handler, an input, and a context; it runs the handler and
// returns one of {Succeeded, Failed, Canceled}. The caller (the runner)
// translates those into runstate transitions and persists them.

import { type FailureRecord, classify } from '@tideway/failure';

export interface JobContext {
  // Cancellation signal. Aborted when the operator cancels, when the
  // deadline trips, or when a parent fails (downstream cascade).
  signal: AbortSignal;
  // Information about the current run. Handlers commonly use these for
  // logging.
  runId: string;
  attempt: number;
  // Heartbeat: handlers that do long pieces of work without I/O should
  // call this every ~10 seconds. The runner translates each call to a
  // lease extension.
  heartbeat(): void;
  // Optional output capture. Handlers can ignore.
  log(level: 'info' | 'warn' | 'error', message: string): void;
}

export type Handler<I, O> = (ctx: JobContext, input: I) => Promise<O> | O;

export type WorkResult<O> =
  | { kind: 'ok'; result: O; durationMs: number }
  | { kind: 'fail'; failure: FailureRecord; durationMs: number }
  | { kind: 'canceled'; reason: string; durationMs: number };

export interface RunOptions {
  runId: string;
  attempt: number;
  // The runner pre-creates an AbortController and gives us its signal.
  // We attach our own listener for the heartbeat-to-lease bridge.
  signal: AbortSignal;
  // Called every time the handler heartbeats. Typically the runner
  // wires this through to LeaseRegistry.heartbeat.
  onHeartbeat?: () => void;
  // Output sink. Defaults to a no-op; the runner usually sets this to a
  // ring-buffer-backed function.
  onLog?: (level: 'info' | 'warn' | 'error', message: string) => void;
  // Time source for duration measurement. Defaults to performance.now or
  // Date.now. Tests pass a fake.
  clock?: () => number;
}

export async function run<I, O>(
  handler: Handler<I, O>,
  input: I,
  opts: RunOptions,
): Promise<WorkResult<O>> {
  const clock = opts.clock ?? (typeof performance !== 'undefined' ? () => performance.now() : Date.now);
  const start = clock();

  // Pre-flight: if the signal is already aborted, don't even invoke the
  // handler. This happens when the runner picks up a job that was
  // canceled while in the queue.
  if (opts.signal.aborted) {
    return {
      kind: 'canceled',
      reason: reasonFor(opts.signal),
      durationMs: 0,
    };
  }

  const ctx: JobContext = {
    signal: opts.signal,
    runId: opts.runId,
    attempt: opts.attempt,
    heartbeat() {
      opts.onHeartbeat?.();
    },
    log(level, message) {
      opts.onLog?.(level, message);
    },
  };

  try {
    const result = await handler(ctx, input);
    if (opts.signal.aborted) {
      // Handler returned but was supposed to have stopped. Honor the
      // cancellation rather than the success.
      return {
        kind: 'canceled',
        reason: reasonFor(opts.signal),
        durationMs: clock() - start,
      };
    }
    return { kind: 'ok', result, durationMs: clock() - start };
  } catch (err) {
    if (opts.signal.aborted) {
      return {
        kind: 'canceled',
        reason: reasonFor(opts.signal),
        durationMs: clock() - start,
      };
    }
    return { kind: 'fail', failure: classify(err), durationMs: clock() - start };
  }
}

function reasonFor(signal: AbortSignal): string {
  // signal.reason is supported but not always set; fall back to a generic
  // string. We also stringify for log-friendliness.
  const r = (signal as AbortSignal & { reason?: unknown }).reason;
  if (typeof r === 'string') return r;
  if (r && typeof r === 'object' && 'message' in r && typeof (r as { message: unknown }).message === 'string') {
    return (r as { message: string }).message;
  }
  return 'aborted';
}

// Convenience: a helper that pairs a handler with a deadline. If the
// deadline trips before the handler resolves, the abort signal fires and
// the result comes back as 'canceled' with reason='deadline'. Used by the
// runner; user code generally doesn't call this directly.
export function withDeadline<I, O>(
  handler: Handler<I, O>,
  input: I,
  opts: RunOptions & { deadlineMs: number },
): Promise<WorkResult<O>> {
  const composite = new AbortController();
  if (opts.signal.aborted) composite.abort(opts.signal.reason ?? 'aborted');
  opts.signal.addEventListener('abort', () => composite.abort(opts.signal.reason ?? 'aborted'), {
    once: true,
  });
  const timer = setTimeout(() => composite.abort('deadline'), opts.deadlineMs);

  return run(handler, input, { ...opts, signal: composite.signal }).finally(() => clearTimeout(timer));
}
