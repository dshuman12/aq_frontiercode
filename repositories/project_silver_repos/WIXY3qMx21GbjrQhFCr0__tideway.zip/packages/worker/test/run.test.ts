import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { JobFailure, Retryable } from '@tideway/failure';
import { run, withDeadline, type Handler, type RunOptions } from '../src/index.ts';

const baseOpts = (overrides: Partial<RunOptions> = {}): RunOptions => ({
  runId: 'run-1',
  attempt: 1,
  signal: new AbortController().signal,
  ...overrides,
});

describe('run: success path', () => {
  it('returns kind=ok with the handler result', async () => {
    const handler: Handler<number, number> = (_ctx, x) => x * 2;
    const r = await run(handler, 21, baseOpts());
    assert.equal(r.kind, 'ok');
    if (r.kind === 'ok') assert.equal(r.result, 42);
  });

  it('records duration', async () => {
    let t = 0;
    const clock = () => t;
    const handler: Handler<void, string> = async () => {
      t += 250;
      return 'ok';
    };
    const r = await run(handler, undefined, baseOpts({ clock }));
    assert.equal(r.kind, 'ok');
    if (r.kind === 'ok') assert.equal(r.durationMs, 250);
  });

  it('passes runId and attempt through', async () => {
    let captured: { runId: string; attempt: number } | undefined;
    const handler: Handler<void, void> = (ctx) => {
      captured = { runId: ctx.runId, attempt: ctx.attempt };
    };
    await run(handler, undefined, baseOpts({ runId: 'specific-run', attempt: 4 }));
    assert.deepEqual(captured, { runId: 'specific-run', attempt: 4 });
  });

  it('synchronous handler works too', async () => {
    const handler: Handler<number, number> = (_, x) => x + 1;
    const r = await run(handler, 5, baseOpts());
    assert.equal(r.kind, 'ok');
    if (r.kind === 'ok') assert.equal(r.result, 6);
  });
});

describe('run: failure path', () => {
  it('classifies a JobFailure as permanent', async () => {
    const handler: Handler<void, void> = () => {
      throw new JobFailure('hard fail');
    };
    const r = await run(handler, undefined, baseOpts());
    assert.equal(r.kind, 'fail');
    if (r.kind === 'fail') {
      assert.equal(r.failure.kind, 'permanent');
      assert.equal(r.failure.message, 'hard fail');
    }
  });

  it('classifies a Retryable as retryable', async () => {
    const handler: Handler<void, void> = () => {
      throw new Retryable('transient');
    };
    const r = await run(handler, undefined, baseOpts());
    assert.equal(r.kind, 'fail');
    if (r.kind === 'fail') assert.equal(r.failure.kind, 'retryable');
  });

  it('classifies a foreign Error as retryable', async () => {
    const handler: Handler<void, void> = () => {
      throw new Error('boom');
    };
    const r = await run(handler, undefined, baseOpts());
    assert.equal(r.kind, 'fail');
    if (r.kind === 'fail') assert.equal(r.failure.kind, 'retryable');
  });

  it('returns canceled if the signal aborts mid-throw', async () => {
    const ctrl = new AbortController();
    const handler: Handler<void, void> = () => {
      ctrl.abort('external');
      throw new Error('but we already canceled');
    };
    const r = await run(handler, undefined, baseOpts({ signal: ctrl.signal }));
    assert.equal(r.kind, 'canceled');
  });
});

describe('run: cancellation', () => {
  it('does not invoke the handler if signal is already aborted', async () => {
    const ctrl = new AbortController();
    ctrl.abort('pre-canceled');
    let invoked = false;
    const handler: Handler<void, void> = () => {
      invoked = true;
    };
    const r = await run(handler, undefined, baseOpts({ signal: ctrl.signal }));
    assert.equal(invoked, false);
    assert.equal(r.kind, 'canceled');
  });

  it('honors abort that happens during the handler', async () => {
    const ctrl = new AbortController();
    const handler: Handler<void, string> = async (ctx) => {
      // Wait until signal aborts.
      await new Promise<void>((resolve) => {
        ctx.signal.addEventListener('abort', () => resolve(), { once: true });
        setTimeout(() => ctrl.abort('test-trigger'), 5);
      });
      return 'finished anyway';
    };
    const r = await run(handler, undefined, baseOpts({ signal: ctrl.signal }));
    assert.equal(r.kind, 'canceled');
  });

  it('reports the signal reason', async () => {
    const ctrl = new AbortController();
    ctrl.abort('deadline');
    const handler: Handler<void, void> = () => undefined;
    const r = await run(handler, undefined, baseOpts({ signal: ctrl.signal }));
    if (r.kind === 'canceled') assert.equal(r.reason, 'deadline');
  });
});

describe('run: heartbeat and log', () => {
  it('forwards heartbeat to onHeartbeat', async () => {
    let beats = 0;
    const handler: Handler<void, void> = (ctx) => {
      ctx.heartbeat();
      ctx.heartbeat();
      ctx.heartbeat();
    };
    await run(handler, undefined, baseOpts({ onHeartbeat: () => (beats += 1) }));
    assert.equal(beats, 3);
  });

  it('forwards log to onLog with level + message', async () => {
    const captured: Array<{ level: string; message: string }> = [];
    const handler: Handler<void, void> = (ctx) => {
      ctx.log('info', 'starting');
      ctx.log('error', 'whoops');
    };
    await run(handler, undefined, baseOpts({ onLog: (level, message) => captured.push({ level, message }) }));
    assert.deepEqual(captured, [
      { level: 'info', message: 'starting' },
      { level: 'error', message: 'whoops' },
    ]);
  });

  it('handler ignoring heartbeat is fine', async () => {
    const handler: Handler<void, number> = () => 42;
    const r = await run(handler, undefined, baseOpts());
    assert.equal(r.kind, 'ok');
  });
});

describe('withDeadline', () => {
  it('completes if the handler finishes within the deadline', async () => {
    const handler: Handler<void, string> = async () => {
      await new Promise((r) => setTimeout(r, 5));
      return 'done';
    };
    const r = await withDeadline(handler, undefined, { ...baseOpts(), deadlineMs: 100 });
    assert.equal(r.kind, 'ok');
  });

  it('cancels with reason=deadline if the handler exceeds the deadline', async () => {
    const handler: Handler<void, string> = async (ctx) => {
      await new Promise<void>((resolve) => {
        ctx.signal.addEventListener('abort', () => resolve(), { once: true });
      });
      return 'never';
    };
    const r = await withDeadline(handler, undefined, { ...baseOpts(), deadlineMs: 10 });
    assert.equal(r.kind, 'canceled');
    if (r.kind === 'canceled') assert.equal(r.reason, 'deadline');
  });
});
