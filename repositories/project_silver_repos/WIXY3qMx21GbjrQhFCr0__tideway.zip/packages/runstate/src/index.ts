// Run lifecycle state machine.
//
// A "run" is one execution of one job within a workflow. It moves through
// a small set of named states; each state has a fixed set of legal events
// it can receive. The FSM here is deliberately explicit (an exhaustive
// switch over (state.kind, event.kind) pairs) rather than a table of
// transitions stored in data, because:
//
//   - The legal-transition graph is small (we have 7 states and 9 events,
//     and most pairs are illegal).
//   - Type narrowing inside a switch lets the compiler check that every
//     case touches the correct fields. A data-driven table would lose
//     that.
//   - When something goes wrong in production, "transition X from Y is
//     not legal" is a much clearer error than a generic "transition
//     denied by table at index N".
//
// See docs/rfcs/0002-state-machine.md for context. The decision to model
// retry_scheduled as its own state (rather than overloading "queued" with
// an attempt counter) came out of an incident where we couldn't tell from
// a snapshot whether a queued run was a brand-new submission or a retry,
// and operators kept canceling retries thinking they were original
// submissions.

import type { FailureKind } from '@tideway/failure';

export type RunId = string;

export type RunState =
  | { kind: 'queued'; enqueuedAt: bigint }
  | {
      kind: 'running';
      startedAt: bigint;
      workerId: string;
      leaseExpiresAt: bigint;
      attempt: number;
    }
  | { kind: 'succeeded'; finishedAt: bigint; result: unknown; attempt: number }
  | {
      kind: 'failed';
      finishedAt: bigint;
      failureKind: FailureKind;
      message: string;
      attempt: number;
    }
  | { kind: 'retry_scheduled'; nextAttemptAt: bigint; attempt: number; lastFailureKind: FailureKind }
  | {
      kind: 'canceled';
      finishedAt: bigint;
      reason: 'deadline' | 'external' | 'parent_failure';
    }
  | { kind: 'timed_out'; finishedAt: bigint; deadlineWas: bigint; attempt: number };

export type RunStateKind = RunState['kind'];

export type Event =
  | { kind: 'dispatch'; at: bigint; workerId: string; leaseExpiresAt: bigint }
  | { kind: 'heartbeat'; at: bigint; leaseExpiresAt: bigint }
  | { kind: 'succeed'; at: bigint; result: unknown }
  | { kind: 'fail'; at: bigint; failureKind: FailureKind; message: string }
  | { kind: 'schedule_retry'; at: bigint; nextAttemptAt: bigint }
  | { kind: 'requeue'; at: bigint } // retry_scheduled -> queued, when next-attempt time arrives
  | { kind: 'cancel'; at: bigint; reason: 'deadline' | 'external' | 'parent_failure' }
  | { kind: 'time_out'; at: bigint; deadlineWas: bigint }
  | { kind: 'lease_expire'; at: bigint }; // running -> queued, lease expired

// Custom error used to signal an illegal transition. The message format is
// stable; downstream code in scheduler/ greps for "illegal transition" in
// log scrapers, so don't change the prefix without updating that too.
export class IllegalTransition extends Error {
  override readonly name = 'IllegalTransition';
  constructor(state: RunStateKind, eventKind: Event['kind']) {
    super(`illegal transition: ${eventKind} not legal from ${state}`);
  }
}

export interface TransitionOptions {
  // The attempt number to use when transitioning into running. If not
  // provided, the caller is on `queued`-fresh (attempt = 1) and we infer.
  attempt?: number;
}

export function initialState(at: bigint): RunState {
  return { kind: 'queued', enqueuedAt: at };
}

export function transition(state: RunState, event: Event, opts: TransitionOptions = {}): RunState {
  switch (state.kind) {
    case 'queued':
      return fromQueued(state, event, opts);
    case 'running':
      return fromRunning(state, event);
    case 'retry_scheduled':
      return fromRetryScheduled(state, event);
    // Terminal states: succeeded, failed, canceled, timed_out.
    case 'succeeded':
    case 'failed':
    case 'canceled':
    case 'timed_out':
      // Terminal states are absorbing. The only legal "event" is none --
      // we fall through to throw. (Cancel-on-already-failed is a common
      // operator action that we explicitly ignore at a layer above; it
      // shouldn't reach here.)
      throw new IllegalTransition(state.kind, event.kind);
  }
}

function fromQueued(state: RunState & { kind: 'queued' }, event: Event, opts: TransitionOptions): RunState {
  switch (event.kind) {
    case 'dispatch':
      return {
        kind: 'running',
        startedAt: event.at,
        workerId: event.workerId,
        leaseExpiresAt: event.leaseExpiresAt,
        attempt: opts.attempt ?? 1,
      };
    case 'cancel':
      return { kind: 'canceled', finishedAt: event.at, reason: event.reason };
    case 'time_out':
      return { kind: 'timed_out', finishedAt: event.at, deadlineWas: event.deadlineWas, attempt: 0 };
    default:
      throw new IllegalTransition(state.kind, event.kind);
  }
}

function fromRunning(state: RunState & { kind: 'running' }, event: Event): RunState {
  switch (event.kind) {
    case 'heartbeat':
      return { ...state, leaseExpiresAt: event.leaseExpiresAt };
    case 'succeed':
      return {
        kind: 'succeeded',
        finishedAt: event.at,
        result: event.result,
        attempt: state.attempt,
      };
    case 'fail':
      return {
        kind: 'failed',
        finishedAt: event.at,
        failureKind: event.failureKind,
        message: event.message,
        attempt: state.attempt,
      };
    case 'schedule_retry':
      // The transition to retry_scheduled needs prior failure context. We
      // accept it here for the case where a retry decision is made
      // synchronously from running (without a separate failed state). The
      // failure kind defaults to 'retryable' because if the scheduler is
      // calling this path, that's the only sensible classification.
      return {
        kind: 'retry_scheduled',
        nextAttemptAt: event.nextAttemptAt,
        attempt: state.attempt,
        lastFailureKind: 'retryable',
      };
    case 'cancel':
      return { kind: 'canceled', finishedAt: event.at, reason: event.reason };
    case 'time_out':
      return {
        kind: 'timed_out',
        finishedAt: event.at,
        deadlineWas: event.deadlineWas,
        attempt: state.attempt,
      };
    case 'lease_expire':
      // Lease expired without a graceful succeed/fail. Send back to
      // queued so another worker can pick up. Attempt count carries over.
      return { kind: 'queued', enqueuedAt: event.at };
    default:
      throw new IllegalTransition(state.kind, event.kind);
  }
}

function fromRetryScheduled(
  state: RunState & { kind: 'retry_scheduled' },
  event: Event,
): RunState {
  switch (event.kind) {
    case 'requeue':
      return { kind: 'queued', enqueuedAt: event.at };
    case 'cancel':
      return { kind: 'canceled', finishedAt: event.at, reason: event.reason };
    case 'dispatch':
      // Skip the requeue intermediate state. Attempt number bumps.
      return {
        kind: 'running',
        startedAt: event.at,
        workerId: event.workerId,
        leaseExpiresAt: event.leaseExpiresAt,
        attempt: state.attempt + 1,
      };
    default:
      throw new IllegalTransition(state.kind, event.kind);
  }
}

export function isTerminal(state: RunState): boolean {
  return (
    state.kind === 'succeeded' ||
    state.kind === 'failed' ||
    state.kind === 'canceled' ||
    state.kind === 'timed_out'
  );
}

export function isActive(state: RunState): boolean {
  return state.kind === 'running' || state.kind === 'queued' || state.kind === 'retry_scheduled';
}

// For debugging dumps. Stable JSON shape -- bigints emitted as decimal strings
// with a "n" suffix so a round-trip parser can recover the bigint.
export function snapshot(state: RunState): Record<string, unknown> {
  const out: Record<string, unknown> = { kind: state.kind };
  for (const [key, value] of Object.entries(state)) {
    if (key === 'kind') continue;
    out[key] = typeof value === 'bigint' ? `${value}n` : value;
  }
  return out;
}
