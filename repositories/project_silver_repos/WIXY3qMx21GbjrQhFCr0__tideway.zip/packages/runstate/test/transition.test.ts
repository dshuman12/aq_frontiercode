import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import {
  IllegalTransition,
  initialState,
  isActive,
  isTerminal,
  snapshot,
  transition,
  type Event,
  type RunState,
} from '../src/index.ts';

const t = (n: number): bigint => BigInt(n);

const dispatch = (at: number, lease: number, workerId = 'w1'): Event => ({
  kind: 'dispatch',
  at: t(at),
  workerId,
  leaseExpiresAt: t(lease),
});

describe('initialState', () => {
  it('starts queued with the given enqueue time', () => {
    const s = initialState(t(100));
    assert.equal(s.kind, 'queued');
    if (s.kind === 'queued') {
      assert.equal(s.enqueuedAt, t(100));
    }
  });
});

describe('queued -> *', () => {
  it('queued + dispatch -> running with attempt=1 by default', () => {
    const s = transition(initialState(t(0)), dispatch(10, 1010));
    assert.equal(s.kind, 'running');
    if (s.kind === 'running') {
      assert.equal(s.workerId, 'w1');
      assert.equal(s.leaseExpiresAt, t(1010));
      assert.equal(s.attempt, 1);
    }
  });

  it('queued + dispatch with attempt option carries that value', () => {
    const s = transition(initialState(t(0)), dispatch(10, 1010, 'w2'), { attempt: 3 });
    assert.equal(s.kind, 'running');
    if (s.kind === 'running') assert.equal(s.attempt, 3);
  });

  it('queued + cancel -> canceled with reason', () => {
    const s = transition(initialState(t(0)), { kind: 'cancel', at: t(5), reason: 'external' });
    assert.equal(s.kind, 'canceled');
    if (s.kind === 'canceled') assert.equal(s.reason, 'external');
  });

  it('queued + time_out -> timed_out', () => {
    const s = transition(initialState(t(0)), { kind: 'time_out', at: t(5), deadlineWas: t(4) });
    assert.equal(s.kind, 'timed_out');
  });

  it('throws on queued + heartbeat', () => {
    assert.throws(
      () =>
        transition(initialState(t(0)), {
          kind: 'heartbeat',
          at: t(5),
          leaseExpiresAt: t(100),
        }),
      IllegalTransition,
    );
  });

  it('throws on queued + succeed', () => {
    assert.throws(() =>
      transition(initialState(t(0)), { kind: 'succeed', at: t(5), result: null }),
    );
  });

  it('throws on queued + lease_expire', () => {
    assert.throws(() => transition(initialState(t(0)), { kind: 'lease_expire', at: t(5) }));
  });

  it('throws on queued + requeue', () => {
    assert.throws(() => transition(initialState(t(0)), { kind: 'requeue', at: t(5) }));
  });
});

describe('running -> *', () => {
  const running = (): RunState => transition(initialState(t(0)), dispatch(10, 1010));

  it('running + heartbeat extends lease, keeps everything else', () => {
    const r = running();
    const s = transition(r, { kind: 'heartbeat', at: t(20), leaseExpiresAt: t(2020) });
    assert.equal(s.kind, 'running');
    if (s.kind === 'running' && r.kind === 'running') {
      assert.equal(s.leaseExpiresAt, t(2020));
      assert.equal(s.workerId, r.workerId);
      assert.equal(s.startedAt, r.startedAt);
      assert.equal(s.attempt, r.attempt);
    }
  });

  it('running + succeed -> succeeded with result and attempt', () => {
    const s = transition(running(), { kind: 'succeed', at: t(50), result: { ok: 1 } });
    assert.equal(s.kind, 'succeeded');
    if (s.kind === 'succeeded') {
      assert.deepEqual(s.result, { ok: 1 });
      assert.equal(s.attempt, 1);
    }
  });

  it('running + fail -> failed with kind and attempt', () => {
    const s = transition(running(), {
      kind: 'fail',
      at: t(50),
      failureKind: 'permanent',
      message: 'bad',
    });
    assert.equal(s.kind, 'failed');
    if (s.kind === 'failed') {
      assert.equal(s.failureKind, 'permanent');
      assert.equal(s.message, 'bad');
      assert.equal(s.attempt, 1);
    }
  });

  it('running + schedule_retry -> retry_scheduled with attempt and nextAttemptAt', () => {
    const s = transition(running(), {
      kind: 'schedule_retry',
      at: t(50),
      nextAttemptAt: t(60_000),
    });
    assert.equal(s.kind, 'retry_scheduled');
    if (s.kind === 'retry_scheduled') {
      assert.equal(s.attempt, 1);
      assert.equal(s.nextAttemptAt, t(60_000));
      assert.equal(s.lastFailureKind, 'retryable');
    }
  });

  it('running + cancel -> canceled', () => {
    const s = transition(running(), {
      kind: 'cancel',
      at: t(50),
      reason: 'parent_failure',
    });
    assert.equal(s.kind, 'canceled');
  });

  it('running + time_out -> timed_out preserving attempt', () => {
    const s = transition(running(), { kind: 'time_out', at: t(50), deadlineWas: t(40) });
    assert.equal(s.kind, 'timed_out');
    if (s.kind === 'timed_out') {
      assert.equal(s.deadlineWas, t(40));
      assert.equal(s.attempt, 1);
    }
  });

  it('running + lease_expire -> queued', () => {
    const s = transition(running(), { kind: 'lease_expire', at: t(50) });
    assert.equal(s.kind, 'queued');
    if (s.kind === 'queued') assert.equal(s.enqueuedAt, t(50));
  });

  it('throws on running + requeue', () => {
    assert.throws(() => transition(running(), { kind: 'requeue', at: t(50) }));
  });

  it('throws on running + dispatch', () => {
    assert.throws(() => transition(running(), dispatch(50, 1500, 'w2')));
  });
});

describe('retry_scheduled -> *', () => {
  const retryScheduled = (): RunState => {
    const r = transition(initialState(t(0)), dispatch(10, 1010));
    return transition(r, { kind: 'schedule_retry', at: t(50), nextAttemptAt: t(70) });
  };

  it('retry_scheduled + requeue -> queued', () => {
    const s = transition(retryScheduled(), { kind: 'requeue', at: t(70) });
    assert.equal(s.kind, 'queued');
    if (s.kind === 'queued') assert.equal(s.enqueuedAt, t(70));
  });

  it('retry_scheduled + dispatch -> running with attempt+1', () => {
    const s = transition(retryScheduled(), dispatch(80, 1080, 'w2'));
    assert.equal(s.kind, 'running');
    if (s.kind === 'running') {
      assert.equal(s.attempt, 2);
      assert.equal(s.workerId, 'w2');
    }
  });

  it('retry_scheduled + cancel -> canceled', () => {
    const s = transition(retryScheduled(), { kind: 'cancel', at: t(80), reason: 'external' });
    assert.equal(s.kind, 'canceled');
  });

  it('throws on retry_scheduled + heartbeat', () => {
    assert.throws(() =>
      transition(retryScheduled(), { kind: 'heartbeat', at: t(80), leaseExpiresAt: t(2080) }),
    );
  });

  it('throws on retry_scheduled + succeed', () => {
    assert.throws(() =>
      transition(retryScheduled(), { kind: 'succeed', at: t(80), result: null }),
    );
  });
});

describe('terminal states', () => {
  const succeeded = (): RunState =>
    transition(transition(initialState(t(0)), dispatch(10, 1010)), {
      kind: 'succeed',
      at: t(50),
      result: 1,
    });
  const failed = (): RunState =>
    transition(transition(initialState(t(0)), dispatch(10, 1010)), {
      kind: 'fail',
      at: t(50),
      failureKind: 'permanent',
      message: 'x',
    });

  it('throws on any event from succeeded', () => {
    assert.throws(() => transition(succeeded(), { kind: 'cancel', at: t(60), reason: 'external' }));
  });

  it('throws on any event from failed', () => {
    assert.throws(() =>
      transition(failed(), { kind: 'heartbeat', at: t(60), leaseExpiresAt: t(2060) }),
    );
  });

  it('isTerminal recognizes terminal states', () => {
    assert.equal(isTerminal(succeeded()), true);
    assert.equal(isTerminal(failed()), true);
    assert.equal(isTerminal(initialState(t(0))), false);
  });

  it('isActive recognizes active states', () => {
    assert.equal(isActive(initialState(t(0))), true);
    assert.equal(isActive(transition(initialState(t(0)), dispatch(10, 1010))), true);
    assert.equal(isActive(succeeded()), false);
  });
});

describe('IllegalTransition error', () => {
  it('has a stable message format', () => {
    try {
      transition(initialState(t(0)), { kind: 'heartbeat', at: t(5), leaseExpiresAt: t(100) });
      assert.fail('expected throw');
    } catch (err) {
      assert.ok(err instanceof IllegalTransition);
      assert.match(err.message, /illegal transition: heartbeat not legal from queued/);
    }
  });
});

describe('snapshot', () => {
  it('emits bigints as "Nn" strings', () => {
    const s = transition(initialState(t(123)), dispatch(456, 789));
    const snap = snapshot(s);
    assert.equal(snap.kind, 'running');
    assert.equal(snap.startedAt, '456n');
    assert.equal(snap.leaseExpiresAt, '789n');
    assert.equal(snap.attempt, 1);
  });

  it('preserves non-bigint fields verbatim', () => {
    const s = transition(transition(initialState(t(0)), dispatch(10, 1010)), {
      kind: 'succeed',
      at: t(50),
      result: { count: 7, label: 'done' },
    });
    const snap = snapshot(s);
    assert.deepEqual(snap.result, { count: 7, label: 'done' });
  });
});
