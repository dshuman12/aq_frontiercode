// Audit log. Append-only, in-memory, with optional sink for durable
// persistence (typically a JSONL file or the runner's outbox).

import type { AuditEvent } from './events.ts';

export interface AuditSink {
  (event: AuditEvent): void | Promise<void>;
}

export class AuditLog {
  private readonly events: AuditEvent[] = [];
  private nextSeq = 1;
  private readonly sinks: AuditSink[] = [];
  private readonly clock: () => number;

  constructor(opts?: { clock?: () => number }) {
    this.clock = opts?.clock ?? Date.now;
  }

  append(event: Omit<AuditEvent, 'seq' | 'at'> & { actorId?: string }): AuditEvent {
    const seq = this.nextSeq;
    this.nextSeq += 1;
    const stamped = {
      ...event,
      seq,
      at: this.clock(),
      actorId: event.actorId ?? '',
    } as AuditEvent;
    this.events.push(stamped);
    for (const sink of this.sinks) {
      try {
        const r = sink(stamped);
        // We don't await sink promises; the audit log is fire-and-forget
        // from the caller's perspective. The runner attaches a sink that
        // queues into the outbox if durable persistence is required.
        if (r && typeof (r as Promise<void>).catch === 'function') {
          (r as Promise<void>).catch(() => undefined);
        }
      } catch {
        // ignore sink failures; audit must never bring down the runner
      }
    }
    return stamped;
  }

  attachSink(sink: AuditSink): () => void {
    this.sinks.push(sink);
    return () => {
      const i = this.sinks.indexOf(sink);
      if (i >= 0) this.sinks.splice(i, 1);
    };
  }

  // Read events. Optional filtering by kind, actor, time window.
  read(filter: AuditFilter = {}): AuditEvent[] {
    const out: AuditEvent[] = [];
    const limit = filter.limit ?? Infinity;
    for (const event of this.events) {
      if (filter.kind && event.kind !== filter.kind) continue;
      if (filter.actorId && event.actorId !== filter.actorId) continue;
      if (filter.since !== undefined && event.at < filter.since) continue;
      if (filter.until !== undefined && event.at > filter.until) continue;
      out.push(event);
      if (out.length >= limit) break;
    }
    return out;
  }

  // Total event count (across all kinds).
  size(): number {
    return this.events.length;
  }

  // High-water seq number. Useful for the runner to know where the log
  // is up to.
  highSeq(): number {
    return this.nextSeq - 1;
  }

  // Drop events older than `before`. Returns the number dropped. The
  // sequence numbers stay monotonic (we never reuse old seqs).
  prune(before: number): number {
    let dropped = 0;
    while (this.events.length > 0 && this.events[0]!.at < before) {
      this.events.shift();
      dropped += 1;
    }
    return dropped;
  }
}

export interface AuditFilter {
  kind?: AuditEvent['kind'];
  actorId?: string;
  since?: number;
  until?: number;
  limit?: number;
}
