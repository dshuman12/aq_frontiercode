// Audit event types.
//
// Distinct from the runstate FSM events: those track per-run lifecycle.
// Audit events track operator-significant actions (submit, cancel, drain,
// dlq replay) plus security-relevant access (who connected over the
// wire, with what client identity).
//
// We deliberately keep this taxonomy small. Audit logs that try to
// capture everything end up logging nothing usefully; logs that
// capture five things capture the things you'd want during an
// incident.

export type AuditEvent =
  | SubmitEvent
  | CancelEvent
  | DrainEvent
  | DlqReplayEvent
  | DlqDropEvent
  | ConnectionEvent;

export interface BaseEvent {
  // Sequence number assigned by the audit log on append. Monotonic.
  seq: number;
  // ms since epoch.
  at: number;
  // Optional client identity. Populated for wire-originated events;
  // empty string for in-process events.
  actorId: string;
}

export interface SubmitEvent extends BaseEvent {
  kind: 'submit';
  runId: string;
  handler: string;
  // Whether the submission deduplicated against an idempotency entry.
  dedup: boolean;
}

export interface CancelEvent extends BaseEvent {
  kind: 'cancel';
  runId: string;
  reason: string;
}

export interface DrainEvent extends BaseEvent {
  kind: 'drain';
  graceful: boolean;
  inflightAtTime: number;
}

export interface DlqReplayEvent extends BaseEvent {
  kind: 'dlq-replay';
  // The number of dlq entries replayed.
  count: number;
  // The filter the operator used.
  filter: { handler?: string; failureKind?: string; tag?: string };
}

export interface DlqDropEvent extends BaseEvent {
  kind: 'dlq-drop';
  runId: string;
}

export interface ConnectionEvent extends BaseEvent {
  kind: 'connection';
  // 'accepted' or 'rejected'. Rejected typically means handshake-version
  // mismatch.
  outcome: 'accepted' | 'rejected';
  protocolVersion: number;
}

// Type guards.
export function isSubmit(e: AuditEvent): e is SubmitEvent {
  return e.kind === 'submit';
}
export function isCancel(e: AuditEvent): e is CancelEvent {
  return e.kind === 'cancel';
}
export function isDrain(e: AuditEvent): e is DrainEvent {
  return e.kind === 'drain';
}
export function isDlqReplay(e: AuditEvent): e is DlqReplayEvent {
  return e.kind === 'dlq-replay';
}
export function isDlqDrop(e: AuditEvent): e is DlqDropEvent {
  return e.kind === 'dlq-drop';
}
export function isConnection(e: AuditEvent): e is ConnectionEvent {
  return e.kind === 'connection';
}
