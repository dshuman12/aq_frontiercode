import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { AuditLog } from '../src/log.ts';
import { isSubmit, isCancel } from '../src/events.ts';

class FakeClock {
  constructor(public t = 1000) {}
  now = () => this.t;
  advance(ms: number) {
    this.t += ms;
  }
}

describe('AuditLog: append', () => {
  it('assigns monotonic seq numbers', () => {
    const log = new AuditLog();
    const a = log.append({ kind: 'submit', runId: 'r-1', handler: 'h', dedup: false });
    const b = log.append({ kind: 'submit', runId: 'r-2', handler: 'h', dedup: false });
    assert.equal(a.seq, 1);
    assert.equal(b.seq, 2);
  });

  it('stamps wall-clock time', () => {
    const c = new FakeClock(5000);
    const log = new AuditLog({ clock: c.now });
    const e = log.append({ kind: 'drain', graceful: true, inflightAtTime: 3 });
    assert.equal(e.at, 5000);
  });

  it('defaults actorId to empty string', () => {
    const log = new AuditLog();
    const e = log.append({ kind: 'submit', runId: 'r-1', handler: 'h', dedup: false });
    assert.equal(e.actorId, '');
  });

  it('honors caller-supplied actorId', () => {
    const log = new AuditLog();
    const e = log.append({
      kind: 'submit',
      runId: 'r-1',
      handler: 'h',
      dedup: false,
      actorId: 'alice',
    });
    assert.equal(e.actorId, 'alice');
  });
});

describe('AuditLog: type guards', () => {
  it('isSubmit narrows correctly', () => {
    const log = new AuditLog();
    const e = log.append({ kind: 'submit', runId: 'r-1', handler: 'h', dedup: false });
    assert.equal(isSubmit(e), true);
    assert.equal(isCancel(e), false);
  });
});

describe('AuditLog: sinks', () => {
  it('attached sinks fire on every append', () => {
    const log = new AuditLog();
    const captured: number[] = [];
    log.attachSink((e) => captured.push(e.seq));
    log.append({ kind: 'submit', runId: 'r-1', handler: 'h', dedup: false });
    log.append({ kind: 'cancel', runId: 'r-1', reason: 'op-cancel' });
    assert.deepEqual(captured, [1, 2]);
  });

  it('returned unsubscribe stops further events', () => {
    const log = new AuditLog();
    const captured: number[] = [];
    const off = log.attachSink((e) => captured.push(e.seq));
    log.append({ kind: 'submit', runId: 'r-1', handler: 'h', dedup: false });
    off();
    log.append({ kind: 'submit', runId: 'r-2', handler: 'h', dedup: false });
    assert.deepEqual(captured, [1]);
  });

  it('sink that throws does not break append', () => {
    const log = new AuditLog();
    log.attachSink(() => {
      throw new Error('boom');
    });
    const e = log.append({ kind: 'drain', graceful: true, inflightAtTime: 0 });
    assert.equal(e.seq, 1);
  });

  it('async sink that rejects does not break append', () => {
    const log = new AuditLog();
    log.attachSink(async () => {
      throw new Error('boom');
    });
    const e = log.append({ kind: 'drain', graceful: true, inflightAtTime: 0 });
    assert.equal(e.seq, 1);
  });
});

describe('AuditLog: read', () => {
  function seed(log: AuditLog) {
    log.append({ kind: 'submit', runId: 'r-1', handler: 'a', dedup: false, actorId: 'alice' });
    log.append({ kind: 'submit', runId: 'r-2', handler: 'b', dedup: false, actorId: 'bob' });
    log.append({ kind: 'cancel', runId: 'r-1', reason: 'op-cancel', actorId: 'alice' });
    log.append({ kind: 'drain', graceful: true, inflightAtTime: 2, actorId: 'alice' });
  }

  it('without filter returns all events', () => {
    const log = new AuditLog();
    seed(log);
    assert.equal(log.read().length, 4);
  });

  it('filter by kind', () => {
    const log = new AuditLog();
    seed(log);
    const submits = log.read({ kind: 'submit' });
    assert.equal(submits.length, 2);
  });

  it('filter by actorId', () => {
    const log = new AuditLog();
    seed(log);
    const aliceEvents = log.read({ actorId: 'alice' });
    assert.equal(aliceEvents.length, 3);
  });

  it('filter by time window', () => {
    const c = new FakeClock(0);
    const log = new AuditLog({ clock: c.now });
    log.append({ kind: 'drain', graceful: true, inflightAtTime: 0 });
    c.advance(1000);
    log.append({ kind: 'drain', graceful: true, inflightAtTime: 0 });
    c.advance(1000);
    log.append({ kind: 'drain', graceful: true, inflightAtTime: 0 });
    const window = log.read({ since: 500, until: 1500 });
    assert.equal(window.length, 1);
  });

  it('honors limit', () => {
    const log = new AuditLog();
    seed(log);
    assert.equal(log.read({ limit: 2 }).length, 2);
  });
});

describe('AuditLog: size / highSeq / prune', () => {
  it('size reports current count', () => {
    const log = new AuditLog();
    log.append({ kind: 'drain', graceful: true, inflightAtTime: 0 });
    log.append({ kind: 'drain', graceful: true, inflightAtTime: 0 });
    assert.equal(log.size(), 2);
  });

  it('highSeq monotonically tracks next-1', () => {
    const log = new AuditLog();
    assert.equal(log.highSeq(), 0);
    log.append({ kind: 'drain', graceful: true, inflightAtTime: 0 });
    assert.equal(log.highSeq(), 1);
  });

  it('prune drops events older than the cutoff', () => {
    const c = new FakeClock(0);
    const log = new AuditLog({ clock: c.now });
    log.append({ kind: 'drain', graceful: true, inflightAtTime: 0 });
    c.advance(2000);
    log.append({ kind: 'drain', graceful: true, inflightAtTime: 0 });
    const dropped = log.prune(1000);
    assert.equal(dropped, 1);
    assert.equal(log.size(), 1);
  });

  it('prune does not change highSeq (seqs never reused)', () => {
    const c = new FakeClock(0);
    const log = new AuditLog({ clock: c.now });
    log.append({ kind: 'drain', graceful: true, inflightAtTime: 0 });
    c.advance(2000);
    log.append({ kind: 'drain', graceful: true, inflightAtTime: 0 });
    log.prune(1000);
    assert.equal(log.highSeq(), 2);
  });
});
