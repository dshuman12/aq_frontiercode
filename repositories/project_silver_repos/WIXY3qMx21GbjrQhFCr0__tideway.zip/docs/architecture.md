# Architecture

A bird's-eye view of how the pieces fit together. For decisions and
their reasoning, see the RFCs in `docs/rfcs/`.

## Layout

```
                    submit / cancel / status (wire)
                                  |
                                  v
                          +-----------------+
                          |     runner      |
                          | (single Node    |
                          |  process)       |
                          +-----------------+
                          /        |        \
                     scheduler   workers    outbox flush
                          \        |        /
                           \       |       /
                            \      v      /
                          +---------------+
                          | SQLite store  |
                          +---------------+
```

## Package map

The runtime is split into 16 packages plus 2 apps and 2 tools. Each
package has a single responsibility and a small public surface.

| Package | Owns |
|---|---|
| failure | error taxonomy + classifier |
| runstate | run lifecycle FSM |
| dag | graph + topology + cycles + layers |
| scheduler | dispatch decision logic |
| worker | per-job execution context |
| inflight | currently-running tracker (heap by deadline) |
| replay | crash recovery from event log |
| idempotency | (handler, key) registry |
| backoff | retry policy functions |
| deadline | propagation through DAG |
| outbox | transactional side-effect queue |
| leasing | TTL-based worker leases |
| cron | 5-field expression parser + nextFire |
| dlq | dead-letter queue + replay tooling |
| tracing | OTel-shaped span emission |
| wire | length-prefixed JSON RPC |
| store | abstract Store + Memory + SQLite |
| (app) runner | the daemon that orchestrates all the above |
| (app) console | the CLI that talks to the daemon |
| (tool) loadgen | synthetic DAG submitter |
| (tool) migrate | schema migration runner |

## Data flow on submit

1. Caller calls submit (in-process API or wire request).
2. Runner builds a `RunCreated` event.
3. Idempotency registry: fresh / join / result.
4. If fresh: append `RunCreated` to event log, append idempotency
   inflight entry, all in one transaction.
5. Scheduler tick eventually picks the run; lease acquired, event
   appended, dispatch.
6. Worker runs handler. On success/failure, FSM transitions, event
   appended; outbox emits side-effects in same transaction.
7. Outbox flush loop drains side-effects to the configured sink.
8. Idempotency entry transitions to completed/failed.

## Data flow on crash recovery

1. Runner starts. Lifecycle = `starting`.
2. Open store (run migrations as needed).
3. Replay event log into in-memory state map. Track high-water LSN.
4. For runs in `running` state with expired lease: requeue.
5. Lifecycle = `running`. Begin scheduler/worker/outbox loops.

The replay is deterministic given the event log; that's the property
that makes the crash window safe.

## What's NOT here

- Cross-host distribution (RFC 0013).
- Quorum/any-of fan-in (RFC 0012, draft).
- Run-level resource quotas (CPU/memory caps per handler). Not yet
  needed; the runner inherits OS-level limits.
