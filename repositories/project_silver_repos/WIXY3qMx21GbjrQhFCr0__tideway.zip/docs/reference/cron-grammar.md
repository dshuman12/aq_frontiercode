# Cron grammar reference

This is the grammar accepted by `@tideway/cron`. RFC 0011 explains why
this set was chosen.

## Fields

```
minute  hour  day-of-month  month  day-of-week
0-59    0-23  1-31          1-12   0-6 (Sun=0)
```

Five whitespace-separated fields. No seconds, no year.

## Per-field syntax

Each field is one or more comma-separated pieces. Each piece is one of:

| Form | Meaning |
|---|---|
| `*` | every value in the field's range |
| `N` | the single value N |
| `N-M` | every value from N to M, inclusive |
| `*/S` | every Sth value, starting at the field's minimum |
| `N/S` | every Sth value, starting at N up to the maximum |
| `N-M/S` | every Sth value within the range N-M |

Lists, ranges, and steps may be combined with commas:
`0,30,15-45/5`. Trailing or leading whitespace is stripped before
parsing.

## What is NOT supported

- Named months (`JAN`, `FEB`, ...) and days (`MON`, `TUE`, ...).
- The `L` (last day) and `W` (nearest weekday) extensions.
- The `#` (Nth weekday of month) extension.
- 6-field (Quartz, with seconds).
- 7-field (Quartz, with year).

These are valid grievances. RFC 0011 has the rationale.

## Time zone

All cron times are interpreted in UTC. There is no per-expression
time zone. To get a wall-clock time in a specific zone, compute the
UTC equivalent yourself and pass that.

## Examples

```
* * * * *           every minute (UTC)
0 * * * *           top of every hour
0 9 * * 1-5         09:00 on weekdays
30 9-17 * * 1-5     30 minutes past every hour 9am-5pm on weekdays
0,30 * * * *        twice an hour, on the hour and the half
*/15 * * * *        every 15 minutes
0 0 1 * *           midnight on the 1st of every month
0 0 1 1 *           midnight on Jan 1
0 0 29 2 *          midnight on Feb 29 (leap years only)
```

## Edge cases

- `0 0 30 2 *` and `0 0 31 2 *` never fire. `nextFireAfter` returns
  null after exhausting the 5-year search window.
- `0 0 31 4 *` (April 31) never fires; same behavior.
- Leap-year handling for Feb 29 is correct: the next firing of
  `0 0 29 2 *` is the next leap year.
- DST: not a concern because we operate in UTC.
