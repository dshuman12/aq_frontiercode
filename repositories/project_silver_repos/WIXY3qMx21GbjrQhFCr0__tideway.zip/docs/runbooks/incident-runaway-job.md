# Incident runbook: runaway job

A "runaway" job is one that's consuming resources beyond its budget.
Symptoms: the runner's CPU is pinned, a worker slot has been held by
the same run id for far longer than its declared deadline, or the
heartbeat-to-lease bridge is firing more frequently than the heartbeat
interval should permit.

## Identify the run

```
tideway list --state running --limit 100
```

Look for a run whose `attempt > 1` AND whose `startedAt` is more than
its declared deadline ago. That's the candidate.

## Confirm it's actually misbehaving

A run can be slow without being runaway. Confirm with:

- `tideway status --run-id RID` shows the lease being heartbeated. If
  the heartbeat interval looks like it's still 10s, the worker is
  alive and just slow. Decide whether to wait or cancel.
- If heartbeats are missing or sporadic but the run is still
  "running", the worker may be deadlocked. Cancel and let the lease
  expire.

## Cancel cleanly

```
tideway cancel --run-id RID --reason "operator: runaway"
```

The runner sends an abort signal to the worker. Cooperative handlers
abort within ~100ms; uncooperative handlers won't notice and the
worker has to wait for the lease to expire (default 30s).

## If cancellation isn't enough

If the handler is uncooperative AND the runner itself is suffering
(e.g., its event loop is blocked because the handler is doing CPU-
bound work synchronously), the only real option is to restart the
runner. Take a backup first.

## Postmortem

Before closing the incident:

1. Confirm the dlq has the right entry.
2. File a ticket against the handler's owning team. The runtime is
   not at fault here; the handler is.
3. If the handler is one we own, also check whether the deadline was
   set too generously - a 1-hour deadline on a job that should take
   a minute means the runaway state lasts an hour before being
   detected. The default deadline in our handlers is 5 minutes;
   exceptions need a comment explaining why.
