# Release runbook

Tideway releases are fairly mechanical. The interesting part is the
in-place migration story; everything else is the usual ceremony.

## Prepare

1. Bump version in root `package.json`. Per-package versions follow
   the root version - I don't independently version internal
   packages.
2. Update CHANGELOG.md. Group changes under `### Added`, `### Changed`,
   `### Fixed`, `### Removed`. Anything that requires migration
   action goes under `### Migration` with explicit steps.
3. Run `npm run ci` locally. Skip with prejudice if green.

## Cut the release

```
git tag v$(jq -r .version package.json)
git push origin --tags
```

The release workflow in CI builds the npm tarball and publishes it.

## Migrate production

Each release whose CHANGELOG has a `### Migration` block requires:

1. Take a SQLite backup. `cp tideway.db tideway-pre-$VERSION.db`.
2. Drain the runner.
   ```
   tideway drain
   ```
   This blocks new submissions but lets inflight finish. Wait for
   `tideway list --state running` to return empty.
3. Stop the runner.
4. Run the migration:
   ```
   tideway-migrate run --db /var/lib/tideway/tideway.db
   ```
5. Start the new runner. Confirm `tideway status` reports
   `lifecycle=running` within 10 seconds.

If anything goes wrong: restore the backup, downgrade the binary,
file a postmortem.

## Roll back

```
sudo systemctl stop tideway-runner
cp tideway-pre-$VERSION.db tideway.db
# install the prior binary
sudo systemctl start tideway-runner
```

This loses any work that completed during the upgrade window. We
accept that loss because the alternative (running the old binary
against the new schema) is worse.
