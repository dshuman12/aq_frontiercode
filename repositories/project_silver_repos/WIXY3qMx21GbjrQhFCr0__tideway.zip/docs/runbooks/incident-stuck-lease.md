# Incident runbook: stuck lease

The reaper sweep should detect expired leases and requeue the
underlying runs. If runs are sitting in `running` state with leases
older than the TTL and the reaper isn't picking them up, the reaper
itself is the problem.

## Check the reaper sweep is running

The runner emits a tracing span named `lease-sweep` once per reaper
tick (default: every 5 seconds). If the spans aren't appearing for
~30 seconds, the reaper isn't running.

## Most common cause: a long task on the event loop

The reaper is scheduled via `setInterval`. An async task that doesn't
yield (a 30-second JSON.parse on a huge payload, a synchronous
`fs.readFileSync` on a slow disk) blocks the timer.

Find blocking tasks via:

```
tideway status --socket /var/run/tideway.sock
```

A `lifecycleStallMs` field in the response > 1000 indicates the event
loop has been blocked.

## If the reaper itself is healthy but leases aren't expiring

Check the system clock. Cross-host clock skew can theoretically cause
this, though tideway's leases are process-local so it's unlikely.
Real cause is usually a bug in the lease-acquire path that wrote a
TTL of `Infinity` by accident; grep the event log for
`leaseExpiresAt:.*999999`.

## Resolution

Once identified, the fix is usually to restart the runner. Lease
state recovers during replay (RFC 0001).

## If you have to manually requeue

Last resort. The console doesn't expose a "force requeue" command on
purpose. If you absolutely need it:

```
sqlite3 /var/lib/tideway/tideway.db
UPDATE runstate SET kind='queued', enqueuedAt=strftime('%s','now')*1000
WHERE run_id='RID' AND kind='running';
```

This is dangerous because it bypasses the FSM's invariants. Only do
it for a run that the worker has provably abandoned.

(There is a TODO to add `tideway force-requeue` as a console
subcommand. It hasn't been done because the use case is rare and
adding it would tempt people to use it when they shouldn't.)
