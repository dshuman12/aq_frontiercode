# On-call runbook

This is the runbook the primary on-call engineer should have open
when paged about a tideway-related issue.

## What you own

The runner process and the SQLite store backing it. You do NOT own
the handlers themselves - those belong to the team that registered
them. Your job is to keep the runtime healthy enough that handler
issues are visible in the logs and dlq.

## First steps when paged

1. Check that the runner process is running.
   - `pgrep -fa tideway-runner`
   - If not running: see `incident-runner-down.md` (does not exist
     yet; sorry; the short version is "restart it and check the
     SQLite WAL for partial writes").
2. Check the runner's status socket.
   - `tideway status --socket /var/run/tideway.sock`
   - This should return the lifecycle state and a brief snapshot of
     inflight runs. If it hangs, the event loop is wedged - see
     `incident-runaway-job.md`.
3. Check the dlq depth.
   - `tideway dlq inspect --limit 20`
   - A large dlq with a recent timestamp distribution is the most
     common page trigger.

## Common issues and where they go

| Symptom | Runbook |
|---|---|
| One job consumed too much CPU/memory | incident-runaway-job.md |
| Reaper is not reclaiming dead-worker leases | incident-stuck-lease.md |
| Outbox depth growing | not yet documented; usually means the sink is down |
| Disk filling from event log | not yet documented; usually means dlq replays piled up |

## Escalation

Page the secondary if any of:

- runner is down and you can't restart it cleanly
- dlq is growing faster than you can inspect
- the SQLite WAL refuses to checkpoint (`pragma wal_checkpoint(FULL)`
  returns nonzero)

## What you do NOT do without coordination

- `rm` the SQLite file. Even when corrupted. Take a backup first
  via `sqlite3 tideway.db ".backup /tmp/tideway-{date}.db"`.
- Manually edit the runstate. Use the console's `cancel` or
  `dlq drop` commands; never UPDATE rows directly.
- Increase the runner's worker count past 32 without warning the
  team. Workers don't share connections beyond that point and the
  store starts to thrash.
