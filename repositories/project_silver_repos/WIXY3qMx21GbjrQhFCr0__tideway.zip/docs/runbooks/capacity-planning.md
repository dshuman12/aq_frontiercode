# Capacity planning

How to size a tideway deployment.

## Workers

The worker pool size sets a hard cap on concurrent dispatch. Defaults
to 8 because that's enough for the workloads I've measured and small
enough to keep SQLite happy.

Rule of thumb: workers = max(8, expected concurrent jobs * 1.2). The
1.2 leaves headroom for the heartbeat / lease / outbox loops.

Above ~32 workers you start to see SQLite write contention. If you
need more concurrency than that, your workload either needs a
broker-shaped runtime (Temporal) or your handlers are doing something
they shouldn't be inside the runtime.

## Store sizing

The store has three growing tables:

| Table | Growth driver | Recommended retention |
|---|---|---|
| event_log | one row per state transition | 30 days |
| outbox | one row per emitted side-effect, deleted on delivery | (delivered immediately) |
| idempotency | one row per submission with a key, expires per TTL | TTL window |

A 1k-runs/day workload with average 6 transitions/run produces 6k
event_log rows/day. At 200 bytes/row, that's 1.2 MB/day or ~36 MB/month.
Retention purging (a separate cron job) keeps the database under
control.

## Outbox sink throughput

The outbox flush loop dispatches up to `batchSize` (default: 64)
messages per tick. Tick rate is per-runner-config (default: every
100ms). Sustained outbox throughput therefore caps at ~640
messages/sec per runner.

If the sink is faster than this, tune `batchSize` up. If the sink is
slower, the outbox depth grows; the alarm fires when depth > 10k for
> 5 minutes.

## Heartbeat / lease

Default lease TTL = 30s, heartbeat interval = 10s. The 3:1 ratio is
deliberate: it tolerates two missed heartbeats before considering the
worker dead. Below 2:1 you get false-positive lease expirations under
GC pauses; above 4:1 the reclaim latency stops being useful.

For long-running jobs (e.g., > 5 minutes), bump TTL but keep the
ratio. Jobs that legitimately need a 60-minute TTL are rare;
investigate whether the work can be split into smaller jobs first.
