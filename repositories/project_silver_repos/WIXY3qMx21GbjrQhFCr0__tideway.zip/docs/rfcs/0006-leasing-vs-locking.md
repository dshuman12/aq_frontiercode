# RFC 0006: Leasing rather than locking

- Status: accepted
- Author: Hammad
- Date: 2026-01-30

## Context

When a worker picks up a job, the runtime needs to ensure no other
worker also picks it up. Two options: a held lock (e.g., a database
row lock with `SELECT ... FOR UPDATE`), or a TTL-bounded lease.

I went with leasing. The reasoning, in case anyone is tempted to
revisit this:

A row lock survives only as long as the connection. If a worker on a
flaky network holds the lock and gets partitioned, the lock stays
"held" until TCP keepalive or some other signal closes the connection,
which is on the order of 30-90 seconds in default Linux configs. We
either wait that out (terrible operator experience) or build our own
liveness detection on top, in which case I've reinvented leasing
poorly.

A lease, by contrast, has a fixed TTL with a clear meaning: "if I
haven't heartbeated by T, assume I'm dead". The reaper sweep finds
expired leases and reclaims them. The semantics are observable purely
from the registry side without trusting connection state.

## Decision

`@tideway/leasing` exposes `LeaseRegistry` with `acquire / heartbeat /
release / sweepExpired`. The runner heartbeats every 10 seconds against
a 30-second TTL.

## Consequences

Good:
- Reaper detection latency is bounded by the TTL.
- A worker that crashes hard (segfault, OOM kill, host loss) doesn't
  wedge its job - it just sits queued until the lease expires and the
  reaper picks it up.

Bad:
- Clock skew between the leasing process and any peer that observes
  the lease can cause spurious "expired" judgments. Mitigated by the
  fact that our leases are process-local; the only consumer is the
  same runner that wrote them. Cross-host leasing would need NTP-style
  bounds.

## Open questions

The 30s TTL was chosen because most jobs we care about complete inside
that window. Long-running jobs need longer TTLs and proportionally
slower reaper response. Currently the operator sets per-handler-class
TTLs at registration time; whether that's the right knob is something
I'm still poking at - see also TODO.md item about lease-budgeting.
