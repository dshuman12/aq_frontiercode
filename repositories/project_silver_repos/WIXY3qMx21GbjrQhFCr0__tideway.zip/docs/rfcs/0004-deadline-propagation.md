# RFC 0004: Deadline propagation through DAGs

- Status: accepted
- Author: Hammad
- Date: 2026-01-08

## Context

A workflow with multiple steps inherits its overall deadline from the
operator who submitted it. The question is how to derive each step's
effective deadline from the workflow-level constraint.

## Decision

A node's effective deadline is the minimum of:

- its declared deadline (if any)
- the effective deadline of every parent (recursively)

Computed via BFS by in-degree at validation time. A `null`-equivalent
is represented as `Infinity` so the min-reduce is uniform.

## Discussion

The "declared-only" alternative (each node's deadline is its own,
period) was tempting because it's simpler. But it leads to a class of
bug where the operator declares "this whole workflow must finish by
T", a child node finishes a moment after T, the workflow as a whole
is now over budget, and nothing in the system flagged it because no
individual node's local deadline was breached.

The "min-of-parents" rule means a child can never outlive its parent.
That matches the natural intuition of "deadline" in workflow land.

For diamond children with two parents, we take min over both. The
strictest path wins.

## Implementation note

`@tideway/deadline` exposes `propagate(graph)` returning a
`Map<NodeId, Deadline>`. The runner runs propagation once per
workflow at submission time, then again whenever the topology changes
(currently never, but the API supports it for future cancellation
sub-DAGs).

## Open questions

None.
