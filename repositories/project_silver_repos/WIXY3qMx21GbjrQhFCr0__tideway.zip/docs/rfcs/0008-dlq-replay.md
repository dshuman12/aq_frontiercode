# RFC 0008: Dead-letter queue replay semantics

- Status: accepted
- Author: Hammad
- Date: 2026-02-16

## Context

Jobs that exhaust retries (or fail with `permanent`) land in the dead-
letter queue. Operators inspect the dlq and decide whether to:

- replay (re-run with attempt count reset)
- drop (give up)
- bulk-replay/drop (do it for many entries matching a filter)

The question is what "replay" means precisely. Does it preserve the
original attempt count? Does it issue a new run id? Does it bypass
idempotency cache?

## Decision

Replay creates a fresh run with attempt = 1, a new run id, and a
fresh idempotency window (the existing entry is abandoned). The
original entry's `finalAttempt` is preserved for trace continuity:
status queries on the new run can see "this run replays a prior
failure that gave up at attempt 4".

Drop is permanent. Operators who want a "soft delete" pattern can
replay with `--max-attempts=0` to short-circuit.

## Why a new run id?

Two reasons. First, observability: the trace for the replayed run is a
new trace, with a parent-link to the original. Otherwise, a replay
appears as continued execution of the failed run, which makes incident
post-mortems hard ("did this work the second time? when?").

Second, idempotency: the original (handler, key) entry is in 'failed'
state inside the TTL. If we reused the run id and the handler was
keyed, the new run would short-circuit to the failed result without
running. Forcing a new run id sidesteps this.

## Consequences

Good:
- Replays are clearly distinguishable in traces.
- Caller-keyed idempotency continues to make sense post-replay.

Bad:
- Operators have to remember that "replay" is "submit a new run".
  The CLI helper that lists "this run was a replay of {id}" mitigates
  this but doesn't make it disappear.
