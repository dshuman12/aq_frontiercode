# RFC 0001: In-process runtime shape

- Status: accepted
- Author: Hammad
- Date: 2025-11-22

## Context

Most workflow runtimes (Temporal, Airflow, BullMQ, even Inngest in its
self-hosted form) are broker-shaped: a separate process owns the queue,
workers connect to it, and the application talks to the broker over the
network. That's the right answer when you have many services that all
need to submit work, or when workers should scale independently of the
submitting service.

It's the wrong answer for the use case I keep hitting: a single backend
service that needs durable retries, deadlines, and idempotent
side-effects for *its own* work. Pulling in BullMQ + Redis is overkill;
ad-hoc try/retry loops with manual idempotency-key bookkeeping is what
we end up writing instead, and that code is buggy.

## Proposal

Tideway runs in-process. The application embeds the runtime as a
library. State lives in a SQLite file colocated with the service.
Workers are pooled goroutine-style inside the same Node process. The
"runner" daemon and the "console" CLI exist for operational visibility
but are optional - they connect over a unix socket to inspect a
running runtime, but the runtime itself doesn't need them.

## Alternatives considered

- **Broker mode (Temporal-shaped).** Dropped. Adds a process to deploy
  and a network hop for every transition. The use case I care about
  doesn't justify that overhead.
- **Library that pushes onto a generic queue (Redis, SQS).** Considered.
  Same complexity as broker mode plus we lose the ability to commit
  state-transition + outbox in one transaction.
- **Pure in-memory.** Rejected. Loses durability across crashes, which
  is the entire point.

## Consequences

Good:
- Zero infrastructure to deploy. The store is a file.
- Single transaction across runstate change + outbox emission. This is
  the property that makes the "exactly-once side effect" guarantee
  achievable; without it I'd need 2PC against the side-effect target.
- The runner can be embedded in tests trivially.

Bad:
- No cross-host distribution. If the host dies, the workflows die with
  it (until the host comes back and replay rebuilds state). For the
  target use case this is acceptable; for HA workloads it's a deal-
  breaker. Documented in 0013.
- Single SQLite file is a bottleneck under sustained 1000+ writes/sec.
  Acceptable for our load; people running into the limit should reach
  for a real broker.

## Open questions

None.
