# RFC 0012: Fan-out / fan-in semantics

- Status: **draft / WIP**
- Author: Hammad
- Date: 2026-04-02
- Last touched: 2026-05-01

## Context

I'm still arguing with myself about the right semantics for partial
fan-in failures.

A node B with parents [P1, P2, P3] is dispatched once all three parents
succeed. Easy case. The hard case: P1 succeeds, P2 succeeds, P3 fails
permanently. Today, B is canceled with reason='parent_failure'.

That's defensible. It's also wrong for a class of cases the runtime
should support but currently doesn't: "fan-in but tolerate up to K
failed parents, as long as K' >= 1 succeeded". This is the "any-of"
or "majority-of" pattern that real workflows want for redundancy.

## Considered approaches (none accepted yet)

1. **Per-edge "required" flag.** Each parent edge declares whether
   the child can run if that parent fails. Default: required. The
   scheduler logic becomes: dispatch B if every required-parent
   succeeded AND at least one optional-parent succeeded (or there are
   no optional parents).

   Problem: the at-least-one rule is a property of the *child*, not
   the edges, so the edge-flag form misrepresents it.

2. **Per-node "join-policy".** Each node declares one of:
   `all`, `any`, `quorum(K)`. The scheduler resolves dispatch
   eligibility per the policy.

   Problem: `quorum(K)` interacts strangely with the deadline rule.
   What's the effective deadline of a quorum-K node when the K-th
   parent succeeded an hour after the strictest parent's deadline
   would have asked it to run? My current draft says "use the time
   of the K-th success", but that means the deadline I record at
   submission is wrong, which the operator UI then displays
   misleadingly.

3. **Don't support it; document the workaround.** The user wraps the
   "any-of" pattern in their own catch-failure handler that emits
   a synthetic success event. Crude but it works today.

## What I'm leaning toward

Option 3 currently, option 2 in a future major. The right thing is
probably option 2 with a clarification in the deadline rule: a
quorum-K node's effective deadline is `min(declared, max_K(parents'
effective deadlines))` - the K-th tightest among parents. But I
haven't proven that this doesn't cause weird interactions with the
cancellation cascade.

Coming back to this later. Marking this WIP so I remember.

## Open questions

- Quorum + deadlines: what happens if K succeed but one of those was
  past their effective deadline?
- The retry policy interacts: if a parent is in `retry_scheduled`
  state, do we wait for it or count it as "not yet succeeded but will
  be"?
