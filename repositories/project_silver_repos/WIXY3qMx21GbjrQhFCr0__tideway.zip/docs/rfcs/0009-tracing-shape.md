# RFC 0009: Tracing shape (OTel-compatible attributes)

- Status: accepted
- Author: Hammad
- Date: 2026-02-25

## Context

Tideway emits tracing spans for: job-execution, retry, deadline-check,
lease-acquire, outbox-flush. The question was whether to take a hard
dependency on `@opentelemetry/api` or roll a small in-tree exporter.

## Decision

In-tree, OTel-compatible. The reasoning:

- The API surface I actually need is tiny: start a span, set
  attributes, record an exception, end. Three classes and two
  interfaces.
- `@opentelemetry/api` brings in a bunch of ceremony (context
  propagation, baggage, the global tracer provider) that doesn't fit
  the in-process runtime model.
- The span shape we emit is JSON-compatible with OTel's wire format,
  so swapping in the real SDK if a user wants to is a one-file change
  in the runner.

## Span shape

Every emitted span has:

- `context: {traceId, spanId}` - 32-hex traceId, 16-hex spanId
- optional `parent: SpanContext`
- `name`, `kind: 'internal' | 'producer' | 'consumer' | 'client' | 'server'`
- `startTimeUnixNano`, `endTimeUnixNano` (bigint, nanoseconds since epoch)
- `attributes: Record<string, string | number | boolean>`
- `status: { code: 'unset' | 'ok' | 'error', message?: string }`
- `events: SpanEvent[]`

A `JsonlExporter` writes one span per line as JSON; the runner
optionally pipes that to a sidecar that forwards to the OTel
collector.

## Consequences

Good:
- No transitive dependency.
- Trivial to test (`InMemoryExporter` accumulates spans).

Bad:
- We don't get OTel's context-propagation hooks for free. Handlers
  that want to continue an inbound trace have to thread `traceparent`
  through manually. For the in-process case this is fine; the runner
  passes the context to handlers via `JobContext`.
