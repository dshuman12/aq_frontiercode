# RFC NNNN: Title

- Status: draft | accepted | rejected | superseded
- Author:
- Date:
- Supersedes:
- Superseded by:

## Context

What problem prompted this RFC? Include enough background that a reader
joining the project six months from now can decide whether the decision
still holds.

## Proposal

What's the proposed change. Concrete enough to be implementable from
this document.

## Alternatives considered

What else was on the table. Include the obvious "do nothing" option even
when it's clearly wrong.

## Consequences

What follows from accepting this, both good and bad. Be explicit about the
costs.

## Open questions

Anything not yet resolved.
