# RFC 0005: Pluggable retry policies

- Status: accepted
- Author: Hammad
- Date: 2026-01-19

## Context

Retries need a policy that maps `attempt` -> delay. The library
ships exponential, linear, fibonacci, and constant. Operators
inevitably want something we didn't think of.

## Decision

The policy is a plain function `(attempt: number) => Duration`. The
built-ins are factories that close over their parameters and return
such a function. User code can pass any function; the `custom`
factory exists only for self-documenting callsites.

Jitter is layered on top via `jitter(policy, opts)`. The four jitter
modes (none, full, equal, decorrelated) cover the common patterns
without making the policies themselves stateful.

## Why not a class?

I prototyped this with a `RetryPolicy` interface and concrete
classes. It worked but the boilerplate for the simplest "give me 30
seconds, every time" case was 3 lines (class extension + constructor)
where the function form is one. The function form also makes
`policy(attempt)` look like math, which is what it is.

## Consequences

Good:
- The user-extension story is trivial: write a function.
- Composition is regular: `capped(jitter(exponential(...), {...}), 60_000)`
  reads as "exponential with full jitter, capped at 60 seconds".

Bad:
- Stateful policies (decorrelated jitter) need a closure. That's the
  one case where the function form is slightly awkward; you have to
  remember that creating a new closure per run is required, otherwise
  the state leaks across runs.
