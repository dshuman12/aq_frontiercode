# RFC 0007: Transactional outbox

- Status: accepted
- Author: Hammad
- Date: 2026-02-09

## Context

When a job completes, two things should happen:

1. The runstate transitions to `succeeded` (or `failed`).
2. Any side-effects the job emitted - child run submissions, callbacks
   to external systems, tracing spans - get delivered.

If we update runstate first and then deliver side-effects, a crash
between the two drops side-effects. If we deliver first and then update
runstate, a crash duplicates them. The classical solution is the
outbox pattern: emit side-effects into a durable queue *in the same
transaction* as the runstate update, then drain the queue separately.

## Decision

The store has an `outbox` table. Side-effects are written there as
part of the same SQLite transaction that writes the runstate event.
A flush loop drains the outbox and calls the registered sink. The
sink either succeeds (we mark delivered) or fails (we nack with
exponential backoff; quarantine after N attempts).

Per-partition ordering is preserved: messages with the same partition
key are delivered sequentially. Across partitions, delivery is
concurrent.

## Why per-partition ordering?

Without it, a tracing span emitted before its child span can be
delivered after, which produces nonsense traces. Picking partition
key = traceId fixes it.

## Consequences

Good:
- No 2PC needed against the side-effect sink.
- At-least-once delivery is automatic. Sinks handle de-dup.

Bad:
- Sinks have to be idempotent. This is a real constraint that has to
  be documented for handler authors.
- The outbox can grow unboundedly under sink outage; we have an
  alarm for it but not a back-pressure mechanism. The runner doesn't
  refuse new submissions when the outbox is large.
