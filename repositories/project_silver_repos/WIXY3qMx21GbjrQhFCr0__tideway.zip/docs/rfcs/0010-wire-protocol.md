# RFC 0010: Wire protocol versioning

- Status: accepted
- Author: Hammad
- Date: 2026-03-04

## Context

The console connects to the runner over a unix socket and speaks a
length-prefixed JSON protocol. We need a story for backward-compat
when the protocol evolves.

## Decision

A single-byte handshake at connection time. The initiator sends
PROTOCOL_VERSION; the responder accepts (echoes the same byte) or
rejects (closes the socket without writing). Version mismatches are
caught at handshake, not deep into a request.

For now PROTOCOL_VERSION = 1. When we eventually need to break
compat, the responder advertises a capability set in its handshake
response (no longer just an echo) and the initiator falls back to a
compatible subset. None of this is implemented yet; the byte just
gives us the room to do it.

## Why JSON not protobuf?

Message volumes are low (one CLI command -> one wire round-trip).
JSON is human-readable on the wire, which has saved several hours of
operator debugging by making `cat` work as a poor man's tracer. The
size and parse-cost penalty doesn't matter at our volumes.

## Why a single byte?

We could embed a JSON header instead. The byte is fine because
I'll never need to tell the peer more than "what version are you,
and what do you support" at handshake time, and the support set only
matters once we have multiple incompatible versions, which is years
away.

## Consequences

Good:
- A peer with the wrong version gets a clean rejection rather than a
  cryptic JSON parse error mid-stream.
- The protocol is debuggable with `nc` plus a hex editor.

Bad:
- The single-byte commitment means we have at most 256 protocol
  versions. We will not hit this.
