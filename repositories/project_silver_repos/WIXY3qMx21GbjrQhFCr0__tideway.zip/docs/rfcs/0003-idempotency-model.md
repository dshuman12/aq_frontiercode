# RFC 0003: Caller-keyed idempotency

- Status: accepted
- Author: Hammad
- Date: 2025-12-19

## Context

Two ways the runtime could prevent duplicate side-effects:

1. **Caller-keyed.** The submitter passes an `idempotencyKey`. The
   runtime hashes (handler, key) and uses that as a dedup token within
   a TTL window.
2. **System-keyed.** The runtime computes a key from the input
   payload's hash. No caller cooperation needed.

System-keyed sounds appealing - "I'll dedup automatically!" - but it
doesn't survive contact with reality. Two submissions with structurally
identical inputs that should be treated as separate (e.g., "send
welcome email to user 37" submitted on day 1 and again on day 30) hash
to the same key and the second one silently no-ops. The caller has no
way to override.

## Proposal

Caller-keyed. The submission API takes an optional `idempotencyKey`
string. If absent, no dedup. If present, the registry stores
(handler_id, key) -> { inflight | completed | failed } with a TTL
(default 24h) and routes subsequent submissions to one of:

- **fresh** - this is the first submission, run it
- **join** - someone else has it inflight, wait
- **result** - it already completed within TTL, return the stored result

## Alternatives considered

- **System-keyed only.** Rejected for the reason above.
- **Both, with a flag.** Considered briefly; rejected as needless
  complexity. Callers who want input-hash dedup can compute the hash
  themselves and pass it as the key.

## Consequences

Good:
- Caller controls dedup explicitly. "Send the same payload twice" is
  expressible.
- The (handler, key) compounding means the same key under different
  handlers doesn't collide (e.g., "order-37" can mean both "send
  email" and "log audit" without interference).

Bad:
- Caller can submit different payloads under the same key and get the
  first payload's result back, which is surprising. Considered
  hashing the input as a tamper check - if the (handler, key) is
  reused with a different payload hash, reject - but didn't do it
  because legitimate use cases (e.g., adding fields to the payload
  over time) want the more permissive behavior.

## Open questions

None.
