# RFC 0002: Explicit run-state FSM

- Status: accepted
- Author: Hammad
- Date: 2025-12-04

## Context

Every workflow run moves through a small set of named states (queued,
running, succeeded, failed, retry_scheduled, canceled, timed_out). Every
state has a fixed set of legal events.

Two ways to model this:

1. **Implicit.** Carry a few flags around (`isRunning: boolean`,
   `result: T | null`, `error: Error | null`) and let the call sites
   decide what's legal.
2. **Explicit.** A discriminated union state + a pure `transition(state,
   event)` function with an exhaustive switch.

I went with explicit. Here's why.

## Proposal

`@tideway/runstate` exposes:

- A `RunState` discriminated union with one variant per state kind.
- An `Event` discriminated union with one variant per event kind.
- A pure `transition(state, event, opts?)` function that returns the
  new state or throws `IllegalTransition`.
- An `initialState(at: bigint)` constructor.

The function is exhaustive on (state.kind, event.kind). Illegal pairs
throw with a stable error message format that downstream tooling
greps for.

## Alternatives considered

The implicit form was tried in a sketch from 2025-11-25. It wasn't
terrible but the tracking issue was that "is this run dispatchable?"
required reading three fields that had to be pairwise consistent. The
explicit FSM made that property a one-line check (`state.kind ===
'queued' || state.kind === 'retry_scheduled'`), which was worth the
extra ceremony.

A separate concern: making the FSM table-driven (data, not code). I
rejected this because it loses TypeScript's type narrowing inside the
switch. With an exhaustive switch, the compiler tells you when you
add a new state and forget to handle it somewhere; with a table you
can't get that without extra plumbing.

## Consequences

Good:
- Adding a new state requires touching every relevant switch, which
  surfaces all the places that care.
- Replay is trivial: just fold `transition` over the event log.
- Test coverage is mechanical: 7 states * 9 events = 63 (state, event)
  pairs, each gets a test (legal or illegal). The package's tests
  assert all 63.

Bad:
- The FSM grew a `retry_scheduled` state when an earlier draft had
  used `queued + attempt > 0`. Operators couldn't tell from a snapshot
  whether a queued run was a fresh submission or a retry, and they
  kept canceling retries thinking they were originals. The explicit
  state cost ~30 lines of FSM code and saved hours of operator
  confusion.

## Open questions

None.
