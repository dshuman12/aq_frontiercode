# RFC 0013: Distributed runtime mode

- Status: **rejected (not in scope)**
- Author: Hammad
- Date: 2026-04-10

## Context

Asked by an early reader: "can tideway run across multiple hosts?"

No, and not by accident.

The in-process design (RFC 0001) is intentional. Adding cross-host
distribution would mean either:

- consensus on the event log (Raft or similar), which is months of
  work and a different category of system, or
- partitioning workflows across hosts with a coordinator, which
  recreates the broker-shape we explicitly didn't want.

If you need either of those, use Temporal. Tideway's value is being
the small, embedded thing for the case where you don't.

This RFC exists so the next person who asks can be pointed at it,
rather than re-litigating the question.
