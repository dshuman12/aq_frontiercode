# RFC 0011: Cron semantics (5-field, UTC, no extensions)

- Status: accepted
- Author: Hammad
- Date: 2026-03-15

## Context

Cron-scheduled workflows are a frequent ask. The cron grammar has
several variants in the wild (POSIX 5-field, Vixie 5-field with
named months, Quartz 6/7-field with seconds and year, the various
"L"/"W"/"#" extensions). Picking the wrong one means either limiting
expressivity or shipping a parser whose edge cases I'll be
debugging forever.

## Decision

5-field POSIX-style only:

```
minute  hour  day-of-month  month  day-of-week
0-59    0-23  1-31          1-12   0-6 (Sun=0)
```

Each field supports `*`, single value, range (`N-M`), step
(`*/S`, `N/S`, `N-M/S`), comma list. No named months/days. No L/W/#.
All times are interpreted in UTC.

## Why no named fields?

Named months and weekdays look helpful but interact badly with case
sensitivity, locale, and three-letter ambiguity (does `THU` mean
Thursday or some other locale's day?). The runtime cost of supporting
them correctly is real (a name->number table maintained per locale)
and the user-facing benefit is tiny - everyone copies cron expressions
from somewhere anyway, and numeric forms paste-compatible across
implementations.

## Why UTC?

Tz handling needs a tz database (`Intl.DateTimeFormat`'s coverage is
inconsistent across Node versions, and pulling in `tzdata` is a lot
of bytes for an embedded runtime). UTC means our cron is explicit about
the wall-clock semantics: "fire when this UTC condition holds". A
caller who wants "every weekday at 9am New York time" computes that
as "every weekday at 13:00 UTC, except during DST when it's 14:00"
and submits two cron expressions, or rewrites the schedule each DST
transition.

This is annoying. It's also the only honest answer that doesn't
require us to ship a tz database.

## Consequences

Good:
- The parser is a few hundred lines.
- Behavior is fully deterministic across hosts.
- Users who genuinely need wall-clock semantics build a thin wrapper
  in their own code.

Bad:
- "Every weekday at 9am local" is not directly expressible. Documented
  in the cron-grammar reference page.
