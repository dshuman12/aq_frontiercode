# nota

**nota** is a local-first, markdown-powered personal knowledge base for the command line.

It keeps your notes as plain `.md` files — no proprietary formats, no cloud dependency — while providing fast full-text search, wiki-style linking, tag management, and optional AI-powered features.

```
$ nota new "Design decisions for the auth service"
✓ Created design-decisions-for-the-auth-service.md

$ nota find "auth jwt"
1. Design decisions for the auth service  notes/auth/...
2. JWT rotation strategy                  notes/security/...

$ nota backlinks "JWT rotation strategy"
  Design decisions for the auth service  notes/auth/...
  Security runbook                       notes/ops/...
```

---

## Features

| Feature | Command |
|---|---|
| Create & edit notes | `nota new`, `nota edit` |
| Full-text search (FTS5) | `nota find <query>` |
| Fuzzy title matching | included in `find` |
| Semantic / embedding search | `nota find --semantic` |
| Wiki-style links `[[Note]]` | auto-indexed |
| Backlinks | `nota backlinks <note>` |
| Tag system (`#tag`) | `nota tags` |
| Daily notes | `nota daily` |
| Note templates (Jinja2) | `nota new --template path/to/tmpl.md` |
| Knowledge graph | `nota graph` / `nota graph --json` |
| HTML export | `nota export html` |
| PDF export | `nota export pdf` (requires `nota[pdf]`) |
| Live index (file watcher) | `nota index --watch` |
| MCP server for AI assistants | `nota mcp-serve` |
| AES-256 encryption | `nota encrypt <note>` |
| Obsidian vault import | `nota import --format obsidian <path>` |
| Plugin system | entry-point group `nota.plugins` |

---

## Installation

```bash
pip install nota
```

Optional extras:

```bash
pip install nota[semantic]   # sentence-transformers for embedding search
pip install nota[pdf]        # WeasyPrint for PDF export
pip install nota[sync]       # boto3 for S3 sync (experimental)
pip install nota[encrypt]    # cryptography for AES-256 note encryption
pip install nota[mcp]        # MCP server for AI assistant integration
pip install nota[all]        # everything
```

---

## Quick start

```bash
# initialise a vault in the current directory
nota init

# create a note
nota new "My first note"

# list notes
nota ls

# search
nota find "python async"

# open a note in $EDITOR
nota edit "my first note"

# see what links to a note
nota backlinks "my first note"

# daily journal
nota daily
```

---

## Vault layout

```
my-vault/
├── .nota/
│   ├── config.json   # vault-local config
│   └── index.db      # SQLite index (auto-generated)
├── daily/
│   └── 2025-06-01.md
├── projects/
│   └── auth-redesign.md
└── ideas.md
```

---

## Configuration

`nota` reads configuration from the first file found in:

1. `.notarc` (project root)
2. `.nota/config.json` (vault)
3. `~/.notarc`
4. Platform config dir (`~/.config/nota/config.json` on Linux)

```json
{
  "vault": "/home/user/notes",
  "editor": "nvim",
  "date_format": "%Y-%m-%d",
  "semantic_model": "all-MiniLM-L6-v2",
  "webhooks": ["https://hooks.example.com/nota"],
  "plugins": ["my_nota_plugin"]
}
```

---

## Plugins

Any Python package can extend nota by registering under the `nota.plugins` entry-point group:

```toml
# in your plugin's pyproject.toml
[project.entry-points."nota.plugins"]
my-plugin = "my_nota_plugin"
```

The module must expose `register(cli: click.Group) -> None`.

---

## MCP integration

Start a stdio MCP server so AI assistants (Claude, Cursor, etc.) can read and create notes:

```bash
nota mcp-serve
```

Resources are exposed as `nota://<note-id>`, and two tools are provided:
- `search_notes(query, limit)` — full-text search
- `create_note(title, content, tags)` — create a new note

---

## Development

```bash
git clone https://github.com/pramodhkrishna42/nota
cd nota
pip install -e ".[dev]"
pytest
```

---

## License

MIT © Pramoth Krishna
