"""Export notes and vault graph to JSON."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..core.note import Note
from ..core.store import Store


def export_json(store: Store, output: Optional[Path] = None) -> Dict[str, Any]:
    notes_data: List[Dict[str, Any]] = [n.to_dict() for n in store.notes()]
    graph = store.graph()
    payload = {
        "version": 1,
        "vault": str(store.vault_root),
        "notes": notes_data,
        "graph": graph,
        "stats": store.stats(),
    }
    if output:
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")
    return payload
