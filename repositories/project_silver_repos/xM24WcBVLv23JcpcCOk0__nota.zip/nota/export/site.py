"""Static site generator for nota vaults.

Produces a self-contained HTML site with:
  - An index page listing all notes
  - Per-note pages with navigation and backlinks
  - A tag index page
  - A graph page (JSON-powered, optional)
  - Configurable themes (light / dark / custom CSS)
"""
from __future__ import annotations

import html as _html
import json
import re
import shutil
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

from ..core.note import Note
from ..core.store import Store
from .html import _md_to_html, _wiki_to_anchor

# ---------------------------------------------------------------------------
# Themes

_THEMES: Dict[str, str] = {
    "light": """
      :root { --bg:#fff; --text:#222; --link:#2563eb; --dim:#6b7280;
              --border:#e5e7eb; --code-bg:#f3f4f6; --tag-bg:#e5e7eb; }
    """,
    "dark": """
      :root { --bg:#1a1a2e; --text:#e2e8f0; --link:#60a5fa; --dim:#94a3b8;
              --border:#334155; --code-bg:#0f172a; --tag-bg:#1e293b; }
    """,
    "sepia": """
      :root { --bg:#fdf6e3; --text:#4a3f35; --link:#b5890e; --dim:#8c7b6b;
              --border:#d4c5a9; --code-bg:#f4ead5; --tag-bg:#ede3cc; }
    """,
}

_BASE_CSS = """
* { box-sizing: border-box; margin: 0; padding: 0; }
body { background: var(--bg); color: var(--text); font-family: system-ui, sans-serif;
       font-size: 16px; line-height: 1.7; }
a { color: var(--link); text-decoration: none; }
a:hover { text-decoration: underline; }
.layout { display: flex; min-height: 100vh; }
.sidebar { width: 260px; min-width: 260px; border-right: 1px solid var(--border);
           padding: 1.5rem 1rem; position: sticky; top: 0; height: 100vh;
           overflow-y: auto; background: var(--bg); }
.sidebar h2 { font-size: 1.1rem; margin-bottom: 0.75rem; color: var(--dim); }
.sidebar ul { list-style: none; }
.sidebar ul li { padding: 0.2rem 0; }
.sidebar .nav-link { font-size: 0.88rem; color: var(--text); display: block;
                      padding: 2px 4px; border-radius: 3px; }
.sidebar .nav-link:hover { background: var(--code-bg); text-decoration: none; }
.sidebar .nav-link.active { color: var(--link); font-weight: 600; }
.main { flex: 1; padding: 2rem 2.5rem; max-width: 860px; }
h1 { font-size: 2rem; margin-bottom: 0.5rem; }
h2 { font-size: 1.4rem; margin-top: 2rem; margin-bottom: 0.5rem; }
h3 { font-size: 1.1rem; margin-top: 1.5rem; }
p  { margin: 0.75rem 0; }
.meta { color: var(--dim); font-size: 0.85rem; margin-bottom: 1.5rem; }
.tag { background: var(--tag-bg); border-radius: 3px; padding: 1px 7px;
       font-size: 0.82rem; margin-right: 4px; }
.note-card { border: 1px solid var(--border); border-radius: 6px;
             padding: 1rem 1.25rem; margin-bottom: 1rem; }
.note-card h3 { margin-top: 0; }
.note-card .excerpt { color: var(--dim); font-size: 0.9rem; margin-top: 0.4rem; }
code { background: var(--code-bg); padding: 2px 5px; border-radius: 3px;
       font-size: 0.9em; font-family: 'JetBrains Mono', monospace; }
pre  { background: var(--code-bg); padding: 1rem; border-radius: 6px;
       overflow-x: auto; margin: 1rem 0; }
blockquote { border-left: 3px solid var(--border); padding-left: 1rem;
             color: var(--dim); margin: 1rem 0; }
table { border-collapse: collapse; width: 100%; margin: 1rem 0; }
th, td { border: 1px solid var(--border); padding: 0.5rem 0.75rem; text-align: left; }
th { background: var(--code-bg); }
.backlinks { margin-top: 3rem; border-top: 1px solid var(--border); padding-top: 1.5rem; }
.search-box { width: 100%; padding: 0.5rem 0.75rem; border: 1px solid var(--border);
              border-radius: 6px; background: var(--bg); color: var(--text);
              font-size: 0.9rem; margin-bottom: 1rem; }
.tag-count { color: var(--dim); font-size: 0.85rem; }
footer { color: var(--dim); font-size: 0.8rem; margin-top: 3rem;
         padding-top: 1rem; border-top: 1px solid var(--border); }
"""

_SEARCH_JS = """
const idx = {};
document.addEventListener('DOMContentLoaded', () => {
  const box = document.getElementById('search');
  if (!box) return;
  const cards = Array.from(document.querySelectorAll('.note-card'));
  box.addEventListener('input', () => {
    const q = box.value.toLowerCase();
    cards.forEach(c => {
      const text = c.textContent.toLowerCase();
      c.style.display = (!q || text.includes(q)) ? '' : 'none';
    });
  });
});
"""


# ---------------------------------------------------------------------------
# Page builders

def _page(title: str, body: str, *, sidebar: str, theme: str = "light", custom_css: str = "") -> str:
    theme_css = _THEMES.get(theme, _THEMES["light"])
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{_html.escape(title)}</title>
<style>
{theme_css}
{_BASE_CSS}
{custom_css}
</style>
</head>
<body>
<div class="layout">
<nav class="sidebar">
  <div style="font-weight:700;font-size:1.1rem;margin-bottom:1.5rem">
    <a href="index.html" style="color:var(--text);text-decoration:none">nota</a>
  </div>
  {sidebar}
</nav>
<main class="main">
{body}
<footer>Generated by <a href="https://github.com/pramodhkrishna42/nota">nota</a>
on {datetime.now().strftime('%Y-%m-%d')}</footer>
</main>
</div>
<script>{_SEARCH_JS}</script>
</body>
</html>"""


def _sidebar_html(notes: List[Note], *, active: Optional[str] = None) -> str:
    lines = ['<h2>Notes</h2>', '<ul>']
    for note in sorted(notes, key=lambda n: n.title.lower()):
        href = note.stem + ".html"
        active_cls = ' active' if note.stem == active else ''
        title_esc = _html.escape(note.title)
        lines.append(
            f'<li><a class="nav-link{active_cls}" href="{href}">{title_esc}</a></li>'
        )
    lines += ['</ul>', '<br>',
              '<h2>Pages</h2>', '<ul>',
              '<li><a class="nav-link" href="index.html">Home</a></li>',
              '<li><a class="nav-link" href="tags.html">Tags</a></li>',
              '<li><a class="nav-link" href="graph.html">Graph</a></li>',
              '</ul>']
    return "\n".join(lines)


def _excerpt(note: Note, max_chars: int = 160) -> str:
    text = re.sub(r"#{1,6}\s+", "", note.content)
    text = re.sub(r"\[\[([^\]]+)\]\]", r"\1", text)
    text = re.sub(r"\*+([^*]+)\*+", r"\1", text)
    text = re.sub(r"`[^`]+`", "", text)
    text = " ".join(text.split())
    return text[:max_chars] + "…" if len(text) > max_chars else text


# ---------------------------------------------------------------------------
# Individual pages

def _build_note_page(
    note: Note,
    store: Store,
    all_notes: List[Note],
    *,
    theme: str,
    custom_css: str,
) -> str:
    sidebar = _sidebar_html(all_notes, active=note.stem)
    backlinks = store.backlinks(note)

    tags_html = " ".join(
        f'<a class="tag" href="tags.html#{t}">{_html.escape(t)}</a>'
        for t in note.tags
    )
    created_str = note.created.strftime("%Y-%m-%d") if note.created else ""
    modified_str = note.modified.strftime("%Y-%m-%d")

    meta_parts = []
    if created_str:
        meta_parts.append(f"Created {created_str}")
    meta_parts.append(f"Modified {modified_str}")
    meta_parts.append(f"{note.word_count:,} words")

    content_html = _md_to_html(note.content)

    backlinks_html = ""
    if backlinks:
        items = "\n".join(
            f'<li><a href="{b.stem}.html">{_html.escape(b.title)}</a></li>'
            for b in backlinks
        )
        backlinks_html = f"""
        <div class="backlinks">
          <h2>Backlinks</h2>
          <ul>{items}</ul>
        </div>"""

    body = f"""
    <h1>{_html.escape(note.title)}</h1>
    <div class="meta">
      {tags_html}
      {"&nbsp;·&nbsp;".join(meta_parts)}
    </div>
    {content_html}
    {backlinks_html}
    """
    return _page(note.title, body, sidebar=sidebar, theme=theme, custom_css=custom_css)


def _build_index_page(notes: List[Note], all_notes: List[Note], *, theme: str, custom_css: str) -> str:
    sidebar = _sidebar_html(all_notes)
    cards = []
    for note in notes:
        tags_html = " ".join(f'<span class="tag">{_html.escape(t)}</span>' for t in note.tags[:4])
        excerpt = _html.escape(_excerpt(note))
        cards.append(f"""
        <div class="note-card">
          <h3><a href="{note.stem}.html">{_html.escape(note.title)}</a></h3>
          <div>{tags_html}</div>
          <div class="excerpt">{excerpt}</div>
        </div>""")

    body = f"""
    <h1>Notes</h1>
    <p style="color:var(--dim);margin-bottom:1rem">{len(notes)} notes</p>
    <input class="search-box" id="search" type="search" placeholder="Filter notes…" />
    {"".join(cards)}
    """
    return _page("nota — Notes", body, sidebar=sidebar, theme=theme, custom_css=custom_css)


def _build_tags_page(store: Store, all_notes: List[Note], *, theme: str, custom_css: str) -> str:
    sidebar = _sidebar_html(all_notes)
    tag_counts = store.all_tags()
    rows = []
    for tag, count in tag_counts.items():
        rows.append(f"""
        <div id="{_html.escape(tag)}" style="margin-bottom:1.5rem">
          <h2>#{_html.escape(tag)} <span class="tag-count">({count})</span></h2>
          <ul>{"".join(
            f'<li><a href="{n.stem}.html">{_html.escape(n.title)}</a></li>'
            for n in store.by_tag(tag)
          )}</ul>
        </div>""")

    body = f"""
    <h1>Tags</h1>
    <p style="color:var(--dim);margin-bottom:1.5rem">{len(tag_counts)} unique tags</p>
    {"".join(rows)}
    """
    return _page("nota — Tags", body, sidebar=sidebar, theme=theme, custom_css=custom_css)


def _build_graph_page(store: Store, all_notes: List[Note], *, theme: str, custom_css: str) -> str:
    sidebar = _sidebar_html(all_notes)
    adj = store.graph()
    graph_json = json.dumps(adj)

    body = f"""
    <h1>Knowledge Graph</h1>
    <p style="color:var(--dim);margin-bottom:1rem">
      {len(all_notes)} nodes &nbsp;·&nbsp;
      {sum(len(v) for v in adj.values())} edges
    </p>
    <canvas id="graph" width="800" height="600"
            style="border:1px solid var(--border);border-radius:6px;width:100%"></canvas>
    <script>
    const ADJ = {graph_json};
    // minimal force-directed layout
    const canvas = document.getElementById('graph');
    const ctx = canvas.getContext('2d');
    const nodes = Object.keys(ADJ);
    const W = canvas.width, H = canvas.height;
    let pos = {{}};
    nodes.forEach((n, i) => {{
      const angle = (2 * Math.PI * i) / nodes.length;
      pos[n] = {{ x: W/2 + 280*Math.cos(angle), y: H/2 + 220*Math.sin(angle),
                  vx:0, vy:0 }};
    }});
    function tick() {{
      // repulsion
      nodes.forEach(a => nodes.forEach(b => {{
        if (a===b) return;
        const dx = pos[a].x-pos[b].x, dy = pos[a].y-pos[b].y;
        const d = Math.sqrt(dx*dx+dy*dy) || 1;
        const f = 2000/(d*d);
        pos[a].vx += dx/d*f; pos[a].vy += dy/d*f;
      }}));
      // attraction
      nodes.forEach(src => (ADJ[src]||[]).forEach(tgt => {{
        if (!pos[tgt]) return;
        const dx = pos[tgt].x-pos[src].x, dy = pos[tgt].y-pos[src].y;
        const d = Math.sqrt(dx*dx+dy*dy) || 1;
        const f = d/40;
        pos[src].vx += dx/d*f; pos[src].vy += dy/d*f;
        pos[tgt].vx -= dx/d*f; pos[tgt].vy -= dy/d*f;
      }}));
      // damping + clamp
      nodes.forEach(n => {{
        pos[n].vx *= 0.85; pos[n].vy *= 0.85;
        pos[n].x = Math.max(20, Math.min(W-20, pos[n].x + pos[n].vx));
        pos[n].y = Math.max(20, Math.min(H-20, pos[n].y + pos[n].vy));
      }});
    }}
    function draw() {{
      ctx.clearRect(0,0,W,H);
      ctx.strokeStyle='#888'; ctx.lineWidth=1;
      nodes.forEach(src => (ADJ[src]||[]).forEach(tgt => {{
        if (!pos[tgt]) return;
        ctx.beginPath(); ctx.moveTo(pos[src].x,pos[src].y);
        ctx.lineTo(pos[tgt].x,pos[tgt].y); ctx.stroke();
      }}));
      ctx.fillStyle='#2563eb';
      nodes.forEach(n => {{
        ctx.beginPath(); ctx.arc(pos[n].x,pos[n].y,5,0,Math.PI*2); ctx.fill();
      }});
      ctx.fillStyle='#222'; ctx.font='11px system-ui';
      nodes.forEach(n => {{
        const label = n.split('/').pop().replace('.md','');
        ctx.fillText(label, pos[n].x+7, pos[n].y+4);
      }});
    }}
    let i = 0;
    function loop() {{ if(i++<80) tick(); draw(); requestAnimationFrame(loop); }}
    loop();
    </script>
    """
    return _page("nota — Graph", body, sidebar=sidebar, theme=theme, custom_css=custom_css)


# ---------------------------------------------------------------------------
# Main entry point

def build_site(
    store: Store,
    output_dir: Path,
    *,
    theme: str = "light",
    custom_css: str = "",
    clean: bool = False,
) -> int:
    """Generate a complete static site from the vault.

    Args:
        store: nota Store instance.
        output_dir: destination directory (created if absent).
        theme: ``'light'``, ``'dark'``, or ``'sepia'``.
        custom_css: additional CSS appended to the base stylesheet.
        clean: if True, wipe *output_dir* before generating.

    Returns:
        Number of HTML files written.
    """
    if clean and output_dir.exists():
        shutil.rmtree(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    all_notes = sorted(store.notes(), key=lambda n: n.modified, reverse=True)
    count = 0

    # per-note pages
    for note in all_notes:
        html = _build_note_page(note, store, all_notes, theme=theme, custom_css=custom_css)
        (output_dir / f"{note.stem}.html").write_text(html, encoding="utf-8")
        count += 1

    # index
    (output_dir / "index.html").write_text(
        _build_index_page(all_notes, all_notes, theme=theme, custom_css=custom_css),
        encoding="utf-8",
    )
    count += 1

    # tags
    (output_dir / "tags.html").write_text(
        _build_tags_page(store, all_notes, theme=theme, custom_css=custom_css),
        encoding="utf-8",
    )
    count += 1

    # graph
    (output_dir / "graph.html").write_text(
        _build_graph_page(store, all_notes, theme=theme, custom_css=custom_css),
        encoding="utf-8",
    )
    count += 1

    return count
