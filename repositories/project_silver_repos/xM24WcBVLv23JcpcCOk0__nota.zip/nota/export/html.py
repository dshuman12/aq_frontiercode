"""Export notes to HTML."""
from __future__ import annotations

import re
import html as _html
from pathlib import Path
from typing import Optional

from ..core.note import Note

_WIKI_RE = re.compile(r"\[\[([^\]|#]+)(?:#([^\]|]*))?\|?([^\]]*)\]\]")

_HTML_TEMPLATE = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
<style>
  body {{ font-family: system-ui, sans-serif; max-width: 760px; margin: 2rem auto; padding: 0 1rem; line-height: 1.6; color: #222; }}
  h1,h2,h3 {{ margin-top: 1.8em; }}
  a {{ color: #2563eb; text-decoration: none; }}
  a:hover {{ text-decoration: underline; }}
  .tag {{ background: #e5e7eb; border-radius: 3px; padding: 1px 6px; font-size: 0.85em; }}
  .meta {{ color: #6b7280; font-size: 0.9em; margin-bottom: 1.5em; }}
  code {{ background: #f3f4f6; padding: 2px 5px; border-radius: 3px; font-size: 0.92em; }}
  pre {{ background: #f3f4f6; padding: 1em; border-radius: 6px; overflow-x: auto; }}
  blockquote {{ border-left: 3px solid #d1d5db; margin: 0; padding-left: 1em; color: #4b5563; }}
</style>
</head>
<body>
<div class="meta">
  {tags_html}
  {dates_html}
</div>
{body}
</body>
</html>
"""


def _wiki_to_anchor(m: re.Match) -> str:
    target = m.group(1).strip()
    heading = m.group(2)
    alias = m.group(3).strip() if m.group(3) else target
    href = target.replace(" ", "-").lower() + ".html"
    if heading:
        href += "#" + heading.replace(" ", "-").lower()
    return f'<a class="wikilink" href="{_html.escape(href)}">{_html.escape(alias)}</a>'


def _md_to_html(md: str) -> str:
    """Minimal markdown-to-HTML conversion for export."""
    try:
        import markdown  # type: ignore
        return markdown.markdown(md, extensions=["fenced_code", "tables", "toc"])
    except ImportError:
        pass
    # fallback: basic conversion
    lines = []
    in_code = False
    for line in md.splitlines():
        if line.startswith("```"):
            if in_code:
                lines.append("</pre>")
                in_code = False
            else:
                lines.append("<pre><code>")
                in_code = True
            continue
        if in_code:
            lines.append(_html.escape(line))
            continue
        line = re.sub(r"^### (.+)$", r"<h3>\1</h3>", line)
        line = re.sub(r"^## (.+)$", r"<h2>\1</h2>", line)
        line = re.sub(r"^# (.+)$", r"<h1>\1</h1>", line)
        line = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", line)
        line = re.sub(r"\*(.+?)\*", r"<em>\1</em>", line)
        line = re.sub(r"`(.+?)`", r"<code>\1</code>", line)
        line = _WIKI_RE.sub(_wiki_to_anchor, line)
        if line and not line.startswith("<h"):
            line = f"<p>{line}</p>"
        lines.append(line)
    return "\n".join(lines)


def export_html(note: Note, output_dir: Optional[Path] = None) -> Path:
    out_dir = output_dir or note.vault_root / ".nota" / "export" / "html"
    out_dir.mkdir(parents=True, exist_ok=True)

    tags_html = " ".join(
        f'<span class="tag">#{t}</span>' for t in note.tags
    )
    created = note.created
    modified = note.modified
    dates_parts = []
    if created:
        dates_parts.append(f"Created: {created.strftime('%Y-%m-%d')}")
    dates_parts.append(f"Modified: {modified.strftime('%Y-%m-%d')}")
    dates_html = " &nbsp;·&nbsp; ".join(dates_parts)

    body = _md_to_html(note.content)

    rendered = _HTML_TEMPLATE.format(
        title=_html.escape(note.title),
        tags_html=tags_html,
        dates_html=dates_html,
        body=body,
    )

    out_path = out_dir / (note.stem + ".html")
    out_path.write_text(rendered, encoding="utf-8")
    return out_path


def export_vault_html(vault_root: Path, output_dir: Optional[Path] = None) -> list[Path]:
    from ..core.store import Store

    store = Store(vault_root)
    outputs = []
    for note in store.notes():
        outputs.append(export_html(note, output_dir))
    return outputs
