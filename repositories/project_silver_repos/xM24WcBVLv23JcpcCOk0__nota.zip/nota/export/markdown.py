"""Markdown export utilities.

  - Consolidated vault export: all notes merged into a single .md file
    with an auto-generated table of contents.
  - Per-note TOC injection.
  - Link rewriting for static site output.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import List, Optional, Tuple

from ..core.note import Note
from ..core.store import Store


# ---------------------------------------------------------------------------
# Table of contents

_HEADING_RE = re.compile(r"^(#{1,6})\s+(.+)$", re.MULTILINE)


def _slugify_heading(text: str) -> str:
    text = text.lower().strip()
    text = re.sub(r"[^\w\s-]", "", text)
    text = re.sub(r"\s+", "-", text)
    return text


def make_toc(content: str, *, min_level: int = 1, max_level: int = 3) -> str:
    """Generate a markdown table of contents from heading lines in *content*."""
    lines: List[str] = []
    seen_slugs: dict[str, int] = {}

    for m in _HEADING_RE.finditer(content):
        level = len(m.group(1))
        if level < min_level or level > max_level:
            continue
        text = m.group(2).strip()
        slug = _slugify_heading(text)

        # handle duplicates
        count = seen_slugs.get(slug, 0)
        seen_slugs[slug] = count + 1
        anchor = slug if count == 0 else f"{slug}-{count}"

        indent = "  " * (level - min_level)
        lines.append(f"{indent}- [{text}](#{anchor})")

    return "\n".join(lines)


def inject_toc(note: Note, *, placeholder: str = "<!-- toc -->") -> str:
    """Return note content with a TOC injected at *placeholder*.

    If *placeholder* is absent, the TOC is inserted after the first H1.
    """
    content = note.content
    toc = make_toc(content)
    if not toc:
        return content

    if placeholder in content:
        return content.replace(placeholder, toc, 1)

    # insert after first H1
    m = re.search(r"^# .+$", content, re.MULTILINE)
    if m:
        insert_pos = m.end()
        return content[:insert_pos] + "\n\n" + toc + content[insert_pos:]

    return toc + "\n\n" + content


# ---------------------------------------------------------------------------
# Link rewriting

_WIKI_RE = re.compile(r"\[\[([^\]|#]+)(?:#[^\]|]*)?\|?([^\]]*)\]\]")


def rewrite_wiki_links(content: str, *, extension: str = ".md") -> str:
    """Replace [[Wiki Links]] with standard markdown [Title](slug.ext)."""

    def _replace(m: re.Match) -> str:
        target = m.group(1).strip()
        alias  = m.group(2).strip() if m.group(2) else target
        slug   = target.lower().replace(" ", "-")
        return f"[{alias}]({slug}{extension})"

    return _WIKI_RE.sub(_replace, content)


def rewrite_links_for_html(content: str) -> str:
    return rewrite_wiki_links(content, extension=".html")


# ---------------------------------------------------------------------------
# Consolidated vault export

def _note_anchor(note: Note) -> str:
    return note.stem.lower().replace(" ", "-")


def export_consolidated(
    store: Store,
    output: Optional[Path] = None,
    *,
    include_toc: bool = True,
    sort_by: str = "title",
) -> str:
    """Export all vault notes as one big markdown document.

    Args:
        store: the nota Store to read from.
        output: if given, write the result to this file.
        include_toc: prepend a vault-level table of contents.
        sort_by: ``'title'``, ``'created'``, or ``'modified'``.

    Returns:
        The consolidated markdown string.
    """
    from datetime import datetime

    notes = list(store.notes())
    if sort_by == "title":
        notes.sort(key=lambda n: n.title.lower())
    elif sort_by == "created":
        notes.sort(key=lambda n: n.created or datetime.min)
    elif sort_by == "modified":
        notes.sort(key=lambda n: n.modified, reverse=True)

    sections: List[str] = []

    if include_toc:
        toc_lines = [f"- [{n.title}](#{_note_anchor(n)})" for n in notes]
        vault_toc = "# Table of Contents\n\n" + "\n".join(toc_lines)
        sections.append(vault_toc)
        sections.append("\n---\n")

    for note in notes:
        meta = note.metadata
        header_lines = [f"# {note.title}"]

        tag_str = " ".join(f"`#{t}`" for t in note.tags)
        if tag_str:
            header_lines.append(f"\n{tag_str}")

        if note.created:
            header_lines.append(f"\n*Created: {note.created.strftime('%Y-%m-%d')}*")

        header = "\n".join(header_lines)
        body = rewrite_wiki_links(note.content)
        sections.append(header + "\n\n" + body)
        sections.append("\n---\n")

    result = "\n".join(sections)

    if output:
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(result, encoding="utf-8")

    return result


# ---------------------------------------------------------------------------
# Section extraction

def extract_section(content: str, heading: str) -> Optional[str]:
    """Extract the body of a named heading section from markdown content."""
    pattern = re.compile(
        r"^(#{1,6})\s+" + re.escape(heading) + r"\s*$",
        re.MULTILINE | re.IGNORECASE,
    )
    m = pattern.search(content)
    if not m:
        return None

    level = len(m.group(1))
    start = m.end()

    # find the next heading of same or higher level
    next_heading = re.compile(
        r"^#{1," + str(level) + r"}\s",
        re.MULTILINE,
    )
    nm = next_heading.search(content, start)
    end = nm.start() if nm else len(content)
    return content[start:end].strip()


def split_by_headings(content: str, level: int = 2) -> List[Tuple[str, str]]:
    """Split *content* into [(heading_text, section_body), ...] at heading *level*."""
    pattern = re.compile(r"^#{" + str(level) + r"}\s+(.+)$", re.MULTILINE)
    positions = [(m.start(), m.group(1).strip()) for m in pattern.finditer(content)]

    sections: List[Tuple[str, str]] = []
    for i, (pos, title) in enumerate(positions):
        end = positions[i + 1][0] if i + 1 < len(positions) else len(content)
        body = content[pos:end].split("\n", 1)[1].strip() if "\n" in content[pos:end] else ""
        sections.append((title, body))

    return sections
