"""PDF export via WeasyPrint (optional dependency)."""
from __future__ import annotations

from pathlib import Path
from typing import Optional

from ..core.note import Note
from .html import export_html


def export_pdf(note: Note, output_dir: Optional[Path] = None) -> Path:
    try:
        import weasyprint  # type: ignore
    except ImportError as exc:
        raise RuntimeError(
            "PDF export requires WeasyPrint: pip install nota[pdf]"
        ) from exc

    out_dir = output_dir or note.vault_root / ".nota" / "export" / "pdf"
    out_dir.mkdir(parents=True, exist_ok=True)

    # reuse HTML export as intermediate
    html_path = export_html(note)
    pdf_path = out_dir / (note.stem + ".pdf")

    doc = weasyprint.HTML(filename=str(html_path))
    doc.write_pdf(str(pdf_path))
    return pdf_path
