"""Plugin system for nota.

Plugins are discovered via the `nota.plugins` entry-point group.
Each plugin module must expose a `register(cli)` function that receives
the main Click group and can attach new commands.
"""
from __future__ import annotations

import importlib
from typing import TYPE_CHECKING, List

if TYPE_CHECKING:
    import click


def load_plugins(cli: "click.Group", names: List[str]) -> None:
    for name in names:
        try:
            mod = importlib.import_module(name)
            if hasattr(mod, "register"):
                mod.register(cli)
        except Exception as exc:
            import warnings
            warnings.warn(f"nota: failed to load plugin {name!r}: {exc}", stacklevel=2)


def discover_entry_point_plugins(cli: "click.Group") -> None:
    try:
        from importlib.metadata import entry_points

        eps = entry_points(group="nota.plugins")
        for ep in eps:
            try:
                mod = ep.load()
                if hasattr(mod, "register"):
                    mod.register(cli)
            except Exception as exc:
                import warnings
                warnings.warn(f"nota: entry-point plugin {ep.name!r} failed: {exc}", stacklevel=2)
    except Exception:
        pass
