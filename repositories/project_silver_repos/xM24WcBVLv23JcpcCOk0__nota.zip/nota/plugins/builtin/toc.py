"""Built-in plugin: Table of Contents generation and injection.

Provides:
  - TocProcessor        — pipeline processor that injects <!-- toc --> markers
  - generate_toc()      — compute a TOC from markdown text
  - inject_toc()        — insert the TOC into text at the marker position
  - TocEntry            — data class for a single heading entry
  - vault_toc_report()  — report notes that are long but lack a TOC
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, List, Optional, Tuple

from nota.core.pipeline import Processor, PipelineContext


# ---------------------------------------------------------------------------
# Data types

@dataclass
class TocEntry:
    level: int
    text: str
    anchor: str
    line_no: int

    def to_markdown(self, min_level: int = 1) -> str:
        indent = "  " * (self.level - min_level)
        return f"{indent}- [{self.text}](#{self.anchor})"


@dataclass
class Toc:
    entries: List[TocEntry] = field(default_factory=list)

    def to_markdown(self) -> str:
        if not self.entries:
            return ""
        min_level = min(e.level for e in self.entries)
        lines = ["<!-- toc-generated -->"]
        lines += [e.to_markdown(min_level) for e in self.entries]
        lines.append("<!-- /toc-generated -->")
        return "\n".join(lines)

    def to_html(self) -> str:
        if not self.entries:
            return ""
        min_level = min(e.level for e in self.entries)
        items = "".join(
            f'<li style="margin-left:{(e.level-min_level)*16}px">'
            f'<a href="#{e.anchor}">{e.text}</a></li>'
            for e in self.entries
        )
        return f'<nav class="toc"><ul>{items}</ul></nav>'

    @property
    def depth(self) -> int:
        if not self.entries:
            return 0
        return max(e.level for e in self.entries) - min(e.level for e in self.entries) + 1


# ---------------------------------------------------------------------------
# Core functions

_HEADING_RE = re.compile(r"^(#{1,6})\s+(.+?)(?:\s+#+)?$", re.MULTILINE)
_FENCE_RE   = re.compile(r"^```.*?^```", re.DOTALL | re.MULTILINE)
_TOC_MARKER = "<!-- toc -->"
_TOC_BLOCK  = re.compile(
    r"<!-- toc-generated -->.+?<!-- /toc-generated -->", re.DOTALL
)


def _slug(text: str) -> str:
    text = re.sub(r"[^\w\s-]", "", text.lower())
    return re.sub(r"\s+", "-", text.strip())


def _strip_fences(text: str) -> str:
    """Return text with fenced code blocks replaced by blank lines."""
    return _FENCE_RE.sub(lambda m: "\n" * m.group().count("\n"), text)


def generate_toc(text: str, min_level: int = 1, max_level: int = 6) -> Toc:
    """Parse markdown headings and return a Toc object."""
    safe = _strip_fences(text)
    entries: List[TocEntry] = []
    seen_anchors: dict = {}

    for lineno, line in enumerate(safe.splitlines(), start=1):
        m = re.match(r"^(#{1,6})\s+(.+)$", line)
        if not m:
            continue
        level = len(m.group(1))
        if not (min_level <= level <= max_level):
            continue
        raw_text = m.group(2).strip()
        # strip inline markdown from heading text
        display = re.sub(r"[*_`~]", "", raw_text)
        display = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", display)
        anchor_base = _slug(display)
        # deduplicate anchors
        if anchor_base in seen_anchors:
            seen_anchors[anchor_base] += 1
            anchor = f"{anchor_base}-{seen_anchors[anchor_base]}"
        else:
            seen_anchors[anchor_base] = 0
            anchor = anchor_base

        entries.append(TocEntry(level=level, text=display, anchor=anchor, line_no=lineno))

    return Toc(entries=entries)


def inject_toc(text: str, toc: Optional[Toc] = None, min_headings: int = 3) -> str:
    """Insert or update the TOC in *text*.

    If *toc* is None it is generated from *text*.
    Replaces ``<!-- toc -->`` with the generated TOC.
    Also replaces any existing ``<!-- toc-generated -->…<!-- /toc-generated -->`` block.
    """
    if toc is None:
        toc = generate_toc(text)

    if len(toc.entries) < min_headings:
        return text  # not enough headings — don't clutter

    toc_md = toc.to_markdown()

    # Replace existing generated block first
    text = _TOC_BLOCK.sub(toc_md, text)

    # Then replace marker if still present
    if _TOC_MARKER in text and toc_md not in text:
        text = text.replace(_TOC_MARKER, toc_md, 1)

    return text


def has_toc(text: str) -> bool:
    return _TOC_MARKER in text or bool(_TOC_BLOCK.search(text))


def needs_toc(text: str, threshold: int = 4) -> bool:
    """Return True if note is long enough to benefit from a TOC."""
    toc = generate_toc(text)
    return len(toc.entries) >= threshold and not has_toc(text)


# ---------------------------------------------------------------------------
# Vault-level report

@dataclass
class TocReportEntry:
    note_id: str
    heading_count: int
    has_toc: bool
    needs_toc: bool


def vault_toc_report(store: Any, threshold: int = 4) -> List[TocReportEntry]:
    """Return a list of notes that could benefit from a TOC."""
    results: List[TocReportEntry] = []
    for note in store.notes():
        try:
            text = note.path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue
        toc = generate_toc(text)
        ht = has_toc(text)
        nt = len(toc.entries) >= threshold and not ht
        results.append(
            TocReportEntry(
                note_id=note.id,
                heading_count=len(toc.entries),
                has_toc=ht,
                needs_toc=nt,
            )
        )
    return results


# ---------------------------------------------------------------------------
# Pipeline processor

class TocProcessor(Processor):
    """Pipeline processor: inject a TOC into notes that need one."""

    name = "toc"
    optional = True

    def __init__(self, min_headings: int = 3, auto_inject: bool = False) -> None:
        self.min_headings = min_headings
        self.auto_inject  = auto_inject

    def process(self, ctx: PipelineContext) -> PipelineContext:
        toc = generate_toc(ctx.text)
        ctx.set("toc", toc)
        ctx.metadata["heading_count"] = len(toc.entries)
        ctx.metadata["has_toc"]       = has_toc(ctx.text)

        if self.auto_inject and needs_toc(ctx.text, self.min_headings):
            # Find first heading and insert TOC before it
            m = re.search(r"^#{1,6}\s+", ctx.text, re.MULTILINE)
            if m:
                pos = m.start()
                ctx.text = ctx.text[:pos] + _TOC_MARKER + "\n\n" + ctx.text[pos:]
                ctx.text = inject_toc(ctx.text, toc, self.min_headings)

        return ctx


# ---------------------------------------------------------------------------
# Plugin registration

def register(cli: Any) -> None:
    """Register the ``nota toc`` command."""
    import click

    @cli.command("toc")
    @click.argument("note_id")
    @click.option("--inject/--no-inject", default=False, help="Write TOC back to note file.")
    @click.option("--html", "fmt_html", is_flag=True, default=False, help="Output as HTML.")
    @click.pass_context
    def toc_cmd(ctx_obj: click.Context, note_id: str, inject: bool, fmt_html: bool) -> None:
        """Show or inject table of contents for a note."""
        from nota.core.store import Store

        vault_path = ctx_obj.obj["vault"]
        store = Store(vault_path)
        note = store.get_note(note_id)
        if note is None:
            click.echo(f"Note not found: {note_id}", err=True)
            raise SystemExit(1)

        text = note.path.read_text(encoding="utf-8", errors="replace")
        toc = generate_toc(text)

        if not toc.entries:
            click.echo("No headings found in this note.")
            return

        if fmt_html:
            click.echo(toc.to_html())
        elif inject:
            new_text = inject_toc(text, toc)
            note.path.write_text(new_text, encoding="utf-8")
            click.echo(f"TOC injected into {note.path.name} ({len(toc.entries)} entries).")
        else:
            click.echo(toc.to_markdown())
