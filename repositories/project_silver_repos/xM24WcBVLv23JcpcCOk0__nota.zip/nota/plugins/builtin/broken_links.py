"""Built-in plugin: detect broken wiki-links in a vault.

Reports links that point to notes which do not exist in the store.
Can be used as a standalone checker or as a pipeline processor.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Set

from nota.core.pipeline import Processor, PipelineContext


# ---------------------------------------------------------------------------
# Data types

@dataclass
class BrokenLink:
    source_id: str
    target: str
    source_path: Optional[Path] = None

    def __str__(self) -> str:
        return f"{self.source_id} → [[{self.target}]]"


@dataclass
class BrokenLinkReport:
    broken: List[BrokenLink] = field(default_factory=list)
    checked: int = 0

    @property
    def count(self) -> int:
        return len(self.broken)

    def summary(self) -> str:
        if not self.broken:
            return f"No broken links found ({self.checked} notes checked)."
        lines = [f"{self.count} broken link(s) found in {self.checked} notes:\n"]
        for bl in self.broken:
            lines.append(f"  {bl}")
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Vault-level checker

_WIKI_RE = re.compile(r"\[\[([^\]|]+)(?:\|[^\]]+)?\]\]")


def check_broken_links(store: "Any") -> BrokenLinkReport:  # type: ignore[name-defined]
    """Scan every note in *store* for unresolved [[wiki links]].

    Returns a BrokenLinkReport listing all broken links found.
    """
    # Build set of known IDs (stems)
    known_ids: Set[str] = set()
    notes = list(store.notes())
    for note in notes:
        known_ids.add(note.id)
        known_ids.add(note.path.stem)

    report = BrokenLinkReport(checked=len(notes))

    for note in notes:
        try:
            text = note.raw_text
        except Exception:
            try:
                text = note.path.read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue

        for m in _WIKI_RE.finditer(text):
            target = m.group(1).strip()
            slug = re.sub(r"\s+", "-", target.lower())
            # Check by slug, original casing, or direct stem match
            if (
                slug not in known_ids
                and target.lower() not in {k.lower() for k in known_ids}
                and target not in known_ids
            ):
                report.broken.append(
                    BrokenLink(
                        source_id=note.id,
                        target=target,
                        source_path=note.path,
                    )
                )

    return report


# ---------------------------------------------------------------------------
# Pipeline processor

class BrokenLinkDetector(Processor):
    """Pipeline processor: records unresolved [[wiki links]] to ctx.warnings."""

    name = "broken-link-detector"
    optional = True

    def __init__(self, known_ids: Optional[Set[str]] = None) -> None:
        self.known_ids: Set[str] = known_ids or set()

    def process(self, ctx: PipelineContext) -> PipelineContext:
        for m in _WIKI_RE.finditer(ctx.text):
            target = m.group(1).strip()
            slug = re.sub(r"\s+", "-", target.lower())
            if (
                self.known_ids
                and slug not in self.known_ids
                and target.lower() not in {k.lower() for k in self.known_ids}
            ):
                ctx.warn(f"Broken link: [[{target}]]")
        return ctx


# ---------------------------------------------------------------------------
# Click command (plugin registration)

def register(cli: "Any") -> None:  # type: ignore[name-defined]
    """Register the ``nota broken-links`` command."""
    import click
    from nota.core.store import Store

    @cli.command("broken-links")
    @click.pass_context
    def broken_links_cmd(ctx_obj: click.Context) -> None:
        """List all broken wiki-links in the vault."""
        vault_path = ctx_obj.obj["vault"]
        store = Store(vault_path)
        store.index_all()
        report = check_broken_links(store)
        click.echo(report.summary())
        if report.broken:
            raise SystemExit(1)
