"""Built-in plugin: per-note and vault-wide word statistics.

Provides:
  - WordStatsProcessor  — pipeline processor adding word stats to metadata
  - vault_word_stats()  — compute stats across the entire vault
  - top_words()         — term-frequency analysis (excluding stop words)
  - readability_score() — Flesch Reading Ease approximation
"""
from __future__ import annotations

import math
import re
import string
from collections import Counter
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set, Tuple

from nota.core.pipeline import Processor, PipelineContext


# ---------------------------------------------------------------------------
# Constants

_STOP_WORDS: Set[str] = {
    "a", "an", "the", "and", "or", "but", "in", "on", "at", "to", "for",
    "of", "with", "by", "from", "as", "is", "was", "are", "were", "be",
    "been", "being", "have", "has", "had", "do", "does", "did", "will",
    "would", "could", "should", "may", "might", "shall", "can", "need",
    "dare", "ought", "used", "it", "its", "this", "that", "these", "those",
    "i", "me", "my", "we", "our", "you", "your", "he", "she", "they",
    "them", "their", "what", "which", "who", "whom", "not", "no", "nor",
    "so", "yet", "both", "either", "neither", "just", "also", "about",
}


# ---------------------------------------------------------------------------
# Data types

@dataclass
class NoteWordStats:
    note_id: str
    word_count: int
    char_count: int
    sentence_count: int
    avg_word_length: float
    avg_sentence_length: float
    readability: float
    top_words: List[Tuple[str, int]]
    reading_time_min: int


@dataclass
class VaultWordStats:
    total_notes: int
    total_words: int
    total_chars: int
    avg_words_per_note: float
    median_words: float
    longest_note_id: str
    longest_note_words: int
    shortest_note_id: str
    shortest_note_words: int
    top_words: List[Tuple[str, int]]
    readability_avg: float
    notes: List[NoteWordStats] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Core functions

def _clean_text(text: str) -> str:
    """Strip markdown syntax, returning plain prose."""
    text = re.sub(r"^---.*?---\s*", "", text, flags=re.DOTALL)
    text = re.sub(r"```.*?```", "", text, flags=re.DOTALL)
    text = re.sub(r"`[^`]+`", "", text)
    text = re.sub(r"#{1,6}\s+", "", text)
    text = re.sub(r"\[\[([^\]|]+)(?:\|([^\]]+))?\]\]", lambda m: m.group(2) or m.group(1), text)
    text = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", text)
    text = re.sub(r"!\[.*?\]\(.*?\)", "", text)
    text = re.sub(r"[*_~]", "", text)
    text = re.sub(r"<[^>]+>", "", text)
    return text


def word_count(text: str) -> int:
    return len(_clean_text(text).split())


def sentence_count(text: str) -> int:
    clean = _clean_text(text)
    sentences = re.split(r"[.!?]+", clean)
    return max(1, sum(1 for s in sentences if s.strip()))


def avg_word_length(text: str) -> float:
    words = _clean_text(text).split()
    if not words:
        return 0.0
    total = sum(len(w.strip(string.punctuation)) for w in words)
    return total / len(words)


def readability_score(text: str) -> float:
    """Approximate Flesch Reading Ease (0–100, higher = easier)."""
    clean = _clean_text(text)
    words = clean.split()
    if not words:
        return 0.0
    sents = sentence_count(clean)
    syllables = sum(_syllable_count(w) for w in words)
    score = 206.835 - 1.015 * (len(words) / sents) - 84.6 * (syllables / len(words))
    return round(max(0.0, min(100.0, score)), 1)


def _syllable_count(word: str) -> int:
    """Rough syllable count via vowel group heuristic."""
    word = word.lower().strip(string.punctuation)
    if not word:
        return 0
    vowels = re.findall(r"[aeiouy]+", word)
    count = len(vowels)
    if word.endswith("e") and count > 1:
        count -= 1
    return max(1, count)


def top_words(text: str, n: int = 20, exclude_stop: bool = True) -> List[Tuple[str, int]]:
    """Return the *n* most frequent words in *text*."""
    clean = _clean_text(text).lower()
    tokens = re.findall(r"\b\w+\b", clean)
    if exclude_stop:
        tokens = [t for t in tokens if t not in _STOP_WORDS and len(t) > 2]
    freq: Counter[str] = Counter(tokens)
    return freq.most_common(n)


def note_stats(note_id: str, text: str) -> NoteWordStats:
    clean = _clean_text(text)
    words = clean.split()
    wc = len(words)
    cc = len(text)
    sc = sentence_count(clean)
    awl = avg_word_length(clean)
    asl = wc / max(1, sc)
    rd = readability_score(clean)
    tw = top_words(clean, n=10)
    rt = max(1, round(wc / 200))
    return NoteWordStats(
        note_id=note_id,
        word_count=wc,
        char_count=cc,
        sentence_count=sc,
        avg_word_length=round(awl, 2),
        avg_sentence_length=round(asl, 1),
        readability=rd,
        top_words=tw,
        reading_time_min=rt,
    )


def vault_word_stats(store: Any) -> VaultWordStats:
    """Compute word statistics across all notes in *store*."""
    note_list = list(store.notes())
    if not note_list:
        return VaultWordStats(
            total_notes=0, total_words=0, total_chars=0,
            avg_words_per_note=0.0, median_words=0.0,
            longest_note_id="", longest_note_words=0,
            shortest_note_id="", shortest_note_words=0,
            top_words=[], readability_avg=0.0,
        )

    note_stats_list: List[NoteWordStats] = []
    all_text = ""
    for note in note_list:
        try:
            text = note.path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            text = ""
        ns = note_stats(note.id, text)
        note_stats_list.append(ns)
        all_text += " " + _clean_text(text)

    word_counts = sorted(ns.word_count for ns in note_stats_list)
    n = len(word_counts)
    median = word_counts[n // 2] if n % 2 else (word_counts[n // 2 - 1] + word_counts[n // 2]) / 2

    longest = max(note_stats_list, key=lambda x: x.word_count)
    shortest = min(note_stats_list, key=lambda x: x.word_count)
    total_words = sum(ns.word_count for ns in note_stats_list)
    rd_avg = sum(ns.readability for ns in note_stats_list) / n

    return VaultWordStats(
        total_notes=n,
        total_words=total_words,
        total_chars=sum(ns.char_count for ns in note_stats_list),
        avg_words_per_note=round(total_words / n, 1),
        median_words=median,
        longest_note_id=longest.note_id,
        longest_note_words=longest.word_count,
        shortest_note_id=shortest.note_id,
        shortest_note_words=shortest.word_count,
        top_words=top_words(all_text, n=30),
        readability_avg=round(rd_avg, 1),
        notes=note_stats_list,
    )


# ---------------------------------------------------------------------------
# Pipeline processor

class WordStatsProcessor(Processor):
    """Pipeline processor: annotate ctx.metadata with word statistics."""

    name = "word-stats"
    optional = True

    def process(self, ctx: PipelineContext) -> PipelineContext:
        clean = _clean_text(ctx.text)
        words = clean.split()
        wc = len(words)
        ctx.metadata["word_count"]      = wc
        ctx.metadata["char_count"]      = len(ctx.text)
        ctx.metadata["sentence_count"]  = sentence_count(clean)
        ctx.metadata["readability"]     = readability_score(clean)
        ctx.metadata["reading_time_min"] = max(1, round(wc / 200))
        ctx.metadata["avg_word_length"] = round(avg_word_length(clean), 2)
        return ctx


# ---------------------------------------------------------------------------
# Plugin registration

def register(cli: Any) -> None:
    """Register the ``nota word-stats`` command."""
    import click

    @cli.command("word-stats")
    @click.argument("note_id", required=False)
    @click.option("--top", default=20, show_default=True, help="Number of top words to show.")
    @click.pass_context
    def word_stats_cmd(ctx_obj: click.Context, note_id: Optional[str], top: int) -> None:
        """Show word statistics for a note or the entire vault."""
        from nota.core.store import Store
        vault_path = ctx_obj.obj["vault"]
        store = Store(vault_path)

        if note_id:
            note = store.get_note(note_id)
            if note is None:
                click.echo(f"Note not found: {note_id}", err=True)
                raise SystemExit(1)
            text = note.path.read_text(encoding="utf-8", errors="replace")
            ns = note_stats(note.id, text)
            click.echo(f"Note     : {ns.note_id}")
            click.echo(f"Words    : {ns.word_count}")
            click.echo(f"Chars    : {ns.char_count}")
            click.echo(f"Sentences: {ns.sentence_count}")
            click.echo(f"Avg word len : {ns.avg_word_length}")
            click.echo(f"Avg sent len : {ns.avg_sentence_length}")
            click.echo(f"Readability  : {ns.readability}")
            click.echo(f"Reading time : {ns.reading_time_min} min")
            click.echo(f"\nTop {top} words:")
            for word, count in top_words(text, n=top):
                click.echo(f"  {word:20s} {count}")
        else:
            store.index_all()
            vs = vault_word_stats(store)
            click.echo(f"Notes         : {vs.total_notes}")
            click.echo(f"Total words   : {vs.total_words}")
            click.echo(f"Avg per note  : {vs.avg_words_per_note}")
            click.echo(f"Median        : {vs.median_words}")
            click.echo(f"Readability   : {vs.readability_avg}")
            click.echo(f"Longest       : {vs.longest_note_id} ({vs.longest_note_words} words)")
            click.echo(f"Shortest      : {vs.shortest_note_id} ({vs.shortest_note_words} words)")
            click.echo(f"\nTop {top} vault words:")
            for word, count in vs.top_words[:top]:
                click.echo(f"  {word:20s} {count}")
