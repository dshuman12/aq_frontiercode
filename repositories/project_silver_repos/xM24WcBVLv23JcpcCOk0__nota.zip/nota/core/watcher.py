from __future__ import annotations

import time
from pathlib import Path
from typing import Callable, Optional

from watchdog.events import FileSystemEvent, FileSystemEventHandler
from watchdog.observers import Observer

from .note import Note
from .store import Store


class _VaultHandler(FileSystemEventHandler):
    def __init__(self, store: Store, on_change: Optional[Callable[[str], None]]) -> None:
        self._store = store
        self._on_change = on_change
        self._pending: set[str] = set()

    def _handle(self, path_str: str) -> None:
        path = Path(path_str)
        if path.suffix != ".md":
            return
        if any(part.startswith(".") for part in path.parts):
            return
        try:
            note = Note(path, self._store.vault_root)
            self._store.index_note(note)
            self._store.conn.commit()
            if self._on_change:
                self._on_change(path_str)
        except Exception:
            pass

    def on_created(self, event: FileSystemEvent) -> None:
        if not event.is_directory:
            self._handle(str(event.src_path))

    def on_modified(self, event: FileSystemEvent) -> None:
        if not event.is_directory:
            self._handle(str(event.src_path))

    def on_deleted(self, event: FileSystemEvent) -> None:
        path = Path(str(event.src_path))
        if path.suffix != ".md":
            return
        try:
            note_id = path.relative_to(self._store.vault_root).as_posix()
            self._store.conn.execute("DELETE FROM notes WHERE id=?", (note_id,))
            self._store.conn.execute("DELETE FROM fts WHERE id=?", (note_id,))
            self._store.conn.commit()
            if self._on_change:
                self._on_change(str(event.src_path))
        except Exception:
            pass

    def on_moved(self, event: FileSystemEvent) -> None:
        self.on_deleted(type("E", (), {"src_path": event.src_path, "is_directory": False})())
        self.on_created(type("E", (), {"src_path": event.dest_path, "is_directory": False})())


class Watcher:
    """Watches a vault directory and keeps the index up to date."""

    def __init__(
        self,
        store: Store,
        on_change: Optional[Callable[[str], None]] = None,
    ) -> None:
        self._store = store
        self._on_change = on_change
        self._observer: Optional[Observer] = None

    def start(self) -> None:
        handler = _VaultHandler(self._store, self._on_change)
        self._observer = Observer()
        self._observer.schedule(handler, str(self._store.vault_root), recursive=True)
        self._observer.start()

    def stop(self) -> None:
        if self._observer:
            self._observer.stop()
            self._observer.join()
            self._observer = None

    def run_forever(self) -> None:
        self.start()
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            pass
        finally:
            self.stop()
