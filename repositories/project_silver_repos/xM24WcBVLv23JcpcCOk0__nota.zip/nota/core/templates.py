"""Note template system for nota.

Templates are Jinja2 (or plain-string) note skeletons stored in:
  <vault>/.nota/templates/
  <user_config_dir>/nota/templates/

A template may include front-matter defaults, placeholder variables,
and conditional sections.  The user creates a new note with:

    nota new --template daily

and nota renders the template, substituting built-in variables:
  {{ title }}   — the note title
  {{ date }}    — today's date (formatted per config)
  {{ time }}    — current time HH:MM
  {{ datetime }}— ISO-8601 datetime
  {{ year }}    — four-digit year
  {{ month }}   — two-digit month
  {{ day }}     — two-digit day
  {{ author }}  — from config (git user or platform login)
  {{ vault }}   — vault directory name
  {{ id }}      — slug-ified title

Custom variables can be passed via --var key=value flags.
"""
from __future__ import annotations

import os
import platform
import re
import string
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional, Tuple

try:
    from jinja2 import Environment, BaseLoader, TemplateNotFound, StrictUndefined
    _HAS_JINJA = True
except ImportError:  # pragma: no cover
    _HAS_JINJA = False


# ---------------------------------------------------------------------------
# Built-in variable providers

def _built_in_vars(title: str, vault_path: Path) -> Dict[str, str]:
    now = datetime.now()
    slug = re.sub(r"\s+", "-", re.sub(r"[^\w\s-]", "", title.lower()).strip())
    try:
        author = os.environ.get("GIT_AUTHOR_NAME") or platform.node()
    except Exception:
        author = "unknown"
    return {
        "title":    title,
        "date":     now.strftime("%Y-%m-%d"),
        "time":     now.strftime("%H:%M"),
        "datetime": now.isoformat(timespec="seconds"),
        "year":     now.strftime("%Y"),
        "month":    now.strftime("%m"),
        "day":      now.strftime("%d"),
        "author":   author,
        "vault":    vault_path.name,
        "id":       slug,
        "iso_week": now.strftime("%V"),
        "weekday":  now.strftime("%A"),
    }


# ---------------------------------------------------------------------------
# Template loader

class VaultTemplateLoader:
    """Resolve template names to file paths across multiple search dirs."""

    EXTENSIONS = (".md", ".md.j2", ".jinja2", ".txt")

    def __init__(self, search_dirs: List[Path]) -> None:
        self.search_dirs = [Path(d) for d in search_dirs if Path(d).is_dir()]

    def resolve(self, name: str) -> Optional[Path]:
        for d in self.search_dirs:
            for ext in self.EXTENSIONS:
                candidate = d / (name + ext)
                if candidate.is_file():
                    return candidate
                # also try without extension if name already has one
                bare = d / name
                if bare.is_file():
                    return bare
        return None

    def list_templates(self) -> List[str]:
        names: List[str] = []
        seen: set = set()
        for d in self.search_dirs:
            if not d.is_dir():
                continue
            for p in sorted(d.iterdir()):
                if p.is_file() and p.suffix in self.EXTENSIONS:
                    stem = p.name
                    for ext in self.EXTENSIONS:
                        if stem.endswith(ext):
                            stem = stem[: -len(ext)]
                            break
                    if stem not in seen:
                        seen.add(stem)
                        names.append(stem)
        return names


# ---------------------------------------------------------------------------
# Renderer

class TemplateRenderer:
    """Render a template string with variable substitution.

    Supports both Jinja2 (if installed) and stdlib string.Template as fallback.
    """

    def __init__(self, use_jinja: bool = True) -> None:
        self._use_jinja = use_jinja and _HAS_JINJA
        if self._use_jinja:
            self._env = Environment(
                loader=BaseLoader(),
                undefined=StrictUndefined,
                keep_trailing_newline=True,
            )

    def render(self, template_text: str, variables: Dict[str, Any]) -> str:
        if self._use_jinja:
            try:
                tmpl = self._env.from_string(template_text)
                return tmpl.render(**variables)
            except Exception as exc:
                # Fall back to stdlib on Jinja error
                pass
        return self._stdlib_render(template_text, variables)

    @staticmethod
    def _stdlib_render(template_text: str, variables: Dict[str, Any]) -> str:
        """Simple {{ key }} substitution without Jinja."""
        def _sub(m: re.Match) -> str:
            key = m.group(1).strip()
            return str(variables.get(key, m.group(0)))
        return re.sub(r"\{\{([^}]+)\}\}", _sub, template_text)


# ---------------------------------------------------------------------------
# Template manager

class TemplateManager:
    """High-level API: discover, render, and save templates."""

    DEFAULT_TEMPLATES: Dict[str, str] = {
        "default": """\
---
title: {{ title }}
created: {{ date }}
tags: []
---
# {{ title }}

""",
        "daily": """\
---
title: {{ date }}
created: {{ datetime }}
tags: [daily]
---
# {{ date }}

## Tasks
- [ ]

## Notes

## Links

""",
        "meeting": """\
---
title: {{ title }}
created: {{ datetime }}
tags: [meeting]
attendees: []
---
# {{ title }}

**Date:** {{ date }}
**Time:** {{ time }}

## Agenda

## Notes

## Action Items
- [ ]

""",
        "project": """\
---
title: {{ title }}
created: {{ date }}
tags: [project]
status: active
---
# {{ title }}

## Goal

## Milestones

## Notes

## References

""",
        "zettel": """\
---
title: {{ title }}
created: {{ datetime }}
id: {{ id }}
tags: []
type: permanent
---
# {{ title }}

## Idea

## Evidence

## Links

""",
        "weekly": """\
---
title: Week {{ iso_week }} – {{ year }}
created: {{ date }}
tags: [weekly]
---
# Week {{ iso_week }} – {{ year }}

## Highlights

## Completed

## In Progress

## Next Week

## Notes

""",
    }

    def __init__(
        self,
        vault_path: Path,
        extra_dirs: Optional[List[Path]] = None,
    ) -> None:
        self.vault_path = Path(vault_path)
        template_dir = self.vault_path / ".nota" / "templates"
        search_dirs  = [template_dir] + list(extra_dirs or [])
        self.loader   = VaultTemplateLoader(search_dirs)
        self.renderer = TemplateRenderer()

    def render(
        self,
        template_name: str,
        title: str,
        extra_vars: Optional[Dict[str, Any]] = None,
    ) -> str:
        """Render *template_name* with *title* and optional extra variables."""
        tmpl_text = self._load_template(template_name)
        variables = _built_in_vars(title, self.vault_path)
        if extra_vars:
            variables.update(extra_vars)
        return self.renderer.render(tmpl_text, variables)

    def list_templates(self) -> List[str]:
        """Return names of all available templates (built-in + user-defined)."""
        user = self.loader.list_templates()
        built_in = list(self.DEFAULT_TEMPLATES.keys())
        # user-defined templates take precedence
        return sorted(set(built_in + user))

    def save_builtin(self, name: str) -> Path:
        """Write a built-in template to the vault templates directory."""
        if name not in self.DEFAULT_TEMPLATES:
            raise KeyError(f"No built-in template named {name!r}")
        template_dir = self.vault_path / ".nota" / "templates"
        template_dir.mkdir(parents=True, exist_ok=True)
        dest = template_dir / f"{name}.md"
        dest.write_text(self.DEFAULT_TEMPLATES[name], encoding="utf-8")
        return dest

    def save_all_builtins(self) -> List[Path]:
        return [self.save_builtin(n) for n in self.DEFAULT_TEMPLATES]

    # ------------------------------------------------------------------

    def _load_template(self, name: str) -> str:
        # 1. Look in vault templates directory
        p = self.loader.resolve(name)
        if p is not None:
            return p.read_text(encoding="utf-8")
        # 2. Built-in templates
        if name in self.DEFAULT_TEMPLATES:
            return self.DEFAULT_TEMPLATES[name]
        available = ", ".join(self.list_templates())
        raise KeyError(f"Template {name!r} not found. Available: {available}")

    def __repr__(self) -> str:
        return f"TemplateManager(vault={self.vault_path.name!r})"


# ---------------------------------------------------------------------------
# Parse extra vars from CLI (key=value strings)

def parse_extra_vars(pairs: List[str]) -> Dict[str, str]:
    """Parse ``['key=value', 'foo=bar']`` into a dict."""
    result: Dict[str, str] = {}
    for pair in pairs:
        if "=" not in pair:
            raise ValueError(f"Invalid variable specification: {pair!r} (expected key=value)")
        k, _, v = pair.partition("=")
        result[k.strip()] = v.strip()
    return result
