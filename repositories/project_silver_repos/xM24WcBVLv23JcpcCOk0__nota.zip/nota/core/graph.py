"""Knowledge graph algorithms for nota vaults.

Provides PageRank, betweenness centrality, connected components,
shortest-path search, and hub/authority detection over the note
link graph returned by Store.graph().
"""
from __future__ import annotations

import math
from collections import defaultdict, deque
from typing import Dict, Iterator, List, Optional, Set, Tuple


# ---------------------------------------------------------------------------
# Type aliases

AdjList = Dict[str, List[str]]       # source -> [targets]
Score   = Dict[str, float]            # note_id -> numeric score


# ---------------------------------------------------------------------------
# Basic traversal helpers

def reverse_graph(adj: AdjList) -> AdjList:
    """Return the transpose of *adj* (all edges reversed)."""
    rev: AdjList = defaultdict(list)
    for src, targets in adj.items():
        rev.setdefault(src, [])
        for tgt in targets:
            rev[tgt].append(src)
    return dict(rev)


def all_nodes(adj: AdjList) -> Set[str]:
    nodes: Set[str] = set(adj.keys())
    for targets in adj.values():
        nodes.update(targets)
    return nodes


def bfs(adj: AdjList, start: str) -> Dict[str, int]:
    """BFS from *start*. Returns {node: distance} for reachable nodes."""
    dist: Dict[str, int] = {start: 0}
    queue: deque[str] = deque([start])
    while queue:
        node = queue.popleft()
        for nb in adj.get(node, []):
            if nb not in dist:
                dist[nb] = dist[node] + 1
                queue.append(nb)
    return dist


def shortest_path(adj: AdjList, src: str, dst: str) -> Optional[List[str]]:
    """Return shortest path from *src* to *dst*, or None if unreachable."""
    if src == dst:
        return [src]
    prev: Dict[str, Optional[str]] = {src: None}
    queue: deque[str] = deque([src])
    while queue:
        node = queue.popleft()
        for nb in adj.get(node, []):
            if nb not in prev:
                prev[nb] = node
                if nb == dst:
                    # reconstruct
                    path = [dst]
                    cur: Optional[str] = dst
                    while cur != src:
                        cur = prev[cur]
                        path.append(cur)  # type: ignore[arg-type]
                    return list(reversed(path))
                queue.append(nb)
    return None


# ---------------------------------------------------------------------------
# Connected components (undirected view)

def connected_components(adj: AdjList) -> List[Set[str]]:
    """Weakly connected components treating links as undirected edges."""
    undirected: Dict[str, Set[str]] = defaultdict(set)
    for src, targets in adj.items():
        for tgt in targets:
            undirected[src].add(tgt)
            undirected[tgt].add(src)
        undirected[src]  # ensure key exists

    visited: Set[str] = set()
    components: List[Set[str]] = []

    for node in all_nodes(adj):
        if node in visited:
            continue
        comp: Set[str] = set()
        queue: deque[str] = deque([node])
        while queue:
            n = queue.popleft()
            if n in visited:
                continue
            visited.add(n)
            comp.add(n)
            for nb in undirected.get(n, set()):
                if nb not in visited:
                    queue.append(nb)
        components.append(comp)

    return sorted(components, key=len, reverse=True)


# ---------------------------------------------------------------------------
# PageRank

def pagerank(
    adj: AdjList,
    damping: float = 0.85,
    iterations: int = 50,
    tolerance: float = 1e-6,
) -> Score:
    """Compute PageRank over the note link graph.

    Args:
        adj: adjacency list from Store.graph()
        damping: teleportation probability (standard 0.85)
        iterations: maximum power-iteration steps
        tolerance: convergence threshold (L1 norm of rank delta)

    Returns:
        Dict mapping note_id -> PageRank score (values sum to 1.0)
    """
    nodes = list(all_nodes(adj))
    n = len(nodes)
    if n == 0:
        return {}

    node_idx = {node: i for i, node in enumerate(nodes)}
    out_degree = [len(adj.get(node, [])) for node in nodes]

    # sparse adjacency (column = who points to row)
    in_links: List[List[int]] = [[] for _ in range(n)]
    for src, targets in adj.items():
        si = node_idx.get(src)
        if si is None:
            continue
        for tgt in targets:
            ti = node_idx.get(tgt)
            if ti is not None:
                in_links[ti].append(si)

    rank = [1.0 / n] * n
    dangling_nodes = [i for i, d in enumerate(out_degree) if d == 0]

    for _ in range(iterations):
        dangling_sum = sum(rank[i] for i in dangling_nodes)
        new_rank = [(1.0 - damping) / n + damping * dangling_sum / n] * n
        for i in range(n):
            for j in in_links[i]:
                new_rank[i] += damping * rank[j] / out_degree[j]

        # check convergence
        delta = sum(abs(new_rank[i] - rank[i]) for i in range(n))
        rank = new_rank
        if delta < tolerance:
            break

    return {nodes[i]: rank[i] for i in range(n)}


# ---------------------------------------------------------------------------
# Betweenness centrality (Brandes algorithm, unweighted)

def betweenness_centrality(adj: AdjList, normalise: bool = True) -> Score:
    """Compute betweenness centrality for all nodes.

    Uses Brandes (2001) O(VE) algorithm on the directed graph.
    """
    nodes = list(all_nodes(adj))
    n = len(nodes)
    cb: Dict[str, float] = {v: 0.0 for v in nodes}

    for s in nodes:
        # BFS phase
        stack: List[str] = []
        pred: Dict[str, List[str]] = {v: [] for v in nodes}
        sigma: Dict[str, float] = {v: 0.0 for v in nodes}
        sigma[s] = 1.0
        dist: Dict[str, int] = {v: -1 for v in nodes}
        dist[s] = 0
        queue: deque[str] = deque([s])

        while queue:
            v = queue.popleft()
            stack.append(v)
            for w in adj.get(v, []):
                if dist[w] < 0:
                    queue.append(w)
                    dist[w] = dist[v] + 1
                if dist[w] == dist[v] + 1:
                    sigma[w] += sigma[v]
                    pred[w].append(v)

        # accumulation phase
        delta: Dict[str, float] = {v: 0.0 for v in nodes}
        while stack:
            w = stack.pop()
            for v in pred[w]:
                if sigma[w] > 0:
                    delta[v] += (sigma[v] / sigma[w]) * (1.0 + delta[w])
            if w != s:
                cb[w] += delta[w]

    if normalise and n > 2:
        scale = 1.0 / ((n - 1) * (n - 2))
        cb = {v: c * scale for v, c in cb.items()}

    return cb


# ---------------------------------------------------------------------------
# Hub and authority scores (HITS)

def hits(adj: AdjList, iterations: int = 30) -> Tuple[Score, Score]:
    """Compute HITS hub and authority scores.

    Returns:
        (hubs, authorities) — two dicts mapping note_id -> score
    """
    nodes = list(all_nodes(adj))
    if not nodes:
        return {}, {}

    hub: Dict[str, float] = {v: 1.0 for v in nodes}
    auth: Dict[str, float] = {v: 1.0 for v in nodes}
    rev = reverse_graph(adj)

    for _ in range(iterations):
        new_auth: Dict[str, float] = {}
        for v in nodes:
            new_auth[v] = sum(hub.get(u, 0.0) for u in rev.get(v, []))

        new_hub: Dict[str, float] = {}
        for v in nodes:
            new_hub[v] = sum(new_auth.get(u, 0.0) for u in adj.get(v, []))

        # normalise
        auth_norm = math.sqrt(sum(x ** 2 for x in new_auth.values())) or 1.0
        hub_norm  = math.sqrt(sum(x ** 2 for x in new_hub.values())) or 1.0
        auth = {v: new_auth[v] / auth_norm for v in nodes}
        hub  = {v: new_hub[v]  / hub_norm  for v in nodes}

    return hub, auth


# ---------------------------------------------------------------------------
# High-level summaries

def top_n(scores: Score, n: int = 10) -> List[Tuple[str, float]]:
    """Return the top *n* (node, score) pairs sorted descending."""
    return sorted(scores.items(), key=lambda x: -x[1])[:n]


def graph_summary(adj: AdjList) -> Dict[str, object]:
    """Return a dict of high-level graph metrics."""
    nodes = all_nodes(adj)
    n_nodes = len(nodes)
    n_edges = sum(len(v) for v in adj.values())
    components = connected_components(adj)

    avg_out = n_edges / n_nodes if n_nodes else 0.0
    density = n_edges / (n_nodes * (n_nodes - 1)) if n_nodes > 1 else 0.0

    pr = pagerank(adj)
    top_pr = top_n(pr, 5)

    return {
        "nodes": n_nodes,
        "edges": n_edges,
        "components": len(components),
        "largest_component": len(components[0]) if components else 0,
        "avg_out_degree": round(avg_out, 3),
        "density": round(density, 5),
        "top_pagerank": [(nid.split("/")[-1].replace(".md", ""), round(s, 4))
                         for nid, s in top_pr],
    }


def ego_graph(adj: AdjList, center: str, radius: int = 1) -> AdjList:
    """Return the subgraph within *radius* hops of *center*."""
    reachable: Set[str] = set()
    frontier = {center}
    for _ in range(radius):
        next_frontier: Set[str] = set()
        for node in frontier:
            for nb in adj.get(node, []):
                if nb not in reachable and nb != center:
                    next_frontier.add(nb)
        reachable.update(frontier)
        frontier = next_frontier
    reachable.update(frontier)

    return {src: [t for t in targets if t in reachable]
            for src, targets in adj.items()
            if src in reachable}
