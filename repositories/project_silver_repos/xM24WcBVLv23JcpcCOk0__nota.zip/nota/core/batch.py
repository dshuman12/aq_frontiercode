"""Batch operations over vault notes.

All mutating operations write changes directly to the markdown files
and return a list of affected note paths for the caller to re-index.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

import frontmatter

from .note import Note, iter_markdown
from .store import Store


# ---------------------------------------------------------------------------
# Internal helpers

def _load_post(path: Path) -> frontmatter.Post:
    try:
        return frontmatter.load(str(path))
    except Exception:
        return frontmatter.Post(path.read_text(encoding="utf-8", errors="replace"))


def _save_post(path: Path, post: frontmatter.Post) -> None:
    path.write_text(frontmatter.dumps(post), encoding="utf-8")


def _normalise_tag_list(raw: object) -> List[str]:
    if isinstance(raw, list):
        return [str(t) for t in raw]
    if isinstance(raw, str):
        return [t.strip() for t in raw.split(",") if t.strip()]
    return []


# ---------------------------------------------------------------------------
# Tag operations

def add_tag(note: Note, tag: str) -> bool:
    """Add *tag* to *note*'s frontmatter. Returns True if the file changed."""
    post = _load_post(note.path)
    tags = _normalise_tag_list(post.metadata.get("tags", []))
    if tag in tags:
        return False
    tags.append(tag)
    post.metadata["tags"] = tags
    _save_post(note.path, post)
    return True


def remove_tag(note: Note, tag: str) -> bool:
    """Remove *tag* from *note*'s frontmatter. Returns True if changed."""
    post = _load_post(note.path)
    tags = _normalise_tag_list(post.metadata.get("tags", []))
    if tag not in tags:
        return False
    tags.remove(tag)
    post.metadata["tags"] = tags
    _save_post(note.path, post)
    return True


def rename_tag(note: Note, old: str, new: str) -> bool:
    """Rename *old* tag to *new* in frontmatter and inline occurrences."""
    changed = False
    post = _load_post(note.path)

    # frontmatter
    tags = _normalise_tag_list(post.metadata.get("tags", []))
    if old in tags:
        tags[tags.index(old)] = new
        post.metadata["tags"] = tags
        changed = True

    # inline #tags
    original_content = post.content
    new_content = re.sub(
        r"(?<!\w)#" + re.escape(old) + r"(?!\w)",
        "#" + new,
        original_content,
    )
    if new_content != original_content:
        post.content = new_content
        changed = True

    if changed:
        _save_post(note.path, post)
    return changed


def batch_add_tag(store: Store, tag: str, predicate: Optional[Callable[[Note], bool]] = None) -> List[Path]:
    """Add *tag* to all notes matching *predicate* (default: all notes)."""
    affected: List[Path] = []
    for note in store.notes():
        if predicate and not predicate(note):
            continue
        if add_tag(note, tag):
            affected.append(note.path)
    return affected


def batch_remove_tag(store: Store, tag: str, predicate: Optional[Callable[[Note], bool]] = None) -> List[Path]:
    """Remove *tag* from all notes matching *predicate*."""
    affected: List[Path] = []
    for note in store.notes():
        if predicate and not predicate(note):
            continue
        if remove_tag(note, tag):
            affected.append(note.path)
    return affected


def batch_rename_tag(store: Store, old: str, new: str) -> List[Path]:
    """Rename *old* -> *new* across every note in the vault."""
    affected: List[Path] = []
    for note in store.notes():
        if rename_tag(note, old, new):
            affected.append(note.path)
    return affected


# ---------------------------------------------------------------------------
# Frontmatter field operations

def set_field(note: Note, key: str, value: object) -> None:
    """Set an arbitrary frontmatter *key* to *value*."""
    post = _load_post(note.path)
    post.metadata[key] = value
    _save_post(note.path, post)


def delete_field(note: Note, key: str) -> bool:
    """Remove a frontmatter *key*. Returns True if it existed."""
    post = _load_post(note.path)
    if key not in post.metadata:
        return False
    del post.metadata[key]
    _save_post(note.path, post)
    return True


def batch_set_field(
    store: Store,
    key: str,
    value: object,
    predicate: Optional[Callable[[Note], bool]] = None,
) -> List[Path]:
    """Set *key*=*value* on all notes matching *predicate*."""
    affected: List[Path] = []
    for note in store.notes():
        if predicate and not predicate(note):
            continue
        set_field(note, key, value)
        affected.append(note.path)
    return affected


# ---------------------------------------------------------------------------
# Rename / move

def rename_note(note: Note, new_title: str, *, update_links: bool = True, store: Optional[Store] = None) -> Path:
    """Rename *note* on disk and optionally update all inbound wiki-links.

    Returns the new path.
    """
    slug = new_title.lower().replace(" ", "-")
    slug = re.sub(r"[^\w-]", "", slug)[:80]
    new_path = note.path.parent / f"{slug}.md"

    if new_path.exists() and new_path != note.path:
        raise FileExistsError(f"Target already exists: {new_path}")

    # update frontmatter title
    post = _load_post(note.path)
    post.metadata["title"] = new_title
    _save_post(note.path, post)

    # rename the file
    note.path.rename(new_path)

    if update_links and store is not None:
        old_stem = note.stem
        new_stem = new_path.stem
        _rewrite_links_in_vault(store, old_stem, new_stem)

    return new_path


def move_note(note: Note, dest_dir: Path) -> Path:
    """Move *note* to *dest_dir* (which must exist or will be created)."""
    dest_dir.mkdir(parents=True, exist_ok=True)
    new_path = dest_dir / note.path.name
    if new_path.exists():
        raise FileExistsError(f"Target already exists: {new_path}")
    note.path.rename(new_path)
    return new_path


def _rewrite_links_in_vault(store: Store, old_stem: str, new_stem: str) -> int:
    """Replace [[old_stem]] references with [[new_stem]] across the vault."""
    pattern = re.compile(r"\[\[" + re.escape(old_stem) + r"([\]|#])")
    replacement = r"[[" + new_stem + r"\1"
    count = 0
    for md_path in iter_markdown(store.vault_root):
        text = md_path.read_text(encoding="utf-8", errors="replace")
        new_text, n = pattern.subn(replacement, text)
        if n > 0:
            md_path.write_text(new_text, encoding="utf-8")
            count += n
    return count


# ---------------------------------------------------------------------------
# Bulk content transforms

def batch_replace(store: Store, pattern: str, replacement: str, *, regex: bool = False) -> List[Tuple[Path, int]]:
    """Search-and-replace across all note bodies.

    Returns list of (path, match_count) for changed files.
    """
    if regex:
        compiled = re.compile(pattern)
    results: List[Tuple[Path, int]] = []
    for note in store.notes():
        text = note.path.read_text(encoding="utf-8", errors="replace")
        if regex:
            new_text, count = compiled.subn(replacement, text)
        else:
            count = text.count(pattern)
            new_text = text.replace(pattern, replacement)
        if count > 0:
            note.path.write_text(new_text, encoding="utf-8")
            results.append((note.path, count))
    return results


def deduplicate_tags(store: Store) -> List[Path]:
    """Remove duplicate tags (case-insensitive) from every note's frontmatter."""
    affected: List[Path] = []
    for note in store.notes():
        post = _load_post(note.path)
        raw = post.metadata.get("tags")
        if not raw:
            continue
        tags = _normalise_tag_list(raw)
        seen_lower: Dict[str, str] = {}
        deduped: List[str] = []
        for t in tags:
            key = t.lower()
            if key not in seen_lower:
                seen_lower[key] = t
                deduped.append(t)
        if len(deduped) != len(tags):
            post.metadata["tags"] = deduped
            _save_post(note.path, post)
            affected.append(note.path)
    return affected


# ---------------------------------------------------------------------------
# Statistics helpers

def tag_co_occurrence(store: Store) -> Dict[Tuple[str, str], int]:
    """Return a dict of {(tagA, tagB): count} for co-occurring tags."""
    counts: Dict[Tuple[str, str], int] = {}
    for note in store.notes():
        tags = sorted(set(note.tags))
        for i, a in enumerate(tags):
            for b in tags[i + 1:]:
                pair = (a, b)
                counts[pair] = counts.get(pair, 0) + 1
    return dict(sorted(counts.items(), key=lambda x: -x[1]))
