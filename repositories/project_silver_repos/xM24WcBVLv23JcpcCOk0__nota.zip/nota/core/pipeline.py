"""Note processing pipeline for nota.

A Pipeline is a sequence of Processors that transform or enrich a note's
raw text before it is indexed or exported.  Processors are composable,
individually testable, and run in registration order.

Built-in processors
--------------------
StripFrontmatter       — remove YAML front-matter before passing body downstream
NormalizeWhitespace    — collapse runs of blank lines; trim trailing spaces
InjectTitle            — prepend a # Heading if none exists in the body
ResolveWikiLinks       — expand [[Wiki Links]] to standard markdown links
RewriteHashtags        — convert #tag → ``tag`` with a configurable prefix
ExtractTasks           — collect [ ] / [x] task items into note.metadata
WordCountAnnotator     — set metadata["word_count"] from body
ReadingTimeAnnotator   — set metadata["reading_time_min"] (avg 200 wpm)
SlugifyLinks           — normalise all [[link]] targets to their slug form
SanitizeHTML           — strip unsafe raw-HTML elements in safe mode
LintHeadings           — warn when headings skip levels (h1→h3)
ExpandAbbreviations    — replace registered abbreviations inline
"""
from __future__ import annotations

import re
import textwrap
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple


# ---------------------------------------------------------------------------
# Context object passed through the pipeline

@dataclass
class PipelineContext:
    """Mutable context object threaded through every processor."""
    text: str                              # current note body (without front-matter)
    raw: str                               # original raw text (read-only reference)
    metadata: Dict[str, Any]               # frontmatter key-value store (mutable)
    path: Optional[Path] = None
    warnings: List[str] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    links: List[str] = field(default_factory=list)
    tasks: List[Dict[str, Any]] = field(default_factory=list)
    extra: Dict[str, Any] = field(default_factory=dict)  # arbitrary side-channel data

    def warn(self, msg: str) -> None:
        self.warnings.append(msg)

    def set(self, key: str, value: Any) -> None:
        self.extra[key] = value

    def get(self, key: str, default: Any = None) -> Any:
        return self.extra.get(key, default)


# ---------------------------------------------------------------------------
# Processor base

class Processor(ABC):
    """Base class for all pipeline processors."""

    #: Human-readable name for logging / debugging
    name: str = "unnamed"
    #: Whether this processor can be skipped safely
    optional: bool = False

    @abstractmethod
    def process(self, ctx: PipelineContext) -> PipelineContext:
        """Transform ctx in-place (or return a new one) and return it."""

    def __call__(self, ctx: PipelineContext) -> PipelineContext:
        return self.process(ctx)

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}()"


# ---------------------------------------------------------------------------
# Pipeline

class Pipeline:
    """Ordered list of Processors applied to a PipelineContext.

    Usage::

        pipe = Pipeline()
        pipe.add(StripFrontmatter())
        pipe.add(NormalizeWhitespace())
        pipe.add(WordCountAnnotator())

        ctx = PipelineContext(text=raw_text, raw=raw_text, metadata={})
        result = pipe.run(ctx)
        print(result.text, result.metadata)
    """

    def __init__(self, processors: Optional[List[Processor]] = None) -> None:
        self._processors: List[Processor] = list(processors or [])

    def add(self, processor: Processor) -> "Pipeline":
        self._processors.append(processor)
        return self

    def remove(self, name: str) -> bool:
        before = len(self._processors)
        self._processors = [p for p in self._processors if p.name != name]
        return len(self._processors) < before

    def run(self, ctx: PipelineContext) -> PipelineContext:
        for proc in self._processors:
            try:
                ctx = proc.process(ctx)
            except Exception as exc:
                ctx.warn(f"{proc.name} raised {type(exc).__name__}: {exc}")
                if not proc.optional:
                    raise
        return ctx

    def run_text(self, text: str, metadata: Optional[Dict[str, Any]] = None) -> PipelineContext:
        ctx = PipelineContext(text=text, raw=text, metadata=dict(metadata or {}))
        return self.run(ctx)

    def __len__(self) -> int:
        return len(self._processors)

    def __repr__(self) -> str:
        names = ", ".join(p.name for p in self._processors)
        return f"Pipeline([{names}])"


# ---------------------------------------------------------------------------
# Built-in processors

class StripFrontmatter(Processor):
    """Remove YAML front-matter (--- … ---) and populate ctx.metadata."""
    name = "strip-frontmatter"
    _RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n?", re.DOTALL)

    def process(self, ctx: PipelineContext) -> PipelineContext:
        m = self._RE.match(ctx.text)
        if m:
            raw_fm = m.group(1)
            ctx.text = ctx.text[m.end():]
            try:
                import yaml  # type: ignore
                ctx.metadata.update(yaml.safe_load(raw_fm) or {})
            except Exception:
                for line in raw_fm.splitlines():
                    if ":" in line:
                        k, _, v = line.partition(":")
                        ctx.metadata.setdefault(k.strip(), v.strip())
            ctx.tags = _ensure_list(ctx.metadata.get("tags", []))
        return ctx


class NormalizeWhitespace(Processor):
    """Collapse multiple blank lines to one; strip trailing spaces."""
    name = "normalize-whitespace"
    optional = True

    def process(self, ctx: PipelineContext) -> PipelineContext:
        lines = ctx.text.splitlines()
        cleaned: List[str] = []
        prev_blank = False
        for line in lines:
            line = line.rstrip()
            blank = not line
            if blank and prev_blank:
                continue
            cleaned.append(line)
            prev_blank = blank
        ctx.text = "\n".join(cleaned).strip()
        return ctx


class InjectTitle(Processor):
    """If the body has no H1 heading, prepend one from metadata['title']."""
    name = "inject-title"
    optional = True

    def process(self, ctx: PipelineContext) -> PipelineContext:
        title = ctx.metadata.get("title", "")
        has_h1 = bool(re.search(r"^#\s+", ctx.text, re.MULTILINE))
        if title and not has_h1:
            ctx.text = f"# {title}\n\n{ctx.text}"
        return ctx


class ResolveWikiLinks(Processor):
    """Expand [[Wiki Links]] to [label](/note/slug) markdown links."""
    name = "resolve-wiki-links"
    optional = True
    _RE = re.compile(r"\[\[([^\]|]+)(?:\|([^\]]+))?\]\]")

    def __init__(self, link_prefix: str = "/note/") -> None:
        self.link_prefix = link_prefix

    def process(self, ctx: PipelineContext) -> PipelineContext:
        links: List[str] = []

        def _sub(m: re.Match) -> str:
            target = m.group(1).strip()
            label  = (m.group(2) or target).strip()
            slug   = re.sub(r"\s+", "-", target.lower())
            links.append(slug)
            return f"[{label}]({self.link_prefix}{slug})"

        ctx.text = self._RE.sub(_sub, ctx.text)
        ctx.links.extend(links)
        return ctx


class RewriteHashtags(Processor):
    """Convert #tag → a clickable tag token."""
    name = "rewrite-hashtags"
    optional = True
    _RE = re.compile(r"(?<!\w)#([\w/-]+)")

    def __init__(self, tag_prefix: str = "/tags/") -> None:
        self.tag_prefix = tag_prefix

    def process(self, ctx: PipelineContext) -> PipelineContext:
        found: List[str] = []

        def _sub(m: re.Match) -> str:
            tag = m.group(1)
            found.append(tag)
            return f"[#{tag}]({self.tag_prefix}{tag})"

        ctx.text = self._RE.sub(_sub, ctx.text)
        for t in found:
            if t not in ctx.tags:
                ctx.tags.append(t)
        return ctx


class ExtractTasks(Processor):
    """Collect task list items into ctx.tasks."""
    name = "extract-tasks"
    optional = True
    _RE = re.compile(r"^(\s*)-\s+\[([ xX])\]\s+(.+)$", re.MULTILINE)

    def process(self, ctx: PipelineContext) -> PipelineContext:
        for m in self._RE.finditer(ctx.text):
            indent_level = len(m.group(1)) // 2
            done = m.group(2).lower() == "x"
            label = m.group(3).strip()
            ctx.tasks.append({"label": label, "done": done, "level": indent_level})
        return ctx


class WordCountAnnotator(Processor):
    """Set metadata['word_count'] from body text."""
    name = "word-count"
    optional = True

    def process(self, ctx: PipelineContext) -> PipelineContext:
        text = re.sub(r"[^\w\s]", " ", ctx.text)
        ctx.metadata["word_count"] = len(text.split())
        return ctx


class ReadingTimeAnnotator(Processor):
    """Set metadata['reading_time_min'] at 200 wpm."""
    name = "reading-time"
    optional = True
    WPM = 200

    def process(self, ctx: PipelineContext) -> PipelineContext:
        wc = ctx.metadata.get("word_count") or len(ctx.text.split())
        ctx.metadata["reading_time_min"] = max(1, round(wc / self.WPM))
        return ctx


class SlugifyLinks(Processor):
    """Normalise [[link]] targets to slug form."""
    name = "slugify-links"
    optional = True
    _RE = re.compile(r"\[\[([^\]|]+)(?:\|([^\]]+))?\]\]")

    @staticmethod
    def _slug(s: str) -> str:
        return re.sub(r"\s+", "-", s.strip().lower())

    def process(self, ctx: PipelineContext) -> PipelineContext:
        def _sub(m: re.Match) -> str:
            target = self._slug(m.group(1))
            label  = m.group(2) or m.group(1).strip()
            return f"[[{target}|{label}]]"
        ctx.text = self._RE.sub(_sub, ctx.text)
        return ctx


class SanitizeHTML(Processor):
    """Strip raw HTML from the text body (safe mode)."""
    name = "sanitize-html"
    optional = True
    _RE = re.compile(r"<[^>]+>")

    def process(self, ctx: PipelineContext) -> PipelineContext:
        ctx.text = self._RE.sub("", ctx.text)
        return ctx


class LintHeadings(Processor):
    """Warn when heading levels skip (e.g. # → ###)."""
    name = "lint-headings"
    optional = True
    _RE = re.compile(r"^(#{1,6})\s+", re.MULTILINE)

    def process(self, ctx: PipelineContext) -> PipelineContext:
        prev = 0
        for m in self._RE.finditer(ctx.text):
            level = len(m.group(1))
            if prev and level > prev + 1:
                ctx.warn(
                    f"Heading level skipped: h{prev} → h{level} near "
                    f"'{ctx.text[m.start():m.start()+30].strip()}'"
                )
            prev = level
        return ctx


class ExpandAbbreviations(Processor):
    """Replace registered abbreviations with their expansions."""
    name = "expand-abbreviations"
    optional = True

    def __init__(self, abbrevs: Dict[str, str]) -> None:
        self.abbrevs = abbrevs
        self._patterns = [
            (re.compile(r"\b" + re.escape(k) + r"\b"), v)
            for k, v in sorted(abbrevs.items(), key=lambda x: -len(x[0]))
        ]

    def process(self, ctx: PipelineContext) -> PipelineContext:
        for pat, replacement in self._patterns:
            ctx.text = pat.sub(replacement, ctx.text)
        return ctx


# ---------------------------------------------------------------------------
# Preset pipelines

def default_pipeline() -> Pipeline:
    """Standard pipeline suitable for indexing and search."""
    return (
        Pipeline()
        .add(StripFrontmatter())
        .add(NormalizeWhitespace())
        .add(ExtractTasks())
        .add(WordCountAnnotator())
        .add(ReadingTimeAnnotator())
        .add(SlugifyLinks())
        .add(LintHeadings())
    )


def export_pipeline(link_prefix: str = "/note/", tag_prefix: str = "/tags/") -> Pipeline:
    """Pipeline for rendering/exporting (resolves links, rewrites tags)."""
    return (
        Pipeline()
        .add(StripFrontmatter())
        .add(NormalizeWhitespace())
        .add(InjectTitle())
        .add(ResolveWikiLinks(link_prefix=link_prefix))
        .add(RewriteHashtags(tag_prefix=tag_prefix))
        .add(ExtractTasks())
        .add(WordCountAnnotator())
        .add(ReadingTimeAnnotator())
    )


def safe_pipeline() -> Pipeline:
    """Pipeline for user-submitted content (strips HTML)."""
    return (
        Pipeline()
        .add(StripFrontmatter())
        .add(SanitizeHTML())
        .add(NormalizeWhitespace())
        .add(WordCountAnnotator())
    )


# ---------------------------------------------------------------------------
# Helpers

def _ensure_list(value: Any) -> List[str]:
    if isinstance(value, list):
        return [str(v) for v in value]
    if isinstance(value, str):
        return [value] if value else []
    return []
