from __future__ import annotations

from typing import List, Optional, Tuple

from rapidfuzz import fuzz, process

from .note import Note
from .store import Store


def fuzzy_search(
    store: Store,
    query: str,
    limit: int = 10,
    score_cutoff: float = 40.0,
) -> List[Tuple[Note, float]]:
    """Fuzzy match *query* against note titles.

    Returns (note, score) pairs sorted by descending score.
    """
    notes = list(store.notes())
    titles = [n.title for n in notes]

    matches = process.extract(
        query,
        titles,
        scorer=fuzz.WRatio,
        limit=limit,
        score_cutoff=score_cutoff,
    )
    results: List[Tuple[Note, float]] = []
    for _title, score, idx in matches:
        results.append((notes[idx], score))
    return results


def ranked_search(
    store: Store,
    query: str,
    limit: int = 20,
) -> List[Note]:
    """Combine FTS5 and fuzzy title matching, deduplicated and ranked."""
    fts_results = store.search(query, limit=limit)
    fts_ids = {n.id for n in fts_results}

    fuzzy_results = [n for n, _score in fuzzy_search(store, query, limit=limit // 2)]
    fuzzy_new = [n for n in fuzzy_results if n.id not in fts_ids]

    combined = fts_results + fuzzy_new
    return combined[:limit]


class SemanticSearch:
    """Optional semantic search using sentence-transformers.

    Falls back gracefully when the optional dependency is not installed.
    """

    _model: Optional[object] = None
    _model_name: str = "all-MiniLM-L6-v2"

    def __init__(self, store: Store) -> None:
        self.store = store
        self._embeddings: Optional[object] = None

    def _ensure_model(self) -> bool:
        if self._model is not None:
            return True
        try:
            from sentence_transformers import SentenceTransformer  # type: ignore

            SemanticSearch._model = SentenceTransformer(self._model_name)
            return True
        except ImportError:
            return False

    def build_index(self) -> int:
        if not self._ensure_model():
            return 0
        import numpy as np  # type: ignore
        from sentence_transformers import SentenceTransformer  # type: ignore

        model: SentenceTransformer = self._model  # type: ignore
        notes = list(self.store.notes())
        texts = [f"{n.title}\n{n.content[:512]}" for n in notes]
        self._embeddings = model.encode(texts, show_progress_bar=False)
        self._notes_index = notes
        return len(notes)

    def query(self, text: str, top_k: int = 5) -> List[Tuple[Note, float]]:
        if self._embeddings is None:
            self.build_index()
        if self._embeddings is None or not self._ensure_model():
            return []
        import numpy as np  # type: ignore
        from sentence_transformers import SentenceTransformer  # type: ignore

        model: SentenceTransformer = self._model  # type: ignore
        q_emb = model.encode([text])[0]
        embs = self._embeddings  # type: ignore
        scores = np.dot(embs, q_emb) / (
            np.linalg.norm(embs, axis=1) * np.linalg.norm(q_emb) + 1e-9
        )
        top_idx = np.argsort(scores)[::-1][:top_k]
        return [(self._notes_index[i], float(scores[i])) for i in top_idx]
