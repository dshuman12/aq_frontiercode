"""Vault metrics and analytics for nota.

Provides aggregate statistics, trend analysis, and per-note scoring:
  - VaultMetrics      — snapshot of key vault health indicators
  - TrendWindow       — time-series bucketing for activity trends
  - NoteScore         — composite relevance / importance score
  - compute_metrics() — produce a full VaultMetrics snapshot
  - activity_trend()  — per-day/week/month note-creation/edit counts
  - top_notes()       — ranked by configurable scoring function
  - tag_cooccurrence()— find tags that appear together frequently
  - link_density()    — outbound-link count histogram
  - vocabulary_size() — unique word count across the vault
  - freshness_score() — how recently a note was modified (0–1)
"""
from __future__ import annotations

import math
import re
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any, Callable, Dict, Iterator, List, Optional, Tuple

from nota.core.note import Note


# ---------------------------------------------------------------------------
# Data classes

@dataclass
class VaultMetrics:
    """Snapshot of key vault health indicators."""
    note_count:       int
    word_count_total: int
    word_count_avg:   float
    word_count_median: float
    tag_count:        int
    link_count:       int
    orphan_count:     int
    duplicate_titles: int
    notes_without_tags: int
    avg_links_per_note: float
    longest_note_id:  str
    shortest_note_id: str
    top_tags:         List[Tuple[str, int]]
    top_linked_notes: List[Tuple[str, int]]
    stale_notes:      List[str]    # not modified in > 90 days
    generated_at:     str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "note_count":         self.note_count,
            "word_count_total":   self.word_count_total,
            "word_count_avg":     round(self.word_count_avg, 1),
            "word_count_median":  self.word_count_median,
            "tag_count":          self.tag_count,
            "link_count":         self.link_count,
            "orphan_count":       self.orphan_count,
            "duplicate_titles":   self.duplicate_titles,
            "notes_without_tags": self.notes_without_tags,
            "avg_links_per_note": round(self.avg_links_per_note, 2),
            "longest_note":       self.longest_note_id,
            "shortest_note":      self.shortest_note_id,
            "top_tags":           self.top_tags,
            "top_linked":         self.top_linked_notes,
            "stale_notes":        self.stale_notes[:10],
            "generated_at":       self.generated_at,
        }


@dataclass
class NoteScore:
    """Composite importance / relevance score for a note."""
    note_id:       str
    link_score:    float   # PageRank-like incoming link weight
    freshness:     float   # 0–1 based on recency of modification
    word_score:    float   # normalised word count
    tag_score:     float   # how many tags (normalised)
    total:         float   # weighted sum
    rank:          int = 0

    def to_dict(self) -> Dict[str, float]:
        return {
            "note_id":    self.note_id,
            "link":       round(self.link_score, 4),
            "freshness":  round(self.freshness, 4),
            "words":      round(self.word_score, 4),
            "tags":       round(self.tag_score, 4),
            "total":      round(self.total, 4),
            "rank":       self.rank,
        }


@dataclass
class TrendBucket:
    """A single time bucket in a trend series."""
    label: str           # e.g. "2025-06", "2025-W22"
    created: int = 0     # notes created in this period
    modified: int = 0    # notes modified
    words_added: int = 0


@dataclass
class TagCooccurrence:
    tag_a: str
    tag_b: str
    count: int

    def __str__(self) -> str:
        return f"#{self.tag_a} + #{self.tag_b}: {self.count}"


# ---------------------------------------------------------------------------
# Main compute function

def compute_metrics(store: Any, stale_days: int = 90) -> VaultMetrics:
    """Produce a full VaultMetrics snapshot from *store*."""
    notes: List[Note] = list(store.notes())
    if not notes:
        return VaultMetrics(
            note_count=0, word_count_total=0, word_count_avg=0.0,
            word_count_median=0.0, tag_count=0, link_count=0, orphan_count=0,
            duplicate_titles=0, notes_without_tags=0, avg_links_per_note=0.0,
            longest_note_id="", shortest_note_id="",
            top_tags=[], top_linked_notes=[], stale_notes=[],
            generated_at=datetime.now().isoformat(timespec="seconds"),
        )

    word_counts = [n.word_count for n in notes]
    sorted_wc   = sorted(word_counts)
    n           = len(notes)
    total_words = sum(word_counts)
    median_wc   = sorted_wc[n // 2] if n % 2 else (sorted_wc[n//2-1] + sorted_wc[n//2]) / 2

    tag_freq: Counter[str] = Counter()
    for note in notes:
        tag_freq.update(note.tags)

    link_freq: Counter[str] = Counter()
    total_links = 0
    for note in notes:
        lks = note.links
        total_links += len(lks)
        for lk in lks:
            link_freq[lk] += 1

    stale_cutoff = datetime.now() - timedelta(days=stale_days)
    stale: List[str] = []
    for note in notes:
        if note.modified and note.modified < stale_cutoff:
            stale.append(note.id)

    title_counts: Counter[str] = Counter(n.title.lower() for n in notes if n.title)
    dup_titles = sum(1 for _, c in title_counts.items() if c > 1)

    word_array = sorted(word_counts)
    longest  = notes[word_counts.index(max(word_counts))]
    shortest = notes[word_counts.index(min(word_counts))]

    try:
        orphan_ids = {n.id for n in store.orphans()} if hasattr(store, "orphans") else set()
    except Exception:
        orphan_ids = set()

    return VaultMetrics(
        note_count       = n,
        word_count_total = total_words,
        word_count_avg   = total_words / n,
        word_count_median= median_wc,
        tag_count        = len(tag_freq),
        link_count       = total_links,
        orphan_count     = len(orphan_ids),
        duplicate_titles = dup_titles,
        notes_without_tags = sum(1 for note in notes if not note.tags),
        avg_links_per_note = total_links / n,
        longest_note_id  = longest.id,
        shortest_note_id = shortest.id,
        top_tags         = tag_freq.most_common(20),
        top_linked_notes = link_freq.most_common(20),
        stale_notes      = stale,
        generated_at     = datetime.now().isoformat(timespec="seconds"),
    )


# ---------------------------------------------------------------------------
# Trend analysis

def activity_trend(
    notes: List[Note],
    period: str = "month",
    n_periods: int = 12,
) -> List[TrendBucket]:
    """Return per-period activity buckets (creation/modification counts).

    *period* is one of ``"day"``, ``"week"``, ``"month"``.
    """
    now = datetime.now()
    if period == "day":
        fmt = "%Y-%m-%d"
        delta = timedelta(days=1)
    elif period == "week":
        fmt = "%Y-W%W"
        delta = timedelta(weeks=1)
    else:  # month
        fmt = "%Y-%m"
        delta = timedelta(days=30)

    # Build label sequence (most recent first, then reverse)
    labels: List[str] = []
    current = now
    for _ in range(n_periods):
        labels.append(current.strftime(fmt))
        current -= delta
    labels.reverse()

    buckets: Dict[str, TrendBucket] = {label: TrendBucket(label=label) for label in labels}
    label_set = set(labels)

    for note in notes:
        if note.created:
            lbl = note.created.strftime(fmt)
            if lbl in buckets:
                buckets[lbl].created += 1
        if note.modified:
            lbl = note.modified.strftime(fmt)
            if lbl in buckets:
                buckets[lbl].modified += 1
                buckets[lbl].words_added += note.word_count

    return [buckets[l] for l in labels]


# ---------------------------------------------------------------------------
# Note scoring

def score_notes(
    notes: List[Note],
    backlink_counts: Optional[Dict[str, int]] = None,
    weights: Optional[Dict[str, float]] = None,
) -> List[NoteScore]:
    """Compute a composite score for each note in *notes*.

    Default weights: link=0.4, freshness=0.3, words=0.2, tags=0.1
    """
    if not notes:
        return []

    weights = weights or {"link": 0.4, "freshness": 0.3, "words": 0.2, "tags": 0.1}
    backlink_counts = backlink_counts or {}

    # Normalise word counts
    wc_max = max((n.word_count for n in notes), default=1) or 1
    # Normalise tag counts
    tc_max = max((len(n.tags) for n in notes), default=1) or 1
    # Normalise backlinks
    bl_max = max(backlink_counts.values(), default=1) or 1

    now = datetime.now()
    scores: List[NoteScore] = []

    for note in notes:
        # Freshness: exponential decay with 30-day half-life
        if note.modified:
            age_days = max(0, (now - note.modified).days)
        else:
            age_days = 365
        freshness = math.exp(-age_days / 30.0)

        link_score = backlink_counts.get(note.id, 0) / bl_max
        word_score = note.word_count / wc_max
        tag_score  = len(note.tags) / tc_max

        total = (
            weights.get("link",      0.4) * link_score
            + weights.get("freshness", 0.3) * freshness
            + weights.get("words",    0.2) * word_score
            + weights.get("tags",     0.1) * tag_score
        )

        scores.append(NoteScore(
            note_id    = note.id,
            link_score = link_score,
            freshness  = freshness,
            word_score = word_score,
            tag_score  = tag_score,
            total      = total,
        ))

    scores.sort(key=lambda s: -s.total)
    for i, s in enumerate(scores, start=1):
        s.rank = i

    return scores


def top_notes(
    notes: List[Note],
    n: int = 10,
    backlink_counts: Optional[Dict[str, int]] = None,
) -> List[NoteScore]:
    """Return the top *n* notes by composite score."""
    return score_notes(notes, backlink_counts)[:n]


# ---------------------------------------------------------------------------
# Tag co-occurrence

def tag_cooccurrence(notes: List[Note], min_count: int = 2) -> List[TagCooccurrence]:
    """Find pairs of tags that appear together in at least *min_count* notes."""
    pair_counts: Counter = Counter()
    for note in notes:
        tags = sorted(note.tags)
        for i in range(len(tags)):
            for j in range(i + 1, len(tags)):
                pair_counts[(tags[i], tags[j])] += 1

    result: List[TagCooccurrence] = [
        TagCooccurrence(tag_a=a, tag_b=b, count=c)
        for (a, b), c in pair_counts.most_common()
        if c >= min_count
    ]
    return result


# ---------------------------------------------------------------------------
# Link density

def link_density(notes: List[Note]) -> Dict[str, Any]:
    """Return a histogram of outbound link counts."""
    counts = [len(n.links) for n in notes]
    if not counts:
        return {"histogram": {}, "avg": 0.0, "max": 0, "notes_with_links": 0}
    hist: Counter[int] = Counter(counts)
    return {
        "histogram":       dict(sorted(hist.items())),
        "avg":             sum(counts) / len(counts),
        "max":             max(counts),
        "notes_with_links": sum(1 for c in counts if c > 0),
    }


# ---------------------------------------------------------------------------
# Vocabulary size

def vocabulary_size(notes: List[Note], min_freq: int = 1) -> int:
    """Count unique words across all notes (stop-words excluded)."""
    _STOP = {"a","an","the","and","or","but","in","on","at","to","for","of",
              "with","by","from","as","is","was","are","were","it","its"}
    vocab: set = set()
    for note in notes:
        try:
            text = note.content
        except Exception:
            continue
        words = re.findall(r"\b\w{3,}\b", text.lower())
        vocab.update(w for w in words if w not in _STOP)
    return len(vocab)


# ---------------------------------------------------------------------------
# Freshness score (single note)

def freshness_score(note: Note, half_life_days: float = 30.0) -> float:
    """Return a 0–1 freshness score based on last modification time."""
    if note.modified is None:
        return 0.0
    age = max(0, (datetime.now() - note.modified).days)
    return math.exp(-age / half_life_days)
