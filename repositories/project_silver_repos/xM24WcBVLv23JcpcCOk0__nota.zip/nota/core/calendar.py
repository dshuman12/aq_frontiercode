"""Calendar and activity heatmap for nota vaults."""
from __future__ import annotations

import calendar
from collections import defaultdict
from datetime import date, datetime, timedelta
from typing import Dict, List, Optional, Tuple

from .store import Store

# Unicode block chars from lightest to densest
_BLOCKS = " ░▒▓█"


def _clamp(value: int, lo: int, hi: int) -> int:
    return max(lo, min(hi, value))


# ---------------------------------------------------------------------------
# Data collection

def activity_by_day(
    store: Store,
    *,
    field: str = "modified",
    start: Optional[date] = None,
    end: Optional[date] = None,
) -> Dict[date, int]:
    """Count notes created or modified per calendar day.

    Args:
        field: ``'modified'`` (mtime) or ``'created'`` (frontmatter)
        start / end: inclusive date range filter
    """
    counts: Dict[date, int] = defaultdict(int)
    for note in store.notes():
        if field == "created" and note.created is not None:
            d = note.created.date()
        else:
            d = note.modified.date()

        if start and d < start:
            continue
        if end and d > end:
            continue
        counts[d] += 1

    return dict(counts)


def streak(activity: Dict[date, int]) -> Tuple[int, int]:
    """Return (current_streak_days, longest_streak_days)."""
    if not activity:
        return 0, 0

    sorted_dates = sorted(activity)
    today = date.today()

    # current streak — count backwards from today
    current = 0
    d = today
    while d in activity:
        current += 1
        d -= timedelta(days=1)

    # longest streak
    longest = 0
    run = 0
    prev: Optional[date] = None
    for d in sorted_dates:
        if prev is not None and (d - prev).days == 1:
            run += 1
        else:
            run = 1
        longest = max(longest, run)
        prev = d

    return current, longest


# ---------------------------------------------------------------------------
# Rendering

def heatmap(
    activity: Dict[date, int],
    year: Optional[int] = None,
    *,
    colour: bool = False,
) -> str:
    """Render a GitHub-style weekly heatmap for *year*.

    Each column is a week (Mon–Sun); each cell is one day.
    """
    y = year or date.today().year
    jan1 = date(y, 1, 1)
    dec31 = date(y, 12, 31)

    max_count = max(activity.values(), default=1)

    # Build a grid: 7 rows (Mon=0..Sun=6) × 53 cols (weeks)
    grid: List[List[str]] = [["  "] * 54 for _ in range(7)]

    d = jan1
    while d <= dec31:
        week = (d - jan1).days // 7
        dow = d.weekday()
        count = activity.get(d, 0)
        intensity = int(_clamp(count * (len(_BLOCKS) - 1) // max(max_count, 1), 0, len(_BLOCKS) - 1))
        cell = _BLOCKS[intensity] * 2
        if colour:
            # ANSI green gradient
            levels = [0, 22, 28, 34, 40]
            ansi = levels[_clamp(intensity, 0, 4)]
            cell = f"\033[38;5;{ansi}m{cell}\033[0m" if ansi else cell
        grid[dow][week] = cell
        d += timedelta(days=1)

    # Month labels row
    month_labels = [""] * 54
    for m in range(1, 13):
        first_of_month = date(y, m, 1)
        week_idx = (first_of_month - jan1).days // 7
        if week_idx < 54:
            month_labels[week_idx] = calendar.month_abbr[m]

    header = "".join(f"{lbl:<4}" if lbl else "  " for lbl in month_labels[:54])

    day_labels = ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"]
    rows = [f"{day_labels[r]}  " + "".join(grid[r]) for r in range(7)]

    return header + "\n" + "\n".join(rows)


def monthly_summary(activity: Dict[date, int], year: Optional[int] = None) -> str:
    """Return a month-by-month table of note counts."""
    y = year or date.today().year
    lines: List[str] = [f"  {'Month':<12} {'Notes':>6}  {'Bar'}"]
    lines.append("  " + "-" * 40)

    max_count = max(
        (sum(v for d, v in activity.items() if d.year == y and d.month == m) for m in range(1, 13)),
        default=1,
    )

    for m in range(1, 13):
        count = sum(v for d, v in activity.items() if d.year == y and d.month == m)
        bar_len = int(count * 20 // max(max_count, 1))
        bar = "█" * bar_len
        name = calendar.month_name[m]
        lines.append(f"  {name:<12} {count:>6}  {bar}")

    current, longest = streak(activity)
    lines.append("")
    lines.append(f"  Current streak : {current} day(s)")
    lines.append(f"  Longest streak : {longest} day(s)")
    lines.append(f"  Total active   : {len(activity)} day(s) in {y}")

    return "\n".join(lines)


def most_active_hours(store: Store) -> Dict[int, int]:
    """Return {hour: note_count} based on file modification times."""
    counts: Dict[int, int] = defaultdict(int)
    for note in store.notes():
        counts[note.modified.hour] += 1
    return dict(counts)


def most_active_weekdays(store: Store) -> Dict[str, int]:
    """Return {weekday_name: count} based on modification times."""
    day_names = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    counts: Dict[str, int] = defaultdict(int)
    for note in store.notes():
        counts[day_names[note.modified.weekday()]] += 1
    return dict(counts)
