"""Nota query language — filter notes with a structured mini-DSL.

Syntax examples::

    tag:python
    tag:python AND tag:async
    title:"async io"
    created:>2025-01-01
    modified:<2026-01-01
    words:>500
    words:100..2000
    tag:python NOT tag:archived
    (tag:python OR tag:rust) AND words:>200
    links:>3
    has:daily
    path:projects/

Operators: AND, OR, NOT (case-insensitive), parentheses for grouping.
Field comparisons: ``:``, ``:>``, ``:<``, ``:>=``, ``:<=``, ``:..`` (range).
Unqualified terms do a full-text body search.
"""
from __future__ import annotations

import re
from datetime import datetime
from typing import Callable, Iterator, List, Optional, Tuple

from .note import Note
from .store import Store


# ---------------------------------------------------------------------------
# Tokeniser

_TOKEN_RE = re.compile(
    r'(?P<lparen>\()'
    r'|(?P<rparen>\))'
    r'|(?P<and>\bAND\b)'
    r'|(?P<or>\bOR\b)'
    r'|(?P<not>\bNOT\b)'
    r'|(?P<field>[\w]+:[^\s()]+)'
    r'|(?P<quoted>"[^"]*")'
    r'|(?P<word>[^\s()]+)',
    re.IGNORECASE,
)


class Token:
    __slots__ = ("kind", "value")

    def __init__(self, kind: str, value: str) -> None:
        self.kind  = kind
        self.value = value

    def __repr__(self) -> str:
        return f"Token({self.kind}, {self.value!r})"


def tokenise(query: str) -> List[Token]:
    tokens: List[Token] = []
    for m in _TOKEN_RE.finditer(query):
        kind = m.lastgroup
        assert kind is not None
        value = m.group()
        if kind in ("and", "or", "not"):
            kind = kind.upper()
        tokens.append(Token(kind, value))
    return tokens


# ---------------------------------------------------------------------------
# AST nodes

Predicate = Callable[[Note], bool]


class _And:
    def __init__(self, left: Predicate, right: Predicate) -> None:
        self._l, self._r = left, right

    def __call__(self, note: Note) -> bool:
        return self._l(note) and self._r(note)


class _Or:
    def __init__(self, left: Predicate, right: Predicate) -> None:
        self._l, self._r = left, right

    def __call__(self, note: Note) -> bool:
        return self._l(note) or self._r(note)


class _Not:
    def __init__(self, operand: Predicate) -> None:
        self._op = operand

    def __call__(self, note: Note) -> bool:
        return not self._op(note)


# ---------------------------------------------------------------------------
# Field predicate builders

def _parse_field_predicate(token_value: str) -> Predicate:
    """Parse ``field:op_value`` into a Predicate callable."""
    colon = token_value.index(":")
    field = token_value[:colon].lower()
    raw   = token_value[colon + 1:]

    # range  words:100..2000
    if ".." in raw and not raw.startswith(".."):
        lo_s, hi_s = raw.split("..", 1)
        lo, hi = _coerce(field, lo_s), _coerce(field, hi_s)
        return lambda n, f=field, lo=lo, hi=hi: lo <= _get_field(n, f) <= hi  # type: ignore

    # comparison  words:>500  created:<=2025-06-01
    if raw and raw[0] in (">", "<", "="):
        op, val_s = _split_op(raw)
        val = _coerce(field, val_s)
        return _cmp_pred(field, op, val)

    # plain equality / substring
    val_s = raw.strip('"')
    return _eq_pred(field, val_s)


def _split_op(raw: str) -> Tuple[str, str]:
    if raw.startswith(">="):
        return ">=", raw[2:]
    if raw.startswith("<="):
        return "<=", raw[2:]
    if raw.startswith(">"):
        return ">", raw[1:]
    if raw.startswith("<"):
        return "<", raw[1:]
    return "=", raw.lstrip("=")


def _coerce(field: str, val_s: str):
    if field in ("created", "modified"):
        try:
            return datetime.fromisoformat(val_s)
        except ValueError:
            return val_s
    if field in ("words", "links", "headings"):
        try:
            return int(val_s)
        except ValueError:
            return 0
    return val_s


def _get_field(note: Note, field: str):
    if field == "tag":
        return note.tags
    if field == "title":
        return note.title.lower()
    if field == "path":
        return note.id
    if field == "created":
        return note.created or datetime.min
    if field == "modified":
        return note.modified
    if field == "words":
        return note.word_count
    if field == "links":
        return len(note.links)
    if field == "headings":
        return note.heading_count
    if field == "has":
        return None  # handled separately
    return ""


def _eq_pred(field: str, val: str) -> Predicate:
    if field == "tag":
        return lambda n, v=val: v in n.tags
    if field == "path":
        return lambda n, v=val: v in n.id
    if field == "title":
        return lambda n, v=val: v.lower() in n.title.lower()
    if field == "has":
        # has:daily, has:links, has:tags, has:image
        specials = {
            "daily":   lambda n: "daily" in n.id,
            "links":   lambda n: len(n.links) > 0,
            "tags":    lambda n: len(n.tags) > 0,
            "image":   lambda n: "![" in n.content,
            "code":    lambda n: "```" in n.content,
            "table":   lambda n: "| " in n.content,
            "toc":     lambda n: "<!-- toc -->" in n.content,
        }
        fn = specials.get(val.lower())
        return fn if fn else lambda n: False
    return lambda n, f=field, v=val: str(_get_field(n, f)).lower() == v.lower()


def _cmp_pred(field: str, op: str, val) -> Predicate:
    ops = {
        ">":  lambda a, b: a > b,
        "<":  lambda a, b: a < b,
        ">=": lambda a, b: a >= b,
        "<=": lambda a, b: a <= b,
        "=":  lambda a, b: a == b,
    }
    fn = ops.get(op, ops["="])
    return lambda n, f=field, fn=fn, v=val: fn(_get_field(n, f), v)


def _text_pred(term: str) -> Predicate:
    """Case-insensitive substring search in title + content."""
    t = term.lower().strip('"')
    return lambda n, t=t: t in n.title.lower() or t in n.content.lower()


# ---------------------------------------------------------------------------
# Recursive descent parser

class _Parser:
    def __init__(self, tokens: List[Token]) -> None:
        self._tokens = tokens
        self._pos    = 0

    def _peek(self) -> Optional[Token]:
        return self._tokens[self._pos] if self._pos < len(self._tokens) else None

    def _consume(self) -> Token:
        tok = self._tokens[self._pos]
        self._pos += 1
        return tok

    def parse(self) -> Predicate:
        pred = self._parse_or()
        return pred

    def _parse_or(self) -> Predicate:
        left = self._parse_and()
        while (tok := self._peek()) and tok.kind == "OR":
            self._consume()
            right = self._parse_and()
            left = _Or(left, right)
        return left

    def _parse_and(self) -> Predicate:
        left = self._parse_not()
        while (tok := self._peek()) and tok.kind in ("AND", "word", "field", "quoted", "lparen"):
            if tok.kind == "AND":
                self._consume()
            # implicit AND between adjacent terms
            elif tok.kind in ("OR",):
                break
            right = self._parse_not()
            left = _And(left, right)
        return left

    def _parse_not(self) -> Predicate:
        if (tok := self._peek()) and tok.kind == "NOT":
            self._consume()
            operand = self._parse_atom()
            return _Not(operand)
        return self._parse_atom()

    def _parse_atom(self) -> Predicate:
        tok = self._peek()
        if tok is None:
            return lambda n: True

        if tok.kind == "lparen":
            self._consume()
            pred = self._parse_or()
            if (close := self._peek()) and close.kind == "rparen":
                self._consume()
            return pred

        self._consume()
        if tok.kind == "field":
            return _parse_field_predicate(tok.value)
        if tok.kind in ("word", "quoted"):
            return _text_pred(tok.value)

        return lambda n: True


# ---------------------------------------------------------------------------
# Public API

def compile_query(query: str) -> Predicate:
    """Compile a query string into a callable ``Predicate(note) -> bool``.

    Raises ``QuerySyntaxError`` if the query cannot be parsed.
    """
    tokens = tokenise(query.strip())
    if not tokens:
        return lambda n: True
    try:
        return _Parser(tokens).parse()
    except Exception as exc:
        raise QuerySyntaxError(f"Invalid query {query!r}: {exc}") from exc


def search(store: Store, query: str, limit: int = 0) -> List[Note]:
    """Run *query* against every note in *store*.

    Args:
        store: the nota Store to search.
        query: query string (see module docstring for syntax).
        limit: max results; 0 means unlimited.

    Returns:
        List of matching Note objects, sorted by modified date descending.
    """
    pred = compile_query(query)
    results = [n for n in store.notes() if pred(n)]
    results.sort(key=lambda n: n.modified, reverse=True)
    return results[:limit] if limit else results


def explain(query: str) -> str:
    """Return a human-readable explanation of what a query matches."""
    tokens = tokenise(query.strip())
    parts = []
    for tok in tokens:
        if tok.kind == "field":
            colon = tok.value.index(":")
            field = tok.value[:colon]
            val   = tok.value[colon + 1:]
            parts.append(f"[{field} matches {val!r}]")
        elif tok.kind in ("AND", "OR", "NOT"):
            parts.append(tok.value.upper())
        elif tok.kind == "lparen":
            parts.append("(")
        elif tok.kind == "rparen":
            parts.append(")")
        else:
            parts.append(f"[body/title contains {tok.value!r}]")
    return " ".join(parts)


class QuerySyntaxError(ValueError):
    pass
