"""Periodic task scheduler for nota.

Provides a lightweight in-process scheduler for recurring vault tasks:
  - Auto-indexing on a configured interval
  - Stale-link detection sweeps
  - Backup snapshots
  - Summary report generation
  - Plugin heartbeat hooks

Uses stdlib threading.Timer for scheduling — no external dependency.
The scheduler is designed to be started as a daemon alongside the web
server or watcher and stopped gracefully on SIGINT/SIGTERM.
"""
from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any, Callable, Dict, List, Optional, Tuple

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Types

TaskFn = Callable[[], None]


@dataclass
class ScheduledTask:
    """A single recurring task registered with the Scheduler."""
    name: str
    fn: TaskFn
    interval_seconds: float
    description: str = ""
    enabled: bool = True
    run_immediately: bool = False

    # Runtime state
    last_run: Optional[datetime] = field(default=None, compare=False)
    last_error: Optional[str]   = field(default=None, compare=False)
    run_count: int               = field(default=0,    compare=False)
    error_count: int             = field(default=0,    compare=False)

    @property
    def next_run(self) -> Optional[datetime]:
        if self.last_run is None:
            return datetime.now() if self.run_immediately else (
                datetime.now() + timedelta(seconds=self.interval_seconds)
            )
        return self.last_run + timedelta(seconds=self.interval_seconds)

    @property
    def is_due(self) -> bool:
        nr = self.next_run
        return nr is not None and datetime.now() >= nr

    def execute(self) -> bool:
        """Run the task, update bookkeeping, return True on success."""
        try:
            self.fn()
            self.last_run    = datetime.now()
            self.run_count  += 1
            self.last_error  = None
            return True
        except Exception as exc:  # noqa: BLE001
            self.last_error    = str(exc)
            self.error_count  += 1
            self.last_run      = datetime.now()
            log.error("Scheduled task %r failed: %s", self.name, exc)
            return False

    def status_dict(self) -> Dict[str, Any]:
        return {
            "name":          self.name,
            "description":   self.description,
            "enabled":       self.enabled,
            "interval_s":    self.interval_seconds,
            "last_run":      self.last_run.isoformat() if self.last_run else None,
            "next_run":      self.next_run.isoformat() if self.next_run else None,
            "run_count":     self.run_count,
            "error_count":   self.error_count,
            "last_error":    self.last_error,
        }


# ---------------------------------------------------------------------------
# Scheduler

class Scheduler:
    """Thread-safe task scheduler with a polling loop.

    Tasks are checked on each *tick* (default 30 s) and run in their own
    daemon threads to avoid blocking the scheduler loop.

    Example::

        scheduler = Scheduler(tick=10)
        scheduler.add("reindex", store.index_all, interval=300,
                      description="Re-index vault every 5 minutes")
        scheduler.start()
        # … later …
        scheduler.stop()
    """

    def __init__(self, tick: float = 30.0) -> None:
        self._tick  = tick
        self._tasks: Dict[str, ScheduledTask] = {}
        self._lock  = threading.Lock()
        self._thread: Optional[threading.Thread] = None
        self._stop  = threading.Event()
        self._running = False

    # ------------------------------------------------------------------
    # Registration

    def add(
        self,
        name: str,
        fn: TaskFn,
        interval: float,
        description: str = "",
        run_immediately: bool = False,
        enabled: bool = True,
    ) -> "Scheduler":
        """Register a recurring task.  Returns self for chaining."""
        task = ScheduledTask(
            name=name,
            fn=fn,
            interval_seconds=interval,
            description=description,
            run_immediately=run_immediately,
            enabled=enabled,
        )
        with self._lock:
            self._tasks[name] = task
        return self

    def remove(self, name: str) -> bool:
        with self._lock:
            return self._tasks.pop(name, None) is not None

    def enable(self, name: str) -> bool:
        with self._lock:
            if name in self._tasks:
                self._tasks[name].enabled = True
                return True
        return False

    def disable(self, name: str) -> bool:
        with self._lock:
            if name in self._tasks:
                self._tasks[name].enabled = False
                return True
        return False

    # ------------------------------------------------------------------
    # Lifecycle

    def start(self) -> None:
        if self._running:
            return
        self._stop.clear()
        self._running = True
        self._thread = threading.Thread(
            target=self._loop, name="nota-scheduler", daemon=True
        )
        self._thread.start()
        log.info("Scheduler started (tick=%ss, tasks=%d)", self._tick, len(self._tasks))

    def stop(self, timeout: float = 5.0) -> None:
        self._stop.set()
        self._running = False
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=timeout)
        log.info("Scheduler stopped")

    @property
    def is_running(self) -> bool:
        return self._running

    # ------------------------------------------------------------------
    # Query

    def status(self) -> List[Dict[str, Any]]:
        with self._lock:
            return [t.status_dict() for t in self._tasks.values()]

    def get_task(self, name: str) -> Optional[ScheduledTask]:
        with self._lock:
            return self._tasks.get(name)

    def run_now(self, name: str) -> bool:
        """Trigger a task immediately (in its own thread)."""
        with self._lock:
            task = self._tasks.get(name)
        if task is None:
            return False
        t = threading.Thread(target=task.execute, daemon=True, name=f"nota-task-{name}")
        t.start()
        return True

    # ------------------------------------------------------------------
    # Internal

    def _loop(self) -> None:
        while not self._stop.wait(self._tick):
            with self._lock:
                tasks_copy = list(self._tasks.values())
            for task in tasks_copy:
                if not task.enabled or not task.is_due:
                    continue
                t = threading.Thread(
                    target=task.execute,
                    daemon=True,
                    name=f"nota-task-{task.name}",
                )
                t.start()

    def __repr__(self) -> str:
        return (
            f"Scheduler(tick={self._tick}s, tasks={len(self._tasks)}, "
            f"running={self._running})"
        )


# ---------------------------------------------------------------------------
# Vault-specific task factories

def make_reindex_task(store: Any, force: bool = False) -> TaskFn:
    """Return a task function that re-indexes the vault."""
    def _reindex() -> None:
        count = store.index_all(force=force)
        log.debug("Reindex: %d notes processed", count)
    return _reindex


def make_broken_link_task(store: Any) -> TaskFn:
    """Return a task that logs broken links."""
    def _check() -> None:
        from nota.plugins.builtin.broken_links import check_broken_links
        report = check_broken_links(store)
        if report.broken:
            log.warning("Broken links found: %d", report.count)
            for bl in report.broken:
                log.warning("  %s", bl)
    return _check


def make_backup_task(vault_path: Any, backup_dir: Any) -> TaskFn:
    """Return a task that creates a timestamped zip backup of the vault."""
    import zipfile
    from pathlib import Path

    def _backup() -> None:
        vp = Path(vault_path)
        bd = Path(backup_dir)
        bd.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        dest = bd / f"nota_backup_{stamp}.zip"
        with zipfile.ZipFile(dest, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            for p in vp.rglob("*.md"):
                zf.write(p, p.relative_to(vp))
        log.info("Backup created: %s", dest.name)

    return _backup


def make_stats_log_task(store: Any) -> TaskFn:
    """Return a task that logs vault statistics."""
    def _stats() -> None:
        try:
            count = store.note_count()
            log.info("Vault stats: %d notes", count)
        except Exception as exc:  # noqa: BLE001
            log.warning("Stats task failed: %s", exc)
    return _stats


# ---------------------------------------------------------------------------
# Default scheduler setup

def default_scheduler(store: Any, vault_path: Any) -> Scheduler:
    """Create a Scheduler pre-configured with common vault tasks."""
    s = Scheduler(tick=60)
    s.add(
        "reindex",
        make_reindex_task(store),
        interval=300,
        description="Re-index changed vault notes every 5 minutes",
        run_immediately=True,
    )
    s.add(
        "broken-links",
        make_broken_link_task(store),
        interval=3600,
        description="Check for broken wiki-links every hour",
    )
    s.add(
        "stats-log",
        make_stats_log_task(store),
        interval=900,
        description="Log vault statistics every 15 minutes",
    )
    return s
