"""Note summarisation — local LLM via ollama, with extractive fallback."""
from __future__ import annotations

import heapq
import json
import re
import urllib.error
import urllib.request
from typing import Generator, Iterator, List, Optional

from .note import Note


# ---------------------------------------------------------------------------
# Extractive summariser (zero dependencies)

_SENT_RE = re.compile(r"(?<=[.!?])\s+")
_WORD_RE  = re.compile(r"\b\w+\b")

_STOP_WORDS = frozenset(
    "a an the is are was were be been being have has had do does did "
    "will would could should may might shall can am i we you he she it "
    "they them their this that these those of in on at to for with from "
    "by as or and but not so yet also just more very much all no up out "
    "if then when where how what who why its my our your his her".split()
)


def _score_sentences(text: str) -> List[tuple[float, int, str]]:
    sentences = [s.strip() for s in _SENT_RE.split(text) if len(s.split()) > 4]
    if not sentences:
        return []

    # term frequency over full text
    words = [w.lower() for w in _WORD_RE.findall(text) if w.lower() not in _STOP_WORDS]
    tf: dict[str, int] = {}
    for w in words:
        tf[w] = tf.get(w, 0) + 1

    scored: List[tuple[float, int, str]] = []
    for i, sent in enumerate(sentences):
        sent_words = [w.lower() for w in _WORD_RE.findall(sent) if w.lower() not in _STOP_WORDS]
        score = sum(tf.get(w, 0) for w in sent_words) / max(len(sent_words), 1)
        scored.append((score, i, sent))

    return scored


def extractive_summary(note: Note, sentences: int = 3) -> str:
    """Return an extractive summary using TF-scored sentence selection."""
    content = note.content
    scored = _score_sentences(content)
    if not scored:
        # fall back to first non-heading lines
        lines = [l for l in content.splitlines() if l.strip() and not l.startswith("#")]
        return " ".join(lines[:sentences])

    top = heapq.nlargest(sentences, scored)
    # restore original order
    top.sort(key=lambda x: x[1])
    return " ".join(s for _, _, s in top)


# ---------------------------------------------------------------------------
# Ollama integration

_DEFAULT_MODEL = "llama3.1"
_OLLAMA_URL    = "http://localhost:11434/api/generate"


class OllamaError(RuntimeError):
    pass


def _post_json(url: str, payload: dict) -> Iterator[dict]:
    data = json.dumps(payload).encode()
    req = urllib.request.Request(
        url,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            for line in resp:
                line = line.strip()
                if line:
                    yield json.loads(line)
    except urllib.error.URLError as exc:
        raise OllamaError(f"Cannot reach Ollama at {url}: {exc}") from exc


def ollama_is_running() -> bool:
    try:
        urllib.request.urlopen("http://localhost:11434", timeout=2)
        return True
    except Exception:
        return False


def summarize_streaming(
    note: Note,
    *,
    model: str = _DEFAULT_MODEL,
    max_tokens: int = 200,
    system_prompt: Optional[str] = None,
) -> Generator[str, None, None]:
    """Stream an LLM summary token by token via ollama.

    Falls back to extractive if ollama is not available.
    """
    if not ollama_is_running():
        yield extractive_summary(note)
        return

    prompt = (
        f"Summarise the following note in 2-3 sentences. "
        f"Be concise and factual. Output only the summary, no preamble.\n\n"
        f"Title: {note.title}\n\n{note.content[:3000]}"
    )

    payload = {
        "model": model,
        "prompt": prompt,
        "stream": True,
        "options": {"num_predict": max_tokens, "temperature": 0.3},
    }
    if system_prompt:
        payload["system"] = system_prompt

    try:
        for chunk in _post_json(_OLLAMA_URL, payload):
            token = chunk.get("response", "")
            if token:
                yield token
            if chunk.get("done"):
                break
    except OllamaError:
        yield extractive_summary(note)


def summarize(
    note: Note,
    *,
    model: str = _DEFAULT_MODEL,
    max_tokens: int = 200,
) -> str:
    """Return full summary as a string (blocking)."""
    return "".join(summarize_streaming(note, model=model, max_tokens=max_tokens))


# ---------------------------------------------------------------------------
# Auto-title suggestion

def suggest_title(note: Note, *, model: str = _DEFAULT_MODEL) -> str:
    """Suggest a better title for a note based on its content."""
    if not ollama_is_running():
        # extractive: use first non-empty, non-heading line up to 60 chars
        for line in note.content.splitlines():
            stripped = line.strip().lstrip("#").strip()
            if stripped:
                return stripped[:60]
        return note.title

    prompt = (
        f"Suggest a concise, descriptive title (max 8 words) for this note. "
        f"Output only the title, nothing else.\n\n{note.content[:1000]}"
    )
    payload = {
        "model": model,
        "prompt": prompt,
        "stream": False,
        "options": {"num_predict": 30, "temperature": 0.2},
    }
    try:
        for chunk in _post_json(_OLLAMA_URL, payload):
            return chunk.get("response", note.title).strip().strip('"')
    except OllamaError:
        pass
    return note.title


# ---------------------------------------------------------------------------
# Bulk summarisation

def summarize_vault(store, *, model: str = _DEFAULT_MODEL, max_tokens: int = 150) -> dict[str, str]:
    """Return {note_id: summary} for every note in the vault."""
    from .store import Store  # local import to avoid circular

    results: dict[str, str] = {}
    for note in store.notes():  # type: ignore[union-attr]
        try:
            results[note.id] = summarize(note, model=model, max_tokens=max_tokens)
        except Exception:
            results[note.id] = extractive_summary(note)
    return results
