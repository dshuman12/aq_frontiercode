"""Remote sync for nota vaults via S3 (or S3-compatible storage).

Design:
  - Delta-based: only changed notes (by checksum) are uploaded/downloaded.
  - A remote manifest (.nota/manifest.json) tracks {note_id: checksum}.
  - Conflicts are handled conservatively: newer mtime wins by default.
  - Requires nota[sync] (boto3).
"""
from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from .note import Note
from .store import Store


# ---------------------------------------------------------------------------
# Manifest

@dataclass
class Manifest:
    notes: Dict[str, str] = field(default_factory=dict)   # note_id -> checksum
    updated_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())

    def to_json(self) -> str:
        return json.dumps({"notes": self.notes, "updated_at": self.updated_at}, indent=2)

    @classmethod
    def from_json(cls, raw: str) -> "Manifest":
        data = json.loads(raw)
        m = cls()
        m.notes = data.get("notes", {})
        m.updated_at = data.get("updated_at", "")
        return m


# ---------------------------------------------------------------------------
# S3 client wrapper

class S3Sync:
    """Sync a nota vault with an S3 bucket."""

    _MANIFEST_KEY = ".nota/manifest.json"

    def __init__(self, bucket: str, prefix: str = "nota/", *, profile: Optional[str] = None) -> None:
        try:
            import boto3  # type: ignore
        except ImportError as exc:
            raise RuntimeError("S3 sync requires: pip install nota[sync]") from exc

        session = boto3.Session(profile_name=profile)
        self._s3 = session.client("s3")
        self.bucket = bucket
        self.prefix = prefix.rstrip("/") + "/"

    def _key(self, note_id: str) -> str:
        return self.prefix + note_id

    # ------------------------------------------------------------------
    # manifest

    def _fetch_remote_manifest(self) -> Optional[Manifest]:
        try:
            resp = self._s3.get_object(Bucket=self.bucket, Key=self.prefix + self._MANIFEST_KEY)
            return Manifest.from_json(resp["Body"].read().decode())
        except Exception:
            return None

    def _push_manifest(self, manifest: Manifest) -> None:
        self._s3.put_object(
            Bucket=self.bucket,
            Key=self.prefix + self._MANIFEST_KEY,
            Body=manifest.to_json().encode(),
            ContentType="application/json",
        )

    # ------------------------------------------------------------------
    # push

    def push_note(self, note: Note) -> None:
        content = note.path.read_bytes()
        self._s3.put_object(
            Bucket=self.bucket,
            Key=self._key(note.id),
            Body=content,
            ContentType="text/markdown; charset=utf-8",
            Metadata={"nota-checksum": note.checksum},
        )

    def push(self, store: Store, *, dry_run: bool = False) -> "SyncResult":
        result = SyncResult()
        remote_manifest = self._fetch_remote_manifest() or Manifest()

        local_notes = list(store.notes())
        for note in local_notes:
            remote_cs = remote_manifest.notes.get(note.id)
            if remote_cs == note.checksum:
                result.skipped.append(note.id)
                continue
            if not dry_run:
                try:
                    self.push_note(note)
                    remote_manifest.notes[note.id] = note.checksum
                    result.uploaded.append(note.id)
                except Exception as exc:
                    result.errors.append((note.id, str(exc)))
            else:
                result.uploaded.append(note.id)

        if not dry_run:
            self._push_manifest(remote_manifest)

        return result

    # ------------------------------------------------------------------
    # pull

    def pull_note(self, note_id: str, vault_root: Path) -> Path:
        resp = self._s3.get_object(Bucket=self.bucket, Key=self._key(note_id))
        content = resp["Body"].read()
        local_path = vault_root / note_id
        local_path.parent.mkdir(parents=True, exist_ok=True)
        local_path.write_bytes(content)
        return local_path

    def pull(self, store: Store, *, dry_run: bool = False) -> "SyncResult":
        result = SyncResult()
        remote_manifest = self._fetch_remote_manifest()
        if not remote_manifest:
            return result

        local_checksums = {n.id: n.checksum for n in store.notes()}

        for note_id, remote_cs in remote_manifest.notes.items():
            local_cs = local_checksums.get(note_id)
            if local_cs == remote_cs:
                result.skipped.append(note_id)
                continue
            if not dry_run:
                try:
                    self.pull_note(note_id, store.vault_root)
                    result.downloaded.append(note_id)
                except Exception as exc:
                    result.errors.append((note_id, str(exc)))
            else:
                result.downloaded.append(note_id)

        return result

    # ------------------------------------------------------------------
    # two-way sync with mtime conflict resolution

    def sync(self, store: Store, *, dry_run: bool = False) -> "SyncResult":
        result = SyncResult()
        remote_manifest = self._fetch_remote_manifest() or Manifest()
        local_notes = {n.id: n for n in store.notes()}

        # upload new/changed local notes
        for note_id, note in local_notes.items():
            remote_cs = remote_manifest.notes.get(note_id)
            if remote_cs == note.checksum:
                result.skipped.append(note_id)
                continue
            if remote_cs is not None:
                # conflict: remote has a different version — prefer newer mtime
                try:
                    resp = self._s3.head_object(Bucket=self.bucket, Key=self._key(note_id))
                    remote_mtime = resp.get("LastModified")
                    local_mtime = note.modified
                    if remote_mtime and remote_mtime.replace(tzinfo=None) > local_mtime:
                        # remote wins — download
                        if not dry_run:
                            self.pull_note(note_id, store.vault_root)
                        result.downloaded.append(note_id)
                        result.conflicts.append(note_id)
                        continue
                except Exception:
                    pass
            if not dry_run:
                try:
                    self.push_note(note)
                    remote_manifest.notes[note_id] = note.checksum
                    result.uploaded.append(note_id)
                except Exception as exc:
                    result.errors.append((note_id, str(exc)))
            else:
                result.uploaded.append(note_id)

        # download notes that exist remotely but not locally
        for note_id in remote_manifest.notes:
            if note_id not in local_notes:
                if not dry_run:
                    try:
                        self.pull_note(note_id, store.vault_root)
                        result.downloaded.append(note_id)
                    except Exception as exc:
                        result.errors.append((note_id, str(exc)))
                else:
                    result.downloaded.append(note_id)

        if not dry_run:
            self._push_manifest(remote_manifest)

        return result

    # ------------------------------------------------------------------
    # presigned sharing

    def presigned_url(self, note: Note, expires_in: int = 7 * 86400) -> str:
        """Generate a pre-signed download URL for *note* (default 7 days)."""
        return self._s3.generate_presigned_url(
            "get_object",
            Params={"Bucket": self.bucket, "Key": self._key(note.id)},
            ExpiresIn=expires_in,
        )


# ---------------------------------------------------------------------------
# Result container

@dataclass
class SyncResult:
    uploaded: List[str]   = field(default_factory=list)
    downloaded: List[str] = field(default_factory=list)
    skipped: List[str]    = field(default_factory=list)
    conflicts: List[str]  = field(default_factory=list)
    errors: List[Tuple[str, str]] = field(default_factory=list)

    def summary(self) -> str:
        parts = []
        if self.uploaded:
            parts.append(f"↑ {len(self.uploaded)} uploaded")
        if self.downloaded:
            parts.append(f"↓ {len(self.downloaded)} downloaded")
        if self.conflicts:
            parts.append(f"⚡ {len(self.conflicts)} conflict(s) resolved")
        if self.skipped:
            parts.append(f"· {len(self.skipped)} unchanged")
        if self.errors:
            parts.append(f"✗ {len(self.errors)} error(s)")
        return ", ".join(parts) if parts else "Nothing to sync"
