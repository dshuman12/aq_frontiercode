from __future__ import annotations

import hashlib
import re
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional, Tuple

import frontmatter

# [[Target Note|alias]] or [[Target Note#heading]]
_WIKI_RE = re.compile(r"\[\[([^\]|#]+)(?:#[^\]|]*)?\|?([^\]]*)\]\]")
# inline #tag — must not be inside a code span
_TAG_RE  = re.compile(r"(?:^|\s)#([\w/:-]+)", re.MULTILINE)
# heading lines
_H_RE    = re.compile(r"^(#{1,6})\s+(.+)$", re.MULTILINE)
# bare URL
_URL_RE  = re.compile(r"https?://[^\s\)>\"]+")
# inline code spans (to skip tag detection inside them)
_CODE_RE = re.compile(r"`[^`]+`")


class Note:
    """Represents a single markdown note file.

    All properties are lazily loaded and cached by mtime so repeated
    accesses within a single process are cheap even for large vaults.
    """

    __slots__ = ("path", "vault_root", "_post", "_mtime")

    def __init__(self, path: Path, vault_root: Path) -> None:
        self.path       = path
        self.vault_root = vault_root
        self._post: Optional[frontmatter.Post] = None
        self._mtime: Optional[float]            = None

    # ------------------------------------------------------------------
    # lazy loading

    def _load(self) -> None:
        try:
            mtime = self.path.stat().st_mtime
        except OSError:
            return
        if self._post is None or mtime != self._mtime:
            try:
                self._post = frontmatter.load(str(self.path))
            except Exception:
                self._post = frontmatter.Post("", **{})
            self._mtime = mtime

    # ------------------------------------------------------------------
    # identity

    @property
    def id(self) -> str:
        """Vault-relative POSIX path — stable unique identifier."""
        return self.path.relative_to(self.vault_root).as_posix()

    @property
    def stem(self) -> str:
        return self.path.stem

    @property
    def suffix(self) -> str:
        return self.path.suffix

    # ------------------------------------------------------------------
    # content properties

    @property
    def title(self) -> str:
        self._load()
        assert self._post is not None
        if "title" in self._post.metadata:
            return str(self._post.metadata["title"])
        for line in self._post.content.splitlines():
            stripped = line.strip()
            if stripped.startswith("# "):
                return stripped[2:].strip()
        # humanise the filename as last resort
        return self.path.stem.replace("-", " ").replace("_", " ").title()

    @property
    def content(self) -> str:
        self._load()
        assert self._post is not None
        return self._post.content

    @property
    def raw(self) -> str:
        """Full file bytes decoded as UTF-8 (includes frontmatter)."""
        return self.path.read_text(encoding="utf-8", errors="replace")

    @property
    def metadata(self) -> Dict[str, Any]:
        self._load()
        assert self._post is not None
        return dict(self._post.metadata)

    # ------------------------------------------------------------------
    # tags

    @property
    def tags(self) -> List[str]:
        self._load()
        assert self._post is not None
        fm_tags = self._post.metadata.get("tags", [])
        if isinstance(fm_tags, str):
            fm_tags = [t.strip() for t in fm_tags.split(",") if t.strip()]
        elif not isinstance(fm_tags, list):
            fm_tags = []

        # strip inline code before scanning for #tags
        stripped = _CODE_RE.sub("", self._post.content)
        inline = _TAG_RE.findall(stripped)

        seen: Dict[str, None] = {}
        for t in list(fm_tags) + inline:
            seen[str(t)] = None
        return list(seen)

    # ------------------------------------------------------------------
    # links

    @property
    def links(self) -> List[str]:
        """Targets of all [[wiki-links]] in the note body (raw, may duplicate)."""
        self._load()
        assert self._post is not None
        return [m.group(1).strip() for m in _WIKI_RE.finditer(self._post.content)]

    @property
    def unique_links(self) -> List[str]:
        return list(dict.fromkeys(self.links))

    @property
    def external_links(self) -> List[str]:
        """Bare HTTP/HTTPS URLs found in the note body."""
        self._load()
        assert self._post is not None
        return _URL_RE.findall(self._post.content)

    # ------------------------------------------------------------------
    # headings

    @property
    def headings(self) -> List[Tuple[int, str]]:
        """Return [(level, text), ...] for all headings in the note."""
        self._load()
        assert self._post is not None
        return [(len(m.group(1)), m.group(2).strip())
                for m in _H_RE.finditer(self._post.content)]

    def section(self, heading: str) -> Optional[str]:
        """Extract the body text under a heading (case-insensitive)."""
        from ..export.markdown import extract_section
        return extract_section(self.content, heading)

    # ------------------------------------------------------------------
    # dates

    @property
    def created(self) -> Optional[datetime]:
        self._load()
        assert self._post is not None
        val = self._post.metadata.get("created") or self._post.metadata.get("date")
        if val is None:
            return None
        if isinstance(val, datetime):
            return val
        try:
            return datetime.fromisoformat(str(val))
        except (ValueError, TypeError):
            return None

    @property
    def modified(self) -> datetime:
        return datetime.fromtimestamp(self.path.stat().st_mtime)

    @property
    def age_days(self) -> int:
        """Days since the note was last modified."""
        return (datetime.now() - self.modified).days

    # ------------------------------------------------------------------
    # content metrics

    @property
    def word_count(self) -> int:
        return len(self.content.split())

    @property
    def char_count(self) -> int:
        return len(self.content)

    @property
    def reading_time_minutes(self) -> float:
        """Estimated reading time at 200 wpm."""
        return self.word_count / 200.0

    @property
    def heading_count(self) -> int:
        return len(self.headings)

    @property
    def link_density(self) -> float:
        """Ratio of outbound links to words (0.0–1.0+)."""
        wc = self.word_count
        return len(self.links) / wc if wc else 0.0

    # ------------------------------------------------------------------
    # integrity

    @property
    def checksum(self) -> str:
        return hashlib.sha256(self.path.read_bytes()).hexdigest()[:16]

    def is_encrypted(self) -> bool:
        from ..utils.encrypt import is_encrypted
        return is_encrypted(self.path)

    # ------------------------------------------------------------------
    # frontmatter mutation helpers

    def set_metadata(self, key: str, value: Any) -> None:
        """Write a frontmatter field and save the file."""
        self._load()
        assert self._post is not None
        self._post.metadata[key] = value
        self.path.write_text(frontmatter.dumps(self._post), encoding="utf-8")
        self._post = None  # invalidate cache

    def update_metadata(self, updates: Dict[str, Any]) -> None:
        """Bulk-update multiple frontmatter fields atomically."""
        self._load()
        assert self._post is not None
        self._post.metadata.update(updates)
        self.path.write_text(frontmatter.dumps(self._post), encoding="utf-8")
        self._post = None

    # ------------------------------------------------------------------
    # serialisation

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":           self.id,
            "title":        self.title,
            "tags":         self.tags,
            "links":        self.unique_links,
            "created":      self.created.isoformat() if self.created else None,
            "modified":     self.modified.isoformat(),
            "word_count":   self.word_count,
            "reading_time": round(self.reading_time_minutes, 1),
            "headings":     self.headings,
        }

    def to_markdown(self, *, rewrite_links: bool = False) -> str:
        """Return the note as clean markdown (frontmatter stripped)."""
        if rewrite_links:
            from ..export.markdown import rewrite_wiki_links
            return rewrite_wiki_links(self.content)
        return self.content

    # ------------------------------------------------------------------
    # dunder

    def __repr__(self) -> str:
        return f"Note({self.id!r})"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Note):
            return NotImplemented
        return self.path == other.path

    def __hash__(self) -> int:
        return hash(self.path)

    def __lt__(self, other: "Note") -> bool:
        return self.id < other.id


def iter_markdown(root: Path) -> Iterator[Path]:
    """Yield all .md files under *root*, skipping hidden/internal dirs."""
    for p in sorted(root.rglob("*.md")):
        if any(part.startswith(".") for part in p.relative_to(root).parts):
            continue
        yield p
