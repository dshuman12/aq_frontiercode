from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

from .note import Note
from .store import Store

_WIKI_RE = re.compile(r"\[\[([^\]|#]+)(?:#([^\]|]*))?\|?([^\]]*)\]\]")


@dataclass
class LinkEdge:
    source: str       # note id
    target: str       # note id or unresolved stem
    heading: Optional[str] = None
    alias: Optional[str] = None
    resolved: bool = False


def extract_links(note: Note) -> List[LinkEdge]:
    edges: List[LinkEdge] = []
    for m in _WIKI_RE.finditer(note.content):
        target = m.group(1).strip()
        heading = m.group(2).strip() if m.group(2) else None
        alias = m.group(3).strip() if m.group(3) else None
        edges.append(LinkEdge(
            source=note.id,
            target=target,
            heading=heading,
            alias=alias,
        ))
    return edges


def resolve_links(note: Note, store: Store) -> List[LinkEdge]:
    """Resolve wiki-link targets to actual note ids."""
    stems: Dict[str, str] = {n.stem: n.id for n in store.notes()}
    edges = extract_links(note)
    for edge in edges:
        resolved = stems.get(edge.target)
        if resolved is None:
            # try as relative path
            candidate = note.path.parent / (edge.target + ".md")
            if candidate.exists():
                resolved = candidate.relative_to(store.vault_root).as_posix()
        if resolved:
            edge.target = resolved
            edge.resolved = True
    return edges


def link_graph(store: Store) -> Dict[str, List[str]]:
    """Build a directed adjacency list for the full vault."""
    adj: Dict[str, List[str]] = {}
    for note in store.notes():
        targets = [e.target for e in resolve_links(note, store) if e.resolved]
        adj[note.id] = targets
    return adj


def orphans(store: Store) -> List[Note]:
    """Notes with no inbound or outbound links."""
    adj = link_graph(store)
    linked: Set[str] = set()
    for src, targets in adj.items():
        if targets:
            linked.add(src)
            linked.update(targets)
    return [n for n in store.notes() if n.id not in linked]


def ascii_graph(adj: Dict[str, List[str]], max_nodes: int = 30) -> str:
    """Render a simple ASCII representation of the link graph."""
    lines: List[str] = []
    nodes = list(adj.keys())[:max_nodes]
    for node in nodes:
        targets = [t for t in adj.get(node, []) if t in set(nodes)]
        stem = node.split("/")[-1].replace(".md", "")
        if targets:
            for t in targets:
                t_stem = t.split("/")[-1].replace(".md", "")
                lines.append(f"  {stem}  ->  {t_stem}")
        else:
            lines.append(f"  {stem}")
    return "\n".join(lines)
