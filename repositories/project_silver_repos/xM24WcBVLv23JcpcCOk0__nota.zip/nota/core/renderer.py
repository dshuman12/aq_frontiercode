"""Markdown renderer for nota notes.

Converts raw markdown to HTML with nota-specific extensions:
  - [[Wiki Links]] resolved to vault anchors
  - #tag syntax highlighted
  - Fenced code blocks with language labels
  - Task list checkboxes (- [ ] / - [x])
  - Footnotes
  - Callouts / admonitions  (> [!NOTE], > [!WARNING] …)
  - Table of contents injection via <!-- toc --> marker
  - Inline metadata display from frontmatter
  - Mermaid diagram pass-through (fenced ```mermaid blocks)

All output is self-contained HTML fragments (no <html>/<body> wrapper)
suitable for embedding in the server's page layout.
"""
from __future__ import annotations

import hashlib
import html
import re
import textwrap
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple


# ---------------------------------------------------------------------------
# Configuration

@dataclass
class RenderConfig:
    """Options controlling the rendering pipeline."""
    base_url: str = "/"
    link_prefix: str = "/note/"
    tag_prefix: str = "/tags/"
    highlight_code: bool = True
    render_task_lists: bool = True
    render_callouts: bool = True
    render_footnotes: bool = True
    render_mermaid: bool = True
    inject_toc: bool = True
    toc_min_headings: int = 3
    external_link_icon: bool = True
    safe_mode: bool = False  # strip raw HTML when True


# ---------------------------------------------------------------------------
# Token types

@dataclass
class _Heading:
    level: int
    text: str
    anchor: str


@dataclass
class _TocEntry:
    level: int
    text: str
    anchor: str


# ---------------------------------------------------------------------------
# Renderer

class MarkdownRenderer:
    """Single-pass markdown-to-HTML renderer.

    Usage::

        renderer = MarkdownRenderer(config)
        html_fragment = renderer.render(markdown_text)
    """

    _HEADING_RE   = re.compile(r"^(#{1,6})\s+(.+)$", re.MULTILINE)
    _WIKI_RE      = re.compile(r"\[\[([^\]|]+)(?:\|([^\]]+))?\]\]")
    _HASHTAG_RE   = re.compile(r"(?<!\w)#([\w/-]+)")
    _BOLD_RE      = re.compile(r"\*\*(.+?)\*\*|__(.+?)__")
    _ITALIC_RE    = re.compile(r"\*(.+?)\*|_(.+?)_")
    _CODE_RE      = re.compile(r"`([^`]+)`")
    _LINK_RE      = re.compile(r"\[([^\]]+)\]\(([^)]+)\)")
    _STRIKE_RE    = re.compile(r"~~(.+?)~~")
    _TASK_RE      = re.compile(r"^(\s*)-\s+\[([ xX])\]\s+(.+)$", re.MULTILINE)
    _CALLOUT_RE   = re.compile(r"^>\s+\[!(NOTE|TIP|WARNING|DANGER|INFO|SUCCESS|QUESTION)\]\s*(.*)$", re.IGNORECASE | re.MULTILINE)
    _FOOTNOTE_DEF = re.compile(r"^\[\^(\w+)\]:\s+(.+)$", re.MULTILINE)
    _FOOTNOTE_REF = re.compile(r"\[\^(\w+)\]")
    _HR_RE        = re.compile(r"^(?:-{3,}|\*{3,}|_{3,})$", re.MULTILINE)
    _BLOCKQUOTE_RE = re.compile(r"^(>\s?.+(?:\n>\s?.+)*)$", re.MULTILINE)
    _TABLE_RE     = re.compile(
        r"(\|.+\|\n\|[-| :]+\|\n(?:\|.+\|\n?)+)", re.MULTILINE
    )

    _CALLOUT_ICONS = {
        "note":     "ℹ",
        "tip":      "💡",
        "warning":  "⚠",
        "danger":   "🔥",
        "info":     "ℹ",
        "success":  "✓",
        "question": "?",
    }

    def __init__(self, config: Optional[RenderConfig] = None) -> None:
        self.cfg = config or RenderConfig()
        self._footnote_defs: Dict[str, str] = {}
        self._toc_entries: List[_TocEntry] = []

    # ------------------------------------------------------------------
    # Public API

    def render(self, text: str) -> str:
        """Render *text* (markdown) to an HTML fragment."""
        self._footnote_defs = {}
        self._toc_entries = []

        if self.cfg.render_footnotes:
            text = self._collect_footnotes(text)

        blocks = self._split_blocks(text)
        parts: List[str] = []
        for block in blocks:
            parts.append(self._render_block(block))

        body = "\n".join(parts)

        if self.cfg.render_footnotes and self._footnote_defs:
            body += self._render_footnote_section()

        if self.cfg.inject_toc and len(self._toc_entries) >= self.cfg.toc_min_headings:
            toc_html = self._render_toc()
            body = body.replace("<!-- toc -->", toc_html, 1)

        return body

    def render_inline(self, text: str) -> str:
        """Render only inline elements (no block structure)."""
        return self._inline(text)

    # ------------------------------------------------------------------
    # Block splitting

    @staticmethod
    def _split_blocks(text: str) -> List[str]:
        """Split markdown into logical blocks separated by blank lines."""
        blocks: List[str] = []
        current: List[str] = []
        in_fence = False
        fence_marker = ""

        for line in text.splitlines():
            stripped = line.strip()
            if not in_fence:
                if stripped.startswith("```") or stripped.startswith("~~~"):
                    in_fence = True
                    fence_marker = stripped[:3]
                    if current:
                        blocks.append("\n".join(current))
                        current = []
                    current.append(line)
                elif stripped == "" and current:
                    blocks.append("\n".join(current))
                    current = []
                else:
                    current.append(line)
            else:
                current.append(line)
                if stripped.startswith(fence_marker) and len(stripped) >= 3 and stripped != fence_marker[0] * len(stripped[:3] + "x"):
                    # ended fence
                    if stripped == fence_marker or stripped.startswith(fence_marker) and len(stripped) == len(fence_marker):
                        in_fence = False
                        blocks.append("\n".join(current))
                        current = []

        if current:
            blocks.append("\n".join(current))
        return blocks

    # ------------------------------------------------------------------
    # Block renderers

    def _render_block(self, block: str) -> str:
        lines = block.splitlines()
        first = lines[0] if lines else ""

        # Fenced code block
        if first.startswith("```") or first.startswith("~~~"):
            return self._render_fence(block)

        # Heading
        m = re.match(r"^(#{1,6})\s+(.+)$", first)
        if m and len(lines) == 1:
            return self._render_heading(len(m.group(1)), m.group(2))

        # Horizontal rule
        if re.match(r"^(?:-{3,}|\*{3,}|_{3,})$", first.strip()) and len(lines) == 1:
            return "<hr />"

        # Callout (blockquote with [!TYPE])
        callout_m = re.match(r"^>\s+\[!(NOTE|TIP|WARNING|DANGER|INFO|SUCCESS|QUESTION)\]\s*(.*)$", first, re.IGNORECASE)
        if callout_m and self.cfg.render_callouts:
            return self._render_callout(callout_m, lines[1:])

        # Blockquote
        if first.startswith(">"):
            return self._render_blockquote(block)

        # Table
        if "|" in first and len(lines) >= 2 and re.match(r"^\|[-| :]+\|$", lines[1].strip()):
            return self._render_table(lines)

        # Unordered list
        if re.match(r"^\s*[-*+]\s", first):
            return self._render_list(lines, ordered=False)

        # Ordered list
        if re.match(r"^\s*\d+\.\s", first):
            return self._render_list(lines, ordered=True)

        # Paragraph / inline
        text = " ".join(lines)
        return f"<p>{self._inline(text)}</p>"

    def _render_fence(self, block: str) -> str:
        lines = block.splitlines()
        marker = lines[0].strip()
        lang = marker.lstrip("`~").strip()
        code_lines = lines[1:-1] if len(lines) > 2 else []
        code = "\n".join(code_lines)
        esc = html.escape(code)

        if lang == "mermaid" and self.cfg.render_mermaid:
            uid = hashlib.md5(code.encode()).hexdigest()[:8]
            return (
                f'<div class="mermaid-wrapper" data-id="{uid}">'
                f'<pre class="mermaid">{esc}</pre></div>'
            )

        lang_attr = f' data-lang="{html.escape(lang)}"' if lang else ""
        label = f'<span class="code-lang">{html.escape(lang)}</span>' if lang else ""
        return (
            f'<div class="code-block">{label}'
            f'<pre><code class="language-{html.escape(lang)}"{lang_attr}>{esc}</code></pre></div>'
        )

    def _render_heading(self, level: int, text: str) -> str:
        clean = re.sub(r"[^\w\s-]", "", text.lower())
        anchor = re.sub(r"\s+", "-", clean.strip())
        self._toc_entries.append(_TocEntry(level=level, text=text, anchor=anchor))
        inner = self._inline(text)
        return f'<h{level} id="{anchor}">{inner} <a class="anchor" href="#{anchor}">¶</a></h{level}>'

    def _render_callout(self, m: re.Match, rest_lines: List[str]) -> str:
        kind = m.group(1).lower()
        title = m.group(2).strip() or kind.capitalize()
        icon = self._CALLOUT_ICONS.get(kind, "ℹ")
        body_lines = [line.lstrip("> ") for line in rest_lines]
        body = self._inline(" ".join(body_lines))
        return (
            f'<div class="callout callout-{kind}">'
            f'<div class="callout-title">{icon} {html.escape(title)}</div>'
            f'<div class="callout-body">{body}</div></div>'
        )

    def _render_blockquote(self, block: str) -> str:
        inner_lines = [re.sub(r"^>\s?", "", l) for l in block.splitlines()]
        inner = self.render("\n".join(inner_lines))
        return f"<blockquote>{inner}</blockquote>"

    def _render_table(self, lines: List[str]) -> str:
        headers = [c.strip() for c in lines[0].strip("|").split("|")]
        alignments: List[str] = []
        for cell in lines[1].strip("|").split("|"):
            cell = cell.strip()
            if cell.startswith(":") and cell.endswith(":"):
                alignments.append("center")
            elif cell.endswith(":"):
                alignments.append("right")
            else:
                alignments.append("left")

        thead = "<tr>" + "".join(
            f'<th style="text-align:{a}">{self._inline(h)}</th>'
            for h, a in zip(headers, alignments)
        ) + "</tr>"

        tbody_rows = []
        for row_line in lines[2:]:
            cells = [c.strip() for c in row_line.strip("|").split("|")]
            row = "<tr>" + "".join(
                f'<td style="text-align:{alignments[i] if i < len(alignments) else "left"}">'
                f"{self._inline(c)}</td>"
                for i, c in enumerate(cells)
            ) + "</tr>"
            tbody_rows.append(row)

        tbody = "\n".join(tbody_rows)
        return f'<div class="table-wrapper"><table><thead>{thead}</thead><tbody>{tbody}</tbody></table></div>'

    def _render_list(self, lines: List[str], ordered: bool) -> str:
        tag = "ol" if ordered else "ul"
        items_html: List[str] = []
        item_lines: List[str] = []

        def flush() -> None:
            if item_lines:
                content = " ".join(item_lines).strip()
                # task list
                task_m = re.match(r"\[([ xX])\]\s+(.*)", content)
                if task_m and self.cfg.render_task_lists:
                    checked = 'checked=""' if task_m.group(1).lower() == "x" else ""
                    label = self._inline(task_m.group(2))
                    items_html.append(
                        f'<li class="task-item"><input type="checkbox" disabled {checked}/> {label}</li>'
                    )
                else:
                    items_html.append(f"<li>{self._inline(content)}</li>")
                item_lines.clear()

        for line in lines:
            stripped = line.strip()
            if re.match(r"^[-*+]\s", stripped):
                flush()
                item_lines.append(re.sub(r"^[-*+]\s+", "", stripped))
            elif re.match(r"^\d+\.\s", stripped):
                flush()
                item_lines.append(re.sub(r"^\d+\.\s+", "", stripped))
            elif stripped:
                item_lines.append(stripped)
        flush()

        return f"<{tag}>{''.join(items_html)}</{tag}>"

    def _render_footnote_section(self) -> str:
        items = "".join(
            f'<li id="fn-{html.escape(k)}">'
            f'{self._inline(v)}'
            f' <a href="#fnref-{html.escape(k)}">↩</a></li>'
            for k, v in self._footnote_defs.items()
        )
        return f'<hr /><section class="footnotes"><ol>{items}</ol></section>'

    def _render_toc(self) -> str:
        if not self._toc_entries:
            return ""
        min_level = min(e.level for e in self._toc_entries)
        items = []
        for e in self._toc_entries:
            indent = "  " * (e.level - min_level)
            items.append(
                f'{indent}<li><a href="#{html.escape(e.anchor)}">'
                f"{html.escape(e.text)}</a></li>"
            )
        return f'<nav class="toc"><ul>\n{"".join(items)}\n</ul></nav>'

    # ------------------------------------------------------------------
    # Inline rendering

    def _inline(self, text: str) -> str:
        if self.cfg.safe_mode:
            text = re.sub(r"<[^>]+>", "", text)

        # collect footnote refs first
        if self.cfg.render_footnotes:
            text = self._FOOTNOTE_REF.sub(self._footnote_ref_sub, text)

        text = self._WIKI_RE.sub(self._wiki_link_sub, text)
        text = self._LINK_RE.sub(self._md_link_sub, text)
        text = self._HASHTAG_RE.sub(self._hashtag_sub, text)
        text = self._BOLD_RE.sub(lambda m: f"<strong>{m.group(1) or m.group(2)}</strong>", text)
        text = self._ITALIC_RE.sub(lambda m: f"<em>{m.group(1) or m.group(2)}</em>", text)
        text = self._STRIKE_RE.sub(lambda m: f"<del>{m.group(1)}</del>", text)
        text = self._CODE_RE.sub(lambda m: f"<code>{html.escape(m.group(1))}</code>", text)
        return text

    def _wiki_link_sub(self, m: re.Match) -> str:
        target = m.group(1).strip()
        label  = (m.group(2) or target).strip()
        slug   = re.sub(r"\s+", "-", target.lower())
        href   = f"{self.cfg.link_prefix}{slug}"
        return f'<a class="wiki-link" href="{html.escape(href)}">{html.escape(label)}</a>'

    def _md_link_sub(self, m: re.Match) -> str:
        label = m.group(1)
        href  = m.group(2)
        extra = ""
        if href.startswith("http://") or href.startswith("https://"):
            extra = ' target="_blank" rel="noopener noreferrer"'
            if self.cfg.external_link_icon:
                label += " ↗"
        return f'<a href="{html.escape(href)}"{extra}>{html.escape(label)}</a>'

    def _hashtag_sub(self, m: re.Match) -> str:
        tag  = m.group(1)
        href = f"{self.cfg.tag_prefix}{html.escape(tag)}"
        return f'<a class="tag-link" href="{href}">#{html.escape(tag)}</a>'

    def _footnote_ref_sub(self, m: re.Match) -> str:
        key = m.group(1)
        return (
            f'<sup><a id="fnref-{html.escape(key)}" '
            f'href="#fn-{html.escape(key)}">[{html.escape(key)}]</a></sup>'
        )

    # ------------------------------------------------------------------
    # Footnote collection (strip definitions from text before rendering)

    def _collect_footnotes(self, text: str) -> str:
        def collect(m: re.Match) -> str:
            self._footnote_defs[m.group(1)] = m.group(2)
            return ""
        return self._FOOTNOTE_DEF.sub(collect, text)


# ---------------------------------------------------------------------------
# Convenience function

def render_note(text: str, config: Optional[RenderConfig] = None) -> str:
    """Render *text* to HTML using default or provided config."""
    return MarkdownRenderer(config).render(text)


def render_preview(text: str, max_chars: int = 300) -> str:
    """Render the first *max_chars* chars as plain text (no HTML)."""
    stripped = re.sub(r"^---.*?---\s*", "", text, flags=re.DOTALL)
    stripped = re.sub(r"#{1,6}\s+", "", stripped)
    stripped = re.sub(r"\[\[([^\]|]+)(?:\|([^\]]+))?\]\]", lambda m: m.group(2) or m.group(1), stripped)
    stripped = re.sub(r"\*\*(.+?)\*\*", r"\1", stripped)
    stripped = re.sub(r"\*(.+?)\*", r"\1", stripped)
    stripped = re.sub(r"`([^`]+)`", r"\1", stripped)
    stripped = re.sub(r"\s+", " ", stripped).strip()
    if len(stripped) > max_chars:
        return stripped[:max_chars].rsplit(" ", 1)[0] + "…"
    return stripped
