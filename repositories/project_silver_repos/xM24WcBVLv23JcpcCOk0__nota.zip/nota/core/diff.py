"""Note diffing and change detection for nota.

Provides:
  - LineDiff   — line-by-line unified diff with hunk grouping
  - WordDiff   — inline word-level diff for prose
  - MetaDiff   — frontmatter change detection
  - NoteChange — composite change summary between two note snapshots
  - diff_html  — HTML representation of a diff for the web UI
  - changelog  — auto-generate a Markdown changelog between two versions
"""
from __future__ import annotations

import difflib
import html
import re
import textwrap
from dataclasses import dataclass, field
from enum import Enum, auto
from pathlib import Path
from typing import Dict, Iterator, List, Optional, Sequence, Tuple


# ---------------------------------------------------------------------------
# Op types

class Op(Enum):
    EQUAL   = auto()
    INSERT  = auto()
    DELETE  = auto()
    REPLACE = auto()


@dataclass(frozen=True)
class DiffLine:
    op: Op
    old_lineno: Optional[int]
    new_lineno: Optional[int]
    text: str


@dataclass(frozen=True)
class DiffWord:
    op: Op
    text: str


@dataclass
class Hunk:
    old_start: int
    new_start: int
    lines: List[DiffLine] = field(default_factory=list)

    @property
    def old_range(self) -> Tuple[int, int]:
        n = sum(1 for l in self.lines if l.op in (Op.EQUAL, Op.DELETE))
        return self.old_start, n

    @property
    def new_range(self) -> Tuple[int, int]:
        n = sum(1 for l in self.lines if l.op in (Op.EQUAL, Op.INSERT))
        return self.new_start, n

    def header(self) -> str:
        os, oc = self.old_range
        ns, nc = self.new_range
        return f"@@ -{os},{oc} +{ns},{nc} @@"


# ---------------------------------------------------------------------------
# Line diff

class LineDiff:
    """Compute a line-by-line unified diff between two texts."""

    DEFAULT_CONTEXT = 3

    def __init__(self, old: str, new: str, context: int = DEFAULT_CONTEXT) -> None:
        self.old_lines = old.splitlines(keepends=True)
        self.new_lines = new.splitlines(keepends=True)
        self.context   = context
        self._hunks: Optional[List[Hunk]] = None

    # ------------------------------------------------------------------
    # Public

    @property
    def hunks(self) -> List[Hunk]:
        if self._hunks is None:
            self._hunks = list(self._build_hunks())
        return self._hunks

    @property
    def is_empty(self) -> bool:
        return not any(
            l.op != Op.EQUAL for h in self.hunks for l in h.lines
        )

    def stats(self) -> Dict[str, int]:
        added = deleted = unchanged = 0
        for h in self.hunks:
            for l in h.lines:
                if l.op == Op.INSERT:
                    added += 1
                elif l.op == Op.DELETE:
                    deleted += 1
                else:
                    unchanged += 1
        return {"added": added, "deleted": deleted, "unchanged": unchanged}

    def unified_text(self) -> str:
        parts: List[str] = []
        for hunk in self.hunks:
            parts.append(hunk.header())
            for dl in hunk.lines:
                if dl.op == Op.INSERT:
                    parts.append(f"+{dl.text}")
                elif dl.op == Op.DELETE:
                    parts.append(f"-{dl.text}")
                else:
                    parts.append(f" {dl.text}")
        return "\n".join(parts)

    # ------------------------------------------------------------------
    # Internal

    def _build_hunks(self) -> Iterator[Hunk]:
        matcher = difflib.SequenceMatcher(None, self.old_lines, self.new_lines)
        opcodes = matcher.get_opcodes()

        # expand to hunks with context
        groups = list(matcher.get_grouped_opcodes(self.context))
        old_no = 1
        new_no = 1

        for group in groups:
            hunk_old_start = group[0][1] + 1
            hunk_new_start = group[0][3] + 1
            hunk = Hunk(old_start=hunk_old_start, new_start=hunk_new_start)

            for tag, i1, i2, j1, j2 in group:
                if tag == "equal":
                    for line in self.old_lines[i1:i2]:
                        hunk.lines.append(DiffLine(Op.EQUAL, old_no, new_no, line.rstrip("\n")))
                        old_no += 1
                        new_no += 1
                elif tag == "insert":
                    for line in self.new_lines[j1:j2]:
                        hunk.lines.append(DiffLine(Op.INSERT, None, new_no, line.rstrip("\n")))
                        new_no += 1
                elif tag == "delete":
                    for line in self.old_lines[i1:i2]:
                        hunk.lines.append(DiffLine(Op.DELETE, old_no, None, line.rstrip("\n")))
                        old_no += 1
                else:  # replace
                    for line in self.old_lines[i1:i2]:
                        hunk.lines.append(DiffLine(Op.DELETE, old_no, None, line.rstrip("\n")))
                        old_no += 1
                    for line in self.new_lines[j1:j2]:
                        hunk.lines.append(DiffLine(Op.INSERT, None, new_no, line.rstrip("\n")))
                        new_no += 1
            yield hunk


# ---------------------------------------------------------------------------
# Word diff

class WordDiff:
    """Inline word-level diff for prose comparison."""

    _SPLIT_RE = re.compile(r"(\s+|\b)")

    def __init__(self, old: str, new: str) -> None:
        self.old = old
        self.new = new

    def diff(self) -> List[DiffWord]:
        old_tokens = self._tokenize(self.old)
        new_tokens = self._tokenize(self.new)
        matcher = difflib.SequenceMatcher(None, old_tokens, new_tokens)
        result: List[DiffWord] = []
        for tag, i1, i2, j1, j2 in matcher.get_opcodes():
            if tag == "equal":
                for tok in old_tokens[i1:i2]:
                    result.append(DiffWord(Op.EQUAL, tok))
            elif tag == "insert":
                for tok in new_tokens[j1:j2]:
                    result.append(DiffWord(Op.INSERT, tok))
            elif tag == "delete":
                for tok in old_tokens[i1:i2]:
                    result.append(DiffWord(Op.DELETE, tok))
            else:
                for tok in old_tokens[i1:i2]:
                    result.append(DiffWord(Op.DELETE, tok))
                for tok in new_tokens[j1:j2]:
                    result.append(DiffWord(Op.INSERT, tok))
        return result

    def html(self) -> str:
        parts: List[str] = []
        for dw in self.diff():
            esc = html.escape(dw.text)
            if dw.op == Op.INSERT:
                parts.append(f'<ins class="wd-ins">{esc}</ins>')
            elif dw.op == Op.DELETE:
                parts.append(f'<del class="wd-del">{esc}</del>')
            else:
                parts.append(esc)
        return "".join(parts)

    def _tokenize(self, text: str) -> List[str]:
        return [t for t in self._SPLIT_RE.split(text) if t]


# ---------------------------------------------------------------------------
# Metadata diff

@dataclass
class FieldChange:
    field: str
    old_value: object
    new_value: object

    @property
    def op(self) -> Op:
        if self.old_value is None:
            return Op.INSERT
        if self.new_value is None:
            return Op.DELETE
        return Op.REPLACE


class MetaDiff:
    """Detect changes in note frontmatter (as plain dicts)."""

    def __init__(self, old_meta: Dict, new_meta: Dict) -> None:
        self.old = old_meta
        self.new = new_meta

    def changes(self) -> List[FieldChange]:
        result: List[FieldChange] = []
        all_keys = set(self.old) | set(self.new)
        for k in sorted(all_keys):
            ov = self.old.get(k)
            nv = self.new.get(k)
            if ov != nv:
                result.append(FieldChange(field=k, old_value=ov, new_value=nv))
        return result

    def is_empty(self) -> bool:
        return not self.changes()

    def summary(self) -> str:
        parts: List[str] = []
        for ch in self.changes():
            if ch.op == Op.INSERT:
                parts.append(f"+ {ch.field}: {ch.new_value!r}")
            elif ch.op == Op.DELETE:
                parts.append(f"- {ch.field}: {ch.old_value!r}")
            else:
                parts.append(f"~ {ch.field}: {ch.old_value!r} → {ch.new_value!r}")
        return "\n".join(parts)


# ---------------------------------------------------------------------------
# Composite change summary

@dataclass
class NoteChange:
    """Summary of all changes between two snapshots of a note."""
    path: Path
    body_diff: LineDiff
    meta_diff: MetaDiff
    word_delta: int        # +/- word count
    link_added: List[str]  = field(default_factory=list)
    link_removed: List[str] = field(default_factory=list)

    @property
    def has_body_changes(self) -> bool:
        return not self.body_diff.is_empty

    @property
    def has_meta_changes(self) -> bool:
        return not self.meta_diff.is_empty

    @property
    def is_empty(self) -> bool:
        return not self.has_body_changes and not self.has_meta_changes

    def summary_line(self) -> str:
        stats = self.body_diff.stats()
        parts = [f"{self.path.name}:"]
        if stats["added"]:
            parts.append(f"+{stats['added']} lines")
        if stats["deleted"]:
            parts.append(f"-{stats['deleted']} lines")
        if self.word_delta:
            sign = "+" if self.word_delta >= 0 else ""
            parts.append(f"{sign}{self.word_delta} words")
        if self.link_added:
            parts.append(f"{len(self.link_added)} links added")
        if self.link_removed:
            parts.append(f"{len(self.link_removed)} links removed")
        return " ".join(parts)


def compare_notes(
    old_text: str,
    new_text: str,
    path: Path,
    old_meta: Optional[Dict] = None,
    new_meta: Optional[Dict] = None,
    old_links: Optional[List[str]] = None,
    new_links: Optional[List[str]] = None,
) -> NoteChange:
    """Build a NoteChange by comparing two text snapshots."""
    old_meta = old_meta or {}
    new_meta = new_meta or {}
    old_links = old_links or []
    new_links  = new_links or []

    body_diff = LineDiff(old_text, new_text)
    meta_diff = MetaDiff(old_meta, new_meta)

    old_wc = len(old_text.split())
    new_wc = len(new_text.split())

    old_set = set(old_links)
    new_set  = set(new_links)
    return NoteChange(
        path=path,
        body_diff=body_diff,
        meta_diff=meta_diff,
        word_delta=new_wc - old_wc,
        link_added=sorted(new_set - old_set),
        link_removed=sorted(old_set - new_set),
    )


# ---------------------------------------------------------------------------
# HTML output

def diff_html(diff: LineDiff, context: int = 3) -> str:
    """Render a LineDiff as an HTML table (side-by-side or unified)."""
    rows: List[str] = []
    for hunk in diff.hunks:
        rows.append(
            f'<tr class="diff-hunk"><td colspan="4">'
            f'<code>{html.escape(hunk.header())}</code></td></tr>'
        )
        for dl in hunk.lines:
            if dl.op == Op.EQUAL:
                cls = "diff-eq"
                prefix = " "
            elif dl.op == Op.INSERT:
                cls = "diff-ins"
                prefix = "+"
            else:
                cls = "diff-del"
                prefix = "-"

            old_no = str(dl.old_lineno) if dl.old_lineno is not None else ""
            new_no = str(dl.new_lineno) if dl.new_lineno is not None else ""
            esc   = html.escape(dl.text)
            rows.append(
                f'<tr class="{cls}">'
                f'<td class="ln old">{old_no}</td>'
                f'<td class="ln new">{new_no}</td>'
                f'<td class="diff-op">{prefix}</td>'
                f'<td class="diff-text"><code>{esc}</code></td>'
                f"</tr>"
            )
    body = "\n".join(rows)
    return f'<table class="diff-table"><tbody>{body}</tbody></table>'


# ---------------------------------------------------------------------------
# Markdown changelog generator

def changelog(changes: List[NoteChange]) -> str:
    """Generate a Markdown summary of a list of NoteChange objects."""
    if not changes:
        return "_No changes._"

    lines: List[str] = ["## Changes\n"]
    for nc in changes:
        if nc.is_empty:
            continue
        lines.append(f"### {nc.path.stem}")
        lines.append(nc.summary_line())
        if nc.has_meta_changes:
            lines.append("\n**Metadata:**")
            lines.append("```")
            lines.append(nc.meta_diff.summary())
            lines.append("```")
        if nc.link_added:
            lines.append("\n**Links added:** " + ", ".join(f"[[{l}]]" for l in nc.link_added))
        if nc.link_removed:
            lines.append("\n**Links removed:** " + ", ".join(f"[[{l}]]" for l in nc.link_removed))
        stats = nc.body_diff.stats()
        lines.append(
            f"\n_{stats['added']} lines added, {stats['deleted']} lines removed_\n"
        )
    return "\n".join(lines)
