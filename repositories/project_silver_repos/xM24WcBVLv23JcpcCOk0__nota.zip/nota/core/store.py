from __future__ import annotations

import json
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Dict, Iterable, Iterator, List, Optional, Tuple

from .note import Note, iter_markdown

_SCHEMA = """
CREATE TABLE IF NOT EXISTS notes (
    id       TEXT PRIMARY KEY,
    path     TEXT NOT NULL,
    title    TEXT,
    tags     TEXT,   -- JSON array
    links    TEXT,   -- JSON array
    checksum TEXT,
    created  TEXT,
    modified TEXT,
    words    INTEGER DEFAULT 0
);

CREATE VIRTUAL TABLE IF NOT EXISTS fts USING fts5(
    id,
    title,
    content,
    tokenize = 'porter unicode61'
);

CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT
);

CREATE INDEX IF NOT EXISTS idx_notes_modified ON notes(modified DESC);
CREATE INDEX IF NOT EXISTS idx_notes_created  ON notes(created  DESC);
"""

_INSERT_NOTE = """
INSERT OR REPLACE INTO notes (id, path, title, tags, links, checksum, created, modified, words)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
"""


class Store:
    """SQLite-backed index of a nota vault.

    The database lives at <vault>/.nota/index.db and is kept in WAL mode
    for safe concurrent reads while the watcher writes.
    """

    def __init__(self, vault_root: Path) -> None:
        self.vault_root = vault_root.resolve()
        self._db_path   = vault_root / ".nota" / "index.db"
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn: Optional[sqlite3.Connection] = None

    # ------------------------------------------------------------------
    # connection management

    @property
    def conn(self) -> sqlite3.Connection:
        if self._conn is None:
            self._conn = sqlite3.connect(str(self._db_path))
            self._conn.row_factory = sqlite3.Row
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA synchronous=NORMAL")
            self._conn.execute("PRAGMA foreign_keys=ON")
            self._conn.execute("PRAGMA cache_size=-8000")  # 8 MB page cache
            self._conn.executescript(_SCHEMA)
            self._conn.commit()
        return self._conn

    def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None

    def __enter__(self) -> "Store":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    # ------------------------------------------------------------------
    # iteration

    def notes(self) -> Iterator[Note]:
        """Yield every note in the vault as a lazy Note object."""
        for p in iter_markdown(self.vault_root):
            yield Note(p, self.vault_root)

    def note_count(self) -> int:
        return sum(1 for _ in iter_markdown(self.vault_root))

    # ------------------------------------------------------------------
    # lookup

    def get(self, ref: str) -> Optional[Note]:
        """Resolve *ref* to a Note.

        Resolution order:
        1. Exact vault-relative id (e.g. ``projects/auth.md``)
        2. Plain filename (``auth.md``)
        3. Stem match (``auth``)
        4. Case-insensitive title match
        """
        # exact id / path
        candidate = self.vault_root / ref
        if candidate.exists():
            return Note(candidate, self.vault_root)

        # filename
        candidate2 = self.vault_root / (ref if ref.endswith(".md") else ref + ".md")
        if candidate2.exists():
            return Note(candidate2, self.vault_root)

        ref_lower = ref.lower()
        for note in self.notes():
            if note.stem.lower() == ref_lower or note.title.lower() == ref_lower:
                return note
        return None

    def get_many(self, refs: Iterable[str]) -> List[Note]:
        return [n for r in refs if (n := self.get(r)) is not None]

    # ------------------------------------------------------------------
    # indexing

    def index_note(self, note: Note) -> None:
        """Index or re-index a single note."""
        tags     = json.dumps(note.tags)
        links    = json.dumps(note.unique_links)
        created  = note.created.isoformat() if note.created else None
        modified = note.modified.isoformat()
        words    = note.word_count

        self.conn.execute(_INSERT_NOTE, (
            note.id, str(note.path), note.title,
            tags, links, note.checksum,
            created, modified, words,
        ))
        self.conn.execute("DELETE FROM fts WHERE id=?", (note.id,))
        self.conn.execute(
            "INSERT INTO fts(id, title, content) VALUES (?, ?, ?)",
            (note.id, note.title, note.content),
        )

    def index_all(self, *, force: bool = False) -> int:
        """Re-index changed notes. Returns the count of updated notes."""
        cur = self.conn.execute("SELECT id, checksum FROM notes")
        cached: Dict[str, str] = {row["id"]: row["checksum"] for row in cur}

        updated = 0
        live_ids: set[str] = set()
        for note in self.notes():
            live_ids.add(note.id)
            if force or cached.get(note.id) != note.checksum:
                try:
                    self.index_note(note)
                    updated += 1
                except Exception:
                    pass

        # prune stale entries (deleted notes)
        stale = set(cached) - live_ids
        for sid in stale:
            self.conn.execute("DELETE FROM notes WHERE id=?", (sid,))
            self.conn.execute("DELETE FROM fts WHERE id=?", (sid,))

        self.conn.commit()
        return updated

    def remove_note(self, note_id: str) -> None:
        self.conn.execute("DELETE FROM notes WHERE id=?", (note_id,))
        self.conn.execute("DELETE FROM fts WHERE id=?", (note_id,))
        self.conn.commit()

    # ------------------------------------------------------------------
    # full-text search

    def search(self, query: str, limit: int = 20) -> List[Note]:
        """Full-text search via FTS5 with BM25 ranking."""
        try:
            rows = self.conn.execute(
                "SELECT id FROM fts WHERE fts MATCH ? ORDER BY rank LIMIT ?",
                (query, limit),
            ).fetchall()
        except sqlite3.OperationalError:
            return []
        results: List[Note] = []
        for row in rows:
            p = self.vault_root / row["id"]
            if p.exists():
                results.append(Note(p, self.vault_root))
        return results

    def search_by_tag(self, query: str, limit: int = 20) -> List[Note]:
        """Filter by tag substring using the indexed JSON tags column."""
        rows = self.conn.execute(
            "SELECT id FROM notes WHERE tags LIKE ? LIMIT ?",
            (f"%{query}%", limit),
        ).fetchall()
        results: List[Note] = []
        for row in rows:
            p = self.vault_root / row["id"]
            if p.exists():
                results.append(Note(p, self.vault_root))
        return results

    # ------------------------------------------------------------------
    # relational queries

    def backlinks(self, note: Note) -> List[Note]:
        """Return all notes that contain a wiki-link pointing to *note*."""
        stem = note.stem
        return [
            n for n in self.notes()
            if stem in n.links or note.id in n.links
        ]

    def by_tag(self, tag: str) -> List[Note]:
        return [n for n in self.notes() if tag in n.tags]

    def by_tags(self, tags: List[str], *, require_all: bool = False) -> List[Note]:
        """Filter notes by multiple tags (OR by default, AND if require_all)."""
        tag_set = set(tags)
        results = []
        for note in self.notes():
            note_tags = set(note.tags)
            if require_all:
                if tag_set.issubset(note_tags):
                    results.append(note)
            else:
                if tag_set & note_tags:
                    results.append(note)
        return results

    def recent(self, n: int = 10) -> List[Note]:
        """Return the *n* most recently modified notes."""
        rows = self.conn.execute(
            "SELECT id FROM notes ORDER BY modified DESC LIMIT ?", (n,)
        ).fetchall()
        results: List[Note] = []
        for row in rows:
            p = self.vault_root / row["id"]
            if p.exists():
                results.append(Note(p, self.vault_root))
        return results

    def created_between(self, start: datetime, end: datetime) -> List[Note]:
        rows = self.conn.execute(
            "SELECT id FROM notes WHERE created >= ? AND created <= ? ORDER BY created",
            (start.isoformat(), end.isoformat()),
        ).fetchall()
        return [Note(self.vault_root / r["id"], self.vault_root)
                for r in rows if (self.vault_root / r["id"]).exists()]

    def longest_notes(self, n: int = 10) -> List[Tuple[Note, int]]:
        """Return (note, word_count) for the *n* longest notes."""
        rows = self.conn.execute(
            "SELECT id, words FROM notes ORDER BY words DESC LIMIT ?", (n,)
        ).fetchall()
        results: List[Tuple[Note, int]] = []
        for row in rows:
            p = self.vault_root / row["id"]
            if p.exists():
                results.append((Note(p, self.vault_root), row["words"]))
        return results

    # ------------------------------------------------------------------
    # tags

    def all_tags(self) -> Dict[str, int]:
        """Return {tag: note_count} sorted by descending count."""
        counts: Dict[str, int] = {}
        for note in self.notes():
            for tag in note.tags:
                counts[tag] = counts.get(tag, 0) + 1
        return dict(sorted(counts.items(), key=lambda x: -x[1]))

    def tag_cloud(self, limit: int = 50) -> List[Tuple[str, int]]:
        """Return top *limit* (tag, count) pairs for display."""
        return list(self.all_tags().items())[:limit]

    def notes_without_tags(self) -> List[Note]:
        return [n for n in self.notes() if not n.tags]

    # ------------------------------------------------------------------
    # graph

    def graph(self) -> Dict[str, List[str]]:
        """Return directed adjacency list {note_id: [linked_note_ids]}."""
        stems: Dict[str, str] = {n.stem: n.id for n in self.notes()}
        adj: Dict[str, List[str]] = {}
        for note in self.notes():
            targets: List[str] = []
            for link in note.unique_links:
                resolved = (
                    stems.get(link)
                    or (link if (self.vault_root / link).exists() else None)
                )
                if resolved and resolved != note.id:
                    targets.append(resolved)
            adj[note.id] = targets
        return adj

    # ------------------------------------------------------------------
    # statistics

    def stats(self) -> Dict[str, object]:
        row = self.conn.execute(
            "SELECT COUNT(*) as n, COALESCE(SUM(words),0) as w, "
            "COALESCE(SUM(json_array_length(links)),0) as l FROM notes"
        ).fetchone()
        return {
            "notes":    row["n"],
            "words":    row["w"],
            "links":    row["l"],
            "tags":     len(self.all_tags()),
        }

    def full_stats(self) -> Dict[str, object]:
        """Extended stats including graph metrics."""
        from .graph import graph_summary
        base = self.stats()
        base["graph"] = graph_summary(self.graph())
        longest = self.longest_notes(3)
        base["longest"] = [{"id": n.id, "words": w} for n, w in longest]
        return base

    # ------------------------------------------------------------------
    # meta key/value store (for plugins and extensions)

    def get_meta(self, key: str) -> Optional[str]:
        row = self.conn.execute(
            "SELECT value FROM meta WHERE key=?", (key,)
        ).fetchone()
        return row["value"] if row else None

    def set_meta(self, key: str, value: str) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO meta(key, value) VALUES (?, ?)", (key, value)
        )
        self.conn.commit()

    def delete_meta(self, key: str) -> None:
        self.conn.execute("DELETE FROM meta WHERE key=?", (key,))
        self.conn.commit()
