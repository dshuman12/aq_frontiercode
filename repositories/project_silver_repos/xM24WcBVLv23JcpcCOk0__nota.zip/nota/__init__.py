"""nota — local-first markdown knowledge base."""

__version__ = "0.5.2"
__author__ = "Pramoth Krishna"
__email__ = "pramodhkrishna42@gmail.com"
