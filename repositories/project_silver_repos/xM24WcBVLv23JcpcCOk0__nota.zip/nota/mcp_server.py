"""MCP (Model Context Protocol) server for nota.

Exposes the vault as an MCP resource so AI assistants can read,
search, and create notes without leaving their chat interface.

Usage:
    nota mcp-serve --vault /path/to/vault
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional

from .core.store import Store
from .core.search import ranked_search


def _make_note_resource(store: Store, note_id: str) -> Dict[str, Any]:
    note = store.get(note_id)
    if note is None:
        return {"error": f"note not found: {note_id}"}
    return {
        "uri": f"nota://{note.id}",
        "title": note.title,
        "content": note.raw,
        "metadata": note.metadata,
        "tags": note.tags,
        "links": note.links,
    }


def serve(vault_root: Path, host: str = "127.0.0.1", port: int = 5173) -> None:
    try:
        from mcp.server import Server  # type: ignore
        from mcp.server.stdio import stdio_server  # type: ignore
        import mcp.types as types  # type: ignore
    except ImportError as exc:
        raise RuntimeError("MCP server requires: pip install nota[mcp]") from exc

    store = Store(vault_root)
    store.index_all()

    server = Server("nota")

    @server.list_resources()  # type: ignore
    async def list_resources() -> List[types.Resource]:
        return [
            types.Resource(
                uri=f"nota://{n.id}",
                name=n.title,
                description=f"nota note — {n.id}",
                mimeType="text/markdown",
            )
            for n in store.notes()
        ]

    @server.read_resource()  # type: ignore
    async def read_resource(uri: str) -> str:
        note_id = uri.removeprefix("nota://")
        note = store.get(note_id)
        if note is None:
            raise ValueError(f"Note not found: {note_id}")
        return note.raw

    @server.list_tools()  # type: ignore
    async def list_tools() -> List[types.Tool]:
        return [
            types.Tool(
                name="search_notes",
                description="Full-text search across the nota vault",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "query": {"type": "string", "description": "Search query"},
                        "limit": {"type": "integer", "default": 10},
                    },
                    "required": ["query"],
                },
            ),
            types.Tool(
                name="create_note",
                description="Create a new note in the vault",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "title": {"type": "string"},
                        "content": {"type": "string"},
                        "tags": {"type": "array", "items": {"type": "string"}},
                    },
                    "required": ["title", "content"],
                },
            ),
        ]

    @server.call_tool()  # type: ignore
    async def call_tool(name: str, arguments: Dict[str, Any]) -> Any:
        if name == "search_notes":
            results = ranked_search(store, arguments["query"], arguments.get("limit", 10))
            return [{"id": n.id, "title": n.title, "path": str(n.path)} for n in results]
        if name == "create_note":
            from datetime import datetime
            from .cli import _create_note
            note = _create_note(
                store.vault_root,
                title=arguments["title"],
                content=arguments["content"],
                tags=arguments.get("tags", []),
            )
            store.index_note(note)
            store.conn.commit()
            return {"id": note.id, "path": str(note.path)}
        raise ValueError(f"Unknown tool: {name}")

    import asyncio
    asyncio.run(stdio_server(server))
